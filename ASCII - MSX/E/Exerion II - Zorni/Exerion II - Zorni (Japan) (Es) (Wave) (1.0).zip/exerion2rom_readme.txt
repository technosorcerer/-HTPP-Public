Exerion 2 (MSX)
Traducción al Español v1.0 (22/01/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Exerion 2 (1984) (Toshiba Emi) (J).rom
MD5: e8519fc1f9a4af0115a8abb450b32bd6
SHA1: 2b36fe2b0d98d65ab31f13fcb858db6858a51d46
CRC32: 0b6c146f
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --