Language patch (text only)
Language: Dutch
--------------------------

Vertaling naar het Nederlands
Versie: 1.0
Datum: 21-06-2019
(c) 2019 Kana Translations

--------------------------
Opmerkingen bij deze patch
--------------------------
Deze vertaling en hack is geheel oorspronkelijk.

--------------------------
Patch-instructies
--------------------------
De patch heeft de IPS-indeling, en kan worden toegpast
met LunarIPS of Floating IPS.

--------------------------
Spelinformatie
--------------------------
Gebruikt oorspronkelijk bronbestand:

Titel: Elevator Action (Japan)
MD5: 4ececca3e5358198c39747d08d3e5f66
SHA1: 6cbddd118afe63e79cb8a40f8aa879df1c7590e1
CRC32: 39886593
32768 bytes

--------------------------
Dankwoord/Credits
--------------------------
Kana - Nederlandse vertaling en hack

--------------------------
Very special thanks
--------------------------
Wave - voor het briljante programma Hextractor, website:
traduccioneswave.blogspot.com

-- EINDE --