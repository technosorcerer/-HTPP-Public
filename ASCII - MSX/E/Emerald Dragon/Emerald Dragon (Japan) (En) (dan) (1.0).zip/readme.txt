emerald dragon - spanish-english translation by dan

warning: the translation has be done by a non-native speaker, so if you are particular about english, please refrain from playing this version


the ips files work on the following disks:

Emerald Dragon (1990)(Glodia)(jp)(Disk 1 of 5)(Visual Disk A)
Emerald Dragon (1990)(Glodia)(jp)(Disk 2 of 5)(Visual Disk B)
Emerald Dragon (1990)(Glodia)(jp)(Disk 3 of 5)(Opening Disk)
Emerald Dragon (1990)(Glodia)(jp)(Disk 4 of 5)(Game Disk)
Emerald Dragon (1990)(Glodia)(jp)(Disk 5 of 5)(Ending Disk)

the game starts with visual disk A (not with the game disk)
i would have liked to make some improvements, but i'm not a programmer :(
there's a bug in the selection menu, so please use numbers when making a selection
the game crashes when playing with a philips nms (please don't ask me why)

un gran remerciement � django pour m'avoir encourag� � traduire le jeu

thanks for playing





