Antarctic Adventure (MSX)
Traducci�n al Espa�ol v1.0 (30/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Antarctic Adventure (1984) (Konami) (J).rom
MD5: 97ee96f00fac07a5d70a3801d8a9805a
SHA1: e894a38f3e2ad435cc5d17a66600e6016b5e47fb
CRC32: aae7028b
16.384 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --