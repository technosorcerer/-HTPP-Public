Actman (MSX)
Traducción al Español v1.0 (24/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Actman (1984) (Mass Tael) (J).rom
MD5: 399552677f6eceb94f6c86878f4acb12
SHA1: cb48969f27eaebf24c61f651399ec2433d85bcbc
CRC32: e4dbcdbd
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --