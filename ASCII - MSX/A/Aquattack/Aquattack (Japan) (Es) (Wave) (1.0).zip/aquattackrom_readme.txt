Aquattack (MSX)
Traducción al Español v1.0 (19/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Aquattack (1984) (Toshiba Emi) (J).rom
MD5: 796881611b3499463ccdbd59dc9f731a
SHA1: 93462ac9a322c2e5e0d996fddbe9eba2f3436931
CRC32: f3297895
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --