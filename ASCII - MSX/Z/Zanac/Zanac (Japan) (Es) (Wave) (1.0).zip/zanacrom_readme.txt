Zanac (MSX)
Traducción al Español v1.0 (15/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Zanac (1986) (Pony Cannon) (J).rom
MD5: 7ae5847140746484ec6cf739eede5b15
SHA1: 46e9ed7b7f6dfda8eee266476c9ebc4dd9d8fcc2
CRC32: 425e0d34
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --