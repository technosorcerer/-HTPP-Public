Language patch (text only)
Language: Dutch
--------------------------

Vertaling naar het Nederlands
Versie: 1.0
Datum: 19-06-2019
(c) 2019 Kana Translations

--------------------------
Opmerkingen bij deze patch
--------------------------
Deze vertaling en hack is geheel oorspronkelijk.

--------------------------
Patch-instructies
--------------------------
De patch heeft de IPS-indeling, en kan worden toegpast
met LunarIPS of Floating IPS.

--------------------------
Spelinformatie
--------------------------
Gebruikt oorspronkelijk bronbestand:

Titel: Video Hustler (Japan).mx1
MD5: 08a7bf1ad4fdc213a203f191615bbc9c
SHA1: 82868a81d805fb391fce588623fc888296cbf62a
CRC32: 64853262
8192 bytes

Titel: Video Hustler (Japan) (Alt 1)
MD5: ccfb673858f03940aca707ad5c4af7f2
SHA1: eed68d254a17d76c36e094dd8a50a362a964e1b7
CRC32: 8d99c3b0
8192 bytes

--------------------------
Dankwoord/Credits
--------------------------
Kana - Nederlandse vertaling en hack

--------------------------
Very special thanks
--------------------------
Wave - voor het briljante programma Hextractor, website:
traduccioneswave.blogspot.com

-- EINDE --