Star Force (MSX)
Traducción al Español v1.0 (19/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Star Force (1985) (Hudson) (J).rom
MD5: 202e2df136f4ba32d175dd8e93210bbb
SHA1: c1746efeb4b44dcc80dfc4f429009feac91d9c48
CRC32: c14e53a1
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --