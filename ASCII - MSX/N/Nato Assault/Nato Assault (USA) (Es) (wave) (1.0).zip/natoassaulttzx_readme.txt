Nato Assault (ZX Spectrum)
Traducción al Español v1.0 (02/08/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Nato Assault.tzx
MD5: a4830b2a1cdbe00a13f75752edd615a5
SHA1: 6933210f33ec83895ffbf506f4d7fd4bf01495ab
CRC32: ba2d917d
58411 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --