Language patch (text only)
Language: Dutch

--------------------------
Oh Shit! (MSX)
--------------------------

Vertaling naar het Nederlands
Versie: 1.0
Datum: 25/08/2019
(c) 2019 Kana Translations

--------------------------
Opmerkingen bij deze patch
--------------------------
Deze vertaling en hack is geheel oorspronkelijk.

--------------------------
Patch-instructies
--------------------------
De patch heeft de IPS-indeling, en kan worden toegpast
met LunarIPS of Floating IPS.

--------------------------
Spelinformatie
--------------------------
Gebruikt oorspronkelijk bronbestand:

Oh Shit!.mx1
MD5: 1721862f3f033e74607af9e26688403d
SHA1: 9a369b52f92269073dd7b7e72919d6b1d19fe63d
CRC32: 1d34e4e0
32768 bytes
Note: this is the rom version!


--------------------------
Dankwoord/Credits
--------------------------
Kana - Nederlandse vertaling en hack

--------------------------
Very special thanks
--------------------------
Wave - voor het briljante programma Hextractor, website:
traduccioneswave.blogspot.com

https://www.msxgamesworld.com/gamecard.php?id=790
-- EINDE --