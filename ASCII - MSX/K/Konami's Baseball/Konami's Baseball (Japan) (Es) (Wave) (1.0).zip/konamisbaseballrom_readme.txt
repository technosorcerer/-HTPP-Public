Konami's Baseball (MSX)
Traducción al Español v1.0 (12/12/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Konami's Baseball (1984) (Konami) (J).rom
MD5: 039a7ea2de0aa7261cad28ac8539e887
SHA1: 076d6f5b9f8427f6959f7a255abb4acac0dd9d0c
CRC32: b660494b
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --