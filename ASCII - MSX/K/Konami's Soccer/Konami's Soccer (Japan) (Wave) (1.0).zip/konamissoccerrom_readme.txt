Konami's Soccer (MSX)
Traducci�n al Espa�ol v1.0 (19/05/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Konami's Soccer (1985) (Konami) (J).rom
MD5: a113021087cc957f6bd64600a315e44d
SHA1: fd7518a6aedb51630364082c27bdfe4411adfd4c
CRC32: 74bc8295
32768 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --