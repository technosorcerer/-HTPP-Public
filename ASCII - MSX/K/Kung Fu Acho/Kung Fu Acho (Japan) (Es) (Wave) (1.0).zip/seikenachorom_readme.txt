Seiken Acho (MSX)
Traducción al Español v1.0 (19/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Seiken Acho (1985) (Ascii) (J).rom
MD5: a2bda3945fd30a31af5019aa9ac3c87a
SHA1: 530ecff542a537c320b17bd5d64c86d5d65619f3
CRC32: 999dd794
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --