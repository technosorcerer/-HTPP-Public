Aplicar na Rom: Shalom (1987) (Konami) (J).rom
Sistema: MSX
Genero: RPG
Produtora: Konami
Ano de Lan�amento: 1987
N� de Jogadores: 1
Tradutor: Ricardo Bittencourt
Grupo: Mundo Bizarro
Lan�amento da Tradu��o: 27/05/2004
Site: http://www.700km.com.br/mundobizarro/
Vers�o: 1.2 Beta
Tradu��o: 99%

Antes de aplicar o IPS na sua rom fa�a uma c�pia da mesma