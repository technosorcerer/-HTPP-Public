Kageno Densetsu (MSX)
Traducción al Español v1.0 (16/12/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Kageno Densetsu (1986) (Taito) (J).rom
MD5: 8e59c543f38bf4ca3986e7117d68f87d
SHA1: ffc8c57b26f2f495bd77efac5b815efe9c25336c
CRC32: 69367e10
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --