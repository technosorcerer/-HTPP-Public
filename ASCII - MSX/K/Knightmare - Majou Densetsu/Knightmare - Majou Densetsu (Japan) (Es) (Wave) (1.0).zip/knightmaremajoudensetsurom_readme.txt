Knightmare - Majou Densetsu (MSX)
Traducción al Español v1.0 (24/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Knightmare - Majou Densetsu (Japan).rom
MD5: ebfcaba358d7ceca95c7385276321f78
SHA1: c8ff858d239c62a859f15c2f1bf44e1d657cec13
CRC32: 0db84205
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --