Oil's Well (MSX)
Traducción al Español v1.0 (31/12/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Oil's Well (Japan).rom
MD5: 9cb4a6ae96b0c98ae826b520ac268af6
SHA1: 5b53794d3d73df29cbcec411c0f65e9e9898977f
CRC32: 3c7f3767
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --