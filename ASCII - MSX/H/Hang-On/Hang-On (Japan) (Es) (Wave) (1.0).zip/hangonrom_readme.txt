Hang On (MSX)
Traducción al Español v1.0 (24/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Hang On (1985) (Pony Cannon) (J).rom
MD5: 8ed0c9f88fdc84b877451c1b528abae3
SHA1: 26fc48ddaca0fedc90fc151d4ecd5ca6d1ccc77b
CRC32: 48e7212c
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --