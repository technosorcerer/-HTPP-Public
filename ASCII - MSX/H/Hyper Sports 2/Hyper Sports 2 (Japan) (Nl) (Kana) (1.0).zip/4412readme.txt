Language patch (text only)
Language: Dutch
--------------------------

Vertaling naar het Nederlands
Versie: 1.0
Datum: 15-04-2019
(c) 2019 Kana Translations

--------------------------
Opmerkingen bij deze patch
--------------------------
Deze vertaling en hack is geheel oorspronkelijk.
Enkele letters van het alfabet waren niet beschikbaar
als tile, w.o.: J, Z.

--------------------------
Patch-instructies
--------------------------
De patch heeft de IPS-indeling, en kan worden gebruikt met LunarIPS of Floating IPS.

--------------------------
Spelinformatie
--------------------------
Gebruikt oorspronkelijk bronbestand:

Titel: Hyper Sports 2 (Japan).rom (No-Intro Romset)
Platform: MSX

MD5:   665E6C909788650BB0187A8D7DDDED80
SHA1:  9002AA0B2D49A9FC323180487FF591781867A99C
CRC32: 968FA8D6
Bytes: 16384

--------------------------
Dankwoord/Credits
--------------------------
Kana - Nederlandse vertaling en hack

--------------------------
Very special thanks
--------------------------
Wave - voor het briljante programma Hextractor, website:
traduccioneswave.blogspot.com

-- EINDE --