Hyper Sports 1 (MSX)
Traducción al Español v1.0 (12/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Hyper Sports 1 (1984) (Konami) (J).rom
MD5: b870891550234b6ada5d876f88c57b6f
SHA1: 2c85b993671de612e9338d094565a4eb32a97ea0
CRC32: 18db4ff2
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --