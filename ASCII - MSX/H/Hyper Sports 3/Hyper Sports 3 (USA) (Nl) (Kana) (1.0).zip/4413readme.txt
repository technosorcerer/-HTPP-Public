Language patch (text only)
Language: Dutch
--------------------------

Vertaling naar het Nederlands
Versie: 1.0
Datum: 15-04-2019
(c) 2019 Kana Translations

--------------------------
Opmerkingen bij deze patch
--------------------------
Deze vertaling en hack is geheel oorspronkelijk.

--------------------------
Patch-instructies
--------------------------
De patch heeft de IPS-indeling, en kan worden
gebruikt met LunarIPS of Floating IPS.

--------------------------
Spelinformatie
--------------------------
Gebruikt oorspronkelijk bronbestand:

Titel: Hyper Sports 3 (Japan).rom (No-Intro Romset)
Platform: MSX

MD5:   01A2C85070D987A1B83F591E83B5BCFE
SHA1:  AF4E0490C178A18A47B34831FB5E3CF8B61D34D9
CRC32: 9107BCC8
Bytes: 80A831E1

--------------------------
Dankwoord/Credits
--------------------------
Kana - Nederlandse vertaling en hack

--------------------------
Very special thanks
--------------------------
Wave - voor het briljante programma Hextractor,
website: traduccioneswave.blogspot.com

-- EINDE --