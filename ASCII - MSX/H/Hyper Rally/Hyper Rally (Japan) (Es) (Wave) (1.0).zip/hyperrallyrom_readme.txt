Hyper Rally (MSX)
Traducción al Español v1.0 (12/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Hyper Rally (1985) (Konami) (J).rom
MD5: d302ba993f34a093e64829a8c60a7993
SHA1: 7dfe091e02f6c1b21bd65e44eb5052d564d0ef92
CRC32: f94d452e
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --