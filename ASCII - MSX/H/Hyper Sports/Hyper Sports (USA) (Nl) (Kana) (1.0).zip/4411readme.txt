Language patch (text + one tile)
Language: Dutch
--------------------------

Vertaling naar het Nederlands
Versie: 1.0
Datum: 15-04-2019
(c) 2019 Kana Translations

--------------------------
Opmerkingen bij deze patch
--------------------------
Deze vertaling en hack is geheel oorspronkelijk.
Enkele letters van het alfabet waren niet beschikbaar
als tile, w.o.: J, Z.

--------------------------
Patch-instructies
--------------------------
De patch heeft de IPS-indeling, en kan worden gebruikt met LunarIPS of Floating IPS.

--------------------------
Spelinformatie
--------------------------
Gebruikt oorspronkelijk bronbestand:

Titel: Hyper Sports 1 (Japan).rom (No-Intro Romset)
Platform: MSX

MD5:   B870891550234B6ADA5D876F88C57B6F
SHA1:  	2C85B993671DE612E9338D094565A4EB32A97EA0
CRC32: 18DB4FF2
Bytes: 16384

--------------------------
Dankwoord/Credits
--------------------------
Kana - Nederlandse vertaling en hack

--------------------------
Very special thanks
--------------------------
Wave - voor het briljante programma Hextractor, website:
traduccioneswave.blogspot.com

-- EINDE --