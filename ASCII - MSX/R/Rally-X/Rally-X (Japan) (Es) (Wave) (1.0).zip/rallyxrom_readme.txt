Rally-X (MSX)
Traducción al Español v1.0 (19/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rally-X (1984) (Namcot) (J).rom
MD5: 3e5900c0f1b940095f82c16b3e7cfb00
SHA1: fc7212c6813574224114c3bb5bfa99206c0816a5
CRC32: 63413493
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --