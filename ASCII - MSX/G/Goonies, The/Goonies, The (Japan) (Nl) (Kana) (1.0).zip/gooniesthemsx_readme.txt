Language patch (text only)
Language: Dutch
--------------------------

Vertaling naar het Nederlands
Versie: 1.0
Datum: 26-04-2019
(c) 2019 Kana Translations

--------------------------
Opmerkingen bij deze patch
--------------------------
Deze vertaling en hack is geheel oorspronkelijk.

--------------------------
Patch-instructies
--------------------------
De patch heeft de IPS-indeling, en kan worden gebruikt met LunarIPS of Floating IPS.

--------------------------
Spelinformatie
--------------------------
Gebruikt oorspronkelijk bronbestand:

Titel: The Goonies (Japan).rom
Platform: MSX

MD5:   24A6D9CFA9E38E120678A538663E8AD2
SHA1:  B1248F7B9D4E16A894555C51C533D3FD9A90802E
CRC32: DB327847
Bytes: 32768

KEYWORD / KENWOORD
--------------------------
De sleutelwoorden voor de rondeselectie zijn ongewijzigd gebleven.
The level select keywords have not been changed.

Level Passwords

At the title screen, press CTRL + K to enter the password
screen and type the following keys:

Effect	Password
Stage 1	GOONIES
Stage 2	MR SLOTH
Stage 3	GOON DOCKS
Stage 4	DOUBLOON
Stage 5	ONE EYED WILLY


--------------------------
Dankwoord/Credits
--------------------------
Kana - Nederlandse vertaling en hack

--------------------------
Very special thanks
--------------------------
Wave - voor het briljante programma Hextractor, website:
traduccioneswave.blogspot.com

-- EINDE --