Guardic (MSX)
Traducci�n al Espa�ol v1.0 (31/05/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Guardic (1986) (Compile) (J).rom
MD5: 9e21b956d02cdf275baa501837aca094
SHA1: 67baaaa870ad4a08f55ec1c67dbeabc97b6f18a0
CRC32: 6aebb9d3
32768 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --