
Golvellius (MSX)
English Translation Patch

Version 1.0
Released on April 21, 2008

By Novalia Spirit
Contact information: novaliaspirit (AIM and Hotmail)
http://novaliaspirit.99k.org/


Table of contents:
1. Patching instructions
2. Frequently asked questions
3. Acknowledgements
4. Legal disclaimer


-------------------------------------------------------------------------------
 1. Patching instructions
-------------------------------------------------------------------------------

1. Get a copy of the ROM.
2. Extract the patch file from the archive.
3. With the help of a tool such as Lunar IPS, apply the patch to the ROM.

Note that the patch is not compatible with the MSX2 version of Golvellius, and
that it should be applied to a clean copy of the ROM. If you right-click (or
control-click on a Mac) the ROM and select the option to view its properties,
the listed size, calculated in bytes, should be 131072.


-------------------------------------------------------------------------------
 2. Frequently asked questions
-------------------------------------------------------------------------------

Q: I do not have access to an MSX computer. Are there viable alternatives?
A: Yes, emulators. Here are two of the most popular MSX emulators:
   1. blueMSX: www.bluemsx.com
   2. openMSX: http://openmsx.sourceforge.net

Q: Why are certain words or characters colored differently?
A: In the unmodified game, kana characters are blue, roman letters are yellow,
   and numbers are white. The translation simply preserves such variations.

Q: Why is the text written in capital letters?
A: This is due to the fact that the unmodified game only contains uppercase
   roman letters. It was my intention to preserve as many of the original
   elements as possible, hence my reticence to take liberties in that regard.
   It bears mentioning, however, that I have drawn a number of punctuation
   symbols that did not originally exist. The set of roman letters has also
   been duplicated to allow for a blue color.

Q: You alluded to a version for the MSX2. Can you elaborate?
A: Two remakes of Golvellius were created. The first was conceived for the Sega
   Master System, while the second was designed for the MSX2. The scenario and
   mechanics are sensibly the same in all three versions. However, the remakes
   feature enhanced graphics as well as distinctive locations and enemies.
   Hence, each version offers a vastly different experience.

Q: I played all three versions and still want more. Suggestions?
A: Compile released a parody titled Super Cooks that operates on a modified
   engine of Golvellius for the MSX2. The story essentially follows the
   adventures of Kelesis, now dressed as a cook, on a journey impeded by evil
   fruits and vegetables, which are to be defeated, notably, with the help of
   a frying pan...


-------------------------------------------------------------------------------
 3. Acknowledgements
-------------------------------------------------------------------------------

My most sincere thanks to BiFiMSX. Not only has he volunteered as a beta
tester, but he also provided code that allowed the dialogue from the epilogue
to be relocated, allowing space constraints to be overcome. On a personal
level, he made his mark with the interest and enthusiasm that he showed in the
project, which provided a powerful and constant source of motivation.

Vampier, for partially testing the patch, as well as for being a source of
motivation in the same manner as described above.

Yy, whose YY-CHR program was employed to locate and modify font characters.


-------------------------------------------------------------------------------
 4. Legal disclaimer
-------------------------------------------------------------------------------

The contents of this document cannot be reproduced without the written consent
of the author, unless for personal purposes. Permission to distribute the files
included in the archive is granted exclusively to romhacking.net and
ips.tni.nl.

� 2008 Jame Coban. All rights reserved.
