Language patch (text only)
Language: Dutch
--------------------------

Vertaling naar het Nederlands
Versie: 1.0
Datum: 14-04-2019
(c) 2019 Kana Translations

--------------------------
Opmerkingen bij deze patch
--------------------------
Deze vertaling en hack is geheel oorspronkelijk.
N.B. De Europese cartridge (dump) bevat nog enkele Japanse tekststrings,
deze zijn ongewijzigd gebleven.

--------------------------
Patch-instructies
--------------------------
De patch heeft de IPS-indeling, en kan worden gebruikt met LunarIPS of Floating IPS.

--------------------------
Spelinformatie
--------------------------
Gebruikt oorspronkelijk bronbestand:

Titel: Galaga (Japan).rom (No-Intro Romset)
Platform: MSX (MSX1)

MD5:   AD242A3199771CD5EE35EA5CDD5276B5
SHA1:  FAA5AEF23FEBC61A875E28EEBE3AADF83E1F5BA7
CRC32: 8856961D
Bytes: 32768

--------------------------
Dankwoord/Credits
--------------------------
Kana - Nederlandse vertaling en hack

--------------------------
Very special thanks
--------------------------
Wave - voor het briljante programma Hextractor, website:
traduccioneswave.blogspot.com

-- EINDE --