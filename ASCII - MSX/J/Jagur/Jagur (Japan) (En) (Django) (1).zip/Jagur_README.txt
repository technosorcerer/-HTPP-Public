JAGUR 5

Also known as:
Jagur, Jagur: Golden Triangle

Developed: Compile
Year: 1987
System: MSX1

This translation was done by renowned computer translator DJANGO, who mainly translates into French, but also English.

Unfortunately he releases his translations as full ROMs, meaning they never end up on Romhacking.net.

So I took Lunar IPS and made a simple IPS patch to be applied to an unpatched ROM ofr Jagur 5.

All credit should go to DJANGO (though frankly, he should really be releasing IPS patches to make things easier).

ABOUT THE GAME:
This is a col little adventure title, reminiscent of Metal Gear on MSX2 and Mercenary Force on Game Boy.

You start with one guy, collect your squad, get some gear, then roam around East Asia doing side-quests, killing bosses, and buying more gear.

It is fantastic. Unfortunately the language barrier makes things a bit tricky.

When you enter a house, push up again to commence dialogue with the person inside.

Included in this ZIP file is a PDF with instructions and a walkthrough,and an MCF file for cheats.

Just use Lunar IPS to patch it. I did and it worked easy.