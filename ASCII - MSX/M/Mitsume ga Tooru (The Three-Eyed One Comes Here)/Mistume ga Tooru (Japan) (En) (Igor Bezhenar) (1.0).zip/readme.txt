This patch is for the Japanese localization of NATSUME�s Mitsume ga Tooru for the MSX home computer. It translates the game to English and Russian. The context and meaning of the original Japanese is maintained, but grammar, spelling, and expressions are adapted to English and Russian speakers.

ROM Information:

Mitsume ga Tooru. The Three-Eyed One Comes Here (1989)(Natsume)(jp).rom
CRC32: 4F70C1F9
MD5: 223BD344FE8833C2EB385C256EB7029A
SHA-1: 7341EFC039394EC159FEEBCFAA9D4A61EBF08A18
SHA-256: 396357F4F7B4AD59B5ABBA22C88E60652265E378576B39D61B9EC58F0D479147

You can use online IPS Patcher from https://www.marcrobledo.com/RomPatcher.js/ or use any other IPS Patcher tools.