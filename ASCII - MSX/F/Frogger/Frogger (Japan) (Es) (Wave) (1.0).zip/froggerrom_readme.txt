Frogger (MSX)
Traducción al Español v1.0 (19/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Frogger (1983) (Konami) (J).rom
MD5: 4daf350513798227186c3454bb396114
SHA1: a194b845857c8b33ef4fd5e53d7f38150b4fa4cf
CRC32: 97e2fcb4
8192 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --