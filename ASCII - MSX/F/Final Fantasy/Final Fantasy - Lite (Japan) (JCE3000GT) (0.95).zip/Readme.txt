			Final Fantasy I Lite
			Released: February 20th 2014
			Update Last: February 22st 2014

	
Description:
This a lite or easy mod of Final Fantasy (MSX) starts your characters off with increased base stats to make the game a little easier.  This is a good port of Final Fantasy with upgraded graphics and music.  The only drawbacks are you have to deal with the MSX system which is a pain in the ass and the walking speed is slightly reduced and a little choppy.  Otherwise it is worth playing just to play another version of the first Final Fantasy.  

Whats been changed:
-All starting characters begin with 250 HP.
-All starting characters begin with 50 of the primary stats (left window on status menu) and slightly higher of the secondary stats (right window on status menu).  
-All Clinic and Inn visits are free.
-Edited two weapons (Small Knife and Wooden Staff) and 1 armor (Cloth Armor) to give the best attack/defense in the game and made them available in Cornelia to purchase.
-All healing-related items in the item shop are free, also includs the Bottle in the Caravan.  
-Added the Excalibur and Masamune to Cornelia's and Elfland's weapon shops respectively.  
-All spells cost 50 gold.
-Edited some of the early spells to give the effects of the later spells of the same name.  For example, Harm does Harm 4 damage.  
-Heal potion heals more in battle.


What's next:
-Add more magic points to magic users.
-Increase the starting gold of the party.
-Maybe more?


NOTE: You will need the right MSX disk image exactly 720KB (737,280 bytes) in size and is entitled: "Final Fantasy (1989)(Micro Cabin)(jp)(Disk 1 of 2)(Game Disk).dsk".  You will need to search google for the disk image of this game. Below is the original ROM/Disk file information to ensure you are patching the right file.  

Original ROM/Disk information:
CRC32:	E268F257
MD5:	636370BA2BBD18F94168D93D82988848
SHA-1:	88313A53A1301D030317D5D1B76C16FCF4AE1A21


TIP: I have added a guide on how to get this game loaded and working in the Blue MSX emulator if you are having trouble.  



2014 JCE3000GT
http://www.jce3000gt.com
jce3000gt@gmail.com