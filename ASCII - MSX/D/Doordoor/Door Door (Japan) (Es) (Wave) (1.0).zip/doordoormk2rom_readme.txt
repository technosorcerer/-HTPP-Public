Doordoor Mk2 (MSX)
Traducci�n al Espa�ol v1.0 (31/05/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Doordoor Mk2 (1984) (Enix) (J).rom
MD5: 50435ce4bb1373f57c903d85bc3c7986
SHA1: f8feeac4384bc4f109c70f962e15ce925bf70c13
CRC32: f8ad9717
16384 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --