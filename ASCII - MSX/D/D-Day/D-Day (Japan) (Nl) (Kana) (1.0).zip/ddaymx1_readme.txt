Language patch (text only)
Language: Dutch

--------------------------
D-Day (MSX)
--------------------------

Vertaling naar het Nederlands
Versie: 1.0
Datum: 22/06/2019
(c) 2019 Kana Translations

--------------------------
Opmerkingen bij deze patch
--------------------------
Deze vertaling en hack is geheel oorspronkelijk.

--------------------------
Patch-instructies
--------------------------
De patch heeft de IPS-indeling, en kan worden toegpast
met LunarIPS of Floating IPS.

--------------------------
Spelinformatie
--------------------------
Gebruikt oorspronkelijk bronbestand:

D-Day (Japan).mx1
MD5: f791fdd30dfd64019281ae53e4343bd4
SHA1: 18e87e15b09ec2fddc52fad10edc57918fadec34
CRC32: 5d284ea6
16384 bytes

--------------------------
Dankwoord/Credits
--------------------------
Kana - Nederlandse vertaling en hack

--------------------------
Very special thanks
--------------------------
Wave - voor het briljante programma Hextractor, website:
traduccioneswave.blogspot.com

-- EINDE --