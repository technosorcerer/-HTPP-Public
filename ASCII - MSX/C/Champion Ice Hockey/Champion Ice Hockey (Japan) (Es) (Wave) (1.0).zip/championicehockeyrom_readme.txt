Champion Ice Hockey (MSX)
Traducción al Español v1.0 (08/12/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Champion Ice Hockey (1986) (Pony Cannon) (J).rom
MD5: 9626a8b01a0d22173f9980b52e9771d4
SHA1: ebb46dd4cf36407ad82d9f50d9bef3e938dc144e
CRC32: bf4b018f
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --