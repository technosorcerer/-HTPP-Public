Language patch (text only)
Language: Dutch

--------------------------
Color Ball (MSX)
--------------------------

Vertaling naar het Nederlands
Versie: 1.0
Datum: 12/08/2019
(c) 2019 Kana Translations

--------------------------
Opmerkingen bij deze patch
--------------------------
Deze vertaling en hack is geheel oorspronkelijk.

--------------------------
Patch-instructies
--------------------------
De patch heeft de IPS-indeling, en kan worden toegpast
met LunarIPS of Floating IPS.

--------------------------
Spelinformatie
--------------------------
Gebruikt oorspronkelijk bronbestand:

Color Ball (Japan).mx1
MD5: 51d3e2426907224ab2244315cb05132c
SHA1: ac391fe51f69e0a55fe3ab66c8ec3f2792dd5d08
CRC32: 12552a1f
8192 bytes

--------------------------
Dankwoord/Credits
--------------------------
Kana - Nederlandse vertaling en hack

--------------------------
Very special thanks
--------------------------
Wave - voor het briljante programma Hextractor, website:
traduccioneswave.blogspot.com

-- EINDE --