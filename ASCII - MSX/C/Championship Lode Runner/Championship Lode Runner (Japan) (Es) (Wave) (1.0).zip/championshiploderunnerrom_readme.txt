Championship Lode Runner (MSX)
Traducción al Español v1.0 (16/12/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Championship Lode Runner (1985) (Sony) (J).rom
MD5: 4180cc41bf2efb3033c2e7ef867cc87e
SHA1: 650381b96f36e74a4eaf5ae3f924f6f8deac7100
CRC32: 2f75e79c
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --