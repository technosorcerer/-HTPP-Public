Language patch (text only)
Language: Dutch

--------------------------
Championship Lode Runner (MSX)
--------------------------

Vertaling naar het Nederlands
Versie: 1.0
Datum: 22/06/2019
(c) 2019 Kana Translations

--------------------------
Opmerkingen bij deze patch
--------------------------
Deze vertaling en hack is geheel oorspronkelijk.

--------------------------
Patch-instructies
--------------------------
De patch heeft de IPS-indeling, en kan worden toegpast
met LunarIPS of Floating IPS.

--------------------------
Spelinformatie
--------------------------
Gebruikt oorspronkelijk bronbestand:

Championship Lode Runner (Japan).mx1
MD5: 4180cc41bf2efb3033c2e7ef867cc87e
SHA1: 650381b96f36e74a4eaf5ae3f924f6f8deac7100
CRC32: 2f75e79c
32768 bytes

--------------------------
Dankwoord/Credits
--------------------------
Kana - Nederlandse vertaling en hack

--------------------------
Very special thanks
--------------------------
Wave - voor het briljante programma Hextractor, website:
traduccioneswave.blogspot.com

-- EINDE --