Choroq (MSX)
Traducci�n al Espa�ol v1.0 (31/05/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Choroq (1984) (Taito) (J).rom
MD5: fb48d5e9cdea7d080dbcf1702f533642
SHA1: 99f9e9753edbaee820e36a1a58f1cd7ae2b26265
CRC32: 5506bf9b
16384 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --