Cabbage Patch Kids (MSX)
Traducción al Español v1.0 (24/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Cabbage Patch Kids (1983) (Konami) (J).rom
MD5: a46dbb59535bf812574bd8cef354b491
SHA1: c06de0eda82e1daa3ea3cbc5eba5d884fd0ce8e8
CRC32: 057d2790
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --