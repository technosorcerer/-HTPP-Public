Choplifter (MSX)
Traducci�n al Espa�ol v1.0 (31/05/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Choplifter (1985) (Sony) (J).rom
MD5: 27121600b9c989885fae3dcece2cf07a
SHA1: a2a7c93c9c8b55a5cce4c9005f3c194e3b762e9c
CRC32: 1f5eafc8
32768 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --