Crusader (MSX)
Traducción al Español v1.0 (02/08/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Crusader (Japan).rom
MD5: 3f6ca4ab412a7c5e8ca9ded41c7ecf91
SHA1: d0e8bc3f5fd93dcd07cbb945b00018a491842242
CRC32: 0b69dd50
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --