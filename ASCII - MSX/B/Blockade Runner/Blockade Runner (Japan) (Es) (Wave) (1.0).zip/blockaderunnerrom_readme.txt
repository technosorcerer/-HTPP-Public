Blockade Runner (MSX)
Traducción al Español v1.0 (12/12/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Blockade Runner (1984) (Toshiba Emi) (J).rom
MD5: fa3f66390a2ed8d3e4db6d75de81b91d
SHA1: bd4b8c48f1d8107f11ae680a787d7b3825669b7c
CRC32: 8334b431
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --