Language patch (text only)
Language: Dutch

--------------------------
Blockade Runner (MSX)
--------------------------

Vertaling naar het Nederlands
Versie: 1.0
Datum: 22/06/2019
(c) 2019 Kana Translations

--------------------------
Opmerkingen bij deze patch
--------------------------
Deze vertaling en hack is geheel oorspronkelijk.

--------------------------
Patch-instructies
--------------------------
De patch heeft de IPS-indeling, en kan worden toegpast
met LunarIPS of Floating IPS.

--------------------------
Spelinformatie
--------------------------
Gebruikt oorspronkelijk bronbestand:

Blockade Runner (Japan).mx1
MD5: fa3f66390a2ed8d3e4db6d75de81b91d
SHA1: bd4b8c48f1d8107f11ae680a787d7b3825669b7c
CRC32: 8334b431
16384 bytes

--------------------------
Dankwoord/Credits
--------------------------
Kana - Nederlandse vertaling en hack

--------------------------
Very special thanks
--------------------------
Wave - voor het briljante programma Hextractor, website:
traduccioneswave.blogspot.com

-- EINDE --