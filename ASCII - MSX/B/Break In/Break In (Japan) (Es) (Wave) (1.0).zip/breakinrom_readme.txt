Break In (MSX)
Traducción al Español v1.0 (08/12/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Break In (1987) (Jaleco) (J).rom
MD5: eab747201237ef95c210148a3888a0b1
SHA1: bcfdb43b275c62a76856aab94fb1b53bd92b2db2
CRC32: 8801b31e
65536 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --