Language patch (text only)
Language: Dutch

--------------------------
Boggy '84 (MSX)
--------------------------

Vertaling naar het Nederlands
Versie: 1.0
Datum: 08/08/2019
(c) 2019 Kana Translations

--------------------------
Opmerkingen bij deze patch
--------------------------
Deze vertaling en hack is geheel oorspronkelijk.

--------------------------
Patch-instructies
--------------------------
De patch heeft de IPS-indeling, en kan worden toegpast
met LunarIPS of Floating IPS.

--------------------------
Spelinformatie
--------------------------
Gebruikt oorspronkelijk bronbestand:

Boggy '84 (Japan).mx1
MD5: ed3620892fb8a70154732ffac6f0b1ef
SHA1: 5c96169207e197237aa728d8ce4e24c0635d5904
CRC32: ec089246
8192 bytes

--------------------------
Dankwoord/Credits
--------------------------
Kana - Nederlandse vertaling en hack

--------------------------
Very special thanks
--------------------------
Wave - voor het briljante programma Hextractor, website:
traduccioneswave.blogspot.com

-- EINDE --