Language patch (text only)
Language: Dutch

--------------------------
Balance (MSX)
--------------------------

Vertaling naar het Nederlands
Versie: 1.0
Datum: 08/08/2019
(c) 2019 Kana Translations

--------------------------
Opmerkingen bij deze patch
--------------------------
Deze vertaling en hack is geheel oorspronkelijk.

--------------------------
Patch-instructies
--------------------------
De patch heeft de IPS-indeling, en kan worden toegpast
met LunarIPS of Floating IPS.

--------------------------
Spelinformatie
--------------------------
Gebruikt oorspronkelijk bronbestand:

Balance (Japan).mx1
MD5: 9c3c4f7c76ce97efb8b755c0b1dac233
SHA1: cd452442338366411f6b24739fe59e20f3ac24dc
CRC32: cdabd75b
8192 bytes

--------------------------
Dankwoord/Credits
--------------------------
Kana - Nederlandse vertaling en hack

--------------------------
Very special thanks
--------------------------
Wave - voor het briljante programma Hextractor, website:
traduccioneswave.blogspot.com

-- EINDE --