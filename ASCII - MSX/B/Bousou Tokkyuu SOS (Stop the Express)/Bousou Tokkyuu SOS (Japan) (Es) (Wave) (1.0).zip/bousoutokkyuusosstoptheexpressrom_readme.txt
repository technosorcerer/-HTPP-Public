Bousou Tokkyuu SOS (MSX)
Traducción al Español v1.0 (24/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bousou Tokkyuu SOS. Stop the Express (1985)(Hudson Soft).rom
MD5: b5e6d3f1fb1b3c01415dd71d05104d78
SHA1: f2d1a057940b44c04ba08f4ff2767eef8b515833
CRC32: 334efc07
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --