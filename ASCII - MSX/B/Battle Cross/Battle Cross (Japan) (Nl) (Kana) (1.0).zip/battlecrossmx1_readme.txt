Language patch (text only)
Language: Dutch

--------------------------
Battle Cross (MSX)
--------------------------

Vertaling naar het Nederlands
Versie: 1.0
Datum: 11/08/2019
(c) 2019 Kana Translations

--------------------------
Opmerkingen bij deze patch
--------------------------
Deze vertaling en hack is geheel oorspronkelijk.

--------------------------
Patch-instructies
--------------------------
De patch heeft de IPS-indeling, en kan worden toegpast
met LunarIPS of Floating IPS.

--------------------------
Spelinformatie
--------------------------
Gebruikt oorspronkelijk bronbestand:

Battle Cross (Japan).mx1
MD5: 916ad37b0ef7dc3a01f5ec52936a52b8
SHA1: 8b63f36be31d7d021c19103ebe8c68b69aae699c
CRC32: 25e675ea
16384 bytes

--------------------------
Dankwoord/Credits
--------------------------
Kana - Nederlandse vertaling en hack

--------------------------
Very special thanks
--------------------------
Wave - voor het briljante programma Hextractor, website:
traduccioneswave.blogspot.com

-- EINDE --