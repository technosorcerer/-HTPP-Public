Butamaru Pants (MSX)
Traducción al Español v1.0 (08/12/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Butamaru Pants (1983) (Hal) (J).rom
MD5: 5591580e9b0fccd4efc351ef6ffb4db3
SHA1: b755d7db109cd0a9392accd1c83e6d995a8a04d6
CRC32: 4b2aa972
8192 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --