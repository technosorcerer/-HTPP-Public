Yazzie (MSX)
Traducción al Español v1.0 (27/07/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Yazzie.rom
MD5: e7c6ad8bfb41983651c84fcc0409d6d6
SHA1: f6e6b0690f06470e521d975d03145ec858589c9d
CRC32: d659d039
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --