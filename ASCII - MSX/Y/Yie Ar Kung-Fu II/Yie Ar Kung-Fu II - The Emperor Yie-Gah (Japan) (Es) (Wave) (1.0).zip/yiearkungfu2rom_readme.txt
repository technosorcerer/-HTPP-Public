Yie Ar Kung-Fu 2 (MSX)
Traducci�n al Espa�ol v1.0 (30/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Yie Ar Kung-Fu 2 (1985) (Konami) (J).rom
MD5: b591bb62cec12fcc13f54885cf3c7df6
SHA1: 57827f8d49369e4dbf20a968e535374d35ff1648
CRC32: d66034a9
32.768 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --