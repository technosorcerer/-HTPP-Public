Yie Ar Kung-Fu (MSX)
Traducci�n al Espa�ol v1.0 (30/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Yie Ar Kung-Fu 1 (1985) (Konami) (J).rom
MD5: 983a3d5031cda4c9701eee524566eba5
SHA1: a3090a15c95334da3e0f94030eadee02b5032c0c
CRC32: 8a12ec4f
16.384 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --