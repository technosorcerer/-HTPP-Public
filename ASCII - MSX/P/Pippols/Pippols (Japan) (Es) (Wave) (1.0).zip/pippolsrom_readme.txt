Pippols (MSX)
Traducción al Español v1.0 (19/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pippols (1985) (Konami) (J).rom
MD5: f4afc761cda302c78f20f81c1922aa36
SHA1: 10e63eba7d2b10d946822f21e7fd106f5dfab632
CRC32: be6a5e19
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --