Pac-Man (MSX)
Traducción al Español v1.0 (12/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pac-Man (1984) (Namcot) (J).rom
MD5: 01078dd71f4e70e95bc3acdf605c19da
SHA1: 61695eb1dc6242d8a70c7ef2172cf86a26e3c2dd
CRC32: d74dffa2
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --