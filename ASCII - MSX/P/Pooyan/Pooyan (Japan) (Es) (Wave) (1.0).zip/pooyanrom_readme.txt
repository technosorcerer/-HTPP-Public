Pooyan (MSX)
Traducción al Español v1.0 (12/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pooyan (1985) (Hudson) (J).rom
MD5: f38f3aa7da1635cb8a6397304bd3a0eb
SHA1: 692a55393e8eef0800a612c01456e9cecd9c1418
CRC32: 558a09f6
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --