Parodius (MSX)
Traducción al Español v1.0 (14/09/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en la traducción de A&L Soft.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Parodius (Japan).rom
MD5: 790972d4e53fcbc2ee46317a583fb52e
SHA1: 2220363ae56ef707ab2471fcdb36f4816ad1d32c
CRC32: 9bb308f5
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --