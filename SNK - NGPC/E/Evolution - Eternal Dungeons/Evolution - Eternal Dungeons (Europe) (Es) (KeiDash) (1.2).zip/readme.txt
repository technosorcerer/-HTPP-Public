Evolution: Eternal Dungeons (NEOP-0090)
Spanish Translation v1.2

___Applying the Patch___

The patch is in IPS format, you can use any patcher for your operative system, for example WinIPS for Windows. 
The patch file was generated using WinIPS. 

___Acknowledgements___

Hacking:                KeiDash
Main Translation:       KeiDash
Script Editing:         KeiDash

A special thank you to all Neo Geo Pocket fans. You can gget more information aboout us in www.neogeopocket.es,
a special site for this console.