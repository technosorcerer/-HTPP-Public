Cotton - fantastic Night Dream (NEOP-0105)
Spanish Translation v1.0

___Applying the Patch___

The patch is in IPS format, you can use any patcher for your operative system, for example WinIPS for Windows. 
The patch file was generated using WinIPS. 

___Acknowledgements___

Hacking:                Ele91
Main Translation:       Ele91
Script Editing:         Ele91

A special thank you to all Neo Geo Pocket fans. You can get more information aboout us in www.neogeopocket.es,
a site dedicated for this handle console.