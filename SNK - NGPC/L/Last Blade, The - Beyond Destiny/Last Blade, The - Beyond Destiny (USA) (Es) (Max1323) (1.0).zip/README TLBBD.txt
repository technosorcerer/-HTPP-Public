"The Last Blade: Beyond the Destiny"
Traducción al Español Ver. 1.0 (04/10/2024)
por Max1323 (Traducciones Max1323).
---------------------------------------------------
Descripción:
The Last Blade Beyond the Destiny empieza con los eventos
del primer Last Blade, contando con los 10 personajes de la misma.
El juego cuenta también con los eventos de Last Blade 2, para ello
es necesario comprar los finales de cada personaje en la Galería.

Desarrollado: Saurus
Publicado:    SNK
Lanzamiento:  16/03/2000 (JAP)
	      XX/XX/2000 (EUR)
---------------------------------------------------
Acerca del proyecto:
-La mayoría de los textos están traducidos. Se agregaron
los caracteres españoles.
-Solo se tradujo una mínima cantidad de gráficos.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS (PC)
Utilizar UniPatcher (Android)
Utilizar Rom Patcher (Parcheador Online):
https://romhackplaza.org/patch/

Archivo IPS
Last Blade, The (UE) [!].ngc
File Size     2.00 MB
File MD5      19C6DDAB908704735F0EA465C9705A68        
File SHA-1    166AC59DFBFA9EB7DDAFEFBFAA5000E01E9F5286
File CRC32    F4637EC0