Rockman - Battle & Fighters (Neo Geo Pocket Color)
Traducción al Español v1.0 (22/02/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en el de CF y marc_max.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rockman - Battle & Fighters (Japan).ngc
MD5: 1ca3a6b4e23c51bdab70182c3406e73d
SHA1: 7aabe4ce0a81c959625f1a9e254c144893f0e16a
CRC32: 3c010642
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --