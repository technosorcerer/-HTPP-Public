Rockman Battle & Fighters NGP Translation Patch v0.9 by marc_max
================================================================

This is a very simple translation of Rockman Battle & Fighters for Neo Geo Pocket Color.
I didn't make use of pointers, just felt lazy.

Basically, all texts (except database descriptions) are translated. This includes:
* option menu
* erase data menu
* pause menu
* database trade menu
* Dr. Light's enemy descriptions in PF
* endings and other cutscenes

What's missing:
* main menu graphics
* database descriptions

Some notes:
* endings and cutscenes texts were adapted from the arcade versions
* main menu wasn't translated, but since all other texts are translated, you'll always know where you are
* the game's font was replaced by a new one (borrowed from here: http://forums.nesdev.com/viewtopic.php?f=2&t=10284#p115257)
  and 26 lowercase letters were added, overwriting some kanjis



Apply it to:
* Rockman - Battle & Fighters (Japan).ngc (no-intro)
* CRC32: 9C861E49





I include the table just in case anyone wants to translate the database.
Also, a complete 100% savegame is included too.


-- marc_max 2018