NigeRonpa English translation v0.9

Coding : 
 - Lo�c
 
Translation :
 - JinRawX from REDDIT forum
 - Lo�c

Additionnal informations :

- All ingame text are changed, except link-up menu, and names in the ending credits.
- The translation still need to be improved, and the character bio are replaced by generic text.
- The name input menu should be rewritten to give a better result.
- Building upgrade menu fixed. In original game, the upgrade price was deduced before upgrade confirmation.

Any comments are welcome.

You can reach me on reddit/Nigeronpa