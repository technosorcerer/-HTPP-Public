"Gal's Fighters"
Traducci�n al Espa�ol Ver. 1.2 (28/04/2022)
por Max1323 (maxmuruchi@gmail.com)
---------------------------------------------------
Descripci�n:
"Q.O.F". 
Una pelea de ensue�o que permite la participaci�n de las mejores luchadoras. 
Para la ganadora, se le te otorgar� el "Talism�n K" que le concedera cualquier deseo.
Cada una con sus motivos impuls�ndolas, las mujeres se preparan para participar en la batalla.

Desarrollado: Yumekobo
Publicado:    SNK
Lanzamiento: 27/01/2000 (JAP)
             19/02/2000 (USA)
             XX/XX/2000 (EUR)                           
---------------------------------------------------
Acerca del proyecto:
-Se tradujo los textos y solo se a�adio la �.
-Se tradujeron algunos gr�ficos y algunos textos faltantes.
-Se a�adieron los acentos.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS
Gals Fighters (UE) [!].ngc
File Size     2.00 MB
File MD5      08922D2BDC6C80D56DDF50836CCAD77C        
File SHA-1    09A74B42EF9B63ACA675AEAD5854512AD0B585A1
File CRC32    B02C2BE7