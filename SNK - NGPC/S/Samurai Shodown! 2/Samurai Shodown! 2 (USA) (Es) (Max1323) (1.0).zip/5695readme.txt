"Samurai Shodown! 2 Pocket Fighting Series"
Traducción al Español Ver. 1.0 (20/09/2020)
por Max1323 (maxmuruchi@gmail.com)
---------------------------------------------------
Descripción:
En una tierra desconocida, una perturbación inquietante
perturba el cielo, llevando una masa oscura a la tierra.
Es la reencarnación del mal, Yuga el Destructor.
El objetivo de este ser es unificar este mundo y el inframundo,
utilizando al hombre y mujer hermafroditas para la construcción
de su utopía para convertirse en el fundamento de la resurrección
del Dios Oscuro.

Desarrollado: Saurus 
Publicado:    SNK
Lanzamiento:  30/04/1999 (USA)
	      XX/XX/2000 (EUR)
	      10/06/1999 (JAP)	
---------------------------------------------------
Acerca del proyecto:
Se tradujo los textos pero no los textos gráficos ya
que son bastantes complejos para modificarlos.
Agradezco a David por el testeo del juego.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS

Samurai Shodown! 2 (JUE) [!].ngc
File Size   2.00 MB
File MD5    8D6A36ACD3B171970D87D2FCA6796A4A        
File SHA-1  2EC4DA369D3B91AF15DEFA64429BD9DAAC7EE9B5
File CRC32  4F7FB156
