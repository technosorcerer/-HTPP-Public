"Samurai Shodown! Pocket Fighting Series"
Traducci�n al Espa�ol Ver. 1.0 (12/05/2020)
por Max1323 (maxmuruchi@gmail.com)
---------------------------------------------------
Descripci�n:
Haohmaru,Nakoruru,Genjuro y una gran cantidad de los favoritos de SNK llegan a la port�til de NeoGeo Pocket. Levanta tu espada
para cortar los planes de Shiro Amakusa.

Desarrollado:Saurus
Publicado:   SNK 
Lanzamiento: 25/12/1998 (JAP)
             XX/XX/1998 (EUR)                           
---------------------------------------------------
Acerca del proyecto:
Se tradujo los textos se agregraron los caracteres espa�oles y acentuaciones. Tambi�n se tradujo algunos gr�ficos.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS

Samurai Shodown! (JUE) [M][!].ngp
File Size     2.00 MB
File MD5        D13F954B2F1C703BDF857837C24E332E                 File SHA-1      2C6ADFA69E7AEADA7D4198B373436EEE35B70D01         File CRC32      32E4696A                                                                           
