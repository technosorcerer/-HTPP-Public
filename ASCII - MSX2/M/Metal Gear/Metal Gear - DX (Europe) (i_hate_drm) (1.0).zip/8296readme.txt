DOCUMENTATION

MAME Debugger:
mame nms8280 mgear -debug
[Press Scroll-Lock to enable/disable MAME menus (this was Fn+C for my laptop)]

	Set Breakpoint at instruction 1234 when memory ABCD equals EF:
	bpset 1234, maincpu.pb@abcd==ef

Z80 Assembly:
https://clrhome.org/table/

Metal Gear Maps:
https://www.vgmaps.com/Atlas/MSX/index.htm#M

Metal Gear Scripts:
https://www.geocities.ws/nekurahoka/

Metal Gear Disassembly:
https://github.com/GuillianSeed/MetalGear



CHANGES:

01. Can use keyboard Q-W-E-R for menus, and F for punch.
    Q = Quit (Pause), W = Weapons, E = Equipment, R = Radio, F = Fight (Punch).
02. Don't have to press F5 to continue.
03. Can swap between menus.
04. Rations/Ammo fill up completely.
05. Don't have to select keycard to open doors.
06. Keycards group together in inventory.
07. Game auto-saves when you EXIT the elevator.
08. Can open menus in elevators.
09. All dialogue is skippable.
10. Can use ration in equipment menu with punch button.

11. Bosses flash red when damaged.
11a. Fixed one wrong tile on Hind-D. Changed color of nearby crates.

12. Big Boss calls to explain how to get Schneider's frequency.
12a. Auto-dial disabled after calls to make this process seamless.
13. Schneider calls for bombable walls in the basement.
14. Jennifer calls at 4-Star Rank for Locked Door / Rocket Launcher.
14a. Jennifer's calls count as "listened to" even if you skip her text.

15. Removed bombable wall in basement leading to Enemy Uniform.

16. Oxygen Tank is in Compass room. Compass is in room next to Coward Duck.
16a. Oxygen Tank renamed from "BOMBE" to "SCUBA". Ration in Oxygen Tank room.
16b. Radio messages about location of Oxygen Tank / Compass disabled.

17. Total Explosives unaffected by rank. Maximum capacity is always 20.
18. Explosives/Ammo added to Metal Gear fight to prevent possible soft-lock.
19. Electric Grid outside Coward Duck altered to prevent possible soft-lock.
20. Door below Shootgunner changed to Card 1 Lock to prevent possible soft-lock.
21. Ration added to Building 2 Roof to prevent possible soft-lock.
22. Ration added to Building 2 Basement to prevent possible soft-lock.
23. Ration added to Grey Fox Cell to prevent possible soft-lock.

24. Sentinel guards have a minimum wait-time before turning (still randomised).
25. Modified guard positions/paths to prevent immediate alerts.




FUTURE: 
-Space Skip Text (Might Shoot Prisoners)
-Mines Slowdown



European version is nearly identical to Japanese version except:
- no region-lock
- no textbox when collecting items
- 33 radio messages removed (including an incoming call in the first room with cameras)
- two prisoner messages removed (use parachute, seek basement elevator).

https://tcrf.net/Metal_Gear_(MSX2)#Regional_Differences



FREE SPACE:

PAL VERSION = 1182 bytes: 		JPN VERSION = 95 bytes:
7FAF - 7FFF (81 bytes)
DFCC - DFFF (52 bytes)			DFDB-DFFF (37 bytes)
13FE6 - 13FFF (26 bytes)		13FE6-13FFF (26 bytes)
19C3C - 19FFF (964 bytes)		19FE0-19FFF (32 bytes)
1FFA7 - 1FFFF (89 bytes)



USED SPACE:

Keyboard = 13 bytes at 7FF3
	 = 61 bytes at 19FC0	// bankswap (called every cycle)
MenuSwap = 44 bytes at 7FB0
Keycards = 18 bytes at 7FE0
AutoCall = 24 bytes at 19F80	// bankswap (called once after msg)
JenCalls = 26 bytes at 19FA0
MGrItems = 09 bytes at DFCC
GroupKey = 29 bytes at 19F60	// bankswap (called once when pickup item)
	 = 19 bytes at DFE0
Sentinel = 10 bytes at DFD6
BossHurt = 44 bytes at 19E90	// bankswap (called once on new screen)
	  146 bytes at 19EC0	// bankswap (called every cycle - timer)



Keyboard Bits: 	FBDA-FBDF: 7654 3210   /   ;][/ =-98  /  BA~- .,\-   /   JIHG FEDC   /   RQPO NMLK   /   ZYXW VUTS

		FBE0-FBE2: F3_F2_F1_Pgdn  Caps_Pgup_Lctrl_Lshft   /   Entr_End_Bck_Rctrl  Tab_Esc_F5_F4   /   →↓↑←  Del_Ins_Home_Space

		FBE3-FBE4: [NUMPAD] 4321 0/+*   /   [NUMPAD] .Entr-9 8765


STABILITY FIX:

Radio code is close to breaking. Too many instructions per cycle.
It should be reaching instruction $4246 every cycle and waiting for the system interrupt.
But sometimes the system interrupt occurs before the cycle is finished - such as in Room 24.
The below code skips the loading of Snake/Enemy Sprites when in menus.

2F47:						NEW CODE:
 6F47  ld   a,($C151)	3A 51 C1						// C151 = GameMode (0=Playing,1=NextRoom,2=Weapons,3=Equip,4=Radio,etc.)
 6F4A  cp   $02		FE 02		|	6F4A  sub  $02		D6 02
 6F4C  jr   z,$6F55	28 07		|	6F4C  cp   $03		FE 03
 | 6F4E  cp   $03	FE 03		|	6F4E  jr   c,$6F71 o-|	38 21	// If GameMode is 2/3/4, jump to UpdateControls
 | 6F50  jr   z,$6F55	28 03		|	6F50  nop nop	     |	00 00
 | | 6F52  call $8FD0	CD D0 8F	// DrawCallAndCountdownText  |
 6F55  call $53AB	CD AB 53	// LoadSnakeSprites	     |
 6F58  call $5318	CD 18 53	// ""			     |
 6F5B  call $535E	CD 5E 53	// ""			     |
 6F5E  call $65FB	CD FB 65	// ""			     |
 6F61  call $8176	CD 76 81	// ""			     |
 6F64  ld   a,($C130)	3A 30 C1				     |
 6F67  cp   $F0		FE F0					     |
 6F69  jr   nc,$6F71	30 06					     |
 | 6F6B  call $7458	CD 58 74	// LoadEnemySprites	     |
 | 6F6E  call $5599	CD 99 55	// ""			     |
 6F71  call $7CAA	CD AA 7C	// UpdateControls <----------|
 6F74  ld   a,($C151)	3A 51 C1
 6F77  call $41EA	CD EA 41	// JumpIndex

D6 02 FE 03 38 21 00 00


KEYBOARD CODE (F = Punch):

3CD8:
 7CD8  ld   a,$04	3E 04
 7CDA  call $0141	CD 41 01	|	7CDA  call $BFF3	CD F3 BF	// Call below code instead

7FF3:
 BFF3  call $0141	CD 41 01	// A = RQPO NMLK
 BFF6  ld   e,a		5F		// E = RQPO NMLK
 BFF7  ld   a,$03	3E 03
 BFF9  call $0141	CD 41 01	// A = JIHG FEDC
 BFFC  or   $F7		F6 F7		// A = ---- F---
 BFFE  and  e		A3		// A = RQPO (NF)MLK
 BFFF  ret		C9

CD 41 01 5F 3E 03 CD 41 01 F6 F7 A3 C9


KEYBOARD CODE (QWER = Pause/Weapon/Equip/Radio):

3D06:
 7D06  ld   a,$06	3E 06		|	7D06  di		F3		// disable interrupts
 7D08  call $0141	CD 41 01	|	7D07  ld   hl,$A000	21 00 A0
 7D0B  cpl		2F		|	7D0A  ld   (hl),$0C	36 0C		// change A000-BFFF bank to 0C
 7D0C  rlca		07		|	7D0C  call $BFC0	CD C0 BF
 7D0D  rlca		07		|	7D0F  ld   (hl),$03	36 03		// change A000-BFFF bank to 03
 7D0E  rlca		07		|	7D11  ei		FB		// enable interrupts
 7D0F  and  $07		E6 07		|	
 7D11  ld   e,a		5F		|	// F3 21 00 A0 36 0C CD C0 BF 36 03 FB

19FC0:
 BFC0  ld   a,$06	3E 06
 BFC2  call $0141	CD 41 01	// A = F3_F2_F1_Pgdn  Caps_Pgup_Lctrl_Lshft
 BFC5  cpl		2F
 BFC6  rlca		07
 BFC7  rlca		07
 BFC8  rlca		07
 BFC9  and  $07		E6 07		// A = 0000 0_F3_F2_F1
 BFCB  ld   e,a		5F		// E = 0000 0_F3_F2_F1

 BFCC  ld   a,$04	3E 04
 BFCE  call $0141	CD 41 01	// A = RQPO NMLK
 BFD1  bit  6,a		CB 77		// CHECK Q (F1)
 BFD3  jr   nz,$BFD7	20 02
 | BFD5  set  0,e	CB C3		// 0000 000Q
 BFD7  rlca		07		// CHECK R (F4)
 BFD8  jr   c,$BFE2	38 08
 | BFDA  ld   a,($C008)	3A 08 C0	// check if game paused
 | BFDD  rrca		0F
 | BFDE  jr   c,$BFE2	38 02		// if game paused, ignore R press
 | | BFE0  set  3,e	CB DB		// 0000 R00Q
 BFE2  ld   a,$05	3E 05
 BFE4  call $0141	CD 41 01	// A = ZYXW VUTS
 BFE7  bit  4,a		CB 67		// CHECK W (F2)
 BFE9  jr   nz,$BFED	20 02
 | BFEB  set  1,e	CB CB		// 0000 R0WQ
 BFED  ld   a,$03	3E 03
 BFEF  call $0141	CD 41 01	// A = JIHG FEDC
 BFF2  bit  2,a		CB 57		// CHECK E (F3)
 BFF4  jr   nz,$BFF8	20 02
 | BFF6  set  2,e	CB D3		// 0000 REWQ
 BFF8  ret		C9

3E 06 CD 41 01 2F 07 07 07 E6 07 5F
3E 04 CD 41 01 CB 77 20 02 CB C3 07 38 08 3A 08 C0 0F 38 02 CB DB
3E 05 CD 41 01 CB 67 20 02 CB CB 3E 03 CD 41 01 CB 57 20 02 CB D3 C9



AUTOMATIC CONTINUE:

27F4:
 67F4  ld   a,($C113)	3A 13 C1   |				// A = FKeysHold
 67F7  bit  4,a		CB 67	   |				// Was F5 Pressed?
 67F9  ret  z		C8	   |	67F9  nop	00	// Ignore
 67FA  ld   hl,$92A0	21 A0 92


               G  A  M  E        O  V  E  R
5292  FF 58 58 47 41 4D 45 00 00 4F 56 45 52 
529F  FE 						|	529F  FF		// END TEXT HERE
52A0  50 70 43 4F 4E 54 49 4E 55 45 00 00 46 35 FF
            C  O  N  T  I  N  U  E        F  5



SWITCH MENUS:

2F47:
 6F47  ld   a,($C151)	3A 51 C1	|	6F47  call $BFB0	CD B0 BF
 6F4A  cp   $02		FE 02		|	
 6F4C  jr   z,$6F55	28 07		|	
 6F4E  cp   $03		FE 03		|	
 6F50  jr   z,$6F55	28 03		|	

7FB0:
 BFB0  ld   a,($C151)		3A 51 C1	// (C151) = Game Mode (0=Playing,1=NextRoom,2=Weapons,3=Equipment,4=Radio,5=Truck,etc.)
 BFB3  push af			F5
 BFB4  ld   c,$02		0E 02
 BFB6  sub  c			91
 BFB7  cp   $03			FE 03
 BFB9  jr   nc,$BFDA		30 1F		// If Game Mode is not 2/3/4, exit
 | BFBB  ld   a,($C112)		3A 12 C1	// (C112) = F1-F8 Key Press
 | BFBE  rra			1F
 | BFBF  rra			1F
 | BFC0  jr   c,$BFCC		38 0A		// If Bit1 set (F2), C=2
 | | BFC2  inc  c		0C
 | | BFC3  rra			1F
 | | BFC4  jr   c,$BFCC		38 06		// If Bit2 set (F3), C=3
 | | | BFC6  inc  c		0C
 | | | BFC7  rra		1F
 | | | BFC8  jr   c,$BFCC	38 02		// If Bit3 set (F4), C=4
 | | | | BFCA  pop  af		F1
 | | | | BFCB  ret		C9		// If nothing pressed (or F1/F5/Enter), exit
 | BFCC  pop  af		F1
 | BFCD  push af		F5
 | BFCE  cp   c			B9
 | BFCF  jr   z,$BFDA		28 09		// If F-Key pressed matches the already open Game Menu, exit
 | | BFD1  ld   a,($C0F2)	3A F2 C0
 | | BFD4  ld   ($C0F1),a	32 F1 C0	// (C0F1) = (C0F2)	RestoreMusicFlag = SavedMusicFlag	// If music saved, set for restore
 | | BFD7  call $70F6		CD F6 70	// (C151) = C	(2/3/4 = F2/F3/F4 = Weapons/Eqipment/Radio)	// Function saves/restores music
 BFDA  pop  af			F1
 BFDB  ret			C9

3A 51 C1 F5 0E 02 91 FE 03 30 1F 
3A 12 C1 1F 1F 38 0A 0C 1F 38 06 0C 1F 38 02 F1 C9
F1 F5 B9 28 09 3A F2 C0 32 F1 C0 CD F6 70 F1 C9



FILL AMMO / RATIONS:

4F27:
 8F27  add  a,(hl)	86		|	8F27  and  a		A7
 8F28  daa		27		|	8F28  jr   z,$8F2E	28 04	// If A = 0, skip (e.g. when first pickup new gun)
 8F29  ld   (hl),a	77		|	| 8F2A  inc  hl		23	// Go to hundreds byte
 8F2A  jr   nc,$8F2E	30 02		|	| 8F2B  inc  (hl)	34
 8F2C  | inc  hl	23		|	| 8F2C  inc  (hl)	34
 8F2D  V inc  (hl)	34		|	V 8F2D  inc  (hl)	34	// Adds 300 to total
 8F2E  ld   a,$01	3E 01

A7 28 04 23 34 34 34



KEYCARDS:

394F:
 794F  ld   a,($C135)	3A 35 C1	|	794F  call $BFE0	CD E0 BF
 7952  cp   d		BA		|	
 7953  jp   nz,$7A77	C2 77 7A	|

7FE0:
 BFE0  ld   a,($C13B)	3A 3B C1	// Check EquipmentRemoved Flag
 BFE3  dec  a		3D
 BFE4  ret  z		C8		// A = 0
 BFE5  push hl		E5
 BFE6  ld   h,$C5	26 C5
 BFE8  ld   a,$9F	3E 9F
 BFEA  add  a,d		82		// d = KeyCardRequired (0E to 15)
 BFEB  ld   l,a		6F
 BFEC  ld   a,(hl)	7E		// Check if card taken ($C5AD to $C5B4)
 BFED  pop  hl		E1
 BFEE  and  a		A7
 BFEF  ret  z		C8		// A = 0
 BFF0  ld   a,d		7A		// If player has card, A = KeyCardRequired
 BFF1  ret		C9

3A 3B C1 3D C8
E5 26 C5 3E 9F 82 6F 7E E1 A7 C8 7A C9



GROUP KEYCARDS:

Unlock all equipment slots:

7BB:
 47BB  ld   hl,$C530	21 30 C5
 47BE  ld   b,$19	06 19		|	47BE  ld   b,$1B	06 1B	(Add two extra item slots)

82B:
 482B  cp   $11		FE 11		|	482B  cp   $13		FE 13	(total icons in second and third column + 1)
 482D  ld   de,$6828	11 28 68
 4830  jr   z,$4838	28 06
 4832  cp   $08		FE 08		|	4832  cp   $0A		FE 0A	(total icons in third column + 1)

	Explanation: Without the above, the two extra item slots would go into the first column.

5234:
 9234  ld   de,$C530	11 30 C5	|
 9237  ld   b,$18	06 18		|	9237  ld   b,$11	06 11	// Separates third column and allows blank spots between cards

	Explanation: There is code that groups all icons together - preventing any blank spots in inventory.
	We only want that code to check the first two columns.


Fix Cursor:

Note: There was no space for extra cursor positions, so had to code it...

3DB:
 43DB  ld   ($C155),de	ED 53 55 C1	|	43DB  call $BFE0, nop		CD E0 BF 00
 43DF  jr   $43A0	18 BF

DFE0:
 BFE0  cp   $1A		FE 1A
 BFE2  jr   nz,$BFE7	20 03
 | BFE4  ld   de,$B09C	11 9C B0	// Cursor second-last slot
 BFE7  cp   $1B		FE 1B
 BFE9  jr   nz,$BFEE	20 03
 | BFEB  ld   de,$B0AC	11 AC B0	// Cursor bottom-right slot
 BFEE  ld   ($C155),de	ED 53 55 C1
 BFF2  ret		C9

FE 1A 20 03 11 9C B0 FE 1B 20 03 11 AC B0
ED 53 55 C1 C9

3F16:
 7F16  ld   a,($C154)	3A 54 C1
 7F19  cp   $11		FE 11		|	7F19  cp   $13		FE 13
 7F1B  ret  nc		D0
 7F1C  add  a,$09	C6 09		// CURSOR RIGHT

3F3A:
 7F3A  cp   $19		FE 19		|	7F3A  cp   $1B		FE 1B
 7F3C  ret  z		C8
 7F3D  inc  a		3C		// CURSOR DOWN


Keycards Go To Third Column:

4DE8:
 8DE8  ld   (hl),c	71		|	8DE8  di		F3		// disable interrupts
 8DE9  ld   a,c		79		|	8DE9  ld   a,$0C	3E 0C
 8DEA  cp   $08		FE 08		|	8DEB  ld   ($A000),a	32 00 A0	// change A000-BFFF bank
 8DEC  jr   nz,$8DF7	20 09		|	8DEE  call $BF60	CD 60 BF
 8DEE  ld   a,$10	3E 10		|	8DF1  ld   a,$03	3E 03
 8DF0  ld   ($C160),a	32 60 C1	|	8DF3  ld   ($A000),a	32 00 A0	// change A000-BFFF bank
 8DF3  xor  a		AF		|	8DF6  ei		FB		// enable interrupts
 8DF4  ld   ($C15F),a	32 5F C1	|	
 8DF7  call $8F1F	CD 1F 8F	

F3 3E 0C 32 00 A0 CD 60 BF 3E 03 32 00 A0 FB

19F60:
 BF60  ld   a,c		79
 BF61  cp   $0E		FE 0E
 BF63  jr   c,$BF6E	38 09
 | BF65  cp   $16	FE 16
 | BF67  jr   nc,$BF6E	30 05	// If picked up item is keycard (0E to 15)
 | | BF69  rlca		07
 | | BF6A  rlca		07	// Times 4
 | | BF6B  add  a,$40	C6 40	// Place in allocated spot: C578 to C594
 | | BF6D  ld   l,a	6F

 BF6E  ld   (hl),c	71
 BF6F  cp   $08		FE 08
 BF71  jr   nz,$BF7C	20 09
 | BF73  ld   a,$10	3E 10
 | BF75  ld   ($C160),a	32 60 C1
 | BF78  xor  a		AF
 | BF79  ld   ($C15F),a	32 5F C1
 BF7C  ret		C9

79 FE 0E 38 09 FE 15 30 05 07 07 C6 40 6F
71 FE 08 20 09 3E 10 32 60 C1 AF 32 5F C1 C9


Keycards from "HIRAKE GOMA" Cheat Code Go To Third Column:

DFAD:
 BFAD  ld   hl,$C530	21 30 C5	|	BFAD  ld   hl,$C578	21 78 C5	// Start checking for free spots at C578
 BFB0  ld   a,(hl)	7E
 BFB1  and  a		A7
 BFB2  jr   z,$BFBB	28 07





ELEVATOR AUTO-SAVES:

DE64:
     BE64  79 79  79 00  F0 03  F0 1F  F2 27  F1 0F  F1 1B  F2 35	|	79 79  79 00  03 F0  1F F0  27 F2  0F F1  1B F1  35 F2
     BE74  F1 3F  F3 48  F5 CE  F3 5F  F5 CF  F4 58  F6 9A  F3 51	|	3F F1  48 F3  CE F5  5F F3  CF F5  58 F4  9A F6  51 F3
     BE84  F5 CD  F7 6D  FA 73  A5 08  0A CC  40 0B  49 45  7D 5D	|	CD F5  6D F7  73 FA
     BE94  38 7B  66 4B  6C 68  69 4E  6E 6B  76 74  7B 38		

[Room, PrevRoom] - swapped these around for elevators (F0-FA)



ELEVATOR MENUS:

2F9B:
 6F9B  ld   a,($C130)	3A 30 C1
 6F9E  cp   $E0		FE E0
 6FA0  jr   nc,$6FCB	30 29		|	nop, nop	00 00		// PAUSE IN ELEVATORS / LADDERS

30F0:
 70F0  ld   a,($C130)	3A 30 C1
 70F3  cp   $F0		FE F0
 70F5  ret  nc		D0		|	nop		00		// MENU IN ELEVATORS (NEED ABOVE)



NO UNSKIPPABLE TEXT:

1D99:
 5D99  ld   a,($CEE0)	3A E0 CE	// SkipTextMode (00 = skippable, 01 = unskippable (can skip after msg typed), 02 = unskippable (wait for next msg)
 5D9C  dec  a		3D
 5D9D  jr   z,$5DB2	28 13		|	5D9D  nop nop	00 00
 5D9F  dec  a		3D
 5DA0  jr   z,$5DB2	28 10		|	5DA0  nop nop	00 00

SkipTextMode 1 is used by Big Boss / Fire Trooper
SkipTextMode 2 is used by Other Bosses / Fake Madnar / Elevator Guards / Sleepy Guards / Capture Guards / Desert Guards / Ellen "Help Me"

1E6B:
 5E6B  ld   a,($CEE0)	3A E0 CE	|	5E6B  ld   a,($C006)	3A 06 C0	// ControlsTrigger
 5E6E  cp   $02		FE 02		|	5E6E  and  $20		E6 20
 5E70  jr   z,$5E9A	28 28		|	5E70  jp   nz,$5E9F	C2 9F 5E
 5E72  ld   a,($C006)	3A 06 C0	|	5E73  ld   a,($C112)	3A 12 C1	// FKeysTrigger
 5E75  and  $20		E6 20		|	5E76  and  $20		E6 20
 5E77  jr   nz,$5E9F	20 26		|	5E78  jp   nz,$5E9F	C2 9F 5E
 5E79  ld   a,($C112)	3A 12 C1	|	5E7B  ld   a,($CEE0)	3A E0 CE	// SkipTextMode
 5E7C  and  $20		E6 20		|	5E7E  cp   $02		FE 02
 5E7E  jp   nz,$5E9F	C2 9F 5E	|	5E80  jp   z,$5E9A	CA 9A 5E
 5E81  ld   a,($CEE0)	3A E0 CE	|	5E83  nop		00
 5E84  dec  a		3D

// Reordered the above so that it checks for input even if SkipTextMode = 02 (unskippable, wait for next msg)

3A 06 C0 E6 20 C2 9F 5E 3A 12 C1 E6 20 C2 9F 5E 3A E0 CE FE 02 CA 9A 5E 00



CAN USE RATION/ANTIDOTE WITH PUNCH BUTTON:

3EF1:
 7EF1  ld   a,($C006)	3A 06 C0
 7EF4  bit  4,a		CB 67		|	7EF4  and  $30		E6 30
 7EF6  jp   nz,$7F76	C2 76 7F	|	7EF6  jp   nz,$7F76	C2 76 7F
 7EF9  and  $0F		E6 0F		|	7EF9  ld   hl,$C15C	21 5C C1
 7EFB  jr   nz,$7F08	20 0B		|	7EFC  ld   a,($C006)	3A 06 C0
 | 7EFD  ld   a,($C007)	3A 07 C0	|	7EFF  and  $0F		E6 0F
 | 7F00  and  $0F	E6 0F		|	7F01  jr   nz,$7F0B	20 08
 | 7F02  ret  z		C8		|	| 7F03  ld   a,($C007)	3A 07 C0
 | 7F03  ld   hl,$C15C	21 5C C1	|	| 7F06  and  $0F	E6 0F
 | 7F06  dec  (hl)	35		|	| 7F08  ret  z		C8
 | 7F07  ret  nz	C0		|	| 7F09  dec  (hl)	35
 7F08  ld   hl,$C15C	21 5C C1	|	| 7F0A  ret  nz		C0
 7F0B  ld   (hl),$08	36 08
 7F0D  rra		1F

E6 30 C2 76 7F 21 5C C1 3A 06 C0 E6 0F 20 08 3A 07 C0 E6 0F C8 35 C0



GETTING SCHNEIDER'S FREQUENCY:

	If you call Big Boss in Room 1E (below first camera room), he says: "THERE MUST BE SOME RESISTANCE. TRY TO CONTACT WITH THE TRANSCEIVER!"
	Cycle through the radio channels in this room (or Room 01, 1F, 21) and Schneider will pick up.

	There are patrolling guards on this screen (1E), so it's not really ideal for an incoming call.
	Big Boss already has a message to give in the screen above (camera room) and to the left (ammo room).
	But there are no radio messages in the first prisoner room - so let's have him call there.

	BIG BOSS CALLS (PRISONER ROOM 94):
	18298 change from 01 to 08 for incoming call.
	1F7EE: C5 B6		|	6B B6			// Use same room calls as Room 1E
	1F66B: 14 14 21 17	|	18 14 21 17		// Set freq / auto-dial Big Boss

DISABLE AUTO-DIAL AFTER CALL

29CC:
 69CC  xor  a		AF		|	69CC  di		F3		// disable interrupts
 69CD  ld   ($C806),a	32 06 C8	|	69CD  ld   a,$0C	3E 0C
 69D0  ld   ($C801),a	32 01 C8	|	69CF  ld   ($A000),a	32 00 A0	// change A000-BFFF bank
 69D3  inc  a		3C		|	69D2  call $BF80	CD 80 BF
 69D4  ld   ($C805),a	32 05 C8	|	69D5  ld   a,$03	3E 03
 69D7  ld   hl,$C153	21 53 C1	|	69D7  ld   ($A000),a	32 00 A0	// change A000-BFFF bank back
 69DA  ld   (hl),a	77		|	69DA  ei		FB		// enable interrupts
 69DB  ld   a,($C922)	3A 22 C9
 69DE  and  a		A7
 69DF  ld   a,$50	3E 50
 69E1  call z,$427C	CC 7C 42

F3 3E 0C 32 00 A0 CD 80 BF 3E 03 32 00 A0 FB

19F80:
 BF80  ld   a,$01		3E 01
 BF82  ld   hl,($C803)		2A 03 C8
 BF85  inc  hl			23
 BF86  inc  hl			23
 BF87  ld   (hl),a		77		// Auto-reply on message set to 1 (off) after call

 BF88  xor  a			AF
 BF89  ld   ($C806),a		32 06 C8
 BF8C  ld   ($C801),a		32 01 C8
 BF8F  inc  a			3C
 BF90  ld   ($C805),a		32 05 C8
 BF93  ld   hl,$C153		21 53 C1
 BF96  ld   (hl),a		77
 BF97  ret			C9

3E 01 2A 03 C8 23 23 77
AF 32 06 C8 32 01 C8 3C 32 05 C8 21 53 C1 77 C9


SCHNEIDER BASEMENT CALLS (ROOM 3A): 

1823E change from 10 to 18 for incoming call
1F681 change from 25 to 29 (sets freq and auto-dials)

JENNIFER 4-STAR CALLS (ROOM 56/57):

5C9:
 45C9  ld   a,(hl)	7E		|	45C9  call $BFA0	CD A0 BF
 45CA  and  $08		E6 08		|	
 45CC  ld   c,$02	0E 02
 45CE  jr   z,$45D7	28 07

19FA0:
 BFA0  ld   a,($C130)	3A 30 C1
 BFA3  or   $01		F6 01		// Add 1 to RoomNum if even number (56->57)
 BFA5  cp   $57		FE 57
 BFA7  jr   nz,$BFB6	20 0D		// Jump if not in Room 56/57
 | BFA9  ld   a,$02	3E 02
 | BFAB  ld   ($C882),a	32 82 C8	// Set auto-dial
 | BFAE  ld   a,$48	3E 48
 | BFB0  ld   ($C138),a	32 38 C1	// Set freq to 48 (Jen)
 | BFB3  and  $08	E6 08		// A = 8 (incoming call) (zero flag cleared)
 | BFB5  ret		C9
 BFB6  ld   a,(hl)	7E
 BFB7  and  $08		E6 08
 BFB9  ret		C9

3A 30 C1 F6 01 FE 57 20 0D
3E 02 32 82 C8 3E 48 32 38 C1 E6 08 C9 7E E6 08 C9


The below code prevented Jennifer from delivering the rocket / opening the door, if the player skipped her text.
You could still just close the radio to skip it, so it seems pointless and potentially confusing on replays. Removed the check.

1F19:
 5F19  ld   a,($CEE3)		3A E3 CE	// CEE3 = SkipTextFlag		|
 5F1C  and  a			A7						|
 5F1D  ret  nz			C0		// If SkipText, exit		|	5F1D  nop			00
 5F1E  ld   hl,$C661		21 61 C6	// C661 = JenniferRocketFlag	|
 5F21  ld   a,($CEF0)		3A F0 CE	// CEF0 = TextId		|
 5F24  cp   $75			FE 75
 5F26  jr   z,$5F35		28 0D
 | 5F28  ld   hl,$C663		21 63 C6	// C663 = JenniferOpenDoorFlag
 | 5F2B  cp   $76		FE 76
 | 5F2D  jr   z,$5F35		28 06
 | | 5F2F  ld   hl,$C662	21 62 C6	// C662 = SchneiderCapturedFlag
 | | 5F32  cp   $8A		FE 8A
 | | 5F34  ret  nz		C0
 5F35  ld   (hl),$01		36 01
 5F37  ret			C9




REMOVE BASEMENT WALL LEADING TO ENEMY UNIFORM (ROOM 3B)

1F055 change from 30 to 80




OXYGEN TANK IN COMPASS ROOM (B8):

DB38 change from 13 (Compass) to 12 (Oxygen Tank)

RENAME "BOMBE" (OXYGEN TANK) TO "SCUBA":
	D95C  42 4F 4D 42 45 FF		|	D95C  53 43 55 42 41 FF
	      B  O  M  B  E			      S  C  U  B  A


COMPASS IN ROOM NEXT TO COWARD DUCK (C0):

DB5D change from 23 (Ammo) to 13 (Compass) and position on table (20 48):
	DB5D  23 18 68 23 50 40 FF	|	DB5D  13 20 48 23 50 40 FF

DISABLE COMPASS MESSAGE:

	Msg 7A:		THIS IS MR.SCHNEIDER...
			THE COMPASS CAN BE
			FOUND ON THE 2ND FLOOR.
			...OVER

	1F68B  45 7A	|	1F68B  05 7A
	1F699  44 7A	|	1F699  04 7A
	1F69D  45 7A	|	1F69D  05 7A
	1F6C3  45 7A	|	1F6C3  05 7A

	// Alternatively, could change the message to: "THE COMPASS IS AT THE END OF THE STREAM."


RATION IN OXYGEN TANK ROOM (C8):

DB64 change from 12 (Oxygen Tank) to 1E (Ration)

CHANGE OXYGEN TANK MESSAGE:

1F6AA change from 87 to 86 (Jennifer's Call outside Oxygen Tank Room - i.e. Room 73)

Msg 87:				Msg 86:

THIS IS JENNIFER...		THIS IS JENNIFER...
THERE IS AN OXYGEN		YOU SHOULD BREAK DOWN
CYLINDER BEYOND			THE WALL.
THE WALL.			...OVER
...OVER




WEAPON MAX RANKS:	0518A	50 00 	50 00 	15 00 	05 00 	05 00 	05 00 	05 00 	05 00
			0519A	00 01 	00 01 	30 00 	10 00 	10 00 	10 00 	10 00 	10 00
			051AA	00 02 	00 02 	60 00 	20 00 	15 00 	15 00 	15 00 	15 00
			051BA	00 03 	00 03 	90 00 	30 00 	20 00 	20 00 	20 00 	20 00
			051CA	99 09 	99 09 	99 09 	99 09 	99 09 	99 09 	99 09 	99 09
				HandG	SMG	GrenL	RockL	Bombs	Mines	Missl	?


			Set 5192,51A2,51B2 = 20	// Plastic Explosives max capacity will always be 20


METAL GEAR ROOM (ROOM 76) - ADD AMMO / EXPLOSIVES:

DBE9:
 BBE9  ld   a,($C130)	3A 30 C1	|	BBE9  call $BFCC	CD CC BF

DFCC:
 BFCC  ld   a,($C130)	3A 30 C1
 BFCF  cp   $76		FE 76		// If Room = 76
 BFD1  ret  nz		C0
 BFD2  ld   a,$9B	3E 9B		// Then A = 9B (Unused Room)
 BFD4  ret		C9

3A 30 C1 FE 76 C0 3E 9B C9


DA10  00									|	2C	// Unused Index (2C) for Unused Room (9B)

DAA6  7B BB    7F BB    83 BB    87 BB 						|	7B BB    82 BB    86 BB    8A BB	// Update Index for below

DB7B  23 50 18 FF    1E 40 48 FF    07 20 48 FF    23 50 60 23 70 A8 FF		|	23 39 19 05 38 D8 FF    1E 40 48 FF    07 20 48 FF    23 70 A8 FF

      ^ Unused Item Layout (2C)                    ^ Layout for Room C4/D8 (2F)		^ New Item Layout for Metal Gear Room                 ^ Removed 1
        23=Ammo, Y=50, X=18			     Has TWO ammo boxes                   23=Ammo 05=Bombs                                      Ammo Box



ADJUST ELECTRIC GRID LAYOUT OUTSIDE COWARD DUCK:

													     __ __
    1B760  25 24 25 11 14 19 07 14  08 09 0A 9F 14 19 07 14	|	25 24 25 11 14 19 07 14  08 09 0A 9F 1C 1D 07 14
    1B770  17 1F 1F 1B 1C 1D 07 14  19 07 A9 A9 1A 1B A9 14	|	17 1F 1F 1B 1A 1B 07 14  AA A9 A9 A9 A9 A9 A9 C7
										    ^^ ^^	 ^^ ^^       ^^ ^^    ^^
Electric Grids (19, 07, 1A, 1B, 14) replaced with regular flooring (AA, A9, and the newly made C7).
Center Pillar pushed back as I didn't have two spare metatiles for its shadow.

Found a duplicate metatile (Range: 1C2C0 - 1D2BF), and used it for the bottom-right corner (C7).
The duplicate was at 1CF10/1CF20 (C6/C7), and each tile was only used once (Room 0F/1F). 
Kept C6 - as it pairs well with C5. Replacing C7 below.

DUPLICATE METATILE (C6/C7):
    1CF10  60 60 60 60 60 60 60 60 60 60 60 60 21 17 60 60	|	
    1CF20  60 60 60 60 60 60 60 60 60 60 60 60 21 17 60 60	|	42 42 4C 1C 42 42 4D 1C 42 42 4C 1C 42 42 4D 1C

WHERE IT WAS USED (ROOM 0F):									       __
    1A570  07 07 07 07 07 12 77 16  0D 0D C7 07 07 10 20 21	|	07 07 07 07 07 12 77 16  0D 0D C6 07 07 10 20 21	// CHANGE C7 to C6



CARD1 DOOR BELOW SHOOTGUNNER (39) - Set 1F08F from 03 to 02
Added Ration to Building2 Roof Cell (BA) - Set DA2F to 23
Added Ration to Building2 Basement Cell (CB) - Set DA40 to 23	// Alternatively, could make it a spare gas mask (set to 05)
Added Ration to Building1 Basement Grey Fox Cell (A4) - Set DA19 to 23



SENTINEL GUARDS TURNING:

1B38:
 5B38  ld   a,r		ED 5F			// R = Memory Refresh Register (increments every instruction - Range: 00-7F)
 5B3A  ld   (ix+$5d),a	DD 77 5D	|	5B3A  call $BFD6	CD D6 BF
 5B3D  jp   $4248	C3 48 42	|	

DFD6:
 BFD6  cp   $10		FE 10
 BFD8  jr   nc,$BFDC	30 02
 | BFDA  add  a,$10	C6 10		// Add 10 cycles to wait if A < 10
 BFDC  ld   (ix+$5d),a	DD 77 5D
 BFDF  ret		C9

FE 10 30 02 C6 10 DD 77 5D C9



REMOVING IMMEDIATE ALERTS:

Guard Positions 		B07E - B55F	(907E, 4E2 bytes)
Guard Paths			BEA1 - C1CE	(9EA1, 32E bytes)
Guard Path Pointers		C1CF - C2DE	(A1CF, 110 bytes)
Guard Path Pointer to Pointer	C2DF - C444	(A2DF, 166 bytes)

Room 0B (11) - BUILDING 1, GROUND, TOP-CENTER (EXIT TO DESERT):
    C1E3:  C5 A1    C5 A1    B1 A1    B1 A1				|	C5 A1    C5 A1    B7 A1    B7 A1			// Path Pointers
	// A1C5 = (2, 0, 3) = (L, U, R)						// A1B7 = (3, 1, 2) = (R, D, L)
	// A1B1 = (2, 1) = (L, D)

Room 0D (13) - BUILDING 1, GROUND, MID-RIGHT (OUTSIDE SMG ROOM):

    B0F5:  02    04 70 58    04 60 88					|	02    04 A8 98    04 38 88				// Pos

    BF15:  03 B0 58 80 58 20 58    06 20 88 70 88 70 A8 B0 A8		|	03 A8 58 80 58 20 58    06 70 88 70 A8 B0 A8 70 A8	// Paths
    BF25:  70 A8 70 88							|	70 88 20 88

Room 0E (14) - BUILDING 1, GROUND, MID-RIGHT (CAMERA ROOM):
    B0FC:  03    06 98 40    06 50 C0    06 B8 A0			|	03    06 98 40    06 50 C0    06 98 A0			// Pos (Cams)

Room 1E (30) - BUILDING 1, LVL 2, MID-LEFT (BELOW CAMERA ROOM):
    B171:  02    1E 90 C8    1E B0 38					|	02    1E AB C8    1E B0 38    				// Pos

    BFCE:  04 AB C8 AB 68 AB C8 30 C8    04 B0 68 58 68 58 38		|	04 AB 78 AB C8 30 C8 AB C8    04 B0 68 58 68 58 38	// Paths
    BFDE:  B0 38							|	B0 38

// Not technically an immediate alert - there is a chance that the guard will look up when he reaches the bottom of the screen.
// The player might not have a box yet, and so the only way to guarantee avoiding detection would be to run down and punch the guard.
// Also moved the guard's path back a little to avoid sprite overlapping with the other guard.

Room 26 (38) - BUILDING 1, LVL 2, MID-RIGHT (ABOVE ELECTRIC GRID ROOM):
    B1A9:  02    04 50 38    1E 88 40					|	02    04 90 C8    1E 88 40				// Pos

    C055:  04 10 38 50 38 90 38 B8 38    04 88 C8 10 C8 88 C8		|	04 90 38 10 38 90 38 90 C8   04 88 C8 10 C8 88 C8	// Paths
    C065:  88 68 							|	88 68

Room 27 (39) - BUILDING 1, LVL 2, TOP-RIGHT (OUTSIDE ELEVATOR):
    C24D:  AE A1    B1 A1    AE A1    B1 A1				|	C0 A1    C0 A1    C0 A1    C0 A1			// Path Pointers
	// (3, 1), (2, 1), (3, 1), (2, 1)					// (3, 1, 2, 1)
	// (R, D), (L, D), (R, D), (L, D)					// (R, D, L, D)

	// NOTE: Only two guards are on-screen.
	// The second two are used if player came from elevator.

Room 2B (43) - BUILDING 1, ROOF, TOP-LEFT:
    B1C1:  02    05 90 18    04 28 E8 					|	02    05 90 68    04 28 98				// Pos

    C070:  04 90 68 38 68 38 18 90 18   04 28 98 88 98 88 E8 		|	04 38 68 38 18 90 18 90 68    04 88 98 88 E8 28 E8	// Paths
    C080:  28 E8							|	28 98

Room 46 (70) - BUILDING 2, GROUND, BOTTOM-LEFT (LEFT OF ENTRANCE):
    B28A:  02    04 45 50    04 2B A0 					|	02    04 45 50    04 45 C0				// Pos

    C0D6:  02 45 18 45 50    02 2B 90 2B F0				|	02 45 18 45 50    02 45 90 45 F0			// Paths

Room 4A (74) - BUILDING 2, GROUND, CENTER (OUTSIDE ANTENNA ROOM):
    B295:  03    04 28 C0    04 60 30    04 AB 90			|	03    04 28 C0    04 60 30    04 A8 90			// Pos

    C0E0:  02 28 90 28 F0    02 48 30 90 30    02 AB 30 AB 90		|	02 28 90 28 F0    02 90 30 48 30    02 A8 30 A8 90	// Paths
										// I moved Guard 3 higher (A8) so you don't have to 
										// punch him or take damage to get past him undetected.

Room 4D (77) - BUILDING 2, GROUND, MID-RIGHT (WATER ROOM):
    B2A3:  03    30 28 28    04 88 D8    04 AB C0			|	03    30 28 28    04 88 D8    04 A8 90			// Pos

    C0EF:  02 50 D8 B0 D8    02 AB 60 AB C0				|	02 B0 D8 50 D8    02 A8 C0 A8 60			// Paths (Guard 2/3)
										// I moved Guard 3 higher (A8) so you don't have to 
										// punch him or take damage to get past him undetected.

    C27D:  C0 A1    EF A0    F4 A0					|	B7 A1    EF A0    F4 A0					// Path Pointers
	// A1C0 = (3, 1, 2, 1) = (R, D, L, D)					// A1B7 = (3, 1, 2) = (R, D, L)

Room 4F (79) - BUILDING 2, LVL 1, BOTTOM-LEFT (OUTSIDE AMMO ROOM):
    B2AD:  04    1E 30 40    1E AB 20    1E 48 90    04 70 E0		|	04    1E 30 40    1E A8 20    1E 48 90    04 48 E0	// Pos

    C0F9:  04 40 40 80 40 80 20 40 20    02 AB 60 AB 20    03 60	|	04 40 40 80 40 80 20 40 20    02 A8 60 A8 20    03 60	// Paths
    C109:  90 38 90 18 90    03 10 E0 1C E0 70 E0 			|	90 38 90 18 90    03 70 E0 10 E0 1C E0

Room 50 (80) - BUILDING 2, LVL 1, MID-LEFT (GUARDING DOCTOR):
    B2BA:  03    30 70 30    30 30 88    30 58 98 			|	03    30 70 30    30 30 88    30 54 78			// Pos

    C28B:  B7 A1    B7 A1    B7 A1					|	C0 A1    C0 A1    C0 A1					// Path Pointers
	// A1B7 = (3, 1, 2) = (R, D, L)						// A1C0 = (3, 1, 2, 1) = (R, D, L, D)

Room 51 (81) - BUILDING 2, LVL 1, TOP-LEFT (OUTSIDE ELEVATOR):
    B2C4:  04    04 80 1C    04 30 20    04 2B E0    04 B0 E0		|	04    04 98 1C    04 30 50    04 2B A0    04 98 DC	// Pos

    C115:  02 B0 1C 80 1C    04 30 50 30 20 70 20 30 20    04 2B	|	02 80 1C B0 1C 	  04 30 20 70 20 30 20 30 50    04 2B	// Paths
    C125:  A0 2B E0 60 E0 2B E0    03 78 E0 90 E0 B0 E0 		|	E0 60 E0 2B E0 2B A0    03 78 DC 90 DC B0 DC

Room 52 (82) - BUILDING 2, LVL 1, BOTTOM-CENTER (BELOW ARNOLD ROOM):
    C299:  C5 A1    C0 A1    B4 A1    C5 A1 				|	C0 A1    C0 A1    C5 A1    C5 A1 			// Path Pointers
	// A1C5 = (2, 0, 3) = (L, U, R)						// A1C0 = (3, 1, 2, 1) = (R, D, L, D)
	// A1B4 = (2, 0) = (L, U)						// A1C5 = (2, 0, 3) = (L, U, R)

Room 54 (84) - BUILDING 2, LVL 1, TOP-CENTER (ABOVE ARNOLD ROOM):
    B2E5:  04    1E 2A 40    1E 70 30    05 30 E0    05 70 A0		|	04    1E 2A 40    1E 90 30    05 30 E0    05 70 A0	// Pos

    C133:  04 2A 60 2A 40 2A 20 2A 40    03 B0 30 90 30 70 30		|	04 2A 20 2A 40 2A 60 2A 40    03 70 30 B0 30 90 30	// Paths
    C143:  02 30 90 30 E0    04 70 88 70 9A 70 D0 70 9A 		|	02 30 90 30 E0    04 70 88 70 9A 70 D0 70 9A

Room 56 (86) - BUILDING 2, LVL 1, MID-RIGHT (OUTSIDE R.LAUNCHER ROOM):
    B2F6:  03    30 68 D0    04 40 30    04 AB 58 			|	03    30 68 D4    04 40 34    04 A8 58			// Pos	

    C15C:  02 60 30 28 30    02 AB B0 AB 58 				|	02 60 34 28 34    02 A8 B0 A8 58			// Paths (Guard 2/3)

Room 57 (87) - BUILDING 2, LVL 1, TOP-RIGHT (OUTSIDE COMPASS ROOM):
    C2B1:  C5 A1    B1 A1    B4 A1 					|	B7 A1    C0 A1    B7 A1					// Path Pointers
	// (2, 0, 3), (2, 1), (2, 0)						// (3, 1, 2), (3, 1, 2, 1), (3, 1, 2)
	// (L, U, R), (L, D), (L, U)						// (R, D, L), (R, D, L, D), (R, D, L)

Room 6B (107) - BUILDING 3, GROUND, END OF WATER PASSAGE:
    B3D4:  04    04 40 30    04 50 D0    04 B0 30    04 B0 D0		|	04    04 30 30    04 30 D0    04 78 30    04 70 D0	// Pos	

    C166:  04 17 30 17 60 17 30 40 30    04 25 D0 25 A0 25 D0		|	04 40 30 17 30 17 60 17 30    04 50 D0 25 D0 25 A0	// Paths
    C176:  50 D0    02 78 30 B0 30    02 70 D0 B0 D0			|	25 D0    02 B0 30 78 30    02 B0 D0 70 D0

Room B5 (181) - BUILDING 2, LVL 1, AMMO ROOM:
    B4D4:  02    0A 66 88    0A 32 BC					|	00    0A 66 88    0A 32 BC			// Pos (Guards removed)

Room B7 (183) - BUILDING 2, LVL 1, ANTIDOTE ROOM:
    B4DF:  02    0B 72 50    0B 54 A1 					|	00    0B 72 50    0B 54 A1			// Pos (Guards removed)



BOSS HURT COLOR CHANGE:

// EnemyHurt Code
4D28:
 8D28  ld   a,(iy+$0d)	FD 7E 0D	|	8D28  ld   a,$80	3E 80
 8D2B  sub  c		91		|	8D2A  call $8C36	CD 36 8C	// Call Below Code with A=80
 8D2C  jr   nc,$8D2F	30 01		|	8D2D  nop		00
 | 8D2E  xor  a		AF		|	8D2E  nop		00
 8D2F  ld   (iy+$0d),a	FD 77 0D	|	8D2F  nop nop nop	00 00 00
// No Damage Code
 8D32  ld   a,(ix+$00)	DD 7E 00		3E 80 CD 36 8C 00 00 00 00 00
 8D35  cp   $03		FE 03			
 8D37  jp   c,$821F	DA 1F 82
 8D3A  ret		C9

// ChkPlayerShots Code
4C33:
 8C33  ld   a,($C142)	3A 42 C1							// C142 = WeaponInUse
 8C36  and  a		A7		|	8C36  push af		F5
 8C37  ret  z		C8		|	8C37  di		F3		// disable interrupts
 8C38  ld   hl,$8951	21 51 89	|	8C38  ld   hl,$A000	21 00 A0
 8C3B  cp   $03		FE 03		|	8C3B  ld   (hl),$0C	36 0C		// change A000-BFFF bank to 0C
 8C3D  jr   c,$8C4A	38 0B		|	8C3D  call $BEC0	CD C0 BE
 8C3F  cp   $04		FE 04		|	8C40  ld   a,$03	3E 03
 8C41  jr   z,$8C4A	28 07		|	8C42  ld   ($A000),a	32 00 A0	// change A000-BFFF bank to 03
 8C43  cp   $07		FE 07		|	8C45  ei		FB		// enable interrupts
 8C45  jr   z,$8C4A	28 03		|	8C46  pop  af		F1
 8C47  ld   hl,$8992	21 92 89	|	8C47  and  $7F		E6 7F		// AND 0111 1111
 8C4A  ld   ($EC02),hl	22 02 EC	|	8C49  ret  z		C8		// If A=00 or 80, return
					|	8C4A  nop nop nop	00 00 00
 8C4D  call $4384	CD 84 43

F5 F3 21 00 A0 36 0C CD C0 BE 3E 03 32 00 A0 FB F1 E6 7F C8 00 00 00


19EC0:
 BEC0  cp   $80			FE 80
 BEC2  jr   z,$BEE8		28 24
 | BEC4  and  a			A7		// ChkPlayerShots Code
 | BEC5  jr   z,$BED9		28 12
 | | BEC7  ld   hl,$8951	21 51 89
 | | BECA  cp   $03		FE 03
 | | BECC  jr   c,$BED9		38 0B
 | | | BECE  cp   $04		FE 04
 | | | BED0  jr   z,$BED9	28 07
 | | | | BED2  cp   $07		FE 07
 | | | | BED4  jr   z,$BED9	28 03
 | | | | | BED6  ld   hl,$8992	21 92 89
 | BED9  ld   ($EC02),hl	22 02 EC
 | BEDC  ld   a,($D010)		3A 10 D0	// NEW CODE: ChkEnemyHurtTimer (D010 = EnemyHurtTimer)
 | BEDF  and  a			A7
 | BEE0  ret  z			C8		// If EnemyHurtTimer == 0, return
 | BEE1  dec  a			3D
 | BEE2  ld   ($D010),a		32 10 D0	// Decrement EnemyHurtTimer
 | BEE5  jr   z,$BF13	 o	28 2C		// If EnemyHurtTimer == 0, jump to ChangeBossColor Code
 | BEE7  ret		 |	C9
			 |
 BEE8  ld   a,(iy+$0d)	 |	FD 7E 0D	// EnemyHurt Code
 BEEB  sub  c		 |	91
 BEEC  jr   nc,$BEEF	 |	30 01
 | BEEE  xor  a		 |	AF
 BEEF  ld   (iy+$0d),a	 |	FD 77 0D
			 |
 BEF2  ld   a,($D000)	 |	3A 00 D0	// NEW CODE: ChkBossHurt
 BEF5  cp   $09		 |	FE 09		// TANK (09)
 BEF7  jr   z,$BF0C	 |	28 13
 | BEF9  cp   $12	 |	FE 12		// BULLDOZER (12)
 | BEFB  jr   z,$BF0C	 |	28 0F
 | | BEFD  cp   $23	 |	FE 23		// IF LASER (23), RETURN
 | | BEFF  ret  z	 |	C8
 | | BF00  cp   $25	 |	FE 25		// IF FLAME (25), RETURN
 | | BF02  ret  z	 |	C8
 | | BF03  cp   $29	 |	FE 29		// COWARD DUCK (29)
 | | BF05  jr   z,$BF0C	 |	28 05
 | | | BF07  sub  $20	 |	D6 20
 | | | BF09  cp   $07	 |	FE 07		// BIG BOSS (20), SHOTGUNNER (21), M.GUN KID (22), FIRE TROOPER (24), HIND-D (26)
 | | | BF0B  ret  nc	 |	D0
 BF0C  ld   a,c		 |	79		
 BF0D  and  c		 |	A1
 BF0E  ret  z		 |	C8		// Return if BossDamage == 0
 BF0F  ld   (iy+$10),$10 |	FD 36 10 10	// D010 = 10 cycles		(D010 is our newly created EnemyHurtTimer)
			 |
 BF13  ld   a,($D000) <--|	3A 00 D0	// NEW CODE: ChangeBossColor
 BF16  cp   $26			FE 26		// HIND-D (26)
 BF18  jr   nz,$BF2C		20 12
 | BF1A  ld   de,$7000		11 00 70	// RED	(RB0G)
 | BF1D  ld   a,($D010)		3A 10 D0
 | BF20  and  a			A7
 | BF21  jr   nz,$BF26		20 03
 | | BF23  ld   de,$1003	11 03 10	// OG GREEN (RB0G)
 | BF26  ld   a,$01		3E 01		// PALETTE 1
 | BF28  call $4E66		CD 66 4E	// SetPaletteColor
 | BF2B  ret			C9		// EXIT - Hind-D is a special case (not made of sprites)

 BF2C  ld   bc,$084F		01 4F 08	// NEW COLOR (RED/BLACK)
 BF2F  ld   a,($D010)		3A 10 D0	
 BF32  and  a			A7
 BF33  jr   nz,$BF42		20 0D		// If EnemyHurtTimer > 0, Boss = RED
 | BF35  ld   bc,$024D		01 4D 02	// OG COLOR FOR MOST BOSSES
 | BF38  ld   a,($D000)		3A 00 D0
 | BF3B  cp   $13		FE 13
 | BF3D  jr   nc,$BF42		30 03
 | | BF3F  ld   bc,$0B4C	01 4C 0B	// OG COLOR FOR TANK & BULLDOZER
 BF42  ld   de,$0005		11 05 00	// Incrementer (5)
 BF45  ld   hl,$D020		21 20 D0
 BF48  ld   a,(hl)		7E		// A = (D020) = Total Sprites * 2
 BF49  add  hl,de  <-----|	19
 BF4A  ld   (hl),b	 |	70		// (D020 + DE) = B color
 BF4B  add  hl,de	 |	19
 BF4C  ld   (hl),c	 |	71		// (D020 + DE) = C color
 BF4D  sub  $02		 |	D6 02
 BF4F  jr   nz,$BF49 	 o	20 F8
 BF51  ret			C9

FE 80 28 24 A7 28 12 21 51 89 FE 03 38 0B FE 04 28 07 FE 07 28 03 21 92 89
22 02 EC 3A 10 D0 A7 C8 3D 32 10 D0 28 2C C9 FD 7E 0D 91 30 01 AF FD 77 0D
3A 00 D0 FE 09 28 13 FE 12 28 0F FE 23 C8 FE 25 C8 FE 29 28 05 D6 20 FE 07 D0 79 A1 C8 FD 36 10 10
3A 00 D0 FE 26 20 12 11 00 70 3A 10 D0 A7 20 03 11 03 10 3E 01 CD 66 4E C9
01 4F 08 3A 10 D0 A7 20 0D 01 4D 02 3A 00 D0 FE 13 30 03 01 4C 0B 11 05 00 21 20 D0 7E 19 70 19 71 D6 02 20 F8 C9

FIX HIND-D TOP-LEFT TILE:

Set 1F434 from 1B to 0B to fix Hind-D top-left tile (left wing)

CHANGE CRATES IN HIND-D BOSS ROOM FROM GREEN TO BROWN:

My method for turning HIND-D red when damaged involved updating the screen palette - hence I had to alter the color of the nearby crates.
This was unfortunate... a silver-lining is that the crates now closer resemble the orange color they normally have on rooftops.

BCF:
 4BCF  call $426A	CD 6A 42
 4BD2  call $42C4	CD C4 42
 4BD5  ld   hl,$9509	21 09 95
 4BD8  ld   de,$9400	11 00 94
 4BDB  ld   b,$08	06 08
 4BDD  push hl		E5		|	4BDD  di		F3		// disable interrupts
 4BDE  call $524C	CD 4C 52	|	4BDE  ld   a,$0C	3E 0C
 4BE1  pop  hl		E1		|	4BE0  ld   ($A000),a	32 00 A0	// change A000-BFFF bank to 0C
 4BE2  ld   de,$9840	11 40 98	|	4BE3  call $BE90	CD 90 BE
 4BE5  ld   b,$08	06 08		|	4BE6  ld   ($A000),a	32 00 A0	// change A000-BFFF bank to 09
 4BE7  call $5265	CD 65 52	|	4BE9  ei		FB		// enable interrupts
 4BEA  jr   $4BAE	18 C2

F3 3E 0C 32 00 A0 CD 90 BE 32 00 A0 FB

19E90:
 BE90  ld   a,($E700)	3A 00 E7
 BE93  push af		F5		// Store E700 Palette Value
 BE94  ld   a,($C130)	3A 30 C1
 BE97  cp   $32		FE 32
 BE99  jr   nz,$BEA8	20 0D		// In Hind-D Room?
 | BE9B  ld   a,$04	3E 04
 | BE9D  ld   ($E700),a	32 00 E7	// E700 = Palette 4
 | BEA0  push de	D5
 | BEA1  ld   de,$3102	11 02 31	// BROWN (RB0G)
 | BEA4  call $4E66	CD 66 4E	// SetPalette4 to BROWN
 | BEA7  pop  de	D1
 BEA8  push hl		E5
 BEA9  call $524C	CD 4C 52	// Load3bppTiles (for crates)
 BEAC  pop  hl		E1
 BEAD  ld   de,$9840	11 40 98
 BEB0  ld   b,$08	06 08
 BEB2  call $5265	CD 65 52	// Load3bppTileFlip (for crates)
 BEB5  pop  af		F1
 BEB6  ld   ($E700),a	32 00 E7	// Retore E700 Palette Value
 BEB9  ld   a,$09	3E 09
 BEBB  ret		C9

3A 00 E7 F5 3A 30 C1 FE 32 20 0D 3E 04 32 00 E7 D5 11 02 31 CD 66 4E D1
E5 CD 4C 52 E1 11 40 98 06 08 CD 65 52 F1 32 00 E7 3E 09 C9