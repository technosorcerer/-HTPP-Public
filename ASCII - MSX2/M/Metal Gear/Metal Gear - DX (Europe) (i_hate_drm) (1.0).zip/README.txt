01. Can use keyboard Q-W-E-R for menus, and F for punch.
    Q = Quit (Pause), W = Weapons, E = Equipment, R = Radio, F = Fight (Punch).
02. Don't have to press F5 to continue.
03. Can swap between menus.
04. Rations/Ammo fill up completely.
05. Don't have to select keycard to open doors.
06. Keycards group together in inventory.
07. Game auto-saves when you EXIT the elevator.
08. Can open menus in elevators.
09. All dialogue is skippable.
10. Can use ration in equipment menu with punch button.

11. Bosses flash red when damaged.
11a. Fixed one wrong tile on Hind-D. Changed color of nearby crates.

12. Big Boss calls to explain how to get Schneider's frequency.
12a. Auto-dial disabled after calls to make this process seamless.
13. Schneider calls for bombable walls in the basement.
14. Jennifer calls at 4-Star Rank for Locked Door / Rocket Launcher.
14a. Jennifer's calls count as "listened to" even if you skip her text.

15. Removed bombable wall in basement leading to Enemy Uniform.

16. Oxygen Tank is in Compass room. Compass is in room next to Coward Duck.
16a. Oxygen Tank renamed from "BOMBE" to "SCUBA". Ration in Oxygen Tank room.
16b. Radio messages about location of Oxygen Tank / Compass disabled.

17. Total Explosives unaffected by rank. Maximum capacity is always 20.
18. Explosives/Ammo added to Metal Gear fight to prevent possible soft-lock.
19. Electric Grid outside Coward Duck altered to prevent possible soft-lock.
20. Door below Shootgunner changed to Card 1 Lock to prevent possible soft-lock.
21. Ration added to Building 2 Roof to prevent possible soft-lock.
22. Ration added to Building 2 Basement to prevent possible soft-lock.
23. Ration added to Grey Fox Cell to prevent possible soft-lock.

24. Sentinel guards have a minimum wait-time before turning (still randomised).
25. Modified guard positions/paths to prevent immediate alerts.

This hack is compatible with the EUROPEAN ROM of Metal Gear.

It can be played at 60 Hz using blueMSX Emulator.

Options -> Emulation -> Video Frequency -> 60 Hz.

You can apply this patch using Lunar IPS.

Full documentation has been included, as well as supporting images and individual hacks (if you would like to make your own Metal Gear DX).

Hope you enjoy.