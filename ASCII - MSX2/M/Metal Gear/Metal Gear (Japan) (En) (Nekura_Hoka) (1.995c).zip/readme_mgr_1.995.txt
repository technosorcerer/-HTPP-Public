Metal Gear Remix (a.k.a. Metal Gear Redux)
Version 1.995 rev.c
Japanese to English translation for the MSX2 (06/06/2020)
2004, 2020 Takamichi Suzukawa, Jon Taylor, and Nekura_Hoka
Readme by: Nekura_Hoka
-----------------------------------------------------------


What is this?
-----------------------------------------------------------
 This patch is for the Japanese localization of Konami's
Metal Gear for the MSX home computer. It translates the
game to american english.


Terms and Conditions
-----------------------------------------------------------
 This patch is freely available for non-commercial use.
This patch must be distributed in its original form without
modification to itself or it's parent archive (zip file).
Contents of the parent archive must not be altered in any
way. Do not distribute this patch with a ROM copy of Metal
Gear.


Features:
-----------------------------------------------------------
	 -Faithful fan translation of all 155
	  messages from the original Japanese
	  version of the game. The original United
	  Kingdom release of the game did not
	  include all the original messages. The
	  current full script is 12210 bytes, and
	  is compressed by 45% to 6693 bytes.

         -New font with lowercase lettering.
	  This is not a feature available in any
	  other version of the game.

	 -Full compliance with details from
	  other titles in the Metal Gear
	  series.


Usage:
-----------------------------------------------------------
1. The patch requires the use of an IPS patch
   utility. IPS.exe is readily available on
   the 'net. Personally, I use LunarIPS.

2. You need a properly dumped Japanese Metal
   Gear ROM for the MSX. If you have a cartridge
   of Metal Gear for the MSX, but not the
   hardware to dump it, then any of the Japanese
   ROMs available on the internet should do nicely.

   This patch will work on both the original
   Japanese rom, and the version that has been
   hacked to be region-free. If you are emulating
   the region locked rom, you will have to 
   configure your emulator to emulate a Japanese
   machine.
	
3. Use the patcher to patch your ROM (back it
   up beforehand). If the ROM doesn't emulate
   make sure the original ROM you patched
   works to verify you have a good copy.
   If you're using an emulator that uses a
   database to automatically detect the MSX
   ROM type (blueMSX etc.), be sure it has
   detected it as a Konami PSG ROM ('Konami' in
   newer versions of blueMSX, 'Konami 4' in older
   versions).

Notes. This patch will work with the VSYNC hack for
   Metal Gear. No issues that I've discovered. This
   patch should work with the disk Save/Load hack
   for this game, but might not with work with saves
   from a previous version. I recommend applying the
   translation patch first, then the Save/Load patch.

Changes for 1.995:
-----------------------------------------------------------
 -With the use of an automated system to encode the
  script and calculate pointer values on-the-fly, I've
  fleshed out the script using Takamichi's original
  translation and information from later Metal Gear
  titles. The context and meaning of the original
  Japanese is maintained, but grammar, spelling, and
  expressions are adapted to American English speakers.

  It was very important to me on this go-around to make
  the game feel more natural. Prior versions were better
  than the UK translation, but space economy was always so
  critical that basic articles of conversational English
  were repeatedly shortened or lost. Everything felt
  abbreviated and we never wanted that for this
  translation. My hopes for this translation, ones that
  I never thought we could do, have finally been met.

 -Big Boss' playful messages regarding some items now
  includes Snake's characteristic ", huh?" I thought
  this would be a nice addition and it kind of signals
  to players of the series that they're in for a
  less-than-serious communication.

 -New font which is slightly larger than the 1.9 font.
  Some players had trouble with the small size of the
  prior font. Unfortunately, the font tiles are now
  part of the script compression system, so it is not
  possible to have an all capital font without reducing
  script size, but this one is easier to read.

Changes for 1.91:
-----------------------------------------------------------
 -Fixed a bug with the final message after the end
  credits. The location address was off by a single
  byte, causing the message not to display.

Changes for 1.9:
-----------------------------------------------------------
 -Heavily modified the font table. The original
  font table was used, but the capital letters
  had to be thinned so they wouldn't look out
  of place with the new lowercase ones. I tried
  a font with stencil lines in the lowercase, in
  addition to those in the uppercase, but the font
  becomes almost unreadable in my opinion, so it
  was scrapped. I toyed with the idea of using a
  completely different font altogether (I drew in
  OCR-A, of Crimson Tide etc. fame), but it
  didn't seem right to completely get rid of the
  essence of the original font in the game.

 -Game now utilizes MCT (Multi Character Tiles)
   This means sometimes the game has more than
  one character per font tile. On average only
  2 per tile. There is one that includes
  3 characters "'ll". This process saved a load
  of space and allowed for the lowercase script
  (before it would have been impossible without
  cutting the script or game reassembly) and
  some other things.

 -No longer uses the Literal/Modern different
  patches. Beretta and Ingram are properly
  spelled in this one, regardless of how they
  were in the original Japanese. (Ingrum and
  Belleta)

 -Changed Big Boss' title from simple "commander"
  to "commander-in-chief". This was a space-saving
  consideration in the original patch and isn't
  necessary anymore. "commander-in-chief" jives
  with Previous Operations and Takamichi's
  original translation of the game's script.

 -Added Diane's "...Bye" to one message that
  was erroneously missing it. You may notice
  that there are other messages that don't
  feature a sign-off from the characters, but
  this is in sync with the original script. This
  instance was just a mistake by myself.

 -Added "Find ammo and don't waste it." to BB's
  description of the Beretta. Takamichi pointed
  this out a couple of times before the 1.0
  release, but I'd mistakingly thought it wasn't
  in the original script. I was wrong.

 -Miscellaneous formatting changes because of
  the new tiles.

 -Changed "Are they moving their houses?" to
  simply "Are they moving?". "their houses"
  sounds translated and overcomplicates a simple
  and extremely common idiom. I originally kept
  'their houses' in v1.0 becuase I was being
  overly cautious about whether the player
  would understand what was meant by it. The
  more I played the game after the original
  patch's release, I realized it wasn't really
  necessary to the fluent english speaker.

 -Changed "schoolgirl's uniform" to "sailor's
  suit". The original translation reads "sailor's
  clothing" and is a reference to japanese 
  school uniforms. It's intended as a jab
  against the soldiers and indirectly to Solid
  Snake, becuase he's gonna wear it. I figured
  "Sailor's suit" was a more natural way to bring
  up the right image in westerner's heads, while
  staying close to the original translation.

 -Includes translation project members names
  in the game's final credits.

 -Changed the mention of "rank" in the script to
  refer to "class". "Class" has always appeared
  in the HUD and I wanted the script instance to
  match. Also, while dumping MGS3's subtitles, I
  noticed that "Colonel class" is mentioned rather
  than 'Colonel rank', so I figured the change
  could be a neat way to sync with the series.

 -Changed 'Trans' item to 'Bug'. Makes the item
  synchronus with the script mention and I
  thought it would be better to have a full word
  for the item name in the select screen rather
  than a fragment of one. 
   "Bug" is a bit informal, but there are plenty
  of item names in the various installments of
  the series that are at least as informal as this.
  An example might be the planted "Bomb" in Snake's
  inventory. I think the philosophy of using an
  unambiguous name for the dangerous item is the
  right one.


Credits:
-----------------------------------------------------------
Takamichi Suzukawa - Translator

Jon Taylor - Proof-reader

Nekura_Hoka - Coder


Thanks:
-----------------------------------------------------------
msx.org Forums - For tolerating a new person's
	request for aid. Many forums on the net
	seem to have devolved into an arena for
	pummeling new posters, this one hasn't as
	far as I can tell.

Ola Andersson - Got Takamichi in touch with me and
	got this project rolling towards
	completion. Also had some good questions
	and suggestions that helped more than he
	will ever know.

Junkerhq.net - The text dumps available here led
	me (Nekura) to begin looking for a way to
	dump the script for Metal Gear, which
	began my interest in doing the coding for
	the script insertion. There's an abundance
	of info on all of Kojima's games and a
	good set of forums.

Hideo Kojima, Noriki Hibino, and Harry
Gregson-Williams- For a great game series and for
	Kojima's Red Disc collection soundtrack
	remixes as well as the Original Soundtracks
	for MG 1+2 and MGS1, 2 and 3. This music kept
	me at least halfway sane and motivated during
	the table readdressing process. (which I did
	essentially manually)

Raihan Kibria, Pabs, and Gerson Kurz - For
	frhed 1.1.0 an amazingly powerful and
	useful FREE hex editor. This is primarily
	what I used for the script insertion.
	http://www.kibria.de/frhed.html

Microsoft - For the XP versions of Calculator and
	Notepad. Calculator for the hex value
	conversions and Notepad for finally having
	a 'Replace' function, thereby making
	switching to wordpad unnecessary and
	finally at least equaling the over
	12-year-old edit.com program in
	capability. ;D

Squaresoft - For making Final Fantasy IV with the
	DTE (Dual Tile Encoding) script system
	which gave me the idea to do a similar
	thing for MG and save a lot of space.