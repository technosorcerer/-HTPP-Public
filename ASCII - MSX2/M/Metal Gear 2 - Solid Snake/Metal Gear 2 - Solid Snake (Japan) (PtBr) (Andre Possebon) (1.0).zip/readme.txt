////////////////////////////////////////
//                                    //         
//             METAL GEAR 2           //
//                                    //
//            KONAMI - 1990           //
//------------------------------------//
//                                    //
//      METAL GEAR 2 EM PORTUGUES     //
//                                    //
//          VERSAO 1.0 - 2002         //
//                                    //
//          ANDRE POSSEBON            //
//          DANIEL TREZUB             //
//    ALEXANDRE ANTONIUTTI PASSOS     //
//          JORGE STROMBERG           //
//                                    //
////////////////////////////////////////

VERSAO 1.0

	Esta � a primeira vers�o traduzida 
para o portugu�s deste grande jogo que � 
METAL GEAR 2. O trabalho de tradu��o foi 
feito de forma que ficasse o mais fiel 
poss�vel a hist�ria original. Como durante 
uma partida � dif�cil passar por todas as 
situa��es poss�veis, ainda podem haver alguns 
erros, portanto sinta-se � vontade para 
comunicar quaisquer falhas encontradas.

ANDRE POSSEBON - andre2999@yahoo.com

http://www.geocities.com/msxland/mg2pt/

Esse ips s� funciona na vers�o .rom, n�o aplicar na vers�o disk (.dsk).

-----------------------------------------------------------------------------------
AGRADECIMENTOS

	A tradu��o do METAL GEAR 2 contou com a
ajuda de algumas pessoas cujo esfor�o possibilitou
a realiza��o deste trabalho e por tanto n�o podemos
esquece-las.


-  TAKAMICHI SUZUKAWA & MAARTEN TER HUURNE
   Autores da vers�o em ingl�s do METAL GEAR 2.

-  ADRIANO CAMARGO RODRIGUES DA CUNHA
   Pela ajuda t�cnica na tradu��o da apresenta��o 
   e de alguns outros textos.
-----------------------------------------------------------------------------------
