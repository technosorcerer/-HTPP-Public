KING KONG 2 ENGLISH RETRANSLATION
=================================

This is a brand new 'King Kong 2' english translation.
Now, all the messages have been retranslated from the original japanese script, quite different than the french translated one.

What you need to use this patch:

1) 'kk2-eng.ips' file (obviously).

2) 'King Kong 2' (Japanese) ROM dump, from your original cartridge of the game.

3) An IPS patching program. These programs are freely available at many places on the internet. You can patch the game on your MSX too; Just get IPS4MSX by BiFi here:

http://ips.tni.nl/

This patch is for the japanese version of 'King Kong 2', not for the previous english nor french translated versions. You distribute it freely. Just one condition, you must include THIS text with the patch.

Huge thanks to:

-Chiho and Kyoko for translating the original script.
-Takamichi Suzukawa for the manual translation and a few corrections to the translated script.
-Caspar Smit for remaking his walkthrough and helping me with the testing (http://www.gamefaqs.com/computer/msx/game/918126.html).
-Zanac2 and Saeba for their help with the original manual ;)
-Manuel Pazos for disassembling the game (he let me know there are three different endings, appart from other discoveries).

Keep on MSXing!!

(c)IMANOK 2005
http://www.imanok.cjb.net