Aplicar na Rom: Aleste (1988) (Compile) (J).rom
Sistema: MSX
Genero: Nave
Produtora: Compile
Ano de Lan�amento: 1988
N� de Jogadores: 1
Tradutor: Luiz H. Lugato
Grupo: Nenhum
Lan�amento da Tradu��o: 30/1/2002
Site: Nenhum
Vers�o: ???
Tradu��o: 99%

Antes de aplicar o IPS na sua rom fa�a uma c�pia da mesma