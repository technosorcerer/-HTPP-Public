




                                  Silviana
                         English Translation Patch




 History
-----------------------------------------------------------------------------

091213 Initial release




 Overview
-----------------------------------------------------------------------------

This is a translation patch for the MSX2 game Silviana. In addition to being
a full translation, it also makes numerous enhancements to the game in order
to increase your enjoyment. There is also a dual-language feature of sorts.




 Applying the Patch
-----------------------------------------------------------------------------

Hopefully included with this document is a patch file in the IPS format.
This patch utilizes run-length compression, which was not part of the
original IPS standard. Therefore, it is possible that some patcher programs
will not work with this patch.

Every copy of this game that I've seen in the wild is based on the same
cracked source disk. This patch might work with the uncracked version, but
this hasn't been confirmed.




 Playing the Game
-----------------------------------------------------------------------------

Once you've patched the disk image, simply load it in your favorite MSX
emulator or write it to a floppy disk to use on a real MSX2 system.
It requires an NTSC MSX2 (or better) and 128k of RAM (originally only 64k).

The controls are as follows:

Button A / Space  Confirm, use equipped item
Button B / Enter  Cancel, inventory screen
F1		  Save game to RAM
F2		  Inventory screen
F3		  Equipment screen
F4		  Treasures screen
Shift-F5	  Save game to RAM & disk
Escape		  Pause game

To run the game with Japanese text, you need to modify the AUTOEXEC.BAT file
to add a second argument which should consist only of the letter 'J'.
You could also accomplish this by pressing Control-C repeatedly after MSX-DOS
loads in order to halt the batch file. (There is probably an easier way to
disable it but I don't know what it is.) When control returns to MSX-DOS,
type "TYPE AUTOEXEC.BAT" to see the command used to start the game, then
retype it and add a space and the letter 'J'. Be aware that only some of
the text will be in Japanese.

Warning: it is not recommended to extract the files and run them as a
virtual disk. I have had problems with some emulators apparently building
the simulated disk image wrong sometimes. In addition, certain emulators
will refuse to write back any changes so you won't be able to save the game.




 Q & A
-----------------------------------------------------------------------------

Q: This patch doesn't work! What do I do?

A: Try using a different emulated machine, preferably one that meets the
   system requirements listed earlier and that can run the original game.
   You may also have better luck using a different emulator.


Q: Silviana or Sylviana?

A: Without an official romaji rendering, there is no way to tell for sure.
   Both spellings are "real" names in the West and are legitimate renderings
   of the Japanese. There are other possible transliterations as well.

   One of the files on the disk use the former spelling so that is the one
   used for this translation. However, I would not necessarily consider that
   to be conclusive.


Q: What do Gamma Eyes do?

A: If equipped, they will protect you from one trapped chest/bag.




 List of Changes (not exhaustive)
-----------------------------------------------------------------------------

Text in the opening pictures was translated and the graphics were repacked
English section of font was improved
Minor graphical fixes to a few of the icons
Some error strings were translated
Lots of unnecessary delays were reduced or eliminated
Additional input options can now be used at the main menus
New Game / Continue options were swapped so that Continue is at the top
Numbers moved around in the inventory screen for aesthetic reasons
Equipment screen modified to show more text
The previously unused (in-game) B Button now accesses the inventory
F2/F3/F4 now work more intuitively and with added convenience
All 30 characters of the text display line are now available for use
Dual-language feature added




 Translation Notes
-----------------------------------------------------------------------------

Probably the biggest flaw of this translation is that item and equipment
names are restricted to eight characters. Hence, almost everything got
abbreviated to some degree during translation. Fixing this is certainly
possible, but some of the other parts of the various displays would suffer
and it is more work than I wish to invest in such a short game.

Most of the abbreviations should be intelligible when viewed in the context
of their icons, but a few of the less obvious ones are listed here.

 St = Statue
Flw = Flower
Fth = Feather
  R = Ring
  D = Doll




 Hacking Notes
-----------------------------------------------------------------------------

This was started as a toy project, but ended up being fairly complete.
As you can see from the changes section above, quite a lot of improvements
were made to the game, and I believe it to be superior to the original.

As you may have noticed, the RAM requirements for this game increased over
the original amount. The reason is that there is very little obviously-unused
memory during the main part of the game. While it might be possible to scrape
together enough space for the translated strings and code hacks, they would
be scattered all over the place and certain system areas would probably have
to be overwritten. It was much easier and safer to simply store the string
data in an unused RAM page and overwrite the Japanese strings with the code
that was written to facilitate this hack. I admit that the additional RAM
requirement is a demerit.

Most of my translation patches have dual-language features where the original
Japanese script is kept intact and can be activated under certain conditions.
This game is no exception, however it is more of a side effect rather than a
planned feature. The original string section was kept but moved to paged RAM
so that it could be used in place of untranslated strings during development.
Because of this, it was not hard to add a command line option to disable the
English strings and use the originals. However, this only applies to some of
the in-game strings, not items and other text.

Variable-width is surprisingly easy to do in certain MSX2 video modes.
Unfortunately, doing it the easy way was noticeably slowing down the text
scrolling and I didn't have the fortitude to do the messy hacks necessary
to fix it. It also might not have looked good without being applied to all
the other in-game text, which was a daunting task. Still, you do get some
variable-width text in the opening, since it uses pre-rendered graphics.
Several programs were developed to unpack and repack the picture data and
to render the text directly into the bitmaps using the same font as the game.

While I sometimes endeavor to fix original bugs present in games, I often
leave them alone if they aren't likely to get blamed on me. This game has
an interesting defect where continuously switching between the equipment
and treasure screens will deplete the stack. Returning to the game will
unroll it. I'm not sure how many times you'd have to do this to disrupt the
game, but it seems harmless for anyone not intentionally trying to break it.
