Super Runner (MSX)
Traducción al Español v1.0 (05/12/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Runner (1987) (Pony Cannon) (J).rom
MD5: a5fc4e9b290ee0e2e8ebb7f8b49d1ace
SHA1: 3202af113265e67e130a0b948dc167a9f9e9cc79
CRC32: 5a5be701
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --