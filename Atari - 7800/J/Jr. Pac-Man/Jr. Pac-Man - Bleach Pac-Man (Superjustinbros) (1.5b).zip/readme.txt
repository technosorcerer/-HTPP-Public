~Bleach Pac-Man Readme~

This is v1.5 of a modification to a homebrew Atari 7800 port of the arcade game "Jr. Pac-Man". It modifies most of the graphics and text, as well as adding in a new set of eight levels to replace the originals.

The hack is based on the 2000's manga and anime series "Bleach" by Tite Kubo, and tries to be as accurate as possible to the source material. Not everything desired could be implemented into the hack due to the limitations of the original unmodified ROM and the editor utility used to create the hack.

The original unmodified ROM is located here:
http://www.atariage.com/forums/topic/140371-hi-question-about-the-atari-jr-pac-man-discovered/page__view__findpost__p__1740840

The utility, the Pac-Man Construction Set, is here:
http://www.atariage.com/forums/topic/149672-how-to-create-custom-7800-pacman-hacks/

Pac-Man is © Namco/Namco Bandai Games.
Bleach and its characters are © Tite Kubo and (Weekly) Shonen Jump.
Original homebrew port of Jr. Pac-Man was created by PacManPlus.

This is a non-profit fangame/hack created by Superjustinbros
(superjustin@optonline.net) for entertainment.