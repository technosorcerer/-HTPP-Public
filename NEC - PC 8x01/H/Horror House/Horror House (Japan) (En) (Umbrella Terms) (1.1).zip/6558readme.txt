----------------------------
--      Horror House      --
--    Complete English    --
--       Translation      --
----------------------------

Horror House {V1 mode, MON R, press S}.t88
SHA-1: 3BA80F042ACB22B53DA0D433C02D74E239879572
SHA-256: 0B5BFBB86C6ADE0B05B8C293FEC92DE3340DF7E337ABC4018DE6FD5163294045
MD-5: CC74CD971562A5EF869823428B4C9DD9

Apply with DeltaPatcher.

WARNING: This game has EXTREME FLASHING LIGHTS/COLORS, so please be careful when
playing.

NOTE: All text should be translated, but if you find
anything untranslated/mistranslated/typos, contact @UmbrellaTerms on Twitter.

NOTE: When you type "LOOK INVENTORY" with no items, you will get a grammatically
incorrect sentence. This is not a typo but a consequence of the game's
code.

Historical Context:
Falcom's first adventure game. Released August 1983.

To load game:
While the game technically works on the M88 emulator, the vertical text alignment
will be random. This occurrs with the unpatched file, so I assume this is an
emulator issue. This does not occurr in the QUASI88(Q88) emulator, so I
reccommend you use that one to play. I do not know about running it on
actual hardware. The following instructions are for Q88:
Click Misc -> Tape Image [Load] -> Set -> Choose .t88 file
For V1 Mode: At "How many files(0-15)?" just hit return.
Type "mon" and hit enter.
Type "r" and hit enter.
Wait for game to load, it will take a while. (You can go to Setting -> Speed ->
No Wait to speed it up, but turn it off once the main screen comes up.)
At the main screen keep pressing "s" until the game starts, it can be finicky
with detection.

Instructions:
I do not have the manual, so these are from me.
You are stuck in a house full of ghosts/yokai/monsters. Try to figure out the
mystery of the house and escape.

The parser works in the form of VERB + NOUN. Commands must be in all caps, so
it will be a good idea to have caps lock on.

Verbs and nouns are only one word each. When a noun appears in the game text, it will
be in all caps. There are many nouns/verbs never shown in text, so you can't
completely rely on in-game text. These are the basic verbs:
GO	TAKE	DROP	LOOK	READ	MOVE

Movement is in the form of GO [DIRECTION] with the directions being:
FORWARD LEFT RIGHT BACK UP
EX: GO FORWARD
You will always be facing the same direction in a room, there is no turning.
You can use F1-F5 as movement shortcuts in the order of directions shown above.

To see inventory type "LOOK INVENTORY"

Sometimes the parser will keep pressing a key or return, just keep pressing backspace
or return until it fixes. You might want save state because that can lead to
instant game over in some cases due to how the game works.

If you would like to see all the available nouns/verbs in the game, go into
the SPOILERS folder and open the commands(spoilers).txt file. There is also a
solutions(spoilers).txt file that gives solutions to puzzles.



