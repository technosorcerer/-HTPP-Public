Patch réalisé par le Liberl News en Octobre 2022.
Traduction et programmation : Twn et Aisoce

=== Instructions ===
1 - Récupérer le fichier .t88 original (japonais).
2 - Le patcher avec xdelta (utiliser par exemple https://www.romhacking.net/utilities/598/)
3 - Mettre le fichier font.rom dans le bon dossier selon l'émulateur (Pour M88, le fichier font.rom doit être placé dans le même dossier que m88.exe)
