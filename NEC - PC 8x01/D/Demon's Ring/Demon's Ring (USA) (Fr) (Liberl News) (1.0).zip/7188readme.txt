Patch réalisé par le Liberl News en Janvier 2023.
Traduction et programmation : Twn et Aisoce

=== Instructions ===
1 - Récupérer les deux fichiers .d88 originaux
2 - Les patcher avec xdelta (utiliser par exemple https://www.romhacking.net/utilities/598/)
3 - Mettre le fichier font.rom dans le bon dossier selon l'émulateur (Pour M88, le fichier font.rom doit être placé dans le même dossier que m88.exe)
4 - Vous pouvez récupérer le manuel traduit à ce lien : https://drive.google.com/file/d/1y30XHW05CAfQq0I6-UIuzuuIft2e8ryU/view?usp=drive_link