[//]: <> (This readme is in the markdown format. Please preview in a markdown parser.)

# Shin Taketori Monogatari (PC-88): English Version 1.0

Source code: [https://github.com/romh-acking/shin-taketori-monogatari-pc88-en](https://github.com/romh-acking/shin-taketori-monogatari-pc88-en)

## About
*Shin Taketori Monogatari* (The New Bamboo Cutter Story) is a game developed by Cross Media Software and published in 1984 by Victor Musical Industry. It was released on multiple Japanese computers: the PC-88, PC-98, and Sharp X1. Later on, a sequel was released, titled Shin Tamatori Monogatari (The New Stolen Gem Story). A Famicom version titled Kaguya Hime Densetsu (The Legend of Princess Kaguya) was released soon after which loosely adapts the two games; [I also translated this version, check it out!](https://github.com/romh-acking/kaguya-hime-densetsu-fc-en)

If you played the Famicom adaption, you'll discover a fairly weird game. The source material, believe it or not, is even weirder. Looking at the early Japanese PC library, it's fairly easy to find some unhinged content, even from the most unexpected developers, like Enix. Most were just flat out adult games with adult content with subject matter that just begged law makers to create regulations. Thankfully, Shin Taketori Monogatari doesn't go down this route. It has some adult themes and dirty jokes, but it's by no means an adult game. It's an adult gag comedy that pushes the envelope of sheer insanity, but it's not explicit. Just keep in mind this is a game with early 80s sensibilities.

Personally, I think the Famicom version makes for a better game. It has a more modern game design, and there's no loading times.

## Hacking Notes
To find all the text in, I added a DTE asm hack. With it, we had more than enough space to fit the script in. To load the hack in, I had to store my hacks into empty sectors, make the game recognize them, and leverage the game's built-in logic to load the function into RAM. A standard practice to do in most games, except the best debugger at my disposle is MAME. MAME is a mixed bag and your experience depends on the core. For the PC-88, it's okay, but better than anything else out there. To date, the PC-88 cores don't have a throttle option. So debugging for a while required having me sit through the lengthy intro over and over. After getting some good footing, I got away with using M88 and its throttle feature.

The manual lists just five team members, but inside the BASIC code loaded into RAM there's additional credits of two other people for "protect". What does this mean? I always assumed it was just copy protection because the game uses a custom file system, but I wasn't exactly correct. Later on I realized that not all logic was in the assembly code. Apparently, a lot of logic was handled by BASIC code. I assumed it was compressed until I realized, no, it was not. It was XOR encrypted... twice. And the keys were random bytes from the BIOS. The "protection" was reverse engineered in a couple of hours and tools were made in a few days of work to handle decrypting and encrypting the data to and from the disk. The data was fragmented on the disk too for good measure. Amusingly, the protection leveraged by the game was the weakest hurdle imposed onto me.

I had to create a decompiler and compiler for the PC-88's implementation of BASIC. This was done to adjust a good chunk of logic to adjust string ordering and translate Japanese text and adjust Engrish text. This was a pain to work with for a couple of reasons:
1. There was duplicated logic in almost all of the BASIC files, however, the logic wasn't always duplicated one to one. This made finding and replacing at a wide scale tricky.
2. The BASIC code is obtuse and has poor variable names.

The game uses vector graphics which are drawn on-screen, some of which contain Japanese text. I did not translate these. Inserting the text was already an undertaking. The tools at my disposal make the tasks possible but tedious and I value my time (to a certain extent). The graphics are loaded in a `0x100` byte large window at RAM address `0xD100`. Go wild.

This was one of the hardest games I had to work with. The codebase is held together by duct tape, PC-88 emulation tools and documentation are mediocre at best, and the game being an open-ended text adventure made beta testing very lengthy. The workflow for this project consisted of me working as a hacker and having testers basically trek out the game to understand the progression and what bugs existed. The entire production was basically a continuous beta test. A huge shoutout to the beta testers for this project. Without you all, this project wouldn't be possible or at the quality it is at.

## Patching Instructions
The patch is a [Beat patch](https://github.com/killvxk/beat). Either use the Beat patcher or patch your rom here:

[https://www.marcrobledo.com/RomPatcher.js/](https://www.marcrobledo.com/RomPatcher.js/)

## Pictures
Because the images weren't translated, here's the transcriptions for the images and their translations.

| Japanese | Translation | Description |
| :--- | :--- |:--- |
|新竹取物語|The New Bamboo Cutter Story|Title screen|
|モリもきをいに (森も気をいに)|Be careful in the forest|Gun smoke|
|食|Food|Seen when typing `HELP` inside the hole|
|ヨイコノ本|Porn|On the vending machine|
|両|Ryo|This game's currency. Seen at various places, mostly above coin slots|
|うけつけ|Receptionist|Used at hospital|
|ゲイにも人権を！|Human Rights for Gays!|Used at protest|
|オカマにも青春を！|Youth for Okama!|Used at protest|
|ゲイバー|Gay Bar|Used in multiple endings|

## Translation Notes

**Spoilers up ahead!**

### Apple and Chill
| Japanese | Translation |
| :--- | :--- |
|◆ありゃりゃ・・、　なんだこれは！<br>　リンゴを　ひやしていたのか。|Oh my, what's this?!<br>Was he chilling an apple

When you help the old man (Fishermen Santa in the Famicom version), he offers you what's on his fishing line. The above line is part of this scenario, and the twist is that an apple is on the line. The translation is janky, so it was originally decided to localize it as "Did he catch an apple?". This was changed at the last minute for the following reasons:
1. If you enter the pond in-game, it's revealed it is indeed at a very cold temperature. So this line serves as a hint.
2. The in-game CG reveals the line was intentionally tied at the stem, without the presence of a hook.
3. Apparently, you're supposed to keep apples in cold temperatures to keep them fresh. The more you know.

### I Wish There Were Still Dinosaurs
| Japanese | Raw Translation | Translation |
| :--- | :--- | :--- |
|◆クライ性かくね。　そんな、　キョウリュウなんて　出て来ませんよ。|That's pretty dark. Dinosaurs don't exist.|It's kind of dark, but no scary dinosaurs will pop out.|

You get this line when you look at the lake or safe. This is the best way we could make sense of this line.

### Momotaro
| Japanese | Raw Translation | Translation |
| :--- | :--- |:--- |
|◆オシリを　うかべて　ドンブラコ、　ドンブラコ。|There's a butt floating. Donburako, Donburako.|You float downstream, ass up. \*Glub\* \*Glub\*|

Donburako is an onomatopoeia for a heavy object bobbing up and down in a body of water. It's most famously used in the Japanese folk tale *Momotaro*, as this game makes references to.

### Always Ask a Woman Her Age
With the Japanese input option, the input "IKUTSU" is part of a pun. It is both a polite way of asking someone's age and asking how much. When prompted with this input, Saeko responds with “There's two sugar cubes in this tea.” There isn't an English input alias here. For this translation, the input option selection was dummied out, and the input mode is set to English.

### Apple Starr
| Japanese | Translation |
| :--- | :--- |
|◆オリンゴ、　コロリン、　スットン、　トン。|Oringo, Kororin, Sutton, Ton.|
|◆トックリ、　コロリン、　スットン、　トン。|Tokkuri, Kororin, Sutton, Ton.|

These lines are used when you throw away the apple and saké respectively. The exact meaning behind these lines is unclear but is mostly likely a Omusubi Kororin reference.

## Game Tips
**Spoilers up ahead!**

> I had a really terrible time at it last time I played. It took me 20 minutes to climb the tree. What the fuck?! The old man gave me one hell of a scare! I thought he shot me. Wtf? The monkey is an okama?? What does this mean? What is this game on?

—marklincadet, 2023

The game is as obtuse as you would expect for a game from 1984. Here's some tips to make the game experience more pleasant.

### Casing
When typing commands, make sure to have capslock on. Commands mostly require words and letters in all capital letters.

### Engrish Inputs
Unlike the Famicom game, this is a text adventure game, so there's no menu options. As you can imagine, the entry is finnicky, especially in English. The original game came with an option for English input. Some of the input is Engrishy, but it works surprisingly well all things considered. This translation cleans up the input for the most part. Here's some that I didn't fix:

* `DO KISS`
	* To kiss someone
* `DOWN`
	* Climb down. `GO DOWN` also works.
* `SHAKEHAND`

### Movement
The arrow keys are an alias for compass directions. For example, inputting the up arrow key will print "North". Please refer to the translated manual included with this translation release for more information on the input. Please note the manual has details on the dummied out language options.

### Score
Unlike the Famicom port where it increments your score for certain milestones, the PC versions calculate your score at the very end. It's calculated in obtuse BASIC code, but basically the choices you make influene your score. The difficulty you choose is one such factor that influences your score.

### Difficulty
At the beginning of the game, there's an option for game difficulty. It mainly effects the mini-games. On disk 1's minigame, if you lose, it affects how long it takes to die. In disk 2, it increases the difficulty. Having the pot in your inventory also increases the difficulty, for whatever reason.

### Disk 1 Mini-Game
This mini-game is pretty difficult, especially on high clockspeeds. However, if you lose, it's a slow death. You have to do a special sequence at the hospital to recover from the loss.

### Open-Ended
On both disk sides, there's branching paths you can take. On disk 1, you have the option of going left or right; the cave and cabin respectively. You can either finish one path or the other, but not both. The right path also has a branching path: if you take 10 actions in the cabin, you can skip the maze sequence. On disk 2, at the end of the game, you have the option to destroy the boulder with 20 strikes with the pickaxe or go right to a hidden passage.

### The Dark
Doing ten actions in a dark area will result in being able to see in the dark. No match or candle required.

## Changelog
* 2023 December 22nd: 1.1
    * Text tweaks and bug fixes
* 2023 December 4th: 1.0
    * Initial release

## Credits

### Main Team
* FCandChill
    * ASM work
    * Utilities
    * Localizer
    * Proofreader
* CounterDiving
    * Translation
* ppltoast
    * Tester
    * Game documentation

### Support
* Lazermutt4
    * Kanji identification
* Her-saki
    * Spot-translations

### Beta Testers
* ppltoast
* divingkxt
* marklincadet
* missilelawnchair
* witchyummy
* kanjicrt
