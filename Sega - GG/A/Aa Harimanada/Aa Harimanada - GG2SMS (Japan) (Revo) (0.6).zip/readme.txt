patch by Revo:  http://www.slevinproduction.com/mastersystem/


- The down arrow of the second controller is Start.