GG Aerial Assault V1.0 Conversion by BcnAbel76 - 2017-01-14

* Full palette conversion 
* Must patch original V1.1 version rom 
* Start is 2nd controller down arrow. (In future it can be remapped to button 1, this game only use 1 or 2 to fire) 
* Fixed Checksum 
* Left Column Blank active 

