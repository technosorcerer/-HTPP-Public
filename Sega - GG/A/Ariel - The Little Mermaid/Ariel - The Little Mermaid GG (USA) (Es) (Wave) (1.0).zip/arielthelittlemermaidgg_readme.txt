Ariel - The Little Mermaid (Game Gear)
Traducci�n al Espa�ol v1.0 (24/02/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ariel - The Little Mermaid (U) [!].gg
MD5: e786fb76fb3808a7b4906aa3ba9ff1a7
SHA1: d2f1b95a6d0a2cacd93ed307a5a6576f954a7d56
CRC32: 97e3a18c
262.144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --