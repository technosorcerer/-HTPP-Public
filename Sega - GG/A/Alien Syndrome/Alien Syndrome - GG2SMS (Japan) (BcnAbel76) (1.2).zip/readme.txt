Alien Syndrome ( Game Gear Version ) V1.0 GG2SMS by BcnAbel76 - 2016-12-23

* This version differs Master System version 
* Start is "Down" Arrow 2nd Controller 
* Full palette conversion 
* Fixed checksum 
* Work in real hardware