Ax Battler: A Legend of Golden Axe V1.0b GG2SMS Conversion by BcnAbel76 2016-09-13

- GG ports removed 
- Run in Master System real hardware 




Ax Battler: A Legend of Golden Axe V1.0 GG2SMS Conversion by BcnAbel76 2016-09-11

- "Down Arrow" 2nd controller is START/PAUSE 
- Game Gear to Master System Palette Conversion Full 
- Minor garbage in some stages 
- 100% Playable 
- Fixed Checksum for real hardware compatibility 
- Fixed internal data, now it's a Master System ROM 



I try to patch Japanese Rom but it doesn't work because It's another game internal version. If japanese people tell me then I try to create a patch for them 