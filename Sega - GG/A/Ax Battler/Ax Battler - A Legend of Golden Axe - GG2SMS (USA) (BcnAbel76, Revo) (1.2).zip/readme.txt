Ax Battler: A Legend of Golden Axe V1.0 GG2SMS 2016-09-11

- "Down Arrow" 2nd controller is START/PAUSE 
- Game Gear to Master System Palette Conversion Full 
- Minor garbage in some stages 
- 100% Playable 
- Fixed Checksum for real hardware compatibility 
- Fixed internal data, now it's a Master System ROM 

Conversion by BcnAbel76 

I try to patch Japanese Rom but it doesn't work because It's another game internal version. If japanese people tell me then I try to create a patch for them 