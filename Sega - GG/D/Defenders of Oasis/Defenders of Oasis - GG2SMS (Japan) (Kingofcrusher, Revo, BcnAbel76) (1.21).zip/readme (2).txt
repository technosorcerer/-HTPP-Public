Defenders of Oasis Master System hack
Post Posted: Wed Mar 21, 2012 3:11 am
I spent the day getting Defenders of Oasis to run on a Master System. I'm mostly pleased with the result, but just in case I lose interest in this I figured I'd post what I had finished so far. 

Here's what's done- 
1) Inserted a new palette routine that takes the current GG palette and converts it to SMS so colors look nice. 
2) Fixed sprite XY bounds checking so that sprites display on full screen instead of getting cropped at GG's borders. I think I found all of these, but there might be more some where. 
3) GG's start button (for menu) is mapped to the SMS's pause button. 
4) Added the ability to hold button 2 during a battle to speed up text (this makes a HUGE difference, battles get tedious fast without it). 
5) Halfway fixed the menu screen to not display any junk. 

Things I still want to do- 
1) Fix the areas outside a map's XY boundaries to display black tiles instead of junk or looping around like they do now. 
2) Map start button to 1+2 for people who don't have a controller with a pause button. This is easy, I just forgot to do it and I'm too tired right now :) 
3) Fix the damn battle screen and menu to not display junk outside the GG's screen border. 

Anyway, if anyone tries it on real hardware let me know if it works. I didn't do anything weird so I don't see why it wouldn't, but you never know. 
-Steve / kingofcrusher