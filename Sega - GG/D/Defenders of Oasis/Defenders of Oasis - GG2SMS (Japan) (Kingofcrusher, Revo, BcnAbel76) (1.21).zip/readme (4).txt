!!Defenders Of Oasis GG2SMS v1.2 patch by BcnAbel76 - 2017-05-01

- Before versions was writting to fast VDP registers and makes game has graphical and palette conversion issues in Master System real hardware, not in Megadrive. (Thanks Calindro ;) )

- Redone palette conversion and restoring some necessary old code

- Now game works 100% in MASTER SYSTEM real hardware

- Start is now, with master system pad, push twice button "2", with megadrive pad, push Start button. (GREAT GAMEPLAY!!!!)

- Removed Start mapped to Pause Button, worst gameplay

- Swap Stereo effects port to PSG

!!Defenders Of Oasis GG2SMS v1.1 patch by Revo - 2014-12-14
* Defenders of Oasis is working on real hardware by deleting GG ports and fixing the checksum. 
* When using a ROM cart, the SRAM emulation lets saving work.  With repro carts, the problem now is about the 8ko extra memory for saving. Impossible to run a new game, just continue and then you have no save so you can't play at all. 
* Some palette / graphic issues.

!!Defenders Of Oasis GG2SMS v1.0 patch by kingofcrusher - 2013-03-21
* Inserted a new palette routine that takes the current GG palette and converts it to SMS so colors look nice. 
* Fixed sprite XY bounds checking so that sprites display on full screen instead of getting cropped at GG's borders. I think I found all of these, but there might be more some where. 
* GG's start button (for menu) is mapped to the SMS's pause button. 
* Added the ability to hold button 2 during a battle to speed up text (this makes a HUGE difference, battles get tedious fast without it). 
* Halfway fixed the menu screen to not display any junk. 