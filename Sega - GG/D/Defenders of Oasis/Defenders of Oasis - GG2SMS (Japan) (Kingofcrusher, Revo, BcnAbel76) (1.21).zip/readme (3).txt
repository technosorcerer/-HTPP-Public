v1.1 - Revo
Defenders of Oasis is working on real hardware by deleting GG ports and fixing the checksum. 

The problem now is about the 8ko extra memory for saving. Impossible to run a new game, just continue and then you have no save so you can't play at all. 


v1.0 - kingofcrusher
1) Inserted a new palette routine that takes the current GG palette and converts it to SMS so colors look nice. 
2) Fixed sprite XY bounds checking so that sprites display on full screen instead of getting cropped at GG's borders. I think I found all of these, but there might be more some where. 
3) GG's start button (for menu) is mapped to the SMS's pause button. 
4) Added the ability to hold button 2 during a battle to speed up text (this makes a HUGE difference, battles get tedious fast without it). 
5) Halfway fixed the menu screen to not display any junk. 

http://www.smspower.org/forums/viewtopic.php?t=13652