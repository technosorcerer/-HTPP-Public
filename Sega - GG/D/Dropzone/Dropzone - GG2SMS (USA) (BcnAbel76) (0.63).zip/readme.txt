DropZone V0.63 GG2SMS Conversion by BcnAbel76 - 2017-04-12

- Deleted remanent GG port 
- Updated palette conversion in game and menu (Player 1 Blue, Player 2 Red ) 




Drop Zone V0.6 GG2SMS Conversion by BcnAbel76 - 2017-01-07

- Start is 2nd Controller Down Arrow 
- Most palette routine converted 
- Fixed Checksum 
- Music Funny 
- Very playable 

