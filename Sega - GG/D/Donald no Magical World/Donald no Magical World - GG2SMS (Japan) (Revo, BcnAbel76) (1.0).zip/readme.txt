Donald No Magical World V1.0 GG2SMS Conversion by BcnAbel76 - 2017-04-11
- Fixed game crash. All seems is working ok 



Donald No Magical World WIP v0.1 GG2SMS Conversion by Revo 2016-12-11
- Japanese tile screen by default.
- The game crash during introduction (you just have to press start within 10sec after the Sega screen).
- Start is configured on down player 2.

