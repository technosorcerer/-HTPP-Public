Scratch Golf V1.0 GG2SMS Conversion by BcnAbel76 - 2017-01-08
* Full palette conversion 
* Start is Down Arrow 2nd Controller 
* Fixed Checksum 
* Garbage around screen, game playable 

