WIP v0.2
Start is now configured on 1 for the menu and on Pause in-game. Credits to sverx. 

For the conversion to be finish: 

- move the life bar up corner left. 
- fix the lightning problem on intro and maybe somewhere else. 
- fix the garbage screen on Lucasfilm Games logo screen.



WIP v0.1
patch by Revo:  http://www.slevinproduction.com/mastersystem/

- Down controller 2 is start. 

- Only the Lucasfilm Games logo screen have garbage screen. 

- The lightning of the intro before the game is wrong. 
