patch by Revo:  http://www.slevinproduction.com/mastersystem/

- Down controller 2 is start. 

- Only the Lucasfilm Games logo screen have garbage screen. 

- The lightning of the intro before the game is wrong. 

