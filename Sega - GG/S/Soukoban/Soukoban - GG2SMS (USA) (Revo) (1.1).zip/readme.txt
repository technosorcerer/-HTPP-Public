patch by Revo:  http://www.slevinproduction.com/mastersystem/

- Artifacts on menus and around the screen.
- Start menu not needed.