!!Sonic The Hedgehog V1.1 GG2SMS Conversion by BcnAbel76 - 2017-07-11
*Fixed Tidal Plant Acts 1-2 missing colors
*Fixed transition "no water"-"water"
*Fixed Left Column Blank mixing "no water"-"water"
*Fixed Stage Select Cheat:

(When Knuckles appears to steal the emeralds during the opening demo, hold [u] and press 2Player [d] when he is over the third emerald (taking it or not). A ring sound will confirm the code. Start the game and the Stage Select screen will appears )

!!Sonic The Hedgehog V1.0 GG2SMS Conversion by BcnAbel76 - 2017-06-23
*Automatic palette conversion implemented ( For example: Emeralds now is showing correct )
*[1] Button is Start/Pause and [2] Button is Jump
*Blank routines to delete most garbage
*Swap Stereo effects port to PSG
*Left Column Blank active, must to detect game stage to run ok
*HUD moved top left and HUD Ring animation corrected in TIME ATTACK mode
*Activated "3D STAGE" option in main menu ( You can practice to collect 80 rings )
*Some colors adjusted manually
*Corrected Demo Mode
*Corrected Good Ending bad graphics
*Added "SMSPOWER" to credits

Not working or not 100% (hardware differences):

*Good Ending colors does not match with game gear version, but engine is sharing info betwen 3D stage and good ending, for now it is the best I can do it, looks very very well ;)
*Low garbage in some Title Stages
*Stage Select is not working for Start Button hack, really I think it is no problem because you need to collect all emeralds to complete game, using this option you never complete it
*Rest is all ok!