patch by Revo:  http://www.slevinproduction.com/mastersystem/

- The down arrow of the second controller is Start.
- Problem with menu screen.
- Only ''Duel'' mode work, not ''Strory" mode.
- Artifacts on menus and around the screen.