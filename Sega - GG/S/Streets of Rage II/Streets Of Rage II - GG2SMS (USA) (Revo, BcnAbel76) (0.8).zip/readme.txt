Game Gear to Master System Conversion.

Apply IPS Patch to "Bare Knuckle II ~ Streets of Rage 2 ~ Streets of Rage II (World).gg"


Bare Knuckle II~ Streets of Rage II (World) 2PLAYERS MODE V0.8 GG2SMS 

Changelog:

- Updated Player 2 controller code, now just play perfect as Player 1 !!!
- Updated scroll in Level 6: ( Elevator sequence & Final Battle )
- Hidden area in Elevator Sequence Level 6
- Sorry Player 2 can not Pause game if Player 1 is dead, game is looping and broken
- Moved backgrounds and centered it.
- Moved enemies in level 1 now are showing ok when coming out blinds
- Updated wrong tile in Level 3


And remember:

- START is mapped to PAUSE Button 
- 2 Players Cooperative FIGHT VS 3 ENEMIES!!! 
- Game is set to English by default, logo shows STREETS OF RAGE II


Hack limitations:

- When new level is loaded first stretch is off or wrong tiled, it is needed to screen advance in Master System resolution
- Items/Boxes can hit before appearing because all background is moved with offset and data is matching extended ratio, I moved all to fit with moved background, please attack them when appearing ;) 


CoNvErSioN By BcnAbel76
