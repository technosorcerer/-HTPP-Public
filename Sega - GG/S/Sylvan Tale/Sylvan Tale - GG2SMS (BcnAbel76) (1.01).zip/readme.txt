Sylvan Tale V1.0 GG2SMS Conversion by BcnAbel76 - 2016-09-20

- "Down Arrow" 2nd controller Start/Pause 
- Full palette conversion 
- GG ports removed 
- Now is a Master System Rom 
- Game playable 
- Garbage arround screen 
- Apply patch to Japanese release or Japanese translated to English release 

