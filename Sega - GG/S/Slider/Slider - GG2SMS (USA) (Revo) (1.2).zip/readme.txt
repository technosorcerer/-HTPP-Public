patch by Revo:  http://www.slevinproduction.com/mastersystem/

- Start is configured on button 2.