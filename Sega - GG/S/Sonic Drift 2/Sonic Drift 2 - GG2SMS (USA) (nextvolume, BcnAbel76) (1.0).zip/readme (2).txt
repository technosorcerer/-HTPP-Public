Sonic Drift 2 SMS readme 2009/07/05 version
-----------------------
This is a quick conversion of Sonic Drift 2 from the Game Gear to the Master System.

NOTE: The only difference between this version and the one from June 1st is that the ROM checksum
      has been fixed, and it will boot with US/European BIOSes.

The palette uploading routine has been totally rewritten, and the title screen now
checks if 1 (Start) is pressed, instead of Game Gear's Start.

Sonic Drift 2's races already spanned all the screen, but on the Game Gear,
they were not shown completely. On the Master System, they are, which can
lead to the occasional glitch.

Bugs:
- Can't exit demo mode (you have to wait for it to finish)
- Status is shown in the middle of the screen during races
  (this requires much hacking to change)
- Some garbage is shown in the top right part of the screen
  during races
- Some things look like they're cut in some screens
  This happens also because Sonic Drift 2 wrote "useless" stuff
  in the parts of the tilemap not shown on screen.

> Bugs due to hardware limitations <
- Can't pause in a race (due to lack of buttons)
- Colors do not appear as they were meant to be often.
  Shades are "scaled down" in precision, due to colors being 12bit on the Game Gear
  (which has a total of 4096), instead of 6bit as on the Master System
  (which has a total of ONLY 64). The difference is obvious. Most things look fine, though.

Comments? Questions? Email them to tails92 at gmail dot com
I'd like if someone tried this on a REAL Master System, which I don't have.
A Megadrive with a pass-through would be good as well.

For a new version, check http://tails92.sepwich.com

- nextvolume, July 5th 2009