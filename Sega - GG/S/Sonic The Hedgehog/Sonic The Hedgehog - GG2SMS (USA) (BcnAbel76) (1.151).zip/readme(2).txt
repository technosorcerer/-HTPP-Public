Sonic The Hedgehog V1.0 GG2SMS - Conversion by BcnAbel76 - 2017-03-26

- Full palette conversion 
- Down Arrow 2nd Controller is START (For now) 
- GG ports removed 
- Fixed Checksum 
- Please apply patch to original V1.1 game gear rom 

