Sonic The Hedgehog V1.151 GG2SMS SMSStyle Edition Conversion by BcnAbel76 - 2017-04-07

- Added SMSStyle Edition V1_151 GG2SMS  
http://www.smspower.org/forums/16582-FINISHEDSonicTheHedgehogGameGearSMSStyleEdition

- v1.12 Regular edition also included



Sonic The Hedgehog V1.12 GG2SMS Conversion by BcnAbel76 - 2017-04-07

- Fixed SEGA Voice at Init Logo Screen



Sonic The Hedgehog V1.11 GG2SMS Conversion by BcnAbel76 - 2017-03-30

- Fixed underwater colors in Laberynth Zone, Acts 1,2,3 



Sonic The Hedgehog V1.1 GG2SMS - Conversion by BcnAbel76 - 2017-03-28

- START is "1" Button 



Sonic The Hedgehog V1.0 GG2SMS - Conversion by BcnAbel76 - 2017-03-26

- Full palette conversion 
- Down Arrow 2nd Controller is START (For now) 
- GG ports removed 
- Fixed Checksum 
- Please apply patch to original V1.1 game gear rom 

