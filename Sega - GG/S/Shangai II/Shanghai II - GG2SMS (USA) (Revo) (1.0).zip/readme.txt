Shanghai II v1 by Revo - 2016-12-09

Button 1 & 2. Garbage screen up screen in-game. 

Sometimes crashing on the wait screen on Meka, no problem with Emulicious. Should work on real hardware.