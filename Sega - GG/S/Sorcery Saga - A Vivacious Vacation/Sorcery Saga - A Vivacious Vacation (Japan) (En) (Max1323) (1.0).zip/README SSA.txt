"Sorcery Saga A: Vivacious Vacation"
Traducción al Español Ver. 1.0 (16/02/2024)
por Max1323 (Traducciones Max1323).
Basada en la gran traducción de Supper.
---------------------------------------------------
Descripción:
Las vacaciones comenzaron para Arle por lo que decide ir a visitar
a su abuela que vive al otro lado del Bosque de las Hadas, pero en
el camino, Arle se encuentra con Satán que está desforestando el
bosque para construir un parque de diversiones.

Desarrollado: Compile
Publicado:    Compile
Lanzamiento:  24/11/1995 (JAP)
---------------------------------------------------
Acerca del proyecto:
-La traducción fue hecha gracias a las herramientas 
creadas por Supper, filler (Traducción) y TheMajinZenki (Traducción).

-La mayoría de los textos están traducidos. Se agregaron
los caracteres españoles.

-Se traducieron algunos gráficos.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS (PC)
Utilizar UniPatcher (Android)
Utilizar Rom Patcher JS (Parcheador Online):
https://www.romhacking.net/patch/

Archivo IPS
Madou Monogatari A - Dokidoki Vacation (Japan).gg
File Size     512 KB
File MD5      AB0D1EB20AC63A984D874A885CA2588D        
File SHA-1    C027AA76FE0E09A2D1B982EEA0DF2C8B687AADF7
File CRC32    7EC95282