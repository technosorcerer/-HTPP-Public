Shining Force Gaiden JAP V1.0 GG2SMS Conversion by BcnAbel76 - 2017-01-29

* Full palette conversion 
* 2nd controller "Down" arrow is START 
* Deleted down blank lines 
* Fixed Checksum 
* Backup memory needed to store data progress 
* Japanese 

