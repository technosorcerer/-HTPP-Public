Shining Force Gaiden - Final Conflict JAP V1.0 GG2SMS Conversion by BcnAbel76 - 2017-01-28

- Adapted compatible hacking with fan translation 
- Full palette conversion 
- 2nd controller "Down" arrow is START 
- Deleted down blank lines 
- Fixed Checksum 
- Backup memory needed to store data progress 
- Japanese 

Shining Force Gaiden - Final Conflict ENG V1.0 GG2SMS Conversion by BcnAbel76 - 2017-01-28


- Idem in English 
- Credits to translation go to Shining Force Central 
- Hard work to relocate my data code, making compatible with fan translation ;) 


