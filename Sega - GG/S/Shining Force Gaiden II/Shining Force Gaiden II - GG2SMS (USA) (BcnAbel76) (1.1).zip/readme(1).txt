Shining Force II - The Sword of Hajya ENG V1.0 GG2SMS Conversion by BcnAbel76 - 2017-01-28
* Full palette conversion 
* 2nd controller "Down" arrow is START 
* Deleted down blank lines 
* Fixed Checksum 
* Backup memory needed to store data progress 
* English 
----
Shining Force Gaiden II JAP V1.0 GG2SMS 
* Idem in Japanese 
(You must apply patch to correct rom, game is the same, but internal rom data differs, Gaiden 2 for Japanese and Sword of Hajya for English) 



