!!Shining Force II - The Sword of Hajya ENG V1.1 GG2SMS Conversion by BcnAbel76 - 2017-06-29
*Master Everdrive compatible
*START mapped to Megadrive pad "Start" button OR Master System pads Player 2 "Down"
*Deleted upper garbage in animations, really this game is getting very very low garbage

For save game with Master Everdrive:
(THIS IS NOT A BUG GAME, for now Everdrive OS7 or OS8 is not correctly autosaving and delete file)

*You need OS V5 version!!!
*Load manually SRAM, first time you can for example create SRAM file in Emulicious, only entering your name, then save it into SD folder SAVES
*Load game and continue in menu your data progress
*For save, remember you need EGRESS magic to enter save data and advance a bit in game history. When you see "Your adventure has been saved" then switch off system, if you continue your data will be corrupted !!!
*Init system and go to Tools/Save SRAM, select your backup file to SAVE your progress
*Next time you can continue without problems