Game Gear to Master System Conversion.

Apply IPS Patch to "Bare Knuckle ~ Streets of Rage (World).gg"


Bare Knuckle ~ Streets of Rage (World) 2PLAYERS MODE V0.6 GG2SMS

Changelog:

- Updated Player 2 controller code, now just play perfect as Player 1 !!!
- Updated MR.X sequence, ( Door sequence & Final Battle )
- Player 2 can Pause game if Player 1 is dead
- Moved backgrounds and centered it, (Points Screen must to be not centered allowing screen advance in gameplay)
- Moved enemies in level 1 now are showing ok when coming out blinds
- Updated wrong tile when game reboots

Hack limitations:

- When new level is loaded first stretch is off or wrong tiled, it is needed to screen advance in Master System resolution

And remember:

- START is mapped to PAUSE Button 
- You need in Select Menu to init 2P mode pushing PAUSE (START) 
- 2 Players Cooperative FIGHT VS 3 ENEMIES!!! 
- Game is set to English by default, logo shows now STREETS OF RAGE 

CoNvErSioN By BcnAbel76
