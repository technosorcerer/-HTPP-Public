Kishin Douji Zenki Game Gear Translation

Contents:

1. Foreword

2. Game description

3. Translation notes

4. Hacking notes

5. Disclaimer

6. Staff and special thanks

-----------------------------------------------------------------------

1. Foreword

This is an English patch for Kishin Douji Zenki for the Game Gear. This is a popular anime/manga series that spawned a few games for various platforms (one of the SFC games got fan-translated, everything else is left in Japan). They're usually platformers and/or fighting games/board games of various description. This one is the former - a rather typical platformer for the era with nice visuals and cutscenes. We hope you enjoy our efforts of bringing it to you in English!

If you have any comments/suggestions regarding this translation, please contact one of the people who worked on it. Everyone can be easily found on the RHDN forum.

2. Game description 

You play either as Chiaki or Zenki, except for the boss battles where Chiaki summons Zenki's true form. The game is largely a platformer with various staples of the genre - bottomless pits, spikes and enemies you need to deal with to advance and beat the game. Each character plays somewhat differently, with Zenki being faster, but unable to use magic like Chiaki. The game isn't very long or difficult, but it has nice visuals and sounds. Overall, it should likely be regarded as one of the best GG platformers.

Also, it's important to mention that each character can utilize slightly different routes, so there's an element of replayability to the game, by getting through various obstacles specific to that one character.

3. Translation notes

(from TheMajinZenki): Ironically, I didn't know much about this series before doing this translation, except for some snippets and bits of info. In general it wasn't a difficult translation, but some of the names/terms can be interpreted in more than one way, seeing that there isn't that much data on them in English. Also, the story in this game differs somewhat from that in the manga/anime, with different events taking place at different times.

The untranslated bits are: Zenki's transformation screen (it's the same as in the manga/anime - and originally written in Sanskrit, too, not in Japanese, to evoke mysticism), the kanji on the elemental orbs ("godai" philosophy derived from Buddhism - no space to fill them in) and the kanji one boss (Hiki) throws at you, most of which being attack names (which would likely look silly in English, and barely readable, just like the kanji itself). 

4. Hacking notes 

(from Supper): I came to this project as I was wrapping up work with Filler on a translation of the Game Gear Magic Knight Rayearth game. cccmar asked if I'd be interested in another Game Gear title and, since I'd taken the time to write Game Gear tools and libraries for MKR, I figured I might as well get some more use out of them. I reused a lot of code from that project for this one, so it went pretty quickly -- or at least, a few weeks sure feels quick compared to the months Rayearth wound up taking.

The hacking work for this game was mostly straightforward. The game engine is more elaborate than I would have expected for a licensed platformer: it implements some fairly sophisticated multithreading, and the cutscenes run on a robust scripting system that I had to write a disassembler/assembler for (which formed the bulk of my workload for the project). Once the assembler was done and the text printing patched to use four lines instead of two, the rest was basically mundane and consisted mostly of adjusting delay commands to account for the longer English strings.

You might notice that this game has a couple of voice samples that have been subtitled for the translation. It's a nice touch to have, and thanks to the full-featured scripting system, it was actually very easy to implement. It's a nice change of pace from puzzling over how to subtitle CD audio tracks for PC-Engine CD games.

I somehow also ended up doing the art edits on this project (is there some way to get real artists to work on these things??). Fortunately, that mostly just meant hand-cleaning text generated from fonts to make it look decent at a low resolution. Turns out Gentium Italic can go a long way if you try.

I'd never heard of Kishin Douji Zenki before doing this, and even having read the script of the game several times, I couldn't actually tell you what it's about. Good thing I wasn't doing the script editing this time!

Anyway, thanks to cccmar for putting this project together, TheMajinZenki for translating the script and putting up with my questions, and Filler for editing the script and doing the initial work on the project. Also, shout-outs to SMS Power! for being _the_ 8-bit Sega resource. Hope you enjoy the game.

5. Disclaimer

This translation is a non-commercial and unofficial project which is in no way affiliated with the game creators or distributors. We don't own anything here and have no copyrights.

We release this translation in the form of a patch, not the actual ROM. Please, don't ask us to send you the ROM, or where you can find it - we can't help you with that.

You can redistribute this translation freely as long as you don't ask money for it and include this readme.txt file with it. We don't condone any form of commercial redistribution. Please, keep that in mind.


6. Staff:

Supper        - hacking, tools (coding)

TheMajinZenki - lead translator

Filler        - translation check

cccmar        - testing/initial proofreading

Special thanks go to:

- the ROMhacking.net forum for hosting our patch

- the Sega community - especially SMS Power for being a great resource for hackers and casual gamers alike
