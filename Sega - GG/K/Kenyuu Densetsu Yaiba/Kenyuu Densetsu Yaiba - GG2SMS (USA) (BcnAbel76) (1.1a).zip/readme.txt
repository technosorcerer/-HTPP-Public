Kenyuu Densetsu Yaiba V1.0 GG2SMS Conversion by BcnAbel76 - 2016-12-09

* "Down Arrrow" 2nd controller is Start 
* Full palette conversion 
* Garbage around screen 
* Fixed checksum, master system rom 
* Playable 