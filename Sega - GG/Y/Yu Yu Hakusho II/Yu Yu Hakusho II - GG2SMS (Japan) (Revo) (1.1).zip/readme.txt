patch by Revo:  http://www.slevinproduction.com/mastersystem/

- Artifacts on menus and around the screen.
- There is garbage screen when you select your player
- The down arrow of the second controller is Start.