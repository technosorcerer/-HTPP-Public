Judge Dredd V1.0 GG2SMS conversion by BcnAbel76 - 2016-12-23

* Start is "Down" Arrow 2nd Controller 
* Full palette conversion 
* Fixed checksum 
* Work in real hardware