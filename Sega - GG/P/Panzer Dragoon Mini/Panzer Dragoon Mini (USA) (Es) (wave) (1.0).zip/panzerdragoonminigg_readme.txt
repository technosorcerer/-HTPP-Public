Panzer Dragoon Mini (Game Gear)
Traducción al Español v1.0 (07/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Panzer Dragoon Mini (J) [!].gg
MD5: 4d0d6d25dfef7e1a509d828f157d515f
SHA1: c1498f68acb234f46ab6f443f484a48ebd183f0f
CRC32: e9783cea
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --