patch by Revo:  http://www.slevinproduction.com/mastersystem/

I couldn't adapt Vingazole conversion palette code on this game, but like I wanted a real pinball game for Master System so bad, I changed colors one by one. The result is that there is some wrong fading between 2 screens. 

Start not needed.