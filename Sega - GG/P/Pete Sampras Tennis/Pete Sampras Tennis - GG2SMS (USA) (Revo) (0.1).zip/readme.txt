Pete Sampras Tennis WIP v0.1 by Revo - 2015-11-23

* The colors conversion code only work for the menu. 
* In-game I had to change the colors manually so every field have the same color. 
* Wrong color on Codemaster splash screen and on Map screen. 
* I had to delete one tile in-game to limit garbage screen, it's the orange letter ''D''. 
* Start configured on button down player 2 (only needed to make pause in-game).