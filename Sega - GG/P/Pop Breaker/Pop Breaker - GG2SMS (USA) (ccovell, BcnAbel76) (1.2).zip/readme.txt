Pop Breaker V1.2 GG2SMS Conversion by BcnAbel76 - 2017-01-23

* Restored Master System real hardware compatibility 




Pop Breaker GG->SMS Patch V1.1 by Chris Covell - 2005-02-21

Hi, folks. Chris Covell here.
This is an IPS patch that converts a Pop Breaker ROM for the Game Gear into a ROM that will work on the Sega Master System. It is my first such hack.
To apply the patch, you need the original Pop Breaker (J) GG ROM, and an IPS patching utility (go find it yourself). Apply the patch as per the instructions, and don't forget to rename the ROM extension to ".SMS"! ;)
Since the SMS doesn't have the GG "Start" button, I've remapped it to the "Pause" button on the SMS power base. Or you can also press buttons 1+2 together to start the game. HOWEVER, pressing 1+2 together when the game is paused is the key for the self-destruct mechanism in Pop Breaker. Be careful!
If you notice any errors or problems with the patch, please e-mail me at chris_covell@yahoo.ca. Feel free to visit my homepage at www.zyx.com/chrisc
-- Version 1.1 of this patch fixes the Sega Checksum so that it may work on a real SMS.