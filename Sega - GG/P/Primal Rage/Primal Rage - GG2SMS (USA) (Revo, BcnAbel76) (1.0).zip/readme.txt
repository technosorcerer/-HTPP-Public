Primal Rage V1.0 GG2SMS Conversion by BcnAbel76 - 2017-03-30
* Fixed game. All seems to work fine. 
* ( Game is not the best fighting game, but ... ) 

----

Primal Rage v0.1 GG2SMS Conversion by R�vo 2017-02-11
*Start configured on down controller 2 (only needed to quit options).
*Pause in-game with Start make crash the game. 
*Special attack of the character Blizzard make reset the game. 
*Most of the time the game crash or reset after a combat is over. 
*Garbage screen lightning in-game.