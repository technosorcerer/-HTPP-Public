Phantasy Star Gaiden 
V1.0 GG2SMS JAP by BcnAbel76 - 2017-02-05
* Full palette conversion 
* 2nd controller "Down" arrow is START 
* Fixed Checksum 
* Left Column Blank active 
* Backup memory needed to store data progress 
* Japanese 

V1.0 GG2SMS ENG by BcnAbel76 - 2017-02-05
* Idem in English 
* Credits to transaltion goes to Dynamic-Designs, Taskforce