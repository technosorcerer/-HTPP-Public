Pac-Man GG->SMS Patch
---------------------

Hi, folks.  Chris Covell here.

This is an IPS patch that converts a Pac-Man ROM for the Game Gear into a ROM
that will work on the Sega Master System.

To apply the patch, you need the original Pac-Man GG ROM, and an IPS patching
utility (go find it yourself).  Apply the patch as per the instructions, and don't
forget to rename the ROM extension to ".SMS"!  ;)

Since the SMS doesn't have the GG "Start" button, I've remapped it to Button 1 on
the SMS controller.  Pac-Man's controls are extremely simple, anyway. ;)

If you notice any errors or problems with the patch, please e-mail me at
chris_covell@yahoo.ca.  Feel free to visit my homepage at http://www.zyx.com/chrisc