patch by Revo:  http://www.slevinproduction.com/mastersystem/

-Start is configured on button 1. 
-Password system not working 'cause of the English patch.