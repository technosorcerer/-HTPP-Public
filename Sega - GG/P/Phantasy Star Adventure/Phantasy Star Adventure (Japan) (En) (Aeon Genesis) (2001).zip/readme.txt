PHANTASY STAR ADVENTURE
ENGLISH TRANSLATION V1.00
Copyright 2001 by Aeon Genesis
http://agtp.romhack.net

ToC

1.About Phantasy Star Adventure
2.Patch History
3.Patch Credits
4.Known Issues
5.Application Instructions

-------------------------------
1.About Phantasy Star Adventure
-------------------------------
PSA is a Game Gear text adventure based on the popular Phantasy Star
mythos. In it, you play an unnamed Agent from Planet Motavia's City of
Knowledge, Paseo, on his vacation to Dezolis to see a friend's new
invention. However, Doctor Miller gets kidnapped and his invention is
stolen; it's up to you to rescue the doctor and get the invention back!

---------------
2.Patch History
---------------
Back in May of 1999, when I was still a fledgling romhacker and a
stupid newbie (yes, even I was a stupid newbie at one point ^_^) there
was a crappy little patch for Phantasy Star Adventure by Spiffmaster
Cow. He included a text script with the game so non-Japanese and non-
Cavespeak readers could play, but it wasn't REALLY a translation, per
se. So I attempted to do the project, and for the longest time, didn't
get any farther than Spiffmaster did :P Somewhere in the summer of '99,
Roto handed me a script dumper for the game, but being the stupid
newbie I was, I didn't know what to do with it and lost it in a format
in early 2000 ^^;; I worked on it halfheartedly at irregular intervals
between then and....

'bout two months ago, Ipkiss showed me where some of the dialogue was.
This was the first major step to seeing the completed project. I
fiddled with it some, on and off, found out how some of the stuff was
stored, and petitioned akujin to make a custom script dumper. Then I
promptly forgot about it ^^; Maybe two weeks ago, akujin hands me a
script dump and explains the REST of the stuff I hadn't quite figured
out yet. Four days later, he hands me a translated script o_O About a
week later, a beta patch is ready and out the door, an another week
later, well, this is what you see :)

---------------
3.Patch Credits
---------------
THE PHANTASY STAR ADVENTURE TEAM
Gideon Zhi - Project leader, lead romhacker
Akujin - Romhacker, translator

SPECIAL THANKS
Spiffmaster Cow - Original patch
Josh Dammier - Original script
Ipkiss - Located the dialogue

--------------
4.Known Issues
--------------
-The passwords do not work. I have never recoded a password system
before, and I have absolutely no clue how they work. If someone would
want to give me a hand with it, I'd appreciate it. For now though, PSA
is short enough that you can play through it in one sitting anyway,
and if you absolutely HAVE to save, just use a savestate.

--------------------------
5.Application Instructions
--------------------------
Make sure to have a backup of your ROM before applying the patch!
Using SNESTool, choose "Use IPS" and follow the onscreen instructions.
