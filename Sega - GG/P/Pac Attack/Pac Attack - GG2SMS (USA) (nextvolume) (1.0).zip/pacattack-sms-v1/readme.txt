Pac-Attack SMS patch
by nextvolume <tails92@gmail.com> (http://unhaut.fav.cc)

First release v1
-------

This is the first release of this patch that allows you to play Pac-Attack, a game released in 1994 by Namco for the Game Gear, on your Master System.

The game works well, and is playable, but there are some small artifacts:
- garbage on the bottom of the title screen
- at the beginning of the game it says "FOR SEGA GAME GEAR"

These issues may be fixed in a newer release; the tilemaps seem to be compressed and I haven't figured the compression out yet.

Moreover, 2 player versus mode is not supported, because it relied on the Gear-to-Gear cable; it won't be possible to select the option in the main menu.

The Game Gear START button is mapped to Button 2 on the Master System, and does what START used to do on the Game Gear (pause, etc.)

The patch applies to a ROM image of the Pac-Attack cartridge; as far as I'm aware only one version exists of it, and it was released in all territories (Japan, Europe and USA).

In this archive other than for the IPS format patch, named `pacattack_sms.ips', you can find the full source code of the injected code snippets that were used to make the patch; this means that if you are technically versed, you can improve the patch yourself.
The Makefile is very simple and easily understood; to build the patch, simply run `make'.
The ROM image must be placed in this directory and named `pacattack_orig.sms'; the patched ROM afte running `make' will be named `pacattack.sms'.
The Makefile assumes you are on a Unix-like operating system; if you are on Windows you can try using MSYS or Cygwin.

The assembler you will need to use is z80asm (http://www.nongnu.org/z80asm/)

inject, fixsum, nop and putstring were written by me (nextvolume), they will respectively inject a code snippet, fix the ROM checksum, insert NOP instructions in the ROM and insert a string in the ROM; do whatever you want with them, but give credit.

Enjoy!

-nextvolume
17th May 2014
