Pengo (Japan) V1.0 GG2SMS Conversion by BcnAbel76 - 2017-03-28

- START is "1" Button 
- Full palette conversion 
- Fixed checksum 
- Apply patch to Japanese Rom 
- For unknown SEGA logo at start is cracked graphics but rest is ok 

( This hack is made by 0, differs from already done none Japanese version, because it includes PopCorn Music !!! ) 

