#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[])
{
	FILE *romFile;
	unsigned int hexAddr;
	unsigned int termChar;
	
	if(argc < 4)
	{
		printf("Usage: putstring <ROM file> <string> <hex addr> [terminationChar (in hex)]\n");
		return EXIT_SUCCESS;
	}
	
	romFile = fopen(argv[1], "rb+");
	
	if(romFile == NULL)
	{
		printf("Could not open ROM file!\n");
		return EXIT_FAILURE;
	}
	
	sscanf(argv[3], "%x", &hexAddr);
	
	fseek(romFile, hexAddr, SEEK_SET);
	fputs(argv[2], romFile);
	
	if(argc >= 5)
	{
		sscanf(argv[4], "%x", &termChar);
		fputc(termChar, romFile);
	}
	
	fclose(romFile);
	
	return EXIT_SUCCESS;
}
