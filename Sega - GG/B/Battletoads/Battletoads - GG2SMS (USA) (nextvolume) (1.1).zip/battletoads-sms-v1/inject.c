#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[])
{
	FILE *codeFile;
	FILE *romFile;
	unsigned int codeAddr;
	unsigned int jumpFromAddr;
	int endOfFile = 0;
	int c;
	
	if(argc < 5)
	{
		printf("inject - Inject code inside Master System/GG ROM (by nextvolume)\n");
		printf("usage: inject <code> <ROM> <code_addr (hex)> <call_from_addr (hex)> [is_call]\n");
		printf("\n");
		printf("Not enough arguments!\n");
		printf("\n");
		printf("Tip: Addresses are 16-bit only. The SEGA Master System uses bank-switching.\n");
		printf("You need to know how bank-switching is set up at the time you want to run\n");
		printf("your injected code, otherwise things won't go well.\n");
		
		return EXIT_SUCCESS;
	}
	
	codeFile = fopen(argv[1], "rb");
	
	if(codeFile == NULL)
	{
		printf("Could not open code file!\n");
		return EXIT_FAILURE;
	}
	
	romFile = fopen(argv[2], "rb+");
	
	if(romFile == NULL)
	{
		printf("Could not open ROM file!\n");
		fclose(codeFile);
		return EXIT_FAILURE;
	}
	
	sscanf(argv[3], "%x", &codeAddr);
	sscanf(argv[4], "%x", &jumpFromAddr);

// Write jump instruction
	fseek(romFile, jumpFromAddr, SEEK_SET);

// If the fifth argument exists, no matter its value, generate a call instead of a jump	
	if(argc > 5)
		fputc(0xCD, romFile);
	else
		fputc(0xC3, romFile);
	
	fputc(codeAddr & 0xFF, romFile);
	fputc(codeAddr >> 8, romFile);

// Inject code
	fseek(romFile, codeAddr, SEEK_SET);
	
	while(!endOfFile)
	{
		c = fgetc(codeFile);
		
		endOfFile = feof(codeFile);
		
		if(!endOfFile)
			fputc(c, romFile);
	}
	
// Close file handles	
	fclose(codeFile);
	fclose(romFile);
	
	return EXIT_SUCCESS;
}
