Battletoads SMS patch v1.1 by Revo
-Less garbage screen. 
-Color of the flickering (when 60Hz) changed.




First release v1 by nextvolume <tails92@gmail.com> (http://unhaut.fav.cc)
-------

This is the first release of this patch that allows you to play Battletoads, a game released in 1993 by SEGA for the Game Gear, on your Master System.

The game works well, and is playable.
There is garbage outside the center of the screen (where the Game Gear screen used to be), but it doesn't affect gameplay.

The Game Gear START button is mapped to Button 1 on the Master System, except during gameplay, where it is mapped to the Pause button.

The patch applies to a ROM image of the European and American version of the Battletoads cartridge.

In this archive other than for the IPS format patch, named `battletoads_sms.ips', you can find the full source code of the injected code snippets that were used to make the patch; this means that if you are technically versed, you can improve the patch yourself.
The Makefile is very simple and easily understood; to build the patch, simply run `make'.
The ROM image must be placed in this directory and named `battletoads_orig.sms'; the patched ROM afte running `make' will be named `battletoads.sms'.
The Makefile assumes you are on a Unix-like operating system; if you are on Windows you can try using MSYS or Cygwin.

The assembler you will need to use is z80asm (http://www.nongnu.org/z80asm/)

inject, fixsum, nop and putstring were written by me (nextvolume), they will respectively inject a code snippet, fix the ROM checksum, insert NOP instructions in the ROM and insert a string in the ROM; do whatever you want with them, but give credit.

Enjoy!

-nextvolume
21st May 2014
