Batman Forever v1 by Wafer 2019-11-15
* Compatible with MD and Saturn pad, supports start button
* Supports pause button and down on controller 2
* Game can be started without start button
* If you are using a 6-button pad, forcing compatibility by holding down Mode when starting up is highly recommended

Controls:

Master System controls are the same as GG, with the following exceptions:

Block: 1+2
Cape Morph: 1+2+up
Exit inventory screen at start of level: 1

MD/Saturn pad controls are the same as a Master System game played with an MD pad, with the following exceptions:

Block: A
Pause: Start
Cape Morph: A+B or A+up

Batman Forever v1 by BcnABel76 2017-01-19
* Start is 2nd controller "down" arrow.
* Adjusted some colors to Master System palette.
* This game no enter in pause mode because it is needed to push Start+1+2 in original, but in hacking for now not possible (next update will take this option).