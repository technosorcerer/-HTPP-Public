Bishoujo Senshi Sailor Moon S v0.2 by Wafer 2019-11-03
* Compatible with MD and Saturn pad, supports start button
* Supports pause button and down on controller 2
* Game can be started without start button

Bishoujo Senshi Sailor Moon S v0.1 by Revo 2017-01-03
* Start configured on button down controller 2.