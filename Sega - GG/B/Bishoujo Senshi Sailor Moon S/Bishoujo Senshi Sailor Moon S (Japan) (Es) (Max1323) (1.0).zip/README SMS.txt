"Bishoujo Senshi Sailor Moon S"
Traducción al Español Ver. 1.0 (11/08/2024)
por Max1323 (Traducciones Max1323).
Basada en la gran traducción de Supper y filler.
---------------------------------------------------
Descripción:
Basada en el manga y anime creado por Naoko Takeuchi.
Es un juego de plataformas de 5 etapas donde podrás 
jugar con Sailor Moon y Chibiusa.
Además cuenta con 4 minijuegos, Picnic de la Bola Luna-P,
Buscar a Tuxedo Mask, Ruleta del Equipo Sailor y Mundo Trivia.

Desarrollado: Shimada Kikaku
Publicado:    Bandai
Lanzamiento:  27/01/1995 (JAP)
---------------------------------------------------
Acerca del proyecto:
-Está versión fue hecha desde cero. No se usó la traducción que
está en Romhacking.

-La traducción fue hecha gracias a las herramientas 
creadas por Supper, ccmar (Testeo) y filler (Traducción).

-La mayoría de los textos están traducidos. Se agregaron
los caracteres españoles.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS (PC)
Utilizar UniPatcher (Android)
Utilizar Rom Patcher JS (Parcheador Online):
https://www.romhacking.net/patch/

Archivo IPS
Bishoujo Senshi Sailor Moon S (Japan).gg
File Size     512 KB
File MD5      33CA01D639AEF0B2FECF2D059175ABBE        
File SHA-1    824E463D0BE5C0E81205A475B5AD7E55C366E486
File CRC32    FE7374D2