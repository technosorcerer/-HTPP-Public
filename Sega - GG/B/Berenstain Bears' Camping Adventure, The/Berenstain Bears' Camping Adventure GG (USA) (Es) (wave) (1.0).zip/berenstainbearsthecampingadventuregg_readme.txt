Berenstain Bears', The - Camping Adventure (Game Gear)
Traducci�n al Espa�ol v1.0 (01/02/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Berenstain Bears', The - Camping Adventure (U) [!].gg
MD5: 0063255819682649ed682a50a0e8a440
SHA1: a35bef59a59df2a6d3dc4b8d3fe2e4cc79464537
CRC32: a4bb9ffb
262.144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --