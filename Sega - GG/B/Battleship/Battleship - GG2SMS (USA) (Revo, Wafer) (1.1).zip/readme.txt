Battleship v1.1 by Wafer 2019-11-03
* Compatible with MD and Saturn pad, supports start button
* Supports pause button and down on controller 2
* Game can be started without start button

Battleship v1 by Révo 2017-01-24
* Start configured on down controller 2.