Barbie Super Model V1.0 GG2SMS Conversion by BcnAbel76 - 2017-01-09
* Full palette conversion 
* 2nd Controller Down Arrow is Start 
* Fixed Checksum 

