Baku Baku Animal (Game Gear)
Traducci�n al Espa�ol v1.0 (27/06/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Baku Baku Animal (U).gg
MD5: 3ff5a4888076e7a5905bc565563c3692
SHA1: f4f31d08e17b9936dea621fef9b38e1cd067bef2
CRC32: 8d8bfdc4
262144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --