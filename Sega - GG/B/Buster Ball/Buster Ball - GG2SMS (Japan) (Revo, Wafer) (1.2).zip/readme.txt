Buster Ball v1.2 by Wafer 2019-11-03
* Compatible with MD and Saturn pad, supports start button
* Supports pause button and down on controller 2
* Game can be started without start button

Buster Ball v1.1 by Revo 2015-12-05
* Sega logo when you start the game.
* No more garbage screen after the first goal (for that I deleted one tile, it's the down part of the number 0 for the score; not a perfect compromise but I think it's way better like that).
* The down arrow of the second controller is Start.