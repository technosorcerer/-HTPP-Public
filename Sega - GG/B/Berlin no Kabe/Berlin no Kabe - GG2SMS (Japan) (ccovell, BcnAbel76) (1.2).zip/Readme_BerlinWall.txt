The Berlin Wall GG->SMS Patch Ver 1.1
-----------------------------

Hi, folks.  Chris Covell here.

This is an IPS patch that converts a Berlin Wall ROM for the Game Gear into a ROM
that will work on the Sega Master System.

To apply the patch, you need the original Berlin Wall (J) GG ROM, and an IPS patching
utility (go find it yourself).  Apply the patch as per the instructions, and don't
forget to rename the ROM extension to ".SMS"!  ;)

Since the SMS doesn't have the GG "Start" button, I've remapped it to the "Pause"
button on the SMS power base.  Button 1 can also be used to start the game on the
title screen.

If you notice any errors or problems with the patch, please e-mail me at
chris_covell@yahoo.ca.  Feel free to visit my homepage at http://www.zyx.com/chrisc
--
Version 1.1 of this patch fixes the checksum for play on a real SMS.