Game Gear to Master System Conversion.

Apply IPS Patch to "Berlin no Kabe (J).gg"


The Berlin Wall (Berlin No Kabe) v1.2 GG2SMS

Changelog:

- START is mapped to PLAYER 1 button "1" and PAUSE Button in Game or Demo Mode
- 2 Players Mode Activated !!!
- Written Player 2 controller code
- Bypassing checkings/data Gear2Gear communication
- Changed Main Menu Option showing now "2P VERSUS START"
- If PLAYER 1 deads can continue pressing PAD1 "1" or "2" buttons
- If PLAYER 2 deads can continue pressing PAD2 "1" or "2" buttons


CoNvErSioN By BcnAbel76