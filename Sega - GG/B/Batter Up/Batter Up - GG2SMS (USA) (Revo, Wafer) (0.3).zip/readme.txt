Batter Up v0.2 by Wafer 2019-11-03
* Compatible with MD and Saturn pad, supports start button
* Supports pause button and down on controller 2
* Game can be started without start button

Batter Up v0.1 by Révo 2017-01-23
* Game also know as Gear Stadium in Japan.
* Start configured on down controller 2.
* Garbage screen around the screen after first shot.