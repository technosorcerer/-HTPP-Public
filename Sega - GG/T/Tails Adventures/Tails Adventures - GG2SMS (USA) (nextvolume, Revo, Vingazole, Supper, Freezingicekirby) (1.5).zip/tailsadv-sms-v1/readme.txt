Tails Adventure SMS patch
by nextvolume <tails92@gmail.com> (http://unhaut.fav.cc)

First release v1
-------

This is the first release of this patch that allows you to play Tails Adventure, a game released in 1995 by SEGA for the Game Gear, on your Master System.

The game works well and is fully playable.
There are some screen artifacts, like the power gauge appearing scrambled on the left side of the screen during gameplay when the power gauge should not be appearing on screen; when it should be appearing on the screen, there is no problem though.

The START button was mapped to Button 2 except during gameplay, where it is mapped to the Pause button.

The patch applies to a ROM image of the Tails Adventure cartridge; as far as I'm aware only one version exists of it, and it was released in all territories (Japan, Europe and USA).

In this archive other than for the IPS format patch, named `tailsadv_sms.ips', you can find the full source code of the injected code snippets that were used to make the patch; this means that if you are technically versed, you can improve the patch yourself.
The Makefile is very simple and easily understood; to build the patch, simply run `make'.
The ROM image must be placed in this directory and named `tailsadv_orig.sms'; the patched ROM afte running `make' will be named `tailsadv.sms'.
The Makefile assumes you are on a Unix-like operating system; if you are on Windows you can try using MSYS or Cygwin.

The assembler you will need to use is z80asm (http://www.nongnu.org/z80asm/)

inject, fixsum and nop were written by me (nextvolume), they will respectively inject a code snippet, fix the ROM checksum and insert NOP instructions in the ROM; do whatever you want with them, but give credit.

Enjoy!

-nextvolume
15th May 2014
