#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
	FILE *romFile;
	unsigned int startAddr;
	unsigned int len;

	if(argc < 4)
	{
		printf("nop - Writes NOPs in ROM (by nextvolume)\n");
		printf("\n");
		printf("Usage: nop <ROM> <start_addr (hex)> <len>\n");
		printf("Not enough arguments!\n");
		return EXIT_SUCCESS;
	}
	
	romFile = fopen(argv[1], "rb+");
	
	if(romFile == NULL)
	{
		printf("Could not open ROM file!\n");
		return EXIT_FAILURE;
	}
	
	sscanf(argv[2], "%x", &startAddr);
	sscanf(argv[3], "%d", &len);
	
	fseek(romFile, startAddr, SEEK_SET);
	
	for(; len > 0; len--)
		fputc(0, romFile);
	
	fclose(romFile);
	
	return EXIT_SUCCESS;
}
