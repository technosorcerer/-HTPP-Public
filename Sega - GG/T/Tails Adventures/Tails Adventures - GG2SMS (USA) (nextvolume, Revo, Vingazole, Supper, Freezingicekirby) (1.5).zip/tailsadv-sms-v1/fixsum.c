#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
	FILE *romFile;
	unsigned int theByte;
	int x;
	unsigned int sum = 0;
	
	if(argc < 2)
	{
		printf("fixsum - Fix Master System ROM checksum (by nextvolume)\n");
		printf("\n");
		printf("Usage: fixsum <ROM>\n");
		printf("Not enough arguments!\n");
		return EXIT_SUCCESS;
	}
	
	romFile = fopen(argv[1], "rb+");
	
	if(romFile == NULL)
	{
		printf("Could not open ROM file!\n");
		return EXIT_FAILURE;
	}
	
	fseek(romFile, 0x7FFF, SEEK_SET);
	theByte = fgetc(romFile);
	
	theByte &= 0xF;
	
	fseek(romFile, 0, SEEK_SET);
	
	switch(theByte)
	{
		case 0xa: // 8kb
			for(x = 0; x <= 0x1FEF; x++)
				sum += fgetc(romFile);
		break;
		
		case 0xb: // 16kb
			for(x = 0; x <= 0x3FEF; x++)
				sum += fgetc(romFile);
		break;
		
		case 0xd: // 48kb
			for(x = 0; x <= 0xBFEF; x++)
				sum += fgetc(romFile);
		break;
		
		case 0xc: // 32kb
		case 0xe: // 64kb
		case 0xf: // 128kb
		case 0x0: // 256kb
		case 0x1: // 512kb
		case 0x2: // 1024kb
			for(x = 0; x <= 0x7FEF; x++)
				sum += fgetc(romFile);
		break;
	}
	
	switch(theByte)
	{
		case 0xe:
			for(x = 0x8000; x <= 0xFFFF; x++)
				sum += fgetc(romFile);
		break;
		
		case 0xf:
			for(x = 0x8000; x <= 0x1FFFF; x++)
				sum += fgetc(romFile);
		break;
		
		case 0x0:
			for(x = 0x8000; x <= 0x3FFFF; x++)
				sum += fgetc(romFile);
		break;
		
		case 0x1:
			for(x = 0x8000; x <= 0x7FFFF; x++)
				sum += fgetc(romFile);
		break;
		
		case 0x2:
			for(x = 0x8000; x <= 0xFFFFF; x++)
				sum += fgetc(romFile);
		break;
	}
	
	theByte |= 0x40;
	
	fseek(romFile, 0x7FFF, SEEK_SET);
	fputc(theByte, romFile);
	
	fseek(romFile, 0x7FFA, SEEK_SET);
	fputc(sum & 0xFF, romFile);
	fputc(sum >> 8, romFile);
	
	return EXIT_SUCCESS;
}

	
	