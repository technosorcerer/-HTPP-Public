Changes in v1.5 - Major "deluxe" update by freezingicekirby 2016-09-17

- The Flicky on the right side of the screen during the intro has been relocated. 

- Some of the terrain during the intro has also been altered to accommodate the above change. 

- The credits screen itself was altered to hide the characters when they walk/fly off the background. 

- Credits background was widened one tile. 

- The text during the credits was updated once again. 

- Tails' graphics were altered slightly. 

Again, thanks to Calindro for helping with some parts of this. Thanks go to Supper, too, who indirectly helped make these credits changes possible with that information he provided to me some months ago! 

As per the usual, all comments and feedback are greatly appreciated!

http://www.smspower.org/forums/16207-TailsAdventureSMSDeluxeUpdateV15




Version 1.4  - Major "deluxe" update by freezingicekirby 2016-09-10

Changes include... 

- Green Island and Cavern Island were moved outwards a bit. 

- The text box on the world map has been repositioned. 

- One dolphin on the world map has been relocated. 

- The palette and some of the graphics inside Tails' House were improved. 

- The HUD can now be seen at all times when pressing the Pause button, correcting an issue unintentionally caused by the GG2SMS patch. 

- The horizon in Polly Mountain 1-3 (Boss Room) has been fixed. 

- The items "Sonic", "Knuckles", and "Fang" have been renamed to "Spin Dash", "Super Punch", and "Lucky Charm". Their graphics were also changed, but they function exactly as before. 

- Updated credits. 


Again, a big thanks to Calindro for helping me out on both moving the doors on the world map and fixing the HUD issue.  http://www.smspower.org/forums/16207-TailsAdventureSMSDeluxeUpdateV15






1.3! Changes include... 

- Completely reworked water in Cavern Island. Now it's solid, and when Tails jumps into any of them, a checkered imitation-transparency effect gets applied. 

- Camera boundary on the right side of the boss room (when you return after defeating him) has been fixed. I forgot to change it last time, apparently. 

- Also, I added a warp tile at the end of the aforementioned boss room, so now if you return to this area for whatever reason, you don't have to trek through the previous two areas to get back to the world map. 




http://www.smspower.org/forums/16207-TailsAdventureSMSDeluxeUpdateV14




Tails Adventure SMS Deluxe Password
You can find the Password version of my patch attached to this comment. It's the most-recent v1.3 patch, though keep in mind that despite it still saying "Load" on the title screen and "Save" within Tails' House, it works like it did before.