Tintin Au Tibet V1.0 Conversion by BcnAbel76 - 2017-01-14

* Full palette conversion 
* Start is 2nd controller down arrow 
* Fixed Checksum 
* Left Column Blank active 

