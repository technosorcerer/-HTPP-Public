Tails Skypatrol v0.3 GG2SMS Conversion by BcnAbel76 2016-12-28
* Deleted down blank lines 
* Fixed Checksum 

Tails Skypatrol v0.2 GG2SMS Conversion by Revo 2016-12-24
*Left column blank active. 

Tails Skypatrol v0.1 GG2SMS Conversion by Revo 2014-05-15
*Artifacts on menus and around the screen.
*The down arrow of the second controller is Start.
*patch by Revo:  http://www.slevinproduction.com/mastersystem/
