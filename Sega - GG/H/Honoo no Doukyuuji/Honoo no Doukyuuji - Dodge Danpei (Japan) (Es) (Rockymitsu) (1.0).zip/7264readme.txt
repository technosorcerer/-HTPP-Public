Gracias por abrir el texto, este es el primer trabajo que veras acerca de este juego, he trabajado en
traducir parte del idioma de origen que tiene el videojuego y corregir varios errores durante el proceso.
hay algunos detalles por ejemplo "kazami" se ve que se llama "kazagumi" pero no es ese su nombre, es simplemente kazami.
es debido a que el juego usa caracteres compartidos, osea, pueden 5 nombres tener el mismo cuadro grafico. gracias!
Prueba el parche ahora, espero lo disfrutes.