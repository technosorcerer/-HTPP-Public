Head Buster (Game Gear) Japanese to English Translation v0.99
-------------------------------------------------------------
Copyright (??) 2005 Chris Covell (chris_covell@yahoo.ca)


What is Head Buster?
--------------------

It's a turn-based strategy game, or as the Japanese reviews call it, a
"1/2 realtime strategy game".  It was released in March 1991 for the Sega Game Gear
system, a nice little system that had relatively poor sales and software support.
(Relative to the GameBoy, of course.)  ;-)

I first played it when, while in Japan, I asked my girlfriend living in another city
to find any GG games and send them to me.  She sent me a game called Head Buster.
At first, I couldn't figure much out (the cartridge was loose.  No instruction manuals
or game explanation), and I disliked strategy games, so I didn't play it much.
But then I understood what each of your robot's body parts and weapons did, and how
to win a match, so I started enjoying this game a lot.  It's fun to pick up and play for
a short while, and is much simpler than most strategy games.  Perfect for a portable system!

The hard part was that it's all in Japanese, so that's why I translated it.


About the Patch
-----------------------------

To apply the .IPS translation patch, make sure you have gotten yourself a ROM of Head Buster
(Usually called Head Buster (jp).gg) and an IPS patching program.  Once you know how to use
the IPS patching program, choose the original .GG ROM as the source file, and my included .IPS
file as the patch.  The end result should be a version of Head Buster translated into English!

You can find out about Head Buster in more detail at my translation page:
http://www.disgruntleddesigner.com/chrisc/HeadBusterEnglish/
Also, please check out my website at http://www.chrismcovell.com

This translation should run correctly, as I have tested it quite a bit.  Everything (except for
a small bit of Engrish) has been translated into English.  If you encounter an error while playing
please let me know!


Translation Info
----------------

To translate the game's text, I made a table (manually!) of the game's Japanese font mapping,
and then wrote in some English text, substituting Roman characters into the game's font space.
I then had to rewrite most of the text pointers since the English text took up quite a bit more
space than the original Japanese.  Fortunately, I had _just_ enough free space at the end of the
ROM to put some rerouted text.  Yes, a 90% hand-made translation.

I want to take the time now to point out deliberately that, although I researched and tried out
about 7 or 8 different "table/pointer/translation" software packages, all of them fell far short
of my expectations.  Some were MS-DOS only, some crashed with some VB or Basic run-time error right
at the beginning, others mangled both input and output tables, and others seemed designed to work
with Super Famicom games only.  So, I had to do it all by hand.  That's quite disappointing.

Anyway, to wrap this up, I'd like to thank T. Kakehata, M. Takahashi, O. Cornut, NCS, and others
who made playing and translating this game a lot of fun.  Bye for now!

Chris Covell 8/15/2005