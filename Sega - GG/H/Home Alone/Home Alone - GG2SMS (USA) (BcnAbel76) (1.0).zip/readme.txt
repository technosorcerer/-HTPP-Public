Home Alone (Game Gear Version) V1.0 GG2SMS conversion by BcnAbel76 - 2016-12-27

* Start is "Down" Arrow 2nd Controller 
* Full palette conversion 
* Fixed Checksum 
* Left blank column active