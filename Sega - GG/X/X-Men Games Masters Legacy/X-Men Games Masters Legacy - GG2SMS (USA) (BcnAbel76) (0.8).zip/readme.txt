X-Men - Gamemaster's Legacy V0.6 GG2SMS Conversion by BcnAbel76 - 2016-12-21

* Start is Down arrow 2nd controller 
* Full palette conversion 
* Fixed checksum 
* Work in real hardware 
* Fixed garbage while jumping 
* Removed background colors loop 