X-Men v0.9 GG2SMS Conversion by Wafer 2020-04-13

* Compatible with MD and Saturn pad, supports start button
* Supports down on controller 2
* If you are using a 6-button pad, forcing compatibility by holding down Mode when starting up is highly recommended

X-Men v0.8 GG2SMS Conversion by Revo 2017-01-07

* Less garbage screen on Title screen and menus.
* Left column blank active.

X-Men v0.7 GG2SMS Conversion by BcnAbel76 2016-12-28

* Deleted down blank lines.
* v0.71 Fix compatibility with real hardware.

X-Men v0.6 GG2SMS Conversion by BcnAbel76 2016-12-20

* Working ok!
* Fixed garbage while jumping.
* Removed background colors loop.

X-Men v0.1 GG2SMS Conversion by BcnAbel76 2016-12-19

* Palette conversion ok.
* Start 2nd down arrow.
* Graphical glitches while jumping.
* Long bar down screen, (may causing problems).