X-Men V0.6 GG2SMS Conversion by BcnAbel76 - 2016-12-20
* Working ok! 
* Fixed garbage while jumping 
* Removed background colors loop 


X-Men v0.1 GG2SMS Conversion by BcnAbel76 - 2016-12-19
*Palette conversion ok
*Start 2nd down arrow
*Graphical glitches while jumping
*Long bar down screen, (may causing problems)