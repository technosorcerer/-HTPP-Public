patch by Revo:  http://www.slevinproduction.com/mastersystem/

- The down arrow of the second controller is Start.
- Artifacts on menus and around the screen.