Lost World, The - Jurassic Park WIP v0.2 by Revo - 2015-11-22

* Some garbage screen deleted. 

* I stop working on the game when I saw the scrolling problem. You will have problem with some text and 3 bosses can't be played. Also the last level with the car is impossible to play.



Lost World, The - Jurassic Park WIP v0.1 by Revo - 2014-08-11

* The down arrow of the second controller is Start. 
* Artifacts on menus and around the screen
http://www.slevinproduction.com/mastersystem/