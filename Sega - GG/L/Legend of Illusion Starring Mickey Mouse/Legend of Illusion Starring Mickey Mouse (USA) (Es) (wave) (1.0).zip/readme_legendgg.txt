Legend of Illusion Starring Mickey Mouse
Traducci�n al Espa�ol v1.0 (11/01/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Legend of Illusion Starring Mickey Mouse
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Legend of Illusion Starring Mickey Mouse
-----------------
Otra aventura de mickey en los 8 bits, con muy buenos efectos y gameplay variado, identico en game gear y master system.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Legend of Illusion Starring Mickey Mouse (U) [!].gg
524.288	bytes
CRC32: ce5ad8b7
MD5: 6d106d9c80b9d0cdc4f555be3c3677d3
SHA1: fa1200fd34a81796222eae97175c2fb72a77e970

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --