Lemmings 2 - The Tribes (Game Gear)
Traducción al Español v1.0 (06/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Lemmings 2 - The Tribes (Unknown) (Proto).gg
MD5: bc7abc4f5c8a35a383eed5a4a94de10b
SHA1: ad0ce8fc8ce9e5ef9b68b76fb7f3eced4245d5c4
CRC32: fbc807e1
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --