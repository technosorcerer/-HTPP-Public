The Legend of Galahad (Mega Drive)
Traducción al Español v1.0 (04/05/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Añadidos caracteres españoles
-Traducidos gráficos de estado
-Guion revisado

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Legend of Galahad, The (USA, Europe).md
MD5: 536e5a1ffb50d33632a9978b35db5df6
SHA1: 3368af01da1f3f9e0ea7c80783170aeb08f5c24d
CRC32: 679557bc
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --