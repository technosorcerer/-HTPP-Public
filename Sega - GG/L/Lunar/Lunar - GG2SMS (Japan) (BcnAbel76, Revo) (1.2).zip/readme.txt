I made conversion, and I surprised, english translation patch crash my moddified ROM. 

Then I remade conversion readdressing my code to do compatible with this great rom hacking translation made in 2009 by Aeon Genesis / SGST 

This game was designed in full resolution, it looks now fantastic in Master System, scrolling well and no garbage. 

English patch + Master System patch = 1024 KB (8 Mbit) + 16Kb Backup 
Japanese patch + Master System patch = 512 KB (8Mbit) + 16Kb Backup 

----------------------------------------------------------------------------------------------------------------

LUNAR: - Sanpo-suru Gakuen / Walking School V1.0 GG2SMS Conversion by BcnAbel76 - 2016-10-01

- "Down Arrow" 2nd Controller Start/Pause 
- Full palette conversion 
- Fixed checksum 
- Japanese or English 
- Coded compatible English Translation 2009 by Aeon Genesis / SGST 
- Master System ROM 
- Working in Real Hardware 
- Funny, very playable 
- Enjoy and apprecite community job 1996-2016 

