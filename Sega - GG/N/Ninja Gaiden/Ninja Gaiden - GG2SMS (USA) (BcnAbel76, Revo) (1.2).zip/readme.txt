Ninja Gaiden v0.01 patch by BcnAbel76

- 2nd controller "Down Arrow" is Start/Pause 
- Only 1st stage, Sega logo, and Main Menu is palette corrected 
- Game playable, garbage around screen 