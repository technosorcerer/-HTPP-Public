Ninja Gaiden v0.02 patch by BcnAbel76 2016-09-07

- Update more palettes, Up screen 2 
- Adjust some colors to Master System 





Ninja Gaiden v0.01 patch by BcnAbel76 2016-09-05

- 2nd controller "Down Arrow" is Start/Pause 
- Only 1st stage, Sega logo, and Main Menu is palette corrected 
- Game playable, garbage around screen 