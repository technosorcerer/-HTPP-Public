Ninku 2 WIP v0.2 by Revo - 2015-11-22

* No more lightning down the screen (didn't finish the game but it should be fine until the end). Had to change the font color of the title screen from blue to black.




Patch by Revo:  http://www.slevinproduction.com/mastersystem/

* The down arrow of the second controller is Start.
* Artifacts on menus and around the screen.