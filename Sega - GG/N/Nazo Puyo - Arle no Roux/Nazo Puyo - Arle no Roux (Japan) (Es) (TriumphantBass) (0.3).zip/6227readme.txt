Puyo Puzzle: Arle's Roux (Nazo Puyo: Aruru no Ru)

With a valid ROM, apply the IPS using a IPS-patching utility.