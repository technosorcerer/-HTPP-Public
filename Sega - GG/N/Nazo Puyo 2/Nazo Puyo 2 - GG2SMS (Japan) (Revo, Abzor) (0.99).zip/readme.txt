!!Nazo Puyo 2 v0.9 GG2SMS Conversion by Revo 2017-04-13
*Start configured on down controller 2.
*Bug: the title screen doesn't display (zap).
*Use save.
*Display in Japanese.