!!Crystal Warriors v1.1 GG2SMS Conversion by Revo and BcnAbel76 2020-04-24
* Fixed problems in palette conversion, now all is ok
* Updated controller code, now Megadrive or MS pads are detected, START, B, C for MD pad, or 2P(Down Arrow), 1P (1, 2 ) for MS pad

!!Crystal Warriors v1 GG2SMS Conversion by Revo 2016-12-13
@@10 minutes gameplay video: https://www.youtube.com/watch?v=inDBLj7YRLo @@

*Start is on down controller 2.
*Most of the time during combat sprites will have wrong colors, this is due to the fact that the game is able to display different colors on the same palette and this is something I don't understand (I only saw that on this game and Codemasters games).
*In the village, to have good colors, press start 2 times.