Crazy Faces SMS patch
by nextvolume <tails92@gmail.com> (http://unhaut.fav.cc)

First release v1
-------

This is the first release of this patch that allows you to play Crazy Faces, a game developed in 1993 by Domark Software for the Game Gear, on your Master System.
The game never made it to public release, and a prototype cart of it was found and dumped by the people at SMS Power (http://www.smspower.org) in 2012.

The game works well and fully playable.
There are no problems I could detect during my limited testing; if there are, let me know.

The Game Gear START button is mapped to Button 2 on the Master System, except during gameplay, when it is mapped to the Master System PAUSE button.

The patch applies to a ROM image of the Crazy Faces cartridge, as dumped by the people at SMS Power; the ROM image can be found on their website - as this is a forgotten piece of software, which never even saw public release, you can consider it to be abandonware.

In this archive other than for the IPS format patch, named `crazyfaces_sms.ips', you can find the full source code of the injected code snippets that were used to make the patch; this means that if you are technically versed, you can improve the patch yourself.
The Makefile is very simple and easily understood; to build the patch, simply run `make'.
The ROM image must be placed in this directory and named `crazyfaces_orig.sms'; the patched ROM afte running `make' will be named `crazyfaces.sms'.
The Makefile assumes you are on a Unix-like operating system; if you are on Windows you can try using MSYS or Cygwin.

The assembler you will need to use is z80asm (http://www.nongnu.org/z80asm/)

inject, fixsum, nop and putstring were written by me (nextvolume), they will respectively inject a code snippet, fix the ROM checksum, insert NOP instructions in the ROM and insert a string in the ROM; do whatever you want with them, but give credit.

Enjoy!

-nextvolume
16th May 2014
