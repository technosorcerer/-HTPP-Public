Captain America and the Avengers v0.4 by Wafer 2019-11-03
* Compatible with MD and Saturn pad, supports start button
* Supports pause button and down on controller 2
* Game can be started without start button

Captain America and the Avengers v0.3 by Revo 2017-01-10
* Less garbage screen in menus.
* Better adaptation of the title screen.

Captain America and the Avengers v0.2 Revo 2016-12-11
* Left Blank Column active.
* Less garbage screen on title screen.

Captain America and the Avengers v0.1 Revo 2014-05-13
* Artifacts on menus and around the screen.
* The down arrow of the second controller is Start.