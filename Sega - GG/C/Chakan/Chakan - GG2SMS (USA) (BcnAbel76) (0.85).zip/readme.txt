Chakan V0.6 GG2SMS Conversion by BcnAbel76 - 20161220
* Working ok! 
* Fixed garbage while jumping 
* Removed background colors loop 

Chakan v0.1 GG2SMS Conversion by BcnAbel76 - 20161219
*Palette conversion ok
*Start 2nd down arrow
*Graphical glitches while jumping
*Long bar down screen, (may causing problems)
*Game can crash if you cause a lot of glitches when jumping