patch by Revo:  http://www.slevinproduction.com/mastersystem/

Start on down controller 2