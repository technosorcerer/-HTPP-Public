The Chessmaster v1.1 by Wafer 2019-12-31

* Compatible with MD and Saturn pad, supports start button
* Supports pause button and down on controller 2
* Game can be started without start button
* If you are using a 6-button pad, forcing compatibility by holding down Mode when starting up is highly recommended

The Chessmaster v1 GG2SMS Conversion by Revo 2015-05-02

patch by Revo:  http://www.slevinproduction.com/mastersystem/

Start on down controller 2