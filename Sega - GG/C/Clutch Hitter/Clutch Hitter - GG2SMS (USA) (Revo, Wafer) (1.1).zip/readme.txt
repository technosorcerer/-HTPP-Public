Clutch Hitter v1 by Wafer - 2019-12-31

* Compatible with MD and Saturn pad, supports start button
* Supports pause button and down on controller 2
* Game can be started without start button
* If you are using a 6-button pad, forcing compatibility by holding down Mode when starting up is highly recommended

Clutch Hitter v1 by Revo - 2015-11-24

* Start is configured on down controller 2. 
* Tile #0 deleted in-game to limit garbage screen (it's the up corner left of the big ball, when the ball is up in the sky). 
* One color in-game is pink instead of white (I had choice beetween pink or blue).