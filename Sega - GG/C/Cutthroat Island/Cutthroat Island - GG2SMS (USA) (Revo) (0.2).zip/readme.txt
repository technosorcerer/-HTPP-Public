patch by Revo:  http://www.slevinproduction.com/mastersystem/

- Artifacts on menus and around the screen.
- The down arrow of the second controller is Start.