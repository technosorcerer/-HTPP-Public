Frogger [Prototype] GG->SMS Patch Ver 0.92
---------------------------------

Hi, folks.  Chris Covell here.

This is an IPS patch that converts a Frogger ROM for the Game Gear into a ROM
that will work on the Sega Master System.  The version of Frogger that has been released
is the wrong size.  It should be 128k, not 256k.  This patch will work fine on
both 128k and 256k versions of the ROM, fortunately.

To apply the patch, you need the original Frogger [Proto] GG ROM, and an IPS patching
utility (go find it yourself).  Apply the patch as per the instructions, and don't
forget to rename the ROM extension to ".SMS"!  ;)

Since the SMS doesn't have the GG "Start" button, I've remapped it to the "Pause"
button on the SMS power base.

If you notice any errors or problems with the patch, please e-mail me at
chris_covell@yahoo.ca.  Feel free to visit my homepage at http://www.zyx.com/chrisc
--
Version 0.92 of the patch repositions some status information in the game, as well as
fixing the checksum for play on a real SMS.