Fatal Fury Special GG2SMS Conversion by BcnAbel76

- May not work on real hardware, need to polish some code 
- "Down Arrow" 2nd controller is START/PAUSE 
- Game Gear to Master System Palette Conversion Full 
- Minor garbage in some stages 
- 100% Playable 
- Only 1P game (Remember 2P in game gear requires link cable), don't select 2 Player Versus or game crash 


