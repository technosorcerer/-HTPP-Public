Game Gear to Master System Conversion.

Apply IPS Patch to "Fatal Fury Special (U) [!].gg"



FATAL FURY SPECIAL ( 2PLAYERS MODE ) V1.2 GG2SMS

Changelog:

- START is mapped to PAUSE Button
- 2 Players Mode Activated !!!
- Written Player 2 controller code
- Bypassing checkings/data Gear2Gear communication
- Changed Main Menu colors manually
- Updated wrong tile when game reboots
- Updated tiles in Andy Bogard Stage
- If PLAYER 1 is fighting VS CPU then it is showing "ENEMY"
- If PLAYER 1 is fighting VS HUMAN then it is showing "PLAYER 2"


And remember:

- START is mapped to PAUSE Button 
- 2 Players VERSUS!!! FIGHT !!!


Known errors,
Hack limitations,

- Game is set to Player 1, example: Player 1 VS Player 2, then Player 2 wins, game is showing "YOU LOSE"
- Ryo Sakazaki in demo mode is showing 2 or 3 colors no correct, but if I repair it game crashes
- Some stages is showing garbage offside gameplay screen


CoNvErSioN By BcnAbel76
