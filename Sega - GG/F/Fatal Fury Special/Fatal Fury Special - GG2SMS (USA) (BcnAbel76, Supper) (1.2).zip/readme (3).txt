Fatal Fury Special GG2SMS Conversion by BcnAbel76 V1.02 2016-09-13

- GG ports removed 
- Run in Master System real hardware 



Fatal Fury Special GG2SMS Conversion by BcnAbel76 V1.01 2016-09-10

- Fixed Checksum for real hardware compatibility 
- Fixed internal data, now it's a Master System ROM 




Fatal Fury Special V1.0 2016-09-09
- May not work on real hardware, need to polish some code 
- "Down Arrow" 2nd controller is START/PAUSE 
- Game Gear to Master System Palette Conversion Full 
- Minor garbage in some stages 
- 100% Playable 
- Only 1P game (Remember 2P in game gear requires link cable), don't select 2 Player Versus or game crash 


