﻿********************************************************************************
*                          Eternal Legend (Game Gear)                          *
*                          English Translation Patch                           *
*                              v1.0 (15 May 2020)                              *
*                                                                              *
*                        TheMajinZenki -- Translation                          *
*                               Supper -- Hacking                              *
*                               cccmar -- Editing and Testing                  *
********************************************************************************

<Legend> tells of the <lost city> of 'Millennium', a golden <paradise> created 
to praise the <gods>. It is said that the bearer of the eight [Golden Knives] 
shall open the way to 'Millennium' and its long-lost <treasures> and 
<technology>. One day, <<Arwyn>>, a <young man> hunting for <treasure>, 
unexpectedly finds himself caught up in the <search> for 'Millennium'. In a 
<journey> spanning the entire <world>, <<Arwyn>>, together with companions 
<<Ryall>> and <<Blue Moon>>, must solve <mysteries> and uncover <conspiracies> 
from across the ages in order to learn the <secret> of 'Millennium'...

[Eternal Legend] is a 1991 RPG developed by Japan Art Media for the [Sega Game 
Gear]. It's a very <orthodox> RPG notable mostly for being the very <first> one 
on the [Game Gear]. It features vast overworlds based on real-world 
<continents>, a simple monster <summoning> mechanic, and a highly idiosyncratic 
system of <text bracketing>.

This [patch] fully translates the <game> into <English>.

                    ****************************************
                    *          Table of Contents           *
                    ****************************************

  I.   Patching Instructions
  II.  Notes
  III. Authors' Comments
  IV.  Version History

                    ****************************************
                    *       I. Patching Instructions       *
                    ****************************************

You'll first need a ROM image of Eternal Legend for the Game Gear. It should 
match the following specifications:

  No-Intro filename: Eternal Legend - Eien no Densetsu (Japan).gg
  CRC32:             04302BBD
  MD5:               C58D6291DA8A4919328B8F42BE8640A7
  SHA-1:             717B4E33CF3956E4194B912533BF1B7BF9D20725

The patch itself is a standard IPS patch. Use a tool such as Lunar IPS to apply 
the IPS file to the ROM. The patch will expand the ROM to 1 MB, so don't use 
ancient patching utilities that don't support that.

                    ****************************************
                    *              II. Notes               *
                    ****************************************

Eternal Legend was the very first RPG released for the Game Gear. It is, to put 
it mildly, a bit clunky. Though the gameplay is largely standard RPG fare, the 
game has a bad habit of making important event triggers invisible and in some 
cases unfindable without manually using the "Search" command. It also likes to 
prevent the plot from progressing until you talk to *exactly* the right people 
in the right order, often without any indication that this is the case. And 
while the game maps are unusually large, your party walks agonizingly slowly, 
often while being assaulted by monsters every few steps.

In the interest of making the game slightly more bearable, several features that 
we originally added to the game to help debug the translation have been left in 
as strictly optional cheats:

- Holding down Button 1 while walking will make the party move faster. This will 
also speed up forced movement during cutscenes.

- The System menu now contains an option to disable random encounters.

- Holding Button 1 will fast-forward text (in the original game, only Button 2 
did this).

- The patch comes bundled with a full walkthrough (see "walkthrough.txt"). If 
you're stuck, don't hesitate to check it; the game pulls all kinds of unfair 
stunts that you really, really don't want to try to get through blindly. Anyone 
familiar with this game isn't going to have fond things to say about the 
Labyrinth.

To reiterate, all of this is totally optional. For the original game experience, 
don't use the "run" button, leave encounters on, and don't look at the 
walkthrough ever. And, uh, try to have fun.

And needless to say, all <brackets> in the <game script> are exactly per the 
original <text>. We wouldn't change those for the <world>.

                    ****************************************
                    *       III. Authors' Comments         *
                    ****************************************
  
  -------------------
  -- TheMajinZenki --
  -------------------
  
  I decided to translate this game because we had worked on Moldorian earlier 
on, and I heard that was some kind of spiritual successor to Eternal Legend. 
Apparently it was the very first RPG on Game Gear, which made me interested in 
it. Considering its age, the story is very simple, but I think it still has its 
charm considering its limitations. I hope you'll enjoy :)
  
  ------------
  -- cccmar --
  ------------
  
  Alright, so what can I say... Eternal Legend is the very first RPG on the Game 
Gear (and incidentally, the last without an English translation). It has some 
unusual features for the time, such as degradable weapons, summoning (still not 
too common in JRPGs at that time) and a weakness targeting system.
The main issue with it is the cryptic nature of some segments - that's why 
Supper cooked up a handy walkthrough for you, should you ever get stumped. You 
probably will. We did the game kinda on the spur of the moment, seeing that was 
the last JRPG for the system without a translation. So, this is probably it for 
our Game Gear projects. It was quite a ride, but I'm happy we all partook in it. 
So long, Game Gear... the unknown journey will continue!
  
  ------------
  -- Supper --
  ------------
  
  I tried to talk Zenki out of it, I really did... but here we are anyway. There 
aren't any more Game Gear RPGs left to translate, right? Right?? We're not going 
to have to suffer through all this again, right???
  
  ...Well, anyway, here's one more translation done. You might have picked up on 
the fact that I don't care for the game much, but in all fairness, it *was* the 
first RPG on the Game Gear. Unfortunately, that doesn't change the fact that 
it's just not a great game. I've tried to make it less painful by leaving in my 
debugging cheats -- ironic, considering I'm usually the one arguing *against* 
translations making arbitrary "enhancements", but given that it's all 100% 
optional and the game desperately needed something to alleviate all the tedious, 
sloooow wandering through its gigantic maps, I'm more than willing to let it 
slide this time.
  
  At any rate, I hope a few of you out there will at least give this a shot 
despite the fact that I can't seem to stop badmouthing it. It has its good 
points: the plot isn't bad, there don't seem to be any major bugs, and it has a 
few legitimately creative ideas, like the giant retracting spike and spear traps 
on the overworld. It's just that for everything the game does right, it does 
something else wrong, or at least very clunkily. Oh well.
  
  And boy, you can tell they wanted to have color-coded text but couldn't figure 
out how to make it work, huh? Well, guess <brackets> are the <next-best> thing.

                    ****************************************
                    *         IV. Version History          *
                    ****************************************

v1.0 (15 May 2020): Initial release.
