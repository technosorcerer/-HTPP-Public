The Incredible Hulk DX
Dec. 18th 2023
BillyTime! Games
--------------------

This patch is an complete overhaul to The Incredible Hulk by U.S. Gold.

Features:
*Multiple playable Hulk variants
*Tweaked gameplay
*Hi-Score SRAM
*Progress SRAM

--------------------
Green Hulk
--------------------
*2x Damage
*Can do super moves without limit

--------------------
Red Hulk (What If?)
--------------------
*4x Damage
*Takes 2x as much damage
*Can do super moves without limit

How to select:
Press and hold B at the title screen until the intro cutscene appears.

--------------------
Gray Hulk (What If?)
--------------------
*1x Damage
*Takes 1x as much damage
*Can do super moves without limit
*Health Regen

How to select:
Press and hold C at the title screen until the intro cutscene appears.

SRAM:
--------------------
Saving:
Game saves after completing each level.

Loading:
Press and hold start at the title screen until the intro cutscene appears.

Game Save:
*Progress
*Current Hulk form

Hi-Score SRAM
--------------------
Saving:
Scores save after Initials are entered and player returns to the title screen. 

Loading:
Scores load upon boot. If checksum fails or it is your first time booting, default scores are loaded.

How to Patch:
--------------------
1.Grab a copy of Incredible Hulk, The (USA, Europe).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file