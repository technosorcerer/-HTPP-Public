Patch to use on rom Itchy & Scratchy (JUE) [!].gg 
Game originaly develloped for Master System then ported to Game Gear. 
Fullscreen, no garbage screen. Palette converted manually. Thanks to Vingazole for moving the life bars. 
Pause in-game is down player 2. 