GG Portrait - Yuuki Akira v1 by Revo - 2016-12-09

* Garbage screen sometimes. Controls: 1 & 2