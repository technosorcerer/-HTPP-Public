"Gunstar Heroes"
Traducción al Español Ver. 1.0 (12/01/2024)
por Max1323 (Traducciones Max1323), Wave (Traducciones Wave) y Bunkai.
---------------------------------------------------
Descripción:
Hace mucho tiempo, la Tierra fue empujada al borde de la perdición por 
el Dios de la Destrucción, Golden Silver, hasta que los cuatro Gunstars,
Red, Blue, Green y Yellow aparecieron y lo sellaron en la Luna. 
Temiendo por su eventual regreso, los Gunstars se pusieron en un sueño criogénico para poder detener a Golden Silver cuando llegue el momento.
El tiempo pasó y todo sigue en paz, hasta que un día aparece el General
Grey para buscar los cuatro cristales de poder de Golden Silver, y envía
una unidad de excavación a la Luna.
El Dr. Brown, era el encargado de liderar la unidad de excavación del General Grey, él descubre a los cuatro Gunstars en su lugar de descanso,
él descubre los eventos del pasado y promete ayudarlos a detener al 
General Grey. Sin embargo, Green ha perdido su memoria y el General Grey
lo engaña para ayudarlo a revivir a Golden Silver.
Esto deja a Red y Blue para recuperar a su aliado y evitar que el
General Grey reviva al terrible destructor.

Desarrollado: M2
Publicado:    SEGA
Lanzamiento:  24/03/1995 (JAP)
---------------------------------------------------
Acerca del proyecto:
-La mayoría de los textos están traducidos. Se agregaron
los caracteres españoles.
-Los textos son casi similares a la versión de Genesis/Mega Drive
por lo que fue fácil traducirlo a excepción de ciertos cambios
para está versión, que gracias a Bunkai pudo traducir esas partes.
-Gracias a Wave por sumarse al proyecto, revisó y corrigió
algunos textos.
-Gracias a Bunkai por traducir los textos faltantes del juego.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS (PC)
Utilizar UniPatcher (Android)
Utilizar Rom Patcher JS (Parcheador Online):
https://www.romhacking.net/patch/

Archivo IPS
Gunstar Heroes (Japan).gg
File Size     512 KB
File MD5      752353CCC6678C727926B661C7AD5E3F        
File SHA-1    D509F4CF534C3638A29314563E98DE5F963F8264
File CRC32    B27BCF3D