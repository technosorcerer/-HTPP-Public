patch by Revo:  http://www.slevinproduction.com/mastersystem/

- May not work on real hardware; Emulator-only.
- Artifacts on menus and around the screen.
- The down arrow of the second controller is Start.