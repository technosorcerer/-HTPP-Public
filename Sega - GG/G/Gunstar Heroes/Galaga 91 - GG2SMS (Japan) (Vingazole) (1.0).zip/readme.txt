Patch by Vingazole

- Galga 2 is the European Version, Galga '91 is from Japan.
- Start button mapped to button 2.
- Changed ''game gear'' to ''master system'' on the title screen.