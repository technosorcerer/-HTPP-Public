Version 1.5 updated by vingazole

Hi, little enhancement to the great conversion job already done by Chris Covell on GG Aleste 2/Power Strike 2 : 

- displays the title "GG Aleste II" , whether the console is japanese or not. 

- uses BUTTON 1 for the menus, letting the pause in-game mapped to the Master System PAUSE button. 





GG Power Strike II / GG Aleste II GG->SMS Patch
-----------------------------------------------

Hi, folks.  Chris Covell here.

This is an IPS patch that converts a "GG Aleste II" or "Power Strike II" ROM for 
the Game Gear into a ROM that will work on the Sega Master System.

To apply the patch, you need the original Power Strike II GG ROM, and an IPS patching
utility (go find it yourself).  Apply the patch as per the instructions, and don't
forget to rename the ROM extension to ".SMS"!  ;)
I haven't tested the patch with the Japanese ROM "GG Aleste II" but it should work.

Since the SMS doesn't have the GG "Start" button, I've remapped it to the "Pause"
button on the SMS power base.  This cannot be avoided, unfortunately.

I've tested this game out on real SMS hardware, and it works great. Any bugs or glitches
in emus are probably the fault of the emulators.  But, if you notice any errors or 
problems with the patch, please e-mail me at chris_covell@yahoo.ca.

Feel free to visit my homepage at http://www.zyx.com/chrisc