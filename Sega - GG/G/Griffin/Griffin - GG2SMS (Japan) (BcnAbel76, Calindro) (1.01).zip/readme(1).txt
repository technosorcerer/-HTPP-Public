Griffin V1.01 GG2SMS Conversions by BcnAbel76 - 2017-01-24
* Optimized code conversion 
* Added Megadrive/Genesis controller, Start on Start Button or 2nd Master System controller "Down" Arrow 



Griffin v1 GG2SMS Conversion by BcnAbel76 2016-12-17
*Full palette conversion
*START is 2nd Controller "Down" Arrow, (for now)
*GG ports removed
*Checksum fixed, master system rom, work in real hardware