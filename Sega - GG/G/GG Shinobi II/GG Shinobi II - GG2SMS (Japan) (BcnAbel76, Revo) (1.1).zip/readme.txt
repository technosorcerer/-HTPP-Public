Shinobi II - The Silent Fury V1.0 GG2SMS Conversion by BcnAbel76 - 2016-09-22

-"Down Arrow" 2nd controller Start/Pause 
- Full palette conversion 
- GG ports removed 
- Checksum fixed 
- Now is a Master System Rom 
- Run in Real Hardware 
- Very playable !!! 
- Enjoy 

