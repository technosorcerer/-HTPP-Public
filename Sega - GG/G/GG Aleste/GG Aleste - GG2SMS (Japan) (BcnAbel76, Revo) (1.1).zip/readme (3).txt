GG Aleste V1.03 GG2SMS Conversion by BcnAbel76 - 2017-01-24
* START is now configured in Megadrive/Genesis "Start" or "Down Arrow" 2nd Controller Master System Pad 

----

GG Aleste V1.02 GG2SMS Conversion by BcnAbel76 - 2016-12-12
* Moved lives icon 
* Remaped START to Megadrive/Genesis Controller, no needed 2nd controller anymore

----

GG Aleste V1.0 GG2SMS Conversion by BcnAbel76 - 2016-09-15

* "Down Arrow" 2nd Controller is Start/Pause 
* Full palette conversion 
* Minor garbage at screen bosses (GG Resolution vs Master System) 
* Pause button at Master System, no effect, now don't crash game 
* Now is a Master System Rom 
* GG ports removed 
* Work in real hardware 
* Very playable !