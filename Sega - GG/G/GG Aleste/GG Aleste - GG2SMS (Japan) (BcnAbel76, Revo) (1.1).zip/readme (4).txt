GG Aleste V1.0 GG2SMS Conversion by BcnAbel76 - 2016-09-15

- "Down Arrow" 2nd Controller is Start/Pause 
- Full palette conversion 
- Minor garbage at screen bosses (GG Resolution vs Master System) 
- Pause button at Master System, no effect, now don't crash game 
- Now is a Master System Rom 
- GG ports removed 
- Work in real hardware 
- Very playable ! 