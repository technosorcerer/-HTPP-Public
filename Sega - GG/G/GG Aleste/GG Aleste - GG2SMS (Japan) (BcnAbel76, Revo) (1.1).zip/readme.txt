!!GG Aleste V1.1 GG2SMS Conversion by Revo - 2017-04-13
*Different conversion than BcnA one.
*Start configured on 2 (sound test screen still accessible, segaretro say that button 2 is used in-game but I'm pretty sure it's not!).
*Counter life icon moved in the corner.