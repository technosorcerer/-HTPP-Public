Greendog - The Beached Surfer Dude! V1.1 GG2SMS Conversion by Revo - 2017-02-16
- Left column blank active. 
- Less garbage screen on Sega screen. 


Greendog - The Beached Surfer Dude! V1.0 GG2SMS Conversion by BcnAbel76 - 2017-02-15
- Full palette conversion 
- Down Arrow 2nd Controller is START 
- Fixed Checksum 
- Some garbage around Title Scren and gaming 

