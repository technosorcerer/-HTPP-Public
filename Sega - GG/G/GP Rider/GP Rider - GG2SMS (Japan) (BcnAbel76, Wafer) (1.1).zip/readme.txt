!!GP RIDER (Game Gear) v1.1 GG2SMS Conversion by Wafer 2020-04-21
* Compatible with SMS and MD pad, supports [Start] button
* Supports [d] on controller 2 as start
* If you are using a 6-button pad, forcing compatibility by holding down %bgcolor=white black%'''[MODE]'''%% when starting up is '''highly''' recommended

!!GP RIDER (Game Gear) v1.0 GG2SMS Conversion by BcnAbel76 2020-04-20
GP RIDER (Game Gear) V1.0

* Apply patch GP Rider (U) [!] version
* Megadrive / Genesis controller required, buttons START, B and C
* Enjoy it