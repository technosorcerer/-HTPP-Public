!!GP RIDER (Game Gear) v1.0 GG2SMS Conversion by BcnAbel76 2020-04-20
GP RIDER (Game Gear) V1.0

* Apply patch GP Rider (U) [!] version
* Megadrive / Genesis controller required, buttons START, B and C
* Enjoy it