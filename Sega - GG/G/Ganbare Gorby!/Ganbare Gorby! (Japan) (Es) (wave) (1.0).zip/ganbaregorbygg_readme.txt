Ganbare Gorby! (Game Gear)
Traducción al Español v1.0 (13/05/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ganbare Gorby! (Japan).gg
MD5: 4d965f99be3edd9593af1c365d6a2653
SHA1: cd3e8910a99bf6717e63aed3aa212ead0597e5cd
CRC32: a1f2f4a1
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --