********************************************************************************
*                          Godzilla: Monsters Attack                           *
*                          English Translation Patch                           *
*                              v1.1 (08 Mar 2019)                              *
*                                                                              *
*                        TheMajinZenki -- Translation                          *
*                               Supper -- Hacking                              *
*                               cccmar -- Editing and Testing                  *
*                             Xanathis -- Testing and Editing                  *
*                               Filler -- Original Script Dump                 *
********************************************************************************

Godzilla's here, time to trample Tokyo.

Gojira: Kaijuu Daishingeki (Godzilla: Monsters Attack, derived from the 1969 
film All Monsters Attack) is a 1995 strategy/fighting hybrid game for the Game 
Gear. It features five missions loosely based on various Godzilla films, with 
the player choosing to play as either Godzilla and friends (aiming to destroy a 
certain amount of the city) or the JSDF (trying to prevent it). The overall 
battle plays out in a turn-based strategic view, while combat between units 
takes place in action-based one-on-one fighting matches.

This patch fully translates the game into English.

                    ****************************************
                    *          Table of Contents           *
                    ****************************************

  I.   Patching Instructions
  II.  Basic Gameplay
  III. Authors' Comments
  IV.  Version History

                    ****************************************
                    *       I. Patching Instructions       *
                    ****************************************

You'll first need a ROM image of Gojira: Kaijuu Daishingeki. It should match the 
following specifications:

  No-Intro filename: Gojira - Kaijuu Daishingeki (Japan).gg
  CRC32:             4CF97801
  MD5:               E550267F3AE767BED5D0E2A126F44A10
  SHA-1:             FF3E8905635A02EB85556146225020B52506424C

The patch itself is a standard IPS patch. Use a tool such as Lunar IPS to apply 
the IPS file to the ROM. The patch will expand the ROM to 1 MB, so don't use 
ancient patching utilities that don't support that.

                    ****************************************
                    *          II. Basic Gameplay          *
                    ****************************************

  Since there's not a lot of information about this game out there and we 
couldn't find a copy of the manual to translate, this section contains some 
basic information. Most of it should be obvious just by playing, but some of the 
fighting mode commands aren't easy to work out.
  
  ************
  * Overview *
  ************
  
  The game has five stages in total. The first four can be played in any order; 
if certain requirements are fulfilled during those stages, the fifth and final 
stage will be unlocked. You'll know you've met these requirements if a medal 
appears next to the stage name after completing it.
  
  You can play as either the G-Force (a.k.a. the JSDF) or Godzilla and allies. 
The stages are the same regardless of which side you choose -- only the units 
you control are different. (Tip: Play as Godzilla first. It's generally harder 
and takes a lot more time to achieve victory as the G-Force.)
  
  ********************
  * Stage Objectives *
  ********************
  
  The objectives of each stage are explained before it starts, but certain 
conditions must be met in each stage to unlock the final stage and the best 
ending. Specifically:
  
  * If playing as the G-Force, the destruction rate must be kept below a certain 
value.
  * If playing as Godzilla, the destruction rate must exceed a certain value.
  * In stages where Space Monsters appear, the stage must be cleared by 
defeating all the Space Monsters. Defeating Godzilla or the G-Force will 
technically count as a victory, but will prevent you from unlocking the final 
stage.
  * Other conditions may apply per stage, e.g. rescuing or protecting Baby 
Godzilla.
  
  *****************
  * Strategy Mode *
  *****************
  
  D-Pad     -- move the cursor
  Start     -- open the main menu
  Button 1  -- select the currently targeted unit for use
  Button 2  -- move the cursor to the next unit that hasn't yet moved on the 
current turn
  
  Close-range attacks are initiated by moving a unit adjacent to another, then 
selecting the "Attack" option. Units with long-range attacks may use them by 
moving so that an enemy is in range, then selecting the "Long-Range" option.
  
  Monsters can recover health by idling for a turn (select the unit, then press 
Button 2 again without moving it). G-Force weapons can recover health and/or 
regain units by entering a supply base.
  
  If the "Auto" option is enabled in the Options Menu, the cursor will 
automatically move to the next unit in the unit list after the current one takes 
a turn.
  
  ***************
  * Combat Mode *
  ***************
  
  Controls vary depending on the unit in use, but the following apply to most 
unit types:
  
  D-Pad Left/Right  -- move
    * Hold the direction opposite your unit's facing to block (while the 
opponent is attacking).
    * Rapidly tap Left or Right twice to dash. Some units have dash attacks 
activated by pressing Button 1 or 2 while dashing.
  D-Pad Up          -- jump
  Button 1          -- light attack
  Button 2          -- heavy attack
  
  Some units have a special attack, activated by pressing Buttons 1 and 2 
simultaneously. For these units, the "Lv" meter will slowly rise during battle 
to indicate the special attack's charge level. Generally, firing while the meter 
is in the blue zone performs a "weak" special attack, while firing in the yellow 
zone performs a "strong" one. Some special attacks have additional controls, so 
try experimenting with them.
  
                    ****************************************
                    *        III. Authors' Comments        *
                    ****************************************
  
  -------------------
  -- TheMajinZenki --
  -------------------
  
  Before this game I never knew much of Godzilla. Of course I knew about it, it 
is one of the most famous fictional monsters in the world, but I've never 
watched the movies nor played any of the games. When I first started translating 
this game I didn't know what to think, but watching the gameplay somehow clicked 
with me (probably due to my passion for licensed strategy games like the SRW 
series). There wasn't much to translate in this game to be fair, it was mostly 
the list of units, objectives and the monster biographies. The scenarios are 
based on some of the classic movies, mixing elements from multiple of them (for 
example, while there is no specific scenario based on Mothra vs. Godzilla, 
Mothra can appear in any scenario if the JSDF is on the verge of annihilation).
I think this game could be interesting for both for strategy fans in general and 
for fans of Godzilla. I hope you enjoy it as much as I did working on it :)

  ------------
  -- Supper --
  ------------
  
  I've never watched a Godzilla film in my life. This game made me want to, so I 
guess it did its job.
  
  After slamming out Moldorian, a fairly full-featured Game Gear RPG, in two 
weeks, I figured the hacking for this game would go even quicker since it's 
generally simpler. But nope, this was another one of those games where new text 
in a new format just kept popping up every time I thought I was finished. First 
it was the "to be continued" text in the bad ending, then it was a Japanese 
newspaper page that took several agonizing hours to reformat into a 
Western-style one, then it was the debug menu... Point is, this took longer to 
hack than an RPG despite having considerably fewer menus. You really can't judge 
these things just by looking at the game.
  
  Anyway, I did a full VWF conversion despite the obstacles, and I think things 
came out looking pretty nice. It's a game with charm, especially if you play as 
Godzilla, so I hope you enjoy.
  
  Also, I feel like someone, somewhere, is going to look at the title screen and 
immediately become incensed that I used a Godzilla logo from 2014 for the title 
screen of a game that came out in 1995. To that person I'm going to preemptively 
say "please reconsider your life choices".
  
  ------------
  -- cccmar --
  ------------

  I am somewhat familiar with the Godzilla series, but mostly with the older 
films (up until the late ‘80s period). The tale of an enormous, prehistoric 
dinosaur-like monster empowered by nuclear radiation is as old as the mountains 
(well, maybe not quite this old), and various new installments are still in 
production. Also, a rather large number of games based on the franchise has been 
made thus far. Most of them are action games/beat ‘em ups/fighting games, but 
there are a few odd ducks, such as this one. This here is a strategy 
game/fighting game hybrid, where you need to carefully manoeuver around the map 
and fulfill various objectives, which usually involve destroying the city, 
JSDF’s forces or rival space monsters (or Godzilla, in JSDF’s campaign). It’s 
quite an interesting mixture overall, but you really need to be on your toes to 
get anywhere. There’s not much of a plot all things considered, but each mission 
is based on the films to some extent. What else is there to say… playing as a 
giant monster has its appeal and it’s definitely fun once you get the hang of 
the game mechanics. The editing process for this was very easy, since there’s 
not “that” much text. Well, who would’ve thought that what was once a bloke 
wearing a rubber costume could become this popular all over the world?

                    ****************************************
                    *          IV. Version History          *
                    ****************************************

v1.1 (08 Mar 2019): Fixed bugs that caused garbled text when the game was run on 
real hardware. Thanks to ERICONWHEELZ for reporting this and helping test the 
updated version.

v1.0 (02 Jan 2019): Initial release.
