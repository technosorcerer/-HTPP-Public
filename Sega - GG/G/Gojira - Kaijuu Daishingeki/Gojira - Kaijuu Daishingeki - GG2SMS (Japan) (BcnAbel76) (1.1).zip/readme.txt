!!GODZILLA: MONSTERS ATTACK (Godzilla: Kaijuu Daishingeki) v1.1 GG2SMS Conversion by Wafer 2020-04-21
* Compatible with MD and Saturn pad, supports [Start] button
* Supports [d] on controller 2 and [Pause] button as start
* If you are using a 6-button pad, forcing compatibility by holding down %bgcolor=white black%'''[MODE]'''%% when starting up is '''highly''' recommended
* Game makes heavy use of [Start] button, so an MD or Saturn pad or a modded console is highly recommended.

!!GODZILLA: MONSTERS ATTACK (Godzilla: Kaijuu Daishingeki) v1.0 GG2SMS Conversion by BcnAbel76 2020-04-20
Credits Game Gear Version:
(TheMajinZenk,Translation)
(Supper, Hacking)
(cccmar, Script Editing/Revision)

* Megadrive / Genesis controller required, buttons START, B and C
* Apply patch to original japanese version
* Rom now is 1Mbyte and SRam is required to store data
* Enjoy it