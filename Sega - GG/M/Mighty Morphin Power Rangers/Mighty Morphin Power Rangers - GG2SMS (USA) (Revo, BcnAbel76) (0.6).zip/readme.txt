Game Gear to Master System Conversion.

Mighty Morphin Power Rangers v0.6 GG2SMS

Changelog:

- Extra Options activated
- 2 Players Mode Activated !!!
- Written Player 2 controller code
- Bypassing checkings/data Gear2Gear communication
- Changed Main Menu Option showing now "1P VS 2P"
- You can select Fighting Stage entering extra options and go to "STAGE" then "Left" or "Right" and "Exit", then go to "1P VS 2P" and your selected stage appears ;)
- In "1P VS 2P, for select P2 character you need to do it with P1 "2", select you character then press "2", you hear a beep, confirmating it. Selection finishes pressing "1" for Player 1 character
  (If you don't select any character for P2 then RED Ranger is default)
  (If you want chage stage then "Exit" and enter in "Extra Options"

And remember:

- START is mapped to PLAER1 "1" in menu and PAUSE Button in game 
- 2 Players VERSUS!!! FIGHT !!!

Known errors,
Hack limitations,

- Game is set to Player 1, example: Player 1 VS Player 2, then Player 2 wins, game is showing "YOU LOSE"
- Some stages is showing garbage offside gameplay screen, BUT REALLY LOW!!!!!
- Palette is autoreading itself, when enemy is constant changing can show bad colors for seconds, REALLY STRANGE!!!!


CoNvErSioN By BcnAbel76
