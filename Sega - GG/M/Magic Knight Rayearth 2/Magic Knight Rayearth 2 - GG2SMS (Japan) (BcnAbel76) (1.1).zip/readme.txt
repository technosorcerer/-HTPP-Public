Magic Knight Rayearth 2 - Making of Magic Knight V1.0 GG2SMS Conversion by BcnAbel76 - 2017-01-24
*Start is 2nd Controller Down Arrow 
* Fixed Cheksum 
* Full palette conversion 
* Japanese 