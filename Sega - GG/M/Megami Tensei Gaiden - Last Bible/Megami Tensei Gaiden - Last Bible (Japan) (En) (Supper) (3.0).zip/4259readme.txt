Megami Tensei Gaiden: Last Bible
Patch Version: Three
English Translation Patch Information and Credits

-----------------------
  GENERAL INFORMATION
-----------------------

This patch is for Megami Tensei Gaiden: Last Bible on the Game Gear.
The text and graphics have been translated from Japanese into American English.

This version three patch fixes a typo and it also includes the translated packaging, with the box and sticker in png format, and the translated manual in pdf format. (See more details below.)

Two patching formats are provided, so you can use either .bps or .ips.
Do not apply both patches.

Be sure only to patch the original Japanese rom.

Do not apply the patch to a previously patched rom.

----------------------
  ROM SPECIFICATIONS
----------------------

These are the specifications for the ROM that this patch should be applied to:

  No-Intro filename: Megami Tensei Gaiden - Last Bible (Japan).gg
  CRC32:             2E4EC17B
  MD5:               AB54600E28D866558323381F74FE2749
  SHA-1:             D98332EBA27FD4A0DB82D551A54BEE4FDCCF41A2

The patch expands the ROM to from 512KB to 1MB, so make sure to use a modern patching tool that supports this.

Do not try to apply this patch to Megami Tensei Gaiden: Last Bible Special (which is a completely different game) or the Gameboy version (or Gameboy Color version) of Megami Tensei Gaiden: Last Bible.

-----------
  CREDITS
-----------

Hacking:
Supper

Translation:
Tom

Beta Testing:
ZyloWolfBane
surt_r
Phantomknighttv
mikeprado30
DDSTrans



---------------------
  PACKAGING CREDITS
---------------------
Base manual images from - https://segaretro.org

Fonts from - https://fontlibrary.org/
Bebas Neue font - Designed by Ryoichi Tsunekawa
Calcutta font - Designed by Manushi Parikh, Satya Rajpurohit
Fyodor font - Designed by Chris Hughes

pdf to png converter - https://ezgif.com/pdf-to-png
Image editing program- GIMP 2

Image Editing:
Novyal

Translation:
Tom