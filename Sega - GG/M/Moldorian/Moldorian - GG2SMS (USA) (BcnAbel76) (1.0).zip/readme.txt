!!MOLDORIAN The Sisters of Light and Darkness V1.0 GG2SMS Conversion by BcnAbel76 2018-12-18
ENGLISH TRANSLATION CREDITS GO:

TheMajinZenki -- Translation
Supper -- Hacking
cccmar -- Editing and testing
Xanathis -- Testing and editing
Filler -- Original script dump

MASTER SYSTEM CONVERSION
*New palette routine written on the fly, RGB stored data in 3 bytes is extremely strange
*Adjusting some colors manually
*No megadrive pad support for now, gameplay is basically using [1] or [2] button
*Deleted garbage in SEGA logo
*Some minor garbage during gameplay, not full master system resolution is designed for game. but very playable
*SRAM required

REMEMBER!!!!!!
Only patch GAME GEAR Japanese ROM with this IPS Patch!!!!!!! Then rename extension ".GG" to ".SMS", it is all