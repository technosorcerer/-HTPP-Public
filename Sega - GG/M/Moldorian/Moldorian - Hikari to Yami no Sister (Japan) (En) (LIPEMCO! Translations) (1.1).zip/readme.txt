********************************************************************************
*                Moldorian ~ The Sisters of Light and Darkness ~               *
*                          English Translation Patch                           *
*                              v1.1 (23 Aug 2019)                              *
*                                                                              *
*                        TheMajinZenki -- Translation                          *
*                               Supper -- Hacking                              *
*                               cccmar -- Editing and Testing                  *
*                             Xanathis -- Testing and Editing                  *
*                               Filler -- Original Script Dump                 *
*                               Novyal -- Manual Scanslation                   *
********************************************************************************

In the village of Keuzon within the Human Realm of Moldoria lives a boy named 
Navarre, shunned by his peers as a coward and weakling. His only real companion 
is Miria, his friend since childhood. One day, goaded by a village boy, Navarre 
ventures with Miria to a cave near the village to prove his strength. But 
unbeknownst to any of them, dark forces are at work upon the land, and Navarre 
will soon find himself swept up in an adventure beyond his imagination...

Moldorian: The Sisters of Light and Darkness is a 1994 RPG for the Sega Game 
Gear. It's notable for its unusual combat system (read the manual, we translated 
it for a reason!) and a quality soundtrack by the esteemed Hitoshi Sakimoto.

This patch fully translates the game into English.

                    ****************************************
                    *          Table of Contents           *
                    ****************************************

  I.   Patching Instructions
  II.  Authors' Comments
  III. Secret Cutscene
  IV.  Manual Scanslation
  V.   Version History

                    ****************************************
                    *       I. Patching Instructions       *
                    ****************************************

You'll first need a ROM image of Moldorian: Hikari to Yami no Sister (sometimes 
identified as "Moldorian: Hikari to Yami no Shimai", or "Moldorian: Hikari to 
Yami no Kyoudai"). It should match the following specifications:

  No-Intro filename: Moldorian - Hikari to Yami no Sister (Japan).gg
  CRC32:             4D5D15FB
  MD5:               95FB42E84A2B08ACCE481B0894EA3CEA
  SHA-1:             0DAD260B5357B2F61D1452BB73D8321CA53D7262

The patch itself is a standard IPS patch. Use a tool such as Lunar IPS to apply 
the IPS file to the ROM. The patch will expand the ROM to 1 MB, so don't use 
ancient patching utilities that don't support that.

                    ****************************************
                    *        II. Authors' Comments         *
                    ****************************************
  
  -------------------
  -- TheMajinZenki --
  -------------------

  I usually don't do RPGs since they're the hardest to translate, due to the 
randomness of npc, which makes them hard to deal with without context, but 
Moldorian seemed interesting enough that I accepted to work on it. The story is 
a bit of a cliche, but short enough that it doesn't outstay its welcome. I'd say 
the most difficult part of this translation was localizing the spell names. 
Originally, they were made up words that somewhat gave off a "vibe" of what the 
spell would be due to the name being based on a Japanese kanji or onomatopoeia; 
rather than simply romanizing them, we decided to do something similar and use 
words that give off a similar feel but with English. Hopefully they work for you 
players.
At any rate, I hope you enjoy one of the rare GameGear RPGs.

  ------------
  -- Supper --
  ------------
  
  So just barely a week after releasing Metal Max, here we are with another 
game. Zenki had already done the translation a while back, so I started on the 
hacking while Metal Max was still in testing and, to my surprise, got it done in 
about two weeks. I was expecting much more of a struggle.
  
  One reason for the quick turnaround time was that I did a full 
proportional-width font conversion this time around, which allowed for much more 
efficient use of screen space. Most menus layouts were simply used verbatim 
instead of having to be resized or hacked to use single-spacing. Doing a VWF on 
an 8-bit system has its own complexities compared to more powerful consoles, but 
in this case it was definitely the right move.
  
  The other reason this went so fast was that I did what I really should have 
done for the Magic Knight Rayearth translation Filler and I made earlier this 
year: use a hash table to remap the old string pointers to the new ones instead 
of trying to actually find and change all of them. This saved tons and tons of 
time, and I can't believe it never occurred to me to try it during the Rayearth 
pointer nightmare. We'll call it progress.
  
  Since Zenki went to the trouble of translating the user manual, I also added 
an in-game manual viewer (please read it before complaining about the battle 
system). Originally, I had a wistful note here about how I wished we could have 
done a proper scanslation, but as of Version 1.1, my hopes and dreams have 
unexpectedly come true! Check out the "Manual Scanslation" section below.
  
  Well, hope you enjoy. This isn't the best or worst RPG ever made, but it's at 
least worth a pop.
  
  Thanks, as always, to SMS Power! for being a great resource and a great 
community.
  
  ------------
  -- cccmar --
  ------------

  Filler mentioned Moldorian to me a while ago. I’ve always been interested in 
this game, so I decided to find more information about it online. Unfortunately, 
there wasn’t that much stuff out there, and so I thought - why not make this one 
of our next projects? So, I mentioned it to Supper and TheMajinZenki and here we 
are. There were initially some issues with the text dump (incidentally, Supper 
had later found a full dump for Moldorian and Eternal Legend online!), but 
Filler managed to mostly overcome them, and provided a script for TheMajinZenki 
to translate. This game wasn’t particularly difficult to edit, with the 
exception of spell names, which are often punny/onomatopoeic in Japanese. The 
game itself has quite a few neat features, such as being able to buy multiple 
items at once, sporting a relatively intuitive UI, quite a few different spell 
types, and many enemies. Overall, it is a short and sweet journey. Still, I 
STRONGLY urge you, the player/s, to read the manual that was added to the game, 
especially the section about the battle controls - they’re somewhat different 
from your standard battle controls in most other turn-based RPGs. Anyway, good 
luck and have fun!

                    ****************************************
                    *         III. Secret Cutscene         *
                    ****************************************

During editing, a peculiar block of text turned up that no one could figure out 
how to get to show up in-game. After some consternation and subsequent 
disassembling of the game, it turned out that a late-game event branches based 
on, of all things, a secret button code that has to be entered during a 
cutscene. It's quite possibly the most primitive QTE of all time.

This code isn't found anywhere in the game. It's also not anywhere on the 
Internet at the moment, so apparently the developer never released it -- it may 
have been intended for an official guidebook that never came out. In their 
stead, we're releasing it now.



*** spoilers ***



At the end of Highlandia, there's a cutscene in which King Pinion and Bucalli 
battle. During the cutscene, the following dialogue occurs:

  Pinion: "Stand back! It's too dangerous!"
  Bucalli: "You're still alive? Hmph. That works for me. You'll get to witness 
Pinion's last breath!"

Close Bucalli's dialogue box, then immediately hold Button 1, Button 2, and Up 
simultaneously while the animation of Pinion and Bucalli fighting plays. Ceria 
will break up their fight, leading to a slightly different sequence of events.

                    ****************************************
                    *        IV. Manual Scanslation        *
                    ****************************************

Thanks to some spectacular work by Novyal, this patch is now bundled with a 
complete scanslation of the game's user manual! It's thirty beautiful pages of 
cool art and painstakingly typeset text, so make sure to check it out. 
Preferably before you start playing, because otherwise you're going to be pretty 
confused when you wander into a battle and your characters do nothing but 
shuffle around until they get killed.

The translated manual should have come bundled with this patch as a PDF. You can 
also view it online on this patch's web site: 
http://stargood.org/trans/moldorian_manual.php

Credits for the manual translation:

  Cleaning, Typesetting, and Editing
      Novyal
  Original Translation
      TheMajinZenki
  Scans
      Sega Retro (https://segaretro.org/File:MHtYnS_GG_JP_Manual.pdf)
  Endless Publication Delays
      Supper
  Fonts
      Fonts from Font Library:
          Ambrosia, designed by fontforge
          Basic, designed by Magnus Gaarde
          GFS Theokritos, designed by George Matthiopoulos
          Alex Brush, designed by Robert E. Leuschke
          Source Serif Pro, designed by Frank Grießhammer
          Bagnard, designed by Sebastien Sanfilippo
          Square Grotesk Heavy, designed by Natanael Gama
      All fonts are licensed under the SIL Open Font License, Version 1.1.
  Software
      PDF to PNG converter: ezgif
      Image editor: GIMP 2

                    ****************************************
                    *          V. Version History          *
                    ****************************************

v1.1 (23 Aug 2019):
  * The patch now comes packaged with a fully scanslated manual! Major thanks to 
Novyal for doing an awesome editing job (and apologies for taking so long to 
release it).
  * Fixed a minor palette issue that occurred in the original game: whenever a 
character portrait was displayed, the window background color would darken 
slightly and remain that way until a new map was loaded. The darker color is now 
always used, as was probably the intention. This isn't the only problem with 
palette conflicts in the game, but it's one of the most noticeable.
  * Fixed a bug that was causing the horizontal separators on the status screen 
to not show up.
  * Fixed a bug that could cause the player name on the name entry screen to be 
displayed incorrectly when a character was erased under certain circumstances. 
The input handling on this screen is still kind of wonky, but that's how it was 
in the original game.
  * Modified the "0" character in the font to look less like an "8".
  * Reduced the width of certain menu windows to remove "dead space" on the 
right side caused by the translated text being shorter than the original.
  * Very tiny script tweaks here and there (proper use of "Your Majesty" vs. 
"Your Highness", etc.).

v1.0 (15 Dec 2018): Initial release.

