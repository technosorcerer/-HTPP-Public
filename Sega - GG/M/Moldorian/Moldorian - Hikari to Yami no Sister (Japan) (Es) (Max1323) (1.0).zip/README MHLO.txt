"Moldorian: Las Hermanas de Luz y Oscuridad"
Traducción al Español Ver. 1.0 (03/05/2024)
por Max1323 (Traducciones Max1323).
Basada en la gran traducción de LIPEMCO! Translations.
---------------------------------------------------
Descripción:
Moldoria, un mundo habitado por humanos y Magi, cada uno en su propio dominio.
La gente de ambos reinos pasaron sus vidas en paz.
Nunca hubo un motivo para una disputa entre ambas razas.
Sin embargo, hay alguien que conspira para ponerle un fin a esta paz.
Por desgracia, todavía nadie conoce esto.

Desarrollado: Rit's
Publicado:    SEGA
Lanzamiento:  30/10/1994 (JAP)
---------------------------------------------------
Acerca del proyecto:
-La traducción fue hecha gracias a Supper (Herramientas), TheMajinZenki (Traducción original), filler (Dumpeo del script), cccmar y Xanathis (Edición y Testeo original).

-Gracias a Wave por hacer una revisión de los textos.

-La mayoría de los textos están traducidos. Se agregaron
los caracteres españoles.

-Se traducieron algunos gráficos.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS (PC)
Utilizar UniPatcher (Android)
Utilizar Rom Patcher JS (Parcheador Online):
https://www.romhacking.net/patch/

Archivo IPS
Moldorian - Hikari to Yami no Sister (Japan).gg
File Size     512 KB
File MD5      95FB42E84A2B08ACCE481B0894EA3CEA        
File SHA-1    0DAD260B5357B2F61D1452BB73D8321CA53D7262
File CRC32    4D5D15FB