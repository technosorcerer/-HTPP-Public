patch by Revo:  http://www.slevinproduction.com/mastersystem/

- Start button not needed