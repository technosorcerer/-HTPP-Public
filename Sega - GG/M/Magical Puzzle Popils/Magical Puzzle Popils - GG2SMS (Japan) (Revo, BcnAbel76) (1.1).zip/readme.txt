!!Magical Puzzle Popils V1.1 GG2SMS Conversion by Revo and BcnAbel76 - 2017-05-10
*Fixed bad palette conversion in transitions, demo and intro game
*Restored START button in [d] 2Player (Editing levels and Options need it to menu-store data)
*Swap Stereo to PSG port, added lost audio effects

!!Magical Puzzle Popils V1.0 GG2SMS Conversion by Revo
* Start button not needed.