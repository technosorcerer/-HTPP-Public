Madou Monogatari I WIP v0.1 by Revo - 2015-11-25

* Start on down controller 2. 
* Strange bug on real hardware, maybe working with everdrive. 
* Original version (Jap) and translated version (English) available.