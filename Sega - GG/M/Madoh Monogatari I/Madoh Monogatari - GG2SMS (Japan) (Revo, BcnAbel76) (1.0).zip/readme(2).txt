Madou Monogatari I V0.9 GG2SMS English Conversion by BcnAbel76 - 2016-12-08

* START Button is Start, (needed Megadrive/Genesis controller) 
* Full palette conversion 
* No garbage :) 
* Fixed checksum, and master system rom 
* Added English translation, thank you filler, SSTranslations 
* Known bug pressing START will press UP, it does intro game escaped and go directly to game, help for fixing appreciate :) 
* Work in real hardware 




Madou Monogatari I WIP v0.1 by Revo - 2015-11-25

* Start on down controller 2. 
* Strange bug on real hardware, maybe working with everdrive. 
* Original version (Jap) and translated version (English) available.