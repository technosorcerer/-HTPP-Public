Mega Man GG2SMS conversion V0.1b by BcnAbel76 2016-09-14

* GG remanent port deleted, may cause game don't boot 
* Added phantom code for init game 
* Work in real hardware 
* Palette conversion no well corrected in game 



Mega Man GG2SMS conversion v0.1 by Vingazole - 2011-07-20

* Down arrow of the second controller is start.




http://www.smspower.org/Hacks/GameGearToMasterSystem