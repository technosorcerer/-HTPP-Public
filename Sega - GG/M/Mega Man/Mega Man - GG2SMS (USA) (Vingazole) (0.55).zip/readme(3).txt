Game Gear MegaMan is the only Sega 8 bits system game, I try to conversion to Master System for it 

After several days of rom hacking.. 
(Yesterday was a rainy day, It becames a intense work day) 


A small introduction: 

Megaman is created in USA exclusively by the company Freestyle, structure programming not look anything other ROM I've ever seen. 

The programming of the color palette is the foundation of this game, and that is where the conversion to Master System becomes tedious. 

Precisely the basis of Game Gear to Master System conversions is to detect writing palette, add a routine that modifies the data, and write it correctly. 

In this game I have detected a lot of hits to the palette, for example only 1 or 2 colors. This is strange because you usually write the entire palette. 

Game Gear data consist of 2 bytes and 1 byte Master System, that makes access to the palette is chaotic and nothing matches where must to go. 



Ladies and Gentlemen, 22 years before, and NOW !!!!!! 

MEGAMAN Playable at Sega Master System !!! 

----------------------------------------------------------------------------------------------------------
Mega Man GG2SMS conversion V0.52 by BcnAbel76 2016-11-13
- Deleted tile at boss select/intro screen 
- Adjusted colors to Master System palette at Sega, Capcom Logos and main menu screen 
- Thanks Revo to colaborate 
- Conversion by BcnAbel76






Mega Man GG2SMS conversion V0.51 by BcnAbel76 2016-09-27


- Moved life bar top up left , (thankyou vingazole) 
- Implemented left column blank (thankyou Revo) 




Mega Man GG2SMS conversion V0.5b by BcnAbel76 2016-09-23
- Detected and corrected multiple palette writing 
- Restored Megaman blinking routine 
- Fixed checksum, working in Real Hardware 
- Optimised code for clear palette, in some stages you shot enemy and "lights" turn off 
- Maybe you found in game some colors don't are ok, let me know if possible, savestate or similar, and for correct try to pause game, and continue playing, (I don't play all game for now) 
- Game looks now incredible :) 


For future versions: 
- I try to correct scroll and center the background is a bit more up than it must to be. 
- Remap Start Button 
- Move life bar top left



Mega Man GG2SMS conversion V0.2 by BcnAbel76 2016-09-20

- Game now is Playable (colors aproximate to original) 
- Real Hardware working 
- Enjoy ;) 
- It's hard to me trace routine with before hack, then I redone from "0" this hack. 
I do game playable with some bugs in game palette, but more near it should be. 
I extract the blinking palette routine when you continue pressing , causing a lot of palette errors, then you hear sound effect, but megaman or background don't flash 



Mega Man GG2SMS conversion V0.1c by BcnAbel76 2016-09-16

- Fixed Checksum for running in Real Hardware (Thankyou law81) 



Mega Man GG2SMS conversion V0.1b by BcnAbel76 2016-09-14

* GG remanent port deleted, may cause game don't boot 
* Added phantom code for init game 
* Work in real hardware 
* Palette conversion no well corrected in game 



Mega Man GG2SMS conversion v0.1 by Vingazole - 2011-07-20

* Down arrow of the second controller is start.




http://www.smspower.org/Hacks/GameGearToMasterSystem