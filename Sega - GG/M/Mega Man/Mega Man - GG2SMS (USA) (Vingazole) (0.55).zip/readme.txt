Mega Man GG2SMS conversion V0.2 by BcnAbel76 2016-09-20

- Game now is Playable (colors aproximate to original) 
- Real Hardware working 
- Enjoy ;) 
- It's hard to me trace routine with before hack, then I redone from "0" this hack. 
I do game playable with some bugs in game palette, but more near it should be. 
I extract the blinking palette routine when you continue pressing , causing a lot of palette errors, then you hear sound effect, but megaman or background don't flash 



Mega Man GG2SMS conversion V0.1c by BcnAbel76 2016-09-16

- Fixed Checksum for running in Real Hardware (Thankyou law81) 



Mega Man GG2SMS conversion V0.1b by BcnAbel76 2016-09-14

* GG remanent port deleted, may cause game don't boot 
* Added phantom code for init game 
* Work in real hardware 
* Palette conversion no well corrected in game 



Mega Man GG2SMS conversion v0.1 by Vingazole - 2011-07-20

* Down arrow of the second controller is start.




http://www.smspower.org/Hacks/GameGearToMasterSystem