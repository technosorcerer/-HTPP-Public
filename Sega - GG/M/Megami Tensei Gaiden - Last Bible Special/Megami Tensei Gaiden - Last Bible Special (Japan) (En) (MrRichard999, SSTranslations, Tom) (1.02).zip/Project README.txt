Megami Tensei Gaiden - Last Bible Special

ENGLISH TRANSLATION PATCH V1.02

RELEASE DATE 6/28/2018

WORK DONE BY...

Tom - Script translation
SSTranslations - Initial hacking work
Rainponcho - Critical edits/fixes, increasing dungeon speed, and ASM edits.
MrRichard999 - Resumed the project and fixed the remaining issues
Helly - Spot translation support for MrRichard999
GamerHengky - Initial beta testing
DDS - Helped in fixing bugs for Version 1.02

This translation project was lost in limbo for many years, but it has finally 
been completed. Megaten Gaiden Last Bible S, or Last Bible Special, is a dungeon
crawler offshoot of the Megami Tensei Gaiden Last Bible series. This title, only
released on the Game Gear, is probably one of the most unforgiving and difficult
games in the series. One of the reasons the game was stalled for so long was 
because of how punishing the game can be. Beating the game without relying on 
cheats is quite a feat.

The title screen graphics have been replaced, dungeon movement has been sped up 
(due to how slow it was previously), and enemy encounters were slightly reduced 
as the rate was at a ridiculous level. Also, the start button, which originally 
had no function, has been changed into an on-the-fly mute button. If the 
soundtrack gets on your nerves, just hit start, and the music will either fade 
out or fade in at your command. (The sound effects will always play.)
We hope you enjoy this release! If you have any questions, please feel free to 
contact either Tom through twitter (@RetroTranslator) or MrRichard999 on RHDN.

Included is a Vanilla patch which has just the translation and a modded patch with the adjusted turn speed & a more modest encounter rate. Each patch should only be applied to a clean original Japanese ROM.

VERSION 1.01 UPDATE
-Minor text correction for after picking up the Pyramid at Ignis Fort.


For those who wish to adjust the values for enemy encounters in the game, here is some data that Rainponcho provided:

Edit ROM at address 57cc:
- 00 = guaranteed
- 01 = very low to no encounters
- 02 = pretty low
- 03 = decent (17-23)
- 04 = ~11-15? (Our Default)
- 05 = default, annoying (Japanese Default)
- 06+ = >_>

Also if you wish to make it so weapons never break (which is very frustrating!):

Edit ROM at address 5f6d4 to = c3 ==> No weapons breaking cheat!

VERSION 1.02 UPDATE

- Fixed a bug at the fountain with the text display
- Fixed a bug where confronting Hoenheim displayed a text error.