!!Megami Tensei Gaiden Last Bible Special v0.6 GG2SMS Conversion by BcnAbel76 2017-08-17
*Megadrive or Master System Pads switching with [Pause] Button, START is MD [Start] button or MS 2nd Player [d] (Default: MD Pad)
*Full palette conversion
*Removed GG ports
*Translation Credits to MrRichard999, SSTranslations (Steven Seehorn), Tom, Helly, Hengki Kusuma Adi, rainponcho
*Game funny playable, remember SRAM needed to store data
*Patch Japanese Rom
*Corrected Checksum

Known "bugs"
*For now intro music is running fast, if possible set console to 50Hz