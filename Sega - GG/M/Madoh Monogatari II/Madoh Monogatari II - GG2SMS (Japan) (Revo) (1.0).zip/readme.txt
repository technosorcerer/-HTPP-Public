Madou Monogatari II WIP v0.1 by Revo - 2015-11-25

* Start on down controller 2. 
* Japanese only. 
* Probably the same bug on real hardware than Madou Monogatari I.