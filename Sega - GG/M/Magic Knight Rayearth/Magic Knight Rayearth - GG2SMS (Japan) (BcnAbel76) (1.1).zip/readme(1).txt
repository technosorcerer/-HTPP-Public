Magic Knight Rayearth V1.0 GG2SMS Conversion by BcnAbel76 - 2017-01-25
* Full palette conversion 
* Start is 2nd controller down arrow 
* Full japanese 
* Fixed Checksum 

