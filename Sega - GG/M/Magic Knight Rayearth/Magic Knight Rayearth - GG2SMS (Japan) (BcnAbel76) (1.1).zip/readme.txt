!!Magic Knight Rayearth V1.1 ENGLISH GG2SMS Conversion by BcnAbel76 - 2019-02-18

Translation Credits goes to:
*Supper (Hacking)
*filler (Translation)

GG2SMS

*Removed wrong tiles
*[d] arrow is "START"
*Compatible version with fan translation

(DO NOT DOUBLE PATCH ROM!!!, included English, patch original GG Rom )

!!Magic Knight Rayearth V1.0 GG2SMS Conversion by BcnAbel76 - 2017-01-25
* Full palette conversion 
* Start is 2nd controller down arrow 
* Full japanese 
* Fixed Checksum