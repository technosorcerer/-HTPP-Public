patch by Revo:  http://www.slevinproduction.com/mastersystem/

v1 changes:
- No more garbage screen. 
- Improvement on Spectrum Holobyte logo screen and Bullet-Proof Software logo screen. 
All credit for this version come to Ichigobankai.


v0.2 changes:

- Start button configure on button 1 (thanks to sverx) 
- Pause button crash fixed (thanks to sverx) 
- palette update 
- full logo but garbage screen 
- title screen arrangement.