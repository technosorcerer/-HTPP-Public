patch by Revo:  http://www.slevinproduction.com/mastersystem/

- Spectrum Holobyte logo, Bullet-Proof Software logo and title screen are cut to limit garbage screen.
- Start is configure on down player 2.
- Pause button make freeze the game (forever).
- Don't know if all the colors are converted, didn't play the game a lot yet.