patch by Revo:  http://www.slevinproduction.com/mastersystem/

- Start button configure on button 1 (thanks to sverx) 
- Pause button crash fixed (thanks to sverx) 
- palette update 
- full logo but garbage screen 
- title screen arrangement.