patch by Revo:  http://www.slevinproduction.com/mastersystem/

Start on down controller 2 (not always needed in the menu)