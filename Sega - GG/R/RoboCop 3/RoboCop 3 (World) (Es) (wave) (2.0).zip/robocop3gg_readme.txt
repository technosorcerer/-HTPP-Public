RoboCop 3 (Game Gear)
Traducción al Español v2.0 (01/02/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Guion retraducido
-Añadidos Á y Ó
-Traducido GAME OVER

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
RoboCop 3 (World).gg
MD5: ae7121e6ce2831e1b700515b6060acaf
SHA1: 8de7c9ac95b734af9e3fbe5700ac4c6599799702
CRC32: 069a0704
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --