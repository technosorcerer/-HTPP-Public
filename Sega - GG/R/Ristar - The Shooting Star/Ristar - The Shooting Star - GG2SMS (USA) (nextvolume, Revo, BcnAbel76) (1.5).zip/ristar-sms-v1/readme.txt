Ristar the Shooting Star SMS patch
by nextvolume <tails92@gmail.com> (http://unhaut.fav.cc)

First release v1
-------

This is the first release of this patch that allows you to play Ristar, a game released in 1995 by SEGA for the Game Gear, on your Master System.

The game works well, and is playable.
There is garbage on the borders of the screen, but it doesn't affect gameplay.

The Game Gear START button is mapped to Button 1 on the Master System, except during gameplay, where it is mapped to the Pause button.
In some instances where both START and Button 1 were mapped to an action, the buttons have been inverted: one such example is the Sound Menu, where once Button 1 paused the music, and START exited the menu.
Now Pause pauses the music, and Button 1 exits the menu.

The patch applies to a ROM image of the European and American version of the Ristar cartridge.

In this archive other than for the IPS format patch, named `ristar_sms.ips', you can find the full source code of the injected code snippets that were used to make the patch; this means that if you are technically versed, you can improve the patch yourself.
The Makefile is very simple and easily understood; to build the patch, simply run `make'.
The ROM image must be placed in this directory and named `ristar_orig.sms'; the patched ROM after running `make' will be named `ristar.sms'.
The Makefile assumes you are on a Unix-like operating system; if you are on Windows you can try using MSYS or Cygwin.

The assembler you will need to use is z80asm (http://www.nongnu.org/z80asm/)

inject, fixsum, nop and putstring were written by me (nextvolume), they will respectively inject a code snippet, fix the ROM checksum, insert NOP instructions in the ROM and insert a string in the ROM; do whatever you want with them, but give credit.

Enjoy!

-nextvolume
31st May 2014
