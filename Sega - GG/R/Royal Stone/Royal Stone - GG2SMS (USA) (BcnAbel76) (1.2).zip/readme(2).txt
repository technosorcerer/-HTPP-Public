!!Royal Stone V1.1 GG2SMS Conversion pack by BcnAbel76 - 2017-04-21

This pack consists of 4 ips patches:

Royal Stone ENG V1.1

*Megadrive Pad Required, START is now START Button (Best Gameplay)
*Left Column Blank Active
*Game is in English (Credits go to AeonGenesis)
*Optimised Code

Royal Stone JAP V1.1

*Megadrive Pad Required, START is now START Button (Best Gameplay)
*Left Column Blank Active
*Game is in JAPANESE
*Optimised Code

Royal Stone ENG Developer V1.1

*Not for gaming!!! Palette not converted!!!!
*Minimal Hack, only for game inits, GG Ports Removed
*START is 2nd Controller "DOWN"
*Game is in English (Credits go to AeonGenesis)

Royal Stone JAP Developer V1.1

*Not for gaming!!! Palette not converted!!!!
*Extreme Minimal Hack, only for game inits, GG Ports Removed
*START is 2nd Controller "DOWN"
*Game is in JAPANESE

Choose your language and patch original Game Gear Rom
Then if anytime a bug appears choose developer patch, try to backup your data file to your hard disk, and continue "gaming/testing" with developer rom to determinate if bug is for hacking or for original game

This is an extract about Aeon Genesis describes about known bugs:

--------------
4.Known Issues
--------------
--Some minor graphical garbage appears on certain animation frames
during combat sequences. Only occurs on some emulators (happens
when using Dega, but not with Meka or Bizhawk.) OK in Emulicious

There are a few known issues with the game itself not caused by the patch:
--In Round 15, there are two major foes - an enemy commander and an underling.
If the commander is killed before his cutscene with the underling, the game
crashes.
--After promoting a character to the Evoker class, it's possible to dismiss a
monster that doesn't exist. It's also possible to select this monster in
battle, which can cause unpredictable results.
--Scrolling through the spell list too fast during combat sequences can cause
incorrect text to be displayed. The spells will still function correctly,
however.

Please report any bugs, spelling errors, and such
on The Pantheon (http://agtp.romhack.net/pantheon)
Screenshots are preferred, as are savestates.

!!Royal Stone V1.0 GG2SMS Conversion by BcnAbel76 - 2016-09-19
* "Down Arrow" 2nd controller is Start/Pause 
* Full palette conversion 
* Fixed checksum for Real Hardware 
* Now is a Master System Rom 
* Adjust some colors to Master System palette 
* GG ports removed 
* Some garbage arround screen 
* Game playable, enjoy! 
* Thanks Angela for be patient ;) 
* Japanese or English Patch