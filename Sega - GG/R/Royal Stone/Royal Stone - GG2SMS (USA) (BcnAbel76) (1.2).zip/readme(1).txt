Royal Stone V1.0 GG2SMS Conversion by BcnAbel76 - 2016-09-19

- "Down Arrow" 2nd controller is Start/Pause 
- Full palette conversion 
- Fixed checksum for Real Hardware 
- Now is a Master System Rom 
- Adjust some colors to Master System palette 
- GG ports removed 
- Some garbage arround screen 
- Game playable, enjoy! 
- Thanks Angela for be patient ;) 
- Japanese or English Patch 