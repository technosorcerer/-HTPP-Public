Help Dickfall Jerry collect as much lost treasue from the Junkle of Chodes before the world ends! You have 20 minutes.

patch to a "Pitfall! (1982) (Activision) [!].a26" a get to gettin!