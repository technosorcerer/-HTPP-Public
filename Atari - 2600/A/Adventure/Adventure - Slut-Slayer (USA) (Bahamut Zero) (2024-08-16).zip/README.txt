Twelve foot tall super skanks are invading the kingdom! Grab your golden dildo and protect us, oh mighty Slut Slayer!

Patch to a Adventure (1978) (Atari) [!].a26 and get a slayin'!