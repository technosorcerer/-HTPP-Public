::========================================
::Astroblast (Rainbow Brite Mod)
::By eskayelle
::January 2020
::========================================
::
::**CONTENTS**
::
::*****INTRODUCTION*****
::*****TOOLS USED*****
::*****INSTRUCTIONS*****
::*****SPECIAL THANKS*****
::*****BATCH FILE ASSEMBLY*****
::
::
::*****INTRODUCTION*****
::Aside from Gulliver's Triple Challenge, a Pong clone from the 1970s,
::the first video game I'd ever played was Astroblast for Atari.
::Developed by Hal Finney as a port of the Intellivision's Astrosmash,
::this game was my first foray into cartridges and joysticks.
::
::One of my favorite memories of this game was a four year-old me hitting 1,000 points one night in the mid-80s,
::just a few days after we'd purchased it.  
::Not knowing what to expect, and having no exposure to video games other than that Pong clone,
::my dad's first reaction was to shout, "You blew up the TV!"
::I'm sure there were a few expletives peppered in there; those were the times...
::
::Astroblast being my first real video game love, I played the heck out of out,
::through elementary school, high school, and just after college.
::(I still break it out every now and then, which helped prompt me to work on these mods.)
::My family held little tournaments on holidays to see who could take the highest score.
::A simple game really, it was a great bonding tool, and it really defined Atari's motto back then:
::Easy to play; difficult to master.
::
::The purpose of these Astroblast hacks is twofold:
::1) To remove the ROM's access to the paddles.
::Astroblast is the one game designed for Atari that permitted both paddle and joystick play,
::paddle being the better bet for ease of play and higher scores...
::... but we didn't all have paddles (I didn't till after college...).
::
::And... with some emulators, the default is to read as if paddles are active, 
::making gameplay difficult on a d-pad or analog stick due to the much higher paddle input object velocity.
::These hacks effectively eliminate the paddle read and force the joystick input object velocity instead.
::This makes the game more enjoyable on an Atari Flashback, or a PSP, a DS, a modified Arcade 1up with Odroid/Raspberry Pi...
::
::2) With more joystick-centered gameplay, to enhance the experience when using a joystick or d-pad.
::(Remember... original Astroblast is optimally played when using paddles, 
::so the Rainbow Brite Mod accommodates for that by being friendlier with scoring penalties,
::and by giving a lot more tastes of the various difficulty levels,
::that last difficulty extremely hard to attain and keep up with in the original game with just a joystick.)
::
::
::The following romhacks are distributed as separate IPS patches, which should each be patched to an original NTSC Astroblast ROM:
::Astroblast (Rainbow Brite Mod) (2020) (Double Z) (h)
::
::Use a tool like LunarIPS (Windows) or UniPatcher (Android) to patch one of the above mods to your Astroblast ROM.
::The patched ROM then can be opened and played via several emulators, including in Windows, Linux, and Android environments.
::
::The following is a list of known Windows or Android emulators within which this ROM works;
::note that it also works with Raspberry Pi/RetroArch. 
::
::Windows--
::1) Stella 6.0
::2) RetroArch build date Feb 3 2019
::
::Android--
::1) 2600.emu v1.5.37
::
::This romhack provides the following enhancements to the Astroblast experience:
::
::Astroblast (Rainbow Brite Mod) (2020) (Double Z) (h)
::1) Removes the paddle capability in favor of joysticks ("Without a Paddle" mod).
::2) Forces the game to rotate among the 5 difficulty settings every 200 points.
::At 100,000 points, the hardest difficulty level is set and maintained ("Controlled Chaos" / "Rainbow Brite" mods).
::3) Reduces the penalty incurred when a base is destroyed ("Sweet Dreams" mod).
::
::
::*****TOOLS USED*****
::1) DASM
::2) XVI32
::3) Stella 6.0
::
::
::*****INSTRUCTIONS*****
::Head over to AtariAge for instructions on how to play the original game.  
::This hack does not modify gameplay other than removing the ability to use paddles,
::removing the background color changes, cycling difficulty settings every 200 points,
::and reducing the penalty for a destroyed base.
::
::www.atariage.com/manual_html_page.php?SoftwareID=832
::
::
::*****SPECIAL THANKS*****
::1) To Hal Finney, for making a great game that fostered my love for video games over the years.
::2) To Dennis Debro, for taking the time to reverse engineer Astroblast and put his findings to public domain.
::3) To Andrew Davie, for his awesome Atari 2600 Programming for Newbies guide.
::4) To my dad, for the fond memories of Astroblast throughout the years.  I owe you one TV...
::
::
::*****BATCH FILE ASSEMBLY*****
::Rainbow Brite v2
dasm "Astroblast (Rainbow Brite Mod v2) (2020) (Double Z) (h).asm" -lastroblast-cc.txt -f3 -v5 -o"Astroblast (Rainbow Brite Mod v2) (2020) (Double Z) (h).bin"
fc /B "Astroblast (Rainbow Brite Mod v2) (2020) (Double Z) (h).bin" "Astroblast (1982) (Mattel) (!).a26" > astroblastcompare-cc.txt
@pause
