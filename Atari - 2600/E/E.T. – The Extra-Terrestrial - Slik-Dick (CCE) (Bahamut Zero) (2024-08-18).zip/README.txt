Help Slik, the sentient space penis, gather enough pube tech and become the most influential politician on his home planet! 

Patch to a E.T. - The Extra-Terrestrial (CCE).bin rom