Star Force (SG-1000)
Traducción al Español v1.0 (27/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Star Force (SG-1000) [!].sg
MD5: 2cbd1f9f4927f9618390340f56f116a6
SHA1: d38875cb08de0ea892e5ef80f93987bbc445ef8f
CRC32: b846b52a
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --