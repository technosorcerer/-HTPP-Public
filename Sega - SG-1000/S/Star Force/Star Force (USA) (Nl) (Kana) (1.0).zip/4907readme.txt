Language patch (text only)
Language: Dutch

--------------------------
Star Force (SG-1000)
--------------------------

Vertaling naar het Nederlands
Versie: 1.0
Datum: 06/08/2019
(c) 2019 Kana Translations

--------------------------
Opmerkingen bij deze patch
--------------------------
Deze vertaling en hack is geheel oorspronkelijk.

--------------------------
Patch-instructies
--------------------------
De patch heeft de IPS-indeling, en kan worden toegpast
met LunarIPS of Floating IPS.

--------------------------
Spelinformatie
--------------------------
Gebruikt oorspronkelijk bronbestand:

Star Force (Japan).sg
MD5: 2cbd1f9f4927f9618390340f56f116a6
SHA1: d38875cb08de0ea892e5ef80f93987bbc445ef8f
CRC32: b846b52a
32768 bytes

--------------------------
Dankwoord/Credits
--------------------------
Kana - Nederlandse vertaling en hack

--------------------------
Very special thanks
--------------------------
Wave - voor het briljante programma Hextractor, website:
traduccioneswave.blogspot.com

-- EINDE --