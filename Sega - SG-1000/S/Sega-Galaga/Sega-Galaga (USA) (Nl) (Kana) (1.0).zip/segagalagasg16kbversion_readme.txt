Language patch (text only)
Language: Dutch

--------------------------
Sega-Galaga (SG-1000)
--------------------------

Vertaling naar het Nederlands
Versie: 1.0
Datum: 02/08/2019
(c) 2019 Kana Translations

--------------------------
Opmerkingen bij deze patch
--------------------------
Deze vertaling en hack is geheel oorspronkelijk.

--------------------------
Patch-instructies
--------------------------
De patch heeft de IPS-indeling, en kan worden toegpast
met LunarIPS of Floating IPS.

--------------------------
Spelinformatie
--------------------------
Gebruikt oorspronkelijk bronbestand:

Sega-Galaga (Japan) (16kB).sg
MD5: e2619cf7c307ac1916c534519f6043d9
SHA1: 32e776b3a17f7c0df0fa9eb49a3e451cfe702bfd
CRC32: 981e36c1
16384 bytes

--------------------------
Dankwoord/Credits
--------------------------
Kana - Nederlandse vertaling en hack

--------------------------
Very special thanks
--------------------------
Wave - voor het briljante programma Hextractor, website:
traduccioneswave.blogspot.com

-- EINDE --