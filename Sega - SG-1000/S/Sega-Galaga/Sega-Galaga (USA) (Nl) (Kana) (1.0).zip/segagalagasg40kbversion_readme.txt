Language patch (text only)
Language: Dutch

--------------------------
Sega-Galaga (SG-1000)
--------------------------

Vertaling naar het Nederlands
Versie: 1.0
Datum: 02/08/2019
(c) 2019 Kana Translations

--------------------------
Opmerkingen bij deze patch
--------------------------
Deze vertaling en hack is geheel oorspronkelijk.

--------------------------
Patch-instructies
--------------------------
De patch heeft de IPS-indeling, en kan worden toegpast
met LunarIPS of Floating IPS.

--------------------------
Spelinformatie
--------------------------
Gebruikt oorspronkelijk bronbestand:

Sega-Galaga (Japan) (40kB).sg
MD5: 7f7e1d564448fdce96d239ad9ebf37d6
SHA1: 9b093878f92ce8b918beaa44dcc8a41282f9f267
CRC32: 31283003
40960 bytes

--------------------------
Dankwoord/Credits
--------------------------
Kana - Nederlandse vertaling en hack

--------------------------
Very special thanks
--------------------------
Wave - voor het briljante programma Hextractor, website:
traduccioneswave.blogspot.com

-- EINDE --