Zoom 909 (SG-1000)
Traducción al Español v1.0 (05/12/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Zoom 909 (Taiwan).sg
MD5: d99925f7b3fa1961906f169b61f1a492
SHA1: 7a998a0da19471f7e3e5bd82a9fbaf82a966ee40
CRC32: 9943fc2b
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --