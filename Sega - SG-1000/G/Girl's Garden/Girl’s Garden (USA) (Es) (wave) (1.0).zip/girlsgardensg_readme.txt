Girl's Garden (SG-1000)
Traducción al Español v1.0 (13/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Girl's Garden (SG-1000).sg
MD5: ac95c0655360f667e3ad705e2eb7367a
SHA1: 0e08786587fb76909b3f9806ba1f5d57ea17728c
CRC32: 1898f274
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --