Orguss (SG-1000)
Traducci�n al Espa�ol v1.0 (16/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Orguss (SG-1000).sg
MD5: 0f45fa8e9b985fd5c6545645462b9400
SHA1: c50b133dac95718e3a92a7ed45b6c7e83927abb0
CRC32: f4f78b76
32.768 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --