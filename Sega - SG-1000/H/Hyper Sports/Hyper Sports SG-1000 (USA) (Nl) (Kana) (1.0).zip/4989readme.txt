Language patch (text only)
Language: Dutch

--------------------------
Hyper Sports (SG-1000)
--------------------------

Vertaling naar het Nederlands
Versie: 1.0
Datum: 09/09/2019
(c) 2019 Kana Translations

--------------------------
Opmerkingen bij deze patch
--------------------------
Deze vertaling en hack is geheel oorspronkelijk.

--------------------------
Patch-instructies
--------------------------
De patch heeft de IPS-indeling, en kan worden toegpast
met LunarIPS of Floating IPS.

--------------------------
Spelinformatie
--------------------------
Gebruikt oorspronkelijk bronbestand:

Hyper Sports (Japan).sg
MD5: d8e6d89d520c91a9ea219291b55284bb
SHA1: 8a13ee297f861f436b9529a5e2193cb697baa56f
CRC32: ba09a0fd
32768 bytes

--------------------------
Dankwoord/Credits
--------------------------
Kana - Nederlandse vertaling en hack

--------------------------
Very special thanks
--------------------------
Wave - voor het briljante programma Hextractor, website:
traduccioneswave.blogspot.com

-- EINDE --