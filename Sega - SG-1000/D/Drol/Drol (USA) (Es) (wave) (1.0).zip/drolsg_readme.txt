Drol (SG-1000)
Traducción al Español v1.0 (11/09/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Drol (SG-1000).sg
MD5: 8eb2ab42d2bc3f3568e85cba2b46a251
SHA1: 607b2b9a946eaaebb938800bd3b1df7d9342388c
CRC32: 288940cb
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --