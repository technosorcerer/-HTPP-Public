Doki Doki Penguin Land (SG-1000)
Traducción al Español v1.0 (05/12/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Doki Doki Penguin Land (SG-1000).sg
MD5: c9412b2aa1de5070734297573dba7132
SHA1: 176e2d2648b20e6fac823021697138803ef38b27
CRC32: fdc095bc
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --