Championship Loderunner (SG-1000)
Traducción al Español v1.0 (11/09/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Championship Loderunner (SG-1000).sg
MD5: f49d9ea611ccb9289994774406f20d06
SHA1: a0dad095489da2bdf8ec03f1acc83f809db2371f
CRC32: 11db4b1d
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --