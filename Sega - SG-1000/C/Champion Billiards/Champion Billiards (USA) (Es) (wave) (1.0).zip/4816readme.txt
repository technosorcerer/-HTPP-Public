Champion Billards (SG-1000)
Traducción al Español v1.0 (11/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Champion Billards (SG-1000) [!].sg
MD5: 71c32b1cf1e85d217421068ac8ccc655
SHA1: f517e6a6123643a5e7e5fff6b413139afa412d8e
CRC32: 62b21e31
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --