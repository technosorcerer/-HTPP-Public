Language patch (text only)
Language: Dutch

--------------------------
Exerion (SG-1000)
--------------------------

Vertaling naar het Nederlands
Versie: 1.0
Datum: 07/08/2019
(c) 2019 Kana Translations

--------------------------
Opmerkingen bij deze patch
--------------------------
Deze vertaling en hack is geheel oorspronkelijk.

--------------------------
Patch-instructies
--------------------------
De patch heeft de IPS-indeling, en kan worden toegpast
met LunarIPS of Floating IPS.

--------------------------
Spelinformatie
--------------------------
Gebruikt oorspronkelijk bronbestand:

Exerion (Japan, Europe).sg
MD5: 7f0ae039dd072d825ebfd2d3bf02a2a0
SHA1: 839e19487b96d02222ff397b047cbc6a0fbc08ff
CRC32: a2c45b61
16384 bytes

--------------------------
Dankwoord/Credits
--------------------------
Kana - Nederlandse vertaling en hack

--------------------------
Very special thanks
--------------------------
Wave - voor het briljante programma Hextractor, website:
traduccioneswave.blogspot.com

-- EINDE --