Exerion (SG-1000)
Traducción al Español v1.0 (18/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Exerion (SG-1000) [!].sg
MD5: 7f0ae039dd072d825ebfd2d3bf02a2a0
SHA1: 839e19487b96d02222ff397b047cbc6a0fbc08ff
CRC32: a2c45b61
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --