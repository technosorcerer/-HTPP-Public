Nova Blast (Colecovision)
Traducción al Español v1.0 (24/12/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Nova Blast (1983) (Imagic) [!].col
MD5: daba4037e3034b0ac3ab2ced264370e9
SHA1: d42f8620c9c7bc099ed0f4005f989189c766f57f
CRC32: ea06f585
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --