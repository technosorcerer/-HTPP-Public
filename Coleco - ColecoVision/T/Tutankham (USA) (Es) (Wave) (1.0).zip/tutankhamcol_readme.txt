Tutankham (Colecovision)
Traducción al Español v1.0 (01/02/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tutankham (USA).col
MD5: 79db029b4e77bc2752ab97bd4df03428
SHA1: a668ff92e6f83e37f44178260618bbc650ca61c9
CRC32: 0408f58c
12288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --