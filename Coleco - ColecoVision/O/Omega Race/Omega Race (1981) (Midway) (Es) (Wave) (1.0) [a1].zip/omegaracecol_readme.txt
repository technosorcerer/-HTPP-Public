Omega Race (Colecovision)
Traducción al Español v1.0 (31/12/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Omega Race (1981-83) (Midway).col
MD5: e7af8dc8712a761c418e91598a5eee1c
SHA1: 84f4b6fa6ab30b6c2e2b79bf61c5bb3421530303
CRC32: 9921ecb5
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --