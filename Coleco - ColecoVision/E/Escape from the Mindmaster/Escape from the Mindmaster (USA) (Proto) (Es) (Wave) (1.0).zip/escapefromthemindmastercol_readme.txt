Escape From The Mind Master (Colecovision)
Traducción al Español v1.0 (10/12/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Escape From The Mind Master (1983) (Starpath) (Prototype).col
MD5: abe178883b62a738c692a2656a03a77e
SHA1: 00c157e87a8f85ede84b26bfab018c50678f88e4
CRC32: 3678ab6f
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --