Evolution (Colecovision)
Traducción al Español v1.0 (04/02/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Evolution (1983) (Sydney).col
MD5: 74b7a74c714c1be14d58124e6f9797ab
SHA1: acc3f1f3a7c129d736c3625667a3c1d942f12bbe
CRC32: dff01cf7
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --