James Bond 007 (Colecovision)
Traducción al Español v1.0 (15/02/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
James Bond 007 (USA).col
MD5: c7ea91d9ac4d4a104d8e7832f8db3962
SHA1: 22ee76c680e94fa016263473d0ffdbed1ea5ab7b
CRC32: 561f2530
12288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --