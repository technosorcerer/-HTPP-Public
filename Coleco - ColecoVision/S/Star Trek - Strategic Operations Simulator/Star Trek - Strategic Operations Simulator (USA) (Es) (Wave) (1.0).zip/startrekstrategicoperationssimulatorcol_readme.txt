Star Trek - Strategic Operations Simulator (Colecovision)
Traducción al Español v1.0 (22/02/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Star Trek - Strategic Operations Simulator (USA).col
MD5: 45006eaf52ee16ddcadd1dca68b265c8
SHA1: d37140e1abd1a0402af5c9e02ab3e4d0c6afe598
CRC32: 95824f1e
24576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --