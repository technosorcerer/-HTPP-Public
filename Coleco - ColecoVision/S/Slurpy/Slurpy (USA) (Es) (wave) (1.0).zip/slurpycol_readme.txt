Slurpy (Colecovision)
Traducción al Español v1.0 (15/10/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Slurpy (1984) (Xonox).col
MD5: 1240edfec95508e1e0400cc5a557ab4b
SHA1: ef01edb9f1ec6c01323f81ff03fd077dea50f105
CRC32: 27f5c0ad
24576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --