The Lion King
Traducci�n al Espa�ol v1.0 (24/02/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre The Lion King
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre The Lion King
-----------------
Adaptaci�n de la pel�cula de animaci�n de Disney.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Lion King, The (E) [!].sms
524.288	bytes
CRC32: c352c7eb
MD5: e50336c0d146e8a341c7ae198a016527
SHA1: 3a64657e3523a5da1b99db9d89b1a48ed4ccc5ed

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --