Lord of the Sword (Master System)
Traducci�n al Espa�ol v1.0 (16/01/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Lord of the Sword (USA, Europe).sms
MD5: b80f87887881343e5705ff3cce93c5f1
SHA1: a5326a0029f7c3101add3335a599a01ccd7634c5
CRC32: e8511b08
262.144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --