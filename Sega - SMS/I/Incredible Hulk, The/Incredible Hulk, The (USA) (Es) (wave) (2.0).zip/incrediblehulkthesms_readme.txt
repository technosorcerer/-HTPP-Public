The Incredible Hulk (Master System)
Traducción al Español v2.0 (20/02/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0: Añadidos acentos y revisión de script

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Incredible Hulk, The (Europe, Brazil).sms
MD5: 285d996c1d7dbf38458df61c28bbaa01
SHA1: 235ad7d259023610d8aa59d066aaf0dba2ff8138
CRC32: be9a7071
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --