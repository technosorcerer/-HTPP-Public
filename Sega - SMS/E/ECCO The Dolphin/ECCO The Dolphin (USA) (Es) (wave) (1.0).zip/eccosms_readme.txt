Ecco the Dolphin (Master System)
Traducci�n al Espa�ol v1.0 (28/09/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ecco the Dolphin (UE).sms
MD5: bea00f9b73ac248bafa7e406a5489b32
SHA1: 3bfdef48f27f2e53e2c31cb9626606a1541889dd
CRC32: 6687fab9
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --