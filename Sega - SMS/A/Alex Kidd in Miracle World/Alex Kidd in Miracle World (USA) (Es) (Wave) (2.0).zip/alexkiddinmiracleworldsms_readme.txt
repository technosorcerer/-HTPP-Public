Alex Kidd in Miracle World (Master System)
Traducción al Español v2.0 (16/06/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Añadida rutina para escribir tildes encima de las letras
-Guion reescrito y adaptado
-Traducido gráfico SCORE
-Traducido gráfico SHOP
-Traducidas partes del título

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Alex Kidd in Miracle World (USA, Europe) (Rev 1).sms
MD5: f43e74ffec58ddf62f0b8667d31f22c0
SHA1: 6d052e0cca3f2712434efd856f733c03011be41c
CRC32: aed9aac4
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --