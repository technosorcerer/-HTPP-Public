Questa patch traduce in italiano il gioco identificato dal No-Intro come: 
Alex Kidd in Miracle World (USA, Europe) (v1.1)

Ecco a voi un altro gioco tradotto in italiano. Per la traduzione mi sono servito dell'ottimo editor KiddEd di Calindro (https://www.romhacking.net/utilities/1111/). Per alcuni fix ho comunque dovuto usare le maniere forti con hack asm e spostamento puntatori. 
Di questa traduzione ne fornir� 2 versioni. Una come l'originale del 1986 in cui Alex mangia una palla di riso ed un'altra come la versione incorporata del 1990 in cui Alex mangia un hamburger.

Comunque ecco le caratteristiche:

* Spostamento di tutte le vignette della schermata del titolo per far posto ad altra grafica.
* Aggiunta una linea sul bordo sinistro delle 2 vignette del titolo a sinistra mancante anche sull'originale. 
* Fixata la cifra 0 finale dei soldi mostrati nella schermata di pausa che era colorata leggermente giallognola.
* Fixata anche la cifra delle vite sempre nella schermata di pausa (in questo caso l'errore appariva solo la prima volta che si richiamava pausa), che veniva mostrata sempre giallognola.
* Fixata la grafica del sacco dei soldi sempre nella schermata di pausa che appariva leggermente sfasata.
* Uniformata la grafica dei sacchi dei soldi gi� presenti in gioco da quelli che trovi rompendo i blocchi. Adesso il simbolo in basso � sempre arrotondato.
* Fixata la posizione della palla di riso (o hamburger) alla fine di alcuni livelli perch� appariva leggermente sfasata.
* Fixata la grafica di Janken pietrificato che appariva corrotta sul lato destro.
* Invertiti i controlli di salto e pugno ma lasciando inalterato la funzione del tasto 2 per la modalit� segreta continua. L'editor Kidded spostava anche questa sul tasto 1.
* Aggiunto il supporto per il pad megadrive e la comodit� del tasto pausa sul joypad.
* Tradotti tutti i testi compresa l'insegna dei negozi e la grafica dei punti nella schermata di pausa.
* Per la versione con l'hamburger ricopiata a mano un pixel alla volta la grafica dalla versione del 1990.
* Altri fix vari che non ricordo.

Ver. 1.1

* Fix del checksum delle rom.

Ver. 1.2

* La spiegazione per la morra cinese era sbagliata in quanto affermava di dover vincere 3 partite quando in realt� ne bastano 2. Cercando di trovare una traduzione pi� fedele ho provato la rom giapponese ed ho scoperto che durante l'incontro in alto oltre al nome di Alex compare anche il nome del nemico. Questo mi ha stimolato ad aggiungere anche questa chicca alla mia traduzione importando e modificando opportunamente il codice asm dalla vesione jap alla mia. Ed ho corretto anche il testo della spiegazione.
* Quando Alex lampeggiava per l'invincibilit� se presenti su schermo lampeggiavano anche l'omino di 1-UP, un paio di pixel del nemico fiamma, ed il condimento dell'hamburger, qualche pixel di Igul nel castello di Radaxian ed il corno di Janken durante la morra. Adesso correttamente non lampeggiano pi�. 


(C) 2024 Di Somma Michele
mike.1983@libero.it