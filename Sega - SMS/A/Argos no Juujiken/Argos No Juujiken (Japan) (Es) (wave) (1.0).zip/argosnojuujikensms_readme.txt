Argos no Juujiken (Master System)
Traducción al Español v1.0 (27/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Argos no Juujiken (J) [!].sms
MD5: 8e8b04b5a9fe7b6cdb25b6550e7a831e
SHA1: a4b63ed417380f8170091e66c0417123799a731f
CRC32: bae75805
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --