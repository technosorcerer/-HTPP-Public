Global Defense (Master System)
Traducción al Español v1.0 (29/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Global Defense (UE) [!].sms
MD5: 7ab485ee37ea7ce538f7dba08b64d95e
SHA1: 189ee1d4250a1f33e97053aa804a97b4e1467728
CRC32: b746a6f5
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --