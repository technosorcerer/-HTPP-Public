Ghouls'n Ghosts (Master System)
Traducción al Español v2.0 (23/03/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Cambiado zapatillas por botas
-Guion reescrito
-Textos recolocados y ampliados
-Invertidos textos de tienda para sentido español
-Cambiada posición de equipo en menú para tener más espacio

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ghouls'n Ghosts (USA, Europe).sms
MD5: 85707b3a74483910699ccc4ba20c64ff
SHA1: b193e624795b2beb741249981d621cb650c658db
CRC32: 7a92eba6
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --