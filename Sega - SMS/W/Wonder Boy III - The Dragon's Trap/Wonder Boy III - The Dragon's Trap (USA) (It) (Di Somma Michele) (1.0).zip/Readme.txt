Questa patch traduce in italiano il gioco identificato dal No-Intro come: 
Wonder Boy III - The Dragon's Trap (USA, Europe)

La creazione di questa patch � stata abbastanza veloce, i testi nel gioco sono pochi anche se ho dovuto apportare alcune modifiche asm e modifiche puntatori per problemi di spazio. Ho corretto anche un errore di inizializzazione del colore di sfondo in quanto facendo partire la rom da alcune flash cart risultava fastidiosamente colorato invece di essere nero.

Questa patch include anche altre 2 patch non mie che per� reputo necessarie. 

Una � la SRAM patch che permette di salvare in memoria invece di usare le scomode password. (https://www.romhacking.net/hacks/3628).

Un'altra � la credits fix che corregge i titoli di coda (https://www.romhacking.net/hacks/3665).

(C) 2024 Di Somma Michele
mike.1983@libero.it