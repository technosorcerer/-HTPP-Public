Wolfchild (Master System)
Traducci�n al Espa�ol v1.0 (12/10/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Wolf Child (UE) [!].sms
MD5: 08eb9bf02f5eb4e238f791f27d65449a
SHA1: 92873f8d7b81a57114b135a2dfffc58d45643703
CRC32: 1f8efa1d
262.144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --