Ninja Gaiden (Master System)
Traducción al Español v1.1 (10/02/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Arregladas dos erratas del texto.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ninja Gaiden (Europe, Brazil) (Beta).sms
MD5: b070dc2ba3f106e89d1e9551f49a0027
SHA1: c67db6539dc609b08d3ca6f9e6f8f41daf150743
CRC32: 761e9396
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --