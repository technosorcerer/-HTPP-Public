The New Zealand Story (Master System)
Traducci�n al Espa�ol v1.0 (07/09/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
New Zealand Story, The (E) [!].sms
262.144 bytes
MD5: 05e5054e2ea818d4b7eb53d624562dcf
SHA1: e433b21b505ed5428d1b2f07255e49c6db2edc6c
CRC32: c660ff34

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --