Back to the Future Part III (Master System)
Traducci�n al Espa�ol v1.0 (27/07/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Back to the Future Part III (UE) [!].sms
262.144	bytes
MD5: 3d24a52e98e6c85d7c059386451ce749
SHA1: 7d67dd38fea5dba4224a119cc4840f6fb8e023b9
CRC32: 2d48c1d3

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --