Baku Baku Animals (Master System)
Traducci�n al Espa�ol v1.0 (27/06/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Baku Baku Animals (B) [!].sms
MD5: 8a94ded3d95aa46dae8800b92e66d3ee
SHA1: 07d8f300b3a3542734fcd24fa8312fe99fbfef0e
CRC32: 35d84dc2
262144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --