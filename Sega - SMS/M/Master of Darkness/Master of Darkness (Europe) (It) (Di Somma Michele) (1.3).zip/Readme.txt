Questa patch traduce in italiano il gioco identificato dal No-Intro come: 
Master of Darkness (Europe)

Ecco a voi il frutto di una settimana di lavoro. Questo semplice gioco per Sega Master System mi ha sempre affascinato cos� ecco la sua traduzione in italiano.  

Comunque ecco le caratteristiche:
* Tradotti tutti i testi anche quelli del men� nascosto.
* Varie modifiche a puntatori per spostare alcune frasi.
* Aggiunta la grafica per la parola Fine.
* Aggiunta di una routine asm per cambiare la grafica della parola End in Fine.
* Altri fix vari.

Ver. 1.1
* Fix vari

Ver. 1.2
* Fix vari

Ver. 1.3 
* Fix della routine asm per cambiare la grafica della parola End in Fine. Dopo tanti anni ho scoperto che su vero hardware non funzionava bene.

(C) 2024 Di Somma Michele
mike.1983@libero.it