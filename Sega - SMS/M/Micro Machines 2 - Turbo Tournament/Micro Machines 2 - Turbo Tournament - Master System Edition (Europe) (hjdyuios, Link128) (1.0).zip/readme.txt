Micro Machines 2 - Turbo Tournament: Master System Edition v1.0:

This is my attempt to bring the classic "Micro Machines 2 - Turbo Tournament"
from the Game Gear to the Master System, enhancing the gameplay and visuals
for a more immersive racing experience. The graphics have been improved, and
the gameplay has been adjusted to use the Master System's capabilities fully.

How to use this patch:
The BPS patch must be applied to the Game Gear version of
"Micro Machines 2 - Turbo Tournament".
- Unpack both the original ROM and this patch.
- Use a BPS patching tool (such as Beat) to apply the patch to the ROM.
- Play!

Original ROM Information:
- Filename: Micro Machines 2 - Turbo Tournament (Europe).gg
- CRC-32: dbe8895c
- SHA-1: 53ad6546462638ab246b4fdd7ca4b8966dde0d96

Special thanks to:
- Calindro for the Emulicious emulator with advanced debugging capabilities.

Emulicious website: https://emulicious.net/

Credits:
- Codemasters.

Version history:
v1.0
First release
- Expanded viewport to 256x192 resolution (effective 248x192);
- Converted graphics from 12-bit to 6-bit color;
- Cleaned up menu screens by removing unwanted artifacts;
- Enabled sprites to be displayed outside the original Game Gear viewport;
- Implemented traditional two-player mode using both Master System controllers
  with A and B buttons for acceleration and reverse/break;
- Mapped pause and reset functions to the console's respective buttons for
  convenience.
