The Three Dragon Story (Master System)
Traducción al Español v1.0 (06/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Three Dragon Story, The (K).sms
MD5: 9acd8b2eab5453380242ab3a6417c165
SHA1: a05a7a41295c38add5dfc71032d2d83b96f518b1
CRC32: 8640e7e8
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --