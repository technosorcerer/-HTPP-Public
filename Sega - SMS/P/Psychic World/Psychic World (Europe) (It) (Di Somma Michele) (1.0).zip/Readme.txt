Questa patch traduce in italiano il gioco identificato dal No-Intro come: 
Psychic World (Europe)

Ecco a voi un'altra veloce traduzione in italiano.  

Comunque ecco le caratteristiche:
* Espansione della rom per inserire altra grafica. Perdendo un po' di tempo forse sarei riuscito ad inserirla nella rom originale ma non penso che ad oggi sia un problema avere una rom pi� grande.
* Aggiunti gli accenti ed altra grafica varia per la traduzione.
* Tradotti tutti i testi anche quelli del men� nascosto.
* Varie modifiche a puntatori per spostare alcune frasi.
* Modificata la grafica "engrish" di Lucia nei titoli di coda chiamata Rucia.
* Altri fix vari.

(C) 2024 Di Somma Michele
mike.1983@libero.it