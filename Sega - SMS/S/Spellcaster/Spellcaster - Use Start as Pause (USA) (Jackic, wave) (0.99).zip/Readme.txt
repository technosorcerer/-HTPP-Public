Megadrive Start button as pause hack for Spellcaster on the SMS.

What is this?

This is a little hack aimed to people who plays this game on real hardware via a flashcart, now, when using a megadrive/genesis controller, the start button will act as the main console's pause button.

How do I use this?

Use an IPS patcher and apply the patch to the rom, you are good to go.

Notes: 

Tested on SMS everdrive on master system 1 hardware. This is competible with translations but, sadly, it is not compatible with the sram hack.

Wave/Jackic 2024.