Strider
Traducci�n al Espa�ol v1.0 (18/11/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Strider
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Strider
-----------------
Version de Master System del arcade Strider.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Strider (UE) [!].sms
524.800	bytes
CRC32: 131bdb98
MD5: 2566f4379f0fcfafd061ea8b6e75f580
SHA1: c36c9a666aa6189d1e6edc7132b5b96925464e5b

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --