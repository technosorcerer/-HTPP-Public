Tails in Sonic The Hedgehog is a ROM Hack of Sonic The Hedgehog on the Sega Master System that replaces Sonic with Miles "Tails" Prower.
This includes a change in the life icon, 1-up Monitor, Act result screen, and a change in color palette.

How use this patch:
The ips patch must be applied to the Master System version of Sonic the Hedgehog
- Unpack both the original rom and this patch
- Use Lunar IPS to apply the patch to the rom (it will overwrite the original rom)
- Play!