Scramble Spirits (Master System)
Traducci�n al Espa�ol v1.0 (19/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Scramble Spirits (UE) [!].sms
MD5: 82b9ee0920c3c46798ecd659be0a5d9a
SHA1: 430154dc7ac1bb580c7663019ca476e5333e0508
CRC32: 9a8b28ec
262.144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --