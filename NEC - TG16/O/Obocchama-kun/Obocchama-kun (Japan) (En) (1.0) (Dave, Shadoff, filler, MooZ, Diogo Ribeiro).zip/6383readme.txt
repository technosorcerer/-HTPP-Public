----------------------
Obocchama-kun (HuCARD)
----------------------
English Translation Patch
Version 1.0

---------------
About the Patch
===============

The game is fully playable in English.
This patch has been made available for free.
Commercial use is strictly forbidden--including but not limited to "repros."

------------------
Applying the Patch
==================

Lunar IPS is an easy-to-use Windows tool to apply IPS patches to ROMs
available here: https://fusoya.eludevisibility.org/lips/
or here: http://www.romhacking.net/utilities/240/



---------------
Filler's Notes:
===============

I dumped a Japanese script for Obocchama-kun while dumping scripts for a number of games on the PC Engine. It was Sept 10 of 2020, and I posted the untranslated script to a running "Raw Scripts" thread I'd made on https://pcengine.proboards.com.

About a year later, 4lorn and David Shadoff began working on Obocchama-kun and reached out to me about some of the puns in the game likely due to my recent work on Wonder Momo. I don't consider puns my strongest suit, but I've gotten a knack for them since my work on the Sorcery Saga (Madou Monogatari) games, so I agreed to take a look.

Below are notes on some specific puns in Japanese, and what I personally suggested in English for those interested.

とらック This is literally "truck". However, "とら" written in hiragana emphasizes the word "tiger" in Japanese. I wanted to get some type of cat, and some type of vehicle together in a clever way in English. I settled on "feline-wheelin" for the rhyme, and "transpawtation" which I think is the more fun wordplay of the two. They went with "Catruck", possibly due to space constraints.

くるまエビ Kurumaebi is literally "prawn" (くるまえび 車蝦). It's separated with hiragana/katakana again, emphasizing that the word "car" (kuruma). To keep this vehicle/animal pun I suggested "crustation wagon", or "autoprawn" (evoking "autobahn") which is I believe what they went with.

おめでたい "Omedetai" can mean happy or a matter to celebrate, but it can also mean silly or stupid. The sprite is a celebrating fish. "tai" is a type of fish, what we call sea bream, or snapper in English. Leaning into the "stupid/silly" meaning of omedetai I suggested "Dumb bass".

かもん "Kamon" in hiragana suggests "kamo" or "duck". Specifically a wild duck. "Ahiru" are apparently domesticated ducks. At any rate, it's written like "come on (Kamon)", and the duck sprite is seen making a "come here" gesture. "Duck call" seemed an obvious choice. A duck call calls ducks to you, but the duck is calling you, so it's unexpected. It looks like they went with "conard" or "canard", it's a little hard to tell. It seems to be a play on mallard, but I'm not sure of the pun.

まりげーたー "Malligator" is pretty straightforward since "まり/mali/mari" means ball. I suggested "balligator". Seems like they went with "pogosaur". Maybe the monster bounces.

ハイエーナー "Haieenaa" This is a riff on "hyena", but it sounds kind of like "sure is fast". Basically, a quick canine. I suggested "K9 yards" and "K9 to 5", of which the latter was used.

ねコンドル "Nekondoru" This seems to be a play on "寝込む/ねこむ/nekomu" which means to be fast asleep, and "condor". I suggested "yawndor" to keep the meaning and word play.

フラツキミンゴ "Furatsukingo" seems to be a combination of "ふらつく/furatsuku" which means to feel giddy/dizzy, or to stagger or waver. Basically it's an unsteady flamingo. I suggested "flappingo".

ばくてん "Bakuten/バク転" is the word for a "back-flip", and a tapir is "ばく/baku". Here we have a tapir doing a back-flip. I suggested "tapir artist" to evoke "trapeze artist". They went with tap-tapir.

ハット "Hatto" A pigeon is "hato". Here there is a glottal stop, in addition to it being written in katakana makes it like the words "hat" or "hut". The image is clearly a bird, and I think it's supposed to be wordplay on "pigeon", so I suggested "pigeoff".

よみがえる "Yomigaeru" means to rise from the dead, or come back to life. The last half of the word sounds like frog (kaeru). The sprite looks like a blob forming the shape of a frog. I suggested "reamphibian" as a combination of "reanimate" and "amphibian".

ヘリコブタ "Helicobuta" is a combination of "helicopter" and "buta" which means "pig". I suggested "pork chopper" combining "pork chop" and "chopper" as in helicopter. They went with "helipig".
 
こんなモンキー "Konnamonkii" seems to be a combination of "こんなもん/konnamon" and "monkey". "Konnamon" is like "this/like this/this thing/such a thing". I wanted to try to keep with the monkey word play and suggested "commonkey", as a combination of "common", and "monkey". Probably not my best suggestion out of the lot. Looks like they went with "babounce" which seems to be a combination of "baboon" and "bounce".

ばくだんらっこ "Bakudanrakko" I may be missing some wordplay here, but this seems to be a combination of "bakudan/bomb" and "rakko/otter". I suggested "otter bombshell" and "ottomic bomb". I feel the latter may be in poor taste, but I think it's the more clever of the two. They went with "bombotter".

とんぼがえる This is a play on "蜻蛉返り/とんぼがえり/tonbogaeri" which is a somersault, and "kaeru/gaeru" which is frog. I went with some alteration and suggested "tumble toad".

16トン "16 ton" The joke here is that "ton" means "pig/pork" in Japanese. I struggled with this one and settled on "P.1.6". The joke here being that "6" looks like a capital "G". It gives more of the impression of an android pig, or a code name, but it works well with the sprite and space limitations. I was so enamored of this that I actually pushed back on this as opposed to "16thud" which was settled on afterward. I don't know the final result and I'm okay with whatever the team decides, but this is one of my favorite little puns I came up with for these enemies.

もーゆるさん "Mooyurusan" is a riff on a stock villain saying "I'll get you for this" but the way it's written suggests a cow's "moo". I suggested "I'll get moo!".

こんもり "Konmori" is a play on "bat" which is "koumori". Here the sprite is a bat, but "konmori" means "thick" or "dense" like a dense forest. I wanted to focus on words that sound like "bat" so I suggested "fat bat". I believe they kept the approach but decided on "scat bat".

I ended up skipping a few of the enemy names and onomatopoeia because I couldn't come up with anything I was satisfied with, but I'm glad I had an opportunity to help with this project and I hope it made things a little easier for the translation team.

Congrats to everyone on the release of another PCE/TG16 fan translation patch! It's nice to see the system and games get some more love and I'm happy to have been able to be a part of it.


-------------
4lorn's Notes
=============

When I first played Obocchama-kun in October 2021, I was awestruck. Dancing hippos, back-flipping tapirs, and a pig-faced genie who pulls out chickens from his pants? How could this have *not* been translated yet?

Obocchama-kun is a PC Engine action platformer based on the children's award winning 1986 manga by Kobayashi Yoshinori, serialized in Shogakukan's CoroCoro Comic. Released in 1991, the game follows the exploits of the Little Princeling as he tries to protect the ancestral stele of the Turtle-chama, which is in danger of being defiled by mysterious invaders, and save his friends along the way. A pretty standard platformer, but it does stand out with its weird assortment of power-ups, Obo's quirkiness and enemies - some of which were designed by fans of the manga, after a competition was held while the game was in production.

Soon enough, I began working through the script filler had already extracted, and the additional strings still requiring extraction. Me and Dave Shadoff also contacted MooZ, who had already cracked the game's GFX compression routine for his French translation of the game. Things got into a pretty nice rhytm but went into a lull due to handling multiple projects but eventually, work on Obo was resumed, with the new graphics and translated text finally being inserted. In between playtesting and finalizing things, I still managed to fix a couple of missing background elements on Level 14.

MooZ should be showered with praise for handling Obocchama-kun's compression and end credits routine. Also, Dave Shadoff's technical assistance is always appreciated and filler's support, both in terms of script extraction and translating the majority of the bestiary, deserves a ton of praise.

MooZ, filler, Dave Shadoff and I hope everyone enjoys this English translation of Obocchama-kun!

PS: A word of caution for photosensitive players. During the boss encounter on Level 12, the screen will quickly flash between black and white on two occasions - the intensity can be annoying even for people without photosensitivy issues, so some care is suggested.

--------------------------------------
Brief notes on the translation (4lorn)
======================================

The GFX were all translated, but two quirks should be pointed out.

During the game, Obocchama will find two power-ups. One, available right at the start of Level 1, is ヨーグルト (yogurt), which paralizes enemies for a short amount of time. The word itself is not entirely shown on the original; I managed to translate it while maintaining the original still and, hopefully, still make it legible.

The second power-up might remain unnoticed for most players, as it's only found on Level 12. It's a small power-up where one can read ゆ (hot water) which, when acquired, will spawn a character further ahead that grants Obo an extra life. The yogurt graphics were somewhat manageable, but it would be impossible to fit this one in the available GFX while retaining meaning and legibility. Instead, the English translation adopts the word "tea".

Regarding enemy names, filler's work was stellar as always. The ones that "got away" were down to space constraints but hopefully do a good job nonetheless. However, I'd be amiss if I didn't explain the intention behind one of the enemies I translated: のってマングース, "Notte mangūsu", which could be interpreted in a number of ways. At first I considered "Maraca Mole" but after a while, I decided on Chac-a-mole, "chac-chac" being another name for maracas. And so, the final result became a pun on "whack-a-mole". 

Finally: in the original japanese version, the last line after the credits list is さいならっきょ (sainarakkyo), which is a nonsense variation of さよなら (sayounara). This is actually one of the many weird ways in which Obo often expressed himself in the original stories, but would be lost in translation. Writing "goodbye" in a silly manner would have prompted an explanation anyway, so instead I've chosen to use "goodbye" and explain it in the readme.

---------
Viva NEC!
=========