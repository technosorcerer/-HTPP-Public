if exist "Emerald Dragon EN [v1.0] SplitBin.bin" del "Emerald Dragon EN [v1.0] SplitBin.bin"
set binfullname=%~n1
copy /b "%binfullname% (Track 01).bin" + "%binfullname% (Track 02).bin" + "%binfullname% (Track 03).bin" + "%binfullname% (Track 04).bin" + "%binfullname% (Track 05).bin" + "%binfullname% (Track 06).bin" + "%binfullname% (Track 07).bin" + "%binfullname% (Track 08).bin" + "%binfullname% (Track 09).bin" + "%binfullname% (Track 10).bin" + "%binfullname% (Track 11).bin" + "%binfullname% (Track 12).bin" + "%binfullname% (Track 13).bin" + "%binfullname% (Track 14).bin" + "%binfullname% (Track 15).bin" + "%binfullname% (Track 16).bin" + "%binfullname% (Track 17).bin" + "%binfullname% (Track 18).bin" + "%binfullname% (Track 19).bin" + "%binfullname% (Track 20).bin" + "%binfullname% (Track 21).bin" + "%binfullname% (Track 22).bin" + "%binfullname% (Track 23).bin" + "%binfullname% (Track 24).bin" + "%binfullname% (Track 25).bin" + "%binfullname% (Track 26).bin" + "%binfullname% (Track 27).bin" + "%binfullname% (Track 28).bin" + "%binfullname% (Track 29).bin" + "%binfullname% (Track 30).bin" + "%binfullname% (Track 31).bin" "Emerald Dragon EN [v1.0-rev0] SplitBin.bin"

xdelta3 -d -s "Emerald Dragon EN [v1.0-rev0] SplitBin.bin" "../redump_patch/Emerald Dragon EN [v1.0-rev0] Redump.xdelta" "Emerald Dragon EN [v1.0-rev0] SplitBin.bin_patched"

if exist "Emerald Dragon EN [v1.0-rev0] SplitBin.bin" del "Emerald Dragon EN [v1.0-rev0] SplitBin.bin"
move "Emerald Dragon EN [v1.0-rev0] SplitBin.bin_patched" "Emerald Dragon EN [v1.0] SplitBin.bin"
