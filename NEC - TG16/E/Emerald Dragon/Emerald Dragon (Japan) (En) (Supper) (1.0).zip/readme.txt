﻿********************************************************************************
*                   Emerald Dragon (PC-Engine Super CD-ROM²)                   *
*                          English Translation Patch                           *
*                           by Stargood Translations                           *
*                              v1.0 (31 Dec 2025)                              *
*                                                                              *
*                               Supper -- Hacking & Translation                *
*                               cccmar -- Editing & Testing                    *
*                          Oddoai-sama -- Testing                              *
********************************************************************************

In Ishbern, the Holy Land, the sacred grounds where dragons once roamed have
lain defiled by demonkind for two decades. As the foul armies of Garsia the
Infernal prepare to strike the finishing blow against the beleaguered kingdom
of Eirvad, one slim ray of hope shines through: the dragon-man Atrushan, come
to protect his sworn companion Tamrin on her quest to uncover her mysterious
past. Together, they journey across Ishbern, seeking to stem the onslaught of
the Hellions and discover the dark truth behind the war that ravages the land.

Emerald Dragon is a 1994 RPG for the PC-Engine Super CD-ROM², developed by Alfa
System and published by NEC Home Electronics. A remake of Glodia's 1989 game for
Japanese home computers, it heavily overhauls the presentation with flashy new
visuals, voice acting, and music, as well as vastly refined gameplay.

This patch fully translates the game into English.

                    ****************************************
                    *          Table of Contents           *
                    ****************************************

  I.    Patching Instructions
  II.   Running the Game
  III.  Known Issues
  IV.   Additional Features
  V.    FAQ
  VI.   Terminology Reference
  VII.  Authors' Comments
  VIII. Special Thanks
  IX.   Version History

                    ****************************************
                    *       I. Patching Instructions       *
                    ****************************************

To use this translation, you'll need to apply a patch to a disc image of
the game. Unfortunately, patching disc images is inherently complicated
because there are numerous CD image formats in use, as well as many ways that
poorly-written disc ripping programs can mess things up and make a patch not
work properly. As a result, this is a rather long section – sorry! But please
read it over carefully before complaining that the patch doesn't work.

Just to be clear: this patching process is designed to support every disc image
format it reasonably can. Though a Redump-verified disc image is a definite
plus, options are provided to patch pretty much any image so long as it has the
correct data track. If you don't have one of the Redump images, just go ahead
and try to patch whatever you have using whichever of the options below applies
to it.

Now then, here are your options for patching, approximately ordered from best
to worst:

  A. Directly patch a single-file Redump-verified BIN or IMG image
  B. Directly patch a multi-track Redump-verified BIN image
  C. Automatically patch a BIN or IMG image via binpatch.bat
  D. Automatically patch an ISO+WAV+CUE image via isopatch.bat
  E. Manually patch

These options are explained in the subsections that follow.

  -----------------
  - GAME VERSIONS -
  -----------------

Two revisions of the PC-Engine version of Emerald Dragon are known to exist:

  - The original release. We'll refer to this as "Revision 0" for convenience,
  though in reality, you'll most likely find it listed on other sites simply as
  "Emerald Dragon (Japan)", with no version suffix at all.
  - Revision 1: A bugfixed update. This revision fixes a money underflow glitch
  in the slot machine minigame, and possibly makes other minor changes. Often
  listed on other sites as "Emerald Dragon (Japan) (Rev 1)".

This translation is based on Revision 1, so that is the primary target for the
patching process. Because the differences between Revisions 0 and 1 are fairly
minimal, patches are also provided for Revision 0. You should therefore be able
to patch any release of the game.

Note that a demo version of the game ("Taikenban") also exists. This is, of
course, not supported by the patching process.

  -------------------
  - BEFORE STARTING -
  -------------------

It should go without saying, but first, extract all the contents of the
translation patch's ZIP to your hard drive if you haven't already.

Before you start, you'll need to determine what format your disc image is in. At
the very least, you must have an image in BIN+CUE, IMG+CUE, or ISO+WAV+CUE
format; more exotic formats are not supported. It's unfortunately not uncommon
to come across disc images that don't use the standard file extensions used
in this section, or use them differently from normal, which makes things very
confusing. Some tips:

  - One common way of distributing disc images is the "dual CCD/CUE"
  format. This consists of four files: a CCD, a CUE, an IMG (or possibly BIN),
  and a SUB. If your image is like this, you can throw away the CCD and SUB
  files, as they aren't needed for the patch. For our purposes, an IMG is the
  same as a BIN, so any references to a "BIN" below can also refer to an "IMG"
  or vice versa.

  - If your disc image has a CCD but no CUE, you may be able to patch it with
  method A. If that fails, you'll need to look into creating or obtaining a CUE
  file for the disc.

  - If your disc image consists of a CUE and a large number of BIN files,
  it's in the "split BIN" format. This format is particularly used by the
  distributions available on certain archival web sites. It's possible to patch
  this format as long as the BIN files represent one of the Redump disc images,
  just split up into its component tracks.

  - You're not likely to see them much these days, but old, lossy formats like
  ISO+MP3 are not supported.

  --------------------------------------------------------------------
  - A. Directly patch a single-file Redump-verified BIN or IMG image -
  --------------------------------------------------------------------

Use this method if at all possible. While not as simple as the auto-patching
method described later, it gives the most reliable results.

You can patch using this method if your disc image *exactly* matches one of the
two verified "good" images as listed on Redump.org, and if all the tracks on the
disc are combined into one single BIN or IMG file.

First, check that your disc image contains a single file with the extension
".bin" or ".img". If it does, verify that that file matches one of the following
specifications. (If you don't know how to do that, just go ahead and follow the
steps listed below; if you get an error, your disc image is wrong.)

REVISION 1: http://redump.org/disc/32497/
  Redump name: Emerald Dragon
  CRC32:       cf0ca987
  MD5:         cbe62de2bc2b7c380a6b6370dfca84ca
  SHA-1:       4650050fcadd759c51c00a37c0ff2bdd58ed6789

REVISION 0: http://redump.org/disc/32498/
  Redump name: Emerald Dragon
  CRC32:       fb3b1dc9
  MD5:         b8e4e2edfb7cb9a9df09c2fdf0d80efe
  SHA-1:       2b7f12b2d2b852fc32d06e93da4bf7339fe7804b

If your disc image is a match, all you need to do is apply an xdelta patch to
the BIN or IMG file, then rename it and pair it with the CUE file provided in
the download.

  1. Extract the "redump_patch" folder from the translation ZIP and open it.

  2. Run "DeltaPatcher.exe", which should be present in that folder. This is the
  popular Delta Patcher program for applying xdelta patches. If you're not using
  Windows, you'll need to obtain an alternate patching program for your system,
  such as the command-line "xdelta3" program.

  3. Locate the .xdelta patch files in the "redump_patch" folder. Select the one
  labeled "Revision 1" or "Revision 0" depending on which version you have.

  4. Use Delta Patcher (or another xdelta patching tool) to apply the patch to
  the BIN or IMG file. If you get an error, you'll need to try one of the other
  patching methods below.

  5. If your disc image came with a CCD or CUE file, delete it now.
     DO NOT USE THE OLD CCD OR CUE FILE WITH THE PATCHED IMAGE!
     Also get rid of any SUB file if it exists. It's not needed.

  6. The "redump_patch" directory should contain a CUE file with a name like
  "Emerald Dragon EN [v1.0] Redump.cue". Rename your patched disc image so it
  has *exactly* the same name as the CUE, except with a .bin extension instead
  of .cue.
     IMPORTANT: If the file you patched was originally an IMG file, make
     sure that you change the extension to .bin. The CUE will not work if the
     extension is .img.

  7. You're done! Make sure you have the CUE and BIN in the same directory,
  then open the CUE in an emulator. Or if you have the hardware, burn the image
  to a CD and play it on your PC-Engine. Or better yet, use a Turbo EverDrive or
  something, because it's a whole lot less hassle.

  -------------------------------------------------------------
  - B. Directly patch a multi-track Redump-verified BIN image -
  -------------------------------------------------------------

  One common distribution of the game found on certain archival sites uses the
  Redump-verified disc image, but splits it up into separate tracks instead of
  combining them into a single file. This is easily recognized by the presence
  of 31 separate BIN files and a single CUE.

  Before patching:

  - Make sure that your disc's CUE file has a name like "Emerald Dragon
  (Japan).cue" or "Emerald Dragon (Japan) (Rev 1).cue".

  - Make sure that the BIN files are named like this:
      Emerald Dragon (Japan) (Track 01).bin
      Emerald Dragon (Japan) (Track 02).bin
      …
      Emerald Dragon (Japan) (Track 31).bin
    OR
      Emerald Dragon (Japan) (Rev 1) (Track 01).bin
      Emerald Dragon (Japan) (Rev 1) (Track 02).bin
      …
      Emerald Dragon (Japan) (Rev 1) (Track 31).bin

  To patch:

  1. Copy the CUE file and all BIN files into the "splitbin_patch" directory.

  2. Drag-and-drop the CUE file onto "binpatch_rev1.bat" (to patch a Revision 1
  disc) or "binpatch_rev0.bat" (Revision 0).

  3. If all goes well, this should produce a new, single-track format disc image
  in the same directory. (This works by simply combining all the tracks together
  and then applying the same patch as in method A.)

  4. Use the CUE file provided in the "splitbin_patch" directory to play the
  game.

  --------------------------------------------------------------
  - C. Automatically patch a BIN or IMG image via binpatch.bat -
  --------------------------------------------------------------

If your disc doesn't match the Redump dump, or you otherwise couldn't get method
A to work, it may still be possible to patch it. If your disc is in BIN+CUE
format or IMG+CUE format, and you're using Windows:

  1. Make sure that your BIN/IMG and CUE have the same base name
  (e.g. "emdr.bin" and "emdr.cue", or "emdr.img" and "emdr.cue"). Note that if
  you rename the BIN file, you will need to open your CUE in a text editor and
  make the same change to any occurrences of the name inside the file.

  2. Copy both the BIN/IMG and CUE into the "auto_patch" directory.

  3. Drag-and-drop the BIN/IMG file onto either "emdr_rev1.bat" or
  "emdr_rev0.bat", depending on which version you think you have.

  4. If all goes well, this should produce an ISO+WAV+CUE format disc image in
  the same directory.

  ----------------------------------------------------------------
  - D. Automatically patch an ISO+WAV+CUE image via isopatch.bat -
  ----------------------------------------------------------------

If your disc image is already in ISO+WAV+CUE format, you can perform a procedure
similar to patching via binpatch.bat:

  1. Copy all the disc image files to the "auto_patch" directory.

  2. Drag-and-drop track 2 of your image onto "isopatch_rev1.bat" or
  "isopatch_rev0.bat", depending on which version you think you have.

  3. If all goes well, this should produce an ISO+WAV+CUE format disc image in
  the same directory.

  ---------------------
  - E. Manually patch -
  ---------------------

You can also attempt to apply the xdelta patches in the "auto_patch" directory
to the ISO of an ISO+WAV+CUE image manually. Pretty much the only reason to do
this is if you're on Linux and can't or won't use Wine. If that's the case,
then presumably you're smart enough to handle it yourself, so you're on your
own here.

                    ****************************************
                    *         II. Running the Game         *
                    ****************************************

This patch was developed and tested using mednafenPceDev
(https://github.com/pce-devel/mednafenPceDev) and Mesen
(https://github.com/SourMesen/Mesen2). These appear to be the most accurate
PC-Engine emulators available today, and either one of them should run the game
satisfactorily.

If you're unfamiliar with the PC-Engine, figuring out how to run CD-based games
can be confusing. This section tries to make things clear for new users.

The simple version is this: Originally, NEC/Hudson released the PC-Engine. Then
they decided they needed a CD add-on and released the CD-ROM² ("CD ROM-ROM")
system. Then they decided that their original CD add-on wasn't powerful enough,
so they made the upgraded Super CD-ROM². Most CD-based games target the Super
CD-ROM² and are not compatible with the original, unenhanced CD-ROM².

In order to play the translation, you'll need to have a ROM image of the Super
CD-ROM² System Card Version 3.00. Using a card with a lower version number
will cause an error screen to appear when the game starts. You're on your own
for obtaining the BIOS image; the No-Intro name is "[BIOS] Super CD-ROM System
(Japan) (v3.0).pce".

You'll also need to set up your emulator to use this BIOS image, of
course. Stock versions of Mednafen will look for a file named "syscard3.pce"
in the "firmware" directory and give an error if it doesn't exist, so move and
rename your BIOS image accordingly. Mesen will prompt you for the BIOS image
the first time you try to launch a CD game. Other emulators have their own setup
procedures, so check their documentation for instructions.

                    ****************************************
                    *          III. Known Issues           *
                    ****************************************

The translation itself has no known issues. However, at least on Mednafen,
both the original game and the translation appear to have a very small chance
of crashing the first time the menu is opened after starting a new game when no
save data previously existed. It's unclear what causes this, or if it can occur
on real hardware, so we haven't done anything to try to fix it. If this happens
to you, just restart the game and chances are everything will work just fine.

There are some other minor things that "look like bugs" but are simply quirks of
the original game:

- When asking the bartender in Hvovi about Ostracon under certain conditions,
after displaying the normal message, the game may erroneously display the
message shown when the "threaten" option is selected.

- Trying and failing the highest rank of an arena challenge will always result
in being considered a "pro" and refused entry on subsequent attempts, even
though it doesn't really make sense.

                    ****************************************
                    *       IV. Additional Features        *
                    ****************************************

In hopes of making the experience more enjoyable for the less patient, this
translation includes a few optional extra features to allow various aspects of
the game to be sped up.

Aside from the battle fast-forward, all of these are features that already
existed in the original game but could only be used in debug mode, which (unlike
this game's Super Famicom cousin) is not accessible without modifying the game.

  -----------------------
  - Battle Fast-Forward -
  -----------------------

  Holding Button I during battles will increase units' movement speed and
  shorten or skip most animations.

  Please note that when fast-forwarding, combat messages will be dismissed
  immediately if the text speed is set to "Fast," but will have a short delay if
  it's "Normal" or "Slow."

  -----------------
  - Overworld Run -
  -----------------

  Holding Button I while moving on the overworld will increase Atrushan's
  movement speed. The speed increase is proportional to the Walk Speed setting,
  so you'll "run" faster if your base movement speed is set higher.

  -----------------
  - Speech Toggle -
  -----------------

  A new option has been added to the System menu to disable the in-game voice
  acting, which allows dialogue to be advanced more quickly.

  Note that this also affects voice clips which play on the overworld. If speech
  is turned off, these clips won't play and subtitles won't be shown for them,
  which may make some scenes confusing. It's probably best to keep this on if
  you haven't already played through the game.

  -----------------
  - Cutscene Skip -
  -----------------

  Pressing the Run Button during most cutscenes will now skip them.

                    ****************************************
                    *                V. FAQ                *
                    ****************************************

Q. Is this based on the existing fan translation of the SNES version of the
game?

A. No, not at all. This translation was done completely from scratch and without
reference to the existing translation until the very end of production, when it
was used as a cursory sanity check on the finished work. It wouldn't have been
much help anyway because the Japanese script was heavily written for the Super
Famicom port, and the overlap between them is generally very loose.



Q. How does this version differ from the SNES version?

A. It's pretty much a different game. The Super Famicom port came out over a
year after this version and made many changes for various reasons. Needless to
say, in order to fit on a cartridge, all the flashy CD-based elements like the
voice acting and cutscenes had to be reduced to a handful of fuzzy voice clips
and small cut-in stills. But even aside from that, the game was simplified,
censored, made easier, and generally rewritten in what was most likely an
effort to make it more appealing to children, who made up a larger portion of
that console's userbase. Blood was removed or recolored brown, "hard words" were
replaced with simpler ones, additional bits of slapstick or physical comedy were
stuck in here and there...that sort of thing.

   That's not to say that the SFC version is strictly worse than this one -- the
battles use redrawn graphics and certainly look much nicer, and an effort was
clearly made to "remix" the game to improve on issues in the PCE version. But
the changes are something of a mixed bag, and considering how much content
was inherently lost in the process of porting to a less capable machine, that
version just doesn't enjoy the same reputation as this one.



Q. I want to start a new game, but I can't because the game keeps automatically
reloading my last save file!

A. For some reason, the developers chose to make the game default to loading
the most recent save file every time it starts. To do anything else, you need to
hold certain button combinations as the game boots:

   - Button II: Opens a menu that lets you start a new game or load any existing
   file.
   - Button I+II: Starts a new game.
   - Button I: Skips the NEC logo and immediately loads the most recent save
   file.
   - Up: Opens the Memory Base 128 save manager. The Memory Base 128 was a
   peripheral that could store large amounts of save data; this tool allows you
   to transfer data between a Memory Base 128 and the normal Backup Memory. Most
   emulators don't support it. If you want to use this, you'll need to run the
   game in mednafenPceDev with the pce.memorybase128_enable flag set to 1.



Q. How do I use items in battle?

A. Press Button II during any party member's turn to bring up the battle
menu. In addition to using items, you can order party members to focus their
attacks on a particular enemy, or attempt to escape (though see the below
question).



Q. I keep choosing the "flee" option, but the game always tells me I can't
escape. Did you break something?

A. Unfortunately, no; this is just how the game works. The formula that
determines your chance of escape is absurd, and without insane amounts of
grinding, it's generally 0%. For example, the starting area outside Urvan, which
has the weakest enemies in the game, requires you to be level 13 to have a 5%
chance of successful escape, with an additional 5% per level beyond that. For
reference, an average player might be around that level by the time they finish
both of the opening dungeons and leave this area behind. This pattern continues
throughout the game. Get used to fighting every single encounter, because in
practice, escape is never an option.



Q. What are all these weird messages like "That was your fault, Atrushan!" that
keep popping up during Tamrin's turn?

A. The game appears to have a mechanic where magic-using characters have a
chance of "messing up" a spell, which ends their turn immediately and displays
a quote in which they lament their mistake. (This is possibly meant to be some
sort of balance against the fact that, with no MP system, there's no limit
on using magic except what the AI will choose to cast.) While it's possible
for this to happen with other characters, it's by far the most frequent and
noticeable with Tamrin.



Q. Why is there a dedicated button for conferring with the party, but not
opening the map!?

A. It's an odd choice, isn't it? But actually, the game does provide a map
button; it's just that you have to use a 6-button controller. If you're using an
emulator, make sure you configure the additional buttons and set the controller
mode to 6-button (you can do this in the middle of the game without issue).

                    ****************************************
                    *      VI. Terminology Reference       *
                    ****************************************

If you play this game, you'll quickly notice a lot of unusual names like
"Hvovi", "Mithramihr", "Khosrow", and so on. This is because most of the names
are taken from real-world religious or historical terms, primarily but not
exclusively Avestan-language terminology relating to Zoroastrianism.

A great deal of time on this translation went towards researching these names
to try to determine their origin and the most correct way of presenting them in
English. This section lists the terms for which we were able to find some sort
of plausible explanation, or in some cases, ones where there didn't appear to be
any satisfactory origin and we chose an arbitrary spelling.

The information listed here is just a best guess. Given the obscurity of the
base material, it's quite difficult to, for instance, determine specifically
that the word ダードワ is derived from the 95th name of Ahura Mazda,
"dâdhâr"; we've made every effort to match everything up to its real-life
counterpart, but there are certainly terms that had some origin we simply
couldn't find, or ones that we mistook for something else. Apologies for any
errors.

Many thanks to tekiro, who wrote the following post in 2005 speculating on the
origins of many of these names: http://www.tekiro.main.jp/?eid=318204 Without
that, this list would probably be less than half as long.

Transliterations from Avestan sometimes use unintuitive conventions; for
instance, the letter "V" is pronounced more like "W" in many cases, and the pair
"kh" actually represents something more like an "H" sound. Pronunciation guides
are provided below in cases where spelling differs significantly from typical
English usage.



  Apas (アーパス)

    Probably from https://en.wikipedia.org/wiki/Aban: "Apas (/ˈɑːpəs, æp-/,
    Avestan: āpas) is the Avestan language term for 'the waters', which, in its
    innumerable aggregate states, is represented by the Apas, the hypostases of
    the waters."

  Atrushan (アトルシャン)

    Derived from "atroshan," a type of Zoroastrian fire temple:
    https://en.wikipedia.org/wiki/Fire_temple

  Avesta (アヴェスタ)

    https://en.wikipedia.org/wiki/Avesta "The Avesta (/əˈvɛstə/, Book
    Pahlavi: ʾp(y)stʾk' (abestāg), Persian: اوستا (avestâ)) is the text
    corpus of religious literature of Zoroastrianism. All its texts are composed
    in the Avestan language and written in the Avestan alphabet."

  Bagin (バギン)

    Also a type of Zoroastrian fire temple.

  Barsom (バルソム)

    https://en.wikipedia.org/wiki/Barsom "A barsom /ˈbɑːrsəm/ is a
    ritual implement used by Zoroastrian priests to solemnize certain sacred
    ceremonies."

  Dastur (ダストゥール)

    https://en.wikipedia.org/wiki/Dast%C5%ABr "A dastur (/dəˈstʊər/
    də-STOOR), sometimes spelt dustoor, is a term for a Zoroastrian high priest
    who has authority in religious matters and ranks higher than a mobad or
    herbad."

  Dhadhva (ダードワ)

    Pronounced "dah-dwah." Thought to be from "dâdhâr" ("the just creator"),
    one of the names of the principal god of Zoroastrianism, Ahura Mazda:
    https://en.wikipedia.org/wiki/Names_of_God_in_Zoroastrianism

  Druguant (ドゥルグワント)

    Pronounced something like
    "droo-gwant." https://en.wikipedia.org/wiki/Nasu_(Zoroastrianism) "Druj is
    the root for the adjective drəguuaṇt, meaning 'owner of falsehood,' which
    '[designates] all beings who choose druj over asha.'"

  Eirvad (エルバード)

    Pronounced "air-vahd." https://en.wikipedia.org/wiki/Herbad "Hērbad (also
    hīrbad, hērbed or ērvad) is a title given to Zoroastrian priests of minor
    orders." Our choice of the spelling "Eirvad" is purely out of aesthetic
    considerations.

  Falna (ファルナ)

    This is believed to be derived from "Khvarenah", which in Japanese
    is フワルナフ: https://en.wikipedia.org/wiki/Khvarenah "Khvarenah
    (also spelled khwarenah or xwarra(h): Avestan: 𐬓𐬀𐬭𐬆𐬥𐬀𐬵
    xᵛarənah) is an Avestan word for a Zoroastrian concept literally denoting
    'glory' or 'splendour' but understood as a divine mystical force or power
    projected upon and aiding the appointed."

    If that is in fact the origin, then strictly speaking, "Farna", "Kharna", or
    "Harna" would be more correct. But personally, I think "Falna" sounds a lot
    better than any of those, and the derivation is pretty distant anyway, so I
    selfishly invoked editorial privilege and went with my own preference.

  Fravard (フラワルド)

    Pronounced "fraward." https://en.wikipedia.org/wiki/Frawardin_Yasht "The
    Frawardin Yasht is the thirteenth Yasht of the 21 Yasht collection and is
    dedicated to the veneration of the Fravashi."

  Garsia (ガルシア)

    Okay, so this one is in fact just the standard way of writing the Spanish
    name "Garcia" in Japanese. The spelling of "Garsia" is editorial, mostly
    because I felt like it was extremely incongruous to have such a completely
    ordinary name for a huge nasty evil demon king. You know how Ted Woolsey
    arbitrarily changed a character's name from "Tina" to "Terra" on the grounds
    that Tina sounds exotic to Japanese people, but plain to Americans? Well,
    that was a really stupid decision. But in this case, I think the principle
    actually applies.

  Ghomez (ゴーメズ)

    From https://en.wikipedia.org/wiki/Cow_urine No, seriously: "Cow urine,
    gomutra or gōmēz is a liquid by-product of metabolism in cows. It has a
    sacred role in Zoroastrianism and some forms of Hinduism."

    Note that this is not the way the Spanish name "Gomez" is written in
    Japanese; that would be ゴメス. Spelling this as "Ghomez" is arbitrary,
    but "Gomez" would definitely be misleading.

  Hadar (ハダル)

    https://en.wikipedia.org/wiki/Hadar_(star) "Beta Centauri is a triple star
    system in the southern constellation of Centaurus. It is officially called
    Hadar (/ˈheɪdɑːr/)."

  Helmand (ヘルマンド)

    https://en.wikipedia.org/wiki/Helmand_River "The Helmand river, also
    historically known as the Etymandros, is the longest river in Afghanistan
    and the primary watershed for the endorheic Sistan Basin."

  Helrode (ヘルロード)

    Unknown origin. tekiro claims it's from a historian named
    ヘンリー・ロード; I can't find any record of such a person and it
    seems a very unlikely derivation anyway, so this spelling is arbitrary.

  Hvare (フワル)

    Pronounced something like
    "hwarr." https://en.wikipedia.org/wiki/Hvare-khshaeta "Hvare-khshaeta
    (Hvarə-xšaēta, Huuarə-xšaēta) is the Avestan language name of the
    Zoroastrian yazata (divinity) of the 'Radiant Sun'."

  Hvovi (フウォーウィー)

    Pronounced like "hwoh-wee." From Hvōvi, the third wife of Zoroaster,
    founder of Zoroastrianism: https://en.wikipedia.org/wiki/Zoroaster

  Ishbern (イシュバーン)

    Unknown. Neither we nor anyone else seems to have been able to come up
    with an origin for this term, so the spelling of "Ishbern" is completely
    arbitrary and picked mostly for aesthetics.

    In the original home computer versions, this was written out as
    イシュ・バーン with a dot in the middle, suggesting a two-word name
    (i.e. "Ish Bern"). In this port, the dot was removed except for a couple of
    seemingly random occurrences, which were most likely editing mistakes.

  Karshvar (カルシュワル)

    Pronounced "karsh-whar." https://en.wikipedia.org/wiki/Karshvar
    "In the Avesta, reference is made to seven karshvar (Avestan:
    𐬐𐬀𐬭𐬀𐬱𐬀𐬎𐬎𐬀𐬭𐬀‎, romanized: karšvar,
    lit. 'delineated land' > Persian: kišvar), climes or zones, organizing
    the world map into a seven-storied ziggurat representing the cosmic
    mountain."

  Kerdir (キルデール)

    Pronounced something like "keer-dehr." https://en.wikipedia.org/wiki/Kartir
    "Kartir (also spelled Karder, Karter and Kerdir; Middle Persian:
    𐭪𐭫𐭲𐭩𐭫 Kardīr) was a powerful and influential Zoroastrian
    priest during the reigns of four Sasanian kings in the 3rd century."

  Khosrow (ホスロウ)

    Pronounced "hoss-rho." https://en.wikipedia.org/wiki/Khosrow_I
    "Khosrow I (also spelled Khosrau, Khusro or Chosroes; Middle Persian:
    𐭧𐭥𐭮𐭫𐭥𐭣𐭩), traditionally known by his epithet
    of Anushirvan (Middle Persian: 𐭠𐭭𐭥𐭱𐭫𐭥𐭡𐭠𐭭,
    lit. 'the Immortal Soul'), was the Sasanian King of Kings of Iran from 531
    to 579."

  Khshrunoom (フシュルヌム)

    Pronounced something like "hshroo-noom." Apparently derived from the term
    "Khshnoom", which I frankly don't think I have the necessary mindset
    to even begin to understand. Here's how some 500-page textbook on the
    subject that I found introduces it: "The word 'KHSHNOOM' occurs in the
    Gathas (Ysn. 48,12 & 53.2), and from its derivative Khshnu, to rejoice,
    means the heart-rejoicing Occult Knowledge in commentary form, referred
    to in Pahlavi as 'Zand-akas' (Bd. 1,1). Khshnoom also means divine
    or spiritual knowledge (Sans. kshna, Pers. Shanakhtan, to know)."
    https://www.holybooks.com/wp-content/uploads/A-MANUAL-OF-KHSHNOOM.pdf

  Majles (マジュレス)

    https://en.wikipedia.org/wiki/Majlis "Majlis is an Arabic term meaning
    'sitting room', used to describe various types of special gatherings
    among common interest groups of administrative, social or religious
    nature in countries with linguistic or cultural connections to the Muslim
    world. Majlis can refer to a legislature as well and is used in the name of
    legislative councils or assemblies in some states."

  Margiana (マルギアナ)

    Pronounced with a hard G sound, as in "gear." Probably from this:
    https://en.wikipedia.org/wiki/Margiana "Margiana (Greek: Μαργιανή
    Margianḗ, Old Persian: Marguš, Middle Persian: Marv) is a historical
    region centred on the oasis of Merv and was a minor satrapy within the
    Achaemenid satrapy of Bactria, and a province within its successors, the
    Seleucid, Parthian and Sasanian empires."

  Mithramihr (ミスラミフル)

    A combination of two names for the god Mitra/Mithra:
    https://en.wikipedia.org/wiki/Mitra

    Note that the original version of the game for home computers writes this
    as ミスラ・ミフル, with a dot in the middle that would generally
    indicate a space in English, i.e. "Mithra Mihr." That was removed in this
    version, so we've interpreted it as a single word.

  Nanai (ナナイ)

    https://en.wikipedia.org/wiki/Nane_(goddess) "Nane (Armenian: Նանե,
    romanized: Nanē) was an Armenian mother goddess, as well as the goddess of
    war and wisdom...She has also been referred to as Hanea, Hanea, Babylonian
    Nana, Sumerian Nanai."

  Ostracon (オストラコン)

    https://en.wikipedia.org/wiki/Ostracon "In Classical Athens, when the
    decision at hand was to banish or exile a certain member of society, citizen
    peers would cast their vote by writing the name of the person on the shard
    of pottery; the vote was counted and, if unfavorable, the person was exiled
    for a period of ten years from the city, thus giving rise to the term
    ostracism."

  Ovingstone (オヴィングストン)

    tekiro claims this to be "the name of a historian," with no
    elaboration. D-BOY's very old English-language FAQ on this game's
    terminology makes a similar claim, also failing to identify exactly who the
    historian in question is. I haven't been able to turn up anyone of note by
    this name, which makes me suspect that either one document copied the other,
    or both are parroting a common source that's completely wrong. In any case,
    the spelling of "Ovingstone" is arbitrary.

  Parsee (パールシー)

    https://en.wikipedia.org/wiki/Parsis "The Parsis or Parsees (/ˈpɑːrsiz/)
    are a Zoroastrian ethnic group in the Indian subcontinent."

  Pulse (パルス)

    If this has any real-world origin, we ignored it. It's written out as
    "PULSE" in English in multiple places in the original game, so that's what
    we used.

  Sada (サダ)

    Possibly from "Sadeh", which is spelled "Sada" in some transliterations:
    https://en.wikipedia.org/wiki/Sadeh "Sadeh (Persian: سده also
    transliterated as Sade), is an Iranian festival that dates back to the
    Achaemenid Empire."

    Another possible origin for this is an Avesta-related term:
    "Manuscripst [sic] for liturgical purposes contain the Avestan text plus
    liturgical instructions. They are called Sade or Sadah, meanig [sic]
    pure." https://en.wikipedia.org/wiki/Avesta

  Saoshyant (サオシュヤント)

    Pronounced "saosh-yant." https://en.wikipedia.org/wiki/Saoshyant "Soshiant
    (Avestan: 𐬯𐬀𐬊𐬳𐬌𐬌𐬀𐬧𐬝 saoš́iiaṇt̰) is an
    Avestan-language term that literally means 'one who brings benefit',
    and which is used in several different ways in Zoroastrian scripture and
    tradition. In particular, the expression is the proper name of the Soshiant,
    an eschatological saviour figure who brings about Frashokereti, the final
    renovation of the world in which evil is finally destroyed."

  Srosh (スローシュ)

    https://en.wikipedia.org/wiki/Sraosha "Sraosha (Avestan:
    𐬯𐬭𐬀𐬊𐬴𐬀, romanized: sraoṣ̌a or
    𐬯𐬆𐬭𐬀𐬊𐬴𐬀, səraoṣ̌a; Persian: سروش), is the
    Avestan name of the Zoroastrian yazata of "Conscience" and "Observance",
    which is also the literal meaning of his name. In the Middle Persian
    commentaries of the 9th-12th centuries, the divinity appears as
    𐭮𐭫𐭥𐭱, S(a)rosh."

  Tamrin (タムリン)

    The only thing on this list anyone's likely to notice, really. tekiro
    connects this name to "Tam Lin", a male character from a traditional
    Scottish ballad. That seems quite far-fetched to me. D-BOY's FAQ claims this
    is "tamryn", from the Russian word for "palm tree". Personally, I think
    that's also a very far-flung and unlikely origin (it has no religious
    or historical connections and would be the only thing in the game at
    all related to Russia), but many others appear to have happily adopted
    this exotic twist, including the authors of the 2007 Super Famicom fan
    translation.

    Since I feel neither of the above is a convincing explanation, by my
    personal preference and editorial fiat, this translation uses "Tamrin."

  Thuggi (サギー)

    https://en.wikipedia.org/wiki/Thuggee "Thuggee (UK: /θʌˈɡiː/, US:
    /ˈθʌɡi/) was a supposed network of organized crime in the medieval
    to post-modern centuries of gangs that traversed the Indian subcontinent
    murdering and robbing people. A member of Thuggee was referred to as a
    Thug."

    Spelling of "Thuggi" is purely because "Thuggee" felt like a very strange
    name.

  Tiridates (ティリダテス)

    https://en.wikipedia.org/wiki/Tiridates "Tiridates (Parthian:
    𐭕𐭉𐭓𐭉𐭃𐭕, Tīridāt, Old Armenian: Տրդատ, Trdat) is a
    word of Iranian origin ('given by the god Tir')." Pick anybody you like from
    the list in the article as the specific source for the name in this game;
    it's not terribly important.

  Urvan (ウルワン)

    Pronounced "urwan." From Avestan: "urunaêca [urvan] 5 (D) m. soul"
    https://www.avesta.org/avdict/avdict.htm

  Varamur (ワラムル)

    Pronounced "waramur." tekiro thinks this is from a cave in Iran that
    appears to be known as "Vara Cave" or "Wara Cave" (see, for example,
    https://damavandmt.blogspot.com/2010/01/cave-vara.html). This seems an
    awfully loose connection, so our choice of "Varamur" is ultimately quite
    arbitrary.

  Vendidad (ヴェンディダード)

    https://en.wikipedia.org/wiki/Vendidad "The Vendidad /ˈvendi'dæd/, also
    known as Videvdat, Videvdad or Juddēvdād, is a collection of texts within
    the greater compendium of the Avesta."

  Vergil (バージル)

    https://en.wikipedia.org/wiki/Virgil "Publius Vergilius Maro (Classical
    Latin: [ˈpuːbliʊs wɛrˈɡɪliʊs ˈmaroː]; 15 October 70 BC – 21
    September 19 BC), usually called Virgil or Vergil (/ˈvɜːrdʒɪl/ VUR-jil)
    in English, was an ancient Roman poet of the Augustan period."

    The Japanese spelling is specifically the Anglicized
    "Vergil/Virgil" as opposed to the Latin pronunciation of "Vergilius"
    (ウェルギリウス). The choice of "Vergil" over "Virgil" is, of course,
    arbitrary.

  Vourukasha (ウォウルカシャ)

    Pronounced "whoa-ru-kasha." https://en.wikipedia.org/wiki/Vourukasha
    "Vourukasha is the name of a heavenly sea in Zoroastrian mythology. It was
    created by Ahura Mazda and in its middle stood the Harvisptokhm or the 'tree
    of all seeds.'"

  Yaman (ヤマン)

    https://en.wikipedia.org/wiki/Airyaman "In the Avesta, airyaman (Avestan:
    𐬀𐬌𐬭𐬌𐬌𐬀𐬨𐬀𐬥, romanized: airiiaman) is both an
    Avestan language common noun and the proper name of a Zoroastrian divinity."

  Zalma (ザーマ)

    Probably derived from https://en.wikipedia.org/wiki/Zam: "the Avestan
    language term for the Zoroastrian concept of 'earth.'" Specific spelling as
    "Zalma" is arbitrary and for aesthetics.

  Zandieg (ザンディーグ)

    https://en.wikipedia.org/wiki/Zandik "Zandik (Middle Persian:
    𐭦𐭭𐭣𐭩𐭪) is a Zoroastrian term conventionally interpreted as
    heretic in a narrow sense, or, in a wider sense, for a person with any
    belief or practice that ran contrary to Sassanid-mediated Zoroastrian
    orthodoxy."

    The name used in this game appears to be deliberately different from the
    actual source word (ザンディク), so we've used a similarly altered
    spelling.

                    ****************************************
                    *        VII. Authors' Comments        *
                    ****************************************

  ----------
  - cccmar -
  ----------

  Emerald Dragon is certainly a JRPG of its time. From the music and the
  graphics to the voice acting, you'll see right away that the game has same
  nostalgic quality to it as many other games from that period. So how does it
  play? Imagine an evolution of Ys with turn-based battles; it reminds me of a
  game called Madara on the Famicom, too. That kind of system tends to be rather
  slow, and that is the case here too (high encounter rate as well. Arguably,
  presentation is this game's strongest suit. Everything is as it should
  be. However, it seems to me that the game was either meant to be episodic or
  have more entries (I know of at least the planned prequel). As a result, the
  story feels kinda disjointed and not fully fleshed-out. In other words, the
  game is rather shallow. Still, it might scratch that itch for those wishing to
  play more JRPGs from that time period.

  ---------------
  - Oddoai-sama -
  ---------------

  The last time I had to deal with run and bump combat was in the early Ys games
  and although it's far from perfect, I'd say it's a lot more engaging when done
  in real time. Emerald Dragon's turn-based variant of this battle system ends
  up working against itself once the novelty wears off, making encounters more
  of a time sink than a challenge provided you equip the latest gear and don't
  stray from where the story sends you. This, combined with a mostly useless
  escape command and the ai's behavior, makes it very difficult to actually lose
  fights while simultaneously managing to lengthen your game time. That being
  said, I'm still not tired of it for all my criticism and the story itself
  is serviceable and presented well. All in all this feels like the videogame
  adaptation of a larger work and it's been enjoyable to go through, even if it
  loses steam toward the end.

  ----------
  - Supper -
  ----------

  Some years back, I believe there was somebody -- and I feel terrible that I
  can't remember your name, but I guess you know who you are -- who said they
  were glad that I worked on translating the unusual games that I did instead of
  just doing "cookie-cutter RPGs." Well, here I am, translating a cookie-cutter
  RPG. I guess I thought betraying all my principles would be more fun than
  this. Where did I go wrong?

  Aah, where do I start? Emerald Dragon isn't a game I had any particular
  attachment to coming into this project. I'd never played it and knew nothing
  about it except that it was an RPG, it was supposedly a good game, and some
  nonzero number of people wanted to see it translated. I tend not to work
  on mainstream titles like this one simply because I rarely find them very
  interesting. I prefer things that have uniqueness or personality to them, even
  if they're not what most people (even myself) would actually consider fun --
  Galaxy Fraulein Yuna certainly springs to mind. But I figured that for once,
  I'd try to give people what they think they want, so Emerald Dragon it was.

  There's a lot I could say about this game, and I actually got about
  halfway through a lengthy diatribe here before thinking better of it. So
  I'll spare you most of that and just get to the point: I actually don't
  much care for this game. The production values are high, the game systems
  are polished, and the presentation is dramatic -- boy, does this game ever
  want to be dramatic! -- but beyond the surface level, there's simply very
  little there. The plot is shallow, with potentially interesting story angles
  constantly ignored in favor of beating up the nearest bad guy (and despite the
  title, everything related to dragons was clearly just an afterthought). The
  characters themselves are fine, and I can certainly imagine someone telling
  a nice story about them, but despite the reams of party chat dialogue, they
  never grow or develop or really do much of anything interesting. Combat is
  slow and unengaging, with the vast majority of the time spent watching the AI
  take its turns. And with random encounters frequent and all but inescapable,
  once the "wow" factor wears off, the whole experience turns into a tedious
  test of patience.

  The first thing I did when I started on this project in early May was play
  through the whole game, so I knew full well what I was getting into. But I
  wanted to do a relatively big, technically complex project for a game that
  some people might actually be interested in playing, so I decided to take it
  on despite my personal distate. My initial playthrough only took 29 hours
  despite the impediment of having to read the text in a foreign language,
  so I knew it wasn't too unreasonable a size. I figured it would be somewhat
  difficult, but doable.

  Well, I was looking for "technically complex," and I certainly got it. Alfa
  System had a reputation for technical prowess, and the code in this game
  definitely lives up to it. It's generally written in a very tight and tricky
  way that puts everything else I've ever looked at on the PCE at to shame, with
  heavy use of advanced techniques like stack manipulation and self-modifying
  code to build a highly capable -- and difficult to understand -- game engine.

  It was a lot to deal with, and I had to significantly step up my game to
  make this happen. There's really no way to actually explain the complexity
  involved in setting up an assembler framework for injecting duplicate copies
  of the same arbitrary code fragments into multiple pre-existing binaries while
  simultaneously allowing them all to link against each other properly; simply
  organizing the structure of the system was nearly as bad as actually writing
  all the low-level code. And believe me, writing that low-level code was pretty
  damn bad.

  The cutscenes were particularly hellish. One of this game's brag points was
  that the cutscenes are all presented full-screen instead of being letter-
  and/or pillarboxed, as most PCECD games were. That's very impressive and
  all, but unfortunately means the game consumes even more VRAM than usual, and
  often puts a big, moving sprite layer at the bottom of the screen -- and since
  the hardware has an incontrovertible 16-sprites-per-line limit, that's a big
  problem if you want to show subtitles on top. For the first time ever, I wound
  up being forced to use raster interrupts to crop the bottom of the screen
  in certain scenes so that the subtitles wouldn't screw everything up. It's
  unfortunate, and I generally avoided it where I could, but I can't make the
  hardware do things it's fundamentally incapable of.

  It also didn't help matters that I grew very frustrated with the turgid
  pace of the game's combat and took it upon myself to add a new fast-forward
  feature, which then had to be extensively tested to make sure it didn't
  accidentally change any of the battle mechanics. Bet you didn't know that
  the game determines what Tamrin's lasers hit by running a collision algorithm
  on the individual segments of the beam as the animation plays, huh? Well, I
  only found out once I realized her attacks were never hitting anything when
  fast-forward was on. So that part had to be totally reworked to run all the
  calculations synchronously instead (which is why the game hitches so much if
  you skip that animation). Great fun.

  In the end, I managed to get everything squared away, but I'm pretty sure
  it was the largest amount of technical work I've ever had to put into a
  project. I'd be a liar if I told you I enjoyed it, but I'm at least satisfied
  that I was able to make it happen.

  And oh yeah, I also had to actually translate the game. The dialogue itself
  doesn't tend to be all that complicated, but it turned out the game required a
  lot more localization work than I initially realized. A lot of the headaches
  came once I learned that most of the names were derived from Zoroastrianism
  or related historical terms; I spent a significant number of hours poring
  over such riveting reading as an Avestan dictionary or a Japanese translation
  of the Bundahishn, searching for clues to the more obscure names. That, I
  certainly hadn't signed up for.

  There were also a lot of coined or not-really-translatable terms that needed
  to be turned into something satisfactory in English. The name for the enemy
  forces, for instance, is 魔軍, which is not a real Japanese word; the
  individual characters translate literally as "demon army." Well, "the Demon
  Army" sounds like just about the most generic bunch of bad guys in the world,
  doesn't it? Direct translations of kanji compounds tend to end up being like
  that: overly verbose and very robotic-sounding in a way that the original
  word is not. So I made my best effort to come up with sense approximations
  that sound like something you might find in a fantasy novel: the "demon army"
  is the Hellions, the 魔王 ("demon king") is the Infernal One, the 魔王殿
  ("demon king palace") is the Infernum, the 魔獣 ("demon beasts") are
  Hellspawn, the 魔闘鬼 ("demon war ogre") is the Warmonger, etc. This is a
  situation where literal correctness is clearly not the most important concern.

  I knew the project was going to be a lot of work, but thanks to all the
  technical and localization struggles involved, it wound up being even more
  than I bargained for. It did ultimately work out, and for that, I'm glad...but
  unfortunately, I can't say that I came out of this with any more enthusiasm
  for the game than I started with. I got very little out of it personally,
  and if I'm quite honest, I wish I'd done something else instead. Guess that's
  a pretty downer note to end on, but perhaps that's my just deserts for picking
  a project to try to please the public instead of myself. Well, next time, I'll
  just have to choose a game no one but me could possibly give a damn about.

  All that aside, I hope some of you will enjoy this game despite my
  naysaying. By no means is it _bad_, and I've made every effort to make it as
  palatable as I can. But it's not very deep -- neither the gameplay nor the
  plot -- so don't expect too much, either. Try to take it for what it is: a
  cleaned-up port of a nice, but dated, game.

                    ****************************************
                    *         VIII. Special Thanks         *
                    ****************************************

Per tradition, thank you to elmer for the bugfixed bchunk executable included in
the patching process.

Thanks to SadNES cITy Translations for the Delta Patcher program, which is
bundled with this patch as a convenience.

Thank you to tekiro for attempting to make a reference for the origins of the
game's unusual names: http://www.tekiro.main.jp/?eid=318204 While it's not
perfect, it was invaluable for many of the more obscure terms.

Thanks to contributors to MobyGames for their work compiling information on the
readings of the development staff's names, which was used as a reference for
translating the credits.

Thanks as well to Nightcrawler, Eien Ni Hen, and other contributors for their
translation of the Super Famicom version of the game back in 2007. I didn't
actually play it or use it as a reference for anything, but glancing over
videos of it did clue me in on a couple of details I'd overlooked, such as the
plurality of "Golden Fangs."

                    ****************************************
                    *         IX. Version History          *
                    ****************************************

v1.0 (31 Dec 2025): Initial release.
