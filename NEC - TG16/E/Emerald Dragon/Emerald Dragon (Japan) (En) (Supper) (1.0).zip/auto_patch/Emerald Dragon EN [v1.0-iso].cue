FILE "Emerald Dragon EN [v1.0-iso] 01.wav" WAVE
  TRACK 01 AUDIO
    INDEX 01 00:00:00
FILE "Emerald Dragon EN [v1.0-iso] 02.iso" BINARY
  TRACK 02 MODE1/2048
    PREGAP 00:03:06
    INDEX 01 00:00:00
FILE "Emerald Dragon EN [v1.0-iso] 03.wav" WAVE
  TRACK 03 AUDIO
    PREGAP 00:02:00
    INDEX 01 00:00:00
FILE "Emerald Dragon EN [v1.0-iso] 04.wav" WAVE
  TRACK 04 AUDIO
    INDEX 01 00:00:00
FILE "Emerald Dragon EN [v1.0-iso] 05.wav" WAVE
  TRACK 05 AUDIO
    INDEX 01 00:00:00
FILE "Emerald Dragon EN [v1.0-iso] 06.wav" WAVE
  TRACK 06 AUDIO
    INDEX 01 00:00:00
FILE "Emerald Dragon EN [v1.0-iso] 07.wav" WAVE
  TRACK 07 AUDIO
    INDEX 01 00:00:00
FILE "Emerald Dragon EN [v1.0-iso] 08.wav" WAVE
  TRACK 08 AUDIO
    INDEX 01 00:00:00
FILE "Emerald Dragon EN [v1.0-iso] 09.wav" WAVE
  TRACK 09 AUDIO
    INDEX 01 00:00:00
FILE "Emerald Dragon EN [v1.0-iso] 10.wav" WAVE
  TRACK 10 AUDIO
    INDEX 01 00:00:00
FILE "Emerald Dragon EN [v1.0-iso] 11.wav" WAVE
  TRACK 11 AUDIO
    INDEX 01 00:00:00
FILE "Emerald Dragon EN [v1.0-iso] 12.wav" WAVE
  TRACK 12 AUDIO
    INDEX 01 00:00:00
FILE "Emerald Dragon EN [v1.0-iso] 13.wav" WAVE
  TRACK 13 AUDIO
    INDEX 01 00:00:00
FILE "Emerald Dragon EN [v1.0-iso] 14.wav" WAVE
  TRACK 14 AUDIO
    INDEX 01 00:00:00
FILE "Emerald Dragon EN [v1.0-iso] 15.wav" WAVE
  TRACK 15 AUDIO
    INDEX 01 00:00:00
FILE "Emerald Dragon EN [v1.0-iso] 16.wav" WAVE
  TRACK 16 AUDIO
    INDEX 01 00:00:00
FILE "Emerald Dragon EN [v1.0-iso] 17.wav" WAVE
  TRACK 17 AUDIO
    INDEX 01 00:00:00
FILE "Emerald Dragon EN [v1.0-iso] 18.wav" WAVE
  TRACK 18 AUDIO
    INDEX 01 00:00:00
FILE "Emerald Dragon EN [v1.0-iso] 19.wav" WAVE
  TRACK 19 AUDIO
    INDEX 01 00:00:00
FILE "Emerald Dragon EN [v1.0-iso] 20.wav" WAVE
  TRACK 20 AUDIO
    INDEX 01 00:00:00
FILE "Emerald Dragon EN [v1.0-iso] 21.wav" WAVE
  TRACK 21 AUDIO
    INDEX 01 00:00:00
FILE "Emerald Dragon EN [v1.0-iso] 22.wav" WAVE
  TRACK 22 AUDIO
    INDEX 01 00:00:00
FILE "Emerald Dragon EN [v1.0-iso] 23.wav" WAVE
  TRACK 23 AUDIO
    INDEX 01 00:00:00
FILE "Emerald Dragon EN [v1.0-iso] 24.wav" WAVE
  TRACK 24 AUDIO
    INDEX 01 00:00:00
FILE "Emerald Dragon EN [v1.0-iso] 25.wav" WAVE
  TRACK 25 AUDIO
    INDEX 01 00:00:00
FILE "Emerald Dragon EN [v1.0-iso] 26.wav" WAVE
  TRACK 26 AUDIO
    INDEX 01 00:00:00
FILE "Emerald Dragon EN [v1.0-iso] 27.wav" WAVE
  TRACK 27 AUDIO
    INDEX 01 00:00:00
FILE "Emerald Dragon EN [v1.0-iso] 28.wav" WAVE
  TRACK 28 AUDIO
    INDEX 01 00:00:00
FILE "Emerald Dragon EN [v1.0-iso] 29.wav" WAVE
  TRACK 29 AUDIO
    INDEX 01 00:00:00
FILE "Emerald Dragon EN [v1.0-iso] 30.wav" WAVE
  TRACK 30 AUDIO
    INDEX 01 00:00:00
FILE "Emerald Dragon EN [v1.0-iso] 31.wav" WAVE
  TRACK 31 AUDIO
    INDEX 01 00:00:00
