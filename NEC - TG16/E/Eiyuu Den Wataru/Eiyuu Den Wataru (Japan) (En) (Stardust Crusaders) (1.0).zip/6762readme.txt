==========================================================
====================Mashin Hero Wataru====================
==========================V 1.00==========================
Genre: Platformer

Source language: Japanese

Platform: PC Engine HuCard

Patch language: English

Author: Pennywise

E-mail: antoniusblocko@protonmail.com
		
http://yojimbo.eludevisibility.org/
 
======================================================
About Mashin Hero Wataru
======================================================
Project History:

This project is probably about 10 years old at this
point. It was basically abandoned then restarted
recently and was fairly simple to do.



======================================================
Patching Instructions
======================================================
You can patch the ROM with FLIPS or use RHDN's online
patcher.

https://www.romhacking.net/patch/

http://www.romhacking.net/utilities/893/

Apply the patch to the Japanese ROM:

Mashin Hero Wataru.pce

We would be highly grateful, if you find some time to 
contact us with proposals or corrections. Information
on found bugs or corrections would be highly 
appreciated.

P.S.

Support the game industry by buying used games!

Even if the money doesn't go to the developers
directly, as the games become rare and harder
to find, the price goes up, and people become
more inclined to buy new releases "while they can!"

======================================================

Credits go to:

Pennywise - hacking, text editing

aishsha - translation

The MajinZenki - additional translation, ending translation

Ryusui - spot translations

harmony7 - spot translations

Graphicus - title screen design

cccmar - testing

All those who contributed into this process.

======================================================

Compiled by Pennywise. December 2022