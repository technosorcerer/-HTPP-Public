Mr. Heli no Daibouken (PC Engine)
Traducción al Español v1.0 (05/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mr. Heli no Daibouken (Japan).pce
MD5: 31867ab522ff7b9937987ec473db0a11
SHA1: df6346583d7169ffdec03925c9b15d3e4f066079
CRC32: 2cb92290
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --