Tatsujin (PC Engine)
Traducci�n al Espa�ol v1.0 (14/05/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tatsujin (Japan).pce
MD5: 0674f72871d7a779d262b519d244e33a
SHA1: dda768075fbf8c0624e2c1f217b1092513b1c942
CRC32: a6088275
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --