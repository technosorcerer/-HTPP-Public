Language patch (text only)
Language: Dutch
--------------------------

Vertaling naar het Nederlands
Versie: 1.0
Datum: 06-05-2019
(c) 2019 Kana Translations

--------------------------
Opmerkingen bij deze patch
--------------------------
Deze vertaling en hack is geheel oorspronkelijk.

--------------------------
Patch-instructies
--------------------------
De patch heeft de IPS-indeling, en kan worden toegepast
met LunarIPS of Floating IPS.

--------------------------
Spelinformatie
--------------------------
Gebruikt oorspronkelijk bronbestand:

Titel: Tatsujin (Japan).pce
Platform: PC Engine / Turbografx-16

MD5:   0674F72871D7A779D262B519D244E33A
SHA1:  DDA768075FBF8C0624E2C1F217B1092513B1C942
CRC32: A6088275
Bytes: 524288

--------------------------
Dankwoord/Credits
--------------------------
Kana - Nederlandse vertaling en hack

--------------------------
Very special thanks
--------------------------
Wave - voor het briljante programma Hextractor, website:
traduccioneswave.blogspot.com

-- EINDE --

Tatsujin
Options menu: hold select + run button on the title screen

Expanded option menu: play the game to 7100 points,
then reset (hold select + run button),
and on the title screen hold select + start