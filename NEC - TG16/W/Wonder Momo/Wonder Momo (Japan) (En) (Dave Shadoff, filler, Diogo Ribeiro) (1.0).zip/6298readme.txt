
--------------------
Wonder Momo (HuCARD)
--------------------
English Translation Patch
Version 1.0

---------------
About the Patch
===============

The game is fully playable in English.
This patch has been made available for free.
Commercial use is strictly forbidden--including but not limited to "repros."

------------------
Applying the Patch
==================

Lunar IPS is an easy-to-use Windows tool to apply IPS patches to ROMs
available here: https://fusoya.eludevisibility.org/lips/

--------------
Filler's Notes
==============

In late 2019, running low on Game Gear scripts to dump I turned my attention to other systems, namely the Mega Drive and PC Engine. I ended up decoding the custom script encoding and dumping a script for Wonder Momo on November 9th of 2019. Incidentally, I accidentally deleted the table file I'd made after dumping the script and used a data recover program to save myself having to remake it.

It looks like I was busy translating and editing the script for Sorcery Saga A (Madou Monogatari A) for several months. Come February of 2020 the English language translation patch for Sorcery Saga A was released and I decided to translate the small script for Wonder Momo.

I got curious what was up with the line "viva non non". Best I can tell it's a reference to a song from 1968 by "Drifters" (https://youtu.be/i1cL63afoi0). I guess it's a pop rendition of a folk song to which they added the line "viva non non". From what I recall it's considered to be nonsense, or possibly a reference to a cabaret the band visited, but as of now I can't locate any sources to corroborate.

I may or may not have reached out to anyone to hack the game, but at any rate I listed the game under "orphaned projects" on my website and moved on to other things.

Fast forward to September 24th of 2021, 4lorn reached out to me saying he'd started working on the game and noticed it listed under my orphaned projects. I sent along my script and the rest is history.

Many thanks to PC Engine expert and occasional collaborator David Shadoff who helped expand the ROM and find the text pointers to facilitate inserting the English language script. Also, thanks of course to 4lorn for reaching out to me and handling much of the technical work on this project.

-------------
4lorn's Notes
=============

Hubris is a terrible thing, but it can get you into interesting situations.

After finishing my translation for Rabio Lepus on the PC Engine, I decided to look into other unlocalized games for NEC's platform. Riding high on my success with the previous one, which turned out to be a solo project, I decided to work on Wonder Momo and thought that maybe, just maybe, a second solo project could turn out just as good.

Oh, sweet PC Engine translation child.

It only dawned on me after I had extracted the script for Namco's game that someone might have already tried translating it - there's not a whole lot of text, and the game is fairly easy to edit. I soon discovered filler had already worked on a translation and so, rather than have the game suffer what might end up being a subpar translation on my behalf, I contacted him and he sent me his script.

To say the project didn't quite turn out like I was expecting is an overstatement. There is barely any compression, but little in the way of breathing room for extended scripts either. Attempts to hijack certain parts of video RAM weren't very successful, so I then decided to contact the ever brilliant dshadoff, who had previously worked with filler on Maison Ikkoku's translation. dshadoff was gracious enough to go well beyond the call for technical assistance, expanding the ROM, patching in several text repointing routines and even fixing a Vsync timing problem - every PCE emulator that  stumbled when rendering the original Wonder Momo will now display the translated version without problems.

Along the way, we both ended up figuring out a way to overcome the game's double-spacing for cutscenes, which also helped.

As these obstacles were overcome, I then replaced the Japanese characters with a new English font, localized the logo for the title screen and inserted the script.

And here we are, with another PC Engine game translated to English! I hope everyone enjoys the localized version of Wonder Momo.

My thanks to filler for his delicious script; dshadoff for his technical wizardry, which is beyond words; and my hubris, for giving me the chance to work with this great team. I won't be seeing it again, but who knows, maybe filler, dshadoff and me will work together again...

-------------
Viva Non Non!
=============

