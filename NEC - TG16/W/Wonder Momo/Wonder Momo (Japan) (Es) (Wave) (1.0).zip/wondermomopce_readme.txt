Wonder Momo (PC Engine)
Traducción al Español v1.0 (23/10/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basada en la de Dave Shadoff, Diogo Ribeiro y filler.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Wonder Momo (Japan).pce
MD5: 367c426ccd7b9ce45e86a836d83d17db
SHA1: 5af6050a0a549e73f05a2d06fd2f55a93027be5f
CRC32: 59d07314
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --