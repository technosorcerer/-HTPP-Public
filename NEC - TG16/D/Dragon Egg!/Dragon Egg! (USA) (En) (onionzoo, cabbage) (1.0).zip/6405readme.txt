
--------------------
Dragon Egg! (HuCARD)
====================

English Translation Patch
Version 1.0


---------------
About the Patch
===============

The game is fully playable in English.
This patch has been made available for PERSONAL USE ONLY.
COMMERCIAL USE IS STRICTLY FORBIDDEN. That includes "repros."
This patch may not be redistributed in any form, partially or wholly, without written permission.


------------------
Applying the Patch
==================

Just apply the included IPS patch to your ROM. 
If your ROM has a header, you can use the "HEADER" version patch.
Use your favorite IPS patching tool. 
I recommend the very simple Lunar IPS program for Windows users.
It is available here: http://www.romhacking.net/utilities/240/


--------------
Author's Notes
==============

2021.12.30

I have been sitting on this patch for a long time now, so 
I figured it was time to release it. Dragon Egg probably 
didn't need an English translation, but I decided to make 
one anyway, since I've always enjoyed the game. I hope 
you enjoy it, too. 

Big thanks to onionzoo for translating the text. 

 -- cabbage

http://cabbage.cx
Twitter @HuCABBAGE


------------------
See you next time?
==================
