Daisenpuu (PC Engine)
Traducci�n al Espa�ol v1.0 (25/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Daisenpuu (Japan).pce
MD5: 677302bdec15a9c56ef6b7aade125fad
SHA1: 81f8c8f01530bb3d22e2dd463202d0e26e7faf24
CRC32: 9107bcc8
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --