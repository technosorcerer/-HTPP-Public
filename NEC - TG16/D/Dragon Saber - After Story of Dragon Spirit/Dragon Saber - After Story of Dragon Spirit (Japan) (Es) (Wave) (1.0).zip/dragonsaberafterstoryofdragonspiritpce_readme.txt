Dragon Saber - After Story of Dragon Spirit (PC Engine)
Traducci�n al Espa�ol v1.0 (30/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dragon Saber - After Story of Dragon Spirit (J).pce
MD5: a8dbe74d6cb012951478202e3b5ea08a
SHA1: 6d94cd3e27dbe1694229f7f006dc821be4764aa2
CRC32: 3219849c
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --