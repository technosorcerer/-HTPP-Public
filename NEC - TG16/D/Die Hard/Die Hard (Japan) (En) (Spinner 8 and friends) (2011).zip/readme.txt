

                       (insert elite ascii graphic here)


                        Die Hard 1.0 (3 February 2011)
                             Official Readme File!

------------------------------------------------------------------------------

I. Introduction
II. Project
IIa. Project Members
IIb. Tools
IIc. History
III. End-User Information
IV. Thx
V. Legal stuff that would never hold up in court

------------------------------------------------------------------------------

                             Introduction

I wasn't even aware that there was a version of Die Hard for the TurboGrafx/PC
Engine until about a month ago. Not even that supreme tome of knowledge,
Wikipedia, had so much as a mention! It's by Pack-In-Video, the same
developers as the NES Die Hard, but the two games are very different. This one
is much more action-focused, playing like a top-down shooter in the style of
Commando or Ikari Warriors and such. You don't even start out in the Nakatomi
Building, where the entirety of the movie takes place - the first level is in
a jungle area (the game calls it a "garden"), and the second level is a huge
swamp kind of place (the game calls this a "pond"). It's pretty weird, but you
should still check it out sometime.


------------------------------------------------------------------------------

                               Project

Things went pretty smoothly once I figured out that the font was stored as
four large bitplanes, one after the other, along with an incredibly simple
compression scheme. It was weird to figure out and even weirder to hack, so I
wrote a cute little program to calculate what each of the layers should be.
The hardest part was taking the incredibly dry Japanese script and turning it
into something that John McClane, the lead character of the Die Hard
franchise, would actually say. Hopefully it all worked out okay.


Members:
--------
Spinner 8 (spinner_8@parodius.com)
  - hacking
DarknessSavior (DarknessSavior@gmail.com)
  - translation

You can visit our respective websites at suprise.oddigytitanium.com and
dsrh.dedtech.com if you want! Except that coincidentally, neither website is
currently up. Whoops! Visit them later!


Tools used:
-----------
Mednafen 0.9.015-WIP by Mednafen Team
  (http://mednafen.sourceforge.net)
WindHex32 EX 0.99.14 by Bongo`
  (http://stealth.romhack.net)
HxD 1.7.7.0 by Ma�l H�rz
  (http://mh-nexus.de)
Atlas 1.06 by Klarth
Tile Layer Pro 1.1 by Kent Hansen
Relative Searcher 2.5 by Jair
Microsoft Visual C# 2010 Express 10.0.30319.1 by Microsoft Corp.
  (http://www.microsoft.com/express/Downloads/)
  

Patch history!
--------------
Version 1.0 - All pre-level monologue scenes translated. A typo in the debug
              menu was corrected. That's pretty much it.
              
              
Known Issues
------------
- With a quick hack like this, there shouldn't be any problems, although there
  may be some errors that I somehow repeatedly glossed over. Please please
  email me at spinner_8@parodius.com with any issues, so that I may fix them.


------------------------------------------------------------------------------

                               End-User

In this age where emulation is much more common than playing games on the
original hardware with game copiers, the completely unnecessary headers on
TG16/PCE games are slowly being phased out. This means that this translation
patch is only usable on ROMs that do NOT have this header. Those of you with a
ROM compatible with No-Intro standards should be fine, but everyone else
should bear in mind that your ROM absolutely must be 524,288 bytes in size or
this patch will NOT work. For the extra-cautious, the CRC should be 1B5B1CB1.

If your ROM is 524,800 bytes in size, never fear! Simply open the ROM in your
favorite hex editor and delete the first 512 bytes. In other words, everything
from 0 to 1FF (mostly zeroes) should be deleted. Then you'll be able to patch
your ROM with no problems. And don't worry, your ROM will still run in every
modern TG16/PCE emulator, including Magic Engine, Ootake, Hu-Go!, and
Mednafen.

The game's controls are as simple as simple can be. The II button punches and
shoots, the I button jumps. Just like you think it would.


------------------------------------------------------------------------------

                               Thanks!

This translation is entirely dedicated to Drakee, since I did it all for him
as a (very) late Christmas present. Merry Christmas, bro, and thanks for all
the used UMDs.

Big thanks to DarknessSavior, who handed me a translated script in less than
twenty-four hours. He was also always there when I needed corrections or
re-wordings, so his input in this project was invaluable. Hurray!

Thanks once again to Sardius for testing the game and making sure everything
wasn't too terribly written. Thanks also to Colonel Buttons for his assistance
with testing.

Thanks to Beckey and Emily for their attempts at helping me write the script.
Your help is appreciated, but in the end I decided to have McClane say things
other than simply "where the fuck am I fuck this shit fuck!!".

Thanks once again to oddigy for the webspace. This year, I promise.

   
------------------------------------------------------------------------------

                         Legal Made-up Stuff

This is a free translation, and is not for profit. Please respect the spirit
of this project and do not sell or otherwise profit from this translation.

Please do not distribute this translation patch with the original Japanese
ROM, either pre-patched or otherwise. By itself, however, you are welcome to
re-distribute this translation, so long as this readme file is included.

Feel free to use this translation as a base for your own (non-profit) work,
but please do me the courtesy of letting me know about it. It's not absolutely
necessary, of course, but I just like to hear about such things.