Dragon Spirit (PC Engine)
Traducci�n al Espa�ol v1.0 (30/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dragon Spirit (U).pce
MD5: 1fe13078c7aba4ef0777d5a470d56986
SHA1: 3bdd082360335232715633b469da71ab2597279d
CRC32: 086f148c
262.144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --