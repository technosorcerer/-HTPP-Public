Drop Off (PC Engine)
Traducción al Español v1.0 (05/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Drop Off (U).pce
MD5: 7df6342574ed3e0241029a11f1f5c4da
SHA1: 54bb6ea11aca4ca6a16ba439828ba1f6fada3623
CRC32: fea27b32
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --