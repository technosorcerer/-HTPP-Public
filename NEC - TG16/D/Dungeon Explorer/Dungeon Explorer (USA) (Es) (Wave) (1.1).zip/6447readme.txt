Dungeon Explorer (PC Engine)
Traducción al Español v1.1 (21/11/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1:Arreglado juego para 3-5 jugadores.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dungeon Explorer (USA).pce
MD5: a07c43bea439c8c904bc4908737af5c5
SHA1: d6d18128d55d886a9b6a8c8ea65af76e783001f9
CRC32: 4ff01515
393216 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --