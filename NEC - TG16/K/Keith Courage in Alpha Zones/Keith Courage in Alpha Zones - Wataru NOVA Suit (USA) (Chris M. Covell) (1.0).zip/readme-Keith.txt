NOVA Suit / Ryuujinmaru Suit hacks
----------------------------------
for Keith Courage (TurboGrafx-16) and Mashin Eiyuu Den Wataru (PC-Engine)
-------------------------------------------------------------------------
by Chris Covell (chris_covell -at- yahoo.ca)
--------------------------------------------


What?
-----

Well, these are relatively simple hacks that let you play in the overworld
levels of Keith Courage / Wataru as the NOVA suit / mecha.  People have
long complained that the overworld sections of this game are tedious and
slow-paced, due to the plodding little boy whom you have to control in
this stage.

Well, go nuts!  Cruise through these levels with the speed of the mech suit!

There are .IPS patch files for both the US and JP versions of this game.
Feel free also to explore the included source code to see what was changed.


What else?
----------

I've also made the game's built-in debug menu more easily accessible: when
"START" shows up on the title screen, press the I button.  The final two
options let you choose whether to play as the NOVA suit in both over- and
underworld sections, OR!!  try playing the challenging underworld stages
as the titular slow and plodding little boy!  Consider it a new "hard mode"
for this game.

This game had to have quite a few changes made in order to allow for the NOVA
suit in the overworld, and Keith Courage / Wataru in the underworld battle
stages.  Most importantly, the boy normally can't jump high enough in the 
underworld to clear platforms, so I've added to his jump height.  He can now,
with a little skill from you, clear every jump in the underworld levels -- 
barring one in Level 6, which needs a long-distance jumper.
Oh, well, use the NOVA suit for that one.

Other changes involve some palette selection hacking, and extensive hacking or
rerouting of the gravity and character control routines which diverge depending
on what's being controlled, either Keith or the NOVA suit.  For example, the
NOVA suit never needed to go into shops, so that was impossible until I had to
hack that functionality back in.  And the overworld never had disappearing
platforms, so when Keith is in the underworld where there are some, he would
fall right through them!  So, those routines had to be put back in.

Anyhow, enjoy this hack, don't take it too seriously, and I hope this makes
Keith Courage / Wataru more exciting to play!

Chris Covell, 10/25/2021
www.chrismcovell.com