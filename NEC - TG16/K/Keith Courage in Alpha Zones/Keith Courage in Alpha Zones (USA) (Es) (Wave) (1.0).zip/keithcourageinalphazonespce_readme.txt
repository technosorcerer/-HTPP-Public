Keith Courage in Alpha Zones (PC Engine)
Traducción al Español v1.0 (08/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Keith Courage in Alpha Zones (U).pce
MD5: e5309b10903ccc3032c2f919e8db7384
SHA1: 09f37cf6ddbbf202994d88ac62225ca027e791ac
CRC32: 474d7a72
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --