Kiki Kaikai (PC Engine)
Traducción al Español v1.0 (26/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Kiki Kaikai (Japan).pce
MD5: b345329df7acc1938c291440dd1ed5ad
SHA1: 8dc4fce4beca91f51f123acf8f1cc659ed58d312
CRC32: c0cb5add
393216 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.
Sensenic - Traducción del Japonés.

-- FIN --