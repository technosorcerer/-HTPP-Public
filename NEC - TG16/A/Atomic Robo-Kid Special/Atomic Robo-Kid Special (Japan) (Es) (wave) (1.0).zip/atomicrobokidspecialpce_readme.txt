Atomic Robo-Kid Special (PC Engine)
Traducci�n al Espa�ol v1.0 (16/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Atomic Robo-Kid Special (Japan).pce
MD5: 548ca5eb135f526f3a2837f5259d795f
SHA1: 1ea46287855ef25e4614a3f37a7037baa5a49545
CRC32: dd175efd
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --