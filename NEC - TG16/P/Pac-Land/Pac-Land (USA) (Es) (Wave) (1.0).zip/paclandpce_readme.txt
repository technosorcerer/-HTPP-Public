Pac-Land (PC Engine)
Traducción al Español v1.0 (16/09/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pac-Land (U).pce
MD5: 5cc45bfe5da979c51417e77bfe221a2b
SHA1: ff74f1812196ec5c64df4b9a78a4697d3b53ef1a
CRC32: d6e30ccd
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --