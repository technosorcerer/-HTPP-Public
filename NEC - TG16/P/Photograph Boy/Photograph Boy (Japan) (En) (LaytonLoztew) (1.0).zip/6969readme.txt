Gekibo: Gekisha Boy	"Photograph Boy"
Platform: PC Engine

English
1.0

Author: LaytonLoztew
E-mail: laytonloztew@gmail.com
Site:	laytonloztew.neocities.org

====================================
Background
====================================
This is a fully playable English patch for "Gekibo: Gekisha Boy"

====================================
Patching
====================================
Use with:

(No Intro)
Gekisha Boy (Japan).pce
355F281D002A139A05525264A28FB526
E8702D51

====================================
About
====================================
The previously available translation exhibits a few issues, this new translation is intended to resolve those flaws and improve the player's experience:

- Text box sizes now mostly match the original.

- Text boxes have been fixed to prevent overlapping, aside from some intended instances in the original.

- The original credits have been restored, and translated.

- Hints for all levels have been rewritten to be more accurate and specific.

- Dialogue after the final level now makes it clearer which rank you have achieved.

- All text has been rewritten to better match the original.


The title screen logo and some minor text is still untranslated.

====================================
Comments
====================================
This patch was originally made while creating achievements for RetroAchievements. During this process I discovered the following:

- The dean's dialogue after each level is determined by the following:
<10 pictures taken = "Not many photos here, are there?"

>=25 good pictures taken = "Not bad! You are getting good!"
 <25 good pictures taken = "Try harder to take better photos."
 <15 good pictures taken = "So many blurry photos."
 
 
- You can achieve three ranks after the final level: B, A, and S

B-Level Cameraman: Complete the game with atleast one game over
A-Level Cameraman: Complete the game without a game over
S-Level Cameraman: Complete the game without a game over, and achieve at least 350,000 points in levels prior to TAKE 09.

====================================
Credits
====================================
LaytonLoztew - hacking, translation, testing

====================================
Thanks To
====================================
Zatos Hacks, Alexander Beetle - previous translation referenced
RetroAchievements