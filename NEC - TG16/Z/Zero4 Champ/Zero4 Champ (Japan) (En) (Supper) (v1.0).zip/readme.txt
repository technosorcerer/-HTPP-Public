﻿********************************************************************************
*                                 Zero4 Champ                                  *
*                          English Translation Patch                           *
*                           by Stargood Translations                           *
*                              v1.0 (03 May 2025)                              *
*                                                                              *
*                               Supper -- Hacking & Translation                *
*                               cccmar -- Editing & Testing                    *
*                             Xanathis -- Testing                              *
*                          Oddoai-sama -- Testing                              *
********************************************************************************

Zero yon: quarter-mile drag racing. Its short length is exactly what gives
it its mystique, with the slightest mistake spelling certain defeat for the
hapless driver. Arriving in the big city from the countryside, a young man
becomes enchanted by the world of zero yon and resolves to be the top racer in
Japan. But with little more than a banged-up clunker and some pocket change to
his name, the road is sure to be a long one. Do you have what it takes to build
the car of your dreams and race your way to the top?

Developed and published by Media Rings for the PC-Engine in 1991, Zero4 Champ
(pronounced "Zero Yon Champ") is a racing/adventure game, notably the first
racing game for a home console to feature real-life cars licensed from Japanese
auto makers. Though nominally a drag racing game, it features an extensive story
mode with simulation and money management elements. Its unusual concept proved
to be a surprising commercial success, resulting in several sequels over the
following years.

And do take note: its sense of humor is distinctly...risqué. Don't say you
weren't warned.

This patch fully translates the game into English.

                    ****************************************
                    *          Table of Contents           *
                    ****************************************

     I. Patching Instructions
    II. Cheats and Bonuses
   III. Authors' Comments
    IV. Special Thanks
     V. Version History

                    ****************************************
                    *       I. Patching Instructions       *
                    ****************************************

To use this translation, you'll need to apply a patch to a ROM image of Zero4
Champ for the PC-Engine.

** IMPORTANT ** There are two different versions of Zero4 Champ! Following
its original release, a later "V1.5" version with a minor bugfix was also
published. This translation is based on the later version; the original release
is NOT supported. Please make sure to use the right ROM, or the translation
won't work.

The original, unmodified ROM should match the following specifications:

  No-Intro name: Zero4 Champ (Japan) (V1.5).pce
  CRC32:         b77f2e2f
  MD5:           cf51006c86541b94e8305f456c4d47c5
  SHA-1:         2b664760931cc6011d31cae310410dab7cba2067

For maximum compatibility, this patch is provided in both BPS and IPS
formats. The .bps and .ips files in this package contain the exact same
content and will produce the same output ROM; the only difference is the patch
format. Please use BPS if possible, as it automatically verifies that you are
patching the correct ROM and will give an error if you use the wrong file.

Choose either the .bps or .ips file, then use a BPS or IPS patching
program to apply it to your ROM file (do not apply both). Floating IPS
(https://github.com/Alcaro/Flips/releases) is an excellent choice for this
purpose and can handle both patch formats, but any other patcher should work
just as well.

For specific details on how to apply the patch, see your patching program's
instructions.

                    ****************************************
                    *        II. Cheats and Bonuses        *
                    ****************************************

Zero4 Champ contains a slew of secrets and hidden codes. Some of them
involve entering special passwords in Japanese that had to be changed for the
translation, so this section contains information on how to activate them. For
the benefit of anyone interested, other obscure easter eggs are also covered
here.

  --------------
  - Sound Test -
  --------------

  Start a new game and enter the following as your name:
  NAVEL

  This will open the sound test.

  (Original code: みかのへそ, "Mika's belly button".)

  -------------------
  - Start with GT-R -
  -------------------

  At the title screen, select "Continue" and enter the following password:
  IWANTAFASTCARBUTHAVINGTOWORKSUX

  This will begin a new game in which you start with the Skyline GT-R, the most
  expensive vehicle in the game.

  (Original code:
  はやそうなくるまがひとつほしいけどばいとするのがめんどうだなあ,
  "I want to get a fast-looking car, but working part-time is such a pain".)

  --------------------------
  - Start with Extra Money -
  --------------------------

  At the title screen, select "Continue" and enter the following password:
  GIVEMEMONEYCUZINEEDTOPIMPMYRIDE

  This will begin a new game in which you start with 10,000,000 yen.

  (Original code:
  いいおんなくるまにのせてみたいけどかねがないからなにもできない,
  "I want to give good-looking girls a ride in my car, but can't do anything
  because I don't have the money".)

  --------------------
  - Start with Nitro -
  --------------------

  At the title screen, select "Continue" and enter the following password:
  ISUCKREALLYHARDSOGIVEMENITROPLZ

  This will begin a new game in which you start with 255 Nitro Jet items.

  (Original code:
  へたくそでどじでのろまでどんくさいこんなわたしににとろください,
  "Please give nitro to I, who am unskilled, clumsy, a blockhead, and stupid".)

  ---------------
  - View Ending -
  ---------------

  At the title screen, select "Continue" and enter the following password:
  ENTERTHISPASSWORDTOSEETHEENDING

  This will play the ending sequence.

  (Original code:
  もういちどさいごがみたいそんなひとこれをいれればはいこのとおり,
  "'I want to see the ending again.' Such people, if you enter this...yes, like
  this...")

  ------------------------------
  - Super Tune/Nitro Jet Cheat -
  ------------------------------

  Go to the auto shop, and when Gan's first box of dialogue is displayed,
  press the following sequence of buttons on the D-Pad: LUDDURUDDURU (the same
  sequence of presses required to shift from neutral up through fifth gear
  during a race). After agreeing to be called a "loser", you'll be given the
  option to get your car super-tuned or receive 10 Nitro Jets for free.

  --------------------------
  - Vs. Mode Car Passwords -
  --------------------------

  In Vs. Mode, it's possible to use passwords to load a car, and you're
  intended to use the first five characters of a normal password generated
  in-game for this purpose. However, due to the game lacking thorough password
  validation, it's possible to use made-up passwords to load cars that are
  normally unobtainable (only used by opponents), or even invalid "glitch"
  cars. These aren't intentionally programmed cheats, just consequences of a
  not-so-well-thought-out password system, much like "JUSTIN BAILEY" and similar
  "cheat codes" from other games. They're nonetheless somewhat interesting, so
  here's a list of such passwords for use in the translation.

  These passwords are conversions of the Japanese codes found on this page:
  http://zero4champ.web.fc2.com/z4c/ura/ Thanks to the contributors of the
  original information, some of which seems to date back to magazine reader
  write-in sections from 1991. Note that the original source lists multiple
  codes for the same car; I've simplified this to just one each.

    tMI!T   Skyline 2000 RS Turbo-C
    lfspl   Soarer 3000GT
    1qls3   Toyota Sports 800
    51s0a   Fairlady 240Z
    mPYYe   Toyota 2000GT (displayed as the March iz on the preview screen,
            but shows up correctly during races)

  The following passwords are accepted, but result in glitched
  cars. Unfortunately, due to changes in the translation, they'll probably just
  cause the game to spew garbage text and freeze on the car preview screen. But
  for completeness' sake:

    ns?TV   Glitched, extremely fast car
    iiddd   Glitched car
    nbsdj   Glitched car

  ---------------------
  - Other Easter Eggs -
  ---------------------

  - Win the UFO Pitcher minigame three times, then play it again.

  - If you give Mami a two-second head start but still win the race against
  her (which is most likely impossible without using a Nitro Jet), she does in
  fact make good on her promised "reward" afterward. NOTE: This scene contains
  graphic content.

  - Answer all ten questions wrong on any segment of the driver's license
  renewal exam that occurs every three years. (Incidentally, the exam continues
  indefinitely until you get at least nine out of ten questions right.)

  - If you enter certain terms as your name, such as "SEX", the game will
  "censor" them. The list of censored words is actually quite long and includes
  a number of "unusual" entries; if you're really that interested, you can find
  it in the translation's script.

                    ****************************************
                    *        III. Authors' Comments        *
                    ****************************************

  ----------
  - Supper -
  ----------

  I'll just confess up front: I don't know a damn thing about cars. To give
  you an idea of how far out of the loop I am, I was surprised to learn in
  the course of translating this that almost all modern cars are front-wheel
  drive. Needless to say, me and this game were not a match made in heaven.

  My history with this series is a strange and stupid one. An extremely long
  time ago, long before I knew a lick of Japanese much less had anything to do
  with the fan translation scene, a copy of Zero4 Champ II somehow found its
  way onto my PC through circumstances I've long since forgotten. This was in
  the bad old days when emulating any PCECD game besides maybe Castlevania was
  hopeless, so I never got to play it, had no idea what it was even about, and
  ended up just sticking the CD audio music in my playlist. Eventually I lost it
  in a hard drive crash and forgot about it.

  But the odd name stuck with me, so when I was studying Japanese by reading
  articles in the old magazine PC Engine Fan years later, I wound up reading a
  long walkthrough article for it. I never bothered playing -- still haven't,
  actually! -- but as a result, I learned not just some helpful new vocabulary
  words like 抑える (got to keep those RPMs in check), but all about zero yon
  racing and the general concept of the games.

  Thus, when I bumped into the series for a third time in March, after happening
  to spot a Let's Play thread for it while waiting for testing to wrap up on The
  Blue Crystal Rod, I finally caved and actually played this game. I was looking
  for a new project to work on, and it turned out that it met all the criteria I
  had in mind: a PC-Engine game -- HuCard rather than CD for a change of pace --
  not too long, and a genre I'd never really worked on before (racing, though
  admittedly it's at least as much of an adventure game as a racer). That,
  combined with the fact that it turned out to be surprisingly fun, was good
  enough for me, so I got to work and here we are.

  After spending so many years working exclusively on PCECD games, doing a short
  HuCard game would probably have been a walk in the park, except for some
  reason I decided to add a bunch of entirely self-imposed difficulties. The
  original game uses typical tile-based printing, but I wanted the translation
  to look as good as I could possibly make it, so I basically dynamited that
  and replaced it with a new printing system using dynamically allocated
  tiles, allowing for variable-width text with full character kerning and
  multiple fonts. Oh, and I threw in dynamic word wrapping too, because why
  not? (Because it's a big pain in the ass, that's why!) This probably added
  weeks to the development time, but it was quite satisfying when it all came
  together...eventually.

  The translation side of things was pretty easy, aside from the obvious
  hangup of having to do a lot of research not just on cars in general, but
  _Japanese_ car lingo specifically. The game doesn't use too much jargon,
  mercifully, but you won't find terms like 手曲げマフラー in your
  average dictionary. Still, the script was less than a quarter the size of the
  one from my last project, so despite all difficulties, this felt like a breeze
  by comparison.

  Honestly, considering the length of the script, the technical work I
  did on this was probably massive overkill. To give you an idea of the
  disproportionate amount of work involved here, I wrote well over twice as much
  code for this project as I did for The Blue Crystal Rod, a far larger game. I
  can't help but think that what I did with this translation was kind of like
  taking the March iz you start the game with, buying all the upgrades for it,
  and then getting it super-tuned on top of that: there's really no reason at
  all to do it except to amuse yourself. Luckily, that was my only real goal,
  and I succeeded!

  I ended up sinking quite a bit of work into this -- relative to the length of
  the game, anyway -- and I'm pretty satisfied with how it turned out. I doubt
  there's a huge audience for it, but I can at least imagine a few people will
  appreciate it.

  Well, enjoy. My apologies in advance for any car terminology I screwed
  up. Seriously, I tried!

  ----------
  - cccmar -
  ----------

  Zero Yon Champ was a surprise to me. It's a game that wasn't really on my
  radar before this project even though I do enjoy a racing game every now and
  then, and this is a fairly long-running series, starting with this entry. It's
  definitely more than that, however, with various additional modes and ideas
  very uncommon in the genre (such as first-person dungeons). Overall, it's an
  interesting game that is not very well known in the West due to the lack of
  release, so I hope you enjoy it!

  ---------------
  - Oddoai-sama -
  ---------------

  At first the VN format was the main draw for me but this game turned out to
  have more in store than a racing car driving simulator with shounen manga
  plot vibes. I certainly didn't expect to find a miniature dungeon crawl
  with classic RPG battles among the few minigames that help you progress,
  and although the game gets rather grindy toward the end it was an interesting
  experience overall.

  I suspect the technical details for the featured real-life cars deserve to
  be praised for their accuracy, sadly I don't know anything about cars! But I
  trust the developer did his research since he's a car enthusiast.

  All in all a decent title by 90s standards, just gets a tad repetitive.

                    ****************************************
                    *          VI. Special Thanks          *
                    ****************************************

Thank you to the apparently anonymous author of the following Japanese strategy
guide site for the game, which was a very helpful resource during the creation
of this translation: http://zero4champ.web.fc2.com/

Special thanks to Isometric Bacon for starting a Let's Play of this game that
reminded me of the series' existence at just the perfect time to start working
on this project. I looked it over after I finished the translation, and it was
really great to have some actual context for all the cars featured in this game,
which otherwise are just a bunch of names to me. Sorry this "real" translation
probably isn't as amusing as machine-generated gibberish...

                    ****************************************
                    *         VII. Version History         *
                    ****************************************

v1.0 (03 May 2025): Initial release.
