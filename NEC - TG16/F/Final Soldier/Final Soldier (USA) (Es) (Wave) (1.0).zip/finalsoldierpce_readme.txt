Final Soldier (PC Engine)
Traducci�n al Espa�ol v1.0 (03/05/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Final Soldier (J).pce
MD5: fe5b3f899f0ee5994508f259bbb74cfe
SHA1: ce89c6ea5d9eb36a642742ecad9c35c16b761c49
CRC32: af2dd2af
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --