
---------------------------------
Fushigi no Yume no Alice (HuCARD)
---------------------------------
English Translation Patch
Version 1.0

---------------
About the Patch
===============

The game is fully playable in English.
This patch has been made available for free.
Commercial use is strictly forbidden--including but not limited to "repros."

------------------
Applying the Patch
==================

Lunar IPS is an easy-to-use Windows tool to apply IPS patches to ROMs
available here: https://fusoya.eludevisibility.org/lips/
or here: http://www.romhacking.net/utilities/240/


-------------
4lorn's Notes
=============

A fun little project, this.

Out of several candidates, Fushigi no Yume no Alice (Alice's Dreams in Wonderland) came up as a potential translation project once the pieces started to line up. Filler had already extracted the majority of the script back in 2020, Dave Shadoff made the suggestion based on the script's small size, and MooZ's knack for graphical de/encoding and quickly locating vital routines soon made it possible to handle several issues. All that was left was to translate the game, reinsert the text and do some graphical editing on the side.

Care was placed into bringing forward a translation that felt like an official, overseas release. To this end, I was adamant about localizing the title and logo screen in a way that felt faithful to the original; while most people would go by the game's name alone, Fushigi no Yume no Alice actually ventures into several fairy tales, including not only Lewis Carroll stalwarts but also Pinocchio and the Little Red Riding Hood folk tale. Since the story involves denizens of these tales being corrupted or placed in harm's way, we decided on "The Fairytale Dreams of Alice", as it represents both the developer's intention and the game's content.

For the most part, it was a standard translation project: smooth sailing until it wasn't, troublesome until it no longer was. It should be noted that although the translation had to undergo several cuts and revisions in order to fit within limits, it's perfectly playable and readable as it stands. An expanded version of the script might be doable but is not being considered at the moment.

Dave Shadoff, MooZ, filler, and I hope everyone enjoys this English translation of Fushigi no Yume no Alice!

---------
Viva NEC!
=========



