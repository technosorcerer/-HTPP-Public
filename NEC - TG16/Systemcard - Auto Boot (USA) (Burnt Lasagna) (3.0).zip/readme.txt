=======================================
Auto-boot SYSTEMCARD 3.0 Patch
=======================================

This IPS patch is intended to slightly streamline TurboGrafx-CD emulation and maybe real hardware via flashcards. What it does is make the prerequisite SYTEMCARD3.0 auto-boot into the game and remove the system cards graphics. 
Basically, this patch makes it so that it can seamlessly start CD games the second you start it in an emulator/flashcard, removing the system card menu being the middle man. 

This patch was built around the modified system card 3 ROM that�s included with TurboGrafx-CD Virtual Console games. I simply removed the cards graphics to make its presence almost non-existent.

-Burnt Lasagna
http://www.romhacking.net/community/1599/
