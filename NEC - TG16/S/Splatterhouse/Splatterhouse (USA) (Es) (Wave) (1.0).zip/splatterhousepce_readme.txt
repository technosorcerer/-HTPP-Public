Splatterhouse (PC Engine)
Traducción al Español v1.0 (27/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Splatterhouse (U).pce
MD5: f6690ec0f440ced641718d6bc52e3fbd
SHA1: e2167b5d67a065ec97763d3ee843ac2b2328c082
CRC32: d00ca74f
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --