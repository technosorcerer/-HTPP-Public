==========================================================
=====================Tower of Druaga======================
=========================V 1.01===========================
Genre: Action

Source language: Japanese

Platform: PC Engine HuCard

Patch language: English

Author: Pennywise

E-mail: antoniusblocko@protonmail.com
		
http://yojimbo.eludevisibility.org/
 
======================================================
About
======================================================
Project History:

This project began last year after Mesen released a
new emulator update with PC Engine support. Previously
Mednafen was the best option though its command-line
design never sat well with me. So when that released
I started poking around with a few games and this game
was basically good practice.

There's already a translation for this game, but there
was room for improvement. So I began working on it on
and off with several breaks until it was finished.

======================================================
Version History
======================================================
1.0 - initial release
1.01 - secret message translated

======================================================
Patching Instructions
======================================================
Apply the patch to the Japanese ROM:

Druaga no Tou (Japan).pce

We would be highly grateful, if you find some time to 
contact us with proposals or corrections. Information
on found bugs or corrections would be highly 
appreciated.

P.S.

Support the game industry by buying used games!

Even if the money doesn't go to the developers
directly, as the games become rare and harder
to find, the price goes up, and people become
more inclined to buy new releases "while they can!"

======================================================

Credits go to:

Pennywise - hacking, text editing

Ryusui - spot translations

TheMajinZenki - spot translations

Graphicus - misc graphic design

cccmar - testing

All those who contributed into this process.

======================================================


Compiled by Pennywise. January 2024