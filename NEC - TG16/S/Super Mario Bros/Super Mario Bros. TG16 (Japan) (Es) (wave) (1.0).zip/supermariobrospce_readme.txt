Super Mario Bros (PC Engine)
Traducción al Español v1.0 (18/06/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Mario Bros (J) [p1].pce
MD5: 0608d3243e0a1a755140a1e03420809e
SHA1: 5c2d1c1615772dcb931ee18a9d0c65555e76a919
CRC32: 3347b4c8
65536 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --