Soldier Blade (PC Engine)
Traducci�n al Espa�ol v1.0 (03/05/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Soldier Blade (U).pce
MD5: 59d23b7af39ea827eceb1d7e2cc363c0
SHA1: 3b4cc242f68a1d61c83a1a0dbdee23d2ae8f1427
CRC32: 4bb68b13	
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --