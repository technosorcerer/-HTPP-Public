S.C.I. - Special Criminal Investigation (Japan) Noise Fix
-----------------------------------------------------------

This is a fix that removes the extra noise during the title screen, quieter sections of the game, and the pause screen.
If you play the game on real hardware or certain FPGA systems, this could be very beneficial for you, especially with decent audio hardware. 


Install
---------
Use the patcher of your choice to apply to the No-Intro version of the ROM. Won't work on headered ROMs, like those from older sets.

Notes
-------

This game is a sequel to Chase HQ, and as it turns out, the way it does audio is also very similar. There was a little bit more going on, but it was still doing a lot of needless opening and simple muting of channels.
As to the game itself, this is a smart follow-up to the original. Lots of interesting new ideas. A shame the audio samples are worse overall haha.