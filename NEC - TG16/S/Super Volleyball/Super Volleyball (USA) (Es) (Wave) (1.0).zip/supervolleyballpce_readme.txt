Super Volleyball (PC Engine)
Traducción al Español v1.0 (01/01/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Volleyball (USA).pce
MD5: 2b31c6c01d779eec5bb19863e3c5af9b
SHA1: de71722255d0136b47f63e93bedb2ed8b3d0d4f0
CRC32: 245040b3
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --