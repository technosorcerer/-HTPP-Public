Sonic Spike - World Championship Beach Volleyball (PC Engine)
Traducción al Español v1.0 (08/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Sonic Spike - World Championship Beach Volleyball (U).pce
MD5: e9a17f9e425cb6cf3e14c83eddd7dc06
SHA1: 5a74eead0593190979028ef99a19519bab00b3ab
CRC32: f74e5eb3
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --