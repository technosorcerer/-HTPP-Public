+-------------------+
| SonSon II English |		v1.0b - 11/15/97
+------+------------+
| Info |
+------+
Translated: Everything
Needed: Testing
Start date: 11/3/97
End Goal: perfect translation (no bugs)

FAQ:
====
Q- Can I report bugs?
A- Sure can. Meet me on EFNet and tell me.  Also, try and
	take a screen cap of it.  It helps.
Q- What?  Son Goku?  Isn't he the guy in Dragon Ball?
A- Yes.  Dragon Ball was based on a Chinese myth.  This is
	based on the same myth.
Q- This game is tough! How much more do I have to go through?
A- There are 7 levels.

Thanks/Messages
===============
Demi - FF2e rocks!
Planet X Software - 'cuz BigWierd r0x j00 all
Flobbasko - just 'cuz he's helped me

DISCLAIMER
==========
SonSon II is a trademark/copyright of Capcom Co. Ltd
and NEC Avenue.  This translation is unauthorized.
Use at your own risk.  Don't blame us if you get in
trouble.