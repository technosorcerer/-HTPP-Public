Super Star Soldier (PC Engine)
Traducción al Español v1.0 (30/08/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Star Soldier (U).pce
MD5: bc7d4b0852d04fe49f6e3705b899c5e5
SHA1: e0c487782e155b1cf50f5fb4c8d6a24be0301a6e
CRC32: db29486f
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --