Language patch (text only)
Language: Dutch
--------------------------

Vertaling naar het Nederlands
Versie: 1.0
Datum: 11-04-2019
(c) 2019 Kana Translations

--------------------------
Opmerkingen bij deze patch
--------------------------
Deze vertaling en hack is geheel oorspronkelijk.

--------------------------
Patch-instructies
--------------------------
De patch heeft de IPS-indeling, en kan worden gebruikt met LunarIPS of Floating IPS.

--------------------------
Spelinformatie
--------------------------
Gebruikt oorspronkelijk bronbestand:

Titel: Violent Soldier (Japan).pce (No-Intro Romset)
Platform: PC Engine / Turbografx-16

MD5:   6E1F6D152F17B6008D1968D016C34A1A
SHA1:  76581FE7ACB707B1E5BAB2AC27CD27E3ED06078A
CRC32: CB2939F1
Bytes: 1BC36B36

Titel: Sinistron (USA).pce (No-Intro Romset)
Platform: PC Engine / Turbografx-16

MD5:   1C5EB68A65115ABACCD9479503FD3A2B
SHA1:  65DEFEEECFE60564A214B6572F94243FCFEA78E0
CRC32: CB2939F1
Bytes: 393216

--------------------------
Dankwoord/Credits
--------------------------
Kana - Nederlandse vertaling en hack

--------------------------
Very special thanks
--------------------------
Wave - voor het briljante programma Hextractor, website:
traduccioneswave.blogspot.com

-- EINDE --