Shinobi (Japan) Noise Fix
----------------------------

This is a fix that removes a lot of extra noise during the title screen, quieter sections of the game, mission screen, and the pause screen.
If you play the game on real hardware or certain FPGA systems, this could be very beneficial for you, especially with decent audio hardware. 


Install
---------
Use the patcher of your choice to apply to the No-Intro version of the ROM. Won't work on headered ROMs, like those from older sets.

Notes
-------

Someone requested this game get one of these patches. I had only played the SMS version, and enjoyed that very much. I think this version might be better, but the audio issues were pretty horrendous.
The audio is fairly programmatic. Credits to the origianl developers, there's some intelligent design in the way the game programmatically runs through just a handful of lines, discerning what to do based on loaded memory.
The issue with the above is that it is constantly opening all channels at full volume right before it does anything (because it doesn't know what it's about to do), so it can't be stopped there unless you like total silence. There's a few places where it very intentially is trying to tear down audio, and edits to those sections can silence parts of gameplay, but that leaves the title screen, and interstitial mission screens.
There was a separate routing that gets called for muting the main amp, and that was only used for specifically silent segments, like the title screen or transitions, and this function was redirected to something that closed all channels to fully silence the system.
Lastly, there's a programmatic function that sets the stereo volume based on the content, every frame that audio is generated, but because it's programmatic it never closes the channels, just sets zero if there's no data. As such, I set up a jump that closes the active channel in the event the values are zero, otherwise, it writes as intended.

This was a fun project to try to clean up. Hopefully it's a good improvement for all, especially for a game that plays pretty well, and, now, sounds pretty good as well.