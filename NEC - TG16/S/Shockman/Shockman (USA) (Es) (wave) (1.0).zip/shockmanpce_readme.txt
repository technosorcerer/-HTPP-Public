Shockman (PC Engine)
Traducción al Español v1.0 (11/09/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Shockman (USA).pce
MD5: 57c888f4af792dc4588a2f9dbebea31a
SHA1: f3e0f9546afe257748496a652f138dbc318bed05
CRC32: 2774462c
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --