Violent Soldier (PC Engine)
Traducci�n al Espa�ol v1.0 (25/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Violent Soldier (Japan).pce
MD5: 6e1f6d152f17b6008d1968d016c34a1a
SHA1: 76581fe7acb707b1e5bab2ac27cd27e3ed06078a
CRC32: 1bc36b36
393.216 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --