Victory Run (PC Engine)
Traducción al Español v1.0 (20/09/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Victory Run (U).pce
MD5: bc4361c967514ef29293778ad748a6b7
SHA1: bab16031a16490415cedd5ba47cbe4cadc3d8727
CRC32: 85cbd045
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --