Ballistix (PC Engine)
Traducción al Español v1.0 (16/09/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ballistix (U).pce
MD5: 9610910760ed0c034961866ceb7d4e23
SHA1: 8f65c5b459b477adc97ab7809ca8e85329f25769
CRC32: 420fa189
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --