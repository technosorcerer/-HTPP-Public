Bloody Wolf - Noise Fix
---------------------------

This patch fully closes out the audio channels during pause, which will prevent the variable level of noise that could play when the music would stop.
This is helpful for real hardware of any revision and certain FPGA implementations, if using more sensitive audio hardware (though it can be reasonably audible on tiny portable speakers too)

Installation
-------------------
Apply the patch to a nointro version of the US game. It has not been tested on any other region version, and will definitely not work on a headered ROM

About
------------
The original game had a simple pause routine, which basically just muted the entire amp output. 
This is more effective than other schemes that often leave noise, but it could still leave variable nosie depending on what last was played.
The new scheme of this patch goes through a simple routine to close all channels, thus greatly eliminating noise.

Most of the game is fine and manages audio well, but the pause screen was a bit too simple, and was just annoying enough for me to quickly try to do something about it haha.
