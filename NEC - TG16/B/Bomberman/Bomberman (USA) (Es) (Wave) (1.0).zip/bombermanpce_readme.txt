Bomberman (PC Engine)
Traducción al Español v1.0 (11/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bomberman (U).pce
MD5: 22945308eb41396f39c00444be9f251f
SHA1: dc63680e579764bbacb7f07514f4f49ab888d3b1
CRC32: 5f6f3c2a
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --