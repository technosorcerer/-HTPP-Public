Battle Royale (PC Engine)
Traducción al Español v1.0 (20/09/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Battle Royale (U).pce
MD5: beb2b4486ed8a66f0df10e260bdc5224
SHA1: 07b39d5315aa07bf880b89b10dc3c01ed7ced5ab
CRC32: e70b01af
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --