Boxy Boy (PC Engine)
Traducción al Español v1.0 (27/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Boxy Boy (U).pce
MD5: c316ad2e57400feaf16fcaff67935b00
SHA1: 7e165324d735a20156fd90ac97d0bf1c115e0a02
CRC32: 605be213
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --