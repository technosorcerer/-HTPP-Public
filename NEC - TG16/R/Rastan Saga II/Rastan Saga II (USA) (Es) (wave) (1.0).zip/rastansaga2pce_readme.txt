Rastan Saga II (PC Engine)
Traducci�n al Espa�ol v1.0 (14/09/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rastan Saga II (Japan).pce
393.216 bytes
MD5: e998693ab9d694eebe66e5942fd5137e
SHA1: cf06ba4d1bd31ebd69f0415ae52848f752ec8f6b
CRC32: 00c38e69

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --