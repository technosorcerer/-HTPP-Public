R-Type Part-2 (PC Engine)
Traducci�n al Espa�ol v1.0 (25/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
R-Type Part-2 (Japan).pce
MD5: 9fda7ef8db7fe2799149cb0fbef20c95
SHA1: 7667dce9f6a09f8197efe0718e476b48579760d6
CRC32: f207ecae
262.144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --