----R-Type Plus----
This is a simple hack that that looks to unify the positive elements of the Japanese and Western releases of this game. Benefits are:
1. Both the first and second half of the game in one game card (like the US version)
2. Passwords for continuing midway and starting second loop (like the I and II Japanese cards)
3. Reduced flickering (like the Japanese versions)


----Applying the patch----
Grab a No-Into version of the US version of the ROM (CRC: 91CE5156), and apply the patch. Works on original hardware, in my testing.


----Passwords----
All original passwords for the Japanese versions of the game will work as expected. Passwords for the R-Type II card will start you half-way through the game. To access passwords, at the title screen, hold Select, the press Run. If attempting the Credits cheat at the title screen, be sure to release the Select button before pressing Run to start, if you don't want to engage the PAssword function.

This patch does also allow "cheat" passwords, as in passwords where you can have more power-ups at the very start of the game, or at the start of second loop, than was originally allowed.

Here is a short list of known tested passwords:

---2nd Half, 1st Loop
JJL-6589-MB
Full speed, all upgrades

COK-1722-NI
Normal Speed, all upgrades, air laser

COK-1722-NG
Normal Speed, all upgrades, ground laser

COK-1722-NC
Normal Speed, all upgrades, reflective laser

---1st Half, 2nd Loop
CPL-3590-CM
Normal Speed, 2 orbs and missiles

DPK-6133-DN
Normal Speed, very few upgrades

---2nd Half, 2nd Loop
COK-1722-PI
Normal Speed, all upgrades, air laser

COK-1722-PG
Normal Speed, all upgrades, ground laser

COK-1722-PC
Normal Speed, all upgrades, reflective laser

---Cheat Passwords
JJL-6589-MN
Full speed, all upgrades, 1st loop, 1st stage

JJL-6589-ON
Full speed, all upgrades, 2nd loop, 1st stage


----Password Analysis---
I haven't spent a ton of time digging into the system, but here are my notes from what I have dug into:
Password layout - lll-nnnn-ll
Letters cannot be higher than 'P', otherwise it will create an automatic failure before any decryption.

The first 4 letters are the most important, applying directly to upgrades, abilities and loops. Each consists of 4 bits, with the least significant bit acting as a component of the xor checksum scheme the game uses to authenticate passwords. This effectively means there are odd and even letters. In Hex: 'A' = $00, 'P' = $0F

Each bit aligns in order from the last to the first letter, going from bit 1, 2, 3, to 4, excluding bit 0 and the higher bits. This assembled value is what the xor checksum must match, which is calculated from the first 7 characters of the password. The final character acts mostly as modifier.

Numbers are directly related to your score, and are calculated based on a fixed conversion, that's modified by the last two bits of authentication bits (the value created from these is what is then subtracted).

Here is what the letters define:

3rd letter
2nd bit = Missiles
3rd+4th bit = 1 or 2 orbs

4th letter
2nd bit = 1st or 2nd loop
3rd+4th bit = Weapon

1st letter = speed

2nd letter = lives

last letter = Level / Modifier (M or N will mean you start on the first stage)