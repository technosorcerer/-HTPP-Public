Night Creatures (PC Engine)
Traducción al Español v1.0 (12/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Night Creatures (USA).pce
MD5: e658e63f886560e9c388e2a9ee2eb349
SHA1: 16c4b43f92f5bc6c99fe84f71daff76cf1c0d0a6
CRC32: c159761b
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --