Ninja Spirit - Noise Fix
----------------------------

This patch closes out the channels that were generating extra noise during the game, thus making the silent portions of the game actually silent
This patch is useful for real hardware of any revision, as well as certain FPGA implementations

Installation
---------------

Apply this patch to the nointro US version of Ninja Spirit. It may also work other region versions, but not headered versions

About
---------
Artemio is due credit for originally documenting the issue on his page, as well as for a potential fix.
This patch likely differs from his, as it only specifically patches the locations necessary to close the audio at the event of certain sound and pause events.

The noise was incredibly bothersome to me, so I am glad he and others in the community took the time to review and document sound variance across the platform.