Ghost Manor (PC Engine)
Traducción al Español v1.0 (05/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ghost Manor (USA).pce
MD5: 2f2d4d92c14ba5770edd5f449507aac8
SHA1: 7092a265599194a280eca9314b496079cc49dcbd
CRC32: 2db4c1fd
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --