﻿********************************************************************************
*               Ginga Ojousama Densetsu Yuna 2: Eien no Princess               *
*                          English Translation Patch                           *
*                              v1.0 (18 Dec 2021)                              *
*                                                                              *
*                               Supper -- Hacking and Translation              *
*                             Mafoo343 -- Manual Translation,                  *
*                                         Translation Support,                 *
*                                         Testing                              *
*                        TheMajinZenki -- Translation Support                  *
*                               cccmar -- Testing                              *
*                             Xanathis -- Testing                              *
********************************************************************************

With the forces of darkness once again at bay, life seems to have returned to 
normal – or as close to normal as it gets for high school idol and galactic 
savior Yuna Kagurazaka. But trouble is brewing! After an unfortunate encounter 
with her self-proclaimed rival Erika Kousaka, Yuna accidentally summons a 
planet-destroying warship, the "Eternal Princess," to Earth. Now Yuna, 
partnering with mysterious android girl Yuri Cube, has scant days to try to take 
out the beacons guiding the ship before it arrives and annihilates the Earth, 
all while battling the deadly assassins of the "Erika 7." Is there any hope for 
the planet!?

Ginga Ojousama Densetsu Yuna 2: Eien no Princess (Galaxy Fraulein Yuna 2: The 
Eternal Princess) is a 1995 adventure game/visual novel for the PC-Engine Super 
CD-ROM² system, developed by Red Company and Will and published by Hudson Soft. 
The sequel to the original Galaxy Fraulein Yuna, it mostly follows in its 
predecessor's footsteps on a larger budget, with bigger and better visuals, full 
voice acting, and much more polish all around. Compared to the first game, it 
drops most pretenses of interactivity in favor of basically being a low-res OVA 
that requires periodic button presses to watch, with the occasional battle or 
minigame to break things up. And there's sometimes dungeon crawling, for some 
reason?

This patch fully translates the game into English.

                    ****************************************
                    *          Table of Contents           *
                    ****************************************

  I.    Patching Instructions
  II.   Running the Game
  III.  Known Issues
  IV.   Additional Features
  V.    Debug and Unused Stuff
  VI.   Authors' Comments
  VII.  Special Thanks
  VIII. Version History

                    ****************************************
                    *       I. Patching Instructions       *
                    ****************************************

To use this translation, you'll need to apply a patch to a disc image of the 
game. Unfortunately, patching disc images is inherently complicated because 
there are numerous CD image formats in use, as well as many ways that 
poorly-written disc ripping programs can mess things up and make a patch not 
work properly. As a result, this is a rather long section – sorry! But please 
read it over carefully before complaining that the patch doesn't work.

Just to be clear: this patching process is designed to support every disc image 
format it reasonably can. Though a Redump-verified disc image is a definite 
plus, options are provided to patch pretty much any image so long as it has the 
correct data track. If you don't have one of the Redump images, just go ahead 
and try to patch whatever you have using whichever of the options below applies 
to it.

Now then, here are your options for patching, approximately ordered from best to 
worst:

  A. Directly patch a single-file Redump-verified BIN or IMG image
  B. Directly patch a multi-track Redump-verified BIN image
  C. Automatically patch a BIN or IMG image via binpatch.bat
  D. Automatically patch an ISO+WAV+CUE image via isopatch.bat
  E. Manually patch

These options are explained in the subsections that follow.

  -------------------
  - BEFORE STARTING -
  -------------------

There are two known versions of this game: the FABT version and the FAAT 
version, distinguished by the last four characters of their disc mastering code. 
Curiously, these versions are actually identical save that the audio tracks are 
offset by exactly one sample between them. Don't ask me why. This patch is based 
on the FABT version, which appears to be more common, but an additional patch is 
provided for the FAAT version.

It should go without saying, but first, extract all the contents of the 
translation patch's ZIP to your hard drive if you haven't already.

Before you start, you'll need to determine what format your disc image is in. At 
the very least, you must have an image in BIN+CUE, IMG+CUE, or ISO+WAV+CUE 
format; more exotic formats are not supported. It's unfortunately not uncommon 
to come across disc images that don't use the standard file extensions used in 
this section, or use them differently from normal, which makes things very 
confusing. Some tips:

  - One common way of distributing disc images is the "dual CCD/CUE" format. 
This consists of four files: a CCD, a CUE, an IMG (or possibly BIN), and a SUB. 
If your image is like this, you can throw away the CCD and SUB files, as they 
aren't needed for the patch. For our purposes, an IMG is the same as a BIN, so 
any references to a "BIN" below can also refer to an "IMG" or vice versa.
  
  - If your disc image has a CCD but no CUE, you may be able to patch it with 
method A. If that fails, you'll need to look into creating or obtaining a CUE 
file for the disc.
  
  - If your disc image consists of a CUE and a large number of BIN files, it's 
in the "split BIN" format. This format is particularly used by the distributions 
available on certain archival web sites. It's possible to patch this format as 
long as the BIN files represent one of the Redump disc images, just split up 
into its component tracks.
  
  - You're not likely to see them much these days, but old, lossy formats like 
ISO+MP3 are not supported.

  --------------------------------------------------------------------
  - A. Directly patch a single-file Redump-verified BIN or IMG image -
  --------------------------------------------------------------------
  
Use this method if at all possible. While not as simple as the auto-patching 
method described later, it gives the most reliable results.

You can patch using this method if your disc image *exactly* matches a verified 
"good" image as listed on Redump.org, and if all the tracks on the disc are 
combined into one single BIN or IMG file.

First, check that your disc image contains a single file with the extension 
".bin" or ".img". If it does, verify that that file matches one of the following 
specifications. (If you don't know how to do that, just go ahead and follow the 
steps listed below; if you get an error, your disc image is wrong.)

  FABT VERSION: http://redump.org/disc/32566/
    Redump name: Ginga Ojousama Densetsu Yuna 2: Eien no Princess
                 (mastering code "HCD5075   HRH750414-2FABT")
    CRC32:       a5eaf3d2
    MD5:         acb64430c3a5204ed5839d2364e31710
    SHA-1:       b6764a3e10dba73bf043bb327d4c4832c31dfa54

  FAAT VERSION: http://redump.org/disc/52124/
    Redump name: Ginga Ojousama Densetsu Yuna 2: Eien no Princess
                 (mastering code "HCD5075   HRH750414-2FAAT")
    CRC32:       7807f68e
    MD5:         cde2ceef0022a25348b9f1888b5d340b
    SHA-1:       74073958cd6560d6206c83786c457a41daa7b0d5

Consult the Redump links for full details.

If your disc image is a match, all you need to do is apply an xdelta patch to 
the BIN or IMG file, then rename it and pair it with the CUE file provided in 
the download.

  1. Extract the "redump_patch" folder from the translation ZIP and open it.
  
  2. Run "DeltaPatcher.exe", which should be present in that folder. This is the 
popular Delta Patcher program for applying xdelta patches. If you're not using 
Windows, you'll need to obtain an alternate patching program for your system, 
such as the command-line "xdelta3" program.
  
  3. Locate the .xdelta patch files in the "redump_patch" folder. Pick the 
.xdelta file whose version label matches your disc: "[v1.0-fabt]" for the FABT 
version, or "[v1.0-faat]" for the FAAT version.
  
  4. Use Delta Patcher (or another xdelta patching tool) to apply the 
appropriate patch to the BIN or IMG file. If you get an error, you'll need to 
try one of the other patching methods below.
  
  5. If your disc image came with a CCD or CUE file, delete it now.
     DO NOT USE THE OLD CCD OR CUE FILE WITH THE PATCHED IMAGE!
     Also get rid of any SUB file if it exists. It's not needed.
     
  6. The "redump_patch" directory should contain a CUE file with a name like 
"Ginga Ojousama Densetsu Yuna 2 EN [v1.0] Redump.cue". Rename your patched disc 
image so it has *exactly* the same name as the CUE, except with a .bin extension 
instead of .cue. Note that at this point, it doesn't matter which version you 
patched – the output disc image will always be the same, regardless of which 
version you started with.
     IMPORTANT: If the file you patched was originally an IMG file, make sure 
that you change the extension to .bin. The CUE will not work if the extension is 
.img.
     
  7. You're done! Make sure you have the CUE and BIN in the same directory, then 
open the CUE in an emulator. Or if you have the hardware, burn the image to a CD 
and play it on your PC-Engine.

  -------------------------------------------------------------
  - B. Directly patch a multi-track Redump-verified BIN image -
  -------------------------------------------------------------
  
  One common distribution of the game found on certain archival sites uses the 
Redump-verified disc images, but splits them up into separate tracks instead of 
combining them into a single file. These are easily recognized by the presence 
of 23 separate BIN files and a single CUE.
  
  Before patching:
  
  - Make sure that your disc's CUE file has a name like "Ginga Ojousama Densetsu 
Yuna 2 - Eien no Princess (Japan) (FABT).cue" (for the FABT version) or "Ginga 
Ojousama Densetsu Yuna 2 - Eien no Princess (Japan) (FAAT).cue" (for the FAAT 
version).
  
  - Make sure that the BIN files are named like this:
      Ginga Ojousama Densetsu Yuna 2 - Eien no Princess (Japan) (FABT) (Track 
01).bin
      Ginga Ojousama Densetsu Yuna 2 - Eien no Princess (Japan) (FABT) (Track 
02).bin
      …
      Ginga Ojousama Densetsu Yuna 2 - Eien no Princess (Japan) (FABT) (Track 
23).bin.
    If patching the FAAT version, the code at the end should of course be 
"(FAAT)" instead of "(FABT)".
  
  To patch:
  
  1. Copy the CUE file and all BIN files into the "splitbin_patch" directory.
  
  2. Drag-and-drop the CUE file onto "binpatch_fabt.bat" (if patching the FABT 
version) or "binpatch_faat.bat" (if patching the FAAT version).
  
  3. If all goes well, this should produce a new, single-track format disc image 
in the same directory. (This works by simply combining all the tracks together 
and then applying the same patch as in method A.)
     
  4. Use the CUE file in the "splitbin_patch" directory to play the game.

  --------------------------------------------------------------
  - C. Automatically patch a BIN or IMG image via binpatch.bat -
  --------------------------------------------------------------

If your disc doesn't match one of the Redump dumps, or you otherwise couldn't 
get method A to work, it may still be possible to patch it. If your disc is in 
BIN+CUE format or IMG+CUE format, and you're using Windows:

  1. Make sure that your BIN/IMG and CUE have the same base name (e.g. 
"yuna2.bin" and "yuna2.cue", or "yuna2.img" and "yuna2.cue"). Note that if you 
rename the BIN file, you will need to open your CUE in a text editor and make 
the same change to any occurrences of the name inside the file.
  
  2. Copy both the BIN/IMG and CUE into the "auto_patch" directory.
  
  3. Drag-and-drop the BIN/IMG file onto "binpatch.bat". Note that unlike with 
the above methods, it doesn't matter if the disc is the FABT or FAAT version; 
there is only one patch for both.
  
  4. If all goes well, this should produce an ISO+WAV+CUE format disc image in 
the same directory.

  ----------------------------------------------------------------
  - D. Automatically patch an ISO+WAV+CUE image via isopatch.bat -
  ----------------------------------------------------------------

If your disc image is already in ISO+WAV+CUE format, you can perform a procedure 
similar to patching via binpatch.bat:
  
  1. Copy all the disc image files to the "auto_patch" directory.
  
  2. Drag-and-drop track 2 of your image onto "isopatch.bat".
  
  3. If all goes well, this should produce an ISO+WAV+CUE format disc image in 
the same directory.

  ---------------------
  - E. Manually patch -
  ---------------------

You can also attempt to apply the xdelta patches in the "auto_patch" directory 
to the ISO of an ISO+WAV+CUE image manually. Pretty much the only reason to do 
this is if you're on Linux and can't or won't use Wine. If that's the case, then 
presumably you're smart enough to handle it yourself, so you're on your own 
here.

                    ****************************************
                    *         II. Running the Game         *
                    ****************************************

** NOTE: This translation was developed and tested on the most recent stable 
release of Mednafen as of this writing, version 1.27.1. Overall, it has the most 
accurate PC-Engine emulation currently in existence…though it still has bugs 
that cause Yuna 2's opening scenes to display incorrectly in the unpatched game. 
The translation modifies it to ensure those issues don't happen, so I'd still 
recommend Mednafen over the competition.

If you're unfamiliar with the PC-Engine, figuring how to run CD-based games can 
be confusing. This section tries to make things clear for new users.

The simple version is this: Originally, NEC/Hudson released the PC-Engine. Then 
they decided they needed a CD add-on and released the CD-ROM² ("CD ROM-ROM") 
system. Then they decided that their original CD add-on wasn't powerful enough, 
so they made the upgraded Super CD-ROM². Most CD-based games, including this 
one, target the Super CD-ROM² and are not compatible with the original, 
unenhanced CD-ROM².

Regular CD-ROM² games require a BIOS in order to run, but Super CD-ROM² games 
require a special, more powerful BIOS. So in order to play this game on an 
emulator, you *must* have a ROM image of the Super CD-ROM² System Card Version 
3.00! Using lower versions will cause the game to give you an error message when 
it starts up. Not having the BIOS means it won't work at all.

You're on your own for obtaining the BIOS image; the No-Intro name is "[BIOS] 
Super CD-ROM System (Japan) (v3.0).pce".

You'll also need to set up your emulator to use this BIOS image, of course. 
Stock versions of Mednafen will look for a file named "syscard3.pce" in the 
"firmware" directory and give an error if it doesn't exist, so move and rename 
your BIOS image accordingly. Other emulators have their own setup procedures, so 
check their documentation for instructions.

Additionally, make sure to run the game in two-button Control Pad mode. The 
PC-Engine was originally released with controllers that had two buttons, but 
later had upgraded controllers released with six buttons. The six-button 
controllers use a different protocol from the two-button controllers, meaning 
that games that weren't specifically designed to support them – including this 
one – will have "glitchy" input unless the controller is put in two-button 
compatibility mode. Emulators will generally default to two-button mode, but if 
you have problems with the game not accepting input or pressing buttons on its 
own, check your emulator's settings.

                    ****************************************
                    *          III. Known Issues           *
                    ****************************************
  
  - While this isn't so much an "issue" as a design choice, the opening and 
ending credits have been left untranslated. Nobody expects the credits sequences 
from an actual anime to get an on-screen translation, and this game is trying as 
hard as it can to be an anime, so let's just give it what it wants and leave 
them as they are, huh? It's frankly not worth the trouble when 99% of players 
are just going to be looking at the song lyrics anyway. If you want to know who 
worked on the game, some very industrious people on MobyGames have the full 
credits already translated for you (albeit with some amusing errors like "Celica 
from the Bicycle Club" – that's "jidousha", not "jitensha"!).
  
  - Related to the above, there are a few minor display errors in the ending 
credits where graphics for the song subtitles conflict with the sprites for the 
credits text, causing bits of the latter to disappear. If I'd actually been 
translating the credits, I'd have moved these lines out of the way to prevent 
the issue…but I wasn't doing that, so I didn't bother. Sorry, but again, who's 
actually reading them anyway?
  
  - On rare occasion, skipping certain voice clips at certain times may cause 
small visual errors. The only instance of this that I know of is in Chapter 4; 
when Yuna is getting up after the ice beam, quickly skipping the voice clip 
before the animation finishes will make Yuna's face pop in before the rest of 
her body reaches the right position. (This can also occur without the patch by 
using debug mode.) Also, fast-forwarding with Button II during scenes that 
automatically advance the dialogue will make the text go out of sync with the 
audio, but don't blame me for that one – it's just how the game engine works.

                    ****************************************
                    *       IV. Additional Features        *
                    ****************************************

In addition to translating the game, this patch makes some small but important 
changes aimed at eliminating needless frustrations and annoying bugs:

  - Voiced lines and sound clips can now be skipped by default. Though the 
original game allows a limited form of this when debug mode is enabled, the 
translation expands on it: any time that the game is waiting for a voice clip or 
sound effect to finish playing, pressing Button I will immediately cut it off 
and move on. In battles, this can also be done by holding Button II. Note that 
this does not skip animations or text printing, so you'll still have to wait for 
those to finish before you can skip the sound.
  
  - Fast-forwarding text has been made less awkward. The original game 
fast-forwards when Button I is held. Since this is also the button to advance to 
the next text box, that sometimes makes it difficult to avoid fast-forwarding 
the text even when you're not trying to. To make things easier, the patch 
changes the controls to work the same way they did in the translation for the 
previous game: holding Button II fast-forwards, while pressing Button I advances 
to the next text box.
  
  - The original game had a nasty bug with the save menu. When prompted to save 
the game, choosing "Save" but then cancelling at the file select menu by 
pressing Button II erroneously left the RCR interrupt disabled. In practical 
terms, this means that if the save prompt was not immediately followed by a 
"widescreen" event, the display window would be completely blacked out, with the 
game only showing text, until one occurred. This has been fixed for the 
translation.
  
  - As mentioned in the previous section, in the unpatched game, Mednafen 
versions at least up through 1.27.1 have problems displaying some parts of the 
visual scenes. Specifically, the very first two scenes of the intro (the Hudson 
logo/distance shot of the fleet, and the following close-up of it) will both be 
completely blacked out, as will at least one later scene. Though this doesn't 
happen on real hardware, the translation modifies the game to prevent the issue 
from occurring as a convenience.

                    ****************************************
                    *      V. Debug and Unused Stuff       *
                    ****************************************

  Having had some years to refine their technique, Will did a much better job of 
organizing this game than the first, resulting in much less unused content on 
the disc (unfortunately for us). But there's still some interesting bits and 
bobs to be found, so I'll list what I know of here.

  +------------+
  | Debug Mode |
  +------------+

  This code was known long before I ever had anything to do with the game, but 
I'll list it here for reference (and because no one seems to have ever bothered 
to fully explain all the effects).

  On the title screen, press Up, Down, Right, Left, Button I, Button II, Up, 
Down, Right, Left, Button I, Button II. Then, press Run (don't hit any other 
buttons before pressing Run or the code will reset). You'll be taken to a "menu" 
to confirm that you're in debug mode; press Button I or II to clear it and 
return to the title screen. Fun fact: this was originally a real menu that gave 
you the option to turn voices on (音声あり) or off (音声なし) and set the game to debug 
mode or release mode (製品モード). For the final game, they removed everything except 
the debug mode option, leaving only the text behind.

  In any case, after returning to the title screen, start the game as normal and 
you'll be taken to a scenario select menu.

  When debug mode is on, the game will not force you to wait for voice clips to 
end before being able to advance to the next text box during the visual novel 
portions. You're also given the option before each battle and dungeon crawler 
segment to skip it. At predetermined points, you'll also be kicked to the 
scenario select menu, where you can either go on to the next scene 
chronologically or select a different one.

  Finally and perhaps most importantly, debug mode enables a bunch of debug 
features during battles:

  - Select + Run:         Empties your current character's health.
  - Select + Right/Left:  Moves the Mood Meter (the little flying Elner that
                          weights offense/defense for/against you) in the
                          corresponding direction.
  - Select + Down:        Restores a small amount of health to your current 
character.
  - Select + Up:          Makes the opponent's cards visible.
                          (Why wasn't this the default!?)
  - Select + Button II:   Sets all the opponent's cards to the same type.
                          Pressing this multiple times will cycle through the
                          different card types.
  - Select + Button I:    Sets all your cards to the same type.
                          Pressing this multiple times will cycle through the
                          different card types.

  +----------------------+
  | Primitive Debug Menu |
  +----------------------+
  
  Somewhat impressively for a game that isn't that complicated gameplay-wise, 
Yuna 2 actually has no less than *three* debug menus with overlapping 
functionality. Aside from the scenario select enabled by the above menu, there 
are two other debug menus that aren't accessible by any normal means.
  
  The more basic of these can be accessed by modifying the game's main data 
track (track 2). After converting to ISO, set the three bytes at offset 0x800 to 
the hexadecimal sequence "00 00 22". This will force the game to boot directly 
into the menu. (Incidentally, do this on the original game, not the translation 
– not only is the menu not translated, it's been overwritten with new resources, 
so trying this will just crash the game.)
  
  This menu is a standalone executable with a very barebones appearance, 
consisting of plain off-white text on a black screen. Proclaiming itself the 
"YUNA-2 DEBUG MODE", it lists some basic system information in the right column 
(System Card version, amount of main memory, and whether or not the Arcade Card 
is present – though this game doesn't actually use the Arcade Card for 
anything). The left column provides options to start any battle, watch any of 
the seven cutscenes, and play Star Bowl or Space Duck.
  
  The last option in the menu, and the only one not covered by the standard 
debug menu, is a somewhat mysterious "CD-DA Counter" (ＣＤ−ＤＡ　カウンター). When 
selected, the game will display a black screen and start playing CD audio track 
3, the audio for the first part of the opening cutscene. On this screen, each 
press of Button I will print the number of frames that have elapsed since the 
audio started. Pressing Run will exit, though the audio will continue playing.

  +-----------+
  | Test Menu |
  +-----------+
  
  The third debug menu is an in-game menu, like the standard one. It might have 
been intended to be accessed through the standard debug menu, but this isn't 
possible in the finished game.
  
  To replace the normal scenario select menu with this menu, go to offset 
0x173D02A in the ISO for track 2 and change the byte there from "5A" to "EC". 
(This will work in the translation too.) Then start the game, enter the debug 
code at the title screen as described above, confirm the debug mode prompt, and 
after being returned to the title screen, choose "Start". You'll be taken to a 
menu with eight options:
  
  - Maze Test (迷路テスト) – Allows you to choose one of two test layouts for the 
dungeon crawler segments and play it. Maze 1 uses the lunar ruins tileset, while 
Maze 2 uses the ruined battleship tileset. Both dungeons are completely empty; 
all you can do is wander around. The only way out is to reset.
  
  - Demo Test (デモテスト) – Allows you to view any of the seven visual scenes.
  
  - Battle Test First Half (バトルテスト前半) – Allows you to start any of the first 6 
battles.
  
  - Battle Test Second Half (バトルテスト後半) – Allows you to start any of the last 6 
battles.
  
  - Bonus (おまけ) – Automatically flashes through an endless loop of the exact 
slideshow featured on the bonus CD that was packed in with the 1995 rerelease of 
the original Galaxy Fraulein Yuna. Yeah, that's right, it's all in this game. 
But wait, there's more…
  
  - PSG Test (ＰＳＧテスト) – A series of dialogue boxes that play back various PSG 
sound effects while displaying their corresponding filenames. Not terribly 
interesting.
  
  - HuVIDEO (ＨＵＶＩＤＥＯ) – Plays back an FMV of the anime footage for the Yuna 1 
commercial…you know, the footage they stuck on a CD and used as an incentive to 
get people to buy the Yuna 1 rerelease? Yep, it's not just the slideshow – 100% 
of the content from the bonus CD is contained in Yuna 2 itself, just 
inaccessible. Real thoughtful, huh? The video is followed by an interactive 
version of the slideshow accessible above, though for some reason, many of the 
pictures have display errors where large chunks show up as black. Clicking 
through the whole thing will loop back to the video.

  +---------------+
  | Miscellaneous |
  +---------------+
  
  - During cutscene transitions, the game loads sprites for an animation of a 
ticking clock to the very end of video memory (not in the translation, though – 
I needed the space for other things). Presumably, this was going to be displayed 
when the game was loading data from the CD, but no such thing happens in the 
finished product.
  
  - The special "checkerboard" eyecatches in Chapter 3 that show tiled 
backgrounds of Yuna and Yuri/Polylina also load in an alternate version of the 
Yuna tile that shows her smiling, but never use it. Presumably, the idea was to 
have her smile after the other character is revealed.

                    ****************************************
                    *        VI. Authors' Comments         *
                    ****************************************
  
  ------------
  -- Supper --
  ------------
  
  Well, this happened. I've got regrets about the way I went about it, but it 
happened, and however it did, I'm glad the whole thing came together in the end.
  
  After the release of the Yuna 1 translation a few months back, I was busy with 
other things for a while. But one day, I happened to stumble across that game's 
kiosk demo, and had a fun afternoon modifying it to break out of the demo area 
so I could play the whole thing. (Guess I should probably release that as a 
patch sometime, huh?) That got me going on Yuna again, and I decided to get 
started on the translation for the sequel right away.
  
  That part's all fine and dandy. The problem is that I got extremely carried 
away with things and, after dumping the script, fully implementing script 
insertion, porting over the subtitle system from the first game, etc. etc., I 
proceeded to just start translating the game on my own. Which might have been 
okay except that I never told Mafoo about any of this, and didn't do so until 
I'd finished the entire script. At which point, very big OOPS! – it turned out 
he'd been working on translating it himself and I'd basically rendered all of 
that useless.
  
  So while it wasn't my intention to do anything underhanded, I owe Mafoo a lot 
of apologies for not being forward enough about things, and a lot of gratitude 
for the fact that he was still willing to help out with the project after that 
fiasco. Having his partial translation to compare against helped me fix no small 
number of errors I'd made in mine, and brought the whole thing to a much higher 
level than it would have been otherwise. It's also Mafoo who provided the lyrics 
to the insert song "Gomen Ne", which I didn't have and originally thought I was 
just going to have to leave blank. So while neither of the phrases suffices for 
conveying the depth of my feelings, they're all I can say: I'm sorry, and thank 
you.
  
  So, with that mess out of the way, let's talk about the actual game!
  
  From a technical perspective, Yuna 2 was both easier and harder to work with 
than Yuna 1. It eliminates the use of multiple executables with redundant code, 
i.e. there's now a single unified cutscene player instead of having 50 cutscenes 
that are each their own self-contained program, which greatly simplifies the 
hacking process. But the game also uses CD audio tracks for cutscenes instead of 
ADPCM clips, which among other things meant the subtitle code had to be modified 
to make it possible to switch subtitles in the middle of loading transitions. 
Though the subtitles are visually identical to the previous game, the actual 
integration into the game engine is very different, and it took some doing to 
get it all to work right.
  
  The developers also took note of the issue from Yuna 1 where printing text 
would cause animations to lag or stall entirely, and took measures to prevent it 
with Yuna 2. Unfortunately, part of their strategy was to cap the maximum 
printing speed at one character per frame, which caused problems when I needed 
to double it to keep it from being too slow with the increased number of 
characters in the translation. In the end, I had to partially redo the printing 
system to avoid needless VRAM readbacks, which were badly throttling 
performance, just to allow this to happen. Felt pretty good, though.
  
  On the translation side of things, this game was actually a lot easier than 
Yuna 1. The script is considerably shorter due in part to the near-total absence 
of narration – it's something like two-thirds to three-fourths the size, I think 
– and it has far fewer voice-only scenes, which are the most painful part to 
deal with. The script itself is mostly straightforward comedy material that 
isn't too taxing even for me…though there were some curveballs in there, like 
the fancy-dancy space battle full of military terminology at the start, or Yuri 
suddenly spouting off some weird prophecy written in classical Japanese. Fun. 
Big thanks to TheMajinZenki for checking the script over for me and catching 
some things I never would have (fun fact: I had no idea what "Armani" was).
  
  Overall, it wasn't an easy project by any stretch of the imagination, but with 
a reasonably solid foundation from the previous game to build off of for both 
the hacking and the translation, I was able to hammer this one out pretty 
quickly.
  
  One more time, my apologies and my eternal thanks to Mafoo for enduring my 
idiocy. I don't know if I'll be doing more Yuna in the future or not, but I've 
really enjoyed working on the series so far. Hope you'll all get a kick out of 
this one.
  
  P.S. Don't bother trying to beat Star Bowl or Space Duck. There are no win 
conditions. Yeah, I really don't know what the point was supposed to be.
  
  --------------
  -- Mafoo343 --
  --------------
  
  Well, this all came together a lot sooner than I expected. Originally I was 
planning to handle the translation for Yuna 2 myself, but it looks like Supper 
got so pumped up for the sequel that before he knew it, he ended up completing 
work for the whole game at breakneck speed. Serious props to him, I wish I could 
work that fast. Even though this didn’t go down the way I expected it, I’m glad 
I still got the chance to help out here and there at least a little bit. I had 
fun working on this and I hope you enjoy :)

                    ****************************************
                    *         VII. Special Thanks          *
                    ****************************************

Thanks to the members of LIPEMCO! Translations (other than that selfish jerk 
Supper) for their support throughout development and assistance in testing the 
translation.

Thanks to Yerna…I mean, Elner…I mean, elmer for providing resources and 
documentation for the PC-Engine that were very extensively referenced during the 
production of this patch, and for the special bugfixed Windows binary of bchunk 
that's used in the patching process.

Additional thanks goes to SadNES cITy Translations for the Delta Patcher 
program, which is bundled with this patch as a convenience.

                    ****************************************
                    *        VIII. Version History         *
                    ****************************************

v1.0 (18 Dec 2021): Initial release.
