Traducción Gunhed para PC Engine
Versión actual: 1.0 (29/10/18)
Autor: RMGlitch
----------------------------------
Descripción:
Juego de disparos basado en la película del mismo nombre que fue lanzado en occidente bajo el nombre
de Blazing Lazers.

----------------------------------
Detalles de la traducción:
Este juego ya cuenta con una traducción, pero en ella se borra toda referencia a la película en la que
se basa. Por fortuna, la versión japonesa está en inglés y los textos son exactamente los mismos que en
la versión USA. Se tradujeron los pocos textos que posee mediante un port directo de la versión
traducida por Wave, que fue autorizado por la misma persona. Sobra decir que el grueso de esta
traducción es gracias a su anterior trabajo, por lo que el crédito es suyo. Se pudo agregar tildes a
algunas letras, pero no se ha podido encontrar los gráficos de GAME OVER y AREA que salen al jugar, así
como los tiles de las letras de los créditos. Si se encontraran, se lanzará una actualización.

----------------------------------
Instrucciones
Aplicar el parche con algún programa con capacidad de inyectar archivos IPS
Debe hacerse sobre el archivo:  Gunhed (Japan).pce
No debe llevar header y debe tener el CRC 32:   A17D4D7E

----------------------------------
Adicional
Si encontrais algún error de tipeo o similar, podeis escribir a:
aznable345@gmail.com
No se responderá cualquier pregunta relacionada a ROMs o similares.