Lady Sword
PC Engine Hu Card
Publisher: Games Express
Year: 1992
Region: JP

English Language Translation Patch Readme

Staff
Hacking: Esperknight, Tomaitheous
Translation: Filler, Grant Laughlin
Additional Translation: Eien ni Hen
Editing: Paul Acevedo
Playtesting: Gabriel Jones, Enigmaopoeia
Initial Work: Filler

This project has been a long time in the making, largely due to my own priorities. It has generated interest from various parties over the years and even raised a few eyebrows as to why I'd even have any interest in such a game anyway. Developed by Hacker International (http://en.wikipedia.org/wiki/Hacker_International) "known for its play-for-porn approach to gaming" was responsible for a number of unlicensed titles for the NES and PCE systems. From many perspectives Hacker International is an interesting bit of history from the 8-bit gaming era. I'm happy to make available an English language patch to a game that was not only not released in the US but was even produced outside the normal licensing channels in it's country of origin.

For anyone who enjoys a good dungeon crawl and has wondered what the heck dismembered floating heads and girly pics have to do with it, I hope that you enjoy trying out the English language patch for Lady Sword.

Note: This game does feature some nudity and is intended for adult audiences. Please abide by the laws in your country regarding material of this type.

Patch Info:

This patch can be applied with any ips patcher to a rom of Lady Sword for the PCE. The file lady_sword_en.ips applies the English language patch, ls_cheat.ips is a it says a cheat that gives you infinite life and 255 strength because well, you may want it. :) The game is quite hard but please do enjoy giving it a try and enjoy the English language version we worked hard to bring to you.

History

Filler: I originally started work on this game in October of 2003 when I began trying to dump a script. However, it wasn't until early 2005 that I went back and managed to get something from it to start translating. Tomaitheous offered to help with the hacking in late 2006 and work began on the project. He did a lot of work figuring out the way fonts are handled and was able to insert a nice font. The plan then was to get a full polished scrip Tomaitheous could figure out how to compress it efficiently. Around this time he also was able to provide me with an invincibility patch.

By late 2006 early 2007 Grant Laughlin stepped up to help me with the script translation. I was able to hand the half finished script to him and he did a great job finishing it off. Enter an inexplicable 2 year black hole... I made the mistake of letting the project rest on me performing a playthrough of the game to test the script. Basically I let this project languish due to interest in other projects.

Tomaitheous and I turned our attention to Bubblegum Crash for the remainder of 2007. It was around 2008-2009 when things started heating up with Welcome to Pia Carrot and all my playtesting efforts went to that. By the time I took an interest in Lady Sword again in mid 2009 Tomaitheous was still ready to assist but I was still struggling to play through the game. At this time Slayers was starting to heat up and I was again busy with a project that was dearer to my heart.

Around this time, once Slayers was done, I offered to help Esperknight with Urusei Yatsura - Stay with You on the PCECD. Meanwhile Tomaitheous had been working on Dead of the Brain with David Shadoff for a couple of years. Esperknight expressed some interest in Lady Sword and had apparently worked with Tomaitheous and David on Dead of the Brain a bit and offered to talk to Tomaitheous.

In the mean time Hoshi wo Sagashite (Story of Mio) was released thanks to Kingofcrusher and I began working with him on Madou Monogatari, and with Dynamic-Designs on Aretha II. Around the beginning of 2010 Esperknight began looking at Lady Sword and managed to insert the script! With this as motivation we continued working on this and managed to start up some beta testing around mid-year. I finished off the script for Madou Monogatari which was released in September and started in on Aretha II again. I finished Aretha II in November 2010 and finally turned my attention back to editing the Lady Sword script with feedback from the beta testing. A version of Lady Sword was released on Nov. 28th 2010.

Translation Notes:

This script will probably remain one of my  most interesting discoveries due to a diary left in it by the original programmer. Here is a translation of that diary:

"Ah, I'm tired. I don't have much energy these days. Perhaps it's my age... The head-women and the girly pics were appended later, they're just kinda thrown in. I wanted to put in more monsters rather than broads. Without the dames, I probably could have put in about 100 new monsters- but I guess coming up with that many monsters is tough. New magic would have been nice too. But spells eat a lot of space, so we couldn't do it. I mean we planned on 2 megs and now we're at 8. Huh. Some development plan.

July, 1990 Without any planning, at the time the 3D work was being done there was still 2 megs of magic that was
not being considered. We had a different title then, too. It was kind of a fairy-tale setting then. 

August, 1990 The designer disappeared. "A man that's toyed with by a fickle lady." It's kind of funny, but I don't think I want to play that game. 

September, 1990 It's starting to take shape. The graphics got done by an amateur, and I feel like it's going to look like an ancient NES game. I don't know much about how the system will work from here out...Doing this kind of judgment work...

July 1991 Just like I thought, those were some bad pictures. Added a designer. Now at 4 megs. 

Aug. 1991 We've just worked out how the ladies are being worked in, and the basic story. Changed the title, too.

Nov. 1991 The graphics (only) are roughly finished. We were at 4 megs, but we're going to keep going without erasing. Lost our designer. 

Feb. 1992 Got a new designer. Put in the head-ladies and the girly pics. Changed the title to LADYSW0RD. Somehow we're at 8 megs. Put in some story for the girls. Who likes that? Yep, it's the 'lady.' That, and 'beautiful' is popping up randomly. I guess that's how it goes. You can kinda grasp the story.
 
I was drunk the other day, and I spilled whiskey on my keyboard. The next day I moved it, and it came dribbling out. Gah! Crap! I took it apart and cleaned  it, but it was already too late. Waahh. Must be karma. I should
be glad the CPU isn't busted. Well, anyway, see ya."

Thank You:

Filler: I'd like to thank Tomaitheous for all his early hard work on this game. It was through no fault of his that the game remained unreleased for so long. A big thank you to Esperknight for renewing my interest in this project and for his fantastic work on this challenging game. Can't wait to work on many more games together.

Thanks to Grant Laughlin for his work on the script. He originally approached me to see if I needed help with Welcome to Pia Carrot but instead ended up translating about half of the Lady Sword script making him a full co-translator. I hope to work with Grant more in the future.

Thanks to Gabriel Jones, creator of the awesome Lady Sword: Strangest Game Ever page (http://www.angelfire.com/ri/returns/sword.html). Gabriel was great to do a full playthrough of the English language patch of the game and share his findings with us. In fact I think this was the first successful close beta that any of my personal projects have had, all thanks to the efforts of testers like Gabriel.

Thanks to Paul Acevedo, author of the Lady Sword FAQ on GameFAQs for his assistance editing the script. Paul fixed many capitalization, spelling, and punctuation errors, as well as catching some consistency and naming issues. Thanks to Enigmaopoeia as well for a lot of naming advice that was implemented in the release script.

Thanks to Eien ni Hen as always for assisting me on RHDN's forum with checking the somewhat odd ending text. Her version of the ending appears in the release script.

Thanks to anyone I've missed!