Impossamole (PC Engine)
Traducción al Español v1.0 (05/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Impossamole (U).pce
MD5: d212a1bbb8d329d05910dc407ca60173
SHA1: bda974dfebe28c125f081363da3bbe96777404d7
CRC32: e2470f5f
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --