Primer proyecto y a la vez la primera traducción de este videojuego, debo aclarar algunas cositas.
Hay un detalle que no me gusta pero no puedo corregirlo, es algunas letras que tienen mas espacio que
el que tiene la barra de nombre en los partidos. lo que si les dejo como se llama cada uno acá abajo:

Tamagawa: Danpei, Chinnen, hiura, mikasa, tsuyoshi, hayami, yuuichi, yuuji, ozaki, tsutomu.
Saint arrows (en el juego st.arrows): Taiga, igarashi, mitamura, kobayakawa, higashiyama, kusunoki.
Tosa attackers: Ryouta, misaki, arakida, harima, kotouge, katsuragi, shijima.
Black Armors: Arashi, takayama, usami, fuwa, hattori, yuuki, ogata.
Sandstorms: mitsurugi, jiroumaru, sakyou, taroumaru, kurobe, oogaki, iwaki.
Fireboys: kiryuu, houjou, shiouji, ibusuki, kokonoe, akechi, takayanagi.
blizzards: himuro, kumagaya, yagashira, kazama, asahina, kogure, kitao.
SkyFighters: Asuka, wachizume, chouno, amagi, tenma, kyougoku, akaboshi.

Espero que disfruten de la traducción, saludos.
 
                                      Rockymitsu 2024