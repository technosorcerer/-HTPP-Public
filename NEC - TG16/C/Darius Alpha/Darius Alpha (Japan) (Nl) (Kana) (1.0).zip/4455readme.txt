Language patch (text only)
Language: Dutch
--------------------------

Vertaling naar het Nederlands
Versie: 1.0
Datum: 11-04-2019
(c) 2019 Kana Translations

--------------------------
Opmerkingen bij deze patch
--------------------------
Deze vertaling en hack is geheel oorspronkelijk.
N.B. De Europese cartridge (dump) bevat nog enkele Japanse tekststrings,
deze zijn ongewijzigd gebleven.

--------------------------
Patch-instructies
--------------------------
De patch heeft de IPS-indeling, en kan worden gebruikt met LunarIPS of Floating IPS.

--------------------------
Spelinformatie
--------------------------
Gebruikt oorspronkelijk bronbestand:

Titel: Darius Alpha (Japan).pce
Platform: PC Engine / NEC TurboGrafx-16


MD5:   C87135A6AF3344C9316FE06FCCBCFD97
SHA1:  F59C538FA632F687C356AF70659FB07B37933F78
CRC32: B0BA689F
Bytes: 393216

--------------------------
Dankwoord/Credits
--------------------------
Kana - Nederlandse vertaling en hack

--------------------------
Very special thanks
--------------------------
Wave - voor het briljante programma Hextractor, website:
traduccioneswave.blogspot.com

-- EINDE --