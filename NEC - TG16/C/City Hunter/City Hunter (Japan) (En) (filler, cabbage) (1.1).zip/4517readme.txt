
--------------------
City Hunter (HuCARD)
====================
English Translation Patch
Version 1.1


---------------
About the Patch
===============

The game is fully playable in English.
This patch has been made available for free.
Commercial use is strictly forbidden--including but not limited to "repros."


------------------
Applying the Patch
==================

Lunar IPS is an easy-to-use Windows tool to apply IPS patches to ROMs
available here: https://fusoya.eludevisibility.org/lips/

Two versions of the patch are included. One is for raw ROM dumps (windows
shows a file size of 384kb), and the other is for ones that have an added 
header (windows shows 385kb). If you're confused, just make two copies of 
your ROM and patch each one with one patch and use whichever one works.


--------------
Filler's Notes
==============

This is the forth PC Engine project I've worked on, but it's the first project 
where I've inserted data into the ROM in order to find out what kanji are 
included in the text encoding. This was an adventure for me and I documented 
it in a video here: https://youtu.be/MPKfhdwWupM

Thanks to the double byte text encoding and the varying single bytes that show 
up at the end of lines (may be pointers or something, I'm not sure) I had to 
be careful about the dumped text being thrown off by a single line ending byte 
being followed by a 00, or 01 that was part of a preceding character being 
decoded as part of the text encoding. It wasn't that hard to fix but it threw 
me off at first.

Also come to find out, the kanji for Ryo's name (獠) isn't included in the JIS 
kanji, so I had to make sure to use a Unicode set for the script dump to 
properly include it.

Translating the script was pretty straightforward. I made the script dump in 
late November of 2018 and had finished the translation by the end of the year. 
I had some trouble having lost/misplaced some of my translated text and had to 
re-translate a days worth of work, but thankfully the script is small and it 
wasn't a big deal.

I THINK cabbage reached out to me about working on inserting the script, but 
he'll have to confirm that. At any rate, we ended up connecting on Twitter 
over my posts about the work I was doing and hacking work progressed on and 
off with testing and script edits here and there until early May 2019.

Big thanks to cabbage for all his work on this one including script editing. 
My original draft sounded rather stilted in retrospect, so the edit for 
length really freshened it up. Also thanks to Cccmar for testing, and any 
others who play-tested the beta release and provided feedback. I'm a big 
anime fan and I really enjoy being able to work on unofficial translation 
patches for anime styled games. The PCE is a really cool system that doesn't 
get enough love from gamers or fan translators so this is a project I'm 
especially glad to see completed for others to enjoy.


---------------
cabbage's notes
===============

City Hunter is one of those games that I would keep coming back to and trying 
to hack. I never really managed to get anywhere, but each time I came back, I 
would understand a bit more or make a bit more progress.

Filler recently posted on twitter that he had dumped the script, so I 
mentioned that I had already done a bit of hacking on that game and would be 
happy to contribute. Cut to a little while later, and we have a complete patch.

There was a fair bit of work on the hacking side. 
A new font was inserted (carefully). The 2-byte encoding was hacked to 1-byte. 
The 16x16 text was hacked to 8x16. Menu and credits were completely different 
and harder to figure out. That probably took longer than the dilogue. Maybe 
not; maybe it just felt longer because I was spending so much time on 
something so small.

Thanks to Filler for inspiring me to take a more serious look at this game. 
Also thanks to Necromancer for very early testing and feedback.

I hope you enjoy playing City Hunter in English. 
Please check out my website. 
Feel free to buy me a beer sometime. 
And remember, feedback is always appreciated.

 -- cabbage

http://cabbage.cx


------------------
See you next time?
==================
