Language patch (text only)
Language: Dutch
--------------------------

Vertaling naar het Nederlands
Versie: 1.0
Datum: 11-04-2019
(c) 2019 Kana Translations

--------------------------
Opmerkingen bij deze patch
--------------------------
Deze vertaling en hack is geheel oorspronkelijk.
N.B. De Europese cartridge (dump) bevat nog enkele Japanse tekststrings,
deze zijn ongewijzigd gebleven.

--------------------------
Patch-instructies
--------------------------
De patch heeft de IPS-indeling, en kan worden gebruikt met LunarIPS of Floating IPS.

--------------------------
Spelinformatie
--------------------------
Gebruikt oorspronkelijk bronbestand:

Titel: Cyber Core (Japan).pce (No-Intro Romset)
Platform: PC Engine / Turbografx-16

MD5:   C16B1AEE2D7023B410DD5E513C4AEC0B
SHA1:  D0765259B06B12DFDA66D8B861954EBC62022440
CRC32: 4CFB6E3E
Bytes: 393216

--------------------------
Dankwoord/Credits
--------------------------
Kana - Nederlandse vertaling en hack

--------------------------
Very special thanks
--------------------------
Wave - voor het briljante programma Hextractor, website:
traduccioneswave.blogspot.com

-- EINDE --