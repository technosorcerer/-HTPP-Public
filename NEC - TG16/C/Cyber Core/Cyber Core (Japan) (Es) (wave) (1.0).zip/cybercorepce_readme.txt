Cyber Core (PC Engine)
Traducci�n al Espa�ol v1.0 (25/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Cyber Core (U).pce
MD5: c16b1aee2d7023b410dd5e513c4aec0b
SHA1: d0765259b06b12dfda66d8b861954ebc62022440
CRC32: 4cfb6e3e
393.216 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --