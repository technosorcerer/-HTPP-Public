=========================================================
=======================Bravoman==========================
========================V 1.00===========================
Genre: Action

Source language: Japanese

Platform: PC Engine HuCard

Patch language: English

Author: Pennywise

E-mail: antoniusblocko@protonmail.com
		
http://yojimbo.eludevisibility.org/
 
======================================================
About Bravoman
======================================================
Project History:

This is another project I started when Mesen added PCE
support. The game caught my eye when I mistakenly thought
the character of Dr. Bakuda aka Dr. Bomb made a cameo in
Megami Tensei II. Turns out the name was actually Bakuta.
Though I wouldn't be surprised if it was a sly reference.

Anyhow, not being familiar with the game I checked out
the US release and immediately saw it was of the old-
school Engrish kind that falls into the so bad it's
good category. Though I thought maybe it would warrant
a new translation from the Japanese source.

So eventually I started hacking it and was not an easy
feat due to sprite limits in addition to dealing with
compression. It wasn't until late in the project's life
that this weird tangent of a project that the translation
became totally worthwhile. The game has tons of hidden
easter egg text that can only be accessed by hitting random
areas of stage or ducking in some bizarre area. All of
this content was removed from the US release for what
I'm assuming was space reasons. The messages were
particularly difficult to find and I even resorted
to reverse engineering part of the game. In the end
I found all the messages in the game. Aside from the
underwater stages, most stages have at least 1
hidden message.

The game also has a fully functional debug mode that
was disabled, but I reenabled it. Press 1 on the title
screen to access it.

Anyhow, translating this game was a lot of fun as it
was quite silly and goofy. No Engrish was necessary
to carry the humor across.

======================================================
Patching Instructions
======================================================
Apply the patch to the Japanese ROM:

Chouzetsu Rinjin - Bravoman (Japan).pce

We would be highly grateful, if you find some time to 
contact us with proposals or corrections. Information
on found bugs or corrections would be highly 
appreciated.

P.S.

Support the game industry by buying used games!

Even if the money doesn't go to the developers
directly, as the games become rare and harder
to find, the price goes up, and people become
more inclined to buy new releases "while they can!"

======================================================

Credits go to:

Pennywise - hacking, text editing

Ryusui - spot translations, misc graphic design

MatatabiMitsu - partial translation

TheMajinZenki - credits translation, song lyrics translation

aishsha - credits translation

Graphicus - misc graphic design

cccmar - testing

All those who contributed into this process.

======================================================


Compiled by Pennywise. January 2024