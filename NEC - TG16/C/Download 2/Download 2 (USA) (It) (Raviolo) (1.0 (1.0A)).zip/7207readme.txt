Download II Italian Dub Patch (1.0) (22/01/24)
Made by Raviolo - with love -

***ATTENZIONE! Vi ricordo che potete applicare la patch solo sul
back-up di una copia di gioco che avete acquistato legalmente!***

***WARNING! This patch may only be applied to a back-up copy of
a legally obtained copy of the game!***

-----------------------
HOW TO APPLY THE PATCH
-----------------------
1)Insert your Download 2 CD in the computer.
2)Open TurboRip, type the "auto" command and select the CD drive that contains the disc. The program 
  will automatically create a folder named "Download II (J), which contains all the game data. 
3)Open "Download II (U)" and patch the file "02 Download II (J).iso" with the "DL2-ITA1.0.xdelta" patch.
4)Have fun!

**For more info, check the readme file (leggimi) inside the patch folder**

-----------------------
COME APPLICARE LA PATCH
-----------------------
1)Inserite la vostra copia giapponese di Download II nel lettore CD, oppure montate una copia virtuale utilizzando 
  il programma che preferite (Daemon/Nero ecc.) 
2)Aprite TurboRip, inserite il comando "auto" e selezionate il CD drive in cui si trova il gioco. Il programma creerà 
  la cartella "Download II (J)", contenente tutti i file di gioco (se il programma vi dice che alcuni file sono 
  corrotti e/o non possono essere estratti, ignorateli).
3)Aprite la cartella "Download II (J)" e applicate la patch "DL2-ITA1.0.xdelta" al file "02 Download II (J).iso",
4)Divertitevi!