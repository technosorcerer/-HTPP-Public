Chase HQ - Noise Fix
--------------------------
This patch removes the excess noise heard over the title screen, pause, and generally quiet portions of the game.
This is useful for real hardware of any revision, as well as certain FPGA implementations.

Installation
----------------
Patch this over the nointro US version. I have not tested it with other regions, and it definitely won't work with a headered ROM.

About
----------
On his page about the TG16 noise issue, Artemio had mentioned that this game was another where he found excessive noise, and had tried some patching, found success for the pause screen, but not for the title screen, etc.
As thanks for documenting the issue, I went in and found the exact places for the pause event (keeping the changes simple there, ideally), and discovered what was happening in the audio system to always render noise in the way it was.
It turns out it was constantly enabling channels on every frame as a separate routine (and also on event change), which was different from when it was actually opening and generating the sound.
This patch just uses those same routines to ensure channels are properly closed, when not doing anything

Personally, it makes this version much more playable. I might still prefer the GG/SMS version, but the voice samples and colors in this version give it a step up, especially without the added noise.