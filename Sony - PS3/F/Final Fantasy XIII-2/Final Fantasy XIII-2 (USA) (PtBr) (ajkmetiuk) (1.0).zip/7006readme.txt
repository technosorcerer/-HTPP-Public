Tradu��o de Final Fantasy XIII-2 para PS3

Sobre a tradu��o:
- Este � um port da tradu��o de PC para o PS3. 
- A tradu��o funciona tanto no jogo base (vers�o 1.0) como no update 1.06.
- A tradu��o funciona com todas DLCs lan�adas.
- O port foi feito em cima do jogo em m�dia americana [BLUS30776].
- Reutilizei meu save zerado de 2014, ent�o eu n�o revisei o jogo inteiro por completo, mas uns 70% sim, afinal, eu realmente s� tinha zerado, o jogo estava com 35h somente de gameplay.
Revisado boa parte dos fragmentos, feito os finais das dlcs, feito os 8 finais alternativos + o final da hist�ria principal + o final secreto e o que entrou nessa gameplay, foi corrigido.
(Infelizmente, para ter acesso ao final secreto tem que praticamente platinar o jogo, a gameplay de 35h foi para 80h, mas valeu a pena!)
- Foram corrigidos v�rios erros ortogr�ficos, textos que excediam o tamanho limite e cortavam, textos que simplesmente estavam deletados do script (acredito que deletaram sem querer na hora de traduzir),
v�rias palavras sem acentos, textos que ficaram em ingl�s (inclusive nas dlcs e o quiz inteiro e os fragmentos relacionados ao quiz da Academia 4XX), textos exclusivos da vers�o console
e entre outras coisas que nem lembro mais.
- Tudo isso j� foi informado e passado para o autor da tradu��o do PC (Rhadamants) ent�o pode ser que algum dia saia uma vers�o atualizada com essas coisas inclusas tamb�m.


Progresso: 100%

Vers�o 1.0
-Portada a tradu��o para o PS3. Inclus�o do patch 1.06 + as DLCs + revis�o + corre��es ortogr�ficas + corre��es de textos cortados e deletados + tradu��o de textos em ingl�s e conte�do extra do console.

CR�DITOS:

Tradu��o para PC: TriboGamer

Administrador: Rhadamants
Tradutores: Rhadamants, Lantier, Kamisama, LTMOTA, leo_14_jti,
Kaique_TR, Sandriner, MattKaz, Mathew2, Rafflues, luanbra,
kyryto, Shiragani, Vigaku, maxpayne23, BELERA, lobozero, Sufiaum,
caduzito12, ytaloxd524 e kimihir0
Revisores: Rhadamants, Lantier, Kamisama e LTMOTA
Testes In-game: Rhadamants
Instalador: H3rdell

Adapta��o para PS3, revis�o e tradu��o do conte�do extra do console: ajkmetiuk
Ferramentas desenvolvidas por FluffyQuack (v1.4)


Como utilizar o patch:

O pacote vem com 3 patchs, um para ser aplicado no jogo base e um para aplicar no update 1.06 e outro nas DLCs.

Tradu��o no jogo base (1.0):

- Tenha em m�os o dump do jogo americano de m�dia f�sica [BLUS30776].
- Copie a pasta PS3_GAME para dentro da pasta FF13-2_PS3_JOGO_BASE.
- Execute o arquivo TRADUZIR_JOGO_BASE.bat e espere terminar o processo.
- Copie a pasta PS3_GAME de volta para o console e � s� jogar.
- Caso n�o queira que o jogo atualize, � s� retirar da internet ou cancelar o update quando aparecer o prompt.

Tradu��o no update 1.06 (Opcional, use caso tenha as DLCs que complementam a hist�ria):

- Instale o update pela PSN ou, ao abrir o jogo, o mesmo j� ir� pedir para atualizar automaticamente.
- Localize o update em seu PS3, geralmente ele � instalado em dev_hdd0/game/BLUS30776/USRDIR
- Copie os arquivos filelist_patch_u.ps3.bin e white_patch_u.ps3.bin para a pasta FF13-2_PS3_PATCH
- Execute o arquivo TRADUZIR_PATCH.bat e espere terminar o processo.
- Copie os dois arquivos de volta para o console e � s� jogar.

Tradu��o nas DLCs (Opcional, caso n�o tenha a DLC, � s� ignorar esse passo):
- Tenha as DLCs instaladas. Se n�o tiver todas, n�o tem problema, o que possuir ser� traduzido. 
- Localize a DLC em seu PS3, geralmente ela � instalada em dev_hdd0/game/BLUS30776/USRDIR/
- As IDs das DLCs s�o definidas como 0000001,0000002,0000003, etc, at� a 0000036.
- Copie todas as pastas que tiver, de 0000001 at� 0000036 para a pasta FF13-2_PS3_DLC
- Execute o arquivo TRADUZIR_DLC.bat e espere terminar o processo.
- Copie todas as pastas de volta para o console e � s� jogar.


Agradecimentos Especiais: Ao Rhadamants que me autorizou fazer o port para o PS3 e a toda equipe de tradu��o da vers�o de PC, a tradu��o j� � meio antiga, de 2016,
mas acho que o PS3 era o �nico que n�o havia port ainda.

*Esta adapta��o � disponibilizada gratuitamente, sem fins lucrativos!
Se voc� comprou ela, voc� foi enganado!

NOTA: N�o foi testado o jogo inteiro no PS3, utilizei um save antigo meu j� zerado, ent�o, caso tenha algum bug ou problema, � s� reportar.
NOTA 2: S� foi testado no PS3 e com o jogo americano de m�dia f�sica, n�o garanto funcionamento em outras vers�es com ID diferentes ou em emuladores.

Bom jogo!