Tradução de Final Fantasy XIII para PS3

Sobre a tradução:
- Este é um port da tradução de PC para o PS3.
- O port foi feito em cima do jogo em mídia asiática [BCAS25005] mas foi adaptado para ser compatível com a versão americana [BLUS30416], européia [BLES-00783] e japonesa [BLJM67005].


Progresso: 100%

Versão 1.0

Feito o port, traduzido alguns gráficos ainda em inglês, reedições gráficas dos botões do PS3, corrigido erros ortográficos e tradução dos extras do console.
Testado um pouco do ínicio do jogo e usado meu save antigo somente para testar algumas partes para ver se funciona, não foi jogado totalmente com a tradução.

CRÉDITOS:

Tradução para PC: TriboGamer

Administrador: Rhadamants
Tradutores: Rhadamants, Sandriner, Ribacm, Kamisama, doughalen, leo_14_jti, Nabukolvisk, Frerol e MattKaz
Revisores: Rhadamants, Kamisama, Ribacm, Lantier e Mathew2
Testes In-game: Rhadamants
Instalador: H3rdell

Adaptação para PS3, revisão, reedição gráfica e tradução do conteúdo extra do console: ajkmetiuk
Ferramentas desenvolvidas por FluffyQuack (v1.4)


Como utilizar o patch:

O pacote vem com 2 patchs, um para ser aplicado no jogo base e um para aplicar no update 1.01 (Exclusivo da versão japonesa).

Tradução no jogo base (1.0):

- Tenha em mãos o dump do jogo.
- Copie a pasta PS3_GAME para dentro da pasta FF13_PS3 (a pasta movie não é necessária).
- Execute o arquivo TRADUZIR_JOGO.bat e espere terminar o processo.
- Copie a pasta PS3_GAME de volta para o console e é só jogar.

Tradução no update 1.01 (Exclusivo da versão japonesa):

- Instale o update pela PSN ou, ao abrir o jogo, o mesmo já irá pedir para atualizar automaticamente.
- Localize o update em seu PS3, geralmente ele é instalado em dev_hdd0/game/BLJM67005/
- Copie a pasta USRDIR para a pasta FF13_PS3_PATCH
- Execute o arquivo TRADUZIR_PATCH.bat e espere terminar o processo.
- Copie a pasta de volta para o console e é só jogar.

OBS: a única diferença notável desse update é a adição do modo fácil, que nunca foi lançado no ocidente no PS3, apenas no japão.
As únicas versões que tiveram oficialmente localização americana foram a versão especial japonesa Ultimate Hits International do Xbox 360 e a da Steam, que usou como base este mesmo release do jogo. 

Agradecimentos Especiais ao Rhadamants e toda equipe de tradução da TriboGamer!

*Esta adaptação é disponibilizada gratuitamente, sem fins lucrativos!
Se você comprou ela, você foi enganado!

Bom jogo!