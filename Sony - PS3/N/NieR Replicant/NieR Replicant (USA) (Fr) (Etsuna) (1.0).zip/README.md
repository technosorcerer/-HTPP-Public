# Nier Undub VOSTFR
Undub Nier By Etsuna

Twitter : https://twitter.com/etsunamattel

Twitch : https://www.twitch.tv/etsuna_

# Pour tout problème sur l'Undub, merci de m'envoyer un MP sur Twitter !!!

Ce Undub est à appliquer sur la version Japonaise de Nier.

Seul les Fichiers/dossiers suivants sont nécessaires :

  EBOOT.BIN
  
  EVENT
  
  FONT
  
  TEXT
  
# V1.0

Quête principale testé

Fins A/B/C/D testées

DLC JAP Testé (entièrement traduit en FR).

Les quêtes nécessaires pour la fin C/D ont été testées. Ce qui veux dire que j'ai pas testé toutes les quêtes du jeu !

Corrections textes.

# V0.2b (Non release)

Phase de test

Corrections textes

Correction CRLF
 
# V0.1b (parce que j'ai jamais pensé a faire des versions pendant mon dev, Non release) :

Phase de test
  
Les modifications sont les suivantes : 

  - Tous les textes sont en français.
  
  - Le texte utilisé est celui de la version EU, donc il y a probablement des différences entre les voix et le texte.
  
  - Certains mots sont coupés en fin de ligne, c'était déjà le cas dans la version EU du jeu,
  il est nécessaire de réécrire l'intégralité des textes du jeu, je n'ai ni le temps, ni le mentale pour ça.
  Libre à vous si vous vous sentez l'âme d'un guerrier du texte et que vous voulez vous y lancer.
  
  - J'ai quand même aligné tous les textes hors InBoxText et RadioBoxText (en haut à gauche), donc les lettres,
  les objets, les descriptions (quêtes comprises), ça c'est OK.
  
  - La syncho à été faite entre les voix et le texte, il se peut qu'il y ai des soucis.
  
  - LA VERSION JAPONAISE A DES BIPS DE CENSURE DANS SA VERSION ORIGINALE ! JE PEUX PAS PATCHER CES BIPS !
  
  - Grimoire Weiss devient Grimoire Shiro, son nom dans sa version Japonaise.
  
  - Grimoire Noir devient Grimoire Kuro, son nom dans sa version Japonaise.
  
  - le "Papa" devient "Grand frère" pour pas être trop creepy xD
  
  - le "Fille" devient "Sœur" pour pas être trop creepy aussi xD
