This is just a beta English patch to a supposedly partial English patch of
Initial D: Extreme Stage, that I have unfortunately put on hold and stopped
working on since 12/24/2014 due to some issues that I've never got hold of
the modified images a friend of mine was working on and got busy with my
other projects. I'm just releasing it now since some might have a use for
it and enjoy the game partially patched even though not completed and wont
just be wasted hiding privately on my pc. 

I have not fully bug tested this since 2014 and just made a patch from my last
working backup and tested a bit. There are a lot of version of this game and
this patch is specifically for Initial D: Extreme Stage [BLJM60055]. Not sure
if I'm able to revive this project but I'll try to have a look again and maybe
port it to the BLJM50053 version with is a much more common version of the
game and also have a IRD useful for verification of the integrity of the files.

How to patch:

Copy the 2d.xdelta, car.xdelta, EBOOT.xdelta, patch.bat and xdelta3.exe
inside your Initial D game directory run patch.bat and wait for it to
finish. Copy your BACKUP folder just in case you failed to make a whole
backup of your game and you can delete 2d.xdelta, car.xdelta, EBOOT.xdelta,
patch.bat and xdelta3.exe inside your Initial D game directory.