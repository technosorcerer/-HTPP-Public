In the Castlevania: Harmony of Despair game with DLC, user may notice that the music list (under Help&Options -> Settings -> Sound Settings -> Music setting) sometimes have a few duplicated song names (song names but not songs) showing there.

This patch will eliminate the duplicated song names.

This patch works for US, JP and EU editions.

How to apply the patch:
1. Download the patch and extract it.
2. Copy the extracted folder "dlc99_remove_BGM_Dup" into the DLC folder as below:

EU edition:   \game\NPEB00563\USRDIR\dlc\
JP edition:   \game\NPJB00138\USRDIR\dlc\
NA edition:   \game\NPUB30505\USRDIR\dlc\