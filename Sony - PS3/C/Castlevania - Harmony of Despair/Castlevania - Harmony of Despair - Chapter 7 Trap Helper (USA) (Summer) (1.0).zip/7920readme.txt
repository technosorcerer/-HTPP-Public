In chapter 7 of Castlevania: Harmony of Despair, there is a trap which contains several hidden switches, and those switches have different locations under normal and hard difficulty settings.  This patch will provide some assistence to help you find out those switches.

There are three types of hidden switches:
1.  Trigger the trap
2.  Stop the firewall (left)
3.  Open the door in the right side path (for #2/#4/#6 player) 

This patch will give you some clues.  Watch the bricks carefully!

This patch works for US, JP and EU editions.

Warning:  Make a backup of your original file before apply the patch!

How to apply the patch:
1. Download the patch and extract it.
2. Locate the original file \USRDIR\dlc\dlc01_stage_pyramid\data\stage\splits\stage00_04_fg_left.dds, verify its file size (4,544,128 Bytes) and MD5 hash (2c6e6438faab1bee9c3b6226c619e8a7).
3. Use any xdelta patching tool to apply the patch to above file.


EU edition:   NPEB00563
JP edition:   NPJB00138
NA edition:   NPUB30505


=====================================
在《恶魔城：绝望的和声》第七章，左侧的钉板陷阱那里有好几处隐藏的开关，这些开关的位置会随游戏难度的不同而改变位置。本补丁将为你识破这些隐藏开关的位置提供一些辅助。

一共有三种类型的隐藏开关：
1.  触发钉板落下
2.  暂停左侧的火焰墙（取得紫色宝箱）
3.  开启右侧通道的大门（多人游戏时第2/4/6号游戏者可以抄近路）

本补丁会提供一些线索来找到这些开关。仔细观察附近的砖块！

本补丁适用于美版、日版、欧版。

警告：在打补丁之前，先给原文件做个备份。

如何打补丁:
1. 下载补丁包，解包。
2. 找到原文件 \USRDIR\dlc\dlc01_stage_pyramid\data\stage\splits\stage00_04_fg_left.dds，比对文件大小（4,544,128 字节）以及MD5哈希值（2c6e6438faab1bee9c3b6226c619e8a7）。
3. 使用任意xdelta补丁软件应用这个补丁，并替换原文件。


欧版:   NPEB00563
日版:   NPJB00138
美版:   NPUB30505