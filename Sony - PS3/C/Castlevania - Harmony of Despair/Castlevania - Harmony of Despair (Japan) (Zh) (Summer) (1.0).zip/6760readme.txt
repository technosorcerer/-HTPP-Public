How to patch:
1. Locate the original file game\NPJB00138\USRDIR\data\text\textres_ja.txrc, verify its file size (96,432 Bytes) and MD5 hash (c56a5aa4363e2a0458a3bfc0178ebb57).
2. Use any xdelta patching tool to apply the patch to above file.

=============
如何打补丁：
1. 找到原始文件game\NPJB00138\USRDIR\data\text\textres_ja.txrc，校验文件大小（96,432 Bytes）和MD5哈希值（c56a5aa4363e2a0458a3bfc0178ebb57）。
2. 使用任意xdelta补丁工具对以上文件打补丁即可。