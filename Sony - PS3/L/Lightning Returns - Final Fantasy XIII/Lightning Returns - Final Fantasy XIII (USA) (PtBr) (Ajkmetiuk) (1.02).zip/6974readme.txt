Tradução de Lightning Returns: Final Fantasy XIII para PS3

Sobre a tradução:
- Este é um port da tradução de PC para o PS3. 
- A tradução funciona tanto no jogo base (versão 1.0) como no update 1.01.
- A tradução funciona com todas DLCs lançadas.
- O port foi feito em cima do jogo em mídia americana [BLUS31164].

Progresso: 100%

Versão 1.0
-Portada a tradução para o PS3.

Versão 1.01
-Adicionado compatibilidade com o Patch 1.01 e DLC da roupa da Aerith.

Versão 1.02
-Rhadamants traduziu as DLCs faltantes no PC e portei tudo para o PS3, creio que agora o jogo esteja 100% tanto no PC como no PS3.

CRÉDITOS:

Tradução para PC: TriboGamer e Central de Traduções

Administrador(es): Rhadamants e Zexia
Tradutor(es): Rhadamants, airtonj3, GStrifeX, hicaroJr, Jnt_ntl,
kimihir0, leo_14_jti, snice, TheCrazeey, Vigaku, Zadock e Zexia
Revisor(es): Rhadamants e Zexia
Testes In-game: Zexia e ddanniell
Ferramentas: Rhadamants, Albeoris e Le hieu
Instalador: Rhadamants

Adaptação para PS3: ajkmetiuk
Ferramentas desenvolvidas por FluffyQuack (v1.4)


Como utilizar o patch:

O pacote vem com 3 patchs, um para ser aplicado no jogo base e um para aplicar no update 1.01 e outro nas DLCs.

Tradução no jogo base (1.0):

- Tenha em mãos o dump do jogo americano de mídia física [BLUS31164].
- Copie a pasta PS3_GAME para dentro da pasta LRFF13_PS3_JOGO_BASE.
- Execute o arquivo TRADUZIR_JOGO_BASE.bat e espere terminar o processo.
- Copie a pasta PS3_GAME de volta para o console e é só jogar.
- Caso não queira que o jogo atualize, é só retirar da internet ou cancelar o update quando aparecer o prompt.

Tradução no update 1.01 (Opcional, esse é mais para quem quiser jogar com a DLC de áudio em japonês ou usar as DLCs de roupas):

- Instale o update pela PSN ou, ao abrir o jogo, o mesmo já irá pedir para atualizar automaticamente.
- Localize o update em seu PS3, geralmente ele é instalado em dev_hdd0/game/BLUS31164/USRDIR
- Copie os arquivos filelist_patch_u.ps3.bin e white_patch_u.ps3.bin para a pasta LRFF13_PS3_PATCH
- Execute o arquivo TRADUZIR_PATCH.bat e espere terminar o processo.
- Copie os dois arquivos de volta para o console e é só jogar.

Tradução nas DLCs (Opcional, caso não tenha a DLC, é só ignorar esse passo):
- Tenha as DLCs instaladas. Se não tiver todas, não tem problema, o que possuir será traduzido. 
- Localize a DLC em seu PS3, geralmente ela é instalada em dev_hdd0/game/BLUS31164/USRDIR/
- As IDs das roupas são definidas como 0000001,0000002,0000003, etc, até a 0000015 (0000020 é a dlc de áudio japonês, então podemos ignorar).
- Copie todas as pastas que tiver, de 0000001 até 0000015 para a pasta LRFF13_PS3_DLC
- Execute o arquivo TRADUZIR_DLC.bat e espere terminar o processo.
- Copie todas as pastas de volta para o console e é só jogar.


Agradecimentos Especiais: a toda equipe de tradução da versão de PC que fizeram um excelente trabalho e a tradução ficou simplesmente incrível.
O jogo é fantástico e sim, merecia uma bela tradução como essa! Obrigado a todos envolvidos...

*Esta adaptação é disponibilizada gratuitamente, sem fins lucrativos!
Se você comprou ela, você foi enganado!

NOTA: Não foi testado o jogo inteiro no PS3, então, caso tenha algum bug ou problema, é só reportar.
NOTA 2: Só foi testado no PS3 e com o jogo americano de mídia física, não garanto funcionamento em outras versões ou em emuladores.

Bom jogo!