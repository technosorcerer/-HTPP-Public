Tradu��o de Lightning Returns: Final Fantasy XIII para PS3

Sobre a tradu��o:
- Este � um port da tradu��o de PC para o PS3. 
- A tradu��o funciona tanto no jogo base (vers�o 1.0) como no update 1.01.
- As falas dos NPCs das roupas DLC n�o foram traduzidas na tradu��o do PC e, curiosamente, a �nica roupa com tradu��o � a da Aerith
e � justamente a que n�o tinha dispon�vel no PC, ent�o, a �nica que inclu� no pacote foi ela.
- O port foi feito em cima do jogo em m�dia americana [BLUS31164].

Progresso: 100%

Vers�o 1.0
-Portada a tradu��o para o PS3.

Vers�o 1.01
-Adicionado compatibilidade com o Patch 1.01 e DLC da roupa da Aerith.

CR�DITOS:

Tradu��o para PC: TriboGamer e Central de Tradu��es

Administrador(es): Rhadamants e Zexia
Tradutor(es): Rhadamants, airtonj3, GStrifeX, hicaroJr, Jnt_ntl,
kimihir0, leo_14_jti, snice, TheCrazeey, Vigaku, Zadock e Zexia
Revisor(es): Rhadamants e Zexia
Testes In-game: Zexia e ddanniell
Ferramentas: Rhadamants, Albeoris e Le hieu
Instalador: Rhadamants

Adapta��o para PS3: ajkmetiuk
Ferramentas desenvolvidas por FluffyQuack (v1.4)


Como utilizar o patch:

O pacote vem com 3 patchs, um para ser aplicado no jogo base e um para aplicar no update 1.01 e outro na DLC da Aerith.

Tradu��o no jogo base (1.0):

- Tenha em m�os o dump do jogo americano de m�dia f�sica [BLUS31164].
- Copie a pasta PS3_GAME para dentro da pasta LRFF13_PS3_JOGO_BASE.
- Execute o arquivo TRADUZIR_JOGO_BASE.bat e espere terminar o processo.
- Copie a pasta PS3_GAME de volta para o console e � s� jogar.
- Caso n�o queira que o jogo atualize, � s� retirar da internet ou cancelar o update quando aparecer o prompt.

Tradu��o no update 1.01 (Opcional, esse � mais para quem quiser jogar com a DLC de �udio em japon�s ou usar as DLCs de roupas):

- Instale o update pela PSN ou, ao abrir o jogo, o mesmo j� ir� pedir para atualizar automaticamente.
- Localize o update em seu PS3, geralmente ele � instalado em dev_hdd0/game/BLUS31164/USRDIR
- Copie os arquivos filelist_patch_u.ps3.bin e white_patch_u.ps3.bin para a pasta LRFF13_PS3_PATCH
- Execute o arquivo TRADUZIR_PATCH.bat e espere terminar o processo.
- Copie os dois arquivos de volta para o console e � s� jogar.

Tradu��o na DLC da Aerith (Opcional, caso n�o tenha a DLC, � s� ignorar esse passo):
- Tenha a DLC instalada.
- Localize a DLC em seu PS3, geralmente ela � instalada em dev_hdd0/game/BLUS31164/USRDIR/0000003
- Copie os arquivos filelist_p0000003img_u.ps3.bin e white_p0000003img_u.ps3.bin para a pasta LRFF13_PS3_DLC
- Execute o arquivo TRADUZIR_DLC.bat e espere terminar o processo.
- Copie os dois arquivos de volta para o console e � s� jogar.


Agradecimentos Especiais: a toda equipe de tradu��o da vers�o de PC que fizeram um excelente trabalho e a tradu��o ficou simplesmente incr�vel.
O jogo � fant�stico e sim, merecia uma bela tradu��o como essa! Obrigado a todos envolvidos...

*Esta adapta��o � disponibilizada gratuitamente, sem fins lucrativos!
Se voc� comprou ela, voc� foi enganado!

NOTA: N�o foi testado o jogo inteiro no PS3, ent�o, caso tenha algum bug ou problema, � s� reportar.
NOTA 2: S� foi testado no PS3 e com o jogo americano de m�dia f�sica, n�o garanto funcionamento em outras vers�es ou em emuladores.

Bom jogo!