Mortal Kombat II (Mega Drive 32X)
Traducción al Español v1.0 (04/10/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mortal Kombat II (32X) (W) (Jan 1995) [!].32x
MD5: 9d258d11fe1e4cac2c1aab370c35e57a
SHA1: f75698de887d0ef980f73e35fc4615887a9ad58f
CRC32: 211085ce
4194304 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --