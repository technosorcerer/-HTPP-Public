Metal Head (Mega Drive 32X)
Traducción al Español v1.0 (10/12/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Metal Head (Japan, USA) (En,Ja).32x
MD5: 03cc5d7549d71ba4e9ddc1beae3805fb
SHA1: 4e872fbb44ecb2bd730abd8cc8f32f96b10582c0
CRC32: ef5553ff
3145728 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --