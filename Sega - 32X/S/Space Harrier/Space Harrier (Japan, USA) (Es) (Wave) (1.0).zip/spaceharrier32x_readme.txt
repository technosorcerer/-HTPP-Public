Space Harrier (Mega Drive 32X)
Traducción al Español v1.0 (23/01/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Space Harrier (Japan, USA).32x
MD5: 6180e973f678bfc96705e8be4e0783f1
SHA1: f32a52a7082761982024e40291dbd962a835b231
CRC32: 86e7f989
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --