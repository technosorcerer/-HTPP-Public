Aplicar na ROM: Space Harrier (32X) (?) [!].32x ou Space Harrier (32X) (?) [!].bin
Caso sua ROM seja europ�ia aplique um desses patchs: [32X] Space Harrier (E) [!] [T-BR] [T-Carlson].ups, [32X] Space Harrier (E) [!] [T-BR] [T-Carlson].ips ou [32X] Space Harrier (E) [!] [T-BR] [T-Carlson].exe.
Casu sua ROM seja americana aplique um desses patchs: [32X] Space Harrier (JU) [!] [T-BR] [T-Carlson].ups, [32X] Space Harrier (JU) [!] [T-BR] [T-Carlson].ips ou [32X] Space Harrier (JU) [!] [T-BR] [T-Carlson].exe.

Antes de aplicar o IPS na sua ROM fa�a uma c�pia de seguran�a da mesma. Caso o patch n�o funcione mude a exten��o da rom para .smd e converta para .bin.