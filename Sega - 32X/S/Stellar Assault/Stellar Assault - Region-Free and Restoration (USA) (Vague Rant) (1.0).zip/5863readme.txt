  ============================================================================
==   Stellar Assault (or Shadow Squadron) Region-Free and Restoration Patch   ==
  ============================================================================

Stellar Assault is a space shooter developed by Sega CS and released in 1995 for
the Super 32X. The game was originally released in two forms, one for Japan and
the other for North American and European markets. Both releases are region-
locked, and the game has several differences when played on western consoles.
This patch region unlocks the game and restores the major changes (title screen,
difficulty select, enemy colors, etc.) back to their original form.

 =============== 
= Compatibility =
 =============== 

This patch can be applied to either of the released versions of the game.

Stellar Assault (Japan).32x
CRC32: FCE4C8C7
MD5:   5F6C601DCECCA937B6F2C2161E4566FE
SHA-1: FF4F1A2DDED85F3AD43BF28A85C46AD8595D5614

Shadow Squadron ~ Stellar Assault (USA, Europe).32x
CRC32: 60C49E4D
MD5:   1415A8675ADF3E8647B3DF673B50056D
SHA-1: 561C8C63DBCABC0B1B6F31673CA75A0BDE7ABC72

 =========
= Changes =
 =========

Here's a list of all changes implemented in this patch. If you like, you can use
this information to mix and match patches to suit your preferences; a patcher
like IPSelect will allow you to choose which patches do or do not apply if you
want a simple GUI approach.

0x0150 534841444F57205351554144524F4E -> 5354454C4C41522041535341554C54
Changing the USA internal name from SHADOW SQUADRON to STELLAR ASSAULT

0x018E xxxx -> 0000
Zeroing out the checksum; 32X skips checksum calculation with 0000 as checksum

0x116E 67 -> 60
Restores Magenta as the default enemy color and Normal as the default difficulty

0x11C0 6616 -> 4E71
Restores the original Stellar Assault title screen

0x1E1A 67 -> 60
Restores the difficulty select to a three-way select instead of two-way

0x1F2C 67 -> 60
Restores the Normal difficulty setting (needs the previous fix to work)

0x33BC 6632 -> 4E71
Restores the MCTV logo on "Trace" replays

0x4A04 67 -> 60
Allows the game to run on any region console

 ==========
= Unchanged =
 ==========

In the process of finding the above, there were a couple of other region checks
which I felt were either not worth changing, or I didn't find what they did.

0x143A 67 -> 60
Would change copyright text from US SEGA 1995 to JP SEGA ENTERPRISES, LTD. 1995

0x7DFA 67 -> 60
No idea, I did not identify what this check changes