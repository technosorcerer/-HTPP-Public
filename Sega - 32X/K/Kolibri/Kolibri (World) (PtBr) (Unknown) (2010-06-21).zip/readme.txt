Aplicar na ROM: Kolibri (W) [!].bin
ou Kolibri (W) [!].32x

Antes de aplicar o IPS na sua ROM fa�a uma c�pia de seguran�a da mesma.

O Fusion apresenta um bug na fase Extracao e com qualquer emulador se voc� passar de fase com o cheat Vidas infinitas ele s� ir� para a pr�xima fase se voc� desabilitar. Tais problemas n�o s�o por causa da tradu��o.