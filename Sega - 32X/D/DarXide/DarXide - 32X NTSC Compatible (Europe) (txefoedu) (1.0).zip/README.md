# darxide-unlock
Region NTSC unlock patch for Darxide (Sega 32x game)
