This patch completely replaces the original engine, adding performance improvements and new features, as well as missing levels from the Jaguar port.

- Network support via the Zero Tolerance (aka Technopop) link cable.
- Splitscreen coop and deathmatch modes.
- New title screen that resembles the Saturn and PlayStation versions.
- Rendering has been spread across both SH2 processors for better speed.
- User input is processed at 30FPS, while game logic runs at 15FPS.
- Low (two pixel modes) 128×144, 128×160, 160×180 and three high detail 224×128, 252×144, 320×184 video modes.
- Anamorphic widescreen support for 16:9 screens.
- Improved visual fidelity (aka ‘high color’) mode.
- FM Synth soundtrack courtesy of Spoony Bard.
- Selecting between no music, VGM FM music, or playing music from attached Sega CD (requires Sega CD in addition to 32X).
- Stereo panning for game sounds.
- Controller hot plugging support.
- Save ram support - keeps track of finished levels, health, armor, weapons and ammo - eight save slots as well as an auto-save at the end of each level.
- Includes levels that were omitted from the original release.
- Restores sprite directions from the Jaguar version as well as in-fighting between monsters.
- Level fixes courtesy of Wavy.
- Spectres look the way they did in the original PC version.
- Jaguar Doom HUD assets.
- Three drawing modes: the regular sector based lighting (although it’s better than the original Doom 32X in that sprites also use this lighting, no more 100% bright sprites!), “potato” mode which doesn’t texture floors or ceilings for slightly better speed, or the original Doom fading light rendering (which is just a smidgen slower and looks a little muddy given the fifteen bit palette of the 32X).
- ‘Always run’ option.
- Anti-aliased automap with smooth scaling.
- Support for three-button and six-button pads, as well as the Sega mouse. You can choose how to map the primary three buttons in the menu.
- Verified as working on Kega Fusion 3.64, a Model 2 Genesis + Model 2 CD + launch 32X, a CDX + 32X, with a NeoFlash NeoMyth MD and the V1 Mega EverDrive, and also with Mega EverDrive Pro and MegaSD.
- Support for 32X+ (CDDA tracks from CUE files) on the MegaSD flashcart.
- Multi-region, supports both PAL and NTSC.

== CHANGELOG ==

Changes in v2.1:
- Fixed regressions:
-- SegaCD audio support didn't work
-- Random 'R_FlatNumForName: not found' error in 320px mode
-- Glowing lights were broken
-- Gradient lighting on floors and ceilings was broken
-- Sprites would sometimes partially or completely disappear in 320px mode
- Fixed an old Jaguar Doom bug related to item collection, where if the player was touching multiple items simultaneously, neither item would be picked up if at least one of them was maxed out in inventory
- Fixed bug where sprites would sometimes become visible through walls depending on the sector's relative floor height
- Fixed bug where the game would freeze if player's ammo count was greater than 999
- Fixed the attack speed of shotgun guys not being consistently doubled in nightmare mode
- PWM frequency increased from 30Hz to 70Hz, reducing the maximum latency for in-game sounds from 33ms to 14ms
- Some of the game's assets received color restoration treatment
- Improved rendering performance in high resolution modes
- The 320px mode screen size reduced from 184 to 180 pixels
- Optimized maps loading time
- Added support for custom finale text and background to the DMAPINFO lump

Changes in v2.0:

- Network support via the Zero Tolerance (aka Technopop) link cable.
- Fullscreen 320×184px graphics mode.
- A refined palette / colourmap has been added for improved visual fidelity, aka “high colour” mode.
- Controller hot plugging support.
- Anamorphic widescreen support for 16:9 screens.
- 32X+ (CDDA tracks from CUE files) support has been added and is enabled when the MegaSD flash cart is detected.
- Upon completing the game, the song “The End of DOOM” is now played during the final message.
- The colormap now inverts during invulnerability to closer match the original DOS port of the game.
- The AutoMap now has smooth scaling.
- The maximum number of sound channels in the mixer has been increased from 4 to 8.
- Monsters in neighboring sectors are now more likely to wake up when a player fires a weapon.
- Sector lighting now defaults to high detail mode.
- Imps and Cacodemons now have slower projectile speeds.
- Doom 2 map specials are now supported.
- Improved multi-threaded rendering of sprites.
- The map title and stats are now displayed in the automap.
- When possessing the sphere of invulnerability, the god mode face is now shown in the status bar.
- The game can no longer be paused during multiplayer.
- You can no longer attack, strafe or use things when in the automap.
- The Spectre is now featured in the final cast sequence.

Changes in v1.5:

- Improved rendering performance by 25%.
- Restored the “Sign of Evil” music track for E1M8.
- Menu logos, font and HUD icons revamped by Polonium to closer match the original box art.
- All maps have proper REJECT lumps now, boosting performance even further.
- Restored the missing third sight and death grunts for zombie monsters.
- The game now defaults to fullscreen video mode.
- Pressing MODE+Start now switches to fist if you have berserk.
- Fixed the automap being squished vertically and also tweaked default automap scale.
- The automap is now anti-aliased.
- Fixed the menu occasionally wouldn’t play the switch sound upon being brought up.
- The second player can no longer pause or unpause the game in splitscreen mode.

Changes in v1.4:

- Added splitscreen coop and deathmatch modes.
- Fixed sounds effects being in mono on real hardware.
- Memory and CPU optimizations.
- Changed 240p PAL mode to use letter-boxing instead of vertical stretching.
- Pressing START button during the finale screen restarts the game now.

Changes in v1.3:

- New status bar graphics, that more closely match the PC original, by Wavy.
- New “PAL Aspect ratio” option, which increases vertical screen resolution by 16 pixels, allowing the game graphics to be unsquished on PAL.
- Improved UI responsiveness.
- Restored bridge across the lava in MAP22 that had been missing in the Jaguar version of the map.

Changes in v1.2b:

- Fixed strobe lights flickering too fast.
- Tweaked timings for the hold mode of the START button.

Changes in v1.2a:

- Improved compatibility with SRAM saves on older Everdrive models.

Changes in v1.2:

- Smooth 30FPS doors and platforms.
- The DOOM logo now scrolls during introduction sequence like it does in PSX version the game.
- Added XZ strafe mapping to options.
- Menu wasn’t visible in automap mode.
- Improved auditory cues in menus.
- Pressing MODE + START now switches to fist.
- Fixed gibbing animation in HUD.
- Strafing now follows the USE action mapping, instead of being hardcoded to “C”.
- Corrected monster animation speed on finale screen and added shot sounds.
- The “New game” menu now remembers the last selected map until game’s restarted.

Changes in v1.1b:

- Automap scaling isn’t reset on loading a save state anymore.
- Fixed an occasional Z_Free error in map selection menu.

Changes in v1.1a:

- Fixed chainsaw sounds.

Changes in v1.1:

- Added E3M3 “Deep Into the Code” music track.
- Added support for dedicated strafe buttons (Y&Z or C&Z, Y for Use).
- Fixed double damage taken in lava and slime.
- Fixed powerups expiring at double rate.
- The ‘always run’ mode no longer toggles fast turning.
- Lost souls should now bounce off floors and ceilings (vanilla Doom bug).
- Draw map titles in menus.
- Navigation is menus should feel snappier now.
- Removed the framerate option from video settings.

== CREDITS ==

Resurrection

- Programming: Victor Luchits, Joseph Fenton
- Music: Spoony Bard https://www.youtube.com/c/spoonybard13
- Level fixes: Wavy
- Additional support: MatteusBeus, TrekkiesUnite118, Barone

Calico DOOM

- Programming and reverse engineering: James Haley
- Additional code: Samuel Villarreal, Rebecca Heineman

Special thanks

- id Software
- Songbird Productions
- RetroRGB
