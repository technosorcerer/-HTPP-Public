
                                DOOM
                           Sega 32X, 1994

                       Tradução Portuguesa (PT)
                          XX de XXXXX de 20XX

------------------------------------------------------------------
1. Conteúdos & Uso
2. Histórico & Notas Sobre o Patch
3. Agradecimentos
4. Contacto
------------------------------------------------------------------

------------------------------------------------------------------
1. Conteúdos & Uso
------------------------------------------------------------------

 Este ficheiro *.ZIP deve conter:

 - D32XPT_Readme.txt 	- Este ficheiro de texto, em Português
 - D32XPT.xdelta       	- O patch para Doom da 32X
 - BFG.xdelta		- Patch opcional com a BFG 9000

 Os dados do ROM original devem ser:

 SHA1: B68E9C7AF81853B8F05B8696033DFE4C80327E38
 MD5: 79339867D9D4F58B169753D9A29EA1A5
 CRC32: 208332FD
 Checksum: D746

 Uma vez aplicado, o ROM com o patch deve ter:

 SHA1: E287D54E316F18F54E31506271F5F127B5E9AC66
 MD5: 4A1F926F1CDC2A40F6D054AFD20C6B73
 CRC32: 69D63276
 Checksum: FD44


 Podem ver os valores através do Hasher online do Romhacking,
 disponível no site: https://www.romhacking.net/hash/

 Para aplicar o patch, é necessário usar o xdelta UI,
 disponível no site: http://www.romhacking.net/utilities/598/

 O patch opcional com a BFG 9000 deve ser aplicado sobre o ROM
 ao qual já foi aplicado o patch de tradução.

------------------------------------------------------------------
2. Histórico & Notas Sobre o Patch
------------------------------------------------------------------

 Início do projeto: 08 de novembro, 2019
 Fim do projeto: 13 de janeiro, 2020

 Este patch foi feito para a versão JU[!] (Japão, Estados Unidos)
 de Doom. A tradução para português inclui:

 Texto e Gráficos: 100%
 • Ecrã inicial
 • Opções (controlos, dificuldade, etc.).
 • HUD (armas, vida, etc.).
 • Níveis e itens (sinais de saída, munições, etc.).
 • Créditos finais (equipa e nomes de inimigos).

 Além da tradução, este patch corrige uma série de problemas
 encontrados na versão de 32X, a fim de apresentar uma melhor
 experiência de jogo e que agora pode ser concluída a 100%.

 *A saber, além da tradução o patch principal proporciona:

[Melhorias Gerais]
 • Remove todas as "Things" (entidades) não usadas nos mapas
   (Multiplayer, Deatmatch, etc.) de modo a aliviar a memória
   dos mesmos.

 • Corrige a orientação do míssil. Na versão original, o "sprite"
   do míssil apenas inclui a versão frontal ou seja, visualmente
   é como se fosse disparado ao contrário.

 • Apresenta várias "linedefs" (superfícies) que por erro ou
   omissão não eram apresentadas no minimapa quando deviam ser,
   e oculta "linedefs" desnecessárias.


[Correções]
 • Nível 2: Corrige a impossibilidade de conquistar 100% de 
   inimigos ao mover um Imp que havia ficado atrás de uma parede
   quando o nível foi convertido para 32X. Esta correção aplica-se
   aos modos de dificuldade mais elevados.

 • Nível 4: Duas caixas de munições para a caçadeira não tinham
   definições de dificuldade, por isso nunca eram mostradas.
   Agora estão presentes em todos os modos de dificuldade.

 • Nível 5: Existe um pentagrama no nível que devia teleportar
   os jogadores para o início do mesmo, mas o setor de destino
   não tinha a "tag" correspondente pelo que o teletransportador
   nunca funcionava. Agora funciona.

 • Nível 6: Na última divisão, um inimigo ("Demon") foi colocado
   entre uma parede e um sinal de saída, tornando-se incapaz de 
   mover. Foi movido de modo a não ficar entalado na geometria
   do nível.

 • Nível 7: Dois barris não tinham definições de dificuldade,
   por isso nunca eram apresentados no mapa. Agora estão presentes
   em todos os níveis de dificuldade.

 • Nível 8: Certas partes do nível não apareciam no minimapa.

 • Nível 9: O setor com as duas alavancas que ativam as portas
   da divisão com o cartão vermelho e desbloqueiam o acesso 
   à área secreta com a Plasma Gun não aparecia no minimapa.

 • Nível 10: Corrige a impossibilidade de conquistar 100% de 
   inimigos e 100% de segredos. Foi criado um caminho para uma
   divisão secreta que ainda está presente no nível, mas cujo 
   acesso foi cortado deixando no seu interior vários inimigos 
   e itens impossíveis de alcançar. O interior da sala também
   foi corrigido a nível de texturas e de geometria.

 • Nível 10: Corrige o efeito "Hall of Mirrors", um efeito de
   distorção causado quando o jogo tenta renderizar alguma área
   sem textura, o que o força a renderizar a última superfície
   com textura repetidamente.

 • Nível 10: Um barril não tinha definições de dificuldade,
   por isso nunca era apresentado no mapa. Agora está presente
   em todos os níveis de dificuldade.

 • Nível 10: Uma parede referenciava uma textura que não existe
   no jogo.

 • Nível 11: Corrige a impossibilidade de alcançar 100% de 
   segredos ao colocar a "tag" apropriada numa área que foi 
   simplificada durante o processo de conversão dos níveis para 
   32X. A área em si é a escadaria após a piscina de lava, a qual
   conduz até à Plasma Gun. A "tag" de área secreta foi colocada
   no último degrau.

 • Nível 12: Certas partes do nível não apareciam no minimapa.

 • Nível 13: Uma divisão perto do início do nível tinha duas paredes
   viradas ao contrário, o que resultava em paredes invisíveis.

 • Nível 14: Corrige a impossibilidade de conquistar 100% de 
   inimigos. Durante a conversão para 32X, uma armadilha perto do
   final do nível foi mantida mas o ativador naõ foi reintroduzido. 
   Foi criado um novo ativador e uma "tag" também foi aplicada ao 
   setor necessário para que agora seja possível aceder à divisão 
   com inimigos.

 • Nível 14: Uma caixa de munições para a caçadeira tinha sido
   deixada fora do mapa, no local onde outrora existia uma parte
   do nível (removida durante a conversão). A caixa foi movida
   desse "vazio" para perto do início do nível.

 • Nível 14: Uma parede referenciava uma textura que não existe
   no jogo.

 • Nível 14: Corrige a textura usada na saída do nível, que estava
   desalinhada e como tal não mostrava a típica alavanca de saída.

 • Nível 15: Várias superfícies referenciam texturas não existentes
   no jogo ou simplesmente não referenciam nenhuma textura (o que
   resulta na aplicação de uma textura padrão), ou estão
   desalinhadas. Onde aplicável foi usada a textura correta.
   Além disso, quase todas as texturas do nível foram alinhadas
   manualmente.

 • Nível 15: Um dos setores com um dos ativadores necessários para 
   chegar até ao final do nível tinha um efeito de luminosidade 
   erradamente definido para "0".

 • Nível 17: Certas partes do nível não apareciam no minimapa.

 • Nível 17: Foi removido um destino de teletransporte para o qual
   não havia teletransportador.

 *Incluí também um patch opcional que reintroduz a BFG 9000
  no jogo, no mesmo nível e local da versão de Jaguar (Nível 11).
  A BFG 9000 foi incluida num patch opcional para que os jogadores
  pudessem optar entre uma versão original (ainda que traduzida
  e melhorada mas mais próxima à versão lançada para o mercado)
  e uma versão com a arma removida.

 Finalmente, esta tradução foi escrita ao abrigo do Novo Acordo
 Ortográfico português.

------------------------------------------------------------------
3. Agradecimentos
------------------------------------------------------------------

 • Saxman, pelos conversores de 32X para *.WAD.

------------------------------------------------------------------
4. Contacto
------------------------------------------------------------------

 Para qualquer comentário, crítica, sugestão ou erro relativo
 a este patch de tradução para Doom, enviem e-mail para:

 diogo.fa.ribeiro @ gmail

 Também me podem encontrar no Romhacking.net com o nome "4lorn".

