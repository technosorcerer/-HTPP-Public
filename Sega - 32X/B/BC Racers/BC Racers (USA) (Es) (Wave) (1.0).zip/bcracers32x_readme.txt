BC Racers (Mega Drive 32X)
Traducción al Español v1.0 (16/01/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
BC Racers (USA).32x
MD5: 35a11e021ca0b7ff909e4774eb8b3236
SHA1: 9b5fd499eaa442d48a2c97fceb1d505dc8e8ddff
CRC32: 936c3d27
3145728 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --