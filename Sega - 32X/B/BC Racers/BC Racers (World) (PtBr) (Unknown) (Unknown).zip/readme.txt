Caso os patch que come�am com BIN- n�o funcionem tente com o que come�a com SMD-.

Antes de aplicar o patch na ROM fazer uma c�pia de seguran�a da mesma.