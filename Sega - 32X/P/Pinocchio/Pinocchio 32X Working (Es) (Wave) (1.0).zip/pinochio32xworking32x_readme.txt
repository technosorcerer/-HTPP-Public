Pinochio (Mega Drive 32X)
Traducción al Español v1.0 (07/01/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
-Compatible con Special edition y Prototype Fixes, solo se pierde la traducción de las opciones

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pinochio 32X Working.32x
MD5: 406ab3e46797d8459c3d9efbbc044282
SHA1: 39ccf67e516bdaec879f1e30b23d5f253e82b6c8
CRC32: 390a90f9
4194304 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --