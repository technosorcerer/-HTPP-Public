Disney's Pinocchio (32X) IPS patch version 1.00
17 FEB 2019
By Barone
Made using Exodus, Gens r57shell Mod, HxD, RRR Palette v1.2, GEMS Tools 

==Purpose of the patch==
This patch fixes and improves several details of the prototype recently released by Hidden Palace:
- Region conversion (original release is Europe-only).
- Color palette improvement for the backgrounds. They are rendered by the Mega Drive and had several repeated values to them causing the loss of pixel art details.
- Audio tempo and pitch fix for 60 Hz regions (the original protorype release is adjusted for 50 Hz). 
- Bypass of the pulsing-red test screen during the boot-up sequence of the game.

==Usage==
Apply the included IPS file to the ROM (e.g. via Retron 5, Cybergadet Retrofreak, dedicated programs such as "StealthPatch IPS Patcher" and "Lunar IPS").
There are specific patches for each region release of the game since the checksums of the ROMs are different. 
After applying the patch to its correct regional ROM, the checksum will be the correct one already.
 
==Notes==
* Successfully tested on real hardware.Unlike written elsewhere, the game doesn't lock-up during gameplay; I've extensively tested it with no issues whatsoever.
* The animations run a bit faster than normal in 60 Hz and I still didn't find a way to adjsut it. But the game is still perfectly playable in 60 Hz. 
* Thanks to Hidden Palace and Radar for the release of this amazing prototype.

==Contact info==
Go to the AtariAge or Sega-16 forums and you'll find me there.
I also have this thread: http://www.sega-16.com/forum/showthread.php?30343-Barone-s-Hacking-Corner which is dedicated to hacking discussions and feedback.

