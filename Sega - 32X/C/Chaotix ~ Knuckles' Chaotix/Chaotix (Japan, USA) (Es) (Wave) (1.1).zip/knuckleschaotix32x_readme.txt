Knuckles' Chaotix
Traducci�n al Espa�ol v1.1 (11/06/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Knuckles' Chaotix
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Knuckles' Chaotix
-----------------
Plataformas de Knuckles para la 32x.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
V1.1: Arreglados textos de opciones.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Knuckles' Chaotix (JU) (32X) [!].32x
3.145.728 bytes
CRC32: d0b0b842
MD5: 47b1095e68b053125cd2cd5b1ac4eb50
SHA1: 0c2fff7bc79ed26507c08ac47464c3af19f7ced7

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --