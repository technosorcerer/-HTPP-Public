Cyber Brawl ~ Cosmic Carnage (Mega Drive 32X)
Traducción al Español v1.0 (08/10/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Cyber Brawl ~ Cosmic Carnage (Japan, USA).32x
MD5: 32f3002a46a462735aa12ca856cb7652
SHA1: 9a563ed821b483148339561ebd2b876efa58847b
CRC32: 7c7be6a2
3145728 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --