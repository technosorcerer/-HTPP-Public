Aplicar na ROM: After Burner 32X (A).bin

Antes de aplicar o IPS na sua ROM fa�a uma c�pia de seguran�a da mesma.