Aplicar na ROM: After Burner Complete (32X) (E) [!].32x

Antes de aplicar o IPS na sua ROM fa�a uma c�pia de seguran�a da mesma.