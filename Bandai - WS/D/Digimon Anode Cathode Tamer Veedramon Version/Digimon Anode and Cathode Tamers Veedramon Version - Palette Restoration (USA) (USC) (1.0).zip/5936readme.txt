Digimon Anode/Cathode Tamer Veedramon Edition - Palette Restoration
Version 1
20 MAY 2021
-Nikc

==================================================
|Description
=================================================

Digimon Anode/Cathode Tamer Veedramon Edition is one of the rare Wonderswan Color games released with an intentional English version (such that it is). However, it is a very unintentional issue - the background palette of Datamon's Server Room is overwritten by the player's palette, resulting in a garish green tinted area with clashing colors.

This small patch fixes the typo and distorted sprite overlay to restore the room's appearance. Now you can see the Server Room as the artists originally intended!

==================================================
|Changelog
=================================================

v1: 
 -> Initial Release
  
==================================================
|Future Updates
=================================================

-> Restore any other palette issues or problems

==================================================
|How to Patch
=================================================
Get a copy of the "Digimon Anode Cathode Tamer Veedramon Version" ROM and an IPS patching program (Lunar IPS seems to be the standard).
Run the program, click 'Apply patch', and viola! Enjoy.

==================================================
|Feedback
=================================================

Questions? Suggestions? Glitches?
WonderswanTranslations@gmail.com