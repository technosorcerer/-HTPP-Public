Rainbow Islands - Putty's Party (WonderGate Unlock)
---------------------------------------------------

The original game has an extra menu that allows you to unlock some extra features if you hook up a neat little accessory that connects to your 2000s era Japanese cell phone, communicates with certain web pages under certain conditions, and then sets a few flags in the save file.
These extra bonuses and the ways to access them via save hacking have been documented here:
https://tcrf.net/Rainbow_Islands:_Putty%27s_Party

The purpose of this hack is allow you to access these items without having to dial back 22 years or edit save files, while maintaining as close to the original experience as possible.
As such it does these two things specifically:
-Bypass the connection and communication process of the "Get Item" function of the WonderGate menu, and deliver a random item to your current save file
-Bypass the connection and communication process of the "Get Image" function of the WonderGate menu, and activate an image based on your score (in order of what you have unlocked already)

Essentially it does what the menus suggest, and acts like it's actually communicating. It doesn't make any edits to menus.

Install:
--------
This hack is compatible with the original Japanese version (No-Intro), as well as 1.0 of Nikc's English translation patch. It's possible it may not be compatible with future patches, but these edits are in a code space that should be mostly unused by any other functions, so it should have a high propensity for compatibility, so long as you're using a verified and modern romset (probably won't work with trimmed roms).
It's IPS so use your preferred patching tool, like Lunar.

The regular patch does what is suggested above and immediately below, and the CHEAT patch is explained in the second "How to" section of this readme. Only use one or the other.

If you wanted, you could use the cheat patch to just unlock all the stuff you want, and then go back to the normal ROM, and play as you desire. The save files should be compatible, and won't be reliant on either of these patches.

How to get items
----------------
All you need is a save file in any slot with some progress. Then select one of these options in the WonderGate menu.

Get Item:
This option will issue an item at random to your selected save file, even if you already obtained it. You will get to the view the special cutscene that accompanies it as well!
Technically, all these items can be obtained through the normal course of play. Even the Devil's Tear can be obtained, I believe, though from what I can tell it is exceedingly rare such that you will probably never obtain it.

Get Image:
This option will issue an image for the title screen based on your score. Any save file used will unlock it for everyone.
This gets progressively higher and higher, and there's cute little cutscenes that congratulate you and tell you the next amount you need. Eventually you need to max out the score at 99,999,990

How to get items using the CHEAT patch
--------------------------------------
This patch completely ignores the original routines and checks, and just issues what I believe would be the most desired items, no score checks, no random chance. This is coincidentally, also the 1.0 patch. Here's how to use it.

Before starting be sure to save progress to any file slot of your choice if you haven't already
(To do do this, simply select the game option from the main menu, select New Game, skip to the intro by pressing Start, then on the file select screen, press X4 to call up the menu, and select the Save option. Now you can reboot

1. Launch the game.
2. Get to the Title screen
3. Select WonderGate
4. Select either "Get Item" or "Get Image", based on what you want
5. Select the save file
6. Confirm action
7. If "Error 999" shows up, this means success
8. Press X3 to get out of this menu

Repeat any of the above if you want to apply the affect to different file slots, or want to unlock different things. 
Unlocking the Images only needs to be done once. 
There's not a way to remove items once unlocked, apart from clearing or overwriting save information.

Notes:
------

As of Nikc's 1.0 English patch, the connecting and communication screen will look a little funny while stuff is going. It looks fine in Japanese, so I believe the reason is because these particular strings and graphics have not been translated because the y were otherwise inaccessible until this point.
I actually could have bypassed a little more of these strings, but it felt better to try to retain as much of the communication messages as possible, so I tried to keep them, while decreasing any scanning times as well

In Japanese, The 999 error screen says something roughly translated to English like: 
WonderGate Error
Let's Go
Good Luck

With the English patch, it is garbled, since I believe only the default error message was translated (which makes sense, normally nothing else will ever come up).

At the time of this writing the English patch is 1.0 and it has a reference that they may be adding some of these unlocks into the natural progression of the game. If so, that's cool, and I don't have a problem if it makes this obsolete in some way. There's a possibility it may still be compatible though, unless that patch overwrites the WonderGate data in some way.
If it makes sense for him to use this in his future patch, he doesn't need to ask, and has my permission to use it (or make it better) in an upcoming version.

Big thanks to the original person who did the research on TCRF (who I know realize is Nikc). It helped me find all the appropriate locations, including all the additional locations needed for proper assignment, save storage, etc., etc.

Bonus:
------
There's a bonus menu in the game, which you unlock once you view all 5 endings in the game.
If you're feeling savvy, you can unlock this quickly by editing your save file with 0x01 at addresses 0x21A through 0x21E.
Better to do it legitimately though, right?
Right?
I knew you had it in you.