Rainbow Islands - Putty's Party (WonderGate Unlock)
---------------------------------------------------

The original game has an extra menu that allows you to unlock some extra features if you hook up a neat little accessory that connects to your 2000s era Japanese cell phone, communicates with certain web pages under certain conditions, and then sets a few flags in the save file.
These extra bonuses and the ways to access them via save hacking have been documented here:
https://tcrf.net/Rainbow_Islands:_Putty%27s_Party

The purpose of this hack is allow you to access these items without having to dial back 22 years or edit save files, while maintaining as close to the original experience as possible.
As such it does these two things specifically:
-Bypass the connection and communication process of the "Get Item" function of the WonderGate menu, and deposit the overpowered Devil's Tear into your save file based on the save file selection (1, 2, or 3)
-Bypass the connection and communication process of the "Get Image" function of the WonderGate menu, and activate all 12 available additional title screen images, which aren't reliant on the save file (which I believe is the original behavior).

Essentially it does what the menus suggest, though there aren't any fancy frills to it. It doesn't make any edits to manus, and instead calls up a hidden error message on success. Mostly to maintain compatability, no edits have been made to internal menus or messaging.

Install:
--------
This hack is compatible with the original japanese version (No-Intro), as well as 1.0 of Nikc's English translation patch. It's possible it may not be compatible with future patches, but these edits are in a code space that should be mostly unused by any other functions, so it should have a high propensity for compatability, so long as you're using a verified and modern romset (probably won't work with trimmed roms).
It's IPS so use your preferred patching tool, like Lunar.

How to get items
----------------
In case you were curious, after you've applied this patch, here's how to take advantage of it:
Before starting be sure to save progress to any file slot of your choice if you haven't already
(To do do this, simply select the game option from teh main menu, select New Game, skip to the intro by pressing Start, then on the file select screen, press X4 to call up the menu, and select the Save option. Now you can reboot

1. Launch the game.
2. Get to the Title screen
3. Select WonderGate
4. Select either "Get Item" or "Get Image", based on what you want
5. Select the save file
6. Confirm action
7. If "Error 999" shows up, this means success
8. Press X3 to get out of this menu

Repeat any of the above if you want to apply the affect to different file slots, or want to unlcok different things. 
Unlocking the Images only needs to be done once. 
There's not a way to remove items once unlocked, apart from clearing or overwriting save information.

Notes:
------

In Japanese, The error screen says something roughly translated to English like: 
WonderGate Error
Let's Go
Good Luck

With the English patch, it is garbled, since I believe only the default error message was translated (which makes sense, normally nothing else will ever come up).

At the time of this writing the English patch is 1.0 and it has a reference that they may be adding some of these unlocks into the natural progession of the game. If so, that's cool, and I don't have a problem if it makes this obsoltet in some way. There's a possibility it may still be compatible though, unless that patch overwrites the WonderGate data in some way.
If it makes sense for him to use this in his future patch, he doesn't need to ask, and has my permission to use it (or make it better) in an upcoming version.

Big thanks to the original person who did the research on TCRF. It helped me find all the appropriate locations, including all the additional locations needed for proper assignment, save storage, etc., etc.