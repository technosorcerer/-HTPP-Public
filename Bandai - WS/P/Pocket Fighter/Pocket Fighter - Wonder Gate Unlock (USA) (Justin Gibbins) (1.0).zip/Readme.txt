Pocket Fighter (WonderGate Unlock)
----------------------------------

This game is actually really cool considering the limitations of the platform, and actually includes some neat little extras, such as the Card Battle mode.
Like Putty's Party, though, some of those extras are locked behind the WonderGate, which today is defunct, making unlocking certain things impossible if you don't edit a save file as documented here:
https://tcrf.net/Pocket_Fighter_(WonderSwan)

Inexplicably, you'll notice some important features such as Training and Sound Test are locked behind this, meaning that if you're not equipped with a time travel device (or SRAM editing tools), you're not getting these cherry features.

What are you gonna do about it?
-------------------------------
This patch simply edits the Extras menu, such that it always shows everything, and lets you select it all. It doesn't write to SRAM, and it also removes the need to have save data there.
No muss, no fuss.

Install
-------
It's IPS format, so just use something like Lunar.
This is a very simple patch in two small places, and should be compatible with other patches going forward.
As always, go with No-Intro, and I would anticipate this would fail to install over trimmed romsets from eras past.

Use
---
After install, just select the Pocket Fighter option from the main menu, Select Options, then Extras, and it will all be there. 
No need to load a save file or anything like that either. Works on real harrdware from my testing.

Notes:
------

Thanks to the original person who did the research on TCRF
I know this kind of game doesn't need it, but I always like reading the win quotes and story stuff from these kinds of games in English, so hopefully one day this game gets a little of that treatment, if it ain't too much trouble.