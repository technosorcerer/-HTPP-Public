--- Clock Tower for WonderSwan - English Fan Translation ---
By BobSchneeder45
Distributed by Team C.U.T.S.
Using Aeon Genesis's English translation of the Super Famicom original,
with item and character names altered to match the Clock Tower: Rewind translation,
as well as some minor tweaks where needed.

Installation: Apply the IPS patch to the Japanese Clock Tower for WonderSwan ROM.

Note on hardware limitations:
In some cases you'll come across very short messages or ones that always stay on the first row.
This is due to the low number of sprites available for text,
meaning the text needs to fit during the worst case scenario where a lot of sprite slots are already taken.

Enjoy!