Chocobo's Dungeon for WonderSwan: Fan Translation Readme
v1.1

Changelog:
v1.1: Script cleanup
v1.0: Initial release

Instructions: 
Apply the .ips patch with a patcher such as Lunar IPS.
================================================================================================================
FAQ:
1: What is this game?
 Chocobo's Dungeon 2 received an English translation, but the first game in the series, a PS1 game, never
 received a translation. It did however receive a WonderSwan remake that ALSO never got translated!
 This translation is for that version of the game.
2: Does this game have connections to other games in the series?
 Chip appears in 2 and Every Buddy, while Atla and Camilla are recruitable buddies in Every Buddy in a cameo
 appearance. The events relating to them are direct references to this game.
3: What is the game like?
 The game is very much a classic Mystery Dungeon structurally. Its difficulty ramps up quickly and expects you
 to exit and re-enter the dungeon to prepare. You can use the Teleport Card to exit, and re-enter the dungeon
 in order to make it further after you've prepared more.
================================================================================================================
Known Errors:
-Text is occasionally offset by a slight amount. This is due to the method we used to get the script into the
 game.
-Whistle animation has slight display error.
-Title screen has not been translated.
================================================================================================================
Credits
================================================================================================================
SpecialAgentApe:	Hacking, Menu Translation, Graphics editing
Higsby:			Translation
ShinxHijinx:		Testing
================================================================================================================
Special Thanks
================================================================================================================
wowjinxy