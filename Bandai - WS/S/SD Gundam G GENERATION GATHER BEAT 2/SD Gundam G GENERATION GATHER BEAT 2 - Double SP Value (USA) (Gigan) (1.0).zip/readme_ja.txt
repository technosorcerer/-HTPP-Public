SD Gundam G Generation - Gather Beat 2 Hack

"SDGGG_GatherBeat2_Hack.ips"

「SDガンダム GGENERATION GATHER BEAT2」のIPSパッチです。

【変更点】
・全パイロットのSP初期値を倍化

<EOF>
