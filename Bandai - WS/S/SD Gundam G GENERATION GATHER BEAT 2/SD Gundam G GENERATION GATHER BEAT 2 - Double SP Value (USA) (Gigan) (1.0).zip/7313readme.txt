SD Gundam G Generation - Gather Beat 2 Hack

"SDGGG_GatherBeat2_Hack.ips"

IPS patch for "SD Gundam G GENERATION GATHER BEAT 2". 

[change point]
- Double the initial SP value of all pilots

<EOF>
