Super Robot Wars Compact 2-1 Easier Hack

The cost of repairs and remodeling is high even though the amount of money earned when defeating an enemy is small, so even if there is a shortage of funds, stress will accumulate.
For light users who want to play comfortably, the economic cost has been greatly reduced.
Please try it.

"SRW-Compact 2-1 Easier.ips"

This is "Super Robot Wars Compact 2 dai 1-bu: Chijo gekido-hen" IPS patch.

[Changes]
- SP consumption value 1/5, unit modification cost 1/10, weapon modification cost reduced to 1/3
- Swap repair costs and earned funds
- Units with 4 or less parts slots are +1
- Lowered the HP of units with HP over 15000.

P.S.
I used MasMin to analyze this hack.
https://www.romhacking.net/utilities/1668/

EOF