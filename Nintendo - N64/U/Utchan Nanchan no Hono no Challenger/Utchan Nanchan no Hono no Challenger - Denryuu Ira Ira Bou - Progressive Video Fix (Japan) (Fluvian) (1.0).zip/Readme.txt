The graphics for this game are internally a low res 320x240, but due to a developer
oversight the video mode used is 640x480i. In other words the N64 outputs 
interlaced video without the additional resolution. 
All the pixels are twice the height and width, for CRT users there's noticeable 
interlacing and no scanline gaps.


This patch turns the console video output 320x240 progressive to match
the graphics of the game.

Patch using a BPS patcher like Beat.