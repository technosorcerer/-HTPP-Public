Uranium Mario 64 by usernamesarespiders has 110 stars according to this star display. A light kaizo hack which is a kaizo version of Plutonium. Hack works with Mupen-era plugins (it was built on them two years ago before... the troubles). Best played with savestates unless you're a baller or something. Credits listed in hack. Use flips to convert bps if you don't know how figure it out I'm not your dad.

Thanks again to AndrewSM64, GMD, and LinCrash for playtesting. Thanks Internet Archive for being cool as fuck.

Texture Ports:
Banjo Kazooie,
Majoras Mask, 
Glover,
Super Mario 64 + Beta
Diddy Kong Racing 
Donky kong 64
Crash Tag Team Racing Motors
Chrono Cross
Dream Land
Earthworm Jim 3D
Super Mario Galaxy 1 and 2
Smash Bros
Mario Party
Mario Kart 64 + Wii
Bomberman 64
Ape Escape
Paper Mario Castle
Resident Evil
Silicon Valley
SM64DS
New Soup Wii
Sonic Unleashed
Super Mario Sunshine
Luigi's Mansion
Custom Self Made Textures

Ports Used:
Yoshi's Story Main Theme
Banjo Kazooie Gruntilda's Lair
Sonic CD Tidal Tempest
Sonic Something Oil Ocean
Underwater City
Illusion Stone Chamber
NSMB Wii Ghost House (Pirannha Plant Inst)
SMG Purple Coin Comet
Mario Party 2 Bowser's Land
DK64 Catacombs
SMRPG Barrel Volcano
Banjo Kazooie Gobi Valley
Banjo Something Mad Monster's Mansion
SMW Underground
Bango Tooie Isle o Hags
Pirates' Fortress
Kirby 64 Beach
SSBB Ricco Harbour
Pokemon Ranger Jungle Relic
Castlevania cmed
De mysteriis dom sathanas??? by 47110 (C9 Song)
MK8 Shy Guy Falls
Bubblegoop Swamp
SMG Freezeflame Galaxy (Piranna Inst)
MK64 Rainbow Road
Banjo Kazooie Bubblegoop Swamp
DKC2 Stickerbrush
Mario Party Dangerous Game
Pokemon Uranium Trainer Battle
M&L Paper Jam Doop Doop Dunes
Sonic Advance 3 Ocean Base Map
Animal Crossing Meteor Shower
Magmoor Caverns

The silence in the "The End" is called "I need a vacation alone" composed by me. I made it on the toilet.
