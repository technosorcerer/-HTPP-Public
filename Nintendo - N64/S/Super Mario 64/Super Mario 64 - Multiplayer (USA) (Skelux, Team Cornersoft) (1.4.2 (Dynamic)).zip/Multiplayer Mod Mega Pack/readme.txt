XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

SUPER MARIO 64 / STAR ROAD MULTIPLAYER

		CJES LUIGI

XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

All those modifications have to be
patched using ppf-o-matic3 to the
regular SM64 Multiplayer or
SMSR Multiplayer ROM!

I hope the patches still work on future
versions. They were last tested on 
version 1.3.1 of SM64 Multiplayer and
1.2.1 of SMSR Multiplayer.

XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

What the patches do:

----------------------------------------

SM64 Multiplayer Cjes Luigi.ppf

Replaces Luigi's model with the one
Cjes made.

----------------------------------------

SM64 Multiplayer Classic N64 Colors.ppf

Changes both Mario's and Luigi's
palettes to match the colors from the
original game.

----------------------------------------

Player 2 as Player 1.ppf

Self explanatory. Player 1 is Luigi,
Player 2 is Mario (keep in mind that
Mario will still have Luigi's physics).


----------------------------------------

SM64 Multiplayer Green Mario.ppf

Replaces Luigi with a 2nd Mario
wearing Luigi clothes.

----------------------------------------

SM64 Multiplayer SMG4.ppf

Replaces Luigi with SMG4.
No questions.
Star Road Colors.ppf

Changes both Mario's and Luigi's
palettes to match the colors from
Super Mario Star Road.

----------------------------------------

Luigi Dialog (SM64).ppf

A simple text edit that makes NPC's
speak to both Mario and Luigi in
Super Mario 64 Multiplayer.

----------------------------------------

Luigi Dialog (SMSR).ppf

A simple text edit that makes NPC's
speak to both Mario and Luigi in
Super Mario Star Road Multiplayer.

----------------------------------------

SM64 Multiplayer (Cjes).wad

The Wii Wad for Super Mario 64
Multiplayer using Cjes' Luigi model.

----------------------------------------

SM64 Multiplayer (Cjes+N64 Colors).wad

The Wii Wad for Super Mario 64
Multiplayer using Cjes' Luigi model
and the original SM64 Colors.

XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX


If you want to change the head icons in
the game's HUD, use N64Rip and these
addresses:

Mario Head Icon (16x16): 0080A156
Luigi Head Icon (16x16): 0080A356

XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

Credits to:

Cjes for making this awesome Luigi model.
https://www.youtube.com/watch?v=1h7UgiHscRQ

Skelux Core for making SM64 Multiplayer
and publishing the documents.
https://www.youtube.com/watch?v=Gk5-XNP6doM

Kaze Emanuar and Super Mario who helped
me finding some of the addresses.
https://www.youtube.com/user/KazeBG0
https://www.youtube.com/channel/UCi8_NJFUne1kchf58qHfA-Q

Starxxon for making the original Luigi.
https://www.youtube.com/watch?v=sUWy7S_urRg

GeoshiTheRed for several forms of support.
https://www.youtube.com/user/GeoshiTheRed/feed

XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX