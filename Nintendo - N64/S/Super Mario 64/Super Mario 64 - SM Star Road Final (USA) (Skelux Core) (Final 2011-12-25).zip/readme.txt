---Super Mario Star Road (Final Version PPF)---

Introduction:
Super Mario Star Road is an immense fan game of  Nintendo's Mario series featuring over 30 new areas, 
nearly 50 tunes and much more new content.

Patch Setup:
1. Obtain a Super Mario 64 rom
2. Extend it with 'M64 ROM Extender 1.3b' in the 'Patching Tools' folder
3. Drag the rom over 'rom_expand.exe' in the 'Patching Tools' folder
4. Patch "Super Mario Star Road.ppf" to it using "PPF-O-MATIC 3.0" in the 'Patching Tools' folder

Emulator Setup:
1. Download a Nintendo 64 emulator, I recommend Project 64
2. If you are using Project 64 1.6, open it and press Ctrl+T
3. Open the 'Options' tab and uncheck 'Hide Advanced Settings'
4. Close the settings box and press Ctrl+T again
5. Open the 'Advanced' tab and set 'Default Memory Size' to '8 MB'
6. Click 'OK' then press Ctrl+O to locate and load the Super Mario Star Road rom

Optional Setup:
1. Press Esc to enter full screen mode
2. To increase the game resolution, open the 'Options' menu and click 'Configure Graphics Plugin...' then change the full screen resolution
3. If you want to play with a controller, open the 'Options' menu and click 'Configure Controller Plugin...'
4. Improve audio by clicking the 'Options' menu followed by 'Configure Audio Plugin...' and 'Sync game to Audio'

Patching Note:
While selecting the ISO file in PPF-O-MATIC, you may need to set 'Files of type' to 'All Files' 
before selecting the rom.

You may visit these pages for more information:
https://sites.google.com/site/supermario64starroad/home/
http://www.youtube.com/user/Skelux
