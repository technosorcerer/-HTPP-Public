SUPER MARIO STARDUST MOON

Hack created by Fares242
Megafixed and edited by LinCrash [via base v1.2]

=====

I thank you for the long awaiting update of Fares242's newly released hack, which to all of us, knew how it turned out if he had taken more time and effort to fix the things on his own but couldn't. 
It's also unfortunate that I personally didn't enjoy 100% of the gameplay because it's starting to get repetitive a lot, so here's a little big something to spice it up from the ground-up. 
To those who played the early versions and felt that something went wrong from the beginning, I recommend reading the changelog to get a slew of improvements.

To those who were pleased with my updates, I appreciated the reviews and feedback I got in return. And of course, most of the thanks should belong, first and foremost to Fares242 for creating the
sequel, even if the gameplay was distinguishably below our expectations. And if, some day, he's allowed to improve for his future projects, I'll try to be as constructive with my criticism (and so are the fans) to help him get to the basic of basics.

Once again, thank you all and please enjoy the rewarding masterpiece I have ironed out for your excitement! Peace out!

~ LinCrash


PS: Oh of course, I can't ever leave you without a little surprise as well, here's a DLC associated to the game. How about that for replay value?! 

=====

CREDITS:

Thanks to:
Ozzie/Ozsef - playtesting, feedback, suggesting QoL changes (pre-2.3 build)
DJ_Tala - playtesting, feedback, extra help (custom star model, CIC error fix)
KingToad - early v2.4 build playtesting

Special thanks to:
SM64 ROM Hacks Discord Community - for the hype, feedback and discussion around the hack
Pilzinsel64, ROM Manager Team - for their provided resources and tweaks used

=====

KNOWN ISSUES [SOLVED]

This hack has CIC errors popping up while loading the ROM. But it should be working fine for a few PJ64 1.6 users if PJ64Fixups is installed with CIC error fix enabled.