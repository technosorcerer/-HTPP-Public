)                                    (
)                                    (
)  THANK YOU FOR DOWNLOADING ! ! !   (
)                                    (
)                                    (
________________________________________

factoids!

This build was completed on 8/27/24 at 3:05 AM CST!

I need sleep

going on a small break after this is published! (atleast until my wifi returns)

maybe possibly open source soon????

ETA: probably never im really lazy :sob:

finished hack might not ever come, ill probably just change the name and remove the big "DEMO" if that happens


Thank these kind people specifically:

Kaze Emanuar | Main inspiration for hack (kaze is ripped LMFAO)

Reozies20 (i think (its a tradition to have a horribly misspelled name in the description of my hacks) | for being a catgirl with an unfortunately large hat

nutta | genuine encouragement, and being an absolute G.

Albert fingerdoodle | uhh cool guy 

and basically everyone in kaze emanuar's discord server!




AND YOU..............................................................................................................................................Ur mom lol (im so sorry)







i literally cannot stress how much i appreciate you downloading this hack <3


- MemeTime/7up/Vista/Parrot/Ada/Adam/Rose (those are all my names)



Peace.
