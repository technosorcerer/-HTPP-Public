Current version: v1.0

Transcending the Rainbow is a 182 star high-end kaizo made by Serium.

For a full playthrough of the Beta stages of the game, check out this playlist by Unendlich:
https://www.youtube.com/playlist?list=PLtqXbB_CUPkHWGVF40jTjP89VzpAT9zJj

Memories of a Lucid Dream - Guest course by Amsixx, who also made the port.

Super Mario 64 base game created by Nintendo.

Most textures sourced from BroDute's texture pack with some slight adjustments. Some textures handmade by me.

Music credits:
MIDIs for songs were sourced from OnlineSequencer, Musescore, VGMusic.
None of the songs are made by me, none of the MIDIs are made by me. All rights go to their respective holders.
MIDIs were ported to SM64 soundfont and made into m64 by me.

Course: Song name - Artist (Game/Source)
Overworld 1: Lonely Rolling Star - The 8-Bit Big Band (Katamari Damacy)
Peach's Metal Training Camp: Dance of Eternity - Dream Theatre
Peach's Vanish Training Camp: Flower Dance - DJ Okawari
Peach's Wing Training Camp: Fukkireta - Dwandonly
Starting Savannah: Yoru ni Kakeru - YOASOBI
Trepidation Mansion: KING - Kanaria
Dark Mossy Maze: Feral Amalgamation - DM DOKURO (Terraria Calamity Mod)
Below Zero: Antarctic Reinforcement - DM DOKURO (Terraria Calamity Mod)
Waters of Tranquility: Footfalls - Masayoshi Soken (Final Fantasy XIV)
Sparking Resolve - Death by Glamour - Toby Fox (UNDERTALE)
Key 1 Fight: Viyella's Tears - Laur

Overworld 2: Bury the Light - Casey Edwards, Victor Borba (Devil May Cry 5)
A Moment's Reminiscence: Caramelldansen - Caramell
Starship Voyagers: Storm Eagle (Mega Man X)
Dreams of Sakura: Mesmerizer - Satsuki
Torture Nexus: Wizpig Race (Diddy Kong Racing)
Infernal Complex: KICKBACK - Kenshi Yonezu (Chainsaw Man)
Grand Scorched Ruins: Isaac's Battle Theme (Golden Sun)
Ad Infinium: Devil N' Bass (Super Meat Boy)
Final Step: An Enigmatic Encounter - Benjamin Crimson (UNDERTALE Last Breath)
Bowser Fight: Lace - Christopher Larkin (Hollow Knight: Silksong)

Overworld 3: Title - Deniz Akbulut (CrossCode) (NOT A PORT)
Memories of a Lucid Dream: Bergentrückung - Toby Fox (UNDERTALE) (Ported by Amsixx)
Ancient Night Flourish: Six Trillion Years and an Overnight Story - Leo/need
Desolate Dystopia: The Disappearance of Hatsune Miku - cosMo
Accursed Rose: Romeo and Cinderella - Doriko
Land of Fiction: Triple Baka - LamazeP
Suffocation: Rolling Girl - Wowaka
Ashen Misery: Grimm - Christopher Larkin (Hollow Knight)
Key 2 Fight: Uragirimono no Requiem - Daisuke Hasegawa (JoJo's Bizarre Adventure: Golden Wind)
Serium's Delirium: Shizuka - Deniz Akbulut (CrossCode) (NOT A PORT)

Metal Cap: Toxicity - System of a Down
Vanish Cap: FLOWER - DJ YOSHITAKA
Wing Cap/Shell: Akasha - Xi
Star Select/Star Get: Ao no Sumika - Tatsuya Kitani (Jujutsu Kaisen)
File Select: Title - Deniz Akbulut (CrossCode) (NOT A PORT)
Credits: Fallen Down (Reprise) - Toby Fox (UNDERTALE)

???: SUPER TETO - nbaji

This project initially started in January 2023, but very little progress was made for a long time. However, at the start of May 2024,
I decided to take this project seriously and released a short demo of what I had finished so far, which was a measly 30 stars.
Due to the overwhelming support from everybody, I was further motivated and decided that I was going to make this project a priority.
Over the course of 7 months, I worked almost everyday for multiple hours making, testing, and gathering feedback on new levels and
ideas I had.

Overall, I am very proud of this project. What started as my first attempt at making a kaizo ended up becoming so much more than that,
and I look forward to making new hacks in the future and pushing myself to new heights, both as a player and a creator. Giving people
a memorable experience is something that will always make me happy, and I hope that you can get something out of this hack. Whether
you choose to just get a few stars with savestates, or if you go all the way and get every single star, I appreciate you.

Thank you.

- Serium
