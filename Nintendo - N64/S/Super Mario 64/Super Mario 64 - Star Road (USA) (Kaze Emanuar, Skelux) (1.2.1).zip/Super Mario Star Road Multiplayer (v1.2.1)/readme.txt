--------Super Mario Star Road Multiplayer 1.2, by Skelux--------
If you downloaded the PPF, you must first follow these instructions:
1. Obtain a Super Mario 64 (U) ROM
2. Extend it using 'M64 ROM Extender 1.3b' in the 'Patching Tools' folder
3. Drag the ROM over 'rom_expand.exe' in the 'Patching Tools' folder
4. Patch 'SMSR Multiplayer 1.2.ppf' to it using 'PPF-O-MATIC 3.0' in the 'Patching Tools' folder

If you wish to play online, it is recommended that you use the emulator included. You will first need to go 
into 'Options' then 'Settings' and change the ROM directory to where the SMSR Multiplayer ROM is located. 
To play online, click on 'File' then 'Start Kaillera...', enter your name, then click 'Master Servers List'.
Join any server and right-click below the chat window to host a game that your friend can join.
To set up the controls, go into 'Options' then 'Configure Controller Plugin...' and go to the 'Player 2' tab.

While playing the game, you can hold 'R' to lock the camera onto your player. Pressing 'L' will switch to 
an alternative camera mode. Also, since PJ64k does not save while playing online, you can press 'Z' at the file 
select screen to unlock all levels. Either player can perform taunts by pressing D-PAD buttons. You may pause the game 
while in the main hub and press left or right to toggle team attack, which allows you to damage the other player.

If you experience online desync, this can be fixed if both players hold down L+R+START which will simultaneously
warp them back to the main hub. This button combination will not work in the hub exterior or at the star select menu.

Alternatively, you may eliminate desync and further reduce lag by setting up the AQZ Netplay input plugin. 
This will also allow you to save your progress.

~Skelux

--------FAQ--------
Q. Where can I find your other work?
A. https://www.youtube.com/user/Skelux/

Q. Can I play this on Wii 64?
A. Yes, but a lot of levels will lag.

Q. What alternative emulators would you recommend?
A. You could try Mupen64++ or an AQZ plugin, both of which will allow you to save your progress.

Q. I have another question, where can I ask it?
A. http://origami64.net/

--------Changes--------
Version 1.2:
[Player Interaction]
*Can toggle Team Attack by pressing left or right at the pause menu
*Added D-Pad taunts
*Can perform a flip off the other player if jumped on while crouching
*Can knock back player by diving into them
*Fixed minor collision sphere bug when jumping on the other player
*Some attacks have a different effect on the other player
*No bounce from punching other player
[Object Interaction]
*Player two can collect 1-ups
*Player two can trigger check points
*Player two can end races with KTQ
*Cannons are now visible, though code is incomplete
*Fixed giant collision sphere on some enemies
*Fixed Handroid's collision sphere
*Tumbling bridges respawn
*Improvements made to talking with NPCs and signs
*Fixed minor bugs with picking up objects
*Changed behavior of recovery hearts to support both health bars
*Platforms on tracks respond to player two
*Fixed koopa shells occasionally crashing the game 
[Interface]
*Players have separate health, now displayed numerically
*Players have separate coin counters
*Players have air underwater
*Fixed crashing when selecting 'Save & Quit'
*Race timer has been moved
*Small improvement to Luigi's life icon by Quasmok
*New file select graphic by Quasmok
*Menu cheat now unlocks the second-floor cannon
[Camera]
*Can press 'L' for an alternate camera mode
*Camera starts in zoomed-out mode
*Camera behavior does not change while dying or collecting stars
[Misc]
*New title screen
*Both players can hold down L+R+START to warp back to castle and fix online desync
*Character clothing colors more accurately match modern Mario and Luigi
*Restored randomization code to fix some behaviors such as snow
*Many more forms of death allow the other player to continue playing
*Disabled getting stuck in snow/sand to fix a bug
*Some effects such as smoke from running are fixed
*All eye animations are working for both players
*Stars appear above the correct player's head
*Fixed Koopa shells being duplicated
*Spawned stars jump over to the player who spawned it
*Fixed stars from boxes or red coins freezing after speaking with an NPC
*Player 3 and 4's controls have been removed for now
*Fixed menu cheat not unlocking the 30-star doors
*Fixed crashing on pause menu when many objects are visible
*Fixed bug occurring if both players die simultaneously
*Fixed picked-up objects appearing on dead players
*Disabled buggy effects from Koopa Shell

Version 1.1:
*The second player is Luigi
*Luigi jumps higher than Mario
*Luigi decelerates slower than Mario
*Fixed random freezing in Project 64
*Reduced online desync by replacing randomization code
*Included working palette codes
*Players can attack each other
*Added widescreen improvements
*Fixed player two animation after entering level
*Seesaw platform physics work for both players
*Tilting square platforms work for player one
*Tumbling bridges behave correctly for player two
*Player two can activate floor switches
*Player two can activate cap switches
*More objects are always visible and active for player two
*Mario's ability ends correctly in cap levels
*Fixed disabled fall damage
*Player shadows do not vanish while hanging from ledges
*Fading warps are functional
*Players cannot lose their cap
*If one player falls into quicksand, the other can continue playing
*Sealed doors do not repeatedly display messages
*Skip sealed door animations when menu cheat is activated
*Pushable objects can be moved by player two
*Fixed Bob-omb interaction with player two
*Fixed various issues related to picking up objects
*Players begin standing next to each other
*Recovery hearts can be used by player two
*Both players can ride koopa shells properly
*Fixed freezing on complicated levels when players are far apart
*Fixed pause menu graphical errors

Version 1.0: 
*Initial release

--------Palette Codes--------
Mario Overalls:
8107EC00 RRGG
8107EC02 BB00
8107EC08 RRGG
8107EC2A BB00

Mario Shirt & Hat:
8107EC18 RRGG
8107EC1A BB00
8107EC20 RRGG
8107EC22 BB00

Mario Gloves:
8107EC30 RRGG
8107EC32 BB00
8107EC38 RRGG
8107EC3A BB00

Mario Shoes:
8107EC48 RRGG
8107EC4A BB00
8107EC50 RRGG
8107EC52 BB00

Mario Skin:
8107EC60 RRGG
8107EC62 BB00
8107EC68 RRGG
8107EC6A BB00

Mario Hair:
8107EC78 RRGG
8107EC7A BB00
8107EC80 RRGG
8107EC82 BB00

Luigi Overalls:
813EC000 RRGG
813EC002 BB00
813EC008 RRGG
813EC00A BB00

Luigi Shirt & Hat:
813EC018 RRGG
813EC01A BB00
813EC020 RRGG
813EC022 BB00

Luigi Gloves:
813EC030 RRGG
813EC032 BB00
813EC038 RRGG
813EC03A BB00

Luigi Shoes:
813EC048 RRGG
813EC04A BB00
813EC050 RRGG
813EC052 BB00

Luigi Skin:
813EC060 RRGG
813EC062 BB00
813EC068 RRGG
813EC06A BB00

Luigi Hair:
813EC078 RRGG
813EC07A BB00
813EC080 RRGG
813EC082 BB00