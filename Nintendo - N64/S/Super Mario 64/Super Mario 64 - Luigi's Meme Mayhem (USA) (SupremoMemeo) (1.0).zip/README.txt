Welcome to Luigi's Meme Mayhem: Version 1!

This hack started creation on April 5th 2020 and ended on July 20th 2020

This is my first Super Mario 64 hack, so it may be a little buggy. I hope you have a fun experience, though!

In this game, Princess Peach is captured by Bowser yet again! But this time, he has sent her and the Toads into the Land of Memes, a twisted, meme-filled version of the Mushroom Kingdom that he created using black magic!

Mario is too busy golfing or driving or smashing or doing whatever the fuck he's doing, but Luigi is worried about her. So, because his brother can't be arsed to do it, it's up to him to save the day! Can he save her in time?

Changes made from the original:
Luigi! L is finally real! With a model made by Cjes, Luigi also has his own unique physics! He can run faster, jump higher, and swim faster than Mario! However, he loses oxygen faster and is also rather slippery.

New textures! The Land of Memes is a horrible, twisted, meme dimension, so the enemies should reflect that! Race Kappa the Zoomer, stomp on Mario Pissing Goombas, and crush a Whomp with a fetish for flattening people - especially green plumbers!

Music! Many tracks from games such as Undertale, Sonic the Hedgehog, Bomberman, and other games in the Mario series appear here! (Credit where needed is in MUSCREDIT.txt)

And many more!

I do not know if this hack works on real hardware, since I do not have my own N64 to test it. If it does, it needs the N64 Expansion Pak to work, as it runs on 8 MB of RAM.

Known bugs:

There is an invisible wall in the Cabin of Cool, Cool Mountain. You cannot go through the slide here. Until I figure out how to fix this, the two stars related to this area are unobtainable.

There may be a game crash in Tiny-Huge Island. Going down the pipe in the small section that transports you to the big section might cause a fatal error on Project64. This does not happen when going from big to small. I am unaware if this happens in other emulators or if it happens on console.

It is possible to bypass the 8 star requirement for the first Bowser stage by climbing on top of the door due to extending level boundaries. This may be helpful for speedrunning, but if I figure out how to patch it, I will.

Thank you for reading! Now go play the fuckin' game already, will ya?

- SupremoMemeo


(This hack is not meant for anyone under the age of 13. If you are under the age of 13, do not play this. It contains some very harsh language that your mother would not want you to read in your good Christian household.)