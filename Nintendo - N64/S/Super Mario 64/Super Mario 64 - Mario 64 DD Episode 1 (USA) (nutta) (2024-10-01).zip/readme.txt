Thank you for downloading Mario 64 DD 60 FPS revision ~ nutta

Special thanks to Mike Ratner for supporting me to be able to make this 60FPS revision and MayroSMM for commissioning me to make this project initially


~nutta

KNOWN ISSUES;

invisible walls in some places