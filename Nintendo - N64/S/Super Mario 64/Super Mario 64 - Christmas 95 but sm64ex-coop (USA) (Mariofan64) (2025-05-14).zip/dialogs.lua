smlua_text_utils_dialog_replace(DIALOG_000,1,6,30,200, ("w o w !  y o u ' r e \
s m a c k  i n  \
t h e  m i d d l e  o f \
a  p e a c e f u l  \
r i v e r !\
b u t  h o w  l o n g \
i s  t h i s  p e a c e \
g o i n g  t o  l a s t ?\
y o u ' l l  f i n d \
t h e  s t a r s  t h a t\
t h e  k u p p a  k i n g \
s t o l e  i n s i d e \
t h e  p a i n t i n g \
w a l l s . \
f i r s t , t a l k \
t o  t h e  a l l y \
h e ' l l  h e l p \
y o u  o u t ."))

smlua_text_utils_dialog_replace(DIALOG_001,1,6,30,200, ("d o  n o t  p l a y\
t h i s  l e v e l\
o r  e l s e  w h o\
h a s  s e v e r a l\
s e i z u r e s  t o\
e n t e r  t h i s !\
t h e r e  i s\
n o  e n d  b u t\
b e c a u s e  i  l i k e\
t h i s . . . .\
\
\
( p l a c e h o l d e r )"))

smlua_text_utils_dialog_replace(DIALOG_002,1,8,95,200, ("l e v e l  l o c a t e d  !\
\
p a n i c !\
w h y  d i d  y o u\
I  g o  w r o n g ?\
\
\
\
y o u  n e e d  t o\
w h e r e  i s\
a r e a .\
\
\
\
\
\
t h e r e  i s  n o\
e s c a p e .\
\
\
\
\
\
\
l e v e l  b y :\
m a s t e r  n a m a\
\
m o d i f i e d  b y :\
m e"))

smlua_text_utils_dialog_replace(DIALOG_003,1,6,30,200, ("1 2 3 4 5 6 7 8 9\
\
\
\
t e s t  l e v e l\
2 9 9 9"))

smlua_text_utils_dialog_replace(DIALOG_004,1,3,95,200, ("i ' l l  p r e p a r e \
t h e  c a n n o n \
f o r  y o u"))

smlua_text_utils_dialog_replace(DIALOG_005,1,3,30,200, ("Hey, Mario! Is it true\
that you beat the Big\
Bob-omb? Cool!\
You must be strong. And\
pretty fast. So, how fast\
are you, anyway?\
Fast enough to beat me...\
Koopa the Quick? I don't\
think so. Just try me.\
How about a race to the\
mountaintop, where the\
Big Bob-omb was?\
Whaddya say? When I say\
『Go,』 let the race begin!\
\
Ready....\
\
//Go!////Don't Go"))

smlua_text_utils_dialog_replace(DIALOG_006,1,3,30,200, ("Hey!!! Don't try to scam\
ME. You've gotta run\
the whole course.\
Later. Look me up when\
you want to race for\
real."))

smlua_text_utils_dialog_replace(DIALOG_007,1,5,30,200, ("Hufff...fff...pufff...\
Whoa! You...really...are...\
fast! A human blur!\
Here you go--you've won\
it, fair and square!"))

smlua_text_utils_dialog_replace(DIALOG_008,1,4,30,200, ("1 9 9 5 - 7 - 2 9\
t e s t  l e v e l\
3 0 0 4"))

smlua_text_utils_dialog_replace(DIALOG_009,1,5,30,200, ("Long time, no see! Wow,\
have you gotten fast!\
Have you been training\
on the sly, or is it the\
power of the Stars?\
I've been feeling down\
about losing the last\
race. This is my home\
course--how about a\
rematch?\
The goal is in\
Windswept Valley.\
Ready?\
\
//Go//// Don't Go"))

smlua_text_utils_dialog_replace(DIALOG_010,1,4,30,200, ("y o u ' v e  j u s t \
s t e p p e d  o n\
t h e  w i n g  C a p \
s w i t c h !\
s a v e ?\
\
//y e s////n o"))

smlua_text_utils_dialog_replace(DIALOG_011,1,4,30,200, ("y o u ' v e  j u s t \
s t e p p e d  o n\
t h e  M e t a l  C a p \
s w i t c h !\
s a v e ?\
\
//y e s////n o"))

smlua_text_utils_dialog_replace(DIALOG_012,1,4,30,200, ("y o u ' v e  j u s t \
s t e p p e d  o n\
t h e  v a n i s h  C a p \
s w i t c h !\
s a v e ?\
\
//y e s////n o"))

smlua_text_utils_dialog_replace(DIALOG_013,1,5,30,200, ("y o u ' v e  \
c o l l e c t e d \
1 0 0  c o i n s !\
s a v e ?\
//y e s////N o"))

smlua_text_utils_dialog_replace(DIALOG_014,1,4,30,200, ("p o w e r  s t a r !\
\
s a v e?\
\
//y es  //n o"))

smlua_text_utils_dialog_replace(DIALOG_015,1,4,30,200, ("( p l a c e h o l d e r )"))

smlua_text_utils_dialog_replace(DIALOG_016,1,3,30,200, ("Hop on the shiny shell and\
ride wherever you want to\
go! Shred those enemies!"))

smlua_text_utils_dialog_replace(DIALOG_017,1,4,30,200, ("I'm the Big Bob-omb, lord\
of all blasting matter,\
king of ka-booms the\
world over!\
How dare you scale my\
mountain? By what right\
do you set foot on my\
imperial mountaintop?\
You may have eluded my\
guards, but you'll never\
escape my grasp...\
\
...and you'll never take\
away my Power Star. I\
hereby challenge you,\
Mario!\
If you want the Star I\
hold, you must prove\
yourself in battle.\
\
Can you pick me up from\
the back and hurl me to\
this royal turf? I think\
that you cannot!"))

smlua_text_utils_dialog_replace(DIALOG_018,1,4,30,200, ("I'm sleeping because...\
...I'm sleepy. I don't\
like being disturbed.\
Please walk quietly."))

smlua_text_utils_dialog_replace(DIALOG_019,1,4,30,200, ("s h h h !\
P l e a s e \
w a l k  q u i e t l y  \
i n  t h e  h a l l w a y !"))

smlua_text_utils_dialog_replace(DIALOG_020,1,6,95,150, ("Dear Mario:\
Please come to the\
castle. I've baked\
a cake for you.\
Yours truly--\
Princess Toadstool"))

smlua_text_utils_dialog_replace(DIALOG_021,1,5,30,200, ("w e l c o m e  t o  t h e\
t e s t  s t a g e !\
\
\
\
t h i s  c a n  b e\
f o u n d  i n\
t h e  g i g a l e a k\
o f\
j u l y  2 0 2 0  i f\
y o u ' r e  b e  u s e d\
a n o m a l y ?\
\
\
\
l e t ' s  p l a y\
t h e  l e v e l !"))

smlua_text_utils_dialog_replace(DIALOG_022,1,2,30,200, ("t h i s  d o o r  i s\
l o c k e d"))

smlua_text_utils_dialog_replace(DIALOG_023,1,3,30,200, ("w r o n g  k e y !"))

smlua_text_utils_dialog_replace(DIALOG_024,1,5,30,200, ("1  s t a r  l e f t"))

smlua_text_utils_dialog_replace(DIALOG_025,1,2,30,200, ("t h i s  d o o r  i s\
l o c k e d"))

smlua_text_utils_dialog_replace(DIALOG_026,1,2,30,200, ("t h i s  d o o r  i s\
l o c k e d"))

smlua_text_utils_dialog_replace(DIALOG_027,1,2,30,200, ("t h i s  d o o r  i s\
l o c k e d"))

smlua_text_utils_dialog_replace(DIALOG_028,1,2,30,200, ("t h i s  d o o r  i s\
l o c k e d"))

smlua_text_utils_dialog_replace(DIALOG_029,1,2,30,200, ("t h i s  d o o r  i s\
l o c k e d"))

smlua_text_utils_dialog_replace(DIALOG_030,1,6,30,200, ("Hello! The Lakitu Bros.,\
cutting in with a live\
update on Mario's\
progress. He's about to\
learn a technique for\
sneaking up on enemies.\
The trick is this: He has\
to walk very slowly in\
order to walk quietly.\
\
\
\
And wrapping up filming\
techniques reported on\
earlier, you can take a\
look around using [C]> and\
[C]<. Press [C]| to view the\
action from a distance.\
When you can't move the\
camera any farther, the\
buzzer will sound. This is\
the Lakitu Bros.,\
signing off."))

smlua_text_utils_dialog_replace(DIALOG_031,1,5,30,200, ("No way! You beat me...\
again!! And I just spent\
my entire savings on\
these new Koopa\
Mach 1 Sprint shoes!\
Here, I guess I have to\
hand over this Star to\
the winner of the race.\
Congrats, Mario!"))

smlua_text_utils_dialog_replace(DIALOG_032,1,5,30,200, ("If you get the Wing Cap,\
you can fly! Put the cap\
on, then do a Triple\
Jump--jump three times\
in a row--to take off.\
You can fly even higher\
if you blast out of a\
cannon wearing the\
Wing Cap!\
\
Use the [C] Buttons to look\
around while flying, and\
press [Z] to land."))

smlua_text_utils_dialog_replace(DIALOG_033,1,6,30,200, ("Ciao! You've reached\
Princess Toadstool's\
castle via a warp pipe.\
Using the controller is a\
piece of cake. Press [A] to\
jump and [B] to attack.\
Press [B] to read signs,\
too. Use the Control Stick\
in the center of the\
controller to move Mario\
around. Now, head for\
the castle."))

smlua_text_utils_dialog_replace(DIALOG_034,1,6,30,200, ("Good afternoon. The\
Lakitu Bros., here,\
reporting live from just\
outside the Princess's\
castle.\
\
Mario has just arrived\
on the scene, and we'll\
be filming the action live\
as he enters the castle\
and pursues the missing\
Power Stars.\
As seasoned cameramen,\
we'll be shooting from the\
recommended angle, but\
you can change the\
camera angle by pressing\
the [C] Buttons.\
If we can't adjust the\
view any further, we'll\
buzz. To take a look at\
the surroundings, stop\
and press [C]^.\
\
Press [A] to resume play.\
Switch camera modes with\
the [R] Button. Signs along\
the way will review these\
instructions.\
\
For now, reporting live,\
this has been the\
Lakitu Bros."))

smlua_text_utils_dialog_replace(DIALOG_035,1,5,30,200, ("1 9 9 4 - 1 2 - 0 4\
c a s t l e"))

smlua_text_utils_dialog_replace(DIALOG_036,1,5,30,200, ("w e t  d r y  t o w n\
l e v e l ."))

smlua_text_utils_dialog_replace(DIALOG_037,1,2,30,200, ("I win! You lose!\
Ha ha ha ha!\
You're no slouch, but I'm\
a better sledder!\
Better luck next time!"))

smlua_text_utils_dialog_replace(DIALOG_038,1,4,95,200, ("r e a c t i n g \
t o  t h e  s t a r\
p o w e r ,  t h e \
d o o r  o p e n s ."))

smlua_text_utils_dialog_replace(DIALOG_039,1,4,30,200, ("No visitors allowed,\
by decree of\
the Big Bob-omb\
\
I shall never surrender my\
Stars, for they hold the\
power of the castle in\
their glow.\
They were a gift from\
Bowser, the Koopa King\
himself, and they lie well\
hidden within my realm.\
Not a whisper of their\
whereabouts shall leave\
my lips. Oh, all right,\
perhaps one hint:\
Heed the Star names at\
the beginning of the\
course.\
//--The Big Bob-omb"))

smlua_text_utils_dialog_replace(DIALOG_040,1,3,30,200, ("Warning!\
Cold, Cold Crevasse\
Below!"))

smlua_text_utils_dialog_replace(DIALOG_041,1,3,30,200, ("I win! You lose!\
Ha ha ha!\
\
That's what you get for\
messin' with Koopa the\
Quick.\
Better luck next time!"))

smlua_text_utils_dialog_replace(DIALOG_042,1,8,30,200, ("y a j i m a  t e s t\
l e v e l  1 0 0 0\
\
m o d e l  b y :\
u 6 4 d a\
\
m o d i f i e d  b y :\
m e"))

smlua_text_utils_dialog_replace(DIALOG_043,1,5,30,200, ("i f  y o u  j u m p\
a n d  h o l d  t h e\
『 A 』  b u t t o n ,\
y o u  c a n  h a n g\
o n  t o  s o m e\
o b j e c t s\
o v e r h e a d .\
i t ' s  t h e  s a m e\
a s  g r a b b i n g  a\
f l y i n g  b i r d !"))

smlua_text_utils_dialog_replace(DIALOG_044,1,5,95,200, ("( p l a c e h o l d e r\
t e x t )\
\
\
\
( p l a c e h o l d e r\
t e x t )"))

smlua_text_utils_dialog_replace(DIALOG_045,1,3,95,200, ("1 9 9 5 - 3 - 31\
w e t  d r y  t o w n\
l e v e l\
m o d e l  b y :\
u 6 4 d a\
\
m o d i f i e d  b y :\
m e"))

smlua_text_utils_dialog_replace(DIALOG_046,1,5,30,200, ("You have to master three\
important jumping\
techniques.\
First try the Triple Jump.\
\
Run fast, then jump three\
times, one, two, three.\
If you time the jumps\
right, you'll hop, skip,\
then jump really high.\
Next, go for distance\
with the Long Jump. Run,\
press [Z] to crouch then [A]\
to jump really far.\
\
To do the Wall Kick, press\
[A] to jump at a wall, then\
jump again when you hit\
the wall.\
\
Got that? Triple Jump,\
Long Jump, Wall Kick.\
Practice, practice,\
practice. You don't stand\
a chance without them."))

smlua_text_utils_dialog_replace(DIALOG_047,1,2,95,200, ("i ' l l  p r e p a r e \
t h e  c a n n o n \
f o r  y o u"))

smlua_text_utils_dialog_replace(DIALOG_048,1,4,30,200, ("Snow Mountain Summit\
Watch for slippery\
conditions! Please enter\
the cottage first."))

smlua_text_utils_dialog_replace(DIALOG_049,1,5,30,200, ("Remember that tricky Wall\
Kick jump? It's a\
technique you'll have to\
master in order to reach\
high places.\
Use it to jump from wall\
to wall. Press the\
Control Stick in the\
direction you want to\
bounce to gain momentum.\
Practice makes perfect!"))

smlua_text_utils_dialog_replace(DIALOG_050,1,4,30,200, ("Hold [Z] to crouch and\
slide down a slope.\
Or press [Z] while in the\
air to Pound the Ground!\
If you stop, crouch, then\
jump, you'll do a\
Backward Somersault!\
Got that?\
There's more. Crouch and\
then jump to do a\
Long Jump! Or crouch and\
walk to...never mind."))

smlua_text_utils_dialog_replace(DIALOG_051,1,6,30,200, ("Climbing's easy! When you\
jump at trees, poles or\
pillars, you'll grab them\
automatically. Press [A] to\
jump off backward.\
\
To rotate around the\
object, press Right or\
Left on the Control Stick.\
When you reach the top,\
press Up to do a\
handstand!\
Jump off from the\
handstand for a high,\
stylin' dismount."))

smlua_text_utils_dialog_replace(DIALOG_052,1,5,30,200, ("Stop and press [Z] to\
crouch, then press [A]\
to do a high, Backward\
Somersault!\
\
To perform a Side\
Somersault, run, do a\
sharp U-turn and jump.\
You can catch lots of\
air with both jumps."))

smlua_text_utils_dialog_replace(DIALOG_053,1,5,30,200, ("Sometimes, if you pass\
through a coin ring or\
find a secret point in a\
course, a red number will\
appear.\
If you trigger five red\
numbers, a secret Star\
will show up."))

smlua_text_utils_dialog_replace(DIALOG_054,1,5,30,200, ("Welcome to the snow\
slide! Hop on! To speed\
up, press forward on the\
Control Stick. To slow\
down, pull back."))

smlua_text_utils_dialog_replace(DIALOG_055,1,4,30,200, ("Hey-ey, Mario, buddy,\
howzit goin'? Step right\
up. You look like a fast\
sleddin' kind of guy.\
I know speed when I see\
it, yes siree--I'm the\
world champion sledder,\
you know. Whaddya say?\
How about a race?\
Ready...\
\
//Go//// Don't Go"))

smlua_text_utils_dialog_replace(DIALOG_056,1,6,30,200, ("You brrrr-oke my record!\
Unbelievable! I knew\
that you were the coolest.\
Now you've proven\
that you're also the\
fastest!\
I can't award you a gold\
medal, but here, take this\
Star instead. You've\
earned it!"))

smlua_text_utils_dialog_replace(DIALOG_057,1,4,30,200, ("i  l o s t  m y \
b a b y !"))

smlua_text_utils_dialog_replace(DIALOG_058,1,4,30,200, ("y o u \
f o u n d \
m y  p r e c i o u s \
b a b y !  wh e r e\
h a v e  y o u  b e e n ?\
h e r e ,  t a k e  i t \
w i t h  m y \
e t e r n a l\
g r a t i t u d e ."))

smlua_text_utils_dialog_replace(DIALOG_059,1,4,30,200, ("t h a t ' s \
n o t  m y  b a b y !"))

smlua_text_utils_dialog_replace(DIALOG_060,1,4,30,200, ("ATTENTION!\
Read Before Diving In!\
\
\
If you stay under the\
water for too long, you'll\
run out of oxygen.\
\
Return to the surface for\
air or find an air bubble\
or coins to breathe while\
underwater.\
Press [A] to swim. Hold [A]\
to swim slow and steady.\
Tap [A] with smooth timing\
to gain speed.\
Press Up on the\
Control Stick and press [A]\
to dive.\
\
Press Down on the Control\
Stick and press [A] to\
return to the surface.\
\
Hold Down and press [A]\
while on the surface near\
the edge of the water to\
jump out."))

smlua_text_utils_dialog_replace(DIALOG_061,1,4,30,200, ("BRRR! Frostbite Danger!\
Do not swim here.\
I'm serious.\
/--The Penguin"))

smlua_text_utils_dialog_replace(DIALOG_062,1,3,30,200, ("Hidden inside the green\
block is the amazing\
Metal Cap.\
Wearing it, you won't\
catch fire or be hurt\
by enemy attacks.\
You don't even have to\
breathe while wearing it.\
\
The only problem:\
You can't swim in it."))

smlua_text_utils_dialog_replace(DIALOG_063,1,5,30,200, ("The Vanish Cap is inside\
the blue block. Mr. I.\
will be surprised, since\
you'll be invisible when\
you wear it!\
Even the Big Boo will be\
fooled--and you can walk\
through secret walls, too."))

smlua_text_utils_dialog_replace(DIALOG_064,1,5,30,200, ("When you put on the Wing\
Cap that comes from a\
red block, do the Triple\
Jump to soar high into\
the sky.\
Use the Control Stick to\
guide Mario. Pull back to\
to fly up, press forward\
to nose down, and press [Z]\
to land."))

smlua_text_utils_dialog_replace(DIALOG_065,1,6,30,200, ("Swimming Lessons!\
Tap [A] to do the breast\
stroke. If you time the\
taps right, you'll swim\
fast.\
\
Press and hold [A] to do a\
slow, steady flutter kick.\
Press Up on the Control\
Stick to dive, and pull\
back on the stick to head\
for the surface.\
To jump out of the water,\
hold Down on the Control\
Stick, then press [A].\
Easy as pie, right?\
\
\
But remember:\
Mario can't breathe under\
the water! Return to the\
surface for air when the\
Power Meter runs low.\
\
And one last thing: You\
can't open doors that\
are underwater."))

smlua_text_utils_dialog_replace(DIALOG_066,1,5,30,200, ("Mario, it's Peach!\
Please be careful! Bowser\
is so wicked! He will try\
to burn you with his\
horrible flame breath.\
Run around behind and\
grab him by the tail with\
the [B] Button. Once you\
grab hold, swing him\
around in great circles.\
Rotate the Control Stick\
to go faster and faster.\
The faster you swing him,\
the farther he'll fly.\
\
Use the [C] Buttons to look\
around, Mario. You have\
to throw Bowser into one\
of the bombs in the four\
corners.\
Aim well, then press [B]\
again to launch Bowser.\
Good luck, Mario! Our\
fate is in your hands."))

smlua_text_utils_dialog_replace(DIALOG_067,1,5,30,200, ("Tough luck, Mario!\
Princess Toadstool isn't\
here...Gwa ha ha!! Go\
ahead--just try to grab\
me by the tail!\
You'll never be able to\
swing ME around! A wimp\
like you won't throw me\
out of here! Never! Ha!"))

smlua_text_utils_dialog_replace(DIALOG_068,1,5,30,200, ("It's Lethal Lava Land!\
If you catch fire or fall\
into a pool of flames,\
you'll be hopping mad, but\
don't lose your cool.\
You can still control\
Mario--just try to keep\
calm!"))

smlua_text_utils_dialog_replace(DIALOG_069,1,6,30,200, ("Sometimes you'll bump into\
invisible walls at the\
edges of the painting\
worlds. If you hit a wall\
while flying, you'll bounce\
back."))

smlua_text_utils_dialog_replace(DIALOG_070,1,5,30,200, ("1 9 9 5 - 0 7 - 2 9\
d o n j o n  t e s t\
3 4 0 0"))

smlua_text_utils_dialog_replace(DIALOG_071,1,3,30,200, ("Danger Ahead!\
Beware of the strange\
cloud! Don't inhale!\
If you feel faint, run for\
higher ground and fresh\
air!\
Circle: Shelter\
Arrow: Entrance-Exit"))

smlua_text_utils_dialog_replace(DIALOG_072,1,5,30,200, ("High winds ahead!\
Pull your Cap down tight.\
If it blows off, you'll\
have to find it on this\
mountain."))

smlua_text_utils_dialog_replace(DIALOG_073,1,4,95,200, ("Aarrgh! Ahoy, matey. I\
have sunken treasure,\
here, I do.\
\
But to pluck the plunder,\
you must open the\
Treasure Chests in the\
right order.\
What order is that,\
ye say?\
\
\
I'll never tell!\
\
//--The Cap'n"))

smlua_text_utils_dialog_replace(DIALOG_074,1,5,30,200, ("You can grab on to the\
edge of a cliff or ledge\
with your fingertips and\
hang down from it.\
\
To drop from the edge,\
either press the Control\
Stick in the direction of\
Mario's back or press the\
[Z] Button.\
To get up onto the ledge,\
either press Up on the\
Control Stick or press [A]\
as soon as you grab the\
ledge to climb up quickly."))

smlua_text_utils_dialog_replace(DIALOG_075,1,5,30,200, ("Mario!! My castle is in\
great peril. I know that\
Bowser is the cause...and\
I know that only you can\
stop him!\
The doors in the castle\
that have been sealed by\
Bowser can be opened only\
with Star Power.\
\
But there are secret\
paths in the castle,\
paths that Bowser hasn't\
found.\
\
One of those paths is in\
this room, and it holds\
one of the castle's Secret\
Stars!\
\
Find that Secret Star,\
Mario! It will help you\
on your quest. Please,\
Mario, you have to\
help us!\
Retrieve all of the\
Power Stars in the castle\
and free us from this\
awful prison!\
Please!"))

smlua_text_utils_dialog_replace(DIALOG_076,1,6,30,200, ("Thanks to the power of\
the Stars, life is\
returning to the castle.\
Please, Mario, you have\
to give Bowser the boot!\
\
Here, let me tell you a\
little something about the\
castle. In the room with\
the mirrors, look carefully\
for anything that's not\
reflected in the mirror.\
And when you go to the\
water town, you can flood\
it with a high jump into\
the painting. Oh, by the\
way, look what I found!"))

smlua_text_utils_dialog_replace(DIALOG_077,1,2,150,200, ("It is decreed that one\
shall pound the pillars."))

smlua_text_utils_dialog_replace(DIALOG_078,1,5,30,200, ("Break open the Blue Coin\
Block by Pounding the\
Ground with the [Z] Button.\
One Blue Coin is worth\
five Yellow Coins.\
But you have to hurry!\
The coins will disappear\
if you're not quick to\
collect them! Too bad."))

smlua_text_utils_dialog_replace(DIALOG_079,1,4,30,200, ("Owwwuu! Let me go!\
Uukee-kee! I was only\
teasing! Can't you take\
a joke?\
I'll tell you what, let's\
trade. If you let me go,\
I'll give you something\
really good.\
So, how about it?\
\
//Free him/ Hold on"))

smlua_text_utils_dialog_replace(DIALOG_080,1,1,30,200, ("Eeeh hee hee hee!"))

smlua_text_utils_dialog_replace(DIALOG_081,1,4,30,200, ("The mystery is of Wet\
or Dry.\
And where does the\
solution lie?\
The city welcomes visitors\
with the depth they bring\
as they enter."))

smlua_text_utils_dialog_replace(DIALOG_082,1,4,30,200, ("Hold on to your hat! If\
you lose it, you'll be\
injured easily.\
\
If you do lose your Cap,\
you'll have to find it in\
the course where you\
lost it.\
Oh, boy, it's not looking\
good for Peach. She's\
still trapped somewhere\
inside the walls.\
Please, Mario, you have\
to help her! Did you know\
that there are enemy\
worlds inside the walls?\
Yup. It's true. Bowser's\
troops are there, too.\
Oh, here, take this. I've\
been keeping it for you."))

smlua_text_utils_dialog_replace(DIALOG_083,1,6,30,200, ("There's something strange\
about that clock. As you\
jump inside, watch the\
position of the big hand.\
Oh, look what I found!\
Here, Mario, catch!"))

smlua_text_utils_dialog_replace(DIALOG_084,1,3,30,200, ("Yeeoww! Unhand me,\
brute! I'm late, so late,\
I must make haste!\
This shiny thing? Mine!\
It's mine. Finders,\
keepers, losers...\
Late, late, late...\
Ouch! Take it then! A\
gift from Bowser, it was.\
Now let me be! I have a\
date! I cannot be late\
for tea!"))

smlua_text_utils_dialog_replace(DIALOG_085,1,5,30,200, ("You don't stand a ghost\
of a chance in this house.\
If you walk out of here,\
you deserve...\
...a Ghoul Medal..."))

smlua_text_utils_dialog_replace(DIALOG_086,1,3,30,200, ("Running around in circles\
makes some bad guys roll\
their eyes."))

smlua_text_utils_dialog_replace(DIALOG_087,1,4,30,200, ("Santa Claus isn't the only\
one who can go down a\
chimney! Come on in!\
/--Cabin Proprietor"))

smlua_text_utils_dialog_replace(DIALOG_088,1,5,30,200, ("Work Elevator\
For those who get off\
here: Grab the pole to the\
left and slide carefully\
down."))

smlua_text_utils_dialog_replace(DIALOG_089,1,5,95,200, ("Both ways fraught with\
danger! Watch your feet!\
Those who can't do the\
Long Jump, tsk, tsk. Make\
your way to the right.\
Right: Work Elevator\
/// Cloudy Maze\
Left: Black Hole\
///Underground Lake\
\
Red Circle: Elevator 2\
//// Underground Lake\
Arrow: You are here"))

smlua_text_utils_dialog_replace(DIALOG_090,1,6,30,200, ("b w a  h a  h a  h a !\
y o u ' v e  s t e p p e d\
r i g h t  i n t o\
m y  t r a p ,  j u s t\
a s  I  k n e w\
y o u  w o u l d !\
I  w a r n  y o u ,\
『 f r i e n d , 』\
w a t c h  y o u r\
s t e p !"))

smlua_text_utils_dialog_replace(DIALOG_091,2,2,30,200, ("Danger!\
Strong Gusts!\
But the wind makes a\
comfy ride."))

smlua_text_utils_dialog_replace(DIALOG_092,1,5,30,200, ("p e s t e r i n g \
m e  a g a i n , a r e\
y o u ,  m a r i o ? \
c a n ' t  y o u  s e e \
t h a t   I ' m  \
h a v i n g  a  m e r r y\
l i t t l e  t i m e , \
m a k i n g  \
m i s c h i e f  w i t h \
m y  m i n i o n s ?\
n o w ,  r e t u r n \
t h o s e  s t a r s !\
m y  t r o o p s \
i n  t h e   w a l l s\
n e e d  t h e m !"))

smlua_text_utils_dialog_replace(DIALOG_093,1,5,30,200, ("m a r i o !  y o u  \
a g a i n ! \
I ' v e  b e e n \
l o o k i n g  f o r \
s o m e t h i n g\
t o  f r y  wi t h \
m y  f i r e \
b r e a t h !\
y o u r  f r i e n d s \
a r e  a l l \
t r a p p e d \
wi t h i n  t h e i r\
wa l l s ...\
j u s t  l i k e  y o u .\
t h e  o n e \
c o n t r o l l i n g \
h i m . . .\
y o u ' l l  n e v e r \
s e e  t h e \
p r i n c e s s  \
a g a i n \
 b wa  h a  h a  h a !"))

smlua_text_utils_dialog_replace(DIALOG_094,1,4,30,200, ("Get a good run up the\
slope! Do you remember\
the Long Jump? Run, press\
[Z], then jump!"))

smlua_text_utils_dialog_replace(DIALOG_095,1,4,30,200, ("To read a sign, stand in\
front of it and press [B],\
like you did just now.\
\
When you want to talk to\
a Koopa Troopa or other\
animal, stand right in\
front of it.\
Please recover the Stars\
that were stolen by\
Bowser in this course."))

smlua_text_utils_dialog_replace(DIALOG_096,1,4,30,200, ("The path is narrow here.\
Easy does it! No one is\
allowed on top of the\
mountain!\
And if you know what's\
good for you, you won't\
wake anyone who's\
sleeping!\
Move slowly,\
tread lightly."))

smlua_text_utils_dialog_replace(DIALOG_097,1,5,30,200, ("Don't be a pushover!\
If anyone tries to shove\
you around, push back!\
It's one-on-one, with a\
fiery finish for the loser!"))

smlua_text_utils_dialog_replace(DIALOG_098,1,2,95,200, ("Come on in here...\
...heh, heh, heh..."))

smlua_text_utils_dialog_replace(DIALOG_099,1,5,95,200, ("Eh he he...\
You're mine, now, hee hee!\
I'll pass right through\
this wall. Can you do\
that? Heh, heh, heh!"))

smlua_text_utils_dialog_replace(DIALOG_100,1,3,95,200, ("Ukkiki...Wakkiki...kee kee!\
Ha! I snagged it!\
It's mine! Heeheeheeee!"))

smlua_text_utils_dialog_replace(DIALOG_101,1,3,95,200, ("Ackk! Let...go...\
You're...choking...me...\
Cough...I've been framed!\
This Cap? Oh, all right,\
take it. It's a cool Cap,\
but I'll give it back.\
I think it looks better on\
me than it does on you,\
though! Eeeee! Kee keee!"))

smlua_text_utils_dialog_replace(DIALOG_102,1,5,30,200, ("Pssst! The Boos are super\
shy. If you look them\
in the eyes, they fade\
away, but if you turn\
your back, they reappear.\
It's no use trying to hit\
them when they're fading\
away. Instead, sneak up\
behind them and punch."))

smlua_text_utils_dialog_replace(DIALOG_103,1,4,95,200, ("Upon four towers\
one must alight...\
Then at the peak\
shall shine the light..."))

smlua_text_utils_dialog_replace(DIALOG_104,1,5,30,200, ("The shadowy star in front\
of you is a 『Star\
Marker.』 When you collect\
all 8 Red Coins, the Star\
will appear here."))

smlua_text_utils_dialog_replace(DIALOG_105,1,3,95,200, ("Ready for blastoff! Come\
on, hop into the cannon!\
\
You can reach the Star on\
the floating island by\
using the four cannons.\
Use the Control Stick to\
aim, then press [A] to fire.\
\
If you're handy, you can\
grab on to trees or poles\
to land."))

smlua_text_utils_dialog_replace(DIALOG_106,1,2,95,200, ("Ready for blastoff! Come\
on, hop into the cannon!"))

smlua_text_utils_dialog_replace(DIALOG_107,1,3,95,200, ("Ghosts...\
...don't...\
...DIE!\
Heh, heh, heh!\
Can you get out of here...\
...alive?"))

smlua_text_utils_dialog_replace(DIALOG_108,1,2,95,200, ("Boooooo-m! Here comes\
the master of mischief,\
the tower of terror,\
the Big Boo!\
Ka ha ha ha..."))

smlua_text_utils_dialog_replace(DIALOG_109,1,4,95,200, ("Ooooo Nooooo!\
Talk about out-of-body\
experiences--my body\
has melted away!\
Have you run in to any\
headhunters lately??\
I could sure use a new\
body!\
Brrr! My face might\
freeze like this!"))

smlua_text_utils_dialog_replace(DIALOG_110,1,5,95,200, ("I need a good head on my\
shoulders. Do you know of\
anybody in need of a good\
body? Please! I'll follow\
you if you do!"))

smlua_text_utils_dialog_replace(DIALOG_111,1,4,95,200, ("Perfect! What a great\
new body! Here--this is a\
present for you. It's sure\
to warm you up."))

smlua_text_utils_dialog_replace(DIALOG_112,1,4,30,200, ("( p l a c e h o l d e r )"))

smlua_text_utils_dialog_replace(DIALOG_113,1,6,30,200, ("There are special Caps in\
the red, green and blue\
blocks. Step on the\
switches in the hidden\
courses to activate the\
Cap Blocks."))

smlua_text_utils_dialog_replace(DIALOG_114,1,5,95,200, ("It makes me so mad! We\
build your houses, your\
castles. We pave your\
roads, and still you\
walk all over us.\
Do you ever say thank\
you? No! Well, you're not\
going to wipe your feet\
on me! I think I'll crush\
you just for fun!\
Do you have a problem\
with that? Just try to\
pound me, wimp! Ha!"))

smlua_text_utils_dialog_replace(DIALOG_115,1,5,95,200, ("No! Crushed again!\
I'm just a stepping stone,\
after all. I won't gravel,\
er, grovel. Here, you win.\
Take this with you!"))

smlua_text_utils_dialog_replace(DIALOG_116,1,5,95,200, ("Whaaa....Whaaat?\
Can it be that a\
pipsqueak like you has\
defused the Bob-omb\
king????\
You might be fast enough\
to ground me, but you'll\
have to pick up the pace\
if you want to take King\
Bowser by the tail.\
Methinks my troops could\
learn a lesson from you!\
Here is your Star, as I\
promised, Mario.\
\
If you want to see me\
again, select this Star\
from the menu. For now,\
farewell."))

smlua_text_utils_dialog_replace(DIALOG_117,1,1,95,200, ("Who...walk...here?\
Who...break...seal?\
Wake..ancient..ones?\
We no like light...\
Rrrrummbbble...\
We no like...intruders!\
Now battle...\
...hand...\
...to...\
...hand!"))

smlua_text_utils_dialog_replace(DIALOG_118,1,6,95,200, ("Grrrrumbbble!\
What...happen?\
We...crushed like pebble.\
You so strong!\
You rule ancient pyramid!\
For today...\
Now, take Star of Power.\
We...sleep...darkness."))

smlua_text_utils_dialog_replace(DIALOG_119,1,6,30,200, ("y o u ' l l  p a y \
f o r  t h i s ...\
l a t e r !"))

smlua_text_utils_dialog_replace(DIALOG_120,1,4,30,200, ("y o u ' l l  p a y \
f o r  t h i s ...\
l a t e r !"))

smlua_text_utils_dialog_replace(DIALOG_121,1,5,30,200, ("y o u ' l l  p a y \
f o r  t h i s ...\
l a t e r !"))

smlua_text_utils_dialog_replace(DIALOG_122,1,4,30,200, ("The Black Hole\
Right: Work Elevator\
/// Cloudy Maze\
Left: Underground Lake"))

smlua_text_utils_dialog_replace(DIALOG_123,1,4,30,200, ("Metal Cavern\
Right: To Waterfall\
Left: Metal Cap Switch"))

smlua_text_utils_dialog_replace(DIALOG_124,1,4,30,200, ("Work Elevator\
Danger!!\
Read instructions\
thoroughly!\
Elevator continues in the\
direction of the arrow\
activated."))

smlua_text_utils_dialog_replace(DIALOG_125,1,3,30,200, ("Hazy Maze-Exit\
Danger! Closed.\
Turn back now."))

smlua_text_utils_dialog_replace(DIALOG_126,2,3,30,200, ("Up: Black Hole\
Right: Work Elevator\
/// Hazy Maze"))

smlua_text_utils_dialog_replace(DIALOG_127,3,4,30,200, ("Underground Lake\
Right: Metal Cave\
Left: Abandoned Mine\
///(Closed)\
A gentle sea dragon lives\
here. Pound on his back to\
make him lower his head.\
Don't become his lunch."))

smlua_text_utils_dialog_replace(DIALOG_128,1,4,95,200, ("You must fight with\
honor! It is against the\
royal rules to throw the\
king out of the ring!"))

smlua_text_utils_dialog_replace(DIALOG_129,1,5,30,200, ("Welcome to the Vanish\
Cap Switch Course! All of\
the blue blocks you find\
will become solid once you\
step on the Cap Switch.\
You'll disappear when you\
put on the Vanish Cap, so\
you'll be able to elude\
enemies and walk through\
many things. Try it out!"))

smlua_text_utils_dialog_replace(DIALOG_130,1,5,30,200, ("Welcome to the Metal Cap\
Switch Course! Once you\
step on the Cap Switch,\
the green blocks will\
become solid.\
When you turn your body\
into metal with the Metal\
Cap, you can walk\
underwater! Try it!"))

smlua_text_utils_dialog_replace(DIALOG_131,1,5,30,200, ("Welcome to the Wing Cap\
Course! Step on the red\
switch at the top of the\
tower, in the center of\
the rainbow ring.\
When you trigger the\
switch, all of the red\
blocks you find will\
become solid.\
\
Try out the Wing Cap! Do\
the Triple Jump to take\
off and press [Z] to land.\
\
\
Pull back on the Control\
Stick to go up and push\
forward to nose down,\
just as you would when\
flying an airplane."))

smlua_text_utils_dialog_replace(DIALOG_132,1,4,30,200, ("Whoa, Mario, pal, you\
aren't trying to cheat,\
are you? Shortcuts aren't\
allowed.\
Now, I know that you\
know better. You're\
disqualified! Next time,\
play fair!"))

smlua_text_utils_dialog_replace(DIALOG_133,1,6,30,200, ("Am I glad to see you! The\
Princess...and I...and,\
well, everybody...we're all\
trapped inside the castle\
walls.\
\
Bowser has stolen the\
castle's Stars, and he's\
using their power to\
create his own world in\
the paintings and walls.\
\
Please recover the Power\
Stars! As you find them,\
you can use their power\
to open the doors that\
Bowser has sealed.\
\
There are four rooms on\
the first floor. Start in\
the one with the painting\
of Bob-omb inside. It's\
the only room that Bowser\
hasn't sealed.\
When you collect eight\
Power Stars, you'll be\
able to open the door\
with the big star. The\
Princess must be inside!"))

smlua_text_utils_dialog_replace(DIALOG_134,1,5,30,200, ("The names of the Stars\
are also hints for\
finding them. They are\
displayed at the beginning\
of each course.\
You can collect the Stars\
in any order. You won't\
find some Stars, enemies\
or items unless you select\
a specific Star.\
After you collect some\
Stars, you can try\
another course.\
We're all waiting for\
your help!"))

smlua_text_utils_dialog_replace(DIALOG_135,1,5,30,200, ("It was Bowser who stole\
the Stars. I saw him with\
my own eyes!\
\
\
He's hidden six Stars in\
each course, but you\
won't find all of them in\
some courses until you\
press the Cap Switches.\
The Stars you've found\
will show on each course's\
starting screen.\
\
\
If you want to see some\
of the enemies you've\
already defeated, select\
the Stars you recovered\
from them."))

smlua_text_utils_dialog_replace(DIALOG_136,1,6,30,200, ("Wow! You've already\
recovered that many\
Stars? Way to go, Mario!\
I'll bet you'll have us out\
of here in no time!\
\
Be careful, though.\
Bowser and his band\
wrote the book on 『bad.』\
Take my advice: When you\
need to recover from\
injuries, collect coins.\
Yellow Coins refill one\
piece of the Power Meter,\
Red Coins refill two\
pieces, and Blue Coins\
refill five.\
\
To make Blue Coins\
appear, pound on Blue\
Coin Blocks.\
\
\
\
Also, if you fall from\
high places, you'll\
minimize damage if you\
Pound the Ground as you\
land."))

smlua_text_utils_dialog_replace(DIALOG_137,1,6,30,200, ("Thanks, Mario! The castle\
is recovering its energy\
as you retrieve Power\
Stars, and you've chased\
Bowser right out of here,\
on to some area ahead.\
Oh, by the by, are you\
collecting coins? Special\
Stars appear when you\
collect 100 coins in each\
of the 15 courses!"))

smlua_text_utils_dialog_replace(DIALOG_138,1,3,30,200, ("Down: Underground Lake\
Left: Black Hole\
Right: Hazy Maze (Closed)"))

smlua_text_utils_dialog_replace(DIALOG_139,1,6,30,200, ("Above: Automatic Elevator\
Elevator begins\
automatically and follows\
pre-set course.\
It disappears\
automatically, too."))

smlua_text_utils_dialog_replace(DIALOG_140,1,6,30,200, ("Elevator Area\
Right: Hazy Maze\
/// Entrance\
Left: Black Hole\
///Elevator 1\
Arrow: You are here"))

smlua_text_utils_dialog_replace(DIALOG_141,1,5,150,200, ("y o u ' v e  \
r e c o v e r e d  o n e \
o f  t h e  s t o l e n \
p o w e r  s t a r s !"))

smlua_text_utils_dialog_replace(DIALOG_142,1,5,150,200, ("y o u ' v e  \
r e c o v e r e d  \
t h r e e \
o f  t h e  s t o l e n \
p o w e r  s t a r s !"))

smlua_text_utils_dialog_replace(DIALOG_143,1,6,150,200, ("y o u ' v e  \
r e c o v e r e d  \
e i g h t \
o f  t h e  s t o l e n \
p o w e r  s t a r s !"))

smlua_text_utils_dialog_replace(DIALOG_144,1,6,150,200, ("y o u ' v e  \
r e c o v e r e d  30 \
o f  t h e  s t o l e n \
p o w e r  s t a r s !"))

smlua_text_utils_dialog_replace(DIALOG_145,1,6,150,200, ("y o u ' v e  \
r e c o v e r e d  50 \
o f  t h e  s t o l e n \
p o w e r  s t a r s !"))

smlua_text_utils_dialog_replace(DIALOG_146,1,6,150,200, ("y o u ' v e  \
r e c o v e r e d  70\
o f  t h e  s t o l e n \
p o w e r  s t a r s !"))

smlua_text_utils_dialog_replace(DIALOG_147,1,2,30,200, ("1 9 9 4 - 1 2 - 3 0\
t e s t  l e v e l"))

smlua_text_utils_dialog_replace(DIALOG_148,1,6,30,200, ("Snowman Mountain ahead.\
Keep out! And don't try\
the Triple Jump over the\
ice block shooter.\
\
\
If you fall into the\
freezing pond, your power\
decreases quickly, and\
you won't recover\
automatically.\
//--The Snowman"))

smlua_text_utils_dialog_replace(DIALOG_149,1,3,30,200, ("1 9 9 5 - 2 - 1 4\
c a s t l e  g r o u n d s\
\
m o d e l  b y :\
u 6 4 d a\
\
m o d i f i e d  b y:\
m e\
a l i t t l e b i t 6 4"))

smlua_text_utils_dialog_replace(DIALOG_150,1,5,30,200, ("w a a a a ! \
y o u ' v e \
f l o o d e d  m y\
h o u s e ! \
w h - w h y ?? \
e v e r y t h i n g ' s \
b e e n  g o i n g \
w r o n g  e v e r \
s i n c e  I  g o t \
t h i s  s t a r ..."))

smlua_text_utils_dialog_replace(DIALOG_151,1,4,30,200, ("y o u  a r e  t h e \
o n e  t h a t  \
f l o o d e d  m y\
h o u s e ! \
w h - w h y ?? \
e v e r y t h i n g ' s \
b e e n  g o i n g \
w r o n g  e v e r \
s i n c e  I  g o t \
t h i s  s t a r ...\
n o w  I ' m \
r e a l l y  m a d !\
w a a a a a a a a ! !"))

smlua_text_utils_dialog_replace(DIALOG_152,1,3,30,200, ("o w w c h ! \
o k a y , I  g i v e.\
t a k e  t h i s\
s t a r !\
i  d o n ' t \
r e a l l y  n e e d \
i t  a n y m o r e ...,\
p l e a s e , c o m e\
b a c k  a n d \
v i s i t  a n y t i m e ."))

smlua_text_utils_dialog_replace(DIALOG_153,1,4,30,200, ("Hey! Who's there?\
What's climbing on me?\
Is it an ice ant?\
A snow flea?\
Whatever it is, it's\
bugging me! I think I'll\
blow it away!"))

smlua_text_utils_dialog_replace(DIALOG_154,1,5,30,200, ("Hold on to your hat! If\
you lose it, you'll be\
easily injured. If you\
lose it, look for it in the\
course where you lost it.\
Speaking of lost, the\
Princess is still stuck in\
the walls somewhere.\
Please help, Mario!\
\
Oh, you know that there\
are secret worlds in the\
walls as well as in the\
paintings, right?"))

smlua_text_utils_dialog_replace(DIALOG_155,1,6,30,200, ("Thanks to the power of\
the Stars, life is\
returning to the castle.\
Please, Mario, you have\
to give Bowser the boot!\
\
Here, let me tell you a\
little something about the\
castle. In the room with\
the mirrors, look carefully\
for anything that's not\
reflected in the mirror.\
And when you go to the\
water town, you can flood\
it with a high jump into\
the painting."))

smlua_text_utils_dialog_replace(DIALOG_156,1,5,30,200, ("The world inside the\
clock is so strange!\
When you jump inside,\
watch the position of\
the big hand!"))

smlua_text_utils_dialog_replace(DIALOG_157,1,5,30,200, ("Watch out! Don't let\
yourself be swallowed by\
quicksand.\
\
\
If you sink into the sand,\
you won't be able to\
jump, and if your head\
goes under, you'll be\
smothered.\
The dark areas are\
bottomless pits."))

smlua_text_utils_dialog_replace(DIALOG_158,1,6,30,200, ("1. If you jump repeatedly\
and time it right, you'll\
jump higher and higher.\
If you run really fast and\
time three jumps right,\
you can do a Triple Jump.\
2. Jump into a solid wall,\
then jump again when you\
hit the wall. You can\
bounce to a higher level\
using this Wall Kick."))

smlua_text_utils_dialog_replace(DIALOG_159,1,6,30,200, ("( p l a c e h o l d e r )"))

smlua_text_utils_dialog_replace(DIALOG_160,1,4,30,200, ("Press [B] while running\
fast to do a Body Slide\
attack. To stand while\
sliding, press [A] or [B]."))

smlua_text_utils_dialog_replace(DIALOG_161,1,4,30,200, ("Mario!!!\
It that really you???\
It has been so long since\
our last adventure!\
They told me that I might\
see you if I waited here,\
but I'd just about given\
up hope!\
Is it true? Have you\
really beaten Bowser? And\
restored the Stars to the\
castle?\
And saved the Princess?\
I knew you could do it!\
Now I have a very special\
message for you.\
『Thanks for playing Super\
Mario 64! This is the\
end of the game, but not\
the end of the fun.\
We want you to keep on\
playing, so we have a\
little something for you.\
We hope that you like it!\
Enjoy!!!』\
\
The Super Mario 64 Team"))

smlua_text_utils_dialog_replace(DIALOG_162,1,4,30,200, ("No, no, no! Not you\
again! I'm in a great\
hurry, can't you see?\
\
I've no time to squabble\
over Stars. Here, have it.\
I never meant to hide it\
from you...\
It's just that I'm in such\
a rush. That's it, that's\
all. Now, I must be off.\
Owww! Let me go!"))

smlua_text_utils_dialog_replace(DIALOG_163,1,5,30,200, ("Noooo! You've really\
beaten me this time,\
Mario! I can't stand\
losing to you!\
\
My troops...worthless!\
They've turned over all\
the Power Stars! What?!\
There are 120 in all???\
\
Amazing! There were some\
in the castle that I\
missed??!!\
\
\
Now I see peace\
returning to the world...\
Oooo! I really hate that!\
I can't watch--\
I'm outta here!\
Just you wait until next\
time. Until then, keep\
that Control Stick\
smokin'!\
Buwaa ha ha!"))

smlua_text_utils_dialog_replace(DIALOG_164,1,4,30,200, ("Mario! What's up, pal?\
I haven't been on the\
slide lately, so I'm out\
of shape.\
Still, I'm always up for a\
good race, especially\
against an old sleddin'\
buddy.\
Whaddya say?\
Ready...set...\
\
//Go//// Don't Go"))

smlua_text_utils_dialog_replace(DIALOG_165,1,5,30,200, ("I take no responsibility\
whatsoever for those who\
get dizzy and pass out\
from running around\
this post."))

smlua_text_utils_dialog_replace(DIALOG_166,1,4,30,200, ("I'll be back soon.\
I'm out training now,\
so come back later.\
//--Koopa the Quick"))

smlua_text_utils_dialog_replace(DIALOG_167,1,4,30,200, ("Princess Toadstool's\
castle is just ahead.\
\
\
Press [A] to jump, [Z] to\
crouch, and [B] to punch,\
read a sign, or grab\
something.\
Press [B] again to throw\
something you're holding."))

smlua_text_utils_dialog_replace(DIALOG_168,1,5,30,200, ("h e y !  k n o c k  \
i t  o f f !"))

smlua_text_utils_dialog_replace(DIALOG_169,1,4,30,200, ("Keep out!\
That means you!\
Arrgghh!\
\
Anyone entering this cave\
without permission will\
meet certain disaster."))

