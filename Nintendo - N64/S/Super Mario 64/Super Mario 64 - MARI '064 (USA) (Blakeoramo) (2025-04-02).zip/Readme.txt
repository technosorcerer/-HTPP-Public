MARI '064 By Blakeoramo

MAKE SURE TO PLAY ON A ACCURATE EMULATOR AND SET THE WIDESCREEN MODE TO STRETCHED 
(THIS GAME ONLY SUPPORTS 16:9 NOT 4:3)

Happy April Fools! (I know it's like less than half an hour before midnight when I upload this)