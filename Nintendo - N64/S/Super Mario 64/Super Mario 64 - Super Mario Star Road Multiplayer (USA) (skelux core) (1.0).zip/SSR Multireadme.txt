---Star Road Multiplayer 1.0, created by Skelux---

If you downloaded the PPF, you must first follow these instructions:
1. Obtain a Super Mario 64 rom
2. Extend it with 'M64 ROM Extender 1.3b' in the 'Patching Tools' folder
3. Drag the rom over 'rom_expand.exe' in the 'Patching Tools' folder
4. Patch "SMSR Multiplayer 1.0.ppf" to it using "PPF-O-MATIC 3.0" in the 'Patching Tools' folder

I recommend playing with Project 64 V0.40 , as later versions of Project 64 will crash randomly.
You will first need to go into "Options" then "Settings" then change the rom directory to where
the SMSR Multiplayer rom is located. To play online, open Project64k.exe and go into "File" then 
"Start Netplay...". Join any server and right-click below the chat window to host a game that 
your friend can join. 

After opening the NetPlay window, set your connection speed to 'Good', as higher settings will cause lag.
For a more reliable game, go into "Options" then "Configure Audio Plugin" and tick "Sync game to Audio". 

To set up the controls, go into "Options" then "Configure Controller Plugin..." and go to the "Player 2" tab.
While playing the game, you can hold 'R' to lock the camera onto your player. Also, since PJ64k does
not save while playing online, you can press 'Z' at the file select screen to unlock all levels.

Player 3 & 4 are now able to interact with the objects Player 1 & 2 were last standing on respectively.
They can do this be pressing the D-Pad buttons.

~Skelux

---Changes---
1.0: 
-First release, modified version of SM64 Multiplayer 1.1

FAQ:
Q. Where can I find your other work?
A. https://www.youtube.com/user/Skelux/

Q. Can I play this in Wii 64?
A. Yes, but a lot of courses will lag.

Q. I am trying to earn one of the stars which you get from winning a race, but my opponent got stuck.
A. Try one of the following: Leave and come back to that star later, reset the game, or complete a different race before coming back to it.

Q. I was playing Colorful Coral Caverns with a friend and the game froze, can this be prevented?
A. Because of issues in the game memory, this course (possibly others) will freeze if the players walk too far apart.

---Palette Codes---
These are not finished, I plan to give both players a unique
palette eventually.

P1 Overalls:
8107EC00 RRGG
8107EC02 BB00
8107EC08 RRGG
8107EC0A BB00

P1 Shirt & Hat + P2 Shirt & Shoes:
8107EC18 RRGG
8107EC1A BB00
8107EC20 RRGG
8107EC22 BB00

P1 Shoes:
8107EC48 RRGG
8107EC4A BB00
8107EC50 RRGG
8107EC52 BB00

P1 Skin & P2 Skin:
8107EC60 RRGG
8107EC62 BB00
8107EC68 RRGG
8107EC6A BB00