 _____                       ____ _   _ _   _ _____ 
|_   _|__  __ _ _ __ ___    / ___| | | | \ | |_   _|
  | |/ _ \/ _` | '_ ` _ \  | |   | | | |  \| | | |  
  | |  __/ (_| | | | | | | | |___| |_| | |\  | | |  
  |_|\___|\__,_|_| |_| |_|  \____|\___/|_| \_| |_|  

so... you've decided to install this hack... well, there's two versions. There is the streamsafe version and the uncensored version. The uncensored version has the original version of the slide level and the wing cap level as well as the first bowser stage fully uncensored. this hack has 31 achievements which are in another included text file. it also has a main game and a post game. have fun!

.__                      __                         __         .__     
|  |__   ______  _  __ _/  |_  ____   ___________ _/  |_  ____ |  |__  
|  |  \ /  _ \ \/ \/ / \   __\/  _ \  \____ \__  \\   __\/ ___\|  |  \ 
|   Y  (  <_> )     /   |  | (  <_> ) |  |_> > __ \|  | \  \___|   Y  \
|___|  /\____/ \/\_/    |__|  \____/  |   __(____  /__|  \___  >___|  /
     \/                               |__|       \/          \/     \/  

step 1: install flips.exe
step 2: click 'apply patch'
step 3: select the version of the game you wish to play on
step 4: select your legally obtained US ROM of Super Mario 64
step 5: save the newly created ROM file
step 6: launch the rom in project64