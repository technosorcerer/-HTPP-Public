Super Mario 64 "Smoke Fix"

this is a set of three BPS patches to fix Mario's "on fire" texture in SM64. thanks to the recent decompilation efforts, it's now known that this texture is displayed in the wrong format by the game, resulting in black garbage pixels. since video game smoke of this era was often depicted with black garbage pixels, the mistake went unnoticed for over two decades. this patch corrects the error by displaying the texture correctly as proper transparent smoke. it does not add any new art; the texture has been inside the ROM all along.

simply apply the patch you want to the respective version of the game. since the Shindou Edition has not yet been decompiled at the time of writing, no patch is available for it.

if you are decompiling the game, you can make this change very easily without using patches: 
-open /actors/burn_smoke/model.inc.c
-on line 47, change the reference "G_IM_FMT_RGBA" to "G_IM_FMT_IA"

at build time, this will compile the texture into IA16 format (correct) instead of RGBA16 (incorrect).

zoinknoise
17 march 2020

O2 compressed the US AND Japanese versions to reduce their lag.

Nintendo 64 Wizard
18 March 2020