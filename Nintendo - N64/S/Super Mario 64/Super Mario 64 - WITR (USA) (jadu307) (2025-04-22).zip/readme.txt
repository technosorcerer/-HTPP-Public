	WITR
--------------------
Sorry that this is so long. I don't expect a lot of you to read this because you're too eager to play the same 5 riveting levels that have been seen in every other hack.

WHY THE HACK IS NAMED THE WAY IT IS:
WITR = Where Is The ROM (stupid injoke GIF from like 4 years ago)

CREDITS:
Dudaw - Used a ton of the ASM he released.
Emmy - Rocky Mountain painting graphic
XKoop7321 - Occasional ASM help
dualsh0x/duskewl/jadu307 - Did everything else

By the way, I recommend you use PJ64. I know it sucks but you kinda need it for changing the counter factor in the ROM settings.

STUFF ABOUT THE PROJECT:
Project started on a whim late August 2023, typically I'm more used to the SM64 decompilation (which you should really use for hacks that overhaul large amounts of code, by the way) so I wanted to challenge myself and see how well I could make a recreation using only binary tools. On top of that, I also wanted to challenge myself to not use any leaked assets, but that's a really stupid idea and just sort of wasted my time instead. Nonetheless, I was too lazy to turn some assets into their actual leaked counterparts, so you're dealing with crappy remakes instead in this.

Oh yeah, you can also find attached more text files detailing my plans for the hack before I completely lost interest. Part of me doesn't wanna say it's outright cancelled, however, because there probably is a really miniscule chance I'll pick it up if I have more than enough free time and my original projects bore me to death. 

BUGS/THINGS THAT ANNOY ME AND WILL ANNOY YOU TOO:
- The castle lags way too much. Set the counter factor to 1 (2 by default) in the ROM settings tab to stop it. The camera in the castle is also pretty broken and gets all ugly when you enter and leave a room.
- Objects that spawn stars don't work properly. The behavior crashes the game so it's been replaced with the normal star code, meaning it spawns exactly where the object is. Not a big deal for the penguin star.
- The Big Bully does not spawn a star, because I was an idiot 2 years ago.
- People have complained about the hack not working unless they use 1.6? Not sure why, it works fine for me using the GlideN64 graphics plugins. 
- The star camera code isn't perfect, so if you keep moving the camera while grabbing a star, Mario will end up facing the wrong way.
- The WF tower's platforms don't have the right collision. 

Features this hack has that probably not a lot of other ones have:
- Fully functional paintings for the two floors
- Better code for the 'grabbing a star' camera than a lot of other hacks (It actually has code to re-focus on Mario so he isn't offcentered)
- Unique textbox font inspired by the JP SM64 alphabet
- Some sound effects are higher quality like the beta (painting sparkles)
- LLL is a fusion between all its versions (never got to doing this for other maps)
- ROM protection that someone will probably break soon anyway