LinCrash strikes back again with another green comet madness! 
Time to put to shame those who think kaizo green comet hacks are hip this year!

This is Koopa Power: Green Comet! 70 green stars with some technical twists and turns.


Dedicated to AndrewSM64, current runner of Koopa Power and WR holder #TeamCraftW

And happy Bleh-day to Ozsef, biggest green comet addict and a great fella. 
Enjoy your gift, my A! suh buh duh nuh yuh


Credits
=======
Original hack by VenusFeuerFalle
Created and edited by LinCrash
Inspiration: Arthurtilly, Ozsef, and the whole RHDC squad