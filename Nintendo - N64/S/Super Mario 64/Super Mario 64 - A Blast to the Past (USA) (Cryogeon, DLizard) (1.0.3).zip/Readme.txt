Thank you so much for checking out the Readme of
SM64 Romhacking: Blast to the Past

This hack is purely an object edit made by: Cryogeon and DLizard
This is to show on how much improvement has been made over the
years ~10 years ago.

Containing a whole 70 stars. There's no specific reward for collecting all 70...
except bragging rights I suppose. Intended Star Count is: 45

The object edits are from older levels past 10 years
Original Creators go as followed and those who have made the object edit.
Course 1: Lugmillord - Cryogeon
Course 2: Skelux - DLizard
Course 3: SomeRussianMarioDude - Cryogeon
Course 4: sm64pie/SM64ShiningStars - Cryogeon
Course 5: Midoji - DLizard
Course 6: Apoieus - Cryogeon
Course 7: Brodute - DLizard
Course 8: Skillux - Cryogeon


Caps: DobieMeltfire - DLizard
Bowser 1: sm64pie/SM64ShiningStars - Cryogeon
Bowser 2: Kampel125 - Cryogeon


Music:
Overworld 1: Kougahei
Overworld 2: Rambi_Rampage

Course 1: Pablo's Corner
Course 2: scuttlebugraiser
Course 3: aglab2
Course 4: Blocky
Course 5: ???
Course 6: Apoieus
Course 7: ???
Course 8: EDark

Bowser 1: Bubby64
Bowser 2: ???

Caps: ???
The End: Mosky2000