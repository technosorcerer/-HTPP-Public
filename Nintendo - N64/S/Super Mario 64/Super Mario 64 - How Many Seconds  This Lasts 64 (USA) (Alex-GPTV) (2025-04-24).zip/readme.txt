"How Many Seconds This Lasts: 64", created by Alex_GPTV

Full instructions for PATCHING, emulator settings and CONFIGURING UP TO 4 CONTROLLERS is in the release video on this hack's romhacking.com page.

---------------BPS instructions---------------

- Obtain a Super Mario 64 ROM

- Open FloatingIPS

- When the tool window shows up, click on "Apply Patch"

- Select the "How Many Seconds This Lasts: 64.bps" patch when it asks you to

- Then select the regular Super Mario 64 ROM file when it asks you to

- After both are selected, save it by giving it a new name ("How Many Seconds This Lasts: 64.z64" for example)

- When it's done, the new patched file is now created and you can exit the tool

Notes:

This is made for Parallel Launcher with the graphics plugin "GlideN64"

  CREDITS:
- ROM hack by Alex_GPTV
- Some code, plus BIG advice and help with using texture combiners, Blender, and coding by Dorrieal
- Modding tools and Hacker Mario 64 codebase by the SM64 modding community
- Original game by Nintendo
Music:
Level music: Beach Happening by Heimo Rhonda, remixed by Alex GPTV
- End songs from Toki Tori 2 (SonicPicnic)

If you have any questions or want to chat, you can join this Discord: https://discord.gg/bWMuMD6

~Alex_GPTV