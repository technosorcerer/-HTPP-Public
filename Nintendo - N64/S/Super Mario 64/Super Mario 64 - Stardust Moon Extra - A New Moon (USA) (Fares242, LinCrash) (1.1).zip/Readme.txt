SUPER MARIO STARDUST MOON [EXTRA: A NEW MOON]

Created and edited by LinCrash
Original hack created by Fares242 [via base v2.4+ update]

=====

CREDITS:

Thanks to:
KingToad - for playtesting (v1.0 release)
DJ_Tala - for extra help (custom star model, CIC error fix)

=====

There are 70 Moon Crystals in total. A Star Display layout is included to track each in every course.

This is the Green Comet version, but I decided to keep the "Extra" part of the title because of reasons, and also a major issue 
that I had with the Moon Crystal model that was solved just then. 

If you're stuck looking or collecting any of these, go read signs or talk to NPCs you can find.
But if you do NOT want to, well... feel free, but shame on YOU for ignoring my advice.

So with that being said, thanks for playing and enjoy.

=====

[v1.1]

- [NEW!] Moon Crystal model update (uncollected/color code, render)
- Updated Display layout
- Updated textboxes w/ slight changes
- Added fire spitters + new hint in C3
- Stardust & Moon Crystal textures changed to green in OW, C1, C4 and C13


[v1.0.1]

- Added 2 new hint signs in C12 and C15
- Removed leftover Moon Crystal in C10
- Fixed Bob-omb textbox in C8


[v1.0]

Initial release