If by any chance you have the ROMs or patches for versions V1.5, V2.0, or V2.a, please let me know by leaving a comment on this video:
https://youtu.be/sNVIES8Q6hw?si=QVK27aqQ3yJeDKYE

Here’s the Archive.org link to the original .zip file of version V1.c:
https://web.archive.org/web/20201012234909/https://f1868cda-a-62cb3a1a-s-sites.googlegroups.com/site/awesomelukeystudios/hacks/SuperMario64SpookyWorldsV1c.zip?attachauth=ANoY7cqS-T338uoMTqaIFS8W2qxxCggWY3Joa9A1Lmk5sesVL_VapqbHmvPcqnft2eC8ED9cDUIbnuetDChhkxzNThCh0It-Vd19mmJe9RRR61oWFNhzo2mKBb00bxJ9YiogkpEpMOI16Nd0xKgNp-c1fizJrXYbqtlHyute2JYY_lphomd98L2xHChuLV9a1YVG0JHLTiUzI6hlxwmr4oVNGCQ1Z2m3nlUpNEYx4wkft26i54oLgR9k459JSa4u02w4cYtVjQ0q&attredirects=0

If you found this useful, consider subscribing to my YouTube channel!