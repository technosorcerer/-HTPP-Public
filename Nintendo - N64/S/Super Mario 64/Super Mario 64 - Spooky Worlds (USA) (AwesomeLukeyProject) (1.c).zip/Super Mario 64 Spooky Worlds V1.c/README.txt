Thank you for checking the README. This will show you what
You need to do so this hack will work.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Part I , Starting Off.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

1. First. You are going to need to drag out the Rom Expander
   & Drag out the patch.

2. Now , Drag out the Clean Extended Rom That came in the
   package.

3. Now , once you have everything situated , Drag the Clean
   Extended Rom inside the Rom_Expander Program.

4. Wait a couple seconds for the Expanding to finish & when
   Done , The Game size should be 49,152 KB.

Now your rom is Expanded.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Part II , Patch the ppf file to the Expanded Rom
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

1. Now what you are going to do is Drag out my PPf O-Matic
and run it.

2. The Screen Should appear with the words Iso File and 
   Patch.

3. For the Iso File , Click the disc at the end of the white
   line and When the Selection Menu pops up ,  go down and
   Change the file type from CD-Images to all files.

4. Select the Fresh Extended and Expanded Of mine.

5. For the Patch , click the disc at the of it's white line
   as well and select my Spooky Worlds Patch I gave you.

6. Now Apply

Now you have made the Rom.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Part III , The Final Step
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

NOTE : You must have Project 64 for the game to work.

1. Start Up Project 64 and my Rom and go to 
   Options > Settings.

2. Then , select Options on the top and uncheck 
   "Hide advance Settings" Then Click OK

3. Now Re open the Options > Settings Section.

4. Now this time Select "Rom Settings and Change the Memory
Size to 8 mg instead of Default or 4 mg.

5. Now go to Advance Settings and change the Default Memory
   Size to 8 Mg.

6. Click OK and Start up the Rom.

And you are done ! Congratulations.


~Awesomelukey Studios � ~