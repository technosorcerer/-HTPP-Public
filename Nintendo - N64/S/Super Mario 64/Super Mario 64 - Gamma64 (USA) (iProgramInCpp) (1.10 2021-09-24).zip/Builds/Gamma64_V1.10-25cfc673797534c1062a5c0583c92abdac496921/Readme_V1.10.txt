Gamma64 V1.10 by iProgramInCpp - README!

What's New in this build?
- Fixes for the Jungle, yet again
- More stability checks. Real Hardware is now 100% STABLE
- Fixed Ghost House music loudness, it's now balanced with the rest of the soundtrack

Put "0x8D3BD49B=1 (Gamma64_V1.10)" in your save_db.txt when playing on real hardware.