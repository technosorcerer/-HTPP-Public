Gamma64 V1.04 by iProgramInCpp - README!

What's New in this build?
- Fixed weird dialogue in the City level, it should be better.
- Fixed File Select. It now no longer crashes the game on real N64 (forgot a segmentload that was loaded in the MarioHead screen)
- Fixed squatkick
- Misc. other stuff