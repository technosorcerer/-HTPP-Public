Gamma64 V1.06 by iProgramInCpp - README!

What's New in this build?
- Fixes for the Jungle 
- Reduced time for the camera cutscene when getting a Star in the courtyard.

Put "0x8DDE949B=1 (Gamma64_V1.06)" in your save_db.txt when playing on real hardware.