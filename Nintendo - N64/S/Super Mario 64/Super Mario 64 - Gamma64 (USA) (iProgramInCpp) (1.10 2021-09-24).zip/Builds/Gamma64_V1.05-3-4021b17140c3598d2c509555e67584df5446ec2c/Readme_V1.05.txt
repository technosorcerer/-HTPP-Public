Gamma64 V1.05 by iProgramInCpp - README!

What's New in this build?
- Fixes for Mount Freeze's Slide, hopefully jungle too

Put "0x083C356D=1 (Gamma64_V1.05)" in your save_db.txt when playing on real hardware.