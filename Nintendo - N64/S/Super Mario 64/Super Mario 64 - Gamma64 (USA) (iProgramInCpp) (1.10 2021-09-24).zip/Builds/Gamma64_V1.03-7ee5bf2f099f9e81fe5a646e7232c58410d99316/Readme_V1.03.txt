Gamma64 V1.03 by iProgramInCpp - README!

What's New in this build?
- Fixed missing Bob-omb in GH, you're now able to complete the stage
- Fixed a bunch of bugs
- Added a new course! (after you finish  the game, use the pause menu)