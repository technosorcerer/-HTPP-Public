Thank you for playing SM64: Beyond the Cursed Mirror!
-Rovert

Flips Patching tutorial: https://youtu.be/dDNMz2SyGtY

I highly suggest using this emulator for the best performance:
https://parallel-launcher.ca/

VERSION 1.0
5-19-2023