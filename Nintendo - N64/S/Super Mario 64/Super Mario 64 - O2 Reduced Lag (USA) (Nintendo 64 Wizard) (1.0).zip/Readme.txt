After Super Mario 64 was finally decompiled back into its source code, it was discovered that 
Nintendo failed to use the O2 compression method when they compiled the game originally. This 
knowledge has existed for months, but now there�s a way for anyone to get the benefits of an O2 
compressed Super Mario 64 with a simple patch rather than command line kung-fu in unix.

This patch almost completely erases the lag in Super Mario 64, including the lag caused by the 
infamous Bowser sub, which now runs at nearly full speed even when the entire sub is in view.


Patch this "Super Mario 64 (USA)" rom file:

File/ROM SHA-1: 9BEF1128717F958171A4AFAC3ED78EE2BB4E86CE
File/ROM CRC32: 3CE60709

After patching:
File/ROM SHA-1: E2FC14DC38CD73AEA89D64A0BEAC383D7583114B
File/ROM CRC32: FB6FB9FE


Patch this "Super Mario 64 (Japan)" rom file:

File/ROM SHA-1: 8A20A5C83D6CEB0F0506CFC9FA20D8F438CAFE51
File/ROM CRC32: DD801954

After patching:
File/ROM SHA-1: 13C5DBC25AB182D83129222968E198AD1FF22BB9
File/ROM CRC32: 504D3DB


Released By	Nintendo 64 Wizard
* works on native N64 hardware with an everdrive