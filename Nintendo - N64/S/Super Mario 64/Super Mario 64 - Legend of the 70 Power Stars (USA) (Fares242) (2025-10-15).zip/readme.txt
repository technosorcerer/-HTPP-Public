                                              THE LEGEND OF THE 70 POWER STARS

The castle is composed of 70 power stars held together by a grans star. Bowser comes and spreads them all around the Mushroom Kingdom, steals the grand star, & kidnaps Princess Peach. It's up to Mario to collect the stars, save the grand star, and rescue the princess!


This hack is composed of:
-70 power stars all missions changed except for the secret slide & the secret aquarium.
-Cap levels have no stars, but the caps are essential, so activate the cap switches.
-Difficulty may require playing and mastering the original.


                 



                                                            ENJOY!!! 