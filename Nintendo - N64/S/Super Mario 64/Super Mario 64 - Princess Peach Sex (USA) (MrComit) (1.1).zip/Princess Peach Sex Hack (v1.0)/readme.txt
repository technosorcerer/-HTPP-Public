SET UP: Please play this hack on Project 64 version 1.6 or 2.4, with memory set to 8mb, and GlideN as the video plugin.
Note that Glide*N* is different from Glide. This hack was not made to be played on Glide, so you may experience graphical errors if you play on Glide or any other video plugin.

HOW TO PLAY: Use this website https://hack64.net/tools/patcher.php
For "ROM" select your own original Super Mario 64 (U) [!].z64 rom
For "Patch" select the "PPSH 1.0.bps" included in the download

This hack is console compatible and has been tested to work on Everdrive.