Welcome to Mario and the Forgotten Adventures II - Imminent Departure.
This hack has 115 Stars, any% ISC is at 65 Stars.

In this folder, you will find the hack, the Star Display for this hack and an oversimplified map of the hack.

Special shoutouts to :

- Woissil for the coding (very useful in B1)
- TVGC for the music in some levels  (second area of C6 and first 2 areas of B1)
- Reverser for being my beta tester

And of course the shoutouts to everyone in the SM64 ROM Hack community for making the tools that made such hack possible.

A thing or two before tackling this hack : this hack has improved some enemies by quite a bit. Here are some examples:
1) The Snufits fire bullets that are much faster than usual.
2) Bullet Bills can take sharper turns and go slightly faster than usual.


Also, make sure to read the textboxes. They may hold precious information for your adventure.