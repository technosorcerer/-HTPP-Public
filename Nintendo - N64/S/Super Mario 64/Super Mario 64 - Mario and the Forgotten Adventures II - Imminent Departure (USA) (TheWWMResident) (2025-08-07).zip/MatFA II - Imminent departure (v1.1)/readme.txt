Welcome to Mario and the Forgotten Adventures II - Imminent Departure.
This hack has 115 Stars, any% ISC is at 65 Stars.

In this folder, you will find the hack, the Star Display for this hack and an oversimplified map of the hack.

Special shoutouts to :

- Woissil for the coding (very useful in B1)
- TVGC for the music in some levels  (second area of C6 and first 2 areas of B1)
- Reverser for being my beta tester

And of course the shoutouts to everyone in the SM64 ROM Hack community for making the tools that made such hack possible.

A thing or two before tackling this hack : this hack has improved some enemies by quite a bit. Here are some examples:
1) The Snufits fire bullets that are much faster than usual.
2) Bullet Bills can take sharper turns and go slightly faster than usual.


Also, make sure to read the textboxes. They may hold precious information for your adventure.

-- Changelog --

v1.1 (04/08 at 6:26PM UTC) : 
- fixed both warp holes in C1 (one was too small for comfort and the other one did not appear in Stars 5-6)
- fixed the dialogue of Bob-Omb in C1 and the sign in VC to be less vague.
- put the invi !-box of VC on the ground instead of airborne, as well as revealing the invi !-box in B1.
- fixed some dialogues in B1.
- moved one sign from Sky station to C4. It also holds a precious piece of information for C4.
- C6's pink Bob-Ombs now are in different places, whether you select Star 1 or Stars 2~6.

v1.0 (04/08 at 6:00AM UTC) : release of the hack