☆☆☆　Suepr Mario The Majestic Road ver.1.0　☆☆☆


Thank you for downloading.
I strongly recommend you to set the counter factor to 1.

I would like to thank Mese for his great help in creating the title screen, providing BGM, installing tweaks, and fixing bugs.
I would also like to thank the guests who provided courses, Juuris for the midi of Ride Out!
Mr. S for the midi of Range Hood Makuroke, and BroDute for the m64 of Mirror Temple.
Almost all of Touhou music are created by sm64pie.














Here are the courses and background music information.









-------- Courses --------




C1: Peaceful stroll
C2: Aerial Garden
C3: Subterranean Animism
C4: Rotten Village
C5: Unknown Kadath           (Made by Mese)
C6: the Base of a Volcano
C7: Music Space
C8: Huge Desert
C9: Baseball Ground
C10: Lost Wallkicks
C11: Warp Zone               (Made by Tenori)
C12: Cosmic Hill
C13: Fantastic Scenery       (Made by Nuwitch)
C14: Four Mountains of Faith
C15: Lunatic Legacy

B1: Wasabi Temple
B2: Liberation From the Cave
B3: Undefined Final Ocean

WC: Sky Ruins
MC: Scorching Ruins
VC: Ancient Ruins

・mini courses
Eccentric Ruins
Majestic Land
Phantasmagoria of Eastern Night (Made by Dretchen)
Spring Dream






-------- BGM --------



OW1: 情熱、都会暮らし       (from パワプロクンポケット13)
OW2: Mirror Temple          (from Celeste)
OW3: 燃え尽きるぜ～         (from パワプロクンポケット10)

C1:  恋は渾沌の隷也        （from 這いよれ! ニャル子さん）
C2:  ミストレイク           (from 東方輝針城)
C3:  少女さとり             (from 東方地霊殿)
C4:  人形裁判              （from 東方妖々夢)
C5:  endless carnival       (from ブルーアーカイブ)
C6:  バレスタイン城のテーマ (from Y's III)
C7:  BabeL ～Grand Story～  (from pop'n music 19 TUNE STREET)
C8:  bag                    (from Dance Dance Revolution)
C9:  She I                  (from パワプロクンポケット9)
C10: VS trainer             (from Pokemon Uranium)
C11: ワタクシドモノタタカヒ (from パワプロクンポケット12)
C12: 星条旗のピエロ         (from 東方紺珠伝)
C13: 神々が恋した幻想郷     (from 東方風神録)
C14: 明日ハレの日、ケの昨日 (from 東方風神録)
C15: 宇宙を飛ぶ不思議な巫女 (from 東方紺珠伝)

B1:  黒髪乱れし修羅となりて (from pop'n music 18 せんごく列伝)
B2:  リーインカーネーション (from 東方夢時空)
B3:　Ride Out!              (by ASK)


MC:  The Scorching Labyrinth(from 神巫女 -カミコ-)
WC:  Unwelcome School       (from ブルーアーカイブ)
VC:  Snow halation          (from ラブライブ！)

ER:　夜空のユーフォーロマンス(from 東方星蓮船)
ML:  幻の大地 セルペンティナ (from Zwei!!)
PEN: 六十年目の東方裁判      (from 東方花映塚)
SD:  春の湊に                (from 東方星蓮船)

WCap, VCap:  FREEDOM DiVE↓         (by xi)
MCap:        KING                   (by Kanaria)
B1B, B2B:    宇宙戦艦ヤマト         (by 宮川泰)
B3B: 　　　　平安のエイリアン　　　 (from 東方星蓮船)

KTQ Race:    レンジフードまっくろけ (from ポピラ2)
File Select: 1年目                  (from パワプロクンポケット6)
Star Select: アーメン               (from パワプロクンポケット10)