SRW-W Exhilarated

This is an PPF patch for the NDS "Super Robot Wars W".

Changes:
- SP consumption and weapon/aircraft modification costs are reduced.
- Weapons/aircraft modification limit up
- The acquisition fund was increased by 1.5 times.
- Allied pilot ability (SP/defense/hit rate) increased by 10%

Please be aware that the game difficulty will be easy.
The goal was non-stress and exhilaration.

Enjoy!
