Copy this folder to the 'apps' folder on your SD for load with the homebrew channel.

http://hbc.hackmii.com for the homebrew channel download and information.