Economical Super Robot Taisen 64

"Eco_UnitPilotMods_SRW64.ppf"

This is NINTENDO64 "Super Robot Taisen 64 (Japan)" PPF patch.

[Changes]
- Reduced SP consumption, Unit / Weapon remodeling costs.
- Strengthened the usefulness of the weapons of allied robots, including Boss Borot. (Range, Hit rate, Critical rate, etc.)
- Increased allied robot stride and number of parts slots (+1)
- Weapons with range 9 or more change to reduces range or attack power. (Final bosses)
- Increase the upper limit of the remodeling stage
- Units with HP 20000 or higher have a 15% reduction in HP (enemies)
- Increases the ability of allied pilots by 5 to 10 percent
- Super strengthening Sweemurg
- Renamed (Lawrence Jefferson-> Teshigawara Sebastian)
- Expansion of pilot riding range (For example, Hilde can ride a Gundam and Simone can ride a Layzner.)

For light users who want to play casually and enjoyably without stress.
More units will be active by strengthening short-range weapons.
If you want to enjoy invincible play, we recommend choosing the story of Miss Manami. ;)

P.S.
I used the MasMin to find a table of SP consumption values.
https://www.romhacking.net/utilities/1668/

PPF PATCHER
https://web.save-editor.com/tool/rom_patcher_for_ppf.html

[Extra]
Cheat Code: 801C2650 0079
Play a special scenario in which F91, Zambot-3, and GoShogun participate.
(Requires saved data).

INSTRUCTIONS:
1. turn on the above cheat and start the game
2. load the data (for ROM)
3. save the data 
4. quit the game temporarily
5. turn off the cheat and start the game
6. load the data
 The next scenario will be a special scenario.

EOF