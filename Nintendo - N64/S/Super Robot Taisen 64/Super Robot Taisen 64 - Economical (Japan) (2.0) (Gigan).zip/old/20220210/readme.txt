Economical Super Robot Taisen 64

"Economical_SRW64.ips"

This is NINTENDO64 "Super Robot Taisen 64 (Japan)" IPS patch.

[Changes]
- Reduced SP consumption, Unit / Weapon remodeling costs.

For light users who want to play casually and enjoyably without stress.

P.S.
I used the MasMin to find a table of SP consumption values.

https://www.romhacking.net/utilities/1668/

EOF