Economical Super Robot Taisen 64

"Eco_UnitMods_SRW64.ppf"

This is NINTENDO64 "Super Robot Taisen 64 (Japan)" PPF patch.

[Changes]
- Reduced SP consumption, Unit / Weapon remodeling costs.
- Weapon with range 1 change to range +1 or hit correction + 10%.
- Weapon with range 2 change to range +1 or critical correction + 10%.
- Weapons with range 9 or more change to reduces range or attack power. (Final bosses)
- Increase the upper limit of the remodeling stage
- Units with HP 20000 or higher have a 15% reduction in HP (enemies)
- Super strengthening Sweemurg
- Renamed (Lawrence Jefferson-> Teshigawara Sebastian)

For light users who want to play casually and enjoyably without stress.
More units will be active by strengthening short-range weapons.
If you want to enjoy invincible play, we recommend choosing the story of Miss Manami. ;)

P.S.
I used the MasMin to find a table of SP consumption values.
https://www.romhacking.net/utilities/1668/

PPF PATCHER
https://web.save-editor.com/tool/rom_patcher_for_ppf.html

EOF