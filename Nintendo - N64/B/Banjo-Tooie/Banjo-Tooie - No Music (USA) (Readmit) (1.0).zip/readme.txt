Banjo-Tooie - No Music Version 1.0

MOD DESCRIPTION:

This mod removes the background music in the USA v1.0 of Banjo-Tooie. Jingles such as the one that plays when a jiggy appears, when you collect a jiggy, collect a jinjo, collect all jinjos in a level, complete a new honeycomb, the music that plays when King Jingaling is revived, as well as the transformation music, have all been kept, in order to maintain the character of the game. Also, the beginning "da na na na na na" jingle of the wading boots has been kept in, however; after many hours of trying, the equivalent jingle could not be kept in for the Turbo Trainers (Running Shoes), Springy Step Shoes, the Claw Clamber Boots, or the Wonderwing. This is because Banjo-Tooie is not coded the same way as Banjo-Kazooie, and every attempt made to preserve these jingles has resulted in either a crash or a graphical glitch. For the time being, it's a necessary compromise and this as good of a no music mod as Banjo-Tooie can have. Perhaps this will change in the future.

CODES:

Also, to enhance the game experience, it is recommended to go into the game's settings on the file select screen and enable Widescreen mode. Here are 2 codes that can disable the anti-aliasing, along with the master code:

(m)
F1000302 0002
F100030E 0005

These 2 codes work on console, but do nothing on emulator.
Disable AA
810414EC 0000
810414EE 3206
8104151C 0000
8104151E 3206

Disable AA 2
800414ED 0000
800414EE 0033
8004151D 0000
8004151E 0033

BACKGROUND INFORMATION:

The first version of this mod was finished on August 23, 2023, but the release was delayed due to wanting to release it around the same time as the Banjo-Kazooie - No Music mod.