Grasstemis 64

This was a proof of concept, mainly a way to check if both the bomberhacker overhaul's importers worked properly.
It's a simple retexture, but it might freshen up gameplay for those whom want! The hack works on actual console as well

Enjoy!