*UPDATE*
Banjo-Kazooie - No Music Version 1.A
This an improvement to the one that was released yesterday. This one includes the "Gu-Huh" sound that Banjo makes during the intro title sequence. Please use this release instead of the earlier one.

Mod Description:

This mod removes the background music in the USA v1.0 of Banjo-Kazooie. Jingles such as the one that plays when a jiggy appears, when you collect a jiggy, collect a jinjo, collect all jinjos in a level, as well as the beginning "da na na na na na" sounds of the wading boots, turbo trainers, and gold feathers have all been kept in to retain the character of the game.

Also, these codes are recommended to enhance the game experience. They can be found here:
https://www.youtube.com/watch?v=-LXpEitofKA

Widescreen v1.0:
81277A0C 4334 
81277A10 4334
81277A18 4308
81277A20 4308
81275D24 3FE6

This code works on console, but does nothing on emulator.
Disable Anti-Aliasing v1.0:
812773AC 0000
812773AE 3202
812773DC 0000
812773DE 3202