---------------------------------------------
	     Delta Patcher 1.0
---------------------------------------------
 (C) 2010 Phoenix <phoenix_87_c@hotmail.com>



-------------------------
1. What is this?
-------------------------

Delta Patcher is yet another frontend to the
xdelta3 decoder/encoder created by Joshua
McDonald. Delta patcher is able to make and
apply patches. But... why making another frontend?
All the frontends I've seen don't support some
options of the encoder/decoder at all, like
compression level for encoding and checksum
checking for decoding/encoding. Also, they are
all written in .NET (0_0). So, this tool was
designed to be selfcontained (as of now, only
for Windows). It's written in C++ using
wxWidgets for the GUI components and all the
needed libraries are static linked to the EXE.
All you need is to place the xdelta.exe file
in the same directory of this tool (no more
.NET Framework required).
Last, but not the least, Delta Patcher is
GPL2'd and cross-platform: it runs fine on
Windows and Linux and should compile on MacOS
too.

(The xdelta version shipped with this release
is 3.0z)

-------------------------
2. Features
-------------------------

-Cross-platform and opensource: modify and
 redistribuite it under the GPL2 license;

-Native executable.
 For Windows, just drop xdelta.exe in the same
 directory;
 For Linux, you should install wxWidgets and
 xdelta3 then compile Delta Patcher with
 CodeLite (a GNOME environment is needed);

-Multilanguage: Delta Patcher can be
 translated into any language using .po files.
 If you want multilanguage support you have
 to place the "resource" directory along with
 this tool (see source code for the pot file);

-Supports patch compression level and
 checksum validation in the encoding process
 (making the patch);

-Supports disabling checksum validation when
 applying patches. If your rom/iso is not
 exactly the same of the one used by the
 creator of the patch, you can try to
 apply the patch nevertheless (this one is a
 very common problem when dealing with ISO
 patches).

-Associate xdelta patch files within the
 frontend, just click the checkbox on the GUI;

-No console windows when executing xdelta,
 all output text will be redirected to the
 log window;

-Drag & Drop support for original file and
 xdelta patch file in the decoding window.



-------------------------
3. Full and Lite versions
-------------------------

This package comes with two versions of the
frontend. The Lite version is simply the
patching GUI, this is intended to be shipped
along with your patch. This way, the final
user doesn't need to mess with other options
like patch creation (simplicity comes first!).
The Full version is mainly for romhackers,
it supports both creation and application
of xdelta patches.



-----------------------
4. Contacts and sources
-----------------------

You can contact me by email at
phoenix_87_c@hotmail.com or in the SadNES cITy
board at http://lnx.sadnescity.it/forum/.
The full source code can be obtained at
www.sadnescity.it in the utility section.


Phoenix.
