Snow Glow Village: A brand new Banjo-Kazooie level created by Koolboyman and Skill!

This level is small and pretty easy, but I hope you all find it fun!  

How to play: 
- Get This program: http://www.romhacking.net/utilities/704/
- Download an N64 emulator. I recommend Project 64 http://www.emulator-zone.com/doc.php/n64/project64.html
- Get a clean Banjo-Kazooie V1.0 (U) ROM. 
- Use the program to patch the file to the BK ROM. 
- Play and enjoy!

Skill: 
- http://www.rarewarecentral.com

Koolboyman: 
- http://www.youtube.com/koolboyman
- http://www.twitter.com/koolboyman

Special Thanks: Subdrag
- http://www.goldeneyevault.com/