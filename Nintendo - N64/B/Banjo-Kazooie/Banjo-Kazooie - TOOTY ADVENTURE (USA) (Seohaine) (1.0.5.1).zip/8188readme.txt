Download Patch 
https://mega.nz/folder/n8BBEb7Q#PthNYZ7Z3aEUeem5u57CTQ

V1.0.5 
Most everdrives will work with this

V1.0.5.1 
For those that don't work with ther other (no custom intro)