Perfect Dark Unlock Everything
by Triclon

E-mail - triclon@gmail.com
Website - https://triclon.neocities.org

What is this?

This patch conveniently unlocks everything in Perfect Dark so you can jump right in with all game modes, guns, characters, etc.!  You will need to patch the .bps file over a Perfect Dark USA v1.0 rom.  It must be a .z64 file.  Expansion Pak required (not that you should be playing Perfect Dark without one in the first place).


How did I even make this?

My friend wanted to play some Perfect Dark multiplayer on console with my Everdrive and I couldn't find an easy way to unlock everything, so I made this.  How?  I patched the ridiculously long "Ultimate Code" by Gray Vader found on https://gamehacking.org directly into the Perfect Dark rom with my handy dandy N64 Gameshark Code Injector utility (https://www.romhacking.net/utilities/1659/).  My understanding is the "Ultimate Code" is a combination of a whole lot of other Perfect Dark Gameshark codes cobbled together into one giant code.  I am not sure the "Ultimate Code" was ever intended to even be run on console, since I think it was too many lines of code for the N64 Gameshark to handle, but hey it works on console now since the injector has no such limitation.