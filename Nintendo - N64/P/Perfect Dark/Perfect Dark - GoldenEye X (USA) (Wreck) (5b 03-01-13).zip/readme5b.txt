Inside the zip, you will find four files: the first and second
are both XDelta patches, which can be patched to your unmodified
Perfect Dark v1.1 NTSC ROM.  Only use the "Clouds" version if you
plan to play on console with a backup device, or are using an
emulator that can properly render the clouds.  The third is a
details text, which includes various information about the current
version of the mod.  Updates, special notes, and known gameplay
glitches are listed.  Lastly, is a text file that tells the difference
between the Clouds and Cloudless versions.  If you don't know how to
apply an XDelta patch, you'll probably want to download the
GoldenEditor / Perfect Editor combo program from the GoldenEye Vault.
Here is a direct link to the download page...

http://www.goldeneyevault.com/viewfile.php?id=37

With the program open, go to "Tools".  From the selection menu,
highlight "XDelta Patching".  Choose "Apply PD XDelta Patch"
from the list.  First you will need to find and select your PD
v1.1 NTSC ROM.  Afterward, select the XDelta patch.  You will then
be asked to save your new ROM.  After a few moments, the process
should complete.  Simply load it up in the emulator (or backup
device) of your choice, and enjoy!