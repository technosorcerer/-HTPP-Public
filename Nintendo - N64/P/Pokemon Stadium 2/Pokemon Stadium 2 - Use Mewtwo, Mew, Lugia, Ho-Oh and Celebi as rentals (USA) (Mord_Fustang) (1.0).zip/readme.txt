Pokemon Stadium 2 - Mord's Rental Hack

Use Mewtwo, Mew, Lugia, Ho-Oh and Celebi as rentals in Prime Cup (includes multiplayer).

Normally, Mew and Celebi can be unlocked.
Mewtwo, Lugia, and Ho-oh must be traded from a cartridge.

The number of slots are hardcoded, so Caterpie, Metapod, Weedle, Kakuna, and Magikarp have been removed and Mewtwo, Mew, Lugia, Ho-Oh and Celebi are added.

Made using a hex editor.

Tested using Project64 & Everdrive 2.5.  Note there may be the same issues on Everdrive 2.5 as would be present in an unmodified ROM.

---

Pokemon Stadium 2 (U) [!].z64
MD5: 1561C75D11CEDF356A8DDB1A4A5F9D5D
SHA-1: D8343E69A7DC63B869CF6361D87CDE64444281D3
CRC32: A9998E09

After patching:
Pokemon Stadium 2 (U) - Mord's Rental Hack.z64
MD5: F24E9EBD9E4502D4D32209F37D03653D
SHA-1: 5248171E4C80E64B4A609CA184D981B608D71462
CRC32: 42E8956A