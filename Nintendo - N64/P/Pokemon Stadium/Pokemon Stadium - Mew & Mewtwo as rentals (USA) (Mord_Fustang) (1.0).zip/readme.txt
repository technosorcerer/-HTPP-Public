Pokemon Stadium - Mord's Rental Hack

Simple hack to use Mew and Mewtwo as rentals in Prime Cup 
(includes Free Battle/multiplayer).

Mew is not normally accessible until after the Mewtwo battle.
Mewtwo is not accessible as a rental and must be traded from a cartridge.

The number of slots are hardcoded, so Metapod and Kakuna were removed and Mew and Mewtwo added in.

Tested using Project64 & Everdrive 2.5.

Use "beat" to patch.



---

Pok�mon Stadium (U) [!].z64
MD5: ED1378BC12115F71209A77844965BA50
SHA-1: ED7BEF5A306F88C0A6E96B15E71FEE2EF32058F3
CRC32: 72F66F05
-
After patching:
Pokemon Stadium (U)  - Mord's Rental Hack.z64
MD5: 23B9FC70CE307D247B7E8302E4C9E4B3
SHA-1: 72A6AC0D85E03FBA9A890AE947BA24376E80FE8B
CRC32: 0BD3E61C