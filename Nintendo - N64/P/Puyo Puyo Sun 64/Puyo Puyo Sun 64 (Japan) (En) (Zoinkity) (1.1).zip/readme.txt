﻿Puyo Puyo Sun 64 English patch v1.1

  Puyo Puyo Sun 64, now with English text.  Japanese voiceover has been incorporated into endings and optionally in story mode.  Select "Cutscenes: Voice" in the options menu to enable it.  When not selected, the original typewriter sound is used instead.
  Portions of this work were pirated from Puyo Nexus's translation, v1.3~ish.  Yes, an unlicensed derivitive work unabashedly modified from their unlicensed derivitive work without anyone's knowledge or consent.  The TLnotes are more informed on how gratuitous that was, but effectively was limited to the tutorial and part of Draco's dialog.

Plot:
  Satan exploits global warming to turn the island into a tropical paradise so he'll be swimmin' in women.  Cut a swath of Puyo genocide across the land and put an end to his lecherous scheme.
  For the uninitiated, the Puyo series is a matching puzzle game focusing on clearing multiple sets in sequence rather than simultaneously clearing large numbers of pieces.  A tutorial is present in the options menu on the right-most page to get you started.

Patching:
  Apply the xdelta patch using the similarly named xdelta.  The patch will only apply to a ROM in native (big-endian) byteorder.

  Common Name:
  	Puyo Puyo Sun 64 (Japan)
  Internal Checksum:
  	94807E6B 60CC62E4
  SHA-1
  	CF79EC32E7E78B2CAD15B5B7DD763F578648B6C6
  SHA512
  	BCDC8CA93E5F0FBD1FD3C90F2A5439254079D63A0090313A4B2D13EC11C7F2C77D8CAC0EBE33DFE09395C6417FD5113B4F1BD1934ABC1BCC7FE7A3B2FADD4533

Notes:
  Modern emulators capable of running the 64DD conversions should be able to boot this title.  Recompilers are unlikely to work; use interpretters instead.  Worst case, start MAME in debugger mode, open a memory editor window to BFC007E6, change the two bytes from 3F3F to DDDD, then press F5 to run.
  PJ64 v2.x series now supported.  It required inserting a NULL byte into the internal name.  See the revision log for a rant about that.
  Emulators in particular don't always initialize eeprom correctly.  It's suggested to use "Options: Delete Saved Data" when playing for the first time.
  Console testing done with a 64drive HW1 and a Doctor 64 Jr. (albeit in a somewhat roundabout manner) revealed no replay issues.  4k eeprom required.
  Everdrive v2.x and v3 are confirmed to run normally.  Everdrive X7 is confirmed *broken* and unable to run several previous N64 patches as well.  There are no plans to RE this device to develop a workaround at this time.

  Some antipiracy measures were taken to provide a +unique+ experience to anyone attempting to sell these at market.

  Pressing A+B+C+Start will reset to Title.  It's the only thing mentioned in the manual that isn't terribly obvious.

-Zoinkity
