Installation guide:

1. Get a bps patcher (for example flips). You can also use online patchers.
2. Get a Paper Mario rom (it has to be a US version ending in .z64).
3. Use the patcher to patch the rom and then play it with your favorite emulator!

That should be all, enjoy!