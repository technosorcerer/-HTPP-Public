﻿.: TWINE 640i Patches :.
  These patches enable 640i thriple-buffered deflickered output (what, back then, passed for the highest of hi-res) in TWINE, provided you have 8MB of rdram present.  Otherwise, you'll only have normal output.  You can switch between this and 32bit color buffers using the in-game graphics settings menu.
  
  It is *highly* recommended you use either an overclocked console (like Analogue 3D or iQue) or a rather swift emulator.  Regular consoles are, at the best of times, as marginally playable as always and at the worst of times (like during replays) tedious.

  PAL is only included for curiosity's sake.  The retail game used a non-standard lazy scaling factor (1.1 instead of 1.2, so 528 lines instead of 576) that hilariously is not applied in c32 mode.  The patches in the main directory are "no scale" variants.  Patches that apply scaling are in teh subdirectory.  Without a PAL TV to test against, just providing it as-is for those who are curious.  (Some poor dev must have ptsd from all this, looking forward to the interview.)

  The "fast" variants use two framebuffers instead of the triple buffering.  It's arguable how much memory PAL actually uses and annoying to test properly, so that exists to cover all bases.
  Incidentally...  It's well-known TWINE runs worse with an expansion pak.  The primary reason is it switches to triple-buffering--and can't keep up!  When less than 8MB is present only two framebuffers are used.


.: Patching :.
  The patches will only apply to an original, unpatched ROM in native byte order (big-endian).  Attempting to patch something else will result in a completely unhelpful checksum error.  You cannot apply the "traditional" patch to a "international" patched file or vice-versa, only to an unpatched file.
  Xdelta patches can be applied with the aptly-named xdelta patcher; use version 3.0.8 or up.  (In other words, one from the last decade.)
  
  USA Common Name
  	007 - The World Is Not Enough (USA).n64
  USA Patch Name
  	TWINE 640i (USA).xdelta

  USA Original File Checksums
  SHA-1
  	2D0134ED3B9DE132C720FE697B532B4C232FF9FE
  SHA-512
  	5815087DF95B7C04FCF3E89C3CBEE8FC10BD15A4B269F2919709167D320384B15C41B6B75E978AB0D4668B6C77AA7F1CAE243F69B54FC970BCA3726080F49535

  Patched File Checksums
  SHA-1
  	77D81CE09739009253C68E9FA5B3474C7361B13F
  SHA-512
  	447659413BE88305FFD2AD665492CE8127E759362B8F087B25A8ACB2248275BBCB22375FB6B5A9FF85AE39075D72FF984C0147B28A5879A2CB2A08E6205DB288


  PAL Common Name
  	007 - The World Is Not Enough (Europe) (En,Fr,De).n64

  PAL Original File Checksums
  SHA-1
  	7FDE668850A7E1A8402AB94BB09538A537A7E38B
  SHA-512
  	4C2295A9EFE4EC248471E52A5E4728730AAB256422EB0DE6FA427839A7EC4421657AFA716A4AAF0511E905B86DF2DEE7E00CAECE407E0B5536334F940D039CE1

  PAL Patch Name
  	TWINE 640i No Scale (PAL).xdelta

  Patched File Checksums
  SHA-1
  	F0170B091C150E1EFC77C3978874A606B8AD574D
  SHA-512
  	5E155CE6ADA020127C61B8ECF894F377E9061E11981CA0612B0E03D97BEAC4C89EC44C71125BA28B54A9651942FD5CF6AB52B290816181607E1EB24270032D45

  PAL "Fast" Patch Name
  	TWINE 640i Fast No Scale (PAL).xdelta

  Patched File Checksums
  SHA-1
  	05567FCBE66360829525B99C4C5582362B4F89B4
  SHA-512
  	74F510922BEA0743B06D63042B8CF6B7451BA74B036DF3CE93FF4A95200011D8EDA6C1178431834BD4F9AA6E729B2BE8592FE9BA6A6154773E2CC2E9CB5C3D8B

-Zoinkity
