﻿.: TWINE 320i Patches :.
  While nosing around to create a 640i patch, noticed that there was support for a previously-unknown 320i mode that isn't available via menus.  It has a couple caveats:
1) It requires an expansion pak (8MB of rdram).
2) It can't be combined with "hi-color" mode (c32 framebuffers).

  These patches force the game to run in 320i mode if an expansion pak is found.  You can switch between this and 32bit color buffers in the in-game graphics settings menus.
  Actual output is 320x480 interlaced, a rather peculiar choice and honestly a bit meh.
  Overclocked consoles, including the iQue and A3D, are suggested.  iQue will take up to several seconds to switch modes however (and generally look awful).

  PAL is only included for curiosity's sake.  It used a non-standard lazy scaling factor (1.1 instead of 1.2, so 528 lines instead of 576) and it's doubtful they even looked at the feature when porting, pretty sure it displays wrong.  Without a PAL TV to test against, just providing it as-is.  A "no scale" variant is also provided.  Incidentally, the c32 mode isn't scaled at all in retail.  (Some poor dev must have ptsd from all this, looking forward to the interview.)

  It's well-known TWINE runs worse with an expansion pak.  The primary reason is it switches to triple-buffering--and can't keep up!  When less than 8MB is present only two framebuffers are used.


.: Patching :.
  The patches will only apply to an original, unpatched ROM in native byte order (big-endian).  Attempting to patch something else will result in a completely unhelpful checksum error.  You cannot apply the "traditional" patch to a "international" patched file or vice-versa, only to an unpatched file.
  Xdelta patches can be applied with the aptly-named xdelta patcher; use version 3.0.8 or up.  (In other words, one from the last decade.)
  
  USA Common Name
  	007 - The World Is Not Enough (USA).n64
  USA Patch Name
  	TWINE 320i (USA).xdelta

  USA Original File Checksums
  SHA-1
  	2D0134ED3B9DE132C720FE697B532B4C232FF9FE
  SHA-512
  	5815087DF95B7C04FCF3E89C3CBEE8FC10BD15A4B269F2919709167D320384B15C41B6B75E978AB0D4668B6C77AA7F1CAE243F69B54FC970BCA3726080F49535

  USA Patched File Checksums
  SHA-1
  	77D81CE09739009253C68E9FA5B3474C7361B13F
  SHA-512
  	447659413BE88305FFD2AD665492CE8127E759362B8F087B25A8ACB2248275BBCB22375FB6B5A9FF85AE39075D72FF984C0147B28A5879A2CB2A08E6205DB288


  PAL Common Name
  	007 - The World Is Not Enough (Europe) (En,Fr,De).n64

  Original File Checksums
  SHA-1
  	7FDE668850A7E1A8402AB94BB09538A537A7E38B
  SHA-512
  	4C2295A9EFE4EC248471E52A5E4728730AAB256422EB0DE6FA427839A7EC4421657AFA716A4AAF0511E905B86DF2DEE7E00CAECE407E0B5536334F940D039CE1

  PAL Patch Name
  	TWINE 320i (PAL).xdelta

  Patched File Checksums
  SHA-1
  	A59B2F8EC054697A48E5D2C3788890DFBB517483
  SHA-512
  	673C411B31F9D1B47963FC4C5A965F91614256FDDB50084380D6B883AADE3621A3DD58706162FA3807AB524B62038CF906BC9445BD3285DA327C07231543FCD1

  PAL "No Scale" Patch Name
  	TWINE 320i No Scale (PAL).xdelta

  Patched File Checksums
  SHA-1
  	D06E6D2D19EE650660163F752187D81ED025076E
  SHA-512
  	A3C510351F287AEC528BA96890EAA11C9C679300D1A1557BD6D9C2D1A2DB2E6325A45DF2A3729EED774B862466EE7C22FC509DC49D680BA5F5C77ABD099E187A

-Zoinkity
