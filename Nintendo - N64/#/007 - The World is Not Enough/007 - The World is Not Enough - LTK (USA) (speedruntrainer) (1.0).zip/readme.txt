Patch the 007 - The World is Not Enough LTK.xdelta with 007 - The World is Not Enough NTSC ROM using xdelta GUI.

This is an LTK mod for TWINE.

Tools used: 
GoldenEye 007 Setup Editor changing the game to TWINE.
N64 Gameshark code injector

Credits: 
SubDrag - GoldenEye 007 Setup Editor, adding TWINE
BoPeep* Unlock all levels and difficulties
speedruntrainer - Changing the guard's health to 1 and modifying a Gameshark code 'Bond has TONS of health' changing the values so Bond passes away in 1 hit.
Goldenboy - Original Bond has TONS of health code

* Not entirely sure, only a code that didn't unlock difficulties have been found.
  So there might or might not be an original creator to unlock all levels with their difficulties