40 Winks N64 Crack
+-+-+-+-+-+-+-+-+-+

  This crack bypasses the screen which displays:
"THIS GAME IS NOT DESIGNED TO BE PLAYED ON THIS SYSTEM"
  Turns out there really isn't anything preventing you from playing the game after all ;*)

  Two versions of the fix are provided here.  You can either apply the patch to a rom image to permanently, or you can use GameShark cheat codes to hotfix the problem.  Both do exactly the same thing.

+GameShark Version+
  Enter this code into your cheat device:
8002E221 0000


+Patch Version+
  Apply the patch provided to an +unbyteswapped+ 40 Winks rom (N4WX).  The patch applies the fix and revises the checksum for you.

+_+

Technical:
  The routine 8002E600 recieves a value V0 that denotes how to treat the current intro splash screen.  Normal operation sets V0=1, allowing the menus to progress.  However, fatal errors return V0=2, which fixes the screen permanently.
  The patch simply forces the last test prior to the displayed message to always return true, causing it to branch with V0=1.  Technically, it changes the test:
BEQL	V0,V1,8002E600
to
BEQL	R0,R0,8002E600

  This occurs at 8002E220 in RDRAM, and 0x2EE21 in ROM.

@_@

  If you suffer some terrible calamity, you can always attempt to write me.  I don't have regular internet access, but I will try to return a message as soon as possible.

-Zoinkity	(nefariousdogooder@yahoo.com)
Giant Fish Monster Productions
