﻿Wave Race 64 (USA) (Rumble Edition)

  A more jittery Wave Race 64 in a less oriental language!
  Besides famously supporting the Rumble Pak--arguably the best implementation in any N64 game--Controller Pak users can store ghosts on Time Trial courses, provided 121 pages for your pookas to possess.


.: Patching :.
  The patch will only apply to a ROM in native byte order (big-endian).  Attempting to patch something else will result in a completely unhelpful checksum error.  Xdelta patches can be applied with the aptly-named xdelta patcher; use version 3.0.8 or up.

  Common Names
  	Wave Race 64 (Japan) (Rev B) (Shindou Edition).n64
  	Wave Race 64 - Shindou Edition (J) (V1.2).n64

  Original File Checksums
  SHA-1
  	445ECB4904CC0AB6B81FB415A35072E99F18B545
  SHA-512
  	85A833F5ECA65D14BBB0FB28D79899C013CFF03959A5CA15B1705CE78B550D4297884A0E35F2BB2EE1BC27EE1628ADAFF3646CA35942EAFED3A2F19301E6D4B5

  Patched File Checksums
  SHA-1
  	D65BBD1EB8E9F5EC23FEC2465A9B4EAEAE7CF249
  SHA-512
  	15C74DD7482528CBA0A8964FC2AD6031664D7B46B99C7A7522FBCDE2E8D3C9A9ED863565A46AFF13ED6F45E93433ABDB0E3C19327D2DEDCDB8A8B87DF69E8446

.: Notes :.
  This was nowhere near as straightforward as it should have been.
*) Your Controller Pak save data from USA games should be compatible with Japanese versions.  Through a silly oversight, the Game ID checked in English versions is Japanese (NWRJ).
*) The official localization was maintained (Blue, not Pirate; Glacier Coast, not Cool Wave, etc.) and voice converted to the new format.  When relevant, messages, layout, and formatting match E1.  A few Japanese layout differences are retained for personal aesthetics (difficulty names aligned top, for instance).  There's a fair number of newly-translated messages and a few coerced for room (~50 ghost & warning messages across the menus).  Controller Pak terminology (mostly) refers to "Notes" & "Pages" now, not a more generic "data".  It should be close-ish to what Nintendon't...didn't.  Please don't kill the messenger.
*) The original Japanese version doesn't always give prompts to insert Controller or Rumble Paks.  The conditionals are a bit dubious and it doesn't seem like it's caused any major headaches in the last few decades, so this behavior remains as-is.  Frankly, with a minor software change and a soldering iron there's no reason the two can't be simultaneous...
*) If whatever you're using to play this runs the original game it should run this as well.  If it doesn't, this won't work either.  Emulators historically had problems with the Japanese title on account of how they fraud cycles & counts, resulting in a run condition where the thread that initializes EEPROM passed control to the thread that utilized EEPROM before init occurs, usually resulting in a hanging message. (-or was it a NULL msg pointer?  It wouldn't run, and that's what matters.)  It runs great on a real console; everything else will catch up eventually.  If you're using some older emu try changing the "cheat count" setting to something higher.

.: Revisions :.
2023.02.28	CD59604DC58A9B52D9A06517C8FA005B309BA5FB
	initial release
2023.08.08	24C7BC1DA8385F7F12C11C8F6940BFFEF6CE8AFF
	Bugfix for swapped *x10 course names.  Affects stage select, records, & erase menus.
2025.04.28	D65BBD1EB8E9F5EC23FEC2465A9B4EAEAE7CF249
	Single-byte bugfix for the Controller Pak read error message when entering Time Attack.  Please thank a dying battery for this update.

-Zoinkity
