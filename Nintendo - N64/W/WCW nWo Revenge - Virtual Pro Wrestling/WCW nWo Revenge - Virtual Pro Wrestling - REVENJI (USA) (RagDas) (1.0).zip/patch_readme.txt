WCW/nWo REVENJI - Patching the ROM
==================================
Hello, freem here. I've been assigned the task of making and releasing
the patch file for RagDas' ROM hack of WCW/nWo Revenge.

This hack is meant for WCW/nWo Revenge, NTSC-U, Z64 format.

ROM Formats
-----------
For varying reasons, there are different formats of Nintendo 64 ROMs.
Most N64 ROM hacking work has standardized on the Z64 format, as that's what
the console actually sees when running the game.

Therefore, if your copy of WCW/nWo Revenge is not already in Z64 format,
you will need to convert it for the patch to work properly.

ROM conversion can be done with various programs, such as:
- uCON64: http://ucon64.sourceforge.net/
- ToolN64 (sometimes called "Tool64"): https://www.zophar.net/utilities/n64aud/tool-n64.html

The target format will be listed as either "Z64" or "big endian".

Patch Formats
-------------
Due to varying opinion in the Nintendo 64 emulation scene about what patch
format is considered the best, this hack is being provided in two different
patch formats. Hopefully nobody will complain.

These formats are xdelta (file ending in ".xdelta") and beat (file ending in ".bps").

There is a web-based patcher compatible with both formats at
https://hack64.net/tools/patcher.php

You only need to apply one of the patch files. Do not attempt to apply both patches.

Patching with xdelta
--------------------
On Windows, I recommend using "Delta Patcher" by SadNES cITy Translations,
available from http://www.romhacking.net/utilities/704/

Patching with beat
------------------
beat is available from https://code.byuu.org/beat in both source code and
Windows binaries. The Windows binary is a GUI program, which is
hopefully straightforward enough to use.

ROM Hashes
----------
The original ROM has these hashes:
MD5    c1384f3637d7a381b29341fed3ef3ceb
SHA-1  e1711a2511394b9357b5f1ac8ca5cc17bd674836

Once the ROM is patched successfully, it should have the following hashes:
MD5    3286c8740ae65518b26ba0468fe0ee34
SHA-1  0b84155f0696727b34f4e616def0d7b2e44e7ad1
