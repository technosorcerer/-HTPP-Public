DOOM 64: Complete Edition
=========================

Version 1.0

The focus of this hack is to bring features from Nightdive's 2020 Doom 64 remaster (https://doomwiki.org/wiki/Doom_64_(2020_version) into the original game.

Highlights
----------

- Includes the new levels introduced in the 2020 release (The Lost Levels episode, Panic fun level).
- Option to turn off the three-point texture filter, or filter only skies.
- Option to run automatically when using the D-Pad, or using the Run button to toggle running.
- Option to toggle green blood from the japanese version.
- Option to toggle medikit, stimpak and berserk sprites with a blue cross from the 2020 version.
- Display secret found messages, artifact found messages and regular messages at the same time, with different colors.
- User configuration, including controller bindings, is now saved per saved game.
- Adds an entry to the main and game menus to load saved games at any time. The password menu is now only used to enter passwords.
- Restored the unused second medikit pickup message.
- Default brightness is now 100%.
- No demo desyncs.

In addition, the following extra features were added:

- Restored the third zombie sight and death sounds.
- Support for the Expansion Pak for resource intensive maps.
- F3DEX2 rendering microcode, improving frame rate.
- A fifth difficuty: Hardcore! that enables fast monsters and gives extra ammo.
- Additional cheats in the Features menu, including one to give all artifacts and change difficulty.

Patching
--------

There are two versions of the patch included:

a) doom64-stripped.bps:

This patch does not contain any extra levels or sprites for green blood and alternate medikits, only the quality of life features.

Apply this patch to a clean Doom 64 (USA) (Rev 1) No-Intro rom (SHA1 6FB0CE9C75BBE54B6E1EDE337652B0221E5F2AAD).

b) doom64.bps:

This patch contains everything the stripped patch does, and adds resources exclusive to the 2020 remaster (Lost Levels episode, option to use green blood, toggle alternate medikit sprites).

You need to own Nightdive's 2020 remaster in order to apply this patch. Because of this, applying it requires additional steps. Carefully follow these instructions:

- Apply doom64.bps to the DOOM64.WAD file inside the 2020 release installation folder (SHA1 D041456BEA851C173F65AC6AB3F2EE61BB0B8B53).
- Rename the newly generated file to give it a bps extension (e.g temp.bps).
- Apply the new patch (temp.bps) to a clean Doom 64 (USA) (Rev 1) No-Intro rom (SHA1 6FB0CE9C75BBE54B6E1EDE337652B0221E5F2AAD).
- Use the generated rom to play.
