﻿Dezaemon 3D English Translation
  A full English translation of Athena's only fully-3D SHMUP creator, featuring over four and a half hours of tutorial dialog, translated sample games, and a number of bug fixes.  It's also remains completely compatible with the 64DD.
  Translation by Whowasphone404, hacking by Zoinkity.

Table of Contents
line  26	.: Features :.
line  27		[Provided Files]
line  44		[Known Bugs Corrected]
line  58		[Known Bugs Remaining]
line  69		[Additional Features]
line  84	.: Patching :.
line  91		[Original File Checksums]
line  97		[Patched File Checksums]
line 104	.: General Gameplay Notes :.
line 116	.: Emulation :.
line 134	.: Hardware (64DD & Flashcarts) :.
line 145	.: DezaIO Fileserver :.
line 159		[Some Boring Technical Details]
line 183		[Controls & Features]
line 239	.: The Hidden Sample Game - RAMSIE :.
line 270	.: Screenshot Feature :.
line 287	.: Custom Editor Wallpaper :.
line 302	.: Default Filenames :.
line 332	.: Release Log :.

.: Features :.
  [Provided Files]
  "Dezaemon 3D (USA).xdelta"
    The patch file.  Apply with a version of xdelta made in the last decade (version 3.0.8 or up).
  "file formats.txt"
    Documentation on the various file formats data is stored in.  Note some fields are still incomplete.
  "Tools/DezaDiskTool.exe"
    64bit Windows executable to build and extract files from Dezaemon 3D Save Disks.
  "Tools/readme.txt"
    User's guide for DezaDiskTool.
  "Scripts/DezaIO_CartMapper.js"
  "Scripts/modules/CartMapper.js"
    Fileserver IO implementation for scripting-enabled versions of Project64.  See ".: DezaIO Fileserver :." for more details.
  "Scripts/sram"
    Blank SRAM copy if required by the fileserver.  Move into the working directory.
  "64drive/menu.bin"
    Modified version of the 64drive's official final menu release (1.14h) with added save support.
  
  [Known Bugs Corrected]
  Considering the complexity of Dezaemon 3D's highly-conditional code, there are surprisingly few bugs present to begin with and fewer yet that are critical.
  These known issues have been corrected:
  *) In the Build/Player/shot/shot2, the tooltip for animation frame 3 used #4's second line, #4 had no second line.  A unique string was added to correct this.
  *) In Paint/Palette, color bars had no tooltips unlike the various other color pickers.  Most of the palette window lacks tooltips but that's probably intentional.
  *) The memory meters in the player, enemy, map, title screen, and ending editors will no longer "point" as if they are selectable.  In an earlier version, these likely listed individual editor memory usage within a global Build Tool data file.  Their data is actually spread across three files: CBL for some common build data, *BL for stage-specific things like layouts, and GAM for some global elements.
  *) The default save file no longer sets two tutorials as complete.
  *) Corrects the stage number limit for USAGI-san in the Model Tool built-in library.  When advancing forward (and only advancing forward) 8 stages were reported, not 7.  "Stage 8" would load stage 7's data.
  *) The data level up icon in the 64DD file select menu's copy is now disabled at the top level (dark, does not point).  Likewise, non-interactive tooltips in this menu (filename, memory meter, disk capacity, etc.) no longer "point" as if they are selectable.
  *) Closed a common collision in the SRAM writeback test.  It's far likelier to discern a dead battery from nonexistent or damaged SRAM and now has a visible message.  Originally, it would quietly reinitialize every play and disable saving without telling you!  Hanging on an error message is more ideal than quietly throwing your work away.  If you repeatedly get an error, check your SRAM exists or that your emulator is using banked SRAM.
  *) Tutorial autowrap could corrupt line advancement when backstepping dialog.  Explicit newlines were unaffected.  The logic was adapted, but more to the point the script was written so the situation doesn't occur.
  *) The tutorial for the 64DD File Select screen was not set to use that menu!  The correct menu is now displayed by adding a mechanism so tutorials can run outside of ROM mode.  As a consequence, the 64DD tutorials are only viewable now if the correct disk is inserted.
     Please note though a 64DD release could overload the tutorial menu with one including actual 64DD content and adapt existing content for the layout changes on the main menu, etc.  It would almost be a requirement; the file select screen normally crashes if used in ROM mode for lack of disk data to parse.  Replacing placeholder content is par for the course in other expansions like Pocket Monsters Stadium or F-Zero X.

  [Known Bugs Remaining]
  Assume any unlisted bugs are unknown to the writer!  These are bugs in the software only, occurring on console and emulation.
  Known or suspected bugs not corrected include:
  *) Unpatched because the exact behavior can't be consistently replicated is a file fragmentation error that can occur with disks when very specific file types and attributes are set.  It isn't known to affect normal use.  Potentially related, it's suspected that RAM entries should be clearing a particular filetable flag when deleted.
  *) The save data used for tutorials can, situationally, replace original data during the game edit main menu tutorial if exited at the wrong state.  This can't be virtualized in a realistic manner, and a similar problem applies to DISK mode.
  *) If you did save more than 50 games on a disk the remainder are unselectable.  However, depending how they are listed the high scores may be tracked incorrectly.  When games are deleted and the later entries become available, this may corrupt the scores.
  *) Only (realistically) a problem for emulation, the tutorial covering the game edit main menu will glitch when the "save" button is pressed if the save does not complete in the expected amount of time.  It is possible--but highly unlikely--dodgier hardware implementations of the save type may also cause this issue.
     Whether this occurs is based entirely on implementation.
     With actual hardware, the only impediment to saving on SRAM is bus access.  Some emulators still use direct filestreams instead of buffering the data and writing it back asynchronously (either later or at close) at simulated speed.  Disks are slower than a sea of transistors and you don't have exclusive access; effectively any game that uses SRAM or FLASH (especially FLASH) writes the data back at a fraction the expected speed.  Normally games wait for save operations to complete (when they aren't made by HAL) but there's always an edge case like this one.
     The side-effects in the tutorial are twofold.  The options window for the portion involving the wallpaper and BGM won't be open (though the remaining parts can be viewed, unless...).  Secondly--and most problematic--is that the tutorial can continue beyond that while saving completes in the background.  Depending how quickly you proceed (by mashing B) more demos in the tutorial may glitch, and it's possible to quit the tutorial in a way that results in a corrupt save.

  [Additional Features]
  Other additional features or changed behavior:
  *) The first of the two 64DD tutorials is presented more as a commercial than a simple description of how the data limits have changed.  It's also not reliant on any 64DD features.
     64DD tutorials are locked until all other tutorials have been viewed and a drive + correct disk are present (a side-effect of using a linear topic list), so a choice was made to move this tutorial into the secret appendix instead.  It's a fun tutorial and filled with what they didn't yet know were lies ;*)
  *) To make up for moving the above tutorial, added in a third 64DD tutorial covering file copy features, data levels, and touching on user data and file types.
     This tutorial WILL break if you don't have any files on your disk at all.  A retail disk would have had at least a couple sample games.  A virtualized filetable could have been made and conditionally attached somehow.  At any rate, it's a very helpful tutorial and worth throwing a UserError.
  *) Some actual acknowledgement that RAMSIE exists once it's unlocked.
     +) A tooltip for RAMSIE on the Game Select screen was added, shown only when unlocked.
     +) Adds an option to copy its stage data when creating a new stage in the editor's main menu.
     +) Once unlocked, its data is available in the model library.
  *) File locks are now bitflags.  Originally, a lock of 1 made it read-only (only in Game Select menu) and 2 or more made it completely hidden.  By using bitflags instead you could have a resource-only listing (like the sample games) that aren't in the play menu.
  *) Scroll tutorial topics with C-Up and C-Down.  It doesn't making a ticking noise, only works on taps and not holds, but it does scroll.
  *) PUCODE, a message to the debugging staff from the developers, was remapped to a filesystem index.  There may be a way to view it...


.: Patching :.
  The patch will only apply to an original, unmodified ROM in native byte order (big-endian).  Attempting to patch something else will result in a completely unhelpful checksum error.
  Xdelta patches can be applied with the aptly-named xdelta patcher; use version 3.0.8 or up.  (In other words, one from the last decade.)
  Please note that this patch is incompatible with the "disk conversion" patches released a decade ago.  *DISKCARTS ARE DEPRECATED.*  However, it is completely compatible with the "Dezaemon 3D Save Disk" via either original hardware, emulation, or hardware emulation.
  Common Name
  	Dezaemon 3D (Japan)

  [Original File Checksums]
  SHA-1
  	1C10A85A2B6A782E6302B19C2387E2D58983A8D4
  SHA-512
  	5CC13260A04CE3E596BA3F218FE29B7D80FFA76F288FF5F2B0077554C9C85A289ABDF7087F070E13064A5F18DE3EC57331C36D5074E607BEE914BDC830B6C334

  [Patched File Checksums]
  SHA-1
  	04D0423ED9C143DC33AAA16835D6F8019F1720BB
  SHA-512
  	77CB35BB4F3DEF7342BFF8466B95B73CA0BAF01B7CAB1F1777B12F8F721A28640137D2ABD9D3BF281BC5936F89FE76B3149981ED4D0D2DE1D918275D30809D9B


.: General Gameplay Notes :.
*) This game can be run with either 4MB or 8MB of RDRAM, 8MB recommended.  Some internal behavior changes between these modes, usually a matter of copying data permanently to memory instead of repeatedly reading from ROM.  8MB is required to use with a 64DD.
*) All saved data on both cartridge and disk is compatible with the Japanese game.
*) A N64 Mouse can be used if plugged into Controller Port 2 before the game starts.
   When a mouse is detected, the Control Stick on Controller 1 will be disabled.  Controller 1's A Button is remapped to Z, and the B Button is remapped to R (effectively, B will still function on both the controller and mouse).  All other controller buttons remain enabled, and if you use an extended, modern mouse those buttons will be combined with it.
*) In DISK mode there is a limit of 50 games.
*) If a disk does not have a DEZA3D.SYS file, it copies the required data from the cartridge save file.  This way, your existing game settings are carried over to the disk and it's no longer tied to a battery-backed device.
   If the cartridge save is corrupt, uninitialized, or non-existent the copy will fail and an error will be displayed.  The error can't be corrected or circumvented as long as a disk is present.
   Initializing your disk erases and recopies this file; it's the most common cause of the problem.
   The easiest way around this is to start the game without the disk (either eject it or remove the drive), initialize your cartridge's save file or otherwise repair it, reinsert the disk, press the Reset button, then try the disk again.  Using a soft reset instead of cycling the power ensures that in the event your battery died the initialized save is still valid.


.: Emulation :.
*) Please refer to https://64dd.org/ for up-to-date information on emulating 64DD support.  This website also provides information on how to play combo cart & disk games on certain flashcarts.
   DISK mode cannot be recommended enough!  Vastly more is possible when a 64DD is used!  It was literally the way it was meant to be played; this game was originally a pure disk.
*) If your emulator uses an external file for settings (as many do), refer to its documentation on how to copy the original game's settings to a new entry for this translation.  Likewise, some plugins keep settings in an external file as well.
*) For scripting-enabled versions of Project64, an implementation of the debug fileserver is provided.  Read "DezaIO Fileserver Feature" below for more details.
*) Whether the fileserver screencapture function saves more than a black screen is dependant on how the emulator simulates the framebuffer.
*) Depending on how SRAM writeback is implemented, it may take significantly longer for an emulator to save than cartridge.  This is known to cause a glitch in one of the tutorials, as outlined in "Known or suspected bugs not corrected" above.
*) Dezaemon 3D uses a unique banked SRAM x3 save type that some emulators fail to support (especially older ones).
   A telltale sign is if DMA/hardware address errors appear after the Athena logo.  In most cases the new "Backup RAM Hardware Fault" message will appear when the wrong configuration is used.  If it isn't supported, expect these fairly serious errors:
   +) In ROM mode, until data spans to the other two units it may false-positive and give the appearance saving is supported.  Once data is large enough, either: (1) the game will throw an error and crash, (2) data will be lost, and/or (3) an invalid checksum error will be thrown on next boot, displaying the "SRAM must be initialized" message.
   +) In DISK mode, do NOT reinitialize the disk!  See the "DEZA3D.SYS" section of the "General Gameplay Notes" above for more information.
*) Some HLE graphics and RSP plugins fail to display all of the editor's graphics correctly.  If you're experiencing dropped graphics or object selection errors, consider using LLE (like angrylion).  Remember that Intel integrated graphics can have issues that are not present with Nvidia and AMD GPUs, plus outdated drivers can also cause issues.
   +) The most common (and critical) issue will be models either not appearing in the Model Tool's views or all four views being displayed simultaneously in the upper-left corner.  This makes model editing impossible.
   +) Some graphics plugins won't display basic 2D text, such as warning messages at boot, due to the way it refreshes (or doesn't).  This goes underreported with other games, especially with at-boot Controller Pak managers.  Dezaemon 3D uses these messages for disk errors, save errors, and initialization prompts among other things, and incompatible plugins will display a blank screen.
   +) Among non-critical errors, some have trouble rendering the water effect on the title screen (likely an RSP issue).  Others may threshold alpha in certain image types or under certain conditions, especially with text.  Others drop lines at the bottom of images or suffer tearing, leaving streaks or gaps between large tiled images.
   +) Selection errors come in two forms.  One is when the plugin misaligns 2D & 3D elements like the grid in the Paint & Model tools and tile selection.  The other is inconsistent draw distances.  Models may be drawn incorrectly in the Model Tool in such a way that your cursor does not align with the model below.  This makes selection by users difficult but not impossible, but is known to glitch parts of the tutorials.


.: Hardware (64DD & Flashcarts) :.
*) The game expects a Japanese retail drive or development drive.  Unreleased USA drives are not recognized and doing so would pointlessly complicate disk support.
*) It also requires an unreleased "Dezaemon 3D Save Disk".  A disk generator is provided along with the patch or you could use one of several recovered prototypes.  Prototypes expect a development drive; the disk generator can make Japanese-region disks.
*) SummerCart64 supports emulating the 64DD!  An up-to-date tutorial on setting up and using 64DD support can be found at: https://64dd.org/tutorial_sc64.html
*) This game requires banked SRAM x3, aka 768Kbit SRAM.  This type is supported by the three most modern flashcarts as of 2024: EverDrive64, 64drive, and SummerCart.
   +) For 64drive users: you have three choices.  First is using direct mode, manually setting 768Kbit support and, optionally, uploading a save.  If you're intending to use a menu instead, either use a "universal menu" or the provided, modified version of the official final menu release (1.14h) in the "64drive" directory.  This changes the ID test to exclude region and adds save support for a few more games you may or may not have.
   +) For other devices: please refer to your flashcart's documentation or support forum on how to set or force the correct save type.
   +) Older Bung copiers require the original cart for proper save support.  It's the only one of its kind, after all.  Attempting to use any other format or workaround is at your own risk, but anyone still rocking these devices probably knows the schtick.
*) Please note that in the recovered prototype disks, SAMPLEZ1 & SAMP's GAM file data has slightly different, incompatible formatting.  Copying them is very likely to corrupt your disk data when accessed, but the files can be repaired fairly easily when edited external.


.: DezaIO Fileserver :.
  The game has a PC fileserver function!
  When activated, the game will request or write files to a slaved PC.
  Provided in the "Scripts" folder is a implementation of "DezaIO" for use with scripting-enabled versions of Project64 4.x (maybe only development versions at the moment?).  It relies on modules written by Seru-kun of 64DD.org, and I'd like to thank them for testing the script--something I can't do with my PC.
  (Refer to the "JS-API-Documentation" portion of Project64's documentation for the proper settings to enable scripts as this may change over time.)

  *To turn on the debugger, enter the Build Menu and put the cursor in the upper-right corner.*
  Enter this button sequence (C-Up, C-Down, C-Up, C-Down, C-Left, C-Right, C-Left, C-Right) to toggle the debugger on & off.
  A sound will chime and the game *will halt* until communication with the attached device is established.

  !IMPORTANT!
  Do NOT try to activate the fileserver unless connected to a PC!
  As soon as you insert the button code it will wait until the connection is initialized, potentially softlocking the game!
  
  [Some Boring Technical Details]
  There are two interfaces, one tied to hardware address 11000000 from its 64DD-only days, and a second tied to a "fourth" SRAM bank address at 080C0000 when the game was converted to cartridge.  The debugger address is determined by 801FF43D[0], byte 0xD of SRAM block 11.
  By default the value is 0, selecting 11000000.  To set it to 1 and use 080C0000, hold all the C Buttons down when changing the editor's wallpaper.  To revert it, change the wallpaper again without holding the buttons.  Note this is also how you can use one of the textures from the Paint Tool's image band as a background in the editor.
  The original hardware is unknown, but likely just a generic UART.
	080C0000 / 11000000	value f/ PC -> N64
	080C0004 / 11000004	value f/ N64 -> PC
	080C0008 / 11000008	status, likely tied to the microcontroller's transmit/receive interrupts; 1 when PC posts a byte, cleared either on read or N64 transmit depending how they rigged it.
  One byte is interchanged at a time using this algo:
	while not @base+8 & 1:  pass
	input = @base+0
	base+4 = output << 16
	return input & 0xFF

  To initialize the fileserver, the console sends 0x20 until it receives 0x10, then sends 0x10 until it receives 0x20.  This will loop until it completes, so do not turn on the debugger without an attached device!

  Read & write requests are sent using two packets.  The console will send a request packet first, always 0x5C bytes:
	0x0	4	type (1:[unused], 2:read f/ debugger, 3:write to debugger)
	0x4	4	length
	0x8	4	0
	0xC	0x50	filename
   This is followed by a read or write for the given length in the request packet.

  Implementing the hardware itself is relatively simple.  In the case of the "SRAM" type, note the next pin is available and functional on the LVX138 for use as an enable pin for a microcontroller.

  [Controls & Features]
  General:
    Certain global hotkeys, notably Start, will no longer work in most menus.
    In ROM mode, local saves are ignored.  Data will be saved and loaded f/ a 0x18000 byte file named "sram" when a disk isn't present.  The game will halt until a file is provided!
    L Button	saves a screencap named "DEZA%3.3d.BMP" to debugger
    (Note this is different from the screenshot feature.  It creates a bitmap from the framebuffer and may not work with all emulator configurations.)

  When switching menus (loading files):
    Hold R	read "tut.bin" (0x10000) f/ debugger in addition to (most) other files.
		To use, hold R while transitioning into a menu to load a tutorial set on that editor's page.  Note this also works within games.

  In TUCODE.SYS or when manually loaded as above: (Tutorials)
    Enables tutorial script command 19, used to record controller input.  This is how the tutorials were recorded.  Once recorded, replace them with playback command 8 and the correct record index.  An N64 Mouse is highly recommended.
    Replays (i.e.: tutorials) will use "key%3.3d.bin" instead of the file on cartridge.
    In standby:
      + Left	[stop]   Press to quit recording and continue the script.
      + Right	[record] Always returns to the original position before re-recording.
      + Up	[play]   Read "key%3.3d.bin" f/ debugger (0x1000); replays input from the original start position.
    While recording:
      + Down	[pause]  Stops recording and writes "key%3.3d.bin" to debugger.  File is automatically flushed when size exceeded.  Returns to standby but you will be able to move the cursor to restore the editor's state if necessary.

  In MDCODE.SYS: (Model Editor)
    In root menu:
      Hold R, press C-Up	deletes all untextured faces
      Hold Z, press Start	write model as "test.de2" (0xC20)
      Press Start		read model "test.de2" (0xC20)
    In paint submenu:
      Hold R, press Start	read "bg.img" (0x8000), replacing eight image blocks
      Hold Z, press Start	write "test.img" (0x1000)
      Press Start		read "test.img" (0x1000), replacing one block (64x32)

  In OPCODE.SYS: (Opening: Athena logo, 64DD test, warning messages, title screen, root menu, attract sequence)
    R Button	replace	BG image (water effect) with "op.img", a 32x32 c16 image
    C Buttons	rotate BG image
    + Up/Down	scale BG image

  In BMCODE.SYS: (Build Menu)
    Hold Start, press C-Left	write cur. game files to debugger (GAM, CGR, CMD, CBL, ULB, MUS, *GR, *MD, *BL)
    Hold Start, press C-Right	read game files f/ debugger (GAM, CGR, CMD, CBL, ULB, MUS, *GR, *MD, *BL)
    (also see button code to enable debugger above)

  In MUCODE.SYS: (Music Editor)
    Hold Start, press + Up	write cur. song as "BGM_**.BIN" (0x2C9A)
    Hold Start, press + Down	read cur. song as "BGM_**.BIN" (0x2C9A)
    Hold Start, press L		In music track editor, rolls loudness of instruments up one level, wrapping around, and copies cur. audio (802BA1C0) to audio buffer.

  In GSCODE.SYS: (Game Select)
    Hold Start, press C-Up	read & execute {filename}.EXE f/ debugger

  {filename}.EXE works the same as the EXE files on disk: it's a "program extension", aka "plugin".  It loads and runs a block of code--the same as each of the editor/menu pages.  No restrictions!
  The hiccup here is that an entry for the file must already be added to the filetable.  The file length is read from the entry and the N64 will only read up to that many bytes from PC after posting the request.
  This thing operates within editor mode (EDMCODE), not the game code (GACODE) for created works.  It executes from 802400B0 accepting two arguments: an argument that can be set to 800C4C80[0] but rarely is, and a flag indicating if it's first run (True only right after load, so you can do init).  To stop executing it, set 800C4C87[0] to one of the other menus like 0xF, the Game Start menu.
  An example of what a code block might look like is the unused file PUCODE.SYS.  If loaded as an EXE, a message thanking the debug team is displayed.  It returns to the Game Start menu when you press Start.  In this case, 800C4C80[0] is used as the version number of the game.
  "SAMPLE01.EXE" is the default name until a game is loaded but from the PC's perspective the filename isn't important.  You don't need a 64DD to run the debugger version either, it's available via button code.


.: The Hidden Sample Game - RAMSIE :.
  There is a tooltip that reveals the button code to unlock RAMSIE!
  Instead of giving the RAMSIE code here, here's a walkthrough on how to find it yourself!
  RAMSIE is the real-world reward for decoding the silly afterward tutorial where Kenta was supposed to receive a secret raffle prize in a toilet.
  There are additional hints given for finding it in the secret appendix--if you're willing to read through all 205 randomly-selected bits of advice.  Quite frankly it's rather obscure, but here are the three hints for your amusement.  The first two are less than useful.
  当選通知の受け取り場所に書いてあるのは、どこかの地図らしいぞ!
  当選通知の受け取り場所を読むには、仏と数字に注目するといいらしいぞ!
  The last secret bit of advice is quite helpful:
  当選通知の内容がわからないうちは、へルプをオフにするのはやめた方がいいぞ
  It's best not to turn off the help tooltip function because hahaha, that's how they reveal the button code.
  The map itself reads:
受け取り場所:走仏上下止
       1234回
       5678逃
        |  逃
      48|  蛇
        ↓  突
    トイレのココ
  走仏上下止, the column Buddha is in, indicates the window you need to be on to read the message.  It refers to the "basic movement" window of the "build tools/enemy editor/motion" menu.  The icon for "fixed movement" looks like your typical sitting Buddha, sans blessing.  It also acts as a guidepost; the numbers and message are all in this column.
  トイレのココ, "in the toilet", is not the only tutorial to mention toilets.  The clue is in the tutorial covering the main menu.  In it Capt. Deza changes the background to #57 which Kenta calls "blue toilet tiles"--the first of these types of tiles in the background image list (aka toilet #1).
  Once you know the correct page and wallpaper, the map is very easy to follow.
  The "48 snakes" (蛇) line refers to the number of pixels between the speed buttons and the hidden message, roughly translating to the same number of taps of the down arrow.  Each line of text on the map denotes 16 pixels.  Using "snakes" is a bit of a red herring though; they're mentioned several times in the Music Tool tutorials.
  Shown on the map is the number pad for the speed setting.  The arrow is drawn down through the "2" and "6", leading 3 rows down (48 pixels) to the hidden message.
  突 can mean poke or plunge, and in this case refers to pointing with the cursor.
  
  In short!:
  To show the tooltip, you must set the editor's background to #57.  Open the Build Tools, select the enemy editor, select "motion", then "basic motion".  Under these *exact conditions* it replaces the pointers to the tooltips in the main enemy editor window behind it with a set that maps a tooltip to an 8x8 invisible square at (54, 208) to (62, 216).
  To view it, line up the index finger of your cursor with the center of the numbers; the easiest line to follow is the point where the hands of the "fixed motion" icon meet (the sitting "Buddha").  Slowly move straight down to the bottom of the screen, easiest with the +pad.  ~80% of the way down--48 pixels below the number pad--the hand will point, revealing the code.
  To unlock the game, go to the Game Select menu, move your cursor over the dark cartridge image, and enter the button code.


.: Screenshot Feature :.
  This feature was mentioned in the 205 randomly-selected pieces of secret advice.
  なんと、画面キヤプチヤー機能があるらしいぞ。ほんとうなのか?!
  By holding the L Button and pressing C-Up, you can capture part of the screen as an image.  It's saved to the Paint Tool User Library.  Yes!  It is, in fact, useful for something!
  Controls:
    Control Stick	Move the capture region box.
    Start Button	Save the region to the User Library, closing the box.
    B Button		Cancel screenshot, closing the box.
    C Buttons		Resize the capture region box.

  Screenshots can be taken of gameplay or most editor windows.  Exceptions include the opening and Paint Tool.
  When first activated, the game pauses and a box the size of the User Library image (128x128) is drawn on-screen.  Reposition this box with the Control Stick.  The C Buttons will change the region's dimensions.  If the selected region is smaller than 128 pixels it will be copied normally and the remaining space filled with alpha.  If you stretch either side so it's larger than 128 pixels, that side of the image will be scaled-down to fit into this space.  Press Start to copy the data or the B Button to cancel.  No other buttons are read.
  Once copied to the Paint Tool User Library, press the "Paste from Buffer" button (the up arrow) to copy the saved screenshot and paste it into the image band.
  
  Even in DISK mode, the Paint Tool User Library is not saved at power off.


.: Custom Editor Wallpaper :.
  This feature was alluded to in the 205 randomly-selected pieces of secret advice.
  なんと、力ベ紙エディット機能があるらしいぞ。ウソテクではないのか?!
  A custom wallpaper can be selected from the images the user can edit.  In ROM mode this is only the first 18 64x32 texture blocks in the Paint Tool.  In DISK mode, all 80 wallpapers can be replaced without issue.
  To use this, hold all of the C Buttons on controller 1 down when changing the wallpaper by clicking the left or right arrow.  The selected 64x32 texture will be tiled on the screen.  To revert the change, simply change the wallpaper number without holding the C Buttons.
  Changes to common image data directly affect the background.  Editing the image or loading new data will both cause this.  Images are counted top to bottom, left to right (1 & 2 in the first row, 3 & 4 in the second, etc.)

  Also, this flag is used to change the base address (and therefore the hardware used!) for fileserver IO.
  
  There are a few caveats to using this feature in ROM mode.
  When no disk is present, only the first 18 64x32 textures can be used for wallpapers.  In other words, only the images with orange numbers you can draw yourself.
  Any image number past 18 will "cap" to 18, and the wallpaper is not applied to the opening, tutorial, game select, or 64DD file select screens.  Instead, the normal wallpaper for that value is applied.
  In DISK mode all wallpapers can be replaced but the wallpaper number remains the same across all of your projects.  You can also set a stage-specific image, so the wallpaper can change between each stage of each project you're working on.


.: Default Filenames :.
  In the 64DD File Select menu, if you hold B+Z+L+R when clicking "New File" one of several default filenames will be used.  These increment, but note some names are nothing but spaces.
  The names are: 
01  "SAMPLE01"
02  "SAMPLE02"
03  "SAMPLE03"
04  "SAMPLE04"
05  "SAMPLE05"
06  "ATHENA  "
07  "DEZAEMON"
08  "KIWAME  "	As in "Pro Mahjong Kiwame".
09  "PERON   "	This is the name of their green rabbit mascot.
10  "OWARI   "
11, 12, 13, & 14  "        "

  After #14, if you hold B+Z+L when clicking "New File" (no R Button) these strings will be used.  Otherwise, the list wraps back around to the top if you hold B+Z+L+R.
15  "        "
16  "MOCHA   "
17  "HOTEHOTE"
18  "KUMACHAN"
19  "RIKACHAN"
20  "GANCHAN "
21  "3JIKAI  "
22  "MEMBER  "
23  "98▼2▼10 "
24  "SHIGE   "
25  "TOKKO   "
26  "THANKYOU"


.: Release Log :.
2024.09.12	initial release

