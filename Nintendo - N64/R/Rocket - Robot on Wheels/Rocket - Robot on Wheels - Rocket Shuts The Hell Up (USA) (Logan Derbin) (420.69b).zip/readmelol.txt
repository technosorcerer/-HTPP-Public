Rocket: Robot on Wheels is a cool game, but there's a few awful horrible no-good repetitive sound effects that become really grating over time. This lil' patch does the following:

Rocket's "Whoo-hoo!" vocalization during double-jumps has been removed.
The awful "swish" sound that happens when adjusting the camera with the C-buttons has been removed.
The "Get Health" sound effect has been slightly reduced in volume (Shit was loud).

All other sound effects are untouched.

If you really really hate Rocket's vocalizations, there's also a "Rocket Shuts the Fuck Up" patch that makes the little bastard mute forever. This approach is a little heavy-handed, though - It feels a little weird to play a platformer with no jump sound.

Rocket a great game, and I'm glad you'll be able to enjoy it without those little audio microaggressions. Have a good time!


Filename: Rocket - Robot on Wheels (USA).z64
CRC-32: e0399f23
SHA-1: 622d71a44da0b81ea68092cac9198c66154a4f4a


PS: This is for the US version only right now, sorry. Maybe one day.