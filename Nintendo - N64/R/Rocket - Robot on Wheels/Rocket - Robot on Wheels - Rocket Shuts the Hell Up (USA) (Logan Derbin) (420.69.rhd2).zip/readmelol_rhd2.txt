

Rocket: Robot on Wheels is a cool game, but there's a few awful-horrible-no-good sound effects that become really repetitive and grating over time. This lil' patch does the following:

- Removes Rocket's "Whoo-hoo!" vocalization during double-jumps.
- Removes the awful "swish" sound when adjusting the camera.
- Slightly reduces the volume of the "Get Health" sound effect (It was WAAAY too loud in the original release).

All other sound effects are untouched.

If you really REALLY hate Rocket's vocalizations (same lol), there's also an alternative patch included called "Rocket REALLY Shuts the Hell Up" that removes EVERY single one of Rocket's vocalizations, making the little freak completely mute forever. This approach might be a little heavy-handed, though - It feels a weird to play a platformer with no jump sound. But you get used to it. This is my preferred way to play.

Rocket is a great game, and now it can be enjoyed without those little audio microaggressions. Have a good time!



PS: This patch is currently only for the US version of the game. Sorry about that. Maybe one day.



PSS: Rocket: Robot on Wheels doesn't directly credit its composer, but I'm pretty sure it's Julian Soule. The game lacks a conventional End Credits sequence, so everyone just kinda assumes that Ashif Hakik composed it (including Wikipedia), probably because he composed Sucker Punch's next game, Sly Cooper and the Thievius Raccoonus. But get this - Rocket: Robot on Wheels DOES have an end credits screen, albeit a very unconventional one. It consists of a large room filled with lil' guys bouncing around. When the player picks one up, it reveals a photo and name of one of the developers. Julian Soule appears in this room, while Ashif Hakik doesn't. The credits don't specify jobs/roles, but, like... What else would Julian Soule be doing? Unless he has a catering side-gig or something idk.

Check out his inclusion in this video of the game's credits room: https://www.youtube.com/watch?v=xKHDaCtJYRk&t=1653s

I don't know why I care so much about this. Need to up my meds, I guess.

Don't feel like updating Wikipedia to list Julian as the composer, so if/until someone does, this'll just be a fun fact shared between us. Love you, too. ;)

_____________________________________________________

Changelog:

v420.69 - Initial release

v420.69a - Bugfix to "Rocket REALLY Shuts the Hell Up": Rocket no longer vocalizes when hurt (he has no mouth, so he mustn't scream).

v420.69rhdn - Identical to v420.69a, but the readme and patch filenames are sanitized for romhacking.net's "no naughty words" policy. Edits are surrounded by asterisks. I kept "Hell" in, though - there's like a hundred "Hell Mode 😈" hacks on Romhacking.net, after all!

v420.69rhd2 - Identical to v420.69a, but the readme and filenames are sanitized for romhacking.net's "no naughty words" policy. Edits are a lot less stupid now. I was bitter about it before, so I initially made the edits really dumb and corny. but I'm over it now - a pint of Ben and Jerry's calmed me down.