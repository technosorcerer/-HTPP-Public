Rocket: Robot on Wheels is a cool game, but there's a few awful-horrible-no-good sound effects that become really repetitive and grating over time. This lil' patch does the following:

- Removes Rocket's "Whoo-hoo!" vocalization during double-jumps.
- Removes the awful "swish" sound played when adjusting the camera.
- Slightly reduces the volume of the "Get Health" sound effect (*Hot-dog, it* was loud).

All other sound effects are untouched.

If you really REALLY hate Rocket's vocalizations, there's also a "Rocket Shuts the *Gosh-Diddly-Darn-Heck* Up" patch included that removes every single one of Rocket's vocalizations, making the little *lilly-livered raggamuffin* completely mute forever. This approach might be a little heavy-handed, though - It feels a weird to play a platformer with no jump sound.

Rocket is a great game, and now it can be enjoyed without those little audio microaggressions. Have a good time!

PS: This patch is currently only for the US version of the game. Sorry about that. Maybe one day.



PSS: Rocket: Robot on Wheels doesn't directly credit its composer, but I'm pretty sure it's Julian Soule. Everyone seems to be under the assumption that it's Ashif Hakik (including Wikipedia), probably because he composed Sucker Punch's next game, Sly Cooper and the Thievius Raccoonus. However, Rocket: Robot on Wheels DOES have an end credits screen, albeit a very unconventional one. It consists of a large room filled with lil' guys bouncing around. When the player picks one up, it reveals a photo and name of one of the developers. Julian Soule appears in this room, while Ashif Hakik doesn't. Julian isn't credited directly as a composer (none of the developers' roles are specified), but... What else would he be doing?

Check out his inclusion in this video of the game's credits room: https://www.youtube.com/watch?v=xKHDaCtJYRk&t=1653s

I really can't be bothered to *be a-heavin' and a-hoein'* around with Wikipedia right now (especially considering my only source is the game itself, and Wikipedia isn't crazy about people using video sites as sources), so if/until someone does, this'll just be a fun fact for you between us. ;)

_____________________________________________________

Changelog:

v420.69 - Initial release

v420.69a - Bugfix to "Rocket Shuts the *Gosh-Diddly-Darn-Heck* Up": Rocket no longer vocalizes when hurt (he has no mouth, so he mustn't scream).

v420.69rhdn - Identical to v420.69a, but the readme and filenames are adjusted to adhere with romhacking.net's submission requirements. Edits are surrounded by asterisks. The word "Hell" remains, though - there's like a hundred "Hell Mode 😈😈" hacks on Romhacking.net, after all!