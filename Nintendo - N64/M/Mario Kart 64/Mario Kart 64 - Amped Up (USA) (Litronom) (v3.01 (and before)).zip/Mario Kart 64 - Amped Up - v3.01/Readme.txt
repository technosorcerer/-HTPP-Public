			Mario Kart 64 - Amped Up version 3.00
					Made by Litronom

*This is a mod for the game Mario Kart 64.*

It features:
-16 brand new courses
-5 additional game modes,
-fully animated 3D racers
-modern visuals
-groovy music
-customization settings
-unlockables
and much, much more!


*Available game modes*

For Grand Prix:
-Default
-Elimination Mode
-Balloon Race

For Versus:
-Default
-Elimination Mode
-Balloon Race

For Time Trial:
-Default
-N64 Coin Mode
-Target Zones
-Mini Turbos

For Battle:
-NOT AVAILABLE RIGHT NOW


*Download*

Get this and other mods from this archive:
https://mega.nz/folder/9BB32Cib#ISfFcu6hrF7CCl-2FTHaAA


*Installation*

Patch *Mario Kart 64 (U) [!].z64 (CRC32: 434389C1)* with the provided .bps file. Either use https://www.marcrobledo.com/RomPatcher.js/ or flips.exe or whatever patcher you prefer



*Configuration for Emulators and Consoles*

Enable 8MB Memory on emulator or plug in an Expansion Pak on console.
Enable 16k EEPROM.
The 60 FPS option is an experimental mode for emulators and needs specific settings to change the cycle speed.
On Project64 set "Counter Factor" to 1 and "VI Refresh Rate" to 2200.
Please look out for similar labeled settings in your emulator of choice, if you wish to enjoy good performing 60 FPS gameplay.