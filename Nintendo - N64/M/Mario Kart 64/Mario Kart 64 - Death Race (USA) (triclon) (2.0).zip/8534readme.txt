================================================

Mario 64 Death Race v2
by Triclon

================================================

The Death Race is rom hack for Mario Kart 64 inspired by the Death Race in F-Zero X.  Each player gets 3 hit points (HP).   Spin outs, hits, getting squished, or having Lakitu picking you up causes 1 HP worth of damage.   If you have 1 HP left, you turn dark to indicate one more hit will kill you so be careful.   Lose all your HP, you are dead, and the course restarts in GP mode.  The race will not end until one player is left standing.  Kill all the players and you win, and you go to the next course in GP mode.  Death Race is playable in both GP and VS modes.					

This is one of the most complex Nintendo 64 Gameshark codes I have created. The idea behind this started in the Discord64 chat. A user suggested I make a Death Race code, most likely as a joke, akin to the Death Race in F-Zero or Mario Kart 8’s battle mode.  I thought it was a cool idea so here it is in its full glory.  

There are four versions of the Death Race.  You can either play regular or with the "CPUS use human items" hack (https://www.romhacking.net/hacks/8317/) where CPUs can use shells and other items they normally can't in for an added challenge.  There is also a "Wii" version of each for if you are going to play on a Wii emulator such as Wii 64 or Not64 or on some old emulators.

The Google Sheet where the Death Race Gameshark code was developed can be found here if you want to see how it all works and learn how to modify it yourself:
https://docs.google.com/spreadsheets/d/1cuM45MkzCfLQxO2rnUA52XEoV3L_LJlOTRigrV_HfYM/edit?usp=sharing

================================================

HOW TO PATCH

-You will need a USA/NTSC Mario Kart 64 rom in the .z64 format
-If you are using the Wii or possibly an older emulator, use the patch MK64_death_race_v2_patch_Wii.bps, otherwise for everything else including modern emulators and console use MK64_death_race_v2_patch.bps
-For an added challenge, use the "CPUs use human items" version of the above patches.
- Apply the .bps patch to a (USA/NTSC) Mario Kart 64 rom that is in .z64 format using your own patching utility or one of the following fine online Patchers:
https://www.romhacking.net/patch/
https://hack64.net/tools/patcher.php
- Some emulators can also soft patch a .bps file to a vanilla rom

OR USE THE GAMESHARK CODE

The gameshark code that is the Death Race can be found in gameshark_code.txt.  One advantage of using the gameshark code is you can add in your own gameshark codes as well to modify the game.  You can copy directly into your emulator cheats.  It works in mupen64 and it's various derivatives, but it is not guaranteed to work in all emulators such as Project64.  You can also inject it into a rom yourself using my N64 Gameshark code Injector:
https://www.romhacking.net/utilities/1659/

================================================

Questions, comments, or found a bug?
Email me at triclon@gmail.com

Want to keep up on the latest Mario Kart 64 hacking scoop? Join the OverKart 64 Discord 
https://discord.gg/7dKKsnr4yU
Be sure to checkout the #death-race channel!

Visit my YouTube channel: https://www.youtube.com/user/triclon

Visit my website: https://triclon.neocities.org

================================================


TROUBLESHOOTING

DEATH RACE REQUIRES THE EXPANSION PAK (8mb):
If it doesn't boot first make sure your console has an Expansion Pak installed, or the emulator you are using has it enabled.

WILL NOT RUN ON CONSOLE:
Make sure you are using the non-Wii version of the patch: MK64_death_race_v2_patch.bps or MK64_death_race_cpus_use_human_items_v2_patch.bps.  Also make sure you have an expansion pak in your console, as Death Race requires it.

WILL NOT RUN ON THE WII:
Use the Wii version of the patch: MK64_death_race_v2_patch_WII.bps or MK64_death_race_cpus_use_human_items_v2_patch_wii.bps.

================================================

CHANGELOG
v2 
- Fixed many many crashes and bugs, especially when playing on console.
- Added "CPUs use human items" version.
- Added extra mode.
- Fixed several issues with the scoring.


v1
 - Initial Release.
