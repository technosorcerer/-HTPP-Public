================================================

Pokemon Kart 64 v1.2
by B.B.

================================================

Feel free to add, remove, remix, update etc. Everything about this mod is open to the modding community and available for making reproduction carts.

Special thanks to Dead Hamster, Triclon, Litronom, HootHoot, MtZuul, Ox, Rain, and the OverKart 64 community!

================================================

TO PATCH

You need:
Mario Kart 64 (USA).z64
and
https://www.romhacking.net/patch/
or
https://hack64.net/tools/patcher.php

================================================

CHANGELOG 8/14/25:
Added the second splash screen for extra mirror mode