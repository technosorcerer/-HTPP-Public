================================================

Battle Santa 64
by Triclon, DeadHamster, and MtZuul

================================================

Merry Christmas!

Battle Santa 64 is a special 2023 Christmas single player version of Battle Kart 64 (https://www.romhacking.net/hacks/5618/) that follows the tradition of the OverKart 64 Christmas Mod (https://www.youtube.com/watch?v=nM-kXa55EdE).

In Battle Santa 64, you play as Santa Claus trying to take back the presents stolen by Bowser, Wario, and Donkey Kong.  You have five minutes to collect as many as you can.  They will run away so you will need to chase them down, hit them, and pick up the presents they drop.  After five minutes you will see how many you have collected, what your high score is, and can restart by holding A and B simultaneously to try again.


Why did we make Battle Santa 64?
-Prototype a new "collect" game mode and test out custom objects being dropped on the course.  Here you are collecting presents, but this will likely be included in a future release of Battle Kart 64 where you must collect items from others, probably coins.
-It isn't much but the cutscene where Santa is asking Bowser, Wario, and Donkey Kong to return the presents and they refuse is the first and only custom Mario Kart 64 cutscene ever made (so far as we know).
-Showcase the ability of the N64 to play high quality (32000 Hz Stereo) music.

================================================


Questions, comments, or found a bug?
Email me at triclon@gmail.com

Want to keep up on the latest Mario Kart 64 hacking scoop? Join the OverKart 64 Discord 
https://discord.gg/7dKKsnr4yU
Be sure to checkout the #battlekart-64 channel!

Visit my YouTube channel: https://www.youtube.com/user/triclon

Visit my website: https://triclon.neocities.org

================================================

HOW TO PATCH

-You will need a USA/NTSC Mario Kart 64 rom in the .z64 format
-The easiest way to patch the rom is to go to the page for Battle Santa 64 on romhacking.net and scroll down and click "Patch Online Now"
- You can also apply the .bps patch to a (USA/NTSC) Mario Kart 64 rom that is in .z64 format using your own patching utility or one of the following fine online Patchers:
https://www.romhacking.net/patch/
https://hack64.net/tools/patcher.php
- Some emulators can also soft patch a .bps file to a vanilla rom

================================================


TROUBLESHOOTING

BATTLE SANTA 64 REQUIRES THE EXPANSION PAK (8mb):
If it doesn't boot first make sure your console has an Expansion Pak installed, or the emulator you are using has it enabled.

UNABLE TO SEE TEXT IN EMULATOR:
If you have trouble seeing the text in an emulator, try changing the video plugin your emulator is using.

WILL NOT RUN ON THE WII:
To fix on Wii64, set the option "LimitVIs = 2" on settings.cfg.  
To fix on Not64, change the  Speed Limit from VI to DL or Off.
Thanks to VeliZer0 for finding these fixes.
I have not tried VC injection so if anyone gets that to work, please let me know.

============
Credits:

Triclon - Programming, game mode, bots, cutscene, testing, and debugging.

DeadHamster - Santa Claus model, present models and programming, Christmas Kimura logo, and bot AI paths.

MtZuul - Modifying Luigi's voice to be Santa and importing Up on a Housetop music.

Individual title screen assets created by Triclon using Bing image creator, assembled in Photoshop by DeadHamster.

Up on a Housetop Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 3.0 License
http://creativecommons.org/licenses/by/3.0/