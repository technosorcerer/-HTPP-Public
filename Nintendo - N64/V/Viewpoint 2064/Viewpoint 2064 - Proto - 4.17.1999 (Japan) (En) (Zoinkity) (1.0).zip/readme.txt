﻿Viewpoint 2064 1999/4/17 Build English Cinematic Patch

  Applying this patch translates cinematics and Rumble Pak dialogs into English.
  It does not address any enormous of bugs that already exist in this game.

  Please note this is for the original public release of the 1999/4/17 master build, presumed final or near final candidate.  A separate patch has already been released for the earlier prototype.  In this version all five endings, epilogue, and credits are viewable.


.:Patching:.
  Apply the xdelta patch using the similarly named xdelta.  The patch will only apply to a ROM in native (big-endian) byteorder.  Output will be a single big-endian file, stripped to 0x1000000 bytes.
  4Kbit EEPROM is required to run the game.

Common Names:
	VIEWPOINT 2064 [NJKJ].z64
	Viewpoint 2064 (Japan) (Proto - 4.17.1999).n64
	(prototype timestamp 1999/4/17)

Original SHA-1:
	56368BBC7485F140078F1891CEDE69BD1EE2662A
Original SHA512:
	1680C5B3111B1D374E5197B4EFD7BB0B6A90B41BD8257416831661924527CF9E218A8918BE09201BA20C841357605004DCDFA8A693302040D448E4EAE5567A9D

Patched SHA-1:
	6832E161A4D307766FFB953C78C92D27B72ACBEC
Patched SHA512:
	BA31F6AC18295D9A2B43A7F774FB70E1DD917B4646E5ACBD3E147C4A483856584DCE27130A4F441701821128ED56C4190DE73FEB29D401F596F9127BF0B6DD41


.:Gameplay Notes:.
  The epilogue is part of ending 5 but only plays if all of the endings have already been viewed.  Credits roll after the epilogue.  If you don't want to be spoiled, do not read the earlier prototype's TL notes.  Turns out the ending prediction was spot-on, minus the whole "sentient shade of the color blue" thing.

  Normal, round shots can be absorbed by your option to charge up the particle wave cannon meter at the bottom of the screen.  When full a chime sounds and you can fire the weapon.  You can also move the option in front of you as a shield but won't be able to fire.

  At the end of a stage is the option to follow the left or right route.  The left route opens up based on your score in that stage (or downed ships, or something like that) and a notice appears on the screen when the conditions are met.  Dying resets this.


.:TL Notes:.
  Compared to the earlier prototype, about half of the introduction was changed.  Now it very clearly sets the overarcing identity crisis plot thread from the onset.  Several awkward lines in the mission cutscenes were (thankfully) modified as well, and the last lines of the first ending no longer refer to what he learns in other endings.  Two were also added into the epilogue, as in actually appended to the end of the dialog table.

  The game's fairly inconsistent about where it writes text on the screen, even within the same cutscene.  Some of these were corrected.  Two lines were white text on a white background.  These were colorized.  "Memory File", from the earlier proto, was used instead of "Ending", a purely aesthetic choice.

  The font remains fixed-width but text was re-encoded for variable byte lengths.  A new FA** command was added to offset the current x position.  Font 7 was replaced with an 8x16 font instead of recycling the one already present, basically appeasing my own aesthetics.  Admittedly, the "italics" are horrible but to retain the spacing each character needs to be smooshed in a pixel per "step".
  Using an 8x16 font, the text limit in most cases is ~24 characters per line, which may sound like a lot until you realize "Time-space disturbance" is 22 characters.

  The script reads like teenage shonen space nonsense and lean towards overdramatic.  In the interests of full disclosure I'm not especially happy with the final product; too much passive voice, too many weird tense changes and awkward phrasing to fit within constraints, and some of it just never really came together.  More time's not going to fix any of that.  Whatever, it's done.  It's not ideal, but at least serviceable.

  Was hoping to finish this within 24 hours of the release.  Would have made it if the kanji table didn't change...


.: Changelog :.
2025/11/25	6832E161A4D307766FFB953C78C92D27B72ACBEC
	Initial Release

-Zoinkity
