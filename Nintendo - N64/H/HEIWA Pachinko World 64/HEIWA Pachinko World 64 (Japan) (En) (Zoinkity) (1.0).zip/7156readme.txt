﻿HEIWA Pachinko World 64 English Translation
*** Mature content warning!  Certain games have lewd (but not r18) content like strip mahjong.  In Japan pachinko cannot be played below the age of 18.  ***

line  12	.: Introduction :.
line  30	.: Patching :.
line  48	.: Gameplay Notes :.
line  56	.: How to Play :.
line  88	.: Translation Notes :.  (aka RANT)
line 112	.: Patch Versions :.


.: Introduction :.
  "HEIWA Pachinko World 64" (1997/11/28) follows the apparent success of three prior SFC titles: "HEIWA Pachinko World" (1995/2/24), "HEIWA Pachinko World 2" (1995/9/29), and "HEIWA Pachinko World 3" (1996/4/26).  The first N64 pachinko game, it features 3D versions of four HEIWA real-world machines and semi-free movement virtual parlors.

  As far as pachinko goes it's fairly respectable.
  Everything else is hilariously tacky.

  Its failing is indecision, a re-targetting that missed both marks.  It's so pronounced it's almost as if two developers were involved--an original developer and another that quickly applied a 3D veneer.  Half of the game is designed around the limitations of a 2D, 16-bit system.  There's a preference toward heavily-dithered <= 16 color palettes instead of 256 color palettes, and those palettes lean towards particular color ranges that system was better at reproducing.  Menu-heavy focus is recycled from the older titles, inner menus isolated rather than stacking.  Inexcusable is that when you elect to quit playing it hangs on that message.  Should you close the window?  Hold reset as you turn the power off?
  Do yourself a favor and turn the BGM off.
  The other half--including the machines--is low-poly 3D, not much different from the low-poly early Japanese exclusives on PSX and PC.  The machines are the highlight.  Contrasted against their real-life counterparts they're surprisingly accurate.  HEIWA's machines from this era are simple, retaining the printed cardstock and plastic look more common to Showa-era units.  The roulettes aren't sterling but workable.  They do sound like they should (if isolated in a basement).  A definite step up from Naxat Soft's "Heiwa Pachinko Soushingeki" the year before.  By far the best part of the game.
  The parlors are sparse but decent representations of what they are and well-populated, using dungeon-crawl mechanics for free movement.  Short draw distance and lack of texturing are negatives.  Most details are useful ones, like how players at winning machines have ball trays for their approximate winnings and machines will flash and play their jingles on hits (when row-sliding).
  What parlors aren't is a cacophony.  Instead of atmosphere--a deafening din of whistles and bells--there's a midi-rific cheese topping.  100% fail.  Pachinko business strategy works most effectively when you can't hear yourself think twice.
  The town is a bit laughable.  The one saving grace is that the queues for each parlor indicate its popularity that day--proportional to the slight difference in odds (nevermind the queues shouldn't exist with empty seats in the parlor, but hey--newspapers!).  There is no story like in later titles, for *better* or worse.

  This marks the last joint venture between Shouei and HEIWA.  Aqua Rouge would continue to produce their pachinko-only titles for Playstation.

  At any rate it isn't the best game and the bar's pretty low for pachinko titles already.  However, it *is* a game, and one now in English.


.: Patching :.
  The patch will only apply to a ROM in native byte order (big-endian).  Attempting to patch something else will result in a completely unhelpful checksum error.  Xdelta patches can be applied with the aptly-named xdelta patcher; use version 3.0.8 or up.  (In other words, one from the last decade.)
  Common Name
  	Heiwa Pachinko World 64 (Japan)

  Original File Checksums
  SHA-1
  	D48A484FEBAAC3BD146130434921861890503B29
  SHA-512
  	5259BCA3395D9410C65140F013546A24D869A47CA25793E73498CEDFAACCCC3374CF337A19FE02989F60F3A0F1F063A33122926EB46639E8844E2690AA057C95

  Patched File Checksums
  SHA-1
  	782B5950D6C493D7DB45C565A5CF005E2B2E49EC
  SHA-512
  	94DD5C74E08277A191685452AE0B24BD184D3BF660ED92B1B61DE5E644C65D0DB39A21F236FB877896966629D793A988AB17BAC5EBDD211EA2928002AD7E0A06


.: Gameplay Notes :.
*) Only tested on actual hardware.
   Anything that runs on a real machine will (eventually) run under emulation as well.  If it doesn't, complain to their developers; that's how they know there's a problem in need of fixing.  Changing software to work exclusively on the current generation of emulators is a philosophy that should have died in nuclear winter with zsnes.
*) If every file you create has 0 yen, attach or emulate a 4k EEPROM on the cart channel.
*) Japanese game saves are not completely compatible with this translation.  Data is unchanged but the names will be corrupted.  Voiced/semivoiced will display random garbage, the rest will substitute the new language.  Coexistence won't work with this antiquated text display.
*) Pre-existing bugs were not fixed.  Known ones are "Lucky Lucky"'s sign not lighting when it should, roulettes randomly flickering, the wrong number of trays for certain exponents of two, and some condition where Lemon Pai softlocks in "Lucky Lucky".  These occur on original cartridges.


.: How to Play :.
*) The goal of the game is to make 1 million yen.  There will be a fancy ultra-dithered animation and scrolling message.  There are no credits and you can continue playing afterward.  Nobody is willing to take responsibility. {_x.x}_
*) When you sit at a machine, open the menu to "borrow" (purchase) balls.  Each hall has a different exchange rate.  (see below)
*) Balls are autolaunched (hold Z to apply a brake).  You "aim" the stream by turning the dial with the Control Stick, controlling the intensity they're fired at.  The basic targets in these or any other pachinko games are flowers, the payout gates at the bottom, and in any post-Showa machine a central jackpot roulette.  The general strategy is to work the upper-left, then at a jackpot move to the right.  L & R zoom, + pad pans, C buttons change the viewing angle.
*) Pachinko is designed to string you along.  "Jackpots", lit. "big hits", aren't Vegas-style cartloads of coins.  Where you make bank is that jackpots enter payout mode.  Payout gates open where each ball passing through nets half a dozen to dozen (marked on the info sheets).  They're commonly called "attackers".  Petals on flowers open as well, making them a bigger target.  Jackpots can be--and usually are--strung together continuously or sequentially; the first makes the rest easier for a time.  They'll chain for a while then run cold, at which point you should cash-out and move to a different machine.  Typically expect to make a few thousand balls off a jackpot.
*) Unlike reality in Japan (though maybe in Hong Kong & Taiwan) your balls are turned directly to yen at the exchange rate for that parlor.  (The exchange methods are only partly implemented in this game.)  The prizes are only for show.
*) Saving the game ends the day.  Each day you lose some money for personal expenses (food, etc.) and saving the game automatically deducts that.  If you go negative, it's game over.  If you elect to quit playing, it will thank you and spin on that message until you reset or turn off the power.
*) When you change the date it displays how much money you'll have left on the selected date.  It costs 1500 yen per day.  Press left/right to highlight the month or day in the upper left corner, then up/down to change the value.  B cancels, A accepts.  You can only advance as far as your finances permit.
*) In walkabout mode, very little in a parlor is interactive.  The doors out are (blue doors, not red), and when you enter a row of machines they will be, but card machines, money exchangers, staff, etc. are not.  Cards can only be purchased at CR machines and balls borrowed at normal machines via the menus (press A during play).  Cash-out is automatic when you stop playing a given machine.  You can navigate almost entirely using menus instead of movement like its SFC predecessors.
*) The "call boy" provides statistics for that day--a super-simple "battle counter" (not to be confused with the call button).  In order for it to provide play statistics some amount of time must pass, even just a few minutes.  Use the "time" option in the menu to your advantage.
   L & R switch between the buttons on the interface, A selects them.  It opens to the "rates" display.
   The "rates" display shows the total roulettes spun, jackpots won, and hourly rates for both.  Pressing A switches from counter to graph mode.  Which jackpot mode's stats are displayed is indicated by the background color.
   A light-blue background is for normal jackpots, dark blue for continuing jackpots, green for unlimited jackpot mode.
   The "plays" display counts the total roulette spins, balls shot, prize balls won, and the net profit.  Pressing A will reset these counts.
*) Lucky days at a parlor use a higher return rate and (at least in this game) increase the base chance of a jackpot.  The dates for these are highlighted on the calendar.  (Was this legal back then?  You sure as heck can't manipulate odds nowadays.)
*) Every other pass through the attract sequence presents a summary of one of the parlors.  It's the only place outside the manual you will find most of this information.  Here it is again, for convenience.
   Big World
     Sale rate: 2.5 yen
     Exchange terms: once per game (when you quit playing you're cashed-out)
     Open weekends and national holidays.  "Big treat" at the end of the month (a "lucky day" as described above).
   Lucky-Lucky
     Sale rate: 3 yen
     Exchange terms: lucky number system (implemented as a raffle following a game where a jackpot occurred)
     An overall average parlor.  Ball win rate is higher on rivals' business holidays.
   Fuji Hall
     Sale rate: 4 yen
     Exchange terms: unlimited
     Appealing exchange rate and average ball count, especially at end-of-month adjustment.
     Closed Wednesdays.
*) On the info sheets, "reach" ("richi") is a borrowed mahjong term for when you're one away from winning the roulette, like "Uno".  To string you along more effectively (or make things more exciting if you're an optimist), many machines have long and varied behavior when this happens and those are noted on the info cards.  From a player's perspective, if a machine acts like it's about to win it's about to win.


.: Translation Notes :.
  Pre-emptive apologies for the apologist rant.
*) This was a very low-effort project.  Everything was replaced in-place instead of rebuilding the filetables.  No existing bugs in the unmodified game are addressed.
*) Inserted a small backward-compatible extension to the codec to allow unlimited dictionary lengths.  It's indicated in the lowest bit of the decompressed size field.
*) Its scatterbrained art direction isn't changed.  16bit-iness was retained, down to pseudoaliasing and dithering with those limited palettes.  Its pre-rendered 3D uses pre-rendered 3D.  A professional localization would throw that garbage away and make new, more consistent garbage, but not me ;*)
*) Another choice left unchanged is unreadability.  N64 doesn't just use analog out; the VI interface is a very snazzy signal encoder incompatible with our digital world.  Pixels aren't an analog concept and they aren't guaranteed square.  On CRTs, games like this one where pixel-thin text is used grow more illegible the higher the resolution.  An extreme example are explanations on the backgrounds of Oak's Lab in Pokemon Stadium 2/Pocket Monsters Stadium 3.  Like there, most of the original text in this game isn't remotely legible on a CRT even when it isn't scaled.  Digital TVs (for the most part) nor emulators have a problem.  Unlike most of my work, no effort was taken to make it easily playable on CRTs.  The original wasn't, and too much would require redesign to make it so.
*) Pachinko terminology is terrifying, multilayered slang.  The industry has spent years trying to develop pachinko for western audiences unsuccessfully, faceplanting against that language barrier.  What you're reading in-game is very likely wrong.  Even if it's right it's likely wrong.  (Consistency vs time)  Those info pages are dodgy at best.  If it's normal slang I likely don't know it either.
   "Tama" means "Ball" and is the name of the ball-shaped mascot.  HEIWA semi-localized a few units as "TAMAchan" over time; I'm staying consistent with their choice of name.  Otherwise, if it were any word other than "ball" it would be translated despite being a name since that is *what he is*.  A duck by any other name is still a duck.  Yeah...but Namco it up as "Lil' Ball's house" or haha "Ball-Man", wow, that's meme worthy.
   Fair warning, there's also a few brutal localizations in here.
   Among the more questionable are 交渙 (lit. change scatter) as "shuffle" when it re-randomizes under the lucky number system, and "rolls" in place of "starts" for スタート to count the number of roulettes--a choice as explicit as it is deviant.  "Rolls" has the advantage of two Ls at 2-3 pixels each.
   Another is rendering 美女大集合2 as "♥♥♥ Galore 2" (♥♥♥ in place of "beauties", get your mind out of the gutter).  If you can think of a way to stick the literal into 62 pixels legibly without completely changing the layout of everything else, have at it.
   "Pank", the meaning falling closer to "to break down" than "malfunction", is when a jackpot goes by without any balls entering the pockets or when the slots time-out.  There isn't a very good single-word-that-fits option, you get what you paid for.
   Adapted a few of the messages to insert caveats only mentioned in the manual.  Went with the international yen symbol versus kanji.  I raise your "pai" with my own pun.  "Pin View" is "Examine"; there's more going on in those menus than just peeking at the unit like other games limit you to.  I prefer "Hand of the Heavens/Earth" but "Hand of God" fits better.  Wanted "payout", got "profit", etc.  Lots of little concessions like that.
*) The machines were rebranded for the most part against all better judgement.
   Roulettes are localized but their layouts were modified as little as possible to remain faithful to the original machines.  Not a fan of vertical text, other layouts worked worse.  The standard for mahjong terminology is to just use "ron", "tsumo", etc.  Not a lot of agreement on the reach/richi front.  Some text that was illegible, unintelligible, or used stroke reduction was stripped (Success Story, I'm looking at you, 90% BS).
*) Prizes are not translated.
   Although the game illegally exchanges your balls for yen on-site, if you look around the counter at the parlors they have the standard assortment of fabulous prizes you'd expect--or at least legally-distinguishable non-brands that won't get the developers sued.  The boxes are surprisingly detailed though, and modifications to the brands were consistent across the different faces.  Worth peeking behind the counter to get a look at them.  They aren't translated here even though a couple of the (real) brands do sell in the USA market with official branding, SONY & Attack detergent coming to mind.  Simplying writing "T*P" won't cut it though; they're covered in a lot of other text, and the smaller boxes are unintelligible.
*) Very little unused content exists.
   There is a list of days of the week, a month counter, and 48x32 image set for numbers 1-12.  They're together, so likely a date select replaced with the final calendar.
   A second list of days of the week is bundled between the fonts and mode select images with no clear use.
*) I am quite well aware of the ties between the pachinko industry and North Korea (no more email spam campaigns) and don't feel old pachinko VGs or translating them has any noticable impact on the situation.  (Haven't seen complaints about the Japanese government's attempts to normalize relations directly, you might as well ban all their current and previous exports.  Hope you like xbone.)  If it doesn't sit well with you, don't play pachinko.  There are plenty of great reasons to not play pachinko.
   My only interest is covering all the games nobody in their right mind would bother with.  Complain about only 13% of VGs being represented commercially all you like, but exactly how much of that (overly optimistic) statistic consists of lame, buggy, boring, cancelled, rushed, or cash-in titles that deserve preservation only on the merit that they exist to be preserved?  Development is a gleaming highway through history built from bricks of polished dung, and these games tell that story--dispelling the myth of inexplicable ingenuity successful studios more often than not perpetuate.  This is one of those games, the bitter end to an otherwise successful SFC series, maybe hastily converted from a different target platform.  Say what you want, but the 3D walkabout in the other two N64 pachinkos didn't come out of a vacuum and these characters are more human (and read newspapers, cute touch there).  Try them--"Pachinko 365 Nichi" (1998) & "Parlor! Pro 64" (1999)--and note the evolutionary development (against noses).  How Parlor! made that 3D leap is particularly interesting, clinging to low-cost mini 2D releases as long as they did.  (Yet only one BS title?  Weirdos...)  Maybe influenced by this game's failure?


.: Patch Versions :.
  If you are ever unsure what specific release you have with this or any other patch I've created, the timestamp is encoded C-style at 0x34 in the header (YYMDhms).
1.0	2023/12/31
	Initial release.


  May the odds be ever in your favor.

-Zoinkity
