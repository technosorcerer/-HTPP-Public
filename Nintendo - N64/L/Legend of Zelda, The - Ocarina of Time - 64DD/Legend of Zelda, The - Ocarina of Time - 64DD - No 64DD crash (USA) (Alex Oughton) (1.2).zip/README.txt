For Ocarina of Time USA 1.2.
Author: Alex Oughton.

Changes the instruction decompressed to 810ADAE0 to direct 64DD check results to an unused location in memory.

A similar fix is possible using the following gameshark codes:

F10004E6 2400 MASTER1
EE000000 0000 MASTER2
D10ADAE4 A062 64DD FIX1
810ADAE4 0000 64DD FIX2