Zelda Majora�s Mask, Masked Quest, official VC Wad v1.2 by Garo-Mastah

this wad contains all you need for put the respective romhack onto the wad

*with Dpad Support for change the masks/play ocarina
*removed textures in .tga format, due the original graphic respect
*with functional manual, not customized.... yet

the WadMii program, does function of pack/unpack wad
U8Mii, what extract the resources and update the content if you need, ex: 00000005.app and put
"romc" file onto it
owned by ShowMiiWads, credits to him/her

1- in the actual MMMQ rom, after you patched the original rom with the update, you must rename it as "romc" and open your favorite
hex editor and fill 4 bytes in the 1st space 08 00 00 00 and after that, save it

2- replace said file and repack the 00000005.app folder into a file with U8Mii

3- so you must repack the complete file, delete the 00000005.app folder and repack it into a wad with WadMii
and Voila... you had the official wad channel for install it into a just hacked Wii or the Wii U running vWii as well

are you ready for it.... let us go
GM out