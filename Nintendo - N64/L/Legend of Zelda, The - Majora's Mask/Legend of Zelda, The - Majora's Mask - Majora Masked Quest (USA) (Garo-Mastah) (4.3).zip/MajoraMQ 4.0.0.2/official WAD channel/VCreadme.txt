****************************************************************************
*Legend of Zelda, The - Majora's Mask - Masked quest project. PreAlpha-Beta v1.2 VC edition*
*By Garo-Mastah*                                                           *
****************************************************************************

the wad is finished ready to test.
the balance change aren�t can be to wait.




***************************************************************************************


this is the first fase of my ultimate version of the game with so many changes in the gameplay, altering many known places like; the pirate fortress, the moon, etc.

differences with the original game and the Deathbasket�s "MQ":

Link at the beginning, starts the game with No sword and No Shield. Like OOT, but That motivates the quest of the 2 valued items around the Clock Town.
now the Poe Sisters guards the Bow and the magic elemental arrows around of Termina, starting with Amy Until to older Meg, from the Spider houses to the lone peak Shrine and the Ancient Castle Of Ikana respectively.
the powder keg is now, useful in some cases.
some items are required for go to the final (Goron Mask and the Ice Arrows as well).
The transformation masks have special elemental powers in some attacks (ex. Goron Spikes have the hability to burn some enemies and the Fierce Deity Link is capable of kill enemies with his Sword Beam).
some important items are hidden in some grottos (you have to discover yourself :3).
The infamous Moon Trials are now more exciting and interesting and not optionally anymore, the 3 MASKS are required for advance to the next trial to gets into the Final room (Majora), the moon field also requires 2 important items in the game To climb towards where is the Majora masked moon child to accept the final challenge of the game, and talking about of moon children, 10 masks are mandatory for gives to the moon children, 1, 2, 3 and 4 respectively; that reminds me the Ganon trials in the Ganon�s Castle in OOT.

Initial release
Recent changes:
the orange Stray fairy is hidden in the place where is the guard bomber.
the east Clock Town Guard position is fixed. for avoid what deku Link escapes in the First Cycle, sorry.
the Deku Palace grotto holes from the JP release are restored, making the Palace a hard place to glitching. making an interesting stealth skills, and shiro, the Stone Mask guard is in the Bean Seller Grotto, oops. and Kamaro is in the place what the Stone mask guard was.
the pirate Fortress is reinforced its security, avoiding the get into the principal room where the bee hive is.
the 3 principal Masks are hidden in special places, leaving the goron graveyard half-intact, deleting the Getting Deku Mask cutscene.
some early enemies from OOT and the beta stuff are restored (ex. the Gray Hookshot Pillars from OOT).
the Scarecrow�s song, the powder keg and the Elegy are useful.
The Secret Shrine is renamed as Ikana Shrine, the Zora Hall as the Zora Shrine and the Mountain Village as North Mountains.
the Lottery shop and the Bank Teller are moved to the South Clock Town. :3
the Zora eggs are not obtainnable bottle item anymore, instead, are hidden and enclosed into the treasure chests (requires real bottles), they can be found at the differents places, 3 in pirate fortress instead of 4, 1 in the Pinnacle rock instead of 3, and the another 3; 1 at Mountain village and the 2, in the road to the Goron Village (both in Spring after Goht defeated).
the owl statue in the West Clock town is gone
the 4 fountains have new apparence, each color for each region, to match with MM3D, also the bosses scenarios

*UPDATED*
*Updated - 02/18/2017*
cosmetic changes NEW:
the young Link�s tunic and boots, the Sash and the Hero�s Shield are yellow-golden color, just the Shield�s cerulean color is swapped to golden.
the Link�s Deku, Goron, Zora and the FD forms are customized to the Green, Red, Blue and Turquoise respectively into color themes for have an unique style in each form. a texture edit using the MM debug Rom as base.
the elegy Link�s statue is less creepy now.
the Purple logo is colored into a yellow-colored logo.

*Updated - 02/27/2017*
Balance Update, and tweaks NEW:
thanks to Fkualol, Link and his all forms can do manual jump, in 2 differents modes, forward and stand jump,
the shield crouch stab is disabled finally later of 9 years.
finally the FD Link have the Adult Link�s size and can open lifting dungeon doors, and can be usable anywhere with no restrictions of any type, he finally can use regular items & weapons, but he can�t use the hookshot, bow and magic arrows.
the Goron Link have the walking speed to match with MM3D�s Goron Link walking speed.
the hookshot range is lightly extended.

tweaks by me:
the Magic bean Seller is moved now to one of the Gossip Stone grottos, one of the well Gibdos still wants the Magic beans.
the FSS music is back to regular FSS music.

*Updated - 03/11/2017*
the time travel don�t affect sword level is added, plus the Remove subtraction to razor sword strike counter (thanks Aroenai),
is added too, for keep the razor sword during the adventure.
the stray fairies of the woodfall and snowhead temples�colors are swapped to match with MM3D fairies.
the Swamp Spider House quest for 30 Skulltulas and the Ocean one is randomized, giving posibility of get until 31.

tweaks:
the mirror shield�s image is replaced, as display list and also the GI image in from a creepy face to a Majora�s symbol.
some tweaks in Mountain village (path to goron graveyard) and the added a new puzzle same graveyard.
ikana castle also gets new puzzles.
the FD link now is usable in anywhere, and can use the lifting doors now, if you complete the miniboss challenge at the Secret (Ikana) Shrine.
the Fire Arrows path puzzle where is the blue Poe Sister is renoved, located in goron village, road to Lonepeak cave.
the cow nosering is restored, to match with the J version of the game (thanks again Aroenai).


things to do:
make the temples are completed in reverse way, like OOT MQ
modify the shops
avoid the boss key skips
put more enemies in temples, as are made in the Spider Houses.



the romhack are used in Any% only, the work has not finished, until when it�s ready
always make a new savefile before start the game. please.


that�s all

are you ready to try?
let�s go

"that�s the law of US, The Garo"
 
G-M out
have a spectacular day!