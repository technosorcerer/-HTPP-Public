****************************************************************************
*Legend of Zelda, The - Majora's Mask - Masked quest project. Alpha-Beta-Gamma v4.3.0
"Dawn of a April flu chuchuvid21 N64 .bps edition*
*By Garo-Mastah                                                            *
****************************************************************************

as well, i included the IPS Patcher to patch the .bps file for a fresh unmmodified NTSC MM 1.0 N64 rom
Big endian .z64 rom
rom crc
5354631C-03A2DEF0
http://www.romhacking.net/scratchpad/30074/
***************************************************************************************



*UPDATED*
*Updated - 04/01/2021*
*New omg*

What�s new?
the Dpad icons are located to the Left of the screen, again
the new chuchu species, HUD balance and mid-time quality-of-life fixes

Fixes
the swamp skulltula issue has fixed when you complete 30 tokens.

Tweaks
the HUD now show the purple jewel in the day counter instead of blue.
the Snowhead temple portal to boss fight glow red instead of white.
the stray fairies from swamp and mountain colors sparks are fixed.
new types of elemental chuchus who are around of Termina
Path to swamp - fire ones
one of the gossip grottos - an electric one
and the GB temple - the ice ones
the normal chuchus are yellow colored.
the Shabom enemies are back, for a moment, at GBT replacing skulltulas.
the Deku Link dust is green instead of yellow.
the elegy statue glows are customized the colors to match link�s forms, ex FD link elegy glow
is got a own color.


Addons
everything incluided from Woodfall and Ranch & Snowhead Update!.


things to do:
make the temples are completed in reverse way, like OOT MQ
modify the shops* alpha
avoid the boss key skips, discharted
put more enemies in temples, as are made in the Spider Houses. checked
the GBT and the STT are left for a while...



the romhack are used in Any% only, the work has not finished, until when it�s ready
always make a new savefile before start the game. please.
install it into the wii via wad manager, use it with under your own risk. *old way*
coming soon for Wii U VC with widescreen feature and full Dpad funcionality*
planning, near

that�s all

are you ready to try?
a second chance? huh?
let�s go

"that�s the law of US, The Garo"
 
G-M out
have a spectacular day!