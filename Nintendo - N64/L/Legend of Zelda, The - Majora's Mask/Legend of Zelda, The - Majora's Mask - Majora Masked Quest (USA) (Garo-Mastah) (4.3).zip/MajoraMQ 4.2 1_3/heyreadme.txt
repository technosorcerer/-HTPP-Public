****************************************************************************
*Legend of Zelda, The - Majora's Mask - Masked quest project. Alpha-Beta-Gamma v4.2 1/3
"Dawn of a new Wave Mark the 3rd!, Ranch & Snowhead Update N64 .bps edition*
*By Garo-Mastah                                                            *
****************************************************************************

as well, i included the IPS Patcher to patch the .bps file for a fresh unmmodified NTSC MM 1.0 N64 rom
Big endian .z64 rom
rom crc
5354631C-03A2DEF0
http://www.romhacking.net/scratchpad/30074/
***************************************************************************************



*UPDATED*
*Updated - 09/02/2020*
*New, Deepers Creepers*

What�s new?
the Dpad mask and ocarina on-the-fly item selection commands, courtesy from Saneki from his Randomizer hack tool, is now available, so you can press each side of the N64 Dpad directional for choose 3 of 4 transformation
masks and the Ocarina as well, give you the chance of handle 7 items.
now in this button order:
Dpad Down - ocarina of time
Dpad Right - deku mask
Dpad Up - goron mask
Dpad Left - zora mask

Fixes
the terrifying library door bug is fixed, now comfortably pick up the zora mask
with no issues.
Romani Ranch now has proper hylian title instead of Kakariko�s.
the deku salesman now gives you 200 ruppee reward after you trade all
the titles.
the hookshot platform in the moon, it can move with no issues.
the ikana castle reward is waiting to you after you defeated the 1st
Wizzrobe, just check the blue chest at the castle entrance. is not another Big Poe, right?


Tweaks
the Snowhead temple redesign has completed 100%, so have fun.
here appears new Keeses species, the electric ones, into Snowhead temple, for now, and Dark Ones at Stone Tower entrance (at night).
and 2 new Wizzrobe species, the normal one, who replaces the fire one at
Woodfall temple, and the Curser, who is in the Ikana Shrine (At night).
and more little stuff.
migrated from MMR to Patcher64+, courtesy from Admentus64.
The title screen have yellow colors instead of Original Purple.


Addons
everything incluided from Woodfall Update!.


things to do:
make the temples are completed in reverse way, like OOT MQ
modify the shops* alpha
avoid the boss key skips, discharted
put more enemies in temples, as are made in the Spider Houses.



the romhack are used in Any% only, the work has not finished, until when it�s ready
always make a new savefile before start the game. please.
install it into the wii via wad manager, use it with under your own risk. *old way*
coming soon for Wii U VC with widescreen feature and full Dpad funcionality*
planning, near

that�s all

are you ready to try?
a second chance? huh?
let�s go

"that�s the law of US, The Garo"
 
G-M out
have a spectacular day!