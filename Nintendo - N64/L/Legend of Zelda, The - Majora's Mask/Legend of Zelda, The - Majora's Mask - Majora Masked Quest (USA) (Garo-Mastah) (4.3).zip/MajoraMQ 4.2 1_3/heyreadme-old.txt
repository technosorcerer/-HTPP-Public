****************************************************************************
*Legend of Zelda, The - Majora's Mask - Masked quest project. Alpha-Beta-Gamma v4.0.0.2
"Dawn of a new Wave Mark II!, Woodfall Update N64 .bps edition*
*By Garo-Mastah                                                            *
*VC edition*
http://www.romhacking.net/scratchpad/30229/
****************************************************************************

as well, i included the IPS Patcher to patch the .bps file into a fresh unmmodified NTSC MM 1.0 N64 rom
Big endian .z64 rom
rom crc
5354631C-03A2DEF0

and theres its official WAD channel into the package
no ROM, you just get the rom with its crc yourself for patch it and mod the ROM for wrap into the WAD
***************************************************************************************



*UPDATED*
*Updated - 05/28/2020*
*New, Deep Dish*

What�s new?
the Dpad mask and ocarina on-the-fly item selection commands, courtesy from Saneki from his Randomizer hack tool, is now available, so you can press each side of the N64 Dpad directional for choose 3 of 4 transformation
masks and the Ocarina as well, give you the chance of handle 7 items.
Dpad Right - ocarina of time
Dpad Up - deku mask
Dpad Left - goron mask
Dpad Down - zora mask

and that�s not all, will be a hack what does arrow cycling, will gives you a one-the-fly rapid changing arrow skill with no need to press pause to choose ala Wind Waker
arrows.


Tweaks
the Woodfall temple redesign has completed 100%, so have fun.
restored Big deku baba and shabom *not appear yet* enemie desc.
the Deku Link bubble shoot has its range extended.
and more little stuff.


Addons
new enemies are arriving, example, different Flying skulls Bubbles from OOT are back with new skills and a new one.
the Iron Knuckles had 2 species now, the original and the all-brand new Royal Knuckle, based on my hacked IK. totally redesigned.
a new octorok species named, octonut, only will be found in the swamp,
and the Wizzrobe have new brothers, the thunder Wizzrobe and the Wizzrobe real-bombchu-summoner, based on the WW and BotW vibes.

new object are added, the red ice and the green bubble boobytap.


*UPDATED*
*Updated - 06/02/2020*

the HUD of the game display the buttons gray colored to match with the VC menu
so the next time i will release two flavors soon...

Bugfix
there something related with the Ikana Castle door, when caused freze the game.


things to do:
make the temples are completed in reverse way, like OOT MQ
modify the shops* alpha
avoid the boss key skips
put more enemies in temples, as are made in the Spider Houses.



the romhack are used in Any% only, the work has not finished, until when it�s ready
always make a new savefile before start the game. please.
install it into the wii via wad manager, use it with under your own risk. *old way*
coming soon for Wii U VC with widescreen feature and full Dpad funcionality*

that�s all

are you ready to try?
a second chance? huh?
let�s go

"that�s the law of US, The Garo"
 
G-M out
have a spectacular day!