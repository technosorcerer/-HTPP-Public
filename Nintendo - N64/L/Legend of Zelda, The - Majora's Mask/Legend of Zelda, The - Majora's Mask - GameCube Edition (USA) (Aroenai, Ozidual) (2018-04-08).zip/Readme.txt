The Legend of Zelda: Majora's Mask
Gamecube to N64 patches
by Aroenai & Ozidual
----------------------------------

FOR PRIVATE USE ONLY
If you're selling flash carts with these rom patches, you're doing to against the author's wishes.

----------------------------------

This is a patch to revert all of the cosmetic changes, emulation related changes, misc bugs/glitches, and various censorship changes for the Legend of Zelda: Majora�s Mask Gamecube roms for use on real N64 consoles.

Changes:

 -Restore the Nintendo 64 boot logo
 -Restore the no-controller text
 -Restore the ending credits music & Scarecrow�s song (Gamecube emulator streamed from disc)
 -Restore the confirmation chime for correct songs (Gamecube emulator streamed from disc)
 -Restore the Language select screen when there is no save (Europe only)
 -Restore the Language select screen under Option (Europe only)
 -Restore the original A, B, and Start button colors (HUD, pause menu, selection cursors, text, Ocarina musical staff, etc.)
 -Restore references to the original N64 controller (text/graphics)
 -Restore text corrections from the Europe v1.1 release (including missing sounds, transposed and missing control characters in text)
 -Correct header to prevent incorrect speed on N64 consoles (Europe, Gamecube roms were programmed for 60 hz only)
 -Correct boot code for NUS-CIC6105/7105
 -Correct white screen transition when entering Termina Field from the Astral Observatory during the day on the 1st cycle
 -Correct item reference when collecting Magical Mushrooms (Link would but away the bottle automatically due to this error)
 -Correct door placement for the Magic Hag's Potion Shop in the cleansed Swamp
 -Correct missing waterfall sound actors for the cleansed swamp, cleaned magic potion shop, and secret shrine areas
 -Correct message box types for Tingle's map dialogs
 -Correct typos in name references for Dinolfos and Wizzrobes
 -Correct translations for the Troupe Leader's Mask, and Town Title Deed items
 -Correct translations for the Deku Butler, Lulu's Diary, and the Great Bay Temple Turtle
 -Correct the mixed silver and white text added with the Gamecube text corrections
 -Correct placement of items on the File Select screen for Japanese, and current time for Owl Statue saves (USA, Europe, and Japanese)
 -Correct Options menu texture placement (USA)
 -Correct trailing spaces in dialog for all languages
 -Add an expanded Name entry screen with support for additional characters (Europe only; Uppercase and lowercase selectable with Caps Lock button)
 -Add Japanese translations for the Owl Statue save textures
 -Add the nose ring for all cows (matches OoT 3ds; original Japanese release only displayed during Romani�s story)
 -Add location titles for the Zora Cape, Zora Shop, Deku Scrub Playground, and Barn
 -Add fully functional instrument icons and item descriptions (matches functionality in MM 3DS, icons from the original Japanese release*)
 -Add support for the Japanese VRS unit (functionality was present already, port of Zoinkity's code to enable it)
 -Port Goht's awakening cutscene fix from the Japanese N64 v1.1 release (Link is no longer run over)
 -Port the Epona save transfer glitch fix from Europe N64 v1.x
 -Revert Skull Kid's face to the Japanese N64 version
 -Revert the USA 4th Piece of Heart collection sound change (no longer repeats the "small item" fanfare; matches OoT)
 -Revert the USA Bomber Kid's location change for the hide and seek mini game on top of the Stock Pott Inn (no longer falls off the roof awkwardly when getting close)
 -Revert the USA Deku Palace Bean Seller route change (grottos from Japanese v1.x are no longer unused)
 -Revert the Gamecube change to Goron Link's camera height when opening chests (text box placement was incorrect, previous Japanese bug)
 -Revert the Gamecube change to Skull Kid's scream (volume decreased when the camera moved away, previous Japanese bug)
 -Prevent the roms from crashing when injected in Wii Virtual Console

* - Default icon for the Deku Pipes was modified to match the in-game appearance, the original icon can be selected by searching the rom for "00 00 7A 30 00 00 89 50" and changing 89 50 to 80 A0.


Credits:

 CloudMax - ovl_kaleido_scope documentation
 fkualol - 4th heart piece sound & credits fix, Cow asm, Goht cutscene fix, Stock Pot Inn roof Bomber Kid location, 1st cycle Observatory>Termina Field transition fix, Goron Link camera
 Garo-Mastah - potion shop door placement correction, initial report of the missing waterfall sound actors
 GlitterBerri - rom documentation, translation corrections
 Melonspeedruns - French text translations
 mzxrules - rom documentation
 ozidual - n64 logo restoration, restored Language selection, expanded Name entry, no controller text restoration, correct song chime fix, magic mushroom bottle fix, instrument icon swapping asm, File select screen placement modifications, MM 3DS text extraction, and fixing my dumb mistakes in general
 Zoinkity - rom compressor, MM "Z" pause menu replacement documentation, asm to enable the VRS unit
 Aroenai/arablizzard2413 - text and graphic editing, color and file offset modifications, Yaz0 archive and table modifications for item names and icons, text id replacement asm, location and map location table modifications, Deku Palace bean seller route restoration, waterfall sound actor restorations, finding the bottle catch item table, porting all other fixes from OoT Debug/MM U 1.0, NUS-CIC6105 bootcode restoration


ROM / ISO Information:

    Legend of Zelda, The - Majora's Mask (USA) (GameCube Edition).z64
    CRC32: B008458F
    MD5: AC0751DBC23AB2EC0C3144203ACA0003
    SHA-1: 9743AA026E9269B339EB0E3044CD5830A440C1FD
    _______________________________________________________
    Legend of Zelda, The - Majora's Mask (Europe) (GameCube Edition).z64
    CRC32: 12836E19
    MD5: DBE9AF0DB46256E42B5C67902B696549
    SHA-1: A849A65E56D57D4DD98B550524150F898DF90A9F
    _______________________________________________________
    Zelda no Densetsu - Mujura no Kamen (Japan) (GameCube Edition).z64
    CRC32: B9BF76DF
    MD5: D3929AADF7640F8C5B4CE8321AD4393A
    SHA-1: 1438FD501E3E5B25461770AF88C02AB1E41D3A7E