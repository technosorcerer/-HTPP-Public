This is a 1.0 US ROM of The Legend of Zelda: Ocarina of Time.

The BPS patch will work online but with glitches. The other players will appear as Link with glitched out textures. Those players still see on their screen that they are a dragon.

To use with Randomizer:

1. First patch a clean rom with rando, then open the included zzdec.exe program as admin
2. Open your patched rando rom in zzdec.exe and then save it as a new rom
3. Go to this site: https://www.marcrobledo.com/RomPatcher.js/
4. Load the rom file as the rom that zzdec.exe just generated, and the patch as dragon-decompressed.PPF
5. Patch the rom, compress it, now you should be able to play as dragon in rando.

Credits:

Character: KasperZERO
Model: FrustratedZeus
Import: Zeldaboy14

Special thanks to Kaze Emanuar. Please support his Patreon for more romhacks.