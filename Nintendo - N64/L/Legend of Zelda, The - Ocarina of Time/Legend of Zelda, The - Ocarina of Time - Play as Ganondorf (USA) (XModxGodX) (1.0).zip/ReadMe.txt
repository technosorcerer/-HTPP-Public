Apply the Patch using PPF-O-Matic: http://www.romhacking.net/utilities/356/
Note: If the screen flashes red every time you pause the game you can disable the Minimap to stop this or if you don't want to do that every time you transition to a new area use this gameshark code: 801C8522 0001

Bugs: Some of the items are graphically glitched when used by Ganondorf most noteably the Hookshot, Biggoron's Sword, Mirror Shield and Gauntlets. The screen may flash red when pausing using certain Emulators. If you can't stand that disabling the Minimap should stop this (assuming you remember to do so with every screen transition) or you can use this gameshark code to disable the minimap completely: 
No Map
801C8522 0001

Credit to Flotonic for making the Stalchild mod and N64Mods for the Ganondorf Mod for the debug version I just ported it over to Vanilla Ocarina of Time.