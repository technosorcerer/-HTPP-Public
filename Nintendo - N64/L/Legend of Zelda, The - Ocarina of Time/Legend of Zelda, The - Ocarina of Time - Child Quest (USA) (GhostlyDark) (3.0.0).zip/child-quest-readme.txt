Author: Admentus, GhostlyDark
Last Updated: 2025-04-21
Release: v3.0.0

Website:
https://evilgames.eu/emulation.htm#cq

Patcher64Plus:
https://github.com/Admentus64/Patcher64Plus-Tool



===============
= Child Quest =
===============

Experience the story of Ocarina of Time without ever reaching adulthood.
All items are usuable and every collectable can be acquired.
Riding Epona, doing both trading quests, pulling the Master Sword...
Hidden surprises included!

Included with the download are standalone BPS variants for:

- Original dungeons
- Master Quest dungeons
- Ura Quest (MQ Beta) dungeons
- Widescreen patches (incompatible with real hardware)

You may customize your experience further using Patcher64Plus instead.



============
= Base ROM =
============

Legend of Zelda, The - Ocarina of Time (USA).z64

CRC32:
cd16c529

MD5:
5bd1fe107bf8106b2ab6650abecd54d6

SHA1:
ad69c91157f6705e8ab06c79fe08aad47bb57ba7



================
= Contributors =
================

- Lead Development & Design:      Admentus
- Custom Model:                   Admentus
- Idea & Dungeon Design:          GhostlyDark
- Quality Assurance & Testing:    GhostlyDark
- Testing:                        Mod God
- Testing & Gold Dust Texture:    ThanatosZero