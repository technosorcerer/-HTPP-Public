~~~The Helix Blade Demo~~~
--------------------------

Patch using an OoT 1.0 rom.

~~~~~~~~~Credits~~~~~~~~~
-------------------------

Core Pride - Design

https://www.youtube.com/channel/UCeoeM7CcsUg6o0UtX8teW7w

Green Ocarina - Music

https://www.youtube.com/channel/UCCDnHjETUEAKsJqDNNUVT3g

~~~~~~~~~~UPDATE~~~~~~~~~
-------------------------

Fixed the Oceanside Temple boss door.

Fixed the waterbox in the beach area.
