~~~ THE MISSING LINK : LATEST RELEASE (v2.0) ~~~

*** INSTRUCTIONS ***
1: First get your legally obtained copy of The Legend of Zelda: Ocarina of Time (NTSC-1.0 version) ready.
2: Go to https://www.marcrobledo.com/RomPatcher.js/
3: Open your rom file in the site.
4: If your rom ends in .z64, use the "big endian" patch. If it ends in .n64, use the "little endian" patch.
   * If neither rom works, download Tool64 (https://www.zophar.net/utilities/n64aud/tool-n64.html) and convert your rom to "Big Endian" and try again.
5: Apply the patch.
6: Now play the game in an emulator, or on a real Nintendo 64!
   * If you want to play on Wii Virtual Console, you can patch a legally obtained Ocarina of Time .wad with this tool: http://bombch.us/DOxs (open the GUI version).

*** CHANGELOG ***
(v2.0)
- New title screen design, and fixed a bug in the original game where the letterbox does not function on the title screen.
- Made some changes to make translations etc. easier to create and recompress.

*** ALL CREDITS ***
Producer - Kaze Emanuar (https://www.youtube.com/user/KazeBG0)

Level Design - Kaze Emanuar
               Zel (https://www.youtube.com/channel/UCXUJgD8VMY_yEHY8ebY4k-g)
               CDi-Fails (https://discord.gg/nGFZ394)

3D Models and Maps - Zel
                     CDi-Fails

Programming - Kaze Emanuar
              Zel

Composers - Zerovolt0v (https://soundcloud.com/zerovolt0v)
            A6stringthing (https://soundcloud.com/a6stringthing)
            Sauraen (https://soundcloud.com/sauraen)
            Badub (https://www.youtube.com/user/TheFantasticBeats)
            DezZival (https://www.youtube.com/channel/UCcz2H4QpuFSyvgIdxSxYVeg)

Boss Animations - Rankaisija (https://github.com/turpaan64)
                  Ultra553 (https://www.youtube.com/channel/UC4utWR1AgmT0VEpB70T5RSQ)

Cutscenes - CDi-Fails
            Zel
            OstrealavaO2 (https://www.twitch.tv/ostrealava02)

Concept Art - Aurora-Xatu (https://www.deviantart.com/aurora-xatu)
              Ty Anderson (https://www.patreon.com/tyanderson)

Writers - Zel
          CDi-Fails

Testers - Zerovolt0v
          Sauraen
          E-Gor (https://www.youtube.com/user/Killgore52)
          GTM (https://www.twitch.tv/racingman1)
          Collins
          Ricar (https://www.youtube.com/c/Ricar2002YT)
          Fig (https://twitch.tv/fig02)

Special Thanks - Nokaubure (https://www.youtube.com/channel/UC8YeUzGI2PbzVFQDOOFlBbA)
                 z64me (http://www.z64.me/)
                 OoT Decomp Team (https://github.com/zeldaret/oot)

*** ORIGINAL WEBSITE ***
http://web.archive.org/web/20200930204000/https://tml.z64.me/