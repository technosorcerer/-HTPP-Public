﻿*************************************************************************
*                                                                       *
*                         Mushishi: Amefuru Sato                        *
*                     English Translation Patch v1.0                    *
*                  By the Anime Game Translations Team                  *
*                                                                       *
*************************************************************************

Thank you for downloading this English patch of Mushishi: Amefuru Sato for the Nintendo DS!

                   *****************************************
                   *           Table of Contents           *
                   *****************************************

  I.   Patching Instructions
  II.  Notes
  III. Closing

                   *****************************************
                   *       I. Patching Instructions        *
                   *****************************************

For instructions on how to patch and play the game, please visit https://agtteam.net/mushishi/guide/nds/

                   *****************************************
                   *               II. Notes               *
                   *****************************************

CHANGES TO THE GAME
In the original game, only Japanese characters can be used in the name-entry screens, whereas in the patched game, only English characters may be used. Save files are however fully compatible between the two. If transferring a save file from the original to the patched game, any unnamed mushi, and any numbers, will be translated (e.g. "名称不明〇〇一" will become "Mushi 001"), but any custom names will be preserved.

COMPATIBILITY
We recommend that PC users emulate the game with melonDS, as opposed to DeSmuME, due to graphical issues associated with the latter.


                   *****************************************
                   *              III. Closing             *
                   *****************************************

Join our discord server to send us your questions, check out our other projects or even lend a hand in our mission to bring more anime games to the English-speaking fandom!
https://discord.com/invite/UUF7Zbm

We hope you enjoy!

                         ===========================
                                PATCH CREDITS       
                         ===========================

=Hacking=
 Illidan

=Translation=
 ithyrial
 Phantom
