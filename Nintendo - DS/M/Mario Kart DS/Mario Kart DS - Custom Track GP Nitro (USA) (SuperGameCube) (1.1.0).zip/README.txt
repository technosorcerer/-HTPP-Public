This is release 1.1.0 of CTGP Nitro!

CTGP Nitro is a modification of Mario Kart DS that expands on the game with a
selection of custom player-made courses, much like other Mario Kart
modifications with a similar name.

################################################################################

CTGP Nitro Prerequisites:

Please use the Xdelta program included to patch your ROM.
Use the US patch if you have a US region ROM.
Use the EU patch if you have a EU region ROM.

If you do not own a PC, and cannot run the included Xdelta program, please use
this online patcher instead:
https://www.romhacking.net/patch/

If you need a video tutorial on how to patch your MKDS ROM, you may follow this
video:
https://youtu.be/8_AuFruqk5E

################################################################################

Supported Languages:

English
Spanish PAL
French
German
Italian

################################################################################

!!IMPORTANT INFORMATION!!

You may experience some compatibility issues depending on how you play CTGP
Nitro. CTGP Nitro is confirmed to work on MelonDS, mobile emulators and most
flash cards on the market. (Some flash cards may perform differently to others).
It is generally not recommended to play CTGP Nitro using DeSmuME, as it has a
tendency to introduce lag that is not normally present.

If you are playing CTGP Nitro through TWiLightMenu++ on a Nintendo 3DS/DSi and
you are on a version older than v24.0.0 it is recommended to update to the
latest as the "SWI Halt Hook" option in older versions caused performance
issues. Otherwise you will experience lag in-game that isn't normally there. In
order to get assistance with the configuration process, you may visit this
Discord server: https://discord.gg/yD3spjv

################################################################################

Troubleshooting:

One problem you may run into is the game freezing on a white screen on startup.
If this happens, ensure that you have used the correct patch file for your ROM.
If you have an EU ROM, patch it with the EU xdelta file.

If the game freezes online or during races, ensure that there are no
modifiations to the ROM. Modifications to CTGP Nitro are unsupported and may
make the game unstable. If you still have issues, report the issue in the
Discord server: https://discordapp.com/invite/CAktUYP

If the game crashes with a red screen, it is best to take a clear picture and
report the problem. One potential reason for a crash would be using your
Nintendo WFC friends list online on Wiimmfi. In this case, you may have to clear
your friends list before being able to connect to Wiimmfi. When reporting an
issue, make sure to include as much information about the events leading up to
the crash as possible.

################################################################################

About Unlocks:

All content in CTGP Nitro is unlocked by default, so there is no need to use an
AR code or a 100% save file.

################################################################################

About Records:

Extra Cup and course records will overwite the record data of other cups and
courses. If you wish to keep track of your records, it is recommended to use
separate save data for each page of cups. However, records for online play
should be accurate. You don't need to worry about this if you just like to play
casually.

################################################################################

About Ghost Data:

CTGP Nitro only has enough space to save 32 ghosts, 1 per course slot. If you
want to save Time Trial ghosts, it is highly recommended to use separate save
data for each individual page of courses. More save slots for ghost data may be
added in the future.

################################################################################

About Local Multiplayer:

Only Multi-card Multiplayer is supported. Single-card Multiplayer support is
disabled. You and the other players must each have a system in the Nintendo
DS/3DS family and a way to load a copy of the same release of CTGP Nitro.

################################################################################

About Online Play:

A selection of all 32 Nintendo Tracks as well as all 72 Custom Tracks are
available to choose from in the online course roster. All previously excluded
Nintendo courses now function properly online.

If you wish to play CTGP Nitro online you may connect to any Nintendo Wi-Fi
replacement service of your choice, such as Wiimmfi. If you can't connect your
DS to the Internet, the melonDS emulator emulates online support and can be used
to play CTGP Nitro online with ease. A Nintendo Wi-Fi USB Connector may also
work through a Windows XP/Vista Virtual Machine. Alternatively, a mobile device
access point may be used or an alternate router can be set up for cheap. Routers
can usually be configured to have a MAC filter to help deter unwanted
connections, but do note that this is not a secure solution, and it is
recommended to disable the radio when not in use.

For more in-depth information about Mario Kart DS Online Play, please consult
this guide made by MKDS Network:
https://docs.google.com/document/d/1f3PChwQig40UaiPXlh-Gi5CggGiBPzyrpiecLZlT8ZE/edit

For more information about using your Nintendo Wi-Fi USB Connector with Wiimmfi,
refer to this video:
https://youtu.be/zYJqRqAn-ss

If you wish to play online using MelonDS, you can do so out of the box. No
Ethernet connection is required, and no special access point is needed. If you
are having difficulties connecting to Wiimmfi or other services through MelonDS,
you may need to delete your Nintendo WFC Configuration in the Nintendo WFC
Settings. Choose "Options" and select "Erase Nintendo WFC Configuration".

!!WARNING!!
You cannot carry over registered friend codes from a previous Nintendo WFC
Configuration. Doing so will cause the game to crash upon attempting to connect
to any service. To solve this, simply go to Records from the title screen,
choose "Friends", and select "Erase data".

################################################################################

About showcasing & broadcasting:

If you are creating content based on CTGP Nitro, please direct people to this
channel for future updates and releases of CTGP Nitro:
https://www.youtube.com/channel/UC8WmR3h7QfqjBa65i02NBZw

################################################################################

CREDITS:

Project Lead:
SuperGameCube

Logo design:
Dabniel

Title Screen Design:
Birdo
Garhoogin
SuperGameCube

2D Graphics:
Dabniel
Ringo*Astro
Rocoloco321
Super
SuperGameCube

Programming:
Garhoogin
Gericom
GolyBidoof
Rocoloco321
SuperGameCube

Debugging:
Garhoogin
GolyBidoof
Hailbot
Marioiscool246
Rocolocco321
SuperGameCube

Development of Custom Tracks Online:
Garhoogin
GolyBidoof
SuperGameCube
UltimateARHacker

Playtesting:
Fishguy6564
Garhoogin
Hailbot
Hyphen
Jacanapes
Jake02
Marioiscool246
Prellit
Rocoloco321
Scyhigh
Southport
SuperGameCube
UltimateARHacker
Xgone

Spanish Localization:
Rocoloco321
Ringo*Astro
Super
Vard
Xgone

French Localization:
Antiflex
Mapper
Prellit
SombrAbsol
Yoshi Yoshi

Italian Localization:
J0hnn0
Pikalex04

German Translation:
Makyx
Nazuna
Pikalex04
Polish


Custom Track Contributions:

Life Cup:
MONOCHROME RACEWAY             by Rocoloco321
MAKER MOUNTAIN                 by Gren-aid
LLAMA CIRCUIT                  by Jacanapes
MOONLIGHT LAKE                 by AltairYoshi

Egg Cup:
CLIFFSIDE SAND SLIDE           by Egbert45
TOY TIME GALAXY                by Antiflex
MARS COLONY 2150               by Prellit
COLOR CIRCUIT                  by Rocoloco, Okin, Rinorocks

Moon Cup:
MUSHROOM GARDEN                by Xgone
WHITTLE WOODWAY                by Casini Loogi
PIRANHA PLANT PASS             by SuperGameCube
SNOWFLAKE CANYON               by Xgone

POW Cup:
PRO VANILLA LAKE 2             by Southport & Karterfreak
CARRERA CIRCUIT                by Louis Miles
ENVIRONMENT MAP CAVE           by Antiflex
SKY-HIGH ROAD                  by Southport

Spiny Cup:
Wii LUIGI CIRCUIT              by Rocoloco321
SNES CHOCO ISLAND 1            by Prellit
Wii MOO MOO MEADOWS            by Antiflex
N64 TOAD'S TUNRPIKE            by AltairYoshi

Boo Cup:
Wii MARIO CIRCUIT              by AltairYoshi
3DS ALPINE PASS                by Prellit
Tour NEW YORK MINUTE           by Rocoloco321 & Ermelber
N64 WARIO STADIUM              by Mapper

Chomp Cup:
DOKAN COURSE                   by Nintendo
NOKONOKO BEACH                 by Nintendo
GCN MARIO CIRCUIT              by Nintendo
BETA PINBALL                   by Nintendo

SNES Cup:
SNES Mario Circuit 3           by MetaShrew
SNES GHOST VALLEY 3            by Southport
SNES BOWSER'S CASTLE 3         by Southport
SNES RAINBOW ROAD              by Southport

Acorn Cup:
KARTVILLE                      by Rocoloco321 & Yoshidude4
AUTUMN FOREST                  by Eider & JorisMKW
GOOMBA LAKE                    by Southport
CRYSTAL VILLAGE                by Prellit

Freezie Cup:
ROSALINA'S STARTRIP            by Antiflex
SNOWMAN VILLAGE                by Prellit
SNOWY THRILL TRAIL             by AltairYoshi
YOSHI MOUNTAIN                 by Southport

Shine Cup:
ERMELBER CIRCUIT               by Rocoloco321 & Ermelber
TOAD OASIS                     by Ermelber & Jelle
CASCADE JUNGLE                 by Jelle
MOTORCAT's DIRT DERBY          by Jacanapes

Bell Cup:
FLIP-OUT RIDGE                 by AltairYoshi
LED-NEON TOWN                  by Xgone
SKY-HIGH CATHEDERAL            by Bertocho
TOAD'S BBQ                     by Bertocho

Turnip Cup:
N64 LUIGI RACEWAY              by Rocoloco321
SNES MARIO CIRCUIT 2           by Mapper
GBA SHY GUY BEACH              by SuperGameCube
Wii MUSHROOM GORGE             by Prellit

Coin Cup:
N64 MARIO RACEWAY              by Antiflex
SMS BLOOPER SURFING SAFARI     by Hailbot
Tour MERRY MOUNTAIN            by Eider
Wii U ANIMAL CROSSING          by Ermelber

Bob-Omb Cup:
Wii U HYRULE CIRCUIT           by Ermelber & Stomatol
Wii COCONUT MALL               by Ermelber & Yoshidude4
GBA SNOW LAND                  by SuperGameCube
Wii MOONVIEW HIGHWAY           by Ermelber & Yoshidude4

N64 Cup:
N64 DK's JUNGLE PARKWAY        by SuperGameCube & Rocoloco321
N64 YOSHI VALLEY               by Casini Loogi
N64 BOWSER'S CASTLE            by SuperGameCube
N64 RAINBOW ROAD               by SuperGameCube & Rocoloco321

Bee Cup:
PRO MARIO CIRCUIT 2            by Jake02, Karterfreak
SALTWATER LAKE                 by Rocoloco321, Bear, Remurin
ALONSO PARK                    by Bertocho
LAVE BEACH                     by Prellit

Hammer Cup:
GBA CHEEP CHEEP ISLAND         by Ermelber & Casini Loogi
SNES BOWSER'S CASTLE 1         by Prellit
N64 KALIMARI DESERT            by Ermelber & Yoshidude4
Wii U SWEET SWEET CANYON       by Rocoloco321


Battle Stage Contributions:

CITY TRIAL                     by Hailbot
GOOMBA RUINS                   by Xgone
THE SKELD                      by Hyphen
TIMEBOMB TOWER                 by Yosomii
SNES BATTLE COURSE 1           by AltairYoshi
SWITCH URCHIN UNDERPASS        by Ermelber


Alt-Skin Contributions:

Classic Daisy                  by Birdo
Classic DK                     by Birdo
Kangaroo Yoshi                 by AltairYoshi
King Koopa                     by Southport
Minecraft Mario                by Rocoloco321
Paper Dry Bones                by Gren-aid
Robo-Mario                     by JGG
SNES Luigi                     by Southport
Super Show Toad                by Birdo
Urban Waluigi                  by Southport
Waralina & Waluma              by Birdo
Warupichi                      by Birdo


Custom Music Contributions:

3DS Alpine Pass                by Yoshimaster & Krisgames4
3DS Neo Bowser City            by Yoshimaster & Krisgames4
4 Minutes Before Death         by GolyBidoof
DKR Green Wood Village         by Krisgames4
GBA Beach                      by Krisgames4
GBA Snow Land                  by Yoshimaster & Krisgames4
LR Imperial Grand Prix         by Jacanapes
N64 Bowser's Castle            by Krisgames4
N64 DK's Jungle Parkway        by Krisgames4
N64 Kalimari Desert            by Krisgames4
N64 Raceways                   by Yoshimaster
N64 Rainbow Road               by Kitsu
N64 Toad's Tunrpike            by Krisgames4
SNES Bowser Castle             by Krisgames4
SNES Ghost Valley              by Krisgames4
SNES Rainbow Road              by Krisgames4
SNES Vanilla Lake              by Krisgames4
Super Mario 64 Slide/Athletic  by Krisgames4
Super Mario Land 2 Athletic    by Krisgames4
Super Mario Sunshine Event     by Krisgames4
Urchin Underpass               by Yoshimaster
Wii Circuit                    by Yoshimaster & Krisgames4
Wii Coconut Mall               by Yoshimaster & Krisgames4
Wii Koopa Cape                 by Yoshimaster & Krisgames4
Wii Maple Treeway              by Krisgames4 & Yoshimaster
Wii Moonview Highway           by Yoshimaster & Krisgames4
Wii U Animal Crossing (Summer) by Yoshimaster
Wii U Animal Crossing (Winter) by Yoshimaster
Wii U Hyrule Circuit           by Yoshimaster & Krisgames4
Wii U Ice Ice Outpost          by Krisgames4
Wii U Sweet Sweet Canyon       by Yoshimaster & Krisgames4

