Mute MKDS hack by: LuigiXHero
No credit needed took a few seconds

All I did was go through each sequence in nitro studio 2 and set the volume to 0, if for some reason you want to use this hack for your romhack just rip the sdat and put it into your hack.