This hack changes the controls to more closely resemble those of the SNES Kirby games:
- Y inhales and attacks
- B jumps and flies

Note 1: this title has no partners -- so X and A instead mirror B and Y, respectively.

v0.2:
Updated pause menu graphics to show B/Y instead of A/B

Also included are optional patches to not drop the ability when kirby takes damage.

Database match: Kirby - Squeak Squad (USA)
Database: No-Intro: DS (all) (v. 20180806-120027)
File/ROM SHA-1: DBD8F2ECE2B272AE271DA0B83599E9EA8E366F13
File/ROM CRC32: 5C90DF04