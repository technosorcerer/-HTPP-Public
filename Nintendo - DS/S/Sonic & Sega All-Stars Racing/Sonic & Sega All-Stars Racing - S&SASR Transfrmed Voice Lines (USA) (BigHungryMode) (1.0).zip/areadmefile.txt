this is a simple hack of the ds version Sonic & SEGA All-Stars Racing that replaces some character voice lines/all-star themes with the ones from the game's sequel (Sonic & All-Star Racing Transformed)
(also the countdown sounds were replaced with the one's from the J2ME version, that was an oversight :p)

a tutorial might be coming soon (depends if i have motivation to finish the one i already made)

please note that you have to provide your own rom, then use an xdelta patcher to patch the game



uhh that's it i guess