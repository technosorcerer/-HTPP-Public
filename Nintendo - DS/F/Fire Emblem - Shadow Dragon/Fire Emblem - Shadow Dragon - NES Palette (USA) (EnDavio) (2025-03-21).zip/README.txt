Fire Emblem: Shadow Dragon - NES Palette Mod v.1.0

Features:
The colour palettes of several classes, both in battle and on the map, have been altered to restore the consistent red/blue colour scheme for player and enemy units from the NES version of the game. This also extends to the enemy Dracoknights' mounts, which have been changed to green.

Compatibility note:
This mod, by the three included patches, is compatible with all the regional versions of the game. We cannot guarantee compatibility with other mods, but if you wish to install another patch, we suggest attempting to do so after installing this one and disabling Delta Patcher's checksum validation in its settings.

Installation:
- Obtain by your own means an unmodified ROM of the game.
- Obtain a program to apply xdelta patches. A recommended tool is Delta Patcher, which is obtainable form romhacking.net.
- Select the unmodified ROM to use as the source file, followed by the patch that is compatible with your version of the game (FE11_NPM_E.xdelta for the European version, FE11_NPM_U.xdelta for the American version and FE11_NPM_J.xdelta for the Japanese version).
- Click on the button to apply the patch. The modified ROM will then be created. Note that the default setting in Delta Patcher will cause it to overwrite the original ROM, so we suggest ensuring to have a backup or changing the program's settings.

Changelog:
- v.1.0: Initial release.

Credits:
EnDavio - Hacking, graphic editing
CedAodh - Graphic editing support
