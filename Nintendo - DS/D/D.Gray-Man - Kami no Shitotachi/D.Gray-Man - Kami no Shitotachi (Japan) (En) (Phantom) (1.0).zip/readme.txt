Thank you for downloading the English translation patch for the D.Gray-Man NDS game, created by Phantom & Supper!

Before you can play the translation, you�ll need to patch the game on your computer using a legal copy of the ROM.

===

Instructions

-Download xdelta UI from http://www.romhacking.net/utilities/598/ 
-Extract the .rar with WinRAR or 7-Zip.
-Run �xdeltaUI�(not the file simply named �xdelta�)
-For �patch�, choose the �DGrayManPatch.xdelta� file.
-�Source� should be your copy of the ROM, as an �.nds� filetype.
-Finally, set your output destination. 
-IMPORTANT Give the output file any name you�d like, but be sure to add �.nds� to the end, or it will not work e.g. �DGrayManPatched.nds�
-Hit patch, and you�re good to go!

Play this file on an emulator such as DeSmuME, or use a flashcart to play it on any member of the NDS family.

We hope you enjoy!

===

Want to get in touch?

Shoot an email to phantomghosttranslations@gmail.com

===
Hungry for more?

Check out https://phantom-patches.tumblr.com/ for anime game fan-translation projects by Phantom, or visit http://stargood.org/ for more ROM Hacks by Supper!
