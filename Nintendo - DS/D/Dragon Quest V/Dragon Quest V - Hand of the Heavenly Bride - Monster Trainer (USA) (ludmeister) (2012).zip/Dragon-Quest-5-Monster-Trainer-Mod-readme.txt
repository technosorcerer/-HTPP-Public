Dragon Quest 5: Hand of the Heavenly Bride for Nintendo DS
	Ludmeister's Monster Trainer Mod v1.0
	Released March 1st, 2012
	http://jeffludwig.com/
******************************************************************************

This patch kit will convert a stock version of Dragon Quest 5: Hand of the 
Heavenly Bride to Dragon Quest 5 Ludmeister's Monster Trainer Mod v1.0.
Here's exactly what this will accomplish:

Dragon Quest 5 is fun for many of the same reasons that Destiny of an Emperor
was so engaging: you can recruit many different characters at will, and put
together your preferred attack force.  As the vanilla game stands however, the
player's possiblities were hamstrung by the lateness of when certain recruitable
monsters were encountered.  In particular, the Ghost, Wax Murderer, Fat Rat were
not encountered in Chapter 2, even though they were in Chapter 1!

For those that enjoy the monster training aspecs of Dragon Quest 5, this mod
offers greater potential for putting together your winning party.  Secondarily,
it makes monsters easier to recruit, reducing the frustration in grinding to
recruit your favorite potential team members.  It also aims to give different 
monsters equipment which is better suited to their abilities and personalities.



Version 1.0 Changelog
******************************************************************************

	* Numerous recruitable monsters are able to be recruited much earlier in the 
	  game, opening up many different party combinations.  None of the recruitable
	  monsters (with the exception of Rebj�rn) require you to have beaten the game.
	  
	* In chapter 3, there is a "Monster Island" where very nasty monsters can be
	  encountered.  This is a good place to level up, and a great place to recruit 
	  new monsters!
	  
	* The odds of recruiting monsters are much better now.  Less grinding is required
	  to recruit your party.  In recruiting your first of any particular monster, the
	  chances to recruit it will be no greater than 1 in 16 (some were as rare as 
	  1 in 256!)
	  
	* Changed the item drop rate for many monsters.  In particular, Mini Medals will
	  be much easier to win in battles with Mimics/Canniboxes.
	  
	* Equipment used by most monster classes, as well as Bianca and a few other 
	  characters is changed.
	  
	* Many characters and monsters have different level up progressions for stats.
	  Some are subtly tweaked, others more radically.
	  
	* The Pip and Conk monsters are much more able to use their learned spells and 
	  abilities as they level up. 
	  
	* Liquid Metal Slimes and Metal Slimes do not run quite as often, and their
	  Defense is reduced enough that extremely powerful characters stand a chance
	  of knocking them down with normal blows.
	  
	* Some of the weapons and armor have been edited, but nothing too major.
	
	* Monsters drop gold at an accelerated rate, due to the greater financial
	  obligations you will have to outfit your new monster companions!
	  
		

To convert your stock Dragon Quest 5: Hand of the Heavenly Bride ROM:
******************************************************************************

The following applies this and all future releases of the Ludmeister's Monster 
Trainer Mod.

0. First of all, you will need to obtain a clean DS ROM of Dragon Quest 5: Hand 
   of the Heavenly Bride. You will need the US version, ROM #3424.  You are on 
   your own for this step, as it is illegal to provide ROMs of copyrighted 
   material. There are sites that do provide this ROM though, and you should be 
   able to obtain it.

1. When you get it, make a backup of it if you would want to play the stock version, 
   play another mod, or, in case I post an updated version of the mod here... I am not 
   going to make version 1.0 to "version whatever" patches for my mods, for instance.
   
2. Download Ludmeister's Monster Trainer Mod.
  
3. Download Nintenlord's "NUPS" UPS patcher or other similar UPS utility.  You 
   will need it to apply the .ups patch found in the download.  Download NUPS
   at http://www.romhacking.net/utilities/606/
   
4. Apply the .ups patch to your Dragon Quest 5 US ROM using the UPS patching program 
   of your choice.

5. I hope you enjoy it!

