The DS version of Dragon Quest IV had the party chat removed for it’s western release. This patch adds that back in using text from the mobile port of the game, which did include the translated party chat text.

Since this includes all the missing text from the original DS version, this should be the definitive way to play the game.

You will need the USA (En,Fr,Es) .nds ROM for DQIV and XDelta Patcher. If you want to patch the JP version, you will need my JP game patch version, which uses an older process.


Original creator: scbroede
https://github.com/scbroede/dq4-partychat-patcher

AustNerevar
https://proquestinations.com