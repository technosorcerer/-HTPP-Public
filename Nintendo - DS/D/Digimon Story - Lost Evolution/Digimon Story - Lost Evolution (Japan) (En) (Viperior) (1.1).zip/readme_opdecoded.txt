Version 1.0
Two Versions are now provided, one for people who already applied our 1.0 Patch, and one for people who want to apply it on a fresh dumped raw. There is no difference in functionality. The folders are named "Upgrade" and "Full" respectively.

Version 1.0
Notable Limitations:

1) You will not be able to enter Nicknames for Digimon >8 characters. The Default Names will however display the full Name of the Digimon.
2) The Player Name cannot be >5 characters.
3) As you already know from Dusk/Dawn, some names had to be shortened, given the limited space
on the screen available. This was already the case with the Japanese release of this game.
4) The game runs most smoothly on Hardware and melonDS. While we don’t discourage the use of other emulators, you may or may not run into issues with them.
5) Due to the Nature of how we had to handle Text, Sorting by Name will actually not sort by Name. 

Should you spot anything worth reporting, you can contact us via opdecoded@gmail.com
