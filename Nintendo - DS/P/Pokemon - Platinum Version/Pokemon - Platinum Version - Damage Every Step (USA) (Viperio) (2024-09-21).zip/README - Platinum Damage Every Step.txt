Platinum - Damage Every Step

Damage:
- All party Pokemon take 1 HP damage for each step taken.
- Poison damage stacks with this damage (2 HP damage every 4 steps if poisoned).
- This damage can make Pokemon faint in the overworld, but no message is showed.
- This damage can cause a white out.

Healing items:
- All HP healing items have been removed from shops.
- All HP healing items have been removed from wild Pokemon held item pools.
- All HP healing items have been removed from pickup.
- Berries can't be replanted.