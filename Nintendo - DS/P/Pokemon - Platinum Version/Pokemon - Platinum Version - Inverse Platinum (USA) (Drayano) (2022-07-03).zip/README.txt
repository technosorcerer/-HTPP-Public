This is a patch that inverts the type matchups in Pokémon Platinum, using the same rules as XY's Inverse Battles.

This means that type matchups that ordinarily are not very effective or have no effect (immune) are now super effective,
while those that were super effective are now not very effective.

This patch should ideally be applied to Rev 1 USA Pokémon Platinum ROM, with a CRC32 of 69D628E8. It may work on others, though.
You can use the included Lunar IPS program to do it (IPS patches work well for small changes!).

This patch only changes the type chart of the game and absolutely nothing else.
As a result, this game can still be used with the Universal Pokémon Randomizer while keeping the type chart change intact.

Please note this hasn't really been tested thoroughly.
It should work, but not sure what happens in the case of things such as Foresight/Odor Sleuth.

Here is a full list of changed type matchups. Any combo of types not listed takes neutral damage (as normal).

NORMAL vs. ROCK is super effective
NORMAL vs. GHOST is super effective
NORMAL vs. STEEL is super effective
FIRE vs. FIRE is super effective
FIRE vs. WATER is super effective
FIRE vs. GRASS is not very effective
FIRE vs. ICE is not very effective
FIRE vs. BUG is not very effective
FIRE vs. ROCK is super effective
FIRE vs. DRAGON is super effective
FIRE vs. STEEL is not very effective
WATER vs. FIRE is not very effective
WATER vs. WATER is super effective
WATER vs. GRASS is super effective
WATER vs. GROUND is not very effective
WATER vs. ROCK is not very effective
WATER vs. DRAGON is super effective
ELECTRIC vs. WATER is not very effective
ELECTRIC vs. ELECTRIC is super effective
ELECTRIC vs. GRASS is super effective
ELECTRIC vs. GROUND is super effective
ELECTRIC vs. FLYING is not very effective
ELECTRIC vs. DRAGON is super effective
GRASS vs. FIRE is super effective
GRASS vs. WATER is not very effective
GRASS vs. GRASS is super effective
GRASS vs. POISON is super effective
GRASS vs. GROUND is not very effective
GRASS vs. FLYING is super effective
GRASS vs. BUG is super effective
GRASS vs. ROCK is not very effective
GRASS vs. DRAGON is super effective
GRASS vs. STEEL is super effective
ICE vs. WATER is super effective
ICE vs. GRASS is not very effective
ICE vs. ICE is super effective
ICE vs. GROUND is not very effective
ICE vs. FLYING is not very effective
ICE vs. DRAGON is not very effective
ICE vs. STEEL is super effective
ICE vs. FIRE is super effective
FIGHTING vs. NORMAL is not very effective
FIGHTING vs. ICE is not very effective
FIGHTING vs. POISON is super effective
FIGHTING vs. FLYING is super effective
FIGHTING vs. PSYCHIC is super effective
FIGHTING vs. BUG is super effective
FIGHTING vs. GHOST is super effective
FIGHTING vs. ROCK is not very effective
FIGHTING vs. DARK is not very effective
FIGHTING vs. STEEL is not very effective
POISON vs. GRASS is not very effective
POISON vs. POISON is super effective
POISON vs. GROUND is super effective
POISON vs. ROCK is super effective
POISON vs. GHOST is super effective
POISON vs. STEEL is super effective
GROUND vs. FIRE is not very effective
GROUND vs. ELECTRIC is not very effective
GROUND vs. GRASS is super effective
GROUND vs. POISON is not very effective
GROUND vs. FLYING is super effective
GROUND vs. BUG is super effective
GROUND vs. ROCK is not very effective
GROUND vs. STEEL is not very effective
FLYING vs. ELECTRIC is super effective
FLYING vs. GRASS is not very effective
FLYING vs. FIGHTING is not very effective
FLYING vs. BUG is not very effective
FLYING vs. ROCK is super effective
FLYING vs. STEEL is super effective
PSYCHIC vs. FIGHTING is not very effective
PSYCHIC vs. POISON is not very effective
PSYCHIC vs. PSYCHIC is super effective
PSYCHIC vs. DARK is super effective
PSYCHIC vs. STEEL is super effective
BUG vs. FIRE is super effective
BUG vs. GRASS is not very effective
BUG vs. FIGHTING is super effective
BUG vs. POISON is super effective
BUG vs. FLYING is super effective
BUG vs. PSYCHIC is not very effective
BUG vs. GHOST is super effective
BUG vs. DARK is not very effective
BUG vs. STEEL is super effective
ROCK vs. FIRE is not very effective
ROCK vs. ICE is not very effective
ROCK vs. FIGHTING is super effective
ROCK vs. GROUND is super effective
ROCK vs. FLYING is not very effective
ROCK vs. BUG is not very effective
ROCK vs. STEEL is super effective
GHOST vs. NORMAL is super effective
GHOST vs. PSYCHIC is not very effective
GHOST vs. DARK is super effective
GHOST vs. STEEL is super effective
GHOST vs. GHOST is not very effective
DRAGON vs. DRAGON is not very effective
DRAGON vs. STEEL is super effective
DARK vs. FIGHTING is super effective
DARK vs. PSYCHIC is not very effective
DARK vs. GHOST is not very effective
DARK vs. DARK is super effective
DARK vs. STEEL is super effective
STEEL vs. FIRE is super effective
STEEL vs. WATER is super effective
STEEL vs. ELECTRIC is super effective
STEEL vs. ICE is not very effective
STEEL vs. ROCK is not very effective
STEEL vs. STEEL is super effective