hinkage's Battle Factory Challenge v4.0


ROM Base:
Pokemon - Platinum Version (USA) (Rev 1)

Patch using Xdelta:
https://www.romhacking.net/utilities/598/

Tested on DeSmuME emulator 0.9.11_x86 (if there are any emulation issues).


Rental Pokemon spreadsheet:
https://docs.google.com/spreadsheets/d/1UT-Ft9Ld-1hJQJZUBLhJAsoENkArIwK-/edit?usp=sharing&ouid=102662568641268076999&rtpof=true&sd=true
It details every level 100 rental Pokemon's moves, item, ability, and EVs.


About:
This is a "small" hack of Pokemon Platinum that removes the physical/special split, and takes the player straight to the Battle Factory.

For those of you who don't know:
Prior to gen 4, a move uses the Attack stat or Special Attack stat based on its type; it is not unique for each move. This is known as the "pre-physical/special split" era.
Here is a list of whether each type is physical (uses Attack) or special (uses Special Attack):
PHYSICAL TYPES:
Normal
Rock
Ground
Flying
Fighting
Ghost
Bug
Steel
Poison
SPECIAL TYPES:
Fire
Water
Grass
Electric
Dragon
Psychic
Dark
Ice


Things to note:
-Hidden Power is not yet included in this hack, but if it were, it unfortunately would NOT be type-based. If this hack expands, I'll definitely get a fix for that.
-All the Clowns are named Phil/Phillip.
-All the Guitarists sing real lyrics.
-As of v4.0, this hack is oficially renamed from "Pokemon Platinum Version - No PSS" to... its current name.


Completed updates:
-v1 Revamped all 950 possible rental mons to have more appropriate stats, natures, and/or movesets.
-v3 Balanced rental mons from v2; turns out it WAS severely needed.
-v3 Add easychat-esque text for the Battle Factory opponents, a la gen 3.
-v3 Crunch has been reverted to lowering SpDef once again. Flash Cannon was changed to lower Def.
---(Crunch lowered SpDef in gens 2 and 3 and was changed to lower Def in gen 4 onward when it became physical; the same makes sense for Flash Cannon).
-v3.5 added ability to change battle music. Leave the Factory and talk to the Guitarist to change it.
-v3.5 updated low HP bar sound.
-v3.5 doubled HP bar drain speed.
-v4.0 New titlescreen!
-v4.0 added ability for player to change lobby/arena and Frontier Brain battle music.
-v4.0 TRIPLED HP bar drain speed, and quadrupled its fill speed.
-v4.0 removed some unecessary parts of the intro, like the rival naming sequence.
-v4.0 rewrote some text from v3.5, like Thorton's and the "ADVENTURE INFO" (now called "HACK INFO") details at the beginning of the game.
-v4.0 updated Crunch and Flash Cannon move descriptions to match their changed effects.
-v4.0 Intimidate text changed to 2 lines instead of 3 (it saves a couple unnecessary seconds of waiting/mashing).
-v4.0 Thunder attack text changed to Pokemon Stadium Announcer 8) because it's fun.
-v4.0 Almost complete overhaul--yet again--of most mons, as they were still too OP. 


MAYBE updates:
-Make more changes to the level 50 mons; as of v4.0 there are only minor edits
-?????


Bugfixes:
-v3.5 fixed a Parasol Lady's opening text that was just "PARASOL LADY"
-v4.0 fixed battles having no music by default (var wasn't initialized)
-v4.0 fixed Thorton text issues/other minor text issues
-v4.0 Uproar move effect lol (Idt I used it before v4.0 anyway but still)
-v4.0 probably a few others I forgot


CREDITS:
Me--paying taxes and wageslaving
AdAstra--coding dynamic music routines for regular battles, the Factory Brain battle, and in the Factory lobby/arena

SPECIAL THANKS:
Mikelan, BagBoy, and Nitram--HP bar drain/fill speed modification
Lhea, HD125D--all their help and making dynamic music possible
LRXC--balancing suggestions


Thanks for playing!
If you like this, check out my other DS ROM hack "Richard," my Make A Great Map 7 contest entry, also in the Sideshow Showcase on Ped--er, PokeCommunity. It's kewl.