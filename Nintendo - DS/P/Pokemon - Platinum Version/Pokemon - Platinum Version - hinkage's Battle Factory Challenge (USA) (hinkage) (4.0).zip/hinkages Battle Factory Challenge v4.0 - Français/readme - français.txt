hinkage's Battle Factory Challenge v4.0 - Français


ROM :
Pokemon - Platinum Version (USA) (Rev 1)

Patcher le ROM en utilisant Xdelta :
https://www.romhacking.net/utilities/598/

Jouez en utilisant DeSmuME emulator 0.9.11_x86


Tableur des Pokemon :
https://docs.google.com/spreadsheets/d/1kNV8qiAdoy3jPWxNXe67W5raSKCZnw3H/edit?usp=sharing&ouid=102662568641268076999&rtpof=true&sd=true


Un attaque est physique (utiliser le stat d'Attaque) ou spéciale (utiliser le stat d'Attaque Spéciale) basé sur le type
LES TYPES PHYSIQUES :
Normal
Roche
Sol
Vol
Combat
Spectre
Insecte
Acier
Poison
LES TYPES SPÉCIAUX :
Feu
Eau
Plante
Electrik
Dragon
Psy
Tenebres
Glace


CREDITS:
Me--paying taxes and wageslaving
AdAstra--coding dynamic music routines for regular battles, the Factory Brain battle, and in the Factory lobby/arena

SPECIAL THANKS:
Mikelan, BagBoy, and Nitram--HP bar drain/fill speed modification
Lhea, HD125D--all their help and making dynamic music possible
LRXC--balancing suggestions


Thank you so much for to playing my game!