This mod replaces Phoenix Wright's voice clips in "Professor Layton vs. Phoenix Wright: Ace Attorney" with those from "Phoenix Wright:
Ace Attorney – Dual Destinies". This only covers the four clips used in both; naturally, those exclusive to the crossover could not be
replaced.

To install this, just copy the "luma" folder to the root of your SD card. If softpatching is not already enabled, you can turn it on
by holding Select as your power on to access the Luma3DS menu. From there, you can just run the game and the mod will automatically work.

NOTE: Although this mod is set up to affect both the American and European versions of the game, the latter is untested, and theoretically
may not work correctly if the files are in a different location inside the game.