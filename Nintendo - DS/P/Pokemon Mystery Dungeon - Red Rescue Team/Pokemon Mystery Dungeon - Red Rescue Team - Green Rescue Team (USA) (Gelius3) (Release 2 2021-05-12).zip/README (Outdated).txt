Pok�mon Mystery Dungeon - Green Rescue Team (Release 2)
By Gelius

Introduction:
You ever questioned why we got Blue and Red Rescue Team, but never Green Rescue Team?
Well, question no more!

Pok�mon Mystery Dungeon - Green Rescue Team is like a third version to Red and Blue Rescue Team, with it's fair share of quality of life changes and it's unique spin on dificulty.

Patching tutorial:

While we can't provide you with the rom i used or where to obtain one, i can tell you that you'll need a clean Pok�mon Mystery Dungeon - Red Rescue Team (USA, Australia) rom to play it.
Then use the patch and patcher we provided.
Put it all together.
And Voil�.

(Oh and you need an Emulator, any should work. I used VBA-M, but your choice's on your own)

Credits:

Before i go to some changes i made, i should go over the credits.

First, big thanks to FragOnCrack and Nahnegnal, for they not only helped me with some things i had issues on, but they also served as an inspiration. I seriously recommend playing their romhack if you haven't already, they are amazing and i assure you it's better than mine.
Additional Credits to Nahnegnal for his willingness to teach me the language of wizards: Hex Code Editing. It's not easy, and i'm still on the proccess of learning, but i'll get there.
Credits for the creator of PMDe (Forgot what's their name).
Huge shoutout to the PMD Advanced Discord Server, as they were there when i was making this. It also happens to be where a lot of the RRT Hacking community is.
Additionally, big thanks to the SkyTemple Discord Server, as some people there assisted me in some stuff down the line (Even though it's a Server dedicated to EoS). They're making a EoS editing tool, so i recommend you check it out.
Big thanks to my Beta Testers (Whom i'm keeping in secret).
Big, big shoutout to Mystaldi, who allowed me to post this on his Discord Server! Check out their channel, as they're amazing.
Also credits to Nintendo/Pokemon Company/Gamefreak because they own Pok�mon.
And for Chunsoft (Later named Spike Chunsoft) for creating both Red and Blue Rescue Team and Rescue Team DX, as it served as some inspiration to some of the changes.

Without further ado, let's move into the changes.

Changelog:

Release 1:

Some Dungeons change visual aesthetic mid dungeon where they normally wouldn't. Music too!
Items were assigned a palette swap. This is to help categorizing some items more easily.
Some dungeons have new spawns you have to be on the lookout for. Not every dungeon has them, but most have them, ranging from subtle to big changes.
Some of these spawns are a combination of PMD Red and Blue, and PMD DX.
Re-instated some unused spawns naturally in the game (Nothing like legendaries or game breaking, obviously).
All version exclusives were removed. You can now find those pesky version exclusives without having to do missions involving the version exclusive.
Friend Areas are purchasable from the start! (Except Absol's, still Story event)
Fully evolved Pokemon can be recruited! Long gone are the days of being unable to recruit those. Of course, it's still encouraged you evolve Pokemon over recruiting the evolved form, due to certain level up moves a Pokemon can learn in earlier stages.
Purity Forest was made a tad bit easier (AKA more bearable), but this is still somewhat experimental.
The DLC Dungeons also had it's own changes. The codes that usually unlock them still work with this version, so feel free to get them to unlock Oddity Cave, Remains Island, Fantasy Strait and Marvelous Sea.
The Main Story Dungeons will allow you to take a full team of 4 to the dungeons. Finally, will you be able to complete the main story with your Absol and Magnemite exploring together with you, or whatever squad you got up!
There's Post Game changes.

Release 2 (The Dificulty Patch):

General Dificulty curve ramped up.
A couple changes to Spawn Tables were made, to slot in more Pokemon and make the dungeons more varied.
Most Post Game Dungeons now rarely go under the level 30 mark, with some dungeons harder than others.
Boss Fights got a level buff in general.
Most Pokemon gained a Second Ability where they didn't, some swapped some Abilities in and out, and some got type changes.
A sizeable amount of Dungeons changed name, and some friend areas were updated to their DX names. This also came with Text changes.
Weather was added much earlier on in the game.
A couple general changes to some dungeons were made.

Add-Ons:

Currently, the only mod that's compatible is the Red Rescue Team Complete Team Control Hack/Mod, also known as "Manual Movement" by Jirt. While you could try to play without it, given the general raised dificulty, you may prefer having full control of your team rather than leaving it all to a dumb AI.

Kecleon Shops:

Now you might be thinking: What do i mean with "Kecleon Shops"?

Whith the .zip file i will include a list of where Kecleon Shops may be found. This will be extremely useful for those who are relying on getting these to either recruit Kecleon or get certain items, or to check if it's worth bringing money to a dungeon. This list applies to Red, Blue and Green Rescue Team, as between the originals and the hack, i didn't change where the shops spawn. Seriously, check it out, it's going to help you.

FAQ?

Q: Where can i get the rom?
A: Not telling you

Q: Is the game harder than the regular one?
A: Yes, absolutely. While playtesting for the first time, we found the game to actually be harder. Release 1 was moderately harder, but Release 2 now will be rather hard with the dificulty changes we applied.

Q: Can i ask for the rom?
A: No, get it yourselves.

Q: Have you touched the Post Game?
A: Yes, the Post Game had alterations, namely dificulty. This means the hack is somewhat complete

Q: Wait, "Somewhat complete"? Does this mean there'll be no updates?
A: While they're not on the scope right now, new updates aren't out of question! If PMDe gets updated with new features, i might have an easier time making updates. Currently, editing the Hex Code is so convuluted for myself it would take ages for me to fully understand it. Updates based on feedback (for balancing purposes) can happen, but asides that, Release 2 could very well be the final update.

Q: Have you used the unused Dungeons?
A: As much as i'd want, currently, that's impossible. The dungeon Count is still the same as the original. Plus, if i wanted to add any dungeon anyways, it'd be Wonderous Sea. Which, like i said, with my current scope, it's impossible. Same with recreating the Illusory Grotto.

Q: I bought this game on a cartridge.
A: Then you probably were ripped off. It's your money, i don't responsiblize for that. All i say is that this rom hack's free anyways, so if you paid money for it, you were ripped off big time, my pal.

Q: Can i stream/let's play this hack?
A: Yes! You can! Just be sure to credit the rom hacker, obviously!

Q: Can i edit the hack?
A: While yes, you can, it will not be considered an official update. As such, any edits you do, will not be deemed as oficial. They could be eventually implemented, but it's unlikely.

Q: HURR DURR YOUR HACK SUXKZ, GO AWAY
A: Then why did you play it in the first place?

Q: The game doesn't look like much.
A: Understandable view. I too don't see it as much. It's just a small thing i started making for myself. If you enjoy it, then thanks. If it isn't a big thing for you, decision accepted. Just don't be like the sentence mentioned above. That's not criticism, that's just being a jerk.

Q: Do you have a Discord Server?
A: I have Discord, but not a Server. You can find me in Nahnegnal's Discord Server, The Spinda Cafe Discord Server and the SkyTemple Discord Server though. Of course, don't flood the room with questions of my romhack, it's their server after all!

Q: Any particular part you see being dificult?
A: Considering i just updated the entire game to ramp up the dificulty, i might just say the entire game. Those before still apply, but surely others like Murky Cave, Frosty Forest, Mt. Freeze, Silver Trench, Mt. Faraway, etc are much much harder than the original.

Q: Do you plan to make "Yellow Rescue Team" or do something for Blue Rescue Team?
A: No plans for Yellow Rescue Team exist as of now (as there's already a hack doing that anyways), and currently, there's not enough to hack in PMD Blue.

Q: The Rom Hack's too dificult.
A: Yeah that's exactly what may happen. Even i fear my own creations sometimes.

Any further questions, feel free to ask!

With that, i will finish this README wishing you happy playing!