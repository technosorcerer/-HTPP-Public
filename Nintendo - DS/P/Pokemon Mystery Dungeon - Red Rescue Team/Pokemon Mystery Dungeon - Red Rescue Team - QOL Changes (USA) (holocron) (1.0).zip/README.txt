

             Pokemon Mystery Dungeon - Red Rescue Team 
             QOL Changes Hack by holocron
                     Version 0.9

----DESCRIPTION-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
This is a hack for Pokemon Mystery Dungeon - Red Rescue Team that makes several changes,
including buffed recruitment values, color-coded items, the ability to control the player and partner separately, and more!
See patchnotes.txt for full list of changes.
I hope this patch makes your Red Rescue Team experience even just a little bit smoother.


----INSTALLATION-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
This patch comes in the form of an .ips file.
For Windows users, simply open the patch and select a US/AUS Pokemon Mystery Dungeon - Red Rescue Team ROM, the patch will then apply itself.
For Linux users you can use programs such as JIPS or lazy_ips to apply the patch.
For Mac users you can use Multipatch


----BUGS--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
I haven't run into any myself. If you find a bug please contact me via one of the folling channels
https://www.pokecommunity.com/member.php?u=838661
https://www.reddit.com/u/hoIocron


----SPECIAL THANKS----------------------------------------------------------------------------------------------------------------------------------------------------------------------
Special thanks to Cipnit for allowing me to use his Complete Control Hack. https://www.pokecommunity.com/showthread.php?t=418131
