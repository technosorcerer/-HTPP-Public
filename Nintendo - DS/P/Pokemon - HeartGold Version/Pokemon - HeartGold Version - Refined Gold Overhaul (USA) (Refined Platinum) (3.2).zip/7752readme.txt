﻿Refined Gold Overhaul patch for Pokemon Heartgold
By RefinedPlat
Link to this changelog on Google Docs
https://docs.google.com/document/d/1I_Vukoq3CK2q4BtcglUp9x-OZh4hEJqHhfzjmPQv0l8/edit?usp=sharing


For the record, this is only associated with Refined Gold, Refined Platinum, and not-yet-released Gen 5 patches.
Absolutely NO connection to Refined Crystal or anything.
1X Introduction
1X0 List of Changelogs
General Changelog (encounters, evolutions, additional ground items, technical stuff) https://docs.google.com/document/d/1I_Vukoq3CK2q4BtcglUp9x-OZh4hEJqHhfzjmPQv0l8/edit?usp=sharing
Trainer Changes Johto
https://docs.google.com/document/d/1e-8zYV6Y3WI7-58M7Q8jibizpzi_eTJJq-Bi3lxxdq4/edit?usp=sharing
Trainer Changes Kanto
https://docs.google.com/document/d/1FYcb91VcAZV70QW7axim6V7Qe97v_FCHdHKxJiH3ZKM/edit?usp=sharing
Moveset Changes
https://docs.google.com/document/d/1Ra0BZ8W9yurPtCScD2yKljOnLlEFM6T3fpBtAheTIyI/edit?usp=sharing
Wild Held Items Changes
https://docs.google.com/document/d/1QSrpM1LBqMNHrK2TXg1l1J07b_TU4rZuKEm5LCXDiRE/edit?usp=sharing


Download Link (in case you found the document via Google Docs only)
https://www.romhacking.net/hacks/7752/


1a Table of Contents


1X Introduction
1X0 List of Changelogs
1a Table of Contents
1bX Releases
1b1 Refined Gold Overhaul changelog
1b2 Refined Gold base changelog
1cX About
1c0 Which to Play
1c1 General Refined Gold
1c2 The Overhaul
1d Applying
2X Pokemon Changes
2a Evolution Changes
2bX Movepool Changes
2b1 Legendary Movepool Changes
3X Wild Encounters
3aX Johto-Dex Accessibility
3a1 Formerly Kanto-only
3a2 Formerly Kanto or Safari-only
3bX Wild Encounters - Radio
3b1 Hoenn Radio
3b2 Sinnoh Radio
3cX Wild Encounters - Walking
3c1 Johto
3c2 Kanto
3c3 Rock Smash Encounters
3c4 Dynamic Encounters
3c5 Safari Zone
3dX Wild Encounters - Surfing
3d1 Johto
3d2 Kanto
3eX Wild Encounters - Fishing
3e1 Johto
3e2 Kanto
3f Wild Encounters - Starters
4X Event Changes
4a Overview and Levels
4b Event Changes List
4c Legendary Encounters
4c1 Post-Dex
4c2 Post-Blue
4c3 Post-Red
5X Item Changes
5aX Evolution Items in the Overworld
5a1 About
5a2 Johto
5a3 Kanto
5b Shop Changes
5c TMs
5d Fossil Guild
5e Misc.
5fX Held Item Changes
5f1 Legendary Items
6X Technical Stuff
6aX Flags
6a1 Important Flags
6a2 Formerly Unused Flags
6b Variables Used
6c Script Archives Added
6d Event Files
6e Text Archives Added
6f Encounter Files Added
6g Notable Maps
6h MISC.
7X Trainers
7a Trainer IDs Added
7b Trainer Contents
8X Random Stuff
8a Random Thoughts
9X FAQ
ZX Disclaimer and Credits


1bX Releases
1b1 Refined Gold Overhaul changelog
v3.2 - February 24, 2024
Tavern Trawl
- The entire fishing encounter table has been revised and improved! Documentation reflects this and now both lists accurate information and accounts for Night fishing.
- A variety of NPCs consisting of Johto Elite Four members and figures from Sinnoh will now appear and be available to be talked to as the player progresses.
        * Johto and Kanto Gym Leaders now have additional dialogue at their photo locations and can be talked to repeatedly after refusing a photo. (Photos can still be taken infinitely by reentering the area)
- Using the postgame Block system, 2nd stage Johto Starters can be found in the Safari Zone. This means once the player has access to 1 block of the respective biome, they can acquire Johto Starters without further delay. Johto Starters have been removed from standard encounters altogether. See 3c5 for more details.
        * Kanto Starters remain in lategame Kanto, along with Hoenn and Sinnoh starters found via Radio in those routes.
- Made it clearer that the first tier of superbosses are available in the dialogue after getting Rock Climb from Professor Oak.
- Redid the former Johto starter routes as well as 47 and 48.
- Reworked Hoenn and Sinnoh Radio encounters to improve cohesion.
- Reverted Bugsy's Scyther back to having Quick Attack instead of Cut. Also tweaked Whitney.
- Optimized Superboss teams with better movepool and item synergies.
- Fixed a bug where Clair's Fighting Dojo rematch would not shut off the rain afterwards.
- Fixed a bug where entering the Furret House on a bike would crash the game.
- Various minor fixes and improvements.
v3.1 - December 11, 2023
Climax of Avaritia
- The Superboss update is finally out after a year and a half! This is post-Blue content and not to be taken lightly. See the Kanto Trainer Changelog for more details!
    * After defeating two of Mr. Game, Elder Li and Kimono Girl Kuni, you will get a strange call to go to Viridian Forest!
    * Proton, Petrel, Archer, Ariana, and Eusine are all available as team-testing postgame content.
    * The preexisting fights have been rebalanced to improve level balancing and battle quality.
    * Added three normal trainers to Ariana’s location.
- Fixed a major bug involving Safari Zone.
    * You should now be able to complete the Warden’s Owner Aptitude Exams and catch Pokemon in the right areas.
- Fixed a bug with certain fights repeating mid-battle dialogue by removing the offending lines.
- Removed a small amount of irrelevant content that was intended to be scrapped a long time ago.
- Added the Furret House.
- Various minor fixes and improvements.
v3.0.6 - November 18, 2023
From Whitney, With Spite
- Substantial reworks to the early and midgame Johto exp curve to make the game flow better and have a more organic curve.
    * Exp Curve is now balanced such that a team of 5 will not overlevel; formerly it was balanced around a team of 4 which caused moderate grindiness.
    * See the Trainer changelog for more details.
    * No meaningful changes to Radio Tower onwards.
- A Move Relearner is now in Cianwood.
- The Snowpoint Move Tutor is now in Lake of Rage regardless of player choices.
- Player is now given 10 Poke Balls after completing the catching tutorial instead of 5 to match modern games.
- Slowpoke now evolves into Slowking by leveling up while holding a King’s Rock instead of by using a Water Stone
    * Poliwhirl still evolves into Politoed after learning Rain Dance
- Fixed a bug with Onix not evolving in the day.
- Fixed a bug where Move Tutors required you to have at least one of all 4 shards.
- Small changes to Kanto's wild encounter levels.
- Minor bug fixes and improvements, replaced most MultiLocalText with ListLocalText for ease of use.


v2.0.2 - September 3, 2023
- Buffed Suicune and Regigigas’s levels.
- Buffed various trainers around Goldenrod.
- Nerfed the level of Route 34 Eevees so they can evolve into Leafeon and still learn Razor Leaf.
v2.0.1 - September 3, 2023
- Very disappointed in Registeel.
- Minor fixes and improvements.
v2.0 - August 30, 2023
Kant Stop Me Now
- KANTO HAS BEEN COMPLETELY OVERHAULED!
- Kanto is now an engaging postgame and features a level curve from mid 50s way off to the grand finale against Blue's level 72 Umbreon.
    * Trainers in Kanto are much stronger with bigger, more intricate teams. Nothing obscenely difficult, but be careful - they just might surprise you!
    * Kanto's progression is more "directed" levelwise, giving a faint sense of movement and texture instead of mush.
    * Kanto wilds have been blanket buffed. May be tweaked more later.
    * Fighting Dojo Rematches have been buffed accordingly.
    * There is no significant plot in Kanto, only coherent trainer progression.
- Minor buffs to the initial Elite Four, especially Lance.
- Improved some trainer text and Pokegear conversations to reflect changed trainer classes.
- Fine-tuning of some encounter files in both Kanto and Johto.
    * A few repel manips from vanilla are now possible again, but you'll have to check the new levels required in DSPRE by yourself.
- Gave Registeel a can of tuna and told him to do a crime.
- Added Stone Edge TM to the Waterfall area in R47.
- Gracieda now works with all Shaymin.
- Additional minor fixes and optimizations.


v1.4.3 - August 1, 2023
- Hugh in post-Waterfall Mt. Mortar now has a proper team.
- The Thief TM in Mt. Mortar and the Thief TM in Rocket HQ now properly use the same flag.
- Minor fixes and tweaks.
v1.4.2 - Unknown
- Re-fixed a major glitch that made the game load the incorrect variant of nonlinear trainers.
v1.4 - July 25, 2023
Jot Down Johto
- Substantial Johto trainer tweaks to have more random moves like Taunt to make the team composition feel more organic.
- The final first tier gym leader in Kanto (Erika, Janine, Sabrina) will now have a sixth Pokemon.
    * All of the second tier Kanto Gym Leaders (Brock, Blaine, Misty) now have six Pokemon instead of just Brock.
- Rematch Clair in the Dojo now has a new team and calls auto-Rain.
v1.3 - July 18, 2023
- Fixed a bug where Kanto gym leaders would load the wrong trainer file
- The player now goes through Diglett’s Cave after the first tier of Kanto to Pewter instead of taking Route 19. Basically to get the Pewter and Cinnabar it’s like vanilla HG now instead of heading south from Fuchsia and wrapping around.
- Various minor fixes.
v1.2.3 - June 29, 2023
- Whitney has been nerfed somewhat.
v1.2.2 - Unknown
- There is now a lady who will trade you Shards in exchange for your Athlete Points.
- Various shards added to ground items; see 5X for more details.
v1.1 - Unknown
- The Fossil Guild is now open in the Route 2 Nugget house.
- A lady in Ruins of Alph will now let you revive Fossils after completing all of the panel puzzles.
- An Old Amber can now be found in Dark Cave Route 45 side.
    * Old Amber can no longer be found in Ruins of Alph. It is still renewable by trading Rare Bones to the Fossil Guild.
- Fixed a gamebreaking glitch involving level 0 encounters spawning.
- Minor improvements and optimizations.
v1.0.4 - Unknown
- Various minor level up and encounter tweaks
- Ruins of Alph and Cliff Cave now give access to version exclusive fossils.
v1.0 - May 8, 2023
The Overhaul, first release!!!
Main Changes
- The entirety of post-Morty up until Radio Tower is now fully nonlinear.
    * All relevant trainers, including Gym Leaders, will scale based on completion of the “tracks” of Olivine and Mahogany.
    * Wild encounters also scale. Saving and reloading in a map will load the weaker version, but will update to the appropriate level on reentering the map.
    * The 7th Gym Leader will now have 5 Pokemon instead of 4.
- Lake of Rage trainers are now post-Pryce content to mirror Route 47.
- The entire game has been overhauled for a difficulty curve below Renegade Platinum but firm enough to challenge the average player. The level curve also is now functional and does not leave Johto with a dearth of exp.
- While incomplete, Kanto has had some band-aid changes to bosses. Trainers are not comprehensively fixed yet.
Other changes
- Additional movepool changes, namely to Sandshrew and Typhlosion.
- Move Tutors that accept shards have been added.
    * There is one in Ecruteak, one in Saffron, and depending on your path one in either Lake of Rage or Cianwood City.
- A woman on the way to Pokeathlon Dome will trade Athlete Points for shards.
- You can now skip the catching tutorial. Additional text has been optimized.
- Improved in-battle text on boss fights. Format is now First Non-OHKO Hit->Last Pokemon instead of Last Pokemon->Last Pokemon Critical HP. Falkner, Bugsy, Whitney are unaffected.
- Moomoo Farm Miltank now takes 5 Oran Berries to be fully healed instead of 7.
- Rocket HQ now has text on the computers. This elaborates on the plot of the game with only a little conjecture.
- Various minor text changes and script fixes.
1cX About
1c0 Which to Play
If you are starting a new playthrough but are not sure which hack to play, you probably want *Refined Gold Overhaul*.


Basically, if you want the full experience of the revamped Heartgold, want to experience nonlinear progression during the midgame, or are interested in a complete HGSS romhack that doesn’t have the bells and whistles of Sacred Gold et al, play *Refined Gold Overhaul*.
If you simply want to replay vanilla Heartgold with the option of completing the National Pokedex and encounter/boss options that don’t have the diversity of boiled cabbage, play base Refined Gold.


This is NOT like Renegade Platinum where there is a “full” version of the hack and one with dialed back balancing tweaks but the same basic gameplay. Refined Gold Overhaul is its own hack, being a very different experience with vastly more rebalancing, trainer changes, and overall improvements.
1c1 General Refined Gold
**THIS IS A 493 PATCH, MEANING ALL POKEMON INCLUDING LEGENDARIES AND MYTHICALS ARE AVAILABLE**


Refined Gold is a hack intended to allow the player to complete the National Pokedex in Heartgold as well as providing moderate QoL improvements. It's basically a "remaster" of HG with QoL while still staying as true as possible to the vanilla experience. All exotic Pokemon are in the postgame, meaning it plays fairly similarly to the vanilla Heartgold. The focus on the main game encounters is instead opening up options and being more flexible with the RNG instead of having things like 5 different 1% encounters.
The core plot is identical to vanilla Heartgold. If you want to go back to Heartgold, whether to revisit memories or make new ones, this mod is meant to help make them a little more vivid.


* All 1% chances (Yanma, Marill, etc) have been increased to 4% minimum where possible.
* Legendaries are also scattered across the map as NPCs, with most willing to fight you after you've beaten Lance or Blue.
* Kanto now has a wild level curve meant to go from “post-Victory Road” up to an appropriate level to make it into an actual postgame. This is a big departure from vanilla, but because Kanto's wild Pokemon feel bland in vanilla in both difficulty and variety, this is an acceptable cost.
* Every TM, berry, and evolution item has been made renewable. TMs are sold in the Good Rod Angler's house in Olivine once you beat Lance, while additional evolution items and berries can be bought in Vermillion with 10 badges.
* Johto itself has a very poor power curve, so I have taken the liberty of adding in certain evolution items and select TMs to improve the player's tool access. Normally, you would HAVE access to, say, a Leaf Stone but only by farming phone calls with Gina or using the Pokeathlon; now you can find one post-Surf in Cherrygrove. Of the Gen 4 evolution items, only 1 Shiny Stone and 1 Dusk Stone have been added.
* HP counters fall up to 2x faster. This is purely aesthetic. Gen 4 is famous for its HP counter falling incredibly slow in this generation, as it never increases in speed to make up for higher HP foes. So, this hack inherently has 2x HP drain speed in effect. This isn’t too noticeable, but helps a lot in the endgame with high HP foes. Credit to Nitram for the specific method used.
* I cannot confirm the edited ROM is still compatible with additional edits to the speed, and am not responsible if doing so breaks your game. But, if the appropriate change is made to the relevant overlay, it should be fine. Remember to make backups and be safe. 
1c2 The Overhaul
Because Heartgold has such a painful level curve and Pokemon distribution, I did an "Overhaul" of my original hack. While it's still within Johto Dex limitations, the wild encounters are much more interesting and trainers are competently built with engaging teams. Pokemon such as Swinub and Houndour are available in time for the main game, and important trainers such as Proton and Eusine have more impactful and thematic teams.
It's not a difficulty hack and should feel a little harder than USUM without being overboard.


In essence, RGO is what I imagine Heartgold *would* have been if it was a new game with HG’s dex but Platinum’s standards for gameplay and quality, plus some additional revamping for fun. Although the maps and plot are for better or for worse the same tier as GSC, the trainers are engaging and the atmosphere is as top-notch as it always has been.
At its core, think of this less as an enhancement hack like Drayano’s work and more as a *restoration*; the hack goes to great lengths to maintain key components of the original (freedom to pick their path post-Morty, the HGSS Johto Dex, etc) while still doing its best to improve upon equivocally flawed parts of it (terrible boss teams, poor access to Johto Pokemon on trainers and wilds, lack of direct access to evolution items, etc).


That said, what really sets apart Refined Gold Overhaul is that there are several novel advancements in the scripting department that I made to better capture the original experience. These include shop scripts, shard move tutors, and my crown jewel, the nonlinear segment.
* From post-Morty to Radio Tower is fully nonlinear, allowing the player to pick their own path. This recreates the original choice in vanilla without sacrificing player agency or gameplay quality.
* Both trainers and wild encounters will become more powerful after completing a "track", either by finishing Rocket HQ or getting the SecretPotion.
* Gym trainers and leaders scale off of the player's badge count, with the 7th Gym being a real threat and packing 5 mons instead of 4.
* Kanto has been segmented into three phases. You can pick the gyms of each phase in any order, Megaman 7 style. It goes Surge/Janine/Erika/Sabrina-> Brock/Misty/Blaine-> Blue. This offers a more cohesive and engaging postgame campaign because frankly vanilla Kanto is a mess.
1d Applying
To apply this patch, just get your CLEAN UNEDITED COPY OF Pokemon Heartgold, then pull out Delta Patcher and apply the patch. Do not attempt to apply the patch to an already patched ROM.
Hex edits and cheat codes may not be fully compatible with this patch. PkHex is fully compatible.


Delta Patcher can be found here https://www.romhacking.net/utilities/704/


To check if the patch was applied correctly, look in the Cherrygrove City PC. A Painter NPC will be present. Oak’s introduction text should also be changed.


Info on the specific dump:


File: Pokemon - HeartGold Version (USA).nds
CRC-32: c180a0e9
MD5: 258cea3a62ac0d6eb04b5a0fd764d788
SHA-1: 4fcded0e2713dc03929845de631d0932ea2b5a37
SHA-256: 65f02a56842b75aa92d775d56d657a56fe3fa993550b04dc20704ab82d760105
2X Pokemon Changes
There are no stat or typing changes. No moves have been changed (ex Rock Climb is still Normal, Whirlpool is still 35 BP/70% acc)
These are small-scale, primarily serving to make a 493 possible and make movepools more streamlined within the bounds of HG-legal moves.
2a Evolution Changes
Haunter and Graveler evolve upon learning a key move for their skillsets. Politoed is heavily associated with Drizzle, so Poliwhirl evolves into it by learning Rain Dance.


Evolutions not mentioned here have not been edited. All preexisting methods still work.


Move Evolutions
Haunter - Evolves when leveling up while knowing Shadow Ball (Level 36)
Graveler - Evolves when leveling up while knowing Earthquake (Level 36)
Poliwhirl - Evolves into Politoed when leveling up while learning Rain Dance (Level 36)


Level Evolutions
Kadabra - Evolves at level 38
Machoke - Evolves at level 38


Held Item Evolutions
Slowpoke - Evolves into Slowking by leveling up while holding King’s Rock
Magneton - Evolves into Magnezone by leveling up while holding Dubious Disc
Eevee - Evolves into Glaceon by leveling up while holding Blue Shard at Night
Eevee - Evolves into Leafeon by leveling up while holding Green Shard in the Day
Magmar - Evolves into Magmortar by leveling up while holding Magmarizer
Electabuzz - Evolves into Electivire by leveling up while holding Electrizer
Rhydon - Evolves into Rhyperior by leveling up while holding Protector
Scyther - Evolves into Scizor by leveling up while holding Metal Coat
Onix - Evolves into Steelix by leveling up while holding Metal Coat
Seadra - Evolves into Kingdra by leveling up while holding Dragon Scale
Porygon - Evolves into Porygon2 by leveling up while holding Up-Grade
Porygon2 - Evolves into Porygon Z by leveling up while holding Dubious Disc
Nosepass - Evolves into Probopass by leveling up while holding Yellow Shard
Feebas - Evolves into Milotic by leveling up while holding Pamtre Berry
Dusclops - Evolves into Dusknoir by leveling up while holding Reaper Cloth
Clamperl - Evolves into Huntail by leveling up while holding Deep Sea Tooth
Clamperl - Evolves into Gorebyss by leveling up while holding Deep Sea Scale


Stone Evolutions
Slowpoke - Evolves into Slowking by using a Water Stone (REMOVED as of v3.0.6)


2bX Movepool Changes
**PLEASE SEE ACCOMPANYING DOCUMENT FOR DETAILS**
Modest changes. These should have a moderate impact on your playthrough, instead just letting you fine tune some builds without having to get a new Pokemon. All of these are moves the Pokemon can legally know in this generation (as of HGSS), only changed to make it less problematic to get them. Includes things like fixing pre-evolution only moves, updating a few learnset levels to B2W2 tier so you don't wait until level 60 before getting a good STAB, and giving the Dratini line Extremespeed to match the HGSS event. There's also a fair few Move Tutor moves from HGSS thrown in.


It isn't the most dramatic changelog, but Pokemon like Wooper and Natu should be much easier to use this way.


2b1 Legendary Movepool Changes


Legendary level up moves have been changed significantly to make them into worthwhile fights at the levels they are fought. They still can't hold a candle to even basic trainer AI, but hopefully it's more exciting.
Some of these are approximations, and moot points if you're not importing low-level legends. All of their normal level up moves are still there, these are just shoved into the right place to give them those movepools in their fights.


All movesets are still legal in Gen 4. Yes, this means no Sacred Fire Entei, I'm sorry.
Events are not included as legal move options with the exception of Arceus's Spacial Rend.


Roamers - same level
Ho-Oh - 55
Post Dex - level 60, 70 for Suicune Lugia
Post Blue - level 70, 80 for Regigigas
Post Red - level 80 for Groudon/Kyogre, level 85 for the rest
Arceus is level 95
Roamers have not been edited.


Articuno - Ice Beam, Aerial Ace, Ancient Power, Signal Beam at level 70
Zapdos - Discharge, Drill Peck, Mud-Slap, Heat Wave at level 70
Moltres - Heat Wave, Air Slash, Ominous Wind, Solarbeam at level 70
Mewtwo - Aura Sphere, Psychic, Shadow Ball, Recover at level 75
Mew - Hidden Power, Superpower, Ancient Power, Earth Power at level 85


Entei (Roamer) - Flamethrower, Stomp, Fire Spin, Roar at level 40
Raikou (Roamer) - Reflect, Spark, Quick Attack, Roar at level 40


Raikou (Rematch, TBA) - Signal Beam, Discharge, Calm Mind, Thunder at level 60
Entei (Rematch, TBA) - Shadow Ball, Lava Plume, Calm Mind, Eruption at level 60
Suicune - Extrasensory, Surf, Calm Mind, Blizzard at level 70
Lugia - Aeroblast, Roost, Psychic, Calm Mind at level 70
Ho-oh - Sacred Fire, Steel Wing, Aerial Ace, Punishment at level 55
Celebi - Charge Beam, Leaf Storm, Psychic, Giga Drain at level 60


Regirock - Mud-Slap, Rock Slide, Earthquake, Stealth Rock at level 60
Regice - Charge Beam, Ice Beam, Signal Beam, Hyper Beam at level 60
Registeel - Curse, Iron Head, Amnesia, Superpower at level 60
Latias - Attract, Surf, Dragon Pulse, Mist Ball at level 65
Latias - Healing Wish is at 75
Latios - Mud-Slap, Thunderbolt, Dragon Pulse, Luster Purge at level 65
Latios - Memento is at 75
Kyogre - Calm Mind, Thunder, Ice Beam, Water Spout at level 80
Groudon - Swords Dance, Thunder Punch, Earthquake, Superpower at level 80
Rayquaza - Dragon Dance, Extremespeed, Outrage, Rest at level 85
Jirachi - Cosmic Power, Drain Punch, Iron Head, Psychic at level 70
Deoxys - Cosmic Power, Psycho Boost, Energy Ball, Charge Beam at level 70


Uxie - Calm Mind, Extrasensory, Yawn, Signal Beam at level 60
Mesprit - Reflect, Light Screen, Psychic, Energy Ball at level 60
Azelf - Zen Headbutt, Ice Punch, Fire Punch, Facade at level 60
Dialga - Dragon Claw, Iron Tail, Thunder Wave, Bulk Up at level 85
Palkia - Spacial Rend, Surf, Earth Power, Mud-Slap at level 85
Giratina - Calm Mind, Shadow Ball, Draco Meteor, Will-O-Wisp at level 85
Regigigas - Zen Headbutt, Fire Punch, Thunder Wave, Crush Grip at level 80
Heatran - Lava Plume, Metal Sound, Flash Cannon, Magma Storm at level 70
Cresselia - Psychic, Protect, Light Screen, Confusion at level 70
Manaphy - Tail Glow, Energy Ball, Surf, Psychic at level 60
Darkrai - Dark Void, Dark Pulse, Psychic, Nasty Plot at level 70
Shaymin - Seed Flare, Air Slash, Mud-Slap, Leech Seed at level 60


Arceus - Spacial Rend, Recover, Flamethrower, Judgement at level 95


3X Wild Encounters
To save space, these are sorted by method, route and then by time. Various values may be omitted because they were unimportant, the Pokemon is found everywhere, or I neglected to mention them.


Like in Refined Platinum, functionally all non-Johto Dex Pokemon are strictly found via post-E4 means. There's also a very diverse selection now in Post-E4 areas (read: Kanto), with a huge amount of Pokemon from other regions dwelling in it. Johto should be a revamped vanilla with extra seasoning, while Kanto is a whole new ballgame.


Individual level changes are not mentioned. Evolved mons are not always mentioned.
If no time is specified, it takes effect all day.
All Pokemon unique to a given area are still there, though Pokemon like Graveler and Golbat may not appear at all in certain areas to make space for new Pokemon.


Sinnoh Radio and Hoenn Radio are always 20% chances, and replace the 10% slots. Since it's easy to change the date and put the radio on, I'm using it for a lot of exotic and Safari Pokemon.
If only one Radio Pokemon is mentioned, it is a 40% chance there.


Various Radio Pokemon in Kanto have been upgraded to their evolved forms - be prepared to see Luxrays and Bronzongs, Hariyamas and Camerupts. These are not listed.


3aX Johto-Dex Accessibility
These are Pokemon that are normally Kanto (or Safari-only) exclusive but have been added to Johto areas. Their evolutions may not be accessible before beating the Elite Four.
3a1 Formerly Kanto-only
Electabuzz
Omanyte
Kabuto
Aerodactyl
Sneasel
Houndour
Slugma
3a2 Formerly Kanto or Safari-only
Jigglypuff
Grimer
Murkrow
Larvitar
3bX Wild Encounters - Radio
3b1 Hoenn Radio
Cliff Cave - Trapinch, Cacnea
Diglett's Cave - Trapinch, Cacturne
Ice Path (1F) - Castform, Spheal
Ice Path (B1F-B3F) - Castform, Sealeo
Mt. Moon (All) - Sableye, Mawile
Mt. Mortar (B1F) - Meditite, Makuhita
National Park - Volbeat, Illumise
Ruins of Alph - Baltoy, Vigoroth
Seafoam Islands (1F-B3F) - Sealeo, Castform
Seafoam Islands (B4F) - Walrein, Castform


Route 4 - Sableye, Mawile
Route 8 - Dusclops, Banette
Route 10 - Exploud, Manectric
Route 11 - Exploud, Manectric
Route 13 - Kecleon, Tropius
Route 14 - Kecleon, Tropius
Route 15 - Kecleon, Tropius
Route 16 - Swalot, Weezing
Route 17 - Swalot, Weezing
Route 18 - Swalot, Weezing
Route 29 - Poochyena, Gulpin
Route 33 - Shroomish, Seedot
Route 36 - Baltoy, Vigoroth
Route 37 - Baltoy, Vigoroth
Route 42 - Seviper, Zangoose
Route 43 - Seviper, Zangoose
Route 44 - Metang, Shelgon
Route 45 - Mightyena, Swalot
Route 46 - Poochyena, Gulpin


Route 1 - Sceptile
Route 3 - Blaziken
Route 24 - Swampert


3b2 Sinnoh Radio
Cliff Cave - Hippopotas, Nosepass
Dark Cave (Route 31 Side) - Cranidos, Shieldon
Dark Cave (Route 45 Side) - Cranidos, Shieldon
Dark Cave (Route 45 Side; Post-Ice Path) - Rampardos, Bastiodon
Diglett's Cave - Hippowdon, Nosepass
Ice Path (All) - Snorunt, Snover
Mt. Moon (All) - Lunatone, Solrock
Mt. Mortar (B1F) - Gabite, Riolu
Mt. Silver (Snowy) - Froslass, Bronzong
National Park - Beautifly, Dustox
Ruins of Alph - Riolu, Burmy
Seafoam Islands (All) - Glalie, Abomasnow


Route 4 - Lunatone, Solrock
Route 7 - Luxray, Manectric
Route 8 - Spiritomb, Misdreavus
Route 10 - Luxray, Bibarel
Route 11 - Luxray, Bibarel
Route 13 - Cherrim, Lopunny
Route 14 - Cherrim, Lopunny
Route 15 - Cherrim, Lopunny
Route 16 - Skorupi, Toxicroak
Route 17 - Drapion, Toxicroak
Route 18 - Drapion, Toxicroak
Route 29 - Swablu, Ralts
Route 33 - Croagunk, Skorupi
Route 36 - Riolu, Burmy
Route 37 - Riolu, Burmy
Route 42 - Munchlax, Tyrogue
Route 43 - Munchlax, Tyrogue
Route 44 - Gabite, Drifblim
Route 45 - Altaria, Kirlia
Route 46 - Swablu, Ralts


Route 1 - Torterra
Route 3 - Infernape
Route 24 - Empoleon


3b3 Unedited Radio Encounters
Just in case anyone needs them. Pokemon may be evolved relative to vanilla.
Hoenn Radio
Bell Tower - Linoone, Spinda
Burned Tower - Linoone, Spinda
Dark Cave - Absol, Makuhita
Ilex Forest - Spoink, Numel
Mt. Mortar 1F, Back, Waterfall - Absol, Makuhita
Rock Tunnel - Absol, Hariyama
Slowpoke Well - Absol, Makuhita
Sprout Tower - Zigzagoon, Spinda
Tohjo Falls - Absol, Hariyama
Union Cave - Absol, Makuhita
Victory Road - Absol, Hariyama
Viridian Forest - Grumpig, Camerupt


Route 2 - Plusle, Minun
Route 5 - Plusle, Minun
Route 6 - Exploud, Linoone
Route 7 - Plusle, Minun
Route 25 - Exploud, Linoone
Route 26 - Exploud, Linoone
Route 27 - Exploud, Linoone
Route 28 - Exploud, Linoone
Route 30 - Whismur, Zigzagoon
Route 31 - Whismur, Zigzagoon
Route 34 - Whismur, Zigzagoon
Route 35 - Whismur, Zigzagoon
Route 38 - Plusle, Minun
Route 39 - Plusle, Minun
Route 47 - Exploud, Linoone
Route 48 - Plusle, Minun


Sinnoh Radio
Bell Tower - Chatot, Medicham
Burned Tower - Chatot, Meditite
Ilex Forest - Budew, Carnivine
Mt. Mortar 1F, Back, Waterfall - Bronzor, Chingling
Rock Tunnel - Bronzong, Chimecho
Slowpoke Well - Bronzor, Chingling
Sprout Tower - Chatot, Meditite
Tohjo Falls - Bronzong, Chimecho
Union Cave - Bronzor, Chingling
Victory Road - Bronzong, Chimecho
Viridian Forest - Roselia, Carnivine


Route 2 - Luxray, Luxray
Route 5 - Luxray, Luxray
Route 6 - Floatzel, Bibarel
Route 25 - Floatzel, Bibarel
Route 26 - Floatzel, Bibarel
Route 27 - Floatzel, Bibarel
Route 28 - Floatzel, Bibarel
Route 30 - Buizel, Bidoof
Route 31 - Buizel, Bidoof
Route 34 - Buizel, Bidoof
Route 35 - Buizel, Bidoof
Route 38 - Luxio, Luxio
Route 39 - Luxio, Luxio
Route 47 - Floatzel, Bibarel
Route 48 - Luxio, Luxio
3cX Wild Encounters - Walking
3c1 Johto


Johto Dungeons
Bell Tower 2F - Ariados 20%, Weepinbell 10%, Murkrow 4%
Bell Tower 2F (Morning, Day) - Noctowl 30%, Raticate 30%, Haunter 4%, Rattata 1%
Bell Tower 2F (Night) - Noctowl 40%, Haunter 14%, Raticate 10%, Gastly 1%
Bell Tower 3F-9F Noctowl 30%, Murkrow 10%, Weepinbell 5%
Bell Tower 3F-9F (Morning, Day) Raticate 30%, Ariados 15%, Haunter 10%
Bell Tower 3F-9F (Night) Ariados 20%, Haunter 15%, Raticate 10%, Gengar 5%
Burned Tower 1F - Rattata 20%, Koffing 34%
Burned Tower 1F (Morning) - Raticate 19%, Grimer 15%, Zubat 10%, Magmar 2%
Burned Tower 1F (Day) - Raticate 22%, Grimer 10%, Zubat 10%, Magmar 4%
Burned Tower 1F (Night) - Raticate 19%, Grimer 15%, Zubat 15%, Magmar 2%
Burned Tower B1F - Koffing 50%, Raticate 20%
Burned Tower B1F (Morning) - Grimer 10%, Magmar 5%, Rattata 10%, Zubat 5%
Burned Tower B1F (Day) - Grimer 5%, Magmar 10%, Rattata 10%, Zubat 5%
Burned Tower B1F (Night) - Grimer 10%, Magmar 5%, Zubat 15%
Cliff Cave - Golbat 20%, Graveler 20%, Krabby 10%, Kingler 10%, Machop 10%, Onix 10%, Machoke 5%, Quagsire 8%, Steelix 2%
Cliff Cave (Morning, Day) - Misdreavus 5%
Cliff Cave (Night) - Misdreavus 10%
Dark Cave R31 Side - Geodude 45%, Zubat 34%, Phanpy 10%
Dark Cave R31 Side (Morning, Day) - Poliwag 7%, Dunsparce 4%
Dark Cave R31 Side (Night) - Dunsparce 6%, Poliwag 5%
Dark Cave R45 Side; Pre-Archer - Graveler 25%, Zubat 20%, Wobbuffet 15%, Golbat 11%, Geodude 10%, Dunsparce 4%
Dark Cave R45 Side; Pre-Archer (Morning, Day) - Phanpy 10%, Teddiursa 5%
Dark Cave R45 Side; Pre-Archer (Night) - Teddiursa 10%, Phanpy 5%
Ilex Forest - Butterfree 4%, Beedrill 4%
Ilex Forest (Morning) - Caterpie 20%, Weedle 20%, Paras 15%, Metapod 10%, Kakuna 10%, Hoothoot 10%, Pineco 10%, Venonat 5%, Oddish 2%
Ilex Forest (Day) - Caterpie 20%, Weedle 20%, Metapod 10%, Kakuna 10%, Hoothoot 10%, Pineco 10%, Paras 5%, Venonat 5%, Oddish 2%
Ilex Forest (Night) - Oddish 52%, Hoothoot 20%, Venonat 15%, Paras 5%
Ice Path 1F - Golbat 30%, Piloswine 20%, Swinub 10%, Teddiursa 10%, Zubat 10%
Ice Path 1F (Morning) - Sneasel 10%, Delibird 5%
Ice Path 1F (Day) - Sneasel 5%, Delibird 5%
Ice Path 1F (Night) - Delibird 10%, Sneasel 5%
Ice Path B1F-3F - Golbat 40%, Piloswine 20%, Swinub 10%
Ice Path B1F-3F (Morning) - Delibird 15%, Sneasel 10%
Ice Path B1F-3F (Day) - Delibird 15%, Sneasel 5%
Ice Path B1F-3F (Night) - Delibird 20%, Sneasel 5%
Mt. Mortar Entrance - Zubat 40%, Machop 20%, Golbat 10%, Raticate 10%, Rattata 5%, Slugma 5%
Mt. Mortar Entrance (Morning, Day) - Marill 6%, Geodude 4%
Mt. Mortar Entrance (Night) - Marill 8%, Geodude 2%
Mt. Mortar Back - Machop 36%, Rattata 10%, Raticate 5%, Zubat 5%, Marill 4%
Mt. Mortar Back (Morning, Day) - Gedoude 30%, Slugma 10%
Mt. Mortar Back (Night) - Geodude 20%, Slugma 20%
Mt. Mortar Waterfall Cave - Golem 20%, Machamp 20%, Graveler 10%, Machoke 10%, Golbat 10%, Azumarill 4%
Mt. Mortar Waterfall Cave (Morning, Day) - Raticate 15%, Tyrogue 6%, Magcargo 5%
Mt. Mortar Waterfall Cave (Night) - Raticate 10%, Magcargo 10%, Tyrogue 5%, Hitmontop 1%
Mt. Mortar Karate King - Zubat 40%, Raticate 20%, Machop 10%, Machoke 10%
Mt. Mortar Karate King (Morning, Day) - Marill 6%, Geodude 5%, Slugma 5% Tyrogue 4%
Mt. Mortar Karate King (Night) - Slugma 10%, Marill 8%, Tyrogue 2%
National Park - Butterfree 20%, Beedrill 20%, Yanma 1%
National Park (Morning) - Pidgey 25%, Psyduck 10%, Venonat 10%, Sunkern 6%, Scyther 4%, Pinsir 4%
National Park (Day) - Sunkern 25%, Psyduck 20%, Scyther 6%, Pinsir 4%, Pidgey 4%
National Park (Night) - Hoothoot 24%, Venonat 15%, Psyduck 10%, Pinsir 6%, Scyther 4%
Ruins of Alph Exterior - Natu 70%, Smeargle 30%
Ruins of Alph Interior - Unown 100%
Slowpoke Well B1F - Zubat 70%, Slowpoke 20%, Psyduck 10%
Slowpoke Well B2F - Golbat 35%, Zubat 30%, Slowpoke 21%, Psyduck 10%, Slowbro 4%
Sprout Tower - Hoothoot 20%, Bellsprout 5%
Sprout Tower (Morning, Day) - Rattata 65%, Sentret 10%
Sprout Tower (Night) - Gastly 60%, Rattata 10%, Sentret 5%
Union Cave 1F -  Geodude 30%, Sandshrew 30%, Zubat 25%, Rattata 10%, Onix 5%
Union Cave B2F - Raticate 30%, Zubat 20%, Golbat 20%, Geodude 15%, Onix 5%
Union Cave B2F (Morning) - Sandshrew 6%, Sandslash 4%
Union Cave B2F (Day, Night) - Sandshrew 8%, Sandslash 2%
Whirl Islands 1F, B1F; Base - Kingler 20%, Krabby 20%, Zubat 20%, Seel 15%, Poliwhirl 10%, Golbat 10%, Corsola 5%
Whirl Islands B2F; Base - Kingler 20%, Golbat 20%, Seel 20%, Krabby 10%, Poliwhirl 10%, Zubat 10%, Dewgong 5%, Corsola 5%
Victory Road 1F - Golbat 30%, Graveler 20%, Ursaring 15%, Donphan 15%, Rhyhorn 10%, Larvitar 4%, Onix 4%, Rhydon 2%
Victory Road 2F, 3F - Graveler 20%, Golbat 20%, Ursaring 10%, Donphan 10%, Rhyhorn 10%, Golem 5%, Steelix 5%, Larvitar 4%, Rhydon 2%
Victory Road 2F, 3F (Morning, Day) - Sandslash 10%, Arbok 4%
Victory Road 2F, 3F (Night) - Arbok 10%, Sandslash 4%


Johto Routes
Route 26 - Sandslash 30%, Arbok 10%, Ponyta 10%, Rapidash 10%, Jumpluff 5%
Route 26 (Morning, Day) - Doduo 20%, Dodrio 10%, Raticate 5%
Route 26 (Night) -  Raticate 20%, Quagsire 10%, Dodrio 5%
Route 27 - Jumpluff 20%, Arbok 15%, Raticate 10%, Sandslash 5%, Ponyta 5%
Route 27 (Morning, Day) - Doduo 25%, Dodrio 10%
Route 27 (Night) - Quagsire 40%, Doduo 5%
Route 29 (Morning, Day) - Pidgey 50%, Sentret 40%, Hoppip 5%, Rattata 5%
Route 29 (Night) - Hoothoot 60%, Rattata 35%, Sentret 5%
Route 30 (Morning, Day) - Caterpie 20%, Weedle 20%, Hoppip 10%
Route 30 (Morning) - Ledyba 30%, Pidgey 10%, Poliwag 5%, Spinarak 5%
Route 30 (Day) - Pidgey 30%, Ledyba 10%, Spinarak 10%
Route 30 (Night) - Spinarak 30%, Hoothoot 30%, Rattata 20%, Poliwag 5%, Caterpie 5%, Weedle 5%, Ledyba 5%
Route 31 - Bellsprout 20%
Route 31 (Morning, Day) - Caterpie 20%, Weedle 20%, Hoppip 6%, Poliwag 5%
Route 31 (Morning) - Pidgey 10%, Ledyba 15%, Spinarak 4%
Route 31 (Day) - Pidgey 21%, Ledyba 4%, Spinarak 4%
Route 31 (Night) - Rattata 20%, Spinarak 15%, Poliwag 11%, Caterpie 10%, Weedle 10%, Hoothoot 10%, Ledyba 4%
Route 32 - Bellsprout 20%, Ekans 20%
Route 32 (Morning) - Mareep 20%, Hoppip 20%, Rattata 15%, Zubat 5%
Route 32 (Day) - Mareep 20%, Hoppip 20%, Rattata 20%
Route 32 (Night) - Wooper 30%, Rattata 10%, Mareep 10%, Zubat 5%, Hoppip 5%
Route 33 - Ekans 20%
Route 33 (Morning, Day) - Wooper 20%, Spearow 20%, Psyduck 10%, Hoppip 5%
Route 33 (Morning) - Rattata 20%, Zubat 5%
Route 33 (Day) - Rattata 25%
Route 33 (Night) - Wooper 30%, Zubat 25%, Rattata 20%, Psyduck 5%
Route 34 - Drowzee 40%, Rattata 20%, Abra 15%, Ditto 6%, Eevee 4%
Route 34 (Morning, Day) - Jigglypuff 10%, Grimer 5%
Route 34 (Night) - Grimer 10%, Jigglypuff 5%
Route 35 - Drowzee 25%, NidoranM 20%, NidoranF 20%
Route 35 (Morning) - Pidgey 10%, Abra 15%, Ditto 6%, Yanma 4%
Route 35 (Day) - Pidgey 10%, Abra 10%, Yanma 11%, Ditto 4%
Route 35 (Night) - Hoothoot 10%, Abra 15%, Ditto 6%, Yanma 4%
Route 36 - NidoranM 30%, NidoranF 28%, Stantler 5%, Yanma 2%
Route 36 (Morning, Day) - Growlithe 15%, Vulpix 10%, Pidgeotto 10%
Route 36 (Night) - Vulpix 15%, Growlithe 10%, Hoothoot 10%
Route 37 - Stantler 30%
Route 37 (Morning) - Ledyba 30%, Ledian 10%, Growlithe 10%, Pidgeotto 10%, Pidgey 5%, Vulpix 5%
Route 37 (Day) - Pidgey 30%, Pidgeotto 25%, Growlithe 10%, Vulpix 5%
Route 37 (Night) - Spinarak 30%, Noctowl 15%, Hoothoot 10%, Ariados 10%, Vulpix 10%, Growlithe 5%
Route 38 - Furret 20%, Magnemite 24%, Miltank 6%, Tauros 5%, Snubbull 5%
Route 38 (Morning, Day) - Meowth 30%, Farfetch'd 10%
Route 38 (Night) - Meowth 40%
Route 39 - Furret 20%, Magnemite 20%, Tauros 14%, Miltank 14%, Snubbull 2%
Route 39 (Morning, Day) - Meowth 20%, Farfetch'd 10%
Route 39 (Night) - Meowth 30%
Route 42 - Mankey 30%, Mareep 30%, Flaaffy 10%, Scyther 4%, Marill 2%
Route 42 (Morning) - Spearow 25%, Murkrow 5%, Fearow 4%
Route 42 (Day) - Spearow 30%, Fearow 4%
Route 42 (Night) - Zubat 20%, Murkrow 10%, Golbat 5%
Route 43 - Girafarig 30%, Swinub 10%, Pinsir 4%
Route 43 (Morning) - Fearow 20%, Venonat 6%, Mareep 5%, Murkrow 5%
Route 43 (Day) - Fearow 20%, Mareep 10%, Flaaffy 6%
Route 43 (Night) - Venonant 16%, Noctowl 10%, Murkrow 10%
Route 44 - Weepinbell 34%, Tangela 30%, Lickitung 20%, Swinub 10%, Bellsprout 5%, Octillery 1%
Route 45 - Graveler 20%, Gligar 20%, Golem 10%, Fearow 15%
Route 45 (Morning) - Donphan 24%, Skarmory 6%, Teddiursa 5%
Route 45 (Day) - Donphan 10%, Skarmory 10%, Teddiursa 5%, Phanpy 5%
Route 45 (Night) - Ursaring 14%, Donphan 10%, Skarmory 6%, Phanpy 5%
Route 46 Pre-Archer - Geodude 35%
Route 46 Pre-Archer; (Morning) - Spearow 35%, Rattata 20%, Phanpy 10%
Route 46 Pre-Archer; (Day) - Spearow 35%, Rattata 20%, Phanpy 5%, Jigglypuff 5%
Route 46 Pre-Archer; (Night) - Rattata 50%, Phanpy 5%, Teddiursa 5%
Route 47 - Ditto 41%, Miltank 20%, Fearow 10%, Houndoom 5%, Gloom 5%, Dugtrio 4%
Route 47 (Morning, Day) - Farfetch'd 15%
Route 47 (Night) - Noctowl 10%, Misdreavus 5%
Route 48 - Tauros 20%, Gloom 20%, Skiploom 10%, Fearow 10%, Electabuzz 5%, Girafarig 5%, Diglett 4%
Route 48 (Morning, Day) - Farfetch'd 21%, Houndour 5%
Route 48 (Night) - Noctowl 10%, Houndour 10%, Misdreavus 4%, Houndoom 2%


3c2 Kanto
Kanto Dungeons
Cerulean Cave 1F - Parasect 20%, Magneton 10%, Ditto 10%, Electrode 5%, Wobbuffet 5%, Cradily 5%, Armaldo 5%
Cerulean Cave 1F (Morning, Day) - Machamp 20%, Golbat 10%, Primeape 10%
Cerulean Cave 1F (Night) - Golbat 30%, Machamp 10%
Cerulean Cave B1F  - Alakazam 20%, Parasect 20%, Golbat 10%, Machamp 10%, Magneton 10%, Ditto 10%, Electrode 5%, Wobbuffet 5%, Rampardos 5%, Bastiodon 5%
Cerulean Cave B2F - Alakazam 20%, Parasect 20%, Crobat 10%, Machamp 10%, Magnezone 10%, Ditto 10%, Electrode 5%, Wobbuffet 5%, Omastar 5%, Kabutops 5%
Diglett's Cave - Diglett 30%, Nosepass 5%, Trapinch 5%, Lairon 4%
Diglett's Cave (Morning, Day) - Dugtrio 56%
Diglett's Cave (Night) - Dugtrio 54%, Vibrava 2%
Mt. Moon All - Golbat 30%, Sandslash 20%, Lairon 10%, Graveler 10%, Golem 10%, Parasect 10%, Clefairy 5%
Mt. Moon All (Morning, Night) - Clefable 5%
Mt. Moon All (Day) - Aggron 5%
Rock Tunnel 1F - Marowak 30%, Graveler 20%, Machoke 15%, Golbat 10%, Golem 10%, Medicham 8%, Machamp 5%, Kangaskhan 2%
Rock Tunnel B1F - Marowak 35%, Graveler 20%, Golem 10%, Onix 10%, Golbat 10%, Medicham 10%, Kangaskhan 5%
Seafoam Island B2F - Golbat 35%, Seel 20%, Golduck 20%, Dewgong 15%, Psyduck 5%, Sealeo 5%
Seafoam Island B3F - Golbat 35%, Dewgong 20%, Golduck 20%, Seel 10%, Psyduck 5%, Sealeo 5%, Glalie 5%
Seafoam Island B4F - Golbat 30%, Dewgong 24%, Golduck 21%, Seel 10%, Jynx 5%, Sealeo 5%, Glalie 5%
Seafoam Island B5F - Dewgong 30%, Golbat 20%, Golduck 20%, Jynx 15%, Walrein 9%, Glalie 4%, Froslass 2%
Viridian Forest - Butterfree 20%, Beedrill 20%
Viridian Forest (Morning) - Pidgeot 26%, Breloom 15%, Nuzleaf 10%, Pikachu 5%, Nincada 4%
Viridian Forest (Day) - Pidgeot 26%, Ninjask 20%, Breloom 5%, Nuzleaf 5%, Pikachu 9%
Viridian Forest (Night) - Noctowl 26%, Nuzleaf 15%, Breloom 10%, Pikachu 5%, Nincada 4%


Kanto Routes
Route 1 (Morning) - Furret 40%, Pidgeot 30%, Swellow 14%, Venusaur 12%, Purugly 4%
Route 1 (Day) - Furret 40%, Pidgeot 40%, Swellow 9%, Venusaur 7%, Purugly 4%
Route 1 (Night) - Raticate 40%, Noctowl 30%, Purugly 14%, Venusaur 7%, Swellow 4%
Route 2 South - Butterfree 10%, Beedrill 10%
Route 2 South (Morning) - Pidgeot 20%, Beautifly 20%, Swellow 20%, Purugly 7%, Dustox 5%, Roselia 4%, Nincada 4%
Route 2 South (Day) - Pidgeot 40%, Swellow 10%, Purugly 10%, Roselia 8%, Beautifly 5%, Dustox 5%, Pikachu 2%
Route 2 South (Night) - Noctowl 20%, Dustox 20%, Purugly 20%, Swellow 7%, Beautifly 5%, Roselia 4%, Nincada 4%
Route 2 North - Nidorina 20%, Nidorino 20%, Raticate 10%, Diglett 4%
Route 2 North (Morning) - Pidgeot 20%, Swellow 15%, Roselia 7%, Nincada 4%
Route 2 North (Day) - Pidgeot 20%, Roselia 14%, Swellow 6%, Purugly 6%
Route 2 North (Night) - Noctowl 20%, Purugly 15%, Roselia 5%, Nincada 4%, Trapinch 2%
Route 3 - Sandslash 14%, Arbok 10%, Jigglypuff 10%, Drifblim 4%
Route 3 (Morning, Day) - Raticate 30%, Fearow 25%, Charizard 7%
Route 3 (Night) - Golbat 30%, Raticate 20%, Charizard 12%
Route 4 - Fearow 30%, Jigglypuff 10%, Sableye 10%, Mawile 10%
Route 4 (Morning, Day) - Raticate 20%, Arbok 10%, Drifblim 10%
Route 4 (Night) - Golbat 30%, Drifblim 5%, Clefairy 5%
Route 5 - Jigglypuff 10%, Alakazam 5%
Route 5 (Morning) - Weepinbell 30%, Pidgeotto 20%, Pidgeot 20%, Skitty 10%, Staraptor 5%
Route 5 (Day) - Weepinbell 30%, Pidgeotto 20%, Pidgeot 20%, Staraptor 10%, Skitty 10%
Route 5 (Night) - Gloom 40%, Noctowl 20%, Weepinbell 10%, Staraptor 10%, Skitty 5%
Route 6 - Magneton 10%
Route 6 (Morning) - Weepinbell 30%, Skitty 30%, Persian 10%, Pidgeot 5%, Porygon 5%, Pelipper 5%, Pachirisu 5%
Route 6 (Day) - Weepinbell 30%, Persian 20%, Skitty 10%, Staravia 10%, Pachirisu 10%, Pidgeot 5%, Porygon 5%
Route 6 (Night) - Gloom 29%, Staravia 20%, Weepinbell 10%, Staraptor 10%, Persian 10%, Porygon 7%, Pelipper 5%
Route 7 - Persian 20%, Vulpix 20%
Route 7 (Morning) - Growlithe 20%, Raticate 20%, Fearow 10%, Murkrow 5%, Houndour 5%
Route 7 (Day) - Growlithe 25%, Raticate 20%, Fearow 10%, Houndour 5%
Route 7 (Night) - Murkrow 15%, Growlithe 10%, Houndour 10%, Houndoom 10%
Route 8 - Persian 20%, Shuppet 10%
Route 8 (Morning, Day) - Pidgeotto 20%, Kadabra 20%, Growlithe 15%, Pidgeot 5%
Route 8 (Morning) - Alakazam 5%
Route 8 (Day) - Banette 5%
Route 8 (Night) - Noctowl 20%, Gengar 10%, Kadabra 10%, Dusclops 10%, Misdreavus 10%, Murkrow 10%
*Route 8 is right next to Lavender Town. I filled it with ghosts. Not much else to say.
Route 9 - Primeape 20%, Raticate 20%, Fearow 20%, Zangoose 11%, Seviper 11%, Mankey 10%, Pachirisu 4%, Manectric 4%
Route 10 - Electrode 20%, Voltorb 10%
Route 10 (Morning) - Fearow 30%, Raticate 15%, Electrike 10%, Pachirisu 5%, Electabuzz 5%, Manectric 5%
Route 10 (Day) - Electrike 20%, Pachirisu 15%, Raticate 10%, Fearow 10%, Electabuzz 10%, Pikachu 5%
Route 10 (Night) - Quagsire 30%, Raticate 15%, Electrike 10%, Pachirisu 5%, Electabuzz 5%, Manectric 5%
Route 11 - Hypno 31%, Raticate 20%, Magneton 20%
Route 11 (Morning, Night) - Kirlia 10%, Pinsir 14%, Stantler 5%
Route 11 (Day) - Pinsir 10%, Kirlia 14%, Stantler 5%
Route 13 - Nidorina 20%, Nidorino 20%, Pelipper 10%, Chansey 11%,
Route 13 (Morning, Day) - Pidgeot 15%, Skiploom 15%, Gastrodon 5%, Jumpluff 4%
Route 13 (Night) - Noctowl 15%, Gastrodon 15%, Skiploom 5%, Quagsire 4%
Route 14 - Nidorina 20%, Nidorino 20%, Pelipper 5%, Chansey 4%
Route 14 (Morning, Day) - Pidgeot 20%, Skiploom 16%, Gastrodon 10%, Jumpluff 5%
Route 14 (Night) - Noctowl 20%, Gastrodon 15%, Quagsire 10%, Skiploom 6%
Route 15 - Nidorina 30%, Nidorino 30%, Chansey 2%
Route 15 (Morning, Day) - Skiploom 18%, Pidgeot 10%, Gastrodon 5%, Jumpluff 5%
Route 15 (Night) - Quagsire 18%, Noctowl 10%, Gastrodon 10%
Route 16 - Grimer 20%, Koffing 10%, Torkoal 10%, Slugma 5%, Houndour 5%
Route 16 (Morning, Day) - Fearow 30%, Weezing 5%, Murkrow 5%
Route 16 (Night) - Weezing 20%, Murkrow 10%, Magcargo 5%, Houndoom 5%
Route 17 - Grimer 20%, Koffing 10%, Muk 5%, Houndour 2%
Route 17 (Morning, Day) - Fearow 20%, Torkoal 19%, Slugma 10%, Stunky 10%, Weezing 4%
Route 17 (Night) - Weezing 20%, Slugma 15%, Skuntank 10%, Torkoal 10%, Magcargo 4%
Route 18 - Grimer 20%, Koffing 10%, Slugma 10%, Muk 5%, Torkoal 5%
Route 18 (Morning, Day) - Fearow 25%, Stunky 20%, Weezing 5%
Route 18 (Night) - Skuntank 20%, Weezing 20%, Stunky 5%, Magcargo 5%
Route 21 - Tangela 40%, Mr. Mime 25%, Tangrowth 10%
Route 21 (Morning, Day) - Sudowoodo 20%, Rotom 5%
Route 21 (Night) - Sudowoodo 15%, Rotom 10%
Route 22 - Arbok 10%, Primeape 10%, Rapidash 5%, Togetic 5%
Route 22 (Morning) - Fearow 30%, Raticate 20%, Dodrio 10%, Swellow 10%
Route 22 (Day) - Fearow 30%, Raticate 20%, Dodrio 20%
Route 22 (Night) - Raticate 40%, Politoed 10%, Purugly 10%
Route 24 - Alakazam 10%, Pelipper 4%
Route 24 (Morning) - Weepinbell 35%, Lombre 30%, Venomoth 14%, Blastoise 7%
Route 24 (Day) - Weepinbell 30%, Sunkern 30%, Lombre 10%, Blastoise 12%, Sunflora 4%
Route 24 (Night) - Venomoth 34%, Gloom 20%, Lombre 20%, Blastoise 7%, Weepinbell 5%
Route 25 - Alakazam 10%, Pelipper 5%, Eevee 5%
Route 25 (Morning) - Weepinbell 25%, Pidgeotto 20%, Lombre 20%, Pidgeot 10%, Venonat 5%
Route 25 (Day) - Weepinbell 25%, Pidgeotto 25%, Pidgeot 20%, Lombre 10%
Route 25 (Night) - Gloom 30%, Venomoth 20%, Lombre 15%, Venonat 10%, Weepinbell 5%


Route 28 - Donphan 20%, Tangela 20%, Ursaring 15%, Tangrowth 10%, Staraptor 5%
Route 28 (Morning, Day) - Rapidash 25%, Dodrio 5%
Route 28 (Night) - Rapidash 20%, Sneasel 10%
Mt. Silver Piedmont; 85 - Rapidash 30%, Tangrowth 25%, Donphan 15%, Tangela 10%, Ursaring 10%
Mt. Silver Piedmont (Morning, Day) - Dodrio 10% Tangrowth
Mt. Silver Piedmont (Night) - Sneasel 5%, Weavile 5%
Mt. Silver Reservoir; 86 - Steelix 20%, Probopass 10%, Ursaring 10%, Donphan 10%, Golbat 5%, Rhyperior 5%, Pupitar 5%
Mt. Silver Reservoir (Morning, Day) - Quagsire 30%, Golduck 5%
Mt. Silver Reservoir (Night) - Mismagius 25%, Quagsire 10%
Mt. Silver Escarpment; 87 - Golbat 20%, Steelix 30%, Ursaring 10%, Donphan 10%, Heracross 5%, Pupitar 5%
Mt. Silver Escarpment (Morning, Day) - Golem 15%, Gliscor 5%
Mt. Silver Escarpment (Night) - Golem 10%, Gliscor 10%
Mt. Silver Hoarfrost; 89 - Sneasel 20%, Abomasnow 20%, Quagsire 10%, Donphan 10%, Ursaring 10%, Golduck 5%, Mamoswine 5%, Pupitar 4%, Tyranitar 1%
Mt. Silver Hoarfrost (Morning, Day) - Weavile 10%, Golbat 5%
Mt. Silver Hoarfrost (Night) - Mismagius 15%
Mt. Silver Hollow; 88 - Golbat 20%, Steelix 20%, Exploud 5%, Pupitar 5%
Mt. Silver Hollow (Morning) - Aggron 20%, Bronzong 10%, Glalie 10%, Quagsire 10%
Mt. Silver Hollow (Day) - Bronzong 20%, Aggron 10%, Glalie 10%, Quagsire 10%
Mt. Silver Hollow (Night) - Froslass 20%, Aggron 10%, Bronzong 10%, Mismagius 10%
Mt. Silver Hearth; 79 - Steelix 20%, Golem 14%, Magmortar 11%, Weavile 10%, Tyranitar 10%, Magcargo 5%
Mt. Silver Hearth (Morning, Day) - Arcanine 20%, Golbat 10%
Mt. Silver Hearth (Night) - Ninetales 20%, Mismagius 10%
Mt. Silver Catacombs; 80 - Golem 20%, Weavile 20%, Ursaring 10%, Donphan 10%, Steelix 10%, Abomasnow 5%, Golbat 4%, Pupitar 4%, Crobat 1%, Tyranitar 1%
Mt. Silver Catacombs (Morning Day) - Probopass 10%, Dusknoir 5%
Mt. Silver Catacombs (Night) - Dusknoir 10%, Mismagius 5%
Mt. Silver Precipice; 81 - Weavile 20%, Absol 20%, Steelix 15%, Ursaring 10%, Donphan 10%, Crobat 5%, Tyranitar 5%
Mt. Silver Precipice (Morning, Day) - Probopass 15%
Mt. Silver Precipice (Night) - Mismagius 15%
3c3 Rock Smash Encounters
*Most of these are very negligible to begin with
Cliff Cave - Kingler 90%, Shuckle 10%
Victory Road - Golem 90%, Larvitar 10%
3c4 Dynamic Encounters
*These are changes that apply to the nonlinear section between Morty and Radio Tower, as well as encounters in Whirl Islands and Route 46.
*Changes are relative to the "base" set of changes for space purposes.


Route 38; Post-M - Granbull 1%
Route 38; Post-M (Night) - Persian 10%
Route 39; Post-M (Night) - Persian 10%
Route 42; Post-Morty - Flaaffy 20%
Route 42; Post-Morty (Morning, Day) - Fearow 14%
Route 42; Post-Morty (Night) - Golbat 14% 
Route 42; Post-O - Primeape 10%
Route 42; Post-O (Morning, Day) - Fearow 25%
Route 42; Post-O (Night) - Golbat 20% 
Route 43; Post-O (Morning, Night) - Venomoth 5%
Mt Mortar - various incoherent Graveler, Machoke, Raticate rates, as well as increased Tyrogue rates in the Karate King area after completing Olivine track.


Dark Cave R45; Post-Ice Path - Golbat 30%, Golem 20%, Wobbuffet 15%
Dark Cave R45; Post-Ice Path (Morning, Day) - Ursaring 15%, Graveler 10%, Donphan 6%, Dunsparce 4%
Dark Cave R45; Post-Ice Path (Night) - Donphan 15%, Dunsparce 10%, Ursaring 6%, Graveler 4%
Route 46; Post-Ice Path - Gligar 10%, Skarmory 5%
Route 46; Post-Ice Path (Morning) - Fearow 30%, Donphan 25%, Graveler 10%, Ursaring 10%, Jigglypuff 5%, Raticate 5%
Route 46; Post-Ice Path (Day) - Fearow 30%, Graveler 20%, Jigglypuff 10%, Ursaring 10%, Donphan 5%, Wigglytuff 5%, Raticate 5%
Route 46; Post-Ice Path (Night) - Ursaring 30%, Raticate 25%, Graveler 10%, Fearow 10%, Jigglypuff 5%, Donphan 5%


Whirl Islands 1F, B1F; Post-Silver Wing - Kingler 20%, Gastrodon 20%, Golbat 20%, Swalot 10%, Bronzong 10%, Dewgong 10%, Seel 5%, Corsola 5%
Whirl Islands B2F, B3F; Post-Silver Wing - Swalot 20%, Dewgong 20%, Gastrodon 20%, Kingler 15%, Bronzong 10%, Golbat 10%, Corsola 5%
3c5 Safari Zone
*All base grass and water encounters have gone from 15-17 to 25-27.
Default
Plains - Electabuzz 10% (replaces ID 3 - Rattata)
Savannah (Night) - Houndour 10% (replaces ID 9 - Golbat)
Marshland - Diglett 10% (replaces ID 1 - Koffing)


Object Related
*Postgame only
Meadow - Bayleef 10%; 5 Forest Objects (replaces ID 9 - Wooper)
Savannah - Quilava 10%; 5 Plains Objects (replaces ID 6 - Rhyhorn)
Swamp - Crocnaw 10%; 5 Waterside Objects (replaces ID 1 - Furret)
3dX Wild Encounters - Surfing
3d1 Johto
Cianwood City - Tentacool 90%, Horsea 9%, Mantine 1%
Cliff Edge Gate - Shellos 30%, Gastrodon 5%
Dragon's Den - Magikarp 60%, Gyarados 30%, Dratini 5%, Dragonair 5%
Mt. Mortar (1F) - Marill 4%
Mt. Mortar (3F, B1F) - Marill 6%
Slowpoke Well B1F - Slowbro 4%
Union Cave B1F - Lapras 4%
Union Cave B2F - Lapras 6%


Route 40 - Tentacool 65%, Tentacruel 30%, Mantine 5%
Route 26 - Tentacool 70%, Tentacruel 30%
Route 27 - Tentacool 70%, Tentacruel 30%


3d2 Kanto
Celadon City - Grimer 60%, Corphish 30%, Crawdaunt 5%, Muk 5%
*Celadon is unfishable and filled with Grimer, so I assume the waters are heavily polluted
Cerulean Cave 1F - Golduck 60%, Aerodactyl 40%
Cerulean Cave B1F - Golduck 60%, Aerodactyl 40%
Cerulean Cave B2F - Aerodactyl 61%, Golduck 39%
Cerulean City - Surksit 60%, Goldeen 30%, Masquerain 5%, Seaking 5%
Cinnabar Island - Tentacruel 60%, Wingull 30%, Anorith 5%, Lileep 5%
Fuchsia City - Tentacool 60%, Wingull 35%, Surskit 5%
Pallet Town - Tentacruel 65%, Tentacool 30%, Wailmer 5%
Seafoam Island Bottom - Seel 60%, Seadra 30%, Sealeo 10%
Vermillion City - Tentacool 60%, Wingull 30%, Tentacruel 5%, Pelipper 5%
Viridian City - Poliwag 60%, Surskit 30%, Poliwhirl 5%, Masquerain 5%


Route 6 - Psyduck 60%, Surskit 30%, Golduck 5%, Masquerain 5%
Route 10 - Seaking 65%, Surskit 30%, Masquerain 5%
Route 12 - Tentacruel 60%, Wailmer 30%, Pelipper 6%, Wailord 4%
Route 13 - Tentacruel 60%, Wailmer 30%, Pelipper 6%, Wailord 4%
Route 19 - Tentacruel 60%, Wingull 30%, Wailmer 10%
Route 20 - Tentacruel 60%, Wingull 30%, Wailmer 5%, Dewgong 5%
Route 21 - Tentacool 60%, Tentacruel 30%, Wailmer 5%, Pelipper 5%


Mt. Silver (Exterior) - Dragonair 90%, Lapras 10%


3eX Wild Encounters - Fishing
Given information is for Morning/Day. At night, a specific Pokemon will replace the 10% encounter slot in Good Rod fishing and the 30% encounter slot in Super Rod fishing. If no Night Fishing Pokemon is listed, the encounters are static through the whole day.
In other words:
Route ## (Night) - [Pokemon] means that Pokemon takes up the 10% of the Good Rod table and the 30% of the Super Rod table. In Olivine City, Staryu takes these slots, replacing the Corsola encounter entirely. This may affect one table but not the other; Vermillion City has Carvanha in the 10% slot and the Night slot, but not in the Super Rod 30% slot. Therefore Carvanha’s encounter rate is unchanged at night on the Good Rod table, but increases by 30% at night on the Super Rod table.
3e1 Johto
Blackthorn City - Good Rod; Poliwhirl 60%, Magikarp 40%
Blackthorn City - Super Rod; Feebas 80%, Dratini 20%
Blackthorn City (Night) - Super Rod; Poliwhirl 30%
Cherrygrove City - Old Rod; 70% Magikarp, 30% Krabby
Cherrygrove City - Good Rod; 45% Krabby, 40% Magikarp, Corsola 10%, Qwilfish 5%
Cherrygrove City - Super Rod; 50% Kingler, 30% Corsola, 15% Krabby, 5% Qwilfish
Cherrygrove City (Night) - Staryu
Olivine City - Old Rod; Magikarp 80%, Krabby 15%, Staryu 5%
Olivine City - Good Rod; 45% Krabby, 40% Magikarp, Corsola 10%, Horsea 5%
Olivine City - Super Rod; 50% Kingler, 30% Corsola, 15% Krabby, 5% Seadra
Olivine City (Night) - Staryu
Cliff Edge Gate - Good Rod; 40% Magikarp, 30% Barboach, 30% Poliwag
Cliff Edge Gate - Super Rod; 40% Whishcash, 30% Gyarados, 15% Barboach, 10% Poliwhirl, 5% Politoed
Cliff Edge Gate (Night) - Poliwhirl
Dark Cave (R31 Side) - Super Rod; 40% Goldeen, 30% Seaking, 15% Omanyte, 15% Kabuto
Dark Cave (R45 Side) - Super Rod; 40% Seaking, 30% Goldeen, 15% Omastar, 15% Kabutops
Dragon's Den - Super Rod; 40% Feebas, 30% Dratini, 15% Dragonair, 10% Gyarados, 5% Milotic
New Bark Town - Super Rod; Chinchou 40%, Shellder 30%, Tentacruel 15%, Lanturn 10%, Luvdisc 5%
Olivine City - Old Rod; Magikarp 80%, Krabby 15%, Staryu 5%
Olivine City - Good Rod; 45% Krabby, 40% Magikarp, Corsola 10%, Chinchou 5%
Olivine City - Super Rod; 50% Kingler, 30% Corsola, 15% Krabby, 5% Lanturn
Olivine City (Night) - Staryu
Slowpoke Well B1F - Super Rod; Seaking 55%, Goldeen 30%, Barboach 10%, Whiscash 5%
Slowpoke Well B2F - Super Rod; Seaking 40%, Goldeen 30%, Barboach 15%, Whiscash 10%, Slowking 5%
Tohjo Falls - Super Rod; Seaking 40%, Goldeen 40%, Barboach 15%, Luvdisc 5%
Violet City - Old Rod; 70% Magikarp, 30% Poliwag
Violet City - Super Rod; 40% Poliwhirl, 30% Poliwag, 15% Magikarp, Barboach 10%, 5% Politoed


Route 26 - Super Rod; Chinchou 40%, Shellder 30%, Tentacruel 15%, Lanturn 10%, Luvdisc 5%
Route 27 - Super Rod; Chinchou 40%, Shellder 30%, Tentacruel 15%, Lanturn 10%, Luvdisc 5%
Route 32 - Old Rod; Magikarp 70%, Tentacool 25%, Qwilfish 5%
Route 32 - Good Rod; Tentacool 45%, Magikarp 40%, Qwilfish 15%
Route 32 - Super Rod; Tentacruel 40%, Tentacool 30%, Magikarp 20%, Qwilfish 15%
Route 40 - Good Rod; Tentacool 40%, Chinchou 30%, Horsea 15%, Shellder 10%, Remoraid 5%
Route 40 - Super Rod; Chinchou 40%, Shellder 30%, Seadra 15%, Octillery 10%, Lanturn 5%
Route 41 - Good Rod; Tentacool 40%, Chinchou 30%, Horsea 15%, Shellder 10%, Remoraid 5%
Route 41 - Super Rod; Chinchou 40%, Shellder 30%, Seadra 15%, Octillery 10%, Lanturn 5%
Route 44 - Good Rod; Magikarp 40%, Poliwag 30%, Remoraid 20%, Poliwhirl 10%
Route 44 - Super Rod; Barboach 40%, Poliwhirl 30%, Octillery 20%, Politoed 10%


3e2 Kanto
Cerulean Cave 1F - Good Rod; 40% Poliwag, 30% Poliwhirl, 15% Omanyte, 15% Kabuto
Cerulean Cave 1F - Super Rod; 40% Poliwrath, 30% Politoed, 15% Kabutops, 15% Omastar
Cerulean Cave B1F - Good Rod; 40% Poliwag, 30% Poliwhirl, 15% Omanyte, 15% Kabuto
Cerulean Cave B1F - Super Rod; 40% Poliwrath, 30% Politoed, 15% Kabutops, 15% Omastar
Cerulean Cave B2F - Good Rod; 40% Kabuto, 35% Omanyte, 25% Poliwhirl
Cerulean Cave B2F - Super Rod; 40% Omastar, 30% Kabutops, 20% Politoed, 5% Poliwrath
Cerulean City - Old Rod; 100% Goldeen
Cerulean City - Good Rod; 40% Goldeen, 40% Corphish, 15% Staryu, 5% Finneon
Cerulean City - Super Rod; 40% Seaking, 30% Corphish, 15% Staryu, 10% Crawdaunt, 5% Lumineon
Cinnabar Island - Old Rod; Tentacool 85%, 10% Lileep, 5% Anorith
Cinnabar Island - Good Rod; 40% Anorith, 35% Lileep, 15% Chinchou, 5% Shellder
Cinnabar Island - Super Rod; 40% Lanturn, 30% Shellder, 15% Armaldo, 15% Cradily
Fuchsia City - Good Rod; 40% Corphish, 30% Barboach, 30% Magikarp
Fuchsia City - Super Rod; 40% Crawdaunt, 30% Gyarados, 15% Barboach, 15% Whiscash
Pallet Town - Good Rod; 40% Tentacool, 40% Shellder, 15% Chinchou, 5% Carvanha
Pallet Town - Super Rod; 40% Chinchou, 30% Shellder, 15% Tentacruel, 10% Lanturn, 5% Sharpedo
Vermillion City - Good Rod; Tentacool 40%, Chinchou 30%, Shellder 15%, Carvanha 10%, Magikarp 5%
Vermillion City - Super Rod; Chinchou 40%, Tentacruel 30%, Shellder 15%, Sharpedo 10%, Lanturn 5%
Vermillion City (Night) - Super Rod; 30% Carvanha
Viridian City - Good Rod; 80% Corphish, 20% Poliwag
Viridian City - Super Rod; 40% Crawdaunt, 30% Corphish, 25% Poliwhirl, 5% Gyarados


Route 4 - Old Rod; 100% Goldeen
Route 4 - Good Rod; 40% Goldeen, 40% Corphish, 15% Staryu, 5% Finneon
Route 4 - Super Rod; 40% Seaking, 30% Corphish, 15% Staryu, 10% Crawdaunt, 5% Lumineon
Route 9 - Good Rod; 40% Goldeen, 40% Corphish, 15% Chinchou, 5% Finneon
Route 9 - Super Rod; 40% Seaking, 30% Corphish, 15%, Lanturn, 10% Crawdaunt, 5% Lumineon
Route 10 - Good Rod; 40% Goldeen, 40% Chinchou, 15% Finneon, 5% Corphish
Route 10 - Super Rod; 40% Seaking, 30% Chinchou, 15% Crawdaunt, 10% Lumineon, 5% Lanturn
Route 12 - Good Rod; 55% Tentacool, 40% Magikarp, 5% Qwilfish
Route 12 - Super Rod; 55% Tentacruel, 30% Tentacool, 10% Relicanth, 5% Qwilfish
Route 13 - Good Rod; 55% Tentacool, 40% Magikarp, 5% Qwilfish
Route 13 - Super Rod; 55% Tentacruel, 30% Tentacool, 10% Qwilfish, 5% Relicanth
Route 19 - Good Rod; Krabby 45%, Magikarp 40%, Corsola 10%, Clamperl 5%
Route 19 - Super Rod; Kingler 40%, Corsola 30%, Krabby 15%, Clamperl 10%, Staryu 5%
Route 19 (Night) - Staryu
Route 20 - Good Rod; 40% Tentacool, 40% Shellder, 15% Chinchou, 5% Carvanha
Route 20 - Super Rod; 40% Chinchou, 30% Shellder, 15% Tentacruel, 10% Lanturn, 5% Sharpedo
Route 21 - Good Rod; 40% Tentacool, 40% Shellder, 15% Chinchou, 5% Carvanha
Route 21 - Super Rod; 40% Chinchou, 30% Shellder, Tentacruel 15%, 10% Sharpedo, 5% Lanturn
Route 24 - Old Rod; 100% Goldeen
Route 24 - Good Rod; 40% Goldeen, 40% Corphish, 15% Staryu, 5% Finneon
Route 24 - Super Rod; 40% Seaking, 30% Corphish, 15% Staryu, 10% Crawdaunt, 5% Lumineon
Route 25 - Old Rod; 100% Goldeen
Route 25 - Good Rod; 90% Goldeen, 10% Seaking $ Seaking
Route 25 - Super Rod; 100% Seaking


Mt. Silver (Exterior) - Good Rod; 70% Gyarados, 20% Dratini, 10% Dragonair $ Dragonair
Mt. Silver (Exterior) - Super Rod; 95% Gyarados, 5% Dragonite
Mt. Silver (Exterior, Night) - Super Rod; Dratini 30%
Mt. Silver Cave (Various) - Good Rod; Barboach 40%
Mt. Silver Cave (Various) - Super Rod; Whiscash 40%


3f Wild Encounters - Starters
Route 1 - Venusaur (7% all day; 12% in Morning)
Route 3 - Charizard (7% all day; 12% in Night)
Route 24 - Blastoise (7% all day; 12% in Day)
Hoenn and Sinnoh starters are found via Hoenn Radio and Sinnoh Radio of these routes.


Johto Starters can be found postgame in the Safari Zone; see section 3c5.
4X Event Changes
4a Overview and Levels
All event Pokemon are now fully obtainable, and all events aside from the Universe Egg (working on it, not sure how to do it) have been restored. Furthermore, all legendaries are fightable as static encounters. A man in the Frontier Access will give you hints as to where they are hiding.


Most legendaries become available after beating the Elite Four and getting the National Dex. The next set becomes available AFTER GETTING ROCK CLIMB, which is after beating Blue.
The final set is AFTER GETTING THE BLUE ORB FROM MR. POKEMON, which is after beating Red and getting a Kanto starter from Prof. Oak.


Arceus specifically requires you to have received the National Dex Diploma from the Gamefreak employee in Celadon City. This means you must have all Pokémon EXCEPT Mew, Celebi, Jirachi, Deoxys, Phione, Manaphy, Darkrai, Shaymin, and Arceus.
Receiving the Azure Flute also sets the flags correctly, so you can head straight there.


Post Dex - level 60, 65 for Suicune and 70 for Lugia
Post Blue - level 70, 75 for Regigigas
Post Red - level 80 for Groudon/Kyogre, level 85 for the rest
Arceus is level 95
Roamer levels have not been edited.


PreDex: Entei*, Raikou*, Ho-oh*
PostDex: Regirock/Regice/Registeel, Latios/Latias*, Shaymin, Manaphy, Celebi, Suicune*, Lugia*, Azelf/Uxie/Mesprit
PostBlue: Regigigas, Heatran, Darkrai, Cresselia, Articuno*/Zapdos*/Moltres*, Mewtwo*, Jirachi, Deoxys
PostRed: Kyogre*/Groudon/Rayquaza*, Dialga/Palkia/Giratina, Mew
Diploma: Arceus
* marks a fight available in vanilla.


4b Event Changes List
EVENT SPOILERS:


Ilex Shrine (Celebi): Event is fully intact, you just need a Celebi and 12 badges. Required for some post-Blue content.


Ilex Shrine (Spiky-Eared Pichu): Event is fully intact, BUT you now need a Raichu instead of a Pichu. Remember that the Spikey-Eared Pichu cannot be traded nor evolve in any way.


Sinjoh Ruins: Event is currently unavailable. However, using an event Arceus still works. Also, you have to bring Arceus to get another one of the Creation Trio, and you need the Creation Trio to get Arceus. It's basically just a little bonus if you want to see it.


Flower Shop Gracidea: Event is fully intact and now works even with any Shaymin. After beating Erika, you can fight Shaymin in Celadon; after this, just bring Shaymin to the flower shop.


4c Legendary Encounters


LEGENDARY SPOILERS:
All of these are NPCs you need to talk to. Some have a question for you, others just want to get down to fighting.
Talk to the guy in Frontier Access for hints.


4c1 Post-Dex
Latios - Pewter City, Runner
Uxie - Sprout Tower/Violet City, Old Lady
Azelf - Pokelathon/National Park, Cowgirl
Mesprit - Radio Tower Pinnacle/Goldenrod, Attendant
Celebi - Route 34 (closest to Ilex), Scientist
Manaphy - Cerulean Gym, Maid
Shaymin - Celadon Town, School Kid


Regice - Ice Path, Snowboarder
Regirock - Tohjo Falls, Hiker
Registeel - Diglett Cave, Juggler
4c2 Post-Blue
Regigigas - Mt. Silver Expert Belt Chamber, Regigigas
Heatran - Cinnabar Island, Firebreather
Cresselia - Lavender Town, Singer
Darkrai - Dark Cave, Gym Glasses Guy
Jirachi - Pallet Town, Female Picnicker
Deoxys - Silph Co., Male Team Rocket Grunt


4c3 Post-Red
Mew - Route 25, below the Cerulean Cape, Schoolgirl
Groudon - Right outside Embedded Tower, Route 48, Waiter
Dialga - Route 48, Sage
Adamant Orb - Vermilion City
Palkia - Lake of Rage, Parasol Lady
Lustrous Orb - Olivine Lighthouse
Giratina - Slowpoke Well, Conductor
Griseous Orb - Dragon's Den


Arceus:
“Words to the wise: We came. We built.
We sensed and rejected. We left.
The creator still holds dear that which permits his advent.
Past union's depth, a path leading to wisdom and ruin opens.
There, the artisan of the universe seeks your challenge.
Enter the path of the pillar of water,
behind the spiraling, shelled swimmer from before your time.”




(If you NEED more of a hint, Arceus is somewhere in the Ruins of Alph.)


4dX NPC Field Additions
4d1 Superbosses
*Spoilers ahead.
Tier 1 Superbosses
Unlock after beating Blue and getting Rock Climb


Elder Li - Sprout Tower
Kuni - Kimono Theater
Mr. Game - Goldenrod Game Corner


Tier 2 Superbosses
Unlock after beating two of the Tier 1 Superbosses and visiting Viridian Forest


Eusine - Bellchime Trail
Proton - Rocket Hideout
Petrel - Rocket Hideout
Archer - Cherrygrove City
Archer - Rock Tunnel


Tier 3 Superbosses
Unlock after completing the Celebi Event in Ilex Forest, finishing the Silver Multi in Dragon’s Den, and beating all Tier 2 Superbosses


Giovanni - Tohjo Falls
4d2 Gym Leaders
Requirements are the same as to get a photograph from them.


Falkner - Celadon Department Store 4F; Weds
Bugsy - National Park; Monday, Friday
Whitney - Goldenrod Department Store 6F; 6:00 PM - 9:00 PM
Morty - Bellchime Trail; Friday
Chuck - Route 47; Sunday (no longer vanishes after Jade Orb)
Jasmine - Olivine Cafe; 12:00 PM - 1:00 PM
Pryce - Lake of Rage; 6:00 AM - 10:00 AM (Photo available all-day in Mahogany Gym)
Clair - Dragon’s Den; 5:00 - 7:00 PM
Brock - Diglett’s Cave R2 Side; Tues/Weds/Fri/Sun 5:00 PM - 9:00 PM
Misty - Route 25; 2:00 PM - 4:00 PM
Lt. Surge - Route 39; Saturday (requires Magnet Train Station Trade)
Erika - Celadon City; Monday
Janine - League Reception Gate; 6:00 PM - 8:00 PM
Sabrina - Olivine City Harbor; Monday, Friday
Blaine - Cinnabar Island; Thursday
Blue - Cinnabar Island; Friday


Byron - Olivine Lighthouse
Fantina - Kimono Theater after completing Radio Tower.


4d3 Elite Four
Appear after fixing the Power Plant with the Machine Part


Will+Karen - Cianwood City
Koga - Fuchsia City
Bruno - Pewter Museum


4d4 Frontier Brains
Appear after getting a Silver Print from them.
Palmer - Celadon Department Store 6F
Thorton - Bill’s Cottage
Darach - Route 39
Argenta - Pokeathlon Dome
Dahlia - Celadon Game Corner


Can be rematched on the following days
Monday - Palmer, Dahlia
Tuesday - Palmer, Thorton
Wednesday- Thorton, Darach
Thursday - Darach, Argenta
Friday - Argenta, Dahlia


5X Item Changes
5aX Evolution Items in the Overworld
5a1 About
HGSS technically provides access to the stones, but only by Pokelathon or phone call gifts. As such, concrete access is being added.
A Dusk Stone and a Shiny Stone can be found post-Radio Tower. Other items, such as the Protector, are not available until post-Lance so as to preserve the original feel of the game. Dusk and Shiny get singled out because while Rhydon and Gligar are strong enough for the Elite Four, Misdreavus and Togetic feel mediocre and are not worth using.
HGSS went out of its way to make sure you didn't have the cross-gen evos where possible; I don't quite agree with that, but I'm not sure if it's my place to override it.


While you will need more than appear here to complete the Pokedex, this makes it much easier to use, say, Growlithe or Misdreavus. Because you can actually evolve one. Feel free to buy the remaining amount for Lombre and whatnot in the postgame.


A * means they appear in the base game. Is not counting the Rock Climb availability outside of Shiny and Dusk.
King's Rocks are actually no longer required for evolution as Slowking is done via Water Stone and Politoed is done via leveling with Rain Dance.
5a2 Johto
Sun Stone - Route 47
Moon Stone - Ruins of Alph*, Tohjo Falls*
Fire Stone - Burned Tower
Thunderstone - Lake of Rage
Water Stone - Whirl Islands, Slowpoke Well
Leaf Stone - Cherrygrove City


Dragon Scale - Mt. Mortar*
Metal Coat - Olivine Cafe (6+ Badges)
King's Rock - Slowpoke Well*


Shiny Stone - National Park Rock Climb*, From Elm (Upstairs, 175+ Seen, Post-Radio Tower)
Dusk Stone - Goldenrod Tunnel (warehouse)
5a3 Kanto
Moon Stone - Mt. Moon Square (Mondays at Night)*
Fire Stone - Route 16
Water Stone - Seafoam Islands*
Leaf Stone - Viridian Forest*


Up-Grade - Silph Co.*


Dusk Stone - Cerulean Cave Rock Climb*
5b Shop Changes
Just A Souvenir Shop
*Sells Old Gateau, Lava Cookies, Dive Balls.


Celadon Dept. Store - 4F
*Sells Luxury Balls, Repeat Balls, Timer Balls


Olivine Angler House - TMs
Vermillion Portside House - Berries, Evo Items
5c TMs
TM31 Brick Break - Black Belt in Cliff Cave
TM47 Steel Wing - Route 41, past a Whirlpool
TM53 Energy Ball - From Amphy after using SecretPotion
TM56 Fling - Rocket HQ
TM62 Silver Wind - Ilex Forest (Surf section)
TM71 Stone Edge - Route 47 (Waterfall section)
TM81 X-Scissor - Route 43 (by the Apricorn)
TM91 Flash Cannon - Radio Tower Director's Room (after getting the Basement Key)


TM46 Thief - Left behind by the Grunts in Mt. Mortar; uses the same flag as the vanilla Thief which is still in Rocket HQ.
5d Fossil Guild
Hiker in Route 2 North
Trades fossils for their counterparts.
Helix <=> Dome
Claw <=> Root
Skull <=> Armor
Rare Bone => Old Amber
5e Misc.
New shard locations
*There is a trader who will take Athlete Points for shards in the R35 gate to National Park/Pokeathlon Dome.
*These replace preexisting unimportant items. If the original item is already obtained in a save file, you cannot get the shards.
Red Shard - Full Heal in Dark Cave R31 side
Red Shard - Antidote in Burned Tower
Red Shard - Ultra Ball in Mt. Mortar 1F Back
Red Shard - Ultra Ball in Radio Tower 4F
Red Shard - Revive in Rock Tunnel
Blue Shard - Awakening in Union Cave 1F
Blue Shard - Full Heal in Lake of Rage (dry)
Blue Shard - Ultra Ball Whirl Islands 1F, SW Entrance
Blue Shard - Max Potion in Ice Path
Blue Shard - Ice Heal in Seafoam Islands
Yellow Shard - Potion in Ruins of Alph
Yellow Shard - Parlyz Heal in Route 35
Yellow Shard - Full Heal in Goldenrod Warehouse Door Puzzle
Yellow Shard - Max Potion in Mt. Mortar 2F
Yellow Shard - Max Potion in Route 9
Green Shard - Antidote in Ilex Forest
Green Shard - Super Potion in Route 42
Green Shard - Revive in Route 47
Green Shard - Full Heal in Route 45
Green Shard - Dire Hit in Viridian Forest


Yellow Shard - Full Heal in Bell Tower 3F
Red Shard - Ultra Ball in Bell Tower 4F
Blue Shard - Full Heal in Bell Tower 6F


Old Amber - Dark Cave R45 side


*Player now receives 10 Poke Balls from Ethan/Lyra instead of 5.


*These are normally Pokewalker-exclusive.
Heat Rock - Reward for completing Blaine's curriculum.
Damp Rock - Route 13
Smooth Rock - Diglett's Cave
Icy Rock - Man in Celadon Department Store 5F


Rock Smash rocks
Cliff Cave (postgame) - now Pearl 25%, Root Fossil 20%, Big Pearl 10%, Red Shard 10%, Yellow Shard 10%, Claw Fossil 20%, Rare Bone 5%
Ruins of Alph - now Red Shard 25%, Yellow Shard 20%, Blue Shard 20%, Green Shard 15%, Helix Fossil 10%, Dome Fossil 10%
*Old Amber is available either by a ground item in Dark Cave R45, or trading Rare Bones with the Fossil Guild.
5fX Held Item Changes
*Please see the accompanying document for more details.


5f1 Legendary Items
Most legendaries now have items to give them a bit more oomph. These are largely offensive items, usually to boost their main STAB or give them their special item. These are all 100% chances.
To the best of my knowledge, Roaming Pokemon will never hold an item, but I'm NOT 100% certain of this.


Latias and Latios probably SHOULD have Soul Dew, but since it's event exclusive at best, nullified in the Battle Frontier and banned basically everywhere, it has been omitted.


Articuno - NevermeltIce
Zapdos - Magnet
Moltres - Wide Lens
Mewtwo - Wise Glasses
Raikou - Petaya Berry
Entei - Liechi Berry
Suicune - Sitrus Berry
Ho-Oh - Sacred Ash
Lugia - Sacred Ash
Regirock - Hard Stone
Regice - NevermeltIce
Registeel - Metal Coat
Latias - Petaya Berry
Latios - Quick Claw
Kyogre - Mystic Water
Groudon - Soft Sand
Rayquaza - Dragon Fang
Jirachi - Starf Berry
Deoxys - Petaya Berry (all but Defense); Starf Berry (Defense)
Uxie - Enigma Berry
Mesprit - Odd Incense
Azelf - Scope Lens
Dialga - Adamant Orb
Palkia - Lustrous Orb
Heatran - Sitrus Berry
Regigigas - Sitrus Berry
Giratina (Altered) - Spell Tag
Giratina (Origin) - Griseous Orb
Cresselia - Sitrus Berry
Phione - Starf Berry
Manaphy - Starf Berry
Darkrai - Wide Lens
Arceus - Petaya Berry


Mew, Celebi and Shaymin all naturally hold Lum Berries; this is unchanged.


6X Technical Stuff
6aX Flags
6a1 Important Flags
Flag 498, 0x1F2; used to determine whether you have completed the Mahogany track. Set by completing Rocket Hideout.
Flag 185, 0xB9; used to determine whether you have completed the Olivine track. Set by obtaining the SecretPotion.
Flag 512, 0x200; used to determine whether you have completed Radio Tower. Set after beating Archer. Used for the Shiny Stone gift from Elm.
Flag 569, 0x239; used to determine whether you have reached Blackthorn for the first time. Set by helping the Kimono Girl in Ice Path.


Flag 299, 0x12B; determines whether the second wave of legendaries and the initial superbosses will talk to you. Set by obtaining Rock Climb.
Flag 2558, 0x9FE; used to hide the Executive Superbosses. Is cleared/set when you go near the relevant areas; set if you haven’t met the requirements (beat 2 out of 3 of Kuni/Mr. Game/Li and do what the phone call tells you), cleared afterwards.
6a2 Formerly Unused Flags
Flag 2550, 0x9F6; used by Byron in Olivine City to tell if you've talked to him and received the SilverPowder before.
Flag 2551, 0x9F7; used by Byron in Olivine City to tell if you've received the Lustrous Orb.
Flag 2552, 0x9F8; used by a man in Vermilion City to tell if you've received the Adamant Orb.
Flag 2553, 0x9F9; used by Falkner in Dragon's Den to tell if you've received the Griseous Orb.
Flag 2554, 0x9FA; used by the Painter sprite in the Arceus fight.
Flag 2555, 0x9FB; used by a set of strange men who aren't not in Dark Cave.
Flag 2556, 0x9FC; handles a researcher in Ruins of Alph’s ability to revive fossil Pokemon. Set by clearing all four slide puzzles.
Flag 2557, 0x9FD; UNUSED.
Flag 2558, 0x9FE; used to hide the Executive Superbosses. Is cleared/set when you go near the relevant areas; set if you haven’t met the requirements (beat 2 out of 3 of Kuni/Mr. Game/Li and do what the phone call tells you), cleared afterwards.
Flag 2559, 0x9FF; used to hide the Giovanni Superboss in Tohjo Falls.
Flag 2560, 0xA00; UNUSED
Flag 2561, 0xA01; used by the Eusine Superboss to tell if you've fought him before.
Flag 2562, 0xA02; used by the Giovanni Superboss to tell if you've fought him before.
Flag 2563, 0xA03; used by the Proton Superboss to tell if you've fought him before.
Flag 2564, 0xA04; used by the Petrel Superboss to tell if you've fought him before.
Flag 2565, 0xA05; used by the Archer Superboss to tell if you've fought him before.
Flag 2566, 0xA06; used by the Ariana Superboss to tell if you've fought her before.
Flag 2567, 0xA07; used by the Mr. Game superboss to tell if you've fought him before.
Flag 2568, 0xA08; used by the Elder Li superboss to tell if you've fought him before.
Flag 2569, 0xA09; used by the Kuni superboss to tell if you've fought her before.
Flag 2570, 0xA0A; used by Professor Elm in his living room to tell if you've gotten the Shiny Stone from him before.
Flag 2571, 0xA0B; set by getting a Heat Rock for finishing Blaine's curriculum. Talk to the lady at the front with the Volcano Badge to obtain it if you never got one.
Flag 2572, 0xA0C; set if you've helped a man in Celadon Dept. Store 5F (9 badges+).
Flag 2573, 0xA0D; Smooth Rock in Diglett's Cave.
Flag 2574, 0xA0E; Damp Rock in Route 13.
Flag 2575, 0xA0F; Metal Coat Sailor in Olivine Cafe.
Flag 2576, 0xA10; Dusk Stone in Goldenrod's warehouse.
Flag 2577, 0xA11; Sun Stone in Route 47
Flag 2578, 0xA12; Fire Stone in Burned Tower
Flag 2579, 0xA13; Thunderstone in Lake of Rage
Flag 2580, 0xA14; Water Stone in Whirl Islands
Flag 2581, 0xA15; Water Stone in Slowpoke Well
Flag 2582, 0xA16; Leaf Stone in Cherrygrove City (Route 30 Pond)
Flag 2583, 0xA17; Fire Stone in Route 16
Flag 2584, 0xA18; TM31 Brick Break from Black Belt in Cliff Cave
Flag 2585, 0xA19; TM47 Steel Wing in Route 41
Flag 2586, 0xA1A; TM53 Energy Ball from Amphy after using SecretPotion
Flag 2587, 0xA1B; TM56 Fling in Rocket HQ
Flag 2588, 0xA1C; TM62 Silver Wind in Ilex Forest
Flag 2589, 0xA1D; TM81 X-Scissor in Route 43
Flag 2590, 0xA1E; TM91 Flash Cannon in Radio Tower Director's Room
Flag 2591, 0xA1F; TM71 Stone Edge in Route 47 Waterfall Area
Flag 2592, 0xA20; reserved in case of ground item in future update.
Flag 2593, 0xA21; Old Amber in Dark Cave R45 Side.
Flag 2594, 0xA22; Articuno NPC Defeated Flag; set if you have defeated the Articuno NPC before. UNUSED
Flag 2595, 0xA23; Zapdos NPC Defeated Flag; set if you have defeated the Zapdos NPC before. UNUSED
Flag 2596, 0xA24; Moltres NPC Defeated Flag; set if you have defeated the Moltres NPC before. UNUSED
Flag 2597, 0xA25; Mewtwo NPC Defeated Flag; set if you have defeated the Mewtwo NPC before. UNUSED
Flag 2598, 0xA26; Mew NPC Defeated Flag; set if you have defeated the Mew NPC before.
Flag 2599, 0xA27; Raikou NPC Defeated Flag; set if you have defeated the Raikou NPC before. UNUSED
Flag 2600, 0xA28; Entei NPC Defeated Flag; set if you have defeated the Entei NPC before. UNUSED
Flag 2601, 0xA29; Suicune NPC Defeated Flag; set if you have defeated the Suicune NPC before. UNUSED
Flag 2602, 0xA2A; Lugia NPC Defeated Flag; set if you have defeated the Lugia NPC before. UNUSED
Flag 2603, 0xA2B; Ho-Oh NPC Defeated Flag; set if you have defeated the Ho-Oh NPC before. UNUSED
Flag 2604, 0xA2C; Celebi NPC Defeated Flag; set if you have defeated the Celebi NPC before.
Flag 2605, 0xA2D; Regirock NPC Defeated Flag; set if you have defeated the Regirock NPC before.
Flag 2606, 0xA2E; Regice NPC Defeated Flag; set if you have defeated the Regice NPC before.
Flag 2607, 0xA2F; Registeel NPC Defeated Flag; set if you have defeated the Registeel NPC before.
Flag 2608, 0xA30; Latias NPC Defeated Flag; set if you have defeated the Latias NPC before. UNUSED
Flag 2609, 0xA31; Latios NPC Defeated Flag; set if you have defeated the Latios NPC before.
Flag 2610, 0xA32; Kyogre NPC Defeated Flag; set if you have defeated the Kyogre NPC before. UNUSED
Flag 2611, 0xA33; Groudon NPC Defeated Flag; set if you have defeated the Groudon NPC before.
Flag 2612, 0xA34; Rayquaza NPC Defeated Flag; set if you have defeated the Rayquaza NPC before. UNUSED
Flag 2613, 0xA35; Jirachi NPC Defeated Flag; set if you have defeated the Jirachi NPC before.
Flag 2614, 0xA36; Deoxys NPC Defeated Flag; set if you have defeated the Deoxys NPC before.
Flag 2615, 0xA37; Uxie NPC Defeated Flag; set if you have defeated the Uxie NPC before.
Flag 2616, 0xA38; Mesprit NPC Defeated Flag; set if you have defeated the Mesprit NPC before.
Flag 2617, 0xA39; Azelf NPC Defeated Flag; set if you have defeated the Azelf NPC before.
Flag 2618, 0xA3A; Dialga NPC Defeated Flag; set if you have defeated the Dialga NPC before.
Flag 2619, 0xA3B; Palkia NPC Defeated Flag; set if you have defeated the Palkia NPC before.
Flag 2620, 0xA3C; Heatran NPC Defeated Flag; set if you have defeated the Heatran NPC before.
Flag 2621, 0xA3D; Regigigas NPC Defeated Flag; set if you have defeated the Regigigas NPC before.
Flag 2622, 0xA3E; Giratina NPC Defeated Flag; set if you have defeated the Giratina NPC before.
Flag 2623, 0xA3F; Cresselia NPC Defeated Flag; set if you have defeated the Cresselia NPC before.
Flag 2624, 0xA40; Manaphy NPC Defeated Flag; set if you have defeated the Manaphy NPC before.
Flag 2625, 0xA41; Darkrai NPC Defeated Flag; set if you have defeated the Darkrai NPC before.
Flag 2626, 0xA42; Shaymin NPC Defeated Flag; set if you have defeated the Shaymin NPC before.
Flag 2627, 0xA43; Arceus NPC Defeated Flag; set if you have defeated the Arceus NPC before.
Flag 2628, 0xA44; used to tell if you've paid the toll in Mt. Mortar.
Flag 2629, 0xA45; used to hide the Rocket Grunt in Mt. Mortar after beating Morty.
Flag 2630, 0xA46; early-Kanto Diglett Tunnel roadblock. Set after getting 12 badges.
Flag 2631, 0xA46; early-Kanto Nugget Bridge roadblock. Set after getting 12 badges and trying to cross.
Flag 2632, 0xA47; set if you have received the call to start the superboss quest.
Flag 2633, 0xA48; set if you have started the superboss quest.
Flag 2634, 0xA49; set if you have talked to the informant after having beaten all 5 superbosses and completed the Lance+Clair multi battle in Dragon’s Den.
Flag 2635, 0xA4A; set if you have talked to Eusine after getting 16 badges and catching Suicune.
Flag 2636, 0xA4B; set to mark the call to unlock the Giovanni battle as ready.
Flag 2637, 0xA4C; set to mark the Giovanni superboss in Tohjo Falls as being unlocked.
Flag 2638, 0xA4D; set if you’ve talked to the Eusine superboss before.
Flag 2639, 0xA4E; set if you’ve talked to the Giovanni superboss before.
Flag 2640, 0xA4F; set if you’ve talked to the Proton superboss before. Set with the Proton battle flag.
Flag 2641, 0xA50; set if you’ve talked to the Petrel superboss before. Requires the Proton battle flag.
Flag 2642, 0xA51; set if you’ve talked to the Archer superboss before.
Flag 2643, 0xA52; set if you’ve talked to the Ariana superboss before.
Flag 2644, 0xA53; UNUSED
Flag 2645, 0xA54; used to hide a special dialogue NPC if the player has met the requirements and rolls a 1/150 chance when entering a certain area.
6b Variables Used
Important Variables:
Var 16638, 0x40FE; determines if the Celebi Giovanni event has been completed.


[not relevant yet, will be relevant in a future update]
16461, 0x404D - Palmer Print; If 2+ (Silver Print), Palmer will appear at X.
16462, 0x404E - Thorton Print; If 2+ (Silver Print), Thorton will appear at X.
16463, 0x404F - Argenta Print; If 2+ (Silver Print), Argenta will appear at X.
16464, 0x4050 - Darach Print; If 2+ (Silver Print), Darach and Caitlin will appear at X.
16465, 0x4051 - Dahlia Print; If 2+ (Silver Print), Dahlia will appear at X.


Formerly Unused Variables:


Var 16418, 0x4022; a variable of little importance.
Var 16419, 0x4023; a variable of little importance.
Var 16420, 0x4024; Used in Glitter Lighthouse
Var 16421, 0x4025; counts the # of "lower tier" superbosses (Mr. Game, Elder Li, Kuni) that have been defeated.
Var 16422, 0x4026; the track the player chose first. Set to 1 (Olivine Track first) or 2 (Mahogany Track first).
Var 16423, 0x4027; handles the initial Superboss quest call triggers.
Var 16424, 0x4028; handles the end of the Superboss quest.
6c Script Archives Added
965; Mt. Silver's Expert Belt chamber, used so Regigigas can say things
966; Bell Tower Pinnacle Entrance, used so a lost sage can say things
967 to 972; something secret and unused.
973; Mt. Mortar Entrance
974; Mt. Mortar Entrance Levelscript
975; Mt. Mortar Back
976; Mt. Mortar Back Levelscript
977; Mt. Mortar Waterfall
978; Mt. Mortar Waterfall Levelscript
979; Whirl Islands 1F
980; Whirl Islands 1F Levelscript
981; Dark Cave R31
982; Dark Cave R31 Levelscript
983; A House
984; A House, Levelscript
985; Rock Tunnel 1F
986; Rock Tunnel 1F Levelscript
6d Event Files
N/A
6e Text Archives Added
829; Lighthouse balcony, used so Byron can say things.
830; Dark Cave (Violet Entrance), used so an NPC can allude to Almia
831; Tohjo Falls, used so Regirock can say things
832; Mt. Silver's Expert Belt chamber, used so Regigigas can say things
833; One of the Ruins of Alph chambers, used so an old man can say things
834; Bell Tower Pinnacle Entrance, used so a lost sage can say things
835 to 840; something secret and unused.
841; Mt. Mortar entrance, used so a Rocket Grunt can flail angrily at you.
842; A House
843; Rock Tunnel 1F
6f Encounter Files Added
142 - Route 38; Post-Morty
143 - Route 38; Post-Mahogany
144 - Route 39; Post-Morty
145 - Route 39; Post-Mahogany
146 - Route 40; Post-Mahogany
147 - Route 41; Post-Mahogany
148 - Olivine City; Post-Mahogany
149 - Cianwood City; Post-Mahogany
150 - FILLER
151 - Mt. Mortar Entrance; Post-Morty
152 - Mt. Mortar Entrance; Post-Olivine
153 - Mt. Mortar Back; Post-Morty
154 - Mt. Mortar Back; Post-Olivine
155 - Mt. Mortar Karate King; Post-Morty
156 - Mt. Mortar Karate King; Post-Olivine
157 - Route 42; Post-Morty
158 - Route 42; Post-Olivine
159 - Route 43; Post-Olivine
160 - FILLER
161 - Route 46; Post-Ice Path
162 - Dark Cave R45 Side; Post-Ice Path
163 - Whirl Island 1F; Post-Silver Wing
164 - Whirl Island B1F; Post-Silver Wing
165 - Whirl Island B2F; Post-Silver Wing
6g Notable Maps
Superboss Weather-Rooms
*Now irrelevant.
T27R0101 "Jubilife City", 82, 0x52; Rain
T27R0601 "Jubilife City", 105, 0x69; Hail
T22R0501 "Jubilife City", 161, 0xA1; Sand
T27R0301 "Jubilife City", 175, 0xAF; Sun (no relevant weather)


Dev Rooms??
Currently unused.
T25R1301 "Goldenrod City", 0xD0
T25R1302 "Goldenrod City", 0xD1
T25R1303 "Goldenrod City", 0xD2
T25R1304 "Goldenrod City", 0xD3
T25R1305 "Goldenrod City", 0xD4
T25R1306 "Goldenrod City", 0xD5
6h MISC.
*Weathers 20 and 21 now apply Sun and Trick Room respectively.
*Pewter Gym has Sandstorm.
*Seafoam Island Gym has Sun.
*Viridian Gym has Trick Room.
*Routes 13, 15 have Rain all-day.
*Route 14 has Sun from 4:00 to 17:00
*Route 17 has Sun from 4:00 to 20:00 and Rain from 0:00 to 4:00.
7X Trainers
7a Trainer IDs Added


IDs 735 to 862
Various unused trainers are now used.


*See the other Readme for more details.
8X Random Stuff
8a Random Thoughts
This is basically what I had in mind when I was thinking about how to do this.
Grand total of (8+9+12+27+4+5+9=74 evolutionary lines), bar legends.
8 Version Exclusive
9 DPPt only
12 Pokewalker
27 Safari
5 Bug-catching
5 Gift only
9 Starter


Version exclusives (8 evolution lines+Embedded Tower Legendary):
HG
Mankey, Primeape, Growlithe, Arcanine, Spinarak, Ariados, Gligar, Gliscor, Mantyke, Mantine, Phanpy, Donphan, Sableye, Baltoy, Claydol, Kyogre
SS
Vulpix, Ninetales, Meowth, Persian, Ledyba, Ledian, Teddiursa, Ursaring, Delibird, Skarmory, Mawile, Gulpin, Swalot, Groudon


Unobtainable Pokemon (9 lines in the wild)
Wild: Sinnoh starters, Cranidos line, Shieldon line, Drifloon line, Glameow line, Stunky line, Rotom
Legendaries: Regis, Uxie, Mesprit, Azelf, Heatran, Cresselia, mythicals.
Mt. Coronet/Eterna/216: Magnezone, Leafeon, Glaceon, Probopass (can be fixed by changing their evolutions)


Pokewalker Exclusives: (12 evolution lines)
Skitty, Delcatty, Carvanha, Sharpedo, Wailmer, Wailord, Feebas, Milotic, Castform, Kecleon, Tropius, Snorunt, Glalie, Shellos, Gastrodon, Spiritomb, Finneon, Lumineon, Snover, Abomasnow, Froslass


Safari Item Exclusive Pokemon: (27 evolution lines)
There may be overlap, this lists each line by the first time it appears in this list
Plains;
Manectric, Zangoose, Lotad, Surskit
Meadow;
Nuzleaf, Nosepass, Riolu
Savannah;
Cacturne, Shroomish, Torkoal
Peak;
Lairon, Spheal, Vigoroth
Rocky Beach;
Gible, Corpish
Wetland;
Pachirisu, Shelgon
Forest;
Shuppet, Beldum
Swamp;
Duskull
Marshland;
Seviper, Croagunk
Wasteland;
Skorupi, Solrock
Mountain;
Lunatone
Desert;
Hippopotas, Trapinch


Bug Catching Exclusive Pokemon (4 evolution lines; 5 if Volbeat/Illumise are separate)
Pinsir, Scyther, Nincada, Volbeat, Illumise


Gift: (5 lines)
Eevee, Porygon, Sudowoodo, Togepi, Tyrogue


Starters: (9 lines)
Chikorita, Cyndaquil, Totodile, Bulbasaur, Charmander, Squirtle, Treecko, Torchic, Mudkip


Lists
https://serebii.net/heartgoldsoulsilver/hoennsinnoh.shtml
https://serebii.net/heartgoldsoulsilver/safarizone.shtml


8b Bugs
- When saving and reloading in one of the “nonlinear” maps, the encounter file will use the weakest by default until you reenter the map. This is a hardware limitation.
- For some reason a few of the gym leader field dialogue after taking a photo plays when saying NO to the photo, and for some it is after saying YES to a photo. I cannot tell how or why this is happening.
9X FAQ
Q: What’s the difference between Refined Gold and Refined Gold Overhaul?
A: Refined Gold is much more purist vis a vis vanilla content. It has very minimalist trainer changes, making for a closer to vanilla gameplay experience. Since aforementioned gameplay experience is garbage, I made Refined Gold Overhaul, which ought to make it closer to USUM in trainer quality than HGSS. In other words:
Refined Gold is for people who want to play vanilla HG but not deal with the full agony of Heartgold, or want to be able to complete the National Pokedex.
Refined Gold Overhaul is what I feel like HGSS *should* have been if it was built with Gen 4 standards for gameplay and progression.


Q: My game crashes constantly on a flashcart!
A: If this happens, update to the latest version of the hack and/or the latest version of TwilightMenu. Thanks to DeadSkullzJr, the antipiracy patching needed for RGO is now a part of TWM+.


Q: Are there any type changes?
A: No type changes, ability changes or stat changes. All movepools are also HG legal, more or less. If anyone asks, I did so against my will. If only I could have had X-Scissor Ariados…


Q: What is the shiny rate?
A: The shiny rate is untouched from vanilla.


Q: Why Heartgold over Soulsilver?
A: I don’t have the energy to make two hacks that are functionally identical bar title screen and legendary and then justify making two hacks instead of just having one. Of the two, Ho-Oh felt way more atmospheric and thematically appropriate given Johto’s themes and style.


Q: Why Lyra over Kris?
A: Setting aside that this isn’t a Crystal hack, Lyra’s poofy hat is too cute for me to forsake it.


Q: Why are there Slugma in Mt. Mortar?
A: Apparently Steven collected pitchstone from Mt. Mortar. Pitchstone is a volcanic glass, meaning Mt. Mortar is likely an extinct volcano. That huge water section is most likely the old crater.


Q: Where can I find [item]?
A: The only items added are covered in 5X. There is a Dusk Stone and Shiny Stone available to the player, but other items such as the Protector are limited to post-E4.


Q: Where can I find [Pokemon]?
A: All non-legendary Pokemon are available pre-Blue, but pre-Lance only most Johto Dex mons are available. Check 3X. No exotic mons are available pre-E4.


Q: Will you add [Fairies, G5+ mons, Megas, Dynamax, Ice Stone, etc]
A: No. This goes against the spirit of the hack.


Q: What do I do after [event]?
A: I haven’t changed anything substantial about the plot. Kanto requires you to complete the Machine Part sidequest as well as beat Janine, Sabrina, Erika and Lt. Surge before moving on to the second half, but otherwise it should be as it was in vanilla.


Q: Can I contact you?
A: I’d love to hear about your experience with my hack. Please contact me on Discord.
ZX Disclaimer and Credits


Most changes were done by myself. Some teams were written and added by the people listed below.


Special thanks to the following:
Input on design, theorycrafting, and balancing/encounter distribution was provided by Frozen Metroid/Senate, Julian Kaffeebohnen, SpagoAsparago, PathologicalLurker, Quick, Worcestershirey, TitaniumTogekiss, PksLab, Gorapa, DarmaniDan, Tanning Bed, Dr. Fizz, SkarmTSK, and McGee. TwilightMenu++ compatibility courtesy of DeadSkullzJr.
Assistance in hacking and discovering absolutely ridiculous new ways to surmount obstacles was provided by AdAstra, Cannons, Drayano, turtleisaac, Nomura, Lhea, and BluRose.
And, of course, there are countless others who have provided small bits of insight or suggestions. Shoutout to Melki, PathoLurk, Viridian, Wobb, Minkuru, and Gelius.
Thank you as well to all of the beta testers who helped make sure this hack was a quality and enjoyable one.


Thank you to everyone who helped me, gave me suggestions, and cheered me on. I love all of you :D


I have received no money for doing this. All characters and rights belong to Nintendo and other relevant figures. This is strictly for non-profit purposes and should fall within fair use accordingly.