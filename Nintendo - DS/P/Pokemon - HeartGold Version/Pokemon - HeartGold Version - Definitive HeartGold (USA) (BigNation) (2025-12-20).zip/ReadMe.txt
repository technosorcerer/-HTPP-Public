Read this note for some information!

In this drive there is the patch download to use for your copy of HeartGold.
Do not ask how to get the rom itself due to legal reasons.

The HeartGold ROM that you apply the patch to should have the following as their CRC32 values. 
If they don't, the patch may fail to apply.
Heart Gold: C180A0E9

Link to patcher: https://www.romhacking.net/utilities/598/

If you encounter an issue with Definitive HeartGold then redownload the patch again
and make sure you have the correct version of base HeartGold for the installation process. 
Save Files will still be compatible.

Encounter Table: https://bit.ly/DefHGEncounterTable

Video talking about the game: https://www.youtube.com/@BigNation1

Discord server that also contains info: https://discord.com/invite/qbjHWJr