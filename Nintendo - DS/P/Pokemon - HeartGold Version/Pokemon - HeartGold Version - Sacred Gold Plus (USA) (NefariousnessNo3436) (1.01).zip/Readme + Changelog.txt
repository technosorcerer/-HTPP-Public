Sacred Gold Plus has the following changes:

- Fairy type implemented (credits to mikelan)
- 14 additional Fairy type moves (5 status, 5 special, 4 physical)
- Learnset changes to distribute the new fairy type moves around
- Black & White style camera (outdoors and indoors are fully 3D & more FoV)
- Some additional cheats for QoL (uncap fps, instant text, disable 3d edge marking etc, check the Extras folder)

Credits to Drayano, Mikelan and all who worked SG/SS.

Be sure to check the Extras folder for additional cheat codes and all of the original SG/SS Documentations.


HOW TO INSTALL:
(only US rom supported)

- Open xdeltaUI.exe
- for Patch select the file named "Sacred Gold Plus 1.0.xdelta"
- for Source File select your un-modified copy of Heart Gold (US)
- for output file, select a location you would like to save the rom to,
make sure to name the rom something you will remember and add .nds at the end.
- you can now play the game, enjoy!

Changelog:

1.0: Initial Release

1.01: Minor Fixes
- added Dazzling Gleam to the Togepi, Togetic and Togekiss learnsets
- added Old Patches folder for history sake
- added Compatible usrcheat.dat for Twiligt Menu / R4 Cards that contains
all the cheats I've made for this rom hack

