Ever wondered what Ash / Satoshi would look like in a Pokemon game?

I might not be the only one who wanted to play with Ash / Satoshi in some Pokemon game, so I'll share the pixelart work I did and was able to incorporate into my favorite game of the franchise to play on my Twitch channel. 

There are still some changes to make like editing the trainer card or the VS image for Ash, but all the main things have been covered (overworld sprites and Battle sprites).

features
- all Gold/Ethan "Overworld" sprites were changed to Ash / Satoshi including the following animations:
 - idle
 - walk
 - run
 - bicycle
 - surf
 - HM/TM
 - Save

- Added an alternate costume for the Team Rocket base infiltration chapter inspired by the Team Rocket costume from the anime that includes all of the above mentioned animations.

- Changed the Battle sprite with all the animations of throwing Pokeball and sending the pokemon to battle.

now you can use pokesav to get pikachu and have a nostalgic experience.

some bug (nothing serious): 
There is a visual bug at the beginning of the battle transition in some parts, I'm just an artist so I couldn't do much about it, however I think the artwork covers enough to make the experience compelling. hope you enjoy it and that the art quality is to your liking.

- Kensu William (Kensuyjin33)

Don't forget to follow me on my social networks where I do Pixelart, 
also if you have any custom Sprite request you can send a DM on any 
of my social networks through the following links:

All Links:
https://beacons.ai/kensuyjin33

Portfolio:
https://www.behance.net/Kensuyjin33

Art Gallery:
https://www.deviantart.com/kensuyjin33

Twitch:
https://www.twitch.tv/kensuyjin33

Youtube:
https://www.youtube.com/c/kensuwilliam

X (Twitter):
https://twitter.com/KensuWilliam

Instagram:
https://www.instagram.com/kensuyjin33/

My discord server:
https://discord.com/invite/ymP4aymvcn

Donations:
https://www.paypal.com/paypalme/kensuyjin33

Thanks :D