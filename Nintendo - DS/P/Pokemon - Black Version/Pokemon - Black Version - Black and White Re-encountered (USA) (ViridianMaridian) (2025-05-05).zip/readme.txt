Patch at https://www.romhacking.net/patch/

Requires US Black or White ROM (NOT PROVIDED)

-------------------------------------------------------------------------------------------------------------------------------------------------------------

Wish there were more than five Pokemon obtainable before the first gym in Pokemon Black and White?
Sick of waiting until near the end of the game to obtain Pokemon like Pawniard, Vullaby or Mienfoo?
Then Pokemon Black and White Re-encountered is for you!

This small rom hack brings many of the later encounters forward and removes roadblocks to improve encounter variety in the early game. Every non-legendary and non-pseudo-legendary is available for capture before the seventh badge, including Zorua!

Some highlights include early access to the Dreamyard and Pinwheel Forest, Surf obtainable in Driftveil City and previously unremarkable routes like Route 18 given unique encounters.

Perfect for a first time playthrough. 99% of the adventure is the same, but now you can enjoy building your team from the wide variety of Unova Pokemon without waiting a painfully long time to obtain them all.

-------------------------------------------------------------------------------------------------------------------------------------------------------------

OVERWORLD CHANGES
-Dreamyard cone moved so the grass is accessible before Gym 1.
-Pinwheel Forest Plasma Grunt blockade moved further in so the grass is accessible before Gym 2.
-Fly is now obtained in Nimbasa City from the Ace Trainer in place of Strength.
-Surf is now obtained in Driftveil City from Bianca in place of Fly.
-Strength is now obtained at Twist Mountain from Alder in place of Surf.
-Trainer Pokemon and Wild Pokemon levels have been adjusted accordingly.

-------------------------------------------------------------------------------------------------------------------------------------------------------------

ENCOUNTER CHANGES
-Route 2 has Pidove replacing Lillipup.
-Dreamyard has Sewaddle replacing Patrat.
-Dreamyard has Venipede added.
-Desert Resort has Vullaby replacing Dwebble.
-Vullaby is no longer version exclusive.
-Lostlorn Forest has Zorua added (only in Dark Grass).
-Cold Storage has Pawniard replacing Timburr.
-Route 1 Dark Grass has Scraggy removed.
-Route 18 has Mienfoo replacing Scraggy.
-Route 18 has Rufflet added.
-Rufflet is no longer version exclusive.
-Route 18 now first appearance of Dwebble.
-P2 Laboratory has Dwebble replacing Scraggy.
-Route 7 has Bouffalant replacing Deerling.
-Twist Mountain has Heatmor added (now exclusive to Pokemon White).
-Twist Mountain has Durant added (now exclusive to Pokemon Black).
-Icirrus City has Ducklett replacing Stunfisk.
-Route 8 has Ducklett replacing Stunfisk.
-Moor of Icirrus now first appearance of Stunfisk.
-Dragonspiral Tower has Pawniard replacing Mienfoo.
-Route 9 has Scraggy replacing Pawniard.
-Route 10 has Tranquill replacing Vullaby/Rufflet.
-Victory Road has Vullaby replacing Rufflet in white version.
-Route 11 has Tranquill and Unfezant replacing Vullaby/Rufflet and Mandibuzz/Braviary.
-Village Bridge has Tranquill and Unfezant replacing Vullaby/Rufflet and Mandibuzz/Braviary.
-Route 14 has Mienfoo and Mienshao removed.

-------------------------------------------------------------------------------------------------------------------------------------------------------------

POKEMON CHANGES
-Sewaddle evolves at level 18.
-Venipede evolves at level 20.
-Vullaby evolves at level 37.
-Pawniard evolves at level 40.
-Mienfoo evolves at level 41.
-Mienfoo learns Quick Guard at level 41 and U-turn at level 45.
-Mienshao learns Wide Guard at level 41 and U-turn at level 45.
-Dwebble evolves at level 38.
-Rufflet evolves at level 42.
-Larvesta evolves at level 50.
-Volcarona learns Flame Burst at level 50 and Silver Wind at level 55.
-Zorua evolves at level 40.

-------------------------------------------------------------------------------------------------------------------------------------------------------------

Rom hack creator: ViridianMaridian - https://www.pokecommunity.com/members/viridianmaridian.1123523/