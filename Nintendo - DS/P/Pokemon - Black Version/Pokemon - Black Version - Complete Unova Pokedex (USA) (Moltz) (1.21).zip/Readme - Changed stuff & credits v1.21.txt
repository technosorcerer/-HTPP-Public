;;;;;;;;;;;IMPORTANT INFO;;;;;;;;;;;;;
Unlike previous versions, the romhack now makes use of a properly dumped rom of Pokémon Black and Pokémon White.
Therefore, it's suggested to everyone to switch into it ASAP to ensure the game can run on normal hardware and emulation without running into issues.

;;;;;;;Movepool Changes/Additions;;;;;;;

-Spinarak & Ariados
Can now learn X-Scissor by TM.

-Purrloin & Liepard
Can now learn U-Turn by TM.

-Simisage
Learns Torment at level 25.
Learns Grass Knot at level 31.
Learns Recycle at level 36.
Learns Natural Gift at level 40.
Learns Crunch at level 43.

-Simisear
Learns Amnesia at level 25.
Learns Fire Blast at level 31.
Learns Recycle at level 36.
Learns Natural Gift at level 40.
Learns Crunch at level 43.

-Simipour
Learns Taunt at level 25.
Learns Brine at level 31.
Learns Recycle at level 36.
Learns Natural Gift at level 40.
Learns Crunch at level 43.

-Musharna
Learns Yawn at level 1.
Learns Imprison at level 1.
Learns Nightmare at level 24.
Learns Future Sight at level 31.
Learns Psychic at level 37.
Learns Calm Mind at level 43.
Learns Stored Power at level 47.

-Leavanny
Learns Bug Buzz at level 54.
Learns Flail at level 59.

-Whimsicott
Learns Stun Spore at level 1.
Learns Poison Powder at level 1.
Learns Gust at level 16.
Learns Charm at level 19.
Learns Giga Drain at level 26.
Learns Tailwind at level 28.
Learns Helping Hand at level 35.
Learns Hurricane at level 46.
Learns Endeavor at level 53.
Learns Cotton Guard at level 61.

-Lilligant
Learns Sleep Powder at level 1.
Learns Stun Spore at level 1. 
Learns Teeter Dance at level 16.
Learns Aromatherapy at level 19.
Learns Giga Drain at level 26.
Learns Quiver Dance at level 28.
Learns Helping Hand at level 35.
Learns Petal Dance at level 46.
Learns After You at level 53.
Learns Leaf Storm at level 61.

-Cincino
Learns Wake-Up Slap at level 34.
Learns Charm at level 40.
Learns Captivate at level 40. 
Learns Hyper Voice at level 45.
Learns Last Resort at level 49.
Learns Encore at level 53.

-Escavalier
Learns Endure at level 1.
Learns Flail at level 1.
Learns Double Edge at level 56.
Now learns Giga Impact at level 60.

-Kling, Klang and Klinklang.
Can now learn Wild Charge by TM.

-Eelektross
Learns Thunderbolt at level 44.
Learns Acid Spray at level 49.
Learns Coil at level 54.
Learns Gastro Acid at level 59.
Learns Zap Cannon at level 64.
Learns Thrash at level 74.

-Chandelure
Learns Memento at level 45.
Learns Curse at level 45.
Learns Shadow Ball at level 53.
Learns Imprison at level 58.
Learns Pain Split at level 61.
Learns Overheat at level 69.
Learns Inferno at level 76.

-Accelgor:
Learns Bide at level 1.
Learns Yawn at level 1.
Learns Guard Swap at level 60.

;;;;;;;Graphical Changes;;;;;;;

-Pokémon Icons seen in the Teams and PC menus have been redesigned to look like animated versions from the ones 
seen in Generation 6-7.
-Battle platforms now use non-animated versions from Pokémon Black 2 and White 2. For the few areas that don't look
1 to 1 to Black and White, those have received new custom ones.
-In-house battles now use a background heavily inspired by Pokémon Black 2 and White 2.
-The Underground 1, Throne Room and Champion areas had their background slightly tweaked.
-Skyla's sprite used in battle has been slighly tweaked to match the rest of her in-game artwork.

;;;;;;;Wild Encounters Changes;;;;;;;

-Version exclusive pokemon from the opposite version -excluding exclusive legendaries- as of version 1.0-
are found in both games but at a lower encounter rate.
-Mienfoo, Pawniard, Rufflet, Vullaby and Deino have a 1% encounter chance to appear in the first areas they show up.
Consequently, their evolved forms can now be caught in the wild in their respective zones.
-Every new encounter change/addition is now visible in the Pokédex's Habitat Function.

--Unovan Additions--

-Servine: 20% encounter rate in Route 12 (shaking grass only, postgame).
-Dewott: 30% encounter rate in Undella Bay save for winter where's only an 1% chance (surfing spots only, postgame).
-Pignite: 20% encounter rate in Challenger's Cave (shaking dust only, postgame).
-Zorua: 10% encounter rate in the Dreamyard.
-Zoroark: 20% encounter rate in Abundant Shrine (shaking grass only).
-Swadloon: 5% encounter rate in Route 6.
-Cubchoo: 10% encounter rate in the Cold Storage.
-Karrablast: 15% encounter rate in Icirrus City, Route 8 and Moor of Icirrus.
-Shelmet: 10% encounter rate in Route 6.
-Heatmor & Durant: 10% encounter rate each in Twist Mountain.
-Thundurus (Black) / Tornadus (White): 30% of the time in Village Bridge (surfing spots only, postgame).
--The version exclusive counterpart has also a 5% chance to be found in those same spots as well.
-Zekrom (Black) / Reshiram (White): 5% encounter rate in Challenger's Cave 3F (shaking dust only, postgame).
-Keldeo: 5% encounter rate in Route 14 (surfing spots only, postgame).
-Meloetta: 5% encounter rate in Village Bridge (shaking grass only, postgame).
-Genesect: 5% encounter rate in Route 15 (shaking grass only, postgame).

--Unovan Changes--

-Golett now replaces Woobat in Victory Road.
-Karrablast no longer appears in Route 11.
-Basculin no longer appears in Route 11 & 14 while surfing.
-Tranquill no longer appears in Route 12.
-Mienfoo/Mienshao no longer appear in Route 14.
-Woobat no longer appears in Challenger's Cave.

--National Dex Additions & Changes--

-Illumise (Black) / Volbeat (White): 10% encounter rate in the Dreamyard Underground.
-Parasect (Black) / Breloom (White): 2% encounter rate in Route 12.
-Mightyena (Black) / Houndoom (White): 5% encounter rate in Route 13.
-Minum (Black) / Plusle (White):  20% of the time in Village Bridge (shaking grass only).

;;;Pokémon families encountered in White Forest can now be found outside it, to account for the likelyhood many 
won't be available by the time the player arrives to it (inaccessible in Black version without Extralink):;;;
--Vigoroth: 2% encounter rate in Dreamyard's exterior (Dark Grass only).
--Gloom: 10% encounter rate in Dreamyard's underground.
--Kadabra & Kirlia: 5% encounter rate each in Dreamyard's underground.
--Corphish: 30% & Crawdaunt: 10% encounter rate in Route 3 when fishing (latter is fishing spots only).
--Trapinch & Haunter: 10% encounter rate in Relic Castle from 6F onwards.
--Lombre & Ludicolo now replace Basculin in Route 11 while surfing (latter is surfing spots only).
--Nuzleaf: 5% encounter rate in Route 11.
--Roselia now replaces Karrablast in Route 11.
--Wurmple: 10% encounter rate in Route 12.
--Skiploom: 5% encounter rate in Route 13.
--Staravia now replaces Mienfoo in Route 14.
--Marril: 9% & Azumarril: 1% encounter rates in Route 14 while surfing.
--Nidorina & Nidorino: 5% encounter rate each in Route 15.
--Rhydon: 10% encounter rate in Route 15.
--Weepinbell: 10% encounter rate in Abundant Shrine.
--Surskit: 60% & Masquerain: 30% encounter rate in Abundant Shrine waters while surfing (latter is surfing spots only).
--Quagsire: 10% encounter rate in Abundant Shrine while surfing.
--Pidgeot: 40% & Togekiss: 10% encounter in the Marvelous Bridge respectively.
--Porygon: 9% encounter rate in Giant Chasm's entrance.
--Chansey: 10% encounter rate in Giant Chasm's 3F (shaking grass only).
--Lairon now replaces Woobat in Challenger's Cave.
--Loudred: 10% encounter rate in Challenger's Cave's 1F.
--Electabuzz & Magmar now replace Sableye and Mawile in Challenger's Cave 2F respectively.
--Shelgon: 5% encounter rate in Challenger's Cave 2F.
--Machoke Replaces Lickitung in Challenger's Cave 3F.
--Magneton Replaces Graveler in Challenger's Cave 3F.

;;;;;;;Pokémart Changes;;;;;;;

* Undella Town's second clerk now sells Cover and Plume Fossils for 7000 pokédollars each.

;;;;;;;Modified Trainers Changes (at least, from what I can remember);;;;;;;

-Team Plasma now uses the Woobat family line.
-Trainers overall use more Pokémon variety and moves to account for the encounter and move changes.
-Notable Gym Changes:
--Trainers from Castelia City's Gym onwards use more Pokémon variety.
--Trainers from Gyms which have fewer families from a certain type now focus on having Pokémon featuring moves
from the Gym's specialized type.
--Gym Leader's teams now follow the Black 2/White 2 healing system in which, in exchange of having only one healing
item (rather than 2 like in Black & White 1), their ace now carries a Sitrus Berry.
---A similar principle is applied to the Elite Four.
--Opelucid City's Gym Leader now uses 4 pokemon.
-Cheren and Bianca now use 5 Pokémon in their last main-story battle.
-The Elite Four now use 5 Pokémon during their first battle.
-The Elite Four and Champion's Pokémon now make noticeably use of Items.

;;;;;;Q&A;;;;;;;

-Where's Victini? Why didn't you add it in a wild area just like the others?

Mostly because he's already catchable in an event-only area that can be accesed by inserting Liberty Ticket's Wondercard manually via PkHex.
For more info in the matter please check the following link: https://projectpokemon.org/tutorials/save-editing/using-pkhex/importing-wondercards-r29/

-Why does this version no longer comes with the anti-piracy patch?
 
* 1. The games don't work on Nintendo DSi-like hardware with it.
* 2. Modern emulators and software from DS/DSi/3DS flashcards already have ways around the game's anti-piracy, so
you shouldn't be able to find any issues playing the game unless what you're playing it on is very outdated.

-I didn't like how you did "X"/ I found an oversight/ there's something it could have been done better.

Feel free to send me a PM. This is my first Pokémon romhack I've publicly released, so any sort of feedback and criticism is highly appreciated.

-So what exactly changed between v1.20 & 1.21?

Well, besides now using properly dumped roms as a base... Staravia previously didn't show up in the Pokédex Area Function. And now it does.

;;;;;;Credits ;;;;;;;

-pleonex, for Tinke 0.9.2.
-SadNES cITy Translations, for xDelta.
-KazoWAR and Kaphotics, for various Pokémon Black & White editing tools.
-Dadaro, for Pokémon Black & White's Shop Editor.
-Andibad, for Pokémon Rom Changer and ANDT.
-RavenDS, for Raven Dex Editor.
-???, for crystaltile2 (let me know if you know their name).
-Gericom, Mario Kart DS Course Modifier (yes, it actually works for non-Mario Kart stuff).
-MrDollSteak & co., for providing the animated sprites.
-...And I guess me (Moltz) for making this romhack???