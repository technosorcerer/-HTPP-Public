--Gyms/E4 additions--

Elesa: Tynamo (replaces one of the Emolgas)
Skyla: Sigyliph
Brycen: Cubchoo
Drayden/Iris: Zweilous & Archeops
Shauntaul: Male Jellicent
Marshal: Scrafty
Grimsley: Mandibuzz
Caitlin: Beheeyem

These new team members are weaker than the respective ace of each trainer.
Their movesets are either copies from each other, based on BW2 or they can be found in their learnset.

--New Encounters--

Zorua (Dreamyard)
Mienshao (Dragonspiral Tower 1F)
Bisharp (Route 9, Double Grass)
Gothorita line & Solosis line (Route 5 and 9)
Braviary & Mandibuzz (Desert Resort, Desert)

These have at least a 10% encounter rate.

Keldeo (Route 14)
Meloetta (Village Bridge)
Genesect (Route 15)

These have a 5% chance in Shaking/Bubbling spots only.

--New Evolution Methods--

Poliwhirl       -> Politoed        by leveling up holding King's Rock
Kadabra         -> Alakazam        at level 37
Machoke         -> Machamp         at level 37
Graveler        -> Golem           at level 37
Slowpoke        -> Slowking        using a Water Stone
Haunter         -> Gengar          at level 37
Onix            -> Steelix         by leveling up holding Metal Coat
Rhydon          -> Rhyperior       by leveling up holding Protector
Seadra          -> Kingdra         by leveling up holding Dragon Scale
Scyther         -> Scizor          by leveling up holding Metal Coat
Electabuzz      -> Electivire      by leveling up holding Electirizer
Magmar          -> Magmortar       by leveling up holding Magmarizer
Porygon         -> Porygon2        by leveling up holding Up-Grade
Porygon2        -> Porygon-Z       by leveling up holding Dubious Disc
Feebas          -> Milotic         by leveling up holding Prism Scale
Dusclops        -> Dusknoir        by leveling up holding Reaper Cloth
Clamperl        -> Huntail         by leveling up holding DeepSeaTooth
Clamperl        -> Gorebyss        by leveling up holding DeepSeaScale
Boldore         -> Gigalith        at level 37
Gurdurr         -> Conkeldurr      at level 37
Karrablast      -> Escavalier      by leveling up with Shelmet in the party
Shelmet         -> Accelgor        by leveling up with Karrablast in the party
Eevee           -> Espeon          using a Sun Stone
Eevee           -> Umbreon         using a Moon Stone
Gligar          -> Gliscor         by leveling up holding Razor Fang
Sneasel         -> Weavile         by leveling up holding Razor Claw
Budew           -> Roselia         by reaching high happiness
Chingling       -> Chimecho        by reaching high happiness
Happiny         -> Chansey         by leveling up holding Oval Stone
Riolu           -> Lucario         by reaching high happiness
