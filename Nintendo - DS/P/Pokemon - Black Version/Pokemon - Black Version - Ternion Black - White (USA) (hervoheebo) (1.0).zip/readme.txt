Pokémon Ternion Black/White is a hack that changes the main battle format used by NPC trainers to Triple Battle. With a few exceptions, normal Single Battles against trainers are now Triple Battles and Double Battles against trainer pairs are now Rotation Battles. The few existing Triple and Rotation Battles in the base game are left unchanged.

The different format creates a cascade of some other necessary changes to follow. Since Triple Battles absolutely require both parties to begin with at least 3 Pokémon, the minimum size of NPC trainer teams is 3. Trainers with larger teams in the base game have more in proportion: 1 becomes 3, 2 becomes 4 and so on. Please always be sure to have at least 3 able Pokémon in your team before challenging any trainer, because the game will crash otherwise. (Game Freak apparently chose to make sure with map scripts that the player cannot enter Double, Triple and Rotation Battles with too few Pokémon rather than fixing the crash itself.)
Care has been taken to give appropriate Pokémon to expand the existing teams. If you see something not quite right like a Gym trainer having a Pokémon of the wrong type, it can be considered a bug.

The base experience given by all Pokémon has been reduced to 0.66 times the original value. As a consequence of the increased NPC team size, you will gain much more experience, and without experience adjustment, quickly begin overpowering the NPC trainers with sheer levels. As a result, wild battles will also give less experience, so this is considered a technical shortcoming. An ideal solution would be to reduce the experience from trainer battles only, but the ability to do that hasn't been found yet.

Lastly, all Ace Trainers and Veterans have custom movesets and sometimes use and have items. This is honestly not a strictly required change, but as the difference in power between an unorganized and organized team in Triples is much more apparent, this bit of customization aims to make these characters a bit more of a threat. Triples is an unforgiving format though, so don't expect to walk away from any trainer battle unscathed.

There are no other changes to the title screen, text, trade evolutions, or anything else. Given BW's identity as a basic and pure game, this hack particularly intends to be a Triple Battle demonstration. Following entries in the Ternion series include a few judicious changes like fixing trade evolutions.

---
Important notes for getting started:
The first battles against Bianca, Cheren and N are still Single Battles as it's either impossible to get a team of 3 before them, or because they're part of the tutorial sequence. The Triple Battles start with the generic trainers after Accumula Town, so be sure to have 3 able Pokémon in your team by then, otherwise the game will crash upon entering battle.

If you lose 2 or 3 Pokémon in a single turn and have trouble replacing them, remember to first select the replacement, then select or tap the fainted first, second or third team member to decide which spot they should take. This awkward procedure is also in the base game where it confused some players.

Patching
The archive includes different ways to patch the hack. It can be applied to Black or White. Firstly, there is a patch for an unmodified English ROM of Black and White. Secondly, there is a patch for English Black and White with a no-exp patch. Lastly, the NARC files are included for manual patching for any other ROM. The extracted ROM has unnamed files in unnamed directories. The included "092" file will therefore replace the file found in the 092 directory and so on.

Known bugs and shortcomings:
-As noted, entering Triple Battles without at least 3 fighting-capable Pokémon will result in a crash.
-Trainer pairs (those that did Double Battles before) have messed up speech bubbles, but don't prevent game progression.
-The Battle Subway and Battle Institute are unchanged because they use a different trainer system that randomizes Pokémon from a pool, and I haven't found anywhere how to change the format - it might be hardcoded.
-Trainers specifically giving less experience would be preferable to reducing the experience given by all Pokémon.

ROM Hashes:

Database match: Pokemon - Black Version (USA, Europe) (NDSi Enhanced)
Database: No-Intro: DS (all) (v. 20210227-111036)
File/ROM SHA-1: 26AD0B9967AA279C4A266EE69F52B9B2332399A5
File/ROM CRC32: 4F6E5580

Database match: Pokemon - White Version (USA, Europe) (NDSi Enhanced)
Database: No-Intro: DS (all) (v. 20210227-111036)
File/ROM SHA-1: BC696A0DFB448C7B3A8A206F0F8214411A039208
File/ROM CRC32: B552501C

No-exp patch ROMs:
Database match: not found
Database: No-Intro: DS (all) (v. 20210227-111036)
File/ROM SHA-1: A4460B1DB943C7D9A685B206EFE567B1314DBEDB
File/ROM CRC32: 433AA9D6

Database match: not found
Database: No-Intro: DS (all) (v. 20210227-111036)
File/ROM SHA-1: 8C2A5EF094D914BC38A1DBC217E2952932B39CD4
File/ROM CRC32: B07ABCA6