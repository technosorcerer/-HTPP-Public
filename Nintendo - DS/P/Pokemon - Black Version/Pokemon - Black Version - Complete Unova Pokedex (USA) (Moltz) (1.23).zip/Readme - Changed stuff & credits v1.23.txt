;;;;;;;;;;;IMPORTANT INFO;;;;;;;;;;;;;
From version 1.21 onwards, the romhack now makes use of a properly dumped rom of Pokémon Black and Pokémon White. Therefore, it's suggested to use the base roms listed (or at least one with the DSi functionality untouched) to avoid running into issues.

;;;;;;;Movepool Changes/Additions;;;;;;;

-Spinarak & Ariados
Can now learn X-Scissor by TM.

-Purrloin & Liepard
Can now learn U-Turn by TM.

-Simisage
Learns Torment at level 25.
Learns Grass Knot at level 31.
Learns Recycle at level 36.
Learns Natural Gift at level 40.
Learns Crunch at level 43.

-Simisear
Learns Amnesia at level 25.
Learns Fire Blast at level 31.
Learns Recycle at level 36.
Learns Natural Gift at level 40.
Learns Crunch at level 43.

-Simipour
Learns Taunt at level 25.
Learns Brine at level 31.
Learns Recycle at level 36.
Learns Natural Gift at level 40.
Learns Crunch at level 43.

-Musharna
Learns Yawn at level 1.
Learns Imprison at level 1.
Learns Nightmare at level 24.
Learns Future Sight at level 31.
Learns Psychic at level 37.
Learns Calm Mind at level 43.
Learns Stored Power at level 47.

-Leavanny
Learns Bug Buzz at level 54.
Learns Flail at level 59.

-Whimsicott
Learns Stun Spore at level 1.
Learns Poison Powder at level 1.
Learns Gust at level 16.
Learns Charm at level 19.
Learns Giga Drain at level 26.
Learns Tailwind at level 28.
Learns Helping Hand at level 35.
Learns Hurricane at level 46.
Learns Endeavor at level 53.
Learns Cotton Guard at level 61.

-Lilligant
Learns Sleep Powder at level 1.
Learns Stun Spore at level 1. 
Learns Teeter Dance at level 16.
Learns Aromatherapy at level 19.
Learns Giga Drain at level 26.
Learns Quiver Dance at level 28.
Learns Helping Hand at level 35.
Learns Petal Dance at level 46.
Learns After You at level 53.
Learns Leaf Storm at level 61.

-Cincino
Learns Wake-Up Slap at level 34.
Learns Charm at level 40.
Learns Captivate at level 40. 
Learns Hyper Voice at level 45.
Learns Last Resort at level 49.
Learns Encore at level 53.

-Escavalier
Learns Endure at level 1.
Learns Flail at level 1.
Learns Double Edge at level 56.
Now learns Giga Impact at level 60.

-Kling, Klang and Klinklang.
Can now learn Wild Charge by TM.

-Eelektross
Learns Thunderbolt at level 44.
Learns Acid Spray at level 49.
Learns Coil at level 54.
Learns Gastro Acid at level 59.
Learns Zap Cannon at level 64.
Learns Thrash at level 74.

-Chandelure
Learns Memento at level 45.
Learns Curse at level 45.
Learns Shadow Ball at level 53.
Learns Imprison at level 58.
Learns Pain Split at level 61.
Learns Overheat at level 69.
Learns Inferno at level 76.

-Beartic
Learns Aqua Jet at level 1.

-Accelgor:
Learns Bide at level 1.
Learns Yawn at level 1.
Learns Guard Swap at level 60.

;;;;;;;Evolution Changes;;;;;;;

-Machoke, Graveler, Kadabra and Haunter can evolve at level 40.
-Poliwhirl and Slowpoke can evolve to Politoed and Slowking respectively by leveling up while holding King's Rock.
-Onix and Scyther can evolve to Steelix and Scizor respectively by leveling up while holding Metal Coat.
-Seadra can evolve to Kingdra by leveling up while holding Dragon Scale.
-Porygon can evolve to Porygon2 evolves by leveling up while holding Upgrade.
--In turn, Porygon2 can evolve to Porygon-Z by leveling up while holding Dubious Disc.
-Electabuzz can evolve to Electivire by leveling up while holding Electirizer.
-Magmar can evolve to Magmortar by leveling up while holding Magmarizer.
-Rhydon can evolve to Rhymperior by leveling up while holding Protector.
-Feebas can evolve to Milotic by leveling up while holding a Prism Scale.
-Dusclops evoles to Dusknoir by leveling up while holding a Reaper Cloth.
-Clamperl evolves to Huntail or Gorebyss by leveling up while holding a DeepSeaTooth or DeepSeaScale respectively.
-Magneton and Nosepass can evolve into Magnezone and Probopass through using a Thunderstone like in Generation 8 onwards. Do note they can still evolve by leveling-up in Chargestone Cave like in the original games.
-Boldore evolves at level 42.
-Gundurr evolves at level 45.
-Karrablast and Shelmet evolve by happiness at any time.

;;;;;;;Graphical Changes;;;;;;;

-Pokémon Icons seen in the Teams and PC menus have been redesigned to look like animated versions from the ones seen in Generation 6-7.
-Battle platforms now use non-animated versions from Pokémon Black 2 and White 2. For the few areas that don't look 1 to 1 to Black and White, those have received new custom ones.
-In-house battles now use a background heavily inspired by Pokémon Black 2 and White 2.
-The Underground 1, Throne Room and Champion areas had their background slightly tweaked.
-Skyla's sprite used in battle has been slightly tweaked to match the rest of her in-game artwork.

;;;;;;;Wild Encounters Changes;;;;;;;

-- OVERALL CHANGES -- 

-Version exclusive Pokémon from the opposite version can now be found in both games but at a lower encounter rate (ie. Solosis is a rare encounter in Black while Gothita is uncommon in White).
-Mienfoo, Pawniard, Rufflet, Vullaby and Deino have a 1% encounter chance to appear in the first areas they show up. Consequently, their evolved forms can now be caught in the wild in their respective zones.
-Every new encounter change/addition is now visible in the Pokédex's Habitat Function.
-Nidorina and Nidoqueen can now breed just like Nidoran Female.
-Various moves had their names tweaked to keep them up to date with Generation 9.
-The rom's size is now about 70% smaller.

-- EXPANDED HABITATS FOR UNOVAN POKÉMON --

-Servine: 20% encounter rate in Route 12 (shaking grass only, postgame).
-Dewott: 30% encounter rate in Undella Bay save for winter where's only an 1% chance (surfing spots only, postgame).
-Pignite: 20% encounter rate in Challenger's Cave (shaking dust only, postgame).
-Zorua: 10% encounter rate in the Dreamyard.
-Zoroark: 20% encounter rate in Abundant Shrine (shaking grass only).
-Swadloon: 5% encounter rate in Route 6.
-Cubchoo: 10% encounter rate in the Cold Storage.
-Karrablast: 15% encounter rate in Icirrus City, Route 8 and Moor of Icirrus.
-Shelmet: 10% encounter rate in Route 6.
-Heatmor & Durant: 10% encounter rate each in Twist Mountain.
-Thundurus (Black) / Tornadus (White): 30% of the time in Village Bridge (surfing spots only, postgame).
--The version exclusive counterpart has also a 5% chance to be found in those same spots as well.
-Zekrom (Black) / Reshiram (White): 5% encounter rate in Challenger's Cave 3F (shaking dust only, postgame).
-Keldeo: 5% encounter rate in Route 14 (surfing spots only, postgame).
-Meloetta: 5% encounter rate in Village Bridge (shaking grass only, postgame).
-Genesect: 5% encounter rate in Route 15 (shaking grass only, postgame).

-- LOCATION CHANGES --

-Golett now replaces Woobat in Victory Road.
-Karrablast no longer appears in Route 11.
-Basculin no longer appears in Route 11 & 14 while surfing.
-Tranquill no longer appears in Route 12.
-Mienfoo/Mienshao no longer appear in Route 14.
-Woobat no longer appears in Challenger's Cave.

4.4 -- NATIONAL DEX ADDITIONS & CHANGES --

-Illumise (Black) / Volbeat (White): 10% encounter rate in the Dreamyard Underground.
-Parasect (Black) / Breloom (White): 2% encounter rate in Route 12.
-Mightyena (Black) / Houndoom (White): 5% encounter rate in Route 13.
-Minum (Black) / Plusle (White): 20% of the time in Village Bridge (shaking grass only).

--Vigoroth: 2% encounter rate in Dreamyard's exterior (Dark Grass only).
--Gloom: 10% encounter rate in Dreamyard's underground.
--Kadabra & Kirlia: 5% encounter rate each in Dreamyard's underground.
--Corphish: 30% & Crawdaunt: 10% encounter rate in Route 3 when fishing (latter is fishing spots only).
--Trapinch & Haunter: 10% encounter rate in Relic Castle from 6F onwards.
--Lombre & Ludicolo now replace Basculin in Route 11 while surfing (latter is surfing spots only).
--Nuzleaf: 5% encounter rate in Route 11.
--Roselia now replaces Karrablast in Route 11.
--Wurmple: 10% encounter rate in Route 12.
--Skiploom: 5% encounter rate in Route 13.
--Staravia now replaces Mienfoo in Route 14.
--Marril: 9% & Azumarril: 1% encounter rates in Route 14 while surfing.
--Nidorina & Nidorino: 5% encounter rate each in Route 15.
--Rhydon: 10% encounter rate in Route 15.
--Weepinbell: 10% encounter rate in Abundant Shrine.
--Surskit: 60% & Masquerain: 30% encounter rate in Abundant Shrine waters while surfing (latter is surfing spots only).
--Quagsire: 10% encounter rate in Abundant Shrine while surfing.
--Pidgeot: 40% & Togekiss: 10% encounter in the Marvelous Bridge respectively.
--Porygon: 9% encounter rate in Giant Chasm's entrance.
--Chansey: 10% encounter rate in Giant Chasm's 3F (shaking grass only).
--Lairon now replaces Woobat in Challenger's Cave.
--Loudred: 10% encounter rate in Challenger's Cave's 1F.
--Electabuzz & Magmar now replace Sableye and Mawile in Challenger's Cave 2F respectively.
--Shelgon: 5% encounter rate in Challenger's Cave 2F.
--Machoke Replaces Lickitung in Challenger's Cave 3F.
--Magneton Replaces Graveler in Challenger's Cave 3F.

;;;;;;;Pokémart Changes;;;;;;;

* Undella Town's second clerk now sells Cover and Plume Fossils for 7000 pokédollars each.

;;;;;;;Modified Trainers Changes (at least, from what I can remember);;;;;;;

-Team Plasma now uses the Woobat family line.
-Trainers overall use more Pokémon variety and moves to account for the encounter and move changes.
-Notable Gym Changes:
--Trainers from Castelia City's Gym onwards use more Pokémon variety.
--Trainers from Gyms which have fewer families from a certain type now focus on having Pokémon featuring moves
from the Gym's specialized type.
--Gym Leader's teams now follow the Black 2/White 2 healing system in which, in exchange of having only one healing
item (rather than 2 like in Black & White 1), their ace now carries a Sitrus Berry.
---A similar principle is applied to the Elite Four.
--Opelucid City's Gym Leader now uses 4 pokemon.
-Cheren and Bianca now use 5 Pokémon in their last main-story battle.
-The Elite Four now use 5 Pokémon during their first battle.
-The Elite Four and Champion's Pokémon now make noticeably use of Items.

;;;;;;Q&A;;;;;;;

--Q:How many Pokémon can you catch overall? 

A: Somewhere aroun 416 Pokémon, considering the hack allows you to get Keldeo, Meloetta & Genesect and all the version-exclusive mons in one game.

--Q:Where's Victini? Why didn't you add it in a wild area just like the others?

A: Mostly because he's already catchable in an event-only area that can be accesed by inserting Liberty Ticket's Wondercard manually via PkHex.
For more info in the matter please check the following link: https://projectpokemon.org/tutorials/save-editing/using-pkhex/importing-wondercards-r29/
That being said, I'm looking into implementing the event without requiring any sort of Wonder Trades in the near future...

--Q: Is this hack compatible with vanilla Pokémon Black and White saves?

A: Yep. Just make sure they have the game's save file is the exact one the rom uses and it should load it with no issues as long its also an EN version save file.

--Q: How do I know the patch did anything to my game?

A: Check the lower half of the game's Title Screen. If on the bottom left side it says "Complete Unova Pokédex 1.X" (X being the version number), then the patch worked as intended.

--Q: I didn't like how you did "X"/ I found an oversight/ there's something it could have been done better/a battle triggered a blue screen of death/my Pokémon can't gain EXP for some reason/and more.

A: Feel free to send me a PM. This is my first Pokémon romhack I've released, so any sort of feedback and criticism is highly appreciated.

;;;;;;Credits ;;;;;;;

-pleonex, for TinkeDSi 0.9.3.
-SadNES cITy Translations, for xDelta.
-KazoWAR and Kaphotics, for various Pokémon Black & White editing tools.
-Dadaro, for Pokémon Black & White's Shop Editor.
-Andibad, for Pokémon Rom Changer and ANDT.
-RavenDS, for Raven Dex Editor.
-???, for crystaltile2 (let me know if you know their name).
-Gericom, Mario Kart DS Course Modifier (yes, it actually works for non-Mario Kart stuff).
-MrDollSteak & co., for providing the animated sprites.
-Frost for FrostsGen5 Editor.
-...And I guess me (Moltz) for making this romhack???