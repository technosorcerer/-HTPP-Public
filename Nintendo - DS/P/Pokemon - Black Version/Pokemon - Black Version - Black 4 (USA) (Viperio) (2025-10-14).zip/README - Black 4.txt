Black 4

- All gen 5 Pokémon have been replaced by gen 4 Pokémon, or pre-evolutions / split evos from gen 4 Pokémon (e.g. Magmar, Gardevoir).
- The shiny odds have been increased to ~1/255.