Pokémon Ternion Black 2/White 2 is a hack that changes the main battle format used by NPC trainers to Triple Battle. With a few exceptions, normal Single Battles against trainers are now Triple Battles and Double Battles against trainer pairs are now Rotation Battles. The few existing Triple and Rotation Battles in the base game are left unchanged.

The different format creates a cascade of some other necessary changes to follow. Since Triple Battles absolutely require both parties to begin with at least 3 Pokémon, the minimum size of NPC trainer teams is 3. Trainers with larger teams in the base game have more in proportion: 1 becomes 3, 2 becomes 4 and so on. Please always be sure to have at least 3 able Pokémon in your team before challenging any trainer, because the game will crash otherwise. (Game Freak apparently chose to make sure with map scripts that the player cannot enter Double, Triple and Rotation Battles with too few Pokémon rather than fixing the crash itself.)
Care has been taken to give appropriate Pokémon to expand the existing teams. If you see something not quite right like a Gym trainer having a Pokémon of the wrong type, it can be considered a bug.

The base experience given by all Pokémon has been reduced to 0.66 times the original value. As a consequence of the increased NPC team size, you will gain much more experience, and without experience adjustment, quickly begin overpowering the NPC trainers with sheer levels. As a result, wild battles will also give less experience, so this is considered a technical shortcoming. An ideal solution would be to reduce the experience from trainer battles only, but the ability to do that hasn't been found yet.

All Ace Trainers and Veterans have custom movesets and sometimes use and have items. This is honestly not a strictly required change, but as the difference in power between an unorganized and organized team in Triples is much more apparent, this bit of customization aims to make these characters a bit more of a threat. Triples is an unforgiving format though, so don't expect to walk away from any trainer battle unscathed.

Compared to the first entry, Ternion Black/White, there are a few additional changes. Pokémon evolving via trading will also evolve under similar conditions by level-up. For example, those evolving via trading only such as Haunter will also evolve after reaching a certain level. Those evolving via trading while holding a specific item will also evolve by leveling up while holding that item. Karrablast and Shelmet evolve by level-up while their counterpart is in the party. Since in these games it's possible to trade with other players anywhere by infrared, these new methods in fact don't affect game balance from a logical/theoretical standpoint.

A few TMs previously available from BP purchase only can now be bought from the Driftveil PokéMart for 10000 apiece: Quash, Ally Switch and Protect, which was available in Ternion Black/White from the professor after registering a certain amount of Pokémon to the Pokédex. Protect is not necessary, but hugely useful and opens up a large amount of additional plays in Triples, so this was felt to be a necessary change. Not making Ally Switch more freely available would be a huge missed opportunity, and Quash is a very obscure move that for sure would not see any use were it only available from BP. Other attempts to make these TMs available would be to swap them with some other overworld/purchasable TMs, or increase the amount of BP gained from the early tournaments, or lowering their BP cost to 1, but these attempts were unsuccessful, so for now they are simply purchasable for money.

Lastly, rocks were removed from a section of the river in Route 14 to allow access to the Abundant Shrine without Waterfall. The wild Pokémon and trainer levels in this area are actually already appropriate in the base game, and by the time you get Waterfall naturally, they are low in level compared to you. The real reason for this change is to allow earlier access to the Trick Room TM, a move of theoretically high potential in other formats, but formidable in Triples since each turn has many more potential actions.

Unova's Challenge (Black Tower and White Treehollow) regular trainers are unchanged. This is considered a technical shortcoming, as they seem to use the same unknown mechanic for setting the format as the Battle Subway and Battle Institute. Only the boss trainers are defined normally, and their format has been changed to Triple Battle. Many attempts were made to investigate the Unova's Challenge trainer system but all were unsuccessful.

---
Important notes for getting started:
The first battle against your rival is still a Single Battle as it's impossible to get a team of 3 before it. The Triple Battles start with the generic trainers of Route 20, so be sure to have 3 able Pokémon in your team by then, otherwise the game will crash upon entering battle.

If you lose 2 or 3 Pokémon in a single turn and have trouble replacing them, remember to first select the replacement, then select or tap the fainted first, second or third team member to decide which spot they should take. This awkward procedure is also in the base game where it confused some players.

Patching
The hack can be patched to the specified English Black 2 or White 2 ROMs. The NARC files are also included for manual patching for any other ROM. The extracted ROM has unnamed files in unnamed directories. The included "091" file will therefore replace the file found in the 091 directory and so on.

Known bugs and shortcomings:
-As noted, entering Triple Battles without at least 3 fighting-capable Pokémon will result in a crash.
-Trainer pairs (those that did Double Battles before) have messed up speech bubbles, but don't prevent game progression.
-Unova's Challenge, the Battle Subway and Battle Institute are unchanged because they use a different trainer system that randomizes Pokémon from a pool, and attempts to change the format have been unsuccessful - it might be hardcoded.
-Trainers specifically giving less experience would be preferable to reducing the experience given by all Pokémon.
-Multi Battles against Team Plasma have rarely been observed to crash the game, but this is possibly an emulator bug, using DraStic.

Database match: Pokemon - Black Version 2 (USA, Europe) (NDSi Enhanced)
Database: No-Intro: DS (all) (v. 20210227-111036)
File/ROM SHA-1: E51E6DFB8678A3D19DCD2A10691B96A569CA0ABB
File/ROM CRC32: D4427FD1

Database match: Pokemon - White Version 2 (USA, Europe) (NDSi Enhanced)
Database: No-Intro: DS (all) (v. 20210227-111036)
File/ROM SHA-1: B5D7490BE7B415B8F1E672A53E978A9CC667E56A
File/ROM CRC32: 777EB04F
