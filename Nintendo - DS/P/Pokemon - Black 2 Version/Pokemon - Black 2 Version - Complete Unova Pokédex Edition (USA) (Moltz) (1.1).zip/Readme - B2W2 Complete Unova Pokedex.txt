;;;;;;;;;;;;;MAIN README;;;;;;;;;;;;;;;
;;;;;;Pokémon Black 2 and White 2;;;;;;
;;;;;Complete Unova Pokedex V. 1.1;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

This romhack makes use of a properly dumped rom of Pokémon Black 2 and Pokémon White 2. Therefore, it's suggested to use the base roms listed (or at least one with the DSi functionality untouched) to avoid running into issues:

----

Pokemon - Black Version 2 (USA, Europe) (NDSi Enhanced)
Database: No-Intro: DS (all) (v. 20210227-111036)
File/ROM SHA-1: E51E6DFB8678A3D19DCD2A10691B96A569CA0ABB
File/ROM CRC32: D4427FD1

----

Pokemon - White Version 2 (USA, Europe) (NDSi Enhanced)
Database: No-Intro: DS (all) (v. 20210227-111036)
File/ROM SHA-1: B5D7490BE7B415B8F1E672A53E978A9CC667E56A
File/ROM CRC32: 777EB04F

----

You can check whether or not you're using the correct rom with this online tool: https://www.romhacking.net/hash/

As for how to use this patch, look for a tool called Xdelta patcher. There should be an online version available as well.

;;;;;;;Evolution Changes;;;;;;;

-Machoke, Graveler, Kadabra and Haunter can evolve at level 40.
-Poliwhirl and Slowpoke can evolve to Politoed and Slowking respectively by leveling up while holding King's Rock.
-Onix and Scyther can evolve to Steelix and Scizor respectively by leveling up while holding Metal Coat.
-Seadra can evolve to Kingdra by leveling up while holding Dragon Scale.
-Porygon can evolve to Porygon2 evolves by leveling up while holding Upgrade.
--In turn, Porygon2 can evolve to Porygon-Z by leveling up while holding Dubious Disc.
-Electabuzz can evolve to Electivire by leveling up while holding Electirizer.
-Magmar can evolve to Magmortar by leveling up while holding Magmarizer.
-Rhydon can evolve to Rhymperior by leveling up while holding Protector.
-Eevee evolves to Leafeon and Glaceon through using a Leaf Stone and Dawn Stone respectively, not unlike Generation 8 onwards (getting Glaceon requires a different stone in those games though. I ain't adding the Ice Stone just for it).
-Feebas can evolve to Milotic by leveling up while holding a Prism Scale.
-Dusclops evoles to Dusknoir by leveling up while holding a Reaper Cloth.
-Clamperl evolves to Huntail or Gorebyss by leveling up while holding a DeepSeaTooth or DeepSeaScale respectively.
-Magneton and Nosepass can evolve into Magnezone and Probopass through using a Thunderstone like in Generation 8 onwards. Do note they can still evolve by leveling-up in Chargestone Cave like in the original games.
-Boldore evolves at level 42.
-Gundurr evolves at level 45.
-Karrablast and Shelmet evolve by happiness at any time.

NOTE: Sans Eevee evolving to Leafeon/Glaceon, the original evolving method for all the Pokémon listed above is still present in the game's data.

;;;;;;;Graphical Changes;;;;;;;

-Pokémon Icons seen in the Teams and PC menus have been redesigned to look like animated versions from the ones featured in Generation 6-7.
-Colress' third and fourth battles now use a different battle background.
-The battle background of N's Castle now uses a new model for its battle platform.
-Skyla's graphics are now consistent across all her in-game appearances. Incidentally, an animation error involving her battle sprite has been fixed.

;;;;;;;Moveset Changes;;;;;;;;;
-Overall, Pokémon who evolve by Stone Evolutions now have access to moves normally exclusive to their pre-evolutions, learning them at a later time.
--This includes as exceptions Escavalier, Accelgor, and Kyurem.

For more details, check the detailed .txt file detailing all the additions and changes.

;;;;;;;Wild Encounters Changes As a Whole;;;;;;;

-Version exclusive Pokémon from the opposite version can now be found in both games but at a lower encounter rate (ie. Solosis is a rare encounter in Black while Gothita is uncommon in White).
-Mienshao, Bisharp, Braviary and Mandibuzz now replace Mienfoo, Pawniard, Rufflet, Vullaby in the wild.
-Every new encounter change/addition/removal is now visible in the Pokédex's Area and Habitat Functions.

For more details, check the detailed .txt file detailing all the additions and changes.

;;;;;;;Modified Trainer Changes & Other (from what I can recall);;;;;;;

* A few minor trainers' teams have received slight tweaks, mainly to account availability changes and Pokémon members added to major story battles.
** I believe a few important ones had one or two moves swapped, but I can't recall which ones exactly right now.
* Humilau City's Gym Leader now uses 4 Pokémon in Easy/Normal mode, and 5 in Hard Mode.
* The Elite 4 now uses 5 Pokémon in Easy/Normal mode, and 6 in Hard Mode.
* The main story fight against Kyurem has been increased in difficulty.
** This also impacts Kyurem's moveset once it becomes available for capture later.
* Hugh now uses 4 Pokémon in 4th fight, and 5 in his last main-story fight.
* Fixed an oversight where Marshal's Conkeldurr's in his second fight uses Sheer Force rather than Guts (Hard Mode only).

;;;;;;;Misc. Changes;;;;;;;

* Nidorina and Nidoqueen can now breed just like Nidoran Female.
* Magby and Elekid have a 5% of having a Magmarizer/Electirizer with them respectively on the wild.
* Nacrene City's second clerk now sells Cover and Plume Fossils for 7000 pokédollars each.
* It's possible to obtain the Reveal Glass without a Landorus-Therian that came from Pokémon Dream Radar. Bringing any Landorus-Therian to the shrine in Abundant Shrine (after seeing the credits once) should be enough.
* It's possible to gain access to the Iceberg Chamber (Black2)/Iron Chamber (White2) after capturing Registeel/Regice in Black 2/White 2 respectively.
* Various moves had their names tweaked to keep them up to date with Generation 9.
* All Difficulty and Area Keys are now unlocked from the start. No extra event/NPC required.
* Easy and Challenge Mode now fully work as intended. Check the update log for more details on it.

;;;;;;Q&A;;;;;;;

--Q: Is Easy/Hard Mode available in both versions without needing to finish the game like in vanilla?
----------------------------------------------------------------------------------------------------
A: Yep. An oversight involving both has also been fixed, so have fun!

--Q: Why is Eevee the only Pokémon which loses its old evolution conditions when evolving into Leafeon/Glaceon? 
---------------------------------------------------------------------------------------------------------------
A: Internally, each Pokémon has a limited entry number for potential evolutions (ie. 7). Due to Eevee having filled its entries completely, I was forced to make the compromise.

--Q: The Dawn Stone isn't available in Black 2 and White 2 up until postgame (outside of dust clouds which drop items at random). How am I supposed to get Glaceon before then?
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
A: A Dawn Stone has been added in Route 16. As long you can use Strength, you should be able to obtain it.

--Q: The Pokédex thinks the Habitat in some areas is complete even though [Victini/Keldeo/Meloetta/Genesect] hasn't been seen yet. Is it a bug?
----------------------------------------------------------------------------------------------------------------------------------------------
A: Surprisingly, no! Mythical Pokémon are not required to complete neither the Unova nor National dex due to their normally-limited availability. So that quirk's a side effect of that.

--Q: Does this hack patches the game's anti-piracy measures?
 ----------------------------------------------------------
A: Nope. I decided against it for 2 reasons:
* 1. The games don't work on Nintendo DSi-like hardware with it.
* 2. Modern emulators and software from DS/DSi/3DS flashcards already have ways around the game's anti-piracy, so you shouldn't be able to find any issues playing the game unless what you're playing it on is very outdated.

--Q: I'm trying to run the game on TwilightMenu++ but I'm running into issues, such as my Pokémon not gaining EXP or experiencing crashes. Is there a way to fix that?
----------------------------------------------------------------------------------------------------------------------------------------------------------------------
A: Yep:
* 1. Get the game's Anti-Piracy (AP) patch and apply it to the base rom of Black 2/White 2. 
* 2. Then, patch that rom with the Complete Unova Pokédex patch.

--Q: Is this hack compatible with vanilla Pokémon Black 2 and White 2 saves?
---------------------------------------------------------------------------
A: Yep. Just make sure they have the game's save file is the exact one the rom uses and it should load it with no issues as long its also an EN version save file. Also, doing so automatically unlocks all locked difficulties/areas present within the game's Key system.

--Q: How do I know the patch did anything to my game?
----------------------------------------------------
A: Check the lower half of the game's Title Screen. If on the bottom left side it says "Complete Unova Pokédex 1.X" (X being the version number), then the patch worked as intended.

--Q: Think you could have shared more precise encounter rates for all the Pokémon? Just flat percentages isn't enough for me...
------------------------------------------------------------------------------------------------------------------------------
A: My original idea was to do exactly just that, actually! But then I set a specific date to release this romhack and I was unable to document that on time, so... expect proper documentation in a nearby future.

--Q: I didn't like how you did "X"/ I found an oversight/ there's something it could have been done better/a battle triggered a "blue screen of death"/my Pokémon can't gain EXP for some reason/etc.
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
A: Feel free to send me a PM or contact me (I go by Moltz20 on bluesky). Any sort of feedback and criticism is highly appreciated.


;;;;;UPDATE LOG;;;;;;

Version 1.1
* Implemented a patch that automatically makes available all difficulty modes and areas locked behind the game's Key System, version exclusivity be damned.
* Fixed an oversight where Black 2 and White 2's Easy/Challenge Modes didn't lower/raise the stats of the enemy trainer's Pokémon (ie. their levels were previously indicative of their enemy AI, moveset changes and sometimes IVs than anything else).
* Fixed a few transparency issues involving the new Icon Sprites for Zubat, Banette, and Skorupi.

Version 1.01
* Regice & Registeel are now obtainable in Black 2 and White 2 without save editing. Capturing Registeel in Black 2 now unlocks the Iceberg Chamber, while capturing Regice in White 2 allows access to the Iron Chamber.

Version 1.00
* First release.

;;;;;;Credits ;;;;;;;

-pleonex, for TinkeDSi 0.9.3.
-SadNES cITy Translations, for xDelta.
-KazoWAR and Kaphotics, for various Pokémon Black & White editing tools.
-Andibad, for Pokémon Rom Changer and ANDT.
-RavenDS, for Raven Dex Editor.
-???, for crystaltile2 (let me know if you know their name).
-Gericom, Mario Kart DS Course Modifier (yes, it actually works for non-Mario Kart stuff).
-MrDollSteak & co., for providing the animated gen 6-styled icon sprites.
-hzla, for Pokeweb.
-Frost for FrostsGen5 Editor.
-shogokawadafan_76995, for helping me implement the patch that makes all Key and Difficulty modes available in the games.
-DaSquyd, for figuring out a fix for the Easy/Challenge Mode level/stat discrepancy in Enemy Trainers' Pokémon.
-...And I guess me (Moltz) for making this romhack???