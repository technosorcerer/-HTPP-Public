READ ME Version 1.2

=================
TABLE OF CONTENTS
=================

1.Intro
2.How to patch
3.Known problems
4.Hints & tips
5.Best way to play the hack.
6.Credits
7.Changelog



----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

1.Intro

First of all, thanks for downloading this hack!

This patch will replace the NSMB levels with all the levels of "Super Mario Bros.1" (1985) from the NES and "Super Mario Bros. 2/The Lost Levels" (1986) From the FDS,
As well with bonus custom areas + extras. 

The original levels have been done exactly as their NES/FDS counterparts, so you get to play the original levels as they are. To add more content, the first 5 worlds
+ certain levels from world 7 (and one from W6) have been expanded with custom areas,that holds the starcoins and the routes to the secret exit that opens new paths in the world map.
This new areas includes new challenges, and some are modeled after the SMB1 level style, but the true challenge is, can you find all the starcoins?



----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

2.How to patch

Here is an detailed way on how to patch with the Xdelta program included in the pack.
Please have in mind that you will need the (U) [USA] version of the ROM!

 1. Find a NSMB ROM. (Dont ask where to get one)

 2. The ROM must be the (U) Version of the game!, the others won't work. 

 3. Extract all the files from the pack.

 4. Just in case, move the ROM in the same folder where the patch and xdelta is!

 5. Open "xdeltaUI.exe" (the location of the "xdelta.exe" MUST BE in the SAME LOCATION where the "xdeltaUI.exe" is)

 6. Remember, we want to patch the rom, so we have to click on the tab "Apply Patch" (It should be marked in the default setting)

 7. You will see 3 empty boxes with 3 buttons to the right from each of them. (1. box - Patch, 2. box - Source File, 3. box - Output File)

 8. Click on the first button "Open", right of the "Patch"-box. A new window will open.

 9. Search for the xdelta-patch now and double click on "New Super Mario Bros. Deluxe!.xdelta" (the 1. box will now show the directory of the patch)

10. Now to the second button, click "Open" right of the "Source File"-box and search for the "clean, not trimmed" ROM. (Remember! Only the (U) version will work! If you dont use the correct ROM, you will get the "Target cheksum mismatch" error)

11. And at last, the third button! Click on "..." right of the "Target File" box and choose a place to save the patched file.

12. After saving the new file, it wont have an extension. You will need to right mouse click on the file and press "rename".

13. You have to add ".nds" at the end of the filename [Example: after saving "NSMBDX", rename to "NSMBDX.nds"]

14. The game is now successfully patched!

15. Get it on your flashcard or use an emulator to play the game! Enjoy!

(NOTE: Avoid using ROMs that have some kind of name after the version. [like: New super mario bros. (U)(xxxxx) This are usually trimmed/modified rom. Only try to use them if you cant get other ROM you got to work, and for the record, the source
file I used to create the patch weights 13.7MB when it is compressed/the weight of the .rar file containing the rom, so something between that range should work)



----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

3.Known problems.

Every game does not comes without its flaws. 

The main problem you will see is that you can see "mario's feet" when exiting/entering 2 height warp pipes. This is a layer issue that cannot be fixed without ASM hacks.
A workaround would be to extend the pipe further, but this would take the feeling of the original games, so I did not do this.

On most levels, when you appear on the midway/checkpoint part of the level, on some cases there might be some enemies near mario. You have 3 ingame seconds on most cases to react, so please watch out for this. I cant do nothing on this because
SMB1 includes a flag that removes the enemies on the screen you appear.

The levels arent played in the exact order they appear in the games. Only the first world fulfill this (to some extent) Generally, you play first the SMB1 levels and then TLL levels. I had to do this because of limited areas. You can spot
which level is from a game by the graphics used ;)

The main thing you will notice is the "flying fish" arent flying at all. Unfortunately, NSMB does not includes this type of fish. While they DO include a JUMPING fish, this jumping fish wont
work WITHOUT the water/lava that spawns all over the level (and doesnt jump high enough). Meaning that if I use the water/lava, this would modify the original level and wont look good, so the "floating
fish" are the replacement for the flying fish. Sorry about that!

There is no "powerup/powerdown" that kills mario, so the poison mushroom has been replaced with the "mini mushroom". While its not the same, some people dont like playing around with the mini
mario physics, so it kinda fullfills its role to be "avoided"

Is not possible to add bowser at the last part of each castle. The bowser in the first world castle boss is too big to fit in the original area, so instead, the fire/hammer bros. replace him there.

The undeground bonus section of the original levels might not be in an underground theme for some levels. This is because NSMB levels have predetermined areas, which cant be added/removed, which means 
only 1 theme can be used per area.

In the overworld, the text box is too bright. I dont know the cause of this, so I cant fix it. Still, the text is still readable. (for the most part)

C-3 from TLL is not included. Why? I am out of level slots for more free levels. I had 2 options. Include either C-3 or C-4. This levels are exactly like 7-3 and 7-4, except with minor modifications.
I took out C-3 because it only adds a lakitu at the first part of the level. Usually, since you were in the air, it would be a pointless enemy, and C-4 atleast has a really noticeable change.

If you use cheat codes, they can corrupt/mess up the save file and in-game gameplay, so use them at your own risk!

When using the Mega-Mushroom in some levels, you might break off some objects, which will make the sceneary seem like cut. I cant fix this. In some cases, I have added an unbreakable block to prevent this cutout, so when using the mega mushroom,
watch out for sceneary covered by a block, since this cant be destroyed!

The ending pictures have been modified. This leads to an odd problem that I cant fix ATM. This bug, AFAIK, only shows up once you 100% the game. THe bug is that some pictures will be discolred to red, and have some kind of "NEW" mark at the 
corner. I did located the file to this, but its not possible to edit it as of now.
The last fight with bowser jr. has rising lava. You can defeat it normally with no ground pounds, but the lava will continue rising, to the point it will cover mario, but he wont die.

The lakitu's in world 9 underwater areas doenst work. This is because the game handles the spiny enemies differently when touching water, and since the whole area is underwater, the spiny's wont spawn at all.

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

4. Hints & Tips.

As I mentioned, the first 5 worlds have custom areas HIDDEN, so how do you find them?
Here is a hint of the methods to find them:

-On most levels, a pipe from the original level layout will take you to the custom area.
-Some levels have an "invisible vine block", so if you cant find any normal entrance to it, be sure to search the level for this invisible block.
-Certain level type have walkable walls that look like normal solid blocks, but the entrance is marked by some sort of "different" block.
-There is only 1 level in which you have to fall in a harmless 1x1 block. Ill let you figure out which level is ;)


*Some Starcoins will appear encased in solid blocks. If you cant find a way to destroy the surrounding blocks, be sure to kill all the enemies near the area where the encased starcoin is.
*All the levels that have a secret path in the original NSMB still have them. The secret exit flag (or the path to it) may be hidden in this custom areas.
*Mini Mario gets launched way farther by the Pipe-Cannon than normal mario does.
*The warpzones of the original levels are there. The entrances to them are hidden in the custom areas. Usually the original warpzone pipe will exit you near the entrances to the warpzone cannons ;)


---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

5. Best way to play the hack

Really, the best way to play the hack is on a REAL DS with a flashcard. This hack was tested on a TTDS, so in theory, it should work on all the others.

If you dont have a way to play on the DS, you then will need to play on an emulator.

-For people that have High-End PCs, DESmuME emulator would be the best choice.

-for people with Mid-end PCs, you might want to try this JIT recompiled DESmuME. Its faster than the normal one.
 Link for the JIT DESmuME:
 http://www.emucr.com/2012/05/desmume-jit-svn-r4287.html?m=1
 (NOTE: that version is a somewhat old revision, but it plays fine with NSMB) 
 If you Still have lag and framerate issues, read below.

-For people with Low-End PCs, try the above version of DESmuME with this settings that will greatly improve speed:

1. Open the Emulator.
2. Click the "Config" tab.
3. Select "Emulation Settings"
4. Disable the "Advanced Bus-Level timing" checkbox.
5. Enable the "Patch DelayLoop SWI (speed hack)" checkbox, then click on OK.
6. Click again the "config" tab.
7. Select "Frame Skip", and set it to 4. (you can try to use other numbers to see which it fits better for you)
8. You're done! Emulation should be faster by now!

-If the above methods doesnt work for you, and DESmuME still lags for you, then you need to use NO$GBA DS emulator. Use this as your last resort. Even if NO$GBA is faster,
It cant display some things from the game like the water and some effects, so I do not recommend playing the hack with that.



------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------



6. Credits

=================================================================

Main credits goes for Nintendo for creating New Super Mario Bros.

=================================================================

NSMBEditor:
-Treeki
-Dirbaio
-Piranhaplant

Hack by:
-Gridatttack

Boxart & icon:
-Sonictopfan/juiceala

Logo:
-Twiztidsinz

Beta Testing:
-Friedslick6
-Juiceala/Sonictopfan
-Garmichael

Misc.
-SKJmin
-Heartgold99
-TTower11
-MarioMaster
-Fr33ze


For more mario games hack, go to my youtube channel ;)
www.youtube.com/user/gridatttack

7. Changelog
v1.2
-Included HD boxart.
-Fixed the ROM icon cheksum, so now it should work on all carts.

v1.1
-Fixed 1-1 issues.
-Fixed 1-3 broken warp.
