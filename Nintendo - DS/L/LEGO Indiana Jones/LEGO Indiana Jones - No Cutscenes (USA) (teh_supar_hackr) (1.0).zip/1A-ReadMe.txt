Created by teh_supar_hackr

This rom hack does one thing, skips all of the FMV cutscenes. Oh and it also cuts the rom file size from the original 64MB to 35.2MB. How this was done was by replacing all of the video files with a blank bik file that makes it skip straight to the gameplay.

This hack uses xDelta to patch the NTST-U version of the game. Tested in MelonDS, and DesMuMe and works as it should. It should also work on real hardware via a flash cart. 