This is a port of "OEA All-in-One" from RHDN. However, as implied by the "Redux" moniker, I took the occasion to spiff a few things up.

As before, this hack combines the following hacks:
- Plantations No More (Plantation is renamed)
- Gemma On The Title Screen (Gemma is on the title screen instead of Biff, and she comes before Biff in the shop’s list of units)
- Dogistador (The Conquistador is replaced with the unused sprite of a wolf/dog)
- All Maps Early (All maps can be played in Freeplay etc. without buying them in the shop)
I was going to get rid of All Maps Early, but then messing with Entities.ebp made the Astronaut missions crash, so here we are.

Additionally, the renamings have been changed, now that I have a proper text editor that can handle various string lengths. Specifically,
"Plantation" now becomes "Cache" instead of "Storehouse", and "Conquistador" becomes "Wolf" instead of "Ancient Wolf".

Finally, using some Google-fu I applied these renaming changes to the French and Spanish translations as well. You can find the list of
translations in the file "Translations.txt"; please let me know if there are any errors.