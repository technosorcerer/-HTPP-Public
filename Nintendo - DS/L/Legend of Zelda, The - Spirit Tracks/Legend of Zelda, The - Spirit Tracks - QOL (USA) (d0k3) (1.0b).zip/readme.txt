The Legend of Zelda
Spirit Tracks
QoL Hack v1.0b
by d0k3 (2024)



PREAMBLE
During a recent playthrough of Spirit Tracks, I couldn’t help but notice how certain parts of the game were quite frustrating. In search of a solution, I turned to Action Replay cheats. However, not all of them worked as expected, and none aligned with the experience I was aiming for — something that would make the more tedious sections more enjoyable without feeling like outright cheating. This led me to experiment with improving existing cheats, delving into how Action Replay codes function (it’s essentially a programming language), and before long, I was deep in that rabbit hole.

The result of my efforts is this patch, which I’m sharing with the world, in the hope that it will enhance future playthroughs for other Zelda fans.


INSTRUCTIONS
You need one of these two game dumps and a BPS compatible patching tool.

Legend of Zelda, The - Spirit Tracks (Europe) (En,Fr,De,Es,It) (Rev 1).nds
CRC-32: 4F9E66F0
MD-5: B822BC0934831E971C4AC2F8B1AB4194
Patch file: loz_st_qol-1.0b-e.bps

Legend of Zelda, The - Spirit Tracks (USA) (En,Fr,Es) (Rev 1).nds
CRC-32: 319A13E5
MD-5: 10A88D4359A1C02E67A6070AB2730407
Patch file: loz_st_qol-1.0b-u.bps

If you need a BPS compatible patching tool, use this one:
https://www.marcrobledo.com/RomPatcher.js/

Instead of patching your game dump, you may also just use the included Action Replay .cht files with your emulator or flash card for the same effects.


CONTROLS
This is what you can do with this romhack.

Train Overdrive Mod:
-> 2nd gear speed is 1.5x faster than original
-> Reverse speed is 1.5x faster than original
-> Press and hold L or R for BOOST MODE (4x original speed)
-> For 8x speed: switch to 2nd gear, press L & R (together) and keep holding either L or R

Mic Blow Button Mod:
-> Press L or R fo fake mic blowing while playing the flute
-> Press X or Up to fake mic blowing everywhere else

Super Secret Cheat Code:
-> Press L & R & B & Down while viewing your treasures
-> Wonder why this doesn't work for all treasure types?
-> Some things need to be earned!


NOTE TO FELLOW ROMHACKERS
This patch isn’t meant to be "complete." It mainly addresses slow train travels and the frustrating mic blow mechanics. There are still plenty of things in the game that could use improvement. For example, the game’s economy is severely unbalanced, with rupees and low-value treasures being too scarce until near the end. Train parts are also too expensive, and the treasure system forces players into repetitive mini-games and/or exchanging treasure with other players (which is almost impossible in 2024). Some boss fights feel more like battles against poor controls rather than challenging enemies. If you have additional ideas for improving the game, feel free to use this patch as a base, just remember to give credit!


TOOLS & RESOURCES USED
If you want down that rabbit hole, too, here's a list of resources I used in making this patch. I also included the .CHT files (feel free to use them), including one version with comments and explanations.

DeSmuME
(for finding offsets and debugging)
https://desmume.org/

DSATM
(I used offset 0x23FC000 and repeat every 10 cycles)
https://www.gamebrew.org/wiki/DSATM

BEAT Patcher
(for creating the patch files)
https://github.com/Screwtapello/beat?tab=readme-ov-file

DeadSkullzJr's NDS(i) Cheat Databases
(best cheat database out there)
https://gbatemp.net/threads/deadskullzjrs-nds-i-cheat-databases.488711/

Making an Action Replay code
(the best tutorial out there for getting started with AR coding)
https://www.reddit.com/r/learnprogramming/comments/6kqbcr/making_an_action_replay_code/

CTRPF-Action Replay Code Types
(a valuable resource and explanation of AR code types)
https://gist.github.com/Nanquitas/d6c920a59c757cf7917c2bffa76de860

Online NDS Action Replay encoder/decoder
(converter between pseudo code and AR code)
https://eldred.fr/nds-ar-encoder/



(C) 2024 d0k3
