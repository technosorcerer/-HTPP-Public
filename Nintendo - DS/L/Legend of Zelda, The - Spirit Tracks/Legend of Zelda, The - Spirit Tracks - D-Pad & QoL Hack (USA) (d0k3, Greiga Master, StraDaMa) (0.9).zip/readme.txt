The Legend of Zelda
Spirit Tracks
DPAD & QoL Hack v0.9
by d0k3 (2024)


OVERVIEW
This is a combined patch that integrates both the QoL Hack v1.0b by d0k3 and the D-Pad Patch (update 2, rebased on good dump) by Greiga Master / StraDaMa. The goal is to enhance the overall gameplay experience by addressing several frustrations that players might encounter, including slow train travel, cumbersome mic-blowing mechanics, and lack of D-pad controls. This patch improves these areas while maintaining the core challenge and enjoyment of the game.


INSTRUCTIONS
You need this game dump and a BPS compatible patching tool.

Filename: Legend of Zelda, The - Spirit Tracks (USA, Australia) (En,Fr,Es).nds
CRC-32: 38392357
SHA-1: 1f0921b5e99db9d92d24710f1b004e4f3c997b73

If you need a BPS compatible patching tool, use this one:
https://www.marcrobledo.com/RomPatcher.js/


FEATURES
This is what you can do with this romhack.

QoL Enhancements / Train Overdrive Mod:
-> 2nd gear speed is 1.5x faster than original
-> Reverse speed is 1.5x faster than original
-> Press and hold L or R for BOOST MODE (4x original speed)
-> For 8x speed: switch to 2nd gear, press L & R (together) and keep holding either L or R

QoL Enhancements / Mic Blow Button Mod:
-> Press L or R fo fake mic blowing while playing the flute

QoL Enhancements / Super Secret Cheat Code:
-> Press L & R & B & Down while viewing your treasures
-> Wonder why this doesn't work for all treasure types?
-> Some things need to be earned!

D-Pad Controls:
-> D-Pad: Move
-> Y + D-Pad: Move slower
-> B: Wide slash
-> B + D-Pad: Long slash
-> Y + B: Spin Attack
-> A: Interact / Mic Blow
-> A + D-Pad: Roll
-> Select + Left: Switch between Zelda and Link


KNOWN ISSUES / FURTHER IMPROVEMENTS
While this patch significantly improves certain aspects of the game, it doesn't address everything. The game economy is still unbalanced, with rupees and low-value treasures being too scarce early on. Additionally, train parts are overpriced, and certain boss battles may feel like fights against poor controls rather than a true challenge.

If you have suggestions for further improvements, feel free to build on this patch. Just remember to credit the original creators!


TOOLS & RESOURCES USED / QOL PATCH
If you want down that rabbit hole, too, here's a list of resources that were used in creating the QoL patch. I also included the .CHT files (feel free to use them), including one version with comments and explanations.

DeSmuME
(for finding offsets and debugging)
https://desmume.org/

DSATM
(I used offset 0x23FC000 and repeat every 10 cycles)
https://www.gamebrew.org/wiki/DSATM

BEAT Patcher
(for creating the patch files)
https://github.com/Screwtapello/beat?tab=readme-ov-file

DeadSkullzJr's NDS(i) Cheat Databases
(best cheat database out there)
https://gbatemp.net/threads/deadskullzjrs-nds-i-cheat-databases.488711/

Making an Action Replay code
(the best tutorial out there for getting started with AR coding)
https://www.reddit.com/r/learnprogramming/comments/6kqbcr/making_an_action_replay_code/

CTRPF-Action Replay Code Types
(a valuable resource and explanation of AR code types)
https://gist.github.com/Nanquitas/d6c920a59c757cf7917c2bffa76de860

Online NDS Action Replay encoder/decoder
(converter between pseudo code and AR code)
https://eldred.fr/nds-ar-encoder/


CREDITS
QoL Patch: d0k3
https://romhackplaza.org/romhacks/spirit-tracks-qol-hack-nintendo-ds/

D-Pad Patch: Greiga Master / StraDaMa
https://www.romhacking.net/hacks/2235/
https://github.com/StraDaMa/Legend-of-Zelda-Phantom-Hourglass-D-Pad-Patch


(C) 2024 d0k3 & Greiga Master / StraDaMa
