The Legend of Zelda
Spirit Tracks
DPAD & QoL Hack v0.9c
by d0k3 (2024)


OVERVIEW
This is a combined patch that integrates both the QoL Hack v1.0b by d0k3 and the D-Pad Patch (update 2, rebased on good dump) by Greiga Master / StraDaMa. The goal is to enhance the overall gameplay experience by addressing several frustrations that players might encounter, including slow train travel, cumbersome mic-blowing mechanics, and lack of D-pad controls. This patch improves these areas while maintaining the core challenge and enjoyment of the game.


INSTRUCTIONS
You need one of these two game dumps and a BPS compatible patching tool.

Filename: Legend of Zelda, The - Spirit Tracks (USA, Australia) (En,Fr,Es).nds
CRC-32: 38392357
SHA-1: 1f0921b5e99db9d92d24710f1b004e4f3c997b73
BPS file: loz_st_dpad_qol-0.9c-ua.bps

Filename: Legend of Zelda, The - Spirit Tracks (Europe) (En,Fr,De,Es,It).nds
CRC-32: 84aa2400
SHA-1: 9e99cc803a14ce038eb908db585431f8254f09ee
BPS file: loz_st_dpad_qol-0.9c-e.bps

If you need a BPS compatible patching tool, use this one:
https://www.marcrobledo.com/RomPatcher.js/

For convenience, BPS patch files containing only the D-Pad romhack are included in ./dpadonly (use a clean rom for patching) If you encounter issues with this romhack on your flashcard, you can apply the D-Pad hack along with the included CHT files located in ./cht (make sure to use the correct one for your game) to achieve the same result.


VERSION HISTORY
A list of changes since the inital release.

DPAD & QoL Hack v0.9c
- rebased (Europe) patches for the untrimmed base dump

DPAD & QoL Hack v0.9b
- added patches for the (Europe) game version

DPAD & QoL Hack v0.9a
- changed the DSATM memory offset to 0x23FE000 for better compatibility
- added D-Pad only BPS file
- updated .cht files

DPAD & QoL Hack v0.9
- initial release


FEATURES
This is what you can do with this romhack.

QoL Enhancements / Train Overdrive Mod:
-> 2nd gear speed is 1.5x faster than original
-> Reverse speed is 1.5x faster than original
-> Press and hold L or R for BOOST MODE (4x original speed)
-> For 8x speed: switch to 2nd gear, press L & R (together) and keep holding either L or R

QoL Enhancements / Mic Blow Button Mod:
-> Press L or R fo fake mic blowing while playing the flute

QoL Enhancements / Super Secret Cheat Code:
-> Press L & R & B & Down while viewing your treasures
-> Wonder why this doesn't work for all treasure types?
-> Some things need to be earned!

D-Pad Controls:
-> D-Pad: Move
-> Y + D-Pad: Move slower
-> B: Wide slash
-> B + D-Pad: Long slash
-> Y + B: Spin Attack
-> A: Interact / Mic Blow
-> A + D-Pad: Roll
-> Select + Left: Switch between Zelda and Link


KNOWN ISSUES / WARNING
This romhack is incompatible with DSTT flashcards — attempting to use it could result in a corrupted save file. It may also have issues with other flashcards, so proceed with caution, as results may vary depending on the hardware.


FURTHER IMPROVEMENTS
While this patch significantly improves certain aspects of the game, it doesn't address everything. The game economy is still unbalanced, with rupees and low-value treasures being too scarce early on. Additionally, train parts are overpriced, and certain boss battles may feel like fights against poor controls rather than a true challenge.

If you have suggestions for further improvements, feel free to build on this patch. Just remember to credit the original creators!


(C) 2024 d0k3 & Greiga Master / StraDaMa
