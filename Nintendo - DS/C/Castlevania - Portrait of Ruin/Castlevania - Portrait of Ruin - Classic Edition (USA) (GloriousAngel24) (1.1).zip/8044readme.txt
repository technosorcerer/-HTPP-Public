Castlevnia Portrait of Ruin Classic Edition

Author: GloriousAngel24

LATEST VERSION: v1.1


TABLE OF CONTENTS

- 1) Castlevania Portrait of Ruin Classic Edition (Main)
- 2) Castlevaina Portrait of Ruin Classic Edition (Richter Walk Mode)
- 3) Sprite Changes
- 4) Patching Instructions, Including Patch Swapping
- 5) Release Contents
- 6) Credits and Sources




- 1) Castlevania Portrait of Ruin Classic Edition (Main):

Experience Castlevania Portrait of Ruin with classic elements from classic Castlevania games in place of weapons, sub weapons, enemies and other characters.
Make your way to the top of the castle, slaying enemies with Castlevania 1 and 2 style leather whips, Castlevania Rondo of Blood modeled chain whips, Castlevania Symphony of the Night and Rondo of Blood(also Rondo of Blood like) subweapons.

Enemies and other characters take form of their older counterparts from Castlevania Rondo of Blood, Castlevania Symphony of the Night, Super Castlevania 4 and even Castlevania 3.

All other Rondo of Blood elements added to Portrait of Ruin are not exactly using Rondo of Blood color palettes but instead using their Dracula X color palette conversions (the way Maria, her animals, and other Rondo of Blood enemies have been brought to Portrait of Ruin).
So the Rondo of Blood elements have a bit of a brighter appearance.

Aside from the visual changes the gameplay is pretty much the same as in vanilla, at least for the most part.




- 2) Castlevania Portrait of Ruin Classic Edition (Richer Walk Mode):

There are 2 patches. The "CV POR Classic Edition (Main)" patch has pretty much the same vanialla gamplay but with the classic visuals.
Then the "CV POR Classic Edition (Richter Walk)" patch is what I would like to call "Richter's Hard Mode".

The (Richter Walk) patch is where you experience Richter mode in the most classic way.
Richter no longer sprints but instead power walks the way he did in Rondo of Blood and Symphony of the Night. But don't worry, he still has his sliding, double jumping and all of his other abilities.
You'll find yourself barely evading some enemy/boss attacks and making some tight jumps with single jumping.

Also in the Richter Walk mode, you absoulutely can defeat all bosses without taking any damage. Well, at least for majority of the bosses, you wouldn't necessarily need Maria's help nor help from Richter's Grand Cross.
For some later(or very few) boss battles you absolutely need Maria's help and or help from Richter's Grand Cross to get through without taking any damage.

And speaking of Maria, if Richter loses speed so does Maria. Her speed has been reduced to Soma's speed from Dawn of Sorrow.




- 3) Sprite Changes


	- Characters:

		-Richer: In his Rondo of Blood form. When holding up in the (Main) patch, he poses like vanilla but with ROB "Name Entry" sprites. Then when holding up in the (Richter Walk) patch, he uses his classic arms out pose.

		-Old Axe Armor: Is now an Axe Lord or Old Axe Lord from Rondo of Blood.

	- Weapons:

		-Leather Whip: CV1 style

		-Rose Steam Whip: CV2 style

		-Jonathan's Chain Whips: ROB Style (Even for whip dangling and diagonal whipping).

		-Richter's Vampire Killer: The exact Vampire Killer from ROB but extended.


	- Sub Weapons (The ROB Sub Weapons Jonathan uses have their own unique MASTERED forms):

		- Dagger: ROB/DX form.

		- Axe (Johnathan): ROB/DX style

		- Axe (Richter)(Old Axe Lord): ROB/DX form

		- Bible: ROB style

		- Holy Water (Jonathan): ROB/DX and SOTN green color

		- Holy Water (Richter): SOTN blue color

		- Cross (Jonathan): ROB/DX form

		- Cross (Richter): SOTN form. 20 x 22, in pixel units, like in ROB instead of 20 x 20 like in SOTN.

		- Grand Cross: SOTN Crucifix


	- Enemies:

		- Bat: SOTN form

		- Une: SCV4 style/colored

		- Armor Night: SOTN style/colored

		- Bone Pillar: ROB/DX Horns added

		- Fleaman: ROB/DX form

		- Harpy: ROB style, DX colored

		- Gaibon: SCV4 style/colored

		- Slogra: SCV4 style/colored

		- Minotaur: ROB style, DX colored

		- Ripper: ROB/DX form, still uses original color palettes.

		- Mummy Man: ROB style, DX colored

		- Whips Memory: ROB/DX form (In the (Richter Walk) patch, if Richter(player) walks so does Whips Memory).

		- Fake Trevor: Uses most color palettes from "Greatest Five" Dual Crash to more resemble CV3 Trevor. He wields the ROB Vampire Killer and uses a purple colored slash during the attack.
			       He also uses actual grey DX style crosses and giant crosses instead of boned crosses. Fake Trevor probably shouldn't be using actual crosses but uses them anyways.

		- Death (v1.1): ROB/DX style, DX colored

		- Dracula (v1.1): ROB/DX style, DX colored

		- True Dracula (v1.1): DX style, DX colored


	- Miscellaneous:

		- Title Screen: Bluish/purplish moon is based off of the moon from Castlevania Rondo of Blood at the Castle Keep stage.
				The light green for fog comes from the light green lighting in the sky in the Castlevania Rondo of Blood Title Screen.

		- Doors (v1.1): Overall sprites are in the style of ROB and DX (a combination of both).

		- "Greatest Five" Dual Crash: Whips are in ROB form.

		- Sub Weapon Icons: Changed to align with classic sub weapons.

		- Staff Roll for Richter's and Old Axe Lord's playthrough: Just simple sprite changes.




- 4) Patching Instructions, Including Patch Swapping

	Patching uses xdelta program. The original Source File is "Castlevania - Portrait of Ruin (USA)". First, select the Patch. Second, select the Source File. Lastly, name the Output File and select where you want to save the file.
	
	There are two things you can do with these two patches. You can either patch them seperately or you can switch between patches and keep your saved data.
	Let's say you choose the (Richter Walk) patch first. During patching, name the Output File whatever you want. Then start up the game and the emulator will create a save using the name of the file at the time of the initial start up.
	If you want to switch from Richter walking back to him sprinting...

		1st) Start patching up the (Main) patch.
		2nd) Give the Output File the same exact name as you gave your file that uses (Richter Walk) patch.
		3rd) Be sure to replace the file that uses the (Richter Walk) patch with the newly (Main) patched file, ONLY during patching with the Output File destination.
		4th) Select Patch and its done.

	That way you switch from Richter walking to him sprinting and keep your saved data along with that. Then you can also switch from sprinting to walking, vice versa.
	Perhaps it's possible that there is an easier way of switching between patches without this specific method but this is the only safest way I know.




- 5) Release Contents

v1.0

Inital Release


v1.1

- Doors are in the style of "Rondo of Blood" and "Dracula X", a combination of both.

- Death wears a blue robe like in "Rondo of Blood" or "Dracula X".

- Dracula wears a purple cloak like in "Rondo of Blood" or "Dracula X".

- True Dracula is blue, resembling his final form from "Dracula X".

- Dracula's and Death's character portraits are recolored to align with their recolored sprite counter parts. Both of their color palettes are shared with other character portraits such as Johnathan's sholder pads and Brauner's suit. Though such changes are barely noticable, thought it should be mentioned.

- For "Greatest Five" Dual Crash and "Richter Mode" Credits, corrections have been made regarding where Simon holds the whip by.





- 6) Credits and Sources

	Main Author: GloriousAngel24

	Tools: DSVEdit_x64 by LagoLunatic

	All sprite sheets are from The "Spriters Resource" https://www.spriters-resource.com
	Credit to owners of sprite sheets and to Konami along with all that.

		- Richter ROB sprite sheet - by BadBatman3
		- Enemies ROB sprite sheet (color palettes only) - by BadBatman3
		- Bosses ROB sprite sheet (color palettes only) - by BadBatman3
		- Maria ROB sprite sheet (color palettes only) - by BadBatman3
		- Name Entry sprite sheet - by Badbatman3
		- Candles and Items ROB sprite sheet (color palettes only) - by BadBatman3
		- Other ROB sprites and color palettes - from Castlevania Rondo of Blood by Konami	
		- Bat SOTN sprite sheet - by SmithyGCN
		- Spear Guard SOTN sprite sheet (color palettes only) - by Smithy GCN
		- Thornweed color palettes - from Super Castlevania 4 by Konami
		- Gaibon SCV4 sprite sheet (color palettes only) - by SmithyGCN
		- Slogra SCV4 sprite sheet (color palettes only) - by SmithyGCN
		- Enemies DX - by Smithy GCN
		- Bosses DX - by GCN
		- Other DX color palette data - from Castlevania Dracula X by Konami
		- Sub Weapons sprite sheet - by SmithyGCN 
		- Flea Man sprite sheet - by Deathbringer
		- Whips CVChronicles sprite sheet (for leather whips customization) - by SmithyGCN

	Obtained character speed values from "Castlevania Speedruns" https://castlevaniaspeedruns.com

