===============================================================================
Castlevania - Circle of the Realm
By: Darren Zcon
===============================================================================
Installation guide:
This is a ROM hack of Castlevania - Portrait of Ruin. In order to apply the patches provided,
you will need to first make sure you have the correct dump of the original game and the
required patching software.

    File: Castlevania - Portrait of Ruin (USA).nds
    CRC-32: 96DF4C4D
    MD5: 2EDD57540CAE45842FBD19C45A4214F9
    SHA-1: 382602E3615B2282EEAD584014125E71B5B0F033
    SHA-256: 1174A36FD91F79E95E90B76AA1268AF8FC09F69C04CC8E5B4FF791E872254ABD


Xdelta UI:
https://www.romhacking.net/utilities/598/

MultiPatch:
https://www.romhacking.net/utilities/746/

Xdelta Patcher:
https://kotcrab.github.io/xdelta-wasm/

UniPatcher
Download the app on Play Store or Ios (Maybe?), using it is a completely straight forward.
===============================================================================
A B O U T:
"Set's 7 years after Dracula's defeat on the event of Castlevania - Circle of The Moon (GBA 1999 - 2001)
Out of no where, a castle emerged once again. Play as Nathan Graves and Hugh Baldwin, storm the
demonic castle, collect powerups, and let the adventure begin!"

F E A T U R E ' S:
- Custom gameplay mechanic (Mostly)
- Custom storyline
- Custom enemy
- Custom weapon
- Custom music
- Custom sound effect
- Custom character
- More replay abilities
- Custom Emblem on the name entry
- Fixed some of the bugs from Portrait of Ruin itself
- More Circle of The Moon Reference
- Custom riddle or puzzle (Not many)
- Custom area/map progression
- More exploded skeleton

K N O W N   I S S U E ! ! !
1. Charlotte in Portrait of Ruin was considered as a extra character like Richter, Maria, and Old Axe Armor. Giving Charlotte the
ability to critical art also unlock the ability to combo tech (Martial art, spinning art, etc). The main goal for this hack is too
give Nathan and Hugh some equality, Nathan needs at least a Martial art combo to 100% the side quest, Hugh also deserve the
same combo tech as Nathan. But again, Charlotte was poorly programmed, she only have various moveset disabled (Double Jump,
slide, Griffon wing, etc.) EXCEPT Critical art, spinning art, and martial art. YES, Hugh can critical art, do various Richter combo
input at THE beginning of the game without the relic unlocked. This issue might be fixed in the future, this isn't our fault, it's
just how poorly Charlotte was programmed... I mean go figure, Portrait of Ruin was finished under a Year, that infamous 
infinite quest glitch and death softlock makes it obvious.

2. There's 1 Crissaegrim/ Valmanway weapon in this game (Warning: it's also a meme), if the weapon is being used as a
partner character (AI), the player will freeze in place. To fix it, unequip those weapon or partner bounce. (Again, not our fault
Portrait of Ruin was rushed, VERY rushed, Illusion fist however is a different thing.)

3. Suspend glitch still exist and currently there's no way to solve it. Could be usefull but becarefull that it might break things.

4. This game wont work on some emulator's, check the [Compability list.txt]

5. Not an actual issue that impact the gameplay, this game has custom NPC, and there's lack of Ayami Kojima's art style
out there that looks approximately the same as this NPC, probably in the future. (Some new portrait were drawn by Darren Zcon)

Obviously the game isn't 100% perfect, not even 90%, which is why your feedback is greatly appreciated!

C H A N G E L O G:
- BETA Ver. 0.0.1
(Only playable by Jupiter Climb as a early showcase)
A lot of bad balancing aeugh....

- Official Version 1.0.0
Game released!
