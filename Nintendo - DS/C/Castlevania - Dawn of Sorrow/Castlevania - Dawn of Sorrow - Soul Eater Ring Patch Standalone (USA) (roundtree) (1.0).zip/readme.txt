Soul Eater Ring Patch Standalone
for Dawn of Sorrow
by roundtree

This is a standalone patch created for Dawn of Sorrow that changes the price of the soul eater ring to 30k, 50k, 100k, 150k, or 200k, depending on which patch you choose to use. The patches are all .xdelta format, so Delta Patcher must be used to apply them. They will work for either the original Dawn of Sorrow rom or Definitive Edition+ or whatever other rom you have.

IMPORTANT: You must uncheck checksum validation in order to apply this patch to any other rom besides the original No-Intro USA version of Dawn of Sorrow. If checksum validation is unchecked, the patch can be applied to Definitive Edition+ or any other patched rom.


Credits:

Original credit for this idea goes to Mureisky, who created the Improved Drop rates patch for Aria of Sorrow improves the drop rate for souls and items, fixes the luck stat, and changes the price of the soul eater ring to 30k.

Credit also goes to LagoLunatic for creating DSVania Editor, without which this patch would not exist.

Also Marco Calautti for Delta Patcher for creating the patch from the altered rom.
