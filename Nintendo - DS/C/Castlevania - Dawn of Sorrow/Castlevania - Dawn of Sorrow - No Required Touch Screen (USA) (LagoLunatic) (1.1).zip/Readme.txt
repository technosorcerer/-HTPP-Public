
Castlevania: Dawn of Sorrow No Required Touch Screen
By LagoLunatic

This patch makes several changes to Dawn of Sorrow so that you can complete the game without needing to use the touch screen for anything.
* Magic seals are completed automatically like in Julius mode.
* Ice blocks can be destroyed with melee weapons if you have Balore's soul.
* The name signing screen when starting a new game is skipped.

This patch only works on the North American version of Dawn of Sorrow.

Patching instructions:
Use a program like Lunar IPS to apply the .ips patch to the game ROM.
