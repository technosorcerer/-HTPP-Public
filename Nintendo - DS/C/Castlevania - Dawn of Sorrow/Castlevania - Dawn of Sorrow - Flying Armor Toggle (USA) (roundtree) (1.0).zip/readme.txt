Flying Armor Toggle Patch
Dawn of Sorrow
by roundtree

This patch changes the flying armor from having to hold the button into a toggle button. Much nicer to use this way on a touchscreen phone but not bad on a controller. This patch can be applied to either the original Dawn of Sorrow rom or the Definitive Edition+. Make sure you use Delta Patcher and click the gear icon and uncheck "checksum validation".

IMPORTANT: This patch was created with the original Dawn of Sorrow rom, so an error will prevent patching the Definitive Edition+ unless the "checksum validation" has been unchecked.

A quick side note: If anyone can create a patch for the HP Regeneration rate for the Creature Soul, please do! I've already tried several times and failed. But if I do manage to succeed, I'll upload a patch so everyone can use it.

Credits:

Credit must be given to radzo73 for coming up with the idea in the first place when he made this exact patch for Aria of Sorrow. I don't feel like I would have even thought of this patch unless he made his patch first.

Also LagoLunatic for creating DSVania Editor. (Works on both Windows and Linux with Wine) This patch would have never happened without that editor.

Also Marco Calautti for Delta Patcher. Not sure if he is the original author, but this patch would have never happened without Delta Patcher. Floating IPS complained to me for trying to create a patch larger than 16 mb (although its smaller than 1 mb in reality.)
