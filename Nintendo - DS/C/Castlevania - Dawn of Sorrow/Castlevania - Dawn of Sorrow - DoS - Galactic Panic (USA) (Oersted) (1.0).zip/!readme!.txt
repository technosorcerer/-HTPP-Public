You do not have to kill all bosses in order to access the Mines of Judgement. Simply defeating Aguni will do!


Galacta Knight's Attacks
Axe -> Galactic Sword
Simple Projectile attack.

Holy Water -> Rending Slash
An even bigger projectile attack. Great for combos.

Cross -> Aeon World
Allows you to damage and kill foes by depleting their MP.

Grand Cross -> Thunderstrike Stab
Fully invincible. Very high vertical range. Grounded only.