Castlevania: Dawn of Sorrow - Definitive Edition combines various improvement/bugfix patches and QoL level edits to create the best way to play Castlevania: Dawn of Sorrow. Included in this hack are: 

- Castlevania: Dawn of Dignity (New Portraits Hack)
This hack replaces the game's anime portraits with portraits similar to the ones featured in Aria of Sorrow, drawn by Ayami Kojima. Some portraits are taken from other official Castlevania games, while a handful were drawn from scratch by acediez. 
- Castlevania: Dawn of Sorrow Fixed Luck
This hack fixes the Luck stat, which originally had next to no effect on the drop rate of Souls, to actively influence the drop rate based on height. 
- Castlevania: Dawn of Sorrow No Required Touch Screen
This hack removes the dependence on touch screen elements in the game. It removes the Seal drawing mechanic, skips the name signing at the start of the game, and enables you to break ice blocks with melee weapons.

- An issue in the original game is that, once the player uses the Souls of Gergoth, Death and Abaddon to forge new weapons using the Weapon Synthesis mechanic, these Souls no longer count towards the 100% Soul collection, making the Chaos Ring unobtainable unless he starts a New Game+ file and obtains these Souls again. This has been fixed by allowing the player to collect these three Souls twice per run. 

- In the original, the Black Panther Soul, which gives you a huge speed boost and costs next to no MP, is found in one of the very last rooms in the game. This makes the Soul pretty useless. This hack places the Black Panther Soul in the room behind the Throne Room, a choice reminiscent of Aria of Sorrow. 

- This hack makes the Alucard Sword obtainable without the player having to resort to the use of glitches. 

The Readme file of this patch contains two cheat codes, a Level 1 cap and a remove money code. These serve to enhance the replay value of the game, not to make the game easier. 

PERMANENT LVL 1 AND MENU EXP=0 (menu shows LV. 99, only works when starting a new game):

220F740C 00000063
020F7448 00000000

MONEY = ZERO:

020F744C 00000000

INSTRUCTIONS: 

For CLEAN Hard Mode LV.1: talk to Yoko to release all of your Souls. Then sell all of your equipment, with the MONEY = ZERO cheat activated. Start a New Game on Hard Mode. The file is now ready, deactivate the Money cheat and keep the permanent LVL 1 cheat activated while playing.
For Hard Mode Lv.1 + all of your previous Save stuff: Activate the Permanent LV.1 cheat and start Hard Mode from your cleared file. Keep it active while playing.
To make it up for the Character swap weapons not changing like Soma, here's a fun custom mode:
Play as Yoko/Julius/Alucard + Chaos Ring only (extreme MP regen) on Hard Mode Lv.1: Start a New Game on Hard mode with the ALL ACCESSORIES cheat activated, kill the 1st boss, save and quit. Deactivate the ACCESSORIES cheat, activate the MONEY = 0 cheat and enter the game. Talk to Yoko to release all of your Souls, then sell all of your equipment except the Chaos Ring, save and quit. Deactivate the Money cheat. The file is now ready to play, keep the Permanent LVL 1 AND your chosen Sprite swap cheat activated while playing.
