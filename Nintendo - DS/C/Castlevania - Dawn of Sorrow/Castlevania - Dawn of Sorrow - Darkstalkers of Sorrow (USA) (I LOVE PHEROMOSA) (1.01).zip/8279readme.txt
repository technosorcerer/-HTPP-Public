Hack made by New King of Antland#9302 (I LOVE PHEROMOSA)
ROM required: Castlevania: Dawn of Sorrow (US)

A hack where the player sprites are almost as big as a Great Armor. Only applies to
hitboxes, not player collision since we haven't found a way to modify that yet.

Characters replacing Julius and Alucard:
	-Q-Bee
	-B.B. Hood

Q-Bee Features:
	-Two subweapons: Bee Swarm and Bee Transformation.
		-Bee Swarm can only be used in the ground.
		-Bee Transformation has an *Amazingly accurate* hitbox.
	-Uses no weapons so attack frames are delayed and can't break ice blocks.
	-Can't jump or divekick after a high jump.
	-*Amazingly accurate* crouch hitbox.
	-Entire game is beatable with just her.

B.B. Hood Features:
	-Two subweapons: Fireball and Bombs.
		-Fireball can only be used in the ground.
		-I don't know how to make subweapons only usable in air so I would
		appreciate it if you only used Bombs in the air, thanks.
	-Uses weapons which means they can break ice blocks.
		-If the damage gets reduced after a level up, don't worry it's just a
		Julius mode thing and means the damage is now at its intended values.
	-Can't high jump or divekick.
	-Backdash has an *accurate hitbox*.
	-Some bosses may be impossible to solo due to large hitbox.

Extra Features:
	-New warps and saves added (refer to giant red arrows in image.png in this folder).
	-Sliding is faster and covers longer distance.
	-Later bosses have their exp points increased.
	-Somacula first phase has slightly increased speed.
	-Cool end cutscene and credits sprites.

Known Issues:
	-Some of the player sprites may become shaky and somewhat stretched, this only
	happens if you are facing right. Probably due to the fact that this game is
	struggling to render huge player sprites.

--Version 1.01--

	-Fixed the problem with B.B. Hood's crouch attacks sometimes not hitting anything.
	-Removed drawbridge, for the greater good.
	-Dialogue changes.