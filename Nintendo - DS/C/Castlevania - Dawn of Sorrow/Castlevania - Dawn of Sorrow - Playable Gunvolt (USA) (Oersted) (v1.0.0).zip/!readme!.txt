You do not have to kill all bosses in order to access the Mines of Judgement. Simply defeating Aguni will do!


Patch Differences
Standard Mode
The intended experience. Gunvolt plays as intended here.

Amp Up Mode
Gunvolt's Movement speed has been massively increased.
Gunvolt's Dash is even faster now, but lasts for less time. However, it goes farther than before.
Gunvolt's Dash now has zero friction.
All of Gunvolt's stats are increased by 10.
Gunvolt's grounded jump propels him much higher. Maybe even too high, he isn't someone like Broly...


Gunvolt's Attacks
Axe -> Electrical Barrier
Buer with a new coat of paint. This barrier deals constant shock damage.

Holy Water -> Instant Shock
Ryucuda, usable by Gunvolt. It's low damage accounts for it's instant nature.

Cross -> Luxcalibur
Gunvolt's Blade, in the form of a large range attack.

Grand Cross -> Buster Acerbatus
A cheap, easily usable Acerbatus. It's damage is near equal to the Buster Shot, to balance out it's larger hitbox.

Standard Attack -> Buster Shot
A simple projectile. Nothing of note.