Castlevania Dawn of Sorrow ROM hack - Bloodstained: Curse of the moon crossover (Nightmare mode)
This hack has Julius mode changed into COTM's nightmare mode with moddified skill sets
Mostly for fun purpose

Features:
-Julius, Yoko and Alucard changed into Miriam, Alfred and Gebel
-Modified conversation
-Modified sprites
-Modified bosses
-Added custom song
-Moddified tileset for a certain stage

-Miriam:
	+ Attack: strike
	+ Can slide
	+ High jump
	+ Can backdash
	+ Subweapon:
		Sickle: slash + stab
		Axe: low Iframe + slash
		Knife: stab + poison

-Alfred:
	+ Attack: strike + regen
	+ Can backdash
	+ Higher mana regen
	+ Subweapon:
		Burning Sphere: fire + can cast 4 times
		Frostcaliber: ice + immobile most enemies (can one hit some)
		Voltaic Ray: Lightning

-Gebel:
	+ Attack: slash + curse
	+ Can backdash
	+ Run faster
	+ Subweapon:
		?: ?
		Immortal Metamorphosis: bat transformation


-Bosses: adjust damage and hp for certain bosses

-Known bug when writing this txt: 
	final boss song may be too tough for some platforms to handle


-Credit:
	+ Game:
		Castlevania: Dawn of Sorrow (Konami)
		Bloodtained: Curse of the moon (Inti Creates)

	+ Custom sprites:

	+ Main hacker: ColinBun - Double Hammers (Both are me) (Discord - ColinGoat#4322)

	+ Creator of DSVania Editor (used for hacking the game): LagoLunatic

	+ Added song: 
		-Aquarius, Mine of Judgement, clock tower (Bastlevania)
	
 		-Moonlit blade, Desperado's death parade, Depths of Despair, Boundless Avarice, Theme of Gebel, Malicious Intent, Silent Howling( 2 versions), Theme of Bloodstained, Exorchism (Bloodstained games)
		
	+ Helping hands:
		- Exorion Hagen (Tester)
		- Darren /Ncoz (Tester/ Hacking help/.sseq creating / porting)