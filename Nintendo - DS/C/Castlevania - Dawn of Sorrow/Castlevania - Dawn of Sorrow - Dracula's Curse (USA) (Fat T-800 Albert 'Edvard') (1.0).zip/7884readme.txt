===============================================================================
Castlevania - Dracula's Curse
By: Fat T-800 Albert
===============================================================================
This is a ROM hack of Castlevania - Dawn of Sorrow. In order to apply the patches provided,
you will need to first make sure you have the correct dump of the original game and the
required patching software.

Castlevania - Dawn of Sorrow (USA)
Database: No-Intro: DS (all) (v. 20210227-111036)
File/ROM SHA-1: 47530FF87E608F88105A314FDF36DC385F8DEC94
File/ROM CRC32: 135737F6

Xdelta UI:
https://www.romhacking.net/utilities/598/

MultiPatch:
https://www.romhacking.net/utilities/746/

Xdelta Patcher:
https://kotcrab.github.io/xdelta-wasm/
-------------------------------------------------------------------------------
Notes:

It is highly recommended that you play this hack with a joypad or controller for the best experience.
-------------------------------------------------------------------------------

Changelog & Credits:

v1.0.0 - June 18, 2023
Fat T-800 Albert:
- Initial release

JupiterClimb:
- Beta tester 

Masked Dedede:
- Beta Tester

DragonX24:
- Beta Tester

Serbagz:
- Alucard from Dawn of Dissonance.
- Part of the Sypha sprite ports
- Beta Tester

elpegaso7:
- Original creator of SOTN-expanded sprite sheets of Trevor, Sypha and Grant

Serio CVF team:
- Part of the Grant sprites
