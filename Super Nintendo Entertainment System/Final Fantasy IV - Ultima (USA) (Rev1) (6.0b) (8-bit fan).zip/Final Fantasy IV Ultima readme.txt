Final Fantasy IV - Ultima
---------------------------------------------------------
-= Complete hack v6.0b =-
Apply 'Final Fantasy IV - Ultima v6.0b no header.ips' directly to a non-headered 'Final Fantasy II (U) (V1.1).smc'
or...
Apply 'Final Fantasy IV - Ultima v6.0b headered.ips' directly to a headered 'Final Fantasy 2 (V1.1) (U).smc'
---------------------------------------------------------

What this hack does:
---------------------------------------------------------
FF2US always felt somewhat lacking and incomplete but full of potential. This hack rectifies that by adding a ton of additions to the base game while keeping the majority of the main story intact and the feel of FF2US the same. This hack can be viewed as a 'deluxe' version of FF2US.
---------------------------------------------------------

Version 6.0b changes:
---------------------------------------------------------
Critical bug fix to MagicMap and Scan that crashed the game when used to view worldmaps.
Saves from versions 6.0a and 6.0 will work perfectly!
Saves from all other previous versions WILL GLITCH. Please start a new game and enjoy! :)
---------------------------------------------------------

Version 6.0a changes:
---------------------------------------------------------
Minor texts update and polish.
Minor map update.
Saves from version 6.0 will work perfectly!
Saves from all other previous versions WILL GLITCH. Please start a new game.
---------------------------------------------------------

Version 6.0 changes:
---------------------------------------------------------
BRAND NEW ENEMY GRAPHICS!! Huge special thanks to chillyfeez for the tremendous help and collaboration on this update project!! The new graphics would not have been possible without his help!! Much appreciation and credit to chillyfeez!!
3 Brand New Areas!!
2 New Bosses!!
2 New Items!!
1 New Armor!!
New locations and updates to the World Maps.
Edge's steal is now much more effective making stealing much easier!
Balanced and polished several items so that they don't take up unnecessary space in the inventory.
Carrots are now unlimited use so call that Big Chocobo as needed!
Various edits to treasure chests and item drops.
New and improved Boss Battles especially the ones at Endgame!
New palettes for various enemies.
Updated and added various dialogs.
Edits to various shops.
General polish.
Saves from all previous versions WILL GLITCH. Please start a new game.
---------------------------------------------------------

Version 5.42 changes:
---------------------------------------------------------
Minor change in a cutscene event.
Saves from version 5.41 will work perfectly!
Saves from all other previous versions WILL GLITCH. Please start a new game.
---------------------------------------------------------

Version 5.41 changes:
---------------------------------------------------------
Undated Boss Script for the AI Mk.I.
Polished several maps and triggers in the Lunar Subterrane.
Saves from all previous versions WILL GLITCH. Please start a new game.
---------------------------------------------------------

Version 5.40 changes:
---------------------------------------------------------
New Boss for the Lunar Subterrane! This 'new' boss replaces where the AI used to take place.
Moved the location of one boss in the Lunar Subterrane.
Edited several chest contents.
Saves from all previous versions WILL GLITCH. Please start a new game.
---------------------------------------------------------

Version 5.32! changes:
---------------------------------------------------------
Edits to several bosses' stats for balance.
Edits to several weapons' stats for balance.
Edits to several enemies' drops for more meaningful drops at several points in the game.
Saves from versions 5.32 5.31 5.30 will work perfectly!
Saves from all other previous versions WILL GLITCH. Please start a new game.
---------------------------------------------------------

Version 5.32 changes:
---------------------------------------------------------
Edits to several endgame bosses' scripts for balance.
Saves from versions 5.31 and 5.30 will work perfectly!
Saves from all other previous versions WILL GLITCH. Please start a new game.
---------------------------------------------------------

Version 5.31 changes:
---------------------------------------------------------
Minor edits to several bosses.
Additional Script for one of the Super Bosses at Endgame.
Saves from version 5.30 will work perfectly!
Saves from all other previous versions WILL GLITCH. Please start a new game.
---------------------------------------------------------

Version 5.30 changes:
---------------------------------------------------------
AI is no longer a required battle! The location of the fight with AI has been moved and is now an optional boss.
Nerf'd several bosses to make the main game more accessible to the general audience. However, optional bosses are just as tough as ever!
Added new hints and dialog before some of the battles.
Added and changed treasures locations.
Various weapons balancing.
Various map polish.
Updated palette to a few enemies.
Saves from all previous versions WILL GLITCH. Please start a new game.
---------------------------------------------------------

Version 5.21f changes:
---------------------------------------------------------
Minor texts polish and update.
Saves from version 5.20f will work perfectly!
Saves from all other previous versions WILL GLITCH. Please start a new game.
---------------------------------------------------------

Version 5.20f changes:
---------------------------------------------------------
Polished 3 of the endgame bosses' scripts due to the bug that was discovered and fixed in v5.14f.
In doing the above, added a brand new spell for one of the optional bosses at endgame.
Various edits to chest items for balance.
Moved an endgame super secret shop to a new location. Also added a new cutscene showing the player of the new location of the shop.
Saves from all previous versions WILL GLITCH. Please start a new game.
---------------------------------------------------------

Version 5.14f changes:
---------------------------------------------------------
Fix to a critical bug causing one of the endgame spells to malfunction.
Minor update to 2 endgame bosses' scripts.
Saves from version 5.13f 5.12f and 5.10f will work perfectly!
Saves from versions 5.01f and 5.0f will work fine. However, you will not be able to obtain the new spell if you have already defeated Echidna. Please use a save before you've defeated her in order to learn the new spell!
Saves from all other previous versions WILL GLITCH. Please start a new game.
---------------------------------------------------------

Version 5.13f changes:
---------------------------------------------------------
Bug fix to 2 Weapons: The Slaying Tail and The Apocalypse. The amount of status effect inflicted on an enemy caused an overflow during battle resulting in 255 messages being displayed. Not game breaking as it doesn't softlock, but annoying nonetheless. Thanks to 'mathguy86' for discovering the bug!
Saves from version 5.12f and 5.10f will work perfectly!
Saves from versions 5.01f and 5.0f will work fine. However, you will not be able to obtain the new spell if you have already defeated Echidna. Please use a save before you've defeated her in order to learn the new spell!
Saves from all other previous versions WILL GLITCH. Please start a new game.
---------------------------------------------------------

Version 5.12f changes:
---------------------------------------------------------
Minor bug fix in Dwarf Castle where you could get stuck if you try to do the Warp Glitch.
Updated sprites for Ultima Weapon and Apocalypse.
Updated encounters in Lunar Sub and Lunar Core.
Saves from version 5.10f will work perfectly!
Saves from versions 5.01f and 5.0f will work fine. However, you will not be able to obtain the new spell if you have already defeated Echidna. Please use a save before you've defeated her in order to learn the new spell!
Saves from all other previous versions WILL GLITCH. Please start a new game.
---------------------------------------------------------

Version 5.10f changes:
---------------------------------------------------------
Brand New spell added that you can learn at Endgame!
Minor update and polish to maps/texts.
Updates to a few Boss Scripts.
Saves from versions 5.01f and 5.0f will work fine. However, you will not be able to obtain the new spell if you have already defeated Echidna. Please use a save before you've defeated her in order to learn the new spell!
Saves from all other previous versions WILL GLITCH. Please start a new game.
---------------------------------------------------------

Version 5.01f changes:
---------------------------------------------------------
Minor update to Armors Equip and Drop List.
Scan now works on Bosses!
Saves from version 5.0f will work perfectly!
Saves from all other previous versions WILL GLITCH. Please start a new game.
---------------------------------------------------------

Version 5.0f changes:
---------------------------------------------------------
3 Brand New Areas!
3 New Items! Including the legendary Megalixir!
2 New Spells!
Lots of new updates to the World Maps.
Various edits to treasure chests and item drops.
New and improved Boss Battles especially the ones at Endgame!
New sprites and palettes for various weapons and enemies.
Reverted name of 'Esperland' back to 'Feymarch'!
Updated various dialogs.
Many edits to existing gears.
New Endgame Super Shop!!
General polish.
Saves from all previous versions WILL GLITCH. Please start a new game.
---------------------------------------------------------

Version 4.32f changes:
---------------------------------------------------------
Buffed Zeromus.
Nerfed Illusions.
Nerfed Ultima(boss).
Saves from versions 4.31f and 4.21f will work perfectly!
Saves from all other previous versions WILL GLITCH. Please start a new game.
---------------------------------------------------------

Version 4.31f changes:
---------------------------------------------------------
Minor update to some dialog texts.
Minor arrangements to some map tiles in one of the new areas.
Saves from version 4.21f will work perfectly!
Saves from all other previous versions WILL GLITCH. Please start a new game.
---------------------------------------------------------

Version 4.21f changes:
---------------------------------------------------------
This is an addendum to the FINAL version of this hack as well as several areas of polish and bugfixes.
In doing this, I've added 1 New OP Boss, 1 New Armor Gear, several map additions and polish, and texts updates.
Also balanced and re-balanced some existing gears and bosses.
I've aimed to polish this hack as much as I could and hope everyone will continue to enjoy this hack immensely!! :D
Saves from all previous versions WILL GLITCH. Please start a new game.
---------------------------------------------------------

Version 4.10f changes:
---------------------------------------------------------
Barring bug fixes and other critical updates, this should be the FINAL version of this hack. Enjoy!! :)
Balanced weapons, gears, spells and enemies stats.
Polished maps and numerous dialog texts.
Added a few new and very interesting areas. ;)
It's been a blast and a super fun past year creating, updating and adding new stuff to this hack. But as with all fun things, it's time to move on to new horizons! :) I'd like to thank all those who's helped out with various things for this hack, and all those who supported me and the project throughout the year!
Hope everyone will continue to enjoy this hack immensely!! :D
Saves from all previous versions WILL GLITCH. Please start a new game.
---------------------------------------------------------

Version 4.0 changes:
---------------------------------------------------------
2 New Ultimate Weapons at Endgame!
2 New Endgame Armors!
3 New Optional OP Endgame Bosses!!
5 New Areas!!
Buff'd and nerf'd various bosses throughout the game.
More specifically, nerf'd required boss battles in the Lunar Sub to make for casual playthroughs without the need for grinding. At the same time, optional boss battles have been buff'd.
Updated and polished various dialogs.
Updated several weapons stats.
Saves from all previous versions WILL GLITCH. Please start a new game.
---------------------------------------------------------

Version 3.40 changes:
---------------------------------------------------------
Added a few minor scenarios after the events at Fabul.
Updated a secret boss fight in the Lunar Sub.
Fixed a game freezing bug that can be triggered while fighting the Pale Dim from the previous versions.
Updated and polished various dialogs.
Updated several weapons' stats.
Saves from version 3.21c 3.21b 3.21a 3.21 3.20 will work perfectly, but you might miss out on 1 item depending on your progress. If your save is before the Lunar Core your game will work fine. If you are already at the Lunar Core, chances are you will miss 1 item. If that's the case, try an earlier save.
Saves from all other previous versions WILL GLITCH. Please start a new game.
---------------------------------------------------------

Version 3.21c changes:
---------------------------------------------------------
Enhanced sprites for the Ultima Weapon and the Apocalypse Greatsword!
Saves from version 3.21b 3.21a 3.21 3.20 will work perfectly, but you might miss out on 1 item depending on your progress.
Saves from all other previous versions WILL GLITCH. Please start a new game.
---------------------------------------------------------

Version 3.21b changes:
---------------------------------------------------------
New sprites for the Ultima Weapon!
Saves from version 3.21a 3.21 3.20 will work perfectly, but you might miss out on 1 item depending on your progress.
Saves from all other previous versions WILL GLITCH. Please start a new game.
---------------------------------------------------------

Version 3.21a changes:
---------------------------------------------------------
Refined scripts for 2 Lunar Core bosses.
Updated an enemy tech/spell.
Saves from version 3.21 and 3.20 will work perfectly, but you might miss out on 1 item depending on your progress.
Saves from all other previous versions WILL GLITCH. Please start a new game.
---------------------------------------------------------

Version 3.21 changes:
---------------------------------------------------------
Buffed a weapon.
Added a weapon in a chest at the Lunar Core.
Saves from version 3.20 will work perfectly, but you might miss out on 1 item depending on your progress.
Saves from all other previous versions WILL GLITCH. Please start a new game.
---------------------------------------------------------

Version 3.20 changes:
---------------------------------------------------------
New endgame side quests! Rewards are some very powerful weapons!!
New weapons!
Special NEW weapon graphics for an endgame ultimate weapon!
Various weapon buffs.
Fixed various texts.
Saves from all other previous versions WILL GLITCH. Please start a new game.
---------------------------------------------------------

Version 3.10a changes:
---------------------------------------------------------
Minor update to some random encounters in the Underworld and Overworld.
Saves from version 3.0 3.0a 3.0b 3.0c 3.0d 3.10 will work perfectly!
Saves from all other previous versions WILL GLITCH. Please start a new game.
---------------------------------------------------------

Version 3.10 changes:
---------------------------------------------------------
Updated the Multiple Swings Animation mod. Changed the amount of swings dependency from levels to the attack multiplier instead.
Saves from version 3.0 3.0a 3.0b 3.0c 3.0d will work perfectly!
Saves from all other previous versions WILL GLITCH. Please start a new game.
---------------------------------------------------------

Version 3.0d changes:
---------------------------------------------------------
Buffed a mid-game weapon.
Saves from version 3.0 3.0a 3.0b 3.0c will work perfectly!
Saves from all other previous versions WILL GLITCH. Please start a new game.
---------------------------------------------------------

Version 3.0c changes:
---------------------------------------------------------
More balance adjustments to endgame gears.
Saves from version 3.0 3.0a 3.0b will work perfectly!
Saves from all other previous versions WILL GLITCH. Please start a new game.
---------------------------------------------------------

Version 3.0b changes:
---------------------------------------------------------
Minor buffs to certain endgame weapons.
Saves from version 3.0 and 3.0a will work perfectly!
Saves from all other previous versions WILL GLITCH. Please start a new game.
---------------------------------------------------------

Version 3.0a changes:
---------------------------------------------------------
Minor update that fixes the Immunity bug that affects characters who puts on and then removes the Adamant Armor and/or Glass Helmet, which resulted in a PERMANENT extreme weakness to fire and ice! Thanks to Grimoire LD for the bugfix patch!
Saves from version 3.0 will work perfectly!
Saves from all other previous versions WILL GLITCH. Please start a new game and enjoy!
---------------------------------------------------------

Version 3.0 changes:
---------------------------------------------------------
Huge update!
New attack animation! Characters now swing their weapons & attack multiple times depending on their level! Huge thanks to chillyfeez for this very special mod!! :D
3 new weapons! One of which is another endgame weapon that requires some discovering and defeating a new OP boss to acquire! Another one is a near-endgame weapon that also requires some searching to obtain.
2 brand new boss fights!
1 new endgame OP secret boss!
Updated sound effect for the Thunder Slash! This is an improvement over the original where there's an awkward silence in its swing animation. Again huge thanks to chillyfeez for help with this improvement! :)
Updates and buffs to various enemies and bosses.
Updates to various dialogs.
Brand new hidden secrets at endgame that contain new weapons and bosses!!
New areas at endgame!
Plus many more minor changes and edits.
Saves from previous versions WILL GLITCH. Please start a new game and enjoy! :)
---------------------------------------------------------

Version 2.20c changes:
---------------------------------------------------------
Minor update to AI's script.

Saves from version 2.10a 2.10b 2.10c 2.10d 2.20 2.20a 2.20b will work perfectly!
Saves from version 2.0 2.0a 2.0b 2.0c 2.10 might have minor issues. The core game will work fine but items/chests have been added/moved around so you might miss out on certain new items. Whether or not your save will work depends on where you are in the game: If you are already in the final dungeon, the chances are you will miss out on some newly added items, it's advised that you load a save from before entering the Lunar Subterrane. Saves before the final dungeon should work without issues.
Saves from versions before 2.0 WILL GLITCH. Please start a new game.
---------------------------------------------------------

Version 2.20b changes:
---------------------------------------------------------
Updated initial equipment for Kain.
Updated enemy drops for some bosses.

Saves from version 2.10a 2.10b 2.10c 2.10d 2.20 2.20a will work perfectly!
Saves from version 2.0 2.0a 2.0b 2.0c 2.10 might have minor issues.
Saves from versions before 2.0 WILL GLITCH. Please start a new game.
---------------------------------------------------------

Version 2.20a changes:
---------------------------------------------------------
Child Rydia now has more interesting White Spells to use for a limited time! :)
Updated the Magma Giant's stats and boss fight.
Updated some shop content at endgame.
Updated some enemy drops.
Updated and fixed various dialogs.

Saves from version 2.10a 2.10b 2.10c 2.10d 2.20 will work perfectly!
Saves from version 2.0 2.0a 2.0b 2.0c 2.10 might have minor issues.
Saves from versions before 2.0 WILL GLITCH. Please start a new game.
---------------------------------------------------------

Version 2.20 changes:
---------------------------------------------------------
Edge no longer able to equip the Dragon Whip for balance reasons.
Updates to several enemy drops.
Updated an area en route to the super secret boss and weapon.

Saves from version 2.10a 2.10b 2.10c 2.10d will work perfectly!
Saves from version 2.0 2.0a 2.0b 2.0c 2.10 might have minor issues.
Saves from versions before 2.0 WILL GLITCH. Please start a new game.
---------------------------------------------------------

Version 2.10d changes:
---------------------------------------------------------
Big thanks to chillyfeez and Myself086 for the improved SPRINTING function by holding the Y button in towns and dungeons! You can still SPRINT in the overworlds and slow down airships toggling the Y button while standing still.

Saves from version 2.10a 2.10b 2.10c will work perfectly!
Saves from version 2.0 2.0a 2.0b 2.0c 2.10 might have minor issues.
Saves from versions before 2.0 WILL GLITCH. Please start a new game.
---------------------------------------------------------

Version 2.10c changes:
---------------------------------------------------------
Minor buffs to various weapons.
Saves from version 2.10a and 2.10b will work perfectly!
Saves from version 2.0 2.0a 2.0b 2.0c 2.10 might have minor issues.
Saves from versions before 2.0 WILL GLITCH. Please start a new game.
---------------------------------------------------------

Version 2.10b changes:
---------------------------------------------------------
Minor updates to powers for weapons used as items.
Minor buffs/nerfs to various weapons.
Minor updates to weapons palettes.
Minor texts updates.
Minor spell animation update.
Saves from version 2.10a will work perfectly!
Saves from version 2.0 2.0a 2.0b 2.0c 2.10 might have minor issues.
Saves from versions before 2.0 WILL GLITCH. Please start a new game.
---------------------------------------------------------

Version 2.10a changes:
---------------------------------------------------------
Updated several chests placements and enemy drops for game balance.
Updated boss script for Illusion.
Saves from version 2.0 2.0a 2.0b 2.0c 2.10 might have minor issues.
Saves from versions before 2.0 WILL GLITCH. Please start a new game.
---------------------------------------------------------

Version 2.10 changes:
---------------------------------------------------------
Big thanks to b0ardface for helping to fix the attack power overflow glitch! Now several endgame weapons have an attack power of 255 and do not overflow when equipping them!
Saves from version 2.0 2.0a 2.0b 2.0c will work perfectly!
Saves from versions before 2.0 WILL GLITCH. It's advised that you start a new game.
---------------------------------------------------------

Version 2.0c changes:
---------------------------------------------------------
Minor update to Cagnazzo's attacks and stats.
Minor update to certain items drops.
Saves from version 2.0 2.0a 2.0b will work perfectly!
Saves from versions before 2.0 WILL GLITCH. It's advised that you start a new game.
---------------------------------------------------------

Version 2.0b changes:
---------------------------------------------------------
Minor update to the Boss at the Tower of Babil entrance.
Saves from version 2.0 and 2.0a will work perfectly!
Saves from versions before 2.0 WILL GLITCH. It's advised that you start a new game.
---------------------------------------------------------

Version 2.0a changes:
---------------------------------------------------------
Updated Boss fight at the Tower of Babil entrance to be more interesting and rewarding.
Other minor bug fixes and edits.
Saves from version 2.0 will work perfectly!
Saves from versions before 2.0 WILL GLITCH. It's advised that you start a new game.
---------------------------------------------------------

Version 2.0 changes:
---------------------------------------------------------
Huge update!
Dark Knight Cecil now dual-wields and is 2-handed!! Have fun! :)
3 new enemies! 2 bosses and 1 regular enemy.
5 new boss fights! 1 just before half way and 4 at endgame.
3 endgame weapons now obtainable in final hidden area of the game instead of relying on ultra-rare drops.
2 new shields!
1 brand new OP endgame weapon that requires finding hidden path and defeating optional OP boss to acquire.
Brand new hidden areas at endgame that contain new weapons and bosses!!
New areas at endgame!
Certain characters can now equip more weapons!
Plus many more minor changes and edits.
Saves from previous versions WILL GLITCH. It's advised that you start a new game.
---------------------------------------------------------

Version 1.30 changes:
---------------------------------------------------------
Equipment Screen Mod is now implemented and you can now see the equipment stats much like in the later Final Fantasy games! Huge thanks to Crow! for help implementing this amazing feature!
Saves from version 1.20 and 1.10b will work without problems!
Saves from version 1.10 and 1.10a will work. However, if any of your characters has already lost the ability to do critical hits, this update won't 'revive' their ability to do critical. In this case, you'll need to start a new game unfortunately.
Saves from versions before 1.10 might glitch. The core game will work fine but items/chests have been moved around so you might miss out on certain items. It's advised that you start a new game.
---------------------------------------------------------

Version 1.20 changes:
---------------------------------------------------------
Added an extra save point in Lunar Core.
You are no longer required to battle the AI again after the initial fight.
Buffed Ultima Weapon(Boss).
Added shortcut in Tower of Babil to make the escape after Yang less tedious.
Saves from version 1.10b will work without problems!
Saves from version 1.10 and 1.10a will work. However, if any of your characters has already lost the ability to do critical hits, this update won't 'revive' their ability to do critical. In this case, you'll need to start a new game unfortunately.
Saves from versions before 1.10 might glitch. The core game will work fine but items/chests have been moved around so you might miss out on certain items. It's advised that you start a new game.
---------------------------------------------------------

Version 1.10b changes:
---------------------------------------------------------
Fixed several bugs that can cause players to permanently lose the ability to do critical hits. Special thanks to chillyfeez and Grimoire LD for indentifying and fixing the bug!
Buff several endgame weapons.
Fixed minor bugs and glitches.
Updated text. Thanks to vivify93 and chillyfeez for the help!
Saves from version 1.10 and 1.10a will work. However, if any of your characters has already lost the ability to do critical hits, this update won't 'revive' their ability to do critical. In this case, you'll need to start a new game unfortunately.
Saves from versions before 1.10 might glitch. The core game will work fine but items/chests have been moved around so you might miss out on certain items. It's advised that you start a new game.
---------------------------------------------------------

Version 1.10a changes:
---------------------------------------------------------
Removed the 'no critical' bit that was erroneously applied to a number of weapons. You can now do critical hits using ALL weapons including the Ultima Weapon!
Minor update to some color palettes.
Saves from version 1.10 will work perfectly!
Saves from versions before 1.10 might glitch. The core game will work fine but items/chests have been moved around so you might miss out on certain items. It's advised that you start a new game.
---------------------------------------------------------

Version 1.10 changes:
---------------------------------------------------------
Added a brand new area!
Lightbringer Sword and Tempest Katana now require a boss fight to obtain!
Various map edits.
Added new dialogs.
Updated an enemy's drop list.
Saves from previous versions might glitch. The core game will work fine but items/chests have been moved around so you might miss out on certain items. It's advised that you start a new game.
---------------------------------------------------------

Version 1.0c changes:
---------------------------------------------------------
Edge is now able to equip Whips!
You can now return from Zemus' room.
Gave NPC hint on how to reach the Ultima Weapon sword.
Various minor map edits.
Updated various texts.
Updated various enemies' drop list.
Saves from all previous versions(1.0, 1.0a, 1.0b) will work.
---------------------------------------------------------

Version 1.0b changes:
---------------------------------------------------------
Cat Claw - Added Curse and Stun effects.
Fixed King Fabul dialog from Doom to Deathbringer to match the in-game weapon name.
Vulture now always drops Cockatrice summon.
Updated various enemies' drop list. Improving them.
Saves from both previous versions(1.0 and 1.0a) will work.
---------------------------------------------------------

Version 1.0a changes:
---------------------------------------------------------
Rising Sun - Buffed attack power from 50 to 52.
Tempest Sword - Buffed attack power from 70 to 80.
Saves from version 1.0 will work.
---------------------------------------------------------

List of features, additions and changes:
---------------------------------------------------------
1) 32 New Weapons! Including Ultima Weapon!
2) 22 New Spells! Also revamped existing spells so the useless ones are now useful!
3) New Equipment Screen with DETAILED buffs and stats!! Plus new Armors and Gears.
4) New commands for characters and end-game party.
5) New events! New side quests! New enemies!!
6) 23 New bosses!! New areas! New endgame scenarios!!
7) New attack/swing animation! New sound effects! New weapon graphics!!
8) Revamped shops/equipment and balanced their progression.
9) Dark Knight Cecil now dual-wields and is 2-handed!!
10) Edge is now buffed and very potent offensively!* He can also steal items much easier now!
11) Rydia has also been buffed(slightly). It's a surprise!
12) Cecil has been buffed as a tank. He's still strong offensively, but he's now able to block physical attacks for wounded members without much problems. He also now has a slew of new defensive buffing spells and commands.
13) Rosa can use more White Mage combative gears and a final white spell.
14) Kain has a few new offensive buffing white spells at endgame and new commands as he rejoins the team.
15) Rare items and summons now drop much easier! This hack is designed as a 'play-through' without grinding.**
16) Many enemies now have meaningful rare drops, and all end-game enemies now have rare ultimate drops!
17) New thrown weapons and back-row weapons!
18) Lots of secrets that can lead to early acquirement of better equipment!
19) Few minor tweaks to the base game such as save points, etc.
20) Useless finds now replaced with good items or equipment!
21) All weapons/armors used by characters no longer in party are now usable by at least one character from the end-game party!
22) MOST items/equipment are now non-missable. Meaning they will be acquirable in some ways at end-game. (not including unique ones such as Excalibur, etc. so don't throw those for 100% games!)

* Edge always felt a bit useless at end-game. I see the intent was for him to be a well-rounded, jack of all trades character but I think that fell short and the end result is he's really not that good in anything. I buffed him so he's now capable both physically and magically! He has new spells, new gears, and end-game steals have good items as opposed to useless junk in the vanilla version.
** More copies of endgame, OP and ULTRA rare items will still require grinding to acquire.
---------------------------------------------------------

Other notes:
---------------------------------------------------------
As the vanilla version was a very easy game, here's what I did with this hack's difficulty:
-About 1/3 into the game, the difficulty starts to increase slightly from the vanilla game.
-At around the events after the Sealed Cave, the game's difficulty ramps up.
-After the last save point in the last dungeon, the game becomes 'Nintendo hard'. Casual players would likely not make it and might need to grind a bit. Veterans of the game should still have no problem beating it.  ;)
...
-After witnessing many players on streams having frustration at the last stretch of the game, I've added an extra save point plus you are no longer required to battle the AI again after the initial fight. Hope this helps alleviate some of the frustrations at endgame!

Ultima is my favorite RPG series growing up and Ultima from later FF games has been added to this hack, hence naming this hack: Final Fantasy IV - Ultima
---------------------------------------------------------

Tools and resources used:
---------------------------------------------------------
ff4kster, FFIV Project II, FF4ed, FlexHEX, Tile Layer Pro, snes9x, zsnes, SD2SNES, discord and romhacking.net.
---------------------------------------------------------

Special thanks:
---------------------------------------------------------
I would first like to give credits to chillyfeez, Pinkpuff, vivify93, Fauntleroy, Yousei, Grimoire LD, b0ardface and Crow! Pinkpuff and Fauntleroy for their inspiration with Unprecedented Crisis and Golbez Edition. Pinkpuff for the AMAZING ff4kster editor! This hack would NOT have been possible without it! Yousei for the FF4ed editor as it was the only one I found that allowed me to edit the world maps! Huge thanks also to vivify93 for allowing us to use Project II as a base! I chose to use Project II because it's the closest to FF2US, with most of the dummied out content added back in. Also, a very special thanks to chillyfeez and Grimoire LD for indentifying and fixing the critical hit bug! Thanks to chillyfeez again and Myself086 also for the improved version of the SPRINT function! Much thanks to chillyfeez again for the multiple attack swings mod and help with improving the sound effect for the Thunder Slash! Another HUGE thanks to chillyfeez for the help with new enemy graphics!! Grimoire LD again for the Immunity bugifx patch. A very very special thanks to b0ardface from the Free Enterprise FF4 Randomizer mod (http://ff4fe.com/) for fixing the attack power overflow glitch! Last but not least, huge thanks to Crow! for help implementing the Equipment Screen Mod! Crow! is also the author of the amazing FF4 randomizer called The Lunarian Shuffle. You can find more info for his works at the following: Twitch channel (https://www.twitch.tv/iicrowii) and The Lunarian Shuffle's official blog (https://ff4-lunarianshuffle.blogspot.com/). 
---------------------------------------------------------

Acknowledgements and Credits:
---------------------------------------------------------
SQUARE for this amazing game.
Nintendo for licensing the game in the US.
---------------------------------------------------------

Files included in zip:
---------------------------------------------------------
Final Fantasy IV - Ultima v6.0b no header.ips
Final Fantasy IV - Ultima v6.0b headered.ips
Final Fantasy IV Ultima readme.txt
Weapons List v6.0 (SPOILERS!!).txt
Spells List v6.0 (SPOILERS!!).txt
---------------------------------------------------------

Other info:
---------------------------------------------------------
Please check back in the future for more in-depth guides and boss strategies at:
http://www.8bitfan.info/
8.bit.fan@8bitfan.info
https://discord.gg/4MqjwJt
https://twitter.com/8_bit_fan
https://www.romhacking.net/hacks/4134/
---------------------------------------------------------

2018.9.3 v1.0 by 8-bit fan / 8.bit.fan / butz
2018.9.8 v1.0a by 8-bit fan / 8.bit.fan / butz
2018.9.15 v1.0b by 8-bit fan / 8.bit.fan / butz
2018.9.22 v1.0c by 8-bit fan / 8.bit.fan / butz
2018.10.5 v1.10 by 8-bit fan / 8.bit.fan / butz
2018.11.15 v1.10a by 8-bit fan / 8.bit.fan / butz
2018.12.5 v1.10b by 8-bit fan / 8.bit.fan / butz
2018.12.6 v1.20 by 8-bit fan / 8.bit.fan / butz
2019.1.20 v1.30 by 8-bit fan / 8.bit.fan / butz
2019.2.16 v2.0 by 8-bit fan / 8.bit.fan / butz
2019.2.19 v2.0a by 8-bit fan / 8.bit.fan / butz
2019.2.21 v2.0b by 8-bit fan / 8.bit.fan / butz
2019.2.23 v2.0c by 8-bit fan / 8.bit.fan / butz
2019.2.24 v2.10 by 8-bit fan / 8.bit.fan / butz
2019.2.28 v2.10a by 8-bit fan / 8.bit.fan / butz
2019.3.4 v2.10b by 8-bit fan / 8.bit.fan / butz
2019.3.6 v2.10c by 8-bit fan / 8.bit.fan / butz
2019.3.15 v2.10d by 8-bit fan / 8.bit.fan / butz
2019.4.15 v2.20 by 8-bit fan / 8.bit.fan / butz
2019.4.25 v2.20a by 8-bit fan / 8.bit.fan / butz
2019.4.26 v2.20b by 8-bit fan / 8.bit.fan / butz
2019.4.27 v2.20c by 8-bit fan / 8.bit.fan / butz
2019.5.22 v3.0 by 8-bit fan / 8.bit.fan / butz
2019.5.24 v3.0a by 8-bit fan / 8.bit.fan / butz
2019.5.28 v3.0b by 8-bit fan / 8.bit.fan / butz
2019.5.29 v3.0c by 8-bit fan / 8.bit.fan / butz
2019.5.31 v3.0d by 8-bit fan / 8.bit.fan / butz
2019.6.2 v3.10 by 8-bit fan / 8.bit.fan / butz
2019.6.4 v3.10a by 8-bit fan / 8.bit.fan / butz
2019.6.13 v3.20 by 8-bit fan / 8.bit.fan / butz
2019.6.14 v3.21 by 8-bit fan / 8.bit.fan / butz
2019.6.17 v3.21a by 8-bit fan / 8.bit.fan / butz
2019.6.18 v3.21b by 8-bit fan / 8.bit.fan / butz
2019.6.20 v3.21c by 8-bit fan / 8.bit.fan / butz
2019.6.25 v3.40 by 8-bit fan / 8.bit.fan / butz
2019.7.12 v4.0 by 8-bit fan / 8.bit.fan / butz
2019.7.25 v4.10f by 8-bit fan / 8.bit.fan / butz
2019.8.8 v4.21f by 8-bit fan / 8.bit.fan / butz
2019.8.22 v4.31f by 8-bit fan / 8.bit.fan / butz
2019.8.26 v4.32f by 8-bit fan / 8.bit.fan / butz
2019.10.8 v5.0f by 8-bit fan / 8.bit.fan / butz
2019.10.12 v5.01f by 8-bit fan / 8.bit.fan / butz
2019.10.14 v5.10f by 8-bit fan / 8.bit.fan / butz
2019.10.18 v5.12f by 8-bit fan / 8.bit.fan / butz
2019.10.28 v5.13f by 8-bit fan / 8.bit.fan / butz
2019.11.1 v5.14f by 8-bit fan / 8.bit.fan / butz
2019.11.2 v5.20f by 8-bit fan / 8.bit.fan / butz
2019.11.3 v5.21f by 8-bit fan / 8.bit.fan / butz
2019.11.7 v5.30 by 8-bit fan / 8.bit.fan / butz
2019.11.8 v5.31 by 8-bit fan / 8.bit.fan / butz
2019.11.9 v5.32 by 8-bit fan / 8.bit.fan / butz
2019.11.10 v5.32! by 8-bit fan / 8.bit.fan / butz
2019.11.13 v5.40 by 8-bit fan / 8.bit.fan / butz
2019.11.14 v5.41 by 8-bit fan / 8.bit.fan / butz
2019.11.22 v5.42 by 8-bit fan / 8.bit.fan / butz
2019.12.23 v6.0 by 8-bit fan / 8.bit.fan / butz
2019.12.24 v6.0a by 8-bit fan / 8.bit.fan / butz
2019.12.25 v6.0b by 8-bit fan / 8.bit.fan / butz