Choumahou tairiku WOZZ 8x8 text translation
-------------------------------------------

Translation & Hacking by  
      akujin (akujin_@hotmail.com)

-------------------------------------------

Patching instructions for those who need
them:

1)Unzip the ROM, patch, and Snestool into
the same directory.
2)Run Snestool
3)Press the "u" key on your keyboard (For
"U"se IPS)
4)Highlight WOZZ8X8.IPS in the left-hand 
pane and press "enter"
5)Highlight the name of the ROM (WOZZ.SMC 
for example) in the left-hand pane and 
press "enter"

There! It's patched! Now play it in the
Emu of your choice.

-------------------------------------------

I originally created this patch a few
months ago when I decided to play through
the game. I dumped/ translated/ reinserted
all of the 8x8 font text (menues, spells,
items, monsters, etc.), except for the
tactic menu options. The main dialogue
seems to be compressed somehow. At any rate
I didn't change any of the main dialogue
text other than to replace the English font
that was already there. And I only did that
so I could mess around with the VWF width
table.
I recently found this patch again and
decided there might be others out there who
would like to check it out. It's a fairly
good game. Definitely a game worth playing
through, especialy if you can read the
dialogue which is hilarious in places. I
currently have no plans to do any more work
on this game. Maybe someday I'll finish the
walkthrough I was thinking about writing
for it. I only hacked this stuff as a
learning experience, but if a skilled group
decides to fully translate this game
someday I would love to help out.
(email me!)

-------------------------------------------

Translation Project Homepage:
http://members.xoom.com/akujin_/index.html

-------------------------------------------
Feel free to put this patch up on your
webpage, but please leave this file in the
.zip so people know where it came from.