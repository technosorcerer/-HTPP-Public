Addams Family Values - Boss Rush 1.0
2019 Billy Time! Games 
Special Thanks to Jlukas for his valuable insight, knowledge and troubleshooting. None of this would be possible without him. :)

How to Patch:
1.Grab a headered copy of Addams Family Values (U)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch you rom with the included BPS file

The main goal of this hack is to defeat all of the game's seven bosses one after the other.
Some bosses will refill your health and increase your health cap.
Your inventory is limited and finite, All eight cookies are provided alongside Lurch's Bowling Ball, Amulet of True Sight and The Shockwave.
All other gates and doors are sealed, No other family member is present to help you.
Gameplay Improvements from Afterlife Edition have been included for an Improved Gameplay Experience. (https://www.romhacking.net/hacks/4837/)  

Changelog:
(12/28/2019): Initial Release. 
*Romit Teleport to Jelby Boss no longer throws up SRAM Errors
*Neo Plant Features Teleport to Ma Hench Boss no longer throws up SRAM Errors 
(12/24/2019): Christmas Beta