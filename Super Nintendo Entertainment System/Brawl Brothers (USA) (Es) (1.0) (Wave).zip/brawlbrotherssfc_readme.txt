Brawl Brothers (Super Nintendo)
Traducción al Español v1.0 (18/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Brawl Brothers (U) [!].smc
MD5: 96c2f98baf38dd63c6a466688d7099f1
SHA1: 01bf09e99d9b7baa88f852293ec941cf863f7009
CRC32: e822065c
1572864 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --