-----------------------------------------------
       BREATH OF FIRE TEXT RELOCATOR
	       MADE BY GEMINI (2016)
-----------------------------------------------

This is a simple hack I created for the Italian translation of
Breath of Fire. It includes a script that moves text data, text
pointers, and dictionary data in an expanded area of the ROM.

It consists of a script to be compiled with xkas plus. The script
uses a few macros that you can change in order to resize the
first bank of text, and split it evenly with the second main one.
This is because text banks are internally treated as a big joined
one, but you can split it as you need by changing the macro
bank0_cnt in the script.

The package comes with compile.bat, which will rebuild a file
named bof.sfc with all the changes. Either rename a vanilla rom
with that name or change compile.bat to whatever name you prefer.

NOTE: despite the game being a Lo-Rom, text banks can still encode
as full 64 KB blocks, like on Hi-Rom. This is because the game has
internal hackish code that helps it cross bank boundaries.

NOTE 2: The script will also expand the ROM to 2 full MB.
