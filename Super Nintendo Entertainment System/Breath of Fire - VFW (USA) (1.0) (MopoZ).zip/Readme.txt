Breath of Fire I


The game added VWF. It is used in all dialogs. In messange Menu \ Shop \ battle. Just added H-DMA and transparency to the dialogue box. Changed mapper to Hi-rom. Rewritten sram system.
This hack can be used to translation or re-translation (but add me to the authors, just let me know about new ideas that you want xD).

Uses ROM non-header.

-----------------------
VWF Monster Name
-----------------------

The same way I did in the game vwf for the names of monsters during the battle. With the normal V-sync it does not conflict. But on snes9x v1.51 does not work.
If you go to the VWF monsters, then at $cbf000 ($bf000) put jsl $c60000

for xkas
---------------
org $cbf000 
 jsl $c60000
---------------

for HEX-editors
----------------
 $22 $00 $00 $C6
----------------


Ver.1
Enjoy xD
gegMopo3 aka MopoZ
gegmopo3@list.ru
01.31.2011