				Arcana Easy Type v1.0
		          Final release (November 17th 2011)

Basically this makes the game so much easier.  Now you'll be able to play this great game without having to worry about grinding out level after level and thus you waste no time.  I made this for me primarily but I'm sure someone else would get some use out of it.  

What's been changed:
-Adjusted the character stats to 999 HP/MP and 99 for the rest.






Note: This is a final patch and is complete.  If you find any issues and or bugs please email me.  Suggestions are also welcomed.

http://www.jce3000gt.com/
jce3000gt@gmail.com