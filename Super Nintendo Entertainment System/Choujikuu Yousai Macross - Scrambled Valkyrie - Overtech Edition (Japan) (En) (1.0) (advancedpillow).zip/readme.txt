Choujikuu Yousai Macross - Scrambled Valkyrie (Japan).sfc
IPS MD5:	EF01A4D9DEAC670D3A1CD93ECED4C31E
ROM MD5 before:	E11C1D923EA1B2F6A00E5886AA6B6202
ROM MD5 after:	D39B3B6F170472C7618CFAFE93D50413

Mod includes:
- Unlocking stage select
- Adding a controller input to change the morph form bidirectionally
- Setting default controls for changing to L and R
- Reversing the order of animation frames when changing backwards
- Adding a "CASUAL" game rank
-- Doubles health and recovery items to match
-- Takes 2 enemy hits to decrease a weapon level