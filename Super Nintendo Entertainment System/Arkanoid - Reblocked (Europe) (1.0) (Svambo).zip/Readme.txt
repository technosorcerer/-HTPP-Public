ARKANOID REBLOCKED



While the SNES is well known for it's great Jump & Run games and it's brilliant RPGs, it has some quite nice casual games too. Arkanoid is one of them, but it's too long for a quick gaming session and the difficulty level is frustrating sometimes - so why not make an own version?
Arkanoid Reblocked features 38 Videogame related levels and a playtime of roundabout one hour. The difficulty is quite fair so it's suitable to play it with your kids or your non-pro-gamer-friends too.

The Zip-File contains 2 patches: One for the US-version of Arkanoid, one for the PAL-version. If everything went well with patching the checksum for the game should be ok.


Arkanoid Reblocked was done by:
                    
Hacking   		Svambo           
                     
Editor coding   	Dom aka Doke     
                 
Graphic Decompression	ManakoDE         

Level Design         	Poe              
                     	ffmcloud         
                     	Svambo           
                     	Dom aka Doke     
                                    
Advice & Support  	Sportklaus 
                     	Micah            
                     	Bredator        
                     	Krischan         
                     

This little hack was developed while creating an editor for the game called ArkanEdit. It will soon be released on romhacking.net too. 

Greetings to all the great guys on snesfreaks.de, SNES-Projects.de, romhacking.net and everyone who still loves the SNES in 2020. :-)
