Title: Unsightly Pixel
Author: Gi Nattak
Version: v1.0
Applies to: Chrono Trigger (U)

-----------------------------------------------------------------

Description:

There is a small stray light brown pixel that exists on the town maps thanks to a graphic compression issue. It is quite hard to notice, but once you do I guarantee you will never be able to unsee it. This patch removes that pixel, which is actually part of the upper left house's shadow pixels, but due to how the graphic gets compressed it shares a spot with a totally separate house and thus winds up right in the middle of the grass in front of said house. So removing it barely effects the look of the upper left house's shadowing, and in turn removes this mistake of a pixel from being where it shouldn't be.

-----------------------------------------------------------------

Offset range effected:

043AA0 - 044838

New compressed gfx length: D99
Decompressed length: 1000

-----------------------------------------------------------------

Credits:

Madsiur, for helping break down the issue and providing good info on how to fix it as well as troubleshooting a byte overflow issue with Peer Sprite Viewer.