                                CUTTHROAT ISLAND PARA SUPER NINTENDO  
	                            TRADUZIDO POR UNKNOWN MASTER

                                      WWW.MONKEYSTRADUCOES.COM


                           Informa��es sobre a ROM que foi usada na tradu��o:



Nome do Jogo: Cutthroat Island
ROM Utilizada: Cutthroat Island (U).smc
CRC: 2F0C7D2D 
G�nero: Aventura/Plataforma
Console: SNes (Super Nintendo)
Lan�amento: 1995
Produtora: Software Creations
Distribuidora: Acclaim Entertainment
Jogadores: 2
Checksum: Corrigido





		                    Como aplicar o Patch de Tradu��o:

	O Patch ser� distribu�do em dois formatos diferentes, que s�o IPS-EXE e *.IPS. Voc� pode 
escolher um deles para aplicar na sua ROM para traduz�-la. Fique atento, e dependendo do formato que 
escolher, siga as instru��es do formato escolhido a seguir:


			                  1 - Formato IPS-EXE

	O Patch ser� distribu�do tamb�m no bom e velho formato IPS-EXE, para facilitar a aplica��o do 
mesmo por parte da maioria dos usu�rios. Ele deve ser aplicado na ROM "Cutthroat Island (U).smc", com 
CRC 2F0C7D2D. 
	O Patch s� funcionar� nesta ROM, pois ele checar� o CRC da mesma. Se tentar aplic�-lo em outras 
vers�es com CRCs diferentes, provavelmente n�o funcionar� corretamente.

	Uma vez tendo a ROM correta em m�os, siga os seguintes passos:

1 - Coloque o arquivo "Cutthroat Island BR v1.0.exe" no mesmo diret�rio onde a ROM 
"Cutthroat Island (U).smc" estiver;

2 - Execute o "Cutthroat Island BR v1.0.exe", clique em "Patch" e o jogo j� estar� traduzido e com o 
Checksum corrigido (o Patch ser� aplicado automaticamente);

3 - Divirta-se no emulador :D

	Uma outra maneira de aplicar o Patch � a seguinte:

1 - Execute o arquivo "Cutthroat Island BR v1.0.exe", logo depois clique em "Browse" para procurar onde 
a ROM "Cutthroat Island (U).smc" est� em seu PC e mande abrir;

2 - Clique em "Patch" e o jogo j� estar� traduzido e com o Checksum corrigido; 

3 - Divirta-se no emulador :D

	
			                   2 - Formato *.IPS

	Se optar por aplicar este Patch, tenha em mente que voc� deve ter um aplicador de Patches IPS, 
tais como o LunarIPS. � poss�vel aplic�-lo com outras ferramentas que suportam este formato, como o 
Ninja Patcher ou mesmo o IPSWin. Para evitar problemas, lembre-se de que ele deve ser aplicado na ROM 
"Cutthroat Island (U).smc" com CRC 2F0C7D2D.

	Os programas de aplica��o de Patches, voc� encontra na �rea de download de Utilit�rios do PO.B.R.E., 
categoria "Patching".
 
	
	Usarei aqui o LunarIPS como exemplo:

1 - Abra o LunarIPS e clique em "Apply IPS Patch";

2 - Ele primeiramente pedir� o Patch IPS, ent�o navegue at� onde o Patch "Cutthroat Island BR v1.0.ips"
est� e mande abrir;

3 - Logo depois, ele pedir� o arquivo (ROM) para aplicar o Patch, ent�o navegue at� onde a ROM 
"Cutthroat Island (U).smc" est� e mande abrir;

4 - O Patch j� estar� aplicado, e o jogo j� estar� traduzido e com o Checksum corrigido :P

5 - Divirta-se no emulador!




                                     Informa��es sobre a Tradu��o:



Gr�ficos: 100%
Ponteiros: 100%
Scripts: 100%
Outros Textos: 100%
Tabela: 100%
Acentos: 100%
Progresso Geral: 100%


Grupo:  Monkey's Tradu��es 
Site:  http://www.monkeystraducoes.com/                                             
ROMHacking:  Unknown Master
Tradu��o/Extra��o/Inser��o dos Textos: Unknown Master
Extra��o/Edi��o/Inser��o Gr�fica: Unknown Master
Beta-Tester e Revis�o: Unknown Master

	O game foi jogado at� o fim por mim (emulador) e o mesmo rodou 100% sem nenhum bug ou algo do 
g�nero. Todos os dois formatos de Patch (*.IPS e IPS-EXE) foram testados e todos est�o funcionando 
perfeitamente. Todos os di�logos/textos/menus/gr�ficos necess�rios do game est�o traduzidos e n�o h� 
nenhuma quebra de linha ou quaisquer outros bugs. 

	Usei o Snes9x para emular, mas se poss�vel, testem-no em outros emuladores.

	Mesmo assim, se por acaso encontrar algum bug em rela��o � tradu��o, por favor, entre em contato 
comigo e reporte.


  
		                         Coment�rios do Tradutor:


	Bom, creio que todos j� conhecem, ou pelo menos j� ouviram falar deste jogo, Cutthroat Island, mais
conhecido por "Ilha da Garganta Cortada". O filme foi lan�ado aqui no Brasil e fez muito sucesso, mas o game
parece n�o ter feito muito sucesso na �poca em que foi lan�ado. Eu acredito que seja porque ele foi lan�ado
para um p�blico jovem, mas ele � extremamente dif�cil at� mesmo para um adulto. A dificuldade do jogo �
bem elevada. O jogo aqui traduzido � para SNes, mas ele tamb�m foi lan�ado para outras plataformas, como o
Mega Drive e Game Boy.
	Lembro-me de que eu o jogava bastante e sempre morria nas primeiras fases. Como resultado, at� hoje
eu o reconhe�o como um dos jogos mais dif�ceis do SNes, pois mesmo sabendo do que vai ocorrer, voc� muitas
vezes morre. E o que � pior: n�o h� passwords e nem continues, ou seja, morreu, volta TUDO de novo... Hoje em 
dia, eu o termino, pois agora j� sou um "macaco" velho, xD... Contarei a voc�s atrav�s deste breve coment�rio
os motivos que me levaram a traduzir este jogo:

	Estava l�, eu relaxando em um domingo qualquer com alguns colegas e levei o meu DVD cheio de ROMs de
SNes para PS2, para jogarmos durante a tarde. Um deles escolheu esse jogo, e logo surgiram os coment�rios do 
tipo "Nossa, eu jogava muito esse jogo!", "Puxa, eu nunca zerei este jogo maldito...". Como eles sabem que eu 
traduzo jogos, me pediram que eu traduzisse esse e depois levasse pra gente jogar ele em PT-BR. De tanto insistirem,
eu peguei essa ROM do DVD de SNes e dei uma r�pida analisada para ver como ela funcionava, e felizmente o jogo
� muito f�cil de traduzir, em gr�ficos e textos. N�o resisti e atendi ao pedido dos meus amigos... Fui l� e o
traduzi! Foi legal, pois me fez lembrar dos velhos tempos em que eu xingava o coitado do SNes por morrer tanto 
no jogo e nunca chegar na quinta fase, quando ele nem tinha culpa no cart�rio. Gra�as � esse projeto, consegui 
terminar o jogo completando 100% dele, e inclusive descobri coisas que eu NUNCA SUSPEITEI que existisse nesse
jogo! 
	O que �? Bem, eu os desafio a terminar o jogo encontrando as 5 arcas secretas. Voc�s ver�o por si 
mesmos quando zerarem o jogo! Eu os desejo sorte... Voc�s v�o precisar!

				   

		                      Contato com o Autor da Tradu��o:


	Para elogios, bugs, cr�ticas sobre essa tradu��o ou mesmo amizade, poder� encontrar-me na medida do 
poss�vel em:

manuelytto444@gmail.com
manuelytto_007@yahoo.com.br



			                   Agradecimentos Especiais:


- Primeiramente a Deus, pois sem Ele, eu nada seria;

- Ao grupo Monkey's Tradu��es, por permitir que fa�a parte da equipe, mesmo n�o tendo o tempo que 
desejaria para estar em contato freq�ente com eles;

- Aos meus amigos que insistiram para que eu traduzisse esse jogo xD~

- � todos aqueles que prestigiam nossos trabalhos de tradu��o;

- Ao PO.B.R.E. (www.romhackers.org), por reunir tantos ROMHackers em um s� ideal.



Unknown Master - "Living and Learning"
