One of the biggest issues of FF4 is the obnoxiously limited amount of inventory space. This optional patch rectifies that by changing the "Change" option in the menu to "Choco". Doing so will allow you access the Fat Chocobo at any point in the game.

To further save inventory space, the "-SORT-" item/option has also been removed to make room. Press X or Y to sort items in the inventory.

The ips patch only works with a patched version of FF4 Ultima in a no-header format.

Patch courtesy and created by Chillyfeez.

If you have any questions or issues, feel free to reach out to our team on the FF4 Ultima Discord at: https://discord.gg/4MqjwJt

Enjoy!!