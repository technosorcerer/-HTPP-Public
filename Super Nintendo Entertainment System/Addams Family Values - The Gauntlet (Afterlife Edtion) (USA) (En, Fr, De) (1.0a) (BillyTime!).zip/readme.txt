Addams Family Values - The Gauntlet 1.0
2020 Billy Time! Games 
Special Thanks to Jlukas for his valuable insight, knowledge and troubleshooting. None of this would be possible without him. :)

How to Patch:
1.Grab a headered copy of Addams Family Values (U)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch you rom with the included BPS file

The main goal of this hack is to complete an amalgamated dungeon. Comprised of several rooms taken from various dungeons, the green house and Debbie's mansion.
Health is limited to Two skulls. 
No bosses are present in this hack.
Your inventory is limited and finite, Only four cookies are provided.
All other gates and doors are sealed, No other family member is present to help you.
Gameplay Improvements from Afterlife Edition have been included for an Improved Gameplay Experience. (https://www.romhacking.net/hacks/4837/)  

Changelog:
(3/26/2020): Initial Release. 