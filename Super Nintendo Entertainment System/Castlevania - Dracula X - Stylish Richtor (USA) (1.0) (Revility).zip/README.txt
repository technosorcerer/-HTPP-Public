CastleVania Dracula X "Evil Richter" Patch
By SyX aka Revility    10/02
website: www.revility.cm
 
-----------------------------------------------------------------
About

If you don't know...
In CastleVania Symphony of the Night you were allowed to play as Richter Belmont.  The funny part was he looked the way he did in DX and not how he was suppose to appear in SOTN. In the Saturn Version SOTN, Nocturne in the Moonlight, you got the chance to play as the way he appeared in the instruction manual and promo art, well it sort of looked like it.  So for my first time graphic hacking, I put Evil Richter in the SNES DX.  I say it came ok. Nuff said'


---------------------------------------------------------------------
HOW DO I USE IT?


This is NOT a ROM, it's an IPS file; a patch for a ROM. You must already have an NTSC Dracula X ROM.

To apply the patch, go to any website with ROM hacking utilities (www.zophar.net , www.romhacking.org , http://www.cg-games.net , etc.) and grab an IPS patcher. The favorite seems to be SNESTOOL for DOS, but there's stuff like WinIPS as well. Just follow the directions that come with the program. For SNESTOOL, select "use IPS", navigate the directories with the arrow keys, select the patch, then select the ROM. Couldn't be simpler. And you may want to back up your ROM.


If you still need more information, go to 

http://www.zophar.net/trans/ipsfaq.html

--------------------------------------------------------------------


How I did it-

I used just tile layer pro and thats it.

--------------------------------------------------------------------

Relations FAQ

Q1- Can I upload this hack to my website?

A- Sure! Just make sure you use this zip file with the filenames and documentation intact. I'd rather you not offer a patched ROM. If you must, please zip it and include this FAQ-README file. 

Also, please don't post the patched ROM to any newsgroup on USENET without this readme file included.

Q2- Can I translate this FAQ into another language?

A- Yes, please do.

Q3- I am a member of a 1337 R0Mh4x0ring group, and we need a guy who's not adverse to spending countless hours editing 16 bit graphics! Will you join us? We'll put your name in the credits!

A- Maybe... O_o

Q4 You could have done better... why not?

A- First time doing this and putting the tiles back together in the viewer and trying to get look in sink is a pain in the arse for this game. Tough Titty.

