3x3 Eyes: Juuma Houkan translation Patch version 1.01 by Atomizer_Zero

Changelog:

2nd February 2017 = version 1.01
 - Added missing lines for saving on Chapter 4. (thanks sdcSpade for the report)

25th January 2017 - version 1.0
 - Full release. Fully playable/completable!

22nd January 2017 - version 0.9
 - Chapter 4A completed.
 - Added missing text character.

17th January 2017 - version 0.8
 - Finished Chapter 3.

16th January 2017 - version 0.7
 - Fixed a typo.
 - Added a missing line in chapter 2.
 - Added a missing line in chapter 3.

14th January 2017 - version 0.6
 - Added missing lines from chapter 3.

13th January 2017 - version 0.5
 - Fixed broken message box.
 - Edited dialogue to make more sense.
 - Added most of chapter 3.

12th January 2017 - version 0.4
 - Fixed typos.
 - Edited some message boxes.

11th January 2017 - version 0.3
 - Chapter 2 completely translated (Shiria path and Pai path).

9th January 2017 - version 0.2
 - Fixed some typo's.
 - Fixed a broken message box.
 - Fixed Chapter screen's allignment.
 - Adjusted a couple of message boxes.
 - Added text for Chapter 2 (with Pai).

4th January 2017 - version 0.1
 - Initial release.
 - Battle menu translated (may change at a later date)
 - Title screen idle intro translated.
 - Chapter 1 completely translated.

Patching information:

Apply .ips patch to unheadered rom of 3x3 Eyes:Juuma Houkan(Japan).sfc 

Play!

Known Issues:

 - During battles, the Jump ablities description is off centered to the rest of the ability descriptions. This is tricky to fix, but i'll look into it when the game is done.

 - Some message boxes are a bit too big for the text. This is going to be fixed when the game is fully translated.

Contact Info:

Submit bug reports, errors in translation or something like that to my twitter @Atomizer_Zero

Do not ask me where to get the Rom for this game. Google is your friend here.

Special Thanks:

Romhacking.net Forum - Without their guides and their users, this wouldn't even have began. 

Assemblergames.com Forum - Everyone is super awesome and supportive on there. Give them a visit!

-=FamilyGuy=- on Assemblergames forum. Made a nifty program for me to aid in the translation process.

@AkiHizirino - A good friend who has helped with some translation quirks and provided loads of support.

mkwong98 - For the original script and translation, on gamefaqs.com.

3x3Eyes.com - Awesome website full of information about 3x3 Eyes and related materials. 

ReadMe 2017 Atomizer_Zero.