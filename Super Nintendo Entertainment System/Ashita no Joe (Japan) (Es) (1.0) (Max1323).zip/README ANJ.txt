"Ashita no Joe"
Traducci�n al Espa�ol Ver. 1.0 (17/03/2019)
por Max1323 (maxmuruchi@gmail.com)
Basado en la traducci�n de Vice Translation.
---------------------------------------------------
Descripci�n:
Ashita no Joe basado en el manga del mismo nombre. 
Juego de boxeo en el que tendras que derribar a tus 
contrincantes. 
 
Desarrollado: Wave
Publicado:    K Amusement Leasing
Lanzamiento:  27/11/1992 (Jap�n)             
---------------------------------------------------
Acerca del proyecto:
Se tradujo los di�logos.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS

Ashita no Joe (J).sfc (No-Header)
File MD5      C7F80EB13AD9EE5FB5598B24002B6113        
File SHA-1    36A58CF915F394875B1FF6CB9BCA539E0CB4BDA0
File CRC32    6B54BE97                                                      File Size     1.00 MB
                              
                           
                              
                              
                             
                       
