Captain Commando
Traducci�n al Espa�ol v1.1 (08/05/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Captain Commando
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Captain Commando
-----------------
Port de la recreativa para SNES, versi�n europea.
v1.1:Arreglada alguna frase al derrotar un jefe.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Captain Commando (E) [!].smc
2.097.152 bytes
CRC32: 5b9aa73a
MD5: 36f54352e7aba538529913707a734f9e
SHA1: 92a25bad603b74df95ccadcab08015ee77bd671d

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --