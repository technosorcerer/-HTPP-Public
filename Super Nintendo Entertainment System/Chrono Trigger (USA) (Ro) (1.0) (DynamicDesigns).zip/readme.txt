
Chrono Trigger - English Version
------------------------------------------------------------------------------------------------------------------------------------------------------
contained
1) Introduction
2) Use
3) Comments
-------------------------------------------------------------------------------------------------------------------------------------------------------
1) INTRODUCTION
-------------------------------------------------------------------------------------------------------------------------------------------------------
This translation was created using Chronotrigger Texteditor V 1.00 (from: http://www.romhacking.net/utils/296/) and Temporal Flux (from the same site).
You can distribute this translation to whoever you want, just don't change this tab, or try to sell it.
-------------------------------------------------------------------------------------------------------------------------------------------------------
2) USE
-------------------------------------------------------------------------------------------------------------------------------------------------------
To be able to use this .ips, you need a "snes emulator" and a Chrono Trigger game (rom) in English (.smc or .sfc).
Use Google to search for the game and the emulator ("Chrono Trigger rom" / "snes emulator"). I can't give you links unfortunately because we can't
http://www.dynamic-designs.us/, http://www.romhacking.net/ and other translation sites for games. Sorry...
To use this .ips, make sure that the game and the .ips tab have the same name and are in the same place (folder), but do not change the .smc and .ips extension.
That's what I'm going to do with the "zsnes" and "snes9x" emulator. So if the game is called "Chrono Trigger.smc", be sure that the .ips tab is called "Chrono Trigger.ips".
If that doesn't work or you use another emulator, you will need to use a program to apply the .ips tab to the .smc (Use IPS) game. Links to two good programs:
LunarIPS: http://www.romhacking.net/utils/240/ Sau: SNESTool12: http://www.romhacking.net/utils/18/
You may need to use "remove header" on the .smc game with SNESTool12 before applying the .ips tab. The game must be 4.00 MB in "Properties".
If you are using Windows 7, you will need to use the "DOSBox" program in order to use SNESTool12. Drag SNESTL12.exe onto DOSBox.exe and I will open it.
--------------------------------------------------------------------------------------------------------------------------------------------------------
3) COMMENTS
--------------------------------------------------------------------------------------------------------------------------------------------------------
Unfortunately, I could not use the five letters (unicode) in Romanian. This program does not let you save them in the game.
I worked on creating this translation for free and without its affiliation supporting Square-Enix and its other companies ...
So you can't blame me if it doesn't work on your computer if you don't like the translation. But I don't think that's going to be a problem ... I hope!
I translated this game because it was never officially translated into Romanian.
If you like Chrono Trigger, I would recommend buying it to support Square-Enix and encourage them to create such good games.
I changed two names for the characters in the game to sound better in Romanian. Dad was changed to Shin and not to Mu. I changed it so there would be no confusion in the game.
"Katana" is a type of Japanese sword that Crono uses. I used this not to be confused with Frog's swords.
"Poi" is a Hawaiian dish that Lucca talks about once in the game. The two are not grammatical mistakes.
"Reptiles" and "Mystics" are two different species in the game. They are not grammatical mistakes either. "Luminaire" is a technical name for Crono.
"Bowling" is a type of game and "sashimi" is a Japanese dish (slices of curd or smoked fish). The two things are mentioned by Doreen sometime in the game.
People in prehistoric times, 65,000,000 BC (in the game), like Ayla and Kino speak a little bad. So it was with the English version, translated by Ted Woolsey.
And unfortunately, I had very little writing space in the game, so some things look a bit strange in writing (text). I'm sorry about that, but I have nothing to do ...

If you have a question or a comment, you can ask at this forum: http://www.dynamic-designs.us/d-dforum/viewforum.php?f=54.
But please don't ask where the game or emulator is. It can be found very easily using Google ...
If you need help with "patching" the .ips tab with the .smc game, look here: http://www.fantasyanime.com/patching.htm
You can go to this site if you need help somewhere in the game or for information about Chrono Trigger: http://shrines.rpgclassics.com/snes/ct/index.shtml

I would recommend Zsnes V.1.17 for this game. In some parts of the game, you have to press three buttons to enter a password.
You cannot press more than two buttons at once with this emulator, so you must change L and R to the same button for these parts of the game.
After that, you can change them again. That's all I have to say. I worked for a year to translate this game. I hope you like it!
Thanks to http://www.dynamic-designs.us/ for "hosting" (where to find this tab, which can also be found at http://www.romhacking.net/). They also have a "forum".
Translator - Recca / Thanks to Bongo`, Wildbill, Taskforce and Red Soul at http://www.dynamic-designs.us/ for help. We are all team members.