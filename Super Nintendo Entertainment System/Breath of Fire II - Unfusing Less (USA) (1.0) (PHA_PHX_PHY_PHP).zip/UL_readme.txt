===============================================================================
===                        Breath of Fire II (SNES) (US)                    ===
===                           "Unfusing Less" Hack                          ===
===============================================================================

    In the original game, a shamanized player character lost his shaman fusion
every time his HP fell to or below a quarter of his maximum HP, in particular:
  - if ((HP > 0) && (HP <= max_HP/4)), PC entered a wounded (critical health)
    state with modified sprite
  - if (HP <= 0), PC got KO'd

    Those conditions fleshed out into code which, with some variations, was a
part of these in-game situations:
  - getting unfused in battle by taking critical (that puts in critical health)
    or fatal (>= HP) damage by attacks, spells or items
  - getting unfused on overworld by taking critical item damage (Bait/Crappie,
    Wisdom Fruit)
  - getting unfused on overworld by taking critical poison damage

    Other in-game situations the code wasn't part of which led to losing sha-
mans were:
  - getting unfused on overworld by using DivideBL/Defuse Orb
  - getting unfused upon entering a cutscene

    The goal of the "Unfusing Less" hack (abbr. "UL") was to rewrite condi-
tions as to when to perform unfusion, to make the game generally a more enjoy-
able experience (most people's complaint about the shaman system was how easy
it was to lose a shaman and how hard it was to walk back to base to re-apply).

    As of now, things that UL has changed are:
  - shamanized characters will never lose fusion by falling to critical health
    in battle by attacks, spells or items; on overworld - by items and poison.
    However, fatal damage will still unfuse and KO them (not the case with
    items and poison though - those leave characters with 1 HP).
    
    Other instances which the code under question didn't touch are not changed
yet, as they either don't need it, or may require a complete overhaul of game's
code.

===============================================================================
===                                   Usage                                 ===
===============================================================================

    Files attached:
  - "UL_orig.ips" - to apply to "Breath of Fire II (USA).sfc" (checksums below)
    Version of hack for original US version players.
  - "UL_retrans.ips" - to apply to "Breath of Fire II (USA) [En+Hack by \
    d4s+Watercrown v1.2b] (Original Title Screen Music).sfc" (checksums below)
    Version of hack for re-translation players.

    Checksums:
  - "Breath of Fire II (USA).sfc"
    Size : 3,145,728 bytes (3 MiB)
    CRC32: 67CDACC5
    MD5  : e1ff1ed4ad5dbdbe86774920dfb5e9d4
  - "Breath of Fire II (USA) [En+Hack by d4s+Watercrown v1.2b] (Original \
    Title Screen Music).sfc"
    Size : 4,194,304 bytes (4 MiB)
    CRC32: 1169783E
    MD5  : 0d15877595f4d1a3b11e33c801f85b47
    You can get this version from "Breath of Fire II (USA).sfc" by applying
    extra patches from the "re-translation pack".

    IPS patchers: "Lunar IPS".

    Have fun, but also have no warranty for any unspecified behavior. Tested
and it worked fine in my case with SNES9X and HIGAN.

    Hack was made by PHA_PHX_PHY_PHP.
