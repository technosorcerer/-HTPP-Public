two patches are included because there are two dumps of the game.

use ewj2_eur_to_usa_single.xdelta if you have a dump that is a single img file named Earthworm Jim 2 [SLES-00343].img (crc32: ABE93015), after applying the patch rename the img file to Earthworm Jim 2 (USA).bin and use the included cue file.
use ewj2_eur_to_usa_redump.xdelta if you have the redump version that has multiple bin files and apply the patch to Earthworm Jim 2 (Europe) (Track 01).bin (crc32: 0173FAFB).

that's all.
have fun :)