This caused a bunch of Twitter drama when I put it on RHDN so I'm reposting it here with a bit less fanfare
I took a look at the game files for Germs: Nerawareta Machi and realized the script and files are easily extracted and reinserted.
This is my attempt at an English translation, built on top of Mr. Nobody's Spanish translation. Due to limitations on text space, some of the translations will be off. I used machine translation on some of the Japanese lines for clarity. A better version is being worked on by others. If you run into any glaring issues, feel free to shoot me a message. There's almost certainly things I missed. I'll update the patch if I find any.

Made by grundo,
Built on work by Mr. Nobody