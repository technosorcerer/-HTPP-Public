I took a look at the game files for Germs: Nerawareta Machi and realized the script and files are easily extracted and reinserted.
This is my attempt at an English translation, built on top of Mr. Nobody's Spanish translation. It's not complete, and some of the translations are way off due to lack of context. This is a solo project and under a month of work so go easy on me!
Still, it's pretty far along, and at this point I'd say relatively playable. I'm still working on it but would also welcome additional help!


Made by grundo,
Built on work by Mr. Nobody