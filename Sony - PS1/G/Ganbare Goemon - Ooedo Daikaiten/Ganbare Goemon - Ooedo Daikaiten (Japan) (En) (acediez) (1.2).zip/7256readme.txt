========================================================================================
Go for it! Goemon: The Grand Cycle of Oedo (1.2) - 2024.03.29
========================================================================================
This is a complete translation of "Ganbare Goemon - Ooedo Daikaiten" for
the Playstation.
Links: 
	Download Page:
	https://archive.org/download/gfig-tgcoo
	RHDN Project Page:
	https://www.romhacking.net/translations/7256/
	News and support:
	@acediez on Twitter/X
	
Target File:
	Ganbare Goemon - Ooedo Daikaiten (Japan).bin
	MD5: ad7c68d71479ca78749af3623afcdce4
	http://redump.org/disc/20543/
	
The patch format is "xdelta", which can be applied using xdeltaUI:
	xdeltaUI in RHDN
	https://www.romhacking.net/utilities/598/
	
	
About the game
========================================================================================
"Ganbare Goemon: Ooedo Daikaiten" ("Go for it! Goemon: The Grand Cycle of Oedo")
is a single-player action platformer with light exploration elements and first-person
mech battles. It was released at the start of 2001, the same year that would later
see the release of the last game we translated, "Goemon Shin Sedai Shuumei" ("Goemon:
The Successor for a New Generation"). Both were developed by "NOW Production" around
the same time the Goemon Team was working on the PS2 revival, "Boken Jidai Katsugeki"
("Mystical Ninja Goemon Zero.") (Source: @ProjectGoemon on Twitter/X)

The game draws heavily from the second SFC game, both in gameplay and stage design.
It has character appearances from all over the SFC and N64 games. Most notoriously, the
soundtrack is lifted straight from "Goemon's Great Adventure." True to the series'
humor and spirit, the story embraces the theme of recycling. Gameplay-wise, the
revisited stage themes and mechanics serve as a sort of "best of" for the series.

 
About the translation
========================================================================================
This is a complete translation. The whole script has been translated, as well as all
visible text in graphics (leaving aside a few intentional exceptions.) No other changes
have been made to the game. Enjoy!
 
 
Game tips
========================================================================================
- In case you've never played a Goemon game before: "Inns" in towns are where you
  save your progress.
- Use your money. Money’s only purpose in this game is to keep you alive.
  (Except for one quest in the second town.)
  When you get a game over, you lose 1/2 of your current money, so it's better to spend
  some money to stay alive than losing it all:
  Use projectiles to clear up enemies from a distance before making a difficult jump.
  Go to the bath houses for health upgrades.
  Buy armors, they’ll help you preserve your weapon upgrades longer.
- Money and armors are stored in your save file. Extra lives, weapon upgrades and health
  upgrades are not (but you can save money and use bath houses to at least replenish
  the health upgrades.)
- If you lose a boss battle and still have some remaining lives, you can restock
  your defense items in a town, save, and even level up your weapons on an easy stage,
  before going back to retry.
- All four characters have a special ability used with the Triangle button. They're all
  needed to progress on certain stages:
  - Goemon has the chain pipe: a long range attack he can use without spending ryo.
    It's used to swing from the golden square blocks with the manji symbol.
  - Ebisumaru can slowly float downwards (you need to press and hold Triangle. The
    floating starts after the jump.)
  - Yae and Sasuke can transform when they're swimming to go underwater.
- Try every character. They all have different strengths and attack ranges. Some can
  attack downwards (Sasuke Lvl.2, Yae any level), which is pretty useful in certain
  platforming sections. Ebisumaru's floating down technique can also be very useful
  in many stages (not just the ones that make it mandatory.)
 
 
Town Quests
========================================================================================
Each town has a quest to get a “Pass.” You need them to be able to go through the
Exit of the town and move on to the next stage. Talking to people in towns will give
you clues on how to get them.

If you're having trouble with these, here's a step by step:

Hagure Town:
- Look for the Wise Man’s house at the upper right side of town. It’s the first door
  of a building with multiple doors (left to right.)
- After talking to him, backtrack one screen and go to the upper left side of town.
- Enter the building at the far left side. At the end of this small dungeon, you’ll
  find Wise Man’s belly wrap.
- Bring it to him and he’ll give you this town’s Pass.

Gurume Village:
- This town’s Pass is for sale at the Store for 500 ryo. Easy.
The hints on this town lead to the “gambling den” mini-game as a way to raise money,
but the mini-game is completely optional.

Satsuma Village:
- You need to find the houses of the two game twins and beat them at their mini-games.
  You can identify their houses easily because they’re the only houses with no signs
  that have a grey crosshatch design on the front. Each will give you a half of this
  town’s Pass.

Gurume Village:
- This town’s Pass comes from a third mini-game. The house looks the same as the
  mini-game houses from the previous town.
- There’s also a second exit through a secret passage, located inside the closed
  castle in the upper left side of town. To get access to it:
  - Talk to people in town and find hints about the emperor running away and setting
    up a sandal shop in Oedo.
  - Go find him at the upper right side of Hagure Town. He’ll give you the key to
    the castle.
Both methods of crossing the town will lead to different stages. You can do either,
or both.

Kaiki Village:
You'll want to use the Teleport service for this one.
- First, talk to the first few houses to get hints about a guy called Kitaro that
  went to Satsuma Village to get a sweet called Castella for his grandma.
- Go to Satsuma Village. Find Kintaro at the upper right section of the village.
- Buy the "Castella" from Satsuma Village’s food store.
- Now go back to Kaiki Village and give it to Kintaro's grandma (first house in town,
  left to right.)
- Then to back to Kitaro on Satsuma Village. He’ll give you Kaiki Village’s pass.
 
 
Changelog
========================================================================================

Version 1.2 - 2024.03.29
- Oops! I accidentaly left my debug stuff in v1.1. Now you can play normally!

Version 1.1 - 2024.03.27
- (Bugfix) Fixed a freeze that would occur in stores when playing with 2 players.

Version 1.0 - 2024.03.26
- First release
 
 
Credits & acknowledgements
========================================================================================
acediez: 	Hacking. Graphics.
Tom:		Translation. Testing.

Graphics in town were based on graphics done by FlashPV for the SFC Goemon translations.
 
Once again, this project is dedicated to the SFC Goemon translation team of DDS, Tom
and FlashPV. You guys started this!

Thanks again Tom. I'm very proud of our two Goemon translations. It's been fun!

- acediez.