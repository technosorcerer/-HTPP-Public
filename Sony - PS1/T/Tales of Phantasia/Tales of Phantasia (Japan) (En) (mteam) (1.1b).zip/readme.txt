Tales of Phantasia PSX Addendum v1.1b
mteam, Feb 23rd 2025

mziab - hacking and tools
FlamePurge - title screen graphic edit

==========

This patch fixes various issues discovered in the Tales of Phantasia PSX
translation by Phantasian Productions.

While I greatly enjoyed their localization, it had a few minor blemishes,
which I remember reporting to Cless way back in 2013. Unfortunately, the
promised v1.1 update never came to be.

This had been nagging at me for quite some time, so after my own Tales of
Destiny project wrapped up (and seeing how both games share the same engine),
I figured I'd take matters into my own hands. Luckily, I still had my old bug
reports and was able to glean the rest from archived threads from the
Phantasian Productions message board. Basically, this patch is the v1.1 update
we never got (hence the version number).

And while the game threw me some curve-balls and turned out to be very
different from ToD in some respects, I'd say this was a fun little project.
I hope this is useful to people interested in playing the translation. Enjoy!

- mziab

==========

Changelog:

- Fixed a dozen text issues (typos, minor grammatical errors, one spill-over,
  and a mistranslation regarding the status of Aska and Shadow)
- Fixed the crash when sorting the Collector's Book
- Fixed mislabelled Pumpkin King (which displayed as Vampire King) in the
  Monster Book and re-sorted the entries
- Fixed some inconsistencies, spill-overs and a broken pointer in the debug room
- Updated the version number in the title screen for the sake of clarity

==========

The patch needs to be applied over a Japanese .bin file with the following specifications:

sha1sum: 7d182ea8ce547ad3b10229a5fae45fbcd27d950a
md5sum: 611940c88db0b48d87413bcf9e69cd2e
size: 612,778,320 bytes

You can apply the patch using either Delta Patcher or the RHDN web patcher
available at https://www.romhacking.net/patch/
