NOTE:
If anybody has a better icon for hurricane class than a cloud with a lightning bolt, which can fit in 18 pixels of vertical space, please let me know in Issues!

As far as I can tell, I've translated everything except the plain text and the credits.

Translating the plain text is far beyond my capabilities, unfortunately.* This means that the text of the tutorials, along with the description of the difference between Crane and Slide remain in Japanese.

*(Part of my issue is that AFAIK these use a BIOS font, and idk how to work around that)


Art credits:

I used the following art for the grade names:

Turtle Class
https://www.pixilart.com/draw/sea-turtle-09de62bb5f9a673

Rabbit Class
https://media.tenor.com/VsI4oUh4-wQAAAAe/pixel-rabbit-rabbit.png


Electric Class
https://stock.adobe.com/images/electricity-icon-flash-lightning-high-voltage-logo-charging-icon-pixel-art-style-design-8-bit-sprites-isolated-vector-illustration/445079177

Hurricane Class
(Still have to find the image I used)

The main font I used was Daydream
Daydream from dafont

The word class uses
larceny from dafont

thin rank stage name time:
lillian from dafont

The ? replacing the japanese word for question:
Gallaencia


Tools used:
TIM2VIEW
Paint.NET
Gimp
