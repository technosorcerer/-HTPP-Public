Hello everyone

About Tactics Ogre - The Survivor (USA)

This new patch is including content different

Features:


- Possibility to  join you characters supposed not join you or die "Allies/Enemies" Join you.

The Patch ver 5.0

Note:
- Patch working on the original version
- All rights reserved © Atlus
- This Patch is for fans only, not for sales.


Enjoy it!
