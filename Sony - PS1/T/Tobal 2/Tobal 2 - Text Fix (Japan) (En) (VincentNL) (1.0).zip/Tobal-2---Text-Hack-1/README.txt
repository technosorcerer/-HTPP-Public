//
// TOBAL 2 - English Text Fix + New GFX + Bugfixes
//

Based on Tobal 2 English Translation v1.01b, this ASM and GFX hack adjust text to be halfwidth to maximise density and improve readibility.

Patch to be used with original Tobal 2 (Japan) (v1.1).bin!

// Code and GFX by VincentNL
  ♥ ko-fi.com/vincentnl
  ♥ patreon.com/vincentnl


// Full credit for English translation goes to Infinite and r4dius!

+ New asm to use halfwidth
+ Adjust character names offsets in Selection
+ New pointers for extended translation
+ Menu options text adjusted
+ New english Training UI gfx
+ Original game bugfixes (Debug leftover 1 frame flash in training)

++ Support for Tobal 2 Editor! (to be released)