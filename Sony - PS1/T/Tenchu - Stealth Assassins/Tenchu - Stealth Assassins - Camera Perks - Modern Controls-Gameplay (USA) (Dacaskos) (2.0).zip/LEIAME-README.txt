Tenchu Modern Controls/Gameplay hack (Former/Antigo "Camera & Perks" hack)

ASM por Dacaskos

Refeito do zero para adicionar suporte a movimentação analógica/controle de câmera com analógicos ( Não esqueça de acioná-lo!)
Remade from scratch to add analog movement/camera control (Don't forget to activate it!)


Observações Importantes/Problemas Conhecidos
-L1 agora é usado como um "Lockon manual". Ele trava a câmera atrás do personagem, bem como força os movimentos funcionarem como no jogo original (Tank Controls), além de servir de quick look se necessário.
-Como um defeito colateral de como o hack funciona, após uma cutscene/loading a câmera pode começar desalinhada com o personagem (mirada pra outro lugar). Considere sempre segurar/apertar o L1 após um loading/cutscene pra fazer a câmera começar atrás do personagem por segurança.
-L1 agora também é usado como botão de defesa. Segure L1 estando parado ou andando a pelo menos 45 graus em direção ao alvo para defender, e como a defesa gira o personagem na direção do inimigo, isso invariavelmente vai fazer "lockon" nele.
-Dashes e rolamentos podem ser feitos a partir do botão Circulo/B, o que eu chamo de "B-Step". Movimentos de dois toques ainda funcionam na maior parte, mas prefira usá0los em conjunto com o Dpad ao invés do analógico. ( Dica: Double Tap o circulo enquanto está escorando na parede vai fazer você rolar na direção desejada)
-Somersault pode ser feito agora pressionando X + O. 
-Segurar R1 no ar permite travar a rotação do personagem ao mesmo tempo que "digitaliza" o controle de impulsão aéreo. Use-o pra manter e/ou direcionar o personagem na direção desejada no ar, levando em conta que o jogo ainda leva em consideração a posição relativa do personagem (tank controls) e não da câmera.
-O Agachamento funciona pra que o personagem fique sempre na direção da câmera.
-Agachamento parado da zoom de câmera na mesma distância que o free aim original
Problemas Conhecidos
-80% do hack está tentando acomodar o uso de câmera/movimentação livre em um jogo que nunca foi feito pra isso. 
Você pode achar problemas como por exemplo, ao soltar o botão de defesa enquanto põe o manche pra trás, o boneco vai continuar andando pra trás de costas pra o oponente ao invés de correr. Nesse caso específico, procure soltar levemente o manche pra resetar o comando de corrida. O mesmo com o agachamento que só funciona em 4 direções. Procure resetar o comando sempre que necessário ou usar o DPAD.
-Esse jogo tem algumas limitações de execução de input. Notavelmente espadadas não funcionam "pra baixo" e combos não funcionam se os controles estão colocandos na diagonal, então se a intenção é combar, sempre considere largar o manche quando for atacar


Do Hack antigo foram mantidas as seguintes alterações:
-Tracking de ataque aumentado
-O "Bumping" na parede pulando foi removido
-A colisão de parede é menos "pegajosa" (mudar de direção correndo na parede)
-Wallflip teve altura ligeiramente aumentada

Como um extra, a seleção de Layout de fases (antes acessada apenas com um cheat code), é ativada por padrão


Important Notes / Known Issues
-L1 is now used as a manual lock-on. It locks the camera behind the character, forces movement to behave like the original game (Tank Controls), and can also act as a quick-look button when needed.
-Due to how the hack works, after a cutscene or loading screen the camera may start misaligned with the character (facing a different direction). It’s recommended to hold or tap L1 after any cutscene or loading to realign the camera behind the player for safety.
-L1 is also used as a defense button. Hold L1 while standing still or moving at least 45 degrees toward the target to defend. Since the defense action turns the character to face the enemy, this will effectively lock-on to them as well.
-Dashes and rolls can now be performed using the Circle/B button, a function I call the “B-Step.” Double-tap motions still work in most cases, but it’s better to use them together with the D-Pad instead of the analog stick.
(Tip: Double-tapping Circle while leaning against a wall will make you roll in the desired direction.)
-Somersaults can now be performed by pressing X + Circle.
-Holding R1 in mid-air locks the character’s rotation and makes aerial control “digital.” Use this to maintain or redirect your character’s direction while airborne, keeping in mind the game still uses tank-style movement (relative to the character, not the camera).
-Crouching now makes the character always face the camera’s direction.
-Standing crouch zooms the camera to the same distance as the original free-aim mode.

Known Issues
-Roughly 80% of the hack is about accommodating free camera and movement in a game that was never designed for it.
-You may encounter issues such as: releasing the defense button while holding the stick backward may cause the character to keep walking backward facing the opponent instead of running. In that case, slightly release the stick to reset the run input.
Similarly, crouching only works in four directions. Try resetting the stick position or using the D-Pad whenever needed.
-This game has some limitations regarding input execution. Notably, attacks don't register  with downward directions, as well as combos don't work while pushing the controls diagonally. So always consider attacking while on neutral.

Features Kept from the Older Hack
-Increased attack tracking.
-Removed wall bump effect when jumping near walls.
-Reduced “sticky” wall collision (changing direction while running against a wall).
-Slightly increased wall-flip height.

Extra

Stage layout selection (previously accessible only through a cheat code) is now enabled by default.



Instruções:

Aplique o patch no arquivo "Bin" de sua cópia da versão REV 1/1.1 americana do Tenchu com algum programa que aplique arquivos do tipo xdelta.
Recomendo o "Delta Patcher"
https://www.romhacking.net/utilities/704/

Instructions:

Apply the patch on the "BIN" file of your USA REV 1/1.1 Tenchu copy/image with any software that applies xdelta patches
I recommend "Delta Patcher"
https://www.romhacking.net/utilities/704/

