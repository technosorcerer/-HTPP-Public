-= Vagrant Story Font Patch =-

How to install (On Windows):

1.  Unzip the included zip file
2.  Download and open "Delta Patcher Lite" and click the first yellow folder icon. 
3.  Choose your original unmodified "Vagrant Story (USA).bin" file.
4.  Click the second yellow folder icon and choose the "VagrantStoryFontPatch.xdelta" file .
5.  If you don't want to lose your original unpatched game file, click the little gear icon next to the "Apply patch" box and click "Backup original file".
	-You will then need to remove the word "PATCHED" from the bin file's name later.
6.  Click "Apply patch"!
7.  Place the patched "Vagrant Story (USA).bin" file in the same folder as your original "Vagrant Story (USA).cue" file and it's ready to be played!

How to install alternative (All OS's):
1.  Go to https://hack64.net/tools/patcher.php
2.  For ROM, enter the original "Vagrant Story (USA).bin" file.
3.  For Patch, enter the "VagrantStoryFontPatch.xdelta" file.
4.  For Save as, enter "Vagrant Story (USA).bin".
    -If you don't want to lose your original unpatched game file, make a backup of it now.
5.  Click Patch 
6.	Place the patched "Vagrant Story (USA).bin" file in the same folder as your original "Vagrant Story (USA).cue" file and it's ready to be played!
