Vib-Ribbon NTSC Patch
---------------------


This hack converts the European release of Vib-Ribbon from PAL to NTSC. Since the European release of the game has an English language option, this hack has the effect of providing an English version of the game that can run on NTSC consoles.

The hack is distributed as an XDelta patch file. This patch should be applied to the Track 1 bin file. If you only have one bin file, please split it into multiple tracks using BinMerge first.
