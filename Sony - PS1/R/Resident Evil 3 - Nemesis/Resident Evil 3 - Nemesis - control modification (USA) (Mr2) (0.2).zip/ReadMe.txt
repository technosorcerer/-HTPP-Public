﻿--------------------------Info---------------------------
Game name: Resident Evil 3
Console: PlayStation
Game ID USA: SLUS-00923
Patch: SP (Solid patch)
Patcher: Solid patcher
Patcher download link:
 Windows: https://romhackplaza.org/utilities/solid-patcher-utility/
 Linux: https://romhackplaza.org/utilities/solid-patcher-utility-2/
 https://rgcorp.ucoz.net/load/console_soft/solid_patcher/2-1-0-97
----------------------------------------------------------
--------------------------patch------------------------
Patch add next features:

 Run on the [] button, without holding the UP button.
 L1, L3 - turn move.
 R1, R2 + L3 change targets.
 R3 - action\attack.
 Gun reload: R1+[].
----------------------------------------------------------
For the gun reload modification, was used 
code research from Sharpnull.
----------------------------------------------------------
Author by Mr2.
e-mail: rgcorpsoft@gmail.com
https://rgcorp.ucoz.net/