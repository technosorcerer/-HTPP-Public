Resident Evil 3 - I'll give you STARS edition

ASM por/by Dacaskos

Agradecimentos/Créditos:
Unicorngoulash: Espaço extra para mods (Re3 Modders Edition) & código de Faca Suporte original
Diamondcutter/UL1/Misfire: Endereço de "Freeze" da versão PAL

Special Thanks/Credits:
Unicorngoulash: Extra space for mods (Re3 Modders Edition) & Knife Backup original asm code
Diamondcutter/UL1/Misfire: Freeze Address from the PAL version

Atualização 1.4.2

-Bug que invertia eixo vertical em uma câmera específica na luta contra o Nemesis na sala de manivelas de ácido na Dead Factory corrigido
-Bug que não acionava Tactical Reload com o Carlos (modo história) corrigido.

Atualização 1.4.1

-Pequeno Fix temporário que corrige bug com Carlos não acionando o Tactical Reload. Infelizmente, a animação de reload ainda vai ser ativada mesmo se estiver sem munição no inventário. Ainda estou vendo o que pode ser feito.

Atualização 1.4
-Adicionado suporte à movimento analógico 360 relativo à camera. Leia a parte de mudanças para entender melhor como funciona. Devido a esta mudança, o controle digital no dpad a partir de agora por padrão usa os valores de rotação do jogo padrão, mas você pode ainda modulá-los segurando L1 pra maior velocidade de rotação aos moldes da versão antiga do hack.
-Pelo mesmo motivo, a animação de andar pra trás em "Caution/Danger" foi restaurada. Correr ainda funciona como se estivesse em caution.
-Tactical Mode (Reload Freeze desligado/animação de abaixar arma padrão) é o modo padrão do hack agora pra uma experiência padrão mais próxima do original.
-Uma versão alternativa do Tactical Mode chamada "Fast Disarm Mode" foi adicionada apertando R1 + Quadrado estando no inventário. É o mesmo Tactical Mode, com a diferença que a animação de abaixar a arma é cancelável pra maior mobilidade (faz uma grande diferença em gameplay)
-Gunpowders com a Letra C (AC, BC, CC, CCC) também agora dão quantidade de experiência respectiva às munições correspondentes a suas letras.
-Um bug de não acionamento do Tactical Reload se a munição estivesse no primeiro slot corrigido.
-Grande parte do código refeita pra diminuir redundância/risco de uso de registradores indevidos. Há uma grande quantidade de códigos ridiculamente burros nos hacks de inventário ainda que eu preferi não mexer pra não estragar alguma coisa.

Update 1.4.2

-Bug that inverted analog Y axis while at a particular camera in the fight against Nemesis (acid switches room inside Dead Factory) fixed.
-Bug that prevented activation of Tactical Reloading when playing as Carlos (story mode) fixed.

Update 1.4.1

-Small temporary fix for Carlos not activating Tactical Reloading. Unfortunately, for now, it will still activate the animation even if there isn't ammo in the inventory (I'm looking for a better solution)

Update 1.4
-Added support for 360° analog movement relative to the camera. Read the “Changes” section to understand exactly how it works. Due to this change, digital D-pad movement now uses the game’s original rotation values by default again. However, you can still modulate rotation speed by holding L1 for faster turning, similar to how the older version of the hack behaved.
-For the same reason, the “walk backwards” animation in Caution/Danger has been restored. Running while in Danger still behaves the same as Caution.
-Tactical Mode (Reload Freeze disabled / default weapon-lowering animation) is now the default mode of the hack, aiming for a gameplay experience closer to the original.
-A new variation called “Fast Disarm Mode” has been added — activated by pressing R1 + Square while in the inventory. It’s the same Tactical Mode, but the weapon-lowering animation can be canceled, offering much higher mobility (it makes a big difference in gameplay).
-Gunpowders labeled with the letter C (AC, BC, CC, CCC) now also grant experience corresponding to their respective ammo types.
-Fixed a bug preventing Tactical Reload from triggering when the ammo was in the first inventory slot.
-Large parts of the code were rewritten to reduce redundancy and the risk of improper register usage.
There are still a lot of ridiculously dumb inventory hack routines that I preferred not to touch — just to avoid breaking something.

Atualização 1.3
-A animação de levantar da mirada agachada é cancelável agora para ação mais rápida

Update 1.3
-Rising up from crouching aiming position is skippable for quicker action now.

Atualização 1.2
-O código de Tactical Reload agora checa a munição se está com clip cheio e/ou se não possui munição disponível.
-A Rotação do personagem agora é modular segurar o L1. Com a versão padrão do hack, segurar L1 faz com que a rotação se torne a original do jogo. Usando a versão "vanilla rotation" do hack, segurar L1 aumenta o índice para o padrão do hack.
-Mudança no código de desarme rápido que provavelmente corrige potenciais outros bugs de animação ainda antes não identificados
-Um código que aleatoriamente faz os inimigos (especialmente o Nemesis) tirarem +10 de hp em cada ataque foi removido

Update 1.2
-Proper Tactical Reloading. The code now checks if the clip is full and/or if there's ammo in the inventory.
-Modular Rotation. Holding L1, if using the default hack version, will change the rotation to its vanilla values. If using the Vanilla Rotation version, will change to the hack's defaults
-Changes in the quick disarm code that probably fix potential bugs previously not identified
-Code that randomly make enemies (specially Nemesis) deal +10 of damage was removed


Atualização 1.1
-É possível esquivar estando em danger agora
-"Modo Tático": Congelamento no reload agora é opcional ligando/desligando (ligado por padrão) com R1 + Triangulo dentro do inventário.
-Enquanto estiver no "Modo Tático" (congelamento desligado), o reload automático do jogo (atirar sem munição) é desabilitado, sendo o reload agora feito apenas manualmente via R1 + Triangulo (mas ainda é possível combinar munição como no jogo original sem problemas)
-Enquanto estiver no "Modo Tático", a animação de abaixar a arma funciona como no jogo original (não é possível cancelá-la)
-Alguns códigos foram enxugados pra usarem menos instruções (os códigos de munição ainda são uma bagunça no entanto, não quis mexer em nada)

Update 1.1:
-Dodging while in danger is possible now
-"Tactical Mode": Reload Freeze now is optional by toggling on/off (on by default) with "R1 + Triangle" while in inventory.
-While in "Tactical Mode" (freeze off), auto reloading (firing with no ammo left) is disabled so reloading must be done manually with R1 + Triangle (it's still possible to combine ammo inside inventory like vanilla though).
-While in "Tactical Mode", the animation for lowering the weapon is no longer cancellable (works as vanilla)
-Some code were revamped for less use of instructions (the ammo codes are still a mess though, didn't want to mess with it)



Mudanças:
-Movimento Analógico 360 relativo à câmera aos moldes da versão N64 do RE2. O código checa a transição de câmera pra que enquanto não houver mudança de ação  (exemplo: Andar > Correr, Correr > Andar, Parar, Mirar, etc)o ângulo de referência ainda seja da câmera anterior para movimentação contínua entre telas. Use isso para rapidamente alterar a direção que quiser ir na troca de câmera apertando o quadrado.
-Ainda, segurar L1 enquanto se move com o Dpad (Tank Controls) aumenta o índice de rotação da personagem pra melhor mobilidade
-A animação de "correr mancando" (Danger) foi anulada para funcionar como se estivesse em "Caution"
-Reload seguro/Reload Freeze (opcional): A animação de reload congela os oponentes no tempo que durar. Alterne com R1 + Triangulo no Inventário para acionar.
-Esquiva segura: A animação de esquiva congela os oponentes no tempo de sua duração até a conclusão da mira (exceção: a esquiva de agachar congela apenas na hora de mirar)
-É possível esquivar mesmo estando em Danger
-Reload Tático: R1 ou R2 + /\
-Desarme rápido (opcional): A animaçao de abaixar a arma é anulável (melhor mobilidade). Para ativar, use R1 + Quadrado no inventário ou, alternativamente, ative o Reload Freeze com R1 + Triangulo no Inventário.
-A animação de se levantar da mirada agachada é cancelada para ação pós tiro mais rápida.
-Facadas rápidas: O ataque com facas teve retorno acelerado
-Faca Suporte by @UnicornGoulash: Desequipar qualquer arma irá deixar a personagem armada com a faca (não é necessário levar a faca no inventário)
-"Fix" na Fabricação de Munição: queimar gunpowder AA, BB, CC, AC, BC, AAA, BBB, AAB ou BBA aumenta a experiência em 2 ou 3, de acordo. AAB/BBA aumenta uma letra em 2 e a outra em 1.
 ATENÇÃO: Só funciona se você queimar a gunpowder EM CIMA DA RELOADING TOOL, e não o oposto (a reloading tool em cima da gunpowder não vai funcionar)
-Troca de Munição Comum/Especial: Após ganhar nível de experiência o suficiente para fazer Munição Especial (+7), aperte "Check" para mudar de uma munição para a outra (é possível notar com a mudança de cor da munição. Azul = comum, Vermelha = Especial)
-Você começa com 10 slots
-Não é necessário Ink Ribbons pra salvar o jogo
-Vencer o Nemesis (nos encontros em que ele dá um item) restaura seu life por completo
-Mudança de Roupa: Apertar Select no Inventário muda roupinha das 6 disponíveis (carrega após próxima porta)
ordem: normal - normal sidepack - biker - stars - disco - policewoman - regina
-O reload automático quando se está sem munição no pente é desabilitado por padrao, sendo necessário recarregar a arma manualmente agora (é possível combinar munição como no jogo original). Ativando o Reload Freeze habilita o reload automático padrão do jogo original
-Dano aleatório de +10 dos inimigos removido.


Changes:
-360° Analog Movement relative to the camere similar to the N64 version of RE2. The code checks for camera transitions, so as long as there’s no action change (for example: Walk > Run, Run > Walk, Stop, Aim, etc.), the reference angle will still be taken from the previous camera, allowing smooth movement across screens. Use this to quickly adjust your direction during camera changes by tapping square.
-Still, holding L1 while moving with the D-pad (Tank Controls) increases the character’s rotation speed, making movement more responsive.
-"Limping running" (Danger Run) animation changed to the same as "Caution" animation
-Safe Reload / Reload Freeze (optional): The reload animation freezes enemies for the duration of the reload. Toggle it with R1 + Triangle in the inventory.
-Safe Dodge: The dodge animation freezes opponents for the duration until aiming is complete (exception: the crouching dodge only freezes during aiming)
-It's possible to dodge even under Danger condition
-Tactical Reload: R1 or R2 + /\
-Quick Disarm(optional): The weapon-lowering animation can be canceled, allowing faster mobility. Activate it with R1 + Square in the inventory, or alternatively by enabling Reload Freeze with R1 + Triangle.
-Rising up from crouch aiming position is skippable for quicker action after firing.
-Quick Stabs: The knife attack has a faster return
-Knife Backup by @UnicornGoulash: Unequipping any weapon will arm the character with a knife (no need to carry the knife in the inventory)
-Ammo Crafting "Fix": Burning gunpowder AA, BB, AC, BC, CC, AAA, BBB, AAB, or BBA increases experience by 2 or 3, accordingly. AAB/BBA increases one letter by 2 and the other by 1
	WARNING: Only works if you burn the gunpowder ON TOP OF THE RELOADING TOOL, not the other way around (the reloading tool on top of the gunpowder won't work)
-Swap Common/Enhanced Ammo: After gaining enough experience level to make Enhanced Ammo (+7), press "Check" to switch between ammo types (noticeable by the color change of the ammo. Blue = common, Red = Enhanced)
-You start with 10 slots
-Ink Ribbons are no longer necessary to save the game
-Beating Nemesis (encounters which he drops an item) puts you on maximum health
-Costume Change: pressing select while in inventory put next outfit in queue from the 6 availabie (will load in next room)
	order: normal - normal sidepack - biker - stars - disco - policewoman - regina
-Auto-reload when the magazine is empty is now disabled by default, meaning you’ll need to reload manually (you can still combine ammo just like in the original game). Enabling Reload Freeze restores the original auto-reload behavior.
-+10 Random enemy damage removed

Problemas Conhecidos:
-É possível controlar a personagem com o controle analógico na attract demo. Não muito um problema, mas pode ser engraçado.
-A animação de "facada na parede" foi removida, e dependendo da posição da personagem, a câmera talvez não mude durante facadas contínuas. Irá mudar normalmente assim que a personagem faça uma outra ação (Ex: andar)

Known Issues:
-It's possible control the character in the attract demo with the analog controls. Not much of a problem, but can be funny.
-The "Wall stabbing" animation was removed, and depending of the character position, the camera may not change when continuously stabbing. It will change accordingly as soon as the char makes another action (i.e walk)


Instruções:

Aplique o patch no arquivo "Bin" de sua cópia da versão americana do Resident Evil 3 com algum programa que aplique arquivos do tipo xdelta.
Recomendo o "Delta Patcher"
https://www.romhacking.net/utilities/704/

Instructions:

Apply the patch on the "BIN" file of your USA Resident Evil 3 copy/image with any software that applies xdelta patches
I recommend "Delta Patcher"
https://www.romhacking.net/utilities/704/