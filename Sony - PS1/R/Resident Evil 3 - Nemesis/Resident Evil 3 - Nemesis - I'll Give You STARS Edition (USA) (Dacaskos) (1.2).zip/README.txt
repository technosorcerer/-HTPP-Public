Resident Evil 3 - I'll give you STARS edition

ASM por/by Dacaskos

Agradecimentos/Créditos:
Unicorngoulash: Espaço extra para mods (Re3 Modders Edition) & código de Faca Suporte original
Diamondcutter/UL1/Misfire: Endereço de "Freeze" da versão PAL

Special Thanks/Credits:
Unicorngoulash: Extra space for mods (Re3 Modders Edition) & Knife Backup original asm code
Diamondcutter/UL1/Misfire: Freeze Address from the PAL version

Atualização 1.1
-É possível esquivar estando em danger agora
-"Modo Tático": Congelamento no reload agora é opcional ligando/desligando (ligado por padrão) com R1 + Triangulo dentro do inventário.
-Enquanto estiver no "Modo Tático" (congelamento desligado), o reload automático do jogo (atirar sem munição) é desabilitado, sendo o reload agora feito apenas manualmente via R1 + Triangulo (mas ainda é possível combinar munição como no jogo original sem problemas)
-Enquanto estiver no "Modo Tático", a animação de abaixar a arma funciona como no jogo original (não é possível cancelá-la)
-Alguns códigos foram enxugados pra usarem menos instruções (os códigos de munição ainda são uma bagunça no entanto, não quis mexer em nada)

Update 1.1:
-Dodging while in danger is possible now
-"Tactical Mode": Reload Freeze now is optional by toggling on/off (on by default) with "R1 + Triangle" while in inventory.
-While in "Tactical Mode" (freeze off), auto reloading (firing with no ammo left) is disabled so reloading must be done manually with R1 + Triangle (it's still possible to combine ammo inside inventory like vanilla though).
-While in "Tactical Mode", the animation for lowering the weapon is no longer cancellable (works as vanilla)
-Some code were revamped for less use of instructions (the ammo codes are still a mess though, didn't want to mess with it)



Mudanças:
-Personagem gira no próprio eixo mais rápido que no original (melhora em desvios e mobilidade, no geral)
-A animação de "correr mancando" (Danger) foi anulada para funcionar como se estivesse em "Caution"
-A animação de andar pra trás em "Caution/Danger" foi anulada pra funcionar como se estivesse em "Fine"
-Reload seguro (opcional): A animação de reload congela os oponentes no tempo que durar
-Esquiva segura: A animação de esquiva congela os oponentes no tempo de sua duração até a conclusão da mira (exceção: a esquiva de agachar congela apenas na hora de mirar)
-É possível esquivar mesmo estando em Danger
-Reload Tático: R1 ou R2 + /\
-Desarme rápido (opcional): A animaçao de abaixar a arma é anulável (melhor mobilidade)
-Facadas rápidas: O ataque com facas teve retorno acelerado
-Faca Suporte by UnicornGoulash: Desequipar qualquer arma irá deixar a personagem armada com a faca (não é necessário levar a faca no inventário)
-"Fix" na Fabricação de Munição: queimar gunpowder AA, BB, AAA, BBB, AAB ou BBA aumenta a experiência em 2 ou 3, de acordo. AAB/BBA aumenta uma letra em 2 e a outra em 1.
 ATENÇÃO: Só funciona se você queimar a gunpowder EM CIMA DA RELOADING TOOL, e não o oposto (a reloading tool em cima da gunpowder não vai funcionar)
-Troca de Munição Comum/Especial: Após ganhar nível de experiência o suficiente para fazer Munição Especial (+7), aperte "Check" para mudar de uma munição para a outra (é possível notar com a mudança de cor da munição. Azul = comum, Vermelha = Especial)
-Você começa com 10 slots
-Não é necessário Ink Ribbons pra salvar o jogo
-Vencer o Nemesis (nos encontros em que ele dá um item) restaura seu life por completo
-Mudança de Roupa: Apertar Select no Inventário muda roupinha das 6 disponíveis (carrega após próxima porta)
ordem: normal - normal sidepack - biker - stars - disco - policewoman - regina
-Modo Tático: R1 + Triângulo no inventário ativa as seguintes mudanças que fazem o jogo um pouco mais desafiador:
	-O Reload não congela mais os oponentes (as esquivas ainda congelam)
	-O Desarme rápido é desativado (funciona como no jogo original)
	-O reload automático quando se está sem munição no pente é desabilitado, sendo necessário recarregar a arma manualmente agora (é possível combinar munição como no jogo original)


Changes:
-The character spins on their axis faster than in the original (improves dodging and overall mobility)
-"Limping running" (Danger Run) animation changed to the same as "Caution" animation
-"Caution/Danger" Backwalk animation changed to work as "Fine" animation
-Safe Reload (optional): The reload animation freezes opponents for its duration
-Safe Dodge: The dodge animation freezes opponents for the duration until aiming is complete (exception: the crouching dodge only freezes during aiming)
-It's possible to dodge even under Danger condition
-Tactical Reload: R1 or R2 + /\
-Quick Disarm(optional): The animation for lowering the weapon is cancellable (enhanced mobility)
-Rapid Stabs: The knife attack has a faster return
-Knife Backup by UnicornGoulash: Unequipping any weapon will arm the character with a knife (no need to carry the knife in the inventory)
-Ammo Crafting "Fix": Burning gunpowder AA, BB, AAA, BBB, AAB, or BBA increases experience by 2 or 3, accordingly. AAB/BBA increases one letter by 2 and the other by 1
	WARNING: Only works if you burn the gunpowder ON TOP OF THE RELOADING TOOL, not the other way around (the reloading tool on top of the gunpowder won't work)
-Swap Common/Enhanced Ammo: After gaining enough experience level to make Enhanced Ammo (+7), press "Check" to switch between ammo types (noticeable by the color change of the ammo. Blue = common, Red = Enhanced)
-You start with 10 slots
-Ink Ribbons are no longer necessary to save the game
-Beating Nemesis (encounters which he drops an item) puts you on maximum health
-Costume Change: pressing select while in inventory put next outfit in queue from the 6 availabie (will load in next room)
	order: normal - normal sidepack - biker - stars - disco - policewoman - regina
-Tactical Mode: pressing R1 + Triangle while inside inventory activates the following changes that make the game a little bit more challenging:
	-Reload Freezing is disabled (the dodges still freeze though)
	-Quick Disarming is disabled (works as in vanilla)
	-Auto reloading when the clip is empty is disabled so that now reloading must be done manually (combining ammo still works normally)

Problemas Conhecidos:
-A animação de "facada na parede" foi removida, e dependendo da posição da personagem, a câmera talvez não mude durante facadas contínuas. Irá mudar normalmente assim que a personagem faça uma outra ação (Ex: andar)

Known Issues:
-The "Wall stabbing" animation was removed, and depending of the character position, the camera may not change when continuously stabbing. It will change accordingly as soon as the char makes another action (i.e walk)


Instruções:

Aplique o patch no arquivo "Bin" de sua cópia da versão americana do Resident Evil 3 com algum programa que aplique arquivos do tipo xdelta.
Recomendo o "Delta Patcher"
https://www.romhacking.net/utilities/704/

Instructions:

Apply the patch on the "BIN" file of your USA Resident Evil 3 copy/image with any software that applies xdelta patches
I recommend "Delta Patcher"
https://www.romhacking.net/utilities/704/