Resident Evil 2 - Power Knife
July 28th, 2021
BillyTime! Games
--------------------
This patch buffs the combat knife to better combat zombies. Might work on other creatures as well.

How to Patch:
--------------------
1.Grab a copy of Resident Evil 2 - Dual Shock Ver.(USA) (Track 01).bin (REDUMP) (Disc 1 and 2)
2.Grab xdelta UI (https://romhackplaza.org/utilities/xdelta-ui-utility/)
3.Patch your rom with the corresponding file