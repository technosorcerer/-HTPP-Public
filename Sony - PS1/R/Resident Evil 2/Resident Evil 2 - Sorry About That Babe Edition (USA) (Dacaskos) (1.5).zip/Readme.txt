Resident Evil 2 Dual Shock - "Sorry about that, babe" Edition

ASM por Dacaskos

Agradecimentos/Créditos:
Diamondcutter/UL1/Misfire: Endereço de "Freeze" da versão PAL

Special Thanks/Credits:
Diamondcutter/UL1/Misfire: Freeze Address from the PAL version


Atualização 1.5
-Adicionado suporte à movimento analógico 360 relativo à camera. Leia a parte de mudanças para entender melhor como funciona. Devido a esta mudança, o controle digital no dpad a partir de agora por padrão usa os valores de rotação do jogo padrão, mas você pode ainda modulá-los segurando L1 pra maior velocidade de rotação aos moldes da versão antiga do hack.
-Pelo mesmo motivo, a animação de andar pra trás em "Caution/Danger" foi restaurada. Correr ainda funciona como se estivesse em caution.
-Tactical Mode (Reload Freeze desligado/animação de abaixar arma padrão) é o modo padrão do hack agora pra uma experiência padrão mais próxima do original.
-Uma versão alternativa do Tactical Mode chamada "Fast Disarm Mode" foi adicionada apertando R1 + Quadrado estando no inventário. É o mesmo Tactical Mode, com a diferença que a animação de abaixar a arma é cancelável pra maior mobilidade (faz uma grande diferença em gameplay)
-Código de Knife Backup funciona agora também ao carregar um jogo salvo
-Efeito estranho de recarga ao acionar Tactical Reload com uma Rocket Launcher ou Faca corrigidos.

Update 1.5
-Added support for 360° analog movement relative to the camera. Read the “Changes” section to understand exactly how it works. Due to this change, digital D-pad movement now uses the game’s original rotation values by default again. However, you can still modulate rotation speed by holding L1 for faster turning, similar to how the older version of the hack behaved.
-For the same reason, the “walk backwards” animation in Caution/Danger has been restored. Running while in Danger still behaves the same as Caution.
-Tactical Mode (Reload Freeze disabled / default weapon-lowering animation) is now the default mode of the hack, aiming for a gameplay experience closer to the original.
-A new variation called “Fast Disarm Mode” has been added — activated by pressing R1 + Square while in the inventory. It’s the same Tactical Mode, but the weapon-lowering animation can be canceled, offering much higher mobility (it makes a big difference in gameplay).
-Knife Backup code fixed to work also after load (save game)
-Weird effects while trying to activate Tactical Reloading with a Rocket Launcher or Knife fixed.


Atualização 1.4 Fix
-Fix em mirada no disco do Leon que travava com certas armas (zoei a instrução original, mil perdões)
-Código de Knife Backup Unequip estendido pra funcionar no Extreme Battle.

Update  1.4 Fix
-Fix on Aiming with Leon using certain weapons (messed up the original cpu instruction, sorry)
-Unequip Knife coded extended to work also in Extreme Battle.


Atualização 1.4
-Knife Backup agora funciona simplesmente desequipando qualquer arma ao estilo do hack do unicorngoulash no RE3. Unequip alguma arma pra ter uma faca equipada. (o código anterior com select ainda funciona como leftover)

Update 1.4
-Knife Backup now works just like unicorngoulash's hack from RE3. Just Unequip any weapon to have a Knife in hand (old code that swaps the unique item with select still is a leftover)


Atualização 1.3 Fix
-Corrigido attract demo travando


Update 1.3 fix
-Hanging attract demo fixed

Atualização 1.3
-O código de Tactical Reload agora checa a munição se está com clip cheio e/ou se não possui munição disponível.
-A Rotação do personagem agora é modular segurar o L1. Com a versão padrão do hack, segurar L1 faz com que a rotação se torne a original do jogo. Usando a versão "vanilla rotation" do hack, segurar L1 aumenta o índice para o padrão do hack.
-Mudança no código de desarme rápido que provavelmente corrige potenciais outros bugs de animação ainda antes não identificados


Update 1.3
-Proper Tactical Reloading. The code now checks if the clip is full and/or if there's ammo in the inventory.
-Modular Rotation. Holding L1, if using the default hack version, will change the rotation to its vanilla values. If using the Vanilla Rotation version, will change to the hack's defaults
-Changes in the quick disarm code that probably fix potential bugs previously not identified.


Atualização 1.2
-10 slots no segundo cenário ao acessar o inventário (não necessário alcançar uma item box no segundo cenário)

Update 1.2
-Not necessary anymore to reach a item box in 2nd Scenario to gain 10 slots (it's enabled on inventory access)

Atualização 1.1
-"Modo Tático": Congelamento no reload agora é opcional ligando/desligando (ligado por padrão) com R1 + Triangulo dentro do inventário.
-Enquanto estiver no "Modo Tático" (congelamento desligado), o reload automático do jogo (atirar sem munição) é desabilitado, sendo o reload agora feito apenas manualmente via R1 + Triangulo (mas ainda é possível combinar munição como no jogo original sem problemas)
-Animação da máquina no laborátorio corrigida

Update 1.1:
-"Tactical Mode": Reload Freeze now is optional by toggling on/off (on by default) with "R1 + Triangle" while in inventory.
-While in "Tactical Mode" (freeze off), auto reloading (firing with no ammo left) is disabled so reloading must be done manually with R1 + Triangle (it's still possible to combine ammo inside inventory like vanilla though)
-Fuse machine (lab) broken animation fixed



Mudanças:
-Movimento Analógico 360 relativo à câmera aos moldes da versão N64 do RE2. O código checa a transição de câmera pra que enquanto não houver mudança de ação  (exemplo: Andar > Correr, Correr > Andar, Parar, Mirar, etc) o ângulo de referência ainda seja da câmera anterior para movimentação contínua entre telas. Use isso para rapidamente alterar a direção que quiser ir na troca de câmera apertando o quadrado.
-Ainda, segurar L1 enquanto se move com o Dpad (Tank Controls) aumenta o índice de rotação da personagem pra melhor mobilidade
-A animação de "correr mancando" (Danger) foi anulada para funcionar como se estivesse em "Caution"
-Reload seguro/Reload Freeze (opcional): A animação de reload congela os oponentes no tempo que durar. Alterne com R1 + Triangulo no Inventário para acionar.
-Facadas rápidas: O ataque com facas teve retorno acelerado
-Dano de facada em zumbis: Zumbis sofrem cerca de 2.5x mais dano agora com a faca
-Reload Tático: R1 ou R2 + /\ (não funciona com a submachinegun)
-Desarme rápido (opcional): A animaçao de abaixar a arma é anulável (melhor mobilidade). Para ativar, use R1 + Quadrado no inventário ou, alternativamente, ative o Reload Freeze com R1 + Triangulo no Inventário.
-O reload automático quando se está sem munição no pente é desabilitado por padrao, sendo necessário recarregar a arma manualmente agora (é possível combinar munição como no jogo original). Ativando o Reload Freeze habilita o reload automático padrão do jogo original
-Faca Suporte: Desequipe qualquer arma pra ter uma faca na mão 
-Não é necessário Ink Ribbons pra salvar o jogo
-!!Extra: Alcance um baú para já ganhar 2 slots no inventário (sidepack). Atenção: Não vai funcionar a depender do andamento do jogo (notavelmente após pegar as ervas nos fundos do East Office que conecta o primeiro/segundo andar).

Changes:
-360° Analog Movement relative to the camere similar to the N64 version of RE2. The code checks for camera transitions, so as long as there’s no action change (for example: Walk > Run, Run > Walk, Stop, Aim, etc.), the reference angle will still be taken from the previous camera, allowing smooth movement across screens. Use this to quickly adjust your direction during camera changes by tapping square.
-Still, holding L1 while moving with the D-pad (Tank Controls) increases the character’s rotation speed, making movement more responsive.
-"Limping running" (Danger Run) animation changed to the same as "Caution" animation
-Safe Reload / Reload Freeze (optional): The reload animation freezes enemies for the duration of the reload. Toggle it with R1 + Triangle in the inventory.
-Tactical Reload: R1 + /\ (won't work with the submachinegun)
-Quick Disarm(optional): The weapon-lowering animation can be canceled, allowing faster mobility. Activate it with R1 + Square in the inventory, or alternatively by enabling Reload Freeze with R1 + Triangle.
-Auto-reload when the magazine is empty is now disabled by default, meaning you’ll need to reload manually (you can still combine ammo just like in the original game). Enabling Reload Freeze restores the original auto-reload behavior.
-Quick Stabs: The knife attack has a faster return
-Zombie stabs: Zombies suffer circa 2.5x more damage with the knife
-Support Knife: Unequip any weapon to have a knife in hand
-Ink Ribbons are not needed to save the game
-!!Extra: Reach a chest to immediately gain 2 inventory slots (sidepack). Attention: It will not work depending on the game's progress (notably after picking the herbs at the back of the East Office that connects the first/second floor).


Problemas Conhecidos:
-É possível controlar a personagem com o controle analógico na attract demo. Não muito um problema, mas pode ser engraçado.
-A animação de "facada na parede" foi removida, e dependendo da posição da personagem, a câmera talvez não mude durante facadas contínuas. Irá mudar normalmente assim que a personagem faça uma outra ação (Ex: andar)

Known Issues:
-It's possible control the character in the attract demo with the analog controls. Not much of a problem, but can be funny.
-The "Wall stabbing" animation was removed, and depending of the character position, the camera may not change when continuously stabbing. It will change accordingly as soon as the char makes another action (i.e walk)


Instruções:

Aplique o patch no arquivo "Bin" de sua cópia da versão americana do Resident Evil 2 Dual Shock com algum programa que aplique arquivos do tipo xdelta.
Recomendo o "Delta Patcher"
https://www.romhacking.net/utilities/704/

Instructions:

Apply the patch on the "BIN" file of your USA Resident Evil 2 Dual Shock copy/image with any software that applies xdelta patches
I recommend "Delta Patcher"
https://www.romhacking.net/utilities/704/