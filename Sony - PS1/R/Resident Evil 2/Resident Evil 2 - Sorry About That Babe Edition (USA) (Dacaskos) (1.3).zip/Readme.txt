Resident Evil 2 Dual Shock - "Sorry about that, babe" Edition

ASM por Dacaskos

Agradecimentos/Créditos:
Diamondcutter/UL1/Misfire: Endereço de "Freeze" da versão PAL

Special Thanks/Credits:
Diamondcutter/UL1/Misfire: Freeze Address from the PAL version

Atualização 1.1
-"Modo Tático": Congelamento no reload agora é opcional ligando/desligando (ligado por padrão) com R1 + Triangulo dentro do inventário.
-Enquanto estiver no "Modo Tático" (congelamento desligado), o reload automático do jogo (atirar sem munição) é desabilitado, sendo o reload agora feito apenas manualmente via R1 + Triangulo (mas ainda é possível combinar munição como no jogo original sem problemas)
-Animação da máquina no laborátorio corrigida

Update 1.1:
-"Tactical Mode": Reload Freeze now is optional by toggling on/off (on by default) with "R1 + Triangle" while in inventory.
-While in "Tactical Mode" (freeze off), auto reloading (firing with no ammo left) is disabled so reloading must be done manually with R1 + Triangle (it's still possible to combine ammo inside inventory like vanilla though)
-Fuse machine (lab) broken animation fixed



Mudanças:
-Personagem gira no próprio eixo mais rápido que no original (melhora em desvios e mobilidade. É possível Circle-stab lickers, por exemplo). Dica: Use o giro caminhando pra trás como um "quick-turn manual"
-Desarme rápido: A animaçao de abaixar a arma é anulável (melhor mobilidade)
-Facadas rápidas: O ataque com facas teve retorno acelerado
-Dano de facada em zumbis: Zumbis sofrem cerca de 2.5x mais dano agora com a faca
-A animação de "correr mancando" (Danger) foi anulada para funcionar como se estivesse em "Caution"
-A animação de andar pra trás em "Caution/Danger" foi anulada pra funcionar como se estivesse em "Fine"
-Reload seguro (opcional): A animação de reload congela os oponentes no tempo que durar
-Reload Tático: R1 + /\
-"Modo Tático": Congelamento no reload agora é opcional ligando/desligando (ligado por padrão) com R1 + Triangulo dentro do inventário. ATENÇÃO: Enquanto estiver no "Modo Tático" (congelamento desligado), o reload automático do jogo (atirar sem munição) é desabilitado, sendo o reload agora feito apenas manualmente via R1 + Triangulo (mas ainda é possível combinar munição no inventário como no jogo original sem problemas)
-Faca Suporte: Pressione Select no Inventário para trocar o item único (Isqueiro/Lockpick) por uma faca (não é necessário ter a faca no inventário). Desequipe a "faca" sempre que quiser retornar ao item original
Nota: Funciona com todos os personagens, inclusive nos modos extra. Foi desativado no cenário da Claire porque obviamente a Sherry é muito novinha pra usar uma faca. Não há problema de trocar também no final do cenário da Claire (quando ela recebe a vacina), porque o item de vacina é puramente estético (não afeta o jogo)
-Não é necessário Ink Ribbons pra salvar o jogo
-!!Extra: Alcance um baú para já ganhar 2 slots no inventário (sidepack). Atenção: Não vai funcionar a depender do andamento do jogo (notavelmente após pegar as ervas nos fundos do East Office que conecta o primeiro/segundo andar). Se estiver no segundo cenário, prefira ir direto ao baú na Waiting Room antes de pegar as ervas no caminho para o East Office

Changes:
-The character rotates on its own axis faster than in the original (improves dodging and mobility. For example, it's possible to circle-stab lickers). Tip: Use backwalk turning as a "manual quick-turn"
-Quick disarm: The animation of lowering the weapon can be canceled (better mobility)
-Quick stabs: The knife attack speed has been increased
-Zombie stabs: Zombies suffer circa 2.5x more damage with the knife
-The "limping run" animation (Danger) has been canceled to work as if in "Caution"
-The backward walking animation in "Caution/Danger" has been canceled to work as if in "Fine"
-Safe Reload (optional): The reload animation freeze enemies for its duration
-Tactical Reload: R1 + Triangle
-"Tactical Mode": Reload Freeze/Safe Reload now is optional by toggling on/off (on by default) with "R1 + Triangle" while in inventory. WARNING: While in "Tactical Mode" (freeze off), auto reloading (firing with no ammo left) is disabled so reloading must be done manually with R1 + Triangle (it's still possible to combine ammo inside inventory like vanilla though)
-Support Knife: Press Select in the Inventory to switch the unique item (Lighter/Lockpick) for a knife (You don't need to have knife in the inventory). Unequip the "knife" whenever you want to return to the original item
Note: Works with all characters, including in extra modes. It was disabled in Claire's scenario because obviously, Sherry is too young to use a knife. There is no problem switching also at the end of Claire's scenario (when she gets the vaccine), because the vaccine item is purely aesthetic (does not affect the game)
-Ink Ribbons are not needed to save the game
-!!Extra: Reach a chest to immediately gain 2 inventory slots (sidepack). Attention: It will not work depending on the game's progress (notably after picking the herbs at the back of the East Office that connects the first/second floor). If you are in the second scenario, prefer going straight to the chest in the Waiting Room before picking up the wheel in the East Office.



Problemas Conhecidos:
-A animação de "facada na parede" foi removida, e dependendo da posição da personagem, a câmera talvez não mude durante facadas contínuas. Irá mudar normalmente assim que a personagem faça uma outra ação (Ex: andar)
-O demo play da Claire na sala de Arquivo da delegacia vai travar o jogo por ela erroneamente pegar um Ink Ribbon devido às mudanças de rotação da personagem


Known Issues:
-The "Wall stabbing" animation was removed, and depending of the character position, the camera may not change when continuously stabbing. It will change accordingly as soon as the char makes another action (i.e walk)
-The Attract-demo with Claire inside the RPD File Storage can (and will) softlock the game when she erroneously grab an Ink Ribbon due to changed rotation


Instruções:

Aplique o patch no arquivo "Bin" de sua cópia da versão americana do Resident Evil 2 Dual Shock com algum programa que aplique arquivos do tipo xdelta.
Recomendo o "Delta Patcher"
https://www.romhacking.net/utilities/704/

Instructions:

Apply the patch on the "BIN" file of your USA Resident Evil 2 Dual Shock copy/image with any software that applies xdelta patches
I recommend "Delta Patcher"
https://www.romhacking.net/utilities/704/