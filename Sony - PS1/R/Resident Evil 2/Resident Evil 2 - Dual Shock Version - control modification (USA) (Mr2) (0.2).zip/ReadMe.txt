﻿--------------------------Info---------------------------
Game name: Resident Evil 2 Dual Shock Ver.
Console: PlayStation
Game ID USA: SLUS-00748
Game ID USA: SLUS-00756
Language: English
Patch: SP (Solid patch)
Patcher: Solid patcher
Patcher download link:
 Windows: https://romhackplaza.org/utilities/solid-patcher-utility/
 Linux: https://romhackplaza.org/utilities/solid-patcher-utility-2/
 https://rgcorp.ucoz.net/load/console_soft/solid_patcher/2-1-0-97
----------------------------------------------------------
--------------------------patch------------------------
Patch add next features:

 Auto-aim is enabled by default.
 Run on the [] button, without holding the UP button.
 R1 + L3 change targets.
 R3 - action\attack.
 Map launch: L2 button.
 Gun reload: R1+[].
----------------------------------------------------------
For the map launch and gun reload modification,
was used code research from Sharpnull.
----------------------------------------------------------
The checksum corresponds to the single-track image of the game.
If you have a two-track image, patch it to the first track. And ignore the checksum verification.
"Resident Evil 2 - Dual Shock Ver. (USA) (Disc) (Leon) (Track 1).bin"
"Resident Evil 2 - Dual Shock Ver. (USA) (Disc 2) (Claire) (Track 1).bin"
----------------------------------------------------------
Author by Mr2.
e-mail: rgcorpsoft@gmail.com
https://rgcorp.ucoz.net/