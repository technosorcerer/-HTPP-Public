~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
~----------------------- Rescue Shot 60Hz Patch -------------------------~
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Patch version: v1.0

Author: Static

Platform: Playstation 1

Date: 2000-05-08

--- Info -----------------------------------------------------------------

This is an old 60Hz patch (selector screen) for the PAL release of Rescue Shot, originally only released in  
Japan and Europe. Making it possible to play this game in English and 60Hz with the Namco Guncon on real hardware.
Originally I tried using zapper2k to try 60Hz patch the game, but it would result in an endless loading screen after
the first boss (using an xstation).

This release doesn't have that issue and plays at the original Japanese game speed. 
No sped up gameplay or music.

The HUD however is a few pixels further down than the Japanese release, your life counter sits just a pixel 
above the 240th line of graphics (which can be an issue if you don't adjust your TV overscan) 
but everything is perfectly fully rendered and not cut off. 

Be sure to use the screen centering tool in the games option menu to move the screen upwards as much as possible.

I converted the old .psexe patch into the modern .ppf standard.


--- How to Patch ---------------------------------------------------------
Use PPF-o-Matic https://www.romhacking.net/utilities/356/

Apply the patch to a redump verified (2024-06-17) dump of the game 
"Rescue Shot (Europe) (En,Fr,De,Es,It)" 





 




