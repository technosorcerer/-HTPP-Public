Polish translation for ROX on PS1.
---
It translate all graphics in game.
---
The patch is for PAL EUR SLES-04069.
---
It's a small game.
You need to build a domino dieces.
It's relaxing and playable game...
---
Have fun!
---
krzys837@wp.pl
https://www.romhacking.net/community/8112/
https://steamcommunity.com/id/krzys8372
---
