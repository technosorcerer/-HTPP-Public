Easy Mode:

The save files included here will make the game substantially easier,
starting you off with an endgame engine and chassis.

Simply load the appropriate memory card to your emulator/system and
begin playing.

If your device does not support any of the included formats, use the
program "MemcardRex" to convert it.