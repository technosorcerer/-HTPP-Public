-= Racing Lagoon English Patch =-

How to install:

1.  Unzip the included zip file
2.  Open the included program "Delta Patcher Lite" and click the first yellow folder icon. 
3.  Choose your original unmodified "Racing Lagoon (Japan, Asia).bin" file.
4.  Click the second yellow folder icon and choose the "RacingLagoonEnglish.xdelta" file 
5.  If you don't want to lose your original unpatched game file, click the little gear icon next to the "Apply patch" box and click "Backup original file"
	-You will then need to remove the word "PATCHED" from the bin file's name later.
6.  Click "Apply patch"!
7.  Place the patched "Racing Lagoon (Japan, Asia).bin" file in the same folder as your "Racing Lagoon (Japan, Asia).cue" file and it's ready to be played!

Still have questions? Ask for help in the Discord channel: discord.gg/M4VkVemWgG
Want to support Hilltop? patreon.com/hilltopworks

Important Notes:
-If you are playing the game on DuckStation, uncheck the "Culling Correction" option in the PGXP
section of Enhancements to avoid crashes.

Credits:
-Project lead, translation, editing, graphics, and hacking: Hilltop @HilltopWorks

-Translators: Kendall @Kendalljp2, MVD, Pancake @PancakeTaicho, Mistyhands

-Hacking and Graphics: _Ombra_, SolidSnake11

-Automotive Consultants: SYD-88, RX @AngelAtRedline

-Additional Testing: CJ Iwakura

-Additional Hacking: invelica