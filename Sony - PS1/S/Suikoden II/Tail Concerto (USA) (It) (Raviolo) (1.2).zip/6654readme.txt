Tail Concerto Italian Dub Patch (1.2)(15/01/24)
Made by Raviolo - with love -

V1.2 works on emulators only!
V1.2 funziona solo su emulatore!

***WARNING! This patch may only be applied to a back-up copy of
a legally obtained copy of the game!***

HOW TO APPLY THE PATCH
This patch was made for the American version of the game.
Use DeltaPatcher to patch the game.
I suggest patching a bin+cue file.
For more info, check the readme file (leggimi) inside the patch folder.
 

***ATTENZIONE! Vi ricordo che potete applicare la patch solo sul
back-up di una copia di gioco che avete acquistato legalmente!***

COME APPLICARE LA PATCH
La Patch va applicata ad una copia americana del gioco.
Potete usare DeltaPatcher per applicare la patch.
Consiglio di patchare una bin+cue del gioco.
Per ulteriori info, date un'occhiata al file 'leggimi' nella cartella della patch.