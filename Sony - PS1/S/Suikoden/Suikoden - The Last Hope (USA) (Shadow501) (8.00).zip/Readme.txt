Hello everyone

About Suikoden - The Last Hope 

This new patch is including content different events give Odessa to become main character 
with the Hero " McDohl" 

Features:

- Different scenario for Odessa. 
- Keeping Odessa still alive. 
- Saving Gremio. 
- Saving Ted. 
- Possibility to return to Toran castle after final battle.  
- Possibility to visiting Gregminster after final battle. 
- Possibility to visiting Village of the Elves after final battle. 
And other features that support the game. 

The Patch 8.0
- Bugs Fixed
- Two Odessa added in party before go to "Moravia" solved %100
- Updated all events


Note:
- Patch working on the original version
- All rights reserved © Konami
- This Patch is for fans only, not for sales.

Attention!

To for not get any glitch please playing game, "DON'T USE SAVE MEMORY CARD!!!", "QUICK SAVESTATE!!!" , also don't "Swap CD between original!!! or Patched!!!!" , You must play from beginning.



- Useful for not freeze or glitch game "Emulator pSX 1.13" (Recommended)



Enjoy it!