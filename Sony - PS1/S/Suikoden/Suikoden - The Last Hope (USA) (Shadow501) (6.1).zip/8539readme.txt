Hello

About Suikoden - The Last Hope 

This new patch is including content different events give Odessa to become main character 
with the Hero " McDohl" 

Features:

- Different scenario for Odessa. 
- Keeping Odessa still alive. 
- Saving Gremio. 
- Saving Ted. 
- Possibility to return to Toran castle after final battle.  
- Possibility to visiting Gregminster after final battle. 
- Possibility to visiting Village of the Elves after final battle. 
And other features that support the game. 

The Patch 6.1
Modify some dialogues
Modify some treasures items


Note:
- Patch working on the original version
- All rights reserved © Konami
- This Patch is for fans only, not for sales.

 
Enjoy it!