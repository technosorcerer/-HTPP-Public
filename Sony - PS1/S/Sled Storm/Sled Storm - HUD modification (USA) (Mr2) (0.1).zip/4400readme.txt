--------------------------Info---------------------------
Game name: Sled Storm
Console: PlayStation
Game ID USA: SLUS-00955
Patcher: Cheat Patcher v0.9 or higher.
----------------------------------------------------------
--------------------------patch------------------------
The patch changes the graphic interface in following game modes:

 1 player
 Multi-player(vertical split screen)
 Multi-player(horisontal split screen)
 Time trials

--------------------Cheat Patcher------------------
Download link:
http://www.romhacking.net/utilities/1112/
----------------------------------------------------------
Author by Mr2.
e-mail: fsocp@land.ru
http://rgcorp.ucoz.net/