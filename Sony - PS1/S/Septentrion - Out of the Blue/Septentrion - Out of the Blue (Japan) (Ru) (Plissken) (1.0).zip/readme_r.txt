[SLPS-01940]Septentrion ～Out of the Blue～ 
Original file: MD5 14cf1d4dbe0b9cf0f4808dc9ae209db8
Patched file:  MD5 0131b0be6b27e8ef6635655b6a047b0b

Ромхакинг выполнил plissken, перевод от Deep_wolf

История изменений:
1.0.0 - первоначальный релиз

Другие мои переводы здесь: https://boosty.to/plissken
Твиттер на английском: https://x.com/Plissken___
Твиттер на русском: https://x.com/Plissken__ru
Дискорд на английском: https://discord.gg/n9vp4yhs5r
Дискорд на русском: https://discord.gg/gsGdhhWZKA

Личные ресурсы Deep_wolf:
https://vk.com/yellowsimpsons
https://www.youtube.com/@Deep_wolf