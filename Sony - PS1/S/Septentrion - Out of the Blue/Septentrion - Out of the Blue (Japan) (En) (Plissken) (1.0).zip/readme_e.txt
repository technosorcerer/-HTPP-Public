[SLPS-01940]Septentrion ～Out of the Blue～ 
Original file: MD5 14cf1d4dbe0b9cf0f4808dc9ae209db8
Patched file:  MD5 da22e903ec8cbf67353d0c1e52606de9

Romhacking by Plissken
Translation by Deep_wolf

History:
1.0.0 - Initial release

Other translations: https://boosty.to/plissken
Twitter/X: https://x.com/Plissken___
Discord: https://discord.gg/n9vp4yhs5r

Deep_wolf's blogs (in Russian):
https://vk.com/yellowsimpsons
https://www.youtube.com/@Deep_wolf