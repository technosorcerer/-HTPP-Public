Spyro 3.5: Return to the Forgotten Realms by Hwd405 and Jeremy Thompson
------------------------------------------------------------------------

Contained in this release:
* SpyroYotDChallengeMode.exe - the patching tool
* resources/ - a folder full of resources used in the patching process
* dumpsxiso.exe - Lameguy64's iso extraction tool
* mkpsxiso.exe - Lameguy64's iso creation tool
* README.txt - this file
* CREDITS.txt - full credits
* CHANGELOG.txt - changelog

------------------------------------------------------------------------

The easiest method to run the tool is simply to drag and drop the .bin / .iso file of your choosing onto SpyroYotDChallengeMode.exe. Then, simply follow the instructions shown in the command window.

If this does not work, or you'd like a consistent step-by-step method of running the tool, follow these steps:
* Open Windows Explorer and create a directory for the game.
* Put the ISO file, the patcher exe, both dumpsxiso.exe and mkpsxiso.exe, and the resources directory into a folder.
* Rename the ISO file to spyro3.bin. Note that this is not required to run the tool, but all commands in this section will assume that you have renamed the file in this way.
* In Windows Explorer, in the same directory as before, enter "cmd" into the address bar and press enter. A cmd window should appear.
* Run the following command:

SpyroYotDChallengeMode.exe "spyro3.bin"

* Wait for this to complete.

------------------------------------------------------------------------

Note that if the filename of the ISO has spaces contained within it, the filename must have quotes around it when running the command.

PAL versions of the game are not supported. Additionally, attempting to run the tool against an already patched file will fail.

Please enjoy this hack - a lot of time, effort and love has gone into making it.