"Street Fighter Alpha 2"
Traducción al Español Ver. 1.0 (11/03/2025)
por Max1323 (Traducciones Max1323).
---------------------------------------------------
Descripción:
La historia de Street Fighter Alpha 2 se desarrolla seis
meses después de la historia del primer Street Fighter y
seis años antes de los eventos de Street Fighter II.

Desarrollado: Capcom
Publicado:    Capcom
Lanzamiento:  09/08/1996 (JAP)
	      30/09/1996 (USA)
	      XX/12/1996 (EUR)
---------------------------------------------------
Acerca del proyecto:
-La mayoría de los textos están traducidos.
---------------------------------------------------
Instrucciones del parche:
Utilizar Rom Patcher (Parcheador Online):
https://romhackplaza.org/patch/
Recomendación:
Utilizar xdelta UI
https://www.romhacking.net/utilities/598/

1° Agregar el parche en Patch
2° Agregar el juego sin modificar en Source File
3° Al guardar el juego en Output File, es necesario agregar el nombre con la extensión Ejemplo.bin
Atención: Mantener el mismo nombre del archivo original para que no aparezca algún error.

Archivo xdelta. Aplicar el parche solo al Track 1.
Street Fighter Alpha 2 (USA) (Track 1).bin
File Size     543 MB
File MD5      BD36CFBFF67D6314BFA0E9BE0D4557F7        
File SHA-1    E63DE691E13C6E6BF1AE327597A66717A8D887EA
File CRC32    E3E36D91
Número de Serie: SLUS-00258

Street Fighter Alpha 2 (USA) (Track 2).bin
File Size:    42 MB
File MD5      9E59C2FEC7C6D2921C21BBDAEE41F993        
File SHA-1    BFD1FC889C31A5C1066C741CD1D0E152B151CB24
File CRC32    3521B8E4

Street Fighter Alpha 2 (USA).cue
File Size:    1 KB
File MD5      6236AD7875BEAAE478A1264444AF1C68        
File SHA-1    1E65C88EDEAB3FE33BF48A2C1783B30779A1D131
File CRC32    3A1544FF