SCREAMING MAD GEORGE'S PARANOIASCAPE
ENGLISH TRANSLATION V1.00
Copyright 2025 by Aeon Genesis
http://www.aeongenesis.net

ToC

0.  Hosting notes
1.  About Paranoiascape
2.  Patch History
3.  Patch Credits and Contributors
4.  Known issues
5.  Application Instructions


---------------
0.Hosting Notes
---------------
Please note that romhack.ing is an authorized patch redistributor.
This patch is expressly forbidden from being hosted at romhacking.net.

---------------------
1.About Paranoiascape
---------------------
Paranoiascape is a first-person surrealist horror pinball game. If that sounds insane, it is! I don't want to say much more because it really is something that should be experienced, not described, but I will note that the game does have an option for an infinite number of pinballs - I recommend setting this. You still have a health bar and can still die, but this option reduces some of the extra frustration that dropping the ball can create.

As far as the patch goes, before each level there's a screen offering some tips for the level - this translates that. There are also some voice clips in 3-2 where Screaming Mad George himself gives you feedback -- it turns out that he recorded English versions of these and included them on the disk, and I was able to swap the calls to the Japanese clips with calls to the English clips!

---------------
2.Patch History
---------------

October 11, 2025 - Initial v1.00 Release

---------------
3.Patch Credits
---------------
THE PARANOIASCAPE TEAM
Gideon Zhi    - Project leader, lead romhacker, assembly work
Matatabi      - Translation

--------------
4.Known Issues
--------------
There are no known issues.

--------------------------
5.Application Instructions
--------------------------
Quick ISO Info:

MD5-SUM: EFDE909F9C8AA9F31529829396D36A54
SHA-256: 81E53B7AC8B1E6A4354F0674CADCD154EC5D3142862FFB217ADBA370FDB22127