﻿--------------------------Info---------------------------
Game name: C-12: Final Resistance
Console: PlayStation
Game ID Europe: SCES-03364
Language: English
Patch: SP (Solid patch)
Patcher: Solid patcher
Patcher download link:
https://rgcorp.ucoz.net/load/console_soft/solid_patcher/2-1-0-97
----------------------------------------------------------
--------------------------patch------------------------
Patch add next feature:

 The reverse has been removed, from the camera control with the right analog and directional buttons.
 The vertical reverse has been removed, from aim control with left analog and directional buttons.

 R1 - aim. (first personal mode)
 R2 - lock target / strafe.
 L3 - crouch.
 R3 - center the camera. (you need to hold the button)
----------------------------------------------------------
The checksum corresponds to the single-track image of the game.
If you have a two-track image, patch it to the first track. And ignore the checksum verification.
"C-12 - Final Resistance (Europe) (Track 1).bin"
----------------------------------------------------------
Author by Mr2.
e-mail: rgcorpsoft@gmail.com
https://rgcorp.ucoz.net/