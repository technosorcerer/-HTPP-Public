--- Clock Tower (US)/Clock Tower 2 (JP) - Debug Menus ---

Use DeltaPatcher to apply the .xdelta path to the .bin file of the game (for the Hyper PlayStation Re-mix demo, apply to the Track 01 bin)

[Changes]
Can now press START on controller 2 to show the most recent debug menu. Press START again to return. Alternatively, press L1 or R1 on controller 2 to show the previous or next menu instead (doesn't work if you're already in a menu). Once displayed, every menu behaves exactly as coded by HUMAN Entertainment for earlier builds such as the Hyper PlayStation Re-mix one, including START being used to exit.

[General controls within menus]
Face buttons are commonly used to change values, while shoulder buttons are used to choose which option to alter. The "VIEW FREE" menu is a bit different. For that one, hold R1 to move camera and hold R2 to rotate and finally use X and TRIANGLE on controller 1 to zoom in and out. Also, on the SCALE FREE menu, you can use the D-pad to scale all axes simultaneously.