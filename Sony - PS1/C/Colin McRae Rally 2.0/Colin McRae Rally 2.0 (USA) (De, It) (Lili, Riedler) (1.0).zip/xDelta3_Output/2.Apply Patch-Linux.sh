#!/bin/sh
cd "$(cd "$(dirname "$0")" && pwd)"
mkdir ./output
chmod +x ./exec/xdelta3_x64_linux
echo Place the files to be patched in the \"original\" directory with the following names:
echo --------------------
echo "Colin McRae Rally 2.0 (USA) (En,Fr,Es).cue"
echo "Colin McRae Rally 2.0 (USA) (En,Fr,Es) (Track 1).bin"
echo "Colin McRae Rally 2.0 (USA) (En,Fr,Es) (Track 2).bin"
echo --------------------
echo Patched files will be in the \"output\" directory
read -p "Press enter to continue..." inp
./exec/xdelta3_x64_linux -v -d -s "./original/Colin McRae Rally 2.0 (USA) (En,Fr,Es).cue" "vcdiff/Colin McRae Rally 2.0 (USA) (En,Fr,Es).cue.vcdiff" "./output/Colin McRae Rally 2.0 (USA) (En,De,It).cue"
./exec/xdelta3_x64_linux -v -d -s "./original/Colin McRae Rally 2.0 (USA) (En,Fr,Es) (Track 1).bin" "vcdiff/Colin McRae Rally 2.0 (USA) (En,Fr,Es) (Track 1).bin.vcdiff" "./output/Colin McRae Rally 2.0 (USA) (En,De,It) (Track 1).bin"
./exec/xdelta3_x64_linux -v -d -s "./original/Colin McRae Rally 2.0 (USA) (En,Fr,Es) (Track 2).bin" "vcdiff/Colin McRae Rally 2.0 (USA) (En,Fr,Es) (Track 2).bin.vcdiff" "./output/Colin McRae Rally 2.0 (USA) (En,De,It) (Track 2).bin"
