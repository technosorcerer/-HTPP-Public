=====================================================
------ Captain Tsubasa J-Get in the Tomorrow --------
=====================================================
----------------------- Info ------------------------
Game name: Captain Tsubasa J-Get in the Tomorrow
Console: PlayStation 1
Game ID USA: SLPS_003.10
Hack version: 0.1
Patch: PPF(PlayStation Patch Format)
Patcher: ppf-o-matic3
File/ROM CRC32:   2ed16cb1
File/ROM MD5:     65322d6a952e9ddaeb2e3cce4ff71de0
File/ROM SHA-1:   7c0a6ec32b2b0867e2258d1de22d03735514b3a4
----------------------- v0.1 ------------------------
* All Teams are unlocked by default (at the beginning of the game)
* Unrestricted selection of the same team
=====================================================
-------------------- PPF Patcher --------------------
Download link:
http://www.romhacking.net/utilities/356/
=====================================================
Author: acemon33
E-mail: zaxmon33@gmail.com