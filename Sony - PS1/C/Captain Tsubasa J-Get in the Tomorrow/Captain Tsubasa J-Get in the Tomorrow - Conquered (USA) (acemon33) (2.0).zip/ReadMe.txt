=========================================================
--- Captain Tsubasa J - Get in the Tomorrow Conquered ---
=========================================================

-------------------- Description --------------------
This patch unlocks All teams at the start of the game, 
all the supershots of the players, and allows both players to select the same team.

------------------------- Info --------------------------
Game name: Captain Tsubasa J-Get in the Tomorrow
Console: PlayStation 1
Game ID: SLPS_003.10
Hack version: 2.0
Patch: xdelta file format
Patcher: xdeltaUI / DeltaPatcher
File/ROM CRC32:   BFBFC5E9
File/ROM MD5:     17C0B148316458F56EA8F47D38B693FF
File/ROM SHA-1:   97CE5437CE229074A0E12A4A238011A2FC4410C4

------------------------- v2.0 --------------------------
* Unlock supershots of all players
* Increase GK catch rate (Hopefully to balance the gameplay!)

------------------------- v0.1 --------------------------
* All Teams are unlocked by default (at the beginning of the game)
* Unrestricted selection of the same team 

=========================================================

---------------------- How to Use ----------------------
Use DeltaPatcher on a clean vanilla image file (.bin) to apply the patch.
Download any of these links:
https://github.com/marco-calautti
https://www.romhacking.net/utilities/704/
https://www.romhacking.net/utilities/598/
https://romhackplaza.org/utilities/xdelta-ui-utility/

=========================================================

----------------------- Contact Me ----------------------
Author:  acemon33
E-mail:  zaxmon33@gmail.com
Discord: acemon33#3218
github:  https://github.com/acemon33