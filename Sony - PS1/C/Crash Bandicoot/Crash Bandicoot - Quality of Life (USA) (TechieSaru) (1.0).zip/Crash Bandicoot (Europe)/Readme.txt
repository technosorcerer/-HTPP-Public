Please use PPF-O-MATIC V3.0 to apply this patch.
It can be downloaded at: https://www.romhacking.net/utilities/356/

Apply the patch to the .bin file for your game