This improvement hack reactivates some details that were removed in the retail version and
other features that were only available in the Japanese version, see the list below.

Changelog v1:
* Unlock Secret passage in Castle Entrance (Normal and Inverted Castle)
* Fix missing pallete in Save Room from Secret Passage (Normal and Inverted Castle)
* Activate the unused title description text
* Activate the Sprite/Pixie and Nosedevil card in the Relic menu
* Sprite/Pixie and Nosedevil japanese names translated into English
* Add Pixie Card in the Olrox's Quarter's like the Japanese Version
* Add Nosedevil Card in the Catacombs like the Japanese Version
* Pixie can Sing "Nocturne" (After level 90)
* Uncensored priest's speech in the Royal Chapel
* Activate the unused Richter spin kick and double jump moves

WEBSITES:
* https://retro-jogos.com
* https://www.youtube.com/RetroJogos