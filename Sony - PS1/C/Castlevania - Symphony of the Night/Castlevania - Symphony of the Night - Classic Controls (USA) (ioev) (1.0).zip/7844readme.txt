  -=- Castlevania: Symphony of the Night (USA) - Classic Controls v1.0 -=-
          By ioev, email: zimmatic@gmail.com, discord: ioev#3061
                       Released on May 16th, 2023

A patch that restores the original Japanese button layout along with a few
small tweaks:

* Skip intro movies and start the game with the O button


                     -=- Installation Instructions -=-

This patch is for the redump verified iso: http://redump.org/disc/3379/

Patch your .bin with the included xdelta file, and make any necessary changes to
the cue file if the filename changes.

Please let me know if you run into any problems!


                            -=- Tools used -=-

* PCSX-Redux (debugging and testing)
* jPSXdec (extracting the iso)
* HxD (for a little bit of everything)
* Some custom Ruby stuff for searching/patching
* psx-mode2 (inserting modified files back into the iso)
* MiSTer PSX Core (for final testing/playthrough)