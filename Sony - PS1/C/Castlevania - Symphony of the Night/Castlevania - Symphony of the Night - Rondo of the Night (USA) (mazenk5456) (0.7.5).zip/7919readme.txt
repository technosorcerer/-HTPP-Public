Castlevania Rondo of The Night
1. Game patch 
1.1 How to Music patch
1.2 Music patch 1
1.3 Music patch 2
2. Changes
3. patch changes 0.7.5
4. How to play 
5. What to do
6. What to not do 
7.WHIP FIXED 


1. Game patch 
Patch your game with the PPF file you can find over to romhack.net:
https://www.romhacking.net/hacks/7919/

You can patch your game by using the online ROM patcher that romhacking.net provides:
https://www.romhacking.net/patch/ 

Once you there you need to place your original copy of the game (Castlevania - Symphony of the Night (USA) (Track 1).bin) in "ROM file:" and the PPF file you got from the romhacking.net site goes in "Patch file:"

1.1 How to Music patch
Music patch is an optional separate PPF file for the hack you can find it on this YT video description:
https://www.youtube.com/watch?v=Odm63vs7wBc


The procedure its the same as you did with the main patch EXCEPT this time you gonna place your hacked copy of Rondo of The Night in "ROM file:" instead of the vanilla game and music patch file PPF goes into "Patch file:"

Database match: Castlevania - Symphony of the Night (USA) (Track 1).bin
Database: No-Intro: Genesis (v. 20210226-213851)
File/ROM SHA-1: F967119E006695A59A6442237F9FC7C7811CF7BF
File/ROM CRC32: 5BE47B


1.2 Music patch 1

-replace all sotn music with  megaman and other castlevania games music 


1.3 Music patch 2

-replace all sotn music with fancy custom of choice musics from multiple other games


2. Patch changes  0.0.1-0.6.2

-Richter has access the game menu now + hud of Alucard
-Richter has access to the library shop 
-Richter can level up 
-The martial art Blade dash increases its damage out of your current INT stat
-The martial art Slide kick increases its damage out of your current STR stat
-Added new music
-No sub weapons or item crashes in this demo
-Buffed enemies and nerf some, added different patterns to some bosses 
-You can now cancel your whip attack animation with blade dash whether you touching ground or not
-Added new names to weapons
-Enemies readjustment to balance the game
-Blade dash new ability behind relic (Slideless)
-Backflip has iframes by default (yay!)
- you can do backflip anytime in air 
- you can change direction in the backflip or slidekick (locked removed ) 
-slide kick go straight usually now but you can turn around anytime you want 
-you can cancel backflip and slidekick with blade dash left and right 
- sub weapons added and item crashes 
-increase  item crashes cost and nerf dmg
- level up animation is back
-backflip can be done while moving after jumping or running after jumping 
- increase succbus chance of throwing balls and clones 
- incrase succbus balls speed 
- change color palette of slogra and gaibon 
- Cerberus got buffed in speed and jump
 - replacing items and relics location
- backflip can be unlocked with relic now


3. Patch changes 0.7.5
-blade dash added upgrade relic (beyblade)
-uppercut added upgrade relic (rising strike)
-red bird actual boss 
-black bird actual boss
-relics icon and color change
- blade dash can be performed by down+foward+ circle 
- medusa got buffed in her lazer speed and hit box 
- doppelganger change color palette
- dangle whip removed fully for now
-- library card relic removed
-- bey blade input changed to pressing R2 not holding R2
-- mighty rich relic added ,richter can do blade dash diagonal by holding R1, if you are in jump animation you will do up words blade dash , if you are in falling animation you will do down words blade dash


4. How to play
- To increase your attack equip weapons in your right(first) hand only 
- Equip food items will lead you to deal 0 dmg (No hits) to enemies
- Richter starts without bladedash, uppercut and slidekick so you need to get them
- In order to increase your stats by level just open the menu and close it 
- In order to enter Minotaur and were wolf fight you have to jump stright before the locked door
- When you exit the shop select "exit" in the shop menu, otherwise you'll get softlocked 
-Skipping every cutscene helps avoding possible crashes 
- to do bayblade hold R2 and do blade dash
- to do uppercut high you must have uppercut+ rising strike and then hold L1 and do uppercut

5. What to do
Get Holy glasses on the normal castle in order to unlock the inverted castle, collect all (5) vlad relics in order to fight dracula's third form

6.  What to not do
- Do not active bat card, ghost card, demon card, etc
- Do not equip axe lord armor by any means and if you do make sure you don't save your game or its gonna crash
- don't unquip (empty hand) then save then reload the save then open the menu then close it 


7. WHIP FIXED
whip is finally fixed enjoy 
