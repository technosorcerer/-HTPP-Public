castlevania richter mod (patch) 
1. Game patch 
2. Changes
3. How to play 
4. Do not do 
5. Unlocking the inverted castle


1. Game patch 
Patch your game with the PPF file you can find over to romhack.net then patch the music with youtube link 

Database match: Castlevania - Symphony of the Night (USA) (Track 1).bin
Database: No-Intro: Genesis (v. 20210226-213851)
File/ROM SHA-1: F967119E006695A59A6442237F9FC7C7811CF7BF
File/ROM CRC32: 5BE47B



2. Changes v0.6

-Richter can access the game menu now + hud of Alucard
-Richter has access to the library shop 
-Richter can level up 
-The martials blade dash and slide kick scale its damage out of your current attack? int str stats 
-New added custom music
-No sub weapons or item crashes in this demo
-Buffed enemies and nerf some, added different patterns to some bosses 
-You can now cancel your whip attack animation with blade dash whether you touching ground or not
-Added new names to weapons

3. How to play
- To increase your attack equip weapons in your right(first) hand only 
- Equip food items will lead you to deal 0 dmg (No hits) to enemies
- Richter starts without bladedash, uppercut and slidekick so you need to get them
- In order to increase your stats by level just open the menu and close it 
- In order to enter Minotaur and were wolf fight you have to jump stright before the locked door
- When you exit the shop click exit in the shop menu, otherwise you'll get softlocked 

4.  Do not do
- Do not force sub weapons to use them by any means
- Do not active bat card , ghost card , demon card, etc


4. Unlocking the inverted castle
collect all of the vlad relics + holy glasses 


