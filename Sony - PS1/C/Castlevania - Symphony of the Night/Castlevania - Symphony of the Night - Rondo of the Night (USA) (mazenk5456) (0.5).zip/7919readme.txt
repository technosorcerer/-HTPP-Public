castlevania richter mod (patch)
0-game patch 
1-changes
2-how to play 
3-do not do 
4-end of the game


0- game patch 
patch the game with file in romhack.net then patch the music with youtube link 

Database match: Castlevania - Symphony of the Night (USA) (Track 1).bin
Database: No-Intro: Genesis (v. 20210226-213851)
File/ROM SHA-1: F967119E006695A59A6442237F9FC7C7811CF7BF
File/ROM CRC32: 5BE47B



1- changes v0.5

-richter can access the menu now + hud of alucard 
-richter can level up 
-richter scale his dmg out of attack,int,str for whip ,blade dash,slide kick
-new added custom music
-no sub weapons or item crashes in this demo
-buffed enemies and nerf some, added different patterns to some bosses 
-blade dash can be chainable fully with whip now 


2-how to play
- to increase your attack equip weapons in right hand only 
- food items , consumables will do 0 dmg
- richter starts without bladedash,uppercut,slidekick so you have to get them
-to increase your stats by level just open the menu and close it 
- to enter Minotaur and were wolf fight you have to jump stright before the locked door
-when you exit the shop click exit in the shop menu 

3- do not do
- do not force sub weapons to use them by any means
- do not active bat card , ghost card , demon card, etc


4-end of the game
collect all vlad relics + holy glasses 


