Castlevania Symphony of the Night - Survival Mode 

Hack by Razi

This patch is a harder version of Symphony of the Night, PSX NTSC-U (slus_000.67).

==This patch includes==
*300% HP of ALL Bosses, (except Dracula in prologue, you can still beat him under
1 minute). 300% compared with the original game. 100% in the original.
*300% HP includes Shaft's Orb when you fight with Richter.
*270% HP of Galamoth.
*300% HP includes simple monsters like Karasuman, Slogra and Gaibon
in the Inverted Castle, because they shares same HP with bosses Karasuman, Slogra and Gaibon.
 
*250% HP includes Lesser Demon (boss and monsters)

 Increased time of items disappearing, from 5 to 8 seconds (except hearts, money, sub-weapons). Item after 4 seconds starts to blink, then item blinks for 4 second, which gives totally 8 seconds.
 
 Added infinite Wing Smash (like in Sega Saturn version)

 Ability to restore HP in the save rooms was removed
 
 Ability to restore MP in the save rooms was removed

 No other changes. The rest is the same as in the original.