Castlevania Symphony of the Night - Boss Mode 
v 1.2
Hack by Razi

This patch is a harder version of Symphony of the Night, PSX NTSC-U (slus_000.67).

==This patch includes==
*300% HP of ALL Bosses, (except Dracula in prologue, you can still beat him under
1 minute).
*300% HP includes Shaft's Orb when you fight with Richter.
*270% HP of Galamoth.
*300% HP includes simple monsters like Karasuman, Lesser Demon, Slogra and Gaibon
in the Inverted Castle, because they shares same HP with bosses Karasuman, Lesser
Demon, Slogra and Gaibon.

No other changes. The rest is the same as in the original.

Additional information: Be careful in the necromancy laboratory because Lesser
demons very often summons demonic allies.