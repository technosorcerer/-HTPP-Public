Castlevania Rondo of The Night
1. Game patch 
1.1 How to Music patch
2. Patch changes 1.3
3. Colors patch 
4. WHIP FIXED 
5. What do you expect from the final version of RotN (v2.0)?
6. Credits


1. Game patch 
Patch your game with the PPF file you can find over to romhack.net:
https://www.romhacking.net/hacks/7919/

You can patch your game by using the online ROM patcher that romhacking.net provides:
https://www.romhacking.net/patch/ 

Once you there you need to place your original copy of the game (Castlevania - Symphony of the Night (USA) (Track 1).bin) in "ROM file:" and the PPF file you got from the romhacking.net site goes in "Patch file:"

1.1 How to Music patch
Music patch is an optional separate PPF file for the hack you can find it on this YT video description:
https://www.youtube.com/watch?v=Odm63vs7wBc


The procedure its the same as you did with the main patch EXCEPT this time you gonna place your hacked copy of Rondo of The Night in "ROM file:" instead of the vanilla game and music patch file PPF goes into "Patch file:"

Database match: Castlevania - Symphony of the Night (USA) (Track 1).bin
Database: No-Intro: Genesis (v. 20210226-213851)
File/ROM SHA-1: F967119E006695A59A6442237F9FC7C7811CF7BF
File/ROM CRC32: 5BE47B


1.2 Music patch 1

-replace all sotn music with  megaman and other castlevania games music 


1.3 Music patch 2

-replace all sotn music with fancy custom of choice musics from multiple other games


1.4 Music patch 3 
-replace all sotn music and audio with new story of rotn




Patch changes 1.3

- Changed all items location around the castle
- Rebalance all enemies and equipments
- Added items called cores for vampire killer to power up
- New weapons
- Rename alot of stuff
- added tips items
- save menu palette and map palette changed
- item crashes and sub weapons work
- fix the animation of the swords downwords so you would swing down
- added new feature ( sub weapon select )

notes for 1.3
- Richter can now use BOTH VampireKiller whip and weapons found in the castle. You can switch between them in the menu, via the Left hand (now just called Weapons)
- The Right Hand is now called Soul Core, which you will eventually acquire Cores in the game. Equip them in Soul Core to power up the Whip if you want to use it, as well as the strength of Blade Dash.
- changing from normal weapons to whip sometimes causes glitchy graphics, and if this happens, just save the game and do a soft reset.
- some medicines (if you still get them), like HAX. Potion, will straight up crash the game so don't use it xD Heart Refresh works though, and it's very useful.

 Patch changes 1.2
- spin kick bounce back restored
- fixed all the areas bugs
- fixed item bugs
- changed colors palettes of some weapons
- changed item locations
- rebalance some enemies
- fixed diagonal slashes for all weapons almost
- added new weapon called blaze 

 optional Patch changes (whip)
- richter vampire killer only weapon 
- spin kick bounce back
- sub weapons is there 





4. Colors patch (change richter color)
patch the main game then patch it again with color then with the music 
-14 colors added in total
-few adjustments to white, pink and lighter & brighter light blue so it looks more fitting to sight +4 "special" colors added 


6. What to do
Get Holy glasses on the normal castle in order to unlock the inverted castle, then collect all (5) vlad relics in order to fight dracula's third form

8. Whip fixed
whip is finally fixed enjoy 


9. What do you expect from the final version of RotN (v2.0)?
(Feel free to leave more suggestions at my discord server)
- colors sprite whip added
- cape color change depends on which cape you wearing
- new bouns playable characters 
- richter texture in cutsenses instead of alucard
- dialogue change text

10.Credits

Mazenk : the developer who did all this
Oyyy/nukesheart : rebalance, design, testing , making
Kris Naga: testing, decision making, design
Mott : helped alot with alot of codes in the rom hack
Mauk696 : helped alot with coding bosses & enemeies 
paul_met: giving permission to include quality hack to rotn
Sonic dreamcaster : helped with decomp project
Xeeynamo : helped with decomp project

