Castlevania Rondo of The Night
1. Game patch 
1.1 How to Music patch
1.2 Music patch 1
1.3 Music patch 2
1.4 Music patch 3 + story audio 
2. Patch changes  0.0.1-0.6.2
3. Patch changes 1.0
4. Colors patch
5. How to play 
6. What to do
7. What to not do 
8. WHIP FIXED 
9. What do you expect from the final version of RotN (v2.0)?
10. Credits


1. Game patch 
Patch your game with the PPF file you can find over to romhack.net:
https://www.romhacking.net/hacks/7919/

You can patch your game by using the online ROM patcher that romhacking.net provides:
https://www.romhacking.net/patch/ 

Once you there you need to place your original copy of the game (Castlevania - Symphony of the Night (USA) (Track 1).bin) in "ROM file:" and the PPF file you got from the romhacking.net site goes in "Patch file:"

1.1 How to Music patch
Music patch is an optional separate PPF file for the hack you can find it on this YT video description:
https://www.youtube.com/watch?v=Odm63vs7wBc


The procedure its the same as you did with the main patch EXCEPT this time you gonna place your hacked copy of Rondo of The Night in "ROM file:" instead of the vanilla game and music patch file PPF goes into "Patch file:"

Database match: Castlevania - Symphony of the Night (USA) (Track 1).bin
Database: No-Intro: Genesis (v. 20210226-213851)
File/ROM SHA-1: F967119E006695A59A6442237F9FC7C7811CF7BF
File/ROM CRC32: 5BE47B


1.2 Music patch 1

-replace all sotn music with  megaman and other castlevania games music 


1.3 Music patch 2

-replace all sotn music with fancy custom of choice musics from multiple other games


1.4 Music patch 3 
-replace all sotn music and audio with new story of rotn


2. Patch changes  0.0.1-0.6.2

-Richter has access the game menu now + hud of Alucard
-Richter has access to the library shop 
-Richter can level up 
-The martial art Blade dash increases its damage out of your current INT stat
-Added new music
-Buffed enemies and nerf some, added different patterns to some bosses 
-You can now cancel your whip attack animation with blade dash whether you touching ground or not
-Added new names to weapons
-Enemies readjustment to balance the game
-Blade dash new ability behind relic (Slideless)
-Backflip has iframes by default (yay!)
- you can do backflip anytime in air 
- you can change direction in the backflip or slidekick (locked removed ) 
-slide kick go straight usually now but you can turn around anytime you want 
-you can cancel backflip and slidekick with blade dash left and right 
- sub weapons added and item crashes 
-increase  item crashes cost and nerf dmg
- level up animation is back
-backflip can be done while moving after jumping or running after jumping 
- increase succbus chance of throwing balls and clones 
- incrase succbus balls speed 
- change color palette of slogra and gaibon 
- Cerberus got buffed in speed and jump
 - replacing items and relics location
- backflip can be unlocked with relic now


3. Patch changes 1.0
-blade dash added upgrade relic (beyblade)
-uppercut added upgrade relic (rising strike)
-red bird actual boss 
-black bird actual boss
-relics icon and color change 
- medusa got buffed in her lazer speed and hit box 
- doppelganger change color palette
- dangle whip removed fully for now
-- bey blade input changed to pressing R2 not holding R2
-- mighty rich relic added ,richter can do blade dash diagonal by holding R1, if you are in jump animation you will do up words blade dash , if you are in falling animation you will do down words blade dash
- texture image added to menu (RICHTER PORTRAIT)
- rebalance enemeis and items 
- SPIN KICK ADDED
- SPIN KICK IN relic 
- SPIN KICK PEFORM BY DOWN FOWARD + CIRCLE
- BLADE DASH DOWN FOWARD + SQAURE 
- RICHTER CAN POSE EDGY LIKE HARMONY AND PORTRAIT BY HOLDING UP
-SFX RICHTER FROM BOSS FIGHT
- SPIN KICK BOUNCE AFTER HITTING ANYTHING 
- SPIN KICK SCALE WITH CON
- SPIN KICK REVIVE FIX
- adjusted spin kick damage
- added level 1 patch
- Minotaur and Werewolf moveset change
- quality hack added in rotn
--------------------------------------
- Soy milk and Holy water difficulties added

Holy water is the standard experience intended for RotN we hope you have fun with it and enjoy it!

Soy milk is an easier version of the standard experience. Richter is a lot more stronger, you have early access to your first ring of varda within the second skeleton you kill when you enter the castle and the only 2 one-shots in the entire game are removed.
----------------------------------------------------
- doppelganger boss fight adjusted little


4. Colors patch (change richter color)
patch the main game then patch it again with color then with the music 
-14 colors added in total
-few adjustments to white, pink and lighter & brighter light blue so it looks more fitting to sight +4 "special" colors added 


5. How to play
- To increase your attack equip weapons in your right(first) hand only 
- Equip food items will lead you to deal 0 dmg (No hits) to enemies
- Richter starts without bladedash, uppercut and slidekick so you need to get them
- In order to increase your stats by level just open the menu and close it 
- When you exit the shop select "exit" in the shop menu, otherwise might get softlocked 
-Skipping the cutscene after saving richter will help you not crash (The little inverted castle animation cutscene)
- to do uppercut high you must have uppercut+ rising strike

6. What to do
Get Holy glasses on the normal castle in order to unlock the inverted castle, then collect all (5) vlad relics in order to fight dracula's third form

7.  What to not do
- Do not active bat card, ghost card, demon card, etc
- Do not equip axe lord armor by any means and if you do make sure you don't save your game or its gonna crash
- don't unquip (empty hand) then save then reload the save then open the menu then close it 
- don't equip anything in left hand (unless you want glitchy looking whip)
- don't jump/blade dash at the middle of the clook room with both silver and gold ring equipped, otherwise the game is gonna crash. You're supposed to calmly walk to the side and the cutscene is going to trigger correctly

8. Whip fixed
whip is finally fixed enjoy 


9. What do you expect from the final version of RotN (v2.0)?
(Feel free to leave more suggestions at my discord server)
- colors sprite whip added
- cape color change depends on which cape you wearing
- new bouns playable characters 
- richter texture in cutsenses instead of alucard
- dialogue change text

10.Credits

Mazenk : the developer who did all this 
Kris Naga: testing, decision making, design
Mott : helped alot with alot of codes in the rom hack
Mauk696 : helped alot with coding bosses & enemeies 
paul_met: giving permission to include quality hack to rotn
Sonic dreamcaster : helped with decomp project
Xeeynamo : helped with decomp project
