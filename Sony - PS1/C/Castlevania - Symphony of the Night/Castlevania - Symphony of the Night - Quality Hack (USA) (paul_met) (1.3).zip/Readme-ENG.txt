Castlevania: Symphony of the Night (PSX) - QHack (v1.3)
=======================================================

About QHack:
~~~~~~~~~~~~
- This hack is designed to improve the quality of the original game in both the visual and gameplay.
- To use this hack you need the original USA version of the game (SLUS-00067) and "PPF O MATIC" tool.

	MD5 (data track):	acbb3a2e4a8f865f363dc06df147afa2
	MD5 (audio track):	8f4b1df20c0173f7c2e6a30bd3109ac8
	CRC32 (total):		acf987e8

Changes in version 1.3:
~~~~~~~~~~~~~~~~~~~~~~~
- Activation of stereo sound mode by default.
- The previously missed loading room on the global map is highlighted in white.

Changes in version 1.2:
~~~~~~~~~~~~~~~~~~~~~~~
- Adjusted height of the magic pillar when using the cross by Richter (ingame).
- Updated the tile maps in locations with emerging mermans from water.

Changes in version 1.1:
~~~~~~~~~~~~~~~~~~~~~~~
- Adjusted vertical position of HUD (for Richter, Dracula and Alucard).
- Adjusted vertical position of Alucard in the final scene (bad ending).
- Adjusted height of the magic pillar in the opening scene (when Maria restores Richter).


Changes in version 1.0:
~~~~~~~~~~~~~~~~~~~~~~~
- Removed black bars on the top and bottom of the screen (ingame, menu, final scene).
- Updated the tile maps of all locations to increase the visible area of the screen.
- Unlocked and finalized rooms under the hatch (at the entrance to the usual and reverse castles).
- The positions of some menu items have been changed (expanded backgrounds & frames, etc.).
- Impossibility to leave the castle through the gate by playing for Richter.
- Impossibility to keep the initial equipment of Alucard (avoiding a meeting with Death, using the trick with a wolf, is no longer possible).
- Impossibility of going outside the castle in the location of "Royal Chapel" (in the form of a bat).
- The loading rooms on the global map are now highlighted in white.

Credits:
~~~~~~~~
paul_met - hacking
Maximum - testing

Contacts:
~~~~~~~~~
Web: http://meduza-team.ucoz.net
Email: paul-met@yandex.ru