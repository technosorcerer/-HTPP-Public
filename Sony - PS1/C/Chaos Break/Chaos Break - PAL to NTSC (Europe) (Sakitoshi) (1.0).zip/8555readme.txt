this patch is for the redump dump, you'll know because it has 2 bin files.
apply the patch to Chaos Break (Europe) (En,Fr,De,It) (Track 1).bin (CRC32: E957B273).
the titleid was changed to slus-03107 which is unused.
don't forget to edit your cue file if you rename the bins.
xdelta 3.1.0 was used to create this patch.
have fun!

changelog:
v1.0
initial release.
