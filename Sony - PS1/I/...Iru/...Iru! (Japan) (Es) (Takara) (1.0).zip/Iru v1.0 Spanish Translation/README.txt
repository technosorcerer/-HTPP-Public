#####################################################################
...ya están aquí! (...iru!) Traducción en castellano v1.0 (Julio 2021)
#####################################################################

## Introducción ##

Tú y algunos compañeros os quedáis hasta tarde en el colegio para preparar el 
festival cultural de mañana. Pero hay algo mucho más siniestro en marcha...
¿Podrás sobrevivir a los horrores de la escuela y escapar con vida?

...ya están aquí! Es más una novela/puzzle narrativo que un survival horror.
El juego progresa al hablar con otros personajes y utilizar objetos.
Sólo puedes correr y esconderte cuando afrontes un peligro.

El parche ha sido testado en una PS1 y se ha completado sin problemas.


## Instalación ##

- Arrastra y suelta el archivo BIN en "Arrastra el archivo BIN sobre este archivo.bat".
- Se generarán "Iru-v1.0-esp.bin" y "Iru-v1.0-esp.cue" en la misma carpeta del parche.
- ¡Que lo disfrutes!

* Si no usas Windows puedes utiliza el archivo .xdelta3 en la carpeta "patch_data" 
en su archivo BIN para aplicar el parche con programas como xdelta.


################
## PRECAUCIÓN ##
################

- Recomendamos guardar tras el apagón. Hay un evento que ocurre poco después 
de este evento que ocasionalmente bloquea el juego en algunos emuladores. 
Este error está presente en el juego original y es algo aleatorio, así que 
vuelve a intentarlo si te ocurre. La consola no suele dar este error.

## Consejos ##

- Hemos incluido mapas y una guía en inglés sin spoilers que puedes usar para
navegar por el juego si te quedas atascado. Los mapas vienen directamente del 
manual del juego. Recomendamos explorar el juego por tu cuenta, y luego consultar 
el recorrido si te quedas atascado.

- Puedes usar L2/R2 para mirar hacia arriba y hacia abajo. Debes posicionarte
y mirar directamente a los objetos para guardarlos en tu inventario. Puedes probar
con la palanca que hay en el suelo de la primera sala del juego.

- Usa los tablones de anuncios para guardar la partida. Hay eventos que pueden
matarte sin previo aviso, así que asegúrate de guardar para evitar tener que 
repetir los eventos demasiado.

- Hay 2 versiones a través del juego que se basan en una decisión al inicio. 
La guía menciona este punto de bifurcación, pero te animo a que veas lo que ocurre
en tu primera partida y luego probar la otra ruta después. 

- El juego tiene 3 finales: final verdadero, final normal y un final malo.
El final malo es diferente en cada camino, así que hay 4 finales en total.
Consulta la guía si te quedas atascado para encontrarlos.


## Créditos ##

EsperKnight 	- Hacking
SnowyAria 	- Traducción original (JP-ENG)
Mr. Nobody 	- Gráficos y traducción al castellano  
Cargodin	- Edición original de guión
Blueskyrunner	- Edición original de guión
TurnipTheBeat	- Tester


## Contacto ##

¿Has encontrado fallos o has tenido algún problema? Pasa por nuestro discord:
*  https://discord.gg/bewGNtm

También puedes seguirme para apoyar otras traduciones y proyectos:

https://www.youtube.com/channel/UCIKecQiCyFs9fGBBZ2WEPdg
https://mrnobodystudios.blogspot.com/
https://twitter.com/mrnobodystudios
http://www.romhacking.net/community/4650/