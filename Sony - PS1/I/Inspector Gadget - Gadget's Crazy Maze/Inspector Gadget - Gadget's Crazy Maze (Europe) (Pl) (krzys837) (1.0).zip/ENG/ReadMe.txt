Polish translation for Gadget game, PAL SLES 03084.
---
It translate texts, graphics and fonts.
---
Overall, this game is one big crap.
when it comes to gameplay as well
about the technical stuff itself.
Probably made hastily when Gadget was popular.
Anyway... I don't like gadgets cartoon.
---
An interesting fact is that in the game files
there is information from testers saying that
that the entire game have not been tested
... : P
---
The last time I played this game on PS1
was probably in 2006 or 2008.
Interestingly fact is the game is not that easy
in later levels. I remember this game
as enough nice and sweet.
---
Credits:
krzys837 - Translation, graphics
W3trace - Technical stuff
---
krzys837@wp.pl
Krzysztof Jasiński
https://steamcommunity.com/id/krzys8372
---
