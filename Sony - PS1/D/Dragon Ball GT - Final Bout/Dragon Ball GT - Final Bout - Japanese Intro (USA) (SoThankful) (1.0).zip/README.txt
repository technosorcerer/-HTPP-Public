==============================
  Dragon Ball GT - Final Bout (USA) (Japanese Intro Hack) - Version [1.0]
==============================

Author: SoThankful
Date: 2025-07-20

------------------------------
Description:
------------------------------
This patch replaces the North American intro sequence with the Japanese intro from the original Japanese release of the game.

------------------------------
Files Included:
------------------------------
- Japanese Intro.xdelta
- README.txt

------------------------------
Instructions:
------------------------------
1. Obtain a clean, unmodified .bin
2. Use a patching tool such as Delta Patcher (for .xdelta patches)
3. Apply the patch file to the clean .bin.
4. Play the patched .bin on your preferred emulator or hardware.

------------------------------
Notes:
------------------------------
- It’s recommended to make a backup copy of your original .bin before applying this patch, so you can always keep a clean, unmodified version.
- This patch is for personal use only.

Thank you for using this patch!