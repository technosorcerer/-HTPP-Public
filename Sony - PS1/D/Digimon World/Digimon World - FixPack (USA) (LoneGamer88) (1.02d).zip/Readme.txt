 DIGIMON WORLD FIXPACK v1.02d
==============================

 1. Description:
-----------------
Digimon World FixPack is a hack focused on fixing bugs and polishing the game's presentation.
The localized version that was released in PAL and NTSC territories is a mess, and there are probably
still many bugs and visual nuisances left to fix, so the hack is far from perfect. Even so, there is a
substantial improvement in dialogue readability, menu presentation, and of course, the fixing of several
of the most infamous bugs.

 2. Hack base:
---------------
The hack is built upon the patches that Vicen04 has made for the game, which also serve as the foundation
for his own hack, Digimon World Vice (github.com/Vicen04/Dw1DataAndPatches/releases/)

The patches are:
 � Bank Text Fix (improves textbox behavior in the bank)
 � Battle Text Fix (fixes some NPC battles not starting)
 � Battle Time Fix (fixes battles ignoring time-based features)
 � BGM Fix (BGM will now continue playing when changing maps instead of stopping and restarting)
 � Bonus Try Fix (makes the Bonus Try minigame skill-based if you don't have the lucky value)
 � Evolution Target Fix (fixes later evolutions of a Digimon being sometimes ignored)
 � Evolution Item Flag Fix (fixes stat gains being disabled until game restart when using an evolution item)
 � Evolution Item Rejection Fix (prevents Fresh and In-Training Digimon from using evolution items)
 � Forget Techniques Fix (fixes unintended deletion of moves after losing all your lives)
 � Missing Text Fix (fixes missing and corrupted dialogues)
 � Mojyamon Animations Fix (fixes Mojyamon going out of bounds and moving toward the player)
 � OmniDisk Fix (makes the OmniDisk use the limit set for the boost disks)
 � Prosperity Medal Fix (fixes not receiving the Prosperity Medal if your Tamer level is 10)
 � Recycling Shop Text Fix (fixes the text in the recycling shop)
 � Rotation Bug Fix (fixes the game's inability to handle 180-degree rotations)
 � Savedata Text Fix (fixes broken Digimon names in the save file)
 � Sleep Hunger Fix (fixes incorrect math related to sleep and hunger)
 � Softlock Fixes (fixes softlocks that occur under certain conditions)
 � Tankmon Missing Techniques Fix (fixes Tankmon having the wrong tech set)
 � Textbox Choice Fix (fixes wrong data being executed when pressing triangle on text choices)
 � Digitamamon Restaurant Exploit Fix (fixes exploit allowing unlimited eating at restaurant)
 � Giromon Jukebox Fix (fixes crash related to Giromon's Jukebox)
 � MP Consumption Text Fix (fixes text crash when earning the MP consumption bonus in battle)
 � Sleep Regeneration Fix (fixes HP/MP overflow when sleeping in favorable areas or with Rest Pillow)
 � Sukamon Natural Evolution Stats Gains Fix (fixes Sukamon not gaining stats when evolving naturally)
 � Tournament Schedule Fix (fixes tournaments sometimes displaying in the wrong row)
 � Brains Tech Learning Text Fix (fixes the brains training technique learn corrupted text)
 � Quick Battle Text (makes post-battle text instantaneous, like in the Japanese version)
 
 3. Changes:
-------------
The English localization text remains nearly intact (I'm not a native English speaker, so a full retranslation is
beyond my capabilities). Some of the changes were necessary to add more script code due to the game's file size and
LBA checks. The main changes consist of correcting a significant number of spacing and punctuation errors, and
converting all written-out numbers for money and stats into numerical digits. There are also some minor dialogue
changes, and the rest are name changes for items (and descriptions), locations, music tracks, and techniques to
make them display better in text boxes and maintain proper consistency.

I�ve also made some bug fixes, such as making Gekomon actually go to the arena, allowing progress through Drill Tunnel
if you beat Ogremon there before defeating Drimogemon, ensuring certain vending machines work as intended, allowing
some Digimon to appear or participate in tournaments, and fixing various visual glitches on a certain map and in
some menus.

Finally, I've restored the items that allow to evolve into Panjyamon, Gigadramon and MetalEtemon. Given the "bonus"
nature of these Digimon and their "clone" status, I have slightly revamped them for this hack, maintaining
a vanilla style, of course.
 
 4. Installation:
------------------
Use PPF-O-Matic (www.romhacking.net/utilities/356/) to apply the PPF patch to the ISO.
The ISO must be USA version ("Digimon World (USA).bin" file, MD5: 8520edac0f7f1454f8a008ac5e599c1a).

 5. Detailed Changelog:
------------------------
SLUS_010.32
 � Fixed MetalMamemon NPC name
 � Panjyamon is now an Ultimate-level Digimon
 � Updated Noble Mane to be usable only on Champion-level Digimon (SydMontague)
 � Added Ice type to Panjyamon (new techs: Winter Blast, Ice Statue, Aqua Magic)
 � Changed Gigadramon Ice type to Fire type (new techs: Red Inferno, Infinity Burn and Meltdown)
 � Changed MetalEtemon Air type to Mech type (new techs: Delete Program, Reverse Prog and Full Potential)
 � Added Noble Mane, Giga Hand and Metal Banana to merit shop (1000 Merit points each)
 � Added sell prices to Noble Mane, Giga Hand and Metal Banana (5000 Bits each)
 � Restored Underground Lab BGM (Vicen04)
 � Changed partner name position on save slots to display below the player�s name (Vicen04)
 � Corrected blue separator lines in some menus (SydMontague)
 � Fixed "Techset" offset in Tech menu (SydMontague)
 � Fixed position of Power and MP values in Tech menu (Vicen04)
 � Fixed "Spec" being cut off in Tech menu (SydMontague)
 � Fixed tech info box being too large (SydMontague)
 � Fixed status bar length issues (Vicen04)
 � Improved the game font
 � Name/description tweaks: (apart of this, there are several lowercase-to-uppercase and vice versa changes)
	- Tech: Metal Sprinter > Metal Splinter
	- Tech: Spnning Needle > Spinning Needle
	- Tech: Genoside Attack > Genocide Attack
	- Tech: Giga Scissor Claw > Giga Destroyer
	- Tech: Iga School Knife Throw > Ninja Knife Throw
	- Tech: Delete Program > Delete Prog.
	- Tech: Fist of the Beast king > Beast King Fist
	- Tech: Dark Network & Concert Crush > Concert Crush
	- Tech: Nightmare Syndromer > Nightmare Syndrome
	- Tech: Super Thunder Strike > S. Thunder Strike
	- Tech: Mail Strome > Maelstrom (WTF is a Mail Strome)
	- Tech: High Electro Shocker > Hi-Electro Shocker
	- Tech: Tremar > Tremor
	- Item: sm.recovery > HP Floppy
	- Item: med.recovery > Medium HP
	- Item: lrg.recovery > Large HP
	- Item: sup.recovery > Super HP
	- Item: Sup.restore > S. Restore
	- Item: S.Off.disk > S. Off. Dsk
	- Item: S.Def.disk > S. Def. Dsk
	- Item: S.speed.disk > S. Spd Disk
	- Item: Brain Chip > Brains Chip
	- Item: Quick Chip > Speed Chip
	- Item: Digimushrm > Digimshrm
	- Item: Ice mushrm > Ice Mshrm
	- Item: Deluxmushrm > DeluxeMshrm
	- Item: Orange bana > Orng Banana
	- Item: Happymushrm > Lucky Mshrm
	- Item: Leomonstone > StoneTablet
	- Item: Frig Key > Fridge Key
	- Item description: Small Recovery: +500 HP > HP Floppy: +500 HP
	- Item description: Medium Recovery: +1500 HP > Medium HP Floppy: +1500 HP
	- Item description: Large Recovery: +500 HP > Large HP Floppy: +5000 HP
	- Item description: Super Recovery: full HP > Super HP: full HP
	- Item description: Recover +500 Magic Points > MP Floppy: +500 MP
	- Item description: Med. MP: recover + 1500 MP > Medium MP Floppy: +1500 MP
	- Item description: Lrg. MP: recover +5000 MP > Large MP Floppy: +5000 MP
	- Item description: Boost Off. Pwr+Speed +1000 > HP and MP +1000
	- Item description: Fully recovers HP and MP > Recovers +1000 HP and MP
	- Item description: Recover 1000 MP +other uses > Recovers +1000 MP + ???
	- Location: Great Canyon Top Area > Great Canyon Top
	- Location: Great Canyon Bot. Area > Great Canyon Bottom
	- Location: Ancient Dino Region > Anc. Dino Region
	- Location: Ancient Glacial Region > Anc. Glacial Region
	- Location: Ancient Speedy Region > Anc. Speedy Region
	- Music: Ogre Fortress > Ogremon Theme
	- Music: Ogremon 2 > Canyon Night
	- Music: Ogremon 3 > Fortress Empty
	- Music: A.Dino Speed > Anc. Dino Speed
	- Music: A. Dino Speed Night > Anc. Dino Speed Night
	- Music: A. Dino Glacial > Anc. Dino Glacial
	- Music: A. Dino Glacial Night > Anc. Dino Glacial Night
	- Music: Factorial Town Day > Factorial Town
	- Music: Bettle Land Day > Bettle Land
	- Name: King of Sukamon > KingSukamon
	- Name: Master Tyrannomon > MasterTyrannomon
	- Dialog: Woah! > found!

STD_REL.BIN
 � Fixed Gigadramon sprite not appearing on tournaments (Vicen04)

SCN/DG.SCN
 � Geckomon now REALLY goes to the Arena
 � Fixed incorrect triggers when Jijimon talks about Kabuterimon and Elecmon
 � Fixed incorrect trigger when getting second place in the Beetle Cup (the trigger should only activate when winning)
 � Fixed talking with Vegiemon trigger not being unset after recruiting Vegiemon
 � Fixed softlock that occurred when completing Secret Beach Cave before defeating Drimogemon
 � Fixed Mojyamon after exchange animations
 � Fixed Gear Sabanna vending machine (bonus Dual Floppy when inventory is full)
 � Fixed Anc. Dino Region vending machine (Moldy Meat and MP Floppy)
 � Added a missing Penguinmon dialogue in the Monochromon minigame
 � Added Cancel option when selecting food at the restaurant.
 � MegaSeadramon, Phoenixmon and HerculesKabuterimon can now appear in the arena after reaching 100 prosperity
 � Panjyamon can participate in B, A and Animal Tournaments (apart from those allowed in vanilla)
 � Gigadramon can participate in B, A, Dino and Wing Tournaments (apart from those allowed in vanilla)
 � MetalEtemon can participate in B, A, Animal and Humanoid Tournaments (apart from those allowed in vanilla, except Mech)
 � Mojyamon can participate in Humanoid Tournaments (appears as NPC, so, consistency's sake...)
 � Phoenixmon can appear in Thunder Tournaments (partner version can participate, so, again, consistency's sake...)
 � Changed all writen money and stats values to digits
 � Corrected several instances of incorrect spacing and punctuation
 � Minor corrections to some dialogues.

SCN/MAPHEAD.SCN
 � Corrected some instances of incorrect spacing
 � Made some text tweaks to accommodate new code
 � Added Gekomon trigger
 � Restored Underground Lab BGM (Vicen04)

CHDAT/MMD2/MTET.MMD
 � Restored MetalEtemon staggered animation

CHDAT/MMD2/PANJ.MMD
 � Added 3 additional tech slots to Panjyamon

ETCDAT/ETCTIM.BIN (FI_INFO.TIM and SYSTEM_W.TIM)
 � Fixed inverted colors in action menu text 
 � Fixed status bar palette issues (SydMontague)
 � Fixed "HAPPINESS" position

MAP/MAP08/MAYO01_2.MAP and MAYO01_2.TFS
 � Fixed palette issues on the MAYO01_2 map (jype)

 6. Acknowledgements:
----------------------
SydMontague: for all the reverse engineering work and documentation on the game.
Vicen04: for his Vice hack, which has revived my interest in the game after so many years.
jype: for his decompilation tool for the game scripts; it was basically what motivated me to create this hack.
To the three of them, thanks for the help.
Without the work of these people, it would have been IMPOSSIBLE for me to do this hack.
