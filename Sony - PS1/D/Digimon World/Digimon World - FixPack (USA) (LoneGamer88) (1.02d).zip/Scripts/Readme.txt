
FixPack 1.02c scripts.

Ready for compile with dwbasic by jype (gitlab.com/jype/dwbasic).
Remember to truncate (DG.SCN to 804864 bytes, MAPHEAD.SCN to 24686 bytes).