
 Brace yourself for another long readme...
 
 ------------------------------------------
 Digimon World Maeson - Public Release 1.04
 ------------------------------------------
 
 S000 - Installation and Optional Patches
 S001 - Introduction
 S002 - Basic Elements
 S003 - Food, Item and Fishing Changes
 S004 - Mechanical Changes
 S005 - Evolution Changes 
 S006 - Tech Changes
 S007 - Other Changes
 S008 - Glitches Fixed
 S009 - Tips 
 S010 - Trivia

 Changelog 1.04b:
 
 I fixed one very strange regression made on 1.04, which I cannot explain 
 to myself. 
 
 For some reason Palmon's evolutions were rolled back to a previous version
 where it couldn't evolve into Greymon. Thanks to Gretel for informing me.
 
 ---
 
 Based on feedback, I made a very small adjustment on a couple of Items 
 when used as bait, and fixed one issue with baits.
 
 Before, there was no fish you could use to catch Black Trouts. This was 
 an intentional design choice to avoid getting too many of them, as they 
 provide Stat gains when eaten, I was worried they could be abused.
 
 It went from 10 HP/SP and 1 to each other stat, to 100 and 10 respectively. 
 
 But I received a message commenting they're much harder to get now. Thinking
 again, the real life time needed to fish a bunch of Black Trouts to be able 
 to gain significant advantage from them somewhat counters the ingame advantage, 
 and after all, it's not as if you weren't able to max out in Stats in several
 other ways. 
 
 In any case, the Digitrout, Black trout and Digicatfish had their bait traits 
 changed. This also opens the possibility for "chain fishing", starting with 
 a Digianchovy and being able to go up to the fabled DigiSeaBass.
 
 Like with the Black Trout it's something I was a bit against as it seemed too 
 easy, but again the real life time invested in this stuff offsets the advantages
 I feel, not to mention the chances of failing and having your bait taken away.
 
 I did also change the Sirloin's bait data, because it would give much easier 
 access to DigiSeaBass with these changes, and you get free infinite amounts of 
 them. 
 
 Besides this, I also fixed an oversight in the bait data that would cause a few 
 Items have the data from others. Now every bait should work as it's written in 
 this readme. 
 
 Nothing else has been changed. I hope these changes don't make things easy to abuse.


 Added to 1.04 on 03/11/23:
 
 I've corrected the Original Lifespan patch, as it had some missing data. But Remember 
 that Lifespan is set the moment you either start a game, or your Digimon revives.
 
 So, if you were to patch your game after having a savefile created, it won't make 
 any difference until it reborns.
 
 Second, I also saw someone asking for giving the option to have the original amount 
 of Bits given after battle. I can see where the sentiment comes from, even if I think 
 it's too rough, but hey, I added another extra patch that restores the original quantities.
 

 Changelog 1.03: 
 
 Vice04 fixed a remaining text-related glitch that affected the Monochromon 
 Minigame. This is the same glitch that could happen if you pressed Triangle
 whenever given a choice to "back" or exit from it. 
 
 The other change is that I lowered the amount necessary to pass the Minigame,
 from 3072 Bits down to 2048, making it far less reliant of luck. 
 
 You can restore the original amount of you want, but... Why would you?
 
 I apologize for having all these three updates so close to eachother, 
 things just popped very close to eachother.

 Changelog 1.02:
 
 Fixed the evolutive Items Smelly Ring, Ugly Mirror and Machine Claw.
 
 Somehow one of the changes in the code for these Items reverted 
 back to the oriignal values during the last parts of the making 
 of the hack, I do not understand what or how I managed to do that.
 
 Anyway, they are working as intended now...

 Changelog 1.01:

 While we tested on several ways like original hardware, PS2, Popstarter,
 EPSXE, PCSX Rearmed, Duckstation and I even got it working perfectly 
 fine on both the Wii and 3DS through homebrew, apparently the emulator 
 Beetle PSX has issues with this hack. 
 
 I've never used it and on a quick check the performance seems to be 
 worse than PCSX Rearmed or Duckstation on my end, but regardless of 
 that I remade the patches, fixing the ECC and ECD sectors so it 
 plays on all emulators. 
 
 The content of the hack is not changed in any way.
 
 Fortunately, CD sectors are not like ROM Checksums, they only check a 
 small part of the entire image, so combining patches that had these 
 sectors fixed is fine. After Breath of Fire II I grew a serious dislike 
 for these things!
 
 In any case, if you have doubts any of your PS1 images might have bad 
 sectors, you can try LuHa's ECCRegen tool:
 
 https://www.romhacking.net/utilities/1550/
 
 It's a solid tool!
 
    -------------------
    S000 - Installation 
    -------------------
 
 This is pretty simple. Just grab PPF-o-Matic, the correct Bin/Cue of the game, 
 and my patches. This hack has been made for a Bin file with this hash data:
 
 CRC32: E6FDD00E
 SHA1: 5611645da66183e30d11fb6c11a2784ff47e1fdb

 Open PP-O-Matic, choose the Bin file, and my Main Patch file. 
 Apply it, and you're done... Unless you want to add some Alternate Patches!

 -----------------
 Optional Patches:
 -----------------
 
 I included several optional patches you can apply after the main one. They alter a number 
 of things that you might want to revert, or to have to create a different experience.
 
 1: Starter Patches: 

 They change the initial Digimon you can start the game with, so it's not always the same 
 Agumon and Gabumon choices that we always had.

 Have in mind that you might have a bit of a harder time early on depending on which starter 
 you choose, depending on the types of Digimon and the Techs they can learn. Agumon and Biyomon 
 have long ranged Techs to start with, but they take more damage from Water Techs, so the 
 Modokibetamon might prove to be dangerous. On the other hand, Digimon such as Gabumon and 
 Patamon might have a harder time to learn a Tech that's better than Sonic Blow.
 
 Yet this opens a lot of new possibilities for early game variety. Who wouldn't want to start 
 with Penguinmon and conquer File Island in the name of the Curling Empire? What about starting 
 with a Betamon or Kunemon and explore the Graylord's Mansion early?
 
 Anyway, you have Agumon and Gabumon with the main patch, and other 4 optional ones that alter 
 both of the Starters. "Digi 1" means the Digimon that substitutes Agumon, and "Digi 2" the
 that does the same with Gabumon.
 
 File name:                     Digi 1	   Digi 2
 Main Patch                     Agumon     Gabumon
 Extra Patch - Beta Biyo.pff    Betamon    Biyomon 
 Extra Patch - Pal Pata.ppf     Palmon     Patamon 
 Extra Patch - Penguin Elec.ppf Penguinmon Elecmon 
 Extra Patch - Kune Penguin.ppf Kunemon   Penguinmon
 
 Starting Techs:
 Agumon  & Biyomon: Spit Fire 
 Gabumon & Patamon: Sonic Jab 
 Betamon & Elecmon: Static Elec.
 Penguinmon, Palmon & Kunemon: Poison Claw.
 
 * Biyomon and Penguinmon start with other moves in the original 
   game, being Electric Cloud and Winter Blast in particular.
   They are too strong to start with and offer unfair advantage, 
   so I gave them basic moves shared with other starting Techs.

 You can apply only one! It's not going to corrupt your BIN file, but you're not doing 
 anything but replacing the previous optional patch. 

 2: Remove Tech Bonus Requirement:
 
 In the original game, after your Digimon knows a certain amount of Techs, the Bonus point for 
 Evolution will always be given towards EVERY possible evolution your current Digimon can have,
 meaning that you lose some control over your choices as you can no longer use any other Bonus 
 requirement. 
 
 This patch makes it so the Tech Bonus is removed, and you always can use Happiness, Discipline 
 or Battles. 
 
 3: Restore Greymon's Strength:
 
 In the original game, the Greymon that comes to File City is very infamous and very much despised
 for two main reasons, those being it appears without any warning to newbie players, and that it is 
 absurdly strong for appearing so early into the game if you talk to Jijimon once prosperity is 
 at 15 or higher.

 It has been a constant source of frustration and jokes, as it was very common to appear when you're 
 not ready at all, basically making you lose a Life with no way to avoid it unless you happened to
 have an Autopilot ready, and even then that just saved you for that one time...

 In the main hack, Greymon has been weakened out to a more reasonable level, but if you want him to 
 become as srong as he was, just apply this patch.
 
 4: Vice04's Curling Extravaganza of Fun
 
 ...Well, no, he didn't really call it that. This patch makes it so every time you play Curling, a random
 Digimon will be your opponent, instead of always Penguinmon. All of it was made by Vice04, and because 
 he needed to try and repurpose animations, it took quite a lot of tedious trial and error but the result 
 is pretty fun!
 
 It is a rather cute addition I think, but I leave it optional as... Well, I have a soft spot for that 
 trolling penguin, what I can say. I love it, I hate it, and I love to hate it.
 
 Just have in mind that if you patch this one on your ISO, when you recruit Penguinmon chances are 
 you will play against any other Digimon. Everything will work normally, but it won't make any 
 sense story-wise. After that everything is fine.


    -------------------
    S001 - Introduction
    -------------------
			
 ---------------
 About this game
 ---------------
 
 Chances are that, when thinking about childhood memories most people would go straight to their Marios, Zeldas, 
 Sonics or Metal Gears to name a few... And while I hold my own for such sagas, the memories about this particular 
 game are just as strong, if not more. And I mean it in plenty of both "good" and "bad" ways.
 
 This thing came to my life with no prior knowledge of it, and I never played anything like it back then. I was always 
 interested in games where you had, raised or controlled monsters, and this had that in spades, so it captured my 
 imagination and interest like few things did at the time.
 
 ...But what truly made me stay with this game for as long as I did was the absolute, sheer feeling of uncertainty. 
 As a child, it was a constant source of frustration and questions whenever something did not go as I planned or, 
 after thinking I've understood how something worked, finding out I was wrong and I needed to go back and keep 
 making sense of things after the game breaking any attempt of logic to understand it that I made.
 
 Well, I have to also admit that the scenario design was another big hook. The way the world of the game is designed 
 was really interesting. Having electronic parts integrated in natural places, or seeing how the creatures of this 
 world somewhat used human created objects that somehow appeared on it, like all the sound equipment on Gekko Swamp
 or all the trash repurposed as a fortress in Great Canyon and such, gave the game a far more interesting world to 
 observe. All the little details here and there were also quite captivating. The game even references creatures 
 that we would not know they exist for a long time, like SaberLeomon.
 
 And I was not alone, this game became one of the biggest conversational subjects for quite some time with friends, 
 we would all be stumped at pretty much every aspect of it, constantly asking ourselves about the strange and downright 
 esoteric ways this strange world worked, often times leaving me with more questions than answers.
 
 It may sound weird when you put it like this that I hold so many memories, regardless of how positive or not 
 they may sound. It captured my fascination so darn tightly, and it's the truth. 
 
 This is one of the most absurd games I played as a child as far as trying to make sense of things. So many things going
 on at the same time, so many mechanics that are never explained, so many outcomes for actions that you don't understand, 
 so many Items that you can't be sure of what effect they have, so many questions about what you're doing wrong when your 
 Digimon evolves into something completely different every time, even if you do things similarly... And it's so open when 
 compared to most games from that time that you never ever knew if you were on an appropiate area for your power level 
 until too late.
 
 Trying to make sense of all these things while exploring a pretty wacky world with such flawed but sometimes funny 
 translation, was and probably still is one of my most cherished experiences. It's mostly the absolute sense of mystery, 
 both intentional and accidental, that made it so interesting and still worth looking into, specially when I compare it 
 to the modern ways of designing video games (and marketing them, not to mention the formless blob trying to spoil any
 possible detail that is "content media"), where it seems that with each passing day there has to be less and less space 
 for the player to learn or discover things by themselves and actually create a connection with the thing it's interacting 
 with. Although I will concede that Digimon World takes that into such lengths that can get overbearing sometimes. 
 
 Thing is, from the looks of it, quite a few people felt the same way. Looking for information about this game was one 
 of the first things I remember when I got to try that newfangled thing called the Internet, and to my surprise, a lot 
 more people were talking about it, in many different corners that mostly do not exist anymore. From mere conversations 
 to rumours so absurd that could rival the already crazy enough logic of the game itself, but most important of all, 
 people trying to research the game by tinkering with it. And with the pass of time, old ideas and rumours were disipated 
 to leave space to actual data on how this game worked, finally finding what exactly wanted from you.
 
 Checking around again, it seems like this game left a mark in many people out there. And adding to that, the more I kept 
 searching, the more apparent to me became how much more important this particular game was for the entire franchise 
 going forward. 
 
 Finding these things made me wonder if I could somehow improve or tweak it, like I've done with other games for 
 my own enjoyment. Which brings me...

 ---------------
 About this Hack
 ---------------
 
 After playing it many, many times, and understanding better how a lot of the mechanics and such work, plus finding
 a deeper respect to it, I started wanting to have a version of the game that tried to polish or improve several of 
 elements because as much as I love it, to say it's flawed is... an understatement. 
 A huge one.
 
 So back in 2021, after finishing my work on FF1 Dawn of Souls I started to mess around with other games, this being 
 one of them. While I spent most of 2022 reworking three of my other hacks, mostly from scratch to make the best 
 version I could out of them, I kept checking and learning what could be done with Digimon World. I left a preliminar 
 version ready at some point before finishing the work on those other hacks, but since I released them and went back 
 to this, the entire thing has basically changed. So many more things have been tweaked and improved that it's crazy.
 
 And I must say that a number of the changes that were included in this hack couldn't have been made without 
 the help of Vice04, who did rework several pieces of code to improve, or downright fix many of the weird glitches 
 this game has. I am very thankful for his help and his patience. Might the universe bless him with as many copies 
 of Mole Mania as he deserves.
 
 But besides that, it wouldn't have been nearly as easy to work with without the research of people like Romsstar,
 SydMontague and Ginoshie that had researched a lot, and I mean a lot of information about the game thoughout the years, 
 or the youtube channel Geta92, which has an incredible collection of videos showing many quirks of the game that I 
 learnt from.
 
 In fact, after the release of this hack, I got the chance to talk with Romsstar and find out neat tidbits of info 
 about researching the game and other things, really interesting and very wild to talk to someone with so much 
 weight on the overall presence of this game on the net. 
 
 Now, here's a list of some of the changes made to the game:
 
 · One of the biggest points is to smooth out Evolution.
 
   This was done by reworking the requirements in order to simplify and remove as much overlap as possible, 
   changing the evolutionay lines so every Rookie and Champion had an equal amount of options to evolve into, 
   instead of some having more than others, adding three Ultimate Digimon that were relegated to only be 
   evolved through Items.
   
   Stat gains upon evolution were also tweaked to be in line with the current stat requirements too. 


 · Large tweaks to Techs. In the original game it's absolutely wild and there's no resemblance of logic in how 
   powerful or weak, how much little MP costs, the chances to cause Status and such between Techs, beyond 
   that the developers really wanted to make Mech Techs overpowered in comparison to most others.

   Of course, while I cannot change every aspect of them (like animation speed or delay between uses) I have 
   tried to bring some order between the Techs of different types, so they all more or less are in the same 
   ballpark, and the player wants to use something other than the three or four broken Techs that always used.

   I made learning Techs much easier too, both by battling and by training. 

   Finisher Techs were also tweaked as there was some very unfair favoritism, with some Digimon of the same Level 
   having noticeably weaker Techs than others.    
   
   
 · Expanded Lifespan. The original game's 360 hours have been expanded to 480, providing 5 days more for each 
   reencarnation of your Digimon for a total of 20, up to 24 if it evolves to Ultimate. there's a patch to 
   revert it to 360 hours if the player so desires. This gives you a bit more time to play around the Arena, 
   explore more and overall being able to more things with less worry about training taking too much time. 
   
   
 · Modifying the effects of many Items, mostly related to food, so they're more distinct and useful in specific 
   situations. Making fish more useful, providing options to increase or lower the Weight in larger numbers, 
   Digi-Evolution Items providing Stat and Lifespan increases and making two dummy Items to have options to 
   evolve into Numemon and Sukamon, etc. 
   
   
 · Changes to enemy Digimon. This goes from altering their stats here and there, sometimes to strengthen a particular 
   enemy, others to weaken something that I believe might be too strong for the moment you fight it. Other changes 
   are related to the Items they drop, now there's more variety and enemies leave items a lot more often. I also 
   raised the amount of Bits given by most Digimon, as in the original game, specially early on, Bits are way too 
   scarce, limiting your purchasing capabilities which in turn affect your ability to explore the island and deal 
   with the wild Digimon that tend to put a serious dent on your partner Digimon after repeated battles.

   Boss Digimon will always drop an Item if the player was capable of grabbing it after the battle. In the original 
   it was a random chance which wasn't all that great. Some bosses drop different Items, too.

   
 · Changes to Items found while exploring, reducing the number of boring Digishrooms out there and putting more 
   interesting ones to find, making those items that before were so rare in casual playing be of actual use.
   
   Also changed some of the prices for Items in normal shops, and also the Merit prices in ShogunGekkomon's Point 
   Shop. It was ridiculously expensive, what it gave to you originally wasn't worth the time, and it felt kinda 
   worthless in general. With lower prices, Evolutionary Items being much more useful, and also having a new way 
   to earn Merit Points (by doing something that's also benefitial for you) it should be a bit more useful now. 

   
 · Changes to a number of other mechanics or systems, such as the Type matchups, fishing, the Restaurant, and the 
   eating habits of the Digimon, among others. Cases such as Gabumon requiring insane amounts of food, or certain 
   Digimon losing alarming amounts of Energy per hour were ironed out, and all species have been standarized 
   depending their rank and size. 
   
 · A large amount of glitches of different levels of severity have been fixed, most by Vice04 by un-messing the 
   code and rewriting it, although many others were mistakes that could either be annoying or outright freeze the
   game. For details on each, you can check its own section. 
   
   
   Alongside this, a very large number of text corrections to improve different types of issues, from rewording 
   very poorly written parts that were important to progress (like "Return to the position where you get the 
   points from the dumb one" on Graylord's Mansion being one of the worst ways to convey what it wanted to convey)
   explanations of mechanics that were completely wrong, many typos, poorly formatted text and specially choices 
   had a lot of issues, like the text for one choice running into the espace for the second choice, making it hard 
   to find sense in what you're supposed to say, and things like that. 
   
   Oh, and Item descriptions and such, some were very bad. 

   Mind you: THIS IS NOT A RETRANSLATION. I still want to leave the weird feeling of the script, I just wanted 
   to clean up what I could or fix what was specially wrong. Of course, what I was able to do anyway, as the 
   game is very fragile and can break very easily, and in a weird way, the way the script is makes some sense 
   in the game's world as its inhabitants lost their ability to speak or understand language in varying levels.
   
   
 · Added optional patches to change the Starter Digimon when starting a New Game. Each patch will give you two 
   different Rookies, with their basic move and balanced stats. This changes the early game experience a lot, 
   from the early days with your Rookie, to different evolutionary routes you can take, and places you can visit.
   Ever wanted to check Graylord's Mansion right out of the gate?
   
   There's a few other optional patches too. 


 And there are other things here and there, but that should summarize it well enough. 
 
 -----------------
 About this Readme
 -----------------
 
 Yes, a long-lived tradition of mine. I want the player to be informed of changes I made and 
 mechanics that would not usually be explained in-game or around the net. This is doubly so 
 in the case of Digimon World, as there's still a large amount of disinformation and outright 
 fake rumours to this day, so I wanted to add as much as I could here. 
 
 Sections are going to be quite large, and will have lots of text to explain things with enough 
 detail. If you are only interested in basic information in list forms, you have an extra Readme 
 that only contains such things. 

 This readme also contains specific information about several mechanics that have not been changed 
 that can help the player too. It'd be weird to explain to you how Types work, while not telling you 
 what Stats do, for example. 


	---------------------
	S002 - Basic Elements
	---------------------
	
 Here I will explain basic mechanics such as Stats, Lifespan and such. 
 
 Most of this information is the same as in the original game, but I will point out which is not
 by adding "*" on the title of each subsection. Here we go: 
 
 -----------------------
 Stats and their meaning
 -----------------------
 
 Offense: It raises the damage you do with your Techs, but it's not merely adding and that's that, 
          there's some rules, and the Defense of the target plays a big, big role. 
            
          Each point of Offense will serve to multiply the damage of Techs used. The calculations 
          are simple:
          
          Every 5 Offense over your enemy's Defense, the damage of that Tech raises by 1%. So, 
          for every 50 Offense over your opponent's Defense, you'll do 10% more damage. 
          
          This goes up to a difference of 500. If you had, let's say 600 Offense, and the enemy 
          had 100 Defense, that would be extra 100% more damage, basically doubling your damage. 
          
          If the difference is higher than 500, it will ignore it and stay as 500.
          
          This means that Offense doesn't mean much after you reach a certain milestone, as very 
          few enemy Digimon have very high Defense. It will be more useful on the Arena, though!
          
          Be aware that if you have less Offense than your enemy has Defense, damage will
          be substracted instead!
          
          If you had 200 Offense, and the enemy had 250 Defense, you will only do 90% of the 
          normal damage!
		  

 Defense: As you can imagine, Defense is what's used to reduce damage. 
 
          If the Defense of the defender matches the Offense of the attacker, no extra damage will 
          be received. 
		  
          If the Defense of the defender surpasses the Offense of the attacker, damage received will 
          be lowered. This works at the same rate as for causing damage. Every 5 points of Defense 
          over Offense, it means a 
		  1% of reduction. 
		  
		  The maximum difference also caps at 500, and after that, any extra 
		  Defense no longer matters.
		  
          While you can get away with no need for super high Offense in most 
		  situations, having a high Defense is very useful, as wild Digimon 
		  tend to pack a lot of Offense. 
		  
		  
 Speed:   Speed serves a variety of purposses. 
 
          The most important one is to cut down the length of pauses between executing Techs. 
          Raising Speed will lower these delays for all Techs, and while it's more noticeable 
          with slower Techs, as faster ones reach their "peak speed" earlier, it's useful 
          for all of them.
          
          Sonic Jab, for example, is very awkward and slow at low Speeds (like when starting out)
          but if you train for a while you'll see performing much better and become a rather neat 
          interrupting attack that makes foes flinch. 		  
          
          But be aware that once you reach 300 Speed, you won't get any more improvements on this 
          regard. Which is for the better, you don't need to train too much to get the best results.
          
          Besides that higher Speeds make charging your Finisher Tech faster. Max Speed of 999 would
          cut the waiting by around 33%.
          
          Speed is also used for Blocking attacks and for successfuly hitting with their own Techs, 
          but it's biased much more towards the blocking side than to aid hitting.
          
          So, it is quite important overall. 
		  
 Brains:  Brains does a lot of things too. 
 
          As this stat is raised, you will be able to give new Commands to your Digimon, which are 
          the most obvious and easy to see changes. 
          
          It starts with the basic command. The Digimon will act without much thought or focus.
          
          At 100 Brains, your Digimon learns Attack. With this tactic, your Digimon will focus on  
          using the Tech with the highest power, regardless of MP consumption. It will also stay  
          close to the opponent, and not move unless it's to follow it. 
          
          At 200 Brains, your Digimon learns Moderate. In this tactic, your Digimon will use the Tech 
          that uses the least MP (so, usually the least powerful one) and will walk around the battlefield, 
          making it a bit harder to be hit. The time between attacks is longer than on other tactics. 
          
          At 300 Brains, your Digimon learns both Run Away and Target Change.
          
          Run Away will make your Digimon constantly run around the field, never attacking. Can be useful 
          to make it move away from area-of-effect Techs, or to make your foe waste MP by avoiding attacks. 
          
          Target Change will only be useful if you're fighting two or more foes. 
          It will simply target the other enemy. 
          
          At 400 Brains, it will learn Defend. Your Digimon stops moving and attacking, and its blocking 
          capabilities are increased. Can be quite useful when waiting for your opponent to attack, so it 
          does not interrupt your own Techs, or more importantly, your own Finisher attack. 
          
          At 500 Brains, you will be able to directly order your Digimon to use the Techs you have assigned 
          to it. Because of this, Max Power and Moderate disappear, which is not a big loss as Max Power is 
          the same as using your strongest Tech, and Moderante your least powerful one without the longer 
          delay between attacks. 
          
          At 700, 800, 900 and 999 Brains your Digimon will get a reduction on its MP Consumption when using 
          Techs, 5% each time for a total of 20% at 999. This is quite big, but it also takes a looong time 
          training so...
          
          Beyond this, Brains also affects other things! 
          
          149 or less Brains: 
          Your Digimon will only target enemies near of itself. 
          
          Between 150 and 299 Brains: 
          The limit above is removed. Whenever your Digimon knocks down a foe 
          on a battle with several enemies, it will change targets. If there's 
          3 foes, it will target the one that would get the most damage based 
          on type advantages.
          
          300 or more Brains:
          Prorizes enemies with Status Errors, if no enemy has a Status, then 
          will priorize the enemy that would get the most damage based on type 
          advantages. 
          
          And besides that, once your Digimon has 200 or more Brains, the chances 
          to use Techs increase (so, it uses them more often) with more bias towards 
          the assigned Techs with highest power. 
          
          Brains also affects the amount of Power Up Techs it can use per battle.
          299 or less Brains: Wisdom / 100 + 1 time. 
          Between 300~599 Brains: 4 Times.
          600 or more Brains: 5 Times. 
          
          Finally, Brains also affects Digimon stopping in midbattle to stare nowhere.
          This is only for enemies, and will affect those with less than 300 Brains. 
          Your Digimon works on Discipline instead.

 HP and MP: Pretty obvious what they do, but oh well.
 
          HP or Hit Points are Digimons' Life. It gets reduced when they receive attacks, 
          and if it reaches 0, it gets knocked down. if it's an enemy, it ends the battle.
          
          But if your Digimon gets to 0 HP, it enters into Coma Status. The game will count 
          down from 5, giving you time to revive it with a Restore or Super Restore, but 
          if you do not manage to do so, it will lose a Life, and you will also lose some 
          Items. 
          
          Having a decent amount of HP is pretty important, but with the use of healing 
          Items you can get away with not training it heavily. 
          
          MP or Magic Points (no really, Magic is the right word, funny on this digital 
          world) are exactly for what you imagine, being able to execute Techs.
          
          Every Tech requires an specific amount of MP, and without MP you can't do
          anything but stay there, doing nothing until you can do your Finisher.
          
          If you ask me, MP is more important than HP. It goes down faster than HP, 
          and without it, it does not matter how much HP you have because you can't 
          defend yourself.
          
          Of course you can restore it with Items, but having a good amount of MP 
          will slow down the consumption of restorative Items, because if you think 
          you can get by merely spamming MP Floppies you'll find out how utterly boring 
          is to do that...

 Happiness and Discipline:
          
		  These are not really battle-related Stats (well, a tiny bit for Discipline I guess) 
		  but they're quite important too.
		  
		  Happiness is... Pretty self-explanatory. The higher it is, the happier your 
		  partner is. Happiness is sometimes used as an Evolution Bonus Requirement.
		  
          Happiness is also very important for Lifespan. If your Digimon hass less than 81 Hapiness, 
		  every 4 hours passed you will lose between 1 to 5 hours more, depending how much lower it is.
          Above 81, you won't have to worry about it at all. If Happiness is very low, your Digimon 
		  can lose a lot of lifespan, so pay attention.
		  
		  Happiness is gained by feeding it when hungry, going to the bathroom, being in a place it 
		  likes, or giving it Items that specifically raise Happiness. It is very easy to have it 
		  at maximum, so you shouldn't worry unless you're terrible at the game. 
		  
		  Many things do lower Happiness, like being tired, training (but it lowers it very slowly, 
		  it is not a concern and usually by feeding it when hungry it makes it moot) not feeding 
		  it, not getting to the bathroom in time, scolding it when it's not reasonable, etc...
          
		  Discipline is a bit different. It is also sometimes an Evolution Bonus Requirement.
		  
          Discipline affects how much time you have to go to the bathroom once your Digimon needs 
		  to go, and also affects your Digimon stopping battle to look up at the sky and do nothing. 
		  
		  With high enough Discipline, you can even get away with having to battle while trying to go
		  to the bathroom, and no one wants to have their Digimon looking at nothing and getting hit. 
		  
		  One good way to raise it to acceptable Levels if its too low is to try to give healing Items 
		  to your Digimon. It will often refuse them, and if you scold it right away after refusing, 
		  it will be seen as a reasonable scolding, and your Digimon will get both Happiness and 
		  Discipline points.
		  
		  Once Discipline is high enough, this trick stops working as it will accept your Items with 
		  no attempt of turning them down, unless we're talking an Evolution Item or something like 
		  that that simply won't work unless in the right conditions. This is not a reasonable way 
		  to scold your Digimon.
 

 --------
 Lifespan **
 --------

 Lifespan has been extended. In the original game, every life of your Digimon has a 360 Hour limit.
 Meaning, 15 days. It can be extended with 4 days more if it evolves to Ultimate, and you can add 
 to that by feeding Chain Melons, or DigiSeaBass.
 
 In this hack, each life of your Digimon is now 480 Hours, so 20 days, up to 24 if evolving into 
 Ultimate. The Champion period lasts two days more, meaning that getting to Ultimate takes 12 days 
 out of your Digimon's Life, and then spends as Ultimate the other 12 days. 
 
 The rate at which Baby and In-Training Digimon evolve has also been tweaked a bit: 
 
 Evolutionary step:          Time    Total Lifespan 
 Baby Digimon to In-Training   6H           6 Hours 
 In-Training  to Rookie       18H           1 Year
 Rookie       to Champion     72H           4 Years 
 Champion     to Ultimate    196H          12 Years
 Ultimate     to rebirth     284H + 96H    24 Years 
 
 Of course, this chart takes into account that your Digimon has over 81 Happiness all the time. 
 Very easy to do on your second life forward by giving your Baby Digimon a Blue Apple, you can 
 read more about Happiness on the Evolution section.
 
 You can revert this to the original Lifespan if you want with an optional patch, which I would 
 only consider to do if you wanted to fill up the Digimon Chart, but that'd be after having completed 
 pretty much everything else... Nonetheless, there's the option. 
 
 
 -------------
 Type Matchups **
 -------------
 
 This was not known by pretty much anyone back then, even if we could feel something was going 
 on, but turns out that this game has actually coded in a way for each type to react to attacks
 from every Type.
 
 The original game had a pretty unfair distribution of resistances and weaknesses, here it is:
 
		   | Fire |Grapple|  Air | Earth |  Ice | Mech | Filth |
	-------|------|-------|------|-------|------|------|-------|
	Fire   |  10  |  15   |   5  |  20   |  20  |  15  |  20   |
	Combat |  10  |  10   |   2  |  15   |  10  |  10  |   5   |
	Air    |  15  |  15   |  15  |  10   |  15  |  15  |   5   |
	Nature |   5  |  15   |  20  |  10   |  10  |   5  |  15   |
	Ice    |  20  |  15   |   5  |  15   |  10  |  15  |  20   |
	Mech   |  10  |  10   |   5  |  10   |  10  |  10  |   5   |
	Filth  |   5  |  15   |   5  |   2   |  10  |  20  |   2   |
    -----------------------------------------------------------o
	
 Now, it might look weird at first, but here's the thing: 
 
 10 is "Normal damage". Not resistant, nor weak to it. 
 20 and 15 are weaknesses, one bigger than the other. 
  2 and  5 are resistances, one lower than the other. 

 Knowing that, as you can see certain types were made to be outright 
 worse than others; Grapple Digimon received extra damage from pretty much 
 everything, Air Digimon resisted most types, and Fire attacks were effective 
 against most.
 
 Pretty strange balance, in all fairness. So I went ahead and tweaked it.

	A    D| Fire  |Grapple| Air   | Earth | Ice   | Mech  | Filth | None |
	------|-------|-------|-------|-------|-------|-------|-------|------|
	Fire  |   5   |  10   |  15   |  20   |   5   |  10   | 20    |  10  |
	Battl |  10   |   5   |  10   |   5   |  15   |  20   | 5     |  10  |
	Air   |  15   |  20   |   5   |  10   |  10   |   5   | 5     |  10  |
	Earth |   5   |  15   |  20   |   5   |  10   |  10   | 15    |  10  |
	Ice   |  20   |  10   |   5   |  10   |   5   |  15   | 20    |  10  |
	Mech  |  10   |   5   |  10   |  15   |  20   |   5   | 5     |  10  |
	Filth |  10   |  10   |  10   |  10   |  10   |  20   | 5     |  10  |
    ---------------------------------------------------------------------o

 I made the main 6 types to be in line with Fire, which seems pretty fair, with two weaknesses, 
 one minor and one major, two resistances and also receiving normal damage from everything else.
  
 Filth type has two major and one minor weakness, but to compensate it is resistant to the other 
 four types. Not that it helps that much as Filth Digimon are the least common to battle, and in 
 fact there's only two "generic" enemies of that type, Geremon and PlatinumSukamon.
 
 Now, this mechanic gets a bit complicated as all Digimon have two or three types, and you must 
 combine them to see how each species deals with types...
 
 The calculation it makes is to sum all three Types of the defender Digimon, and then divide them 
 by 30, the resulting number then is used to multiply the damage.
 
 This is why I added another group, "None" above. If a Digimon has only two Types, 
 its third one is considered None, which is neutral to everything. 
 
 Examples: 
 
 Fire Attack VS Kokatorimon (Air/Grapple)
               
			   10 Grapple + 15 from Air + 10 from None = 35
			   35 divided by 30 = 1.16
			   Thus, Kokatorimon takes 16% more damage from Fire Techs.
			   
 Ice Attack VS MetalGreymon (Mech/Grapple/Fire)
			   
			   15 from Mech + 10 from Grapple + 20 from Fire = 45
			   45 divided by 30 = 1.5
			   Thus, MetalGreymon takes 50% more damage from Ice Techs.

 Filth Attack VS Piximon (Air/Earth)
 
               10 from Air + 10 from Earth + 10 from None = 30 
			   30 divided by 30 = 1
			   Thus, Piximon takes the normal amount of damage from Filth Techs.
			   
 Ice Attack VS Panjyamon (Grapple/Ice/Air) 
 
               10 from Grapple + 5 from Ice + 5 from Air = 20
			   20 divided by 30 = 0.66
			   Thus, Panjyamon takes 33% less damage from Ice Techs. 
			  
 Types are lot more balanced now, and having Grapple not being a curse, which is 
 by far the most repeated Type in the game, is also kinda nice too.

 This is one of those hidden mechanics that really, really affected the damage, 
 and made you wonder some many times you or the enemy did so little damage, or 
 so disgustinly much in other situations.  
 
 Use it to your advantage, even if in this game you can only have one Digimon at 
 the same time!
 

 -------------------------------------------------------------
 Learning Techs and Brain Training: Dr. Kawashima not included  ** 
 -------------------------------------------------------------
 
 In the original game, learning new Techs could be brutally boring. 
 
 The chances for doing so were rather low in general even for Techs that were not strong, but 
 the game was designed to be a lot more stingy and simply unfair based on the order of the 
 Types your Digimon had. 
 
 Let's use Green Trap, for example. 
 
 If your Digimon had Nature/Earth as its first Type, it had a 14% chance to learn it. 
 And if it was its second Type, it would be lowered to 10%. Meh, not the worst, right? 
 Yet here's the kicker: If it was on the third Type, like Drimogemon or Vademon, you had 
 a 0% chance. Yes, you were NOT capable of learning a Tech you could use!
 
 As you can imagine, we did not know this back then. Can you imagine how much time we wasted 
 globally trying to learn something the code wouldn't let us learn, without even telling us 
 it was futile? Yeah. Pretty disheartening, and made quite a few Digimon much worse than others. 
 
 And this also applied to learning Techs through Brain Training, and it had even lower chances!
 for every Brain amount that ended with 50 (so 50, 150, 250 etc) you had a chance to learn something.
 But it was mostly useless with how low chances were and how often you simply had 0% to learn. 
 
 This is why I changed all of that for this hack. No matter the order, you have the same chance 
 to learn any Tech that your Digimon can use. Not only that, but the chances have been improved 
 significantly.
 
 That goes for both learning through battling and Brain Training. Chances for Brain Training are 
 obviously lower as it has no risk involved unlike fighting, and you could learn ANY Tech that 
 the Digimon could learn, so you get several chances for multiple Techs. 
 

	----------------------------
	S003 - Food and Item Changes
	----------------------------

 There's quite the variety of Items in Digimon World, some more common, and some frustratingly 
 rare, and a good chunk of them are Food! Unfortunately, what the actual effects of each one 
 are is very obscured and often not even hinted, the most you can get is an underwhelming 
 description of the Item and that's it.
 
 But once you look at data for these things, you discover that a chunk of them felt kinda useless,
 either because its effects were too little, or they were too rare to become of any actual usefulness 
 as more basic ones got the job done, and a bunch of them had the same effect too.
 
 I took the liberty of modifying them, trying to make as many of them have some sort of use 
 regardless of your progress through the game. For example, the basic Meat is great to increase 
 your Digimon's weight both early on and late into the game, while Digishrooms offer the same 
 nutritional value with less increament of Weight, and Digianchovy now provides more energy 
 than either as it takes more effort to get via fishing.
 
 Talking about Fish, they were made also more useful, specially early on, as you can invest your 
 Digimushrooms into fishing and be assured of getting at least something better for your time.


   Ene: Refers to how filling the Item is for your Digimon.        Hap: How much Happiness it provides.  
   Wei: Of course, how much Wegiht is added to your Digimon.       Dis:	How much Discipline it provides.
        A negative number takes away Weight.	
   Tir: How much Tiredness it removes from your Digimon.          Life: How many Hours of life it gives to your Digimon. 
        They're always negative values.                                 Digimon. Each in-game Hour is one real time Minute.
   HP/MP:  How much HP or MP it recovers.
   
  -------------------------------------------------------------------------------------------------------------------
  Name          Ene Wei Tir Hap Dis Life   HP   MP   Other
  -------------------------------------------------------------------------------------------------------------------
  Meat           15   2   -   -   -    -  ---  ---   Good to raise the Digimon's weight early on. 
  Giant Meat     25   3   -   -   -    -  ---  ---   More filling, gives a bit more weight.
  Sirloin        35   4  -5   5   -    -  ---  ---   Most filling, heals tiredness and gives happiness.
  SuperCarrot    15  -2   -   -   -    -  ---  ---   Training MP, Off & Brain +20%. It lowers weight. *
  HawkRaddish    15   2   -   -   -    -  ---  ---   Training HP, Def & Speed +20%. It raises weight. *
  Digipine       20   0   -   -   -    -  ---  ---   Training all Stats up by +50%. Adds no weight.   *
  SpinyGreen     10   1 -50   -   -    -  ---  ---   Takes away tiredness, great for training. 
  Digimushroom   15   1   -   -   -    -  ---  ---   Good to keep your Digimon at lower weight levels. 
  Ice Mushroom   20   2   -   -  50    -  ---  ---   Raises discipline significantly. 
  DeluxeMshroom  40   2   -   -   -    -  ---  ---   HP/MP +150, Off/Def/Spe/Bra +15.
  Blue Apple     30   2   -  50   -    -  ---  ---   Very filling, and raises happiness significantly. 
  Red  Berry     25   2 -20  20  20    -  ---  ---   Provides Happiness Discipline and reduces Tiredness all in one.
  Gold Acorn     40  10   -   -   -    -  ---  ---   Very filling, increases Weight by a lot. 
  Big  Berry     80  20   -   -   -    -  ---  ---   Fully saciates your Digimon, increases the most weight.
  Sweet Nut      20   2   -   -   -    - 9999  ---   Fully restores the HP of the Digimon. 
  Super Veggie   20   2   -   -   -    -  --- 9999   Fully restores the MP of the Digimon.
  Orange Banana  25   2   -   -   -    - 1500 1500   Recovers full HP & MP if eaten when hungry.
  Prickly Pear   30 -10   -   -   -    -  ---  ---   Decently filling, takes away a lot of weight. 
  Power Fruit    25   2   -   -   -    -  ---  ---   Offense +25.
  Power Ice      25   2   -   -   -    -  ---  ---   Defense +25.
  Sage  Fruit    25   2   -   -   -    -  ---  ---   Brains  +25.
  Speed Leaf     25   2   -   -   -    -  ---  ---   Speed   +25.
  Muscle Yam     20   2   -   -   -    -  ---  ---   HP     +250.
  Calm   Berry   20   2   -   -   -    -  ---  ---   MP     +250.
  Digianchovy    25   1   -   -   -    -  ---  ---   Quite filling, provides very little weight gains.
  Digisnapper    35   2   -   -   -    -  ---  ---   Great to saciate larger Digimon while keeping weight low. 
  Digitrout      50  -5   -   -   -    -  ---  ---   Doesn't lower tiredness like Sirloin but lowers Weight and fills more.
  Black Trout    30   2   -   -   -    -  ---  ---   HP/MP +100, Off/Def/Spe/Bra +10.
  Digicatfish    80 -20   -   -   -    -  ---  ---   Fully saciates your Digimon, lowest the most weight. 
  DigiSeabass    35   5   -   -   -    6 9999 9999   5%   chance to make your Digimon sick. Gives 6 hours of Lifespan.
  Moldy Meat     30   2   -   -   -    -  ---  ---   100% chance to make your Digimon sick. 
  HappyMushroom  15   2 -30  30   -    -  ---  ---   30%  chance to make your Digimon sick. 
  Chain Melon    50   0 -50  50   -   24  ---  ---   5%   chance to make your Digimon sick. Gives a full day of Lifespan.
  -------------------------------------------------------------------------------------------------------------------
  * The training effect of SuperCarrot, HawkRaddish and Digipine go away if you fed your 
    Digimon something else after giving them one of these, so the best way to use them 
    is to either give one of them last when feeding them so they last longer, or go to 
    the restaurant, as feeding them through that doesn't remove the effect but you will 
    need the Bits to do so. On the other hand you will get some extra Stats!
  -------------------------------------------------------------------------------------------------------------------

 The other group of Items are more like your usual RPG stuff, with thing to recover 
 HP and MP, or ailing Status Effects. They have not suffered much change, beyond prices 
 for the most part. But there are a couple that do have important changes:
 
  ---------------------------------------------------------------------------------------
  Name          Usage              Description
  ---------------------------------------------------------------------------------------
  HP Floppy     In/Out of Battle   Recovers  500 HP to your Digimon 
  Big   HP      In/Out of Battle   Recovers 1500 HP to your Digimon 
  Large HP      In/Out of Battle   Recovers 5000 HP to your Digimon 
  Full  HP      In/Out of Battle   Recovers All  HP to your Digimon 
  ---------------------------------------------------------------------------------------
  MP Floppy     In/Out of Battle   Recovers  500 MP to your Digimon
  Big   MP      In/Out of Battle   Recovers 1500 MP to your Digimon
  Large MP      In/Out of Battle   Recovers 5000 MP to your Digimon
  ---------------------------------------------------------------------------------------
  Double Floppy In/Out of Battle   Recovers 1500 HP and MP to your Digimon
  Omnipotent    In Battle only     Recovers all HP and MP, heals any Status besides Coma
  ---------------------------------------------------------------------------------------
  Restore       In Battle only     Recovers from Coma and gives  50% of the Max HP back
  Sup.Restore   In Battle only     Recovers from Coma and gives 100% of the Max HP back
  ---------------------------------------------------------------------------------------
  Various       In Battle only     Heals any Status besides Coma
  Protection    In Battle only     Protects from Status during the battle
  Bandage       Out of Battle      Heals Sickness and minor Injuries 
  Medicine      Out of Battle      Heals Sickness and all Injuries 
  ---------------------------------------------------------------------------------------
  Off. Disk     In Battle only     Raises Offense by 20 each during one battle   ***
  Def. Disk     In Battle only     Raises Defense by 20 each during one battle   ***
  HiSpeed Disk  In Battle only     Raises Speed   by 20 each during one battle   ***
  S.Off.Disk    In Battle only     Raises Offense by 50 each during one battle   ***
  S.Def.Disk    In Battle only     Raises Defense by 50 each during one battle   ***
  S.Speed Disk  In Battle only     Raises Speed   by 50 each during one battle   ***
  Omni Disk     In Battle Only     Raises Off. Def. & Speed by 20 during one battle ***

  Note: These disks stop giving effect after you've reach a 30% extra of a given stat. 
        If your Offense is 100, it will stop increasing after reaching 130, for example.
		If a stat is 999 already, it won't go beyond that.
  ---------------------------------------------------------------------------------------
  Off.  Chip    Out of Battle      Raises Offense by 50 permanently
  Def.  Chip    Out of Battle      Raises Defense by 50 permanently
  Brain Chip    Out of Battle      Raises Brains  by 50 permanently
  Quick Chip    Out of Battle      Raises Speed   by 50 permanently
  HP    Chip    Out of Battle      Raises Max HP  by 50 permanently
  MP    Chip    Out of Battle      Raises Max MP  by 50 permanently
  DV Chip A     Out of Battle      Raises Off. & Brains by 100, but takes a day of Lifespan
  DV Chip D     Out of Battle      Raises Def. & Speed  by 100, but takes a day of Lifespan      
  DV Chip E     Out of Battle      Raises HP & MP  by 1000, but takes a day of Lifespan
  
  Note: Devil Chips also have a 10% Chance of lowering Tamer Level.
  ---------------------------------------------------------------------------------------  
  Porta Potty   Out of Battle      Makes the need to go to the bathroom disappear ***
  Auto  Pilot   Out of Battle      Transports you back to File City
  Rest Pillow   Out of Battle      Extends the HP and MP recovered by sleeping by 20%
  Health Shoes  Out of Battle      Makes you slowly recover HP and MP when walking
  Enemy Repel   Out of Battle      On multi-foe battles, makes it more likely for them to flee
  Enemy Bell    Out of Battle      On multi-foe battles, makes it more likely for them to stay
  Training Man. Out of Battle      Adds 10% more Stat Gains when training if in your bag
  
  Note: When using a Porta Potty you don't get any Happiness nor Discipline.
  ---------------------------------------------------------------------------------------
  
 Besides all of these, you have Digi-Evolution Items. These are pretty selfexplanatory, you give 
 it to your Digimon while on a specific stage (Rookie for Champion Items, Champion for Ultimate Items) 
 and it will evolve right that moment.

 I won't list them because there's nothing more to say about them, besides that in this hack they 
 provide Stat Gains unlike in the original game, and Lifespan extension if you evolve into Ultimate.

 This makes these Items far, far more useful and interesting. Before they were seen by most as a 
 detriment, with the only use case I've seen people agree was to fill up the Chart faster.

 Besides all the ones you could get before, the Electo Ring, previously unused, now exists inside 
 the game's world, and has been renamed as "Smelly Ring" and instead of doing nothing, now it evolves 
 your Digimon to Numemon. Can be obtained from Geremon with 15% Chance. 
 
 The Moon Mirror, another unused item, is also obtainable and renamed Ugly Mirror, and can be used to 
 evolve into Sukamon. Can be obtained from battling Sukamons in Factorial Town. 
 
 
 Lastly, the Enemy Repel and Enemy Bell can be obtained much sooner than before. Fighting Flarerizamon 
 for the first and Weedmon for the latter, you have a 10% chance of obtaining one. 
 
 Because the game did not explain well what they do, allow me to explain:
 
 Whenever you have several enemy Digimon onscreen right before starting a battle, there is a chance 
 they either join the battle against you, or feel unsure and run away.
 
 The Enemy Repen makes it so they want to go away much more often, and the Enemy Bell compels them 
 to stay and battle against you. It's not guaranteed, but it makes a difference.

-------------------------------------------------------------------------------------------

 -------------------
  Fishing Changes 
 -------------------
 
 Now that fishing provides better Items, I also wanted to make the Items you find a bit more interesting 
 to use when fishing. Certain Items attract certain types of fishes, and the more rare ones are a lot more
 appealing to bigger fish. 
 
 In the original game, many items shared the same traits as far as attracting fish, which made them less 
 interesting, not to mention most items only worked on the lower sized fish, so they were a waste of bait. 
 
 I tweaked this a bit to make certain items more interesting to specific fishes, increase the variety of 
 effects to make the bigger fishes less of a hassle to get, and to lower the necessity of making chained 
 fishing to get one of the bigger fishes.

 DA: Digianchovy DS: Digisnapper DT: Digitrout
 BT: Black Trout DC: Digicatfish SB: DigiSeabass

 Food           DA DS DT BT DC SB             Food           DA DS DT BT DC SB  
 --------------------------------             --------------------------------
 Meat           15 -- -- -- -- --             Prickly Pear   -- 15 15 20 15 --
 Giant Meat     -- 15 -- -- -- --             Orange Banana  -- 15 15 20 15 --
 Sirloin        -- -- 15 -- -- --             Power Fruit    -- 10 10 20 -- --
 SuperCarrot    -- 10 15 -- -- --             Power Ice      -- 10 10 20 -- --
 HawkRaddish    -- 10 15 -- -- --             Sage  Fruit    -- 10 10 20 -- --
 SpinyGreen     -- -- -- 20 10 --             Speed Leaf     -- 10 10 20 -- --
 Digimushroom   25 10 -- -- -- --             Muscle Yam     -- -- 10 10 10 20
 Ice Mushroom   -- -- -- -- -- 05             Calm   Berry   -- -- 10 10 10 20
 DeluxeMshroom  -- -- -- -- 10 --             Digianchovy    -- 15 -- -- -- --
 Digipine       -- -- -- -- -- --             Digisnapper    -- -- 15 -- -- --
 Blue Apple     20 -- -- -- 10 05             Digitrout      -- -- -- 10 -- --
 Red  Berry     20 20 -- -- -- --             Black Trout    -- -- -- -- 10 --
 Gold Acorn     20 -- 20 -- -- --             Digicatfish    -- -- -- -- -- 10
 Big  Berry     20 -- -- 20 -- --             DigiSeabass    -- -- -- -- -- --
 Sweet Nut      20 -- -- -- 20 --             Moldy Meat     15 15 -- -- 10 --
 Super Veggie   20 -- -- -- -- 20             HappyMushroom  10 10 -- -- -- 15
                                              Chain Melon    -- -- -- -- -- --
-------------------------------------------------------------------------------------------
 
 --------------------------
 S004 - Mechanical Changes
 --------------------------
 
 Here's a number of other changes that don't have specific sections, but needed to be 
 addressed. They range from minor to quite important: 
  
 1: The Weight and Battle requirements have been changed. 
 
 Weight originally worked on a range of 10. Now, they work in a range of 5. 
 Battles originally worked in a "Less than X" or "X or More" fashion, but now they work in a range, 
 like Weight, with a range of 4, including the lowest number. So if a Digimon before could need 
 15 or more Battles, now it could be between 12 and 15 Battles.
 
 ----------------------------------------------------------------------------------------------
 
 2: Feeding habits have been tweaked all around. 
 
 Certain Digimon, such as Gabumon required alarming amounts of food. Others consumed amounts of 
 Energy, obtained by eating, that were absurd compared to other Digimon of similar rank and size. 
 Most of them are subtle enough to not be noticebale, with the exception of those that had to eat 
 every three hours. 

 ----------------------------------------------------------------------------------------------

 3: This was pointed out above, but Evolutionary Items in the original game did not provide any Stat 
    Gains, nor Lifespan extension, but on this hack they do provide them. 

 Another thing changed is that, if you evolved from an Item in the original game, and would keep 
 playing (or I guess save with save states) and reach to evolve into an Ultimate, you would not 
 get Stat Gains upon evolution. Now that does not happen.
 
 Mind you that evolving by items doesn't give you Tamer Levels, though.

 ----------------------------------------------------------------------------------------------

 4: One-chance-only Techs now can be learnt by other means. 
 
 Previously, Infinity Burn, Pulse Laser, Reverse Prog,Delete Prog and DG Dimension were Techs 
 which had only one chance to be learnt outside of Brain Training, making them very hard to 
 obtain not only for the low chances of the original game, but because you only had one shot
 and you most probably did not have your Digimon as a species that could learn it either.
		  
 I am very happy to say that the game has been changed a bit to give the player the chance to 
 learn them outside of those one-time fights.
		  
 Infinity Burn can be learnt with one of the ClearAgumon in the Toy Kingdom. 
		  
 Pulse Laser from the Guardromon in Factorial Town. All of them know it.
		  
 And in the Back Dimension, I swapped the Tekkamon there for two Giromon that know Delete Prog, 
 DG Dimension and Reverse Prog. 
		  
 With that there's no "missable" Techs anymore, although you cannot count with having DG Dimension
 or Delete Prog until the end of the game if you don't learn them on those one-time battles. It's 
 not my fault that the game was designed for Mech to be only an Ultimate Level Type...

 ----------------------------------------------------------------------------------------------		 

 5:  File City Restaurant!

 The Restaurant was improved, from fixing Giromon's Jukebox, to the food itself.
 The bonuses that each dish gives are more appealing, there's no longer "tiers" of 
 dishes, all three options of each cook costs the same and provide the same number 
 of benefits, and as a nice little extra, eating in the Restaurant also gifts you 
 5 Merit points, what more can you ask for?

 Each cook grants raises to three different Stats, two fixed ones, and the other 
 one varies depending on the dish. For example, Meramon's dishes always raise Offense 
 by 15 and HP by 20, and each dish adds another 10 to either Defense, Speed or Brains.
 
 Every dish provides the same Happiness and Discipline bonuses. These dishes fill the 
 Digimon to the maximum, so you cannot eat several times and try to abuse it. 
 
 Oh, and eating in the restaurant does not alter your Weight, making it useful not just 
 for everything above, so you can control the weight of your Digimon better too.
 
 Digitamamon dishes no longer choose a random outcome out of three possibilites, 
 to me it wasn't very interesting as only one was the better one. 
 Oh, and Digitamamon does not have the glitch anymore, thanks to Vice04.  

 ------------------------------------------------------------
 Frigimon      Works between 18:00 to 24:00
               MHP MMP Off Def Spe Bra Tir Hap Dis Ene  Price 
 Snow Shake    +-- +20 +10 --- --- +15 -10  +4  +2 +80   2500
 Ice  Cream    +-- +20 --- +10 --- +15 -10  +4  +2 +80   2500
 Snow Cone     +-- +20 --- --- +10 +15 -10  +4  +2 +80   2500
 ------------------------------------------------------------
 Meramon       Works between 12:00 to 18:00
               MHP MMP Off Def Spe Bra Tir Hap Dis Ene  Price 
 Red Ramen     +20 --- +15 +10 --- --- -10  +4  +2 +80   2500
 Hot Curry     +20 --- +15 --- +10 --- -10  +4  +2 +80   2500
 Hot Pot       +20 --- +15 --- --- +10 -10  +4  +2 +80   2500
 ------------------------------------------------------------
 Tyrannomon    Works between 06:00 and 12:00
               MHP MMP Off Def Spe Bra Tir Hap Dis Ene  Price 
 Dragon Noodle +20 --- +10 +15 --- --- -10  +4  +2 +80   2500
 Zaurus Pizza  +20 --- --- +15 +10 --- -10  +4  +2 +80   2500
 J. Burger     +20 --- --- +15 --- +10 -10  +4  +2 +80   2500
 ------------------------------------------------------------
 Garurumon     Works between 00:00 and 06:00
               MHP MMP Off Def Spe Bra Tir Hap Dis Ene  Price 
 T-Bone Steak  --- +20 +10 --- +15 --- -10  +4  +2 +80   2500
 DX-Bone Steak --- +20 --- +10 +15 --- -10  +4  +2 +80   2500
 Phantom Steak --- +20 --- --- +15 +10 -10  +4  +2 +80   2500
 ------------------------------------------------------------
 Vademon:      Appears at random with a low chance. 
               MHP MMP Off Def Spe Bra Tir Hap Dis Ene  Price 
 Space Salada  +25 --- +05 +05 +05 +05 -10  +4  +2 +80   2500
 UFO   Soup    +25 +25 --- --- --- --- -10  +4  +2 +80   2500
 Galaxy Course --- +25 +05 +05 +05 +05 -10  +4  +2 +80   2500
 ------------------------------------------------------------
 Digitamamon:  Appears at random with a low chance.
               MHP MMP Off Def Spe Bra Tir Hap Dis Ene  Price 
 Boiled Egg    --- --- +15 +10 +10 +10 -10  +4  +2 +80   3000
 Omelette      --- --- +25 +20 --- --- -10  +4  +2 +80   3000
 Egg Bowl      --- --- --- --- +20 +25 -10  +4  +2 +80   3000
 ------------------------------------------------------------

 ----------------------------------------------------------------------------------------------

 6: Factorial Town Evolution Mechanic 
 
 In the original game, you could make your Digimon evolve into another if it was a 
 Mamemon, and could be turned into a MetalMamemon, or a Giromon. 
 
 Neat idea, but quite underused, and it was more of a side-change than evolving, you 
 already needed an Ultimate. Vice04 wanted to expand on it, and reworked it to 
 allow 7 different digimon to evolve into two different others, one with 50% chance, 
 and another with 10% (the other 40% counts as failing, just like in the original game).
 
 The way it works now is that it checks for specific Champions or Etemon, and tries to 
 make it evolve into an Ultimate. Because this unlocks very, very late into the game, it 
 does not matter much, because by that point you could get to Ultimate very easily 
 through either training or Items in the Arena.
 
 Here are the evolution possibilities:
 
 Greymon:    MetalGreymon 50% Machinedramon 10%
 Tyrannomon: Mamemon      50% Machinedramon 10% 
 Seadramon:  Gigadramon   50% MegaSeadramon 10%
 Angemon:    Andromon     50% Vademon       10%
 Leomon:     Panjyamon    50% Andromon      10%
 Etemon:     MetalEtemon  50% Andromon      10%
 Nanimon:    MetalMamemon 50% Giromon       10%
 
 ...Yes, this mean Machinedramon is playable. Before you start clapping with your ears, 
 remember that, as cool as it looks, it has a very limited pool of Techs compared to any 
 other Digimon. Its Finisher Tech is really strong, though...

 ----------------------------------------------------------------------------------------------

 7: Drimogemon Treasure Search Business. 
 
 Once you recruit Drimogemon it will open a service in which it will try 
 to find an Item for you.
 
 It has two plans, one for 3 Days, and one for an astounding 10 days. 
 Once you recruit Gabumon, it actually improves significantly this service.
 
 I have made a single change to the 3 Day plan, but the 10 Day one got a bigger one,
 changes for both of them are only noticeable once you have Gabumon recruited too.
 
 3 Day Plan with Gabumon             10 Day Plan with Gabumon 
 
    26% Restore                            8% Offense Chip
    16% Sup.Restore                        8% HP Chip 
     8% Omnipotent                         8% Brain Chip 
     8% Protection                         8% Def   Chip
     8% S.Off.Disk                         8% MP Chip 
     8% S.Def.Disk                         8% Quick Chip 
     8% S.Spd.Disk                         8% Koga Laws 
     8% Omnidisk                           8% Flaming Wing 
     4% FlamingWing                        8% Torn Tatter
     4% TornTatter                         8% Sup. Restore
     2% Koga Laws                         10% Restore 
                                          10% Omnipotent

 To point out the differences: 
 
 On 3 Days Plans, instead of getting Large MP, which can be bought cheaply, you get 
 Restores which are more valuable. 
 
 On 10 Days Plans, Chips and Evolution Items have twice the chances than before, 
 while Omnipotent and Restore are down to 10% from 32% and 24% respectively. 
 So now it's far more likely to give you better stuff.
 
 Again, you wait TEN DAYS for a single thing, it should be more worth it.

 ----------------------------------------------------------------------------------------------

 8: Curling Rewards 
 
 I changed a few of the Items that are given to you if you win, because a bunch of them were 
 kinda underwhelming, either because you could buy them or because they were... Meat. 
 
 Winning against Penguinmon:
 Rooster, White Fang, DeluxMshrm, Big Berry, Digipine, Omni Disk
 
 Winning against MetalMamemon
 Silver Ball, Metal Armor, Chainsaw, Small Spear, Ray Gun, Mysty Egg, Full Recover

 ----------------------------------------------------------------------------------------------

 9: Tournaments:
 
 Ah, the Arena, what a cool idea... But how frustrating is in practice. 
 
 The Digimon you fight here are generally smarter and much stronger, and there's 
 lots of different tournaments which is fun.
 
 But it's a bit uneven with what Digimon can enter each one, and the most annoying 
 part is that, while your enemies will always be at full HP and MP, you only 
 recovered 20% of each between rounds.

 This forces you to play on very specific cheap ways, as there's no way you can 
 fight fairly against foes that often have higher Stats than you expect, and 
 are always at top form while you are not, or to only do the Arena when your
 Digimon was maxed out, which was boring and removed any excitement for me.

 So a few changes were made.  

 First, now you recover 80% of your HP and MP, so the player should have a lot 
 more room to use other tactics and a much larger variety of Techs, and also 
 be a lot more fair as you will have enough HP to actually try fighting on 
 the second and third rounds.
 
 Second, the Type Tournaments got a few changes made to the Digimon that can 
 enter. I took away the Rookies, because the never had any chance and entering 
 with them was basically losing before starting. You had no time to train them 
 enough to compete against the Champion and Ultimates in the Arena with only 
 three days. 
 
 So I used their slots to put Champion and/or Ultimate Digimon that could fit
 it but weren't available, like Phoenixmon in Fire Cup. 
 
 Normal Tournaments:
 -----------------------------------------------------------------------------
 These are the usual ranked Cups. D, C, B, A and S.
 
 D is for Rookies.
 C is for Rookies and "weak" Champions. 
 B is for Champions.
 A is for Champions and Ultimates. 
 S is for Ultimates.

 Or at least, that's the intention. Any Digimon can enter any besides 
 Machinedramon. Yes, Gigadramon, Panjyamon and MetalEtemon can. 
 
 But have in mind that you have a 30% chance to have your Tamer Level 
 lowered if you try to enter a D or C rank tournament with an Ultimate 
 Level Digimon. Quite risky, seeing how slowly you gain Tamer Levels.

-----------------------------------------------------------------------------
 Type Cups
-----------------------------------------------------------------------------
 For "Type" Cups, the game only cared for the first type of a Digimon. 
 So for example, Agumon and Greymon could enter, but MetalGreymon does 
 not because its first type is Mech. 

 I tried to make a few changes to include Digimon that feel they should 
 be in some of these cups, but it's not perfect as I also removed the 
 Rookies. They really had little to no chance to win, at least on your 
 side, so I believed those slots were better used for Champion and 
 Ultimates. 
 
----------------------------------------------------------------------------------------------------------------------
 F - Fire Cup                                         G - Grapple 
 -------------                                        -------------
 Greymon Meramon Birdramon                            Devimon Tyrannomon Mamemon Monzaemon Ogremon
 Centarumon Monochromon                               Drimogemon Leomon  Kokatorimon SkullGreymon
 Digitamamon Phoenixmon MetalEtemon                   MetalMamemon Etemon MetalEtemon Panjyamon Gigadramon
 
 W - Air (W for Wind, I guess?)                       N - Nature 
 -------------                                        -------------
 Airdramon Kokatorimon Bakemon                        Kabuterimon Vegiemon Kuwagamon
 Unimon Angemon Phoenixmon                            Ninjamon Monochromon 
 Piximon Monzaemon                                    Piximon H-Kabuterimon Gigadramon 
 
 C - Cool (Ice/Water Digimon)                         M - Mech (Only Ultimates, really)
 -------------                                        -------------
 Mojyamon Coelamon Shellmon Garurumon                 Mamemon MetalGreymon Vademon
 Frigimon Whamon Seadramon                            Andromon Giromon Megadramon 
 MegaSeadramon Panjyamon SkullGreymon                 T - Trash 
                                                      -------------
                                                      Nanimon Sukamon Numemon

----------------------------------------------------------------------------------------------------------------------
 Version Tournaments
-----------------------------------------------------------------------------
 Lastly, you have the "Version" Tournaments.
 
 Each Version Cup can only be entered by a certain group of Digimon, 
 and while these groups might look rather random and weird, they're based 
 on the original Digimon Virtual Pet / Tamagotchis that started it all, 
 which is quite a neat little wink if you ask me.  
 
 Version 1                                           Version 2
 ---------                                           ---------
 Agumon Betamon                                      Gabumon Elecmon 
 Greymon Devimon Airdramon                           Kabuterimon Angemon Birdramon Garurumon 
 Tyrannomon Meramon Seadramon Numemon                Frigimon Whamon Vegiemon 
 MetalGreymon Mamemon Monzaemon                      SkullGreymon MetalMamemon Vademon 
 
 Version 3                                           Version 4
 ---------                                           ---------
 Patamon Kunemon                                     Biyomon Palmon 
 Unimon Ogremon Shellmon Centarumon                  Monochromon Leomon Coelamon Kokatorimon
 Bakemon Drimogemon Sukamon                          Kuwagamon Mojyamon Nanimon 
 Andromon Giromon Etemon                             Megadramon Piximon Digitamamon 
 
 Version 0 
 ---------
 Penguinmon 
 Ninjamon
 Phoenixmon H-Kabuterimon MegaSeadramon 
 MetalEtemon Panjyamon Gigadramon
 
 ----------------------------------------------------------------------------------------------

 ------------------------
 S005 - Evolution Changes
 ------------------------
 
 Now we're getting to the big stuff! This section has a lot of explaining, so have patience.
 
 Evolution has been streamlined and expanded for each species. Rookies that had less than 6 possible 
 Champions to evolve to now have that amount. Certain Rookies had their possible evolutions changed 
 around so there's a bit more variety.

 In the same way, Champions that had less than 3 possible Ultimates to evolve into now have that amount, 
 which provides A LOT more variety and gives many Champions more value and the player a lot more options 
 to reach a particular Ultimate without having to go always with the same route.
 
 Besides those 3 Ultimates, Champions can also try to become one of the three "extra" Ultimates that 
 were not obtainable in the original game without external help: Gigadramon, MetalEtemon and Panjyamon.
 These three had requeriments higher than the others, do not matter to the completion of the Digimon 
 Chart. They have Type differences from their original counterparts and can partially learn different
 Techs from them, too. 
 
 With that said, I changed Panjyamon the most, as it was a Champion originally, and now it's an 
 Ultimate Digimon.
 
 Besides that, I also made it so Devimon can be evolved into through Patamon and Betamon, instead of 
 only being able to have it by making your Digimon into Angemon, and purposefully kill it until it 
 happens. That mode is still possible, like the other special ways to evolve or mutate, but you can 
 now also get to it through normal means.
 
 The same can be said about Vademon. You can still do the usual "wait" mode, or you can evolve to it 
 from a number of Champions. 

 I tried to take a look at the original Virtual Pets to choose some evolutions, like giving Vegiemon 
 the chance to evolve into Vademon, which was its only choice on those tamagotchis, but for the most 
 part I tried to share the Ultimates more or less evenly, as there are quite a few less than Champions. 
 That's why I also made Monzaemon, Etemon and Digitamamon available to other species besides the Filth 
 trio, but they're more limited than other Ultimates. 
 
 Overlap between requirements has been cut to a minimum, which was a constant issue in the original game. 
 Below you will see a small explanation about each of the requirement types needed for an Evolution, I 
 recommend a quick look, specially for Battles and Weight as they work differently enough now. 
 
 
 
 Regarding Evolution: 
 --------------------
 
 To choose an evolution, the game requires tree out of four possible elements to be
 considered acceptable in the requeriments. This is how the original behaves too, by the way. 
		   
 Those are Stats, Weight, Care Mistakes and a Bonus requirement. This last one is actually comprised of several 
 possible things, and vary depending on the species of Digimon you want to evolve into. Once one of the possible 
 Bonus requirements is successfully achieved, no other Bonus will add to your chances to evolve. 
 Meaning no matter how many Bonus requirements you met, it only counts for one.

 All of this means you can completely ignore either Stats, Weight or Care Mistakes and still evolve in what you
 want by using the Bonus requirement! But personally I rarely leave Stats out of the equation, because it's 
 easier for me to keep the stats where they should than intentionally make Care Mistakes, which you can easily 
 lose count, or I rather skip the Weight if I want an evolution that require no Care Mistakes. 
 
 It's your choice really, and one of the cool things about this system.
 
 Nonetheless, once you progress long enough in either the original game or this mod, the Bonus requirement will 
 be activated once you learn enough Techniques, and it'll always be on effect. Thus, once you reach the amount, 
 the other Bonuses, like Happiness, Discipline and Battles will be ignored... Which is a dobule edged sword, 
 because it's in effect for every evolution, not only the one you'd want to get. 
 
 There's an alternate patch that removes the the Tech Bonus, in case someone wants it, like myself.
 But back on track, the original game was quite messy regarding how unclear or overlapping the requirements 
 could get.
 
 For example: Say you had a Betamon, and wanted to evolve into Shellmon. It required 1000 HP and 100 Defense. 
 
 But it can also evolve into Coelamon, which only needed 100 Defense, so by aiming at Shellmon, you already 
 covered the requirement for Coelamon too. Shellmon needs 35 to 45 Weight, which is shared with Whamon, yet 
 another issue. And Shellmon requires five Care Mistakes or more, and by doing them, you're also fullfilling 
 the requirements for both Coelamon and for Seadramon!
 
 See what I'm talking about? It's very messy and is no wonder we all were so darn confused by evolution 
 back then. And it also affected Ultimate evolutions.
 
 For example, Meramon. In the original game, it can evolve into Andromon or MetalGreymon, and both overlap in Care 
 Mistakes, Battles, Discipline and of course, Techs; making it quite obnoxious to aim for one specific evolution 
 and meeting several of the requirements for the other automatically. 
 
 Which reminds me: Lastly, No Digimon has a Bonus requirement based on species.
 
 For example, Biyomon was sorta forced down the Birdramon evolution because it was a Bonus requirement. All of 
 these instances were removed. Not only made it harder for other Digimon to be Birdramon, with the example 
 mentioned, but also made it harder for Biyomon to evolve into other species, which isn't ideal to me. 
 
 It's a cute idea on paper mind you, but in the practice it complicates things.
 
 Now, here's some "snippets" of information regarding each value considered for evolution:
 ...Hahaha, imagine me being brief. Ludicrous.
 
    ------------------
    Note: About Stats:
	------------------
	In the original game, when checking for evolution, the stats that are the highest will be the ones used. 
	So even if you wanted a Greymon, and you had 1000 HP and 100 Offense, if you also had 101 in Speed, the 
	game would tally up the stats and say "Oh, so you want Birdramon!", and if instead you had 101 in 
	Brains, then the game would make your Agumon a Centarumon.
	
	Even more fun! Let's say your Agumon battled 10 times, and had a weight of 25, not unreasonable things 
	at all, specially early on. Even if it had 1000 HP required to evolve into Greymon, but had let's 
	say, 105 Offense, the game would still screw you over because those 5 extra Offense meant to the game 
	that "Oh, so you want to evolve into Meramon!". 
	
	This is because the original game has a weird Priority system in which the game chooses Evolutions in 
	a rather particular fashion, and it's one of the reasons that made things so inconsistent for all of 
	us back when we did not have hard evidence on how things worked. 
	
	Now, that entire system has been removed in this hack. Besides that and the changes in requirements 
	to avoid overlap, you simply get the stats you need to evolve the highest of all and you'll be fine.
      
    Stat requirements for Ultimates have been toned down from the original game. You need to raise 3 Stats to 
    400 (or 4000, if it's HP or MP). This cuts down time on training for evolving, and only that really, 
    because you will need to train regardless to keep with the stronger Digimon foes as you explore, and 
    if you wanted, you could ignore stats and use the other requirements anyway. 
    
    This was mostly done so you can get some time to explore or do things with your Champion Digimon other 
    than train it to get the requirements as you wait it to evolve, which in early cases could take basically
    all the Champion's lifetime. That's no fun.  
		
    --------------------------
    Note: About Care Mistakes:
    --------------------------
    Many, many rumours throughout the decades about what are Care Mistakes and how they affect your Digimon's 
    life. So many things were thought as Mistakes, when in reality only a few things do. My favourite was 
	believing that not letting your Digimon do their happy animation when iddling or eating was a mistake.
	
	Imagine a game punishing you for things such as these... Oh, hello there, Final Fantasy X-2!
	
	...Anyway, enough goofing off. Here's the list:
    
    1:
    Pooping on the ground is 1 Care Mistake. Sending your Digimon to sleep while it wants to poop won't be 
    seen as a Care Mistake, but your Digimon will still poop and the Virus bar will raise.
    
    2:
    Not feeding your Digimon during the period of time where it asks to be fed counts as 1 Care Mistake. A 
    Digimon will ask for food for a specific amount of time, if you haven't given it enough food after that 
    timer ends, then the Mistake is gained. 
    
    If this timer ends when your Digimon doing any training, or resting with an NPC (like Punimon or Centarumon)
    it counts as 2 Care Mistakes. This can be quite useful in the original game as some evolutions required high 
    number of Mistakes. In this mod, not as much, but it does cut down the time needed to get the necessary 
    Mistakes for a few, like Devimon, and does not fill the Virus bar but makes you feel like a douche.
    
    3: 
    Not letting your Digimon sleep until it stops asking to go to sleep, so keeping it awake during the 9 hours 
    it would sleep from the moment it asks, until its period of sleep ends.
       
    I do not recommend this, because if your Digimon doesn't rest, you won't be able to do much the next day before 
    it gets tired, which makes training useless, and battling more capable of injuring your Digimon. 
    Not to mention it also reduces Happiness and Discipline from your Digimon, shortening its Lifespan. 
    
    Unfortunately, I couldn't do much with the way the count for Mistakes works to avoid overlap.
    I tried to tweak it just enough, but it's the one thing where I couldn't avoid it. 

    -------------------
    Note: About Weight:
    -------------------
    Weight was probably one of the most annoying parts of evolution for several reasons. Weight ranges were on a range 
    of 10 points, which while might sound generous at first, it actually creates an issue by making several digimon 
    fall into the same weight ranges, increasing the chances of making your Digimon evolve into something you didn't 
    want, and you couldn't do much about it. 
    
    Thus, range has been reduced from 10 to 5, and the desired Weights of each species has been changed in a way to 
    avoid as much overlap between species as possible, providing much safer Weight amounts to make it easier to get 
    just right. 
    
    Combined with the changes in Food items, taking care of your weight should be much easier. With the Hunger Math 
    Glitch being fixed, you don't have to worry about your Weight being ruined anymore, but be warned that starting 
    out, you're better off choosing an evolution with medium to high Weight, as lower Weights are a bit hard to pull 
    off without certain foods or knowing well what you're doing.
    
    ...Or just ignore Weight and center on the other requirements. That works too. 
  
  
    And now, about Bonus Requirements. Remember you only need one of these!
	
    --------------------	
	Note: About Battles:
    --------------------
    Battles needed work differently. Before it was a "don't go over this number" or "get over this number". This 
    caused many situations where you were basically screwed, because might want an evolution with low Battles, but 
    several other ones might also need "less than x" battles so it increased the chances to get the other evolutions.
    
    Battles now work similar to Weight, with a range of necessary Battles, and safe amounts for each evolution. 
    This way you can pinpoint the exact evolution you desire without worrying, with the only annoyance being a 
    couple a bit harder to get early on namely Kokatorimon and Devimon needing between 16 and 19 battles.
    
    The battle count resets whenever your Digimon evolves, so have it in mind.

    -----------------------
	Note: About Tech Bonus:
    -----------------------
    As mentioned before in this readme, once your Digimon knows 30 Techs, it will automatically gain a bonus 
    point towards all Evolutions (if champion) and every other bonus condition (Happiness, Discipline, Battles) 
    will be ignored. The amount is 35 Techs for Ultimate evolutions.
    
    This sounds good on paper, but because it affects every possible evolution, it might make things harder. 
    This is how the original game works, and I decided to leave it like it in this mod...
    
    ...But there's an extra patch that will disable this, in case you rather have more control over your 
    evolutions, at the cost of having to met any of the other bonus requirements like you've done through 
    the game before learning 30 or 35 Techs... In other words, you'll keep playing the same way you've
    been doing since you began your journey.

    -------------------------------------
	Note: About Discipline and Happiness:
    -------------------------------------	
	
    Happines   goes from -100 to +100. 
     
    from -100 to -1 an angry red face icon will show up. 
    From  0 to +100 a happy yellow face icon will show up.
    
    So, if a Digimon needs 75 Happiness as a bonus, it means you need to be around three quarters full
    while the yellow icon is shown. Happiness is really easy to increase, and any that had a little 
    knowledge of the game can get even their first Digimon to almost full Happiness before evolving, 
    specially now with the Hunger Math Glitch being fixed.
    
    Happiness is also very important for Lifespan. If your Digimon hass less than 81 Hapiness, every 
    4 hours passed you will lose between 1 to 5 hours more, depending how much lower it is.
    Above 81, you won't have to worry about it.
		
    ---------------------------------------------------------------------------------------------------	
	
    Discipline goes from    0 to +100. 
    
    From 0 to 49 it's considered negative, the blue face icon with sunglasses appears, and the bar 
    is Blue on the left, pink on the right. 
    
    From 50 to 100 it has the normal yellow icon with glasses, and the bar is pink on the left, and 
    blue on the right. This is considered the "normal discipline" by players, generally. 
    
    So if a Digimon needs 75 Discipline as bonus, it means you need to be at half way through while 
    the yellow icon is shown, or in other words "half the normal bar".
    
    One good way to boost Discipline when it's low, is to try to give HP and MP recovering Items to 
    your Digimon. When having little Discipline, it very often refuses to eat them, or other healing 
    Items. When it refuses, without moving, scold your Digimon and it will gain a good chunk of 
    Discipline and some extra Happiness too!

    ---------------------------------------------------------------------------------------------------
    
    I hope these are fair values, neither too hard to obtain, nor too easy to get forcing you to 
    lower them to avoid unwanted evolutions to a point of seriously affecting the other stat
    through praising and scolding.
    
    Compare that to the original game, where they ask for 50 Discipline which is an empty looking bar 
    and you have to forcefully make your Digimon go to the negative side to avoid evolving into 
    something you don't want, which affects you negatively in several ways...
		
    -------------
    Baby Digimon:
    -------------
	These Digimon species work differently from others, and to evolve into a specific one,
	you need to follow two very simple rules: 
	
	Weight must be between 10 and 15. 
	One out of three Stats has to be the highest.
    --------------------------------------------------------------
			   Egg Type: Green dots.
	Koromon    Agumon  : Either HP, MP or Offense.
               Gabubmon: Either Defense, Speed or Brains.
    --------------------------------------------------------------
			   Egg Type: Yellow Stripes.
	Tokomon    Patamon : Either HP, Offense or Brains is highest.
               Biyomon : Either MP, Defense or Speed  is highest. 
    --------------------------------------------------------------	   
			   Egg Type: Pink Spots.
	Tanemon    Palmon  : Either HP, Offense or Speed  is highest.
               Betamon : Either MP, Defense or Brains is highest.
    --------------------------------------------------------------
			   Egg Type:   Blue Lines.
	Tsunomon   Penguinmon: Either MP, Defense or Brains is highest.
               Elecmon:    Either HP, Offense or Speed  is highest.
    --------------------------------------------------------------
	And of course, for Kunemon, make your Baby Digimon sleep on Kunemon's Bed area,
	and it could evolve into it with a 50% chance. It is best for you to save on 
	Jijimon's House on the Memory Card-like device WHILE your Baby is asking to 
    Sleep, or is close to start asking for it, and then go to Kunemon's Bed and 
    let it rest WITHOUT SAVING.

    This whay, if it doesn't evolve into Kunemon you can restart. If you save 
    during the sleeping, you also save after the game makes the choice, 
    whichever one it chooses.	
 
 ------------------------------------------------------------------------------------------
 Here's the list for Rookie Evolutions. Every Champion can be evolved into by two different 
 Rookies, with the exception of Kokatorimon, who can be accessed by three, simply because it 
 was the one that best fit on the last remaining spot on Penguinmon. 
 
 ------------------------------------------------------------------------------------
                            Min  Min  Min  Min  Min  Min     Range  Min Min 
            Evolution       HP    MP  OFF  DEF  SPE  BRA CM  Weight Dis Hap Bat Techs
            -------------------------------------------------------------------------
            Greymon        1200 ----  120   --   --   --  <2 31~35   75  --  --   30  
            Meramon        ---- ----  120   --  120   --  >2 06~10   --  -- 12~15 30
 Agumon     Tyrannomon     1200 ----   --  120   --   --  <5 36~40   --  -- 08~11 30
            Monochromon    ---- ----   --  120   --  120  <3 41~45   --  -- 04~07 30 
            Centarumon     ---- ----   --   --  120  120  <3 26~30   --  -- 00~03 30
            Birdramon      ---- 1200   --   --  120   --  >3 21~25   --  75  --   30
 ------------------------------------------------------------------------------------
                            Min  Min  Min  Min  Min  Min     Range  Min Min 
            Evolution       HP    MP  OFF  DEF  SPE  BRA CM  Weight Dis Hap Bat Techs
            -------------------------------------------------------------------------
            Garurumon      ---- 1200   --   --  120   --  <2 21~25   75  --  ---  30
            Drimogemon     ---- ----  120   --   --  120  <4 31~35   --  75  ---  30 
 Gabumon    Unimon         1200 ----   --   --  120   --  <3 16~20   --  -- 04~07 30
            Tyrannomon     1200 ----   --  120   --   --  <5 36~40   --  -- 08~11 30
            Mojyamon       ---- ----   --  120  120   --  >2 06~10   --  -- 00~03 30 
            Ogremon        ---- ----  120  120   --   --  >5 26~30   --  -- 16~20 30
 ------------------------------------------------------------------------------------
                            Min  Min  Min  Min  Min  Min     Range  Min Min 
            Evolution       HP    MP  OFF  DEF  SPE  BRA CM  Weight Dis Hap Bat Techs
            -------------------------------------------------------------------------
            Seadramon      ---- ----   --   --  120  120  <2 16~20   --  -- 04~07 30
            Whamon         1200 ----   --   --   --  120  <5 41~45   --  -- 08~11 30
 Betamon    Coelamon       ---- 1200  120   --   --   --  >3 11~15   --  -- 12~15 30 
            Shellmon       ---- 1200   --  120   --   --  >3 46~50   --  -- 00~03 30
            Frigimon       1200 1200   --   --   --   --  <5 31~35   --  75  --   30
            Devimon        ----   --   --  120   --  120  >5 06~10   --  -- 17~20 30
 ------------------------------------------------------------------------------------
                            Min  Min  Min  Min  Min  Min     Range  Min Min 
            Evolution       HP    MP  OFF  DEF  SPE  BRA CM  Weight Dis Hap Bat Techs
            -------------------------------------------------------------------------
            Birdramon      ---- 1200   --   --  120   --  >3 21~25   --  75  ---  30
            Airdramon      ---- 1200   --   --   --  120  <2 11~15   --  -- 08~11 30 
 Biyomon    Kokatorimon    1200 ----   --   --   --  120  >3 26~30   --  -- 16~19 30
            Unimon         1200 ----   --   --  120   --  <3 16~20   --  -- 04~07 30
            Kabuterimon    ---- 1200  120   --   --   --  <2 31~35   75  --  ---  30
            Meramon        ---- ----  120   --  120   --  >2 06~10   --  -- 12~15 30
 ------------------------------------------------------------------------------------
                            Min  Min  Min  Min  Min  Min     Range  Min Min 
            Evolution       HP    MP  OFF  DEF  SPE  BRA CM  Weight Dis Hap Bat Techs
            -------------------------------------------------------------------------
            Leomon         ---- ----  120   --  120   --  <2 21~25   --  -- 12~15 30 
            Drimogemon     ---- ----  120   --   --  120  <4 31~35   --  75  ---  30 
 Elecmon    Monochromon    ---- ----   --  120   --  120  <3 41~45   --  -- 04~07 30 
            Kokatorimon    1200 ----   --   --   --  120  >3 26~30   --  -- 16~19 30
            Bakemon        ---- 1200   --  120   --   --  >2 01~05   --  -- 08~11 30
            Angemon        ---- 1200   --   --   --  120   0 11~15   75  --  ---  30  
 ------------------------------------------------------------------------------------
                            Min  Min  Min  Min  Min  Min     Range  Min Min 
            Evolution       HP    MP  OFF  DEF  SPE  BRA CM  Weight Dis Hap Bat Techs
            -------------------------------------------------------------------------
            Kabuterimon    ---- 1200  120   --   --   --  <2 31~35   75  --  ---  30
            Kuwagamon      1200 ----   --  120   --   --  >4 36~40   --  -- 04~07 30 
 Kunemon    Vegiemon       ---- 1200   --   --  120   --  >3 16~20   --  75  ---  30
            Airdramon      ---- 1200   --   --   --  120  <2 11~15   --  -- 08~11 30 
            Shellmon       ---- 1200   --  120   --   --  >3 46~50   --  -- 00~03 30
            Ninjamon       ---- ----   --   --  120  120  >2 06~10   --  -- 12~15 30 
 ------------------------------------------------------------------------------------
                            Min  Min  Min  Min  Min  Min     Range  Min Min 
            Evolution       HP    MP  OFF  DEF  SPE  BRA CM  Weight Dis Hap Bat Techs
            -------------------------------------------------------------------------
            Ninjamon       ---- ----   --   --  120  120  >2 06~10   --  -- 12~15 30 
            Kuwagamon      1200 ----   --  120   --   --  >4 36~40   --  -- 04~07 30  
 Palmon     Vegiemon       ---- 1200   --   --  120   --  >3 16~20   --  75  ---  30
            Ogremon        ---- ----  120  120   --   --  >5 26~30   --  -- 16~20 30
            Whamon         1200 ----   --   --   --  120  <5 41~45   --  -- 08~11 30
            Greymon        1200 ----  120   --   --   --  <2 31~35   75  --  --   30
 ------------------------------------------------------------------------------------
                            Min  Min  Min  Min  Min  Min     Range  Min Min 
            Evolution       HP    MP  OFF  DEF  SPE  BRA CM  Weight Dis Hap Bat Techs
            -------------------------------------------------------------------------
            Angemon        ---- 1200   --   --   --  120   0 11~15   75  --  ---  30  
            Unimon         1200 ----   --   --  120   --  <3 16~20   --  -- 04~07 30
 Patamon    Centarumon     ---- ----   --   --  120  120  <3 26~30   --  -- 00~03 30
            Leomon         ---- ----  120   --  120   --  <2 21~25   --  -- 12~15 30 
            Bakemon        ---- 1200   --  120   --   --  >2 01~05   --  -- 08~11 30
            Devimon        ----   --   --  120   --  120  >5 06~10   --  -- 17~20 30
 ------------------------------------------------------------------------------------
                            Min  Min  Min  Min  Min  Min     Range  Min Min 
            Evolution       HP    MP  OFF  DEF  SPE  BRA CM  Weight Dis Hap Bat Techs
            -------------------------------------------------------------------------
            Frigimon       1200 1200   --   --   --   --  <5 31~35   --  75  ---  30
            Mojyamon       ---- ----   --  120  120   --  >2 06~10   --  -- 00~03 30 
 Penguinmon Garurumon      ---- 1200   --   --  120   --  <2 21~25   75  --  ---  30
            Coelamon       ---- 1200  120   --   --   --  >3 11~15   --  -- 12~15 30 
            Seadramon      ---- ----   --   --  120  120  <2 16~20   --  -- 04~07 30
            Kokatorimon    1200 ----   --   --   --  120  >3 26~30   --  -- 16~19 30
 ------------------------------------------------------------------------------------

 Here is the list for Champions!
 
 By far the evolution requirements here were the messiest of them all, with many Digimon 
 having evolutions with the same requirements at several points. It's no wonder we had so 
 much issues discerning what to do to evolve into a specific Digimon, when there was so 
 many shared requirements...

 And for the most part, that was cleaned up, with only Care Mistakes still having some 
 overlap, simply because I cannot change it into something else like it was done for 
 Weight and Battles. 
 
 Every Champion can access three "normal" Ultimates, unlike the original game, where
 some had three, others less, for some unfair reason. The Stats have been cut down a 
 fair bit to make them less of a hassle, to give the player more freedom to do other 
 things other than train.
 
 One very special thing is that thanks to some serious recoding by Vice04, we were 
 able to redesign the three "unused" Ultimates Panjyamon, MetalEtemon and Gigadramon
 so they form part of normal evolution! They have higher requirements, and while they
 do not affect the Digimon Chart (as in, they do not help in the progress for the 
 Medal, even if they appear on an individual Digimon's evolutive line), they fully work 
 like any other Digimon and have their differences from their original versions. 
 
 Thus, each Champion has three normal Ultimates, plus one of those three "special" 
 ones.
 
 Numemon, Sukamon and Nanimon still have only one "normal" Ultimate, plus one "special" 
 too. 

 -------------------------------------------------------------------------------------
                            Min  Min  Min  Min  Min  Min     Range   Min Min 
            Evolution       HP    MP  OFF  DEF  SPE  BRA CM  Weight  Dis Hap Bat Techs
            --------------------------------------------------------------------------
             Megadramon    4000 4000   --  400   --   --  <3 31~35   --  -- 21~24 35
 Greymon     MetalGreymon  4000 ----  400  400   --   -- <10 41~45   95  -- 25~28 35 
             SkullGreymon  ---- 4000  400   --   --  400  >5 26~30   --  -- 17~20 35
             Panjyamon     5000 5000   --   --   --  500   0 51~55   --  -- 36~40 40
 -------------------------------------------------------------------------------------  
                            Min  Min  Min  Min  Min  Min     Range   Min Min 
            Evolution       HP    MP  OFF  DEF  SPE  BRA CM  Weight  Dis Hap Bat Techs
            --------------------------------------------------------------------------
             Giromon       4000 4000  400   --   --   --  >7 16~20   --  90 32~35 35
 Devimon     SkullGreymon  ---- 4000  400   --   --  400  >5 26~30   --  -- 17~20 35
             Megadramon    4000 4000   --  400   --   --  <3 31~35   --  -- 21~24 35
             Metal Etemon  5000 5000   --   --   --  500   0 51~55   --  -- 36~40 40  
 -------------------------------------------------------------------------------------  
                            Min  Min  Min  Min  Min  Min     Range   Min Min 
            Evolution       HP    MP  OFF  DEF  SPE  BRA CM  Weight  Dis Hap Bat Techs
            --------------------------------------------------------------------------
             Megadramon    4000 4000   --  400   --   --  <3 31~35   --  -- 21~24 35
 Airdramon   Phoenixmon    4000 4000   --   --  400   --  <1 21~25   100 -- 12~15 35 
             Piximon       ---- 4000   --   --  400  400  <5 06~10   --  90  ---  35
             Panjyamon     5000 5000   --   --   --  500   0 51~55   --  -- 36~40 40
 -------------------------------------------------------------------------------------  		  
                            Min  Min  Min  Min  Min  Min     Range   Min Min 
            Evolution       HP    MP  OFF  DEF  SPE  BRA CM  Weight  Dis Hap Bat Techs
            --------------------------------------------------------------------------
             Phoenixmon    4000 4000   --   --  400   --  <1 21~25   100 -- 12~15 35 
 Tyrannomon  Mamemon       ---- 4000  400   --  400   --  <7 11~15   --  90  ---  35 
             SkullGreymon  ---- 4000  400   --   --  400  >5 26~30   --  -- 17~20 35
             Gigadramon    5000 5000   --   --   --  500   0 51~55   --  -- 36~40 40   
 -------------------------------------------------------------------------------------  		  
                            Min  Min  Min  Min  Min  Min     Range   Min Min 
            Evolution       HP    MP  OFF  DEF  SPE  BRA CM  Weight  Dis Hap Bat Techs
            --------------------------------------------------------------------------
             Andromon      ---- 4000   --  400   --  400  <5 26~30   --  -- 22~25 35 
 Meramon     MetalGreymon  4000 ----  400  400   --   -- <10 41~45   95  -- 25~28 35 
             MetalMamemon  4000 ----   --  400  400   -- <10 16~20   90  --  ---  35
             Gigadramon    5000 5000   --   --   --  500   0 51~55   --  -- 36~40 40 
 -------------------------------------------------------------------------------------  		  
                            Min  Min  Min  Min  Min  Min     Range   Min Min 
            Evolution       HP    MP  OFF  DEF  SPE  BRA CM  Weight  Dis Hap Bat Techs
            --------------------------------------------------------------------------
             Megadramon    4000 4000   --  400   --   --  <3 31~35   --  -- 21~24 35
 Seadramon   MegaSeadramon ---- 4000  400   --   --  400  <3 21~25   --  -- 12~15 35 
             Vademon       ---- 4000   --  400   --  400  >3 24~28   90  --  ---  35 
             Panjyamon     5000 5000   --   --   --  500   0 51~55   --  -- 36~40 40 
 -------------------------------------------------------------------------------------  		  
                            Min  Min  Min  Min  Min  Min     Range   Min Min 
            Evolution       HP    MP  OFF  DEF  SPE  BRA CM  Weight  Dis Hap Bat Techs
            --------------------------------------------------------------------------
             H-Kabuterimon ---- ----  400  400  400   --  <5 46~50   --  -- 17~20 35 
 Kabuterimon MetalMamemon  4000 ----   --  400  400   -- <10 16~20   90  --  ---  35
             Vademon       ---- 4000   --  400   --  400  >3 24~28   90  --  ---  35 
             Metal Etemon  5000 5000   --   --   --  500   0 51~55   --  -- 36~40 40  
 -------------------------------------------------------------------------------------  		  
                            Min  Min  Min  Min  Min  Min     Range   Min Min 
            Evolution       HP    MP  OFF  DEF  SPE  BRA CM  Weight  Dis Hap Bat Techs
            --------------------------------------------------------------------------
             Andromon      ---- 4000   --  400   --  400  <5 26~30   --  -- 22~25 35 
 Angemon     Piximon       ---- 4000   --   --  400  400  <5 06~10   --  90  ---  35
             Vademon       ---- 4000   --  400   --  400  >3 24~28   90  --  ---  35 
             Panjyamon     5000 5000   --   --   --  500   0 51~55   --  -- 36~40 40 
 -------------------------------------------------------------------------------------  		  
                            Min  Min  Min  Min  Min  Min     Range   Min Min 
            Evolution       HP    MP  OFF  DEF  SPE  BRA CM  Weight  Dis Hap Bat Techs
            --------------------------------------------------------------------------
             Piximon       ---- 4000   --   --  400  400  <5 06~10   --  90  ---  35
 Birdramon   Phoenixmon    4000 4000   --   --  400   --  <1 21~25   99  -- 12~15 35 
             MetalGreymon  4000 ----  400  400   --   -- <10 41~45   95  -- 25~28 35 
             Gigadramon    5000 5000   --   --   --  500   0 51~55   --  -- 36~40 40  
 -------------------------------------------------------------------------------------  		  
                            Min  Min  Min  Min  Min  Min     Range   Min Min 
            Evolution       HP    MP  OFF  DEF  SPE  BRA CM  Weight  Dis Hap Bat Techs
            --------------------------------------------------------------------------
             SkullGreymon  ---- 4000  400   --   --  400  >5 26~30   --  -- 17~20 35
 Garurumon   MegaSeadramon ---- 4000  400   --   --  400  <3 21~25   --  -- 12~15 35 
             Mamemon       ---- 4000  400   --  400   --  <7 11~15   --  90  ---  35 
             Panjyamon     5000 5000   --   --   --  500   0 51~55   --  -- 36~40 40 
 -------------------------------------------------------------------------------------  		  
                            Min  Min  Min  Min  Min  Min     Range   Min Min 
            Evolution       HP    MP  OFF  DEF  SPE  BRA CM  Weight  Dis Hap Bat Techs
            --------------------------------------------------------------------------
             Monzaemon     ---- ----  400   --  400  400   0 16~20   --  -- 16~20 35  
 Frigimon    Mamemon       ---- 4000  400   --  400   --  <7 11~15   --  90  ---  35 
             Andromon      ---- 4000   --  400   --  400  <5 26~30   90  -- 22~25 35 
             Metal Etemon  5000 5000   --   --   --  500   0 51~55   --  -- 36~40 40  
 -------------------------------------------------------------------------------------  		  
                            Min  Min  Min  Min  Min  Min     Range   Min Min 
            Evolution       HP    MP  OFF  DEF  SPE  BRA CM  Weight  Dis Hap Bat Techs
            --------------------------------------------------------------------------
             MegaSeadramon ---- 4000  400   --   --  400  <3 21~25   --  -- 12~15 35 
 Whamon      Mamemon       ---- 4000  400   --  400   --  <7 11~15   --  90  ---  35 
             Digitamamon   4000 ----   --  400  400   --   0 16~20   --  -- 21~24 35 
             Gigadramon    5000 5000   --   --   --  500   0 51~55   --  -- 36~40 40  
 -------------------------------------------------------------------------------------  
                            Min  Min  Min  Min  Min  Min     Range   Min Min 
            Evolution       HP    MP  OFF  DEF  SPE  BRA CM  Weight  Dis Hap Bat Techs
            --------------------------------------------------------------------------
 Vegiemon    Piximon       ---- 4000   --   --  400  400  <5 06~10   --  90  ---  35
             H-Kabuterimon ---- ----  400  400  400   --  <5 46~50   --  -- 17~20 35 
             Vademon       ---- 4000   --  400   --  400  >3 24~28   90  --  ---  35 
             Gigadramon    5000 5000   --   --   --  500   0 51~55   --  -- 36~40 40  
 -------------------------------------------------------------------------------------  
                            Min  Min  Min  Min  Min  Min     Range   Min Min 
            Evolution       HP    MP  OFF  DEF  SPE  BRA CM  Weight  Dis Hap Bat Techs
            --------------------------------------------------------------------------
 Unimon      Giromon       4000 4000  400   --   --   --  >7 16~20   --  90 32~35 35
             Phoenixmon    4000 4000   --   --  400   --  <1 21~25   99  -- 12~15 35 
             Megadramon    4000 4000   --  400   --   --  <3 31~35   --  -- 21~24 35
             Panjyamon     5000 5000   --   --   --  500   0 51~55   --  -- 36~40 40 
 -------------------------------------------------------------------------------------  
                            Min  Min  Min  Min  Min  Min     Range   Min Min 
            Evolution       HP    MP  OFF  DEF  SPE  BRA CM  Weight  Dis Hap Bat Techs
            --------------------------------------------------------------------------
             Etemon        4000 ----   --   --  400  400   0 21~25   --  -- 12~15 35  
 Ogremon     Andromon      ---- 4000   --  400   --  400  <5 26~30   --  -- 22~25 35 
             Giromon       4000 4000  400   --   --   --  >7 16~20   --  90 32~35 35
             Metal Etemon  5000 5000   --   --   --  500   0 51~55   --  -- 36~40 40  
 -------------------------------------------------------------------------------------  
                            Min  Min  Min  Min  Min  Min     Range   Min Min 
            Evolution       HP    MP  OFF  DEF  SPE  BRA CM  Weight  Dis Hap Bat Techs
            --------------------------------------------------------------------------
             Digitamamon   4000 ----   --  400  400   --   0 16~20   --  -- 21~24 35 
 Shellmon    H-Kabuterimon ---- ----  400  400  400   --  <5 46~50   --  -- 17~20 35 
             MegaSeadramon ---- 4000  400   --   --  400  <3 21~25   --  -- 12~15 35 
             Metal Etemon  5000 5000   --   --   --  500   0 51~55   --  -- 36~40 40  
 -------------------------------------------------------------------------------------  
                            Min  Min  Min  Min  Min  Min     Range   Min Min 
            Evolution       HP    MP  OFF  DEF  SPE  BRA CM  Weight  Dis Hap Bat Techs
            --------------------------------------------------------------------------
 Centarumon  Andromon      ---- 4000   --  400   --  400  <5 26~30   --  -- 22~25 35 
             Giromon       4000 4000  400   --   --   --  >7 16~20   --  90 32~35 35
             Vademon       ---- 4000   --  400   --  400  >3 24~28   90  --  ---  35 
             Gigadramon    5000 5000   --   --   --  500   0 51~55   --  -- 36~40 40  
 -------------------------------------------------------------------------------------  
                            Min  Min  Min  Min  Min  Min     Range   Min Min 
            Evolution       HP    MP  OFF  DEF  SPE  BRA CM  Weight  Dis Hap Bat Techs
            --------------------------------------------------------------------------
             Giromon       4000 4000  400   --   --   --  >7 16~20   --  90 32~35 35
 Bakemon     SkullGreymon  ---- 4000  400   --   --  400  >5 26~30   --  -- 17~20 35
             Etemon        4000 ----   --   --  400  400   0 21~25   --  -- 12~15 35  
             Gigadramon    5000 5000   --   --   --  500   0 51~55   --  -- 36~40 40  
 -------------------------------------------------------------------------------------  
                            Min  Min  Min  Min  Min  Min     Range   Min Min 
            Evolution       HP    MP  OFF  DEF  SPE  BRA CM  Weight  Dis Hap Bat Techs
            --------------------------------------------------------------------------
             Etemon        4000 ----   --   --  400  400   0 21~25   --  -- 12~15 35  
 Drimogemon  MetalGreymon  4000 ----  400  400   --   -- <10 41~45   95  -- 25~28 35 
             Mamemon       ---- 4000  400   --  400   --  <7 11~15   --  90  ---  35 
             Panjyamon     5000 5000   --   --   --  500   0 51~55   --  -- 36~40 40  
 -------------------------------------------------------------------------------------  
                            Min  Min  Min  Min  Min  Min     Range   Min Min 
            Evolution       HP    MP  OFF  DEF  SPE  BRA CM  Weight  Dis Hap Bat Techs
            --------------------------------------------------------------------------
             Megadramon    4000 4000   --  400   --   --  <3 31~35   --  -- 21~24 35
 Monochromon H-Kabuterimon ---- ----  400  400  400   --  <5 46~50   --  -- 17~20 35 
             MetalGreymon  4000 ----  400  400   --   -- <10 41~45   95  -- 25~28 35 
             Metal Etemon  5000 5000   --   --   --  500   0 51~55   --  -- 36~40 40  
 -------------------------------------------------------------------------------------  
                            Min  Min  Min  Min  Min  Min     Range   Min Min 
            Evolution       HP    MP  OFF  DEF  SPE  BRA CM  Weight  Dis Hap Bat Techs
            --------------------------------------------------------------------------
             Andromon      ---- 4000   --  400   --  400  <5 26~30   --  -- 22~25 35 
 Leomon      Mamemon       ---- 4000  400   --  400   --  <7 11~15   --  90  ---  35 
             MetalMamemon  4000 ----   --  400  400   -- <10 16~20   90  --  ---  35	 
             Panjyamon     5000 5000   --   --   --  500   0 51~55   --  -- 36~40 40  
 -------------------------------------------------------------------------------------  
                            Min  Min  Min  Min  Min  Min     Range   Min Min 
            Evolution       HP    MP  OFF  DEF  SPE  BRA CM  Weight  Dis Hap Bat Techs
            --------------------------------------------------------------------------
             MegaSeadramon ---- 4000  400   --   --  400  <3 21~25   --  -- 12~15 35 
 Coelamon    H-Kabuterimon ---- ----  400  400  400   --  <5 46~50   --  -- 17~20 35 
             MetalMamemon  4000 ----   --  400  400   -- <10 16~20   90  --  ---  35
             Gigadramon    5000 5000   --   --   --  500   0 51~55   --  -- 36~40 40  
 -------------------------------------------------------------------------------------  
                            Min  Min  Min  Min  Min  Min     Range   Min Min 
            Evolution       HP    MP  OFF  DEF  SPE  BRA CM  Weight  Dis Hap Bat Techs
            --------------------------------------------------------------------------
             Phoenixmon    4000 4000   --   --  400   --  <1 21~25   99  -- 12~15 35 
 Kokatorimon Piximon       ---- 4000   --   --  400  400  <5 06~10   --  90  ---  35
             SkullGreymon  ---- 4000  400   --   --  400  >5 26~30   --  -- 17~20 35
             Metal Etemon  5000 5000   --   --   --  500   0 51~55   --  -- 36~40 40 
 -------------------------------------------------------------------------------------  
                            Min  Min  Min  Min  Min  Min     Range   Min Min 
            Evolution       HP    MP  OFF  DEF  SPE  BRA CM  Weight  Dis Hap Bat Techs
            --------------------------------------------------------------------------
             Vademon       ---- 4000   --  400   --  400  >3 24~28   90  --  ---  35 
 Kuwagamon   H-Kabuterimon ---- ----  400  400  400   --  <5 46~50   --  -- 17~20 35 
             Piximon       ---- 4000   --   --  400  400  <5 06~10   --  90  ---  35
             Panjyamon     5000 5000   --   --   --  500   0 51~55   --  -- 36~40 40  
 -------------------------------------------------------------------------------------  
                            Min  Min  Min  Min  Min  Min     Range   Min Min 
            Evolution       HP    MP  OFF  DEF  SPE  BRA CM  Weight  Dis Hap Bat Techs
            --------------------------------------------------------------------------
             Monzaemon     ---- ----  400   --  400  400   0 16~20   --  -- 16~20 35  
 Mojyamon    Mamemon       ---- 4000  400   --  400   --  <7 11~15   --  90  ---  35 
             Vademon       ---- 4000   --  400   --  400  >3 24~28   90  --  ---  35 
             Metal Etemon  5000 5000   --   --   --  500   0 51~55   --  -- 36~40 40  
 -------------------------------------------------------------------------------------   
                            Min  Min  Min  Min  Min  Min     Range   Min Min 
            Evolution       HP    MP  OFF  DEF  SPE  BRA CM  Weight  Dis Hap Bat Techs
            --------------------------------------------------------------------------
             MetalMamemon  4000 ----   --  400  400   -- <10 16~20   90  --  ---  35
 Ninjamon    Megadramon    4000 4000   --  400   --   --  <3 31~35   --  -- 21~24 35
             Piximon       ---- 4000   --   --  400  400  <5 06~10   --  90  ---  35
             Panjyamon     5000 5000   --   --   --  500   0 51~55   --  -- 36~40 40  
 -------------------------------------------------------------------------------------
                            Min  Min  Min  Min  Min  Min     Range   Min Min 
            Evolution       HP    MP  OFF  DEF  SPE  BRA CM  Weight  Dis Hap Bat Techs
            -------------------------------------------------------------------------- 
 Numemon     Monzaemon     ---- ----  400   --  400  400   0 16~20   --  -- 16~20 35  
             Gigadramon    5000 5000   --   --   --  500   0 51~55   --  -- 36~40 40  
 Note: When evolving into Numemon, your Digimon loses 10% of each one of its Stats.
 -------------------------------------------------------------------------------------
                            Min  Min  Min  Min  Min  Min     Range   Min Min 
            Evolution       HP    MP  OFF  DEF  SPE  BRA CM  Weight  Dis Hap Bat Techs
            -------------------------------------------------------------------------- 
 Nanimon     Digitamamon   4000 ----   --  400  400   --   0 16~20   --  -- 21~24 35 
             Gigadramon    5000 5000   --   --   --  500   0 51~55   --  -- 36~40 40  
 Note: When evolving into Nanimon, your Digimon does not gain any Stat points.
 -------------------------------------------------------------------------------------
                            Min  Min  Min  Min  Min  Min     Range   Min Min 
            Evolution       HP    MP  OFF  DEF  SPE  BRA CM  Weight  Dis Hap Bat Techs
            -------------------------------------------------------------------------- 
 Sukamon     Etemon        4000 ----   --   --  400  400   0 21~25   --  -- 12~15 35  
             Panjyamon     5000 5000   --   --   --  500   0 51~55   --  -- 36~40 40   
 Note: When evolving into Sukamon, your Digimon loses 50% of each one of its Stats.
 -------------------------------------------------------------------------------------  
 		
	-------------------
	S006 - Tech Changes
	-------------------

 This is another aspect of the game where I wanted to tweak things, and while I wasn't 
 able to do as much as I wanted, at least I got most of it I suppose. 
 
 Anyone that played the original game for a certain amount of time knows how uneven the 
 overall group of Techs is. You have four or five that are absolutely broken, and then 
 you have the rest. 
 
 This is one thing I really wanted to change. One thing that I've grown to loath is 
 creating a large number of "tools" for the player to use but then designing most of 
 them to be poor or a few of them way too good, resulting in most of your developed 
 ideas to be seen as useless. 
 
 I wanted to have a bit more equality between types, having in mind of course that this 
 having a real-time battle system, there are aspects like animation speed, range and how 
 fast an attack can be reused, which sadly I cannot edit.
 
 I tried to make attacks seen as less good to have better traits, and the ones that were 
 basically broken, like Ice Statue or Thunder Justice have hefty costs and/or reduced damage 
 down to more reasonable numbers. Other moves that were just "kinda there" I tried to improve, 
 either by making them relatively more powerful than others or by inflicting Status Effects
 with higher chances to provide some niche use cases.
 
 But this also brings a couple of things to be aware of: When starting you might be surprised 
 with some enemy Digimon doing higher damage than expected, like Goburimon's Magma Bomb, or 
 Modokibetamon's Water Blit. 
 
 I already mentioned above that Techs are overall a lot easier to learn in comparison with 
 the original game, but that also simplifies things a bit. 
 
 Each Digimon's Finisher Tech had its power also tweaked, to make all of them 
 conform to the same standards depending on the type or range of attack but the 
 differences in power are overall quite small between species of the same Level. 
 
 Here's the list of each Type, with a small comment on each Tech of every 
 Type to define what the move does in more detail. 
 
 ----------------------------------------------------------------------------------

 Pow: Pretty obvious, the power of the Tech. The final damage depends on 
      your Offense and your foe's Defense, plus the Types of the Tech and the Digimon 
      that's being targetted by the Tech and a bit of variable damage.

	  The power of the Tech is crucial for the final damage as it's what is multiplied 
	  by both the difference between the attacker's Offense and target's Defense and 
	  the Type Matchup. 

 MP:  The MP Cost of the Tech. It is relative to the other traits. Usually, the 
      more powerful and easier is to use, the higher the MP cost. Very, very 
	  high Brain stats (700 and up) can lower the MP consumption of Techs.

 Range: Pretty selfexplanatory too. Short means the Digimon needs to be very close 
        (or right next to) the foe. Long means that usually it's a projectile that 
		can travel a certain distance towards where the foe was when the attack 
		started, but some have homing capabilities. Wide attacks either the entire 
		field, or a huge area around either the attacker or the target.
		
 Accuracy: The chances for it to actually hit the foe, and not be blocked. The number 
           given here is the base chance of the Tech, but it is altered by the Speed 
		   stat of both the attacker and the defender Digimon.
		   
		   The Speed of the defender will be used to lower the Accuracy of the Tech, 
		   and a fraction of the attacker's Speed will be used to lower the Speed 
		   of the defender, lowering the blocking effect it grants.
		   
		   If you wanted to know why certain Digimon seemed to block like crazy, 
		   it's because of this. The Defender's Speed is quite important, and 
		   the attacker's doesn't cause much of an effect.

 Effect: Which Status Effect, or, Status Error as it's named in this game will the 
         Tech inflict, and at which chance. Status Errors are quite potent and can 
		 be really useful against foes, or truly debilitating against you if you're 
		 not prepared to heal them.

 Chances: the percentage at which your Digimon can learn a specific Tech, and it 
          depends on the order of the types of your Digimon. In the original game, 
		  depending on the order of the types you hade better, worse, or simply NO 
		  chances to learn a move that the species could actually use.
		  
		  Now it doesn't matter the order, everyone has the same chances. 
		  

----------------------------------------------------------------------------
								FIRE TECHS
 ---------------------------------------------------------------------------

---------------------------------------------------------
 Fire            Pow  MP  Range Acc Effect  Ch%  Chances
 --------------------------------------------------------
 Fire Tower      210 105  Short  80  Stun   20%    55%
 Prominence Beam 335 255  Long   75  Flat    5%    35%
 Spit Fire       120  75  Long   70  Conf   10%    75%
 Red Inferno     250 135  Wide   70  Flat   10%    50%
 Magma Bomb      300 150  Long   60  Conf   15%    40%
 Heat Laser      200 150  All    80  Flat   20%    40%
 Infinity Burn   400 345  Wide   70  Stun    5%    25%
 Meltdown        300 300  Wide   65  Stun    5%    25%
---------------------------------------------------------
 
 ---------------------------------------------------------------------------
 Name            Pow  MP  Range Acc Effect  Ch%  Chance 
 Spit Fire       120  75  Long   70  Conf   10%    75%
 
 Shoots a small projectile that travels forward.
 
 While it is on the low end of damage, it costs little MP, has a quick 
 enough animation and delay, so it can be used rather freely, and it's 
 useful even late in the game to interrupt enemies stopping them to use 
 their Techs. 
 
 Add a small chance to cause Confusion and you have a neat basic Tech.
 ---------------------------------------------------------------------------
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Heat Laser      200 150  All    80  Flat   20%    40%

 Irradiates strong heat to the entire battlefield. It doesn't have a long 
 startup animation, and doesn't need to be aimed, so it's very easy to use. 
 
 Causing Flat is a nice bonus too. Damage is just okay but it's fine for 
 such an easy to use Tech that can hit several enemies.
 ---------------------------------------------------------------------------
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Fire Tower      210 105  Short  80  Stun   20%    55%
 
 The attack generates a pillar of fire underneath its target, causing 
 damage and a decent chance to inflict Stun. When the attack is being 
 executed, the enemy's movement gets locked so it cannot avoid it as 
 easily as other moves could be. 
 
 It does not hold much power but with high Accuracy and good chances of 
 inflicting a Status Error, it can have its uses, specially since MP cost 
 is pretty low too.  
 ---------------------------------------------------------------------------
 Name            Pow  MP  Range Acc Effect  Ch%  Chance 
 Magma Bomb      300 150  Long   60  Conf   15%    40%
 
 Throws a homing ball of magma that explodes upon hit, causing heavy 
 damage to a single foe.
 
 It holds a lot of power for the MP cost, and can Confuse, but it has 
 one of the longest startup animations, and not too high Accuracy. 
 Its usefulness depends on how good you are timing the attacks, 
 and with higher Brains to have more commands, it can be used better.
 ---------------------------------------------------------------------------
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Red Inferno     250 135  Wide   70  Flat   10%    50%
 
 Basically, your standard fire breath attack. Its starting animation isn't 
 too long, and while not the most damaging, each one of the fireballs are 
 in fact their own "hit" so it can damage several foes, and also has a 
 rather decent area of effect, so it can spread its Flat Status better.

 Its MP consumption is pretty decent, and it has the interesting quirk that 
 if it gets blocked, each of those fireballs also are blocked. This sounds 
 bad until you realize that each blocked hit raises your Finisher gauge!
 ---------------------------------------------------------------------------
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Prominence Beam 335 255  Long   75  Flat    5%    35%
 
 The Digimon shoots a beam forward. It is pretty powerful, doesn't take long 
 to use, and it's overall a pretty reliable move. Its MP cost is on the 
 higher side, but that's basically its only drawback. Well, maybe it's very 
 low chance to cause Flat too, but with that damage, it doesn't matter much.
 ---------------------------------------------------------------------------
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Infinity Burn   400 345  Wide   70  Stun    5%    25%
 
 It's basically a stronger version of Fire Tower. Higher damage, higher MP 
 Cost, low Stun chances and slower attack animation. It is the strongest 
 Fire Tech, but you need to time it well to make the best out of it, and 
 the MP to keep using it too as well.

 In the original game you only had one chance to learn it through battle, 
 but now can be learnt from ClearAgumon.  
---------------------------------------------------------------------------
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Meltdown        300 300  Wide   65  Stun    5%    25%
 
 Causes high Fire damage in a large area arround the attacker. It deals a lot 
 of damage for such a wide range, but it also takes a lot of MP to use. It has 
 a fast starting animation, so it is hard to flinch the user to avoid it. 
---------------------------------------------------------------------------

----------------------------------------------------------------------------
								AIR TECHS
----------------------------------------------------------------------------

---------------------------------------------------------
 Air             Pow  MP  Range Acc Effect  Ch%  Chances
 --------------------------------------------------------
 Thunder Justice 400 345  Long   70  Stun    5%    25%
 Spinning Shot   270 180  Long   75  Flat   10%    35%
 Electric Cloud  170 120  Long   80  Stun   15%    55%
 Megalo Spark    335 255  Long   70  Stun    5%    35%
 Static Elect    140  90  Short  65  Stun   25%    70%
 Wind Cutter     225 135  Long   75  Flat   10%    45%
 Confused Storm  200 150  All    80  Conf.  20%    40%
 Hurricane       300 300  Wide   65  Conf.   5%    25%
---------------------------------------------------------
 

---------------------------------------------------------------------------
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Static Elect    140  90  Short  65  Stun   25%    70%

 The basic Air Tech. Its range is non-existing, and can be hard to connect 
 a hit with it, but compared to other basic Techs it's more powerful, and it 
 has a very good chance to Stun. You'll want anything else as soon as you can, 
 but with luck it can get you some easy wins early on. 
 
 With very high Speed it can be used more quickly, which can find some use
 on certain species of Digimon, depending on how they move doing this Tech.
---------------------------------------------------------------------------
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Electric Cloud  170 120  Long   80  Stun   15%    55%
 
 Basic long-ranged Air Tech, but not a bad one. The cloud homes into your 
 foe, it does very decent damage for a low enough MP cost, and has good 
 chances to Stun. It's a reliable low cost Tech, all in all. 
---------------------------------------------------------------------------
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Wind Cutter     225 135  Long   75  Flat   10%    45%
 
 A rather easy to use Tech.
 
 The digimon shoots a circular saw-like projectile towards the foe. Its size 
 depends on the size of the Digimon, and can hit more than one foe if they're
 close. Fast enough, easy to hit with, and sometimes causing Flat is great.
 
 While not the most powerful, because of its decent speed and overall 
 reliable performance, it is a comfortable Tech to use.
---------------------------------------------------------------------------
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Confused Storm  200 150  All    80  Conf.  20%    40%
 
 This Tech hits in an area, dealing damage to anyone close around the user. 
 
 It has a long starting animation, making you vulnerable, but with those 
 high Confusion chances, if you're lucky you can chain several ones while 
 not being hit at all. Not too powerfull but can be very annoying.
 
 ...And I mean, it can also be annoying for you too!
---------------------------------------------------------------------------
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Spinning Shot   270 180  Long   75  Flat   10%    35%
 
 The Digimon spins around, shooting three separate wind currents.

 Each one is considered a different hit, so it can hurt more than one foe,
 but you won't be hitting the same one twice though. Its starting animation 
 takes just enough to give a window to hit and flinch, but regardless of 
 that, it is a good Tech that covers a nice area. 
---------------------------------------------------------------------------
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Megalo Spark    335 255  Long   70  Stun    5%    35%
 
 A strong, middle-ranged Tech. It packs a punch, its starting animation is 
 short, and can Stun. While Thunder Justice might be stronger, Megalo 
 Spark can be used faster than it, and that's also quite important.
---------------------------------------------------------------------------
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Thunder Justice 400 345  Long   70  Stun    5%    25%
 
 The strongest Air Tech, with similar power and costs as Infinity Burn. 
 If two enemies are very close to eachother the moment the Thunder hits, 
 it could hit both, but that's very situational. It's a good high end move 
 given you have the MP to use it repeatedly, if not you're going to suffer. 
---------------------------------------------------------------------------
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Hurricane       300 300  Wide   65  Conf.   5%    25%

 It is basically an Air versionof Meltdown, really. One differenct is that 
 you can be interrupted more easily, so choose well when to use it. 
---------------------------------------------------------------------------
 
----------------------------------------------------------------------------
								ICE TECHS
----------------------------------------------------------------------------
 
---------------------------------------------------------
 Ice             Pow  MP  Range Acc Effect  Ch%  Chances 
 --------------------------------------------------------
 Giga Freeze     400 330  Med    70 Stun    5%     25%
 Ice Statue      230 245  Long   65 Flat    5%     25%
 Winter Blast    200 150  Wide   80 Stun   20%     40%
 Ice Needle      120  90  Long   70 Conf   10%     70%
 Water Blit      240 135  Long   80 Flat   10%     50%
 Aqua Magic      ---  60  Self   -------------     50%
 Aurora Freeze   300 300  Long   70 Flat    5%     25%
 Tear Drop       270 150  Long   65 Flat   25%     50%
--------------------------------------------------------
 

---------------------------------------------------------------------------
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Ice Needle      120  90  Long   70 Conf   10%     70%
 
 It is the basic Ice Tech, but not at all a bad one.

 It's fast to execute, and the projectile travels at high speeds making 
 it very hard to avoid unless very far, so it can be useful in very 
 annoying battles even later on, even more if it confuses your foe.

 It costs more MP than Spit Fire, but can be used a bit faster. 
---------------------------------------------------------------------------
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Tear Drop       270 150  Long   65 Flat   25%     50%
 
 It has a long starting time, which leaves the user open to getting hit,
 or to be avoided by foes that like to constantly move around. On the 
 other hand, it deals pretty decent damage for the MP cost, and has 
 high chances of causing Flat, which renders the foe unable to deal 
 high damage for a while. Not bad, but needs good timing. 
---------------------------------------------------------------------------
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Water Blit      240 135  Long   80 Flat   10%     50%
 
 Can be seen as a slower, more powerful version of Ice Needle. While 
 the starting animations takes a bit longer, the projectile itself isn't 
 slow at all, and it is overall a decent move, specially considering the 
 low MP cost.
---------------------------------------------------------------------------
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Ice Statue      230 245  Long   65 Flat    5%     25%
 
 This Tech has a far lesser delay time between uses, which is why it was 
 so popular in the original game as it was combined with stupidly high 
 power and surprisingly low MP cost for what it can do, it was broken.
 
 Here though, its damage is significantly more moderate, and has a higher 
 MP cost. It can still get some good use if you don't mind to burn your 
 MP really fast. 
---------------------------------------------------------------------------
 Name            Pow  MP  Range Acc Effect  Ch%  
 Giga Freeze     400 330  Med    70 Stun    5%     25%
 
 It's basically an Ice version of Red Inferno, with the difference being
 that unlike Red Inferno, it has less of a radius as it doesn't have the 
 same "fireballs moving outwards" effect, but to compensate it packs a 
 much bigger punch. 
 
 It's MP cost is slightly lower than other Tier 8 Techs.
---------------------------------------------------------------------------
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Winter Blast    200 150  Wide   80 Stun   20%     40%

 An Ice version of Heat Laser, basically. Average strength like the other  
 Techs of this style, but with good Stun chances, not needing to aim and 
 okay MP cost, you can get some pretty decent use of it throughout your 
 adventure.

---------------------------------------------------------------------------
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Aqua Magic      ---  60  Self   -------------     50%
 
 Increases Power and Speed by 7% and Defense by 8% with each use. 
 
 It's the weakest buffing Tech, but it also costs significantly less MP 
 than the others, and if we compare the results by spending similar 
 amounts of MP, Aqua Magic would provide higher gains than others. 
 
 The drawback is that you would need to also spend the time to cast 
 it several times, with the risk of getting hit. But you could use it 
 during the moments where the opponent is in the floor after being hit.
---------------------------------------------------------------------------
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Aurora Freeze   300 300  Long   70 Flat    5%     25%
 
 Similar to Meltdown and Hurricane. This one seems to execute faster than 
 Hurricane, and once it starts cannot be interrupted so it's easier to use.
---------------------------------------------------------------------------

 
----------------------------------------------------------------------------
								MECH TECHS
----------------------------------------------------------------------------

--------------------------------------------------------
 Mechanical      Pow  MP  Range Acc Effect  Ch%  Chances
 -------------------------------------------------------
 Power Crane     235 120  Long   70 Stun   10%	   45%
 All Range Beam  300 300  Wide   65 Stun    5%     25%
 Metal Splinter  215 150  Wide   75 Flat   10%     45%
 Pulse Laser     335 255  Long   75 Conf    5%     40%
 Delete Program  400 345  Long   70 Flat    5%     25%
 DG Dimension    400 450  All    70 ----------     25%
 Full Potential  --- 300  Self   -- ----------     25%
 Reverse Prog    250 165  Long   80 Conf   15%     40%
--------------------------------------------------------
 

---------------------------------------------------------------------------
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Power Crane     235 120  Long   70 Stun   10%	   45%
 
 A middle ranged attack that creates a mechanical object to hit a 
 single foe. It has decent Power/MP ratio, and seems to try to home 
 into the target, but it has a rather long starting animation, so you 
 need good timing, or you'll leave yourself open to being hit easily.
---------------------------------------------------------------------------
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Metal Splinter  215 150  Wide   75 Flat   10%     45%
 
 The Digimon summons a bunch of technological trash like resistors and chips 
 and throws it all around. It's similar to Tremor, basically.
---------------------------------------------------------------------------
 Name            Pow  MP  Range Acc Effect  Ch%  Chance 
 Reverse Prog    250 165  Long   80 Conf   15%     40%
 
 The attacker makes some sort of scanning of both, itself and the foe, and 
 then... hits it? The animation is kinda neat, but it takes a while before 
 the enemy is hit, so it might leave you open to being hit yourself.

 It has decent chances of causing Confusion though.  
---------------------------------------------------------------------------
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Pulse Laser     335 255  Long   75 Conf    5%     40%
 
 As if it was the ship in Raystorm, the Digimon charges up energy and shoots 
 a number of homing lasers to the foe. It seems that each laser has a chance 
 to hit, but if there's only one foe they will disappear before it can be 
 hit again. It's a powerful Tech.
---------------------------------------------------------------------------
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Delete Program  400 345  Long   70 Flat    5%     25%
 
 The Digimon summons a bunch of Binary code that surrounds the foe and hits 
 it. It is as powerful as the other "strongest" techs from the other Types.
 
 This Tech was on the original game one of the few that you only had one 
 chance to learn, but you can now try infinitely on Back Dimension's 
 Giromon.
---------------------------------------------------------------------------

---------------------------------------------------------------------------
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 All Range Beam  300 300  Wide   65 Stun    5%     25%

 With the use of strange devices, the Digimon attacks a large area around 
 itself. It's basically the same as the other large area attacks, with 
 the one big difference that there are blind spots between the lasers.
 
 Depending on the position you or your enemy can dodge it, but it's rare.
---------------------------------------------------------------------------
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 DG Dimension    400 450  All    70 ----------     25%
 
 Another Tech that hits the entire field. This one is much more powerful, 
 but it takes very long to do, and takes MP like nothing else. It's flashy, 
 and makes you cool until you realize you can do more in less time with 
 other Techs. But hey, it's soo cool...
--------------------------------------------------------------------------- 
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Full Potential  --- 300  Self   -- ----------     25%

 Boosts Offense by 25%, Defense and Speed by 15%. It's considered the 
 best buffing Tech when looking at the percentages, but the MP cost is 
 the highest, so you cannot reuse it as much as other Techs. On the 
 other hand, a single use packs a lot more gains than any other, and 
 it's not like you can't abuse healing items on mass... 
---------------------------------------------------------------------------

----------------------------------------------------------------------------
								EARTH TECHS
 ---------------------------------------------------------------------------


--------------------------------------------------------
 Nature          Pow  MP  Range Acc Effect  Ch%  Chances
 -------------------------------------------------------
 Poison Powder   180 120  Wide  75%  Poison 30%    45%
 Bug             350 270  Long  75%  Flat   10%    25%
 Mass Morph      --- 105  Self  --   ----------    50%
 Insect Plague   260 165  Long  75%  Poison 25%    40%
 Charm Perfume   200 150  All   80%  Confu. 20%    40%
 Poison Claw     110  90  Short 65%  Poison 35%    70%
 Danger Sting    220 135  Short 80%  Poison 20%    50%
 Green Trap      300 225  Long  80%  Stun   10%    35%
--------------------------------------------------------

--------------------------------------------------------------------------- 
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Poison Claw     110  90  Short 65%  Poison 35%    70%
 
 If there's one basic Tech that's more than what it looks, this is it. 
 
 Damage is low, MP cost is higher than some other simple Techs, but the 
 combination of its ability to cause Poison and how fast can be used makes 
 it a very powerful tool in making foes unable to do their attacks. 

 You won't be doing much damage on high level battles, but sometimes 
 flinching the enemy so they don't attack is all you need to get away.  
--------------------------------------------------------------------------- 
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Poison Powder   180 120  Wide  75%  Poison 30%    45%
 
 The Digimon aims to the sky and shoots pink particles of poison, covering 
 a large radius around it and hitting anything inside it. It has a high 
 chance to poison enemies, which is a great Status to inflict, and a horrible 
 one to suffer. 
 
 Damage is below average and attacking can leave you open to being hit,
 but doesn't need any aiming, it stays a bit on the field, just enough 
 to be able to hit an incoming Digimon. It is a very useful Tech early 
 on and again, its poisoning capabilities cannot be stated enough, 
 specially on multi-enemy battles. 

 If you don't get why, Poison not only reduces HP over time, but also 
 slows down movement speed and the speed at which Techs are used. 
 That's why it's such a powerful Status. 
--------------------------------------------------------------------------- 
 Name            Pow  MP  Range Acc Effect  Ch%  Chance 
 Danger Sting    220 135  Short 80%  Poison 20%    50%
 
 A stronger, albeit slightly slower Poison Claw. If the foe doesn't 
 have quick Techs, it can be quite effective with low MP cost, but for 
 disrutping duties Poison Claw is superior. 
 
 Its Accuracy is among the highest, too.
--------------------------------------------------------------------------- 
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Bug             350 270  Long  75%  Flat   10%    25%

 The Digimon creates a bunch of chips that crawl around the ground, 
 aiming for the opponent, climbing over it and exploding. Sounds convoluted, 
 but can be extremely effective. It can be situational, but sometimes it 
 can even hit twice your foe because some of the chips keep crawling around
 for just enough time for your foe to be hit by the first, get up and become 
 vulnerable again. 
 
 So it can do a lot of damge for the MP cost, and in the original game it was 
 ridiculously powerful. It has been toned down, but still very useful. 
--------------------------------------------------------------------------- 
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Insect Plague   260 165  Long  75%  Poison 25%    40%
 
 The Digimon creates a purple-ish cloud of Poison that slowly travels to the 
 foe. It's a rather curious move, as it will say on the field for a while 
 as the battle continues. 
 
 It can be useful as some sort of "obstacle" to make the foe run into while 
 doing other Techs. The damage is pretty good and has high chances to Poison.
 
 It can be situational but don't sleep on it, specially as you can spawn it
 and have it lurking around when an enemy is trying to use its Finisher,
 making it flinch and saving you from heavy damage.
--------------------------------------------------------------------------- 
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Green Trap      300 225  Long  80%  Stun   10%    35%
 
 Pretty straightforward Tech. The Digimon creates a seed that grows roots 
 directed to the enemy, hitting it. Offers good damage, a chance to Stun, 
 doesn't take long to do and doesn't cost much MP...
 
 ...But it has one weakness, if you're fighting one of those Digimon that 
 just wont stay still for a moment, it's very easy to miss with it.
 
 Outside of such moments, it's pretty good.
--------------------------------------------------------------------------- 
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Mass Morph      --- 105  Self  --   ----------    50%
 
 Boosts Defense by 20%, and Speed by 10%. While it doesn't grant any 
 Offense, the great Defense increase can help quite a bit, and it costs 
 half the MP as Full Potential.
---------------------------------------------------------------------------


----------------------------------------------------------------------------
								GRAPPLE TECHS
----------------------------------------------------------------------------

--------------------------------------------------------
 Grapple         Pow  MP  Range Acc Effect  Ch%  Chances
 -------------------------------------------------------
 Tremor          215 150  Wide   80% Flat   10%    45%
 Muscle Charge   --- 120  Self   --- ----------    25%
 War Cry         ---  90  Self   --- ----------    45%
 Sonic Jab       135  75  Short  65% Stun   20%    80%
 Dynamite Kick   280 150  Short  75% Conf   10%    45%
 Counter         350 150  Short 100% Conf   35%    50%
 Megaton Punch   335 225  Short  75% Stun    5%    35%
 Buster Dive     400 330  Long   70% Flat    5%    25%
--------------------------------------------------------
 
--------------------------------------------------------------------------- 
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Sonic Jab       135  75  Short  65% Stun   20%    80%
 
 Very basic Tech, and while MP cost is low and can Stun, its ridiculously
 low range will mean that often the foe will move out of the way. 
 
 Being able to Stun can help a lot to deal several hits without worrying, 
 but you'll probably want to learn anything else as fast as you can. 
 
 It's one of those Techs that can have varying degrees of usefulness based 
 on Digimon size, and it's very susceptible to the Speed stat. With high 
 enough Speed it can be close to what Poison Claw is. More powerful but 
 not as fast...
--------------------------------------------------------------------------- 
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Dynamite Kick   280 150  Short  75% Conf   10%    45%
 
 A very needed upgrade from Sonic Jab. Packs a much stronger puch for not 
 that much MP, but the most important part is that its range is better than 
 Sonic Jab by a bit. A basic, good Tech that could inflict Confusion. 
--------------------------------------------------------------------------- 
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Tremor          215 150  Wide   80% Flat   10%    45%
 
 The Digimon hits the ground, causing a bunch of boulders to pop out of the 
 ground, each one capable of hitting foes. The damage is decent, it can cover 
 a good area, MP cost is not too high and it's Grapple Tech with the highest 
 chance to cause Flat, not bad for something that can hit several foes.
--------------------------------------------------------------------------- 
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Megaton Punch   335 225  Short  75% Stun    5%    35%
 
 Basically, a much improved Sonic Jab. Its range is ever-so-slightly better 
 than Sonic Jab, the damage is high and MP not bad at all, but that's more 
 of a compensation for the lack of range. It is a bit slower than Sonic Jab, 
 but it's easier to hit with so it pretty much makes for a perfect replacement.
 
 ...Except for the fact that Sonic Jab is much better at causing Stun.
--------------------------------------------------------------------------- 
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Buster Dive     400 330  Long   70% Flat    5%    25%

 The Digimon starts charging up energy and does a jump forward, dealing 
 massive damage to the foe. It covers a much larger area than any other 
 Battle Tech besides Tremar, which is very useful, but its animation is 
 longer than the rest. Fortunately is not long enough to harm it, and 
 is overall pretty reliable as the attacker will turn to face the foe 
 as it charges up. 
 
 If fighting several enemies that are very, very close, it can hit them 
 at the same time. Very situational but a good thing.
--------------------------------------------------------------------------- 
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Muscle Charge   --- 225  Self   --- ----------    25%
 
 Boosts Offense by 30%. Offers the highest Offense gains, but provides nothing 
 else. For many, that's enough though, and the MP cost isn't as high as Full 
 Potential.
--------------------------------------------------------------------------- 
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 War Cry         ---  90  Self   --- ----------    45%
 
 Boosts Offense and Speed by 10%, and Defense by 5%. Slightly superior to Aqua 
 Magic, but the MP cost is also higher. MP for MP, War Cry will grant a small 
 amount extra of Offense and Speed, while Aqua Magic gives more Defense. 
 Overall, it is quite balanced and nice.  
---------------------------------------------------------------------------

----------------------------------------------------------------------------
								FILTH TECHS
 ---------------------------------------------------------------------------

--------------------------------------------------------
 Filth           Pow  MP  Range Acc Effect  Ch%  Chances
 -------------------------------------------------------
 Odor Spray      200 105  Short  70% Stun   20%    50%
 Poop Spd Toss   160 105  Long   65% Poison 25%    55%
 Big Poop Toss   250 180  Long   70% Conf.  20%    35%
 Big Rnd  Toss   300 240  Wide   70% Conf.  20%    35%
 Poop Rnd Toss   200 150  Wide   80% Poison 30%    45%
 Random Spd Toss 250 180  Wide   80% Poison 25%    45%
 Horizontal Kick 150  60  Short  65% Poison 30%    70%
 Ult. Poop Hell  400 345  All   100% Flat   30%    25%
--------------------------------------------------------


--------------------------------------------------------------------------- 
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Horizontal Kick 150  60  Short  65% Poison 30%    70%

 I don't know who they thought they'd be convince with that name. 
 It's basically a fart attack. No range, not very useful, not the weakest 
 Tech but certainly not something you want to depend on at all.
 
 ...Yet it's the only Tech you'll have starting on, on a Digimon that'll 
 be most probably pretty weak. 
 
 The Digital World is pretty devilish sometimes...
--------------------------------------------------------------------------- 
 Name            Pow  MP  Range Acc Effect  Ch%  Chance 
 Poop Spd Toss   160 105  Long   65% Poison 25%    55%

 Well... I mean, it is what it is. The Digimon creates poop and throws it 
 to the foe. High chances of poison, with pretty average Power. 
--------------------------------------------------------------------------- 
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Big Poop Toss   250 180  Long   70% Conf.  20%    35%
 
 The digimon opens its mouth and lets a horrible stench fly towards the foe, 
 dealing moderate damage, having pretty decent chances to Stun, and having 
 a low MP cost all things considered. Not bad range.
--------------------------------------------------------------------------- 
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Poop Rnd Toss   200 150  Wide   80% Poison 30%    45%
 
 The Digimon conjures up a pile of small poops and throws it around itself. 
 its akin to the weaker wide area Techs of other Types. It has higher Power, 
 but it's easier to miss if they avoid the poop. 
--------------------------------------------------------------------------- 
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Random Spd Toss 250 180  Wide   80% Poison 25%    45%
 
 The Digimon conjures up four poops that throws at different directions. 
 It's an improvement over Poop Spd Toss, and could potentially hit more 
 foes if you're battling groups. Besides that, not much more to say. 
--------------------------------------------------------------------------- 
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Big Poop Toss   250 180  Long   70% Conf.  20%    35%
  
  Similar to Poop Sp Toss, but with much higher Power, inflicting Confusion 
  instead of Poison, higher MP Cost... And a much bigger poop.
--------------------------------------------------------------------------- 
 Name            Pow  MP  Range Acc Effect  Ch%  
 Big Rnd  Toss   300 240  Wide   70% Conf.  20%    35%
 
 Well, take Big Poop Toss, and make it an area-of-effect Tech. The Digimon 
 conjures up a pile of big poops and throws it all around itself. It requires 
 little aim, and the power is closer to the stronger wide effect Techs, while 
 having less MP cost. 
--------------------------------------------------------------------------- 
 Name            Pow  MP  Range Acc Effect  Ch%  Chance
 Ult. Poop Hell  400 345  All   100% Flat   30%    25%
 
 Now that's a name... Ultimate Poop Hell. Anyway, the Digimon conjures up 
 massively sized poops that fall into the field, and after a few of those 
 an even larger one drops, making them explode and hurting all foes. 
 Pretty powerful, costly in MP, great chances to cause Flat...

 I'ts a fine move, besides the fact it's kinda easy to interrupt the user, 
 at least until the big poop falls, then there's no way back.
---------------------------------------------------------------------------


 -----------------
 Finish Tech List:
 -----------------
 In the original game, each Digimon has a unique attack to itself that can be unleashed 
 when the "Finish!" Letters are all displayed on your Digimon's HUD. These Techs are 
 much more powerful than normal ones and can be charged up by pressing L1 and R1 
 repeatedly.
 
 In the original game, the power of these Techs were all over the place, with no rhyme 
 or reason given to each one's power. For the most part, there are only two "traits"
 this Finish Techs have, which are Power and range.
 
 Power is pretty easy to understand, range is the minimum distance at which the attack 
 can be started. The thing is that there are many occasions where two Finish Techs are 
 equal in use, but one is arbitrarily made weaker with nothing to make up for it.
 
 For example, Centarumon's Solar Ray has a power of 167, but the Finish Tech of 
 Unimon, Airdramon, Meramon or Ninjamon are betwen 10 and 17 points less powerful
 and then you have Vegiemon's Finish Tech having a power of 130 only.
 
 And the kicker is, all of those have the exact same range and are Digimon of the 
 same Level, Champion. So what I did was to make a more standarized relation between 
 Power and Range, so the less rang the more powerful (as it is slightly riskier to 
 use, as the time needed to get closer might be enough for the foe to attack you 
 and interrupt your Finish Tech, leaving you with nothing) trying to make all 
 the lesser Finish Techs better and all of them more or less similar.
 
 Range goes from 1 being the absolute shortest, having to be right besides 
 the target to 6.
 
 --------------------------------------------------------------------------
 Tech Name       Digimon     Range   OG.Pow  ModPow Element          Rookie
 --------------------------------------------------------------------------
 Electric Shock  Betamon     1        92     100    Air
 Super Th.Strike Elecmon     1       100     100    Air
 Super Slap      Penguinmon  1        91     100    Ice
 Poison Ivy      Palmon      1       101     100    Earth
 Electric Thread Kunemon     2        94     100    Air
 Spiral Twister  Biyomon     3        91      95    Fire
 Boom Bubble     Patamon     3        85      95    Air
 Pepper Breath   Agumon      4        89      90    Fire
 Blue Blaster    Gabumon     4        90      90    Ice
 --------------------------------------------------------------------------
 Tech Name       Digimon     Range   OG.Pow  ModPow Element        Champion
 --------------------------------------------------------------------------
 Dark Claw       Bakemon     1       143     180    Air
 Variable Darts  Coelamon    1       153     180    Ice 
 Sub-0 Ice Punch Frigimon    1       157     180    Ice
 Death Claw      Devimon     1       180     180    Battle 
 Mega Flame      Greymon     3       196     175    Fire
 Blaze Blast     Tyrannomon  3       174     175    Fire 
 Howling Blaster Garurumon   3       183     175    Fire 
 Pummel Whack    Ogremon     3       170     175    Grapple
 Fist Beast King Leomon      3       170     175    Grapple 
 Drill Spin      Drimogemon  3       150     175    Grapple 
 Frozen FireShot Kokatorimon 3       159     175    Fire
 Scissor Claw    Kuwagamon   3       172     175    Grapple
 Fireball        Meramon     4       155     170    Fire
 Spnning Needle  Airdramon   4       152     170    Air
 Volcanic Strike Monochromon 4       160     170    Fire 
 Sweet Breath    Veggiemon   4       130     170    Earth
 Iga School KT   Ninjamon    4       150     170    Grapple
 Solar Ray       Centarumon  4       167     170    Air
 Electro Shocker Kabuterimon 4       170     170    Air 
 Meteor Wing     Birdramon   4       158     170    Fire 
 Hand of Fate    Angemon     4       166     170    Air
 Aerial Attack   Unimon      4       153     170    Air
 Hydro Pressure  Shellmon    5       155     165    Ice
 Ice Blast       Seadramon   5       162     165    Ice 
 Bone Boomerang  Mojyamon    5       148     165    Earth
 Blasting Spout  Whamon      5       150     165    Ice
 Party time      Numemon     6       100     150    Filth
 Party time      Sukamon     6       100     150    Filth
 Party time      Nanimon     6       100     150    Filth
 --------------------------------------------------------------------------
 Tech Name          Digimon     Range   OG.Pow  ModPow Element     Ultimate
 --------------------------------------------------------------------------
 Spiral Sword       Andromon      2       210     220  Mech
 Dark Network       Etemon        2       202     220  Grapple    * Note 2*
 Lovely Attack      Monzaemon     4       230     215  Grapple
 Abduction Beam     Vademon       4       222     215  Mech
 Smiley Bomb        Mamemon       4       225     215  Mech
 Deadly Bomb        Giromon       4       260     250  Mech       * Note 1*
 Energy Bomb        MetalMamon    4       214     215  Mech 
 Nightmare Syndrome Digitamamon   4       222     215  Fire
 Crimson Flare      Phoenixmon    4       213     215  Fire
 Mail Strome        MegaSeadram   4       211     215  Ice
 Hi-Electro Shocker H-Kabuterimon 4       218     215  Air 
 Glacial Blast      Panjyamon     4       ---     215  Ice
 Genoside Attack    Megadramon    5       215     210  Mech       * Note 2*
 Giga Scissor Claw  MetalGreym    5       215     210  Mech
 Dark Shot          Skull Grey    5       200     210  Mech
 Bit Bomb           Piximon       5       232     210  Earth 
 Infinity Cannon    Machinedramon 6       777     777  Mech 
 --------------------------------------------------------------------------
 
 * Giromon's Finish Tech acts very differently from others.
 
   It throws a bomb to the field, and it's not at all reliable.
   That's why is so powerful, it doesn't always work and you 
   tend to need to make so the foe actually touches it, thus 
   giving it extra power so it's less at a disadvantage.
 
 * Dark Network is also the finisher of MetalEtemon.
   Genocide Attack is also the finisher of Gigadramon.
   If wondering about Panjyamon, it basically has the same 
   as MegaSeadramon.   
 ---------------------------------------------------------------------------

 ----------------------------------------------------------------
 Learning Skills with Brain Training, Dr. Kawashima not included:
 ----------------------------------------------------------------
 The original game had rather low chances of being able to learn one attack 
 that the current species of your Digimon could learn from battles. This chance 
 could occur every time your Digimon's brain a multiple of 50. So 50, 100, 150 etc.
 
 Each attack is grouped in one of eight tiers, with each higher one having lower 
 chances. As mentioned, in the original game, the chances were super, super low.
 
 In this hack, chances are far more generous, to help with those cases where you 
 get limited opportunities to learn an attack from a boss, or unique fight.
 Oh, and the order of the Digimon types' makes no difference. If a digimon can 
 learn let's say, Tear Drop, it will have a 55% no matter the order. 
 
 There are 8 Tiers, each one contains one move of each type. I made earlier Tiers to 
 be much easier to learn as it can help a bit when starting out to get one extra Tech, 
 if they can learn it of course. 
 
 Chances    Techs:
             Fire        Air             Ice         Mech            Earth           Grapple     Filth
 ---------------------------------------------------------------------------------------------------------------
 80%      T1 Spit Fire   Static Elec     Tear Drop   Power Crane     Poison Claw     Sonic Jab   Horizontal Kick
 45%      T2 Heat Laser  Electric Cloud  Ice Needle  Metal Splinter  Danger Sting    Dynamite K. Odor Spray
 30%      T3 Fire Tower  Wind Cutter     Water Blit  Reverse Prog    Poison Powder   War Cry     Poop Spd Toss
 25%      T4 Magma Bomb  Spinning Shot   Aqua Magic  Pulse Laser     Insect Plague   Megaton Pn. Poop Rnd Toss 
 20%      T5 Red Inferno Megalo Spark    Winter Bl.  Full Potential  Mass Morph      Counter     Rnd Speed Toss 
 18%      T6 ProminenceB Confused Storm  Giga Freeze Delete Program  Charm Perfume   Muscle Chr. Big Poop Toss 
 15%      T7 Infinity B. Thunder Justice Ice Statue  All Range Beam  Green Trap      Tremor      Big Rnd Toss
 12%      T8 Meltdown    Hurricane       Aurora Fr.  DG Dimension    Bug             Buster Dive Ult. Poop Hell 
 ---------------------------------------------------------------------------------------------------------------
 

 And here, finally, is a list of which normal Techs each Digimon species 
 can learn. There are mostly the same, with only a handful of Digimon 
 having them changed (the three Ultimates that were made available, 
 and a couple of small other changes).
 
 Digimon are grouped by Evolution tier, and ordered alphabetically.
 

------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
							ROOKIES
------------------------------------------------------------------------------------
------------------------------------------------------------------------------------

Agumon: 
 Fire & Grapple:
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |        |   3    |   4    |   5    |   6    |        |        |
 |  Fire  |        |  Spit  |Red     |  Magma |  Heat  |        |        |
 |  Tower |        |  Fire  |Inferno |  Bomb  |  Laser |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |        |   2    |        |   4    |        |        |        |        |
 |        | Muscle |        | Sonic  |        |        |        |        |
 |        | Charge |        |  Jab   |        |        |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 
 
 Betamon: 
 Ice & Air: 
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |        |   3    |   4    |   5    |   6    |        |        |
 |  Giga  |        | Winter |  Ice   | Water  |  Aqua  |        |        |
 | Freeze |        |  Blast | Needle |  Blit  |  Magic |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |        |        |   3    |        |   5    |        |        |        |
 |        |        |Electric|        | Static |        |        |        |
 |        |        |  Cloud |        |  Elec. |        |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
  
  
 Biyomon: 
 Air & Fire: 
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |        |   2    |   3    |   4    |        |   6    |   7    |   8    |
 |        |Spinning|Electric| Megalo |        |  Wind  |Confused| Hurri- |
 |        |  Shot  |  Cloud | Spark  |        | Cutter |  Storm |  cane  |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |        |        |   3    |        |        |   6    |        |        |
 |        |        |  Spit  |        |        |  Heat  |        |        |
 |        |        |  Fire  |        |        |  Laser |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o


 Elecmon: 
 Air & Grapple: 
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |        |        |   3    |   4    |   5    |   6    |        |        |
 |        |        |Electric| Megalo | Static |  Wind  |        |        |
 |        |        |  Cloud | Spark  |  Elec. | Cutter |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |        |   2    |        |        |   5    |   6    |        |        |
 |        | Muscle |        |        |Dynamite| Counter|        |        |
 |        | Charge |        |        |  Kick  |        |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 
 Palmon:
 Earth & Ice: 
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Poison |        |  Mass  |        | Charm  | Poison |        |        |
 | Powder |        | Morph  |        | Perfume|  Claw  |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |        |        |        | Water  |  Aqua  |        |  Tear  |
 |        |        |        |        |  Blit  |  Magic |        |  Drop  |
 O--------o--------o--------o--------o--------o-----------------o--------o

 Gabumon:  
 Grapple & Ice:
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Tremor |        |  War   | Sonic  |Dynamite|        |Metaton | Buster |
 |        |        |   Cry  |  Jab   |  Kick  |        | Punch  |  Dive  |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |        | Winter |  Ice   |        |        |        |        |
 |        |        |  Blast | Needle |        |        |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o

 Kunemon: 
 Earth & Air: 
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |        |  Mass  | Insect | Charm  |        |        |        |
 |        |        | Morph  | Plague | Perfume|  Claw  |  Sting |  Trap  |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Thunder|        |Electric|        |        |  Wind  |Confused|        |
 | Justice|        |  Cloud |        |        | Cutter |  Storm |        |
 O--------o--------o--------o--------o--------o-----------------o--------o


 Patamon: 
 Grapple & Air:
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |        |  War   | Sonic  |Dynamite|        |        | Buster |
 |        |        |   Cry  |  Jab   |  Kick  |        |        |  Dive  |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |Spinning|        |        |        |  Wind  |Confused|        |
 |        |  Shot  |        |        |        | Cutter |  Storm |        |
 O--------o--------o--------o--------o--------o-----------------o--------o


 Penguinmon:
 Ice & Earth: 
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |  Giga  |        | Winter |  Ice   | Water  |  Aqua  |        |        |
 | Freeze |        |  Blast | Needle |  Blit  |  Magic |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |        |        |        | Charm  | Poison |        |        |
 |        |        |        |        | Perfume|  Claw  |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o

------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
								CHAMPIONS
------------------------------------------------------------------------------------
------------------------------------------------------------------------------------

Airdramon:
 Fire & Air: 
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |Promin. |  Spit  |        |        |  Heat  |        |        |
 |        |  Beam  |  Fire  |        |        |  Laser |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |Spinning|Electric| Megalo | Static |  Wind  |Confused| Hurri- |
 |        |  Shot  |  Cloud | Spark  |  Elec. | Cutter |  Storm |  cane  |
 O--------o--------o--------o--------o--------o-----------------o--------o

Angemon:
 Grapple & Air:
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        | Muscle |        |        |Dynamite| Counter|        |        |
 |        | Charge |        |        |  Kick  |        |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |Spinning|Electric| Megalo | Static |  Wind  |Confused| Hurri- |
 |        |  Shot  |  Cloud | Spark  |  Elec. | Cutter |  Storm |  cane  |
 O--------o--------o--------o--------o--------o-----------------o--------o

Bakemon:
 Air & Ice: 
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Thunder|Spinning|Electric| Megalo | Static |  Wind  |        | Hurri- |
 | Justice|  Shot  |  Cloud | Spark  |  Elec. | Cutter |        |  cane  |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |  Giga  |        | Winter |        |        |  Aqua  |        |        |
 | Freeze |        |  Blast |        |        |  Magic |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o

Birdramon:
 Fire & Air: 
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |  Fire  |Promin. |  Spit  |Red     |  Magma |  Heat  |        |Meltdown|
 |  Tower |  Beam  |  Fire  |Inferno |  Bomb  |  Laser |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |Spinning|        |        |        |  Wind  |        | Hurri- |
 |        |  Shot  |        |        |        | Cutter |        |  cane  |
 O--------o--------o--------o--------o--------o-----------------o--------o

Centarumon:
 Fire & Grapple: 
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |  Fire  |Promin. |  Spit  |Red     |  Magma |  Heat  |        |Meltdown|
 |  Tower |  Beam  |  Fire  |Inferno |  Bomb  |  Laser |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        | Muscle |        |        |Dynamite| Counter|        |        |
 |        | Charge |        |        |  Kick  |        |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o

Coelamon:
 Earth & Ice: 
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |        |        | Insect |        | Poison | Danger |        |
 |        |        |        | Plague |        |  Claw  |  Sting |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |  Giga  |  Ice   | Winter |  Ice   | Water  |  Aqua  |        |  Tear  |
 | Freeze | Statue |  Blast | Needle |  Blit  |  Magic |        |  Drop  |
 O--------o--------o--------o--------o--------o-----------------o--------o

Devimon:
 Grapple, Air & Ice:
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        | Muscle |  War   | Sonic  |        | Counter|Metaton | Buster |
 |        | Charge |   Cry  |  Jab   |        |        | Punch  |  Dive  |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Thunder|Spinning|Electric| Megalo |        |        |        |        |
 | Justice|  Shot  |  Cloud | Spark  |        |        |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |  Giga  |  Ice   |        |        |        |        |        |        |
 | Freeze | Statue |        |        |        |        |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o

Drimogemon:
 Grapple & Earth:
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Tremor | Muscle |  War   | Sonic  |Dynamite| Counter|Metaton | Buster |
 |        | Charge |   Cry  |  Jab   |  Kick  |        | Punch  |  Dive  |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |        |        |        | Charm  |        |        | Green  |
 |        |        |        |        | Perfume|        |        |  Trap  |
 O--------o--------o--------o--------o--------o-----------------o--------o

Frigimon:
 Ice & Grapple: 
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |  Giga  |  Ice   | Winter |  Ice   | Water  |  Aqua  | Aurora |  Tear  |
 | Freeze | Statue |  Blast | Needle |  Blit  |  Magic | Freeze |  Drop  |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        | Muscle |        | Sonic  |        |        |        |        |
 |        | Charge |        |  Jab   |        |        |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o

 
Garurumon:
 Ice, Fire & Grapple: 
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |  Giga  |  Ice   | Winter |  Ice   |        |  Aqua  |        |        |
 | Freeze | Statue |  Blast | Needle |        |  Magic |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |  Fire  |        |  Spit  |        |  Magma |        |        |        |
 |  Tower |        |  Fire  |        |  Bomb  |        |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |        |  War   |        |        |        |Metaton | Buster |
 |        |        |   Cry  |        |        |        | Punch  |  Dive  |
 O--------o--------o--------o--------o--------o-----------------o--------o
 
Greymon:
 Fire, Grapple & Air: 
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |  Fire  |Promin. |  Spit  |Red     |  Magma |  Heat  |Infinity|Meltdown|
 |  Tower |  Beam  |  Fire  |Inferno |  Bomb  |  Laser |  Burn  |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        | Muscle |        |        |Dynamite| Counter|        |        |
 |        | Charge |        |        |  Kick  |        |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |Spinning|        | Megalo |        |        |        |        |
 |        |  Shot  |        | Spark  |        |        |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o

Kabuterimon:
 Earth, Fire & Air: 
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Poison |        |  Mass  | Insect | Charm  | Poison | Danger | Green  |
 | Powder |        | Morph  | Plague | Perfume|  Claw  |  Sting |  Trap  |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |Promin. |  Spit  |Red     |        |        |        |        |
 |        |  Beam  |  Fire  |Inferno |        |        |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |        |        |        |        |  Wind  |        | Hurri- |
 |        |        |        |        |        | Cutter |        |  cane  |
 O--------o--------o--------o--------o--------o-----------------o--------o
 
Kokatorimon:
 Air & Grapple: 
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Thunder|Spinning|Electric| Megalo | Static |  Wind  |Confused| Hurri- |
 | Justice|  Shot  |  Cloud | Spark  |  Elec. | Cutter |  Storm |  cane  |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Tremor |        |  War   |        |Dynamite|        |        |        |
 |        |        |   Cry  |        |  Kick  |        |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 
Kuwagamon:
 Earth, Grapple & Air: 
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Poison |        |  Mass  |        | Charm  | Poison | Danger | Green  |
 | Powder |        | Morph  |        | Perfume|  Claw  |  Sting |  Trap  |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        | Muscle |        | Sonic  |        |        |        |        |
 |        | Charge |        |  Jab   |        |        |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |Spinning|        |        |        |  Wind  |        |        |
 |        |  Shot  |        |        |        | Cutter |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o

Leomon:
 Grapple:
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Tremor | Muscle |  War   | Sonic  |Dynamite| Counter|Metaton | Buster |
 |        | Charge |   Cry  |  Jab   |  Kick  |        | Punch  |  Dive  |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |        |        | Megalo | Static |        |        |        |
 |        |        |        | Spark  |  Elec. |        |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o

Meramon:
 Fire & Grapple: 
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |  Fire  |Promin. |  Spit  |Red     |  Magma |  Heat  |Infinity|        |
 |  Tower |  Beam  |  Fire  |Inferno |  Bomb  |  Laser |  Burn  |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |        |  War   |        |Dynamite| Counter|        |        |
 |        |        |   Cry  |        |  Kick  |        |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 
Mojyamon:
 Ice, Grapple & Earth: 
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |  Giga  |        | Winter |  Ice   | Water  |  Aqua  | Aurora |        |
 | Freeze |        |  Blast | Needle |  Blit  |  Magic | Freeze |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |        |        |        |Dynamite|        |Metaton |        |
 |        |        |        |        |  Kick  |        | Punch  |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |        |  Mass  |        |        |        |        | Green  |
 |        |        | Morph  |        |        |        |        |  Trap  |
 O--------o--------o--------o--------o--------o-----------------o--------o

Monochromon:
 Grapple, Fire & Earth:
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        | Muscle |  War   | Sonic  |        | Counter|        | Buster |
 |        | Charge |   Cry  |  Jab   |        |        |        |  Dive  |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |  Fire  |        |        |        |        |  Heat  |Infinity|        |
 |  Tower |        |        |        |        |  Laser |  Burn  |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |        |  Mass  | Insect |        |        |        | Green  |
 |        |        | Morph  | Plague |        |        |        |  Trap  |
 O--------o--------o--------o--------o--------o-----------------o--------o
 
Nanimon:
 Filth & Grapple: 
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |  Odor  |Poop Spd|Big Poop|Big Rnd |Poop Rnd| Random |Horizon.|        |
 |  Spray |  Toss  |  Toss  |  Toss  |  Toss  |Spd Toss|  Kick  |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |        |        |        |Dynamite| Counter|Metaton |        |
 |        |        |        |        |  Kick  |        | Punch  |        |
 O--------o--------o--------o--------o--------o-----------------o--------o

Ninjamon:
 Earth, Grapple & Fire: 
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Poison |        |  Mass  |        | Charm  |        | Danger |        |
 | Powder |        | Morph  |        | Perfume|        |  Sting |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |        |  War   | Sonic  |Dynamite| Counter|        |        |
 |        |        |   Cry  |  Jab   |  Kick  |        |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |  Fire  |        |        |        |  Magma |        |        |        |
 |  Tower |        |        |        |  Bomb  |        |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 
Numemon
 Filth: 
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |  Odor  |Poop Spd|Big Poop|Big Rnd |Poop Rnd| Random |Horizon.|Ult.Poop|
 |  Spray |  Toss  |  Toss  |  Toss  |  Toss  |Spd Toss|  Kick  |  Hell  |
 O--------o--------o--------o--------o--------o-----------------o--------o
 

Ogremon:
 Grapple, Fire & Earth:
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Tremor |        |  War   | Sonic  |Dynamite|        |Metaton | Buster |
 |        |        |   Cry  |  Jab   |  Kick  |        | Punch  |  Dive  |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |        |  Spit  |Red     |  Magma |        |        |        |
 |        |        |  Fire  |Inferno |  Bomb  |        |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |        |        | Insect |        | Poison |        |        |
 |        |        |        | Plague |        |  Claw  |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o

Seadramon:
 Ice, Earth & Fire: 
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |  Giga  |        | Winter |  Ice   | Water  |  Aqua  |        |  Tear  |
 | Freeze |        |  Blast | Needle |  Blit  |  Magic |        |  Drop  |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Poison |        |        |        | Charm  |        | Danger |        |
 | Powder |        |        |        | Perfume|        |  Sting |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |        |  Spit  |        |  Magma |        |        |        |
 |        |        |  Fire  |        |  Bomb  |        |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o

Shellmon:
 Ice & Earth: 
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |  Giga  |  Ice   | Winter |  Ice   | Water  |  Aqua  | Aurora |  Tear  |
 | Freeze | Statue |  Blast | Needle |  Blit  |  Magic | Freeze |  Drop  |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Poison |        |        |        | Charm  |        |        |        |
 | Powder |        |        |        | Perfume|        |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o

Sukamon:
 Filth: 
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |  Odor  |Poop Spd|Big Poop|Big Rnd |Poop Rnd| Random |Horizon.|Ult.Poop|
 |  Spray |  Toss  |  Toss  |  Toss  |  Toss  |Spd Toss|  Kick  |  Hell  |
 O--------o--------o--------o--------o--------o-----------------o--------o
 

Tyrannomon:
 Grapple & Fire:
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Tremor | Muscle |  War   | Sonic  |Dynamite| Counter|Metaton | Buster |
 |        | Charge |   Cry  |  Jab   |  Kick  |        | Punch  |  Dive  |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |Promin. |  Spit  |        |  Magma |        |        |        |
 |        |  Beam  |  Fire  |        |  Bomb  |        |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o

Unimon:
 Air & Grapple: 
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |Spinning|Electric| Megalo | Static |  Wind  |Confused| Hurri- |
 |        |  Shot  |  Cloud | Spark  |  Elec. | Cutter |  Storm |  cane  |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |        |  War   |        |Dynamite| Counter|        |        |
 |        |        |   Cry  |        |  Kick  |        |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o

Vegiemon:
 Earth & Ice: 
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Poison |        |  Mass  |        | Charm  | Poison | Danger | Green  |
 | Powder |        | Morph  |        | Perfume|  Claw  |  Sting |  Trap  |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |        |        |        | Water  |  Aqua  |        |        |
 |        |        |        |        |  Blit  |  Magic |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o

Whamon:
 Ice & Earth: 
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |  Giga  |  Ice   | Winter |  Ice   | Water  |  Aqua  | Aurora |  Tear  |
 | Freeze | Statue |  Blast | Needle |  Blit  |  Magic | Freeze |  Drop  |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Poison |        |        |        | Charm  |        |        |        |
 | Powder |        |        |        | Perfume|        |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o

------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
									ULTIMATES
------------------------------------------------------------------------------------
------------------------------------------------------------------------------------

Andromon 
Battle, Air & Mech:
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Tremor |        |        |        |        | Counter|Metaton | Buster |
 |        |        |        |        |        |        | Punch  |  Dive  |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |        |        | Megalo | Static |        |        |        |
 |        |        |        | Spark  |  Elec. |        |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Power  |All Rng.| Metal  | Pulse  | Delete |DG Dime-|Full    |Reverse |
 | Crane  |  Beam  |Splinter| Laser  | Program| -sion  |Potent. |   Prog |
 O--------o--------o--------o--------o--------o-----------------o--------o

Digitamamon
 Fire, Air & Ice: 
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |  Fire  |Promin. |  Spit  |Red     |  Magma |  Heat  |Infinity|Meltdown|
 |  Tower |  Beam  |  Fire  |Inferno |  Bomb  |  Laser |  Burn  |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Thunder|Spinning|        | Megalo |        |        |Confused| Hurri- |
 | Justice|  Shot  |        | Spark  |        |        |  Storm |  cane  |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |        |        |        |        |  Aqua  |        |  Tear  |
 |        |        |        |        |        |  Magic |        |  Drop  |
 O--------o--------o--------o--------o--------o-----------------o--------o
 
Etemon
Grapple, Air & Filth:
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Tremor | Muscle |  War   | Sonic  |Dynamite| Counter|Metaton | Buster |
 |        | Charge |   Cry  |  Jab   |  Kick  |        | Punch  |  Dive  |
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Thunder|Spinning|        |        |        |  Wind  |        |        |
 | Justice|  Shot  |        |        |        | Cutter |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |        |        |        |        |        |        |Ult.Poop|
 |        |        |        |        |        |        |        |  Hell  |
 O--------o--------o--------o--------o--------o-----------------o--------o

Gigadramon
Mech, Earth & Battle:
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |        |        |        |Dynamite|        |Metaton |        |
 |        |        |        |        |  Kick  |        | Punch  |        |
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Poison |        |        | Insect |        |        | Danger |        |
 | Powder |        |        | Plague |        |        |  Sting |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Power  |All Rng.| Metal  | Pulse  | Delete |DG Dime-|Full    |Reverse |
 | Crane  |  Beam  |Splinter| Laser  | Program| -sion  |Potent. |   Prog |
 O--------o--------o--------o--------o--------o-----------------o--------o

Giromon	
Grapple, Air & Mech:
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |        |        |        |        |        |Metaton | Buster |
 |        |        |        |        |        |        | Punch  |  Dive  |
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Thunder|        |Electric| Megalo |        |        |        |        |
 | Justice|        |  Cloud | Spark  |        |        |        |        |
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Power  |All Rng.| Metal  | Pulse  | Delete |DG Dime-|Full    |Reverse |
 | Crane  |  Beam  |Splinter| Laser  | Program| -sion  |Potent. |   Prog |
 O--------o--------o--------o--------o--------o-----------------o--------o
 
H-Kabuterimon
Fire, Battle & Earth:
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |Promin. |        |Red     |        |        |        |        |
 |        |  Beam  |        |Inferno |        |        |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        | Muscle |        |        |        | Counter|Metaton | Buster |
 |        | Charge |        |        |        |        | Punch  |  Dive  |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Poison |  Bug   |  Mass  | Insect | Charm  | Poison | Danger | Green  |
 | Powder |        | Morph  | Plague | Perfume|  Claw  |  Sting |  Trap  |
 O--------o--------o--------o--------o--------o-----------------o--------o
 
Mamemon
Grapple & Mech:
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Tremor | Muscle |  War   | Sonic  |Dynamite| Counter|Metaton | Buster |
 |        | Charge |   Cry  |  Jab   |  Kick  |        | Punch  |  Dive  |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Power  |        | Metal  | Pulse  |        |        |Full    |Reverse |
 | Crane  |        |Splinter| Laser  |        |       |Potent. |   Prog |
 O--------o--------o--------o--------o--------o-----------------o--------o
 
Megadramon
 Grapple, Ice & Mech:
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |        |        |        |Dynamite|        |Metaton |        |
 |        |        |        |        |  Kick  |        | Punch  |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |  Giga  |  Ice   | Winter |        |        |        |        |        |
 | Freeze | Statue |  Blast |        |        |        |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Power  |All Rng.| Metal  | Pulse  | Delete |DG Dime-|Full    |Reverse |
 | Crane  |  Beam  |Splinter| Laser  | Program| -sion  |Potent. |   Prog |
 O--------o--------o--------o--------o--------o-----------------o--------o
 
Megaseadramon
 Air & Ice: 
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |        |        |        |        |  Wind  |Confused| Hurri- |
 |        |        |        |        |        | Cutter |  Storm |  cane  |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |  Giga  |  Ice   | Winter |  Ice   | Water  |  Aqua  | Aurora |  Tear  |
 | Freeze | Statue |  Blast | Needle |  Blit  |  Magic | Freeze |  Drop  |
 O--------o--------o--------o--------o--------o-----------------o--------o

MetalEtemon 
Grapple, Fire & Air:
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Tremor | Muscle |  War   |        |Dynamite| Counter|Megaton | Buster |
 |        | Charge |   Cry  |        |  Kick  |        | Punch  |  Dive  |
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |Promin. |  Spit  |Red     |  Magma |        |        |        |
 |        |  Beam  |  Fire  |Inferno |  Bomb  |        |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Thunder|        | Megalo |        |        |        |        |        |
 | Justice|        |  Spark |        |        |        |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o

MetalGreymon
 Fire, Grapple & Mech: 
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |        |        |        |        |  Heat  |Infinity|Meltdown|
 |        |        |        |        |        |  Laser |  Burn  |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Tremor |        |        |        |        |        |Metaton | Buster |
 |        |        |        |        |        |        | Punch  |  Dive  |
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Power  |All Rng.| Metal  | Pulse  | Delete |DG Dime-|Full    |Reverse |
 | Crane  |  Beam  |Splinter| Laser  | Program| -sion  |Potent. |   Prog |
 O--------o--------o--------o--------o--------o-----------------o--------o
 
MetalMamemon
 Grapple & Mech:
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Tremor |        |  War   | Sonic  |Dynamite| Counter|Metaton |        |
 |        |        |   Cry  |  Jab   |  Kick  |        | Punch  |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |All Rng.| Metal  | Pulse  | Delete |        |        |Reverse |
 |        |  Beam  |Splinter| Laser  | Program|        |        |   Prog |
 O--------o--------o--------o--------o--------o-----------------o--------o
 
 
Monzaemon
Grapple & Air:
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Tremor | Muscle |  War   | Sonic  |Dynamite| Counter|Megaton | Buster |
 |        | Charge |   Cry  |  Jab   |  Kick  |        | Punch  |  Dive  |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Thunder|        |Electric| Megalo | Static |        |Confused|        |
 | Justice|        |  Cloud | Spark  |  Elec. |        |  Storm |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 
Panjyamon
Grapple, Ice & Air:
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Tremor | Muscle |        |        |Dynamite| Counter|        | Buster |
 |        | Charge |        |        |  Kick  |        |        |  Dive  |
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |  Giga  |  Ice   |        |        |        |        | Aurora |        |
 | Freeze | Statue |        |        |        |        | Freeze |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |Spinning|        | Megalo |        |        |        |        |
 |        |  Shot  |        | Spark  |        |        |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 
Phoenixmon
Air & Fire:
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |Promin. |        |Red     |  Magma |        |        |Meltdown|
 |        |  Beam  |        |Inferno |  Bomb  |        |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Thunder|Spinning|Electric| Megalo | Static |  Wind  |Confused| Hurri- |
 | Justice|  Shot  |  Cloud | Spark  |  Elec. | Cutter |  Storm |  cane  |
 O--------o--------o--------o--------o--------o-----------------o--------o

Piximon
 Air & Earth: 
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |Spinning|        |        |        |  Wind  |Confused| Hurri- |
 |        |  Shot  |        |        |        | Cutter |  Storm |  cane  |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Poison |  Bug   |  Mass  | Insect | Charm  | Poison | Danger | Green  |
 | Powder |        | Morph  | Plague | Perfume|  Claw  |  Sting |  Trap  |
 O--------o--------o--------o--------o--------o-----------------o--------o
 
SkullGreymon
Grapple, Ice & Mech:
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Tremor | Muscle |  War   | Sonic  |Dynamite| Counter|Metaton | Buster |
 |        | Charge |   Cry  |  Jab   |  Kick  |        | Punch  |  Dive  |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |  Giga  |  Ice   | Winter |        |        |        |        |        |
 | Freeze | Statue |  Blast |        |        |        |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |All Rng.|        | Pulse  |        |        |        |        |
 |        |  Beam  |        | Laser  |        |        |        |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 
Vademon
 Earth & Mech: 
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |        |  Bug   |        |        | Charm  |        |        | Green  |
 |        |        |        |        | Perfume|        |        |  Trap  |
 O--------o--------o--------o--------o--------o-----------------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Power  |All Rng.| Metal  | Pulse  | Delete |DG Dime-|Full    |Reverse |
 | Crane  |  Beam  |Splinter| Laser  | Program| -sion  |Potent. |   Prog |
 O--------o--------o--------o--------o--------o-----------------o--------o


------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
 
 
 Fire: 
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |  Fire  |Promin. |  Spit  |Red     |  Magma |  Heat  |Infinity|Meltdown|
 |  Tower |  Beam  |  Fire  |Inferno |  Bomb  |  Laser |  Burn  |        |
 O--------o--------o--------o--------o--------o-----------------o--------o
 
 Air: 
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Thunder|Spinning|Electric| Megalo | Static |  Wind  |Confused| Hurri- |
 | Justice|  Shot  |  Cloud | Spark  |  Elec. | Cutter |  Storm |  cane  |
 O--------o--------o--------o--------o--------o-----------------o--------o
 
 Ice: 
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |  Giga  |  Ice   | Winter |  Ice   | Water  |  Aqua  | Aurora |  Tear  |
 | Freeze | Statue |  Blast | Needle |  Blit  |  Magic | Freeze |  Drop  |
 O--------o--------o--------o--------o--------o-----------------o--------o
 
 Mech:
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Power  |All Rng.| Metal  | Pulse  | Delete |DG Dime-|Full    |Reverse |
 | Crane  |  Beam  |Splinter| Laser  | Program| -sion  |Potent. |   Prog |
 O--------o--------o--------o--------o--------o-----------------o--------o

 Earth: 
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Poison |  Bug   |  Mass  | Insect | Charm  | Poison | Danger | Green  |
 | Powder |        | Morph  | Plague | Perfume|  Claw  |  Sting |  Trap  |
 O--------o--------o--------o--------o--------o-----------------o--------o
 
 Grapple:
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 | Tremor | Muscle |  War   | Sonic  |Dynamite| Counter|Metaton | Buster |
 |        | Charge |   Cry  |  Jab   |  Kick  |        | Punch  |  Dive  |
 O--------o--------o--------o--------o--------o-----------------o--------o
 
 Filth: 
 o--------o--------o--------o--------o--------o--------o--------o--------o
 |   1    |   2    |   3    |   4    |   5    |   6    |   7    |   8    |
 |  Odor  |Poop Spd|Big Poop|Big Rnd |Poop Rnd| Random |Horizon.|Ult.Poop|
 |  Spray |  Toss  |  Toss  |  Toss  |  Toss  |Spd Toss|  Kick  |  Hell  |
 O--------o--------o--------o--------o--------o-----------------o--------o


	--------------------
	S007 - Other Changes
	--------------------

 Here's a nother list of changes that wouldn't fit on other sections.
 
 1: The Stats of many enemy Digimon have been tweaked here and there. Overall, 
    they're a bit higher depending on the area, specially Brains and Speed, which 
	were very low overall. For the most part there were increases all around, but 
	a few were actually nerfed, like the SnowAgumon and SnowGoburimon, which were 
	practically the same as the Champions of that same area. 
	
	There were some changes to Bosses too. For example, in the original Birdramon 
	only has one Tech, now it has three. Devimon doesn't have two stat-raising 
	Techs that would spam and give you ample time to slap it to the ground.
	
	Greymon was also made weaker and more appropied for the early moments of the game 
	where it appears. Its stats were actually a bit higher than Airdramon, who you 
	fight much, much later on the same conditions, making the power of Greymon way 
	too high and weird.
	
	With the changes in Techs, the Offense of several Digimon were made a bit lower, 
	as the raise in Tech Power covers their loss. Enemies in the Back Dimension were 
	made slightly harder too, but with a very strong Digimon you have not much to fear.
	
 2:	Alongside the above, the Bits provided by battling have been raised significantly, 
	as in the original game, they provided very paltry amounts, that more often 
	than not forced players to use exploits to get money. 
	
	Things should flow much better in this regard, being able to buy stuff and even 
	being able to save up money as you explore. 
	
 3:	Not just the Bits, enemy drops were also changed and made more common. 
    Fighting in the Native forest for example will reward you recovery Items more often, 
	Items like Speed Leaf and such are also a bit more common, which then can be used 
	for your Digimon or for Fishing.
	
	Some important changes in drops are that Geremon now drops Smelly Rings, and that 
	Sukamon drop the Ugly Mirror, both are evolutionary Items. The Enemy Bell and 
	Enemy Repel can also be obtained earlier as they're now dropped by Digimon that 
	can be encountered much sooner.
	
 4: Item spawns in maps have been overhauled. It's no secret that the vast majority 
    of items spawned during the adventure are just Digishrooms and little else. Now 
	there's a much higher variety of items lying around, and the chances of them 
	appearing have also been tweaked to be a bit higher. Not enough for them to be 
	easy to farm, of course, but high enough so they happen more often by playing 
	casually. So pay attention as you travel!
	
 5: Some price changes, but most importantly, changes in the ShogunGekkomon point shop.
    In the original game the prices are absurd, and with how slow is to get points, they 
	were barely used, not to mention Evolution Items weren't very useful (also changed).
	
 6: Did you know that Piximon, Mamemon and MetalMamemon only have a measly 3% chance 
    to appear each time you walk into their area in the original game?

    I have increased them from 3% to 33% so players don't have to waste their time 
	to the extents the original game basically forced us to do. 

 7: When starting out, if you speak with Tokomon, it will give you a few items. 
    In this hack Tokomon provides you a few extra more, to help starting out. 
	More meat, more recovery Items including two to revive your Digimon, etc. 

 8: When evolving into Numemon, your Digimon receives a penalty in your Stats. 
    This happens in the original game, and here too, but the penalty itself has
	been softened. Numemon only loses 10% of its Stats instead of 20%.
	
	I wanted Sukamon to also have lesser penalty, but because there's a way to 
	abuse it, I decided to keep the 50% penalty in Stats. Nanimon has none.
	
 9: In the original game, the rewarded Happiness and Discipline points for taking your 
    Digimon to the bathroom when it needed it were very low if compared to the penalties 
	the game gives you if you couldn't reach it. I raised the points given a bit. 

10: A large number of text changes to improve or fix certain things where it was possible. 
    I could not do everything as the text can be rather fragile, and the game is a mess 
	in this regard (well, in most).

    Examples of changes are:	
	
	Completing and improving many, many lines like Myotismon "research" that were both poorly 
	written and more importantly unfinished or cut off before they ended, fixing many typos, 
	correcting several wrong statements about mechanics or rewording stuff to reflect how it 
	works in my hack, making certain choices make more sense, improve many of the text wierdness 
	like how poorly the text related to buying cards is, or the insistence of writting numbers 
	with letters, making parsing text a chore. For example, writing "Four hund and fifty" instead 
	of just displaying "450" in moments where writing it as a number would be faster and simpler.	
	
	For example, on some shops, or during the Monochromon Minigame, which were very messy, 
	specially since after a sale you would get your current profit in numbers and the Bits 
	you just made in letters.
	
	Other things like improving the descriptions for tournaments were also made.
	Just have in mind that it is NOT a retranslation by any means, just trying to fix what 
	I could without breaking stuff, which is very easy to do.

    And I still want to leave the weird feeling of the translation that the game 
	has, it is part of the charm and alien vibes the game always gave to me. 
	
	I wouldn't touch lines as "He ruined my research with evil" because they are 
	objectively perfect in every way.

11: Kinda pointless but the MP restoration machine in Tropical Jungle is actually useful now!
   
    In the original game, it restored an underwhelming 100 MP for 200 Bits, which I will never 
    understand why it was decided to make as an option, or 1000 for 1800 Bits, which is better 
	but not that high.
	
	Now it recovers 1000 MP for 800 Bits, or 2000 for 1600 Bits. Of course, it's so close to 
	the city that it's use isn't going to become vital, but even when I was a kid the first option 
	made me go "Why?!" every time I went through that area.
	
12: Resting on Jijimon's couch or Centarumon's Clinic has been improved.

    In the original game, they healed 300 HP/MP and 500 HP/MP respectively, which are very, very 
	low values from the very beginning, specially the Clinic. There's no way to heal your Digimon 
	without the constant use of Items outside of Sleeping, which can only be done once per day, 
	and depends on each sleep cycle. And with powerful Digimon, it could take many hours to heal 
	up through these methods, making Item spamming more convenient. 
	
	Now they heal 1000 HP/MP and 2000 HP/MP respectively. Because you can only rest on the city, 
	I don't think being able to recover decently by resting is going to break any balance, and will 
	help a lot early on. 
	
	The Tiredness recovery is still the same though, 10 and 20. Changing that would totally make 
	for more abusable training, which I don't really want to happen, you already are given a 
	bunch of things, from Items and Gym upgrades that raise the stat gains, to food that 
	lowers Tiredness and such. 

    You lose the possibility to heal on Jijimon's House after it is remodeled. I don't know if 
	you can sleep on the bed, I tried but I couldn't and cannot remember if I did as a kid. 

13: Monochromon's Minigame is less annoying. 

    Something I should have thought of before, I feel. Based on feedback, it's true that the shop 
	minigame to recruit Monochromon is too based on luck, and often you simply had no chance to 
	get all the Bits necessary because the game wouldn't let you sell the Items that were... Well, 
	actually valuable. 
	
	The amount of money went down from 3072 Bits down to 2048, which is much more fair, and you 
	don't require the level of luck than before, where you wished for medicines all the time. 
	In my tests I was able to get to over 2048 even blowing up every attemp to sell a medicine.
	
	I hope this helps making the minigame more fun...
	
	If you're asking yourself why such random amounts, and not a rounded number that has to do with 
	the fact that the game doesn't look for a specific value written as is, but it writes 256 and 
	then multiplies it by another number, and the resulting amount is the goal to reach.
	
	The original game basically did G=N+(N*11) calculation, where N is 256, so it's 256 + (256 * 11).
	
	256 + 2816 = 3072 which is the Goal. In any case, there's a patch to restore the original goal, 
	if for some reason someone wants it. Personally I never hated this minigame, even if sometimes 
	made me mad for losing when I needed less than 100 Bits to pass, but I concede that it's very 
	luck oriented. 
	
	---------------------
	S008 - Glitches Fixed
	---------------------
	
 Most of the work done here was by Vice04, which did a masterful and very tedious work 
 trying to make sense of the, sometimes, baffling ways the developers coded the game. 
 
 Digimon World is a rather messy game, with many mistakes here and there, and in part 
 I can forgive as the game is, at least to me, a rather complex game with lots of 
 moving parts that act together all the time, with time passing, having to constantly 
 check for events to happen and such.

 But a number of the most egregorious bugs that could hurt the player have been 
 taken care of. This results in much less worry and more joy playing.

 You can find Vice04's documentation here, compiled after we were messing around 
 with the game: 
 
 https://github.com/Vicen04/Dw1DataAndPatches
 
 In particular, he has made a wiki where you can read about each glitch too:
 
 https://github.com/Vicen04/Dw1DataAndPatches/wiki

 Here's a list of all Glitches fixed:
 
 
 1, Tanemon Glitch:
 ------------------
 If Tanemon had Offense as it highest stat, it would not evolve. The problem 
 was that instead of Offense, it was given MP as an evolution requirement, 
 which Betamon already had. Now both Betamon and Palmon look for different 
 Stats to evolve. 
 
 
 2, MP Bonus Glitch:
 -------------------
 When you achieved a Brains stat of 700, 800, 900 and 999 during battles, 
 the game would try to inform you that your Digimon got a small reduction 
 in the MP cost of Techs, but it was so poorly made that it would softlock you. 
 
 Now it works, making the occurrence of reaching said stats through battle 
 a non issue. I also improved the descriptions of commands if learnt during 
 battle to make them less confusing. 
 
 3, Obnoxious Enemy spawn:
 -------------------------
 Do you remember all those times where you flew with Birdramon, only to spawn right 
 next to an enemy and have it go to you start a battle, before you could react because 
 the screen was still black, like for example in Freeze Land? 
 
 Or those other times where moving from one screen to the other had you put right next 
 to an enemy and was basically impossible to avoid unless you knew already that could 
 happen, like in two different points in Ancient Dino Region, or trying to go the Recycle 
 Shop in Gear Savannah?

 Well, I improved a number of those occurrences by moving enemies a bit away from where you 
 would appear. Just have in mind that, sometimes, the game seems to be intentionally made 
 that way, like the DarkRizamon in Overdell designed to chase you when you come from the 
 screen below or the two Goburimon rushing towards you in that one area in the Spore forest.
 
 4, Hunger Math Error: Fixed by Vice04
 -------------------------------------
 This is a very common glitch in which Digimon with sleep schedules that would 
 have them sleep through the change to another day (so, sleep through hour 00:00)
 would have their Hunger times skipped by an entire day. Because of this, they 
 would not eat until the next day, so they'll lose all their Energy, and their 
 Weight will be dropping alarmingly fast. Not just that, but Happiness and 
 Discipline wouldn't raise as high because you're not feeding your Digimon 
 and not getting those bonuses either.
 
 5, Battle Daily Events skip: Fixed by Vice04
 --------------------------------------------
 If you battled between 23:40 to 23:59 and skipped to the next day through battle, 
 with battles taking 20 ingame minutes (so 20 real seconds) the game wouldn't count 
 it as the next day for many events, such as being able to get Meat, your Digimon 
 age woulnd't progress, and other daily events wouldn't happen either. 
 
 Another effect is that, outside of the day-skipping problem, it would not let 
 hours to pass, so your Digimon couldn't evolve either, as the countdown wouldn't 
 well, go down. 
 
 It was a very annoying glitch, and now time flows as it's supposed to, so you have 
 no longer to fear battling at any time. 
 
 6, Rest Pillow Glitch: Fixed by Vice04
 --------------------------------------
 If you were to sleep with the Rest Pillow in your inventory and your Digimon had 
 close to full HP and MP, there would be a rollover glitch in which you'd be left 
 with very wonky values. 
 
 It was fixed by Vice04 by reworking the entire thing. Now you can use it without 
 fearing any issue. 
 
 7, Tech loss upon death: Fixed by Vice04
 ----------------------------------------
 When your Digimon loses all three lives, it will be reborn, with a hit in the Stats 
 it carries to the next life, and will also forget a number of Techs based on how many 
 it knows, regardless of it can use them or not. 
 
 Well, there's one horrifying glitch here. If you lose a Tech of a specific type, it will 
 make you potentially lose ALL the Techs you know of another specific type. This happens 
 on several ways, so you could lose dozens of Techs in one single death. 
 
 8, Sukamon's evolution stat gain glitch: Fixed by Vice04
 --------------------------------------------------------
 Turns out that there was one last laugh to those that would get a Sukamon. If your 
 Sukamon evolved, its stats would get divided instead of adding whatever gains the 
 evolution (in the original game, to Etemon only) would provide. 
 
 Now, that only affected if you fill your Virus Bar, and in this hack you can evolve
 by the Ugly Mirror, but regardless of that, this glitch has been fixed too.

 9, The Storage glitch: Fixed by Vice04
 --------------------------------------
 This is probably the glitch that's the easiest to reproduce since the beginning of the 
 game. Whenever you move around the Storage menu, the text will disappear, and the entire 
 thing will start to look very sloppy. Now it performs significantly better, which makes
 the use of the Storage far less annoying.
 
 10, The Giromon Jukebox glitch:
 -------------------------------
 This one is quite famous. The way this game lets you listen to the soundtrack is through 
 the Jukebox inside the Restaurant. The problem is that some of the track titles are so
 stupidly long that they crash the game. 
 
 There was already a fix made by Romsstar a few years ago, but this one is different.
 
 Just for fun, one of the culprit things of this bug is the hilariously titled music track  
 "cient Region of Dino Glacial Time Zone Theme". It's incredible. Not only is a fantastic
 example of "engrish", unnecessarily long and very word salad-y, it's not entirely typed 
 even, they left the "An" from Ancient out! 
 
 Best part? Next to it, you have "Ancient Region of Dino Glacial Time Zone Night Theme".
 So it's even worse. What could they be thinking with these titles...
 
 11, Pre-battle lines game-breaking glitches:
 --------------------------------------------
 There are a handful of moments where an enemy Digimon will speak to you before battle, and 
 its script is broken causing the game to freeze or basically become impossible to do 
 anything. This is the case for a ClearAgumon and that damned BlueMeramon.
 
 These have been fixed. Also fixed the potential freeze that battling with the Agumon 
 guard in the entrance to the Ogremon Fortress could be caused by mistakes in the coding.
 
 12, The Digitamamon Fix: Fixed by Vice04
 ----------------------------------------
 Besides the text glitching out one could, with a lot of luck of course, abuse an issue 
 where your Digimon could eat, but wouldn't be filled, so you could eat as much as 
 you could until wasting all your Bits. It was a mix of being pretty broken, and
 horribly tedious.
 
 Not only that was fixed, the entire restaurant thing was changed quite a bit.
 
 13 How do you even cause this?: Fixed by Vice04
 -----------------------------------------------
 This is why you don't push your luck.
 
 I was almost finished doing this hack when we joked about how I would encounter a super big 
 glitch that would make me pull my hair out and delay this once more. 
 
 ...Later that day we do find a stupidly large glitch. Not my fault, but from the original game.
 
 It turns out that when you press Triangle when you're given a choice which in all our minds 
 thought it was simply "cancelling" to get out of the conversation or choice, you weren't 
 really cancelling it. The game would choose the first option given, but ignore the first 
 command that choice would have... And then read the rest as if it was chosen. Then game writes 
 data to the memory on the wrong place. And this happens pretty much EVERYWHERE but a couple 
 places. And if this happens, you can corrupt things like the Arena.
 
 This is known as the "Piximon Glitch" sometimes, because it is usually done with the Piximon 
 that sells the Training Manual, if you talk to it at a specific time of the day and cancel.
 
 Well, you don't need Piximon. Almost any choice causes this. This made the glitch go from 
 "harmless and only happens if you force it to happen" to "oh my god, it's in over one hundred 
 and fifty different places" at alarming speeds. 
 
 Fortunately it got fixed by Vice04, so you can exit with Triangle and don't break things.
	
 So, the lesson is: Do not make jokes lightly. 
 And reconsider doing stuff, because you might be stuck doing it for a long, long time.
 ...Lastly, don't learn anything and do it regardless.
 
 ---
 
 There were other glitches in the game, but would normally not affect you, and where discovered 
 as the hack was made. Like Digimon on Flat Status actually look for the attacks of the Digimon 
 prior to it on the data, so Vademon during Flat would look at MetalMamemon's Techs, for example.
 
 This could lead to trying to attack during Flat to hang up the game, depending on what Tech 
 was on the seventh slot on the data of the prior Digimon. What a weird way of doing things...
 
 These have been accounted for and worked around them or fixed too. 
 
 ...Of course I can not promise that every glitch has been fixed. This is Digimon World,
 it's not Pokémon Generation 1 levels of bad but it gets pretty close.
 
 Heck, there has been an ongoing joke for decades that all of these glitches were the 
 bad guys' doing to stop you. One of the very few games where that excuse can work!
 
-----------------------------------------------------------------------------------------

 -----------
 S009 - Tips
 -----------
 
 This is just me being silly and adding stuff for the hell of it.
 
----------------------------------------------
Starting out, what Rookie should you go with?
----------------------------------------------
 Well, that's entirely based on both your tastes and which evolutions you want to aim to, 
 but there are certainly some choices that are harder to start with than others.
 
 Agumon and Biyomon should be the easiest to start with because they have Spit Fire, 
 which while not very powerful it's very easy to use and aim thanks to its range and 
 low MP cost, and both can learn stronger techs by battling on the Native Forest.

 The other Digimon start with melee-range Techs, making them harder to start with.
 
 Of those, Betamon, Palmon, Kunemon, Elecmon and Penguinmon have the advantage to be able 
 to learn new Techs by battling around the Native Forest, so they can get quite powerful 
 after the initial awkwardness. Palmon and Penguinmon starting with Poison Claw makes them 
 better at first, as it's a fast Tech, although it eats through MP quite quick.
 
 That leaves us with Patamon and Gabumon having the roughest start, with only Sonic Blow 
 which is very easy to avoid. Gabumon can learn Megaton Punch from the boss fight with 
 Drimogemon, but you only have one chance out of that. 
 
 Besides that, it can learn Ice Needle from the Muchomon in Tropical Jungle's beach, 
 but if you go there with only Sonic Blow, it's going to be painful, as they have 
 Poison Claw and they'll be faster than your Gabumon.
 
 For Patamon you could try your luck with the Tsukaimon beyond the east bridge, but 
 they're stronger than the Digimon in Native Forest, just like the Muchomon. 
 If you beat Kunemon, it will make a few Tsukaimon appear on the west side of the 
 bridge, they're a bit weaker, but only appear until the bridge is fixed, so be 
 careful not to talk to Coelamon until you learn something.
 
 ...Now, that's for Rookies, but you'll only spend 3 days as a Rookie. It is much 
 more important to aim for a Champion and Ultimate.

 Because you're cut off early on to travel far away from Native Forest, let's focus 
 on which Techs can be learnt there from Digimon you can battle infinitely:

 Magma Bomb for Fire, from Goburimon. 
 Electric Cloud, Static Elec. for Air, from Modokibetamon.
 Water Blit and Tear Drop for Ice from Aruraumon. 
 Sonic Jab for Grapple, from Goburimon. 
 Poison Claw, Poison Powder, Danger Sting from RedVegiemon.
 
 Also, you can find a solitary Tsukaimon near the Bridge to the Tropical Jungle
 as mentioned above and only temporarily, but you could learn Wind Cutter from it
 as it's a great move. 
 
 With that list, I'd argue that an Earth, Ice or Air as your first time 
 would make for a solid starting point. Starting with a Penguinmon, Palmon, 
 or Biyomon could lead to Champions that could use some of these Techs and 
 make the first life of your partner less rough; the first one tends to 
 be the rockiest one as you start with nothing, it's harder and slower to 
 train, and of course, you got no Techs to use, so any help is sorely needed.
 
 Oh, and here's another advice: DO NOT TRY TO GET A MECH ULTIMATE AS YOUR FIRST!
 
 You won't be learning any Mech Techs any time soon, so going for let's say, 
 Andromon, Giromon, Megadramon, Vademon and such is going to make your life 
 misserable because you'll have so few Techs to use, and will make battling 
 an absolute chore. 
 
 Ultimates such as Piximon, Hercules Kabuterimon, or Phoenixmon are 
 far less rough because of that. I learnt this the hard way. 

 Imagine my face the first time I got to Ultimate as a kid, only to 
 find that the Digimon I worked so hard and had to reset several times 
 for was far weaker than when it was a Champion because it couldn't 
 use any Tech beyond the most basic one. 

 Mind you, all of this is just advice, you do whatever you want...
 
--------------------
Keep your bag clean!
--------------------

 You can only store 10 Items in your bag initially, and between healing Items, 
 food and things like Porta Potties and Autopilots, those 10 slots can be filled 
 up quickly. But it is in your best interest to always have some free space.
 
 You are going to find lots of stuff lying around everywhere, and many wild Digimon 
 will drop stuff. So make an effort to always have like 3 slots free at least, if 
 not you may find yourself in an scenario where you find a very cool Item but you 
 cannot grab it, and the things you're carrying are important enough to not be 
 thrown away.
 
 It's always recommended to go to the Storage whenever you go back to the City 
 so you can unload Items that you won't need right at that moment.
 
-----------------------------
First Additions to File City!
-----------------------------

 Besides Agumon, which you're bound to battle the moment out of File City, your first 
 goal should be exactly what Jijimon talks to you about, getting a shop so you can 
 buy healing Items to explore with less risk. 
 
 On File City's plaza, a baby Digimon mentions that a shadow appears on the sea coast
 south of the city during the evenings. That'd be the most recommended thing to check 
 out, as once you're able to buy HP and MP floppies, you can take on tougher Digimon.
 
 I usually do this the first day. Go to that coast, then look for Betamon on Tropical 
 Jungle, and then head back to the City and start playing normally, now being able 
 to buy HP and MP Floppies to make the early start a bit less tough.
 
 You should reconsider trying to fight Rookies like Palmon or Kunemon, easily found 
 out exploring Native Forest without some preparation, specially Palmon. They're a 
 bit stronger than before, and you can't run away from Boss Battles so going ill 
 prepared easily means the loss of a Life of your Digimon, and some Items too.

-------------------------------------------------
Learning Techs, simpler than you might have read!
-------------------------------------------------

 Look, I've played this game for decades, you've (probably) played this game for decades, 
 we've read the many, many rumours out there about how to learn Techs.
 
 That you need to be hit with it, that you might need to block it, that you need to see 
 the Digimon do the Tech you want to learn... Well, no, none of these things matter.
 
 Only two matter: That your opponent has the Tech you want to learn, and your Digimon 
 can learn it. You could learn it from an opponent that never even used the Tech. 
 
 So don't worry much about it, and certainly don't make your Digimon take hits, because 
 it's not going to help at all. If anything, it could rise the chance for injury.

--------------------------------------
Learning which Techs to use, and when!
--------------------------------------

 Yes, yes, big damage numbers are cool and all, but you have to consider other things. 
 
 Going for the most powerful Tech also means spending large amounts of MP, and if you 
 don't have the Stats nor the recovery items for it, you're going to have a horrible 
 experience. MP will empty quickly, and then you cannot defend yourself, making 
 exploration a pain. 
 
 Often times it's better to choose less powerful but less MP consuming Techs. These 
 also have higher chances to cause Status Errors and provide a great advantage.
 
 But beyond that, sometimes less is more in other ways. A quick Tech such as Ice 
 Needle, Poison Claw or Spit Fire can be tremendously useful to interrupt enemy 
 moves that would put a serious dent on your Digimon. 
 
 You also have to consider the Types of the enemies you're fighting. It'd be dumb 
 to try to use that Infinity Burn Tech you got on Freezland, it will do less damage 
 than with other Techs and you'll waste more MP doing less.

 ...Just don't put all your trust on something just because the highest Power.

--------------------------------------------
Don't use Finishers the moment you get them!
--------------------------------------------

 Everybody has suffered from this: You get your Finisher ready, you push Square, your 
 Digimon enters the charging phase... And your opponent did an attack before the 
 charge started, and you're hit, losing your chance of doing it altogether!
 
 It's really annoying, but you have no one to blame but yourself for being hasty. 
 Whenever you have your Finisher ready, wait for the opponent to do their move, and then 
 use it! If you wait for your opponent to attack, they won't be able to do another one 
 fast enough to interrupt yours!

-----------------
Don't sell stuff!
-----------------

 In the original game, you were so strapped for Bits that selling rare Items was necessary
 for many, and certain guides downright recommended to sell your Giant Meat or even Sirloins 
 for money. I am surprised to find this is true, but you have proof of it on the net. And 
 that's when people did not recommend you to outright glitch it up to get massive amounts 
 of Bits.
 
 In this hack, you'll get much more fair amounts of Bits from battling, so there's no need 
 to sell them, specially since most things you'll find exploring are more useful too.
 
 Evolution Items are no longer underwhelming either, so keeping them is better too.

-------------------
Don't be too cheap!
-------------------
 
 If you play old school RPGs often, chances are you developed this mentality:
 
 Your characters have low health, but the battle is about to end, so you refuse 
 to use your scarce healing Items to not waste them when you can heal somewhere 
 else later on, outside of the battle. 
 
 Well, here's when Digimon World comes in and laughs at you because you see, 
 finishing battles with low HP increase the chances of your Digimon to receive 
 an injury!
 
 And the more tired it is, the more that low HP affects the chances!
 I've got injuries on the first battle against Agumon more than once just 
 because I forgot to get Tokomon's Items. 
 
 Not to mention this is not Pokémon, there's no place to fully heal yourself 
 in every corner. In fact, the're not just very few of these, none of them 
 heal you to completion either. 

 So do this at your own risk. Well, at your own Digimon's risk I guess, 
 but it's not good anyway!

----------------
Training Faster!
----------------

 Training is one of the things you'll have to accept doing often, but there are ways 
 to make it faster and simple if you have the tools necessary.
 
 Remember that the Green Gym can be improved twice:
 
 One for recruiting Kuwagamon and Kabuterimon, and the other one by having your 
 partner use 10 times each facility when they're in their Baby or In-Training Levels.
 
 Besides that, you can also get the Training Manual to boost your Stat Gains further.
 
 Once you get Veggiemon on the City, you can also buy Hawk Radishes and Super Carrots, 
 which add 20% extra Stat Gains, each one raises three out of the six Stats.
 
 But out there, there are these things called Digipines, which boost your Stat Gains 
 by a whopping 50% and they affect every Stat! So finding Digipines can be very handy.
 
 ...But of course, after you feed your Digimon with one, it's effect will only be in 
 effect until its next meal, as it will override the effects of the Digipine. That's bad!
 
 Yeah, it's kinda frustrating, but there's a way around that, if you have the Bits.
 Go to the Restaurant! If you invite your Digimon to eat there, the effect of the Digipine,
 Super Carrot or Hawk Radish will be kept, and your Digimon will not only go back to 
 have a full stomach, it will take away some Tiredness, add some Happines lost from 
 training, and you'll even get a few extra Stats added to your Digimon!
 
 The downside is that eating in the Restaurant can get pretty costly. But you'll save
 a lot of time of your Digimon's Lifespan, and you also get some Merit Points that 
 you can accumulate and then exchange for Chips to help with training too!


------------------------------
Improving the Green Gym early!
------------------------------
 
 You're going to spend A LOT of time training, specially during the first few lives of 
 your Digimon, so improving your training facilities will save you time on the long run.
 
 There are several ways to improve them. One is making your Digimon use 10 times one of 
 the training facilities during the Baby and In-Training ranks. But you need your Digimon 
 to reborn several times, and that takes a long time. 
 
 The other one, is to bring two ferocious bug Digimon to the city: Kabuterimon and Kuwagamon.
 
 You could devote your early efforts exclusively to get the Gym upgraded, but requires 
 very specific steps and basically start your game with this in mind:
 
 You need 15 Prosperity points to battle Greymon so it makes the Arena.
 You need the Fishing Rod to catch Seadramon so you can get in Beetle Land.
 
 These two require you to recruit a few Digimon and to get to Trash Mountain. 
 
 Getting to Trash Mountain can be done two ways, one needs to drill through the Drill Tunnel, 
 the other requires you to circle around the Swamp, Freezeland and getting to Gear Savannah 
 through the Misty Forest. It's significantly harder but if you're well experienced in the 
 game it might take less time than drilling the tunnel plus fighting Meramon.
 
 To get up to 15 Prosperity Points, you could try and get the easiest Digimon to recruit
 without the need of grinding your stats and such.
 
 Agumon, Palmon, Betamon, Kunemon, Elecmon or Biyomon (going through Gear Savannah for the Rod?)
 You could try Patamon but you're required to fight three times in a row...
 
 Coelamon, Centarumon, Monochromon, Bakemon, Sukamon
 
 These Champion Digimon add 2 to Prosperity each, and all of them can be recruited without 
 fighting them. You could change two of the Rookies for Vegiemon, but you need to wait to 
 get to the 15th of that year, which can take longer than the entire process sometimes.
 
 Between five of the first group and the five of the second, you reach 15. Then it's a matter 
 of fighting Greymon and getting the Arena. 
 
 Otherwise, if you want to go through the Tunnel, you could forget about let's say,
 Monochromon and fight with Meramon. This will also help you by openning the Restaurant, 
 which definitely helps the training process combined with Digipines or Veggiemon's food.
 
 Once you have the Arena, it's just a matter of catching Seadramon on the Dragon Eye Lake. 
 It can be done the moment you get the first Rod, there's no other requisite. It can be 
 catched with the basic rod, but it requires some patience and to not be too aggressive 
 with the reeling. Seadramon will get tired after a point and you'll be able to reel it 
 in much easier. The hard part is hooking it, as it tends to play with the bait a lot
 to confuse you, but once it bites, it's a game of patience and just reeling when the 
 bar is blue or white.
 
 Seadramon only appears from 9 to 10 AM and 9 to 10 PM. 
 
 Personally I kinda like doing this early as it gives me a solid goal to work towards for
 that will help me during the rest of the game, but I can understand if it sounds a bit 
 too hard to do so early.
 
 -----------------------------------------------------------------------------------------
 
 
 
 -------------
 S010 - Trivia 
 -------------
 
 ------------------------------------------------------------------------
 If you ask fans of the franchise (specially, the animated series ones) 
 about which evolutions "are canon" they will respond very adamantly.
 
 Funny thing is, on the Virtual Pets that started it all, barely any of 
 what people believe are "facts" were such!
 
 For example, the closest "default" evolution of Biyomon was Kokatorimon, 
 Birdramon doesn't even appear on the same device as Biyomon, and in fact 
 only Elecmon could evolve into Birdramon. 
 
 Patamon and Angemon are very connected today, but originally? Nah.
 Patamon closest "default evolution" was Unimon, or even Centarumon.
 Angemon wasn't even on the same device as Patamon, like with Biyomon.
 
 There are some weird things too, like Gabumon would only evolve into 
 Garurumon if you treated it poorly and commited lots of Mistakes.
 
 It's really funny to see how wildly different early Digmon is, specially 
 compared to ideas seen as basic knowledge in people's minds now. 
 
 In some of these cases, Digimon World was the first step towards some of 
 these pre-set evolutionary paths. It's hard to believe but Digimon World 
 can be seen as the foundation for so many things that the franchise would 
 become...
 
 -----------------------------------------------------------------------
 
 Did you know that on the original Virtual Pets, Veggiemon was basically 
 the "Numemon" of its own device? 
 
 It was supposed to be the bad evolution, the one you get if you do poorly 
 training your Rookie.
 
 It's interesting to see then, that Digimon World seemingly promoted Veggie 
 into a normal digimon. It's no Filth Type and learns a variety of Techs,
 has its own Finisher, and can evolve into normal Ultimates like Piximon!
 But there's one little detail they left in from its past...
 
 ...On the Arena, if you fight with or against a Veggiemon, RedVeggiemon or 
 Weedmon, the proyectiles it launches are the classic Poops that the bad 
 evolutions would shoot on the Virtual Pets, just like Numemon and Sukamon!

 -----------------------------------------------------------------------

 I've read that, even if in the end the publisher went with MetalGreymon 
 for the creature on the cover, the developers really wanted to go with 
 Mamemon as the face for the game for the international box art. 
 
 It kinda checks out. Not only a Mamemon is the Digimon seen in the ending 
 FMV, but the player character has gear that has Mamemon decorations, and
 Mamemon had an innate advantage over MetalGreymon on the Virtual Pets. 
 Let's not forget that the original MetalGreymon was a Virus Type...
 
 Later appearances of the player character of this game only upped the 
 Mamemon schtick even more. 
 
 Nonetheless, the Japanese cover is so much better...
 
 -----------------------------------------------------------------------
 
 Originally, MetalEtemon was only available if you were given a Memory 
 Card. The card had a save file with a single MetalBanana for you to 
 use and evolve a Champion. Once. Kind of a waste.

 These Memory Cards where only given in Japan as far as I know, as a 
 way to promote the release of Digimon World. 50 Winners chosen at 
 random on the magazine V-Jump.
 
 Panjyamon and Gigadramon weren't available in any official way, which 
 might indicate that the developers wanted to do other events, but 
 never ended up materializing in any way.

 -----------------------------------------------------------------------
 
 The Item Happy Mushroom was actually mistranslated from the Japanese. 
 In Japanese, which I would translate more like "Gambling Mushroom" as 
 it can either sicken your Digimon or give you Happiness.
 
 Yes, I know it's surprising to read that Digimon World has translation 
 mistakes!
 
 -----------------------------------------------------------------------
 
 In the Japanese (and Spanish) versions, it is hinted that the beginning 
 that no, the player character, named Hiro, is not a good Digimon Tamer
 and the reason why he was brought to the Digital World was not for his 
 skills but for his love for Digimon that would make him capable of 
 communicating with them. 
 
 In the English version it obscures it for some reason.
 Now, if the Spanish version didn't have that game breaking glitch...
 
 I mean, that game breaking glitch *besides* all those other game 
 breaking glitches, of course.
 
 -----------------------------------------------------------------------
 
 There's something pretty funny in one of the battle calculations:
 
 In the formula to see if a move hits the target or if it gets blocked, 
 there's a quite weird number:
 
 Chance to Hit:
                                                                       VVVV
 TechAccuracy - (TechAccuracy * (TargetSpeed - (AttackerSpeed / 10)) / 1998)
 
 Why 1998? It's such a weird number to choose... Some people believe 
 that it is because it's the year where the game started development. 
 
 If it is, it's rather cheeky.
 
 -----------------------------------------------------------------------
 
 For some reason I don't really know, Whamon was conceived as a Champion 
 Digimon in the Virtual Pet, and for Digimon World and other games, it 
 is considered one.
 
 But at some point, it was changed to be an Ultimate and has remained 
 like that since then. I just found out while making this hack. 
 I feel weird about this. Not that it matters but... Why?
 
 -----------------------------------------------------------------------
 
 In the original game, you can choose between an Agumon or a Gabumon 
 as the form of your partner Digimon, but if you look at the Virtual Pet 
 the protagonist, you'd see it's a Version 1 device.
 
 On such version, you could get either an Agumon or a Betamon, not a 
 Gabumon! I wonder if they chose Gabumon knowing that a few months 
 later the first show would air and the friendly rival of sorts for 
 the supposed main character of the show had a pal Gabumon...
 
 -----------------------------------------------------------------------

 Did you know that Penguinmon was created specifically for this game? 
 Imagine a life without it...
 
 That alone makes this game the most important creation of humanity!
 
 -----------------------------------------------------------------------
 
 If you check the Jukebox in the Restaurant, you can find one track that 
 does not play in any area of the game. It's one of the Grey Lord's Mansion 
 themes, for the Underground Lab. It resembles the theme for the Secret 
 Beach Cave you can get to with Whamon, but it uses different samples for 
 the instruments. 
 
 -----------------------------------------------------------------------
 
 This game was in development before the show, which I mentioned all the 
 way in the introduction, but the curious thing is that the late parts 
 of its development coincided with the creation of a new series of 
 Virtual Pets named Pendulum. 
 
 The reason why I am saying all these is that a few aspects of such 
 devices were included in Digimon World.
 
 Phoenixmon, Hercules Kabuterimon and MetalEtemon are three Digimon 
 that were introduced in the Pendulum tamagotchis, and are considered 
 Megas, which is a step over Ultimate. Machinedramon is also a Mega, 
 but wasn't designed to be playable.
 
 Because Digimon World has no Mega Level, they were put as Ultimate.
 
 -----------------------------------------------------------------------
 
 Talking about virtual pets, something incredible that I found out 
 researching this game pertains to that absolutely weird creature 
 named Nanimon.
 
 It is known as the Invader Digimon, and I did not get why... Until now. 
 
 It turns out that Nanimon is actually a Tamagotchi creature that somehow 
 reached the Digital World, and evolved to fit this new place.
 
 The character is Oyajitchi, and with one look at it you can totally see 
 the Nanimon resemblance. The more I read, the more obvious things were.
 
 Both like to booze it up, both make a point to be hard to find, both 
 can be rather obnoxious, and there's a version of Oyajitchi that gives 
 it a Bomb-like design (Nanimon has the exact same concept too).
 
 I also learnt about the plot of the first (there are several?!) 
 Tamagotchi movie. The premise is... interesting to say the least.
  
 -----------------------------------------------------------------------
 
 
 So, this is the end of the readme. 

 I thank the original developers for working on this game, because even after 
 all the flaws it can have I still find it to be a tremendously ambitious title, 
 specially for its day and I find it to be still a unique and 
 
 If you are interested in other retro monster-raising games, I can point you to 
 the Monster Rancher series and Dragon Seeds, both can be found on the PS1 too.
 
 ...They're very different experiences, but cool nonetheless. Heck, I would 
 invite you to check Dragon Seeds for the soundtrack alone; Battle on the Holy Plane 
 is one of the best battle themes I've ever heard.
 
 As mentioned way, way above, I also thank Vice04 for his continuous help and SydMontague, 
 Ginoshie, Geta92, Romsstar and every person that researched the game before me as their info 
 was invaluable to start this hack.
 
 Also, to you if you give it a try. I'll even give you two whole "thank yous" if you 
 read all the way here!