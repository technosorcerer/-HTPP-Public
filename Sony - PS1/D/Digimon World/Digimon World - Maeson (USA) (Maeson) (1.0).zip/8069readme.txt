    -------------------
    S000 - Installation 
    -------------------
 
 This is pretty simple. Just grab PPF-o-Matic, the correct Bin/Cue of the game, 
 and my patches. This hack has been made for a Bin file with this hash data:
 
 CRC32: E6FDD00E
 SHA1: 5611645da66183e30d11fb6c11a2784ff47e1fdb

 Open PP-O-Matic, choose the Bin file, and my Main Patch file. 
 Apply it, and you're done... Unless you want to add some Alternate Patches!

 -----------------
 Optional Patches:
 -----------------
 
 I included several optional patches you can apply after the main one. They alter a number 
 of things that you might want to revert, or to have to create a different experience.
 
 1: Starter Patches: 

 They change the initial Digimon you can start the game with, so it's not always the same 
 Agumon and Gabumon choices that we always had.

 Have in mind that you might have a bit of a harder time early on depending on which starter 
 you choose, depending on the types of Digimon and the Techs they can learn. Agumon and Biyomon 
 have long ranged Techs to start with, but they take more damage from Water Techs, so the 
 Modokibetamon might prove to be dangerous. On the other hand, Digimon such as Gabumon and 
 Patamon might have a harder time to learn a Tech that's better than Sonic Blow.
 
 Yet this opens a lot of new possibilities for early game variety. Who wouldn't want to start 
 with Penguinmon and conquer File Island in the name of the Curling Empire? What about starting 
 with a Betamon or Kunemon and explore the Graylord's Mansion early?
 
 Anyway, you have Agumon and Gabumon with the main patch, and other 4 optional ones that alter 
 both of the Starters. "Digi 1" means the Digimon that substitutes Agumon, and "Digi 2" the
 that does the same with Gabumon.
 
 File name:                     Digi 1	   Digi 2
 Main Patch                     Agumon     Gabumon
 Extra Patch - Beta Biyo.pff    Betamon    Biyomon 
 Extra Patch - Pal Pata.ppf     Palmon     Patamon 
 Extra Patch - Penguin Elec.ppf Penguinmon Elecmon 
 Extra Patch - Kune Penguin.ppf Kunemon   Penguinmon
 
 Starting Techs:
 Agumon  & Biyomon: Spit Fire 
 Gabumon & Patamon: Sonic Jab 
 Betamon & Elecmon: Static Elec.
 Penguinmon, Palmon & Kunemon: Poison Claw.
 
 * Biyomon and Penguinmon start with other moves in the original 
   game, being Electric Cloud and Winter Blast in particular.
   They are too strong to start with and offer unfair advantage, 
   so I gave them basic moves shared with other starting Techs.

 You can apply only one! It's not going to corrupt your BIN file, but you're not doing 
 anything but replacing the previous optional patch. 

 2: Remove Tech Bonus Requirement:
 
 In the original game, after your Digimon knows a certain amount of Techs, the Bonus point for 
 Evolution will always be given towards EVERY possible evolution your current Digimon can have,
 meaning that you lose some control over your choices as you can no longer use any other Bonus 
 requirement. 
 
 This patch makes it so the Tech Bonus is removed, and you always can use Happiness, Discipline 
 or Battles. 
 
 3: Restore Greymon's Strength:
 
 In the original game, the Greymon that comes to File City is very infamous and very much despised
 for two main reasons, those being it appears without any warning to newbie players, and that it is 
 absurdly strong for appearing so early into the game if you talk to Jijimon once prosperity is 
 at 15 or higher.

 It has been a constant source of frustration and jokes, as it was very common to appear when you're 
 not ready at all, basically making you lose a Life with no way to avoid it unless you happened to
 have an Autopilot ready, and even then that just saved you for that one time...

 In the main hack, Greymon has been weakened out to a more reasonable level, but if you want him to 
 become as srong as he was, just apply this patch.
 
 4: Vice04's Curling Extravaganza of Fun
 
 ...Well, no, he didn't really call it that. This patch makes it so every time you play Curling, a random
 Digimon will be your opponent, instead of always Penguinmon. All of it was made by Vice04, and because 
 he needed to try and repurpose animations, it took quite a lot of tedious trial and error but the result 
 is pretty fun!
 
 It is a rather cute addition I think, but I leave it optional as... Well, I have a soft spot for that 
 trolling penguin, what I can say. I love it, I hate it, and I love to hate it.
 
 Just have in mind that if you patch this one on your ISO, when you recruit Penguinmon chances are 
 you will play against any other Digimon. Everything will work normally, but it won't make any 
 sense story-wise. After that everything is fine.
