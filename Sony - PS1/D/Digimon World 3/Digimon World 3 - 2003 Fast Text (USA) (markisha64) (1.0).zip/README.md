# Digimon World 2003 Fast Text
Hold X to progress text

