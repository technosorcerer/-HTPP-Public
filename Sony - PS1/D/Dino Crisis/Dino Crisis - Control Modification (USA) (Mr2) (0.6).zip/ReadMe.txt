﻿--------------------------Info---------------------------
Game name: Dino Crisis
Console: PlayStation
Game ID USA: SLUS-00922
Patcher: Cheat Patcher v1.7 or higher.
----------------------------------------------------------
Dino Crisis (v1.0) game file "SLUS_009.22" MD5:
9399e7bb41e8badc4e2dfe5c0714b485
----------------------------------------------------------
--------------------------patch------------------------
Patch add next feature:

 L2 - map quick launch
 L1 - turn move
 Run on [] or /\ button. (without holding UP button)
 Alternative password for all DDK devices: SIMSALABIM
  *The original passwords still works.
 Scroll info in Memory Cart menu
 Kill modchip protection

--------------------Cheat Patcher------------------
Download link:
https://rgcorp.ucoz.net/load/console_soft/cheat_patcher/2-1-0-4
https://romhackplaza.org/utilities/cheat-patcher-utility/
----------------------------------------------------------
Author by Mr2.
e-mail: rgcorpsoft@gmail.com
https://rgcorp.ucoz.net/