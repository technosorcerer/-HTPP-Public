=====================================================
------------- Digimon World 2 Conquered -------------
=====================================================

----------------------- Info ------------------------
A Mod that allows two players to have a battle combat system as the main walkghrough mode,
Additionally, fixes known bugs in the battle system noted in the game.
you can watch the video (https://www.youtube.com/watch?v=48LA84KnflE)

Stacking this mod with other mods will be available through DW2-TT (https://github.com/acemon33/dw2-tt)

Features:
----------------------- v1.0 ------------------------
* PvP Reimagined: Battle System similar to main walkghrough
* Battle Fix:
   - Chrono Breaker Tech: correct the behavior when some (Attack / Assist / Counter-Attack) Techs following Chrono Breaker
   - Darkside Attack Tech: target can't recover HP (all healing Techs)
   - Giga Byte Wing Tech: target can't Recover Status even the random chance to cure the status
   - Invincibility Tech: correct the behavior when being Attacked by Beast King Fist
   - Shadow Scythe Tech: correct the behavior if it is interrupted
   - Zen Recovery / Parameter Patch / Re-Initilize / Re-Format Tech: reset state changes permanently
   - Venom Infusion Tech: guarantee to disable target's turn (no more crash or soft-lock)
   - Transcend Sword Tech: correct the behavior 1.5 damage vs guarding
* Battle Enhancement:
   - Duo ScissorClaw / Scissor Claw Tech: the defense reduction is applied after the damage is dealt
   - Enemy Boss: can be affected or taken damage by Venom Infusion, motivation down Techs, giga-scissor-claw, Confusion Effect
   - Beast King Fist Tech: the damage is 1.8 on Counter-Attack
   - Subzero Ice Punch Tech: every hit increases 7 AP

=====================================================

--------------- ROM / ISO Information: --------------
Code: SLUS_011.93
File/ROM CRC32:   B0CD9681
File/ROM MD5:     E8EE6810A33C45273800DF07628D816B
File/ROM SHA-1:   D9CB009BC0006E901D8AB1365F764AB71DA02115

=====================================================

-------------------- How to Use --------------------
Use DeltaPatcher on a clean vanilla image file (.bin) to apply the patch.
Download any of these links:
https://github.com/marco-calautti
https://www.romhacking.net/utilities/704/
https://www.romhacking.net/utilities/598/
https://romhackplaza.org/utilities/xdelta-ui-utility/

=====================================================

------------------ Tools being used -----------------
This mod didn't come from vaccume, apart from time & effort, I've used many tools and I appreciate their authors:

- PCSX-Reux                 Thanks for amazing psx reverse engineering emulator, this will never exists without it - (shoutout to @Nicolasnoble)
    https://github.com/grumpycoders/pcsx-redux

- Ghidra                    No comment!
    https://ghidra-sre.org

- DW2-TT                    Extracting the game files properly
	https://www.romhacking.net/utilities/1723

- PSX Extractor-Inserter    Created during the journey
    https://romhackplaza.org/utilities/psx-extractor-inserter-utility

- HxD & ImHex               Hex editing
    https://mh-nexus.de/en/hxd/
    https://imhex.werwolv.net

- BinaryDataConverter       At some point
    https://github.com/Operation-Decoded/BinaryDataConverter

- DigimonWorld2Tool         Visualizing fonts & HUD
    https://github.com/RemyRM/DigimonWorld2Tool

- PSIG                      PlayStation instructions generator (MIPS R3000A Assembler) - (shoutout to @Mr2, you are true LEGEND!)
    https://rgcorp.ucoz.net/load/console_soft/psig/2-1-0-6

- slowR3KA                  PlayStation 1 Disassembler (MIPS R3000A)
    https://github.com/infval/SlowR3KA

- psx-modding-toolchain     At some point
    https://github.com/mateusfavarin/psx-modding-toolchain

- other tools & scripts     Created during the journey

=====================================================

--------------------- Contact Me --------------------
Author:  acemon33
E-mail:  zaxmon33@gmail.com
Discord: acemon33#3218
github:  https://github.com/acemon33