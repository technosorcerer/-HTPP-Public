~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
~----------------- Diver's Dream 60Hz Selector Patch --------------------~
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Patch version: v1.0

Author: Paradox (iMPULSE & SiNNER)

Platform: Playstation 1

Date: 1999-06-13

--- Info -----------------------------------------------------------------

This is an old 60Hz patch (selector screen) for the PAL release of Dolphin's Dream (Diver's Dream)
originally only released in Japan and Europe. The patch makes it possible to play this game in 
English and 60Hz on real hardware as well as emulation. 

Zapper2k patching possibly ends in endless loading screens which was the case with Rescue Shot
after the first boss, these old 60Hz patches are preferred and doesn't seem to have those problems.

The game will play at the exact original Japanese game speed. No sped up gameplay or music.
Verified by comparing the time of various timers and countdowns in-game.

Everything in-game is aligned perfectly on the screen, however the FMVs are offcenter downwards a bit. 
It's only a minor issue as playback works perfectly and no part of the image is cut-off, thanks to the
letterboxing.

I converted the old .sin type patch files into a single modern .bps patch.

--- How to Patch ---------------------------------------------------------
Use Beat https://www.romhacking.net/utilities/893

Apply the patch to the .bin of a a redump verified (2024-06-17) dump of the game 
"Diver's Dream (Europe) (En,Fr,De)" 





 



