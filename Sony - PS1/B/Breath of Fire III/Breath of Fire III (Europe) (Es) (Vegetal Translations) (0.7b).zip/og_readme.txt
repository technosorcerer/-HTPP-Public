http://romhackhispano.org

Vegetal Translations Presenta...
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


\_                                                                   ____/
| `\ \-.   __      _____ _   _                      ____ _____ ,--.  | 
|  / |  \ |  ` /^\`  |  `|   |           .--.      |    '  |   |   \ |
/~'\ |  / |   |   |  |   |   |      .---.|_        |       |   |  ./ |___
|   ||-{  |-- |---|  |   |---|      |   ||         |--/    |   |-/   |
|   ||  \ |   |   |  |   |   |      `---'|         |       |   | `\  |
| ./ |   ||__.|   |  |   |   |          /          |     __|__ |   | |_____
/'                                                                
			    ______ ____ ______
			    \_   | |  | |   _/
			      |  | |  | |  |
			      |  | |  | |  |
			      |  | |  | |  |
			      |  | |  | |  |
			      |  | |  | |  |
			     _|  | |  | |  |_
			    /____| |__| |____\


                                 �Parche
			      en Castellano!

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
Miembros de Vegetal Translations y su respectiva funci�n en este proyecto:

        [Vegetal Gibber]:       Programaci�n de utilidades, extracci�n de
                                scripts, edici�n de gr�ficos y traducci�n
				de scripts

        [CHRoNo]:               Traducci�n de scripts

        [Ninjasuperk]:          Traducci�n de scripts

	[Faloppa]:		Betatesting


Vis�tanos en:	http://www.nekein.com/vegetrans
		http://vegetrans.jandar.net

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

ATENCION:  	Esta versi�n de nuestra traducci�n de BoF3 es una versi�n
		beta, a�n no corregida y perfeccionada al 100%, pero s�
		totalmente jugable. Se puede seguir la historia del juego
		sin problemas, pero a�n faltan aspectos por pulir en la
		traducci�n (faltar�n algunos letreros gr�ficos y parte de
		lo relativo a los elementos opcionales: minijuegos,
		secretos, etc). Puesto que el proyecto nos ha tomado
		muuuuuuuuuuuuuuuuuuuuuuucho m�s tiempo del que pens�bamos
		en un principio, tom� la decisi�n de publicar un parche en
		el momento en que la traducci�n fuese lo bastante completa
		como para poder terminar el juego, para as� m�s adelante
		liberar la versi�n final sin prisas y sin tener a nuestro
		p�blico esperando =)

		En resumen: si eres un perfeccionista, y no quieres jugar
		con una traducci�n que no est� al 100% pulida en todos los
		aspectos, espera a la versi�n final antes de aplicar el
		parche. Si no te importa que algunos detalles, como
		algunos textos poco importantes o peque�os gr�ficos,
		puedan aparecer en ingl�s, entonces este parche beta es
		para ti =)   (de todas formas, los perfeccionistas que
		antes mencion� lo tienen crudo... dudo que en ning�n
		momento tengamos una versi�n literalmente al "100%"
		traducida en todos los aspectos xD )

		Este parche est� dise�ado para la versi�n PAL de BoF3, y
		no funcionar� con la versi�n NTSC del juego.  Lo siento.


- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

1. Introducci�n
2. Instrucciones de aplicaci�n
3. Progreso
4. Notas y observaciones
5. Historial de versiones
6. Bugs conocidos
7. Pistas y soluciones
8. Cr�ditos

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

1. Introducci�n (WARNING: Incoming Rollo)

	Breath of Fire 3... el juego que fue mi perdici�n en la PSX..
Hmmm.. a�n recuerdo aquellos d�as de verano "malgastados" mientras me
quedaba sentado frente a la TV vici�ndome sin parar. Pero bueno,
mejor dej�monos de nostalgias... y pasemos a la historia de sangre,
sudor y l�grimas que nos ocupa xD

	La idea de este proyecto surgi� hace ya bastante tiempo, cuando
las traducciones de PSX a�n eran algo "poco com�n". Un servidor (Vegetal
Gibber) acababa de terminar la traducci�n de BoF2, y hab�a decidido
dedicarme de lleno a BoF1. Pero por un instante se me cruz� una idea
por la mente: "�Qu� pasar�a si echase un vistazo al CD de BoF3 en el
ordenata? A lo mejor hay algo interesante.."

	Cuando encontr� los archivos de datos de BoF3 en el CD,
inmediatamente se me ocurri� hacer una peque�a prueba de "traducci�n"
de la primera pantalla del juego. As� que cre� una ISO del juego,
la edit� "a lo bruto", y la grab� a un CD para probarlo con PSEmuPro..
y no pude evitar gritar "�Eureka!" en cuanto vi la pantalla modificada
(por supuesto, justo cuando aparec�a dicho di�logo el juego se quedaba
"colgado" xD , pero a�n as� me ilusion� el resultado).

	Mientras iba avanzando en BoF1, fui dedicando algunos ratos a
investigar m�s en el tema de BoF3. Pero me di cuenta de que yo solo,
al paso que iba, no terminar�a la traducci�n antes de que el infierno
se congelase :P  Por eso habl� con CHRoNo y Ninjasuperk, mis compa�eros
de grupo, quienes accedieron a ayudarme con este proyecto (�gracias,
chicos!).

	Program� algunas utilidades para facilitar tanto mi labor
como la de mis colegas (un insertador de scripts, y un editor de
texto especial para la traducci�n de los mismos). Hicimos una serie
de pruebas con dichas herramientas, y todo fue sobre ruedas. M�s
adelante, acab� figur�ndome el formato de gr�ficos RAW (aunque los
se�ores __Andrey__ y _Faster me ayudaron en un principio con esta
tarea) y desarroll� tambi�n un pack de utilidades para modificar
dichos gr�ficos (que m�s tarde se convirtieron en las Vegetal's RAW
Utilities, disponibles para descarga en nuestra web)

	Pero esta labor no fue un camino de rosas en todo momento...
Cuando termin� con la programaci�n de las utilidades, "s�lo" me quedaba
dedicarme a la extracci�n, traducci�n y reinserci�n de cada bloque de
texto: un total de unos 1,2MB de texto puro (sin contar los bloques de
texto repetidos), desperdigados a lo largo de unos 200 archivos... algo
realmente tedioso :P  Cada vez iba dedicando menos tiempo a trabajar en
la traducci�n... hab�a otros asuntos que requer�an de mi atenci�n: la
universidad, mis otros proyectos, y otras cosas de mi "vida real". Hubo
incluso momentos en los que llegu� a pensar que jam�s terminar�a este
proyecto, y que acabar�a perdiendo todo el inter�s en �l.

	Por suerte, jam�s llegu� a darme por vencido totalmente... y un
buen d�a me top� con la web del genial proyecto de Breath of Fire 2
mejorado de d4s (http://bof2.blogspot.com). Al ver lo que este hombre
hab�a sido capaz de hacer, decid� que yo no pod�a seguir deshonrando a
mi saga favorita con mi lentitud y mi desinter�s. Al parecer, el virus
BoF segu�a haciendo efecto en m�, a pesar del paso de los a�os xD  Tom�
la decisi�n de lanzar un "ultimatum": si yo no fuera capaz de tener
listo un parche completo (al menos al 90%) y totalmente jugable antes
de la llegada del a�o 2006, admitir�a mi derrota y me retirar�a del
mundo del romhacking sin dejar rastro. Esa promesa signific� el
comienzo de unos cuantos meses de trabajo intensivo, traduciendo texto
y hackeando gr�ficos por doquier... y el d�a 7 de junio de 2005, sobre
las 17:00, ten�a por fin lista la primera versi�n beta casi-completa
de la traducci�n ^_^

	Lleg� la hora del betatesting... y entonces apareci� ante m�
el se�or Faloppa, que lleg� que ni caido del cielo xD  �l se ofreci�
voluntario para probar la traducci�n e informarme de todos y cada uno
de los errores e inconsistencias en mi trabajo, en un tiempo r�cord
(�este hombre s� que se lo curra! :D ). Y finalmente, tras una buena
serie de retoques y correcciones, aquel parche beta madur� y se
convirti� en la traducci�n que ahora tienes en tus manos :)  (o mejor
dicho, reposando en algunos de tus dispositivos de memoria masiva xD )

	Bueno, creo ya he abusado bastante de la paciencia de los
lectores, as� que no les aburrir� m�s. Tan s�lo me resta desearles
que disfruten con salud de nuestro regalo de navidad, que de seguro
les agradar� mucho m�s que aquella primera beta que publicamos hace
unos a�os, en este mismo d�a de navidad. ��Felices fiestas!! :D


- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
2. Instrucciones de aplicaci�n

	Para aplicar el parche correctamente, sigue los pasos
indicados a continuaci�n:

1)	Descomprime el ZIP con el parche en la carpeta que desees.

2) 	Crea una imagen ISO de BoF3 (PAL) a partir de tu CD original
	usando cualquier software de grabaci�n que soporte el formato
	RAW BIN (Fireburner, CDRWin, Nero, Alcohol 120%, etc). Si ya
	posees una imagen BIN del juego, puedes obviar este paso.

	Si est�s usando CDRWin (www.goldenhawk.com), selecciona la
	opci�n "Extract Disc" (el tercer icono del men�) y configura
	los siguientes ajustes en las "Reading Options":

	Marcar la casilla RAW y desmarcar CD+G, CD-TEXT y MCN-ISRC
	Error Recovery: Abort (o Ignore)
	Jitter Correction: Auto
	Subcode Analisys: Auto
	Read Retry Count: 4
	Data Speed: 4X
	Audio Speed: 4X

	Si posees una grabadora de CDs, recomiendo utilizarla para
	leer el CD, en lugar de tu unidad lectora (parece ser m�s
	exacta a la hora de leer los datos del disco).

3)	Utiliza el PPF-O-Matic 3 (b�jalo de nuestra web, en la secci�n
	Extras -> Utilidades) para aplicar el parche PPF sobre la
	ISO en formato BIN.  Es tan simple como seleccionar el parche,
	la ISO, y pulsar sobre el bot�n "Apply"

4)	Ahora tienes dos opciones: una es jugar directamente con la
	ISO, usando un emulador que te lo permita (recomiendo ePSXe
	1.4.0 o superior), o bien grabar de nuevo la ISO sobre un CD-R
	para jugar en tu PlayStation (utiliza la primera opci�n del
	CDRWin para este menester, pero seleccionando el archivo
	CUE en lugar del BIN). Sea cual sea tu elecci�n, buen
	provecho :)


- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
3. Progreso

Progreso total aproximado: 90%

        Traducci�n de textos:
	---------------------
        * Texto de Introducci�n: 100%
	* Texto de Men�s: 95%
	* Objetos y hechizos: 99%
        * Di�logos (texto principal): 95%

	Edici�n de gr�ficos:
	--------------------
	* Caracteres espa�oles: 100%
	* R�tulos de batalla: 90%
	* Pantallas de inicio/fin de juego: 100%
	* R�tulos y men�s de mapa-mundi: 100%
	* R�tulos y men�s de minijuegos: 0%
	* Men�s especiales: 30%
	* Otros gr�ficos: 40%

	Otros:
	------
	* Minijuego de pesca: 20%
	* Minijuego de colonia de hadas: 15%
	* Revisi�n del texto: 0%
	* Correcci�n de punteros: 10%


- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
4. Notas y observaciones

	Esta versi�n de la traducci�n es todav�a una versi�n beta, en
desarrollo. Aunque es totalmente jugable, quedan ciertos detalles por
corregir antes de que el proyecto pueda ser considerado como terminado.


- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
5. Historial de versiones:

* Versiones alpha (que nunca salieron de mis laboratorios)
Versi�n 0.01a - El comienzo del proyecto. Algunos di�logos
		de la introducci�n traducidos.

Versi�n 0.02a - Men�s traducidos parcialmente.
		Objetos y hechizos comenzados.
		M�s di�logos traducidos.

Versi�n 0.03a - M�s objetos y hechizos traducidos.
		Comenzada la extracci�n y traducci�n de scripts.
		(Algunos bancos de texto ya est�n insertados)


* Versiones beta

Versi�n 0.1b - 	Beta p�blica especial de navidad :D
		Jugable hasta el primer "enemigo-jefe" de BoF3.

Versi�n 0.2b - 	Primera versi�n con caracteres espa�oles ^____^
		Hack gr�fico de los men�s completado.
		Jugable hasta el segundo "enemigo-jefe" de BoF3.

Versi�n 0.3b - 	Avanzado el hacking gr�fico (pantalla de
		presentaci�n, men�s, batallas, etc).
		M�s di�logos traducidos e insertados.
		Jugable hasta llegar a la Planta Qu�mica.

Versi�n 0.4b -	Hack gr�fico avanzado (s�mbolos del sistema
		de batalla y pantalla de game over).
		Primera mitad del juego en espa�ol. W00t!

Versi�n 0.5b -	M�s di�logos finiquitados... doh.
		Jugable hasta llegar al Continente Perdido

Versi�n 0.6b -	Primera beta interna completa ^____^
		Historia totalmente jugable en espa�ol.

Versi�n 0.7b -	Segunda beta p�blica, el proyecto casi terminado ^^
		(aunque todav�a quedan detalles por corregir)


- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
6. Bugs conocidos

	* Algunos textos de los men�s usan abreviaturas o aparecen
	incompletos, debido a limitaciones de espacio o punteros que
	a�n no han sido reajustados. Probablemente lo corregiremos en
	la versi�n final del parche.


- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
7. Pistas y soluciones

	Por ahora no podemos ofreceros una gu�a en espa�ol de BoF3,
pero pod�is encontrar varias gu�as de BoF3 (en ingl�s) en www.rpgamer.com
y www.gamefaqs.com


- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
8. Cr�ditos

	Yo (Vegetal Gibber) quiero dar gracias a:

	* Capcom, por crear este fabuloso juego, del cual a�n no
	me he cansado.

	* A mi familia por aguantarme durante todo el d�a hablando
	sobre Breath Of Fire, traducciones, etc... a�n sin tener ni
	idea de qu� va el asunto xD

	* A los dem�s miembros de Vegetal Translations: CHRoNo,
	Ninjasuperk y Faloppa... Sin su ayuda, este proyecto no
	hubiera sido posible :)

	* A __Andrey__ y a su amigo _Faster, por su inestimable
	ayuda en el tema del hacking gr�fico, haciendo posible
	la inserci�n de los caracteres espa�oles en la traducci�n :)

	* A mis amigos del "Proyecto Elefante Blanco": Arioch,
	Jorgatts, Alemalloc, Juanman y Mikinawer... por su apoyo
	y por ser los primeros en reconocer mi trabajo (aunque no se
	hayan ni dignado en probar la versi�n beta que les dediqu� :P)
	Que la fuerza os acompa�e, panda de gromenawers xD

	* A Juanjo Puerto (alias "Potrinca"), por haberme prestado
	su Action Replay cuando lo he necesitado :P

        * A los responsables de la inolvidable FTH, por ser los
	primeros en anunciar mi proyecto (jonas, nos hacemos
	viejos, �eh? xD )

	* A gi0, Pablito's y dem�s colaboradores de la gran web
	"Todo Traducciones", por tomarse siempre la molestia de
	hacer llegar nuestras noticias al p�blico :)
	(�Visita www.todotradus.com!)

	* A todos los que habeis bajado el parche, por probar
	nuestra traducci�n.

	* Y claro est�, un gran saludo a todos los dem�s traductores
	de la "escena" hispana, que se esfuerzan d�a a d�a para que
	todos podamos disfrutar de los mejores videojuegos en espa�ol :)


- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -