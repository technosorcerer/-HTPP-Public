BOF 3 fans who wanted something tougher than the normal game and found the normal challeneges too
boring here you go! Enemies aren't squishy no more and bosses can take a real beating now.
with these other few changes that was added as well this should make the game has a new taste in
gameplay and how to do some fights.

What does this patch do:
It doubles enemies HP making the game harder due to longer fights and a few other changes listed below
.Archmage only got a 1.5 HP boost due to 3k regen would be too much
.All sample bosses got x3 HP (besides the stallion samples 10 11 and 12 they only got doubled)
.Vileweed now has some AP so he can be dangerous
.Some Bosses got AP boost so they can keep up their spells
.Vampire now gives 18k if you can somehow kill it while its regen is on
.Eye goos near Bunyun house gives more exp than normal while blinded
.Vulcan also give more exp when they begin to move
.Drak in the desert has more AP
.Reaper has higher ATK
.D.Lord and Myria has higher INT
.Beyd did not get a HP boost cause it would had make the Zig fight easier
