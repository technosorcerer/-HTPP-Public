Breath of Fire III - Spell Name Update Hack
By Almagest

-------------------------------
Introduction
-------------------------------
This hack updates the spell names so they can phonetically match the original Japanese
names. The spell names were mostly made up by Capcom, they're neither Japanese or English words.
However, there *is* some wordplay involving Japanese and English words.

-------------------------------
How to Apply
-------------------------------
Apply with PPF-O-Matic. Breath of Fire III is a multi-track game,
so the patch must be applied to the track that contains the game (normally Track 1).
If the ISOs have no name, apply to the largest file.
This patch is only compatible with the US release for the PlayStation.
Tested with ePSXe and works. This was not tested on real hardware.

-------------------------------
List of Changes
-------------------------------
=Healing Skills/Spells=
Heal -> Relif
Rejuvenate -> Uplif
Restore -> Toplif
Vitalize -> Refral
Vigor -> Refrest
Raise Dead -> Reval
Resurrect -> Revalra
Purify -> Yakri
Remedy -> Yaklif
Cure -> Yaplif

=Attack Skills/Spells=
Burn -> Pamu
Flare -> Padamu
Fireblast -> Padaama
Inferno -> Padoraama
Frost -> Reiga
Iceblast -> Reigil
Blizzard -> Greigol
Simoon -> Mega
Sirocco -> Domega
Volt -> Val
Lightning -> Baval
Myollnir -> Valhalla
Cyclone -> Sheiza
Typhoon -> Shezaaga
Quake -> Gadabreda
Ragnarok -> Mekomu
Drain -> Rekta
Leech Power -> Marekta

=Status Skills/Spells=
Protect -> Katekt
Shield -> Mikatekt
Speed -> Hasaat
Might -> Gigaat
Blunt -> Stol
Sleep -> Nemrii
Slow -> Daal
Weaken -> Dir
Silence -> Pepopa
Confuse -> Powan
Death -> Waasu
Transfer -> Takrema (this was Marekta spelled backwards - ma-re-ku-ta -> ta-ku-re-ma)

-------------------------------
Special thanks to:
-------------------------------
Rurouni of dragon-brood.com, for all the valuable information