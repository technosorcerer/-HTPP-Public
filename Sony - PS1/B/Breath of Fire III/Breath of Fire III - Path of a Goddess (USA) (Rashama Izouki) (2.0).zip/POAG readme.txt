                                              Breath of fire 3 path to the goddess readme

.Most Enemies behaviors have changed 
.Some enemies have new Properties (such as able to crit or dodge easier)
.Enemies HP are doubled at least (some have higher depending where they are fought)
.Master give different stat boost and skills (note: the changed one as of now do not give a star so use the list below to help you)
.Enemies group will be bigger and they give more exp
.the heroes have different element resistances (ex: Teepo is weaker to lighting and wind now)
.Nina stats are different and also her level ups
.Some enemies have a different name (ex: elder dragon is now called Jono in his fight)
.more superbosses have replaced enemies including the Dodo fight endgame (recommended level to fight them: +70)
.Tankbot at the containeryard is now a boss as well and he meant to act werid as his name states
.Dragon gene cost have been to made cost more
.fairy gift are now different
.Rhapla and parch item shop are now more fish based
.heal spells cost less now
.The unused spell is now used by enemies
.The unused double spells are stronger version of their counterpart (besides 2 of them)
.the more broken spells are no longer learnable
.The ? area near Mt. Glaus in spring time is now a post game area with a superboss waiting for you
============================================= Master list==========================================================================
Note: if you do not learn all skill from a master after getting the level ups
you need for all skills, chances are you may have one of the skills if you learned
it from monsters (assuming you have the room to learn it from the master)
Bunyan
Hp +2     Str +3
Mp -2     Def +1
Agi -3    Int -5
Skill 1 : 2 level ups
skill 2 : 5 level ups
Skill 3 : 8 Level ups
skill 4 : 10 Level ups


Mygas
Hp 0     Str -1
Mp +2     Def -1
Agi 0    Int +3
Skill 1 : 1 level ups
skill 2 : 4 level ups
Skill 3 : 6 Level ups
skill 4 : 8 Level ups
skill 5 : 10 level ups

Yggdrasil
Hp -1     Str -2
Mp +1     Def +1
Agi 0    Int +2
Skill 1 : 2 level ups
skill 2 : 5 level ups
Skill 3 : 8 Level ups
skill 4 : 12 Level ups


D Lonzo
Hp -1     Str -3
Mp -3     Def +1
Agi +1    Int +1
Skill 1 : 2 level ups
skill 2 : 3 level ups
Skill 3 : 4 Level ups


Fahl
Hp +1     Str +2
Mp -2     Def +1
Agi -3    Int -3
Skill 1 : 2 level ups
skill 2 : 4 level ups
Skill 3 : 6 Level ups
skill 4 : 12 Level ups
skill 5 : 16 Level ups
skill 6 : 20 Level ups

Durandal

No change to this guy


Giotto
Hp +4     Str -2
Mp +5     Def -3
Agi -2    Int -2
Skill 1 : 2 level ups
skill 2 : 5 level ups
Skill 3 : 7 Level ups
skill 4 : 9 Level ups
skill 5 : 10 level ups

Hondara
Hp 0     Str -2
Mp +1     Def 0
Agi 0    Int +1
Skill 1 : 2 level ups
skill 2 : 5 level ups
Skill 3 : 8 Level ups
skill 4 : 12 Level ups

Emitai
Hp 0     Str -2
Mp +5     Def -2
Agi 0    Int +5
Skill 1 : 2 level ups
skill 2 : 4 level ups
Skill 3 : 6 Level ups
skill 4 : 8 Level ups

Deis
Hp -3     Str +1
Mp +3     Def -3
Agi +1    Int +3
Skill 1 : 2 level ups
skill 2 : 5 level ups
Skill 3 : 8 Level ups
skill 4 : 11 Level ups
skill 5 : 15 level ups

Hachio
Hp +2     Str +2
Mp -2     Def +1
Agi -1    Int -1
Skill 1 : 2 level ups
skill 2 : 4 level ups
skill 3 : 6 level ups
skill 4 : 8 level ups
skill 5 : 10 level ups
skill 6 : 12 level ups

Bais Lang Lee and Wynn are unchanged

Ladon
Hp +1     Str +2
Mp +1     Def +2
Agi +1    Int +2
Skill 1 : 3 level ups
skill 2 : 5 level ups
Skill 3 : 7 Level ups
skill 4 : 15 Level ups

Maryleep
Hp -1     Str -1
Mp +1     Def -1
Agi +1    Int +1
Skill 1 : 2 level ups
skill 2 : 5 level ups
Skill 3 : 8 Level ups
skill 4 : 10 Level ups
skill 5 : 15 level ups
