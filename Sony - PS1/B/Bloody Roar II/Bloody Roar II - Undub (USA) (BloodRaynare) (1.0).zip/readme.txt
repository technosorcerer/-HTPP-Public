Bloody Roar II - (Half) Undub patch by BloodRaynare
For USA version - SCUS-94424

Replaces (mostly) character voices with the original japanese one. 
Well mostly, because even in the original JP ver. there's only like 7 out of 11 characters 
that have their voices in japanese, the rest of them are voiced in english.

Requires Redump-verified dump of the USA version of BR2. After you patched it, the md5 hash 
should be equal to 906349a87610bf6e6d5fe7f2aa4803c0. Use the included DeltaPatcherLite.exe to patch your dump.