-----------------------------------------------------------------------------------------------

-=Resident Evil 1.5 (Magic Zombie Door) Patch Released 25/12/2020=-

-----------------------------------------------------------------------------------------------

Instructions:

To use this patch you need to have the original RE1.5 MZD (Magic Zombie Door) ISO, I will provide you a download link to it, since the original one is dead:
http://www.mediafire.com/download/3hn9c4e3rdu8yb7

After download it, extract the "RE1.5 (MZD).7z" file and use "xdelta" to apply the patch to the "BH2.bin" file (for more information, look "HOW_TO_USE_XDELTA.PNG" image!).

Done! you can play now!

-----------------------------------------------------------------------------------------------

December 25, 2020 updates:

-Added new backgrounds for room 407 (By Juvenal)
-Added new backgrounds for A-2 Elevator (room 402) (By Juvenal)
-Added new backgrounds for Alligator Boss (room 209) (By Juvenal)
-Added new East Corridor (room 105) (By Juvenal)
-Added new West Corridor 2F (room 10C) (By Juvenal)
-Added new Conference Room (room 114) (By Juvenal and biohazard_star)
-Added new Zombie Tunnel (By Juvenal and biohazard_star)
-Shelters are now playable, however incomplete capcom backgrounds have not been replaced yet (this will be replaced in a future patch)
-Added original backgrounds in room 208 (this will be replaced in a future patch)
-Added puzzle in Firing Range (room 119), which once solved will allow access to Armory (room 11A):
Note 1: Before using it, you must first restore the power of the RPD
Note 2: There are two different ways to solve it (one for each character)
-Added statues puzzle in 3F Corridor (room 113), which once solved will allow access to Conference Room (WIP, yet)
-Added a small puzzle that will allow to obtain the Super Redhawk in the factory (room 305)
-Added simulated gameplay for Sherry at the factory
-Added some texts in some rooms where they are supposed to be save rooms
-Added fuse in room 404 (before it was in 409, but it was changed)
-Added itembox model in room 604
-Added itembox model in Office A (room 30A)
-Added jocker item in room 206 (By Richard Mandel)
-Added eating zombies and Remington M870 in Medical Room (room 10E)
-Added Roy's corpse in room 102
-Added staircase in Radio Room (room 10F) that will allow quick access to room 109 (WIP, yet)
-Added Minidisc Player w/ Disc and Shotgun Shells in Morgue (room 120) (you will need to get the Minidisc Player w/ Disc to unlock the Archive Room door)
-Added missing character names in texts (during custcenes)
-Added shutter in Conference Room (room 114)
-Added shutter in 3F Corridor (room 113)
-Added shutter in room 105
-Added zombie model in B1 Corridor Light (room 123)
-Added color to character names during cutscenes (inspired by the famous mod, Mortal Night)
-Added new Ada model (By Juvenal)
-Added new Annette model (By Juvenal)
-Added small cutscene in room 104 (Elza)
-Added new version of the cutscene of Roy with Elza in Mirror Room (room 101)
-Added new version of John's cutscene with Elza in room 121
-Added crows in room 109 (WIP, yet)
-Added small cutscene of Sherry in room 304 (Leon)
-Added RPD vest models in Armory (room 11A)
-Added itembox model in room 406
-Added Crank in Save Room (room 201) (this will serve to open the gate in Zombie Tunnel)
-Added zombies in Garage B (room11C) (Elza)
-Added zombies in Conference Room (room114) (Leon)
-Added Kevin model as an extra playable character (By TheMitu97)
-Added animation for Leon in Sherry's cutscene in GARAGE B (room 11B)
-Added extended cutscene in TRAIN M. CAR (604) (Leon) (By Richard Mandel)
-Added itembox model in TRAIN M. CAR (room 604)
-Added new ID cards for Leon and Elza (By Juvenal)
-Added Sherry's clock in Aligator Boss (room 209)
-Added placeholder for ALLIGATOR EXIT (room 20A)
-Fixed opening text change time
-Fixed some details in PLD models (By Juvenal)
-Fixed Super Redhawk texture (By Juvenal)
-Fixed a bug in the collisions of L Tunnel (room 200) that caused the game to crash in some occasions
-Fixed a bug that caused the character to disappear when accessing Office A and Office B in the factory
-Fixed some texts in some rooms
-Fixed Yellow Keycard name
-Fixed small bug in the skins of Site A (room 300)
-Replaced Ingram M10 by H&K MC51 in Armory (room 11A)
-The doors of Subway can be opened through the switch
-Improved cutscene in room 11B (Elza)
-Improved cutscene in Corridor (room 309) (Elza) (By Richard Mandel)
-Improved cutscene in room 600 (Leon)
-Doors in room 512 leading to P-4 Lab and Server Room are now locked due to the fire
-Zombies can now break the Lobby blind (room 103) on Elza's stage (WIP, yet)
-Some BGMs have been updated (WIP, yet)
-Elza's fight with Birkin in the laboratory was changed to room 50F
-Removed zombie dogs in Armory (room 11A)
-The door to Save Room (room 401) is locked now (Elza)
-The door to the experiment room (room 40B) has been locked, which can be opened from the Server Room (room 505)
-Updated some inventory's icons/images
-A bonus patch has been included which restores the original (40% build) weapons animations (for those who prefer it)

-----------------------------------------------------------------------------------------------

March, 2020 updates:

-Added new opening (by Richard Mandel)
-Added ending (by Richard Mandel)
-Added new Load Game screen (by Juvenal)
-Added new Staircase 1 (by biohazard_star)
-Added new Staircase 2 (by biohazard_star)
-Added new 3F Corridor (by Juvenal)
-Added new 3F Elevator Hall (by Juvenal)
-Added new Conference Room (by Juvenal)
-Added new cutscene in room 50B (WIP) (Leon game) (by Richard Mandel)
-Added new cutscene in room 600 (Leon game) (by Richard Mandel)
-Added working elevator in room 305
-Added working elevator in room 50D
-Added missing collision to Elza's motorbike in room 103
-You will need to get the Fire Extinguisher to put out the fire on the van (which is in room 105) (Leon game)
-You will need to get the Pliers to open the shutter in room 11E (which is in room 11B)
-You will need to get the Green Keycard to unlock the warehouse's door in room 301 (which is in room 30A)
-You will need to get the Blue Master Keycard to unlock the automatic door in room 400 (which is in room 401) (Leon game)
-Improved cutscene in room 109 (Leon game)
-Improved cutscene in room 114 (Elza game)
-Improved some texts in room 309
-Fixed small camera bug in room 309
-Fixed collision in room 30B
-Fixed small text error in room 501 (Elza game) (thanks to YouTube user for it!)
-Fixed the wrong room connection in Lab's stairs (thanks to YouTube user for it!)
-Fixed collision bug in room 203 (thanks to Richard Mandel for report it!)
-Fixed Air-Jesus in room 206 (thanks to Richard Mandel for report it!)
-Fixed collision bug in room 502
-Fixed some camera switches in room 601
-Removed meme poster in room 101
-Updated some inventory's icons/images (by Juvenal)

-----------------------------------------------------------------------------------------------

December, 2019 updates:

-Replaced RE2 final intro with Trial intro.
-Almost all rooms are accessible now, also sewer rooms are now connected (debug menu is not necessary, except for room 20B).
-Improved cutscene in room 102 (Elza).
-Improved all cutscenes in room 109 (Leon).
-Improved cutscene in room 10B (Elza).
-Added a small cutscene in room 116 (Leon) (based on Inflames's screenshot and Enigmatism415's translation) (still WIP!).
-Improved cutscene in room 11B (Elza).
-Added a new small cutscene in room 11B (Elza).
-Added two new cutscenes in room 200 (Elza);
Included a reconstructed Sherry's cutscene (based on Inflames's screenshots and Enigmatism415's translation).
-Improved small cutscene in room 307 (Elza).
-Improved cutscene in room 309 (Elza).
-Added Marvin's cutscene in room 30C (Elza) (based on Inflames's screenshot);
This cutscene will be executed after the cutscene in room 309.
-Added zombies in room 30D (Site C-Marvin);
Note: You can access this room after Ada's cutscene in room 30E (Leon) and after Marvin's cutscene in room 30C (Elza).
-Improved all cutscenes in room 30E (Leon).
-Improved cutscene in room 30E (Elza).
-Improved all cutscenes in room 400 (Leon).
-Improved cutscene in room 400 (Elza).
-Improved all cutscenes in room 401 (Leon).
-Improved cutscene in room 403 (Elza).
-Improved all cutscenes in room 501 (Elza).
-Added a small cutscene in room 502 (Elza).
-Added vaccine for Marvin and Sherry in room 506.
-Added Birkin battle in room 50E (based on Complete Disc's video #4).
-Lab on fire rooms are now connected after the vaccine events.
-Improved cutscene in room 600 (Leon).
-Improved cutscene in room 603 (Leon).
-Improved cutscene in room 604 (Leon).
-Improved cutscene in room 603 (Elza).
-Improved cutscene in room 604 (Elza).
-Added Annette and fire effect in room 607 (based on Inflames's screenshot).
-Added some description texts in 204, 302, 305, 30D, 502, 50B, 602, 607.
-Added new version of room 10C (by Juvenal).
-Fixed some minor issues.

Note: The door to the warehouse will be closed at the beginning, but it will be opened after certain events occur.

-----------------------------------------------------------------------------------------------

Tricks/Codes:

Play as Leon (with RPD armor):
800B0FF0 0001

Play as Leon (with Umbrella armor):
800B0FF0 0002

Play as Kevin (By TheMitu97):
800B0FF0 0003

Play as Elza (with RPD armor):
800B0FF0 0005

Play as Elza (with Umbrella armor):
800B0FF0 0006

Play as Claire:
800B0FF0 0007

Play as RE3 Jill (By Juvenal Da Corte):
800B0FF0 0008

Play as Elza (Extra Costume) (By Juvenal Da Corte):
800B0FF0 0009

Play as Grant Bitman (By Juvenal Da Corte):
800B0FF0 000A

Play as Grant Bitman (By Rusty):
800B0FF0 000B

Play as Leon with jacket (By Mrox2) (Edited By Juvenal Da Corte):
800B0FF0 000C

Play as Marvin (By Juvenal Da Corte):
800B0FF0 000D

Play as John (By Mrox2) (Edited By Juvenal Da Corte):
800B0FF0 000E

Play as Sherry:
800B0FF0 000F

-----------------------------------------------------------------------------------------------

Credits:

-Team IGAS for his MZD build.
-Mikhail for help me a lot in the beginning.
-mortician for his unhidden patch and other tools.
-Wes67 for create kindly a rebuilder tool for me.
-DXP for his hard work in create all the missing rooms for the RPD and other rooms!
-Juvenal Da Corte for make and let me use several rooms, characters models, and mix stuff!
-Richard Mandel for help me a lot with cutscenes, dialogues, room texts, rooms connection and for his huge support to this project!
-MarkGrass for his BIOFAT and BioHerb tools.
-Leo2236 for his BSSM, RE2MV and RE2RDTE tools.
-MonkeyMan2000 for his Resident Evil 2 BCC tool.
-Mrox2 for help me with some dialogues in my cutscenes reconstruction and for let me use his Leon with jacket PLD.
-SeiyaK0u for let me use parts of his work.
-Rusty for let me use his Grant Bitman PLD.
-The creator of the "Character modifier" and "Select player screen modifier" codes!
-SolidSnake11 for motivate me to fix the "Air Jesus" bug, also for the collision and "zombie get up after killed" bugs fixs!
-Biohazard Espa�a for the ITPS.ITP fix.
-Enigmatism415 for his Inflames's screenshots translations.
-biohazard_star for make and let me use several rooms!
-TheMitu97 for Kevin model.

-----------------------------------------------------------------------------------------------

Enjoy!

-----------------------------------------------------------------------------------------------

Visit my YouTube Channel:
http://www.youtube.com/user/MartinBiohazard

-----------------------------------------------------------------------------------------------