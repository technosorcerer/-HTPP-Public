There are three patches. Each patch may be used by itself, or in combination with any of the other two. 

1. The translation patch: Apply to both disk 1 and 2. Works with bin file from a bin/cue type CD image.

2. Movies Voiced: Replaces movie sound with English voice acting.

3. Movies Subtitled: Adds subtitle text to movie video without changing original audio.


This goal of this translation was to make a polished, enjoyable product which would feel natural to Western sensibilities - similar to what a commercial game localization studio might release. Though every effort was made to preserve the content of the original Japanese, the translation was not a slave to awkward Japanese phrasings and tries to flesh out unstated cultural implications. The result being occasional added phrases or sentences. Every effort was made not to lose any content, but only fill out what was implied in the original.

DIALOG TEXT:
An example is the encounter of Dinadan versus Cador the Death Knight. The evil Cador makes a long, dark speech about "feasting on the dying breath of my enemies, come feed me". Dinadan's literal response is basically one word "no". The significance of this reply would be mostly lost in a direct translation. Its cultural implication is 'fearlessness' and 'competence' in the face of a powerful enemy. Since Dinadan is one of the more playful and laid back characters in the game, his reply was changed to "bet you're fun at parties". The intent was not to add content, but to convey his "fearless competence" to western ears.     

NAMES:
To this same end, some names deviate from literal translations. These changes are limited to names that were originally English words spelled phonetically in the Japanese Alphabet. Japanese game designers were notorious for choosing silly Engrishy names because they sounded exotic to Japanese gamers. Any deviations from literal were chosen to aid pronounceability, create individuality or poignancy etc. 

SPACE:
On very rare occasions, text was shortened for space considerations. Again, every effort was made to keep all original content while shrinking it into a smaller phrasing. 


CREATURE DESCRIPTIONS:
Creature and attack descriptions were the most liberally 'fleshed out' areas in the translation. The intent was to retain original content, while moving away from the dry, repetitive and immersion breaking original phrasing. As a general rule, these rephrasing follow a set pattern. "Low/High HP" becomes "Frail/Hearty", "High/Low" Rune Cost becomes "Hard/Easy to control/tame" etc. 

An example is the Ghoul's description.

Literally:
"A monster featuring a low rune cost. Its attack power corresponds. However using it as a distraction in battle is common. It should not be overlooked because it levels up fast if you can keep it alive."

Became:
"Weak but fearless, this morbid creature is easy to summon and control. It usually serves as a disposable decoy for knights who can stomach its grisly habits."


KNIGHT DESCRIPTIONS:
Knight descriptions did not suffer from the same immersion breaking repetition as creatures and thus are far more literally translated.


OTHER TRANSLATION CHOICES:
Brigandine's story makes it clear that magic is not a generic skill that anyone can learn, but can only be performed by creatures or humans it calls "Rune Marked". Accordingly, the generic term "spell casting" was replaced with the more distinct "Rune casting".

Capital cities have unique titles in Grand Edition except for Caerleon's capital Linnuis. This was considered an oversight and a Linnuis was given a corresponding title.

Menu phrasing was occasionally tweaked to move away from dry immersion breaking labeling. Example: 
"Choose difficulty setting: EASY NORMAL HARD"
became
"Choose your path: Squire, Knight, King"
with explanatory sub-text for each.


If these motives give anyone worries about the accuracy of the translation, I would strongly suggest comparing a transcript to the Legend of Forsena release by Atlus. Though Atlus changed a lot of details and botched the translation regularly, it is still mostly literal (~95% literal).



KNOWN ISSUES:
If the game is completed, and then a new game is started before resetting the console, some text may appear corrupted. This effect is harmless and will go away when power is cycled.

If the start button is used to skip though some text boxes during a cut scene, text may display inaccurately for the rest of that scene. The effect is harmless and disappears at scene's end.

During some random quests, there will be inaccurate use of "the" "a" or "an" in front of random item names (ie. "You found a Anvil").

In the Recollection section, some random quests will display the incorrect name for a knight's Lord. This is a bug in the original game.

In the multi-player section, some knight descriptions (which are normally updated as story events unfold) may display incorrect versions. This is a bug in the original game.

If playing on an actual Playstation console, location names displayed before battle may display incorrectly.

     
