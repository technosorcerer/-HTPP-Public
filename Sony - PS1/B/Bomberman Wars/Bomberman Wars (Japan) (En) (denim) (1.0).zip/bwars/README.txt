Bomberman Wars English Translation
Version 1.0 - 03/Jan/2016

========= Staff =============
***RomHacking
Denim from www.romhacking.net.br

***Translator
Plasma Captain from www.bombermanboard.com

========= About =============
In 2009, Plasma Captain translated some text from Bomberman Wars and posted it at Bomberman Board. As they lacked the romhacking skills, they hoped for someone able to do the hack in PSX. Some few years later, I was willing to try translating a PSX game so I could study some ASM in R3000. I chose Bomberman Wars because it is a game that I played a lot in the past and it is very fun. As I don't know Japanese, I searched for a translation over internet. Luckily I found Plasma's text. ~ Denim

Bomberman Wars is a turn-based strategy game. Each player controls a set of Bombermen, moving them around the board and placing bombs to trap and blow each other up. There's really nothing quite like it, and unfortunately, the game was never released outside of Japan. I imagine that a lot of people who don't know any Japanese were afraid to try it because it is menu-based. Thanks to Denim, with this patch, Bomberman Wars is a lot more approachable to us foreigners. ~ Plasma Captain


========= Notes =============
Version 1.0
- Speeches were not dubbed. We didn't have people to do that....
- Error messages of real hardware weren't translated. 

======= How to patch ========.
Use beat from byuu (http://www.romhacking.net/utilities/893/). Apply over ISO file "Bomberman Wars (J) [SLPS-01347].bin", CRC-32 0D123C88.
