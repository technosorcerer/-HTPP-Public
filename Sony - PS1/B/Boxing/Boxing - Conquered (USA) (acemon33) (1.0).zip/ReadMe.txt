=====================================================
----------------- Boxing Conquered ------------------
=====================================================

-------------------- Description --------------------
Unlocks All characters at the beginning of the game.

----------------------- Info ------------------------
Game name: Boxing
Console: PlayStation 1
Game ID: SLUS_013.09
Hack version: 1.0
Patch: xdelta file format
Patcher: DeltaPatcher / xdeltaUI
File/ROM CRC32:   6D195B0D
File/ROM MD5:     B493F941E1A1846108B03016D806B0D8
File/ROM SHA-1:   4df12b4afc8f2416268c3f853dfa704d51216073

----------------------- v1.0 ------------------------
* Unlocks All characters

=====================================================

-------------------- How to Use --------------------
Use DeltaPatcher on a clean vanilla image file (.bin) to apply the patch.
Download any of these links:
https://github.com/marco-calautti
https://www.romhacking.net/utilities/704/
https://www.romhacking.net/utilities/598/
https://romhackplaza.org/utilities/xdelta-ui-utility/

=====================================================

--------------------- Contact Me --------------------
Author:  acemon33
E-mail:  zaxmon33@gmail.com
Discord: acemon33#3218
github:  https://github.com/acemon33