﻿=======================================================
======================Brave Prove======================
========================V 1.1a=========================
Genre: ACT/RPG

Source language: Japanese

Platform: PlayStation

Patch language: English

Author: paul_met/aishsha/Pennywise

E-mail:	paul294met@gmail.com
	http://meduza-team.ucoz.net
        aishsha@gmail.com
        aishsha@blogspot.com
	http://yojimbo.eludevisibility.org/
 
======================================================
Background
======================================================
This is a complete English patch for Brave Prove
translating the game from Japanese into English.
This product is a hardcore action rpg which could
probably be recommended to those who love the Thor/Oasis
and Alundra franchises. Lush cartoonish worlds,
catchy soundtrack and "not a mediocre" difficulty
with tons of attack combos will be familiar for all
those who witnessed the onset of the genre back on
Sega Mega Drive.
======================================================
Patching Instructions
======================================================
 - In order to apply a "ppf" format patch, you will
   need a utility known as "ppf-o-matic" which can
   be found at http://www.romhacking.net/utilities/356/;
 - It is recommended to patch a disc image compatible
   with the one from "redump.org" (http://redump.org/disc/34167/)
   or use your own dumo in the bin/cue format with
   Mode2/2352 parameters.
-  The Version 1.1a fixes the internal memory issue
   resulting in very hard to track and replicate
   occasional glitches with the use of items.
======================================================
Manual
======================================================
We have also fully translated and edited the game's
manual which you can find in the CBR format. Please,
use the http://www.cdisplay.me/ software to view it
properly.
======================================================
paul_met's comments
======================================================
Long ago, I was under impression of "The Story of Thor",
released on the Sega Megadrive / Genesis. I started looking
something of this style on other platforms as well when
someone advised me to try out "Brave Prove" on PlayStation 1.
The game turned out to be the game I had been looking for.
Cartoonish 2D visuals, top view, elemental allies and
real-time battles. Japanese was the only barrier standing in
the way to the game's plot. At the same time, I lacked the
romhacking skills required to crack the game. However, I managed
to be somewhat successful with PS1 hacking over the flow of years
and got back to "Brave Prove" for another attempt.
It's worth mentioning that the game is very "hacking-unfriendly".
Almost all the resources are repeared over and over again
(text, graphics and even code). Therefore, the technical part
was a really hard nut. I had to apply some tricks to reach
an acceptable output.
Here you are, though. Due to coordinated work of our team
working real hard on this translation, the audience now has
a chance to witness thios blast from the past and have taste
of the gaming industry straight from the 90s!
======================================================
aishsha's comments
======================================================
Another one of my "long term construction projects".
This one started a loooong time ago and might be
counted as my first collaboration with paul_met.
Come to think of it, this one is almost ten years old...
The game has gone through a series of ups and downs,
including a complete hacking rehaul due to a nasty
coding system it applies.
In terms of style, this is a typical thorish or
alundrish kind of adventure which can easily eat
up to 20 hours of your time due to hardcore difficulty
and spinning dungeon designs with a generally light-
hearted plot (which has a place for sorrow and grief,
though) and another "rarely speaking protagonist".
As usual - enjoy the game, it was a long road, and
I'm honestly glad it has come to a successful end.
Buy the original game if you like it (and no, I don't
mean the reproduction shit parasyting on other people's
work while covering it in their greed with honest reasons
and desires "to save the industry"). Search ebay,
the game's still there if you want it.
======================================================
Pennywise's comments
======================================================
I remember aishsha sending me some text for Brave Prove
wayyyy back. So this translation is definitely an old
one that finally got finished. Especially nice to see
the translation shine with some quality hacking to go
along with it. As for the game itself, you can't beat
a new action-RPG for the PSX to play in English for the
first time. It might not rank among the very best games,
but it's pretty damn solid with some beautiful artwork.
One thing I will say is that it'll probably drive
completionists nuts trying to get everything.
I played through the game twice, cheated the second
time and I STILL couldn't find/get everything.
======================================================
cccmar's comments
======================================================
Brave Prove is an interesting Action RPG for the PSX.
I didn't fully know what to expect when I was asked to
test it, but it turned out to be quite an interesting
endeavor. The game might remind you of some similar
titles in the genre, albeit with a twist – most of the
moves can be chained together into combos. They're not
extremely complex or anything, but they add flavor to
the combat as such. The same goes to spells, which can
be triggered by using various button combinations (read
the manual, it will surely help you later on in the game!)
My main issue with the game is that the dungeons are way
too long, but at least there are relatively generous save
points scattered throughout. Overall, it’s pretty fun and
I hope you enjoy it, in spite of some gripes here and there.
======================================================
Disclaimers
======================================================
All the materials in the game are purely copyrights
of Data West. The game developers did their
best and put a lot of hard work into this project,
so BUY THE ORIGINAL GAME IF YOU LIKE IT AND NOT
THE REPRO SCAMMER'S MAKEUPS TRYING TO RIP YOU OFF!!!
======================================================
Credits
======================================================
paul_met - initiator, coordinator, hacker and designer

aishsha - translation, testing, manual works

Pennywise - testing, editing

DrMefistO - compressor/decompressor tool for graphics

esperknight - misc and auxilliary hacking.

Ryusui - misc spot translations

TheMajinZenki - misc spot translations

cccmar - major testing


Xanathis - testing

All those who contributed into this process.

======================================================


Compiled by aishsha. February 2020.