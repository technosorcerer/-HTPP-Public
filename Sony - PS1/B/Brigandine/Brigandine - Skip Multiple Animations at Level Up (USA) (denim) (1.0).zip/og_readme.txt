Brigandine - The Legend of Forsena (Psx)
level up improvement patch

by denim - romhacking.net, romhacking.net.br
-------------------------------------

This patch is designed to remove the multiple level up animation that is displayed when any
character gains enough experience to level up more than once. Thus, instead of multiple
screens showing the status change for each level, with this patch, the game will only show the final
level reached, displaying the sum of all attributes won.

To use it, apply the patches using xdelta directly in the bin file.

Compatible files
----------------

These patches are compatible with the following version of the game:

Brigandine - Legend of Forsena [U] [SLUS-00687].bin
MD5: C1F4B1675F5D4493C242969E8FA1897A
