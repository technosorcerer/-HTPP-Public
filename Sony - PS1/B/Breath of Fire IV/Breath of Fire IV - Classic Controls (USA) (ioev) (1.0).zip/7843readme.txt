          -=- Breath of Fire IV (USA) - Classic Controls v1.0 -=-
          By ioev, email: zimmatic@gmail.com, discord: ioev#3061
                       Released on January 18, 2023

A patch that restores the original Japanese button layout along with a few
small tweaks:

* A mini-game involving Nina, jump is left as X from the US release, instead of O.
  This keeps the controls more in line with the default layout where X activates
  a character Action (Nina's is to fly/jump up in the air.)
* A block moving puzzle, O and X have been swapped so that O pushes a block away,
  and X pulls a block towards you.  Not only did the original feel backwards, it
  also contradicted the help text.


                         -=- Full Changelist -=-

* The 4 selectable controller layouts reverted to the Japanese equivalents
* Various mini-games, map, fishing, etc. had controls reverted/updated
* Controller icons in prompts, on screen display, and dialogue have been updated


                     -=- Installation Instructions -=-

This patch is for the redump verified iso:  http://redump.org/disc/1222/

Patch track 1 with the included xdelta file, and make any necessary changes to
your cue file if the filename changes.

Please let me know if you run into any problems!


                              -=- Thanks! -=-

A HUGE special thanks to navarchos who helped me out extensively on the
romhacking.net forums.  No joke, without their help this patch would not exist.

I also want to thank Klarth, the author of TileShop, who helped me get started
on the graphics editing, and also to team of PCSX-Redux who helped me figure
out some of the more advanced debugging features.


                            -=- Tools used -=-

* PCSX-Redux, Duckstation, NO$PSX (debugging and testing)
* jPSXdec (extracting the iso)
* TileShop (updating graphics for the map, fishing scene, battles)
* HxD (for a little bit of everything)
* Some custom Ruby/C# stuff for searching/patching
* psx-mode2 (inserting modified files back into the iso)
* MiSTer PSX Core (for final testing/playthrough)
