
  *********************************************************************************************************************
  *********************************************************************************************************************
  **                                                                                                                 **
  **  ############                       #                #       ######   #                                         **
  **  #####  #####                       #                #       ##   ##  #                                         **
  **      #  #     #       #  #   ###  ######  ####    ## #       ##   ##  ####     ####    ####   #####   #  #   #  **
  **      #  #     #   #   #     #       #    #    #  #   #       ## ###   #   #   #    #  #    #  #    #      # #   **
  **      #  #      #  #  #   #   ##     #    #####   #   #       ##       #    #  #    #  #####   #    #  #   ###   **
  **      #  #      # # # #   #     #    #    #       #   #       ##       #    #  #    #  #       #    #  #   # #   **
  **      ####       #   #    #  ###     #     ####    ###        ##       #    #   ####    ####   #    #  #  #   #  **
  **                                                                                                                 **
  *********************************************************************************************************************
  *********************************************************************************************************************


Breath of Fire IV (Playstation 1)
Patch Version: Beta 1.00 - 2021/04/30
Release in German language


--------------------------------------------------------------------------
	Patch information
--------------------------------------------------------------------------

This patch is for Breath of Fire IV for Playstation 1.
The whole game including graphics has been translated into German language.
For the patch the NTSC-U-version of the game is required.

Serial: SLUS-01324

BOF4 Beta v4 DAO.xdelta
Type: Disc at Once Image (Single File Image)
Size: 688.315.152 Bytes
CRC32: db4f4706
MD5: 96d1bec91f1c8e956a94dd7dd7326d9b
SHA1: ccf902616e6275adec54392302d6cbde9b3b1380


BOF4 Beta v4 TAO.xdelta
Type: Track at Once Image (Seperated File Image, redump.org)
Link: http://redump.org/disc/1222/
Size: 645.066.576 Bytes
CRC32: 29d0f94c
MD5: 145a7d7ac3469fcb974bbb309ebd61b1
SHA1: 24be71b32aeb52a930bc08dccda5db61e904de8a


--------------------------------------------------------------------------
	Project team
--------------------------------------------------------------------------

Poe		- Project manager, translation, correction and testing
manakoDE	- Hacking, programming, graphics, correction
leitwolf	- Advice, translation
Aka		- Beta test, correction, comma master
deadzack	- Beta test
Degreeno	- Beta test, correction
Kekslabor	- Translation
RetroDima	- Graphics
Toremneon	- Beta test
TundraG3ckO	- Beta test, graphics, correction, riddle master


--------------------------------------------------------------------------
	General information
--------------------------------------------------------------------------

This path is for free and we disassociate ourselves from commercial abuse.
Using the patch happens on your own risk.
The members of Twisted Phoenix can't be prosecuted for loss or damage when your're using the patch.


--------------------------------------------------------------------------
	Greetings & thanks
--------------------------------------------------------------------------

Many thanks to leitwolf and manakoDE for giving me the opportunity to translate the game.
And many thanks for your mental & hacking support throughout the whole time.
Many thanks to Aka and TundraG3cko for their excellent support during the beta test and the rest of the project team.
Also many thanks to RetroDima and TundraG3cko for offering the great graphic support.
Special thanks to the community of SNES-Projects and Red Scorpion where everything began.