uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu
Breath of Fire IV: Working Identify Ability Hack
By navarchos/rh
2022-01-17 (v1.1)
nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn



-------------------------------------------------------------------------------
Table of Contents

0. Compatibility
1. Patching
    [1A] Patching for use in new games
    [1B] Patching for use in pre-existing save files
    [1C] Patching for use in both new games and pre-existing save files
2. Use
3. Changes
4. Known Issues
5. Changelog
-------------------------------------------------------------------------------



0. Compatibility
    The patches are intended for use with the NA release of the game 
    (SLUS-01324). In the future, I plan to make patches for the EU release.


1. Patching
    The patch files come as .PPF files, use PPF-O-Matic 
    (https://www.romhacking.net/utilities/356/) to patch your .BIN file.
    The archive file contains multiple patch files. 
    Each file's is named as "identify_n.ppf", where n is a number indicating at 
    which level Scias receives the Identify ability. Each patch includes the 
    undo data, which means you can also use it to get back the unpatched .BIN 
    file.

    [1A] New game:
    If you would like to start a new game with Scias being able to use
    Identify from the moment he joins your party, use the "identify_3.ppf"
    patch. 

    [1B] Pre-existing save: 
    If you would like to use the ability in a pre-existing save file,
    choose a patch file with the next closest level to Scias's current level
    in your save file. For example, if Scias is currently at level 23, and you 
    would like to be able to use Identify, patch your .BIN file with the
    "identify_26.ppf" patch, and level Scias up to level 26 to obtain
    Identify.

    [1C] Both:
    If you would like to use Identify in a pre-existing save file and in a new
    game, then you should first patch for the pre-existing save file, level up
    until Scias gets Identify, then undo that patch in PPF-O-Matic, and finally,
    patch using the "identify_3.ppf" patch. After acquiring Identify, using any
    of the patches should still work.

    I realize that the patching process is very complicated for pre-existing
    save files. An easier method would be to edit the save file and add 
    Identify to Scias' array of Magic spells. However, editing the save file
    would require changing the checksum, and I'm still not sure what kind of
    checksum algorithm Breath of Fire IV uses. Therefore, any attempts at
    changing the save file will most likely result in a corrupted file error
    when trying to load the file.


2. Use
    Identify is given to Scias as one of his starting abilities if you are
    using the "identify_3.ppf" patch with a new save file, or as an unlockable
    ability by levelling up, if you use any other patch.
    Identify costs 0 AP to use. When using the ability, you'll be presented
    with detailed information about the enemy.

    On the right side of the screen you will notice two panels appear. The top
    one shows the elemental weakness of an enemy, the enemy's current HP, 
    max HP and EXP drop. Each element is indicated by an icon, and the color
    of each icon represents the enemy's resistance level against that element.
    From left to right, top to bottom, the elements are:

    Fire    Wind    Water   Earth     Holy    Mind    Status  Death
    Melee   Ranged  Magic   Breath

    There are three possible resistances indicated by the color of the icons:
    - Red: The enemy is weak against this element. If an enemy is weak against
    an element, they take more than 100% of the normal damage done by that
    element. For most elements this mean a resistance value of 0-1, but in the
    special case of Holy, this means a resistance value of 0-4.

    - Black: The enemy has normal resistance against this element. Enemies with
    normal resistance against an element take 100% of the normal damage done
    by that element. For most elements this means a resistance value of 2, but
    in the special case of Holy, this means a resistance value of 5.

    - Blue: The enemy is strong against this element. If an enemy is strong 
    against an element, they take less than 100% of the normal damage done by
    that element. Resistance level 7 means the enemy absorbs the damage done
    by the element as HP. For most elements this means a resistance value of
    3-7, but in the special case of Holy, this means a resistance value of 6-7.

    The bottom panel shows the amount of zennies drop by the enemy, and the
    enemy's item drops. The first item in the list can be stolen, while the
    second item can only obtained from drops. If an item's name is "////////",
    it means that you have not obtained that item before. This is a known issue,
    see section 4.

    The text box at the bottom of the screen shows some more information about
    the enemy, such as hints and tips provided by the game itself.

    Everything else about this ability, such as the graphs and the "POSITION"
    indicators appear to be merely gimmicks.


3. Changes
    Before describing the changes made, it's worth explaining why Identify was
    removed from the English language versions of Breath of Fire IV.
    In the Japanese release, the elements are indicated using a single Kanji/
    Chinese character. It looked something like this:

    火風水土聖精狀死
    斬射魔竜

    If that looks garbled, knwo that it's partially my fault for not taking
    encoding into account while writing this readme. Sorry about that.
    A screenshot link has been provided below.

    Each element's name fits in exactly one character. However, as we know,
    these names are significantly much longer in English, thus the result was
    an overlap between each element's name in English, which looked something
    like this:

    Fire
     Wind
      Water
       Earth
        Holy
         Mind
          Status
           Death

    Where all of the words above are printed on the same line. If that wasn't
    clear at all, then these two screenshots should clear things up:
    
    Japanese: https://tcrf.net/File:BOF4-Identify3.png 
    NA/EU: https://tcrf.net/File:BOF4-Identify2.png

    What a mess.

    The translation team didn't come up with any other idea to solve this, and
    instead chose to remove Identify from the game.

    A workaround I found was replacing each element's name with the element's
    icon. As an icon takes up the same space as a single character, it would
    fit and there would be no overlap among the element's names.

    The trouble was getting the icons to look right. Wind, Stat-Down (which I
    used for the Mind element) and Holy didn't look good when they were
    colored using the single-color palettes, so I had to make a copy of those
    icons with the appropriate colors so they'd look slightly better.

    Originally the color grey was used to indicate normal resistance. However,
    I found that grey didn't stand out enough when used with the element icons,
    so I switched to using black instead.

    And finally, I had to add the skill back to Scias' level up table. This is
    pretty easy, each entry in the table is 8 bytes wide, and the 6th byte is
    the byte used to indicate the skill acquired at that level.


4. Known Issues
    There are currently no known issues. If you do find any, don't hesitate to
    send me a private message via romhacking.net


5. Changelog
    (2022/01/16) v1.1 Question marks for unknown items no longer share the same
    pointer as the slash which separates current HP and max HP. In addition,
    adjusted the spacing so that each question mark doesn't take up as much
    space as it used to.

