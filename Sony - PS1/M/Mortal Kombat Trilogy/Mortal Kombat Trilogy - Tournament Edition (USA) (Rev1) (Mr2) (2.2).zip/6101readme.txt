﻿------------Mortal Kombat Trilogy--------------
----------TOURNAMENT EDITION------------
--------------------------Info---------------------------
Game name: Mortal Kombat Trilogy
Console: PlayStation
Game ID USA: SLUS-00330
Hack version: 2.2
Patch: PPF(PlayStation Patch Format)
Patcher: ppf-o-matic3
----------------------------------------------------------
Mortal Kombat Trilogy (Rev 1) game file "TRILOGY.EXE" MD5:
0be7230a074402b2f71a635ca8ce0e6f
----------------------------------------------------------
 *The version number of the modification is displayed on the history screen.
----------------------------------------------------------
---------------------------v1.0-------------------------
The patch contains the following changes:
 A menus slowing down of the game loading is disabled.
 Wins reset is disabled.

----------------------------------------------------------
------------------------v1.1----------------------------
The game ID is fixed.(uses in online game via kaillera client)

----------------------------------------------------------
------------------------v1.2----------------------------
The bosses selection in two players mode is blocked.(to unlock the bosses you need activate the cheat menu)
Random bosses selection is blocked.(if bosses are blocked)
Added hidden selection of characters Start + [].

----------------------------------------------------------
------------------------v1.3----------------------------
Removed infinite combos of Noob Saibot. 
Removed x2 blade spin combo of Baraka.
Duplication of the scream during running is fixed.
Game bonuses: greatest victory & fast end is added.

----------------------------------------------------------
------------------------v1.4----------------------------
Game bonuses: greatest victory & fast victory is corrected.

----------------------------------------------------------
------------------------v1.5----------------------------
Removed infinite combo of Noob Saibot through teleport & 3 jabs.
 *After 5 hits combo, teleport is blocked.

----------------------------------------------------------
------------------------v1.6----------------------------
Removed infinite combo of Rain through super roundhouse & jab.
 *After 7 hits combo, super roundhouse is blocked.

----------------------------------------------------------
------------------------v1.7----------------------------
Сhanged and expanded options menu functionality:
 /\ - exit from menu.
 [] - add 10 to numeric parameter.
 O - reset numeric parameter.
The number of wins parameter is added.
 *To restore the count after the network disconection.(Kaillera client)
The match recycle parameter is improved.(game konfigure -> match recycle)
 *Auto reset of the counter is added.
The bosses unlocking parameter is added to cheat menu.(2 players mode)

Practice mode is added. 
 *The bug with disabling special moves is fixed.

Launching of special moves for Jax P2, while holding the O button is fixed. 

----------------------------------------------------------
------------------------v1.8----------------------------
The options menu code is corrected.
Launching of special move(Gotcha Grab) for Jax(MK2) P2, while holding the O button is fixed. 

----------------------------------------------------------
------------------------v1.9----------------------------
Damage calculation in practice mode is fixed.

----------------------------------------------------------
------------------------v2.0----------------------------
Added hidden selection while sprites of characters is visible.
 *Options -> Game Konfigure -> Select screen: on.
Unlocked the characters selection for Shang Tsung's morphing, in practice mode.
The bosses is unlocked in practice mode.

----------------------------------------------------------
------------------------v2.1----------------------------
If bosses are blocked, MK1/MK2  fighters are displayed instead of them on select screen.

----------------------------------------------------------
------------------------v2.2----------------------------
The CPU opponents skills is equivalent to the selected difficulty level of the game.

----------------------------------------------------------
For changing the game name, use cpka1.3HATEMOD.dll.
Download link:
https://disk.yandex.ru/d/q79tyaBhr7yMzA
--------------------PPF Patcher------------------
Download link:
http://www.romhacking.net/utilities/356/
http://rgcorp.ucoz.net/load/patches/ppf_o_matic3/3-1-0-30
----------------------------------------------------------
Author by Mr2.
e-mail: rgcorpsoft@gmail.com
http://rgcorp.ucoz.net/