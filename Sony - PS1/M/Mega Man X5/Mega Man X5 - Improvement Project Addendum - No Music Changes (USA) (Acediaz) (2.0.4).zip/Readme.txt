========================================================================================
Mega Man X5 Improvement Project Addendum (v2.0.4) by acediez - 2022.07.04
========================================================================================

Links:

	Download Page (ALL VERSIONS, including music changes!)
	https://archive.org/download/mmx5_improvement_project_addendum
	
	"Mega Man X5 Improvement Project Addendum" RHDN Forum Thread:
	http://www.romhacking.net/forum/index.php?topic=29471.0
	
	"Mega Man X5 Improvement Project" RHDN Forum Thread:
	http://www.romhacking.net/forum/index.php?topic=22796.0
	
	"Mega Man X5 Improvement Project" RHDN Project Page:
	https://www.romhacking.net/hacks/3711/
	
Target File:

	Mega Man X5 (USA).bin
	MD5: 98C0D278DC4A795A0A7562D950D37CC9
	http://redump.org/disc/7437/
	
The patch format is "xdelta", which can be applied using xdeltaUI:

	xdeltaUI in RHDN
	https://www.romhacking.net/utilities/598/


========================================================================================
Features
========================================================================================

Included changes from the original Improvement Project (v0.01.1):

- Keep both character bonuses regardless of which one is chosen
- Each Heart Tank/Life-Up Part affect both X & Zero
- Save/Load menu was given a redesign
- Fixed the 'injured' sprites for X & Zero

Addendum changes:

- Graphics:
   - Title Screen restored from the japanese version (custom graphics by Metalwario64)
   - Mavericks renamed to their japanese/MMXLC2 names (custom graphics by Metalwario64, based on MMXLC2 new graphics, ripped by DarkSamus993)
- Script:
   - Main version: Complete script replacement, based on Hondoori's translation. Edited by Ghaleonh41
   - No Retranslation: the original USA version's script and font, except for various typos corrected, and Mavericks renamed to their japanese/MMXLC2 names.
- Soundtrack: (optional)
   - Opening theme replaced with the japanese opening song "Monkey"
   - Ending theme replaced with the japanese ending song "Mizu no Naka"
   - Tidal Whale's stage theme changed to the unused track "Deep Sea"
   - X's "Good" Ending theme changed to the unused track "Armageddon"   
   - Dr. Light's theme changed to the unused "Dr. Light" track.
   - Stage Select 2 theme changed to the unused "Stage Select" track.
- Voice clips restoration:
   - X's Charged Shot
   - Zero's Giga Attack
   - X and Zero on low health
   - Maverick introduction name calls
   - Dynamo's voice clips
- Parts Unlocking:
   No need to waste "hours". All available in a single playthrough.
   - Get Life Up/Energy Up at any level
   - Get Life Up+/Energy Up+ (Parts) at any level
   - Get both Parts regardless of Life Up+/Energy Up+ selection.
- Enigma/Shuttle RNG exceptions:
   - Enigma/Shuttle launch with no parts will always fail.
   - Shuttle launch with all 4 parts will always succeed.
- Stage modifications:
   - Tidal Whale's Stage: Auto-scrolling segments run faster (100-125% horizontally, 150% horizontally).
   - Tidal Whale's Stage: U-5555 (mini boss): smaller health bar (75%), but deals more damage (about 150% each attack).
   - Dark Necrobat's Stage: slowdown gimmick removed.
   - Zero Space 1: the inner walls in the laser segments are now not grabbable.
- More options to explore areas:
   - More weapons can break stage objects blocking items in Tidal Whale's, Shining Firely's and Dark Necrobat's stages.
   - Dark Hold protects you from spikes.
   - F-Splasher and can push V-Blocks.
   - More forgiving orb collecting in the Ride Chaser segment (you only need 7 out of 8)
- Incomplete Armors:
   - Armors can now be selected as soon as you get a part for it. While incomplete, they'll be displayed as unarmored X with a custom palette (see details below)
- Gameplay:
   - Dark Hold: can be cancelled.
   - F-Splasher behaves like a regular air dash (can be cancelled)
   - W-Shredder: input changed to Dash + Special
   - Disabled double tap dash input
   - Falcon Armor: gets a custom air dash with the same properties as the "free move" flight.
   - Gaea Armor: can slide down walls by pressing down. Dash speed penalty removed.
- Rebalancing:
   - Gaea Armor: buster damage against common enemies increased.
   - Z-Saber: damage against main bosses decreased.
   - Z-Buster: startup delay sligthly reduced.
   - Longer/harder "X vs. Zero" fight (damage tables reduced)
- QoL:
   - Alia's hints can be turned off from the options menu
   - Cutscenes and dialogues skip by pressing START
   - Cheat Code to unlock Ultimate Armor will keep the Fourth Armor selectable
   - Cheat Codes to unlock Ultimate Armor and Black Zero can be combined 
   - Faster pause menu transitions
   - Exit Button always available, can be used to skip intro stage.
	
	
========================================================================================
Customization
========================================================================================

Additional modifications are provided here in the form of hex edits.
If you've never replaced hexadecimal data in a file before, here's some basic instructions:

1. 	Download: 	HxD (https://mh-nexus.de/en/hxd/)
				EDC/ECC recalculator (https://www.romhacking.net/utilities/1264/)
2. 	After patching, open the modified BIN in HxD
3. 	Press "Ctrl+G" to jump to an address. Use "hex" mode, set offset relative to "begin".
	Paste the addresses listed, and you should find the original values I'm providing.
4. 	Paste the modified hex data with "Ctrl+B" (while Ctrl+V is a "add-paste", Ctrl+B
	is a "overwrite-paste"). Make sure the hexadecimal side of the window is selected
	(the middle column), and the pointer is at the correct address (check the status bar
	at the bottom).
5. 	Repeat 3 and 4 for all the changes you want to make.
6. 	Save and exit.
7. 	Run the modified BIN through the EDC/ECC recalculator. This step is not necessary
	for certain emulators, but it is to play on original hardware and on the more
	accurate emulators.
	
When there's multiple entries listed, you need to modify all of them for the change to
work correctly.

Also note that these addresses will not match an unmodified Mega Man X5 BIN.

I recommend you keep a copy of the patched BIN before you make any manual edits,
so if you make any mistake you can start over.

IF YOU EDIT YOUR BUILD AND SOMETHING SEEMS BROKEN, PLEASE MAKE SURE IT ALSO
HAPPENS ON AN UNMODIFIED BUILD BEFORE REPORTING IT AS A BUG!


Remove Timer
-----------------------------------------------------------------
Remove timer from Stage Select screen
BIN Address: 		173EE4
HEX Data Original: 	02004014
HEX Data Modified: 	00000000

Remove timer from Load File menu (Title Screen)
BIN Address: 		1C46C
HEX Data Original: 	71004010
HEX Data Modified: 	FB700008

Remove timer from Save File menu (Mission Report)
BIN Address: 		181F38
HEX Data Original: 	71004010
HEX Data Modified: 	16C90308

Remove block containing timer text in Load/Save menus
BIN Address: 		3CF83C
HEX Data Original: 	0013B0F80024C0F80024D0F80024E0F80024F0F8002400F8002410F8401320F8
HEX Data Modified: 	000E0B0F000E0B0F000E0B0F000E0B0F000E0B0F000E0B0F000E0B0F000E0B0F

Remove timer from Mission Report
BIN Address: 		17E24C
HEX Data Original: 	04004010
HEX Data Modified: 	82BB0308

Disable running out of time event (Cutscene leading to final stages)
BIN Address: 		17F504
HEX Data Original: 	0B00401C
HEX Data Modified: 	9FBF0308

	
Hide Virus Status UI (Effects still apply)
-----------------------------------------------------------
BIN Address: 		27170
HEX Data Original: 	0C004380 
HEX Data Modified: 	00000334 


Enable Title Screen voice clip ("Rockman X5")
-----------------------------------------------------------
BIN Address: 		1FB28
HEX Data Disabled: 	218000002000B4AF
HEX Data Enabled: 	3646000821800000

BIN Address: 		1FBAC
HEX Data Disabled: 	0800E003
HEX Data Enabled: 	D07C0008


Always get both Life Up and Energy Up upgrades
-----------------------------------------------------------
BIN Address: 		17F0A8
HEX Data Original: 	07008314
HEX Data Modified: 	00000000

BIN Address: 		17F100
HEX Data Original: 	00000000
HEX Data Modified: 	340185AC


Receive All Parts on the Next Hour
-----------------------------------------------------------------
After unlocking Parts (Life Up, Energy Up, or equipable Parts),
you normally have to wait one hour (a stage run) to get your Life/Energy part,
and two hours (two stage runs) to get the equippable part(s).

With this modification, you'll get them all at once after one hour.

BIN Address:        17F1F8
HEX Data Original:  3E004014
HEX Data Modified:  00000000


Change number of Parts equipables by armor
-----------------------------------------------------------------
You can set them to be able to equip as many as you want,
but the UI will only display up to 4. Also consider that some
Parts might not be coded to work with Gaea Armor at all.

X (Unarmored)
BIN Address: 		177048
HEX Data Original: 	04

X (Fourth Armor)
BIN Address: 		177049
HEX Data Original: 	02

X (Falcon Armor)
BIN Address: 		17704A
HEX Data Original: 	02

X (Gaea Armor)
BIN Address: 		17704B
HEX Data Original: 	00

X (Ultimate Armor)
BIN Address: 		17704C
HEX Data Original: 	02

Zero
BIN Address: 		17704D
HEX Data Original: 	04


Fourth Armor - Armor Skills Nerfs
-----------------------------------------------------------------
If you want some extra incentive to use the other armors.
If you're using these, I also recommend not allowing this armor
to equip any Parts (previous section)

Fourth Armor: Disable Damage Reduction
BIN Address: 		34B60
HEX Data Original: 	14006210
HEX Data Modified: 	15006210

Fourth Armor: Disable Knockback Reduction
BIN Address: 		34F4C
HEX Data Original: 	FFFF42240400422C
HEX Data Modified: 	FEFF42240300422C

Fourth Armor: Modify Charged Shot Remnants Duration
(This won't work on vanila. I wrote custom code to not affect Ultimate)
BIN Address: 		101E0
HEX Data Original: 	5A  Remnants hit ~5 times.
HEX Data Modified: 	00  Minimum. Looks off, because the Charged Shot passes through.
						You're used to see something collide.
					04  Just enough to see the remnant end animation (recommended)
					08  Just enough for the remnant to hit 1 time.
					
Ultimate Armor: Modify Changed Shot Remnants Duration (Bonus)
BIN Address: 		101E4
HEX Data Original: 	5A


Fourth Armor - Enable Nova Strike
-----------------------------------------------------------------

Fourth Armor: Enable Nova Strike
BIN Address: 		43528
HEX Data Original: 	FEFF62240300422C
HEX Data Modified: 	FFFF62240400422C

Fourth Armor: Display Giga Attack on Pause Menu
BIN Address: 		36BF8
HEX Data Original: 	FEFF63240300632C
HEX Data Modified: 	FFFF63240400632C


Continues restart the stage (Experimental!)
-----------------------------------------------------------------
Makes Continues take you back to the start of the stage.
This hack isn't implemented completely and hasn't been throughly tested.
Data from your playthrough might not register correctly (collectibles
you got before dying, Mavericks beaten in the boss rush, etc.) 

BIN Address: 				222B4
HEX Data
	Back to checkpoint:		09
	Back to stage start:	08


Enable Item Drops in Xtreme Mode
-----------------------------------------------------------------
BIN Address: 				5CC1C
HEX Data Disabled):			29004010
HEX Data Enabled):			00000000


Change Default Game Options
-----------------------------------------------------------------
BIN Address: 				7C373
HEX Data Original: 			08
HEX Data Current Version:	18

Reverting to the original "08" will make Navigator "OFF" by default.
I thought you'd like to know that.

To turn "ON" or "OFF" any of the other settings by default, add:

+01 	Auto Charge
+02		Rapid Fire
+04		Vibration
+08		Enable Crouching (has to be enabled by default, can't be changed in-game!)
+10		Navigator

Values are hexadecimal (so "02 + 08" isn't "10", it's "0A")


Change Default Button Configuration
-----------------------------------------------------------------
BIN Address:						7C384	

									A	 B    C    D    E    F    G
HEX Data Original:					8000 1000 0200 4000 2000 0800 0400 

	[A] X-BUSTER, Z-SABER			Square
	[B] SPECIAL WEAPONS, Z-BUSTER	Triangle
	[C] GIGA ATTACK					R2
	[D] JUMP						X
	[E] DASH						O		
	[F] WEAPON SELECT R				L2	
	[G] WEAPON SELECT L				L1
	
									A	 B    C    D    E    F    G	
HEX Data Example:					8000 1000 0800 4000 0400 0200 0100

	[A] X-BUSTER, Z-SABER			Square
	[B] SPECIAL WEAPONS, Z-BUSTER	Triangle
	[C] GIGA ATTACK					R1
	[D] JUMP						X
	[E] DASH						L1		
	[F] WEAPON SELECT R				R2	
	[G] WEAPON SELECT L				L2
	
Reference:

	8000 = Square
	4000 = X
	2000 = Circle
	1000 = Triangle
	0800 = R1
	0400 = L1	
	0200 = R2
	0100 = L2
	
	
========================================================================================
Reverse changes
========================================================================================

Some modifications included in the patch can be reversed following the same process.


Music changes 
-----------------------------------------------------------------
These three audio changes can be reverted by code, since the
original music track still exist in the game.

Credits Song
BIN Address: 		186C34
HEX Data Original: 	1C		--> Instrumental theme
HEX Data Modified: 	1F		--> "Mizu no Naka"

X's "Good" Ending Theme
BIN Address: 		220734
HEX Data Original: 	02		--> Intro Stage Theme (Reused)
HEX Data Modified: 	20		--> Armageddon (Unused Track)

Stage Select 2 Theme
BIN Address: 		172094
HEX Data Original: 	17		--> Zero Space Stage Theme (Reused)
HEX Data Modified: 	21		--> Stage Select (Unused Track)

Dr. Light and Tidal Whale's Themes can't be changed back by code because
the original audio files have been replaced to make room for the new ones.
To revert these two tracks, you'll have to use the "no music changes"
alternate patch.

To revert the opening movie only, you can use the "all music changes
except the opening song" (and then, if you also want to remove the
credits song, you can do it as shown above)

Other combination of changes are not possible without redoing the whole
process (editing/converting audio files, rebuilding the disc, etc.)


Incomplete Armors - Unlocking
-----------------------------------------------------------------
The game has a lot of custom code to link each armor skill to
each individual armor program instead of the complete armor.
However, to make it behave like it does in the original game,
all you have to do is revert the changes in Mission Report,
so you only obtain the armor once it's complete.
Armor skills will remain linked to the armor parts instead of the
complete armor, but that won't affect you (since you will have
to collect all 4 programs to get the armor regardless)

BIN Address: 			17F300
HEX Data: 	
	Original:			0D80023C001C4524A100A3900F0004240F0063300B00641421304000CC00A290000000000F00423006004310010002244A00A39000000000020063340800E0034A00A3A0001CC524A100A290F0000324F00044300B00831400000000CC00A29000000000F000423006004410020002244A00A39000000000040063340800E0034A00A3A04B00A3900100022403006210030002240800E003211000004A00A390020004244B00A4A0080063340800E0034A00A3A0	
	Incomplete Armors:	00008534A100A790CC00A8904A00A6900F0004340F00E330050064140F00023103004310000000000800E00301000234F0000334F000E43005008314F000023103004410000000000800E00302000234080003342610E8000B0040102A186200020060140400033402000334010004342410C300040040142510C3004A00A2A00CEA0108421003004B00A3900100023403006210030002340800E00300000234020004344B00A4A00800C3340800E0034A00A3A0

BIN Address: 			183B30
HEX Data: 	
	Original:			801F033C2000638C0F80023C0000648C0C564224300022AE
	Incomplete Armors:	0F80023C0C56423402002382D6000534F7E90108FF006330


Incomplete Armors - Palettes
-----------------------------------------------------------------
Only three colors of the unarmored X sprite palette are modified.
Here's where they are located and what the palette data for those
colors are. You can use this information to either replace the
custom palettes with the normal unarmored X colors, or modify them.

The "Highlights" colors are the ones used when X is shooting.
They're the same colors, just a bit brighter.

Unarmored X (Base)
HEX Data:					06D3 23B6 24B1

Unarmored X (Highlights)
HEX Data:					F4FF 28D7 03AD

Falcon (Base)
BIN Address: 				8CE00
HEX Data:					3E1B 3A0A 0F11

Falcon (Highlights)
BIN Address: 				8CE06
HEX Data:					DF1F 9E0E 0F11

Gaea (Base)
BIN Address: 				8CE0C
HEX Data:					B466 CC49 E628

Gaea (Highlights)
BIN Address: 				8CE12
HEX Data:					7B7F 4F62 E628

Unfortunately, the pause menu mugshot palettes are not as easily
replaceable, as they're not just palette replacements, the images
were also adjusted. If you're not happy with them, consider the
option below.


Incomplete Armors - Complete Armor Display
-----------------------------------------------------------------
Use this to display the complete armor sprite even when the armor
is incomplete. If you use this, make sure you also replace the
incomplete armor custom colors with the regular unarmored X colors
(they're visible underneath the armor)

Armor Sprite Overlay
----------------------
BIN Address: 				25E88
HEX Data:
	Full Armor:				FA00029200000000FFFF4224
	Incomplete Armors:		C4DD010CFA000392FFFF6224
	
Pause Menu Mugshot
----------------------
BIN Address: 				84874
HEX Data:					
	Full Armor:				03006514
	Incomplete Armors:		00000000

Character Select Menu
----------------------
BIN Address: 				175B88
HEX Data:					
	Full Armor:				001C22262A004480
	Incomplete Armors:		ECDE010800000000

BIN Address: 				175D50
HEX Data:					
	Full Armor:				0B006214001C22264A008290000000001000423005004010212000027A5C000C0700052475D0030800000000001C22262A004580
	Incomplete Armors:		0A006214000000004A008290000000001000423005004010212000027A5C000C0700052475D0030800000000C4F8010C001C2226

BIN Address: 				173540
HEX Data:					
	Full Armor:				02001024001C6224160030A22A004680
	Incomplete Armors:		0200103400008634DADB0108160030A2


Boss Level requirement to get Life/Weapon Upgrade
-----------------------------------------------------------------
Revert to only get Life Up/Energy Up after the defeated boss 
reaches a certain level.

BIN Address: 		17E3A0
HEX Data Original: 	04
HEX Data Modified: 	01

BIN Address: 		17F094
HEX Data Original: 	04
HEX Data Modified: 	01


Boss Level requirement to get Life/Weapon+ Upgrade (Parts)
-----------------------------------------------------------------
Revert to only get Parts after the defeated boss reaches
a certain level.

BIN Address: 		17E3BC
HEX Data Original: 	08
HEX Data Modified: 	01

BIN Address: 		17F104
HEX Data Original: 	08
HEX Data Modified: 	01


Get both Parts regardless of Life Up+/Energy Up+ selection
-----------------------------------------------------------------
Rever to only get the Part corresponding to your Life Up 
or Energy Up selection instead of both

BIN Address: 		17F118
HEX Data Original: 	12006214
HEX Data Modified: 	00000000

BIN Address: 		17F15C
HEX Data Original: 	0800E003140185AC10006214
HEX Data Modified: 	00000000140185AC00000000


Exit Stage Button (Modified = Always Available)
-----------------------------------------------------------------
BIN Address: 		36D4C
HEX Data Original: 	0C00649000000000FFFF82240800422C0B004010001604004C00639003160200FFFF4224071843000100633003006010
HEX Data Modified: 	0C0064900000033400000000090063240A008310010063240800831000000000060083100C0063240400831000000000

To only add an exception to disable the button on the Intro Stage,
keep the "modified" code and replace this line:

BIN Address: 		36D44
HEX Data Available: 00000000
HEX Data Disabled:  0C008010


Double Tap Dash
-----------------------------------------------------------------
BIN Address: 		3E0E8
HEX Data Enabled: 	8800A280
HEX Data Disabled: 	00000000


Ride Chaser segment - Orbs required to destroy wall
-----------------------------------------------------------------
It has to be set to at least 01 (or the shooting orbs event will
be skipped entirely) and obviously no more than 08.
Value has to be replaced in both addresses (the second one is for
Alia's dialogue)

BIN Address #1: 	120168
BIN Address #2: 	10F834

HEX Data Original: 	08
HEX Data Modified: 	07


Change W-Shredder Input from (Square) to (Triangle)
-----------------------------------------------------------------
BIN Address: 		47954
HEX Data Original: 	10 (Square)
HEX Data Modified: 	20 (Triangle)


Dark Necrobat's Stage Slowdown Gimmick
-----------------------------------------------------------------
BIN Address: 		38F84
HEX Data Enabled: 	2600C280
HEX Data Disabled: 	00000234


Z-Buster Startup Delay
-----------------------------------------------------------------
Values are in hexadecimal.

Each of the following addresses corresponds to one sprite of
animation. There's four bytes for each sprite. To keep it
simply, I only list the first value here. That's the number
of frames of duration.

Zero's Animation:

BIN		RAM			VALUE
8823C	8007A0B4	14  -> Reduced to 12
88240	8007A0B8	02
88244	8007A0BC	07
88248	8007A0C0	04
8824C	8007A0C4	02
88250	8007A0C8	03

For the hack, I reduced very slightly, because Zero is already
very powerful, and the Z-Buster can already be exploited very
easily by tapping the button while walking.

You could reduce it even more, but if you do, you also need to
adjust the duration of the charging animation itself (the energy
effect on top of the Z-Buster). Otherwise, the sprites may glitch
when firing rapidly.

Charging Animation:

BIN		RAM			VALUE
88258	8007A0D0	03
8825C	8007A0D4	03 
88260	8007A0D8	03
88264	8007A0DC	03
88268	8007A0E0	03

The total of frames of the charging animation must be lower.
How much lower? It varies. It takes some experimentation.

The safest approach is to reduce all the charging animation values
from 3 to 02. This will allow you to safely set the startup delay
a lot lower.

Example 1 (what's in the hack)
Startup Delay		12 		(18)
Charging animation	03 * 5  (15 total)

Example 2 (something I tried, it worked, but seemed too overpowered)
Startup Delay		0C 		(12)
Charging animation	02 * 5  (10 total)


Enigma/Shuttle Launch RNG Exceptions - Upgrades
-----------------------------------------------------------------
This hack adds three exceptions to the normal success chance of 
the Enigma/Shuttle launch:
- Enigma launched with no upgrades will always fail
- Shuttle launched with no upgrades will also always fail
- Shuttle launched with all upgrades will always succeed

Any other situation will use the normal success chance: a random
number is drawn, and the threshold for that value to be a success
increases with each upgrade. It is apparently also affected by
the number of times Zero gets the "VIRUS" status in-game.

Reverting any of these to the original value will remove the jump
to the new code, and will revert that trigger to its normal behavior.

You should be able to mix them safely. You could, for example,
revert the Enigma launch to normal while keeping the Shuttle
launch modification.

Enigma Launch from Menu (Always fail with no parts)
BIN Address: 		20B2B0
HEX Data Original: 	DEB7000C
HEX Data Modified: 	71460008

Shuttle Launch from Menu (Always fail with no upgrades. Always succeed with all parts)
BIN Address: 		16F888
HEX Data Original: 	DEB7000C
HEX Data Modified: 	7B460008

Shuttle Launch from Cutscene When Completed (Always succeed)
BIN Address: 		20E978
HEX Data Original: 	DEB7000C
HEX Data Modified: 	3FE80308


Shuttle Launch RNG Exceptions - Zero Virus Status
-----------------------------------------------------------------

The game originally lowers your Shuttle success chance to none
(or almost none) when Zero has reached the Virus status 13 or
more times throughout your playthrough.

The current implementation overrides it, so it always succeeds
when you have all 4 Shuttle upgrades, no matter what.

The modification below adds a second exception for the Zero Virus 
status count on top of the current RNG exceptions code. With this,
it will always succeed with all Shuttle upgrades as long as Zero
has been infected less than 13 times, and will always if he did,
no matter how many Shuttle upgrades you have.

This way you still have control over either option by the end of
the game.

(This hasn't been throughly tested. If you use it, please
leave a comment on the project thread and tell us how it went.)

Launch From Menu Option
BIN Address: 		16F860
HEX Data Original: 	CA0043800D000224A900249200000000020082142180030221800000
HEX Data Modified: 	0D000234A9002492CA0043800300821421800302A1BA030800000000

Launch From Cutscene After Completing Shuttle
BIN Address: 		20E950
HEX Data Original: 	CA0043800D000224A900249200000000020082142180030221800000
HEX Data Modified: 	0D000234A9002492CA004380030082142180030243E8030800000000


U-555 Rebalance (Tidal Whale Sub-boss)
-----------------------------------------------------------------
Values are in hexadecimal.
The minimum value for a lifebar is 20 and the maximum is 7F.

LIFE BAR SIZE:

Battle 1
BIN Address: 		EBC70
HEX Data Original: 	7F
HEX Data Modified: 	60

Battle 2
BIN Address: 		EBC64
HEX Data Original: 	7F
HEX Data Modified: 	60

Battle 2 - Each half's internal lifebar
BIN Address: 		E9088
HEX Data Original: 	40
HEX Data Modified: 	30

Battle 3
BIN Address: 		EBC48
HEX Data Original: 	7F
HEX Data Modified: 	60

ATTACKS:

Yellow Orb Shots
BIN Address: 		ECEA0
HEX Data Original: 	03
HEX Data Modified: 	04

Big Mouth Laser 1
BIN Address: 		ECEEC
HEX Data Original: 	06
HEX Data Modified: 	0A

Unidentified A
BIN Address: 		ECF50
HEX Data Original: 	04
HEX Data Modified: 	05

Big Mouth Laser 2
BIN Address: 		ECFA4
HEX Data Original: 	06
HEX Data Modified: 	0A

Unidentified B
BIN Address: 		ED00C
HEX Data Original: 	03
HEX Data Modified: 	04

Red Fish
BIN Address: 		DB908
HEX Data Original: 	04
HEX Data Modified: 	05


Damage Table - X vs. Zero
-----------------------------------------------------------------
X
BIN Address: 		83CC8
HEX Data:
	Original: 		0001FF05FF00FF00FF05FF05FF00FF00FF02FF01FF08FF00FF00FF08FF08FF03FF00FF03FF03FF03FF03FF00FF08FF00000200020005000400040800000100040005000000030008000500050001000100010001000800040005FF02FF04FF02FF01FF04000000000000000000000200FF00FF000002FF00FF00FF00FF000003FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00
	Reduced (v1.0): 0001FF02FF00FF00FF03FF03FF00FF00FF01FF01FF04FF00FF00FF04FF04FF02FF00FF02FF02FF02FF02FF00FF04FF00000100010003000200020800000100020003000000020004000300030001000100010001000400020003FF01FF02FF01FF01FF02000000000000000000000200FF00FF000001FF00FF00FF00FF000002FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00
	Reduced (v2.0): 0001FF04FF00FF00FF04FF04FF00FF00FF02FF01FF05FF00FF00FF05FF05FF03FF00FF03FF03FF03FF03FF00FF05FF00000200020004000300030800000100030004000000030005000400040001000100010001000500030004FF02FF03FF02FF01FF03000000000000000000000200FF00FF000002FF00FF00FF00FF000003FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00

Zero/Awakened Zero
BIN Address: 		83D68
HEX Data:
	Original: 		0001FF020000FF05FF00FF00FF00FF00FF020001FF03FF00FF08FF00FF00FF03FF00FF03000500060006FF000008FF00FF02FF02FF03FF02FF020800FF01FF02FF04FF00FF05FF00FF00FF01FF01FF01FF01FF01FF03FF00FF0800020006000800010008000000000000000000000200FF00FF000002FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00
	Reduced (v1.0): 0001FF010000FF03FF00FF00FF00FF00FF010001FF02FF00FF04FF00FF00FF02FF00FF02000300030003FF000004FF00FF01FF01FF02FF01FF010800FF01FF01FF02FF00FF03FF00FF00FF01FF01FF01FF01FF01FF02FF00FF0400010003000400010004000000000000000000000200FF00FF000001FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00
	Reduced (v2.0): 0001FF020000FF04FF00FF00FF00FF00FF020001FF03FF00FF05FF00FF00FF03FF00FF03000400040004FF000005FF00FF02FF02FF03FF02FF020800FF01FF02FF03FF00FF04FF00FF00FF01FF01FF01FF01FF01FF03FF00FF0500020004000500010005000000000000000000000200FF00FF000002FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00FF00


Damage Table - Gaea Armor's Buster
-----------------------------------------------------------------
Damage against common enemies increased

Common Enemies Table A
BIN Address: 		826C2
HEX Data Original:	00040007
HEX Data Modified: 	00050009

Common Enemies Table B
BIN Address: 		82762
HEX Data Original:	00040007
HEX Data Modified: 	00050009

Common Enemies Table C
BIN Address: 		82802
HEX Data Original:	00040007
HEX Data Modified: 	00050009

Common Enemies Table D
BIN Address: 		828A2
HEX Data Original:	00040007
HEX Data Modified: 	00050009

Common Enemies Table E
BIN Address: 		82942
HEX Data Original:	00040007
HEX Data Modified: 	00050009	

Common Enemies Table F
BIN Address: 		829E2
HEX Data Original:	00040007
HEX Data Modified: 	00050009

Common Enemies Table G
BIN Address: 		82A82
HEX Data Original:	00040007
HEX Data Modified: 	00050009

Common Enemies Table H
BIN Address: 		82B22
HEX Data Original:	00040007
HEX Data Modified: 	00050009 	


Damage Table - Z-Saber's Damage Against Bosses 
-----------------------------------------------------------------
Damage against bosses reduced

Crescent Grizzly
BIN Address: 		83308
HEX Data Original:	00020002000500040004080000010004FF00
HEX Data Modified: 	000200010003000300020800000100020003

Tidal Whale
BIN Address: 		833A8
HEX Data Original:	000200020005000400040800000100040008
HEX Data Modified: 	000200010003000300020800000100020008

Volt Kraken
BIN Address: 		83448
HEX Data Original:	000200020005000400040800000100040005
HEX Data Modified: 	000200010003000300020800000100020003

Shining Firefly
BIN Address: 		834E8
HEX Data Original:	000200020005000400040800000100040005
HEX Data Modified: 	000200010003000300020800000100020003

Dark Necrobat
BIN Address: 		83588
HEX Data Original:	000200020005000400040800000100040005
HEX Data Modified: 	000200010003000300020800000100020003

Spiral Pegasus
BIN Address: 		83628
HEX Data Original:	000200020005000400040800000100040005
HEX Data Modified: 	000200010003000300020800000100020003

Burn Dinorex (#1)
BIN Address: 		836C8
HEX Data Original:	00020002000500040004080000010004
HEX Data Modified: 	00020001000300030002080000010002

Burn Dinorex (#2)
BIN Address: 		83808
HEX Data Original:	0005
HEX Data Modified: 	0003

Spike Rosered
BIN Address: 		83898
HEX Data Original:	000200020005000400040800000100040005
HEX Data Modified: 	000200010003000200020800000100020002

Dynamo
BIN Address: 		83938
HEX Data Original:	000200020005000400040800000100040006
HEX Data Modified: 	000200010003000200020800000100020003

-----------------------------------------------------------------

If you want to reverse or add other changes to damage tables, you can use my workbook
as a reference. It's on the download page.

========================================================================================
Credits
========================================================================================

acediez: 		Addendum author.

DarkSamus993: 	All the groundwork from Improvement Project.
				Disc/DAT files documentation.
				Maverick names graphics ripped from MMXLC2.

Metalwario64: 	All custom graphics.
			  
Hondoori:		Script source retranslation (https://hondoori.wordpress.com/)
			  
Ghaleonh41:		Script editing.

gledson999: 	DAT/ARC extraction and reinsertion tools.
				Text editing tools and tables.
				