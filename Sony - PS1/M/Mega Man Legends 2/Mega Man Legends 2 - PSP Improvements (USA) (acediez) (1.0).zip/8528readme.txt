========================================================================================
Mega Man Legends 2 - PSP Improvements (v1.00) by acediez - 2023.03.28
========================================================================================
This is a hack for the PS1 version of Mega Man Legends 2 that replicates a couple of
the adjustments the game got for the japan-exclusive PSP port.

Links: 
	Download Page
	https://archive.org/download/mml2_pspimp
	
Target File:
	Mega Man Legends 2 (USA) (Track 1).bin
	MD5: e7039345d54c1bfc3775a468d4125d48
	http://redump.org/disc/3624/
	
The patch format is "xdelta", which can be applied using xdeltaUI:
	xdeltaUI in RHDN
	https://www.romhacking.net/utilities/598/
	
========================================================================================
Features
========================================================================================
- Normal FPS while underwater:
  the lower FPS mode used for the underwater effect has been removed.
- Normal walking acceleration while underwater:
  The slowed down acceleration at the start of any walk cycle while underwater has been
  removed.
- Reduced weapon upgrades prices:
  The weapons upgrades price list was imported directly from the PSP version.

========================================================================================
Changelos
========================================================================================
v1.0
- First release.

========================================================================================
Customization
========================================================================================
Instructions:
1. 	Download: 	HxD (https://mh-nexus.de/en/hxd/)
				EDC/ECC recalculator (https://www.romhacking.net/utilities/1264/)
2. 	After patching, open the modified BIN in HxD
3. 	Press "Ctrl+G" to jump to an address. Use "hex" mode, set offset relative to "begin".
	Paste the addresses listed, and you should find the original values I'm providing.
4. 	Paste the modified hex data with "Ctrl+B" (while Ctrl+V is a "add-paste", Ctrl+B
	is a "overwrite-paste"). Make sure the hexadecimal side of the window is selected
	(the middle column), and the pointer is at the correct address (check the status bar
	at the bottom).
5. 	Repeat 3 and 4 for all the changes you want to make.
6. 	Save and exit.
7. 	Run the modified BIN through the EDC/ECC recalculator. This step is not necessary
	for certain emulators, but it is to play on original hardware and on the more
	accurate emulators.
========================================================================================

Underwater walking speed momentum
-----------------------------------------------------------
If you want to revert the underwater walking speed
back to normal (and keep only the FPS unlock):

BIN Address:							ABDC0
HEX Data:
	Unmodified (slower):				BE000392
	Modified (normal): 					00000334
	
Price list
-----------------------------------------------------------
If you want to further reduce prices, here are the address
and values for each upgrade.
Values are in hexadecimal, little endian.
That means: read them as pairs of characters, right to left.

Example:
A0860100 = 000186A0 (hexadecimal) = 100,000 (decimal)

									Address  Value

Crusher				Attack	Lvl. 1	19598E4	A0860100
					Energy	Lvl. 1	19598E8	F8240100
					Range	Lvl. 1	19598EC	00000000
					Rapid	Lvl. 1	19598F0	00000000
					Special	Lvl. 1	19598F4	A0860100
					Attack	Lvl. 2	19598F8	801A0600
					Energy	Lvl. 2	19598FC	18730100
					Range	Lvl. 2	1959900	00000000
					Rapid	Lvl. 2	1959904	00000000
					Special	Lvl. 2	1959908	E0930400
					Attack	Lvl. 3	195990C	60AE0A00
					Energy	Lvl. 3	1959910	38C10100
					Range	Lvl. 3	1959914	00000000
					Rapid	Lvl. 3	1959918	00000000
					Special	Lvl. 3	195991C	20A10700
Buster Cannon		Attack	Lvl. 1	1959920	983A0000
					Energy	Lvl. 1	1959924	983A0000
					Range	Lvl. 1	1959928	983A0000
					Rapid	Lvl. 1	195992C	00000000
					Special	Lvl. 1	1959930	00000000
					Attack	Lvl. 2	1959934	409C0000
					Energy	Lvl. 2	1959938	50C30000
					Range	Lvl. 2	195993C	409C0000
					Rapid	Lvl. 2	1959940	00000000
					Special	Lvl. 2	1959944	00000000
					Attack	Lvl. 3	1959948	90D00300
					Energy	Lvl. 3	195994C	A0860100
					Range	Lvl. 3	1959950	60EA0000
					Rapid	Lvl. 3	1959954	00000000
					Special	Lvl. 3	1959958	00000000
Hyper Shell			Attack	Lvl. 1	195995C	50C30000
					Energy	Lvl. 1	1959960	204E0000
					Range	Lvl. 1	1959964	983A0000
					Rapid	Lvl. 1	1959968	00000000
					Special	Lvl. 1	195996C	10270000
					Attack	Lvl. 2	1959970	A0860100
					Energy	Lvl. 2	1959974	50C30000
					Range	Lvl. 2	1959978	60EA0000
					Rapid	Lvl. 2	195997C	00000000
					Special	Lvl. 2	1959980	50C30000
					Attack	Lvl. 3	1959984	400D0300
					Energy	Lvl. 3	1959988	E0220200
					Range	Lvl. 3	195998C	C0D40100
					Rapid	Lvl. 3	1959990	00000000
					Special	Lvl. 3	1959994	A0860100
Homing Missile		Attack	Lvl. 1	1959998	10270000
					Energy	Lvl. 1	195999C	983A0000
					Range	Lvl. 1	19599A0	88130000
					Rapid	Lvl. 1	19599A4	10270000
					Special	Lvl. 1	19599A8	10270000
					Attack	Lvl. 2	19599AC	A0860100
					Energy	Lvl. 2	19599B0	30750000
					Range	Lvl. 2	19599B4	30750000
					Rapid	Lvl. 2	19599B8	30750000
					Special	Lvl. 2	19599BC	30750000
					Attack	Lvl. 3	19599C0	400D0300
					Energy	Lvl. 3	19599C4	A0860100
					Range	Lvl. 3	19599C8	80380100
					Rapid	Lvl. 3	19599CC	A0860100
					Special	Lvl. 3	19599D0	400D0300
Ground Crawler		Attack	Lvl. 1	19599D4	D0070000
					Energy	Lvl. 1	19599D8	B80B0000
					Range	Lvl. 1	19599DC	E8030000
					Rapid	Lvl. 1	19599E0	DC050000
					Special	Lvl. 1	19599E4	88130000
					Attack	Lvl. 2	19599E8	88130000
					Energy	Lvl. 2	19599EC	70170000
					Range	Lvl. 2	19599F0	C4090000
					Rapid	Lvl. 2	19599F4	AC0D0000
					Special	Lvl. 2	19599F8	34210000
					Attack	Lvl. 3	19599FC	401F0000
					Energy	Lvl. 3	1959A00	28230000
					Range	Lvl. 3	1959A04	A00F0000
					Rapid	Lvl. 3	1959A08	7C150000
					Special	Lvl. 3	1959A0C	204E0000
Vacuum Arm			Attack	Lvl. 1	1959A10	00000000
					Energy	Lvl. 1	1959A14	E8030000
					Range	Lvl. 1	1959A18	E8030000
					Rapid	Lvl. 1	1959A1C	00000000
					Special	Lvl. 1	1959A20	E8030000
					Attack	Lvl. 2	1959A24	00000000
					Energy	Lvl. 2	1959A28	88130000
					Range	Lvl. 2	1959A2C	D0070000
					Rapid	Lvl. 2	1959A30	00000000
					Special	Lvl. 2	1959A34	A00F0000
					Attack	Lvl. 3	1959A38	00000000
					Energy	Lvl. 3	1959A3C	10270000
					Range	Lvl. 3	1959A40	A00F0000
					Rapid	Lvl. 3	1959A44	00000000
					Special	Lvl. 3	1959A48	10270000
Reflector Arm		Attack	Lvl. 1	1959A4C	88130000
					Energy	Lvl. 1	1959A50	A00F0000
					Range	Lvl. 1	1959A54	D0070000
					Rapid	Lvl. 1	1959A58	B80B0000
					Special	Lvl. 1	1959A5C	00000000
					Attack	Lvl. 2	1959A60	581B0000
					Energy	Lvl. 2	1959A64	7C150000
					Range	Lvl. 2	1959A68	B80B0000
					Rapid	Lvl. 2	1959A6C	94110000
					Special	Lvl. 2	1959A70	00000000
					Attack	Lvl. 3	1959A74	B8880000
					Energy	Lvl. 3	1959A78	581B0000
					Range	Lvl. 3	1959A7C	88130000
					Rapid	Lvl. 3	1959A80	70170000
					Special	Lvl. 3	1959A84	00000000
Unused?				Attack	Lvl. 1	1959A88	4C1D0000
					Energy	Lvl. 1	1959A8C	E02E0000
					Range	Lvl. 1	1959A90	401F0000
					Rapid	Lvl. 1	1959A94	30750000
					Special	Lvl. 1	1959A98	00000000
					Attack	Lvl. 2	1959A9C	28230000
					Energy	Lvl. 2	1959AA0	983A0000
					Range	Lvl. 2	1959AA4	10270000
					Rapid	Lvl. 2	1959AA8	50C30000
					Special	Lvl. 2	1959AAC	00000000
					Attack	Lvl. 3	1959AB0	E02E0000
					Energy	Lvl. 3	1959AB4	50460000
					Range	Lvl. 3	1959AB8	EC2C0000
					Rapid	Lvl. 3	1959ABC	F0490200
					Special	Lvl. 3	1959AC0	00000000
Blade Arm			Attack	Lvl. 1	1959AC4	60EA0000
					Energy	Lvl. 1	1959AC8	10270000
					Range	Lvl. 1	1959ACC	50C30000
					Rapid	Lvl. 1	1959AD0	00000000
					Special	Lvl. 1	1959AD4	00000000
					Attack	Lvl. 2	1959AD8	F0490200
					Energy	Lvl. 2	1959ADC	30750000
					Range	Lvl. 2	1959AE0	A0860100
					Rapid	Lvl. 2	1959AE4	00000000
					Special	Lvl. 2	1959AE8	00000000
					Attack	Lvl. 3	1959AEC	90D00300
					Energy	Lvl. 3	1959AF0	A0860100
					Range	Lvl. 3	1959AF4	90D00300
					Rapid	Lvl. 3	1959AF8	00000000
					Special	Lvl. 3	1959AFC	00000000
Shining Laser		Attack	Lvl. 1	1959B00	50C30000
					Energy	Lvl. 1	1959B04	A0860100
					Range	Lvl. 1	1959B08	50C30000
					Rapid	Lvl. 1	1959B0C	00000000
					Special	Lvl. 1	1959B10	00000000
					Attack	Lvl. 2	1959B14	E0930400
					Energy	Lvl. 2	1959B18	400D0300
					Range	Lvl. 2	1959B1C	A0860100
					Rapid	Lvl. 2	1959B20	00000000
					Special	Lvl. 2	1959B24	00000000
					Attack	Lvl. 3	1959B28	60AE0A00
					Energy	Lvl. 3	1959B2C	A0252600
					Range	Lvl. 3	1959B30	400D0300
					Rapid	Lvl. 3	1959B34	00000000
					Special	Lvl. 3	1959B38	00000000
Machine Gun Arm		Attack	Lvl. 1	1959B3C	B80B0000
					Energy	Lvl. 1	1959B40	88130000
					Range	Lvl. 1	1959B44	E8030000
					Rapid	Lvl. 1	1959B48	D0070000
					Special	Lvl. 1	1959B4C	00000000
					Attack	Lvl. 2	1959B50	30750000
					Energy	Lvl. 2	1959B54	983A0000
					Range	Lvl. 2	1959B58	88130000
					Rapid	Lvl. 2	1959B5C	204E0000
					Special	Lvl. 2	1959B60	00000000
					Attack	Lvl. 3	1959B64	50C30000
					Energy	Lvl. 3	1959B68	A8610000
					Range	Lvl. 3	1959B6C	10270000
					Rapid	Lvl. 3	1959B70	50C30000
					Special	Lvl. 3	1959B74	00000000
Spread Buster		Attack	Lvl. 1	1959B78	10270000
					Energy	Lvl. 1	1959B7C	10270000
					Range	Lvl. 1	1959B80	64190000
					Rapid	Lvl. 1	1959B84	88130000
					Special	Lvl. 1	1959B88	50C30000
					Attack	Lvl. 2	1959B8C	204E0000
					Energy	Lvl. 2	1959B90	983A0000
					Range	Lvl. 2	1959B94	401F0000
					Rapid	Lvl. 2	1959B98	4C1D0000
					Special	Lvl. 2	1959B9C	00000000
					Attack	Lvl. 3	1959BA0	30750000
					Energy	Lvl. 3	1959BA4	50460000
					Range	Lvl. 3	1959BA8	10270000
					Rapid	Lvl. 3	1959BAC	28230000
					Special	Lvl. 3	1959BB0	00000000
null				Attack	Lvl. 1	1959BB4	00000000
					Energy	Lvl. 1	1959BB8	00000000
					Range	Lvl. 1	1959BBC	00000000
					Rapid	Lvl. 1	1959BC0	00000000
					Special	Lvl. 1	1959BC4	00000000
					Attack	Lvl. 2	1959BC8	00000000
					Energy	Lvl. 2	1959BCC	00000000
					Range	Lvl. 2	1959BD0	00000000
					Rapid	Lvl. 2	1959BD4	00000000
					Special	Lvl. 2	1959BD8	00000000
					Attack	Lvl. 3	1959BDC	00000000
					Energy	Lvl. 3	1959BE0	00000000
					Range	Lvl. 3	1959BE4	00000000
					Rapid	Lvl. 3	1959BE8	00000000
					Special	Lvl. 3	1959BEC	00000000
Hunter Seeker		Attack	Lvl. 1	1959BF0	10270000
					Energy	Lvl. 1	1959BF4	10270000
					Range	Lvl. 1	1959BF8	00000000
					Rapid	Lvl. 1	1959BFC	00000000
					Special	Lvl. 1	1959C00	10270000
					Attack	Lvl. 2	1959C04	983A0000
					Energy	Lvl. 2	1959D38	204E0000
					Range	Lvl. 2	1959D3C	00000000
					Rapid	Lvl. 2	1959D40	00000000
					Special	Lvl. 2	1959D44	A0860100
					Attack	Lvl. 3	1959D48	A8610000
					Energy	Lvl. 3	1959D4C	30750000
					Range	Lvl. 3	1959D50	00000000
					Rapid	Lvl. 3	1959D54	00000000
					Special	Lvl. 3	1959D58	E0930400
Drill Arm			Attack	Lvl. 1	1959D5C	E8030000
					Energy	Lvl. 1	1959D60	E8030000
					Range	Lvl. 1	1959D64	E8030000
					Rapid	Lvl. 1	1959D68	00000000
					Special	Lvl. 1	1959D6C	00000000
					Attack	Lvl. 2	1959D70	D0070000
					Energy	Lvl. 2	1959D74	DC050000
					Range	Lvl. 2	1959D78	D0070000
					Rapid	Lvl. 2	1959D7C	00000000
					Special	Lvl. 2	1959D80	00000000
					Attack	Lvl. 3	1959D84	B80B0000
					Energy	Lvl. 3	1959D88	D0070000
					Range	Lvl. 3	1959D8C	B80B0000
					Rapid	Lvl. 3	1959D90	00000000
					Special	Lvl. 3	1959D94	00000000


========================================================================================
Credits
========================================================================================
acediez: 		Hacking.
