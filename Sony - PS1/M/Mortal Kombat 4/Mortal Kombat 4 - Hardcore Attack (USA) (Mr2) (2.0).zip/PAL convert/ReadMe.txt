﻿--------------------------Info---------------------------
Game name: Mortal kombat 4
Console: PlayStation
Game ID USA: SLUS-00605
Patcher: Cheat Patcher v1.2 or higher.
----------------------------------------------------------
--------------------------patch------------------------
Patch add next feature:

 Converting from NTSC to PAL
 Boost Gameplay speed(PlayStation 2 PAL)

--------------------Cheat Patcher------------------
Download link:
http://www.romhacking.net/utilities/1112/
http://rgcorp.ucoz.net/load/console_soft/cheat_patcher/2-1-0-4
----------------------------------------------------------
Author by Mr2.
e-mail: rgcorpsoft@gmail.com
https://rgcorp.ucoz.net/