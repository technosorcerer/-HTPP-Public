﻿-----------------Mortal Kombat 4-----------------
-------------HARDCORE ATTACK-------------
----------------------------------------------------------
--------------------------Info---------------------------
Game name:Mortal Kombat 4 USA NTSC 
Game ID: SLUS_006.05 
Console: PlayStation
Hack version: 2.0
Patch: SP (Solid patch)
Patcher: Solid patcher
Patcher download link:
https://rgcorp.ucoz.net/load/console_soft/solid_patcher/2-1-0-97
https://disk.yandex.ru/d/7fC_hYZ7zORGsQ

*If the game image checksum does not match, disable its verification or skip it.

-----------------------Warning-----------------------
Do not distribute this modification of MK4 without the documentation, contained in the original archive.

----------------------------------------------------------
--------------------Gameplay-----------------------
Wins reset disabled.
Time out disabled.
Default difficulty: hardcore
Default continue: 9

1.CPU interception of throw disabled.
2.Added Greatest victory & Quick end.
3.Endurance mode modification:
Now for every corpse you get little life energy.
For a quick battle with minimal losses you get extra points.

----------------------------------------------------------
-------------------Easy way out-------------------
 Easy way to escape execution.
 If the opponent has lost 85% lives, press "up" button, and you will escape fatality. 

 With the computer opponent is better not pull, he executes as soon as hear: "finish him".

----------------------------------------------------------
------------------------Active:------------------------
Goro & Noob Saibot activated.
Secret menu activated.

----------------------------------------------------------
-------------------------Music------------------------
New soundtrack:
Music on arenas: DJ Morgan - Sentinel.
Music in main menu: Juno reactor - Nitrogen (Part 1).
Music in select screen: URAN TEMPLE Sub - Frequency.
Music in the pit: Jdx- nice and close.
Music in ladder: XOL DOG 400 - Agresiv.
Music in final arcade mode:Scooter - Nessaja (UK VIP Radio Promo).

---------------Meat modification:----------------
Meat has got own special moves list:
 Weapon:                 ->, ->, /\ 
 Corkscrew kick:      <-, ->, O    
 Shurikens:              down, ->, [] 
 Ice clone:               down, <-, X  
 Shadow uppercut:   down, <-, [] 
 Spike fatality:          ->, down, ->+/\   
 Fan fatality:            down, <-, <-+/\

To select Meat - choose Sub Zero pressed R1 button.

----------------------------------------------------------
--------------New combat codes----------------
 100006 Ring out.
 300003 Random KK.
 004400 Random Arena.

 Ring out:
 You need to hit the enemy "high kick" /\, when he stand on edge of the arena.

-----------------Select weapon-------------------
You can get weapon any fighter, for that you must highlight the character icon and press select weapon button.
 R2 get weapon.
 L2 set default weapon.

The weapon drops out if weapon meter empty.

----------------------------------------------------------
------------------Hardcore attack-----------------
This mode uses the limit of wins or battles. When the rounds limits or wins limits were received, 
the loser is thrown into a pit, and then announce the winner. Loser is not thrown into a pit in the event of a tie, 
or if he has won the last battle. If mode over with an equal score, the winner is the one who won the last battle.

*This mode is accessible only if both controllers are connected to the console.

----------------------------------------------------------
------------------------v1.0----------------------------
Fixed the errors previous version of mod.
Improved kombat kode: Ring out.
"Wins" replaced on "score" in the "hardcore attack"  mode.
Unlocked ability to execute the Goro.
Activated the meter for Reptile invisibility.
(The reptile remains invisible when beaten, until the meter ends)

----------------------------------------------------------
------------------------v1.1----------------------------
Meat character is updated:
 The sounds of special moves are played.
 Gender of the character is changed.
 Sub Zero icon set.
 At the flawless victory and fatality, do not announced the name of an extraneous winner.

Kombat kode 11: weapon kombat is fixed.(Dropdown through the random kombat kode)

----------------------------------------------------------
------------------------v1.2----------------------------
Updated arcade mode:
 The boss Shinnok has more lives and continuous morphing.
 Damage of Goro throw is decreased.
 Endurance(1on2) mode is added.
 Activation "vs mode", available only through Select mode screen.

Goro unlocked  for vs mode.
 (player for Goro, takes equal damage with other fighters)
Unlocked the battle Goro vs Goro in "vs mode".

Updated modes in endurance menu:
 Random kombat kodes is added to "Endurance" mode.
 Hidden characters added to "vs endurance" mode. Disabled replenishment of lives.
 In "Ultimate endurance" added the menu for entering a name.
  (Available at difficulty level: hardcore. High score table is shown in demo mode.)

 The low difficulty of the game is cut. (the minimal difficulty, which that was medium)
 Skipping credits is added. (hold the Start button while scrolling through the list of developers)
 Meat character sounds is fixed in 2on2 mode.
 Other minor fixes.

----------------------------------------------------------
------------------------v1.3----------------------------
Fix of the original glitches:
   Deadly spear attak of Scorpion in 2on2 mode.
   The sound of Goro's "Ground stomp" special move.
   The sound of Goro's Taunt.
   Costume of the second player for Noob Saibot in mirror match.

Fixes of the modification:
  Frozen textures is added to character Meat.
  Added the ability to save Hardcore attack mode limits to the memory card.

Other minor fixes.

----------------------------------------------------------
------------------------v1.4----------------------------
Noob Saibot move list is changed:
 Weapon:                 <-, <-, /\
 Tri-blade:                 down, ->, X
 Teleport punch:        down, <-, []
 Air throw                  R1(in air)
 Super roundhouse:   down, ->, O
 Slide kick:                ->, ->, /\
 Fatality 1:                (hold  R1) ->, <-, ->, X+/\+O
 Fatality 2:                ->, <-, down, down, []
 Spike fatality:           ->, down, ->, /\
 Fan fatality :            down, <-, ->, /\

Reiko(P1) fatality 1 on hidden characters(P2) is fixed.
Easy fatalities(cheat code) for Meat character is blocked.
"Finish him" unlocked in "timeout" for 2 players.

----------------------------------------------------------
------------------------v1.5----------------------------
Meat(original) skin reset in "Arcade endurance" mode is fixed.
Kombat kode 11: weapon kombat is updated.
Reworked the winner announcement code.

Other minor fixes.

----------------------------------------------------------
------------------------v1.6----------------------------
Finishing time item is added to the cheat menu.
Battle timer item is added to the options menu:
 Fatal - resets health if the time is up.
 Normal - victory is awarded to the player with more health.
 Off - the battle timer is disabled.

Score display is added to winner screen in Hardcore Attack mode.
Getting score code is updated in Hardcore Attack mode.

Other minor fixes.

----------------------------------------------------------
------------------------v1.7----------------------------
Kombat kode "ring out" is updated.
 (at the announcement of the winner, the "ring out" string is displayed)
Reduced activation time for cheat menu.
The choice of two hidden characters in 2 on 2 mode is added.
 (Goro can be chosen only  the first in line)

----------------------------------------------------------
------------------------v1.8----------------------------
Unlocked all arenas for Goro(under the player control).
The choice of two Goro's in 2on2 mode is added.
The glitch of control interception by AI, when playing the Goro, is fixed.
The buttons of special moves of Goro is changed:
 Weapon:            ->, ->, X
 Fireball:             ->, <-, []
 Hard smash:      <-, <-, X
 Tele-stomp:        ->, down, <-, /\
 Ground stomp:   <-,  ->, down, down, /\
 Lunge kick:        ->, ->, /\
 Super uppercut:  down, ->, []
 Spike fatality:     down, down, down+X

AI tactics against Goro, is fixed.
Loopholes in AI tactics is fixed.
AI disabling glitches is fixed.
Special move "throw breaker", against AI is added.
 If the player holds the buttons: down+back, when AI trying to make capture, enemy will be pushing back.
 The limit of "throw breakers", depends of difficulty level: medium =1, hard =2, hardcore =3.

Time in "select screen" is increased.
Air throw is fixed.(Raiko, Noob Saibot, Quan Chi)

Other minor fixes.

*AI - artificial Intelligence.

----------------------------------------------------------
------------------------v1.9----------------------------
The glitchy moves are disabled:
 Block jabs.
 Neutral jump kick on the floor.

Meat's clone does not freeze enemy, but causes damage.

The music track on the Forest arena is replaced.

----------------------------------------------------------
------------------------v2.0----------------------------
The life bar glitch, on emulators with widescreen hack is fixed.
Displaing of "throw breakers" is added.
AI blocks all hits in combo.
The players activation time after greeting is corrected.
The accuracy of the Kai fireballs is increased.
Not hidden selection of the secret characters, on button R1 is added.
The "Battles limit" calculation with disabled "VS screen" is fixed.

----------------------------------------------------------
Gameplay videos:
https://www.youtube.com/playlist?list=PLO9KCqOVU0xDvW9jgbDFHeFWSnzzMio3P

----------------------------------------------------------
Author by Mr2.
e-mail: rgcorpsoft@gmail.com
https://rgcorp.ucoz.net/