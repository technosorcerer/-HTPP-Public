Akumaj? Dracula X: Gekka no Yas?kyoku v1.0 (SLPM 86023)

Indice rapido del readme
1) Disclaimer
2) Introduzione e storia della patch
3) Come applicare la patch
4) Note varie
 4.0 - Legenda delle icone
 4.1 - Scelte di traduzione
 4.2 - Frasi parlate non tradotte
 4.3 - Oggetti e altro lasciati in Inglese
5) Bug noti
6) Cronologia della patch
7) Ringraziamenti speciali
8) Staff e contatti

1) Disclaimer
Le patch non facilitano in alcun modo la duplicazione di materiale coperto dal diritto d'autore, in perfetta sintonia col dettato del Digital Millenium Copyright Act del Congresso USA, universalmente riconosciuto come norma di riferimento in materia.
Esse infatti non contengo alcun "crack" e sono create al fine di poter esser applicate SOLO alla versione originale del gioco. Le modifiche, sebbene teoricamente riservate alla casa produttrice del gioco (art. 64-bis* della legge 633/41 sul diritto d'autore, come modificato dal Decreto Legislativo 518/92), sono da sempre tollerate in ambito videoludico.
Le patch comunque sono totalmente gratuite e non vengono in alcun modo vendute, n� da sole, n� gi� applicate sulla versione originale del gioco.
Va pertanto declinata ogni responsabilit� per eventuali attivit� di lucro che vengano da altri illecitamente perpetrate utilizzando le patch di traduzione create dai frequentatori di questa sezione.

a) La presente patch va utilizzata esclusivamente sul gioco originale legittimamente detenuto per il quale � stata creata.
b) Questa patch � stata creata senza fini di lucro o di profitto.
c) Gli autori declinano quindi la responsabilit� delle riviste che, senza alcun consenso dell'autore, che deve ritenersi come gi� NON dato, intendessero, in via del tutto autonoma, vendere o comunque distribuire questo programma nei supporti CD/DVD dei loro periodici;
d) E' assolutamente vietato vendere o cedere a terzi a qualsiasi titolo il gioco gi� patchato; i trasgressori potranno essere puniti, ai sensi dell'art. 171bis Legge sul diritto d'autore, con la reclusione da 6 mesi a 3 anni.
e) Si declina la responsabilit� derivante dall'uso scorretto di questo programma da parte di terzi.
f) Questo programma non contiene porzioni di codice del programma del gioco; Gli elementi che lo formano non sono dotati di autonomia funzionale.
g) Per la creazione di tale patch non � stato necessario violare sistemi di protezione informatica, n� dalla sua applicazione viene messa in atto tale condotta.
f) La patch � un prodotto amatoriale, pertanto l'autore declina la responsabilit� di possibili malfunzionamenti.

L'uso di tale patch � a vostro rischio e pericolo. Si ricorda infine che i diritti sul gioco (software) appartengono ai rispettivi proprietari.

2) Introduzione e storia della patch
Questo progetto � nato nel Febbraio del 2007, quando per caso Shari mi sugger� che non sarebbe stato male tradurre SOTN partendo dai testi Giapponesi e impiegando le voci originali, un po' come � successo con Xenogears. Da qui � nata l'idea di recuperare il mio disco di Dracula X, la versione Giapponese del gioco, e provare a lavorarci un po' su. Inizialmente si pensava che il progetto non sarebbe durato molto, infatti quasi da subito ero riuscito ad estrarre buona parte dei testi da mandare a Shari, ma, come tutte le cose in questo ambito, sembrava fin troppo facile.
Passa il tempo e si vengono a scoprire gli altarini riguardo il codice del gioco e le varie magagne fatte da Konami durante la programmazione. Dubito di aver mai visto un codice pi� sporco e con 3000 giri per fare anche le cose pi� semplici, come mappare un numero su un semplice sprite o disegnare una stringa. :P
Dopo un paio di mesi siamo rimasti bloccati su un punto cruciale, ovvero i dialoghi parlati. Il codice per visualizzare quelli tradotti era veramente un macello da cambiare e il formato degli script era quanto di pi� assurdo si potesse trovare. Il gioco permette addirittura di saltare all'interno dello script con dei semplici controlli di variabili, peccato che la codifica usata per utilizzare queste caratteristiche fosse assai stramba. Ad un certo punto ho provato anche a mandare un'email ai Cinesi per chiedere come avessero risolto con la loro versione, ma non � mai arrivata risposta. Alla fine mi sono rimboccato le maniche e ho eseguito il codice passo passo, tentando di capire precisamente cosa facesse quella massa di istruzioni senza senso. O_o Dopo qualche giorno la soluzione � arrivata ed � stato finalmente possibile avere un reinserimento preciso di tutti i dialoghi, anche di quelli che contenevano i salti condizionali e non.
Passa altro tempo e Shari completa i dialoghi, e con i miei script dei menu la traduzione era finita al 100%, ma mancava qualcosa: il codice. Anche qui una marea di giri per tentare di rattoppare tutte le falle del gioco e le stramberie che IGA ha inserito. A volte pare quasi che il codice sia stato scritto da una scimmia, e non scherzo. O_o
Alla fine anche tutto il codice � stato sistemato, il testo inserito e si � passati al testing rapido di 4 giorni in cui ho visto di tutto, tipo tester che chiedevano la patch senza manco avere il gioco, o gente che dice di fare un testing veloce e poi sparisce nel nulla.
Fortunatamente il Saffo si � rimboccato le mani e ha fatto un testing certosino e rapidissimo, per cui i bug pi� pesanti sono stati corretti nel tempo previsto e la patch � stata finalmente rilasciata al pubblico! :D

3) Come applicare la patch
Vi baster� avere un programmare per creare e masterizzare ISO (Alcohol 120% � perfetto allo scopo), oltre al patcher incluso nel pacchetto della patch. Il gioco a cui applicare la patch � la primissima versione di Dracula X, quella con codice SLPM 86023. Per identificare la versione vi baster� aprire il CD del gioco e cercare il file SLPM_860.23. Se � presente, allora avete la versione corretta del gioco, altrimenti lasciate stare il procedimento di patching (la patch � nata esclusivamente per la primissima edizione).
1) Innanzitutto create la ISO del gioco in formato BIN+CUE oppure IMG+CCD+SUB;
2) aprite il patcher, selezionate file BIN/IMG e patch, quindi fate clic su "Avvia";
3) attendete che il programma svolga tutto il procedimento (ci vorr� qualche minuto);
4) una volta ricevuto il messaggio di completamento, ritornare al vostro programma di masterizzazione, caricate la ISO da masterizzare e passate tutto su CD (evitate di aggiornare i sottocanali con programmi come Alcohol);
5) mettete il disco masterizzato nella vostra Psx e il gioco � fatto!
IMPORTANTE: Applicate la patch SOLO alla versione specificata nella procedura (codice SLPM 86023). Non tentate nemmeno di utilizzare le edizioni USA o PAL del gioco. Otterreste solo risultati catastrofici, oltre a gettare al vento un CD.

4) Note varie
Legenda delle icone
Come avrete potuto notare, nel bestiario sono presenti delle icone per indicare gli elementi di debolezza, forza, immunit� e resistenza di ciascun mostro. Alcune di queste icone potrebbero non essere molto chiare (il font non permetteva grandi opere di pixel art :P), per cui abbiamo pensato di inserire una piccola tabella di corrispondenze per identificare il significato di ogni simbolo in caso doveste avere difficolt�:

Armi, sacro, fuoco, acqua, ghiaccio, attacchi fisici (es: il morso del lupo o il Wing Smash del pipistrello), veleno, maledizione, pietra, fulmine e oscurit�.
Scelte di traduzione
- Olrox: inizialmente avevamo deciso di utilizzare la traslitterazione Orlock (da ?????, Orurokku), in quanto citazione al famosissimo Nosferatu (alias Graf Orlok/Orlock), ma poi ci siamo accorti che la Konami aveva scritto chiaramente in caratteri romani il nome del vampiro, probabilmente per storpiare il nome in qualche modo e renderlo meno riconoscibile, senza contare che Orlock si scrive in maniera diversa in Giapponese.
- Valmanway: il vero nome dell'arma � ??????? (Varumanwe), nome che per� non si riesce a capire da cosa derivi nonostante le varie ricerche. Facendo varie ricerche sono arrivato al nome ufficiale usato da Konami per Castlevania: Dawn of Sorrow, ovvero Valmanway. Non avendo trovato nessuna conferma ho preferito tenere questo titolo piuttosto che tentare di indovinarlo, magari sbagliando in pieno. Se sapere esattamente di cosa si tratti, contattatemi e provveder� a cambiare.
Frasi parlate non tradotte
Nel gioco sono presenti alcune frasi che non hanno sottotitoli, per cui praticamente impossibili da tradurre. Il pi� di queste � inutile ai fini della trama, come il parroco che vi benedice nella cappella, per� alcune sono di vitale importanza e vorrei scriverne un paio per non farvi perdere durante il gioco:
1) Le due fate: quando la musica si interrompe per qualche secondo e sentirete una delle fate che vi parla, vuol dire che siete dei pressi di un muro distruttibile;
2) I due demoni volanti: se vi trovate nei pressi di un pulsante, precisamente sulla Via per le Catacombe e la rispettiva versione invertita, vi diranno "Che succede se premo questo pulsante...?" o "Questo pulsante non � ancora stato premuto".
Oggetti e altro lasciati in Inglese
Come potrete notare giocando, buona parte degli oggetti, tecniche e quant'altro conserva il nome in Inglese. Abbiamo adottato questa scelta in quanto questi nomi erano gi� in Inglese nella versione Giapponese, per cui nella maggior parte dei casi si tratta di nomi propri, anche per oggetti comunemente tradotti in Italiano (vedi Potion). Tempo fa mi era stato chiesto di creare due versioni della patch, una con i nomi originali e l'altro con una traduzione per tutto, ma non � stato possibile operare questa scelta per motivi di spazio nella memoria. Dovessi trovare una soluzione, vedr� di far uscire una versione completamente in Italiano in futuro, ma non sperateci troppo.

5) Bug Noti
Un paio dei miei tester hanno avuto problemi di leggibilit� con il prologo scorrevole (subito dopo aver ucciso Dracula con Richter) e nei titoli di coda. Il problema � dovuto ad una risoluzione eccessivamente alta usata dal gioco in quelle situazioni, che su alcune televisioni pu� provocare problemi di visualizzazione delle lettere (alcune appaiono mozzate, come la "q" o la "l"). Personalmente non ho avuto questo problema sulla mia tv, ma se doveste riscontrare questo problema � da imputare al vostro tubo catodico, e non alla patch.
Comunque sia, doveste trovare errori di qualsiasi genere, inviate un'email a qualcuno dello staff descrivendo esattamente cosa avete fatto per far comparire il problema.

6) Cronologia della patch
-Versone 1.0 (03/08/2007): rilascio della prima versione completa.

7) Ringraziamenti speciali
-Sephiroth 1311, Pedro e Dexther per il beta testing rapidissimo;
-Il forum di Romhacking.it per i vari suggerimenti riguardo la patch;
-Konami per aver creato questo eccezionale gioco, anche se IGA avrebbe potuto scrivere un codice che non sembra fatto da una scimmia. :P

8) Staff e contatti
Lo staff della traduzione � composto da Gemini (traduzione, hacking e programmazione), Shari R'Vek (traduzione), e Mog Tom (grafica).
Se volete contattarci in qualche modo per segnalare correzioni o altro, mandate un'email all'indirizzo geminimewtwo@hotmail.com o scrivere sul topic ufficiale del progetto.