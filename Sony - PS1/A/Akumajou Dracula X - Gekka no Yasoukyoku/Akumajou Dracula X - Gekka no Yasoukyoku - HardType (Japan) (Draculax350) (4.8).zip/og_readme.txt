----------------------------------------------------------------En-Us---------------------------------------------------------------------

Akumajou Dracula X - Gekka no Yasoukyoku - HardType v4.8

This patch is a difficulty and re-balance modification for the PSX Akumajou Dracula X - Gekka no Yasoukyoku NTSC-J version 1.2.

It can be used in the original version of the "SLPM_860.23" Version 1.2.

Enemy HP and Attack have been increased.

Some enemies have higher Defense and Resistances.

Equipment and special attacks have been re-balanced.

Removed Lemuria Sword drop.

The Duplicator has been removed from the game.

The Lemuria Sword is available from the Master Librarian after defeating Dracula.

Note: The Lemuria Sword can cast shield spells.


Credits to LandonRay of Ronhacking forum for the USA version hack, I only ported to japanese version.

Ported by youtube channel - Misturadebits.

----------------------------------------------------------------Pt-Br---------------------------------------------------------------------

Akumajou Dracula X - Gekka no Yasoukyoku - HardType v4.8

Este patch é uma modificação de dificuldade e reequilíbrio para o Akumajou Dracula X - Gekka no Yasoukyoku NTSC-J v1.2 do ps1.

Pode ser usado na versão original "SLPM_860.23" V1.2.

O HP e o ataque dos inimigos foram aumentados.

Alguns inimigos têm maior defesa e resistência.

Equipamentos e ataques especiais foram reequilibrados.

Removido o drop da Espada Lemuria.

O Duplicador foi removido do jogo.

A Espada Lemuria está disponível no Master Librarian após derrotar o Drácula.

Nota: A Espada Lemuria pode lançar feitiços de escudo.


Creditos ao LandonRay do forum Ronhacking pela versão USA do hack, eu apenas portei para a versão japonesa.

Portado pelo canal do youtube - Misturadebits.