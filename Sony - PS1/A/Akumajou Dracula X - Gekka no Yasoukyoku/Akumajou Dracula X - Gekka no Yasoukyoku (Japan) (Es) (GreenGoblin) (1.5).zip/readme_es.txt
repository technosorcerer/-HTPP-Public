Este parche ofrece una traducción completa al español. Hemos usado el juego japonés como base, así que el parche debe aplicarse sobre la versión japonesa que es "Akumajou Dracula X - Gekka no Yasoukyoku" (J) (v1.2) [SLPM-86023] (545.440.560 bytes).
Ha habido muchos intentos anteriores para traducir este juego al español, pero ahora el juego está 100% traducido.

Diálogos: 100%
Menús: 100%
Monstruos: 100%
Objetos: 100%
Gráficos: 100%
Bestiario: 100%
Créditos: 100%

Como curiosidad, os diremos que esta traducción está basada en la traducción al inglés que hicieron Gemini, throughhim413 y Tom, y hemos usado las mismas fuentes 8×8 y 8×12 que ellos. También hemos añadido algunos diálogos que aparecían en la versión de PSP pero no en la PSX.

Este juego está considerado el mejor Castlevania de todos los tiempos, así que esperamos que disfrutéis de esta traducción tanto como nosotros. Han sido varios meses de duro trabajo y estamos muy orgullosos del resultado. ¡A disfrutar!

PD: el parche debe ser aplicado usando PPF-O-Matic 3.0 que se puede bajar de aquí: https://www.romhacking.net/utilities/356/

El equipo:

Hack y traducción: Rafael Silva y Green goblin
Revisión: Sonicus
Punteros: LucJedi
Gráficos: Unknown_Master