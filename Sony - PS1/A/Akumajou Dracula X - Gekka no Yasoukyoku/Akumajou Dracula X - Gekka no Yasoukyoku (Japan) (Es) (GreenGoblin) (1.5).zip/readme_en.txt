This patch features a complete translation into Spanish. We used the Japanese game as a base, so the patch must be applied to the Japanese version of the game which is "Akumajou Dracula X - Gekka no Yasoukyoku" (J) (v1.2) [SLPM-86023] (545.440.560 bytes).
Many Spanish translation attemps have been conducted in the past, but now the game is 100% translated.

Dialogues: 100%
Menus: 100%
Monsters: 100%
Items: 100%
Graphics: 100%
Bestiary: 100%
Credits: 100%

As a curiosity, this translation is based on a previous translation conducted by Gemini, throughhim413 and Tom, and we used the same 8×8 and 8×12 fonts. Also we added some dialogues that were in the PSP version but were not present in the PSX version.

This game is usually considered the best Castlevania ever, so we hope you enjoy this translation as much as we do. It's been several months of hard work and testing and we are very proud of this job. Enjoy!

PD: The patch should be applied using PPF-O-Matic 3.0 which can be found here: https://www.romhacking.net/utilities/356/

The team:

Hack & Translation: Rafael Silva & Green goblin
Proofreading: Sonicus
Pointers: LucJedi
Graphics: Unknown_Master