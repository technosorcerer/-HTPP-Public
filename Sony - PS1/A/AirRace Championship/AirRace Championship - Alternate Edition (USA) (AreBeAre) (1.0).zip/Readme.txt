Airrace Championship Alternate Edition By AreBeAre

How to use
==========

-Extract all files to a folder of your choice
-Locate folder, click on ppf-o-matic3
-Fill in both boxes, top box is the original iso or bin file, bottom box is for the patch in PPF.format
-Click Apply

