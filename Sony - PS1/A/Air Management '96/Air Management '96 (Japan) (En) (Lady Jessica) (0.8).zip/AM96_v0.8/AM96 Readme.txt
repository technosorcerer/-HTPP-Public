Air Management '96 (Aerobiz '96)
 Fan Translation v0.8
 by Lady Jessica

For personal use only. Not for sale or reproduction.

This is a virtually complete translation of Aerobiz '96
except for graphics, as I have no ability to edit these
at the moment and don't understand their format. Any
help that could be provided for that would be very much
appreciated.

There may be some as-of-yet rough or poorly-formatted
text in the game, and a small few parts seem to use
the PSX BIOS font instead of the game's own font, for
some unknown reason (resulting in much larger text.)

The ending also may be a bit of a mess.

Other than this, the game should be fully playable
and can be completed in single player or multiplayer.

Name entry screen is finished as of v0.8. You are
limited to a maximum of 7 letters for your company's
name in the English version for VRAM reasons.


During the game, you will encounter untranslated
graphics due to my inability to replace those at this
time, so I am providing a simple guide as to what
those screens actually mean ahead. It should be easy
to play the game without consulting this once you've
felt out where everything is.

Skill level screen:
The top header says "Level".
Otherwise English.

Player number screen:
The options are as follows.
-DEMO (0 Players)
-1 Player
-2 Players
-3 Players
-4 Players

Company editing screen:
The options are as follows.
-Change Company Name
-Change Company Color
-Change Tail Fin Logo

Change Route screen:
The options are as follows.
-Change Plane Type
-Change Plane Count
-Change Flight Count
-Change Fare
-Close Route

Slot Negotiation screen:
-Displays cost of slots as $(number)0K/slot.
-Displays amount of slots you can negotiate for.

Fleet screen:
The options are as follows.
-Boeing (buy)
-Douglas (buy)
-Airbus (buy)
-Ilyushin (buy)
-World Lease (sell)

Stocks screen:
Untranslated header is Share Price.
The options are as follows.
-Buy Company Shares
-Sell Company Shares
-Acquire Charter Company

Promotion screen:
The options are as follows.
-Route Promotion
-Tour Promotion (Hotels)
-Network Promotion (all routes)

Budget screen:
The budget types are as follows.
-Maintenance (left)
-Marketing (middle)
-Service (right)

Meeting screen:
The options are as follows.
-New Route Advice
-Route Change Advice
-Fleet Advice
-Budget Advice
-Assets Advice
-Marketing Advice


Outside of these, you should (hopefully) not encounter
any untranslated text. Have a good time! If you can
assist me in editing the game's graphics files, drop me
a line in my thread on Romhacking.net if possible.

http://www.romhacking.net/forum/index.php?topic=32515


Credits:
- Lady Jessica (Hacking, translation, editing)
