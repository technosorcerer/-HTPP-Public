Asuka 120% Special BURNING Fest. version 2.1 hack
This is new patch for Special Ver 2 intended to be used for Competitive Play

This patch will :
Removes all infinite Combo for some character
Aerial Throw can be countered , invicible times got extented
Backdash had less invicible times 
Mirror Download if you can't download from romhacking:
https://1drv.ms/u/s!ArhmD3lN6G3NgRBr8lNtkYAOzV0H?e=jGp29N
PPF patches:
https://1drv.ms/u/s!ArhmD3lN6G3NgRH94WUIEscNr2En?e=pyI1f6



ROM / ISO Information:
Asuka 120% Special BURNING Fest. (Rev 01)
MD5 (Track 01.bin): 25FDC6AE09A0C696A682C53EA38C7271
SHA-1 (Track 01.bin): 2572EF0949474E159677098F934D05F0DC19F7E2
http://redump.org/disc/37596/