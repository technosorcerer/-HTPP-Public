Galerians Demo Unlocker v1.0.1 - 2024-09-30
by descawed

---------------------------
Description
---------------------------
This is a mod for the ASCII Zanmai demo disc (PSX, 1998) which removes the To Be Continued
screen from Galerians, allowing you to explore past the end of the demo. A surprising
amount of previously-inaccessible content exists beyond this point, covering the first 3
of the game's 4 stages, although stages B and especially C are highly unfinished. A number
of areas have significant differences from the final game which don't appear in any other
versions, including the international demos (which are based on the Japanese release build).

In addition to removing the To Be Continued screen, I've also patched many other parts of
the game to restore content that was broken or unfinished. However, be aware that this is
NOT a complete game that can be played from beginning to end. This version of the game is
fundamentally unfinished and is mainly of value to those interested in seeing the history
of the game's development. There are bugs remaining, some of which I know about (see
How to Play/Stage A/third bullet), and probably some that I don't. In some cases I was
forced to guess at how to restore content because there wasn't enough information to tell
how a particular section was supposed to work, so some of my changes may not reflect the
developers' original intentions. A more detailed description of the changes, issues, and
limitations of this mod can be found in the "How to Play" and "Changelog" sections below.

---------------------------
Installation
---------------------------
IMPORTANT: If you're using DuckStation, you need to go into your controller settings and
set your controller type to "Digital Controller", otherwise Galerians won't respond to
your inputs.

This mod is distributed as an xdelta patch. You must have an image of the demo disc (aka a
ROM, ISO, etc.) to apply the patch to. The patch requires the image to be in .BIN format
(CRC32: 7EBE2421) or .CHD format, so if your image is in a different format, it'll have to
be converted first. The mod comes with two different automated patcher scripts depending on
your operating system, so check out either the "Windows" or "macOS and Linux" sections
below for instructions. Regardless of what format your original image was in, the patched
image will always be in BIN/CUE format, which you can then play in your preferred emulator.

If for some reason you don't want to or can't use the automated patcher, you can also
apply the patch manually. The patch file is patch.xdelta. I recommend using Delta Patcher,
which runs on all major operating systems and lets you do the process through a GUI instead
of on the command line: https://github.com/marco-calautti/DeltaPatcher/releases
If your disc image isn't in BIN/CUE format, you'll have to convert it first. This page
explains how to do that for CHD files:
https://wiki.recalbox.com/en/tutorials/utilities/rom-conversion/chdman
If your disc image is in some other format, you'll have to find an alternative tool to
do the conversion.

Windows
-----------------
If you have a BIN or CHD file, you should just be able to drag and drop it onto the
patch.bat file in the same folder as this readme. The required tools (xdelta and chdman)
are packaged with this mod (in the win32_util folder). After the patcher finishes, you
should find the patched files in the same folder as patch.bat. For example, if your
original file was called playstationdisc.chd, after the patching is complete, you should
find you now have two new files, playstationdisc_galerians_patched.bin and
playstationdisc_galerians_patched.cue.

macOS and Linux
-----------------
If you have a BIN or CHD file, you should be able to run it through the patch.sh script
in the same folder as this readme. You'll have to do this from the terminal rather than
dragging and dropping like Windows. Assuming you open the terminal in the script folder,
you can run it as `./patch.sh /path/to/zanmai`, replacing /path/to/zanmai with the path
to your disc file. Make sure the script is executable before you try to run it
(`chmod +x patch.sh`). I have NOT bundled Mac and Linux versions of the required tools
(xdelta and chdman) with the mod, so you'll have to install them, but that should be easy
to do via your system package manager (that would be Homebrew for Mac). On Mac it should be
`brew install xdelta rom-tools`, and on Ubuntu, `apt install xdelta3 mame-tools`. Other
Linuxes may need to look up the equivalent packages for their distro. Once those are
installed, the script should just work, although you can also explicitly tell the script
where the tools are if it has trouble finding them; run the script with no arguments
(`./patch.sh`) for details. After the patcher finishes, you should find the patched files
in the same folder as patch.sh. For example, if your original file was called
playstationdisc.chd, after the patching is complete, you should find you now have two new
files, playstationdisc_galerians_patched.bin and playstationdisc_galerians_patched.cue.

---------------------------
How to Play
---------------------------
IMPORTANT: If nothing else, read the third bullet under stage A, which describes how to
work around a glitch that may cause your game to crash.

It will be helpful if you've played the final game, because I'll be describing things in
terms of how they differ from that version. If not, you may want to refer to a guide.
I haven't listed item locations in the sections for the stages they appear in; instead,
items that are new or changed in the demo are in a separate Key Items section at the end.
If you want to explore and find things on your own, you can skip that section. Of course,
the demo is entirely in Japanese, so if you can't read Japanese, you'll need to rely
primarily on scan images to figure out which items are needed where.

Mechanics
-----------------
- Controls:
  - R1: Charge attack
  - L2/R2: Switch between Nalcon and Red
  - Square: Interact; fire attack
  - Circle: Scan
  - Triangle: Map (but only the map for the demo area is in the game, so the map will be
              wrong elsewhere)
  - Start: Item menu
  - Select: Drug menu
- Nalcon in the demo works kind of like a gun where the charge meter is your ammo. Each time
  you press square, it fires one shot which consumes a certain amount of charge, so the more
  you fill the charge meter, the more shots you can fire. After the first shot, the meter
  starts to drain, so you do need to fire rapdily to maximize your number of shots.
- Red works like the final game, but with an added effect that while you're charging, the
  targeted enemy will start to smoke and their movement speed will be reduced. This is
  especially effective against guards, who move noticeably faster in the demo.
- Unlike the final game, dead enemies don't disappear when you leave the room, and sometimes
  they have items on them. If a key item isn't where you expect it to be, see if it's on a
  nearby enemy.
- The only enemies in the game are doctors, guards, rabbits, and Lem, and only doctors and
  guards are functional. Rabbits and Lem have no AI and can't be killed.
- Saving requires items called "memory chips", like ink ribbons in Resident Evil. Two of
  these exist in the demo, one on the 14th floor and one on the 13th floor. They don't
  appear in your inventory; the game tracks your count of memory chips separately.
- The save menu says to press circle to confirm, but it's actually square.

Stage A
-----------------
- The official demo area ends when you blow up the shutter blocking access to the 14th
  floor. Everything up to that point is relatively complete and functional.
- The save station on the 15th floor was disabled for the demo. The other save stations
  still work.
- If you start seeing the Nalcon graphics glitch out after going down to the 14th floor,
  I recommend getting the memory chip from the back of the "fetus room", saving at the
  nearby save station, and then resetting and loading the save. That should clear the
  glitch. If you don't do this, you may start experiencing crashes as you get deeper
  into the game.
- The 3D models for the two-headed animal statues don't appear during gameplay, but they
  are there. You have to scan them to pick them up; activating them just shows a picture.
- To proceed to stage B, use the Eyeball Lens on the elevator in Lem's room and then
  activate the elevator.

Stage B
-----------------
- There are no enemies or NPCs of any kind from this point on.
- The outdoor camera angles, particularly leading to the backyard, are quite broken and
  don't match the backgrounds. As you approach the backyard, I recommend hugging the side
  of the house and running forward for a while to make sure you've reach the fence. Then,
  turn slightly right. You want to be at angle such that you're still mostly facing the
  fence (so you can activate the gate when you get to it), but turned right enough that
  you're moving away from the house as you walk forward. You won't be able to see your
  character, so you'll have to guess a bit. It may be helpful to make a save state at the
  previous camera angle so you can reset if you get lost. If you've got the angle right,
  just walk forward and spam square until you get to the gate.
- The pool table is invisible but it is there. You only need the 3 Ball to move it.
- In the hidden room through the library, there's a shelf immediately to your left when
  you enter. You need to activate this shelf to be able to raise Dr. Pascalle's car from
  the pool. There's no indication when you've activated it, so you may want to walk around
  and click it a bunch of times to make sure you've hit the right spot.
- To proceed to stage C, get Lilia's Doll from the back of the shed and then leave the shed.
  The shed is not locked, so you can do this at any time.

Stage C
-----------------
- The cameras in this stage are a mess, especially in the lobby. All the doors are towards
  the back of the room, so just hug the walls and start pressing square when you think you're
  getting close.
- Almost all the doors in this stage were locked behind flags that could never be set because
  the relevant events hadn't been coded yet. To work around this, I indiscriminately set all
  the flags at the beginning of the stage. Unfortunately, this also has the side effect of
  disabling all item pickups, and possibly certain interaction messages. If you're handy with
  a debugger, you can play around with the flags for yourself and see what happens. There are
  three 64-bit flag banks for this stage at addresses 8019AD38, 8019AD58, and 8019AD78, but I
  believe only the first bank is actually used.
- On the upper floors, I recommend making a save state in the hall before entering a room,
  as some of the rooms are difficult or impossible to get out of.
- Stage D does not exist, so this is the last area that can be explored.

Key Items
-----------------
This is a list of where to find all the key items that are either not in the final version of
the game or not in the same location as they are in that version.

- Security Card: On the first doctor you fight at the beginning of the game.
- Security Card (red): On the big computers at the end of the hall after the Security Card.
- Freezer Room Key: On the guard in the monitor room after you use the Security Card.
- PPEC Storage Key: On the doctor in the room on the left before the Freezer Room.
- 14F Memory Chip: On the cart in the back of the "fetus room" through the door in the back of
  the Special PPEC Office.
- Startup Disk: In the room with all the TVs in the middle where you would see Lem for the first
  time in the final game, it's on the cylindrical thing you use to unlock the door in that version.
- Pharmaceutical Factory Key: On the doctor through the door immediately to your left when you
  go through the first door requiring the reformatted Security Card.
- Test Lab Key: On the computer where you would get the Picture of Your Parents in the final game.
- Control Room Key: In the box on the wall in the same room as the Test Lab Key above.
- Lilia's image data: On the computer that in the final game has the FMV where it "feels like someone
  is picking through [Rion's] brain."
- 13F Memory Chip: Where the Test Lab Key would be in the final game.
- Picture of your Parents: On the computer you interact with to start the Lem boss fight in the final
  game.
- Eyeball Lens: On Lem (he has no AI and can't be killed, so just interact with him to pick it up).
- Door knob: In the bathtub of the first floor bathroom of Rion's house.

---------------------------
Changelog
---------------------------
1.0.1 (2024-09-30)
- Updated readme to provide workaround for DuckStation.

1.0 (2024-09-30)
- Added the red Security Card to the computer bank in the hall near the beginning of the game,
  added a scan image to the door to the G Project Report room showing that location, locked the door
  with this card, and changed the message to reflect this.
  - This is my subjective attempt at restoring access to that room through gameplay and not necessarily
    the sequence of events that the developers intended. The door is locked in the demo, and the message
    says you need the Special PPEC Office Key, which is the same as the final game. However, that key
    doesn't exist in the demo, and if you had actually been able to unlock the door, it's coded to show
    the message "You used the security card." This could refer to the same security card used elsewhere
    in the game, but because the red Security Card item existed in the game data and was unused, I took
    the liberty of using it here. The scan image I used was also already in the files but unused. That
    image shows the computer bank and a doctor standing it. Both the computers and the doctor had
    triggers on them, but they were gutted for the demo, so there's no way to tell which one was which.
    I decided to put the card in the computers, and I put a message on the doctor saying there's nothing
    there in case you check him.
- Disabled the "To Be Continued" screen after using the Liquid Explosive and re-enabled the trigger on
  the stairs to the 14th floor.
- Replaced all references to FMVs that don't exist on the demo disc with references to FMV M04XA (Rion
  talking to the doctor with the Security Card).
- Hard-coded the map code to always use the Hospital 15F map to prevent crashing, as the other maps are
  missing.
- Linked the proper 3D models to the following items, which were using placeholder models:
  - Pill Case
  - Startup Disk
  - Security Card (red)
  - Pharmaceutical Factory Key
  - Data Disk
- Updated code and data to properly display file contents for the following files:
  - G Project Report
  - Rion's test data
  - Dr. Lem's Notes
- Re-enabled full main menu.
- Removed buggy item pickup code that tried to track which items the player had already picked up.
  This code was redundant anyway because each pickup trigger already tracks its own flag to see if
  the player has already picked it up.
- Patched NPC code to not try to run AI for NPCs who have no AI routine set. Prevents crashing in
  rooms with rabbits and Lem.
- Changed Eyeball Lens pickup trigger to allow picking the item up while Lem is alive, since NPCs
  with no AI can't be killed. Also patched trigger to set the correct flag and adjusted the scale
  of the Eyeball Lens model, which was too large.
- Patched code in Lem's office to fix crash from trying to play a sound file that doesn't exist.
- Removed unfinished enemies (likely security mechs) from A1408, A1310, A13RE, and A1312 to prevent
  crashing.
- Corrected the elevator in Lem's room to unlock with the Eyeball Lens instead of the Pharmaceutical
  Factory Key. Also added code to take the player to stage B after interacting with the unlocked
  elevator.
- Changed camera cut 7 in stage B front yard to use the correct camera angle.
- Completed unfinished trigger for using the door knob on the broken door in the kitchen.
- Corrected trigger in parents' room to give you Father's Ring instead of the Fuse.
- Corrected trigger on the shelf in the hidden room to properly set the flag allowing you to raise
  Dr. Pascalle's car from the pool.
- Corrected trigger on pool table to properly set the flag allowing access to the basement when
  you use the 9 Ball.
- Completed unfinished trigger for the door leading to the balcony.
- Added code to the shed to allow picking up Lilia's Doll.
- Added code to the shed door to take you to stage C after picking up Lilia's Doll. This code also
  sets all stage C flags to make sure doors are open.
- Changed spawn point in room 301 to spawn the player in bounds.

---------------------------
Related Links
---------------------------
- Mod tools I used in the making of this mod: https://github.com/descawed/galsdk
- My YouTube channel where I explore the demo's hidden content: https://www.youtube.com/@descawed
- A mod to play as Lilia I made for the final game: https://www.moddb.com/games/galerians/addons/galerians-play-as-lilia
- The game's TCRF article, where at some point I'll be adding more info about this demo: https://tcrf.net/Galerians