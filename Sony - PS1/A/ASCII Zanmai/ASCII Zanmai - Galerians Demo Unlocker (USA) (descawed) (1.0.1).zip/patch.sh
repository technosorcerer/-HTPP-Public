#!/usr/bin/env bash

set -euo pipefail

if [[ "$#" -lt 1 ]]
then
    echo usage: $0 INPUT_PATH \[OUTPUT_PATH \[XDELTA_CMD \[CHDMAN_CMD\]\]\]
    echo '    INPUT_PATH: Path to the ASCII Zanmai disc image file. This should be in BIN format, or, if chdman is installed, CHD format.'
    echo '    OUTPUT_PATH: Path to write the patched disc image file to. Must not be the same as INPUT_PATH. Default is the script directory with "_galerians_patch.bin" appended to the input filename. Output is always in BIN format. A CUE file with the same name but .cue extension will also be created. Existing files will be overwritten without prompting.'
    echo '    XDELTA_CMD: Path or name of the xdelta command. Default is xdelta3.'
    echo '    CHDMAN_CMD: Path or name of the chdman command. Only needed if the input file (INPUT_PATH) is in CHD format. Default is chdman.'
    exit 1
fi

patch_dir=$(dirname "$0")
input_path=$1
input_format="${input_path##*.}"
if [[ "$(echo "$input_format" | tr '[:upper:]' '[:lower:]')" == "chd" ]]
then
    is_chd=true
else
    is_chd=false
fi

if [[ "$#" -ge 2 ]]
then
    bin_output_path=$2
else
    input_name=$(basename "$input_path")
    bin_output_path="$patch_dir/${input_name%.*}_galerians_patch.bin"
fi
cue_output_path="${bin_output_path%.*}.cue"

patch_path="$patch_dir/patch.xdelta"

if [[ "$#" -ge 3 ]]
then
    xdelta=$3
else
    xdelta=xdelta3
fi

if [[ "$#" -ge 4 ]]
then
    chdman=$4
else
    chdman=chdman
fi

if [[ ! -f "$input_path" ]]
then
    echo $input_path not found
    exit 2
fi

if [[ ! -f "$patch_path" ]]
then
    echo "$patch_path not found. The patch.xdelta file should be located in the same directory as this script."
    exit 3
fi

if ! command -v "$xdelta" > /dev/null 2>&1 && [[ ! -x "$xdelta" || ! -f "$xdelta" ]]
then
    echo "Command $xdelta not found. You may need to install xdelta (see the readme for details). If xdelta is already installed but not on the PATH, you can provide an alternative path to the command as the fourth argument to the script (see usage by running the script with no arguments)."
    exit 4
fi

if [[ "$input_path" -ef "$bin_output_path" ]]
then
    # xdelta doesn't seem to like this
    echo Input and output paths must not be the same
    exit 5
fi

# this should only be possible if the user supplies an output path with a .cue extension
output_format="${bin_output_path##*.}"
if [[ "$(echo "$output_format" | tr '[:upper:]' '[:lower:]')" == "cue" ]]
then
    echo The output path should be the path to the BIN file, not the CUE file
    exit 6
fi

if [[ "$is_chd" = true ]]
then
    if ! command -v "$chdman" > /dev/null 2>&1 && [[ ! -x "$chdman" || ! -f "$chdman" ]]
    then
        echo "Command $chdman not found. You may need to install chdman (see the readme for details). If chdman is already installed but not on the PATH, you can provide an alternative path to the command as the fourth argument to the script (see usage by running the script with no arguments)."
        exit 7
    fi

    echo Patching...

    # this isn't safe against race conditions etc., but mktemp on macOS doesn't support --suffix, so I think this is good enough for this simple script
    temp_path=$(mktemp)
    temp_bin_path="$temp_path".bin
    temp_cue_path="$temp_path".cue
    rm "$temp_path"
    "$chdman" extractcd -o "$temp_cue_path" -ob "$temp_bin_path" -i "$input_path" > /dev/null
    # delete CUE file immediately as we don't use it; it's only needed for chdman
    rm "$temp_cue_path"
    # input to xdelta is now the output from chdman
    input_path=$temp_bin_path
else
    echo Patching...
fi

# don't terminate immediately if xdelta fails because we still need to delete the temp file if we're processing a CHD
xdelta_status=0
"$xdelta" -d -f -s "$input_path" "$patch_path" "$bin_output_path" || xdelta_status=$?

if [[ "$is_chd" = true ]]
then
    rm "$temp_bin_path"
fi

if [[ $xdelta_status -ne 0 ]]
then
    # xdelta should've already printed a message
    exit $xdelta_status
fi

# patching succeeded, so create the CUE file and wrap up
echo FILE \"$(basename "$bin_output_path")\" BINARY > $cue_output_path
echo '  TRACK 01 MODE2/2352' >> $cue_output_path
echo '    INDEX 01 00:00:00' >> $cue_output_path

echo Patching succeeded! Patched BIN file: $(realpath "$bin_output_path")