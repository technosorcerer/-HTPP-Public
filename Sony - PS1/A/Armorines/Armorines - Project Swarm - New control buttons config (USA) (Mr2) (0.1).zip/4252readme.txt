--------------------------Info---------------------------
Game name: Armorines - Project Swarm
Console: PlayStation
Game ID USA: SLUS-01022
Patcher: Cheat Patcher v0.9 or higher.
----------------------------------------------------------
--------------------------patch------------------------
Patch add next feature:
 New control buttons config.

 Digital control (config 1, 2):
  UP   - look down      
  DOWN   -  look up
  <-   - look left
  ->   - look right

  X   - move backward
  []   - strafe left
  O   - strafe right
  /\   - move forward        
 
 Config 1:
   R1   - crouch
   R2   - fire
   L1   - weapon select
   L2   - jump

 Config 2:
   R1   - fire 
   R2   - crouch
   L1   - jump 
   L2   - weapon select

 Analog control (config 3, 4).
 �ontrol config:
  Left analog - move
  Right analog - look
 
  Config 3:
   R1   - crouch
   R2   - fire
   L1   - weapon select
   L2   - jump

 Config 4:
   R1   - fire 
   R2   - crouch
   L1   - jump 
   L2   - weapon select

*Turn ON "ANALOG" button on gamepad, to activate analog control.
--------------------Cheat Patcher------------------
Download link:
http://www.romhacking.net/utilities/1112/
----------------------------------------------------------
Author by Mr2.
e-mail: fsocp@land.ru
http://rgcorp.ucoz.net/