HISTORIA DEL JUEGO:

El protagonista de nuestra historia es Arc, un joven guerrero que decide partir para intentar aclarar la muerte de su padre, Yoshua, 10 a�os atr�s. Ser� el destino de Arc, como predijo Yoshua a la madre del chico antes de desaparecer, seguir sus pasos, cuando "el sello se rompa y la monta�a tiemble". Arc tendr� que reavivar la llama del monte de Cion, que encierra bajo el poder del "Arca" (con esto hacen una especie de juego de palabras) un ser maligno.

El sello acaba de romperse por su guardiana, una joven hechicera que no quiere seguir con la tradici�n de su pueblo (vigilar la llama y casarse con el pr�ncipe del castillo de Palencia). Ella, que ha sido enga�ada para hacerlo por sugerencia de otra persona (cuyas intenciones conoceremos m�s adelante), se da cuenta de que algo va mal y decide reavivar la llama, pero entonces aparece Arc, dici�ndole que debe ser �l, pues es su destino, el que reavive el fuego del altar.

Camino de la cima, nuestro protagonista es herido de muerte por el ser que ha escapado del sello maligno, pero entonces es iluminado por una luz y oye una voz que le explica que su destino es salvar a la humanidad de su destrucci�n y que, como prometi� ("la voz") a su padre 10 a�os atr�s, le conceder� el poder del "Arca" para derrotar a cualquier monstruo.

Arc no entiende nada, pero la voz le indica que comprender� todo m�s adelante. En adelante Arc comenzar� a descubrir que ha recibido una gran fuerza e ir� conociendo a numerosos aliados (incluida Kukuru, la joven hechicera que conoce al principio), mientras comprende qu� es lo que est� sucediendo en el mundo, conspiraci�n incluida (para variar en estos juegos) e ir� destapando lo que ha sucedido con su padre (que en realidad va un paso por delante suyo en la aventura y le va dejando cartas para as� ayudarle en su tarea de salvar a la humanidad).

Es un preludio a lo que ser� el anime, y ATL II.

TRADUCCI�N:

Esta es mi primera traducci�n. Despu�s de mucho probar con otros juegos, hacer tutoriales y dem�s. Este juego lo veo suficientemente "accesible" para traducir. Tambi�n cabe a destacar que el juego me parece muy entretenido, y aunque en su �poca no lo jugu� por la cantidad de titulos rpg en castellano de psx me decido a hacerlo para jugar a �l de forma m�s amena. Teniendo en cuenta que hubo una serie de Anime seguro que a mucha gente le d� una alegria jugarlo en castellano.

El curso de la traducci�n fu� tanteando y buscando texto, se cre� una tabla hexadecimal. Seguidamente despu�s de haber encontrado el texto fu� editar la fuente, gracias a CUE que me hizo una aplicaci�n para no tener que ir con el tilemolester editando, ya que, se mezclaban algunos tiles y ten�an diferentes bits, de 4 y 16 bits. Despu�s solo queda extraer script y traducir, para luego reeinsertar. Para acabar habr� que editar algunos gr�ficos pero son muy pocos, el del men� de intro ya est� modificado.