Hello everyone

About Arc the Lad - Rebuild (USA)

This new patch is including content different

Features:

- All the faceset characters is Japanese version . 
- Possibility to play  from begin after final events.

The Patch 1.1

Note:
- Patch working on the original version
- All rights reserved © Sony
- This Patch is for fans only, not for sales.


Enjoy it!