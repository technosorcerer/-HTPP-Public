---------------------------------------------
	     Delta Patcher 2.0
---------------------------------------------
 (C) 2015 Phoenix <phoenix_87_c@hotmail.com>


-------------------------
1. What is this?
-------------------------

Delta Patcher is yet another frontend to the
xdelta3 decoder/encoder created by Joshua
McDonald. Delta patcher is able to make and
apply xdelta patches. But... why making another frontend?
All the frontends I've seen don't support some
options of the encoder/decoder at all, like
compression level for encoding and checksum
checking for decoding/encoding. Also, they are
all written in .NET (0_0). So, this tool was
designed to be selfcontained (as of now, only
for Windows). It's written in C++ using
wxWidgets for the GUI components and all the
needed libraries are static linked to the EXE.
Last, but not the least, Delta Patcher is
GPL2'd and cross-platform: it runs fine on
Windows and Linux and should compile on MacOS
too.

-------------------------
2. Features
-------------------------

-No xdelta.exe is needed. Starting from version 2.0, it has been embedded in the delta patcher executable;

-More intuitive GUI design;

-Multiple options for patch application/creation:
   patch application: 	disable checksum validation
			backup original file

   patch creation: 	patch compression level
			source window size
			checksum
			*custom UTF8 description for patches* -> patches created with delta patcher will show this
			description if opened with delta patcher (a l� PPF-O-MATIC3);

-Associate xdelta patch files to be opened with delta patcher;

-Drag & Drop support for original file and
 xdelta patch file in the decoding window;

-Cross-platform and opensource: modify and
 redistribuite it under the GPL2 license;

-Multilanguage: Delta Patcher can be
 translated into any language using .po files.
 If you want multilanguage support you have
 to place the "resource" directory along with
 this tool (see source code for the pot file).

-------------------------
3. Full and Lite versions
-------------------------

This package comes with two versions of the
frontend. The Lite version is simply the
patching GUI, this is intended to be shipped
along with your patch. This way, the final
user doesn't need to mess with other options
like patch creation (simplicity comes first!).
The Full version is mainly for romhackers,
it supports both creation and application
of xdelta patches.


-----------------------
4. Contacts and sources
-----------------------

You can contact me by email at
phoenix_87_c@hotmail.com or at the SadNES cITy
board at http://lnx.sadnescity.it/forum/.
The full source code can be found at
github.com/marco-calautti/DeltaPatcher.


Phoenix.
