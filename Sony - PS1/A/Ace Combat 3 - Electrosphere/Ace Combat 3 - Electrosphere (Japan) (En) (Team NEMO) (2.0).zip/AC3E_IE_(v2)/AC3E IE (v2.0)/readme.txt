2016.12.14

ACE COMBAT 3 electrosphere
International Edition

Fan-Translation for Discs 1 and 2 (v2.0)

- Contents -

1.Description
2.Technical information
4.Translated Search files
5.A Word from the Translator
6.Known Issues
7.Terms of use
8.Credits
9.Copyright acknowledgements
10.Related links
11.Translations for unsubbed dialogues (M06, M29 and Epilogue)
___ ___ ___

1.Description: this patch contains English translations for all 52 missions. 

Some menus, several Search files and almost every title in the Archive menu are also translated.
___ ___ ___

2.Technical information

These patches have been tested as working with the original SLPS-02020~1 print of the game via these emulators: ePSXe, XEBRA and Mednafen. Reports also confirm full compatibility with: PS1, PS3 with CFW and PSP.

Original print's MD5 checksums:
SLPS-02020: 30F7DCE98B6901290CB26C9BAF27268F 
SLPS-02021: 50760963AE8A26EA0188B165F05B33A1
___ ___ ___

3. How to apply the patches:

First of all, make sure your ISO images are in the BIN/CUE format. The BIN is the file that you'll want to patch.

I)Open the patching utility, DeltaPatcherLite, that can be found in the zip along with the patches.

II)You'll see two boxes, one saying "Original file" and the one below that says "XDelta patch". Click on the folder symbol and select the BIN file of your unpatched image of AC3E (Disc 1 or Disc 2) and then do the same below and select the respective patch you wish to apply.

III)Click on "Apply patch". The original image should now be patched.

Note: if your images correspond to the SLPS numbers listed above, but the MD5 checksum still doesn't match, try to uncheck "Checksum validation" and then apply the patch as it may help patch your copy succesfully.

___ ___ ___

4.Translated Search files

"GRDF,"NEU", "SARF", "Sphere", "NUN", "Snyder's Top", "Aeon Generator", all character biographies.

5.A Word from the Translator

"Hello! I'm the translator, Greenrose, known to some as Son Ryo. I'd like to thank Nine-Gear Crow from Something Awful for getting me into Ace Combat in the first place, and Lunethex also from SA for LPing AC3 and bringing this project to my attention.

That said, while I was able to bring a lot to this project, I wasn't able to look over some things that were already done, and my Japanese is far from perfect so I'm sure I've probably made a few mistakes of my own. If you play this patch, you know some Japanese, and you think you can correct a mistake, you can send me a message on Romhacking.net and we'll try and include it in the next patch. And we do intend to make at least one more patch, with more or all of the search terms included.

Thanks for playing!"
___ ___ ___

6.Known Issues

i) The game freezes if you try to view the following Search files: "Neucom Inc.", "Neucom's history and facts" and "Opto-Neuron".

ii) Some missions contain several lines of dialogue that play only during certains conditions (such as M34 The Orientation and M44 Reality Distortion) but that sadly were not present in the source for our script. 

Due to the very low-res nature of this type of text file, we couldn't transcribe them in time for this release but we'll be doing everything we can to translate them.
___ ___ ___

7.Terms of Use

Do not upload a patched copy of AC3E. This project does not endorse piracy.

Do not sell this translation or copies that were patched with this fan-translation.
___ ___ ___

8.Staff


Lead Translator			BRPXQZME

Translator, Spot-Checker	pmt7ar

Translator, Quality Assurance	greenrose

Lead Programmer			EsperKnight

Programmer, Typesetter		Dashman

Programmer, Technical Support	me

Programmer, Data Miner		Gipphe

Webmaster, Support		Iceman-UK

Editor, Coordinator		DragonSpikeXIII


Team NEMO


Guest Localizer: Mrs. Agness Kaku (Mission 01 Awakening)


- Special Thanks -

BlackDog61

CUE

Eien Ni Hen

Henry H. Jerng

Mike (jPSXdec)

Momomeno

Lab313

Seihen

Sirius-R


- Very Special Thanks - 

http://www28.atwiki.jp/acacac/pages/4.html, a japanese fan-site without which this project would never have beeen possible.
___ ___ ___

9.Copyright Acknowledgments
ACE COMBAT 3� electrosphere �1999 NAMCO Ltd., All Rights Reserved

Frognation and Production I.G. are the owners of their respective properties.

This fan-driven project is unofficial and non-profit.
___ ___ ___

10.Find out more about this project at the following addresses:

Homepage	https://projectnemo.net/

Blog		https://useatoday.blogspot.com/

Romhacking.net	http://www.romhacking.net/translations/2307/
___ ___ ___

11.Translations for unsubbed speeches (M06, M29 and Epilogue)

- Mission 06 Ghosts of the Past -

Rena	With whom...?
	When...?
	With whom...?
	When...?
	When...?
	Before?
	Long ago....
	When...?
	Who....
	Who?
	When...?
	Who?
	I....
	A long time ago....
	I....
	A long time ago....
	I....
	A long time ago...!
	That person...!
	Dision!

 - Mission 29 Betrayal -

UNKNOWN	Good morning.
Is it over?
Who built this, and for what reason?
Just getting him involved is plenty.
Hey, that's enough.
W H O  are  Y O U?
Good morning.
Now, how about you understand this world...
W H A T did you do to M E?
Hey... look, he's looking at us.
Another... thirty seconds.
W H Y am I not D E A D yet...
Your copy's starting up over there.
It's over already, right?
You can see me?
Y O U  A R E N ' T  M E. W H O are Y O U?
You can see me?
S T O P! S T O P  I T!
You can see me?
Run!
You can see me?
I'm not D E A D yet...
You can see me?
Let's meet again.

___ ___ ___

*SPOILERS* DO NOT READ THIS BEFORE SEEING SIMON'S FINAL MESSAGE (Archive title: "We meet again."), after getting all five endings. There are guides on-line explaining the choices you need to make to get all of them.

|
|
|

|
|
|

|
|
|

Simon's final words to Nemo before releasing him:

"This time the story won't be pre-determined like the others. Let's start the game."