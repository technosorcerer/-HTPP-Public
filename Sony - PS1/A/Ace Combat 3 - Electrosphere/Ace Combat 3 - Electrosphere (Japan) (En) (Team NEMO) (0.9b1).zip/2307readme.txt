2024.01.01

Behold. Beware. Believe.

3-Dimensional Dramatic Flight Shooting Game
____ ____ ____    ____ ____ _  _ ___  ____ ___    ____
|__| |    |___    |    |  | |\/| |__] |__|  |     ___|
|  | |___ |___    |___ |__| |  | |__] |  |  |     ___|

____ _    ____ ____ ___ ____ ____ ____ ___  _  _ ____ ____ ____
|___ |    |___ |     |  |__/ |  | [__  |__] |__| |___ |__/ |___
|___ |___ |___ |___  |  |  \ |__| ___] |    |  | |___ |  \ |___

"What do you believe in? What are you fighting for in this world...?"

English Fan-Translation v0.9b1

A Team NEMO Joint

+-+-+-+-+-+-+-+-+
|C|O|N|T|E|N|T|S|
+-+-+-+-+-+-+-+-+

1.Synopsis
2.Information
3.Instructions
4.Checksums
5.Changelog
6.Tips
7.Links
8.Credits
9.Copyright
10.Disclaimer

===============================================================

   +-+-+-+-+-+-+-+-+
1. |S|Y|N|O|P|S|I|S|
   +-+-+-+-+-+-+-+-+

"Wanna play a game of Simon Says?"

The age of nation-states is over.
Corporations hold total control.
Technology is choking mankind.
As bad as things are... they're about to get worse. Much worse.

USEA, 2040. Worldwide tension mounts as the two largest
multinational corporations escalate from competition to total
war. On the information superhighway known as the
Electrosphere, a terrorist group is preparing a revolution to
eliminate the inequalities and limitations of humankind.

Through these skies flies NEMO (the player), fighter pilot and
peacekeeper. But someone he knows is setting him up for a
brutal murder, and RENA (VA: Yuri Shiratori), famous ace pilot
and Nemo's squadron leader, could be the next target. There are
only two people he thinks he can trust; his wingmen ERICH (VA:
Sōichirō Hoshi), a rookie idealist forced to find himself
amidst the war, and FIONA (VA: Kumiko Watanabe), a tough-but-
sweet pacifist looking for another way to stop it. 

As the world spins toward chaos, Nemo, Rena, Erich and Fiona
must navigate this volatile landscape before the enemy's plan
becomes reality.

A visionary dive into an explosive world of all-powerful
corporations and high technology, Ace Combat 3: Electrosphere
paints a frighteningly real portrait of our society's
collective future. Filled with high-flying action and an
intricate storyline, it is a cautionary tale that touches on
the secret fears and dreams buried within us all.

===============================================================

   +-+-+-+-+-+-+-+-+-+-+-+
2. |I|N|F|O|R|M|A|T|I|O|N|
   +-+-+-+-+-+-+-+-+-+-+-+

		NTSC-J - SLPS-02020~1 - Namco Ltd. (5.27.1999)
Patches: 	Ace Combat 3 Electrosphere (English v0.9b1 CD1)
		Ace Combat 3 Electrosphere (English v0.9b1 CD2)
Extras:		Deleted and Extended Scenes
		- Deleted Scenes
		- Extended Scenes
		Direct Audio with AppenDisc (8.26.1999)
		- Interview with the Sound Team
		- Track List
		- Movie Player Titles
		- Original Movie (8:45) (URL)
		Mission & World View (6.30.1999)
		- Backstory
		- Timeline
		- Interview with the Development Team
		- List of Mission Completion Rates
		Mission 00 AKA Mission Zero (6.5.1999)
		- Video (35:02) (URL)
		- Cassette
		Namco Official Guide Book (5.27.1999)
		- Prologue
		- The History of USEA
		- Chronological Table
		- Organizations
		- Characters
		- Mission Flow Chart
		- Mission Story
		- Notes
		- The Analysis of Fighters
		- Face-to-Face with the Director and the Writer
		Promotional Materials
		- In-store Video (10:02) (URL)
		- Namco Catalog 1999
		- Tokyo Game Show '99 Spring
		- Wallpapers
		- Flyers
		- Magazine Ads
		- Ridge Racer Type-4 (1998) AC3 Billboard
		- Tokyo Game Show 1999 Teaser (0:40) (URL)
		- TV spots (0:15x3) (URL)
		- UPEO Pin Badge
		Uncategorized
		- HTML script by BRPXQZME (8.11.2010)
		- Supplementary Interviews
		- Web Links
		- Debut Sales Figures
		- Developer Diaries (URL)
		- Explanation of AC3E
		- Famitsu Weekly 'New Game Cross Review'
		- Hi-res Images on GameGrin
		- Hi-res Promos on MobyGames
		- Japanese Mission Titles
		- "Official Localization Post-Mortem" (URL)
		- Preview by Dengeki PlayStation (URL)
		- Secret Menu (URL)
		- "The Prototype for Electrosphere" (URL)
		External Script (audio-only segments)
Subtitles: 	English
Aspect ratio:	Full-screen (320x480i, 320x240p)
Picture format: Non-anamorphic
TV system:	NTSC
Soundtracks:	Japanese Stereo, Japanese Mono
Patch format:	xdelta
Notes: SLPS-02020~1, the most recent version of the game, is
almost fully translated, except for: incidental radio chatter,
three audio-only sections, and signs embedded onto some FMVs.
Text translations for the aforementioned audio-only sequences
can be found in the Supplements folder.
Tools to verify and patch your disc images have been included
for convenience (instructions in the next section).
Supplements translated by DragonSpikeXIII unless otherwise
noted.

===============================================================

   +-+-+-+-+-+-+-+-+-+-+-+-+
3. |I|N|S|T|R|U|C|T|I|O|N|S|
   +-+-+-+-+-+-+-+-+-+-+-+-+

First, make sure your rips are in BIN/CUE format. The checksums
we support are listed in the next section. Please verify your
images before attempting to patch them; if they don't match,
the patching process will fail.

I) Open the Tools folder and double-click on "Delta Patcher."

II) One box will say "Original file" and one "XDelta patch."
Click the folder icon and select the BIN file of your unpatched
image and do the same below for that disc's patch.

III) Click "Apply patch." Your patched image is now ready.

===============================================================

   +-+-+-+-+-+-+-+-+-+
4. |C|H|E|C|K|S|U|M|S|
   +-+-+-+-+-+-+-+-+-+

SLPS-02020
Size
683 MB (716,287,488 bytes)
Size on disk
683 MB (716,288,000 bytes)

SLPS-02021
Size
690 MB (723,813,888 bytes)
Size on disk
690 MB (723,816,448 bytes)

CRC32
SLPS-02020
CCDDA3B5
SLPS-02021
B86E0F52

MD5
SLPS-02020
30F7DCE98B6901290CB26C9BAF27268F 
SLPS-02021
50760963AE8A26EA0188B165F05B33A1

SHA-1
SLPS-02020
8C6D58308EB389A7B18BC213A6D1E23D14FD3C10
SLPS-02021
A23E046B1EB695E02D214D269FCA70DBE0A437F7

SHA-256
SLPS-02020
CFDEC8640CFB0FE5C1AD1AD8C76C958D756FBE75D73E1F449D468EBBAFB8D60
F
SLPS-02021 
CFD9CD36BA858AA81927306EC761A228C8E88BE48F1B1DB9AC9D7F2BDBE8C85
4

===============================================================

   +-+-+-+-+-+-+-+-+-+
5. |C|H|A|N|G|E|L|O|G|
   +-+-+-+-+-+-+-+-+-+

Version history:

2014.12.25 Playable Demonstration Release (first four missions)

2015.06.28 v1.0 "status quo alteration" (Disc 1 patch)

2015.07.29 v1.1 Re: Disc 1 (update, xdelta format adopted)

2016.12.14 v2.0 "Heaven and Earth" (Discs 1 and 2[main script])

2023.07.13 v0.9b "Phoenix" (all in-game subtitles translated)

Current version: v0.9b1 "Re: Phoenix"

Quick rundown: minor edits based on user feedback; M03's FMV
signs translated; fixed Rena's message after M07; "In-store
Video" fansubbed; Namco catalog scanned; AC3e at TGS '99;
cheats added to "Tips" section.

Detailed explanation (from v0.9b): Text translated

- the main script has been overhauled with a new translation
and new fonts.

- the Search Engine and the Archive are now also completely
translated. Previously translated entries have been updated.

- the Options menu and all other menus, namely the blue ones,
are completely in English for the first time.

Graphics corrected

- M02: Teletext "F/A-18" changed to "F-16"

- M39: briefing "XFA-36A" changed to "F/A-32C"

- M51: mission title font now matches all other mission titles
More information: https://tinyurl.com/bdetmjb9

- Search: the missing "i" has been added to "Classfied"

Music

- M27: "Mind Flow" changed to "Defiled" as per OST booklet

Videos

- two FMVs, M01's "WORLD TOPICS" and M07's "Memory Fragment,"
have been edited where appropriate to display English text.

Other 

- Unused lines and other lines of dialogue whose triggers are
not known yet have also been translated, just in case.

Supplements

- deleted and extended scenes, editorials, guides, interviews,
promotional materials, trivia, videos, and more, have all been
translated. Previously translated extras have also been
included.

To-Do (Help Wanted!)

- in-game subtitles for audio-only story dialogue, which occurs
during M06, M29, and the Epilogue

- subtitles for the incidental radio chatter during missions

- music fix for M29 Betrayal ("Mind Flow" -> "The Execution")

===============================================================

   +-+-+-+-+
6. |T|I|P|S|
   +-+-+-+-+

- AC3e has five different routes, each with its own ending.
Save your progress before each Decision Point to save time
while completing the game (consult the Mission Flow Chart to
know where best to save).

- After clearing all five routes, the Epilogue will be shown,
followed by a Free Mission Mode called "Mission Simulator."
Access it in the "Download" menu by pressing the right button
until the "N" (new) button on screen becomes an "S" (sim).

- Completing all 52 missions with a D rank unlocks alternate
skins for some planes; C rank unlocks the UI-4054 "Aurora"; B
rank the XR-900 "Geopelia"; and A rank the Orbital Satellite
Laser. Unlockables can only be used in Mission Simulator mode.
See the List of Mission Completion Rates (Supplements/Mission &
World View) for information on how to get all As, which will
unlock everything all at once.

- There are cheats you can use in Mission Simulator mode. Input
the following commands after finalizing your loadout, while
the mission is loading:

[ Hold down Circle   + Start Button = Drop Bomb 	]
[ Hold down Cross    + Start Button = Plasma Beam 	]
[ Hold down Triangle + Start Button = O.S.L.	  	]
[ Hold down Square   + Start Button = Spread Bomb (A2A) ]

===============================================================

   +-+-+-+-+-+
7. |L|I|N|K|S|
   +-+-+-+-+-+

Homepage	https://projectnemo.net/

Blog		https://useatoday.blogspot.com/

Gallery		https://goo.gl/photos/716jCfqTEQfxku8F9

YouTube		https://www.youtube.com/@DragonSpikeXIII/videos

===============================================================

   +-+-+-+-+-+-+-+
8. |C|R|E|D|I|T|S|
   +-+-+-+-+-+-+-+

- Team NEMO (2009-2023) -


Project Manager/Lead Translator

DragonSpikeXIII


Support/Webmaster

iceman-uk


Translator, Mission and Archive Drafts (2009-2010)

BRPXQZME


Translator, Epilogue Draft (2009-2010)

pmt7ar


Hacker, Data Mining (2011)

Gipphe


Hacker, AC3 Toolkit, Decompression (2014-2016)

esperknight


Hacker, Tooling, Original Typesetter (2014-2016)

Dashman


Translator, Retranslations for v2.0 (2016)

Greenrose


Hacker/QA/Tooling/Typesetter (2018)

weissvulf


Co-founded by DragonSpikeXIII and iceman-uk on GameFAQS' AC3e
forum in 2009, "Project NEMO" is a US/UK joint effort that also 
features contributions from all over the world. It was named
after a project at the core of AC3e's story. The main group
itself is called "Team NEMO."


- Special Thanks -

ACE COMBAT 3 FANSITE http://www28.atwiki.jp/acacac/pages/4.html
(transcript, their effort made our work much easier) _/\_

Agness Kaku (for her 'Demo File')

CUE (PSX-MODE2)

Fabian, Avarik, Krishty, GaiaBlitz, Ribbon-Blue (Script Books)

Frognation LTD. (official translations)

Krishty (extractor)

M-35 (jPSXdec, technical support [Intro/Credits])

Mephisto (Tim2View)

midsummersnow (team logo from 2011)

momomeno (spot transcriptions [Search Engine])

Namco LTD. (official translations)

Namco HomeTek Inc. (strings [Aircraft/Weapon Stats])

ridtrikaplz (M27 BGM fix)

The Romhacking.net community (translation support and more)

Rythus (English 'Data-swallow' string [pre-edit])

rveach (TimViewer)

TaskForce23 (translation support, 'The Analysis of Fighters')

Testers: CJManson, ???, ???, ???

Infrid (compressor)

The kind soul that shared the guide books on ACS years ago _/\_

...and all those who have helped support our homepage!

===============================================================

   +-+-+-+-+-+-+-+-+-+
9. |C|O|P|Y|R|I|G|H|T|
   +-+-+-+-+-+-+-+-+-+

Original Japanese Version

(C)1999 NAMCO LTD., All Rights Reserved

Frognation LTD. and Production I.G Inc. are the owners of their
respective properties.


North American Version

(C)2000 NAMCO HomeTek Inc., All Rights Reserved


English Fan-Translation

(C)2009, 2024
Team NEMO
All Rights Reserved
Ask the project manager for permission to use it.
Commercial distribution is prohibited.


Delta Patcher 3.0.1 (C) 2022 Phoenix <phoenix_87_c(at)hotmail.
com>

GSFW is the property of David T. Ashley
(http://esrg.sourceforge.net/utils_win_up/md5sum/)

===============================================================

    +-+-+-+-+-+-+-+-+-+-+
10. |D|I|S|C|L|A|I|M|E|R|
    +-+-+-+-+-+-+-+-+-+-+

This project is unofficial and non-profit.

These patches and text translations are provided by the fan-
translators for free and separate from the products they were
derived from.

There may be errors present, such as mistranslations, typ0s and
bad grammer.

Official material hosted online is subject to DMCA (Digital
Millenium Copyright Act) law.

Any resemblance to reality is total coincidence.

And last but not least:
many AIs were harmed in the making of this translation.
