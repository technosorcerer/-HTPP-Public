-= Aconcagua English Patch =-

How to patch (On Windows):

1.  Unzip the included zip file
2.  Open the included program "Delta Patcher Lite" and click the first yellow folder icon. 
3.  Choose your original unmodified "Aconcagua (Japan) (Disc 1).bin" file.
4.  Click the second yellow folder icon and choose the "AconcaguaEnglishPatchDisk1.xdelta" file.
5.  If you don't want to lose your original unpatched game file, click the little gear icon next to the "Apply patch" box and click "Backup original file".
	-You will then need to remove the word "PATCHED" from the bin file's name later
6.  Click "Apply patch"!
7.	Repeat steps 3-6 using "Aconcagua (Japan) (Disc 2).bin" and "AconcaguaEnglishPatchDisk2.xdelta"
8.  Place the patched .bin files in the same folder as your "Aconcagua (Japan) (Disc 1).cue" and "Aconcagua (Japan) (Disc 2).cue" files and they're ready to be played!

How to patch alternative (All OS):

1.  Go to https://hack64.net/tools/patcher.php
2.  For ROM, enter the original "Aconcagua (Japan) (Disc 1).bin" file.
3.  For Patch, enter the "AconcaguaEnglishPatchDisk1.xdelta" file.
4.  For Save as, enter "Aconcagua (Japan) (Disc 1).bin".
    -If you don't want to lose your original unpatched game file, make a backup of it now.
5.  Click Patch and place the patched "Aconcagua (Japan) (Disc 1).bin" file in the same folder as your "Aconcagua (Japan) (Disc 1).cue" file
6.	Repeat steps 2-5 using "Aconcagua (Japan) (Disc 2).bin" and "AconcaguaEnglishPatchDisk2.xdelta" and they're ready to be played!

-----!!!!IMPORTANT NOTES!!!!-----
1. 	Aconcagua has a terrible audio bug when playing on the Duckstation emulator. This is NOT due to the patch, as this
	happens on the standard Japanese version as well. I recommend using the Bizhawk emulator to play the game.
2.	At the end of disc 1, some emulators have trouble performing the disc swap to disc 2. However, this is not a problem,
	as you can simply turn off the emulator, load up disc 2, and load your save from the end of disc 1.
3.	You may notice that the subtitles during voiced cut scenes sometimes don't 100% match up with the voices.
	This is due to very complicated technical reasons that prevent us from expanding the size of the original
	subtitles. However, I've taken lengths to ensure that the subtitles are still descriptive and meaningful for
	players who rely on reading the subtitles.
-----!!!!IMPORTANT NOTES!!!!-----

Still have questions? Want to report bugs and typos? Join my Discord channel: https://discord.gg/M4VkVemWgG
Want to support the patch creator? https://patreon.com/hilltopworks - https://ko-fi.com/hilltop

Credits:
Localization and hacking: 				Hilltop					@HilltopWorks
Graphics and Spanish language support: 	Mr. Nobody				@mrnobodystudios
FMV programming (jPSXdec developer):	Michael "m35" Sabin 	https://github.com/m35/jpsxdec

Follow me on twitter at https://twitter.com/HilltopWorks for news on future English patches.


Software Licenses:

jPSXdec is used for "revenue generating business activities" with explicit permission from the rights holder:

jPSXdec: PlayStation 1 Media Decoder/Converter in Java
Copyright (C) 2007-2022 Michael Sabin
All rights reserved.

Redistribution and use of the jPSXdec code or any derivative works are permitted in the efforts to
translate the PlayStation game “Aconcagua” to English provided that the following conditions are met:
	-Redistributions may not be sold.
	-Redistributions that are modified from the original source must include the complete source
	 code, including the source code for all components used by a binary built from the modified
	 sources. However, as a special exception, the source code distributed need not include anything
	 that is normally distributed (in either source or binary form) with the major components
	 (compiler, kernel, and so on) of the operating system on which the executable runs, unless that
	 component itself accompanies the executable.
	-Redistributions must reproduce the above copyright notice, this list of conditions and the
	 following disclaimer in the documentation and/or other materials provided with the
	 distribution.
	-The English translation of the PlayStation game “Aconcagua” is made available for free

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.