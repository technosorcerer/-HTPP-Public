--------------------------Info---------------------------
Game name: Alien Resurrection
Console: PlayStation
Game ID EUR: SLES-02913
Patcher: Cheat Patcher v0.7 or higher.
----------------------------------------------------------
--------------------------patch------------------------
Patch add next feature:
 New control buttons config.

 �ontrol config:
  UP   - look down      
  DOWN   - look up
  <-   - look left
  ->   - look right

  X   - move back
  []   - strafe left
  O   - strafe right
  /\   - move forward        

  R1   - action/gun reload
  R2   - fire
  L1   - quick turn
  L2   - crouch
  

  SELECT   - use item
  SELECT +  L1/L2   - select item
  SELECT +  R1/R2   - select weapon

 Aim move speed  fix.
--------------------Cheat Patcher------------------
Download link:
http://www.romhacking.net/utilities/1112/
----------------------------------------------------------
Author by Mr2.
e-mail: fsocp@land.ru
http://rgcorp.ucoz.net/