package com.pdfjet;


public class IoStream {
    public static final int END = -1;
}
