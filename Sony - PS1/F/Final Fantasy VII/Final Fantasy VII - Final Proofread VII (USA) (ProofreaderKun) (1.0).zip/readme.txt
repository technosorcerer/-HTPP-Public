//INSTALLATION//
Apply each .xdelta patch to the respective disc's .bin using the xdelta UI:
	https://www.romhacking.net/utilities/598/
	
//BACKGROUND//
Despite scorn in recent years, Final Fantasy VII's English translation is excellent.
It's difficult to imagine how millions of English speakers would consider it among
the greatest stories ever written if the very English version they played truly were
the indecipherable mess it's sometimes made out to be.

It did however deserve a proofreading. Not from another Japanese speaker, but another English speaker.

This hack is thus a very conservative update to the game's field text; by
editing the script concurrently with playing the game in-full, I've fixed awkward grammarisms,
removed instances of "the Shinra", incorporated the best of the PC version's text changes,
and tried to make sense of what little truly made no sense.

As I wanted to play to the strengths of the beloved and unique English version, I have only
very sparingly referenced the Japanese script, and in 99% of such cases it was
simply to make sense of any nonsense I could not intuit from the English script alone.
This means Aeris still calls Zack her first boyfriend, Tifa still calls Barret a retard,
and Cait Sith is still in the game.

This is the Final Fantasy VII you remember.

//RESOURCES//
Makou Reactor (text editing):
	https://github.com/myst6re/makoureactor
	
PlayStation vs PC script differences:
	https://www.neoseeker.com/final-fantasy-vii/faqs/163296-psx-pc-script.html
	https://thelifestream.net/ffvii-the-original/ffvii-version-guide/ps-english-versus-pc-english/
	
Japanese script:
	https://jackindisguise.github.io/final-fantasy-vii-catalog/scenes.html
	
Readings of the Japanese script:
	https://lizbushouse.com/final-fantasy-vii-script-comparison/
	https://kotaku.com/s/final-fantasy-vii
