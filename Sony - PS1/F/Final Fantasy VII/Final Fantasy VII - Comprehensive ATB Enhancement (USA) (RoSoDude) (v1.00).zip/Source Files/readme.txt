The BATTLE.X modules included in these subfolders are for use with PSX hacks that change FF7's file system.

If you are using these files, do NOT use the PPF patches! They are at best redundant, and at worst will completely mess up your FF7 ROM depending on the file system of the patch you used

You will need:
-The FF7 ROM (.bin) patched with your hack of choice 
-The associated .cue file for your FF7 ROM
-A disc image editing tool (CDMage or PowerISO)

After patching your FF7 ROM with your hack of choice, load its .cue file into your disc image editor. You should be able to view the file system and see the battle module \Track 1\BATTLE\BATTLE.X

You will be replacing the battle module. Your options are as follows:
1) \Base ATB modules\ATB\:
	-ATB Enhanced
	-Default configuration. Identical to main PPF patch
2) \Base ATB modules\ATBplus\:
	-ATB Enhanced + ARMs Damage Limit Break (Lucky 7s fury removed)
	-Intended for GalenMyra's HardType mod. Identical to "Plus" PPF patch
3) \Base ATB modules\ATBplus7777\:
	-ATB Enhanced + ARMs Damage Limit Break (Lucky 7s fury intact)
	-Intended for CAulin's Reborn mod (already integrated as of v5.0)
4-6) \CTB Wait modules\...\
	-CTB Wait equivalents to 1-3, to be used in the same manner

Use your disc image editor to import the appropriate BATTLE.X module into the ROM. Click to confirm if asked to pad with zeros. You are now done!

Please note that the BATINI.X file as part of ARMs Damage Limit Break hack is NOT redistributed here! These BATTLE.X files are for compatibility with ROMs that have already been patched with it