Final Fantasy 7 -- Comprehensive ATB Enhancement v1.00
by RoSoDude https://rosodudemods.wordpress.com/

Final Fantasy 7's ATB system is serviceable, but the functionality of the Recommended mode leaves something to be desired. Intended to bridge the gap between strict animation pausing of FF5 and the looser command queue of FF6, FF7's Recommended mode is designed to let time pass during shorter animations but pause time during longer battle animations. However, this was accomplished using an esoteric set of conditions that makes the ATB pause seem inconsistent and unreliable. In the original implementation, time pauses [1-5] seconds after the start of the animation if the player and enemy parties have had an equal number of turns; otherwise time pauses [1-5] seconds after any character (player or enemy) reaches full ATB during the animation ([1] second on fastest Battle Speed, [3] seconds on default Battle Speed, [5] seconds on slowest Battle Speed). This rule excludes limit breaks and counter moves, which extend any current or pending pause if executed directly after another animation, but never pause time when executed on their own. Summon animations (which pause time even in Active mode) and Wait mode menu selections utilize a separate pausing system and work consistently.

This patch cuts out the complicated conditionals and [1-5] second timer for pausing in place of a much simpler rule: time pauses during animations as soon as any character (player or enemy) reaches full ATB. Limit breaks and counter moves still extend any current/pending pause (and thus yield turn advantage to the user), but also can now pause time when executed on their own. This rule maintains the flow of battles on all Battle Speed settings, while subtly improving the balance and legibility of the ATB system. Since ATB speed is now much more meaningful, Haste now speeds up timers by 1.5x instead of 2x. In addition, all timers now properly scale with Battle Speed: in particular, Death Sentence and Slow-numb now tick 4x faster on the fastest Battle Speed, 1.34x faster on the default Battle Speed, and 0.79x slower on the slowest Battle Speed, aligning them with all other battle timers.

Included alongside the main hack is an alternate "CTB Wait Addon" patch which removes all active time elements from battle when "Wait" mode is selected, similar to FF10's Conditional Turn-Based battle system. See the separate readme for details.

The hack should be compatible with other FF7 hacks, but with some caveats:
-As it replaces the compressed BATTLE.X module, any other hacks that replace this module will have their changes overwritten by this patch. In an effort to mitigate this, I've included the W-item bugfix in all versions of the patch, and also have a "Plus" patch version which includes the ARMs Damage Limit Break (no Lucky 7s fury) patch. This "Plus" PPF can be patched directly on top of GalenMyra's HardType mod
-In addition, any hacks that change FF7's file system (e.g. CAulin's Reborn mod, which integrated this patch as of v5.0) alter the sector offsets, so my patch would overwrite the wrong area on the ROM. As a solution, I have included versions of the BATTLE.X module to be inserted directly onto the ROM; use these instead of the PPF patches! Instructions are provided in the \Source Files\ folder
-If the game gets stuck on a black screen while loading (title screen or battles) when used alongside another hack, you need to use error_recalc or EDCRE to fix the EDC/ECC data on your ROM

Source files for assembly and hex codes are included as a reference for other modders.

Credits to Ortew for the W-Item bugfix
Credits to ARMs for the Damage Limit Break patches
Acknowledgements to Bosola for instructions on GZIP compression
Acknowledgements to FFHacktics community members Tallcall, Sardek, Xifanie, and RetroTypes for essential tips on MIPS assembly/PSX debugging

Changelist:
v1.00 
-Initial Release