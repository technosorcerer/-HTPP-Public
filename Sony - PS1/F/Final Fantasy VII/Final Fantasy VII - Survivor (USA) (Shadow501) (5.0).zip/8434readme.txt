This Patche is for fans only, not for sales.
All rights reserved (C) Square Enix

Patch working on the orginal version

Final Fantasy VII is viewed as one of the best games
RPGs, as well as games in general, are very popular.
Some of them played this game in the 90s at that time
They may wish there was a scenario to save some characters or deviate the events of the story
One way or another, but there are fans of the game who were insisting on continuing the events As it is, 
I offer this patch to those who wished that one of the main and pivotal characters in the story had survived
She is Aeris/Aerith.
-Save Aerith
  It has put a lot of effort into showing its event in a way that engages the player
The event is received as if it had originally happened. Aerith will participate in a small phase in the second disc in the Snow Village once Cloud receives a punch from Elena,
Put Aerith in your party then start the ski event, then she will leave the party, and the events of the game proceed unchanged, but without her participation in the basic story, while modifying the dialogues that she remembers before going to the northern cave.
Aerith will join the team in the third disc, but will not participate in the northern cave.
Patch also included
- Playing as Sephiroth?!
 On the third disc, when entering the city of Nibelheim, head to the hotel on the second floor
You will find Sephiroth, but as one of his wandering clones, you can benefit
Of his supernatural powers, but on the condition that Vincent never joins your group.
You won't be able to play with him in the northern cave.
- The meeting with Cloud's mother on the third disc.
- Visit the unbroken city of Mideel in the third disc by speaking
With one of the guys downtown.
- Honey Bee Inn has reopened with some additions at the entrance
- Add challenges In Wall Market with Aniki on all discs
- Possibility of visiting Sector 7 slums again
- In Gold Saucer, keep the possibility of riding the moving cart with anyone
Team members in disc three.
- In Gold Saucer, it is possible to participate in the theatrical show by speaking
With the man at the entrance. On the third disc.
- Plying football again in Costa del Sol
And other additions that support the game and do not affect the level of power in the game.

Enjoy!

All rights reserved (C) Square Enix