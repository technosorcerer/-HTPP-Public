New PSX patch created. It also works with the xdelta patcher (after all, it works great that way), so you'll have to use CDMage to replace the old scene.bin, kernel.bin, mds7pb_1.dat, limtmenu.mnu and shopmenu.mnu with the new ones.



FFVII AV Demo v1.0, by ArmorVil
*******************************

NOTE: Everything is edited up to the world map. That means you should never load a game with my patch. 
Always start a new game, and don't continue it after the Midgar events or bad things will happen.

Installation instructions:
-------------------------

1) If you don't have one already, create a CD image of your FFVII Disc 1. You can do so with most CD-burning utilities 
like Nero, Alcohol, Clone CD, etc.

2) OPTIONAL : make a backup of your iso, so you always have a clean original.

3) Double-click CDmage.exe. Select "File", "Open", and choose your CD image. Now, click on the + sign in front of 'Track1',
and click on BATTLE. A list of files will appear in the right window. Right-click on SCENE.BIN, choose "Extract files...",
and choose to extract it in the folder you put all of my files into. 

4) Do the same thing you did for SCENE.BIN, for the files named KERNEL.BIN, MDS7PB_1.DAT, LIMTMENU.MNU, and
SHOPMENU.MNU. Here is where you can find them :

- KERNEL.BIN inside the INIT folder ;
- MDS7PB_1.BAT inside the FIELD folder. There a lot of files in there, and they're organized alphabetically ;
- LIMTMENU.MNU and SHOPMENU.MNU inside the MENU folder.

5) Now, all those files should be in the same directory as all the files I provide. Follow these simple steps :

6) Double-click "apply scene patch.bat"

7) Double-click "apply kernel patch.bat"

8) there is no step 8 :P

9) Double-click "apply mds7pb_1 patch.bat"

10) Double-click "apply limtmenu patch.bat"

11) Double-click "apply shopmenu patch.bat".

12) Now, the files sceneav.bin, kernelav.bin, mds7pb_1av.dat, limtmenuav.mnu and shopmenuav.mnu 
have been created. Those are the files that you now have to insert in place of the originals, in your CD image.

13) Either move, delete or rename scene.bin, kernel.bin, mds7pb_1, limtmenu.mnu, and shopmenu.mnu,
so you can rename the new files in their respective counterparts (in other words, just delete the "av" characters
in their names). 

14) Go back to CDMage, and right click on SCENE.BIN. Select "Import File...", and select the newly created 
SCENEav.BIN that you just renamed into SCENE.BIN. Chances are the tool will tell you that the imported file is
shorter than the original, and it will ask you if you want to match its file-length by adding 0s. Choose "yes".

15) Do step 14 again, but for the 5 other files (KERNEL.BIN, MDS7PB_1.DAT, LIMTMENU.MNU, and SHOPMENU.MNU). 

16) Now your CD image has entirely been patched. You can close cdmage, and either immediately play the game with
a PSX emulator, or you can burn your CD Image on a CD to play it on the PSOne (not advisable, since this is only
a demo that ends after Midgar - but if you have a CD to spare, go ahead). 

Not the easiest installation process, I know, but at least it should work flawlessly now.

-Credits
--------

The entire Qhimm community. Sorry, I'm too lazy to type the name of all the people who helped 
me a bunch (and there are many!) at the moment, but I'll be sure to mention them in the final 
readme (the one that will come with the complete mod).

Questions, comments, critiques ? Please drop by this thread on the Qhimm forums :

http://forums.qhimm.com/index.php?topic=11019.0

Thanks for trying the demo! All feedback is appreciated =)