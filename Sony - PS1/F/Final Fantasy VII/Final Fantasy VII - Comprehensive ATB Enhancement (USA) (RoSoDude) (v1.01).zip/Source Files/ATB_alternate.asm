;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; RoSoDude's Comprehensive ATB Enhancement v1.00
; Alternative Wait mode (Conditional Turn-Based)
; The patch must be assembled onto the BATTLE.X module
; Guide to module decompression/compression:
; https://forums.qhimm.com/index.php?topic=15074.0
; After importing the module, fix EDC/ECC data on the ROM
; error_recalc.exe (Windows): https://www.romhacking.net/utilities/1264/
; EDCRE (Windows/Linux): https://github.com/alex-free/edcre
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; Implements ATB pause during ANY menu in Wait mode (not just submenus)
; Also pauses if any command is currently waiting on the queue (time only moves between commands)
; Gameplay in Wait mode resembles FF10 CTB
; Fleeing in Wait mode reverts to Recommended mode behavior (can be used to pass time)
; Assembled on top of ATB_Enhanced.asm changes

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; ATB animation pausing/turn-based Wait
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

; Original code (ATB Recommended/Wait Animation Pause Check):
000a32c0: 3c02800f lui r2,0x800f
000a32c4: 94427daa lhu r2,0x7daa(r2)		; r2 = $0x800F7DAA			(0b01 = 0x01 if ATB Recommended, 0b10 = 0x02 if ATB Wait)
000a32c8: 27bdffe8 addiu r29,r29,0xffe8		; r29 = r29 - 0x0018
000a32cc: 1040001d beq r2,r0,0x000a3344		; skip ATB animation pause check if neither Recommended nor Wait
000a32d0: afbf0010 sw r31,0x0010(r29)
000a32d4: 10800012 beq r4,r0,0x000a3320		; branch if r4 == 0... 		(no active command)
000a32d8: 34020006 ori r2,r0,0x0006			; ...with r2 = 0x06
000a32dc: 3c03800f lui r3,0x800f
000a32e0: 94637dba lhu r3,0x7dba(r3)		; r3 = $0x800F7DBA			(0x06 during normal attacks, 0x05 during limit breaks, other for counters etc.)
000a32e4: 00000000 nop
000a32e8: 14620016 bne r3,r2,0x000a3344		; branch if r3 != 0x06		branch out if not a normal attack
000a32ec: 00000000 nop
000a32f0: 3c03800f lui r3,0x800f
000a32f4: 90636b9a lbu r3,0x6b9a(r1)		; r3 = $0x800F6B9A			(current queue position)
000a32f8: 3c02800f lui r2,0x800f
000a32fc: 90426ba1 lbu r2,0x6ba1(r2)		; r2 = $0x800F6BA1			(total queue length)
000a3300: 00000000 nop
000a3304: 10620002 beq r3,r2,0x000a3310		; branch if r3 == r2...
000a3308: 34070001 ori r7,r0,0x0001			; ...with r7 = 0x01			(if no moves waiting on queue, animation pause flag is 0x01)
000a330c: 34070003 ori r7,r0,0x0003			; otherwise r7 = 0x03		(if moves waiting on queue, animation pause flag is 0x03)
000a3310: 00002021 addu r4,r0,r0			; r4 = 0
000a3314: 00002821 addu r5,r0,r0			; r5 = 0
000a3318: 08028ccf j 0x000a333c				; jump to queue animation pause flag...
000a331c: 34060007 ori r6,r0,0x0007			; ...with r6 = 0x0007
000a3320: 0c028dfe jal 0x000a37f8			; call to set animation pause flag directly...
000a3324: 2404ffff addiu r4,r0,0xffff		; ...with r4 = 0xFFFF (null)
000a3328: 10400006 beq r2,r0,0x000a3344		; branch if r2 == 0...	(no need to queue animation pause flag = 0 because it is already set)
000a332c: 00002021 addu r4,r0,r0			; ...with r4 = 0
000a3330: 00002821 addu r5,r0,r0
000a3334: 34060007 ori r6,r0,0x0007
000a3338: 00003821 addu r7,r0,r0
000a333c: 0c029c95 jal 0x000a7254			; call to calculate animation pause flag
000a3340: 00000000 nop
000a3344: 8fbf0010 lw r31,0x0010(r29)
000a3348: 27bd0018 addiu r29,r29,0x0018
000a334c: 03e00008 jr r31
000a3350: 00000000 nop

; New code (ATB Recommended/Wait Animation Pause Check):
000a32c0: 3C01800F lui r1,0x800f
000a32c4: 94257DAA lhu r5,0x7daa(r1)		; r5 = $0x800F7DAA			(0b01 = 0x01 if ATB Recommended, 0b10 = 0x02 if ATB Wait)
000a32c8: 27BDFFE8 addiu r29,r29,0xffe8		; r29 = r29 - 0x0018
000a32cc: 10A00017 beq r5,r0,0x000a332c		; skip ATB animation pause check if neither Recommended nor Wait
000a32d0: AFBF0010 sw r31,0x0010(r29)
000a32d4: 10800019 beq r4,r0,0x000a333c		; branch if r4 == 0... 		(no active command)
000a32d8: 94237DBA lhu r3,0x7dba(r1)		; ...with r3 = $0x800F7DBA	(0x06 during normal attacks, 0x05 during limit breaks, other for counters etc.)
000a32dc: 34020006 ori r2,r0,0x0006			; r2 = 0x06					(check if normal attack)
000a32e0: 10620008 beq r3,r2,0x000a3304		; branch if r3 == 0x06...	(skip ahead to check queue if so)
000a32e4: 34020005 ori r2,r0,0x0005			; ...with r4 = 0x0005		(check if limit)
000a32e8: 14620002 bne r3,r2,0x000a32f4		; branch if r3 != 0x05...	(skip to check for existing pause flag if not)
000a32ec: 34030002 ori r4,r0,0x0002			; ...with r4 = 0x0002		(check Wait mode)
000a32f0: 10850009 beq r4,r5,0x000a3318		; branch if r4 == r5...		(set pause flag to 0x03 if a limit in Wait mode)
000a32f4: 8C2239E0 lw r2,0x39e0(r1)			; ...with r2 = $0x800F39E0	(animation pause flag)
000a32f8: 00000000 nop
000a32fc: 30420001 andi r2,r2,0x0001		; r2 = r2 AND 0x01, true if it's equal to 0x01 or 0x03
000a3300: 1440000A bne r2,r0,0x000a332c		; branch out if we already have a current/pending pause...
000a3304: 90236B9A lbu r3,0x6b9a(r1)		; ... with r3 = $0x800F6B9A	(current queue position)
000a3308: 90226BA1 lbu r2,0x6ba1(r1)		; r2 = $0x800F6BA1			(total queue length)
000a330c: 00000000 nop
000a3310: 10620002 beq r3,r2,0x000a331c		; branch if r3 == r2...
000a3314: 34070001 ori r7,r0,0x0001			; ...with r7 = 0x01			(if no moves waiting on queue, animation pause flag is 0x01)
000a3318: 34070003 ori r7,r0,0x0003			; otherwise r7 = 0x03		(if moves waiting on queue, animation pause flag is 0x03)
000a331c: 00002021 addu r4,r0,r0			; r4 = 0
000a3320: 00002821 addu r5,r0,r0			; r5 = 0
000a3324: 0C029C95 jal 0x000a7254			; call to calculate animation pause flag
000a3328: 34060007 ori r6,r0,0x0007			; ...with r6 = 0x07
000a332c: 8FBF0010 lw r31,0x0010(r29)
000a3330: 27BD0018 addiu r29,r29,0x0018
000a3334: 03E00008 jr r31
000a3338: 00000000 nop
000a333c: 0C028DFE jal 0x000a37f8			; call to set animation pause flag directly...
000a3340: 2404FFFF addiu r4,r0,0xffff		; ...with r4 = 0xFFFF (null)
000a3344: 1040FFF9 beq r2,r0,0x000a332c		; branch if r2 == 0...	(no need to queue animation pause flag = 0 because it is already set)
000a3348: 00000000 nop
000a334c: 08028CC7 j 0x000a331c				; jump optimization
000a3350: 00003821 addu r7,r0,r0			; ...with r7 = 0

; MassHexASM output:
0F80013C AA7D2594 E8FFBD27 1700A010 1000BFAF 19008010 BA7D2394 06000234 08006210 05000234 02006214 02000434 09008510 E039228C 00000000 01004230 0A004014 9A6B2390 A16B2290 00000000 02006210 01000734 03000734 21200000 21280000 959C020C 07000634 1000BF8F 1800BD27 0800E003 00000000 FE8D020C FFFF0424 F9FF4010 00000000 C78C0208 21380000 
; MassHexASM output:
0F80013C AA7D2294 E8FFBD27 1D004010 1000BFAF 13008010 06000234 BA7D2394 01000734 0B006210 05000234 04006214 AA7D2294 02000334 06006210 03000734 E039228C 00000000 01004230 0D004014 01000734 21200000 21280000 CF8C0208 07000634 FE8D020C FFFF0424 05004010 00000000 C58C0208 21380000 959C020C 00000000 1000BF8F 1800BD27 0800E003 00000000
; replaces:
0F80023C AA7D4294 E8FFBD27 1D004010 1000BFAF 12008010 06000234 0F80033C BA7D6394 00000000 16006214 00000000 0F80033C 9A6B6390 0F80023C A16B4290 00000000 02006210 01000734 03000734 21200000 21280000 CF8C0208 07000634 FE8D020C FFFF0424 06004010 21200000 21280000 07000634 21380000 959C020C 00000000 1000BF8F 1800BD27 0800E003 00000000

; Original code (ATB Global Pause):
000a3868: 3c03800f lui r3,0x800f			; BEGIN ATB PAUSE CHECK SUBROUTINE
000a386c: 94637daa lhu r3,0x7daa(r3)		; r3 = (r3+0x7DAA) = $0x800F7DAA (0b01 = 0x01 if ATB Recommended, 0b10 = 0x02 if ATB Wait)
000a3870: 34020002 ori r2,r0,0x0002			; r2 = 0x02
000a3874: 1462000e bne r3,r2,0x000a38b0		; skip menu check if r3 != r2, i.e. not ATB Wait
000a3878: 00000000 nop
000a387c: 3c03800f lui r3,0x800f			; r3 = 0x800F0000
000a3880: 84633896 lh r3,0x3896(r3)			; r3 = $(r3+0x3896) = $0x800F3896 (menu halfword)
000a3884: 00000000 nop
000a3888: 2c62001c sltiu r2,r3,0x001c		; r2 = r3 < 0x001C
000a388c: 10400008 beq r2,r0,0x000a38b0		; branch if r2 == 0 (r2 >= 0x001C)...
000a3890: 00031080 sll r2,r3,0x02			; ...with r2 = r3 << 0x02
000a3894: 3c01800a lui r1,0x800a			; r1 = 0x800A0000
000a3898: 00220821 addu r1,r1,r2			; r1 = r1 + r2
000a389c: 8c2201b0 lw r2,0x01b0(r1)			; r2 = $(r1+0x01B0)
000a38a0: 00000000 nop
000a38a4: 00400008 jr r2					; jump to $r2 (e.g. 0x800A38AC for magic menu, 0x800A38B0 for main menu)
000a38a8: 00000000 nop
000a38ac: 34100001 ori r16,r0,0x0001		; r16 = 0x01 (set true if we got a pause from ATB Wait)
000a38b0: 0c0292a0 jal 0x000a4a80			; check for summon byte at $0x800FAFDC
000a38b4: 00000000 nop
000a38b8: 02028025 or r16,r16,r2			; r16 = r16 OR r2 (set true if we got a pause from ATB Wait OR summon)
000a38bc: 3c038010 lui r3,0x8010
000a38c0: 946383d0 lhu r3,-0x7c30(r3)		; r3 = $0x800F83D0
000a38c4: 3c02800f lui r2,0x800f
000a38c8: 8c4239e4 lw r2,0x39e4(r2)			; r2 = $0x800F39E4
000a38cc: 30630003 andi r3,r3,0x0003		; r3 = r3 AND 0x0003
000a38d0: 0003182b sltu r3,r0,r3			; r3 = ($0x800F83D0 AND 0x0003) != 0
000a38d4: 28424001 slti r2,r2,0x4001		; r2 = $0x800F39E4 < 0x4001
000a38d8: 14400002 bne r2,r0,0x000a38e4		; branch if r2 != 0, i.e. $800F39E4 < 0x4001...
000a38dc: 02038025 or r16,r16,r3			; ...with r16 = r16 OR r3 (set true if we got a pause from ATB Wait OR summon OR animation pause)
000a38e0: 34100001 ori r16,r0,0x0001		; r16 = 0x01
000a38e4: 02001021 addu r2,r16,r0			; r2 = r16
000a38e8: 8fbf0014 lw r31,0x0014(r29)		
000a38ec: 8fb00010 lw r16,0x0010(r29)		; set true for pause from ATB Wait, summon, $0x800F83D0 AND 0x0003 != 0 (???), or animation timer is greater than 0x4001 = 16385
000a38f0: 27bd0018 addiu r29,r29,0x0018
000a38f4: 03e00008 jr r31					; r31 = 0x800a3950
000a38f8: 00000000 nop

; New code (ATB Global Pause):
000a3868: 3c03800f lui r3,0x800f			; BEGIN ATB PAUSE CHECK SUBROUTINE
000a386c: 94637daa lhu r3,0x7daa(r3)		; r3 = (r3+0x7DAA) = $0x800F7DAA (0b01 = 0x01 if ATB Recommended, 0b10 = 0x02 if ATB Wait)
000a3870: 34020002 ori r2,r0,0x0002			; r2 = 0x02
000a3874: 1462000e bne r3,r2,0x000a38b0		; skip menu check if r3 != r2, i.e. not ATB Wait
000a3878: 00000000 nop
000a387c: 3c03800f lui r3,0x800f			; r3 = 0x800F0000
000a3880: 84633896 lh r3,0x3896(r3)			; r3 = $(r3+0x3896) = $0x800F3896 (menu halfword)
000a3884: 00000000 nop
000a3888: 04600009 bltz r3,0x000a38b0		; branch if r3 = 0xFFFF... (no character menu open)
000a388c: 00008021 addu r16,r0,r0			; ...with r16 = 0
000a3890: 3C028015 lui r2,0x8015
000a3894: 9442248E lhu r2,0x248E(r2)		; r2 = 0x8015248E (fleeing)
000a3898: 34630007 ori r3,0x0007			; 0x07 indicates fleeing
000a389c: 10430004 beq r2,r3,0x000a38b0		; branch if fleeing (no pause from ATB Wait)
000a38a0: 00000000 nop
000a38a4: 00000000 nop
000a38a8: 00000000 nop
000a38ac: 34100001 ori r16,r0,0x0001		; r16 = 0x01 (set true if we got a pause from ATB Wait)
000a38b0: 0c0292a0 jal 0x000a4a80			; check for summon byte at $0x800FAFDC
000a38b4: 00000000 nop
000a38b8: 02028025 or r16,r16,r2			; r16 = r16 OR r2 (set true if we got a pause from ATB Wait OR summon)
000a38bc: 3c038010 lui r3,0x8010
000a38c0: 946383d0 lhu r3,-0x7c30(r3)		; r3 = $0x800F83D0
000a38c4: 3c02800f lui r2,0x800f
000a38c8: 8c4239e4 lw r2,0x39e4(r2)			; r2 = $0x800F39E4
000a38cc: 30630003 andi r3,r3,0x0003		; r3 = r3 AND 0x0003
000a38d0: 0003182b sltu r3,r0,r3			; r3 = ($0x800F83D0 AND 0x0003) != 0
000a38d4: 28424001 slti r2,r2,0x0001		; r2 = $0x800F39E4 < 0x0001
000a38d8: 14400002 bne r2,r0,0x000a38e4		; branch if r2 != 0, i.e. $800F39E4 < 0x0001...
000a38dc: 02038025 or r16,r16,r3			; ...with r16 = r16 OR r3 (set true if we got a pause from ATB Wait OR summon OR animation pause)
000a38e0: 34100001 ori r16,r0,0x0001		; r16 = 0x01
000a38e4: 02001021 addu r2,r16,r0			; r2 = r16
000a38e8: 8fbf0014 lw r31,0x0014(r29)		
000a38ec: 8fb00010 lw r16,0x0010(r29)		; set true for pause from ATB Wait, summon, $0x800F83D0 AND 0x0003 != 0 (???), or animation timer is greater than 0x0001
000a38f0: 27bd0018 addiu r29,r29,0x0018
000a38f4: 03e00008 jr r31					; r31 = 0x800a3950
000a38f8: 00000000 nop

; MassHexASM output:
0F80033C AA7D6394 02000234 0E006214 00000000 0F80033C 96386384 00000000 09006004 21800000 1580023C 8E244294 07006334 04004310 00000000 00000000 00000000 01001034 A092020C 00000000 25800202 1080033C D0836394 0F80023C E439428C 03006330 2B180300 01004228 02004014 25800302 01001034 21100002 1400BF8F 1000B08F 1800BD27 0800E003 00000000
; replaces:
0F80033C AA7D6394 02000234 0E006214 00000000 0F80033C 96386384 00000000 1C00622C 08004010 80100300 0A80013C 21082200 B001228C 00000000 08004000 00000000 01001034 A092020C 00000000 25800202 1080033C D0836394 0F80023C E439428C 03006330 2B180300 01404228 02004014 25800302 01001034 21100002 1400BF8F 1000B08F 1800BD27 0800E003 00000000