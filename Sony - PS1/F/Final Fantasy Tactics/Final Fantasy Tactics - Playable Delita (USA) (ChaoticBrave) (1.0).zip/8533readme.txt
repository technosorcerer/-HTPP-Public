Playable Delita in Final Fantasy Tactics
========================================

What this does:

-Completely replaces playable Ramza with Delita. You will be going through the whole game with Delita's sprites and skills. These will change as when Ramza's did in the story. 

What this doesn't do:

-Change Ramza-specific sprites, such as when he bows to the Princess at the start, to look like Delita. Ramza with Delita's colour palette will be used.
-Change story context. There will be two Delitas in the story. You will be doing the heretic's story with a Delita coat of paint.
-Change the overworld and shops. The shop graphics will still use Ramza, and the overworld will still use Ramza sprites.

=========================

Instructions:

1) Make sure you have Delta Patcher and open it.
2) Load your ROM in the "Original file" field.
3) Put the patch in the "XDelta patch" field.
4) Click "Apply patch".
5) Done! Make the opponents blame themselves or God!

=========================

Credits:

ChaoticBrave: For making the patch of course!
NoharOSP: For a crash course on Delta Patcher.
melonhead and Glain: For the incredible FFTPatcher Suite.
Celdia: For a guide on importing custom formation screen sprites.