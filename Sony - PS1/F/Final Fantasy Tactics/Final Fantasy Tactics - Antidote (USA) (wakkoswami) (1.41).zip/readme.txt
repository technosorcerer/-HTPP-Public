Antidote is a rebalancing hack that attempts to give a viable use or value to as many aspects of FFT as possible while making few nerfs or flashy changes so you still feel like you're playing the same FFT, just with more options available. Both for you, and your AI adversaries.

Antidote's difficulty starts out about the same as the original game, but increases steadily as you progress. Most enemies have higher job levels with more abilities, secondary skillsets that they are proficient with, and/or slightly better equipment.

If the original release were to be thought of like a "Beginner" difficulty for new players, then this hack could be considered an "Intermediate" difficulty. Capable of keeping an experienced player on their toes, while still being beatable for those less skilled.

Antidote is built off of the Convenience version of my FFT: Prime hack (https://www.romhacking.net/hacks/4611) and includes all the goodies like the improved WOTL translation with Sound Novels and Spell Quotes, dialog skipping, bugfixes, ability/job stats made identical to the original JP release, halved ability costs, and guaranteed rare items when using the Chemist's Treasure Hunter ability.


		This hack includes:

			GENERAL CHANGES

The gamebreakingly powerful Arithmetician Job has been turned into the Sage, a mid to late game Job that uses a rebalanced "Ja-Magicks" skillset made up of Zalera's 6 -ja abilities and Ultima's Dispelja. In return for contributing their unique abilities to the player's use and having the MP costs and charge times increased, Zalera and Ultima both get innate Halve MP and Zalera gains the previously unused "CT 0" ability, making all of his spells cast instantly.

Maximum Level has been reduced from 99 to 50 and Speed growths have been halved for all Jobs, including monsters, to address late game balance issues. Additionally, many Speed altering abilities and items are slightly less effective and Haste/Slow's effect has been reduced from a 50% increase/decrease to 25%. Abilities with long charge times will still be usable at the end of the game.


			ABILITY CHANGES

Bravery/Faith changes are no longer permanent. Most abilities that alter Bravery/Faith are more effective to compensate, and the few Bravery alterations caused by choices made in dialog during the story are much larger.

Learn %, which affects both the AI's chance to learn an ability and the odds of getting it from a crystal, has been doubled for all abilities. Most are at 100% now.

Abilities used by human units that absorb HP/MP or damage a percentage of the target's HP (Invigoration/Gravity) are now Dark elemental. All Lucavi bosses now halve Dark damage.

Odds of stealing slightly improved for all but weapons. Thieves get 2 new abilities:
Steal Turn - Replaces Steal EXP - (SP+50)% chance to cancel an action while it is charging/being performed.
Flee - Move+3 when critically wounded.

Excluding Steel, Squire abilities that increase stats now add status effects instead:
EX: Tailwind - SP+1 changed to Effect: Haste.

All Swordskills, like Shadowblade, have been given MP costs.

Sky/Nether Mantra abilities have their Vertical Ranges reduced from 3 to 0, making it easier to hit the spaces you want with them. MP costs added. Nether Mantras fixed to do max damage with Atheist and no damage with Faith.

Cloud's Limit abilities gain +50% power, and do similar damage as the US PS1 release of the game.

All 8 Range weapons/abilities reduced to 6. (Guns, Shockwave, Horizontal Jump 8, etc.)

Archer's Aim skillset has been rebalanced entirely and can actually be used now.

All monster skills get +10% accuracy if applicable.

AI fixes for several abilities, a few of them weren't being used at all.

Vanish doesn't work on performing characters, they'll keep singing/dancing and won't turn invisible.


			ITEM CHANGES
			
Axes and Flails now use the same [(PA * Brave)/100] * WP formula that Katanas/Knight's Swords do.

The random damage formula used only by Women's Bags now has been changed to ([PA / 2] + {1...PA}) * WP from just {1...PA) * WP. Weapon Power has been reduced to compensate, max damage is the same but they do more damage on average.

Books' Ranges increased from 3 to 4.
			
At least a 30% boost on HP for all heavy body armors.

Weapons with 20% Weapon Evasion or less get a 5% increase.

Earlier Cloaks/Shields have more Evasion.

Weapon Power on Knives, Katanas, Crossbows, endgame Longbows, and Shuriken increased, along with others (see readme for spoilers).

Genji equipment improved.

Random enemies equip some items that they didn't used to, mainly accessories.

Hi-Potion/X-Potion healing reduced to 60/120 HP respectively.

Only 1 Excalibur is available to the player (from Midlight's Deep). Aside from the Ragnarok war trophy from Hashmal, a Defender is the only Knight's Sword given to the player for free.


			JOB CHANGES
	
All negative stat growths on Jobs have been set to neutral. Mime's positive growths have been reduced to be in line with other Jobs. Using the Level Up/Down trick is nearly pointless now.

Folmarv/Loffrey/Cletienne and Orran - Gained innate Defense Boost/Arcane Defense
Zalbaag (Possessed) - Innate Defense Boost/Arcane Defense
Belias/Adremmelech - Gained Immunity to Silence
Ultima, High Seraph - Can be Immobilized, but not Disabled
Ultima, Arch Seraph - Removed Weakness to Holy element

All Squire classes can equip Shields, Helmets, Armor, Robes and Axes. Movement reduced from 4 to 3. The distinctions between Ramza's Squire class and the others are mostly gone, he gets better stats, Knight's Swords and a few extra abilities.

Chemists can equip Crossbows.

Wizard's MA multiplier from 150 to 125, Summoner's MA multiplier from 125 to 150. (Mage Jobs - ranked by new MA values: Summoner-Sage-Time-Black-Mystic-White, Summoner is slower than the rest and White Mage is slightly faster.)

Thief can equip Ninja Blades.

Orator can equip Crossbows, MP multiplier from 70 to 95, MA multiplier from 75 to 100.

Samurai gains innate Doublehand.

Sage - HP multiplier to 75, MP multiplier to 120, SP multiplier to 100, PA multiplier to 65, MA multiplier to 135, MP growth to 9 (High growth), all other growths are neutral.

Bard can equip Robes, HP multiplier from 55 to 80, MP multiplier from 50 to 100, PA multiplier from 30 to 65, Speed multiplier from 100 to 110, Movement from 3 to 4, Class Evade from 5 from 10

Dancer's HP multiplier from 60 to 85, MP multiplier from 50 to 75, Speed multiplier from 100 to 110, Movement from 3 to 4, Class Evade from 5 to 20

All Lucavi gain new Reaction abilities.

Orlandu's Sword Saint can't equip Hats/Clothes

Mustadio's Machinist can equip Crossbows
	
	
			JOB LEVELING CHANGES
			
Job Level 1 has been set from 100 JP to 50 JP, reducing the amount of starting JP a unit has.

The Job system has been opened up and simplified into 3 tiers. Start with 7 Jobs and level up 1 Job to unlock the next (excluding Mime):
Job Level 4 - 700 JP - to unlock 2nd tier Job
Job Level 5 - 1100 JP - to unlock final tier Job

Lv.4 Squire -> Lv.5 Knight -> Samurai

Lv.4 Thief -> Lv.5 Dragoon -> Ninja

Lv.4 Archer -> Lv.5 Monk -> Geomancer

Lv.4 Chemist -> Lv.5 Orator -> Bard/Dancer

Lv.4 White Mage -> Lv.5 Mystic -> Sage

Lv.4 Black Mage -> Lv.5 Time Mage -> Summoner

Mime


			SKILLSET CHANGES
	
All Jobs' Reaction/Support/Movement abilities rearranged, many still remain with the same Job though. See readme for a list of R/S/M Ability Changes.
	
Chant - Added to Generic Squire/Algus/Orran skillsets.

Ramza gets Steel in chapter 1 and Tailwind in chapter 2 instead of the opposite.
	
Meliadoul gains Zalbaag's 4 Blade of Ruin swordskills.

Beastmaster removed, monsters acquire their Beastmaster skills for normal use. See readme for a list of Monster Skill Changes.

JP Boost, Accrue JP, Move +3, Jump +3 removed.

Belias gains the unused Embrace ability (5 range instant Immobilize on 1 enemy).

Dycedarg can cast Ultima, giving Ramza one more opportunity to learn it.


			BATTLE CHANGES

10 lucky enemies get previously poachable-only items which can be stolen, see readme for spoilers.

Most special characters now have a set level based on story progression.

Guests have secondary skillsets that they may make some use of in battles.

A little more consistency with levels and abilities for units that leave and rejoin your party later on.

Gaffgarion will be a fully equipped Fell Knight at Zeirchele Falls no matter what changes you make to him before the battle.
	
To make the new Level cap work: no enemies will spawn over the Party's average Level in random encounters, which can make some battles (like in Midlight's Deep) easier. Anyone assigned a Level over 50 has been reduced. (Excluding Lucavi/Construct 7)
	
Monsters in Midlight's Deep/Necrohol of Mullonde have their classes improved by 1 if not already the highest tier to offset the Level cap reduction. Human units in Midlight's Deep are all improved similar to late chapter 4 enemies.

Most human bosses in mandatory encounters are improved with R/S/M abilities, stronger equipment, and/or secondary skillsets they can make use of.

Slightly higher variety in enemy jobs later in the game, for both random and mandatory battles.





Check the readme to see a more detailed list with additional changes.

Use the "Online ROM Patcher" under Submissions on the left to apply the .ppf patch to your game.





	Detailed list of unmentioned changes:
	
			ABILITY CHANGES
			
Fix?: Random enemies can appear with Fury, Magick Boost, and Adrenaline Rush equipped

The various Equip X abilities can't/won't be equipped by Jobs that don't need them

Fix: AI properly calculates CT with Swiftness/CT 0

Reraise - Accuracy from 140 to 160, JP cost reduced from 500 to 250
Regen - Accuracy from 170 to 190
Protectja/Shellja - Effect Area +1, Shellja costs 24 MP
Wall - Accuracy from 140 to 160
Holy - 50 to 42 power
Thundara - Costs 12 MP
Poison - Accuracy from 160 to 180
Haste - Accuracy from 180 to 200
Hasteja - Effect Area +1, Accuracy reduced from 240 to 120
Slowja - Effect Area +1, Accuracy reduced from 240 to 100
Stop - Accuracy from 110 to 130
Float - Accuracy from 140 to 160
Reflect - Accuracy from 180 to 200
Quick - Accuracy from 140 to 160, JP cost reduced from 450 to 225
Gravity - Dark elemental
Graviga - Accuracy from 120 to 180, Dark elemental
Meteor - Power from 40 to 50
Empowerment/Invigoration - Accuracy from 160 to 200, Dark elemental
Belief/Disbelief - Accuracy from 150 to 190
Corruption - Accuracy increased from 100 to 140
Fervor - Accuracy from 120 to 130
Trepidation - Accuracy from 140 to 180
Delirium - Accuracy increased from 130 to 170
Harmony - JP cost reduced from 400 to 200
Titan - Power from 22 to 25
Golem - AI targets allies, learn % quadrupled to 40 from 10
Salamander - Effect Area +1, Vertical Range +1
Ashura - Damage from MA*8 to MA*9
Ama-no-Murakumo - Damage from MA*14 to MA*15
Kiyomuri - Randomly casts either Protect OR Shell on each ally
Kiku-ichimonji - Range reduced from 8 to 6
Masamune/Chirijiraden - AI won't use

Accuracy for all Songs and Dances increased from 50 to 75%
Life's Anthem - Heals (MA+20) HP from (MA+10)
Rousing Melody - CT increased from 8 to 15
Battle Chant - CT increased from 8 to 10
Witch Hunt/Mincing Minuet - Formula changed to (PA+Y) from PA+[PA*Br/100], Y=20
Slow Dance - CT increased from 8 to 15
Polka - CT increased from 8 to 10
Last Waltz - Accuracy increased from 34% to 75%, matching Finale

Cyclone - Vertical Range increased from 0 to 1
Shockwave - Range reduced from 8 to 6
Steal Helm - (SP+45)% chance to steal from (SP+40)%
Steal Armor -(SP+40)% chance to steal from (SP+35)%
Steal Shield -(SP+55)% chance to steal from (SP+35)%
Steal Accessory -(SP+45)% chance to steal from (SP+40)%
Steal Turn - (SP+50)% chance to cancel charging, performing. AI is capable of using
Entice - Accuracy reduced from (MA+20) to (MA+10)%
Praise/Preach - Accuracy increased from (MA+50)% to (MA+90)%, Bravery/Faith +20 from +4
Rend Speed - Reduces Speed by 1 instead of 2
Focus - Effect: Berserk, AI flag changed but it never uses
Tailwind - Effect: Haste, AI flag changed to add status
Steel - Bravery +25 from +5, 50 to 0 JP (Ramza auto-learns)
Chant - 50 JP cost added (from 0)
Shout - Effect: Berserk, Haste, Faith, no bravery increase

Judgment Blade - Costs 8 MP
Cleansing Strike - Costs 12 MP
Northswain Strike - Costs 16 MP
Hallowed Bolt - Costs 20 MP
Divine Ruination - Costs 24 MP
Crush Armor - Costs 16 MP
Crush Helm - Costs 12 MP
Crush Weapon - Costs 24 MP
Crush Accessory - Costs 12 MP, JP cost reduced from 400 to 200
Duskblade - Costs 2 MP
Shadowblade - Costs 8 MP
Celestial Stasis - Costs 25 MP
Heaven's Wrath - Vertical Range from 3 to 0, 15 MP cost added
Ashura - Vertical Range from 3 to 0, 21 MP cost added
Adamantine Blade - Power from 10 to 11, Vertical Range from 3 to 0, 27 MP cost added
Maelstrom - Power from 12 to 14, Vertical Range from 3 to 0, 33 MP cost added
Celestial Void - Vertical Range from 3 to 0, 39 MP cost added
Divinity - Vertical Range from 3 to 0, 45 MP cost added
Hell's Wrath - Vertical Range from 3 to 0, 10 MP cost added
Nether Ashura - Vertical Range from 3 to 0, 14 MP cost added
Nether Blade - Power from 34 to 36, Vertical Range from 3 to 0, 18 MP cost added
Nether Maelstrom - Power from 40 to 45, Vertical Range from 3 to 0, 22 MP cost added
Corporeal Void - Power from 20 to 21, Vertical Range from 3 to 0, 26 MP cost added
Impiety - Vertical Range from 3 to 0, 30 MP cost added
Petrify (Assassin) - Fixed: AI will use, Range reduced from 6 to 3
Petrify (Lucavi) - AI uses more often, Range reduced from 5 to 2
Ague - AI flag set to Add Status from Affect Stats
Magicksap - 250 JP cost added
Speedsap - 250 JP cost added, reduces Speed by 2 instead of 3
Powersap - 250 JP cost added
Mindsap - 250 JP cost added
Biora (Slow version) - Accuracy from 110 to 170
Biora (Silence version) - Accuracy from 120 to 180

Toadja - 7 CT, 20 MP, 120 accuracy, 375 JP
Gravija - 12 CT, 76 MP, 425 JP, Dark elemental, fixed so AI will use
Flareja - 9 CT, 99 MP, 50 power, 750 JP
Blindja - 2 Effect Area, 4 CT, 8 MP, 75 JP
Confuseja - 7 CT, 33 MP, 170 accuracy, 300 JP
Sleepja - 2 Effect Area, 8 CT, 40 MP, 170 accuracy, 275 JP
Dispelja - 68 MP, 300 JP

Syphon/Drain - Dark elemental
Break - Accuracy reduced from 180 to 170
Dragon's Might - Bravery +25 from +5, PA/MA/SP +1 from +2
Holy Breath - Effect Area reduced from 2 to 1
Vengeance (Beowulf) - Range reduced from 8 to 6

Brave Slash - Power from 8 to 12 (USPS1=12)
Cross Slash - Power from 12 to 18 (USPS1=22)
Meteorain - Power from 20 to 30 (USPS1=26)
Omnislash - Fixed AI, Power from 30 to 45 (USPS1=40)
Cherry Blossom - Power from 42 to 63 (USPS1=60)

Bomblet - 0 to 1 Vertical Range
Thunder/Water/Ice Anima - Damage from MA*2 to MA*3
Wind Anima - Damage from MA*3 to MA*4
Dread Gaze - Bravery -10 increased to -50
Beam - Fixed AI
Featherbomb - Damage from MA*2 to MA*3
Peck - PA -3 from -2
Reckless Charge - 0 to 1 Vertical Range
Bequeath Bacon - Removed, doesn't work with new Level cap. No good formula to replace with that works with the animation
Leaf Rain & Guardian/Shell/Life/Magick Nymph - 0 to 1 Vertical Range
Goo/Bad Breath - Fixed AI, both will be used now
Dispose - Range reduced from 8 to 6

Ether - 150 to 75 JP
Antidote - 35 to 15 JP
Eye Drops - 40 to 20 JP
Echo Herbs - 60 to 30 JP
Maiden's Kiss - 100 to 50 JP
Gold Needle - 125 to 65 JP
Holy Water - 200 to 100 JP
Horizontal Jump 8 reduced to 6

Aim +3
Aim +4
Aim +5
Aim +6 - 7 CT
Aim +7 - 8 CT
Aim +8 - 9 CT
Aim +9 - 10 CT, 250 JP
Aim +10 - 12 CT, 300 JP

Bravery Boost - Bravery +3 increased to +15, JP cost reduced from 350 to 90
Faith Boost - Faith +3 increased to +15, JP cost reduced from 350 to 175
Adrenaline Rush - +1 Speed changed to +25 CT, JP cost reduced from 450 to 225
Vanish - JP cost reduced from 500 to 250
Critical: Quick - JP cost reduced from 400 to 100
Magick Counter - JP cost reduced from 400 to 200
Critical: Recover MP - 200 to 100 JP
Auto-Potion - 200 to 400 JP
Soulbind - 150 to 300 JP
Earplug - 150 to 75 JP
Reflexes - 200 to 400 JP
Archer's Bane - 225 to 125 JP
First Strike - 650 to 500 JP

Equip Guns - JP cost reduced from 400 to 200
Equip Katana - 200 to 100 JP
Halve MP - 500 to 250 JP
EXP Boost - 175 to 350 JP
Attack Boost/Defense Boost/Arcane Strength/Arcane Defense - 200 to 400 JP
Concentration - 200 to 400 JP
Brawler - 100 to 200 JP
Throw Items - 175 to 350 JP

Flee - Move+3 when critically wounded, 100 JP
Move +1 - 100 to 110 JP
Teleport - 325 to 500 JP
Ignore Weather - 100 to 50 JP
Ignore Terrain - 110 to 55 JP
Waterwalking - 210 to 105 JP
Swim - 150 to 75 JP
Lavawalking - 75 to 40 JP
Fly - 500 to 400 JP


			ITEM CHANGES

Blind Knife - 4 to 5 WP
Mage Masher - 4 to 6 WP
Platinum Dagger - 5 to 7 WP
Main Gauche - 6 to 8 WP
Orichalcum Dirk - 7 to 9 WP, May inflict Slow
Assassin's Dagger - 7 to 11 WP
Air Knife - 10 to 13 WP
Zwill Straightblade - 12 to 15 WP

Sasuke's Blade - 14 to 15 WP
Iga Blade - 15 to 16 WP
Koga Blade - 15 to 16 WP

Sleep Blade - Available at same time as Ancient Sword, enemy level req. from 23 to 21
Materia Blade - 10 to 15 WP
Chaos Blade - 40 to 30 WP

Ashura - 7 to 8 WP
Kotetsu - Available after saving Agrias, 8 to 9 WP
Osafune - Available at chapter 3 start, 9 to 10 WP
Murasame - Available after first Zalmour fight, 10 to 11 WP
Ama-no-Murakumo - Available after meeting Belias, 11 to 12 WP
Kiyomori - 12 to 13 WP

Battle Axe - 9 to 10 WP

Poison Rod - MA+1, Price from 500 to 1000
Dragon Rod - Absorbs Fire/Ice/Lightning, Price from 12000 to 36000

White Staff - WP from 3 to 4
Healing Staff - 4 to 5 WP
Golden Staff - WP from 6 to 7
Zeus Mace - MA+2 from 1, WP from 6 to 7
Staff of the Magi - WP from 7 to 8, Element: Holy, Boosts Holy element

Iron Flail - 9 to 10 WP
Morning Star - 16 to 14 WP
Scorpion Tail - 23 to 22 WP

Stoneshooter - 16 to 14 WP

Knightslayer - 3 to 5 WP, Random enemies will equip
Crossbow - 4 to 6 WP
Poison Bow - 4 to 7 WP
Hunting Bow - 6 to 8 WP
Gastrophetes - 10 to 12 WP, Random enemies will equip

Ice Bow - May cast Blizzard
Artemis Bow - 10 to 12 WP, Available for purchase in castles after Orlandu joins
Yoichi Bow - 12 to 14 WP
Perseus Bow - 16 to 18 WP

Bestiary - 8 to 9 WP
Papyrus Codex - 9 to 10 WP
Omnilex - 11 to 12 WP

Obelisk - 12 to 15 WP
Dragon Whisker - 17 to 18 WP
Javelin (2) - 30 WP to 22 WP

Croakadile Bag - 10 to 7 WP, MA+2 from 1
Fallingstar Bag - 20 to 13 WP
Pantherskin Bag - 12 to 8 WP
Hydrascale Bag - 14 to 9 WP

Damask Cloth - Available after meeting Delacroix, 8 to 10 WP, Enemy level required: 13
Cashmere - Available after meeting Belias, 10 to 13 WP, Enemy level required: 25

Shuriken - 4 to 6 WP
Fuma Shuriken - 7 to 9 WP
Yagyu Darkrood - 10 to 12 WP

Escutcheon - 10 to 15% Phys Evade
Buckler - 13 to 18% Phys Evade
Bronze Shield - 16 to 21% Phys Evade
Round Shield - 19 to 24% Phys Evade
Mythril Shield - 22 to 26% Phys Evade
Golden Shield - 25 to 29% Phys Evade
Ice Shield - 28 to 32% Phys Evade
Flame Shield - 31 to 33% Phys Evade
Diamond Shield - 34 to 35% Phys Evade
Platinum Shield - 37 to 38% Phys Evade
Genji Shield - 43 to 44% Phys Evade, 30% Magic Evade, PA+1
Kaiser Shield - 46 to 47% Phys Evade
Escutcheon (2) - 75 to 50% Phys Evade

Circlet - Enemy level required: 27 from 29, Available for purchase after chapter 4 start
Crystal Helm - Enemy level required: 29 from 27
Genji Helm - +25 MP, MA+1, Immunity to Confusion

Black Cowl - Immune: Sleep, PA+1
Thief's Cap - Speed +2 to +1

Leather Armor - 10 to 13 HP
Linen Cuirass - 20 to 26 HP
Bronze Armor - 30 to 39 HP
Chainmail - 40 to 52 HP
Mythril Armor - 50 to 65 HP
Plate Mail - 60 to 78 HP
Golden Armor - 70 to 91 HP
Diamond Armor - 80 to 104 HP
Platinum Armor - 90 to 117 HP
Carabiner Mail - 100 to 130 HP
Crystal Mail - 110 to 170 HP
Genji Armor - 150 to 200 HP, +25 MP, MA+1, Immunity to Toad
Mirror Mail - 130 to 145 HP
Maximillian - 200 to 250 HP

Chameleon Robe, Winged Boots, Hermes Shoes, Red Shoes, Reflect Ring, Angel Ring - Random enemies will equip

Spiked Boots - Price: 1200 to 800
Rubber Boots - Random enemies will equip, Enemy level required: from 5 to 25
Genji Glove - Immunity to Disable
Bracer - Enemy level required: from 60 to 50
Magick Ring - Equip: Shell
Nu Khai Armband - Equip: Protect
Guardian Bracelet - Negates Fire

Shoulder Cape - 10/10 to 15/15 Evade
Leather Cloak - 15/15 to 18/18 Evade
Elven Cloak - 25/25 to 24/24 Evade
Vampire Cape - 28/28 to 27/27 Evade
Featherweave Cape - 40 to 30 Phys Evade

Chantage - Always: Reraise to Initial: Reraise
Cherche - PA+1

Hi-Potion - Heals 60 from 70, Enemy level required from 2 to 6
X-Potion - Heals 120 from 150, Enemy level required from 3 to 20
Ether - Available at Eagrose in chapter 1
Hi-Ether - Available after meeting Delacroix, Enemy level required from 5 to 15
Elixir - Enemy level required from 14 to 30
Antidote - Enemy level required from 6 to 1
Eye Drops - Enemy level required from 7 to 1
Echo Herbs - Enemy level required from 8 to 4
Maiden's Kiss - Enemy level required from 9 to 4
Gold Needle - Enemy level required from 10 to 4
Holy Water - Enemy level required from 11 to 10
Remedy - Enemy level required from 12 to 15
Phoenix Down - Enemy level required from 13 to 1


			JOB CHANGES

Elidibus is immune to Stop

Meliadoul's Divine Knight can't equip Polearms, can only fit 4 innates. (Equip Sword/Crossbow/Shield/Armor)

All 6 Undead versions of Generic Jobs - Made same buffs as Generic Jobs above

Wisenkin and Sekhret - 4 Move from 3

Automaton - Useless innate Ignore Weather/Terrain removed, he cannot enter water

All Lucavi gain new Reaction abilities:
Cuchulainn - Gains Counter
Belias - Gains Fury
Zalera - Gains Faith Boost
Adremmelech - Gains Bonecrusher
Hashmal - Gains Magick Boost
Ultima 1 - Absorb MP to First Strike
Ultima 2 - Faith Boost to Soulbind
Elidibus - Counter to Magick Counter


			REACTION/SUPPORT/MOVEMENT ABILITY CHANGES

	Squire/Base	
Counter
Defend
Move +1

	Knight
Parry
Vigilance
Equip Heavy Armor
Equip Swords
Ignore Terrain

	Samurai
Bonecrusher
Shirahadori	
Doublehand
Equip Katanas
Jump +2

	Thief
Vanish
Gil Snapper
Safeguard
Poach
Flee

	Dragoon
Fury
Equip Polearms
Equip Shields
Ignore Elevation

	Ninja
Reflexes
Sticky Fingers
Dual Wield
Move +2

	Archer
Adrenaline Rush
Archer's Bane
Equip Crossbows
Concentration
Jump +1

	Monk
First Strike
Bravery Boost
Brawler
Lifefont

	Geomancer
Nature's Wrath
Attack Boost
Equip Axes
Swim

	Chemist
Auto-Potion
Counter Tackle
Throw Items
Reequip
Treasure Hunter

	Orator
Mana Shield	
Ear Plug
Equip Guns
Beast Tongue
Waterwalking

	Bard/Dancer
Critical: Recover HP
Tame
Fly

	White Mage
Regenerate
Cup of Life
Arcane Defense
Ignore Weather

	Mystic
Absorb MP
Magick Boost
Defense Boost
Manafont

	Sage
Soulbind
EXP Boost
Accrue EXP

	Black Mage
Magick Counter
Arcane Strength
Lavawalking

	Time Mage
Critical: Quick
Faith Boost
Swiftness
Levitate

	Summoner
Critical: Recover MP
Dragonheart
Halve MP
Teleport


			MONSTER SKILL CHANGES

Chocobo - Choco Beak - Choco Cure - Choco Esuna
Black Chocobo - Choco Beak - Choco Cure - Choco Pellets
Red Chocobo - Choco Beak - Choco Cure - Choco Meteor

Goblin - Tackle - Goblin Punch - Eye Gouge 
Black Goblin - Tackle - Goblin Punch - Spin Punch 
Gobbledygook - Tackle - Goblin Punch - Bloodfeast

Bomb - Bite - Self-Destruct - Bomblet
Grenade - Bite - Self-Destruct - Flame Attack
Exploder - Bite - Self-Destruct - Spark

Red Panther - Claw - Venom Fang - Cat Scratch
Coeurl - Claw - Cat Scratch - Blaster
Vampire Cat - Claw - Blaster - Vampire

Piscodaemon - Tentacles - Ink - Dischord
Squidraken - Tentacles - Dischord - Mind Blast
Mindflayer - Tentacles - Mind Blast - Level Drain

Skeleton - Chop - Thunder Anima - Water Anima
Bonesnatch - Chop - Water Anima - Ice Anima
Skeletal Fiend - Chop - Ice Anima - Wind Anima

Ghoul - Ectoplasm - Sleep Touch - Oily Touch
Ghast - Ectoplasm - Oily Touch - Drain Touch
Revenant - Ectoplasm - Drain Touch - Zombie Touch

Floating Eye - Wing Buffet - Dread Gaze - Bewitching Gaze
Ahriman - Wing Buffet - Bewitching Gaze - Doom
Plague Horror - Wing Buffet - Doom - Beam

Jura Aevis - Talon Dive - Glitterlust - Featherbomb
Steelhawk - Talon Dive - Featherbomb - Beak
Cockatrice - Talon Dive - Beak - Peck

Pig - Reckless Charge - Squeal - Toot
Swine - Reckless Charge - Snort - Toot
Wild Boar - Reckless Charge - Snort - Squeal

Dryad - Leaf Rain - Shell Nymph - Magick Nymph
Treant - Leaf Rain - Guardian Nymph - Life Nymph

Wisenkin - Pickaxe - Beef Up - Feral Spin
Minotaur - Pickaxe - Feral Spin - Breathe Fire
Sekhret - Pickaxe - Breathe Fire - Earthsplitter

Malboro - Tentacles - Lick - Goo
Ochu - Tentacles - Goo - Bad Breath
Greater Malboro - Tentacles - Bad Breath - Malboro Spores

Behemoth - Gore - Heave - Gigaflare
Behemoth King - Gore - Heave - Twister
Dark Behemoth - Gore - Heave - Almagest

Dragon - Charge - Thunder Breath - Tail Sweep
Blue Dragon - Charge - Thunder Breath - Ice Breath
Red Dragon - Charge - Thunder Breath - Fire Breath

Hydra - Tri-Attack - Tri-Breath - Tri-Thunder
Greater Hydra - Tri-Breath - Tri-Thunder - Tri-Flame
Tiamat - Tri-Thunder - Tri-Flame - Dark Whisper


			BATTLE CHANGES

10 lucky enemies get previously poachable-only items which can be stolen:

Holy Lance - Equipped by Dragoon at Dugeura Pass mandatory encounter
Wyrmweave Silk - Equipped by Dancer in Meliadoul's Bervenia encounter
Zwill Straightblade - Equipped by Thief in Cloud's Sal Ghidos encounter
Ivory Pole - Equipped by Zalmour (first encounter)
Rubber Suit - Equipped by Cletienne (final encounter)

Omnilex - Equipped by Sage in Crevasse MD encounter
Fallingstar Bag - Equipped by Summoner in Hollow MD encounter
Scorpion Tail - Equipped by Ninja in Oubliette MD encounter
Whale Whisker - Equipped by Mystic in Crossing MD encounter
Dragon Whisker - Equipped by Dragoon in Interstice MD encounter

A low Level Thief in Cloud's Sal Ghidos encounter and the final boss's Ultima Demons gain 10 Levels.

Zalera's Undead Knights and the Demons in possessed Zaalbag's battle have (high) set Levels instead of being based on the party's average Level. Zalera's Undead Knights are now flagged as men instead of monsters so they spawn with equipment.

Dycedarg has a Save the Queen that can be stolen.

Like Ultima, Alma gains Soulbind instead of Faith Boost in the Final Battle.

Rooftop Riovanes battle - Set Rapha's AI to defensive like in Yardrow


			CHANGELOG

	Version 1.1
	
Reraise - Accuracy from 140 to 160
Regen - Accuracy from 170 to 190
Wall - Accuracy from 140 to 160

Poison - Accuracy from 160 to 180

Haste - Accuracy from 180 to 200
Hasteja - Accuracy from 100 to 120
Stop - Accuracy from 110 to 130
Float - Accuracy from 140 to 160
Reflect - Accuracy from 180 to 200
Quick - Accuracy from 140 to 160
Graviga - Accuracy from 120 to 180
Meteor - Power from 40 to 50

Empowerment - Accuracy from 160 to 200
Invigoration - Accuracy from 160 to 200
Belief - Accuracy from 150 to 190
Disbelief - Accuracy from 150 to 190
Corruption - Accuracy from 130 to 140
Fervor - Accuracy from 120 to 130
Trepidation - Accuracy from 140 to 180
Delirium - Accuracy from 175 to 170

Titan - Power from 22 to 25
Odin - Removed instant death, Effect: KO
Salamander - Effect Area +1, Vertical Range +1

Accuracy for all Songs and Dances increased from 50 to 75%

Entice - Accuracy reduced from (MA+20) to (MA+10)%

Adamantine Blade - Power from 10 to 11
Maelstrom - Power from 12 to 14

Nether Blade - Power from 34 to 36
Nether Maelstrom - Power from 40 to 45
Corporeal Void - Power from 20 to 21

Biora (Slow version) - Accuracy from 110 to 170
Biora (Silence version) - Accuracy from 120 to 180

Gravija - Accuracy from 120 back to 160
Confuseja - Accuracy from 175 to 170

	Version 1.2
	
Elidibus' dialog updated to match the WOTL translation, I didn't notice that it was unchanged when working on FFT Prime.

Sleep Blade - Available at same time as Ancient Sword, enemy level req. from 23 to 21
Poison Rod - MA+1
White Staff - WP from 3 to 4
Golden Staff - WP from 6 to 7
Zeus Mace - MA+2 from 1, WP from 6 to 7
Staff of the Magi - WP from 7 to 8, Element: Holy
Croakadile Bag - MA+2 from 1
Morning Star - 16 to 14 WP
Scorpion Tail - 23 to 20 WP
Bestiary - 8 to 9 WP
Papyrus Codex - 9 to 10 WP

Black Cowl - Immune: Sleep, PA+1
Chantage - Always: Reraise to Initial: Reraise
Cherche - PA+1

Masamune/Chirijiraden - AI won't use
Bomblet - 0 to 1 Vertical Range
Peck - PA -3 from -2
Reckless Charge - 0 to 1 Vertical Range
Leaf Rain & Guardian/Shell/Life/Magick Nymph - 0 to 1 Vertical Range

Orlandu's Sword Saint can't equip Hats/Clothes
Mustadio's Machinist can equip Crossbows
Zalbaag (Possessed) - Innate Defense Boost/Arcane Defense
Wisenkin and Sekhret - 4 Move from 3

Squidraken - Tentacles/Dischord/Mind Blast
Mindflayer - Tentacles/Mind Blast/Level Drain
Pig - Reckless Charge/Squeal/Toot
Wild Boar - Reckless Charge/Snort/Squeal

	Version 1.3

Steel = 50 to 0 JP (Ramza auto-learns)
Chant - 10 to 50 JP
Ether - 150 to 75 JP
Antidote - 35 to 15 JP
Eye Drops - 40 to 20 JP
Echo Herbs - 60 to 30 JP
Maiden's Kiss - 100 to 50 JP
Gold Needle - 125 to 65 JP
Holy Water - 200 to 100 JP

Bravery Boost - 175 to 90 JP
Critical: Recover MP - 200 to 100 JP
Critical: Quick - 200 to 100 JP
Auto-Potion - 200 to 400 JP
Soulbind - 150 to 300 JP
Earplug - 150 to 75 JP
Reflexes - 200 to 400 JP
Archer's Bane - 225 to 125 JP
First Strike - 650 to 500 JP

Equip Katana - 200 to 100 JP
Halve MP - 500 to 250 JP
EXP Boost - 175 to 350 JP
Attack Boost/Defense Boost/Arcane Strength/Arcane Defense - 200 to 400 JP
Concentration - 200 to 400 JP
Brawler - 100 to 200 JP
Throw Items - 175 to 350 JP

Move +1 - 100 to 110 JP
Teleport - 325 to 500 JP
Ignore Weather - 100 to 50 JP
Ignore Terrain - 110 to 55 JP
Waterwalking - 210 to 105 JP
Swim - 150 to 75 JP
Lavawalking - 75 to 40 JP
Fly - 500 to 400 JP

Orichalcum Dirk - May inflict Slow
Assassin's Dagger - 10 to 11 WP
Air Knife - 12 to 13 WP
Zwill Straightblade - 14 to 15 WP
Sasuke's Blade - 14 to 15 WP
Iga Blade - 15 to 16 WP
Koga Blade - 15 to 16 WP
Materia Blade - 10 to 15 WP
Poison Rod - Price from 500 to 1000
Dragon Rod - Price from 12000 to 36000
Healing Staff - 4 to 5 WP
Scorpion Tail - 20 to 22 WP
Stoneshooter - 16 to 14 WP
Ice Bow - May cast Blizzard
Omnilex - 13 to 12 WP
Javelin 2 - 25 to 22 WP

Bard - Speed multiplier to 110 from 100, Movement to 4 from 3, Class Evade to 10 from 5
Dancer - Speed multiplier to 110 from 100, Movement to 4 from 3, Class Evade to 20 from 5

Vampire Cat - Claw/Blaster/Vampire

Construct 7 back to Level 66 from 50, Nelveska Temple's Greater Hydras back to Hydras.

Zalera's undead knights and the demons in possessed Zaalbag's battle have (high) set Levels instead of being based on the party's average Level.

Minor battle adjustments.

	Version 1.4
	
Rooftop Riovanes battle - Set Rapha's AI to defensive like in Yardrow, and swapped the Assassins' accessories to ensure that Rapha survives the first round.

Dragon Whisker - 17 to 18 WP

Elidibus is immune to Stop

	Version 1.41 - Final

The minorist of minor updates - Samurai's innate Doublehand ability is properly mentioned in the help text for the Job's Requirements. No other issues reported or found by myself since 1.4, so this should be the final version.





			ASM HACK CREDITS:

Emmy - Instant skills blink red if unusable due to silence/out of mp

FFMaster/Raijinili - Silent Walk becomes Flee

Raijinili - Un-Truth Faith/Innocent bugfix (Un-Truth does max damage with Innocent and no damage with Faith)

Glain - Equippable R/S/M only limited by job innates (Prevents Player/AI from equipping Doublehand on Samurai or various "Equip X" abilities on jobs that don't need them)

nates1984 - Weapon XA Rewrite (This hack changes Axes and Flails to use the same [(PA * Brave)/100] * WP formula that Katanas/Knight's swords use, it also automatically fixes FFT's random damage formula (that only Women's Bags now use) to vary between 0.5x - 1.5x expected damage. A side effect is that Wiznaibus and Witch Hunt now do PA + Y rather than PA + [PA * Brave / 100])
	
pokeytax - Brave/Faith Up gives +15 instead of +3,
	CT Save (Changes Speed Save's +1 Speed to +25 CT)
	
Pride - AI CT Charge Supports (Fixes minor bug where the AI didn't correctly know Short Charge and Non-charge saved them CT),
	Random enemies can appear with PA Save, MA Save, and Speed Save
	
RavenOfRazgriz - Haste, Slow Edits
	
Xifanie - Maximum levelup (=50),
	Remove forced slowdown for Math Skill (Skillset ID 0x15),
	Removes permanent brave alteration. (version 2.0),
	Removes permanent faith alteration. (version 2.0)
