			FFT: Prime

Built upon FFT: Complete v.50, which fixes a few bugs and includes 99% of the script and text from the PSP port, The War of the Lions.
All remaining bugs and unaltered text have been fixed if possible, so setting aside the other alterations that the patch makes, one could think of this as an unofficial full release of FFT: Complete.

Abilities, Character Statistics, Job Levels, and Job Requirements are all identical to the original Japanese release of the game, with one notable exception:
Although Elmdore has the Safeguard ability in the original Japanese release, he is left without it so that the unique Masamune and Genji equipment can still be obtained.
A full list of Ability and Character Statistic differences (minus the JP cost changes) can be found in the readme.

Newly retranslated Spell Quotes in the WOTL style replace the old quotes, though they are too long for all of them to fit.
Excluding all of the "non-spell" quotes (Iaido & Martial Arts) and Rapha/Marach's quotes were enough to get the rest inserted.
If you'd like to add these back in, replacing other quotes (Be sure to check/uncheck the appropiate box for "Quote" in FFTPatcher), or if you're just curious what the other quotes are, a list is included in the readme.

Includes ASM hacks made by the Final Fantasy Hacktics community that fix some longstanding bugs and provide quality of life improvements:

	Event skip (Start button) - Start button skips events, effects, battle and event text, map titles, unit movement, chapter title and end graphics, the gameover screen, and the ending credits. There's no confirmation, so be careful! (Trying to skip the Zodiark summon animation in the Airship Graveyard causes the game to softlock, so beware of that. Otherwise the skip has no issues in my experience.)

	Switch unit number with L1 and R1 buttons (formation) - Switch unit number with L1 and R1 buttons in the formation screen. Changes unit order as appropriate. L1 and R1 still work normally (switching the selected unit) in menus.

	Save between battles after formation screen - Allows saving between battles AFTER the formation screen. Loading a save made this way will still load the formation screen, but with the latest changes saved. Saving before the formation screen still functions as normal.

	JP scroll glitch actual fix (Disable paging on confirm menu) - Disables paging when a confirm menu is up so there is no way to do the JP scroll glitch.

	Equipment duplication glitch fixes - Fixes the equipment duplication glitches that can be triggered from using Best Fit in the shops.

	All formulas apply elemental (v2) - Fixes the Oil status bug by making it double fire damage properly and sword skills with an element attached will now actually apply these elements, taking precedence over the element on a weapon like the Icebrand.

	Random unit equipment more selective - Random unit equipment will now be more selective of secondary item types. (You shouldn't see Knights in chapters 2 to 4 using Linen Robes)

	Iaido visual bug fix - Fixes a visual bug during some Iaido animations where characters would use a Rod instead of a Katana.

	Nether Mantra Faith/Atheist bugfix - Nether Mantra does max damage with Atheist and no damage with Faith.



			FFT: Prime - Convenience

In addition to everything in the previous section, this version of the patch has a few more changes to make the game less tedious and more fun to play:

	JP costs of all abilities halved, some absurdly overpriced abilities like Fly (5000 JP) are reduced further. The game may become slightly more challenging as a consequence of this change, since enemy combatants are able to afford more abilities as well.

	Mime's Lv.8 Squire/Chemist prerequisites removed. The job only requires Lv.5 Orator/Geomancer/Summoner/Dragoon.

	Cloud's initial Level when recruited is close to the average Level of your party instead of 1.

	When using the Treasure Hunter ability, only the rare item will be obtained. There won't be any need to worry about a unit's Bravery level when searching for items and leaving it up to chance whether you get the rare one or not.



			Ability and Character Statistic Differences

	Time Magicks
Graviga CT is 9 in FFTU, 10 in FFTJ
Meteor 60 Power and CT is 13 in FFTU, 40 Power and CT is 20 in FFTJ

	Mystic Arts
Induration CT is 9 in FFTU, 10 in FFTJ

	Summon
Summons are stronger and/or faster in FFTU.
Moogle FFTU (Power 12, CT 2) FFTJ (Power 10, CT 3)
Shiva/Ramuh/Ifrit FFTU (Power 24, CT 4) FFTJ (Power 20, CT 7)
Titan FFTU (Power 28, CT 5) FFTJ (Power 22, CT 10)
Golem CT 3 vs CT 4
Carbuncle CT 4 vs CT 5
Bahamut FFTU (Power 46, CT 10) FFTJ (Power 42, CT 15)
Odin FFTU (Power 40, CT 9) FFTJ (Power 36, CT 13)
Leviathan/Salamander FFTU (Power 38, CT 9) FFTJ (Power 34, CT 13)
Sylph 5 CT vs 7 CT
Faerie FFTU (Power 24, CT 4) FFTJ (Power 20, CT 7)
Lich 9 vs 10 CT
Cyclops FFTU (Power 50, CT 9) FFTJ (Power 44, CT 12)
Zodiark FFTU (Power 96, CT 10) FFTJ (Power 90, CT 17)

	Limit
Brave Slash is stronger in FFTU (12 vs 8 Power)
Cross Slash is stronger in FFTU (22 vs 12 Power)
Meteorain is stronger in FFTU (26 vs 20 Power)
Omnislash is stronger in FFTU (40 vs 30 Power)
Cherry Blossom is stronger in FFTU (60 vs 42 Power)

	Squire
Ramza's base stats and PA growth are better in FFTU.
HP = 7D/78
Spd = 6B/64
C-PA = 31/32
PA = 6F/6E
MA = 66/64

	Squire
Delita's base stats are superior in FFTU.
HP = 82/78
PA = 78/6E

	Holy Knight
Delita's HP is better in FFTU.
HP = 87/82

	Astrologer
Orran's base stats are superior in FFTU.
HP = 8C/6C
Spd = 7D/78
MA = 82/7D

	Ark Knight
Elmdore is stronger and has Safeguard in FFTJ, preventing the stealing of Genji equipment.
HP = B4/BE
Spd = 78/7D
C-PA = 28/27

	White Knight (Chapter 1)
Wiegraf is weaker in FFTU.
HP = 8C/96
PA = 74/78

	White Knight (Chapter 3)
Wiegraf is ridiculously weaker in FFTU.
HP = A5/C8
Spd = 6E/8C
PA = 78/7D
MA = 5F/64

	Soldier
Cloud is superior in FFTU.
MP = 74/64
C-PA = 2A/32
PA = 7B/6E
C-MA = 2E/32
MA = 78/64

	Gigas
Belias has less HP in FFTU.
HP = 50/5A

	The Impure
FFTU Cuchulainn is much weaker.
HP = 32/41
Spd = 82/8A
MA = 82/96

	Arch Seraph
FFTU Ultima has less speed and PA.
Spd = 5F/64
C-PA = 26/24



			Excluded Spell Quotes

Live and die unfettered, release the energy from words ancient and new! Ashura!
O dark and resentful spirits, gather in this place... Kotetsu!
Sever the ties of memory across the void to forget... Osafune!
Where wind does not blow, the slicing sword shall scatter the leaves as winds of life! Murasame!
Rising among clouds, only the deities of the sky know our path, Ama-no-Murakumo!
Through mercy all can be forgiven, for the heart of the sword is to judge evil! Kiyomori!
Countless sword spirits, heed the call to be drawn forth! Muramasa!
Hidden sword piercing the heavens, this hellfire path leads not to Buddha! Kiku-ichimonji!
Furious sword, transform into a demon of living hell! Masamune!
Fire devouring sword, dye this earth with a spring rain of crimson! Chirijiraden!

Burning hot justice! Roaring bloody fists! Pummel!
White hot the whirling rage does burn! Its cry, a roar that knows no bounds! Aurablast!
The earth's wrath flows through my fists! You cannot hide! Shockwave!
These fingertips containing all my heart and soul! Lead them to hell! Doom Fist!

Echoes of sound slumbering in death's memory, crash with flash and thunder... Heaven's Wrath!
Raging flames of the goddess, a torrent of fire filling clouds and scorching earth... Ashura!
Bind the light that fades behind dark clouds into thunderbolts of diamond light! Adamantine Blade!
Evil spirits, with fang and talon rend and tear the oceans... Maelstrom!
With bells ringing, the light fades into void revealing the present as illusion... Celestial Void!
Elemental gods and spirits of heaven and earth, lend yourself through this chant... Divinity!
Your roar a storm, great black wyrm. Unmatched the dread your wings portend! Hell's Wrath!
Sword foe of your evil flames! Now burn away the foes we face... Nether Ashura!
Through gust and gale, your spark ignite. Bring down your ruin, swift and sure... Nether Blade!
With tears of heaven rend and tear, from this land wash all filth and drek! Nether Maelstrom!
Sacred heart of the void, heed this prayer to purge this world of the impure! Corporeal Void!
The power of the gods dwelling between heaven and earth shall be unleashed! Impiety!



Use romhacking.net's "Online ROM Patcher" to apply the ppf patch of your choosing to a fresh Final Fantasy Tactics (US) image file:
https://www.romhacking.net/patch/



			Changelog

Replaced a few ASM hacks for newer, better alternatives and fixed a couple lines of dialog that weren't showing, along with some other minor text fixes.
Newly retranslated Spell Quotes in the WOTL style and the WOTL's Chapter Titles are also included.



			Credits

Cheetah, Dominic NY18, Melonhead, Heian, Eternal, Vanya, FFMaster, and PX_Timefordeath for FFT: Complete v.50

Tuffy da Bubba and RafaGam for the translated Sound Novels

Daykeras for the WOTL styled Spell Quotes

iamthehorker for the WOTL Chapter Titles

Raijinili for the Nether Mantra Faith/Atheist bugfix

Glain for all other ASM hacks



Not a fan of an ASM hack or some gameplay change I've made? Want to make your own patch using this as a base?
Follow the directions below using the files included in the Source folder to set up your own FFT: Complete to work off of!

1. Apply the old FFT: Complete v.50.ppf to a fresh FFT image file:
https://ffhacktics.com/smf/index.php?action=dlattach;topic=3659.0;attach=2892

2. Use ShishiSpriteEditor.exe to open your FFT image file and navigate to the Other Images tab.
Select Image>Import all images... from the menu bar and choose the Source/images folder.
Close ShishiSpriteEditor.exe.

3. Using CDMage (https://ffhacktics.com/w/images/6/68/CDmage.7z), open your FFT image file and select the 2nd option "M2/2352".
Open the Event folder, right-click TEST.EVT and Import File... selecting the TEST.EVT I've included in the Source folder.
Close CDMage once the file is imported.

4. Now, download the 0.492 version of FFTactext from:
https://github.com/Glain/FFTPatcher/releases/download/v0.492/FFTPatcher_492.rar
Open the program and select the .ffttext you want, Prime.ffttext for the vanilla game with the original JPN stats or Prime - Convenience.ffttext, which removes the Lv.8 Squire/Chemist prerequisites from Mime on top of the Prime changes.
The newer FFTactext versions throw an error when patching, so use the 0.492 version for the .ffttext files I've provided.

5. From here, if you want to keep the original US PS1 stats you should change the appropriate Ability Descriptions back using the Statistic Differences I posted above.
Graviga, Meteor, Induration, and the various Summon CTs should be all of them.

6. The fixed War of the Lions translation is patched in!
You can swap to the newest FFTPatcher suite (https://ffhacktics.com/wiki/FFTPatcher_Suite) for the FFTPatcher and FFTorgASM programs.
Apply my gameplay changes by using the .fftpatch files with FFTPatcher or the various ASM Hacks by using Prime.xml with FFTorgASM if you wish.
A custom SCEAP.dat was used for the "FFT: Complete Beta v.50" text that shows when you first load up the game, you can pull the SCEAP.dat from an unmodified FFT image with CDMage and patch it in with FFTPatcher to remove the text.