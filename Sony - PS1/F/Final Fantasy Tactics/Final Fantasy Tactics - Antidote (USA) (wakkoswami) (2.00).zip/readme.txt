			ANTIDOTE

Antidote is a rebalancing hack that attempts to give a viable use or value to as many aspects of FFT as possible while making few nerfs or flashy changes, so you still feel like you're playing the same FFT, just with more options available.
Both for you, and your AI adversaries.

Difficulty starts out about the same as the original game, but increases steadily as you progress.
Most enemies have higher job levels with more abilities, secondary skillsets that they are proficient with, and/or slightly better equipment.

If the original release were to be thought of like a "Beginner" difficulty for new players, then this hack could be considered an "Intermediate" difficulty, capable of keeping an experienced player on their toes while still being beatable for those less skilled.

Antidote is built off of the Convenience version of my FFT: Prime hack (https://www.romhacking.net/hacks/4611) and includes everything listed there.



			GENERAL CHANGES

The gamebreakingly powerful Arithmetician has been turned into the Sage, a mid to late game job that uses a rebalanced "Ja-Magicks" skillset made up of Zalera's 6 -ja abilities and Ultima's Dispelja.
In return for contributing their unique abilities to the player's use and having the MP costs and charge times increased, Zalera and Ultima both get innate Halve MP and Zalera gains the previously unused "CT 0" ability, making all of his spells cast instantly.

Maximum Level has been reduced from 99 to 50 and Speed growths have been halved for all jobs, including monsters, to address late game balance issues.
Additionally, many Speed altering abilities and items are slightly less effective and Haste/Slow's effect has been reduced from a 50% increase/decrease to 25%.
Abilities with long charge times will still be usable at the end of the game.

Changed starting options on new game - Message display speed: Fast, Navigation message: OFF,  Show Exp and Jp gained: OFF, Show unequippable item by Job: OFF
Select Option 14: Return to initialize setting to change them back to default

Added a Weapon Damage formula reference to the bottom of the Miscellany tutorial list



			ABILITY CHANGES

Bravery/Faith changes are no longer permanent, most abilities that alter Bravery/Faith are more effective to compensate and the few Bravery alterations caused by choices made in dialog during the story are much larger.

Learn %, which affects both the AI's chance to learn an ability and the odds of getting it from a crystal, has been doubled for all abilities, most are 100% now.

Abilities used by human units that absorb HP/MP or damage a percentage of the target's HP (Invigoration/Gravity) are now Dark elemental.
All Lucavi bosses halve Dark damage, Elmdore and Possessed Zalbaag absorb it.

Odds of stealing slightly improved for all but weapons, Thief gets 2 new abilities:
Steal Turn - Replaces Steal EXP - (SP+50)% chance to cancel an action while it is charging/being performed.
Flee - Move+4 when critically wounded.

Excluding Steel/Shout, Squire abilities that increase stats now add status effects instead:
EX: Tailwind - SP+1 changed to Effect: Haste

Archer's Aim skillset has been rebalanced entirely and can actually be used now.

All sword skills have been given MP costs.

Unyielding Blade skills always do damage regardless of the presence of equipment, Safeguard prevents damage.
Damage is the usual WP*PA if breaking gear, otherwise the skills gain a small damage bonus based on MP cost.

Sky/Nether Mantra abilities have their Vertical Ranges reduced from 3 to 0, making it easier to hit the spaces you want with them, and MP costs have been added.

Everything about Cloud besides Climhazzard/Finishing Touch has been improved.

All 8 Range weapons/abilities reduced to 6. (Guns, Shockwave, Horizontal Jump 8, etc.)

Monsters can have up to 4 skills naturally and their skills gain +10% accuracy if applicable.

AI fixes for several abilities, a few weren't being used at all.

Vanish doesn't apply to performing characters, they'll keep singing/dancing and won't turn invisible.



			ITEM CHANGES

Axes and Flails now use the same (PA*Bravery)/100 * WP formula that Katanas/Knight's Swords do. Axes may break a piece of the enemy's equipment, or perform a second strike if no equipment is present.

The random damage formula used only by Women's Bags now has been changed to ((PA/2)+(1...PA)) * WP from just (1...PA) * WP.
Weapon Power has been reduced to compensate, max damage is the same but they do more damage on average.

Books now inflict status effects and Cloths may sap an enemy's stats.

Weapon Power on Knives, Crossbows, endgame Longbows, and Shuriken increased, along with others (see readme for spoilers).

Around a 30% boost on HP for most heavy body armors.

Weapons with 20% Weapon Evasion or less get a 5% increase.

Earlier Cloaks/Shields have more Evasion.

Masamune/Genji equipment improved.

Hi-Potion/X-Potion healing reduced to 60/120 HP respectively.

Random enemies equip some items that they didn't used to, mainly accessories.

Only 1 Excalibur is available to the player, found in Midlight's Deep.
Aside from the Ragnarok war trophy from Hashmal, a Defender is the only Knight's Sword given for free.



			JOB CHANGES

Negative stat growths on jobs have been set to neutral and positive growths have been added for jobs with high stats that weren't receiving any benefit.
Overall, stat growths have little effect now, but leveling from 1-50 in the same/similar jobs will give a small bonus in the stats a job is good with.
Thief/Ninja/Mime are the only jobs that get extra Speed from a higher Speed growth at Level 50.

All Squire classes can equip Shields/Helmets/Armor/Robes/Axes, Movement reduced from 4 to 3.
Ramza's Squire job has its name change as the story progresses. Perhaps something else is different?

Chemist can equip Crossbows.

Wizard's MA multiplier from 150 to 125, Summoner's MA multiplier from 125 to 150. (Mage jobs - ranked by new MA values: Summoner-Sage-Time-Black-Mystic-White, Summoner is slower than the rest and White Mage is slightly faster)

Time Mage can equip Books.

Thief can equip Ninja Blades, Speed growth and multiplier increased to match Ninja.

Orator can equip Crossbows, MP multiplier from 70 to 95, MA multiplier from 75 to 100.

Samurai gains innate Doublehand.

Bard can equip Robes, HP multiplier from 55 to 80, MP multiplier from 50 to 100, SP multiplier from 100 to 110, PA multiplier from 30 to 65, Movement from 3 to 4, Class Evade from 5 from 10.

Dancer's HP multiplier from 60 to 85, MP multiplier from 50 to 75, SP multiplier from 100 to 110, Movement from 3 to 4, Class Evade from 5 to 20.

Sage can equip Rods/Staves, HP multiplier to 75, MP multiplier to 135, SP multiplier to 100, PA multiplier to 60, MA multiplier to 140, MP growth to 8 (highest growth), all other growths are neutral.

Mime's HP multiplier from 140 to 200, PA multiplier from 120 to 130, MA multiplier from 115 to 150, Class Evade from 5 to 30.
Positive stat growths have been reduced to be in line with other jobs, all generic jobs are now left with the same MA growth.
Gains innate Beast Tongue and status immunity to all negative statuses that a Ribbon would defend against.

Orlandeau's Sword Saint can't equip Hats/Clothes.

Mustadio's Machinist can equip Crossbows.

Some monsters have different Reaction abilities, weaker monsters have slightly increased stats.

All Lucavi gain new Reaction abilities, some gain increased stats, Support/Movement abilities, or status immunities (see readme for spoilers).



			JOB LEVELING CHANGES

Job Level 1 has been set from 100 JP to 50 JP, reducing the amount of starting JP a unit typically has. The job system has been opened up and simplified into 3 tiers, start with 6 jobs and level up 1 job to unlock the next:
Job Level 4 - 700 JP to unlock 2nd tier job
Job Level 5 - 1100 JP to unlock final tier job

Lv.4 Squire -> Lv.5 Knight -> Samurai
Lv.4 Thief -> Lv.5 Dragoon -> Ninja
Lv.4 Archer -> Lv.5 Monk -> Geomancer
Lv.4 Chemist -> Lv.5 Orator -> Bard/Dancer
Lv.4 White Mage -> Lv.5 Mystic -> Sage
Lv.4 Black Mage -> Lv.5 Time Mage -> Summoner

All jobs unlocked -> Mime



			SKILLSET CHANGES

All jobs' Reaction/Support/Movement abilities rearranged, many still remain with the same job though.
See readme for a list of R/S/M Ability Changes.

Chant added to Generic Squire/Argath/Orran skillsets.

Ramza gets Steel in chapter 1 and Tailwind in chapter 2 instead of the opposite.

Meliadoul and Folmarv gains Zalbaag's 4 Blade of Ruin sword skills.

Beastmaster removed, monsters acquire their Beastmaster skills for normal use.
See readme for a list of Monster Skill Changes.

JP Boost, Accrue JP, Move +3, Jump +3 removed.

Dycedarg can cast Ultima, giving Ramza one more opportunity to learn it.

Changed Zalmour's status-inflicting spells from Beowulf's versions to the Mystic's so that he can actually cast them.

Belias gains the previously unused Embrace ability (5 range instant Immobilize on 1 enemy).



			BATTLE CHANGES

A few lucky enemies acquire items that were only available from poaching, which can now be stolen (see readme for spoilers).

Most human bosses in mandatory encounters are improved with R/S/M abilities, stronger equipment, and/or secondary skillsets that they can make use of.

Gaffgarion will be a fully equipped Dark Knight at Zeirchele Falls no matter what changes you make to him before the battle.

Slightly higher variety in enemy jobs later in the game, for both random and mandatory battles.

Guests have secondary skillsets that they can make some use of in battles.

Most special characters now join at a set Level based on story progression.

To make the new Level cap work, no enemies will spawn over the party's average Level in random encounters, which can make some battles (like in Midlight's Deep) a bit easier.
Anyone assigned a Level over 50 has been reduced to 50 (excluding Lucavi/Construct 7).

Monsters in Midlight's Deep/Necrohol of Mullonde have their classes improved by 1 if not already the highest tier to offset the Level cap reduction a bit.
Human units in Midlight's Deep are all improved similar to late chapter 4 enemies.

Some bosses were originally set to drop War Trophies, but when they teleport away the game removes the trophy as well, moved these around so they actually drop:
Gaffgarion - Golgollada Gallows: Protect Ring, now dropped by another enemy in the same battle
Zalmour - Lesalia: Magick Ring, now dropped by another enemy in the same battle
Elmdore - Riovanes Castle Roof: Cursed Ring, all enemies teleport away here, now dropped by Zalera

Treasure Hunter items improved by 1 tier.
No rare items, just better/earlier storebought stuff.



Check the readme to see a more detailed list with additional changes.

Use romhacking.net's "Online ROM Patcher" to apply Antidote.ppf to a fresh Final Fantasy Tactics (US) image file:
https://www.romhacking.net/patch/



	Detailed list of unmentioned changes:



			ABILITY CHANGES

Random enemies can appear with Fury, Magick Boost, and Adrenaline Rush equipped

The various Equip X abilities can't/won't be equipped by jobs that don't need them

AI properly calculates CT with Swiftness/CT 0

Improved the AI's use of Protect/Shell/Float

Critical hits always do bonus damage

Split the 3-4 different versions of Bio/ra/ga between different enemy skillsets so all can see some use

Cura/Curaga - Vertical Range +1
Curaja - Effect Area +1, 16 to 32 MP cost
Reraise - Accuracy from 140 to 160, JP cost from 500 to 250
Regen - Accuracy from 170 to 190
Protectja/Shellja - Effect Area +1, Accuracy from 120 to 140, Shellja costs 24 MP
Wall - Accuracy from 140 to 160
Holy - Power from 50 to 42
Thundara - 10 to 12 MP cost
Firaja/Thundaja/Blizzaja - Can be Magick Countered
Poison - Accuracy from 160 to 190
Toad - AI will use
Haste - Accuracy from 180 to 200
Hasteja - Effect Area +1, Accuracy from 240 to 140
Slowja - Effect Area +1, Accuracy from 240 to 120, Can be Magick Countered
Stop - Accuracy from 110 to 140
Float - Accuracy from 140 to 160
Reflect - Accuracy from 180 to 200
Quick - Accuracy from 140 to 160, Can't be Magick Countered, JP cost from 450 to 225
Gravity - Dark elemental
Graviga - Accuracy from 120 to 180, Dark elemental
Meteor - Power from 40 to 50, Flagged as "Random Hits" to make the AI more careful about using

Empowerment/Invigoration - Accuracy from 160 to 200, Dark elemental, Invigoration costs 12 MP from 16
Belief/Disbelief - Accuracy from 150 to 190
Corruption - Accuracy from 100 to 140, 20 to 12 MP cost
Fervor - Accuracy from 120 to 130, 16 to 14 MP cost
Trepidation - Accuracy from 140 to 180, 20 to 12 MP cost
Delirium - Accuracy from 130 to 170, 20 to 14 MP cost
Harmony - Effect Area +1, Vertical Range +1, JP cost from 400 to 200

Titan - Power from 22 to 25
Golem - CT increased from 4 to 8
Salamander - Effect Area +1, Vertical Range +1
Osafune - Damage from MA*4 to MA*6
Kiyomori - Randomly casts either Protect OR Shell on each ally
Kiku-ichimonji - Range reduced from 8 to 6
Masamune/Chirijiraden - AI won't use

Seraph Song - Heals (MA+25) MP from (MA+20)
Life's Anthem - Heals (MA+25) HP from (MA+10)
Rousing Melody - CT increased from 8 to 15, Accuracy from 50% to 70%, AI won't use
Battle Chant - Accuracy from 50% to 80%
Magickal Refrain - CT decreased from 10 to 8, Accuracy from 50% to 80%
Nameless Song - Accuracy from 50% to 60%
Finale - Accuracy from 50% to 65%, AI won't use

Witch Hunt/Mincing Minuet - Formula changed to (PA+15) from PA+(PA*Bravery/100)
Slow Dance - CT increased from 8 to 15, Accuracy from 50% to 60%, AI won't use
Polka - Accuracy from 50% to 70%
Heathen Frolick - CT decreased from 10 to 8, Accuracy from 50% to 70%
Forbidden Dance - Immobilize/Disable added to the list of potential effects
Last Waltz - Accuracy from 34% to 55%, AI won't use

Cyclone - Vertical Range increased from 0 to 1
Shockwave - Range reduced from 8 to 6
Steal Helm - (SP+45)% chance to steal from (SP+40)%
Steal Armor - (SP+40)% chance to steal from (SP+35)%
Steal Shield - (SP+55)% chance to steal from (SP+35)%
Steal Accessory - (SP+45)% chance to steal from (SP+40)%
Steal Turn - (SP+50)% chance to cancel charging/performing, AI will use
Entice - Accuracy from (MA+20)% to (MA+10)%
Praise/Preach - Accuracy from (MA+50)% to (MA+90)%, Bravery/Faith +20 from +4
Sinkhole - Dark elemental
Tanglevine/Contortion - Earth elemental
Rend Speed - Reduces SP by 1 from 2

Focus - Effect: Berserk, AI changed but it never uses, 20% chance to learn
Tailwind - Effect: Haste, AI flag changed to Add Status
Steel - Bravery +25 from +5
Chant - 50 JP cost added, Mimicable
Shout - PA/MA+1

Judgment Blade - Costs 10 MP
Cleansing Strike - Costs 15 MP
Northswain Strike - Costs 20 MP
Hallowed Bolt - Costs 25 MP
Divine Ruination - Costs 30 MP
Crush Armor - Costs 16 MP, 3 Power
Crush Helm - Costs 12 MP, 2 Power
Crush Weapon - Costs 24 MP, 5 Power
Crush Accessory - Costs 12 MP, 2 Power, JP cost from 400 to 200
Duskblade - Costs 6 MP, Ramza can learn via Gaffgarion's crystal
Shadowblade - Costs 12 MP, Ramza can learn via Gaffgarion's crystal
Celestial Stasis - Costs 25 MP

Heaven's Wrath - Vertical Range from 3 to 0, Costs 15 MP
Ashura - Vertical Range from 3 to 0, Costs 21 MP
Adamantine Blade - Power from 10 to 11, Vertical Range from 3 to 0, Costs 27 MP
Maelstrom - Power from 12 to 14, Vertical Range from 3 to 0, Costs 33 MP
Celestial Void - Vertical Range from 3 to 0, Costs 39 MP
Divinity - Vertical Range from 3 to 0, Costs 45 MP

Hell's Wrath - Vertical Range from 3 to 0, Costs 10 MP
Nether Ashura - Vertical Range from 3 to 0, Costs 14 MP
Nether Blade - Power from 34 to 36, Vertical Range from 3 to 0, Costs 18 MP
Nether Maelstrom - Power from 40 to 45, Vertical Range from 3 to 0, Costs 22 MP
Corporeal Void - Power from 20 to 21, Vertical Range from 3 to 0, Costs 26 MP
Impiety - Vertical Range from 3 to 0, Costs 30 MP

Petrify (Assassin) - AI will use, Range reduced from 6 to 3
Energize - Range +1, Fixed to display Ability name
Parasite - Fixed to display Ability name
Vengeance (Byblos) - Range +1, No vertical threshold
Petrify (Lucavi) - AI uses more often, Range reduced from 5 to 2
Darkness - Inflicts Blind/Poison
Ague - AI flag set to Add Status from Affect Stats
Magicksap/Powersap/Mindsap - 250 JP cost added
Speedsap - 250 JP cost added, Reduces SP by 2 from 3
Vampire (Human version) - Dark elemental
Biora (Slow version) - Accuracy from 110 to 170
Biora (Silence version) - Accuracy from 120 to 180
Leg Shot - Accuracy from (SP+50)% to (SP+60)%

Toadja - 7 CT, 24 MP, 120 Accuracy, 375 JP cost, Mimicable, Can be Magick Countered
Gravija - 12 CT, 76 MP, 425 JP cost, Dark elemental, AI will use, Mimicable, Can be Magick Countered
Flareja - 9 CT, 90 MP, 50 Power, 750 JP cost, Mimicable, Can be Magick Countered
Blindja - 2 Effect Area, 4 CT, 8 MP, 75 JP cost, Mimicable, Can be Magick Countered
Confuseja - 7 CT, 24 MP, 170 Accuracy, 300 JP cost, Mimicable, Can be Magick Countered
Sleepja - 2 Effect Area, 8 CT, 40 MP, 170 Accuracy, 275 JP cost, Mimicable, Can be Magick Countered
Dispelja - 56 MP, 5 CT, 300 JP cost, Mimicable, Can be Magick Countered

Disempower - Absorbs all MP from 1 target, reduces other targets' MP to 0
Return - CT decreased from 7 to 5
Blind - 6 to 2 MP cost
Syphon/Drain - Dark elemental
Faith/Doubt - 10 to 8 MP cost
Zombie/Confuse - 14 to 18 MP cost
Berserk - 16 to 20 MP cost
Silence - 16 to 10 MP cost
Chicken - 12 to 20 MP cost
Dispel - Accuracy from 200 to 220
Disable - Accuracy from 200 to 205, 14 to 6 MP cost
Sleep - 20 to 14 MP cost
Break - Accuracy from 180 to 170
Dragon's Gift/Speed - AI will use
Dragon's Might - Bravery +25 from +5, PA/MA/SP +1 from +2, AI will use
Holy Breath - Effect Area -1
Vengeance (Beowulf) - Range reduced from 8 to 6, AI flag set to Affects HP from Add Status

	Limit: Skills properly flagged as Magical Attacks if needed and can be used by the AI
Brave Slash - Power from 8 to 30 (US PS1=12), CT from 3 to 4
Cross Slash - Power from 12 to 22 (US PS1=22), May inflict Stop
Blade Beam - CT from 5 to 7, Range from 2 to 4, Effect Area +1, Vertical Range +1
Meteorain - Power from 20 to 37 (US PS1=26)
Finishing Touch - CT from 5 to 10, Vertical Range +2, Removed Stop/Petrify effects
Omnislash - Power from 30 to 55 (US PS1=40), Vertical Range +1
Cherry Blossom - Power from 42 to 77 (US PS1=60), Vertical Range +2

Bomblet (all 3 versions) - 0 to 1 Vertical Range, All use the same MA*4 formula, AI flagged as Magical Attack
Thunder/Water/Ice Anima - Damage from MA*2 to MA*3
Wind Anima - Damage from MA*3 to MA*4
Oily Touch - Inflicts Oil/Slow
Dread Gaze - Bravery -10 to -50
Beam - AI will use, MA -3 from -2
Featherbomb - Damage from MA*2 to MA*3
Peck - PA -5 from -2
Reckless Charge - 0 to 1 Vertical Range
Bequeath Bacon - Changed to "White Wind" formula: Heal HP(User's Current HP), Hit F_(MA+255)%
Leaf Rain - Damage from MA*3 to MA*4, 0 to 1 Vertical Range
Guardian/Shell Nymph - 0 to 1 Vertical Range
Life Nymph - Healing from MA*2 to MA*3, 0 to 1 Vertical Range
Magick Nymph - Healing from MA*1 to MA*2, 0 to 1 Vertical Range
Beef Up - PA+2, MA+1
Goo - AI will use, Inflicts Immobilize/Disable
Bad Breath - AI will use
Destroy - Power from 10 to 14, Self damage from 1/8 to 1/10
Compress - Power from 12 to 20, Self damage from 1/6 to 1/8
Dispose - Range reduced from 8 to 6
Pulverize - Power from 16 to 27, Self damage from 1/4 to 1/6

Ether - 150 to 75 JP cost
Hi-Ether - 200 to 100 JP cost
Antidote - 35 to 15 JP cost
Eye Drops - 40 to 20 JP cost
Echo Herbs - 60 to 30 JP cost
Maiden's Kiss - 100 to 50 JP cost
Gold Needle - 125 to 60 JP cost
Holy Water - 200 to 100 JP cost
Horizontal Jump 8 reduced to 6

Aim +3
Aim +4
Aim +5
Aim +6 - 7 CT
Aim +7 - 8 CT
Aim +8 - 9 CT
Aim +9 - 10 CT, 250 JP cost
Aim +10 - 12 CT, 300 JP cost

Fury - 300 to 225 JP cost
Magick Boost - 250 to 200 JP cost
Adrenaline Rush - +1 SP changed to +25 CT, 450 to 300 JP cost
Vanish - 500 to 350 JP cost
Vigilance - 100 to 150 JP cost
Dragonheart - 300 to 350 JP cost
Bravery Boost - Bravery +3 to +15, 350 to 150 JP cost
Faith Boost - Faith +3 to +15, 350 to 150 JP cost
Recover MP - 200 to 100 JP cost
Critical: Quick - 400 to 150 JP cost
Bonecrusher/Parry - 100 to 200 JP cost
Magick Counter - Works on all -ja magicks, 400 to 200 JP cost
Counter Tackle - Changed to "Threaten" - Attacker's Bravery -20 within 3 range vs. physical attacks, 125 JP
Nature's Wrath - 150 to 300 JP cost
Absorb MP - 125 to 100 JP cost
Auto-Potion - 200 to 450 JP cost
Counter - 150 to 250 JP cost
Mana Shield - 200 to 400 JP cost
Soulbind - 150 to 500 JP cost
Earplug - 150 to 90 JP cost
Reflexes - 200 to 500 JP cost
Shirahadori - 350 to 400 JP cost
Archer's Bane - 225 to 100 JP cost
First Strike - 650 to 350 JP cost

Equip Heavy Armor - 250 to 225 JP cost
Equip Shields/Safeguard - 125 to 200 JP cost
Equip Swords/Polearms - 200 to 175 JP cost
Equip Katana - 200 to 85 JP cost
Equip Crossbows - 175 to 125 JP cost
Equip Axes - 85 to 100 JP cost
Equip Guns - 400 to 200 JP cost
Halve MP - 500 to 250 JP cost
EXP Boost - 175 to 100 JP cost
Attack Boost/Arcane Strength - 200 to 400 JP cost
Defense Boost/Arcane Defense - 200 to 300 JP cost
Concentration - 200 to 500 JP cost
Tame - 250 to 125 JP cost
Poach/Brawler - 100 to 200 JP cost
Reequip - 0 to 25 JP cost (prevents it from being equipped on most enemies)

Move +1 - 100 to 200 JP cost
Move +2 - 280 to 350 JP cost
Jump +1 - 100 to 110 JP cost
Jump +2 - 250 to 150 JP cost
Ignore Elevation - 350 to 280 JP cost
Lifefont - 150 to 250 JP cost
Manafont - 175 to 270 JP cost
Accrue EXP - 200 to 100 JP cost
Teleport - 325 to 500 JP cost
Ignore Weather - 100 to 75 JP cost
Ignore Terrain - 110 to 100 JP cost
Waterwalking - 210 to 150 JP cost
Swim - 150 to 175 JP cost
Lavawalking - 75 to 50 JP cost
Levitate - 270 to 210 JP cost
Fly - 500 to 325 JP cost
Flee - Move +4 when critically wounded, 100 JP cost
Treasure Hunter - 50 to 100 JP cost



			ITEM CHANGES

Blind Knife - 4 to 5 WP
Mage Masher - 4 to 6 WP
Platinum Dagger - 5 to 7 WP
Main Gauche - 6 to 8 WP
Orichalcum Dirk - 7 to 9 WP, May inflict Slow
Assassin's Dagger - 7 to 11 WP
Air Knife - 10 to 13 WP
Zwill Straightblade - 12 to 15 WP

Sasuke's Blade - 14 to 17 WP
Iga Blade - 15 to 18 WP
Koga Blade - 15 to 18 WP

Sleep Blade - Available at same time as Ancient Sword, Enemy Level required from 23 to 21
Nagrarok - 1 to 11 WP
Materia Blade - 10 to 15 WP
Chaos Blade - 40 to 30 WP

Ashura - Available after saving Ovelia
Masamune - SP+1
Chirijiraden - MA+3

Battle Axe - 9 to 10 WP, May destroy target's helmet
Giant Axe - May destroy target's armor
Slasher - May destroy target's weapon

Poison Rod - MA+1, Price from 500 to 1000
Dragon Rod - Absorbs Fire/Ice/Lightning, Price from 12000 to 36000

White Staff - 3 to 4 WP
Healing Staff - 4 to 5 WP
Golden Staff - 6 to 7 WP
Zeus Mace - MA+2 from +1, 6 to 7 WP
Staff of the Magi - 7 to 8 WP, Element: Holy, Boosts Holy element

Iron Flail - 9 to 10 WP

Knightslayer - 3 to 5 WP, Random enemies will equip
Crossbow - 4 to 6 WP
Poison Bow - 4 to 7 WP
Hunting Bow - 6 to 9 WP
Gastrophetes - 10 to 12 WP, Random enemies will equip

Longbow - 4 to 3 WP, Available at Eagrose, Price from 800 to 400, Enemy Level from 2 to 1
Silver Bow - 5 to 4 WP, Available after saving Elmdore, Price from 1500 to 800, Enemy Level from 6 to 2
Ice Bow - Available after killing Milleuda, Enemy Level from 11 to 6
Windslash Bow - 8 to 9 WP
Artemis Bow - 10 to 12 WP, Available for purchase in castles after Orlandeau joins
Yoichi Bow - 12 to 14 WP

Battle Folio - May inflict Berserk
Bestiary - May inflict Frog
Papyrus Codex - May inflict Undead/Stop
Omnilex - May inflict Traitor

Partisan - 11 to 12 WP
Obelisk - 12 to 15 WP, Price from 10000 to 18000
Holy Lance - MA+2
Javelin(2) - 30 to 22 WP

Croakadile Bag - 10 to 7 WP, MA+1 to +2
Fallingstar Bag - 20 to 12 WP, PA+2
Pantherskin Bag - 12 to 8 WP
Hydrascale Bag - 14 to 9 WP

Damask Cloth - May Powersap the target, Available after meeting Delacroix, Enemy Level required from 24 to 13
Cashmere - May Mindsap the target, Available after meeting Belias, Enemy Level required from 29 to 25
Wyrmweave Silk - May Speedsap the target

Shuriken - 4 to 6 WP
Fuma Shuriken - 7 to 9 WP
Yagyu Darkrood - 10 to 12 WP

Escutcheon - 10 to 15% Physical Evade
Buckler - 13 to 18% Physical Evade
Bronze Shield - 16 to 21% Physical Evade
Round Shield - 19 to 24% Physical Evade
Mythril Shield - 22 to 26% Physical Evade
Golden Shield - 25 to 29% Physical Evade
Ice Shield - 28 to 32% Physical Evade
Flame Shield - 31 to 33% Physical Evade
Diamond Shield - 34 to 35% Physical Evade
Platinum Shield - 37 to 38% Physical Evade
Genji Shield - 43 to 44% Physical Evade, 30% Magic Evade, PA+1
Escutcheon(2) - 75 to 50% Physical Evade

Circlet - Enemy Level required from 29 to 27, Available for purchase after chapter 4 start
Crystal Helm - Enemy Level required from 27 to 29
Genji Helm - +25 MP, MA+1, Immune: Confuse

Black Cowl - PA+1, Immune: Sleep
Thief's Cap - SP+2 to +1
Gaia Gear - MA+1

Leather Armor - 10 to 13 HP
Linen Cuirass - 20 to 26 HP
Bronze Armor - 30 to 39 HP
Chainmail - 40 to 52 HP
Mythril Armor - 50 to 65 HP
Plate Mail - 60 to 78 HP
Golden Armor - 70 to 91 HP
Diamond Armor - 80 to 104 HP
Platinum Armor - 90 to 117 HP
Carabiner Mail - 100 to 130 HP
Crystal Mail - 110 to 170 HP
Genji Armor - 150 to 200 HP, +25 MP, MA+1, Immune: Toad
Mirror Mail - 130 to 150 HP
Maximillian - 200 to 250 HP

Chameleon Robe, Winged Boots, Hermes Shoes, Red Shoes, Reflect Ring, Angel Ring - Random enemies will equip

Spiked Boots - Price from 1200 to 800
Rubber Boots - Random enemies will equip, Enemy Level required from 5 to 25
Power Gauntlet - Price from 5000 to 2500
Genji Glove - Immune: Disable
Bracer - Enemy Level required from 60 to 50
Magick Ring - Equip: Shell
Jade Armlet - Immune: Charm
Nu Khai Armband - Equip: Protect, Removed Immune: Charm
Guardian Bracelet - Negates Fire

Shoulder Cape - 10 to 15% Physical Evade
Leather Cloak - 15 to 20% Physical Evade
Mage's Cloak - 18/18 to 20/20 Evade
Vampire Cape - 28/28 to 30/30 Evade

Chantage - Always: Reraise to Initial: Reraise
Cherche - PA+1

Hi-Potion - Heals 60 from 70 HP, Enemy Level required from 2 to 6
X-Potion - Heals 120 from 150 HP, Enemy Level required from 3 to 20
Ether - Available at Eagrose
Hi-Ether - Available after meeting Delacroix, Enemy Level required from 5 to 15
Elixir - Enemy Level required from 14 to 30
Antidote/Eye Drops/Phoenix Down - Enemy Level required down to 1
Echo Herbs/Maiden's Kiss/Gold Needle - Enemy Level required down to 4
Holy Water - Enemy Level required from 11 to 10
Remedy - Enemy Level required from 12 to 15



			JOB CHANGES

Orran, Folmarv/Loffrey/Cletienne, Holy Dragon Reis, and Possessed Zalbaag - Gained innate Defense Boost/Arcane Defense

Changed Wiegraf's chapter 3 job to use the WOTL stats as a base instead of the overtuned stats from the original JP release

Meliadoul's Divine Knight can't equip Polearms, can only fit 4 innate abilities (Equip Sword/Crossbow/Shield/Armor)

Cloud's Soldier has the powered up stats from the US PS1 release and can now equip Perfumes, Movement from 3 to 4, Gained innate Safeguard/Doublehand

All 6 Undead versions of generic jobs - Made same buffs as generic jobs above

	Monster Statistic and Reaction Ability Changes:
The tiers for a lot of the weaker monsters were jumbled up, with the tier 1/2 monsters having better stats than the 3rd.
These have all been rearranged so the monsters become progressively stronger by tier.

The stat change estimates below came from comparing average Level 50 monsters for each family:
Goblin family - HP+~25, PA+~1, MA+~2, Move/Jump+1, Class Evade doubled, Reaction: First Strike
Bomb family - HP+~50, PA+~1, MA+~4, SP+~1
Mindflayer family - HP+~25, PA+~1, MA+~2, Class Evade doubled, Reaction: Nature's Wrath
Skeleton/Ahriman families - SP+~1, Reaction: Nature's Wrath
Ghost family - SP+~1, Reaction: Shirahadori
Aevis family - HP+~25, Reaction: First Strike
Pig family - Move/Jump+1, Reaction: Adrenaline Rush
Treant family - HP+~25, SP+~1, Move+1, Reaction: Nature's Wrath
Minotaur family - Reaction: Adrenaline Rush, Wisenkin/Sekhret: Movement from 3 to 4
Malboro family - HP+~50, PA+~1, MA+~2, SP+~1, Move+1, Reaction: Nature's Wrath
Behemoth family - Reaction: Bonecrusher

Byblos - HP+~66, PA+~2, MA+~2, SP+~1, Reaction: Mana Shield
Automaton - SP+~1, Reaction: Shirahadori, Useless innate Ignore Weather/Terrain removed
Reaver - HP+~50, PA+~1, MA+~2, SP+~1, Reaction: Magick Counter
Archaeodaemon/Ultima Demon - SP+~1, Reaction: Magick Counter

	Lucavi Statistic and Status Changes:
Cuchulainn - HP+~17%
Zalera - HP+~34%
Adremmelech/Hashmal/Ultima 1 - HP+~40%
Ultima 2/Elidibus - SP+1

Belias/Adremmelech - Gained immunity to Silence
Ultima 1 - Can be Immobilized, but not Disabled
Ultima 2 - Removed weakness to Holy element
Elidibus - Gained immunity to Stop

	Lucavi R/S/M Ability Changes:
Cuchulainn - Counter(+)/Brawler/Swiftness
Belias - Fury(+)/Brawler/Swiftness/Cannot enter water
Zalera - Faith Boost(+)/Halve MP(+)/CT 0(+)/Fly (Removed Cannot enter water, he can float over water)
Adremmelech - Bonecrusher(+)/Brawler(+)/Swiftness/Flee(+)
Hashmal - Magick Boost(+)/Brawler(+)/Swiftness/Manafont(+)
Ultima 1 - First Strike(+)/Brawler/Swiftness/Mastered Teleport (Removed Absorb MP)
Ultima 2 - Soulbind(+)/Halve MP(+)/Swiftness/Mastered Teleport (Removed Faith Boost)
Elidibus - Magick Counter(+)/Brawler(+)/Swiftness/Lifefont(+) (Removed Counter)



			REACTION/SUPPORT/MOVEMENT ABILITY CHANGES

	Squire/Base	
Counter
Defend
Move +1

	Knight
Parry / Vigilance
Equip Heavy Armor / Equip Swords
Ignore Terrain

	Samurai
Bonecrusher / Shirahadori
Doublehand / Equip Katanas
Jump +2

	Thief
Vanish / Gil Snapper
Safeguard / Poach
Flee

	Dragoon
Fury
Equip Polearms / Equip Shields
Ignore Elevation

	Ninja
Reflexes / Sticky Fingers
Dual Wield
Move +2

	Archer
Adrenaline Rush / Archer's Bane
Equip Crossbows / Concentration
Jump +1

	Monk
First Strike / Bravery Boost
Brawler
Lifefont

	Geomancer
Nature's Wrath
Attack Boost / Equip Axes
Swim

	Chemist
Auto-Potion
Throw Items / Reequip
Treasure Hunter

	Orator
Threaten / Ear Plug
Equip Guns / Beast Tongue
Waterwalking

	Bard/Dancer
Critical: Recover HP / Mana Shield
Tame
Fly

	White Mage
Regenerate / Cup of Life
Arcane Defense
Ignore Weather

	Mystic
Absorb MP / Magick Boost
Defense Boost
Manafont

	Sage
Soulbind
EXP Boost
Accrue EXP

	Black Mage
Magick Counter
Arcane Strength
Lavawalking

	Time Mage
Critical: Quick / Faith Boost
Swiftness
Levitate

	Summoner
Critical: Recover MP / Dragonheart
Halve MP
Teleport



			MONSTER SKILL CHANGES

Chocobo - Choco Beak / Choco Cure / Choco Esuna
Black Chocobo - Choco Beak / Choco Cure / Choco Esuna / Choco Pellets
Red Chocobo - Choco Beak / Choco Cure / Choco Pellets / Choco Meteor

Goblin - Tackle / Goblin Punch / Eye Gouge
Black Goblin - Tackle / Goblin Punch / Eye Gouge / Spin Punch
Gobbledygook - Tackle / Goblin Punch / Spin Punch / Bloodfeast

Bomb - Bite / Self-Destruct / Bomblet
Grenade - Bite / Self-Destruct / Bomblet / Flame Attack
Exploder - Bite / Self-Destruct / Bomblet / Spark

Red Panther - Claw / Cat Scratch / Venom Fang
Coeurl - Claw / Cat Scratch / Venom Fang / Blaster
Vampire Cat - Claw / Cat Scratch / Blaster / Vampire

Piscodaemon - Tentacles / Ink / Dischord
Squidraken - Tentacles / Ink / Dischord / Mind Blast
Mindflayer - Tentacles / Ink / Mind Blast / Level Drain

Skeleton - Chop / Thunder Anima / Water Anima
Bonesnatch - Chop / Thunder Anima / Water Anima / Ice Anima
Skeletal Fiend - Chop / Water Anima / Ice Anima / Wind Anima

Ghoul - Ectoplasm / Sleep Touch / Oily Touch
Ghast - Ectoplasm / Sleep Touch / Oily Touch / Drain Touch
Revenant - Ectoplasm / Sleep Touch / Drain Touch / Zombie Touch

Floating Eye - Wing Buffet / Doom / Dread Gaze
Ahriman - Wing Buffet / Doom / Dread Gaze / Bewitching Gaze
Plague Horror - Wing Buffet / Doom / Bewitching Gaze / Beam

Jura Aevis - Talon Dive / Featherbomb / Glitterlust
Steelhawk - Talon Dive / Featherbomb / Glitterlust / Beak
Cockatrice - Talon Dive / Featherbomb / Beak / Peck

Pig - Reckless Charge / Squeak / Toot
Swine - Reckless Charge / Squeak / Toot / Snort
Wild Boar - Reckless Charge / Squeak / Snort / Bequeath Bacon

Dryad - Leaf Rain / Life Nymph / Guardian Nymph
Treant - Leaf Rain / Life Nymph / Guardian Nymph / Shell Nymph
Elder Treant - Leaf Rain / Life Nymph / Shell Nymph / Magick Nymph

Wisenkin - Pickaxe / Beef Up / Feral Spin
Minotaur - Pickaxe / Beef Up / Feral Spin / Breathe Fire
Sekhret - Pickaxe / Beef Up / Breathe Fire / Earthsplitter

Malboro - Tentacles / Bad Breath / Lick
Ochu - Tentacles / Bad Breath / Lick / Goo
Greater Malboro - Tentacles / Bad Breath / Goo / Malboro Spores

Behemoth - Gore / Heave / Gigaflare
Behemoth King - Gore / Heave / Gigaflare / Twister
Dark Behemoth - Gore / Heave / Twister / Almagest

Dragon - Charge / Tail Sweep / Thunder Breath
Blue Dragon - Charge / Tail Sweep / Thunder Breath / Ice Breath
Red Dragon - Charge / Tail Sweep / Thunder Breath / Fire Breath

Hydra - Tri-Attack / Tri-Breath / Tri-Thunder
Greater Hydra - Tri-Attack / Tri-Breath / Tri-Thunder / Tri-Flame
Tiamat - Tri-Breath / Tri-Thunder / Tri-Flame / Dark Whisper



			BATTLE CHANGES

A few lucky enemies acquire items that were only available from poaching, which can now be stolen:
Ivory Pole - Equipped by Zalmour (first encounter)
Holy Lance - Equipped by Dragoon at Dugeura Pass mandatory encounter
Yoichi Bow - Equipped by Undead Archer at Lake Poescas mandatory encounter
Zwill Straightblade - Equipped by Thief in Cloud's Sal Ghidos encounter
Rubber Suit - Equipped by Cletienne (final encounter)

Dycedarg has a Save the Queen that can be stolen

A little more consistency with levels and abilities for units that leave and rejoin your party later on

Riovanes Castle Roof - Set Rapha's AI to defensive, like in Yardrow

Like Ultima, Alma gains Soulbind instead of Faith Boost in the final battle

Zalera's Undead Knights and the Demons in Possessed Zaalbag's battle have (high) set Levels instead of being based on the party's average Level, Zalera's Undead Knights are now flagged as men instead of monsters so they spawn with equipment

A low Level Thief in Cloud's Sal Ghidos encounter and the final boss's Ultima Demons gain 10 Levels

The Byblos who joins you in Midlight's Deep always has 88 Bravery/30 Faith

Treasure Hunter - Gollund Colliery items improved from mythril junk to chapter 4 equipment.
Changed a Mullonde Hi-Potion to an Elixir, so 4x Elixirs are on this map.
Mount Bervenia's inaccessable item moved from (4,11) to (4,4), Flameburst Bombs all changed to late chapter 4 equipment.

The Oubliette, battle 4 - A Monk that could spawn as a guest in this battle was meant to be an enemy based on placement, so now she is



			CHANGELOG

Went through all monsters/Lucavi and did a stat rebalancing, weaker monsters/Lucavi get a boost. Some monsters have different Reaction abilities

Ramza's Squire job has its name change as the story progresses, and he can learn Gaffgarion's Dark Sword skills through the crystal he drops

Added ASM hacks to change Counter Tackle to Threaten and Shout to PA/MA+1, Minotaur's Beef Up improved as a side effect. Removed Counter Tackle from Zalbaag's skillset, Threaten added to Orator and Mana Shield added to Bard/Dancer

Minotaur shared family skill changed to Beef Up, Beef Up gains MA+1

Cloud Overhaul - Everything besides Climhazzard and Finishing Touch has been improved. Details in Ability and Job sections above

Thief - Speed values increased to match Ninja
Time Mage (and Undead TM) - Can equip Books
Sage - MP multiplier +15, MP growth +1, MA multiplier +5, PA multiplier -5, Can equip Rods/Staves
Mime - MA multiplier +15, Class Evade +5
Holy Dragon Reis - Gained innate Defense Boost/Arcane Defense

Quick - Can't be Magick Countered
Meteor - Flagged as "Random Hits" to make the AI more careful about using
Golem - AI changes were causing weird behavior even though they'd use it more often, ability set back to default and CT doubled from 4 to 8

PA/MA Songs and Dances CT from 10 to 8, Immobilize/Disable added to Forbidden Dance's status roulette
AI won't (attempt to) use Rousing Melody/Finale/Slow Dance/Last Waltz
Faster Songs/Dances are more accurate, slower ones are less accurate. Songs are a bit more accurate than Dances in general. HP/MP Songs heal a little more, HP/MP Dances hurt a little less

Non-elemental Geomancy abilities were given an element

Focus reduced to 20% chance to learn so enemy knights have JP to learn Move +1 most of the time
Steel JP cost 0 to 100, Ramza doesn't autolearn any abilities at game start
Chant and Ja-Magicks are Mimicable
Toadja/Flareja - MP costs changed

Increased most sword skill MP costs

Elmdore and Possessed Zalbaag's Vampire skill changed to Dark elemental, Elmdore and Zalbaag now absorb Dark (Units turned to Vampires will heal the bosses)

Osafune/Bomblet/Oily Touch/Beam/Peck/Leaf Rain/Life and Magick Nymph/Goo/Darkness/Disempower/Magick Counter abilities improved

Split the 3-4 different versions of Bio/ra/ga between different enemy skillsets so all can see some use

Automaton's close range skills hit harder and do less self damage. Increased range for some of Byblos' skills and fixed others to display their Ability names

R/S/M JP costs adjusted

Sasuke's Blade/Iga and Koga Blades/Morning Star/Scorpion Tail/Hunting Bow/Stoneshooter/Partisan/Dragon Whisker - WP changes, some are back to original WP

Katanas back to original placements and WP, some Ability powers back to original values. Ashura is available after saving Ovelia, Masamune has SP+1, Chirijiraden has MA+3

Axes may break a piece of the enemy's equipment, or perform a second strike if no equipment is present

Longbows are available as soon as you get to Eagrose, adjusted WP/prices for some Bows, removed Blizzard effect from Ice Bow

Books/Cloths - WP and Range set back to original values. Books now inflict status effects and Cloths may sap an enemy's stats

Obelisk - Price from 10000 to 18000
Holy Lance - MA+2
Fallingstar Bag - PA+2, WP from 13 to 12
Gaia Gear - MA+1
Power Gauntlet - Price from 5000 to 2500
Jade Armlet - Immune: Charm
Nu Khai Armband - Removed Immune: Charm
Kaiser Shield/Cloaks - Evade% changed or set to default

Human enemies in the Gollund Colliery fights were made a bit stronger

Removed some of the poachable items given to enemies and handed out a Yoichi Bow

Barich has Adrenaline Rush/Jump +2 in his first fight and Arcane Strength in both fights

Slightly reduced Elmdore's stats at Limberry to offset the Genji boosts (MA/SP-1). Changed some enemy equipment on Riovanes rooftop and the Assassins' in later battles. Assassins always use Throw secondary with Concentration instead of magic

Wiegraf/Folmarv - Changed some equipment in Orbonne/Mullonde fights

The Oubliette, battle 4 - A Monk that could spawn as a guest in this battle was meant to be an enemy based on placement, so now she is

AI can't use the Aim skillset with Guns, so I swapped around some guest/boss secondary skillsets

Some bosses were originally set to drop War Trophies, but when they teleport away the game removes the trophy as well, moved these around so they actually drop

Treasure Hunter items improved by 1 tier. No rare items, just better/earlier storebought stuff. Gollund Colliery items improved from mythril junk to chapter 4 equipment. Changed a Mullonde Hi-Potion to an Elixir, so 4x Elixirs are on this map. Mount Bervenia's inaccessable item moved from (4,11) to (4,4), Flameburst Bombs all changed to late chapter 4 equipment

Added a Weapon Damage formula reference to the bottom of the Miscellany tutorial list and fixed some tutorials that could softlock the game due to gameplay changes made

Changed starting options on new game

Includes latest FFT: Prime update: "Inserted a better translation for the Enavia Chronicles sound novel (https://mmatyas.github.io/fft/enavia) that replaces the barely comprehensible machine translation that was being used. Added Shirahadori fix and starting date change ASM hacks. Removed the "Now loading" text that was added for the US release and fixed a year suddenly passing by after the Marach frog event. Gave the translation one last pass comparing to the PSP version and fixed and cleaned up some things, mainly in the other 3 Sound Novels."



			ASM HACK CREDITS:

Choto: Counter Tackle Ability Edit (Changes the ability associated with Counter Tackle to "Threaten")

Dokurider: AI Usage - Float (AI will no longer add Float when critical. AI will now only cast Float as a means to intercept incoming damage.)

DW: AI becomes not dumb with protect/shell (AI will now use these statuses only if GREATER than 50% HP.)

Emmy: Silent Walk becomes Flee (Add 4 move when unit is in critical. Originally written by FFMaster FIXED thanks to Raijinili!!),
	Display 4 monster skills in formation

FFMaster: Haste/Slow is 25% speed bonus/loss

Glain: Crits always deal bonus damage (Crit XA bonus minimum is 1 instead of 0. Maximum is still XA - 1.),
	Abilities can flash red without charge time,
	Equippable R/S/M only limited by job innates,
	Crystals can include special job abilities

Grond: Formula 36 (Focus) boosts PA by Y, MA by X

nates1984: Weapon XA Rewrite (Axes and Flails now use the same (PA*Bravery)/100 * WP formula that Katanas/Knight's Swords do. The random damage formula used only by Women's Bags now has been changed to ((PA/2)+(1...PA)) * WP from just (1...PA) * WP. Changes Witch Hunt/Mincing Minuet formula to (PA+15) from PA+(PA*Bravery/100))

Pokeytax: Adrenaline Rush boosts CT by 25,
	Bravery/Faith Boost boosts Bravery/Faith by 15

Pride: AI CT Charge Supports (Fixes minor bug where the AI didn't correctly know Swiftness and CT 0 saved them CT.),
	Random enemies can appear with Fury, Magick Boost, and Adrenaline Rush equipped

Xifanie: Beastmaster is disabled (All monsters can use their 4 skills as if Beastmaster never existed.),
	Maximum levelup (=50),
	Remove forced slowdown for Arithmeticks,
	Removes permanent Bravery/Faith alteration

Xjamxx: Unyielding Blade WOTL (Unyielding Blade skills have 100% chance to break equipment, but damage is WP*PA if gear is about to be broken. If no gear, human or not, it will do normal damage like other sword skills (WP+Y)*PA. Safeguard prevents item breakage and damage.)