Use romhacking.net's "Online ROM Patcher" under the Submissions pane to apply the ppf patch that you want to a fresh FFT.bin.



FFT: Prime
*****************************************************************************************************************************
*Built upon FFT: Complete v.50, which fixes a few bugs and includes 99% of the script and text from the PSP port,
 The War of the Lions. Some more bugs and unaltered text were fixed by me, so setting aside the other alterations that the
 patch makes, one could think of this as an unofficial v.51 release of FFT: Complete.

*Abilities, Character Statistics, Job Levels, and Job Requirements are all identical to the original Japanese release of the
 game, with one notable exception that is listed below. Ability and Character Statistic differences can be found listed out
 in the readme.

*Although Elmdore has the Safeguard ability in the original Japanese release, he is left without it so that the unique
 Masamune and Genji Equipment can still be obtained.

*Includes ASM hacks made by the Final Fantasy Hacktics community that fix some longstanding bugs and provide quality of
 life improvements:

	All formulas apply elemental (v2) - Fixes the Oil status bug by making it double fire damage properly and sword skills
	with an element attached will now actually apply these elements, taking precedence over the element on a weapon like the
	Ice Brand. Holy Sword skills are all either Holy or Lightning/Holy elemental and Fell Sword skills are Dark elemental.

	Equipment duplication glitch fixes - Fixes the equipment duplication glitches that can be triggered from using Best Fit
	in the shops.

	JP scroll glitch actual fix (Disable paging on confirm menu) - Disables paging when a confirm menu is up so there is no
	way to do the JP scroll glitch.

	Random unit equipment more selective - Random unit equipment will now be more selective of secondary item types.
	(You shouldn't see knights in Chapters 2 to 4 using linen robes)

	Unit slots backfilled when unit is removed from party - When a unit is removed from the party, other units backfill the
	slot so that it doesn't leave a gap in the party.
		-BEWARE!- This hack causes buggy behavior if one of your units permanently dies while you have more than one Guest in
		your party. You’ll know immediately when it happens since one of your Guest characters will transform into another
		character after the battle is over, so just reset if it does. (Most players will reset after a permadeath anyways.)

	Cross Skip v3 - Holding X (Cross button), will fly you through dialog text faster than if you were mashing the button.

	Iaido graphic fix - Fixes a visual bug during some Iaido animations where characters would use a Rod instead of a Katana.
*****************************************************************************************************************************



Prime - Convenience
*****************************************************************************************************************************
*In addition to everything in the previous section, this version of the patch has a few more changes to make the game less
 tedious and more fun to play:

	JP costs of all abilities halved, some absurdly overpriced abilities like Fly(5000 JP) are reduced further.
	The game becomes more challenging overall as a consequence of this change, since enemy combatants are able to afford more
	abilities as well.

	Increased the JP cost of the Chemist's Reequip ability from 0 to 25 to keep it from being equipped on nearly every enemy
	in the game in place of other abilities that may actually provide some help to them.

	Mime's Lv.8 Squire/Chemist prerequisites removed. The job requires only Lv.5 Orator/Geomancer/Summoner/Dragoon.

	Cloud's initial Level when recruited is close to the average Level of your party instead of 1.

	When using the Treasure Hunter ability, only the rare item will be obtained. There won't be any need to worry about a
	unit's Bravery level when searching for items and leaving it up to chance whether you get the rare one or not.
*****************************************************************************************************************************



Ability and Character Statistic Differences
*****************************************************************************************************************************
WHITE MAGIC
Cure 3 is cheaper in FFTU. (400 JP vice 450)
Cure 4 is also cheaper (700 JP vice 800)
Raise is cheaper (180 JP vice 200)
Raise 2 is cheaper (500 JP vice 600)
Reraise is cheaper (800 JP vice 1000)
Regen is cheaper (300 JP vice 350)
Protect 2 is cheaper (500 JP vice 600)
Shell 2 is cheaper (500 JP vice 600)
Wall is cheaper (380 JP vice 400)
Esuna is cheaper (280 JP vice 300)

BLACK MAGIC
Fire/Ice/Bolt 3 is cheaper (480 vice 500)
Fire/Ice/Bolt 4 is cheaper (850 JP vice 900)
Flare is cheaper (900 JP vice 1000)

TIME MAGIC
Hastega is cheaper (550 JP vice 600)
Slowga is cheaper (520 JP vice 600)
Stop is cheaper (330 JP vice 350)
Demi 2 CTR is 9 in FFTU, 10 in FFTJ.
Meteor 60Q and CTR is 13 in FFTU, 40Q and CTR is 20 in FFTJ.
Quick is cheaper (800 vice 900)

YIN-YANG MAGIC
Dispel Magic is cheaper (700 vice 800 JP)
Petrify CTR is 9 in FFTU, 10 in FFTJ.
Petrify is cheaper (580 vice 600 JP)

SUMMON MAGIC
Moogle is stronger and quicker in FFTU (Q = 12, CTR 2) than in FFTJ (Q = 10, CTR 3)
Shiva, Ramuh, and Ifrit are stronger and quicker in FFTU (Q = 24, CTR 4) than in FFTJ (Q = 20, CTR 7)
Titan is stronger and quicker in FFTU (Q = 28, CTR 5) than in FFTJ (Q = 22, CTR 10)
Golem is quicker in FFTU (CTR 3 vice CTR 4)
Carbuncle is quicker in FFTU (CTR 4 vice CTR 5)
Bahamut is stronger and quicker in FFTU (Q = 46, CTR 10) than FFTJ (Q = 42, CTR 15)
Bahamut is way cheaper in FFTU (1200 JP vice 1600)
Odin FFTU (Q = 40, CTR 9) FFTJ (Q = 36, CTR 13)
Leviathan FFTU Q = 38, CTR = 9; FFTJ Q = 34, CTR = 13
Salamander same as Levi
Leviathan costs 850 JP in FFTU, 860 in FFTJ
Salamander costs 820 JP in FFTU, 860 in FFTJ
Sylph is quicker in FFTU (5 CTR vice 7 CTR)
Fairy FFTU Q = 24, CTR = 4; FFTJ Q = 20, CTR = 7
Lich is quicker in FFTU (9 vice 10 CTR)
Cyclops FFTU Q = 50, CTR = 9; FFTJ Q = 44, CTR = 12
Zodiac FFTU Q = 96, CTR = 10; FFTJ Q = 90 CTR = 17

DRAW OUT
Koutetsu costs 180 JP in FFTU, 200 in FFTJ
Bizen Boat is cheaper (260 JP vice 300)
So is Murasame (340 vice 400)
Heaven's Cloud 420 vice 500
Kiyomori 500 vice 600 (see a pattern here?)
Muramasa 580 vice 700
Kikuichimoji 660 vice 800
Masamune 740 vice 900
Chirijiraden 820 vice 1000

LIMIT
Braver is stronger in FFTU (Q = 12 vice 8)
Cross-slash is stronger in FFTU (Q = 22 vice 12)
Meteorain is stronger in FFTU (Q = 26 vice 20)
Omnislash is stronger in FFTU (Q = 40 vice 30)
Cherry Blossom is stronger in FFTU (Q = 60 vice 42)
Climhazzard is cheaper (450 JP vice 500)
Meteorain is cheaper (560 vice 600)
Finish Touch 670 vice 700
Omnislash 900 vice 1200
Cherry Blossom 1200 vice *2500* JP!!!

JUMP
Level Jump 3 is cheaper (300 JP vice 350 JP)
So is Level Jump 4 (450 vice 550)
Level Jump 5 (600 vice 800)
Level Jump 8 (900 vice 1100)
Vertical Jump3 (200 vice 250)
Vertical Jump4 (300, 400)
Vertical Jump5 (400, 550)
Vertical Jump6 (500, 700)
Vertical Jump7 (600, 1000)
Vertical Jump8 (900, 1500)

CHARGE
Charge+10 (600, 700)
Charge+20 (1000, 2000)

R/S/M
A Save (550, 600)
MA Save (450, 500)
Speed Save (800, 900)
Sunken State (900, 1000)
Dragon Spirit (560, 600)
Brave Up (500, 700)
Faith Up (500, 700)
Critical Quick (700, 800)
Hamedo (1200, 1300)
Equip Gun (750, 800)
Half MP (900, 1000)
Gained Jp-UP (200, 250)
Train (450, 500)
Two Swords (900, 1000)
Short Charge (800, 1000)
Move+2 (520, 560)
Jump+2 (480, 500)
Move-Get Jp (360, 400)
Teleport (600, 650)
Fly (1200, **5000**!!!)
Silent Walk (700, 800)

01-03 - UberSquire Ramza
Base stats are better in FFTU.
HP = 7D/78
Spd = 6B/64
PA = 6F/6E
MA = 66/64

C-PA is also better
C-PA = 31/32

04 - Squire Delita
Base stats are superior in FFTU.
HP = 82/78
PA = 78/6E

05 - Holy Knight Delita
HP is better in FFTU.
HP = 87/82

15 - Astrologist
Base stats are superior in FFTU.
HP = 8C/6C
Spd = 7D/78
MA = 82/7D

18 - Arc Knight Elmdor
Elmdor is weaker in FFTU.
Has Maintenance in FFTJ, thus preventing the stealing of Genji equips.
HP = B4/BE
Spd = 78/7D
C-PA = 28/27

20 - White Knight Wiegraf (Death Corps)
Wiegraf is weaker in FFTU.
HP = 8C/96
PA = 74/78

28 - White Knight Wiegraf (Shrine Knights)
Wiegraf is ridiculously weaker in FFTU.
HP = A5/C8
Spd = 6E/8C
PA = 78/7D
MA = 5F/64

32 - Soldier
Cloud is superior in FFTU.
MP = 74/64
C-PA = 2A/32
PA = 7B/6E
C-MA = 2E/32
MA = 78/64

3C - Warlock
Velius has less HP in FFTU.
HP = 50/5A

43 - Impure King
FFTU Queklain is much weaker than FFTJ Queklain.
HP = 32/41
Spd = 82/8A
MA = 82/96

49 - Arch Angel
Altima the 2nd has less speed and PA.
Spd = 5F/64
C-PA = 26/24
*****************************************************************************************************************************



Credits
*****************************************************************************************************************************
*Cheetah, Dominic NY18, Melonhead, Heian, Eternal, Vanya, FFMaster, and PX_Timefordeath for FFT: Complete v.50.

*Tuffy da Bubba and RafaGam for the translated Sound Novels.

*Glain for "All formulas apply elemental (v2)", "Equipment duplication glitch fixes", "JP scroll glitch actual fix (Disable
 paging on confirm menu)", "Random unit equipment more selective", and "Unit slots backfilled when unit is removed from
 party".

*Xifanie for "Cross Skip v3".
*****************************************************************************************************************************



Not a fan of that slightly buggy ASM hack or any of the other gameplay changes I've made? Want to make your own patch using
this as a base? Then you're in luck! Follow the directions below using the files included in the Source folder to set up your
own "FFT: Complete v.51" to work off of.

1. Apply the old FFT: Complete v.50.ppf to a fresh FFT ISO:
https://ffhacktics.com/smf/index.php?action=dlattach;topic=3659.0;attach=2892

2. Using CDMage (https://ffhacktics.com/w/images/6/68/CDmage.7z) open your FFT image and select the 2nd option "M2/2352".
Open the Event folder, right-click TEST.EVT and Import File... selecting the TEST.EVT I've included in the Source folder.

3. Close CDMage once the file is imported. Now, download the 0.492 version of FFTactext from:
https://github.com/Glain/FFTPatcher/releases/download/v0.492/FFTPatcher_492.rar
Open the program and select the .ffttext you want, Prime.ffttext for the vanilla game with the original JPN stats or
Prime - Convenience.ffttext which removes the Lv.8 Squire/Chemist prerequisites from Mime on top of the Prime changes.
(The newer FFTactext versions throw an error when patching, so use the 0.492 version for the .ffttext files I've included.)

4. From here, if you want to revert to the original US PS1 stats you'd best change the appropriate Ability Descriptions
back using the Statistic Differences I posted above. Demi 2, Meteor, Petrify, and the various Summon CTs should be all of it.

5. The fixed WotL translation is patched in! Now it's up to you what you want to do. You should be able to swap to the
newest FFTPatcher suite (https://ffhacktics.com/wiki/FFTPatcher_Suite) for the FFTPatcher and FFTorgASM programs. Apply my
gameplay changes by using the .fftpatch files with FFTPatcher or the various ASM Hacks by using Prime.xml with FFTorgASM if
you wish.