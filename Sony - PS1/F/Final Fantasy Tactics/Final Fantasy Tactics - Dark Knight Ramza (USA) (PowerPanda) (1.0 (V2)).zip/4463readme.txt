Patch Name: Dark Knight Ramza
Author: PowerPanda
Released: April 2019

Patches created for: Final Fantasy Tactics (PSX - US)
ROM/File SHA-1: 2B5D4DB3229CDC7BBD0358B95

Patches:	Original - The original version of this patch, updated
		With Crystal - Includes Glain's ASM Hack

--------------------------------------------------------------------------------------
---===Description===---
This is a small patch for the PSX version of Final Fantasy Tactics that allows Ramza to learn the Dark Knight techniques "Night Sword" and "Dark Sword" when he fights against Gafgarion at the end of Chapter 2. If Ramza's class is set to "Squire", he will learn these techniques upon contact.

The techniques can only be learned from enemies, so Gafgarion will not be able to teach it to you in any battle where he is an ally (including Zierkile Falls, since he starts as an ally), and Ramza cannot learn it from Cid.

To offset these skills being so easily missable, the recurring villain Rofel has been changed into a Dark Knight, so that Ramza can also learn these skills in Chapter 4. The battles where this technique can be learned are:
1. Ch2 - Golgorand Execution Site (Gafgarion)
2. Ch2 - Lionel Castle Gate (Gafgarion) (contact or crystal)
3. Ch4 - Hallof St. Murond Temple (Rofel)
4. Ch4 - Underground Book Storage Fifth Floor (Rofel)

--------------------------------------------------------------------------------------
---===Applying the Patch===---

Apply to Final Fantasy Tactics (US) using a PPF program, such as PPF-O-MATIC. Note that the File SHA-1 is for a .BIN file. If you have a .ISO file, it may not work.

This has been tested several times, and is confirmed to be working. If you note any oddities, please make sure that you have the correct BIN (check the SHA-1).

--------------------------------------------------------------------------------------
---===Patch Origins===---

I discovered the technique for making these skills accessible while I was creating my PSP War of the Lions complete hack, "Final Fantasy Tactics: Emergence". The key to making this work was to have 2 copies of Night Sword and Dark Sword: One for use by your enemies, and one for use by your allies. Gafgarion and Cid learn the ally version using JP, whereas Ramza can only learn the enemy version by being hit with it. The skill shows up as a row of dashes on his skills prior to learning it, just like Ultima.

If you enjoy the idea of this, check out FFT Emergence at:
http://www.romhacking.net/hacks/3291/
In that patch, Ramza becomes a true Dark Knight by the end of the game. It also tweaks every other named character, re-arranges the job progression system to make more sense, has 1 brand new job, and contains 46 new learnable skills. I'm proud of it.

--------------------------------------------------------------------------------------
---===Version 2 Changes===---

A few players noted that it was nearly impossible to get Gafgarion to use "Dark Sword" on them. It is admittedly difficult, for 2 reasons:
* Gafgarion only uses Dark Sword against characters that have damaging MP-based spells available in the battle. For example, he will go after Summoners with a Black Magic sub-skill with Dark Sword, but will never use it against Archers with a Punch Art subskill.
* It's not well known, but the original game has both Dark Knight abilities set up to be learned on contact. However, the content is dummied out. The original probabilities for learning them on contact were 100% for "Night Sword", but only 50% for "Night Sword".

Version 1 of this patch left both of those intact to stay as true to the original design as possible. Version 2 has been split into 2 patches so that you can address those issues.

"Original" - This simply updates the probability for "Dark Sword" to 100%. If you get hit with it, you learn it.

"With Crystal" - This also updates "Dark Sword" to 100% probability. In addition, it also incorporates an ASM hack by Glain that allows Ramza to learn the abilities from Gafgarion's crystal, regardless of his current class. If you choose to learn either ability, you will learn both.

--------------------------------------------------------------------------------------
---===Compatibility and Tutorial===---

It is unknown if this patch is compatible with any other FFT patches. If you are interested in combining it with another patch, the best method is to re-create the patch via FFTPatcher and FFTactText. Follow these steps to do so:

1. Create the techniques
  A. Open FFTPatcher and go to the "Abilities" tab.
  B. Choose which slots you want to use to make the copy techniques. I use the 2 empty slots 0165 and 0166, and will refer to them by number in this guide.
  C. Right-click on 00A4 (Dark Sword) and choose to "Clone". Then right-click on 0165 and choose to "Paste All"
  D. Right-click on 00A5 (Dark Sword) and choose to "Clone". Then right-click on 0166 and choose to "Paste All"
  E. On both techniques, set "JP Cost = 0" and "Chance to Learn = 100". Then uncheck "Learn with JP (Player)" and check "Learn on Hit" 
  F. Go to the "Animations" tab and scroll down to 0165 & 0166. Set these both to "|07|00|00|". This causes the technique to be cast by a swing of the sword, rather than raising hands.

2. Assigning the Techniques
  A. In FFTPatcher, go to the "Skill Sets" tab.
  B. Find Ramza's skillset 1A (Guts). Add 0166 to Slot 9 and 0165 to Slot 10. Note that this will leave a blank slot after 0097 (Cheer Up). This is because the techniques need to be in the same slots between skillset 1A (Ramza 2nd Chapter) and 1B (Ramza 4th Chapter).
  C. Find Ramza's skillset 1B (Guts). Add 0166 to Slot 9, 0165 to Slot 10, and 009A (Ultima) to Slot 11.
  D. Find Gafgarion's enemy skillset 27 (Dark Sword). Add 0166 to Slot 9 and 0165 to Slot 10.
  E. Find Rofel's skillset 3C (Mighty Sword). Add 0166 to Slot 9, 0165 to Slot 10, and 0000 <Nothing> to all other slots.
  F. Optional. Cid's skillset 4A (All Swordskill) has Night Sword and Dark Sword backwards. Swap the slots for 00A4 and 00A5.

3. Changing the Text
  A. Open FFTactext and import your ISO.
  B. Go to the Ability Descriptions block. Copy #164 to #357 and #165 to #358. 
  C. Go to the Ability Names block. Copy #164 to #357 and #165 to #358.
  D. Go to the Ability Quotess block. Copy #164 to #357 and #165 to #358. 
  E. Go to the Skillset NAmes block. Set #60 to "Dark Sword".

4. Patching your ISO
  A. Apply the patch from FFTPatcher
  B. Apply the patch from FFTactext
  C. Optional. Apply Glain's ASM hack, which is included in FFTorgASM

If you wish to do this with the PSP version, you will quickly note that there ARE no empty ability slots. The best method is to overwrite Sanguine Sword and Infernal Strike. Then, make sure that the "Dark Knight" job has the ally version of the abilities.

--------------------------------------------------------------------------------------
---===Credits===---
Glain: "Crystals can include special job abilities" ASM Hack
Tools Used: FFTPatcher, and FFTactext, and FFtorgASM 4.92