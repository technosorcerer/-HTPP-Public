=============================================================================
                  Final Fantasy Tactics: Emergence
=============================================================================

Author: PowerPanda
Version: 1.3.2
Applies to: Final Fantasy Tactics: War of the Lions (EU) PSP

Contents:  fftemergence_1_3_2.ppf - The Main Patch
	   FFTE Class Guide.xlsx  - Spreadsheet outlining the Job Classes
	   FFTE Job Tree.jpg	  - Image of the Job Tree
	   Resources.zip	  - Source file for FFTPatcher Suite

=============================================================================
Final Fantasy Tactics was made in 1997, and remains one of the best Tactical Roleplaying Games on the market. In 2007, it was remade for the PSP and ported to IOS/Android. In 2017, this project was created to try to make a better FFT experience. Everything about the game, from concept art to battle data, was examined to see what hints were left of original design choices. Several themes started to "emerge" from this investigation. FFT: Emergence is the result of this exploration. 

Here is a high-level overview of the changes:
   * The Job progression has been re-organized to be more intuitive and sensible. For example, Lancers are gained from training Knights, not Thieves.
   * There are 49 new abilities to learn. 19 were previously enemy-only, and 30 new abilities were created by removing duplicates between classes.
   * Magick charge time and damage formulas have been tweaked to bring mages into balance.
   * Faith is no longer used in Attack and Healing Magick.
   * Many job classes have been tweaked. The following classes were completely redesigned:
      - Soldier (aka Knight) - Given the original Archer ability to charge attacks
      - Archer - Able to inflict statuses through special arrows
      - Cleric, Wizard, Enchanter, and Mystic (aka White Mage, Black Mage, Time Mage, & Oracle) have all shuffled spells around to allow for deeper specialization within each job class.
      - Magus (aka Dark Knight) - redesigned to be an armor-wearing mage class with access to 8 spells previously reserved for enemies.
   * Every special character has been modified. The biggest changes are:
      - Ramza. Slowly becomes a Dark Knight over the course of the story, able to learn the Dark Sword techniques from fighting against Gaffgarion
      - Mustadio. Gains all of the "Sap" abilities, so he can reduce enemies's Power, Magic, Speed, and MP.
      - Beowulf. Swapped spell animations with the Mystics to give his class more personality. Does not require swords to cast his spells.
      - Luso. Given a unique class consisting of the Astral Magicks.
   * Every storyline battle has been tweaked to give players a greater variety of enemies and a smoother difficulty curve.
   * Many items and weapons have been updated.
   * And, of course, the animation slowdown has been removed.

Taken in total, FFT: Emergence offers new gameplay possibilities while still retaining the theme and feel of the old classic. With a difficulty level similar to the original game, any player can pick this up with confidence.

===---===To Apply This Patch===---===
Apply to an unpatched FFT WotL ISO, EU Region. Use a program like PPF-O-Matic to apply the patch. The patched ISO can be played on a PSP emulator or on a homebrew-enabled PSP. If you have an earlier version of Final Fantasy Tactics: Emergence, please start with a clean ISO. You will be able to continue save files from previous versions, but each patch should always be applied to a clean rom.

===---===Dislaimers and Acknowledgements===---===
Everything offered in this patch is done as a free fan-work. All rights to the art, characters, story, etc. remain with Square-Enix. Please purchase the original game, even if you only ever play this hack. It's cheap, and it gives money back to Square-Enix, the owners of the copyright.

I want to give a special thanks to the FFHacktics community for their wealth of programs and documentation on Final Fantasy Tactics. This hack was created using the Shishi Sprite Editor, FFTPatcher, and FFTactText, plus a lot of finesse and elbow grease. It also incorporates Eternal's Slowdown Removal Patch. After playing this patch, why not head over to their site to download some more extensive hacks that completely change the way the game is played?

===---===Detailed Changes===---===
-=Weapons, Clothing, and Items=-
   * Fell Swords take the place of bags. They do more damage the lower your Faith is.
   * Rods damage based on a character's Magic stat, not their Attack stat. This allows a silenced mage to be of some use.
   * Staves are not used for attacking. Instead, they bestow beneficial statuses upon contact.
   * Knives give a +1 boost in speed.
   * All weapons except for Axes have been changed to single-handed weapons.
   * Guns may be dual-wielded. An additional gun has been added for Chapter 4 to bridge the gap between the Mythril Gun and the elemental guns.
   * All shields have increased evasion.
   * All armor gives a larger HP boost.
   * There is no longer any female-only equipment. Hair adornments have been classified as hats, perfumes have been classified as rings, and bags...
   * Chemist Items have been updated to be more powerful and versatile. X-Ethers have been added to the game.
   * Many items have been renamed to reflect changes.

-=Ability Changes=-
   * Too many abilities have been updated to list them all here. Just use the select button in-game. All help text has been updated.
   * Character Special abilities require MP. This is offset by the Refresh line of spells and better Ethers.   

-=Class Changes=-
   * See the included "Class Guide" spreadsheet.

-=Job Tree Changes=-
The job tree has been re-arranged to make more sense for class progression throughout the game. The Squire is the only base class (Chemist being upgraded to a Tier 1 class), and each branch on the path has 3 tiers. The 4th tier requires mastery of multiple branches of the path.

Squire > All Tier 1 Classes > Onion Knight
Soldier > Lancer > Samurai
Archer > Thief > Ninja
Cleric > Enchanter > Summoner
Wizard > Mystic > Summoner
Monk > Geomancer > Dancer (female only)
Chemist > Orator > Bard (male only)

Samurai + Ninja + Geomancer = Mime
Summoner + Orator = Arithmetician
Master Wizard + Master Monk + Soldier + 20 Kills = Magus

See also the included "Job Tree" jpeg

-=Game System Changes=-
   * The PSP Menu Icon/Background and the Game Title Screen has the new logo and art.
   * The Slowdown Removal Patch is included.
   * Every character has "Defend" and "Re-Equip" innately.
   * Monsters have updated Poaching rewards.
   * No moster or trap has the ability to level down your characters. It is impossible to power-level late game.
   * Each storyline battle has been tweaked to provide a steadier difficulty curve. Notorious battles like Golgollada Gallows and Riovanes Castle Interior have been toned down to not be quite so much of a surprise. End-game spellcasters also may have the ability to cast without charge time...

-=Treasure Hunter Changes=-
   * With the Materia Blade now coming equipped on Cloud, it no longer makes sense to find it on Mount Berevenia. I have replaced the item in that location with the "Arondight".
   * Treasure Hunting at Nelveska Temple has been changed so that you will always get the rare item.

=============================================================================
VERSION 1.3.2 CHANGELOG
=============================================================================
After the streamer CasualTom did a full playthrough, we found a number of minor things that needed to be fixed. Thanks, Tom!
1. Watera and Watega can be used with Arithmetics.
2. The Summoner in Lake Posecas is no longer 25 levels above your party.
3. Stoneshooter now costs an appropriate amount of money.
4. The Behemoth line of enemies has been rebalanced to make the Luso battle not impossible.
5. Byblos's abilities have been reworked.
	- Parasite no longer costs MP
	- Vengeance and Karma had the same damage formula. Vengeance has had its formula changed to be the difference between the attacker's max and current HP, not Byblos's.
	- Karma no longer has charge time.
6. Reis's "learn on contact" spells, Tri-Flame, Tri-Thunder, and Dark Whisper, were being learned automatically. They have been changed to learn with JP to prevent this. Dark Whisper has been made to be a dark equivalent of Holy Breath. Both have had their max casting number dropped to 7, after Tom one-shotted the final boss with Holy Breath.

=============================================================================
VERSION 1.3.1 CHANGELOG
=============================================================================
Two small corrections
1. The Astral Light formula has been changed to ignore magic evasion.
2. "Concentration" and "Defense Up" have been swapped between the Archer and Lancer classes, as listed in the Class Guide Spreadsheet.

=============================================================================
VERSION 1.3.0 CHANGELOG
=============================================================================
PapaQuackers noted an error in the Squire Skillset with Version 1.2. Water Anima had been listed twice (one of them should have been Fire Anima), and it caused both abilities to subtract JP, but not be "learned". The skillset has been corrected.

I also corrected a minior error that didn't affect gameplay. In the opening battle, Lezales has the "Vigilance" ability. However, I had put it in the "Support" slot instead of the "Reaction" slot.

Two bugged battles were reported that were impeding players' progress:

1. Luso Recruitment Battle
Depending on your party members' speed stat, it is possible that the Behemoths could kill Luso before you have a chance to act. Luso, for his part, jumped right into the fray. After re-examining this battle, I found its difficulty spike to be way out of line with what Emergence is trying to accomplish, so I made several fixes to bring it back in line:
  *Luso's AI has been marked as "Defensive", so he should act the same as Alma, fleeing from enemies and supporting your team.
  *The Behemoths and Dark Behemoth have been dropped by 2 levels. This should drop their speed to below average. Special thanks to Raijnili for this solution
  *The Starting location of the Dark Behemoth has changed, to focus on your party instead of Luso.
  *The Starting location of 1 Behemoth King has changed to be further away from Luso.
  *The "Twister" ability has been dropped from 34% damage to 33% damage

2. Final Battle vs. Ultima
It was reported that the final battle softlocked on Ultima's first action. This took me months of research, but I finally found that there were 2 problems. First is that the AI was set incorrectly for both Astral Light and Grand Cross. They were swapped. Astral Light only hits allies, but the AI was set to target only enemies. Grand Cross was the opposite. The second, and more serious issue, is that the ability for Ultima's movement shares a slot with Dusk Blade (Enemy Version). So she would teleport, and the game would lock up waiting for the MP damage to show up. Both of these errors crept in between version 1.0 and 1.1. I have corrected them and tested the battle so that the game no longer locks.

=============================================================================
VERSION 1.2.0 CHANGELOG
=============================================================================
-=-=HIGH-LEVEL CHANGES=-=-
*Textual errors corrected
*All innate reaction abilities have been removed
*A few abilities have been shuffled around between classes, and 4 more abilities have been added
*Luso has been given a unique class based on the guest character Orran's "Astrology" abilities

-=-=SYSTEM=-=-
*ISO has been rebuilt from scratch to correct all known item, tech, and help text errors.
*Text for PSP-only Rendesvous Reward items has been updated and corrected. 
- Important Note: all of these items are dummied out in FFT: Emergence. The only way to gain them is to load a save file from another version of the game or hack your save file.
- Bags have replaced the items that replace them in Emergence (Fell Swords and Pistols).
- Should Bags be hacked into your game, they can only be equipped by Chemists, Orators, and Onion Knights.
- All other items have updated names and help text.

-=-=CLASSES=-=-
=SQUIRE=
- 'Vanish' ability added.
- 'Float' upped to 150 JP.

=WIZARD=
- 'Firaja', 'Blizzaja', and 'Thundaja' reduced to 580 JP
- 'Dark' reduced to 600 JP

=ENCHANTER=
- 'Vanish' removed.
- 'Dispel' reduced to 200 JP, targeting limited to 1 tile
- New Ability 'Dispelja' added for 400 JP

=ARCHER=
- Innate ability changed from 'Vigilance' to 'Defense Up'

=THIEF=
- Innate ability 'Reflexes' removed

=MYSTIC=
- Innate ability changed from 'Absorb MP' to 'Manafont'

=ONION KNIGHT=
- 'Master Teleport' added as an Innate ability for Master Onion Knights
- 'Moogle Charm' removed

=MAGUS=
- 'Master Teleport' removed
- 'Celestial Stasis', 'Astral Light', and 'Grand Cross' removed
- New abilities 'Bio', 'Biora', and 'Bioga' added. These previously enemy-only abilities have had their status effects changed to be more fitting for a player character
- Now requires Lv.8 Soldier to unlock, in addition to Master Monk, Master Wizard, & 20 kills

-=-=CHARACTERS=-=-

=STARTING GENERIC CHARACTERS=
- In addition to Biggs, Wedge, and Jessie, the other 3 generics have been given the static names of Dak, Sarah, and Ashley.

=LUSO=
- No longer a copy of the Tengille Family's Arcane Knight class (aka Meliadoul's, Isilud's, and Folmarv's class)
- Gains 'Moogle Charm' from the Onion Knights, renamed to 'Montblanc'
- Borrows 'Quick'/'Stall' from the Squires, who retain their use.
- Gains 'Astral Light', 'Celestial Stasis', and 'Grand Cross' from the Maguses.
- All gained abilities have had their JP costs updated.

=AGRIAS, MELIADOUL, FOLMARV, ISILUD, & GAFFGARION=
- All have gained the "Spirit Blade" ability

-=-=BATTLES=-=-
*Ch2 - Zierchele Falls - Archer corrected to be holding a bow.
*Midlight Deep 10 - Terminus - After beating the storyline battle, there are 4 special encounters in Terminus, inspired by the Rendesvous Battles. Each has a copy of a side character with a unique class, plus all 3 variations of the 4 strongest monster classes.
 1. Reis and Dragons
 2. Beowulf and Behemoths
 3. Valmafra and Hydras. Valmafra has Cletienne's Magick set of Holy, Darkness, Luminaire, Flare, and Arise, with the Squire's "Red Magicks" as a secondary skillset.
 4. Chocobos and Cloud. This has 1 black Chocobo named "Teioh" (party level +5) with 3 Yellow and 3 Red Chocobos for backup. Cloud cheats and uses the Onion Arts skillset as his secondary skill (Barrage). 

===---===Version 1.1.1 to 1.3 Compatibility Notes===---===
Final Fantasy Tactics does not store abilities by their ID number. Rather, it stores them by slot. So, if one version of the game had the spells listed in the order of "Fire, Blizzard, Thunder", and you learned "Fire", the game doesn't actually store that you learned "Fire". It stores that you learned "Slot #1". If the next version had them ordered "Thunder, Fire, Blizzard", and you loaded your save file, you would know "Thunder" instead. This affects a few classes between 1.1.1 and 1.2.
*SQUIRE > Vanish has been added. As a result, all abilities except Chant, Salve, and Oil have been shifted down 1 slot.
* ENCHANTER > the slots for 'Vanish' and 'Dispel' have changed to 'Dispel' and 'Dispelja'.
* MAGUS > the slots for 'Astral Light', 'Celestial Stasis', and 'Grand Cross' have been replaced with 'Bio', 'Biora', and 'Bioga'. Master Teleport has been removed. There is no way to gain back the 3000 JP.
* ONION KNIGHT > 'Moogle Charm' has been removed.
* LUSO > Luso is totally different, but all abilities should map to a rough equivalent in terms of JP.
* AGRIAS, MELIADOUL, GAFFGARION > All abilities have shifted down by 1 slot.

======================================================
REQUESTED CHANGES NOT MADE/ODDITIES EXPLAINED

*Why do some abilities display damage and statuses twice?
>There are 12 abilities that do this: the 7 Marksmanship Shots, Pulsar Crush, Spirit Blade, Snipe Movement, Snipe Action, and Seal Evil. This is because the of the way FFT handles animations. There is a casting animation and an effect animation. Sometimes, the casting animation does not wait for the effect animation before displaying damage. This is fixable by updating the animation string, but I have not yet found one that shows the weapon being used, but waits for the effect.

*Can Ramza have Chant and Salve?
>If you want to use FFTPatcher to add this, go ahead. My patch will not have them. I wanted to portray 2 things through Ramza's lack of abilities at the beginning: First, I wanted the generic characters to not be expendable (This is also the reason why your initial 6 generics will always have the same name). Ramza must rely on his support team to progress. Second, I wanted to show Ramza and Delita progress into a Dark Knight and Holy Knight, respectively. Chant and Salve don't really fit into those classes.

*Why is it so hard to hit Skeletons with arrows?
Skeletons have the inherent ability "Archer's Bane". They are not the only creatures who have gained inherent abilites.