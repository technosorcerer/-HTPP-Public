Final Fantasy 9 -- Comprehensive ATB Enhancement v1.00 (Alternate Fantasy Compat Patch)
by RoSoDude https://rosodudemods.wordpress.com/

Comprehensive ATB Enhancement alters several enemy scripts to remove instant ATB fill gimmicks. Since the Alternate Fantasy hack makes its own changes to enemy scripts, it needs a custom patch for compatibility with the ATB hack. This is only relevant for Disc 3 and Disc 4.

Patch installation order (1.0 ROMs):
1. Alternate Fantasy v3.2
2. Comprehensive ATB Enhancement
3. Alternate Fantasy Compat Patch

NOTE: If the game gets stuck on a black screen while loading (title screen or battles), you need to use error_recalc or EDCRE to fix the EDC/ECC data on your ROM