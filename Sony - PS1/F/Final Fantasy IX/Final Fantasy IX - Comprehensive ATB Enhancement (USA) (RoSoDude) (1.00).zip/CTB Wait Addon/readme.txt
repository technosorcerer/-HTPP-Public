Final Fantasy 9 -- Comprehensive ATB Enhancement v1.00 (CTB Wait Addon)
by RoSoDude https://rosodudemods.wordpress.com/

This patch augments the main ATB hack with an additional feature. When "Active" mode is selected in the config menu, battles work exactly as in the main ATB hack. When "Wait" mode is selected in the config menu, battles become fully turn-based, similar to FF10's CTB battle system (or the PC Memoria Engine's turn-based mode). In this mode of play, time stops when any command menu is open (not just submenus as with the default Wait mode), as well as when there are any commands waiting on the queue. The balance is nearly identical to the main ATB hack as time only proceeds between character turns, however there is no longer any real-time pressure to input commands.

Additionally, when the player attempts to flee while in "Wait" mode, the system temporarily reverts to "Active" mode to enable time to pass while the player characters roll for escape attempts. This can also be used to pass time if the player wishes to delay a character's turn.

This patch can be installed instead of OR on top of the main hack.