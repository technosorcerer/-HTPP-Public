Final Fantasy 9 -- Comprehensive ATB Enhancement v1.00
by RoSoDude https://rosodudemods.wordpress.com/

Final Fantasy 9's ATB system has some notable flaws compared to other entries in the series. ATB is always running in the background regardless of battle animations, so commands can quickly pile up on the queue. This functionally caps the effectiveness of the Agility stat, lets buffs wear off too quickly, and makes auto-regen overpowered. Furthermore, it enables "Wait tricking" abuse with the Wait mode config setting, where the player enters a command submenu to pause ATB during player animations, but lets ATB resume during enemy animations to gain a turn order advantage. Finally, there is general agreement that the battle animations in FF9 are too slow, leading to very sluggish battles compared to prior entries.

Whereas a previous hack sought to speed up battles by increasing the speed of ATB alone, this only exacerbated the problem with slow animations and the command queue, and furthermore lead to status effects ticking much too quickly in the background. This hack makes ATB gauges and other battle timers pause during battle animations, identical to my Comprehensive ATB Enhancement hack for FF6. ATB speed and rates for all status effect timers are more than doubled to offset the added downtime. The 3D scene framerate in battles is also increased by 33%, resulting in faster battle animations and a shorter camera swirl at the start of fights. Monster ATB has a small delay to account for higher Speed stats and instant command queueing. Instant fill ATB gimmicks are removed from several enemies (Ozma, Hades, Kraken, Tonberries) to make these fights possible in the new ATB system. The end result should be a more tactical and robust ATB system which can be tweaked to the user's preference using the in-game config settings.

Included alongside the main hack is an alternate "CTB Wait Addon" patch which removes all active time elements from battle when "Wait" mode is selected, similar to FF10's CTB battle system (or the PC Memoria Engine's turn-based mode). See the separate readme for details.

The included patches are compatible with 1.0 and 1.1 (Rev 1) US ROMs. The hack should be compatible with pretty much every other hack for FF9, except for "Final Fantasy IX ATB Gauge SpeedUp" which is redundant. A special compatibility patch is required for use with Alternate Fantasy v3.2; see the separate readme for details.
NOTE: If the game gets stuck on a black screen while loading (title screen or battles) when used alongside another hack, you need to use error_recalc or EDCRE to fix the EDC/ECC data on your ROM.

Source files for assembly and hex codes are included as a reference for other modders.

Acknowledgements to FFHacktics community members Tallcall, Sardek, Xifanie, and RetroTypes for essential tips on MIPS assembly/PSX debugging
Acknowledgements to Tirlititi for Hades Workshop editor and technical information

Changelist:
v1.00 
-Initial Release