PopoRogue English Translation Patch
Version 1.0
9/12/2025


PopoRogue is the second installment in the PopoloCrois trilogy of Playstation 1 games. Unlike the other two games in the series, this is a dungeon crawler with more minimal story and character elements. You still play as Prince Pietro, but instead of the usual cast of characters, you travel with a large selection of hired mercenaries who you can build parties with and train up.

This patch has been tested on a PS1 Slim, Duckstation, No$psx, and ePSP emulators.

There are known bugs in some emulators that can cause dungeon names to show up incorrectly and can mess with the music. They resolve after saving + restarting.
These are believed to be emulation issues with the original game. But if you encounter this and want to help, please drop a note in the PopoloCrois community discord with your emulator details and a save state!

PopoloCrois Community Discord Link:
https://discord.gg/gWcHWPU5hj

A translation of the game’s manual is available here (credit to Zenksren):
https://mega.nz/file/3UpCDQzR#u1ezhcLzkQ0dDyVfPqoAxTQlbcGHZouJ32bt-pg_5eI

-------------------------
Differences From Original
-------------------------

We have taken the liberty of making some non-translation changes to the original game as follows:

-The Painter NPC from the PopoRogue Demo Disc who gives you a souvenir has been placed in PopoloCrois Castle Town at the very beginning of the game. He is missable if you progress too far, so find him right away!

-The Stray Robot NPC in Gabass will give you all the unique rewards that could only be obtained from using the PocketStation Mini upon the first time talking to them. The items will just show up in your inventory after.

-The Stats menu now displays how close you are to the next level for spells that are applicable.

-Some enemy spawns have been modified to appear at higher levels than in the base game to make 100%-ing the game without relying on the post-game possible. Check out gameplay tips below for a lot more info on this.

-A small number of bugs in the original game like item names being duplicated and such.


-------------------------
Installation Instructions
-------------------------

Download Delta Patcher: https://github.com/marco-calautti/DeltaPatcher/releases

Apply the included xdelta patch files to the disc image of the game:
File/ROM SHA-1: 3EB37F759827900432542A2C1E834FE22749E77B
File/ROM CRC32: 53520C6E

Note that this patch uses the 1.1 version of the game. If the delta patch gives a checksum error, you may have 1.0.


------------------------
Translation Team Credits
------------------------

Riley Bayless (LostOkina) - Hacking, Tooling
Aquagon - Translation, Testing
ExileKiller - Main Menu Graphics

Also thank you to the PopoloCrois discord members for additional beta testing. In particular Zenksren, keke094, and IamMai.

-------------
Gameplay Tips
-------------

-The Item Book can't be filled until the post-game, but you should still strive to try and fill it as much as possible in the main game. For this, try to make
extensive use of the Bargains function in both the Tiger Department Store and Hans' shop in the Lost Town, though keep in mind that the former won't work properly
for this purpose after you obtain the Pendant of Dreams and start the final act of the game.

-Although we made several changes to minimize this when we applied the monster spawn changes, there are monsters you will have a hard time meeting, or even won't be
able to encounter anymore if Pietro's level is too high or if you pass a certain plot trigger.

#41 - Bone Soldier
#43 - Poison Scorpion
#44 - Cactin
#45 - Sand Leech
#49 - Scorpion
#50 - Getchu

All the above monsters disappear from the rest of the game once the Pyramid has been cleared and Coromock has turned green.

#46 - Energy Soul

One appears as a fixed encounter. Others can only be found in B4F and B5F of the Scorching Cave if the party level is low (less
than Lv. 28 in the normal game, less than Lv. 34 in the patched game). Access to these floors requires having cleared the Haunted Castle.

#92 - Flasher

Only appears as a fixed encounter in a section of the Strange Swamp that becomes inaccessible upon clearing the Maze of Gold and Death. Encountering it in other
areas of the swamp requires a low level party.

#107 - Buffalo
#118 - Cactess

These two monsters only appear in the Karakara Plains if the average party level is middling (Lv. 25 to 34 in the normal game, Lv. 31 to 40 in the patched game).

#120 - Chugga-chugga

This monster can only appear in the Lost Woods if the party is at a certain level (Lv. 25 to 31 in the normal game, Lv. 31 to 37 in the patched game).

#120 - Chugga-chugga

This monster can only appear in the Lost Woods if the party is at a certain level (Lv. 25 to 31 in the normal game, Lv. 31 to 37 in the patched game).

#124 - Miraculous Doll

It can only be encountered in the Beanstalk if the party is at a certain level (less than Lv. 32 in the normal game, less than Lv. 38 in the patched game).

#134 - Penpy
#141 - Caterpillar
#144 - Cat Bat
#145 - Spag
#149 - Killer Clown

These monsters are exclusive to the Heavenly Castle, and all monsters in that area disappear upon completing the Dream of th-e Past segment.

#183 - Big Paw
#184 - Battle Shooter

These monsters only show up in the Dream Cavern if the party is at the appropriate levels (less than Lv. 43 in the normal game, less than Lv. 49 in the patched game).

#195 - Tiny Drone
#196 - Young Mantis
#197 - Beetli'l
#198 - Lamb
#199 - Mini-Living Dead
#200 - Little Orc
#202 - Mother Drone

All these monsters are exclusive to the Dream of the Past segment. They can't be encountered anywhere else, not even in the Dream's Continuation.

-Completing the Dream Field Atlas is impossible if you aren't careful about exploring the Stone Maze and the Strange Swamp at certain points during the story.

Stone Maze:

1. Upon entering the Great Crossroads for the first time.
2. After Coromock becomes green again.
3. After defeating all four Dream Demons.

Strange Swamp:

1. Upon entering the Strange Swamp for the first time.
2. Anytime after clearing the Maze of Gold and Death.

This is because the first few rooms change for the former, and access to two rooms is lost for the latter.

------------
Author Notes
------------

LostOkina:
I am so excited that with the release of this patch, the entirety of the PopoloCrois trilogy on the PS1 will be fully playable in English. My thanks to everyone in the community who came together to make it happen. My only ambitions when I started hacking Monogatari II was just to have some fun and learn some new skills. But now, with a lot of collaboration, this series has 3 very high quality translation patches. I love these games, I really hope you enjoy experiencing them!!

aquagon:
It was a pleasure and a joy to work on this project even though I had to split my time between it and the final months of work in the Ciel nosurge Offline patch. My greatest thanks to LostOkina for all the work put into it, as well as honoring my requests for more features into the game!

POPOROGUE is ©Sony/Sugar & Rockets/G-Artists(Epics), PopoloCrois ©Yohsuke Tamori