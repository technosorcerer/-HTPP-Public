=========PopoloCrois Story II (English)=========

A complete English patch for PopoloCrois Story II on PlayStation.
This cult classic RPG was ported and released in the west for PlayStation Portable but was mashed together with its predecessor, resulting in a lot of content changed/cut from both games, and the port itself was poorly made and sloppily translated. For the first time this game can now finally be fully played in English in its original form.

Tested on real hardware, Retroarch (SwanStation core), standalone DuckStation and no$psx.
Experience may vary on other emulators.

A translation of the game's manual is available here:
https://mega.nz/file/LEZjEYDA#LbLPxs5WULfUDwG1m2F1xaFxenQ7sviOZ3ll65vV3eE

CHANGELOG-
v1.1 (11/17/24):
-Updated FMV subs
-Added subs to OP and circus FMVs
-Polished a few areas of Chapter 0's NPC translation (Thanks to Cloudstrife7894 and lindentree for input)
-Minor grammar/formatting fixes
-"Wrong Disc" message(s) now translated
-Fixed un/mistranslated totem pole messages (Chapter 3/5)
-Fixed mistranslation in Chapter 3 story cutscene ("Ashi-onna" wordplay. See "Translation Disclaimer" for more details)
-Fixed spelling of Romana art gallery names (Was previously unaware these are developer anagrams. Thanks to keke_094)
v1.0 (10/30/24): Initial release

===============================================
                Author Notes
===============================================
I began working on this in Jan '24 as an addendum to LostOkina's v0.3 patch with my goal originally to just translate all the NPC text. Eventually in collaboration with LostOkina himself, however, we were to able to add the rest of the translated text I was unable to insert myself and the game-breaking bugs that existed in the v0.3 patch have all been fixed. This was 10 months of on-and-off work for me and I'm happy to have helped see finally this project to completion, please enjoy! ~Zenksren

I am so excited to see this project come to completion. A big thank you to Zenksren for picking this project up and taking on the challenge of translating the massive amount of NPC dialogue in this game. It was also a great opportunity for me to make use of everything I learned since the initial release of the v0.3 patch. For me this project began merely as a way to kill some time during the summer of 2017, but I am so proud of what it is now. This game has a special place in my heart, I really hope you enjoy it! ~LostOkina

===============================================
                Instructions
===============================================
Download Delta Patcher: https://github.com/marco-calautti/DeltaPatcher/releases

Apply the included xdelta patch files to each respective disc image of the game:
Disc 1 - File/ROM SHA-1: 1245E1378C78D5FCB40A0D0082AABBBAF4F18A7D
Disc 1 - File/ROM CRC32: D1195D21
Disc 2 - File/ROM SHA-1: 178ED1522CCA6164B13082758A2131536616BAA2
Disc 2 - File/ROM CRC32: 1A6795BC
Disc 3 - File/ROM SHA-1: 74F27430AA3533956BA4CE10C8E16DB64B8625B9
Disc 3 - File/ROM CRC32: 3AB533CC

===============================================
          Differences from Original
===============================================
-Subtitles added to FMVs
-Subtitles added to most in-game cutscenes that were voice acting only (See "Technical Disclaimer" for more details)
-Several elements of the UI were widened to allow for most menu/item/area names to fit fully in English
-Small font size is used for enemy names in Monster Cards to fit in English
-2 NPCs in Chapter 3 (children in the PopoloCrois town school) who had the wrong dialogue due to developer oversight have been fixed

===============================================
                  Credits
===============================================
Zenksren - Translation (NPC/Monster Cards/Manual), Editing, Testing
LostOkina - 0.3 Patch, Translation, Testing, Hacking, Tooling
Aquagon - Translation (What the Twinkle Star Says)
Wyrdwad - Translation (2002 GameFAQs Translation Guide, A Tiny Flower)
ERT, ??? - Translation Feedback/Assistance

Special thanks to the PopoloCrois Discord server and my close mutuals for their support 

===============================================
               Legal Disclaimer
===============================================
Game ©Sony/Sugar & Rockets/G-Artists(Epics), PopoloCrois ©Yohsuke Tamori
Buy/support official releases if they happen, don't get your copy of the game from an illegal source, don't buy repro copies, don't make repro copies etc etc.

===============================================
            Translation Disclaimer
===============================================
I relied heavily on DeepL and online dictionaries for reference as I know very little Japanese so the translation may not be accurate to the liking of some; however I made it a point to try to keep the translation faithful (or at least in spirit) as best I could while also keeping within the game's character/memory space limit(which is very tight in some spots, especially the Monster Cards). I know there are people who (rightfully) treat accurate translation/localization as serious business so I feel it's important for me to be upfront about my work and I apologize in advance for any liberties that may have been taken as a result. ~Zenksren

UPDATE- Was made aware of a mistranslation in a Chapter 3 story cutscene where GamiGami calls Jilva "Ashi-onna", which is wordplay; "Ashi" here meaning "leg/foot" in reference to Jilva fighting mainly with kicks but also "Ashi" from "Ashisutanto" (assistant). To keep in spirit of the original wordplay I think either "footlady" or "footwoman" i.e. footman works here, YMMV though.

===============================================
             Technical Disclaimer
===============================================
-REAL HARDWARE WARNING: This game has AntiModChip Protection which means it won't play on PS1 consoles with a modchip. Please use another method (the swap trick, Tonyhax etc.) to boot the game instead.
-The final boss has voice dialogue between each form which cannot be subtitled. A text file containing rough translations of these lines (plus lines from a few small cutscenes) has been included with the patch for completion's sake.
-For those wondering why the initial chest message in the save bonus room still ends with Shift JIS full stops; removing them breaks the "Souvenirs found" message for some reason, so it was decided best to leave them intact.
-Unfortunately all instances of large font in cutscenes in the original game had to be removed due to not working with the game's English font. (https://imgur.com/i2TC1bu)
