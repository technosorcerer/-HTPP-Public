X-Men MA [USA] - Costume Mod - 1.0

What is it:
Mod that adds new costume to every single character.
Can be chosen in vs/arcade/survival mode by pressing R1.

How to install:
It is an xDelta patch that can be installed with any xDelta patcher.

It should be installed over first (data) bin track of your cd image.
Usually named "X-Men - Mutant Academy (USA) (Track 01).bin"

Versions:
0.1 - Cyclops Costume
0.2 - Magneto Costume
1.0 - All of the costumes, additional coding