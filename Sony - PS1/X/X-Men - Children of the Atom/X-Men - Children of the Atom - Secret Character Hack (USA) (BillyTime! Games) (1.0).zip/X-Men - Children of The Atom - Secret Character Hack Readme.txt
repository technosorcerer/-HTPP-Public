X-Men - Children of The Atom - Secret Character Hack
March 21st, 2021
BillyTime! Games
--------------------
This patch enables an easy way to select Akuma and allow you to play as
the Two endgame bosses, Juggernaut and Magneto

How To Use:
Press Left On Storm to play As Akuma
Press Right on Sentinel to play As Magneto
Press Right on Spiral to play As Juggernaut

Note:
--------------------
*Picking Akuma will increase CPU difficulty in single player.
*Compatible only with REDUMP set! 

How to Patch:
--------------------
1.Grab a copy ofX-Men - Children of the Atom (USA) (Track 01).bin (REDUMP)
2.Grab xdelta UI (https://romhackplaza.org/utilities/xdelta-ui-utility/)
3.Patch your rom with the corresponding file