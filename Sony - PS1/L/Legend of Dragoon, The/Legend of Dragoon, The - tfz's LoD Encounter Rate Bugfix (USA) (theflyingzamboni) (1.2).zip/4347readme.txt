###########################
#                         #
#  THE LEGEND OF DRAGOON  #
#  ENCOUNTER RATE BUGFIX  #
#    ~~~version 1.2~~~    #
#    by theflyingzamboni  #
#                         #
###########################

-----
About
-----
NOTE: This mod contains completely different code from NoOneee's mod of the same name, and should be considered a replacement for that one, due to bugs present in their bugfix.

This mod is intended as a new fix for the encounter rate bug in The Legend of Dragoon. When calculating the change in remaining distance moved until an encounter, the game (essentially) calculates the difference between the player's current x and y positions and their previous x and y positions, and then adds these together. If the resulting total value is greater than 9, the game applies a higher modifier to the encounter rate to adjust for the greater distance covered per step by running vs. walking.

Unfortunately, the programmers forgot to calculate the absolute values of the changes in x and y position. So if the player moves from x=0 to x=10, the result is (10 - 0 = 10) > 9, which is correct. But if the player moves from x=10 to x=0, the result is (0 - 10 = -10) < 9, which is not. Due to the orientation of the PSX's coordinate plane, this means that moving down/left produces the correct multiplier to encounter rate, while moving up/right causes encounter rate to be lower than intended.

Full credit goes to NoOneee for identifying this problem and the code that caused it. However, NoOneee's original bugfix contains multiple errors, and replaces the original issue with its reverse: Encounter rate is higher when moving up/right, and much, much lower than intended when moving down/left.

This mod uses a different algorithm written from scratch to resolve the original issue. Encounter rate is now similar regardless of direction/speed moved, as was intended in the original game. As of v1.2, there are 4 different versions included in the mod, for zero, half, normal, and double encounter rate. As a caveat, the code handling encounter rate on the world map is separate (and apparently unbugged), but currently has not yet been identified. Because of this, the zero, half, and double rate versions do not apply to the world map. This will hopefully be addressed in the future.

-------------
Compatibility
-------------
REQUIRES: LODModS Patcher v. 1.3 or greater

This mod targets SMAP.OV_. 

Installation is handled using the Legend of Dragoon Modding System, and therefore designed to be easily compatible with other LODModS mods, so long as they don't target the same bytes in the asset files in file_list.txt.

It should also be compatible with non_LODModS mods that meet the same conditions if installed last, though this is not tested, guaranteed, or recommended.

This mod requires the US version of the game (in disc order: SCUS-944.91, SCUS-945.84, SCUS-945.85, SCUS-945.86).

------------
Installation
------------
IMPORTANT: Patcher will create clean backups of the discs with a .orig extension. DO NOT delete these files.

Also IMPORTANT, but not quite as much: Only do step 3 once ALL desired mods have been set up, so the patcher doesn't have to be run multiple times.

1. If you have not already, download the current version of the LODModS Patcher (v1.3 or greater) from http://www.romhacking.net/utilities/1445/.
2. Move the unzipped LoD_Rate_Fix folder to the LODModS "mods" folder.
3. Run the patcher and follow all instructions. When asked which mods to install, include the number corresponding to ONE of the following: Encounter_Rate_Normal, Encounter_Rate_Half, or Encounter_Rate_Double. If more than one is selected, the last one installed will overwrite the others.
  
---------
Changelog
---------
Version 1.2 (03-03-2019)
	- Added a zero encounter rate patch version
	
Version 1.1 (02-13-2019)
	- Updated patches to use LODModS patcher v1.3

Version 1.0 (02-03-2019)
	- Initial release
	
--------------
Special Thanks
--------------
Special thanks to NoOneee for identifying the original bug.