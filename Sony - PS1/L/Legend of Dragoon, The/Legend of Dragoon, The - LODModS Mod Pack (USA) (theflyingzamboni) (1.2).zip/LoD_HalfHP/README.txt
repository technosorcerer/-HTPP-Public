###################################
#                                 #
#  THE LEGEND OF DRAGOON HALF HP  #
#      by Zychronix               #
#                                 #
#    ~~~LODModS Update v1.2~~~    #
#      by theflyingzamboni        #
#                                 #
###################################

-----
About
-----
This mod halves the maximum HP stat for all characters.

--------------------
LODModS Update Notes
--------------------
Full credit for the original concept and execution of this mod goes to Zychronix.

This update is primarily for changing the installation method to use my (theflyingzamboni's) Legend of Dragoon Modding System patcher, so that it can easily be installed alongside other mods using LODModS, to simplify the process for users.

Additionally, some slight errors in the values in the original mod were corrected in this release.

The original mod can be found here: http://www.romhacking.net/hacks/3985/

-------------
Compatibility
-------------
REQUIRES: LODModS Patcher v. 1.3 or greater

This mod targets S_ITEM.OV_. 

Installation is handled using the Legend of Dragoon Modding System, and therefore designed to be easily compatible with other LODModS mods, so long as they don't target the same bytes in the asset files in file_list.txt.

It should also be compatible with non_LODModS mods that meet the same conditions if installed last, though this is not tested, guaranteed, or recommended.

This mod requires the US version of the game (in disc order: SCUS-944.91, SCUS-945.84, SCUS-945.85, SCUS-945.86). 

------------
Installation
------------
IMPORTANT: Patcher will create clean backups of the discs with a .orig extension. DO NOT delete these files.

Also IMPORTANT, but not quite as much: Only do step 3 once ALL desired mods have been set up, so the patcher doesn't have to be run multiple times.

1. If you have not already, download the current version of the LODModS Patcher (v1.3 or greater) from http://www.romhacking.net/utilities/1445/.
2. Move the unzipped LoD_HalfHP folder to the LODModS "mods" folder.
3. Run the patcher and follow all instructions. When asked which mods to install, include the number corresponding to LoD_HalfHP.
  
---------
Changelog
---------
Version 1.2 (02-13-2019)
	- Updated patches to use LODModS patcher v1.3

Version 1.1 (01-30-2019)
	- Updated installation method to use LODModS patcher
	- Corrected slight errors in halved health values
	
Version 1.0 (05-01-2018)
	- Initial release
