###########################
#                         #
#  THE LEGEND OF DRAGOON  #
#    LODMoDS MOD PACK     #
#    ~~~version 1.2~~~    #
#    by theflyingzamboni  #
#                         #
###########################

-----
About
-----
The Legend of Dragoon Modding System (LODModS) is my attempt to make a single unified system for creating and applying mods to LOD. Currently, mods for the game tend to be installed in similar, but slightly different ways using batch files and separately downloaded dependencies. Further, there has been no coordinated attempt to maximize compatibility between mods by different modders. Finally, mods come in a couple different varieties: patches for game files, and scripts to swap game files from one version to another. LODModS acts as a single, simple-to-use replacement for all of these installation methods.

With the release of the LODModS patcher, I have collected and updated all currently available and complete mods for LoD (by various modders, with permission) to install using LODModS, making the process of installing multiple mods far simpler for players. In several cases, I have also expanded, updated, or replaced previous mods, as noted below.

-------------
Included Mods
-------------
(NOTE: All mods require the US version of the game.)

Author: theflyingzamboni
  ~~Full XP~~
    - Gives non-active party members the same XP as active party members, instead of half.
  ~~Encounter Rate Bugfix~~
	- Replaces NoOneee's bugged bugfix of the same name. 
	- Fixes the bug in the original game that lowers the encounter rate when running up/right.
  ~~Expanded Inventory~~
    - Increases maximum inventory capacity from 32 to 64.
	
Author: NoOneee
  ~~Undub~~ (Original: https://www.romhacking.net/hacks/3188/)
    - Replaces English voices with Japanese voices, sans certain Dragoon spells. 
	- Expanded by theflyingzamboni to include the FMVs, as the original only swapped battle voices. 
	- Requires Japanese version.
  ~~Rose's Blood~~ (Original: http://www.romhacking.net/hacks/3187/)
    - Replaces the "black goo" in the censored US Demon's Gate animation with the red-blood version from the Japanese game. 
	- Requires Japanese version.
	
Author: Zychronix
  ~~Half HP~~ (Original: http://www.romhacking.net/hacks/3985/)
	- Halves everyone's maximum HP totals. 
	- Updated by theflyingzamboni to correct errors in halved HP values.

-------------
Compatibility
-------------
REQUIRES: LODModS Patcher v. 1.3 or greater

All mods in this mod pack are compatible with each other, as well as theflyingzamboni's LoD Script Overhaul (currently in beta: http://www.romhacking.net/forum/index.php?topic=25929.0).

------------
Installation
------------
IMPORTANT: Patcher will create clean backups of the discs with a .orig extension. DO NOT delete these files.

Also IMPORTANT, but not quite as much: Only do step 3 once ALL desired mods have been set up, so the patcher doesn't have to be run multiple times.

1. If you have not already, download the current version of the LODModS Patcher (v1.3 or greater) from http://www.romhacking.net/utilities/1445/.
2. Move the unzipped LODModS Mod Pack folder to the LODModS "mods" folder.
3. Run the patcher and follow all instructions. When asked which mods to install, include the numbers corresponding to the desired mods from the Mod Pack (they will be listed individually).

---------
Changelog
---------
Version 1.2 (03-03-2019)
	- Added zero encounter rate version to Encounter Rate Bugfix
	
Version 1.1 (02-13-2019)
	- Added Expanded Inventory
	- Updated patches to use LODModS patcher v1.3
	
Version 1.0 (02-02-2019)
	- Initial release

-------
Credits
-------
Full credit goes to NoOneee and Zychronix for their hard work in creating the original mods collected here.
