#################################
#                               #
#  THE LEGEND OF DRAGOON UNDUB  #
#      by NoOneee               #
#                               #
#   ~~~LODModS Update v1.3~~~   #
#      by theflyingzamboni      #
#                               #
#################################

-----
About
-----
This mod replaces the majority (see update notes) of the English character and enemy battle voices and all of the FMV voices in the US version with audio from the Japanese version.

--------------------
LODModS Update Notes
--------------------
Full credit for the original concept and execution of this mod, as well as the work in identifying which files contain voice audio, goes to NoOneee.

This update is primarily for changing the installation method to use my (theflyingzamboni's) Legend of Dragoon Modding System patcher, so that it can easily be installed alongside other mods using LODModS, to simplify the process for users. 

Additionally, as this mod originally only targeted battle voices, I have extended it to also include file swaps for the pre-rendered FMV cutscenes. Unfortunately, there is still no way to replace LODXA00.XA, meaning some of the Dragoon spell voices will still be in English.

The original mod can be found here: https://www.romhacking.net/hacks/3188/

-------------
Compatibility
-------------
This mod targets individual subfiles within the DRGN0.BIN, as well as LODXA01.XA, LODXA02.XA, and several .IKI files (those with voice audio).

Installation is handled using the Legend of Dragoon Modding System, and therefore designed to be easily compatible with other LODModS mods, so long as they don't target the same asset files in file_list.txt.

It should also be compatible with non_LODModS mods that meet the same conditions if installed last, though this is not tested, guaranteed, or recommended.

This mod requires both the US version of the game (in disc order: SCUS_944.91, SCUS_945.84, SCUS_945.85, SCUS_945.86) and the Japanese version (SCPS_101.19, SCPS_101.20, SCPS_101.21, SCPS_101.22).

------------
Installation
------------ 
IMPORTANT: Patcher will create clean backups of the discs with a .orig extension. DO NOT delete these files.

Also IMPORTANT, but not quite as much: Only do step 3 once ALL desired mods have been set up, so the patcher doesn't have to be run multiple times.

1. If you have not already, download the current version of the LODModS Patcher (v1.3 or greater) from http://www.romhacking.net/utilities/1445/.
2. Move the unzipped LoD_Undub folder to the LODModS "mods" folder.
3. Run the patcher and follow all instructions. When asked which mods to install, include the number corresponding to LoD_Undub.
	- Be sure to specify directory and file name information for the Japanese game discs as well as the US ones, or the patcher will be unable to swap the files. If discs are dual-track, use Track 1. The patcher should select these automatically.

---------------
Original README
---------------
"LoD Battle Voice Undub" by NoOneee
V1.1 - 17 December 2016

This is an unofficial patch for The Legend of Dragoon game.

The patch replaces the English voices in the American discs with the Japanese ones.
This includes enemy and party member voices.
It requires both American and Japanese versions of the game. 

Known Issues:
  A few Dragoon voices aren't undubbed. Those are found in the LODXA00.BIN file,
  whose Japanese version is bigger than the American one, so it can't be easily 
  replaced.
   
  See the thread http://www.romhacking.net/forum/index.php/topic,23004.0.html
  for more details
  
Interesting Stuff:
  While making this patch I've come across some interesting audio files in the 
   game. You can listen them yourself extracting them with the included mrg_manager executable and 
   the PSound utility (http://www.romhacking.net/utilities/679/).
 
  Shana's Additions/Magic?
	This is by far the most interesting discovery. I found some files that could
	possibly be for some kind of additions or magic for Shana or Miranda.
	I assume the idea got scapped at some point of development.
	
	You can extract them with:
	mrg_manager\mrg_manager x DRGN0_USA.BIN shana-addictions 1939 1940 1941 1942 1943 1944
	
	Scan the extracted files in shana-addictions folder with PSound (Force 22050Hz Sample Rate in the Options)
	You can hear the following:
	
	-file01939.bin Dragon Needle
	-file01940.bin Silver Rain
	-file01941.bin ばくれつのや   (Bakuretsu No Ya i.e. 爆裂の矢？ Possible translation: Explosive Arrow)
	-file01942.bin あんこくのや 　 (Ankoku No Ya, i.e. 暗黒の矢？   Possible translation: Arrow of Darkness)
	-file01943.bin けっかい     (Kekkai, i.e. 決壊？　結界？      Possible translations: Outburst, barrier...)
	-file01944.bin Life Force 
	
   Other oddities:
	Extract files 5800 and 6041:
	mrg_manager\mrg_manager x DRGN0_USA.BIN odd-sounds 5800 6041
	
	Scan file05800.bin with PSound. Force 4000Hz Sample Rate in the Options.
	
    file05800 | 00018 (Force 4Hz Sample Rate in the Options)
	This audio sample is reversed, so you can't make sense of it in PSound.
	Convert it to WAV, and use some other program to reverse it.
	(You can use Audacity: Open the WAV file, go to Effects, Reverse and play it.)
	 You can hear "Sonotokiyamatoyoroshiku" (?)

	file05800 | 00019
	I couldn't make sense of this one.

	Scan file06041.bin with PSound. Force 11025Hz Sample Rate in the Options.
	file06041 | 00006
	This audio sample is also reversed, so you can't make sense of it in PSound.
	Convert it to WAV, and use some other program to reverse it.
	(You can use Audacity: Open the WAV file, go to Effects, Reverse and play it.)
	You can hear:
	"Death is the seed from wh..."
	This is taken from one of the Dead City Radio readings (https://en.wikipedia.org/wiki/Dead_City_Radio)
	You can hear the exact same thing here @0:21 https://www.youtube.com/watch?v=7kGzIfk_Siw


  
Changelog:
  Version 1.3 (LODModS Update) (01-29-19)
	- Added support for voices in FMV cutscenes
	- Replaced NoOneee's MRG Manager with LODModS patcher as installation method
	
  Version 1.1 (12-16-16)
    - Replaced psxmode2 with cdpatch(from cmdpack)
    - Now the files are extracted directly from the disc images.
	- Updated MRG Manager to v1.1
	- Added support for more Dragoon voices (LODXA00.BIN is still not being 
	 replaced)
  
  Version 1.0 (11-03-16)
    - Initial Release

Disclaimer:
  This patch is distributed without any warranty. 
  You are not allowed to redistribute the patched disc images or bundle the patch 
  with pirated copies of the game.