###################################
#                                 #
#  THE LEGEND OF DRAGOON FULL XP  #
#        ~~~version 1.2~~~        #
#      by theflyingzamboni        #
#                                 #
###################################

-----
About
-----
The Legend of Dragoon calculates XP for each combat-active party member as (XP / # surviving active party members). Normally, this amount is then halved for the party members who were not in combat. This mod removes that halving command, meaning that everyone now receives full XP.

-------------
Compatibility
-------------
REQUIRES: LODModS Patcher v. 1.3 or greater

This mod targets S_ITEM.OV_. 

Installation is handled using the Legend of Dragoon Modding System, and therefore designed to be easily compatible with other LODModS mods, so long as they don't target the same bytes in the asset files in file_list.txt.

It should also be compatible with non_LODModS mods that meet the same conditions if installed last, though this is not tested, guaranteed, or recommended.

This mod requires the US version of the game (in disc order: SCUS-944.91, SCUS-945.84, SCUS-945.85, SCUS-945.86).

------------
Installation
------------
IMPORTANT: Patcher will create clean backups of the discs with a .orig extension. DO NOT delete these files.

Also IMPORTANT, but not quite as much: Only do step 3 once ALL desired mods have been set up, so the patcher doesn't have to be run multiple times.

1. If you have not already, download the current version of the LODModS Patcher (v1.3 or greater) from http://www.romhacking.net/utilities/1445/.
2. Move the unzipped LoD_FullXP folder to the LODModS "mods" folder.
3. Run the patcher and follow all instructions. When asked which mods to install, include the number corresponding to LoD_FullXP.
  
---------
Changelog
---------
Version 1.2 (02-13-2019)
	- Updated patches to use LODModS patcher v1.3

Version 1.1 (01-29-2019)
	- Updated installation method to use LODModS patcher
	
Version 1.0 (07-07-2018)
	- Initial release