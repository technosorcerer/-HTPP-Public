########################################
#                                      #
#  THE LEGEND OF DRAGOON ROSE'S BLOOD  #
#      by NoOneee                      #
#                                      #
#       ~~~LODModS Update v1.3~~~      #
#      by theflyingzamboni             #
#                                      #
########################################

-----
About
-----
This mod changes the "black goo" in the Demon's Gate animation in the US version to Rose's blood, as it was in the Japanese version.

--------------------
LODModS Update Notes
--------------------
Full credit for the original concept and execution of this mod, as well as the work in identifying the appropriate file to target, goes to NoOneee.

This update is primarily for changing the installation method to use my (theflyingzamboni's) Legend of Dragoon Modding System patcher, so that it can easily be installed alongside other mods using LODModS, to simplify the process for users. I also made a small tweak to target a lower-level subfile, in order to reduce the mod's compatibility footprint.

The original mod can be found here: http://www.romhacking.net/hacks/3187/

-------------
Compatibility
-------------
This mod targets an individual asset within the DRGN21.BIN.

Installation is handled using the Legend of Dragoon Modding System, and therefore designed to be easily compatible with other LODModS mods, so long as they don't target the same bytes in the asset files in file_list.txt.

It should also be compatible with non_LODModS mods that meet the same conditions if installed last, though this is not tested, guaranteed, or recommended.

This mod requires both the US version of the game (in disc order: SCUS_944.91, SCUS_945.84, SCUS_945.85, SCUS_945.86) and the Japanese version (SCPS_101.19, SCPS_101.20, SCPS_101.21, SCPS_101.22).

------------
Installation
------------
IMPORTANT: Patcher will create clean backups of the discs with a .orig extension. DO NOT delete these files.

Also IMPORTANT, but not quite as much: Only do step 3 once ALL desired mods have been set up, so the patcher doesn't have to be run multiple times.

1. If you have not already, download the current version of the LODModS Patcher (v1.3 or greater) from http://www.romhacking.net/utilities/1445/.
2. Move the unzipped LoD_Roses_Blood folder to the LODModS "mods" folder.
3. Run the patcher and follow all instructions. When asked which mods to install, include the number corresponding to LoD_Roses_Blood.
	- Be sure to specify directory and file name information for the Japanese game discs as well as the US ones, or the patcher will be unable to swap the files. If discs are dual-track, use Track 1. The patcher should select these automatically.
  
---------------
Original README
---------------
"LoD Rose's Are Red" by NoOneee
V1.2 - 17 December 2016 

This is an unofficial patch for The Legend of Dragoon game.

The patch replaces the American battle animation of Rose's "Demon's Gate" 
attack with the Japanese one, which has her blood instead instead of a "black goo". 
It requires both American and Japanese versions of the game.

Changelog:
  Version 1.3 (LODModS Update) (01-29-19)
	- Added support for voices in FMV cutscenes
	- Replaced NoOneee's MRG Manager with LODModS patcher as installation method
	
  Version 1.2
    - Replaced psxmode2 with cdpatch(from cmdpack)
    - Now the files are extracted directly from the disc images.
	- Updated MRG Manager to v1.1
  
  Version 1.0
    - Initial Release

Disclaimer:
  This patch is distributed without any warranty. 
  You are not allowed to redistribute the patched disc images or bundle the patch 
  with pirated copies of the game.