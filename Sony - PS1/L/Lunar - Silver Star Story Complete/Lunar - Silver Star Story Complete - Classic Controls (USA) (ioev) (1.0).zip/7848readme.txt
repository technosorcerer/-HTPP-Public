  -=- Lunar Silver Star Story Complete (USA) - Classic Controls v1.0 -=-
          By ioev, email: zimmatic@gmail.com, discord: ioev#3061
                       Released on May 31st, 2023

A patch that tries to restore the original Japanese button layout along with a few
small tweaks.

Changes:
* Swap button layout to use O for action/confirm, X for cancel
* Quick save/fast cancel has been moved to Triangle
* Skip intro movies and start the game with the O button
* Advance text with either X or O

I should note that the quick save button (now Triangle) and using select to open the menu
were added by WD for the US release, and neither of them work very well on closer
inspection.  I left them in primarily because Triangle as quick save is still quite useful.


                     -=- Installation Instructions -=-

This patch is for the redump verified iso.
* Disc 1 - http://redump.org/disc/2676
* Disc 2 - http://redump.org/disc/2677

As well patches are included for the Unworked Designs version:
* Lunar - Silver Star Story Complete (Un-Worked Designs) (Disc 1) (Track 1).bin
  * CRC32: 2FA8F8FF
* Lunar - Silver Star Story Complete (Un-Worked Designs) (Disc 1) (Track 2).bin
  * CRC32: 1700407C


Patch your .bin with the included xdelta file, and make any necessary changes to
the cue file if the filename changes.

Please let me know if you run into any problems!


                          -=- Special Thanks -=-

A big thanks goes out to Supper of stargood translations for providing me with his Elemental
Gearbolt/Lunar de/recomp code!


                            -=- Tools used -=-

* PCSX-Redux (debugging and testing)
* jPSXdec (extracting the iso)
* HxD (for a little bit of everything)
* Some custom Ruby stuff for searching/patching
* psx-mode2 (inserting modified files back into the iso)
* MiSTer PSX Core (for final testing/playthrough)