This is a patch that nullifies modifications made to the USA release of Legend of Legaia, increasing EXP and Gold rewards to their originally intended values, as seen in both the preceding Japan release, as well as the subsequent Europe release.

----
- What changes were made to the USA release?
The USA release of Legend of Legaia has modifiers applied to the EXP and Gold rewards after battle, 75% and 50% respectively. Presumably this was done in an attempt to mitigate losses to rental stores, which aren't really a concern 24+ years later.

----
- Why not just play the Europe release?
The Europe release is letterboxed, and plays at a reduced fps of 50. The game's frame timings appear to be fixed, causing it to run at 5/6th speed. This increases your playtime by up to 20% (e.g. 40 hours increased to 48 hours). Forcing the Europe release to run at 60fps distorts the audio.

----
- How does one apply this patch?
Try using the Online ROM Patcher linked in ROMhacking.net's sidebar. Use your .bin file and the downloaded .ips file. (https://www.romhacking.net/patch/)

----
- Patching is too hard. Is there an alternative?
Try using these Gameshark style cheat codes, which when combined have the exact same effect as this patch.

Unhalve Gold: 8004F0E0 00000000

Un75% EXP: 8004F0C0 00000000

This also allows you to customize which aspects of the patch you want, potentially even during runtime.

----
- What license is this under?
Copyright (c) 2023, CrazyMLC

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.