Daffy Duck - The Marvin Missions Redux
July. 16th 2025
BillyTime! Games
--------------------
This is patch overhauls various aspects of Daffy Duck - The Marvin Missions. It comes with the following features.

*2X Damage from all player weapon sources.
*Jetpack fuel regen, regens at unknown interval in true looney toons fashion.
*Slower jetpack fuel consumption.
*No recoil from firing weapon
*Start with an extra continue
*SRAM System!

SRAM - How It Works:
--------------------

SAVING:
Game saves after every level past the first to prevent accidental overwrites.

LOADING:
Hold Select at the green Start/Options screen and start the game. Keep select held and your game should load where you left off.

Game Saves:
Money
Weaponry
Level Progress

Game does not save:
Nutty Attacks
Life Count
Continue Count


How to Patch:
--------------------
1.Grab a copy of Daffy Duck - The Marvin Missions (USA).sfc (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file