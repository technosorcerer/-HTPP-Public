Dai-4-ji Super Robot Taisen - Touhou Atrangers

"SRW4_TouhouAtrangers.ips"

This is the IPS patch for SNES edition "Dai-4-ji Super Robot Taisen (Japan)".
Please apply to late ROM (V1.1) without header.

-------------------- Changes --------------------
[Change the main characters]
- Ben Raycock (THE☆ANIMAGE)
- Ender Wiggin (Ender's game)
- Popo Twinkle (Twinkle★Popo)
- Mark-Curran (G-SAVIOUR)
- Reimu Hakurei (Touhou Project)
- Marisa Kirisame (Touhou Project)
- Ripple Star (Kirby 64)
- Mau Hanahata (Name change only)

[Change NPC]
- Gilliam to Meta Knight (Kirby's Adventure)
- Changed Chack Keith to Harrison Maddin
  (Adjusted pilot abilities and conversation data to match these changes)
- Nee Gielen changed to Cusco Al.
- Lance Gielen changed to LeRoy Gilliam.
- Hathaway changed to Kikka.
- Change Quess Paraya to Sayla Mass.

[Change the Robot]
- Gespenst to Gaspal (THE☆ANIMAGE)
- Gespenst-mkII to Somuro (THE☆ANIMAGE)
- Guntank to GM Camouf (Mobile Suit Gundam MS IGLOO 603)
- ZAKU II CUSTOM to ZUDAH (Mobile Suit Gundam MS IGLOO 603)
- NEMO to SM (Tony Takezaki presents GUNDAM manga)
- ZWAUTH to ATLANGER (Combined ATLANGER)
- ν Gundam to Hi-ν Gundam (Mobile Suit Gundam Char's Counter Attack - Beltorchika's Children)
- Change F91 to Harrison spec (Blue)
- Gundam to Gungal (Mobile Force)
- GP-01Fb to G-Saviour (G-SAVIOUR)

[Change Level]
- Reduction of level-up criteria (required experience value), SP consumption, remodeling costs, etc.
- Fin funnel enhancement (Hi-ν Gundam Weapon)
- Increased funds acquired, strengthening of allied pilots, adjustment of unit performance, etc.
- Mega bazooka launcher added to Z Gundam.
- Change of armament of ATLANGER (Aura Sword to Broken Cutter, Aura Slash to Cyclone Beam)
- Changed SIRBINE's Aura sword using Unused anime data (changed the weapon name to "Servant")
- Extended pilot transfer range for Gespenst, Huckebein and Grungast.

[Other changes]
- Face graphic is improvement (Roux Louka, Bundle, Hamon, Challia Bull, Tyitti, Zezeenan, Astonaige, Four, Safine, Plesia)
- Mora changed to Ommo (Characters from Gundam)
- Refine Dianan A, Valsione R and Wizoll Custom to cutie.
- Change facial images of Secretary to Lieutenant General Cowen, doctors and legislators.
- Bright changed to the bearded face from the novel version.

* Graphic and text data due to the above changes

[Update Jun-9, 2024]
- Am's spirit command "Reconnaissance" changed to "Disturb"
- Keiko Kamikita's spirit command "Reconnaissance (Lv.1)" has been changed to "Iron Wall (Lv.28)".
- Adjusted the spirit commands of the Combattler team.
- Sheila and Ele, Grand Garan and Goraon can now be switched with Aura Battler types. Special skill "Holy Warrior" added (Sheila Lv.55, Ele Lv.53).
- Repair Device" added to Brueger, with the following adjustments.
 Although the graphics give the impression that the Brueger is smaller than the Gulber, the official setting in the animation states that the Brueger is a heavy support fighter with an overall length of 10.8 m, while the Gulber FXII is a small fighter with an overall length of 5.5 m.
 Despite this, the specifications were almost the same, and not only that, the Brueger was slightly inferior to the Gulber in HP.
 So The performance was adjusted so that, although slightly inferior to the Gulber in terms of mobility, it slightly exceeded it in terms of armour and HP.
- The "Foot Cutter" of Deimos was changed to a "Continuous Thrust" to be more like a karate robot.
- Zebrze-Hlushwa was changed to Dadidu-Donpen (face and text).
- Slat Sword added to Gulber FXII (requires 'bottom power').
- The Vulcan of the Nu Gundam was changed to the New Hyper Hammer.
- Changed Getter Leather to Getter Punch and Spin Cutter to Getter Kick.

--------------------------------------------------

P.S.
"SRW4_TouhouAtrangers_OnlyGraphics.ips" is a patch that only graphics apply.
For example, use it when using it together with a translation patch.
