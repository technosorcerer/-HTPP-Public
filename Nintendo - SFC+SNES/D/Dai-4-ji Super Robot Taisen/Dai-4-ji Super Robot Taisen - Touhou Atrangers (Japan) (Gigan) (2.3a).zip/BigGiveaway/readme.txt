SRW4 - As gentle spring breeze

"srw4_tsp_haru_64.ips"

This is the IPS patch for SNES edition "Dai-4-ji Super Robot Taisen (Japan)".
Please apply to late ROM (V1.1) without header.

[Change Scenario]
This hack builds on the work of great ancestors.
It's a Harukaze patch that's an addition to scenario change hacks called the Titans War patch.
Moreover The following hacks have been added to these.

"srw4_tsp_haru_64.ips" contains all the changes.

[Change Hero]
- Renanjess Starlord to Ryusei Date (Neo Super Robot Wars)
- Irmgard Kazahara to Axel Almar (Super Robot Wars A)
- Hektor Madison to Charles Elwood Yeager (The Right Stuff)
- Erwin Dorsten to Riche Griswell (Super Robot Wars 64)
- Patorisia Hackman to Kusuha Mizuha (Super Robot Wars Alpha)
- Grace Urijin to Lamia Loveless (Super Robot Wars A)
- Mina Likering to Mau Hanabatake (Only Name)
- Lynn Mao to Serane Menens (Super Robot Wars 64)

[Change NPC]
- Gilliam Yeager to Ender Wiggin (Ender's game)

[Change Robot]
- Gespent to Svanhild (Super Robot Wars 64)
- Gespenst-mk2 to Sigloon (Super Robot Wars 64)
- ZAKU II CUSTOM to ZUDAH F (Mobile Suit Gundam MS IGLOO 603)
- NEMO to SM (Tony Takezaki presents GUNDAM manga)
- ZWAUTH to ATLANGER (Combined ATLANGER)

[Change Level]
- Reduction of level-up criteria (required experience value), SP consumption, remodeling costs, etc.
  By This even beginners can enjoy playing.
- Others, such as strengthening allied pilots, weakening boss classes, etc.

[Other trivial changes]
- Part of the prologue changed to match the Titans War scenario
- Jerid's face graphic is more handsome
- Precia's face graphic is more cuteness
- Roux Louka's face graphic is more cuteness
- Bundle's face graphic is more beautiful
- Hamon's face graphic is more beautiful
- Challia Bull's face graphic is more cool
- Tyitti's face graphic is more beautiful
- Zezeenan's face graphic is more villainous
- Astonaige's face graphic is more slimmer
- Four's face graphic is more slimmer

* The large amount of graphic and text data associated with the above has also changed.

About Titans War

The Titans War is a bold reorganization of the scenario of the 4th Super Robot Wars, and is a parallax story with Titans as the main character.
You can enjoy the play experience from the standpoint of a weak and realistic combat elite unit, not a hero group like LONDO BELL.
This hack will give Super Robot fans an invaluable enjoyment.
Thank you to the great creator.
