Dai-4-ji Super Robot Taisen - Touhou Atrangers

"SRW4_TouhouAtrangers.ips"

This is the IPS patch for SNES edition "Dai-4-ji Super Robot Taisen (Japan)".
Please apply to late ROM (V1.1) without header.

-------------------- Changes --------------------
[Change the main characters]
- Ben Raycock (THE☆ANIMAGE)
- Ender Wiggin (Ender's game)
- Popo Twinkle (Twinkle★Popo)
- Mark-Curran (G-SAVIOUR)
- Reimu Hakurei (Touhou Project)
- Marisa Kirisame (Touhou Project)
- Ripple Star (Kirby 64)
- Mau Hanahata (Name change only)

[Change NPC]
- Gilliam to Meta Knight (Kirby's Adventure)
- Changed Chack Keith to Harrison Maddin
  (Adjusted pilot abilities and conversation data to match these changes)

[Change the Robot]
- Gespenst to Gaspal (THE☆ANIMAGE)
- Gespenst-mkII to Somuro (THE☆ANIMAGE)
- Guntank to GM Camouf (Mobile Suit Gundam MS IGLOO 603)
- ZAKU II CUSTOM to ZUDAH (Mobile Suit Gundam MS IGLOO 603)
- NEMO to SM (Tony Takezaki presents GUNDAM manga)
- ZWAUTH to ATLANGER (Combined ATLANGER)
- ν Gundam to Hi-ν Gundam (Mobile Suit Gundam Char's Counter Attack - Beltorchika's Children)
- Change F91 to Harrison spec (Blue)
- Gundam to Gungal (Mobile Force)
- GP-01Fb to G-Saviour (G-SAVIOUR)

[Change Level]
- Reduction of level-up criteria (required experience value), SP consumption, remodeling costs, etc.
- Fin funnel enhancement (Hi-ν Gundam Weapon)
- Increased funds acquired, strengthening of allied pilots, adjustment of unit performance, etc.
- Mega bazooka launcher added to Z Gundam.
- Change of armament of ATLANGER (Aura Sword to Broken Cutter, Aura Slash to Cyclone Beam)
- Changed SIRBINE's Aura sword using Unused anime data (changed the weapon name to "Servant")
- Extended pilot transfer range for Gespenst, Huckebein and Grungast.

[Other changes]
- Face graphic is improvement
  (Roux Louka, Bundle, Hamon, Challia Bull, Tyitti, Zezeenan, Astonaige, Four, Precia, Saphine, Secretary to Lieutenant General Cowen)
- Mora changed to Ommo (Characters from Gundam)
- Refine Dianan A to cutie

* Graphic and text data due to the above changes

[Update May-21, 2024]
- Nee Gielen changed to Cusco Al.
- Lance Gielen changed to LeRoy Gilliam.
- Bright changed to the bearded face from the novel version.
- Hathaway changed to Kikka.
- Change Quess Paraya to Sayla Mass.
- Refined images of Weasol-Kai.
- Rose Cutter of Weasol-Kai changed to Rose Whip (range 1->2).
- Shin Getter 2 and 3's EN/HP recovery rate increased.

--------------------------------------------------

P.S.
"SRW4_TouhouAtrangers_OnlyGraphics.ips" is a patch that only graphics apply.
For example, use it when using it together with a translation patch.
