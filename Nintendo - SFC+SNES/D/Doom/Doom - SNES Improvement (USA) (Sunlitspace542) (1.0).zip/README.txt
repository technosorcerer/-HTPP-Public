Doom SNES Improvement Patch by Sunlit
Version 1.0

About:
Any episode can now be started on any difficulty, as in the Japanese release.
Adds circlestrafing, modified from a patch by xttl from https://www.romhacking.net/hacks/5272/
Fixes the Hyperkin Hyper Click mouse not working, and fixes being unable to exit intermission screens with the mouse.
Insert mouse into controller port 1.

Setup:

Apply the doom_msu1.bps patch to a USA Doom SNES ROM.

Start the game and enjoy!

Credits:
Randy Linden - Programming Doom for SNES and releasing the source code, making this hack possible
Sunlit - SNES mouse improvements, Hyperkin mouse fix
Monika - Programming assistance and moral support