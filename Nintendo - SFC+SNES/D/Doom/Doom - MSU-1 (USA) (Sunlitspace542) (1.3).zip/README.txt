DOOM SNES MSU-1 by Sunlit
Version 1.3

SETUP

Apply the doom_msu1.bps patch to a USA Doom SNES ROM. Make sure the patched ROM is named doom_msu1.sfc.

To build the PCM set, download this FLAC set from
https://sc55.duke4.net/flac/doom_sc55_flac.zip
and extract the contents of the MUSIC directory in that zip into this one.
Run msupcm.exe to generate the PCM files.
Once it has finished, you can delete the FLAC files.

At the end, you should have:
- doom_msu1.bps - this can be deleted
- doom_msu1.msu
- doom_msu1.sfc
- 21 PCM audio files with the prefix 'doom_msu1-'
- tracks.json - this can be deleted
- msupcm.exe - this can be deleted
- this readme - this can be deleted

Start the game and enjoy!

Tracklist:
(this follows the track order of the original PC version, so some levels reuse other levels' music)

Misc:
1 - Intro / Title Screen
2 - Intermission / E2M3

Episode I: Knee-Deep in the Dead
11 - E1M1
12 - E1M2 / Publisher logo
13 - E1M3
14 - E1M4
15 - E1M5
16 - E1M6
17 - E1M7
18 - E1M8
19 - E1M9

Episode II: The Shores of Hell
21 - E2M1
22 - E2M2
24 - E2M4
26 - E2M6
27 - E2M7
28 - E2M8
29 - E2M9

Episode III: Inferno
32 - E3M2
33 - E3M3
38 - E3M8

Other notes:
Any episode can now be started on any difficulty, as in the Japanese release.
Circlestrafing was added, modified from a patch by xttl from https://www.romhacking.net/hacks/5272/
msupcm.exe (msupcm++ by qwertymodo) from https://github.com/qwertymodo/msupcmplusplus/releases/latest

Credits:
Randy Linden - Programming Doom for SNES and releasing the source code, making this hack possible
Sunlit - MSU-1 implementation
Monika - Programming assistance and moral support
CrispyBuns - Real hardware testing
xttl - Original circlestrafing code
qwertymodo - MSUPCM++ PCM audio creation tool (https://github.com/qwertymodo/msupcmplusplus/)