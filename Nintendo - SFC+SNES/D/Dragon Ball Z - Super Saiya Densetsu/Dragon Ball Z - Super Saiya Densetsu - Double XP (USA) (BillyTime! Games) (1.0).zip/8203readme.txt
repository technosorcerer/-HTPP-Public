Dragon Ball Z - Super Saiya Densetsu - Double XP
Nov. 7th 2023
BillyTime! Games
--------------------
This is a fun and simple patch designed for Dragon Ball Z - Super Saiya Densetsu that doubles the amount of experience earned after every fight.

How to Patch:
--------------------
1.Grab a copy of Dragon Ball Z - Super Saiya Densetsu (Japan) (Rev 1).sfc
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file