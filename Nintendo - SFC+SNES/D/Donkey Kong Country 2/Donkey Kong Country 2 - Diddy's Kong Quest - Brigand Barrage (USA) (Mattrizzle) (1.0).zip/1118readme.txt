***********************************************************
*  Donkey Kong Country 2: Brigand Barrage, by Mattrizzle  *
***********************************************************

I. Introduction/Overview
------------------------
Donkey Kong Country 2: Brigand Barrage is a hack which transforms the game into a boss rush.
Play against all 7 of the game's bosses consecutively. Try to avoid getting hit and aim for the fastest time possible!

Thanks for downloading!

--Mattrizzle


II. Releases
------------
January 1, 2013:
    * Bug fix: In All Bosses mode, the new record sound would play in the results screen if a player got a game over
      against a boss with no record.
	
December 2, 2012:
    * Bug fix: Completing a game with 99:59.99 on the timer would freeze the game at a black screen.

August 11, 2012: 
    * The K. Rool Duel post-battle cutscene now differs depending on whether you are playing it as a single battle or as
      part of All Bosses mode.  This makes it consistent with all other battles in the hack.
    * Bug fix: In K. Rool Duel, if you timed a jump just right before the start of the post-battle cutscene, the active
      Kong would be suspended in midair for the duration of the cutscene. This bug exists in the original game as well.

August 3, 2012:  
    * Bug fix: In 2P Team mode, if one player was hit and the other player pressed Y to take control, the camera
      and other objects would remain frozen, leaving the player no other option but to quit or restart the game.

August 3, 2012:  Initial version released


III. How to Patch
-----------------
These instructions assume that you know how to obtain ROMs and use an SNES emulator. If you don't, just use Google!

1. Use an IPS patcher to patch DKC2- Brigand Barrage.ips to a HEADERLESS Donkey Kong Country 2 (U)(1.0) ROM  (CRC32: 006364DB).
    * If you don't have a patching program, SNEStuff can be found at the following link:

      http://www.romhacking.net/utilities/841/

      SNEStuff is able to correctly apply patches made with unheadered ROMs to headered ROMs, and vice-versa.
      It even makes backups if you tell it to, which is good in case you accidentally apply the incorrect patch to a ROM.

2. The hack is now ready to be played in an emulator. Enjoy!


IV. Instructions
----------------
Only changes from the original game are covered here.

    1. Title Screen
    ---------------
        A. Controls:
        ------------
        Start/A/B/Y: Go to Options menu (See 4.)
        X: View saved records (Best Bouts) (See 5.)
        Select: Open "Delete Records" prompt (See 6.)


    2. Options Menu
    ---------------
        A. Controls:
        ------------
        Up/Down: Select an option
        Left/Right: Change the setting of the selected option
        Start/A/B/Y: Begin the boss rush (See 3.)
        X: Return to Title Screen

        B. Options
        ----------
        * Game Play Mode: Choose whether you would like to play the game alone (1P), or with a human teammate (2P Team).
          If you choose the latter, Diddy will be player 1 and Dixie will be player 2.
        * Kong Select: Select whether Diddy or Dixie will be active at the start of the game,
          and (for one-player mode) if your companion will be with you. Go it alone as Diddy for maximum difficulty!
        * Team Color: Choose from 8 color sets for your character(s).
        * Boss Select: Choose whether you would like to play against all seven bosses in succession ("All"), or face an
          individual boss (represented by an icon).
        * Timer Display: Pick whether you want the timer visible (On) or hidden (Off).


    3. Playing the Game
    -------------------
    Beat those bad guys as fast as you can without getting hurt!
        
        A. Controls:
        ------------
        * Start, then L: Go back to the options menu (Options)
        * Start, then R: Start a new game with the current settings (Restart)
        * Start, then Select: Quit the game (Quit)
        
        B. Notes:
        ---------
        * There is no lives counter. If you lose a single life, it's game over!
        * For each battle, the timer runs from the instant you gain control of the Kongs until you either land the last
          hit on the boss, or die.
        * In 2P Team mode, the timer is also paused when one player is hit, and the game is waiting for the other player
          to take control.
        * After beating the last boss or getting a Game Over, you will be taken to the Results screen (See 4.).
        * New records are earned by either getting a faster time, or (if the time is the same as the record time) taking fewer hits.


    4. Results Screen
    -----------------
    So, how well did you do? This screen will show you, whether you win or lose. This screen will only appear if you have beaten 
    at least one boss.  Press A, B, X, Y, or Start to proceed to the Best Bouts screen (See 5.).

        A. Legend:
        ----------
        * Boss icons: Designate the time you spent in each of the boss battles. If battling a single boss, the boss level's name
          will appear instead.
            - If you lost to a particular boss, GAME OVER will appear next to that boss's icon.
              All times beyond this will appear as dashes.
            - If the time and hits taken for a certain boss are displayed in blue, you have earned a new record.
        * Bandage icon: Shows how many times you were hit when fighting a boss.
        * Kong icons: Represent the Kong Select settings chosen at the start.
        * 1P/2P icons: Shows which Game Play Mode was selected.


    5. Best Bouts
    -------------
    This screen shows your best times for each boss, as well as your best total time for all bosses. Icons in this screen have
    the same meaning as those in the Results Screen.

    If this screen was accessed from the Title Screen, pressing A, B, X, Y, or Start will return you to the Title Screen (See 1.).
    If it was reached after viewing the Results screen or getting a Game Over, pressing these buttons will bring you to an
    additional menu with the following options:

        * Options: Go back to the Options menu (See 2.)
        * Retry: Start a new game with the current settings (See 3.)
        * Quit: Return to the intro sequence


    6. Delete Records
    -----------------
    From this screen, you can clear all records from the game's battery backed memory. The instructions are displayed on-screen,
    and are pretty straightforward.

    **WARNING**: Pressing L at this screen will delete your records without asking for additional confirmation!!


V. Distribution Rules
---------------------
* Do not claim this work as your own.
* Do not distribute this hack as a ROM file, only patch files such as IPS, PPF, or UPS should be shared.
* Include the unaltered readme file with the hack when distributing it.


VI. Known Issues
----------------
None.

This demo has been tested on bsnes v0.065 debugger, Snes9x v1.53, and ZSNES v1.51.
Please let me know if you do experience any problems.


VII. Special Thanks To
----------------------
* Nintendo, Rare Ltd.: for creating the original games
* The Kirby: for suggesting the Boss Select option
* B.B.Link: for suggesting the 2-Player Team Mode option
* Phyreburnz: for suggesting Dixie Kong's sixth color scheme
* JASC Software: Paint Shop Pro
* YY: YY-CHR
* Christian Maas: XVI32
* creaothceann: vSNES
* FuSoYa: Lunar Address, Lunar IPS
* byuu: bsnes debugger
* ZSNES dev team
* SNES9x dev team
* Juggling Joker: TileCounter
* Neviksti: pcx2snes
* People of DKC Atlas Forum, SMW Central, Jul, and YouTube: for their support


VIII. Contact Info
------------------
I can be reached at:
* m.grassman87@gmail.com
* DKC Atlas Forum (www.dkc-atlas.com/forum/)
* Jul (jul.rustedlogic.net)
* YouTube (username Mattress87)
* SMW Central (www.smwcentral.net)

(c) 2012 Mattrizzle, Original Game (c) 1995 Nintendo/Rare Ltd.