Donkey Kong Country 2 Diddy's Kong Quest Expert Edition

====== Disclaimer ======
This hack is not affiliated with Nintendo or Rareware.

This hack is not affiliated with Donkey Kong Country - Expert Edition (a rom hack for the first game by _Q_)
	I used the same name because this hack does the same, but for DKC2 instead of DKC
	Check it out: https://romhackplaza.org/romhacks/donkey-kong-country-expert-edition-snes/

====== Description ======
This is a romhack of Donkey Kong Country 2: Diddy's Kong Quest, designed to provide a higher challenge for experienced players.

The Expert Edition is based on the "TUFST" cheat code of Donkey Kong Country 3.

- All Flying DK Barrels have been removed
- All Grounded DK Barrels have been replaced by wooden boxes
- All Star Barrels have been replaced by Banana Bunches
- All wooden chests holding a DK Barrel now hold one banana
- All invisible DK barrels have been replaced by invisible one ups
- You will always start levels with 2 kongs
- The bonus level and Boss arena are left unchanged from the base game, you may find DK Barrels there

Due to the limitation of my hacking capabilities, there are 3 things I could not do:

- In Lockjaw's Locker, removing the DK Barrel near the middle of the level makes the floatsam invisible. The quick fix was to move the DK Barrel in the wall where it is not reacheable.
- In Red-Hot Ride, there is a DK Barrel on an air balloon, replacing it with a wooden box was not possible as the wooden box falls through the balloon. I put the wooden box on solid ground instead.
- Opening the last room of Target Terror crashes the editor, therefore I couldn't replace the hidden DK Barrel with a hidden one up.

This romhack is in stereo mode by default.

====== Patching Instructions ======

Get a Donkey Kong Country 2: Diddy's Kong Quest ROM.
The patch is only compatible with the US version 1.0 of DKC2: "Donkey Kong Country 2 - Diddy's Kong Quest (U) (V1.0).smc"

No-Intro Data:
Donkey Kong Country 2 - Diddy's Kong Quest (USA) (En,Fr)
 MD5:		98458530599b9dff8a7414a7f20b777a
 SHA-1:		3ec2035962918b5523d8b4745406f46f2a739b8d
 SHA-256:	35421a9af9dd011b40b91f792192af9f99c93201d8d394026bdfb42cbf2d8633
 

Download a patching tool such as FLIPS: https://www.smwcentral.net/?p=section&a=details&id=11474

Apply the provided BPS patch file to your ROM using the patching tool. Because the patch is a bps file, it will tell you if the rom is not compatible.

Load the patched ROM in an emulator or physical hardware.

====== Credits ======
Author: Gion

Playtesting:
- Chronoverse
- Raybloo
- MyB

Tool used:
- Super Gorilla Maker 2 by Kaarage

Special Thanks:
- _Q_ for making Donkey Kong Country - Expert Edition
- Rare for creating the original game.
- ioev for the default stereo romhack: https://www.romhacking.net/hacks/5621

====== Permissions ======
Anyone is free to use, modify, and distribute this patch. Enjoy and share it as you like!


