Please take your time to read these few important things in here!

#####################################################################
Recommended Emulator:

Snes9x v1.53 or any version of BizHawk

Avoid using any zsnes Emulator if possible as there can be
potential issues with the game. (Turning barrels, Boxes not opening)

#####################################################################
Patching:

1) Open up the attached program named "Lunar IPS".
2) Select "Apply IPS Patch".
3) You'll be prompted to select a Patch file. 
   You're going to select the file named "DKC2 Unveiled"
4) Now you will need to select the file to patch.
   You're going to select your Donkey Kong Country 2 NTSC-U 1.0 ROM
5) You're done! The file is patched and you can rename it to 
   DKC2 Unveiled if you feel like it!

#####################################################################
Important Notes: 

The amount of bonuses per level is always the same as in vanilla.
Wrinkly and Cranky give new hints on secrets.
Don't be afraid to visit them!

Hold down the L , R and/or Select Button in any combination you like,
while loading up a new or old savefile and you'll look really dapper!

#####################################################################
Need Help with anything?

Contact me on Twitch or join the Unveiled Discord:

www.Twitch.tv/emptysys (Discord Link in Twitch Bio)