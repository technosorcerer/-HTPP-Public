DKC2 Rattle Royale v1.04 (Sequel to Rambi's Revenge, but over 70 times better).

Download Link - https://www.mediafire.com/file/f3roxxgymkzzupz/Rattle_Royale.zip/file

Youtube Playlist - https://www.youtube.com/playlist?list=PLEmOV78AqBIFKRbtvMUO4dHwRld_iQCWI

Rambi's Revenge - https://www.youtube.com/playlist?list=PLEmOV78AqBIHDb79eRCtIinZ5gf79SWxZ
Download in description

---------------------------------------------------------------------

Patching

1) Open up the attached program named "Lunar IPS".
2) Select "Apply IPS Patch".
3) You'll be prompted to select a Patch file. 
   You're going to select the file named "RattleRoyale"
4) Now you will need to select the file to patch.
   You're going to select your Donkey Kong Country 2 NTSC-U 1.0 ROM
   You'll have to find your own.
   Just make sure it's version U1.0
5) That's all! The file is patched and you can rename it to 
   Rattle Royale!

It looks like there apps available for doing this on Android or in the browser as well.

---------------------------------------------------------------------


----ABOUT----

Every level uses Rattly and takes advantage of his tech, with
some unique and never before seen gimmicks. 

It's based on vanilla, but changes are made to make it more fun.

The DK coins have been rehidden, and some bonuses moved or rearraged as needed.

A "W" or "C" in bananans means you might need WRINKLY or CRANKY's help.

The maximum is 100%. Use WRINKLY and CRANKY for help, but I provided some additional 
video links here, if you're having trouble.

WRINKLY typically helps with Main level tech and CRANKY helps more
with Bonus tech and DK coins.


----Rattly Tech Videos----

World 5 Wrinkly hint help video(Tech spoiler)
https://www.youtube.com/watch?v=N3WWkqXzGhs

Other World 5 Wrinkly hint help video(Level and tech spoiler)
https://www.youtube.com/watch?v=qQjEtMS9WrE

----Dev codes----

Dev Exit
Exit any level, even without beating. Pause and press Right + Y, Left + A, Up + B, Down + X
https://youtu.be/8COQFTuKre8?si=EU-MpjN1v76yhOcO

Funky Skip
Return to the main map without Funky by HOLDING L+Select and press
RIGHT, LEFT, UP, DOWN; Twice
WARNING: Can crash in World 4 so don't try it there if you haven't saved.
https://www.youtube.com/watch?v=7D1Zf-pqcgk


---------------------------------------------------------------------

-Created by KFin45
Find me on Twitch/Discord/Youtube
-Extra coding by BlueImp
-Play testing by a10cj

Inspirations from DKC2 IXKZ, Unveiled, AneSKD2,
MaRyu SDK2/Ultimate, Diddy's Punishment

Special Thanks to the 
DKC speedrun commmunity
and DKC Atlas Discord
Infinite teamthrow is banned in speedruns

Practice Hack w/ save file - https://www.mediafire.com/file/ebwrb356p305lr7/RattleRoyalePrac.zip/file


