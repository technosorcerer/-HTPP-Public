"Dark Half"
Traducción al Español Ver. 1.0 (15/03/2024)
por Max1323 (Traducciones Max1323).
Basada en la gran traducción de Aeon Genesis y Eien Ni Hen.
---------------------------------------------------
Descripción:
Rukyu controlaba la Gran Oscuridad y con el tiempo se lo conocio
como el Caído. Su poder era absoluto y temido por el hombre, que
yacía postrado ante su poder.
Pero, surgió una persona que lograría cambiar el
destino de la humanidad, la Santa Rhoda. Ella y los 6 Paladines
pelearon contra el Caído y lograron sellarlo. Atrás quedaron los
días en que la humanidad vivia con miedo, este fue el amanecer
de la nueva era.
Así empieza la Leyenda del Caído.

Desarrollado: Westone
Publicado:    Enix
Lanzamiento:  25/03/1994 (JAP)
---------------------------------------------------
Acerca del proyecto:
-La mayoría de los textos están traducidos. Se agregaron
los caracteres españoles.

-Se traducieron algunos gráficos.
Los demás gráficos como "PUSH START BUTTON" o los
créditos están comprimidos.

-Gracias al parche portugués de PSGM. Pude ver que al mover 
el puntero de Convertir Fatia me traía un error por eso
al ver que en su traducción su solución fue usar los
gráficos para "Convertir" y "Cancelar" era la solución.
También use su estilo para las Opciones.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS (PC)
Utilizar UniPatcher (Android)
Utilizar Rom Patcher JS (Parcheador Online):
https://www.romhacking.net/patch/

Archivo IPS
Dark Half (Japan).sfc
File Size     3.00 MB
File MD5      55108013F875DB3B39DA04B8F58489AB        
File SHA-1    70F4E9C39EEEFC00DFB35E77C604372B305AAE03
File CRC32    7B9793B1