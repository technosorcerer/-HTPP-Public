****************************************************
*  Donkey Kong Country: Boss Blitz, by Mattrizzle  *
****************************************************

I. Introduction/Overview
------------------------
As the title suggests, Donkey Kong Country: Boss Blitz is a modification of DKC which transforms the game into a boss rush mode.
Play against all 7 of the game's bosses consecutively. Try to avoid getting hit and aim for the fastest time possible!

Thanks for downloading!

--Mattrizzle

II. Releases
------------
July 9, 2017:  Major revision (1.5) released
    * All features that were previously exclusive to DKC2: Brigand Barrage have now been backported
        > Option settings and record times are now saved to battery-backed memory 
        > Options Menu changes:
            - Added "Game Play Mode" option: The game can now be played with a second player as a team (2P Team)
            - The "Active Kong" and "Max. No. of Kongs" options have been merged into a single "Kong Select" option; which displays head icons of the Kongs
            - Added a "Boss Select" option: Bosses can now be faced individually instead of all in one sitting
            - The "Team Color" options are now labelled with numbers instead of having unique names. Also, the sixth and seventh color schemes were altered to be representative of the teams in DKC2 and 3 respectively.
            - "Stopwatch Display" has been renamed "Timer Display"
		> During gameplay, pausing now displays a menu with two options in addition to exiting the game: returning to the options menu, and restarting the
		boss rush. Similar options also appear when the game ends.
		> The timer's logic was altered so that it doesn't begin ticking until you have control of the Kong(s)
	* Demos of each boss play after waiting on the title screen for a while
	* Several animations have been altered to make use of unused sprites
	* Fixed the sound Dumb Drum makes when bouncing off the ground
	* Remapped the colors used on the inside of the Kongs' mouths so they look less weird when certain color combinations are used.
	
August 16, 2011:  Initial version (1.0) released

III. How to Patch
----------------
These instructions assume that you know how to obtain ROMs and use an SNES emulator. If you don't, just use Google!

1. Use Lunar IPS to patch dkc_boss_blitz.ips to a HEADERLESS Donkey Kong Country (U)(R1.0) ROM  (CRC32: C946DCA0).
	* Lunar IPS can be found at the following link: http://fusoya.eludevisibility.org/lips/index.html
	* If the ROM is headerless, its size should be 4,096 KB. If not, you'll need to remove the header
	  with NSRT, which can be downloaded at one of the following links, depending on your OS:
		Windows: http://www.romhacking.net/utils/400/
		Mac:	 http://www.romhacking.net/utils/484/
		Linux:	 http://www.romhacking.net/utils/401/
2. The hack is now ready to be played in an emulator. Enjoy!


IV. Instructions
-----------------
Only changes from the original game are covered here.

    1. Title Screen
    ---------------
        A. Controls:
        ------------
        Start/A/B/Y: Go to Options menu (See 2.)
        X: View saved records (Best Bouts) (See 5.)
        Select: Open "Delete Records" prompt (See 6.)


    2. Options Menu
    ---------------
        A. Controls:
        ------------
        Up/Down: Select an option
        Left/Right: Change the setting of the selected option
        Start/A/B/Y: Begin the boss rush (See 3.)
        X: Return to Title Screen

        B. Options
        ----------
        * Game Play Mode: Choose whether you would like to play the game alone (1P), or with a human teammate (2P Team).
          If you choose the latter, Donkey will be player 1 and Diddy will be player 2.
        * Kong Select: Select whether Donkey or Diddy will be active at the start of the game,
          and (for one-player mode) if your companion will be with you. Go it alone as Diddy for maximum difficulty!
        * Team Color: Choose from 8 color sets for your character(s).
        * Boss Select: Choose whether you would like to play against all seven bosses in succession ("All"), or face an
          individual boss (represented by an icon).
        * Timer Display: Pick whether you want the timer visible (On) or hidden (Off).


    3. Playing the Game
    -------------------
    Beat those bad guys as fast as you can without getting hurt!
        
        A. Controls:
        ------------
        * Start, then L: Go back to the options menu (Options)
        * Start, then R: Start a new game with the current settings (Restart)
        * Start, then Select: Quit the game (Quit)
        
        B. Notes:
        ---------
        * There is no lives counter. If you lose a single life, it's game over!
        * For each battle, the timer runs from the instant you gain control of the Kongs until either the boss is--or you are--defeated.
        * In 2P Team mode, the timer is also paused when one player is hit, and the game is waiting for the other player
          to take control.
        * After beating the last boss or getting a Game Over, you will be taken to the Results screen (See 4.).
        * New records are earned by either getting a faster time, or (if the time is the same as the record time) taking fewer hits.


    4. Results Screen
    -----------------
    So, how well did you do? This screen will show you, whether you win or lose. This screen will only appear if you have beaten 
    at least one boss.  Press A, B, X, Y, or Start to proceed to the Best Bouts screen (See 5.).

        A. Legend:
        ----------
        * Boss icons: Designate the time you spent in each of the boss battles. If battling a single boss, the boss level's name
          will appear instead.
            - If you lost to a particular boss, GAME OVER will appear next to that boss's icon.
              All times beyond this will appear as dashes.
            - If the time and hits taken for a certain boss are displayed in gold, you have earned a new record.
        * Bandage icon: Shows how many times you were hit when fighting a boss.
        * Kong icons: Represent the Kong Select settings chosen at the start.
        * 1P/2P icons: Shows which Game Play Mode was selected.


    5. Best Bouts
    -------------
    This screen shows your best times for each boss, as well as your best total time for all bosses. Icons in this screen have
    the same meaning as those in the Results Screen.

    If this screen was accessed from the Title Screen, pressing A, B, X, Y, or Start will return you to the Title Screen (See 1.).
    If it was reached after viewing the Results screen or getting a Game Over, pressing the same buttons will bring you to an
    additional menu with the following options:

        * Options: Go back to the Options menu (See 2.)
        * Retry: Start a new game with the current settings (See 3.)
        * Quit: Return to the intro sequence


    6. Delete Records
    -----------------
    From this screen, you can clear all records from the game's battery backed memory. The instructions are displayed on-screen,
    and are pretty straightforward.

    **WARNING**: Pressing L at this screen will delete your records without asking for additional confirmation!!


V. Distribution Rules
----------------------
* Do not claim this work as your own.
* Do not distribute this hack as a ROM file, only patch files such as IPS, PPF, or UPS should be shared.
* Include the unaltered readme file with the hack when distributing it.


VI. Known Issues
---------------
None.

This demo has been tested on bsnes plus v0.073 (one of the most accurate SNES emulators around), as well as Snes9x v1.53 and ZSNES v1.51.
Please let me know if you do experience any problems.


VII. Special Thanks To
---------------------
* Nintendo, RAREWARE: for creating the original games
* JASC Software: Paint Shop Pro
* YY: YY-CHR
* Christian Maas: XVI32
* creaothceann: vSNES
* FuSoYa: Lunar Address, Lunar IPS
* byuu: bsnes
* Revenant a.k.a. devin: bsnes-plus (fork of bsnes)
* ZSNES dev team
* SNES9x dev team
* Bongo`: SNES Tilemap Editor
* Juggling Joker: TileCounter
* Neviksti: pcx2snes
* Phyreburnz: for the idea of making a Kiddy-colored Diddy palette
* Neale Davidson: for creating the Jumpman font used in the Boss Blitz portion of the game's logo, as well as menu headings

VIII. Contact Info
-----------------
I can be reached at:
* m.grassman87@gmail.com
* DKC Atlas Forum (www.dkc-atlas.com/forum/)
* Jul (jul.rustedlogic.net)
* YouTube (username Mattress87)

(c) 2011, 2017 Mattrizzle, Original Game (c) 1994 Nintendo/Rare Ltd.