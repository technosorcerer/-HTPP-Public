===============================
===                         ===
===   Donkey Kong Country   ===
===     Expert Edition      ===
===          v2.0           ===
===                         ===
===          by Q           ===
===                         ===
===============================

CONTACT: QContinuum256 at gmail dot com


=============
=== About ===
=============

This is a difficulty patch for Donkey Kong Country for the Super NES. It
makes the game harder by removing the DK Barrels (which restore your lost
character), Star Barrels (checkpoints), and Warp Barrels (level skips).
You will need to beat every stage from start to finish with just two Kongs
to progress through the game. It's inspired by the harder difficulty mode
that can be accessed using a cheat code in DKC3.

It also adds Cranky dialogue that was included in the game's data but for
some reason wasn't programmed to appear in the published version of the game.

If this patch is too hard for you, check out the "Challenge Edition" patch,
which removes the DK Barrels and Warp Barrels but leaves the Star Barrels.

If you're looking for an even greater challenge, check out the "Hero Edition"
patch, which removes the DK Barrels, Star Barrels, Warp Barrels, *and*
Donkey Kong himself! That patch requires you to play through the game with
just Diddy!


====================
=== Instructions ===
====================

The "Expert Edition" patch is meant for the US-NTSC 1.0 version of Donkey
Kong Country. It will not work with the US 1.1 or 1.2 versions, the PAL
version, or Super Donkey Kong (the Japanese version).

It's a BPS patch, so it should be applied using the program Beat, which can
be downloaded at the following URL:

* https://www.romhacking.net/utilities/893/

To apply the patch, open Beat and select "Apply Patch." You will be
prompted to select the patch. You will then be prompted to select the
unmodified ROM. Finally, you will be prompted to name the new ROM.

The suggested file name is:
"Donkey Kong Country - Expert Edition (v2.0) [H].sfc"

Beat will tell you whether the patch application was successful. If the
patch application was unsuccessful, it's likely the ROM you tried to
patch is modified or is the wrong version of the game (see above).

Once you have properly patched the ROM, you can play it with the Super NES
emulator of your choice or on a real Super NES or Super Famicom using a
flash cartridge.


============================
=== Detailed Change List ===
============================

* When you start a stage, both Kongs automatically spawn.

* All standing and floating DK Barrels have been removed except for one in
  Temple Tempest, which has been changed to a Vine Barrel (since it's
  necessary to access a bonus room).

* All buried DK Barrels have been replaced with buried banana bunches.

* All Star Barrels and Warp Barrels have been removed.

* Cranky now gives hints about stages in Worlds 1 through 6 instead of just
  World 1. Cranky also gives a hint about Gnawty (the beaver enemy).

* Three Cranky hints that refer to DK Barrels and Star Barrels have been
  removed.

* The BARRAL cheat now sets your starting lives to 20 instead of 50.


==================================
=== Known Issues & Bug Reports ===
==================================

There are currently no known issues. If you find anything wrong, please contact
me using the email address listed above.

Also, this isn't an "issue" per se, but there's currently no custom title screen.
This feature might be added in a future version of the patch. If you're an artist
interested in creating a custom logo, please contact me using the email address
listed above.


===============
=== Credits ===
===============

Q
 * Concept
 * Level editing
 * Text editing
 * Documentation

RainbowSprinklez
 * RainbowZ Editor
 * ASM hacks
 * Technical assistance

Mattrizzle
 * Cranky Level Hints Fix (v2.1)

Big Brawler
 * Playtesting


=======================
=== Version History ===
=======================

*********************
* v2.0 - 11-19-2024 *
*********************

* Created this readme file.

* All hacking redone from scratch using the RainbowZ Editor v0.546 by
  RainbowSprinklez (except for changes to one stage, Temple Tempest, that
  had to be made with the older DKC1 Editor by SalvadorC17).

* Both Kongs now automatically spawn when beginning a stage. The floating
  DK Barrels that were placed at the beginning of each stage to spawn the
  second Kong in previous patches have been removed.

* Removed overlooked DK Barrels from Stop & Go Station and Elevator Antics.

* One of the DK Barrels in Temple Tempest is now a Vine Barrel instead of
  being completely removed because it's necessary to access a bonus area and
  obtain 101% completion. (Thanks to Big Brawler for catching this!)

* Replaced the DK Barrels buried in destructible floors with buried banana
  bunches. (In previous versions of the patch, these were completely removed,
  leaving behind garish empty holes in the ground).

* Removed three of Cranky's hints to account for the fact that there are no
  DK Barrels or Star Barrels in the game.

* Added a Cranky hint about Gnawty that was dummied out of the game.

* Changed the BARRAL cheat to set starting lives at 20.

*********************
* v1.2 - 01-11-2023 *
*********************

* Removed another overlooked DK Barrel from Poison Pond.

*********************
* v1.1 - 01-10-2023 *
*********************

* Removed DK Barrels from Ice Age Alley and Poison Pond that were previously
  overlooked. (Thanks to DKCReturns for catching this!)

* Added Mattrizzle’s Cranky Level Hint Fix, which restores Cranky dialogue
  that was dummied out of the game.

*********************
* v1.0 - 09-18-2018 *
*********************

* Original release.
