Please read about the features of this. https://docs.google.com/document/d/18rmtQjF1AWjeXNTq1qkt3EwBQC0yIunmiyU3IQN9kKQ/edit?pli=1

This was a passion project made by me (RainbowSprinklez). All Mario sprites used here are visual duplicates of Mario from SMW. All of the music was created using the Rare sound engine of DKC1. To explain that is a bit too much to get into here.  