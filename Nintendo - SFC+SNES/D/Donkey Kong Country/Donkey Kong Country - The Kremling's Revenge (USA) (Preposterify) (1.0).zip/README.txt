Donkey Kong Country - The Kremling's Revenge

Hack by Preposterify

The first full Donkey Kong Country Hack! Created using Simion32's DKC Resource Editor.


IMPORTANT: This .ips file must be applied to a clean "Donkey Kong Country (U) V1.0" ROM

