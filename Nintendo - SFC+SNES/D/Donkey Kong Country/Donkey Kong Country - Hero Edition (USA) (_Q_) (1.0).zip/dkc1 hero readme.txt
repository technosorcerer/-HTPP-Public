===============================
===                         ===
===   Donkey Kong Country   ===
===      Hero Edition       ===
===          v1.0           ===
===                         ===
===          by Q           ===
===                         ===
===============================

CONTACT: QContinuum256 at gmail dot com


=============
=== About ===
=============

This is a difficulty patch for Donkey Kong Country for the Super NES. It
makes the game harder by removing the DK Barrels (which restore your lost
character), Star Barrels (checkpoints), Warp Barrels (level skips), *and*
Donkey Kong himself! To progress, you must beat every stage with just Diddy!
It's inspired by the unlockable "Hero Mode" difficulty setting in the Game
Boy Advance version of DKC.

It also adds Cranky dialogue that was included in the game's data but for
some reason wasn't programmed to appear in the published version of the game.

If this patch is too hard for you, check out the "Expert Edition" patch, which
removes the DK Barrels, Star Barrels, and Warp Barrels, but leaves Donkey Kong
in the game.

If that patch is too hard for you, check out the "Challenge Edition," which
removes the DK Barrels and Warp Barrels but leaves the Star Barrels.


======================================
=== A Note on Two Player Team Mode ===
======================================

Two Player Team mode is functional! P1 controls Diddy and P2 controls Donkey Kong
like in the original game. P2 plays first; if they die, control switches to P1.
Since there are no DK Barrels, only one player is able play a stage at a time.
There is no way for a player to tag in the other player, so the only way to switch
control is for one character to die.

Two Player Team mode is the only way to play as DK in this hack.


====================
=== Instructions ===
====================

The "Hero Edition" patch is meant for the US-NTSC 1.0 version of Donkey
Kong Country. It will not work with the US 1.1 or 1.2 versions, the PAL
version, or Super Donkey Kong (the Japanese version).

It's a BPS patch, so it should be applied using the program Beat, which can
be downloaded at the following URL:

* https://www.romhacking.net/utilities/893/

To apply the patch, open Beat and select "Apply Patch." You will be
prompted to select the patch. You will then be prompted to select the
unmodified ROM. Finally, you will be prompted to name the new ROM.

The suggested file name is:
"Donkey Kong Country - Hero Edition (v1.0) [H].sfc"

Beat will tell you whether the patch application was successful. If the
patch application was unsuccessful, it's likely the ROM you tried to
patch is modified or is the wrong version of the game (see above).

Once you have properly patched the ROM, you can play it with the Super NES
emulator of your choice or on a real Super NES or Super Famicom using a
flash cartridge.


============================
=== Detailed Change List ===
============================

* You now start the game as Diddy instead of DK.

* In Two Player Team mode, the game starts with P2 in control.

* All standing and floating DK Barrels have been removed except for one in
  Temple Tempest, which has been changed to a Vine Barrel (since it's
  necessary to access a bonus room).

* All buried DK Barrels have been replaced with buried banana bunches.

* All Star Barrels and Warp Barrels have been removed.

* Cranky now gives hints about stages in Worlds 1 through 6 instead of just
  World 1. Cranky also gives a hint about Gnawty (the beaver enemy).

* Three Cranky hints that refer to DK Barrels and Star Barrels have been
  removed.

* Cranky, Funky, and Candy dialogue was slightly changed so that they address
  Diddy instead of DK or both characters.

* One line of Cranky's dialogue, in which he addresses DK and complains about
  his tie, was removed.

* Cranky's ending dialogue is now a combination of his dialogue from the
  original SNES version and his dialogue from "Hero Mode" in the GBA version.

* The Banana Hoard scene at the end of the game now shows Diddy celebrating
  instead of DK.

* The Animal Bonus Room cheat now starts you as Diddy instead of DK.

* The top Rambi Token in the Animal Bonus Room was moved down two pixels
  so that Diddy can reach it.

* The BARRAL cheat now sets your starting lives to zero instead of 50.


==================================
=== Known Issues & Bug Reports ===
==================================

During the ending sequence, Donkey Kong appears with Diddy in the scene in
which Cranky congratulates you, and Cranky hits DK with his cane like in the
original game. Unfortunately, there's currently no way to change this. Unless
and until it can be fixed, you can interpret it as Cranky getting angry at DK
for not helping Diddy.

Other than that, there are currently no known issues. If you find anything wrong,
please contact me using the email address listed above.

Also, this isn't an "issue" per se, but there's currently no custom title screen.
This feature might be added in a future version of the patch. If you're an artist
interested in creating a custom logo, please contact me using the email address
listed above.


===============
=== Credits ===
===============

Q
 * Concept
 * Level editing
 * Text editing
 * Documentation

RainbowSprinklez
 * RainbowZ Editor
 * ASM hacks
 * Technical assistance

Mattrizzle
 * Cranky Level Hints Fix (v2.1)

Big Brawler
 * Playtesting


=======================
=== Version History ===
=======================

*********************
* v1.0 - 11-19-2024 *
*********************

* Original release.

* Created this readme file.
