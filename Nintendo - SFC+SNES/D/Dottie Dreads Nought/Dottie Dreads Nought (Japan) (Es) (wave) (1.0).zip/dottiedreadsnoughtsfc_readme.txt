Dottie dreads nought (Super Nintendo)
Traducción al Español v1.0 (18/11/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dottie dreads nought (J) (V1.1).sfc
MD5: 90bd580db8b208798013b373bf1425a6
SHA1: 812f508307063cdb5ad37547476c42c3cf1ec892
CRC32: 94afc86d
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --