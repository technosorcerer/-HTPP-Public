"Dragon Quest I & II (Espa�ol)"
Traducci�n al Espa�ol v1.0 (08/03/2019)

1. Sobre Dragon Quest I & II
2. Notas del Proyecto
3. Fallos
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Dragon Quest I & II
-----------------

El clasico de Enix al fin en espa�ol.

---------------------
2. Notas del Proyecto
---------------------
Este proyecto lo inici� hace varios a�os, pero no podia agregar los tildes en los menus. Fue gracias a Jackic (http://jackicblog.blogspot.com) quien me ayud� a editar los tiles y agregarlos, por all� por noviembre del 2018.
Lo siguiente fue traducir ambos juegos, lo que me tom� un par de meses.

Por desgracia, la traduccion de ChrisRPG (Que en paz descanse) qued� con varios bugs, algunos los pude corregir, otros no.

--------------------------------------------
3. Fallo Conocidos
--------------------------------------------

1. En el primer DQ hay unos textos raros tras vencer al rey dragon, no es nada que congele el juego.
2. En DQII hay 3 bugs:
a)El primero se ve cuando tras encontrarte con Rolando y vuelves al pueblo, encontrar�s a otro Rolando, ajajajaja. Si le hablas parece no suceder nada, pero si le hablas mas adelante, provoca problemas, as� que solo ignoralo, no pasa nada.
b)El bug mas feo, es cuando llegas al pueblo de Beranule. Si hablas con el viejo de la posada y duermes all�, despertar�s con Rolando enfermo, la soluci�n a esto es darle un remedio, pero al darselo el texto se repite eternamente y quedas congelado. La soluci�n simple, es NO dormir en Beranule.
c)En un templo, ya al final del juego, y tras derrotar al enemigo final, un sacerdote te habla y el texto se repite, esto tambien es opcional, no sucede nada si no le hablas.

Si encuentras alg�n otro texto raro, no dudes en dejarme un comentario en la entrada del juego:
https://elbauldekarlanga.blogspot.com/2019/03/dragon-quest-i-ii-en-espanol.html

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS. 

Dragon Quest I & II (J)
NoIntro: Dragon Quest I & II (Japan)
Size: 1,573,376 bytes (headered)
MD5: 1DEF71B5557CC6BB7402281D888CAE80 (without the header)