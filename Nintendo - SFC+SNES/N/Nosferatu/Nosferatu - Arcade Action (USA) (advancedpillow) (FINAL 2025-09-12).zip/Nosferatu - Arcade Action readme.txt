NEW CONTROLS:
---------------
- A (tap) = Run
- B = Jump
- X = Spinning Back Kick
- Y = Punch
- D-pad Up = Climb up
- A (tap it), then press Down on the D-pad = slide
- Holding L or R (doesn't matter which) and pressing Left or Right = lunging/dodging/juking
- B to jump then Y or X to attack = Jump Kick
- B and Y or X in quick succession = Double Kick
- Forward and B to jump then Y = Leaping Side Kick
- Down + Y = Quick Uppercut
- Run then Y = Shoulder Charge
- Run then X = Flying Roundhouse
- Run then Down = Slide Kick
- Forward Lunge + Y = Forward Knee
- Holding L or R, forward on D-pad, then Y = Super Combo Attack (very powerful)

TIMER ON OR OFF:
---------------
You can now shut off the Timer in the Configuration menu.

QUICKER ANIMATIONS:
---------------
Sped up a few of the animations a little bit. The most drastic being the turning animations, since they were very slow. Increased the acceleration and deceleration at the beginning and end of running, so it's not quite as sluggish and imprecise.

REMOVED "FIGHTING STANCE":
---------------
The original game's "fighting stance" is mostly just cosmetic now. Pressing an attack actually, now, simply attacks, instead of bringing you into a fighting stance first before you can attack. So pressing Y or X attacks AND puts you in fighting stance. This also makes it so you can juke in or out of fighting stance.

NEW CHEAT CODES:
---------------
- Double Damage = Go to the Configuration menu. Set the cursor to "EXIT". Press the shoulder buttons on the controller in this order: L L R R R L L L
- Full Crystals = During gameplay, pause, and input the following: Up, X, Right, A, Down, B, Left, Y

STAGE SELECT OPTION:
---------------
You can now access the stage select from the Configuration menu.

MUSIC TEST:
---------------
You can now listen to the sweet tunes of the game using the Music Test in the Configuration menu.


Compatible version for the patch: Nosferatu (USA).sfc. Concept and design: advancedpillow. Design and programming: Reld.