Yu Yu Hakusho 2 - Kakutou no Shou
Yu Yu Hakusho 2 - The Fighing Chapter

Jogo 100% em português brasileiro, traduzido por fãs

Acompanhe nossos projetos e tutoriais pelo site: https://hextinkers.neocities.org

---

ATENÇÃO: O arquivo IPS é um patch que deve ser aplicado na ROM original do jogo.

Nome da ROM: Yu Yu Hakusho 2 - Kakutou no Shou (Japan).sfc
Database: No-Intro: Super Nintendo Entertainment System (v. 20210222-050638)
File/ROM SHA-1: 9E7F8F1C08E99BB7F228C5F0A0B548D30BA07386
File/ROM CRC32: B59F8650

Para aprender a aplicar patch, acesse https://hextinkers.neocities.org/tutorial_patch_ips

--

## Equipe de Tradução

Taihen: Tradução, ROM Hacking
vervalkon: Gráficos, ROM Hacking
Sliter: Gráficos

Agradecimentos: Jv132 (Ajustes na fonte)

--

Caso encontre bugs ou queira dar feedbacks, entre em contato por taihendarou[a]gmail.com. Acesse tambÃ©m o site https://hextinkers.neocities.org

NÃO É PERMITIDO QUALQUER TIPO DE COMERCIALIZAÇÃO DESTE PATCH OU DE ROMS/CARTUCHOS COM ESTE PATCH APLICADO! Feito de fã para fã, com objetivo de aprendizado, preservação histórica e diversão.

