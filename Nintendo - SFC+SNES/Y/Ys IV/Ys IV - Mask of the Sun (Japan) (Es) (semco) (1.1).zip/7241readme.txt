TRADUCCIONESS SEMCO (traduccionessemco.blogspot.com)

Ys IV - Mask of the Sun

Traducci�n en Castellano SNES v1.0 (03/03/2024 )
(C) 2024 semco

-------------------------
SOBRE Ys IV - Mask of the Sun
-------------------------
Ys IV: Mask of the Sun es un videojuego de rol de acci�n desarrollado para la videoconsola Super Nintendo, y el cuarto videojuego de la serie Ys. La empresa due�a de la serie Ys, Nihon Falcom, licenci� su desarrollo a Tonkin House.
Ys IV vuelve al estilo de juego utilizado en Ys I y II (incluyendo la recarga autom�tica de HP). Adol se ve desde una vista a�rea, y �l ataca a los enemigos ejecut�ndolos sobre ellos para causar un da�o. Adol gana experiencia al derrotar enemigos y �sta sirve para aumentar su fuerza, como en los juegos anteriores. Adem�s se introduce un nuevo sistema de magia, en el que Adol puede equipar espadas elementales para emitir varios tipos de hechizos de ataque.
Ys IV es secuela de Ys I y II, en donde Dark Fact intentaba obtener los 6 libros para conquistar el mundo y Dahm intenta eliminar a las personas en Ys usando los poderes de la perla negra. 700 a�os atr�s, las diosas y los 6 sacerdotes en Ys Origin repel�an a varios enemigos. Tras la muerte de los sacerdotes, Ys despegaba y la torre de Dahm se construy� al lado del sitio de aterrizaje. Solo las diosas Feena y Reah imped�an la aparici�n de nuevos enemigos hasta el naufragio de Adol en Esteria. Ha pasado 2 a�os de aquel naufragio.

---------------------
NOTAS
---------------------
A�adidos caracteres especiales y de acentuaci�n.
v1.1 (15/03/2024)
Corregidos errores de tipeo en la intro, gracias a Leo Monzon por el reporte.
---------------------
CONTACTO 
---------------------
Si aparece alg�n error o para m�s traducciones

pod�is entrar en:

traduccionessemco.blogspot.com

---------------------------
PARCHEO
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Platform Super NES 
ROM format SNES rom image 
External Header No 
File Size 1572864 (180000) 
ROM Size 1572864 (180000) 
ROM CRC32 CA7B4DB9 
ROM SHA-1 1EC73AB6F7BF43FE0A83F73E6834CD5B7D6C17F8
No-Intro entry Ys IV - Mask of the Sun (Japan) 
Checksum valid Yes
 

----------------------
CREDITOS
----------------------
Versi�n en Castellano:
semco - Hacking y traducci�n en castellano.                                                           JavierCRT - Testeo

Versi�n en Ingl�s:
Gideon Zhi - Hacking	
Shimarisu - Original Translation	
Deuce - Script edit/translation
LordTech - Hacking	Assembly work (old VWF, compression)
g8z et al - Hacking	VWF fix
The Spoony Bard	Graphics - Font Design                    
                                                                              