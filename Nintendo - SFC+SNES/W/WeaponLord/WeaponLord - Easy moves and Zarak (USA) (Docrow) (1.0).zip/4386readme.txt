Note: Many emulators may not support Weapon Lord. If this occurs, use Bsnes...
------------------------------------
Button Key

F=foward
B=Back
U=up
D=Down

Hold buttons:
X= x button
Y= y button
Bb= b button
A= a button

PARRY: Hold Y or L and press or D, or F, or U

Buttons config:
BACK SLASH:             QB  L button
BACK STRIKE:            MB  R button
BACK THRUST:            FB  X button
FORE SLASH:             QF  Y button
FORE STRIKE:            MF  A button
FORE THRUST:            FF  B button

------------------------------------
Special Move List---Command---description or fatality effect
++++++++++++++++++++++++++++++++++++
Korr  (barbarion master warrior)

FLAMEWHIRL:        hold Bb or A and press B      frenzy
POWER PUSH:        near F+F + X or R             thrown       
ELBOW SMASH:       F+F + Bb or A                 grounder 
HEART STRIKE:      hold X or R and press U       body burst
360 FIRE STRIKE:   hold X or R and press B       head smash 
DUAL FIRE STORM:   hold X or R and press D        
TAROK STRIKE:      hold Bb or A and press U      decap,head split
TAROK KNEE STRIKE: B+F + A                       decap 
360 BACK FLAME:    hold Bb or A and press F      deflect 
LONG KICK:         B+F + X or R                  guard break 

*WEAPON BREAKER:    MF,TAROKSTRIKE 
----------------------
Talazia  (the bird of prey)

AIR SLICE:         hold X or R and press F
AIR TEAR:          hold X or R and press U      skull,body burst, 
EAGLE SLASH:       hold X or R and press B      Double hit  
AIR FRENZY:        hold Bb or A and press D     frenzy,
REVERSE CLAW:      hold Bb or A and press B     grounder
FALCON STRIKE:     hold Bb or A and press F     gut,guard break,
TALON STRIKE:      hold R and press D           head crush,head split,deflect
SKY KICK:          B+F + B or A                 grounder/stun
TALON BLADE:       F+F + X or R                 decap,
PREY FLING:        B+F + X or R                 thrown
SHADOW SLASH:      F+F + B or A 

*WEAPON BREAKER:    QB,TALON STRIKE      
---------------------
Bane  (the lone wolf)

CURSED SLAM:       hold X or R and press U    head split
MUTILATOR:         hold X or R and press D    standing body burst,
BERSERKER:         hold Bb or A and press F   head crush, frenzy 
CURSED KICK:       hold Bb or A and press U   decap 
HAMMER BLAST:      hold Bb or A and press D   grounder 
IRON FIST:         F+F + X or R               guard break 
FANG GUTTER:       B+F + Bb or A              stun, gut 
HEAD ROCKER:       B+F + X or R               deflect, 
HAMMER WAVE:       D+D + Bb or A              grounder,
BONE CRUSHER:      D+D + X or R(REPEATx2)     body burst, hit in floor

*WEAPON BREAKER:    QB, CURSED SLAM 
------------------------------------
Zorn  (the defiler)

AXE LIFT:          hold Bb or A and press D    thrown
HELL FIRE:         hold Bb or A and press U    gut, head split 
ARRISE:            hold Bb or A and press B    decap       
CORPSE STRIKER:    hold X or R and press F     ground decap 
SHIELD SCREAMER:   hold X or R and press B     head crush, deflect, 
HELL SHIELD:       hold X or R and press D     guard break 
ANCIENT AXE:       F+F + X or R        
ROLLING CUTTER:    B+F + X or R        
AXE TRIP:          D+D + Bb or A               grounder/stun
HELL GRINDER:      D+D + X or R                body burst, frenzy 
   
*WEAPON BREAK:      QF, HELL FIRE 
--------------------------------------
Jen-Tai  (the war queen)

RAM TOSS:          hold Bb or A and press U  thrown
DEATH BLADE:       hold Bb or A and press B  frenzy 
BACK BLADE:        hold Bb or A and press F  decap  
DOWN STRIKE:       hold X or R and press D   ground decap        
BACKHAND BLAST:    hold X or R and press B   head split,head crush,deflect 
SHIELD RAM:        hold X or R and press F+F 
FACE BREAKER:      B+F + X or R      guard break
SHIELD SPIKE:      B+F + Bb or A     gut,stun 
LEG BREAKER:       F+F + BB or A     body burst,grounder 
AURA STRIKE:       F+F + X or R  

*WEAPON BREAK:      MF, BACKHAND BLAST 
----------------------------
Divada  (mistress of death)

SOUL DISPLACER:    hold X or R and press B    aerial teleport
SOUL BOMB:         hold X or R and press F    body burst,grounder 
SOUL SLICE:        hold X or R and press U    ground decap,decap,head split 
HELL DEFLECT:      hold Bb or A and press D   deflect 
PSYCHO BLADES:     hold Bb or A and press F   gut,frenzy 
SOUL SLAM:         hold Bb or A and press B   stun, linear teleport 
SOUL DRILL:        F+F + X or R               head crush,head split,
DEATH WHIRL:       B+F + Bb or A              slide
HEEL KICK:         F+F + Bb or A              guard break 
 
*WEAPON BREAK:      QB, SOUL SLICE 
------------------------------
Zarak  (the aracne demonlord)

WARP SPIDER:       hold X or R and press B        skull, projectile
WIDOW'S GRIP:      hold X or R and press D        thrown,fatality pt2
CHAOS:             hold X or R and press F        frenzy 
GUILLOTINE STRIKE: hold X or R and press U        ground decap,head crush
WEB SLAP:          hold Bb or A and press B       deflect 
POWER SLICE:       hold Bb or A and press U       gut,stun, 
POWER VAULT:       F+F + Bb or A                  guard break,kick
INFERNO:           B+F + X or R                   body burst 
WEB RIP:           D+D + Bb or A                  thrown,grounder,fatality pt1 

*WEAPON BREAK:      MB, INFERNO 
---------------------------------