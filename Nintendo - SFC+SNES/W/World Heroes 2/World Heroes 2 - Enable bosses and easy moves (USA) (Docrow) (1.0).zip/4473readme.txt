F=foward
B=back
D=Down
U=Upward
FD=Forward+Down
BD=Back+Down

+---------------------+
        Hanzo
+---------------------+

Rekkozan: F + punch
Double Rekkozan B + punch
Kohryuha: D + punch
Ninpoh Kohrin Kazan: B + Kick
Leg Lariat: F + kick
Double Jump: U and U

+---------------------+
         Fuuma
+---------------------+

Tomoe Kuuchuu Nage: In air and close, F + punch
Reppuzan: F + punch
Double Reppuzan: B + punch
Ninpoh Furin Kazan: B + Kick
Enryuha: D + punch (in air too)
Double Jump: U and U

+---------------------+
      Kim Dragon
+---------------------+

Kuuchuu Nage: in air and close, F + punch
Hyakuretsuken: press punch rapidly
Dragon Kick: D + kick
Yoko Chokeri: punch + kick

+---------------------+
        Janne
+---------------------+

Aura Bird: B + F + punch
Justice Sword: B + F + kick
Flash Sword: FD or BD + kick
Sword Hop: D + punch (in air)

+---------------------+
       J. Carn
+---------------------+

Mongolian Tiger Mash: B + F + punch
Mongolian Dynamite: FD or BD + punch
Head Sliding: FD + kick

+---------------------+
       Brocken
+---------------------+

Grenade Launcher: F + punch
German Missile: F + kick
Spark Thunder: A rapidly
Wave Arm: B + punch
Float Attack: A + B in air
Roundhouse Kick: df + Kick in air

+---------------------+
       Rasputin
+---------------------+

Fireball: F + punch 
Thunder Ball: F + F + punch
Air Fireball: F + punch in air
Cossack Dance: F + kick
Axle Spin: B + kick
Air Axle Spin : B + kick in air

+---------------------+
      Erik the Red
+---------------------+

Thor Hammer: FD or BD + punch
Aegyr's Halbread: F + kick
Blizzard Breath: F + F + punch
Long Horn: B + F + punch

+---------------------+
      Captain Kidd
+---------------------+

Shark Knuckle: F + B + punch
Shark Upper: FD or BD + kick
Spiral Kick: B + F + kick
Pirate Ship : F + punch
Toward Kick: punch + kick

+---------------------+
         Shura
+---------------------+

Dash Upper: D + F + punch
Dash Straight: D + F + kick
Tiger Kick: D + kick
Cyclone Kick: F + B + kick
Dash Punch: punch + kick
backstep: B + B

+---------------------+
      Ryoko Izumo
+---------------------+

Bosatsu Sho: D + punch
Nidan Seoi Nage: B + punch ( when near)
Kuuchuu Ha Nidan Nage: F + kick ( when near)
Flash Kick: punch + kick
Dash: F + F
Dash Punch: Dash + punch
Dash Kick: Dash + kick

+---------------------+
         Mudman
+---------------------+

Mud Attack: F + F + punch 
Mud Cutter: B + punch
Mud Gyro: D + punch

+---------------------+
     Johnny Maximum
+---------------------+

Pigskin Thunder Shot: F + punch
Shoulder Butt Crash: F + kick
Head Crash: D + punch
Shoulder Charging: D + kick
Lightning Tackle: B + B + kick

+---------------------+
     Muscle Power
+---------------------+

Super Drop Kick: F + F + kick
Muscle Bomber: B + F + punch
Tornado Body Slam: B + F + punch or F + B + punch ( when near)
Giant Swing: B + F + kick or F + B + kick ( when near)

+---------------------+
     Neo Geesus
+---------------------+

Morph: punch + kick
Explosion: FD or BD + punch

+---------------------+
          Dio
+---------------------+

Sphere ball:  B + punch
Foward Slice: F + F + punch
Foward Upper: F + F + kick
Rolling slash: D + kick
Explosion grab: B + F + kick or F + B + kick ( when near)
Tripping Slide: FD + fierce kick