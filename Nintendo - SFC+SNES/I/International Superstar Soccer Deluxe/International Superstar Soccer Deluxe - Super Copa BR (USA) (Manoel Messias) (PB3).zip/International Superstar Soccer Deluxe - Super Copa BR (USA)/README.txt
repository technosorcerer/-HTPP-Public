=================================================================================================
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
			SUPER COPA BR DELUXE 
			Versão Public Beta 3
			M.M. Edições 2024

	"Edição dos times baseada em "Winning Eleven Brasil All Star/WE2002-PS1" de Diego Gonçalves"

			
	Collaborators:	Marcos Fernandes	Tema de abertura e suporte técnico
			Pedro Ribeiro		Escudo Nacional-AM
			Tardelli		Escudos diversos
			Rafael Veloso		Contribuições em Assembly
			Jorge Guimarães		Contribuições da ISSDPlus
			Douglas Mateus		Avaliação, suporte técnico e correções de bugs		
			Caique Felipe		Avaliação e suporte técnico
			Evandro Bandieira	Avaliação e suporte técnico
		
	Supporters:	Forte Gomba		https://fortegomba.wordpress.com/
			Canal D83games		https://www.youtube.com/@d83games
			Falcon Brazil		https://equipefalconbrasil.blogspot.com/
			Efraim16bits		https://www.youtube.com/@efra-16bit
			Rato Project		https://www.facebook.com/projetorato
			Liga Equilíbrium	https://web.facebook.com/liga.equilibriumissd
			SnesTalgia		https://web.facebook.com/Snestalgia
			Diego Gonçalves		https://www.youtube.com/user/dgoncalvesc
			RomhackingSNES		https://romhackingsnes.blogspot.com/
			Bruno Roberto		https://bstarromhacks.blogspot.com/
			Tony Cinegrafista	https://www.youtube.com/@tonycinegrafistaoficial
			Jorge Guimarães		https://www.facebook.com/projetorato
			Matheus Duarte		https://www.facebook.com/matheus.duarte.3726
			Videogame do Márcio	(Matriz de Camaragibe - Alagoas)

-------------------------------------------------------------------------------------------------
	
	Author 		M.M. Facebook
			Member of Fort Gomba 2019-present
			Member of Falcon Brazil 2020-present

			Collaborator of the Brazilian Football 2019 mod by the Forte Gomba group
			Collaborator of the Libertartadores da América 2020 mod by the Forte Gomba group
			Update 2.0 under the Paulistão Classics mod by Evandro Bandieira/Luciano
			Author of the International Superstar Soccer S/A mod in partnership with Jorge Guimarães (J.Korke)
			Author of the International Superstar Soccer PLUS mod in partnership with J.Korke and Ignácio Alfonso.

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
=================================================================================================

ATTENTION!!! THIS ROM IS STILL UNDER DEVELOPMENT AND THIS RELEASE IS AIMED AT DETECTING BUGS AND PROBLEMS DUE TO A LARGE AMOUNT OF CHANGES.

Hello to the entire romhacking.net community!

I hereby present a new patch, which will probably be the last of my own creation or collaboration, made under the game International Superstar Soccer Deluxe.

This project was developed only for private use and study purposes, for demonstrating techniques and containing experimental modifications. Therefore, I abstain from any commitment and responsibilities for the use of this patch and for the use and sharing of content protected by copyright laws.

This patch was made under the theme "Super Copa BR", which simulates a kind of cup containing some examples of teams from Brazil, whose personal selection, without apparent criteria and even made in a random and recreational way, may not contain completely truthful information or which represent real situations about Brazilian football.

Finally, almost all teams and squads were adapted from another patch for Playstation One - Winning Eleven 2002 called "Winning Eleven Brasil All Star/WE2002-PS1" by Diego Gonçalves. https://www.youtube.com/user/dgoncalvesc

This patch made for the game International Superstar Soccer Deluxe contains some improvements contained in a patch called ISSDPlus (M.M. and J.Korke) and which also contains the following new features:
* Referee who respects the last attack of the game so as not to end it first.
* Low goal shot by pressing the "B" button.
* Choose the game time (1pm-4pm-7pm) using "select+down".
* Correction of the bug that generates the possibility of cheating in PENALTY mode.
* Possibility to save the last Password in SRAM memory (savestate).
* All stadiums edited.
* Now, player names contain 10 letters!
* New uniform details on posters.
* Different details for the two uniforms of the same team (HOME and AWAY).
* Activation scheme for dog referee and special teams by control 1 and facilitated commands.
* Word Series mode subdivided into 3 Regional Series of 12 teams each: Southeast, Northeast and South/Midwest of Brazil, reducing the total number of games to be completed from 70+1 to 22+1.
* International Cup mode adapted so that all teams play qualifying rounds in their respective regionals.
* And several minor details included to improve the game.

=================================================================================================