================================================
International SuperStar Soccer Deluxe Plus
by Manoel Messias & Jorge Guimarães

Version PB4 - Juny 2023
================================================

ATTENTION!!! THIS ROM IS STILL UNDER DEVELOPMENT AND THIS RELEASE HAS THE OBJECTIVE OF DETECTING BUGS AND PROBLEMS DUE TO THE LARGE AMOUNT OF CHANGES.

Hello to the entire romhacking.net community!

The project will be the final evolution of a definitive ROM for the game, bringing unprecedented gameplay improvements and maintaining the already consolidated improvements in skills with team characterization (Jorge Guimarães) for the use of the game in online competitions: “International Superstar Soccer Deluxe Plus”, modification based on the previous project: “[url=https://www.romhacking.net/hacks/5690/]International Superstar Soccer Deluxe (SA)[/url]”.

Among these changes are:

+ MANY MORE TEAMS: 12 new national squads, some coming from the ROM (J), and many unreleased: All teams will be playable in all available game modes, including "INTERNATIONAL CUP" and "WORLD SERIES" modes. Totaling in 54 countries within the game. New teams: China (J), S. Arabia (SA/J), Uzbequistan (J), Iran, S.Africa, Zambia, Ghana, Paraguay (SA/J), Bolivia (SA/J), Venezuela (SA), Ecuador (SA), Costa Rica, Chile (SA), Peru (SA), Honduras, Canada (J), Australia and Yugoslavia.

+ REFEREE RESPECTING THE LAST ATTACK OF THE GAME: From now on, the referees will not end the game if a team has the ball dominated by attacking inside the opponent's area, similar to modern football games, preventing certain bad scenarios where the referee can whistle the end of the game with the ball about to enter the goal.

+ GOAL KICK ON GROUND: Gameplay change, now it will be possible to shoot a low goal kick, pressing the B button, bringing new possibilities for ball output from the goalkeeper.

+ CHOOSE GAME TIME: New option to choose between 13hrs, 16hrs and 19hrs. Press SELECT+DOWN for the menu to appear, on the field and climate selection screen.

+ NEW GAME TIME OPTION: 1 minute Game Time available to choose from OPTIONS menu.

+ PENALTY BUG CORRECTED: Correction of the bug that causes "PENALTY CHEAT" between players 1 and 2, where PLAYER 1 could press buttons to ensure the PLAYER 2 would shoot the penalty off-target, no matter what. Being one less problem when it comes to penalty shootouts present since the (U) version of the game.

+ BATTERY SAVE FUNCTION ENABLED: It is now possible to resume the last game played when restarting the game, keeping the last saved password.

+ ENTRY OF SPECIAL CODES THROUGH THE PLAYER1 CONTROL: There is no longer a need for control 2 to enter the code that enables special items: Referee Dog and the Special Teams, like the “Allstar” squad.


CREDITS:
Manoel Messias (Editor)
Jorge Guimaraes (Editor)
Ignacio Alfonso (Contributor)
Tardelli [D83Games Channel] (Contributor)
Matheus Duarte (Contributor)


---------------------------------------------------------------------------------

(PORTUGUES) 

==================================================
International SuperStar Soccer Deluxe Plus
by Manoel Messias & Jorge Guimarães

Versão PB4 – Junho 2023
==================================================

ATENÇÃO!!! ESTA ROM AINDA ESTÁ EM DESENVOLVIMENTO E ESTE LANÇAMANETO TEM COMO OBJETIVO DETECAR BUGS E PROBLEMAS DEVIDO A GRANDE QUANTIDADE DE MUDANÇAS.

Olá a toda comunidade romhacking.net!

O projeto será a evolução final de uma ROM definitiva para o jogo, trazendo melhorias inéditas de jogabilidade e mantendo as já consolidadas melhorias nas habilidades com caracterização de times (Jorge Guimarães) para uso do jogo em competições online: “International Superstar Soccer Deluxe Plus”, modificação baseada no projeto anterior: “International Superstar Soccer Deluxe (SA)”.

Entre essas mudanças estão:

+ MUITO MAIS TIMES: 12 novas seleções, alguns vindos da ROM (J), e muitos inéditos: Sendo que TODAS as seleções serão jogáveis em todos os modos disponíveis do jogo, inclusive nos modos "INTERNATIONAL CUP" e "WORLD SERIES". Totalizando em 54 países dentro do jogo.
Novos países: China (J), S.Arabia (SA), Uzbequistan (J), Iran, S.Africa, Zambia, Ghana, Paraguay (SA), Bolívia (J), Venezuela (SA), Ecuador (SA), Costa Rica, Chile (SA), Peru (SA), Honduras, Canada (J), Australia e Yugoslavia.

+ ÁRBITRO QUE RESPEITA O ÚLTIMO ATAQUE DO JOGO: A partir de agora, os árbitros não encerrarão o jogo caso um time tenha a bola dominada atacando dentro da área do adversário, similar aos jogos de futebol moderno, impedindo certos cenários ruins onde o árbitro pode apitar o fim de jogo com a bola prestes a entrar no gol.

+ TIRO DE META RASTEIRO: Mudança na jogabilidade, agora será possível bater um tiro de meta de forma rasteira, apertando o botão B, trazendo novas possibilidades de saída de bola.

+ ESCOLHA O HORÁRIO DO JOGO: Nova opção para escolher entre 13hrs, 16hrs e 19hrs. Aperte SELECT+BAIXO para que o menu apareça, na tela de escolha de campo e clima.

+ NOVA OPÇÃO DE TEMPO DE JOGO: Game Time de 1 minuto disponível para escolher no menu OPTIONS.

+ BUG DO PENALTI CORRIGIDO: Correção do bug que causa a "TRAPAÇA DO PENAL" em que o player 1 poderia forçar o player 2 a isolar a bola na cobrança ao apertar várias vezes o botão A, sendo um problema a menos quando se trata em disputa de penaltis presente desde a versão (U) do jogo.

+ FUNÇÃO SAVE POR BATERIA HABILITADO: Agora é possível retomar à última partida jogada ao reiniciar o jogo, mantendo-se a última password salva.

+ INSERÇÃO DE CÓDIGO ESPECIAIS ATRAVÉS DO CONTROLE PLAYER1: Não há mais necessidade do controle 2 para inserção de código que habilita ítens especiais: Juiz Cachorro, e o destravamento de seleções secretas.

Está sendo disponibilizado o link para download da versão BETA de testes, e gostaríamos que nos fornecessem feedback sobre quaisquer bugs, erros ou problemas que possam acontecer, para que estes sejam corrigidos para o lançamento oficial. Bons jogos!


CRÉDITOS:

Manoel Messias (Editor)
Jorge Guimarães (Editor)
Ignacio Alfonso (Colaborador)
Tardelli [Canal D83Games] (Colaborador)
Matheus Duarte (Colaborador)

------------------------------------------------------------------------------------