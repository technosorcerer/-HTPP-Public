Indiana Jones' Greatest Adventures - EasyType Lite Hack by magusRE
----------------------------------------
This Hack aims to make the game more forgiving without changing the difficulty to much. The Boulder in Stage 2 won't kill you anymore but do damage instead. Double invincible frames in the platformer levels should be enough to avoid getting another hit from an enemy in a short time.

USA, Japan and Europe versions are supported.

EasyType Lite:
- Stage Select is always available without need to insert Code
- Stage Select Code replaced with Infinite Health Code (Code input is same, not modified)
- Stage 2 Boulder does damage instead of instant kill
- Double Invincible Frames after taking damage
- Continue on Last Stage (not sending Stages back)
- Infinite Continues

Optional:
- Start with 3 Grenades
- 3 Grenades after death

All changes are available as separate small patches for individual customization.

Going to Options deactivates the Infinite Health and Level Skip Codes, re-enter the Codes to use them again.

Infinite Health Code can put you into a endless loop in Stage 4 Raven Bar when you fall into the Fire, to escape this use the Game Over Code or Level Skip Code.

--------------------
Required ROM:
--------------------
Database match: Indiana Jones' Greatest Adventures (USA)
Database: No-Intro: Super Nintendo Entertainment System (v. 20210222-050638)
File/ROM SHA-1: 07C69B18B8CA3CF83EE0E1A7901020756B3FD85D
File/ROM CRC32: 70DA6BB8

Database match: Indiana Jones' Greatest Adventures (Japan)
Database: No-Intro: Super Nintendo Entertainment System (v. 20210222-050638)
File/ROM SHA-1: 0BF1C7C10988EE1D7C6EA40E6E55B2AEFBB28ECB
File/ROM CRC32: 79B9996

Database match: Indiana Jones' Greatest Adventures (Europe)
Database: No-Intro: Super Nintendo Entertainment System (v. 20210222-050638)
File/ROM SHA-1: F08BE42140CAD072529D4DDF5472BEB447228E00
File/ROM CRC32: FA4560C3

--------------------
Thanks and Credits:
--------------------
www.romhacking.net
Sour for Mesen2