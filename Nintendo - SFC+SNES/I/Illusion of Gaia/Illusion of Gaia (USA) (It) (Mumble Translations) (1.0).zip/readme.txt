
                          ██████████████████████████████████
                    ██████                                  ██████
               █████                                              ██████
               ██                                                     ██░░
             ██                                                         ██░░
           ██    ▐██    ██▌ ██   ██ ▐██    ██▌▐██▀▀██▄ ██      ███████    ██
           ██    ▐███▄▄███▌ ██   ██ ▐███▄▄███▌▐██▄▄██▀ ██      ███▄▄      ██░░
           ██    ▐██ ▀▀ ██▌ ██   ██ ▐██ ▀▀ ██▌▐██  ▐██ ██      ███        ██░░
           ██    ▐██    ██▌  █████  ▐██    ██▌▐██████▀ ███████ ███████    ██░░
             ██                                      Translations       ██░░░░
               ██                                                     ██░░░░
               █████                                              ██████░░
          ████   ░░░██████                                  ██████░░░░░░░░
        ██    ██      ░░░░██████████████████████████████████░░░░░░░░
    ██  ██    ██░░        ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
  ██  ██░░████░░░░
    ██░░    ░░░░

                          https://mumble.romhacking.it

                                   Presenta:

================================================================================
                                Illusion of Gaia
                                -Italiano- v1.00
                            by Clomax, Mog e _Ombra_
                                   05-09-2025
================================================================================

--------------------------------------------------------------------------------
0 - INDICE
--------------------------------------------------------------------------------

1 - Presentazione
2 - Introduzione
3 - Come applicare la patch
4 - Progressi
5 - Progressi futuri
6 - Il gruppo
7 - Grazie a...
8 - Disclaimer

--------------------------------------------------------------------------------
1 - PRESENTAZIONE
--------------------------------------------------------------------------------

Mumble  Translations è  un collettivo  che ha come  scopo quello di  esaltare le
competenze dei singoli per il raggiungimento di un obiettivo comune:
tradurre videogiochi.

--------------------------------------------------------------------------------
2 - INTRODUZIONE
--------------------------------------------------------------------------------

I sogni son desideri, e tradurre Illusion of Gaia era uno di questi.
Ci provai agli albori della mia  esperienza da romhacker, ci sono tornato sopra,
assieme  al fido  Ombra e al  prode Mog, oltre  vent'anni  dopo per  chiudere un
ciclo.
Tecnicamente, il gioco è stato analizzato  in lungo e in largo da altri team, e,
forti delle loro scoperte e con l'esperienza di Ombra è stato veramente semplice
creare un tool che ci permettesse di tradurre ogni singolo aspetto del gioco.
Anche questo progetto è stato portato a termine. Sotto al prossimo!

- Clomax -


Come Faxanadu per NES cinque anni prima, Illusion of Gaia ebbe l'onore di venire
pubblicato in occidente direttamente da Nintendo, in una confezione che sembrava
gridare "È quasi come Zelda".
Ed è  poi questa  la cifra dei  giochi di ruolo  d'azione di  Enix su  SNES: non
riescono a piazzarsi come capolavori del genere, ma hanno talmente tanto cuore e
bizzarrie da non far mai rimpiangere  la decina di ore spese a giocarli, e anche
a  distanza  di  decenni  sono  una  superba  spiaggia  a  cui  tornare  se  hai
sperimentato proprio di tutto.
Detto ciò,  è stato  un consueto  onore poter  revisionare i  testi con  l'aiuto
dell'eccellente  tool di  Clomax,  ormai una certezza,  e della ritraduzione dal
giapponese operata da Swimmy.

- Mog -


Quando  ho  iniziato  a  lavorare  a questa  traduzione,  non avevo  mai giocato
Illusion  of Gaia  da bambino...  eppure,  mentre ci  mettevo  le mani,  mi sono
ritrovato catapultato indietro nel tempo.
Le atmosfere,  le musiche,  lo stile:  tutto  mi ha  riportato a  quelle  stesse
emozioni che provavo da  ragazzino davanti allo SNES,  quando titoli come Secret
of Mana mi facevano  sognare mondi lontani e avventure senza fine.  È stato come
riscoprire una parte di me,  un piccolo viaggio nel passato che non mi aspettavo
di fare.

Sul  lato  tecnico,  l'unica  difficoltà  era la  compressione della  grafica ma
essendo un gioco  Quintent è stato un gioco  da ragazzi  grazie all'informazione
già disponibile online. Una volta oltrepassato questo ostacolo, il resto è stata
una "passeggiata". Mi sono occupato dell’hacking ASM su diverse parti del gioco,
lavorando sui menu,  sul codice di ripuntamento dei testi  e su alcune modifiche
dall’intro agli sprite. L'unica vera rogna è stata la mappa che usava un sistema
particolare di  compressione e "organizzazione".  Dopo qualche giorno  di studio
alla fine è ceduta anche lei e siamo  riusciti a tradurre assolutamente tutto il
traducibile. Come cigliegina sulla torta, ho integrato un hack per le dimensioni
delle  finestre   dei  nomi  delle   locazioni  proveniente   dal  progetto   di
retranslation - un grazie speciale al team per questo fantastico hack - e quello
per l'aggiunta del  bottone di sprint che permette di  correre usando un bottone
invece di premere due volte sul pad direzionale.

Questa traduzione non è stata soltanto  un progetto tecnico: è stato un viaggio,
un ritorno a quelle emozioni che mi hanno fatto innamorare dei videogiochi.
Spero che  chi giocherà  a questa  versione possa  provare almeno  una parte  di
quella stessa magia.

- _Ombra_ -

--------------------------------------------------------------------------------
3 - COME APPLICARE LA PATCH
--------------------------------------------------------------------------------

***IMPORTANTE***

La patch deve essere applicata alla versione americana del gioco.
Di seguito troverete il CRC della ROM su cui applicare questa patch:

Illusion of Gaia (U) [!]: 1C3848C0

Prima di applicare la patch, si consiglia di fare un backup della rom originale.

***ISTRUZIONI***

- Decomprimere lo zip nella cartella dove si trova la ROM originale

- Lanciare il patcher jips.jar (Compatibile con Win/MacOS/Linux)

- Cliccare sui tre puntini a destra di "File To Patch" e selezionare la rom

- Cliccare sui tre puntini a destra di "Patch File" e selezionare il file ips

- Cliccare su "Patch!"

- Giocarci con il vostro emulatore preferito ;)

--------------------------------------------------------------------------------
4 - PROGRESSI
--------------------------------------------------------------------------------

Versione 1.00 (05/09/2025)

Testi:
  - Tradotta la schermata del titolo
  - Tradotte le voci del menù iniziale
  - Tradotta l'introduzione
  - Tradotte le voci del menù del gioco
  - Tradotti i nomi dei luoghi (3 volte)
  - Tradotti i nomi degli oggetti (2 volte)
  - Tradotte le descrizioni degli oggetti
  - Tradotti i nomi dei poteri oscuri
  - Tradotte le descrizioni dei poteri oscuri
  - Tradotti TUTTI i dialoghi del gioco
  - Tradotto il finale
  - Tradotti i crediti

Grafica:
  - Aggiunte le lettere accentate in vari font
  - Tradotta la schermata col logo Enix
  - Tradotta la schermata col logo Nintendo
  - Tradotti i nomi dei luoghi sulla mappa in Mode7
  - Tradotta la scritta finale END in FINE (mantenendo l'animazione)
  - Tradotti PLAYER, ENEMY e DP in alto
  - Tradotta la scritta 5HP

ASM:
  - Spostamento dei testi e del dizionario nell'area espansa
  - Centramento automatico dei nomi dei luoghi
  - Tradotta la scritta PAUSA
  - Aggiunto l'hack creato da C-Dude per il pulsante della corsa

--------------------------------------------------------------------------------
5 - PROGRESSI FUTURI
--------------------------------------------------------------------------------

- La patch è attualmente completa al 100%.
  Ulteriori patch verranno rilasciate per correggere errori, o mancanze, che
  potrebbero verificarsi

--------------------------------------------------------------------------------
6 - IL GRUPPO
--------------------------------------------------------------------------------

Mumble Translations è composto da:

Chester           <andrea@orru.io>
Clomax            <robertofontanarosa@gmail.com>
_Ombra_	          <ombrard@gmail.com>
Mog               <mog_tom@yahoo.it>

--------------------------------------------------------------------------------
7 - GRAZIE A
--------------------------------------------------------------------------------

- C-Dude per aver creato l'hack che assegna il pulsante della corsa.
- Il team del progetto IOGRetranslation per l'hack delle finestre dei nomi.
- Mog, per aver revisionato, instancabilmente, tutti i testi.
- Gens e Juri! per aver testato il gioco.

--------------------------------------------------------------------------------
8 - DISCLAIMER
--------------------------------------------------------------------------------

Questa  patch  è  amatoriale  e non  è affiliata  in alcun  modo  con  Nintendo,
Square-Enix  e   a  nessun'altra   compagnia   coinvolta   nella   creazione   e
distribuzione del gioco.

Usa questa patch a tuo rischio e pericolo.

Illusion  of  Gaia  e i  relativi  nomi  sono  marchi  registrati  dei  relativi
proprietari. Il gioco Illusion of Gaia è ©1993 Quintet.
