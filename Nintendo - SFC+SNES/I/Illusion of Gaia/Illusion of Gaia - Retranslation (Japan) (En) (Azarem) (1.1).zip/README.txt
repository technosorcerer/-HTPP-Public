----------------------------------------------
ILLUSION OF GAIA RETRANSLATED v1.1
Copyright 2024 by GaiaLabs
https://github.com/Azarem/IOGRetranslation
https://github.com/Azarem/GaiaLabs
https://discord.gg/mkKFYkq2xT
----------------------------------------------

TABLE OF CONTENTS

1.) Patch Notes (v1.1)
2.) Application Instructions
3.) MSU Instructions
4.) About the Project
5.) What's New?
6.) Special Thanks


-----------------------------------
1.) Patch Notes (v1.1) [12.29.2024]
-----------------------------------

* Title screen has been re-implemented from the prototype.

* Original mountain background in Edward Castle has been re-implemented, though the animation has yet to be replaced.

* Fixes to music playing at improper times.

* Map titles and their boxes auto center and size. It's done in intervals of two, so text may have a space before or after.

* Handful of item names have been translated (ItemStrings.asm). This is what's seen when the menu opens up.

* Also updated location/scene titles now that longer names are possible.

* Various bug fixes.


----------------------------
2.) Application Instructions
----------------------------

This is a BPS patch for Illusion of Gaia which replaces approximately 99% of the original Robert L. Jerauld localization's script with L Thammy's retranslation of Gaia Gensouki. In addition, the patch decompresses all the assets in the game, while providing an expanded ROM with available space. As a result, loading times are extremely fast! A handful of ASM patches are used to modify the loading process to support faster screen transitions by completely bypassing the decompression steps.

Instructions will also shortly be included for those who wish to take advantage of the game's newly-added MSU-compatibility. In addition to the new script and higher-quality music, several other additions and improvements have been made to the original localization which can be read about in section 2, appropriately titled "MSU Instructions".

To use this patch, download FLIPS, Beat, or use the Online Rom Patcher:

FLIPS - https://www.romhacking.net/utilities/1040/
Beat - https://www.romhacking.net/utilities/893/
Online Patcher - https://romhackplaza.org/patch/
Alternate 1 - https://www.romhacking.net/patch/
Alternate 2 - https://www.marcrobledo.com/RomPatcher.js/

ROM / ISO Information:
Database match: Illusion of Gaia (USA)
Database: No-Intro: Super Nintendo Entertainment System (v. 20210222-050638)
File/ROM SHA-1: 38DE0C84DD2BC3BDFC0A3D7AB0220C79B70887C3
File/ROM CRC32: 1C3848C0


--------------------
3.) MSU Instructions
--------------------

1.) Download one of the music packs from here: https://www.zeldix.net/t1604-illusion-of-gaiatime-gaia-trilogy-ii

2.) Extract the PCM files into the same folder as your "Illusion of Gaia Retranslated" ROM.

3.) Rename the PCM files to match the ROM filename. Ex: if your ROM is named GaiaLabs.smc, your PCM files will be named "GaiaLabs-{number}.pcm", where {number} is the track number in the original name. You want to keep that part.

5.) Make sure you have an empty MSU file to match your ROM: "GaiaLabs.msu"

6.) Use any modern emulator and enjoy the full music experience.

For further documentation and assistance, please see the following link: https://www.zeldix.net/t1607-msu1-getting-started-guide


---------------------
4.) About the Project
---------------------

In September of 1994, Illusion of Gaia made its North American debut. The story by Japanese sci-fi writer Mariko Ouhara was notable for being much darker than the other RPGs Nintendo was allowing at the time. Despite a softening of the themes, the plot she weaved went to dark and intriguing places and left players with much to think about. Unfortunately, the localization was also often incomprehensible, with transitions between first and third person narrative that were difficult to follow.

Many years later in early 2020, ResetEra forum member L Thammy would spend roughly two months translating the game that has been so special for all of us and shared the experience with the internet. Through ResetEra's forums and an accompanying series of subtitled YouTube videos, he attempted and succeeded in retranslating Gaia Gensouki. The assistance of fellow forum-users made the process a collaborative endeavor and gave us a more accurate translation. The thread and videos are still worth reading/viewing, should you be interested in the actual translation process! As of this writing, both can still be found online.

At some point, a spreadsheet was created to compile all of the screenshots, transcription, raw transliteration, revised translation, and contextual comments. L Thammy expressed approval if anyone was willing to use the translation for a patch, but one would not be produced for a little over four years.

The GaiaLabs tool set for Illusion of Gaia ROM hacking hit the scene and its realization finally became possible. Much like L Thammy's Let's Play, Azarem's personal project would be noticed by others with a love for the game and evolve into a collaborative effort that expanded in scope. It took a long time to get here, but the full depth of Mariko Ouhara's "Gaia Gensouki" can be experienced in "Illusion of Gaia Retranslated."

The GaiaLabs Toolset and further documentation about its uses can be found at: https://github.com/Azarem/GaiaLabs.

Let's Play on ResetEra Forums (with Translation Notes): https://www.resetera.com/threads/lets-play-illusion-of-gaia-but-in-japanese-gaia-gensouki-retranslation-attempt.171584/

Let's Play Video (with Subtitles): https://www.youtube.com/playlist?list=PLoqdJOVga77Bp2FnXfnrf8KhPoVuF1Xeh


---------------
5.) What's New?
---------------

While we've added a roster of improvements and changes, care was taken to offer options to the player in how they would like to enjoy this beloved classic. We hope that these new options will help you find a playstyle that you most enjoy!

* New Translation by L Thammy!

* When starting a game, the options menu now offers the choice between the North American localized names (Will, Lance, Seth, etc.) or original Japanese ones (Tim, Rob, Morris, etc.). Please note that in v1.0, choosing English may lead to text minor overflow, but this will be fixed in v1.1 This option replaced the choice between Stereo and Mono. Stereo is now enabled by default.

* Unique borders were designed to better represent the personalities and cultures of the story's characters. The original white border remains in-game, usually being used to describe actions that are occurring.

* The number of lines and placement of text windows has been adjusted where necessary. Minor graphical changes have been made to the HUD to accommodate for this change.

* Inventory stacking has been implemented for certain items, such as Medical Herbs and Red Jewels. At present time, no numeric indicator exists to specify the amount carried. This will be addressed in a future patch.

* The inventory menu screen currently displays certain debug elements such as x/y position at the bottom of the screen. This may be removed in future patches.

* Now there's a Sprint Button! You can also still sprint using a double-press on the D-pad. This can definitely be considered an accessibility option for those who struggle with or dislike the original method. It also makes Illusion of Gaia play a bit more like its successor, Terranigma.

* Dialogue has been made harder to accidentally skip through. Several button inputs that allowed text to advance were disabled to make this possible.

* The option to end your game when speaking with Gaia has been removed, as it essentially resulted in a soft-lock for no reason.

* Asset decompression allows scenes to load MUCH faster.

* MSU compatibility is now included. Instructions for its use can be found in section 2 of this document.

* Sky Deliveryman has been added back into the endgame. Aside from the ability to return to the South Cape, Itory Village, and the Larai Cliffs, nothing about those areas has been changed at this time and traveling to Itory Village will prevent your return to South Cape. Until this is addressed in a later patch, please save before experimenting with the Sky Deliverman and be careful!

-More Coming Shortly-


------------------
6.) Special Thanks
------------------

* Firstly, to L Thammy, who graciously allowed us to use his translation as part of the project.

* Also, to CDude, who has been an active participant in the streams, contributing to creative choices and bug fixes along the way.

* To the staff of Quintet, manga creator Moto Hagio, and sci-fi/fantasy author Mariko Ouharaor, whose passion and talent made all of this possible in the first place.

* Even to Robert L. Jerauld and the Enix USA staff!

Sometimes, we may poke fun at the original translation, but those working in localization at the time often had insufficient resources and were working on tight deadlines. Jerauld reported in a 2014 interview with Heidi Kemps at Gaming Moe, that he "wanted the story to feel natural, the characters to resonate with people, to feel familiar." Considering the love people have shown for Illusion of Gaia, I'd say they did something right!