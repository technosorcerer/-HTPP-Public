Inspector Gadget - The Gadgeteer
April. 25th 2025
BillyTime! Games
--------------------
This is a simple patch designed for Inspector Gadget that tweaks aspects of the game for a better experience. 

New features:
*Can use Blue Copter to Multi-Jump
*Improved Camera - Updates while in mid-air
*Increased Brain cap (Extended Arm Length)
*Can skip Chief Quimby level intros by holding Start and pressing B after receiving the note.

How to Patch:
--------------------
1.Grab a copy of Inspector Gadget (USA).sfc (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file