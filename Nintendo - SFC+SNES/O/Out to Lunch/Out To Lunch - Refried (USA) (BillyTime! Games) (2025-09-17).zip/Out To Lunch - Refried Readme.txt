Out To Lunch - Refried
Sept. 17th 2025
BillyTime! Games
--------------------
This is a overhaul patch designed for Out To Lunch designed to improve some of the in game mechanics.

Changes
--------------------
*Slower Timer
*Keep items and weapons in between levels
*Food runs from player at a slower rate
*Chef Pierre jumps slightly higher


How to Patch:
--------------------
1.Grab a copy of Out to Lunch (USA).sfc (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file