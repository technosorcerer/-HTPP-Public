OLIVIA'S MYSTERY
Altron, 1994 (although it says 1993 on title screen)

English translation by alasker1899 (alasker1899@pm.me)
v1.0, 2024-06-23


I. INTRODUCTION

"Olivia's Mystery" is a puzzle game for Super Famicom, released only in Japan. It features animated block puzzles and a quirky story to tie them all together. Game supports Super NES Mouse.


II. TRANSLATION

Conveniently most of the text in the game was already in English, including title screen, passwords and credits. Only story had to be translated to English.
Machine translation tools were used for initial translation, but manual edits had to be done to make translation more precise and easier to read. Finally, project is still looking for a translator, as current generation of GenAI just cannot grasp all nuances required for a perfect translation. Consider this version of translation as a preview, a proof that text can be inserted into the game.
English font was borrowed from "7th Saga" (SNES).


III. CREDITS

ROM HACKING
alasker1899

TRANSLATION
DeepL, GoogleTranslate, ChatGPT 3.5, meta-llama/Meta-Llama-3-70B-Instruct, mistralai/Mixtral-8x7B-Instruct-v0.1 and maybe few others I forgot.
Special thanks to jisho.org

EDITING
alasker1899


IV. TRIVIA

- Game was featured in 212th episode of GameCenter CX, aired on 2016-01-28.
- A machine code monitor is programmed into the game.

