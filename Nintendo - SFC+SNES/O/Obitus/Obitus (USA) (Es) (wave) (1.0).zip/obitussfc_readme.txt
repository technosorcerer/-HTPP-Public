Obitus (Super Nintendo)
Traducción al Español v1.0 (22/04/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Obitus (USA).sfc
MD5: a8d00feecb22269f8330206d54b12603
SHA1: 83fa98c639c9480836c8b3ae4a7020125f868d67
CRC32: 7c495b36
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --