"X-Men: Mutant Apocalypse"
Traducci�n al Espa�ol Ver. 1.0 (16/03/2019)
por Max1323 (maxmuruchi@gmail.com)
---------------------------------------------------
Descripci�n:
Basado en los c�mics de X-Men de Marvel.
Durante a�os, la naci�n de Genosha ha esclavizado a su poblaci�n mutante, mientras que el resto del mundo le dio la espalda. Ahora, cuando la situaci�n se torna sombr�a, el profesor Charles Xavior se sorprende al encontrar la verdadera fuerza que se esconde detr�s del gobierno de Genosha. Con el destino de toda la raza mutante en la balanza, el Profesor Xavior debe desatar a los X-Men para enfrentar al mutante m�s poderoso de todos: �el Poderoso Apocalypse!    

Desarrollado: Capcom
Publicado:    Capcom
Lanzamiento:  Noviembre 1994 (Estados Unidos)
              1995           (Europa)
              03/01/1995     (Jap�n)             
---------------------------------------------------
Acerca del proyecto:
Se tradujo los di�logos.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS

X-Men - Mutant Apocalypse (U).smc
File MD5      0C8D8FD7E695499B86D39CC75E166671        
File SHA-1    81F66A620352F6ECAD3BDFE0D47F42C55971080C
File CRC32    5E34822A                                
Tama�o        2.00 MB                              

                           
                              
                              
                             
                       
