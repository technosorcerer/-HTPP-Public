X-Men - Mutant Apocaylpse SRAM
Jan. 12th, 2022
BillyTime! Games
--------------------

This patch is designed to add a simple save function to X-Men - Mutant Apocaylpse.

How it works:
--------------------
Saving:
Game saves whenever the password screen appears in mission mode.

Loading:
At the main menu, highlight sound and press left or right. Then select mission mode.

Note:
*Loading without a prior save will result in a black screen
*SRAM saves only work for Mission Mode.

How to Patch:
--------------------
1.Grab a copy of X-Men - Mutant Apocalypse (USA).sfc
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file

BONUS!
--------------------
For developers, this file includes a text file detailing needed changes to create an SRAM hack for X-Men - Mutant Apocaylpse. It can be used as a base for any other HiRom SNES game. 