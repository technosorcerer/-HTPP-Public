================================================================================
                                X-Kaliber 2097
                                -PT-BR- v1.00
                             Dindo, denim e Kuroi
                                  25-01-2024
================================================================================

--------------------------------------------------------------------------------

-------------------------------------------------- -------------------------
EQUIPE
-------------------------------------------------- -------------------------
Dindo: Tradução, Revisão, Romhacking.

denim: Romhacking.

Kuroi: Dump.


-------------------------------------------------- -------------------------
COMO APLICAR O PATCH
-------------------------------------------------- -------------------------

***IMPORTANTE***

O patch deve ser aplicado em todas as versões americanas do jogo.
A seguir, encontre o CRC da ROM para aplicar este patch:

X-Kaliber 2097 (BR) (2024) v1.00: E83ECEEA

Antes de aplicar o patch, certifique-se de fazer um backup da memória original.

***INSTRUÇÕES***

- Abra o programa flips, clique em "Apply IPS Patch"

- Selecione o "X-Kaliber 2097 (BR) (2024) v1.00.ips" e clique em "Abrir"

- Na tela seguinte, selecione a ROM X-Kaliber 2097 (USA).sfc

- Clique em abrir e pronto! Seu jogo estará traduzido ;)

-------------------------------------------------- -------------------------
