Super Star Wars - Return of The Jedi Redux
Sept. 15th 2025
BillyTime! Games
--------------------
This is a overhaul patch designed for Super Star Wars designed to reduce the infamous difficulty of the original.

Changes
--------------------
*Reduced damage from all sources in side scrolling levels
*Reduced Weapon Penalty on death (No Degradation on Easy Mode)
*Reduced distance needed in 1st Speeder Stage (Tatooine)
*2x Damage
*Infinite Lives when playing Easy Difficulty
*Slightly higher double jump
*Continues Increased from 3 to 99
*Reduced health for Tatooine Boss outside of Jabba's Palace
*Reduced health for Rancor Boss
*2x Invulnerability time after taking a hit
*Reduced speeder bike targets needed (Endor)
*Nerfed explosion speed in Death Star Escape

Streamlined Levels: (Optional Patch)
--------------------
*Removed Tatooine
*Removed Ewok Village B
*Removed Tower



How to Patch:
--------------------
1.Grab a copy of Super Star Wars - Return of the Jedi (USA).sfc (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file