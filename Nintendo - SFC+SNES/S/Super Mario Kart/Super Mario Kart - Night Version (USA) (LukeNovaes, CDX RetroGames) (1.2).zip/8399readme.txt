****************************************************** * *****
If you like this mod, please leave a review on RHDN
(http://www.romhacking.net)
****************************************************** * *****

***********************
Super Mario Kart - Night Version
***********************
Game: Super Mario Kart
System: SNES

Database match: Super Mario Kart (USA)
Database: No-Intro: Super Nintendo Entertainment System (v. 20210222-050638)
File/ROM SHA-1: 47E103D8398CF5B7CBB42B95DF3A3C270691163B
File/ROM CRC32: CD80DB86


Super Mario Kart - Night Version (SMK Hack).ips


Producer: CDX RetroGames
Release: 05/19/2022

© 2022 CDX RetroGames
CHANNELS: https://youtube.com/channel/UCwxZRTBcwonBjwqP_GinYhQ
https://youtube.com/c/CDXGAMES0382EQS
****************************************************** *

******
* Info *
******

Super Mario Kart - Night Version is a Project created by Eurípedes do Canal: CDX RETROGAMES.


The main idea was to make a hack totally in the night mood, as all the tracks from the original game are during the day.
And with this idea, the palettes of the terrains of the tracks and the Backgrounds were changed, creating a very beautiful and interesting night atmosphere.



*****************
*Characteristics*
*****************

- BG's in Night Theme

