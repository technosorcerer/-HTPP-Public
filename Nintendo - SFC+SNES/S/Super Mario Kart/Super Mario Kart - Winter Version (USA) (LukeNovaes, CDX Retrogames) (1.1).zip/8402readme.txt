****************************************************** * *****
If you like this mod, please leave a review on RHDN
(http://www.romhacking.net)
****************************************************** * *****

***********************
Super Mario Kart - Winter Version
***********************
Game: Super Mario Kart
System: SNES

Database match: Super Mario Kart (USA)
Database: No-Intro: Super Nintendo Entertainment System (v. 20210222-050638)
File/ROM SHA-1: 47E103D8398CF5B7CBB42B95DF3A3C270691163B
File/ROM CRC32: CD80DB86


Super Mario Kart - Winter Version 

Producer: CDX RetroGames
Release: 2024

© 2024 CDX RetroGames
CHANNEL:
****************************************************** *

******
* Info *
******

Super Mario Kart - Winter Version is a Project created by Eurípedes from YT Channel: CDX RETROGAMES.


The main idea was to make a totally snowy hack that he always thought was beautiful.
And with this idea, the palettes of the terrains of the tracks and the Backgrounds were changed, creating a very beautiful and interesting snow climate, which draws attention.

Some physical versions of the hack were created.

The changes to the names of the Tracks and Cups are as follows:

Cups:
Blizzard Cup (Mushroom Cup)
Alaska Cup (Flower Cup)
Crystal Cup (Star Cup)
Ice Cup (Special Cup)

Tracks:
- Eskimo Circuit (Mario Circuit)
- Polar Plains (Donut Plains)
- Neve Valley (Ghost Valley)
- Icebergs Beach (Koopa Beach)
- Cold Island (Chocolate Island)
- White Lake (Vanilla Lake)
- Diamond Castle (Bowser Castle)
- Color Road (Rainbow Road)



*****************
*Characteristics*
*****************

- Tracks in the Ice Theme (Snow)
- BG's in Ice Theme (Snow)
- New names for tracks and Cups



