
-------------
How to Patch
-------------

This is a .bps patch, a special type of patch file. To play 
this hack, you will need to patch the US unheadered version
of SMK using one of the utilities linked below. :)

https://www.smwcentral.net/?p=onlinetools&tool=flips

https://www.smwcentral.net/?a=details&id=11474&p=section

-------------

Welcome to Resident Evil Kart!

This is a troll hack I decided to make while researching how 
the camera system in Super Mario Kart works. It is a fun, yet 
very challenging hack that puts a new spin on how you play 
Super Mario Kart!

What is this hack? Well, in the original Resident Evil games, 
a technique was used in order to make the games feasible on 
the system and to introduce an element of horror to the games, 
something called "Perspective Shots". Instead of the camera 
always following the player around in an over-the-shoulder or 
dynamic camera mode, the cameras and views were all in 
predetermined locations around the map showing fixed shots 
of the rooms.

I have applied this principle to Super Mario Kart to make 
this hack! Instead of the camera following you around like 
normal, the camera is in predetermined locations around the 
track and provide fixed perspective shots of the track as 
you drive around it. This absolutely makes the game a lot 
harder to play, and provides an interesting challenge to 
those who wish to take it on! 

I have also added support for the Battle Tracks for 
Battle Mode, so you can play with these perspective shots 
against another player, and see how well you can stretch 
your abilities!


Have Fun! >:D


Special thanks to:
SmorBjorn
Julian Fietkau (for the idea that spawned this)
SMKWorkshop
My supporters
YOU! :D