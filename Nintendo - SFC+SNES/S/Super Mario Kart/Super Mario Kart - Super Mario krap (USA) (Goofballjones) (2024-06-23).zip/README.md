a patch for super mario kart for the snes, you gotta go get yourself a rom though

full of idiotic gimmicks and slight track edits. enjoy
