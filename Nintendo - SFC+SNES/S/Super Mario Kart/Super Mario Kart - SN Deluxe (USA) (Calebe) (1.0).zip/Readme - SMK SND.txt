************************************************** * *****
If you like this mod, leave a review on RHDN
(http://www.romhacking.net)
************************************************** * *****

********************************
Project: Super Mario Kart SN Deluxe
********************************
Game: Super Mario Kart
System: SNES

Super Mario Kart SN Deluxe (SMK Hack)


Authors: Caleb
Release: 08/21/2023

© 2023 Caleb and Luke Novaes
https://discord.gg/6y74TNy9

*******************************************

******
*info*
******

Name: Super Mario Kart - SN Deluxe
Original Game: SMK
Release: 08/21/2023
Author: Calebe
Hack Type: Intermediate
Changes: Graphics and Opening
Genre: Racing
Platform: SNES

A hack created where the tracks are mixed in the Cup, it has its graphics modified with a new opening. In addition to some slight modifications to the tracks.


Opening: Opening created by Luke Novaes, subtitle was added: SN in Super Mario Kart and the name of the author of the hack was inserted.


Cups Name:

Cups:
Caleb's Cup (Mushroom Cup)
Among's Cup (Flower Cup)
Calvo Cup (Star Cup)
Special Cup (Special Cup)

Tracks:
No change.


Graphics: Graphics of tracks and opening.


*****************
*Characteristics*
*****************

- Slightly changed tracks
- Remixed tracks between cups
- New Opening


********
*Channels*
********
Channel Calebe Games Rom
https://youtube.com/@CalebeGoncalvesRom?si=CgyLF1bKn3M8xB2h

Channel Resenhando Com Luke: https://www.youtube.com/channel/UC-ESkikEMlIEXJ_7_KdIrmA/
