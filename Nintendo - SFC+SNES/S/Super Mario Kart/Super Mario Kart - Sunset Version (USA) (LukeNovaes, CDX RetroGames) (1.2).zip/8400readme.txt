****************************************************** ** * *****
If you like this mod, please leave a review on RHDN
(http://www.romhacking.net)
****************************************************** ** * *****

***********************
Super Mario Kart - Sunset Version
***********************
Game: Super Mario Kart
System: SNES

Database Match: Super Mario Kart (USA)
Database: No Introduction: Super Nintendo Entertainment System (v. 20210222-050638)
File/ROM SHA-1: 47E103D8398CF5B7CBB42B95DF3A3C270691163B
CRC32 File/ROM: CD80DB86


Super Mario Kart - Sunset Version 1.2 (SMK Hack).ips


Producer: CDX RetroGames
Release: 01/21/2024

© 2024 CDX RetroGames
CHANNELS: https://youtube.com/channel/UCwxZRTBcwonBjwqP_GinYhQ
https://youtube.com/c/CDXGAMES0382EQS
****************************************************** ** *

******
*Information*
******

Super Mario Kart - Sunset Version is a Project created by Eurípedes do Canal: CDX RETROGAMES.


The main idea was to do a hack totally in the late afternoon mood, as all the tracks from the original game are in daylight.
And with this changed idea, the terrain and Background palettes were changed, creating a very beautiful and interesting sunset mood.



*****************
*Characteristics*
*****************

- New BG's in Sunset Theme
- New Characters Screen


Version: 1.2
- New Podium Screen

