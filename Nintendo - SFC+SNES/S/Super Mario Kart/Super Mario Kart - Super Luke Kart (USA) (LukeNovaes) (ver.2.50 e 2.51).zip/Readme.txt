************************************************** * *****
If you like this hack, leave a review on RHDN
(http://www.romhacking.net)
************************************************** * *****

************************
Project: Super Luke Kart
************************
Game: Super Mario Kart
System: SNES

Works with GOODSNES: Super Mario Kart (US).sfc

Patch1: Super Luke Kart ver.2.50 by Luke
Patch2: Super Luke Kart ver.2.51 by Luke


Author: Lucas Novaes
Release: ver.2.50 and ver.2.51: April 3, 2023

© 2023 Lucas Novaes

************************************************** *

   ******
   *Information*
   ******

Super Luke Kart is a Project I created in a partnership between Canal: Resenhando Com Luke and The World of Hack ROM's Group.


The main idea was to create new tracks to get a nice feeling of playing the original game from new perspectives, but with close quality.

Through this Project I also wanted to bring the members of the Channel and the TWOHR Group closer together, giving them the possibility to create their own track that in the end was part of Hack!

I was very excited about this project, because it worked very well, had a good participation, more than I even expected.

The strong car of Canal Resenhando Com Luke and Grupo: The Word of Hack ROMs have always been like SMK Hacks.


****************
*HOW IT WORKED*
****************

First I was creating the tracks and testing them as I had time.
So, as I said, a space was opened for Group and Channel members who wanted to design a track, send it to me so that it could enter the game.

One of the cups would be for these clues, that is, we would have 5 clues from the members in the Members Cup, but I received more than 5 clues so 3 more clues in the Mix RcL Cup were also for the members. So A Copa Especial (Mix RcL) brought my tracks and those from subscribers, totaling 8 tracks from subscribers and the rest of my authorship. Plus 4 battle tracks I made.

It was done as follows:
Those interested sent a Draft with the raw design of the track and it was up to me to do it in the Epic Edit in the best way possible, some members also sent the completed track from the Epic Edit itself.

I worked on this Project with the Epic Edit and Tile Molester programs, where I managed to make some changes that will be explained below.

*****************
*Characteristics*
*****************

- 20 new race tracks!
- 4 new battle arenas!
- 14 new drivers (8 chosen via polls)!
- New points system!
- New item probability sets!
- New backgrounds!
- Play the Special Cup in 50cc!
- All Cups already released from the beginning!

UPDATES Ver.2.0 and 2.1

-New Opening
- Updated Backgrounds
- New Sprites Characters on the podium
- New Bottom of the Podium Sprites
- New Sprites Crushed Characters
- New character icons
- New Character (Megaman)
- New Battle Balloon Sprites
- New Lakitu Sprite
- New Sprite of Thwomps
- New Cheep Cheep Sprite
- New Possibility of Items
- Fixes on tracks


UPDATES Ver.2.50 and 2.51
- Built-in Mirror Mode Switch

*************
*Characters*
*************

Characters were taken from other hacks, I did a poll on The World of Hack ROMs Group and put some options. Characters were chosen from one of the versions of the hack, but I wanted to have characters from the Super Mario series so I made a version with these characters. So it went like this.

VERSION 1.0 (Chosen via poll in the THOHR Group)
-Ken (Hyper Street Kart)
Famous character from the Street Fighter saga.

- Ryu (Hyper Street Kart)
Another famous character from the Street Fighter saga. OBS: I couldn't change the palettes of the clothes, he got the green belt.

Pikachu (Super Smash Kart)
- Famous character from Pokemon Saga.

- Ronald McDonald (Super NikoNiko Kart)
McDonald's Fastfoods Franchise poster boy

- Plankton (Super SpongeBob Kart)
SpongeBob Cartoon Villain.

- Donkey Kong (Super Smash Kart)
Protagonist of the Donkey Kong Country series, unlike the original game that has D.K Jr. here we put the DK of Donkey Kong Country.

- Bomberman (SMK: Character Chaos)
Protagonist of the Bomberman Series.

- Megaman (IrregularHunters Kart)
This is the protagonist of the Megaman Franchise, a Capcom classic that made history on the NES, SNES and PS1.


VERSION 1.1 (Picked by me from the Super Mario Franchise with a Special Guest)

- Mario (We kept the character from the game)
Main Character of the Series.

- Luigi (We kept the character from the game)
Main Character of the Series alongside his brother Mario.

- ShyGuy (SMK: Bit Hoes Edition)
Enemy from Super Mario Bros. 2 of the American version.

- Red Yoshi (Super Uncle Kart 1)
Friend character you first encountered on Starpath in SMW.

- Bowser Jr. (Created for Epic Edit by R4MON, Sprites by Devicho)
Bowser Jr., or simply "Jr." as he was only initially referred to in his first appearance, he is the son of Bowser, King Koopa's heir to the throne, and is the secondary antagonist of the Mario series. bowser jr. first appeared in Super Mario Sunshine, and has since helped his father to kidnap Princess Peach and battle Mario and Luigi. bowser jr. Some say his mother is Peach...

- Wario (Wario from Thedarkbanshee and patched by Fco64)
Wario is Mario's friend and rival in video games. He is very similar to Mario, and they are considered cousins, a fact stated by Nintendo Power magazine. Like Mario and Luigi, Wario may be Waluigi's brother, a fact that has been confirmed and denied. Contrary to what many people think, Wario is not Mario's enemy or his archenemy, but rather a rival, as Mario's archenemy role was filled by Bowser, the main antagonist of the Mario series.

- Kamek (Created for Epic Edit by R4MON, Sprites by NICK having DS)
Also called Magikoopa, in the most recent games, Kamek is a wizard who lives in a castle according to the "Super Mario Brothers" series, his first appearance was in the Super Mario game Yoshi's Island where he tries to prevent Yoshi from entering the baby room Bowser in the hallway ahead of him. Currently, Kamek has become a villain in his own right (before only taking orders from Bowser) although he still plans plans with Bowser as shown in the game Mario Party.



- Diddy Kong (Created for Epic Edit by R4MON, Sprites by Clutch and fixed by Fco64)
Main character of the Donkey Kong Saga, he stars in the first and second game of the Donkey Kong Country series.


********
*clues*
********

- Lucas track (Circuito Mario)
- Falling Bridge (Donut Plains)
- Boo's Valley (Ghost Valley)
- Zika Beach (Koopa Beach)
- Flood (Chocolate Island)
- North Pole (Vanilla Lake)
- Wreck Castle (Bowser's Castle)
- Space (Rainbow Road)

*******
*Battlegrounds*
*******

- Happy Battle
- Lucas Batalha
- mix battle
- Battle of the Labyrinth


*******
*cups*
*******

- Luke Cup (mushroom cup)
All created by me.

- Top Cup (Flower Cup)
All created by me.

- Members Cup (Star Cup)
Created by Members and Subscribers of the channel Resenhando Com Luke e The World of Hack ROMs

- Mix Rcl Cup (Special Cup)
A mix of My Clues and Clues from Members and Subscribers of the channel Reviewing With Luke and The World of Hack ROMs

********
*Members clues*
********

As I said above, some tracks that are part of Copa Members and Mix RcL were sent by Channel and Group Subscribers, they are:

-Dan Morishima:
Clues:
North Pole 2 (Draft)
Castle Wrecks 3 (Draft)


- Fco64
Clues:
Castle Wrecks 4 (Draft)
Space 2 (Draft)


- Detona-cel
Track:
Castle Wrecks 2 (Draft)


- Lord Moltar
Track:
Bridge That Falls 2 (Epic Edition)


- TheDarkBanshee
Track:
Detonates Castle 5 (Epic Edition)


- CDX games
Track:
Luke 4 Clue (Epic Edition)



*****************
*Beta Testers*
*****************

Below are everyone who received the SLK before everyone else to do the tests and check points for improvement.

- Caleb (Inscribed)
- Gatts Shinobi (Inscribed)
- Ashley Alexander (Inscribed)
- robg1979 (Discord)
- Fco64 (Subscribed/Discord)
- Sandy Mc (Discord)
- Gaby Pinheiro



**************
*Special thanks*
**************
- Icesan/Ice3: Creator of Mirror Toggle.ips, a patch that made it possible to mirror all the tracks, making the game more durable and more fun to play again.

- I would like to thank my subscriber Number 1 Calebe who always watches the videos, regardless of what they are. A big hug for you Caleb.

- Discord Server: SMK Workshop - Guys on this server know too much about every detail of the SMK game, I've been there for a few months and I was amazed with so much information, so much new stuff that is rewarding there every day. It only made my affection and curiosity for the game grow even more.

- Mario Designer - What about the guy who made my eyes shine by showing that I too could hack. That's the guy! First Brazilian who showed how it's done, author of some great Hacks and some really cool fan games. It's worth checking out his work.

- R4MON: SMK Workshop - one of the most active on the server helped me a lot with the sprites created for the Epic Edit format.

- Fco64: Bro firmly has been in the Channel Groups for a long time and always helps with good ideas. In addition, he tested the hack, envy 2 beautifully designed tracks and on top of that he fixed some sprites.

- Dan Morishima: For introducing me to the Discord Servers where we discover thousands of new things.

- robg1979: Hack sharing partner.

- Thedarkbanshee: My Brother also helped me a lot with advice about the Hack, he is also included among the unbelievers who sent hints for the hack. Despite the language barrier, we talked a lot.

- Stifu: who made all of this possible, unraveling all the game's code, creating the Epic Edit. Thanks a lot bro.

- Retro Master HD: a fine friend who is always willing to help. Made me a tutorial on switching palettes that helped me and changed Ryu's clothes that was giving me a headache.


- CDX RetroGames: And of course I couldn't miss the CDX guy that I convert the most and do partnerships in this crazy world of rom hacks. We have some projects that you will soon discover...

***************
*Social media*
***************

zap group:
https://chat.whatsapp.com/KeJ8jtgA5RL5R9Lu2DJnnA

Discord: https://discord.gg/KhtB3J

My Channel Blog: http://resenhandocomluke.blogspot.com.br/

Facebook page: https://www.facebook.com/resenhandocomluke/

The World of Hack ROM's: https://www.facebook.com/groups/638222099844922/

- SMK Hacks
https://ultimatesmkhacks.blogspot.com/

- Blog: The World Of Hack ROM's:
https://theworldofhackroms.blogspot.com/

**********
*Credits*
**********

SLK Characters have been removed from other hacks that will be mentioned below:

- Ken and Ryu (Hack Hyper Street Kart)
The Real Phoenix & Ten Shu

- Pikachu and DK (Super Smash Kart)
TheTommygee37

- Bomberman (SMK: Characters Chaos)
shellfall

- Ronald Mcdonald (Super NikoNiko Cart)
shellfall

- Plankton (Super SpongeBob Kart)
kempy

- Megaman (IrregularHunters Kart)
finished by me

- Shyguy (Created by R4MON)
R4MON SMK Workshop Discord

- Red Yoshi (Super Tio Kart 1)
UncleHector78

- Bowser Jr (Created by R4MON)
Devicho's Sprites

- Wario (Snes Super Mario Kart 64 Plus)
TheDarkBanshee, fixed by Fco64

- Kamek (Created by R4MON)
NICKtendo DS sprites

- Diddy (Created by R4MON and fixed by Fco64)
Clutch Sprites
