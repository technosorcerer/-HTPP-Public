you gotta get the damm super matio kart rom and patch it yourself shithead

A dumbass hack I created in my freetime with horrid track design 
