************************************************** * *****
If you like this hack, leave a review on RHDN
(http://www.romhacking.net)
************************************************** * *****

************************
Project: Super Invisible Kart
************************
Game: Super Mario Kart
System: SNES

Works with GOODSNES: Super Mario Kart (USA).sfc

Patch1: Super Invisible Kart Ver. Yoshi (SMK Hack)
Patch2: Super Invisible Kart Ver. Princess (SMK Hack)
Patch3: Super Invisible Kart Ver. Bowser (SMK Hack)
Patch4: Super Invisible Kart Ver. DK Jr (SMK Hack)
Patch5: Super Invisible Kart Ver. K.Troopa (SMK Hack)
Patch6: Super Invisible Kart Ver. Toad (SMK Hack)
Patch7: Super Invisible Kart Ver. Mario & Luigi (SMK Hack)

Author: Luke Novaes
Release: June 2023

© 2023 Luke Novaes

************************************************** *

  ******
  *info*
  ******

The idea for this hack came up while playing another hack that made everything invisible, all characters, items, obstacles and so on.
I enjoyed playing it but I figured this hack would be cooler if only the player was invisible.
And with that in mind I decided to create the hack.

*****************
*Characteristics*
*****************

- New Opening
- Changed Character Sprite
- Changed Sprite of Crushed Character
- Changed the Character's Sprite on the Podium
- Changed Character Icon Sprite
- Changed Names of Some Characters

*************
*Characters*
*************

Invisible Man
Hollow Man
Hollow Woman


***************
*Social media*
***************

YT Channel: https://www.youtube.com/c/ResenhandoComLuke

SMK Hacks: https://ultimatesmkhacks.blogspot.com/

Whats App Group: https://chat.whatsapp.com/KeJ8jtgA5RL5R9Lu2DJnnA

Blog: https://resenhandocomluke.blogspot.com/

Discord: https://discord.gg/Tbm6mdm

The World of Hack Roms: https://www.facebook.com/groups/TheWorldOfHackROMs/


Launch Trailer: https://www.youtube.com/watch?v=AJFq1yTR5fA