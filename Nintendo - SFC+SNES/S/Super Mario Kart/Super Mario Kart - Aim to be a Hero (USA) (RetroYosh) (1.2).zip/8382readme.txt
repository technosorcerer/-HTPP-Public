* SUPER MARIO KART: AIM TO BE A HERO *

Thank you very much for downloading SMK: Aim to be a Hero. This hack has been a hobby project of mine since February 2023, which by the
time I'm writing this [Jan. 17, 2024], this hack has been in development for nearly a year, which is insane to me. This is my first rom hack
in general, and i am very proud of what I have made for my rom hacking debut. I didn't think i would make it this far into the project, but
after almost a year of developing it, I think it's time to share it with all of you. I really hope you enjoy it. ^^

SMK - Aim to be a Hero includes:
- 20 NEW custom tracks to replace the original game's tracks with
- 4 cups to race through, those being Shittake Cup, Rose Cup, Superstar Cup, and finally Hero Cup
- Altered color palettes for most of the track themes, while a couple remain pretty much the same as the original
- A tweaked scoring system for Grand Prix mode, awarding 9 points for 1st, 7 points for 2nd, 5 points for 3rd, 4 points for 4th,
  3 points for 5th, 2 points for 6th, 1 point for 7th, and 0 points for 8th
- Tweaked item probability so the Feather item is exclusive to the battle mode along with the Boo
- 8 track themes in total, 6 new with 1 being taken from Super Circuit, including Pats Acres, Seaside Beach, Mt. Glacier, Sunset Wilds, 
  Davis Farm, Laboratory, Haunted Cave, and Rainbow Road

Also, to be funny, I renamed all of the characters:
Mario = Chris Pratt
Luigi = Weegee
Princess = Peaches
Yoshi = Gex
Bowser = Godzilla
DK Jr. = Ape
Koopa Troopa = Shellcreeper
Toad = AHHHHHHH

v1.0
- initial release

v1.1
- Adjusted object visibility to reduce the amount of pop in effects
- Moved a few objects to accommodate for the tweaked object visibility
- Changed Princess Peach's joke name to "Peaches"

v1.2
- Added 4 custom Battle Courses for Battle Mode
- Made one turn in Davis Farm 1 slightly easier

SMK: Aim to be a Hero hack was made by Joshie the Retro Yosh

Where to find me:
Twitter/X - @RetroYosh
BlueSky - @joshieretroyosh.bluesky.social
Tumblr - @joshieretroyosh