		#####################
		### GENERAL STUFF ###
		#####################

Hello and thank you for downloading Another SMK Hack!

This hack features 20 brand new courses, 4 new battle courses, new course themes, menus, updated graphics, changed music, etc...

Patch the BPS file to a US rom of Super Mario Kart.

For any questions/bug reports/whatever, send me a message on Discord: @blueyoshi57

		###############
		### HISTORY ###
		###############

It has been a long time since I've wanted to make another SMK romhack... probably since the release of Super BlueYoshi Kart.
So, shortly after the release of Super BlueYoshi Kart, I experimented with other hack ideas, none of which really stuck out, and quickly got abandoned.
In the meantime, I also dabbled in hacking MK Super Circuit, and got pretty good at it... but knowledge in this game is still pretty lacking - I still managed
to release Mario Kart R Advance, a port of the SMK hack, in January 2024! After its release, I took about a year break in romhacking (without any real reason,
I just felt like it)... and then comes June 2025, I had some free time, and my interest in SMK romhacking suddenly comes back out of nowhere. So I made a few tracks, eventually
made some custom graphics, etc... and in only ONE MONTH (seriously, I don't know how I did it that fast), this is where I've ended up at. Way, waaay better
than my previous SMK hacks in my opinion (to be fair, the bar is low).

Enjoy!!

And as always, thanks to the SMK Workshop for being an amazing community!

		#################
		### CHANGELOG ###
		#################

v1.0 - 07/22/2020
	Initial release.