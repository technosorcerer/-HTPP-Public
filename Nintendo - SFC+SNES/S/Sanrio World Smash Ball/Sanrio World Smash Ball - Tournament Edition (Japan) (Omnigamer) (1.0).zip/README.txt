SANRIO WORLD SMASH BALL! - Tournament Edition Hack
Version 1.0 - Initial Release
Author: Omnigamer
Date: 8/27/16

==DESCRIPTION==

This improvement hack was made to expand some of the basic competitive features of the game and make it more convenient for playing against friends or otherwise. Major improvement features include:

-Access to all maps in multiplayer mode. In the original, only 20 multiplayer-specific stages are accessible. This hack enables selection of the 30 stages available in single-player as well.
-More efficient map selection. I added custom handling for up/down inputs in addition to the standard left/right during map selection. Simply press up or down to modify the stage value by 10.
-Full roster available. In normal play, Ebaribuu (Pig) is not normally accessible. Either player can now select him by scrolling down beyond Hangyodon.
-Dummy character playable. In addition to Ebaribuu, there's leftover dummy data for one more character slot. I enabled playing as this character, who has reasonable stats, but is not graphically complete. Thus, you can play as Missingno by scrolling once more below Ebaribuu. NOTE: I have noticed some instability when both players use this character, but have not seen the game hang when just one person is using him. Use with caution.
-You can now select the same character as your opponent. Hooray!
-All powerups now only give full power powerups. This was done for balance purposes; some of the other powerups aren't terribly useful, while the "clear goal" powerup is broken for competitive purposes. May revisit this later.

Listed below is a reference for the individual character stats. In future revisions I may alter these for balance, but have not made any changes in this release.

            H SPD   V SPD   POWER   CHARGE
Keroppi     512     352     928     256
Tabo        544     512     832     285
Pokopon     576     384     736     322
Hangyodon   384     336     1024    232
Ebaribuu    768     512     1280    288
Missingno   576     396     1044    288


==HOW TO APPLY==

The included IPS was designed to work with non-header ROMs and is compatible with both the original (J) ROM as well as pre-patched Suicidal Translations English translation ROMs. It may be compatible with other ROMs as well, but I have not personally tested. Simply use your favorite IPS patcher tool to apply the IPS to your ROM and you should be good to go.

==FUTURE WORK==

I'm pretty happy with the current functionality, and as far as I've tested it is stable. Future releases will likely just address stability issues if any pop up, but as far as remaining features I still have a few ideas:

-Different player colors. Just to differentiate the two a bit better, especially when playing the same character.
-Custom stages. This would take a lot of effort, but I think it could be done if there's significant interest. I may also try to limit the stage list to just the most playable stages for multiplayer to cut down on options overload.
-Character rebalancing. As it stands the characters aren't too terribly different, and there could be adjustments made to fit other playstyles. Another thing I'm thinking of is just across-the-board increasing stats to up the overall play speed. I'll fiddle with that as I try more things though.
-Make Missingno an actual character. With a bit of hackery it should be possible to give Missingno an actual set of art assets.
-General quality of life improvements. ex: Making it so that Ebaribuu and Missingno have their own descriptions.

==CONTACT==

Find a bug or have an idea for next release? Send me a message through ROMhacking.net (user: Omnigamer) or on Twitther (@TheOmingamer).