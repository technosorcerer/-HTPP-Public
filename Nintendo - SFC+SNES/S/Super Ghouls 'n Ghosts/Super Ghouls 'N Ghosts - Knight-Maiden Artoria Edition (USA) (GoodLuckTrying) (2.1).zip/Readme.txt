Super Ghouls 'N Ghosts - Knight/Maiden Artoria Edition (USA) v2.0 - by GoodLuckTrying (https://github.com/GoodLuckTrying)

This is a Super Ghouls 'n Ghosts (USA) sprite hack that changes Arthur's sprites into those of a Maiden/Knight, Artoria.

Survey to determine preferred version: https://forms.gle/6TnRSPFfntWedo8n7

Version 2.1 Changes:
- SRAM + Stage 1 Uncensor patches added for each version. The No SRAM version was moved to the Extra Patches folder.
Version 2.0 Changes:
- Hack is a now a full Knight/Maiden Artoria Conversion.
- Artoria replaces Arthur in credits cutscene and endings.
- Unique "The End" arts for Maiden and Knight Versions.
- Little Arthur walking on map replaced by a Knight/Maiden Artoria.
- Arthur Life Icon replaced by an Artoria Icon.
- Gold Armor's Special Attack flashes are now molded after Artoria.
- Citizen/Knight Dolls & 1-Up are now modeled after Artoria.
- Uncensored dialogue.
- Moved 1 tile for the running animation to fix Frame 4.
- Fixed 1-Up. The counter would reset with every Stage transition, making it nearly impossible to ever get one (As you'd have to sit and farm until near the end of the time limit to see one). First 1-Up is in the 32nd pot, following 1-Ups are after every 48 pots.
Version 1.9 Changes:
- Improved running animation frames for Gray/Purple/Gold Armors
- Cleaned up garbage sprites on Briefs/Nightgown/Gray/Purple/Gold Armors
Version 1.8 Changes:
- Cleaned up a lot of animations (For Briefs, Nightgown Gray and Purple/Gold armors).
Version 1.7 Changes:
- Fixed Sun Basket's color for the "Artoria Edition [Basket and Original Pose]" patch. Now it'll be a blue basket instead of red.
Version 1.6 Changes:
- Incorporated the shield back and made a new idle pose that fits it better.
- New patch added to restore both the original pose and basket.
- Fixes to some sprites.
Version 1.5 Changes:
- Fixed an issue with the Princess Transformation's idle pose.
- Further cleaned floating pixels on other animations.
Version 1.4 Changes:
- Fixed an issue during 1 frame with the running animation of Purple/Gold armors.
- Made the running animation's face for Gray/Purple/Gold armor better.
Version 1.3 Changes:
- Fixed cutscene sprites for Maiden for the two "Dress" versions.
Version 1.2 Changes:
- Every costume  (But the Nightgown/Briefs/Baby Transformation paired with the Gray Armor, these will have dark gray yes) now have blue eyes.
- Costume corrections for the Nightgown and Briefs in the Dress editions.
Version 1.1 Changes:
- Magician will turn player into baby, princess, "bee" and seal using correct colors.
Version 1.0 Changes:
- Dress, Gray, Purple and Gold Armor will have unique sprites for the item drop.
- Fixed up sprites for the armors from the original hack (Had lots of floating particles and hair behaved oddly for a few animations).
- Magician will turn player into Princess instead of Maiden and use correct colors.

Versions:
Knight Artoria Edition [Briefs] (USA)
0: Briefs
1: Gray Armor
2: Purple Armor
3: Gold Armor
Knight Artoria Edition [Nightgown] (USA)
0: Nightgown
1: Gray Armor
2: Purple Armor
3: Gold Armor
Maiden Artoria Edition [Briefs] (USA)
0: Briefs
1: Dress
2: Purple Armor
3: Gold Armor
Maiden Artoria Edition [Nightgown] (USA)
0: Nightgown
1: Dress
2: Purple Armor
3: Gold Armor
Extra Patches:
- Artoria Edition [Basket and Original Pose]

Rom Information: Super Ghouls 'N Ghosts (USA)
Database: No-Intro: Super Nintendo Entertainment System (v. 20210222-050638)
File/ROM SHA-1: F12280B13EEA88CA03D700B75CF3C13A0E13F3BC
File/ROM CRC32: 6AABA901

Tools used:
- Tlp
- Tilemolester 0.21
- HxD
- ImHex
- Photoshop
- GIMP
- Mesen

Credits:
FredYeye - Disassembly, 1-Up Fix and more help than I can list here.
tran4of3 - Artist whose art inspired the armored sprites & artist behind the new "The End" Knight/Maiden arts.
Ren - Artist behind the Citizen/Knight Dolls.
poody - Hacker behind the first version of the girl hack.
SfcStuff - Hacker behind the Japanese version with the first armored hack.
