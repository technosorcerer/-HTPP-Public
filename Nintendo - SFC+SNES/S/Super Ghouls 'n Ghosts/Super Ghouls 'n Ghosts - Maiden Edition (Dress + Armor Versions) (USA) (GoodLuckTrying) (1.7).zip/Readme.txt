Super Ghouls 'N Ghosts - Maiden Hack (USA) v1.7 - by GoodLuckTrying (https://github.com/GoodLuckTrying)

This is a Super Ghouls 'n Ghosts (USA) sprite hack that changes Arthur's sprites into those of a Maiden.

Survey to determine preferred version: https://forms.gle/6TnRSPFfntWedo8n7

Version 1.7 Changes:
- Fixed Sun Basket's color for the "Maiden Edition [Basket and Original Pose]" patch. Now it'll be a blue basket instead of red.
Version 1.6 Changes:
- Incorporated the shield back and made a new idle pose that fits it better.
- New patch added to restore both the original pose and basket.
- Fixes to some sprites.
Version 1.5 Changes:
- Fixed an issue with the Princess Transformation's idle pose.
- Further cleaned floating pixels on other animations.
Version 1.4 Changes:
- Fixed an issue during 1 frame with the running animation of Purple/Gold armors.
- Made the running animation's face for Gray/Purple/Gold armor better.
Version 1.3 Changes:
- Fixed cutscene sprites for Maiden for the two "Dress" versions.
Version 1.2 Changes:
- Every costume  (But the Nightgown/Briefs/Baby Transformation paired with the Gray Armor, these will have dark gray yes) now have blue eyes.
- Costume corrections for the Nightgown and Briefs in the Dress editions.
Version 1.1 Changes:
- Magician will turn player into baby, princess, "bee" and seal using correct colors.
Version 1.0 Changes:
- Dress, Gray, Purple and Gold Armor will have unique sprites for the item drop.
- Fixed up sprites for the armors from the original hack (Had lots of floating particles and hair behaved oddly for a few animations).
- Magician will turn player into Princess instead of Maiden and use correct colors.

Versions:
Maiden Briefs + Dress + Armor (USA).ips
0: Briefs
1: Dress
2: Purple Armor
3: Gold Armor
Maiden Briefs + Full Armor (USA).ips
0: Briefs
1: Gray Armor
2: Purple Armor
3: Gold Armor
Maiden Nightgown + Dress + Armor (USA).ips
0: Nightgown
1: Dress
2: Purple Armor
3: Gold Armor
Maiden Nightgown + Full Armor (USA).ips
0: Nightgown
1: Gray Armor
2: Purple Armor
3: Gold Armor
Extra Patches:
- Maiden Edition [Basket and Original Pose].ips

Rom Information: Super Ghouls 'N Ghosts (USA)
Database: No-Intro: Super Nintendo Entertainment System (v. 20210222-050638)
File/ROM SHA-1: F12280B13EEA88CA03D700B75CF3C13A0E13F3BC
File/ROM CRC32: 6AABA901

Tools used:
- Tlp
- Tilemolester 0.21
- HxD
- ImHex
- Photoshop
- GIMP

Credits:
poody - Hacker behind the first version of the girl hack.
SfcStuff - Hacker behind the Japanese version with the first armored hack.