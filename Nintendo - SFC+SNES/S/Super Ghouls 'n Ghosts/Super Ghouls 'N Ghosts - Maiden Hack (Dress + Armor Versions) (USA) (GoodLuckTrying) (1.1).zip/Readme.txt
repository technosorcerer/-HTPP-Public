Super Ghouls 'N Ghosts - Maiden Hack (USA) v1.1 - by GoodLuckTrying (https://github.com/GoodLuckTrying)

This is a Super Ghouls 'n Ghosts (USA) sprite hack that changes Arthur's sprites into those of the maiden.

Version 1.1 Changes:
- Magician will turn player into baby, princess, "bee" and seal using correct colors.

Version 1.0 Changes:
- Dress, Gray, Purple and Gold Armor will have unique sprites for the item drop.
- Fixed up sprites for the armors from the original hack (Had lots of floating particles and hair behaved oddly for a few animations).
- Magician will turn player into Princess instead of Maiden and use correct colors.

Versions:
Maiden Briefs + Dress + Armor (USA).ips
0: Briefs 
1: Dress
2: Purple Armor
3: Gold Armor
Maiden Briefs + Full Armor (USA).ips
0: Briefs 
1: Gray Armor
2: Purple Armor
3: Gold Armor
Maiden Night Dress + Dress + Armor (USA).ips
0: Night Dress
1: Dress
2: Purple Armor
3: Gold Armor
Maiden Night Dress + Full Armor (USA).ips
0: Night Dress
1: Gray Armor
2: Purple Armor
3: Gold Armor

Rom Information: Super Ghouls 'N Ghosts (USA)
Database: No-Intro: Super Nintendo Entertainment System (v. 20210222-050638)
File/ROM SHA-1: F12280B13EEA88CA03D700B75CF3C13A0E13F3BC
File/ROM CRC32: 6AABA901

Tools used:
- Tlp
- Tilemolester 0.21
- HxD
- ImHex
- Photoshop

Credits:
poody - Hacker behind the first version of the girl hack.
SfcStuff - Hacker behind the Japanese version of this armored hack.