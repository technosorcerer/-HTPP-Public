             So Little Garden
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Metroid Construction - A.N.T.I. Contest Entry
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Apply to clean, unheadered ROM
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



~~~~~~~~~~~~~~~~~~~~~~~
Hack Author: MetroidMst
~~~~~~~~~~~~~~~~~~~~~~~
Testers:
Black_Falcon
Jordan5
Vismund
~~~~~~~~~~~~~~~~~~~~~~~



~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Special Thanks and Contributors:
Quote58      - HUD and less teeth
Black_Falcon - All kinds of ASM/Tileset/Testing
SMILEuser96  - All kinds of ASM/Random help with questions
Metaquarius  - All kinds of musics
Scyzer       - All that Shaktool
Jordan5      - All kinds of testing and roomstate knowledge
Crashtour99  - Double Jump is really rad
DSO          - The rooms have names and some ASM help
Coffee       - You are delicious
Jathys       - Camera advice
Personitis   - Ending % even though I had to change it again for reasons?
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



                    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    ---A.N.T.I. Contest Rules---
                    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
1. The hack must contain at least 15 but no more than 30 in-game rooms.
   * Save, refill, map, and boss rooms don't count toward room total.
2. At least one boss fight must be present.
3. The hack must end with the credits. How they're triggered is up to you.
4. No restrictions on assembly and graphics.
5. Upon submission, you must leave a description of how your hack ties into
   the themes which you've chosen (see Thematic Rules below) either in your
   submission post or in a readme.
6. If you're using Super Metroid, it is an absolute requirement to have
   Scyzer's improved ending percent asm applied and working properly to the
   hack. Alternatively you may write your own code for it, as long as when
   100% of the items are collected, the ending displays such.
7. Give credit where it's due and have fun!
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  In addition to the above rules, you must choose at least 3 of the following
thematic pairs which will decide what your hack is to be based around. After
choosing at least three, you must then use one option from each pair (for
example, if you choose the Past/Future pair and use the Past theme, the Future
theme is off limits).

                             THEME CHOICES:
                         Past         -   Future
                         Forest       -   Desert
                         Gloomy       -   Cheerful
                         Ascent       -   Descent
                         Alternative  -   Constraint
                         Enter        -   Escape
                         Collection   -   Sparsity
                         Mystery      -   Clarity
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

             ~~~~~~~~~~~~~~~~~~~
             ---THEME CHOICES---
             ~~~~~~~~~~~~~~~~~~~

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                  ---FOREST---
  The hack takes place in a very foresty type
area, with a lot of lush plant life.


                  ---Future---
  The hack is also very futuristic looking
with the tileset I cobbled together.


                ---Constraint---
  I constrained myself to one whole tileset!


                ---Collection---
  As always, I enjoy collecting items. Since
the size of the hack is very limited, I wanted
to make sure to hide plenty of items.


                 ---Mystery---
  Because people are on the edge of their seat
waiting to see what kind of terrible thing I
throw at them in this hack!
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



                    ~~~~~~~~~~~
                    ---STORY---
                    ~~~~~~~~~~~
  Every 13 years the Shaktools throw a universal
party deep in the Shakazon Brainforest, in order
to celebrate the blooming of the Toolip flowers.
Normally, most people stay away, as Toolip pollen
is quite potent and has caused more symptoms than
prescription drugs in all who are exposed to it.
  However, after the Space Pirates failed in their
last attempt to change a Geemer into a planet-
eating monster, in which the Geemer ended up with
four more eyes and no mouth, Ridley decided that
even a peaceful event with Shaktools could be 
beneficial. So Ridley headed a small group to try
to collect some Toolip pollen while they are being
treated to a great party.
  Toolip pollen has many potential uses, as reports
of those who have been exposed to it reveal many
different effects, making it a valuable item to any
game's plot. Toolip pollen has been said to cause 
any other creature to become half-invisible, warp
time and gravity, affect physics in very specific
circumstances, and in one odd case, cause irrital
bowel sundrome in two unrelated grasshoppers.

  Shaktools are generally nice, so they called a 
truce with Samus as long as she accepts the
invitation to join their party. Unfortunately, they
don't have good editors, and worded a sentence 
about target practice rather poorly. So Samus sees
a paper that calls for a truce if she partakes of
target practice on the range of locality.
  Taking this as an open invitation to wipe out an
innocent species, Samus packs very quickly, 
completey forgetting to take along any items beyond
five extra Energy Tanks, and heads to the Shakazon
Brainforest. . .

  Will the Shaktools ever truly be able to experience
peace with Samus around?
  Are they too naive to see the Space Pirates just 
want the pollen to do more tests and take over the 
galaxy with it?
  Did the Shaktools really just set an elaborate trap
to crush their enemies in one swoop?
  














               ~~~~~~~~~~~~~~~~~~
               ---NEW ITEM USE---
               ~~~~~~~~~~~~~~~~~~

ROCKET BALL:
  This includes many different items in one
It is Spring Ball and Boost Ball combined into
item. However, it also has another feature as well,
If you boost into a wall, you will bounce off of it.
If you hold against a wall, you will constantly climb
up that wall.


               ~~~~~~~~~~~~~~~~~
               ---NEW HUD USE---
               ~~~~~~~~~~~~~~~~~

  The HUD has experienced some changes. To change your
Beams on the fly without pausing, press item-cancel.
  Item select works as usual, to switch between Beams,
Missiles, and Grapple.














