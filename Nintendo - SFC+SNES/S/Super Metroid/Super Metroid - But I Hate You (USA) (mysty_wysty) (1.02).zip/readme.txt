Just a silly little halfhack I made as my first ever romhack :3

Tech 100% REQUIRED to beat game:
  -Same wall jump
  -Alcatraz
  -Infinite bomb jump
  -Crumble block jump
  -Geemer Clip
  -Short charge (mild)
  -BSoH (Bad Sense of Humor)
  -Phantoon RNG Manipulation
  -Bomb Torizo Skip (is this just listed here for the bit? Play to Find Out)
  -L,R,L,R,L,R,L,R,L,R,L,R,L,R,L,R,L,R,L,R,L,R,L,R
  -Turbo Button
  -Arthritis
  -Sudoku
  -Reverse Chozo Sweep
  -Brainbuster

Notes: 
  -This romhack has strong language and sexual themes, and would be considered ESRB rated M (or PEGI 18 for you bri'ish people) if it were actually an official game. If you are going to stream it on Twitch, set your "mature content" info or whatever accordingly (they can get mad if you don't). Figured I should mention this because it's not particularly common in Super Metroid romhacks.
  -There is one puzzle in Maridia which you might either find too difficult or too boring to solve, so I've provided a solution in the PuzzleHelp_Spoilers.zip file (included inside the main download zip) just in case. If you look at the solution that's a certified Skill Issue though.
  -There could potentially still be some bugs with this romhack, but it's fully playable with no major issues as far as I know.
  -I hate you.

Update v1.02:
  -Fixed an early Norfair side path not showing up on map.
  -Fixed Norfair Business Center Reception Desk Entrance mistakenly having the wavy heat background effect.
  -Added visual tell for a hidden missile tank in the ceiling somewhere in Brinstar.
  -Fixed softlock in Wrecked Ship.
  -Fixed issue where rooms overlapped on map and made it look like there was an item dot inside Crocomire Speedway.
  -The above change will make one room in Norfair become unexplored on the map on existing 1.00 / 1.01 saves, but entering the room will mark it as explored again if it bothers you.
  -Known issue: Kraid's tail visibly wraps around to left side of room sometimes. I don't feel like fixing it right now lol.
  
Update v1.01:
  -Fixed Brinstar missile room showing up as the wrong map square location on the minimap
      -This change may mess up Brinstar map completion on existing save files as a result, but it is possible to go back and re-explore the rooms if that bothers you.
  -Fixed bug where some channels of the music in the game's finale would get stuck panned far to one side (making the songs sound weird).
  -A certain part of the game asking you to input a certain button combination is now optional, with a new dialogue box for failing to do so within 10 seconds.