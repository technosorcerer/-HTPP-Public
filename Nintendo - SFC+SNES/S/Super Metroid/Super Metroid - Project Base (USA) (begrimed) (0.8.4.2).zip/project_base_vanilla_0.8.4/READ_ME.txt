
PROJECT BASE
a Super Metroid ROM hack by begrimed and Quote58 (and many others)

version 0.8.4 -- august 11, 2025

INFO / DOWNLOAD PAGE:
http://www.begrimed.com/pb

WHERE TO REPORT BUGS:
discord: https://discord.gg/0iHi0pCvigksYLPf
metconst forum topic: http://forum.metroidconstruction.com/index.php/topic,217.0.html
email: begrimed@gmail.com



=================================
==== ABOUT PROJECT BASE:

Project Base is a Super Metroid mod (“ROM hack”) with smoother mechanics, extensive level edits, graphical touch-ups, programming changes, new content, and much more. It can be played on Snes9x, higan/BSNES, ZSNES, repro carts, SD2SNES, SNES Classic Mini, and probably anything else that is able to load Super Nintendo games.

The difficulty level of Project Base is roughly the same as Super Metroid's difficulty level, which means that completing the game does NOT require any glitches or advanced techniques (not even walljumps). The current release is stable and fully playable.

"Vanilla" leaves Super Metroid's engine/movement completely untouched. It has no extra code features or special colors, and only the map is changed.

If you don't like spoilers, you should play it now before reading any more information about it.

Don't know how to play it? The easiest way is to download a SNES emulator, open the emulator, and then open the Project Base .SMC file in the emulator. Wanna play it with a controller or your SNES console? SD2SNES (more expensive) and repro carts (less expensive) are good options. For emulators, most USB controllers will work.



=================================
==== IMAGERY
Project Base-related graphic edits and logo artwork.



=================================
==== OLD VERSIONS
See how far we've come, and wonder how far we've yet to go.



=================================
==== CONFIG PATCHES
Old and mostly obsolete. Use at your own risk.
Can be applied to vanilla Super Metroid and most hacks.



=================================
==== PROJECT BASE CREDITS:

LEVEL DESIGNER:
begrimed

PROGRAMMER:
Quote58

CODE / TOOLS / INFO:
Quote58, Scyzer, AmoebaOfDoom, TestRunner, Kejardon, Jathys, Black Falcon, Drewseph, PJBoy, Slyandro, anomie, nocash, Near, MathOnNapkins, deskjockey, DSO, suku, JAM, Crashtour99, PHOSPHOTiDYL, DChronos, personitis, Kazuto, Daltone, Smiley, begrimed

GRAPHICS:
begrimed, RealRed, Charmander106, Albert V, Quietus, bob, Quote58, dewhi100, TROM, RedM0nk3y, P.Yoshi

COLOR PALETTES:
begrimed, RealRed, Quote58, Albert V, Drewseph, Jiffy, Metaquarius, Tundain, Digital Mantra, Cardweaver, P.Yoshi, YP, DSO, Vismund Cygnus, Crys, TROM, InsomniaDX, mccad

FEEDBACK & BUG REPORTS:
Stunt_MK, LinkaMeister, Hubert0987, Galamoz, FusionWarrior, Roza, thatzachguyx, bob, Xerclipse, CaptainSwag101, Sirkura, countgooby, interdpth, Thorben, MetroidMst, mrguyaverage, gloobygloob, Black_Falcon, Gespachio, Zylus, Devaliah, Miranda Gemini, Kazuto, AlbertV, Aran;Jaeger, LCA, Xsczo, JAM, Silver Skree, Yuki, Thorben, Dessyreqt, foosda, FPzero, personitis, Aran;Jaeger, Hiroshi Mishima, MetroidMst, Nekoishi, Kn0p3XX, SirAileron, Quietus, Weterr123, Grahf, ShadowOne333, CeruCap, ScoutTown, MrBlueDork, Duopierce, Skorph2014, marsfromvenus, Exister, 62c514a6, VidelLSWFan

SPECIAL THANKS:
The PB speedrunning community has clocked countless hours streaming, routing, finding bugs, and promoting the game. Future versions will be much more polished because of your work.

Charity marathons that feature Project Base are great. Hopefully ROM hacks as a donation incentive will keep gaining momentum.

suku for creating Vanilla++, which inspired me to create the first version of PB

AdvancedPillow for the Project Base and Hollow Eve/B2-TW cartridge sets!

And THANK YOU to everybody else who takes their time to play PB, mention it to others, report bugs, post opinions, and do things.



=================================
==== CHANGES SINCE VERSION 0.8.1:

- Brinstar cosmetic update + area expanded + rooms reworked
- Crateria expanded + rooms reworked
- Tourian cosmetic redesign + area expanded
- Wrecked Ship expanded + first room reworked
- New shortcuts and connections between areas
- 20 new enemy types added
- Extra enemies added to most rooms
- More color variety for enemies and rooms

- Updated alternate vanilla version available ("project_base_vanilla_0.8.4.ips")

- Climb portion of Zebes Escape reworked
- Dash Ball item area reworked
- Slightly shorter enemy-respawn timer (from 64 frames to 48)
- Buffed Spore Spawn, Kraid, Botwoon and Ridley
- Crateria: animated scenery grass added to some spots
- Crateria: animated scenery bugs added to some spots
- Undid edited beam graphics (ingame alt beam graphic options are planned)
- Restored Crateria/Samus theme playing during Hyper Beam sequence
- Differenciated Reserve/Energy Tank colors (R-tanks = orange, E-tanks = pink)
- Differenciated Echo/Charge/Shinespark colors instead of all blue (thanks Roza)
- No default song for Blue Brinstar rooms
- Charge Beam location swapped with nearby Energy Tank; water + PB block removed
- Missile above Charge Beam moved to another spot nearby
- Early-early Crateria Supers are now possible
- Cinematic elements restored (elevator rides, boss intros/deaths)

- New connector: Shinespark from Below Spazer to Red Elevator
- New connector: First Power Bombs to Red Tower
- New connector: Crateria-Maridia ("Griffin-Clarke Connector")
- New connector: Draygon-Elevator
- New connector: Phantoon-Elevator ("Dragnet Connector")

- New pick-up: Missile in Southwest Brinstar Connector
- New pick-up: Super Missile in Wrecked Ship-Maridia Connector
- New pick-up: Power Bomb in Crateria-Maridia Connector ("Griffin-Clarke Freeway")
- New pick-up: Missile in western Green Bullshaft Room

FIXES:
- Fixed flashing background in non-starry parts of Crateria when collecting items
- Fixed occasional flash of blue in Tourian's palette during Zebes Escape
- Fixed escape steam enemy's animation/timing (thanks Roza/guyaverage)
- Deleted escape steam from Landing Site to reduce lag (and because they're annoying)
- Deleted some enemies in Kraid's lair to reduce lag/clutter
- Deleted some Space Pirates in Tourian Escape Room 4 to reduce lag
- Separated Space Pirates in Tourian Escape Room 3 to reduce lag
- Removed Brinstar's chainblocks temporarily until bugfixed
- Camera behavior fix: Blue Brinstar near Rio Missiles
- Camera behavior fix: entrance to Wrecked Ship Bowling Chozo room
- Camera behavior fix: hallway to Maridia turtle family room
- Camera behavior fix: escape hallway (thanks FusionWarrior)
- Map fix: Super Missile room wasn't shown as a separate room (thanks Exister)
- Map fix: Power Bombs after Crocomire WAS shown as a separate room (thanks Exister)
- Applied "Kraid Vomit" bugfix by PJBoy
- Map fix: missing item dot for Missile in Wrecked Ship's Reserve Tank room
- Metal door index fix: Ridley Energy Tank room
- Fixed instance of auto-morph not working in room before Hi-Jump (next to Missile)

MORE COLOR VARIETY + PALETTE SHOUT-OUTS FROM OTHER HACKS:
- Palettes from 20 different hacks mixed into certain spots
- CRATERIA: Redesign, Arrival, Z-Factor, Nature, AngryFireChozo, Chopped And Screwed
- GREEN BRINSTAR: Ancient Chozo
- PINK BRINSTAR: Hyper Metroid
- RED BRINSTAR: Hyper Metroid, Project Base 0.7
- NORFAIR: Verticality, Y-Faster, Cider, Opposition, Nature, Redesign, Ice-Metal Uninstall
- WRECKED SHIP: YPR, Hyper Metroid, Eleven, Sunshine Oddity
- MARIDIA: Vitality, Super Junkoid, Lost World, Suber Meptroid
- And several rooms with partially-blended vanilla palettes

NEW ENEMY TYPES ADDED THROUGHOUT THE GAME:
- Hyper Metroid's Mini Phantoon added to Wrecked Ship
- Hyper Metroid's Large Armored Sidehoppers added to Brinstar/Maridia
- Hyper Metroid's Armored Wavers added to Lower Norfair
- Hyper Metroid's Skultera Fish resprite added near entrance to Lower Norfair
- Super Junkoid's Mero resprite added to Wrecked Ship
- Zelda 3's Bubble/Anti-Fairy added to Tourian
- Zelda 3's Spike Trap added to Tourian
- Hydellius's Large Sidehopper resprite added to Tourian
- Phazon's Viola resprite added to Lower Norfair
- Custom Bull added to Wrecked Ship ("BULLEYE" - bull+eye-flame)
- Custom Sidehopper added to some spots in early Crateria ("DESHO" - desgeega+hopper)
- Custom Ripper added to Norfair and Maridia ("TARA" - "tearer" as in "ripper")
- Custom Ripper added to Tourian ("SQUIJILLI")
- Custom Holtz added to Tourian ("ZOLEBZ" - zebesian+zeb+holtz)
- Custom Rinka added to Tourian ("CIRKA" - circular movement)
- Custom Buyon added to Tourian (unused Mother Brain "PAC-MAN" graphics)
- Custom Geemer added near Wrecked Ship ("GEETCH" - geemer+owtch)
- Custom Fireflea added to Crateria ("FLEAGA" - fireflea+dessgeega)
- Custom Atomic added to Norfair ("BIULAC" - bubbles+viola+atomic)
- Custom Atomic added to Lower Norfair ("BATONG" - bang+atomic)

SMALL LEVEL EDITS FOR BETTER FLOW/VIBES
- Added a pink door + respawning Geemer to first Missile room
- Added a green door + respawning Geemer to first Super Missile room
- Added a yellow door + respawning Geemer to first Power Bomb room
- Made some elevators longer to stay more accurate to the map
- Reverted elevator speeds to what they originally were
- Removed pointless metal door in Mickey Mouse room
- Moved green door near Ice Beam closer to the item + backdoor ice enabled (thanks Roza)
- Removed green door below norfair elevator room (index $00B4)
- Removed some blocks next to Mickey Mouse Missile (Waver needed space)
- Yellow door changed to pink in Climb room
- Yellow door changed to green in Crab Maze
- Green door changed to pink in Green Hill Zone
- Thin platforms for Crateria Mainstreet
- Slightly longer delay until Bomb Torizo's door closes
- Brinstar mockball room adjusted to suggest Dash Ball
- Shortcut by door to Kame turtle room
- Big Pink Shinespark shortcut in front of green door
- Shortcut in front of Spazer room
- Shortcut in Red Brinstar First Power Bombs room into Red Tower
- Removed ugly hill in Crateria gauntlet
- Booster blocks added next to Missile in Maridia near Botwoon (thanks Roza)
- Booster block shortcut added to Zebes escape
- Small edit to Lower Norfair Red Ripper room
- Morph shortcut in room before Ridley
- Small edit to red hallway below Spazer
- Small edit to Ice Beam item room
- Small edit to Lava Dive room
- Easier ceiling access to new Brinstar Missile (thanks Exister)
- Black background for Mother Brain's room (thanks Exister)
- Removed unseen foreground clutter from some rooms
- Tile error fix: accidental air slopes near Norfair Reserve Tank (thanks FusionWarrior)
- Safer access to certain save stations
- Made that one Skultera Fish in Maridia orange again (thanks FusionWarrior)
- Removed floor/ceiling Shutter enemies from the room after Mother Brain
- Extra Morph tunnel next to Super Missiles in east Wrecked Ship room
- Gave Northwest Maridia Bug Room a bit of extra space
- Added a platform below Blue Brinstar Pipe Shortcut Missile (thanks MTZPyrakid)
- Added a Dash Ball bridge to hidden Maridia entrance in Red Brinstar (thanks Roza)
- Bomb block changed into shot block in old Mother Brain Pit Room
- Bomb block changed into shot block in Green Brinstar elevator room
- Bomb block changed into shot block in Crateria Climb
- Bomb block changed to shot block behind First Missiles
- Bomb block changed to shot block in Kraid's Lair
- Certain items placed inside scenery rather than sitting out in the open
- Absolutely more stuff that I forgot to write down, sorry

REMOVED NEEDLESS/MISLEADING SPEEDBOOSTER BLOCKS (SHORTCUTS REMAIN):
- Brinstar elevator room
- Norfair elevator room + small room directly below it
- Wrecked Ship crab room
- Grapple rooms
- Noob bridge room

KNOWN BUGS INTRODUCED IN 0.8.0:
- !Doors close too close behind Samus; easier to get stuck inside blue caps pre-morph
- ?Dash Ball + echoes takes damage after falling from ledges (exacerbated vanilla bug?)
- A metal door copies itself to room ceiling above door to draygon's room under some conditions
- [harmless?] Practice HUD has graphical errors after loading a saved game in Tourian
- [harmless?] Shooting the ceiling in Fireflea room before X-Ray can spawn bombable blocks
- [harmless] Title screen year still says 2020; can't modify without significant code changes
- [harmless] Unable to run across frozen buyons (fixed via level design rework)
- [harmless] Occasional slightly glitchy Samus gfx when entering doors (going right only?)
- [harmless] Save stations occasionally misplace samus by 1 or 2 tiles
- [harmless] AUTO MORPH: Running into certain corners with aim-down held can trigger it
- [harmless] AUTO MORPH: Fails to work under some conditions (e.g. touching PLM)
- [harmless] ?Bottom red kihunter in room near Lower Norfair shortcut sometimes only spawns wings

- [vanilla] incorrect acid-rising sound in mother brain room stops music; harmless
- [vanilla] title screen and Ceres are unedited for now

--------------------------------

0.8.2 - 0.8.4 credits:

OmegaDragnet7: playtesting, feedback, bug reporting, troubleshooting, immense hostility
PJBoy, neen: troubleshooting
Roza: playtesting, routing, bug reporting, feedback
FusionWarrior: playtesting, bug reporting, routing, feedback
Stunt_MK: playtesting, feedback, bug reporting, artistic execution
Exister: playtesting, feedback, bug reporting, area colors
62c514a6: playtesting, bug reporting, feedback
VidelLSWFan: playtesting, feedback
----
RealRed: area graphics, enemy graphics, the power of friendship
P.Yoshi: area graphics, enemy graphics, area colors
TROM: enemy graphics, plasma room colors
RedM0nk3y: enemy graphics
Jiffy: area colors
Digital Mantra: area colors
Drewseph: area colors
Albert V: area colors
Metaquarius: area colors
DSO: area colors
Tundain: area colors
mccad: area colors
YP: area colors
Cardweaver: area colors
Vismund Cygnus: area colors
Crys: area colors
InsomniaDX: area colors
