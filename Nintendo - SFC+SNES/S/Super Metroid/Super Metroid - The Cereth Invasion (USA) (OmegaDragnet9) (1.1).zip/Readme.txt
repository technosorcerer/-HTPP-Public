---------------THE CERETH INVASION---------------------------
-------------------OmegaDragnet9-----------------------------

--------------Changes since 1.0------------------------------

08-23-2024

CHANGELOG ver. 1.1:

Ceres B is a brief, but playable area in the beginning of the game.

Tried to implement as much feedback as possible.

Map has legend system to explain new icons.

Ugly door palettes are corrected.

Ammo system is balanced now:

Missiles spend 1 	contribute 5
Supers spend 5,		contribute 10
Power Bombs spend 5, 	contribute 20

Total ammo should be 195 in this revision.

Removed duplicate Space Jump.



--------------------------Story------------------------------

First entry in the "Wrath of Kraid" series. Takes place after the events of Dread.
(Kraid is not in this game. He's a larger player in the next one.)

Planned prequel to this is "Houston's Big Day" which takes place during the events
of Metroid 3, and shows what Armstrong Houston was doing behind the scenes and why
he's not present anymore.

-----------------------Gameplay-------------------------------

Physics are overhauled. To see how much you can scroll down to ASM credits. 
Massive spoilers.

Respin
Momentum Keep
Fixed Space Jump
Universal Ammo System
Benox50's Easy Walljump
Benox50's Collision Clearance
BlackFalcon's Morph Flash
Kejardon's AutoRun button (If you so choose to enable this.)

World is pretty open. That being said you can get yourself into a tight spot.
That doesn't mean I'm expecting you to do advanced tech.

If you find yourself in what feels like a hellrun, that means you should probably
turn back and go look around some previously explored areas some more.

(You ever get lost, look at the map. I have markers to indicate clues to help with this now.)
Enemies that are too strong are another indicator you should look for more upgrades.

----------------Changes from Contest Version------------------

07-2022-2024

CHANGELOG

-Implemented more level feedback in a few rooms per playtester feedback.
-Added Refill Stations to a particular room
-Slowed down credits speed slightly.
-Revised some potential spoilers in the end credits to harmonize with both endings.
-Replaced one of the ending music tracks with one I felt worked better.
-Title Reads "Wrath of Kraid I" because it could easily be read as "Wrath of Kraido." lol
-Fixed horrible gray door problem in a certain boss room that was introduced in the previous beta update.
-Map shows slightly more of the area to encourage exploration.

07-14-2024

CHANGELOG:

-Fixed horribly broken map.
-Added sprites which indicate you've entered a screen with a gate. This should help keep up with gates.
-Added sprites which indicate there is a significant secret
you might want to revisit later, as people were skipping significant upgrades and having a terrible time later. 
-Fixed tiling errors. 
-Added more to do with Speedbooster (per starlightintheriver.)
-A certain gate now has a brighter trigger button (per felixwright.)
-Spacejump is now fixed regardless of whether Gravity Suit is equipped or not.
-Fixed obtuse wall in the Eastern Wing that people thought they needed to walljump off.
-Boiler Area is finished now. 
-Ridley music is fixed. No longer sounds like he has a cold. 
-Gate added to the Void to prevent people from going back the way they came without unlocking a gate.
-Some dialogue is changed.
-Fixed music-less room in the Lower Recesses. 
-Restored SBA functionality to the Universal Ammo system (my fault, as I commented Tundain's code out in another project that I was attempting to make work with the Spazer/Plasma beam combo, a patch I have long since abandoned due to technical challenges.)

--------------------------Assembly----------------------------

Amoeba	-Ceres Enable
	-Kejardon's Auto Run
	-Mapscroll
	-Room Names
	-Scyzer's Footstep Effects
	-FF Events and Tubes

Benox50	-Chain Spark
	-Extended Event PLM
	-Collision Clearance
	-Easier Walljump

Begrimed
	-Various Hex edits for missile/super missile intervals, bomb intervals, and spacejump intervals.
	-The SMMM was invaluable for this hack.

BlackFalcon
	-SpinjumpRestart With Morph Roll (AM2R Charge Walljumping by PHOSPHOTiDYL)
	-Skip Ceres
	-Transparency Fix
	-Tractor Beam Speed Doubled
	-Morph Flash (with some tweaks by Quote58)

Crashtour99
	-Title Sequence Tweaks

dewhi100
	-Better Room Cleared Event PLM

DSO	-Processing Tweak

Flamestar666
	-Stop Beam Trails hex tweak
	-Speed of Charge Shots

FullOfFail
	-Draygon Destruction Timer (Credits to JAM, Scyzer, and Insom.)

H A M 	-Faster Startup
	-Fix Walljump Graphical Y Offset and Hitbox
	-Charge While Spinjumping

JAM	-Messenger PLM
	-Draygon Destruction Timer Unset Code
	-Event Gray Doors (I wrote the code for this, but very likely has some overlap with JAM's)
	-FF Events and Tubes

Kejardon
	-Block Remover (In code but not utilized yet.)
	-Decompression
	-SuperMissileFix (with JAM)
	-SpeedBooster Springball

MetroidNerd#9001
	-Event Triggers From Killing Enemies (part of this ended up in various Event ASM
as well as the Enemy AI for the Metroids)

Mentlegen
	-Thicc Plasma GFX
	-Run in Lava or Acid

Moehr	-Silence Baby Metroid

Nodever2
	-Full Door Cap Rewrite
	-Heatbit
	-Landing Speed (Credits to Scyzer and Cauuy)
	-Speed Booster Vertical Momentum Fix
	-No Morphball Bounce
	-TorizoSpeed (not utilized in this project but it's in the code.)

PHOSPHOTiDYL
	-No Morph Bomb Spread
	-Pickup Sound Skip
	-Skip to Credits and Display Completion Time at the End
	-Easy Title Screen Logo
	-Various Boss Event Bits Documentation
	-Use Ridley Anywhere

Scyzer	-Saveload
	-Ending Totals
	-MultiCRE (mostly not utilized.)

Smiley
	-Starting Items
	-Botwoon Wall Removal Code

Tundain	-Spinning Flair
	-Remote Gates
	-Suit Based Shinespark Damage
	-Universal Ammo
	-Botwoon Wall Removal 

----------------------UTILITIES--------------------------------

Amoeba/TestRunner
	-SMART
Scyzer	-SMILE RF
YY	-YYCHR
Sour	-MesenS
xkas	-byuu/near
LunarIPS
	-fusoya

--------------------------MUSIC--------------------------------

AlbertV
	-Cyberspace
	-Sector3 PYR 
	-Lost Ancient Ruins
	-Art Gallery
	-Hall of Monsters

Metaquarius
	-Metroid 4 Prologue
	-Metroid 2 SR388 Surface 
	-Future Base (Kottpower)
	-Alternate Zebes Green Brinstar

Super Metroid FTP
	-Phantoon's Curse (Kottpower)

------------------------GRAPHICS-------------------------------

GF_Kennon
	-Rustworks
	-Space Pirate Frigate
BlackFalcon
	-Space GFX
Jefe962
	-AM2R's the Tower
Amoeba and TestRunner
	-Spritemap for Room Names
RealRed
	-Metroid Prime Suits
Mentlegen
	-Thicc Plasma GFX

-----------PLAYTESTERS-------------------------

felixwright
MetroidMST
Ob
Oi27
RT-55J
starlightintheriver
somerando cauuy
roebloz

Special thanks to somerando caauy for assisting with troubleshooting with Varia Suit music. 

