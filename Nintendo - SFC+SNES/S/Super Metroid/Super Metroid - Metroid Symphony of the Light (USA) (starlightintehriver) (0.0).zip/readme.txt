Metroid - Symphony of the Light (Demo)
by starlightintheriver

	When a distress signal interrupts Samus's grocery trip, she immediately rushes to find the source.
Haumea Station, a high-energy laboratory owned by Exelion, has fallen into disarray. Since the station
was working on warp-drive technology, it's unlikely that the perpetrators would be either the Galactic
Federation or the Space Pirates- it must be a new threat.

-----------------------------------------------------------------------------

Major credit to the lovely folks of the Metconst discord for answering my stupid questions, including:
	-Tundain
	-Ob
	-oi27
	-RT-557
	-neen
	-Nodever2
	-P.JBoy
	-ponch
	-AmoebaOfDoom
	-H A M
	-Onnyks
	-cauuyjdp
	-Exister
	-Smiley
	-TestRunner
	-noxus365
	
Also, thanks to the following users for their ASM:
	-Nodever2
	-BlackFalcon
	-Ob
	-PBase
	-Phospho
	-Benox50
	-oi27
	-H A M
	-squishy_ichigo
	-Kazuto
	-Tundain
	-AmoebaOfDoom
	-Scyzer
	-MFreak
	-MarioFanGamer
	-MoogleEmperor
	-noxus365
	-P.JBoy
	-SMILEuser96