This is a halfhack I made specifically for one friend which originally was not going to be released publicly, but I changed my mind. 
It's a troll hack full of inside jokes for that aforementioned friend as well as jokes that poke fun at Super Metroid hacking as a whole, featuring many references to obscure and highly-specific things, intentionally poorly designed rooms, baffling design choices, and an utterly psychotic amount of custom assembly to create an utterly unhinged and bizarre playthrough of Super Metroid. 

Notes: 
  -This hack requires you to be able to same wall walljump, infinite bomb jump, and mockball.
  -To break out of knockback, mash the L and R buttons. Successfully doing so will play a sound and give you extra invulnerability frames.
  -This romhack has swearing and lewd jokes, so enable the appropriate rating options on Twitch if you wish to stream it.
  -If you have trouble with the second of the two puzzles in Maridia, see PuzzleHelp_Spoilers.zip file (included inside the main download zip). If you do, that's a certified Skill Issue though.
  -I hate you.

Update v1.11:
  -Fixed bug where dialogue skip introduced in v1.10 did not work half the time.
  -Fixed bug where screw attacking Draygon could cause the fight to stop working properly.
  -Added even more hinting for "Colosseum" puzzle solution.

Update v1.10:
  -space colon (most important change)
  -Added "Skill Issue Trooper" to tell players about mashing L and R to get out of knockback.
  -Fixed various places where hitting a spike respawned you at the start of the room (due to respawn triggers not existing yet).
  -Fixed bug where you could still take damage during the spike respawn animation.
  -Fixed bug where knockback cancels early when auto reserve tanks activate (this also fixes a bug where the "red" and "blue" status effects on final boss could get incorrectly stored and re-activate suddenly when not expected).
  -Fixed bug where knockback was inescapable in morph ball.
  -Added feature for all dialogue to skip faster if you encounter it again without turning the game off and then die such that it causes the text to wanna show again or whatever.
  -On a certain puzzle, changed text saying to press R for "help" to say press R for "info" instead, so it's clear it's not going to give you a solution or troll you (all it does is tell you the controls and basic rules).
  -Made it more clear in one of the puzzles that you should use bombs rather than shooting it.
  -Made the door to escape "Colosseum" room no longer require killing all enemies.
  -Made solution to "Colosseum" room puzzle less cryptic.
  -Added missing item dot on map for Draygon boss door room.
  -Various small fixes and improvements to room tile placement.
  -Reduced the damage of gold and orange space pirates.
  -Updated a joke in "Ridley E-Tank Room" to actually be funny.
  -Buffed Ridley defense and damage.
  -Removed save station after ninja pirates.
  -Removed option to display Japanese text because I have no plans to translate to Japanese.
  -Fixed incorrect palettes when final boss flashes white both when taking damage and when doing that other thing that makes him flash white (spoilers).
  -Final boss Blue Orb heavily nerfed.
  -Final boss Yellow Orb slightly nerfed.
  -Final boss Red Orb status effect now takes priority over and cancels the Blue Orb status effect and not the other way around, instead of both red and blue overriding each other all the time.
  -Final boss main body and spikes do the same contact damage now instead of the spikes doing 50% more damage than the rest of the body, because this didn't come across very obviously and felt a bit inconsistent. The damage value chosen is also lower than the average damage it had before, so this is a nerf.
  -Corrected Suku's name in credits.

Update v1.04:
  -Knockback nerf
  -Phantoon nerf
  -Final boss nerf
  -Fixed tile errors in some rooms.
  -Fixed some map screen errors in Norfair and Maridia. Just like the previous map fixes, existing saves will get the affected rooms marked as unexplored.
  -Fixed softlock when sparking across "Spiky Acid Snakes Tunnel" without Grapple Beam.
  -"Grapple Jump Cavern": Fixed camera locking when you let the <event> sequence play out to the end before exiting the main portion of the room.
  -"Grapple Jump Cavern": Made a certain skip easier to do.
  -Fix infinite spike respawn softlock in water room after Grapple Beam.
  -Fixed entrance door to Crocomire's room getting messed up sometimes.
  -Fixed "rich loser" boss being freezable if you don't use Wave Beam.

Update v1.03:
  -Fixed a softlock just before first "Missile".
  -Fixed camera scroll getting stuck if you begin to ascend the hidden path in Halfie Room then change your mind and go back down.
  -Fixed softlock in "Botwoon Speed Hallway" in Maridia
  -Fixed bug where Kraid tail wrapped around sometimes and was visible on left edge of room.
  -Slightly adjusted layout of post-Crocomire room to prevent vanilla Grapple Beam related glitches.
  -Fixed severe 0.0001 FPS slowdown when charging a beam and going through a specific door in specific endgame scenario (if you know you know).

Update v1.02:
  -Fixed an early Norfair side path not showing up on map.
  -Fixed Norfair Business Center Reception Desk Entrance mistakenly having the wavy heat background effect.
  -Added visual tell for a hidden missile tank in the ceiling somewhere in Brinstar.
  -Fixed softlock in Wrecked Ship.
  -Fixed issue where rooms overlapped on map and made it look like there was an item dot inside Crocomire Speedway.
  -The above change will make one room in Norfair become unexplored on the map on existing 1.00 / 1.01 saves, but entering the room will mark it as explored again if it bothers you.
  -Known issue: Kraid's tail visibly wraps around to left side of room sometimes. I don't feel like fixing it right now lol.
  
Update v1.01:
  -Fixed Brinstar missile room showing up as the wrong map square location on the minimap
      -This change may mess up Brinstar map completion on existing save files as a result, but it is possible to go back and re-explore the rooms if that bothers you.
  -Fixed bug where some channels of the music in the game's finale would get stuck panned far to one side (making the songs sound weird).
  -A certain part of the game asking you to input a certain button combination is now optional, with a new dialogue box for failing to do so within 10 seconds.




(Original v1.0 launch description is as follows:)

Just a silly little halfhack I made as my first ever romhack :3

Tech 100% REQUIRED to beat game:
  -Same wall jump
  -Alcatraz
  -Infinite bomb jump
  -Crumble block jump
  -Geemer Clip
  -Short charge (mild)
  -BSoH (Bad Sense of Humor)
  -Phantoon RNG Manipulation
  -Bomb Torizo Skip (is this just listed here for the bit? Play to Find Out)
  -L,R,L,R,L,R,L,R,L,R,L,R,L,R,L,R,L,R,L,R,L,R,L,R
  -Turbo Button
  -Arthritis
  -Sudoku
  -Reverse Chozo Sweep
  -Brainbuster