I wanted to make a sequel to Kero, but it would take a long time to complete, so I made a demo instead.

I didn't give out any hints.

The previous game was terrible, so I made a hack ROM while taking into account my mistakes.

________________________________________________________________________________________________________

Special Thanks

https://metroidconstruction.com/

Resources

Music

Graphics

Patches 

