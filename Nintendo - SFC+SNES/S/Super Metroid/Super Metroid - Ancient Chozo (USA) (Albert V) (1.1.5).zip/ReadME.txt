Ancient Chozo is an expansion of the original Game
that contains the original Super Metroid Map layout with
extra largest new rooms and areas locations, plus new routes to find.


It has new GFX in most of the areas and new palettes,
Ancient Chozo started from Project Base Hack, but it's not the same,
it has new color palette for the entire game, and even more places to explore plus
new custom enemies, moves, puzzles, music, and some few more stuff
The new routes makes the game more interesting and more fun to explore.
My intention was to keep the original route of Vanilla and add some new routes that can curious players could find,
and also the players with good skills can break the Game Sequence.
The gameplay now rewards both types of players,
those who likes going faster,can now beat the game faster than cause they have new shortcuts and new routes to travel between each area much faster!
On the other hand,those who like exploring or breaking the game sequence, now gets most of the upgrades and power ups! Although it's a task not to easy to perform!
Chozo Hack focused on Explorations and most of the original items locations has been changed!
There's a lot of new secrets to discover, new areas, new rooms and no longer have the help of the X-Ray vision, but there's a new feature find them, so the players 
can feel curious finding  new secrets and upgrades using a different method, so that makes the adventure even more interesting and enjoyable.
I've have added more rooms and more areas also new gfx and  I'll be adding some more in future versions.

Ancient Chozo Hack is my First Project!
I always wanted to have a different Hack with the same map but much more to explore using new and rearranged graphics
with some extra stuff like new music and more puzzles.
So I just wanted to share some of that.
I really like the feeling of loneliness and the  ambience in the Metroid series, the ruined places like chozo ruins abandoned spots, it's atmosphere, and the strange creatures, specially  the race of the chozo.



  
  
  
                      ** BIG THANKS TO GRIME ** 
                                     
- New Shinesparks Control can now steered left/right or up/down
- New Instant Bombs make bombs explode instantly with no jump (only works on the ground)
- New Tractor Beam (updated) charge beam attracts energy/ammo much faster and smoother than before




FEATURES:
- The intro story text can be fast-forward pressing a button.
- New -- Power bombs have now the ability to reveal special blocks!
- New -- Frozen enemies can be destroyed using shinespark or screw attack!
- Red bristar is back! and a new custom tileset has been used for kraid area.
- New Secret Rooms added on Brinstar and Maridia, Some items are now on this rooms.
- New Custom Music Background on Brinstar and a new section extension of Maridia.
- New Suit palette, now with the one was equipped when the game was beaten.
- New Puzzles, even more than version 1.1.0.
- New Mechanics as moving and falling platforms.
- New Rooms, and new areas added.
- New Color palette for the entire game.
- New Samus Suit sprites + palette added.
- Modified Enemies & Bosses including palettes.
- Faster Doors, Elevators, Rooms transitions & item-collection sequences.
- Detail on this Areas: Brinstar Upper/Lower, Maridia, and Norfair Upper-Lower.
- New Beams sprites and sparks Animation edited.
- Item Fanfare Has Been Restored to the Original Sound but doesn't prevents samus for keep moving freely.
- Explosion Sound Has Been now Restored to the Original Sound.
- New Graphics Added to Brinstar and maridia.




MOVES:
- New Diagonal Bomb Jump -- Bombs now thows you to a considerable distance! -- Place a bomb and slightly move to the side where you want to be thrown, Now Killing Enemies on its way! (Now optional)
- Instant bomb explosion -- place a bomb and hold down for an instant explosion, preventing samus to jump in ball form!.
- Project Base Psychics Modified.
- RESPIN -- Press jump button at any time during normal fall to resume spinning.
- BACK FLIP -- While crouched, hold run, then press & hold jump + back button.
- BOMB SKIP -- Hold down button to avoid bomb jumping.
- QUICK MORPH #1 -- Hold item cancel + press down button to instantly morph.
- QUICK MORPH #2 -- Hold L + press down button, this only works in the air.
- DEMORPH JUMP -- Until Spring Ball is equipped, holding run allows spin-jumping straight out of ball form!
- SPEED BALL -- With Spring Ball equipped, Samus gains the ability to run at full speed as a ball
- UP SPIN -- While standing still, hold run button to easily spin-jump straight up
- SPIN FALL -- Hold jump button as you fall from a ledge to flip automatically


FIXES:
- Permanents Stucks has been fixed.
- Glitched Palettes on some items-Fixed, thanks to Grime :)
- Some messing Sprites on Samus Suit has been fixed.
- Soft and solid blocks has been fixed in most of the areas.

CHANGES SINCE VERSION 1.1.0:
- Samus in the intro story has been restored.
- The intro story text now sounds much better than before.
- Edited -- less health on some Bosses and enemies.
- Faster fight with spore spawn mini boss.
- Many spikes were removed and  its damage has been reduced.
- I have removed Some yellow doors making the game less lineal now.
- some wall spikes were removed, letting the player to perform wall jump freely to get early stuff.
- 2 new custom songs has been added.
- Much more not listed yet.

CREDITS AND BIG THANKS:
-#Grime, Moehr, StuntCoyote, AnarchyGuitarist, Scyzer, Black Falcon, Realred, Smiley, Mccad00, Quote58, Shannon Cross,
  Geo Korf & Metaquarius
  For troubleshooting, resources, Publicity and gameplay testing.

Also thanks to The Metroid Construction Community!