Houston Saves Halloween.

Version 1.1
November 1st, 2025

Changelog:

1.) Fixed a game-breaking bug where detonating 4 obstacle enemies at the same time as a door transition was preventing the next room from loading. This affected the endgame. Now it is impossible to duplicate the bug as the enemy count in both rooms has been reduced. Fortunately nobody seems to have been affected, yet...

2.) Changed the way a certain barrier enemy behaved. No longer vulnerable to Power Bombs. However, I have added it to be weak to uncharged shots now, as well as normal missiles. (This became apparent after watching Cauuy's playthough.)

3.) I fixed the horrible scrolling bug that was in a certain room near the Level 1 Hatch station. Now the room should behave better when going back in.

Contest Version
October 31 2025

OmegaDragnet9

Music credits to Mentlegen, Metaquarius, and Albert V.

GFX by Kennon, Jiffy and others. 

Thanks Conner for putting this together.

Thanks Radium/Mentlegen for being generous with the borrowed suit palettes and music.

ASM, a lot of people included in the game's credits.

NEW MOVES:

Hold B to make elevators go faster.

Hold L when pressing down for instant morph (borrowed from Project Base.)

A whole lot of borrowed Project Base physics stuff.

