Thank you for downloading super metroid freadom-3.

#The concept of this hack
As in the previous and previous two hacks, you can attack from any map.
terrain, and almost all red, green, and yellow gates,
blue/green shutters have been eliminated.

#Major Changes
　The colors of things other than Samus are changed by VARIA Customizer.
　The appearance of Samus has been changed by myself.
The name of the area which can be seen on the pose map is changed.
Almost all of the room topography has been changed.
The time it takes for a bomb to explode has been changed.
The behavior is like a two-step jump under the following conditions: 1.
　1. Falling from a scaffold without jumping.
　2. Deactivate morph ball in mid-air
　3. Take damage (does not occur when damage boost is activated)
　*It can be triggered underwater if the conditions are met.
　　Also, if you are aiming diagonally or up/down, it will not trigger even if the conditions are met.
Space jump control has been simplified.
　You can continue to jump even if you hit jump repeatedly.
The following actions can now be performed during a shine spark
　During upper shine
　　Left/Right directional key: Shift to left/right shine
　　Down arrow key: Morph ball (Bombs and P-bombs can be used)
　During Left/Right Shine
　　Up arrow key : Shift to upper shine
　　Left/Right Directional Key ：Change direction of Horizontal Shine
　　Down arrow key : Morph ball (Bombs, P-bombs can be used)
　　LR key ： Adjust altitude
　If you use this well, you will be able to speed run.
　If you hit the up and down thorns while in the ball state, you will turn into a blue suit.
　If you are not good at controlling the ball, try to find thorns and turn it into a blue suit.

#About the attached file
There is a text file called Challenge to enjoy this hack over and over again.
You can try it if you like.
Also, the patch "fall jump.IPS" is a randomizer, etc.
It allows double jumps outside of this hack.

#What we use
Shinespark Control　Black Falcon様
Varia customizer    theonlydude様

This file and the challenge file are translated using DeepL translation.