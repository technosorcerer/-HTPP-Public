gossamer: a super metroid romhack by neen

the "special fx" (special effects) option, located in the special setting menu (replacing the "icon cancel" option), toggles a feature where some rooms alternate layer blending code every frame. this looks best on original hardware on a crt, or on emulators where you can be sure that the game is running at 60fps. when recording gameplay or streaming, you may want to turn this option OFF. if you are photosensitive, proceed with caution, or you may want this option OFF.

level design and hack concept by neen

patches used:
Skipping Ceres by Black Falcon
FF events and tubes by JAM
Instant Pickups by Oi27 et al
Save / Load by Scyzer
Custom Scrolling Sky by AmoebaOfDoom
Edit Special Settings Menu by InsaneFirebat
Suit Aura by Oi27
Water and Acid Tilemap Fix by Black Falcon
Ending Totals by Scyzer
Less Tedious Tilemaps by OmegaDragnet7
...and other assembly programming done by neen

play testing:
Digital Mantra
caauyjdp
RT-55J

additional music:
reversed original SM music by Scottrick

with excerpts from:
The Love Song of J. Alfred Prufrock by T.S. Eliot
The Conqueror Worm by Edgar Allen Poe

special thanks:
Super Metroid Mod Manual by begrimed
Super Metroid Automagical Repoint Tool by TestRunner and Amoebaofdoom
Everyone in the discord for your programming help and encouragement.

Shoutouts:
Etaoin Shrdlu
Loren Ipsum
Alan Smithee
Polly Esther