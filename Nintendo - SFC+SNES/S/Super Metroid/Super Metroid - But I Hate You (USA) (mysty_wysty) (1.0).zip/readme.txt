Just a silly little halfhack I made as my first ever romhack :3

Tech 100% REQUIRED to beat game:
  -Same wall jump
  -Alcatraz
  -Infinite bomb jump
  -Crumble block jump
  -Geemer Clip
  -Short charge (mild)
  -BSoH (Bad Sense of Humor)
  -Phantoon RNG Manipulation
  -Bomb Torizo Skip (is this just listed here for the bit? Play to Find Out)
  -L,R,L,R,L,R,L,R,L,R,L,R,L,R,L,R,L,R,L,R,L,R,L,R
  -Turbo Button
  -Arthritis
  -Sudoku
  -Reverse Chozo Sweep
  -Brainbuster

Notes: 
  -This romhack has strong language and sexual themes, and would be considered ESRB rated M (or PEGI 18 for you bri'ish people) if it were actually an official game. If you are going to stream it on Twitch, set your "mature content" info or whatever accordingly (they can get mad if you don't). Figured I should mention this because it's not particularly common in Super Metroid romhacks.
  -There is one puzzle in Maridia which you might either find too difficult or too boring to solve, so I've provided a solution in the PuzzleHelp_Spoilers.zip file (included inside the main download zip) just in case. If you look at the solution that's a certified Skill Issue though.
  -There could potentially still be some bugs with this romhack, but it's fully playable with no major issues as far as I know.
  -I hate you.