Version 1.2

11-21-2025

Changelog:

Added PHOSPHOTiDYL's Item % and In Game Timer to pause screen.

Updated the Respin/MorphRoll Table to eliminate the glitchy break out of respin when holding angle and jump (thanks RealRed for the tips.)

Problematic Gray Door in the Great West Maintenance Hall has finally been modified.

Cereth Mainframe East Gate has a more crumbly broadcast to discourage backtracking.