Super Mario RPG - Double XP
Aug. 15th 2023
BillyTime! Games
--------------------
This is a fun and simple patch designed for Super Mario RPG - Legend of the Seven Stars that doubles the amount of experience earned after every fight.

How to Patch:
--------------------
1.Grab a copy of Super Mario RPG - Legend of the Seven Stars (USA).sfc
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file