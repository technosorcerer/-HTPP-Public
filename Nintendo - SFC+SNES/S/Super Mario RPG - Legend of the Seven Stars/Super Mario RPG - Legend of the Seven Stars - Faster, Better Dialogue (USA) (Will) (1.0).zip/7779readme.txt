Hold down B to advance through text faster. 



Code by Doomsday31415

Feel free to use for making hacks!