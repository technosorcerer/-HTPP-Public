Super Castlevania IV - Cv 1 Font & Icons
By MathUser
v1.0

This is a hack which changes the font and HUD to resemble that of CV 1. It
changes the HUD font to be like Castlevania 1 and also the font. The Simon
sprite is recolored and CV1 style item icons have been added.