Super Bomberman 4 (Lenha)

Description

This hack was created with one goal in mind: to make Battle Mode more fun, fresh, and competitive than ever before!
It introduces redesigned stages, new and extra power-ups, pre-activated passwords, secret content unlocked, and several gameplay tweaks.

Whether you’re a casual fan or a seasoned Bomberman player, this version brings new life to Super Bomberman 4 multiplayer battles.

Features

Stages
Brand new themes for all stages
• Stage 2: clock animations removed
• Stage 3: audience removed from the sides
• Stage 7: bushes removed
• Stage 10: Honey & Kotetsu cosplay removed
• Secret stages 11 and 12 unlocked

More Items
• Increased item count in stages 1, 2, 3, 4, 6, 7, 9, and 10
• Extra items added: Bomb Pass, Pierce Bomb, Full Fire, 1-Up, Select Item, and Time
• Select Item: customized
• Time: freezes the match timer for a few seconds
• 1-Up: added but has no effect in Battle Mode

Pre-activated Passwords
• 0164 → Unlocks extra mounts (Swin, Haguhagu, Crazy Balloon, Bobo, Ponpon, and Daruman)
• 7777 → Winner becomes the Golden Bomber

Skull Items
• 3 Skull items per stage
• Includes a hidden effect that swaps player positions (not present in the original game)

Normal Game Tweaks
• Player 1 = Bazooka Bomber
• Player 2 = Jet Bomber
• Black Triceradops included

Other Changes
• Start button disabled during matches in both Battle Mode and Normal Game

How to Patch

Obtain a clean ROM of Super Bomberman 4 (Japan) with the following checksum:
SHA-1: FF580E5A990B1EB4026FDC3669EC6F4A750B6309
CRC32: 3BBAEB19
(No-Intro, headerless dump)

Apply the included .bps patch to the ROM using FLIPS (Floating IPS).

Do not ask for or share ROMs — only the patch is provided.

Credits
• Hack by Lendario

Special Thanks
• slidelljohn – for helping with several resources and improvements in this hack
• Robert Hart (Bavi_H) – for helping disable the pause function in the game

This project would not have been possible without their support and knowledge.

Additional Information
• This hack was developed by Lendario for the Bomberman community.

For multiplayer competitions, gameplay showcases, and Bomberman 4 online battles, check out my YouTube channel:

Batalha dos Players

🇧🇷 Brazilian channel dedicated to organizing Super Bomberman 4 online multiplayer competitions.

👉 YouTube.com/BatalhadosPlayers

.