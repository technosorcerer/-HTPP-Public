This patch will only unlock the two Battle Mode hidden stages. It also works with the Svambo english patched ROM.

Enjoy.

Made by denim and Tedenfe - http://www.romhacking.net.br/