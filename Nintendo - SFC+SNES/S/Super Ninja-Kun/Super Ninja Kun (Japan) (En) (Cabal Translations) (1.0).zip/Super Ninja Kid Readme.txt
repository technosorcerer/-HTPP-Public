==========================================================
=====================Super Ninja Kid======================
=========================V 1.00===========================
Genre: Platformer

Source language: Japanese

Platform: SNES

Patch language: English

Author: Pennywise

E-mail: antoniusblocko@protonmail.com
		
http://yojimbo.eludevisibility.org/
 
======================================================
About
======================================================
Project History:

This translation is the same one that was featured on
that Jajamaru Collection. The ROM is already floating
around after someone cracked the game, so this patch
will basically turn it into that.

======================================================
Patching Instructions
======================================================
Patch is in IPS, BPS and xdelta formats.

Apply the patch to the Japanese ROM:

Super Ninja-kun (Japan).sfc

We would be highly grateful, if you find some time to 
contact us with proposals or corrections. Information
on found bugs or corrections would be highly 
appreciated.

P.S.

Support the game industry by buying used games!

Even if the money doesn't go to the developers
directly, as the games become rare and harder
to find, the price goes up, and people become
more inclined to buy new releases "while they can!"

======================================================

Credits go to:

Pennywise - hacking

Ryusui - translation

FlashPV - graphic design

All those who contributed into this process.

======================================================


Compiled by Pennywise. November 2025