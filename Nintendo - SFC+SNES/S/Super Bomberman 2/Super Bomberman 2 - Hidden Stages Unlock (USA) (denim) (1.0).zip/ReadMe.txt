This patch unlocks all Battle Mode hidden stages.

Enjoy.

Made by denim and Tedenfe - http://www.romhacking.net.br/