Instructions: apply the SFCbuttons patch, marked in perpetual BETA, to an original "Super Mario RPG: Legend of the Seven Stars" SNES ROM with your patching method.

This simple hack is explicitly designed to replace the North American palette of the battle and Bowyer buttons with the more colorful Japanese version.

It was intended to be built in Super Mario RPG: Legend of the Seven Stars ~Rebrick Time Capsule~, but was split due to introducing at least one minor aesthetic bug.

The issue: Magikoopa's fireball projectile graphically corrupts when he demonstrates it in Rose Way. No other aesthetic glitches were spotted, but there may be more.

The solo version may theoretically be applied to other hacks, but since the patcher will likely warn or stop it, there is a two-in-one version that includes Rebrick Time Capsule.

Apply it if the buttons are more important to your experience, but if someone finds the cause of this issue and corrects it in a standalone update, you may use that patch instead.

Above all, support the official release. ~"LiThL"