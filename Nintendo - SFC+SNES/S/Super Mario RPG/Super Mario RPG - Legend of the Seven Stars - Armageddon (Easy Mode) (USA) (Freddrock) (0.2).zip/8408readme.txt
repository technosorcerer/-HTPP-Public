Super Mario RPG - Armageddon (Easy Mode)
____________________

Hi!

Thanks for checking out this rom hack for Super Mario RPG Armageddon. 

This is an easy mode for Super Mario RPG Armageddon. The stats changed will allow the player to feel stronger on the attack and on defense. Full details in the Improvements sections below.

FULL credit goes to DarkKefka and Doomsday31415 for the original Armageddon rom hack. The version used for this patch is 10h2. Please use the rom hack as the base for this patch.

Improvements:

v0.1
_____

- Base attack values of every party member raised by 3x dependent on current level
- Magic attack values of every party member raised by 2x dependent on current level

v0.2
_____

- Base defense values of every party member raised by 3x dependent on current level
- Base magic defense values of every party member raised by 2x dependent on current level
- Defense timing values returned to original Super Mario RPG values for more leniency.

Installation instructions:
_______________

Patch the .ips file onto the base NORMAL rom hack of Super Mario RPG: Armageddon. The rom hack can be found here:

https://www.romhacking.net/hacks/6665/
