"Mario RPG ReGoogled" romhack by: Hangedman

***

v3 Update:
Fixed a couple missed joke phrases and a couple missing Psychopath translations.

***

This is an updated version of FantaKuat's "Mario RPG Google Translate" romhack, with the goal of making it generally stream-safe.

Retranslations were made to remove real-world references (except for some expressions), and anything real overt.
Also added translations for location names, and other assorted things that didn't get translated.

>> The 'no-butts' patch has no swearing and no clear innuendo.
>> The 'some-butts' patch does have swearing and innuendo.

You can tell which patch you're using on the file select screen, in the upper-right corner: on the some-butts patch, there's no space between the two Ss in 'KISS'. Useful mistake.

If you want to patch these easily, use https://www.marcrobledo.com/RomPatcher.js/.

***

If for some reason you don't like these changes, here's the original -

Original "Mario RPG Google Translate" romhack by: FantaKuat
Original romhack license terms: Repost & Edit as you like, just don't claim as your own.
Original romhack available at: https://www.romhacking.net/hacks/4490/