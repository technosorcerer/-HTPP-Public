Super Mario RPG - Armageddon (White Text Color)
____________________

Hi!

Thanks for checking out this rom hack for Super Mario RPG Armageddon. 

This improves the text color for dialogue boxes and menus in Super Mario RPG Armageddon for Normal and Hard modes. They were hard to read before and this makes it easier to sit further away from the screen if needed.

FULL credit goes to DarkKefka and Doomsday31415 for the original Armageddon rom hack. The version used for this patch is 10b2.

Improvements:

1.0
_____

- Updated all dialogue text to be white. Previous text was a dark blue with a blue background and you could not read the text at all. This makes it easier and much more tolerable.
- Updated all menu text to be white. Again the text was an off blue and hard to read so the update was much needed.

Installation instructions:
_______________

Patch the normal or hard mode .ips file onto the Super Mario RPG: Armageddon rom hack found here:

https://www.romhacking.net/hacks/6665/
