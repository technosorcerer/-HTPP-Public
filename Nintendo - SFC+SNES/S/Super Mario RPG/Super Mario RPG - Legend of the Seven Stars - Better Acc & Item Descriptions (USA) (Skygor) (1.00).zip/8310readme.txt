Super Mario RPG - Legend of the Seven Stars (US) Better Acc & Item Descriptions
Skygor a.k.a. Tiro DvD
December 20, 2023
v1.00


Several non purchasble accessories have other abilities than those listed in the description such as reducing elemental damage. (I'm dissapointed the remake didn't address this.) This is a simple patch that lists all the abilities of accessories and a few others hopefully in the stype of the original translation.


Accessories Changed
-----------------------
Amulet               1/2 ele damage
Attack Scarf         Prot. KO
B-tub Ring           1/2 ele
Ghost Medal          Perma Def/Mdef buff
Jinx Belt            Prot. KO
Quartz Charm         Perma Atk/Mag Def/Mdef buff, Prot. KO
Saftey Badge         Prot. all status
Saftey Ring          Prot all status, KO., 100% ele damage
Troppa Pin           Perma Atk/Mag buff


Items & Misc Changed
-----------------------------
Kerokero Cola mentions FP healed.
Lazy Shell and Super Suit prot. all status, 100% ele damage
Rewrote Power Blast, Bracer, Energizer, Crystalline, to be consistent of single/party atk/def.
Corrected Fright Bomb to be single target.



History
1.00 - first patch


To Do
Possible formatting adjustments.