░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒

       -- Manall's Waluigi RPG --
        https://manallsmods.net

▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░


Hello! Thank you for trying my mod.

Waluigi is, shall we say ... underappreciated at time of writing. I believe the future will see an end to this, and to kick those days off I have created a love letter to our rose-loving antihero.

Super Mario RPG should be regarded as one of the best games of all time. The story, setting and characters combined with innovative gameplay are still inspirational to me today. It also paved the way for a few fantastic Paper Mario games, and THANK GOD Nintendo has finally begun remastering these!

Enjoy or die.


░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
                                
             Getting Started
             ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯
▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░


Apply my .ips patch to a headered*, unmodified SMRPG rom file, grab an SNES emulator and you're set to play. I prefer SNES9x.

Just don't torture yourself by using ZSNES.


░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
                                
                 Credits
                 ¯¯¯¯¯¯¯
▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░


giangurgolo......for the Lazyshell editor, and subsequent heart palpitations

Yakibomb.........your wacky form of creativity

slidelljohn......help with bugfixing


░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
                                
                Vault
                ¯¯¯¯¯
▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░

So you wanna open that vault, huh?

...
...

You'll need the password. Yep, it's still a Mario game after all.

And for THAT, you'll have to track down a key hidden somewhere in the game.
Keep your eyes open, and you'll undoubtedly find other new cool stuff along the way.