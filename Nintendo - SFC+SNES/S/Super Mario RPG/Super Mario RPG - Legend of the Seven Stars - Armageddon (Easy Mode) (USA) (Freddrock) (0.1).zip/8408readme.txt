Super Mario RPG - Armageddon (Easy Mode)
____________________

Hi!

Thanks for checking out this rom hack for Super Mario RPG Armageddon. 

This is an easy mode for Super Mario RPG Armageddon. It increases the base attack values and the magic attack values so that missing the "second timing" doesn't feel so defeating.

FULL credit goes to DarkKefka and Doomsday31415 for the original Armageddon rom hack. The version used for this patch is 10h2. Please use the rom hack as the base for this patch.

Improvements:

1.0
_____

- Base attack values of every party member raised by 3x dependent on current level
- Magic attack values of every party member raised by 2x dependent on current level

Installation instructions:
_______________

Patch the .ips file onto the base NORMAL rom hack of Super Mario RPG: Armageddon
