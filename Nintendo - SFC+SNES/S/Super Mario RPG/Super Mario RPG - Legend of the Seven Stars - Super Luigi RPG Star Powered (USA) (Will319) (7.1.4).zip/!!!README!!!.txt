Hello! Hope the reader's day is going well, I'm here to help you out on how to play this!

The version number is 7.1.4, if it isn't that, yet it has this file, you probably got this from the wrong place.
I'd personally recommend a full virus scan.

Don't expect me to give you a copy of SMRPG, though. I'm not particularly keen on having Nintendo having trained snipers aimed at me!



First, get a legally obtained copy of Super Mario RPG Legend of the Seven Stars on SNES!

-NOTE: No, we will NOT provide one for you, if you can't find one, tough luck.

Second, apply one of the 2 patches included in this folder onto it with Lunar IPS!

-NOTE: Only apply one at once! If you're going to use the other, use different copies!

Third, check the copy in SNES9x V1.60 (Perhaps future versions will work too, but if you want to be confident, use 1.60!)

-NOTE: If the SNES9x bootup text is yellow, something went wrong while patching! You'll need to redo it, and try a different copy of SMRPG!

-SECOND NOTE: IF PLAYING ON SNES9x, DISABLE CHEATS. EVEN IF YOU HAVE THEM DISABLED, REMOVE ALL CHEATS FROM THE PROGRAM, CHECK APPLY CHEATS AND UNCHECK APPLY CHEATS. OTHERWISE MANY ASM CHANGES WILL NOT WORK!

Fourth: Put the patched copy where ever is most convenient for how you wish to play, and hopefully enjoy!