░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒

      --- Manall's Wa7uigi RPG ---

▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░

Hello! Thank you for trying my mod.

Super Mario RPG should be regarded as one of the best games of all time. The story, setting and characters combined with innovative gameplay are still inspirational today.

It also paved the way for a few good Paper Mario games in spite of its unfortunate position as both a late SNES title, and a collaboration with Square that would not endure for the benefit of memorable characters like Geno and Booster.

Waluigi is...shall we say, underappreciated at time of writing. I believe the future will see an end to this, and to kick those days off I have created a love letter to our rose-loving anti-hero. Enjoy or die.

contact: manalockhart@gmail.com

░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
                                
                Vault
                ¯¯¯¯¯
▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░

So you wanna open that vault, huh? You'll need the password, and for that you'll have to locate a secret key hidden somewhere in the game. Keep your eyes open!