********************************************
Super Mario VS The Koopa Bros.
Super Koopa RPG: Intermission
-A Super Mario RPG Romhack/mod-
Version 1.0
Created by: AnAxemRanger
********************************************

*********
The Story
*********
After the Koopa Bros. saved the world during the events of Super
Koopa RPG, Bowser decides to host a party at his Keep to celebrate.
He invites Mario, Luigi, Toadstool, and Kooper.
...But there may be more to this party than meets the eye.  As part
of his master plan, Bowser orders the Koopa Bros. to defeat Mario.
Who will emerge victorious?


**********
Background
**********
This romhack was created for the Big Yoshi Romhacking Discord's
August 2025 romhacking contest.  The theme of the contest is to make
a hack that centers around a boss fight.  It was made in a little
less than 2 months.

You don't need to have played Super Koopa RPG in order to enjoy this
hack.  The backstory provided in the section above is really all the
background you need to know what's going on.

**********************************
Here's some basic info in FAQ form
**********************************
Q. What is this?
A. This is a mod (or "Romhack" as they're sometimes called) of Super
Mario RPG.

Q. What does this mod change?
A. While short, this mod does add several things, such as:
-New story and events
-New Bowser's Keep design
-New Bowser's Keep Battlefield
-New Weapons for Mario and Toadstool
-Kooper has returned from Super Koopa RPG as a playable character
-The Koopa Bros. as enemies
-Enemy attacks and spells
-New equipment
-Custom music

Q. How do I play it?
A. You must apply this .ips patch to a clean ROM of the US version of
Super Mario RPG.  I cannot provide you this ROM.
There are tools to help apply .ips patches.  I suggest you use your
favorite search engine to find information about them.

Q. How long is it?
A. Around 20-30 minutes or so, depending on if you go for all three
endings.

Q. What's the difficulty like?
A. Not too difficult, but a bit more difficult than the original
SMRPG.  Keep yourself healed each turn and time your defense when
possible and you shouldn't have too hard of a time.

Q. What secrets and extras are there?
A. There are three separate endings depending on the results of the
battle.

Q. Why didn't you use the Koopa Bros. battle theme in the actual
fight?
A. Because SMRPG's audio engine is very temperamental.  I tried
including it in the fight, but it ends up bugged with high pitched
screeching sounds playing.  If you're familiar with SMRPG romhacking,
you probably know what I'm talking about.  In general, you can
only use relatively simple songs in battle.

Q. I found a game breaking error!
A. Please report it to me.  I can't guarantee I'll fix everything,
but I'll certainly fix what I can.


*******
Credits
*******
giangurgolo and Omega - Creators of the original Lazy Shell program
Yakibomb - Keeper and programmer for the updated Lazy Shell program
Will319 - Admin of the Big Yoshi Romhacking Discord, contest host
Tonberry2k - Luigi sprite


Any other custom/changed graphics or sprite rips were either listed
as "no credit needed" with no name given or are original edits by me.


*****
Other
*****
My hacks are always free to enjoy, but if you like my content and
want to thank me, please consider contributing to my Ko-Fi:
https://ko-fi.com/anaxemranger

email: AnAxemRanger@gmail.com

Discord name: @anaxemranger
Discord Server: https://discord.gg/vzyzQWh4FF

Youtube: https://www.youtube.com/@AnAxemRanger
Check out Youtube for romhack videos, fun SMRPG facts, challenge
playthroughs of various games, and more!

Romhacking Development Blog: https://ko-fi.com/anaxemranger

Github: https://github.com/AnAxemRanger?tab=repositories
Check out Github for links to my romhacks and more!
