Please try using SNES9X V1.60 or the SNES9X Core in Retroarch if the emulator of your choice does not work!

LISTEN TO THE FULL 4.05 OST HERE! https://www.youtube.com/watch?v=g8b0LQqR3ug

LISTEN TO THE FULL 2.5 OST HERE! https://www.youtube.com/watch?v=fA-qEmkTgYU

OFFICIAL STAR POWERED DISCORD SERVER: https://discord.gg/5Rg39zktuX

Always save state to 90% of the time avoid save file wipes.

ALWAYS PATCH ON A NEW ROM WHEN YOU UPDATE!

Super Luigi RPG Star Powered is a mod that adds:

-LUIGI and DAISY over MARIO and PEACH
-New music made by Will319, CousinCatnip and DarkKefka!!
-Various new items!
-New Armors, Spells and Accessories for all of the party members.
-A new boss fight in Star Hill!
-New enemies and bosses!
-Land’s End and Bean Valley are now ice themed areas!
-Higher stat boosts once you hit level 28-30

Featuring amazing work from Pidgezero_one, Yakibomb, Darkkefka, CousinCatnip, Garatchten,
Doomsday31415 & RP-Genocraft, Inspired by Super Mario RPG Armageddon,
Super Luigi RPG Star Powered is the culmination of 9 and a half years worth of blood, sweat, tears, and hard effort,
as well as a tribute to the whole of Super Mario RPG Legend of the Seven Stars Romhacking Community!

Super Luigi RPG Star Powered aims to be a less extreme alternative to other difficulty hacks for the game,
for those craving a harder Super Mario RPG, but not quite as extreme as the existing alternatives.

Star Powered includes over 60+ New Items, Accessories, Armors, and Weapons to try out! 
As well as 50+ New Bosses & Enemies! Even 4+ New Areas to explore!

Romhacking.net page: https://www.romhacking.net/hacks/6345/