Major Changes:

-Mario is now Luigi, Peach is now Daisy.
-New songs remixed by ( https://twitch.tv/cousincatnip ) CousinCatnip, Will319, and DarkKefka!
-Enemies have been significantly buffed, bosses even more so.
-New Armor, Accessories, and spells for Mallow, Luigi, Bowser, Daisy and Geno.	
-Bean Valley, Monstro Town, and Land's End are now icy landscapes!

-V3 Changes

-Made all enemy names proper case
-New color palette for Daisy, courtesy of the SMRPG Open World Randomizer
-A from the heart message by me has been left at the end of a certain endgame boss fight
-Added a reward for getting all hidden chests
-New original monster spell (courtesy of Yakibomb)
-Organized the shops inventories to not be messy
-2 new bosses in Gate
-New boss in Nimbus Land
-New true final boss in Factory (In the room with the falling Yaridoviches)
-Made story minigames more difficult
-Kefka has been completely revamped and looks cleaner
-New boss in Belome Temple
-New postgame bosses in Mushroom Kingdom
-Pipe Vault is now named Lava Cave and is meant for Endgame
-New Superboss in Sea
-New Boss in Chilly Valley
-Frogfucius's student in Seaside Town has been replaced with a cameo character! Also has a second shop too!
-Too many new accessories to count (No seriously I lost count. Make sure you check the Seaside Town accessories shop.)
-Gunyolk and its unused counterpart have been replaced
-Added a new side quest involving Yoshi
-Gave Bowser Stat Boost
-Gave Mallow Poison Gas (Now Snow Cloud)
-Gave Daisy Lightning
-Gave the player the option to make Bowser a mage
-Made many parts of the game more visually appealing (Palette changes, fixes, etc, forest maze has blueberries now, I fixed moleville being green)
-Remastered Many Bosses
-CousinCatnip Remastered ALL of his songs, (Go follow him on his twitch :})
-You can now view the credits parade in a separate patch (YOU WILL NEED TO PROVIDE AN ADDITIONAL CLEAN ROM FOR THIS.)
-Bullet Bill Blasters, bombs, and Booster's train are now blockable.
-Boss Rush Doesn't SUCK anymore.
-Used Super Mario RPG Armageddon's Collision for Star Hill
-Intro is now readded

-V4 Change Log
-2 New Superbosses
-Revamped Emerald Weapon
-Added Haste
-Added ASM related items, long thought to be long lost to time. Surprises :)
-Blocked off Palace of Shadow until endgame
-Misc. minor bug fixes

-V4.05 Change Log
-MANY Softlock fixes (hopefully? I tested them a lot... Lets pray together. Modding this game sucks.)
-Balanced Megalixirs
-Changed Music
-Added a new song
-New final boss

-V5 Changelog

-Added the option to hold down B to skip through dialogue
-Added Custom Sprite for Luigi
-Reduced Lag in many battles
-Locked Culex Door, Grate Guy's Casino, and Pipe Vault for until Postgame

-V5a, b, c & FINAL changelogs 

-Made Smithy lag less
-Fixed Chaos Star Softlock
-Fixed Battle Hud Icons displaying improperly
-Added a Heart Icon to represent KO Immunity
-Fixed Yaridovich Softlock
-Made game harder
-Made dialogue easier to read
-Fixed many ugly looking color palettes

-VFinal+

-Fixed Smithy X's AI looping improperly
-Hopefully fixed enemies dying prematurely and not vanishing
-Hopefully made Yaridovich lag less
-Fixed Axem Red's attack animation frame data being wonky
-Fixed severe flashing lights issue involving multiple fights, IRL friend suffers from epilepsy, so I figured I should fix this, hence this update
-Sped up knife toss attack
-Fixed buggy numerals displaying after bomb attacks
-Changed color of enemy defeated explosion stars
-Boss Rush sucks even less

-VFinal++

-Fixed Object Overflow bug
-Added a Save Point and Checkpoints to the Boss Rush
-Restored Vanilla Color Palettes for many areas
-Renamed Ice Smash to Ultra Hammer
-Replaced Ultra Hammer with Mario Hammer
-Added Shooting Star Summit

-VOvertuned

-Fixed Lag in a fight in the Factory, did literally nothing else.

-Maximum

-Too much to even consider listing.
-Major highlight is making the game prettier, more appealing to a wider audience, and fixing many bugs.

-Maximumer

-Fixed even more bugs and issues.

-Maximumest

-Fixed typos, animations, color palettes, and tiling errors
-Added a bank to Mushroom Kingdom that is unlocked once you first get there.