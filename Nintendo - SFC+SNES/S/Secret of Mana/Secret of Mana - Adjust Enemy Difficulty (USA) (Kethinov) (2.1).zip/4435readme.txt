~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
==========================================
Secret of Mana Adjust Enemy Difficulty 2.1
by Kethinov                       Mar 2019
==========================================
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

This hack offers 208 different options for adjusting monster/boss difficulty which depending on the combination of hacks you apply can either increase or decrease the amount of level grinding that is necessary to finish the game.

You can independently adjust:

- 13 stats.
- On either monsters, bosses, or both.
- Up or down based on percentage of the original value: 25% (1/4), 33% (1/3), 50% (1/2), 75% (3/4), 200% (2x), 300% (3x), 400% (4x), and 500% (5x).

The adjustable stats are:

General stats:

- Base Levels: The level of the monster/boss.
- Experience: How much experience is awarded when it is defeated.
- GP: How much GP is awarded when it is defeated.
- HP: How many hit points the monster has.
- MP: How many magic points the monster has to cast spells with.

Magic stats:

- Attack Magic Power: How powerful the black magic (attack magic) spells cast by the monster/boss are.
- Defensive Magic Power: How powerful the white magic (defensive magic) spells cast by the monster/boss are.
- Elemental Levels: What level the spells cast by the monster are.
- Intelligence: Affects the magic power calculation. Higher intelligence means more powerful magic.
- Wisdom: Affects the magic defense calculation. Higher wisdom means stronger defenses against magic.

Melee stats:

- Agility: Affects evade chance and hit chance. Higher evade means harder to hit and misses less often.
- Strength: Affects damage of melee attacks. Higher strength means more damage done per strike.
- Weapon Levels: Affects damage of melee attacks. Higher weapon levels means more damage done per strike.

Important things to note:

- The most useful stats to adjust for increasing or decreasing difficulty are experience, GP, and HP.
- If you adjust experience or GP, it is recommended that you do it proportionally. For example, if you cut experience in half, you should cut GP in half too to prevent the game's economy from getting out of whack.
- This hack bundle is compatible with "Harder Final Boss" but only if this is applied first.
- Hacks which increase HP or MP bundle Queue's "Big Health And Mana Support" hack to add support for high HP (new max 65535) and MP (new max 255) values.

Changelog:

- 2.1: Added support for high HP (new max 65535) and MP (new max 255) values. Thanks to Queue for providing additional code that makes this possible.
- 2.0: Greatly expanded hack list. Renamed to "Adjust Enemy Difficulty" from "Easier or Harder Monsters."
- 1.0: Initial version.