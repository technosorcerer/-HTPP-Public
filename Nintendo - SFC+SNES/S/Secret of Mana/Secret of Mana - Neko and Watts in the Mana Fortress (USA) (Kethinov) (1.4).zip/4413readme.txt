~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
======================================================
Secret of Mana Neko and Watts in the Mana Fortress 1.4
by Kethinov                                   Mar 2019
======================================================
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

This patch adds Neko and Watts to the Mana Fotress and restores some unused Neko frames too. The new Nekos offer you the same items as the Tree Palace Neko, plus the ability to save inside the Mana Fortress. The new Watts is useful because there are so many weapon orbs that can be collected in the Mana Fortress. With Neko and Watts in the Mana Fortress, now you never have to leave.

Specific changes:

- New Neko at the previously useless dead end ledge just before fighting Buffy.
- New Watts at the previously useless dead end southeast corner of the map just after fighting Buffy.
- Another new Neko at the teleporter just before fighting the Dark Lich.
- Some of the New Nekos will wander, displaying the previously unseen Neko graphics.
- The Haunted Forest and Lofty Mountain Nekos will also now wander, displaying the previously unseen Neko graphics.

Some important things to note:

- Neko will only wander up and down. Mostly down. This is because Neko does not have left/right walking frames, so when he attempts to wander, any commands he receives to walk left or right are interpreted as down instead. As such, Neko will only wander in locations that are suitable for him to walk down most of the time.
- How to combine this with the Variable Width Font hack: 1. Apply VWF, 2. Remove header, 3. Apply this hack, 4. Apply this hack's VWF support hack.
- How to combine this with Relocalized: 1. Apply Relocalized, 2. Apply this hack, 3. Apply this hack's Relocalized support hack.

Changelog:

- 1.4: Fixed Neko placement bug.
- 1.3: Moved the last Neko to beyond the teleporter.
- 1.2: Fixed bug when loading a save file saved in the Mana Fortress that caused the Mana Fortress music not to play until you transition a screen. Thanks to Queue for the fix. Also added support for Relocalized.
- 1.1: Fixed bug when combined with VWF.
- 1.0: Initial version.