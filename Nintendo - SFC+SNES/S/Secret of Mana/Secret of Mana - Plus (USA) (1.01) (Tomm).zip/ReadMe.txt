Secret of Mana Plus 1.01

-------------
PRESENTATION
-------------
This hack enhances 3 palaces of Secret of Mana:

- The Wind Palace and the Moon Palace become real dungeons filled with monsters.
- The Gold Tower and Gold Isle story is expanded, with additionnal maps.

The new zones and maps feature:
- Additionnal monsters and bosses: new versions of vanilla enemies with their own stats/spells/colors...
- Cutscenes: The new maps are integrated into the main story and add new plot points through numerous cutscenes.
- Secrets: A few bonus maps containing chests have been added across the game.

Notable changes: 
- The 2 bosses (Buffy and Dread Slime) now drop weapon orbs.
- The Dark Stalker in Tasnica is now a bit tankier.
- The Lofty Mountains background scrolling has been fixed.
- Other minor fixes.

Besides the additionnal content, the core game remains unchanged.

------------
MULTIPLAYER
------------
For more than one player use ONLY the multiplayer version of the hack. It inactivates the abilty to "leave characters behind and warp them back to you" which is very buggy when there are 2 or 3 players.

------------------
ENHANCEMENT HACKS
------------------
This hack includes the following enhancement hacks:
- Max consumable count increased from 4 to 7 (by Moppleton)
- Allow allies to leave the edge of the screen (by Moppleton): allies will not get you stuck anymore.
- Elemental melee damage (by Moppleton): Elemental sabers will cause 1.5 times damage against the right element, and half damage against the wrong element.
- Enemy species damage (by Moppleton): 1.5 attack against targets whose species is weak to the weapon you have equipped.
- Spell grinding speed-up hack (x2) (by Kethinov)

------------------
HACK COMPATIBILTY
------------------
Secret of Mana Plus is NOT compatible with TURBO, REBORN or the RANDOMIZER.

This hack required some heavy rom modification so it conflicts with a lot of other hacks.
- NOT compatible with any hack modifying maps, NPCs or monsters placement.
- NOT compatible with any hack changing monsters stats as it will not affect new monsters.
- NOT compatible with many hacks modifying spells as it may conflict with new monsters AI.

--------------
V1.01 CHANGES
--------------
- Minor map fixes
- Fixed a bug that caused the game to lock if you entered the Resistance for the first time while some characters were snowmen.


For any bug, issue or question about the hack, you can contact me by the romhacking.net forum. Use the following topic: https://www.romhacking.net/forum/index.php?topic=38152.0