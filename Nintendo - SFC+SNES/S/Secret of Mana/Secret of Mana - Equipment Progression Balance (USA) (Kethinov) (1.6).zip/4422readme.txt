~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
================================================
Secret of Mana Equipment Progression Balance 1.6
by Kethinov                             Mar 2019
================================================
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

This patch rearranges the armor, items, shops, and monster drops significantly. This hack is effectively a more ambitious effort to solve the problems that the previous similar hack "Drop Table Balance" attempted to solve. But instead of editing only the drop table, this hack alters the armor, items, shop, and drop tables to attain even better progression balance.

Why:

- Promote a more balanced and natural feeling of item/armor progression throughout the game.
- Reduce the excessive amount of grinding in the game.
- Restore unused content back into the game (e.g. the unused item, armor, and Neko walking frames).
- Make no items missable or excessively hard to find.
- Make all armor useful; prevent getting new armor that is worse than what you already have.
- Increase incentive to fight and defeat many of the game's more annoying monsters by making their drops more useful.
- Make overall difficulty more consistent / less uneven across a playthrough.
- Make it easier to get the weapon orbs dropped in the Mana Fortress which otherwise would require excessive grinding.

Armor changes:

- All armor is now buyable. No more missable or excessively rare items.
- Armor progression was balanced. There is no more useless armor. Each new piece of equipment you encounter in a typical playthrough will either be an upgrade or offer reasonable tradeoffs over existing equipment. Armor stats and defensive properties have been tweaked accordingly with the goal of preserving the original spirit of each piece of equipment as much as possible.
- Armor stats were adjusted to increase difficulty or reduce difficulty in various stages of the game. In some dungeons you will have better armor than the original game and in others you will have weaker armor than the original game. This is to make difficulty more consistent / less uneven across a playthrough.
- Some armor sequencing has been rearranged to better match the spirit of the region the armor is acquired in. Stats have been adjusted accordingly to keep progression linear.
- Restored unused Ruby Armet headgear for Primm back into the game. It is now sold at Kakkara.
- Some armors will now be considered "siblings" to one another. "Siblings" are identical in defensive properties (and cost) to one another except in regards to some stat boost or status effect. As such, they are sold together at shops or are sold separately at shops that become accessible at the same time (e.g. Todo/Kakkara and Mandala/Gold Isle).

Items / shops:

- All shops now sell more items. It is now possible to buy Faerie Walnuts, Royal Jam, Barrels and other later items earlier in the game. And more vendors sell early items like Candy later in the game too.
- Restored unused consumable item back into the game. The new item, now called the Faerie Coconut, restores 50mp and features a new animation. The Faerie Walnut has been revised to restore only 25mp to balance things out. This hack supersedes the "Faerie Coconut" standalone hack.
- Price of Barrels is now reduced from its base price of 225gp (450gp at Neko's) to 100gp (200gp at Neko's). Barrels are also available at regular shops now too instead of just Neko's, who double charges for everything. This makes Barrels a lot cheaper and therefore less painful to waste.
- Armor prices have been greatly reduced to encourage upgrading more often without the need for grinding. This was already needed with the original game's armor table, but adding even more buyable armor into the game heightens the need for this considerably.
- The cost of upgrading weapons is now half of what it is in the original game. (The code changes are identical to how this was also done in "Level 9 Weapons Progression Balance" to preserve compatibility between this hack and that one.)
- Neko and Watts have been added to the Mana Fortress. The new Neko sells you unique, Mana Fortress-exclusive items, plus the ability to save inside the Mana Fortress. With Neko and Watts in the Mana Fortress, now you never have to leave. The New Nekos will wander, displaying the previously unseen Neko graphics. The Haunted Forest and Lofty Mountain Nekos will also now wander, displaying the previously unseen Neko graphics. This hack supersedes the "Neko and Watts in the Mana Fortress" standalone hack.

Drop changes:

- Which monsters drop which items has been rearranged significantly to minimize useless/unhelpful items being dropped. Faerie Walnuts and other useful consumables will drop more often from more monsters now.
- Monsters no longer drop unique armor. All armor is buyable. When monsters do drop armor, it will usually be better than what you have and will more closely match the theme of the monster.
- Like the original game, various monsters in the Mana Fortress will still drop 9th weapon orbs (excluding the sword), but these drops will now be common drops instead of rare drops. Also the spear orb has been moved from Tsunami to Turtlance.

This hack is not compatible with the following hacks:

- Masterflow's Hard Mode: Alters the armor and drop tables in an incompatible way.
- Kethinov's Drop Table Balance: Alters the drop table in an incompatible way. This hack was expressly designed to supersede "Drop Table Balance."
- Timbo's Equipment Overhaul: Alters the armor, drop, and shops tables in an incompatible way.
- Queue's Ruby Armet hack: Alters the shops table in an incompatible way.
- Kethinov's Neko and Watts in the Mana Fortress: This hack supersedes the "Neko and Watts in the Mana Fortress" standalone hack by incorporating its changes into this one, but enhancing it further by making the new Neko sell unique items.
- Kethinov's Faerie Coconut: This hack supersedes the "Faerie Coconut" standalone hack by incorporating its changes into this one's revised and expanded shops table.

Some important things to note:

- How to combine this with the Variable Width Font hack: 1. Apply VWF, 2. Remove header, 3. Apply this hack, 4. Apply this hack's VWF support hack.
- How to combine this with Relocalized: 1. Apply Relocalized, 2. Apply this hack, 3. Apply this hack's Relocalized support hack. 
- The new Mana Fortress Neko will only wander up and down. Mostly down. This is because Neko does not have left/right walking frames, so when he attempts to wander, any commands he receives to walk left or right are interpreted as down instead. As such, Neko will only wander in locations that are suitable for him to walk down most of the time.
- A companion hack "Faerie Coconut Replacement Graphic" has also been included. This hack replaces the graphic for the Faerie Coconut with a graphic that looks more explicitly like a coconut. The original graphic was a graphic that was included in the original game, but dummied out and went unused. The concept of the "Faerie Coconut" was created for the unused item it because it looked sort of like a coconut. But ThanatosZero suggested incorporating a graphic that looked more like a coconut and did a great job producing such a graphic. Timbo then did the hacking work to incorporate the graphic into the ROM. You can optionally apply that hack atop this one depending on which graphic you prefer.

Changelog:

- 1.6: Fixed Neko placement bug.
- 1.5: Grave Bats no longer drop Vampire Capes. Also moved the last Neko to beyond the teleporter.
- 1.4: Small balance adjustment to make mid-game and later a bit harder. Also fixed bug when loading a save file saved in the Mana Fortress that caused the Mana Fortress music not to play until you transition a screen. Thanks to Queue for the fix. And added support for Relocalized.
- 1.3: Fixed crash caused by combining this with VWF.
- 1.2: Fixed bug in which the "Harder Final Boss" hack was accidentally bundled with this.
- 1.1: Added "Faerie Coconut Replacement Graphic" companion hack.
- 1.0: Initial version.

-----------------
New armor tables:
-----------------

Headgear:
--------------
name           | gp    > to    | who > to  | def > to  | mdf > to | old location    > new location | old effects           > new effects
============== | ============= | ========  | ========  | ======== | ============================== | =======================================
Bandana          50    > 20      B   > '     2   > 1     2   > 1    potos           > potos/neko     none                  > '
--------------
Head Gear        70    > 35      B   > '     7   > 3     7   > 3    dwarf village   > pandora1       none                  > '
Hair Ribbon      55    > 35      G   > '     3   > '     3   > '    pandora1        > '              none                  > '
--------------
Steel Cap        180   > 55      B   > '     13  > 7     13  > 7    matango         > kippo          none                  > '
Rabite Cap       45    > 40      S   > '     5   > '     5   > '    dwarf village   > '              none                  > '
--------------
Golden Tiara     350   > 250     GS  > G     17  > 7     17  > 7    kakkara/todo    > pandora2       none                  > '
Quill Cap        110   > 250     GS  > S     10  > 7     10  > 7    upperland       > pandora2       none                  > '
--------------
Raccoon Cap      550   > 250     all > B     21  > 9     21  > 9    kakkara/todo    > upperland      none                  > '
--------------
Dragon Helm      7500  > 550     all > '     66  > 13    66  > 13   gold isle       > matango        none                  > eng
--------------
Tiger Cap        1100  > '       all > B     32  > 19    32  > 19   northtown       > kakkara        none                  > '
Ruby Armet       N/A   > 1100    G   > '     46  > 19    46  > 19   [UNUSED]        > kakkara        none                  > eng
Circlet          2300  > 1100    BS  > S     38  > 19    38  > 19   mandala         > todo           int+5                 > '
--------------
Quilted Hood     700   > 5625    GS  > B     26  > '     26  > '    northtown       > '              agi+5                 > '
Unicorn Helm     5625  > '       all > G     55  > 26    55  > 26   gold isle       > northtown      wis+5                 > '
Duck Helm        11250 > 5625    GS  > S     78  > 26    78  > 26   gold isle       > northtown      none                  > '
--------------
Cockatrice Cap   22500 > 7500    all > '     142 > 55    143 > 55   {basilisk}      > mandala        pet                   > '
--------------
Amulet Helm      36000 > 11250   GS  > '     143 > 75    142 > 75   {national scar} > tasnica        int+5 wis+5           > none
--------------
Needle Helm      15000 > '       all > '     140 > 125   140 > 125  grand palace    > '              none                  > '
--------------
Griffin Helm     44500 > 32767   B   > '     145 > 150   145 > 150  {griffin hand*} > mana fortress  agi+5 str+5           > none
Faerie Crown     58000 > 32767   GS  > '     150 > '     150 > '    {terminator}    > mana fortress  int+5 wis+5           > '
--------------

Body armor:
--------------
name           | gp    > to    | who > to  | def > to  | mdf > to | old location    > new location | old effects           > new effects
============== | ============= | ========  | ========  | ======== | ============================== | =======================================
Overalls         20    > '       B   > '     3   > 1     1   > '    potos           > potos/neko     none                  > '
--------------
Chain Vest       120   > 40      all > '     10  > 3     6   > 2    kippo           > pandora1       none                  > '
Kung Fu Suit     25    > '       G   > '     4   > '     2   > '    pandora1        > '              none                  > agi+5
--------------
Spikey Suit      260   > 100     BS  > B     13  > 15    8   > '    dwarf village   > kippo          none                  > '
Kung Fu Dress    350   > 125     G   > '     17  > '     10  > '    kippo           > '              none                  > agi+5
Midge Robe       120   > 100     S   > '     7   > 15    4   > 10   dwarf village   > '              none                  > '
--------------
Fancy Overalls   675   > '       all > '     22  > 19    13  > 10   matango         > pandora2       none                  > '
--------------
Chest Guard      1000  > 1100    GS  > B     28  > 22    16  > 13   kakkara/todo    > matango        none                  > '
Ruby Vest        4500  > 1100    all > G     43  > 22    24  > 13   southtown       > matango        none                  > eng
Golden Vest      2250  > 1100    all > S     34  > 22    20  > 13   kakkara/todo    > matango        none                  > '
--------------
Tiger Suit       6375  > 2250    BS  > B     52  > 26    29  > 14   northtown       > kakkara        none                  > '
Tiger Bikini     7100  > 2250    G   > '     64  > 26    35  > 14   northtown       > kakkara        none                  > '
Magical Armor    11500 > 2250    all > S     78  > 26    41  > 14   mandala         > todo           none                  > bln cnf slp tng
--------------
Flower Suit      21000 > 7100    G   > '     115 > 30    57  > 15   gold isle       > northtown      poi slp               > '
Tortoise Mail    14850 > 7100    BS  > '     95  > 30    49  > 15   tasnica         > northtown      none                  > '
--------------
Battle Suit      30000 > 11500   all > '     139 > 80    67  > 45   gold isle       > '              none                  > '
--------------
Vestguard        32750 > 30000   all > BS    240 > 160   90  > '    grand palace    > '              none                  > str+5
Vampire Cape     47000 > 30000   GS  > '     243 > 160   93  > 90   {fiend head}    > grand palace   none                  > agi+5 poi
--------------
Power Suit       53000 > 32767   B   > '     245 > 225   95  > '    {whimper}       > mana fortress  str+5                 > '
Faerie Cloak     65000 > 32767   GS  > '     250 > 225   100 > '    {master ninja}  > mana fortress  cst+5                 > '
--------------

Arms:
--------------
name           | gp    > to    | who > to  | def > to  | mdf > to | old location    > new location | old effects           > new effects
============== | ============= | ========  | ========  | ======== | ============================== | =======================================
Wristband        45    > 10      BG  > '     1   > '     3   > '    pandora1        > potos/neko     none                  > '
--------------
Elbow Pad        90    > 20      all > '     2   > '     4   > '    kippo           > pandora1       none                  > '
--------------
Power Wrist      150   > 30      all > '     4   > 3     7   > 5    dwarf village   > kippo          str+5                 > '
Cobra Bracelet   280   > 30      all > '     6   > 3     10  > 5    pandora2        > kippo          poi                   > '
Gold Bracelet    3750  > 30      all > '     24  > 3     43  > 5    tasnica         > dwarf village  pet                   > mog pet slp
--------------
Silver Band      525   > 150     all > GS    10  > 6     17  > 10   kakkara/todo    > pandora2       wis+5                 > '
--------------
Golem Ring       750   > 150     all > B     13  > 6     22  > 10   southtown       > upperland      tng                   > '
--------------
Wolf's Band      400   > '       all > '     8   > '     13  > '    matango         > '              agi+5                 > '
--------------
Dragon Ring      31000 > 525     all > '     92  > 10    242 > 17   {ice thug*}     > kakkara        none                  > eng
Frosty Ring      1200  > 525     all > '     16  > 10    28  > 17   northtown       > todo           fst                   > '
--------------
Guardian Ring    12500 > 3750    all > B     41  > 16    78  > 22   {doom sword}    > southtown      none                  > agi+5
Shield Ring      5100  > 3750    all > G     29  > 16    52  > 22   gold isle       > southtown      none                  > pet
Lazuri Ring      8800  > 3750    all > S     35  > 16    64  > 22   gold isle       > southtown      int+5 wis+5           > '
--------------
Ivy Amulet       1875  > 6375    all > '     20  > 43    34  > 64   mandala         > '              poi slp               > '
Watcher Ring     37500 > 6375    all > '     93  > 43    243 > 64   {eggplant man}  > mandala        mog                   > eng mog
Amulet Ring      48000 > 6375    all > '     95  > 43    245 > 64   {tsunami}       > mandala        pet                   > fst pet
--------------
Faerie's Ring    55000 > 6375    all > '     100 > 43    250 > 64   {wolf lord}     > gold isle      agi+5 bln cnf poi pyg > int+5 bln cnf pyg
--------------
Ninja Gloves     24000 > 6375    all > '     91  > 43    241 > 64   {dark stalker}  > tasnica        agi+5 tng             > '
Gauntlet         18750 > 6375    all > '     90  > 43    240 > 64   grand palace    > tasnica        str+5                 > '
Imp's Ring       42500 > 6375    all > '     94  > 43    244 > 64   {ghost*}        > tasnica        eng fst               > '
--------------

Key:
- '                 = Indicates no changes were made to this property of the item
- [UNUSED]          = Indicates item was dummied from the game and unobtainable originally
- {name of monster} = Indicates item was originally obtainable from monster chest
- *                 = Indicates item was missable

Locations key:
- potos:         Potos merchant
- neko:          Neko's house
- pandora1:      Pandora merchant
- kippo:         Kippo merchant
- dwarf village: Dwarf Village merchant
- pandora2:      Pandora armor shop
- upperland:     Upperland Neko
- matango:       Matango merchant
- kakkara:       Kakkara merchant
- todo:          Todo merchant
- southtown:     Southtown merchant
- northtown:     Northtown merchant
- mandala:       Mandala merchant and Neko
- gold isle:     Gold City merchant
- tasnica:       Tasnica merchant
- grand palace:  Sunken continent Neko
- mana fortress: Mana Fortress Neko (New!)

Item properties key:
- str: Strength (attack power)
- int: Intelligence (magic power)
- cst: Constitution (adds to defense)
- agi: Agility (adds to evade)
- wis: Wisdom (adds to magic defense)
- bln: Balloon resist
- cnf: Confuse resist
- eng: Engulf resist
- fst: Frosty resist
- mog: Moogle resist
- pet: Petrify resist
- poi: Poison resist
- pyg: Pygmy resist
- slp: Sleep resist
- tng: Tangled resist
- gp: Price
- who: Who can equip the item (B for boy [Randi], G for girl [Primm], S for sprite [Popoi], or all for anyone can equip it)
- def: Defense stat
- mdf: Magic defense stat

---------------
New drop table:
---------------

Potos:
- Rabite:         Candy / 4gp                    -> Candy / Rabite Cap
- Lullabud:       Medical Herb / 16gp            -> Medical Herb / Cup of Wishes
- Mushboom:       14gp / 64gp                    -> Candy / Chocolate

Pandora:
- Buzz Bee:       Candy / 22gp                   -> Candy / Chocolate
+ Rabite:         Candy / 4gp                    -> Candy / Rabite Cap
+ Lullabud:       Medical Herb / 16gp            -> Medical Herb / Cup of Wishes
+ Mushboom:       14gp / 64gp                    -> Candy / Chocolate

Gaia's Navel:
- Blat:           Candy / 20gp                   -> Candy / Chocolate
- Kid Goblin:     28gp / 4gp                     -> Cup of Wishes / Faerie Walnut
- Green Drop:     Medical Herb / 24gp            -> Medical Herb / Cup of Wishes
+ Mushboom:       14gp / 64gp                    -> Candy / Chocolate

Haunted Forest:
- Polter Chair:   44gp / 74gp                    -> Barrel / Royal Jam
- Werewolf:       Cup of Wishes / Kung Fu Dress  -> Cup of Wishes / Royal Jam
- Eye Spy:        Chocolate / Medical Herb       -> Chocolate / Royal Jam
- Chobin Hood:    34gp / 64gp                    -> Candy / Chocolate
+ Mushboom:       14gp / 64gp                    -> Candy / Chocolate

Undine's Cave:
- Iffish:         nothing / nothing              -> Faerie Walnut / Faerie Coconut

Underground Palace:
- Goblin:         Candy / Faerie Walnut          -> Barrel / Faerie Walnut
- Ma Goblin:      60gp / 45gp                    -> Candy / Chocolate
- Chess Knight:   Medical Herb / Cup of Wishes   -> Faerie Walnut / Faerie Coconut
+ Blat:           Candy / 20gp                   -> Candy / Chocolate
+ Green Drop:     Medical Herb / 24gp            -> Medical Herb / Cup of Wishes

Pandora Ruins:
- Zombie:         Medical Herb / 96gp            -> Cup of Wishes / Cup of Wishes
- Tomato Man:     Faerie Walnut / Cup of Wishes  -> Faerie Walnut / Faerie Coconut
- Evil Sword:     Candy / 120gp                  -> Faerie Coconut / Faerie Walnut
+ Chess Knight:   Medical Herb / Cup of Wishes   -> Faerie Walnut / Faerie Coconut

Upper Land:
- Silktail:       158gp / 65gp                   -> Chocolate / Royal Jam
- Pebbler:        Chocolate / Faerie Walnut      -> Chocolate / Cup of Wishes
- Nemesis Owl:    Medical Herb / Quill Cap       -> Medical Herb / Cup of Wishes
- Steamed Crab:   Faerie Walnut / Candy          -> Faerie Walnut / Faerie Coconut
- Water Thug:     Candy / Cobra Bracelet         -> Candy / Chocolate
- Crawler:        Candy / Medical Herb           -> Candy / Chocolate

Matango Caves:
- Kimono Bird:    Chocolate / Fancy Overalls     -> Chocolate / Royal Jam
+ Silktail:       158gp / 65gp                   -> Chocolate / Royal Jam
+ Pebbler:        Chocolate / Faerie Walnut      -> Chocolate / Cup of Wishes
+ Nemesis Owl:    Medical Herb / Quill Cap       -> Medical Herb / Cup of Wishes
+ Steamed Crab:   Faerie Walnut / Candy          -> Faerie Walnut / Faerie Coconut
+ Water Thug:     Candy / Cobra Bracelet         -> Candy / Chocolate
+ Crawler:        Candy / Medical Herb           -> Candy / Chocolate

Ice Country:
- Howler:         Candy / Medical Herb           -> Candy / Cup of Wishes
- Shellblast:     Chocolate / Cup of Wishes      -> Barrel / Tortoise Mail
- La Funk:        Faerie Walnut / Cup of Wishes  -> Faerie Coconut / Faerie Walnut
+ Pebbler:        Chocolate / Faerie Walnut      -> Chocolate / Cup of Wishes

Ice Palace:
- Weepy Eye:      Medical Herb / Chest Guard     -> Faerie Walnut / Faerie Coconut
- Blue Drop:      Chocolate / Golden Tiara       -> Candy / Chocolate
- Mystic Book:    Chocolate / Faerie Walnut      -> Faerie Walnut / Faerie Coconut
- Specter:        Faerie Walnut / Cup of Wishes  -> Faerie Coconut / Faerie Walnut
+ Shellblast:     Chocolate / Cup of Wishes      -> Barrel / Tortoise Mail

Kakkara Desert:
- Mad Mallard:    Candy / Medical Herb           -> Candy / Duck Helm
- Pumpkin Bomb:   24gp / 68gp                    -> Candy / Chocolate
- Spider Legs:    Chocolate / Candy              -> Faerie Walnut / Faerie Coconut
+ Pebbler:        Chocolate / Faerie Walnut      -> Chocolate / Cup of Wishes

Fire Palace:
- Sand Stinger:   Candy / Medical Herb           -> Candy / Chocolate
- Robin Foot:     Chocolate / Quilted Hood       -> Chocolate / Quilted Hood
- Red Drop:       Chocolate / Silver Band        -> Candy / Chocolate
- Dark Funk:      Candy / Faerie Walnut          -> Faerie Coconut / Faerie Walnut

Empire Sewers:
- Dinofish:       nothing / nothing              -> Faerie Walnut / Faerie Coconut
+ Iffish:         nothing / nothing              -> Faerie Walnut / Faerie Coconut
+ Blue Drop:      Chocolate / Golden Tiara       -> Candy / Chocolate

Northtown Ruins:
- Imp:            Candy / Cup of Wishes          -> Candy / Imp's Ring
- Ghoul:          Candy / Medical Herb           -> Cup of Wishes / Cup of Wishes
- Wizard Eye:     Chocolate / Faerie Walnut      -> Chocolate / Royal Jam
- Grave Bat:      Candy / Chocolate              -> Candy / Chocolate
+ Weepy Eye:      Medical Herb / Chest Guard     -> Faerie Walnut / Faerie Coconut
+ Specter:        Faerie Walnut / Cup of Wishes  -> Faerie Coconut / Faerie Walnut
+ La Funk:        Faerie Walnut / Cup of Wishes  -> Faerie Coconut / Faerie Walnut
+ Zombie:         Medical Herb / 96gp            -> Cup of Wishes / Cup of Wishes
+ Tomato Man:     Faerie Walnut / Cup of Wishes  -> Faerie Walnut / Faerie Coconut
+ Green Drop:     Medical Herb / 24gp            -> Medical Herb / Cup of Wishes
+ Blue Drop:      Chocolate / Golden Tiara       -> Candy / Chocolate
+ Red Drop:       Chocolate / Silver Band        -> Candy / Chocolate
+ Robin Foot:     Chocolate / Quilted Hood       -> Chocolate / Quilted Hood

Emperor's Castle:
- Armored Man:    Candy / Cup of Wishes          -> Candy / Chocolate
- Dark Ninja:     Candy / Chocolate              -> Chocolate / Ninja Gloves
- Emberman:       Faerie Walnut / Chocolate      -> Faerie Walnut / Faerie Coconut
+ Mystic Book:    Chocolate / Faerie Walnut      -> Faerie Walnut / Faerie Coconut

Lofty Mountains:
- Trap Flower:    Medical Herb / Candy           -> Faerie Walnut / Faerie Coconut
- Bomb Bee:       Medical Herb / Royal Jam       -> Faerie Walnut / Faerie Coconut
- Eggatrice:      Medical Herb / Chocolate       -> Faerie Walnut / Faerie Coconut

Palace of Darkness:
- Fierce Head:    Faerie Walnut / Unicorn Helm   -> Faerie Walnut / Faerie Coconut
- Dark Knight:    Magical Armor / Gauntlet       -> Faerie Walnut / Gauntlet
+ Dark Ninja:     Candy / Chocolate              -> Chocolate / Ninja Gloves
+ Emberman:       Faerie Walnut / Chocolate      -> Faerie Walnut / Faerie Coconut
+ Imp:            Candy / Cup of Wishes          -> Candy / Imp's Ring
+ Grave Bat:      Candy / Chocolate              -> Candy / Chocolate

Gold Tower:
- Beast Zombie:   Chocolate / Medical Herb       -> Chocolate / Cup of Wishes
+ Wizard Eye:     Chocolate / Faerie Walnut      -> Chocolate / Royal Jam
+ Weepy Eye:      Medical Herb / Chest Guard     -> Faerie Walnut / Faerie Coconut

Moon Palace / Joch's Cave / Underground City / Mana Fortress:
- Marmablue:      Faerie Walnut / Cup of Wishes  -> Faerie Coconut / Faerie Walnut

Cave of Courage:
- Nitro Pumpkin:  Cup of Wishes / Chocolate      -> Royal Jam / Cup of Wishes
- Shape Shifter:  nothing / nothing              -> Faerie Coconut / Faerie Walnut
- Mimic Box:      Faerie Walnut / Royal Jam      -> Faerie Coconut / Faerie Walnut
- Captain Duck:   Royal Jam / Duck Helm          -> Royal Jam / Cup of Wishes
- Eggplant Man:   Cup of Wishes / Watcher Ring   -> Cup of Wishes / Faerie Coconut
- Needlion:       Royal Jam / Needle Helm        -> Royal Jam / Needle Helm
+ Pumpkin Bomb:   24gp / 68gp                    -> Candy / Chocolate
+ Beast Zombie:   Chocolate / Medical Herb       -> Chocolate / Cup of Wishes
+ Rabite:         Candy / 4gp                    -> Candy / Rabite Cap

Underground City:
- Basilisk:       Faerie Walnut / Cockatrice Cap -> Barrel / Faerie Coconut
- Steelpion:      Medical Herb / Royal Jam       -> Royal Jam / Cup of Wishes
- Kimono Wizard:  Faerie Walnut / Royal Jam      -> Faerie Coconut / Faerie Walnut
- Metal Crawler:  Chocolate / Gauntlet           -> Royal Jam / Cup of Wishes
- Dark Stalker:   Chocolate / Ninja Gloves       -> Chocolate / Ninja Gloves
+ Fierce Head:    Faerie Walnut / Unicorn Helm   -> Faerie Walnut / Faerie Coconut
+ Captain Duck:   Royal Jam / Duck Helm          -> Royal Jam / Cup of Wishes
+ Eggatrice:      Medical Herb / Chocolate       -> Faerie Walnut / Faerie Coconut

Great Palace:
- Turtlance:      Chocolate / Tortoise Mail      -> Candy / Barrel
- National Scar:  Faerie Walnut / Amulet Helm    -> Faerie Walnut / Faerie Coconut
- Doom Sword:     Cup of Wishes / Guardian Ring  -> Cup of Wishes / Cup of Wishes
- Heck Hound:     Royal Jam / Faerie Walnut      -> Royal Jam / Cup of Wishes
- Gremlin:        Candy / Royal Jam              -> Candy / Chocolate
+ Imp:            Candy / Cup of Wishes          -> Candy / Imp's Ring
+ Ghoul:          Candy / Medical Herb           -> Cup of Wishes / Cup of Wishes
+ Beast Zombie:   Chocolate / Medical Herb       -> Chocolate / Cup of Wishes
+ Howler:         Candy / Medical Herb           -> Candy / Cup of Wishes

Pure Land:
- Griffin Hand:   Chocolate / Griffin Helm       -> Chocolate / Griffin Helm
- Mushgloom:      Chocolate / Barrel             -> Barrel / Royal Jam
- Ice Thug:       Royal Jam / Dragon Ring        -> Royal Jam / Cup of Wishes
- Ghost:          Royal Jam / Imp's Ring         -> Faerie Coconut / Faerie Walnut
+ Eggplant Man:   Cup of Wishes / Watcher Ring   -> Cup of Wishes / Faerie Coconut
+ Needlion:       Royal Jam / Needle Helm        -> Royal Jam / Needle Helm

Mana Fortress:
- Tsunami:        Amulet Ring / Spear Orb        -> Chocolate / Royal Jam
- Terminator:     Faerie Crown / Whip Orb        -> Whip Orb || [reverts to Candy at max orbs] / Faerie Crown
- Fiend Head:     Vampire Cape / Axe Orb         -> Axe Orb || [reverts to Candy at max orbs] / Faerie Cloak
- Metal Crab:     Vestguard / Bow Orb            -> Bow Orb || [reverts to Candy at max orbs] / Gauntlet
- Whimper:        Power Suit / Javelin Orb       -> Javelin Orb || [reverts to Candy at max orbs] / Power Suit
- Wolf Lord:      Faerie's Ring / Glove Orb      -> Glove Orb || [reverts to Candy at max orbs] / Faerie's Ring
- Master Ninja:   Faerie Cloak / Boomerang Orb   -> Boomerang Orb || [reverts to Candy at max orbs] / Ninja Gloves
+ Turtlance:      Chocolate / Tortoise Mail      -> Spear Orb || [reverts to Candy at max orbs] / Barrel
+ Dark Stalker:   Chocolate / Ninja Gloves       -> Chocolate / Ninja Gloves
+ National Scar:  Faerie Walnut / Amulet Helm    -> Faerie Walnut / Faerie Coconut
+ Doom Sword:     Cup of Wishes / Guardian Ring  -> Cup of Wishes / Cup of Wishes
+ Basilisk:       Faerie Walnut / Cockatrice Cap -> Barrel / Faerie Coconut
+ Eggatrice:      Medical Herb / Chocolate       -> Faerie Walnut / Faerie Coconut
+ Kimono Wizard:  Faerie Walnut / Royal Jam      -> Faerie Coconut / Faerie Walnut
+ Metal Crawler:  Chocolate / Gauntlet           -> Royal Jam / Cup of Wishes
+ Heck Hound:     Royal Jam / Faerie Walnut      -> Royal Jam / Cup of Wishes
+ Beast Zombie:   Chocolate / Medical Herb       -> Chocolate / Cup of Wishes
+ Howler:         Candy / Medical Herb           -> Candy / Cup of Wishes
+ Marmablue:      Faerie Walnut / Cup of Wishes  -> Faerie Coconut / Faerie Walnut
+ Shape Shifter:  nothing / nothing              -> Faerie Coconut / Faerie Walnut
+ Eggplant Man:   Cup of Wishes / Watcher Ring   -> Cup of Wishes / Faerie Coconut
+ Needlion:       Royal Jam / Needle Helm        -> Royal Jam / Needle Helm
+ Mimic Box:      Faerie Walnut / Royal Jam      -> Faerie Coconut / Faerie Walnut
+ Captain Duck:   Royal Jam / Duck Helm          -> Royal Jam / Cup of Wishes
+ Rabite:         Candy / 4gp                    -> Candy / Rabite Cap
+ Dark Knight:    Magical Armor / Gauntlet       -> Faerie Walnut / Gauntlet

key:
- indicates new monster
+ indicates repeated monster