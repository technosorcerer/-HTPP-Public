For more than one player use the multiplayer version. It inactivates the abilty to "leave characters behind and warp them back to you" which is very buggy when there are 2 or 3 players.

For any bug, issue or question about the hack, you can contact me by the romhacking.net forum. Use the following topic: https://www.romhacking.net/forum/index.php?topic=38152.0