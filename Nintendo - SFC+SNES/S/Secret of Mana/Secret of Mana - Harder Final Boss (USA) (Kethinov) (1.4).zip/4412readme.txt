~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
====================================
Secret of Mana Harder Final Boss 1.4
by Kethinov                 Mar 2019
====================================
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

This patch significantly steps up the difficulty of the two phases of the final boss fight (Dark Lich and Mana Beast) so as to subvert the "final boss is a pushover" trope common to so many RPGs. These fights will now be much longer and reasonably challenging even if you max level your characters.

Specific changes for Dark Lich:

- Level increased from 72 to 99.
- HP increased from 6666 to 46666.
- MP increased from 99 to 255.
- Strength increased from 74 to 99.
- Intelligence increased from 96 to 99.
- Wisdom increased from 96 to 99.
- Spell power increased from 44 to 99.
- Spell list changed from the rather nonthreatening Freeze, HP Absorb, Earth Slide, Thunderbolt, Dark Force, Evil Gate, and Dispel Magic each against a single target to the much more vicious combination of Blaze Wall against all targets and MP Absorb sometimes against all targets, sometimes against one target.
- Dark Lich will attack more aggressively and go underground less often.
- Incorporated "Fix Dark Lich Head Bang Glitch" hack to prevent Dark Lich from being pinned using the "head bang" glitch. Side effect: he will no longer chase you when he is underground, but this was easily avoided in the original AI logic anyway by staying to his left or right.

Specific changes for the Mana Beast:

- Level increased from 73 to 99.
- HP increased from 9990 to 65535.
- MP increased from 99 to 255.
- Spell power increased from 45 to 99.
- Now immune to all elements.
- Will now no longer waste time casting Wall. In the original game this mechanic could be exploited to prevent it from casting Lucent Beam.

Important things to note:

- Because these fights will be so much longer now, you might want to consider combining this with patches that introduce the "Faerie Coconut" second MP restorative item and/or patches that increase the total number of items you can have in your inventory as well to take the edge off a bit.
- If you want to apply any game-wide difficulty mods such as the hacks in "Adjust Enemy Difficulty," be sure to apply those first, then this hack after.

Changelog:

- 1.4: Increased MP of the two bosses. Also fixed Analyzer glitch. Thanks to Queue for providing additional code that makes this possible.
- 1.3: Overhauled Dark Lich AI and fixed crash during Mana Beast fight.
- 1.2: Mana Beast now more aggressive (will no longer waste time casting Wall).
- 1.1: Mana Beast now immune to all elements.
- 1.0: Initial version.