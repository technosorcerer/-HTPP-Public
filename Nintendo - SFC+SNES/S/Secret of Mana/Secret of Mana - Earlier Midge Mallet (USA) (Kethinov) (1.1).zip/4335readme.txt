~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
=======================================
Secret of Mana Earlier Midge Mallet 1.1
by Kethinov                    Jan 2019
=======================================
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

This patch makes it possible to get the Midge Mallet as soon as you retrieve the stolen water seed.

In the original version of the game you had to first return the stolen water seed to the Water Palace before the dwarf elder would give the Midge Mallet to you. That original logic made the Midge Mallet easy to miss since you'd have to double back to Gaia's Navel to get it which would be going significantly out of your way for a relatively minor item.

Important things to note:

- Apply this to an unheadered ROM.
- How to combine this with the Variable Width Font hack: 1. Apply VWF, 2. Remove header, 3. Apply Earlier Midge Mallet, 4. Apply Earlier Midge Mallet VWF support.
- How to combine this with Relocalized: 1. Apply Relocalized, 2. Apply Earlier Midge Mallet, 3. Apply Earlier Midge Mallet Relocalized support.

Changelog:

- 1.1: Added support for Relocalized.
- 1.0: Initial version.
