~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
=====================================
Secret of Mana Later Midge Mallet 1.4
by Kethinov                  Feb 2019
=====================================
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

This patch prevents acquisition of the Midge Mallet until after you've acquired Flammie, which adds a small amount of additional difficulty to the game.

In the original version of the game it was possible to get the Midge Mallet from the dwarf elder just before going to the Upper Land. Doing so required having to double back a bit to retrieve it, but it was generally worth it to get this fairly handy item so early, otherwise you'd have to wait until you get Flammie before you can go back to retrieve it.

Important things to note:

- This patch is incompatible with the "Earlier Midge Mallet" hack for rather obvious reasons. You must choose one or the other. Thanks to Timbo for suggesting this alternative version of the hack.
- How to combine this with the Variable Width Font hack: 1. Apply VWF, 2. Remove header, 3. Apply Later Midge Mallet VWF version.
- How to combine this with Relocalized: 1. Apply Relocalized, 2. Apply Later Midge Mallet Relocalized version.

Changelog:

- 1.4: Slight change in code to prevent acquiring Midge Mallet during Empire Castle events. Also simplified patching process.
- 1.3: Actually fixed it this time.
- 1.2: Fixed bug preventing this from working correctly.
- 1.1: Added support for Relocalized.
- 1.0: Initial version.