-=======================Secret of Mana: Relocalized v1.7======================-
                                    By Timbo

							  
-==================================DISCLAIMER==================================-

This hack is an offshoot of FuSoYa's VWF Edition hack. The bulk of
the script changes were created by FuSoYa's Niche. I am not the original
author of the script changes or the VWF hack. You can find out more about
Secret of Mana VWF Edition here:

https://www.romhacking.net/hacks/18/

-=================================Instructions=================================-

This hack must be applied to a clean non-headered US version of Secret of
Mana.  To apply the patch you'll need an IPS patching program like Floating
IPS. You can find Floating IPS here:

https://www.romhacking.net/utilities/1040/

-================================Information===================================-

About Relocalized:

Secret of Mana - Relocalized focuses on updating, uncensoring, and
relocalizing" gameplay, graphical and text (both script and non-script)
elements of Secret of Mana

- Death Machine: AKA Kettle Kin gets restored to its full uncensored chainsaw
  wielding glory. Not only is this a graphical hack, it also rewrites the its
  AI to perform just as it did in the original Japanese release. 

- Teleportation Circles: When Square released this game in 1993 Nintendo of
  America had strict policies against religious imagery appearing in its
  titles. The six-pointed stars in the teleportation circles were reduced to
  triangles. This hack restores them to their original appearance.

- Title Screen Background: When Square ported this game over to English, they
  butchered the original background image. Because of some graphical problems
  they cropped the image of the full Mana Tree at its roots and expanded it.
  The result is a blurry pixelated mess. Relocalized restores the original
  image.

- Opening Text Crawl: Relocalized updates the text crawl to that of the
  superior HD version.

- Relocalization: The titular feature. This hack takes the game's outdated,
 awkward, and inaccurate text and script elements and localizes them
 differently. Just like with FuSoYa's hack before it, Relocalized holds true to
 the style of beloved 90's Squaresoft translator, Ted Woolsey.


For a full list of changes see the changelog below the credits.

-===================================Credits====================================-

FuSoYa 		- The original creator of the VWF hack that this is based upon.
Mziab 		- Programmer/Hacker. Created script insertion tools.
Queue		- Restored the original title screen and uncensored Kettle Kin.
Regrs		- Created the mixed case naming hack.
Justin3009 	- Created spacing Fix in the Weapon/Magic Level menu.
Bahabulle	- Created the tools that modify the intro text.
Timbo		- Everything else.

-================================Special Thanks================================-

I just want to thank everyone else who helped with this hack in indirect ways.
Whether that was by providing me with tools and hacks developed by others,
debugging and documenting miles of unexplored code, listening to me rant,
proofreading my work, helping me with hacks that didn't make the cut, or
creating a website that inspired me to actually make this hack. Your help was
essential. Zhade, Moppu, Hiei-, Kethinov, Kiyoshi Aman, and anyone else
that I have most certainly forgetten. Thank you.

-==================================Changelog===================================-

v1.7 Changes
- Changed "Raring to go!" to "Ready for a fight!"
- Changed "Burned out!" to "All tuckered out!"
- Changed "Enemy wimps out!" to "Ha! Buncha' wimps!"
- Changed "Won't fit." to "doesn't fit."

v1.6b Changes
- Fixed "I'm was born in the Empire..."
- Fixed minor text oversights.
- Changed casing format that caused "'s Poisoned!" to display as "      P".
- Fixed Action Grid text bug.
- Fixed crash that occurs from trying to skip naming a character. 

v1.6 Changes
- Mixed case character naming now possible.
- Removed the last remaining reference to Popoi's gender in the script.
- Spell descriptions have been updated to allow for room for statistical data.
- Minor casing changes.
- Reverted back to old punctuated message system.
- Miniaturized was too long. It's system message was changed to "Shrank!"
- Miniaturized's status was changed to "Shrunk".
- Unconscious was too long. It's system message was changed to "Asleep!"
- Unconscious' status message was changed to "Asleep"
- Burning's system message was localized to "Ablaze!"
- Burning's status was localized to "Ablaze".
- Gigas whip was corrected to Gigas' Whip.
- Diamond Missile was localized to Diamond Shards.
- Freeze was localized to Ice Smash to match later entries in the series.
- Detect was localized to Analyze for comprehensiveness.
- Sleep was reverted back to Sleep Flower because the change was unnecessary.
- Dispel was reverted back to Dispel Magic because the change was unnecessary.
 
v1.5 Changes
- Major Overhaul to the entire system message system.
- Changed "Tangled" status to "Slowed"
- Changed "Frostied" status to "Frozen"
- Changed "Ballooned" status to "Stunned"
- Changed "Shrunk" status to "Miniaturized"
- Changed "Engulf" status to "Burning"
- Minor adjustments to weapon and spell descriptions.
- Removed subtitle from title screen.
- Changed "Hit %" to "Accuracy %"
- Changed "Tinkly Barrier" to "Twinkly Barrier"
- Changed "Lycanslayer" to "Beastslayer"
- Changed "Silver Chain" to "Silver Whip"
- Changed "Chain Flail" to "Morningstar Whip"
- Changed "Chain Hammer" to "Hammer Whip"
- Changed "Diamond Chain" to "Diamond Whip"
- Changed "Gigas Chain" to "Gigas Whip"
- Changed "Blue Sorbet" to "Blue Bavarois"
- Changed Turtle Guard to Tortoise Guard
- Changed "Gas Cloud" to "Bluster Gas"
- Changed "Shadow x1" to "Shadow Boy"
- Changed "Shadow x2" to "Shadow Girl"
- Changed "Shadow x3" to "Shadow Sprite"
- Changed "Jabberwocky" to "Jabberwock"
- Changed "Frost Gigas" to "Frost Giant"
- Changed "Fire Gigas" to "Fire Giant"
- Changed "Thunder Gigas" to "Thunder Giant"
- Changed "Frost Gigas" to "Frost Giant"
- Changed "Sleep Flower" to "Sleep"
- Changed "The ultimate chain." to "The ultimate whip."
- Corrected typo "The village is a shambles!"
- Corrected typo "regain it's power"
- Corrected typo "and invitation"
- Changed "Water Palace" to "Water Shrine" at Gaia's Navel Cannon Man.
- Fixed Pamaela's Grandfather's dialogue bug.
- Changed Burst's icon from red to green to match it's graphics.
- Continued to resist the urge to change "Flail of Hope" to "Vampire Killer".

v1.4 Changes
-Replaced last remaining instance of "GP" with "L"
-Changed "Stamina" to "Fortitude" in the Status and Skills Menus.
-Replaced "wait 'till you have 100% power" with  "wait 'till your stamina is
 at 100%".
-Added Queue's gorgeous title screen hack and stuck his name in the credits.
-Adjusted the intro text to accommodate for the Title Screen hack.
-Restored Kettle Kin to his pre-censored Death Machine form with Queue's
 Kettle Kin hack.
-Added a new Weapon/Magic Levels icon. It replaces the ugly magic icon with a
 staff like the remake.
-Corrected some very minor shading issues with some of the game's menu icons.
-Restored the teleportation circles in the Haunted Forest back to their
 pre-censored versions.
-Fixed the GOGOGOGOGOGOGOGO bug.
-Changed Morning Star to Chain Flail.
-Changed Hammer Flail to Chain Hammer.
-Changed Flaming Cocktail to Fiery Cocktail.
-Changed Twinkly Barrier to Tinkly Barrier.

v1.3 Changes
-"Seiken Densetus II: Removed from the game's logo.
-Legalese restored to the opening of the text crawl but removed entirely from
 the end. In it's place is the subtitle "VWF Edition: Relocalized"
-Instances of "Money" or "GP" replaced with "Lucre" or "L"
-Minor text edits.
-Final Credit Sequence adjusted.

v1.2 Changes

It was brought to my attention that the Cobra Shuttle looks like a boomerang
when thrown in combat. As such it's getting it's original English nonsense
name back. Additionally, some changes were made to whip names to better match
them to their icon graphics.

-Reverted Manji Shuriken back to Cobra Shuttle
-Reverted Hira Shuriken back to Shuriken
-Changed Full Moon Ring to Moonring Blade
-Reverted Chain Flail back to  Chain Whip
-Changed Silver Flail to Silver Chain
-Changed Morning Star to Star Flail
-Changed Diamond Flail to Diamond Chain
-Changed Gigas Flail to Gigas Chain

v1.1 Changes:
-Intro changed to the HD remake script.
-The title screen was modified.
-A forth wall breaking reference was removed.
