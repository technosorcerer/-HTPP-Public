~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
===================================================================
Secret of Mana Gaia's Navel With the Girl Without Doubling Back 1.1
by Kethinov                                                Mar 2019
===================================================================
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

This patch is an extremely minor quality of life improvement which resolves an annoying catch 22 near the beginning of a playthrough: If you get the girl before the sprite and you go to the Haunted Forest, you will get turned back for want of an axe from Gaia's Navel. But if you go to Gaia's Navel first, the girl doesn't understand why you'd want to go there and she forces you to uselessly go to the Haunted Forest first only to get turned back for want of an axe from Gaia's Navel.

With this patch applied, the girl will not force you to go to the Haunted Forest before Gaia's Navel. You can go straight to Gaia's Navel without any fuss.

Important things to note:

- Apply this to an unheadered ROM.
- How to combine this with the Variable Width Font hack: 1. Apply VWF, 2. Remove header, 3. Apply Gaia's Navel With the Girl Without Doubling Back, 4. Apply Gaia's Navel With the Girl Without Doubling Back VWF support.
- How to combine this with Relocalized: 1. Apply Relocalized, 2. Apply Gaia's Navel With the Girl Without Doubling Back, 3. Apply Gaia's Navel With the Girl Without Doubling Back Relocalized support.

Changelog:

- 1.1: Added support for Relocalized.
- 1.0: Initial version.
