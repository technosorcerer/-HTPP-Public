~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
========================================
Secret of Mana Better Default Text Boxes
by Kethinov                     Jan 2019
========================================
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

This patch changes the default text box to make it more readable and attractive.

Specific changes:

- The message box border has been changed from the original game's default of "basic" to the "curved frame" option. This border is in the original game, but it is not the default.
- The "horizontal line" message box background pattern has been altered to be a solid color.

Important things to note:

- Apply this to an unheadered ROM.
- The original text box border and background can still be used. They are in the options as off by default options.
- The original text box border is still used for some interfaces, most notably the new game / load save screen.