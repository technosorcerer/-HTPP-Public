~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
=============================================
Secret of Mana No HP Restored At Level Up 1.0
by Kethinov                          Jan 2019
=============================================
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

This patch increases the game's difficulty slightly by no longer giving you a free heal whenever you level up.

Apply this to an unheadered ROM.