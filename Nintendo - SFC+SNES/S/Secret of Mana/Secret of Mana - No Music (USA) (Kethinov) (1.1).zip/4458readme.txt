~~~~~~~~~~~~~~~~~~~~~~~~~~~
===========================
Secret of Mana No Music 1.1
by Kethinov        Apr 2019
===========================
~~~~~~~~~~~~~~~~~~~~~~~~~~~

This hack removes all music from the game, but leaves (most of) the sound effects in place. This allows you to play audio from another source like blasting your stereo without having to mute the game's sound effects along with its music. Good for playing living room co-op with your friends if you enjoy the hack and slash sounds but you want to put on some different music.

Some important things to note:

- Known issue: A small number of sound effects are disabled too because they either require interaction with the game's music to function correctly (e.g. earthquake and waterfall) or they are misclassified in-game as music (cannon travel firing).
- Apply this to an unheadered ROM.
- How to combine this with the Variable Width Font hack: 1. Apply VWF, 2. Remove header, 3. Apply No Music, 4. Apply No Music VWF support.
- How to combine this with Relocalized: 1. Apply Relocalized, 2. Apply No Music, 3. Apply No Music Relocalized support.

Changelog:

- 1.1: Added support for Relocalized.
- 1.0: Initial version.
