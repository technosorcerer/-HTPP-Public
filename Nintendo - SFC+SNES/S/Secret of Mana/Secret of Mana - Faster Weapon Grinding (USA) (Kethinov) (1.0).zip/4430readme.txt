~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
=========================================
Secret of Mana Faster Weapon Grinding 1.0
by Kethinov                      Mar 2019
=========================================
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

This hack offers four different options for increasing the pace of weapon grinding.

Technical details: The weapon skill gain point formula uses a constant of 9, subtracts current weapon level, then divides that by either 2 or 4 depending whether or not you got the kill or the enemy's level is higher than yours. This hack increases the constant of 9 to up to 15 in order to step up the pace of weapon level grinding.

Hack list:

- "A Bit Faster" - Only slightly faster than the original game.
- "Moderately Faster" - This will be noticeably faster than "A Bit Faster."
- "Much Faster" - This will be significantly faster than the first two hacks.
- "Zippy" - Fastest.

Why only faster skill gain options and no options to slow it down? Two reasons:

1. Weapon skill gain is already pretty slow in the original game. You'll never be able to get close to level 8 on most weapons unless you do a lot of unnecessary level grinding.

2. Adjusting the formula in this way can't be used to slow down weapon skill gain without creating unacceptable side effects. It is technically possible to make a hack that slows down weapon skill gain, but it would require significantly rewriting the weapon experience subroutines to do it, which should be covered by a different (more complex) hack.

Apply this to an unheadered ROM.