~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
===========================================================
Secret of Mana Level 9 Weapons Progression Balance Hack 1.7
by Kethinov                                        Mar 2019
===========================================================
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

This patch adds 10 new weapon orb acquisition events to the game such that you will be able to upgrade all weapons to level 9 after completing the Pure Land before visiting the Mana Fortress.

This resolves a number of frustrating quirks in the original game. For instance, in the original game by the time you reach the Mana Fortress, despite the fact that there are 9 versions of each weapon, there are only enough weapon orbs available to upgrade your weapons to level 8, except for the glove and axe which are even more frustratingly stuck at 7.

In the original game you can farm the missing orbs in the Mana Fortress by defeating various monsters, but because they are rare drops, it takes an eternity to do so. And even if you do so, that still excludes upgrading the sword to level 9 (without exploiting some well-known glitches) because the game was hardcoded to only let you have the fully powered Mana Sword for the final boss fight once it is "activated" by the Mana Magic spell, allowing you to use it at full power for only a frustratingly short amount of time.

To resolve those issues, this hack makes the following changes:

- New glove orb chest in Elinee's Castle. (Monster in a dead-end room converted.)
- New glove orb chest in the Underground City. (There was always supposed to be two additional orb chests that spawned there, but in the original game they were broken.)
- New axe orb chest in Elinee's Castle. (Monster in a dead-end room converted.)
- New axe orb chest in the Underground City. (There was always supposed to be two additional orb chests that spawned there, but in the original game they were broken.)
- New sword orb chest in the Palace of Darkness. (Monster in a dead-end room converted.)
- New spear orb chest in Fire Palace. (1000gp chest converted.)
- New bow orb chest in Fire Palace. (Monster in a dead-end room converted.)
- New boomerang orb chest in Pandora ruins. (Monster in a dead-end room converted.)
- New javelin orb chest in in Pandora ruins. (Monster in a dead-end room converted.)
- The spear orb chest in the Gold Tower is now a whip orb.
- The Thunder Gigas will drop a spear orb instead of a sword orb.
- When the Mana Tree dies, it will give you the 9th sword orb.
- The cost of upgrading weapons is now half of what it is in the original game.
- There are new money chests in the following locations: a 50gp chest in a Pandora ruins dead-end room, three 1000gp chests in Northtown ruins dead-end rooms, and a 1000gp chest in a Grand Palace dead-end room.

To suit more modest tastes, there are also two subvariants to choose from bundled with this hack:

- Level 8 Weapons Progression Balance: Includes only the new axe and glove orb chests in the Underground City plus the new money chests.
- Mana Tree Grants Mana Sword: Includes only the changes that give you the 9th sword orb when the Mana Tree dies and the new money chests.
- Those two subvariants can be combined if desired.

Some important things to note:

- How to combine this with the Variable Width Font hack: 1. Apply VWF, 2. Remove header, 3. Apply this hack, 4. Apply this hack's VWF support hack.
- How to combine this with Relocalized: 1. Apply Relocalized, 2. Apply this hack, 3. Apply this hack's Relocalized support hack. 
- To combine this with Remove Empire Castle Gate Permanently, apply this hack first.
- If you want to combine this hack with zhaDe's Gameplay Improvement Hack or Queue's Turbo patcher, you must uncheck the "No Missing Orb" option (if it is available in your build), as this hack supersedes that option in that hack.
- All variants of this hack also bundle "Mana Magic Unequip Fix" by Queue, which fixes the bug causing Spike Knuckle to be sometimes be equipped when Mana Magic fades. Also adjusts the non-spell version of the Mana Sword's stats.

==============================
New weapon progression charts:
==============================

Glove upgrades:
1. Tonpole in Undine's lair.
2. Elinee's Castle chest. (New! Monster converted.)
3. Moogle Village chest.
4. Ice Palace chest.
5. Metal Mantis in Northtown.
6. Dark Palace chest.
7. Underground City chest. (New! Was dummied out of the game.)
8. Red Dragon in Pure Land.

Sword upgrades:
1. Mantis Ant in Potos.
2. Pandora Castle treasury chest.
3. Great Viper in Matango.
4. Northtown Ruins chest.
5. Dark Palace chest. (New! Monster converted.)
6. Given by Tasnica's King.
7. Grand Palace chest.
8. Given by Mana Tree. (New!)

Axe upgrades:
1. Fire Gigas in Underground Palace.
2. Elinee's Castle chest. (New! Monster converted.)
3. Moogle Village chest.
4. Fire Palace chest.
5. Empire Castle chest.
6. Gold Tower chest.
7. Underground city chest. (New! Was dummied out of the game.)
8. Dragon Worm in Pure Land.

Spear upgrades:
1. Tropicallo in Dwarf Village.
2. Pandora Castle treasury chest.
3. Santa's House chest in Ice Country.
4. Fire Palace chest. (New! 1000gp chest converted.)
5. Northtown Ruins chest.
6. Aegagropilon in Grand Palace.
7. Mech Rider III in Grand Palace.
8. Thunder Gigas in Pure Land. (Changed from sword to spear.)

Whip upgrades:
1. Scorpion Army ship chest in Dwarf Village.
2. Given by Jema in the Water Palace.
3. Mech Rider I at the Sandship.
4. Doom's Wall in Northtown.
5. Empire Castle chest.
6. Gold Tower chest. (Changed from spear to whip.)
7. Hydra in Underground City.
8. Hexas in Grand Palace.

Bow upgrades:
1. Wall Face in Pandora.
2. Jabberwocky in Water Palace.
3. Boreal Face in Ice Country.
4. Fire Palace chest. (New! Monster converted.)
5. Northtown Ruins chest.
6. Gorgon Bull in Gold Tower.
7. Kettle Kin in Grand Palace.
8. Snow Dragon in Pure Land.

Boomerang upgrades:
1. Spikey Tiger in Elinee's Castle.
2. Pandora Ruins chest. (New! Monster converted.)
3. Spring Beak in Upperland.
4. Frost Gigas in Ice Palace.
5. Vampire in Northtown.
6. Blue Spike in Gold Tower.
7. Underground City chest.
8. Blue Dragon in Pure Land.

Javelin upgrades:
1. Pandora Ruins chest. (New! Monster converted.)
2. Kilroy in Dwarf Village.
3. Truffle's bedroom chest in Matango.
4. Minotaur in Fire Palace.
5. Mech Rider II in Northtown.
6. Lime Slime in Dark Palace.
7. Snap Dragon in Grand Palace.
8. Axe Beak in Pure Land.

New weapon upgrade pricing:
- Level 2: 100gp (was 200gp)
- Level 3: 200gp (was 400gp)
- Level 4: 400gp (was 800gp)
- Level 5: 800gp (was 1,600gp)
- Level 6: 1,600gp (was 3,000gp)
- Level 7: 3,000gp (was 6,500gp)
- Level 8: 6,500gp (was 12,500gp)
- Level 9: 12,500gp (was 25,000gp)

Changelog:

- 1.7: Updated bundled "Mana Magic Unequip Fix" by Queue to use the newly refactored even more efficient version.
- 1.6: Added "Level 8 Weapons Progression Balance" and "Mana Tree Grants Mana Sword" subvariant options. Also bundled "Mana Magic Unequip Fix" by Queue, though refactored the code to use buffer space more efficiently.
- 1.5: Documented new money chests added to dead end rooms. Also refactored some code to improve compatibility with other hacks. Thanks to Queue for providing the code for the refactor.
- 1.4: Potos basement chest reverted back to 50gp instead of 1000gp. Weapon orbs have been moved to more out of the way places, replacing fewer 50gp and 1000gp chests. Full list: Pandora treasury glove orb to Elinee's castle, Pandora treasury axe orb to Elinee's castle, Palace of Darkness sword orb to a dead-end room, moved Fire Palace bow orb to a dead-end room, Pandora treasury boomerang orb to Pandora ruins, and Pandora treasury javelin orb to Pandora ruins. Also added support for Relocalized.
- 1.3: Fixed bug which caused Potos elder to never give his goodbye speech to Randi. Thanks to star_scream1646 for reporting the bug.
- 1.2: Fix for crash caused by 1.1 and internal tweak to make new pricing table compatible with other hacks.
- 1.1: Swapped 1.0's Dark Palace whip orb for Gold Tower sword orb to space out the upgrades better. Thanks to Timbo for the idea.
- 1.0: Initial version.
