~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
===============================
Secret of Mana Magical Herb 1.3
by Kethinov            Mar 2019
===============================
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

This hack changes the Medical Herb into the Magical Herb, rendering it slightly more useful / less useless. Now in addition to removing negative status effects, it will remove positive ones too. This is as though both Remedy and Dispel Magic were cast on you, which is especially useful if you need to remove Wall status. Though unlike Dispel Magic, the Magical Herb will remove Lucid Barrier and Moon Energy status from you too. The Herb's animation has also been changed into a darker-hued more purple-tinged version of the Remedy animation to signify that it eliminates both positive and negative status effects.

Note: This hack is not compatible with Stardust Herb and they should not be combined.

Changelog:

- 1.3: Fixed bug with Lucid Barrier not dispelling all the way.
- 1.2: New animation. Also now dispels Lucid Barrier and Moon Energy. Thanks to Queue for help with some of the refactoring.
- 1.1: Changes to improve compatibility with other hacks. Thanks to Queue for help refactoring.
- 1.0: Initial version. Thanks to Timbo for inspiring this concept. The development of this hack was a side effect of helping Timbo develop a similar (though mutually exclusive) item mod called Stardust Herb, so check that out too!