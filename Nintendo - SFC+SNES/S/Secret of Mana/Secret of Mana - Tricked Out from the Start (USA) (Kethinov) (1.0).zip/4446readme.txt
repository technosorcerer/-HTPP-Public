~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
=============================================
Secret of Mana Tricked Out from the Start 1.0
by Kethinov                          Apr 2019
=============================================
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

This is a bundle of two hacks that are essentially cheating:

1. Start Rich: You will start out with 65535gp.
2. Best Armor at the Start: Each character will start out with their best armor initially equipped.

Applying either one of these hacks (especially the second one) will make you nearly unstoppable and render the game incredibly easy. If plowing through the game in god mode is your thing, then try this out.

Apply this to an unheadered ROM.