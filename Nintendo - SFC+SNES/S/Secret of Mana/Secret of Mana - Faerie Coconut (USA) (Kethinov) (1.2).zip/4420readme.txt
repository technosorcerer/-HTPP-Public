~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
=================================
Secret of Mana Faerie Coconut 1.2
by Kethinov              Mar 2019
=================================
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

This hack restores the unused consumable item back into the game. The new item, now called the Faerie Coconut, restores 50mp and features a new animation. The Faerie Walnut has been revised to restore only 25mp to balance things out and its price has been reduced accordingly.

The drop table and shops have been edited very slightly to make it possible to acquire this new item.

Drop changes:

- La Funk (Ice Country, Northtown Ruins) will now drop Faerie Coconuts (common) and Faerie Walnuts (rare) instead of Faerie Walnuts (common) and Cups of Wishes (rare).
- Specter (Ice Palace, Northtown Ruins) will now drop Faerie Coconuts (common) and Faerie Walnuts (rare) instead of Faerie Walnuts (common) and Cups of Wishes (rare).
- Dark Funk (Fire Palace) will now drop Faerie Coconuts (common) and Faerie Walnuts (rare) instead of Candy (common) and Faerie Walnuts (rare).
- Emberman (Emperor's Castle, Palace of Darkness) will now drop Faerie Walnuts (common) and Faerie Coconuts (rare) instead of Faerie Walnuts (common) and Chocolate (rare).
- Marmablue (Moon Palace, Joch's Cave, Underground City, Mana Fortress) will now drop Faerie Coconuts (common) and Faerie Walnuts (rare) instead of Faerie Walnuts (common) and Cups of Wishes (rare).
- Shape Shifter (Joch's Cave, Mana Fortress) will now drop Faerie Coconuts (common) and Faerie Walnuts (rare) instead of nothing.
- Mimic Box (Joch's Cave, Mana Fortress) will now drop Faerie Coconuts (common) and Faerie Walnuts (rare) instead of Faerie Walnuts (common) and Royal Jam (rare).
- Kimono Wizard (Underground City, Mana Fortress) will now drop Faerie Coconuts (common) and Faerie Walnuts (rare) instead of Faerie Walnuts (common) and Royal Jam (rare).

Shop changes:

- Faerie Coconut is now buyable (replacing Medical Herb) from the following shops: Upperland Neko, Matango, Kakkara, Todo, Southtown, Northtown, Gold Isle, and Grand Palace.
- Replaced Silver Band with Frosty Ring in Southtown. A Frosty Ring was always intended to be purchasable at Southtown, but a bug in the game prevented it from appearing in the item ring.

Important things to note:

- This hack is mostly compatible with Drop Table Balance, but Drop Table Balance must be applied first. The drop changes in this hack are meant to be a reasonable enhancement to the original spirit behind the balance considerations in Drop Table Balance and will feel appropriate when applied to either Drop Table Balance or to the original game.
- Because this hack modifies the shops, it may not be compatible with other hacks that modify the shops. The choice to replace Medical Herbs with Faerie Coconuts in some shops means the technical changes to the ROM are very minimal, so this increases the likelihood of compatibility with other hacks that also modify the shops in small ways too. However, this hack will not be compatible with any hack the modifies the shops extensively, e.g. a hack that modifies the number of items each shop has or changes the shop pointer table.
- A companion hack "Faerie Coconut Replacement Graphic" has also been included. This hack replaces the graphic for the Faerie Coconut with a graphic that looks more explicitly like a coconut. The original graphic was a graphic that was included in the original game, but dummied out and went unused. The concept of the "Faerie Coconut" was created for the unused item it because it looked sort of like a coconut. But ThanatosZero suggested incorporating a graphic that looked more like a coconut and did a great job producing such a graphic. Timbo then did the hacking work to incorporate the graphic into the ROM. You can optionally apply that hack atop this one depending on which graphic you prefer.

Changelog:

- 1.2: Reverted the Fierce Head rare drop back to Unicorn Helm.
- 1.1: Added "Faerie Coconut Replacement Graphic" companion hack.
- 1.0: Initial version.