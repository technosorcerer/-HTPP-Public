Secret of Mana Plus 2.00

-------------
PRESENTATION
-------------
This hack extends Secret of Mana on Snes.

The extended/added chapters are:
- The Wind Palace: explore this new dungeon and stop the Empire invasion.
- The Empire: travel between Southtown and Northtown on a new road.
- The Gold Tower: face extra adversities to obtain the key and climb the added levels.
- The Moon Palace: a mysterious presence awaits you in the new depths of this eerie place.
- Weapon orbs side quests: 8 new weapon orbs have been hidden throughout the world for more powerful weapons.

The new zones and maps feature:
- Additionnal monsters and bosses: new versions of vanilla enemies with their own stats/spells/colors...
- Cutscenes: The new maps are integrated into the main story and add new plot points through numerous cutscenes.

Other changes:
- After you find the Mana Tree, you'll still be able to fights some griffin hands in the pure land.
- Pecard the lighthouse caretaker now gives you hints to find the new weapon orbs.
- Restored the JP version of teleporters in the haunted forest.
- The 2 bosses (Buffy and Dread Slime) now drop weapon orbs.
- The Dark Stalker in Tasnica is now a bit tankier.
- The Biting  Lizards in Ice Country have been buffed.
- The Lofty Mountains background scrolling has been fixed.
- Restored some dwarfs who were disappearing after Tropicalo.
- Fixed bug of v1 that would in some rare occasions get you stuck at the end of Grand Palace.
- Fixed bug of v1 that would let Jehk revive you outside the Lofty Mountains. 


Besides the additionnal content, the core game remains unchanged.

------------
MULTIPLAYER
------------
Another version of the hack is no longer needed to play multiplayer, the CPU not blocking screen hack should now work nicely even in multiplayer.

------------------
ENHANCEMENT HACKS
------------------
This hack includes the following enhancement hacks by other talented creators:
- Max consumable count increased from 4 to 7 (by Moppleton)
- Allow allies to leave the edge of the screen (by Moppleton and zhaDe): allies will not get you stuck anymore.
- Elemental melee damage (by Moppleton): Elemental sabers will cause 1.5 times damage against the right element, and half damage against the wrong element.
- Enemy species damage (by Moppleton): 1.5 attack against targets whose species is weak to the weapon you have equipped.
- Spell grinding speed-up hack (x2) (by Kethinov)
- Improved screen scrolling for better visibility when moving around (by Binarynova, zhaDe and Queue)
- Kettle Kin chainsaw restoration (by Queue)
- Title screen image restoration (by Queue)

------------------
HACK COMPATIBILTY
------------------
Secret of Mana Plus is NOT compatible with TURBO, REBORN or the RANDOMIZER.

This hack required some heavy rom modification so it conflicts with a lot of other hacks.
- NOT compatible with any hack modifying maps, NPCs or monsters placement.
- NOT compatible with any hack changing monsters stats as it will not affect new monsters.
- NOT compatible with many hacks modifying spells as it may conflict with new monsters AI.

For any issue, question or feedback about the hack, you can contact me on my blog https://hackofmana.com/