Sword World SFC
~English Translation 0.98 Beta~

All dialogue, system, and menu text should be translated.
If you find anything untranslated, a bug report is welcome.

Original ROM checksum should be 0xC11B.

Known issues:
1) Name entry is mostly non-functional
2) Character creation has irregular text
3) Options screen text is garbled

If you would like to report bugs or discuss Sword World, please
join the SW unofficial discord:

https://discord.gg/GnFbBQkmMa

---
Credits:
Hacking, editing, translation: bent

Based on translations by Auquid and Lu