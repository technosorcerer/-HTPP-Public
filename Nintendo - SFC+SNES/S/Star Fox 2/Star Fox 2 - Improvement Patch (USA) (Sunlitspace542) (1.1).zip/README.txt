Star Fox 2 Improvement Patch
-=By Sunlit=-
This set of patches provides fixes and improvements for Star Fox 2.
Changes:
NTSC-U/PAL:
- Fixed twin laser capsule using prototype graphics in the US version
- Battleship emblem texture replaced with skull texture from the AG 6/22 translation patch
- Fixed Taitania not being localized to Titania in the US version
- Fixed Wolf introducing himself as "Star Wolf" and other script typos
PAL:
- Starwing 2 title logo and PAL ROM header
- Optimizations for running at PAL 50hz (i.e. framerate cap increased to 25fps like Starwing (PAL Star Fox 1)
ALL:
- View can be changed in space by pressing select (as in the AG 6/22 translation patch)
- Title screen copyright year changed to 2017 to reflect the official SNES Classic release
- Freed up some ROM space
- Internal build date changed to the build date of the final version of Star Fox 2 (95-09-20 @11:02 AM JST)
- Changed the ROM version field in the header to 01 (Rev. 1)
- Optional patch to enable homing by default

Credits:
Josete2K: Starwing 2 title logo (touched up by me)
Aeon Genesis: Battleship emblem texture
Sega Mega Drive: Titania text sprite

PATCHING INFORMATION

SF2Improvement_U.bps - USA version
SF2Improvement_J.bps - Japanese version
SF2Improvement_E.bps - European/PAL version

SF2Improvement_*_Homing.bps - Patch for a particular region (J/U/E) with homing enabled by default

SF2Improvement_U(_Homing).bps and SF2Improvement_E(_Homing).bps apply to a USA Star Fox 2 SNES Classic ROM.
SF2Improvement_J(_Homing).bps applies to a Japanese Star Fox 2 SNES Classic ROM.


