Very Hard Type
weapon scaling adjustments*
accuracy on all weapons has been decreased to 1 (increase firearms skill to raise accuracy)
decrease to weapon damage
start with strength and charisma at 1 instead of 3
slap patches heal 50% less.. 5hp instead of 10
your magic costs 2x more mp.. all spells cost 4 more mp to cast
your magic is 50% less effective in damage and duration
dermal armor only gives 1 armor point instead of 2
high-tier armor is 1 armor point less-effective (matches strength requirement)
Orc, Mage, and Heavy Dude's base hit points are doubled
enemies drop 50-75% less nuyen

the colt is auto-fire


*very hard weapon scaling adjustments
gun- original str.dam.acc. - very hard str.dam.acc
berreta- 1.3.1 - 1.1.1
colt- 1.3.1 - 1.2.1
Fichetti- 1.4.1 - 1.3.1
Viper- 2.4.2 - 2.4.2
WHawk- 3.6.2 - 3.5.1
Shotty- 4.8.2 - 4.6.1
uzi- 4.8.3 - 3.7.1
Rifle- 5.10.2 - 5.8.1
Cannon- 5.20.6 - 5.15.1

There is a great risk-reward ratio to be found in Shadowrun as the difficulty scale increases.
The further out a player gets from their last nap, the riskier the rewards become.
Save often chummer.


All thanks go to Tony Hedstrom for the very awesome Shadowrun editor.
What a legend.
