applies some of the fixes from the previous retail hacks to the beta ROM:
 
-enables Bulletproof Vest at the Dark Blade shop
-caps Firearm skill at 6
-fixes 'default equipment' bug: http://www.gamefaqs.com/boards/588651-shadowrun/53197837