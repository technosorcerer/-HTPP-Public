Fixes so far:
Shadowrunner weapon equip/unequip bug
-described above
Bulletproof Vest available upon reaching Dark Blade (with thanks to Lenophis)
-self explanatory fix, but you have to equip a weapon before reaching Dark Blade
Firearms stat capped at 6
-mentioned above, discussed here: http://www.gamefaqs.com/boards/588651-shadowrun/50907622
Jangadance and Orifice weapon sounds
-Jangadance was using a light pistol with the heavy sound
-Orifice was using a heavy weapon with the auto sound

Dragoon ZERO