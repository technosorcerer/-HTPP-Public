includes all the changes from the 20100830 patch and also:

I haven't had a lot of time to work on this, I just forced the Head Computer keyword in to the list at game start and starting looking into a few other things.