Shadowrun (Better Negotiation)
Oct. 18th 2025
BillyTime! Games
--------------------
This patch is designed to add an extra benefit to the Negotiation attribute Shadowrun for the Sega Genesis

How it works
--------------------
Each time you level up your Negotiation attribute at an Inn. Gundersons will start to offer you increasingly more money per run.
All character classes receive a buff due to this change. 


How to Patch:
--------------------
1.Grab a copy of Shadowrun (USA).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file