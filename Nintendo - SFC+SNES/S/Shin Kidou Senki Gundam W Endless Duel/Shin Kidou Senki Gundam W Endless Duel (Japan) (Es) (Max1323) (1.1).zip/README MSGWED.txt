"Mobile Suit Gundam W: Endless Duel"
Traducción al Español Ver. 1.1 (04/11/2024)
por Max1323 (Traducciones Max1323).
Basada en la traducción de Aeon Genesis.
---------------------------------------------------
Descripción:
Mobile Suit Gundam Wing: Endless Duel esta basada en el anime del
mismo nombre. Es un juego de peleas exclusivo de Japón.
Los desarrolladores usaron el mismo motor que Mighty Morphin Power Rangers: The Fighting Edition, pero con algunas mejoras.

Desarrollado: Natsume
Publicado:    Bandai
Lanzamiento:  29/03/1996 (JAP)
---------------------------------------------------
Acerca del proyecto:
-La mayoría de los textos están traducidos. Se agregaron
solo los caracteres ñ, ¿, ¡.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS (PC)
Utilizar UniPatcher (Android)
Utilizar Rom Patcher (Parcheador Online):
https://romhackplaza.org/patch/

Archivo IPS
Shin Kidou Senki Gundam W - Endless Duel (Japan).sfc/smc
File Size     2.00 MB
File MD5      E2C3CC007C2C1C358BFE50EAD5C8B9AC        
File SHA-1    6710686B5A3D6620DF9FD6A5820E1717AFFF2D95
File CRC32    C0AECDCA