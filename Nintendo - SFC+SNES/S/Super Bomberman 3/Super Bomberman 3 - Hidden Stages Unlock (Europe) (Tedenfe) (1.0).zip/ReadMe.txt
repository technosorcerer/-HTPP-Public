This patch unlocks all Battle Mode hidden stages, it also works with the NTSC patch provided by GhostlyDark, and I added a patch for those who wants to use in the Japanese ROM.

Enjoy!

Tedenfe - https://www.romhacking.net.br/