- Sunlit's Untitled Star Fox Minihack 2: Quest for the $19 Fortnite Card -
Release 1.0
BPS patch version

- ABOUT THIS HACK -
The long awaited sequel to Sunlit's Untitled Star Fox Minihack.

One route, 6 Stages, mostly planets. I can't speak for the difficulty, but if you can beat the original Star Fox, this shouldn't be terrible.
Also lots of added-in dialogue. It was fun to write that stuff.

It's more Star Fox, who cares?

Hack start date: November 14, 2022
Hack completed: July 3, 2023

- PLOT -
General Pepper's $19 Fortnite Card has been stolen by Andross! The Star Fox team is sent to retrieve it.

- PLAYING THE GAME - 
UntitledStarFoxMinihack2_v1.0_FastROM is for Emulators (and 1CHIP revisions of the SNES, if running with an FXPakPro or SD2SNES.)
UntitledStarFoxMinihack2_v1.0_SlowROM is recommended for real hardware and weaker emulators (ex. 3DS) and anything else that can't run the FastROM version.
The performance difference between FastROM and SlowROM is negligible, though FastROM is recommended if possible.
The BPS format patches apply to a headerless Star Fox (USA) 1.0 ROM.

- CREDITS -

Director:
Sunlit

Assistant Director and Moral Support:
Monika

Thanks To:
Kandowontu
SFEX Team
Monika
Original Devs