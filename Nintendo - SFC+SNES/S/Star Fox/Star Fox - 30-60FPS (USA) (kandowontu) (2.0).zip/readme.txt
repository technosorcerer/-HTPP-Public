Hello!

Updates: -Fixed screen flashing after boss defeated
-Fixed 60FPS mode (wasn't doing animations/color cycles at 60fps)
-Added: 2 more fun tests
-Renamed: SF60FPS Variant 2 to SF20FPS 60FPS Elements

This is a set of patches to unlock 30 and 60FPS mode for Starfox!

1) How is this achieved?
2) How do I run it?
3) Can I see the FPS?
4) Disclaimer
5) Credits, Discord, Twitter

1) How is this achieved?

The game has 3 IRQ routines to complete the game cycle of strats (movement/attack/health/etc routines), drawing the screen etc. It does this in 3 game cycles, which limits the game to 20FPS at max.

What has been done is the IRQ routines have been programmed to run right after each other without waiting a game cycle, from irq 2->3 for 30fps mode and from irq 1->2->3 for 60fps mode.

Additionally, every frame will also be drawing as well as doing the strats. What has been done is the strats will only process every 2/3 frames for 30/60fps while still drawing it every frame. This slows the game pace back down.

UPDATE: The current FPS Builds:

SF20FPS 30FPS Elements:
SF20FPS 60FPS Elements:  These both are paced at the original 20fps speed/movements but all animations and color cycles are at 30/60 fps respectively.

SF30FPS v2.0:
SF60FPS v2.0: Both of these are paced closer to 30fps, so slightly faster than the original game but with the smoothness of more frames.

SF60FPS FULL SPEED v2.0: No slowdowns, no pacing, full speed ahead.

SLOWFOX TEST			:
STARFOX TRUE PACING TEST	:Both of these are glitchy tests for your enjoyment


2) How do I run it?

The game does NOT run on console. It requires most importantly a CPU overclock.

SNES9X - CPU OVERCLOCK under HACKS set to MAX

BSNES - CPU OVERCLOCK set to 126% CPU speed (a .BML file is also supplied, put in the same folder as the rom with the same name for BSNES)

MESEN - Set to "Wait 60 scanlines AFTER NMI"

Retroarch SNES9X - CPU OVERCLOCK may be called "REDUCE SLOWDOWN" under HACKS

For the best experience, visit our discord for a custom SNES9X build with faster cpu overclocking ;)

3) Can I see the FPS?

Yes you can! Just press A+B on the title screen to enable the on-screen FPS display.

4) DISCLAIMER

The FPS may fluxuate, especially in 60FPS mode. This is simply due to emulation restrictions. 30FPS mode provides the most solid experience. 60FPS can almost be achieved solidly using a custom SNES9X build that is provided on our discord.

This hack simply unlocks the game's artificial limitations.

5) Credits

All programming, research, testing, trial and error and discoveries by kandowontu

Testing by Sega Mega Drive, Sunlitspace542

http://discord.gg/sfex

http://twitter.com/kandowontu
