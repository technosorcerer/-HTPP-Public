Sunlit's Untitled Star Fox Minihack DX
-Version 1.0-
2025 Emerald Softworks

Released: March 19, 2025
Type of hack: Graphics, Levels, Text

I. About
A Major update to one of my very first Star Fox hacks to make it feel a bit less lazy, as I was limited by what I knew how to do with the game at the time, and the tools available at the time.
The base I use to make these hacks (UltraStarFox) has evolved significantly in the years since, and several new tools have been written to make modifying this game less of a pain.
Simply put, The hack was ported to the latest version of the base UltraStarFox code, and several things were added and changed to freshen things up a bit.

As in the original version, this is a mini Star Fox hack with 1 route and 6 levels. 5 are based on locations from the original game, with 1 new planet.

------

II. Setup

Within the 7z are patches for each region and version of Star Fox/Starwing.
Find the patch that matches the Star Fox/Starwing ROM you have, and apply it with a patcher such as Floating IPS or a web-based patcher such as the one at https://hack64.net/tools/patcher.php.

Supported ROMs:
USA Rev 0, Rev 1, Rev 2
Japan Rev 0, Rev 1
PAL Rev 0, Rev 1, Germany Rev 0

This hack is intended for NTSC consoles. YMMV on a PAL console.

------

III. Credits

Sunlit's Untitled Star Fox Minihack DX presented by Emerald Softworks

EMERALD SOFTWORKS IS:
Sunlit - Director, Lead programmer, Level designer, Graphic designer
Monika - Assistant director, Assistant programmer, Graphic designer

Thanks to
Argonaut Software
Kando
Monika
Nintendo
Original Star Fox Staff
Team SFEX
UltraStarFox contributors

Powered by UltraStarFox

------

IV. Tools Used
General Game Modification:
UltraStarFox codebase and associated tools by Sunlit et al.

Testing/Debugging:
Mesen 2.0 by Sour
SD2SNES/FXPak Pro by Ikari01 & Krikzz

Graphics:
YY-CHR.NET by YY
Tilemap Studio by Rangi42
Superfamiconv by Optiroc
sf_crunch/sf_decrunch by Everything
Paint.NET

Programming:
Visual Studio Code
Notepad++

Misc:
Superfamicheck by Optiroc
WinMerge
HxD

------

V. The Great Big List of Changes from Untitled Star Fox Minihack 1.2 (for those interested)
Ported to latest UltraStarFox code, many under-the-hood changes since original release
New title screen
Map GFX have been touched up a bit
Dialogue changes
Characters' GFX have been changed to reflect their Star Fox 2 designs
Applied Kando's RNG fix and made random teammate selection completely random
Intro and Scramble sequences are now skipped
Minor level design changes to fix some jankiness
New level backgrounds for 1-1 and 1-3
Stage 1-3 overhaul (no longer a Corneria duplicate)
Barrel roll input window doubled to 6 frames
Boss roll text fixed
New credits sequence
Pressing start on the 'THE END' screen reboots the game