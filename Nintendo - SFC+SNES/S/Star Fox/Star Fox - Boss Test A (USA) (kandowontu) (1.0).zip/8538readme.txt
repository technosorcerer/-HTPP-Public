Hi, this is my take on ASM programming for SNES' Star Fox! 

Attempting to make a new boss move/attack/whatever set, basically giving the first level boss a twist haha, feel free to try it out! 

Hopefully it shouldn't glitch out or something, after all it's my first attempt at modifying the game's source code, I used the "ultrastarfox" variant to make it, check it out!

If the game glitches or restarts, just try again please!




Developers: kandowontu and Sunlit
Code/Director: kandowontu
Graphics/Palettes: Sunlit
Music: Random

http://twitter.com/kandowontu
http://patreon.com/kandowontu
https://discord.gg/Xg6bFyC9U3

Made with UltraStarfox
https://github.com/Sunlitspace542/ultrastarfox

Dedicated to and influenced by Randy Becker, the developer of Starfox.exe
http://twitter.com/ProperDeveloper
