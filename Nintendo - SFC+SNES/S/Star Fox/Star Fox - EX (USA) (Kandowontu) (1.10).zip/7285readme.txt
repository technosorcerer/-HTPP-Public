STAR FOX EX Manual

Star Fox EX (Exploration Showcase)

Starfox Exploration Showcase began as a simple set of mods for the game meant to
demonstrate what was possible with the full source code and some clever coding.
It has evolved from a personal project to a complete DLC/Addon for the original
Starfox game, including new courses/backgrounds/music/models/modes/secrets.

The plot, characters, models, features and implementations should be enjoyed as unpolished amateur work.

After passing version 9.16, Star Fox Exploration Showcase has been rebranded as

	STARFOX EX

It is recommended that you go through this manual before playing the mod!

	FIRST AND FOREMOST:

---- THERE ARE 2 MAPS!

-THE GAME STARTS ON MAP 2. TO SWITCH TO MAP 1, PRESS R ON THE MAP SCREEN.
-WHILE ON MAP 1, PRESS L TO GO BACK TO MAP 2.
-THIS CANNOT BE DONE ONCE A LEVEL HAS STARTED UNLESS YOU ARE IN PLANET SELECT MODE.
-IF USING BSNES, PLEASE ADD THE .BML FILE SUPPLIED IN THE SAME FOLDER AS THE ROM WITH THE SAME NAME.
-RECOMMENDED EMULATOR: SNES9X 1.60
-RECOMMENDED SETTINGS: CPU OVERCLOCK - MAX | SUPERFX OVERCLOCK - 400%

	ENJOY THE GAME!

Sections:
1) Pre-Game Menu
2) In-Game Commands
3) Pause Menu
4) Other Details
5) MISC Notes



1) PRE-GAME MENU 
	Here, I will attempt to explain each option.
	As a shortcut, you can press L or R to change pages as well as
	left and right while highlighting PAGE. 
	Press START on START GAME to start the game

a) Page 1

		CHEATS

	1) GOD MODE
		-Disables collision
		-Enables faster boosts with X+B, L+R+X and L+R+X+B
		-Enables GOD NUKE. Press R+A to spawn a bomb that kills all objects on screen
		-Lives are removed from the on-screen display
		-This is automatically disabled with NEWGAME+, unless...?
	2) RANDOM FIRE
		-You fire a random weapon for each shot
	3) ENEMY FIRE DISABLED
		-Enemies do not fire at the player (for the most part)

		GAME MODES

	1) PEPPER SKIP
		-Skips the planet zoom-in and pepper speeches (used to be for snes mini)
	2) SCORED
		-Enables the on-screen score counter and applies changes
		found in "scored edition changes.txt"
	3) HARD MODE
		-Disables all laser upgrades
		-Start with 2 bombs
		-Laser damage halved
		-No continues
		-Secret boss at end of courses 1/2/3/4
	4) ENDURANCE
		-Works for courses 1 and 4 only
		-Course 1 has the following levels back to back:
		1-1, 2-1, 3-1, 2-2, 2-3, 3-3, 2-4, 3-5, 1-4, 2-6, 3-7
		-Course 4 has all of the bosses back to back
	5) LEVEL FEATURES
		-Enables "level features" for MAP1 only - see notes at end
	6) 2 PLAYER MODE
		-Enables 2 player mode - works with scope mode
		-Death/views are handled differently in this mode
	*WHEN MULTITAP MODE IS ON, THIS CHANGES TO:
	6) NUMBER OF PLAYERS
		-Selects the number of players for multitap mode
		-Set to 1 player to control all 5 from player 1 controller
	7) TEAM ASSAULT MODE
		-Enables 2 player or 4 player CPU assistants
		-They will play the game with you, hunting down enemies
	8) MOUSE CONTROL
		-Enables mouse control (on port 2 only)
	9) SUPER SCOPE MODE
		-Enables Super Scope control (on port 2 only)
		-Controls second player in 2 player mode
		-Jumps to calibration screen before starting game
		(NOTE: MOUSE AND SCOPE CANNOT BE USED TOGETHER)
		*CALIBRATION SCREEN:
		-Press "C" button on scope when centered to calibrate
		-Press "Fire" to test
		-There is also a mini-version of the upcoming Starfox Paint
		-Use A/B to change color, L/R to change the size

	10) NTT DATA PAD SUPPORT
		-Enables NTT Data Pad controller input
		-Special inputs unique to this controller
		-See NTT DATA PAD section for mode details
	11) MULTITAP SUPPORT***
		-Enables SNES Multitap Support, enabling up to 5 players
		-Select the amount of players above at (6) after turning this on
		***Not recommended for hardware, can make PSU hot!***

b) Page 2

		MODS

	1) RAINBOW LASER
		-Makes each shot of the lasers a different color
	2) MODEL SIZE
		-Sets all model sizes to 1x, 2x or 4x size
	3) WIREFRAME MODE
		-Enables wireframe mode
		-Set to ON+ for mixed poly/wire mode
	4) SCRAMBLE SKIP
		-Skips the scramble scene in all courses
	5) DARK MODE
		-Light sources never hit anything
	6) OBJ PALETTE
		-Changes the entire game's object palette to your selection
	7) NO BACKGROUNDS
		-Completely removes all backgrounds, leaving it black
	8) NO DOTS/SNOW/STARS
		-Removes ground dots and/or snow+stars
	9) SHOW PLAYER COLBOX
		-Adds red boxes showing the players wing/body collision boxes
	10) -NAN MODE
		-Wonderful, mysterious things
		-See section: NAN MODE
	11) DISABLE BGMSFX
		-Disable all music, sound fx or both.
	12) BGM SPEED
		-Speed up or slow down all of the music tracks greatly
	13) 21.7 MHZ CPU
		-Enables the full SuperFX chip capability
		-The game was shipped with 10.4 MHZ originally
	14) FPS COUNTER
		-Enables an on-screen display on the current Frames Per Second
	15) BOUNCY DEATH MODE
		-A fun mode, leading the player to remain in complete control
		of the arwing after dying, never fully reaching death.
		-This is a joke mode, expect the game to break!
	16) NO ENGINE SOUNDS
		-Turns off or on the ship's constant in-air engine noise
	17) BACKGROUND
		-Changes the background for the pre-game menu
	18) MAX FPS***
		-Allows you to play the game in 30 or 60 fps mode
		-Objects are delayed and spaced out to try to account for this
		***DOES NOT WORK ON HARDWARE - ALL EMULATORS NEED CPU OVERCLOCK:
		SNES9x: MAX CPU OVERCLOCK
		BSNES: 126% OR MORE CPU OVERCLOCK
		MESEN-S: WAIT 60 SCANLINES AFTER NMI and MAX CPU OVERCLOCK

c) Page 3

	1) SHIP SELECT
		-Allows you to to change the players ship
		-All hit boxes are the same
		-Has a model view option as well
	2) MODEL TEST MODE
		-Full model test mode
		-Hold SELECT for instructions
	3) BGM TEST
		-Full Sound and Music test
		-Some Sound FX only play with certain tracks loaded (You can load a track, fade out, and then test SFX)
		-Pressing L+R enables "CURSED BGM MODE" where you can enjoy creepy cursed versions of every track
		-Pressing X+A loads SUB TRACK test (can crash game)
		-LEFT/RIGHT on Track Number/Sound FX Number to change
		-Start to play Track/SFX
	4) THANKS
		-A simple thank you to people who have supported this project
	5) NTT PAD TEST
		-A test to make sure all extra NTT Data Pad buttons work
	6) MULTITAP TEST
		-A screen to test buttons for all controllers for multitap mode
	7) RANDOMIZE OBJ PALETTE
		-Will randomize the color palette every time a level is loaded
	8) RANDOMIZE BG PALETE
		-Will randomize the background palette every time a level is loaded
	9) GRID LINES
		-Turns the grid dots into grid lines (thanks chuckborrisnorris)
	10) NO HUD
		-Enable or disable the in-game HUD (life, bombs etc)
	11) CLASSIC HP/WING DMG
		-Enables or disables classic HP/Wing damage
		-Classic:	HP = 40, Wings have 5 hits each
		-New:		HP = 100, no wing damage
	12) CLASSIC CAMERA
		-Enables or disables classic camera functionality
	13) RAPID FIRE
		-Continue firing as long as Y is held with this enabled
	14) BOOST/BRAKE METER
		-Enable this to use the classic boost/brake meter with all its limitations.
	15) MORE DOTS/SNOW/STARS
		-Takes advantage of the additional MARIO ram by adding more particles
	16) HOLD TO BARREL ROLL
		-Holding L or R when doing a barrel roll will continue to spin with this on
	17) HELPER BALLS
		-Turning this option off will disable the ability to use Helper Balls.
	18) CROSSHAIR MENU
		-Allows you to select the NEW, ORIGINAL or NO crosshair for 1st+3rd person.
		-Can select a different crosshair for each player in 2/3/4/5 player mode.
		-Some crosshairs are animated!

2) IN-GAME COMMANDS

	1) View Changes
		-Holding LEFT, RIGHT or UP and pressing SELECT changes to one of
		three different angled views
		-Holding DOWN and pressing SELECT switches to a realistic
		cockpit view where the world rotates around instead of the ship
		-First Person and Third Person are always selectable with SELECT
	2) Helper Ball
		-HOLD L and R and press B to spawn a Helper Ball
		-You can have up to 3 helper balls
		-Every Helper Ball spawn decreases your health by 15
		-Helper Balls defend and attack enemies before being spent up
	3) Super Boost/Hyper Boost/Warp Boost (GOD MODE ONLY)
		-Fly even faster by holding X and then holding B
		-Want to go to ludicris speeds?
		--HOLD L+R and then hold X to fly at a HYPER rate
		--HOLD L+R+X and B to fly at WARP SPEEDS
	4) God Nuke (GOD MODE ONLY)
		-Hold R and fire a bomb
		-It will destroy all enemies on-screen
	5) TESTING COMMANDS
		-Hold L+R and press SELECT to complete the level instantly
		-Hold L+A and press START to kill the player instantly
		--This also works with player 2
		-Activate GOD+ mode: ???
		-Activate GOD+ mode in-game: ???
		-HOLD L or R while starting TRAINING to start 1 of 2 message tests

3) PAUSE MENU

	1) WEAPON
		-Pressing left/right changes your current weapon
		-God gun 99 removes all objects it encounters
		-Weapons can be overpowered, so use with levity in mind
	2) DOUBLE
		-Enables/Disables dual shots for some of the custom weapons
	3) SHAPE
		-Changes your current ship model
	4) BGM
		-Highlighting this and selecting a track and then unpausing will change the current level track.
	5) NOBORDER
		-Removes all borders and movement limitations
	6) DEBUG
		-Set to 1 to have the top half of pause menu always display
		-Set to 2 to have entire pause menu always display
	7) X-HAIR
		-Turns crosshair on/off
	8) FRZ+EXP
		-Freeze and explore mode
		-Once turned on, hit BRAKE to stop the ship in its tracks
		-Move forward and backwards with X and B
		-Completely removes the rails, allowing you to move at your own pace
	9) STEP BY STEP
		-While highlighted, you can press left/right to advance a single/
		multiple frames, to move the game in a step by step fashion
		-While holding left and right, up and down and fire will work
	10) FIRERATE
		-How long of a delay each laser shot has before the nextshot
		-Default is 2
		-1 can hardlock in rare situations

	USELECTABLE ITEMS:
		HEALTH
		-The player's health
		GOD
		-Indicates god mode on/off
		SPEED
		-Current ship speed
		ROTX/Y/Z
		-Current ship rotation
		WORLDX/Y
		-Current ship position in the world
		NGPLUS
		-Indicates if Hard mode is on or off
		CURSPEC/TOTSPEC
		-Indicates the total "special" enemies spawned and total
		"special" enemies killed. These are the enemies coded
		to affect the stage score % at the end.
		FRAME
		-Current game frame in the level (resets every level)


4) OTHER DETAILS

	-NAN MODE:
		1: Sets all polys to use the white -NAN texture
		2: Sets all polys to use the animated lava texture
		3: Sets all polys to use the animated blue lava texture
		4: Sets all polys to use the electric animated texture
		5: Sets all polys to use the Trevor the Cat texture
		6: Enables "Wobble mode 1"
		7: Enables "Wobble mode 2"
		8: Enables "Wavy Mode"
		9: Enables "Cel Shading" mode

	-NTT DATA PAD CONTROLS
		0 	- Fire Missile 
		Hang up - Kill Self
		* 	- Kill all enemies
		.	- Super Homing Laser
		#	- God Gun
		C	- Orb Shot
		1/3 	- all range turning
		5 	- center camera 
		4/6 	- rotate camera left/right
		2/8 	- rotate camera up and down
		7/9 	- zoom in/out

	-LEVEL FEATURES
		-Only works on map 1
		1-1 - Play the level completely with Andross's boss fight background
		2-1 - New palette for Corneria
		3-1 - Another new palette for Corneria
		1-2 - Spawns a group of smiling asteroids that leave black hole warps
		2-2 - Displays a very short *special* credits before continuing the 		level
		3-2 - Spawns a group of asteroids that all spawn the Out of this 		Dimension warp bird when destroyed
		1-3 - Short additional fight with a mix of ships and a new background 		at the start of the level.
		2-3 - Fight dodora bird at start of level, new background after 		weather change, extra fun enemies added
		3-3 - Fight a funny Macbeth/Andross boss, new background swap for 		water section
		1-4 - Walkers. Lots of them. Who doesn't like walkers?
		2-4 - Enjoy another level using the final boss fight's background!
		3-4 - Play inside the nucleus for the whole level. And then enter a 		nucleus within a nucleus.
		1-5 - Is it the black hole? Nope, just 1-5.
		2-5 - There is a temporal distortion messing with the background!
		3-5 - Play Macbeth with a flowing watery type background.
		1-6 - Complete the "THE END" puzzle to continue.
		2-6 - Nothing
		3-6 - It's like that scene from Out of this Dimension but without the 			slot machine.
		3-7 - Replay the training level on Venom.

	-TITLE SCREEN KEY COMBINATIONS
		-HOLD L - PRESS SELECT - start game in model test mode
		-SUPER HIGH POLY MODE: ???
		-HOLD Y - PRESS A, B or X - Change title screen models
		-HOLD R - PRESS SELECT - cycle through mosaic mode options (tile size, layer)

5) MISC NOTES

	-The original levels are ~95% faithful to the original. Some enemies may have had to be removed to prevent crashes.

	-On MAP 1, Course 4 is a BOSS ONLY course

	-Health has been increased to 100hp, no wing destruction (can be turned off)

	-In 1 player mode, player 2 controller controls the camera
	(L2+R2+RIGHT2 resets the view)
	--UP2/DOWN2 adjusts X position of camera
	--RIGHT2/LEF2 adjusts Y position of camera
	--A2/B2 rotates the caemera on the Z plane
	--X2/Y2 zooms in and out
	--L2/R2 turns the player ship in any direction for all range mode

	-Great Commander's 6 panels have increased in size

	-Prof Hangar's hp has been adjusted to accomodate rapid fire

	-Out of this Dimension now leads to black hole after completion

	-Game can be restart after credits

	-Australia never ends, just like real life

	-Teammates have their own colors and also actually help the player

	-To access the secret menu, during the intro press X+A (you'll hear a jingle)
	-Then go to page 3 of pregame menu, highlight THANKS and press Y+A
	-(Most things here are best used with god mode)

	-To access the secret level, on level 6-3 destroy 7 green asteroids throughout the level
	-This will spawn a yellow asteroid. Destroy this and fly into the fire.

	-On MAP 1:
	-Hold R and press X for an ending sequence test (space part) 
	-Hold R and press Y for boss bgm test (ancient test I made)
	-Planet cheat: Hidden courses go directly to Black Hole, OOTD, or a BOSS ROLL test for map 1.
	
	-On MAP 2:
	-Planet Cheat: Hidden courses go directly to Comet or a BOSS ROLL test for map 2.

	-To activate god mode+: ???

	-kando mode controls:
		-Flip screen Upside Down: ???
		-Flip screen Left: ???
		-Flip screen Right: ???
		-Duplicate player: ???
		-Duplicate all enemies: ???

	-Cray mode: 1: ???
		    2: ???
		    3: ???
		    4: ???
		    5: ???
		    6: ???

	-Other undocumented features and secrets exist!

Specific credits:

Luigi head model, Original Camera Controls/ISO Views, PAL Test: Starxxon
Texture Expansion SuperFX Code: MrL314
SuperFX Background Effect Mods, Wireframe mode/Wobble Modes, Grid Lines: chuckborrisnorris
All New Level Backgrounds/Palette Work: SegaRetro92 (SegaMegaDrive)
Galaxip/Gyaraga/Air Raider Models, Enemy Fighters, Structures: Random Stuff
Star Fox 64/Command Model Conversions, Modeling Assistance: Euclidium
Credits Text/General Documentation, Ship Models: CoolK
Models from EX-Zodiac: Ben Hickling
New Avatars: SunlitSpace542, phonymike (tool maker)
New Map Background: Hayao, Random Stuff
NTT PAD Help: Catador, phonymike, Raphnet Labs
Mouse/Scope Help: Catador, phonymike
Metroid Sprites: Fenix
Title Screen Logo: SegaRetro92, Hayao
Music Tools: MrL314, phonymike, ebmused developers
Music: Livvy94, phonymike, Random Stuff, Plasmariel, EG_9371
All programming, integrations: kandowontu

Many, many testers including, but not limited to:
Chromius
kaine23
Kert Gartner
DoctorWhosThat
Chris Highwind
phonymike
Random Stuff
Sfan
Solgnar
SunlitSpace542
The Angry Scotsman
Mike Bachmann
BlazingRaven495
Brozilla
Darkhorse
djedditt

Special thanks to the original developers

And many, many others.

Twitter: @kandowontu
E-Mail: kandowontu@me.com
Discord: discord.gg/U4CtzqDGa5