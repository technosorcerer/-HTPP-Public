-- Star Fox 64-Style HUD mod v4.0 by Sunlit --
Changes HUD to be closer to SF64’s layout, adds Star Fox 2 character mugshots (optional), upgrades the 2D sprite crosshair into a 3D one, enables the first person crosshair in third person view (optional), adds rumble support from Star Fox Shindou Edition, and upgrades the game to use 21Mhz Super FX. (optional)

Patches apply to a Star Fox USA Rev 0 ROM file (No-Intro database name is "Star Fox (USA).sfc").
The one to use is dependent on your preference.

4.1 (7/18/2025) Changes:
	Fixed rumble bug where if you pressed start at just the right time in the intro, the Attack Carrier's rumble sequence will continue instead of being stopped

4.0 (7/18/2025) Changes:
	Rebased on the latest UltraStarFox
	Rumble support from Star Fox Shindou Edition added
	Teammate being chased message healthbar moved back to its original position (I now think the way it used to be looks ugly, there's really no way to do it that'd look good imo), it has also been reduced to half its original height
	New SFEX/SFCD-style 3D crosshair that looks like SF64's (added by request)
	FastROM support dropped (It's technically not supposed to work anyway, and it's only like a 1% improvement)

3.0 (12/28/2023) Changes:
	Boss health meter completely revamped - Much more like SF64's
	Other unnoteworthy under-the-hood changes

2.3.3 Changes:
	Fix issues regarding FastROM/SlowROM

2.3.2 Changes:

	ROMs with various configurations added:
	SlowROM/FastROM+10mhz/21mhz, reticle/no reticle, and sf1/sf2 mugshots
