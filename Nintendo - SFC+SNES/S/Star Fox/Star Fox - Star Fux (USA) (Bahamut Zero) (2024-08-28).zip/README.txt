Apply patch to unheadered Star Fox (USA).smc rom


Hashes
CRC32: 0BAE0941
MD5: 9DCE6A9DCBE4E304D67B9E8FD8999E7E

