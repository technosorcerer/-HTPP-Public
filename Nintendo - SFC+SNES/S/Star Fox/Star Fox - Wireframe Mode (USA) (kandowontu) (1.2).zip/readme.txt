Apply patch to headered Starfox v1.2 rom. Rom will be 2MB and will only work on a GSU-2 cartridge.

v1.2 Changelog - Sprites now show properly (asteroids, etc.)

Original patch and coding by kandowontu

Discord: https://discord.gg/TYuD3TkEhB

Twitter: @kandowontu