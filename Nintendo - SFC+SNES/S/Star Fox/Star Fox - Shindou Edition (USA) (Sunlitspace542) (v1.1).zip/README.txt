SNES rumble is here!
Introducing Star Fox - Shindou Edition, the Super NES classic, now with revolutionary force feedback controls never before seen on the SNES, using the SNES rumble specification created by the amazing Randal Linden for "The Ultimate" Doom (2025)!

Many rumble effects have been added to make the game more immersive and take advantage of the new hardware.

Tested and working on real SNES hardware with an FXPak Pro flashcart and a rumble controller prototype, and with the Mesen emulator.

Multiple patches are included for each region’s releases of the original game. Box art for the NTSC-U and NTSC-J versions are also provided.
The raw files for the SNES rumble pad icons (English/Japanese) are also provided. These are free to use for the cover art of your own rumble patches.

Currently, only the Mesen 2 emulator supports rumble.
To enable, go to Settings -> SNES -> Input -> Port 1 and select 'SNES Rumble'.

It also appears that BlueRetro adapters may now support rumble: https://github.com/darthcloud/BlueRetro/discussions/1274

This patch was designed around and tested primarily with the actual rumble controller, and thus the rumble may feel a bit weak on Mesen.
It is recommended that you set the force feedback slider under Settings -> Input to the maximum, as this gets you as close as possible to the strength of the actual SNES rumble controller.
However, every controller is different. You may need to change this setting to your preference, or you may not need to change it at all.

Thanks to Randy Linden for his help in testing the game on real hardware before my controller arrived, and ensuring that rumble works on real hardware. It has been an honor to get the opportunity to work with you on this project.
Thanks to Kandowontu for programming the sequenced rumble system, which has been used for certain effects, and for performing the final few testing and polishing passes.

Changes:
1.1 - Fixed rumble bug where if you pressed start at just the right time in the intro, the Attack Carrier's rumble sequence will continue instead of being stopped
