Thank you for downloading the VLDC6 Compilation Hack!

---------------
- Autosave (midways save too)
- Play levels in any order you prefer
- Start+Select to exit levels at any time
---------------

Here you will find a collection of 84 levels from 2013, 4 switch palaces, and a full overworld map made just for the compilation by codfish1002 (the main map) and MORC (all submaps). Work on the project commenced in 2021, with bursts of interest every few months slowly leading to the project's completion in 2024. VLDC6 was somewhat simpler compared to the other VLDCs and had a more restrictive set of rules; that simplicity is reflected in this compilation. Very little custom music was used and ASM was kept to a minimum. The more restrictive nature of VLDC6 consequently led to a number of disqualified entries, which are included in this compilation and marked with a (DQ). The only reward for completion (outside of simply filling in the overworld indicators) is a special 114-exit icon on the file select screen.

If you are playing in 2-Player mode, please note that you can not exchange lives and that Luigi's palette may look off in some levels. Exchange of lives was removed as it interfered with the names on the overworld border. Some levels that altered Mario's palette did not change Luigi's.

If you would like to look into the history of this contest, refer to the following threads.

VLDC6 Rules and Submissions Thread - https://www.smwcentral.net/?p=viewthread&t=62149
Contains the rules for VLDC6 as well as most of the entries submitted to the contest.

VLDC6 Discussion Thread - https://www.smwcentral.net/?p=viewthread&t=62150
A lengthy thread containing multiple discussions on the ruleset of the contest as well as assorted other matters.

VLDC6 Results Show Thread - https://www.smwcentral.net/?p=viewthread&t=63260
Contains the results for VLDC6 in addition to the comments and scores from the judges.

VLDC6 Compilation WIP Thread - https://www.smwcentral.net/?p=viewthread&t=120590
A thread following much of the development of this compilation if you happen to be interested. Most of the initial level insertion process was complete before the thread was created.

Have fun!
- Minish Yoshi