Credits:
Testing:
  xHF01x, dacin

Tools:
  LunarMagic 3.30 - FuSoYa
    https://www.smwcentral.net/?p=section&a=details&id=26916&r=0

  GPS 1.4.2 - p4plus2, me - (no the version is not a mistake, technically I used an unreleased debug build which I had lying around because apparently that's what I had in my base rom, 1.4.21 has the same ASM though so I'll link that)
    https://www.smwcentral.net/?p=section&a=details&id=25810&r=0

Blocks:
  Hurt / Death Block for Kaizo / Pit Hacks - dacin
    https://www.smwcentral.net/?p=section&a=details&id=27268&r=0

Check the ASM/ directory for all the code used in the hack that isn't tool code. Read the readme file inside the ASM/ directory if you want to avoid spoilers.

Notes on room settings:
  All rooms except for the first room (105) use item memory index 0. Map16 and objects are a bit mixed in the level but generally the filter pathways in the final section are the only ones intentionally affected by item memory.
  Room 2 (106) has the "Make sprites beyond level boundaries interact with air instead of water" flag set
  Most rooms use different sprite memory settings from each other

Notes on unintended glitches:
  Unfortunately there are a couple of glitches that could not reasonably fix.
  I decided against patching out everything because it's not always reasonable to do and may affect parts of the level in unintended ways, turning the puzzles more into figuring out how the asm works rather than how the game works.
  And since I did want to release the hack eventually, there is a list of generally unapproved glitches here:

  - duplicating shells by offscreening them while they are on yoshi's tongue (or any other sprite)
  - fish item-swaps (using the above for an item swap)
  - recovering carriable items by storing them on invisible yoshi tongue
  - duplicating springboards below the level
  - walljumps/wallclips
  - spawn index transferal (patched out)

Special Thanks to xHF01x and dacin for testing this and always giving me more breaks to fix :)
