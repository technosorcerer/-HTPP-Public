This folder contains all the ASM that was used on the hack not including what was applied by LM or GPS' main code

The blocks/ folder contains all custom blocks which were applied using GPS 1.4.2, there is nothing particularly sensitive in there.

The patches/ folder contains all patches applied to the ROM. The files immediately in there are hex edits for gfx, counter break and the like.
Inside patches/_SPOILER/ are a few ASM files that handle a couple of things you're expected to run into while playing the level. I recommend you do not look at this folder until after the level or if you must know how one of the changes works.

UberASM, music or sprite tools have not been used on the ROM.
