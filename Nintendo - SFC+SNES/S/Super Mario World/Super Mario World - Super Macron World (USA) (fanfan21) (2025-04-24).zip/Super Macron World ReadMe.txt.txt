`  `  `  `  `  `  `  `  `  `  `  `  `  `  `  `  `  `  `  `  `  `  ` DISCLAIMER `  `  `  `  `  `  `  `  `  `  `  `  `  `  `  `  `  `  `  `  `  `
THIS ROM HACK IS NOT A HATE HACK, NOR DOES IT INTEND ON TARGETING ANY INDIVIDUAL AND ANY GROUPS. THIS HACK IS ONLY CREATED FOR ENTERTAINMENT PURPOSES.
REPEAT, THE HACK DOES NOT ATTACK ANY GROUPS AND INDIVIDUALS.

                                                      ~ ~ ~ ~ ~ SUPER MACRON WORLD ~ ~ ~ ~ ~
Created by fanfan21 (also known as NonAlcoholicBunnyBeer, N.A.B.B.)

Super Macron World is a hack of Super Mario World that is a tribute like a lot of other Kaizo Hacks.

My tribute goes to The Macron Show, a Prank Call Podcast that has given entertainment since March of 2015. The Podcast lately been focusing on Twitter (now known as X,
but I'm still calling it Twitter, despite what others say) Complainers. The only plot, because the hack can only be beaten using tools, people are complaining
the game is too difficult, but in reality, it's super easy!

   ----------------------------------------------------------------------------------------------------------------------------------------------------------------------

Super Macron World's Development has started around the middle of March, 2024.

This is the first ever hack I started to create, but put it to the side for a while.

+ + + MUSIC CREDITS + + +

Nintendo Presents: Trials of Mana - Pihyara Flute (Unsampled by h.carrell)
Link: https://www.smwcentral.net/?p=section&a=details&id=35521

Title Screen: Sounds for the Supermarket Vol. 1 (Karl Jenkins - Mr. Lucky) (Ported by sincx)
Link: https://www.smwcentral.net/?p=section&a=details&id=23733

Intro Screen: ~omh~ - THE BRICK ~ Opus No. 1 (Ported by Daizo Dee Von)
Link: https://www.smwcentral.net/?p=section&a=details&id=37414

Overworld: Verizon - Default Tone (Unsampled by bebn legg)
Link: https://www.smwcentral.net/?p=section&a=details&id=27538

Impaitent: Top Gear - Las Vegas (Unsampled by Unknown User)
Link: https://www.smwcentral.net/?p=section&a=details&id=8484

The No-Fly List: Settle the Score (Ported by Ruberjig)
Link: https://www.smwcentral.net/?p=section&a=details&id=13422

Jeff's Jeer: New Ghostbusters II - Court (Ported by Pinci)
Link: https://www.smwcentral.net/?p=section&a=details&id=18423


UNDERSTAFFED: Rudra no Hihou - Evil Eyes by scratch
Link: https://www.smwcentral.net/?p=section&a=details&id=38242

UNDERSTAFFED (Peace area): Ys IV: Mask of the Sun - Promarock by Nanako
Link: https://www.smwcentral.net/?p=section&a=details&id=13397

Complaints Resolved (& Yoshi's are here): Undertale - Absolutely Overfamiliar Shrine by TickTockClock
Link: https://www.smwcentral.net/?p=section&a=details&id=38012


* * * * OTHER CREDITS * * * *
Lunar Magic (Version 3.40) by FuSoYa
AddMusick (Version 1.10) by Kipernal


(No other Patches or ASM additions has been added)

Special Thanks for Inspiration as well for other Hacks/Creators:
- Abuse and Die Trilogy by AbuseFreakHacker & his other works
- Mario Must Die Trilogy by Sokobansolver
- SMW Skill Challenge 1 & 2 by Magikey
- ..and so much more other Tool-Assisted Kaizo hacks out there and the Kaizo Community itself.