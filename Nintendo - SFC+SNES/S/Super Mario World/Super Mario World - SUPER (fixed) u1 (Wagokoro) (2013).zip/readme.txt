				=================
				  SUPER - Fixed
				=================

				  Fix Update 1

			      ====================
			       Changelog of fixes
                              ====================

Fix Update 1 (19/04/2019)
	-Fixed a mess-up in our multiplication fixes which (possibly among other
	 things) caused bullets in one level to fire out of their cannons in
	 the wrong direction. (Thanks to Wagokoro for pointing this out)

	-Fixed a mistranslation in one level name that was made due to not realizing
	 that it was a reference to another piece of popular media.
	 (Thanks to someone in bolop's Twitch chat for mentioning this)

First Version (19/01/2019)
	-Initial release

				 ==============
				 About the hack
				 ==============

SUPER is an SMW hack released around 2013, made by Wagokoro.
It's somewhat short, with 29 exits, and has a high level of difficulty.
It was originally released in Japanese.

The hack does not use custom music, and thus did not have any sound-related issues.
However, there are a couple of programming related bugs that only pop up on BSNES
and real SNES hardware. You can find a short list of what was fixed later in this
document.

				==================
				About this release
				==================

For this release, we've done a full translation of the hack into English.
We've also fixed a small number of compatibility issues, so that this
hack can be played on a real console (hopefully) without major bugs.

Patches for both the Japanese version and English version are included.
Both have had their compatibility problems fixed.

There are also two optional ASM patches. See below for how to apply them.

			      =====================
			      About the ASM patches
			      =====================

Once the BPS patch of your choice has been applied, the resulting ROM should be ready
to play on most hardware and software capable of running SNES games without further
modification.

However, there are some more options in the form of ASM patches that you might be interested in.
In this hack's case, we've included patches for the following:

	- Translator note to explain a total of one cultural reference (English version only).
	- Hint patch which adds a certain hint that we have reason to think was left out
	  of the original hack by accident. (exact details in the patch's ASM file.)

We have tried making the process of applying these patches as simple as possible, so
even if you've never done anything with ASM before it shouldn't take longer than a
few minutes to find out what they all do and to actually apply the ones you want.

The process uses a program called "Asar" by Alcaro (and others), which is not our work, but a
cut-down copy of which (only including the .exe and license information) is supplied inside
this zip file for the sake of ease of use.
The full program can normally be found at these addresses:
https://www.smwcentral.net/?p=section&a=details&id=14560
https://github.com/RPGHacker/asar

Below is a step-by-step guide to learning what all the ASM patches do, and how to apply them.

1. Prepare the ROM by applying either of the BPS files to a clean, headered USA version ROM of
	Super Mario World, and placing it into the 'asar161' folder.

2. Go to the 'asar161' folder, and open '@main.asm' in a text editor of your choice (Notepad will work).

(You can skip step 3 and step 4 if you want all of the patches.)

	3. Read the explanations about each patch inside this file to decide which patches you
		want applied to the ROM, and follow the instructions.

	4. Make sure '@main.asm' has been saved with any edits you made.
		(Take care in step 6 if you rename this file.)

5. Run 'asar.exe'.

6. When asked for the patch name, enter "@main" (without quotes) or whatever
	else you have renamed it to.

7. When asked for the ROM name, enter the file name of the ROM that you put in the same folder
	in step 1, with or without file extension.

And now if nothing has gone wrong (it shouldn't), you will get a list of the patches that have
been applied, and a message saying that the patch has been applied successfully.
The ROM is now ready to be played.

			  ======================================
			  Compatibility problems that were fixed
			  ======================================

	- Custom code that makes incorrect use of SNES multiplication and division registers.
	- A custom dual spinning platform sprite that reads from uninitialized memory to set
	  the initial position of one of its platforms, leading to a 50/50 chance that both
	  platforms start in the same place when played on BSNES or a real console.

				    ==============
				    About our work
				    ==============

We're a small team that fixes old hacks that suffer compatibility issues due to
using tools and code that were designed with ZSNES and SNESGT's inaccurate
emulation in mind. We take a low-level approach, opting to fix the specific
issues using precision ASM patches rather than replacing their assets entirely,
in the hope that the result will be as accurate as possible to how the hack
would've played on ZSNES.

Keep in mind that we are NOT concerned with making these old
hacks 'more playable' by changing gameplay aspects, or fixing other bugs
that would've been present originally. However, if a hack has severe problems
that could easily lead to crashes or softlocks, or if there are features that we
personally thought would be neat to see, then we will include ASM patches that you
can apply to the ROM as an option. Check the instructions above for how to apply them.

One last note is that none of these hacks were made by us. We take no credit for
the original design, only for the fixes and translations applied to them.
We hope this will allow these hacks to be preserved, and played by more people.

					=======
					Credits
					=======

This is a list of all the people whose software/patches/work we've used or adapted on this hack:

Asar 					- Alcaro et al
Recover Lunar Magic 			- Parasyte
Modern Recover Lunar Magic		- This Eye o' Mine
Extended Overworld Level Names		- Smallhacker
Translator Notes patch 			- Super Maks 64
Message Box Chaining patch 		- Super Maks 64
"Vanilla cutscene" font 		- Lemonade

Translation, fixes, and additional ASM by This Eye o' Mine.
Thanks to lion for originally making a textfile translation that we used as a reference.
Proofreading and testing by Ryrir.

And of course thanks to Wagokoro, who made the hack in the first place.

Sorry to any people we might've missed.

- The Hack Fix/Translation team