
The purpose of making "Evil Doopu World" was to learn how to use Lunar Magic and pay tribute to an upcoming streaming legend WhoIsDoopu (yellow dog in a teacup) and his community in only 6 days (30h).

This time I challenged myself to spend 60 days (120h) learning ASM and developing workflow for using Lunar Magic in more efficient way. I also paid tribute to the current streaming legend WhoIsDoopu (yellow dog in a teacup) and his community.

Therefore Evil Doopu World 2 was made primarily for me to have fun creating stuff and not always with player in mind.

Nevertheless I think it turned out ok. It has some unique setups and expert players should have a lot of fun with it.

Even though it only has 6 levels it also bolsters 35 playable sections. Difficulties varie from very high intermediate to expert. There is quite a bit of chocolate in the hack, but except very few places it maintains a vanilla feel. 

If you don't mind spoilers and want to have better feel for the actual length of the hack you can check out "readme/levels-structure.html".

Levels are based on WhoIsDoopu's community humor like: reoccurring number 6, missing midways, hating grab jumps and the word "Doopster". Although lack of knowledge of these topics shouldn't take much away from the gaming experience.

There are 3 sections that can be skipped as I know they won't be too everyone's liking.

There are trolls. But if you don't like getting trolled there is a "readme/troll-guide.html" included that lists all of the trolls.

Good luck and have fun!

!SPOILERS AHEAD! !SPOILERS AHEAD! !SPOILERS AHEAD! !SPOILERS AHEAD! !SPOILERS AHEAD! !SPOILERS AHEAD!








































 .d8888b.  8888888b.   .d88888b.  8888888 888      8888888888 8888888b. 
d88P  Y88b 888   Y88b d88P" "Y88b   888   888      888        888   Y88b
Y88b.      888    888 888     888   888   888      888        888    888
 "Y888b.   888   d88P 888     888   888   888      8888888    888   d88P
    "Y88b. 8888888P"  888     888   888   888      888        8888888P" 
      "888 888        888     888   888   888      888        888 T88b  
Y88b  d88P 888        Y88b. .d88P   888   888      888        888  T88b 
 "Y8888P"  888         "Y88888P"  8888888 88888888 8888888888 888   T88b


# Puzzle

Below you'll find a solution to the puzzle. You can also skip the puzzle completely if in the room before the puzzle you'll type "PUB" 6 times.

## Solution

1. Get the Moon over the entry pipe.
2. Go through the left pipe. Get p-switch without getting any moons.
3. Go through the right pipe. Use the most right ON switch (use p-switch to get there).
4. Use P-Switch. Use OFF switch to get mushroom without getting any moons.
5. Get 2 moons on the right side using ice physics.
6. Go throught the left pipe. Get p-switch and the top-left moon.
7. Go throught the bottom pipe. Use the most right ON switch.
8. Go through the left pipe. Get 2nd p-switch. Use OFF switch to get mushroom and get 2 moons above OFF switch.
9. Go through the bottom pipe. Use most left ON switch then use p-switch to use OFF switch to get 2nd mushroom.
10. Get all the moons in the middle using 2 mushrooms.
11. Go throught the left pipe. Get p-switch. 
12. Go through the bottom pipe. Use the most right ON switch.
13. Go through the left pipe. Get 2nd p-switch.
14. Open 6-moon gate and get 2 coins.
15. Use p-switch and get another coin behind gate and the coin below OFF switch.
16. Get second to last coin using item swim physics.
17. Win?








































 .d8888b.  8888888b.   .d88888b.  8888888 888      8888888888 8888888b. 
d88P  Y88b 888   Y88b d88P" "Y88b   888   888      888        888   Y88b
Y88b.      888    888 888     888   888   888      888        888    888
 "Y888b.   888   d88P 888     888   888   888      8888888    888   d88P
    "Y88b. 8888888P"  888     888   888   888      888        8888888P" 
      "888 888        888     888   888   888      888        888 T88b  
Y88b  d88P 888        Y88b. .d88P   888   888      888        888  T88b 
 "Y8888P"  888         "Y88888P"  8888888 88888888 8888888888 888   T88b


# Boss Fight

## Information about phases (you can find skip instructions below)

There are 8 different phases. 3 that give you projectiles and 5 fillers. Order of the ones that give you projectiles is determined in the very beginning and remains the same for the duration of the whole fight. The order of the fillers is determined every time when all 5 fillers have been used. The sequence is filler, filler, filler, projectile and then it repeats.

## How to skip

You can skip the boss fight completely if you'll type "PUB" 6 times in the room before the fight.