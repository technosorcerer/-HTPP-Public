~Readme~

After almost a year of laziness and slow testing (yeah, it wasn't supposed to take that long), I present you my new Kaizo hack: Eh!
This is my new serious kaizo project, started after more experimental "Trapped in The Goomba Land" made for YouTuber (hello if you're reading this :P)
I made it with "being easy for beginners" in mind, though some sections may be a bit difficult.
No worries, I've included multiple checkpoints in each level, so it won't be that frustrating. Hopefully. Especially since it's updated version.

So, what does this hack have?
-Multiple checkpoints as I mentioned already
-SA-1 for no lags and some obstacles
-Some fancy ASM for unique level design, and overall expirience.
-Custom Music and vanilla-ish aesthetics (mostly vanilla, but contains a few non-vanilla assets)
-6 main levels and extra levels are coming soonTM!
-Non-existant plot because who needs that

I hope you'll enjoy playing Eh, and thanks for support!

Note:
This hack is mostly free of glitch usage - only a couple of places require you to know specific glitches. They shouldn't be hard to figure out though.

WARNING:
While checkpoints save after you exit them (select+start) in game, they don't save with SRAM (or BW-RAM in this case).
I can't expand save files due to conflicting patches. And even if I remove them, they still don't save correctly. Sorry for any inconveniences.

~Changelog~
V.1.0
Initial Release

V.1.1
After watching Linkdead's twitch stream (RIP) I  tweaked some level design, so now the hack should be a bit easier to go through.
I hope it doesn't suck now.

~Credits~

Blocks:
GreenHammerBro
worldpeace
MarioE
Alcaro
Iceguy
Smallhacker

Sprites:
Mikeyk
JackTheSpades
MarioFanGamer
imamelia
smkdan
Erik
Iceguy
Alcaro
Mandew

Music:
MercuryPenny
Wakana
tcdw
Lui37
NastCF
Ultima
HarvettFox96
K M S
Izuna
DAA234
Masterlink
LadiesMan217
trumpet24601

Graphics:
Pixel-Gon
Berk
Link13

Patches:
Worldpeace
Lui37
Vitor Vilela
Arujus
Davros
lolcats439
Alcaro
LX5
wiiqwertyuiop
Noobish Noobsicle
ghettoyouth
DiscoTheBat
Erik
p4plus2

UberASM:
Blind Devil

Special thanks go to Squiggs for playing my kaizo hack made for him (Trapped in Goomba land), and giving motivation to work on this,

And everyone who else who supported me, left nice comments or feedback:
Super Stiviboy
chinesesmw
Pixel-Gon
Taffy
ft029
KaizoDaemon
Katerpie
Darkbloom
JustinTAS
PaperWario
randomdude999

Big thank you goes to SwagAssMustafa, the only guy who cared to test my hack and gave some feedback.