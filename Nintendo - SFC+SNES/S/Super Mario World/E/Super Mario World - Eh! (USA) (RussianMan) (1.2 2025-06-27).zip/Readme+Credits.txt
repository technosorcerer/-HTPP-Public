~Readme~

After almost a year of laziness and slow testing (yeah, it wasn't supposed to take that long), I present you my new Kaizo hack: Eh!
This is my new serious kaizo project, started after more experimental "Trapped in The Goomba Land" made for YouTuber (hello if you're reading this :P)
I made it with "being easy for beginners" in mind, though some sections may be a bit difficult.
No worries, I've included multiple checkpoints in each level, so it won't be that frustrating. Hopefully. Especially since it's an updated version.

That portion was written ages ago. In retrospect, this hack is ball-bustingly difficult, and not very suitable for beginners.
Even though the hack is challenging, the multiple chekpoints do ease the pain a bit, plus the new accessibility features can help.
The autosave is also perfect for breaks, the hack saves each time you get a new checkpoint or go to the overworld. Take breaks, stay hydrated, etc.

So, what does this hack have?
-Multiple checkpoints as I mentioned already
-Autosaving (also mentioned already)
-SA-1 for no lags and some obstacles
-Accessibility features in the form of FPS Toggle (switch between 60 and 30) and Freeze Frame
-Some fancy ASM for unique level design, and overall experience.
-Custom Music and vanilla-ish aesthetics (mostly vanilla, but contains a few non-vanilla assets)
-6 main levels and 2 extra levels (NO MORE THAN THAT, HAHAHAH)
-Non-existent plot because who needs that, amiright gamers

I hope you'll enjoy playing Eh, and thanks for support!

Note:
This hack is mostly free of glitch usage - only a couple of places require you to know specific glitches. They shouldn't be hard to figure out though.

~Changelog~
V.1.0
Initial Release

V.1.1
After watching Linkdead's twitch stream (RIP) I  tweaked some level design, so now the hack should be a bit easier to go through.
I hope it doesn't suck now.

V.1.2 (about 6 years later......)
-Ported to a new ROM, upgrading various tools and patches (should fix music resetting every time the player dies, which... idk where that came from, but then again, the hack is pretty ancient at this point)
-Added 2 extra levels, and thus making this the final version of the game (unless a major bug is found or the hack breaks again in terms of working on accurate emulators).
-Remade level 3 boss from scratch.
-Checkpoints now save to SRAM (you can quit out of the level or stop playing, and they will be remembered).
-The L/R scrolling has been completely disabled for all stages (this also fixes the castle level which had L/R scrolling enabled by accident).
--The sections that required L/R scrolling were redesigned to compensate (specifically, first section of "Eh... Sky Park." and "Eh... Spaceship.").
-Text adjustements
-New accessibility features: FPS Toggle and Freeze Frame, which are mapped to L and R, respectively.
-"Eh... Laboratory" has been reworked - now it's a hub, the tutorial portion was redesigned, and a new settings screen has been added. The level name has been changed.
-Made snake fireballs from the first level interact with the player every frame, making sections with them more consistent. To compensate, their spawn timer has been increased by 1 frame (this makes sections with them a tiny bit easier).
-Other minor level design edits, either to make them play nicer or to add clarity:
--Minor tweak to the 3rd section of "Eh... Beginning"
--Minor tweak to the 4th section of "Eh... Sky Park."
--Added a coin trail to the second section of "Eh... Spaceship."
--Minor tweak to the 5th section of "Eh... Spaceship."
--Redesigned the end of the 4th section of "Eh... Pitfall."
--Minor tweak to the 2nd section of "Eh... Beach."
--Minor tweak to the 4th section of "Eh... Beach."
--Added coin trails to the 5th section of "Eh... Beach."
--Minor tweak to the 6th section of "Eh... Beach."
--Added coin trail to the 2nd section of "Eh... Castle."
--Minor tweak to the 7th section of "Eh... Castle."
--Minor tweak to the 9th section of "Eh... Castle."

~Credits~

Blocks:
HammerBrother
worldpeace
MarioE
Alcaro
Iceguy
Smallhacker
MarioFanGamer

Sprites:
Mikeyk
JackTheSpades
MarioFanGamer
imamelia
smkdan
Erik
Iceguy
Alcaro
MellyMellouange
yoshicookiezeus

Patches:
Lui37
Vitor Vilela
Arujus
Davros
lolcats439
Alcaro
LX5
wiiqwertyuiop
Noobish Noobsicle
ghettoyouth
DiscoTheBat
Erik
p4plus2
wye

UberASM:
Kevin
westslasher2
Alcaro
Erik
Fernap

Music:
Wakana
Nanako
Lui37
NastCF
Ultima
HarvettFox96
K M S
DAA234
Masterlink
LadiesMan217
trumpet24601
Giftshaven
sincx
Xulon

Graphics:
Andyana Jonseph
P-Tux7
Berk
Link13
Blizzard Buffalo

Special thanks go to Squiggs for playing my kaizo hack made for him (Trapped in Goomba land), and giving motivation to work on this,

And everyone who else who supported me, left nice comments or feedback:
Stivi
chinesesmw
Andyana Jonseph
Taffy
ft029
KaizoDaemon
Katerpie
Darkbloom
JustinTAS
PaperWario
randomdude999
cardboardcell

Big thank you goes to Anas, who tested my hack and gave some feedback.

And streamers:
Linkdeadx2
juzcook (there you go, i "finished" the hack!)
Lungfish3000
drkdnk
(sorry if i missed you, dear streamer whom i didn't put on this list!! you'll always be in my heart somewhere)