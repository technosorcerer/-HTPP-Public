I hope you like this hack that I have been preparing for several months!

Here are the credits:

GRAPHICS:
XradicalD , eto2D
Xulon
Gamma V
allowiscous , imamelia
Rykon-V73
Ayami
Dr. Tapeworm
E-man38
Tornado
MaiK
BakonMaker , GlitchyR-01
sunwarrior25
Pink Gold Peach
SRH
Anorakun
Brutapode89
Tob
MarioFanGamer
Rykon-V73
Guilherme F. Santos
Bak Sangwoo
ECS.98
Metal-Yoshi94
Anas
KirbyStar
Natsuz2
Evan.F , Green Jerry , kojimkj
Hinalyte
Merio
KaidenThelens
DaHitmenGuy
Segment1Zone2
Golden Yoshi
Evan.F , GlitchyR-01

SPRITES:
imamelia
Sonikku
anonimzwx
MellyMellouange
Iceguy
7601
Ersanio
Isikoro , Mayor Flare
yoshicookiezeus	
Koopster
HuFlungDu
Chdata
Erik , smkdan
dahnamics
leod
Ladida
MarioFanGamer
algas5 , wye
Darolac
Blind Devil
Kaijyuu
Nowieso

MUSIC:
Pink Gold Peach
Ultima
Wyatt
brickblock369
Dispace
Nanako
ElderSubZero
Pinci
LadiesMan217
Kevin
imamelia
Hazel
Masterlink
BoneFish- MF DOOM
Blind Devil
sincx
CaseP
Bak Sangwoo
Hooded Edge
Dr. Tapeworm

BLOCKS:
zuccha
Gulaschko
HammerBrother
Anas
MarioE
Roy , Sonikku
ASM
ShadowMistressYuko
ASMagician Maks
Alcaro

PATCHES:
Ladida , lx5 , wye
MarioFanGamer
Noobish Noobsicle
DiscoTheBat, Kevin, Roy, imamelia, worldpeace
smkdan
MarioE
Alcaro
anonimzwx
TheBiob
Erik
HammerBrother
Ersanio
Chdata
And some tweaks...

UBERASM:
MarioFanGamer
Kevin
Incognito
Thomas
Natsuz2 (HDMAGadrient in level 18)
Blind Devil

TOOLS USED:
Asar 1.8.1.0-By Alcaro
UberASM 2.0-By Fernap, Vitor Vilela
PIXI 1.40-By Atari2.0, JackTheSpades, Tattletale
AddMusicK 1.0.10-By Kipernal
GPS 1.4.4-By TheBiob, p4plus2 
Mario/Luigi Palette Live Editor-By JackTheSpades
Lunar Magic 3.40.0.0-By FuSoYa
LMSW 1.11-beta1-By Alcaro, TheBiob
Snes9x-x64 1.60
Zsnesw
Floating IPS (Flips) 1.31-By Alcaro
Effect Tool 3.0-By JackTheSpades, dtothefourth

TEST PLAYERS:
Deles_craft
Zenit2002

CUSTOM GRAPHICS:
BDGames2023 (me)
Deles_craft

COVER ARTIST:
Deles_craft

Thanks to these wonderful people for creating everything used in this hack!







