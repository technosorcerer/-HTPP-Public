Please Private Message to report any bugs. Don't add the Bug report to the Comment Below.

Tested with latest Snes9x, Bsnes, Original SNES Console, hasn't been tested on Super NT yet for the later versions (cause the Beehive level 1 and 2 crash on the Super NT for the v2.0 and v2.0.1 played by Lindeadx2.)

NOTE:
- 100 percentng the hack requires collecting all the Sledge Coins/Yoshi Coin in the main World. 70 Exits for Any% without getting all the Sledge Coins/Yoshi Coins and the Secret Exits.
- The Sledge Coins, Lost World Switches and the Coins will be saved to the rom when reseting the game or game over.
- You can Switch Character on the Overworld by Pressing R.

Bugs to Know:

Minor:
 - There's still a slight chance of a pop-like noise sfx happening when entering levels or when transporting level section.

(v1.0	09-01-2013 Version)
	- First Finish
(v1.1	06-20-2014 Version)
	- Chomp Chain glitch Fixed on Bsnes/Real Hardware. Thanks to Kaijyuu.
	- Now it has a Yoshi Coin Overworld Counter instead of the All Yoshi Coins collected Status Bar Patch.
(v2.0	06-22-2021 Version)
	- Removed the Health Bar Patch for some reason, and replaced it with SMA2 Powerdown Patch.
	- Fix the SRAM error.
	- The Player is no longer visible while teleporting on the Bonus Barrel.
(v2.0.1	09-14-2021 Version)
	- Fixed the Rope Climb on nothing after being pushed to the wall.
	- Fixed the Underground Pillars Level when Yoshi can pass the No Yoshi Sign Block.
	- Etc.
(v2.0.2	10-11-2021 Version)
	- Added a sign for Peach when she not allow to float in a level room, so the player won't be confuse.
	- Went from SRAM Expand to SRAM Plus, cause found bugs after clearing some exits on File C messes up File B SRAM.
(v2.0.3	10-24-2021 Version)
	- Update the Sprite Status Bar from v1.1.0 to v1.1.1B which causing the game to freeze on Bsnes v115 on certain levels, don't know if that fixes for Super NT from crashing the game.
	- Fix few bugs
(v2.1	12-03-2021 Version)
	- Fixed the Ground Pound bug for Luigi when on Yoshi/In the Water/Ducking/DKC Barrel/Pause/Message Box.
	- Fixed the Graphic glitch after game over on Peach.
	- Change the 2 Player Mode, To Switch Character on Overworld by Pressing R instead.
(v2.2	05-30-2024 Version)
	- Fixed the HDMA FG & BG Palette bug when Pausing the Game on the SNES Console & Super NT. Thanks to Ice Man for the HDMA Fix update.
	- No Death animation while in the Bonuses when small Luigi/Peach.
	- Fix the Sprite Status Bar from causing the 1 Row tiles to look like garbage for the Layer 3 BG.
	- Etc.
(v2.2.1	06-24-2024 Version)
	- Fixed The Message for Panser's Ice Cave, I had used the wrong message box sprite for the 2nd bonus stage. No one on the previous versions had mention that to me, Thanks to Ringo for the notice.

CREDITS

Tools I Use:
	- Addmusic v4.05.03 by Romi, HuFlungDu
	- AM4 Player v1.01 by Vitor Vilela
	- Asar v1.36 by Alcaro
	- BlockTool Super Deluxe v0.44A by smkdan
	- Cluster SpriteTool by Alcaro
	- GradientTool v0.8.1.7 by ExoticMatter
	- HxD Hex Editor v1.7.7.0 by Maël Hörz
	- Lunar Magic v2.12 to v2.22 by Fusoya
	- Overworld SpriteTool by Alcaro
	- Racing Stripe v1.3.1.0 by Edit1754
	- SampleTool v2.0.0.5 by smkdan
	- Slogger by smkdan
	- SMW Misc. Text Editor by smallhacker
	- SMW Status Bar Editor by smallhacker
	- SnesGFX v2.4 by Vitor Vilela
	- SpriteTool v1.40 by Romi
	- Stim2Bin by Edit1754
	- TinyMM
	- Tweaker v12 by Mikeyk
	- Variable Width Font Cutscene Tool by Romi
	- Xkas v0.06 by byuu
	- yy-chr Beta v0.99 by YY Creator
	
Patches I Use:
	- 100 Exits by Alcaro
	- Classic Fireball by Alcaro
	- Coin Counters (4-digit) v1.1 by imamelia
	- Counter Break Y by Glyph Phoneix
	- Counter Patch by Iceguy
	- Custom Bounce Blocks by Kaijyuu
	- Disable Bonus Star v1.1 by Aiyo, imamelia
	- Feather Power-up Fix by Romi
	- Generic ExGFX Uploader v1.2 by Edit1754
	- Ground Pound by MarioEdit
	- HDMA v3.5 to v3.6 by Ice Man
	- Item Box GFX Fix by Kenny3900
	- Layer 3 ExGFX v2.2 by Roy, Edit1754
	- Multiple Midway Point v1.3 to v1.5 by Kaijyuu
	- Multiple Songs on Main Map by smkdan
	- No More Sprite Tile Limits v1.0.1 by edit1754
	- No Title Screen Movement by DiscoTheBat
	- One OR Two Players Only by p4plus2
	- Overworld Counters by Ladida
	- Pause Menu Patch by Iceguy
	- Piranha Plant Fix Patch Fix by Chdata
	- Play as Yoshi v1.1 by WhiteYoshiEgg
	- Princess Peach Abilities by Ladida
	- Ropefix by Alcaro
	- Separate Luigi Graphics v2.2 to v3.0 by DiscoTheBat, Smallhacker
	- Slow Horizontal Layer 2 (BG) Scrolling Rate by lolcats439
	- SMA2 Powerdown by Alcaro
	- SMB3 Screen Scrolling Pipes by Fuosya, Alcaro
	- Sprite Status Bar v1.1.0 to v1.1.1B by Edit1754
	- SRAM Plus by MarioEdit
	- UberASM v1.1 by p4plus2
	- Windowing Fadeout/In v1.1 by Ersanio

Author for Graphics:
	- Alcaro
	- Alessio
	- Anonymous
	- Black Sabbath
	- Bullymario
	- Buu
	- carol
	- Carsr4carpeople1
	- ChaoticFox
	- cheat-master30
	- Dahnamics
	- DiscoTheBat
	- Doomdragon
	- DragonFire6780
	- Edit1754
	- Firebar
	- Fusoya
	- Hadron
	- HaruMKT
	- Hinalyte
	- Hobz
	- ibz10g
	- Jack Kitetsu
	- Jonny Azzuris
	- Kaeru
	- Kaijyuu
	- Leictron
	- Link901
	- Luigi-san
	- LunarDrake
	- Mai
	- Mikeyk
	- NekohDot
	- PineappleProducer
	- RaindropDry
	- Ravelos Second
	- Romi
	- Rykon-V73
	- ShrooboidBrat
	- Shrooby
	- smkdan
	- Sonikku
	- Supermario12
	- Thehoundsquad
	- Themetaknight
	- X-King
	- Zchannel

	Graphics From:
	Animaniacs
	Castlevania: Aria of Sorrow
	Castlevania: Dracula X
	Castlevania Chronicles
	Chrono Trigger
	Donkey Kong Country 2
	Donkey Kong Country 3
	Donkey Kong: King of Swings
	Go Go Ackman 1
	Go Go Ackman 2
	Ice Age 2: The Meltdown (GBA)
	Joe & Mac 3
	JowTH's
	Kirby Super Star
	Mega Man 3
	Mega Man 7
	Mega Man X2
	Metroid Fusion
	Sonic the Hedgehog 2
	Super Mario All-Stars: SMB1
	Super Mario All-Stars: SMB2
	Super Mario All-Stars: SMB3
	Super Mario Land 2
	Super Metroid
	The Death and Return of Superman
	Yoshi's Island
	CUSTOM GFX

Author for Blocks:
	- 1524
	- ASM
	- Broozer
	- Bullymario some with Blockcreator v1.1
	- Camoslash
	- Carol
	- Decimating DJ
	- Edit1754
	- Ersanio
	- Fierce Deity
	- Fusoya
	- Hamtaro126
	- Iceguy
	- Jagfillit
	- Kaijyuu
	- Koyuki
	- l8strudel
	- Lexator
	- Lolcats439
	- MarioEdit
	- New Hacker
	- Ninja Boy
	- PatPatPat
	- Ramp202
	- Roy
	- Sind
	- Sonikku
	- S.L.
	- Teo17
	- Varn
	- WhiteYoshiEgg
	- Wiiqwertyuiop

Author for Sprites:
	- 682
	- Alcaro
	- Andy-k-250
	- BoingBoingsplat
	- carol
	- Chdata
	- Dahnamics
	- Davros
	- Dispari Scuro
	- Edit1754
	- HuFlungDu
	- Iceguy
	- imamelia
	- Jimmy52905
	- Kaijyuu
	- Killozapit
	- Koyuki
	- Ladida
	- Lavos
	- Le Comte Niark
	- Magus
	- Mattrizzle
	- Maxx
	- Mikeyk
	- Nameless
	- Protagonist
	- Reini
	- Romi
	- Schwa
	- Shinnok
	- Smkdan
	- Sonikku
	- S.N.N.
	- wiiqwertyuiop
	- Yoshicookiezeus
	- Some Japanese Authors

Author for Music:
	- andres
	- Anikiti
	- Atma
	- Bullymario
	- CK Crash
	- Counterfeit
	- CrispyYoshi
	- DDDDOS7HQM
	- Dispari Scuro
	- Ersanio
	- FPI
	- Fyord
	- HarvettFox96
	- Homing
	- Ice Man
	- imamelia
	- Jimmy52905
	- Kipernal
	- Lui37
	- Masashi27
	- MidiGuy
	- oL7G5pOF4c
	- Opposable
	- RednGreen
	- Red Chameleon
	- Sinc-X
	- Slash Man
	- Sonikku
	- Spade
	- spigmike
	- Sui
	- S.N.N.
	- Supertails
	- Tornado
	- undefinied3
	- Wagokoro_
	- Worldpeace125
	- X-treme
	- Some Japanese Authors

	Music From:
	Actraiser 1
	An Untitled Story
	Bugs Bunny Birthday Blowout
	Cave Story
	Challenger
	Chaos Angels
	Chrono Trigger
	Donkey Kong Country 2
	Donkey Kong Land 2
	Duck Tales
	Final Fantasy 6
	Hydlide 3
	Ice Age 2: The Meltdown 2 (GBA)
	Kirby Super Star
	Live-A-Live
	Mario & Luigi: Partners in Time
	Mario Kart 64
	Mega Man 2
	Mega Man 3
	Mega Man 6
	Mega Man 7
	Mega Man 8
	Mega Man 10
	Mega Man X3
	Mega Man X6
	Metroid 1
	New Super Mario Bros. 2
	Paper Mario
	Penguin Adventure MSX
	Pokemon Red/Blue/Yellow
	Sonic the Hedgehog 2
	Sonic 3 & Knuckles
	Super Mario 64
	Super Mario All-Stars
	Super Mario Bros. 2
	Super Mario Bros. 3
	Super Mario Land 1
	Super Metroid
	Yoshi's Safari
	Yoshi's Story
	You Spin Me Round (Like a Record)
	CUSTOM Ports
	