
                       ############################
                      /                            \
                     #     'Super Mario World'      #
                     #                              #
                     #      ~~Never Say Die~~       #
                      \                            /
                       ############################

                       
                       
+-----------------+                                        +-------------+
|TABLE OF CONTENTS|                                        |SUMMARY      |
+-----------------+----------------------------------------+-------------+
|a01. PATCHING INSTRUCTIONS                                |PATCHING     |
+----------------------------------------------------------+-------------+
|b02. RECOGNITION AND SALUTATIONS                          |THANKS       |
+----------------------------------------------------------+-------------+
|c03. THE PURPOSE OF THIS HACK                             |PREAMBLE     |
+----------------------------------------------------------+-------------+
|d04. HOW THIS HACK WAS ACCOMPLISHED                       |METHODOLOGY  |
+----------------------------------------------------------+-------------+
|e05. USE AS YOU SEE FIT                                   |DISCLAIMER   |
+----------------------------------------------------------+-------------+
==========================================================================
+------------------------------------------------------------------------+
|a01. PATCHING INSTRUCTIONS                                              |
|                                                                        |
|1. Acquire a clean unheadered American release of the Super Mario World |
|   ROM for the SNES.                                                    |
|     We used "Super Mario World (U) [!]" as a base;                     |
|2. Acquire an SNES emulator.                                            |
|     We tested this modification on both SNES 9x and Mesen;             |
|3. Download an IPS patching program.                                    |
|     We used LunarIPS;                                                  |
|4. Run LunarIPS and apply the patch included with this file on the      |
|   Super Mario World ROM that you acquired in step 1.                   |
|5. Run the ROM with your favorite emulator or use real hardware.        |
+------------------------------------------------------------------------+
==========================================================================
+------------------------------------------------------------------------+
|b02. RECOGNITION AND SALUTATIONS                                        |
|                                                                        |
|This modification was authored by FatRatKnight.                         |
|This readme was written by FatRatKnight and edited by Phaxuji.          |
+------------------------------------------------------------------------+
==========================================================================
+------------------------------------------------------------------------+
|c03. THE PURPOSE OF THIS HACK                                           |
|                                                                        |
|This is FatRatKnight.  Making this hack was a bit of a teaching         |
|experience.  I was helping someone else create this as a means for      |
|folks who just wanted to play Super Mario World for fun without         |
|worrying about failing.  As a result, we now have a hack where mistakes |
|are much less jarring and fatal.                                        |
|                                                                        |
|More to the point, you can't die.  As in, it's not possible.  What's    |
|that?  Fell off a cliff?  Not a problem!  Just bounce right back into   |
|the field and continue!                                                 |
|                                                                        |
|For those who are brand new to games or kids or anyone who just doesn't |
|enjoy the punishing world of platformers, this hack is dedicated to     |
|you.                                                                    |
|                                                                        |
|Here is a list of the following effects that have been changed from the |
|original game:                                                          |
| * Upon taking damage, Small Mario will simply be Small Mario again.    |
| * Upon falling off a cliff, Mario will bounce back up instead.         |
| * Upon being crushed, Mario has free left-right movement.              |
| * Upon falling into lava, Mario doesn't die.                           |
| * The timer can go to zero, but nothing will happen as a result.       |
| * The Start -> Select trick to leave cleared levels is usable even in  |
|     uncleared levels.                                                  |
+------------------------------------------------------------------------+
==========================================================================
+------------------------------------------------------------------------+
|d04. HOW THIS HACK WAS ACCOMPLISHED                                     |
|                                                                        |
|'Taking damage doesn't lose a life'                                     |
|                                                                        |
|It is as simple as telling the game that Mario isn't small when he      |
|takes a hit.                                                            |
|                                                                        |
|A branch at System Bus location $00F5D7 is asking whether Mario is      |
|small when we take damage.  Removing it (with NOP NOP) meant we never   |
|jump to the death code, so it always looks like an ouch when we're hit. |
|                                                                        |
|We'd like to at least have some way of going back to Small Mario, which |
|is why we didn't keep him invincible from damage.  Just that we removed |
|the possibility of losing a life when we're hit.                        |
|                                                                        |
| - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -|
|'Falling off a cliff is bouncy'                                         |
|                                                                        |
|It's as simple as... well, we needed a whole new function, but at least |
|it's very short and allows for Mario to bounce back like it was         |
|nothing.                                                                |
|                                                                        |
|The game uses a JSL at System Bus location $00F5B2 to jump to the death |
|code.  We didn't like the death, so we instead used the padding         |
|starting at $00FF93 and injected our own code to set -128 to Mario's Y  |
|velocity.  If you need more height, remember that holding either jump   |
|buttons reduces gravity acting on Mario, allowing a higher bounce.      |
|                                                                        |
|Also, that annoyance with swimming too low isn't fatal anymore!  It's   |
|so much easier to notice the missing terrain under the stage!  Try      |
|going under a bunch of walls... it'll be fun, I tell you!               |
|                                                                        |
|A few quirks were noted, however.  Mario is far enough below everything |
|that he is effectively interacting with a world that never expected him |
|to exist there.  For example, I recall hitting a few odd note blocks    |
|during a Sumo Bros. attack.                                             |
|                                                                        |
|Also, hitting a goal post from underneath and bouncing up and down      |
|during the ending walk tends to glitch the graphics in colorful ways.   |
|Along the way, we did note one -- and ONLY one -- instance of a crash   |
|that we were unable to replicate.  However, as a result, save states    |
|are advised if possible.  Nevertheless, the game has been tested and    |
|completed from start to finish several times without crashing.          |
|                                                                        |
| - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -|
|'Falling into lava is merely warm'                                      |
|                                                                        |
|It's as simple as finding the multiple spots in the code where Mario    |
|dies from falling into lava.  Seriously, there were three different     |
|lavas the game handles!  Huh, I guess it wasn't too simple, then.       |
|                                                                        |
|Lava #1 - Normal lava.  We adjusted a branch at System Bus $00EDDD and  |
|decided we don't like running the death code.  Interesting, this lava   |
|is treated like water when it doesn't roast us toasty.                  |
|                                                                        |
|Lava #2 - Bubbly lava.  That spot at System Bus $00ED64 looked ugly.    |
|With a fixed branch, we fall straight through!  This lava blocks upward |
|momentum, so once below the screen, you're relying on the bouncy cliffs |
|code to survive.  How convenient that we also included that in this     |
|hack!  You'll probably need to go underneath some other terrain and     |
|bounce back up that way.                                                |
|                                                                        |
|Lava #3 - Boss lava.  Like the one seen in the boss fight of Castle #1. |
|Tastes like just normal air once we messed with that branch at System   |
|Bus $00F9A0.  Shockingly, with no solid ground below, we call the       |
|bouncy cliffs code when Mario reaches the fated death line below.       |
|                                                                        |
| - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -|
|'Timer only ever speeds up music these days'                            |
|                                                                        |
|It's as simple as changing a single branch again!  In the timer code    |
|this time, however.                                                     |
|                                                                        |
|It's at System Bus $008E69.  Actually, the whole function starts sooner |
|and ends later, but the one branch we adjusted just asks if the timer   |
|used to be more than none a moment ago.  So by tweaking that, the game  |
|always thinks when it hits zero, that there was never a timer to kill   |
|Mario with.                                                             |
|                                                                        |
| - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -|
|'Start + Select always works in stages.'                                |
|                                                                        |
|It's as simple as telling the game we've totally cleared that stage,    |
|even though we never did.                                               |
|                                                                        |
|System Bus $00A267 makes the check.  Disabling it seems to let us       |
|escape many a place, even the big Bowser fight at the end.              |
|                                                                        |
|Because we got rid of every method we can think of on how Mario dies,   |
|this opens up possibilities where we can trap Mario into a spot         |
|inescapable to the highest jump he can make.  There's probably some     |
|corner of a castle somewhere they never intended for you to reach       |
|thanks to the bouncy cliffs code.  Letting Start + Select always work   |
|means you can at least escape from the trap, allowing Mario to continue |
|his adventure.                                                          |
|                                                                        |
|Oh, and if you're wondering how to do Start + Select, first you press   |
|Start to pause the game, then Select to leave the stage.  Surely this   |
|was impossible to guess from the name we've given it.                   |
|                                                                        |
| - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -|
|'Being crushed.  More like a hug, really.'                              |
|                                                                        |
|It's as simple as... you know what?  No, not simple, it was             |
|complicated.                                                            |
|                                                                        |
|We're guarding against terrain crush, where we let Mario move as        |
|desired, and screen edge crush, where we shove Mario back in instead.   |
|                                                                        |
|First off, what do we want for crushy behavior?  Free movement would at |
|least let us get us somewhere we like.  Always going left kind of       |
|works, but we didn't like the game's default behavior and went with     |
|checking the controller to see where to go.                             |
|                                                                        |
|For that, we needed a new function.  For that function, we needed room. |
|The padding zone at System Bus $00FF93 wasn't enough. We chose a spot   |
|in another bank, at $03FDE0.  This, being in another bank -- and the    |
|fact all the cool kid stuff was using JSR and not JSL -- meant we had   |
|to attach a little more to our $00FF93 to allow a JSR to go there, then |
|a JSL from there to get to our 03 bank.  I wasn't in the mood to add 2  |
|bytes to an existing function, then track down and relink every         |
|possible function call to stuff after $00E9FB.                          |
|                                                                        |
|As for the function itself, we studied where the directional inputs     |
|were and used them to change Mario's position.  We have coded an        |
|attempt at going up and down, but apparently we're in conflict with     |
|some other game function and that snaps us onto the grid despite our    |
|attempts.  But left/right is working fine and that's enough for us.     |
|                                                                        |
|Finally, we could also be crushed by the left and right screen edges.   |
|While we did track down the two checks for crushing Mario, we simply    |
|used the same function (the one we made to shove Mario around during    |
|a crush) and added an additional check.  Any position outside of the    |
|screen edges would just nudge Mario 16 pixels back into the field.      |
+------------------------------------------------------------------------+
==========================================================================
+------------------------------------------------------------------------+
|e05. USE AS YOU SEE FIT                                                 |
|                                                                        |
|Use this modification as you see fit.  This modification can be         |
|included and used with any other modifications.  No guarantees are      |
|implied as to its effectiveness.  This modification has not been tested |
|with any other.  Authors of their own modifications may feel free to    |
|use this one as they see fit.  No credit is necessary.                  |
+------------------------------------------------------------------------+