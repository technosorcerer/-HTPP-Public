				=================
				  VIP 5 - Fixed
				=================

				 ==============
				 About the hack
				 ==============

VIP 5 (also known as MIX 5) is an SMW hack released around 2011, made by
users on the Japanese VIP forum. It was originally released in Japanese,
and is quite large, sporting 100 exits. As of this writing, it is the fifth
and latest entry of the VIP/MIX hack series.

As per usual for the series, the hack was released in two versions, one of
which featured normal SMW GFX, and the other of which featured custom graphics
for all of the characters and enemies based on memes that originated on the
Japanese collection of message boards known as '2ch'. The custom GFX version
of this entry in the series also features an overworld with fully custom graphics
and animations.

Both versions of the hack also has have notable (though concentrated) amount of
custom ASM, some of which has significant amounts of trouble running on any
emulators beyond ZSNES and SnesGT (which this was originally developed for).

				==================
				About this release
				==================

First of all, we were not involved in and take no credit for the development of
the hack itself. We merely did the fixes and translation described below.

This release is based on the custom GFX version of the hack. Furthermore, it
is based on version 1.05, which is the latest version. Version 1.05, which does
add some things to the game, is also notable for introducing some bugs that
cause the game to crash on some levels regardless of what emulator you're playing
on.

The release included in this zip file basically does three things. First of all,
it fixes the crash bugs introduced by version 1.05 of VIP 5. Secondly, it fixes
(to the best of our knowledge and abilities) all of the compatibility issues
that occur when playing this game on more accurate emulators. This hack has been
tested and confirmed to work on Snes9x, BSNES, and even a real SNES console.
See the header "Bugs that were fixed" further down in this readme to get a full
list of things that were fixed, as well as some issues that are known to still occur.

Finally, the zip also includes a version of the hack that translates the Japanese
text into English. The patches for both the Japanese version and English version
have the above-mentioned fixes applied to them.

As a bonus, this package contains two ASM patches for some extra features.
Read the section below to find out what they are and how to apply them

			      =====================
			      About the ASM patches
			      =====================

Once the BPS patch of your choice has been applied, the resulting ROM should be ready
to play on most hardware and software capable of running SNES games without further
modification.

However, there are some more options in the form of ASM patches that you might be interested in.
In this hack's case, we've included patches for the following:

	- Translator notes on the overworld in the English version which explain some of
	  the cultural references made in the game's text.
		(Discretion advised: some of these notes explain jokes which reference
		 explicit things which some may find offensive. Do not apply this patch
		 if you want to continue believing that the VIP series is wholesome
		 and innocent.)

	- Bug fix for a Dragon Coin that often fails to spawn when it should in one level.

We have tried making the process of applying these patches as simple as possible, so
even if you've never done anything with ASM before it shouldn't take longer than a
few minutes to find out what they all do and to actually apply the ones you want.

The process uses a program called "Asar" by Alcaro (and others), which is not our work, but a
cut-down copy of which (only including the .exe and license information) is supplied inside
this zip file for the sake of ease of use.
The full program can normally be found at these addresses:
https://www.smwcentral.net/?p=section&a=details&id=14560
https://github.com/RPGHacker/asar

Below is a step-by-step guide to learning what all the ASM patches do, and how to apply them.

1. Prepare the ROM by applying either of the BPS files to a clean, headered USA version ROM of
	Super Mario World, and placing it into the 'asar161' folder.

2. Go to the 'asar161' folder, and open '@main.asm' in a text editor of your choice (Notepad will work).

(You can skip step 3 and step 4 if you want all of the patches.)

	3. Read the explanations about each patch inside this file to decide which patches you
		want applied to the ROM, and follow the instructions.

	4. Make sure '@main.asm' has been saved with any edits you made.
		(Take care in step 6 if you rename this file.)

5. Run 'asar.exe'.

6. When asked for the patch name, enter "@main" (without quotes) or whatever
	else you have renamed it to.

7. When asked for the ROM name, enter the file name of the ROM that you put in the same folder
	in step 1, with or without file extension.

And now if nothing has gone wrong (it shouldn't), you will get a list of the patches that have
been applied, and a message saying that the patch has been applied successfully.
The ROM is now ready to be played.

			  ======================================
			  Compatibility problems that were fixed
			  ======================================

				WARNING: Spoilers ahead

	- Custom code that makes incorrect use of SNES multiplication and division registers.

	- Crashes related to the use of an old AddMusic tool made by carol which uploads
	  music data into a section of Audio RAM which gets overwritten by echo data.

	- Stuttering audio caused by residual audio data getting continually replayed when
	  echo delay is set to 0, but echo playback is not turned off.

	- Copious amounts of black flashes and garbage tiles flickering on the overworld due
	  to custom tile animation routines taking far too long to process graphics data.

	- One spotlight room becoming almost impossible to see on real hardware due
	  to different emulation of the 'half-color enable' feature on certain emulators.

	- A yellow flash that occurred in one of the special world levels due to the custom
	  graphics upload routine taking too long to upload its graphics.

	- Large amounts of palette glitching during two end/post-game bosses, caused by invalid
	  writes to CGRAM outside of screen blanking periods.

	- Some black flashes and flickering at the top of the screen during the same two bosses,
	  caused by custom graphics upload routines taking too long to finish.

			  	     ===============
			  	     Other bug fixes
			  	     ===============

The following are some issues that were introduced in version updates of the original hack.
We have taken the liberty of fixing these for this release, even though they are not strictly
compatibility issues, as they would occur on any emulator.

	- Aforementioned crashes that happened upon loading some levels.

	  These were introduced in version 1.05, and caused by some of the new custom
	  ASM overwriting data which marked the end of music data to upload to Audio RAM.
	  This in turn was caused by the AddMusic tool used in this hack not setting the
	  size of its music chunks correctly in the chunk's metadata, marking the last two
	  bytes as free ROM for other tools to use.
	  The game would effectively overwrite its own audio engine and get stuck waiting 
	  for the crashed audio processor to respond.

	- Appearance of multiple columns of the letter 'D' in one of the special
	  world levels instead of the intended blank tiles, blocking the player's view.

	  This bug was introduced in version 1.04 due to that version's inclusion of
	  custom enemy names in the credits. One of the tiles added to the GFX file
	  that's used to display these enemy names inadvertently overwrote the blank tile
	  that was used by this level.

				      ============
				      Known issues
				      ============

	- A glitch involving the palette HDMA for the second phase of the post-game boss
	  being applied to the background instead of the boss itself has been reported on
	  BSNES-plus v04 running with the accuracy profile. This effect is fairly rare,
	  not fatal, and can be fixed by restarting the console (make sure to save the midpoint first).

	  The direct cause seems to be that the HDMA is getting applied before
	  horizontal blanking starts, which messes up the CGRAM address. However, we have not
	  been able to figure out what the root cause of this is, as debugging reveals nothing
	  out of the ordinary. Tests on console did not have this bug occur, so it is not known
	  whether this occurs on real hardware as well. In any case, this bug will not occur
	  on Snes9x (and presumably emulators less accurate than that).

	- There is still some black screen flashing due to an excess of graphics data being uploaded.
	  Specifically there is a large possibility of a single flash when stopping freelook on the
	  overworld, as well as some minor cases during the end-game bosses.

	- The custom sample data used in a few levels tends to crackle.

	- Some of the levels still have some minor flickering at the very top of the screen.
	  

					=======
					Credits
					=======

This is a list of all the people whose software/patches/work we've used or adapted on this hack:

Asar 					- Alcaro et al
Recover Lunar Magic 			- Parasyte
Extended Overworld Level Names		- Smallhacker
Fixed Color Data NMI Optimizer 		- Ladida
Lunar Magic				- FuSoYa

ASM for translator notes, message box chaining, and cutscene text chaining by Super Maks 64.
Translation, compatibility/bug fixes, and additional ASM by This Eye o' Mine.
Additional research and translation by lion.
Proofreading and testing by SimFan96, Ryrir, and aterraformer.

And of course thanks to Vippers, who made the hack in the first place.

Our apologies to any people we might've missed.

- The Hack Fix/Translation team