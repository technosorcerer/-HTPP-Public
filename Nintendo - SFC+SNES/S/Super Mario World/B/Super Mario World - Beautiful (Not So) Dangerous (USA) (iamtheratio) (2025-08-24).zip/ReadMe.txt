BEAUTIFUL (NOT SO) DANGEROUS
A SMW ROMHACK CREATED BY: IAMTHERATIO
Version: 1.0
© 2025

╔══ HACK DETAILS: ══════════════════════════════════════════════════════════════════════════════════════════════╗
║
║  Beautiful (Not So) Dangerous is a beginner-friendly reimagining of the original Beautiful Dangerous, rebuilt from the ground up to
║  welcome new players into the kaizo genre. With a focus on fun over frustration, this hack offers 15 exits that balance challenge
║  with accessibility. 
║ 
╚═════════════════════════════════════════════════════════════════════════════════════════════════════════════╝
╔══ FEATURES: ══════════════════════════════════════════════════════════════════════════════════════════════╗
║ 
║  v1.0:
║  - Retry prompt
║  - 15 total exits, 2 of them Switch Palaces
║  - Both secret exits are within first half
║  - Custom sprites, blocks, graphics, palettes, and music
║  - Custom overworld by Devazure
║  - Midways are automatically saved
║  - 3 room final castle with midways
║  - Custom boss
║  - No fast pipes or motor skills
║
╚═══════════════════════════════════════════════════════════════════════════════════════════════════════════╝
╔══ SPECIAL THANKS: ════════════════════════════════════════════════════════════════════════════════════════════╗
║
║  I'd like to give extra special thanks to the following people for their help.
║
║  DevazureBlue
║  
║  Also, big thanks to the SMW community for all the love, the Romhack Races baserom, and for answering all of my endless questions.
║  I truly appreciate everything.
║
╚════════════════════════════════════════════════════════════════════════════════════════════════════════════╝

╔══ MUSIC: ════════════════════════════════════════════════════════════════════════════════════════════════════╗
║
║  LEVEL:                                       PORT:                                                           CREATOR:
║  Title Screen                                 Celeste - Resurrections                                         Maxodex
║  Intro Screen                                 Knights of the Round - Merlin                                   qantuum
║  Yoshi's House                                Hollow Knight - White Palace                                    Maxodex
║  Adventure Awaits                             Mango Mountain                                                  Dispace
║  Life's A Beach                               Sunshine Type                                                   Macrophaje
║  Monochromatic Attic                          Ghost Factory Ambience                                          brickblock369
║  Monochromatic Attic (Secret Exit)            3x3 Eyes: Juuma Houkan - Factory                                SiameseTwins
║  Green Switch Palace                          The 12th Vanilla Level Design Contest - Mountain Zone           icrawfish
║  Above The Waves                              Puyo Puyo - Brave of Puyo Puyo                                  Ultima
║  In Bloom                                     Super Nazo Puyo 2 - Rulue's House & Menu Screen                 MercuryPenny
║  In Bloom (Secret Exit)                       Undertale - It's Raining Somewhere Else                         Teows
║  Blue Switch Palace                           Bakumatsu Kourinden Oni - Underwater                            Ahrion
║  Cold Nights                                  Mega Man 11 - Tundra Man Stage (Arranged)                       com_poser
║  Astral Plains                                8th VLDC, Map - Grass                                           HaruMKT
║  In The Clouds                                Bomberman 64 - Altaile II                                       Ahrion
║  Speakeasy                                    Last Bible III - Ancient Warrior                                Kevin
║  Heavy Gloom                                  Shadow of the Dark Spirit ~ Complete Darkness (Remix)           Hooded Edge
║  The Hollow (Intro)                           Pizza Tower - Meatophobia                                       Daizo Dee Von
║  The Hollow (Room 1)                          SMW Central Production 2 - Check the Temperature                Blind Devil
║  The Hollow (Room 2)                          Slippery Scary Subterranean                                     brickblock369
║  The Hollow (Room 3)                          Kidou Senshi Gundam F91: Formula Senki 0122 - Act 1 & 7         Ahrion
║  The Hollow (Room 4)                          Secret of Evermore - Boss Theme 2                               ggamer77
║  The Hollow (Boss Battle)                     Metal Max 2 - Wanted Person Battle                              Ahrion
║  Credits                                      The 8th Annual VLDC - MAP - Grass and Hub                       Izuna
║  Overworld - Main                             Bomberman 2 (DS) - Multiplayer Lobby                            Teows
║
╚════════════════════════════════════════════════════════════════════════════════════════════════════════════╝
