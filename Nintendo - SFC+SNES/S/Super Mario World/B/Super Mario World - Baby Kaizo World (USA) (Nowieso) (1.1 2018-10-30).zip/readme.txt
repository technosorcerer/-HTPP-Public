Baby kaizo World
made by Nowieso (not Noweiso!11!!1!!)
Started making: 12. August 2018
Finished making: 30. October 2018
Current Version: 1.1
Last Update: 20. November 2018
---------------------------------------------------------------------------------------
If you use a SNES Classic, you might want to use the version without the deathcounter,
because the deathcounter Patch can cause a lot of issues on the console.

I recommend playing this hack AFTER beating Learn2Kaizo by NeXuS15,
because you will learn a lot of mechanics in that hack that I do not
explain in my hack. https://www.romhacking.net/hacks/3676/

Dear Baby,
I made this hack for you so you can practice Kaizo tricks
in easy, short and forgiving levels. Take your time with the levels,
don't get frustrated if a level takes you some time to beat. You will feel
very good after beating it. If you feel like you need more practice with a
certain kaizo mechanic, I recommend playing the level multiple times for
practice. I hope you will have a lot of fun with this hack.
Thank you for downloading. This means a lot to me.

~Nowieso (Not Nowesio!!11!)

When you finished this hack (or found an issue), please contact me and let me
know if you enjoyed it or not. Feedback is the most important thing in order
to improve level design.
YouTube: Nowieso Gaming
Twitch: twitch.tv/nowieso
Discord: https://discord.gg/x95bFpr
www.nowieso.de

----------------------------Music------------------------------------------------------
*The names of the songs are the same names as they are called on SMWCentral*


Title Screen, Yoshi's House, Switch Check:
LittleBabyBum - Big and Small

Overworld 1 Grassland:
Floating Overworld

Overworld 2 Forest:
3x3 Eyes: Seima Kourinden - Mexico

Overworld 3 Mountain:
Legend of Zelda: A Link to the Past - Death Mountain

Overworld 4 Bowser:
Arrangement - Bowser's Doom Way

Baby's Garden:
Super Mario World Theme - Pops Remix

Blargg's Hot Home:
Deep Dark Caves

Baby Beach:
Super Mario RPG - The Road is Full of Dangers

Baby's Nightmare
Mario Kart: Super Circuit - Boo Lake / Broken Pier

Switch Palace's:
Mario Kart DS - Waluigi Pinball

Ropes Are Not Toys, Baby's First P-RUN:
Athletic Piano (Pal Version)

Sandstone Cavern:
Pok�mon Ruby/Sapphire - Team Magma & Aqua Hideout

Dark Side Of Kaizo:
New Super Mario Bros. U - Acorn Plains (Overworld Theme)

Normal Castles:
New Super Mario Bros. - Castle (v2)
Super Nazo Puyo: Ruru no Ruu - Boss Theme

Enter The Forest:
Mario and Luigi: Bowser's Inside Story - Let's Meet in the Mysterious Forest

Platform Hopping:
Secret of Mana - The Little Sprite

Sunglasses Ready?:
Super Mario World - Cave (Icy Remix)

PRECISION SUCKS:
Donkey Kong Country - Forest Frenzy

Nightmare Forest:
Secret of Mana - Rose and Ghost

RUN FOREST:
Fatal Chase

Sky Tree Jr. :
Dungeon Explorer - Judas Dungeon

Baby Shells:
Super Mario Sunshine - Bianco Hills

Janked Up Slopes:
Super Mario RPG - The Axem Rangers Drop In

Baby River:
Chrono Trigger - Undersea Palace

Smash The Ghosts:
Ghost
Sonic & Knuckles - Miniboss

Chuck Garden:
Mountainous Melody

Dragon Caverns:
Beats from Deeps

Baby's First Disco:
Super Mario RPG - Docaty Mountain Railroad

Babysitter Moles:
SMW & SMB Underground Remix

Unhealthy Cola:
Donkey Kong Country 2 - Hot-Head Bop

Smashin' Tears:
Seiken Densetsu 3 - Few Paths Forbidden

No Time To Breathe:
Underground Zone - Sonic the Hedgehog 2 

Baby Star:
Kirby Super Star - Halberd ~ Nightmare Warship

Kindergarten Castle:
Mario Kart DS - Bowser's Castle
Super Mario RPG - Fight Against Bowser

Discardation:
Touhou 10: Mountain of Faith - Faith is for the Transient People

Invisibility:
Little Master: Niji Iro no Maseki - Forest of Labyrinth

Moletainity:
Pok�mon Mystery Dungeon Series - Amp Plains

Fuzzynation:
100% Orange Juice - Military Sora's Theme

Baby Finale:
Castlevania: Curse of Darkness - The Visitor in the Silk Hat
Mario & Luigi: Bowser's Inside Story - Final Battle


--------------------------Updates------------------------------------------------------

v1.1
-palette improvements (AAAAAAA my eyes)
-better secret exit hints, one complete secret exit replacement
-better indication
-improvements on the levels for speedrunners
-removed cutoff in a few levels
-shell in a layer 2 level is replaced with a throwblock
-broken levels (special world) in the snes classic version fixed
-easier layer 2 section in a ghosthouse, also fixed a bug with the midway entrance
-better layer 2 water jump in a cave level
-rip delicious cheese
-improved message box texts
-fixed broken layer 2
-added custom music to a sublevel because I forgot to add it there
-new final boss



