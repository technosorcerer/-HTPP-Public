BUTT GRAVY
by xMANGRAVYx

1 exit
Kaizo Beginner-Intermediate Difficulty

What a crappy day to be a plumber.
This project was designed for those of us with a juvenile sense of humor. The goal is to lead Mario through a series of single room challenges. Players are tasked with clearing each room using various skillsets learned in kaizo. There are 50 rooms total, and some will be more forgiving than others. Later rooms will require more precise timing and accurate movement.

Press START+SELECT in any room to save progress and return to the overworld.

Good luck, have fun and thanks for playing!

This hack is dedicated to my five year old daughter and her love for toilet humor.
__________________

FLUX BASEROM CREDITS

A number of people have gone above and beyond in terms of helping me with code for this new baserom.
KEVINM and SPOONS in particular deserve special thanks. The following people have also graciously helped a ton:

Fernap
binavik
MarioFanGamer
TheMario90
AmperSam
LightAligns
meatloaf
Janklorde
TheBiob

__________________

Sprites:

yoshicookiezeus (ball and chain disassembly; swinging pendulum BnC)
imamelia (brown/checkerboard plat; pipe piranha pack; growing vine; Bowser statue; growing pipe; Line-Guided Rope [with KevinM])
immamelia/Thomas (poison mushroom)
Djief (baby Yoshi disassembly)
KevinM (flying question block)
dtotthefourth/KevinM (line-guided any sprite)
Erik (grey rising platform; stationary parakoopa; Para-Spiny)
Darolac (single mushroom scale plat)
mellonpizza (Lakitu cloud; p-switch [with contributions by Fernap])
Davros/Blind Devil (orb)
Sonikku (message box)
Koopster (sprite offsetter)
RussianMan (spring)
MarkAlarm (Yoshi disassembly)
Tattletale (configuragble thwomps)
RussianMan/SJandCharlieTheCat (sprite muncher)
Darolac (sprite killer)
NaroGugul/KevinM (multi-bounce numbered shell)
Iceguy (grey falling platform; Non-Line Guided Grinder)
dtotthefourth (customizable throwblock; any timed platforms; sprite stacker)
mikeyk/JackTheSpades (donut lift)
Flying rope machine (Von Fahrenheit with KevinM)
Romi/Blind Devil (bumpty)
Ladida (cluster effects)
Erik557 (spawn kicked shell)
Blind Devil (Cursor)
________

Patches:

Binavik (per-level status bar stuff; layer 2 falloff and triangle fixes; other general help)
Noobish Noobsicle (rollover/256 fix)
Katun24 (cape-spin consistency and flight directional change patches; item throw direction)
dtothefourth (baby and adult Yoshi together; layer 2 triangle fix)
KevinM (Placeable Throw Block; p-swtich Yoshi dup fix; Yoshi Sprites Interaction Fix [with TheBiob]; Yoshi tongue cutoff; Torpedo Ted Offscreen Smoke Fix; sprite item box; toggleable status bar; Yoshi/ball and chain fix; kaizos triggered by death animation fix)
p4plus2 (fire/berry fix)
RussianMan (pokey GFX fix)
Zeldara109 (Triple rotating platform fix)
mario90 (layer 2 falloff fix)
Thomas (berry fixes; disable level clear fade; Fireball Conveyor Fix)
RussianMan (pipe exit sound fix)
(Green)HammerBrother (screen constrain; Yoshi Keyhole Fix; disable first frame jump after landing)
imamelia (line-guided rope length fix; Yoshi/Non-Dynamic Podoboo; Yoshi Coin Fix)
lolcats439 (block dup; P-balloon/Cloud Fix patch; Walljump/Note Block Glitch Fix; Slow Horizontal Layer 2 scroll)
Tattletale (ghost hole fix)
Edit1754 (sprite height fix)
Edit1754/MathOnNapkins/Arujus/VitorVilela/Tattletale/KevinM (NMSTL)
Deflaktor (No pressed p-switch carry)
JamesD28 (carryable sprites, extra bit)
Ramp202 (no silent bullet bill)
Rmi (feath autoscroll fix)
andy_k_250 (magikoopa palette fix)
Anas/Yoshifanatic1 (overworld sprite redundancy patch)
SkywinDragoon (Yoshi immunity to a few sprites fix [with TheBiob])
Ladida/lx5 (Mario's 8x8 Tiles DMA-er)
el_usive (on/off line guides global)
worldpeace (layer 2 buoyancy optimize)
Davros (statue, ninji etc. ceiling check)
Darolac (block snake fix)
TheBiob (victory pose fix)
yoshifanatic (damage/swim fix)
Koopster (bomomb palette; layer 3 tide and regular water fix)
Alcaro (Tide Sprite Interaction Fix; time up fix; rope glitch; title screen white tile glitch; boo bat ceiling fix; Placeable Disco Shell)
? (SpinJumpOnTwoSpritesAtOnceFix)
? (Reznor bridge fix)
? (Sunken ghost fix)
? (Yoshi stomp wrap fix)

meatloaf (move left at goal)
? (ControlLuigiWithSameController)
RussianMan (no item stuck in wall)
WhiteYoshiEgg (OW speed change)
p4plus2 (one player only patch)
Blind Devil (cheep-cheep motion)
Alcaro (skull raft movement fix)
CliffTheCrafter (Update Vertical Scroll on Enemy Bounce)
chillyfox (thwomp/shell interaction fix)
Erik (Per-Level Layer 3 Tides Act-like Settings)
MarioFanGamer (Solid Slope Assist Tile)
Mandew (Goodbye Football RNG)
(Green)HammerBro (X Speed Fixes, speed oscillation; sprite scroll fix)
Maarfy (powerup freeze remove)
Thomas (All-Inclusive Mario Physics Modifier Patch)
CliffTheCrafter (spin-jump while holding items fixes)
MiracleWater (Springboard Fixes)
KevinM (VRAM optimization)
Lui ([no] Level Specific Speeds for Monty Moles and Hammers)
? (multiple block snake fix - Kevin?)
? (sprite priority fixes)

________

UberASM:

dtothefourth (frame-perfect spinfly from ground; on/off cooldown)
xHF01x (float delay)
KevinM + worldpeace, lx5, imamelia, Thomas, dtothefourth, etc. (retry)
KevinM (no powerup freeze; swim speed; configuragble Yoshi eats; vertical scroll)
Westslasher2/Alcaro/Erik (OW save)
TheBiob (goomba stun timer)
Binavik (Disable help sprite interaction)
janklorde (with RussianMan) (control disable)
Thomas (level wraps; teleport on no sprites)
RussianMan (motor skills)
Binavik (general help)
Ayami (layer 2 BG autoscroll)
JamesD28 (per-level sprite palettes)
kaizoman (one-way scroll)
Abdu/SJandCharlieTheCat (spawn already on Yoshi)
RussianMan (speed limit)
BlueToad (flip on/off cycle)
Mattrizzle/Ghettoyouth (lightning generator)
Koopster (layer 2 vertical rise/fall)
Badummzi and Maarfy (instant death on powerup loss)
(Green)HammerBro (SSP Uber stuff)
Mandew (low gravity)
Thomas (teleport system)
Alcaro/(Green)HammerBrother/dtothefourth/westslasher2 (flight fixes)
Blind Devil (OW and orb stuff)
JamesD28 (general help)

________

Blocks:

(Green)HammerBrother (screen-scrolling pipes; keylock blocks; one-way blocks; throwblock pack)
Blind Devil (cursor level-select blocks)
Nowieso (Carryable Sprite Spawner Blocks; sprite killer; boost block — with swunsh_)
MagmaMouse (Camera up-scrolling block)
RussianMan (remove Latiku cloud if riding)
EternityLarva (conveyor blocks; disappearing blocks)
MarioFanGamer ([better] doors; pixel-perfect spikes; destroy Yoshi block; questin-mark spawn blocks [with lx5])
Davros/mikeyk (donut lift blocks)
westslasher2 (Non-screen dependent exit pipe)
Djief (pipes enterable in midair)
dtothefourth (sprite buoyancy blocks;) 
MarioE (selective sprite killer)
KatMakes (collectables)
LDA (coin that increases time)
JackTheSpades (kill munchers)
Mindless (exit to OW block)
ASMagicianMaks (sprite and Mario-only blocks)
edit1754 (Instant slope drop-off)
dogemaster (sprite-bouncing blocks)
SJandCharlieTheCat (including contributions and hybridizations: single-use on/off blocks; half-tile duck death block; layer 2 sprite-only block; hybrid sprite killer; on/off death blocks; a number of other very simple blocks)
5544/Sonikku/wiiqwertyuiop (spin-jump blocks)
Teo17 (teleport blocks)
SL/DiscoMan/Erik557 (anti-coin)
katun24 (anti-upthrow jank blocks)

Unknown creators: sprite-only triangle; kill star power block; ThrowblockFixedForSpinOscillation.asm (a2yerold?)
________

Testers and general guinea pigs:

Particular thanks to TheVoipah, the Jankfinder himself, who's been an invaluable source of jank-finding for many months.
Jquery861
Wolfguy423
Quietmason
gui
ItzEcks
resnov
cangrejo
ThePrestinator
el_usive
________

GPS: TheBiob, p4plus2, (Green)HammerBrother
AddmusicK: Kipernal, KevinM, Lui, Medic, Vitor, KungFuKirby, HertzDevil
UberASM: Vitor Vilela, lx5, RPG Hacker
PIXI: Atari2.0, JackTheSpades, Tattletale, lx5, Sillymel
ASAR: Alacro, RPG Hacker, randomdude999, p4plus2, CypherSignal, LDAsuku, Katrina, Atari2.0, Vitor Vilela
________

GFX (layer 3 BGs): Hayashi Neru (a lot), Berk (a lot), KaidenThelens, Tob, Link13
