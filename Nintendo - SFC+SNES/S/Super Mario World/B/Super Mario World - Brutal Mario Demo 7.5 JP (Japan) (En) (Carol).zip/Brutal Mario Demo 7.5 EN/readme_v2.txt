To use patch, just apply it using Lunar IPS (or something like that) over a Demo 7.5 (Cheap Demo) ROM.

Only the main 16 stages are translated, nothing in the original overworld.

Special thanks to the Brutal Mario wiki for its translation section, which really helped me out on this.

Enjoy!


Version 2 of this patch was made in a completely different way to the 1st.
Initially, I re-inserted all of Carol's custom sprites with only changes made to the script in the opening sprite data.
The side effect of this was broken graphics and behaviour in some of the other sprites, I guess the addresses being moved about made it act weird.
This time, I went in with a hex editor and manually changed the sprite data there, byte by byte, and using some nearby free space to store the larger script.
This means only one sprite was changed, so all the bugs I introduced in the 1st version are gone now.
Crazy, since both patches are completely different but give basically the same end result!