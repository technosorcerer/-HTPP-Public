CASTLEMANIA
by xMANGRAVYx

6 exits
Standard/Normal Difficulty

This rom hack is inspired by the early Castlevania series and attempts to channel the spirit of 'NES difficulty'. It's designed to be a throwback hack of sorts- with instant-death blocks, secrets, and familiar enemies to fans of the franchise. Each level was designed with a custom graphics set and soundtrack paying homage to the source material. Some sections offer tighter platforming than others without feeling cheap or unfair to the player. Most importantly- each level has a clear path forward with the player never wondering where to go or what to do next. Fans of the Castlevania series know of it's difficult nature and shouldn't be surprised by any obstacles within the hack. To channel the concept of 'NES difficulty', this hack will not save until you complete all 6 levels, and GAME OVER will result in the player having to start over.

NOTE:
In playtesting, a few testers thought it necessary to offer an alternate version of this hack. It was decided the download file will also include an 'EASY VERSION' which will allow the player to save their progress after every level is cleared. This also lets the player CONTINUE after Game Over. Other than slight palette changes to differentiate the two- both versions are exactly the same. It also should be noted some of the level bosses don't indicate damage, however as long as your attacks are making contact it is in fact taking damage. These are attributes of the sprites used unfortunately..

Good luck, have fun and THANK YOU for playing!