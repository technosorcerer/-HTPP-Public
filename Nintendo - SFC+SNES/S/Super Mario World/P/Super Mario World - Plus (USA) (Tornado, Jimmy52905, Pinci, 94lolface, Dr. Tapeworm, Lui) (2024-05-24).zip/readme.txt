info: 
this is a hack of smw that i started back in december of 2023, and finished at the end of september 2024.
the hack contains extra course themes, inspired by super mario maker 2 and smw central's vldc hacks.

credits:
Tornado, Jimmy52905, Pinci, 94lolface, Dr. Tapeworm, Lui, and the "SMW remade from memory" romhack for the music used
MarioE for the Walljump patch
Roy for the patch of red and blue blocks giving stars
Koopster for the patch to re-enter switch palace
Smallhacker for the separate player sprites patch
Andyana Jonseph and Devazure for ripping the All-Stars Luigi sprites
Bloony Fox for the extra background sprites used