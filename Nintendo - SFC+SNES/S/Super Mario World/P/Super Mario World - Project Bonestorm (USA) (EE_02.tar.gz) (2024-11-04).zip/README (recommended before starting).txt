								 Project_Bonestorm.tar.gz

							(A Mega Man/X-styled SMW ROM hack by EE_02.tar.gz)
								
								17 exits, single-player only


___________________________________________________________________________________________________________________________________________________________________   
Version 1.0 - November 5, 2024

- Initial release
- Formerly named ".EXE//Project Executable Project" from the 2020 Demo to now named above

___________________________________________________________________________________________________________________________________________________________________

TABLE OF CONTENTS
--
1. Custom Mechanics - Tutorial (important)
2. About the "Rest Area" (important)
3. Q&A
___________________________________________________________________________________________________________________________________________________________________ 

___________________________________________________________________________________________________________________________________________________________________                                                                                                                
1. Custom Mechanics - Tutorial (important)

*(For those who aren't fully familiar, or used to the normal SMW mechanics and gameplay)*
 
*Keep in mind that since it's a Mega Man-Styled gameplay, you will only be as small Mario along with it's hitboxes in the game. However, you can take
 multiple hits before you get eliminated. Also, you are able to freely shoot fireballs in a straight line at any time.*

		Dashing: Press the R button to dash. You can dash on the ground and in midair. You can also dash through 2-3 block wide gaps, and dashing in front
                         of small enemies will eliminate them.  

		Walljumping: You can also walljump. As you hold the D-Pad against the wall, press the B button to walljump.

		Healing HP/Extra Lives: Picking up health tanks that are hidden during the stages will fully refill the HP bar, store an additional health tank, 
                                        and grant you an extra life. Using stored health tanks will only heal HP.

 * Feel free to try out these custom mechanics in-game. *

___________________________________________________________________________________________________________________________________________________________________

2. About the "Rest Area" (important)

		In the game, there is a "Rest Area" marked by an "i" icon. That is where you can pick up only health tanks and
		proceed to the next part of the game after you've completed six stages in any order.
___________________________________________________________________________________________________________________________________________________________________

3. Q&A

Q: Why did it take so long to release this?
	A: Yes, i'll admit that it took a while to come out from the 2020 demo to the 2024 final release. It's just that life happened with more responsibilites, 
	   therefore it was hard to continue working on it as i've been on-and-off on it's development. 

Q: Are there any differences from the 2020 demo to the 2024 final version?
	A: There are various things that are different from the demo to the final release like the name change of the hack, slight level design edits from 
	   the existing stages in the demo, "STATION" stage now named "GENESIS", Graphical edits, and the Orbital stage had been omitted (for now) as 
           many people did not like that stage and plus I couldn't work with it so far (just to name a few). 

Q: Why did I make this ROM hack? 
	A: I just like making things. I also had too much fun with Lunar Magic as well as streamers like Juzcook and Barbarian got me inspired.

Q: How come the gameplay and mechanics are similar to the Mega Man classic/X series?
	A: I like the gameplay of the Mega Man games. 

Q: Why is there so much blue in the game?
	A: Blue is my favorite color. There are other colors in the game also. 

Q: Why is it named Project_Bonestorm.Tar.gz?
	A: I'm super nerdy with computers and tech. Also, i'm got good at naming things but my friends like the name and so do I. 

Q: Why did you change the title?
	A: I started to not like the original name (as if Project_Bonestorm.tar.gz was any better from .exe//Project). In addition, a good dude named The_Bonestorm inspired me so
           therefore i personally had to include his name in the new one. 

Q: Will there be a sequel to this ROM Hack?
	A: So far, not really. I'll make a sequel when I feel like it and it's pretty unlikely that'll ever happen.
	   I want to focus on ASM projects when this hack comes out. 

