Peach's Challenging Quiz And Easy Kaizoes!

I made special things:
0-50 rounds platformed Door Door NES.
Losing a life play Yoshi's island 1995 Boss intro.