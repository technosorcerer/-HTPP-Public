Difficulty: Beginner

Levels:
- Vanilla: 003
- Kaizo: 001 + 025-064

Preamble:
Due to a fact that I used a "BaseROM" that doesnt get support anymore 
since early 2019, there are sadly some things that I couldn't include
because of compatibility issues, like, for example, the "No Powerup/
Down Animation" Patch. I still tried to include as many QoL Patches
as possible, since these are key for an up-to-date SMW Level.



About my Level of Choice:
I don't want spoil much about my Level selection, but it might 
already be clear by telling you, that it is inspired by one
particular Level of the previous contest.
The "Gimmick" will be a secret aswell, but you'll quickly
figure out what it's about!

I kept the setups intentionally easier and possibly even 
cheeseable due to the sheer amount of different new mechanics 
and I wanted to create a highly variable but still fun experience.
There are also some bugs that I have absolutely no control over. 
I am pretty sure things would quickly get frustrating otherwise.

All of the Graphics (except for the Powerups/Mario Sprites/Projectiles)
are mostly Vanilla Graphics with minor Adjustments and Map16 Edits 
or some "custom additions" made by me. Since I needed so many diffierent 
themes, I still wanted to keep the experience as close to Vanilla as 
possible, since you should still have the "Vanilla Feel" (even tho 
this probably won't be the case since I might have overdone these 
"a little"). The Resemblance should be fine nevertheless, since there 
is not much to be resembled (again, some foreshadowing~). 

Keep in mind, that I only introduce some mechanics once. 
For example, throwing Projectiles upwards will work in almost any
situation, even if it's not introduced in the specific section.
There will be enough space to try things out, so play around a little 
and explore before rushing through the Level!

Also, I hope I never come up with a dumb idea like this again, this
took waaaaaay too much time, I will for sure release this as my first 
official hack xD
Danke Merk... uhh, Saphros!



Shoutouts to:
- LX5 who provided all the ressources on GitHub and made
  this Level possible.
- Ahrion who helped me with the Music Insertion for this creation.
- My Friends, that helped me with some of the Music Choices.
- H3nt4ik4m3n, FreestyleGX and CroNo486 for playtesting.
- Flio, because he made some Extra Rooms for this, which are 
  totally optional, and become accessable after you have 
  beaten the actual submission. (These will be in the final Hack 
  when I upload it to SMWCentral)
- The Judges, because they will spend a lot of time for this
  and all the other levels (but especially this one).
- The Community, cause it makes cool contests like this
  possible. ♥