Thank you for downloading my rom hack "Super Mario in Yoshi's Island." I've been spending most of my time organizing this hack for quite some time, and it's still not finished. I give thanks and kudos to the members of SMWCentral.net for assembling everything to make this possible. I made this as a homage to the developers of "Super Mario World 2: Yoshi's IslandTM" for the SNES. If you would like to contribute to this project please send me a PM on SMWCentral.net because I would like to make this a collaboration project one day and put the SNES to the limits, just like the developers of Yoshi's Island. Also please don't release any of my graphics that I have made from this hack unless you get promission from me. It was a lot of work to put down. Anywho I'm going to list some credits and glitches that I've experienced from my last play through:

Credits:
Sonniku for sprites
edit1754 for sprites
imamelia for sprites
smkdan for sprites
Nimono for sprites
Rykon-V73 for GFX
Anas for tilesets and GFX
MarioFanGamer for tilesets, GFX, and sprites
S.R.H. for tilesets and GFX
Natsuz2 for tilesets and GFX
Ayami for tilesets and GFX
Luigi-San for tilesets and GFX
cheat-master30 for tilesets and GFX
Mogu94 for tilesets and GFX
Hauashi Neru for tilesets and GFX
Cars4carpeople1 for tilesets and GFX
Hobz for tilesets and GFX
Keikonium and Metaknight for tilesets and GFX
and the original graphic designers of YI
(If I'm forgetting someone, please pm me :)

Glitches:
- Piranha plants when hit give off garbage gfx - it's from inserting sprites too many times is my guess why that happens.
- 1-4 Cape spinning Koopa Troopas crashes the game
- 1-5 A room is missing tiles behing the dooe.
- 2-2 The locked door leads to a soft lock bonus game
- 2-7 Tap-tap boss doesn't have hit collision for some reason