-------------SPANISH/ESPAÑOL------------

Muchas gracias por descargar The adventures end (las aventuras terminan), secuela directa de mi primer hack "Adventures Begin" la cual tendrá futura actualización y corrección de bugs, disfruta de este DEMO con su historia continua del anterior juego estoy abierto a cooperaciones para terminar el hack, porfavor no dudes en enviar un PM a SMWCENTRAL.

tu amigo YUTUZ....

-------------ENGLISH/INGLÉS-------------

Thank you very much for downloading The adventures end, direct sequel of my first hack "Adventures Begin" which will have future update and bug fixes, enjoy this DEMO with its continuing story of the previous game I am open to cooperations to finish the hack, please feel free to send a PM to SMWCENTRAL.

your friend YUTUZ....

---------AGRADECIMIENTOS ESPECIALES / SPECIAL VERY THANKS------------
-Mariofangamer
-KevinM
-GreenHammerBro
-MathOnNapkins
-kaizoman666
-FusoYa