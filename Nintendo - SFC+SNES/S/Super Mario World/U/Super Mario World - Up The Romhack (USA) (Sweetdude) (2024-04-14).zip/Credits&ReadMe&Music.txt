Pro Tips:
There is a hidden moon in the game, it's really hard to find so good luck!
You can save on the OW by pressing Select!
Midways are saved automatically on grab. (Unless you're on Super NT without SD2SNES/FXPakPro)
2 Player is most optimal for Speedruns!

Socials:
Twitch.tv/Sweetdude_ (I stream sometimes)
youtube.com/SweetDude (I upload sometimes)
patreon.com/Sweetdude (Just if you want to donate to me for whatever reason, don't feel obligated to!)
Discord: sweetdude (Feel free to DM me if you want any of the ASM/music in the game, I'm willing to share it all so long as I have the permission to!) 

Music:

Only Up From Here (Part 1)
Super Mario Bros. 3 - PLUMBING TO THE X-TREME!!! ~ Athletic / Overworld 2 (Remix) - Hooded Edge
https://www.smwcentral.net/?p=section&a=details&id=34046

Only Up From Here (Part 2)
Super Mario Land - High in the Sky ~ Ending Theme (Remix) - Hooded Edge
https://www.smwcentral.net/?p=section&a=details&id=26682

Only Up From Here (Part 3)
Super Mario Land - Oh, Daisy! (Arrangement) - MoxieCat
https://www.smwcentral.net/?p=section&a=details&id=32622

Quick Picker Uppers (Part 1)
Kirby's Adventure - Cute 'n Bouncy ~ Yogurt Yard (Remix) - Hooded Edge
https://www.smwcentral.net/?p=section&a=details&id=27595

Quick Picker Uppers (Kamek)
Super Mario Party - Kamek - Zavok
https://www.smwcentral.net/?p=section&a=details&id=20150

Quick Picker Uppers (Part 2)
Kirby Super Star - Hail to the King! ~ King Dedede (Remix) - Hooded Edge
https://www.smwcentral.net/?p=section&a=details&id=32034

Case of the Uppies (Part 1)
Sonic 3D Blast (Genesis) - Le Epic Bonus Music ~ Special Stage (Remix) - Hooded Edge
https://www.smwcentral.net/?p=section&a=details&id=31016

Case of the Uppies (Part 2)
DuckTales - Journey To The Very End ~ The Moon (Remix) - Hooded Edge
https://www.smwcentral.net/?p=section&a=details&id=31049

Drivin Me Up a Wall (Part 1)
SMW Central Production 2 - Be the Hero - Dark Mario Bros, Moose, Ultima
https://www.smwcentral.net/?p=section&a=details&id=30732

Drivin Me Up a Wall (Part 2)
Gyakuten Kenji 2 - Pursuit ~ Wanting to Find out the Truth - Ultima
https://www.smwcentral.net/?p=section&a=details&id=37447

Gonna Twist You Up (Part 1)
Sonic 3 & Knuckles - Fleet of the Gods ~ Flying Battery Zone Act 1 (Hakurei-Mix) - Hooded Edge
https://www.smwcentral.net/?p=section&a=details&id=28973

Gonna Twist You Up (Part 2)
Sonic The Hedgehog 4: Episode I - The Ocean That Brightens ~ Splash Hill Zone Act 1 (Remix) - Hooded Edge
https://www.smwcentral.net/?p=section&a=details&id=28109

Gonna Twist You Up (Part 3)
Tetris Attack - Staff Roll - Milon Luxy
https://www.smwcentral.net/?p=section&a=details&id=26181

Looking Up a Barrel (Part 1)
Donkey Kong Country 2: Diddy's Kong Quest - Snakey Chantey - Kevin
https://www.smwcentral.net/?p=section&a=details&id=28889

Looking Up a Barrel (Part 2)
Donkey Kong Country - The Golden Swing ~ Bonus Room Blitz (Remix) - Hooded Edge
https://www.smwcentral.net/?p=section&a=details&id=29603

Looking Up a Barrel (Part 3)
Donkey Kong Country - The Credits Concerto - HaruMKT
https://www.smwcentral.net/?p=section&a=details&id=8338

House Up In The Sky
Smart Ball - Green Plains - Jakeapus
https://www.smwcentral.net/?p=section&a=details&id=35688

Quadruple Castle (Part 1)
Link: The Faces Of Evil - DO THE DUCK WALK!! ~ Firestone Lake (Remix) - Hooded Edge
https://www.smwcentral.net/?p=section&a=details&id=35535

Quadruple Castle (Part 2)
Undertale - Satanic Bakery Sale ~ Spider Dance (Remix) - Hooded Edge
https://www.smwcentral.net/?p=section&a=details&id=31626

Quadruple Castle (Part 3)
Kirby Super Star Ultra - Vengeance, The Mask's Awakening ~ Masked Dedede (Remix) - Hooded Edge
https://www.smwcentral.net/?p=section&a=details&id=33877

Quadruple Castle (Part 4)
Mega Man V - OH SHIT!!! NOT THE GODDAMN SUN!!! ☀️ ~ Sunstar (Remix) - Hooded Edge
https://www.smwcentral.net/?p=section&a=details&id=34382

Credits
Mario Kart 64 - Bright as the Night ~ Rainbow Road (Remix) - Hooded Edge
https://www.smwcentral.net/?p=section&a=details&id=25915

Title Screen
Bomberman 2 (DS) - Multiplayer Lobby - Teows
https://www.smwcentral.net/?p=section&a=details&id=25277

Goal
SimCity (SNES) - Congratulations - MercuryPenny
https://www.smwcentral.net/?p=section&a=details&id=34020

Helping me with ASM Problems:
Brakkie
SMWCentral ASM Channel
Fernap

Testing:
Brakkie
TheVoipah
FirstNameButt
Lizard
OnlySpaghettiCode
SuperMeatBro

Poetry:
Falling Up - Shel Silverstein (Inspiration)
Up Up Up - Rosalie Franzese (Inspiration)
Only Up Ending Sequence - SCKR Games (Direct Quote)
Stand Up! - Martin Luther King JR (Direct Quote)

ASM:

Erik
Carol
Kevin
lx5
imamelia
Donut
Thomas
ShadowMistressYuko
JamesD28
Brakkie
Superyoshi
HammerBrother
Morsel
xhsdf
Fernap
RussianMan
edit1754
smkdan
Multibella
Koopster
RHR Baserom

Graphics:
yno14jax
imamelia
SMW_Hacker17
Anas
pieguy1372
AmperSam
Black Sabbath
Anorakun
Falconpunch
Gamma V
Marioman
Segment1Zone2
Roberto zampari
Ralshi02
edit1754
NopeContest
Ayami
mathie