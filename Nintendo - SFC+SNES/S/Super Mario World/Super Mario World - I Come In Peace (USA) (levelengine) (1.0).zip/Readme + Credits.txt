NOTE: As you complete levels, check marks appear in the bottom right corner of the main overworld map. If you've gotten a 100% SRAM file, there should be 22 check marks in all (20 normal exits + 2 secret).

MUSIC:
ActRaiser: Northwall - S.N.N.
Dreamer - Lui37
Forest (Dark Ambience) - RednGreen
Forest Reggae - ThinkOneMoreTime
Dark Side of the Kingdom Water Theme - Q-bee/Blind Devil
Dark Side of the Kingdom Spirit's Lair - Q-bee/Blind Devil
Dark Side of the Kingdom Heaven Clouds - Egadd
DKC Aquatic Ambience - Slash Man
Slippery Subterranean - Jimmy52905
Secret of Evermore: Ivor Tower Dog Maze - S.N.N.
FF2j: Pandemonium Castle - Davros
Kid Dracula Stage 1 - Sinc-X

BLOCKS:
key teleport - smkdan
Conveyor Blocks - Sayuri
Framal blocks - Sind

SPRITES:
Pendulum stuff - Alcaro
Vertical Scroll - Jimmy52905
Venus Fire Traps / sideways piranhas / sideways thwomps / Pansers - mikeyk
Custom Sprite shooter - Davros, (Magus, XM, mikeyk)
cave-in blocks - yoshicookiezeus
Ice Brothers - NamelessProtagonist