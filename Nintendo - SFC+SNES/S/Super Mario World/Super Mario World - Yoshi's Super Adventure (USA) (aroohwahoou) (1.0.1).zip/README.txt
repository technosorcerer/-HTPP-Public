==========================
= YOSHIS SUPER ADVENTURE =
=         by aroohwahoou =
==========================

==============================================================================
=   To play this hack, you need an emulator capable of running games that    =
=   use the SA-1 enhancement chip, such as Snes9x or Mesen.                  =
=   Do not use ZSNES. It's not 2005.                                         =
==============================================================================

Thanks for downloading my hack! This is my first ever SMW hack, and I've been
working on it on and off since 2021. During that time, I basically taught
myself pixel art, and changed the hack's art style several different times.

Hack was tested and works correctly on original hardware + CRT.

Included is a collage of some (but not all) of the artwork I made for a
scrapped instruction manual.

==============================================================================

TIPS:

Hold L + R when starting or continuing a game to play as a blue Yoshi.

To throw an object you're holding, press X/Y again, rather than just letting
go of X/Y. (If you accidentally let go of X/Y, and don't want to throw it, you
can pause, start holding X/Y, then unpause.)

Hold X/Y when moving on the overworld map to walk faster.
Press L + R to replay a fortress you've beaten.

When bouncing off a pink mushroom platform, hold B/A to bounce higher. Holding
A will cause you to spinjump, and holding B will make you stop spinning.

Press UP to talk to NPCs.

==============================================================================

CHANGE LOG:

v1.0.1 (2025.01.25)
- Courses without Yoshi Coins no longer display outlines for them on the HUD
- Final boss HP reduced 7 -> 5
- Adjusted difficulty of S-7
- Adjusted difficulty of S-*
- Lightened the shading on the score sprites
- Repositioned the numbers on level panels by one pixel
- Made the ending of the Switch Palaces look a bit nicer
- Edited some text
- Updated credits to support lowercase letters, update changed usernames, and be shorter
- Credits are now viewable as a text file

Fixes:
- Fixed potential softlock in the Red Switch Palace
- Sleepy Goombas now properly animate in S-3
- Updated the "1" level panels to be consistent with the rest of the hack's font
- Fixed minor cut-off when 3-4 is first revealed (as well as it initially using an old design for the "4")
- Fixed minor palette issue on the goal castle in 1-1


v1.0.0 (2024.12.24)
- Initial release