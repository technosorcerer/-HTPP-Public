SMOKED FISH AND CABBAGE 2
by xMANGRAVYx

28 exits
Kaizo Beginner-Intermediate difficulty

This romhack is created to test the player's skill and reflexes. It presents challenges difficult enough
that a standard player may struggle, but indicators throughout are in place to help guide you to the goal.
Pace is the trick in most instances! This hack makes use of some more complicated tech that may be unfamiliar to 
the casual player- blue coins are in place to indicate spin jumps and green coins indicate item throws (usually shells).
Color palettes and graphic choices were carefully picked to match the setting and create a tone for each level. Every
level's soundtrack was also carefully picked in an effort to create a satisfying gameplay loop as the player grinds 
each of the 28 courses. The map is comprised of several different zones strung together to feel like a complete world.
Levels do not have a difficulty curve as there are plenty of 'palette cleansers' throughout. This design choice was 
decided to give the player a chance to breathe and continue progressing without wanting to destroy their controller in 
frustration after a lengthy grind.

Each zone has it's own unique graphic style and challenge set:

RETRO ZONE
-graphics and palettes picked to remind the player of earlier Mario games/Nintendo consoles
-moderate difficulty
-some trickier sections in the second half of the zone

CITY ZONE
-inspired by the 'Checkpoint City' level from the first Smoked Fish and Cabbage (excluding the checkpoint gimmick)
-each level takes place during a different time and place in the city
-final level in the zone requires quick reflexes and accurate player placement
-DON'T LOOK DOWN!!

LAKE ZONE
-any fan of the TMNT NES game with understand the concept right away: FEAR THE WEEDS
-controlled swimming is recommended/encouraged

FOREST ZONE
-fast paced/precision based platforming
-more emphasis on shell jump accuracy

CAVE ZONE
-simple/smooth platforming mixed in with some moderate tech
-speed and accuracy is necessary

BASIC ZONE
-spin jumps and shell tech
-quick-paced platform rides -MOVE IT OR LOSE IT!!

CHEESE ZONE
-course difficulty is noticably steeper than most earlier levels
-fast-paced platforming
-shell accuracy required
-the level 'Cross Pollination' has 4 hidden rooms... can you find them all?

GLACIER ZONE
-slippery ground makes for some tough platforming
-level design is fairly difficult from here
-kaizo blocks indicated throughout

MEAT ZONE
-these last two levels are HARD
-follow the coin indicators so everything spawns correctly
-the final level is a true test of your patience and endurance- GOOD LUCK!!

This romhack is a sequel to the original Smoked Fish and Cabbage. It is considerably more ambitious than the
original in both design, graphics, effects, etc. I hope you enjoy and thanks for playing!!