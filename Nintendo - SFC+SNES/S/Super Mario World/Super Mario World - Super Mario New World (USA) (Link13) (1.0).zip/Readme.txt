~~~~~~~~~~~~~~~~~~~~~~
|	Super	     |
|     Mario New	     |	
|	WorldTM	     |
|		     |
|   by Link13 2024   |
~~~~~~~~~~~~~~~~~~~~~~
Thanks for downloading and taking the time to read the readme! :3

Introduction: Bowser trapped the Yoshi's behind the switch palaces
and the Mario Brothers have to go save them one by one AND THE PRINCESS!

Hack created by Link13 and all thanks to whom have been part of it are in the credits scene 2.

Purpose: I wanted to use everything provided for the rom hack and making the Super Mario World
experience better in many possible ways.

Big thanks to LX5 and their powerups for making this hack even better.

Enjoy!

(7/20/2024)v1.0 - Main Release!