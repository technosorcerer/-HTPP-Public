Thanks so much for choosing to play my hack! It means so much to me! One of my favorite streamers, thabeast721, said someone should make a beginner Kaizo consistency hack.
Well, here it is! I hope you have as much fun as I had making this! This hack is pure vanilla! There are some QOL patches to make the hack more enjoyable. Other than that,
there are no major patches. No cape turn around patch! Thanks to all the help from the SMWC community, and to my play testers! Without any of your help I don't think this
hack would ever gotten finished. You all have taught me so much about Lunar Magic, a tiny bit of coding, and so much more! You are all MVPs! Thanks so much!

This is the final version of my first hack! Some major changes happened in this version. After making the first version of my hack, I started to create another hack (which is
no longer being worked on for personal reasons). During the start of the second hack, I got to become better at using Lunar Magic. I took a lot of your feedback to make this
final version of my first hack even better! Without your feedback, I wouldn't have pushed myself to become even better when using Lunar Magic. This final version took a lot
longer than I originally anticipated. The base ROM I used for this hack has a lot of palette issues. I ran into that problem A LOT! With perseverance I managed to tackle that
problem. I'm no longer going to be touching this hack again. I also may or may not create another hack again. I wanted to contribute to the SMW community in some fashion. So,
I thought I'd make a hack. I hope you find the changes I made to be for the good than for the worse. Thanks again for your support! Keep on playing some amazing SMW hacks!

I'm also including a track list of all the songs and SFX effects you'll be hearing in my hack. I tried to choose music based on the theme for each level. However, that
sometimes did not go as planned. I still think I chose some great music for my hack!

Once again, I thank you so much for playing my hack! It means the world to me! Good luck and have fun! This hack is meant to push you as a Kaizo player!

Track list:
1.  Super Mario 64 - Let's a Go SFX
2.  Super Mario 64 - File Select
3.  SMW Central Production 2 - Innocent Beginnings
4.  The 7th VLDC - Grass and Forest Map (Yoshi's Island Submap)
5.  Sword of Mana - Running Towards the Futue
6.  The 7th VLDC - Here We Go (Remix)
7.  Super Mario Bros. - Course Clear (Alternative) [Goal Tape Level Clear]
8.  Super Mario World 2: Yoshi's Island - Flower Garden (Bowser Strikes Back Remix)
9.  Yoshi's Safari - Grass Land
10. Duck Life 4 - Flying Training Theme
11. Terranigma - Flying to the Sky
12. Metroid - Samus Fanfare (Goal Sphere/Orb Level Clear)  
13. Mario & Luigi: Partners in Time - Yoshi Mountain
14. Super Mario Bros. Wonder - Pipe Rock Plateau
15. Ikachan - Battle Inside Water
16. The 7th VLDC - Mountain
17. Asterix & Obelix - Map (Main Overworld)
18. Super Mario Bros. 3 - Giant_Disco.mp3 ~ Giant Land (Remix)
19. Teenage Mutant Ninja Turtles IV: Turtles in Time - Technodrome ~ Let's Kick Shell
20. Mega Man IV: Wily's Disco Station ~ Dr. Wily's Station (Remix)
21. Alcahest - Mountain Trail
22. 100% Orange Juice - Seagull's Theme
23. New Ghostbusters II - Court
24. Mega Man 4 - Sky of Danger ~ Dr. Cossack's Citadel 3 & 4 (Remix)
25. Tsuri Bit - Blue Ocean Fishing Cruise
26. The Legend of Zelda: A Link to the Past - Dungeon of Shadows
27. Mario Kart: Super Circuit - Bowser Castle
28. Romancing SaGa 3 - Julian's Theme
29. Castlevania III: Dracula's Curse - Aquarius
30. New Super Mario Bros. - Mushroom Waltz
31. Sean Evans - Empyrean Emerald Zone (Past)
32. The 7th VLDC - Castle
33. Super Mario Galaxy - Buoy Base Galaxy
34. Final Fantasy: Mystic Quest - Fossil Labyrinth (Valley of Bowser Submap)
35. Super Mario Bros. - Castle (Remix)
36. Spindizzy II - Ballrace
37. SMW Castle (7/8)
38. SMW Central Production 2 - Fantastic Fanfare
39. II Maniero Spettrale - Forest
40. The Ninja Warriors - Final Stage
41. Super Mario 3D World - World Star (Special World Submap)
42. The Thing - Main Theme
43. Spelunky - Mines B
44. Radical Dreamers - Sneaking Around
45. Super Mario RPG: Legend of the Seven Stars - Welcome to Booster Tower
46. AHH Real Monsters-Stage Intro 1
47. Snowboard Kids - Night Highway
48. Radical Dreamers - Snakebone Mansion
49. Pilotwings - Hang Glider
50. Earthbound - Caverns of Winter
51. The 8th VLDC - Castle 2
52. New Super Mario Bros. Wii - Beach (Bonus) [Used in the first version of my hack]