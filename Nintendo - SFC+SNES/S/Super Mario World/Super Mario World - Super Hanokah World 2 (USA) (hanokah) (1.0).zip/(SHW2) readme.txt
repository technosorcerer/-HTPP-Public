Super Hanokah World 2 - Version 1.0
2023-2024 hanokah. (I wanna say all rights reserved, but the reservation cost like 200$)

How to play:
1. patch unmodified SMW rom
2. run in emulator
3. enjoy!

KNOWN BUGS/ISSUES as of version 1.0:

-Some of the piranha plants in ToH2 dont spawn
-Peach pallete is messed up in bowser fight, i've looked in every pallete and every graphics file, i'm still not sure how it's happening. Guess that means no SMWcentral release

CREDITS (most of these users can be found on smwcentral.net, also i may have missed a few):

-level design-

hanokah - well, of course: i made the hack, although i got some help with the bonus level:

segment1zone2 - i reused the defualt level for the metroid norfair tilemap he made in

Mica, Murphmario - bonus level stuff as well, counts as gfx too

--ExGFX--

MM102 - Enhanced Outlined Mario (player)

Ralshi02 - SMM2 SMW Cloud gfx in world 6

Ayami - Cosmos cosmic adventure DOS font (replaced original font)

Heitor Porfiro, Kestertank, and Kopejo - New Global Blocks

ModernKiwi, SuperSledgeBro, edgar - Super Mario All-Stars: Super Mario Bros. Expanded Snow (World 7 levels)

blackace - Peach's Castle (World 1 Overworld)

yno14jax - Super Mario All-Stars: Super Mario Bros. 3 - Hills and Platforms (W3 Castle)

Gamma V - Super Mario World - Desert (W2 Main), Mechanical BG (W6 fort)

AppleBoy54321 - Koopatrons and Galoombots (used in W6 fort)

G-Rex Studio, zAce08xZ - Various Super Mario World Enemies In Winter Style (used in most of W7)

Idunno - SMW styled shy guy (used in most of W4)

LinkstormZ, Rykon-V73 - SMAS SMB3 styled mountains (W5-4)


--MUSIC--

nipcen - remix of 01 Miss.txt

Wakana - piano man arrangement for game over

LadiesMan217 - yoshis island athletic theme (World 1 - Athletic), SMB3 ice land SMAS (World 7), YI castle/fort theme (World 8 Ghost House)

Jimmy - YI flower garden arrangement from bowser strikes back (World 1 - Main)

Overcrow - SM64 Dire, Dire Docks (Water levels)

JX - MMX4 boss theme w/ MMX2 samples (Boss fights except for worlds 3 and 6), Ketsui no remorse w/ MMX2 samples (World 8), Metal slug 3 pyramid in MMX2 style (World 2 - Main), MM3 Needle Man in MMX3 Style (World 3 - Main/Athletic), Touhou 7 spiritual domination who done it in MMX3 style (World 7 - Main)

Lexou - M&L-PiT Dark Dungeons (World 1 - Underground / World 3 - Puzzle / World 7 - Level 4)

Samantha - Bio Metal Dark Clouds (Castle theme)

Kusamochi - Mega Man Zero intro stage (Pre-W1 Intro level)

Segment1Zone2 - Skate or Die NES skate shop (title), MMX2 Volcanos Fury (World 8 - Main)

Ruberjig - over the forest (World 4)

(not in .txt file) - Mega Man 1 Stage Select (World 1)

Kevin - MMX Stage Select 1 (World 2)

Anas - NSMB W7 (World 6)

Ahrion - Soul Blazer Underground Castle (World 3)

(not in the file for some reason) - M&L:PiT Yoshi mountain (World 5)

(not in file) - you suffer (30 IntroScreen.txt)

Newerteam - NewerSMBDS Cloudbolt Chasm w/ YI samples (World 6 Level 4)

maxodex - MMX Boomer Kuwanger (World 6 - Main/Athletic)

Daizo dee von - pumped up on detached cliffs (unused, but its become a running joke so

brickblock369 - Fortress of Artifical Fabrication by KungFuFurby (World 6 Fort)

Bak Sangwoo - MMX6 Hi-Max w/ MMX2 samples (Worlds 3 and 6 boss fights, W8 ghost house boss)

Tamaki - MMX Sting Chameleon (World 4 - Athletic)

KevinM - SMM2 SMW Forest early version (World 4 - Main)

DanTheVP - rise of the robots The Loader (Fortress theme)

Iguy - guns n roses you could be mine in MMX style (World 5 - Main)

AmperSam - Zool: ninja of the Nth dimension rave theme (World 3 Castle)