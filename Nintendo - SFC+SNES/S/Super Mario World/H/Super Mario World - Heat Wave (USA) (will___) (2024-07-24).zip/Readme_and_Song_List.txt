Heat Wave is an intermediate difficulty Kaizo hack that I have created over the past couple of years. It contains a mix of linear, fast-paced platforming as well as slower-paced sections with obstacles that can be completed in multiple ways.

Features:
	- Standard quality of life features (fast retry, save midways on overworld, bug fixes, etc.)
	- Custom music
	- Some chocolate mechanics, but nothing that alters Mario's physics or controls
	- No shell jumps or cape
	- Light indication, light trolls, and light lore
	- 19 exits: 17 required 'main' exits and 2 bonus post-credits exits

I'd like to thank everyone who decides to try this hack out. I hope you have fun.

-----------------------------------------------------------------------------------------------

SONG LIST below, in order of appearance (spacing out because it contains spoilers I guess)







































Title Screen: Last Bible III - Harry's Theme, ported by Kevin (https://www.smwcentral.net/?p=section&a=details&id=29254)
Intro Level: Pokémon Colosseum/XD: Gale of Darkness - Relic Forest, ported by icrawfish (https://www.smwcentral.net/?p=section&a=details&id=32507)
Beach Map: Trials of Mana - Splash Hop, ported by Kevin (https://www.smwcentral.net/?p=section&a=details&id=31312)
Yoshi's Greenhouse (outside): Flower Garden; from the Super Mario World 2: Yoshi's Island Soundtrack, ported by LadiesMan217, Lui, Vitor Vilela, and musicalman (https://www.smwcentral.net/?p=section&a=details&id=20485)
Yoshi's Greenhouse (inside): Mario Paint - Flyswatter ~ Level 2, ported by Kevin (https://www.smwcentral.net/?p=section&a=details&id=26799)
Pitch Dark: Last Bible III - Hill, ported by Kevin (https://www.smwcentral.net/?p=section&a=details&id=29244)
Level end: Donkey Kong Country - Bonus Win, ported by Kevin (https://www.smwcentral.net/?p=section&a=details&id=24063)
Cave Map: Super Mario Kart - Ghost Valley (Map Remix), ported by Dispace (https://www.smwcentral.net/?p=section&a=details&id=30233)
The Batacombs: Donkey Kong Land - Voices of the Temple, ported by Teows (https://www.smwcentral.net/?p=section&a=details&id=21876)
Cozy Cavern: Jazz Jackrabbit - Marbelara, ported by AmperSam (https://www.smwcentral.net/?p=section&a=details&id=28556)
Hang Loose: Super Mario Odyssey - Steam Gardens, ported by HaruMKT (https://www.smwcentral.net/?p=section&a=details&id=22622)
Shifting Sands (water sections): Donkey Kong Country 3: Dixie's Double Trouble! (GBA) - Water World, ported by HaruMKT (https://www.smwcentral.net/?p=section&a=details&id=10414)
Companion Ship (section 1): Donkey Kong Country 2: Diddy's Kong Quest - Lockjaw's Saga, ported by Slash Man (https://www.smwcentral.net/?p=section&a=details&id=22209)
Companion Ship (boss): Donkey Kong Country 2: Diddy's Kong Quest - Crocodile Cacophony, ported by sincx (https://www.smwcentral.net/?p=section&a=details&id=17199)
Forest Map: Pokémon Mystery Dungeon: Explorers of Sky - Southern Jungle, ported by Exodust (https://www.smwcentral.net/?p=section&a=details&id=21983)
Red Woods: Yooka-Laylee - Tropic Trials, ported by Wavee (https://www.smwcentral.net/?p=section&a=details&id=28252)
Hyperallergenic: Ribbit King - Lavatron 3, ported by musicalman (https://www.smwcentral.net/?p=section&a=details&id=19825)
Kill Mill (sections 1 and 2): Mega Man ZX - Green Grass Gradation (Mega Man X2 Style), ported by JX444444 (https://www.smwcentral.net/?p=section&a=details&id=26820)
Kill Mill (boss): Live A Live - Megalomania, ported by Tamaki (https://www.smwcentral.net/?p=section&a=details&id=20922)
Sky Map: Super Adventure Island - Blue Blue Moon, ported by Kevin (https://www.smwcentral.net/?p=section&a=details&id=27255)
Magic Tar Pits: Nausicaä of the Valley of the Wind - A Princess Who Loves Insects (Chrono Trigger Mix), ported by qantuum (https://www.smwcentral.net/?p=section&a=details&id=25499)
Numerical Disorder (sections 1 and 2): Mad Stalker (X68000) - Stage 5, ported by sincx (https://www.smwcentral.net/?p=section&a=details&id=11973)
Numerical Disorder (section 3): LED Storm (Amiga) - Title Screen, ported by brickblock369 (https://www.smwcentral.net/?p=section&a=details&id=26866)
Under Fire (sections 1 and 2): Dubmood, Zabutom & Blz - Chaos #1, ported by Ahrion (https://www.smwcentral.net/?p=section&a=details&id=30423)
Under Fire (boss): Dubmood - Paradox #2, ported by Ahrion (https://www.smwcentral.net/?p=section&a=details&id=30525)
Dark Forest Map: Ghouls 'n Ghosts (Amiga) - Stage 3 (Baron Rankle's Tower), ported by brickblock369 (https://www.smwcentral.net/?p=section&a=details&id=26811)
Dour Flowers (sections 1 and 2): Chrono Trigger - Secret of the Forest, ported by RednGreen (https://www.smwcentral.net/?p=section&a=details&id=20504)
Dour Flowers (section 3): Last Bible III - Sodom, ported by Kevin (https://www.smwcentral.net/?p=section&a=details&id=29276)
The Entourage: Donkey Kong Country 2: Diddy's Kong Quest - Forest Interlude, ported by Slash Man (https://www.smwcentral.net/?p=section&a=details&id=7111)
Phantom Pain (outside): The Flintstones - Unused Song 2, ported by RednGreen (https://www.smwcentral.net/?p=section&a=details&id=15112)
Phantom Pain (inside): Waterworld - Shop, ported by Kevin (https://www.smwcentral.net/?p=section&a=details&id=22441)
Fire Map: Brain Lord - Site of Civilization, ported by SiameseTwins (https://www.smwcentral.net/?p=section&a=details&id=31967)
Boiling Point: Skyroads - Road 5 (Oktalyzer), ported by Mirrordrill (https://www.smwcentral.net/?p=section&a=details&id=33365)
Heat Death (section 1): Tengai Makyou Zero - To Hell, ported by Ahrion (https://www.smwcentral.net/?p=section&a=details&id=35424) 
Heat Death (boss sections): Thunder Force IV - Metal Squad, ported by Ultima (https://www.smwcentral.net/?p=section&a=details&id=34331)
Credits: Sonic CD (JP/EU) - Metallic Madness Zone (Good Future), ported by Slash Man (https://www.smwcentral.net/?p=section&a=details&id=8014)
Burnout (blue section): xaimus - mitotic dance, ported by sincx (https://www.smwcentral.net/?p=section&a=details&id=21848)
Burnout (green section): Chromag - Rain, ported by Kevin (https://www.smwcentral.net/?p=section&a=details&id=37498)
Burnout (yellow section): Bomberman Hero - Redial, ported by Dippy (https://www.smwcentral.net/?p=section&a=details&id=19126)
Burnout (gray section): Azazel - Polta Taivas, ported by Ahrion (https://www.smwcentral.net/?p=section&a=details&id=30339)
Burnout (red section): Last Bible III - Underworld Forest, ported by Kevin (https://www.smwcentral.net/?p=section&a=details&id=29281)
