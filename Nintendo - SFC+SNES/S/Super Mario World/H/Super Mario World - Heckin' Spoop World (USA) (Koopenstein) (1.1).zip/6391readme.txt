
ROM Hack: Heckin� Spoop World (version 1.1)
Created By: Koopenstein.  I also go by my streaming usernames, DanJer and YetoSoup.
o https://fb.gg/danjergames
o https://twitch.tv/YetoSoup
First and foremost, thank you very much for playing my hack!  The goal was to be, well, real spooky.  I hope you�ll enjoy it.  Some general notes: there are some wonky colors, backgrounds, and environmental interactions.  I was going for a �dream� (think Mario 2) type scenario, so these are intentional (and kosher with the community guidelines).  This hack is meant to be fun and involves platforming and light kaizo.  Beginners will find it challenging, but it is easily mastered with practice. ??
A special thanks goes out to the SMW Central community (with a particular nod to Snifit for graphics utilized for �The Halloween Party�, and Green Jerry for graphics sprinkled throughout the hack): you guys made this possible.  All graphics, music, sprites, etc., came from the community, with a personal touch here and there.  There are far too many people to thank here, so here�s your overall shoutout: YOU GUYS ROCK!
Thanks again for playing, and I�ll catch you on the next level!  Happy Halloween!
- Koopenstein.  10.01.2022.

