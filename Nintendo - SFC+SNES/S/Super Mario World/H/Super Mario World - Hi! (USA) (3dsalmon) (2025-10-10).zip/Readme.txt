This romhack is called "Hi!"


This is my first hack. It has:

- Fast paced, challenging platforming
- Exactly six kaizo blocks (find them all!)
- a few trolls here and there (sorry! kinda)
- Some setups that may require some experimentation to solve 
- Levels built around both vanilla platforming and occasional ASM gimmicks (and one fairly challenging shell level)

You can view a full playthrough of the hack here: https://www.youtube.com/watch?v=f8KUu5fYIQQ

Huge thanks to the countless friends and people from different Discords and forums who helped me answer the seemingly constant stream of questions I had while making this, and an extra special thanks to the playtesters. 

If you play this, I hope from the bottom of my heart that you enjoy yourself, and even if you don't, you have my gratitude for trying it out.

P.S: I have chosen Master difficulty for this hack, but I made the overwhelming majority of it before "Master" difficulty existed, and its original intended difficultly was somewhere in the middle of the (old) "Expert" difficulty, so take that as you will. 