===========================
Chaotic Realm v1.22 - Fixed
===========================

==============
About the hack
==============


Chaotic Realm is a hack released in 2010 (or at least, v1.22 was) by anonimato, and is pretty compact, with 10 exits.
It was originally released in English.

You can find the original hack and author's comments at:
https://www.smwcentral.net/?p=section&a=details&id=9997
Please check it out if you want to know more about the hack itself.

This hack had custom music inserted with Romi's AddMusic, alongside a custom instrument table which was long enough to bleed into the echo buffer. This resulted in the music crashing the game before too long. An itemized list of issues fixed can be found further down in this readme.

==============
About our work
==============

We (by which I mean mainly Ryrir, Super Maks 64, and myself, This Eye o' Mine) basically take old SMW hacks that have issues relating to emulator compatibility, and fix them so these hacks will work properly on newer emulators and, hopefully, real hardware. Although this is unrelated to this particular hack, I'm also involved in translating Japanese hacks to English.

In our fixes of old hacks, we try as much as possible to preserve the way the original hack worked internally. For instance, hacks that used a custom music loading engine have not had this engine replaced, but simply had their assets edited so that they're no longer loaded in such a way that crashes the SNES, and had the N-SPC music engine that SMW uses patched to eliminate a couple of other sound bugs arising from the assumptions about hardware behavior based on ZSNES' inaccurate emulation. The result is that the hack will pretty much work and sound exactly as it would on ZSNES when played on something like BSNES or a real console (minus that emulator's terrible sound quality), and in some areas the music might incidentally even be a bit less glitchy than it used to be.

The above should be true as far as we can tell from testing (which was done on BSNES), and unless otherwise specified in the readme.

==================
About this release
==================

This is usually the part of the readme where I talk about optional ASM patches, but this hack did not have any elements that I felt warranted patching. The ZIP file contains this readme and the BPS patch. Just apply the BPS patch to a clean and headered USA SMW ROM and play!

Here's a list of what was fixed:
- Issues related to the use of Romi's AddMusic, mostly involving music data loaded into the echo buffer getting overwritten.
- Echo delay settings that were so high the resulting effect overwrote sample data in ARAM.
- Robotic music noises due to a bug in the N-SPC sound engine causing wrong sample data to be loaded when a sound effect finishes playing on a channel that is doing percussion. (Only really a noticable issue on BSNES or real hardware)
- Stuttering noises due to leftover echo data getting continually played back when the game isn't generating any new echo data.
- An issue in one level where HDMA writing to the layer 2 scroll setting register somehow caused the level's textbox contents to scroll along with the background.
	(This is only sort-of fixed. The effect is still noticable for a frame or two after the textbox is done drawing.)
	(If I ever find out exactly what causes it, I will release an update with a complete fix.)

We don't mind if you want to redistribute this patch. I mean who are we to talk?

=======
Credits
=======

Very little was done to the hack besides fixing compatibility issues, so not many people to credit here this time.

Of course, major thanks to anonimato, who made this hack in the first place.
I had nothing to do with this hack's creation; I only fixed it in the hope that more people will end up playing it.

Thanks to Super Maks 64 for pioneering the method of fixing broken AddMusic and helping me learn how this works.
Besides that, thanks to both him and Ryrir for their continued assistance in making this whole fixing stuff possible.

Finally, thanks to Pholtos for LPing this hack, which was the reason I decided to fix it in the first place.

- This Eye o' Mine
