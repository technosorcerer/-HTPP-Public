Hello! Thank you for downloading JDCGames collab - a community project made by members of our community. This collab contains 37 levels, 5 worlds and of course - plenty of secrets to reveal. 
The project itself has spanned 9 months, having started on August 11th, 2011. I think the project has come a long way since then, and I am finally glad to see it done. 

As always, please PM me (JDC) if you have any queries regarding this. If there are any bugs or errors, please also try and let me know so I can fix them ASAP.

Thank you for downloading! I hope you enjoy this collab. 
 