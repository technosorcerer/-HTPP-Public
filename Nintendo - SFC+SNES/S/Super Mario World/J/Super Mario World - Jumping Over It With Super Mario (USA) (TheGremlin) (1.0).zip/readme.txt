Jumping Over It with Super Mario is a "Getting Over It"-style experience. There's 3 levels
that you can play in any order, just beating any of the three means unlocking the
credits and beating the game:

jumping over it:
    the main attraction of the hack and the most challenging level. highly inspired by 
    classics such as Carl Is Such A Nice Guy and Ultra Slope Muncher. You climb a
	mountain and try to surmount the insurmountable. requires kaizo precision/knowledge
	and a lot of patience

9 hole challenge:
    a fun simple golfing challenge in super mario world. using the MOLF asm by
    dtothefourth, mario turns into a golfball! saves after every hole. can you stay
	under par?

notVANILLA SECRET 3:
	mario has gained the power of commitment: he is committed to every single jump
	and once he is in the air he is steadfast on keeping his trajectory. can you
	overcome a somewhat familiar seeming breezy sea of dolphins?

I hope you enjoy this hack! Just make sure to bring a lot of patience. Good Climbing!