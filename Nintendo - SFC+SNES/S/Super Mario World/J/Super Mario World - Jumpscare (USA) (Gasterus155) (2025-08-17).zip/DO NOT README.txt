If you read the description of this hack, that means you know what,s going on in this hack
but in case you didn,t:
This is a troll hack and kaizo at the same time
it foucses on the troll of hidden enemies that appear from unexpected places to kill the player......and at the same time it requier some kaizo experience and knowledg 
of some janks/glitches of original game
Although I later deviated from this goal.
anyway......after you knew what,s waitng you in this hack....I have to warn you that It contains a lot of things that most players hate
for example:
unexpacted deaths
some long levels that may take a long time to beat
blind jumps when player fall from high place without indicators
and some other things
.
if you are not ready for all of that...well......smwc have a lot of good and fun hacks that are better a lot than this hack......you can enjoy them instead
this hack isn,t for all people......it,s just for those very few people who don,t have a life and enjoying that kind of hacks (like me)
.
is there any other type of trolls except the hidden enemies? yes
.
you can always use start + select to leave any level.....press select during retry prompt to leave the level too
the game always auto save your progress anytime you back to overworld
game will not freez during retry prompt.....means that you can know what,s the thing that killed you......although this can spoile some trolls.....but isn,t matter
watch out those sections that looks like a preview for next level.....they don,t have checkpoint.......and always they have a troll that can make you trying agian from the beginning (or at least from the last checkpoint)
.......
that,s all
Good Luck