thank you so much for downloading my hack!
to play it, you'll need to get a clean rom of super mario world, and apply the included .bps patch to it with Floating IPS.

if you would like to share your thoughts, feel free to comment on the smw central page!
and if you happen to come across any bugs or issues, you can contact me via PM on smw central, sayurisrc on discord, or @amelia.cat on bluesky!

these memories are mine, but they are open to interpretation for anyone. i hope you enjoy this challenging glimpse into moments from my life that shaped who i am, and what i feel.

- amy (sayuri)

~~~~~~changelog~~~~~~

v1.0 (January 15, 2026)
- initial release!

v1.01 (January 19, 2026)
- fixed two unintentional breaks in level 1
- fixed two unintentional breaks in level 2
- removed two grinders in the last half of level 3
- removed a sea urchin after the fourth checkpoint in level 5
- fixed an unintentional break at the very end of level 6
- fixed a minor softlock after level 10's third checkpoint by adding a way to die there
- fixed a break after the fourth checkpoint in level 10
- slightly reduced the difficulty of sections 1, 3 & 5 of level 12

~~~~~~credits (also in-game)~~~~~~

~~~~~Graphics~~~~~

Rykon-V73
cheat-master30
Dappertron
WonderfulWorld
StanTheMackiar
Gamma V
Hach
Carld
Anorakun
No Body the Dragon
E-man38
Kojimkj
ModernKiwi
SmithyCGN
Blizzard Buffalo
edgar
Roberto zampari
Wavee

~~~~~Music~~~~~

StayAtHomeStegosaurus
Teows
Wyatt
Misora
Kevin
Dzing
icrawfish
Ahrion
Fullcannon
bebn legg
Hooded Edge
sinseiga
Pinci
Maxodex

~~~~~Sprites~~~~~

Isikoro
Tattletale
Russian Man
Darolac
HammerBrother
MellyMellouange
Blind Devil
imamelia
NovaSquirrel
Ladida
Major Flare
Davros
Sonikku
dtothefourth
wye
Arinsu
Donut
Kaizoman
Iceguy
Telinc
algae5
MarioFanGamer

~~~~~Patches, Blocks, UberASM~~~~~

Underway
HammerBrother
Iceguy
dacin
Aika
HuFlungDu
Kevin
betalogic
wiiqwertyuiop
Squid Man
Alcaro
westslasher2

~~~~~Very Special Thanks~~~~~

v_input_output
junelinked