                                                     ======================================================
                                                     = JERRY'S AUTOWALKING ADVENTURE TO RESCUE HIS CHEESE =
                                                     ======================================================
                                                     Version 1.0.1                   Released on 23/11/2023

=========
= ABOUT =
=========
This hack is my first finished and released Kaizo hack.

I've never finished or released a Kaizo hack until now (other than 3 KLDC entries in 2016, 2017 and 2020), so I decided to make one, and actually finish and release it.

My first attempt at making a Kaizo hack dates back to 2016, called Kaizo Wario World. As the name implies, it had Wario as the playable character, and its first level was the one originally released as an entry for the 2016 KLDC, but with some changes like adding blocks that kills Yoshi to avoid cheese. I think I had added my 2017 KLDC entry to that hack as its second level as well, which was after the last post on that hack's thread on SMW Central. That hack was never finished.

In 2018, I started working on a second attempt at a Kaizo hack that had Wario as the playable character like the 2016 hack, and finished its first level. Said level had the same theme as my KLDC 2016 entry: a cherry blossom-themed level. That hack was never finished as well.

Then in early 2020, I started working on a third attempt at a Kaizo hack that had a similar title as the 2016 hack, except instead of Wario, the playable character was Jerry from the Tom and Jerry cartoons, so the title of that hack was Kaizo Jerry World. I had finished 4 or 5 levels for that hack (and one of them was my 2020 KLDC entry). I was planning to make around 10 exits for that hack, and was going to use Gamma V's graphics for the foregrounds and some backgrounds. Again, like both of the Wario hacks, that hack was never finished.

Now, in October 2023, I started working on this hack. Like the abandoned hack from 2020, it has Jerry as the playable character, but the graphics are mostly vanilla, but it does use some of Gamma V's graphics, which are the decorations in the beach level, and the background in the snow level.

==============
= CHANGE LOG =
==============
V1.0.1 (23/11/2023):
--------------------
* Made a minor change near the start of Tom's Castle to fix cheese.

V1.0 (23/11/2023):
------------------
* Changed the level order again.
 - Sticky Forest is now level 2 like in Beta 1.
 - Platform Blossom is now level 3.
 - Poison Shroom Beach is now level 4.
 - Snow and Ice is now level 5 like in Beta 1.
 - Motor Skills Cave is now level 6 like in Beta 1.
* Made a proper overworld.
* Added coins between the 2023 text on the title screen.
* Added new music for the overworld, the Tutorial Treehouse and the "The End" level.
* Added an invisible sprite killer box to the midway in Sticky Forest that kills the Bullet Bill that goes to the right if you respawn from the midway.
* Fixed a grammar error in the Tom's Castle message box.
* Applied the "No Silent Bullet Bill" patch.
* The boss no longer spits fireballs because they're slow and most of the time, they wouldn't be aimed at the player.
* Added HDMA gradient to the sublevel after beating the boss.

Beta 3 (22/11/2023):
--------------------
* Fixed an error in the overworld that prevented the player from moving past Snow and Ice due to forgetting to change the initial enabled directions after switching the level order.
* Minor adjustments to Sticky Forest to prevent cheese near the end.
* Applied the Rollover Fix patch (only the pipe fix part of the code due to this hack using the No Consecutive Score Awards patch) to fix the wrong warp glitch that happens if you were to die over 256 times in a single level.

Beta 2 (21/11/2023):
--------------------
* Changed level order:
 - Platform Blossom is now level 2.
 - Snow and Ice is now level 4.
 - Motor Skills Cave is now level 5.
 - Sticky Forest is now level 6.
* Made some adjustments to Sticky Forest.
* Fixed a typo on the Motor Skills Cave message box.
* Removed a duplicated Spiny that was placed on top of another one near the midpoint of Motor Skills Cave, which could cause a vanilla bug where the player would die.

Beta 1 (15/11/2023):
--------------------
* Initial beta release.

===========
= CREDITS =
===========
Graphics:
---------
Gamma V (Extra Tiles - Beach [Miscellaneous], Extra Tiles - Ice [Miscellaneous], Snowy Mountains [Background])
Green Jerry (Tom and Jerry - Jerry [Player])

Music:
------
Bak Sangwoo (Sonic the Hedgehog Spinball - Toxic Caves [Unsampled])
GoldPooka (Golden Axe - Sutakora, Sassa! [Unsampled])
Green Jerry (Pokémon Red/Blue/Yellow - Prof. Oak's Laboratory [Unsampled], Tom and Jerry - Main Theme [Unsampled], Tom and Jerry (SNES) - Jerry's Victory! [Unsampled])
gocha (Final Fantasy Legend II - Struggle to the Death [Unsampled])
Isikoro (MegaMari - Cirno's Stage [Unsampled])
Jimmy (Mega Man 9 - Opening 1 [Unsampled])
Kipernal (CUSTOM (SMW Central Production 2) - Innocent Beginnings [Unsampled])
Kitikuchan (Ganbare Goemon 2 (NES) - Chugoku, Hokkaido [Unsampled])
Kritter (CUSTOM - Island Ho! (Reboot) [Unsampled])
monkey03297 (Pocky & Rocky - Rocky's Message [Unsampled])
Moose (Alcahest - Panakeian Temple [Unsampled])
Samantha (Chrono Trigger - Singing Mountain [Unsampled])
Teows (CUSTOM (The 11th Vanilla Level Design Contest) - Mountain Map [Unsampled])
Torchkas (CUSTOM (SMW Central Production 2) - Innocent Beginnings [Unsampled])
VecchiaZim (CUSTOM - Happy Accidents [Unsampled])
Wakana (Castlevania III: Dracula's Curse - Mad Forest [Unsampled])
worldpeace (Siren (Alexander Brandon) - Snowfall [Unsampled])

Blocks:
-------
Alcaro (Teleport Block)
Ersanio (Icy Block)
JackTheSpades (Kill Muncher)
Mandew (Sticky Ceiling)
MarioE (Teleport Block)

Sprites:
--------
Darolac (Invisible Sprite Killer Box)
Iceguy (Ultimate Noob Sprite)
imamelia (Poison Mushroom)
Mandew (Invisible Sprite Killer Box)
Thomas (Poison Mushroom)
yoshicookiezeus (Random Shell Shooter)

Patches:
--------
Aika (Disable Bonus Stars)
Alcaro (Placeable Disco Shell)
anonimzwx (Fix HDMA Flickering)
ASMagician Maks (Message Chaining)
imamelia (Disable Bonus Stars)
JackTheSpades (Timer Disabler)
Kevin (Per Level "Mario Start!" Enable/Disable)
Koopster (No Consecutive Score Awards, Timer Disabler)
lolcats439 (Walljump/Note Block Glitch Fix)
Noobish Noobsicle (Rollover Fix, pipe fix only)
p4plus2 (One OR Two Players Only)
Ramp202 (No Silent Bullet Bills)

UberASM:
--------
Kevin (Retry System)
mathie (Automatic Walking)
RussianMan (Mid-air Jump Changer)

Tools:
------
Alcaro (Asar)
Atari2.0 (PIXI)
ExoticMatter (GradientTool)
FuSoYa (Lunar Magic)
JackTheSpades (PIXI)
Kipernal (AddmusicK)
p4plus2 (Gopher Popcorn Stew)
Tattletale (PIXI)
TheBiob (Gopher Popcorn Stew)
Vitor Vilela (UberASM Tool)

Beta Testers:
-------------
dubiousdinobot