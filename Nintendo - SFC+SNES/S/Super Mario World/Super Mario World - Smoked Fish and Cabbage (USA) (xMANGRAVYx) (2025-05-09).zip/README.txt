SMOKED FISH AND CABBAGE (v3.0)
by xMANGRAVYX
-Dedicated to the Loving Memory of Noah James-

7 exits
Standard Hard/Kaizo Beginner difficulty

This romhack was designed with accessibility in mind. My intention was to create a hack hard enough for beginners to grind, but easy enough a more skilled player could breeze through it. I kept the project small on purpose to not overwhelm myself during the learning process, and designed a small world with 7 levels. Each of the 7 levels has it's own unique theme, and the difficulty curves with progression. I carefully chose each soundtrack and template to reflect the tone of the level I was designing at the time. All levels were short enough I felt checkpoints weren't necessary.

NOTE:
After a few years of feedback and learning Lunar Magic I decided to revisit this old gem. This project was never meant to reinvent the wheel.. it's a project born of passion and the desire to learn something new. Unofficially dubbed 'NEW Smoked Fish and Cabbage', this entry is more or less what the original should've been if I had more experience in 2023. It largely keeps the original design intact while smoothing out the edges. A few minor updates were made to the level structure and the worldmap was completely reworked. I hope this version of Smoked Fish and Cabbage reaches the right audience and helps bring new players into kaizo.

________________________________________________________________________________________________________________________________________________________________________

RETRO GRAVY
-inspired by and designed to look like a level in a gameboy game
-carefully selected shades of green to avoid foreground/background blending

CHECKPOINT CITY
-coined phrase in the Mario Maker community by DGR Dave that I felt would make a cool level concept
-literally a city of checkpoints used as decoration - not one of these functions as a real checkpoint

THE DANGER ZONE
-my first level designed in Lunar Magic!
-redesign of a 20 second speedrun level I created in Mario Maker 2

CHEDDAR BELIEVE IT
-went with shades of yellow and orange to create a 'cheesy' tone
-slightly more precise level design than the previous 3

THE CLOT THICKENS
-inspired by true life events, this level is designed to feel as though it takes place in the body
-shades of red and white used to support the level concept

BELLY OF THE BEAST
-underwater level designed as a nod to the DAM level in the NES version of TMNT
-pink weeds damage the player, some paths are intentionally tight

NONE SHELL PASS
-vertical tower ascension
-general theme is a fortress with red accents (original concept was inspired by the Virtual Boy)

This romhack was designed with passion and determination- Thank you for playing!!

A HUGE 'thank you' goes out to Saphros for inspiring me to revisit this project in an effort to bring it to new audiences, to Jezjitsu for his brilliant help with palettes, and my playtesters for sharing their time and feedback with me to bring the best experience possible to players. Finally, thank you to the community for keeping this entry relevant - you're all the best!!