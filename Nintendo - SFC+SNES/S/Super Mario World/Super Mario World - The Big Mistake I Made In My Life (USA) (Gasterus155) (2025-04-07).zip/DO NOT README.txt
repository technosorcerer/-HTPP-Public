HI
If you read the description of this hack 
so you dont need to read this
.
i will talk about this hack:
there is 35 exits, 29 normal exit and 6 secret exits
secret exits are in these levels:
"the first level" "frog cave" "bad night" "peacefull hills"  "day or night?" and "nitrogen cave"
and the first 3 secret exits will not lead you to any other level, i mean that they wlii not open another level when you beat theme, but they will added to exits counter
there is an exits counter in the bottom of overworld, when you reach 35 exits, here you can consider yourself compleated this hack, secret exits and switch palaces are counts
the final level "the cursed mountain" will requaier 34 exit to play it
,
in this hack your progress is automaticly save when you return to overworld, so don,t forget to return to overworld to save your checkpointes by pressing start+select (the level 5 (cursed house) has a section that you can,t use start button to pause the game, here you will need to press selecte when you die)
,
and about the difficulty, i can.t lie about this........this hack is very hard and some levels here can take from you houres and houres to beat them.....or 1 hour with savestates
it,s not impossible to clear this hack..........but that could be very difficulte.......my advice is to use savestates if you found yourself can,t beat the levels RTA.....Savetates should be yout best friend
but this hack will still be hard even with savestates
some times you will need to do some glitches "like banzai bill glitch" or hard jumps "like key jump", "yump" but don,t worry there is no wall clip glitch or not block glitch  
,
about the trolls?......yes there is......but not a lot........and you will not like them
.
i don.t think i did a lot of changes in this version.....i just did some small changes at some levels to make them easier.......(or harder).......eaither by adding indecators......or editing some obsticals.......or changing them by other easier 
but the hack is still very hard.....

i think that,s all?

good luck