This document CONTAINS SPOILERS as it's here to help in case you get stuck anywhere or anything.
If you get stuck or need help in: Red Tower or Bowser's Castle, or simply do not care about spoilers, feel free to scroll down and read.
































































RED TOWER:
In this level you can Shinespark like in Super Metroid with the speed booster. To do so, run with P-Speed and press down WHILE having P-Speed. You will then
lose your momentum and gain a charge. Then you can either just shinespark upwards by jumping, or move left or right and jump to shinespark diagonally.

BOWSER'S CASTLE:
For the Bowser Battle, you can press A shortly before landing on Bowser to deal more damage. This is not necessary, but it makes the battle significantly
easier.