HI
If you are reading this now, that means you downloaded my hack (i think?)
and that makes me happy

in fact, this is my first rom hack, and i am just a realllllly nob at making rom hacks with my zero knowledge at ASM
My beginning was the worst beginning, because I faced a lot of problems



Anyway
This ROM HACK has some small problems i will talk about theme 
but befor that
you have to know that this hack will save your progress automatically after you returne to overworld
so if you close the game befor that, your checkpoints will not be saved
yeah like most rom hacks, i wanted to alert you to that becaus I know the feeling of playing for a long time and then losing everything, and i don't want this to happen with anyone in this hack

to returne to the overworld you can use START + SELECTE like most rom hacks
but there is a level (or section in a level), in this section you cant use START button so you cant use START + SELECTE, if you want to leave this level you can press SELECTE during RETRY prompt, and your checkpoints will be saved

now i will talk about some small issuses that may be annoying:

wierd sprite tiles: some glitched sprite tiles in some levels especially the last level, the rason is that this level have a dynamic sprite (If you don't know what is Dynamic Sprites, me to)
i know a way to fix that but for some reason it didnt work

another issuse but its from me this time, english is not my first language, (I think you noticed that from the way I speak) Therefore, you may find some mistakes in the messages

I don't know if there are other problems or not but that what i found becaus i tested this hack twice (in zmz and snes9x)
If I can find a solution to these problems, I will fix them
If I can't.........I will think about what I can do

AND LAG AND INVISIBLE PLAYER/SPRITES ARE NOW FIXED!!!!!!!!!!!!!!!!!!

in the end i am just a nob in ASM

and......If you have suggestions or advice that could help me improve myself in the future.....I hope you tell me

and thats all
Have a great time