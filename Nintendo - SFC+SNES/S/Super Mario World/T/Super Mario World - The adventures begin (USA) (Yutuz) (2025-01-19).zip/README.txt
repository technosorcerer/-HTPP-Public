THANK YOU SO MUCH FOR DOWNLOADING THIS TRICK!
  
this trick took me all summer vacations as free time =), so I worked hard to create this mod and one of my goals is to achieve NINTENDO-style levels, enjoy it but you may find bugs until the next version.

-----version history----
2.0
*slight change of title name
*now you can play with luigi by pressing R anywhere on the map.
*added game over animation
*ROM of the second game for bigger patches reasons
*recreation of levels completely from 0 for crashes reasons
*the story makes sense towards the second installment “the adventures end”.
*new and exclusive levels for more entertainment
*improved graphics and music
*fixed garbage events
*new dialogs improved
*Long jump (run, press down and jump) SM64
*High jump (run, turn a little and jump) SM64
*Wall jump SM64

1.2
*Yoshi Island's intro will only be used in "special levels"
*Added dragon coin indicators and secondary outputs
*Minor bug fixes in levels
*Fixed bugs in the OW map with unlocked events
*The difficulty was lowered to level "3-K" and renamed to 3-2 ("K" means Kaizo level)
*The error of past events in level "3-A" was corrected
*Some levels were renamed
*Some levels were slightly modified
*Fixed the music error with STRONG ECO at level "3-C"

1.1
*initial version

-----special thanks-----

*patcdr (thank you very very much)
*GreenHammerBro

*MarioFanGamer

*MathOnNapkins (No More Sprite Tile Limits team)

*smkdan

*TheBiob

*Nowieso & swunsh_

*Chdata/Fakescaper

*Roy

*SiameseTwins

*kaizoman666

*Sonikku, Daizo Dee Von & the Mad Scientist 2022

*WhiteYoshiEgg

*Decoy Blimp

*KevinM

*Sonikku

*Ladida & imamelia

*FusoYa