HI
If you read the description of this hack 
so you dont need to read this
.
i will talk about this hack:
there is 28 exits, 23 normal exit and 5 secret exits
secret exits are in these levels:
"the first level" "frog cave" "bad night" "peacefull hills" and "day or night?"
and the first two secret exits will not lead you to any other level, i mean that they wlii not open another level when you beat theme, but they will added to exits counter
there is an exits counter in the bottom of overworld, when you reach 28 exits, here you can consider yourself compleated this hack, secret exits and switch palaces are counts
the final level "the cursed mountain" will requaier 27 exit to play it
,
in this hack your progress is automaticly save when you return to overworld, so don,t forget to return to overworld to save your checkpointes by pressing start+select (the level 5 (cursed house) has a section that you can,t use start button to pause the game, here you will need to press selecte when you die)
,
and about the difficulty, it,s random and don,t have a spesific system, some levels are long and others are shorts or mediem, the same thing with difficulty
some times you will need to do some glitches "like banzai bill glitch" or hard jumps "like key jump", but don,t worry there is no wall clip glitch or not block glitch or vanilla p-switch jump
,
about the trolls?......yes there is......but not a lot
.
the previous versions had some issuses (like slow downs or disappearing sprites.......etc) but they are fixed now
there is still one issuse witch is wierd sprite tiles in the final level becaus it has a dynamic sprite.....so it will affect some sprite that uses sp4 gfx
Edit:.......this issue is "half fixed"........dolphins and blurp fish will appeare correctly......but big boo will still appeare wierd

i think that,s all?

good luck