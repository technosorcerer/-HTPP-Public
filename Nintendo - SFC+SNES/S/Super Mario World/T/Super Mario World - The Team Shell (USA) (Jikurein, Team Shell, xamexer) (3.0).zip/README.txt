Thank you for downloading the Team Shell hack! 

In this hack there are 2 modes : 

*Adventure*

and

*Exploration*

In adventure mode, it is like a normal hack with progression. Each level beaten unlocks new directions for you to go in to beat more
levels and maybe even find some cool stuff along the way!

In exploration mode, the whole overworld is free for you to explore. We are very proud of our overworld and if some levels are too hard
and you just want to check out some other levels without the pressure of having to beat all of the levels before it you can go forth and 
explore to your heart's content.

Each level has a dificulty rating and while not perfect, will give a general idea on how hard the level is. You may have to beat harder
levels to go to different paths!

In this hack there are also NO secret exits. Red level spaces are for aesthetic purposes only. There are however 4 big P-switches scattered
around the overworld, found by beating levels in a normal fashion.



1.1 - Fixed an overworld bug in exploration mode
    - Fixed typos

1.2 - Fixed a graphical issue in Infinity Castle

2.0 - Huge balance changes and reworks of levels. Added HoboOfHyrule's level for optional play.

2.1 - Fixed broken levels in the Special World

2.2 - Changed some levels to be more consistent and fixed other minor issues.

2.3 - More balance changes and visual fixes.

2.4 - Fixed an oversight in the final level. 

3.0 - Fixed "Basic Platforming" and Ez midair patch.