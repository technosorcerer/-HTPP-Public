Thank you for downloading this romhack! I began working on this hack in late 2019, but I lost motivation to work on it.
In 2023 I decided to clean up the levels and assets I had already created to at least release a small taste of what this project could have become.
It's not a long game, but I hope you enjoy playing it!
- Tob

- - - - - - - - - - - - - - -

HOW TO PATCH:
Please refer to this guide: https://smwc.me/1399053

- - - - - - - - - - - - - - -

Credits:

Leveldesign: Tob
Graphics: Tob, PercentN
Music and Sound: Kevin, Dippy, Nanako, Maxodex, Teows, ss_isbjorn, Pinci, sincx, HaruMKT, Wakana
ASM: MarioFanGamer, Medic, Sonikku, Ladida, Burning Loaf, TheBiob, Demonsul, KilloZapit, Koyukillo, Erik557, Tahixham, Tob, Noobish Noobsicle, Kaizoman, Vitor Vilela

- - - - - - - - - - - - - - -

For any questions or feedback:
Discord: dertob_
Twitter: @dertob_