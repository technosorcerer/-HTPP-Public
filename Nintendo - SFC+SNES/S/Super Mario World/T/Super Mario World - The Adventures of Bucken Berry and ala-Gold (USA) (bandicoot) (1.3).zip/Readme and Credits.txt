The Adventures of Bucken Berry and Ala Gold
by Bandicoot v1.1.0

This is a traditional adventure hack designed to be a "prequel story" of sorts to new super mario bros wii
Our protagonists nicknamed Bucken Berry And Ala-Gold (aka Blue Toad and Yellow Toad)have been trained by Mario and the Princess to become the new guardians of the Mushroom Kingdom, however a few days after their training concluded the Princess had misteriously disapeared, Mario being the hero he is went after her but never came back, now our new heroes decided to go on an adventure to save them both from wathever evil has fallen upon them.

This hack features 7 worlds filled with fun and traditional levels and an secret extra world for those who wants more challenge and exploration.
In total the hack has 93 exits to find.
Our Toad protagonists also have a few more moves on their dispose like the walljump and the charged jump from SMB2.


Why Bucken Berry and Ala-Gold?
The are nicknamed that part of the Mario comunity have adopted for the Blue and Yellow Toads as nicknames,
it is also rumored that the devs of New Super Mario bros wii had used this as nicknames for the characters as well
but it was never confirmed and of course those arent their oficial names, 
but I just found the nicknames funny and decided to use them in my game.

Why the weird boss names?
These boss names were given by me to the bosses in homage to the FlickeringPixeelz group on Twitch
they are some good friends of my that loves my hacks and I grew to enjoy a lot their content.
(Especially when Deankind is playing Mario), some of the jokes are also intern jokes within the group that would be hard to understand without knowing their content btw.
Feel free to check their livestreams at twitch here:https://www.twitch.tv/flickeringpixelz

I hope you enjoy.

Credits:

Level Design & Game Design:
Bandicoot
------------------------------------------
Beta Testers:
Deankind & Flickering Pixelz
Insanit
Fire Fast
Railson Santos
Fortright MC
h.carrell
lo fang 123
lordkronos100
------------------------------------
Special Thanks
Deankind & FlickeringPixelz Team on twitch

------------------------------------------
Tools:
Fusoya
Kipernal
Alcaro
Atari2.0
JackTheSpades,
Tattletale
Snes9x team
Vitor Vilela
Major Flare
dtothefourth
mzuenni	
uyuyuy99
Smallhacker
-------------------------------------------------------

Graphics:

Bandicoot
Gamma V
Ayami
Pink Gold Peach
Eminus
Dark Mario Bros
GlacialSiren484
Jamestendo64 
mariomaker6
Kaching720
LinkstormZ 
MauricioN64
Undead441
ShadowMistressYuko
Dan
TheOrangeToad
NopeContest
AyGaAlPa
DynastyLobster
Blizzard Buffalo
hash
Jack_Vincent13
Anorakun

-------------------------------------------------------------------
Custom Sprites:

imamelia
Mikeyk
Romi
leod
Stivi
Sonikku
Dispari Scuro
smkdan
Erik557
Darolac
M.S
Koopster
Mirumo
AmperSam
Blind Devil
Isikoro
yoshicookiezeus
Mandew
MellyMellouange
Roberto Zampari
Nekoh
RussianMan
edit1754
HuFlungDu
SMWEdit
Davros
Iceguy
JackTheSpades
KevinM
MarioFanGamer
Thomas
kaizoman666
________________________________
Custom blocks:

HammerBrother
Telinc1
TheXander
Darolac
ShadowMistressYuko
JackTheSpades
Iceguy
Infrared
quietmason
Alcaro 
MarioE
Sind
Ersanio
Sind
RussianMan
K3fka
-------------------------------------------------------------
ASM & Patches:

Bensalot
Kaizoman
Noobish Noobsicle
aroohwahoou
MarioFanGamer
JackTheSpades
Disk Poppy 
Erik 
Thomas
wye
smkdan
Roy
Romi
Alcaro
BMF
Iceman
HammerBrother
Ladida
Edit1754
Vitor Vilela
Arujus
MathOnNapkins
TattleTale
KevinM
Erik557
RussianMan
aCrowned	
MarioE
ExE Boss
Kevin
lx5 
worldpeace
DiscoTheBat
imamelia

-------------------------------------
Custom Music:

Bandicoot
Pink Gold Peach
Gamma V
Ladiesman217
Lui, 
Vitor Vilela
musicalman
ggamer77
Hooded Edge
HaruMKT
EDIT3333
Samantha	
icrawfish
Isikoro
Masterlink
Zavok
Hiro
Giftshaven
Goomba-24
Wakana
Marcozzo Daro
JordanTRS
its_4life
Tornado
Torchkas
Ultima
Wavee
FPI
xyz600sp
MidiGuy
JuniorDarkSword
Masashi27
Pinci
brickblock369
Dippy
bebn_legg
com_poser
Maxodex
Infinity
Todd
Mr. Red
MercuryPenny
Ahrion
SiameseTwins
KungFuFurby
Magi 
Slash Man
ThinkOneMoreTime	
KevinM
CrimsonZN
Jimmy
RednGreen
Nanako
DanTheVP
Hazel