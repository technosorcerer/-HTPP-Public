-------------SPANISH/ESPAÑOL------------

Muchas gracias por descargar The adventures end (las aventuras terminan), secuela directa de mi primer hack "Adventures Begin" la cual tendrá futura actualización y corrección de bugs, disfruta de este DEMO con su historia continua del anterior juego estoy abierto a cooperaciones para terminar el hack, porfavor no dudes en enviar un PM a SMWCENTRAL.

tu amigo YUTUZ....

-----CAMBIOS-----
V2 30/05/2025
-cambio del titulo
-algunos niveles totalmente cambiados
-cambio de dificultad para algunos niveles
-Sistema de reintento en niveles complejos
-arreglos en HDMA
-arreglos en traducción al español
-créditos mejorados
-Los niveles de VIP son totalmente eliminados y remplazados por nuevos y mejorados (gracias por las correcciones hacia los moderadores)
-arreglo de paletas en el mapa
-arreglo de eventos basura

NOTA: no tendrá su versión en ingles hasta en una futura actualización

---------AGRADECIMIENTOS ESPECIALES / SPECIAL VERY THANKS------------
Herramientas/tools
-Fusoya
-Romi
-SMWCentral Forum

Graphics/graficos
-Gamma V
-Shikaternia, TheOrangeToad
-Roy
-Hinalyte
-Mr. MS
-Pieguy1372
-Tahixham
-Yutuz
-Falconpunch
-E-man38
-Marioman
-Hayashi Neru
-Link13
-OrangeBronzeDaisy
-Rykon-V73
-DynastyLobster
-Merio
-ECS.98
-Natsuz2
-Black Sabbath
-wiiqwertyuiop

Bloques/blocks
-dacin
-HammerBrother
-Mariofangamer

Sprites
-Daizo Dee Von
-Eminus & Von Fahrenheit
-Darolac
-JamesD28
-HammerBrother
-Davros
-Sonikku
-Roy
-dahnamics
-Romi
-Isikoro
-Tattletale
-Dispari Scuro
-mikeyk
-Blind Devil
-smkdan

Códigos ASM/ASM codes
-Mariofangamer
-KevinM
-GreenHammerBro
-Mattrizzle
-kaizoman666
-Telinc1
-Eduard
-Nowieso
-kevin
-Blind Devil

Musica/music
-LadiesMan217
-Vitor Vilela
-musicalman
-Milon Luxy
-JX444444
-SiameseTwins
-Ultima

Moderadores/moderators
-Yutuz
-LuffyCLN
-Big Brawler
-Linkdeadx2
-Apersam
-Linkdeadx2
-donwafle
-BigBrawler
-BuzzerPop