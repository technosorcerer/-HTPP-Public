After releasing my first hack, the idea of a Remastered came up, and the idea started to take shape well above expectations. A hype was created and after a lot of work, it is finally done!

The REMASTERED version has significant improvements in the level design in general, aesthetic improvements, reasonable difficulty and much less frustrating. I concentrated on maintaining the base difficulty, applying as much fun as possible with reworked and more creative setups.
The main change right away is the fact that there is no longer an Overworld, following 100% linear. The lore is more developed. Almost all songs have been replaced and new levels added.

The hack now has 12 exits, the last one being an EXTRA level. Anyone who is a fan of Morsel's work will certainly like the hack, since it is dedicated to him.

I could not fail to mention how grateful I am for the affection I have received from the community for the past few months. That certainly motivated me to improve more and more, I love you all.

====IMPORTANT NOTES====

This hack has NO OVERWORLD, and your checkpoints will be saved automaticaly once you take the midway bar.
All the music are on SMWCentral.net, you can find it for yourself since I'm lazy to get every single url :p
If you have any questions send me a PM or DM, whatever is better for ya.

Overall, enjoy the game :)

1.3 changes

- Reduced overall tightness
- Level 3: Removed 3d perspective ground tiles
- Level 4: Added a 2nd checkpoint
- Level 5: Removed camera blocks and changed a weird setup
- Level 7: Bounce block is now visible, Banzai will no longer despawn in the 2nd half
- Level 8: Fixed Boo Ring inconsistency
- Level 11: Better Boss Fight