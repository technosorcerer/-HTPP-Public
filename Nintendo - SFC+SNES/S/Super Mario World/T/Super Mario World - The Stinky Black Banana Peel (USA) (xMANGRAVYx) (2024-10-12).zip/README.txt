THE STINKY BLACK BANANA PEEL
by xMANGRAVYx

8 exits
Kaizo Beginner-Intermediate Difficulty

This rom hack was designed to help ease players into the next stage of their kaizo journey. We as a community worked together on design choices over a two month
period to bring you an 8 level world meant to test your skill and reflexes. This world begins as a beginner-friendly hack, and slowly builds
towards a more intermediate second half. Complete with tricks, trolls and secrets... this hack aims to be a trial for lower skilled players, and a smooth ride for the
more seasoned veterans. Challenge the bounds of your skillset and cleanse the world of 'The Stinky Black Banana Peel'

The graphics and soundtrack in this hack were carefully selected in an effort to keep the gameplay loop satisfying and feeling fresh. 

This rom hack makes use of more advanced setups, and will certainly challenge players of all skill levels.
Good luck, have fun and THANK YOU FOR PLAYING!!

A huge 'THANK YOU' goes out to my Twitch community for all their time and effort with this project! You all brought such incredible ideas to the table, and I'm
beyond proud of what we came up with together.