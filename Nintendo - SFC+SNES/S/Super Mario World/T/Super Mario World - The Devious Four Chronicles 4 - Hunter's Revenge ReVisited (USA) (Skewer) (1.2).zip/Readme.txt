;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;                                                                                   ;;;;;
;;;;;    ;;;;;;;;     ;;;;;;;;;     ;;;;;;;     ;;;;;;;;     ;;;;;;;;;     ;;;;;;;;;    ;;;;;
;;;;;    ;;     ;;    ;;           ;;     ;;    ;;     ;;    ;;  ;;  ;;    ;;           ;;;;;
;;;;;    ;;     ;;    ;;           ;;     ;;    ;;     ;;    ;;  ;;  ;;    ;;           ;;;;;
;;;;;    ;;;;;;;      ;;;;;;;;     ;;;;;;;;;    ;;     ;;    ;;  ;;  ;;    ;;;;;;;;;    ;;;;;
;;;;;    ;;     ;;    ;;           ;;     ;;    ;;     ;;    ;;  ;;  ;;    ;;           ;;;;;
;;;;;    ;;     ;;    ;;           ;;     ;;    ;;     ;;    ;;  ;;  ;;    ;;           ;;;;;
;;;;;    ;;     ;;    ;;;;;;;;;    ;;     ;;    ;;;;;;;;     ;;  ;;  ;;    ;;;;;;;;;    ;;;;;
;;;;;                                                                                   ;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

If you are reading this, then that means you've downloaded the full version of "The Devious Four Chronicles Episode 4
Hunter's Revenge ReVised"!  This was a project by Skewer started in 2014, an attempt to turn the original "Hunter's Revenge
Recharged", the black sheep hack of the TD4C, into something that fit in with the rest of the series' quality.  It is safe
to say that this project succeeded.

If you have not played "The Devious Four Chronicles Episode 3: The Crater", it's highly recommended you do so and introduce
yourself to the series.  Otherwise, please enjoy this Super Mario World hack.  It's recommended you play in an emulator that
is not ZSNES, as music breaks on that emulator.

Do not rip any graphics from this mod.

Changes:
1.0
�EInitial Release

v1.1
�EChanged global animation of the SMB3 Bricks.  They now show up as coins when POW is active.
�ERemoved badly colored Yoshi Coins in "Grassy Crossroads"
�EFixed roofing in the secret path of "The Thicket", no longer are you able to be potentially Softlocked.
�EFixed an issue with jumping piranha plant getting stuck in a roof in "Canopy Carnage"
�EFixed piranha cutoff in a subroom in "Wonder Blizz"
�ERemoved messageless message boxes.  Period.
�EGrinders can no longer be killed by sliding, fixing weird animation issues in "Capital Space"
�EFixed glitched pipe corner tiles in "Stronghold Showdown"
�EFixed upside-down slopes in "Hack Moderators Hideout"
�EFixed foreground penetration in "Maridia" area
�EFixed glitched note-block graphic in "Fields of Beguile" (same with Heated Kiln)

v1.2 "The Major Shift"
�E Reverted the Titlescreen graphics back to their original form prior to original 1.0 release.
�E Changed around some of the sound channels of the BGM to "Capital 2" so that one can actually hear the melody when jumping all over the place.
�E Changed the "Nintendo Presents" from "Scorpion Works" to "D4 Team Presents".
�E Updated Peach's cutscene graphics to use the same ones as in "The Crater" for consistency purposes.
�E The entrances to Synth Key Challenges all now have exit pipes which send you back to the main level if you do not want to take the secret challenge. Furthermore, these exit pipes now have the word "BACK" written onto them.
�E Heat effect has been added to the background of "Certain Secret Areas", for consistency with others.
�E Added Midway Point to Synth Key Challenge 3, as it is a water level, and a pretty long one.
�E Removed the "Surprise Mutha-F**ka" crab in Synth Key Challenge 3 that attacks you when you exit a pipe.  Seriously, how did that guy get by the testing?!?
�E World 4-4, "Pitchin' Or Chicken'" has been altered slightly.  There is now a P-Switch run near the end of the level instead of the P-Balloon float because the original design is just hell for players who are not experienced with the P-Balloon.  Plus I think it adds a little bit more variety instead of just "floating around."
�E The Ending of "The Eighth Key" has had its last room modified to be slightly easier.
�E Fixed the cheap shot at the end of "Turn Block Vessicle", that's just not needed and really mean. X(
�E Blocks in "Mutation Base" acted like Ice Blocks when they're not supposed to. Fixed.
�E Added midway point after the boss in "Gateway to the Synth"
�E Remixed "Thaumaturgy Annex"s level to be highly gravity based, so that the level stands out on its own.
�E Doubled the length of "Thaumaturgy Annex", now with a varied Gravity based gimmick.
�E Added a gravity based room to "Floor 48".
�E Nerfed the lasers in "Floor 48", they no longer instantly kill you, instead they just hurt you.
�E Major nerf to the "Seekers"; Seekers are the flying enemies that chase you relentlessly whenever you get close to them. They're basically flying wigglers from Yoshi's Island with a graphics change.
�E Increased the time for the Neon enemies before they begin their pursuit.
�E Nerfed the speed of the blue Killer Diamond enemies seen in the Tower
�E Nerfed the speed of the green Killer Square enemies seen in the Tower
�E Removed ability for the 100 Coin Roulette to store LX5 powerups to the status bar.
�E "Moderators' Hideout" level removed in favor of more universe lore faithful material.
�E "Sectorian Style" level added.
�E Nerfed "Sectorial Style" boss, now only needs 3 hits to be defeated.
�E All references to SMWC removed for universe lore faithful material. It was fun back when I was a moderator back in 2014, but it's 2023 at this time of releasing this patch and thus it is no longer fun anymore.
�E Quite a few rewrites to the cutscenes in the game for consistency purposes.