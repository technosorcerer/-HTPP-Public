==============================================================================================================================================================
___________.__                   __                  .__      .__                 ___________                      __           ___________                 
\__    ___/|  |__ _____    ____ |  | __  ______ ____ |__|__  _|__| ____    ____   \__    ___/_  _  __ ____   _____/  |_ ___.__. \_   _____/________ _______ 
  |    |   |  |  \\__  \  /    \|  |/ / /  ___// ___\|  \  \/ /  |/    \  / ___\    |    |  \ \/ \/ // __ \ /    \   __<   |  |  |    __)/  _ \__  \\_  __ \
  |    |   |   Y  \/ __ \|   |  \    <  \___ \/ /_/  >  |\   /|  |   |  \/ /_/  >   |    |   \     /\  ___/|   |  \  |  \___  |  |     \(  <_> ) __ \|  | \/
  |____|   |___|  (____  /___|  /__|_ \/____  >___  /|__| \_/ |__|___|  /\___  /    |____|    \/\_/  \___  >___|  /__|  / ____|  \___  / \____(____  /__|   
                \/     \/     \/     \/     \/_____/                  \//_____/                          \/     \/      \/           \/            \/      
==============================================================================================================================================================

The Story:

Mario has found himself in that time of the year once more - the plump, followed by the slump. From turkeys named Yoshi to forests of gold, Mario must battle his way through Thanksgivingland. AS it turns out, an evil enemy from Mario's past has stolen all of the Thanksgiving veggies and goodies - does Mario have what it takes to defeat his enemy AND be home in time for the football game and stuffing? Let's find out!

Gameplay:

The game has two modes - Standard and Hard. You can choose your path via the first level of the game. Please note - your choice is solidified if you choose Hard Mode. Standard Mode allows for both paths. The Standard Mode falls under the Standard-Immediate to Standard-Hard skill level. Hard Mode is Kaizo-Beginner to Kaizo-Intermediate. Give both a try - I have confidence you have what it takes to win swim team (slang for winning the game, lol). I hope you enjoy the experience and that all things Thanksgiving will be conjured for ya. And oh yeah - eat three plates of food for me. If you arent having to unbutton your pants after the feast, you're doing it wrong.

Thanks for playing!

Happy Thanksgiving!

- Yeto. 11.28.2024. 
