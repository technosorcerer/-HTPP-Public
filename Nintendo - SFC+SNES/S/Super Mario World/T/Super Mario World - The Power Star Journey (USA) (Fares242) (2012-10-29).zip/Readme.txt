                 ---------------------Super Mario-The Power Star Journey---------------------


--Story--

Once again, Bowser comes to Mushroom Kingdom to cause trouble! But this time, makes it to STAR VALLEY & steals the King Star
that was holding the power stars together, thus letting them spread! Bowser then builds a base in space called STAR BASE.
But, worse is still ahead! Bowser at the end intends to use the King Star's power to absorb all star power from the planet!
To beat Bowser, Mario must reach STAR VALLEY & use its space-blast cannon that can blast him to BOWSER'S STAR BASE.
To do that, Mario must collect 80 power stars to open the door that Bowser sealed in STAR VALLEY.
STAR VALLEY has a HIDDEN entrance you have to find.
Can Mario get the job done?


--Features--

A new game is here! After almost 11 months of hard work, I, Fares242 bring you "Super Mario-The Power Star Journey"!
It has:
-All new levels
-All new music
-97 power stars (don't know if there are 100 coin stars, never took them into account. You can search if you want)

ATTENTION: Each star appears at its act! Example--Star 1 appears when you select act 1 from the menu, star 2 act 2, etc...

--Assistance--

For assistance I have provided you with my youtube channel:
http://www.youtube.com/user/Fares242?feature=mhee

For those with no youtube accounts, they can reach me on my e-mail for help in the game:
sultan_fares@yahoo.com

PLEASE READ THE TEXTS OF THE GAME! SOME TEXTS ARE CRUCIAL NAMELY THE ONES THAT ARE HINTS FOR THE MYSTERIES OF THE GAME!!!



Enjoy this game & would love to see if you like it!