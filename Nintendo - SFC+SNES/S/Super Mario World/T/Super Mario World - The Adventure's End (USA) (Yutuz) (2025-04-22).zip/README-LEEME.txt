-------------SPANISH/ESPAÑOL------------

Muchas gracias por descargar The adventures end (las aventuras terminan), secuela directa de mi primer hack "Adventures Begin" la cual tendrá futura actualización y corrección de bugs, disfruta de este DEMO con su historia continua del anterior juego estoy abierto a cooperaciones para terminar el hack, porfavor no dudes en enviar un PM a SMWCENTRAL.

tu amigo YUTUZ....

-----CAMBIOS-----
-Se agrego un pequeño tutorial al principio de la aventura
-se elimino dos jefes y se remplazo por magikoopa en el castillo 3
-se agregaron nuevos diálogos y mejorados
-se arreglaron muchos bugs anteriores y pequeños detalles

-NOTA-
Recomiendo utilizar SNES9GX ya que Zsnes detecta muchos errores graficos, también dejare solo la versión en español por cuestiones de tiempo, la versión en ingles no saldrá, lo siento...
Algunos niveles son de dificultad alta, por lo que ya no puedo bajar mas la dificultad


---------AGRADECIMIENTOS ESPECIALES / SPECIAL VERY THANKS------------
Herramientas/tools
-Fusoya
-Romi
-SMWCentral Forum

Graphics/graficos
-Gamma V
-Shikaternia, TheOrangeToad
-Roy
-Hinalyte
-Mr. MS
-Pieguy1372
-Tahixham
-Yutuz
-Falconpunch
-E-man38
-Marioman
-Hayashi Neru
-Link13
-OrangeBronzeDaisy
-Rykon-V73
-DynastyLobster
-Merio
-ECS.98
-Natsuz2
-Black Sabbath
-wiiqwertyuiop

Bloques/blocks
-dacin
-HammerBrother
-Mariofangamer

Sprites
-Daizo Dee Von
-Eminus & Von Fahrenheit
-Darolac
-JamesD28
-HammerBrother
-Davros
-Sonikku
-Roy
-dahnamics
-Romi
-Isikoro
-Tattletale
-Dispari Scuro
-mikeyk
-Blind Devil
-smkdan

Códigos ASM/ASM codes
-Mariofangamer
-KevinM
-GreenHammerBro
-Mattrizzle
-kaizoman666
-Telinc1
-Eduard
-Nowieso
-kevin
-Blind Devil

Musica/music
-LadiesMan217
-Vitor Vilela
-musicalman
-Milon Luxy
-JX444444
-SiameseTwins
-Ultima

Testers
-BrianPlayGamesBad
-Yutuz
-LuffyCLN
-Big Brawler
-Linkdeadx2