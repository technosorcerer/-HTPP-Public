plot: this is an extremely dangerous adventure, sonic is in a dangerous desert and decided to go to an oasis where his friends are, can sonic reach the oasis ?
this hack is now released this year, but it was made back in 2022, it was an abandoned project since that year until today. it has original ports made by me.
finally is complete and ready to go

note: interested in the ports in this hack ? i will soon release a music pack from this and from my other hacks I did, but credit is needed.

anyways, here is the credits

graphics:

sonic the hedgehog by Kusamochi

music (all ported by sholmes)

anything

animal crossing - rainy day

Chopin - Prelude in E Minor Op.28 No.4

Relaxing Oasis

Sprites:

pokey disassembly by imamelia

flying pokey by Erik

jumping goomba by Mr MS

patches:

remove status bar by lui

one file one player by kevin

inspired by Kaizo Mario World Series (these hacks by Takemoto doesn't have retry system)