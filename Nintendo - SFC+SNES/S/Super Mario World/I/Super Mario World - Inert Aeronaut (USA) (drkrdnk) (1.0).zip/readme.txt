--------------------------------------------------------------------------------
  Inert Aeronaut by drkrdnk
--------------------------------------------------------------------------------

I made a 'vanilla cape' kaizo romhack that focuses mostly on speed control
during flight. This means speed oscillation, float delay and cape spin
turnaround are not patched. The intention is to prevent you from relying on
patched turnarounds as a way of controlling your movement and embrace other
techniques.

Some parts are intended to be played in a slow and considered manner, whereas
others will demand a faster pace where death is part of the learning process.
The majority of sections are approximately 40 in-game seconds in length when
completed as intended.

Required skills include
  * good understanding of the takeoff meter and conditions for flight
  * fine control over slowing down and speeding up
  * recovering from 0 speed
  * slowing down AND speeding up during sticky flight

You will NOT be required to perform
  * cape spin turnarounds
  * spin-flight
  * duck flight
  * yoshi flight

It may help to be comfortable with vanilla turnaround strats or backwards
pumping for the purposes of recovering or stalling but neither are required.
You may need to plan ahead if you are not utilising these techniques.

Cape is hard and I would recommend training with "Learning to Fly" by DJLocks
and NewPointless if you are not already an experienced cape gamer.

https://www.smwcentral.net/?p=viewthread&t=104020

Good luck

--------------------------------------------------------------------------------
  Verified Working Setups
--------------------------------------------------------------------------------

Mesen2 emulator
MiSTer FPGA SNES core
Super Famicom with SD2SNES PRO (firmware v1.11.0)
Super NT with FXPAK PRO

--------------------------------------------------------------------------------
  Music Credits
--------------------------------------------------------------------------------

Title Screen and Credits
  Radix
  Unreal Superhero
  ported by Pixelninetales

Main Overworld
  Yoko Shimomura
  Silent Labyrinth (Live A Live)
  ported by icrawfish

Practice Zone
  Hiroyuki Yanada, Iwao Mitsunaga
  Dungeon (Last Bible III Remix) (MTG: Last Bible II)
  ported by icrawfish

First Level
  Hirokazu Ando
  Cruising (HAL's Hole in One Golf)
  ported by Segment1Zone2
  
Anonymole Forest
  Yuzo Koshiro
  The Island of Everlasting Summer (Super Adventure Island)
  ported by SiameseTwins

MegaYegha Flood
  Robert A. Allen
  Letni (Jazz Jackrabbit)
  ported by Pixelninetales

Grippy Grotto
  A. Akamatsu, S. Oita, S. Nakaya
  Wanna Learn Somethin'? (Super Adventure Island 2)
  ported by KevinM
  
Netscape Navigator
  Shinji Tachikawa
  Deep Dark Caverns (Power Lode Runner)
  ported by Segment1Zone2

Ghost Glider
  Manami Gotoh
  Macabre Funk (Magic Sword)
  ported by icrawfish
  
Flightmare Cafe
  Iku Mizutani, Kinuyo Yamashita
  Winter (Ohmono Black Bass Fishing)
  ported by Jakeapus

Magma Passage
  Hiroyuki Iwatsuki
  Stage 1-2 (Mitsume ga Tooru) 
  ported by Ahrion
  
Scorching Spelunk
  Tsukasa Tawada, Zep Takashiba
  Naval Battle (Super Earth Defense Force)
  ported by icrawfish
  
Sticky Collapse
  Lee Jackson
  Goin' Down the Fast Way (Rise of the Triad)
  ported by Bak Sangwoo

Final Overworld Zone
  Yasuhiko Fukuda, Akira Yamaoka, Manabu Saito 
  Moon (Smart Ball/Jerry Boy)
  ported by Jakeapus  

Yossy Summit
  Go Ichinose
  Lake (Pokemon DPPt)
  ported by sinseiga

