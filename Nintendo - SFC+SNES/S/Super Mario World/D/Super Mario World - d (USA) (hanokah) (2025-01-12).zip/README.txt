"D": a super mario world romhack by hanokah
Version 1.0, Jan. 12 2025

13 levels, 0 secret exits
--------------
The point of this hack was to experiment with pretty much any level ideas I could come up with, 
compared to my previous 2 hacks "Super Hanokah World" and "Super Hanokah World 2" (both of which
can be found on romhacking.net and are extremely broken even for 2023/2024 hacks), which were
inspired by more traditional Mario games.

Credits can be found in the credits.txt file.
