# Daisy's Crazy Adventure Beta 1.0.0

Created by BlueSheep123 in 2024.

## Introduction

_Daisy's Crazy Adventure_ is a ROM hack of Nintendo's _Super Mario World_. This is a **choco-nilla** hack with **normal difficulty**. In this adventure, the evil alien Tatanga has returned to Sarasaland and taken over the entire empire and kidnapped Luigi. It's up to our hero Daisy to rescue Luigi and bring back peace.

The hack is loosely inspired by Super Mario Land.

## Features

- 4 worlds, 17 exits (4 of which are bosses, so 13 levels)
- Each level introduces and builds upon a unique gimmick
- Custom music from a variety of games and composers.
- Custom bosses
- Custom ASM (UberASM, blocks, sprites)
- A minimalist HUD
- Custom graphics

## Installation Instructions

1.  Download a SNES emulator. Snes9x or BizHawk is strongly recommended as this ROM hack was tested using them. ZSNES is an outdated and inaccurate emulator last updated in freaking 2007! The game will lag and music will not play properly in ZSNES!
2.  Obtain a copy of the original Super Mario World ROM.
3.  Use ROM Clean to ensure you are using an unmodified ROM. [Download ROM Clean](https://www.smwcentral.net/?p=section&a=details&id=12178)
4.  Use Floating IPS (Flips) to apply the `Daisy's_Crazy_Adventure.bps` patch. [Download Flips](https://www.smwcentral.net/?p=section&a=details&id=11474)
5.  Flips will output a `.smc` or `.sfc` file. Open this file in your emulator to play the game.

## Credits

### Tools

Lunar Magic - level editor
YYCHR - graphics editor
Snes9X - emulator
UberASM - ASM
AddmusicK - Music inserter
Asar - ASM
Effect Tool - HDMA editor
Blocreator - Block editor

### Patches

DKCR status bar by WhiteYoshiEgg
VRAM optimize by KevinM
kaizoman666 - horizontal wrap
Edit1754 and others - No More Sprite Tile Limits v1.2.1
Score remover by GreenHammerBro and WhiteYoshiEgg
Remove title screen movement by DiscoTheBat, LM stuff by Erik557
One File, One Player patch by Kevin
Tweaks v1.0 from SMWC

### UberASM

Airjump by HammerBrother
Cutscene by Blind Devil
Disable Buttons by janklorde
Free Vertical Scroll by Kevin
Horizontal Wrap by Thomas
Layer 2 Falls customization by Kevin
Some modified by me

### Blocks

Cannon blocks by HammerBrother
Player solid and sprite solid blocks by ASMagician Maks
One way blocks by HammerBrother
One use noteblock by Darolac
On/off collectable by Darolac
Spiny block by TheBourgyman
Sticky ceiling (magnet) by MellyMellouange
Wall jump block by xhsdf
Some created and modified by me

### Graphics

ClockworkNettie (https://twitter.com/weeble) - Daisy player sprite
_I modified some of the player sprites_
https://www.smwcentral.net/?p=section&a=details&id=33114 - Desert overworld
https://www.smwcentral.net/?p=section&a=details&id=21073 - Desert tileset
https://www.smwcentral.net/?p=section&a=details&id=26278 - Mountain background
https://www.smwcentral.net/?p=section&a=details&id=11703 - Moai heads
https://www.smwcentral.net/?p=section&a=details&id=15864 - Rocky tileset
https://www.smwcentral.net/?p=section&a=details&id=11735 - Asian tileset
https://www.smwcentral.net/?p=section&a=details&id=13071 - Forest tileset
https://www.smwcentral.net/?p=section&a=details&id=13045 - Layer 3 pyramids
https://www.smwcentral.net/?p=section&a=details&id=14597 - Layer 3 desert
https://www.smwcentral.net/?p=section&a=details&id=33114 - Desert overworld
Various Mario games
Some created and modified by me

### Music

Title | Game | Author | Location used

#### Overworld

Ruins | Super Mario Land | Hirokazu Tanaka | Overworld 1
Super Mario Land 2 Overworld | Super Mario Land 2 | Kazumi Totaka | Overworld 2
Crash Bash Warp Room | Crash Bash | Steve Duckworth | Overworld 3
Oriental Garden | Original | HaruMKT | Overworld 4

#### World 1

Birabuto Kingdom | Super Mario Land | Hirokazu Tanaka | Desert
Bloody Tears | Castlevania 2 | Remixed by Lui37 | Desert 2
Resurrections Part 1 and 4 | Celeste | Lena Raine, ported by maxodex | Snow

#### World 2

Muda Kingdom | Super Mario Land | Hirokazu Tanaka | Beach
A Thousand Leagues Below | Shovel Knight | Manami Matsumae | Water
Bramble Scramble Ensemble (Stickerbush Symphony Remix) | Donkey Kong Country 2 | David Wise, arr. Hooded Edge | Bramble

#### World 3

Hot Drinks | Wendy's Fast Food | Marvin Hawkins | Mountain
Factory | SMWC Vanilla Level Design Contest 8 | Dr. Tapeworm | Ruins
Super Mario Land Ruins Remix | Super Mario Land | Hirokazu Tanaka, midi by Andy Smith, arr. Daizo Dee Von | Ruins 2

#### World 4

Chai Kingdom | Super Mario Land | Hirokazu Tanaka | China
Disco Train | Donkey Kong Country 2 | David Wise | Rollercoaster
Arena 1 | One Must Fall 2097 | Kenny Chou | Forest Fire
Hundred Chain (The End of 1000 Years Arrange) | Original | Mr. | Final

#### Boss

Halfmoon | Kirby Super Star | Jun Ishikawa | Regular Boss
In the Final | Mario and Luigi: Bowser's Inside Story | Yoko Shimomura ported by Wakana | Final Boss

#### Win/Lose

Pizza Tower Boss Clear | Pizza Tower | Ronan "Mr. Sauceman" de Castel / ClascyJitto (Frostix) / Post Elvis | Boss clear
DKC Death | Donkey Kong Country | David Wise | Death

#### Cutscene

Oh, Daisy | Super Mario Land | Hirokazu Tanaka | Cutscene
Credits | Super Mario Land | Hirokazu Tanaka | Title
High In The Sky (SML Credits Remix) | Super Mario Land | Hirokazu Tanaka, arr. Hooded Edge | Ending

## Notes

Some assets including graphics, ASM, and blocks were created/modified by me.

## Changelog

06/11/2024 - Beta 1.0.0 released for playtesting.
06/13/2024 - Beta 1.1.0

- Added goal for final boss.
- Added pipes Daisy exits out of in Forest Fire Frenzy.

06/20/2024 - Beta 1.2.0

- Made it easier to get 1-UP in level 2.
- Made parts of Forest Fire Frenzy more sight-readable and easier.

6/22/2024 - Beta 1.2.1

- Removed one way wall from magnet level that caused Drybones to fall.

7/7/2024 - 1.0.0 released

- Small level changes
- Overworld path fixes

7/17/2024 - 1.1.0 released, level design changes

- Made magnet level easier and more forgiving.
- Added more 1-UPs in various places.
- Made Target Terror easier in some spots.
- Made Forest Fire Frenzy easier and made last section shorter.
- Various small changes to other levels.
