Here is Dr. Mario World. 7+ years of off and on work. I still didn't get to do the stuff that I planned to do and was officaly done with this back in early 2012 but I lost all my data on a HD crash and had to use a really old backup to restore the hack, so here it is.

You need a Super Mario World (U) [!] rom to play. Use the enclosed flips.exe to patch the ROM and the TUSH Header editor to add a header before patching it if the ROM doesn't have one already.

Known bugs and tips:

1. Remember that you can slide on the Big Boo.

2. The Yoshi coin sprite often shows a coin in a spot that its really not. 

3. Wario can dash on horizontal ropes, Goal walking, and some other stuff he shouldn't.

4. Metal Mario colors will look weird in some areas.

5. There are holes in certain underwater areas when you bash some blocks.

6. For some reason, Wario can't save his extra heart container to sram, and it will be gone the next time you load.

7. Remember you can smack enemies with the cape using the spin jump.

8. Use The Super Megavitamins (Metal Mario) to defeat tougher bosses. 

9. Theres a secret sub chapter which you collect a lot of germs that can go towards buying items.

10. Remember you can go through a boss when it's flashing.


Thanks and enjoy. 

Big thanks to icegoom for all that he done for me. He will be missed.