D.O.L.L.S.

a hack by Jordan

----------------



-- Hack Write-up --

On an ordinary day, Mario receives an unexpected letter from his old friend, Dr. Barry, inviting him to visit an anomaly research station nestled within a long-abandoned manor just outside the city. What begins as a curious invitation soon takes a dark turn. As Mario steps through the creaking front door, it slams shut behind him, trapping him inside. With only a few cryptic notes scattered on a nearby table to guide him, Mario begins to unravel the eerie secrets of the manor. But something feels off… where is the doctor? And what’s with all the strange little dolls scattered around?

D.O.L.L.S. is an atmospheric exploration hack where players guide Mario through the mysterious halls of a decaying mansion. Exploration is key—be sure to chart your path carefully, or you might find yourself lost in the depths of this foreboding manor. Even death won’t let Mario escape, and he will simply find himself back at the front door, ready to begin again.

Use Start+Select at any time to return back to the front door of the manor.



-- Author's Note --

Thank you for downloading D.O.L.L.S.

This hack has been a rewarding project to create, and it’s hoped that players enjoy working through its challenges. It’s recommended not to rush through the experience—take the time to explore and uncover what might be hidden around the game. A map is not included by design, so if tracking progress and locations is important, players are encouraged to create their own map or use another tracking method. While the hack is not locked, it is suggested to avoid using Lunar Magic for assistance when stuck, as doing so may lead to spoilers. Ultimately, however, the best way to enjoy the hack is however the player finds most enjoyable. Thank you again for giving D.O.L.L.S. a try, and it is hoped that you enjoy the experience.