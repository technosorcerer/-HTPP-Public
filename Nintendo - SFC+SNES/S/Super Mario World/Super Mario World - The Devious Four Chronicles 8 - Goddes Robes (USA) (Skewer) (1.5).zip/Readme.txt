----------------
-- Disclaimer --
----------------

I do not own the desert background and roto-discs, but all other graphics are mine.  Do not rip them without my permission, because
I will find out, and will hunt you down, and I will get you.

----------
-- Info --
----------

This is SMB3 styled hack.  There is no story in this demo version, so enjoy the level design please.
This hack works with Higan, ZSNES, SNES9x, and other emulators.
	Has only been tested on the Higan Accuracy Version

--------------------
-- Known Glitches --
--------------------
� For some reason, black boxes will randomly appear on Level 2.  This seems to happen only on level 2 and nowhere else???  This does not
	affect gameplay
� On accurate emulators, the intro text will "melt" away for some reason.  This does not affect gameplay.

--------------
-- Versions --
--------------

1.0 - Initial (Demo) Release

1.1 - Fixed multiple glitches involving Lunar Magic counting the Midway Point as a sprite and expanding level borders unneedlessly
	Fixed HDMA issues
	Fixed Message Boxes in 1-1
1.2 - Aesthetics change : Replaced most instances of Turn Blocks with Items to look like SMB3 styled Smashable Bricks.
1.3 - Fixed Red Coin glitch in the Grassland Castle
1.4 - Fixed Cutoff error with a goal point room.
1.5 - ACTUAL MAJOR UPDATE!
	Removed Desert Castle Boss "Morton" because he causes a crash.
	Fixed glitch with Fox Tia having no head while climbing a vine.