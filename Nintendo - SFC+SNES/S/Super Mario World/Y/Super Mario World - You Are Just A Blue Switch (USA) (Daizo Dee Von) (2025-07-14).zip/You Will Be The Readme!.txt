####################################################

            Y O U   A R E   J U S T   A
               B L U E   S W I T C H

        Questionable Level Design Contest #3
            1ST PLACE WINNER Expansion

             ------------------------

     From the maker of 100 Rooms of Enemies,
     "no name," R-ACK, ~omh~, and many other
     ROM Hacks: Daizo Dee Von.

                  VERSION:  1.02

####################################################

Thank you for those who downloaded this rom hack.
Those who don't know how to patch BPS files should
first download FLIPS from SMW Central's Tool
Section, then apply this to a clean Super Mario
World rom (if you're lucky to have one). To test
if it's applied successfully, you should see the
game start with a sequence where you're
tutorialized on how to be a blue switch. If you
see any Nintendo Presents logo at bootup, you are
just playing the original game.

YOU ARE JUST A BLUE SWITCH is a short 15 minute
romp where you play as the Blue Switch from the
BLUE SWITCH PALACE going on a journey from the
Forest of Illusion to Ludwig's Castle to pay Ludwig
Von Koopa a visit.

This hack serves as a sequel to DO NOT PRESS THE
YELLOW SWITCH (canon to the original 72hoQLDC entry,
not the upcoming "REPRESSED EDITION" release coming
soon). There's a few nods to that entry, so the
original or re-pressed edition can serve the purpose
of catching said references. :)

####################################################

WHAT TO EXPECT:
-Gameplay where you press L+R together to solidify
solid blocks, and get "power ups" to be able to
re-press yourself again.
-Janky Footballs (that are luckily fixed)
-A boss...or two?
-A good number of secrets.
-The credits are all in-game.

####################################################
		VERSIONS (SPOILERS)
####################################################

v1.03
	- Fixed the ending checkmark for the
	hidden ending.
	- Achnowledged entry to the previous
	room at the beginning of the game.
	- Herobrine Removed

v1.02
	- Added a hard variant of the boss
	- Added 2 new endings
	- Added overworld sequences
	- Added more music
	- Added new secrets
	- Added a checkpoint in area 2
	- Added a way to check which endings you got
	- Decheesed area 1
	- Fixed Footballs in area 2
	- Herobrine NOT Removed

v1.01
	- Altered the level design of area 2

v1.00 "The Questionable Release"
	- Initial Release

v0.00
	- Super Mario World