Hey, what's up and welcome to my hack! So you're here to see the TIPS and that's cool, but first here are the credits:

=== CREDITS ===
"Plok's House / Venge Thicket" - brickblock369 - https://www.smwcentral.net/?p=section&a=details&id=26458
"Super Mario 64 - Slider" - Anas - https://www.smwcentral.net/?p=section&a=details&id=34994
"Rhythm Heaven Megamix - Songbird Remix" - bebn legg - https://www.smwcentral.net/?p=section&a=details&id=28291
"Retry System" - Kevin, lx5, worldpeace - https://www.smwcentral.net/?p=section&a=details&id=26078
Various tweaks






SPOILERS UP AHEAD!!!


























REALLY!!










































=== TIP 1 ===

Press A to jump


=== TIP 2 ===

Hold A to jump higher and decrease Mario's falling speed


=== TIP 3 ===

Hold B to normal jump


=== TIP 4 ===

Hold Z to spin jump


=== TIP 5 ===

Hold L and R to pan the camera left and right, respectively. If you do this, you will never die again.


=== TIP 6 ===

Hold spacebar to charge up fireballs


=== TIP 7 ===

Hold enter to use bullet time (this has no timer or cooldown)


=== TIP 8 ===

Eat Red and Green mushrooms to gain Power and Life, respectively.


=== TIP 9 ===

Power and Life are mutually exclusive concepts


=== TIP 10 ===

You must be Super Mario when you touch the goal in order to not die and crash the game


=== TIP 11 ===

Hold S to ground pound


=== TIP 12 ===

                                                   


=== TIP 13 ===

Run while jumping to jump higher