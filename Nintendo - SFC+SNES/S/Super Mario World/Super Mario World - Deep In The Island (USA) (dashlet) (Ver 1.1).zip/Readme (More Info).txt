(Sorry if you find any spelling mistake, english it's not my main language)

Title                   : Deep In The Island
Proyect Started in      : Sep 23, 2021
Release date            : Jul 18, 2022
Author                  : dashlet
Tested In               : Snes9x
Difficulty              : Medium
Lenght                  : Short

///What Is Included///
-Seven Custom Levels           
-Custom Music
-Custom GFX
-Custom Sprites
-Custom ASM

///What is excluded///
-No Overworld
-Two Player Mode is disable

IF YOU WANT A CHALLENGE: Try to get all Yoshi Coins in each level. If that's not enought then try to do it without dying, good luck!

///Important note about keys///
You can only have ONE KEY AT THE TIME. If you die and you cant grab a key its beacuse you already got one you previously grab before you die. I know this is confusing but it works this way due to some limitations.

---Description---

This is the first and probably only hack i will ever publish online. Its very short but i tried to make it as unique as posible bethween every level. Im quite happy with the result and the experience i gain from doing this. 
The hack originaly was going to have 13 levels but as i got into another things i really never managed to complete the goal. You can find more info about the levels down below. 

Also overworld was cut beacuse of time issues (Im also really bad at designing one). Two player mode is disable beacuse i wanted this hack to be only a singleplayer experience, it also help me to not bother with two player mode posible bugs or problems.

---Major Differences with SMW---

-Spin Jumping with a Fire Flower not longer throws fireballs.
-Flying its now disable
-Manual camera movement its disable.
-Overworld its disable, the game will autosave everytime you complete a level.
-You can now not longer have Mushrooms inside your Itembox.
-Yoshi its now a freaking skeleton.

---Levels By Order---
Level 1: Not So Deep Yet
Music used: Donkey Kong Country 1 - DK Island Swing
This level originally was a lot more non linear, featuring even more multiple paths. Later on i cut down most of them, beacuse for a first level they felt overwhelming.

Level 2: The Ancient Trees
Music used: Trials of Mana (Seiken Densetsu 3) - Powell
I wanted to be very experimental with exits on this level, that's why you find a lot of them. The level ends with a simple puzzle that originaly used On and Off Blocks, but was later discarded due to limitations. This level is inspired by Brutal Mario World, which also uses trees and puzzle elements for a level. Carol used Powell for the music of the level too.

Level 3: What A Long Day!
Music used: Super Mario 3D World - Super Bell Hill
What a long level this is! This is the first level in which i wanted to create some sort of history using level design. You see, during the day theres a lot of "Koopa Like" enemies trying to stop Mario. In the afthernoon there's more animal like enemies and also the Koopa Troops left the area, leaving only Bullet Bill generators. Finally, during the night enemies are sleeping. 

Level 4: Wormhole
Music used: Inner Nights by DoubleThink, Milon Luxy
Im very proud of this level. The name as well as the gimmick is inspired by MAP04 of TNT Evilution (A Doom 2 map pack, from Final Doom). 
This level originally was going to have some text messages which revealed some background lore about the place and other stuff. They were supposed messages left behind by a Koopa, but in the end, it was cut down due to Layer3 shenanigans. This level also used to feature the Dry Bones Yoshi that appears at the end credits. You were supposed to use him to reach the goal, but sadly, it was removed due to bugs and limitations.

Level 5: Sewage Man
Music used: Doom - Dark Halls
This level originally was intended to be related with the cut Factory Level, thats the reason you see Mecha Koopas and Electricity. At the beginning Mario sees a factory which seems to be seal and heavly secure, so naturally, he finds another way in (sewage). By the end of the level, he gets inside the factory for a short look of what the next level it's about. 
Also the Blarggs in this level were supposed to be green but due to a palette error they end up looking yellow, which actually end up liking even more. 

Level 6: Bramble Path
Music used: Hollow Knight - Greenpath
A combination of DKC2 brambles and Greenpath. This level originally was harder, it featured more puzzles and it was longer. This is the last level i made for the hack, and im quite happy about it.

Level 7: Sky Tower
Music used: Sky Tower - Pokemon Mystery Dungeon Red/Blue Rescue Team
This level originally was intended to be the secret level of the hack. You used to unlocked inside level 3. It featured a puzzle you needed to solve to get to a alternative path in the Sky. You can still see this altenative path inside Lunar Magic if you want (Level 18). 
The level inpiration is obvious i think, but as i couldn't find a Rayquaza custom boss (Im joking here by the way) i decided to use Fry Guy instead (Hey its the sun, it kinda makes sense!).

NOW, for the cut levels i can tell you some things you may find insteresting:
-First we have the Factory Level, which actual name is KoopaIndustries.Inc (A reference to DKC1). It was going to use DKC3 Nuts and Bolts track and featured some special Mecha Koopas as well as some new Gimmicks like conveyor belts. 
-I also had in mind a Backtracking level, in which you needed to get all Yoshi Coins to get to the exit. The exit was at the beginning of the level, blocked by blocks you can only get through if you have all Yoshi Coins.
-I also thought of a swamp level at some point, heavly inspired by those you find in DKC2.


---Credits--- 
All custom content was made using SMW Central Assets. Thank you so much community for making my hack even posible.

Special Shoutouts To:
Gamma V (This guy right here makes some of the most vanilla like GFX i ever seen in SMW Central. His hacks are also amazing, check them out!)

KevinM (Thank you KevinM, a lot of the assets i used comes from you)

FuSoYa (Creator of Lunar Magic, the tool you NEED for SMW Hacking)

WhiteYoshiEgg (Main creator of A Plumber For All Seasons, the best SMW rom hack i played so far. You literally inspired me to finish my hack and also helped me with some assets)

Carol (For creating the first hack i had ever play (Brutal/Kitiku Mario World) and also inspired me to start hacking at all (I think i started in 2012)

And YOU for reading this, thank you!

And also all this people!!:
Carld923
Rykon-V73
Ayami
Len13
UnderWay
SuperTails
LevelEngine
Kixune
FalconPunch
Dr.TapeWorm
SacredSilverYoshi
NBTD
ShrooboidBrat
Dark Prince
Anoraku
Themorgana
Schwa
RussianMan
MykeyK
Isikoro
Erik
Edit1754
IceGuy
Mathie
1524
Romi
Von Fahrenheit
Major Flare
EtirnityLarva
Dispari Scuro
JamesD28
Imamelia
MarkAlarm
Darolak
Ersanio
Thomas
SmkDan
Sonikku
TheBiob
Eminus
Milon Luxy
LadiesMan217
Lui
Vitor Vilela
MusicalMan
Sayuri
Com_Poser
Maxodex
DoubleThink
Lumy
Wakana
DMB
HammerBrother
Davros
Alcaro
Brolencho
GreenHammerBro
Edit1754
MarioFanGamer
