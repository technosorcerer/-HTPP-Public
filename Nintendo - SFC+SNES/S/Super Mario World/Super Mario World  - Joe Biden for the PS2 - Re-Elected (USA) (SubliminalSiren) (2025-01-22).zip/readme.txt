Use with:

(No Intro)
Super Mario World (USA).sfc
cdd3c8c37322978ca8669b34bc89c804
B19ED489