This is a 17-exit Kaizo hack dedicated to an amazing Kaizo player named CaptainCanuck87. It was in development for just over a year, and was actually intended as a collab at first.

The difficulty ranges quite a bit from Invictus-level to around Casio-level. Chocolate is a very big aspect of this hack. There is a secret portrait in every level, though there's no reward for finding all of them.

PLEASE NOTE:
The level design philosophy of this hack can make some sections very tricky to figure out blind, so feel free to watch the clear videos if you get stuck: https://www.youtube.com/playlist?list=PL1oA5AhbeH3JgHluFJzNu1kTUKRuYmj6z

Also, this uses SA-1, so get an SD2SNES/FXPAK, or just play on emulator.

If you have a save file from before 1.2, it will likely have issues with 1.2 and beyond due to an added per-level death counter.
