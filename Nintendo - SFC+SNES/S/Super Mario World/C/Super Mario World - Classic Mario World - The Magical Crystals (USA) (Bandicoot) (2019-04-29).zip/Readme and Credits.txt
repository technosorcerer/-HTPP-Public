Classic Mario World 1:The Magical Crystals is a traditional hack where you go on a adventure with Mario through 9 new worlds 
with new levels, custom music, custom gfx and more
It was my first hack here at smwcentral and today I'm re-releasing a updated and defitive version with everything fixed.
This new version fixes the problems left by the previous version released in 2017 and add new features like:
- Expand SRAM Save
- Safe fall patch
- Bug fixes

History:
While Mario and Peach visited Yoshi in dinosaur land Bowser found a new source of power known as the Magical crystals,
there little small crystals had the power to make his owner stronger than ever, with this power at his hand
Bowser kidnapped Princess Peach and all Yoshi's friends, with that Mario and Yoshi decides to go on an adventure
to save them!

Credits:
Hack Made by: Bandicoot
Original Game by: Nintendo

Custom Music:
NeoSigma
Izuna
Roberto zampari
LadiesMan217	
Wakana
Slash Man
Dan
SNN
Moose
Artic Avenger
4803
Qbee
SuperTails
Xcnis
Neocar
L923
Midyguy
Red Chameleon
Pink Gold Peach
Black Hawk
Gamma V
Jascha
J.52905
Crispy Yoshi
Redngreen
Nobuo Uematsu
Counterfeit
Decoyblimp
Ahzuka O.
Worldpeace
Hajime H.
Masterlink
Atma

ASM:
Tornado
Bandicoot
Mario90
Ladida
Ramp202
Imammelia
Alcaro
LX5 
MarioE 
Tattletale
aCrowned
Maxx

Custom Sprites:
4803
Roy
Dahnamics
Medic
Lolcats
Yoshicookie Z
Koops
Manuz OW Hacker
Iceman
Imammelia
IXTAB
Chdata
Koyuki
Yoshi987
Huflungdu
Le cont Niark
Mykeyk
Romi
Icegoom
SMWEdit
Davros
Alcaro
SMKDan

Custom Blocks:
Varn
Ninjaboy
Mzuenny
Bigal
Tmercwins
Jhonsmith41
MarioEdit
JackSpades
Greenhammerbro
Koopster
Manuz OW Hacker
Broozer
Nesquik Bunny

Special Thanks:
Gamma V
Mirran
Iceman
Manuz OW Hacker
Koyuki
Tornado
Dahnamics


Thanks for Playing!