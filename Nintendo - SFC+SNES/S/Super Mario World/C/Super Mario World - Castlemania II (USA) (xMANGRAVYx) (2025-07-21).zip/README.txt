CASTLEMANIA II
by xMANGRAVYx

6 exits
Standard/Hard Difficulty

'An unsettling wind sweeps the land. A Castle shrouded in darkness towers in the distance, and the dead rise from the grave once again..'
Count Koopula is back to his wicked ways in the second entry of 'Castlemania'. Mario has the unenviable task of tracking down the monster and bringing peace back to the land.

This romhack is the sequel to my romhack 'Castlemania' released in summer 2024. It includes custom powerups, cutscenes, secrets and custom bosses never before seen in Super Mario World. My main priority with this entry was to build from the formula of the original while adding new and improved features expected in a sequel. Each level is divided by sections that end with a boss fight as expected by traditional Castlevania games of which this series is inspired by. Some bosses will not take damage by powerups as these can be exploited leading to underwhelming battles.

The final level is comprised of castle sections stitched together by filler rooms selected at random. Entering a red door at the end of a castle section will result in the player entering 1 of 4 different rooms. This design choice was meant to make each player experience feel different and fresh compared to the other. It also falls in-line with the random nature of Dracula's Castle and how it constantly evolves.

A lot of time, passion and stress went into the making of this game, so I really hope you enjoy. 
Good luck, have fun and THANK YOU FOR PLAYING!

I would like to take the opportunity to give huge thanks to some very important people involved in this project. These people have gone above and beyond to help me bring you the best experience possible, and I couldn't have done it without them. Please join me in recognizing the following people:

MY PLAYTESTERS: CheesePopps, MTheOrdinaryGamer, S3pti, SuperDerek908, RangerMan27, GCracka, Saphros, CalamityJo163, Anorakun, BoonieVeteran and Seb
	Thank you all so much for all the love and support you've shown me and this project. You all provided feedback instrumental to making this hack what it is and I 		truly can't thank you enough for your time and dedication. I'll never forget the feeling of defeat I felt when Derek cut through the wall in level 1 with a shell.. or 		when MTheOrdinaryGamer beat a section so fast it killed him (LMAO). You're the best testers a guy could ever ask for and I hope you all know how appreciative I am 	of everything you do.

KOOPSTER:
	Koop has given me so much of his time during this project. What started as a simple question I sent him regarding an issue I had with one of his patches turned into a 		pretty solid friendship and someone I relied heavily on throughout development. He took it upon himself to better countless game mechanics, identify possible design 		flaws and gave constructive criticism. His fingerprints can be seen all across the game, from pipe interactions, to powerup processes, as well as countless others. He's 		also responsible for bringing xMANGRAVYx fan favorite sprite 'Denise' to life in the form of a boss in 'Bridge of Sorrows'. The amount of time and effort Koopster has 		given this project can't be understated... simply put: this hack wouldnt be nearly as polished as it is without his help. Check him out on Bluesky:
	koopster.bsky.social

ANONIMZWX:
	While the original Castlemania reviews were overwhelmingly positive- some players had a few complaints. The main issue I saw from player feedback of the original 		was how underwhelming the final boss felt to them - which I can't disagree. I did the best I could with what I know of ASM but it is a clear weakness of mine..
	I knew when I started developing a sequel I needed to rectify player feedback and try new things.. so I started asking around to see if anyone would be willing to 		work with me on a final boss concept. After weeks of asking around I was pointed in the direction of Anonimzwx. I had been shut down enough times by then that I 		was feeling somewhat hopeless and that I would have to once again settle for something basic and standard, but he was eager to hear about what I envisioned the 		final boss to be. We discussed concepts for a few weeks, worked together on a vision of how things would work, and he took on the role of 'Final Boss Designer' of 		Castlemania II. Development was slow at first, and I worried countless times this hack may never see the light of day, but as the project slowly came to fruition I was 		more and more proud of my decision and who I chose for the task. He and I spent countless hours over months comparing notes, re-working assets, testing... and at 		the end of the day I hope you (the player) can appreciate his final product. I personally am beyond happy with the final product, and look froward to seeing player 		reactions to the finale of Castlemania II. Please be sure to follow him on Youtube and X so more people can see his work:
	https://x.com/anonimzwx
	https://www.youtube.com/@anonimzwx

Finally - thank you to the player. I see your video uploads, your streams, and some of you even wrote articles about the original. I appreciate your support more than you'll ever know.