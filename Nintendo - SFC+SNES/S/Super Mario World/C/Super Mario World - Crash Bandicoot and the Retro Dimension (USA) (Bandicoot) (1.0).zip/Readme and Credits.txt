Crash Bandicoot and the Retro Dimension 

This hack aims to mix the elements of a Crash Bandicoot game into Super Mario World.
You will be playing as our favorite Marsupial Crash Bandicoot and the hack have been designed to feel like a proper Crash game, so lots
of changes, tweaks and elements have been implemented to achieve this goal. 
With that being said, this hack is pretty much a full-on Crash Bandicoot game made within Super Mario World
featuring 86 levels with 102 exits to find, and also 94 gems&86 relics to collect.
It also features new mechanics such as Crash being able to use his iconic spin attack at any time, custom graphics, lots of custom music(especially from the Crash Bandicoot franchise),
and lots of ASM. 
I hope you enjoy it. 
--------------------------------------------------------
Story:
Dr. Cortex has built a dimensional Machine to travel between dimensions, conquering them and obtaining his
Crystals and gems to use in their world domination plans,however this evil plan go wrong and both Cortex,his lackeys and the Bandicoots 
get sent to the misterious dimension 69 which is known as the retro dimension, in this dimension rules are diferent and everything looks like a retro game inspired world.
Now Crash must go on a adventure to stop his enemy goals and find a way back home!

----------------
How to patch the game and play?

You will need:
- A american unmodified Super Mario world rom
- Floating IPS
- The .bps with the language you want
- A Super Nintendo emulator

Open Floating IPS, click apply patch, select the Super Mario world rom,
on the next screen select the .bps of your choice(english or portuguese)
and it's done!
Use a Super Nintendo emulator to play or put it on a everdrive and
play on a real Super Nintendo!
Have fun!


----------Credits------------
Level Design & Game Design:
Bandicoot
--------------------------------------------
Beta Testers:
Bandicoot
N450
Alansanchez412
lo fang 123
marioisradical
Green Jerry
Agent49w2f
-------------------------------------------------------------
Special Thanks:
LinkstormZ - For making the Crash Bandicoot player graphics and wumpa fruit graphics.
Pink Gold Peach - For porting lots of Crash Bandicoot songs to SMW along the years 
Thomas - Coding for Crash's spin
Fiercethebandit - Spritesheets used to create graphics for classic Crash Bandicoot characters
Koopster - help making powerups stationary
Arinsu - Help with TNT sprite
h.carrell - Porting the tada-daah sample to nintendo presents screen
Green Jerry - Huge help with beta testing and text writting
N450 - huge help with beta testing, bug testing and cutoffs fixes
Alansanches412 - huge help with beta testing
---------------------------------------------------------------
Custom Graphics:
Bandicoot
Pink Gold Peach
Gamma V
Bonobi 
LinkstormZ
Duraner Hawkeye
Teyla
Neexy
Fiercethebandit
Dan
hackmania
Ayami
Blizzard Buffalo 
edgar
cheeyev
NopeContest
kirbydavy
AmperSam
DanxInc 
E-man38 
Rykon-V73
Clougo 
Random Talking Bush
Segment1Zone2
yoshifanatic
DynastyLobster
ShadowMistressYuko
TheOrangeToad
Natsuz2
-----------------------------------------------
Custom Blocks:
Bandicoot
HammerBrother
Telinc1
TheXander
Darolac
ShadowMistressYuko
JackTheSpades
Iceguy
Infrared
quietmason
Alcaro 
Bio
lx5
Roy
Sonikku
MarioE
Sind
Ersanio
RussianMan
K3fka
wye
Davros
mikeyk
MarioFanGamer
HuFlungDu
wiiqwertyuiop
---------------------------------------------------------------
Custom  Music:
Pink Gold Peach
worldpeace
Slash Man
Kevin
Darius
Lui
Harumi
musicalman
Ice Man
DanTheVP
Tamaki
KevinM
Wakana
CK Crash
RussianMan
Hooded Edge
7 up
xyz600sp
CrimsonZN
Maxodex
Xulon
com_poser
schema_tuna
Infinity
Hazel
Isikoro
ladiesman217
Bandicoot
---------------------------------------------------------------
ASM&Patches:
Thomas
Koopster
Glyph Phoenix
BMF
Iceman
mikeyk
Ladida
Alcaro
MarioFanGamer
Sonikku
lx5
Aiyo  
Imamelia
Roy
Romi
HammerBrother
JackTheSpades
MathOnNapkins
Arujus
Noobish Noobsicle
VitorVilela
KevinM
Tattletale
WhiteYoshiEgg
ASMagician Maks
dtothefourth
Kaizoman
Kevin 
worldpeace
MrCheeze
Major Flare
Fuzzyfreak
Darolac
------------------------------------------------------------
Custom sprites:
Romi
Mikeyk
Russianman
Sonikku
yoshicookiezeus
smkdan
leod
imamelia
Mandew
Nesquik Bunny
Darolac
lion
SMWEdit
Arinsu
MellyMellouange
Ixtab
Major Flare
andy_k_250
Arinsu
TheBiob
Koopster
Isikoro
JackTheSpades
Blind Devil
WhiteYoshiEgg
HuFlungDu
KevinM
Dtothefourth
Chdata
Fakescaper
Thomas
EternityLarva
Tattletale
Mirumo
Koyuki
-------------------------------------------------------------
Tools:
Fusoya
Kipernal
Alcaro
Atari2.0
JackTheSpades 
Tattletale
TheBiob
p4plus2
Fernap
Vitor Vilela
mikeyk
uyuyuy99
dtothefourth


