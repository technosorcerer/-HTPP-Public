Classic Mario World 2:The Great Alliance(Definitive Version)

This hack is a sequel to my previous hack Classic Mario World: The Magical Crystals.
It contains 9 new worlds filled with new levels and 120 exits to find.

Two years ago I released an improved version on Classic Mario world 1:The Magical Crystals fixing some issues and improving level design and music, so I decided to make the same to this hack but in a whole new level since it really needed.

This version is a improved version over the original release of this hack in 2014, this hack in specific had a very rushed development due to my lack of free time to work on it at the time due to my personal life problems.
The rushed development unfortunaly made effect on the quality of the hack, levels had problems like repetition,were way too long, bugs, glitches, bad level design etc.
In a nutshell this was the weakest entry in the Classic Mario World series I made, with that in mind I decided to rework this hack and improve what can be improved so the players can have a better experience with it.
And so we have it! The definitive and improved version.
 
After being defeated in the last adventure Mario sealed the fragments of the magical crystals and sent them to Rosalina on her observatory so she can find some distant planet to dispatch it.
Meanwhile Bowser wants revenge for having his plans interrupted by Mario, so he reunites various villains from the mushroom kingdom lands and form a great alliance of evil to defeat Mario.

This hack contains:
-93 new levels
-120 exits to find
-New map
-New level design
-Improved game mechanics
-some few custom gfx
-New soundtrack(custom music, now using AddmusicK finally!)
-Custom sprites
-ASM
-Patches
________________________________________________
Some changes made in this new version:

-Most of the levels had their lenght reduced, some even had entire sections removed, with this change levels didnt overstay their welcome and become less repetitive and more intuitive and fun compared to the original version.

-A LOT of changes in level designs,especially in levels that were very bland and boring, but dont expect a miracle, because I kept the hack as close to the original, unless I remade the entire hack from ground up it would be impossible to make the level design better. 

-Added new game mechanics:hability to change the arc of the fireball, safe fall patch, better powerdown, goal point coins,etc. 

-Music now use Addmusic K instead of Addmusic 4.05 which didnt work on some emulators.

-New translation to English since the original had bad grammar mistakes and new translation to Brazilian portuguese.
_____________________________________________________
Credit list: 

Level Design:
Bandicoot

Custom GFX:
Gamma V
JJAMES
Bandicoot

-----------------
New soundtrack:

Masterlink
Gamma V
Wakana
imamelia
KKevinM
gibbl
6646
Counterfeit
LadiesMan217	
Lui37
DAA234
MercuryPenny
Sayuri
Crispy
nicetas_c	
Izuna
NaroGugul
Jimmy
Zagronia
Giftshaven
Moose
Decoy Blimp
Mogsiah
tcdw
Pink Gold Peach
MaxodeX
Jimmy52905
Atma
marioVSshadow
Isikoro
Harumi Makoto
Slash Man
CrispyYoshi
Dark Mario Bros
TheInsanity115
DanTheVP
MidiGuyDP
Pinci
Roberto Zampari
Todd
Darius
Leopold McGinnis
-------------------------
Original CMW2 version Music:
snn
moose
iceman
artic avenger
4803
qbee
xcnis
NeoCarl923
Tornado
Midyguy
Silver Scarlet
Red Chameleon
Black Hawk
Gamma V
Jascha
Jimmy 52905
Crispy Yoshi
Nobuo Uematsu
Counterfeit
Azuhka Ohta
WorldPeace
Hajime Hirasawa
REdngreen
Masterlink
And Some others
-----------

ASM:
Alcaro
aCrowned
MarioFanGamer	
Erik
LX5
Maxx
Roy
MarioE
Tattletale
ladida
discoman
ramp202
KilloZapit
DiscoMan
MathOnNapkins
imamelia
------------------

Sprites:
dahnamics
ersanio
medic
roy
lolcats5439
yoshcoockiezeus
4803
koops
manuz ow hacker
iceman
ixtab
chdata
koyuki
yoshi987
huflundu
lecontniark
mikeyk
romi
icegoom
smwedit
Davros
Schwa
Alcaro
smkdan

-----------------------------
Blocks:

Varn
Ninjaboy
mzuenny
bigal
tmerswims
jhonmith41
marioedit
JackTheSpades
GreenHammerBro
Koopster
Manuz OW Hacker
Broozer
tmercswims
Nesquik Bunny

----------------------------
Special thanks:
Gamma V
Iceman
Manuz ow hacker
Miran
Mario90
All Brazilian players and everyone in SMWCentral.







