v1.1

- fixed softlock potential in 5-4