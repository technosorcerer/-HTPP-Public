Over the course of 12 days, starting December 25th, I had built one level each day for 12 days, in the spirit of the 12 Days of Christmas, which was already done as a level design contest. It proved difficult executing all these new ideas and even gimmicks day after day.

With another 2 years having passed by, I've only gotten better at coming up with new and crazy level ideas, which had really started since 2014. I hope this assortment of experiemtal gimmicky levels is not only fun, but also reasonably balanced. Good luck!

- levelengine

P.S. There are 12 exits in all, and one moon (in the Final Countdown), and Dragon Coins in every level except for Spiritual Guidance. Can you get all this stuff?

SPRITES:
mikeyk
Davros
imamelia
Ladida
Jagfillit
andy_k_250
Le Comte Niark
himajin
Dispari Scuro
Chdata

BLOCKS:
Sind
JackTheSpades
PatPatPat
imjake9

GRAPHICS:
Hobz
Sonikku
Pac

SPECIAL THANKS:
FuSoYa
JackTheSpades
Alcaro
Kipernal
myself
