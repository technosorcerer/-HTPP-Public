
 ▄▄▄▄▄▄▄▄▄▄▄  ▄         ▄  ▄▄▄▄▄▄▄▄▄▄▄  ▄▄        ▄  ▄         ▄  ▄▄▄▄▄▄▄▄▄▄▄ 
▐░░░░░░░░░░░▌▐░▌       ▐░▌▐░░░░░░░░░░░▌▐░░▌      ▐░▌▐░▌       ▐░▌▐░░░░░░░░░░░▌
▐░█▀▀▀▀▀▀▀▀▀ ▐░▌       ▐░▌▐░█▀▀▀▀▀▀▀▀▀ ▐░▌░▌     ▐░▌▐░▌       ▐░▌▐░█▀▀▀▀▀▀▀▀▀ 
▐░▌          ▐░▌       ▐░▌▐░▌          ▐░▌▐░▌    ▐░▌▐░▌       ▐░▌▐░▌          
▐░▌          ▐░█▄▄▄▄▄▄▄█░▌▐░▌ ▄▄▄▄▄▄▄▄ ▐░▌ ▐░▌   ▐░▌▐░▌       ▐░▌▐░█▄▄▄▄▄▄▄▄▄ 
▐░▌          ▐░░░░░░░░░░░▌▐░▌▐░░░░░░░░▌▐░▌  ▐░▌  ▐░▌▐░▌       ▐░▌▐░░░░░░░░░░░▌
▐░▌           ▀▀▀▀█░█▀▀▀▀ ▐░▌ ▀▀▀▀▀▀█░▌▐░▌   ▐░▌ ▐░▌▐░▌       ▐░▌ ▀▀▀▀▀▀▀▀▀█░▌
▐░▌               ▐░▌     ▐░▌       ▐░▌▐░▌    ▐░▌▐░▌▐░▌       ▐░▌          ▐░▌
▐░█▄▄▄▄▄▄▄▄▄      ▐░▌     ▐░█▄▄▄▄▄▄▄█░▌▐░▌     ▐░▐░▌▐░█▄▄▄▄▄▄▄█░▌ ▄▄▄▄▄▄▄▄▄█░▌
▐░░░░░░░░░░░▌     ▐░▌     ▐░░░░░░░░░░░▌▐░▌      ▐░░▌▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌
 ▀▀▀▀▀▀▀▀▀▀▀       ▀       ▀▀▀▀▀▀▀▀▀▀▀  ▀        ▀▀  ▀▀▀▀▀▀▀▀▀▀▀  ▀▀▀▀▀▀▀▀▀▀▀ 

by oyok


------------------
|  Info          |
------------------

This hack was started in early 2021, and I thought I had it mostly wrapped in September 2022, but got stuck on a game breaking bug and not knowing how to make an overworld.

Three years later, I decided to pick it back up and finish it.  After a name change, and extensive revisions, this is the result. I did not hold back with my recent revisions, and "nerfed" a ton of sections, even deleted half of one level and brought back a section that was previously scrapped.

This hack is dedicated to all the games that had an impact on me growing up, or even as an adult.  Every song, every custom graphic (in the secret rooms), and the dumb story all make for a tribute of sorts to my upbringing in the NES and SNES era.

There are a few secret rooms throughout the hack.  They serve no purpose other than to provide a moment to listen to the music and enjoy the scenery. Some of them don't even have message boxes. Just take a moment to rest in these rooms, no need to find any deep meaning or usage from them.

You cannot start+select to exit levels, use the "EXIT" option in the retry menu.  Yes, it's the old school retry menu. 

Press "select" at any time on the overworld to save your progress, INCLUDING checkpoints.  You will also get a save prompt after every level.

Thank you for playing and I hope you enjoy my hack!


-------------
|  CREDITS  |
-------------

Sprites:
  Wiggler Disassembly - Kevin
  Custom Line Guided Rope - Kevin
  Custom Timed Lift - Davros
  Big Boo Boss - Davros
  Koopa Shell Disassembly - Kevin
  Platform Megapack - Mandew
  Ball 'n Chain Disassembly - yoshicookiezeus
  Thwomp Pack - Tattletale
  Line Guided Any Sprite - dtothefourth, Kevin
  Floating Skulls Disassembly - yoshicookiezeus
  Flyin' Disco Shell - RussianMan
  Flame Dino Rhino - mikeyk, edited by oyok
  Customizable Reznor v1.2 - Kevin
  Betterer Boss Bass - Sonikku
  Tryclyde - dahnamics, edited by oyok
  Stationary Spiny/Swooper - RussianMan
  Turn Block Bridge - RealLink


Blocks:
  Mario/Sprite Only Blocks - Aquas, Koopster, ASMagician, Maks
  Camera Scrolling Block - MagmaMouse
  Hurt / Death Block for Kaizo / Pit Hacks - dacin
  Switch Pack - MarioE
  Question Mark Blocks - MarioFanGamer, lx5
  Object Powerup Blocks - HammerBrother
  Custom Conveyor Blocks v1.0 - EternityLarva
  Bounceless on/off switch block - 	HammerBrother
  On/Off Switches (Single Hit and State Changing) - dogemaster
  Throw Blocks Pack - HammerBrother
  Donut Lift - Davros, mikeyk
  Force Yoshi Dismount - JamesD28
  Customizable Sprite Killer - Nowieso
  

ASM:
  Layer 2 auto-scroll - Ayami
  Exit by Falling Offscreen - Kevin
  HDMA Gradient (ASM From Donburi Fields BG GFX pack by Anorakun) - edited by oyok

Music:
  
  - Final Fantasy VII - Anxious Heart
     Nobuo Uematsu
      Ported by Ahrion

  - Super Mario RPG: Legend of the Seven Stars - Welcome to Booster Tower
     Yoko Shimomura
       Ported by Kevin

  - Ogre Battle - Old Man's Prayer
     Hitoshi Sakimoto
       Ported by Nanako

  - Super Mario Bros. 3 - World 1
     Koji Kondo
       Ported by Segment1Zone2

  - Super Mario Odyssey - Steam Gardens
     Koji Kondo
       Ported by HaruMKT

  - El Viento - Stage 1 (New York City)
     Motoi Sakuraba
       Ported by Bak Sangwoo

  - Donkey Kong Country - Fear Factory
     David Wise
       Ported by RednGreen

  - Super Metrioid - Various Songs
     Kenji Yamamoto and Minako Hamano
       Ported by Kevin

  - Final Fantasy VI - The Veldt
     Nobuo Uematsu
       Ported by Kevin
  
  - Final Fantasy VI - The Decisive Battle
     Nobuo Uematsu
       Ported by Vaelstraza

  - Top Gear - Las Vegas
     Barry Leitch
       Ported by Teows

  - The Legend of Zelda: A Link to the Past - Hyrule Castle
     Koji Kondo
       Ported by AntiDuck

  - Donkey Kong Country 2: Diddy's Kong Quest - Krook's March
     David Wise
       Ported by Slash Man
      
  - Radical Dreamers - Wind Ambience
     Yasunori Mitsuda
       Ported by Kevin
 
  - Romancing Saga 3 - The Last Battle
     Kenji Ito
       Ported by Maxodex

  - Donkey Kong Country - The Credits Concerto
     David Wise
       Ported by HaruMKT

  - Metal Slug 4 - Final Madness
     Toshikazu Tanaka
       Ported by Wakana

  - Radical Dreamers - River Ambience
     Yasunori Mitsuda
       Ported by Kevin
  
  - Ecco the Dolphin - Two Tides
     Spencer Nilsen
       Ported by Anonymous
  
  - Undertale - Fallen Down
     Toby Fox
       Ported by Teows

  - EarthBound - Giygas' Intro
     Keiichi Suzuki and Hirokazu 'Hip' Tanaka
       Ported by Kevin

  - Starry Beach [original]
     Composed by Pinci
  
  - F-Zero - Death Wind 
     Yumiko Kanki and Naoto Ishida
       Ported by Milon Luxy

  - Final Fantasy IV - The Final Battle
    Nobuo Uematsu
      Ported by Kevin

  - Final Fantasy VII - Interrupted By Fireworks
    Nobuo Uematsu
      Ported by Ahrion

  - F-Zero Lost Life
    Yumiko Kanki and Naoto Ishida
      Ported by Dippy


Graphics:
  Super Mario World - 16×16 Post-Scaled Font - 	HarvettFox96
  SimSun (Zhongyi Songti) - Nanako
  The Legend of Zelda (FDS) - Font - Green Jerry
  Super Mario Maker - Doors - zAce08xZ
  Super Tetris 3 - Magical Space 3 - 	Brutapode89
  Super Mario RPG: Legend of the Seven Stars - Booster Hill - Mogu94
  Super Metroid - Norfair (Superheated Cavern) - spooonsss
  Super Mario All-Stars: Super Mario Bros. 3 - Mist - ShadowMistressYuko
  Chrono Trigger - Death Peak (Mountains) - Anorakun


Patches:
  Retry -
    	Kevin
      lx5
      worldpeace
  Sprite scroll fix - GreenHammerBro
  No More Sprite Tile Limits -
    Edit1754
    MathOnNapkins
    Arujus
    VitorVilela
    Tattletale
    Kevin
  Frame Rule Patch - ?
  Nuke Statusbar - Lui
  Release Bulk - Beta Logic
  Offscreen Indicator - Thomas
  Double Eat Glitch Fix - Maarfy, Thomas
  Walljump/Note Block Glitch Fix v1.6 - lolcats439
  Placeable (Kicked) Throw Block - Kevin

Testers:
  ripjammer
  KaraJitsu
  fanfan21
  snadge
