Contents:
 1. Authorship Notes
 2. Song List
 3. Patch List

+----------------+
|Authorship Notes|
+----------------+
Coin Quest 2:
 NewPointless made the terrain for this level, and JeepySol placed the coins and sprites afterwards.
 
Cold-Blooded Cavern:
 Contributors submitted rooms with the chosen gimmick.
 
 Room 1-1: NewPointless
 Room 1-2: JeepySol
 Room 1-3: Donkeymint
 Room 2-1: Buflen
 Room 2-2: JeepySol
 Room 2-3: Buflen
 Room 3-1: MmmDoggy
 Room 3-2: MmmDoggy
 Room 3-3: JeepySol
 Room 4-1: Scags
 Room 4-2: Donkeymint
 Room 4-3: Buflen

Randomly Designed:
 Screens were added one at a time by different designers, but they were required to use 2 randomly chosen game elements.

A Game of Telephone:
 JeepySol and MmmDoggy each made a section without testing it, and then they traded and refined each other's sections.

Butternut Squashed:
 Setups were added one at a time by different designers, and then the whole thing was polished collectively.

Brakkie's Blocks:
 Donkeymint made this level with Brakkie's ASM.

My Way Highway:
 Participants took turns adding setups, and while they designed their setup, they also had complete creative freedom with every other part of the level.

Wizard Hat and Robe:
 Like Brakkie's Blocks, Donkeymint made this level with Brakkie's ASM.

The Lost Woods:
 Designers submitted rooms loosely in the style of an old-school Kaizo castle, including no custom blocks.
 
 Section 1:
  Ball 'n' Chain Room: NewPointless
  Paragoomba and Bubble Room: NewPointless
  Bat and Football Room: Scags
  Piranha and Saw Room: JeepySol
  RNG Dolphin Room: MmmDoggy
  Line-Guided and Carrot Platform Room: Buflen
  Bouncing Parakoopa Room: Donkeymint
  P Switch Run Room: Buflen
  
 Section 2:
  Snake Block Room: revolug
  Fuzzy Room: Scags
  Fishin' Boo Room: JeepySol
  Growing Pipe Room: Buflen
  Jumping Line-Guided Platform Room: MmmDoggy
  Line-Guided Rope Room: MmmDoggy
  Koopaling Room: NewPointless
  Dolphin and Torpedo Room: Donkeymint

Iron Fist:
 Revolug made the first room, and JeepySol made the second.
 
Big Castle:
 Participants made rooms using gimmicks borrowed from other creators' levels.
 
 Room 1: MmmDoggy (borrowed from NewPointless' Blacklight Bonezone)
 Room 2: Donkeymint (borrowed from Scags' What That Mouth Do)
 Room 3: Brakkie (borrowed from MmmDoggy's Toe the Line)
 Room 4: Buflen (borrowed from JeepySol's Gilling Spree)
 Room 5: JeepySol (borrowed from revolug's Unfinished Temple)
 Room 6: Scags (borrowed from Donkeymint's Switch Hitter)
 Room 7: revolug (borrowed from Buflen's Strawberry Skyway)
 Room 8: NewPointless (borrowed from Brakkie's Sean)

+---------+
|Song List|
+---------+
 Title Screen, Intro: Super Mario Galaxy - Gusty Garden Galaxy [HaruMKT]
 
Overworld:
 The Hub: The 9th Vanilla Level Design Contest - Beach [Pinci]
 Minty Meadow: The 12th Vanilla Level Design Contest - Autumn Zone [Pinci]
 Metropolitan Area: The 7th Vanilla Level Design Contest - Cave Map [Lui]
 Above the Clouds: The 12th Vanilla Level Design Contest - Sky Map [bebn legg]
 Astral Plane: The 8th Vanilla Level Design Contest - Cave Map [S.N.N.]
 Big Castle Overworld: The 12th Vanilla Level Design Contest - Fire Map [brickblock369] 
 
The Hub:
 Makers' Hut: The 11th Vanilla Level Design Contest - Beach Map [brickblock369]

Minty Meadow (World 1):
 Coin Quest 1: Pokémon Ruby/Sapphire/Emerald - Route 113 [Kevin]
 Merriam Woods: Kururin Paradise - Castle Land [Dispace]
 Easy Shell: Lagoon - Atland [SiameseTwins]
 El Sonidito: Super Mario Bros. 3 - Overworld 2 / Athletic (Mexican Cat version) [Wakana]
 99.9% Imposible: Pop'n Twinbee - Wild Life [brickblock369]
 Switch Hitter:
  First Room: Bubba n' Stix (Amiga) - Part 1 [Dippy]
  Second Room: Bubba n' Stix (Amiga) - Bonus [Dippy]
 Coin Quest 2: Alcahest - Ancient Spaceship [Kevin]
 The Pit: Super Mario Land - Ruins [Andy Smith, Daizo Dee Von]
 Cold-Blooded Cavern: Spelunky - Temple B [Dippy]
 Gilling Spree: Wonder Dog - Bunny Hop Meadow [Dippy]

Metropolitan Area (World 2):
 Toe the Line: TalesWeaver - Sunrise [worldpeace]
 Moist Star: Waterworld - Mission 2 [Kevin]
 Bofa Industries: DKC3 Dixie's Double Trouble "Nuts n' Bolts" [Slash Man]
 Simon Says: Jaguar XJ220 - Speed-e-Boy [Wakana]
 Randomly Designed: Hooded SNES Originals - Groovin' Through The Streets [Hooded Edge]
 Remote Control: The Smurfs' Nightmare - Funny Funny (The Kitchen of Danger) [Vellidragon]
 Strawberry Skyway: Sonic the Hedgehog (8-Bit) - Melodies of the River ~ Bridge Zone (Remix) by Yuzo Koshiro [Hooded Edge]
 Marathon Mountain: Donkey Kong Country - Northern Hemispheres [ggamer77]
 A Game of Telephone: Megami Tensei Gaiden: Last Bible II - Town (Remix) [icrawfish] 
 Butternut Squashed: Hyper Iria - Tower [Ahrion]

Above the Clouds (World 3):
 Step on Me: Persona 2: Innocent Sin - Yukino's Theme [Ahrion]
 Brakkie's Blocks: SMW Central Production 2 - Parched Polyphony [Dr. Tapeworm, Eli Moskowitz, Fyord]
 Classic Buflen: UNDERTALE - Another Medium [Torchkas]
 My Way Highway: Mega Man ZX - Wonder Panorama [Ultima]
 Untidaled Level: Treasure Hunter G Upscale Harbor [Tamaki]
 Blacklight Bonezone: Bee Hunter - Targeting Complete [brickblock369]
 Eye for an Eye: Ghouls 'n Ghosts (Amiga) - Title Screen [brickblock369]
 On Belay: Pilotwings - Hangglider [Sariel]
 Mockroot: Super Mario RPG: Legend of the Seven Stars - Weapons Factory [Kevin]
 Bridge Level: 4Mat - Rose [Ahrion]
 Unfinished Temple: Undertale - Ruins [sincx]

Astral Plane (World 4):
 What That Mouth Do: Knuckles' Chaotix - Door Into Summer [Kevin, tssf]
 Wizard Hat and Robe: Super Mario World 2: Yoshi's Island - Waltz Of The Magikoopa 🎃 ~ Castle & Fortress (Halloween Special Remix) [Hooded Edge]
 Cheep-Heap: Il Maniero Spettrale - Main Theme
 Handful:
  Level: Romancing SaGa 2 - The Sinking Ship [brickblock369]
  Boss: Romancing SaGa - Beat them up! [Wakana]
 Bulletscape: Tengai Makyou Zero - To Hell [Ahrion]
 Free Hugs: Spongebob Squarepants: SuperSponge - Ghost Train [MercuryPenny]
 The Lost Woods: Last Bible III - Red Owl [Kevin]
 Iron Fist: Unreal Tournament '99 - Forgone Destruction [Dippy]
 Sean: Plok - Beach [Torchkas]
 Chromatic Panic: TwinBee Yahho! - Twin Flight [worldpeace]

Big Castle Overworld:
 Big Castle:
  First Half: Mega Man X - Sigma Stage 1 [Kevin]
  Second Half: Tennis [Ahrion]
 Credits: The 11th Vanilla Level Design Contest - Highest-Ranking Map (Unused) [brickblock369] 

+----------+
|Patch List|
+----------+
A list of global patches that affect gameplay mechanics. See in-game credits for a full list of ASM contributors.

 Accessibility:
  Disable Screen Shake
 
 Bugs:
  Berry Eat Crash Fix
  Feather Autoscroll Freeze Fix
 
 Decheese:
  256 Pipe Glitch Fix
  Block Dupe Fix
  Disable Screen Scroll
  P Balloon Cloud Fix
  Rope Fix
  Yoshi Springboard Fix
 
 Dejank:
  Block Dejank for Thrown Items
  Double Spinjump Antifail
  ON/OFF Double Hit fix
  Remove Speed Oscillation
  Slope Pass Glitch Fix
  Sprite Slot Interaction Fix
  Vertical Spawn/Despawn Fix
  Wall Clips Disabled
  Yoshi Stomp Hitbox Fix
 
 Feature Changes:
  Bring Up Save Prompt by Pressing Select
  Cape Turnaround Patch
  Kevin's Retry
   Counter Break: Yes
   Lives: Infinite
   Midways: Save
  Spinjump Carry Fix
  Update Vertical Scroll on Enemy Bounce
 
 Frame Rules:
  Consistent 8 Frame Cape Float Release
  Mario-Sprite Interaction
  Yellow Koopa Jump
 
 Sprite Modifications:
  Ball n' Chain and Yoshi Interaction Fix
  Dynamic Sprites Patch
  No Silent Bullet Bill