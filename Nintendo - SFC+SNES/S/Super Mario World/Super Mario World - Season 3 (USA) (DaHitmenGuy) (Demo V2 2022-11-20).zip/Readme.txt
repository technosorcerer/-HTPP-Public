Storyline:
Bowser once again Kidnaps Princess Peach from the Peach's Castle,
Mario's adventures in Mushroom Kingdom continues in Season 3.

EDIT ON UPDATE V2: THE WORLDS OF THE 2ND DEMO ARE FROM 1 TO 6, SECRET LEVELS ADDED 
FROM SOME LEVELS THAT LINK TO THE SECRET EXIT, AND WARPED PIPES

DETAILS REQUESTED ARE FIXED

Credits for this hack
Graphics:
LumSht

Sprites:
Sonikku
mikeyk
EternityLarva
Darolac
RussianMan
leod


UberAsm:
Ayami
KevinM
Ruberjig

Music:
Pinci
LadiesMan217 = SMB3 Desert Land Map

Hack Tester:
ForthRightMC

..and others that I will remember for credit them

© DaHitmenGuy 2022
