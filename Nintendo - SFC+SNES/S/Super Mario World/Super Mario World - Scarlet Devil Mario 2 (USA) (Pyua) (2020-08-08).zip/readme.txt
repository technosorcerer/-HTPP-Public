			      =====================
		              Scarlet Devil Mario 2
			      =====================

			      ====================
			       Changelog of fixes
                              ====================

First Version (08/08/2020)
	-Initial release

				 ==============
				 About the hack
				 ==============

Scarlet Devil Mario 2 (as it is often called in English) is a Japanese romhack made by
Pyua, and released in 2011. It's a follow up to the hack Scarlet Devil Mario, and both hacks
are heavily based on the Touhou game Embodiment of Scarlet Devil. This hack has 41 exits.

				==================
				About this release
				==================

First of all, we were not involved in and take no credit for the development of
the hack itself. We merely did the fixes and translation described below.

This release fixes the compatibility bugs present in the original hack, which made playback
on any emulator more accurate than ZSNES impossible without crashing. This release should
work even on a real SNES console. Please consult the header "Compatibility problems that
were fixed" further down into this document for a detailed list.

Included is a BPS patch for a fixed version of the original Japanese hack, as well as one
that features an unofficial translation of all the game's text into English.

Finally, there are some ASM patches for additional quality of life and educational features.
Read the next section for more info on how to apply them.

This release is based on version 1.1 of the original hack.

			      =====================
			      About the ASM patches
			      =====================

Once the BPS patch of your choice has been applied, the resulting ROM should be ready
to play on most hardware and software capable of running SNES games without further
modification.

However, there are some more options in the form of ASM patches that you might be interested in.
In this hack's case, we've included patches for the following:

	- Reduction of excessive lag, consisting of a FastROM patch and a fix for the old
	  and extremely processor-heavy implementation of blktool used in this hack.
	- OW messages which will explain some of the references to Japanese internet memes.

We have tried making the process of applying these patches as simple as possible, so
even if you've never done anything with ASM before it shouldn't take longer than a
few minutes to find out what they all do and to actually apply the ones you want.

Below is a step-by-step guide to learning what all the ASM patches do, and how to apply them.

1. Prepare the ROM by applying either of the BPS files to a clean, headered USA version ROM of
   Super Mario World, and placing the resulting .smc file into the 'asm_patches' folder.

2. Run the '@main.cmd' file in the 'asm_patches' folder.

3. For each available patch, you will be told by the program what it does, and asked whether
   you want to apply it. Follow the instructions that appear on screen.

And now if nothing has gone wrong, the ROM should be ready to be played.

If the batch file fails for some reason, you can run asar.exe directly and use it to apply
the file 'apply_all.asm' to your ROM as a fallback. Make sure that the file extension of your
ROM is '.smc', and not '.sfc'.

Notes: Do not mess with any of the files in the asm_patches folder besides the rom you have
placed there, and running @main.cmd. If you want to repatch a ROM, use a new one rather than
one that has already had optional ASM patches applied to it.
Although there's almost no conceivable way you could damage your system by use of @main.cmd,
be aware that as a batch file it is essentially running system commands with any permissions
you give, and that we are not responsible for damage caused by improper usage of it.

The process uses a program called "Asar" by Alcaro (and others), which is not our work.
The program can normally be found at these addresses:
https://www.smwcentral.net/?p=section&a=details&id=14560
https://github.com/RPGHacker/asar

			  ======================================
			  Compatibility problems that were fixed
			  ======================================

	- Crashes related to the use of an old AddMusic tool made by carol which uploads
	  music data into a section of Audio RAM which gets overwritten by echo data.

	- Similar crashes due to songs setting too high an echo delay setting, which causes
	  echo data to overwrite the sample data.

	- Stuttering audio caused by residual audio data getting continually replayed when
	  echo delay is set to 0, but echo playback is not turned off.

	- Robotic sounds in the music of some levels due to a bug in the vanilla
	  sound engine that causes the wrong instrument data to get loaded whenever a sound
	  effect interrupts a music channel that is playing percussion.

	- Small glitches due to inaccurate results from multiplication and division operations,
	  caused by the hack assuming that the system makes the result available immediately
	  rather than after a couple cycles delay as real hardware does.

	- The brightness was slightly raised in one dark level, as real hardware and accurate
	  emulators would otherwise make this level far darker than it would be on the older
	  emulators this hack was designed for.

	- A flash that occurs sometimes when level loading starts, due to the background
	  palette data not getting updated quickly enough.


					=======
					Credits
					=======

This is a list of all the people whose software/patches/work we've used or adapted on this hack:

Asar 					- Alcaro et al
Recover Lunar Magic 			- Parasyte
Lunar Magic				- FuSoYa
Extended Overworld Level Names 		- Smallhacker
Extreme FastROM 			- Ersanio

ASM for message box chaining, cutscene text chaining, translator notes, and level load flash fix
by Super Maks 64.
Translation, compatibility/bug fixes, Modern Recover Lunar Magic, and additional ASM
by This Eye o' Mine.
Proofreading and testing by SimFan96, Ryrir, and lion.

And of course thanks to Pyua, who made the hack in the first place.

Our apologies to any people we might've missed.

- The Hack Fix/Translation team