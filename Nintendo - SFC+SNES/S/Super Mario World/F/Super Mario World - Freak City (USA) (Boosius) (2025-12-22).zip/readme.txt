Welcome to Freak City!
This is a list of credits as well as information about my hack!

--STORY(?)-------------------------------------------------------------------------
It was a normal day at Mario's Mario House, when all of a sudden a loud noise calls to him from outside.
A color-shifting pipe has emerged from the ground. The ever curious Mario jumps in, in hopes of Fame and Fortune.
Little did Mario know, the Pipe would send him, any many others, to a land called Freak City.

--TIPS AND TRICKS----------------------------------------------------------------------
After the first couple levels, you can play the hack in any order you like.
If you're having trouble on a level, skip it and come back later!
There are 92 Exits in the hack. 50 Exits are required to reach the final world and beat the game.

--KNOWN BUGS----------------------------------------------------------------
green vs red - entering or clearing this level will result in the game being weird graphically. saving and resetting fixes this.

--potential epilepsy warning on these levels--------------------------------------
green vs red
my guiding moonlight
yellow lunar palace
montgomery's comet
badass
whimsy


--CREDITS------------------------------------------------------------
Hack created by Mina H. (boosius)
10/25/21 - 11/7/25

Original Game by Nintendo (you knew this)

SPECIAL THANKS
Mom                
Maria
Jason
Devin
My Cats + Dawg
Flippin_Egg
8Ball
Orracle
Citri
BubbleBastard
MischievousMarc <-- huge shoutout for being an awesome playtester and fixing a lotttta problems
Super Mario...
Vinesauce
Simpleflips
Juzcook
BarbarousKing
CarlSagan42
Patcdr
Stucat
YouFailMe
HwailaLuta


I'm so glad to finally finish this hack, it's been an insane part of my life for the last 4 years.
Thank You so much for playing it! <3


and now... the big part..

--Resources Used---------------------------------------------------------------------------------------------------------------------------------------

--ExGFX------------------------------------------------------------------------------------------------------------------------------------------------
Castlevania: Harmony of Dissonance - Castle Treasury (Golden Halls) - Anorakun - https://www.smwcentral.net/?p=section&a=details&id=33400
Castlevania: Bloodlines - Versailles Palace (Fifth Chapel) - Anorakun - https://www.smwcentral.net/?p=section&a=details&id=34315
Castlevania: Bloodlines - Leaning Tower of Pisa (Interior) - Anorakun - https://www.smwcentral.net/?p=section&a=details&id=34316
Castlevania: Dracula X - Stage 7 (Outside) - Anorakun -https://www.smwcentral.net/?p=section&a=details&id=33549
Kirby Super Star - Candy Mountain - Rykon-V73 - https://www.smwcentral.net/?p=section&a=details&id=33715
The Ninja Warrior (Sega CD) - Stage 2 - Roberto zampari - https://www.smwcentral.net/?p=section&a=details&id=39213
Disney's Peter Pan: Return to Neverland - Brown Sea - Roberto zampari - https://www.smwcentral.net/?p=section&a=details&id=37137
DunQuest: Majin Fuuin no Densetsu - Castle Outer - Brutapodee89 - https://www.smwcentral.net/?p=section&a=details&id=36804
Sutte Hakkun - Stage 10 (Sky Mountains) - Anorakun - https://www.smwcentral.net/?p=section&a=details&id=35112
Freedom Planet 2 - City Buildings - Roberto zampari - https://www.smwcentral.net/?p=section&a=details&id=33173
Mega Man X3 - Giant Dam (Water Barrage) - Anorakun - https://www.smwcentral.net/?p=section&a=details&id=31767
Illusion of Gaia - Ending - Anorakun - https://www.smwcentral.net/?p=section&a=details&id=31339
Rendering Ranger R2 - Stage 7 (City) - Roberto zampari - https://www.smwcentral.net/?p=section&a=details&id=29381
Rendering Ranger R2 - Stage 7 - Rykon-V73 - https://www.smwcentral.net/?p=section&a=details&id=27490
Streets of Rage - Title Screen - Brutapode89 - https://www.smwcentral.net/?p=section&a=details&id=24847 ?
FR Citypark - Carld923 - https://www.smwcentral.net/?p=section&a=details&id=23904
Ghost Sweeper Mikami: Joreishi wa Nice Body - Title Screen - Ayami - https://www.smwcentral.net/?p=section&a=details&id=20691
X-Kaliber 2097 - Neo NewYork - Ayami - https://www.smwcentral.net/?p=section&a=details&id=15135
Gimmick! - Overworld - Nariofan101 - https://www.smwcentral.net/?p=section&a=details&id=15838
Donkey Kong Country - Snow - Ayami, Jagfillit - https://www.smwcentral.net/?p=section&a=details&id=32746
The Polar Express - Snow Telephone Pole - Roberto zampari - https://www.smwcentral.net/?p=section&a=details&id=29207
Super Mario RPG: Legend of the Seven Stars - Clouds - SafeDesire - https://www.smwcentral.net/?p=section&a=details&id=1249
Super Mario World - Trees - AmperSam - https://www.smwcentral.net/?p=section&a=details&id=37519
Super Mario All-Stars: Super Mario Bros. 3 - Bowser's Castle (Front Pillars) - Anas - https://www.smwcentral.net/?p=section&a=details&id=30033
Super Mario World 2: Yoshi's Island - Title Screen - Ayami - https://www.smwcentral.net/?p=section&a=details&id=30990
Super Mario World 2: Yoshi's Island - Bush and Palms - Ayami - https://www.smwcentral.net/?p=section&a=details&id=30970
Super Mario All-Stars: Super Mario Bros. 3 - Underground - TheOrangeToad - https://www.smwcentral.net/?p=section&a=details&id=30638
Mega Man 7 - Dr. Wily Stage 4 (Cloud Man's Room) - cheat-master30 - https://www.smwcentral.net/?p=section&a=details&id=30216
Super Mario All-Stars: Super Mario Bros. 3 - Castle - AmperSam, Black Sabbath - https://www.smwcentral.net/?p=section&a=details&id=30076
Mario & Wario - Wario's Fields - Luigi-San - https://www.smwcentral.net/?p=section&a=details&id=30461
Super Mario World - Clouds - allowiscious, imamelia - https://www.smwcentral.net/?p=section&a=details&id=2544
Mega Man X - Sigma Stage 2 - Arinsu - https://www.smwcentral.net/?p=section&a=details&id=30335
Super Mario World 2: Yoshi's Island - Smiley Clouds - UTF - https://www.smwcentral.net/?p=section&a=details&id=30697
Pringles - & Basil Tomato - Rykon-V73 - https://www.smwcentral.net/?p=section&a=details&id=34244
BS Super Ninja-Kun - Sky Chase - Anorakun - https://www.smwcentral.net/?p=section&a=details&id=32321
Kirby's Adventure - Nightmare Wizard Battle - Anonymous - https://www.smwcentral.net/?p=section&a=details&id=10665
Final Fantasy IV - Lunar Core - cheat-master30 - https://www.smwcentral.net/?p=section&a=details&id=30176
Popful Mail (SEGA CD) - Golem Tower - Anorakun - https://www.smwcentral.net/?p=section&a=details&id=33948
Klonoa 2: Dream Champ Tournament - Beach - Rykon-V73 - https://www.smwcentral.net/?p=section&a=details&id=34271
Oscar (SNES) - Title Screen - Natsuz2 - https://www.smwcentral.net/?p=section&a=details&id=32260
Rain and Snow - HarvettFox96 - https://www.smwcentral.net/?p=section&a=details&id=6382
Super Mario World - Starry Sky - S.R.H. - https://www.smwcentral.net/?p=section&a=details&id=13987
Hogs - Flippin_egg - No Link
Beach Stuff - Flippin_egg - No Link
Super Mario World Style Carnival - BakonMaker, Green Jerry - https://www.smwcentral.net/?p=section&a=details&id=35685
Super Mario All-Stars: Super Mario Bros. 3 - Waterfall - edgar - https://www.smwcentral.net/?p=section&a=details&id=27906
Rising Balloons - Gamma V - https://www.smwcentral.net/?p=section&a=details&id=11970
Mario Kart: Super Circuit - Sky Garden - Luigi-san - https://www.smwcentral.net/?p=section&a=details&id=11243
Touhou Koumakyou ~ The Embodiment of Scarlet Devil - Spellcard (Remilia Scarlet) - Rykon-V73 - https://www.smwcentral.net/?p=section&a=details&id=35352
The Addams Family (SNES) - Ice Levels - Roberto zampari - https://www.smwcentral.net/?p=section&a=details&id=27524
The Flintstones: The Treasure of Sierra Madrock - Stage 4 - Big Brawler - https://www.smwcentral.net/?p=section&a=details&id=15056
Touhou Yumejikuu ~ The Phantasmagoria of Dim.Dreram - Mimi-chan - E-man38 - https://www.smwcentral.net/?p=section&a=details&id=38485
Card Captor Sakura: Sakura card de Mini Game - Catch the Roses - Roberto zampari - https://www.smwcentral.net/?p=section&a=details&id=38350
Super Mario All-Star: Super Mario Bros. 3 - Pipes - Natsuz2 - https://www.smwcentral.net/?p=section&a=details&id=30418

--MUSIC--------------------------------------------------------------
Alcahest - Imperial Palace - Kevin - https://www.smwcentral.net/?p=section&a=details&id=24781
Super Bonk - Twilight Space - Nanako - https://www.smwcentral.net/?p=section&a=details&id=28047
Final Fantasy IV - Kain's Theme - Dispace - https://www.smwcentral.net/?p=section&a=details&id=32880
Kirby's Dream Course - Iceberg Ocean - Segment1Zone2 - https://www.smwcentral.net/?p=section&a=details&id=32538
Shin Kido Senki Gundam Wing: Endless Duel - Airport - Ahrion - https://www.smwcentral.net/?p=section&a=details&id=28840
MegaMari - Cirno's Stage - Isikoro - https://www.smwcentral.net/?p=section&a=details&id=29700
Clock Tower - Falling Rain - Samantha - https://www.smwcentral.net/?p=section&a=details&id=18731
Paper Mario - Shooting Star Summit - Fyre150 - https://www.smwcentral.net/?p=section&a=details&id=28055
Super Mario RPG: Legend of the Seven Stars - Barrel Volcano - sincx -https://www.smwcentral.net/?p=section&a=details&id=8327
Streets of Rage 2 - Slow Moon - Hazel - https://www.smwcentral.net/?p=section&a=details&id=23623
Kirby's Dream Land 3 - Ripple Field 1 - Nanako - https://www.smwcentral.net/?p=section&a=details&id=34623
Super Bonk - Game Over - Nanako - https://www.smwcentral.net/?p=section&a=details&id=28033
PilotRedSun - Grinch's Ultimatum - Kaizo Zhang - https://www.smwcentral.net/?p=section&a=details&id=39473
Super Mario RPG: Legend of the Seven Stars - Hello, Happy Kingdom - SiameseTwins - https://www.smwcentral.net/?p=section&a=details&id=26879
Pokemon Ruby/Sapphire/Emerald - Route 113 - Kevin - https://www.smwcentral.net/?p=section&a=details&id=23381
Last Bible III - Battle 3 - Kevin - https://www.smwcentral.net/?p=section&a=details&id=29285
On My Way - Torchkas - https://www.smwcentral.net/?p=section&a=details&id=35593
Mario & Luigi: Superstar Saga - Beanbean Fields - Masterlink - https://www.smwcentral.net/?p=section&a=details&id=17332
Paper Mario - Snow Road - Fyre150 - https://www.smwcentral.net/?p=section&a=details&id=29008
The Legend of the Mystical Ninja - Spunky Female Ninja - Segment1Zone2 - https://www.smwcentral.net/?p=section&a=details&id=29444
Super Paper Mario - Overthere Stairs (Anime Relaxing Mix) - Dispace - https://www.smwcentral.net/?p=section&a=details&id=26378
Tomodachi Life - Forecast - Dispace - https://www.smwcentral.net/?p=section&a=details&id=29390
Castlevania: Aria of Sorrow - Castle Corridor - qantuum - https://www.smwcentral.net/?p=section&a=details&id=26355
New Super Mario Bros. - World 8 - Anas - https://www.smwcentral.net/?p=section&a=details&id=29083
Super Pinball: Behind The Mask - Title Screen - Segment1Zone2 - https://www.smwcentral.net/?p=section&a=details&id=30328
HAL's Hole in One Golf - Take a Rest - Segment1Zone2 - https://www.smwcentral.net/?p=section&a=details&id=29446
Mega Man 2 - Crash Man - Segment1Zone2 - https://www.smwcentral.net/?p=section&a=details&id=32995
Kirby's Block Ball - Stage 2 - EDIT3333 - https://www.smwcentral.net/?p=section&a=details&id=38741
SpongeBob SquarePants: SuperSponge - Roller Coaster & Snail Race - Dippy - https://www.smwcentral.net/?p=section&a=details&id=26283
Ardy Lightfoot - Lumberjack Forest - Gamma V - https://www.smwcentral.net/?p=section&a=details&id=8267
Vertical Glowside 2 - Dispace - https://www.smwcentral.net/?p=section&a=details&id=32879
Sutte Hakkun - Stage 10 - Fyre150 - https://www.smwcentral.net/?p=section&a=details&id=33476
Knights of the Round - Merlin - qantuum - https://www.smwcentral.net/?p=section&a=details&id=30420
On Top of the Castle - Pinci - https://www.smwcentral.net/?p=section&a=details&id=36767
Momodora: Reverie Under the Moonlight - Pardoner's Dance - Sariel - https://www.smwcentral.net/?p=section&a=details&id=27509
Great Battle II: Last Fighter Twin - Ice Castle - EDIT3333 - https://www.smwcentral.net/?p=section&a=details&id=34802
The Sims: Bustin' Out (GBA) - Paradise Island - Dippy - https://www.smwcentral.net/?p=section&a=details&id=28277
Super Mario Advance 2: Super Mario World - Title Screen - MercuryPenny - https://www.smwcentral.net/?p=section&a=details&id=26236
Alcahest - Ancient Spaceship - Kevin - https://www.smwcentral.net/?p=section&a=details&id=25326
Alcahest - Alcahest ~ God of Death - Kevin - https://www.smwcentral.net/?p=section&a=details&id=25825
Pocky & Rocky - Battle in the Sky - EDIT3333 - https://www.smwcentral.net/?p=section&a=details&id=35754
Mario & Luigi: Superstar Saga - Popple Battle - MidiGuy - https://www.smwcentral.net/?p=section&a=details&id=7145
Mega Man 9 - Concrete Jungle - Zavok - https://www.smwcentral.net/?p=section&a=details&id=20483
Mario Kart Wii - Wario's Gold Mine - Kitikuchan, Kusamochi - https://www.smwcentral.net/?p=section&a=details&id=26792
Super Bonk - Prehistoric Jungle - Nanako - https://www.smwcentral.net/?p=section&a=details&id=28032
Uncharted Waters - Aboard in the Tropical Area - Nanako - https://www.smwcentral.net/?p=section&a=details&id=35350
SpongeBob SquarePants - SuperSponge - Industrial Fields: Oil Rig - lu9 - https://www.smwcentral.net/?p=section&a=details&id=9452
Kirby Super Star - Floating Away - Ahrion - https://www.smwcentral.net/?p=section&a=details&id=37793
Walls That Were Once Called Home - icrawfish - https://www.smwcentral.net/?p=section&a=details&id=32892
Under Defeat HD - Never Say Die - Dippy - https://www.smwcentral.net/?p=section&a=details&id=30950
JoJo's Bizarre Adventure (SNES) - The World - Ahrion - https://www.smwcentral.net/?p=section&a=details&id=31288
Mega Man 3 - Dr. Wily's Castle 1 & 2 - Lui - https://www.smwcentral.net/?p=section&a=details&id=7199
Super Adventure Island - Blue Blue Moon - Kevin - https://www.smwcentral.net/?p=section&a=details&id=27255
Final Fantasy III - Eternal Wind - Samantha - https://www.smwcentral.net/?p=section&a=details&id=23948
Final Fantasy VII - Oppressed People- Ahrion - https://www.smwcentral.net/?p=section&a=details&id=31209
Summon Night: Swordcraft Story - I Must Not Lose The Battle! - sincx - https://www.smwcentral.net/?p=section&a=details&id=19546
VS Potential - Dispace - https://www.smwcentral.net/?p=section&a=details&id=32167
Tetris Giant - Fate is "I" Love You - Isikoro - https://www.smwcentral.net/?p=section&a=details&id=33049
Tarot Mystery - What Is Your Birthday? - Kevin - https://www.smwcentral.net/?p=section&a=details&id=31575
Diadra Empty - Heroine 04 - worldpeace - https://www.smwcentral.net/?p=section&a=details&id=23206
Bomberman Hero - Dessert - Fercho91, Pinci, dansalvato - https://www.smwcentral.net/?p=section&a=details&id=34227
Kirby 64: The Crystal Shards - Rock Star (Kirby's Dream Land 3 Style) - JX444444 -https://www.smwcentral.net/?p=section&a=details&id=26626
Kirby Super Star - Bubbly Clouds - Kevin - https://www.smwcentral.net/?p=section&a=details&id=34056
Super Mario Galaxy - Gateway Galaxy - Pinci - https://www.smwcentral.net/?p=section&a=details&id=16534
Earthbound Beginnings - Snowman - Gamma V - https://www.smwcentral.net/?p=section&a=details&id=13999
SpongeBob SquarePants: SuperSponge - Cutscene - Dippy - https://www.smwcentral.net/?p=section&a=details&id=26334
Azazel - Polta Tavias - Ahrion - https://www.smwcentral.net/?p=section&a=details&id=30339
Torifune Iseki ~ Trojan Green Asteroid - Desire Drive - K M S - https://www.smwcentral.net/?p=section&a=details&id=15452
Mario Pinball Land - Under the Ice - bebn legg - https://www.smwcentral.net/?p=section&a=details&id=35818
Tobu Tobu Girl - Electromagnetic Waves (Dream Level) - Pinci - https://www.smwcentral.net/?p=section&a=details&id=30538
Final Fantasy: Mystic Quest - City of Fire ~ Faeria - Zavok - https://www.smwcentral.net/?p=section&a=details&id=34253
Tulips or Roses? - Pinci - https://www.smwcentral.net/?p=section&a=details&id=21394
Bomberman Hero - Tripod (Vs. Nitros) - dansalvato - https://www.smwcentral.net/?p=section&a=details&id=23077
Super Mario Kart - Battle Mode - brickblock369 - https://www.smwcentral.net/?p=section&a=details&id=38220
R-ACK - real final - Daizo Dee Von - https://www.smwcentral.net/?p=section&a=details&id=31518
Cake - The Distance - qantuum - https://www.smwcentral.net/?p=section&a=details&id=30421
Sutte Hakkun - Stage 1 - Fyre150 - https://www.smwcentral.net/?p=section&a=details&id=33467
Super Pinball II: The Amazing Odyssey - Main Menu - Segment1Zone2 - https://www.smwcentral.net/?p=section&a=details&id=30122
Pachinko Fan 2 - Starting a Game - Fullcannon - https://www.smwcentral.net/?p=section&a=details&id=39514
Creedence Clearwater Revival - Bad Moon Rising - kaigem - https://www.smwcentral.net/?p=section&a=details&id=23304
Donkey Kong Country 2: Diddy's Kong Quest - Primal Rave - ggamer77 - https://www.smwcentral.net/?p=section&a=details&id=15009
Corpse Party - Ray Of Hope - TheBourgyman - https://www.smwcentral.net/?p=section&a=details&id=29505
Momodora: Moonlit Farewell - Harpy Attack! - Wakana - https://www.smwcentral.net/?p=section&a=details&id=38234
Masayoshi Takanaka - Brasilian Skies - Overcrow03 - https://www.smwcentral.net/?p=section&a=details&id=35867
Super Mario 64 - Bowser Battle - 84GSMeister - https://www.smwcentral.net/?p=section&a=details&id=31580
Pocky & Rocky - Boss Fight 2 - monkey03297 - https://www.smwcentral.net/?p=section&a=details&id=39564
Super Mario Galaxy - Purple Coins - brickblock369 - https://www.smwcentral.net/?p=section&a=details&id=26986
Star Factory - ThinkOneMoreTime - https://www.smwcentral.net/?p=section&a=details&id=8006
Schoolboy Q - Collard Greens - mueuen - https://www.smwcentral.net/?p=section&a=details&id=30307
Alcahest - The Demon Underworld - Kevin - https://www.smwcentral.net/?p=section&a=details&id=25096
Tsuri Bit - Blue Ocean Fishing Cruise - Isikoro - https://www.smwcentral.net/?p=section&a=details&id=32957
Sutte Hakkun - Stage 5 - Fyre150 - https://www.smwcentral.net/?p=section&a=details&id=33471
Alcahest - Mountain Trail - Kevin - https://www.smwcentral.net/?p=section&a=details&id=25247
The 7th Saga - World Map - icrawfish - https://www.smwcentral.net/?p=section&a=details&id=37088
Alcahest - Underground Sewer - Kevin - https://www.smwcentral.net/?p=section&a=details&id=30398
EarthBound - The Cliff That Time Forgot - Samantha - https://www.smwcentral.net/?p=section&a=details&id=18598
Last Bible III - Mochoa - Kevin - https://www.smwcentral.net/?p=section&a=details&id=29268
WhiteYoshiEgg - City Lights - Segment1Zone2, wye - https://www.smwcentral.net/?p=section&a=details&id=28162
Chrono Trigger - A Prayer To The Road That Leads - Samantha - https://www.smwcentral.net/?p=section&a=details&id=20969
Alcahest - Warrior's Fanfare - Kevin - https://www.smwcentral.net/?p=section&a=details&id=32498
Eye of the Beholder - Nearing the End - Fullcannon - https://www.smwcentral.net/?p=section&a=details&id=25855


--SPRITES-------------------------------------------------------------
X/Y Position Locked Sprite v1.2 - Kevin - https://www.smwcentral.net/?p=section&a=details&id=24622 (the goat)
Baby Yoshi - Dijef - https://www.smwcentral.net/?p=section&a=details&id=25330
Chasing Boo Stream - RussianMan - https://www.smwcentral.net/?p=section&a=details&id=38526
Chasing Porcupufferr - Darolac - https://www.smwcentral.net/?p=section&a=details&id=20396
SMB3 Fire Chomp - Arinsu - edit1754 - https://www.smwcentral.net/?p=section&a=details&id=22472
YI Flying Kamek - Thomas - https://www.smwcentral.net/?p=section&a=details&id=13895
Fleeing Keyhole Spritee V1.0 - TheXander - https://www.smwcentral.net/?p=section&a=details&id=37761
NPCs v4.4 - wye - https://www.smwcentral.net/?p=section&a=details&id=35326
Tryclyde - dahnamics - https://www.smwcentral.net/?p=section&a=details&id=3718
Flame Football - RussianMan - https://www.smwcentral.net/?p=section&a=details&id=37858
Pokey, Football Movement - RussianMan - https://www.smwcentral.net/?p=section&a=details&id=28349
Bumpty - Romi - https://www.smwcentral.net/?p=section&a=details&id=27639
Shatterable/Timed Ky - Arinsu - https://www.smwcentral.net/?p=section&a=details&id=39045
Thwompin' Chuck - Daizo Dee Von - https://www.smwcentral.net/?p=section&a=details&id=32379
Homing Horizontal Thwomp - ShadowMistressYuko - https://www.smwcentral.net/?p=section&a=details&id=28321
Para-Beetle - MarkAlarm, Romi, imamelia - https://www.smwcentral.net/?p=section&a=details&id=27631
Explosive Crosshair V1.0 - TheXander - https://www.smwcentral.net/?p=section&a=details&id=37813
Bird, flies after contact - Arinsu - https://www.smwcentral.net/?p=section&a=details&id=18956
Yoshi's Island-style Shy Guy - imamelia - https://www.smwcentral.net/?p=section&a=details&id=22378
Spike Chuck v1.0 - Eminus, Von Fahrenheit - https://www.smwcentral.net/?p=section&a=details&id=25992
Eerie (+ wave motion) - Ersanio - https://www.smwcentral.net/?p=section&a=details&id=28733
Explosive Bully - Romi, RussianMan - https://www.smwcentral.net/?p=section&a=details&id=29011
Bouncy Cloud - Donut - https://www.smwcentral.net/?p=section&a=details&id=29002
Amazing Flying Hammer Bro + Stationary SMW Hammer Bro - Sonikku - https://www.smwcentral.net/?p=section&a=details&id=35692
Enemy Stack - dtothefourth - https://www.patreon.com/posts/enemy-stack-29005221
Basilisk - Schwa - https://www.smwcentral.net/?p=section&a=details&id=20089
Birdo - mikeyk - https://www.smwcentral.net/?p=section&a=details&id=16799
Fly Guy - smkdan - https://www.smwcentral.net/?p=section&a=details&id=22373
Wreckin' Chuck - Sonikku - https://www.smwcentral.net/?p=section&a=details&id=30909
Tap-Tap - Dispari Scuro - https://www.smwcentral.net/?p=section&a=details&id=32565
Customizable Green Gas Bubble + Disassembly - dogemaster - https://www.smwcentral.net/?p=section&a=details&id=26116
Springy Bubble/Bubble Platform - RussianMan - https://www.smwcentral.net/?p=section&a=details&id=20728
Chucks - RussianMan - https://www.smwcentral.net/?p=section&a=details&id=39323
Sprite Throwin' Chuck - RussianMan - https://www.smwcentral.net/?p=viewthread&t=129341
Rideable Balloon - smkdan - https://www.smwcentral.net/?p=section&a=details&id=16172
Boogie (Beta Sprite) - Maarfy - https://www.smwcentral.net/?p=section&a=details&id=33216
Hybrid Big Boo Boss - RussianMan - https://www.smwcentral.net/?p=section&a=details&id=28506
Ultimate Boom Boom - Darolac - https://www.smwcentral.net/?p=section&a=details&id=25221
Fishin' Boo Boss - Davros - https://www.smwcentral.net/?p=section&a=details&id=17099
Fire-Spitting Boo - Arinsu - https://www.smwcentral.net/?p=section&a=details&id=16656
Monty Mole Pile - RussianMan - https://www.smwcentral.net/?p=section&a=details&id=29012
Rock/Bomb Throwing Monty Mole - leod - https://www.smwcentral.net/?p=section&a=details&id=15159
Trampoline - Donut - https://www.smwcentral.net/?p=section&a=details&id=32476
Matasaburo - ASSATAKKU - https://www.smwcentral.net/?p=viewthread&t=121036
Crab - Darolac - https://www.smwcentral.net/?p=section&a=details&id=22322
Fryguy - Sonikku - https://www.smwcentral.net/?p=section&a=details&id=32734
Stationary Piranha Plant v1.1 - AmperSam - https://www.smwcentral.net/?p=section&a=details&id=37715
Stationary Reznor - RussianMan - https://www.smwcentral.net/?p=section&a=details&id=36885
Bean Dreams (Mexican Jumping Bean) - Wyatt - https://www.smwcentral.net/?p=section&a=details&id=39723
Fire Stalking Piranha Plant - KobaBeach - https://www.smwcentral.net/?p=section&a=details&id=25311
Customizable Firebar - Isikoro - [link not found]
Sir Kibble - Koopster - https://www.smwcentral.net/?p=section&a=details&id=34719
Cosmic Clone - lx5 - https://www.smwcentral.net/?p=viewthread&t=100287
Chasing Urchin, Shoots Fire - RussianMan - https://www.smwcentral.net/?p=section&a=details&id=38534
Speedrun Timer - Nowieso - https://www.smwcentral.net/?p=section&a=details&id=33324
Bowling Goonie - smkdan - https://www.smwcentral.net/?p=section&a=details&id=16770
Cluster Ash Particle Effect - MarioFanGamer - https://www.smwcentral.net/?p=section&a=details&id=35145
Cluster Effects Pack - Ladida - https://www.smwcentral.net/?p=section&a=details&id=30466
Customizable Bloody Grinder - anonimzwx - https://www.smwcentral.net/?p=section&a=details&id=20725
Mini Chomp Shark - yoshicookiezeus - https://www.smwcentral.net/?p=section&a=details&id=32271
Elite Ninji - Darolac - https://www.smwcentral.net/?p=section&a=details&id=20385
Hammer Sprite - mikeyk - https://www.smwcentral.net/?p=section&a=details&id=3288
Tornado - RealLink - https://www.smwcentral.net/?p=section&a=details&id=30185
Tokotoko - smkdan - https://www.smwcentral.net/?p=section&a=details&id=16231
Wallmaster - Blind Devil - https://www.smwcentral.net/?p=section&a=details&id=17881
Punch - Schwa - https://www.smwcentral.net/?p=section&a=details&id=3266
Phanto - yoshicookiezeus - https://www.smwcentral.net/?p=section&a=details&id=3738
Clawgrip - Sonikku - https://www.smwcentral.net/?p=section&a=details&id=31393
Cave-In Generator - yoshicookiezeus - https://www.smwcentral.net/?p=section&a=details&id=3619
YI Blow Hard v2.2 - edit1754 - https://www.smwcentral.net/?p=section&a=details&id=23057
SMB2 Waterfall Platform - Sonikku - https://www.smwcentral.net/?p=section&a=details&id=3512
Kirby Boss - HuFlungDu - https://www.smwcentral.net/?p=section&a=details&id=3685
Kirby's Dreamland 3 Tick - edit1754 - https://www.smwcentral.net/?p=section&a=details&id=3253
Ground Pound Koopa - mikeyk - https://www.smwcentral.net/?p=section&a=details&id=24088
Shark v1.0 - Eminus, Von Fahrenheit - https://www.smwcentral.net/?p=section&a=details&id=25990
Warp Star - Kaijyuu - https://www.smwcentral.net/?p=section&a=details&id=16096
Hoppycat - Koopster - https://www.smwcentral.net/?p=section&a=details&id=35110
Spinning Log - smkdan - https://www.smwcentral.net/?p=section&a=details&id=16768
Looping Giant Eerie - RussianMan - https://www.smwcentral.net/?p=section&a=details&id=34128
Bowser - mikeyk - https://www.smwcentral.net/?p=section&a=details&id=37338
Slope Muncher - NaroGugul - https://www.smwcentral.net/?p=section&a=details&id=22226
Real Homing Bill - Akaginite - https://www.smwcentral.net/?p=section&a=details&id=14098
F.L.U.D.D. - wye - https://www.smwcentral.net/?p=section&a=details&id=3576
Betterer Boss Bass - Sonikku - https://www.smwcentral.net/?p=section&a=details&id=15484
Homing Magikoopa - ASMagician Maks - https://www.smwcentral.net/?p=section&a=details&id=39117
Wing Cap - MellyMellouange - https://www.smwcentral.net/?p=section&a=details&id=15293
Any Sprite Generator - Koopster - https://www.smwcentral.net/?p=section&a=details&id=26723
Sumo Chuck - Sonikku - https://www.smwcentral.net/?p=section&a=details&id=21660
Balloon Gliders - MellyMellouange - https://www.smwcentral.net/?p=section&a=details&id=15166

--BLOCKS--------------------------------------------------------------
Hurt / Death Block for Kaizo / Pit Hacks - dacin - https://www.smwcentral.net/?p=section&a=details&id=27268
Teleport Pack - Alcaro, MarioE - https://www.smwcentral.net/?p=section&a=details&id=9297
Bounce Blocks - Broozer - https://www.smwcentral.net/?p=section&a=details&id=4033
Carryable Sprite Spawner Blocks Pack - Nowieso - https://www.smwcentral.net/?p=section&a=details&id=22543
Customizable Sprite Killer - Nowieso - https://www.smwcentral.net/?p=section&a=details&id=22898
Throw Blocks Pack - HammerBrother - https://www.smwcentral.net/?p=section&a=details&id=9057
Solid on Powerup - Catobat,Keypas,Roy - https://www.smwcentral.net/?p=section&a=details&id=3970
Specific Screen + Conditional Vertical Exit-Enabled Pipe - Koopster - https://www.smwcentral.net/?p=section&a=details&id=24765
One-Way Blocks 1.3.1 - HammerBrother - https://www.smwcentral.net/?p=section&a=details&id=33312
Stationary Reusable P-Switch - HammerBrother - https://www.smwcentral.net/?p=section&a=details&id=28444


--PATCHES-------------------------------------------------------------
No More Sprite Tile Limits v1.2.4 - Arinsu, Arujus, MathOnNapkins, NoelYoshi, Tattletale, Vitor Vilela, edit1754, yoshifanatic - https://www.smwcentral.net/?p=section&a=details&id=40702
Castle Destruction Cutscene Custom Palettes - Kevin - https://www.smwcentral.net/?p=section&a=details&id=40219
Choose Player SMB:TLL Style - DiscoTheBat - https://www.smwcentral.net/?p=section&a=details&id=14070
Donkey Kong Country 2 Navigation Arrows - Alcaro, carol, lx5, wiiqwertyuiop - https://www.smwcentral.net/?p=section&a=details&id=16422
Dark Room Background Fix - Roy - https://www.smwcentral.net/?p=section&a=details&id=19456
Extended Overworld Level Names v1.2 - Alcaro, Smallhacker, yoshifanatic - https://www.smwcentral.net/?p=section&a=details&id=40650
Swim Faster When Holding X/Y - Kevin - https://www.smwcentral.net/?p=section&a=details&id=26329
Retry System (+ Multiple Checkpoints) v2.06c - Kevin, lx5, worldpeace - https://www.smwcentral.net/?p=section&a=details&id=26078
Reprogrammed Vertical Scroll v1.2 - Blind Devil - https://www.smwcentral.net/?p=section&a=details&id=19676


--UBERASM----------------------------------------------------------------
Horizontal/Vertical Autoscroll - Kevin - https://www.smwcentral.net/?p=section&a=details&id=23357
Teleport on No Enemies - Thomas - https://www.smwcentral.net/?p=section&a=details&id=33852
Teleport on Level End v1.1 - Kevin - https://www.smwcentral.net/?p=section&a=details&id=24025
End Level With Dragon Coins - PermaBan - https://www.smwcentral.net/?p=section&a=details&id=28009
Airjump with Jump Counter - HammerBrother, RussianMan - https://www.smwcentral.net/?p=section&a=details&id=27259
Wall Kick v1.1 - Kevin, MarioE - https://www.smwcentral.net/?p=section&a=details&id=18736
Automatic Walking v1.1 - mathie - https://www.smwcentral.net/?p=section&a=details&id=21731
Cutscene Mode - Blind Devil - https://www.smwcentral.net/?p=section&a=details&id=15400
Trigger Cutscene on Level End - Kevin - https://www.smwcentral.net/?p=section&a=details&id=40739
Pressured Water - mathie - https://www.smwcentral.net/?p=section&a=details&id=14373
Spawn Carried Sprites with L/R - Koopster - https://www.smwcentral.net/?p=section&a=details&id=27201
(Specter of Torment-Styled) Wallclimb and Walljump v2.0 - Arinsu, Maarfy - https://www.smwcentral.net/?p=section&a=details&id=19395
Sprites Are Always In Water - Telinc1, Vivian Darkbloom - https://www.smwcentral.net/?p=section&a=details&id=18195
Cycle through Powerups - Gulaschko - https://www.smwcentral.net/?p=section&a=details&id=32174
Freeze Sprites with L/R - JamesD28 - https://www.smwcentral.net/?p=section&a=details&id=30230
Lock Mario in Place with L or R - ageVerrly - https://www.smwcentral.net/?p=section&a=details&id=26589
Pay Coins to Jump - RussianMan - https://www.smwcentral.net/?p=section&a=details&id=24779
Max Speed Gives Invincibility - simon.caio - https://www.smwcentral.net/?p=section&a=details&id=34347
Single Screen v1.3 - TheBiob - https://www.smwcentral.net/?p=section&a=details&id=39169
Fall damage - xhsdf - https://www.smwcentral.net/?p=section&a=details&id=37819
MOLF - dtothefourth - https://www.patreon.com/posts/gdq-ish-2023-7-85070193
Sticky Hands - Darolac - https://www.smwcentral.net/?p=section&a=details&id=21745
Spaceship Movement - AmperSam, Auradee, wiiqwertyuiop - https://www.smwcentral.net/?p=section&a=details&id=39111
Kill Sprites in Bottomless Pits - RussianMan - https://www.smwcentral.net/?p=section&a=details&id=39031


--TOOLS-------------------------------------------------------------------
AddmusicK_1.0.8 - Kipernal - https://www.smwcentral.net/?p=section&a=details&id=37906
PIXI 1.32 - Atari2.0, JackTheSpades, Tattletale - https://www.smwcentral.net/?p=section&a=details&id=37432
GPS (V1.4.21) - TheBiob, p4plus2 - https://www.smwcentral.net/?p=section&a=details&id=40056
UberASMTool14 - Fernap, Vitor Vilela - https://www.smwcentral.net/?p=section&a=details&id=39036
Effect Tool 3.0 - JackTheSpades, dtothefourth - https://www.smwcentral.net/?p=section&a=details&id=23331
YY-CHR - YY Creator - https://www.smwcentral.net/?p=section&a=details&id=27208
Free Space Logger / slogger - smkdan - https://www.smwcentral.net/?p=section&a=details&id=4611