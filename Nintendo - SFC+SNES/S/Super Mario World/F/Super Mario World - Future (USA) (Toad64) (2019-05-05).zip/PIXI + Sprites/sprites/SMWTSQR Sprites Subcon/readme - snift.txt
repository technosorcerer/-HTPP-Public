Snifit by mikeyk (Giant version and optimizations by Blind Devil)

This file just contains some info on CFG files.

snifit.cfg - regular Snifit, dies when stomped on.
snifit_rideable.cfg - rideable Snifit. Can't be carried, and is immune to spinjumps.
snifit_rideable_spin_kill.cfg - rideable Snifit. Can't be carried, but can be killed by spinjumps.
snifit_carryable.cfg - rideable Snifit, closer to SMB2 behavior. Can be carried, ridden on, and be killed by spinjumps.

Also note that behaviors depend on Extra Byte 1 (Extension in LM). Possible values:
0 - Red Snifit which falls from ledges.
1 - Blue Snifit that stays on ledges.
2 - Grey Snifit that hops in place.
3 - Red Snifit which falls from ledges, but spits three fireballs instead.
4 - Blue Snifit that stays on ledges, but spits three fireballs instead.
5 - Grey Snifit that hops in place, but spits three fireballs instead.
anything else - Snifit will use palette and Extra Property values from the CFG file. Nothing will be overridden.

By the way, extra bit determines if it'll be a regular or a giant Snifit. And you can choose if the giant Snifit can
separately be carried/spinkillable/spawn Bullet Bill instead of a small ball depending on defines in the ASM file.

----------

Other credits:
Original Fire Snifit idea by 1524 (XM)
Original Hopping Grey Snifit and Giant Snifits by Sonikku