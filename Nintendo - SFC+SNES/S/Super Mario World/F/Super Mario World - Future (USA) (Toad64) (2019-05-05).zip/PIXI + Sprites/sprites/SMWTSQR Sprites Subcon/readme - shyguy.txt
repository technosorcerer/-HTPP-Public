Shyguy by mikeyk (Giant version and optimizations by Blind Devil)

This file just contains some info on CFG files.

shyguy.cfg - regular Shyguy. Dies when stomped on.
shyguy_rideable.cfg - rideable Shyguy, not carryable and immune to spinjumps.
shyguy_rideable_spin_kill.cfg - rideable Shyguy, not carryable but can be killed with a spin jump.
shyguy_carryable.cfg - closer to SMB2 Shyguy. Can be ridden on and be carried, and can be killed with a spin jump.

Also note that behaviors depend on Extra Byte 1 (Extension in LM). Possible values:
0 - Red Shyguy which falls from ledges.
1 - Blue Shyguy that stays on ledges.
anything else - Shyguy will use palette and Extra Property values from the CFG file. Nothing will be overridden.

By the way, extra bit determines if it'll be a regular or a giant Shyguy. And you can choose if the giant Shyguy can
separately be carried or not/spinkillable or not depending on defines in the ASM file.