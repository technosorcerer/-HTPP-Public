This folder contains restore information for the ROM(s) in the folder
one level above it.  If you move your ROM(s), you should move this
folder as well to keep your restore information easily accessible.
If you rename your ROM, you should rename the .lrp file to match.

-DO NOT modify the Orig ROM files, unless it's to replace them with
 fresh, unmodified copies of the game.  They're required for certain
 restore functions.

-DO NOT modify the contents of the .lrp files if you care about your
 restore points!  You can however back them up, swap them, or delete
 them if they're no longer needed (just remember that you'll lose the
 restore points in them if deleted).

-If you don't want this folder created, turn off all the automatic
 restore features in the program.
