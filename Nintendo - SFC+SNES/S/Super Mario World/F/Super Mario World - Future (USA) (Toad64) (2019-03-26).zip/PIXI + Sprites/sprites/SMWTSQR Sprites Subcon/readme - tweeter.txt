Tweeter by mikeyk (Giant version and optimizations by Blind Devil)

This file just contains some info on CFG files.

tweeter.cfg - regular Tweeter, dies when stomped on.
tweeter_rideable.cfg - rideable Tweeter, can't be carried nor spinkilled.
tweeter_rideable_spin_kill.cfg - rideable Tweeter, can't be carried, but can be killed with a spin jump.
tweeter_carryable.cfg - closer to SMB2 Tweeter. Can be ridden on and be carried, and can be killed with a spin jump.

By the way, extra bit determines if it'll be a regular or a giant Tweeter. And you can choose if the giant Tweeter can
separately be carried or not/spinkillable or not depending on defines in the ASM file.