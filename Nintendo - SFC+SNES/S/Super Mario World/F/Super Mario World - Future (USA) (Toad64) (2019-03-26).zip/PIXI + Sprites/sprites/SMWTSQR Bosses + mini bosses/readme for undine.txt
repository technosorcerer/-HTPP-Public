Undine Boss v1.2
================
by Kickchon, converted to PIXI/SA-1 by Telinc1

This is Undine from Secret of Mana as a boss for Super Mario World.
She flies around the room and periodically summons frostblocks which try to hurt Mario
or three icicles which try to impale Mario from below.
Additionally, a tidal wave is present which tries to push Mario around to pull
him down into the water.

When the frostblocks hit the tidal wave, they become carryable and can be thrown
at Undine to hurt her.


Changes in v1.1
---------------
Fixed some bugs with the frostwave sprite.
Hopefully changed layer priority for the SMWCP correctly.

Changes in v1.11
----------------
Added Troubleshooting for layer priority in the readme file.

Changes in v1.2
----------------
Converted the sprite to PIXI.
Added SA-1 compatibility.
Optimized a lot of routines.


REQUIREMENTS
------------

sprites/undine.asm
sprites/undine.cfg
sprites/pushwave.asm
sprites/pushwave.cfg
sprites/frostwave.asm
sprites/frostwave.cfg
sprites/icelance.asm
sprites/icelance.cfg

graphics/SP2.bin
graphics/SP4.bin
graphics/palette.pal

(!!!) No Sprite Tile Limits patch (not included)
PIXI

INSTALLATION
------------

Inserting
---------

1. Setup PIXI to insert all 4 sprites and note down their custom sprite numbers but do not insert them yet.

2. Open undine.asm with a text editor.
3. At the top of the file, change:
    -> !FrostWaveNumber to the custom sprite number of frostwave.cfg
    -> !IceLanceNumber to the custom sprite number of icelance.cfg
    -> !HitPoints to your desired amount of hits
4. Save undine.asm

5. Open pushwave.asm with a text editor
6. At the top of the file, change:
    -> !FrostWaveNumber to the custom sprite number of frostwave.cfg
7. Save pushwave.asm

8. Open frostwave.asm with a text editor
9. At the top of the file, change:
    -> !PushWaveNumber to the custom sprite number of pushwave.cfg
10. Save frostwave.asm

11. Insert your sprites now!

The Level
---------

A demonstration level comes with this zip file as arena.mwl. The following needs to be done:
1. Sprite Memory Index needs to be 10 to make use of the No sprite Tile Limits patch.
2. Level should only be one screen. (might work with multiple but clipping issues might occur, not tested)
3. Insert the custom sprite undine.cfg and pushwave.cfg
4. The Pushwave sprite should be on the 5th 16x16 tile row from the bottom, Undine should be on 11th row. (only tested with those values, different might work)
5. The Undine Sprite X position needs to be adjusted to Mario's start position so Undine does not go offscreen. If Mario starts at the screen center try 4 16x16 tile columns to the right or left.
6. The boss uses two ExGFX files. Insert them and set SP2 to SP2.bin and SP4 to SP4.bin.
7. The boss uses 2 palettes. By default undine.asm and frostwave.asm share palette F and pushwave.asm and icelance.asm share palette E. Those can be edited with the CFG Editor.

8. Enjoy the boss! :)

Troubleshooting
---------------

As the sprite uses lots of OAM (that is space for sprite tiles) some tiles of the ice lances might not appear.
This can be fixed by editing a value in the icelance.asm file on line 182:
    CLC : ADC #$0C
    STA $3F                 ; Store priority for this sprite
The number #$0C needs to be variated until it matched your previous sprite configuration in the foregoing level.
Note: If you added additional sprites to the boss room, it will not work for the ice lances.
      The boss's sprites use all of the sprite memory when the ice lances are on screen.

USAGE
-----

So now after SMWCP is released, I'm going to release this finally.
So if you use this, a credit would be nice, as this took quite some time. :)
I hope I did not forget anything. If you need more help feel free to PM me on smwcentral.net

Kickchon

PS: This is my first boss, so there will be bugs I did not find yet, let me know if there is something. I'll try to fix it. :O Also because of it being the first boss the code is not the most optimized but AFAIK it runs without slowdown and should process fine.

REFERENCES
----------

Graphics:
    Frostwave from Secret of Mana (Squaresoft)
    Icelance from Secret of Mana 2 (Squaresoft)
    Undine from Secret of Mana (Squaresoft)
    Pushwave handdrawn by me (I know it sucks. ;))
