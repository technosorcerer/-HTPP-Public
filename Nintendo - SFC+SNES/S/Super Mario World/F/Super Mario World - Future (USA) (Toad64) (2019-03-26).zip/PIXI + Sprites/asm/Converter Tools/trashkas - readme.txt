=======
Trashkas
=======

This is a tool I made which converts TRASM style sprites to a format usable by xkas and asar. I made it because TRASM is an extremely bad assembler and sometimes users have trouble inserting sprites with it. To use the tool, select all your sprite .cfg files and drag them onto the application. Alternatively, you can double click the application to automatically convert all files in the folder of the tool. The .cfg file and ASM file will be converted if both are found. Do note that sprites with an invalid .cfg format will obviously not work.

I have not encountered any bugs or issues with converting the sprites packaged with mikeyk's sprite tool, but always do backup your file in case something goes wrong. For any bug reports, report them to Iceguy at http://www.smwcentral.net/?p=profile&id=2593.

=======
License
=======

Don't claim this tool as your own and also don't restribute it without including this document. I will not be held for any damages that arise, direct or otherwise, from the use or presence of this tool.