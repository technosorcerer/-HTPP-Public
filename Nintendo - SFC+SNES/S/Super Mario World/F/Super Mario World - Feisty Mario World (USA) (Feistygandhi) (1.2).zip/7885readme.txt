Feisty Mario World version 1.2
July 1, 2018

This is a romhack designed out of love for Super Mario World, but for those who have played it so much that it's too easy.  The vision for this hack was to make every obstacle in the game faithfully echo the original, but it's full of creative changes to challenge veterans.  There are many balance changes, to include a larger, taller difficulty curve (especially in secret levels) and new obstacles.  Nearly every enemy, every obstacle - every jump - has been changed to varying degrees.  In addition, there are new palettes, a much larger and more diverse soundtrack, and new enemies.

Thank you so much for checking out this hack!

-Feistygandhi