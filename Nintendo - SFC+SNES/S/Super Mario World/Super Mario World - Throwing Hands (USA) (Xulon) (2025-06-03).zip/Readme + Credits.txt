Hey there, thanks for downloading my hack!

THROWING HANDS is a collection of short but challenging levels.
You don't get any powerups to assist you so you'll have to rely on quick thinking and tight platforming skills.
You have infinite lives and instant retries to make the experience much smoother.
I hope you enjoy!


CREDITS:


ASM
AmperSam (Infinite Lives + Infinity Remap)
Donut (Custom Title Screen Fix)
Kevin (Retry System, Free Vertical Scroll)
Koopster (No Goal Sphere Walk)
MellyMellouange (Goodbye Football RNG)
Vitor Vilela & Arujus (SA-1)

GRAPHICS
ECS.98 (Vanilla Title Screen Text)
E-Man38 (Xulon Presents)

PLAYTESTERS
Cape
Erik
K.T.B.
Nitrogen
Segment1Zone2


Here's every song in the game and the person who ported it, in order of appearance:

Sonic Mania - Danger on the Dance Floor (Wakana)
2-gou - Koko Wa (Nanako)
VLDC12- Swamp Theme (icrawfish)
Winning Post 2 - Track 12 (Nanako)
Arcana - Draven's Valley Pass (Nanako)
Touhou Hisouten ~ Scarlet Weather Rhapsody - The Ground's Color is Yellow (Wakana)
Mario Eisouoku ~ IBoCP - Distant Sea of Mangroves (bebn legg)
Dragon Quest V - Deep Underground (icrawfish)
Wagyan Paradise - Roller Coaster (Tamaki)
Novaneo - Fantasy Luck ~ Mystic Winner (bebn legg)
Tiny Toon Adventures Buster Busts Loose - Buster Sky-Jinks (oL7G5poF4c)
Kirby 64: The Crystal Shards - Silent Forest (Milon Luxy)
Shin Megami Tensei II - Battle (Dominator)
WarioWare: Touched! - Rainbow Juice (bebn legg)
Appleseed - Gaia (oL7G5poF4c)
Celestial Fight (RednGreen)
Virt - Nightfall Over the City (MiracleWater)
The Homebrew Channel - Banner (bebn legg)


SPECIAL THANKS
Donut - for making a patch specifically for me to fix a weird title screen graphical bug I was experiencing
Erik - for being my bestie and providing a lot of quality feedback and support during the whole process of making this hack