				================
				8 Powers - Fixed
				================

				  Fix Update 1

			      ====================
			       Changelog of fixes
                              ====================

Fix Update 1 (22/02/2019)
	-Updated the readme and some patch descriptions to not go offscreen with how long the sentences
	 are horizontally, to improve readability.

	-Updated some of our custom sound engine code to eliminate a slight audio delay that happens when
	 changing music tracks mid-gameplay (i.e. when switching to death music, P-switch music, etc.).

	-Shifted sample data around in ARAM to allow for a bigger echo buffer, thereby making it
	 possible to preserve more of the custom music's echo delay settings.

		English version specific:

	-Several 'no Yoshi' and 'no flight' indicators that were missed during initial
	 translation were put into the English version. (There's one 'no Yoshi' level
	 that still doesn't have an indicator, but it was like that in the
	 Japanese version too.)

	-Fixed a typo in one of the level names.

	-Fixed a missing tile in the title screen shown in the closing level.

First Version (03/10/2018)
	-Initial release

				 ==============
				 About the hack
				 ==============

8 Powers is an SMW hack released around 2012, made by a Japanese person going by the
name of 'Mizuno'. It has 62 exits, and was originally released in Japanese.

Like many hacks from that time period, it used a couple of tools and custom assets that
made playback on anything besides emulators like ZSNES and SNESGT impossible and/or glitchy,
as these tools made certain assumptions about how the hardware behaves that were based on the
emulation shortcuts made by these programs.

A specific list of fixes made can be found later in this document.

				==================
				About this release
				==================

For this release, we've both fixed the compatibility issues and done a full translation of the
in-game text and any graphical assets containing such. The ZIP file contains two BPS patches;
one is for the original Japanese version, and the other contains the localized English version.
Both of these have their technical issues fixed (to the extent that we know about them anyway).

Additionally, there are some optional ASM patches included in the ZIP that you can apply.
Some of these might pertain to hardware accuracy aspects, so make sure to take a look in the
"About the ASM patches" section of this document.
We've tried to set it up so applying the patches is really simple, as long as you know basic
OS stuff like how to move files to another directory, open a file in Notepad, and run an executable.

			      =====================
			      About the ASM patches
			      =====================

Once the BPS patch of your choice has been applied, the resulting ROM should be ready
to play on most hardware and software capable of running SNES games without further
modification.

However, there are some more options in the form of ASM patches that you might be interested in.
In this hack's case, we've included patches for the following:

	- FastROM patch, which might help with reduce some lag.
	- Variation of the FastROM patch which only makes the NMI routine run faster.
	  	This will eliminate scanline flickering in at least one level,
		while leaving the bulk of lag in the rest of the ROM intact, if you
		care about that.
	- A Japanese-only patch which fixes a level name at the end of the hack, where the author
	  had mistakenly put the name in the editor on the wrong level number.

We have tried making the process of applying these patches as simple as possible, so
even if you've never done anything with ASM before it shouldn't take longer than a
few minutes to find out what they all do and to actually apply the ones you want.

The process uses a program called "Asar" by Alcaro (and others), which is not our work, but a
cut-down copy of which (only including the .exe and license information) is supplied inside
this zip file for the sake of ease of use.
The full program can normally be found at these addresses:
https://www.smwcentral.net/?p=section&a=details&id=14560
https://github.com/RPGHacker/asar

Below is a step-by-step guide to learning what all the ASM patches do, and how to apply them.

1. Prepare the ROM by applying either of the BPS files to a clean, headered USA version ROM of
	Super Mario World, and placing it into the 'asar161' folder.

2. Go to the 'asar161' folder, and open '@main.asm' in a text editor of your choice (Notepad will work).

(You can skip step 3 and step 4 if you want all of the patches possible.)

	3. Read the explanations about each patch inside this file to decide which patches you
		want applied to the ROM, and follow the instructions.

	4. Make sure '@main.asm' has been saved with any edits you made.
		(Take care in step 6 if you rename this file.)

5. Run 'asar.exe'.

6. When asked for the patch name, enter "@main" (without quotes) or whatever
	else you have renamed it to.

7. When asked for the ROM name, enter the file name of the ROM that you put in the same folder
	in step 1, with or without file extension.

And now if nothing has gone wrong (it shouldn't), you will get a list of the patches that have
been applied, and a message saying that the patch has been applied successfully.
The ROM is now ready to be played.

			  ======================================
			  Compatibility problems that were fixed
			  ======================================

	- Broken music related to excessive echo delay and the use of Carol's AddMusic tool.

	- Robotic noises due to SMW's music engine reloading wrong instrument data after sound effect
	  finishes playing on a channel that is doing percussion.

	- Bugged sprites due to the use of old SpriteTool
	  (which makes incorrect assumptions about the state of RAM).

	- Custom code that makes incorrect use of SNES multiplication and division registers.

					=======
					Credits
					=======

This is a list of all the people whose software/patches we've used or adapted on this hack,
or included as options in the ZIP file.

Asar 				- Alcaro et al
Extended Overworld Level Names 	- Smallhacker
Extreme FastROM 		- Ersanio
Fixed Color Data NMI Optimizer 	- Ladida

Translation and music fixing by This Eye o' Mine.
Proof-reading and testing by Ryrir.
Additional testing by Xenochu.

And of course thanks to the person who made the original hack: Mizuno.

Sorry to any people we might've missed.

- The Hack Fix/Translation team