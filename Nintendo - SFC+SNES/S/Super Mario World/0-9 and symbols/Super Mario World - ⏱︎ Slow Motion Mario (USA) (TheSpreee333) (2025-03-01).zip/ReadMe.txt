Music credits 

EarthBound - Pyramid
by:     Kevin
https://www.smwcentral.net/?p=section&a=details&id=24820

Kirby's Block Ball - Stage 2
Author:	EDIT3333
https://www.smwcentral.net/?p=section&a=details&id=38741

Donkey Kong Country - Aquatic Ambiance
Author:	Xulon
https://www.smwcentral.net/?p=section&a=details&id=22019

Star Fox - Meteor
Author:	DanTheVP
https://www.smwcentral.net/?p=section&a=details&id=22063


