note: 
when you drop any item in midair while mario is spinjumping......this item will go under mario, in normal jump it still work like normal....remember this because you will need that later
