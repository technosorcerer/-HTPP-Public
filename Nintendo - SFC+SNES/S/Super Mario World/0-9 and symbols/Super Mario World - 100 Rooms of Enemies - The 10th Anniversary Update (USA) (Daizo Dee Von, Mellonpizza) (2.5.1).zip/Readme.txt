Hey there! If you really are reading this (which by opening this, you are. Don't close it now, read on...), then you up for a challenge. This is 100 Rooms of Enemies, a hack based off of Paper Mario's Pit of 100 Trials side challenges. Your objective is to clear away all the enemies (and sometimes objects) on the screen in order to progress to the next "room". As you progress, rooms will become harder and harder until you eventually get to Room 100, where the hardest room to clear lies. What could be lurking there, you may ask? I'll let you find out yourself.

There are two versions of the game in the ROM: "Arcade Mode", and "Do or Die Mode". Arcade Mode essentially allows 5 credits to get through the enemy rush, meaning you can only die 5 times unless you find hidden 1-ups within the rooms. Do or Die Mode gives you no lives, and you have only one shot to clear all the rooms. How many rooms can you pass in the Do or Die Mode without dying once? Comment in the description of the hack to brag; I'd love to see your scores!

Hack History:
V2.5.1: "10th Anniversary + 1 Day Update"
-Added missing credit for mario90, as well as character rights in-game (2channel, raocow and Yukivee).
-Added LEGACY GAUNTLET to The Moon Vault.
-Added THE BOSS RUSH to The Moon Vault.
-Added new music for the two 'mini games' above.
-Added new portrait areas at the end of the two 'mini games' above.
-Fixed the save prompt not actually saving in Nightmare Mode Demo.
-Fixed sfx in the restart screen.
-Removed Herobrine


V2.5.0: "10th Anniversary Update"
  *Too many changes, I can't remember all of them, so forgive me.
-Merged "Arcade Mode" and "Do or Die" into the same ROM.
-Added Nightmare Mode Demo (first 50 rooms)
-Added/Changed a few songs
-Added the ability to skip the death animation.
-Nerfed a few rooms
-Fixed all bosses
-Fixed all softlocks (hopefully)
-Fixed missing number for the lives counter in the restart screen.
-Various sprites are now ignored when clearing rooms
-Added shoutouts
-Added scores from both RHR races
-Revamped "The Moon Vault"
-Removed Herobrine

V2.0.0:
-Second Release in Summer 2015
-Fixed Fryguy
-Fixed Room 66
-Revampt Room 69
-Revampt Room 83
-Tweaked Room 85
-Renew Room 100
-New "Nintendo Presents" logo & SFX
-Tweaking the "special prize"
-Credits Added
-Added two Modes (Arcade & Do or Die)
-Added new music

V1.0.0:
-First Release in Summer 2014