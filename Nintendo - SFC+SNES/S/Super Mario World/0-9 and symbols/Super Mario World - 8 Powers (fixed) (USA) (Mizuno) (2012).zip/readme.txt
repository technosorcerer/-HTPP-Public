================
8 Powers - Fixed
================

==============
About the hack
==============

8 Powers is an SMW hack released around 2012, made by a Japanese person going by the name of 'Mizuno'.
It has 62 exits, and was originally released in Japanese.

Like many hacks from that time period, it used a couple of tools and custom assets that made playback on anything besides emulators like ZSNES and SNESGT impossible and/or glitchy, as these tools made certain assumptions about how the hardware behaves that were based on the emulation shortcuts made by these programs. A specific list of fixes made can be found later in this document

==============
About our work
==============

In our fixes of old hacks, we try as much as possible to preserve the way the original hack worked internally. For instance, hacks that used a custom music loading engine have not had this engine replaced, but simply had their assets edited so that they're no longer loaded in such a way that crashes the SNES, and had the N-SPC music engine that SMW uses patched to eliminate a couple of other sound bugs arising from the assumptions about ZSNES' sloppy emulation. The result is that the hack will pretty much work and sound exactly as it would on ZSNES (minus ZSNES' terrible sound quality), and in some areas the music might incidentally even be a bit less glitchy than it used to be.

Note however that as a rule we are not concerned with making the hack's game design 'better' or otherwise fixing bugs that would've been present when playing the original hack on ZSNES. Some of the ASM patches included as options might perform this task to some extent where we thought people might enjoy or appreciate it, but the base BPS patch only fixes stuff that would (or might) have broken gameplay due to hardware or emulator assumptions. The contents of the ASM patches are basically up to our whims, so we're not really open to suggestions. If you want to write your own and share them, we're not stopping you of course!

==================
About this release
==================

For this release, we've both fixed the compatibility issues and done a full translation of the in-game text and any graphical assets containing such. The ZIP file contains two BPS patches; one is for the original Japanese version, and the other contains the localized English version. Both of these have their technical issues fixed (to the extent that we know about them anyway).

Additionally, there are some optional ASM patches included in the ZIP that you can apply for options like for example FastROM. Some of these might pertain to hardware accuracy aspects, so make sure to take a look in the "About the ASM patches" section of this document. We've tried to set it up so applying the patches is really simple, as long as you know basic OS stuff like how to move files to another directory, open a file in Notepad, and run an executable.

We don't mind if you want to redistribute anything, but ask that you redistribute the entire ZIP file for the sake of anybody that might want the extra ASM patches.

=====================
About the ASM patches
=====================

Once the BPS patch of your choice has been applied, the resulting ROM will be ready to play on any hardware or software capable of running SNES games. It will be as authentic as possible to the original hack, with only data and code that might have caused a compatiblity issue on accurate emulators and real consoles changed to work as intended. Obviously, the English version will also have some more edits done for language reasons.

However, there are some more options in the form of ASM patches that you might be interested in.
One of these concerns a (purely graphical) hardware compatibility issue, so it would be a good idea to at least take a look at what they do to decide whether you want them applied.
Besides that, there's some things that might make gameplay more enjoyable, such as a patch that reduces lag and one that adds Dragon Coin collection indicators.

We have tried making the process of applying these patches as simple as possible, so even if you've never done anything with ASM before it shouldn't take longer than a few minutes to find out what they all do and to actually apply all the ones you want.

The process uses a program called "Asar" by Alcaro, which is not our work, but a copy of which is supplied inside this zip file for the sake of ease of use.
The program can normally be found at these addresses:
https://www.smwcentral.net/?p=section&a=details&id=14560
https://github.com/RPGHacker/asar

Below is a step-by-step guide to learning what all the ASM patches do, and how to apply them.

1. Prepare the ROM by applying either of the BPS files to a clean, headered USA version ROM of Super Mario World,
	and placing it into the 'asar150' folder.

2. Move all of the files found in the 'asm_patches' folder over to the 'asar150' folder.
	(Make sure these files and the ROM are all in the same folder as 'asar.exe')

3. Open 'main.asm' in a text editor of your choice (Notepad will work).

4. Read the explanations about each patch inside this file to decide which patches you want applied to the ROM, and follow the instructions.
	(You can skip step 4 and step 5 if you want all of the patches.)

5. Make sure 'main.asm' has been saved with any edits you made.
	(Don't rename it.)

6. Run 'asar.exe'.

7. When asked for the patch name, enter "main" (without quotes).

8. When asked for ROM name, enter the file name of the ROM that you put in the same folder in step 1, with or without file extension.
	(So if you named the rom "test.smc" you can enter either "test" or "test.smc".)

And now if nothing has gone wrong (it shouldn't), you will get a list of the patches that have been applied,
and a message saying that the patch has been applied successfully. The ROM is now ready to be played.

======================================
Compatibility problems that were fixed
======================================

	- Broken music related to excessive echo delay and the use of Carol's AddMusic tool.
	- Robotic noises due to SMW's music engine reloading wrong instrument data after sound effect finishes playing on a channel that is doing percussion.
	- Bugged sprites due to the use of old SpriteTool (which makes incorrect assumptions about the state of RAM).
	- Custom code that makes incorrect use of SNES multiplication and division registers.

	And one of the optional patches greatly reduces the flickering at the top of the screen in at least one level at the expense of also reducing lag. Only apply that one if you can deal with the reduced authenticity of having less lag.

=======
Credits
=======

This is a list of all the people whose software/patches we've used or adapted on this hack, or included as options in the ZIP file.

Asar - Alcaro et al
Extended Overworld Level Names - Smallhacker
Extreme FastROM - Ersanio
Fixed Color Data NMI Optimizer - Ladida

And of course thanks to the person who made the original hack: Mizuno.

Sorry to any people we might've missed.

- Ryrir, Super Maks 64, and This Eye o' Mine