####################################################

   A R E   T H E   E N E M I E S   S M A R T E R
          T H A N   A   C A V E M A N ?

        Mushroom Kingdom: Beyond The Worlds
               Darkness Arc Part #5

             ------------------------

     From the maker of 100 Rooms of Enemies,
     "no name," R-ACK, ~omh~, and many other
     ROM Hacks.

                 VERSION:  1.0.0

####################################################

Thank you for those who downloaded this rom hack.
Those who don't know how to patch BPS files should
first download FLIPS from SMW Central's Tool
Section, then apply this to a clean Super Mario
World rom (if you're lucky to have one). To test
if it's applied successfully, you should see the
"DDV Presents" logo. If you see that, we're
good. If you just see Super Mario World with the
Nintendo logo, you're just playing the original
game. Insert "mention about it being a good game"
here.

"Are the Enemies Smarter Than A Caveman?" is a
traditional ROM Hack that plays similar to the
levels created by the same author between the JUMP
Team Hacks and a handful of others. The levels are
on the shorter side, with the exception of the
final level "THE NOBODY BEAT."

One thing that stands out above most other ROM
hacks is that the enemies in this game are
individuals with different attributes. The same
set of enemies can act differently to each other,
from different speeds to special abilities. That
is why the hack is titled the way it is.

Oogtar is the main character, who is on a quest of
avenging the Mario Brothers from a sudden explosion
from a homing missile launched seemingly by the
"evil" Krackenwolf of "Krack The Hack" fame. You
trek in the flooded ruins of Bowser's Valley to try
to find and question the orange koopa menace.

####################################################

WHAT TO EXPECT:
-A handful of cutscenes
-Oogtar being a playable character
-A handful of bosses
-Very tough but short levels
-A final level that tests your skills.

####################################################
	VERSIONS
####################################################
v1.01
	- Removed player 2 option
	- Herobrine removed.
	
v1.00
	- First release
	- Who knows what horrible bugs lay in this
	version for the inevitable v1.01 :D

v0.56 and anything prior to 1.00
	- Various Betas
	- As they always say, "it used to be worse!"

v0.00
	- Super Mario World


####################################################
			CREDITS
####################################################
-PRODUCER-      
  Daizo Dee Von 

-VOICE OF KRACK PROVIDED BY-
  JamieB0i / Farolicious    

-TESTERS-   
  amhunter
  Anorakun  
  JamieB0i  
  Hwailaluta
  Mellonpizza
  patcdr    
  SF - The Dark Warrior
  Skewer
  
-MUSIC-         
  Ahrion        
  Blue Warrior  
  ChaseNScooter 
  Daizo Dee Von 
  Edit3333      
  Exodust
  ggamer77
  Giftshaven    
  imamelia      
  Kevin         
  LadiesMan217  
  Masterlink    
  Mayonnai
  Milon Luxy    
  S.N.N.        
  Sacri Pan     
  SiameseTwins  
  Ultima        
  
-GRAPHICS-      
  daemoth       
  Daizo Dee Von 
  danikk04      
  imamelia      
  Izzi Rae      
  JamieB0i      
  Mellonpizza   
  WaxPoetic     
  
-SPRITES-        
  Blind Devil     
  Daizo Dee Von   
  Darolac
  Ersanio
  Iceguy          
  imamelia        
  lion            
  mikeyk          
  Ymro            
  yoshicookiezeus 
  
-BLOCKS-        
  Alcaro        
  HammerBrother 
  MarioE        
  
-UberASM-       
  Daizo Dee Von 
  dtothefourth  
  JackTheSpades 
  Ladida        
  Mellonpizza   
  Vitor Vilela  
  
-PATCHES-
  Alcaro        
  Arujus        
  AxemJinx      
  Daizo Dee Von 
  edit1754      
  Erik          
  Kevin         
  imamelia      
  MathOnNapkins 
  NoelYoshi     
  Noobish Noobsicle
  ShUriK KiD    
  Tattletale    
  Vitor Vilela  
  
-TOOLS-                                           
  AddmusicK 1.0.9 by Kipernal et. al.             
  Asar by Alcaro et. al.                          
  Audacity by The Audacity Team                   
  Dyzen Sprite Maker by anonizwx                  
  Effect Tool by JackTheSpades, dtothefourth      
  F.L. Studio 12 by Image-Line                    
  GPS 1.4.21 by The Biob and p4plus2              
  Lunar Magic 3.33 by FuSoYa                      
  PIXI by Atari2.0, JackTheSpades, and Tattletale 
  SMW Misc. Text Editor by Smallhacker            
  SnesGFX v2.62 by Vitor Vilela                   
  Text To Map16 by MM102 (oh hi I'm using it rn)  
  UberASM Tool 1.4 by Vitor Vilela                
  YY-CHR v0.98 by yy                              

-INSPIRATIONS-                
  100 Rooms of Enemies        
  A Fox in Space
  Betterified VI: Bestified   
  Casio Mario World
  Donkey Kong Country         
  Inktober 2022               
  JUMP                        
  Kaizo Mario World           
  Krack The Hack              
  Mega Man 4 Minus Infinity   
  SMW: The After Years        
  The Devious Four Chronicles 
  UNDERTALE                   
  
-SPECIAL THANKS-             
  ChaseNScooter              
  EvilGuy0613                
  JamieB0i                   
  Mellonpizza                
  Yukivee                    
  Team JANK                  
  JUMP Team                  
  h.carrell
  juzcook
  raocow
  patcdr
  drkrdnk
  Laserbelch