---CREDITS---



Musics


Mario Paint - Big Robo Bug  brickblock369

Super Mario Advance 2 - Status Screen  MrCheeze

Kirby Super Star - All Star Rest Area  DDDDOS7HQM

Super Mario 3D World - Super Bell Hill  Zavok

Kirby's Adventure - Butter Building  Gamma V

Super Mario 64 - Hazy Maze Cave  S.N.N

Super Mario Land 2: 6 Golden Coins - Athletic Theme  Gamma V

Super Mario RPG: Legend of the Seven Stars - Beware of Forest Mushrooms  Dippy

New Super Mario Bros. - Castle  imamelia

(Super Mario Bros. 3 - World 2 (Desert World))  MidiGuy

New Super Mario Bros. - Desert  Anas

Kirby Super Star - Trees in the Depths of the Earth  Anas

Super Mario 64 - Dire Dire Docks  bebn legg

Cave of Doom  gpetry

Luigi's Mansion - Main Theme  A_Known_Enemy

Super Mario Bros. 3 - Athletic  MidiGuy

Kirby's Return to Dream Land - Desert Area (Kirby's Dream Land 3 Style)  JX444444

Mega Man 2 - mm2wily1.mml ~ Dr. Wily's Castle 1 & 2 (2008 SMW-Mix)  Hooded Edge

Super Mario Bros. 3 - World 6 (Ice World))  MidiGuy

Super Mario 64 - Cool Cool Mountain  Goomba-24

Super Mario World 2: Yoshi's Island - Athletic  Jimmy

Mario Kart 64 - Frappe Snowland SNN

Yoshi's Island - Cave  LadiesMan217

Cave (High Icy Mix))  MidiGuy

Kirby's Return to Dream Land - Sky Tower  Hiro

Super Mario World - Athletic (Remix)  HarvettFox96

Super Mario World 2: Yoshi's Island - Castle & Fortress  LadiesMan217

New Super Mario Bros. Wii - Beach - Goomba-24

The 9th Annual VLDC - Beach Resort Map - Dr.Tapeworm/G.D./Lui37/Pinci/Magiluigi/Medic/Tato/S.N.N./Torchkas/Wakana/Wavee

Kirby's Dream Land 3 - Sand Canyon 2 - Nanako

Super Mario Maker - The House Mario Ignored Is A Dungeon?! ~ SMB Ghost House - Daizo Vee Von

Super Mario Bros. 3 - Underwater -  MidiGuy

Sonic the Hedgehog 2 - Aquatic Ruin Zone - Hazel

Super Mario 3D Land - Overworld - RednGreen

Super Mario Bros. 3 - Fortress/Castle Theme - MidiGuy

Mario Kart: Super Circuit - Bowser Castle - Giftshaven

Super Smash Bros. -﻿ Ness Wins  HarvettFox96

Kirby Super Star - Staff Roll  Ice Man

--------------------------------------------------------
Graphics

Flower Garden  Gamma V

Kirby Super Star - Green Greens  Rykon

Super Mario All-Stars Super Mario Bros. 3 - Forest Leaves  AmperSam

Ramadesh Desert  HarvettFox96

Dungeon / Sewer  Gamma V

Shaman King: Master of Spirits - Volcano Cave  Roberto zampari

Super Mario World 2: Yoshi's Island - Clouds (Sluggy the Unshaven)  Ayami

Snow "2013"  Gamma V

Snowy Mountains  Gamma V

Gemstone Cave  Gamma V

Popful Mail (SNES) - Hargel Island (Ice Mountains)  Anorakun

Super Mario All-Stars: Super Mario Bros. 3 - Green Mountains (With Snow)  Natsuz2

Super Mario All-Stars: Super Mario Bros. 3 - Athletic  imamelia

Ice Palace Gamma V

Sprites + base

Super Mario Maker 2: Super Mario World - Luigi (Includes SMAS Poses)  Kusamochi

Wario & Waluigi  SuperLuigiBros

Super Mario World 2: Yoshi's Island - Yoshi  Ripped

Classic Beach - Gamma V

Super Adventure Island - Beach -  Masterlink

Athletic - Mr. Pixelator

UnderWater - Gamma V

Super Mario Maker 2: Super Mario World - Ghost House (Night) - Ayami

Super Mario World 2: Yoshi's island - Waterfall Cave - Rykon-V73

Just Another Grassland - Gamma V

Castle "2013" - Gamma V

Catle - Gamma V

Mario Bros. (GBA) - Phases 7 & 8 - NopeContest
-------------------------------------------------------

Patches

Separate Luigi Graphics v3  View

---------------------------------------------------------


Tools Used

LunarMagic

AddMusick

Graphic Editor

Asar

SMW TileEdit

Per Level "Mario Start!" Enable/Disable