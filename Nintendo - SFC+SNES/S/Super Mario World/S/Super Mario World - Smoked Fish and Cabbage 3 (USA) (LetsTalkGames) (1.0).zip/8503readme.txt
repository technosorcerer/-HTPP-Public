SMOKED FISH AND CABBAGE 3
by xMANGRAVYx

28 exits
Kaizo Intermediate-Expert(?) Difficulty

This romhack is heavily inspired by Super Mario Land 2 for the Original Gameboy, and is an ambitious departure from the first two installments. 
The map consists of 5 zones- four zones on the perimeter of the map and one in the center. Each zone has it's own specific theme and concludes with a 
'switch palace' level. The player must complete each zone on the outside of the castle to activate blocks necessary to complete 'The Floor is Lava' on the 
bridge to access the final area. Complete the castle and help our Hero FINALLY leave the 'Other World'.

Each area is filled with it's own theme and level gimmicks to match. Some levels are less difficult than others as seen in previous entries and are meant to
give the player a sense of accomplishment inbetween more challenging areas/setups. The general difficulty targeted was intermediate, however there are some
elements one may deem closer to expert. The graphics and audio were carefully selected in an effort to keep gameplay both satisfying and feeling fresh. 
It also makes use of custom graphics, sprites and other 'chocolate' assets. PACE IS THE TRICK. This hack does have some troll elements as well... 
but nothing a seasoned player hasn't seen already.

SWEET ZONE
-southeast corner of the map
-vibrant visuals
-fast paced gameplay mechanics

RETRO ZONE
-northeast corner of the map
-pays homage to retro Super Mario games
-final level is a 10 room challenge level that takes place in an Original Gameboy game

ZONE OF THE HERO
-northwest corner of the map
-some of the more unique setups in the hack are in this zone
-an assortment of custom assets

CARNIVAL ZONE
-southwest corner of the map
-levels have a dark undertone
-fast paced setups - move it or lose it!!

FINAL ZONE
-center of the map
-all four outer zones and all switch palaces must be completed in order to be granted access to this area
-this is where the difficulty peaks- ESPECIALLY in the last four levels
-the final level in the hack has an RNG gimmick. NOTE: the player is safe under the ceiling....

Clear the castle and our Hero can finally leave the world of Smoked Fish and Cabbage and head home!!


This romhack serves as the finale to the Smoked Fish and Cabbage trilogy. It makes use of more advanced setups, patches, and sprites, and will certainly
challenge players of all skill levels. Good luck, have fun and THANK YOU FOR PLAYING!!