

        ▄████████    ▄█    █▄     ▄█  ███▄▄▄▄      ▄████████ 
       ███    ███   ███    ███   ███  ███▀▀▀██▄   ███    ███ 
       ███    █▀    ███    ███   ███▌ ███   ███   ███    █▀  
       ███         ▄███▄▄▄▄███▄▄ ███▌ ███   ███  ▄███▄▄▄     
     ▀███████████ ▀▀███▀▀▀▀███▀  ███▌ ███   ███ ▀▀███▀▀▀     
              ███   ███    ███   ███  ███   ███   ███    █▄  
        ▄█    ███   ███    ███   ███  ███   ███   ███    ███ 
      ▄████████▀    ███    █▀    █▀    ▀█   █▀    ██████████ (v1.0)

              A Romhack by Doopu (of WhoIsDoopu fame)

SHINE took 2 years to make when it should have taken 3 months. I understand this
is a common occurrence with romhack development.

Most of SHINE was made on stream, with the decoration, final polishing and
playtesting completed offline. It attempts to offer a mixed chocolate/vanilla
experience, featuring both bog-standard platforming and ASM nightmares.

This hack has 12 exits. There are no secret exits, but there are secrets. None
of the secrets are gameplay related, and can be safely skipped if desired. This
includes the Time Capsule.

Pushing 'START' when dialogue boxes are open will skip them.

START+SELECT to leave levels is enabled. This hack autosaves on entry to Overworld.

  ____  _
 / ___|| |_ ___  _ __ _   _ 
 \___ \| __/ _ \| '__| | | |
  ___) | || (_) | |  | |_| |
 |____/ \__\___/|_|   \__, |
                      |___/ 

What the hell? What are you doing here?
'Hello' would have sufficed.
No, I mean... 
Orders from T.
Christ, what is he thinking?
I'm good.
No, you're not. You look like death warmed up. What's that on your lab coat? Jesus...
Huh? Oh... I didn't have time to run a wash.
...
It's okay. We can't stop now.
For God's sake. Look, wait here, let me get you another coat - you know where the kettle is.

   ____              _ _ _       
  / ___|_ __ ___  __| (_) |_ ___
 | |   | '__/ _ \/ _` | | __/ __|
 | |___| | |  __/ (_| | | |_\__ \
  \____|_|  \___|\__,_|_|\__|___/

Playtesters
===========
germdove
gety0pops
MacMoragh

Overworld Graphics
==================
Katrina

Backgrounds
===========
A Dark Place
  Anorakun - Castlevania Dracula X - Stage 5

A Line In The Sand
  Skewer - Underground Cavern

Our Weight
  Anorakun - Chrono Trigger - Death Peak (Mountains)

Where The End Began
  Anorakun - Demon's Crest - Palace of Decadence (Exterior)

The Forgotten
  Roberto zampari - Wickie und die Starken Maenner - Fire Clouds

By Soldiers
  Natsuz2 - The Ninja Warriors - Intro

Not Too Deeply
  Rykon-V73 - Sparkster Level 3
  mason - Shounen Ashibe: Goma-chan no Yuuenchi Daibouken - Lake (Night)
  AleGames - Camping Site

Trial of Wires
  Anorakun - Ganbare Goemon 2: Kiteretsu Shougun Magginesu - Goofy Woods

A Happy Thought
  7601 + Ladida - Cave Story - Outer Wall

The Barricade
  NekohDot - Mega Man 7 - Robot Museum (Exterior)
  idol - Super Mario World 2: Yoshi's Island - Clouds (Sluggy the Unshaven)

Ascension
  Rykon-V73 - Gundam Battle Assault - City Ruins

New Truth
  All previous levels
  Roberto zampari - Lords of Thunder - Demon Castle (Tower)

Credits
  Natsuz2 - Battle Zeque Den - Stage 2

Foregrounds
===========
Multiple
  MarsAmPear - Mars Bars

A Dark Place
  liectreon - Demon's Crest - Dark Forest

A Line In The Sand
  darken - Lava Cave

Our Weight
  Gamma V - Desert "2013"
  Ayami, Jagfillit - Donkey Kong Country - Snow (Layer 3)

Where The End Began
  Roberto zampari - Cave Buster - Tileset

The Forgotten
  PercentN - Graveyard

By Soldiers
  PercentN - City

Not Too Deeply
  MarsAmPear - Mars Bars

The Barricade
  Carld923 - Metal Zone

Ascension
  reghrhre - New Super Mario Bros. U Styled Ghost House Boxes

New Truth
  Gamma V - Choconilla Castle

Music
=====
Fanfare
-------
Janno27 - Orb

Death Song
--------
Blind Devil, Kipernal, Pink Gold Peach - SMW Central Production 2 - Death Songs 

Title
-----
StayAtHomeStegosaurus, bebn legg - The Setting Box

Game Start
----------
VecchiaZim - Vienna 1927?

Credits
-----
icrawfish - Walls That Were Once Called Home

Levels
------
A Dark Place
  LemmyKoopa - Spacy

A Line in the Sand
  Jakeapus - Dusky Forest

Our Weight
  bebn legg - The 12th Vanilla Level Design Contest - Desert Zone

Where The End Began
  Jimmy, Torchkas- SMW Central Production 2 - Flutes of Despair

The Forgotten
  Segment1Zone2, icrawfish - The Village at the End of Time - Longing for Daylight ~ Adagio

Not Too Deeply
  Dispace - Weightless (Sleeping Cover)
  RednGreen - Il Maniero Spettrale - Forest

By Soldiers
  Hooded Edge - Hooded SNES Originals - Groovin' Through The Streets

Trial of Wires
  Slash Man, brickblock369 - Moonlit River

The Barricade
  Crispy - Pyrotechnic Perennial X

A Happy Thought
   icrawfish - Shack Funk

Ascension
   Pinci - On Top of the Castle

New Truth
   RednGreen - Final Castle

Boss
   Fullcannon - Devoid Spirits II - Joker II

Overworld
---------
Exodust - Olivier Messiaen - Oraison

ASM
===
Kevin - constant autoscroll, per level Mario Start, Credits Utilities
dtothefourth - custom camera
Ayami - BG Autoscroll
Medic - Widescreen Overworld
RussianMan - Side Exit Triggers Goal
JackTheSpades, Koopster - Timer Disabler
Aika, imamelia - Disable Bonus Stars
janklorde, TheBourgeyman, Kevin, RussianMan - Code cribbed for with OoT jump
Eduard - Invisible Mario
MellyMellouange - Low Gravity

Sprites
=======
davros, Darolac, imamelia, RussianMan, yoshicookiezeus - Disassemblies
davros - Custom Timed Lifts
Darolac, MellyMellouange - Sprite Killer Sprite
dogemaster - Custom Green Bubble
Donut - Crates
dtothefourth - Custom Vine
Noweiso - Rocket Platforms
wye - NPCs

Blocks
======
spooonsss - Custom Turnblock
HammerBrother - Key Lock Blocks
MarioE - Shatter blocks
MarioFanGamer - Pixel Perfect Spikes
EvilAdmiralKivi - On/Off 1f0

Fonts
=====
TXC Pearl
Green Jerry - Dragon Ball Z: Super Butouden

Baserom
=======
RHR5.8 - Baserom Team
         Additional credits in BASEROM.txt

ASCII Fonts
===========
Delta Corps Priest 1, Standard - https://patorjk.com/software/taag/

Special Thanks
==============
Brakkie - ASM Help (like, a lot)
NixKillsMyths - Design Input
GiganticBucket - Discord Pinger

X. and Y.

My Chat - except for THAT group
