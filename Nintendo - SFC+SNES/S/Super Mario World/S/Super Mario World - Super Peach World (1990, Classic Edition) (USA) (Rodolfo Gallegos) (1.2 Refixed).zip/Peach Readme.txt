v1.2 10-09-2025:
Mario Kissing Peach Is Re-Fixed GFX0D.
Daisy Player 2 Is Playable.
Appears "Peach/Daisy Start!".
Overworld Map Isn't Glitched And Always Be Re-Fixed.

v1.1, 06-05-2025:
100% Accuracy Pallete.
Spin-Jumps Makes In Air Her Peach's Dress.
Refixed Submap with Uppercase And Lowercase Letters Message Box.

v1.0, 02-11-2024:
Edit The Falchion22's SPW Hack.
90% Accuracy Original Pallete.
Peach GFX Found On GFX 22, 24, 26, 2E and 0F.
Animated Jump, Swim, Etc.