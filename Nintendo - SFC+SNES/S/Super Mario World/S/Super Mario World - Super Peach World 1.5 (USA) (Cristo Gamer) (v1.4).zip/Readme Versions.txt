v1.4:
Refixed Overworld Map Exits.
v1.3:
Refixed Status Bar Used
By Linkstorm Z's Peach Lives.
v1.2:
Fixed Peach's Arms And Everything.
v1.1:
Fixed With Red Berries
v1.0:
Making World 1 Levels.