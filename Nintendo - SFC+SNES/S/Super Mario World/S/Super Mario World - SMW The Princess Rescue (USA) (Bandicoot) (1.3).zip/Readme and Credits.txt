
SMW The Princess Rescue is a traditional adventure where you play through platforming levels and need to help Mario to save the Princess. 
It keep the original SMW game mechanics with some modifications.

----------------------------------------------------------------------------
Features:
- New Overworld Map 
- 9 Worlds with 7~9 levels each
- 116 exits to find
- New Level Design
- New Custom Music
- Edited Original SMW Bosses
- DDA System: Dynamic Dificulty Adjustment System based on how many lives you have
- Super Mario World + Super Mario Maker Styled Graphics
- HDMA Gradients
- Expanded SRAM which saves lives, coins,powerups and more
- Star Coins System (Like the one in Classic Mario World 3) 
- Patches that modifies some game mechanics

-----------------------------------------------------------------------------
About DDA:
The DDA(Dynamic Dificulty Adjustment) is a thing I'm testing on this hack, basically if the player 
is struggling to complete a level,the game will get easier when he have a lower number of lives.
The only DDA function added here is if the player has less than a certain number of lives some blocks will spawn a 
extra powerup in the level to help him complete the level, this don't affect anything in the experience for the better players.
For better experience with the game I recomend that you DON'T USE SAVE-STATES OR CHEATS, this way the game will be able to more easily adjust the dificulty for you.
But If you must use save-states I wont stop you, just keep in mind that the game was not designed with any cheat in mind and that it was tested and so its perfectly 
possible to beat it 100% without them.
Good luck and have fun! 

--------------------------------------------------------------------------------------------------------
Credits:

Level Design:
Bandicoot

Beta Testers:
Mes
ZacMario
ForthrightMC
Lordkronos100
MKDSMaster91
erpster2

Special Thanks:
Mes
ZacMario
smwc23105

Tools:
Kipernal
p4plus2
Romi 
FuSoYa
Vitor Vilela
JackTheSpades
Alcaro
Kipernal

Custom Graphics:
SuperMariaSis
KingKoopshi64
Gregor

Custom Blocks:
Nesquik Bunny
Ersanio
JackTheSpades


ASM & Patches:
Noobish Noobsicle
Maxx
LX5 
MarioE
MarioFanGamer
Luigi-San
Alcaro
Erik
Custom Sprites:
Romi
Erik557
Tsutarja
edit1754
Alcaro
Le Comte Niark
imamelia
Ladida
TheBiob
JackTheSpades
Nesquik Bunny
Glyph Phoenix
DiscoTheBat

Custom Music:
GammaV
smwc23105/Pink Gold Peach/GD/GameplaysDetonados
Dan
DAA234
MercuryPenny
Mandew
imamelia
HarvettFox96
Kil
Wakana
Pinci
CrispyYoshi
Tornado
Pinci
Hadron
Darius
Sayuri
ggamer77
Blind Devil
Roberto zampari	
NastCF
Slash man
Atma
LadiesMan217	
Lui37
Torchkas
x-treme
S.N.N.
Moose
HarvettFox96	
MidiGuy
TCDW



Sorry if I missed someone,there's a lot of people :(
I hope you Enjoy the Game!
