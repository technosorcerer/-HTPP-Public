SMOKED FISH AND CABBAGE
by xMANGRAVYX
-Dedicated to the Loving Memory of Noah James-

7 exits
Standard Normal-Hard difficulty

This romhack was designed with accessibility in mind. My intention was to create a hack hard enough for beginners
to grind, but easy enough a more skilled player could breeze through it. I kept the project small on purpose to not
overwhelm myself during the learning process, and designed a small world with 7 levels. Each of the 7 levels has it's
own unique theme, and the difficulty curves with progression. I carefully chose each soundtrack and template to
reflect the tone of the level I was designing at the time. All levels were short enough I felt checkpoints weren't necessary.


Level 1) RETRO GRAVY
-inspired by and designed to look like a level in a gameboy game
-carefully selected shades of green to avoid foreground/background blending

Level 2) CHECKPOINT CITY
-coined phrase in the Mario Maker community I felt would make a cool level concept
-literally a city of checkpoints used as decoration - not one functions as a real checkpoint

Level 3) THE DANGER ZONE
-my first level designed in Lunar Magic!
-redesign of a 20 second speedrun level I created in Mario Maker 2

Level 4) CHEDDAR BELIEVE IT
-went with shades of yellow and orange to create a 'cheesy' tone
-slightly more precise level design than the previous 3

Level 5) THE CLOT THICKENS
-inspired by true life events, this level is designed to feel as though it takes place in the body
-shades of red and white used to support the level concept

Level 6) BELLY OF THE BEAST
-underwater level designed as a nod to the DAM level in the NES version of TMNT
-pink weeds damage the player, some paths are intentionally tight

Level 7) NONE SHELL PASS
-vertical tower ascension
-general theme is a black fortress with red accents

This romhack was designed with passion and determination- Thank you for playing!!