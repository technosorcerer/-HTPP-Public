DIFFICULTY EXPLANATION:
NORMAL MODE has infinite lives and saves every level.
HARD MODE does not have infinite lives, and saves every world.

v1.1:
-Added 3 warp zones.
-Various minor level design changes.
-Visual fixes to 9-4 on console.