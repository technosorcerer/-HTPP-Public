===============================
 Straight Shellin'
 By: RedPandaa_
 Version 1.0
===============================

ABOUT
-----
Straight Shellin' is my first kaizo hack and the first set of levels 
I’ve ever created. The hack was made using the Fluxbase 2 base ROM.

This hack is on the tougher side, and players should expect 
challenging setups and execution throughout. Since these are my 
first levels, the design may be rough in spots, but the hack is 
meant to be a genuine learning project and a first step into 
kaizo creation.

EXITS
-----
7 total exits (including the Credits level)

NOTES
-----
• Everything in the hack reflects my early experience as a creator.
• All credits are included in the in-game credits level.

CONTACT
-------
If you'd like to report a bug or give feedback:
SMW Central: RedPandaa_