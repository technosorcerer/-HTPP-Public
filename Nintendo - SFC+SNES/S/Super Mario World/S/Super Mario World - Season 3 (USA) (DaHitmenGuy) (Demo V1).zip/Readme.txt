Storyline:
Bowser once again Kidnaps Princess Peach from the Peach's Castle,
Mario's adventures in Mushroom Kingdom continues in Season 3.
That is my first demo hack

Credits for this hack
Graphics:
LumSht

Sprites:
Sonikku
mikeyk
EternityLarva
Darolac


UberAsm:
Ayami
KevinM
Ruberjig

Music:
Pinci
LadiesMan217 = SMB3 Desert Land Map

Hack Tester:
ForthRightMC

..and others that I will remember for credit them

© DaHitmenGuy 2022
