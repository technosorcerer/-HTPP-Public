			   ===========================
			   Scarlet Devil Mario - Fixed
			   ===========================

				 ==============
				 About the hack
				 ==============

Scarlet Devil Mario (as it is often abbreviated to anyway) is an SMW hack released around 2009,
made by a Japanese author called Pyua. It has 60 exits, and was originally released in Japanese.

This hack is known for its extensive use of custom assets, including graphics, music, and bosses,
most of which were made by the author himself.
It's by and large based on the Touhou franchise, featuring characters from the first half
of the game Embodiment of Scarlet Devil.
Also interesting is its difficulty system, as there is basically one set of levels that are
repeated with significant variations across four different paths on the overworld, each
representing one of the difficulty modes found in the Touhou games.

Beware, as this hack gets difficult and quite tedious due to its design fairly quickly.
I'd only recommend you try to complete it from 'Hard' mode levels without savestates if
you're prepared for a lot of repetition due to unfair deaths.

				==================
				About this release
				==================

For this release, we've done a full translation of the hack into English.
We've also fixed a small number of compatibility issues, so that this
hack can be played on a real console (hopefully) without major bugs.

Patches for both the Japanese version and English version are included.
Both have had their compatibility problems fixed.

There are several optional ASM patches that add minor features and fix some
of the more severe technical issues which plagued this hack even on ZSNES.
Check the section below for how to configure and apply them.

			      =====================
			      About the ASM patches
			      =====================

Once the BPS patch of your choice has been applied, the resulting ROM should be ready
to play on most hardware and software capable of running SNES games without further
modification.

However, there are some more options in the form of ASM patches that you might be interested in.
In this hack's case, we've included patches for the following:

	- Translator note to explain some of the cultural references (English version only).
	- Dragon Coin collection indicators on the OW, similar to the ones in this hack's sequel.
	- Fix for the major lag problem this hack has due to an ancient implementation of BlockTool.
		(Also includes FastROM)
	- Fix for the long loading times this hack has due to some ASM that spends lots of time doing
	  literally nothing of any useful consequence.

We have tried making the process of applying these patches as simple as possible, so
even if you've never done anything with ASM before it shouldn't take longer than a
few minutes to find out what they all do and to actually apply the ones you want.

The process uses a program called "Asar" by Alcaro (and others), which is not our work, but a
cut-down copy of which (only including the .exe and license information) is supplied inside
this zip file for the sake of ease of use.
The full program can normally be found at these addresses:
https://www.smwcentral.net/?p=section&a=details&id=14560
https://github.com/RPGHacker/asar

Below is a step-by-step guide to learning what all the ASM patches do, and how to apply them.

1. Prepare the ROM by applying either of the BPS files to a clean, headered USA version ROM of
	Super Mario World, and placing it into the 'asar161' folder.

2. Go to the 'asar161' folder, and open '@main.asm' in a text editor of your choice (Notepad will work).

(You can skip step 3 and step 4 if you want all of the patches.)

	3. Read the explanations about each patch inside this file to decide which patches you
		want applied to the ROM, and follow the instructions.

	4. Make sure '@main.asm' has been saved with any edits you made.
		(Take care in step 6 if you rename this file.)

5. Run 'asar.exe'.

6. When asked for the patch name, enter "@main" (without quotes) or whatever
	else you have renamed it to.

7. When asked for the ROM name, enter the file name of the ROM that you put in the same folder
	in step 1, with or without file extension.

And now if nothing has gone wrong (it shouldn't), you will get a list of the patches that have
been applied, and a message saying that the patch has been applied successfully.
The ROM is now ready to be played.

			  ======================================
			  Compatibility problems that were fixed
			  ======================================

	- Custom code that makes incorrect use of SNES multiplication and division registers.
	- SpriteTool's incorrect assumptions about the initial state of certain values in RAM.
	- Music that crashes and locks up the game due to the use of Carol's old AddMusic tool.
	- Audio data getting stuck in the echo buffer, causing it to stutter that sound until echo
	  is disabled.

				    ==============
				    About our work
				    ==============

We're a small team that fixes old hacks that suffer compatibility issues due to
using tools and code that were designed with ZSNES and SNESGT's inaccurate
emulation in mind. We take a low-level approach, opting to fix the specific
issues using precision ASM patches rather than replacing their assets entirely,
in the hope that the result will be as accurate as possible to how the hack
would've played on ZSNES.

Keep in mind that we are NOT concerned with making these old
hacks 'more playable' by changing gameplay aspects, or fixing other bugs
that would've been present originally. However, if a hack has severe problems
that could easily lead to crashes or softlocks, or if there are features that we
personally thought would be neat to see, then we will include ASM patches that you
can apply to the ROM as an option. Check the instructions above for how to apply them.

One last note is that none of these hacks were made by us. We take no credit for
the original design, only for the fixes and translations applied to them.
We hope this will allow these hacks to be preserved, and played by more people.

					=======
					Credits
					=======

This is a list of all the people whose software/patches/work we've used or adapted on this hack:

Asar 					- Alcaro et al
Recover Lunar Magic 			- Parasyte
Overworld Counters 			- Ladida
SRAM Expand 				- Deflaktor
Extended Overworld Level Names 		- Smallhacker
Extreme FastROM 			- Ersanio
Translator Notes patch 			- Super Maks 64
Message Box Chaining patch 		- Super Maks 64

Translation and fix ASM by This Eye o' Mine
Proofreading and testing by Ryrir
Additional research and proofreading by lion

And of course Pyua who made this hack in the first place.

Sorry to any people we might've missed.

- The Hack Fix/Translation team