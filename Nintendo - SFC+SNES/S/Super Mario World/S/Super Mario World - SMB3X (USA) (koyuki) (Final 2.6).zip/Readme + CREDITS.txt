SUPER MARIO BROS. 3 X 
This is the final version of my hack. You can play it until World 9.


Note: The best emulator compatible with this hack is ZSNESW 1.51.
I don't know about other version since it's the only one i used.
SNES9X is incompatible with this.

Another note: Now it works on Snes9x, as well in BSNES.


Story:Bowser and the Koopa Kids Invaded seven islands and their 
next target is Mushroom Kingdom. Mario must stop 
them before it's too late.


Note for some people who request to base their hacks from SMB3X:

1. I'm not allowing people to base their hacks on this hack anymore.
   Because even if i allow people to base from my hack, it's useless because
   of some asm hacks already installed there like the Pause from the status
   bar.Even if you use a status bar editor, it will return to SMB3X letters
   when unpaused .Another thing is i used a lot of custom sprites and blocks
   and i also used custom music so there won't be any large freespace.

2.Do not rip FG graphics from SMB3X that was originally made by me. You can
  use the some of my other graphics as long as you have my permission.Just PM me.


Credits:

Graphics - Pac(Graphics Hack),andy_k_250(SML sprites),Mirumo.
Custom Blocks - Smkdan (BTSD).Mikeyk (SMB3 Pipes),ICB(SMB2 Blocks)
Custom Sprites -Smwedit,Smkdan,Romi,Mirumo,Davros,Carol,Magus
Custom Music - MidiGuy,Supertails,Carol,Jimmy52905,SNN
Lunar Magic - Fusoya

And to some other people in SMWCentral.





ENJOY.