SMW The Princess Rescue 3 - The turnabout
v1.01 - 03-10-2023

This hack is a sequel to my previous hacks SMW The Princess Rescue(2017), and SMW The Princess Rescue 2:Luigi's Journey(2019).
In those two hacks Mario and Luigi both went simultaneously in their own adventures to save their beloved Princess Peach and Daisy from the clutches of Bowser and Tatanga.
At the end of their adventures both went on a honeymoon with their Princesses and here is where SMWTPR3 start.
This hack rather than having the heroes save their Princess has a role-reverse styled story where the Ladies finally get their time to shine, I have been wanting to make this sequel ever since 2020 but with the lack of resources at the time it was not possible, so I shifted my projects into other hacks like SMW The Crown Tale and Quest for Gaming, up until last year when I finally started development on this hack, and now after 1 year of work finally this project is finally completed and its my most ambitious project ever since Classic Mario World 3.
-------------------------------------------------------------
Story:
After their Previous adventures Mario and Luigi went on a honeymoon with their beloved Princesses however Bowser and Tatanga are back to take their revenge sooner than expect, they formed an alliance and release a sudden Kidnap attempt on the Princess, taking both Mario and Luigi by surprised, while our Plumbers manage to protect their ladies both got captured by Bowser and Tatanga instead.
Now with the roles being reversed Peach and Daisy will go on an adventure to save their beloved Plumbers.
------------------------------------------------------

This hack brings a lot of new additions to the gameplay compared to their predecessors, Peach and Daisy have their own moves like being able to float just like Peach in SMB2 or perform a charged jump.
Also they can use the Pink Cape Feather, a new alternative version of the feather that gives them the hability to double jump.
Also new to this hack is the addition of QOL improvements present in my latest hacks like the Autosave, collectibles indicators, slighty faster swimming physics, fast speed on the map and much more.
Also new is the moons will be collected, instead of finding them hidden on the levels the player will have to collect a clock at the start of the level and partake on a time trial challenge to get the moon at the end, a neat little adittion to add some more replay value.

To resume it all, this hack features:

- 88 new levels with 120 exits to find
- Custom graphics
- Custom music
- Custom sprites and bosses
- Several Quality of life improvements to the gameplay
- Autosave
- New gameplay movesets
- Time attack challenges for 3up moons
- Lots of secrets to find

I hope you enjoy!
-------------------------------------------------------------- 

Credits:
--------------------------------------------------------------

Level Design and Game Design:
Bandicoot
-----------------------------------
Beta Testers:

MarioZuero
DarkAntonioGamer2022
Deankind
Fire Fast
Rgothic
Muramatsu
Lordkronos100
Brooklyn Bronkes
Green Jerry
Edgar
Marioisradical
-------------------------------------
Special Thanks:
RussianMan
Lordkronos100
Deankind
Marioisradical
Pink Gold Peach
---------------------------------------------------
Custom Graphics:
Gamma V
FalseCircus
ShadowDragon
Ralshi02
AmperSam
Ayami
Heraga
tmauri
KingKoopshi64
KaidenThelens
Pokerface
Dan
LinkstormZ
S.R.H.
Pink Gold Peach
cheeyev
TheBourgyman
-------------------------------------------------------------------
Custom Music:

Pink Gold Peach
KevinM
FantasticFox
Be11
MaxodeX
RednGreen
Overcrow
Gamma V
Sayuri
marioVSshadow
imamelia
AntiDuck
KoiSAKANA
MarioSonic4life
Giftshaven
Ultima
Samantha
bebn legg
Unknown User
Slash Man
LadiesMan217
SthianFel64
Kyoseron
tssf
Infinity
sinseiga
Decoy Blimp
MidiGuy
Joey
Goomba-24
Dippy
Pinci
Nameless
Lui
Kevin
Marcozzo Daro
Hooded Edge
com_poser
Lumy
musicalman
Vitor Vilela
bebn legg
Ahrion
------------------------------------------------------------------
ASM & Patches:

Alcaro
MarioFanGamer
Ladida
Kevin
Incognito
Blind Devil
WhiteYoshiEgg 
Minimay 
Erik
KevinM
BMF
Iceman
Chdata
Maarfy
JacktheSpades
Noobish Noobsicle
Fakescaper
lx5
Worldpeace
Erik557
Fierce Deity Manuz OW Hacker
MrCheeze
mikeyk
Acrowned
KTB
Roy
Kaizoman
Themorgannah
Russianman
Thomas
JamesD28
Roy
Koopster
Isikoro
Bensalot
--------------------------------------------------
Custom Sprites:

imamelia
RussianMan
Isikoro
Dispari Scuro
Erik557
mikeyk
Iceguy
Romi
Blind Devil
Kevin
Sonikku
1524
smkdan
yan
lolcats439
Incognito
Erik
Alcaro
JackTheSpades
Darolac
Mandew
yoshicookiezeus
Koopster
smkdan
TheBiob
EternityLarva	
----------------------------------------------

Custom blocks:

Kipernal
Major Flare
wiiqwertyuiop	
JamesD28
Francium
GreenHammerBro
RussianMan
JackTheSpades
Iceguy
Darolac
Roy
Sonikku
ncognito
lolcats439
Major Flare
Sayuri



