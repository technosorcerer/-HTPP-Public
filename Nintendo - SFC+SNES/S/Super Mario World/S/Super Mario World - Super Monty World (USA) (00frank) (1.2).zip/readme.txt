
----------------------------

	Super Monty World
		by 00frank
	
----------------------------

NOTE FROM DEV
-----------------------------
Thanks for downloading my hack! 
I hope you have a fun experience playing the levels and don't get frustrated :)
But if you do, or you just want to give general feedback, I would appreciate any comments on the download page.

Importantly, if you have any issues running the game for example crashing (as this is a SA-1 patch), please post your emulator version on the comments section. 
Thanks for reading, and have fun!

WHAT IS THIS O_o
-----------------------------
Welcome to Super Monty World! 
A hack for the people who like to sink their teeth into a longer kaizo experience, this is a Choc-Chip (Mostly vanilla with some custom sprites and ASM) Kaizo:Light hack with 31 exits (can you get the 31-star?), which has a roughly quadratic difficulty curve. That means there's levels for everyone from novices to experienced kaizo players! 

Featuring custom ASM, sprites and music from the lovely people here on smwcentral <3

As my second hack, this makes use of my past experience to create a more polished game with better palettes, more ASM, cleaner controls, more well-designed levels, and no crashes. (hopefully!) This hack took about a half year of intermittent work to complete.

HOW TO USE THIS PATCH
-----------------------------
The .bps file provided is a patch for Super Mario World.
To apply it you need an original SMW ROM, and a file patcher like Floating IPS:
https://www.smwcentral.net/?p=section&a=details&id=11474

You're also gonna need a SNES emulator, although if you have a physical console setup this should still work as there is no SRAM patch.

IF YOU'RE STUCK
-----------------------------
I have created a 100% walkthrough video, which you can use if you are stuck on a section. 
It is available on YouTube:
https://www.youtube.com/watch?v=7pYQwWKM0Cs
	
