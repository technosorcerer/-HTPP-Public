   _____                         _____                _  __                           __          __        _     _ 
  / ____|                       |  __ \              | |/ /                           \ \        / /       | |   | |
 | (___  _   _ _ __   ___ _ __  | |  | | ___  _ __   | ' / __ _ _ __ _ __ ___   __ _   \ \  /\  / /__  _ __| | __| |
  \___ \| | | | '_ \ / _ \ '__| | |  | |/ _ \| '_ \  |  < / _` | '__| '_ ` _ \ / _` |   \ \/  \/ / _ \| '__| |/ _` |
  ____) | |_| | |_) |  __/ |    | |__| | (_) | | | | | . \ (_| | |  | | | | | | (_| |    \  /\  / (_) | |  | | (_| |
 |_____/ \__,_| .__/ \___|_|    |_____/ \___/|_| |_| |_|\_\__,_|_|  |_| |_| |_|\__,_|     \/  \/ \___/|_|  |_|\__,_|
              | |                                                                                                   
              |_|                                                                                ver 1.00  09/11/2022

# Dedicated to
Don Karma
Bathrobe Dwane
Oddkast Podcast
Wizard Legion

# Emulator compatibility notes
Real Hardware - works best here. tested here mostly, this hack really puts emulator accuracy to the test, especially the SPC700.

BSNES - On older versions, the game might randomly crash the emulator (due to an interrupt request), we have tried debugging this issue, recent versions of BSNES do not have this problem, however the debugger and pre v100 just randomly crash sometimes whenever a level or a song is loading.
Snes9x - Use version > 1.60, recommended to set overclock to maximum in Hacks (for no lag), and turn on separate audio buffer, otherwise you may hear sound clicking or the game will lag due to the sound system.
ZSNES - I wasn't able to get this one working well. Using fusoya's 8MB version seems to run the game, however it will randomly crash.

# MSU-1 support
The game supports MSU-1 (both video and audio). You must set up every track individually, There is a MSU-1 pack available, but it won't be posted here.

# Thanks
Thank you for downloading Super Don Karma World. I hope you have a fun time with this hack, like we had creating it.

-Freak Team 2022 and co.