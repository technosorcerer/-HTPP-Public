Tested with latest Snes9x, Bsnes, Original SNES Console. also works on Super NT which I don't have.

NOTE:
- This Romhack Inspires SMB1, SMB3, SML, and Mario Forever.
- There are 4 Zip Folders required password. The Passwords are located in 4 levels in the romhack, you just have to find them. And the Passwords are All CAPS.

v0.5 - 2017
	- Demo Version
v1.0 - 2019
	- First Completed
v2.0 - 2021
	- Feature Changes with some sprites.
v2.2 - 2024
	- Fix some minor bugs, occasionally fixed some instruments on some sample ports, increased the timer for some puzzle levels.

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
Credits:
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

Tools used:
	AddmusicK		v1.0.6		- Kipernal
	Asar			v1.71		- Alcaro
	GPS			v1.4.1		- p4plus2
	Lunar Address		v1.04		- Fusoya
	Lunar Magic		v2.43		- Fusoya
	PIXI			v1.2.9		- JacktheSpades
	Player Tilemap Editor	v1.1		- SmallHacker
	Racing Stripe		v1.3.1		- Edit1754
	Slogger					- Smkdan
	Tweaker			v12		- Mikeyk
	UberASMTool		v1.4		- Vitor Vilela
	YY-CHR Beta		v0.99		- YY Creator

Graphics:
	- Amomario123w
	- Andy-k-250
	- Black Sabbath
	- Bullymario
	- Buu
	- CaptainFoxx
	- Hinalyte
	- Mippish
	- Mogu94
	- Mr. Bean
	- Pac

Patches:
	- Alcaro
	- Chdata
	- DiscoTheBat
	- Edit1754
	- Ersanio
	- GreenHammerBro
	- Ice Man
	- Imamelia
	- Kaijyuu
	- Lui37
	- Lx5
	- Major Flare
	- MarioFanGamer
	- Mattrizzle
	- S.L.
	- SmallHacker
	- Smkdan
	- Vitor Vilela
	- Wiiqwertyuiop
	- Worldpeace125

Blocks:
	- 1524
	- Alcaro
	- Davros
	- Decimating DJ
	- Edit1754
	- Ersanio
	- Fusoya
	- GreenHammerBro
	- Infrared
	- JacktheSpades
	- Lx5
	- Major Flare
	- MarioEdit
	- MarioFanGamer
	- Mikeyk
	- Roy
	- RussianMan
	- SinD
	- Sonikku
	- SuperMario6791

Sprites:
	- Akaginite
	- Carol
	- Davros
	- Erik
	- Iceguy
	- Imamelia
	- Koyuki
	- Leod
	- Mandew
	- Mikeyk
	- NekohDot
	- RealLink
	- Romi
	- Smkdan
	- Sonikku
	- TattleTale

Music:
	- AntiDuck
	- Bullymario
	- Buster Beetle
	- Dark Mario Bros
	- Dragonfly
	- Gamma V
	- ggamer77
	- gocha
	- Ice Man
	- Jimmy52905
	- KevinM
	- Kil
	- Koji Kondo
	- LadiesMan217
	- Lexator
	- Lu9
	- mario90
	- MidiGuy
	- oL7G5poF4c
	- RednGreen
	- S.N.N.
	- Slash Man
	- Supertails
	- ThinkOneMoreTime
	- Torchkas
	- Tornado
	- Wakana
	- Worldpeace125
