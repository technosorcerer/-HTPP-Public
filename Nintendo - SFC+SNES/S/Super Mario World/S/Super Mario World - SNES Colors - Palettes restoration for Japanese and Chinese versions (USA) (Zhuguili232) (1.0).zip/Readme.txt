Thanks for downloading SNES colors / palettes restoration for Super Mario Advance 2: Super Mario World's Japanese and Chinese versions by Zhuguli232.

The SNES colors / palettes restoration patch aims Super Mario Advance 2: Super Mario World to look like its original counterpart.

These patches are made specifically for Japanese and Chinese versions, if you are in American or European versions, this is NOT for you, go to https://www.romhack.ing/database/content/entry/btNu5JQBNs8FWu0Cnm0f/sma2-super-mario-world-color-restoration instead.

To apply the patch:
if you are using the Japanese version:
apply OGColors4SMA2_JP.ips
to
Database match: Super Mario Advance 2 - Super Mario World + Mario Brothers (Japan).gba
Database: No-Intro: Nintendo - Game Boy Advance (v. 20250313-191605)
ROM SHA-1: 8f3d3c33c77872db9818620f5e581ec0fa342d72
ROM CRC32: 901ce373

if you are using the Chinese version:
apply OGColors4SMA2_CN.ips
to
Database match: Chaoji Maliou Shijie (China).gba
Database: No-Intro: Nintendo - Game Boy Advance (v. 20250313-191605)
ROM SHA-1: 1da3124a73b2f22ed29f53b057e759191dc1f3f3
ROM CRC32: d97d4156

If having issues, please report it to me, I will looking into it.

Version: 1.0
2025/10/5