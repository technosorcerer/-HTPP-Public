_______________________________________________Sonic CD USA (snes edition) final test___________________________________________________________________________|
                                                                                                                                                                |
Hello, welcome to Read Me, my name is Figui, I'm 17 years old Brazilian and I'm trying to recreate Sonic CD in my spare time, using it as my main tool          |
Lunar Magic.                                                                                                                                                    |
                                                                                                                                                                |
IMPORTANT: This hack uses the MSU-1 and Sa-1 chip so not all emulators will work, recommended emulators are snes9x and bsnes.                                   |
                                                                                                                                                                |
                                                   !Build instructions!                                                                                         |
                                                                                                                                                                |
                                                                                                                                                                |
Step(1): download the zip file with the MSU-1 songs at this link https://drive.google.com/file/d/1OnnXsLbCN4InPJQ24cFhpTG-SRN4Gokt/view?usp=drive_link          |
otherwise the game may remain silent or play songs from Super Mario World                                                                                       |
(note this file has almost 1gb of memory because of the pcm audios, a common pattern in hacks that use the MSU-1 chip).                                         |
                                                                                                                                                                |
Step(2): after downloading the zip file, extract it and move the 1scd.smc hack into the 1scdUSA folder along with the .pcm and .msu files                       |
                                                                                                                                                                |
                                                   !how to play!                                                                                                |
                                                                                                                                                                |
                                                                                                                                                                |
This game has time travel mechanics, so you need to read the following information                                                                              |
                                                                                                                                                                |
The phases started in the present in the first two acts, and the third act is a Boss phase where the robotinic traps will be.                                   |
Each phase (apart from the third acts) there are signs with "P" and "F" (past and future) in the game there are two types of futures, the bad future and the    |
good future.                                                                                                                                                    |
                                                                                                                                                                |
1) to do this you need to get a past board (a board written "P") and run for a period of time then find the 5 red rings,                                        |
after collecting them Sonic will automatically make the future good, so look for a sign saying "F" and travel to the present and then find another sign to      |
travel to the good future (the sign written "F"), then reach the end of the stage and enter the special stage ring. Try to get 100% on the post to enter        |
in the Time Stones temple (try going to the special stage 3 times) they will be needed to make the good ending.                                                 |
                                                                                                                                                                |
2) if you want a more difficult route to pass the level, you can go to the bad future and look for the 5 red rings and return to the present, after doing       |
this get an "F" plate and you will be directed to the good future and repeat the special stage process                                                          |
                                                                                                                                                                |
3) now if you want to play without worries go to the end of the stage and get the "Goal" sign (however this will cause the bad ending)                          |
                                                                                                                                                                |
                                                !information about the songs!                                                                                   |
                                 all the music in the game is from Sonic Cd and made by fans                                                                    |
                                                                                                                                                                |
________________________________________________________________________________________________________________________________________________________________|