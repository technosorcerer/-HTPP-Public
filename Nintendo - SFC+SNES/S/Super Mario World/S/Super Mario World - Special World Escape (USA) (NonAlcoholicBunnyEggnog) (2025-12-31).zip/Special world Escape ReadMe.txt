Music Credits:
Nintendo Presents: Happy Tree Friends - Laugh by Kevin
Title (C7): Killer Instinct: TJ Theme by Kevin
Special Overworld: Terranigma - Open The Door by Samantha
Forest of Illusion: The Legend of Zelda: Twilight Princess - Faron Woods by MarioFanGamer
Touniquet: Terranigma - Zue by Ahrion
Solitaire: HAL's Hole in One Golf - Cruising by Segment1Zone2
Judge: Phoenix Wright: Ace Attorney: Justice for All - Magic and Tricks by Kazzzy
Felted Forest: Kirby & The Amazing Mirror - Mustard Mountain (Kirby's Dream Land 3 Style) by JX444444

All ASM/Block Credits go to the Flux Industries Baserom Credits.