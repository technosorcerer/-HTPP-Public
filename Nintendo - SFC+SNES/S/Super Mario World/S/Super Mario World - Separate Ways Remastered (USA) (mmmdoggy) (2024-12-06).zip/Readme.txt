This is a big update to my first hack I ever released. I had always been a little ashamed by it because it was so much more rough
around the edges compared to stuff I released afterwards. I also wanted to do com_poser justice because he created such a banger
port for the game. So the result is a much more friendly/better designed game with setups and sections nerfed, changed, or removed. Various
graphics have been updated as well.

I hope that now it will better stand the test of time and live up to my massive, throbbing legacy.

-MmmDoggy


