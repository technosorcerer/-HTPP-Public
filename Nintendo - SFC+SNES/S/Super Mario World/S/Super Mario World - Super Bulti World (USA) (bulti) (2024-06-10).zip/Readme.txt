This rom hack got rejected once I have fixed some issues and again trying to moderate it.
This is my first rom hack and It contain some important kaizo tricks with a little bit of difficulty.
Level 1, 2 and 3 are basic jump intro level
Level 4 is a grab and throw level
Level 5 is a water level
Level 6 contains big boo boss and some kaizo play difficulty normal This level contains a vertical scroll pipe which is basically a troll you can enter this by pressing down but can not come up by it's a one way pip
Level 7 contains P - switches and a  kaizo trick which is very easy to perform - taking the P - switch throw a pipe
Level 8 Contain on/off switches and P speed
Level 9 Contains shell jumps which are not that difficulty can be performed with a little bit practice
Level 10 contains Yoshi information
Level 11 Vertical Level not hard it very easy
Level 12 It contain leve platform and layers
Level 13 Is a introduction to power up handling
Level 14 Is a silipary level
Level 15 Is the final level which is a little bit confusing and illusion containing

Level 16 is a credit level.

For more you can visit to my youtube channel - "BultiIsAlive"
Super Bulti World gameplay - https://youtu.be/yYRlicTrvfg?si=99DrH6dkAneU-umt