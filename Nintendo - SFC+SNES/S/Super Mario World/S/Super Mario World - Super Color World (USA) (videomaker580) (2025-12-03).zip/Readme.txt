Thank you for downloading my hack! This has been a massive passion project for me along with an excuse to learn how to do more with Lunar Magic and other Super Mario World hacking tools. I hope you enjoy playing it as much as I enjoyed making it. It is a kaizo hack, so be prepared to die a lot!

Tweaks:
skip player select menu
disable scoreboard
Prevent dropping items when powering up/down
Remove Back Area Color Flashing in Castle Destruction Cutscene
Vertical Scrolling Fix

Peach's Message changed with the following tool: SMW End Text Editor- https://jsfiddle.net/wxqoqrn2

Block Credits:
Carryable Sprite Shell Block - Nowieso
Quicksand Blocks - Roy, Sonikku
On/Off Blocks - MarioE
Thwomp Crush Block - Roy

UberASM:
Credits fix - Thomas
Lightning Generator - Mattrizzle
Retry System (+ Multiple Checkpoints) v2.06c - Kevin, lx5, worldpeace

Music Credits:
Title Screen:
Shin Megami Tensei II - Gym. Composed by Tsukasa Masuko, ported by Ahrion

Boss Clear:
Super Mario World 2: Yoshi's Island - Bowser Clear Ported by LadiesMan217, musicalman

Egg Saved:Cave Story - Get Heart Tank! Ported by Milon Luxy

Castle Destroyed:
Lunar Clock ~ Luna Dial (Stage-Clear-Mix). Ported by 

Global Songs:
The Simpsons - Skinner & the Superintendent Theme. Ported by Bak Sangwoo.
Epic Sax Guy (Arrangement). Original song: Sunstroke Project & Olia Tira - Run Away | Moldova MD (Epic Sax Guy)Ported by Airbourne Bubblun.

Overworld Music:
It's Raining Somewhere Else. Composed by Toby Fox for Undertale. Ported by Teows
Cave Map from The 8th Vanilla Level Design Contest by S.N.N
My Castle Town. Composed by Toby Fox for Deltarune. Ported by MercuryPenny.
Pascal's Theme from Shin Megami Tensei (Super Famicom). Composed by Tsukasa Masuko, ported by Airhorn
DuckTales 2 - Egypt. Composed by Minae Fujii and Akihiro Akamatsu. Ported by MetallicKreeper.
Secret of Mana - Eight Ringing Bells. Composed by Hiroki Kikuta. Ported by Red Chemeleon.
Donkey Kong Country 2: Diddy's Kong Quest - Lost World Anthem. Composed by Dave Wise. Ported by Crispy.

Level Music Credits:
Undertale - Snowdin Town (Noteblock Remix). Composed by Toby Fox: ported by Segment1Zone2.
Kirby Mass Attack - Dark Clouds. Ported by ASS.
Delta Rune- Smart Race. Composed by Toby Fox. Ported by Segment1Zone2
Chrono Trigger - Brink of Time. Ported by Samantha.
Shin Megami Tensei (Super Famicom) - Ruins. Composed by Tsukasa Masuko. Ported by Ahrion
Shin Megami Tensei - Embassy. Composed by Tsukasa Masuko. Ported by Airhorn
EarthBound - Home Sweet Home. Composed by Keiichi Suzuki and Hirokazu Tanaka. Ported by Airhorn
Secret of Mana - Rose and Ghost. Composed by Hiroki Kikuta. Ported by Red Chameleon.
Etrian Odyssey II - Cherry Tree Bridge. Composed by Yuzo Koshiro. Ported by Maxodex.
Shin Megami Tensei V- Daily Life. Composed by Ryota Kozuka. Ported by Samanthy Himemiya.
Pokemon Black & White - Relic Castle. Composed by Shota Kageyama. Arranged by Ultima.
Final Fantasy VII - Listen to the Cries of the Planet. Composed by Nobuo Uematsu, Ported by Ahrion
Super Mario Maker - The House Mario Ignored Is A Dungeon?! ~ SMB Ghost House. Composed by Koji Kondo. Ported by Die Zo De'vee.
Mega Man 4 - Wrong Side of History 📜 ~ Pharaoh Man (Kamishirasawa-Mix). Ported by Minae Fujii, Yasuaki Fujita, arranged by Hooded Edge
Undertale - Satanic Bakery Sale ~ Spider Dance (Remix). Composed by Toby Fox, arranged by Hooded Edge.
Passat of the Hero. Composed by ThinkOneMoreTime.
Live A Live - Under the Fake. Composed by Yoko Shimomura. Ported by S.N.N.
Metal Slug 3 - Pyramid (Mega Man X2 Style). Composed by Playmore Sound Team (HIYA!, Bero-ou, Hori Hori, Q JIROU, maitaro)
SNK Sound Team.Ported by JX444444.
Nightwish - Ever Dream. Ported by MidiGuy.
Breath of Fire II - Cross Counter. Composed by Yuko Takehara. Ported by qantuum.
Over the Forest. Original song by Ruberjig.
The 9th Vanilla Level Design Contest - Sky & Space Map. Composed by Pinci.
Spongebob Squarepants: SuperSponge - Ghost Train. Composed by Matt Simmonds. Ported by MercuryPenny.
What-A-Blast! - Bits and Bytes. Composed by Ruberjig.
New Wave. Composed by Janno27.
Ys IV: Mask of the Sun - The Heat Inside the Fire. Composed by Yoshiaki Kubotera and Masanori Hiki. Ported by Airhon.
SMW Central Production 2 - Merchant Song. Composed by Dippy and Moose.
Pokémon Mystery Dungeon: Explorers of Time/Darkness/Sky - Quicksand Pit. Composed by A.Iiyoshi, H.Sakamoto, K.Ito, R.Nakamura and K.Saito. Ported by Ultima.
The Lion King (SNES) - Be Prepared. Composed by Frank Klepacki and Dwight Okahara. Ported by Airhon
Shin Megami Tensei II - 3D: Valhalla. Composed by Tsukasa Masuko. Ported  by Ahrion
Mega Man X3 - The Catfish-Disguised Tanuki 🍃 ~ Volt Catfish's Stage (Futatsuiwa-Mix). K. Yamashita, ZUN, arr. Hooded Edge
Final Fantasy VII - Mining Town. Composed by Nobuo Uematsu, ported by Ahrion
Running in the Mountains. Composed by EDIT3333.
Frozen Depths. Composed by Nic Nac.
Snowy Mountain Adventure. Composed by TheGremlin
Sky Map, Void Mix. Composed by S.N.N.
Chrono Trigger - Singing Mountain. Composed by Yasunori Mitsuda. Ported by Samanthy Himemiya.
Seventh Sound. Composed by ThinkOneMoreTime.
BAD Ideal. Composed by TheGremlin.
Space Harrier - Main Theme. Composed by Hiroshi 'Hiro' Kawaguchi. Ported by Ultima.
SMW Central Production 2 - Flutes of Despair. Composed by Jimmy and Torchkas.
Tiny Toon Adventures: Buster Busts Loose! - Spook Mansion. Composed by Kazuhiko Uehara, and Yukie Morimoto. Ported by Kevin.
On Top of the Castle. Composed by Pinci.
Dark Souls - Gwyn, Lord of Cinder (Remix). Composed by Motoi Sakuraba. Chrono Trigger cover by SviSvi.
Scurge: Hive - Deadscape. Composed by Jake Kaufman. Ported by Alucardioid.
Breath of Fire II - Lethal Dose. Composed by Yuko Takehara. Ported by Atma.
Undertale - Another Medium. Composed by Toby Fox. Ported by Torchkas.
Donkey Kong Country 3: Dixie's Double Trouble! - Hot Pursuit. Composed by Eveline Fischer. Ported by Masashi27
F-Zero - Port Town (Re-Arrangement). Composed by Yumiko Kanki. Port by Dippy
Metal Slug - Assault Theme. Composed by Takushi Hiyamuta (also credited as Hiya!). Ported by Wakana.
Castlevania: Symphony of the Night - Darkness Within The Walls ~ Dracula's Castle (Remix). Original song composed by Michiru Yamane. Port by The Devil from the Bible.
~omh~ - Springtrap is Mocking You ~ I Always Come Back. Composed by Die Zo De'vee, The Devil from the Bible, Jonah, Team JANK.
Pizza Tower - Wrath of The Fallen ~ Thousand March (Remix). Composed by Ronan de Castel, ClascyJitto, and Post Elvis. Remix by Segment1Zone2.
Rick Astley - Robo Roll ~ Never Gonna Give You Up (Chrono Trigger Remix). Composed by Rick Astley. Cover by ass and tssf.