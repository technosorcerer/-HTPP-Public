---CREDITS---



Musics

New Super Mario Bros. Wii - World 1 Map - MinecraftGamerLR, Segment1Zone2

Mario Kart Wii - Coconut Mall - Dispace

Super Mario 64 - Bob-omb Battlefield - Tornado

Kirby Super Star - Green Greens - undefinied3

Super Mario 64 - Dire Dire Docks - bebn legg

Super Mario 64 - Cool Cool Mountain - Goomba-24

Super Mario 64 - Koopa's Road - Isikoro

Super Mario 64 - Slider - Giftshaven, MarkVD100

Super Mario 64 - Merry-Go-Round - MrCheeze

---------------------------------------------------------


Tools Used

LunarMagic

AddMusick

Floating IPS (flips)