
SMW The Princess Rescue 2:Luigi to the Rescue

	This hack is a sequel to SMW The Princess Rescue released last year on SMWCentral, its a traditional adventure where you come across 9 worlds to help Luigi save his beloved princess Daisy.
The story happens simultaneosly with the other adventure, while Mario is on his own adventure to save Peach, Luigi came to Sarasaland to visit Daisy, but Tatanga returned to take his revenge kidnapped her again.

The gameplays keeps pretty much what was seen on the previous adventure, to 100% this hack you must beat platforming levels, find star coins to win bonus stars and find all the exits hidden over the map.

This demo contains: 
- 5 worlds completed with 51 levels with 63 exits and 51 bonus stars to be found. and ends right after World 5-Castle.
- New Overworld Map 
- New Level Design
- New Custom Music
- Custom Bosses
- DDA System: Dynamic Dificulty Adjustment System based on how many lives you have
- Super Mario World styled Graphics
- HDMA Gradients
- Expanded SRAM which saves lives, coins,powerups and more
- Star Coins System 
- Patches that modifies some game mechanics

Some changes from the last adventure:

- The DDA* blocks now spawns extra lives too
- The star coins now appear all before or after the midway point on their respective levels, this is because it was too frustrating to collect them all at once on the last game, and I still couldn't fix the imcompability with the patches installed with the Individual Dragon coin save patch.
- Each world now have its own OW music instead of one music for the entire main map.
- The dificulty was toned down a bit.
- Multiple midway points on castle levels, with the second midway points being right before the boss door.(to be implemented yet).

About DDA:
The DDA (Dynamic Dificulty Adjustment)if the player is struggling to complete a level,the game will get easier when he have a lower number of lives.
The DDA functions added here is if the player has less than a certain number of lives some blocks will spawn extra powerups or extra lives in the level to help him complete the level, this don't affect anything in the experience for the better players.

_____________________________________________________

Credits:
Level Design:
Bandicoot

Custom Graphics:
Bandicoot
Gamma V
Gregor
Berk
Hayashi Neru
Allowiscous
Imamelia

Custom Music:
Bandicoot
Pink Gold Peach
Gamma V
Wakana
HarvettFox96
MercuryPenny
Jimmy
LemmyKoopa
Lui37
Moose 
Nameless
 RednGreen 
S.N.N.
Sinc-X 
Torchkas
Tornado
Sayuri
Ultima
Chineesmw
LadiesMan217
Decoy Blimp
Unknown User
EDIT3333
Roberto zampari
Zagronia
OGS93
Izuna
Crispy
MaxodeX
Yoshi9429

Custom Sprites:
Erik 
Blind Devil
RussianMan
yoshicookiezeus
Romi 
Sonikku
LX5
Sonikku 
Telinc1
mikeyk
smkdan
MarioFanGamer
imamelia
Mathos
Tsutarja
TheBiob
Alcaro
Mandew
RealLink
Iceguy
dahnamics
yoshicookiezeus
Akaginite
Dispari Scuro
Darolac
Ixtab


ASM & Patches:
Noobish Noobsicle
Maxx
LX5 
MarioE
MarioFanGamer
Luigi-San
Alcaro
Erik
Custom Sprites:
Romi
Erik557
Tsutarja
edit1754
Alcaro
Le Comte Niark
imamelia
Ladida
TheBiob
JackTheSpades
Nesquik Bunny
Glyph Phoenix
DiscoTheBat

Tools:
Kipernal
p4plus2
Romi 
FuSoYa
Vitor Vilela
JackTheSpades
Alcaro
Kipernal