.o(iF THiS LOOKS GARBLED OPEN THE JPG!)

	███████╗██╗   ██╗██████╗ ███████╗██████╗                  
	██╔════╝██║   ██║██╔══██╗██╔════╝██╔══██╗                 
	███████╗██║   ██║██████╔╝█████╗  ██████╔╝                 
	╚════██║██║   ██║██╔═══╝ ██╔══╝  ██╔══██╗                 
	███████║╚██████╔╝██║     ███████╗██║  ██║                 
	╚══════╝ ╚═════╝ ╚═╝     ╚══════╝╚═╝  ╚═╝                 
                                                          
			 ██████╗██╗   ██╗██████╗ ██╗ ██████╗ ██╗   ██╗███████╗    
			██╔════╝██║   ██║██╔══██╗██║██╔═══██╗██║   ██║██╔════╝    
			██║     ██║   ██║██████╔╝██║██║   ██║██║   ██║███████╗    
			██║     ██║   ██║██╔══██╗██║██║   ██║██║   ██║╚════██║    
			╚██████╗╚██████╔╝██║  ██║██║╚██████╔╝╚██████╔╝███████║    
		 	 ╚═════╝ ╚═════╝ ╚═╝  ╚═╝╚═╝ ╚═════╝  ╚═════╝ ╚══════╝    
                                                        
							██╗    ██╗ ██████╗ ██████╗ ██╗     ██████╗
							██║    ██║██╔═══██╗██╔══██╗██║     ██╔══██╗
							██║ █╗ ██║██║   ██║██████╔╝██║     ██║  ██║
							██║███╗██║██║   ██║██╔══██╗██║     ██║  ██║
							╚███╔███╔╝╚██████╔╝██║  ██║███████╗██████╔╝
							 ╚══╝╚══╝  ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═════╝ 
                                                                                  
					  A Super Mario World Romhack for CuriousAndSpurious - (c) 2023
┌──Info─▼─────────────────────────────────────────────────────────────────────────────────────────────┐
│ Super Curious World is a collaborative ROM hack that was made in a little less than a month for our │
│ friend and fellow Kaizo enjoyer, CuriousAndSpurious as a labor of love after his cancer diagnosis.  │
│ James has passed away on the 26th of May 2024. We hope this game serves as a reminder for an        │
│ amazing and radiant human being that is missed by many. Rest easy, Friend.			      │
│												      │
│					We love you, James.					      │
│ 											              │
│ Patchnotes:											      │
│ v 1.2:											      │
│     - Updated some messages to reflect CaS' passing						      │
│     - Fixed a minor visual glitch								      │
│     - Added a portrait back in                                                                      │
│                                                                                                     │
│ v 1.1:                                                                                              │
│     - Fixed a softlock, scroll jank and a broken door                                               │
│     - Added a message box to Starlight Express						      │
│     - Fixed an overworld event                                                                      │
│												      │
├────────────────────────────────────────────────────────────────────────────────────────↑─Team Love──┤
│⌠Tracklist⌡											      │
├─────Level─▼─────────────────Track─▼─────────────────────────────────Porter─▼────────────────────────┤
│	Bisexual Cape		The Strongest Knight in the Galaxy	Milon Luxy		      │
│	Borrowed Time		Last Bible III - Sky Wing		Kevin			      │
│	CASphodel		Overworld (Metal Version)		worldpeace		      │
│				Good Riddance (TO CANCER)		Macrophaje		      │
│	Credits			HiScore Theme				Ahrion			      │
│	Curious CAStle		Equinox - Atlena 	 		Teows			      │
│	Els Cavern		FFVI Esper World 			MercuryPenny		      │
│				FFIV Fight1 #31 samples			Zavok			      │
│	Foggy Fumes		Fear Factory				RednGreen		      │
│	MelancholyHeadspace	Slippery Scary Subterranean 		brickblock369		      │
│	Parasite Paradise	Jurassic Park - Elevator Music 1 	brickblock369		      │
│				M.U.S.H.A - Fullmetal Fighter 		Ultima			      │
│				Exhaust Heat/F1-ROC - Main Theme 	ggamer77		      │
│	Parshelly Hard		Bubblegum K.K. (Aircheck)		Jead			      │
│	Spurious Shroom		Hello, Happy Kingdom			Siamese Twins		      │
│				Ganbare Goemon 4 - Credits		Dippy			      │
│	Starlight Express	Duck Tales - The Moon 			Crispy			      │
│	Wallkicking Wasteland	VLDC 7 - Desert				RednGreen		      │
│	The best I could do	Flower Stage				Kevin			      │
│	Title Screen		Triple Func				VecchiaZim		      │
│	Portraits 		Nintendo Power Menu Program	 	Ahrion			      │
├──────────────────────────────────────────────────────────────────────────────────────────────↑─♪♫♪──┤
│⌠Level Credits⌡										      │
├─────Level─▼────────────────────────────────Creator─▼────────────────────────────────────────────────┤
│	Bisexual Cape				Dino Mom					      │
│	Borrowed Time				synthie_cat					      │
│	CASphodel				TheUCanes					      │
│	Curious CAStle				drkrdnk						      │
│	Curious Caverns				CodeSynth					      │
│	Els Cavern Tavern 			Elsais117					      │
│	Foggy Fumes				DASHGMR						      │
│	Ice Ice Baby				5auceBrune & CodeSynth				      │
│	MelancholyHeadspace			HotLocalGrandpa					      │
│	Parasite Paradise			iamtheratio					      │
│	Parshelly Hard				5uak						      │
│	Spurious Shroom				EvilAdmiralKivi					      │
│	Starlight Express			DocCzekaj & NixKillsMyths 			      │
│	Wallkick Wastelend			TheBourgyman					      │
│	The Best I Could Do			DaddyNevin					      │
│												      │
│	Credits					synthie_cat					      │
│	Overworld				iamtheratio					      │
│	Title					iamtheratio					      │
├──────────────────────────────────────────────────────────────────────────────────────────────↑─☺☻☺──┤
│⌠ASM, Tools, Graphics + Sprites⌡								      │
├─────Creator─▼───────────────────────────────Thing─▼─────────────────────────────────────────────────┤
│     ASM											      │
│	DToTheFourth +				Effect Tool					      │
│	JackTheSpades										      │
│	mathie					Automatic Walking				      │
│	MarioFanGamer				Customisable Shooter				      │
│	RussianMan				Mushroom Disassembly				      │
│    Tool											      │
│       Various					Aseprite					      │
│       FuSoYa					Lunar Magic					      │
│	Vitor Vilela				UberASM						      │
│	YY Creator				YY-CHR						      │
│	Flux Industries Baserom V2		SJandCharlieTheCat				      │
│    Graphics + Sprites										      │
│	Blind Devil										      │
│	DamianG					District Digital Font				      │
│	iamtheratio										      │
│	Rykon-V73										      │
│	SacredSilverYoshi									      │
│	Super Tails										      │
│	synthie_cat										      │
│	thedigitalandrew			Portraits, Heartclock				      │
├──────────────────────────────────────────────────────────────────────────────────────────────↑─▫•▪──┤
│⌠Playtesters⌡											      │
├─────Nerds─▼─────────────────────────────────────────────────────────────────────────────────────────┤
│	blueribbonhighlife									      │
│	eejay											      │
│	germdove										      │
│	KingJayRool										      │
│	WhoIsDoopu										      │
│	xoxoGossipGreg										      │
├──────────────────────────────────────────────────────────────────────────────────────────────↑─♠♣♦──┤
│⌠Community Shoutouts⌡										      │
│⌠Super Curious World would have never existed without those amazing people!⌡			      │
├─────Also Nerds─▼────────────────────────────────────────────────────────────────────────────────────┤
│	AbbyArtFox	a_coffee_powered_neko	Brecht_VW	DeadweightNate	Deafvibes Gaming      │
│	AlyssaSMW	Jason		LordJ44		MrLevity	Parzival_tripp		      │
│	PlainOleTrey	SillyHatMan	St_Mahoney	TheMCLawdogs				      │
└──────────────────────────────────────────────────────────────────────────────────────────────↑─♥♥♥──┘