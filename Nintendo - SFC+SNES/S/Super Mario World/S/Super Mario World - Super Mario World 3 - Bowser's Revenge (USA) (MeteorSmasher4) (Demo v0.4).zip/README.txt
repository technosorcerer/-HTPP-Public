Hey Everybody, it's a me-me-me-Meteorsmasher4, and I'd like to Say Thank you on Giving my Romhack Demo a Look at.

-Things to be on the Lookout for

To 100% Each World, You'd need to get all 5 Dragon Coins, This is however Optional.

Each Level is 100% Doable. World 4 Castle, Maybe hard to some, But don't give up there is a Reward After This.

Each Level will Display a Time Limit, but However, That isn't supposed to be, Still Working on Kinks

If you find the 2 Lunar Moons in this Demo, Great Job!

This Rom was previously Tested before Attempting to be Released, If you find something to be either Glitchy or too Difficult, Please leave Feedback!!

Each Level also Contains 2 Hidden 1-UPS! Some are Obvious, Some are just Put around, Do your Best on Finding them

Life Count on the Level Display is also Glitchy, and currently looking into it.


Please Hold all Feedback til the WHOLE ROM IS COMPLETED, Meaning Clearing Worlds 1-4 and Getting all 42 Exits. Thank you very Much.

So Please, Convert the .BPS File into a .SMC file, and Enjoy the Rom!