 ____   ______           _    _  _______  _____  ______  _    _  _          _____            _   _   _____  ______  _____    ____   _    _   _____
|  _ \ |  ____|    /\   | |  | ||__   __||_   _||  ____|| |  | || |        |  __ \    /\    | \ | | / ____||  ____||  __ \  / __ \ | |  | | / ____|
| |_) || |__      /  \  | |  | |   | |     | |  | |__   | |  | || |        | |  | |  /  \   |  \| || |  __ | |__   | |__) || |  | || |  | || (___
|  _ < |  __|    / /\ \ | |  | |   | |     | |  |  __|  | |  | || |        | |  | | / /\ \  | . ` || | |_ ||  __|  |  _  / | |  | || |  | | \___ \
| |_) || |____  / ____ \| |__| |   | |    _| |_ | |     | |__| || |____    | |__| |/ ____ \ | |\  || |__| || |____ | | \ \ | |__| || |__| | ____) |
|____/ |______|/_/    \_\\____/    |_|   |_____||_|      \____/ |______|   |_____//_/    \_\|_| \_| \_____||______||_|  \_\ \____/  \____/ |_____/

A SMW ROMHACK CREATED BY: IAMTHERATIO
Version: 1.1
© 2022-2024

╔══ HACK DETAILS: ══════════════════════════════════════════════════════════════════════════════════════════════╗
║
║  Mario wakes up one morning to realize that mustaches have mysteriously appeared throughout the kingdom. Where did they come from?!
║
║  Beautiful Dangerous has 20 exits and has been rated expert due to level-length and the shell level. The levels are longer than
║  average, but the setups are not overly complicated. This makes the difficulty based on challenging the players consistency rather
║  than their technical skills. 
║  
║  Out of the 20 exits, only 1 exit alters Mario's physics, the rest of the exits are good old-fashioned platforming. The player will
║  be required to know typical kaizo tricks and mechanics, as well as basic cape, item swimming, and shell tech to be successful.
║
║  Beautiful Dangerous contains 2 custom bosses (thanks to BucketOfSloppyBeans and Spooonsss) and some trolls/kaizo blocks. There are also hidden
║  portrait rooms throughout, one in every level except Yoshi's house, the 2 switch palaces, and the final castle. Can you find them all?
║
╚═══════════════════════════════════════════════════════════════════════════════════════════════════════════════╝
╔══ FEATURES: ══════════════════════════════════════════════════════════════════════════════════════════════╗
║
║  v1.1 Update Includes:
║  - Bonus Stars have been removed
║  - Blue Switch Palace, Art of Flight, & Polar Bear Club all had minor updates to enhance playability.
║  - Heavy Gloom had graphical fixes.
║  - 2 Portrait rooms updated due to streamer re-names.
║  - Credits have been updated. 
║  
║  v1.0:
║  - Retry prompt
║  - Both secret exits are within first half
║  - Custom sprites, blocks, graphics, palettes, and music
║  - Midways are automatically saved
║  - One water section, cape level, and shell level
║  - 20 total exits, 2 of them Switch Palaces
║  - 5 room final castle with midways
║  - 1 optional experience/level that is not an exit
║  - Trolls & Kaizo blocks
║  - 2 custom bosses
║  - Hidden portrait rooms
║  - No HUD
║  - No fast pipes or motor skills
║
╚═══════════════════════════════════════════════════════════════════════════════════════════════════════════╝
╔══ FROM THE CREATOR: ═══════════════════════════════════════════════════════════════════════════════════════════╗
║
║  Beautiful Dangerous is my first romhack and has taken over 1.5 years to complete. Throughout development I have learned the in-and-outs of
║  Lunar Magic, custom graphics, and even ASM. I also gained an unbelievable appreciation for the amount of work that goes into creating one
║  of these romhacks.
║
║  Although this romhack is not perfect, I am quite proud of it. However, I know it may not be for everyone. If you find yourself getting
║  frustrated please take a break or play something else. There are so many amazing romhacks out there. <3
║
╚════════════════════════════════════════════════════════════════════════════════════════════════════════════════╝

╔══ SPECIAL THANKS: ═════════════════════════════════════════════════════════════════════════════════════════════╗
║
║  I'd like to give extra special thanks to the following people for their help along this journey.
║
║  BucketOfSloppyBeans      Macrophaje      MegaScott
║  SJandCharlieTheCat       Spooonsss       TheDigitalAndrew
║
║  v1.1 Playtesters:
║  - Donaldw518
║  - KingJayRool
║  
║  Also, big thanks to the SMW community for all the love, the Romhack Races baserom, and for answering all of my endless questions. I truly
║  appreciate everything. This hack would not have been possible otherwise.
║
╚════════════════════════════════════════════════════════════════════════════════════════════════════════════════╝

╔══ MUSIC: ════════════════════════════════════════════════════════════════════════════════════════════════════╗
║
║  LEVEL:                                       PORT:                                                           CREATOR:
║  Title Screen                                 Celeste - Resurrections                                         Maxodex
║  Intro Screen                                 Knights of the Round - Merlin                                   qantuum
║  Yoshi's House                                Hollow Knight - White Palace                                    Maxodex
║  Adventure Awaits                             Mango Mountain                                                  Dispace
║  Life's A Beach                               Sunshine Type                                                   Macrophaje
║  Monochromatic Attic                          Ghost Factory Ambience                                          brickblock369
║  Monochromatic Attic (Secret Exit)            3x3 Eyes: Juuma Houkan - Factory                                SiameseTwins
║  Green Switch Palace                          The 12th Vanilla Level Design Contest - Mountain Zone           icrawfish
║  Above The Waves                              Puyo Puyo - Brave of Puyo Puyo                                  Ultima
║  In Bloom                                     Super Nazo Puyo 2 - Rulue's House & Menu Screen                 MercuryPenny
║  In Bloom (Secret Exit)                       Undertale - It's Raining Somewhere Else                         Teows
║  In Bloom (Portrait Room)                     Bone Thugs N'  Harmony - Ghetto Cowboy                          Macrophaje
║  Blue Switch Palace                           Bakumatsu Kourinden Oni - Underwater                            Ahrion
║  Cold Nights                                  Mega Man 11 - Tundra Man Stage (Arranged)                       com_poser
║  Art of Flight                                Radix - Mia & I                                                 Ahrion
║  Optional Experience                          Zelda II: The Adventure of Link - Battle                        Segment1Zone2
║  Link's Palace                                Zelda II: The Adventure of Link - Palace                        Segment1Zone2
║  Link's Palace (Boss Room)                    Zelda II: The Adventure of Link - Final Boss                    MegaNerd14
║  Northwest Passage                            Hyper Iria - Tower                                              Ahrion
║  Northwest Passage (Second Half)              Mother 3 - Memory of Life                                       Apple
║  Polar Bear Club                              SMW Central Production 2 - White Winter Night                   Buster Beetle, Pink Gold Peach
║  Fighting Starlight                           Lovers of Aether - Tutorial Session                             Teows
║  Speakeasy                                    Last Bible III - Ancient Warrior                                Kevin
║  How To Start A Fire                          Burning Waters                                                  imamelia
║  Heavy Gloom                                  Shadow of the Dark Spirit ~ Complete Darkness (Remix)           Hooded Edge
║  The Hollow (Intro)                           Pizza Tower - Meatophobia                                       Daizo Dee Von
║  The Hollow (Room 1 & 2)                      SMW Central Production 2 - Check the Temperature                Blind Devil
║  The Hollow (Room 3)                          Slippery Scary Subterranean                                     brickblock369
║  The Hollow (Room 4 & 5)                      Kidou Senshi Gundam F91: Formula Senki 0122 - Act 1 & 7         Ahrion
║  The Hollow (Room 6)                          Secret of Evermore - Boss Theme 2                               ggamer77
║  The Hollow (Boss Battle)                     Metal Max 2 - Wanted Person Battle                              Ahrion
║  Credits                                      The 8th Annual VLDC - MAP - Grass and Hub                       Izuna
║  Regrab Hideaway                              Mitsume ga Tooru - Boss Theme                                   Teows
║
║  Overworld - Main                             Bomberman 2 (DS) - Multiplayer Lobby                            Teows
║  Overworld - Forest                           Kero Blaster - Freeze Draft                                     Fyre150
║  Overworld - Hyrule                           Zelda II: The Adventure of Link - Village                       Segment1Zone2
║  Overworld - Mountains                        Romancing SaGa 3 - Aurora                                       Samantha
║  Overworld - Cave                             The 11th Vanilla Level Design Contest - Cave Map                Ultima
║
╚════════════════════════════════════════════════════════════════════════════════════════════════════════════╝
