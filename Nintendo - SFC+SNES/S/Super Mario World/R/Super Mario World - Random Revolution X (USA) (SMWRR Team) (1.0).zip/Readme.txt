Thank for play the hack.

I hope you enjoyed

This is version V1.0, It is the first but not the last.
More contant will be added in the future.