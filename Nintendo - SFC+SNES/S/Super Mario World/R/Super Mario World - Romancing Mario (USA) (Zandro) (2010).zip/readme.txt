				=================
		                 Romancing Mario
				=================

			      ====================
			       Changelog of fixes
                              ====================

First Version (13/01/2020)
	-Initial release

				 ==============
				 About the hack
				 ==============

Romancing Mario is a Japanese romhack released in 2010 (according to the copyright on the
title screen, though Zandro's archive at http://smw.servegame.com:45726/ says 2012).
It has 66 exits, and is notable for having an overworld which allows you to tackle the
different worlds in any order you want.

				==================
				About this release
				==================

First of all, we were not involved in and take no credit for the development of
the hack itself. We merely did the fixes and translation described below.

This release fixes the compatibility bugs present in the original hack, which made playback
on any emulator more accurate than ZSNES impossible without crashing. This release should
work even on a real SNES console. Please consult the header "Compatibility problems that
were fixed" further down into this document for a detailed list.

Included is a BPS patch for a fixed version of the original Japanese hack, as well as one
that features an unofficial translation of all the game's text into English.

Finally, there are also a couple of ASM patches that you can optionally apply for some extras
that may enhance playability or understandability. Read the next section for more info on how to
use these.

			      =====================
			      About the ASM patches
			      =====================

Once the BPS patch of your choice has been applied, the resulting ROM should be ready
to play on most hardware and software capable of running SNES games without further
modification.

However, there are some more options in the form of ASM patches that you might be interested in.
In this hack's case, we've included patches for the following:

	- Translator notes on the overworld in the English version which explain some of
	  the cultural references made in the game's text.
	- Fix for the lag caused by the slow code of the old blocktool used by this hack.

We have tried making the process of applying these patches as simple as possible, so
even if you've never done anything with ASM before it shouldn't take longer than a
few minutes to find out what they all do and to actually apply the ones you want.

The process uses a program called "Asar" by Alcaro (and others), which is not our work, but a
cut-down copy of which (only including the .exe and license information) is supplied inside
this zip file for the sake of ease of use.
The full program can normally be found at these addresses:
https://www.smwcentral.net/?p=section&a=details&id=14560
https://github.com/RPGHacker/asar

Below is a step-by-step guide to learning what all the ASM patches do, and how to apply them.

1. Prepare the ROM by applying either of the BPS files to a clean, headered USA version ROM of
	Super Mario World, and placing it into the 'asm_patches' folder.

2. Go to the 'asm_patches' folder, and open '@main.asm' in a text editor of your choice (Notepad will work).

(You can skip step 3 and step 4 if you want all of the patches.)

	3. Read the explanations about each patch inside this file to decide which patches you
		want applied to the ROM, and follow the instructions.

	4. Make sure '@main.asm' has been saved with any edits you made.
		(Take care in step 6 if you rename this file.)

5. Run 'asar.exe'.

6. When asked for the patch name, enter "@main" (without quotes) or whatever
	else you have renamed it to.

7. When asked for the ROM name, enter the file name of the ROM that you put in the same folder
	in step 1, with or without file extension.
	(Warning: if you don't include the file extension, make sure the .bps file of the
	 same name is not in the asm_patches folder, or else asar will try applying the ASM
	 patch to that file instead, which will naturally fail.)

And now if nothing has gone wrong (it shouldn't), you will get a list of the patches that have
been applied, and a message saying that the patch has been applied successfully.
The ROM is now ready to be played.

			  ======================================
			  Compatibility problems that were fixed
			  ======================================

	- Custom code that makes incorrect use of SNES multiplication and division registers.

	- Crashes related to the use of an old AddMusic tool made by carol which uploads
	  music data into a section of Audio RAM which gets overwritten by echo data.

	- Similar crashes due to songs setting too high an echo delay setting, which causes
	  echo data to overwrite the sample data.

	- Stuttering audio caused by residual audio data getting continually replayed when
	  echo delay is set to 0, but echo playback is not turned off.

	- Robotic sounds in the music of some levels due to a bug in the vanilla
	  sound engine that causes the wrong instrument data to get loaded whenever a sound
	  effect interrupts a music channel that is playing percussion.

	- Removed unused ExAnim data in some levels responsible for overburdening the NMI
	  routine, causing a black bar to flicker onto the top of the screen every eight frames.

	- A flash that occurs sometimes when level loading starts, due to the background
	  palette data not getting updated quickly enough.

	- Custom sprites glitching out due to incorrect assumptions about the initial state
	  of values in RAM by old SpriteTool.

					=======
					Credits
					=======

This is a list of all the people whose software/patches/work we've used or adapted on this hack:

Asar 					- Alcaro et al
Recover Lunar Magic 			- Parasyte
Extended Overworld Level Names		- Smallhacker
Lunar Magic				- FuSoYa

ASM for translator notes, message box chaining, level load flash fix by Super Maks 64.
Translation, compatibility/bug fixes, and additional ASM by This Eye o' Mine.
Additional research and translation by lion.
Proofreading and testing by SimFan96 and Ryrir.

And of course thanks to 774, who made the hack in the first place.

Our apologies to any people we might've missed.

- The Hack Fix/Translation team