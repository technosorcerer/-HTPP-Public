ASM:
Ladida
Lx5
ExeBoss
Vitor Vilela
Kipernal
Fusoya
MikeyK
Imamelia
Darolac
Alcaro
Wye
MarioE
MarioFanGamer
Kevin
Ice Man
YoshiFanatic
Lui
Isikoro
Francium
Mario90
Blind Devil
Bensalot
The Cursed Goomba
Major Flare
Janklorde

Music:
Wakana
Pinci
Wavee
LemmyKoopa
Sinc-X
Torchkas
Dr Tapeworm
LadiesMan217
6646

Graphics:
Yoshi Master
Bensalot
Valtteri
RussianMan

Tools:
HuFlungDu
FuSoYa
Kipernal
Alcaro
TheBiob
Atari2.0
p4plus2

Testing:
The Cursed Goomba
Donut
