3rd:
- Fixed place where player can get stuck in Crystal Mountain
- Changed beginning screen of Life in Motion
- Fix in 2nd half in On and Off making it impossible to get stuck behind Thwomp
- Secondary entrance fix in Life in Motion; now spits you out of pipe and not 7 tiles above it
- Fixed para beetle palette in 2nd half of Crystal Mountain

2nd Edition: 
- Overworld paths no longer enabled by default 
- Time limit on Blue Switch Palace increased by 100 seconds
- Time limit on Red Switch Palace increased by 100 seconds

1st Edition (finished very end of 2019): Initial release.

As opposed to trying to finish any longer or currently running SMW hack project, I opted to start fresh feeling uninspired with Variety Slumber at the time this one was started. Development of new SMW hacks from my end was slow and only really happened in the first place when there was both inspiration on what levels to build and an interest in romhacking, both of which recently reappeared last month. However, with the same philosophy I had concerning Bits and Pieces, I was determined to release something, regardless of how long it might have taken.

- levelengine

--------------------------------------------------

With the exception of the level design and placement of overworld tiles, and a few foregrounds and backgrounds drawn here and there, most resources used came from the public contributions from other users over on SMW Central, and (mixed) tilesets from various official Mario titles licensed by Nintendo.