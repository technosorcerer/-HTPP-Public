-------------SPANISH/ESPAÑOL------------

Muchas gracias por descargar The adventures end (las aventuras terminan), secuela directa de mi primer hack "Adventures Begin", disfruta del hack.

tu amigo YUTUZ....

-------------ENGLISH/INGLÉS-------------

Thank you very much for downloading The adventures end, direct sequel of my first hack “Adventures Begin”, enjoy the hack.

your friend YUTUZ....

---------AGRADECIMIENTOS ESPECIALES / SPECIAL VERY THANKS------------
Herramientas/tools
-Fusoya
-Romi
-SMWCentral Forum

Graphics/graficos
-Gamma V
-Shikaternia, TheOrangeToad
-Roy
-Hinalyte
-Mr. MS
-Pieguy1372
-Tahixham
-Yutuz
-Falconpunch
-E-man38
-Marioman
-Hayashi Neru
-Link13
-OrangeBronzeDaisy
-Rykon-V73
-DynastyLobster
-Merio
-ECS.98
-Natsuz2
-Black Sabbath
-wiiqwertyuiop

Bloques/blocks
-dacin
-HammerBrother
-Mariofangamer

Sprites
-Daizo Dee Von
-Eminus & Von Fahrenheit
-Darolac
-JamesD28
-HammerBrother
-Davros
-Sonikku
-Roy
-dahnamics
-Romi
-Isikoro
-Tattletale
-Dispari Scuro
-mikeyk
-Blind Devil
-smkdan

Códigos ASM/ASM codes
-Mariofangamer
-KevinM
-GreenHammerBro
-Mattrizzle
-kaizoman666
-Telinc1
-Eduard
-Nowieso
-kevin
-Blind Devil

Musica/music
-LadiesMan217
-Vitor Vilela
-musicalman
-Milon Luxy
-JX444444
-SiameseTwins
-Ultima

Testers
-BrianPlayGamesBad
-Yutuz
-LuffyCLN