Super Mario World MSU-1(+)
Version 1.5

ASM Written by Conn and improved by yoshifanatic and NTI Productions.
Original MSU-1 patch: http://www.romhacking.net/hacks/2320/

This version of the MSU-1 enabling patch is intended to be a general enhancement to the Super Mario World, not only audio.
Using FuSoYa's Lunar Magic and patches from SMWCentral.net, I was able to fix a lot of the oddities found in the SMW engine.

The patch also adds a separate SFX music set for Player 2, so e.g.: Game Over song will play a diferent track when you are Luigi.
Download a SFX and music PCM set here: https://1drv.ms/f/s!AtMUCmAL6x14hVmyYk0PYUmcguvk

=============
= Changelog =
=============

Version 1.5
-Multiple Overworld Songs patches added
-Removed SA-1 support
-Updated manifest format and removed xml mapping

Version 1.1
-Fixed issue which commits some revisions of the SD2SNES flashcart
-Fixed critical issue which prevents the music from getting started

Version 1.0
-Public release

============
= Features =
============

The patch includes:
-Multiple songs on Main Overworld
-Separate GFX for Player 2, Luigi
-Separate SFX sound for him too
-General speed/performance enhancement to the SMW rom
-A lot of bugfixes to the native glitches in the original game

Note: If the SPC fallback is activated during music transition on Main Overworld, the multiple songs feature will be deactivated.

==============
= Setting Up =
==============

If using higan/nSide, make sure to copy the "Super Mario World_msu1.sfc" folder to your Super Famicom folder,
then apply "smw_msu1.bps" to a clean unheadered rom, the patch works for both unheadered and headered though, but higan only plays unheadered roms.
After that, copy a PCM set of files from any source to the same place where your rom is supposed to be.

Emulators:
https://byuu.org/emulation/higan/
https://github.com/hex-usr/nSide/releases

If playing a SD2SNES flashcart, this one doesn't care if the rom has a header or not. Just make sure
the patched rom, the "smw_msu1.msu" file and the PCM music set are in the same place, no other files are required than these ones mentioned.

If using any bsnes v073 based emulator, .XML mapping is no longer supported, bsnes-plus removed this requirement, please use the latest development version:
http://www.emucr.com/search/label/bsnes-plus?&max-results=16

I highly recommend FLIPS (http://www.smwcentral.net/?p=section&a=details&id=10347) for applying the patches.

NOTE: The patched roms must be named "smw_msu1.sfc", no exceptions, unless you edit manually the manifest.bml file.
How your folder should look like:
...Emulation\Super Famicom\Super Mario World_msu1.sfc\
						.......manifest.bml
						.......smw_msu1.msu
						.......smw_msu1.sfc
						.......smw_msu1-1.pcm
						.......smw_msu1-2.pcm
						.......smw_msu1-3.pcm
						.......And so on.....

That's all folks~
 
===========
= Patches =
===========

Here it is a list of the patches used and their respective authors from SMWCentral:

Extreme FastROM Addressing - Ersanio
Quickrom - Alcaro
SMW-Fix	- MrCheeze
Dark Room BG Fix - Roy
Lava Fix - Roy
Hurtfix - BMF54123
Carrying fixes - Romi
Iggy Hair Fix - Mattrizzle
Clear/Init Unused Ram - Maxx
H:None BG Scroll Reset Patch - edit1754
Rollover Fix - Noobish Noobsicle
P-Switch Jumping Fix - Chdata
Darken Pause - ghettoyouth
LC_LZ2 Decompression Optimizer - 33953YoShI, Ersanio, edit1754
Score+9 - Alcaro
69+83 fix - Alcaro
Thwomp Face Flip - Alcaro
Wait Replace - p4plus2
Sumo Brother Flame Fix - Roy, worldpeace
Clear/Initialize Unused RAM - Alcaro
No 1-UPS While On Vines - wiiqwertyuiop
Better Random Number Generator - wiiqwertyuiop
Star Music Fix Patch - Lui37
Magikoopa Palette Correction Patch - andy_k_250
Bob-omb cape fix - Alcaro
NMI Fix - Kipernal
Feather Autoscroll Freeze Fix - Romi
Fixed Color Data NMI Optimizer - Ladida
SMW Wiggler Bug Fix - zkip
Fishin' Lakitu bug fix - Alcaro
Separate Luigi Graphics - DiscoMan, Smallhacker
Balloon Cloud Clipping Fix - lolcats439
Rope Fix 1 - Alcaro
Rope Fix 2 - Alcaro
Item Box Mushroom Priority Fix - Alcaro
Spike Swim Fix - Alcaro
Horizontal Scroll Fix - Alcaro
Vertical Scroll Fix - Alcaro
Walljump/Note Block Glitch Fix - lolcats439
Slope Pass Glitch Fix - lolcats439
Block Duplication Fix - lolcats439, Vitor Vilela
on/off Layer 2 generator fix - GreenHammerBro
Circle HDMA Fix - p4plus2
Ninji Ceiling Fix - Sonikku
Tide Sprite Interaction Fix - Alcaro
Time Up Fix - Alcaro
Double Spinjump Antifail - Alcaro
Piranha Plant Patch Fix - Chdata
Fire-Spitting Jumping Piranha Plant SFX - Ersanio
Invincible sprite death fix - Alcaro
Goal Point Sprite Reward Fix - Ragey
OW Music - smkdan
ZSNES incompatibility notice - Alcaro

==================================
= Luigi SFX Set & OW Music Patch =
==================================

Like I said above, the patch enables alternative SFX tracks for Player 2 and multiple songs on Overworld, you can download an already compiled SFX set for Luigi here > http://1drv.ms/1L4aE0G <

However, if you would like to make your own, take a look at the music index I set up:

  smw_msu1-1.pcm - Athletic
  smw_msu1-2.pcm - Overworld
  smw_msu1-3.pcm - Swimming
  smw_msu1-4.pcm - The Evil King Bowser - Unused in Game
  smw_msu1-5.pcm - Boss Battle
  smw_msu1-6.pcm - Underground
  smw_msu1-7.pcm - Haunted House
  smw_msu1-8.pcm - Fortress
  
=============== Point of Interest ===============

  smw_msu1-9.pcm - Player Down (Mario)
  smw_msu1-10.pcm - Game Over (Mario)
  smw_msu1-11.pcm - Fortress Clear (Mario)
  smw_msu1-12.pcm - Course Clear (Mario)
  smw_msu1-13.pcm - Invincible / Starman (Mario)
  smw_msu1-14.pcm - P-Switch
  smw_msu1-15.pcm - Secret Exit! / Into Keyhole - Unused in Game
  smw_msu1-16.pcm - Secret Exit! / Into Keyhole (Mario)
  smw_msu1-17.pcm - Fade Out! / Zoom In (Mario)
  smw_msu1-18.pcm - Bonus Game
  smw_msu1-19.pcm - World Clear / Welcome!
  smw_msu1-20.pcm - Bonus Game Clear (Mario)
  smw_msu1-21.pcm - Egg is Rescued
  smw_msu1-22.pcm - The Evil King Bowser
  smw_msu1-23.pcm - Bowser Zoom Out
  smw_msu1-24.pcm - Bowser Zoom
  smw_msu1-25.pcm - Bowser's Last Attack
  smw_msu1-26.pcm - Bowser's Last Attack (Faster)
  smw_msu1-27.pcm - Bowser Defeated (Mario)
  smw_msu1-28.pcm - Princess Peach is Rescued (Mario)
  smw_msu1-29.pcm - The Evil King Bowser (Intro)
  smw_msu1-30.pcm - Title Screen
  smw_msu1-31.pcm - Wandering the Plains
  smw_msu1-32.pcm - Yoshi's Island
  smw_msu1-33.pcm - Vanilla Dome
  smw_msu1-34.pcm - Star Road
  smw_msu1-35.pcm - Forest of Illusion
  smw_msu1-36.pcm - Valley of Bowser
  smw_msu1-37.pcm - Bowser's Castle Emerges
  smw_msu1-38.pcm - Special World / Super Mario Bros. Remix
  smw_msu1-39.pcm - Staff Roll
  smw_msu1-40.pcm - The Yoshis are Home
  smw_msu1-41.pcm - Card List (Mario)

=============== Extended Music Index ===============

  smw_msu1-42.pcm - Player Down (Luigi)
  smw_msu1-43.pcm - Game Over (Luigi)
  smw_msu1-44.pcm - Fortress Clear (Luigi)
  smw_msu1-45.pcm - Course Clear (Luigi)
  smw_msu1-46.pcm - Invincible / Starman (Luigi)
  smw_msu1-47.pcm - Butter Bridge (OW Music)
  smw_msu1-48.pcm - Soda Lake (OW Music)
  smw_msu1-49.pcm - Secret Exit! / Into Keyhole (Luigi)
  smw_msu1-50.pcm - Fade Out! / Zoom In (Luigi)
  smw_msu1-51.pcm - Cookie Mountain (OW Music)
  smw_msu1-52.pcm - Chocolate Island (OW Music)
  smw_msu1-53.pcm - Bonus Game Clear (Luigi)
  smw_msu1-54.pcm-59.pcm - Unused
  smw_msu1-60.pcm - Bowser Defeated (Luigi)
  smw_msu1-61.pcm - Princess Peach is Rescue (Luigi)
  smw_msu1-62.pcm-73.pcm - Unused
  smw_msu1-74.pcm - Card List (Luigi)

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

The point of interest are the songs which will gain a plus of 33 to its index when Luigi is in play. You can just use my template to create your own PCM set or you can go to the ASM file
attached to this download and make some changes in case you want to add more:

-Look for the label "LuigiPlay:" in the ASM file.

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
if !LuigiSFX
LuigiPlay:
	PHA
	PHX
	STA !FreeRAM1
	LDY $0DB3|!Base2
	BEQ NoAlt

	LDX !FreeRAM1
	LDA Luigi,x
	BNE NewMSUSet

NoAlt:
	PLX
	PLA
	BRA AddL

NewMSUSet:
	PLX
	PLA
	CLC
  ADC #$21      ; THIS adds 33 in decimal, change it to something else if you desire

AddL:
	RTS

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;	Choose what tracks will play different if Luigi is playing. Values: $00 - Don't change, $01 - Yes, change	;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

Luigi:
	db $00,$00,$00,$00,$00,$00,$00,$00,$00,$01,$01,$01,$01,$01,$00,$00	;\ 00-0F
	db $01,$01,$00,$00,$01,$00,$00,$00,$00,$00,$00,$01,$01,$00,$00,$00	;| 10-1F
	db $00,$00,$00,$00,$00,$00,$00,$00,$00,$01,$00,$00,$00,$00,$00,$00	;| 20-29
	db $00,$00,$00,$00,$00							;/ 30-34
endif
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

Following this routine, you can easily set which songs will receive alternative music when playing with Luigi.

Customizing the Overworld songs is much more easier. You see, the songs played in my BPS patch are not limited only to those spots, basically,
you can set a song to play in any place you want in the main map, with only a few limitations:

-Look for the label "MusicTBL" in the ASM file.

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
MusicTBL:
db $1F,$1F,$1F,$1F,$1F,$1F,$1F,$1F,$1F,$1F,$1F,$1F,$1F,$1F,$1F,$1F
db $1F,$1F,$1F,$1F,$1F,$1F,$1F,$1F,$1F,$2F,$2F,$2F,$33,$33,$33,$33
db $1F,$1F,$1F,$1F,$1F,$1F,$1F,$1F,$1F,$2F,$2F,$33,$33,$33,$33,$33
db $1F,$1F,$1F,$1F,$1F,$1F,$1F,$1F,$2F,$2F,$2F,$33,$33,$33,$33,$33
db $1F,$1F,$1F,$1F,$1F,$1F,$1F,$1F,$1F,$30,$30,$1F,$1F,$33,$33,$33
db $1F,$1F,$1F,$1F,$1F,$1F,$1F,$1F,$1F,$30,$30,$1F,$1F,$33,$33,$33
db $1F,$1F,$1F,$1F,$1F,$1F,$1F,$1F,$1F,$30,$30,$1F,$1F,$33,$33,$33
db $1F,$1F,$1F,$1F,$1F,$1F,$1F,$1F,$30,$30,$34,$34,$34,$34,$34,$34
db $1F,$1F,$1F,$1F,$1F,$1F,$1F,$1F,$30,$30,$34,$34,$34,$34,$34,$34
db $1F,$1F,$1F,$1F,$1F,$1F,$34,$34,$30,$30,$34,$34,$34,$34,$34,$34
db $1F,$1F,$1F,$1F,$1F,$34,$34,$34,$34,$34,$34,$34,$34,$34,$34,$34
db $1F,$1F,$1F,$1F,$1F,$34,$34,$34,$34,$34,$34,$34,$34,$1F,$1F,$1F
db $1F,$1F,$1F,$1F,$1F,$34,$34,$34,$34,$34,$34,$34,$34,$1F,$1F,$1F
db $1F,$1F,$1F,$1F,$1F,$34,$34,$34,$34,$34,$34,$34,$1F,$1F,$1F,$1F
db $1F,$1F,$1F,$1F,$1F,$34,$34,$34,$34,$34,$34,$34,$1F,$1F,$1F,$1F
db $1F,$1F,$1F,$1F,$1F,$1F,$1F,$1F,$34,$34,$34,$34,$1F,$1F,$1F,$1F
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

Each byte of this table correspond to a 32x32 block piece on the Main Overworld map. Open the rom on Lunar Magic for better orientation and make all
the changes you need for your music set!

===========
= Credits =
===========

-All the guys from the =Patches= section,
-Conn for conceiving this brilliant work,
-yoshifanatic for his Hijack and the music bank switch logic,
-p4plus2 for his Wait Replace patch which increases the emulator frame-rate and smkdan for the OW Music patch, both of them ships with the MSU-1 patch,
-qwertymodo for his great Legend Of Zelda MSU-1 disassembly (and lol, this is another MSU-1 patch by Conn!!!!),
-FuSoYa for allowing the SMWCentral community to grow up this far and...
-byuu for everything!

(and a big special thanks to Alcaro, since his name covers almost all the =Patches= section xp)
