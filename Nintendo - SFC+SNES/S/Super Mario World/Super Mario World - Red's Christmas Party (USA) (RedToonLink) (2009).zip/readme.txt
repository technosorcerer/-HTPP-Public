==============================
Red's Christmas Party! - Fixed
==============================

==============
About the hack
==============

Red's Christmas Party! is a hack released on Christmas of 2009 by RedToonLink. It features one Christmas themed level centred around Zelda-style gameplay of finding items in order to unlock paths.

This hack was originally released in English.

You can find the original hack and author's comments at:
https://www.smwcentral.net/?p=section&a=details&id=10011
Please check it out in order to find more detailed information about the hack.

This hack had custom music inserted with Romi's AddMusic. This caused a variety of issues on accurate emulators, not the least of which is the game crashing due to the sound engine locking up after echo effects, since these would wipe out misc music stored in the echo buffer. Not before the first map breaks your ears with a jackhammer noise though. A full list of issues fixed can be found later in this document.

==============
About our work
==============

We (by which I mean mainly Ryrir, Super Maks 64, and myself, This Eye o' Mine) basically take old SMW hacks that have issues relating to emulator compatibility, and fix them so these hacks will work properly on newer emulators and, hopefully, real hardware. Although this is unrelated to this particular hack, I'm also involved in translating Japanese hacks to English.

In our fixes of old hacks, we try as much as possible to preserve the way the original hack worked internally. For instance, hacks that used a custom music loading engine have not had this engine replaced, but simply had their assets edited so that they're no longer loaded in such a way that crashes the SNES, and had the N-SPC music engine that SMW uses patched to eliminate a couple of other sound bugs arising from the assumptions about hardware behavior based on ZSNES' inaccurate emulation. The result is that the hack will pretty much work and sound exactly as it would on ZSNES when played on something like BSNES or a real console (minus that emulator's terrible sound quality), and in some areas the music might incidentally even be a bit less glitchy than it used to be.

The above should be true as far as we can tell from testing (which was done on BSNES), and unless otherwise specified in the readme.

==================
About this release
==================

This is usually the part of the readme where I talk about optional ASM patches, but this hack did not have any elements that I felt warranted patching. The ZIP file contains this readme and the BPS patch. Just apply the BPS patch to a clean and headered USA SMW ROM and play!

Here's a list of what was fixed:
- Issues related to the use of Romi's AddMusic, mostly involving music data loaded into the echo buffer getting overwritten.
- Stuttering jackhammer-like noise due to leftover echo data getting continually played back when the game isn't generating any new echo data.
...and that's pretty much it for this one.

We don't mind if you want to redistribute this patch. I mean, who are we to talk?

=======
Credits
=======

Very little was done to the hack besides fixing compatibility issues, so not many people to credit here this time.

Of course, major thanks to RedToonLink, who made this hack in the first place.
I had nothing to do with this hack's creation; I only fixed it in the hope that more people will end up playing it.

Thanks to Super Maks 64 for pioneering the method of fixing broken AddMusic and helping me learn how this works.
Besides that, thanks to both him and Ryrir for their continued assistance in making this whole fixing stuff possible.

Finally, thanks to Pholtos for LPing this hack (or planning to at the time of this writing, anyway). That was the main reason I decided to fix it in the first place.

- This Eye o' Mine
