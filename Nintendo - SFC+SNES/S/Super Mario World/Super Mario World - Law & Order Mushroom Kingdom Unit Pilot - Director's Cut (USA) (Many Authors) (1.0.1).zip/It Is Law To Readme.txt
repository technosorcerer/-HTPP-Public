####################################################

            L A W   A N D   O R D E R
    M u s h r o o m   K i n g d o m   U n i t

            P I L O T   E P I S O D E
     " T r a g i c   F o x   ' T a i l s ' "

        Mushroom Kingdom: Beyond The Worlds
             The Jinker Show Era #1

             ------------------------

     From the makers of 100 Rooms of Enemies,
     Super Mario World: The After Years,
     and Super Mario ˢᵗᵒˡᵉ ᵗʰᵉ ˢᵒᵘˡˢ ᵒᶠ ᵗʰᵉ
     ᴵⁿⁿᵒᶜᵉⁿᵗ ᵃⁿᵈ ᴺᵒʷ ᴹᵘˢᵗ ᶜˡᶦᵐᵇ ᵃ ᵀᵒʷᵉʳ ᵗᵒ
     ᴿᵉᶜˡᵃᶦᵐ ʰᶦˢ ᴴᵘᵐᵃⁿᶦᵗʸ World
     ChaseNScooter, Daizo Dee Von,
     Evilguy0613, Jamie

                 VERSION:  1.0.1

####################################################

Thank you for those who downloaded this rom hack.
Those who don't know how to patch BPS files should
first download FLIPS from SMW Central's Tool
Section, then apply this to a clean Super Mario
World rom (if you're lucky to have one). To test
if it's applied successfully, you should see if the
"Major Case Squad" logo is present. If you see that,
you will be playing LAW & ORDER: MUSHROOM KINGDOM
UNIT - PILOT EPISODE. If you just see the
Nintendo logo, you're just playing the original
game. You don't need to play the original game, but
we would highly recommend playing it on an online
service or seeking an original cartridge.

In 2014, ChaseNScooter and EvilGuy0613 to make a
crossover between the "Super Mario World" and "Law & Order:
Special Victims Unit" Universes because Chase was really
into the show at that time, and has the love of Mario
games for over 20 years. Eventually, Daizo Dee Von joined
the project in pursuit of the Major Case Squad.

"These...are their stories."
 - Steven Zirnkilton

After multiple delays, we decided to put the project
in hiatus to focus on other personal projects, as well
as not having the right tools or skills to make this a
reality.

UNTIL RECENTLY!

On November 18th 2018, we finished creating a proposal
game for ChaseNScooter's wife, "WittyKendra," using the
Law & Order: MKU universe as a basis for practice. It took
us 3 years, but we managed to pull it off.

You can watch "The Proposal" (Project "K") here:
	This is where ChaseNScooter "fake ended" his stream.
	https://www.twitch.tv/videos/364531797?t=00h42m51s

	This is where the game actually starts.
	https://www.twitch.tv/videos/364531797?t=00h51m21s

Despite this progress, we took another break from the main
"Episode 01" for the same reasons as before.

But that would change in SMW Central's 2023 "Questionable
Level Design Contest." Daizo Dee Von proposed a "Pilot
Episode" to test the idea to a wider audience, and we all
agreed it was FINALLY time.

How did it do?

Well, technically, we didn't get top 10.

We got something BETTER.

Not only did we get the "The Emmy Goes To" QLDC Honorable
Mention badge on our profiles (ChaseNScooter, EvilGuy0613,
and Daizo Dee Von,) but we decided to invent a little "joke"
character since we figured it would add to the "questionable"
nature of the entry. Her name was "Sloot Byteakuk Yoshi," a
James Bond inspired female character with the personality of
Rogue from the 1992 X-Men: The Animated Series.

ChaseNScooter based the design off of an old Newgrounds video
revolving around Yoshi's Island. She was basically a pink
Yoshi with a red bow, unlike the final design where her bow is
purple and she's got the looks.

All our minds were blown when this character made head-way
into many streams, including the ever-so-popular VinnyVinesauce.
It was clear to us that Sloot Yoshi, as well as Wilson Robotnik,
were very good characters to include in the game.

So much so that we decided to make a Director's Cut of the
Pilot Episode, and that's what we have here...

LAW & ORDER: MUSHROOM KINGDOM UNIT
PILOT EPISODE - TRAGIC FOX "TAILS"
DIRECTOR'S CUT.

(juzcook would be proud)

Now with the entire history out of the way, what type of game
is this ROM Hack?

Basically it's a stripped down Krack The Hack. Lol.

But actually, this is a story-heavy game featuring mashups
of the Mario Characters mixed with the names of the Law &
Order: Special Victims Unit Cast between Seasons 6-12.

Your job is to investigate a recent event involving the
special guest characters Maurice "Sonic" Hedgehog and
Sebastian "Tails" Prower. You will play as Detective Elliot
Mario alongside Detective Olivia Peach to solve the case.
You'll work with other characters that are in the Mushroom
Kingdom Unit Precinct, and hopefully have help from the
people...of the Mushroom Kingdom's very own "Cointreau City."

(And yes we mixed in Sonic too. Shaddup. :p )

The gameplay revolves around finding clues to get one step
closer to solving the case, which means you might want to
go back to some of the places you've been to before. You will
meet some of the previous character we've mentioned before,
alongside some brand new faces EXCLUSIVE to this Director's
Cut of the game.

For all the people who played the QLDC version, we would love
for you to play this edition, as we've done a massive amount
of polishing. There may even be new places to explore around
the city. And yes, even more story. OUR FAVORITE!

daizo edit: favourite, actually.
chaser edit: i'm american, it's favorite
evilguy edit: you two need some milk

Anyway!

But that's enough rambling from us. Good luck, detectives.
You'll be able to do it in around a hour to see all the content!

(Or 5 minutes if you skip all the cutscenes. You're welcome, Juz.)

...

...

...

Though, if you got a keen eye...you may find some secrets. :)


####################################################

v1.0.1. - The Director's Cut
 - You know what, AS a Detective...you may figure
it out for yourself. This is your first "meta" case.
 - Removed Herobrine

v1.0.0 - QLDC Release
 - The first ever release.
(Download it here: https://smwc.me/1613567 )

v0.0.0 - Super Mario World
 - Super Mario World: the purest "vanilla" experience.

v-100000000.0.0.
 - The Big Bang Theory.