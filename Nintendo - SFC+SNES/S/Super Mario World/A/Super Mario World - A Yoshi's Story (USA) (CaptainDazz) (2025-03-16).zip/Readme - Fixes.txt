Hack title: A Yoshi's Story (A Yoshi's Tale in the title screen)
Author: CaptainDazz
Release date: 2010-05-02
Exits: 1
Fixed by: Mr. MS

This is a fixed version of the latest release of "A Yoshi's Story", made by CaptainDazz, that fixes broken music in accurate emulators.

Fixes provided:

- Fixed broken music that would crash the game in accurate emulators.


Notes:

- Songs were reinserted with AddmusicK.