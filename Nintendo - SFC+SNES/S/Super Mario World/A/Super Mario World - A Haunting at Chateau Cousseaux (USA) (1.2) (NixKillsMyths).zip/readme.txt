A few hacks you should consider playing before attempting this hack:
Brave New World by derv82
Brave New World 2 by derv82
Takumi V by abc_ore
Tatsujin Mario part 1 by abc_ore
Tatsujin Mario part 2 by abc_ore

Useful practice resources:
Midair Risers by tjb0607 (Filebin Link: https://www.smwcentral.net/?p=files&u=39906)
insane3 by ??? (Filebin Link: https://www.smwcentral.net/?p=files&u=21381)
10yumps by Fyre150 (Filebin Link: https://www.smwcentral.net/?p=files&u=42439)

Misc information resources:
SMW Glitch List (Link: https://github.com/Ankouno/SMW-Data/blob/master/Glitch%20List.md)
TASVideos SMW (Link: https://tasvideos.org/GameResources/SNES/SuperMarioWorld)
nathanisbored YT (Link: https://www.youtube.com/user/nathanisbored)

1.2 Secret Hint:
Scroll down if you want it -


















































































The orange path starts where nothing is new.