-A Very Special Mario World-
Version 0.2 Demo
Made by PyroKatrix and with help from various members of the SMWCentral community!

The princess seems to be missing again! However, she has left one clue...she says that she's somewhere special, and although you don't know what she could mean, you go on a journey to find her. Where could this "special" place be? That's on you to find out!

With every good game comes its bugs, and there are some I fixed, and few I h=may have missed.

-fixed fireball issue in Green Scenery where the game freezes when it enters the loading zone
-fixed crash that happens when you move right on 6,11:69
-fixed various "MARIO START" crashes

I hope you have as much fun playing my hack as I did working on it all these months.

From somewhere, with love,
	Pyrokastrix and Co.
________________________________________________________________________________

(I want to make Star Road as painful as possible for people that like skipping worlds. A sort of "you're not supposed to be here" type of thing.)
________________________________________________________________________________