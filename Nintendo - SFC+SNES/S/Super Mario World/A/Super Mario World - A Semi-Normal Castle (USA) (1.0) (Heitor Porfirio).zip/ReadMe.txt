Date: 2024/02/06

------------------------
= A Semi-Normal ReadMe =
------------------------

Hi there, thanks for downloading my hack! In it, I was thinking about several other games and fan games to inspire me, and I worked hard to make this hack really fun to play.
From the beginning, I wanted to do a single-level hack in the style of the SLDC 2015 entries and of other existing one-level hacks, as I found them very interesting and each of them had different concept. Obviously, this hack has some improvements over them, and with many more features and is more current.

Anyway, here are many features that this hack has:

- An improved powerdown system. Every time you take hit with a Fire Flower for example, you won't instantly become small.

- You can shoot fireballs upwards too. To do this, simply press UP + Y/X buttons.

- The Yoshi Coins are saved with each Midway Point collected. You no longer needs to collect all 5 Yoshi Coins at once for them to be saved, or play the level again and haven't collected them all.

Can you collect all 5 Yoshi Coins inside the castle, each one having a different challenge? You can do this challenge if you want.

I think ReadMe ends here. Thanks for reading and enjoy the hack!