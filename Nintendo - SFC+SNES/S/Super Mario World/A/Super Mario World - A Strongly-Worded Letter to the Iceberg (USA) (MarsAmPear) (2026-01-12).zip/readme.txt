One Day, Everyone Will Have Always Been Against This
Omar El Akkad

I know this is just a zip file for a Mario game, but if you like to read and can handle something heavy, I implore you to pick this book up. There's a good audiobook too, read by the author. If you don't know much about the issue of Palestine or why it's supposed to be so important/consequential, I implore you to take this opportunity to investigate further. -Mars