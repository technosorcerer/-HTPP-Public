                           *-------------------------------------------------*
                           |                                                 |
                           |   SUPER MARIO WORLD: ADVENTURE IN FOREST LAND   |
                           |                                                 |
                           *-------------------------------------------------*
                           Version 1.0                  Released on 22/08/2025

=====
ABOUT
=====
This is a new hack I felt like working on, after releasing SMW: The 4 Magic Wands during the 2025 Winter C3.
This hack is a reboot of my second SMW hack that I started working in January 2016, called SMW: Forest Travelling, also known as SMW: Climb the Tree during early development of that hack.
The story has been changed (instead of kidnapping Peach, Bowser has kidnapped Mario, and he must defeat Bowser to escape from Forest Land).
In March, after finishing the last world, I ended up not working on this hack at all until August, because the Summer C3 was coming up.

=============================
TOOL TEST ON WINLATOR RESULTS
=============================
If you want to try making a SMW hack through Winlator or another similar app, please read this to see which tools work and which don't. Only the ones used to make this hack will be here.

* Lunar Magic
  -Works fine, however tooltips (except for custom sprites, custom blocks and Map16 tiles on pages 80+) will not show any text. This will actually happen for all programs run on Wine.
* AddmusicK
  -Works fine (only command line version has been tested)
* Asar
  -Works fine.
* GPS
  -Works fine.
* PIXI
  -Works fine. There will be some squares in the text, but it's purely visual.
* UberASMTool
  -Works fine, however trying to add around 10 codes will make it crash mid-insertion with fatal error 0x80131506. There's no way to fix this if it happens.
* YY-CHR (C++ version)
  -Doesn't work, an error appears upon starting the program.
* YY-CHR (.NET version)
  -Works fine, however it tends to throw an unhandled exception error when hovering on buttons. You can still continue using it if clicking on Continue on the error.
* Effect Tool
  -Doesn't work, as the program will not open at all. I asked KaidenThelens to make the parallax scrolling effect code in the title screen and in the level Gamma Forest 4 for me.
* GradientTool
  -Same as YY-CHR.NET. If you're fast enough, you can turn on "Generate Initialization Code" without the error popping up. Formatting (line breaks and some spaces) will be lost when copy-pasting the code to Notepad, however, so you'll have to fix the file manually.
* SMW Status Bar Editor
  -Works fine.
* SMW Misc. Text Editor
  -Works fine.
* Mario Start Editor
  -Works fine.

=======
HISTORY
=======
(All dates are in DD/MM/YYYY format)

* 10/02/2025: Work on the hack starts. The title screen is made, and work on the overworld maps starts.
* 11/02/2025: All overworld maps have been finished.
* 12/02/2025: Work on world 1 (Vanilla Forest) starts.
* 20/02/2025: Work on world 1 (Vanilla Forest) is resumed, after a break of about 8 days.
* 22/02/2025: World 1 (Vanilla Forest) is finished.
* 23/02/2025: Work on world 2 (Gamma Forest) starts.
* 24/02/2025: World 2 (Gamma Forest) is now finished.
* 25/02/2025: Work on world 3 (Cherry Forest) starts.
* 26/02/2025: World 3 (Cherry Forest) is finished.
* 27/02/2025: Work on world 4 (Bamboo Forest) started.
* 28/02/2025: World 4 (Bamboo Forest) is finished.
* 01/03/2025: Work on world 5 (Autumn Forest) starts.
* 06/03/2025: World 5 (Autumn Forest) is finished.
* 14/08/2025: N450 starts testing the beta version of the hack.
* 15/08/2025: N450 finishes testing the beta version of the hack.
              KaidenThelens starts testing the beta version of the hack.
* 16/08/2025: KaidenThelens finishes testing the beta version of the hack.
              Zavok tests the beta version of the hack.
* 18/08/2025: Work on the Brazilian Portuguese version starts and finishes on the same day.
* 22/08/2025: The hack gets released on SMW Central, during the 2025 Summer C3 event.

==========
CHANGE LOG
==========
v1.0 (22/08/2025)
* Initial release.

=======
CREDITS
=======
Graphics:
---------
* AmperSam
  -Super Mario World - Midway & Castle Conveyor Stairs Fix
* Anorakun
  -Super Mario World - Castle Windows (Layer 2 (background) Conversion)
* blackace
  -Peach's Castle
* Danooodle
  -Super Mario World Styled Switch Palace Expansion
* Gamma V
  -Trees in Gamma Forest, from her overworld graphics
  -Bamboo Forest
  -Cherry Blossom Forest
  -Choconilla Forest
  -Super Mario Bros.: The Early Years - Forest
* Green Jerry
  -Trees in overworld border, bamboos in Bamboo Forest, vine end tiles
* KiloMinimo
  -Super Mario World Styled Autumn
* LinkstormZ
  -Super Mario World Styled Autumn
  -Super Mario World Styled Peach's Castle
* Moltz
  -Castle
* NBTD
  -Trees in Bamboo Forest
* sunwarrior25
  -Bamboo Forest
* zAce08xZ
  -Super Mario World Styled Peach's Castle

Music:
------
* Aguiar Salsicha
  -John Charles Fiddy - Walking The Dog
* bebn legg
  -Mario Eisouoku ~ Illusionary Blossom of Cranium Prayer - A Paradise of Leaves Above
  -Mario Eisouoku ~ Illusionary Blossom of Cranium Prayer - Stargazer 20XX
  -Super Mario World - Here We Go (Touhou-Style Remix)
* brickblock369
  -Kururin Paradise - Strawberry Land
* Buster Beetle
  -SMW Central Production 2 - All the Leaves...
* DAA234
  -Hudson's Adventure Island - Underground
* Dark Mario Bros
  -Super Mario 3D World - Double Cherry Pass
* Dispace
  -Blossom Lilypad
  -Lost Times (Jazz Special)
* EDIT3333
  -Super Mario Bros. Wonder - Game Over
* Eli Moskowitz
  -Speedy Gonzales: Los Gatos Bandidos - El Gato Battle 2
* FPI
  -Super Mario Land 2: 6 Golden Coins - Treetop
* Fullcannon
  -Ninji's Forest
* Gamma V
  -Ardy Lightfoot - Lumberjack Forest
  -Kirby's Adventure - Forest/Dark Rooms
  -Super Mario Land 2: 6 Golden Coins - Tree Zone Map
* Green Jerry
  -Pokémon Gold/Silver/Crystal - Ruins of Alph / Union Cave
* HarvettFox96
  -Super Mario Land - Underground
  -Super Mario World (Pirate) - Ending Theme
* Ice Man
  -Hana no Keiji: Kumo no Kanata ni - Dangerous Forests
* its_4life
  -Dr. Robotnik's Mean Bean Machine - Stages 1-4
* Jimmy
  -Super Mario 64 - Inside the Castle Walls
* Kevin
  -Donkey Kong Country - Bonus Win
* Kitikuchan
  -Ganbare Goemon 2 (NES) - Chugoku, Hokkaido
* LadiesMan217
  -Super Mario All-Stars: Super Mario Bros. 3 - Bowser
* Lui
  -The 8th Vanilla Level Design Contest - Forest Map
* Marcozzo Daro
  -Donkey Kong Country - Forest Frenzy
* MercuryPenny
  -Super Mario 64 - Correct Solution
* Moose
  -A Plumber for All Seasons - Autumn Color
  -Pastel Wind
  -SMW Central Production 2 - I'm-a The Superstar!
  -SMW Central Production 2 - Mario Time!
* Nanako
  -Kirby's Block Ball - Stage 4
* NastCF
  -Knuckles' Chaotix - Door into Summer
* Pinci
  -Kero Blaster - Approach to Hondo
* RednGreen
  -Final Castle
* S.N.N.
  -Super Mario Land - Chai Kingdom
* slogra
  -Magical Tree - Main Theme (Remix)
* Supertails
  -Mystical Ninja Starring Goemon - Yamato Bamboo Forest
* Teows
  -Discord Ringtone
* Torchkas
  -SMW Central Production 2 - All the Leaves...
* Wakana
  -Castlevania III: Dracula's Curse - Mad Forest
* Wyatt
  -Super Mario Galaxy 2 - Yoshi Star Galaxy
* Xulon
  -Chrono Trigger - Underground Sewer
  -Donkey Kong Country - Lost Life
* xyz600sp
  -New Super Mario Classic - Autumn Submap
  -New Super Mario Classic - Nature Overworld
* yoshi9429
  -Neutopia II - Sphere 1
* Zavok
  -Pokémon Gold/Silver/Crystal - Route 42

Patches:
--------
* adakkusu-san
  -Course Clear Modifier (Only in Portuguese version)
* Alcaro
  -Item Box Mushroom Priority Fix
  -ZSNES Incompatibility Notice
  -->It has been edited to be a warning screen that shows up on all emulators (not just on ZSNES), as well as real hardware, along with using Start instead of R to continue into the game.
* anonimzwx
  -Fix HDMA Flickering
* Arinsu
  -No Title Screen Movement
* Arujus
  -No More Sprite Tile Limits
* Chdata
  -Piranha Plant Patch Fix
* DiscoTheBat
  -No Title Screen Movement
* edit1754
  -No More Sprite Tile Limits
* HammerBrother
  -Death Animation Cancel Fix
  -Yoshi Keyhole Fix
* Kevin
  -Castle Intro Ledge Fix
  -Different Submap Switching Transition
* lolcats439
  -Block Duplication Fix
* MarioE
  -Wall Kick
* MarioFanGamer
  -Better Powerdown
* MathOnNapkins
  -No More Sprite Tile Limits
* NoelYoshi
  -No More Sprite Tile Limits
* Roy
  -Nintendo Presents Custom Palette
* RussianMan
  -1-Up Score Sprite on 100 Coins
  -Horizontal Pipe Exiting Sound Fix
* Sonikku
  -Better Bonus Game
* spooonsss
  -Block Duplication Fix
* Tattletale
  -Block Duplication Fix
  -No More Sprite Tile Limits
* TheBiob
  -Victory Pose Fix
* Vitor Vilela
  -No More Sprite Tile Limits

Blocks:
-------
* 1524
  -Sign Block
* Alcaro
  -Teleport Block
* JackTheSpades
  -Disappear after Jump
* MarioE
  -Teleport Block
* ShadowMistressYuko
  -Yoshi Coin Block

Sprites:
--------
* Akaginite
  -Classic Firebar
* andy_k_250
  -Paraspiny
* Arinsu
  -Foliage the Para-Plant
* carol
  -Whispy Woods
* dahnamics
  -Giant Piranha Boss
  -Sleepy Bomb
* imamelia
  -SMB3 Nipper
* Isikoro
  -Thwomp Pack + thwompsprfix.asm
* Koopster
  -Fat Piranha Plant
* MarioFanGamer
  -Cluster Falling Leaves Effect
* mikeyk
  -Bomb Koopa
* Roberto zampari
  -Ptooie Boss
* Romi
  -Hoopster
  -SMB3 Ptooie
* Schwa
  -SMB2 Walking Ninji
* smkdan
  -Gau
  -Honen
  -Pionpi
  -Pipe-Dwelling Bullet Bill Blaster
  -Pompon Flower
  -Suu
  -YI Wild Ptooie (non-dynamic)
* Sonikku
  -SMB3 Bowser
* Tattletale
  -Thwomp Pack + thwompsprfix.asm
* Thomas
  -Sleepy Goomba

UberASM:
--------
* Alcaro
  -Autosave + Bring Up Save Prompt by pressing Select
* Arinsu
  -Autosave + Bring Up Save Prompt by pressing Select
* Eduard
  -Invisible Mario
* janklorde
  -Disable Controller Buttons
* Kevin
  -Disable HDMA During Transitions
  -Retry System
  -->Only the multiple checkpoints feature is used, along with changing settings to work like the vanilla game, and saving lives and Yoshi Coins.
* MarioFanGamer
  -Overworld Exit Counter
* westslasher2
  -Autosave + Bring Up Save Prompt by pressing Select

Tools:
------
* Alcaro
  -Asar
* Atari2.0
  -PIXI
* dtothefourth
  -Effect Tool
* ExoticMatter
  -GradientTool
* Fernap 
  -UberASM Tool
* FuSoYa
  -Lunar Magic
* JackTheSpades
  -Effect Tool
  -PIXI
* p4plus2
  -Gopher Popcorn Stew
* Smallhacker
  -SMW Misc. Text Editor (Only in Portuguese version)
  -SMW Status Bar Editor
* Tattletale
  -PIXI
* TheBiob
  -Gopher Popcorn Stew
  -Mario Start Editor (Only in Portuguese version)
* Vitor Vilela
  -UberASM Tool
* YY
  -YY-CHR.NET

Beta Testing:
-------------
* KaidenThelens
* N450
* Zavok

Special Thanks:
---------------
* brunodev85
  -For creating Winlator, the app that was used to run the SMW hacking tools on my Android phone.
* Cape
  -For inserting the remaining UberASM codes to the hack for me, as Winlator has a problem with UberASM Tool where it crashes with error code 0x80131506 if there are a few different codes in list.txt.
* SMW Central
  -For the resources used to make this hack.
* And you!
  -For playing this hack!