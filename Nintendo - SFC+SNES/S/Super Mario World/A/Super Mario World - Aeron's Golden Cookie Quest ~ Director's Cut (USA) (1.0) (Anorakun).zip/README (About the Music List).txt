
->>>> With the exception of:
 - The Legend of the Mystical Ninja - Sexy Strip Show;
 - Gargoyle's Quest 2 - Assaulted Etruria;
 - Ganbare Goemon 2: Kiteretsu Shougun Magginesu - Xexex Clear;
 - Jikkyou Oshaberi Parodius - Omae wa mou Shindeiru;
 - Goemon's Great Adventure - Ryugu Castle; (see the folder Permission Proof to use a certain port)

All the other tracks can be found at SMWCentral.net. Thanks!