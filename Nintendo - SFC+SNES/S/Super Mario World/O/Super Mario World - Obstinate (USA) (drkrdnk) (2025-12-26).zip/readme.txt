--------------------------------------------------------------------------------
  Obstinate by drkrdnk
--------------------------------------------------------------------------------

Mario finds himself in a strange new world, where he must run, jump and spin on
stuff in a quest to touch goaltapes. He quickly discovers that this is a kaizo
romhack so it's kinda tough sometimes.

Enjoy 14 exits of vanilla kaizo platforming with occasional custom sprites
to keep things interesting. Section lengths are 30-40 in-game seconds, and there are
checkpoints on every new screen.

Good luck

--------------------------------------------------------------------------------
  Verified Working Setups
--------------------------------------------------------------------------------

Mesen2 emulator
MiSTer FPGA SNES core

--------------------------------------------------------------------------------
  Music Credits
--------------------------------------------------------------------------------

Title
	Vortex - Training
	composed by Justin Scharvona
	ported by Ahrion
	
Overworld
	myrskytorni
	composed by Buzzer
	ported by Ahrion
	
Moles
	Walls That Are Still Called Home
	original by icrawfish
	remixed by bebn legg
	
Pipes
	I don't Know so I don't care
	composed by ko0x
	ported by Ahrion
	
Rex/Banzai
	Bomberman 64 - Altaile II
	composed by Akifumi Tada
	ported by Ahrion

Ted
	Ape Escape - Rafting Area
	composed by Soichi Terada
	ported by Fyre150
	
Fuzzy Bounce
	Skipp & Friends - Duckiest
	composed by Steven Velema
	ported by Dippy

Balls
	Shoulder Of The Meow
	composed by Nikku4211
	
Castle 1
	Lufia II: Rise of the Sinistrals - Battle 1
	composed by Yasunori Shiono
	ported by Ahrion
	
Pokey
	Kidou Senshi Gundam F91: Formula Senki 0122 - Staff Roll
	composed by Norihiko Togashi
	ported by Ahrion
	
Ultra Star
	Shadow World
	composed by Pink
	ported by Ahrion

Rhino Hop
	Knightmare - Tavern Funk
	composed by Hoffman
	ported by Ahrion
	
Goomber Wiggler
	Pizza Tower - Wudpecker
	composed by ClascyJitto
	ported by Forgado
	
Thwimp Thing
	Bomberman 64 - The Second Attack - Prison Planet Thantos
	composed by Tomohiko Kira, Yasunori Mitsuda, Hidenobu Otsuki, Tomori Kudo, Hiroyo Yamanaka, Yoshitaka Hirota, Kenji Hiramatsu
	ported by Ahrion
	
Chainsaw Cave
	Sonic Mania - Built to Rule (TMZ Act 1)
	composed by Tee Lopes
	ported by HaruMKT
	
Castle 2
	Techno62Party
	composed by Mygg
	ported by Ahrion
	
	Super Metroid - Maridia Rocky Underwater Area
	composed by Minako Hamano
	ported by KevinM
	
Credits
	Natsuki Crisis Battle - Staff Roll
	composed by Sabakuma Yuki, Tomo Chan, AKP
	ported by Ahrion
	
EOF