This hack requires "bsnes-plus" to beat the game.

Mesen can work, but it requires a few extra steps for the Pitch Perfect puzzle.


Note: the game does NOT save: I'd recommend putting a save state before entering the golden door in the middle.
This room has a small chance of crashing if the answer is incorrect.