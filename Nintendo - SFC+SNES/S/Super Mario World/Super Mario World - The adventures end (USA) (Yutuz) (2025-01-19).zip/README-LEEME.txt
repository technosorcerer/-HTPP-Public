-------------SPANISH/ESPAÑOL------------

Muchas gracias por descargar The adventures end (las aventuras terminan), secuela directa de mi primer hack "Adventures Begin" la cual tendrá futura actualización y corrección de bugs, disfruta de este DEMO con su historia continua del anterior juego estoy abierto a cooperaciones para terminar el hack, porfavor no dudes en enviar un PM a SMWCENTRAL.

tu amigo YUTUZ....

-------------ENGLISH/INGLÉS-------------

Thank you very much for downloading The adventures end, direct sequel of my first hack "Adventures Begin" which will have future update and bug fixes, enjoy this DEMO with its continuing story of the previous game I am open to cooperations to finish the hack, please feel free to send a PM to SMWCENTRAL.

your friend YUTUZ....

---------AGRADECIMIENTOS ESPECIALES / SPECIAL VERY THANKS------------
Herramientas/tools
-Fusoya
-Romi
-SMWCentral Forum

Graphics/graficos
-Gamma V
-Shikaternia, TheOrangeToad
-Roy
-Hinalyte
-Mr. MS
-Pieguy1372
-Tahixham
-Yutuz
-Falconpunch
-Hinalyte
-E-man38
-Marioman
-Hayashi Neru
-Link13
-OrangeBronzeDaisy
-Rykon-V73
-DynastyLobster
-Merio

Bloques/blocks
-dacin
-HammerBrother
-Mariofangamer

Sprites
-Daizo Dee Von
-Eminus & Von Fahrenheit
-Darolac
-JamesD28
-HammerBrother
-Davros
-Sonikku
-Roy
-dahnamics
-Romi
-Isikoro
-Tattletale
-Dispari Scuro

Códigos ASM/ASM codes
-Mariofangamer
-KevinM
-GreenHammerBro
-Mattrizzle
-kaizoman666
-Telinc1
-Eduard

Musica/music
-LadiesMan217
-Vitor Vilela
-musicalman
-Milon Luxy
-JX444444