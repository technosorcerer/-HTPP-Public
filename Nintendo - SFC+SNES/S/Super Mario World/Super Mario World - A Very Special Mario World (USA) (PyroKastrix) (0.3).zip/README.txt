-A Very Special Mario World-
Version 0.3 Demo
Made by PyroKatrix and with help from various members of the SMWCentral community!

The princess seems to be missing again! However, she has left one clue...she says that she's somewhere special, and although you don't know what she could mean, you go on a journey to find her. Where could this "special" place be? That's on you to find out!

Changes:
-New levels!
-Subtle changes to graphics.
-A "path" to World 5.
-Him.

I hope you have as much fun playing my hack as I did working on it all these months.

From somewhere, with love,
	Pyrokastrix and Co.
________________________________________________________________________________

"The day I become fluent in asm will be the day of Armageddon. No pun intedned."
________________________________________________________________________________