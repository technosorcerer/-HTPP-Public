Thank you for playing the hack. 
There are some cutoff issues on some of the bridges, and I don't know how to fix them.
Credits are in credits.txt.
That's all i have to say. I just figured I should put a read me file in.
