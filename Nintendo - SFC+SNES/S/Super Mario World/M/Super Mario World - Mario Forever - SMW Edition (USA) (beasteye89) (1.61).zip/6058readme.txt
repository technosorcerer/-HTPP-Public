Thanks for downloading, hope you enjoy.
This hack has Auto-Save and a feature to warp between maps you've unlocked by pressing the Select button.
Some things don't function 1:1 like the original fangame due to various reasons.
Some music and SFX are not in the hack as they have not been ported to SMW by others and I don't know to do so myself.
If you encounter any gamebreaking bugs, please notify me.

Does not come with the Mario Forever toolbar. #sorry