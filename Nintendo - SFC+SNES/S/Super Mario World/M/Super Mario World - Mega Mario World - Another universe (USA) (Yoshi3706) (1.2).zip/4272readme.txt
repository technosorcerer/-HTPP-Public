English:
Here is the full version of my hack, hope you like it

Features:
-8 worlds
-saturated levels (perfect if you hate lineal and empity levels)
-some open levels, you can explore like a super mario 64 2D, find the stars!
-introducted many gameplay sprites like the fluud of SML2 submarine
-custom exgfx on levels and ow
-status bar enhanced

Issues: (i cant fix it)
-if you enter in level 1-2 using blue yoshi the palletes locks bad
-in level 6-! the cape palletes arent perfect
-in level 6-4 luigi molotovs dont match with the ground
-in 3-3 secret exit has a low probability of black screen

Special thanks to MasterLink for all his support, without his help this hack would be garbage (seriously!)

Espa�ol:
Aqui esta la version completa de mi hack, espero que les guste

Caracteristicas:
-8 mundos
-niveles saturados (perfecto si odias los niveles planos y vacios)
-algunos niveles abiertos, puedes explorarlos como si fuera un mario 64 2D, encuentra las estrellas!
-se introducieron algunos sprites que interfieren en la jugabilidad, como el fluud y el submarino de SML2
-exgfx personalizados en niveles y ow
-barra de estado mejorada

Problemas: (no pude corregirlos)
-si entras al nivel 1-2 usando un yoshi azul los colores se ven mal
-en el nivel 6-! las paletas de la capa se ven un poco mal
-en el nivel 6-4 los molotovs que laza luigi no quedan con el suelo
-en el nivel 3-3 usando la salida secreta hay una baja probabilidad de que aparezca una pantalla negra

Agradecimientos a MasterLink por todo su apoyo, sin su ayuda este hack seria basura (enserio!)

*Contain english and spanish patches
*Contiene los parches en espa�ol y ingles
_______________________________________________________________________________________________________
v1.1 fixes:
-corrected red dot from GREEN HILL ZONE? level
-reduced the lag on STORMY CLOUDS
-removed switch character, messes up the palettes from overworld


v1.1 arreglos:
-corregido el punto rojo del nivel GREEN HILL ZONE?
-reducido el lag en el nivel NUVES TORMENTOSAS
-eliminado el bloque de cambio de personaje, distorcionaba las paletas del overworld


v1.2 fixes:
-fixed english translation
-fixed a conflict with the names
-added the hack version at the title screen

v1.2 arreglos:
-corregida la traduccion al ingles
-corregido un conflicto con los nombres
-added the hack version at the title screen