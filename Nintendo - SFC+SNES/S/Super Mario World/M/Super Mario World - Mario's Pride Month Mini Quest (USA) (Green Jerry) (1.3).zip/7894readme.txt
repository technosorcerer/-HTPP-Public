                            __________________                                          __________________
                           |__________________|                                        |__________________|
                           |__________________|          MARIO'S                       |__________________|
                           |__________________|           _                            |__________________|
                           |__________________|          | \  _ .  _|  _               |__________________|
                           |__________________|          |_/ |  | / | /_\              |__________________|
                           |__________________|          |   |  | | | |                |__________________|
                           |                             |   |  | \_| \_/              |
                           |                                                           |
                           |                             |\/|  _   _  _|_ |_           |
                           |                             |  | / \ | \  |  | \          |
                           |                             |  | | | | |  |  | |          |
                           |                             |  | \_/ | |  \/ | |          |
                           |                                                           |
                           |                                     MINI QUEST            |

                           Version 1.3                                               Released on 21/06/2023

=========
= ABOUT =
=========

This hack has a Pride Month theme. This is a mini hack with 1 world, like most of my other special themed hacks.

I originally started this hack in June 2022, and only finished it just before the Summer 2022 C3 had started. That meant I couldn't finish the hack before June ended due to laziness, and didn't want to leave it unfinished until 2023, so I continued working on it anyways.

Then, after it released, I got negative feedback, saying the hack was low effort and embarrassing due to some softlocks being present in the initial release.

Then, Hooded Edge said the difficulty from the second level onwards was very hard. He didn't have fun because of trial and error, and he must be one of these people that hates hard games. Because of that, in this update, the hack has been nerfed.

I was going to bump up the version to 2.0 for this update, but decided to go with 1.3 instead.

==============
= CHANGE LOG =
==============

V1.3 (21/06/2022):
* Added the "Move Layer 3 to Subscreen Fix" patch, which fixes the problem where the status bar would be behind the foreground. I didn't patch it in the earlier versions, because I thought it would be incompatible with the "Inline Layer 3 Messages" patch.
* Mario's map palette now match with his level palette.
* Added a message box to Disco Fields. It explains what to do to be able to enter Pix's Castle.
* Nerfed Shell Cannon Hills, Yellow Switch, Pansers Cave, Rex Cave, Pogo Forest, Para-Beetle Forest, Fire Piranha Cave and Flying Shells Cave. Pits have been shortened, some parts have been changed and some enemies and munchers have been removed.
* Made some changes to Blue Switch to make getting a 1-up possible.
* Replaced a specific Pogo Toad in Pogo Forest that had random jump height with the one with a fixed jump height, which was warping through ? blocks when it was rising.
* Lowered the layer 3 leaves in Para-Beetle Forest by 2 tiles. 
* Replaced some Koopa with shell-less Koopas in Para-Beetle Forest to prevent softlocks.
* Replaced the music in the starting sublevel of Pix's Castle with the same music used in Disco Fields.

V1.2 (11/07/2022):
* Re-recorded the title screen demo, since the old one would sometimes bug out and make Mario die.
* Fixed some coins not appearing on sublevels due to item memory.
* Made a change in a part of Shell Cannon Hills. The setup with the yellow shell-less Koopa is replaced with a pipe and question blocks, and you now use the gray platform to progress past that part.
* Added yellow ! blocks to the pit in the sublevel of Shell Cannon Hills.
* Fixed an error with the ground which caused a large blatant cutoff in Yellow Switch.
* Replaced red ! blocks with blue ! blocks in Rex Cave.
* Fixed wrong corner tiles of the semisolid platforms in Pogo Forest.
* Added more Mario solid blocks in Pogo Forest in the part with the 3 Pogo Toads.
* Replaced a turn block with a question block in the secret exit room of Pogo Forest to prevent a softlock.
* Replaced a couple Para-Beetles in Para Beetle Forest.
* Moved the layer 3 leaves in Para Beetle Forest to make some Para-Beetles easier to see.
* Fixed the Para Beetle in the sublevel of Para Beetle Forest. It was also replaced with a big one. The sublevel was also changed so the entrance pipe is shorter.
* Added a pipe to Fire Piranha Cave to fix a problem where Mario gets instantly hurt after exiting the sublevel pipe. The plant was moved to that pipe.
* Removed muchers from a jump near the start of Flying Shells Cave.
* Replaced all Koopas in Flying Shells Cave with shell-less ones to prevent softlocks.
* Added an invisible coin block in a part after the midway of Flying Shells Cave to prevent a softlock.
* Replaced a bouncing Parakoopa with a normal one near the end of Flying Shells Cave.
* Added a pipe to Flying Shells Cave to allow the secret exit to be obtained.

V1.1 (09/07/2022):
* Fixed the overworld border's pattern.
* Fixed priority on a layer 1 tile.
* Fixed camera after exiting the bonus room in Pansers Cave.
* Fixed wrong blocks in Rex Cave. Also moved a row of red ! blocks down a tile to make a Yellow Rex not fall near the end of the level.
* Removed 2 munchers from Fire Piranha Cave that made a jump difficult without damage.
* Fixed unenterable secret exit pipe in Pogo Forest.

V1.0 (09/07/2022):
* Initial release.

===========
= CREDITS =
===========

Graphics:
---------
BMatSantos (SMW Logo Font)
Danooodle (Super Mario World Styled Switch Palace Expansion)
Dark Prince (Super Mario World (Prototype) - Forest)
Gamma V (Extra Tiles - Beach, Layer 3 Rainbow, mushroom house from her OW graphics)
Green Jerry (Rainbow flag, making the "Pride" logo)
Koopster (JUMP½ - Sprite-Solid Block)

Music:
------
Anas (Kirby Super Star - Boss Battle)
carol (Pop'n TwinBee: Rainbow Bell Adventures - A Child's Fantasy Realm)
Dispace (CUSTOM - 7th min Rock (Overworld))
Gamma V (Super Mario Kart - Koopa Troopa Beach)
Hooded Edge (Castlevania - All Clear)
Isikoro (Hamtaro Rainbow Rescue - Sunny Peak)
Kitikuchan (Dragon Quest 3 - Adventure)
MercuryPenny (Mega Man 6 - Plant Man)
Moose (Alcahest - Panakeian Temple)
Nameless (Sonic the Hedgehog 2 - Mystic Cave Zone, Sonic 3 & Knuckles - Act Clear, Sonic 3 & Knuckles - Lava Reef Zone Act 1)
NewPointless (Dragon Warrior - Rainbow Staff (Rainbow Harp))
Pinci (Crayon Shin-chan 2: Dai Maou no Gyakushuu - Park)
Samantha (Chrono Trigger - Underground Sewer)
Segment1Zone2 (Chip's Challenge (Windows) - CHIP02.mid)
Taffy (Kirby & The Amazing Mirror - Rainbow Route)
Tornado (Double Rainbow)
Zavok (Mario Kart 64 - Rainbow Road, Sonic 3 & Knuckles - Endless Mine)

Blocks:
-------
ASMagician Maks (Mario Solid & Sprite Solid Blocks)
MarioE (ON/OFF block from switch pack)

Sprites:
--------
Erik (Bouncing Rex)
imamelia (Panser, Para-Beetle, Pogo Toad, Venus Fire Trap/Fire Piranha Plant [normal, spreadshot and shower variants])
MarioFanGamer (Shell Shooter)
MarkAlarm (Para-Beetle)
spooonsss (Shell shooter modification)
Romi (Para-Beetle)
RussianMan (Chasing & Hidden Rex, Flyin' Disco Shell)
yoshicookiezeus (Kirby 64: The Crystal Shards - Pix)

Patches:
--------
0x400 (SMB3 Powerdown)
Alcaro (Item Box Mushroom Priority Fix, Placeable Disco Shell)
Chdata (Piranha Plant Fix)
Kevin (Disable Scorecard GFX, Move Layer 3 to Subscreen Fix, Per Level "Mario Start!" Enable/Disable)
Lui (Move Layer 3 to Subscreen Fix)
MarioFanGamer (Inline Layer 3 Messages)
p4plus2 (One OR Two Players Only)

UberASM:
--------
Kevin (Disable HDMA During Transitions)

Tweaks:
-------
Telinc1 (No-Fade Out Goal)

Tools:
------
Alcaro (Asar)
ExoticMatter (GradientTool)
FuSoYa (Lunar Magic)
JackTheSpades (PIXI)
Kipernal (AddmusicK)
p4plus2 (Gopher Popcorn Stew)
Tattletale (PIXI)
TheBiob (Gopher Popcorn Stew)
Vitor Vilela (UberASM Tool)