Credits:
--------

Graphics:
10863
Alex No
Amomario123w
Berk
Big Brawler
Black Sabbath
BMatSantos
Buu
CaptainFoxx
cheeyev
Doomdragon
Green Jerry
GreenHammerBro
imamelia
Koops
Mario3andU
MarioFanGamer
Masterlink
Mirann
Mogu94
ralfsrein_05
SMW_Hacker17
Sonikku
SuperArthurBros
tcdw
Telinc1
tmauri
Tornado
yno14jax
Zack-san

Patches:
1524
Alcaro
Blind Devil
BMF54123
Chdata
Ersanio
KPhoenix
Ladida
Major Flare
MarioE
Mattrizzle
Mellonpizza
Moltz
WhiteYoshiEgg

Sprites:
Davros
imamelia
Koyuki
LX5
Mathos
mikeyk
Romi
Sonikku
Tsutarja

Music & Sound Effects:
LadiesMan217
musicalman
Vitor Vilela

Tools:
Alcaro
FuSoYa
JackTheSpades
Smallhacker
spel werdz rite (Generic Palette Editor - just to edit the SMB3 status bar patch's palette)

Miscellaneous:
Telinc1 (the fix for the Venus Fire Trap's fireballs not shooting 100% correctly)

Change Log:
-----------

-Replaced MidiGuy's and Koyuki's music and sound effects with LadiesMan217's ultimate versions.
-Changed the P-meter's sound effect to SMB3's.
-The presents logo now fades in.
-Fixed the file select palette in the title screen.
-Fixed the goal card's sound effect and music.
-Fixed the goal sphere's music in Boom Boom's Airship.
-Fixed the level tiles after clearing levels in the OW.
-Made some small changes in Para-Beetle Jumps, Roto-Disc Fortress and Boomerang Attack.
-Added 100 seconds to Roto-Disc Fortress, Beetle Cave, Boss Bass Lake, Piranha Plains and Boom Boom's Airship's time limits.
-Raised the block platform at the end of Boss Bass Lake by 1 tile.
-Added an "End of the hack" level. This "level" has no number on its level tile.
-Replaced the drumroll sound effect with SMB3's, even though it's not used due to the SMB3 status bar patch including the minimalist course clear patch with it.
-Entering a level now plays a sound effect.
-Removed the No-Yoshi intro from the Toad Houses.
-Fixed the arrows' colors while scrolling the OW.
-Fixed the item and sphere's palettes in Boom Boom's room.
-Changed the save prompt's font and fixed the palette.
-Removed 1 rocky wrench from Boom Boom's Airship.