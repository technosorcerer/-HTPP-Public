Masterpiece

==== Changes ====

v1.2.8
 - Added a new post-post-post-game level, the black switch palace, 'F.U. palace'
    - completing this level activates 'FU mode', which adds deathblocks to every level in the game, making them substantially harder
    - to activate this effect from a fresh save to replay the entire game in FU mode, enter the following cheat code:
        - In the scoreboard room of 'i keep crawlin back', press: left right L R up up down left R A
 - Added a new gag level 'her wideness'
 - You can now replay completed switch palaces
 - The scoreboard in 'i keep crawlin back' now shows comma and FU switches
 - Added a patch to fix the vanilla SMW bug where running off layer 2 starts you with high velocity
 - In Boss 2 (Bullet Wizard), all bullets and fireballs are now destroyed at the moment the boss is defeated
 - Fixed inconsistent spawning for the rotating platforms in Boss 3 (Reznor)
 - Reduced the time that Boss 5 (Clawgrip) remains invincible after the screen stops scrolling
 - Reworked the ending of 'over the top' to avoid a rare crash
 - In 'i should call her', collecting the post-goal moon now immediately fades to overworld, saving time on the victory walk
 - Fixed a random muncher in 'return to daddy's castle' acting as a solid block
 - Changes to 'enter haimari':
    - use B/Y to go right/left (up/down is still on d-pad)
    - halved speed when bouncing off solids vertically
    - sonic no longer throws hammers when you're very close to him
 - In 'poetry in motion', ghosts that enter the area where new ghosts will not spawn are now destroyed
 - Changes to 'indulge me':
    - redesigned the 'poetry in motion'-based room
    - Small tweaks to the sublevels based on 'gwenyth paltrow' and 'the worlds richest man'
    - Fixed a bug where touching a spiny with the fireflower when it was the last uncompleted sublevel would start an infinite death loop
 - Changes to 'god's final message to her creation':
    - added an optional sublevel that reveals the block choice odds
    - you can no longer roll two death blocks in a row
    - added screen shake when a deathblock is spawned
    - fixed some solid blocks not counting as solid for the spawn cursor logic (turn blocks and brown blocks)
    - some level layout tweaks
 - Changes to 'inner critic':
    - Slightly slowed the rate of egg shooting in the second birdo sublevel  
    - Updated the flying platforms in sublevels 21 and 22 to decrease waiting time as the sublevel starts
    - Lowered the pipe by one tile in the fourth birdo sublevel
 - Furthermore, small layout tweaks were made to the following levels:
    - 'malicious appliance'
    - 'bedlam'
    - 'sigma star'
    - 'i keep crawlin back'
    - 'born and raised'
    - 'fish bish'
    - 'thinly veiled threat'
    - 'left hand of darkness'
    - 'i should call her'
    - 'dream catcher'
    - 'poetry in motion'

==== Credits ====

Complete Themes by
    Kuraine
and ported by
    BeanJammin

Title Screen
and Sonic Cutscene Panels by
    Darcy Dee

Music
    Ahrion
    AnasMario130
    BeanJammin
    bebn legg
    brickblock369
    com_poser
    DanTheVP
    Decoy Blimp
    Dippy
    Dzing
    EDIT3333
    Enderdavid_HD
    Fullcannon
    FYRE150
    Giftshaven
    Gloomy
    h.carrell
    Haimari
    Hooded Edge
    icrawfish
    its_4life
    Kevin
    kx^2
    LadiesMan217
    Lui
    Masterlink
    MercuryPenny
    Ontwikseltsaar
    Overcrow
    PatchesXLI
    Pinci
    Planeswater
    Pulsar
    qantuum
    S1Z2
    SiameseTwins
    sincx
    sinseiga
    tcdw
    Ultima
    Wakana
    Xulon

Graphics
    AmperSam
    Anorakun
    Ayami
    Bandit
    DTA450
    edit1754
    Haimari
    Kusamochi
    Luigi-San
    mikeyk
    Roberto zampari
    Santo
    Sonikku
    Tornado

ASM
    0x400
    Alcaro
    AmperSam
    Arujus
    ASM
    betalogic
    Blind Devil
    Chdata
    chillyfox
    dacin
    Davros
    DiscoTheBat
    DJLocks
    dogemaster
    dtothefourth
    edit1754
    Erik/Kaijyuu
    Fernap
    HammerBrother
    imamelia
    JackTheSpades
    JamesD28
    Karisa
    Katun24
    Kevin
    Koopster
    Ladida
    lolcats439
    lx5
    Major Flare
    MarioFanGamer
    MarkAlarm
    MathOnNapkins
    Medic
    mikeyk
    MiracleWater
    NoelYoshi
    Noobish Noobsicle
    p4plus2
    Ragey
    Romi
    Roy
    RPG Hacker
    RussianMan
    Sonikku
    spooonsss
    Supermario1313
    Tattletale
    Telinc1
    TheBiob
    TheBourgyman
    tjb0607
    underway
    Vitor Vilela
    worldpeace
    xHF01x
    yoshifanatic

Tools
    RHR Baserom
    AddMusicK
    Callisto
    Lunar Magic
    UberASM
    PIXI
    GPS
    -----
    Alcaro
    Atari2.0
    Fernap
    FuSoYa
    JackTheSpades
    Kipernal
    KungFuFurby
    p4plus2
    Tattletale
    TheBiob
    underway
    Vitor Vilela

Thanks
    Amethyst_Rocks
    authorblues
    Barbarian
    BeanJammin
    carrarium
    CircleFriendo
    Darcy Dee
    dtothefourth
    flips
    Greg
    Kevin
    Kuraine
    lungfish3000
    Noel
    Shoujo
    shovda
    Z