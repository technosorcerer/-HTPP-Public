This is a hack vaguely inspired by Nonsense and by the completely insane stories that game mods usually come up with to justify the plot.
It features a lot of custom sprites & blocks (thanks to the BLDC2 baserom) and short-ish levels and worlds, as well as a more forgiving system for taking damage. 
I had lots of fun making this hack, and hope it's as fun to play!

Also it's been updated to 1.1.1 now (minor fixes)

-plot-
Mario wants to go to the store. 
However, he doesn't know that he's going to go through Heaven and Hell, the top of the tallest mountain, the depths of the sea, and the fifth dimension. And also prevent the end of the world as foretold by the Mayan prophecy of 2012.

- This hack uses the BLDC2 Baserom, the credits of which are on a separate .txt file. -

PATCHES:

DKC2 Navigation Arrows by LX5

RAM-dependent Power-up Autokill & 'Traditional' Damage by Beta Logic

Enhanced Powerup Grab by Maxx


LEVELS:

Off The Grid is adapted from a one-off level Derahex made and gave me permission to put in the hack (thanks!)


SPECIAL THANKS to Crocodileclaus94 for helping massively with testing!
...and to everyone who plays and/or enjoys the things that I make :)


MUSIC:

SPOILERS!!! 
SPOILERS BELOW THIS SECTION!!! 
YOU'RE GOING TO BE SO SPOILERED IF YOU SCROLL PAST THIS!!!





MUSIC credits, as well as where they play on, in no particular order:






Pixl the Axolotl
 Boston - More than a Feeling (Credits)
 Sonic 3 & Knuckles - Sandopolis Zone Act 1 (John Tay Alternative) (Everything Tower)
 Sonic 3 & Knuckles - Sandopolis Zone Act 2 (John Tay Alternative) (RUN! JUMP! HIDE!)

Dispace Tourblex
 Michael Jackson - Love never felt so good (Cast Roll)
 Super Paper Mario - Overthere Stairs (Rainforest Lake)
 Sonic Advance 2 - Techno Base Act 1 (Off The Grid)

Wakana
 Touhou Seirensen ~ Undefined Fantastic Object - Heian Alien (IT'S SO OVER)
 Jaguar XJ220 - Speed-e-Boy (EVIL JANK LAND)
 Undertale - Bergentrückung + ASGORE (1000 KM MARATHON)
 Mega Man 9 - Flash in the Dark (At Heck's Gate)

Kevin
 Last Bible III - Shark Ship (Phase Transition)
 Savage - Level 1 (SAVAGE!!! Climb)
 Kirby 64: The Crystal Shards - Aqua Star (Kirby's Dream Land 3 Style) (Pinci is also credited) (Cloud Park (Heaven))
 The Adventures of Kid Kleets - Title (They Love You!)
 Hebereke's Popoon - Unused (GOODBYE SOBER DAY boss)
 E.V.O.: Search for Eden - Bolbox ~ Unnatural Threat (The Store)
 "Flesh Cake" (World 6)
 Chrono Trigger - Ruined World (TORTUROUS ATHLETIC)
 Super Metroid - Maridia Drifting Sand Underwater Area (Idiot Party)

Pinci
 Super Mario 64 - Bob-omb Battlefield (GOD'S JOLLY KINGDOM)
 Seaside Stroll (Honey Mountain)
 Mother 3 - Mind Of A Thief (The Transitway)

Ultima
 Sonic Adventure 2 - Live and Learn (STAR ROAD MEGAMIX 2)

sinseiga
 Deltarune - A CYBER'S WORLD? (A SUPER'S WORLD?)

EDIT3333
Columns III: Revenge of Columns - Industrial District (GOD'S HOLY CHURCH)

icrawfish
 Megami Tensei Gaiden: Last Bible II - Town (Remix) (World 2, Donut Cliffs)
 Five Nights at Freddy's 3 - Bonnie's Lullaby (feed me)

Wyatt 
 Bob Sinclar - Save Our Soul (Final Boss)
 Siren (Alexander Brandon) - Snowfall (SHARED DIG)

Nanako
 Kirby's Dream Land 3 - Pop Star

Ahrion
 Azazel - Polta Taivas (World 3, portal)
 Persona 2: Innocent Sin - Yukino's Theme 

Overcrow03 
 Masayoshi Takanaka - Brasilian Skies (BRAZILIAN SKIES)
 Masayoshi Takanaka - An Insatiable High (LEVEL 1, BUT...)

Fyre150
 Kirby 64: The Crystal Shards - Quiet Forest (he loves eat rocks)
 Sutte Hakkun - Stage 1 (SUNSET COURSE)

bebn legg
 Sonic Robo Blast 2 (V2.2) - Arid Canyon Zone Act 1 (Red Sand Desert)

Ahrion
 Terranigma - Laboratory (EVIL COURSE)
 Shin Megami Tensei - Home (red s. room)
 Dubmood - smb-Polka (SHARED DIG bonus)

SiameseTwins
 Brandish 2: The Planet Buster (SNES) - Laboratory (NONSENSE HOUSE)

Aguiar Salsicha 
 Umineko no Naku Koro ni (When They Cry) - Aci-L (40 CELSIUS BATH)
 SpongeBob SquarePants - Grass Skirt Chase

h.carrell
 Earthbound - Megaton Walk (World 5, Blazing Beach)
 E.V.O.: Search for Eden - Forest Ambience (places)

FalseCircus
 Green Day - Boulevard of Broken Dreams (YELLHAUS)

eltiolavara9
 Kevin Macleod - New Friendly (Title)

Nikku4211
 Skope - Arpeggiator (TOP BANANA AREA)

Sui
 SVC Chaos - Power Generation Room (edited a bit) (new old life)

Enderdavid_HD 
 Plants Vs. Zombies - Cerebrawl (Low-Budget Palace)

Ultima
 Columns III: Revenge of Columns - Column Dive (BEEN IN THE HILLS)

qantuum
 Aphex Twin - Red Calx (World 7, Middle of Nowhere)

JX444444
 Ultimate DOOM - I Sawed the Demons (Mega Man X2 Style)

brickblock369
 EarthBound - Buzz Buzz's Prophecy (World 1, The Angel's Heaven)

SiameseTwins
 EarthBound - Battle Against a Weird Opponent (NORMAL HOUSE boss)

StackDino
 EarthBound - Threed, Zombie Central (Part 2 of AT HECK'S GATE)

MercuryPenny
 Deltarune - My Castle Town (SREGGSofLIBNUM)
 Mario & Luigi: Partners in Time - Yoob's Belly (RED RUINS)
 EarthBound - You Gained a Level! (some minor areas rarely)

Captain 3
 Splatoon - Tornado Shuffle (BURNING BRIDGE)

phlip
 Full Tilt! Space Cadet Pinball - Mission Theme (bonus of THE TRANSITWAY)

ScubaSaul
 Secret of Evermore - Queen Bluegarden (OBERON SMOG)

Unknown User
 E.V.O.: Search for Eden - Tension (tense areas)

AmperSam
 Elvira: Mistress of the Dark - Loader (EVIL JANK LAND part 2)

CosmicTiff
 Mario Artist: Polygon Studio - Modeler Rocket (Music Type 2) (World 4, Badweather National Park)

Maxodex
 Homestuck - Moonsetter (MOONSETTER)

mueuen
 MF DOOM - Doomsday (SUPERYoshi's island2)

HarvettFox96
 Happy H. Christmas (YELLHAUS boss)
 Wizardry (C64) - Main Theme (Hailstorm Keep part 1)
 Wizardry (C64) - Blue Room (Hailstorm Keep part 2)

Apple
 Mother 3 - Porky's Pokies (Normal House)

RednGreen
 Plok - Akrillic (Bright Garden)

Gamma V
 Secret of Mana - Still of the Night (VIDEO GAMES?! section 1)

Dippy
 Bomberman Hero - Redial (BRIDGE STYX)
 Spelunky - Mines B (Horso)
 Spelunky - Yeti Caves (Horso)
 Mother 3 - Volcano! Inferno! (TIDES, OK?!?!)

worldpeace
 Siren (Alexander Brandon) - Repression (DOWNBOAR)

Bak Sangwoo
 Rise of the Triad (1995) - Goin' Down the Fast Way (REUSE! RECYCLE!)

ShivjotRangi
 Ecco: The Tides of Time - Title Theme (VIDEO GAMES?! section 2)

DanTheVP
 Star Fox - Meteor (ACHTUNG! PERILL!)

Drink
 Yume Nikki - Shield-Folk World (some places)

84GSMeister
 Super Mario 64 - Big Boo's Haunt (GOODBYE SOBER DAY)

Hazel
 Castlevania 3 - Evergreen (VIDEO GAMES?! section 3)