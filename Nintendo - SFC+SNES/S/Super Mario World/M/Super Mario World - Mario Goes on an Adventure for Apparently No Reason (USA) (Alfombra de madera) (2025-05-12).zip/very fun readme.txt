Hey I hate readme files and my English sucks

This is my discord:
alfombracitarioj

PLEASE LEAVE A COMMENT IN SMWCENTRAL

If you're waiting for other update stop waiting, better go to YouTube (Alfombra de madera) and download other of my games if I make one

tyvm for downloading the hack!!!1



About demo 1.5

Yep, this version actually isn't complete (well, I know it is a demo but there are two levels you can't play on expert mode) this is because I'm not only busy to make a story, I'm busy to continue working on this so I uploaded this version for now, I hope to work on those two levels soon!


and if you are wondering what "busy" means... I have other projects (and sometimes I waste my time playing Minecraft lol)