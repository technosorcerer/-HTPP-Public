Hack title: Super Mario World Master Quest 4: Redrawn
Author: Alex No
Release date: 2009-03-17
Exits: 70
Fixed by: Mr. MS

This is a fixed version of the latest release of "Super Mario World Master Quest 4: Redrawn", made by Alex No, that fixes broken music in accurate emulators.

Fixes provided:

- Fixed broken music that would cause music noises accurate emulators.
- Fixed the wrong checksum.
- Enabled FastROM to fix a problem in the level "MASTER WORLD 8" and reduce slowdown on some levels.
