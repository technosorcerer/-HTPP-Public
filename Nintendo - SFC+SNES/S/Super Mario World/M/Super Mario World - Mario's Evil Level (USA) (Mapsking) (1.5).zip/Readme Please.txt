Hello there!

This is Mario's Evil Level. It is a challenging hack, but before you begin, there are a few things I would like to tell you. This is a long and difficult level.

This level won the first place for the hardest/longest competition in the first Kaizo level contest at www.smwcentral.net.

Savestates are almost certainly required to beat this hack. I recommend using multiple or auto-incrementing save states, to avoid any accidental savestates.

I made this hack for a few reasons. At the time, Kaizo hacks were first coming out, and were not a standard thing. There were also far fewer patches, and other resources than nowadays. However, many of the Kaizo/difficult hacks had all kinds of graphical glitches, stacked/floating munchers, required abuse of glitches, and while difficult, often looked horrible aesthetically. I decided that I was going to do something different, to make a hard hack that did not look visually appalling or required glitches or slowdown to complete. In Mario's Evil Level, no glitches are intended to be used. As a result, I present a hard hack, with no floating/stacked munchers, no glitchy graphics, no game glitches, no use of slowdown required, actually possible, and yet still challenging.

BTW, this level has been thoroughly tested, with no known errors, but if you happen to find some, please let me know, and I will try to correct them. It was originally intended to be played with Zsnes, and has been with Retroarch and a Snes9x core and on Snes9x. It is known to crash the game/cause problems on a flashcart system.

***Special thanks to xHF01x who originally fixed the music so the hack would work in modern emulators, Parahax_ who helped me with some palette and graphics related questions, Brakkie for ASM help, and NixKillsMyths for additional playtesting.***

Thanks for downloading this, and taking the time to read all of this, even if you simply skipped to the end.  I hope you enjoy Mario's Evil Level, and have fun playing it! Good luck! If you happen to stream it, feel free to put #MEL in your stream title.

Thanks, Mapsking
Originally 1.0 version released 1/2010, edited and updated 01/2024

p.s. There is a silly little secret in Loser's House for anyone who reads this!
-----
Mario's Evil Level Changes

v1.5

-100% Remade in modern LM and mostly modern tools
-Minor graphical OW changes
-Fixed many title screen GFX
-Corrected ExAnimation syncing for horizontal munchers
-Added a "Visibility" option, where the blocks that hurt Mario now look different for those who want it, along with a bunch of graphical changes
-Some music changes
-Credits have been redone
-Applied Counter Break patch (credits to Glyph Phoenix and Roy)
-Applied Even More Nintendo Presents Logo Expansion patch (credits to KevinM)
-Applied More Extended Sprites (credits to SP9_A+B+Up)
-Some "Level Depending On Event" Patch code used or modified (credits to Deflaktor for original patch and Brakkie for help)
-Some "Custom Level Message Sprite" code used or modified (credits to imamelia for original patch and Brakkie for help)
-Some "Normal/Hard Mode" patch code used or modified (credits to wiiqwertyuiop for original patch and Brakkie for help)
-Tons of various other tweaks and things
-Fixed reverse control water allowing you to get stuck in the wall
-Added in OW saves, allowing you to continue and play either Original or Visibility modes at your discretion.

v1.4
-Nerfed a difficult jump
-Fixed a glitch with the boss fight

v1.3
-Fixed minor graphical
-Fixed Secret Exit OW events
-Fixed all broken music

v1.2
-This has a patch added to remove the life counter being reduced upon death, however, it still shows the number of lives.
-Added version number to title screen.

v1.1
-This has been updated to work with modern systems, and fixed some graphical bugs with the boss palette.

v1.0
-Original Release