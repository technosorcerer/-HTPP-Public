MEGASTALGIA: THE OFFICIAL README


This project came about from my love of Mega Man (and the limitations of Mega Man Maker).  I like to think this is a first-of-its-kind thing, but it�s probably not any such thing.  The point is, this is Mario meets Mega Man, and its total Mega Man overload!  Have fun with this � I had a lot of fun making it (and a lot of hours).  Also, yes Mega Man does walk with a pimp limp (thanks to that Tripod he�s packing)�so yeah.  It�s actually because Mega Man is just shy of fitting into the graphical parameters of Mario, so the movement is a bit �off�.  It�s worth it, damn it.  Back me up here.  So, another item of note is that this hack was intended to be released in time for Christmas 2023; however, this was an aggressive timeline for a project like this.  For reasons within AND out of my control, the deadline wasn�t met, and thus here we are in late January of 2024.  It�ll ride, man, for Christmas � the levels are all snowy and holly jolly and whatnot.  Like the snowman from Rudolph, good ol� Burl Ives.  It�s fine.  Lastly, this hack is like Die Hard, but actually a Christmas installment.  
Let�s talk features and controls:

Leaf Shield:

The game comes with the ability to utilize the Leaf Shield, but only in certain levels / areas.  The Leaf Shield is activated and thrown (if you want) by pressing the  �R� button on the controller.  The Leaf Shield can be used in the following levels, and it�s awesome and devastating:
1. Level 3, Electric Slide Stage, Mega Ride Section.
2. Level 5, Twinnin� the Past Stage, Main Section.
3. Level 9, Maverick HQ Stage, Mega Ride Section / Boss Door Room.
4. All other controls are typical SMW garb.

Known Issues / Notes on Overcoming Them:

In Level 06, Star Laboratories, it is sometimes necessary to fall into a hole after grabbing the checkpoint.  Not doing so can cause the boss to not spawn correctly.  The game has infinite lives, and you will restart with a �mega-shroom� equipped by default, so just do this step to avoid being locked in the boss room.  Additionally, this boss can ONLY be defeated by dealing the final blow when and only when his projectiles are off screen.  Make sure they are not on the screen when you deliver that last hit, or the projectiles survive and well, you lose.  Save states suggested here.  The same can occur in the ending of the Cut Man battle � some of the coding is just glitchy with some emulators.

Additional Thanks:

I�d like to thank the RE-TV team, Green Jerry, the SMW Central community and their contributions with graphics and music (there�s too many to name), and YOU for playing.  I hope you enjoy it!  Also, a big thanks to Com_Poser for helping with the intro sound.  And as always, Big Chrome.  If you know the legend of Big Chrome, you know it�s one to be told forever. 
Lastly, if you want, I�ve included a Mario version of the game if you don�t wanna play as Mega Man.  Suit Yourself.

- DanJer / Yeto / Koopenstein.  01/27/2024.


