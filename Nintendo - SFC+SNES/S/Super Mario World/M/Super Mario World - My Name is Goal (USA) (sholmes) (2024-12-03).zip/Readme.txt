note: the evil goal boss is attempted to shatter the master emerald, so tails has to find a way how to defeat him, but can he rebuild the bridge that goal boss destroyed
this is inspired by omh and rack (r-omh-ack)

note: at the the end level the player presses a switch and clears the level, and castle from overworld gets destroyed so goal cannot continue inside, is a victory.

one of the levels of world 2, is a refence of the level warning, Christmas from brutal mario, where mario destroys Christmas decorations (snowmen, or even a Yoshi and peach wearing a hat) however is Halloween instead of Christmas.

hack: sholmes


Graphics:

sonic the hedgehog 2 - title screen by Thehoundsquad

grassland by Rykon-V73

Sonic the Hedgehog 2 hill top zone by NopeContest

underground cavern by Skewer

Sonic Advance casino paradise zone by Luigi-San

mega man 2 flash man stage by Daizo dee von

new super mario bros clouds by Rykon-V73

new super mario bros wii forest by bruninhopz

new super mario bros castle by codfish1002

sonic the hedgehog green hill zone by Alessio

Music (Note, most of the ports are from homing's music pack):

Phineas and ferb - my name is doof (sholmes)

final fantasy adventure - in search of the sacred sword (homing)

treasure hunter g - sad freedom (sholmes) (first appearance of this port is in back to the green hill)

hydlide 3 - town (homing)

suzumiya haruhi - bouken desho desho (homing)

Mario Kart ds - rainbow road (homing)

omh - theme of the plumber (unsampled version of no regrets, rigt?) (daizo dee von and team JANK)

a plumber for all seasons - battle of destiny (imamelia)

tetris - music b (homing)

Kirby's adventure - rainbow resort (homing)

mario paint - creative exercise (homing)

super mario land - muda kingdom (homing)

Kirby super star - green greens (homing)

new super mario bros - overworld (homing)

tetris - music c (homing)

super mario rpg - forest maze (homing)

mega man 2 - wily stage 1 & 2 (homing)

donkey kong country - krook's march (homing)

super mario bros - castle (homing)

kid icarus - underworld (homing)

easy waters (gpetry)

last bible 3 - battle with arec (kevin)

robo warrior - level 1 (homing)

r-ack - no regrets right ? (daizo dee von)

omh - springtrap is mocking you - i always come back (Daizo dee von, hooded edge, Jonah and Team JANK) (remix of battle against vending machine and gadobadorrer)

omh - tower of exits - a secondary exit (Daizo dee von and Team JANK)(omh's final level)

zakuro no aji - action (Nanako) (as heard in Doctor Andre battle from alpha sphere)

brandish 2: the planet buster - the world will become zero - gadobadorrer (mega man x styled) (daizo dee von) (as heard during battle against megagoaldobadorrer boss)

Romancing saga 2 rest theme (kevin)

Blocks:

Mario Solid and Sprite Solid by ASMagician Maks

passable on Yoshi coin by multibella

pass if no sprites on screen by teo17

infinite throwblock spawner (from throw blocks pack) by hammerbrother

passable on all (5) dragon (Yoshi) coins by morsel

one way blocks by hammerbrother 

passable ledge with SFX by Bird0, Sonikku and p4plus2

Sprites:

dry spiny by andy_k_250 (tweaked sprite)

goomba, jumps on walls by russianman

super mario bros wonder melon plant by Russianman

explosive crosshair by TheXander

bill bomber by darloac

bobomb tower by ampersam

boom boom by codfish1002 (note: this is a c3 sprite that is found in c3 forums, at summer 2022 in codfish1002's forum

ball and chain pendulum by alcaro

flamethrower blaarg by russianman

chasing swooper by russianman

mario forever piranha plant by russianman

blaarg disassembly by yoshicookiezeus

divisible boo by anonimzwx

splunkin by boingboingsplat

SMM jumping piranha plant by russianman

ball n chain (pendulum movement) by alcaro

mosaic thwimp by mellymellouange

burt bros by dahnamics (is not in the section but i found it in a rejection log with a download link on)

yellow parakoopa by erik

amazing flying sumo bro by erik

pipe dwelling volcano lotus by russianman

exploding wiggler by russianman

invincible/flashing shell by Sonikku

mega man scroll gate by hammerbrother

iggy boss by koyuji

deadweight bro by imamelia and schwa

bouncing power thwomp by yoshicookiezeus

upside down thwimp (ceiling thwimp) by Mellymellouange

ultimate noob boos by iceguy and Nesquik bunny

bullet bill disassembly by imamelia

blue parakoopa by erik

Gunvolt by dahnamics

X/Y position locked sprite by kevin

line guided any sprite by kevin and dtothefourth

speedrun timer by nowieso

giant goomba boss (SMB3) by imamelia

custom shooter by mariofangamer

mechakoopa but awesome by von Fahrenheit and eminus

switch place sprite by russianman

Patches:

no more sprite tile limits by arujus, mathonkapkins, noelyoshi, tattletale, vitor vilela and edit1754

remove status bar by lui

one file, one player by kevin

VWF Level Intros by ladida and imamelia

SMB3 screen scrolling pipes by fusoya, hammerbrother, erik, deflaktor and spel werd rite

uber asm:

teleport is no enemies by Thomas

inspirations:

JUMP (intro level is a reference)

Brutal Mario (the level warning decorations is a reference to warning, Christmas level)

Bib's adventure (old hack) (bib's adventure uses homing's music pack and my name is goal uses the same)(it is almost like a kaizo hack and wasn't in smw central since during smw central's first days kaizo hacks weren't allowed)

R-ACK (the goal tape boss is a reference of goaldobadorrer)

-OMH- (the final level and the key boss are inspired by the ones from that hack, as well as the vip spoo lemmy boss is inspired by springtrap from i always come back level)

The Brutal Dream (in the final level, the turricane 2 spaceship (from machine boss), is used as ultimate noob boss, which is a reference to the boss from the bowser domain level but in my name is goal is Morton instead of roy, the spaceship graphics are used from the spriters resource and doesn't use the ones from the hack)

VIP series (the graphics of lemmy flying on a spaceship is a sprite from vip and wall mix 2, where after destroying it's spaceship he will become brutal mario lemmy, the graphics used for lemmy boss from brutal mario where from vip and wall and used by carol for brutal mario, in my name is goal (my hack), the graphics of the boss where used as ultimate noob boss and making a reference of springtrap from omh)