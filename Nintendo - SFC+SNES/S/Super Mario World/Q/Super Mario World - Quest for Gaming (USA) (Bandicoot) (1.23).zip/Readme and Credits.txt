SMW Quest for Gaming:

Story:
After so many adventures and Princess Peach rescues Mario and Yoshi finally can have some time 
for some gaming, however the evil Bowser has stolen their games, now they must travel through all the lands 
and take their games and SNES back.
 
Gameplay:
The gameplay in this hack is pretty much the same as the original Super Mario World
However there are some additions and improvements to the game
Some of them being:
- Walljumps 
- Autosave between levels
- Optional Collectables save between deaths and to the save file
- Better P-balloon physics
- Better powerups powerdowns
- Upwards Fireballs
- Safe Falls if you have a powerup
- Dynamic Dificulty System


-----------------------------------------------------------------------------
Credits:

Level Design:
Bandicoot

---------------------
Special Thanks:

Great supporters:
-Brazilian Community
-Mario Hacks Community on Discord

Great help with the beta testing:
- N450
- Deankind & Flickering PixelZ on Twitch
- Lordkronos100
- Fire Fast

Thanks for fulfilling some resource requests I used on this hack: 
-Koopster
-Cthulu
-E-man38
- Goomba24
- Francium

DDA Blocks Improvements:
- MS

Moderation:
- Patcdr(completed)
- Beekay(demo)
-----------------------------------------------
Beta Testing:
Segment1Zone2
Forthrightmc
N450
Lordkronos100(smwcentral&Youtube)
FlickeringPixelsz(Twitch)
Deankind(Twitch)
Wickedlaw(Twitch)
Gabriel(mario hacks on discord)
erpster2
Fire Fast
-------------------------------
Graphics:
Gamma V
Bandicoot
mariomaker6
E-man38
Kaeru
AyGaAlPa
Fernandito2018
Green Jerry
Ayami
Dan
SiulLunar
DTG 
icegoom
I8Strudel
Rykon-V73
majora211
Gate
mit
JowTH
PokerFace
PinkgoldPeach
Tornado
UTF
Daizo Dee Von
LinkstormZ
ModernKiwi
Alessio
Uncle_Bones
Crafink 
ModernKiwi
Segment1Zone2
SF - The Dark Warrior
KiloMinimo 
MarioFanGamer
Luigi-San
----------------------------------------------------
Music:
Pink Gold Peach/Rilla Roo
Gamma V
mindmatchingmoment
Goomba-24
MidiGuy
gibbl
HaruMKT
Coolmario
ShadowBoyUltra
Slash Man
NastCF
Brad Buxer
K.T.B
Dark Mario Bros
Infinity
marioVSshadow
Masterlink
Samantha
Torchkas
Marcozzo Daro
Ladiesman217
Dippy
RednGreen
KevinM
Maxodex
Nameless
Wavee	
xyz600sp
Ultima
bebn legg
qantuum
Hooded Edge
Anas
musicalman	
Roberto zampari		
SiameseTwins
Pistacio
Kevin
Nambona890
Lucas
Taffy
Milon Luxy
undefinied3
x-treme
Lui
Holy Order Sol
K3nny
EDIT3333	
DMB
Teows
DanTheVP
Jane Dohe
Captain 3
ThinkOneMoreTime
brickblock369
Isikoro	
Atma
Vitor Vilela 
Lui37
Darius
-----------------------------------------------------
ASM/Patches:
StackDino
Koopster
RussianMan
MarioFanGamer
Arujus
MathOnNapkins
Tattletale
V'Lanta'la'mana'ma'nisha
Vitor Vilela
edit1754
LX5
Romi
aCrowned
Alcaro
BMF
Disk Poppy
Erik
WhiteYoshiEgg
Minimay
Carol
ShUriK Kid
AxemJinx
Lui
Ladida
wiiqwertyuiop
Maxx
MarioE
HammerBrother
imamelia
KevinM
Isikoro
ShUriK KiD
AxemJinxs
Chdata
Fakescaper
Roy
Blind Devil
MarkAlarm
smkdan
Telinc1
Francium
--------------------------------------------
Sprites:
1524
RussianMan
imamelia
33953YoShI
Romi
HuFlungDu
Mikeyk
Mirumo
Akaginite
Koopster
Iceguy
Erik
Darolac
Telinc1
Kaijyuu
TheBiob
lx5
Ixtab
Sonikku
GreenHammerBro
BlindDevil
Davros
WhiteYoshiEgg
Mandew
Tattletale
kaizoman666
leod
smkdan
MarioFanGamer
EternityLarva
Djief
lion
Isikoro
Von Fahrenheit
RealLink
Schwa

-----------------------------------------------------
Blocks:
HammerBrother
Ersanio
Iceguy
JackTheSpades
cthulhu
EternityLarva
Davros
mikeyk
Darolac
Meirdent
Bandicoot
MS
--------------------------------
Tools:
Fusoya
Alcaro
Kipernal
TheBiob
P4plus2
Atari2.0
JackTheSpades
Vitor Vilela
dtothefourth
Tattletale
-------------------------------------

