				================
				 VIP 3 - Fixed
				================

				  Fix Update 1

			      ====================
			       Changelog of fixes
                              ====================

Fix Update 1 (22/02/2019)
	-Updated the readme and some patch descriptions to not go offscreen with how long the sentences
	 are horizontally, to improve readability.

	-Updated some of our custom sound engine code to eliminate a slight audio delay that happens when
	 changing music tracks mid-gameplay (i.e. when switching to death music, P-switch music, etc.).

		English version specific:

	-Added a missing translation in one of the ExGFX files.

First Version (27/10/2018)
	-Initial release

				 ==============
				 About the hack
				 ==============

VIP 3 is an SMW hack released around 2007, made by a collection of members of the VIP board
on the 2ch message boards.
It has 100 exits (plus the final level), and was originally released in Japanese.

This hack is one of the very first (if not the actual first) to include custom music, which
makes this one of the first hacks made to break on actual hardware. Its method of loading the
custom music is extremely primitive (it literally just loads all of the custom level music in
one go at start up), and as a result fixing it required a bit more specific hacking into the
music engine than usual to make it work.

A specific list of fixes made can be found later in this document.

				==================
				About this release
				==================

For this release, we've both fixed the compatibility issues and done a full translation of the
in-game text and any graphical assets containing such. The ZIP file contains two BPS patches;
one is for the original Japanese version, and the other contains the localized English version.
Both of these have their technical issues fixed (to the extent that we know about them anyway).

Additionally, there are some optional ASM patches included in the ZIP that you can apply.
Some of these might pertain to hardware accuracy aspects, so make sure to take a look in the
"About the ASM patches" section of this document.
We've tried to set it up so applying the patches is really simple, as long as you know basic
OS stuff like how to move files to another directory, open a file in Notepad, and run an executable.

			      =====================
			      About the ASM patches
			      =====================

Once the BPS patch of your choice has been applied, the resulting ROM should be ready
to play on most hardware and software capable of running SNES games without further
modification.

However, there are some more options in the form of ASM patches that you might be interested in.
In this hack's case, we've included patches for the following:

	Fixes:
	- A crash due to one custom block's botched coding.
	- A level that was originally impossible to clear legit due to botched insertion
	  into the original collab.
	- A vanilla crash that happens when collecting a feather offscreen during an autoscroll.

	Misc:
	- FastROM
	- Translator notes explaining some of the cultural references (English version only).
	- Dragon Coin indicators on the overworld.
	- NMI optimization that reduces scanline flickering at the top of the screen on some levels.

We have tried making the process of applying these patches as simple as possible, so
even if you've never done anything with ASM before it shouldn't take longer than a
few minutes to find out what they all do and to actually apply the ones you want.

The process uses a program called "Asar" by Alcaro (and others), which is not our work, but a
cut-down copy of which (only including the .exe and license information) is supplied inside
this zip file for the sake of ease of use.
The full program can normally be found at these addresses:
https://www.smwcentral.net/?p=section&a=details&id=14560
https://github.com/RPGHacker/asar

Below is a step-by-step guide to learning what all the ASM patches do, and how to apply them.

1. Prepare the ROM by applying either of the BPS files to a clean, headered USA version ROM of
	Super Mario World, and placing it into the 'asar161' folder.

2. Go to the 'asar161' folder, and open '@main.asm' in a text editor of your choice (Notepad will work).

(You can skip step 3 and step 4 if you want all of the patches possible.)

	3. Read the explanations about each patch inside this file to decide which patches you
		want applied to the ROM, and follow the instructions.

	4. Make sure '@main.asm' has been saved with any edits you made.
		(Take care in step 6 if you rename this file.)

5. Run 'asar.exe'.

6. When asked for the patch name, enter "@main" (without quotes) or whatever
	else you have renamed it to.

7. When asked for the ROM name, enter the file name of the ROM that you put in the same folder
	in step 1, with or without file extension.

And now if nothing has gone wrong (it shouldn't), you will get a list of the patches that have
been applied, and a message saying that the patch has been applied successfully.
The ROM is now ready to be played.

			  ======================================
			  Compatibility problems that were fixed
			  ======================================

	- Crashes on accurate emulators and real SNES console due to the use of a primitive AddMusic tool.
	- Robotic noises due to SMW's music engine reloading wrong instrument data after sound effect
	  finishes playing on a channel that is doing percussion.
	- Bugged sprites due to the use of old SpriteTool (which makes incorrect assumptions about the state of RAM).
	- Custom code that makes incorrect use of SNES multiplication and division registers.

					=======
					Credits
					=======

This is a list of all the people whose software/patches we've used or adapted on this hack,
or included as options in the ZIP file.

Asar 				- Alcaro et al
Recover Lunar Magic 		- Parasyte
Overworld Counters 		- Ladida
SRAM Expand 			- Deflaktor
Extended Overworld Level Names 	- Smallhacker
Extreme FastROM 		- Ersanio
Fixed Color Data NMI Optimizer 	- Ladida
Feather Autoscroll Freeze Fix 	- Romi
Translator Notes patch 		- Super Maks 64
Message Box Chaining patch 	- Super Maks 64

Translation, music fixing, and additional ASM by This Eye o' Mine
Proofreading and testing by Ryrir
Additional research and proofreading by lion

Besides that, we'd like to acknowledge Horikawa Otane, who made a translation for this hack a few years ago.
We retranslated this because that translation has not aged very well, something she has agreed with us on.
We hope this translation will be a suitable replacement.

And of course thanks to the VIPPERs who made the hack in the first place.

Sorry to any people we might've missed.

- The Hack Fix/Translation team
