==================
VIP 1 - Translated
==================

==============
About the hack
==============

VIP 1 is an SMW hack released around 2005, made by a collection of members of the VIP board on the 2ch message boards.
It has 78 exits (plus the final level), and was originally released in Japanese.

Unlike many hacks we've been fixing up, this one has pretty much nothing preventing it from running on modern emulators or real hardware. It's about as vanilla as they come. There are no custom sprites (although the graphics are obviously swapped), and custom music was not a thing yet in 2005, so not much that can go wrong on that front. Japanese version is still included in this package due to some minute changes that needed to be made to prepare it for some of the ASM patches.

==============
About our work
==============

We are concerned with preserving the playability and accessibility of old Super Mario World ROM hacks, and we try to achieve this by translating Japanese hacks, and fixing old hacks that have compatibility problems with newer emulators and real SNES hardware due to the assumptions about emulator behavior made by those who coded hacking tools back when ZSNES was the standard emulator. None of the hacks that we fix/translate were originally made by us. All credit for the original design and content goes to the hacks' respective authors, and the creators of whatever tools and/or resources they used. Where possible we will link to the place where the original hack can be found, and we hope that through our efforts the author's work can live on.

In our fixes of old hacks, we try as much as possible to preserve the way the original hack worked internally. For instance, hacks that used a custom music loading engine have not had this engine replaced, but simply had their assets edited so that they're no longer loaded in such a way that crashes the SNES, and had the N-SPC music engine that SMW uses patched to eliminate a couple of other sound bugs arising from the assumptions about ZSNES' sloppy emulation. The result is that the hack will pretty much work and sound exactly as it would on ZSNES (minus ZSNES' terrible sound quality), and in some areas the music might incidentally even be a bit less glitchy than it used to be.

Note however that as a rule we are not concerned with making the hack's game design 'better' or otherwise fixing bugs that would've been present when playing the original hack on ZSNES. Some of the ASM patches included as options might perform this task to some extent where we thought people might enjoy or appreciate it, but the base BPS patch only fixes stuff that would (or might) have broken gameplay due to hardware or emulator assumptions. The contents of the ASM patches are basically up to our whims, so we're not really open to suggestions. If you want to write your own and share them, we're not stopping you of course!

==================
About this release
==================

For this release, we've done a full translation of the in-game text and any graphical assets containing such. The ZIP file contains two BPS patches; one is for the original Japanese version, and the other contains the localized English version. Although in this case there were no technical issues to begin with, we've at least tested it on BSNES and ensured that this hack will run as intended on accurate emulators (and probably real hardware).

Additionally, there are some optional ASM patches included in the ZIP that you can apply for options like for example FastROM. We've tried to set it up so applying the patches is really simple, as long as you know basic OS stuff like how to move files to another directory, open a file in Notepad, and run an executable.

We don't mind if you want to redistribute this (I mean who are we to talk), but we recommend that you redistribute the entire ZIP file for the sake of anybody that might want the extra ASM patches.

=====================
About the ASM patches
=====================

Once the BPS patch of your choice has been applied, the resulting ROM will be ready to play on any hardware or software capable of running SNES games. It will be as authentic as possible to the original hack, with only data and code that might have caused a compatiblity issue on accurate emulators and real consoles changed to work as intended. Obviously, the English version will also have some more edits done for language reasons.

However, there are some more options in the form of ASM patches that you might be interested in.
For example, there's a FastROM patch that reduces lag, as well as some that provide other extra features.
Please read further to decide whether any of look appealing to you.

We have tried making the process of applying these patches as simple as possible, so even if you've never done anything with ASM before it shouldn't take longer than a few minutes to find out what they all do and to actually apply all the ones you want.

The process uses a program called "Asar" by Alcaro, which is not our work, but a copy of which is supplied inside this zip file for the sake of ease of use.
The program can normally be found at these addresses:
https://www.smwcentral.net/?p=section&a=details&id=14560
https://github.com/RPGHacker/asar
Please look in one of these places for assistance with any technical issues you might have with this program.

Below is a step-by-step guide to learning what all the ASM patches do, and how to apply them.

1. Prepare the ROM by applying either of the BPS files to a clean, headered USA version ROM of Super Mario World,
	and placing it into the 'asar150' folder.

2. Move all of the files found in the 'asm_patches' folder over to the 'asar150' folder.
	(Make sure these files and the ROM are all in the same folder as 'asar.exe')

3. Open 'main.asm' in a text editor of your choice (Notepad will work).

4. Read the explanations about each patch inside this file to decide which patches you want applied to the ROM, and follow the instructions.
	(You can skip step 4 and step 5 if you want all of the patches.)

5. Make sure 'main.asm' has been saved with any edits you made.
	(Don't rename it.)

6. Run 'asar.exe'.

7. When asked for the patch name, enter "main" (without quotes).

8. When asked for ROM name, enter the file name of the ROM that you put in the same folder in step 1, with or without file extension.
	(So if you named the rom "test.smc" you can enter either "test" or "test.smc".)

And now if nothing has gone wrong (it shouldn't), you will get a list of the patches that have been applied,
and a message saying that the patch has been applied successfully. The ROM is now ready to be played.

=======
Credits
=======

This is a list of all the people whose software/patches we've used or adapted on this hack, or included as options in the ZIP file.

Asar - Alcaro et al
Recover Lunar Magic - Parasyte
	(Updated version by This Eye o' Mine)
Overworld Counters - Ladida
SRAM Expand - Deflaktor
Extended Overworld Level Names - Smallhacker
Extreme FastROM - Ersanio
Fixed Color Data NMI Optimizer - Ladida
Yoshi Coin Fix patch - imamalia
Translator Notes patch - Super Maks 64
Message Box Chaining patch - Super Maks 64

Thanks also to lion for providing some assistance near the end of this project with researching some VIP-related things, and giving some feedback on the translation.

Besides that, we'd like to acknowledge Horikawa Otane, who made a translation for this hack a few years ago.
We retranslated this because that translation has not aged very well, something she has agreed with us on.
We hope this translation will be a suitable replacement.

And of course thanks to the VIPPERs who made the hack in the first place.
Original hack can be found at: https://www18.atwiki.jp/sm4wiki_mix

Sorry to any people we might've missed.

- Ryrir, Super Maks 64, and This Eye o' Mine
