				=================
				  VIP 4 - Fixed
				=================

  				  Fix Update 1

			      ====================
			       Changelog of fixes
                              ====================

Fix Update 1 (18/07/2019)
	-Fixed a patch conflict that would cause the Yoshi Coin fix patch
	 to crash the game. (Thanks to Shiny Ninetales for letting me know)

First Version (11/07/2019)
	-Initial release

				 ==============
				 About the hack
				 ==============

VIP 4 (also known as MIX 4) is an SMW hack released around 2008, made by
users on the Japanese VIP forum. It was originally released in Japanese,
and is quite large, sporting 114 exits. It is the fourth entry in the
VIP/MIX hack series.

As per usual for the series, the hack was released in two versions, one of
which featured normal SMW GFX, and the other of which featured custom graphics
for all of the characters and enemies based on memes that originated on the
Japanese collection of message boards known as '2ch'.

				==================
				About this release
				==================

First of all, we were not involved in and take no credit for the development of
the hack itself. We merely did the fixes and translation described below.

This release is based on the custom GFX version of the hack. Furthermore, it
is based on version 1.15, which should be the latest version. This zip file
contains both a fully-translated English version and a Japanese version.
Emulator and console compatibility problems that were present have been fixed
in both of these. Additionally, there are some ASM patches included for
extra features and bug fixes beyond those caused by platform incompatibilty.
Read the next section for a list of these and instructions on how to apply them.

			      =====================
			      About the ASM patches
			      =====================

Once the BPS patch of your choice has been applied, the resulting ROM should be ready
to play on most hardware and software capable of running SNES games without further
modification.

However, there are some more options in the form of ASM patches that you might be interested in.
In this hack's case, we've included patches for the following:

	- Translator notes on the overworld in the English version which explain some of
	  the cultural references made in the game's text.
	- Bug fix for a Dragon Coin glitching out due to being placed on a subscreen boundary.
	- Bug fix for a message box which pops up where it's not supposed to, which contains
	  a story spoiler.
	- FastROM patch which eliminates most of the lag that's rampant throughout the hack.

We have tried making the process of applying these patches as simple as possible, so
even if you've never done anything with ASM before it shouldn't take longer than a
few minutes to find out what they all do and to actually apply the ones you want.

The process uses a program called "Asar" by Alcaro (and others), which is not our work, but a
cut-down copy of which (only including the .exe and license information) is supplied inside
this zip file for the sake of ease of use.
The full program can normally be found at these addresses:
https://www.smwcentral.net/?p=section&a=details&id=14560
https://github.com/RPGHacker/asar

Below is a step-by-step guide to learning what all the ASM patches do, and how to apply them.

1. Prepare the ROM by applying either of the BPS files to a clean, headered USA version ROM of
	Super Mario World, and placing it into the 'asm_patches' folder.

2. Go to the 'asm_patches' folder, and open '@main.asm' in a text editor of your choice (Notepad will work).

(You can skip step 3 and step 4 if you want all of the patches.)

	3. Read the explanations about each patch inside this file to decide which patches you
		want applied to the ROM, and follow the instructions.

	4. Make sure '@main.asm' has been saved with any edits you made.
		(Take care in step 6 if you rename this file.)

5. Run 'asar.exe'.

6. When asked for the patch name, enter "@main" (without quotes) or whatever
	else you have renamed it to.

7. When asked for the ROM name, enter the file name of the ROM that you put in the same folder
	in step 1, with or without file extension.
	(Warning: if you don't include the file extension, make sure the .bps file of the
	 same name is not in the asm_patches folder, or else asar will try applying the ASM
	 patch to that file instead, which will naturally fail.)

And now if nothing has gone wrong (it shouldn't), you will get a list of the patches that have
been applied, and a message saying that the patch has been applied successfully.
The ROM is now ready to be played.

			  ======================================
			  Compatibility problems that were fixed
			  ======================================

	- Custom code that makes incorrect use of SNES multiplication and division registers.

	- Crashes related to the use of an old AddMusic tool made by carol which uploads
	  music data into a section of Audio RAM which gets overwritten by echo data.

	- Similar crashes due to songs setting too high an echo delay setting, which causes
	  echo data to overwrite the sample data.

	- Stuttering audio caused by residual audio data getting continually replayed when
	  echo delay is set to 0, but echo playback is not turned off.

	- Robotic sounds in the music in one particular level due to a bug in the vanilla
	  sound engine that causes the wrong instrument data to get loaded whenever a sound
	  effect interrupts a music channel that is playing percussion.

	- Removed unused ExAnim data in one level responsible for overburdening the NMI
	  routine and sometimes causing graphical glitches during the victory walk iris out.

	- Various palette and graphics issues that occured during the final boss on BSNES and
	  real hardware, due to data getting uploaded to VRAM and CGRAM outside of v-blank.

	- A flash that occurs sometimes when level loading starts, due to the background
	  palette data not getting updated quickly enough.

	- Custom sprites glitching out due to incorrect assumptions about the initial state
	  of values in RAM by old SpriteTool.

					=======
					Credits
					=======

This is a list of all the people whose software/patches/work we've used or adapted on this hack:

Asar 					- Alcaro et al
Recover Lunar Magic 			- Parasyte
Extended Overworld Level Names		- Smallhacker
Fixed Color Data NMI Optimizer 		- Ladida
Lunar Magic				- FuSoYa

ASM for translator notes, message box chaining, level load flash fix by Super Maks 64.
Translation, compatibility/bug fixes, and additional ASM by This Eye o' Mine.
	Based on initial translation textfile made by lion in 2018.
Additional research and translation by lion.
Proofreading and testing by SimFan96 and Ryrir.

Additional thanks to those who gave feedback when raocow LPed the prototype version of this
fix/translation in 2018.

And of course thanks to Vippers, who made the hack in the first place.

Our apologies to any people we might've missed.

- The Hack Fix/Translation team