			       ==================
		               VIP6 English Patch
			       ==================

			      ====================
			       Changelog of fixes
                              ====================

First Version 	(01/05/2020)
	-Initial release
Update 1 	(02/05/2020)
	-Added fallback option for patching in case the batch file fails.
	 (No actual changes to the hack)

				 ==============
				 About the hack
				 ==============

VIP6 is a Japanese romhack made by the VIP community, and has not actually been finished yet.
It's been in development since 2012, and has had its last demo update in 2017.
As far as completion goes, the entire hack is more or less complete and playable, except
for the boss of the special world, which just doesn't exist yet.
It's a rather large hack as you would expect from the series, with 98 exits.

				 ================
				 About this patch
				 ================

First of all, we were not involved in and take no credit for the development of
the hack itself. We merely did the fixes and translation described below.

This patch was designed for the demo version of VIP6 released on the 5th of September 2017,
which is the latest version as of this writing.
It may work on versions released before or after that date, but this has not been tested.
If a final version is ever released, we will strive to make sure this patch is up to date.

Out of respect for the hack not having actually been released fully yet,  what is
included here is not a BPS, but merely a series of ASM patches to patch the hack into English,
one patch to fix some minor hardware compatibility issues, and an optional patch to include 
translation notes. Also included is the patching utility "Asar", and a batch file to make
application easy.

Read the included "installation_instructions.txt" for a short guide on how to apply.


			  ======================================
			  Compatibility problems that were fixed
			  ======================================

	- Incorrect use of multiplication and division hardware resulting in incorrect
          results, causing minor graphical glitches in some custom sprites.

					=======
					Credits
					=======

This is a list of all the people whose software/patches/work we've used or adapted on this hack:

Asar 					- Alcaro et al
Lunar Magic				- FuSoYa
Extended Overworld Level Names 		- Smallhacker

Groundwork translation and research by lion.
ASM for message box and cutscene chaining by Super Maks 64.
Translation, compatibility/bug fixes, and additional ASM by This Eye o' Mine.
Proofreading by Ryrir, lion, and Zeal
Translation assistance by Zeal.
Testing by Ryrir, lion, and Super Maks 64.

And of course thanks to the VIP community, who made the hack in the first place.

Our apologies to any people we might've missed.

- The Hack Fix/Translation team