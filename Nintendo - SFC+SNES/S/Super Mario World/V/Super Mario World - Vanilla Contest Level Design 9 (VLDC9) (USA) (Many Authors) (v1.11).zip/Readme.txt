____   ____.____     ________  _________  ________ 
\   \ /   /|    |    \______ \ \_   ___ \/   __   \
 \   Y   / |    |     |    |  \/    \  \/\____    /
  \     /  |    |___  |    `   \     \____  /    / 
   \___/   |_______ \/_______  /\______  / /____/  
                   \/        \/        \/          

Thank you for downloading the 9th Annual VLDC collaboration hack!
A little advice upfront, this hack uses a 6MB ROM, as such, some emulators like older version of snes9x might not be able to handle it. While ZSNES can handle the ROM itself, due to the use of the SA-1 chip, it might glitch or crash on random section, so we'd advice against using it.

================================
Supporting Emulators
================================
	snes9x 1.54
	zmz
	zsnes (with risk of sa-1 acting out I guess)
	bsnes 0.73
	higan 1.01 (with ocasional minor graphical glitches)


================================
A brief summary from Jack
================================

Vanilla refers to the fact that the level was made with only Lunar Magic (the SMW editing tool) and no custom code beyond that. Over the years, we've started allowing some additional things like slight graphics manipulation (overlapping, recoloring, rotating 90�) and custom music to be added.
Additionally, we've applied some custom code to fix stuff that couldn't occur in the original game (like dying in a level with 0 seconds on the timer)

Like we did the past 2 years, all the levels have been combined into one gigantic hack. This year, however, is a first, as it�s the first time EVER that we�ve had more levels than what SMW can originally handle. That is to say, more than 96 levels. In total, this hack contains 108 levels that were submitted as part of the contest and additional staff, judge and postgame content for a total of 117 levels and 152 exits.

From the first planning discussions to the finished hack it took as 1 year to put everything together and I�d like to thank everyone who put time and effort into this to finish a hack of that size in such a short amount of time.
The hack features a post-game content that can be unlocked after all exits have been gotten. The Yoshi coins are not required for this. How to unlock the post-game content? Well� I�m sure you�ll figure it out ;)

With that, thanks again for downloading and have fun playing with best regards from JackTheSpades and all of SMWCentral.net who helped to put this amazing hack together.

================================
Version History
================================

V1.10 - First official release
v1.11 - Fixed palette in Divemissil's level
        Fixed yellow level dot for Simple Patch
        Remove exit enabled pipe in LucasRCD's level
	Various stuff in SomeGuy712x's level
	Removed time limit from switch palaces.
	Removed F*** You from Streamside (because we can't have profanity
		like that on an (illegal) ROM hack on the interenet in 2016)
	Changed some names in the credits
	Fix walking on OW after beating S.N.N.'s level
	Small changes to the haunted OW map.
	Fixed 3rd save slot.

	