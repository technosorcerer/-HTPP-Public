Hello! Thank you for downloading the demo for my SMW Hack "LUOGI HACK".

This demo has 12 levels and 3 secret exits and encapsulates the entirety of World 1 and a few levels leading into World 2.
The Hack features a lot of custom graphics, most of which were done by myself. If you would like to use any assets from
this in your work you are free and even encouraged to do so! This hack is not locked and can be edited with Lunar Magic.
Just please don't claim my work as your own and give credit (and maybe let me know!) when you use my assets.

With this hack I am trying to do a sort of celebration of Super Mario World hacking throughout the years. I wanted to pay
homage to older resources that have appeared in many hacks and use them in new, modern levels. With this project I want
to prioritize unique and interesting ideas over trying to improve on things that have been done before.
The beginning of the hack, and this demo, are moderately tame in comparison to the ideas I have for later parts of the game,
but there are many secrets in every corner of a level so it is greatly encouraged to explore as much as you can.

The recommended emulator for this hack is Snes9x 1.60 or 1.61. A handful of people have seen some visual bugs on other
versions or different emulators.

If you have any questions or want to give feedback you can reach me on Twitter and Discord as [dertob_]

Thank you again for checking out my hack! I hope you enjoy it!!
	Tob

- - - - - - - - - -

Credits:

	Custom Sprites
		K3fka, Luks, MarioFanGamer, imamelia, Koopster, Erik,
		RussianMan, linkunarre, smkdan, Isikoro, Major Flare,
		Tattletale, Daizo Dee Von, edit1754
	
	Custom Blocks
		Davros, ASMagician Maks, Sonikku, mikeyk,
		HammerBrother, MarioFanGamer, K3fka, Tob
	
	Other ASM
		K3fka, Luks, Francium, MarioFanGamer, Alcaro,
		Kevin, Thomas, wye, carol, Katrina, Tob
	
	Custom Music
		Hooded Edge, MercuryPenny, imamelia, icrawfish,
		Gamma V, JX444444, FPI, Pinci, ThinkOneMoreTime,
		KungFuFurby, Ahrion, Ladiesman217, Samantha,
		Nanako, nobody, musicalman, Kevin, Tob
	
	Custom Graphics
		idol, Alessio, ECS.98, Tob
	
	Concept, Leveldesign, Overworld (everything else, basically)
		Tob
	
	Special Thanks to my friends and playtesters!
		Luks, K3fka, Mauls, Domiok, Eevee, Magi
		bebn legg, LunaStela64, meatloaf