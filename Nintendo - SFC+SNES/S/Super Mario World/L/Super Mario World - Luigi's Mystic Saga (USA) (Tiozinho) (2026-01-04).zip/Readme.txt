[Português]
Descrição: Esta é a versão 1.4 do Luigi's Mystic Saga, uma atualização focada em modernização, correção de erros e melhorias visuais para garantir a melhor experiência possível nos padrões atuais de ROM Hacking.

Novidades da Versão 1.4:

- Correção ortográfica da caixa de mensagens do Stage 2-Castelo (Na versão PT-BR)

- Novas paletas de cores nos Switches Palaces

- Adição de caixa de mensagem no Stage 1-5


AVISO: Esse hack não funcionará corretamente no ZSNES. Para uma melhor experiência, recomendamos que você use o Snes9x ou o bsnes!


[English]

Description: This is version 1.4 of Luigi's Mystic Saga, an update focused on modernization, bug fixes, and visual enhancements to ensure the best possible experience by today's ROM hacking standards.

What's New in Version 1.4:

- Spelling correction of the Stage 2-Castelo message box (In the PT-BR version)

- New color palettes in Switch Palaces

- Added message box in Stage 1-5

WARNING: This hack will not function correctly on the ZSNES emulator. For the best experience, we strongly recommend using Snes9x or bsnes!