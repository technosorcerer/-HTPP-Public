Le plume is my attempt at creating an approachable cape-focused kaizo hack. My goal was to provide a welcoming entry point for players interested in cape mechanics, offering short and relatively straightforward setups to help build confidence for tackling more advanced cape challenges next. While not a beginner-friendly hack per se, most sections are brief, and the required techniques generally fall short of expert-level difficulty. Turnarounds are patched, as they often present a significant hurdle for newcomers. I hope this hack helps you discover cape in a new light and inspires you to explore this fantastic power-up further.

Le plume features 12 levels with a gradual increase in difficulty. Each of the first 11 levels contains a unique custom moon. Collecting all of them unlocks the 12th and final level. For those new to cape, I recommend revisiting moons that seem out of reach during your first playthrough, as they often pose an extra challenge. If you go that route, don’t forget to hit SELECT on the overworld—your moons won’t save themselves!

I highly encourage players to learn or review basic cape techniques through the excellent hack Learning to Fly by DJ Locks and NewPointless. While some hints are provided via message boxes, this is not a tutorial hack, and players with less cape knowledge may find some setups a bit obtuse. Expect to encounter a variety of mechanics, from speed control to item flight, sticky ceilings, and more. 

Learning Lunar Magic has been a humbling journey, and this hack wouldn’t exist without the help of many generous humans. I am extremely thankful for all the support, in its many forms, that I’ve received over the past months—if not the past years! Above all, I want to highlight the contributions of Drkrdnk for the overworld, FiveFactor for the level Duck hunt, and iamtheratio, whose initial push made the level Fly hard possible. The friendly moon has been coded by bucketofwetsocks and a special thank you to deported and pixelninetales for their patience and generosity in sharing their vast knowledge.

Have fun and remember: it's not a competition, it's a celebration.

1.1 Notes

    Fixed some tile cutoffs, graphics issues, and other small annoyances.

    Increased the moon’s horizontal speed to prevent it from endlessly orbiting the player after finishing a level.

    Watch your hands: Getting to the moon no longer requires replaying the entire section.

    Moonwalk: The final level has been nerfed to better reflect the original intent of the hack.

    Save files from version 1.0 will carry over to 1.1 as long as the filenames are the same.

    For cape nerds: A vanilla turnaround version is available in my file bin (La plume).