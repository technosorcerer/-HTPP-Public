
This is a level I made back in 2015-2016 then more or less abandoned until I went back and added an ending to it in 2023.

It's a fairly long glitch-puzzle level over multiple rooms and iterations. It being a hack I made in 2015/6 also means the level was made without a lot of glitches that are now more well-known in mind.
While I did try my best to breakproof the most important things and make the intended solution feel intended, it is still most likely possible to sequence break some of it. I do encourage you to try and find the intended solutions however.

Here is a non-exhaustive list of glitches that definitely are not intended but are also generally not fixed:
 - Remote controlled on/off switches (kind of on thin ice with one intended trick but generally, do not delay activating on/off switches from afar by scrolling items into it)
 - Walljumps/corner clips/yoshi elevator/etc
 - Yoshi tongue offscreen shenanigans
 - Spawn index transferral
 - Duplicating blocks from a distance
 - Duplicating shells by offscreening them on Yoshis tongue
 - Fish item swaps (or any kind of offscreen item-swap)

Looping sprites might be intended if the room has no time limit. In those cases, this version adds asm that will shorten the amount of time required to loop a sprite drastically.

Special Thanks to xHF01x and dacin for testing this and always giving me more breaks to fix :)
