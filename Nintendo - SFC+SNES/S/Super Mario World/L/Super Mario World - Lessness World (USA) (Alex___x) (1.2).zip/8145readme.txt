Here's some disclaimers and clarifications for the 1.2 version of Lessness World. 



- Motor skills patch:
The patch applied to the game doesn't allows to the player to switch jumps while you're carrying an item. This issue doesn't affect the gameplay since in the levels you don't need to do this movement. 

- Motor skills mixed with Walljumps patch:
This mixture of patches doesn't allow you to switch jumps after you did a walljump. For example you did a wall spinjump, so you'll can't switch to a regular jump. This issue doesn't affect the gameplay because the level in which this mixture is applied doesn't require to switch jumps after a walljump. 

- Spawn throw-blocks patch:
This patch is already fixed for the 1.2, and now the throw-block spawns correctly when you press L/R (in the 1.1 sometimes throw-block spawns offscren). Despite this, it is recommendable to keep pressing Y while you spawn a throw-block. 

- Start + select issue:
There's an issue in which you can start+select some levels, and you inmediately re-start the same level but without music (because of "no overworld" patch). Music is back after you have beat the affected level, or also you can reset the game to fix it. This issue doesn't affect the gameplay.  



If you notice something that affects the gameplay, please let me know through DM on discord (Alex___x), or whisper me on Twitch (twitch.tv/Alex_________x)


