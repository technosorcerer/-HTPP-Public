The Lost Levels Enhanced by Pac - version 1.1

First released: 3rd November 2005
Last updated: 1st February 2012



------Instructions------
You will need:

1. An unmodified Super Mario World (U) ROM - you can find one on Google.
2. An IPS/BPS patcher - I recommend Floating IPS: https://www.romhacking.net/utilities/1040/
3. SNES Emulator - I recommend Snes9x: https://www.emulator-zone.com/snes/

Once you have all of the above:

1. Open your IPS/BPS patcher, and click on Apply Patch.
2. Select the .ips or .bps file included in this download.
3. Select the unmodified SMW ROM, and the hack will be generated.
4. Open the SNES emulator, and load the ROM.
5. Play!



------Usage------
Feel free to use anything you want from this hack for your own project, or to use it as a base. No credit needed.



------See also------
The companion hack to this: Super Mario Bros. Enhanced