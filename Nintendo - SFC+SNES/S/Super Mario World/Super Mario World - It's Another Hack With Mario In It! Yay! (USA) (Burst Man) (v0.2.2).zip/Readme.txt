5/29/2025 UPDATE:

Apparently, there was this unreleased Demo 2 update sitting in one of my folders for over a decade, and since I can't take this demo's entry down from the hacks section, might as well fix it. It was originally dated March 25, 2013, but it may be even older than that. This update was polished further and testedin order to make sure it can be played from start to end without crashing bsnes.

Version 0.2.2 fixes cutoff in many stages and a few broken overworld paths (including the secret exit in Spiny Woods, most infamously), tweaks several levels to be less difficult or annoying, and addresses the garbled graphics that sometimes flashed on screen when you scrolled the screen vertically and the weird sound issues. It now uses the same version formatting as the final versions. Since I didn't keep backups of my resources from back then, some issues cannot be addressed without redoing the whole demo from the ground up.

Outside of the changes listed above this update aims to make minimal changes to the original Demo 2, featuring the 2011 iterations of worlds 1 to 4 as well as the original overworld. Even though these levels are largely the same as the final versions, the pre-Gemstone Islands demos feel distinct enough to coexist without much of an overlap; at the very least, a relic of simpler, worse designed times.

On that note, I'd like to remind you that Adventure in Gemstone Islands is already out. Please play that instead if you want to experience the full game. v2.00 should be uploaded to SMW Central within a couple weeks as of this writing.

-------------------------------------------------------------------------------------------------------

              -=="It's Another Hack with Mario in it! Yay!" Demo v0.2.2=-

=DESCRIPTION=

Help Mario jump over Koopas and stuff! Oh, and save some Yoshi eggs too.
This is my first ROM hack, so don't expect a masterpiece, but not a half-baked job either.
This demo contains the first four worlds (out of eight planned), and 41 available exits.

This update fixes the cutoff in the level Seaside Hijinx and the Blue Switch Palace is now available to play. In addition, it features the final versions of Seaside Hijinx, Emerald Castle and Amethyst Grotto!

If you have anything to tell me about my hack, tell it in a review or just PM me (User ID 5029). Criticism, suggestions and bug reports are welcome. This hack has been tested on BSNES successfully.


=CREDITS=

In no particular order:
MidiGuy, Supertails, MadMikeXP, Kyoseron, Slash Man, Jimmy52905, gpetry, Scratch799, mario90, SNN, SuperLuigiBros, Noobish Noobsicle, ghettoyouth, Ersanio, Fakescaper, purplebridge001, Fuzzyfreak, Ultimaximus, BMF54123, Mattrizzle, mikeyk, Edit1754, MrCheeze, aiyo, Bad luck man, ICB, Atma, Tornado, Buster Beetle, Nipcen, mariondoe, ThinkOneMoreTime, Lucas, LogoFan121092, and anyone else I might've forgotten (if you happen to find something you made in this hack that I didn't give you credit for, let me know).

=VERSION HISTORY=

· v0.2.0 (1-8-2011): Second demo released.

> NEW TO THIS DEMO:
- Two new worlds now available to play: Emerald Forest and Amethyst Cavern.
- SMB3 P Meter implemented.
- Added custom palletes to the majority of the levels available in Demo 1. Most stages from now on will have custom palletes.
- New music added for ghost houses and pitch-dark caverns.
- Added sound to the fire-spitting Jumping Piranha Plant.
- New graphics for castle lava, "1UP" sign, mushrooms and fire flowers.
- Coins from blocks no longer give points.
- The hack now allows for 3 saved games like the original SMW.
- You lose Yoshi upon completing a stage with it now.
- Ghost house and castle entrances have been removed.

> CHANGES TO EXISTING LEVELS FROM DEMO 1:
- You start directly in "Peaceful Island" instead of "Yoshi's New House". The latter cannot be accessed anymore.
- Minor adjustments to the overworld. It is still a placeholder, but it should feel less empty than the first one.
- Added a new background for Peaceful Isle stages.
- Some coins near the slanted pipe removed in "Peaceful Isle". Removed 3UP moon.
- "Not so Peaceful..." renamed to "Greener Pastures".
- The entrance pipe to the secret area in "Peaceful Cavern" was switched, and added more enemies to the stage. Coins in the secret area changed to be less misleading.
- "Peaceful Chasm" renamed to "The Cliff". The last part of the stage was completely changed.
- "Peaceful Secret" renamed to "Crystal Lagoon". Some line-guided platforms were changed. Secret area was modified.
- Minor adjustements to "Monty Island", mostly to remove some cutoff.
- The second world renamed from "Kaliri Island" to "Topaz Island". All the stage names were changed accordingly, except "Kaliri Grasslands" and "Kaliri Secret".
- The brick block lines near the middle of "Topaz Island" were moved where the second question block stairs used to be, and the multiple Fire Flowers were replaced by a single Multiple Coin block. Star remains in the same area.
- Question blocks no longer appear when the P Switch is pressed in "Yellow Switch Palace". A block of coins that used to appear near those blocks was removed as well.
- Fixed music in the second part of "Yellow Switch Palace".
- "Kaliri Grasslands" renamed to "Pokey Plateau". Line of Yellow Switch Blocks near the beginning of "Pokey Plateau" replaced by a single Superkoopa. Two Superkoopas next to the bonus stage pipe in "Pokey Plateau" no longer grant feathers when stomped. Added vertical movement to the secret area of "Pokey Plateau". End of the level expanded a bit.
- "Kaliri Secret" renamed to "Seaside Hijinx". Reworked several parts of "Seaside Hijinx", and a secret area implemented. The warp Star is non-functional though.
- Message box near the pipe in "Topaz Ghost House" removed.
- Fixed some minor cutoff in "Excavation Site". The coins above the last pit in "Excavation site" were moved up a bit to make them easier to grab.
- Most wooden blocks in "Topaz Bridge" were replaced by cement ones. Removed a coin that hinted to the secret vines in "Topaz Bridge" to make it a bit less obvious; removed the 1UP block from the same area. One of the chained platforms near the end of "Topaz Bridge" had its platforms reduced from 3 to 1.
- Modified the position of some switch blocks in the final part of "Topaz Castle".

· v0.1.0 (04-09-2011): First demo released.