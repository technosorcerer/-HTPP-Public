                                *------------------------------------------*
                                |                                          |
                                |   SUPER MARIO WORLD: THE 4 MAGIC WANDS   |
                                |                                          |
                                *------------------------------------------*
                                Version 1.0.2         Released on 15/02/2025

=====
ABOUT
=====
This is a hack I felt like working on after not working on one for a while.
In June 2024, my desktop computer started having crashing issues, and I eventually stopped using it altogether in October the same year, due to not being able to fix the crashes.
I was able to work on this hack by using this app called Winlator, which runs a Wine environment on an Android device. In the past, there was an app called ExaGear which could run LM on Android, nowadays, there are more similar apps that have the same purpose, such as Mobox, Horizon, Dark OS and some others, which all run Wine on Android. While most people use these apps to play PC/Windows games on their Android devices, I decided to use Winlator for a different purpose: making a SMW hack! And so, I then went to work on this hack. I decided to reuse the overworld map that was made for the 2019 OWDC contest. Some changes have been made from the original version of the map, like changing the level names, improving the beach in the grassland world, and fixing some event and path errors.

=============================
TOOL TEST ON WINLATOR RESULTS
=============================
If you want to try making a SMW hack through Winlator or another similar app, please read this to see which tools work and which don't. Only the ones used to make this hack will be here.

* Lunar Magic
  -Works fine, however tooltips (except for custom sprites, custom blocks and Map16 tiles on pages 80+) will not show any text. This will actually happen for all programs run on Wine.
* AddmusicK
  -Works fine (only command line version has been tested)
* Asar
  -Works fine.
* GPS
  -Works fine.
* PIXI
  -Works fine. There will be some squares in the text, but it's purely visual.
* UberASMTool
  -Works fine, however trying to add around 10 codes will make it crash mid-insertion with fatal error 0x80131506. There's no way to fix this if it happens.
* YY-CHR (C++ version)
  -Doesn't work, an error appears upon starting the program.
* YY-CHR (.NET version)
  -Works fine, however it tends to throw an unhandled exception error when hovering on buttons. You can still continue using it if clicking on Continue on the error.
* GradientTool
  -Same as YY-CHR.NET. If you're fast enough, you can turn on "Generate Initialization Code" without the error popping up. Formatting (line breaks and some spaces) will be lost when copy-pasting the code to Notepad, however, so you'll have to fix the file manually.
* Effect Tool
  -Seems to not work, the program doesn't open, yet no error message seems to show up. I asked Anas to make the underwater effect codes with it for me.
* SMW Status Bar Editor
  -Works fine. However, you can't press Page Up or Page Down in counter editing mode, as Wine doesn't have support for these two keyboard keys.
* SMW Misc. Text Editor
  -Works fine.
* Mario Start Editor
  -Works fine.

=======
HISTORY
=======
(All dates are in DD/MM/YYYY format)

* 11/01/2025: Work on the hack starts. The overworld map from my OWDC 2019 entry has been ported to a new SMW ROM, due to the original entry using an event debugger patch (specifically, the old menu-based patch made by Erik).
* 12/01/2025: The title screen is finished.
* 14/01/2025: World 1 (Iggy's Grassland) is finished.
* 15/01/2025: Work on world 2 (Morton's Forest) starts.
* 17/01/2025: World 2 (Morton's Forest) is finished.
* 19/01/2025: Work on world 3 (Lemmy's Snow Hill) started.
* 20/01/2025: World 3 (Lemmy's Snow Hill) is finished.
* 21/01/2025: Work on world 4 (Bowser's Cave) started.
* 23/01/2025: World 4 (Bowser's Cave) is finished.
* 24/01/2025: The remaining UberASM codes have been inserted to the hack.
* 27/01/2025: N450 tests the beta version of the hack.
* 29/01/2025: The hack is finished.
* 14/02/2025: The hack is released on the 2024 Winter C3 on SMW Central.
* 15/02/2025: Update 1.0.1 is released, later on the same day, update 1.0.2 is released.

==========
CHANGE LOG
==========
V1.0 (14/02/2025)
* Initial release.

V1.0.1 (15/02/2025)
* Removed invisible blocks near the second Yoshi Coin, as you could get stuck there if you had revealed the blocks, and don't have a cape if you went past the turn blocks to collect the coin if the blocks stop spinning.

V1.0.2 (15/02/2025)
* The pipes in sublevels with a key and a keyhole are now enterable, to reload the room,  in case you somehow lose the key.

=======
CREDITS
=======
Graphics:
---------
* AmperSam
  -Super Mario World - Midway & Castle Conveyor Stairs Fix
* Anorakun
  -Super Mario World - Castle Windows (Layer 2 (background) Conversion)
* Black Sabbath
  -Super Mario All-Stars: Super Mario Bros. 3 - Bowser's Castle
  -->Only the Bowser statue and the gray block have been used
* Dan
  -Super Mario's Wacky Worlds - Snow Koopas
* E-man38
  -Super Mario World - Foreground Trees
* Gamma V
  -Vanilla Styled Beach Expansion
  -Vanilla Styled Forest Expansion
  -Vanilla Styled Ice Expansion
  -Snow tree in the snow world, from her overworld graphics
* Green Jerry
  -Vine end tiles, wands in overworld border, coconut sprite in Iggy's Grassland 4
* Link901
  -Super Mario's Wacky Worlds - Snow Koopas
* mariomaker6
  -Cave
* Mogu94
  -Palm tree from SMAS: SMB3, used in the small beach section in the grassland world
* Moltz
  -Castle
* Natsuz2
  -Super Mario All-Stars: Super Mario Bros. 2 - Underground

Music:
------
* Aguiar Salsicha
  -John Charles Fiddy - Walking The Dog
* bebn legg
  -Kururin Paradise - Neo Land
* Counterfeit
  -Donkey Kong 64 - Crystal Caves
* Dark Mario Bros
  -New Super Mario Bros. U - Acorn Plains
* EDIT3333
  -Super Mario Bros. Wonder - Game Over
* Enderdavid_HD
  -Super Mario Bros. Wonder - Going Up!
* FPI
  -Super Mario Land 2: 6 Golden Coins - Tree Zone
* Gamma V
  -Sonic 3 & Knuckles - Mushroom Hill Zone Act 2
  -Super Mario Kart - Koopa Troopa Beach
  -M.C. Kids - Opening Cutscene/Character House
  -Wario Blast - Continue
* Goomba-24
  -New Super Mario Bros. Wii - Beach
* Green Jerry
  -Pokémon Gold/Silver/Crystal - Ruins of Alph / Union Cave
* HaruMKT
  -Super Mario Bros. Wonder - Underground
* Hiro
  -Super Bomberman 2 - BGM 3
* icrawfish
  -Live A Live - Silent Labyrinth
* imamelia
  -imamelia's Chocolate Level Design Contest 2009 - Earthy Caverns
* Isikoro
  -Super Mario 64 - Koopa's Road
* its_4life
  -Sonic the Hedgehog 3 - Credits
* JordanTRS
  -Sonic the Hedgehog 3 - Credits
* Kevin
  -Alcahest - Warrior's Fanfare
  -Donkey Kong Country - Bonus Win
* KlonoA13Phill
  -Lazy Town - We are Number One! (Super Mario World Stage Clear Remix)
* LadiesMan217
  -Super Mario Advance 4: Super Mario Bros. 3 - Koopaling Steals Wand
* MercuryPenny
  -Super Mario 64 - Correct Solution
* Milon Luxy
  -Tokimeki Memorial - Christmas Party
* Moose
  -Mushroom Kingdom Meltdown Reloaded - Cave
* Red Chameleon
  -SMW Central Production 2 - Tremble Amid the Trees
* RednGreen
  -SMW Central Production 2 - Watery Depths
* S.N.N.
  -Wario Land 3 - Boss
* Teows
  -Discord Ringtone
* Torchkas
  -SMW Central Production 2 - Tremble Amid the Trees
* Wyatt
  -Super Mario Galaxy 2 - Yoshi Star Galaxy
* Xulon
  -Chrono Trigger - Underground Sewer
  -Donkey Kong Country - Lost Life
  -Tokimeki Memorial - Ski Resort
* Wakana
  -Castlevania III: Dracula's Curse - Mad Forest
* worldpeace
  -Gradius Rebirth - Heavy Blow
* Zavok
  -Final Fantasy: Mystic Quest - Middle Tower

Patches:
--------
* adakkusu-san
  -Course Clear Modifier (Only in Portuguese version)
* Alcaro
  -Free up Tiles 69 and 83
  -Item Box Mushroom Priority Fix
  -ZSNES Incompatibility Notice
  -->It has been edited to be a warning screen that shows up on all emulators (not just on ZSNES), as well as real hardware, along with using Start instead of R to continue into the game.
* Chdata
  -Piranha Plant Patch Fix
* DiscoTheBat
  -No Title Screen Movement
* Erik
  -No Title Screen Movement
* HammerBrother
  -Death Animation Cancel Fix
  -Pit fix
  -Yoshi Keyhole Fix
* Kevin
  -Castle Intro Ledge Fix
  -Different Submap Switching Transition
* lolcats439
  -Block Duplication Fix
* MarioFanGamer
  -Better Powerdown
* Roy
  -Nintendo Presents Custom Palette
* RussianMan
  -1-Up Score Sprite on 100 Coins
  -Horizontal Pipe Exiting Sound Fix
* Smallhacker
  -Extended Level Names (Only in Portuguese version)
* smkdan
  -Multiple Songs on Main Map
* Sonikku
  -Better Bonus Game
* spooonsss
  -Block Duplication Fix
* Tattletale
  -Block Duplication Fix
* TheBiob
  -Victory Pose Fix
* Thomas
  -Edible Blocks

Blocks:
-------
* Alcaro
  -Teleport Block
* Broozer
  -Bounce Blocks
* Ersanio
  -Icy/Frozen Blocks
* MarioE
  -Teleport Block

Sprites:
--------
* andy_k_250
  -Rocko
* Erik
  -Cheep-Cheep that moves like a dolphin
  -Snow Pokey
  -Thwimp Thwomp
* Ersanio
  -SMB3 Statue Laser
* Iceguy
  -Ultimate Noob Sprite
* Ladida
  -Cluster Effects Pack (fish)
* leod
  -Rock/Bomb Throwing Monty Mole
* Major Flare
  -Charging Spiny
  -Custom SMW-Like Iggy Boss
  -Morton Boss
* MarioFanGamer
  -Cluster Falling Leaves Effect
* Mr. MS
  -Jumpin' Goomba
* RussianMan
  -Sleepy Boo
  -Venus Ice Trap
* smkdan
  -Bunbun
* Telinc1
  -Cave-In Generator (Cluster)

UberASM:
--------
* Alcaro
  -Autosave + Bring Up Save Prompt by pressing Select
* Blind Devil
  -Cutscene Mode
* Eduard
  -Invisible Mario
* Erik
  -Autosave + Bring Up Save Prompt by pressing Select
* janklorde
  -Disable Controller Buttons
* Kevin
  -Disable HDMA During Transitions
  -Retry System
  -->Only the multiple checkpoints feature is used, along with changing settings to work like the vanilla game, and saving lives and Yoshi Coins.
* MarioFanGamer
  -Overworld Exit Counter
* westslasher2
  -Autosave + Bring Up Save Prompt by pressing Select

Tools:
------
* Alcaro
  -Asar
* Atari2.0
  -PIXI
* dtothefourth
  -Effect Tool
* ExoticMatter
  -GradientTool
* Fernap 
  -UberASM Tool
* FuSoYa
  -Lunar Magic
* JackTheSpades
  -Effect Tool
  -PIXI
* p4plus2
  -Gopher Popcorn Stew
* Smallhacker
  -SMW Misc. Text Editor (Only in Portuguese version)
  -SMW Status Bar Editor
* Tattletale
  -PIXI
* TheBiob
  -Gopher Popcorn Stew
  -Mario Start Editor (Only in Portuguese version)
* Vitor Vilela
  -UberASM Tool
* YY
  -YY-CHR.NET

Beta Testing:
-------------
* N450

Special Thanks:
---------------
* brunodev85
  -For creating Winlator, the app that was used to run the SMW hacking tools on my Android phone.
* Hot Sauce
  -For inserting the remaining UberASM codes to the hack for me, as I was having the 0x80131506 fatal error problem.
* SMW Central
  -For the resources used to make this hack.
* And you!
  -For playing this hack!