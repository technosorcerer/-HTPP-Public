~~~~~~Introduction~~~~~~

Heyo! Thank you for playing the Chapter 1+2 Demo for my latest project, The Path from Prisminia!

To play this game, you'll need to get a clean, unedited ROM of Super Mario World. They're not hard to find.
Then, apply the included .BPS file to the ROM, using the tool "Floating IPS"!

- SayuriSRC

~~~~~~Story and Information~~~~~~

This game takes place in the same continuity as my previous project, JTTMK 3, but you do not need to play that in any way for this.
After a brief recap of past events in the intro, that's all you need!

~~~~~~Tips~~~~~~

- Save your game anywhere on the map by pressing Select.

- Press Up to go through doors and interact with NPCs, as well as flavor texts marked with a "!". Press B to advance cutscenes. Press START to skip cutscenes.

- Once you unlock it, practice holding down B in the air efficiently to make best use of your hover.

- Power-ups are fairly scarce after Chapter 1. You can always visit the city shops after certain points, though.

- In almost every area, there's a big coin - Ursulite Coins - either hidden, or in a hard-to-reach spot. These will serve a further purpose in the full game, but see if you can get all of the demo coins!

~~~~~~Conclusion~~~~~~

If you wanna share your thoughts, throw a comment on the game's SMWC page!
If you run into any glitches, crashes or bugs, you can leave a comment, send me a PM, or message me on Discord at "sayurisrc"!
I have tested the game on both emulation and real hardware, but who knows what I might have missed.

That's all for now. Look forward to the full game sometime in the future!

~~~~~~Demo Changelog~~~~~~

v1.0 (December 19, 2021)

- First public demo.

v1.3 Special Demo (July 24, 2022)

- Implemented a small part of Chapter 2 - in this demo, only its first level is in the game and the demo is over after beating it
- Objects that have flavor text from Moonlight now have a ! in front of them
- Added the ability to skip all cutscenes (press START)
- Added a sprint button when climbing vines (hold X or Y)
- Increased overworld movement speed
- Rewrote some of the intro dialogue for story reasons
- Altered the Guin City shopkeeper's dialogue
- Swapped to the Message Box Expansion system
- Replaced the mushroom GFX with a custom heart - eventually, every powerup will have new designs

v2.0 Winter C3 2024 Demo (February 23, 2024)

- As you'd guess from the title of the demo, Chapter 2 is fully implemented
- Swapped to the VWF Dialogues system
- Instead of dialogue showing the speaker's name before the dialogue ("Moonlight: blahblahblah"), character dialogue is now colored. Moonlight is light blue, Omelas is bright red, unnamed NPCs are just white, etc.
- Resolved an issue causing the game to crash after saving; huge thank-you to MarioFanGamer and Fernap for their help with this!
- Slightly changed the overworld design in Prisminia of the area around the purple house for story reasons
- Redesigned parts of the chapter 2 overworld map to fit more with altered level paths and a level theme
- Removed dialogue from Moonlight altogether in a certain area to let the room speak for itself
- Along with saving on the overworld via Select, there are now Save Blocks (akin to Paper Mario) in every hub/town/village/city area

v2.1 (April 12, 2024)

- Fixed an incorrect overworld level flag in Prisminia
- Fixed HDMA transition issue in Prism Path and Guin City
- Added instakill blocks to certain spots in Thieves' Hideout and Empyrean Crossing to prevent skips
- Fixed layer 3 error in Gamana Peak
- Fixed a softlock in Lab Prodigialis
- Adjusted some enemy placement in Lab Prodigialis
- Fixed some dialogue typos
- Fixed a rather glaring issue of the side exit still being accessible in Spellbinding Sierra's main area