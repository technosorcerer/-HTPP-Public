3rd Edition (August 2018): It's been too long, mainly because I've distanced myself from this community and I've done far less smw hacking lately, but there was no way I was leaving this unfinished. I did 7 full livestreams of me replaying this romhack to 100% exit completion and took a few notes on what should be changed along the way. Rather than retype the changes made again, I've also included my notes from my livestreams along with the download. In my honest opinion the forums are slowly dying and becoming too strict towards certain views and I'd blame some of the moderators for SMW Central's foreseeable downfall.

2nd Edition (July 2017): yeah, it should be easier now. please jackie let this make it this time.

Hello player, it's been roughly 10 and a half months since the beginning of Bits and Pieces. The original focus was to have a user-centric hack which would consist of levels built from user-suggested resources on Super Mario World Central.
e.g. AnonymousMoot suggests I use the Atomic Shroom sprite (which would shake the ground and blow up if Mario touches it), and I then go on to build a puzzle level based on using the Atomic Shroom to either knock out or move around some enemies.

The requests for sprites and blocks stopped coming in roughly halfway through the hack's development, leaving me time to come up with some more gimmicks if I had to and plenty of time to use many of what suggestions I got. I could say I used roughly 58% of what was requested.

In my first post, I anticipated I'd have enough material to reach a 10-20 long level hack. Except my world themes expanded and expanded to reach new themes, especially everything that's going on in the Underworld/World 5, which is split into two submaps. Eventurally, I ended up going way past my initial prospect and reached a total of 49 levels / 57 exits. (update: proper exit count is actually 58).

A special world with very new level themes got tacked onto the end, but it requires all 49 exits from the main game.

Finally, I'd like to list the people who dropped by to leave suggestions in the early stages of the hack's development:
MelodicCodes
cheat-master30
StrikeForcer
Lazy
imamelia
AlwaysANoob
Master Lakitu
Trollope
Daizo Dee Von
MarioFanGamer
Berkay
Queen Samus
Kaisaan Siddiqui
dffshem
werd

I have to thank these people for making the early stages of bits and Pieces the most fun; gotta mix things up somehow!

And with that, I'll mention that there's 19 moons in all, which is mentioned in the checklist.

- levelengine

--------------------------------------------------

SPRITES:
Romi
mikeyk
LX5
1524
leod
Davros
Schwa
deffon1993
Medic
mikeyk
GreenHamerBro
JackTheSpades
MarioE
682
Koyuki
yoshicookiezeus
Queen Samus
andy_k_250
Awsomest 14
mikeyk
Nesquik Bunny
maro
n00b
Jimmy52905
Lexie

BLOCKS:
Bio
S.L
tmercswims
Hach
edit1754
GreenHammerBro
Chdata
uyuyuy99
JackTheSpades
Sayuri
Ersanio
nick 139
PatPatPat
Roy
Sonikku
Yanama
imamelia

MUSIC:
HarvettFox96
worldpeace
gibbl
Sinc-X
tcdw
gpetry
Thomas
yoshi9429
spigmike
Red Chameleon
S.N.N.
ggamer77
Slash Man
Izuna
scooter
Gamma V
RednGreen
Mogsiah
Moose
Darius
Lui37
Atma
ThinkOneMoreTime
Jimmy52905
Masterlink
Unknown User
xHF01x
Blind Devil
Mssashi27

GRAPHICS:
* Pac *
Rykon-V73
Keikonium
Metaknight
Hinalyte
imamelia
cheat-master30
Thehoundsquad
myself

--------------------------------------------------

Extra Powerups Shenanigans - LX5

SPECIAL THANKS:
FuSoYa
StrikeForcer
JackTheSpades
Alcaro
Pac
Kipernal
myself
(added with 3rd edition) 
SMW Physicist
DoubleDenial