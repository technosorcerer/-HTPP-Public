This project is a team hack that was started by a group of friends back in 2015. I took it upon myself to finally turn it into a finished product years later. So please keep in mind that this does not reflect the current abilities of the people involved and is instead a product of its time.

I still hope you have fun with what we made back then.
	- Mauls