Hey I hate readme files and my english sucks

This is my discord:
alfombracitarioj

PLEASE LEAVE A COMMENT IN SMWCENTRAL

If you're waiting for other update stop waiting, better go to YouTube (Alfombra de madera) and download other of my games if I make one

tyvm for downloading the hack!!!1