(Translator's note: This document has been translated as it was in 2015, with
no guarantee that any information and links contained within are still accurate
as of the time of this writing in 2021.)

Hey there, Anisaki here.
Thanks for downloading this hack.
So, since this is my first hack, and I made it while getting help and advice 
along the way, please overlook any shortcomings.
Okay, I'm not really going to ask anything like that, so if you come across any
problems please contact me.
The green coins in this hack serve as midpoints. That is, touching one will act
like cutting the midpoint tape. 

Well then, I'll be using Mr. Readme here to introduce the stages and their
difficulty ratings.

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

Stage 1: "I Told You Not to Touch Those!"            Difficulty: 2/5

Music: Bottle Fairy: Opening Theme, "Oshiete Sensei-san"
       Kirby Super Star: "Cocoa Cave"

Comments:
       If you've played the stage then you probably already know this, but this
       stage has an ON/OFF switch gimmick. If the switch gets set to OFF, you
       die. Not exactly a hard gimmick to implement, I guess. Since this is
       the first stage of the hack I've tried to keep it simple to play, but
       since it's built around instant death traps, it might be difficult to 
       get a good grasp on the structure of the entire level.

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

Stage 2: "Ninja Forest"                              Difficulty: 1/5

Music: Donkey Kong Country 2: "Forest Interlude"

Comments:
       This stage faces you off against a bunch of graphic-swapped Ninjis while
       your vision is being obscured with fog. The only thing that changes when
       you switch areas is the direction of the fog, so it's not a difficult
       stage at all. The only thing is that the Ninjis that come falling from
       overhead might require some memorization. As for how to get the dragon 
       coin at the start, just try going for it. You'll get it.

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

Stage 3: "Cursed Grounds"                            Difficulty: 2/5

Music: Chrono Trigger: "Underground Sewer"

Comments:
       Sorry for scaring you with that message block. Spin jumping is not
       allowed here. The bit with the boo rings might be a tad difficult. 
       I think getting all the Dragon Coins is also on the hard side.

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

Stage 4: "The Submerged Metro"                       Difficulty: 2/5

Music: Mega Man 9: "Splash Woman Stage"

Comments:
       The first half is not hard at all as long as you watch out for the
       Torpedo boys. The latter half has blocks that turn the stage underwater,
       and ones that reverse that effect. It's mostly pretty simple stuff.
       You might find it a bit hard to collect all of the Dragon Coins, though.

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

Stage 5: "Magical Sky"                               Difficulty: 3/5

Music: Kirby's Adventure: "Grape Garden"

Comments:
       What with the invincible Magikoopa and the fact that you'll die if you
       go too high up, this stage really gives the feeling that the difficulty
       has shot up. In exchange for the lack of midpoint you get a cape in the
       second half. You can get the final Dragon Coin by maintaining your big
       state all the way to the goal area. You might have trouble dealing with
       the Magikoopa if you don't get used to how fast and invincible he is.

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

Stage 6: "Freezy Furnace"                            Difficulty: 3/5

Music: Donkey Kong Country 2: "Hot-Head Bop"
       Donkey Kong Country 2: "In a Snow-Bound Land"
       Kirby Super Star: "Save Hut"

Comments:
       This one starts off as a lava stage, but once you hit the midpoint it
       freezes over into something different. There may be pipes which can only
       be entered when the stage is in one of its two states, but since the
       stage is one-way throughout, this is probably not going to make you lose
       your way. There are quite a lot of areas in this one, so it's on the
       harder side. You can get stuck in the second half if you lose your
       fireballs, but since there's not a single enemy that can move around you
       can take your time to move carefully.
       Some Dragon Coins can only be gotten in the lava half, while the others
       are only reachable in the ice half, so if you see any you can't seem to
       get to in the first half then try again when everything's frozen over.
       Incidentally, the name of this level was made by combining the stage
       names "Fiery Furnace" and "Black Ice Battle" from Donkey Kong Country 2.

       (Translator's note: The bit about the level name applies only to the
       Japanese version, where this stage was called literally
       "Hot Dome Tango", combining the level names "Hot Dome Tizer" (Fiery
       Furnace) and "Ice Dome Tango" (Black Ice Battle) from the Japanese
       version of DKC2. The translated version of this stage simply alters
       Fiery Furnace to sound both hot and frozen while still sounding
       recognizable.)

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

Stage 7: "The Turtle Mines"                          Difficulty: 2/5

Music: Donkey Kong Country 2: "Mining Melancholy"
       Kirby's Adventure: "Yogurt Yard"

Comments:
       This is a bonus-like stage using the minecart.
       I think this is quite an easy stage considering there are no enemies
       besides Koopas. You shouldn't have a hard time as long as you get the
       timing with the minecarts right.
       The Dragon Coin placement is quite perverse though, so have fun
       collecting those.

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

Stage 8: "Colorless City"                            Difficulty: 3/5

Music: Pokemon Gold/Silver/Crystal: "Dark Cave"

Comments:
       This level has a palette that takes you right back to the twentieth
       century. The thing to watch out for in this level is the Chain Chomps.
       You can spin jump on them whether they're chained up or not, so just
       take it easy and you'll be fine. (Mind you, you can't kill them.)
       Quite a few of the Dragon Coins are on the lower part of the level.
       That is all.

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

Stage 9: "The Urine Factory"                         Difficulty: 4/5

Music: Donkey Kong Country: "Fear Factory"

Comments:
       The statue of a boy passing water, as a yellow oasis unfurls.
       A most beautiful and high-brow stage. Surely the level name already
       convinced you of its grace?
       You'll get what I mean better when you start swimming, but the amount
       of oxygen you lose over time depends on how concentrated the 'water' is.
       The green water will kill you instantly, while the red drainage will
       remove your held item.
       You should be able to acquire all the Dragon Coins by just playing
       through the level normally.

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

Stage 10: "Anohage: The Geezer We Saw That Day"      Difficulty: 5/5

Music: Touhou Imperishable Night: "Nostalgic Blood of the East ~ Old World"

Comments:
       This stage is an arrangement based on Moonsong Temple from the hack
       Ossan Mario by Aonano, made with their permission.
       Video of the original: https://www.youtube.com/watch?v=NX_cXHTsKgk

       The biggest differences with the original are as follows:
       - Area 1: The Chainsaws got turned into Grinders.
       - Area 2: Added scroll and some floors.
       - Area 3: Removed Bills, added Chainsaws and some floors.
       - Area 4: Removed yellow Koopas, added some floors.
       - Also removed lights from areas 2 and 4.

       That's about the gist of it.
       You can figure out the details by playing it yourself.
       Dragon Coins can be gotten easily along the way so I'll skip those here.

       Thanks to Aonano for giving permission.

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

Stage 11: "Drink Up, You'll Grow Big and Strong"     Difficulty: 2/5

Music: Super Mario RPG: "Still, the Road is Full of Dangers"
       Final Fantasy 6: "Dancing Mad #3"

Comments:
       Pretty simple stage, isn't it?
       Would you look at all of that milk just getting spilled, what a waste.
       The fire on the candles is just about all you have to watch out for.
       Other than that it's smooth fare.
       There's only one Dragon Coin that's even slightly difficult to get, and
       the rest of them can be gotten as you go along.
       Maybe you'll get to find out exactly in what way you'll grow big and
       strong once you hit the goal!

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

Stage 12: "Super Mario World"                        Difficulty: 2/5

Music: Mega Man 2: "Wily Stage 1"

Comments:
       This stage connects one stage from each of the worlds in the original
       game together into one level.
       There are small changes throughout but they're mostly identical to their
       original appearances.
       If you're going for all the Dragon Coins you're best off getting a good
       grasp of the entire stage beforehand.

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

Stage 13: "Seven-Colored Sea"                        Difficulty: 5/5

Music: Treasure of the Rudras: "Crime of the Heart Night"
       Romancing SaGa 3: "Last Battle"

Comments:
       You travel through this final stage in a submarine, and transition through
       the seven areas in the following order:
	   
       Red: Some preliminary scouting.
       Orange: Cheep Cheeps
       Yellow: Super Koopas
       Green: Thwomps and Thwimps
       Blue: Bullet Bills
       Indigo: Grinders
       Violet: Homing Bills
       
       That's about it. The submarine moves faster during the blue and indigo
       sections, so try not to panic.

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

This concludes my introduction of all of the stages.

If you encounter any problems, you can contact me at
Nico Nico Community: http://com.nicovideo.jp/community/co2910253
Twitter: https://twitter.com/Anisaki_2525

Have fun!

Graphics:       SMWC, Aonano, MST
Music:          SMWC
Sprites:        SMWC, MST, Sainan-san
Stage idea:     Aonano
Testing:        MST
Thecial Spanks: ABC ORE
Tinge:          tinge