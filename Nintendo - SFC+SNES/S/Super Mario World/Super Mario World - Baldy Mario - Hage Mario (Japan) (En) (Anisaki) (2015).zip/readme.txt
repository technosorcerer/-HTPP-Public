			      ====================
		                   Hage Mario
			      ====================

			      ====================
			       Changelog of fixes
                              ====================

First Version (21/06/2021)
	-Initial release

				 ==============
				 About the hack
				 ==============

Hage Mario (Baldy Mario) is a Japanese romhack made by the Japanese hacker Anisaki,
and released in 2015. This hack has 13 exits.

				==================
				About this release
				==================

First of all, we were not involved in and take no credit for the development of
the hack itself. We merely did the translation.

Included is a BPS patch for a version of hack that's been unofficially translated into English.
This version has also had some minor emulator compatibility issues related to improper use of
the hardware's mathematical multiplication and division registers fixed.

The readme included with the original Japanese release has also been translated as the file
"original_readme_translated.txt", as it contains interesting commentary on the levels as well
as some hints.

Finally, there is an ASM patch for additional quality of life and educational features.
Read the next section for more info on how to apply it.

			      =====================
			      About the ASM patches
			      =====================

Once the BPS patch of your choice has been applied, the resulting ROM should be ready
to play on most hardware and software capable of running SNES games without further
modification.

However, there are some more options in the form of ASM patches that you might be interested in.
In this hack's case, we've included patches for the following:

	- OW messages which will explain some of the references to Japanese internet memes.

We have tried making the process of applying these patches as simple as possible, so
even if you've never done anything with ASM before it shouldn't take longer than a
few minutes to find out what they all do and to actually apply the ones you want.

Below is a step-by-step guide to learning what all the ASM patches do, and how to apply them.

1. Prepare the ROM by applying either of the BPS files to a clean, headered USA version ROM of
   Super Mario World, and placing the resulting .smc file into the 'asm_patches' folder.

2. Run the '@main.cmd' file in the 'asm_patches' folder.

3. For each available patch, you will be told by the program what it does, and asked whether
   you want to apply it. Follow the instructions that appear on screen.

And now if nothing has gone wrong, the ROM should be ready to be played.

If the batch file fails for some reason, you can run asar.exe directly and use it to apply
the file 'apply_all.asm' to your ROM as a fallback. Make sure that the file extension of your
ROM is '.smc', and not '.sfc'.

Notes: Do not mess with any of the files in the asm_patches folder besides the rom you have
placed there, and running @main.cmd. If you want to repatch a ROM, use a new one rather than
one that has already had optional ASM patches applied to it.
Although there's almost no conceivable way you could damage your system by use of @main.cmd,
be aware that as a batch file it is essentially running system commands with any permissions
you give, and that we are not responsible for damage caused by improper usage of it.

The process uses a program called "Asar" by Alcaro (and others), which is not our work.
The program can normally be found at these addresses:
https://www.smwcentral.net/?p=section&a=details&id=14560
https://github.com/RPGHacker/asar

					=======
					Credits
					=======

This is a list of all the people whose software/patches/work we've used or adapted on this hack:

Asar 					- Alcaro et al
Lunar Magic				- FuSoYa
Extended Overworld Level Names 		- Smallhacker
YY-CHR.NET				- Yy

ASM for translator notes by Super Maks 64.
Translation, compatibility/bug fixes, and additional ASM by This Eye o' Mine.
Proofreading by Super Maks 64, Ryrir, lion, and Skye.
Testing by Ryrir and Skye.

And of course thanks to Anisaki who made the hack in the first place.

Our apologies to any people we might've missed.

- The Hack Fix/Translation team