The levels in this hack are designed around various custom mechanics. 
Some levels can be more platforming focused while others can lean on puzzle elements. 
I attempted to make levels that could be completed in one go, but you could also 
stop and take a moment to look or think about the upcoming obstacle. 
I also tried to be conscious about the length of each section in a level. 
Each section takes around 30 in-game Mario seconds to complete when going as quickly as possible. 
There are some sections that are shorter because there are more frequent checkpoints. 
Overall, I hope you have fun!
