This is my first "serious" Mario World hack, so I apologize in advance for the bad level design
or even for some beginner bugs, this is just a demo of a little project that was a joke that went too far
The hack is unfortunately entirely in Brazilian Portuguese but in the final version there will be an English version :D



Essa é minha primeira hack de mario world feita "seriamente" então peço desculpas ja pelo level design ruim
ou ate por alguns bugs de iniciante, isso é apenas uma demo de um projetinho que era uma piada que foi longe ate demais
a hack infelismente esta inteiramente em portugues brasileiro mas na verção final ira ter uma verção em ingles :D