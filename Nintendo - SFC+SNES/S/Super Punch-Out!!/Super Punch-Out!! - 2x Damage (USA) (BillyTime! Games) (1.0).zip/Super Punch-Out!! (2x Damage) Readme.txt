Super Punch-Out!! (2x Damage)
Dec. 29th 2025
BillyTime! Games
--------------------
This is a simple patch designed for Super Punch-Out!! that increases the amount of damage inflicted on opponents.

Special Circuit should also be accessible as well.

How to Patch:
--------------------
1.Grab a copy of Super Punch-Out!! (USA).sfc (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file