Super Punch-Out Stage Select 

press start at title screen to enter the stage select and choose to fight any opponent

any problems? email bank [at] bankbank [dot] net