Super Mario All-Stars is a gorgeous looking game, but even its wonderfully updated graphics has it nitpicks, as subtle as they may be. This is a simple aesthetic romhack that touches up the visuals of all 4 games. All with the goal of making the graphics more faithful to their NES originals, or to official Nintendo art from the same era. All with a few goals in mind.

	• SMB1 and LL have had their art modified to be more reminiscent the NES originals, while maintaining the All-Stars artstyle. Just like 2 and 3.
	• Every playable character has been redrawn to better match their NES appearances.
	• All small variants of the playable characters have been revamped to match their larger counterparts, having them look entirely different always appeared odd.
	• Enemies and powerups in all games have been redrawn to be more accurate to their official art. Except SMB3, they're pretty much spot on already.
	• Various small graphical glitches and mistakes have been cleaned up.

Changes in SMB1/LL:
	• Mario and Luigi have been given new sprites based off their original NES appearance
	• All enemies and powerfuls have been modified to better match their official art
	• The enviroment has been redrawn to appear more faithful to the famous cracked bricks, while keeping the improvements of the All-Stars artstyle
	• Peach has been given a makeover too!

Changes to SMB2:
	• The brothers have been edited to better match their NES art
	• Unable to improve on their honestly awkward looking 8-bit appearances, Toad and Peach have instead been given fancy new redesigns
	• Similar to Enemies and powerups who different from their offical SMB1 look, all whose appear different to offical art have been redrawn to match
	• Portions of the enviroment have been changes to call back to the 8-bit original
	• Birdo has been given a makeover too!

Changes to SMB3:
	• Originally having his all-stars SMB3 sprites copied straight from SMB1/LL, Luigi has now been fixed to better match the SMB3 style
	• Both brother's small variants now match their super versions artistically
	• Peach has been given a makeover too!

Also comes included with the SMB/LL brick fix by BMF54123 and DesertFOX.
Credit to Mollychan and P-P for original SMB1/LL brothers and birdo sprites respectively (https://www.spriters-resource.com/custom_edited/mariocustoms/sheet/187409/, https://www.spriters-resource.com/custom_edited/mariocustoms/sheet/111931/).

An unheaded rom is recommended, but a headed one works exactly the same. Apart from a warning message in some emulators,

Changelog
	1.1:
	• Refined the SMB1/LL ground tiles to better match the shading of other level tiles.
	• Added new underground tiles reminiscent of original NES graphics.
	• Touched up SMB2 Mario and Luigi sprites.
	1.2:
	• Added snow variants of SMB2 underground tiles.
	• Revamped Albatoss, Birdo, Cobrat, Flurry, Hoopster, Ninji, Ostro, and Pokey sprites.
	• Small adjustments made to SMB2 shells and mushrooms.
