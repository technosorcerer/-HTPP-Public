Super Mario All-Stars has always been a great compilation of remastered classics, all retouched to bring each game's visuals to life in a new generation... except for Super Mario Bros. and Super Mario Bros. The Lost Levels, which were completely remade to more closely resemble Super Mario Bros. 3.
This is a hack that aims to improve the 16-bit remasters of those games, in an attempt to make them look more accurate to the style of the original NES games.
Most of the sprites have been completely changed, with Bonus areas now having completely redrawn Mario and Luigi portraits and Luigi now sporting his original SMB1 look, being an identical twin to Mario.

VERSION 2.0 UPDATE:
- Luigi now has an unique color palette that resembles his classic appearance
- Small Mario/Luigi have been slightly modified
- A couple of graphics have been adjusted

CREDITS:
- Sprite Editing: Kousaku-P
- SMAS SMB/Lost Levels Brick Fix: BMF54123
- ? Blocks and Empty Blocks: KamiJoJo
- Testing: ProtoCloud, KamiJoJo, Natsu