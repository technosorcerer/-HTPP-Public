All-Stars SMB2 in SMB1 & SMB1 in SMB3 (v1.1):

In this Super Mario All-Stars sprite hack, play as, SMB2 Mario & Luigi in SMB1 and Lost Levels, and SMB1 Mario & Luigi in SMB3.


-SMB1 features:

 SMB2 Mario & Luigi use sprites from SMB2 All-Stars and SMA1, plus custom sprites, and wear their classic overalls. The Koopa Troopa's appearance has been changed to match their
 NES couterpart. Toad's appearance has been changed to beta form, with unused beta sprites and additional custom beta sprites.


-SMB3 features:

 Since SMB1 All-Stars Mario & Luigi sprites and animations are nearly identical to SMB3 Mario & Luigi, why not bring them over to SMB3? One could say its SMB3 Mario & Luigi
 with gloves and white eyes. Experience SMB1 Mario & Luigi with SMB3 power ups and in their modern overalls.


-SMB2 BONUS feature:

 While the SMB1 All-Stars and SMB3 All-Stars sprite hacks are the main features of this overall sprite hack, there is a SMB2 BONUS. Aside from small sprite touch ups for
 Mario & Luigi, Koopa Shell sprites have been edited to make the shell appear slightly bigger or as big as the shells in the other Super Mario Bros games.


-Alternative patch:

 For the alternative patch, the name within the overall title is "SMB2(NES-Style) in SMB1". In SMB1, SMB2 Mario & Luigi stand and jump like in NES SMB2. Big Mario & Luigi use
 SMB2 All-Stars beta standing sprites and their small versions stand like in beta or NES. Instead of jumping with one arm raised, they raise both arms.

 Also in this patch, there is another BONUS feature for SMB2. Instead of a bigger SMB2 Final Koopa Shell, there is a bigger SMB2 Beta Koopa Shell, with spinning animations.


Enjoy!



UPDATE (v1.1) and Compatibility Patching Instructions:

This rom hack is now compatible with BMF54123's "SMAS SMB/Lost Levels Brick Fix" rom hack. Make a copy of the original ROM and rename it. Make sure you're using Lunar IPS.
First use BMF54123's "smas_brickfix_smc" patch on the ROM, then use the normal "All-Stars SMB2 in SMB1 & SMB1 in SMB3" patch or the alternative "SMB2(NES-Style)" patch on
that same ROM.

(If you decide not to use the brick fix patch, you can still use Floating IPS to patch the ROM without needing to make a copy of the original ROM.)


------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Main Author and Sprite Editing: GloriousAngel24


Release Contents:

-Version 1.0	04/04/2024

 Initial Release


-Version 1.1	04/10/2024

 Recreated patches using Lunar IPS instead of Floating IPS to make them compatible with BMF54123's "SMAS SMB/Lost Levels Brick Fix" rom hack.


