Super Mario All-Stars is a gorgeous looking game, but even its wonderfully updated graphics has it nitpicks, as subtle as they may be. This is a simple aesthetic romhack that touches up the graphics of all 4 games. All with the goal of making the art more faithful to their NES originals, or to official Nintendo art from the same era.

•	SMB1 and LL have had their art modified to be more reminiscent the NES originals, while maintaining the All-Stars artstyle.
•	Every playable character has been redrawn to better match their NES appearances.
•	All small variants of the Bros. have been revamped to match their larger counterparts, having them look entirely different always seemed weird to me (looking at you SMB3)
•	Enemies and powerups in all games have been redrawn to be more accurate to their official art. Except SMB3, they're pretty much spot on already.
•	Various small graphical glitches and mistakes have been cleaned up.

Also comes included with the SMB/LL brick fix by BMF54123 and DesertFOX.
Credit to Mollychan and P-P for original SMB brothers and birdo sprites respectively (https://www.spriters-resource.com/custom_edited/mariocustoms/sheet/187409/, https://www.spriters-resource.com/custom_edited/mariocustoms/sheet/111931/).
