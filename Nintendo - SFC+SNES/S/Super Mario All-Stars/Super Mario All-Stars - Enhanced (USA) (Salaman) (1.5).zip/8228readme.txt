Super Mario All-Stars is a gorgeous looking game, but even its wonderfully updated graphics has it nitpicks, as subtle as they may be. This is a simple aesthetic romhack that touches up the visuals of all 4 games. All with the aim of making the graphics more faithful to their NES originals, or to official Nintendo art from the same era. All with a few goals in mind.

Every single playable character has been redrawn to better match their NES appearances. Alongside that all small variants of the playable characters have been revamped to match their larger counterparts. After all, having them look entirely different can appear stange once you notice it. Enemies, objects and the environment have all been redrawn to be more accurate to their official art. And finally, many graphical glitches and oversights have been cleaned up.

Changes in SMB1/LL:
	• A large portion of the games visuals have been redrawn to be more reminiscent the NES originals, while maintaining the All-Stars artstyle. Just like 2 and 3.
	• Mario and Luigi have been given new sprites based off their original NES appearance
	• All enemies and powerups have been modified to better match their official art
	• The enviroment has been redrawn to appear more faithful to the famous cracked bricks, while keeping the improvements of the All-Stars artstyle
	• Peach has been given a makeover too!

Changes to SMB2:
	• The brothers have been edited to better match their NES art
	• Unable to improve on their awkward looking 8-bit appearances, Toad and Peach have instead been given fancy new redesigns
	• Just like enemies and powerups who differ from their offical SMB1 look, the same has been applied to SMB2
	• Portions of the enviroment have been changed to call back to the 8-bit original
	• Birdo has been given a makeover too!

Changes to SMB3:
	• Originally having his all-stars SMB3 sprites taken straight from SMB1/LL, Luigi has now been edited to better match the SMB3 style
	• Portions of the enviroment have been given subtle changes to call back to the 8-bit original
	• Some enemies have been redrawn
	• Peach has been given a makeover too!

Also comes included with the SMB/LL brick fix by BMF54123 and DesertFOX.
Credit to Mollychan and P-P for original SMB1/LL brothers and birdo sprites respectively (https://www.spriters-resource.com/custom_edited/mariocustoms/sheet/187409/, https://www.spriters-resource.com/custom_edited/mariocustoms/sheet/111931/).

An unheaded rom is recommended, but a headed rom will run exactly the same.

Changelog
	1.0:
	• Initial release
	1.1:
	• Fixed shading on SMB1/LL ground tiles
	• Added SMB2 NES styled underground tiles
	• Adjusted SMB2 Mario and Luigi
	1.2:
	• Added snow variants of SMB2 underground tiles
	• Added new Albatoss, Cobrat, Flurry, Hoopster, Ostro, and Pokey sprites
	• Adjusted Ninji, and Birdo
	• Adjusted SMB2 shells and mushrooms
	1.3:
	• Changed a pixel on the SM1/LL ground and underwater tiles
	• Adjusted SMB1/LL koopa, hammer bros. and piranha plant
	• Gave SMB3 Mario and Luigi their gloves
	• Added new SMB3 koopa, drybones, big koopa and micro-goomba sprites
	• Changed SMB3 hammer bros, sledge bros, big goomba and bullet bill sprites
	1.4:
	• Cleaned up title screen
	• Adjusted peach and bowser graphics on title screen
	• Fixed overlooked mistakes with SMB3 player sprites
	• Added new SMB/LL castle tilesets
	• Remade SMB2 overworld and ice cave walls tilesets
	• Added SMB2 interior bricks and desert cave walls tilesets
	• Added now Buster Beetle sprites
	• Title screen now displays patch number
	1.4.1:
	• Changed colour of title screen floor to match SMB3 title screen floor
	• Fixed incorrect SMB1/11 undeground koopa palette
	1.5:
	• Fixed Peach's second frame of animation on title screen
	• General touch ups and pallette fixes of various graphics from all 4 games
	• Remade SMB1/LL hammer bros. (for the 3rd and final time), bloober, mushroom, fire flower, and poison mushroom sprites
	• Adjusted SMB2 Toad's sprites
	• Added new SMB3 chain chomp sprites
	• Revamped SMB3 koopa troopa and hammer bros. sprites and their variants
	• Updated SMB3 ending to match new sprites