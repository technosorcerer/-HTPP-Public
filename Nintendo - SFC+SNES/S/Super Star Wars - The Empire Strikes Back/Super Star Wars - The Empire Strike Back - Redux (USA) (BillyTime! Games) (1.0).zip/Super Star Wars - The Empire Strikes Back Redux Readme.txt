Super Star Wars - The Empire Strikes Back Redux
Sept. 15th 2025
BillyTime! Games
--------------------
This is a overhaul patch designed for Super Star Wars - The Empire Strikes Back designed to reduce the infamous difficulty of the original.

Changes
--------------------
Current Changes:
*Reduced damage from all sources in side scrolling levels
*2X damage
*Reduced weapon degration (No Degration on Easy Mode)
*Reduced or Removed annoying spawns (Hoth Birds, Jet Troopers, Speederbikes)
*Start with all force powers 
*Infinite Lives when playing Easy Difficulty
*Less ships and AT-ATs on vehicle levels
*2x Invulnerability time after taking a hit
*Slightly higher double jump
*Snowspeeder side scrolling level removed
*Continues Increased from 3 to 99

Streamlined level order: (Optional Patch)
Hoth 1
Hoth 2
Hoth Cave 2
Hoth 3
Battle of Hoth
Hoth Escape 1 (Han Solo)
Asteroid Belt Chase
Dagobah 1 
Dagobah 2 
Dagobah 3 
Bespin 1 
Lava Chamber 
Carbon Freezing Chamber
Bespin 2
X-Wing over Bespin
Bespin 5 


How to Patch:
--------------------
1.Grab a copy of Super Star Wars - The Empire Strikes Back (USA) (Rev 1).sfc (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file