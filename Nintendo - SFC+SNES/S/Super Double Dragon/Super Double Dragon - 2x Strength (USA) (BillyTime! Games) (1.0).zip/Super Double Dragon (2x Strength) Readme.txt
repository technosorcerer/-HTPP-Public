Super Double Dragon (2x Strength)
Jan. 5th 2025
BillyTime! Games
--------------------
This is a simple patch designed for Super Double Dragon that doubles the amount of damage inflicted on enemies. An additional patch is available for Return of Double Dragon.

How to Patch:
--------------------
1.Grab a copy of Super Double Dragon (USA).sfc (No-Intro)
OR
Return of Double Dragon (Japan) (En).sfc (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file