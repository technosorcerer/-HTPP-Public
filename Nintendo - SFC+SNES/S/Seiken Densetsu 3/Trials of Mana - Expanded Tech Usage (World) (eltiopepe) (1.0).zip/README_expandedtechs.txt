Expanded tech usage v1.0 by el tio pepe
Patch onto UNHEADERED Trials of Mana or Seiken Densetsu 3 English rom (compatible with Sin of Mana mod as well): 
Also compatible with Sin of Mana mod.


Each class can use their own class's techs in addition to their counterpart's techs.
This means base dark and base light both have two.
LL and LD both have four (2 lv2, 2 lv3), with the lv3's being the light side's.
DL and DD both have four (2 lv2, 2 lv3), with the lv3's being the dark side's.
Ex: Swordmaster Duran will have 3 step cut, whirlwind sword, vaccuum sword,
and eruption sword.
Paladin Duran will have 3 step cut, whirlwind sword, magic circle, and flashing sword.
They are triggered at random (per lv), like Kevin's throws.
Kevin is unique, he gets two regular techs, plus his original throws. This means he has three
per lv2, lv3. I made it so the two dark classes don't both have seriyuu death fist/suzaku sky dance,
since they are identical animations. They get genbu 100 kick and the lights get sky dance. They are the
only exception to the system above. Throws will also trigger less frequently.




Big thanks to praetarius5018 for creating the legendary Sin of Mana mod as well as the bugfix
patch to bring out the best version of this game we all love. Also shoutout to hmsong for all of 
his patches and for happily supplying me with his SD3 notes so that I could better map out the
rom addresses. Also thanks to the Mesen emulator team, their debugger is top tier, and was essential
to all of these patches being created.
