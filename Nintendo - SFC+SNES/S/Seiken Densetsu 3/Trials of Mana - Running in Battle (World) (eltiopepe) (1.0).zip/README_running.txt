Running in battle v1.0 - by el tio pepe
Patch onto UNHEADERED roms.

Hold B to run in battle. Tech usage is swapped to the Y button.
***PRESS B AND Y TOGETHER AT THE SAME TIME to open the menu***

AT mode is also disabled, because it messes with movement and it sucks anyways.




Big thanks to praetarius5018 for creating the legendary Sin of Mana mod as well as the bugfix
patch to bring out the best version of this game we all love. Also shoutout to hmsong for all of 
his patches and for happily supplying me with his SD3 notes so that I could better map out the
rom addresses. Also thanks to the Mesen emulator team, their debugger is top tier, and was essential
to all of these patches being created.