Bugfix 1.10 Trials of Mana compatibility patch v1.0 by el tio pepe
Patch onto UNHEADERED Trials of Mana rom.

This is the latest version of praetarius's fix only patch, modified for compatibility with
Trials of Mana. I didn't change anything in it, it's exactly the same, it just works
with the new ToM 2019 rom.



Big thanks to praetarius5018 for creating the legendary Sin of Mana mod as well as the bugfix
patch to bring out the best version of this game we all love. Also shoutout to hmsong for all of 
his patches and for happily supplying me with his SD3 notes so that I could better map out the
rom addresses. Also thanks to the Mesen emulator team, their debugger is top tier, and was essential
to all of these patches being created.