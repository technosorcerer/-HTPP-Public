Combined or individual patches:

- Secret of Evermore - Practice 1.2.0.ips (combined)
    - practice.ips
    - camera_hack.ips
    - room_timer.ips
- https://www.romhacking.net/patch/ can be used to patch the ROM
    - English/"(U)", preferably good dump/"[!]"
    - No header

Features:
- Teleport to various locations
- Debug Ring Menu (Created by XaserLE, see https://www.romhacking.net/hacks/4638/)
    - Unlock items
    - Atlas
    - No-Clip
    - Spawn various enemies
- Removes various camera restrictions (camera_hack.ips)
- Room timer (room_timer.ips, created by Skarsnik, see https://github.com/Skarsnik/sneshacking/blob/master/SoE/soepractice.asm)
    - Start+Select manual timer


Known Bugs:
- Repurposed memory
    - Strongheart/Cure hut was used for the :)-room and cannot be accessed
    - Some dialogues were trashed to create new dialogues (E.g. Fire Eyes, Horace, etc.)
- Some teleports don't set all relevant flags