                       Super Street Fighter II-16 Round Edition

                                   Hack By Wu Shan
---------------------------------------------------------------------------------------
This hack changes the arcade mode from 12 opponents to 16 opponents, which is enough to challenge all characters.

Features:
·Challenge 16 opponents in arcade mode
·Change some colors
·Zangief's Spinning Piledriver and MK throw sound effects changed to match the arcade version

Have a great time playing!