This is a patch for Aeon Genesis' translation of Shin Megami Tensei that fixes every bug present in the translation, ranging from missing line breaks or texts that are too long, to not being able to buy guns in the first part of the game or not being able to complete one the game's endings.
It also changes the names of demons, races, items, spells, skills and other things to those used in the official translations. This is not only to make the game friendlier to those familiar with Atlus USA's translations, but some spells were so long in Japanese (Maha-Zan and Maha-Zanma, for example) that you couldn't differentiate between both in the selection screen.

This patch must be applied to the original, Japanese rom. If you don't know how to apply .ips patches, you must have both the rom and the patch in the same folder with the same name and start the rom in your emulator (I recommend Snes9x for this game), or hardpatch it by using Lunar IPS so the change is permanent.

This is version 1.0. I don't think future updates are needed.

Shin Megami Tensei is (c) Atlus
The game's English translation is (c) Aeon Genesis
The patch includes Aeon Genesis' translation, with bug fixes and changes made by me, Orden.