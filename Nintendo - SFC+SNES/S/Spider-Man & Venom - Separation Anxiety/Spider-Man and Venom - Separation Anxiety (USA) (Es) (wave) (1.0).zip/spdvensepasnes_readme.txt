Spider-Man & Venom - Separation Anxiety (Super Nintendo)
Traducci�n al Espa�ol v1.0 (09/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Spider-Man & Venom - Separation Anxiety (U).smc
MD5: 07f817a784c393b381db699a046fa4a9
SHA1: 4cc91f82f800b9a10433d91579911083ca47484e
CRC32: 919c509d
3.145.728 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --