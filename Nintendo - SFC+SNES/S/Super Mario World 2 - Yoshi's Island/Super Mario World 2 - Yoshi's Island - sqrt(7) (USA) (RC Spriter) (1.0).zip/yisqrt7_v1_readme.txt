Thanks for downloading Yoshi's Island √7, hope you enjoy!
-RC Spriter


Steps to play this hack:

1. Make sure you have the yisqrt7.bps patch file included in this ZIP folder.

2. Find a Yoshi's Island SNES ROM online, (U) version 1.0. Should be file type .smc or .sfc. Sorry it's a bit inconvenient, but I can't provide a ROM here directly because of questionable legality.

3. Download this patcher program, FLIPS: https://www.smwcentral.net/?p=section&a=details&id=11474

4. Run FLIPS and apply the yisqrt7.bps patch to your ROM.

5. Run the ROM with an emulator (the one I currently use is Snes9x). You'll know it's correctly running the hack if you see an "RC Spriter" logo at the start instead of "Nintendo Presents".
If you have issues with the above steps, feel free to ask me (although I'm no expert), or check more tips here: https://www.smwcentral.net/?p=faq&page=1524970-getting-started


A few notes about the hack and its features:

• I've made custom levels for 1-1 through 2-6 (including 1-Extra) so far; if you beat all of those, the game continues as usual with regular Yoshi's Island levels. Will update the downloadable patch file here as I make more levels.

• Played through it many times to verify there exists exactly 20 red coins, exactly 5 flowers, and plenty of stars, so 100 points are achievable in all of these custom levels (including multiple routes if the path splits).

• I've tried to clean up as many various issues as I could find - mostly bugs due to disappearing sprites, and spots of unclear/unfair level design. But, please let me know if you find any wonky issues remaining.

• Made some custom map icons (although they're pretty simple) plus a few other tiny graphics changes.

• Instead of middle rings, this hack has various "save points" in the form of yellow egg blocks where you can make a savestate. I originally did this because of technical limitations; there weren't any great tools to edit midway entrances when I started making this hack - or at least if there were, I wasn't tech-savvy enough to use them. But I've grown to like the save blocks' simplicity and compactness. Because of this, there are more stars provided in each level (to account for the 10 you'd get per ring), but not many 1ups (you won't need them since you're using savestates, so they really only exist for bragging rights).

• I also added red warp doors at each level's start to warp straight to the goal, in case you're completely stuck and want to see what lies ahead in future levels. Hopefully won't need to be used, but don't feel bad if you do - I definitely made 2-2 quite a bit too hard, but didn't want to make major changes to it and have to compromise its overall design. May or may not change my mind about moving that level to a later world in the future, though.


Check out this link to see some more screenshots and tidbits of info about each level:
https://www.smwcentral.net/?p=viewthread&t=73078


And here's a video playlist with my playthrough of all the levels I've made so far, could be helpful if you want a guide on how to find all the secrets. But, take note that some things might be changed a tiny bit between now and back when the video was recorded - feel free to ask me if you have specific questions.
https://www.youtube.com/playlist?list=PLBd_U5xoWsxbATp5yRiC-9YjFmkBx_pIT
