This is FASTROM for SD The Great Battle (Rev 0 and 1) and is fully compatible with the Aeon Genesis translation.

MISTER Cheat files have been provided for both revisions as well as their english translation counterparts.

SPECIAL THANKS TO ALL MY PATREONS

EXTRA SPECIAL THANKS TO TOP PATREONS:

RHZ
RC_Meatpuppet
Sam M.
mobilevil
June M.
Sunrise Redeemer
Wabbajack

twitter.com/kandowontu
patreon.com/kandowontu
discord.gg/U4CtzqDGa5