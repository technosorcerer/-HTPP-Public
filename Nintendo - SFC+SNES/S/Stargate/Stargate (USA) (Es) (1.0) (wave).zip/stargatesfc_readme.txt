Stargate (Super Nintendo)
Traducción al Español v1.0 (11/10/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Stargate (USA).sfc
MD5: 8d4249cf09bb6e63a7ef4b80d05da2ad
SHA1: 79fe2f6ee71fffe8f9d91a9680ecefe8f1568488
CRC32: 526ce576
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --