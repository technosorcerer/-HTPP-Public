Super Star Wars Redux
Sept. 15th 2025
BillyTime! Games
--------------------
This is a overhaul patch designed for Super Star Wars designed to reduce the infamous difficulty of the original.

Changes
--------------------
*Reduced Weapon Penalty on death (No Degradation on Easy Mode)
*Infinite Lives when playing Easy Difficulty
*Nerf Spawns on Tatooine levels
*Less Jawas on landspeeder stages
*Reduced health for Kalhar Boss Monster
*2x Damage 
*Reduced Tie Fighters and Towers in Death Star
*Reduced Length in Death Star Trench Run
*Continues Increased from 3 to 99
*Skip Sandcrawler Stages (Optional)
*Health Regen (Optional)


How to Patch:
--------------------
1.Grab a copy of Super Star Wars (USA).sfc (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file