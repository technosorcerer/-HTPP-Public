
Street Fighter II Turbo (USA) (10 Turbo Stars Enabled Hack)
Street Fighter II Turbo (USA) (Rev 1) (10 Turbo Stars Enabled Hack)


The pacth enables 10 stars for extra speed in turbo mode, there's no need to do the cheat with the controller anymore!. T
here are patches for v1.0 and v1.1 versions of the roms, these patches works  with msu1 files too!



2023 Hostmaster