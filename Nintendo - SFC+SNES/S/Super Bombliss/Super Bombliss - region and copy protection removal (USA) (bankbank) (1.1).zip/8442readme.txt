Super Bombliss copy and region protection removal
version 1.1 by bankbank

update: patch is for no-intro ROM with CRC32 1d123be6

credits to TCRF https://tcrf.net/Super_Bombliss_(SNES)

Super Bombliss has copy protection. There are 4 separate checks that take place in the game:

1) is there enough SRAM?
2) is there too much SRAM?
3) is the region PAL?
4) unknown

This hack removes these protections. The game should now work properly if there is no SRAM or if there is more SRAM than the original game had. In addition, the game should run on PAL consoles (no guarantee that it will run properly).

if you have any problems, contact bank [at] bankbank [dot] net

bankbank

for any hackers interested, the checks are all at $808547