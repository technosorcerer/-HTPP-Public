This is for Super R-Type (U) for systems that don't support the better SA-1 patch.

SPECIAL THANKS TO ALL MY PATREONS

EXTRA SPECIAL THANKS TO TOP PATREONS:

RHZ
RC_Meatpuppet
Sam M.
mobilevil
June M.
Sunrise Redeemer

twitter.com/kandowontu
patreon.com/kandowontu
discord.gg/U4CtzqDGa5