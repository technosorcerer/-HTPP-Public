Super Mario All-Stars + Super Mario World Regloved v1.0
By Stifu, 2025-11-17

This patch gives gloves to Mario and Luigi in Super Mario Bros 3.
Their lack of gloves was a mistake in the original SMAS / SMAS+SMW.

There is a Redux patch by ShadowOne333 that aims to do the same thing,
but a few frames were not updated properly or at all. The most obvious changes
concern Battle Mode, which was missing gloves on several frames.

This patch can be applied on the original ROM, but should also be compatible
with most other patches, to be applied last.

Filename: Super Mario All-Stars + Super Mario World (USA).sfc
CRC-32: f84305b1
SHA-1: d245e41a2b590f7d63666b0772cbddfb26f254a2
