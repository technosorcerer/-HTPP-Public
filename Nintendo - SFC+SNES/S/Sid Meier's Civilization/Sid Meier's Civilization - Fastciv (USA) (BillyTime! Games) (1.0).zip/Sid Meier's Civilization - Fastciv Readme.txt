Sid Meier's Civilization - Fastciv
Nov. 5th, 2025
BillyTime! Games
--------------------
This patch is designed to ramp up speed when starting a game of Sid Meier's Civilization on SNES.

Current Changes:
--------------------
Settlers and Warriors get extra 1.0 movement
Earned Income per turn is doubled
Upkeep Cost Removed
Settler actions take only 1 turn


How to Patch:
--------------------
1.Grab a copy of Sid Meier's Civilization (USA).sfc
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file