Super Tetris 3 copy and region protection removal
version 1.0 by bankbank

credits to TCRF https://tcrf.net/Super_Tetris_3

Super Tetris 3 has copy protection. There are *40* separate checks that take place in the game that look at two aspects of SRAM:
* is there NO SRAM?
* is there more than the expected amount of SRAM?
if either of these checks fail, the game will softlock on an anti-piracy screen

In addition, the game has region protection. If the region is not NTSC, the game will softlock on a different screen.

This hack removes these protections. The game should now work properly if there is no SRAM or if there is more SRAM than the original game had. In addition, the game should run on PAL consoles (no guarantee that it will run properly).

if you have any problems, contact bank [at] bankbank [dot] net

bankbank

for anyone interesting in hacking, the game state at WRAM $60 is where the action is. LDA #$28 means SRAM failed, LDA #$27 means NTSC failed.