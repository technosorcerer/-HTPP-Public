This is FASTROM for Zero Squirrel (U) + (E Rev 0+1)

SPECIAL THANKS TO ALL MY PATREONS

EXTRA SPECIAL THANKS TO TOP PATREONS:

RHZ
RC_Meatpuppet
Sam M.
mobilevil
June M.
Sunrise Redeemer
Wabbajack

twitter.com/kandowontu
patreon.com/kandowontu
discord.gg/U4CtzqDGa5