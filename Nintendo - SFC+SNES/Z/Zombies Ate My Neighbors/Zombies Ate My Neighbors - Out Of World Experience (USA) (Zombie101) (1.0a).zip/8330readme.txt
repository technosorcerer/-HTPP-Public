            Level Layouts, Hex Editing And Most Sprites by me (Zombie101)       

           Special Thanks to The Following People Who Made This Possible.


Pev,
the Zeldix Website,
My Twin Brother,
My Big Brother,
Stanely Decker,
Oh No! More Zombies Ate My Neighbors Team,
Pirahaplant,
Droter,
BN3$$,
Silver exe,



                                Special Thanks to All my Family And Friends.


Stanely Decker,
Oh No! More Zombies Ate My Neighbors Team,
Pirahaplant,
Skyhurricane,
Droter,
Silver exe,
GaryGamerGuy,
PunchingPlayerPenguin,
Walt95,
bone tail,
Maelstromof Chaos,
Zamn Girl,
Lilian Kage,
Luzvel Video,
Mallory P. Maggiore,
zefennekinfan,
Gia,
Dude 27th,
BN3$$,
Espio The Chameleon,
Izzy Glow,
Alex Wesker,
Yami,
Alex Kidd,
Flamm606,
Everette,
TaeBin,
Future Family,
Future Friends.


Changes:
20New Levels!
New Demos!
Sprites And More!
~~~~~~~~~~~~~~~~~~
INSTALLATION INSTRUCTIONS
~~~~~~~~~~~~~~~~~~

- Make sure to place the ROM and Music Files together!
- Requires Snes9X or BSNES-Plus to make the music work.
- Obtain a headerless ROM of the North American version of Zombies Ate My Neighbors (Headerless ROMs have the .sfc extension)
- Download Lunar IPS (http://fusoya.eludevisibility.org/lips/)
- Place both the ROM and the .ips patch inside the Lunar IPS folder.
- Run Lunar IPS and click on "Apply patch"
- A window will pop up. Select the .ips patch.
- A second window will appear. Select the ROM.
- Lunar IPS will apply the patch to the ROM.
- Rename the ROM to "Zombies Ate My Neighbors (USA) MSU-1" And Play!


ALL RIGHTS GO TO THEIR RESPECTFUL OWNERS!

Sega
Nintendo
Konami
Rareware
Disney

Songs Are Listed in Order You Play Them in.

1-1 Ghoul Patrol - Metropolis 2
1-2 Alien Storm - We Are Busters!
1-Mini Game Level - Donkey Kong Country 2 - Bonus Theme
1-3 Decap Attack - Level 4
1-4 Ghoul Patrol - Boss Fight
2-1 Donkey Kong Country 3 - Water World
2-2 Donkey Kong Country 1 - Misty Menace
2-Mini Game Level - Sonic the Hedgehog 2 - Special Stage
2-3 Jurassic Park 2: the Chaos Continues - Raptor Attack
2-4 STREETS OF RAGE 2 - Alien Power
3-1 STREETS OF RAGE 3 - Dub Slash Round 21
3-2 STREETS OF RAGE 2 - Jungle Base
3-Mini Game Level - Sonic the Hedgehog 1 - Special Stage
3-3 Sonic the Hedgehog 2 - Metropolis Zone
3-4 Sonic the Hedgehog 2 - Death Egg Zone
4-1 Donkey Kong Country 2 - Castle Theme
4-2 Super Mario World - Castle Theme
4-Mini Game Level - Contra Hard Corps - GTR Attack!
4-3 Castlevania 4 - Bloody Tears
4-4 Ghoul Patrol - Sir Raleigh McSpirit