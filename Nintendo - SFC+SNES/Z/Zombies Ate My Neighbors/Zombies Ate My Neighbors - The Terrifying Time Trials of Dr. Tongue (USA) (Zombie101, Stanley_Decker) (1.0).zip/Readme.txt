From the creators of Oh No! More Zombies Ate My Neighbors, Zombies Ate My Neigbors The Sequel, and DOOMSDAY bring you The Terrifying Time Trials of Dr. Tongue! not your typical ZAMN hack, DTTT's will have you racing against the clock to save your neighbors, because when time runs out, it's game over!

this hack has:

25 new levels.
new sprites.
new palettes.
new demos.
new gameplay gimmicks.
and more!

~~~~~~~~~~~~~~~~~~
INSTALLATION INSTRUCTIONS
~~~~~~~~~~~~~~~~~~

- Obtain a headerless ROM of the North American version of Zombies Ate My Neighbors (Headerless ROMs have the .sfc extension)
- Download Lunar IPS (http://fusoya.eludevisibility.org/lips/)
- Place both the ROM and the .ips patch inside the Lunar IPS folder.
- Run Lunar IPS and click on "Apply patch"
- A window will pop up. Select the .ips patch.
- A second window will appear. Select the ROM.
- Lunar IPS will apply the patch to the ROM.
-  (Optional) Rename the ROM to "The Tongue Trials" And Play!