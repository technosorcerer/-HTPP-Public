~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                     Greetings Everbody This Is Zombie 101 And Welcome To                                        
                                 DOOMSDAY 2 Day Of Disaster
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   5 Years In Development And Hard Work And It's Finally Complete Thank                                  You All For Your Patience Help And Feedback!.

This Hack Is Meant To Be Harder Than DOOMSDAY 1 Though It Does Also Depend On How Skilled The Player Who Plays It Is That Will Also Determine It's Difficulty.


Very Special Thanks To Piranhaplant For Helping Me get These Features Into The Game.

Adding 1 New Level For A Total Of 57 Instead Of 56.

Later Making Necrofy Public Wich Added The Ability To Add Alot More To The Hack And Helping Get It To Work With The Hack Because Of All The Changes It Kept Crashing It

Making The Monster Frozen Bonus Into A Zero Damage Bonus.

Making The L Button On The Lucas arts Screen Be The Wolf Howling Sound.

Making The R Button On The Lucas arts Screen Be The Chainsaw Rev Sound.

Telling The Game To Go To The Bonus Levels So When You Play What Would Normally Be The Credit Level The Game Would'nt Go To Level 0 And Loop Forever.

Making The Game Play Level 1 Instead Of Level 2 After A Demo Played And You Pushed Start.

Making The BCDF Password Go To The Credit Level.

Making The Beach Tiles Not Glow Or Glitch When Palette Fading.

Helping Move Dr.Tongues Giant Head Palette So The Giant Baby Wouldnt Be Affected As They Share The Same Palette.

Helping With Making The Giant Spider Into The Giant Scorpion.

Helping With Recoding The Titanic Toddler In Level 40 To Not Respawn Causing The Game To Crash.

Making The Snakeoid In Level 50 Drop The Secret Icon Instead Of A Skeleton Key.

For Helping Find The Giant Spiders Palette So I Could Replace It With A New One For The Scorpion.

Making The Tile For Beating Dr.Bug In 25 Into A Diffrent Tile Instead Of Being The Giant Web One.

Changing The Colors Of Game Over.                                                         
Special Thanks To Stanley Decker As Well As Oh No! Came In Handy For This.

Helping To Make A Patch That Recodes Zeke And Julies Palettes To Be Seperate From Eachother When Using A Monster Potion

Recoding The Skeleton Doors For Grass To Not Affect The Giant Spiders Webs And Be Weed Wackable So People Couldnt Get Extra Skeleton Keys

Piranhaplant Thank You For All Of Your Help Time And Patience Without You This Hack Wouldnt Be What It Is.


Special Thanks To Silver exe For Helping Me Figure Out How To Make The UFO Work On Beach Tiles For Level 44 Getting Wolves To Work On Mall And Factory Tiles And Helping Me Set Up One Of The Bonus Levels And For Letting Me Use His Ming Dynasty Palette And Graphics And Editing Some Of My Level Palettes To Look Better.

Special Thanks To BNESS For Help Making The Cabinet Monster Into The Ghost Of Dr Tongue.

Special Thanks To Eva For Helping With The Scorpion Sprites And My Brother For Helping To Figure Out How To Edit It Along With Editing The Giant Heads Sprites.


Plot:
During The Events In DOOMSDAY 1 Dr.Tongue Betrayed Dr.Bug And Left Him For Dead In His Prison As Prey For His Monsters And When Zeke And Julie Were There Stopping Dr Tongue He Begged Them To Help Him But Not Trusting Him They Left Him With The Same Fate As Dr Tongue Did. He Would Have Betrayed Them Anyway.

Thought To Be Dead He Has Spent The Past Few Years Plotting  His Revenge And Making An Even Greater Army Of Undead Demons To Show Dr Tongue That He Is Not Only Better But That He Will Finish What He Started And Get HIs Revenge On Both Zeke And Julie.

This Hack Is Playable On All Emulators For Pc And Android That I Know Of. 


You can check out the trailer for the game here!:
https://youtu.be/1rlce1WYBus?si=NsyKE5ioBDyRmttq

~~~~~~~~~~
Whats New.
~~~~~~~~~~

60 New Levels!
New Zero Damage Bonus!
Reverse Cycling ( Hold L button while going through Item Inventory ) 
New Passwords!
New Points For When All Monsters Are Killed!
New Pick-Ups For All Weapons!
New Points For Almost All Victims And A Few New Sprites For the Numbers That Float Up When They Are Rescued!
New Points for Almost All Bonuses!
New Amounts Of What You Need To Do To Trigger All Bonuses Exept Victim Ones
Some Sprites Have New Palettes!
New Sprites!
Some Monsters Are Harder To Kill!
100+ New Custom Palettes That I Made Thanks To The Help Of Droter And Piranhaplant
These Are For Tiles Sprites And More!
Completely New Drop Table!
The Demos Have Been Edited!

Side Quest For Completionists!
Try To Find The Secret ! Icon Hidden In Every level!  
                                                                                
Look Out!
Dr.Tongues Spirit Has Risen From Hell To Haunt The Cabinets
And Cause Problems And Kill You And Your Neighbors!



 ~~~~~~~~~~~~~~~~~~
 INSTALLATION INSTRUCTIONS
 ~~~~~~~~~~~~~~~~~~
 
 - Obtain a headerless ROM of the North American version of Zombies Ate My Neighbors (Headerless ROMs have the .sfc extension)
 - Download Lunar IPS (http://fusoya.eludevisibility.org/lips/)
 - Place both the ROM and the .ips patch inside the Lunar IPS folder.
 - Run Lunar IPS and click on "Apply patch"
 - A window will pop up. Select the .ips patch.
 - A second window will appear. Select the ROM.
 - Lunar IPS will apply the patch to the ROM and it'll be ready to play!
 - (Optional) Rename the patched ROM to "DD2DOD" for easier identification. 


Special Thanks to everyone who helped 
me on this journey! - Thank you all for your 
guidance, lessons, support and love! 

Thank you to my inspirations, my fans, 
family and friends for all that you've done 
to help me out! 

Thanks to my Big Bro, for installing the 
love of gaming within me. If not for you 
and the ZAMN game, I wouldn't be who 
I am today. Thanks for always playing 
games with me and making me believe 
in my dreams. 

Thank You to:
 
Stanley Decker
(Special thanks to Stanley Decker for helping 
me with making the game start on level 0 instead of 1 and letting me use the soda machine enemy from oh no! and some of it's sprites- Your encouragement 
and kind words meant so much as well!) 
 
Droter 
(Special thanks to Droter for helping with the 
Custom Item Loot table, For letting me use the 
"ZAMN The Sequel" PiranhaPlant, and Droter sprites. 
- Thank you for the support and the kindness you've shown! - and helping me with tile animations and learning how to make Custom palettets And Your Feed Back To Make This Hack Even Greater!) 

Piranhaplant
(Special Thanks for helping me add all of the new changes to this hack)

Silver exe
(Thank you for helping me figure out how to get The UFO working On Beach wolves in malls and factory and getting the bonus level set And The Palettes Edited)

GaryGamerGuy
(Thank You For Playing And Testing The Hack During It's Development It helped to make the hack a better expeirence)

Punching Player Penguin
(Thank you for helping me figure out how to edit the copyright screen)

bone tail
(Thank You For Testing The Hack And Giving Me Feedback To Make The Hack Better)

Espio The Chameleon
(Thank You For Testing The Hack And Finding All Of The Misspeled Titles So I Could Edit Them To Be Correct)

zefennekinfan
(Thank You For Testing The Hack And Giving Feedback To Make It Better For Everyone Who Plays It Along With Finding Issues Like The Chucky In Level 6)

Zamn Girl
(Thank You For Testing The Hack And Giving Me Your Feedback To Fix The Error Like The Chucky Doll And Balance It)

Alex Wesker
(Thank You For Your Feedback And Testing Of The Hack So I Could Balance It Out More And Make It Better)

BNESS
(Thank You For Making The Cabiniet Monster Sprites Into Dr Tongue And Your Support)

Blaze the Cat Sprites by: Cylent Nite And Asuharamoon.

Surge the Tenrec Sprites by: JAN3000MEGA And HYPERWEREFOX.

Tangle The Lemur Sprites by: Kirbysmith.

Whisper The Wolf Sprites by: IGJH.


I Hope You And Everyone Else Who Plays This Enjoys It For Many Years To                                                               Come!  
             Thank You To All Of You For Making One Of The Best And Most                                 Complex Hacks In ZAMN History With Me! Zombie101.