Zombies Ate My Neighbors SNESRAM
Nov 23rd 2022
BillyTime! Games
--------------------

This patch is designed to add a saving mechanism to Zombies Ate My Neighbors for SNES.

How to use
--------------------

Saving:
Game saves after every level.

Game Saves:
Ammo Count for both Player 1 and 2
Item Count for both Player 1 and 2
Current Level

Game Does Not Save:
Squirt Gun Ammo for both Player 1 and 2 (Original Game)
Medikit Count for both Player 1 and 2 (Original Game)

Loading:
Enter password screen, then press start.

NOTE:
Game will produce a black screen if no prior save is detected.

How to Patch:
--------------------
1.Grab a copy of Zombies Ate My Neighbors (USA).sfc
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Apply Patch to rom

How to Patch to other rom hacks:
--------------------
1.Grab a copy of Zombies Ate My Neighbors (USA).sfc
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Apply SNESRAM Patch to rom
4.Apply hack patch to new ZAMN SNESRAM rom

Confirmed Compatible With:
--------------------
Zombies Ate My Neighbors - The Sequel
101 ZAMN
Bloody Disgusting Edition
ZAMN Reverse Inventory Cycling
Zombies Ate my Neighbors Orange Juice
Zombies Ate My Neighbors: Dr Tongue's Revenge