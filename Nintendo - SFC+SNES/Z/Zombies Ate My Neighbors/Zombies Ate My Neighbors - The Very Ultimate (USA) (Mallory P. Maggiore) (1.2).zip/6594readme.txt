The Very Ultimate Zombies Ate My Neighbors, by Mallory P. Maggiore, 2022, 2024

Version 1.2

1.2 Update

*Bonus points fixed, game won't get "stuck" when earning certain end-of-level bonuses.

1.1 Updates

*Water gun pickup changed to blue.
*Graphic changed for flamethrower pickup.
*Bonus levels 4 and 6 now work, and 5 is the correct bonus level.
*Changes made to some levels to make it not so unfair when using a password.
*Small fixes to a few levels.

Zombies Ate My Neighbors hack, SNES

Created February 10, 2022
Updated April 10, 2024

Contact: golden_road15@hotmail.com

Special thanks to ROM Hacking Man for help with some things.