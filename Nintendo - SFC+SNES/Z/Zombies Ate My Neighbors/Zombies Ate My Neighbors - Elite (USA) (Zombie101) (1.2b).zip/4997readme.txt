                   If you are new to this game DO NOT PLAY THIS HACK!

You can if you want but i recommend you play the original one or an easier hack of it.


Greetings everybody this is Zombie101 and this is my latest Zombies Ate My Neighbors ROM hack Elite Zombies Ate My Neighbors and no matter how impossible this hack may seem it is winnable.

Also this hack was not built for password runs as i was gonna remove them completely but i didn't so. If you want to try it good luck.

Special thanks to Stanely for helping me with the boss in 36, without him i wouldn't have been able to make it work i appreciate the time he took to help me with it. 

[WARNING FOR LEVEL 46] 
This Level contains some flashing 
images and lights! - It might bother 
people with sensitive eyes. 


You can check out the trailer for the game at
https://www.youtube.com/watch?v=EIIyAlp_928

~~~~~~~~~~
Whats New.
~~~~~~~~~~

48 New Levels.
6 New Bonus Levels.
No Starting Items
1 New Custom Pallet That I Made Thanks To The Help Of Droter
And More.

 ~~~~~~~~~~~~~~~~~~
 INSTALLATION INSTRUCTIONS
 ~~~~~~~~~~~~~~~~~~
 
 - Obtain a headerless ROM of the North American version of Zombies Ate My Neighbors (Headerless ROMs have the .sfc extension)
 - Download Lunar IPS (http://fusoya.eludevisibility.org/lips/)
 - Place both the ROM and the .ips patch inside the Lunar IPS folder.
 - Run Lunar IPS and click on "Apply patch"
 - A window will pop up. Select the .ips patch.
 - A second window will appear. Select the ROM.
 - Lunar IPS will apply the patch to the ROM and it'll be ready to play!
 - (Optional) Rename the patched ROM to "EZAMN" for easier identification. 


Special Thanks to everyone who helped 
me on this journey! - Thank you all for your 
guidance, lessons, support and love! 

Thank you to my inspirations, my fans, 
family and friends for all that you've done 
to help me out! 

Thanks to my Big Bro, for instilling the 
love of gaming within me. If not for you 
and the ZAMN game, I wouldn't be who 
I am today. Thanks for always playing 
games with me and making me believe 
in my dreams. 

Thank You to:
 
Stanley Decker 
(Special thanks to Stanley Decker for helping 
me to get the boss in 36 working - Your encouragement 
and kind words meant so much as well!) 
 
Droter 
(Special thanks to Droter for helping with the 
Custom Item Loot table, For letting me use the 
"ZAMN The Sequel" Pirana Plant and SkyHurricane 
Joseph K.Sprites. Thanks as well for 
the Custom Background Level Pallettes! - Thank 
you for the support and the kindness you've shown! - and helping me with tile animations and learning how to make Custom palettes) 

SkyHurricane 
(Thank you for the support and for helping me 
out with everything that you did and for pointing 
me to others who could also help me out!)

Joseph K.
(Thank you for helping me get the tile animations working and telling me how to fit them together and testing this hack and helping me move the door in 36 and 48 and for pointing me to others who could also help me out! and all the support you gave me!)

Piranhaplant
(Thank you for helping me get the snakeoid in 22B to drop 2 keys so i could finish this hack)

Silver exe
(Thank you for helping me figure out how to get 36 working)