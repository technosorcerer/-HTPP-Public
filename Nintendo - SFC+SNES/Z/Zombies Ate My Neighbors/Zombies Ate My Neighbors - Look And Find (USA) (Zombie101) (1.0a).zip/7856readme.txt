            Level Layouts, Hex Editing And Some Sprites by me. (Zombie101)       

                             Special Thanks to All my Family And Friends.

Stanely Decker,
Oh No! More Zombies Ate My Neighbors Team,
Pirahaplant,
Skyhurricane,
Droter,
Silver exe,
GaryGamerGuy,
PunchingPlayerPenguin,
Walt95,
bone tail,
Maelstromof Chaos,
Zamn Girl,
Lilian Kage,
Luzvel Video,
Mallory P. Maggiore,
zefennekinfan,
Gia,
Dude 27th,
BN3$$,
Espio The Chameleon,
Izzy Glow,
Alex Wesker,
Yami,
Alex Kidd,
Flamm606,
Everette,
Taebin,
Future Family,
Future Friends.
   
Although I Made This Hack, I Want to Credit My Friend GaryGamerGuy For The Hacks Even Being Made as it Was His Idea And i Just Made The Hack as a Surpise. I Hope You Enjoy Gary And Anyone Else Who Plays it!

The Trailer For This Hack Can Be Seen On My YouTube Here!:
https://youtube.com/watch?v=_1IxlbG_onQ

Changes:
48 New Levels!
No Passwords! They Have Been Disabled!
No Starting Items! Be Careful as When You Start, You Having Nothing!
Reverse Cycling! ( Hold L button while going through Your Inventory. )
New Demos!
New Bonuses!
New Tiles!
Scores Have Been Edited to Work With The New Ones!
Sprites And More!
~~~~~~~~~~~~~~~~~~
INSTALLATION INSTRUCTIONS
~~~~~~~~~~~~~~~~~~

- Obtain a headerless ROM of the North American version of Zombies Ate My Neighbors (Headerless ROMs have the .sfc extension)
- Download Lunar IPS (http://fusoya.eludevisibility.org/lips/)
- Place both the ROM and the .ips patch inside the Lunar IPS folder.
- Run Lunar IPS and click on "Apply patch"
- A window will pop up. Select the .ips patch.
- A second window will appear. Select the ROM.
- Lunar IPS will apply the patch to the ROM and it will be ready to play!
- (Optional) Rename the patched ROM to "LAFZAMN" for easier identification.

Palettes by: Zombie101, Silver exe.

Custom Tiles by: PunchingPlayerPenguin, Silver exe, Zombie101.

Special Thanks to My Big Brother For Helping Test The Hack And For Helping Record The Gameplay Used For The Release Trailer.

Special Thanks to My Big Sister Eva For Helping Test The Hack.

Special Thanks to Stanely Decker For Letting me Use Some Sprites From The Oh No! More Zombies Ate My Neighbors Hack as Well as Some of His Custom Graphics For Inventory Graphics.

Stanely Decker by: Stanely Decker And The Oh No! More Zombies Ate My Neighbors Team.

Piranhaplant And Droter Sprites by: Droter.

Blaze The Cat Sprites by: Cylent Nite And Asuharamoon.

Rouge The Bat Sprites by: ZIG SONAR, Gabriel AKA Frag, DBurraki, Sparks, Dan Sidney, Rathe, Toadkarter, Teamhedghog, Ryuki, Periai And Slip TP.

Judy Hopps Sprites by: SHINY SEABASS.

SpongeBob Sprites by: A.J. Nitro.
Ripped From: Game Boy Advance - SpongeBob SquarePants Battle for Bikini Bottom.

All Rights go to Their Respective Owners.