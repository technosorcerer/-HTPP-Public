Escape The House!
Jun 1st, 2025
BillyTime! Games
--------------------
This patch is turns Zombies Ate My Neighbors into a one level survival mode.

The Goal is for one player reach 20,000 points before being given the option to leave. 
Each character starts with 150 squirt gun shots and a medikit.
Both characters can only recieve two hits before dying and have only one life.

Good Luck!

Further Changes:
High Score SRAM!
Title Screen Demo is disabled
Password and Options menu are disabled
Tweaked Chainsaw Maniac Health
Tweaked graphics

How to Patch:
--------------------
1.Grab a copy of Zombies Ate My Neighbors (USA).md (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file