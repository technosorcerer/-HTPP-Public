﻿			VANILLA ZAMN DOCUMENT

Owing to the nature of this hack, we wrote a document explaining stuff.

This hack is a collaboration between Victor Klein, Alec Rutz, Zombie101, zefennekinfan, and Izzy Glow)

	What this hack is is an attempt of creating a hack not too unlike those you would see in the older days (stuff like Ultimate ZAMN, Oh No! More ZAMN, Skyhurricane’s hacks like Sky’s or Brutal, or even the original version of ZAMN bread). The idea was originally to make a hack on the oldest version of the ZAMN editor so that it would feel like a hack from those days, though Victor insisted on using the most up to date version of the editor (9.6) so that we not only had more stability, but also so that we had access to things like tile animations (think spikes or electricity in castles), and I think the hack is better for it. 
	This hack is basically working with the restrictions of a newbie hacker, who has no knowledge of how to do hex editing to do some fancy tricks and stuff. I feel like with modern hacks, things are so crazy that it can seem intimidating to a newer hacker, in the works right now, Victor has Ultimate Potatoes Mix, Zombie101 has DOOMSDAY 2, and I myself have Troll ZAMN, which feel like monsters to approach, with changes that involve drastically hacking the game to do things beyond what a new hacker could imagine. With the new editor Necrofy also making it so you have to open the hack as a project in Necrofy if you wanna check out the levels, it can make just checking out levels in the editor feel like work. So that’s what this hack does and how it got its name. It’s a more vanilla hack designed to be smol, to show new hackers that you can make something great without monstrous amounts of hex editing. You don’t need custom palettes, tilesets, bananas, reverse item cycling, or changing title screen stuff to make a hack that’s just fun to play at its core.

Think you can beat our scores? :)
Victor: 825463
Alec: 797568
Zombie101: 502528
Izzy Glow: 415444
zefennekinfan: 367234

Good Luck and have fun :)

~~~~~~~~~~~~~~~~~~
INSTALLATION INSTRUCTIONS
~~~~~~~~~~~~~~~~~~

- Obtain a headerless ROM of the North American version of Zombies Ate My Neighbors (Headerless ROMs have the .sfc extension)
- Download Lunar IPS (http://fusoya.eludevisibility.org/lips/)
- Place both the ROM and the .ips patch inside the Lunar IPS folder.
- Run Lunar IPS and click on "Apply patch"
- A window will pop up. Select the .ips patch.
- A second window will appear. Select the ROM.
- Lunar IPS will apply the patch to the ROM and it will be ready to play!
- (Optional) Rename the patched ROM to "VZAMN" for easier identification.