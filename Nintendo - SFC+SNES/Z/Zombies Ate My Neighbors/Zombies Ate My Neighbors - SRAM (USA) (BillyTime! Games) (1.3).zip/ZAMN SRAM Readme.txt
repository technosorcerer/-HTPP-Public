Zombies Ate My Neighbors SRAM
1/29/2021
BillyTime! Games
------------------

This patch allows for Saving and Loading your in game progress as well Items and weapons in Zombies Ate My Neighbors for Sega Genesis.

Saving:
------------------
Game saves upon completing Level 1 (Zombie Panic) at the results screen and every level after.
NOTE: The game will not save if you jump to or back from a bonus/credits level. You must transition to the very next numbered level.

Loading:
------------------
Go to the password screen and press start, your game will be loaded upon hitting start and selecting a character.

Stacking Items:
------------------
If you die on a saved game and start a new game, you can carry over your previous weapons and Items into your new save. Squirt Guns, Lives, and Medkits do not stack and will always default to its starting number. Random Potions Also will not be saved.

XP System (Seprate Patch - 2/25/2025):
--------------------
After ever level, rewards are given based on various score milestones.

100,000 (Free Key per level, Infinite Squirt Gun)
200,000 (Full Health After Every Level)
300,000 (Free Random Potion Per level)
400,000 (Free Health Kit Per Level)
500,000 (Five Free Bazooka Rounds Per Level)
600,000 (Free Monster Potion Per Level)
700,000 (Free Skull Key Per Level)
800,000 (Free Pandoras Box Per Level)

Modified SRAM patch to include saving current scores. Works for both players.


How to patch:
------------------
1.Grab a copy of Zombies Ate My Neighbors (USA).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file 