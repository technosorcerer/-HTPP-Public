Dr. Mario

Turns off the punishment blocks when either
player scores a 2+ combo.




Same IPS patch works on both versions.

No-Intro hashes - Tetris & Dr.Mario

Europe - BCC6F990C2BEFBA0F8AF1FE5DB95B3EC
USA - 73CF4163C3C2B3F8A38775A5D132C448
