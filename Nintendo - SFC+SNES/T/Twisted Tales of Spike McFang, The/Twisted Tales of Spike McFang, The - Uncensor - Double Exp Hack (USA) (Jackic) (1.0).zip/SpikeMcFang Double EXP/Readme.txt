Half Experience Levels for "Twisted Tales of Spike McFang"

What is this?

It is a very simple patch that will make the amount of experience needed to get a new level half of what it previously was.

In the vanilla game, grinding is almost mandatory (unless you are VERY skilled and patient) as the bosses will put you on your place if you get to them under-leveled or under-equipped, that can be frustrating and way too punishing for a game like this, so, if you want to make your progress a little easier, this patch is for you.

How do I use the patch?

Apply it to the rom, ie. using Lunar ips and you are good to go.

The rom in question is:

Twisted Tales of Spike McFang, The (U) [!].smc 

Jackic 2022.