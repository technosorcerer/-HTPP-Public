Shop uncensoring for "Twisted Tales of Spike McFang"

What is this?

It is a very simple patch that change the monster in charge of the shop for the Blondecorn used in the japanese version.

How do I use the patch?

Apply it to the rom, ie. using Lunar ips and you are good to go.

The rom in question is:

Twisted Tales of Spike McFang, The (U) [!].smc 

File MD5      80D1144DC2D6F7AD5BBBCB1DD448B6CF        
File SHA-1    029FD32F8561B7D1EF9EC17384D4E77EA08CD1EA
File CRC32    8C2068D1                                
ROM MD5       80D1144DC2D6F7AD5BBBCB1DD448B6CF        
ROM SHA-1     029FD32F8561B7D1EF9EC17384D4E77EA08CD1EA
ROM CRC32     8C2068D1   

Jackic 2022.