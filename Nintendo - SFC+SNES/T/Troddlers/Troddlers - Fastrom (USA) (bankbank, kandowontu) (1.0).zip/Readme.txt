This is FASTROM for Troddlers (USA)

THANK YOU TO BANKBANK (twitter.com/bankbank) for doing the bulk of the conversion!

SPECIAL THANKS TO ALL MY PATREONS

A SUPER THANK YOU TO MY TOP SUPPORTER:

Matthew Gambrell

EXTRA SPECIAL THANKS TO TOP PATREONS:

RHZ
Sam M.
mobilevil
June M.
Sunrise Redeemer
Wabbajack

Shoutouts to MiSTerAddons for the hardware!

twitter.com/kandowontu
patreon.com/kandowontu
discord.gg/U4CtzqDGa5