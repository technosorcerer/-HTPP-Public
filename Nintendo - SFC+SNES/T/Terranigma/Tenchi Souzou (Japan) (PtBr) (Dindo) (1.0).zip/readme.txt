___________                               .__                                  
\__    ___/______________________    ____ |__| ____   _____ _____              
  |    |_/ __ \_  __ \_  __ \__  \  /    \|  |/ ___\ /     \\__  \             
  |    |\  ___/|  | \/|  | \// __ \|   |  \  / /_/  >  Y Y  \/ __ \_           
  |____| \___  >__|   |__|  (____  /___|  /__\___  /|__|_|  (____  /           
             \/                  \/     \/  /_____/       \/     \/            
____   ______      _____________ ___________    .___.__  __  .__               
\   \ /   /  \    /  \_   _____/ \_   _____/  __| _/|__|/  |_|__| ____   ____  
 \   Y   /\   \/\/   /|    __)    |    __)_  / __ | |  \   __\  |/  _ \ /    \ 
  \     /  \        / |     \     |        \/ /_/ | |  ||  | |  (  <_> )   |  \
   \___/    \__/\  /  \___  /    /_______  /\____ | |__||__| |__|\____/|___|  /
                 \/       \/             \/      \/                         \/ 
                                                                               
---------------------------------------------------------------------------------
                                                                                                                                                             
 Vers�o 1.00           	 Terranigma - Edi��o VWF            	2023-2024

 20.04.2024
 
--------------------------------------------------------------
- SOBRE O JOGO
--------------------------------------------------------------

  Nome: Terranigma
  Plataforma: Super Nintendo
  G�nero: RPG.

  Esse patch modifica o jogo e o estende para uma largura de fonte vari�vel e adiciona o Quintet Quiz novamente.
  O jogo agora est� completamente traduzido, cada cap�tulo foi verificado v�rias vezes.
  Foi adicionado o Patch NTSC que permite que voc� execute o jogo a 60 fps.
  Foram estudados tr�s scripts para essa vers�o, Franc�s, uma retradu��o em Alem�o e foram retirados alguns textos da rom do Orkut.
  N�o foi usado palavr�es. De minha parte, ele est� livre de bugs.

--------------------------------------------------------------
- EQUIPE
--------------------------------------------------------------

  Dindo: Tradu��o Script Franc�s, Revis�o e Romhacking
  Maverick Blue Warrior: Tradu��o Script Alem�o
  Wolfferrow: Revis�o
  RedScorpion: Romhacking
  Rpg Hacker: Mod de sombra na VWF
  Agradecimentos especiais: Taihen e denim
  Arte: Linxkidd

--------------------------------------------------------------
- ANDAMENTO
--------------------------------------------------------------

  Di�logos:             100%
  Objetos, Techs:       100%
  Menu e outros:        100%
  Revis�o do roteiro:   100%
  Gr�ficos:              90%
  Cr�ditos:             100%
  Introdu��o:           100%
  Outros:               100%

--------------------------------------------------------------
VERS�O
--------------------------------------------------------------

  1.00 Vers�o principal xx/04/24


--------------------------------------------------------------
- COMO APLICAR O PATCH
--------------------------------------------------------------

***IMPORTANTE***
  O patch deve ser aplicado na vers�o japonesa do jogo.
  A seguir, encontre o CRC da ROM para aplicar este patch:

    File: Tenchi Souzou (Japan).sfc
    Name: TENCHI-JPN           
    Company: Enix
    Header: None
    Bank: HiROM
    Interleaved: None
    SRAM: 64 Kb
    Type: Normal + Batt
    ROM: 32 Mb
    Country: Japan
    Video: NTSC
    ROM Speed: 120ns (FastROM)
    Revision: 1.0
    Checksum: Good 0x27C6
    Game Code: AQTJ
    CRC32: 3CC7FDF4
    MD5: 5BEC2D7ECF3117B479C69CADA8EBAFA4

  Antes de aplicar o patch, certifique-se de fazer um backup da mem�ria original.
