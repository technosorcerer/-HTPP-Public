This is a patch to convert the PAL version of Terranigma to NTSC.  It removes
the PAL protections, sets the region to USA, and renames the internal name to
"TERRANIGMA USA" as is Enix's designation for a game released in USA.

To install, apply this IPS file to your Terranigma ROM image, which should be 4,194,816 bytes in length.  If your ROM image is 4,194,304 bytes in length, you need to use SNESTOOL to add a header.

If you have any problems, please contact me at BFeely@aol.com