Weapon



Crystal Spear - STR +3 & LUCK +2 - Ice

Hex Rod - STR +5 & DEF +1 - Fire

RA Spear - STR +5 & LUCK +2 - Water

Rock Spear - STR +5 & DEF +3 & LUCK -5 - Earth

Sticker - STR +10 & HP +40 - Thunder

Neo Fang - STR +10 & DEF +3 & LUCK -5

Fire Pike - STR +10 & LUCK +6 - Fire

Bronze Pike - STR +15 & HP +40 

Light Rod - STR +15 & LUCK +4 - Light

Silver Pike - STR +22 & LUCK +4 - Light

Ice Pick - STR +22 & DEF +3 & LUCK -5 - Ice

Soul Wand - STR +22 & HP +50 - Thunder

Sea Spear - STR +30 & HP +40 - Water

Geo Staff - STR +30 & DEF +5 - Earth

3PartRod - STR +30 & LUCK +5 

Frauchard- STR +30 & DEF -3 & STR +3

Trident - STR +40 & HP +40 

Thunder Pike - STR +40 & LUCK +6 - Thunder

X Spear - STR +40 & DEF +5 - Fire

Dragon Pike - STR +40 & DEF -5 & STR +7

Enbu Pike - STR +45 & DEF -5 & STR +7 Earth

Light Pike - STR +45 & HP +50 - Light

Block Rod - STR +45 & DEF +5 - Ice

Alpha Rod - STR +45 & LUCK +6 - Fire

Hero Pike - STR +50



Armor 



Elle Cape - DEF +6 & LUCK +2

Leaf Suit - DEF +6 & HP +40

RA Armor - DEF +8 & LUCK +2

Bird Suit - DEF +10 & STR +3 & DEF -3

Fur Coat - DEF +10 & LUCK +2

Ice Suit - DEF +10 & HP +40

Monk Suit - DEF +15 & HP +40

Ring Mail - DEF +15 & LUCK -5 & DEF +3

Silver Vest - DEF +25 & HP +40

Vest Armor - DEF +25 & LUCK -5 & DEF +3

Posh Suit - DEF +25 & STR +3 & DEF -3

Sea Mail - DEF +30 & HP +40

Nice Suit - DEF +30 & LUCK +5

KungFigi - DEF +30 & STR +8

Silver Armor - DEF +40 & LUCK +6

Soul Armor - DEF +40 & HP +50

Dragon Mail - DEF +40 & STR +7 & DEF -5

Holy Suit - DEF +45 & LUCK +6

King Armor - DEF +45 & HP +50

Red Armor - DEF +45 & STR +7 & DEF -5

Pro Armor - DEF +45 & STR +8

Hero Armor- DEF +50




Boss Weakness



•Shadow Keeper - Fire Immunity (Arms Only)

•Parasite - Fire Weakness

•Dark Twins - Water Weakness

•Storm Keeper - Earth Weakness & Thunder Immunity (First Form Only)

•Dark Morph - Thunder Weakness

•Bloody Mary - None

•Big Fish - Thunder Weakness

•Hitoderon - Water Weakness

•Security Robot - Earth Weakness

•Dark Gaia - None