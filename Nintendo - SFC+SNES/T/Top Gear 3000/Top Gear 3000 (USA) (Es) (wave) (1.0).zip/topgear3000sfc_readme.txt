Top Gear 3000 (Super Nintendo)
Traducción al Español v1.0 (23/01/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Top Gear 3000 (USA).sfc
MD5: 23eaa07e3f3315fa43f4b4d94ec97a7b
SHA1: 058aadf1ee719cb9e0c7333e665797f990a6381d
CRC32: a20be998
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --