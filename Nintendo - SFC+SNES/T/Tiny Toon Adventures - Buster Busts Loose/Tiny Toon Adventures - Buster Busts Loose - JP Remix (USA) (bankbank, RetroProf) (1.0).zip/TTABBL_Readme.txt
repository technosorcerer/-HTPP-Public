Tiny Toon Adventures Buster Busts Loose JP Remix
---

Game: Tiny Toon Adventures - Buster Busts Loose! (USA)
Format: SNES

Created: 3 July 2024

Hacking: Bankbank
Assistance: RetroProf


Key aspects implemented:

1) Reinstated the password for use on Normal difficulty, which was cut by the Konami USA localisation team, and only available for Kids Mode (which truncates levels, losing about 75% of the gameplay). Passwords also work on Hard now too.

2) Reinstating the full ending, with characters in the credits, for Normal difficulty, as it was in Japan. Also applies to Hard and Easy difficulty.

3) Reinstating the password for level 5, Buster's Sky Jinks, since it was disabled in the US release.


Instructions: it's a basic IPS patch. Just use Lunar IPS or whatever to apply it to the (USA) ROM.

You can also apply the Train Bug Fix by KingMike's Translations. This corrects an amusing anomaly if you change the controls, where you get a Game Over near the end of Level 2. The CPU takes over, and assumes dash is still on L and R.

An image showing all the passwords was created specifically, should you need it when playing.

---
History:

This started as an attempt to bring the poorly localised US edition closer in line with the superior Japanese original, but it ended up becoming sort of a remix of both!

The Japanese original had infinite continues, two difficulty levels (Kids and Normal), and a password system which worked across both. The Kids mode had truncated levels, which were between 50% and 75% shorter. So in the Western level, you got up the stairs to follow max and it just ends and goes to the next level, skipping out the long train ride sequence. If you finished on Kids mode you didn't get any ending, just a credits roll with black background. If you finished on Normal you got an ending and the credits showed all the characters doing fun stuff.

The Konami USA localisation added a Challenge difficulty, which is just Normal but with one heart. It also cut the password system for Normal and Hard, so it only works on Kids mode, which is useless since Kids mode loses 75% of the entire game! Meaning you had to finish the entire game in one sitting. It also reduced the continues to 5 for Normal and 3 for Challenge. Plus they locked the nice credits sequence behind the Challenge mode. Oh, and they disabled the password to take you to the fifth level, Sky Jinks.

All in all, it was a trainwreck travesty of a localisation, destroying the delicate balance of the original, adding arbitrary difficulty, locking out the good ending, and removing a useful part of the design - that password system would allow you to replay favourite levels.

Konami did this a LOT back in the day: Bayou Billy, Contra Hard Corps, Contra III, seemingly every game of theirs when coming to the US was deliberately ruined to make it more difficult and less fun.

If you're emulating it won't matter, but I like to play on original hardware. So this needed fixing! 

Bankbank did all the heavy lifting of comparing RAM states, but allowed me (RetroProf) to do just enough to feel like I was helping. It was a fun daylong project.

It now differs from the Japanese version, making it a hybrid remix of both.

The full credits sequence is shown on all difficulties. We had to brute force this to show in Normal, which means it now shows in Kids too.

We left the Hard mode intact because maybe someone likes the challenge.

Since Normal mode did not allow passwords, they would not show up when you selected End at the continue screen (you just went to the title). Fixing this meant inverting the BEQ to a BNE command, so now if you select End on either Normal or Challenge, it displays the password for that level. On Kids mode it now takes you to the title screen. Consider this retribution for the Kids mode being the only mode to show passwords for the last 30 plus years! (Also it was just easier.)

Sky Jinks also had its password disabled, which we've fixed. Konami USA just shunted a bunch of code into various places to disable stuff - they didn't actually delete the recognition of this code. The game recognises it as being correct, but there's some assembly jammed in there saying if it's level 04 (actually lvl 5, but lvl 1 is 00) to ignore the code. So this was replaced with two NOP. Why didn't Konami just remove that code if they didn't want the password to work?

We didn't bother altering the continues. It doesn't matter anyway. With passwords you can just jump to that level. Also the continues just drop you back at the level's start, so there's not much difference between using one or putting the password in. Ultimately, seeing the numbers there is a reminder of what Konami USA did to this poor game. But if you really want infinite continues you can use GGGuy to patch some Game Genie codes.

There's also the PAL, Spanish, Beta, and Korean versions to look at, in case there's anything interesting.

There's a level select in the code, using the Konami code, but it can't be accessed. We considered reimplementing it, but again, now that the passwords work you don't need a level skip.

Finally, the Japanese version had different unique graphics of Babs or Buster in the rings at the end, depending on if you finished Kids or Normal mode, which was replaced in the US version with the title screen graphics. We didn't check to see if the JP graphics were still intact, but this might be something for a later update.

The important thing is the game can now be played on original hardware, using passwords to access levels as it was meant to be. 

Enjoy.
