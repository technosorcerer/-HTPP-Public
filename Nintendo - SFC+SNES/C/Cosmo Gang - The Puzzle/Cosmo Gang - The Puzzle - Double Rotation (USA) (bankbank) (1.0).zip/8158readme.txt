Cosmo Gang The Puzzle SFC double rotation hack

This is a port of an arcade game which only had 1 button, and thus only one direction of rotation for the falling piece. This hack adds a second, opposite-direction rotation by pressing the Y button.

This hack works in both the single-player endless and puzzle modes as well as the versus mode.

Apply the ips patch to an unheadered SNES ROM, the most common filename will probably be "Cosmo Gang - The Puzzle (Japan).sfc". If you have any problems, you can email bank [at] bankbank [dot] net.

Credits:
bankbank - hacking
Wat - testing


v1.0 - first release 
