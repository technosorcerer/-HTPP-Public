Contra III - The Alien Wars (2x Strength)
July. 4th 2025
BillyTime! Games
--------------------
This is a simple patch designed for Contra III - The Alien Wars that doubles the amount of damage inflicted on enemies.

How to Patch:
--------------------
1.Grab a copy of Contra III - The Alien Wars (USA).sfc (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file