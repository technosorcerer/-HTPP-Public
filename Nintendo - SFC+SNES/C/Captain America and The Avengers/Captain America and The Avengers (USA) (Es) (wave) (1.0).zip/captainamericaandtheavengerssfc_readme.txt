Captain America and The Avengers
Traducci�n al Espa�ol v1.0 (12/11/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Captain America and The Avengers
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Captain America and The Avengers
-----------------
Beat em up de los vengadores version snes.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Captain America and The Avengers (U).smc
1.048.576 bytes
CRC32: 456ab5c8
MD5: a3181e27cf6644ef8b67e4316255936c
SHA1: 8634cb94412de777197a462759393c074efff061

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --