Dracula X TouchUp

Created by MathUser2929

Versions

1.0 - First version
1.1 - Touched up the cross sprite.
1.2 - Increased Attack Strength
1.3 - Floor added to Draculas boss room. Holy Cross graphic added.