Ultra ClayFighter is a complete overhaul of the competitive update to ClayFighter, the Blockbuster Championship exclusive Tournament Edition. The parody nature of the series is taken to the next level as inspiration from 28 years of fighting games are referenced, meaning dozens of new moves and a massively improved core gameplay.


Watch the trailer for a visual breakdown of all the new features and examples of the new juggle system!
https://youtu.be/trOPpMf8FGk

Updates include...

- Expanded juggle system embraces the juggle potential of Tournament Edition but adds new combo extension options including hi-strikers, aerial chains and wall bounces 

- Overhauled KO attack system adds Street Fighter style super meter performed with LP+MP based on a super meter shown in early previews for ClayFighter

- Rushdown and mixup options improve with the addition of overheads and low attacks and improved movement options for the entire cast

- Added defensive options allow you to escape wakeup pressure using a tech roll or use a normal or special attack to  create an opening to counter attack or escape with the new attack clash system

- Keep track of your combos with numbered hitsparks or keep an eye on the new combo counter shown directly below your healthbar

- Fully playable and rebalanced N.Boss with new moves previously unused by the final game

- Dozens of new normal and special moves have been added to give characters significantly more depth, some reference other ClayFighter games but hardcore fighting game fans will spot references to games by SNK, ArcSys, Capcom, Midway and others

- Reduced lag and quicker win screens speed up matches to keep the action moving fast

- Tournament mode has become training mode, practice the new combo system, fight against a friend endlessly or quickly check your controls before a tournament match, just press select to exit

- Completely removed dizzy and new damage scaling system script by Streetwize

- Less frustrating CPU and a more varied arcade mode with individual character ladders and new endings
												  
- Restoration of previously unused audio clips for announcer and characters

- In-game character movelists are displayed at single player character select instead of profiles - http://newchallenger.net/w/index.php?title=Ultra_ClayFighter_Tournament_Edition (Full Movelist @ Super Fighting Wiki)

- Recolored stages and 9 unique character color palettes by DangerMD

http://newchallenger.net/UCF/ExampleStageChanges.png - Preview of Stage Colors
																						

http://newchallenger.net/UCF/UCF_colorguide.png - Full - Preview of Costume Colors

- Updates for Tiny and Bonker sprite color mapping by Darth Marino (Originally from ClayFighter TE-Tiny’s Shorts Fix) to fix sprite flaws for cleaner custom colors


See the games full movelist with in depth breakdowns of each characters moves at the Super Fighting Wiki! http://newchallenger.net/w/index.php?title=Ultra_ClayFighter_Tournament_Edition

Watch the North East Championships 2023 tournament for Ultra ClayFighter 3.2! https://youtube.com/playlist?list=PLLkhzJq9cXVwg4JUQGFWUUNV-FoF_doHA&si=WvPCgqvISJ84Dtbx


=======================

Changelog

Bonker
-3 Ring Circus is faster (3.1)

Blob

-Added wallbounce propery to Danger Flop (QCF+K) (3.2)
-Added Blob Volley air chain (MP,HP,HP) (3.2)
-Buzzsaw (Charge B,F+P) has vertical control when performed mid air (3.2)
-Buzzsaw has a cut limit so it can't infinite on big characters (3.1)
-Throw goes higher (3.1)
-Fixed Super KO Blob Bomber issues (3.1)

BSG
-Hair blade command changed to HP+HK (3.2)
-Added Falsetto of Fury (QCB+P) (3.2)
-Increased animation speed of air HP (3.1)
-Reworked air HK (3.1)
-Fixed Air Note crash (3.1)

Frosty
-Super KO Blizzard Breath now okay in midair (3.2)
-Added Avalanche Snowroller (Charge U,D+K) in midair (3.1)
-Fixed projectile crash (3.1)
-Fixed cut at end of round crash (3.1)
-Fixed hit boxes (3.1)

Gold N.Boss
-N.Raged Tornado (QCB+P) has vertical control(3.2)
-Air note (QCB+K) now available midair (3.2)
-Updated hit boxes (3.1)
-Air note (QCB+K) now only shoots 2 notes at a downward angle (3.1)
-New taunt animation (3.1) 
-Teleport has pushback on block (3.1)

Helga
-Added move Flight of the Valkyrie (LP+LK) (3.2)
-Added wallbounce property to Long Yodel (Charge B,F+K) and standing HK (3.2)
-Super KO Diva Drill now okay in midair (3.2)
-Super KO moves backwards at start to hit better (3.1)
-Fixed Helga DOWN palette (3.1)

Icky
-Dart Dive improved (3.1) 

Taffy
-Added Sugar High (MP+MK) (3.1)
-Added Jawbreaker (QCF+K) (3.1)
-Reworked Candy Hard Kick (3.1)

Tiny
-Added wallbounce property to Close MK (3.2) 
-Fixed Hurricane Punch crash (3.1)
-Infinite Neutral air LP P2 fixed (3.1)
-Fixed Command Grab (3.1)

Arcade Mode
-P2 fixed (3.1)

Training Mode
-Training Mode Text Added to Main Menu fully replacing Tournament Mode (3.2)
-Fixed Timeout in training (3.1) 

=======================

Known Issues

N.Boss may cause crashes. 

Problem: When I try to play on my SD2SNES / FXPAK the game freezes when using N.Boss or at random.

SD2SNES / FXPAK hardware has issues with ClayFighter Tournament Edition, by disabling the in-game hook, in-game buttons, and initial holdoff options in the flashcart menu, you will resolve the issue. Learn more @ https://sd2snes.de/blog/compatibility/in-game-hook-compatibility

=======================

Special Thanks to the team that made this all possible!

Zool
Lead Programmer, Gameplay Design, Video Editor and Combo Maker

BillyTime! Games
Programming

Streetwize 
Programming 

ComboKyo
Zero System Creator, Testing and Programming

DangerMD
Color Editor, Lead Artist, Design

DarthMarino
Sprite Updates via Tiny Shorts Hack

IceManual
Color Values for PalMod Editor

Enigami
SNES Consultant

Kosheh
Color Editor and Design

Preppy
Author of PalMod

TSNK
ClayFighter Creative Consultant

Game Testers

- Rockforge 420
- tobemorecrazy
- MysteryJ
- Epsilon Eagle
- Big Bang Blitz
- Vissery
- BonusLizard
- Max'DOutEX
- arturoware
- JamOnAlfajor
- TheBurpMan
- Valen
- BigZam
- GriffyBones
- Starrich55
- Gwak.fr MrQuarate
- Team Best From Now
- PeanutFan22
- Kruddy_Frogurt
- PieLordX
- Ubersaurus
- Jemmillion
- Rolento13
- Climb Cancel
- Kevin
- Frunkopop
- Collosal Chad
- RobbJam
- Kenny
- Comeback386
- Cosmiccopy


Thanks to these fine folks for showing off Ultra ClayFighter and helping to spread the word!

lo-fi, Epsilon Eagle, MysteryJ, Matt McMuscles, Aszaxa, Big Bang Blitz, Frosty Faustings, SNESDrunk, Gwak.fr MrQuarate, Kamekaze, TTTTTsd, Griffybones, TyroneSama, Jemmillion, Big E, EVΛN NIXON TYPE 4, PieLordX, PeanutFan22, Poverty Fiasco

Thank you to everyone who played Ultra ClayFighter 3.1 on Fightcade 2:

3XD, Another Sun, arturowareCL, Aszaxa, Axogogo, BAAAAAATCHEST, BardMetal, BigMalone, Big Steppy, BlackNekoSamurai, BourbonB_TTV, Bumble-BTuna, catsby420, Celestius, CherryPixelBun, Ciid, Claude, CoolassJack, DashiUp, Darkorie, din333, DingDong2k17, donnyterio, duromkl, Evil_Protocol, FunO, gabrn, Gengoza, GlizzyGulper69, HurricanesCape, Heart_Strings, Hig, HurricanesCape, hwzbobcat, ItsValen, Jazie, Jessica123, Jhamok, leechskulls, Linkhell, LinklicZ, Marvelist, Maxx_EZ, Mi abuela en el auto, MoverTile, MR MADNESS, Neco04, NeeloHus, NightWolfxSG, Pkblue888, red ant, Rese T.Ado, RyuHayaBussy, Sartorius_, Serious Hoovy, sodainmycereal, SoloxNasty, slamdonkey, Sticky Ticker, Tahiego, TheBurpMan, TheWildPegasus, treesy, TyphoonTim, usetwohands, quiwantt, viperm, WohMi, wonderfuldeluxe, yacanhateme, YardyHardy

=======================

Zool's ClayFighter Series Combo Videos
https://www.youtube.com/watch?v=1-W_nZs1jKY&list=PLCapQoSDcPKqlLsUxxxLI1QYjBTECMiLa

Want to provide feedback? Reach out to us on Discord to report bugs, look for competition or Find a bug you want to share? Leave us feedback on Discord

ClayFighter Channel @ Super Fighting Discord:
https://discord.gg/FaDh9Axv2t

Claytonic ClayFighter Series Discord:
https://discord.gg/em9JauPabK

Want to know more about Clayfighter history? We suggest you check out the Matt McMuscles "What Happened?" episode:

What Happened? ClayFighter Edition
https://www.youtube.com/watch?v=twp_dQjuDNI

=======================

Included in this package:

The ZERO System Training LUA Script For Bizhawk 2.8 with the BSNES Core - Written by ComboKyo
Ultra ClayFighter v3.1.9.bps
Color Guide