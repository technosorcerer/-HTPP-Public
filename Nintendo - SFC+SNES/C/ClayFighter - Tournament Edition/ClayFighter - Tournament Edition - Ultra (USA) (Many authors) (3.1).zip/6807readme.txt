Ultra ClayFighter is a complete overhaul of ClayFighter Tournament Edition featuring improvements to play mechanics, graphics and adding modern fighting game features like a training mode. Zool, the lead programmer has worked with a dedicated team of fans to document the original ClayFighter series and has inspired many ClayFighter fans with their combo videos.  

http://newchallenger.net/w/index.php?title=Ultra_ClayFighter_Tournament_Edition Full Movelist @ NewChallenger.net Wiki

Watch the trailer for a visual breakdown of all the new features and examples of the new juggle system! https://youtu.be/trOPpMf8FGk

Features Include:

- New systems and fixes including super moves, low/tripping moves, tech rolls, move clashing and movement options full of genre references fans are sure to recognize

- Updated Lifebars HUD to display super meter and combo counter

- Fully playable and rebalanced N.Boss with new moves previously unused by the final game

- New normal and special moves, including powerful Super KO attacks performed with LP+MP

- Updated juggle system featuring hi-strikers, aerial juggles and wall bounces which heavily reward creative combos and skillful play

- Reduced lag overall and completely removed hit effects

- Tournament mode has becoming training mode for practicing the new combo system

- Dizzy system removed

- Completely new damage scaling system script by Streetwize

- Less frustrating CPU and a more varied arcade mode with individual character ladders and new endings
												  
- Restored unused audio clips for announcer and characters

- In-game character movelists are displayed at single player character select instead of profiles - http://newchallenger.net/w/index.php?title=Ultra_ClayFighter_Tournament_Edition (Full Movelist @ Super Fighting Wiki)

- Recolored stages and 9 unique character color palettes by DangerMD

http://newchallenger.net/clayfighter/ExampleStageChanges.png - Preview of Stage Colors
																						

http://newchallenger.net/clayfighter/UCF_colorguide.png]Full - Preview of Costume Colors

- Updates for Tiny and Bonker color mapping by Darth Marino (Originally from ClayFighter TE-Tiny’s Shorts Fix)

=======================

Version 3.1 Changes/Fixes

Bonker
-3 Ring Circus is faster

Blob
-Buzzsaw has a cut limit so it can't infinite on big characters
-Throw goes higher
-Fixed Blob Bomber 

BSG
-Increased animation speed of air HP
-Reworked air HK
-Fixed Air Note crash

Frosty
-New move added
-Fixed projectile crash
-Fixed Cut at end of round crash
-Fixed hit boxes

Gold N.Boss
-Fixed hit boxes
-Air note now only shoots 2 notes at a downward angle
-Special Taunt 
-Teleport has pushback on block


Helga
-Super KO moves backwards at start to hit better
-Fixed Helga DOWN palette

Icky
-Dart Dive improved 

Taffy
-2 new moves
-Reworked Candy Hard Kick

Tiny
-Fixed Hurricane Punch crash
-Infinite Neutral air LP P2 fixed
-Fixed Command Grab

Arcade Mode
-P2 fixed

Training (Tournament) Mode
-Fixed Timeout in training 

=======================

Known Issues

Problem: When I try to play on my SD2SNES / FXPAK the game freezes when using N.Boss or at random.

SD2SNES / FXPAK hardware has issues with ClayFighter Tournament Edition, by disabling the in-game hook, in-game buttons, and initial holdoff options in the flashcart menu, you can will resolve the issue. Learn more @ https://sd2snes.de/blog/compatibility/in-game-hook-compatibility

=======================

Special Thanks to the team that made this all possible!

Zool
Lead Programmer and Gameplay Design

BillyTime! Games
Programming

Streetwize 
Programming 

ComboKyo
Zero System Creator, Testing and Programming

DangerMD
Color Editor and Lead Artist

DarthMarino
Sprite Updates via Tiny Shorts Hack

IceManual
Color Values for PalMod Editor

Enigami
SNES Consultant

Kosheh
Color Editor

Preppy
Author of PalMod

TSNK
ClayFighter Creative Consultant


Game Testers

- Rockforge 420
- MysteryJ
- Epsilon Eagle
- Big Bang Blitz
- Mr. MKL
- That Punk
- Vissery
- BonusLizard
- MaxDOutEX
- Valen
- PlasmaSword
- BigZam
- GriffyBones
- Starrich55
- Conspiratorial
- Gwak.fr MrQuarate
- MelvanainChains
- Climb Cancel
- Team Best From Now
- PeanutFan22
- Kruddy_Frogurt
- tobemorecrazy
- PieLordX
- Ubersaurus
- JoePReal
- DankPasta
- FlynnJeux

Thanks to these fine folks for showing off Ultra ClayFighter and helping to spread the word!

lo-fi, Epsilon Eagle, MysteryJ, Matt McMuscles, Frosty Faustings, SNESDrunk, Gwak.fr MrQuarate, PlasmaSword, Big Bang Blitz, Aszaxa, TyroneSama, TTTTTsd, Kamekaze, Mr MKL, EVΛN NIXON TYPE 4, PieLordX, PeanutFan22, Poverty Fiasco, Doctor Butler, Aaronitmar, sienna, The Fraud Krew

Thank you to everyone who played Ultra ClayFighter on Fightcade 2!

Another Sun, BAAAAAATCHEST, BigMalone, CherryPixelBun, CoolassJack, Evil_Protocol, GlizzyGulper69, HurricanesCape, ItsValen, Marvelist, MoverTile, Neco04, NeeloHus, NeeloHus, Rese T.Ado, Sartorius_, Serious Hoovy, TheWildPegasus, TyphoonTim, bison2winquote, catsby420, donnyterio, leechskulls, quiwantt, wonderfuldeluxe
=======================

Want to keep an eye on for news of the next update or tournament? Find a bug you want to share? Leave us feedback on the ClayFighter channel on the Super Fighting Discord:

ClayFighter @ Super Fighting Discord:
http://www.discord.io/SNESFGC/

=======================

This release is to celebrate being featured in Matt McMuscles "What Happened?" series, if you haven't seen the video we highly suggest you check it out!

What Happened? ClayFighter Edition
https://www.youtube.com/watch?v=twp_dQjuDNI

=======================

Watch this combo video to learn more about ClayFighter Tournament Edition:
https://www.youtube.com/watch?v=0Mg0MVRrSb4

Learn the history of the ClayFighter series here:
https://www.youtube.com/watch?v=ElChcXGQ7w0

Claytonic ClayFighter Series Discord:
https://discord.gg/em9JauPabK