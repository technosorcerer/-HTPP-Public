The Combatribes (2X Damage)
Sept. 21st 2025
BillyTime! Games
--------------------
This is a simple patch designed for The Combatribes that doubles the amount of damage inflicted on enemies.


How to Patch:
--------------------
1.Grab a copy of Combatribes, The (USA).sfc (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file