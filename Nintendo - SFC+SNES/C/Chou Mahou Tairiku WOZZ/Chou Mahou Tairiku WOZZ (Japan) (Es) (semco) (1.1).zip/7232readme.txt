TRADUCCIONESS SEMCO (traduccionessemco.blogspot.com)

Chou Mahou Tairiku Wozz SNES

Traducci�n al Espa�ol v1.1 (03-02-2024)
(C) 2024 semco

-------------------------
SOBRE Chou Mahou Tairiku Wozz
-------------------------
Chou-Mahou Tairiku Wozz es un juego de rol, desarrollado por RED Entertainment y 
publicado por Bullet Proof Software, que sali� a la venta en Jap�n en 1995.
Traducido por Nightcrawler�s Traslation Corp. al ingl�s, y ahora al castellano
por Traducciones Semco.

---------------------
NOTAS
---------------------
Traducci�n al castellano basada en la versi�n en ingles de Nightcrawler�s Traslation Corp.
Se ha modificado la pantalla de t�tulo.
A�adidos signos caracteres especiales ( � � � )y de acentuaci�n.

v1.1
Traducci�n del gr�fico de final de juego (gracias a Vahanian Pascal "Vahanian Pascal "FlashPV")
---------------------
CONTACTO 
---------------------
Si aparece alg�n error o para m�s traducciones

pod�is entrar en:

traduccionessemco.blogspot.com

---------------------------
PARCHEO
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.

La rom a utilizar debe ser: 

Platform           Super NES                               
ROM format         SNES rom image                          
External Header    No                                      
File Size          3145728 (300000)                        
ROM Size           3145728 (300000)                        
ROM CRC32          B3258F38                                
ROM SHA-1          5ABC7F3AB0B705028F9A7D101A68B31E36C4D11C
No-Intro entry     Chou Mahou Tairiku Wozz (Japan)         
Checksum valid     Yes                                     
 

----------------------
CR�DITOS
----------------------
semco - Hacking y traducci�n en castellano.  
FlashPV - Gr�cico del final
Javier CRT - Testeo    

En la versi�n inglesa:

Nightcrawler - Hacking
Jonny - Hacking
Akujin - Translation
Liana - Translation
Ms. Tea - Script Editing/Revision                 
                                                                              