INSTRUCTIONS:
Apply this patch to a Non-Headered Chrono Trigger ROM.  These were made with Floating IPS, though any other patcher that handles BPS patches (most android-based ones for example, or the latest SNES9x�s softpatching capability) should most definitely apply these without issue.

One patch has everything for your convenience, even MSU-1 (if you want to use this, please refer to the readme in the MSU-1 Files folder).  Your patcher will complain to you if you try to use more than one, or if your ROM is not clean (in other words, nothing else can already be applied to it).

Bugfix Alone.bps: Just the main patch.
Bugfix+Name Liberties.bps: Also has the Name Liberties discussed in the �list of changes� file, found in the Docs folder.
Bugfix+Name Liberties+Aerdan Item Names.bps: Name Liberties, plus item names from Aerdian's Chrono Trigger notes.  Discussed in the same place as above.
Bugfix+SkyDark.bps: Also has Sky and Dark elements instead of Lightning and Shadow.  Graphics and text are all changed to reflect this.
Bugfix+SkyDark and Name Liberties.bps: Has both Skydark and Name Liberties.
Bugfix+SkyDark and Name Liberties+Aerdian Item Names.bps: Has Skydark, Name Liberties, and Aerdian's Item Names.

The �Canoe� folder contains a version made specifically for the SNES Classic to run natively.  Note that this is based on an outdated version of SkyDark and Name Liberties.  Please read the text file that�s also in the folder first.
The "Mystics" folder contains a patch made off of the latest Bugfix Alone that changes Fiends back to Mystics.

Compatibility:
Chrono Trigger Platinum is small enough that it doesn�t impact any of the patches listed here at all.  You should be good to go, as no data clashes.  Just your straight difficulty patch if you�d like it.  Apply it after any of these BPS patches.

Anything that messes with events or text most likely won�t work due to text realignment.  At best things will look wonky.  It can�t really be avoided unfortunately.

If there is a bugfix patch out there, chances are that most likely it�s content is already in here.   Plus many that aren�t even in patch form.  The only one  I can even remotely note is Reptite Reshuffle, and I didn�t really see that as a straight bugfix (plus, I�m pretty sure it isn�t compatible in it�s current format anymore).  Ditto with the 5 letter name patch.  I have not tested this at all, so I�m unsure about it�s compatibility with the larger lines.

Old saves made after Mystic Mountain is first visited, I�m sorry to say, aren�t compatible due to CronoNick restoration.

Important offsets for those using this hack for other things:

MSU-1:
0xD5D05-0xD5DA0
0xDF9B9-0xDFFFF

New tiles:
0x41F400-0x41FF71
