This is a special version of Bugfix Alone that changes any mention of Fiends to Mystics.  Fiendlord is uneffected.

I may or may not come back around and do this to the rest of the patches.  Let me know if you'd like to see them.