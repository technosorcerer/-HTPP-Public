
				Chrono Trigger: Enhansa Edition v1.1 Readme

				TABLE OF CONTENTS:

					1. Foreword
					2. Installation
					3. Character Balance
					4. Tech Balance
					5. Items and Equipment
					6. Hacks
					7. Changelog
					8. Acknowledgements
				

---------------------------------------------------------------------------------------------------------



					1. Foreword



---------------------------------------------------------------------------------------------------------


Welcome! I am delighted to present "Enhansa Edition," a comprehensive gameplay mod designed for the
classic SNES game, "Chrono Trigger." My goal was to create an experience that preserves the essence of
the original while incorporating modern RPG sensibilities.

Unleash the power of time as you discover the redesigned combat mechanics, featuring an array of new
status ailments and player Techs. Experience the perfect synergy of the original's nostalgic charm and
innovative enhancements, allowing you to rewrite history in a truly unforgettable way.

Improving on Chrono Trigger is a daunting task. The original game gets so many things right. I have
strived to maintain its fast-paced combat while introducing challenges that will test your skills and
perseverance. Thank you for playing, and I hope you enjoy!


				-inuksuk, June 2023


---------------------------------------------------------------------------------------------------------



					2. Installation



---------------------------------------------------------------------------------------------------------


Enhansa Edition is distributed as an .ips patch file for the US version of the SNES release. In order to
play, you need supply two things: your own Chrono Trigger ROM and also a patching program to apply the
.ips patch file bundled with this download. I use a program called Lunar IPS to patch.

To install the patch:
	
	1. Open Lunar IPS.

	2. Click "Apply Patch" and select the Enhansa Edition .ips patch file.

	3. Select the vanilla Chrono Trigger ROM to be patched. You're done!

I recommmend that you make a copy of your original Chrono Trigger ROM before attempting the patch
process. No other patches should be applied to the ROM. The patch is for an unheadered ROM. That means
your original Chrono Trigger ROM should be 4,096 KB in size. After patching, your Enhansa Edition ROM
will be 6,144 KB.

---------------------------------------------------------------------------------------------------------



					3. Character Balance



---------------------------------------------------------------------------------------------------------


Every effort has been made to bring out the characters' identity through their in-game stats. I like when
character elements are reflected in the game mechanics, and part of that is having the characters play
differently in battle. To that end, HP and MP totals, Stamina and Magic Defense, Hit and Evade, and Power
and Magic have all been adjusted. Hit and Evade, which were near-useless in the original game, are given
new life through a redesign to the Evade formula.

Power, Magic, and Speed Tabs have been removed. Instead, there's an NPC at the End of Time that will
offer boons in exchange for Soda Tabs (which have replaced the old Tabs one-for-one). The boons can range
from stat increases to enhanced Techs to unique equipment. Players choose between two options, preserving
the player's ability to customize the characters like the original Tabs, but without the possibility for
boundless stat growth that the original Tabs allowed.

The boons at the End of Time are available a total of four times throughout the game, based on your story
progress. You won't lose a chance at an upgrade if you don't visit the NPC for a while; he'll wait for
you and track your choices independently. The upgrades he offers are tailored to each character. The
fourth and final upgrade is available once the Black Omen appears. The game doesn't allow you to reset
your choices and apply the boons again, so choose carefully.


---------------------------------------------------------------------------------------------------------


						CRONO
						-----

Crono is a well-rounded character, which is another way of saying he doesn't excel at anything. His stats
are average overall. His high-end gear and strong Techs mean he's still capable of high damage output.
He has access to many powerful Double and Triple Techs and Life can be quite valuable in recovering when
you stumble in battle, so Crono still earns his place on the team.

Upgrades:
	1: Cyclone+ or Magic Bonus.
	2: Power Bonus or Rainbow Cap.
	3: Power Bonus or Magic Bonus.
	4: Double Attack or Magic Bonus.

Magic Bonus increases stats:
   + 4 Magic / 4 Magic Defense / 8 MP

Power Bonus increases stats:
   + 6 Power / 10 Stamina / 40 HP

Cyclone+ increases Cyclone damage by 30%, including in Combo Techs.
Double Attack adds a 50% chance for the Attack command to hit twice.
Rainbow Cap increases the Lightning damage you deal and reduces the Lightning damage you receive.


---------------------------------------------------------------------------------------------------------


						MARLE
						-----

Marle is an excellent support character with her strong healing capability and Haste. In the original
game, her anemic damage output and lack of party healing pushed her into an awkward design space. I've
moved her in a different direction to deal more damage with her bows. Marle's bows will often grant her a
2x damage bonus against appropriate enemy types. Additionally, Cure 2 has been redesigned into a physical
attack Tech called Sky Shot. This keeps her identity as a healer while still allowing her to make strong
contributions to damage dealing in battle. She's a fragile character, however, with the lowest natural
Stamina and HP.

Upgrades:
	1: Hit Bonus or Aura+.
	2: Hit Bonus or Mermaid Cap.
	3: Hit Bonus or Magic Bonus.
	4: Hit Bonus or Magic Bonus.

Hit Bonus increases stats:
   + 4 Hit / 10 Stamina / 40 HP

Magic Bonus increases stats:
   + 4 Magic / 4 Magic Defense / 8 MP

Aura+ additionally applies Regen status to restore HP over time.
Mermaid Cap increases the Water damage you deal and reduces the Water damage you receive.


---------------------------------------------------------------------------------------------------------


						LUCCA
						-----

Lucca has perhaps the highest damage of all the characters until the lategame. Lucca's Guns now apply a
wide variety of status effects, which together with Hypno Wave mean she's often an excellent inclusion in
the part. With Lucca on your team, she'll catch the enemies like a spider in her web, allowing you to
devour them slowly.

Upgrades:
	1: Hypno Wave+ or Magic Bonus.
	2: Stimulants or Replication.
	3: Defense Bonus or Magic Bonus.
	4: Double Attack or Magic Bonus.

Stimulants increase stats:
   + 1 Speed / 10 Evasion

Magic Bonus increases stats:
   + 4 Magic / 4 Magic Defense / 8 MP

Defense Bonus increases stats:
   + 10 Stamina / 10 Evasion / 40 HP

Hypno Wave+ never misses (except against immunity).
Replication adds a 50% chance to repeat a Magic-type single Tech.
Double Attack adds a 50% chance for the Attack command to hit twice.

---------------------------------------------------------------------------------------------------------


						ROBO
						----

Robo takes versatility to the extreme, though he pays for it with lackluster stats. His excellent Techs
mean that he can fill any role you need him to, though he won't be good at all of them simultaneously.
Robo has the lowest natural Magic and Magic Defense stats, paired with the highest Stamina and HP.
Additionally, he can now use almost any equipment in the game. Depending on how you build him, he may
be a walking fortress with nigh-perfect physical defense that struggles with output or a rampaging
berserker who takes shocking amounts of magic damage.

Upgrades:
	1: Laser Spin+ or Defense Bonus.
	2: Damage Bonus or Cure Beam+.
	3: Damage Bonus or Defense Bonus.
	4: Double Attack or Defense Bonus.

Defense Bonus increases stats:
   + 10 Stamina / 6 Magic Defense / 40 HP

Damage Bonus increases stats:
   + 6 Power / 4 Magic / 8 MP

Laser Spin+ increases damage by 30%, including in Combo Techs.
Cure Beam+ additionally restores status.
Double Attack adds a 50% chance for the Attack command to hit twice.


---------------------------------------------------------------------------------------------------------


						FROG
						----

Frog combines physical prowess with exceptional healing ability. His damage potential is held back by a
lack of true lategame damage Techs, although Frog Squash is still good situationally. Masamune's natural
critical rate has been improved to 50%, which reclaims Frog's Accessory slot from the Hero Medal (which
has also been redesigned to work with all of Frog's swords). Slurp now additionally cures status effects
and Slurp Cut can inflict Slow, although the Tech fails against many bosses.

	1: Slurp Cut+ or Water Damage Up
	2: Power Bonus or Magic Bonus
	3: Double Attack or Heal+
	4: Power Bonus or Magic Bonus

Power Bonus increases stats:
   + 6 Power / 10 Stamina / 40 HP

Magic Bonus increases stats:
   + 4 Magic / 4 Magic Defense / 8 MP

Slurp Cut+ increases damage by 30%, including in Combo Techs.
Water Damage Up increases Water damage you deal by 25%.
Heal+ additionally applies Regen status to increase HP over time.
Double Attack adds a 50% chance for the Attack command to hit twice.

---------------------------------------------------------------------------------------------------------


						AYLA
						----

Ayla has come here to chew bubblegum and kick ass. She has naturally lower Stamina and Magic Defense than
Crono, so she tends towards the glass cannon archetype. Most notably, Charm no longer steals items from
enemies. I think Stealing is not a fun mechanic, so it had to die. Kiss now provides a small amount of MP
restore in addition to curing status effects. Triple Kick (along with its associated Dual and Triple
Techs) is still extremely potent. Taking her Power upgrades pushes her into an Evasion build, where
Physical attacks will fail more often but she will lack defenses against Magic attacks.

Upgrades:
	1: Double Attack or Kiss+
	2: Power Bonus or Defense Bonus
	3: Power Bonus or Defense Bonus
	4: Iron Fist or Power Bonus

Power Bonus increases stats:
   + 6 Power / 10 Evasion

Defense Bonus increases stats:
   + 10 Stamina / 4 Magic Defense / 40 HP

Double Attack adds a 50% chance for the Attack command to hit twice.
Kiss+ additionally applies MP Regen status to restore MP over time.
Iron Fist causes critical hits to deal 4x damage with a 12% critical rate.


---------------------------------------------------------------------------------------------------------


						MAGUS
						-----

The dark prince has the last word when it comes to magic damage. He tends to join at a higher level than
the rest of the party and his stats are above average across the board, especially his Magic Defense
which is the highest in the game. He doesn't play nicely with others, however, so you need to
give some consideration to who makes the cut when you bring Magus to the party. Dark Mist has been
redesigned to a single target drain Tech. Magus's toolkit can feel same-y since five of his eight Techs
target the entire screen in the original game. A physical-build Magus can result in some impressive
damage with Doom Sickle if you can plan around keeping his HP ending in 9 (the weapon now has Crisis
Arm's old effect). All according to keikaku*.

Upgrades:
	1: Double Attack or Dark Bomb+
	2: Power Bonus or Magic Bonus
	3: Power Bonus or Magic Bonus
	4: Power Bonus or Magic Bonus

Power Bonus increases stats:
   + 4 Power / 10 Stamina / 40 HP

Magic Bonus increases stats:
   + 4 Magic / 4 Magic Defense / 8 MP

Double Attack adds a 50% chance for the Attack command to hit twice.
Dark Bomb+ increases damage by 30%.

*Translator's note: keikaku means plan.


---------------------------------------------------------------------------------------------------------




					4. Tech Balance



---------------------------------------------------------------------------------------------------------


Endgame Techs have been scaled down in power. In vanilla Chrono Trigger, characters with low Magic got
very high scaling power on their Techs. Thus Magus' ultimate Tech, Dark Matter, was technically outscaled
by "hard-hitters" like Ayla's Tail Spin and Robo's Shock. Techs have been retuned so that you can get an
accurate estimate of how effective a PC will be with magical Techs by looking at their Magic stat. Magus'
Fire2, Ice2, and Lightning2 have also been nerfed to have the same Tech power as Lucca, Marle, and
Crono's respective spells.

Dual and Triple Techs have had their scaling extensively reworked. Vanilla Chrono Trigger was all over
the place on how the combo Techs' damage were calculated. Sometimes they would combine the component
Techs with multipliers, sometimes it's only one of the component Techs, and the multipliers are chosen
seemingly at random. Dual Techs' damage formulas have been standardized to (almost) always be a
combination of the two component Techs with a 0-50% bonus. Triple Techs get a 25% bonus on the component
single Techs.


---------------------------------------------------------------------------------------------------------



					5. Items and Equipment



---------------------------------------------------------------------------------------------------------

Weapons have been lovingly rebalanced. Endgame weapons have been brought closer together in power level.
Marle generally gets 2x damage to particular enemy types. Lucca generally gets added status effects to
particular enemy types. There are weapons that gives +Magic bonuses for most characters, and Robo's Arms
provide various stat bonuses.

Perfect status protection is now only found on the Amulet. Vigil Hats still protect against Sleep, Chaos,
Slow, and Stop although they now provide relatively little Defense. The Aeon Suit/Helms available from
the Ocean Palace are the highest Defense gear, with alternative endgame gear generally trading Defense
for either Magic Defense or status protection. The Red/Blue/White/Black elemental armors that you get
from the Sealed Chests are now unique. That means no doubling up on absorbing elements via time
shenanigans.

Mid Tonic healing has been reduced to 150 and Full Tonic healing has been reduced to 450 (from 200 and
500 respectively). Lapis healing has been reduced to 150 (from 200). Mid Ether healing has been reduced
to 20 and Full Ether healing has been reduced to 50 (from 30 and 60 respectively). These changes are
partly because HP and MP pools are a little smaller compared to the original game, and partly to increase
the relative importance of the healing Techs.


---------------------------------------------------------------------------------------------------------



					6. Hacks



---------------------------------------------------------------------------------------------------------

I've included files for ROM hackers along with this download. Many of the changes I've made to combat
are saved in .asm files meant to be used with asar. For the general audience, I've included a brief
description of each hack here.

Rock-less Triple Techs (by Mauron)
----------------------

This hack is one part of allowing you to use the Rock triple techs without having them equipped. This
hack prevents the game from making you "forget" the Tech when changing scenes without the linked
accessory equipped.


Dual/Triple Tech ATB Delay (by Pseudoarc)
--------------------------

This hack prevents Dual and Triple Techs from applying ATB penalties to the actor PCs. In the original
game, ATB penalties of up to 50% are applied to secondary and tertiary characters in Techs. Penalties
would also be applied to Single Techs and the leader in multi Techs if not for an apparent bug in the
routine that applies the penalty. (The routine doesn't set up a division correctly, returning zero
instead of the intended value.) Rather than "fix" the routine to always apply ATB penalties, we break
the routine to instead never apply ATB penalties.

Double Attack and Double Tech (by inuksuk)
-----------------------------

This pair of hacks allows your Attack and Tech commands to fire twice under some circumstances, like an
upgrade from Toma or an accessory equipped. Double Attack can also affect your counterattacks. Techs can
only double if it's a single Magic-type Tech. Combo Techs will not double.

Fist Upgrade Stopper (by inuksuk)
--------------------

This hack stops Ayla's weapon being upgraded according to Level. Instead, Toma will offer an Iron Fist.
Normally there's a check at the start of combat to automatically upgrade her Fist based on Level/24.

Hit and Evasion (by inuksuk)
---------------

This hack rewrites how Hit and Evasion are used in the Hit/Miss calculation for attacks. Attacks
standardized so that Physical-type attacks will check Evasion but Magic-type attacks always hit. The new
calculation uses "subtractive miss" according to the formula:
	Attack Miss % = (Evade stat - Hit stat) %
If the defender's Evade is good (50) and the attacker's Hit is low (5), the attack will miss 45% of the
time. As in the original game, various status effects can affect the Miss rate.


Haste and Slow Redesign (by inuksuk)
-----------------------

This hack reduces the ATB effect of both Haste and Slow. Haste now applies a 1.5x ATB bonus (was 2x) and
Slow now applies a 0.75x ATB malus (was 0.5x).


HP Down Status Redesign (by inuksuk)
-----------------------

HP Down is of little consequence in vanilla Chrono Trigger, dealing damage at a rate of about 1 per
second. This hack decreases the interval between ticks. This means that the status removes your HP much
faster and will change the character of some fights.


Hero Medal Redesign (by inuksuk)
-------------------

This hack changes what the Hero Medal does. In the base game, if you're wearing both the Hero Medal and
the Masamune your critical hit rate is set to 50%. Instead, the Hero Medal now increases Frog's critical
rate by 25 percentage points with all weapons (from a base rate of 23%).


Lock Enemies (by inuksuk)
------------

When set on enemies, Lock status will now prevent Techs like it does on PCs. This works by loading the
"Berserk" attack script for the enemy when Lock status is set.

Poison Redesign (by inuksuk)
---------------

Poison has been made much more lethal. For PCs and most enemies, Poison deals 1/4 max HP. If Poison would
kill you, you're instead reduced to 1 HP. Poison is much less effective against bosses, dealing 1/40 max
HP. The interval between Poison ticks is now lower than in vanilla. Stamina increases the interval
between ticks, which was also true in vanilla.

Upgraded Techs (by inuksuk)
--------------

This hack allows Toma to offer you upgraded Techs that function differently in battle. It works on the
fly in battle by checking your upgrades when you cast the Tech to change the effect data.


Muscle Ring Redesign (by inuksuk)
--------------------

This hack hooks Muscle Ring into the routines that check for Silver or Gold Earrings and rewrites them
so that Muscle Ring also grants +25% max HP.



---------------------------------------------------------------------------------------------------------



					7. Changelog



---------------------------------------------------------------------------------------------------------

May 17, 2024

	V1.1.2
	______

	Changes from v1.1
	-----------------

• Fixed a bug where Prism Specs were still applying their old 50% damage bonus.
• Item descriptions updated.
• Fixed a bug where trading a Rock accessory to Spekkio locked the door to Nu Toma's room.
• Fixed a bug with the previous bugfix that prevented you from trading Rock accessories to Spekkio.
• Updated several "stale" AI scripts for compatibility with an editor. No gameplay changes.



June 30, 2023

	V1.1
	____

	Changes from v1.0
	-----------------

• Complete overhaul of Nu Toma's upgrade system. Toma offers upgrades tailored to each PC, making choices
	more compelling and build identities more distinct.
• Toma moved into his own room at the End of Time since his rewards have gotten more complex and needed
	their own space.
• Attacks and Techs will now execute twice under various circumstances. Only Magic-type damaging Techs
	are eligible to be doubled. Combo Techs will not double.
• Regen status implemented. Some of your healing Techs can be upgraded to additionally set Regen status.
• Lock will properly lock enemies out of using Techs, the same as it does for PCs.
• Re-designed Magus's Tech "Dark Mist" to be a draining attack named "Vamp".
• Mechanical overhaul of Hit and Evade. The new system applies only to Physical-type attacks (Magic-type
	attacks never miss). The new system uses "subtractive Hit" according to the formula:
		Attack Miss % = (Evade stat - Hit stat) %
	If the defender's Evade is good (50) and the attacker's Hit is low (5), the attack will miss 45%
	of the time. As in the original game, various status effects can affect the Miss rate.
• Battle timers for Poison, HP Down, and Regen now scale with Battle Speed. Zoomers that set Battle
	Speed 1 will get a more comparable battle experience from status effects.
• Setting Regen status removes HP Down status and vice versa.
• Tech handling re-written to allow healing spells to additionally set a status. Technical changes to
	allow healing spells to apply Regen meant that I also had to make changes to Status Recovery,
	Status Impact, and Transfer HP Tech handling.
• Ayla's Fist no longer upgrades with her Level. Nu Toma will offer her an Iron Fist.
• A new Drain damage formula based on attacker HP and not target HP allows for PCs to Drain in battle
	without dealing unreasonably large damage against bosses.
• Added a 10 second break before fighting Lavos after the Zeal -> M. Machine -> Zeal sequence.
• Behind-the-scenes re-organizing of hacky stuff for future me.
• Prism Specs no longer gives a 50% damage bonus. Now adds 50% chance to double an Attack or Tech,
	adding together with any bonus from Toma.
• Silver Stud and Gold Stud changes reverted to vanilla behaviour. Silver Stud again cuts MP use by 1/2,
	Gold Stud again cuts MP use by 3/4.
• Bugfix for the hack that removes ATB penalties from combination Techs.
• Changes to many PC/enemy Techs to e.g. standardize "Always Hits" flags and status application rates.


December 23, 2021

	v1.0 Release Complete Notes
	___________________________

	Event Changes
	-------------

• A Nu has moved in to Spekkio's room at the End of Time. He's friendly and wants to help you. Original
	Sprite design by Wightraven. Thank you for your help, Wightraven!
• Power, Magic, and Speed Tabs are now Soda Tabs.
• Spekkio has started a rock collection. Bring Spekkio any Black, Silver, White, Blue, or
	Gold Rocks that you find. Once your PCs have learned their prerequisite single Techs, Spekkio
	will teach you the Triple Tech from the Rock permanently. White Rock has been moved to Beast's
	Nest (was Black Omen).
• Spekkio will reveal his true, Pink form if the player collects all five Rock accessories. His sprite
	won't update until you reload the map. Please don't try to actually beat him, it's more of an
	Easter egg for players who wanted to see it without leveling to 99 as required in vanilla. (I
	can at least recommend waiting around until he casts Luminaire.)
• Red/Blue/White/Black Vests removed. The stronger Mails remain. It's no longer possible to double up
	on Sealed Chest items by opening them in both eras. This is also true of the Hero's Grave Sealed
	Chests. This was done because doubling up on elemental absorption was too strong, and also to cut
	out the tedium of collecting them.
• Lucca gets equipped with a new gun when she appears during the prison break sequence.
• Taban awards new items alongside his gifts to Lucca. There's a FlameArrow for Marle with the Taban
	Vest, a BlastGuard for Robo with the Taban Helm, and an Umbrella with the Taban Suit.
• Spekkio's walking test to learn magic has been removed. Just talk to him again to pass.
• Norstein Bekkler doesn't demand any Silver Points to advance the story.
• Frog, Ayla, and Crono are equipped with some dummy gear when they leave your party as part of the story
	so that any gear you might want from them ends up back in your inventory.


	Battle Changes
	--------------

• A newly designed Regen status has been implemented. Marle's Aura and Frog's Heal can be upgraded to
	additionally set Regen.

• Applying Lock to enemies now prevents them from using Techs.

• Haste now applies a 1.5x ATB bonus (was 2x). Slow now applies a 0.75x ATB malus (was 0.5x).

	Motive: Haste and Slow had enormous effects on combat. Now they are not so extreme.

• Dual and Triple Techs no longer have ATB maluses.

	Motive: This was a half-baked mechanic from vanilla. Some participants of dual and triple Techs
	would get a penalty so that their next turn would come slower. Interestingly, if not for a bugged
	division routine in the calculations, there would always be an ATB penalty applied to Techs.
	Rather than fix the bug and slow down combat when using Techs, the penalty never applies now.
	This change is thanks to Pseudoarc. Read more about it at:
	https://www.chronocompendium.com/Forums/index.php?topic=13512.0

• Poison now deals 25% max HP per tick, reducing your HP to a minimum of 1. Bosses take less
	damage from poison (2.5% max HP). Stamina increases the interval between ticks.

• HP Down status reduces HP every (Stamina/8)+3 frames (was every 25 frames)

	Motive: Assuming the player leaves the Battle speed at its default 5 in the Config menu, Poison
	and HP Down are relevant status effects now. Faster Battle speeds result in less damage being
	dealt by Poison and HP Down, since fewer frames are required to fill the ATB gauge.

• Blind status no longer prevents enemies from counterattacking.

	Motive: There was no way to set Blind on enemies in vanilla, so this never would have come up.
	This allows Blind to only apply a 75% penalty to accuracy as intended. Lock set on enemies will
	still prevent them from counterattacking.



	Technique Changes
	-----------------

• Name changes:
Marle's "Cure 2" is now "Sky Shot".
Lucca's "Protect" is now "Shield".
Robo's "RocketPunch" is now "RocketFist".
Robo's "DoublevBomb" is now "Double Bomb".
Magus's "Dark Mist" is now "Vamp".
Magus's "Magic Wall" is now "Barrier".
Marle and Ayla's "Twin Charm" is now "X O X O".
Lucca and Ayla's "Fire Whirl" is now "Inferno".
"Ice Sword 2" and "FireSword 2" will display correctly in battle dialogue when you learn the Tech.

	Motive: Cure 2 and Twin Charm have been redesigned, so they get a new name to match. Protect and
	Magic Wall were renamed to align all the effects to use the same terminology (items, equipment,
	and Techs). "Fire Whirl" is already in use by Crono and Lucca, so we use the DS translation's
	"Inferno" instead. RocketPunch got changed because I wanted a leading space in the name and it no
	longer fit. DoublevBomb, I think, is supposed to mean something like W-Bomb. But plain old Double
	Bomb gets the meaning across just fine without being confusing, and is what later translations
	use.

• All Techs that use Magic for their damage scaling are now marked with a star in the Tech menu.
Previously, only the Techs that Spekkio considered to be magical in nature were marked.

	Motive: I wanted to communicate that some of Lucca's Techs were now scaling with Hit instead of
	Magic, so the Star icon has a slightly different meaning than it does in vanilla. Tech names were
	marked with a Star more or less if Spekkio considered the Tech magical or not. Now, the Star
	communicates mechanical information that the Tech uses your Magic stat for damage.

• Crono's Lightning tech power reduced to 11 (was 12).
	Motive: Fire, Ice, and Water all have 11 tech power. Crono's not special.
• Crono’s Slash deals non-elemental magic damage (was Lightning element).
	Motive: Reptites' counter-attack scripts had a carve-out so that Slash wouldn't Shock them. That
	space in their script is used for other things now. It also doesn't look like lightning ¯\_(ツ)_/¯
• Crono's Luminaire tech power reduced to 34 (was 50). MP cost reduced to 17 (was 20).
	Motive: Magic-build Crono doesn't pair Luminaire with anyone, which left his ultimate Tech under-
	utilized. The tech power is the same as Dark Matter, and slightly ahead of Flare and Shock that
	are at 32. The MP cost reduction to 17 helps Crono cope with his modest MP pool.

• Marle's Aura tech power increased to 8 (was 5). Now also restores status. MP cost increased to 2.
	Motive: With status effects more common, the player is given more ways to remove them.
• Marle's Provoke success chance increased to 100% (was 80%).
	Motive: This hack is all about making status effects relevant. Some enemies are immune to Provoke
	so a built-in chance of failure is unacceptable.
• Marle's Cure tech power reduced to 12 (was 14). MP cost increased to 4 (was 2).
	Motive: Cut down endgame scaling. Healing Techs are more expensive now.
• Marle's Cure 2 redesigned to Sky Shot.
	Motive: Cure 2 was mostly redundant on Marle.

• Lucca's Hypno Wave base success chance increased to 70% (was 60%).
	Motive: ~60% success rate made Hypno Wave betray the player too often on tougher encounters.
• Lucca's Napalm tech power reduced to 9 (was 12). Added 80% Chaos effect.
	Motive: Fire now does more single target damage than Napalm.
• Lucca's Shield now targets the whole party and costs 13 MP (was 6 MP).
	Motive: Multi-targeting makes the Tech a significant improvement over the Shield item.
• Lucca's Mega Bomb tech power reduced to 24 (was 32).
	Motive: Cut down endgame scaling.
• Lucca's Flare tech power reduced to 32 (was 42).
	Motive: Cut down endgame scaling.

• Robo's Rocket Fist tech power increased to 12 (was 11). Added 100% Blind effect.
	Motive: Rocket Punch was awful.
• Robo's Cure Beam tech power reduced to 10 (was 14).
	Motive: Robo has to live with the consequences of having low Magic.
• Robo's Heal Beam tech power reduced to 8 (was 10). MP cost increased to 5 (was 3).
        Motive: Robo has to live with the consequences of low Magic. Healing Techs are more expensive.
• Robo's Area Bomb tech power reduced to 24 (was 30).
	Motive: Cut down endgame scaling.
• Robo's Shock tech power reduced to 32 (was 40).
	Motive: Cut down endgame scaling.

• Frog's Slurp now restores status in addition to the HP restore. MP cost increased to 2 (was 1).
	Motive: With status effects more common, the player is given more ways to remove them.
• Frog's Slurp Cut tech power increased to 12 (was 11). Added Slow effect.
	Motive: Damage was low. Slow effect adds lategame viability.
• Frog's Heal tech power increased to 8 (was 6). MP cost increased to 5 (was 2).
	Motive: More healing is more better. Healing Techs are now more expensive.
• Frog's Cure 2 tech power reduced to 14 (was 24). MP cost increased to 6 (was 5)
	Motive: No more automatic full heals. Your Magic stat matters.
• Frog's Frog Squash tech power increased to 14 (was 10).
	Motive: It's hard to use so it should be rewarding. Also compensates for Frog's lower Stamina
	compared to vanilla Chrono Trigger.
• Frog now requires 40 tech points to learn Heal (down from 160).
	Motive: I wanted it available for Slash and Flea.

• Ayla's Kiss redesigned to restore MP rather than HP. It still restores status.
	Motive: Kiss fills a new niche and Ayla provides a different kind of support.
• Ayla's Rock Throw tech power reduced to 27 (was 30).
	Motive: Rock Throw dual techs were too powerful. Rock Throw's usefulness is slightly mitigated
	by failing on flying and special enemies, but it's still a very efficient use of MP.
• Ayla's Charm redesigned to be a weak magic attack that inflicts Sleep.
	Motive: Stealing is not a fun mechanic.
• Ayla's Tail Spin tech power reduced to 32 (was 40).
	Motive: Low Magic has consequences.
• Ayla's Dino Tail tech power increased to 12 (was 9).
	Motive: Situational Tech gets its power increased. Also compensating for Ayla's lower Stamina
	compared to vanilla Chrono Trigger.
• Ayla's Triple Kick tech power reduced to 34 (was 37).
	Motive: Cut down endgame scaling.

• Magus' Lightning 2, Ice 2, and Fire 2 tech power reduced to 14 (was 18).
	Motive: Brought Magus' version of the spells in line with Crono, Marle, and Lucca's.
• Magus' Barrier targets the whole party and costs 13 MP (was 8 MP).
	Motive: Multi-targeting makes the Tech a significant improvement over the Barrier item.
• Magus' Dark Matter tech power reduced to 34 (was 38).
	Motive: Cut down endgame scaling. Now the actual ultimate magic Tech (along with Luminaire).

• Crono and Marle's Ice Sword 2 deals 125% damage (was 100%).
• Crono and Lucca's Fire Sword 2 deals 125% damage (was 100%).
• Crono and Robo's Rocket Roll deals Cyclone + Laser Spin damage (was Laser Spin*1.5).
• Crono and Robo's Max Cyclone deals (Spincut + Laser Spin)*1.25 damage (was Spincut*2).
• Crono and Frog's Spire deals (Lightning 2 + Leap Slash)*1.5 damage (was Lightning2*2 + Leap Slash).
• Crono and Ayla's Drill Kick deals (Cyclone + Rollo Kick)*1.25 damage (was Rollo Kick*1.75).
• Crono and Ayla's Volt Bite deals (Lightning + Cat Attack)*1.25 damage (was Cat Attack*2).
• Crono and Ayla's Falcon Hit deals Spincut*1.5 damage (was Spincut*2 damage).
	Motive: Falcon Hit was extremely powerful considering how early it is available. Damage remains
	as a function of Spincut to avoid it failing as Rock Throw would on some enemies.
• Marle and Lucca's Antipode deals (Ice + Fire)*1.25 damage (was Ice + Fire).
• Marle and Robo's Cure Touch heals with Cure (was Cure 2).
	Motive: Marle's Cure 2 was removed.
• Marle and Frog's Double Cure heals to full and cures status (was a full heal).
	Motive: More status healing is more better.
• Marle and Ayla's X O X O heals the party with Cure.
	Motive: Marle needs some party healing to help her heal in parties without Robo or Frog.
• Marle and Ayla's Ice Toss deals (Ice + Rock Throw)*1.25 damage (was Ice + Rock Throw).
• Marle and Ayla's Cube Toss deals (Ice 2 + Rock Throw)*1.5 damage (was (Ice2 + Rock Throw)*1.25).
• Lucca and Frog's Line Bomb deals (Mega Bomb + Leap Slash) damage (was Mega Bomb).
• Lucca and Ayla's Inferno deals (Fire 2 + Tail Spin)*1.25 damage (was 50% bonus).
• Robo and Frog's Blade Toss deals (Laser Spin + Slurp Cut)*1.25 damage (was Slurp Cut*2).
• Robo and Frog's Bubble Snap deals (Robo Tackle + Water)*1.5 damage (was Robo Tackle*2).
• Robo and Frog's Cure Wave heals to full and cures status (was a full heal).
	Motive: More status healing is more better.
• Robo and Ayla's Spin Kick deals (Robo Tackle + Rollo Kick)*1.25 damage (was Rollo Kick*2).
• Frog and Ayla's Slurp Kiss restores with Kiss (was Kiss*2).
	Motive: Kiss was redesigned. Now Slurp Kiss restores the party's MP.
• Frog and Ayla's Bubble Hit deals (Water + Rollo Kick)*1.5 damage (was Rollo Kick*2).
• Frog and Ayla's Drop Kick deals (Leap Slash+Triple Kick)*1.25 damage (was Leap Slash*1.5+Triple Kick)
• Crono, Lucca, and Robo's Fire Zone deals (Spincut + Fire 2 + Laser Spin)*1.25 damage (was Spincut*2 +
Fire2*1.25).
• Robo, Frog, and Ayla's Spin Strike deals (Leap Slash + Robo Tackle + Tail Spin)*1.25 damage
	(was Leap Slash*4).
• Marle, Robo, and Frog's Grand Dream deals Frog Squash*3 damage (was Frog Squash*2).


	Equipment and Item Changes
	--------------------------

• Many item descriptions edited to provide more information to the player.
• Name changes:
	"Lode Bow" is now "Bolt Bow"
	"Robin Bow" is now "Mystic Bow"
	"Sage Bow" is now "Ruby Bow"
	"Auto Gun" is now "Mystic Gun"
	"Stone Arm" renamed to "Ruby Arm"
	"Magma Hand" renamed to "Dream Hand"
	"Gold Helm" renamed to "Rainbow Cap"
	"Glow Helm" renamed to "Mermaid Cap"
	"Safe Helm" renamed to "Barrier Cap"
	"Sight Cap" is now "Reason Cap"
	"Mermaid Cap" is now "Umbrella"
	"Power Tab" is now "Soda Tab"

	Motive: Bow and Gun names changed to reflect their new capabilities.
	Robo's prehistory weapons changed to match.
	Reason Cap is named to give some indication to its function.

• Robo can now equip almost every piece of gear. Crono's swords are not available due to graphical bugs.
• Many pieces of equipment have been redesigned or adjusted:
Bolt Sword now deals 150% damage to machines (was nothing)
Star Sword now adds +4 Magic (was nothing)
Shiva Edge now 10% critical rate (was 7%)
Swallow now adds +6 Power (was +3 Speed)
Slasher 2 now adds +3 Speed (was nothing)
Rainbow attack reduced to 210, critical rate reduced to 50% (was 220, 70%)

	Motive: Star Sword is Crono's +Magic weapon--almost everyone gets one now. Shiva Edge's crit
	rate brought up to be in line with other swords, especially considering the 4x critical bonus.
	Swallow gets a considerable power bonus (since that's what the Nu says it does) instead of
	giving a Speed bonus. Slasher 2 gives a Speed bonus, because that's what the Slasher should do.
	Rainbow nerfed because Crono doesn't get to be the best just because he's the protagonist.

Bolt Bow's attack increased to 25 (was 20). Now deals 2x damage to Machines.
Mystic Bow's attack increased to 30 (was 25). Now deals 2x to Magic enemies.
FlameArrow (new item from Taban) has 30 attack. 2x damage to Undead.
Ruby Bow now adds +2 Magic (was nothing).
Dream Bow attack increased to 70 (was 60). Critical hits deal 4x damage (was nothing).
CometArrow attack increased to 90 (was 80). Now deals 2x to Magic enemies (was nothing).
SonicArrow attack increased to 110 (was 100). Now adds +4 Magic (was nothing).
Siren now deals 2x damage to Exotic enemies (that is, Lavos-related enemies).
Valkerye attack increased to 190 (was 180). Now deals 2x damage to Exotic enemies (was nothing).

	Motive: Early game bows increased in power to match the boys' weapons. Marle deals double damage
	to select enemy types. +Magic stats added to some weapons.

Dart Gun's attack increased to 10 (was 7).
Zonker-38 (new weapon) has 20 attack. 80% chance of sleep to biological enemies.
Mystic Gun (was Auto Gun) has 30 attack. 80% chance of Lock to Magic enemies.
Ruby Gun now adds +2 Magic (was nothing).
Dream Gun attack increased to 80 (was 60). Now has WonderShot damage effect (was nothing).
Megablast attack increased to 90 (was 80). Inflicts random status (was nothing).
Shock Wave now adds +4 Magic (was nothing). No longer has 60% chance to inflict confuse.

	Motive: Early- and mid-game Guns increased in power to match the boys' weapons. Lucca applies
	status effects to select enemy types (and later to all enemy types). +Magic stats added to some
	weapons.

HammerArm now adds Power +2 (was nothing).
MirageHand now adds +30 Evade (was nothing).
Ruby Arm now adds +5 Magic Defense (was nothing).
DoomFinger now adds +4 Power (was nothing).
Dream Hand now adds +5 Magic Defense (was nothing).
Megaton Arm now adds +6 Stamina (was nothing).
Kaiser Arm attack increased to 135. Now adds +6 Strength (was nothing).
Giga Arm now adds +6 Stamina (was nothing).
Terra Arm attack increased to 170 (was 150). Now adds +10 Power/Stamina (was nothing).
Crisis Arm crit rate increased to 10% (was 5%). Now adds +5 Magic Defense. Crisis Arm uses the
	"attack up when allies fall" effect that was on the Doom Sickle in the vanilla game.

	Motive: Robo can now equip almost every weapon in the game, so his arms have offensive and
	defensive stats to give him a reason to use his own weapons. Terra Arm buffed to bring it closer
	to other endgame weapons. I swapped the damage effects on Doom Sickle and Crisis Arm to give
	Magus a more viable way to deal physical damage. Robo retains access to the Doom Sickle, so he's
	not giving anything up.

Masamune1 crit rate increased to 50% (was 23%).
FlashBlade deals 150% damage to Magic enemies (was nothing).
Pearl Edge no longer deals 150% damage to Magic enemies.
Demon Hit can no longer be found in the Ocean Palace.
Masamune2 attack increased to 210 (was 200). Crit rate increased to 50% (was 23%).

	Motive: Masamune's crit rate is increased to give the player room not to use the Hero Medal. I'll
	mention here that the Hero Medal was changed to work with all weapons, not just the Masamune.
	Further details in the accessory section below.

Hurricane now adds +4 Magic (was nothing)
Star Scythe critical hits deal 4x damage (was nothing). Critical rate increased to 20% (was 10%).
Doom Sickle deals damage based on the ones digit of your HP. 9 is best, 0 is worst.

	Motive: Hurricane provides Magus' +4 Magic boost, while Star Scythe and Doom Sickle give Magus
	some oomph when attacking.

Lode Vest defense decreased to 70 (was 71).
Aeon Suit defense increased to 85 (was 75).
Zodiac Cape defense reduced to 71 (was 80).
Nova Armor defense reduced to 71 (was 82). Now adds +30 Evade (was status immunity).
Prism Dress defense reduced to 90 (was 99). Now adds Shield (was Barrier) and cuts elements 50%.
Moon Armor defense reduced to 71 (was 85).
Gloom Cape now adds +5 Magic Defense (was nothing).
White/Black/Red/Blue Mail now absorb 25% of their element (was 100%).
BlastGuard (new item from Taban) provides 45 defense, +1 Speed, 50% Fire resistance for Robo.
Lumin Robe defense decreased to 50 (was 63).
Dark Mail defense increased to 54 (was 45). No longer adds magic defense.
Mist Robe defense decreased to 45 (was 54). Now adds Magic Defense +5 (was nothing)
BronzeMail defense increased to 18 (was 16).
MaidenSuit defense decreased to 16 (was 18). Now adds Magic Defense +5 (was nothing)

	Motive: Lode Vest's defense decreased to move it farther down the list of gear. Aeon Suit has
	the highest defense of the endgame gear, but provides no other benefits. Zodiac Cape, Nova
	Armor, and Moon Armor all provide some Magic Defense at the expense of regular defense. Prism
	Dress' defense was slightly reduced, but it now provides innate Shield and excellent elemental
	protection. Early and midgame Male/Female gear made more distinctive with boys' armor providing
	more defense and girls' armor providing more MDef.

Aeon Helm defense increased to 45 (was 33).
Prism Helm defense decreased to 35 (was 40). No longer provides status immunity.
Doom Helm defense increased to 34 (was 29).
Gloom Helm defense decreased to 35 (was 42). Now provides limited status immunity (was all).
Safe Helm redesigned to Barrier Cap. Now grants Barrier (was Shield).
Vigil Hat defense reduced to 26 (was 36). Now provides limited status immunity (was all status).
Haste Helm defense reduced to 30 (was 35).
Life Helm has 30 defense. Provides Sleep immunity.
Umbrella (new item from Taban) has 25 defense. Cuts Water damage 50%.
Beret and Cera Topper (female exclusive) now add +1 Speed (was nothing)

	Motive: Aeon Helm has the highest defense of all the gear, but provides no other benefits. No
	armor provides perfect status immunity now. The Forest Ruins Nu offers a Barrier helmet rather
	than a Shield helmet now to give the player some earlier access to Barrier. Prism Helms now grant
	Shield in addition to some Magic Defense. Other helms provide limited status immunity at the
	expense of defense. Early and midgame female gear made more distinctive by providing +Speed for
 	slightly less defense.

Hero Medal now adds 25% to critical rate for all of Frog's swords.
Muscle Ring now adds 25% to max HP in addition to +6 Stamina (was +Stamina only).
Rock accessories can't be equipped. Read 'Events' for more info.

	Motive: Masamune gets a native 50% crit now to reclaim Frog's accessory slot without punishing
	him. This redesign makes Hero Medal more useful in a wider variety of situations. Muscle Ring was
	never the right decision in vanilla with such a small effect. As for the Triple Techs linked to
	the Rock accessories, Spekkio will now teach the Tech permanently so that you don't need to
	sacrifice an accessory slot to use the Tech.

Mid Tonics now heal for 150 (was 200).
Full Tonics now heal for 450 (was 500).
Lapis now heals for 150 (was 200).
Mid Ethers now heal for 20 (was 30).
Full Ethers now heal for 50 (was 60).
Nu Toma gives out Tarot cards to track how many times each character has been upgraded: The Fool for
	Crono, The Lovers for Marle, The Sun for Lucca, The Hanged Man for Robo, Justice for Frog,
	Strength for Ayla, and The Devil for Magus.

	Motive: HP and MP pools are somewhat smaller compared to vanilla Chrono Trigger, so item healing
	has been scaled back slightly along with it. This also emphasizes Tech healing over item healing.
	Giving out items was the easiest way I could think of to track how many times you'd traded your
	Soda Tabs in. Thank you to the Tarot Card project on Chrono Compendium, from which I lifted the
	card selections. Check it out at https://www.chronocompendium.com/Forums/index.php?board=98.0


	Enemy Changes
	-------------

• Some names have been changed:
	"Naga-ette" is now "Naga"
	"Hench" is now "Grump"
	"Reptite" is now "Grunt"
	"Sorcerer" is now "Efreeti"
	"Mega Mutant" is now "Masa Mutant"
	Mega Mutant's base is now "Mega Mune"
	"Giga Mutant" is now "MagusMutant"
	Giga Mutant's base is now "Giga Golem"
	"Terra Mutant" is now "Terra Brain"

	Motive: Naga-ette sounds stupid. Naga are traditionally female anyway. Hench and Reptite were
	each used for two separate enemies, so the earlier appearances got renamed to Grump and Grunt
	respectively. Efreeti is more in theme with the names of the later Ocean Palace versions of the
	sprite. The Mutant fights in the Black Omen were redesigned, so they got new names to match.

• Many enemies' stats and AI scripts were touched. I have a truly marvelous proof of this, but the
	margins of this Readme are too narrow to contain it.


---------------------------------------------------------------------------------------------------------



					8. Acknowledgements



---------------------------------------------------------------------------------------------------------


I'd like to thank the Chrono Compendium and New Game Plus communities, without which this mod would not
exist.

Special thank you to Mauron, who has very kindly answered many of my questions over the past years.
Mauron was especially helpful as I got started modding, showing great patience with my list of questions.

Thank you to BTB and Synchysi, who in many ways inspired this mod and have given me great advice.

Thank you to the hacker brain trust that hangs out around New Game Plus, whose experience has been a
great help. SNES assembly can be intimidating to learn and you all made the process much easier for me.

Thank you to Wightraven for creating the Nu Toma sprite. That moustache is so powerful.

Thank you to the authors of the tools I used to make the mod:
	Geiger, the creator of Temporal Flux
	Mauron, the creator of many plugins for Temporal Flux
	FuSoYa, the creator of Lunar IPS


---------------------------------------------------------------------------------------------------------



				Appendix A: inuksuCoin leaderboard



---------------------------------------------------------------------------------------------------------


I am very grateful to those who have taken a chance on playing my mod and have given me feedback! As a
way to recognize my wonderful players (read: troubleshooters) I've been keeping track of their more
notable Quality Assurance contributions.

Scoring system:

	-Alpha hack testing			3 inuksuCoins
	-Find a major bug			3 inuksuCoins
	-Find a minor bug			2 inuksuCoins
	-Soda Tab related (retired)	   1 or 2 inuksuCoins


Leaderboard:
	 1. Wightraven				17 inuksuCoins
	 2. Julford				15 inuksuCoins
	 3. Nerocrossius			 9 inuksuCoins
	 4. CS2Magus				 6 inuksuCoins
	 5. SteepRock				 5 inuksuCoins
	 6. Cainen				 5 inuksuCoins
	 7. Synchysi				 4 inuksuCoins
	 8. blossom				 3 inuksuCoins
	 9. LongSword25				 3 inuksuCoins
	10. Fathlo23				 3 inuksuCoins
	11. fredfriendly			 3 inuksuCoins
       



---------------------------------------------------------------------------------------------------------



				   Appendix B: Message to players



---------------------------------------------------------------------------------------------------------


Thank you for playing this ROMhack. The feedback and encouragement I've received have kept me working and
kept me motivated to increase my skills at ROMhacking to realize my vision for Chrono Trigger. Speaking
especially to the group that hangs out in the NGPlus Discord server, thank you for cheering me on and
poking all sorts of holes in the game. The mod would not be what it is today without your enthusiasm.

On that note...looking to get a hold of me somehow? Starting with the quickest way to reach me:

	I chat on Discord!
Try the NGPlus server https://discord.com/invite/bsuKp5A
Or the Chrono Compendium server https://discord.com/invite/FXpBw7T
	I browse the internet!
Try the NGPlus forums at http://ngplus.net/index.php?/forums/forum/41-chrono-trigger-enhansa-edition/
Or the Chrono Compendium forums at https://www.chronocompendium.com/Forums/index.php?board=85.0
	I have e-mail!
inuksuk.tv@gmail.com






---------------------------------------------------------------------------------------------------------






										 Quod erat demonstrandum.
---------------------------------------------------------------------------------------------------------