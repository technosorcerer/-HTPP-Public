-------------------------------------------------------------------------------
CHRONO COMPENDIUM
Chrono Trigger: Prophet's Guile
December 25, 2007
http://www.chronocompendium.com/Term/Chrono_Trigger:_Prophet's_Guile.html
Download the EP at that address!
-------------------------------------------------------------------------------
CONTENTS
-------------------------------------------------------------------------------
1.) History and Foreword
2.) Installation
3.) ROM hacking & EP
4.) Credits
-------------------------------------------------------------------------------
1.) History and Foreword
-------------------------------------------------------------------------------

2007-12-25 V 1.00

-First release!

WARNING: Right now, PG freezes SNES9x during a certain part, making the game
impossible to finish. The latest version of ZSNES works.

Chrono Trigger: Prophet's Guile is a fan game following the story of Magus's
rise to power in the Kingdom of Zeal after arriving in 12000 B.C. thanks to
the distortion at his lair. In his bid to stop Lavos at the Ocean Palace, Magus
must gain the trust of Queen Zeal and abolish all opposition. It's about two
regular Chrono Trigger chapters long, and full of surprises. 

Work on Chrono Trigger: Prophet's Guile began in January 2007. ZeaLitY
suggested that the Crimson Echoes team, sidelined for the moment, develop a
short ROM hack to be released in a couple months. Unfortunately, other matters
came into play and after the backbone of the game was coded, work halted and
shifted back to Crimson Echoes. In December 2007, Chrono'99 revived the project
and thanks to a collaborative effort with his leadership, Prophet's Guile
now stands complete. The only casualty of the development process was a plan
to resprite Magus as the Prophet, which would have involved exhaustive work.

-------------------------------------------------------------------------------
2.) Installation
-------------------------------------------------------------------------------

Prophet's Guile comes in the form of an IPS patch, which will be applied to
your US Chrono Trigger ROM. Please do not ask me where to get a ROM; it is
assumed that you have one. Google it. Once the patch is applied, it cannot be
undone. Also, you need to determine which patch to apply. If you aren't sure
what to do, just apply the one that is named "CTPG-Headered.ips". Here's the
process:

1. Make a copy of your ROM. This patch can't be undone, so you probably want to
   keep your old ROM untouched.

2. Use Lunar IPS or a program of your choice to select the patch and the ROM
   you would like to patch it to. If you aren't sure what to do, just open
   Lunar, hit 'Apply IPS Patch,' then find the Prophet's Guile headered .ips
   file.

3. It will then ask you to specify the rom you wish to modify; use the copy of
   your CT rom.

You can also rename the patch to the name of your rom and run it in ZSNES, and
the emulator will automatically apply it. They must be in the same folder or
specified in the Paths options.

-------------------------------------------------------------------------------
3.) ROM hacking
-------------------------------------------------------------------------------

If you'd like to create your own game or story with Chrono Trigger, it's not
too hard! Check out http://www.chronocompendium.com/Term/Modification.html and
download Temporal Flux. Tutorials and other helpful documents are available
there, and you can pose questions about editing and hacking in the Compendium's
Kajar Laboratories forum at

http://www.chronocompendium.com/Forums/index.php/board,19.0.html

-------------------------------------------------------------------------------
4.) Credits	
-------------------------------------------------------------------------------

==DIRECTOR AND PROGRAMMER==

Chrono'99

==WRITER AND CREATOR==

ZeaLitY

==MAPPERS==

Chrono'99
ZeaLitY
nightmare975

==MUSIC IMPORTING AND REMIXING==

JCE3000GT
Vehek
ZeaLitY

==GRAPHIC HACKING==

FaustWolf
Chrono'99

==MENU ART==

CuteLucca

==ENDING ART==

Julie Dillon

==CONTRIBUTORS==

Vehek
Kyronea
justin3009
Shinrin
Kae

I'd like to thank everyone who has contributed or hung around the Chrono
Compendium. Whether you're a tomato, pirate, Guru, or just a plain old awesome
ROM hacker, you've come together with many other fans to make the site the
true center of the universe.

If you can translate and have some free time, we'd love to find out what's in
a few Japanese interviews, Missing Piece, and Ultimania. Just drop us a line.

http://www.chronocompendium.com/

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
        MaS22Z8Z8MW8S7r002@0ZaS2aZaS:MSZ7rrrS2SM2,7SX7ri2M                     
       MMiZBW0Z8SMri;SM0SZM2ZS7SZSrS.M;80;28ZZ,MM 7XSX7; 2M                    
      rM,8B0B8ZaBM;XBWBBZaM22Sa27SXa M2XMS7Saar.MZ,r7Sr7r 7MZ                  
      MMrBB008a2MMi0@00WBB@X7SS7XS2Z MMiW@XrXXS WM,;rXSXX2iZMM                 
      MXaZZ2XZaMMMSW8ZW0ZMa7;77r;irr WM,ZMS;SS2r M8X;7777Z;;.MM                
      MZ2822MSMM@S2aB8888W    .iZMMM@MMX2M8raa22 MMrZr7X82rX  MMX              
      MW22aM0MMM7aZBB80S aMMMMMMMM0i MM0Z8Zi;r22 ZMSZ2ir8aSXSX.SMM             
      MSS2M0MMSXZB808SiBMMM:         MM7SZBii7aXi MMX0rraX22XX;:,MM            
    rMZX8MWM0Xa8BW0S;8MM          Sa8M@S2ZM2i;72X MM82ZXaa80ZZX2r ZMM          
    MaXMMZa2S88W@272MMr    BMMMMMMM MM;XaZB2ir;7X MMMZZMaZS72Z2SS7,,MM         
   iM:S28X0B0B@ZXXMMW   :MMM8;;i,ZW MiX8ZSW7;S7r7 2MMMXWZXr22S72aSS; MM        
   8Mia220W0Z@arXMM    MMWa8MMMMMMaW@;28S2BiXXXSXi7MMMZZW8X280a2X;;S7 M,       
   MM;0MMB0B0ai8MM   MMMMMMMMMMMMM@M, i77XS ,::iXriMMMZSaBS7XZ0ZXS2X2 MM       
   MM;ZZ0aX;iZMMi  ,MMMMMMMMMMMMMMSWMMMM0S2a8a7.   MMMZaWZZ2B82a2SXSa MM       
   MB7ZZXi0MMMZ   8MMXMMMMMMMMMMMM    ;WMMMMMMMMMM.2MMSWBS2X2222XSX7a MW       
   MX72rZMMr     MMMXXMMMMMMMMMMMMMi             MZX0aXBZW20@Z7SSrrSr M        
   Mrr7MM2     MMM              MMMMMMMMMMMMZ:   MiZW0ZBBraWS22S2S2X MM        
   M.BMM    7MMM                    XMMMWB@MMMM MMi80B0WB7SZ2XrSS7r 8M,        
   MMM;   WMMM:                        WMMZ0MM@ MZ28SZB8X7S7ii;SX;:0MMM        
   M.   XM MM@7MMMM.                     iMMMM 2MrZSZBZX7SSWM@MMaiMM8 2MX      
  XM   MM: :MMMMMMMMMMMMMa               2MMM  M@Xa28027SM0MMBariMMW:riXMM     
  7MXMMM    MMMMMM@      Zv              MMMM WMiZ002r0MMrZMS27XMM2ir22;iMM8   
  SM.        MMMMMMaXMMS                 MMM; M2S0B;WM@S@MW2W;ZMMr;7SXX2X;7MMM:
   XMMM      8MMMMM@MMM                 :MMM MM:8XXMMZM@0WMM@MMWXiXSaZaSX7r;i8M
       MMMMi  2MMMMMMa                  MMMM MWi2MM0MMWMMMB; MBr0r7SX77r;;;;i, 
       MSSMMMM aMMMMM              .MMMMMMM2 MaaMMMMMM@ai:i. MMaMai;S2ZW@MMMMMi
       M@X; ZMMMMMMMM          WMMMMM.@MMMM  MMMMW08Zri;r;  :MMZ00MMMMM@08WB0MX
      MM27;ZM,  :MMMMZ  :BMMMMMMMMW  ZMMMX   MMBXi  ::;:.rBMMM8Z00Z80ZZ88aZSX7,
     MM7;7MM;  iMMMMMMMMMMMMMMMMM   SMMa   SMM27XZ800X7MMMMBSi080ZZa2XX2BMMMMMM
    MMrXMMB   MMMMMMMMMMMMMMMMX    7MM:   MMMXXW0aX;2MMMMW8ZZZX7SZWMMMMMMMMW8S:
  MMM72BM  . MMMMMMMMMMMMMSMM    @MMX    MM7XZX:;BMMMMa:,:7ZWMMMMMMM8X,  ,:i;77
  M@,X28M    @MMMMMMMMMM2 rMM MMMM   :MMMM;;,iBMMMMa7XMMMMMMMWXi,    ,i;rXX77rr
  MM0XZZBMX    ;MMMM@B22WMMMMM:   SMMMW;. ,8MMMMaSa8Z7002rr,i;;;;7ZWMMMMBZ800Z2
MMMWMMSMi2MM:     WMMMMMMMM2    MMMi .rSXSWMMMW8827;XX77SX777X28BM@08BBBWB0ZZ8Z
a22,@MXM27X0MMMS    ;MMMi     MMW X8W@BWMMMW2:.,::rX22ZZ7;8B0B0SZZSSZa7;i;SBMMM
8Z8SMM2MZX778Z2MMMB    ;MS,XMM@SWMMMM0WWZr..:rSaZaSSa8aZB@WB8Za0BZZZ8BMMMMMM02r
				   
			   SERGE ~RADICAL DREAMERS~
				   
            This is the first time I've ever seen his true face.
            Even for a guy like me, I'm taken aback by his looks.
             
            His hair sways in the moonlight, as his piercing blue
            eyes survey the environment below.

            His beauty is different than a woman's... there's some
            sort of a fierce, intrepid quality about him.

            He is truly... a beautiful person.				   
-------------------------------------------------------------------------------
-------------------------------------------------------------------------------