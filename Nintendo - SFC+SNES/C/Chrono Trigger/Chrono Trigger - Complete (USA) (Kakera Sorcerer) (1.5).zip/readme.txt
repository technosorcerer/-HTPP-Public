Chrono Trigger: Complete

Is a labor of love and time travel. By Kakera Sorcerer.

Patching
-There are two patches: one for headered roms and another one for unheadered. If you don't know which to use...
	If your rom is named Chrono Trigger (USA).sfc, use the no header one
	If your rome is named Chrono Trigger (U) [!].smc, use the headered one

Description
This Chrono Trigger hack combines the loved, quirky translation of the original SNES version, with the more extended script of the DS version, to create the best Chrono Trigger version. Compared, as well, with the japanese original, for some lines where meanings were initially lost (mostly funny lines from era to era).

Apart from that, scenes were added that add a bit more interaction between the characters and NPCs (Lucca and Melchior, for instance). Nothing major, but small things here and there to make the journey more worthwhile, and explore having different characters in your party.

Last, more direct references to the the Frozen Flame were added in Zeal, and a possibility of what could have happened with Schala, Zeal, the Flame, Dreamstone, and the Gurus. Mostly Chrono Compendium based, but also a bit of my own (original-material based) theorycrafting. Look out for them!

The core gameplay is kept from the SNES original, with mostly SNES original names.

Credits
Thank you so much to:

Joel Yliluoma, a.k.a. Bisqwit, for his wonderful ChronoTools
Doctor L and KWhazit, for their work on their Chrono Trigger translations, which this hack was inspired on


Version 1.5
-Tested script and playtested game until end

Changelog
-Added some more interaction between Lucca, Robo and Melchior... but you find out when and how it's triggered.
-Specifically went through key moments to make wrapping perfect (Ocean Palace Incident, using the Time Egg, facing Lavos, endings, etc.)
-Fixed tech descriptions, which techs target a single enemy and which target several enemies
-Fixed bug with Robo and Frog names
-Fixed wrapping of tech names, which caused a crash
-Added some more Robo dialogue when Ayla invites everyone to a party
-KNIGHT CAPTAIN to COMMANDER
-Decided to keep ALL CAPS words, that emphasize phrases (I.e: What are YOU doing here?)
-Removed most instances of double and triple exclamation and question marks, sticked mostly to single questionmark, single exclamationmark, one of both, or triple of both (last one is very rare)
-Added CHEF and WIFE to their lines... and kept joke they make in present about family
-Leaving "I'm so happy I could scream"... but giving it context. And kept joke they make in past about this.
-Began playtesting game and making small changes to text paragraphs
-Added Frozen Flame references, after researching and theorycrafting its role in Zeal.
-Tried changing names to regular (no caps) and removing line breaks... did not like it. Left it as before.
-Problem with endlines and random line breaks - went through text and changed style of line breaks
-Decided to keep the "tabbed dialogue" style of SNES original, and ALL CAPS name of speaker
-Went through every text line and decided between DS line, SNES line, or translation of japanese original
-Dumped script with Chrono Tools