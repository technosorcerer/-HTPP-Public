-------------------------------------------------------------------------------
CHRONO TRIGGER COLISEUM
A product of Kajar Laboratories by JP
Rom hack / modification of Chrono Trigger
Released through the Chrono Compendium
http://www.chronocompendium.com
-------------------------------------------------------------------------------
CONTENTS
-------------------------------------------------------------------------------
1.) Legal information
2.) Installation instructions
3.) READ THIS BEFORE PLAYING
4.) Frequently Asked Questions
5.) Crimson Echoes Recruiting
6.) Thanks and credits

10/25/05 - Version 1.00
-First release!
10/27/05 - Version 1.01
-Small exploremode off bugfix.
10/27/05 - Version 1.02
-Marle weapon handicap bugfix.
1/2/05 - Version 2.00
-Rainbow Shell sidequest works again.
-Players can't run away from Coliseum fights.
-Cameo by a famous swordsman added to programmer's room (beat solo, hard).
1/4/05 - Version 2.10
-Minor tweaks.

-------------------------------------------------------------------------------
1.) Legal information
-------------------------------------------------------------------------------

The game Chrono Trigger is copyright Square Enix, 1995.

http://www.square-enix.com/ 

The rom hack demo called 'Coliseum' is done by Kajar Laboratories.

http://www.angelfire.com/ok2/mercenary7/

It is released through the Chrono Compendium.

http://www.chronocompendium.com/ 

The fans and members of Kajar Laboratories acknowledge that under

M. Kramer Manufacturing Company, Inc. v. Andrews,  783 F.2d 421 (4th Cir. 1986),

ROM altering and modification is illegal, and the demo has been made without the
consent of Square Enix. However, Kajar Laboratories wishes that Square Enix view
it as a piece of fanfiction or other fan-related work, falling in the general
body of fan community proceedings that are too numerous to prosecute and summarily
have a positive effect on the popularity of its games. Should Square Enix perceive
the project as a threat to its sales or intellectual property, Kajar Laboratories
will immediately cease operation on the project and comply with Square Enix's
orders.

-------------------------------------------------------------------------------
2.) Installation instructions
-------------------------------------------------------------------------------

CT Coliseum comes in the form of an IPS patch, which will be applied to your
Chrono Trigger ROM. Please do not ask me where to get a ROM; it is assumed that
you have one. Once the patch is applied, it cannot be undone. Also, you need to
determine which patch to apply. If you aren't sure what to do, just apply the one that
is named "Coliseum-Headered.ips". Here's the process:

1. Make a copy of your CT rom. This patch can't be undone, so you probably want
   to keep your old rom untouched.

2. Use Lunar IPS or a program of your choice to select the patch and the rom you
   would like to patch it to. If you aren't sure what to do, download Lunar IPS
   from http://fusoya.panicus.org/lips/ . Once you open it, hit 'Apply IPS Patch,'
   then find the Crimson Echoes demo .ips file. It will then ask you to specify
   the rom you wish to modify; use the copy of your CT rom. That's it!

3. Use an emulator, such as ZSNES ( www.zsnes.com ), to run the game.

You can also rename the patch to the name of your rom and run it in ZSNES, and
the emulator will automatically apply it. They must be in the same folder, however.

-------------------------------------------------------------------------------
3.) READ THIS BEFORE PLAYING
-------------------------------------------------------------------------------

The Chrono Trigger Coliseum is simply an arena where players can battle on
three levels of difficulty, either with the party or a solo party member, for
prizes redeemable by battle points. It is similar to the coliseum of Final
Fantasy 7 in this regard; handicaps are given before each battle. There are
some things you must know before playing.

-The coliseum uses the Silver Point value. To be ethical, spend all your
 Silver Points before playing.

-The coliseum is not accessible until after the Factory dungeon is cleared in
 2300 A.D.

-If you use a savestate ahead of this point in the story to play the coliseum,
 please speak to a new NPC in the Proto Dome who stands near the entrance. This
 loads up the Coliseum (it had to be unloaded before this because of a technical
 note).

-You must collect certain keys to access easy, medium, and hard difficulty.
 Toma, who resides in the Coliseum at all times, provides riddles to their
 location. If you honestly cannot find them, refer to the very bottom of this
 readme.

-Sorry, the Programmer's Ending cannot be viewed while this hack is in effect,
 as it uses this ending's dialogue offset.

-Submit bugs by e-mailing chronocompendium@gmail.com.

-------------------------------------------------------------------------------
4.) Frequently Asked Questions
-------------------------------------------------------------------------------

Q. The guards keep telling me to come back later!

-It should say this if Crono is dead. If Crono is alive, then perhaps you used a
 savestate that grants you 99 of every item. An item called 'Flag' is added
 during Crono's death during the plot to prevent players from entering the coliseum;
 you can't sell or get rid of it, so you must find a savestate that doesn't give
 99 of everything. There's one at Zophar.net, assuredly.

Q. I have the wrong amount of BP!

-It's the same as silverpoints...so if you think you have too much or too little
 it could be because you spent/made SP at the fair.

Q. Why do I change Parties after fighting alone?

-This was the easiest way to implement the alone feature, the reason it is that party
 is because those three members are the three that are for sure in your party when you can
 enter it...though I suppose Robo is too.

Q. Why isn't it open before the EoT?

-Because of the Robo factory subquest.  Things got screwed up with the way the forced
 Robo to be in your party for that quest.

Q. I'm supposed to have frog to fight Magus, but if I fight alone my party becomes Crono,
Lucca, and Marle.

-Use the EoT change party screen to put frog back in.

Q. How much BP do I get for each fight

Easy  Medium    hard
1       2        5
1       2        10
2       5        15
4       7        20
7      12        25
10     20        40
15     25        40+special prize

These are what I have written down....I think I may have made it a LITTLE less
if you fight alone you get double.

Q. Why is it closed when Crono dies?

-Because the "set" party after fighting alone is Crono, Marle, Lucca.  I thought
 about implementing an if statment that would make it a seperate party if you fought
 during that point of the game, but I have already made the Colliseum so big i can't
 add any more "call object Functions".

Q. I want to fight alone with someone other than Crono!

-You fight alone with whoever you're first "first active character" is.  For most
 of the game that is Crono, but after a certain point you can change him, then you
 can fight alone with whoever you want. 

Q. Where are the keys????

-I made them pretty obvious, I probalby should have made them invisible but I was
 worried that it would be to hard then. The riddles/keys was mainly just to make
 the Colliseum more integrated and not seperated from the game.  If you STILL can't
 find them then read the very bottom of this readme.

Q. This is cool, I want to do it.

-Please do, simply download Temporal Flux and get hacking. You can find it at Geiger's
 website, or at the Chrono Compendium's Modification encyclopedia entry.

Q. How'd you implement (name a feature)?

-Eventually I plan on putting a tutorial up, if you're really interested, shoot me
 an email...you can post on the forums too, though I really only check the crimson echoes
 one.

Q. The shop is stupid, why'd you add it?

-I wanted to see how hard it was to do it...haha.  It does become obsolete after awhile,
 but I couldn't make it one of the later shops cause you would have access to good armor
 too soon.  

Q. Zeal's dead...why is she here?

-Yea, I know.  At first I was gunna have Ozzie, Flea and Slash, but the graphics screw
 up when they do a triple tech (Enemy prm problem probably I never looked to far into it), so I needed someone who could put up a worthy fight, and honestly Zeal is probably the only non Lavos person who could.  If one were to make a whole new game we could hack enemy stats and put them in there...maybe Gato+?

Q. I found a bug/have a question and I really want to tell you about it

-Please tell me at jpsondag@gmail.com

-------------------------------------------------------------------------------
5.) Crimson Echoes Recruiting
-------------------------------------------------------------------------------

The Coliseum was originally designed to be a part of the Chrono Trigger rom hack "Crimson Echoes,"
which aims to completely change the game to a new adventurer. Right now, the project is taking any
help it can get in the realm of editing with Temporal Flux. If you can you Flux or want to learn how and
contribute, please e-mail chronocompendium@gmail.com.

-------------------------------------------------------------------------------
6.) Credits and thanks
-------------------------------------------------------------------------------

MAIN PROGRAMMER

JP

MAPPING

Cory

TECHNICAL ADVICE

Geiger
Chickenlump
JLukas

PUBLICITY & RELEASE

Zeality

BETA TESTING & ADVICE

Aitrus
Janus Zeal
...and the other beta testers and contributors!

http://www.chronocompendium.com



















~



















Couldn't find the keys? Look in 65000000 B.C., 1000 A.D., and 2300 A.D.

65 B.C. - Where everything began. What being set into motion the plot
          of Chrono Trigger? Where did he begin his influence?

1000 A.D. - A good place to get snacks and drinks. And...Jerky?

2300 A.D. - Damp and dark, reminiscent of a public utility.