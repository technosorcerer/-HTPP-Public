A new version of the old Kajar Laboratories patch that inserts kWhazit's updated retranslation from kwhazit.ucoz.net/trans/ct/index.html into Chrono Trigger, in addition to trying to fix all the remaining issues that the old patch had.

The old retranslation patch, and the addendum patches based off it, use kWhazit's original literal retranslation of the Japanese text which can come off as unnatural and hard to read at times. The addendum patches do clean it up by further localizing the text, fixing errors, and mixing in text from other translations, but in doing so, the old patch turned more into a Frankenstein's monster of various translations rather than having it be its own thing.

This updated retranslation attempts to offer quality on par with the official DS translation while standing on its own as something different. A more literal translation than the official versions that keeps the Japanese terminology intact but still flows naturally for an English speaker.



All that being said, this re-retranslation does have some minor issues and alterations have been made as well. These are the notable ones:

kWhazit didn't cover all the text in the game in their updated retranslation, so the original one is still used for a lot of the side NPCs and miscellaneous text. The rough spots have been cleaned up by comparing the various translations to come up with something that fits better while keeping the original meaning. (EX: How is your awakening? -> Did you sleep well?) Otherwise, if just adding/removing a word or two or some punctuation helps to make things come across clearer, then the change was made.

Only 10-11 spaces are available for enemy/item/tech names with item/tech descriptions and battle messages being quite short as well, so text had be to cut/altered here. Abbreviations were avoided in favor of finding something shorter that still gets the point across, and going back to the SNES/DS translation was a last resort unless it just seemed like the best alternative. (EX: Miracle Shot -> WonderShot) Similarly, Sylbird is too long to fit as a name, so Epoch remains the default name for the time machine.

Mostly in the interest of uniformity (but also space constraints), the years are still formatted according to how they appear on the world map graphic (1000 A.D. instead of A.D. 1000), and the specific eras mentioned in dialog/on the save menu reflect what is shown on the Epoch's time gauge with Chronosplit's Time Menu Update hack in use. So, Prehistory/Antiquity/Present/End of Time vs. Primeval/Ancient Era/Modern Age/Farthest Reaches of Time.

A small handful of further localization changes were made to make the text more palatable for English speakers. (EX: Vinnegar PINCH!! -> Vinnegar's in a pinch!!) Previously established naming conventions from other Square titles are implemented (EX: Figa -> Firaga), and the amount of ellipses... and stuttering (H-how, Wh-what) have been trimmed down a bit. Using a lot of ellipses really must be cruise control for cool in Japanese with how... often...... Magus... loves...! ...to... use... them...!?

Crono's "Aether" element stays as "Heaven". Remaking and inserting the element graphic would be more trouble than it's worth, and Heaven fits a bit better with his final tech being the "Ultimate holy magic" anyway.

"The Magus" is back to just "Magus". The "The" was added to show that Magus is meant to be more of a title than a name, but there isn't enough room for "The Magus" in more than a few places. Also, unlike the Japanese version, it doesn't make much sense if you decide to change his name to something else later on.



As many bug fixes as possible were added to the patch. Fixes made outside of the Temporal Flux editor include:

Character Name Empty Space fix - Trailing spaces removed on names with less than 5 letters.

Double/Triple Tech ATB Delay fix - The mostly broken ATB delay mechanic that only applies to supporting characters in double/triple techs has been cut out of the game entirely for consistency. See: chronocompendium.com/Term/Active_Time_Battle_Code_and_Delay.html

Targeting AI Low HP fix - The lead character wouldn't be properly targeted in some cases if their HP was the lowest in the party.

Third Eye Menu fix - The Third Eye accessory actually boosts Evade by 2.5x, not 2x. The inventory/shop menus now display this properly.



Setting aside bug fixes, an optional patch with some small gameplay changes to spice things up is also included:

-Specchio's final form can be fought starting from Level 50 instead of 99.
-The 1 respawning Rokk(Rubble) enemy on Grief Mountain(Mt. Woe) no longer respawns.
-Master Golem(Golem Boss): A Power Ring can be stolen.
-Fossil Ape/Twin Nom(Ruminator): Megalixir steals changed to Elixirs.
-AcietNychus(Leaper): Elixir steal changed to Nereid Helm(MermaidCap).

-Dinomen Hideout(Reptite Lair): A Hi-Ether chest was changed to a R'bow Helm, and a Mid-Ether chest to a Hi-Ether.
-Mega/Giga/Teraton Arms: Magic power +2/4/6, Giga/Teraton's value slightly increased.
-PainMantle(Gloom Cape): Speed +1, Absorbs Dark damage.

-Robo, Ayla, and Magus learn techs faster, at the same rate as Marle, Lucca, and Frog.
-Dark Matter: Power changed from 38 to 42, same as Flare.
-Marle's Curaga becomes Healaga: Recovers HP for all allies, 10 Power. Same as Robo's Heal Beam.
-Curaga Wind(Cure Touch) becomes Healing Wind: Functions the same as before.
-Line Bomb: Damage changed from being equal to Megaton Bomb's to 1.5x damage. About 15% stronger than Flare.

And the "Frog Power-up":
-Suzaku(Shiva Edge): 4x damage during criticals removed, Critical rate increased from 7% to 20%.
-Reborn Grandleon(Masamune): 4x damage during criticals added.
-Hero Badge: Raises the Grandleon's Critical rate to 100% vs. 50%. (0x3DB3F7, changed 32 to 64)



Finally, the previously unused "Battle 2" and "Singing Mountain" music tracks have been added in for some extra flavor. Battle 2 appears very briefly in the Cyrus vs. Frog King flashback as it did in the CT Prototype, and Singing Mountain is used as the area theme for Grief Mountain. Thanks to PowerPanda for help implementing this!



Credits:
kWhazit, ZeaLitY, Geiger, JLukas, Vehek, Lena Andreia, and Kyronea for the original CT Retranslation, and kWhazit again for the updated retranslation.
Doctor L for the Heaven element graphic.
belthegor for the JP Title Screen hack.
Chronosplit for the Time Menu Update hack.
Mike Ferrell for the Unsightly Pixel hack.
Mauron for the Third Eye Menu fix.



Version 1.1 - Fixed a couple lines of dialog that got swapped and made a handful of small nitpicky line changes. The second Lavos Spawn fight on Death Mountain(Peak) can no longer be escaped from, and the sealed chest containing the Magic Ring now functions the same as all the others (fanfare interrupts music rather than restarting it and there is a sound effect and white flash when opening the chest).

Version 1.11 - Shortened/changed a few battle messages that were slightly too long, causing a small spot in the middle of the textbox to disappear.

Version 1.12 - Small fix for the "Spacetime Shift" message in the final battle



Apply the patch of your choosing to an unmodified, headered Chrono Trigger (U) rom.