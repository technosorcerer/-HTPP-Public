English:

July 29th 2013

This is a pretty much complete translation of Chrono Trigger into Swedish. It's been on the way since 2004, when there was an active game translation scene in Sweden. In the past few years I've only fiddled with it from time to time, when I needed something to do and didn't have the strength to do anything else. So everything is done for my own sake, and although I've looked at both the english translation and the japanese original text, I think purists might find things to bother them. ^^;

Everything is translated except for the introduction- and ending credits, and the names of the eras in Epoch. I may return to this some day and try to fix that. Sorry about typos and bugs - I've tried, but I probably haven't found them all!

Translated with Chronotools 1.12.4 by Bisqwit.

http://bisqwit.iki.fi/source/chronotools.html

---------------------------------------------


Svenska:

29 Juli 2013

Det h�r �r en i det n�rmaste komplett �vers�ttning av Chrono Trigger till svenska. Den har varit p� g�ng sedan 2004, d� det fanns en aktiv spel�vers�ttarscen i Sverige. De senaste �ren har jag bara h�llit p� med den d� och d� n�r jag beh�vt n�got att pyssla med och inte orkat n�got annat. Allt �r s�ledes gjort f�r min egen skull, och trots att �vers�ttningen skett b�de med den engelska och den japanska texten i huvudet kommer purister f�rmodligen hitta en del st�rande moment.

Allt �r �versatt utom start- och sluttexter och namnen p� tidsperioderna i Epoch. Kanske g�r jag tillbaka n�gon g�ng och ger mig p� det ocks�. Jag ber om urs�kt f�r typos och buggar - jag har f�rs�kt men f�rmodligen inte hittat alla!

�versatt med Chronotools 1.12.4 av Bisqwit. 

http://bisqwit.iki.fi/source/chronotools.html



F�r att spela �vers�ttningen:

Ladda ner Chrono Trigger-rommen.

L�gg rommen och ips-filen i samma mapp.

D�p filerna till samma sak (t ex ct-svensk10.ips och ctsvensk10.smc)

Spela spelet med Zsnes (http://www.zsnes.com/)


Kontakt:
rymdljus@gmail.com

