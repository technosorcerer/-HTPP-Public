-------------------------------------------------------------------------------
CHRONO TRIGGER: CRIMSON ECHOES
A product of Kajar Laboratories
Rom hack / modification of Chrono Trigger
� Kajar Laboratories, released through the Chrono Compendium
Crimson Echoes Homepage: http://crimsonechoes.com/
Chrono Compendium: http://www.chronocompendium.com
-------------------------------------------------------------------------------
CONTENTS
-------------------------------------------------------------------------------
1.) Legal information
2.) Installation instructions
3.) What's Crimson Echoes? What's changed from 1.0?
4.) How was it made? Can I help or anything?
5.) Thanks and credits
-------------------------------------------------------------------------------
1.) Legal information
-------------------------------------------------------------------------------

The game Chrono Trigger is copyright Square Enix, 1995.

http://www.square-enix.com/ 

The rom hack called Crimson Echoes is done by Kajar Laboratories.

http://crimsonechoes.com/

It is released through the Chrono Compendium.

http://www.chronocompendium.com/ 

The fans and members of Kajar Laboratories acknowledge that under

M. Kramer Manufacturing Company, Inc. v. Andrews,  783 F.2d 421 (4th Cir. 1986),

ROM altering and modification is illegal, and the demo has been made without the
consent of Square Enix. However, Kajar Laboratories wishes that Square Enix view
it as a piece of fanfiction or other fan-related work, falling in the general
body of fan community proceedings that are too numerous to prosecute and summarily
have a positive effect on the popularity of its games. Should Square Enix perceive
the project as a threat to its sales or intellectual property, Kajar Laboratories
will immediately cease operation on the project and comply with Square Enix's
orders.

-------------------------------------------------------------------------------
2.) Installation instructions
-------------------------------------------------------------------------------

Crimson Echoes comes in the form of an IPS patch, which will be applied to your
Chrono Trigger ROM. Please do not ask me where to get a ROM; it is assumed that
you have one. Once the patch is applied, it cannot be undone. Also, you need to
determine which patch to apply. If you aren't sure what to do, just apply the one that
is named "CE-Headered.ips". Here's the process:

1. Make a copy of your CT rom. This patch can't be undone, so you probably want
   to keep your old rom untouched.

2. Use Lunar IPS or a program of your choice to select the patch and the rom you
   would like to patch it to. If you aren't sure what to do, download Lunar IPS
   from http://fusoya.panicus.org/lips/ . Once you open it, hit 'Apply IPS Patch,'
   then find the Crimson Echoes demo .ips file. It will then ask you to specify
   the rom you wish to modify; use the copy of your CT rom. That's it!

3. Use an emulator, such as Snes9X or ZSNES, to run the game.

-------------------------------------------------------------------------------
3.) What's Crimson Echoes? What's changed since 1.0?
-------------------------------------------------------------------------------

Chrono Trigger: Crimson Echoes is a planned ROM hack sequel to
Chrono Trigger that aims to follow the old adventurers on a new
journey. Besides providing a fun experience, this project aims to
enliven Chrono Trigger ROM hacking through displaying the power and
possibilities of the program Temporal Flux, which can edit nearly
every aspect of the game.

-------------------------------------------------------------------------------
4.) How was it made? Can I help or anything?
-------------------------------------------------------------------------------

Crimson Echoes was made primarily with Temporal Flux, a Chrono Trigger ROM editor
made by Geiger, a rom hacker with much experience. Temporal Flux (current version
2.0) allows editing of maps, music arrangement, locations, exits, strings and
dialogue, and most importantly, events, which compose the meat of the game. While
a flashy and cool area may be designed well and look good, it's useless if there
are no events to make it work and have scenes take place there.

The aim of Temporal Flux is to become the ultra vehicle for editing and modifying
Chrono Trigger, to include all sorts of functions and capabilities. In addition,
there are countless other utilities that supplement the program and complete
the full spectrum of editing Chrono Trigger. For advanced users with knowledge
of ASM (game assembly code), the possibilities are endless.

You can find utilities for Chrono Trigger rom hacking at:

http://www.chronocompendium.com/Term/Modification

If you want to help or make your own hack, just download Temporal Flux and
start experimenting. Right now, Crimson Echoes only needs people willing
to map well or work with event code. Contrary to popular belief, fan projects
are not carried upon the wings of flashy concept art and hyped screenshots
and spriting, so we welcome any help with finishing the meat of the game.

-------------------------------------------------------------------------------
5.) Credits and thanks
-------------------------------------------------------------------------------

Kajar Laboratories. Play through to the ending to find out who helped!

The creators of Temporal Flux.

ROCK LEE! THE SPRINGTIME OF YOUTH WAITS FOR NO ONE!

http://www.chronocompendium.com