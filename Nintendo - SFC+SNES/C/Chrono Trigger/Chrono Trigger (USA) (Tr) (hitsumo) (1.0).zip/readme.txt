************Hot Chocolate Chrono Trigger Turkish Language Project*********
Version 1.0 Date 7.17.2024 ( yes finihs party time :) )

The story part is over. The remaining part is the game interface
and techniques.
The technical screen is broken, I don't know why :)
Characters deteriorate as they learn new skills.
There are screen errors in conversations. Next updates will be to fix such bugs.
Thanks everyone :)

e-mail:
hitsumo@protonmail.com

website:
http://www.sicakcikolata.com
https://www.chronotriggerturkiye.com/

Twitter :
@chronotriggertr
@SicakC_dunyasi 

************ S�cak Cikolata Chrono Trigger T�rk�e �eviri Projesi******** 
Versiyon 1.0 Tarih 7.17.2024 ( bitti parti zamani:) )


Hikaye kismi bitti. kalan kisim oyun arayuzu
ve teknikler.
Teknikler ekrani bozuldu neden bilmiyorum :)
Yeni yetenek ogrenirken karakterler bozuluyor.
Konusmalarda ekran hatalari var. Sonraki guncellemeler boyle hatalari duzeltmek icin olacak.
Herkese tesekkurler :)

�leti�im

e-mail:
hitsumo@protonmail.com

website:
http://www.sicakcikolata.com
https://www.chronotriggerturkiye.com/

Twitter :
@chronotriggertr
@SicakC_dunyasi 






************Hot Chocolate Chrono Trigger Turkish Language Project*********
Version 0.9 Date 06.23.2024 ( almostly finish yeyyy :) )

1- More translate
2- Some places have been translated again.
3- i love Ayla he he

e-mail:
hitsumo@protonmail.com

website:
http://www.sicakcikolata.com
https://www.chronotriggerturkiye.com/

Twitter :
@chronotriggertr
@SicakC_dunyasi 


************ S�cak Cikolata Chrono Trigger Turkish �eviri Projesi******** 
Versiyon 0.9 Tarih 06.23.2024 ( nerdeyse �eviri bitti ya�a��n :) )


1- Daha fazla �eviri.
2- Bazi yerler tekrar �evrildi.
3- Ayla'yi seviyorum he he :)

�leti�im

e-mail:
hitsumo@protonmail.com

website:
http://www.sicakcikolata.com
https://www.chronotriggerturkiye.com/

Twitter :
@chronotriggertr
@SicakC_dunyasi 


************Hot Chocolate Chrono Trigger Turkish Language Project*********
Version 0.8 Date 09.28.2023 ( where 0.7 ? i dont know :) 

1- More bug fixed.
2- More translation.

e-mail:
hitsumo@protonmail.com

website:
http://www.sicakcikolata.com
https://www.chronotriggerturkiye.com/

Twitter :
@chronotriggertr
@SicakC_dunyasi 

************ S�cak Cikolata Chrono Trigger Turkish �eviri Projesi******** 
Version 0.8 Date 09.28.2023  ( 0.7 nerede ? Bende bilmiyorum :) )


1- Daha fazla hata giderildi.
2- Daha fazla �eviri.

�leti�im

e-mail:
hitsumo@protonmail.com

website:
http://www.sicakcikolata.com
https://www.chronotriggerturkiye.com/

Twitter :
@chronotriggertr
@SicakC_dunyasi 


************Hot Chocolate Chrono Trigger Turkish Language Project*********
Version 0.6 Date 11.20.2021

1- More bug fixed.
2- More translation.

Contact

e-mail:
hitsumo@protonmail.com

website:
http://www.sicakcikolata.com
https://www.chronotriggerturkiye.com/

Twitter :
@chronotriggertr
@SicakC_dunyasi 


************ S�cak Cikolata Chrono Trigger Turkish �eviri Projesi******** 
Versiyon 0.6 Tarih 11.20.2021


1- Daha fazla hata giderildi.
2- Daha fazla �eviri.

�leti�im

e-mail:
hitsumo@protonmail.com

website:
http://www.sicakcikolata.com
https://www.chronotriggerturkiye.com/

Twitter :
@chronotriggertr
@SicakC_dunyasi 


************Hot Chocolate Chrono Trigger Turkish Language Project*********
Version 0.5 Date 27.01.2020
1- More wrong window fixed.
2- And more translate. i am sick. i havent energy. I will translate more when I get better.

For contact

hitsumo@protonmail.com
http://www.sicakcikolata.com
Twitter :
@SicakC_dunyasi 


************ S�cak Cikolata Chrono Trigger Turkish �eviri Projesi******** 
Versiyon 0.5 Tarih 27.01.2020


1- Hatali olan konusma pencelerinin bazilari duzeltildi.
2- Daha fazla �eviri yap�ld�. Hastay�m. Enerjim yok. �yile�ti�imde daha �ok �evirece�im.

�letisim i�in

hitsumo@protonmail.com
http://www.sicakcikolata.com
Twitter :
@SicakC_dunyasi 



************Hot Chocolate Chrono Trigger Turkish Language Project*********
Version 0.4 Date 7.01.2020

For update Sibel Unli she is dead.

1- More wrong window fixed. ( etc empty window ) 
2- And more translate


For contact

hitsumo@protonmail.com
http://www.sicakcikolata.com
Twitter :
@SicakC_dunyasi 



************ S�cak Cikolata Chrono Trigger Turkish �eviri Projesi******** 
Versiyon 0.4 Tarih 7.01.2020

Bu guncelleme �len Sibel �nli i�in.

1- Hatali olan konusma pencelerinin bazilari duzeltildi ( �rne�in fazladan pencere )
2- Daha fazla �eviri yap�ld�.

�letisim i�in

hitsumo@protonmail.com
http://www.sicakcikolata.com
Twitter :
@SicakC_dunyasi 

************ Hot Chocolate Chrono Trigger Turkish Language Project******** 
Version 0.3  27.12.2019

1-  Palace name max 16 character. Accordingly, the translation was made.
2-  Some empty box error fixed.
3-  Last translate palace Magus's Lair with magus battle.
4-  Hot Chocolate Team up one more people hurray Stormage :)
5-  Enjoy it game happy Christmas happy hurray :)

For contact

hitsumo@protonmail.com
http://www.sicakcikolata.com
Twitter :
@SicakC_dunyasi 


************ S�cak Cikolata Chrono Trigger Turkish �eviri Projesi******** 
Version 0.3 Date 10.11.20019

1- Yer isimleri en fazla 16 karakter bu duruma g�re �eviri yap�ld�.
2- �imdilik sadece bir yerde yapt�m. ingilizce konu�mada karakter ismi de�i�ebildi�i icin karakter ismine ek gelirse ba�ka isme uymayaca��ndan
anlat�lan seye bu kural eklenerek ingilizcede olmayan konusma eklenmi�tir.
�rnek: Crono's home Crono'nun evi olarak �evrilebilir. Fakatisim Mehmet olursa Mehmet'nun olacak :)
Cronun'nun evi de�il de Crono bu evde kalmakta gibi :)
3- Baz� yerlerde fazladan bo� konu�ma kutusu geliyor birka��n� kald�rd�m.
4- Magus'u yendi�i yere kadar bir �ok yer �evrildi.
5- S�cak Cikolata'ya bir ki�i daha kat�ld�. Stormmage mutluyum.
6- Oyunun tad�n� ��karin. Mutlu y��lar :)



***********Hot Chocolate Chrono Trigger Turkish Language Project**********
Version 0.2 Date 10.11.2019
1 - Translated a section of the Robo section



************S�cak �ikolata Chrono Trigger T�rk�e �eviri Projesi***********
Versiyon 0.2 Tarih 10.11.2019

1- Robo b�l�m�n�n bir b�l�m� �evrildi.


***********Hot Chocolate Chrono Trigger Turkish Language Project**********
Version 0.1 Date 01.11.2019

1- I use USA version rom

2- Used Programs


*NSRT 3.4 Used to add HEADER
*Crono Texteditor 1.0 for translate.
*Lunar ips Create for patch. it add turkish patch, you should use this program.

Translate Notes

1- Example 50G 50A ( Gold - Altin ) change to.

2- Jurassic era translate jura donemi.

3- Because I couldn't successfully adapt the frog's Victorian way of talk, I used "Ribbit" at the end of its sentences. As long as I don't forget!

4- The item names won't be translated for two reasons. One; character space isn't enough, two; their originals are more charismatic.

5- The techniques will not be translated into Turkish.Same reasons.

6- If the place names program does not cause any problems, I will take them all.

7- I translate as I play. And I liked the game I was playing for the first time. :)
   Thanks to Soulianis for her translation assistance. Should I add his name to the end of the game? Special thanks section :)

8- I translate to learn English.


For contact

hitsumo@protonmail.com
http://www.sicakcikolata.com

************S�cak �ikolata Chrono Trigger T�rk�e �eviri Projesi***********

Versiyon 0.1 Tarih 01.11.2019

1 - USA rom versiyonu kullanildi. 

2- Kullanilan programlar



*NSRT 3.4  Rom'a BA�LIK ( HEADER ) eklemek i�in kullan�ld�.
*Crono Texeditor 1.0 ceviri icin kullanild�.
*Lunar ips rom dosyasin�n yamas�n�n olu�turmak i�in ve rom dosyas�na yama eklemek 
i�in kullan�l�r. T�rk�e yamay� eklemek i�in kullanmal�s�n�z.

�eviri Notlar�


1- �rnegin 50G 50A ( Gold - Alt�n) olarak de�i�tirildi.

2- Jurassic d�nemi, jura d�nemi olarak �evrildi.

3- Kurbagan�n Shakespeare tarz� konusmas�n� t�rk�eye uyduramad�g�m i�in
 cumle sonralarinda farkl�l�k olsun diye vraak kullan�ld�. Unutmadikca!

4- Esyalar �evrilmeyecek iki nedeni var; Karakter alan� yetmiyor, ikincisi �zg�n hali daha etkileyici.

5- Teknikler de turk�ele�tirilmeyecek. Ayn� neden.

6- Yer isimleri program sorun ��kartmazsa hepsini turkcele�tirece�im.

7- Oynad�k�a �eviriyorum. Ve ilk kez oynuyorum oyunu �ok sevdim. :)

�eviride Yard�mlar� i�in Soulianis'e Tesekkurler. Oyunun sonuna ismini eklesem mi ? �zel te�ekk�r b�l�m� :)

8- �ngilizce ��renmek icin �eviriyorum :).

�leti�im

hitsumo@protonmail.com
http://www.sicakcikolata.com



Terim �evirileri

Black Omen - Kara Alamet
Gate - Gecit
Millenium Fair - Milenyum Festivali
Tent of Horror - Dehset Cadiri
Big One - Buyuk Olan