"3×3 Eyes: Juuma Houkan"
Traducción al Español Ver. 1.0 (23/05/2025)
por Max1323 (Traducciones Max1323).
Basada en la gran traducción de Atomizer_Zero, FamilyGuy, AkiHizirino y mkwong98.
---------------------------------------------------
Descripción:
Ling Ling descubre una carta del Profesor Fujii, en donde escribió acerca de una extraña tribu que puede controlar a las bestias. Pai sale a buscar más información en Kowloon, dos días después, Yakumo vuelve del trabajo y se entera de que Ling Ling perdió contacto con Pai. Luego de esto, Yakumo sale a su búsqueda.

Desarrollado: System Sulppy N-Tech
Publicado:    Banpresto
Lanzamiento:  22/12/1995 (JAP)
---------------------------------------------------
Acerca del proyecto:
-La mayoría de los textos están traducidos. Se agregaron los caracteres españoles. *Aclaración: La fuente del texto no es normal.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS (PC)
Utilizar UniPatcher (Android)
Utilizar Rom Patcher (Parcheador Online):
https://romhackplaza.org/patch/

Archivo IPS
3x3 Eyes - Juuma Houkan (Japan).sfc
File Size:    2.00 MB
File MD5      7E55EE60AA3F1E37F7A7A006201EC035        
File SHA-1    B6214C20D83D70F6F83A79F4496486E30F424E17
File CRC32    AD4AD163