Lagoon - Double XP
Nov. 7th 2024
BillyTime! Games
--------------------
This is a fun and simple patch designed for Lagoon that doubles the amount of experience earned after every defeating an enemy.

How to Patch:
--------------------
1.Grab a copy of Lagoon (USA).sfc (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file