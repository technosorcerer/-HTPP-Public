 .===================.
( GANBARE GOEMON HACK )
 '==================='

Here's an attempt make Legend of the Mystical Ninja how it should have been for the US release.
Don't forget I'm french so a native english speaker will probably find some errors...
You now have the choise between 2 versions of the title screen:
-Ganbare Goemon (classic version)
-Go for it! Goemon (like the upcoming translations)

Version 1.01:
-Fixed Last level name
-Change Man/Woman sauna graphics
-Alternate title screen

Version 1.00:
-Corrected some text
-SRAM save!

Version 0.99:
First public release, not fully tested, maybe some things could be improved.
-Title screen change
-Restore many things of the japanese version (like Goemon and Ebisu)
-Added a lowercase font
-Restore the Sammy Rye's Circus Side Show
-Many texts retranslated (mainly the cutscenes)

Staff:
FlashPV: Project leader, hacking, graphic editor
DDS: Main hacking
Akira76: SRAM hack
Darksoul, Hiei, Tom: Spot translations

ROM / ISO Information:
File Size 1048576 (100000)
ROM Size 1048576 (100000)
ROM CRC32 82479D6A
ROM SHA-1 E7DB9B1220D66BC8665FE2761AC396DC28BFD88C
No-Intro ROM name: Legend of the Mystical Ninja, The (USA).sfc
