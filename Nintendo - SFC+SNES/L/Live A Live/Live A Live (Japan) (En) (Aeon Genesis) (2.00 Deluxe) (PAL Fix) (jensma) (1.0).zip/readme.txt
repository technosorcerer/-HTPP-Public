Patches Live a Live to be played on PAL and NTSC systems.
Works with every version of the game, patched to english or not.

Greetings and love to Maxi and the boys,
jensma.de 2017