LOBO (Super Nintendo)
Traducción al Español v1.0 (23/10/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
LOBO.sfc
MD5: a3705f0c8e23167994c72e6a411d75dd
SHA1: ccb6324c6e8dc43ced93a2cba5970757affec755
CRC32: 890dc31c
3145728 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --