LEMMINGS Colour Palette & Level Title Fix v1.2 for the Super Nintendo Entertainment System. Colours changed to match the Commodore Amiga version, Restored the Levels that were censored by Nintendo of America and Level Title Fixes.

Yes, you read it right. The Super Nintendo version of Lemmings deserves to get the Colour Palette Fix Hack treatment too. The Level tile palettes now match close to the Commodore Amiga version whilst keeping the good SNES version specs in place.
Although it wasn�t easy to change the colour palette on this port as this took hours to do and a different method to palette hacking. But got there in the end. Saying that, Glad the Super Nintendo version gives me more colour palettes up to 32,768 colours in order to try and make it as very close to the Amiga colour palette as possible.

Along with not only some Level Title Fixes. but restored the Levels that were censored by Nintendo of America.


UPDATE: v1.2
The colour palette for the dirt, pillar, marble, crystal and Fire level sets now all have the correct Commodore Amiga colour palette sets after more tweaking with it. this is without the doubt the VERY LAST update.

Lastly, I fine tunes the colour button palettes when Pressing "Select" and "Start" to configure the joypad so that the buttons look like you would see on your PAL SNES or Japan Super Famicom controller.


 CHANGES AND FIXES BY JOSHO:

Dirt levels no longer the pale brown look and now a rich red and golden yellow just like the Amiga version.
Yellow Pillar palette now match the Amiga version, now a proper golden Yellow rather than a bright lemon yellow.
Blue Crystal palette now matches the Amiga palette including the very dark one now black rather than BG blue.
Red Hell Fire Levels showing more reddish grey rather than a yellowish grey like the SNES retail version, Blue bricks are more Aqua Blue than a purplish blue..
Marble Levels now Pink and Lavender blue rather than Beige skin colour & purple.
SUNSOFT Intro at the start is now Blue gradient with SUNSOFT logo now Gold rather than Pink gradient and Silver.
The Game Title has improved a lot, Now a Mid Green gradient to replace the pale Light Green.
Improved the Level title & results writing palettes to be more like the Amiga Version.

LEVEL TITLE FIXES BY JOSHO:

Level 17 Tricky � Diet Lemmingade
Level 28 Tricky � Lost something?
Level 3 Taxing � Heaven can wait (we hope!!!!)
Level 16 Taxing � Marry Poppins� land
Level 11 Player 2 � Just for fun or to the death?

ALL SUNSOFT LEVELS TITLES RENAMED TO THE ONES SHOWN ON THE SEGA MEGADRIVE/GENESIS VERSION:

Level 1 SUNSOFT � Two heads are better�
Level 2 SUNSOFT � I am A.T.
Level 3 SUNSOFT � Private room available
Level 4 SUNSOFT � Final impediment
Level 5 SUNSOFT � Lemmings� Ark

RESTORED LEVELS THAT WERE CENSORED BY NINTENDO:
Level 21 Tricky � All the 6�s ��..
Restored Level 16 Fun & Level 3 Taxing level to show HEAVEN than PARADISE!
Level 24 Taxing � Take a running jump�.. Has it�s original level layout restored to show DEATH rather than TERMINATE.
Level 17 2 Player mode Map is restored.

�NOTE: Do NOT patch this Hack with the Lemmings v1.0 or v1.1 USA Revision ROM or the Lemmings Japan ROM. it will not work. You MUST patch this with the Lemmings Europe PAL ROM.�

I can confirm this ROM hack is compatible to run on real hardware using the SD2SNES Flashcart on a real Super Nintendo Hardware.