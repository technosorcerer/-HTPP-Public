Warning, this romhack features corrupted graphics that are flashy and will output loud noises.
Do not play if you suffer from epilepsy.


-----------------
Sen Remastered
------------


A romhack that carefully remasters the classic Sen corruption from Vinesauce. 

This remaster adds new extra content and makes it possible to complete the game. 

This can run on real hardware but for the fully-intended experience, use the BSNES core on Bizhawk.

You can wander in the void world in the search of spirits of sen forever

You can walk to the triforce

Choose your destination