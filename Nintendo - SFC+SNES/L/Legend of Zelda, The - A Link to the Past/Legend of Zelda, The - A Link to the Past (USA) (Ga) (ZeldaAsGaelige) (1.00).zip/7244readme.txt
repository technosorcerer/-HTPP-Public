This is a completely new Irish (Gaeilge/GA) translation of The Legend of Zelda - A Link to the Past (SNES). 

This was inspired by the fact that the  creators stated that Zelda was based on Celtic mythology, so it's quite fitting to translate it into the Celtic language of Irish. 

This translation also includes: 

Edited title screen and other screens to appear in Irish. 

An "Irish" Link (he is now a redhead!)

N.B. It is still underway but you can test it out here and please provide feedback, for example, if you spot any incorrect translations, especially as I'm not a native speaker. Send feedback/help/questions to: ZeldaAsGaeilge at gmail.com