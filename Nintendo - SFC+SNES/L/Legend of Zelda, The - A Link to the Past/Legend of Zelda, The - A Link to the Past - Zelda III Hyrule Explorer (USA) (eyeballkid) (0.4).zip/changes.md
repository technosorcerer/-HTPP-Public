Light World / Pendant order:
----------------------------

1. The Pegasus Boots are in a chest in the bombable room behind Sahasrahla. He promises them to you for after you beat the Eastern Palace. But you can "borrow" them from his storage room early. In case you do, and return to him after you beat the Eastern Palace, he'll not mention the boots - He's a polite guy after all.
2. The Pegasus Boots dialog now starts "You got" instead of "He gave" to reflect the above change.
3. The Pegasus Boots alternative item (which you get from the chest if you have the boots already) is set to 100 rupees. The boots replace the 3 bombs in the middle. The 3 bombs are moved to the right replacing 50 rupees.
4. The large stone blocking the entrance to Death Mountain is now a dashable pile.
   ![dmentr](gifs/dmentr.gif)
5. Remodeled the fence next to witch's hut to allow entrance to Zora's waterfall without the Power Glove.
   ![witch](gifs/witch.gif)


Dark World / Crystal order:
---------------------------

1. The hammerable barrier on the bridge south of the pyramid is now "broken" (presumably by the mad bombing of the angry Hinox!?).
   ![bridge](gifs/bridge.gif)
2. The dark stones at the bird landing point in the desert are now light stones. Misery Mire can be entered without the Titan Mitts.
   ![desert](gifs/desert.gif)
3. The fence below Thieves' Town is remodeled. You can now enter Thieves' Town via jumping the digging game fence - but only after you paid the fee.
   ![dig](gifs/dig.gif)
4. Remodeled the fairy island to allow access to the Ice Palace with hammer or Titan Mitts.
   ![lake](gifs/lake.gif)
5. The hammerable barrier on the bridge leading to Turtle Rock is now partially replaced by dark stones. Hence, Turtle Rock can be reached (but not entered!) with hammer or Titan Mitts.
   ![dmbridge](gifs/dmbridge.gif)


Dark World / Dungeons:
----------------------

1. Adjusted the barrier around the big chest of the Thieves' Town dungeon such that the Titan's Mitt can be acquired without the hammer.
   ![chest](gifs/chest.gif)



