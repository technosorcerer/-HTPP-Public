Zelda III: Hyrule Explorer
==========================

As we all know, ALttP enforces a very linear order of the dungeons (at least until you've played a large part of the game). This minimizes the exploration aspect to a large extend. The goal of this hack is to remove the linearity as much as possible, without changing anything substantial. In fact, the author very much aimed at the changes being completely unnoticeable if not invisible.

Obviously, it would not make sense to allow access to everything at any time. There are a few necessary "sync points" for the story: Link needs all pendants to get the Master Sword, to fight Aghanim, to transfer to the Dark World. Link needs all crystals to access Ganon's tower. Etc. Thus the goal is to allow an "as arbitrary as possible" order for getting the crystals and pendants, respectively.

An in-depth change log is provided (see changes.md or changes.html). However, it might be more interesting to try the modified game without spoiling these changes.


Author's note:
--------------

As of the time of writing this, the mod has been sitting around for over two years. Submitting it now was triggered by the release of "A Link to The Past: ReLink". I remembered that I had done something in the same direction some time ago, yet never posted it to RHDN. As stated in the description, I tried to make minimal invasive changes whereas "ReLink" seems to make larger adjustments. The reason for not submitting it at the time was that I meant to change the title screen. This, however, never got finished. Everything else should have been changed as intended.


Acknowledgments:
----------------

I got great advice from the nice people on the Zeldix and romhacking.net forum:

https://www.zeldix.net/t1287-zelda-iii-hyrule-explorer

So, a warm thank you goes to:

- Conn
- Puzzledude
- qwertymodo
- redmagejoe
- SunGodPortal
- superskuj


Version History:
----------------

v0.4 (2019-06-20):
Fixed an oversight in the Thieves' Town dungeon that locked the Titan's Mitt behind a hammerable barrier. Once again, thanks to redmagejoe for reporting this!

v0.3 (2019-03-22):
In v0.2 was a bug introduced by Hyrule Magic when opening the watergate in the swamp ruins: the jingle plays twice and the water rises twice, basically overflowing the room, however only visually. This was reported by redmagejoe (Thanks!) and wizardly fixed by Conn (Thanks!).

v0.2 (2017-01-02):
First version with the planned changes done.


