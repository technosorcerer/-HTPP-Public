                                      +
                                     +++
                                    +++++
                                   +++++++
                                  +++++++++
                                 +++++++++++
                                +++++++++++++
                               +++++++++++++++
                              +++++++++++++++++
                             +                 +
                            +++               +++
                           +++++             +++++
                          +++++++           +++++++
                         +++++++++         +++++++++
                        +++++++++++       +++++++++++
                       +++++++++++++     +++++++++++++
                      +++++++++++++++   +++++++++++++++
                     +++++++++++++++++ +++++++++++++++++
                    +++++++++++++++++++++++++++++++++++++

                             The Legend of Zelda
                             18 Hours Past v1.11
                                    Readme

                           Hack Made By Letterbomb
                       Version 1.00 - April 21st, 2023
                        Version 1.10 - May 17th, 2024
                        Version 1.11 - May 27th, 2024

                   Original Game Created by Nintendo for the
                Super Nintendo Entertainment System ©1991-1992


                          Readme is Best Viewed with
               Courier New 10 Pt Font with Word Wrap Turned Off


   /\                                                                     /\  
  /__\===================================================================/__\ 
 /\  /\                T A B L E   O F   C O N T E N T S                /\  /\
/__\/__\===============================================================/__\/__\


    I.  Folder Contents

          1.  Patching the Game

          2.  100% Map and Other Contents


   II.  About the Game

          1.  Introduction

          2.  Story (Prelude)

          3.  Frequently Asked Questions


  III.  Final Things

          1.  V1.11 Full Change List

          2.  Special Thanks and Credits


   /\                                                                     /\  
  /__\===================================================================/__\ 
 /\  /\                       I.  Folder Contents                       /\  /\
/__\/__\===============================================================/__\/__\

-------------------------------------------------------------------------------
                            I-1.  Patching the Game                            
-------------------------------------------------------------------------------

To play The Legend of Zelda: 18 Hours Past, you will need:

     1. The included patch (Version 1.11 or Version 1.00).

     2. A patching program such as Beat or Floating IPS.

     3. A copy of the original A Link To The Past (U) (Must be Headerless, if
     it's not there are tools like SNES ROM Utility that can remove the
     Header).
     (Don't bother asking for the Rom!!)

     4. Here is the correct ROM / ISO Information you need to patch the game:
     Name: Legend of Zelda, The - A Link to the Past (U) [!]
     Size: 1,048,576 bytes
     Checksum: CRC32 777AAC2F


To patch the rom, here's what you have to do:

     1. If you're patching the rom with Floating IPS, open the program and
     click on "Apply Patch". 

     2. Click on the Zelda3_18_Hours_Past_v1-11.bps or the
     Zelda3_18_Hours_Past_v1-00.bps file.

     3. Click on the original rom and you're patch will successfully work.


(NOTE: If this mini tutorial does not help, there are tutorials on
Romhacking.net that can help out.)


-------------------------------------------------------------------------------
                       I-2.  100% Map and Other Contents                            
-------------------------------------------------------------------------------

This folder includes some additional content such as the 100% Completion Maps,
the Original 1.00 version of the hack, a fanmade cover for the game, and of
course this Readme file. The 100% Maps for the Overworld and the Dungeons is a
huge spoiler for all of the items in the game, which is why it's in a spoiler
folder. So if you want to experience the game blind, it's highly recommended to
avoid looking at the Map until you are done with the game or if you can't find
an item in the game.


For those who do want to complete the game without looking at the Map for all
of the items, here is the list of items for the 100% Completion:

10 Heart Containers, Master Sword (L2 Sword), Fire Shield (L2 Shield), White
Mail (L2 Mail), Bow of Light, Boomerang, Bombs, Magic Powder, Lamp, Hammer,
Bug Catching Net, Bottle, Pegasus Boots, Power Glove, Diver’s Flippers,
Pendant of Courage, Pendant of Wisdom, and Pendant of Power.


   /\                                                                     /\  
  /__\===================================================================/__\ 
 /\  /\                       II.  About the Game                       /\  /\
/__\/__\===============================================================/__\/__\

-------------------------------------------------------------------------------
                              II-1.  Introduction
-------------------------------------------------------------------------------

The Legend of Zelda: 18 Hours Past is a fan made Zelda III romhack by
Letterbomb, that is based off of The Legend of Zelda: A Link to the Past. The
hack itself was finished while under an 18 hour time limit as a challenge
between Letterbomb, Zarby89, Jared_Brian_, and Scawful. Most of its development
took place from January 18th to the 27th in 2023, but it took until April 21st
of that year to publicly release the hack. When it came out, it started the
releases of the 18 Hour Hacks, and for a hack made so quickly, the reception of
the hack was very positive from a majority of players.

Because of the small amount of time, the hack has a reduced amount of content
in comparison to the base game that should be fun as a bite-sized hack. It
contains a redone Overworld and about four Dungeons total, along with
overhauled Houses and Caves. The Story is changed too, but again the timer made
it hard to vary the Story, especially since some content that aided the Story
was removed. All of this however, helped the v1.00 release be as polished and
playable as possible on release day.

After release, Letterbomb would return to the project here and there to work on
a version 1.01. Initially, the update was supposed to just fix the flaws of
1.00. But because of how insignificant of an update that would be, it
eventually jumped from 1.01 to 1.10 (Now 1.11). Lots of things that were
removed in v1.00 (Overworld/Dungeon Maps, Intros and Epilogues) were restored
in 1.10, and of course many things were added as development continued. But
because of the growing scale of the update, it actually took much longer for it
to be made than the original hack.

Since it took a while for the hack to be updated though, a ton of polish was
added to things like the Text, Story, Areas, etc. There’s also a ton of Quality
of Life improvements implemented, like a new Custom Menu, new item abilities,
and more. As of now, this is easily the most polished version of the hack.
Because of the level of polish, Letterbomb never intends on returning to work
on this hack ever again unless there are major flaws present in the game.

That being said, the creator hopes you enjoy playing through this short and
sweet hack of The Legend of Zelda: A Link to the Past!!


(NOTE: The creator included v1.00 in the folder since it is the original
version that took 18 hours to make. Feel free to play whatever version you
want, but to have the best experience it's recommended to play v1.11 for pretty
much everyone.)

-------------------------------------------------------------------------------
                             II-2.  Story (Prelude)                             
-------------------------------------------------------------------------------

The story for this game is not super strong, however there was still an attempt
to write something compelling and interesting for those who want to experience
something new. This section only covers before Link wakes up, so the rest of
story can be experienced in the game. Also, v1.11 has modified the story to be
even better, so there is a ton of background information added between the
original story and the modified story.


Here is the modified 1.11 Story:

The story takes place in the beautiful lands of Hylia, created by the Deities
of Hylia; Saria, Darunia, and Ruto. After Hylia’s inception, two relics known
as the Master Sword and the Tetraforce were left behind. The Tetraforce was an
extraordinary treasure which was capable of granting any wish possible. As the
world's population grew, this power became property of the Royal Family, where
it was kept away from the rest of the world. Because of the unfathomable power
the Tetraforce was rumored to have, many desired for this power. And soon, an
evil being named Ganon emerged from an alternate world to grab the power of the
Tetraforce himself.

In his attack, he shattered a part of the Tetraforce and it was downgraded to
what we know now as the Triforce. The shards of the shattered Tetraforce also
became the Pendant of Courage, Power and Wisdom, which were taken into hiding
along with the Triforce by the Royal Family. Not long after that, Ganon reigned
over the Royal Family and continued pursuing his search for the Triforce. As
everything was becoming much more hopeless during Ganon’s reign, a Chosen Hero
equipped with the legendary Master Sword and the Triforce emerged from the
darkness to put an end to his ruling.

The Hero was successful in defeating Ganon, and he was soon sealed away by the
King’s trusted Mages. Following Ganon's sealage, Hylia returned to the peaceful
lands it once was. Soon after, the Chosen Hero mysteriously disappeared and let
the Master Sword sleep in the Deep Woods. From there, all was looking well for
the future of Hylia. But one day, Ganon escaped his seal because of a Rogue
Mage who originally helped in sealing him. Ganon plotted his revenge ever since
he was defeated, so when he was removed from his seal he put his plan into
action. He first took over the Royal Family’s Soldiers, which caused havoc
around the lands of Hylia, that were formerly protected by them.

As this is all happening, Zelda who is the daughter of the Royal Family and a
friend are in the Forest Catacombs. Sensing that there was something wrong with
the world of Hylia, they prayed to the Deities of Hylia. During their prayers,
the Soldiers attacked and kidnapped Zelda and her friend and put Zelda into the
Forest Catacomb’s Prison. Without any way to escape, she calls to her childhood
friend Link, who is sleeping during this stormy and chaotic night. Hearing her
calls, Link wakes up and the story begins...


For anyone curious, here is the original 1.00 Story:

The story takes place in the peaceful lands of Hyrule, where everyone
has been living in harmony. However on one fateful day, Ganon arrived and took
over the Tower in the Village to make it his base. Not only that, but he made
plans to conquer the whole world of Hyrule using his army of soldiers. In the
process, the whole world becomes terrorized by soldiers, and while looting the
Catacombs, they capture this girl named Zelda. With no other choice, Zelda
calls out to Link telepathically to try and put an end to Ganon's tyranny. And
so the story begins...


(NOTE: I didn’t have too much time to write the story initially for the hack,
which is why it’s super simplistic. But hopefully the modified version 1.11
story is great!!)


-------------------------------------------------------------------------------
                        II-3.  Frequently Asked Questions                     
-------------------------------------------------------------------------------

If you find yourself stuck at the game or need help finding an item, hopefully
this FAQ section will help out:

Q: I have no Sword at the start of the game, what do I do against enemies?
A: In v1.11, you can now stun enemies with your fist and burn them with the
Lamp if you have magic. However, be careful when trying to stun certain
enemies.

Q: How do I know where to go in the hack?
A: In v1.11, there’s Overworld maps and Dungeon maps. If you didn’t read
certain NPC texts or you’re just clueless on what to do next, Overworld maps
will commonly have icons which show where to go next. The Fortune Teller in the
hack will also tell useful hints for where certain items are.

Q: How many Heart Pieces are there?
A: There are 12 in total, and all of them are found in the Overworld or are in
Caves or Houses. They are never located in Dungeons in this hack.

Q: Why are there Rupee chests in the Dungeons?
A: I had felt like there weren’t enough opportunities to make rupees in this
hack, so I included a couple of optional Rupee chests that you could find in
the Dungeons. These of course do not affect 100%, but they may drive some
people crazy on first playthroughs.

Q: Where do I find the Power Gloves?
A: Before getting the Gloves, you’ll need the Pegasus Boots. Once you have
those, I recommend checking The Cemetery/Potion Shop’s graves.

Q: Where can I find the White Mail?
A: I recommend checking the top of the Northern Steeple, aka the Tower in the
sky. If that doesn’t help, check the map to find a big chest icon.

Q: Is there anything to do after beating the game?
A: There’s unfortunately not any post game content, but you of course can comb
through the hack to find any items or heart pieces that you missed.

Q: Is there a Discord for this hack?
A: Yep! You can also find my other hacks I am working on nowadays. If you run
into any bugs or anything that wasn’t covered in the FAQ you can let me know
there too: https://discord.gg/gxMGhWes5t


It's recommended to join the Discord for help or watch walkthroughs if these
FAQ questions do not help out.


   /\                                                                     /\  
  /__\===================================================================/__\ 
 /\  /\                        III.  Final Things                       /\  /\
/__\/__\===============================================================/__\/__\

-------------------------------------------------------------------------------
                         III-1.  V1.11 Full Change List                        
-------------------------------------------------------------------------------

For anyone curious on what the differences are exactly between v1.11 and v1.00,
here is a full list of everything I changed in the game:

     - Title Screen Edits.
     - Added an Introduction Scene.
     - The story has been slightly reworked.
     - Added a new Menu.
     - Gave the ability to stun enemies with your fist/net.
     - You can burn enemies with the Lamp.
     - You can collect items with your Sword.
     - You can break pots with the L2 Sword.
     - There is a Day/Night System added into the game.
     - Gave all areas names.
     - Added an Overworld Map.
     - Small OW Edits.
     - Added Dungeon Maps.
     - Zelda has text during the escape sequence.
     - Text Overhauls.
     - Additional NPCs in Saria Village.
     - Added new behaviors to certain NPCs after getting certain items.
     - Mothula Spike Block Glitch Fixed.
     - Mothula gets hurt by the sword spins and Light Arrows.
     - The Shop sells Arrows instead of hearts.
     - The Hammer unlocks the Sky Isle's Spawn.
     - Added Clouds in the Northern Steeple.
     - Sprite Palettes and Graphics Fixed.
     - Exit Music plays correctly after exiting certain areas.
     - Rebalanced a couple of the enemies' health and damage.
     - Big Key on Menu updates after getting the dungeon item.
     - Fixed not respawning in Ganon's Fortress after dying to Ganon.
     - Fortune Teller now tells random hints regardless of progression.
     - Increased Bomb Capacity to 30.
     - Added Zoras near Link's House.
     - Removed a dungeon room in the Ancient Stronghold for the Map.
     - Added a dungeon room in the Northern Steeple for the Map.
     - Floor counter now works correctly whenever you warp.
     - Plenty of other bugfixes I probably forgot about now.
     - Plenty of dungeon adjustments I probably forgot about now.
     - Added an epilogue to the game.
     - Added an actual credit scene into the game.

There may be some other changes I completely forgot about, since this update
has been in the works for a long time now.


-------------------------------------------------------------------------------
                       III-2.  Special Thanks and Credits                      
-------------------------------------------------------------------------------

This hack would not be what it is without contributions from the following:

Letterbomb      Sole Hack Designer, v1.11 Improvements.

Zarby89         Developer of ZScream, tons of Assembly help and a great guy.
                The hack wouldn't be nearly as good without his help.

Jared_Brian_    Assembly help, and another great friend who has always been 
                very supportive since I've started hacking this game.

Scawful         Inspiration, helped a ton with assembly stuff and again is a
                great friend I love to work with.

Euclid          Probably my #1 inspiration for hacking this game, and of course
                created Parallel Worlds which is one of my favorite hacks.

SePH            Another #1 inspiration me, if he didn't release the Parallel
                Worlds Beta I would've never started hacking probably.

Puzzledude      Very helpful and full of valuable insights. Was again another
                big inspiration for me when I first got into hacking.

Omega45889      Inspired some of what the hack was. (Specifically Ganon's
                Fortress and the three Pendant format).

Sephiroth3      Zelda III Hacking wouldn’t be as good as it is now without
                the foundational work of Hyrule Magic.

MathOnNapkins   For the Original Disassembly hacking file for this game.

Kan             Created the new Disassembly hacking file for this game, and has
                helped out with a bunch of assembly stuff.

Jeimuzu         Inspiration, Beta Tester, very supportive and one of my best
                friends in the Zelda III hacking scene.

Coy             One of the first people to stream the 18 Hour Hacks. Also has a
                great personality to watch everytime he plays one of our hacks.

Qirn            Another person who streamed the 18 Hour Hacks, and even came up
                with a couple of speedrun strats in our hacks.

Codemann8       Another one of the first people to stream the 18 Hour Hacks.
                Gave constructive criticism that helped make the hack better.

SeanCass        One of the first speedrunners of the game, and even ran the
                game at a live marathon.

Conn            For some assembly patches.

JaSP            For the awesome Day/Night Cycle patch.

Clark           Beta Tester, Readme proof reader and a great friend. Shoutouts
                to them for failing to manhunt me both times we played this
                hack on ALttP Online.

CosmicClown     Another Beta Tester and great friend. Shoutouts to them for
                also failing to manhunt me on ALttP Online.

DaBrogo         Beta Tester and another great friend of mine.

Danaelo         Readme layout.

AstroBlue       Readme Triforce headers.

ALttP Staff     For creating the game we all know and love. I'll always cherish
                this game as one of my first experiences with video games.

The Player      For downloading this Z3 Hack and reading this Readme!


One last thing!! If you have not already, try out the other 18 Hour Hacks we
released as part of the 2023 18 Hour Hack Challenge. These Hacks are:

     Legend of Zelda: Hidden Trove
     By Zarby89

     The Legend of Zelda: The Shadow's Fall (Was updated in August 2023)
     By Jared_Brian_

     Zelda: Meadow of Shadows
     By Scawful

     Zelda: Interconnected Strongholds (Will also be updated to v1.10 soon!!)
     By Letterbomb


Of course, Letterbomb is working on more Romhacks for this game if you're
interested in seeing progress on more of his hacks on his discord. There's also
the ZScream Discord server which is the main place for Z3 Hacking nowadays.

Letterbomb’s Z3 Romhacks Discord - https://discord.gg/gxMGhWes5t
ZScream Discord - https://discord.gg/BsP4653pf5

Now, go and enjoy the Hack!!!


   /\                                                                     /\  
  /__\===================================================================/__\ 
 /\  /\                         T H E   E N D                           /\  /\
/__\/__\===============================================================/__\/__\
