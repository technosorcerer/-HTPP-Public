	The Legend of Zelda, The Hunters Song

               a hack by Alfonso De La Vega

original game: Zelda A Link to the Past for SNES, by Nintendo


This is my second Romhack and I used ZScream to make it.
A sequel of sorts to my first romhack which...( it's alright, but not necessary for this)



********Information about the original base Rom********

Database match: Legend of Zelda, The - A Link to the Past (USA)
Database: No-Intro: Super Nintendo Entertainment System (v. 20210222-050638)
File/ROM SHA-1: 6D4F10A8B10E10DBE624CB23CF03B88BB8252973
File/ROM CRC32: 777AAC2F



********Patching********


You need to have an original copy of the Rom. Use this Rom patcher to patch the file. Select your Rom of the original game, then 
the patch file "LOZTheHuntersSong.ips". 

https://www.romhacking.net/patch/



********About the Rom Hack********

"Old man Link" is awoken by a familiar minish sized friend in search of assistance....

This hack contrast the original story of a fated young hero, with that of an old man who previously completed a quest. 
New sprites, New story. Not only does link speak, but he's the first voice we hear!
The dialogue has been altered.
The overworld is somewhat altered. As are the three dungeons 
Completion time is short.
The difficulty is decent, however it's mostly a story driven affair.



********About the Hacker********

I'm an old school gamer with two kids. It took me about a year to complete this hack. 

I couldn't have done this without the support of the Zscream Discord community and moderators who are very supportive and kind. 

The phenomenal promotional artwork of "old man link" was made by @duckmansdrawings on instagram 



********Info for your hack********

Zscream  Discord- Join the community https://discord.gg/2g82Fvrn

Heres a video tutorial for Zscream part 1 made by Scawful(not me) 1 https://www.youtube.com/watch?v=9e2L0SfqJCc

