
 * * * * * * * * * * * * * * * * * * * * * * * * * * * 
 *      ______         _   _____    _____ ______     *
 *     /   __/  ___   | | /     \  /  ___/   __/     *
 *     \___  \ \__ \__| |/   |   \/  ___/\___  \     *
 *    /       \/ . / .  |    |    \     /       \    * 
 *    \_______/\___\____|____|____/____/\_______/    *
 *                        ______                     *
 *                    __ /      \                    *
 *       |        ___|  \\__  __/_ __       |        *
 *      -+-      / __|   \ /  \/  |  \     -+-       *
 *       |      /    |    \    \  |  /      |        *
 *              \____|____/____/\   /                *
 *                -Fraka-       /__/                 * 
 *                                                   * 
 * * * * * * * * * * [SadNES cITy] * * * * * * * * * *

               http://www.sadnes.emuita.it
           
                       presenta:

======================================================
            Legen of Zelda: A link to the past
		 Italiano versione 1.1
                     by mickey
                     09/09/2001
======================================================

------------------------------------------------------
0 - INDICE
------------------------------------------------------

1 - Come applicare la patch
2 - Progressi
3 - Ringraziamenti
4 - Disclaimer


------------------------------------------------------
1 - COME APPLICARE LA PATCH
------------------------------------------------------

N.B.:Prima di applicare la patch si consiglia di fare 
un backup della rom.
Si consiglia di applicare la patch su una Rom originale
(cio� ancora senza patch).

Scomprimere lo zip in una directory.
Copiare la rom del gioco nella medesima directory.
Con IPS:
  lanciare : ips nome.rom nome.ips.
Con UCON:
  lanciare : ucon i nome.rom nome.ips.
Con SNESTOOL
  lanciare SNESTOOL, selezionare "Use IPS"
  e seguire le istruzioni.
Giocarci con il vostro emulatore preferito.

    nome.rom = nome della rom da patchare
    nome.ips = nome della patch 

Se usate l'emulatore ZSNES in versione 0.800 potete rinominare
l'IPS con lo stesso nome della ROM in vostro possesso. Se la vostra
rom si chiama zelda.smc, rinominate la patch come zelda.ips. A quel
punto mettete la patch dove stanno i files di salvataggio (quelli
*.srm e *.zs?). Sembra pero' che la versione windows dello
Zsnes cerchi questi file nella cartella dove sono situate le
Rom. Quindi fate attenzione...


------------------------------------------------------
2 - PROGRESSI
------------------------------------------------------

Versione 1.1

- correzione di errori vari


Versione 1.0

- 100% del testo tradotto
- 100% del menu tradotto
- correzione di errori vari

Versione 0.9

- 97% del testo tradotto
- 90% del menu tradotto
- correzione di errori vari

Versione 0.8

- 96% del testo tradotto
- 10% del menu tradotto
- correzione di errori vari

Versione 0.5

- 75% del testo tradotto
- 10% del menu tradotto


Versione 0.1

- 5% del testo tradotto
- 1% del menu tradotto

------------------------------------------------------
3- RINGRAZIAMENTI
------------------------------------------------------

Un grazie particolare a _Ombra_, che � stato capace 
di trovare la tabella dei font degli oggetti del menu, 
pi� quella che permette di tradurre il menu iniziale
di scelta della partita.

------------------------------------------------------
4- DISCLAIMER
------------------------------------------------------

Questa patch deve essere usata solo per scopi LEGALI!
Usa questa patch a tuo rischio e pericolo :).
Questa patch pu� essere liberamente distribuita. Ti
Raccomandiamo solo di distribuirla nello stato in cui 
si trova. 
Non distribuire questa patch insieme alla rom del gioco
o il gioco gi� patchato!
Grazie


Nintendo, Zelda ed i relativi nomi sono marchi 
registrati dei relativi proprietari. 
Il gioco di ruolo Legend of Zelda: A link to the past � 
1991, 1992 �Nintendo

Michele
mickey@pointel.it