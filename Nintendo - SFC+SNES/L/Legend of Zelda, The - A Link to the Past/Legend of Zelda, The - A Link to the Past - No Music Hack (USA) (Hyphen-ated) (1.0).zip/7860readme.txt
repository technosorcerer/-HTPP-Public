This mod removes the background music in The Legend of Zelda a Link to the Past. Thank you very much to Hyphen-ated from the Legendairy Discord server for making this patch and giving Readmit permission to upload it here. Hyphen-ated has requested that the Github page for this patch be linked to in this description. Both the Github page and the original readme.txt file have been updated by Hyphen-ated to reflect the fact that this mod is compatible with both the Japanese and USA versions of the game.

The original name of the patch has not been changed, so feel free to rename your rom when applying the patch. This mod is compatible on both emulator and original hardware, and it is also compatible with the Legend of Zelda a Link to the Past Redux (the Patcher64+ tool is the most user-friendly way to make a redux rom), just make sure to apply the No Music patch after applying the redux and not before.

Here is the link to Hyphen-ated's original Link to the Past - No Music Github page:
https://github.com/Hyphen-ated/lttp-no-music

Please also visit Readmit's user page for other No-Music hacks.
https://www.romhacking.net/community/8095/