	The Legend of Zelda, The Winter Lion

               a hack by Alfonso De La Vega

original game: Zelda A Link to the Past for SNES, by Nintendo


This is my first Romhack and I used Hyrule Magic to make it.



********Information about the original base Rom********

Database match: Legend of Zelda, The - A Link to the Past (USA)
Database: No-Intro: Super Nintendo Entertainment System (v. 20210222-050638)
File/ROM SHA-1: 6D4F10A8B10E10DBE624CB23CF03B88BB8252973
File/ROM CRC32: 777AAC2F



********Patching********


You need to have an original copy of the Rom. Use this Rom patcher to patch the file. Select the patch file "Winterlion.ips" then your original Rom. 

https://www.romhacking.net/utilities/240/



********About the Rom Hack********

This hack contrast the original story of a fated young hero, with that of an old man, whos destiny is not fated but chosen. 
The motivations for saving Hyrule and the characters within have all been altered. 
This hack attempts to create two separate paths for the player to take, this is primarily within dungeons and the treasures they receive.
The dialogue has been completely changed to suite a slightly more complex political story and two separate story paths.
The overworld remains mostly unchanged. 
Most dungeons provide a branching pathway, new enemy placement and some alterations to the layout.
The difficulty has been kept the same as this is a more stroy driven hack.

Those seeking for a reason to revisit this SNES classic can now do so.



********About the Hacker********

I'm a father and haven't much time outside of work to have made custome sprites, more complex puzzles, tite screen, dungeons etc.

The story aspect of the game was inspired by the politics and persepctives found at wsws.org

I have zero knowledge on Hex editing. Had I better knowledge of the game/Hyrule Magic or the Newer Rom hacking utility , I would have made it much shorter (those doors!!!)

The phenomenal promotional artwork of "old man link" was made by @duckmansdrawings on instagram 



********Info for your hack********

There's a better utility out there that I did not use, Zscream https://www.romhacking.net/utilities/1507/, 

Heres a video tutorial part 1 made by Scawful(not me) 1 https://www.youtube.com/watch?v=9e2L0SfqJCc

I suggest you join the discord ZELDIX you'll find a really talented and friendly community. Join Here---> https://discord.com/invite/JmbKRYQ9

