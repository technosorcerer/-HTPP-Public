## Zelda: Meadow of Shadows V1.0
By scawful 1/22/2023 - 3/30/2023

### Description:
Meadow of Shadows is a short hack of the Legend of Zelda: A Link to the Past made under an 18 hour timer as apart of a challenge between myself, JaredBrian, Letterbomb, and Zarby89. The game features three dungeons and a final gauntlet area. It showcases the abilities of the ZScream editor and acts as a prequel to the upcoming Oracle of Secrets ROM hack. 

### Credits:
Scawful (Overworlds, Dungeons, Graphics, Palettes, etc.)
SePH (Minish Cap Graphics)
Zarby89 (ASM)
Letterbomb (Overworld Fixes)

### How to Patch

Download beat https://www.romhacking.net/utilities/893/

Patch "The Legend of Zelda: A Link to the Past" US ROM No Header

