A Link to the Past Quick Commands
Version 2
A mod by chillyfeez


INTRODUCTION

This is an improvement patch designed to add functionality from later Zelda games into A Link to the Past. In case are not familiar with the previous version of this patch, it allows the player to map up to eight different items to button combinations by holding the R or L shoulder buttons and pressing A, B, X or Y. If no button is mapped to a particular combination, the game will default to the normal ABXY functionality.


PATCHING INSTRUCTIONS

This mod is intended to work with an unedited copy of the North American release of The Legend of Zelda: A Link to the Past (AKA "Zelda 3") for the SNES. It may well work with other versions of the game, but I make no promises about that. The zip contains two patches - one to be used with a version of the ROM with a header, and one to be used with a version with no header. An unmodified copy of Zelda 3 with a header will display as 1025 KB; a copy with no header will display as 1024 KB. If you are at all unsure of whether your ROM has a header, I recommend making a backup copy before patching. If one patch doens't work, try the other.


HOW TO USE THIS MOD

To map items to button combinations, enter the menu screen (press Start) and highlight the item you want to map. Hil holding one of the shoulder buttons (L or R) press A, B, X or Y. You will see two symbols apprea to the left of the item, representing which button combination is mapped to the item. You may do this for up to eight button combinations. The game will remember your mappings if you save and quit.
While playing, press and hold the L or R buttons. A window will appear just below your heart meter indicating which items are mapped to the shoulder button you pressed. If you press both R and L at the same time, the window will show your R-mapped items. The R button supersedes the L button when both are pressed (in the previous version of this mod, the game would behave as though neither button was pressed in this situation).
To un-map a button combination, enter the menu, highlight the item you wish to un-map, and press its current combination.


WHAT'S NEW IN THIS VERSION

- A bug was discovered in teh original release of this mod. When starting the game from a hard boot or immediately after a fairy revive the Y button would be non-functional until the player first pressed the A button (and if Link didn't have the boots, then the A button must be used to pick up or grab something). This bug has been fixed.
- The HUD window that displays mapped items was added. This was an idea I had several months ago but I didn't ahve the motivation to look into it until the Y button bug was reported.