Hook - Movement Mod

This hack makes various changes to the movement of Hook.

1. No longer need to hold the attack button to run.
2. No longer need to hold the attack button to fly fast.
3. No longer need to hold the jump button to float underwater.
4. Constant run speed with no sliding.
5. Increased mid-air control.

This hack is compatible with the USA ROM of Hook.

You can apply this patch using Lunar IPS.

Documentation has been included.

Hope you enjoy.