DOCUMENTATION

SNES RAM ADDRESS: $7E0000-$7FFFFF

PROCESSOR: Ricoh 5A22 - based on a 16-bit CMD/GTE 65c816
https://en.wikibooks.org/wiki/Super_NES_Programming/65c816_reference
https://wiki.superfamicom.org/65816-reference

MAME Debugging:
mame snes -cart roms\hook.sfc -debug

Game Genie Code (For Testing)
Stop Timer: A268-6F03		(changes $00018AB5 from CE to CD)


CONTROLS:
$7E0025
01 = Right
02 = Left
04 = Down
08 = Up
10 = Start
20 = Select
40 = Attack
80 = Jump

SOME VARIABLES:
$7EF081 - Facing Left = 40, Facing Right = 00
$7EF1C1 - Position X
$7EF241 - 1 = IDLE, 2 = WALK, 3 = RUN, 4 = SLIDE
$7EF280 - 1 = IDLE, 2 = WALK, 0 = RUN
$7EF301 - SPEED:	C0 = IDLE, C1->FF -> 00->79 = WALKING, 80 = FULL SPEED
$7EF341 - MOMENTUM: 	0/1


THE CODE:

// Note that instruction A73F is located at 273F in a Hex Editor.
// For a futher example: B13F is located at 313F

ALWAYS RUNNING						CHANGE:
 00:A73F  lda $0025		AD 25 00	|	
 00:A742  and #$40		29 40		|	09 40		ora #$40

ALWAYS FAST FLYING LEFT/RIGHT				CHANGE:
 00:B13F  lda $0025		AD 25 00	|
 00:B142  and #$40		29 40		|	09 40		ora #$40

ALWAYS FAST FLYING UP/DOWN				CHANGE:
 00:B2C9  lda $0025		AD 25 00	|
 00:B2CC  and #$40		29 40		|	09 40		ora #$40

ALWAYS HOVER IN WATER					CHANGE:
 00:B64F  lda $0025		AD 25 00	|	
 00:B652  and #$80		29 80		|	
 00:B654  bne 00b66d ($17)	D0 17		|	80 17		bra 00b66d ($17)


REMOVE WALK TO RUN:					CHANGE:
 00:A74B  lda $7ef300,x		BF 00 F3 7E	|	
 00:A74F  clc			18		|	
 00:A750  adc $0001		6D 01 00	|	A9 80 EA	lda #$80	nop
 00:A753  sta $7ef300,x		9F 00 F3 7E	|
 00:A757  lda $7ef340,x		BF 40 F3 7E	|
 00:A75B  adc #$00		69 00		|	A9 01		lda #$01
 00:A75D  sta $7ef340,x		9F 40 F3 7E	|

REMOVE RUN TO WALK:					CHANGE:
 00:A6D6  lda $7ef340,x		BF 40 F3 7E	|
 00:A6DA  sbc #$00		E9 00		|	A9 00		lda #00
 00:A6DC  sta $7ef340,x		9F 40 F3 7E	|

REMOVE SLIDES:						CHANGE:
 00:A735  lda $0071		AD 71 00	|	A9 00		lda #00
 00:A738  and #$03		29 03		|	8D 71 00	sta $0071	
 00:A73A  beq 00a73f ($3)	F0 03		|	80 03		bra 00a73f ($3)

REMOVE SLIDE (LEFT):					CHANGE:
 00:A888  lda $7ef340,x		BF 40 F3 7E	|
 00:A88C  cmp #$01		C9 01		|
 00:A88E  bpl 00a8ac ($1c)	10 1C		|	EA EA		nop		nop

REMOVE SLIDE (RIGHT):					CHANGE:
 00:A96E  lda $7ef340,x		BF 40 F3 7E	|
 00:A972  cmp #$01		C9 01		|
 00:A974  bpl 00a994 ($1e)	10 1E		|	EA EA		nop		nop


REMOVE DUCK MOMENTUM:					CHANGE:
 00:AAEB  lda $7ef340,x		BF 40 F3 7E	|
 00:AAEF  sbc #$00		E9 00		|	A9 00		lda #00
 00:AAF1  sta $7ef340,x		9F 40 F3 7E	|


FAST DECELERATION (FOR MID-AIR TURNING)			CHANGE:
 00:ACB9  sbc #$04		E9 04		|	E9 40		sbc #$40
 00:ACBB  sta $7ef300,x		9F 00 F3 7E	|	
