Hi this is the world's first hong kong 97 romhack (besides the MSU1 hack)
This is based off of the famous Cave Story 97 by NameoftheDJ
Enjoy the slaughter of 2.50 million soaps
https://www.youtube.com/watch?v=4uzzMWnmXbQ
https://cavestorybeta.org/cave97.html

Hong Kong 2097 was mysteriouly announced 1 day after i got the graphics working (coincidence?)

# Patching

These patches need to be applied to the later version of HK97 featuring the CM button.

# Credits

Happy soft

Pixel for cave story, cave story beta

NameoftheDJ for the cave story 97 game maker pc game, and most of the graphics. (graphics starting with s)

tilderain, snes porting

motorola68000 for splash5 (su- umou)

Wirelex.exe for graphics starting with w (first cutscene and scuba puu in cm)

Vozaxhi for Puu's Restaurant, and the modded song (RasinnFlakes's Hong Kong 97 FLP)

Mildkyuu, "would you like to see your games in our website? all of the adsense money will go to us"

Satan
