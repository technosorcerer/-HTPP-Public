The Hunt for Red October - Options Menu Restoration Version 1.0 
15/01/2024

A simple Patch to bring back Option Menu only availiable on european version.
Bring you choice for mono/stereo option and a sound test 

Enjoy :)

Wabbajack 

Credits: Thanks tcrf.net for all the information collected about our favorite games, and thanks to romhacks.org to host this patch

