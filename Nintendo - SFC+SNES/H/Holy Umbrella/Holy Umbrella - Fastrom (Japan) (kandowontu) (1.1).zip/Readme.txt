This is FASTROM for Holy Umbrella (J) and the Aeon Genesis English Translation

Apply patch to either vanilla or the translated rom. 

Optionally, apply additional patch for translated rom on top of base patch.

Finally, because I forgot how I made the original patches, apply the v1.1 patch to update it.

SPECIAL THANKS TO ALL MY PATREONS

A SUPER THANK YOU TO MY TOP SUPPORTER:

Matthew Gambrell

EXTRA SPECIAL THANKS TO TOP PATREONS:

RHZ
RC_Meatpuppet
Sam M.
mobilevil
June M.
Sunrise Redeemer
Wabbajack


twitter.com/kandowontu
patreon.com/kandowontu
discord.gg/U4CtzqDGa5