Multi Level-up patch for Arcana (unheadered USA)

Allows EXP to roll over to the next level and allows gaining multiple levels in one battle.
(In vanilla, any extra EXP past a level up is lost.)
So, this makes the game a little less grindy.

If you'd like to mess around with this in a RAM editor, enemy EXP in the current battle is loaded to $136B-$137A.


Technical info:
Clears part of memory on startup to avoid adding uninitialized RAM.
Checks to make sure "Battle Won" music is playing to avoid the function being called in the wrong situation.
Confirmed to work after a Game Over without breaking the game.


1.1
(torha) Fixed a patch conflict with Fastrom Patch.

1.0
(rainponcho/Sarah Shinespark) Initial release.