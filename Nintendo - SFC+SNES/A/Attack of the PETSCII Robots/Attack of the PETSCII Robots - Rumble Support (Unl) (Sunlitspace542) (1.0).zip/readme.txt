Attack of the PETSCII Robots SNES Rumble Pad Patch
==================================================
Patch code by Sunlit, patch version 1.0

This patch adds SNES Rumble Pad support to the Super NES version of Attack of the PETSCII Robots by David Murray (The 8-Bit Guy) et al.

Tested on Mesen 2 and real hardware with a LRG rumble pad prototype.
This patch was designed around the strength of the LRG rumble pad. Rumble strength may vary depending on your choice of emulator/controller.

Rumble effects are now triggered with certain sound effects and actions. These include:
- Changing weapons
- Door open/close
- Items (EMP, magnet, medkit, bomb)
- Gunfire (pistol, plasma gun, robots)
- Moving/placing objects
- Player damage
- Explosions

Usage
=====
The patch is to be applied to a PETSCII Robots SNES ROM with the following SHA1 checksum: 3c2e040cda0dfff1c8fe0e62846314cb7a83b1f6
Its No-Intro database name is "Attack of the PETSCII Robots (World) (Aftermarket) (Unl)".

Rumble is supported by the following emulators:
- Mesen 2 (https://github.com/SourMesen/Mesen2)
- Ares (https://github.com/ares-emulator/ares) (Not in any releases yet as of writing)

You can also play with rumble on real SNES hardware with the following input devices:
- LRG SNES rumble controller (not shipped yet as of writing)
- SNES BlueRetro adapter and a compatible Bluetooth controller with rumble support (e.g. Xbox One, 8bitdo SN30)

Credits
=======
SNES-Robots by David Murray, Govak Lamesi, Piotr Radecki, Noelle Aman
SNES rumble protocol designed by Randy Linden

Tools Used
==========
DiztinGUIsh, BSNES plus special DiztinGUIsh patch - For generating a basic ROM disassembly
Asar - Assembler
Mesen 2 - Testing, debugging
FXPak Pro - Real hardware testing