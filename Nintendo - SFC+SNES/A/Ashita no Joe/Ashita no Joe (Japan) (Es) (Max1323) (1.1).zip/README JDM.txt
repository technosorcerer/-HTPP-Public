"Ashita no Joe" o "Joe del Mañana"
Traducción al Español Ver. 1.1 (29/03/2025)
por Max1323 (Traducciones Max1323).
Basada en la traducción de Vice Translations.
---------------------------------------------------
Descripción:
Ashita no Joe basado en el manga del mismo nombre. 
Juego de boxeo en el que tendras que derribar a tus 
contrincantes.

Desarrollado: Wave
Publicado:    K Amusement Leasing
Lanzamiento:  27/11/1992 (JAP)
---------------------------------------------------
Acerca del proyecto:
-La mayoría de los textos están traducidos. Se agregaron los caracteres españoles.

-La mayoría de los gráficos fueron traducidos. Hay un parche alternativo que traduce el título del juego.

-Desde la 1.0 solo usa la traducción de los textos de la versión de Vice Translations.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS (PC)
Utilizar UniPatcher (Android)
Utilizar Rom Patcher (Parcheador Online):
https://romhackplaza.org/patch/

Archivo IPS
Ashita no Joe (Japan).sfc
File Size:    1.00 MB
File MD5      C7F80EB13AD9EE5FB5598B24002B6113        
File SHA-1    36A58CF915F394875B1FF6CB9BCA539E0CB4BDA0
File CRC32    6B54BE97