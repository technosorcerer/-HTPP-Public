Arkista's Ring (NES)
Traducción al Español v2.0 (28/09/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Corregido orden de objetos
-Recolocados textos
-Cambiado orden de escritura para arco y flechas
-Añadidos É, Ó

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Arkista's Ring (USA).nes
MD5: 99acc5f49d953eafdce418ee21bc63ca
SHA1: 940d3dac5144e2a6399bad3bbe260d93270af10e
CRC32: cd3aa2a5
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.
signatux - Pruebas.

-- FIN --