Parche de traducci�n al castellano para el juego "Adventures of Batman & Robin" de Super Nintendo

�Esto qu� es?

Esto es un parche para modificar el mencionado juego de Super Nintendo y traducir en la medida de los posible los textos al castellano.

�Qu� est� traducido?

Est� traducido todo el gui�n del juego, faltando la pantalla de t�tulo, el men� de selecci�n de armas y los nombres de los niveles que cuentan con compresi�n de texto y se escapa a mis conocimientos actuales.

Se han a�adido todas las vocales acentuadas, exclamaci�n, interrogante y nuestra querida �.

Bugs y estad�sticas

Uno de los niveles del juego tiene lugar en un museo en el que buscamos rehenes y Robin nos avisa v�a interfono de la localizaci�n de dichos rehenes, la he testeado MUCHAS veces pero en una ocasi�n, Robin me dijo que hab�a rehenes en 1a y en realidad estaban en 1b, estoy SEGURO de que es un fallo de la versi�n original porque al cargar la rom original, esto segu�a pasando, solo me ha pasado una vez de much�simas que he jugado y tampoco es traum�tico porque no lleva mucho tiempo mirar el resto de habitaciones.

Otro de los niveles tiene lugar en un escenario pensado por Riddler en el que nos propone unas adivinanzas para seguir avanzando el nivel, dos de ellas no eran m�s que una excusa para activar trampas o mandarte al principio del nivel as� que las he cambiado por otras cosas que, si bien mucha gente tendr� que buscar la respuesta en internet, la respuesta SE PUEDE encontrar, la respuesta original es carne absoluta de gu�a o de saber la respuesta ya que el nivel se basa en un episodio de "Batman Animated Series" en el que salen dichos enigmas.

En la consecuci�n de este proyecto se han invertido como 40 horas, inclu�do el testeo.

�Para qu� versiones vale este parche y qui�n lo puede usar?

Este parche solo se puede aplicar con �xito a la rom "Adventures of Batman & Robin, The (U) [!].smc" ROM CRC32    B3EF81F5

�Qu� me hace falta para instalarlo?

La rom en cuesti�n, este parche y un parcheador ips.

�C�mo aplico la traducci�n?

Usa un parcheador IPS, por ejemplo Lunar Ips para aplicar el parche a la rom y listo.

Notas: 

Se ha testeado el juego a FUEGO en el emulador bizhawk pero esta vez NO se ha probado en hardware real(everdrive), si alguien lo prueba, por favor que se ponga en contacto conmigo para actualizar este archivo de informaci�n.

Gracias por usar esta traducci�n.

Jackic 2019.