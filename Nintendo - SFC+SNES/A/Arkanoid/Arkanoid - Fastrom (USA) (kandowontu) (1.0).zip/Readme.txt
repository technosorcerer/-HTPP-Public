This is FASTROM for Arkanoid - Doh It Again (U) and (J)

SPECIAL THANKS TO ALL MY PATREONS

EXTRA SPECIAL THANKS TO TOP PATREONS:

RHZ
RC_Meatpuppet
Sam M.
mobilevil
June M.
Sunrise Redeemer

twitter.com/kandowontu
patreon.com/kandowontu
discord.gg/U4CtzqDGa5