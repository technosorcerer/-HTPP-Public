Use the one you want:

Amazing Spider-Man, The - Lethal Foes (Japan).ips  ----- normal font
spiderallcaps.ips  ---- ALL LETTERS ARE CAPS