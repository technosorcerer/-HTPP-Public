- Put your ROM in this folder and rename it to "ActRaiser 2 (U) [!].smc"
- If it has a external 0x200 byte header. Remove it and check if you have the rigth ROM. 
- Double click make.bat to patch main.asm to ROM. You find modefied ROM in the root directory. 

Database match: ActRaiser 2 (USA)
Database: No-Intro: Super Nintendo Entertainment System (v. 20210222-050638)
File/ROM SHA-1: 17C086F3418F7F51E5472270D756EC5112914B83
File/ROM CRC32: 4901F718