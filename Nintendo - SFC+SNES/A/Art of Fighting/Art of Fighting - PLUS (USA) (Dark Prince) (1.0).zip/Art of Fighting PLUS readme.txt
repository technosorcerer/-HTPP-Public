                                       Art of Fighting PLUS, 2025.
                                          Made by Dark Prince.

This hack aims to improve the game's visuals while also bringing some uncensored content and a boss hack, something never done for this port before.

As such, it brings the following features:
-ALL characters can be used in the story mode now, just press right and anyone past Robert is one of the previously unplayable characters!
-Graphics are much better in this version, with new fonts that look almost identical to the Neo Geo/Sega Genesis versions.
-Some things have been uncensored, like the bottles in the bottle cut minigame, Mr. Big in the ending as well as King's shirt.
-Some other graphics and palettes are now more accurate to the Neo Geo version, like Mr Karate's palette and icon and the game over screen numbers.
-The level names use a green font identical to the Neo Geo version instead of the usual orange palette.
-Intro picture is more accurate to the Neo Geo version.

And the following bugs:
-Selecting the new characters in the story mode doesn't look good and the characters don't really match what's on screen.
-Mr. Karate has glitchy projectiles in the first fight against Todo in story mode, this was present in the original and I don't know exactly how to fix this.
-Mr. Karate also has a wrong lose portrait due to him never having one in the original SNES port.
-Due to the way the game is programmed, most of the dialogue is broken if using the new characters, this doesn't crash the game unless you stand still in some of the character story mode intros. I recommend to always skip the story mode intros if using characters other than Ryo or Robert.
-Playing the super fire blow as anyone except Ryo, Robert and Mr. Karate is useless. This one isn't a bug but you should still note it.

Credits to Luciano_bullock in The Spriters Resource for the rips used, this hack wouldn't look as good if it weren't for this person.