GOURMET SENTAI BARAYAROU
(Gourmet Warriors)
FULL TRANSLATION by chillyfeez
2024



I. INTRODUCTION

Gourmet Warriors is a quirky beat 'em up for the Super Famicom produced by Virgin Interactive that was originally relased only in Japan. The gameplay, frankly, is a bit generic as beat 'em ups go; what stands out about this title is its personality and its extensive menu (pun intended) of secrets and easter eggs.
I was originally approached about this project by Advancedpillow, who discovered the game several years ago and had an idea for a feature to add (See: III. OPTIONAL POSING HEALS PATCH). After quick implementation of that feature, the discussion broadened to completing the translation that was started by Aeon Genesis and Gideon Zhi in 2000.
While there are some detailed descriptions of added features, this Readme is not an instruction manual. For a full breakdown of the features and secrets this game has to offer, I recommend checking out Goh_Billy's guide on gamefaqs (https://gamefaqs.gamespot.com/pc/267318-gourmet-warriors/faqs/80038).


II. THE TRANSLATION 

The following translations/additions have been implemented with this patch:

A. Intro Screens - There are three expository introductions screens that play in between teh Virgin logo and the title screen, which (questonably) establish the game's story. These screens have been translated.

B. Character Bios - When the title screen shows, if the game is not started within ~45 seconds the game will show a characcter bio and a gameplay demo. The bios have been translated. Implementation of these translations included graphics decompression (this is why the file size of the translation is 1 MB larger than the original ROM).

C. Enemy Bios - if you allow the bios of all three characters to show four times each without begining your game, instead of a fifth rotation the game will show the bios of three enemy characters (who are also playable via one of the game's most intriguing secrets). These enemy bios have also been translated.

D. Options Menu - The options menu, which allows controller customization and difficulty setting, has been translated.

E. Ending Screens - Similar to the intro screens, there are two ending screens that have been translated (one will show after completing the game on Medium Flavor - AKA normal difficulty - and one will show after complting the game on Spicy Flavor - AKA hard mode).

F. Karaoke Mode - At the title screen, holding L, R and Select will enable Karaoke Mode. The lyrics to the theme song appear on screen in time with the music. In the original game, the player woudl need to hold these buttons for ~12 sconds before the text would begin to appear. This translation includes the addition of the words "KARAOKE MODE" at the top of the screen, so there is no question whether you're doing it correctly. Additionally, an extra easter egg was added in to Karaoke Mode - it has a 1/256 chance of happening on its own, but can also be forced by holding the Start button as the title screen fades in. The karaoke lyrics of a different song will show on screen. I don't want to spoil the surprise so that's all I'll tell you. See for yourself!

G. Cooking Interlude - Between levels, the game gives the players the opportunity to combine two "ingredients" picked up into a meal that will restore the life bar to varying degrees. The ingredients and the resulting dishes were previously translated, but this patch translates the rest of the text as well.

H. Ending Credits - The ending credits (shown upon completing the game) have been restructured and now include translation credits.


III. OPTIONAL POSING HEALS PATCH

Likely the most unique but also unquestionably the most pointless gameplay feature, the playable characters have the ability to pose by holding the A button, and will change their poses when pressing different directions on the D-pad. In the original ROM, this posing does absolutely nothing except provide some comic relief to the player. Per Advancedpillow's original request, a feature has been implemented that allows the player to refill their life bar by executing different poses. The speed at which the life bar refills, and the total amount that can be refilled by posing, varies depending on the Flavor (difficulty) selection.


IV. Credits

ORIGINAL TRANSLATION PATCH
Aeon Genesis/Gideon Zhi

TRANSLATION CONCEPT
advancedpillow

LANGUAGE TRANSLATION
Onoreto

HACKING AND ASM WORK
chillyfeez