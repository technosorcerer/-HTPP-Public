Go Go Ackman1 English patch
http://tasam.com/~voltron/ackman

version 1.0

Contributers:
-Rom hacking: Equinox(equinox@fireduck.com)
-Script Translation: Akujin(http://members.xoom.com/_XMCM/akujin_/index.html)
-Initial Spot translation: Teunire

What might be done in future:
-Reword a few lines
-Get rid of ugly font

Tools used:
-thingy
-hexposure
-hex workshop
-NJ star
-relsearch

Thanks to:
-Akujin for showing me the empty space in the rom along with the wonderful translation work
-Jair for having such a wonderful tuturial at http://fly.to/vale to get me started
