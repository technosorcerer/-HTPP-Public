This is a hack of Gradius III (USA) for Super Nintendo. that simply replaces the VIC VIPER with the Halberd from another Super Nintendo Shooter called "BIOMETAL" developed by Athena and published in the west by Activision. why halberd? Idk. just felt like it. IT DOES NOT CHANGE INTRO AND ENDING GRAPHICS.

HOW TO PATCH:
Use an online patcher (like the one on Romhack Plaza) or a patching program (Like Flips). once you are on either of those programs or a different program not specified. you would need a Gradius III (USA).sfc file (You are on your own for this one, sorry not sorry). and the Halberd.bps patch (Obviously). the patchers usually ask for a unmodified rom. so go where your Gradius III rom is. choose that. and then go and find Halberd.bps and then PATCH IT. now you use your preferred emulator. if you don't have an emulator. ones generally recommended are.

Snes9X
BSNES
MESEN
Ares
Retroarch (Use of the Snes9x and Bsnes cores)
Bizhawk

Credits
Gradius III and Vic Viper is owned by: Konami

the Halberd and Biometal is owned by: Athena/Activision

Sprite import by 15Tails

Disabling palette animations from Vic Viper by: Bogaa and 15Tails 

Palette change by: 15Tails