This is a hack of Gradius III (USA) for Super Nintendo. that simply replaces the VIC VIPER with the MF-92GX Halbard from another Super Nintendo Shooter called “BIOMETAL” developed by Athena and published in the west by Activision. why the MF-92GX Halbard? Idk. just felt like it. THIS DOES NOT CHANGE INTRO AND ENDING GRAPHICS. now you also might be also wondering. 

what's with the "+ EXTRA" on the name? especially since that wasn't there on older versions. Funny you mention that! There's more than just the MF-92GX included in the Folder.

You now have these options to use from instead of the Vic Viper!
MF-92GX Halbard from BIOMETAL. (Obviously)
Memim from Jikkyou Oshaberi Parodius. (we come full circle also includes font changes!)
Sue also from Jikkyou Oshaberi Parodius. (Font included still)
Mario from... Super Mario brothers (riding the sky pop from Super Mario land)

And many more coming soon... eventually... probably... eh don't get too excited.
--------------------------------------------------------------------------------------------------------
HOW TO PATCH:
Use an online patcher (like the one on Romhack Plaza) or a patching program (Like Flips). once you are on either of those programs or a different program not specified. you would need a Gradius III (USA).sfc file (You are on your own for this one, sorry not sorry). and the Halbard.bps patch or any other bps patch included in the folders of your choice (Obviously). the patchers usually ask for a unmodified rom. so go where your Gradius III rom is. choose that. and then go and find Halbard.bps or any other BPS included in the folder you wish to use instead and then PATCH IT. now you can use your preferred emulator. if you don't have an emulator. ones generally recommended are.

Snes9X
BSNES
MESEN
Ares
Retroarch (Use of the Snes9x and Bsnes cores)
Bizhawk
--------------------------------------------------------------------------------------------------------
Version 2.6 Changes:
Removed Bonus stages (It caused soft lock problems)
All instances of Halberd has been fixed.
--------------------------------------------------------------------------------------------------------
Version 2.5 Changes:
Added Sue (Uses Jikkyou Oshaberi Parodius SNES Sprites, also Modified to fit in Gradius 3 just like Memim)
Added Mario (Uses the Skypop sprites from Super Mario Land with slightly modified to give color)
--------------------------------------------------------------------------------------------------------
Version 2.0 Changes:
Added Memim (Uses Jikkyou Oshaberi Parodius SNES Sprites, modified a bit to fit in Gradius 3)
Font changes when using the Memim patch.
Halbard patch left unchanged.
Removed 1.0 Halbard ships. (it was crap anyway)
--------------------------------------------------------------------------------------------------------
Version 1.5 Changes:
Redone Halbard sprites
Renamed Main patch to MF-92GX Halbard to match the ships original name in BIOMETAL.
Redone Reduce shield sprites
Fixed Halbard Sprites
Added 1.0's Misaligned sprites as separate for historical purposes
Corrected spelling of Halberd to Halbard on this exact Readme.txt and Description
yes It's not a typo. it's ACTUALLY called Harbard in the game. not Halberd.
--------------------------------------------------------------------------------------------------------
Credits:
Gradius III and Vic Viper is owned by: Konami

Memim and Sue and Parodius is also owned by: Konami

the Halberd and Biometal is owned by: Athena/Activision

Mario is owned by: Nintendo

Sprite import by 15Tails

Disabling palette animations from Vic Viper by: Bogaa and 15Tails 

Palette change by: 15Tails

Special Thanks: Meeky and Kando for some Discord-related Chaos.

Mario Idea: MathUser2929
--------------------------------------------------------------------------------------------------------
For fun pause the game and Do: Up, Up, Down, Down, Left, Right, Left, Right, B, A Start.