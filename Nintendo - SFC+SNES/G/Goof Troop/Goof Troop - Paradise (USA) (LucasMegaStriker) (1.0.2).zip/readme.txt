Goof Troop Paradise
version 1.0.2

CHANGELOG 1.0.1:
- Fixed issues with some doors at the final stage (both versions);
- Fixed some minor spelling mistakes on the Portuguese version.

CHANGELOG 1.0.2:
- Changed some rooms of the final level due to a persistent bug with door events (both versions)