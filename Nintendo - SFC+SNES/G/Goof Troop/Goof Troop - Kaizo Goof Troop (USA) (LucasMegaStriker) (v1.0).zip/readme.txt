Kaizo Goof Troop
Version: 1.0
Date: January 19, 2026
Modified by: MegaStriker

If you downloaded this modification of Goof Troop, you should be aware of the difficult. It is the very first attempt of making a kaizo-like experience on SNES Goof Troop. Good luck, you're going to need it.

Available in both English and Brazilian Portuguese.