Goof Troop Paradise
version 1.0.3

CHANGELOG 1.0.3:
- Fixed played 2 stuck on a tree at one of level 4 screens;
- Fixed the riddle logic to open level 4 boss room (4 rows instead of 3).

CHANGELOG 1.0.2:
- Changed some rooms of the final level due to a persistent bug with door events (both versions)

CHANGELOG 1.0.1:
- Fixed issues with some doors at the final stage (both versions);
- Fixed some minor spelling mistakes on the Portuguese version.