This is FASTROM for The Great Battle V (J)

This patch has been specially designed to work with the English translation! Apply this patch first.

SPECIAL THANKS TO ALL MY PATREONS

EXTRA SPECIAL THANKS TO TOP PATREONS:

RHZ
RC_Meatpuppet
Sam M.
mobilevil
June M.
Sunrise Redeemer

twitter.com/kandowontu
patreon.com/kandowontu
discord.gg/U4CtzqDGa5