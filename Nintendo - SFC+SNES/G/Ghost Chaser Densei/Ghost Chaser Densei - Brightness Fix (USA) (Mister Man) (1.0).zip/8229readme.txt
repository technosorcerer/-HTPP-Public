----------------------------------------
| Ghost Chaser Densei - Brightness Fix |
|          v1.0 by Mister Man          |
----------------------------------------
| Introduction                         |
----------------------------------------
When it comes to palettes, Ghost Chaser Densei features somewhat dim colors compared to Densei Makai, the original arcade game. The reason for this is because the developers made it so the brightness variable (which then gets sent to the SNES' brightness register) only goes up to value 0x0A, which would be the equivalent of around 40% brightness.

This hack fixes this issue by instead making the brightness variable go up to value 0x0F (which would the equivalent of 100% brightness), allowing the game to display the actual undimmed palettes.

Note that this hack is also compatible with the translation patches available for this game.

----------------------------------------
| Changelog                            |
----------------------------------------
| v1.0                                 |
----------------------------------------
* Initial release

* Modified some parts of the game's code to allow the brightness variable to go up to value 0x0F
* Updated the ROM's checksum

----------------------------------------
| Patching                             |
----------------------------------------
To apply this patch, any program that supports the IPS patch format (like LunarIPS) is required.

The patch provided works with the only known version of the game:
* "Ghost Chaser Densei (Japan)"

----------------------------------------
| Tools Used                           |
----------------------------------------
* Mesen-S
* FlexHEX 
* IPSandSUM SNES ROM Utility (by Bongo')
* SNES9x