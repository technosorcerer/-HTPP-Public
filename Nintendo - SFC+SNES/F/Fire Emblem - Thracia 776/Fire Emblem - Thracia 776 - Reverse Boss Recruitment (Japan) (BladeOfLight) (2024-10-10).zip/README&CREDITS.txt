Apply to an unheadered ROM version of Thracia.

NOTE: Every patch in the main folder and in the 'Growth Mods" folder has to be applied to an unmodified ROM, but the patches in the 'Optional' folder have to applied to a patched ROM instead.

You can apply the patch by simply doubleclicking it after extracting the folder. If you need help with anything, read the other .txt files.

-------------------------CREDITS:--------------------------

Thracia Boss RR patch made by Blade of Light.

The Patch was made with the tools created by Zane Avernathy.

The Translation Patch used by this patch is the Lil' Manster Patch, made by Miacis, Ultimage, Expert Criminal, Tchuu, Flasuban and the power of friendship (read: the help of many others whose names I don't know) as well the oroginal Project Exile team.

The base game was, of course, developed by Shōzō Kaga and the FE5 development team.

Huge Thanks to Miacis, Ultimage and the FE5 Hacking Server; this hack would not have been possible without your help!