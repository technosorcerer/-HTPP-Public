Fire Emblem: Thracia 776 - Versione Italiana v.0.8.18

Contenuti:
- Tutti i menu e i capitoli fino al 18 (compresi i capitoli secondari) tradotti in italiano.

Guida all'installazione:
- Procurarsi con i propri mezzi una ROM del gioco non modificata e senza header.
Si può verificare di avere la versione giusta della ROM tramite uno strumento per calcolare i suoi valori di checksum.
I valori di checksum della ROM dovrebbero essere:
MD5      C3FD1CAD754256D7A013864D917F47FA
SHA-1    75B504921D08E313FF58150E40121AC701884517
CRC32    FC519952
- Eseguire il programma Flips.exe nella cartella della traduzione.
- Selezionare "Apply Patch" e selezionare FE5_IT.ips, seguito dalla ROM non modificata.
- Scegliere un nome per la ROM modificata, che sarà il gioco tradotto in italiano.

Aggiornamenti:
- v.0.8.18: Prima versione beta pubblica.

Riconoscimenti:
EnDavio - Capo progetto, programmatore, editor
VittorioFGC - Editor

Ringraziamenti speciali:
I nostri tester e coloro che lo diventeranno
Miacis e il team di sviluppo di Lil’ Manster, su cui si basa questa traduzione
Il team di sviluppo di Project Exile, su cui si basava originariamente questa traduzione
Xylonphone, l’amministratore del server Discord “FE5 Hacking Hel”
Il server Discord “I Genealogisti di Roy,” per il supporto
