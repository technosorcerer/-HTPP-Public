
### V 0.1 (June 29 2023)

Initial release

This includes the following chapters:
- Another Journey
- Birds of a Feather
- In Search of Truth
- The Peddler Merlinus

The following menus are fully implemented:
- Unit inventories
- Trade window
- Options window
- Status window
- Unit list window

The following menus are partially implemented/and/or are placeholders:
- A/B menus
- Main menu
- Battle forecast
- Shops
