--------------------------------
 FE5: New Theory of Thracia 776
--------------------------------

Notice
 - Details of the contents of this hack and the latest information are available on my blog.
   https://fe5.jpn.org/en/

 - I try to upload new articles in English at the same time, 
   but older information may only be available in Japanese. Read about it in machine translation.
   Japanese version is here: https://fe5.jpn.org/

   If you cannot understand the content due to machine translation, please let me know. 
   I will give priority to creating translated articles.


Summary
 - This is FE5 based hack, is designed as a new interpretation that the story of 
   the Gran calendar year 776 based on new historical documents. 
   Some parts of the story are inconsistent with the original FE4 and FE5, 
   but please enjoy it as a new or a different theory.

 - The beginning of the story emphasizes Leif's fate with the House Freege, 
   the second half of the story emphasizes Leif’s story as a heroic fantasy.
   The final boss is King Blume. Against the Freege, who rule the region of Northern Thracia, 
   Leif can end them by his own hand!

 - I also added several branching events so that the player's choices are reflected in the scenario. 
   Strange actions that you would not normally take lead to strange results. 
   These vary, some of which are hinted at in-game, while others are only noticed if you read the manual. 
   Depending on your choices, you may even be able to get people who wouldn't normally join your team to do so.


Notes on use
 - Please apply to the ROM version FE5.smc file (with header), size: 4,194,816, CRC32: 95E289DD.
   This CRC32 refers to the value of the file, 
   not the value that can be checked within the emulator.

 - The NP version does not work properly because its internal structure is different.
   ROM version refers to the ROM cassette version released in 2000.
   NP version refers to the version written to SF memory cassettes (including the prewritten version).

 - If you only have a ROM without a header, add +200h (the contents can be filled in with 00) 
   to the beginning of the ROM file. This is sufficient because the ips patch does not verify 
   the target file, but overwrites the bytes at a fixed position in the file.

 - Please apply it to an unmodified Japanese ROM.

 - Do not use this patch in conjunction with other patches, 
   as the internal configuration may be changed in some parts, which may cause unexpected behavior.

 - This patch is made with Lunar IPS.


Recommended environment
 - Because of the ROM expansion, it will not work without an emulator that supports ExLoROM.

 - The following emulators are confirmed to work.
   Snes9X v1.57 for Windows 
   snesgtx（SNESGT ver0.230 beta 7 ＋ "SNESGT ExLoROM 対応パッチ"）
   Snes9x EX+（Android）


How to select language
 - A new screen has been added for initial startup.
   Pressing B on this screen will start the game in English; pressing A will start it in Japanese.
   If data exists in the save slot, this screen will not appear at startup. 
   But, after starting the game, you can still switch languages by pressing the X button, 
   at the settings screen.

 - This is a Japanese hack, but it implements an English text.
   In English mode, the story and other texts are displayed in English.
   (You can switch between Japanese and English with one ROM.)


About the translated text
 - The text of the story is roughly translated at DeepL and then input with corrections. 
   My English translations may seem unnatural to native speakers, 
   because my first language is Japanese. 
   I welcome any suggestions for grammatical errors fixing, etc. 

 - For the time being, a primary goal is to provide something that can be read (even if barely) 
   by English speakers. Translation quality is secondary. 
   This is because if you can't read it, I can't get any advice from you.


About Contact Information
 - For translation errors or bugs reports, and other communications, please contact me on Twitter.
   https://twitter.com/fe5_ai

 - I also disseminate information on YouTube.
   https://www.youtube.com/@9ai

