# Patching instructions

1. Find a headerless, unmodified ROM of Genealogy. I obviously cannot help you find such a thing
To check if you've got the right ROM, verify its checksum with a tool like [this one](https://www.romhacking.net/utilities/1002/)

Your ROM should have these values:
**MD5      D044F97BE5FC00BD5E02C935F7E88058**
**CRC32    3691875577**
**SHA-1    90F0BDEAF0151899F96281258FCB30899FBD0D44**

2. Download the program *Floating IPS* (or use your favorite patching program if you already have one).

3. Place your unmodified Genealogy ROM, the Flips program, and the `Lil-Nordion 1.01.bps` patch in the same folder.

4. Flip Flips open.

5. Choose "Apply Patch"

6. Select `Lil-Nordion 1.01.bps`.

7. Select your unmodified ROM.

8. Pick a name for the patched ROM. This will be the one you use to play the Lil' Nordion patch.

Note: After patching, your ROM's checksum should be:
**MD5      4E011879C4F59101CACBB7624F5D64B7**
**CRC32    263855641**
**SHA-1    3F6FF1E07C25A94CB4182901E14B2A5AF10457B1**
These checksums will not be correct if using the Lite version of Lil' Nordion.

NOTE+: Some emulators are not compatible with Lil' Nordion, as the ROM's size was changed. Snes9x et bsnes work fine out of the box, and "ZSNES 8MB custom build" works just as well.

NOTE++: If Lil' Nordion doesn't seem to work on your emulator, try the Lite version, which might be small enough for your picky emulator.
        There is no significant difference between LN and LN Lite. Lite is smaller, but will always show a Wrong Checksum warning.


# FAQ

**Q: What’s the Lite version for?**
A: Certain emulators have trouble with the expanded size of our rom. Lil’ Nordion Lite is a smaller version of Lil’ Nordion that might be more compatible for your emulator. There is no significant difference between the normal patch and the Lite patch. Lite is smaller, but will always show a Wrong Checksum warning.

**Q: Which emulators can I use? What ROM do I need?**
A: You can find the answers to all of these questions in `Patching instructions`.

**Q: Will I lose my save from the previons Lil’ Nordion version / Project Naga / any other version of FE4?**
A: Saves should be compatible between all of these roms.
   First, make sure it's a “hard” save, and not a save state. “Hard save” meaning, the thing you would do before turning off a physical console.
   For most emulators, all you have to do is take your new patched rom, name it the same as the older rom, and place it in the folder where your old rom is, replacing it. This should transfer the saves.

**Q: When patching, I'm getting an error message, saying it’s not for my rom.**
A: The Lil' Nordion patch checks if you are using the correct ROM (Japanese, no header) before patching. You simply need to find the correct ROM if you're getting the error message: “This patch is not intended for this ROM.”
   If you are sure you have an unedited Japanese ROM of FE4, it might have a header, which you can easily remove with a program such as [TUSH](https://www.romhacking.net/utilities/608/).

**Q: Are you sure Jealousy is a glitch? The Internet says it’s a game feature.**
A: [Absolutely](https://forums.serenesforest.net/topic/97354-so-it-turns-out-jealousy-was-a-bug/). Proximity love bonuses are not designed to be given unless two units are right next to each other. The only reason this proximity can be bypassed is because of a coding oversight (a register doesn’t get cleared in the case of a female unit next to another), resulting in a distant unit “stealing” another’s love bonus.
   This behavior was later rationalized by players as a “jealousy feature”, but a quick look at the code doesn’t show that kind of intentionality. If they intended to have “jealousy” playing out, they would have set it up the same way as the rest of the game’s code: with neat little priority tables. Not by hackily swapping two opcodes around.

**Q: Did you get permission from Project Naga?**
A: We’ve done our due diligence. The main translator and coder have disappeared from the internet with indications that they have no interest in communicating. Attempts to reach them for an explicit permission were made in the past few years, to no avail. What little code we have was shared willingly with us before they disappeared, which is the best we are going to get on the coding front.
   Our goal is obviously not to steal or overshadow the Project Naga team in any way, and we’d gladly collaborate or assist them if they were to continue their own project.