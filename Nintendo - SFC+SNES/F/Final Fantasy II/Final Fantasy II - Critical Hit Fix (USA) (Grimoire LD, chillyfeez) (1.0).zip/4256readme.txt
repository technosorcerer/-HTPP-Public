Final Fantasy IV - Critical Hit Bug Fix

by Grimoire LD and chillyfeez

- No ownership is claimed by the two mod authors over Final Fantasy IV, or the franchise from which
  it originates.
- Please credit the authors of this fix if you use it in your mod.
- Apply this patch only to "Final Fantasy II (v1.1) (U) [!].smc", either with or without a header.
- Please keep a backup of your ROM or project in case an error occurs.

There are two patches. Choose one of the following:
1. FFII US Critical Hit Fix - Headered (Fix for a headered ROM of 1,049,088 bytes)
2. FFII US Critical Hit Fix - Unheadered (Fix for an unheadered ROM of 1,048,576 bytes)

------------

In versions of Final Fantasy IV for SNES, there are ways a character can permanently lose their
ability to perform critical hits. Here's Deign's explanation:

"Lose Critical Attack Ability: There are two ways to lose critical attack ability. The first is to
be in the group and be in a position where in the next 'auto-fight' (such as when Tellah fights
Edward or Cecil fights Kain) the character's spot is not taken up by one of the NPC fighters.
Meaning that in the case where Golbez and FuSoYa are fighting against Zemus, if there is a character
on the team that still has crit, he can keep his critical attack by being in the same position as
either one of those characters. Or he would lose it if he was in a different position. However, it
was later also discovered that the characters that aren't in the 'auto-fight' will retain critical
attacks IF and only if the group on the right dies.

The second way to lose critical attack ability is to be dead when a fight starts. In both these
cases there is no way to regain critical strike ability. Not by saving and reseting the game,
powering off, sleeping in an inn, leaving the party, or any other number of ways you could think of.
The ability to critical strike is lost forever if either of these conditions are met."

(source: http://tasvideos.org/2033S.html)

This project fixes the incorrect behavior by:
1. Writing critical hit percentages for characters who aren't participating in auto-battles, instead
   of skipping them like before.
2. Continuing to write critical hit data for teammates who are incapacitated when a battle begins.

Unfortunately, since this data is written to the save file, there's no way for existing saves to
recover lost critical hit ability. Players will have to start a new game in order for the fix to
work.

------------

Proper hashes for base ROMs:

HEADERED - Final Fantasy II (v1.1) (U) [!].smc
CRC-32 - EE345FBD
SHA-1 - C0E02B0F44CCA882C0AEE5C16FF41EDB6B79FA71
MD5 - E27E0ADB7CF09A9497A22AB96445D1B9

UNHEADERED - Final Fantasy II (v1.1) (U) [!].smc
CRC-32 - 23084FCD
SHA-1 - 41A74EB369A7A91815529EF99AB1B20E2BDF3E26
MD-5 - 27D02A4F03E172E029C9B82AC3DB79F7