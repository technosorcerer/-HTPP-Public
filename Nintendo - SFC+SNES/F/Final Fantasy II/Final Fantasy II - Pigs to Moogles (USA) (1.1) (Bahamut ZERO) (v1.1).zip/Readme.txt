A simple graphics hack that changes pigs to moogles in the menu, the overworld, and in battle. Should patch cleanly to any existing project.

Note that this does not change the "Pig" text that's shown when targeting allies with magic in battle. You'll have to change that yourself using FF4kster.
 
patch to unheadered Final Fantasy II (U) (V1.1) rom