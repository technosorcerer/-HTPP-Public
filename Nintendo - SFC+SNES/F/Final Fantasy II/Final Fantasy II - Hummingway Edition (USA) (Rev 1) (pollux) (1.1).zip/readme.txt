FINAL FANTASY IV - HUMMINGWAY EDITION v1.0

This here's a patch for the Namingway Edition (apply that first!!) that swaps out the love interest for a Hummingway boy named "Belloway." He's got a new portrait, new battle graphics, and a slightly tweaked Hummingway overworld sprite. His name is often abbreviated to the chosen name of up to six letters, but will be at times referred to with as "<name>way," as it's intended to be his full name, with the default being a shorthand version. 

The script's fully revised to accommodate for all of the differences here, all of his dialogue that goes beyond him just calling a name has been rewritten. All references to Rosa have similarly been adjusted or rewritten, extra tidbits have been added to clarify his place in the world, as well as where he came from.

INSTALLATION - 

Step 1:
You must first apply the default, v1.9a version of the Namingway Edition patch to a clean v1.1 US ROM of Final Fantasy II. The Project II Title screen variant likely won't work. (https://romhack.ing/database/content/entry/DNNu5JQBNs8FWu0Cr3PW/final-fantasy-iv-namingway-edition) 

Use this information to verify you have the correct ROM before applying the Namingway patch.

Final Fantasy II (USA) (Rev 1)
File/ROM SHA-1: 41A74EB369A7A91815529EF99AB1B20E2BDF3E26
File/ROM CRC32: 23084FCD

Step 2: After verifying a successful install of the Namingway Edition, you can then patch the ROM with the Hummingway Edition. Use this information to verify you have the correct ROM before applying the Hummingway patch.

Final Fantasy IV Namingway Edition (v1.99a)
ROM SHA-1: 778842C53700CF0AC7F2A549069D2C5256A74B02
ROM CRC32: 996A2DF3

UPDATE HISTORY -
1.1: Battle sprite cleanups and pose adjustments, script and formatting adjustments, portrait adjustment. Smoothed out every error and rough edge I could find. It's possible I will need to do some remaining polish, but that should be most of it.
1.0: Release.


CREDITS -
I, Pollux, am responsible for the battle sprites, the script revisions, as well as the sprite version of the portrait.

Cafe, a friend of mine this hack was created for, is responsible for the base portrait art that the in-game version was iterated on.