This is FASTROM for Final Fantasy IV (Japan Rev 0/1, Easy Type) and Final Fantasy II (USA Rev 0/1)

Thank you to the FF4 Ultima discord for the decomp!

Thank you Chillyfeez and Aexoden!

SPECIAL THANKS TO ALL MY PATREONS

A SUPER THANK YOU TO MY TOP SUPPORTER:

Matthew Gambrell

EXTRA SPECIAL THANKS TO TOP PATREONS:

RHZ
Sam M.
mobilevil
June M.
Sunrise Redeemer
Wabbajack

Shoutouts to MiSTerAddons for the hardware!

twitter.com/kandowontu
patreon.com/kandowontu
discord.gg/U4CtzqDGa5