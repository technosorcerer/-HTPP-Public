FFIV: The Lunarian Shuffle's Equipment Scren Modification

This ROM Hack for FF2US improves the equipment screen so that it informs the player of many important things about how the character is changing as the equipment is added.  Changes to statistics, attack, and defense are all shown and highlighted in grey or yellow as they change, while the current state of the character's elemental, racial, status, and some other bonuses are shown as well.

The original purpose of this hack was to make way for randomized equipment for Crow!'s challenge-run-creating randomizer, FFIV: The Lunarian Shuffle.  However, it will likely help a number of other projects, too, so it has been made available as a standalone hack.

The "Other" window shows the character's Long Range, Drain, Magnetic, and Unable to Crit properties.  Some glitches which can be fixed using other hacks affect Long Range and Crit ability.

Check out The Lunarian Shuffle, the project that led to the creation of this mod, here:
https://ff4-lunarianshuffle.blogspot.com/

If you appreciate the work that went into this project, consider donating here:
https://streamlabs.com/iicrowii

If your project uses a different hack which clashes with this one, contact me via Discord (Crow!#4674) and I'll try to find time to straighten things out.

Enjoy,
Crow!


Here's a list of what various icons mean:

  Stats
----------
Gauntlet:	strength
Feather:	agility
Heart:		vitality
Rod:		wisdom
Staff:		will

  Elements
------------
Flame:		fire
Crystal:	ice
Lightning bolt:	lit
White orb:	holy
Dark orb:	dark
Feather:	air

 Status Ailments
-----------------
Axe: 		berserk
Bright stone:	instant stone
Dull stone:	gradual petrification
Heart:		charm
Gravestone:	instant death
Skull:		curse
