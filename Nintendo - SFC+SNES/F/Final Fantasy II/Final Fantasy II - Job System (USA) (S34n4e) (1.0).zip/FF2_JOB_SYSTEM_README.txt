=================================
Final Fantasy II - Job system
=================================

=====
About
=====
It's Final Fantasy II... With a job system!

To change jobs go to 
Menu-> Equip-> Job
To move to cursor to Job you must unequip your RHand, LHand, Head, and Body.
New jobs are acquired by progressing the story.

Do not worry about the lack of rings, remaining equipment has been balanced accordingly.

Changing jobs affects the following:
* Your available equipment
* Your current stats
* Your stat growth on level ups
* Your list of spells
* Your commands in battle
* Your sprite in battle
* Your class description in the menu

Fog bugs, feedback, comments, and suggestions feel free to comment it in the forum or directly with me:
https://www.romhacking.net/forum/index.php?topic=39897.0

Discord servers where you can find me (as "S3"):
Final Fantasy IV Ultima
Final Fantasy IV Free Enterprise

===========
ROM details
===========
Title: FINAL FANTASY 2
Country: USA|NTSC
Version: 1.1
SMC-Header: no
CRC32: 23084FCD

============
Main changes
============
* Only 5 playable characters in total, no guests, everything else was repurposed to make room for the job system
* Each playable character represents a color (purple, blue, green, yellow, and red)
* A total of 14 unique Jobs available (including Jobless)
* Story mode is the same and it won't have a retranslation, some text is altered though
* New equipment and new spells
* Find information about the job system in Baron's Training Room
* Some algorithms were redone
* Some new battle sprites replacing old sprites
* Some field sprites changed
* Stat growth depends on the job equipped when you level up
* Job slot is available only after removing your equipment

================
Changed formulas
================
Some formulas have been modified, find the details below

Example:
(Old) first line = formula in vanilla
(New) second line = new formula

(Old) Accuracy = Weapon's accuracy + (Level / 4)
(New) Accuracy = Weapon's accuracy + (Agility / 4)

(Old) Attack = Weapon's attack + (Strength / 4) + (Level / 4)
(New) Attack = Weapon's attack + (Strength / 4) + (Agility / 4)

(Old) Magic defense = Equipment's magic defense
(New) Magic defense = Equipment's magic defense + (((Wisdom / 2) + (Will)) / 4)

(Old) Attack multiplier = 1 + (Strength / 8) + (Agility / 16)
(New) Attack multiplier = 1 + (Strength / 8) + (Level / 16)

(Old) Magic evasion = Equipment's magic evasion + ((Wisdom + Will) / 8)
(New) Magic evasion = Equipment's magic evasion + ((Level + Will) / 8)

(Old) Magic defense multiplier = (Wisdom + Will) / 32 + (Agility / 32)
(New) Magic defense multiplier = (Wisdom + Will) / 64 + (Level / 64)

(Old) Spell power = (Magic's spell power x 4)
(New) Spell power = (Magic's spell power x 4) + (Level / 2)

(Old) Summon Spell power = (Magic's spell power x 8)
(New) Summon Spell power = (Magic's spell power x 4) + (Will / 2)

(Old) Relative agility formula = (Cecil's Agility x 50) / (My Agility x 10)
(New) Relative agility formula = 750 / (My Agility + 32)

(Old) Critical rate odds = (base critical rate / 98)
(Old) Base critical rate is a fixed value depending on the character. That value is doubled with a weapon equipped, and tripled with bow and arrows.
(New) Critical rate odds = (Agility / 255)

(Old) Critical bonus with 1 weapon = base critical bonus + (Weapon's attack / 2)
(Old) Critical bonus with bow and arrows = critical bonus + Arrow's attack
(Old) Critical bonus with 2 weapons or no weapons = critical bonus
(Old) Base critical bonus is a value between 0 and 60 depending on the character
(New) Critical bonus = 48

=================
Tools and patches
=================
Here's a list of the public tools and patches used:

FF4kster 0.8 (https://www.romhacking.net/utilities/914/)
FF4tweak 1.15 (https://www.romhacking.net/utilities/1654/)
YY_CHR.NET 20210606 (https://www.romhacking.net/utilities/958/)
Final Fantasy IV User Options 3.1 (https://www.romhacking.net/hacks/2232/)
SNES Final Fantasy IV: Add 15 New Spell Slots 1.0 (https://www.romhacking.net/hacks/5043/)
FF4 Long Range Fix (https://www.romhacking.net/hacks/892/)
Remove poison message (https://www.romhacking.net/hacks/7985/)
Final Fantasy II - Battle dialogue speed up (https://www.romhacking.net/hacks/8196/)
ff6tools (https://www.romhacking.net/utilities/1267/)


==============
Wall of Thanks
==============

People that, in a way or another, have helped me create and/or enhance this romhack.

Aexoden
chillyfeez
Crow!
ScytheMarshall


==========
Known bugs
==========

* ?

=========
Changelog
=========

Version 1.0

* 2025/04/05
* First release
* Reworked, added, and removed Jobs from Beta
* Reworked, added, and removed Weapons / Armors
* Changed available items for some shops
* Rebalanced, added, and removed some spells
* "Erase" spell also removes float, slow, and fast effects
* Some maps changed from Beta
* Surprise and back attacks are less punishing
* Training Room now has NPCs with dialogue related to the Job system
* Rebalanced some monsters
* Encounter rate decreased for most maps
* Now you can only change your Job after removing your equipment
* Some new field sprites
* Fixed vanilla sylph bug
* Fixed vanilla in-battle dupe weapon/shield bug


Beta

* 2025/02/16
* Beta release for playtesting and feedback

=====
?????
=====
