---------------- F-ZERO BEGINNINGS ----------------

                                      by Alejandro
-----------------------INDEX-----------------------

1. How to
2. What is FZB?
3. Story
4. Why Turbo Snails?
5. Car Physics
6. Known Issues
7. The Future of This Project
8. Credits

1. HOW TO-----------------------------------------

Get Lunar IPS or FLIPS.
Apply the "F-Zero Beginnings 0.1" patch to a US
headerless F-Zero ROM (if you happen to have the
wrong version, try a dump with CRC32:AA0E31DE).
Back up your F-Zero ROM, just in case.

2. What is FZB?-----------------------------------

F-Zero Beginnings is your good old F-Zero game,
except this is supposed to be... A prequel!
This ROM hack is more difficult than the original
game, so prepare to endure a lot of crashing out.

3. Story------------------------------------------

Before the iconic main 4 (Captain Falcon, Dr.
Stewart, Pico and Samurai Goroh) joined the
Grand Prix (aka "The Story of Captain Falcon")
There was a very few selection of cars.
These cars were nothing more than Turbo Snails.
Every racer had no choice but to pick one.
The competition was tougher, as these cars were
a lot harder to pilot unlike the cars of our
protagonists of The Story of Captain Falcon.
And thus, these events defined what F-Zero came
to be, and now it's time for you to know what it
feels like to drive one of these cars.

F-Zero Beginnings takes place before the events
of "The Story of Captain Falcon", which, as
stated in the manual's "What is F-ZERO?" section,
F-Zero happened not only once, but a lot of times
before the main cast joined the Grand Prix.

4. Why Turbo Snails?------------------------------

Turbo Snails are those previously unnamed cars
that appear as CPUs during Grand Prix.
The F-Zero community gave them the name of
"Turbo Snail" after a poll was made in which
fans had to choose from a selection of names,
and Turbo Snail won (See "Turbo snails sea
species" for reference).

5. Car Physics------------------------------------

Turbo Snails are inferior to the main cars in
most ways, such as worse acceleration, turning,
power, and even S-Jet power! It will last half
the original time. Yes, Turbo Snails are THAT bad.
However, CPU speeds were adjusted to match Turbo
Snails' custom stats to make it less difficult.

Here is a summary of Turbo Snails' physics:

Purple Turbo Snail: The way-to-go car for
beginners. It is the most stable car out of the
cast. With its overall good acceleration and
turn speed, pilots will be able to overtake their
rivals easily. Its resistance toward CPU crashes
makes up for its low top speed. You wouldn't want
to drive on electric damage areas for a long time
though, as this car is very weak to that type of
damage source.

Green Turbo Snail: This car is suited for more
experienced players. It has terrible acceleration
and resistance toward CPU crashes, as well as not
so good turning speed. It's also quite slippery.
Despite this, it has the best top speed and
acceleration speed past 400 km/h out of all cars,
as well as quite slow deceleration rate when not
on gas. Pilots should know that in order to
control this car as intended, a lot of dodging and
braking is not to be ignored. Practice mode is
highly recommended to pilot this car the first
time you get around to it.

Brown Turbo Snail: This is the most popular one,
probably. With its slow acceleration tied with
its low top speed, this is certainly not the best
to choose from. This is one of the weakest cars
out of the cast, and honestly, there is not much
to say about it, just give it a try or two.

Explosive Turbo Snail: Identical to Brown Turbo
Snail, except it has slightly less top speed and
it explodes upon contact with any damage source.
What could you expect? If you fancy a challenge,
try beating all courses in Practice mode in a row
without exploding.

6. Known Issues-----------------------------------

a. Purple and Brown Turbo Snails have some "random
pixels" at the sides when sharp turning. Brown
also has some random pixels on the strafing
animation. This is due to the vanilla game having
these same random pixels which aren't as
noticeable as here, since Blue Falcon and Golden
Fox are slightly bigger.

b. Explosive Snail not flashing. Since the flash
animation is a special case, it would be needed
more than I know to make it flash like the CPU
cars. Unfortunately, Explosive Snail will just
appear pink for this version.

c. "POWER DOWN" alert repeatedly displaying when
taking damage at low power levels, and
disappearing entirely throrough the whole game
after exploding as Explosive Snail until the
game is resetted.

d. Fire Field is impossible to beat in Master
with Green Turbo Snail, as its acceleration is
so poor, and the AI is way too fast in corners.

e. White Land II's jump is insanely hard to pull
off with Brown and Explosive Turbo Snails. This
is the downside of these cars, as they are so
bad they can't even make the jump in vanilla.
However while difficult, it is entirely possible
to build enough speed (about 325km/h) if you take
the turns correctly.
This issue is only present in the first lap of
White Land II, as you will have access to S-Jets
for the next laps.

f. Brown and Explosive Turbo Snails cannot beat
Expert/Master classes. I think this is pretty
much self explanatory. They are so bad, cars
overlap them all the time in the original game,
just stick with Beginner/Standard for these.

g. Title screen and Master ending demos not
playing properly. Since car stats were modified,
the pre-made inputs no longer match the new
stats so Turbo Snails will just end up crashing.
This however will not lead to worrysome glitches
such as data loss or game corruption.

h. Turbo Snail names not showing and wrong
acceleration curves at the car selection screen.
The car selection screen has a format in which
there is little to no freedom of editing car
names, so I just left them blank for this
version. Acceleration curves are a similar
deal.

i. Thrusters don't match Turbo Snails' pipes.
Setting them properly is a lot of work so I
decided to release this version with Fire
Stingray's pipe thruster offsets.

All of these issues are taken into consideration
for the next release(s), except issue f of course.

7. The Future of This Project---------------------

Since this is supposed to be a prequel, courses
should be easier. As implied in the manual: In the
past courses were easier, as time had passed, new
hazards were constructed.
Every course will be modified in a way to make
an easier variant of that course. And since it
will be possible to have 15+ courses in a single
ROM, F-Zero Beginnings would eventually be
compounded of 30 courses (the easy variants and
the original courses).
Furthermore, there will be a "Past" and a
"Present" version of the Knight, Queen and King
leagues.
Additionally this means that the White Land II
jump will be shorter in the past (easy) variant,
so Brown and Explosive Turbo Snails will then be
able to make the jump easier.

8. Credits----------------------------------------

Thanks to Porthor & MKDSmaster91 for being beta
testers and Catador for helping me on which bytes
to change, including the Explosive Snail's
feature and all practice unlocked.
Thanks for making this possible.

Are you still reading? Well, I will tell you
something... The credits screen has been edited
too ;) (beat any league in Expert class).