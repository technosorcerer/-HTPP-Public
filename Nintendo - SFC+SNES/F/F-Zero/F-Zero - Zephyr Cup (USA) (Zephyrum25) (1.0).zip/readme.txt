F-Zero: Zephyr Cup - v1.0

Overview
==============================================================

F-Zero: Zephyr Cup is a 1-league hack that gradually goes from
vanilla difficulty, to BSGP and beyond, it's inspired by a mix
of SNES and GBA track design (with some extra stuff on top).

Courses
==============================================================

The following courses are introduced in this order:

Port Town: Breeze Circuit
Big Blue: Cold Horizon
Metal Fort: Aerial Fortress
Fire Field: Chain Burn
Silence: Zephyr Strike

Credits
==============================================================

-Creator-
Zephyrum25

-Playtesters & QA-
PowerPanda
MKDSmaster91
TheDarkConfiguration

-Special Thanks-
PowerPanda (for getting me into the F-Zero modding community)
Goldmouse (for inspiring me to follow my dreams)
erik64 (for motivating me to make it)
Catador & grego2d (Creators of FZEdit)