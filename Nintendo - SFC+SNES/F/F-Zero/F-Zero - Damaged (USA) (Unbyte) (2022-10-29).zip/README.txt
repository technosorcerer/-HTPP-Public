F-Zero Damaged
Corruption Romhack by Unbyte

Features:
- The game will corrupt itself when you take damage
- Lots of random fun and high replayability
- Works perfectly on console

Use Lunar IPS to apply the Patch