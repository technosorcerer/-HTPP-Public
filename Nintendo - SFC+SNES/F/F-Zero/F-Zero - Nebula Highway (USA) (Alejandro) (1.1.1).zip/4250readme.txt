F-Zero Nebula Highway (Beta) by Alejandro.

Index:

1. Version Log
2. Description
3. Difficulty
4. Changes
5. Updates
6. Credits

1. Version Log

-v0.1 (11/30/2018)
The first version of F-Zero Nebula Highway.

-v0.1.1 (12/07/2018)
Added "Player falling off" animation on Practice mode.

2. Description

F-Zero Nebula Highway is a ROM hack of F-Zero for the Super Nintendo, it features
all new 15 courses to race in, most of them are challenging, but even beginners
can play the game on Beginner or even Standard classes.

3. Difficulty

The game is itself challenging, on the beggining it will look pretty though to
play on the hardest class avaliable at the start (Expert), you should start with
lower classes instead. Every league can be completed with every vehicle on the
hardest class. If you practice enough, you will get the hang of the courses, each
course has tricky and useful spots to use your S jet (Boost), get to know all the
courses and find out which places are the best to get in front of the race.

4. Changes

The following changes have been applied since v0.1:
-Many palettes have been changed.
-Vehicles (CPU and player) sprites improved.
-Barriers and road will flash when a CPU hits walls and barrier tiles.
-Explosive CPU is no longer invisible and will not play the engine sound after
exploding.
-Miscellaneous sprites improved.
-City horizon (Mute City and White Land) has been improved.
-Silence's pillars have been improved.
-Port Town horizon has been edited to fix some palette inconsistencies, added a
forest at the horizon as well, also improved most far background sprites.
-Sand Ocean tornados will now have sand palettes.
-CPU sprites positions have been improved depending on your position (Vehicles in
front of you will change sprite sizes depending on perspective more accurately).
-Customized "Player falling off course" animation, (In the original game it is
only shown in Mute City I, II, III and Port Town I, II) The animation will show
when you fall on a background tile.
-Credit screen has been edited.
-Most of courses' horizon gradient have been changed to fit the courses' ambiance.

5. Updates

The hack will receive updates, Along with new courses and features, there are some
known bugs and glitches that are present in this hack, however, it is intended to
fix them when the hacking tools are developed and improved enough.

Known bugs and glitches:

-Master class ending (Wait a while and you will be sent to the records menu).
-Shortcuts (Shortcut penalty isn't implemented yet).

6. Credits

Thanks to Catador for helping me implementing wall and barrier flashing and
explosive CPU fixes.