---------------- F-ZERO BEGINNINGS ----------------

                                      by Alejandro
-----------------------INDEX-----------------------

1. Version Log
2. How to
3. What is FZB?
4. Story
5. Why Turbo Snails?
6. Car Physics
7. Known Issues
8. Credits


1. Version Log-------------------------------------

-v1.0.1 (10/08/2025)
 -Fixed Legacy White Land II checkpoints
  triggering the "Reverse" message in the U turns
  section.

-v1.0 (10/04/2025)
 -General changes:
  -Updated title screen.
  -Player sprites' random pixels fixed.
  -Original game's track names/Leagues changed to
   have the prefix "Classic".
  -Legacy Leagues added.
  -BS F-Zero and BS F-Zero 2 content added.
  -BS F-Zero and BS F-Zero 2 Legacy Leagues added.
  -Soundlink versions of Big Blue II, Sand Storm II
   and Silence II introduced in Week Leagues. This
   avoids the creation of BS F-Zero exclusive
   content (BS Knight/BS Queen/BS King/BS Ace),
   skipping the redundance of using existing
   tracks from the original Knight/Queen/King.
  -Modified AI path in Sand Ocean, Port Town I/II
   and Fire Field to address Brown/Green Turbo
   Snail handicaps.
  -Modified AI path in Sand Storm I/II to address
   Brown/Green Turbo Snail handicaps.

 -Car balance:
  -Purple Snail:
   -Deceleration on released gas increased.
   -Front/back car stun rate on Player increased.
  -Green Snail:
   -Front/back car stun rate on Player decreased.
   -Wall damage decreased.
  -Brown Snail:
   -Front/back car stun rate on CPUs increased.
   -Airborne speed gain increased.
   -Smoother turning curve.
   -Required speed to strafe decreased.
  -Explosive Snail:
   -Airborne speed gain increased.
   -Smoother turning curve.
   -Required speed to strafe decreased.

 -Miscellaneous:
  -CPUs now trigger Dash Zones, regarding of
   Player's camera angle.
  -Player now starts with 7 spare lives.
  -Improved car distance sprite rendering.


-v0.1 beta (11/24/2021)
 -Updated title screen.
 -Updated car selection screen.
 -Added Purple, Green and Explosive Turbo Snails.
 -Player sprites/offsets updated.
 -CPU sprites updated to reflect Turbo Snails.
 -Brown Turbo Snail slot moved to Golden Fox.
 -Brown Turbo Snail stats modified.

-v0.4 alpha (09/18/2020)
-The first release of F-Zero Beginnings.


2. HOW TO-----------------------------------------

Get Beat (BPS Patcher).
Apply the "F-Zero Beginnings 1.0" patch to a US
headerless F-Zero ROM (if you happen to have the
wrong version, try a dump with CRC32:AA0E31DE).
Back up your F-Zero ROM, just in case.


3. What is FZB?-----------------------------------

F-Zero Beginnings is your good old F-Zero game,
except this one is.. A prequel!
This ROM hack features the previously-unplayable
Turbo Snails, as well as brand new versions of
all tracks labeled "Legacy". These Legacy tracks
are easier versions of the original tracks
(labeled "Classic" in this ROM hack).
This ROM hack is more difficult than the original
game, so prepare to endure a lot of crashing out.


4. Story------------------------------------------

Before the iconic main 4 (Captain Falcon, Dr.
Stewart, Pico and Samurai Goroh) joined the
Grand Prix (aka "The Story of Captain Falcon"),
there was a very few selection of cars.
These cars were nothing more than Turbo Snails.
Every racer had no choice but to pick one.
The competition was tougher, as these cars are
harder to pilot unlike the cars of our
protagonists of The Story of Captain Falcon.

Because of the structure of the Turbo Snails, 
the courses were planned to account for their
performance: Tracks of less complexity.
Around the time the iconic crew joined the Grand
Prix, the courses went under modifications, such
as layout changes and getting new hazards (as
mentioned in the F-Zero game manual).
And thus, these events defined what F-Zero came
to be as how we know it today.

F-Zero Beginnings' Legacy Leagues take place
before the events of "The Story of Captain
Falcon", which, as stated in the manual's
"What is F-ZERO?" section, F-Zero had been
presented for quite some time, before the main
cast stepped in and impressed everyone with their
beloved cars.

5. Why Turbo Snails?------------------------------

The F-Zero community gave them the name of
"Turbo Snail" after a poll was made in which
fans had to choose from a selection of names,
and Turbo Snail was chosen (based on the Turbo
Snail, a sea snail species with similar traits).


6. Car Physics------------------------------------

Turbo Snails are inferior to the main cars in
most ways, such as worse acceleration, turning,
power, and even S-Jet power! It will last half
the original time. Yes, Turbo Snails are THAT bad.
However, CPU speeds were adjusted to match Turbo
Snails' custom stats to make the game fair.


Here is a summary of Turbo Snails' physics:


PURPLE TURBO SNAIL: The way-to-go car for
beginners. It is the most stable car of the whole
cast. With its overall good acceleration and
turn speed, pilots will be able to overtake their
rivals easily. It is not without disadvantages,
as you wouldn't want to drive on electric damage
areas for long periods, as this car is very weak
to that type of damage source. It also loses lots
of speed when not on gas, and you may want to
avoid CPUs as well.


GREEN TURBO SNAIL: This car is suited for more
experienced players. It has terrible acceleration,
as well as not-so-good turning speed. It's also
quite slippery.
Despite this, it has the best top speed, best
resistance toward CPU crashes (though still loses
a lot of speed), and also best acceleration speed
past 400 km/h out of all cars, as well as quite
slow deceleration rate when not on gas. Pilots
should know that in order to control this car as
intended, a lot of dodging and braking is not to
be ignored. Practice mode is highly recommended
when you decide to pilot this car first time.


BROWN TURBO SNAIL: This is the most popular one,
probably. With its slow acceleration tied with
its low top speed, this is certainly not the best
to choose from. Avoid damage sources and CPUs
as much as possible. This is one of the weakest
cars out of the cast, and honestly, there is not
much to say about it, just give it a try or two.


EXPLOSIVE TURBO SNAIL: Identical to Brown Turbo
Snail, except it has slightly less top speed and
it explodes upon contact with any damage source.
What could you expect? If you fancy a challenge,
try beating all the Legacy Leagues on Beginner
Class without touching anything harmful!


7. Known Issues-----------------------------------

a. Turbo Snail names not showing and wrong
acceleration curves at the car selection screen.

The car selection screen has a format in which
there is little to no freedom of editing car
names, so I just left them blank for this
version. Acceleration curves are a similar
deal.


b. Missing Records/Credits.

Current version of FZEdit is unable to display
these features for the time being.


c. Explosive Turbo Snail not flashing.

Since the flash animation is a special case, it
would be needed more than I know to make it flash
like the CPU cars. Unfortunately, it is out of my
knowledge.


d. "POWER DOWN" alert.

It repeatedly displays when taking damage at low
power levels, and disappearing entirely throrough
the whole game after exploding as Explosive Snail
until the game is resetted.


e. Mute City II's wrong Power bar color.

FZEdit currently exports the wrong value.


f. White Land II/Forest III's jump is impossible
to pull off with Explosive Turbo Snail.

Naturally, CPU versions can't make the jumps.
Legacy versions can be cleared by the Explosive
Turbo Snail.


g. Brown and Explosive Turbo Snails cannot beat
Expert/Master classes.

I think this is pretty much self explanatory.
They are so bad, cars overlap them all the time
in the original game.
One of the reasons why the Legacy Leagues were
made is for these cars to have a chance.

All Classic and Legacy Leagues can be beaten by
Brown Turbo Snail up to Standard Class.
Explosive Turbo Snail is able to clear all
Legacy Leagues in Beginner Class.


h. Title screen demo not playing properly.

Since car stats were modified, the pre-made
inputs no longer match the new stats so Turbo
Snail will just end up crashing. This however
will not lead to worrysome glitches such as data
loss or game corruption.


i. Thrusters don't match Turbo Snails' pipes.

Setting them properly is a lot of work so I
decided to release this version with Fire
Stingray's pipe thruster offsets.


These issues may hopefully be controlled in
future versions.


8. Credits---------------------------------------

Thanks to Porthor & MKDSmaster91 for being beta
testers and Catador for helping me on the technical
side of things.
Thanks for making this possible.

Also thank YOU for playing! Your support keeps me
motivated to create more stuff.