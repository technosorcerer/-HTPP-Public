F-Ing Stupid

by FangTheHellcat


This is my first ever hack of F-Zero and in general. The hack doesnt contain any modified tracks but instead modified machines.

The Machines
------------------------

Slick Bird (Blue Falcon)

This machine is a slip n sliding maniac. Not to worry though, a simple tap of the accelerator regardless of your current speed will bring it back on track.

Shining Slingstar (Golden Fox)

A machine that stops and starts on a dime. Using the brake is key for turns so you dont stop dead halfway through a corner.

Glass Goose (Wild Goose)

A machine that drives well, and can bully other machines! just...mind the rails and hazards those are deadly..

Blazing Slug (Fire Stingray)

A very slow starter but once it gets moving its almost the same old machine you know and love!
