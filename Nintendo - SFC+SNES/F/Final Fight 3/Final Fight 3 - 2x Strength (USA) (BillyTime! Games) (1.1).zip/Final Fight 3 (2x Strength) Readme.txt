Final Fight 3 (2x Strength)
Jan. 8th 2025
BillyTime! Games
--------------------
This is a simple patch designed for Final Fight 3 that doubles the amount of damage inflicted on enemies.

How to Patch:
--------------------
1.Grab a copy of Final Fight 3 (USA).sfc (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file