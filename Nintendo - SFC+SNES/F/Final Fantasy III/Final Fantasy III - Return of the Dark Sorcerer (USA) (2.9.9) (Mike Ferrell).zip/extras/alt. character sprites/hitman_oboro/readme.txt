This patch changes Oboro's sprite and portrait to a version reminiscent of Hitman (bald with a suit).

Credit: James White (made the sprite and portrait)