This patch changes Ronan's sprite and portrait to another version: Master Ronan!
Basically he resembles more a Kung Fu master, which is pretty awesome.

Credit: James White (made the sprite and portrait)