This patch changes the Pig Status sprite and portrait to that of an awfully cute quadrupedal piglet!

Credit: James White (made the sprite and portrait)