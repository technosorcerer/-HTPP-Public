This patch changes Eiko's sprite and portrait to a different more FFX Summoner look.

Credit: James White (made the sprite and portrait)