This patch changes General Leo's sprite and portrait to that akin of a full-blown T-800 Terminator!

Credit: James White (made the sprite and portrait)