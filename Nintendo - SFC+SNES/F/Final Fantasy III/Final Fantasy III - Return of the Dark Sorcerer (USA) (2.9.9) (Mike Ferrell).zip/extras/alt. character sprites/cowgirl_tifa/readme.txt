This patch changes Tifa's sprite and portrait to her western cowgirl attire from her younger days in FF7.

Credit: James White (made the sprite and portrait)