This patch changes Mog's sprite and portrait to another version: Dancer Mog!
This will of course change every other Moogle sprite in the game as well, because they all share the same sprite ID. All the playable moogles' portraits have been updated to match as well.

Credit: James White (made the sprite and portrait)