This patch changes Shadow the Heartless's sprite and portrait to a bigger, evolved form of sorts, called a Defender, which is also from the Kingdom Hearts universe.

Credit: James White (made the sprite and portrait)