This patch changes Eiko's sprite and portrait to that of a Japanaese "shrine maiden", called a Miko.

Credit: ScarabEnigma (made the sprite and portrait)