This patch changes Serin's sprite and portrait to that fitting of a true king!

Credit: James White (made the sprite and portrait)