This patch changes Clouds's sprite and portrait to that of his Crisis Core attire.

Credit: James White (made the sprite and portrait)