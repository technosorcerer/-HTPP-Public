This patch changes both the physical damage given (Fight) and received while in the back row from 50% less to 25%, which makes things both a bit easier and harder at the same time. This will also unintentionally nerf the effects of 'same damage from back row' weapons, and the Reverse Polarity monster spell.

Credit to assassin for the original code.