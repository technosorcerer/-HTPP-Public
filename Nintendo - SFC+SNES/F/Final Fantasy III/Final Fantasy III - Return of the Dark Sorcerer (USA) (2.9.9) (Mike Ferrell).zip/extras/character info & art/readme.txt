Much of the info as well as some of the character art (Ronan & Serin) is now incorrect and/or dated since the release of v2.0. It's possible that we'll make updates to the actual art pages in the future, but until then you can see the latest updated character info on the RotDS site, see here: https://www.ff6hacking.com/forums/thread-4279-post-41719.html

Artwork by James White