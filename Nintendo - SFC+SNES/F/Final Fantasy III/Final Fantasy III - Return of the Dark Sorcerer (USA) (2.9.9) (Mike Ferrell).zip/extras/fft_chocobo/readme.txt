This patch changes the classic vanilla FF6 chocobo into the Final Fantasy Tactics variant. (courtesy of FFRK)
This includes it's overworld sprite, mode 7 sprites. (riding and dismounting)

Created by: Supah Sayin Rick / SSJ Rick