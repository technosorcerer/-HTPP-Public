Removes the dialog outside of battles, unless it's something that requires a choice. Perfect for K@N races!
Credit to Sir Newton Fig for making the patch.

There is currently two small issues with this patch when used for RotDS:
1) One particular dialog box will still show up during the extended intro, which I'd imagine those who use this patch would be skipping anyway, which is why I didn't bother to remove the dialog box from the event code.
2) The Coral chests in Ebot's Rock won't say how much Coral you received, which can be problematic, but then again not all that bad.

These two issues are more than likely tied together and might get fixed in a future update. Again, this is only an issue for RotDS, the patch itself is normally 100% working as intended.

There was a version of the patch that also removed the battle event dialog, but I chose to not go that far because sometimes it will explain what to do in that battle or w/e.