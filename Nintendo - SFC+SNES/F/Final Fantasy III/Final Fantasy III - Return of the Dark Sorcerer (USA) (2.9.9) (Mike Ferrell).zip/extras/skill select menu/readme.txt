This patch changes both Limit Break (Sword Tech) and Combo (Blitz) to instead be selected from a menu, like Dance.
Combo is renamed to Chi.

Credit:
LightPhoenix for the original "FF6 Selectable Blitz/SwdTech" patch.
Feanor for porting it.