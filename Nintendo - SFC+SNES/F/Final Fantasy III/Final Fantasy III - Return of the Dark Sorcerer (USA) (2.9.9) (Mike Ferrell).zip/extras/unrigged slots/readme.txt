This patch, made by Master ZED a million years ago, will unrig the slots that are rigged against you.

Credit: Master ZED

The Slot Reel Layout edit makes the unrigged slots much more forgiving by coupling the same symbols.

Credit: Synchysi