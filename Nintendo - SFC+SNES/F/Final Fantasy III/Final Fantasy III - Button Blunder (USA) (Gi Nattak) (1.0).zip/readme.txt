Button Blunder v1.0

Bug:
At the end of the game, during the scene with Gogo where he (or possibly she) is informed that "both buttons have to be pressed simultaneously", the buttons/switches on the map are miscolored beyond recognition. I believe this to be a mistake because changing them from palette $0D to their respective palette of $0C makes them look nice and correct, like the only other switch of this kind in the game that is inside the Magitek Research Facility.

Offset:
CA/1B13: 60    Change background layer $0E to palette $0D (changed to palette $0C)

Gi Nattak