Title: Pugs Rage
Author: SilentEnigma
Version: 1.2
Release Date: 2021-12-31
Applies to: Final Fantasy III (v1.0) (U)

Archive Contents
-------------------------------

  PugsRage_H.ips               = basic patch for headered ROMs
  PugsRage_NH.ips              = basic patch for unheadered ROMs

  PugsRage-AZ_H.ips            = compatible w/ RagAZ (headered)
  PugsRage-AZ_NH.ips           = compatible w/ RagAZ (unheadered)

  PugsRage-AZ-Check_H.ips      = w/ RagAZ+Checklist (headered)
  PugsRage-AZ-Check_NH.ips     = w/ RagAZ+Checklist (unheadered)

  PugsRage-AZ-Check-Des_H.ips  = w/ RagAZ+Checklist+Descriptions (headered)
  PugsRage-AZ-Check-Des_NH.ips = w/ RagAZ+Checklist+Descriptions (unheadered)

  PugsRage-AZ-Des_H.ips        = w/ RagAZ+Descriptions (headered)
  PugsRage-AZ-Des_NH.ips       = w/ RagAZ+Descriptions (unheadered)

  PugsRage-Check_H.ips         = w/ Checklist (headered)
  PugsRage-Check_NH.ips        = w/ Checklist (unheadered)

  PugsRage-Check-Des_H.ips     = w/ Checklist+Descriptions (headered)
  PugsRage-Check-Des_NH.ips    = w/ Checklist+Descriptions (unheadered)

  PugsRage-Des_H.ips           = w/ Descriptions (headered)
  PugsRage-Des_NH.ips          = w/ Descriptions (unheadered)

  readme.txt = this file


ROM Addresses
-------------------------------

PugsRage (basic):       C1/4CF4 - C1/4D07, C1/662D - C1/6630, C1/8531 - C1/8535,
                        C2/05DA - C2/060F, C2/4DF6 - C2/4DF7, C2/585F - C2/5863,
                        C3/53D3 - C3/53E0, C3/542B - C3/5432

PugsRage-AZ:            C1/4CF4 - C1/4D07, C1/662D - C1/6630, C1/8531 - C1/8535,
                        C2/05DA - C2/060F, C2/4DF6 - C2/4DF7, C2/585F - C2/5863,
                        C3/53DE - C3/53DF, C3/542B - C3/5434

PugsRage-AZ-Check:      C1/4CF4 - C1/4D07, C1/662D - C1/6630, C1/8531 - C1/8535,
                        C2/05DA - C2/060F, C2/4DF6 - C2/4DF7, C2/585F - C2/5863,
                        C3/5451

PugsRage-AZ-Check-Des:  C1/4CF4 - C1/4D07, C1/662D - C1/6630, C1/8531 - C1/8535,
                        C2/05DA - C2/060F, C2/4DF6 - C2/4DF7, C2/585F - C2/5863,
                        C3/5451

PugsRage-AZ-Des:        C1/4CF4 - C1/4D07, C1/662D - C1/6630, C1/8531 - C1/8535,
                        C2/05DA - C2/060F, C2/4DF6 - C2/4DF7, C2/585F - C2/5863,
                        C3/53DE - C3/53DF, C3/542B - C3/5434

PugsRage-Check:         C1/4CF4 - C1/4D07, C1/662D - C1/6630, C1/8531 - C1/8535,
                        C2/05DA - C2/060F, C2/4DF6 - C2/4DF7, C2/585F - C2/5863,
                        C3/5451

PugsRage-Check-Des:     C1/4CF4 - C1/4D07, C1/662D - C1/6630, C1/8531 - C1/8535,
                        C2/05DA - C2/060F, C2/4DF6 - C2/4DF7, C2/585F - C2/5863,
                        C3/5451

PugsRage-Des:           C1/4CF4 - C1/4D07, C1/662D - C1/6630, C1/8531 - C1/8535,
                        C2/05DA - C2/060F, C2/4DF6 - C2/4DF7, C2/585F - C2/5863,
                        C3/53D3 - C3/53E0, C3/542B - C3/5432

Free space (re)used
-------------------------------

PugsRage (basic):       C2/A691 - C2/A6A7                     (23 bytes)

PugsRage_AZ:            C2/A691 - C2/A6A7, C2/FB7E - C2/FBCF  (105 bytes)

PugsRage_AZ-Check:      C2/A691 - C2/A6A7, C2/FB7E - C2/FBCF  (105 bytes)

PugsRage_AZ-Check-Des:  C2/A691 - C2/A6A7, C2/FB7E - C2/FBCF,
                        C3/FD59 - C3/FD72                     (131 bytes)

PugsRage_AZ-Des:        C2/A691 - C2/A6A7, C2/FB7E - C2/FBCF,
                        C3/FD59 - C3/FD69                     (122 bytes)

PugsRage_Check:         C2/A691 - C2/A6A7                     (23 bytes)

PugsRage_Check-Des:     C2/A691 - C2/A6A7, C3/FD4B - C3/FD6D  (58 bytes)

PugsRage_Des:           C2/A691 - C2/A6A7, C3/FD4B - C3/FD63  (48 bytes)


TABLE OF CONTENTS
-------------------------------
0. Description
1. Installation
2. Relevant Offsets & Disassembly
3. Credits
4. Revision History
5. Legal

________________________________________________________________________________

  0. DESCRIPTION
________________________________________________________________________________


Short Story
-------------------------------
This is a hack for FF3us (SNES) which enables the Pugs rage, normally
inaccessible, to be listed in the field menu and selected in battle.


Long Story
-------------------------------
In FF3us there are 256 Rage abilities in code, four of which are inaccessible:
Allo Ver, Chupon, Siegfried, and Pugs.

The situation with Pugs is perhaps the most complex of the four. The enemy Pugs
can be encountered normally on the Veldt, making the Pugs rage learnable.
However, Pugs occupies the final rage slot (255 = 0xFF) which conflicts with the
NULL I.D. in the game's 8-bit menu system. So the Pugs rage becomes tragically
hidden and not selectable from any menu.

In 2016, Novalia Spirit released the "Rage Checklist" patch which included an
option for displaying Pugs in the field menu. Soon after, Assassin published a
draft implementation for displaying Pugs in the field menu when combining "Rage
Checklist" with his "Alphabetical Rage" patch:
https://web.archive.org/https://slickproductions.org/forum/index.php?topic=2245.60

The Pugs rage has otherwise remained elusive, unusable in battle, mostly due to
the NULL I.D. problem being even more of a pain to solve for the battle menu.

This patch works around the limitation in both the field menu and battle menu
for multiple patching scenarios, while (hopefully) averting some pitfalls along
the way. With the patch applied, it becomes possible to view the Pugs rage in
the field menu list and select it in battle.


Compatibility Note
-------------------------------
The patch assumes that Gau always has at least one rage learned. While this is
the case with the original FF3us, where Gau begins with several rages available,
it may not apply to some large-scale hacks of FF3us.

________________________________________________________________________________

  1. INSTALLATION
________________________________________________________________________________


1. Apply any of the following patches as desired, in order:

  a. Alphabetical Rage [Beta v0.45]    (Assassin)
     http://assassin17.brinkster.net/patches.htm#anchor3

  b. Rage Checklist    [v1.0]          (Novalia Spirit)
     https://www.ff6hacking.com/wiki/doku.php?id=ff3:ff3us:patches:novalia

  c. Rage Descriptions [Megapack v1.0] (SilentEnigma)
     https://silentenigma.neocities.org/ff6/index.html#DescriptionExpansions

2. If you applied both "Alphabetical Rage" and "Rage Checklist", apply
   "Alphabetical Rage Checklist Addendum" (SilentEnigma).
   https://silentenigma.neocities.org/ff6/index.html#AZRageChecklistAddendum

3. Apply the appropriate (headered/unheadered, compatible) "Pugs Rage" patch:

 - If your ROM contains "Alphabetical Rage":

    > If your ROM contains neither "Rage Checklist" nor "Rage Descriptions",
      use "PugsRage-AZ".

    > If your ROM contains "Rage Checklist" but not "Rage Descriptions",
      use "PugsRage-AZ-Check".

    > If your ROM contains both "Rage Checklist" and "Rage Descriptions",
      use "PugsRage-AZ-Check-Des".

    > If your ROM contains "Rage Descriptions" but not "Rage Checklist",
      use "PugsRage-AZ-Des".

 - If your ROM does NOT contain "Alphabetical Rage":

    > If your ROM contains neither "Rage Checklist" nor "Rage Descriptions",
      use "PugsRage" (basic). [This applies to fresh FF3us ROMs]

    > If your ROM contains "Rage Checklist" but not "Rage Descriptions",
      use "PugsRage-Check".

    > If your ROM contains both "Rage Checklist" and "Rage Descriptions",
      use "PugsRage-Check-Des".

    > If your ROM contains "Rage Descriptions" but not "Rage Checklist",
      use "PugsRage-Des".

4. Apply the compatible "Un-Raged" patch (SilentEnigma), if desired.

5. If your ROM uses custom sorting with Assassin's "Alphabetical Rage" patch,
   you will need to regenerate the sorted ID block (C2/FAD0 - C2/FBCF) manually.

________________________________________________________________________________

  2. RELEVANT OFFSETS & DISASSEMBLY
________________________________________________________________________________

a. Common
b. All AZ
c. All Not AZ
d. All Checklist
e. Basic/Descriptions Only (No AZ/Checklist)
f. Descriptions Only (No AZ/Checklist)
g. AZ/AZ+Descriptions Only (No Checklist)
h. AZ+Descriptions Only (No Checklist)
i. Descriptions+Checklist Only (No AZ)
j. AZ+Descriptions+Checklist

==================================================
 a. COMMON
==================================================

Patch(es) Affected:
 PugsRage (basic)
 PugsRage-AZ
 PugsRage-AZ-Check
 PugsRage-AZ-Check-Des
 PugsRage-AZ-Des
 PugsRage-Check
 PugsRage-Check-Des
 PugsRage-Des

-------------------------------

Selecting rage if muddled/berserk & selecting rage ability

Original:
 C2/05D1: DA          PHX
 C2/05D2: 08          PHP
 C2/05D3: 7B          TDC
 C2/05D4: 99 A9 33    STA $33A9,Y   ; high byte, #$FF if uninitialized
 C2/05D7: B9 A8 33    LDA $33A8,Y   ; which monster it is
 C2/05DA: C9 FF       CMP #$FF
 C2/05DC: D0 22       BNE $0600     ; branch if a non-null monster was passed
 C2/05DE: 1A          INC
 C2/05DF: 99 A8 33    STA $33A8,Y   ; store enemy #0, Guard
 C2/05E2: AD 9A 3A    LDA $3A9A     ; # of rages possessed
 C2/05E5: 20 65 4B    JSR $4B65
 C2/05E8: 1A          INC           ; random #: 1 to $3A9A
 C2/05E9: 85 EE       STA $EE
 C2/05EB: A2 00       LDX #$00
 C2/05ED: BD 7E 25    LDA $257E,X   ; Rage menu; was filled in C2/580C routine
 C2/05F0: C9 FF       CMP #$FF
 C2/05F2: F0 0C       BEQ $0600     ; branch if that menu slot was null
 C2/05F4: C6 EE       DEC $EE       ; decrement our random index
 C2/05F6: F0 05       BEQ $05FD     ; if 0, branch, & use menu item last read
 C2/05F8: E8          INX
 C2/05F9: D0 F2       BNE $05ED     ; loop again to check next menu entry
 C2/05FB: 80 03       BRA $0600     ; if looped 256x w/ no match, use enemy #0
 C2/05FD: 99 A8 33    STA $33A8,Y   ; store enemy number
 C2/0600: 20 53 4B    JSR $4B53     ; random: 0 or 1 in Carry flag
 C2/0603: C2 30       REP #$30
 C2/0605: 2A          ROL
 C2/0606: AA          TAX           ; X: rage ID + (0 or 1)
 C2/0607: E2 20       SEP #$20      ; Set 8-bit Accumulator
 C2/0609: BF 00 46 CF LDA $CF4600,X ; load Rage move
 C2/060D: 28          PLP
 C2/060E: FA          PLX
 C2/060F: 60          RTS
Modified:
 C2/05D1: DA          PHX           ; new alt entry for rage by muddle/berserk
 C2/05D2: 08          PHP
 C2/05D3: B9 A9 33    LDA $33A9,Y   ; high byte, #$FF if uninitialized
 C2/05D6: 1A          INC
 C2/05D7: D0 17       BNE $05F0     ; branch if a non-null monster was passed
 C2/05D9: 99 A9 33    STA $33A9,Y   ; high byte, will now be #$00
 C2/05DC: AD 9A 3A    LDA $3A9A     ; # of rages possessed
 C2/05DF: F0 05       BEQ $05E6     ; branch to 0 - 255 rand
 C2/05E1: 20 65 4B    JSR $4B65     ; random #: 0 to $3A9A (max: 255) - 1
 C2/05E4: 80 03       BRA $05E9
 C2/05E6: 20 5A 4B    JSR $4B5A     ; random #: 0 to 255
 C2/05E9: AA          TAX
 C2/05EA: BD 7E 25    LDA $257E,X   ; Rage menu, was filled in C2/580C routine
 C2/05ED: 99 A8 33    STA $33A8,Y   ; store enemy number
 C2/05F0: B9 A8 33    LDA $33A8,Y   ; which monster it is
 C2/05F3: 20 53 4B    JSR $4B53     ; random: 0 or 1 in Carry flag
 C2/05F6: C2 30       REP #$30
 C2/05F8: 2A          ROL
 C2/05F9: AA          TAX           ; X: rage ID + (0 or 1)
 C2/05FA: E2 20       SEP #$20      ; Set 8-bit Accumulator
 C2/05FC: BF 00 46 CF LDA $CF4600,X ; load Rage move
 C2/0600: 28          PLP
 C2/0601: FA          PLX
 C2/0602: 60          RTS

New Subroutine C2/0603:
; Set rage high byte as inititialized and branch to selecting rage ability
 C2/0603: 7B          TDC           ; PLX affects the same status bits N & Z
 C2/0604: 99 A9 33    STA $33A9,Y   ; high byte, #$FF if rage is uninitialized
 C2/0607: 80 C8       BRA $05D1

New Subroutine C2/0609:
 C2/0609: 22 91 A6 C2 JSL $C2A691   ; New Subroutine C2/A691
 C2/060D: 85 2C       STA $2C       ; original C1/662D
 C2/060F: 6B          RTL

; Upon confirming a rage from the menu
Original:
 C2/4DF5: 20 D1 05    JSR $05D1     ; Picks the rage ability
Modified:
 C2/4DF5: 20 03 06    JSR $0603     ; New subroutine C2/0603

-------------------------------

Mimicking rage

Original:
 C2/1560: B9 A8 33    LDA $33A8,Y   ; get monster #
 C2/1563: 1A          INC
 C2/1564: D0 13       BNE $1579     ; branch if it's already defined
Modified:
 C2/1560: B9 A9 33    LDA $33A9,Y   ; high byte, #$FF if uninitialized

-------------------------------

Displaying the menu:

Original:
 C1/4CF4: B9 7E 25    LDA $257E,Y   ; List of known rages, even (left)
 C1/4CF7: 8D 5A 57    STA $575A
 C1/4CFA: B9 7F 25    LDA $257F,Y   ; List of known rages, odd (right)
 C1/4CFD: 8D 60 57    STA $5760
 C1/4D00: 20 07 4E    JSR $4E07
 C1/4D03: 20 AB 63    JSR $63AB
 C1/4D06: 7A          PLY
 C1/4D07: 60          RTS
Modified:
 C1/4CF4: 98          TYA
 C1/4CF5: 8D 5A 57    STA $575A
 C1/4CF8: 1A          INC
 C1/4CF9: 8D 60 57    STA $5760
 C1/4DFC: 20 07 4E    JSR $4E07
 C1/4DFF: 20 AB 63    JSR $63AB
 C1/4D02: 7A          PLY
 C1/4D03: 60          RTS
 C1/4D04: FF FF FF FF

Original:
 C1/662D: 85 2C       STA $2C
 C1/662F: C9 FF       CMP #$FF
Modified:
 C1/662D: 22 09 06 C2 JSL $C20609   ; New Subroutine C2/0609

Original:
 C1/8531: BD 7E 25    LDA $257E,X   ; X holds the rage ID
 C1/8534: C9 FF       CMP #$FF
Modified:
 C1/8531: 8A          TXA
 C1/8532: 22 91 A6 C2 JSL $C2A691   ; New Subroutine C2/A691

-------------------------------

Check rage list entry for validity (assumes at least one valid entry)

New Subroutine C2/A691:
 C2/A691: E2 10       SEP #$10      ; 8-bit X & Y registers
 C2/A693: DA          PHX
 C2/A694: AA          TAX
 C2/A695: 48          PHA
 C2/A696: AD 9A 3A    LDA $3A9A     ; number of known rages
 C2/A699: 3A          DEA           ; highest valid list index
 C2/A69A: C3 01       CMP $01,s     ; the pushed index
 C2/A69C: 68          PLA
 C2/A69D: BD 7E 25    LDA $257E,X   ; rage ID
 C2/A6A0: FA          PLX
 C2/A6A1: C2 12       REP #$12      ; reset zero flag ("valid"), 16-bit X & Y
 C2/A6A3: B0 02       BCS $A6A7     ; branch if index is valid
 C2/A6A5: E2 02       SEP #$02      ; reset zero status flag = "invalid"
 C2/A6A7: 6B          RTL

==================================================
 b. ALL AZ
==================================================

Patch(es) Affected:
 PugsRage-AZ
 PugsRage-AZ-Check
 PugsRage-AZ-Check-Des
 PugsRage-AZ-Des

-------------------------------

Alphabetical Rage:
 C2/5856: EE 9A 3A    INC $3A9A     ; number of known rages
 C2/5859: 8F 80 21 00 STA $002180
 C2/585D: FA          PLX
 C2/585E: E8          INX
 C2/585F: E0 FF       CPX #$FF
 C2/5861: D0 E3       BNE $5846
 C2/5863: 60          RTS
Modified:
 C2/585F: D0 E5       BNE $5846
 C2/5861: 60
 C2/5862: FF FF

-------------------------------

Insert pugs (0xFF) into alphabetized list:

Alphabetical Rage:
 C2/FAD0: EF EB 5E D6 BB 85 B4 3A 0C 6E EC 5D 59 DE BE 1D
 C2/FAE0: 29 20 D5 63 35 D3 4F F2 79 51 26 4A 0B 84 58 E8
 C2/FAF0: 4C 96 C6 E2 A0 3D 1F 7C 40 86 9A B3 11 C7 67 2F
 C2/FB00: 5B 62 AB 4B 92 09 D7 0D 60 28 A7 30 F9 70 1A 25
 C2/FB10: 83 8B D9 B2 A5 A6 B7 39 91 1C 57 47 EA 23 DF CB
 C2/FB20: 99 66 5A 98 AE 31 8A 88 6D F5 A8 AA E0 00 53 89
 C2/FB30: 2B 4E 08 9F C1 2C B5 3E 2E 49 48 F6 D0 A3 FE 6C
 C2/FB40: FD 6B ED DC CD 9B B9 17 45 E5 3C 19 CA 8E 42 61
 C2/FB50: 6A 06 AF E7 F3 55 97 EE D2 64 21 8C A4 56 DB CE
 C2/FB60: 38 A9 F1 33 03 C3 68 C8 05 E6 10 BD 90 0F AC B1
 C2/FB70: BF 72 BC 41 9D C0 A2 C9 6F 94 D4 DA 22 54 DD 0A
 C2/FB80: 7B 3B 78 F8 4D 07 15 75 76 12 7E 3F CF 04 5F 5C
 C2/FB90: E1 C5 A1 E9 73 37 43 FC 95 52 74 B8 01 AD C2 B6
 C2/FBA0: B0 E3 87 7F 16 50 BA 18 1E F0 44 02 9C 8F 9E 2D
 C2/FBB0: 32 36 F7 65 34 7A 27 93 14 46 E4 80 71 D1 FB CC
 C2/FBC0: 1B 2A 69 7D 8D 13 0E 24 77 F4 D8 C4 FA 81 82[FF]
Modified:
 C2/FAD0: EF EB 5E D6 BB 85 B4 3A 0C 6E EC 5D 59 DE BE 1D
 C2/FAE0: 29 20 D5 63 35 D3 4F F2 79 51 26 4A 0B 84 58 E8
 C2/FAF0: 4C 96 C6 E2 A0 3D 1F 7C 40 86 9A B3 11 C7 67 2F
 C2/FB00: 5B 62 AB 4B 92 09 D7 0D 60 28 A7 30 F9 70 1A 25
 C2/FB10: 83 8B D9 B2 A5 A6 B7 39 91 1C 57 47 EA 23 DF CB
 C2/FB20: 99 66 5A 98 AE 31 8A 88 6D F5 A8 AA E0 00 53 89
 C2/FB30: 2B 4E 08 9F C1 2C B5 3E 2E 49 48 F6 D0 A3 FE 6C
 C2/FB40: FD 6B ED DC CD 9B B9 17 45 E5 3C 19 CA 8E 42 61
 C2/FB50: 6A 06 AF E7 F3 55 97 EE D2 64 21 8C A4 56 DB CE
 C2/FB60: 38 A9 F1 33 03 C3 68 C8 05 E6 10 BD 90 0F AC B1
 C2/FB70: BF 72 BC 41 9D C0 A2 C9 6F 94 D4 DA 22 54[FF]DD
 C2/FB80: 0A 7B 3B 78 F8 4D 07 15 75 76 12 7E 3F CF 04 5F
 C2/FB90: 5C E1 C5 A1 E9 73 37 43 FC 95 52 74 B8 01 AD C2
 C2/FBA0: B6 B0 E3 87 7F 16 50 BA 18 1E F0 44 02 9C 8F 9E
 C2/FBB0: 2D 32 36 F7 65 34 7A 27 93 14 46 E4 80 71 D1 FB
 C2/FBC0: CC 1B 2A 69 7D 8D 13 0E 24 77 F4 D8 C4 FA 81 82

==================================================
 c. ALL NOT AZ
==================================================

Patch(es) Affected:
 PugsRage (basic)
 PugsRage-Check
 PugsRage-Check-Des
 PugsRage-Des

-------------------------------

Original:
 C2/585F: C9 FF        CMP #$FF
 C2/5861: D0 E4        BNE $5847    ; loop for all eligible enemies, 0 to 254
 C2/5863: 60           RTS
Modified:
 C2/585F: D0 E6        BNE $5847    ; loop for all eligible enemies, 0 to 255.
 C2/5861: 60           RTS
 C2/5862: FF FF

==================================================
 d. ALL CHECKLIST
==================================================

Patch(es) Affected:
 PugsRage-AZ-Check
 PugsRage-AZ-Check-Des
 PugsRage-Check
 PugsRage-Check-Des

-------------------------------

Rage Checklist:
 C3/5451: FF     ; forbid Pugs
Modified:
 C3/5451: 00     ; allow Pugs

==================================================
 e. BASIC/DESCRIPTIONS ONLY (No AZ/Checklist)
==================================================

Patches Affected:
 PugsRage (basic)
 PugsRage-Des

-------------------------------

Setting up the list:

Original:
 C3/53D3: 90 07       BCC $53DC
 C3/53D5: A5 E0       LDA $E0
 C3/53D7: 8D 80 21    STA $2180
 C3/53DA: 80 05       BRA $53E1
 C3/53DC: A9 FF       LDA #$FF      ; #$FF == blank
 C3/53DE: 8D 80 21    STA $2180
Modified:
 C3/53D3: A5 E0       LDA $E0
 C3/53D5: 90 05       BCC $53DC
 C3/53D7: 8D 80 21    STA $2180
 C3/53DA: 80 05       BRA $53E1
 C3/53DC: 3A          DEA           ; make unexepected ID => now indicates null
 C3/53DD: EA          NOP
 C3/53DE: 8D 80 21    STA $2180

-------------------------------

Displaying list items

Original:
 C3/542B: BF 89 9D 7E LDA $7E9D89,X
 C3/542F: C9 FF       CMP #$FF
 C3/5431: F0 08       BEQ $543B
Modified:
 C3/542B: 8A          TXA
 C3/542C: DF 89 9D 7E CMP $7E9D89,X
 C3/5430: EA          NOP
 C3/5431: D0 08       BNE $543B

==================================================
 f. DESCRIPTIONS ONLY (no AZ/Checklist)
==================================================

Patch(es) Affected:
 PugsRage-Des

-------------------------------

Rage Descriptions (basic):
 C3/FD4B: 4C AD 28    JMP $28AD
 C3/FD4E: FF FF
 C3/FD50: FF FF FF FF
 C3/FD54: FF FF FF FF
 C3/FD58: FF FF FF FF
 C3/FD5C: FF FF FF FF
 C3/FD60: FF FF FF FF
Modified:
 C3/FD4B: A2 C9 9E    LDX #$9EC9    ; original C3/572A
 C3/FD4E: 8E 81 21    STX $2181     ; original C3/572D
 C3/FD51: 7B          TDC           ; original C3/5730
 C3/FD52: A5 4B       LDA $4B       ; original C3/5731
 C3/FD54: AA          TAX           ; original C3/5733
 C3/FD55: DF 89 9D 7E CMP $7E9D89,X ; check for expected value
 C3/FD59: F0 03       BEQ $FD5E
 C3/FD5B: 4C 6D 57    JSR $576D     ; unexpected -> load blanks
 C3/FD5E: 20 3C 57    JSR $573C
 C3/FD61: 4C B0 28    JMP $28B0     ; $28AD (Rage Descriptions) + 3

==================================================
 g. AZ/AZ+DESCRIPTIONS ONLY (No Checklist)
==================================================

Patch(es) Affected:
 PugsRage-AZ
 PugsRage-AZ-Des

-------------------------------

Alphabetical Rage:
 C3/53DE: A9 FF       LDA #$FF
Modified:
 C3/53DE: 98          TYA           ; get current rage
 C3/53DF: 3A          DEA           ; make unexpected ID => now indicates null

-------------------------------

Displaying list items

Alphabetical Rage:
 C3/542B: BF 89 9D 7E LDA $7E9D89,X
 C3/542F: C9 FF       CMP #$FF
 C3/5431: F0 08       BEQ $543B
 C3/5433: EA          NOP
 C3/5434: EA          NOP
Modified:
 C3/542B: BF 89 9D 7E LDA $7E9D89,X
 C3/542F: DF D0 FA C2 CMP $C2FAD0,X ; check for expected ID; unexpected => null
 C3/5433: D0 06       BNE $543B

==================================================
 h. AZ+DESCRIPTIONS ONLY (No Checklist)
==================================================

Patch(es) Affected:
 PugsRage-AZ-Des

-------------------------------

Rage Descriptions (AZ):
 C3/FD59: 20 33 57    JSR $5733     ; new alt entry for subroutine C3/572A
 C3/FD5C: 4C B0 28    JMP $28B0
 C3/FD5F: FF
 C3/FD60: FF FF FF FF
 C3/FD64: FF FF FF FF
 C3/FD68: FF FF
Modified:
 C3/FD59: DF 89 9D 7E CMP $7E9D89,X ; check for expected value
 C3/FD5D: D0 05       BNE $FE44
 C3/FD5F: 20 3C 57    JSR $573C
 C3/FD62: 80 03       BRA $FE47
 C3/FD64: 20 6D 57    JSR $576D     ; unexpected -> load blanks
 C3/FD67: 4C B0 28    JMP $28B0     ; $28AD (Rage Descriptions) + 3

==================================================
 i. DESCRIPTIONS+CHECKLIST ONLY (No AZ)
==================================================

Patch(es) Affected:
 PugsRage-Check-Des

-------------------------------

Rage Descriptions (basic):
 C3/FD4B: 4C AD 28    JMP $28AD
 C3/FD4E: FF FF
 C3/FD50: FF FF FF FF
 C3/FD54: FF FF FF FF
 C3/FD58: FF FF FF FF
 C3/FD5C: FF FF FF FF
 C3/FD60: FF FF FF FF
 C3/FD64: FF FF FF FF
 C3/FD68: FF FF FF FF
 C3/FD6C: FF FF
Modified:
 C3/FD4B: A2 C9 9E    LDX #$9EC9    ; original C3/572A
 C3/FD4E: 8E 81 21    STX $2181     ; original C3/572D
 C3/FD51: 7B          TDC           ; original C3/5730
 C3/FD52: A5 4B       LDA $4B       ; original C3/5731
 C3/FD54: AA          TAX           ; original C3/5733
 C3/FD55: BF 89 9D 7E LDA $7E9D89,X ; learned rages
 C3/FD59: C9 FF       CMP #$FF      ; null?
 C3/FD5B: F0 0B       BEQ $FE48     ; skip to blanks
 C3/FD5D: E0 FF 00    CPX #$00FF    ; pugs?
 C3/FD60: D0 01       BNE $FE43     ; skip pugs translation #$00 -> #$FF
 C3/FD62: 3A          DEA           ; restore pugs #$FF ID
 C3/FD63: 20 3C 57    JSR $573C
 C3/FD66: 80 03       BRA $FE5B
 C3/FD68: 20 6D 57    JSR $576D     ; unexpected -> load blanks
 C3/FD6B: 4C B0 28    JMP $28B0     ; $28AD (Rage Descriptions) + 3

==================================================
 j. AZ+DESCRIPTIONS+CHECKLIST
==================================================

Patch(es) Affected:
 PugsRage-AZ-Check-Des

-------------------------------

Rage Descriptions (AZ):
 C3/FD59: 20 33 57    JSR $5733     ; new alt entry for subroutine C3/572A
 C3/FD5C: 4C B0 28    JMP $28B0
 C3/FD5F: FF
 C3/FD60: FF FF FF FF
 C3/FD64: FF FF FF FF
 C3/FD68: FF FF FF FF
 C3/FD6C: FF FF FF FF
 C3/FD70: FF FF FF
Modified:
 C3/FD59: AA          TAX
 C3/FD5A: BF 89 9D 7E LDA $7E9D89,X ; learned rages
 C3/FD5E: C9 FF       CMP #$FF      ; null?
 C3/FD60: F0 0B       BEQ $FE4D     ; skip to blanks
 C3/FD62: E0 FF 00    CPX #$00FF    ; pugs?
 C3/FD65: D0 01       BNE $FE48     ; skip pugs translation #$00 -> #$FF
 C3/FD67: 3A          DEA           ; restore pugs #$FF ID
 C3/FD68: 20 3C 57    JSR $573C
 C3/FD6B: 80 03       BRA $FE50
 C3/FD6D: 20 6D 57    JSR $576D     ; unexpected -> load blanks
 C3/FD70: 4C B0 28    JMP $28B0     ; $28AD (Rage Descriptions) + 3

________________________________________________________________________________

  3. CREDITS
________________________________________________________________________________


Thanks to:

  Assassin, for the "Alphabetical Rage" patch, Rage menu commentary,
   optimizations
  http://assassin17.brinkster.net/patches.htm#anchor3
  http://slickproductions.org/forum/index.php?topic=2245.60

  Novalia Spirit, for the "Rage Checklist" patch
  https://www.ff6hacking.com/wiki/doku.php?id=ff3:ff3us:patches:novalia

  Assassin & Terii Senshi, for the disassembly of bank C2
  http://assassin17.brinkster.net/guides.htm

  Imzogelmo, for the disassembly of bank C1 & C3
  http://www.angelfire.com/al2/imzogelmo/patches.html

________________________________________________________________________________

  4. REVISION HISTORY
________________________________________________________________________________


2021-12-05 : Version 1.0 released

2021-12-20 : Version 1.1 released
 - Fixed erroneous rage assignment for mimicked rages
 - Thanks Assassin for pointing towards the bug

2021-12-31 : Version 1.2 released
 - Optimizations; uses 17+ fewer bytes of free space (thanks Assassin)
 - Fixed benign branching bug in the "AZ" variants

________________________________________________________________________________

  5. LEGAL
________________________________________________________________________________


Copyright (C) 2021 David R. Thompson (SilentEnigma).

The copyright holder ("author") permits the free use of the attributed work
referenced by this document exclusively for non-commercial purposes, provided
that the following conditions are met:
1. The author and all contributors credited in this readme document shall be
 given credit for their respective contributions wherever the attributed work is
 reused, redistributed, or modified.
2. This readme document shall accompany any of the files comprising the
 attributed work wherever they are redistributed in unmodified form.

The work(s) and file(s) distributed with this document are provided "AS-IS",
WITHOUT ANY WARRANTY. The author shall not be held responsible for any damages
related to the use of work(s) and file(s) distributed with this document.
