|----------------------------------------------|
| Mastered Esper Icon Hack                     |
| by: madsiur                                  |
| version: 1.3                                 |
| Released on: May 2nd, 2025                   |
| apply to: FF3us 1.0 (no header)              |
|----------------------------------------------|

|----------------------------------------------|
| Files                                        |
|----------------------------------------------|

mastered-nh.ips: IPS patch for vanilla ROM (user's color icon)
mastered-yellow-nh.ips: IPS patch for vanilla ROM (yellow icon)
asm/: folder containing the bass assembly files of the two hacks
asm/star.bin: 8x8 2BPP star icon used for the hack

|----------------------------------------------|
| Description                                  |
|----------------------------------------------|

This hack adds a star icon to each mastered Esper
in the Esper menu. An Esper is mastered when all 
its spells are learned. There's a version of the 
hack that draws a yellow star instead of the 
user's color (white by default). This yellow option
was made possible with bits of BNW and BC randomizer
code (thanks to Myria and Ryo_Hazukiyo). You can
specify a different icon and disable star icon
insertion in any of the assembly files.

The default hack uses 130 bytes of free space while
the yellow option uses 190 bytes of free space at
$EEAF01. This free space offsets can be changed in
the bass asm file by changing the offset of the 
"seek($EEAF01)" macro call. The hacks use no free
space in bank $C3.

To assemble the hack use bass v14 by typing a command
such as "bass -o rom.smc mastered.asm".

|----------------------------------------------|
| Links                                        |
|----------------------------------------------|

bass v14:
https://romhack.ing/database/content/entry/BdNw5JQBNs8FWu0CSZB5/bass
https://www.romhacking.net/utilities/794/

|----------------------------------------------|
| Version history                              |
|----------------------------------------------|

Version 1.3 (2025/05/02):
-Fixed a bug with yellow star hack where the star
 icon would lose its color when navigating the
 menu in a certain way (redit to Ryo_Hazukiyo)
-Optimized yellow palette setting code

Version 1.2 (2024/06/29):
-Replaced blue star option with the yellow one
-Removed RAN patches

Version 1.1 (2022/03/27):
-Fixed a bug with the icon when scrolling with L/R

Version 1.0 (2022/02/22):
-Initial release

|----------------------------------------------|
| Download pages                               |
|----------------------------------------------|

Personal website:
https://rewindcoding.dev/en/romhacking/hacks/mastered-esper/

FF6Hacking wiki:
https://www.ff6hacking.com/wiki/doku.php?id=ff3:ff3us:patches:madsiur:mastered

Romhack.ing entry:
https://romhack.ing/database/content/entry/LNNu5JQBNs8FWu0CaVw8/mastered-esper-icon

