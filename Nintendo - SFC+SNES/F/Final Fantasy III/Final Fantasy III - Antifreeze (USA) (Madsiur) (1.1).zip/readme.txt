|----------------------------------------------|
| Antifreeze Hack                              |
| by: madsiur, C-Dude                          |
| version: 1.1                                 |
| released on: June 29th, 2024                 |
| apply to: FF3us 1.0 (no header)              |
|----------------------------------------------|

|----------------------------------------------|
| 1- Files                                     |
|----------------------------------------------|

antifreeze-C2-nh.ips: Patch for monsters and characters that use free space in bank $C2
antifreeze-EX-nh.ips: Patch for monsters and characters that use free space in bank $EE
antifreeze-character-C2-nh.ips: Patch for characters only that use free space in bank $C2
antifreeze-character-EX-nh.ips: Patch for characters only that use free space in bank $EE
antifreeze-monster-C2-nh.ips: Patch for monsters only that use free space in bank $C2
antifreeze-monster-EX-nh.ips: Patch for monsters only that use free space in bank $EE
/asm: Folder containing the bass assembly file of each hack

|----------------------------------------------|
| 2- Description                               |
|----------------------------------------------|

This hack repurposes the unused "repel Magitek" item flag in FF3usME
to make it repel the Freeze status instead ($D85006 bit 3 in the
item data). It also repurposes the "block Magitek" flag in the monster
data for the same purpose ($CF0014 bit 3). Although you can't set
Freeze on a monster in the original game, that option could be useful
for a spell or a rage that set Freeze.

The bank $C2 hack uses free space at $C26480 and the EX hack uses some
at $EEAF01. At most, antifreeze-XX-nh will use 59 bytes of free
space and the character or monster only hacks use about half that amount.
Those free space offsets can be changed in a ASM file by changing the
offset of the "seek" macro call.

To assemble the hack use bass v14 by typing a command such as
"bass -o rom.smc antifreeze-C2.asm".

|----------------------------------------------|
| 3- Version history                           |
|----------------------------------------------|

06/29/2024: Version 1.1 - Fixed a bug with magitek mode (thanks C-Dude!)
02/12/2022: Version 1.0 - Initial release

|----------------------------------------------|
| 3- Download locations                        |
|----------------------------------------------|

Personal website:
https://www.fred65816.net/en/romhacking/hacks/antifreeze

FF6Hacking wiki:
https://www.ff6hacking.com/wiki/doku.php?id=ff3:ff3us:patches:madsiur:antifreeze

RHDN page:
https://www.romhacking.net/hacks/6518/


