Return of the Dark Sorcerer v2.9.8     By Gi Nattak, 2024

===============================
HOW TO PLAY THE HACK
===============================

- Use 7-Zip to unpack the file.
- Included are patches for both headered (h) and headerless (nh) ROMs. If you don't know if your ROM is headered or not, you can use a user-friendly utility like SNEStuff to add or remove the header, then apply the appropriate patch. 
- Correct ROM to patch to: Final Fantasy III (U)(V1.0) ... NOT V1.1.
- Make sure your ROM is 100% clean, meaning there has been no previous modifications.
- Do not patch over a previous RotDS version.
- Feel free to use either 'soundtrack a' or 'soundtrack b' patches, by default the game starts with 'soundtrack a', so no need to use that patch unless you wish to revert back from 'soundtrack b'.
- There are additional patches that can be used in the 'extras' folder.
- The game should run on any of the current popular emulators, I recommend the latest versions of snes9x or bsnes that support ExHiROM. I highly recommend not using ZSNES; it's outdated, inaccurate, and the audio is poorly emulated.
If you're intent on using ZSNES, you'll need to use a custom build that supports ExHiROM, found at FuSoYa's Niche called 'ZSNES 8MB Custom Build'.
- Any of the included patches when used will in turn make the checksum read as 'bad', but it doesn't effect anything at all so no worries.
- Upon starting a new game (or a new game +) you will be asked to choose a difficulty. By default, the game is meant to be played on 'Regular' difficulty, which is basically a not-so-large step up from the original game in terms of overall difficulty. The following difficulties are of course more challenging; monsters and bosses have higher stats and HP, as well as AI changes for bosses sometimes. You will receive more EXP and gil for each subsequently harder difficulty. 'Insane' difficulty is recommended for New Game + (once you beat the game).
- Check out the 'classroom.txt' document located inside 'infos.zip' to learn more about the mod's changes & features.

Important!
If you are having a freezing issue in battle it's because you used the wrong patch for your ROM, for instance you may have patched a headerless ROM with the patch intended for a headered ROM, or visa-versa.

Attempting to use any save data besides RotDS save data will most assuredly cause some sort of terrible issue.
If you use ZSNES and any sort of bug happens, please don't bother reporting it to me.

**DANGER** THOSE WHO ARE PRONE TO SEIZURES MAY WISH TO KNOW THAT SOME PARTS OF THE GAME HAVE CONTINUOUS FLASHING WHICH MAY INDUCE SEIZURES OR UNDESIRED EFFECTS ON PEOPLE WHO ARE SENSITIVE TO THESE TYPES OF DISPLAY!! A PATCH IS PROVIDED IN THE 'EXTRAS FOLDER' THAT WILL ELIMINATE THE FEW MAJOR FLASHING INSTANCES.

===============================
ABOUT THE MOD
===============================

Return of the Dark Sorcerer is an incredibly large fan-made Final Fantasy 6 modification that's been in development since around 2010. Originally the brainchild of Gi Nattak, the project has evolved over the years thanks to a dedicated team and other skilled members of the FF6 romhacking community.

This mod promises to showcase some of the challenging aspects of FF6 romhacking, as well as plenty of fun and exciting new content; from an all new cast of playable characters with customized movesets, a radically changed story with many new and edited events, new overworld maps, a new musical soundtrack, difficulty selection, new battle scripts for monsters & bosses, and an absolute ton of custom monster/esper and NPC sprites.

It is a highly personalized modification of the original game and therefore naturally won't appeal to everyone. It's not a sequel, or a prequel, or a remake to FF6, it is quite simply a massive amalgamation mod and customization of FF6 which does contain a whole bunch of references and can be rather nonsensical or even immersion-breaking at times... but if you go into it prepared for this, you should have a much more enjoyable experience. That being said, a whole lot of time and energy has gone into this project and we are quite pleased with the result.

===============================
EXTERNAL PATCHES USED
===============================

- FF6 Improvement Patch - darkmage and all the corresponding patch creators - please check here: https://www.ff6hacking.com/misc/dark_mage_improvement_project_readme.txt
- Natural Ability Extension, Stat Increase Items - GrayShadows
- Guest Adder, Learnable Rage, Step Dance, Antimagic Field, Resilient Morph, Even Gauge, SwdTech Ready Stance, Reward Display, Wilder Randomness, Runic Forever function - HatZen
- FF6 Names Clean-up Patch - Angelo
- Physical Damage Overflow Fix - Drakkhen
- 255 hours - Leviathan Mist
- New Game Plus - Master Zed
- Natural Stat Growth - Lenophis
- Fanaticism - Ronnen
- Hand Cursor in dialogue choices - Bregalad
- New RNG - Lenophis
- Randomosity monster encounter fix, critical strikes won't carry over to spells - assassin
- Save Point Glitch Fix, Stone Zombie Bug fix, Zombie/Tapir Bug fix, Ultimate Damage Fix, Backwards Jump fix, Game Over Glitch fix, Backstabu, Item Magic Counter, No X In Fight, Double Block, Reflections, Imp's Call, Vanish Runic, Side Saddle, Magitek Madness, Status Unknown, Precious Jewels, Throwback, Anonymous Attack, False Knight, Upside Down, Off Death Row, Blitz Screen, Stepping Out, Lens Cap, Bird Bars, Unequipium, Trigger Happy, Solar Wind, Smoke and Mirrors, Color Wheel (made possible for RotDS thanks to Seibaby) - 13375K31C43R
- Don't Reapply Status, nATB basic patch (in extras folder) - Think0028
- Elemental Mixing Lite - Bropedio (original patch by Think0028)
- Free Moving Terra - Madsiur
- Color-coded MP Digits - Imzogelmo
- FF6j Relic indicators, selective re-equip, Allergic Dog Fix - Novalia Spirit
- Smart Cover, Disable Near Fatal being reapplied if dead, Independent Stop, Muddle Cancel, Quake removes Clear status even when missing Floating targets fix, No Scan counters - seibaby
- Extended character palette - Eggers
- Stuck in a Pose fix, Description Disruption, Docile NPCs, MPDigits-Decoupled, Optional Continue, Soft Reset, Status Icon Overflow - SilentEnigma
- No Sale - C-Dude
- Call Skill - C-Dude and PowerPanda, based on code by assassin and M06
- Imp's Map - C-Dude and Serity
- First Strike - Edea
- Slim Boxes - Gens (idea) & Ryo_Hazuki (hacking)
- X-Magic Summon - Feanor

===============================
CREDITS
===============================

Assembly code work:

Madsiur - Offering hits 2-4 times tweak, equip Magicite command, class titles, guest characters on overworld chocobo fix, banon health animation bug fix, status check event command, level check event command, instrument expansion, WoB Airship 2nd music, Havoc Sword WoR tweak, Warp check, a music pointer change for the final battle, WoR Veldt song, WoR fanfare switch, Item command removal code, Stamina health boost on level up, difficulty selection, expanding map-related data via a custom level editor build, music player (derived from the Pandora's Box team's code), no gradient in menu option, 2x damage to dragon weapon effect, portraits for all character IDs, reverting Cloud's properties and equipment back, guest character AI targeting command, Debilitator tweak, block Frozen status equipment flag, random stat boost per level hooked up with level averaging, expanding monster editor, getting Atlas script up and running, item-type names for the expanded item icons, status timers hack, Mastered Espers, Skean-fix, Golbez special properties.

Synchysi - Spell doing half damage from back row flag, always sprint tweak, gain level event command, Health to Miracle, dual weapon wielder fix in the equip screen, Pep Up alteration, MP-costing critical hit weapons scale MP cost by character level, Limited Esper patch.

Edrin - Characters change palettes in the WoR check, unlearn spell command.

Angelo - Restored ability names, grant character spell command, flashback color in battle.

GrayShadows - Made Golbez (used to be Gogo) act like a normal character in regards to Magic learning/Espers, spell learn rate showing up on weapons, Runic affects only monster spell casts.

HatZen - Equipment Spells, big help with the new WoR Veldt song & Item command removal in battle codes.

abw - created a utility for hacking the intro credits.

dn - Rage & Dance descriptions.

Lufia - Step Mine uses steps instead of time for MP cost, hold B to walk optional patch, swap Steal/Throw function.

C-Dude - Removal of Runic and Retort after KO'd status, FFV-styled Meteo, getting palette 6 characters to show up correctly in the save, shop and party select menus. Relics don't remove statuses out of battle. Fixed the Morph and the Gem Box extra step forward bug.

Gi Nattak - MP Cost - The Lost 3rd digit, Mog Never Fails, Equipable Umaro.

===============================
SPRITEWORK
===============================

James White (a.k.a. phunbaba) - All the portraits, all custom monster and esper sprites, new WoB overworld map tiles, all the new location map objects, a bunch of NPC sprites (please see below for which ones).

SSJ Rick - Most of the main characters and NPCs.

Dr. Blank - Original portrait work before they all got redone.

Lijj - Original Aurora portrait, and some help with the Onion Knight character sprite.

ScarabEnigma - Completed a couple Record Keeper sprite sheets, custom Crusher overworld sprite to replace Guardian, updated/new Zemus static sprite, updated/new Aurora sprites as of v2.9, Young Aurora.

Gi Nattak - Eiko's tent, yin-yang bed map object, Bridge Correction patch.

===============================
EVENT
===============================

Angelo -  Much event work.

Gi Nattak - Much event work.

Madsiur - Shadow in Albrook/Vector.

Lockirby - Namingway.

===============================
BATTLE GRAPHICS
===============================

SSJ Rick - All the custom weapons and a couple spell animations.

XolarDark - Some spell animations.

James White - Soul Caliber summon.

Tsushiy/t-edition - Summon intro animation graphics, Runic sword graphic edit with blue glow.

Lightning - gave the Scythe weapon a handle.

===============================
MAP WORK
===============================

Lockirby - Both the new WoB and WoR maps.

Gi Nattak - The mini-maps for the new overworlds.

Sir Newton Fig - The pool of water in the Ancient Cave.

Gens - Re-creating the unused Pixel Remaster Narshe overworld map tiles.

Everything - Making the patch that implements the unused Pixel Remaster Narshe overworld map tiles.

===============================
BATTLESCRIPTS
===============================

Lord Envoy - A bunch of original boss scripts and & the FF6 Advance Dragon battle scripts.

JCE3000GT - Guardian Beast script.

Gi Nattak - Much battlescript work.

===============================
DIALOG
===============================

Gi Nattak - Much dialog work.

SSJ Rick - Much dialog work.

Magical Trevor - Lots of grammar assistance in the early stages.

Sutebenu - Cleaning up some dialog/grammar in the early stages.

Celes Chere, Final Fantasy 6 - The Novel

Lina Darkstar's fan translation

FF6 Advance (Tom Slattery)

===============================
BETA TESTERS
===============================

AetherMegiddo, Alucard989, Andervann, Angelo, B00MSH1ZZ, Bahamut ZERO, Blitzkrieg, Bryan., Castilho, Crono, DFA, DJKool, DudeMan, FNCardascia, Gaff, IllusionaryNight, James White, Justin, Lockirby, Lord Sutebenu, Lufia, Lysdexic, Magical Trevor, MetalHatton, Mr. Moogle, Odbarc, oronjoker, Qb Spy, RaikouGilgamesh, RegretFear, Retrogamer, Roxas123, SSJ Rick, Starsinger17, Taco_Party, TheIncredibleHouck, Thedirtyhippie, Tim820, Vax, derp, flarenial, lordalexander, maiatsu, touya, wayss

===============================
SPRITE PROPERTY
===============================

James White (a.k.a. phunbaba) - ALL the monsters, portraits, and esper sprites you see in the game, Dragoon Otis, Madeen, Titan, generic female, Search Ghost, Ramuh, Master Oyama, Skeleton, Zombie, Guru, Cannibus plant, Odin, Shokan woman, Shang Tsung, Lightsaber, Carbuncle, Ifrit, Shiva, Dwarf, Bomb, James White/male White Mage and Jackimus NPCs, the new Statues, lufia static, merchant static, Fire Boss, Tuturis, a whole bunch of the shopkeepers and some other random NPCs from Mortal Kombat, Jade Cocoon, Chrono Trigger, Sonic, and all the 'facing down' action poses for the playable characters, all the 'side b' character graphics. Check out James' Deviant Art page here: https://www.deviantart.com/jameswhite89

SSJ Rick - Serin, Reaper, Avalon, Eiko (1st version), alternate Cloud (KO pose done by James White), Metroid, Pig Sprite, Reptite, Lizardman, Lamia, Cobra, Onion Knight, Caped Soldier #2, Returner with Sword, 'Dark Knight' Golbez, Esper Aurora and all her custom poses, Young Ronan and Serin, Young Oboro, Roxanne, Pirate Chick, Tonberry, Caped Soldier no helmet, Queen Hilda, Aerith, Klatu, generic male, generic old man, generic old woman, Preacher, King Durandal, Nun, generic boy, generic female, impresario, elf woman, elf boy, merchant, Talon, maid, lil pimp kid, santa, Raditz, Gremlin, Pirate 2, bald impresario, Arc's mother, Terry, Vanille, scientists, bard, prisoner, walter white/heisenburg, various pokemon, sideways flaming skull, FFT-style RK Chocobo, and pretty much every other NPC and static sprite/object you see in the game such as custom magicite or food items etc.

Kugawattan - finish work on Classic Golbez.

Zozma - Barberella (Aurora, altered by SSJ Rick), Zigfreid, Vargas

Sutebenu - Chained Tifa, "hair blowing in the wind Aurora", Flying Esper Aurora (pre 2.0 versions)

DjinnandTonic - Prinny

OBSailorStar - Olbohn

FEOK - Fusoya, Pirate (finished by SSJ Rick)

Sathka - Hector (Old hooded man)

Zozma - Clyde

FnrrfYgmSchnish - Heartless

Astaroth (tweaked slightly by SSJ Rick) - Tifa

Koreki - Bow Wow

Dr. Blank - Elite Knight

Royaken - Credit for previous work on Cloud's sprite.

ScarabEnigma - FF Record Keeper Eiko, FF Record Keeper Cloud, FF Record Keeper Tifa touch ups, custom Crusher NPC sprite for Guardian, original NPC sprite for the tank, updated/new Aurora sprites, updated/new Aurora sprites.

BigSharkZ - Cute Li'l UFO monster sprite

Badass - Namingway

===============================
MUSIC HACKING
===============================

Jackimus:
Alefgard/FFIV mashup (the bassline)
Battle Theme - Final Fantasy Mystic Quest
Battle Theme - Final Fantasy VII
Battle Theme - Lufia II
Boss Theme - Final Fantasy IX
Boss Theme - Final Fantasy Mystic Quest
Boss Theme - Super Metroid/Prime
Dark King - Final Fantasy Mystic Quest
Dead Sea - Chrono Cross (created the midi)
Eiko's Theme - Final Fantasy IX
FFT Unavoidable Battle (staccato to the trumpets)
Felix's battle theme - Golden Sun 2
Fight Against Smithy - Super Mario RPG
Fight With Seymour - Final Fantasy X
Future Fuckballs 2010 - AVGN
Gaur Plains - Xenoblade
He's a Pirate! - Pirates of the Caribbean
J-E-N-O-V-A - Final Fantasy VII
Mechonis Field - Xenoblade
Megalovania - Undertale
Neclord Battle Theme - Suikoden II
Nuclear Fission - Seiken Densetsu 3
Storm Mammoth (MMX - Storm Eagle & Flame Mammoth Remix)
The Man With the Machine Gun - Final Fantasy VIII
Those Who Fight Further - Final Fantasy VII
Town of Toronto - Brain Lord
You Will Know Our Names - Xenoblade

emberling:
A Painful Death at the Hands of a Psycho - Live A Live
Ancient Dragon's Stronghold - Chrono Cross
Another Winter - Seiken Densetsu 3
Arni Village - Chrono Cross (splits credit with Gi Nattak)
Azys Lla - Final Fantasy XIV
Battle #3 - Lufia 1
Battle Theme - Final Fantasy X
Birth of a God - Final Fantasy VII
Buried in the Snow - Final Fantasy VII
Burn! Bobonga! - Chrono Trigger
Can You Fly, Sister? - Seiken Densetsu 3
Costa Del Sol - Final Fantasy VII
Crateria - Super Metroid
Cross Counter - Breath of Fire 2
Crossing Those Hills - Final Fantasy IX
Dancing Calcobrena - Final Fantasy IV
Don't Be Afraid - Final Fantasy VIII
Doom - Doom II
Fighting of the Spirit - Tales of Phantasia
Flame And Arrow - Treasure of the Rudra (soundtrack b version)
Flight - Xenogears
Force Your Way - Final Fantasy VIII
Gargan Roo - Final Fantasy IX
Guerilla War - Ogre Battle
Hurry! - Final Fantasy VII
Hydra Marshes - Chrono Cross
In the Earthen Womb - Illusion of Gaia (soundtrack b version)
Innocent Sea - Seiken Densetsu 3
Ken's Theme - Street Fighter 2
Kingdom Of Tantal (Day) - Xenoblade Chronicles 2
Lava Dome - Final Fantasy Mystic Quest
Lost Child of Time - Chrono Cross
Lust for Power - Final Fantasy XII
Main Theme - Chrono Trigger
Martial Law - Final Fantasy VIII
Maybe I'm a Lion - Final Fantasy VIII
Mining Town - Final Fantasy VII
Mint's Theme - Tales of Phantasia
Morardain - Xenoblade Chronicles 2
Mount Gale - Final Fantasy Mystic Quest
Mount Pyre - Chrono Cross
Ominous Whispers - Illusion of Gaia
Orc 1 - Warcraft 2
Overworld Theme 3 - Tales of Phantasia
Pain in the Universe - Legend of Mana
Path of Repentance - Final Fantasy X
Raising a Curtain - Tales of Phantasia
Red Knight - Xenogears
Rescue Operation - Star Ocean 2
Rock Theme - Final Fantasy Mystic Quest
Sacrifice - Seiken Densetsu 3
Seal of Time - Ys III: Wanderers from Ys
Shrine of Light - Final Fantasy Mystic Quest
Spirit Chaser - Treasure of the Rudras (splits credit with Gi Nattak)
Spirit of the Hunt - Final Fantasy IX
Steel Giant - Xenogears
Strange Medicine - Seiken Densetsu 3
Ken's Theme - Street Fighter 2
Strike Your Mind - Star Ocean 2
Succession of Witches - Final Fantasy VIII
Sunshade City - Octopath Traveler
Tears of the Stars, Thoughts of the People - Xenogears
The Dark Star - Secret of Mana
The End of the Raging Waves - Etrian Odyssey III
The Gun Barrel of Battle - Lost Odyssey
Time of Decision - Sword of Mana (splits credit with Gi Nattak)
Towering Mountain - Lufia 2 (splits credit with Gi Nattak)
Tunnel Ruins - Golden Sun
Victory Theme - Final Fantasy Mystic Quest
Weird Counterpoint - Seiken Densetsu 3
Whisper And Mantra - Secret of Mana
Wild Fields - Crystalis
World Revolution - Chrono Trigger
Zed's Theme - Wild Arms (splits credit with Gi Nattak and A Tiny Spook)

JCE3000GT:
Field - Romancing Saga 3
Overworld 1 - Final Fantasy Adventure (provided midi)
Shrine - Treasure Conflix
Silent Light - Chrono Trigger
Year of the Holy King - Romancing Saga 3

Tsushiy:
Aerith's Theme - Final Fantasy VII
Battle #2 - Lufia II
Battle #2 - Saga Frontier
Battle #3 - Saga Frontier
Battle 2 Final Fantasy III
Battle 5 - Saga Frontier
Battle with Magus - Chrono Trigger
Boss Battle B - Final Fantasy I
Dreadful Battle - Final Fantasy IV
Four Noble Devils 2 - Romancing Saga 3
Gen's Castle Battle - Romancing Saga 3
Good Night - Final Fantasy IV
Grahf Emperor of Darkness - Xenogears
Illusionary World - Final Fantasy IV
Into the Darkness - Final Fantasy IV
Last Battle - Romancing Saga 3
Trick - Saga Frontier
Unforgettable Sorrow - Final Fantasy IX
Vulpes (day) - Final Fantasy The Four Heroes of Light

MetroidQuest:
Boss Theme - Final Fantasy IV
Unused Battle 2 - Chrono Trigger

Cecil188:
Garden of Memories - Dark Cloud 2

William Kage:
Determination (creator of the original song and midi)

Gi Nattak:
All the rest.

===============================
MISC. CREDITS
===============================

Pandora's Box Team - various font and item icons and an event-related idea or two.
Madsiur - a couple window/wallpaper graphics.
James White - Splash Screen, a couple window/wallpaper graphics.
emberling - custom BRR samples.
BTB - S.Cross palette change to red.
C-Dude & Lightning - hammer weapon gfx shown as the 4th frame of the weapon attack animation.
seibaby - relics won't remove statuses outside of battle. (shares credit with C-Dude)
Ryo_Hazuki - got the yellow-coloring on the Mastered Espers star icon.

===============================
SPECIAL THANKS
===============================

Lord J and his wonderful all purpose editor FF3usME.
giangurgolo for his superb level editor FF6LE.
Terri Senshi for his fantastic sprite editor. ~JW
SSJ Rick, Angelo, Madsiur, & James White for their massive amount of time/work invested.
Lord Envoy for his battle script work.
JCE3000GT for teaching me a lot about the music engine.
Lenophis for his knowledge and assistance.
Lockirby for his great testing skills and beautiful overworld maps.
GrayShadows for his awesome patches and lots of help.
HatZen for his many wonderful patches and help.
Tsushiy for helping me, despite the language barrier.
Jackimus for song feedback and creating & hacking in his own custom songs and being awesome.
Synchysi for taking the time to do some much needed assembly tasks.
Lufia for doing an incredibly thorough testing-playthrough.
Tenkarider for doing an incredibly thorough playthrough.
emberling for greatly advancing the MML game, creating mfvitools which made music-hacking a whole lot easier resulting in countless hours saved, and for going out of her way to make her songs used here on 'Soundtrack B' sound the absolute best in regards to rotds' custom samples.
ScarabEnigma for doing what turned out to be a much needed and unexpected beta testing for v2.0.
Zig for being a die-hard RotDS fan since the beginning.
C-Dude for his kindness and helping to solve some issues.
My good buddy Alex "Nacho" for getting me -very- interested in FF6 and RPGs in the first place so long ago.
The beta testers who managed to make it through much or all of the game.
Squaresoft and all who were involved with the making of the masterpiece that is FF6.

===============================
KNOWN ISSUES
===============================

- Strange targetting in battles that feature 'characters acting as monsters'.
- Monster formations with a high pixel count might have a sprite experience pixel loss when animations are in progress, due to SNES hardware limitations.
- Vysage's blocking hand palette can mess up due to how it was colored.
- Using too many Quicksilvers in a row (casts Quick) can freeze a character if they are in the middle of casting, or something... try to not use Quicksilver on more than one character at a time! And if you become stuck, try to run. And if all else fails, kill your party member who is frozen stuck.
- Sleeping at the inn in Ornyx (Vector) can be a bit wonkey, caused by the lengthier sleeping song.
- Lich Ring will cause Morph to cost twice as much.
- Leo's blaster attack can have some wonkiness with the 'X' animation going on the wrong monster.
- Sometimes Jump will have an additional 'jump' sound happen while in midair, especially when Quicksilver is used directly after Jump. This is an original bug, but becomes more frequent in RotDS because of a multitude of reasons.
- Monsters that can use Jump sometimes will stay up in the air much longer than they should, but will eventually come back down. This is rare enough that I can't reproduce it ever to try and fix it.
- Text boxes in custom intro become weird if game resets during it, with no srm data present.
- Fusoya is the wrong palette during the ending scene.
- In some rare cases, a magic-blocking shield animation can cause a character to step forward or back after blocking.
- Bringing the guest-item character Astral to the 2nd WoR Mobliz Proto-Babil fight will result in him being removed from the party/battle due to another temporary guest joining the fight which uses the same character ID.
- after defeating the final boss, the screen may or may not stay at a black screen until the 'confirm' button is pressed to continue the event.
- If using an inferior emulator, such as ZSNES, a couple select monster formations will have the selectable hand cursor blocked out by the monster mould, and some select songs may have issues.

Please report any bugs or any questions or comments you may have, or just come say hi @
http://www.ff6hacking.com/forums/forumdisplay.php?fid=54
or...
http://ngplus.net/index.php?/forums/forum/6-final-fantasy-vi-return-of-the-dark-sorcerer/

You can reach out to us at our discord channel as well, server name FF6 Hacking: https://discord.gg/FFAHavK

Play on RetroAchievements here: https://retroachievements.org/game/16496

A strategy guide can be found here: https://www.ff6hacking.com/rotds/guide.html
Check out the RotDS soundtrack: https://www.ff6hacking.com/rotds/ost.html
Also here, but they are outdated: https://www.ff6hacking.com/forums/thread-3495.html

On behalf of myself and the others responsible for the creation of this mod, we hope you have an enjoyable experience, and be on the lookout for updates in the future!

Mike Ferrell (Gi Nattak)

===============================
DISCLAIMER
===============================

Final Fantasy VI: Return of the Dark Sorcerer
Copyright (C) 2023 Mike Ferrell (Gi Nattak)

The copyright holder ("author") permits the free use of the attributed work referenced by this document exclusively for non-commercial purposes, provided that the following conditions are met:
1. This readme document shall accompany the attributed work wherever it is redistributed.
2. This permission notice shall accompany the attributed work wherever it is copied, reused, redistributed, or modified.
3. Credit shall be given to all contributors for their respective contributions to the attributed work as recognized in this readme document and other publicly available documentation.

The work(s) and file(s) distributed with this document are provided "AS-IS", WITHOUT ANY WARRANTY. The author shall not be held responsible for any damages related to the use of work(s) and file(s) distributed with this document.

FINAL FANTASY is a registered trademark of Square Enix Holdings Co., Ltd.
FINAL FANTASY VI (C) 1994, 2006, 2014 SQUARE ENIX CO., LTD.

The author of the attributed work referenced by this document makes no claim to FINAL FANTASY VI or any intellectual property contained therein.
