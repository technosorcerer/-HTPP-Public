If the monster has a rare and common item, it will steal the rare 100% of the time, and there's no longer steal miss at all. You can then also steal the common one after the rare one.
This patch is more or less a cheat, so keep that in mind when deciding to apply it or not.

Credit: Lufia
