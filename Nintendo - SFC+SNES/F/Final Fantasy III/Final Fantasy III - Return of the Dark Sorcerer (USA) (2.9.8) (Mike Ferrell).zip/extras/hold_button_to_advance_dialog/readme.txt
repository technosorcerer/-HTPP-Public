This patch makes it so that holding the 'confirm' button, which is normally the 'A' button, will advance dialog text, instead of needing to press it.

Credit to Fëanor.