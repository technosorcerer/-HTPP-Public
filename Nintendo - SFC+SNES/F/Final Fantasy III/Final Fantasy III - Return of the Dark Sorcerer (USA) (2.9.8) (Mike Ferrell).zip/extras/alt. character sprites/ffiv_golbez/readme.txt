This patch changes Golbez's sprite and portrait to a much more FF4 variation.

Credit: James White and Kugawattan