This patch changes Shadow the Heartless's sprite and portrait to a much more intimidating version that is the dreaded Invisible, also from the Kingdom Hearts universe.

Credit: James White (made the sprite and portrait)