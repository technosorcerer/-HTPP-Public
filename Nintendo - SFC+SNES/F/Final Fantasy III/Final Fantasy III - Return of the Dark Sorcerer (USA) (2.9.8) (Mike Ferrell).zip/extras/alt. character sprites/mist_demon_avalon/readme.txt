This patch changes Avalon's sprite and portrait to a mistly demon-like form, with horns, wings, and claws akin to that of a dragon.

Credit: James White (made the sprite and portrait)