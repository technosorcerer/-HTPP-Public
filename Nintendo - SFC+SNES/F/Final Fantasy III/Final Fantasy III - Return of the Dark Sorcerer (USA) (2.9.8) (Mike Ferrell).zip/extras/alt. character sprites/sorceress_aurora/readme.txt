This patch changes Aurora's sprite and portrait to another version: Sorceress Aurora!
She dons a beautiful FF8 Sorceress-inspired garment.

Credit: James White (made the sprite and portrait)