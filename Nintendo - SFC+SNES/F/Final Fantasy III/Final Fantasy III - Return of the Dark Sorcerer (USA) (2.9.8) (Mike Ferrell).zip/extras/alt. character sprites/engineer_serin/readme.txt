This patch changes Serin's sprite and portrait to an engineer reminiscent of Cid from FFIV, with a touch of Mega Man.

Credit: James White (made the sprite and portrait)