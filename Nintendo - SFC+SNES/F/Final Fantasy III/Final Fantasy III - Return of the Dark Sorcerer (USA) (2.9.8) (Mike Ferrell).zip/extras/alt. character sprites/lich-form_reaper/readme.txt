This patch changes Reapers's sprite and portrait to another version: Lich-form Reaper.

Credit: James White (made the sprite and portrait)