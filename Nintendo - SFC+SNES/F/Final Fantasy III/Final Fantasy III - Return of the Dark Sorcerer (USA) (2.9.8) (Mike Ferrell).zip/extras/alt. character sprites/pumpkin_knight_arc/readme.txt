This patch changes Arc's Onion Knight sprite and portrait to that of a familiar spooky orange squash: Pumpkin Knight Arc!
His class name however will remain 'Onion Knight', due to the character length and dialog.

Credit: James White (made the sprite and portrait)