This patch makes it so instead of holding B to run, it will make you walk. You will now run by default/pressing nothing.

Credit: Lufia