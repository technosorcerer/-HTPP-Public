This patch, made by Master ZED a million years ago, will unrig the slots that are rigged against you.
I personally do not like this change because I can't land ANYTHING anymore, unless I 'pause abuse'... but I know that many players do prefer the slots unrigged, so here ya go.

Credit: Master ZED