Title: Battle Interface Upgrade
Author: SilentEnigma
Version: 1.6
Release Date: 2022-05-28
Tools used: FCEUX 2.2.2, YY-CHR
Applies to: FF3j English translation by A.W.Jackson/Neill Corlett/SoM2Freak v1.1

Archive Contents
-------------------------------

  FF3j_BattleInterfaceUpgrade.ips = the patch

  readme.txt                      = this file


ROM Addresses
-------------------------------

  graphics:
    file offsets 01BF80-01BFFF

  code (as mapped in battle):
    00: 92BE
    0C: 822C 822E
    0D: 9F84-9FAC
    18: A09E A1D3 A1F5 A1FF BCC5
    19: 9F90-9FE3
    1A: 80B5-80B7 8E83-8EAD 9056-905A 9177-91CD 91D4-91DA
        94E7-950C 950D 950F 9515 9517 9519-954C
        9928-9929 997B 999C A21D-A21E A27E-A281 A2A5
        A2A9-A2AA A2AE-A2B8 A51D-A51F A5D4-A5D8 A5F4
        A7F2-A7F3 A889-A88A A8BF-A8C0 A9D8-A9D9
        AC74-AC75 ADB0-ADB1 B5C4-B5C5 B5C1-B5C2 B793-B795 B8CF-B8D0
        B9BA-B9BB BFF2-BFFE


TABLE OF CONTENTS
-------------------------------

1. Description & Motivation
2. Detailed Changes
3. Relevant Offsets & Disassembly
4. Revision History
5. Legal

________________________________________________________________________________

  1. DESCRIPTION & MOTIVATION
________________________________________________________________________________


Final Fantasy III introduced new advancements to visual effects in battle:
improved attack animations, the bouncing damage numbers, and enemies that blink
as they attack. These features, which would become standards in succeeding
titles, made the much of the legacy battle commentary obsolete.

A few examples:

 - When a character is cured, his HP increase is shown as a bouncing green
   numeral; it is unnecessary to show the message "HP Up!".

 - With the addition of blinking enemies, one can almost always discern the
   actor and the target of each turn from the animation alone.

 - When an enemy is defeated, its sprite gets wiped away; it is unnecessary to
   show a "Defeated" message.

 - When a physical attack misses, the word "miss" bounces on the target; it is
   unnecessary to show the "Miss!" message.

In FF3j, virtually all battle messages are retained in spite of the new visual
effects. This slows down the action, draws the eyes away from the animations,
and often just provides redundant information. Final Fantasy IV's battle
interface would finally do away with the constant messages, and it feels like
a breath of fresh air by comparison.

This hack revamps the battle interface of FF3j to provide an experience that is
more like that of FF4. It removes unnecessary commentary, uses cleaner FF4-style
window graphics, and also removes a few minor design quirks that failed to
become series standards.

________________________________________________________________________________

  2. DETAILED CHANGES
________________________________________________________________________________


 - Window appearance is upgraded to the style used in FF4

 - Unnecessary mid-action battle messages are bypassed:
    > Actor label window is only displayed when the actor cannot be discerned
      from the animation
    > Target label window is never displayed
    > Action messages are suppressed for several cases (e.g. Defend, BuildUp,
      Jump, Advance, Fall Back, "Miss!")
    > Status effect alerts are only displayed for enemies inflicted by a
      physical attack
    > Most messages about health increases/decreases or getting knocked out are
      now omitted

 - Message windows are repositioned, appearing centered on top of the the menu
   windows and appear one at a time*

 - The enemy list window on the left is no longer erased during the action

 - Damage numerals appear white, as became the series standard, making them
   easier to read

 - The mandatory button press at the beginning of each (non-ambush) battle is
   bypassed

 - Blinking actor I.D. numerals on targeted enemies are no longer displayed

 - Only one left/right button press is now necessary to use the row command

 - Canceling target selection for magic returns to the magic menu rather than
   the top menu

 - Canceling target selection for items returns to the items menu rather than
   the top menu

 - The appearance of window transitions for magic and item menus have been
   adjusted slightly


 * It would have been great to place messages at the top of the screen, but
 there is a PPU table barrier between the windows and the illustration graphics.
 The result would have been windows made of garbage.

________________________________________________________________________________

  3. RELEVANT OFFSETS & DISASSEMBLY
________________________________________________________________________________


Window style

  file offset 01BF80-01BFFF

==================================================

Target window display - replaced with new subroutine code

Original:
 ; Display "target" window
 1A:9177: AD D8 78  LDA $78D8
 1A:917A: 10 2F     BPL $91AB
 1A:917C: C9 FF     CMP #$FF
 1A:917E: F0 4B     BEQ $91CB
 1A:9180: 29 7F     AND #$7F
 1A:9182: C9 08     CMP #$08
 1A:9184: D0 0A     BNE $9190
 1A:9186: A9 16     LDA #$16
 1A:9188: 85 1A     STA $001A
 1A:918A: 20 C6 95  JSR $95C6
 1A:918D: 18        CLC
 1A:918E: 90 11     BCC $91A1
 1A:9190: AA
 1A:9191: BD CD 7E  LDA $7ECD,X
 1A:9194: AA        TAX
 1A:9195: BD 6B 7D  LDA $7D6B,X
 1A:9198: C9 FF     CMP #$FF
 1A:919A: F0 2F     BEQ $91CB
 1A:919C: 85 1A     STA $001A
 1A:919E: 20 BD 95  JSR $95BD
 1A:91A1: A5 1A     LDA $001A
 1A:91A3: A2 00     LDX #$00
 1A:91A5: 20 09 A6  JSR $A609
 1A:91A8: 18        CLC
 1A:91A9: 90 14     BCC $91BF
 1A:91AB: 20 3C FD  JSR $FD3C
 1A:91AE: 18        CLC
 1A:91AF: 69 06     ADC #$06
 1A:91B1: A8        TAY
 1A:91B2: A2 00     LDX #$00
 1A:91B4: B1 57     LDA ($57),Y
 1A:91B6: 9D D7 7A  STA $7AD7,X
 1A:91B9: C8        INY
 1A:91BA: E8        INX
 1A:91BB: E0 06     CPX #$06
 1A:91BD: D0 F5     BNE $91B4
 1A:91BF: A9 09     LDA #$09
 1A:91C1: 85 18     STA $0018
 1A:91C3: 20 6A 96  JSR $966A
 1A:91C6: A9 02     LDA #$02
 1A:91C8: 20 1B 8D  JSR $8D1B
 1A:91CB: 4C 51 90  JMP $9051
Modified:
 ; original code removed, added new subroutines
 1A:9177: EA EA EA EA EA EA EA EA EA EA EA EA EA EA EA EA    NOP x16
 1A:9187: EA                                                 NOP
 ; New subroutine 1A:9188
 1A:9188: A5 10     LDA $0010      ; load horizontal window view position I.D.
 1A:918A: F0 20     BEQ 91AC       ; branch if 0 (default position)
 1A:918C: 4C B0 8E  JMP 8EB0       ; clear all windows
 ; New subroutine 1A:918F
 1A:918F: 18        CLC            ; clear carry
 1A:9190: 69 20     ADC #$20       ; get "actual" message I.D. from accumulator
 1A:9192: C9 2A     CMP #$2A       ; Is Cure4 being used?
 1A:9194: D0 09     BNE $919F      ; branch if not Cure4
 1A:9196: AD D8 78  LDA $78D8      ; Load target I.D.
 1A:9199: C9 88     CMP #$88       ; Is target 'all'?
 1A:919B: F0 0D     BEQ 91AA       ; branch if targeting 'all'.
 1A:919D: A9 24     LDA #$24       ; Load message I.D. for "Fully restored!"
 1A:919F: A2 0D     LDX #$0D       ; number of entries in exclude list
 1A:91A1: DD F2 BF  CMP $BFF1,X    ; compare to current exclusion
 1A:91A4: F0 04     BEQ $91AA      ; branch if matching
 1A:91A6: CA        DEX            ; decrement X
 1A:91A7: D0 F8     BNE $91A1      ; loop through exclusion table
 1A:91A9: 60        RTS            ; return from subroutine
 1A:91AA: A9 FF     LDA #$FF       ; Load message I.D. for no message
 1A:91AC: 60        RTS            ; return from subroutine
 ; New subroutine 1A:91AD
 1A:91AD: AD D7 78  LDA $78D7      ; Load number of hits from last turn
 1A:91B0: C9 FF     CMP #$FF       ; Check if number of hits invalid
 1A:91B2: F0 08     BEQ $91BC      ; If so, skip next line
 1A:91B4: 20 9E 9D  JSR $9D9E      ; subroutine to draw enemy list window
 1A:91B7: A9 07     LDA #$07       ; load I.D. for "minimalist" script
 1A:91B9: 8D D5 78  STA $78D5      ; store battle script
 1A:91BC: A9 FF     LDA #$FF       ; Load invalid hit number
 1A:91BE: 8D D7 78  STA $78D7      ; Store number of hits
 1A:91C1: A9 25     LDA #$25       ; from 1A:9056
 1A:91C3: 4C 0E FA  JMP $FA0E      ; from 1A:9058
 ; New subroutine 1A:91C6
 1A:91C6: 20 C5 F8  JSR $F8C5      ; from 1A:ADBD
 1A:91C9: A9 98     LDA #$98       ; load value used for default menu view
 1A:91CB: 85 08     STA $0008      ; restore value to memory
 1A:91CD: 60        RTS            ; return from subroutine

Original:
 1A:BFF2: 00 00 00 00 00 00 00 00 00 00 00 00 00      ; free space
Modified:
 1A:BFF2: 01 23 25 26 27 2B 38 39 41 45 46 54 5F     ; message exclusion list


==================================================

End of turn

Original:
 1A:9056: A9 25     LDA #$25
 1A:9058: 4C 0E FA  JMP $FA0E
Modified:
 1A:9056: 4C AD 91  JMP $91AD      ; jump to code injection at $91AD (see above)
 1A:9059: EA        NOP
 1A:905A: EA        NOP

==================================================

Start-of-battle button press

Original
 1A:9928: F0 F9     BEQ $9923      ; Branch if button pressed
Modified:
 1A:9928: D0 F9     BNE $9923      ; Branch if no button pressed

==================================================

Blinking actor I.D. numbers

Original:
 19:9F90: 90 4C     BCC $9FDE
 19:9F92: 98        TYA
 19:9F93: 0A        ASL
 19:9F94: AA        TAX
 19:9F95: BD F7 7D  LDA $7DF7,X
 19:9F98: 85 9D     STA $009D
 19:9F9A: A5 A3     LDA $00A3
 19:9F9C: 0A        ASL
 19:9F9D: 0A        ASL
 19:9F9E: 0A        ASL
 19:9F9F: 18        CLC
 19:9FA0: 65 9D     ADC $009D
 19:9FA2: 85 9D     STA $009D
 19:9FA4: 20 D2 90  JSR $90D2
 19:9FA7: D0 0C     BNE $9FB5
 19:9FA9: A5 9D     LDA $009D
 19:9FAB: 49 FF     EOR #$FF
 19:9FAD: 18        CLC
 19:9FAE: 69 F1     ADC #$F1
 19:9FB0: 85 9D     STA $009D
 19:9FB2: 4C BC 9F  JMP $9FBC
 19:9FB5: A5 9D     LDA $009D
 19:9FB7: 18        CLC
 19:9FB8: 69 08     ADC #$08
 19:9FBA: 85 9D     STA $009D
 19:9FBC: BD F8 7D  LDA $7DF8,X
 19:9FBF: 85 9E     STA $009E
 19:9FC1: 8A        TXA
 19:9FC2: 0A        ASL
 19:9FC3: 18        CLC
 19:9FC4: 69 60     ADC #$60
 19:9FC6: AA        TAX
 19:9FC7: A5 9E     LDA $009E
 19:9FC9: 9D 00 02  STA $0200,X
 19:9FCC: A5 A3     LDA $00A3
 19:9FCE: 18        CLC
 19:9FCF: 69 3A     ADC #$3A
 19:9FD1: 9D 01 02  STA $0201,X
 19:9FD4: A9 03     LDA #$03
 19:9FD6: 9D 02 02  STA $0202,X
 19:9FD9: A5 9D     LDA $009D
 19:9FDB: 9D 03 02  STA $0203,X
 19:9FDE: C8        INY
 19:9FDF: C0 08     CPY #$08
 19:9FE1: D0 AB     BNE $9F8E
 19:9FE3: 60        RTS
Modified:
 19:9F90: 60        RTS            ; Skip subroutine
 19:9F91: EA EA EA EA EA EA EA EA EA EA EA EA EA EA EA EA    NOP (x16)
 19:9FA1: EA EA EA EA EA EA EA EA EA EA EA EA EA EA EA EA    NOP (x16)
 19:9FB1: EA EA EA EA EA EA EA EA EA EA EA EA EA EA EA EA    NOP (x16)
 19:9FC1: EA EA EA EA EA EA EA EA EA EA EA EA EA EA EA EA    NOP (x16)
 19:9FD1: EA EA EA EA EA EA EA EA EA EA EA EA EA EA EA EA    NOP (x16)
 19:9FE1: EA EA EA                                           NOP (x3)

==================================================

Erasing Enemy List Window

Original:
 1A:80B5: 20 0B 8F  JSR $8F0B      ; Jump to subroutine to erase window
Modified:
 1A:80B5: 20 9E 9D  JSR $9D9E      ; Jump to subroutine to draw enemy list window

==================================================

Erasing Enemy List Window before Cannon Blast

Original:
 1A:A51D: 20 0B 8F  JSR $8F0B      ; Jump to subroutine to erase window
Modified:
 1A:A51D: EA        NOP
 1A:A51E: EA        NOP
 1A:A51F: EA        NOP

==================================================

Battle turn animation scripts

Original:
 1A:9519: 05 07 0B 06 0C 08 0D 09 0A 04 03 01 02 00 FF  ; physical attack
 1A:9528: 05 06 07 0B 0C 08 09 0D 0A 04 03 02 01 00 FF  ; specials/magic
 1A:9537: 09 0A 04 FF                                   ; victory
 1A:953B: 09 0B 0C 0E 0A 04 FF                          ; level up (?)
 1A:9542: 05 09 0A 04 00 FF                             ; skill up
 1A:9548: 09 0C 0A 04 FF                                ; damaged by poison
Modified:
 1A:9519: 42 95                              ; pointer to "run away" script
 1A:951B: 34 95                              ; pointer to "minimalist" script
 1A:951D: 3A 95                              ; pointer to "skip all" script
 1A:951F: 0B 06 0C 01 08 09 0D 0A 04 01 FF   ; physical attack
 1A:952A: EA                                 ; NOP
 1A:952B: 06 0B 01 09 0C 0D 0A 04 FF         ; specials/magic
 1A:9534: 0B 0C 0D                           ; minimalist turn; no ability/hits
 1A:9537: 09 0A 04 FF                        ; victory
 1A:953B: 09 0B 0C 0E 0A 04 FF               ; level up (?)
 1A:9542: 0B 0D                              ; run away
 1A:9544: 05 09 0A 04 00 FF                  ; skill up
 1A:954A: 0C 0A FF                           ; damaged by poison

==================================================

Pointer to "physical attack" script (index 0)
Original:
 1A:950D: 19 95
Modified:
 1A:950D: 1F 95

Pointer to "specials/magic" script (index 1)
Original:
 1A:950F: 28 95
Modified:
 1A:950F: 2B 95

Pointer to "skill up" script (index 4)
Original:
 1A:9515: 42 95
 becomes:
 1A:9515: 44 95

Pointer to "damaged by poison" script (index 5)
Original:
 1A:9517: 48 95
Modified:
 1A:9517: 4A 95

==================================================

Animation script selection for various conditions

Defend
Original:
 1A:A889: A9 00     LDA #$01       ; index of special/magic script pointer
Modified:
 1A:A889: A9 07     LDA #$07       ; index of minimalist script pointer

Advance & Fall Back
Original:
 1A:A7F2: A9 01     LDA #$01       ; index of special/magic script pointer
Modified:
 1A:A7F2: A9 07     LDA #$07       ; index of minimalist script pointer

Jump
Original:
  1A:A9D8: A9 01     LDA #$01      ; index of special/magic script pointer
Modified:
  1A:A9D8: A9 07     LDA #$07      ; index of minimalist script pointer

BuildUp
Original:
 1A:AC74: A9 01     LDA #$01       ; index of special/magic script pointer
Modified:
 1A:AC74: A9 07     LDA #$07       ; index of minimalist script pointer

Run
Original:
 1A:A8BF: A9 01     LDA #$01       ; index of special/magic script pointer
Modified:
 1A:A8BF: A9 06     LDA #$06       ; index of Run Away script pointer

Slain
Original:
 1A:A2A9: A9 1A     LDA #$1A       ; load message I.D. for "slain"
Modified:
 1A:A2A9: A9 FF     LDA #$FF       ; load I.D. for no message

Knight Guards Ally
Original:
 1A:A21D: A9 52     LDA #$52       ; load message I.D. for "Knight Guards Ally"
Modified:
 1A:A21D: A9 FF     LDA #$FF       ; load I.D. for no message

Near death, Status restored, HP up!, Revived!, ...
Original:
 1A:A5D4: 18        CLC
 1A:A5D5: A5 24     LDA $0024      ; load action I.D.
 1A:A5D7: 69 20     ADC #$20
Modified:
 1A:A5D4: A5 24     LDA $0024      ; load action I.D.
 1A:A5D6: 20 8F 91  JSR 918F       ; jump to new subroutine $918F (see above)

Absorbed!:
Original:
 1A:A5F3: A9 FF     LDA #$01       ; load message I.D. for "Absorbed!"
Modified:
 1A:A5F3: A9 FF     LDA #$FF       ; load I.D. for no message

Absorbed HP!:
Original:
 18:A1F4: A9 25     LDA #$25        ; load message I.D. for "Absorbed HP!"
Modified:
 18:A1F4: A9 FF     LDA #$FF        ; load I.D. for no message

HP Drained!:
Original:
 18:A1FE: A9 26     LDA #$26        ; load message I.D. for "HP Drained!"
Modified:
 18:A1FE: A9 FF     LDA #$FF        ; load I.D. for no message

HP Drained! (again):
Original:
 18:A1D2: A9 27     LDA #$27        ; load message I.D. for "HP Drained!"
Modified:
 18:A1D2: A9 FF     LDA #$FF        ; load I.D. for no message

Critical Hit!
Original:
 18:A09D: A9 34     LDA #$34        ; load message I.D. for "Critical Hit!"
Modified:
 18:A09D: A9 FF     LDA #$FF        ; load I.D. for no message

Damages undead
Original:
 1A:A5EF: A9 45     LDA #$45       ; load message I.D. for "Damages undead"
Modified:
 1A:A5EF: A9 FF     LDA #$FF       ; load I.D. for no message

Cured, after getting hit while confused:
Original:
 1A:A27E: 8A        TXA            ; Transfer A to X
 1A:A27F: 18        CLC            ; Clear carry
 1A:A280: 69 02     ADC #$02       ; Transform to actual message I.D. for "Cured"
Modified:
 1A:A27E: EA        NOP
 1A:A27F: EA        NOP
 1A:A280: A9 FF     LDA #$FF       ; Load I.D. for no message

==================================================

Target not defeated on attack
Original:
 1A:A2A4: F0 11     BEQ $A2B7
Modified:
 1A:A2A4: F0 08     BEQ $A2AE

Defeated (enemy) - set script to normal attack
Original:
 1A:A2AE: A0 2C     LDY #$2C
 1A:A2B0: B1 70     LDA ($70),Y
 1A:A2B2: 10 03     BPL $A2B7      ; Branch if defeated target was ally
 1A:A2B4: FE DA 78  INC $78DA,X    ; Change message I.D. from "slain" to "defeated"
 1A:A2B7: A9 00     LDA #$00       ; load offset for normal attack script pointer
Modified:
 1A:A2AE: AD D7 78  LDA $78D7      ; load value for number of hits
 1A:A2B1: F0 04     BEQ $A2B7      ; branch if number of hits zero
 1A:A2B3: A9 00     LDA #$00       ; load offset for normal attack script pointer
 1A:A2B5: F0 02     BEQ $A2B9      ; branch
 1A:A2B7: A9 07     LDA #$07       ; load offset for minimalist script pointer

==================================================

Status change text

"Petr"
Original:
 18:BCC4: A9 0B     LDA #$0B       ; Load message I.D. for "petr "
Modified:
 18:BCC4: A9 07     LDA #$07       ; Load message I.D. for "Enlarged" (see below)

Rearranged status change message strings
Original:
 0D:9F84: 9B A8 B9 AC B9 A8 A7 00        ; "Revived"
 0D:9F8C: 8C B8 B5 A8 A7 00              ; "Cured"
 0D:9F92: A0 B2 AE A8 FF B8 B3 00        ; "Woke up"
 0D:9F9A: 8E B1 AF A4 B5 AA A8 A7 00     ; "Enlarged"
 0D:9FA3: 8D A8 A4 A7 00                 ; "Dead"
 0D:9FA8: 99 A8 B7 B5 FF 00              ; "Petr "
Modified:
 0D:9F84: 99 B2 AC B6 B2 B1 A8 A7 00     ; "Poisoned"
 0D:9F8D: 99 A4 B5 A4 AF BC BD A8 A7 00  ; "Paralyzed"
 0D:9F97: 00 00 00                       ; ""
 0D:9F9A: 99 A8 B7 B5 AC A9 AC A8 A7 00  ; "Petrified"
 0D:9FA4: 8D A8 A4 A7 00                 ; "Dead"
 0D:9FA9: 99 A8 B7 B5 00                 ; "Petr"

Pointer to string "Dead"
Original:
 0C:822C: A3 5F
Modified:
 0C:822C: A4 5F

Pointer to string "Petr "
Original:
 0C:822E: A8 5F
Modified:
 0C:822E: A9 5F

==================================================

Deciding whether to draw message for status effect from physical attack

Original:
 1A:91D4: AD D9 78  LDA $78D9      ; Load status effect I.D.
 1A:91D7: C9 FF     CMP #$FF       ; If status effect I.D. is invalid,
 1A:91D9: F0 20     BEQ $91FB      ; Skip message
Modified:
 1A:91D4: A5 8C     LDA $008C      ; Load indicator of target (will equal C0 if ally)
 1A:91D7: 4C E7 94  JMP $94E7      ; Jump to code injection at 94E7
 1A:91DA: EA        NOP

Original:
 ; Erase the "target" window
 1A:94E7: AE EE 78  LDX $78EE
 1A:94EA: BD DA 78  LDA $78DA,X
 1A:94ED: C9 FF     CMP #$FF
 1A:94EF: D0 03     BNE $94F4
 1A:94F1: 4C D6 94  JMP $94D6
 1A:94F4: AD D5 78  LDA $78D5
 1A:94F7: D0 0A     BNE $9503
 1A:94F9: 38        SEC
 1A:94FA: A5 64     LDA $0064
 1A:94FC: E9 04     SBC #$04
 1A:94FE: 85 64     STA $0064
 1A:9500: 4C 51 90  JMP $9051
 1A:9503: 38        SEC
 1A:9504: A5 64     LDA $0064
 1A:9506: E9 05     SBC #$05
 1A:9508: 85 64     STA $0064
 1A:950A: 4C 51 90  JMP $9051
Modified:
 ; New subroutine
 1A:94E7: C9 C0     CMP #$C0     ; Is previously loaded target I.D. an ally?
 1A:94E9: F0 0F     BEQ $94FA    ; Branch if ally
 1A:94EB: AD D9 78  LDA $78D9    ; Load status effect I.D.
 1A:94EE: C9 07     CMP #$07     ; Is it petr?
 1A:94F0: F0 0D     BEQ $94FF    ; Branch if petr
 1A:94F2: C9 0C     CMP #$0C     ; Is it para?
 1A:94F4: F0 07     BEQ $94FD    ; Branch if para
 1A:94F6: E9 13     SBC #$13     ; A=0 if pois -> new I.D. for "Poisoned"
 1A:94F8: F0 05     BEQ $94FF    ; Branch if poison
 1A:94FA: 4C FB 91  JMP $91FB    ; Skip message
 1A:94FD: A9 03     LDA #$03     ; Load new I.D. for "Paralyzed"
 1A:94FF: 48        PHA          ; Push accumulator
 1A:9500: AE EE 78  LDX $78EE    ; Load offset for long message I.D.
 1A:9503: A9 FF     LDA #$FF     ; Load invalid I.D. for long message
 1A:9505: 9D DA 78  STA $78DA,X  ; Store invalid I.D. to skip any long messages
 1A:9508: 68        PLA          ; Pull accumulator
 1A:9509: 4C DB 91  JMP $91DB    ; Jump to code for displaying status message
 1A:950C: EA        NOP

==================================================

Message window positions

Original (discontinuous):
 1A:8E83: 61 22     ; drawing actor window
 1A:8E88: C1 22     ; erasing actor window
 1A:8E8C: 6C 22     ; drawing ability window
 1A:8E91: CC 22     ; erasing ability window, and now status alert window
 1A:8E9E: CC 22     ; drawing status alert window
 1A:8EA7: 21 23     ; drawing long message window
 1A:8EAC: 81 23     ; erasing long message window
Modified (discontinuous)
 1A:8E83: 67 22     ; drawing actor window
 1A:8E88: C7 22     ; erasing actor window
 1A:8E8C: CA 22     ; drawing ability window
 1A:8E91: 2A 23     ; erasing ability window, and now status alert window
 1A:8E9E: CA 22     ; drawing status alert window
 1A:8EA7: C4 22     ; drawing long message window
 1A:8EAC: 24 23     ; erasing long message window

==================================================

Damage numeral color

Original:
 00:92BE: 25        ; red
Modified:
 00:92BE: 30        ; white

==================================================

Canceling target selection for magic
Original:
 1A:B8CE: 4C EE B8  JMP $B8EE      ; go to drawing top menu
Modified:
 1A:B8CE: 4C 46 B6  JMP $B646      ; go to drawing magic menu

Clearing all windows before drawing magic menu:
Original:
 1A:B793: 20 B0 8E  JSR $8EB0      ; clear all windows
Modified:
 1A:B793: EA        NOP
 1A:B794: EA        NOP
 1A:B795: EA        NOP

Canceling target selection for items
Original:
 1A:B5C1: C6 52     DEC $0052      ; decrease character I.D. value
 1A:B5C3: 4C B0 B1  JMP $B1B0      ; go to drawing top menu
Modified:
 1A:B5C1: EA        NOP
 1A:B5C2: EA        NOP
 1A:B5C3: 4C AF AD  JMP $ADAF      ; go to drawing item menu

Clearing all windows before targeting with restorative items/magic
Original:
 1A:B9B9: 20 B0 8E  JSR $8EB0      ; clear all windows
Modified:
 1A:B9B9: 20 88 91  JSR $9188      ; jump to new subroutine $9188 (see above)

Advance frame after clearing all windows, before drawing item menu
Original:
 1A:ADBD: 20 C5 F8  JSR $F8C5      ; jump to subroutine updating screen
Modified:
 1A:ADBD: 20 C6 91  JSR $91C6      ; jump to new subroutine $91C6 (see above)

==================================================

Row change command access

Right-arrow command
Original:
 1A:999C: D0 08     BNE $99A6      ; branch if second button press
Modified:
 1A:999C: F0 08     BEQ $99A6      ; branch if right button first press

Left-arrow command
Original:
 1A:997B: D0 08     BNE $9985      ; branch if second button press
Modified:
 1A:997B: F0 08     BEQ $9985      ; branch if left button first press

________________________________________________________________________________

  4. REVISION HISTORY
________________________________________________________________________________


2016-03-01 - Version 1.0 released

2016-04-17 - Version 1.1 released
 - Increased speed of end-of-battle messages

2016-04-25 - Version 1.2 released
 - Improved implementation of version 1.1 change

2016-05-28 - Version 1.3 released
 - New features: item/magic menu changes, row commands

2016-07-04 - Version 1.4 released:
 - Improved message inclusion/exclusion, including:
    > Terrain ability names
    > Libra
    > status effects
 - "Petr " message now reads "Petrified"
 - Fixed bug in paralysis & sleep recovery animation
 - Fixed bug which prevented enemies from fleeing

2016-07-08 - Version 1.41 released
 - "Absorbed!" message now excluded

2016-07-22 - Version 1.42 released
 - "HP Absorbed!" and "HP Drained!" now excluded

2016-07-24 - Version 1.43 released
 - Minor item menu bug fixed, style changes scaled back

2016-08-17 - Version 1.44 released
 - Improved suppression of status effect messages triggered by physical attacks

2016-12-27 - Version 1.45 released
 - Restored status effect messages for paralysis and poison when triggered by
   physical attack on an enemy

2016-12-31 - Version 1.46 released
 - Suppressd "Critical Hit!", another "HP Drained!", and a few rare overlapping
   messages

2017-05-19 - Version 1.5 released
 - Fixed brief graphics glitch when two status ailments are inflicted by a
   single physical attack
 - Optimizations
 - Fixed enemy list being lost during Cannon Blast

2022-05-28 - Version 1.6 released
 - Fixed bug causing Dragoon not to come back down after jumping
 - Status-afflicted sprites for Ranger, Dark Knight, and Sage restored to
   original orientation (previous patch versions flipped them horizontally)
 - Removed inner shadow from FF4-style windows for field sprite compatibility


Thanks to Binarynova for the helpful feedback.

________________________________________________________________________________

  5. LEGAL
________________________________________________________________________________


Copyright (C) 2016, 2017, 2022 David R. Thompson (SilentEnigma).

The copyright holder ("author") permits the free use of the attributed work
referenced by this document exclusively for non-commercial purposes, provided
that the following conditions are met:
1. The author and all contributors credited in this readme document shall be
 given credit for their respective contributions wherever the attributed work is
 reused, redistributed, or modified.
2. This readme document shall accompany any of the files comprising the
 attributed work wherever they are redistributed in unmodified form.

The work(s) and file(s) distributed with this document are provided "AS-IS",
WITHOUT ANY WARRANTY. The author shall not be held responsible for any damages
related to the use of work(s) and file(s) distributed with this document.
