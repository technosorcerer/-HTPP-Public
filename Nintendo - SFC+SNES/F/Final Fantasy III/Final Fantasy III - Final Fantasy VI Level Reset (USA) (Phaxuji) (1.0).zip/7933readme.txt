                       ############################
                      /                            \
                     #      'FINAL FANTASY VI'      #
                     #                              #
                     #       ~~LEVEL RESET~~        #
                      \           v1.0             /
                       ############################



+-----------------+                                        +-------------+
|TABLE OF CONTENTS|                                        |SUMMARY      |
+-----------------+----------------------------------------+-------------+
|a01. PATCHING INSTRUCTIONS                                |PATCHING     |
+----------------------------------------------------------+-------------+
|b02. HOW TO USE                                           |PATCH USE    |
+----------------------------------------------------------+-------------+
|c03. RECOGNITION AND SALUTATIONS                          |THANKS       |
+----------------------------------------------------------+-------------+
|d04. PURPOSE OF MODIFICATION                              |EXPLANATION  |
+----------------------------------------------------------+-------------+
|e05. UNFINISHED BUSINESS                                  |FUTURE       |
+----------------------------------------------------------+-------------+
==========================================================================
+------------------------------------------------------------------------+
|a01. PATCHING INSTRUCTIONS                                              |
|                                                                        |
|1. Acquire a clean unheadered American release of the Final Fantasy VI  |
|   ROM for the SNES.                                                    |
|     We used "Final Fantasy III v1.1" as a base;                        |
|       For those who are unaware, Final Fantasy VI was released in the  |
|       US as "Final Fantasy III", hence the name discrepancy.           |
|2. Acquire an SNES emulator.                                            |
|     We tested this modification on both SNES 9x and Mesen;             |
|3. Download an IPS patching program.                                    |
|     We used LunarIPS;                                                  |
|4. Run LunarIPS and apply the patch included with this file on the      |
|   Final Fantasy VI ROM that you acquired in step 1.                    |
|5. Run the ROM with your favorite emulator or use real hardware.        |
+------------------------------------------------------------------------+
==========================================================================
+------------------------------------------------------------------------+
|b02. HOW TO USE                                                         |
|                                                                        |
|When in the status screen of any character in Final Fantasy VI, simply  |
|press LEFT on the D-PAD, START and the X-button simultaneously.  Doing  |
|so will reset that character's level to 1.                              |
|                                                                        |
|You do not need to press all three buttons at the exact same time with  |
|one single press.  Since pressing any of those buttons in the status    |
|screen does nothing at all, you can hold one button down while you then |
|navigate to press the other two.                                        |
|                                                                        |
|Be cautious when doing this!  When a character's level is reset, it     |
|cannot be undone.  Furthermore, there is no prompt to confirm any level |
|reset.  Once those three buttons are simultaneously registered in the   |
|status screen, the relevant character WILL revert to level 1.  Use at   |
|your own risk.                                                          |
==========================================================================
+------------------------------------------------------------------------+
|c03. RECOGNITION AND SALUTATIONS                                        |
|                                                                        |
|This modification was authored by FatRatKnight.                         |
|This readme was written by Phandiji.                                    |
+------------------------------------------------------------------------+
==========================================================================
|d04. PURPOSE OF MODIFICATION                                            |
|                                                                        |
|Final Fantasy VI is one of the most targeted video games for hacking -- |
|and otherwise modification -- purposes, especially as it pertains to    |
|the Super Nintendo.  It came to our attention, however, that there      |
|appears to be a great deal of consternation wherever Espers are         |
|concerned.  Everyone seems to have an opinion as to their effect on     |
|character growth upon gaining a level.                                  |
|                                                                        |
|Many of those who have offered their own modification have removed it   |
|entirely from the game, while others have kept it but tried to alter    |
|how it works.  Regardless, it does seem to be a point of contention.    |
|                                                                        |
|The source of this contention appears to be related to players feeling  |
|cheated out of the statistic growth of their characters.  If a          |
|character gains levels too early, they miss out on the greater gains    |
|realized by Espers obtained later into the game.  This fact has led     |
|players to forcing a 'low-level game' whereby they intentionally keep   |
|their character levels as low as possible to facilitate greater growth  |
|later on.                                                               |
|                                                                        |
|Thus, this modification originated with the notion that the simplest    |
|method for solving this issue would be to allow for players to reset    |
|the levels of their characters back to 1 whenever they deemed           |
|necessary.  Players could then increase their character's levels to     |
|whatever they felt like without worrying about potentially losing       |
|out on greater statistic realizations.                                  |
|                                                                        |
|We hope this helps those who love Final Fantasy VI to enjoy it moreso.  |
+------------------------------------------------------------------------+
==========================================================================
+------------------------------------------------------------------------+
|e05. UNFINISHED BUSINESS                                                |
|                                                                        |
|Obviously, we did not include a graphical user interface (GUI), nor a   |
|prompt of any kind.  This is due to time constraints and necessary      |
|effort.  If anyone wishes to use this modification to create their own  |
|and incorporate a GUI, they are more than welcome to.                   |
|                                                                        |
|Futhermore, this modification can be included and used with any other   |
|modifications.  No guarantees are implied as to its effectiveness.      |
|This modification has not been tested with any other.  Authors of their |
|own modifications may feel free to use this one as they see fit.  No    |
|credit is necessary.                                                    |
+------------------------------------------------------------------------+

