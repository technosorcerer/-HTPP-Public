Title: Status Icon Overflow
Author: SilentEnigma
Version: 1.2
Release Date: 2023-10-09
Applies to: Final Fantasy III (v1.0) (U)
            Final Fantasy III (v1.1) (U)
            Final Fantasy VI (J)

Archive Contents
-------------------------------

  readme.txt                       = this file

  StatusIconOverflow_J_H.ips       = patch for headered FF6j ROMs
  StatusIconOverflow_J_H_Anti.ips  = anti-patch for headered FF6j ROMs

  StatusIconOverflow_J_NH.ips      = patch for unheadered FF6j ROMs
  StatusIconOverflow_J_NH_Anti.ips = anti-patch for unheadered FF6j ROMs

  StatusIconOverflow_U_H.ips       = patch for headered FF3us ROMs
  StatusIconOverflow_U_H_Anti.ips  = anti-patch for headered FF3us ROMs

  StatusIconOverflow_U_NH.ips      = patch for unheadered FF3us ROMs
  StatusIconOverflow_U_NH_Anti.ips = anti-patch for unheadered FF3us ROMs


ROM Addresses
-------------------------------

FF3us (SNES): C3/29B2 - C3/29B4, C3/4D27 - C3/4D39, C3/4EE5 - C3/4EF5

FF6j (SFC):   C3/2A4D - C3/2A4F, C3/53E7 - C3/53F9, C3/55B4 - C3/55C4


Urgency
-------------------------------
Medium. The full effect of this bug is a frozen game, which some might argue
reduces player enjoyment. On the other hand, the bug seems to have gone
undiscovered for over a quarter century; it is not wreaking any *actual* havoc
on any *actual* players. No, the real inconvenience here is the knowledge that
the bug exists. In that vein, this patch is both the disease and the cure.


TABLE OF CONTENTS
-------------------------------

0. Description
1. Relevant Offsets & Disassembly
2. Credits
3. Revision History
4. Legal

________________________________________________________________________________

  0. DESCRIPTION
________________________________________________________________________________


In FF3us/FF6j for SNES/SFC, there is a memory bug with displaying status effect
icons on the Skills page in the field menu. Every time the player navigates to
the top-level menu on the Skills page, the game renders or re-renders any
applicable status effect icons for the selected character. A new instance of the
icons is created whether or not the icons are already being displayed.

This behavior results in the following glitch & lockup scenario:

 1) Inflict a character with a status effect such that a status icon appears on
    the field menu

 2) Open the character's Skills menu

 3) Navigate back and forth between the Skills menu and an ability list (Espers,
    Magic, etc.)

     > After about 16 repetitions, the portrait graphics will become corrupt

     > After about 38 repetitions, the menu will lock up

    It takes fewer repetitions for the glitch to appear if the character has
    more than one status effect.

This patch resolves the bug by skipping over the status effect icon display code
whenever the player is navigating back to the main Skills menu from an ability
list.

(For the savvy: The lockup occurs due to the game getting stuck on the
infinitely-looping branch instruction at HiROM address C3/11AD in FF3us, or
C3/1218 in FF6j.)

________________________________________________________________________________

  1. RELEVANT OFFSETS & DISASSEMBLY
________________________________________________________________________________

Contents:

a. Final Fantasy III (U/SNES)
b. Final Fantasy VI (J/SFC)

==================================================
 a. FINAL FANTASY III (U/SNES)
==================================================

; executed when returning to Skills menu from ability list
Original
 C3/29B2: 20 27 4D    JSR $4D27
Modified:
 C3/29B2: 20 F0 4E    JSR $4EF0    ; new alt entry point - skip icon display

Original:
 C3/4D27: 20 15 6A    JSR $6A15    ; clears data incl. ability list & main menu
 C3/4D2A: 20 19 6A    JSR $6A19    ; clears data incl. class name
 C3/4D2D: A9 24       LDA #$24
 C3/4D2F: 85 29       STA $29
 C3/4D31: A2 81 5C    LDX #$5C81
 C3/4D34  A0 06 00    LDY #$0006
 C3/4D37: 20 BA 69    JSR $69BA    ; uses value written to $29
Modified:
 C3/4D27: 20 19 6A    JSR $6A19    ; moved original C3/4D2A
 C3/4D2A: A9 24       LDA #$24     ; moved original C3/4D2D
 C3/4D2C: 85 29       STA $29      ; moved original C3/4D2F
 C3/4D2E: A2 81 5C    LDX #$5C81   ; moved original C3/4D31
 C3/4D31  A0 06 00    LDY #$0006   ; moved original C3/4D34
 C3/4D34: 20 BA 69    JSR $69BA    ; moved original C3/4D37
 C3/4D37: 20 DD 4E    JSR $4EDD    ; moved original C3/4EE5

Original:
 C3/4EE5: 20 DD 4E    JSR $4EDD    ; Set Y to character's formation ID
 C3/4EE8: 84 67       STY $67
 C3/4EEA: 4C ED 4E    JMP $4EED    ; 3 pointless bytes
 C3/4EED: A0 DD 42    LDY #$42DD   ; position of class name in Skills menu
 C3/4EF0: A2 50 4F    LDX #$4F50
 C3/4EF3: 20 27 34    JSR $3427    ; Check status & display status icon
Modified:
 C3/4EE5: 84 67       STY $67      ; moved original C3/4EE8
 C3/4EE7: A0 DD 42    LDY #$42DD   ; moved original C3/4EED
 C3/4EEA: A2 50 4F    LDX #$4F50   ; moved original C3/4EF0
 C3/4EED: 20 27 34    JSR $3427    ; moved original C3/4EF3
 C3/4EF0: 20 15 6A    JSR $6A15    ; moved original C3/4D27, new alt entry
 C3/4EF3: 20 A4 34    JSR $34A4    ; store #$20 (white) in $29 (text color)
 

==================================================
 b. FINAL FANTASY VI (J/SFC)
==================================================

; executed when returning to Skills menu from ability list
Original:
 C3/2A4D: 20 E7 53    JSR $53E7
Modified:
 C3/2A4D: 20 BF 55    JSR $55BF    ; new alt entry point - skip icon display

Original:
 C3/53E7: 20 A9 71    JSR $71A9    ; clears data incl. ability list & main menu
 C3/53EA: 20 AD 71    JSR $71AD    ; clears data incl. class name
 C3/53ED: A9 24       LDA #$24
 C3/53EF: 85 29       STA $29
 C3/53F1: A2 D6 62    LDX #$62D6
 C3/53F4: A0 06 00    LDY #$0006
 C3/53F7: 20 2C 71    JSR $712C    ; uses value written to $29
Modified:
 C3/53E7: 20 AD 71    JSR $71AD    ; clears menu data
 C3/53EA: A9 24       LDA #$24
 C3/53EC: 85 29       STA $29
 C3/53EE: A2 D6 62    LDX #$62D6
 C3/53F1: A0 06 00    LDY #$0006
 C3/53F4: 20 2C 71    JSR $712C    ; uses value written to $29
 C3/53F7: 20 AC 55    JSR $55AC    ; Set Y to character's formation ID

Original:
 C3/55B4: 20 AC 55    JSR $55AC    ; Set Y to character's formation ID
 C3/55B7: 84 67       STY $67
 C3/55B9: 4C BC 55    JMP $55BC    ; 3 pointless bytes
 C3/55BC: A0 DB 42    LDY #$42DB   ; position of class name in Skills menu
 C3/55BF: A2 48 47    LDX #$4748
 C3/55C2: 20 C2 34    JSR $34C2    ; Check status & display status icon
Modified:
 C3/55B4: 84 67       STY $67      ; moved original C3/55B7
 C3/55B6: A0 DB 42    LDY #$42DB   ; moved original C3/55BC
 C3/55B9: A2 48 47    LDX #$4748   ; moved original C3/55BF
 C3/55BC: 20 C2 34    JSR $34C2    ; moved original C3/55C2
 C3/55BF: 20 A9 71    JSR $71A9    ; moved original C3/53E7, alt entry point
 C3/55C2: 20 3F 35    JSR $353F    ; store #$20 (white) in $29 (text color)

________________________________________________________________________________

  2. CREDITS
________________________________________________________________________________


Special Thanks:

  Imzogelmo, for his disassembly of bank C3
  http://www.angelfire.com/al2/imzogelmo/patches.html

  Gi Nattak, for reporting bugs in v1.0 & v1.1.

________________________________________________________________________________

  3. REVISION HISTORY
________________________________________________________________________________


2022-04-21 : Version 1.0 released

2022-04-23 : Version 1.1 released
 - Fixed miscolored HP/MP/level values on Skills screen

2023-10-09 : Version 1.2 released
 - Fixed additional instances of miscolored HP/MP/level values on Skills screen

________________________________________________________________________________

  4. LEGAL
________________________________________________________________________________


Copyright (C) 2022, 2023 David R. Thompson (SilentEnigma).

The copyright holder ("author") permits the free use of the attributed work
referenced by this document exclusively for non-commercial purposes, provided
that the following conditions are met:
1. The author and all contributors credited in this readme document shall be
 given credit for their respective contributions wherever the attributed work is
 reused, redistributed, or modified.
2. This readme document shall accompany any of the files comprising the
 attributed work wherever they are redistributed in unmodified form.

The work(s) and file(s) distributed with this document are provided "AS-IS",
WITHOUT ANY WARRANTY. The author shall not be held responsible for any damages
related to the use of work(s) and file(s) distributed with this document.
