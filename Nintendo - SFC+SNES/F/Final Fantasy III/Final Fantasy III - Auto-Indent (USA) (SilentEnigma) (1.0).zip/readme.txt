Title: Auto-Indent
Author: SilentEnigma
Version: 1.0
Release Date: 2020-09-07
Applies to: Final Fantasy III (v1.0) (U)

Contents:

  AutoIndent_A_H_v1.0.ips = patch for headered ROMs, "A" variant

  AutoIndent_A_NH_v1.0.ips = patch for unheadered ROMs, "A" variant
  
  AutoIndent_B_H_v1.0.ips = patch for headered ROMs, "B" variant

  AutoIndent_B_NH_v1.0.ips = patch for unheadered ROMs, "B" variant

  readme.txt = this file


ROM Addresses:

    C0/7F9B, C0/7FA1, C0/8257 - C0/8258, C0/828D - C0/8290, C0/84D9 - C0/84DA,
    C0/8564, C0/8529 - C0/852A

Free space used: 30 bytes

    C0/DA20 - C0/DA3D

RAM used: 1 byte

    Repurposed constant value in field RAM, direct page $C8


--------------------------------------------------

TABLE OF CONTENTS

0. Description
1. Relevant Offsets & Disassembly
2. Credits
3. Revision History
4. Legal

________________________________________________________________________________

  0. DESCRIPTION
________________________________________________________________________________


This hack adds an automatic indent feature for field dialog quotations in FF3us.

Any line that begins after an opening double quotation mark is indented by 4
pixels, until there is a closing double quotation mark (or until end-of-page).

This allows hackers to easily reformat field dialog captions to match the format
used by FF6's PS1-era successors. 

The hack comes in two variants:
 - AutoIndent_A: Uses the original left/right margin widths.
 - AutoIndent_B: Uses thinner left/right margins (more usable text area)

Battle dialog captions are not affected.

=======
Example
=======

> Field Dialog Script text (FF3usME export):

Wedge
[According to our source, the frozen Esper was found in a new mine shaft.]

> Caption Output
  
 Before:
  --------------------------------
 | Wedge                          |
 | "According to our source, the  |
 | frozen Esper was found in a    |
 | new mine shaft."               |
  --------------------------------

 After:
  --------------------------------
 | Wedge                          |
 | "According to our source, the  |
 |  frozen Esper was found in a   |
 |  new mine shaft."              |
  --------------------------------

________________________________________________________________________________

  1. RELEVANT OFFSETS & DISASSEMBLY
________________________________________________________________________________

Left margin size: upon entering room (first line)

Original:
 C0/7F9A: A9 04       LDA #$04
Modified (Variant B only):
 C0/7F9A: A9 00       LDA #$00

--------------------------------------------------

Left margin size: upon entering room (location name caption); also end of page

Original:
 C0/8563: A9 04       LDA #$04
Modified (Variant B only):
 C0/8563: A9 00       LDA #$00

--------------------------------------------------

Loading value to store at $C8

Original:
 C0/7FA0: A9 E0       LDA #$E0      ; max line width (constant)
Modified (Variant A):
 C0/7FA0: A9 04       LDA #$04      ; left margin size for new line
Modified (Variant B):
 C0/7FA0: A9 00       LDA #$00      ; left margin size for new line

--------------------------------------------------

Checking right margin position

Original:
 C0/8257: C5 C8       CMP $C8       ; right margin position (constant)
Modified (Variant A):
 C0/8257: C9 E0       CMP #$E0      ; right margin position (original)
Modified (Variant B):
 C0/8257: C9 E1       CMP #$E1      ; right margin position

Original:
 C0/84D9: C5 C8       CMP $C8       ; right margin position (constant)
Modified (Variant A):
 C0/84D9: C9 E0       CMP #$E0      ; right margin position (original)
Modified (Variant B):
 C0/84D9: C9 E1       CMP #$E1      ; right margin position

--------------------------------------------------

Replace "new line" margin assignment with variable value:

Original:
 C0/8529: A9 04       LDA #$04      ; left margin size
Modified:
 C0/8529: A5 C8       LDA $C8       ; variable margin size

--------------------------------------------------

New subroutine when checking character read from script

Original:
 C0/828D: 85 BE       STA $BE
 C0/828F: A5 BD       LDA $BD
Modified:
 C0/828D: 20 20 DA    JSR $DA20     ; New subroutine C0/DA20
 C0/8290: EA          NOP

New Subroutine C0/DA20 (Variant A):
 C0/DA20: 85 BE       STA $BE       ; originally at C0/828D
 C0/DA22: A5 BD       LDA $BD       ; originally at C0/828F
 C0/DA24: 48          PHA
 C0/DA25: F0 10       BEQ $DA37     ; <EOC>
 C0/DA27: C9 13       CMP #$13      ; <EOP>
 C0/DA29: F0 0C       BEQ $DA37     ;
 C0/DA2B: C9 62       CMP #$62      ; closing double quotes
 C0/DA2D: F0 08       BEQ $DA37
 C0/DA2F: C9 73       CMP #$73      ; opening double quotes
 C0/DA31: D0 08       BNE $DA3B     ;
 C0/DA33: A9 08       LDA #$08      ; margin with indent
 C0/DA35: 80 02       BRA $DA39
 C0/DA37: A9 04       LDA #$04      ; default margin
 C0/DA39: 85 C8       STA $C8       ; unused RAM byte
 C0/DA3B: 68          PLA
 C0/DA3C: 60          RTS

New Subroutine C0/DA20 (Variant B):
 C0/DA20: 85 BE       STA $BE       ; originally at C0/828D
 C0/DA22: A5 BD       LDA $BD       ; originally at C0/828F
 C0/DA24: 48          PHA
 C0/DA25: F0 10       BEQ $DA37     ; <EOC>
 C0/DA27: C9 13       CMP #$13      ; <EOP>
 C0/DA29: F0 0C       BEQ $DA37     ;
 C0/DA2B: C9 62       CMP #$62      ; closing double quotes
 C0/DA2D: F0 08       BEQ $DA37
 C0/DA2F: C9 73       CMP #$73      ; opening double quotes
 C0/DA31: D0 08       BNE $DA3B     ;
 C0/DA33: A9 04       LDA #$04      ; margin with indent
 C0/DA35: 80 02       BRA $DA39
 C0/DA37: A9 00       LDA #$00      ; default margin
 C0/DA39: 85 C8       STA $C8       ; unused RAM byte
 C0/DA3B: 68          PLA
 C0/DA3C: 60          RTS

________________________________________________________________________________

  2. CREDITS
________________________________________________________________________________

Thanks to:

  Imzogelmo, for his disassembly of bank C0.
  http://www.angelfire.com/al2/imzogelmo/patches.html

  Lord J et al., for the FF3usME utility.
  http://www.angelfire.com/pq/jumparound/

________________________________________________________________________________

  3. REVISION HISTORY
________________________________________________________________________________


2020-09-07 : Version 1.0 released.

________________________________________________________________________________

  4. LEGAL
________________________________________________________________________________


Copyright (C) 2020 David R. Thompson (SilentEnigma).

The copyright holder ("author") permits the free use of the attributed work
referenced by this document exclusively for non-commercial purposes, provided
that the following conditions are met:
1. The author and all contributors credited in this readme document shall be
 given credit for their respective contributions wherever the attributed work is
 reused, redistributed, or modified.
2. This readme document shall accompany any of the files comprising the
 attributed work wherever they are redistributed in unmodified form.

The work(s) and file(s) distributed with this document are provided "AS-IS",
WITHOUT ANY WARRANTY. The author shall not be held responsible for any damages
related to the use of work(s) and file(s) distributed with this document.
