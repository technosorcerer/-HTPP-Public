Title: Optional Continue
Author: SilentEnigma
Version: 1.1
Release Date: 2021-10-24
Applies to: Final Fantasy III (v1.0) (U)

Archive Contents:

    OptionalContinue_Full_H.ips = full patch for headered ROMs

    OptionalContinue_Full_NH.ips = full patch for unheadered ROMs

    OptionalContinue_Base_H.ips = base patch for headered ROMs

    OptionalContinue_Base_NH.ips = base patch for unheadered ROMs

    OptionalContinue_Base-CV_H.ips = base patch for headered ROMs, compatible
                                     w/ C. V. Bug-Fix Compilation v1.16 - v1.25

    OptionalContinue_Base-CV_NH.ips = base patch for unheadered ROMs, compatible
                                      w/ C. V. Bug-Fix Compilation v1.16 - v1.25

    readme.txt = this file


ROM Addresses:    

    "Full" variant:
      C0/9926 - C0/9929
      C0/C504 - C0/C505
      CC/E5D8 - CC/E5ED
      CC/E600
      CC/E6FA - CC/FE18
      CD/166F - CE/F0FF
      EF/4A46 - EF/9D16

    "Base" variant:
      C0/9926 - C0/9929
      C0/C504 - C0/C505
      CC/E5D8 - CC/E5ED

    "Base-CV" variant:
      C0/9926 - C0/9929
      C0/C504 - C0/C505
      CC/E5BA - CC/E5E2


Free space used:

    C0/D720 - C0/D73E (31 bytes)
    C3/FB3D - C3/FB7C (64 bytes)

    CC/E5EE - CC/E5FF ("Base" & "Full" variants only) (18 bytes)


NOTE: 

    This mod shares code with the author's "Soft Reset" patch v1.1.

________________________________________________________________________________

TABLE OF CONTENTS

0. Description
1. Relevant Offsets & Disassembly
2. Revision History
3. Credits
4. Legal
________________________________________________________________________________

  0. DESCRIPTION
________________________________________________________________________________


Contents:

a. General Description
b. Instructions for "Base" & "Base-CV"

========================================
 a. General Description
========================================

Optional Continue is a quality-of-life mod for FF3/6 SNES which allows the
player to quit the game after the party is defeated.

The player is given a two-choice prompt following the "defeated" animation.
Selecting the first choice causes the game to proceed normally; selecting the
second choice triggers a return to the title sequence.

Three variants of this mod are available:

 1. "Full": Applies the Optional Continue feature to an unmodified FF3us ROM.
     The player is now given a "Continue? Yes/No" prompt following the
    "defeated" animation. Selecting "No" triggers a return to the title
    sequence.

 2. "Base": Applies a partial implementation of the feature. Includes the new
    code modifications, but excludes the required dialog caption change.

 3. The "Base-CV": Similar to the "Base" variant, adapted for compatibility with
    C. V. Reynolds' Bug-Fix Compilation v1.16. Includes the new code
    modifications, but excludes the required dialog caption change.

The "Full" variant modifies the field dialog script and is thus incompatible
with many FF3 hacks which also modify the field dialog script.

The "Base" and "Base-CV" are available in order to avoid dialog script
conflicts; however, additional steps are required to complete the feature once
the base patch is applied. (See the next subsection for instructions.)

Patches for both headered and non-headered ROMs are included.


========================================
 b. Instructions for "Base" & "Base-CV"
========================================

Instructions for applying the "Base" and "Base-CV" variants:

 0. It is always recommended that you make a backup of your FF3us ROM.
 1. Select the appropriate patch variant for your FF3us ROM:
   a. If the event script has not been modified, use "Base".
   b. If the event script data is aligned to the C. V. Bug-Fix
      compilation v1.16, use "Base-CV".
   c. If the last event in your ROM's event script data begins at HiROM address
      CC/E5BA, and no other data occupies addresses CC/E5BA - CC/E5E2, use
      "Base-CV".
   d. If none of the above apply, further modification may be necessary before
      the patch can be applied. See "Relevant Offsets & Disassembly" for
      implementation details.
 2. Apply the appropriate patch to your FF3 ROM.
 3. Manually edit caption #483 to include a two-choice prompt.
    The FF3usME editor is recommended for completing this task.
    https://www.romhacking.net/utilities/86/
    The following is an example caption (FF3usME export format):

\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
[caption #483]
<D50><OP$12><EOP>
               Continue?
                 <C> Yes
                 <C> No
\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\


________________________________________________________________________________

  1. RELEVANT OFFSETS & DISASSEMBLY
________________________________________________________________________________

Contents:

a. Common
b. "Full" Variant Only
c. "Full" & "Base" Variants
d. "Base-CV" Variant Only

========================================
 a. Common
========================================

Optional Continue main feature

Original:
 C0/9926: 1A B9          ; Pointer to function for general action 0x66 (unused)
 C0/9928: 1A B9          ; Pointer to function for general action 0x67 (unused)
Modified:
 C0/9926: 2C D7          ; Pointer to new subroutine C0/D72C
 C0/9928: 28 D7          ; Pointer to new subroutine C0/D728

New Subroutine C0/D720 (Provide long access to C0/0525):
 C0/D720: 20 25 05    JSR 0525 
 C0/D723: 6B          RTL

New Subroutine C0/D724 (Provide long access to C0/0573):
 C0/D724: 20 73 05    JSR 0573 
 C0/D727: 6B          RTL

New Subroutine C0/D728 (Redirect to soft reset subroutine):
 C0/D728: 5C 3D FB C3 JML $C3FB3D   ; Jump into soft reset subroutine at C3/FB3D

New Subroutine C0/D72C (Store 0x1 to 7E/1E9E if game has been saved, else 0x0):
 C0/D72C: C2 20       REP #$20    ; 16-bit Accumulator
 C0/D72E: 48          PHA
 C0/D72F: AD C7 1D    LDA $1DC7   ; save count (2 bytes)
 C0/D732: F0 02       BEQ $D736   ; branch if none
 C0/D734: 7B          TDC
 C0/D735: 1A          INC A
 C0/D736: 8D 9E 1E    STA $1E9E   ; Unused event bit set if game has been saved
 C0/D739: E6 E5       INC $E5     ; Increase event script offset
 C0/D73B: 68          PLA
 C0/D73C: E2 20       SEP #20     ; 8-bit Accumulator
 C0/D73E: 60          RTS

New Subroutine C3/FB3D (Soft reset, mostly lifted from C0/0020 - C0/004C):
 C3/FB3D: E2 24       SEP #$24      ; Reset same state as when executing C0/0020
 C3/FB3F: A9 F0       LDA #$F0      ; SPC interrupt "Stop song & sound effect"
 C3/FB41: 8D 00 13    STA $1300     ; SPC command byte 0
 C3/FB44: 22 04 00 C5 JSL $C50004   ; Execute SPC command 
 C3/FB48: A2 FF 15    LDX #$15FF
 C3/FB4B: 9A          TXS           ; (made the stack point to $15FF)
 C3/FB4C: A2 00 00    LDX #$0000
 C3/FB4F: DA          PHX 
 C3/FB50: 2B          PLD           ; (made the direct page reg. hold #$0000)
 C3/FB51: 7B          TDC 
 C3/FB52: 48          PHA 
 C3/FB53: AB          PLB           ; (made the data bank reg. hold #$00)
 C3/FB54: A9 01       LDA #$01
 C3/FB56: 8D 0D 42    STA $420D     ; (Disable SlowROM???)
 C3/FB59: 9C 0B 42    STZ $420B
 C3/FB5C: 9C 0C 42    STZ $420C
 C3/FB5F: A9 8F       LDA #$8F
 C3/FB61: 8D 00 21    STA $2100
 C3/FB64: 9C 00 42    STZ $4200
 C3/FB67: 22 20 D7 C0 JSL $C0D720   ; Jump long to new subroutine C0/D720
 C3/FB6B: A2 00 00    LDX #$0000
 C3/FB6E: 86 00       STX $00
 C3/FB70: A2 FF FF    LDX #$FFFF
 C3/FB73: 86 02       STX $02
 C3/FB75: 22 24 D7 C0 JSL $C0D724   ; Jump long to new subroutine C0/D724
 C3/FB79: 5C 53 00 C0 JML $C00053   ; Continue with initialization,
                                    ;  skipping sound chip init. ($C0/004F)

----------------------------------------

Prevent a sound bug introduced by some emulators after the party is defeated in
an unsaved game

Original:
 C0/C503: 4C 00 FF   JMP $FF00  ; Jump to entry point
Modified:
 C0/C503: 4C 28 D7   JMP $D728  ; Jump to new subroutine C0/D728
 

========================================
 b. "Full" Variant Only
========================================

Dialog script modification - Field dialog caption #483

Data rewritten by FF3usME:
 CC/E600
 CC/E6FA - CC/FE18
 CD/166F - CE/F0FF
 EF/4A46 - EF/9D16

========================================
 c. "Full" & "Base" Variants
========================================

Event script modification - Game Over event

Original:
 CC/E5D8: 4B D5 C6  Caption $06D5, wait for button press (text only, bottom)
 CC/E5DB: F2 80     Fade out current song with transition time 128
 CC/E5DD: 5A 04     Fade screen at speed $04
 CC/E5DF: 5C        Pause execution until fade in or fade out is complete
 CC/E5E0: B5 06     Pause for 15 * 6 (90) units
 CC/E5E2: 42 31     Hide object $31
 CC/E5E4: 42 32     Hide object $32
 CC/E5E6: 42 33     Hide object $33
 CC/E5E8: 42 34     Hide object $34
 CC/E5EA: 45        Refresh objects
 CC/E5EB: 39        Free screen
 CC/E5EC: 4F        Exit the current location
 CC/E5ED: FE        Return
 CC/E5EE: FF FF
 CC/E5F0: FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF
Modified:
 CC/E5D8: 66           New command - new subroutine C0/D728 (process save count)
 CC/E5D9: C0 F0 00     Branch to CC/E5F7 if bit 1 of 7E/1E9E is not set
             F7 E5 02 
 CC/E5DF: 4B E4 C1     Caption $01E4, wait for button press (text only, bottom)
 CC/E5E2: B6 E9 E5 02      
             FA E5 02  Branch on user choice: CC/E5E9 (choice 1) or CC/E5FA (2)
 CC/E5E9: F2 80        Fade out current song with transition time 128
 CC/E5EB: 5A 04        Fade screen at speed $04
 CC/E5ED: 5C           Pause execution until fade in or fade out is complete
 CC/E5EE: 95           Pause for 120 units
 CC/E5EF: B2 AC 39 01  Hide objects (?)
 CC/E5F3: 45           Refresh objects
 CC/E5F4: 39           Free screen
 CC/E5F5: 4F           Exit the current location
 CC/E5F6: FE           Return
 CC/E5F7: 4B D5 C6     Caption $06D5, wait for button press (text only, bottom)
 CC/E5FA: F2 80        Fade out current song with transition time 128  
 CC/E5FC: 5A 04        Fade screen at speed $04
 CC/E5FE: 5C           Pause execution until fade in or fade out is complete
 CC/E5FF: 67           New command - new subroutine C0/D73B (soft reset)

========================================
 d. "Base-CV" Variant Only
========================================

Event script modification - Game Over event

C. V. Bug-Fix Compilation:
 CC/E5BA: 4B D5 C6     Caption $06D5, wait for button press (text only, bottom)
 CC/E5BD: F2 80        Fade out current song with transition time 128
 CC/E5BF: 5A 04        Fade screen at speed $04
 CC/E5C1: 5C           Pause execution until fade in or fade out is complete
 CC/E5C2: B5 06        Pause for 15 * 6 (90) units
 CC/E5C4: B2 AC 39 01  Hide objects (?)
 CC/E5C8: 45           Refresh objects
 CC/E5C9: 39           Free screen
 CC/E5CA: 4F           Exit the current location
 CC/E5CB: FE           Return
 CC/E5CC: 00 00 00 00
 CC/E5D0: 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00
 CC/E5E0: 00 00 00
Modified:
 CC/E5BA: 66           New command - new subroutine C0/D728 (process save count)
 CC/E5BB: C0 F0 00     Branch to CC/E5DA if bit 1 of 7E/1E9E is not set
             DA E5 02 
 CC/E5C1: 4B E4 C1     Caption $01E4, wait for button press (text only, bottom)
 CC/E5C4: B6 CB E5 02      
             DD E5 02  Branch on user choice: CC/E5CB (Yes) or CC/E5DD (No)
 CC/E5CB: F2 80        Fade out current song with transition time 128
 CC/E5CD: 5A 04        Fade screen at speed $04
 CC/E5CF: 5C           Pause execution until fade in or fade out is complete
 CC/E5D0: B5 06        Pause for 15 * 6 (90) units
 CC/E5D2: B2 AC 39 01  Hide objects (?)
 CC/E5D6: 45           Refresh objects
 CC/E5D7: 39           Free screen
 CC/E5D8: 4F           Exit the current location
 CC/E5D9: FE           Return 
 CC/E5DA: 4B D5 C6     Caption $06D5, wait for button press (text only, bottom)
 CC/E5DD: F2 80        Fade out current song with transition time 128  
 CC/E5DF: 5A 04        Fade screen at speed $04
 CC/E5E1: 5C           Pause execution until fade in or fade out is complete
 CC/E5E2: 67           New command - new subroutine C0/D73B (soft reset)
 
________________________________________________________________________________

  2. CREDITS
________________________________________________________________________________


Imzogelmo - Disassembly of bank C0 & event script
http://www.angelfire.com/al2/imzogelmo/patches.html#disassembly


LordJ - FF3usME utility
http://www.angelfire.com/pq/jumparound/

________________________________________________________________________________

  3. REVISION HISTORY
________________________________________________________________________________


2020-05-15 : Version 1.0 released.

2021-10-24 : Version 1.1 released.
 - Now compatible with Madisur's 'FF6 Music Player' hack.

________________________________________________________________________________

  4. LEGAL
________________________________________________________________________________

Copyright (C) 2020, 2021 David R. Thompson (SilentEnigma).

The copyright holder ("author") permits the free use of the attributed work
referenced by this document exclusively for non-commercial purposes, provided
that the following conditions are met:
1. The author and all contributors credited in this readme document shall be
 given credit for their respective contributions wherever the attributed work is
 reused, redistributed, or modified.
2. This readme document shall accompany any of the files comprising the
 attributed work wherever they are redistributed in unmodified form.

The work(s) and file(s) distributed with this document are provided "AS-IS",
WITHOUT ANY WARRANTY. The author shall not be held responsible for any damages
related to the use of work(s) and file(s) distributed with this document.
