Title: Cancel Button Dash
Author: SilentEnigma
Version: 1.2
Release Date: 2021-09-14
Applies to: Final Fantasy III (v1.0) (U)

Contents:

    CancelButtonDash_H.ips       = the patch for headered ROMs
    
    CancelButtonDash_H_Anti.ips  = the anti-patch for headered ROMs
    
    CancelButtonDash_NH.ips      = the patch for unheadered ROMs
    
    CancelButtonDash_NH_Anti.ips = the anti-patch for unheadered ROMs

    readme.txt = this file


ROM Addresses:

    C0/4E28 - C0/4E2C
    C0/5892 - C0/5894
    C0/5885 - C0/5887

Free space used: 107 bytes

    C0/D674 - C0/D69E
    C0/D740 - C0/D77F

________________________________________________________________________________

TABLE OF CONTENTS

0. Description
1. Relevant Offsets & Disassembly
2. Revision History
3. Credits
4. Legal
________________________________________________________________________________

  0. DESCRIPTION
________________________________________________________________________________

This patch is a fleshing-out of Master ZED's FF3 Dash button hack.
It adds the ability to dash on the field by holding down the Cancel button
(normally the B button).

The following features are inherited from Master ZED's FF3DashB:
 - The effect stacks with Sprint Shoes, similar to the PS1 version of FF6.
 - The effect is disabled during multi-party battles.

The following new features are added:
 - The author's "Sliding Dash Fix" v1.1 is included. This fixes the graphical
   glitch in FF3DashB.
 - The mapped Cancel button is used as the dash button rather than the B button.
   This patch adapts to hacks of FF3us which allow customization of the cancel
   button.
 - During timed challenges, dashing will cause the countdown timer to run down
   at twice the normal rate. This feature helps to keep the difficulty of the
   original game intact.
   
________________________________________________________________________________

  1. RELEVANT OFFSETS & DISASSEMBLY
________________________________________________________________________________


For info on the base patch, see Master Zed's FF3DashB:
https://masterzed.cavesofnarshe.com/ff3.html

--------------------------------------------------

"Sliding Dash Fix" v1.1
https://silentenigma.neocities.org/ff6/index.html

Original:
 C0/5885: 20 8D D6     JSR $D68D      ; Jump to new subroutine $D68D
Modified (Sliding Dash v1.1):
 C0/5885:  4A          LSR A          ; Shift offset value such that...
 C0/5886:  4A          LSR A          ; the least significant bit will change...
 C0/5887:  4A          LSR A          ; roughly twice in the course of one step.

Original:
 C0/5892: 20 8D D6     JSR $D68D      ; Jump to new subroutine C0/D68D
Modified (Sliding Dash v1.1):
 C0/5892:  4A          LSR A          ; Shift offset value such that...
 C0/5893:  4A          LSR A          ; the least significant bit will change... 
 C0/5894:  4A          LSR A          ; roughly twice in the course of one step.

New Subroutine C0/D68D (Sliding Dash v1.1):
 C0/D68D:  4A          LSR            ; Shift offset bits right
 C0/D68E:  4A          LSR            ; Shift offset bits right
 C0/D68F:  48          PHA            ; Push offset value to stack
 C0/D690:  B9 7F 08    LDA $087F,y    ; Load direction value
 C0/D693:  3A          DEA            ; Check if direction is Right
 C0/D694:  F0 03       BEQ $D699      ; Branch if the direction is Right
 C0/D696:  3A          DEA            ; Check if the direction is Down
 C0/D697:  D0 03       BNE $D69C      ; Branch if the direction is Down
 C0/D699:  68          PLA            ; Pull position off of stack
 C0/D69A:  1A          INC            ; Increase the offset value by 1
 C0/D68B:  48          PHA            ; Push offset value to stack
 C0/D69C:  68          PLA            ; Pull position off of stack
 C0/D69D:  4A          LSR            ; Shift position bits right
 C0/D69E:  60          RTS            ; Return from subroutine


--------------------------------------------------

Additional modifications


FF3DashB:
 C0/D677: AD 19 42    LDA $4219   ; Load 2nd byte for controller 1
Modified:
 C0/D677: 20 40 D7    JSR $D740   ; Jump to new subroutine C0/D740

New Subroutine C0/D740:
 C0/D740: A5 07       LDA $07     ; Load 2nd byte for main controller (mapped)
 C0/D742: 10 3B       BPL $D77F   ; Branch if B btn (bit #$80) not pressed/held
 C0/D744: AD 88 11    LDA $1188   ; Timer status
 C0/D747: 0A          ASL         ; Timer visible on field (bit #$40 set)?
 C0/D748: 10 33       BPL $D77D   ; If not, branch
 C0/D74A: C2 20       REP #$20    ; 16 bit accum./memory
 C0/D74C: 48          PHA         ; Preserve register B just to be safe
 C0/D74D: 5A          PHY
 C0/D74E: DA          PHX
 C0/D74F: AD DF 11    LDA $11DF   ; Offset with Sprint Shoes bit
 C0/D752: 29 20 00    AND #$0020  ; AND for Sprint Shoes bit only
 C0/D755: A8          TAY         ; Transfer sprint shoes status to Y
 C0/D756: 7B          TDC 
 C0/D757: AA          TAX
 C0/D758: BD 89 11    LDA $1189,X ; timer counter (frames)
 C0/D75B: C9 10 00    CMP #$0010  ; less than 16 frames left?
 C0/D75E: 90 0E       BCC $D76E   ; if so, skip penalty
 C0/D760: C4 00       CPY $00     ; check for sprint shoes bit in Y
 C0/D762: 38          SEC
 C0/D763: D0 03       BNE $D768   ; If sprint shoes present, branch
 C0/D765: E9 04 00    SBC #$04    ; extra penalty for dashing w/o sprint shoes
 C0/D768: E9 04 00    SBC #$04    ; penalty for dashing
 C0/D76B: 9D 89 11    STA $1189,X ; timer counter (frames)
 C0/D76E: 8A          TXA
 C0/D76F: 18          CLC
 C0/D770: 69 06 00    ADC #$0006  ; each set of timer data is 6 bytes
 C0/D773: C9 18 00    CMP #$0018  ; 4 adjacent sets of timer data
 C0/D776: D0 DF       BNE $D757   ; loop
 C0/D778: FA          PLX
 C0/D779: 7A          PLY
 C0/D77A: 68          PLA
 C0/D77B: E2 20       SEP #$20    ; 8 bit accum./memory
 C0/D77D: A5 07       LDA $07     ; Load 2nd byte for main controller (mapped)
 C0/D77F: 60          RTS

________________________________________________________________________________

  2. REVISION HISTORY
________________________________________________________________________________


2020-12-28 - Version 1.0 completed.

2021-04-25 - Version 1.1 completed.
  - Fixed a oversight that allowed Shadow's entrance queue at the end of the
    Floating Continent sequence to fall out of step with the escape timer.

2021-09-14 - Version 1.2 completed.
  - Added support for Sprint Shoes + Dash during timed challenges
  - Improved accuracy of timer penalty for dashing without Sprint Shoes
  
________________________________________________________________________________

  3. CREDITS
________________________________________________________________________________


SilentEnigma, Author
https://silentenigma.neocities.org/index.html

Special thanks to Rob "CintariZero" (@Cintari_) for reporting the bug in v1.0.

--------------------------------------------------

"FF3 Dash button hack" Credits:

  Master ZED, Author
  https://masterzed.cavesofnarshe.com/

  Duran Divine Dragon - For the indirect inspiration.

  Imzogelmo - For the free space allocation doc.
  http://www.angelfire.com/al2/imzogelmo/patches.html

--------------------------------------------------

"Sliding Dash Fix" Credits:

  MasterZED, for writing the FF3 Dash button hack.
  https://masterzed.cavesofnarshe.com/

  Imzogelmo, for his disassembly of bank C0 and for his patch allocation list.
  http://www.angelfire.com/al2/imzogelmo/patches.html

  Novalia Spirit, for compiling an excellent bugs list.
  https://www.romhacking.net/community/996/


________________________________________________________________________________

  4. LEGAL
________________________________________________________________________________

Copyright (C) 2020, 2021 David R. Thompson (SilentEnigma).

The copyright holder ("author") permits the free use of the attributed work
referenced by this document exclusively for non-commercial purposes, provided
that the following conditions are met:
1. The author and all contributors credited in this readme document shall be
 given credit for their respective contributions wherever the attributed work is
 reused, redistributed, or modified.
2. This readme document shall accompany any of the files comprising the
 attributed work wherever they are redistributed in unmodified form.

The work(s) and file(s) distributed with this document are provided "AS-IS",
WITHOUT ANY WARRANTY. The author shall not be held responsible for any damages
related to the use of work(s) and file(s) distributed with this document.

"FF3 Dash button hack" Copyright (C) 2005 Master ZED.

FINAL FANTASY is a registered trademark of Square Enix Holdings Co., Ltd.
FINAL FANTASY VI (C) 1994, 2006, 2014 SQUARE ENIX CO., LTD.

The author of the attributed work referenced by this document makes no claim to
FINAL FANTASY VI or any intellectual property contained therein.
