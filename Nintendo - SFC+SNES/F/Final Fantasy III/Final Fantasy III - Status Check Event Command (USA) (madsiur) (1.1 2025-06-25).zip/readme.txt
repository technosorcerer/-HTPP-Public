|----------------------------------------------|
| Status Check Event Command                   |
| by: madsiur                                  |
| version: 1.1                                 |
| Released on: June 25th, 2025                 |
| apply to: FF3us 1.0 (no header)              |
|----------------------------------------------|

|----------------------------------------------|
| Files                                        |
|----------------------------------------------|

status_check_event_command_nh.ips: IPS patch
status_check_event_command.asm: bass assembly file

|----------------------------------------------|
| Description                                  |
|----------------------------------------------|

This hack add the ability to check in an event if
the party leader has a certain status set.
Previously unused event command $83 can now branch
to another event offset if party leader has either
the blind, zombie, poison, magitek, vanish,
petrified, wounded or float status.

With a format of 83 FF XX YY ZZ, FF can have the
following values:

Blind       $01
Zombie      $02
Poison      $04	
Magitek     $08
Vanish      $10
Imp         $20
Petrify     $40
Wounded     $80
Float       $C0

A usage example would be 83 C0 14 49 01, in 
others word "if party leader has float, branch
to CB/4914, otherwise continue". Like others
offset references in event commands the bank
value is relative to bank $CA. Note that this
new event command can only check one status at a
time.

The default hack uses 120 bytes of free space at
$EEAF01. This free space offsets can be changed
in the bass asm file by changing the offset of
the FREE_SPACE_EX constant. The hacks four bytes
of free space in bank $C0.

To assemble the hack use bass v14 by typing
a command such as 
"bass -o rom.smc status_check_event_command.asm".

|----------------------------------------------|
| Links                                        |
|----------------------------------------------|

bass v14:
https://romhack.ing/database/content/entry/BdNw5JQBNs8FWu0CSZB5/bass

|----------------------------------------------|
| Version history                              |
|----------------------------------------------|

Version 1.1 (2025/06/25):
-Added a float check to ensure we are going to 
 check that status.
-Created bass asm file and documented code.

Version 1.0 (2012/01/27):
-Initial release.

|----------------------------------------------|
| Download pages                               |
|----------------------------------------------|

Personal website:
https://rewindcoding.dev/en/romhacking/hacks/status-check/

FF6Hacking wiki:
https://www.ff6hacking.com/wiki/doku.php?id=ff3:ff3us:patches:madsiur:status_check					

