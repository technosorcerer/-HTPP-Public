Title:  Final Fantasy VI - A Soldier's Continengcy (Extended Bestiary edition)
Platform: SNES
Original Release date: 1/23/2023
Latest patch 1.03 release date: 12/27/2023
Author: Lightning Hunter
Version:  1.03
Based on: General Leo edition v3.4 by Fedorajoe
Production time:  Over 5 years


Installation:
_________________________________________________

-First You will need either a 1.0 or 1.1 Final Fantasy III (USA) Rom. The correct ROM(s) will have the following CRC32:
Final fantasy III (USA) 1.0:  A27F1C7A
Final fantasy III (USA) 1.1:  C0FA0464
NOTE: the easiest utility to check the CRC32 is "Rom Hasher":
https://www.romhacking.net/utilities/1002/

-Once you have verified that you have one of the two above ROMs, you will need to check if they have a header or not. One way to find this out is to download
a nifty little utility called "Tush":
https://www.romhacking.net/utilities/608/

-Finally, you need a patcher utility to apply the correct .ips patch over your ROM.  I recommend "Flips":
https://www.romhacking.net/utilities/1040/

-Using your IPS patcher utility, apply one of the following patches based on which FF3 ROM you have:

Final Fantasy III (USA) 1.0 UNHEADERED: Apply "FF6_A_Soldiers_Contingency_v1.03_Unheadered_(10).ips"
Final Fantasy III (USA) 1.0 with HEADER: Apply "FF6_A_Soldiers_Contingency_v1.03_Header_(10)"
Final Fantasy III (USA) 1.1 UNHEADERED: Apply "FF6_A_Soldiers_Contingency_v1.03_Unheadered_(11).ips"
Final Fantasy III (USA) 1.1 with HEADER: Apply "FF6_A_Soldiers_Contingency_v1.03_Header_(11).ips"

-To verify your ROM has been patched correctly, check it with the ROM Hasher utility. The final patched rom should look like this:

Platform         Super NES                                                                                        
File Size   	 6291968 (600200)     
ROM Size    	 6291456 (600000)                    
ROM CRC32    	 44FB63E7                     
ROM SHA-1   	 E42F15E8843E4346C00E5A546D712F24B5A6E11B
Checksum valid   Yes
                                                                                                            
NOTE: This hack has been thoroughly tested on real hardware, and works perfectly. I personally tested it on an Sd2Snes and Super Everdrive with no issues.

NOTE #2:  This hack is actually based on a FF3 version 1.1 ROM. The 1.0 ips patch merely "upgrades" the game from 1.0 to 1.1 (although 1.1 is more of a curse to work with than 1.0, but I digress).


Description:
_________________________________________________

Around 2017, I played a wonderful hack by Fedorajoe called "General Leo Edition".  This became my go-to hack to play the game, but like most FFVI players, I became dissatisfied
with how easy the game was, how many bugs there were, and just how unbalanced the game was in general. I also felt that FFVI had a complete lack of monster diversity, especially in
the World of Ruin. Hence, my nameless hack was born! At first I merely tweaked the stats of all the monsters, items, espers, and more to create a more balanced experience - but I wasn't
satisfied by a longshot, so I started adding new monsters and graphics from other Final Fantasy games. After a few years, my goal changed from adding just a handful of imported
monsters to replacing every single repeat monster graphic in the game. Along the way, I also added 50+ new battle themes, new alt character sprites, new boss fights,
new dialog, and over 50 patches/hacks from various authors in the community to improve the overall experience.  In addition, every AI script has been re-written, and many interesting
features, equipment, spells, and more have been added. The content became so vast that I knew I couldn't just keep this hack to myself anymore.


List of features:
_________________________________________________

-Aproximately 200 new monster sprites on top of the original monsters for a total of 350 monsters
-Optional end-game Beast hunting and some new bosses
-Lots of new eqiupment, including dozens of new ultimate endgame gear
-50+ new battle themes
-New alternate characters that remain faithful to the originals while adding a degree of freshness
-The ability to recruit Leo as in the General Leo edition
-New surprise twist for Gogo and his own set of equipment
-Dozens of new spells and abilities and improved animations for existing spells
-Complete gameplay overhaul and rebalancing:
 Expect a challenge, but nothing unfair. Level grinding will NOT be necessary with good strategy.
-New equipment menu that combines relics and gear
-A surprise twist to the final Kefka fight with your party above a certain level
-All new AI scripts for more intelligent monsters:
 Many monsters become smarter as your party's level increases, while other monsters change entirely!
-50+ user-made hacks, patches, improvements, and more included
-Some new cutscenes
-Pugs instead of Imps that change color based on the character
-Some new dialog and plot twists
-All major bugs fixed, such as vanish/doom trick, psycho cyan, the infamous Gau sketch bug, and the useless evade stat along with countless others
-Ability to learn rages anywhere and to see which rages you are missing in Gau's skill menu
-Colosseum completely re-written: 
 You can now control your characters, and do not lose your items (everyone just resets the game when they lose anyway...)
-Re-written auction house to include more items and to be less annoying
-Functional Umaro, complete with his own set of equipment and a brand new skill!
-New Dash function
-Leo's Shock overhaul:
 Shock is now limited to once per battle and will randomly choose between 3 types of shock attacks.
-New "Miracle" ability for Leo
-More defined classes: 
 Only mages can now use magic/espers, while the warriors are primarily for physical attacks. Some characters are a combination of both support and attack.
NOTE: Esper's no longer grant status boosts upon leveling. This is so your mages aren't the only ones getting status boosts.
-Major rebalancing of characters: 
 All characters should have a purpose for being in your group at one point or another!
-Game-breaking attacks fixed: 
 There is no more fixed dice with offering for example - but to compensate for this you will find new ultimate weapons that are very fun to use!
-Rebalancing of physical attacking vs. magic: 
 Both your warriors and mages have a good reason to be in the party and will support each other
-Rages completely redone: 
 Stray-cat is still the best early rage for example, but quickly becomes obsolete (as it should) as you encounter tougher monsters. Gau has his ultimate endgame rages now.
-No more missable rages; a complete list is doable
-Many skill improvements:
 Faster Bushido, A smart chainsaw that knows when to go for an instant kill, and Dance that never fails (among other changes)
-New desperate attacks, including brand new desperate attacks for Umaro, Gau, and Leo.
-More frequent desperate attacks
-Countless other features. Far too many to list here, in fact!


Changelog:
_________________________________________________
1.03
-Fixed A glaring bug in which the spell "Stop" would work on ANY monster or boss, regardless of their immunity to it.
-Doubled the chances of seeing a certain rare monster in the desert near Maranda in the WoR.
-Fixed a few collision errors in the Veldt Cave (WoR) in which you could get stuck in the wall
-Fixed the dialog incorrectly stating that you obtained the esper "Titan", when in fact it is "Terrato".
-Removed the "Polarity" move from M-Tek Eagle in Cyan's Dream, since it was reported to cause characters to lose the Magitek ability while wearing M-tek armor.
-Increased the success rate of Cyan's Quadra Slice a tad
-Fixed a bug in the WoR "recruitment" scene at the Colosseum (don't want to spoil which scene I'm talking about). The wrong monster script would previously execute, causing strange behavior such as
 the dialog "Storing energy" to appear.

1.02
-Fixed Opera House bug in which the text would display over the next text if you lingered too long, which could cause the rest of the scene to not work as intended
-Moved the battle music in Umaro's Cave to Owzers mansion, and added a new battle theme to Umaro's Cave instead.
-Fixed some spell descriptions, including a jumbled "float" description and the Pug spell incorrectly stating that it toggles "Imp".
-Added a new way to gain experience eggs in Kefka's Tower (see the Guide to spoil it).
-Swapped the Bleary, Crawly, Crawly formation with Crawly, Crawly, Crawly to (hopefully) make Bleary easier to find on the Veldt
-Reduced the damage of various monsters on the Phantom train a tad so you don't burn through so many potions in that sequence
-Changed some instruments for the WoB Desert music
-Fixed an issue with the FF4 battle theme (WoB grass theme) in which too many instruments were heard more on the right side than the left side.
-Fixed a minor popping sound with the Magitek facility battle music
-Changed Rage of Leaf bunny from ShellX to Big Guard (as mentioned in the guide)

1.01
-Fixed a nasty bug in which Terra's Flashback to Kefka and the M-tek armor randomly happens on the Veldt.
-Fixed the incorrect item message that is displayed when you obtain the Genji Glove from the man inside the Returner's hideout after telling Banon "No".
-Fixed a minor item description error for an endgame item
-Toned down the Vomammoth Strength, HP, and magic damage a bit


Patches Used by Author
_________________________________________________

Fedorajoe: for General Leo edition version 3.4 in which I based my entire hack upon!

Assassin: Alphabetical Rage patch, Auto Swordless Runic fix, That Damn Yellow Streak fix, strikes-carryover-multi-fix, Genji Glove fix, Recapture the Glory, Lead-footed Esper,
	  Step Mine's missing digit fix, Control attacks ignore MP cost fix, Pincer + Row fix, Sap/death beta fix
Terii Senshi:   Evade bugfix, Vanish Bugfix, Rippler bugfix
Gi Nattak: No Coral for you, Functional Umaro, Mog Never Fails
Leet Sketcher: Imp's Retort 1.5, Blitz Screen tweak 1.2, Imp Skimp 1.4, Rock Bottom 1.3, Solar Wind 1.0
HatZen08: True Duel, Basic Offering, Wilder Randomness 4.4, Learnable Rage 2.0
Lenophis: Economizer MP tweak, Unhardcoded Tintinabar
Seibaby: World of Ruin Dance backgrounds, Muddle/Smoke Bomb fix, "Make sketch not suck" (parts of the code by Synchysi)
Madsiur: Background Battle Music Hack, Auto-Optimize hack, Antifreeze patch, Mastered Esper, Uncursed Tweak
Imzogelmo: Color-coded MP Digits patch, Multi-Steal Fix, Cursed Shield Fix (with additional fixes by Leet Sketcher)
Warrax: Fixed up 1.1 Color-Coded MP Digits Patch
PowerPanda: Scroll Animation Fix, Airship Unequip (to remove Umaro's equipment)
GrayShadows: Equipment/Relic combination menu, Leo's "once-per-battle" Shock Hack
Cdude: Imp's Mapping 1.0, Permanent Imp Relic, Banon don't wander off fix
Subtraction: Break items for any ability
Catone: Auction re-write hack
Zeemis:  Destiny Sword
SSJ Rick: Throwing Knives, Gun patch, FFT Chocobo, Scythe graphic
T.Geiger: Painful Chainsaw Hack (fixed by Warrax and Assassin).
Novalia Spirit: Rage Checklist Patch, Shadow Chupon Fix, Allergic Dog Fix
DrakeyC: Edgar's Bazooka, Less Restrictive Desperation Attacks
SilentEnigma: Docile NPCs, Alphabetical Rage Checklist Addendum, Cancel Button Dash 1.2 (based on Master ZED's dash button hack)
Master ZED: FC05 enemy command fix
Ryo_Hazuki (upped by Gens): Slim Boxes patch
B-Run: Parts of the AI-Upgrade patch (Thanks to Gi Nattak for help extracing the bits I needed)
Drakkhen: Ignore Defense Weapon



Tools Used by Author
_________________________________________________
FF3usME by Lord J - This hack would not have been started and would not exist without it!
FF3SE by Terii Senshi, SubtractionSoup - Got me through much monster editing before switching to remonsterate, and even now I use it to modify palettes!
FF3SE-M by madsiur - Allowed me to add more monster graphics once I used up all the bytes.
Remonsterate by Abyssonym - Allowed me to add even more monster graphics once I maxed out the bytes yet again with FF3SE-M.
FF6LE-CE by madsiur, originally based on FF6LE by giangurgolo.
HxD by Ma�l H�rz, for a lot of the hex editing
Windhex32 by Genecyst East Software, also for hex editing
Xkas by byuu, for asm compiling
Asar by Alcaro, also for asm compiling
Bass.exe by Near, also for asm compiling
Floating IPS by Alcaro, to compile my hack



Extra special thanks
_________________________________________________

Gi Nattak:
-For writing up a tutorial and teaching me how to play different songs for different bosses!
-For modifying the Colosseum music event so that the original music plays after recruiting Leo.
-Fixing the Relm bug introduced in the original Leo Edition, in which Relm could be recruited before the events at the Veldt Cave (creating a clone of her)
-Fixing another bug in which Relm appears where she shouldn't during the airship cutscene after the events of Thamasa
-Fixing the Atma gameover bug
-Fixing yet another bug in which Celes would sometimes appear outside the party as a clone after the events of the Opera house and Blackjack (when you first arrive at the Southern Continent).
-For Helping me get the FF6 Level Editor working with my hack in order to fix the missing atma/ultima weapon sprite and airship sprite in the floating continent.
-Help with changing the weapon throw/jump animations
-For help with giving Relm interceptor in the WOR.
-For fixing some collision errors in the new rooms of Vector.
-For fixing the Chocobo minimap "gray dot" bug present.
-For helping me insert the music change command
-For helping me disable the Kefka music that plays with the boss lowering animation for other bosses
-For permission to use a few graphics and ideas from RotDS
-For always being responsive over at Discord
-For much, much more that I haven't mentioned here!

madsiur:
-For the many, many tutorials, and for massive amount of help over at FF6Hacking!  I would not have been able to add my first song or BRR sample without him...
-For the ASM background table patch that enabled me to assign different battle themes to different locations!
-For the ASM hack reducing the amount of damage taken in the back-row by 25% instead of 50%.
-For the "No item lost at the Colosseum" ASM patch.
-For his code to replace the Possess command with a new command for Umaro (that randomly chooses between 16 spells).
-For answering countless questions over on the FF6hacking discord server!

C-Dude:
-For always being available to help on discord and for saving the day many, many times!
-For his hacks and help getting the code to work for multi-colored Imps/Pugs as well as a relic that causes permanent imp status.
-For his detailed tutorial on how to edit Weapon graphics/frames/animations - which is how I got the FF4/5 style weapons in front of the character!
-for fixing multiple bugs with remonsterate, including the Crusader summon bug.
-for the modified Atma/ultima weapon sprite for the 2nd form in Kefka's Tower.
-For help with coding the Possesss command with Umaro's new command
-For help with coding both Umaro and Gau to have a desperation attack
-For help with modifying Gogo's "Fight" command behavior and more
-For helping with code to allow weapon procs to multi-target
-For much more than I have listed here!

Casual Tom:
-For Live-Streaming my hack!
-For the very thorough beta testing that took months to complete.
-For the many, many suggestions about gameplay tweaks, improvements, and more
-For taking the time to discuss many possible features and changes to the hack on Discord
-For the coverage of my hack over on YouTube and for suggesting my hack be added to Final Fantasy IV - Ultima discord seerver (and for asking the admins on my behalf).
-For taking such an interest in my hack in general and motivating me to add many features I otherwise would not have.

T92:
-For creating the wonderful .pdf guide based on my very basic .txt version!
-For playtesting the hack

PowerPanda:
-For his valuable input in discovering the source of many bugs and his fast responses over at FF6Hacking!
-For showing me how to change the number of dragon horn jumps.
-For fixing the "scroll animation" bug and allowing Gau to use abilities like flame, blitz, and flood.
-For fixing a few bugs with the new "functional Umaro".

Subtraction:
-For his various fixes (especially with the bugs with Leo's Shock) and helpful responses over at FF6hacking.
-For his fixes to ff3se_m.exe.

Emberling:
-For teaching me how to edit, improve, and hack music to be used in my mod!
-for the mfvitools
-For spending a great amount of time troubleshooting instruments that were not working on real hardware

abyssonym:
-For the incredibly awesome Remonsterate utility.  All the unique sprites of this hack would not be possible without it!
-For his responsiveness and help getting the utility up and running for me on Discord, and for adding support for a FF3 1.1 ROM (in such a prompt manner, I might add).

GrayShadows:
-For the combined Equipment/Relic menu code and the "Once Per-battle-shock" hack!

Warrax:
-For his general responsiveness and great information over at FF6Hacking!
-For porting the Blue MP Digits hack to work on a 1.1 ROM.

Assassin:
-for his occasional help and for pointing me to his "strikes-carryover-multi-fix"

BTB: 
-For letting me use a few special effects, names, and the combined equipment/relic menu (by GrayShadows) from the "Brave New World" hack.

everything8215:
-for fixing the Shock "step forward but not back" bug.
-for setting Cdude and I in the right direction to edit the weapon frames

Serity:
-For general responsiveness and helping fix the Gaia targeting bug among a few other things.

Thanks to the beta testers:
CasualTom, T92, toys, Gens

Also thanks to these people for their responses and help over at FF6Hacking.com:
HatZen08, Cecil188, Odbarc, Tenkarider



Graphics Credits
_________________________________________________

Monster Sprites:
-A majority of the new Monster sprites were converted, enhanced, and in many cases completely redrawn by me (Lightning Hunter) from FF1 Origins (PS1), Final Fantasy Record Keeper,
FF2 Origins (PS1), Brave Exvius, and a handful of other games.
-Many alternate monster sprites were entirely done by me, including Dark Kefka, the Leader, Elite Troop, Officer, and Royal guard.
-James White aka Monsterinabox did the Bee/Hornet sprite and Flaming Skull sprite.  I mildly tweaked them.
-Cdude did the modded Atma/Ultima weapon sprite in Kefka's Tower (the second form).

Character Portraits:
Lightning Hunter (Me): The enhanced Sabin, Leo, and Siegfried portrait. The Siegfried portrait is loosely based on the Gogo portrait by Liji, but is pretty much 99% redrawn by me.
Lijj: For the Bannon, Cyan, Gau, Ghost, Gogo, Imp, Locke, Setzer, Shadow, and Vicks/Wedge portraits (all of which were also enhanced by me). 
Liji's Celes portrait was also used, but heavily modified to be the new portrait of grown-up Relm.
Smash: For the Terra and Edgar portraits (enhanced by me).
PortAlbert the Impact: For the Umaro and Strago portraits (mildly enhanced by me).
Laurel for the Pixel precision portrait set, and to Gens for converting them to FF6.  The handful of portraits used from this set were modified by me.

Character Sprites:
James White aka Monsterinabox: For the Gau sprite, Moogle sprite, and Umaro sprite - all of which have been enhanced and reworked by me.
qwertyeah: For the Locke sprite that I based my heavily modified Setzer sprite on.
NAOKI: For the Cyan Judge sprite from t-edition that I re-made into the Leo Knight sprite.
zozma: For the completed Chancellor sprite that I based the new Edgar sprite on.
Alby: For the hybrid Edgar sprite that I based the new Sabin Sprite upon.
Mickichiba: for the Grown-up Relm sprite (heavily modified by me).
Ctrlxz: For the FF5 Samurai sprite conversion (heavily modified and re-colored by me).
Cdude: For the Tonberry sprite that now replaces the Imp (recolored by me).
Kugawattan: For the Terra sprite and Esper sprite (the hair was done by Sutebenukun). Also quite a few modifications by me on this one.
Think0028 and Bauglir: For the Celes armor sprite.
Pocoloco: For the complete Siegfried sprite.
Sutebenukun: For the FF4 Tellah conversion that I loosely based the new Strago sprite on.
DarkMage: For the FF4 Cid sprite (with lots of changes by me).

Character Sprites (Pack B):
Lightning Hunter (Me): Cyan, Gogo, Strago, Locke, Sabin, and Umaro enhancements. Also the recolors of Kefka, Banon, and more.
Astaroth: For the Snow sprite that was modded into the new Locke sprite
James White aka Monsterinabox: For the Xyraa sprite (aka the "Qrols") - with minor modifcations and new death frame by me, and for the cape on the Gau sprite (re-color by me)
Royaken: For his Cloud sprite that I very loosely based my Locke sprite on (nothing really remains of the Cloud sprite).
Cdude: For the Tonberry sprite that now replaces the Imp (recolor by me).
Think0028 and Bauglir: For the Terra Leggings sprite (Shaw version).
Gens, Tsushii and the T-edition spriters for parts of the Edgar and Celes sprites (which were tweaked heavily by me).
Henry: For the original Vanille character sprite that I based the new grown-up Relm sprite upon.
Kugawattan: For the Terra Esper sprite

Item icons: 
All the new item icons were done by myself (over 50 icons) with the exception of two helmets, one armor, one shield, one Gown, and one glove icon, which wre created by the Pandora's Box Team
(thanks to Gi Nattak for permission to grab them from RotDS).

Other Sprites:
SSJ Rick: for the Chocobo Sprite/Hack, the Gun graphic, the throwing Knives graphic, the Scythe graphic (modded by me), and the converted hammer graphic.
DrakeyC: Edgar's Bazooka graphic


Music Credits
_________________________________________________

ff1_Battle_Scene_2 converted by Gi Nattak (WOR Forest)
FF4_fight_1 converted by MetroidQuest (WOB Grass)
Ff2_battle_scene_1 converted by Tsushiy (WOR Desert)
ffmq_boss_battle converted by emberling (Kefka's Tower Interior)
ffx_battle by emberling (Kefka's Tower 1 and 2)
Undertale_Bonetrousle by Gi Nattak (Ultros)
ff3_battle_1 converted by Tsushiy (WOB Forest)
FF7_battle_FF6 by emberling (Narshe WOR)
ct_battle_2 by emberling (WOB Mountains Outside)
ffmq_battle3 by emberling (Boss theme)
totr_battle by emberling (Kefka's Tower, Iron Giant area )
lufia1_boss_theme by Gi Nattak (Human Boss Theme )
Ct_battle by emberling (WOB Mountains Inside)
Lufia2_battle_theme by Gi Nattak (Floating Continent)
FF4 Boss Theme by Tsushiy (Various Bosses)
totr_sboss by emberling (Umaro's Cave )
FF4 Final Boss Theme by Gi Nattak (Various Bosses)
RSMS_prelude_of_battle by Gi Nattak (WOB Desert)
Atma Weapon Default Music with intro delay (Ultima Weapon)
FF1 Boss Battle B by Tsushiy (Various Bosses)
FF1 Boss Battle A by Tsushiy (Various Bosses)
ffmq_battle1 by Tsushiy (WOR Mountains Inside and Out)
FF2_Battle_Scene_2 by Tsushiy (Various Bosses)
TOP_Battle by emberling (Kefka's Tower Magitek Portion)
Arc_Battle by emberling (Ebot's Rock, Ancient Cave)
FF9_Battle1 by emberling (WOR Grass)
FF7_Birth_of_a_god by emberling (Boss Theme)
rs3_devil2 by emberling (Mazin, Minerva)
TOP_Fighting_of_the_Spirit by emberling (Ancient Castle and Figaro Basement)
Lufia2_Battle3 by emberling (Fanatics Tower)
TOTR_the_flame_and_the_arrow by emberling (Daryl's Tomb)
cv4_beginning by emberling (Phantom Train inside and out, Owzer's Mansion)
Sd3_Sacrifice by emberling (Steel Giant, Guardian)
jts_stage_1 by Gi Nattak (Magitek Facility)
mmx_opening_stage by Gi Nattak (Zozo Interiors)
ys3_the_boy_who_had_wings by Gi Nattak (WOR Figaro Cave, WOB Narshe beginning cave formations, WOR Veldt Cave )
ys8_iclucian_dance by emberling (WOB Figaro Cave, Narshe Mine Tracks)
top_final_act by emberling (Various Bosses)
ff8_force_your_way by emberling (Colosseum)
eo3_waves by emberling (Cave to Sealed Gate and Phoenix Cave Lava Sections)
S&N_Flying_Battery_Zone by Gi Nattak (Zozo Exterior)
nes_ivory_tower by Gi Nattak (Phoenix Cave Normal section)
TOTR_the_spirit_chaser by emberling (Adamantor, Magi Master)
FF7_jenova by emberling (End Boss, part 2, lvl 99)
FF3_Final_Battle by tsushiy (Arch-Beast)
FF3_Battle_2 by Doranarasi & J.M (Warmech)
lufia1_battle1 by emberling (WOB Narshe Secret Entrance, security checkpoint)  
ff5_battle_on_the_big_bridge4 by emberling (Omega)
FF5_the_Final_Battle by emberling (End boss, lvl 99)
ff10_fight_with_seymour by Jackimus and Gi Nattak (Rift Beast)
ff8_dont_be_afraid by emberling (Raft Ride )
MM9 Flash in the Dark by Gi Nattak (Cyan's Dream)
mm7_intro_stage by Gi Nattak (Falling down Waterfall, Magitek Test Tubes)
BoF1 - Battling converted by Gi Nattak (Umaro's Cave, various bosses)


Permissions
_________________________________________________

I don't mind if someone wants to use this hack as a base for other hacks or to borrow content, but I would prefer they message me using one of the methods below - especially
since I would like to see the project in question!


Contact
_________________________________________________

The best way to contact me in regards to this hack is over on Discord, in the "FF6 Hacking" server, or in the "Final Fantasy IV - Ultima" server. My username is Lightning #8303.  You can
also send me a private message over At the FF6Hacking forums (my username there is Lightning):
https://www.ff6hacking.com/forums/portal.php
