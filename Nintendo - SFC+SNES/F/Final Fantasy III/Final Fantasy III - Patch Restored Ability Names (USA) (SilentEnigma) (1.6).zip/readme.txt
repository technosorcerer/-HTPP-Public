Title: Restored Ability Names
Author: SilentEnigma (updates), Angelo26 (original implementation)
Version: 1.6
Release Date: 2020-10-10
Applies to: Final Fantasy III (v1.0) (U)

NOTE: These patches are for HEADERED ROMs (3146240 bytes) only!
NOTE: This patch will expand your ROM to 32Mbits.

Contents:

    RestoredAbilityNames_basic.ips = Angelo's patch with basic updates

    RestoredAbilityNames_basic-MS.ips = Same as above; apply AFTER Imzogelmo's
                                        Multi-Steal Fix
    
    RestoredAbilityNames_full.ips = Patch with full revisions

    RestoredAbilityNames_full-MS.ips = Same as above; apply AFTER Imzogelmo's
                                       Multi-Steal Fix

    readme.txt = this file

    
ROM Addresses:

    Broad, over-inclusive ranges are given here.
    See Section 2 for more precise details.

    C1/5FAD-C1/6034, C1/64F8-C1/650D, C1/65A3-C1/65C2, C1/65D0-C1/661E,
    C1/6660-C1/669B, C1/6ABE, C1/6ACC, C1/6ADC-C1/6B31, C1/8280-C1/828A,
     
    C2/ADE0-C2/AF10, C2/BB23-C2/BB68, C2/DDD6, C2/E04D-C2/E062, C2/E091,
    C2/E237-C2/E23F,
     
    C3/3307, C3/3353, C3/339F, C3/33EB, C3/3497-C3/349A,
    C3/34AE-C3/34AF ("Full" only), C3/34F0-C3/350A, C3/3817-C3/381B,
    C3/4DA0-C3/4DBB, C3/4EEF, C3/4FB5-C3/4FC0, C3/4F12, C3/5028, C3/5053,
    C3/5266-C3/5271, C3/5296, C3/52C1, C3/5328-C3/5333,  C3/54E6-C3/5505,
    C3/5539-C3/5540, C3/555E, C3/57AD-C3/57CC, C3/57F1, C3/5845,
    C3/5991-C3/59C7, C3/5AFA, C3/5AFF-C3/5B1F, C3/5C50-C3/5CC1, C3/5CC2-C3/5CC3,
    C3/5CEA-C3/5CF6, C3/6055-C3/625D, C3/6282-C3/6285, C3/6315, C3/7980-C3/7995,
    C3/79CF-C3/79E7, C3/8A41, C3/C338-C3/C341, C3/C3CE-C3/C3D9,
     
    CC/FFF0-CE/D0A0,
     
    E6/FBAD-E6/FBFC.
     
     ...And wherever "GP" appears in the ROM: D1 bank, equipment...


Free space used:

    C3/F091 - C3/F0F3

--------------------------------------------------

TABLE OF CONTENTS

0. Description & Motivation
1. Detailed Changes
2. Relevant Offsets & Disassembly
3. A Note on Imzogelmo's Multi-Steal Fix 1.01
4. Credits
5. Revision History
6. Legal
________________________________________________________________________________

  0. DESCRIPTION & MOTIVATION
________________________________________________________________________________

From Angelo26's post on ff6hacking.com:
https://www.ff6hacking.com/forums/thread-1127.html

  This patch attempts to clean the naming convention of FF3us and adapts it to
  the convention of the newer games, in terms of ability names.

  - Spell Names Increased to 9 Letters (in battle, menu and dialogue instances)
  - Lore Names Increased to 16 letters (in battle and menu)
  - Esper Names increased to 12 letters (in battle, menu & dialogue)
  - Magitek command window attacks increased to 13 letters.
  - Dance Names increased to 13 letters (in battle and menu)
  - Character Job names added and up to 12 letters
  - Changed GP to GIL (menu, dialogue & respective items)
  - Attacks are increased up to 16 Letters (Magitek Missile, Octopus Tentacle,
    etc.)
  - Esper Attacks increased to 16 Letters (Bolt Fist is now Judgement Bolt,
    etc.)
  - Sabin's Blitzes renamed & increased to 16 letters
  - Bushido techniques now 13 letters (in battle and menu)
  - Renamed Commands - Swdtech to Bushido, Health to Pray, Fight to Attack.
  - Fixes overlapping MP cost with ability names bug
    
  Notes:
  1. This patch will expand your ROM to 32 Mbits. Sorry, no anti-patches!
  2. Use only with HEADERED ROM version 1.0.
  3. You will not be able to use USME to change spell names, esper names, nor
     any of the above names or attacks. You'll need to use Windhex and look for
     the spell names located at (the starting) address F2/0210.
  4. If you wish to change the names of the Battle Status effects, they start at
     C2/ADE1.
  5. Bushido techniques are now at F2/1277


Angelo's original patch was very useful, but difficult to apply. In the final
release there was a bug that affected the game's monster battle script and, as a
workaround, Dr. Meat found that the scripts must first be moved to the expanded
section of the ROM before applying the patch. It was also incompatible with
Imzogelmo's Multi-Steal Fix, including unintended "non-changes" to a few bytes
that made their way into the IPS patch.

The intention of this hack is to update Angelo's patch, making it easier to use
and to make its menu adjustments more visually appealing. There are two versions
in this distribution:
 1. A "basic" update with conservative visual tweaks
 2. A "full" update that adds a few bolder aesthetic changes

Since this hack uses LordJ's FF3usME to move the monster battle scripts, the
patch also fixes the Mag Roader/Wild Cat script bug.

________________________________________________________________________________

  1. DETAILED CHANGES
________________________________________________________________________________

Basic Update:
 - All of the features listed in Section 0 above.
 - Name changes in the "Basic" column of the ability names list below.
 - Moves battle scripts to the FE block in the expanded portion of the ROM.
 - Version compatible with Imzogelmo's Multi-Steal Fix is also available.
 - Realigns the Spell/Learn Rate list in the Esper menu.
 - Space optimization: Returned special ability type names (e.g. Lore, Dance,
   etc.) to their original location on the ROM.
 
Full Revision
 - All of the features listed in the Basic version above.
 - Returns spell description window to its original height. All default
   descriptions now fit properly again.
 - Esper names, LV/HP/MP, etc. rearranged in submenus and the Linuep menu for
   more natural-looking alignment.
 - Ability names altered from the "Basic" version as noted in the "Full" column
   of the list below.
 - Job names have been revamped to reflect the briefly-interesting novelty that
   they are. It is the opinion of the author that, in a story-driven game with
   no job system, the player does not need to be reminded constantly that Locke
   is an "adventurer," Shadow is an "assassin," etc. Therefore, instead of
   appearing in nearly every menu and submenu, cluttering everything up, job
   names are instead relegated to the Status page.

   
Ability Name Comparison:

Original       Basic          Full
------         --------       --------
Ice            Blizzard
Bolt           Thunder
Fire 2         Fira
Ice 2          Blizzara
Bolt 2         Thundara
Fire 3         Firaga
Ice 3          Blizzaga
Bolt 3         Thundaga
Cure 2         Cura
Cure 3         Curaga
Antdot         Poisona
Scan           Libra
Regen          Regene         Regen
Remedy         Esuna
Life           Raise
Life 2         Arise
Life 3         Reraise
Imp            Kappa
Safe           Protect
Rflect         Reflect
Muddle         Confuse
Warp           Teleport
Demi           Gravity
Quartr         Graviga
X-zone         Void
Merton         Meltdown
Doom           Death
Haste2         Hastaga        Hastega
Slow 2         Slowga
Sleep          Sleeper        Sleep
Mute           Silence

Dark           Blind
Psyche         Psyche         Sleep
Mute           Silence        Mute
Image          Mirage         Blink
Muddle         Confuse
Wound          Dead           KO
Near Fatal     Near Death     Critical
Condemned      D. Sentence    Doom
Life 3         Reraise
Safe           Protect
Regen          Regene         Regen

Ifrit          Efreet         Ifrit
Shoat          Catoblepas
Stray          Cait Sith
Starlet        Lakshmi
Crusader       Jihaad         Crusader
Tritoch        Valigarmanda
Palidor        Quetzalli
Terrato        Jormungander   MidgardSormr
Alexandr       Alexander
Zone Seek      Zona Seeker
Sraphim        Seraphim       Seraph

Ice Beam       Blizzard Beam  Ice Beam
Bolt Beam      Thunder Beam
X-Fer          Degenerator    Banisher
Heal Force     Healing Force
TekMissile     MagiTkMissile  M-Tek Missile

Wind Song      Wind Rhapsody  Wind Song
Forest Suite   Forest Noctur  Forest Suite
Desert Aria    Desert Lullab  Desert Aria
Love Sonata    Love Serenade  Love Sonata
Dusk Requiem   Dark Requiem   Dusk Requiem
Water Rondo    Water Harmony  Water Rondo
Snowman Jazz   Snowman Rondo  Snowman Jazz

(Terra)        Sorceress
(Locke)        Adventurer
(Cyan)         Samurai
(Shadow)       Assassin
(Edgar)        Machinist
(Sabin)        Monk
(Celes)        Rune Knight
(Strago)       Blue Mage
(Relm)         Pictomancer
(Setzer)       Gambler
(Mog)          Moogle
(Gau)          Wild Boy       Feral Youth
(Gogo)         Mimic          Mime
(Umaro)        Yeti
(Banon)        Priest         Oracle
(Leo)          Shogun         General
(????)         Ghost
(Kefka)        Biotch (NPC)
(Biggs/Wedge)  Imp. Soldier   Soldier

Angelo's patch also modified several enemy ability names to match later
conventions. In the full update, Angelo's "Will of the Wisp" has changed to
"Will o' the Wisp".

To edit these names after applying the patch, open the ROM in a hex editor with
table support (e.g. WindHex), use the "Battle" table for FF3, and search the
F2 bank (SNES Hi-ROM offset mode). You can then edit the name entries by hand.

________________________________________________________________________________

  2. RELEVANT OFFSETS & DISASSEMBLY
________________________________________________________________________________

Contents:
a. Common
b. "Full" Variant Only

==================================================
 a. Common
==================================================

Much of the following has been adapted from Angelo's original post. It has been
made as comprehensive as possible, but there is still a chance that some code
changes have been missed.

--------------------------------------------------

Magic Spells

Original (discontinuous):
*C1/601A: A9 07        LDA #$07         ; 7 = spell name length
*C1/6031: BF 68 F5 E6  LDA $E6F568,X    ; Load Spell name X
 C1/65A3: A9 07        LDA #$07
 C1/65E8: A9 07        LDA #$07         ; 7 = spell name length
 C1/65F3: BF 67 F5 E6  LDA $E6F567,X    ; Load Spell name X
 C1/6B1D: A9 07        LDA #$07
 C1/6B2E: BF 67 F5 E6  LDA $E6F567,X    ; Load spell name X
 C1/8280: 08                            ; Cursor Position for Battle Spell List

Modified (discontinuous):
*C1/601A: A9 09        LDA #$09         ; 9 = spell name length
*C1/6031: BF 01 00 F2  LDA $F20001,X    ; Load Spell name X
 C1/65A3: A9 09        LDA #$09
 C1/65E8: A9 09        LDA #$09         ; 9 = spell name length
 C1/65F3: BF 00 00 F2  LDA $F20000,X    ; Load Spell name X
 C1/6B1D: A9 09        LDA #$09
 C1/6B2E: BF 00 00 F2  LDA $F20000,X    ; Load spell name X
 C1/8280: 00                            ; Cursor Position for Battle Spell List
 
  *In Imzogelmo's Multi-Steal Fix:
   C1/601A is moved to C1/5FD8
   C1/6031 is moved to C1/5FE0
  
In-Battle Status Effect Names
  Data address range: C2/ADE0 - C2/AF10

--------------------------------------------------

Position of Spell list in battle and field menu

Original (discontinuous):
 C2/E237: 05 03 04 21           <- Not true! It's actually 01 FF 04 21
 C2/E23C: FF FF 04 21           <- Not true! It's actually 00 FF 16 01
 C3/4FB5: A0 07 00     LDY #$0007     ; spell letter length
 C3/4FBA: A0 67 F5     LDY #$F567     ; spell name address
 C3/4FBF: A9 E6        LDA #$E6       ; spell name bank
 C3/5052: A2 92 9E     LDX #$9E92     ; position of spell progress
 C3/5AF9: A2 92 9E     LDX #$9E92     ; space b/t start of spell name and ':'
 C3/5027: A0 0B 00     LDY #$000B

Modified (discontinuous):
 C2/E237: 01 FF 04 21          <- This is actually unmodified!
 C2/E23C: 00 FF 16 01          <- This is actually unmodified!
 C3/4FB5: A0 09 00     LDY #$0009     ; spell letter length
 C3/4FBA: A0 00 00     LDY #$0000     ; spell name address
 C3/4FBF: A9 F2        LDA #$F2       ; spell name bank
 C3/5052: A2 94 9E     LDX #$9E94     ; position of spell progress
 C3/5AF9: A2 94 9E     LDX #$9E94     ; space b/t start of spell name and ':'
 C3/5027: A0 0D 00     LDY #$000D
  
--------------------------------------------------

Size of magic spell name window in field menu (using spell)

Original:
 C3/5845: 07 02
Modified:
 C3/5845: 09 02

--------------------------------------------------

Size of item name window in field menu (using item)

 Original:
  C3/8A41: 0D 02
 Modified:
  C3/8A41: 0C 02

--------------------------------------------------

Growth Rate string:

Original:
 C3/5AFF: A9 C1       LDA #$C1       ; Char: ":"
 C3/5B01: 8D 80 21    STA $2180      ; Add to string
 C3/5B04: A9 FF       LDA #$FF       ; Space char
 C3/5B06: 8D 80 21    STA $2180      ; Add to string
 C3/5B09: 8D 80 21    STA $2180      ; Add to string
 C3/5B0C: A9 D7       LDA #$D7       ; Char: "×"
 C3/5B0E: 8D 80 21    STA $2180      ; Add to string
 C3/5B11: A5 E0       LDA $E0        ; Learning rate
 C3/5B13: 20 E0 04    JSR $04E0      ; Turn into text
 C3/5B16: A5 F8       LDA $F8        ; Tens digit
 C3/5B18: 8D 80 21    STA $2180      ; Add to string
 C3/5B1B: A5 F9       LDA $F9        ; Ones digit
 C3/5B1D: 8D 80 21    STA $2180      ; Add to string

Modified:
 C3/5AFF: A9 01       LDA #$01       ; Submenu I.D. for "Skills"
 C3/5B01: 20 E2 F0    JSR $F0E2      ; New subroutine $F0E2
 C3/5B04: 8D 80 21    STA $2180      ; Add to string
 C3/5B07: A9 D7       LDA #$D7       ; Char: "×"
 C3/5B09: 8D 80 21    STA $2180      ; Add to string
 C3/5B0C: A5 E0       LDA $E0        ; Learning rate
 C3/5B0E: 20 E0 04    JSR $04E0      ; Turn into text
 C3/5B11: A5 F8       LDA $F8        ; Tens digit
 C3/5B13: 8D 80 21    STA $2180      ; Add to string
 C3/5B16: A5 F9       LDA $F9        ; Ones digit
 C3/5B18: 8D 80 21    STA $2180      ; Add to string
 C3/5B1B: A9 00       LDA #$00       ; Submenu I.D. for "Items"
 C3/5B1D: 20 E2 F0    JSR $F0E2      ; New subroutine $F0E2

--------------------------------------------------
 
Lore Names

  Lore names are found in the expanded F2 bank.

Original (discontinuous):
 C1/6660: A9 0A       LDA #$0A
 C1/6665: A9 0A       LDA #$0A       ; from C1/665E (10 = lore name length
 C1/6670: BF FD F9 E6 LDA $E6F9FD,X  ; Load Lore name X
 C3/5266: A0 0A 00    LDY #$000A     ; lore name length
 C3/526B: A0 FD F9    LDY #$F9FD     ; lore name address
 C3/5270: A9 E6       LDA #$E6       ; lore name bank
 C3/5295: A2 95 9E    LDX #$9E95     ; position of ... in lore menu 
 C3/52C0: A0 0E 00    LDY #$000E     ; 14 letters to erase
Modified (discontinuous):
 C1/6660: A9 10       LDA #$10
 C1/6665: A9 10       LDA #$10       ; from C1/665E (16 = lore name length)
 C1/6670: BF 00 07 F2 LDA $F20700,X  ; Load Lore name X
 C3/5266: A0 10 00    LDY #$0010     ; lore name length
 C3/526B: A0 00 07    LDY #$0700     ; lore name address
 C3/5270: A9 F2       LDA #$F2       ; lore name bank
 C3/5295: A2 9A 9E    LDX #$9E9A     ; position of ... in lore menu
 C3/52C0: A0 14 00    LDY #$0014     ; 20 letters to erase 
 
--------------------------------------------------

Magitek Attacks

  Data address range for battle menu display:  E6/FBAD - E6/FBFC
  Attack names are found in the F2 expanded bank.

Original (discontinuous):
 C1/64F8: A9 0A        LDA #$0A
 C1/64FF: A9 0A        LDA #$0A       ; 10 = Magitek attack name length
 C1/650A: BF AD F9 E6  LDA $E6F9AD,X  ; Loads Magitek attack name X
 C1/8289: 10                          ; Cursor pos., left half of Magitek list
 C1/828A: 78                          ; Cursor pos., right half of Magitek list
 C2/E04D: 05 04        ORA $04        ; Pos. for left list of Magitek Atk Menu
 C2/E053: 05 03        ORA $03        ; Pos. for right list of Magitek Atk Menu
Modified (discontinuous):
 C1/64F8: A9 0A        LDA #$0A
 C1/64FF: A9 0A        LDA #$0A       ; 10 = Magitek attack name length
 C1/650A: BF AD F9 E6  LDA $E6F9AD,X  ; Loads Magitek attack name X
 C1/8289: 10                          ; Cursor pos., left half of Magitek list
 C1/828A: 78                          ; Cursor pos., right half of Magitek list
 C2/E04D: 05 04        ORA $04        ; Pos. for left list of Magitek Atk Menu
 C2/E053: 05 03        ORA $03        ; Pos. for right list of Magitek Atk Menu
 
--------------------------------------------------

Dances

  Dance names are found in the F2 expanded bank.
 
Original (discontinuous)
 C1/660B: A9 0C        LDA #$0C
 C1/6610: A9 0C        LDA #$0C       ; 12 = Dance name length
 C1/661B: BF 9D FF E6  LDA $E6FF9D,X  ; Load Mog's Dance name X
 C1/8287: 10                          ; Cursor positioning, left col. of dances
 C1/8288: 80                          ; Cursor positioning, right col. of dances  
 C2/E05B: 04 04        TSB $04        ; Position of Left list of Dances
 C3/57B8: A2 11 00     LDX #$0011     ; X position of right half of Dance
 C3/57C1: A0 0C 00     LDY #$000C     ; Dance name length
 C3/57C6: A0 9D FF     LDY #$FF9D     ; Dance address
 C3/57CB: A9 E6        LDA #$E6       ; Dance bank
 C3/57F0: A0 0C 00     LDY #$000C     ; length of dance names to erase
Modified (discontinuous)
 C1/660B: A9 0D        LDA #$0D
 C1/6610: A9 0D        LDA #$0D       ; 12 = Dance name length
 C1/661B: BF FE F0 F2  LDA $F20FFE,X  ; Load Mog's Dance name X
 C1/8287: 00                          ; Cursor positioning, left col. of dances
 C1/8288: 78                          ; Cursor positioning, right col. of dances  
 C2/E05B: 02 04        TSB $02        ; Position of Left list of Dances
 C3/57B8: A2 11 00     LDX #$0011     ; X position of right half of Dance
 C3/57C1: A0 0D 00     LDY #$000D     ; Dance name length
 C3/57C6: A0 FE 0F     LDY #$0FFE     ; Dance address
 C3/57CB: A9 F2        LDA #$F2       ; Dance bank
 C3/57F0: A0 0D 00     LDY #$000D     ; length of dance names to erase
 
-------------------------------------------------- 

Attacks

Original (discontinuous)
*C1/5FC9: A9 0A        LDA #$0A         ; 10 = skean attack name length
*C1/5FDD: BF B9 F7 E6  LDA $E6F7B9,X    ; Load skean attack name X
 C1/65B4: A9 0A        LDA #$0A         ; 10 = skean attack name length
 C1/65BF: BF B9 F7 E6  LDA $E6F7B9,X    ; Load skean attack name X
 C1/6ADC: A9 0A        LDA #$0A         ; 10 = skean attack name length
 C1/6AED: BF B9 F7 E6  LDA $E6F7B9,X    ; Load skean attack name X
Modified (discontinuous)
*C1/5FC9:  A9 10       LDA #$10         ; 16 = skean attack name length
*C1/5FDD:  BF 5E 03 F2 LDA $F2035E,X    ; Load skean attack name X
 C1/65B4: A9 10        LDA #$10         ; 16 = skean attack name length
 C1/65BF: BF 5E 03 F2  LDA $F2035E,X    ; Load skean attack name X
 C1/6ADC: A9 10        LDA #$10         ; 16 = skean attack name length
 C1/6AED: BF 5E 03 F2  LDA $F2035E,X    ; Load skean attack name X

  * In Imzogelmo's Multi-Steal Fix:
    C1/5FC9 is moved to C1/5FAD
    C1/5FDD is moved to C1/5FB2

--------------------------------------------------

Esper Attacks:

Original (discontinuous):
 C2/BB4D: A9 0A       LDA #$0A       ; Esper attack name length
 C2/BB59: BF 8F FE E6 LDA $E6FE8F,X  ; Esper attack names
 C2/BB66: C0 0A 00    CPY #$000A     ; Esper attack name length
Modified (discontinuous):
 C2/BB4D: A9 10       LDA #$10       ; Esper attack name length
 C2/BB59: BF 4E 0E F2 LDA $F20E4E,X  ; Esper attack names
 C2/BB66: C0 10 00    CPY #$0010     ; Esper attack name length
 
--------------------------------------------------

GP to Gil:
  - Changed all instances in Town Dialogue of Gp to Gil
  - Changed all instances in Battle Small Quotes of Gp to Gil
  - Changed all instances in Battle Text (Bank D1) of Gp to Gil
  - Changed all equipment description that refers to GP (Cat Hood, Coin Toss,
      GP Rain -> GilToss)
 
Data addresses:
 C3/3817: 77 7E 86 A9 00             ; "Gp"
 C3/C338: 41 7A 86 8F 00             ; "GP"
 C3/C33D: 2B 7B 86 8F 00             ; "GP"
"You need more GP!":
 C3/C3CE:  1F 79 98 A8 AE FF A7 9E 9E 9D FF A6 A8 AB 9E FF 
 C3/C3D6:  86 8F BE 00

--------------------------------------------------

Esper Names

Original (discontinuous):
*C1/5FF3: A9 08        LDA #$08       ; 8 = Esper name length
*C1/6007: BF E1 F6 E6  LDA $E6F6E1,X  ; Load Esper name X
 C1/65D0: A9 08        LDA #$08       ; 8 = Esper name length
 C1/65DB: BF E1 F6 E6  LDA $E6F6E1,X  ; Load Esper name X
 C1/6688: A9 08
 C1/668D: A9 08        LDA #$08       ; from C1/6686)(Sets name length?
 C1/6698: BF E1 F6 E6  LDA $E6F6E1,X  ; Loads Esper name X
 C2/E091: 04 03        TSB $03        ; Change the 04 bit
 C3/34F0: 0A           ASL A
 C3/34F1: 0A           ASL A
 C3/34F2: 0A           ASL A
 C3/34F4: A0 08 00     LDY #$0008     ; Esper name length
 C3/34F7: BF E1 F6 E6  LDA $E6F6E1,X  ; Load Esper name
 C3/3508: A0 08 00     LDY #$0008
 C3/4F12: 37 42                       ; Level position, sub menu
 C3/54FA: A0 08 00     LDY #$0008     ; Esper name length
 C3/54FF: A0 E1 F6     LDY #$F6E1     ; Esper name address
 C3/5504: A9 E6        LDA #$E6       ; Esper name bank
 C3/5539: A2 93 9E     LDX #$9E93
 C3/553F: A9 C7        LDA #$C7       ; The '...' character in the font)
 C3/5539: A2 93 9E     LDX #$9E93    
 C3/555D: A0 0C 00     LDY #$000C     ; Esper name 8 chars, +1 space +3 MP cost
 C3/5991: 10 70                       ; Cursor at esper name
 C3/5993: 18 7C                       ; Cursor at spell name
 C3/5995: 18 88                       ; Cursor at spell name
 C3/5997: 18 94                       ; Cursor at spell name
 C3/5999: 18 A0                       ; Cursor at spell name
 C3/599B: 18 AC                       ; Cursor at spell name
 C3/59BD: 0A           ASL A
 C3/59BE: 0A           ASL A
 C3/59BF: 0A           ASL A
 C3/59C1: A0 08 00     LDY #$0008     ; Indirectly says below is 8 chars long
 C3/59C4: BF E1 F6 E6  LDA $E6F6E1,X  ; Load Esper X's name
 C3/5A05: A2 05 00     LDX #$0005     ; Pos. of spell names in learn rate window
 C3/5CC2: 2D 42 8B 95 00              ; Position of and word "LV"
 C3/5CEA: 23 44 8B 9E 9A AB A7 C5 91 9A AD 9E 00   ; 2 bytes pos. + "Learn rate"
 C3/6055: A0 B1 39     LDY #$39B1     ; Position of Esper name status menu
 C3/7993: A0 5B 3B     LDY #$3B5B     ; Position of Esper name, Linuep menu
Modified (discontinuous):
*C1/5FF3:  A9 0C        LDA #$0C      ; 12 = Esper name length
*C1/6007:  BF E6 01 F2  LDA $F201E6,X ; Load Esper name X
 C1/65D0: A9 0C        LDA #$0C       ; 12 = Esper name length
 C1/65DB: BF E6 01 F2  LDA $F201E6,X  ; Load Esper name X
 C1/6688: A9 0C
 C1/668D: A9 0C        LDA #$0C       ; from C1/6686 (Sets name length?)
 C1/6698: BF E6 01 F2  LDA $F201E6,X  ; Loads Esper name X
 C2/E091: 02 03                       ; Change the 04 bit
 C3/34F0: 20 D0 F0     JSR $F0D0               
 C3/34F4: A0 0C 00     LDY #$000C     ; Esper name length
 C3/34F7: BF E6 01 F2  LDA $F201E6,X  ; Load Esper name
 C3/3508: A0 0C 00     LDY #$000C
 C3/4F12: 41 42                       ; Level position, sub menu
 C3/54FA: A0 0C 00     LDY #$000C     ; Esper name length
 C3/54FF: A0 E6 01     LDY #$01E6     ; Esper name address
 C3/5504: A9 F2        LDA #$F2       ; Esper name bank
 C3/5539: A2 9A 9E     LDX #$9E9A
 C3/553F: A9 FF        LDA #$FF       ; The '...' character in the font)
 C3/5539: A2 9A 9E     LDX #$9E9A    
 C3/555D: A0 10 00     LDY #$0010     ; Esper name 12 chars, +1 space +3 MP cost
 C3/5991: 08 70                       ; Cursor at esper name
 C3/5993: 10 7C                       ; Cursor at spell name
 C3/5995: 10 88                       ; Cursor at spell name
 C3/5997: 10 94                       ; Cursor at spell name
 C3/5999: 10 A0                       ; Cursor at spell name
 C3/599B: 10 AC                       ; Cursor at spell name
 C3/59B4: A0 0F 44     LDY #$440F
 C3/59BD: 20 D0 F0     JSR $F0D0
 C3/59C1: A0 0C 00     LDY #$000C     ; Indirectly says below is 12 chars long
 C3/59C4: BF E6 01 F2  LDA $F201E6,X  ; Load Esper X's name
 C3/5A05: A2 04 00     LDX #$0004     ; Pos. of spell names in learn rate window
 C3/5CC2: 37 42 8B 95 00              ; Position of and word "LV"
 C3/5CEA: 1F 44 FF FF FF FF FF 91 9A AD 9E FF 00   ; 2 bytes pos. + "Rate"
 C3/6055: A0 AD 39     LDY #$39AD     ; Position of Esper name status menu
 C3/7993: A0 51 3B     LDY #$3B51     ; Position of Esper name, Linuep menu  
  
  * In Imzogelmo's Multi-Steal Fix:
    C1/5FF3 is moved to C1/5FC4
    C1/6007 is moved to C1/5FC9

--------------------------------------------------

Class Names

Original (discontinuous)
 C3/3497: 65 E7        ADC $E7
 C3/3499: 85 E7        STA $E7
 C3/34AD: 4C E5 34     JMP $34E5
 C3/3306: A0 27 39     LDY #$3927   ; Menu position of class name
 C3/3352: A0 A7 3A     LDY #$3AA7   ; Menu position of class name
 C3/339E: A0 27 3C     LDY #$3C27   ; Menu position of class name
 C3/33EA: A0 A7 3D     LDY #$3DA7   ; Menu position of class name
 C3/4DA0: CB 59 1C 05
 C3/4DA8: 8B 58 1C 03
 C3/4DAC: CB 61 1C 05
 C3/4DB8: 8B 60 1C 03               ; window for Esper & Spell descriptions
 C3/4EED: A0 DD 42     LDY #$42DD
 C3/79CF: 6D 3A 8B 95 00            ; position of and word "LV", Linuep menu
 C3/79E6: 77 3A                     ; level's position, Linuep menu
Modified (discontinuous)
 C3/3497: 22 00 C2 F2  JSL $F2C200
 C3/34AD: 4C A3 F0     JMP $F0A3
 C3/3306: A0 59 39     LDY #$3959   ; Menu position of class name
 C3/3352: A0 D9 3A     LDY #$3AD9   ; Menu position of class name
 C3/339E: A0 59 3C     LDY #$3C59   ; Menu position of class name
 C3/33EA: A0 D9 3D     LDY #$3DD9   ; Menu position of class name
 C3/4DA0: 8B 59 1C 06               ; window for character portrait and stats
 C3/4DA8: 8B 58 1C 02               ; window for Esper and Spell descriptions
 C3/4DAC: 8B 61 1C 06               ; window for character portrait and stats
 C3/4DB8: 8B 60 1C 02               ; window for Esper and Spell descriptions
 C3/4EED: A0 DD 41     LDY #$41DD
 C3/79CF: 7B 3A 8B 95 00            ; position of and word "LV", Linuep menu
 C3/79E6: 81 3A                     ; level's position, Linuep menu
  

--------------------------------------------------

Bushido Techniques
  
Original (discontinuous)
 C2/BB23: A9 0C        LDA #$0C        ; SwdTech name length
 C2/BB2F: BF 40 3C CF  LDA $CF3C40,X   ; SwdTech names
 C3/5328: A0 0C 00     LDY #$000C      ; SwdTech name length
 C3/532B: 84 EB        STY $EB
 C3/532D: A0 40 3C     LDY #$3C40      ; SwdTech address
 C3/5330: 84 EF        STY $EF
 C3/5332: A9 CF        LDA #$CF        ; SwdTech bank
Modified (discontinuous)
 C2/BB23: A9 0D        LDA #$0D        ; SwdTech name length
 C2/BB2F: BF 67 10 F2  LDA $F21067,X   ; SwdTech names
 C3/5328: A0 0D 00     LDY #$000D      ; SwdTech name length
 C3/532B: 84 EB        STY $EB         ; (NO CHANGE)
 C3/532D: A0 40 3C     LDY #$3C40      ; SwdTech address
 C3/5330: 84 EF        STY $EF         ; (NO CHANGE)
 C3/5332: A9 F2        LDA #$F2        ; SwdTech bank

Special Ability Categories (SwdTech -> Bushido)
  Data Address Range: C3/5C50 - C3/5CC1
 
--------------------------------------------------

New Subroutines & Data (Angelo)

 C3/F0A3: B9 00 00     LDA $0000,Y
 C3/F0A6: 22 00 34 F2  JSL $F23400  ; New subroutine in F2 bank for class names
 C3/F0AA: 4C 05 35     JMP $3505
 
 C3/F0AD: 42
 C3/F0AE: EA           NOP
 C3/F0AF: EA           NOP
 C3/F0B0: EA           NOP
 C3/F0B1: EA           NOP
 C3/F0B2: AE A0 08 00 08 00 BF 40 3B CF 8D 80 21 E8 D0 F5
 C3/F0C2: A9 FF 77 7E 86 A2 A5 FF FF FF FF FF FF FF
 
 ; Executes when the "skills" menu is opened:
 C3/F0D0: C2 20        REP #$20        
 C3/F0D2: 48           PHA
 C3/F0D3: 0A           ASL
 C3/F0D4: 0A           ASL
 C3/F0D5: 0A           ASL
 C3/F0D6: 85 E0        STA $E04D
 C3/F0D8: 68           PLA
 C3/F0D9: 18           CLC
 C3/F0DA: 0A           ASL
 C3/F0DB: 0A           ASL
 C3/F0DC: 65 E0        ADC $EO
 C3/F0DE: AA           TAX
 C3/F0DF: E2 20        SEP #$20
 C3/F0E1: 60           RTS

--------------------------------------------------

Control menu text length & window size

Original:
 C2/DDD6: 0C 08    ; Relm's Control window dimensions (12 x 8)
Modified:
 C2/DDD6: 12 08    ; Relm's Control window dimensions (18 x 8)

Original:
 C1/6ACB: A9 07     LDA #$07 ; blank control command length
Modified:
 C1/6ACB: A9 09     LDA #$09 ; blank control command length
                             ; (must match magic spell name length)

Original:
 C1/6ABD: A9 03     LDA #$03 ; spaces after spells/blank (from C1/6AB6, C1/6ABA)
Modified:
 C1/6ABD: A9 07     LDA #$07 ; spaces after spells/blank (from C1/6AB6, C1/6ABA)

--------------------------------------------------
  
In addition to the above, the following items are also affected by the patch:
 - Field dialog scripts will be overwritten (~CC/FFF0-CE/D0A0)
 - Any data already in the expanded section of the ROM will be overwritten.
 - Monster battle scripts are moved to bank FE.
 - Names for jobs, spells, enemy abilities, Espers, Esper attacks, Dances,
   Bushido techniques, and blitzes are stored in the F2 bank.

--------------------------------------------------

New Subroutine (SilentEnigma)

; Conditionally appends ": " to growth rate string; then loads Space char value
 C3/F0E2: CD 2C 02     CMP $0220    ; Compare submenu I.D. to accumulator
 C3/F0E5: D0 0A        BNE $F0F1    ; If not equal, skip appending string
 C3/F0E7: A9 C1        LDA #$C1     ; Char: ":"
 C3/F0E9: 8D 80 21     STA $2180    ; Add to string
 C3/F0EC: A9 FF        LDA #$FF     ; Space char
 C3/F0EE: 8D 80 21     STA $2180    ; Add to string
 C3/F0F1: A9 FF        LDA #$FF     ; Space char
 C3/F0F3: 60           RTS          ; Return

  
==================================================
 Full Variant Only
==================================================

Supersedes "common" where in conflict

--------------------------------------------------

Restore Default Esper & Spell description window size

Original (reverted, discontinuous):
 C3/4DA0: CB 59 1C 05
 C3/4DA8: 8B 58 1C 03
 C3/4DAC: CB 61 1C 05
 C3/4DB8: 8B 60 1C 03

--------------------------------------------------

Reorganize Submenu stats

Original:
 C3/5CC2: 2D 42 8B 95 00           ; Position of and word "LV"
Modified:
 C3/5CC2: 9D 42 8B 95 00           ; Position of and word "LV"

Original:
 C3/4F12: 37 42                    ; Level position
Modified:
 C3/4F12: A5 42                    ; Level position

--------------------------------------------------

Reorganize Lineup (airship) menu stats

Original:
 C3/798A: 20 27 34   JSR $3427     ; Show status effects & set font color white
Modified 
 C3/798A: 20 A9 34   JSR $3427     ; Set font color white (skip status effects)

Original:
 C3/798D: A0 DB 3A    LDY #$3ADB   ; character name position
Modified:
 C3/798D: A0 5B 3A    LDY #$3A5B   ; character name position

Original:
 C3/7993: A0 5B 3B    LDY #$3B5B   ; Position of Esper name
Modified:
 C3/7993: A0 6B 3A    LDY #$3A6B   ; Position of Esper name

Original:
 C3/79CF: 6D 3A 8B 95 00           ; position of and word "LV"
 C3/79D4: ED 3A 87 8F 00           ; Position of and word "HP"
 C3/79D9: 6D 3B 8C 8F 00           ; Position of and word "MP"
 C3/79DE: FB 3A C0 00              ; Position of and "/" (HP)
 C3/79E2: 7B 3B C0 00              ; Position of and "/" (MP)
 C3/79E6: 77 3A                    ; level's position
 C3/79E8: F3 3A                    ; Position of current HP
 C3/79EA: FD 3A                    ; Position of total HP
 C3/79EC: 73 3B                    ; Position of current MP
 C3/79EE: 7D 3B                    ; Position of toal MP
Modified:
 C3/79CF: DB 3A 8B 95 00           ; position of and word "LV
 C3/79D4: EB 3A 87 8F 00           ; Position of and word "HP"
 C3/79D9: 6B 3B 8C 8F 00           ; Position of and word "MP"
 C3/79DE: F9 3A C0 00              ; Position of and "/" (HP)
 C3/79E2: 79 3B C0 00              ; Position of and "/" (MP)
 C3/79E6: E3 3A                    ; level's position
 C3/79E8: F1 3A                    ; Position of current HP
 C3/79EA: FB 3A                    ; Position of total HP
 C3/79EC: 71 3B                    ; Position of current MP
 C3/79EE: 7B 3B                    ; Position of toal MP

--------------------------------------------------

Job Name Revamp

Original (reverted):
 C3/34AD: 4C E5 34    JMP $34E5    ; Bypass job name display (revert original)

Original:
 C3/625B: A0 9D 39    LDY #$39CD   ; Position of job name on status screen
Modified:
 C3/625B: A0 CD 39    LDY #$39CD   ; Position of job name on status screen

Original:
 C3/6282: F0 5D       BEQ $62E1    ; Branch if no status effect
 C3/6284: 64 F1       STZ $F1
Modified:
 C3/6282: 4C91F0      JMP $F091    ; Break out of status effect check
 C3/6285: EA          NOP          ; Operation moved from C3/6284 to C3/F093

New Subroutine C3/F091
 C3/F091: F0 05       BEQ $F098    ; Branch if no status effect, from C3/6282
 C3/F093: 64 F1       STZ $F1      ; Operation from C3/6284
 C3/F095: 4C 86 62    JMP $6286    ; Return to status effect check
 C3/F098: A9 FF       LDA #$FF     ; Print space before job name (for alignment)
 C3/F09A: 8D 80 21    STA $2180    ; (Writes space to WRAM)
 C3/F09D  4C A3 F0    JMP $F0A3    ; Jump to code for printing the job name
 C3/F0A0: EA          NOP
 C3/F0A1: EA          NOP
 C3/F0A2: EA          NOP

Original:
 C3/6314: E0 08 00    CPX #$0008   ; 8 = max job name length + 1 (blank)
Modified
 C3/6314: E0 0D 00    CPX #$000D   ; 13 = max job name length + 1 (blank)

________________________________________________________________________________

  3. A NOTE ON IMZOGELMO'S MULTI-STEAL FIX 1.01
________________________________________________________________________________

It has been suggested by Gi Nattak that the Multi-Steal fix has a bug in it
which breaks the Steal function for monsters. It comes down to one branch
function, which according to the patch's documentation is:

 C2/39A8: B0 62    BCS $3A0F     ; Branch if monster to ????

However, the actual code of the patch yields:

 C2/39A8: B0 5A    BCS $3A04     ; Branch if monster to "If no items to steal"

According to Gi Nattak, the correct entry is:

 C2/39A8: B0 65    BCS $3A12     ; Branch if monster to "Steal for monsters"
  
I have not rigorously verified this solution, but I have been using it and have
not noticed any problems thus far.

-SilentEnigma, 2016-02-19

________________________________________________________________________________

  4. CREDITS
________________________________________________________________________________

Original "Final Fantasy VI: Restored Ability Names" hack:
  Angelo ......... Author
  MetroidQuest ... Code on job names
  James McPhee ... Data organization in the expanded ROM
  Gi Nattak ...... Testing & bug reporting
  
Updated Hack:
  Imzogelmo ...... Multi-Steal fix, disassembly of banks C1 and C3.
  LordJ .......... FF3usME & its "Monster Battle Scripts" hack
  Dr. Meat ....... Found a workaround for the original patch's battle script
                   compatibility issue
  Gi Nattak ...... Resolved a bug in Imzogelmo's patch

Special Thanks To:
  Madsiur, for endorsing the author's usurpation of Angelo's hack
  Antamaru:
   - For identifying the Item submenu bugs through version 1.1 and 1.2
   - For identifying the job name length bug through version 1.3
   - For identifying the Control menu window width bug through version 1.4
  DrakeyC, for his helpful solution proposal for the Item submenu bug in 1.1
  
________________________________________________________________________________

  5. REVISION HISTORY
________________________________________________________________________________

2016-02-19: Version 1.0 released.

2016-02-20: Version 1.1 released.
  - Fixed the cursor position at the list of Espers' spells.

2019-03-03: Version 1.2 released.
  - Fixed the position of the growth rate string in the Item submenu.

2019-11-27: Version 1.3 released.
  - Resized the width of the field menu's magic spell name window to properly
    fit 'poisona'.
  - Also resized the width of the use-item-name window.
    (The default-sized window unnecessarily encroaches upon the lead character's
    name.)

2020-05-17: Version 1.4 released.
  - Fixed bug in the "Full" variant causing job names longer than 7 characters
    not to clear fully whenever the player switches the status screen to a
    character with active status effects.
  - Status effect names & job names in the "Full" variant now take fewer
    liberties.

2020-06-02: Version 1.5 released.
  - Fixed the width of the Control command menu in battle.

2020-10-10: Version 1.6 released.
  - Removed occasional status effect display in "Full" variant's Lineup menu.
    (overlapped with relocated character name)
  - Moved Esper name, HP, & MP left by 8 pixels in "Full" variant's Lineup menu.

________________________________________________________________________________

  6. LEGAL
________________________________________________________________________________

Copyright (C) 2020 David R. Thompson (SilentEnigma).

The copyright holder ("author") permits the free use of the attributed work
referenced by this document exclusively for non-commercial purposes, provided
that the following conditions are met:
1. The author and all contributors credited in this readme document shall be
 given credit for their respective contributions wherever the attributed work is
 reused, redistributed, or modified.
2. This readme document shall accompany any of the files comprising the
 attributed work wherever they are redistributed in unmodified form.

The work(s) and file(s) distributed with this document are provided "AS-IS",
WITHOUT ANY WARRANTY. The author shall not be held responsible for any damages
related to the use of work(s) and file(s) distributed with this document.
