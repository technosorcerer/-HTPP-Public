Title: Stuck in a Pose fix
Author: SilentEnigma
Version: 2.9
Release Date: 2021-04-26
Applies to: FF3us 1.0, FF3us 1.1
Tested on: FF3us 1.0

Contents:

    readme.txt = this file

    StuckInAPose-Full.ips = the full-featured patch (headered)
    StuckInAPose-Full_NH.ips = the full-featured patch (headerless)

    StuckInAPose-FullN.ips = the Full variant anti-patch (headered)
    StuckInAPose-FullN_NH.ips = the Full variant anti-patch (headerless)

    StuckInAPose-Mini.ips = the minimalist patch (headered)
    StuckInAPose-Mini_NH.ips = the minimalist patch (headerless)

    StuckInAPose-MiniN.ips = the Mini variant anti-patch (headered)
    StuckInAPose-MiniN_NH.ips = the Mini variant anti-patch (headerless)

ROM Addresses:

    C0/49EF - C0/49F1
    
Free space used: 
    Full variant:        115 bytes, C0/D780 - C0/D7F2
    Minimal variant:     105 bytes, C0/D780 - C0/D7E8

RAM used (Full variant only): unused field RAM, direct page $C6 - $C7

Urgency: Medium/Low. This bug pops up all over the place: when pausing on a
    staircase, after unequipping party members on the airship, at the end of
    several scenes when control is given back to the player, etc.
    However, these are all fairly minor visual flaws.

--------------------------------------------------

TABLE OF CONTENTS

0. Description
1. Relevant Offsets & Disassembly
    a. Common
    b. Full variant only
    c. Minimal variant only
2. Revision History
3. Credits
4. Legal
________________________________________________________________________________

  0. DESCRIPTION
________________________________________________________________________________

From Novalia Spirit's "100+ Bugs" Thread:

  After any event-dictated movement occurs, the hero sprite may appear to be
  stuck in its last pose or its walking pose. The easiest way to see this is to
  go up and down some stairs. Most of the time, if you stop walking, the hero
  sprite should appear in a walking pose. Other examples of this are when you
  jump on a turtle, when trying to go up a conveyor belt to no avail, and after
  a scene where your party was split temporarily.
  ...
  One better example of this bug is when you're within the airship and talk to
  the guy who can unequip your characters. While you do so, the hero sprite
  should look South and be in a walking pose, yet, even if the said guy isn't
  South of the hero sprite, you can still talk to him since the game still
  considers you're facing him.


The patch comes in two variants:

 Full-featured ("Full")
 - Optimized & consistent transition timing for "stuck" sprites.
 - Uses the most free space, as well as 2 bytes of unused field RAM

 Minimalist ("Mini")
 - Inferior & inconsistent transition timing for "stuck" sprites.
 - Uses less free space than the full variant; no added RAM usage

________________________________________________________________________________

  1. RELEVANT OFFSETS & DISASSEMBLY
________________________________________________________________________________

Contents:

 a. Common
 b. Full variant only
 c. Minimal variant only

==================================================
 a. COMMON
==================================================

Sprite I.D. table for walking animations
Original:
 C0/580D:  04 05 04 03     ; Unknown
 C0/5811:  6E 6F 6E 6F     ; Unknown
 C0/5815:  01 02 01 00     ; Unknown
 C0/5819:  2E 2F 2E 2F     ; Unknown
 C0/581D:  04 05 04 03     ; Character sprite moving north
 C0/5821:  47 48 47 46     ; Character sprite moving east
 C0/5825:  01 02 01 00     ; Character sprite moving south
 C0/5829:  07 08 07 06     ; Character sprite moving west

Sprite I.D. table for standing facing north, east, south, west 
Original:
 C0/582D:    04 47 01 07

Code snippet executed repeatedly when the player has control but is not pressing
any directional buttons
Original:
 C0/49EF:  AC 03 08    LDY $0803
 C0/49F2:  7B          TDC 
 C0/49F3:  99 7E 08    STA $087E,Y
 C0/49F6:  9C 86 08    STZ $0886
 C0/49F9:  20 A5 C8    JSR $C8A5
 C0/49FC:  20 F4 46    JSR $46F4
 C0/49FF:  20 83 4B    JSR $4B83
 C0/4A02:  60          RTS 
Modified:
 C0/49EF:  20 80 D7    JSR $D780      ; Jump to new subroutine $D780

Sprite IDs:
00 stepping south right foot
01 standing south
02 stepping south left foot
03 stepping north right foot
04 standing north
05 stepping north left foot
06 stepping west left foot
07 standing west
08 stepping west right foot
09 crouching
0A ready stance west
0B flinching west
0C alt battle standing west
0D alt battle stepping west
0E arms up west
0F arms up tip toes west
10 casting mouth closed west
11 casting mouth open west
12 battle collapsed(?)
13 eyes closed south
14 winking south
15 eyes closed west
16 arms up south
17 arms up north
18 indignant south
19 hand raised south
1A hand on head south
1B hand raised north
1C hand on head north
1D laughing head up south
1E laughing head down south
1F surprised south
20 bowed head south
21 bowed head north
22 bowed head west
23 turned head south
24 cheeky finger in south
25 cheeky finger up south
26 shy (Terra only?) south
27 tent
28 field collapsed
29 -
2A -
2B -
2C -
2D -
2E riding west
2F riding wind-blown west


==================================================
 b. FULL VARIANT ONLY
==================================================
 
Original:
 C0/7F98:    86 C6       STX $C6      ; Unused RAM byte
Modified:
 C0/7F98:    EA          NOP
 C0/7F99:    EA          NOP


New Subroutine C0/D780:
 C0/D780:  AC 03 08    LDY $0803      ; Original C0/49EF.
 C0/D783:  B9 77 08    LDA $0877,Y    ; Load current sprite I.D.
 C0/D786:  AA          TAX            ; Temporarily store sprite I.D. in X
 C0/D787:  29 BF       AND #$BF       ; Strip mirror bit
 C0/D789:  C9 0F       CMP #$0F       ; "arms up tip toes west [0x0F]"?
 C0/D78B:  F0 58       BEQ $D7E5      ; Branch if "arms up tip toes west [0x0F]"
 C0/D78D:  C9 17       CMP #$17       ; "arms up north [0x17]"?
 C0/D78F:  F0 54       BEQ $D7E5      ; Branch if "arms up north [0x17]"
 C0/D791:  C9 03       CMP #$03       ; "walking north 1st [0x03]"?
 C0/D793:  90 26       BCC $D7BB      ; Branch if less (if walking south)
 C0/D795:  C9 06       CMP #$06       ; "walking west 1st [0x06]"?
 C0/D797:  90 1F       BCC $D7B8      ; Branch if less (if walking north)
 C0/D799:  C9 09       CMP #$09       ; "crouching [0x09]"?
 C0/D79B:  F0 20       BEQ $D7BD      ; Branch if "crouching [0x09]"
 C0/D79D:  90 46       BCC $D7E5      ; Branch if less (if walking east/west)
 C0/D79F:  C9 22       CMP #22        ; "bowing head west" [0x22]"?
 C0/D7A1:  F0 08       BEQ $D7AB      ; Branch if "bowing head west [0x22]"
 C0/D7A3:  C9 2E       CMP #2E        ; "riding west" [0x2E]"?
 C0/D7A5:  B0 4B       BCS $D7F2      ; Skip everything if GT. or Eq.
 C0/D7A7:  C9 13       CMP #$13       ; "eyes closed south [0x13]"?
 C0/D7A9:  B0 1D       BCS $D7C8      ; Branch if GT. or Eq. (several poses)
 C0/D7AB:  8A          TXA            ; Recall current sprite I.D.
 C0/D7AC:  89 40       BIT #$40       ; Test mirror bit
 C0/D7AE:  F0 04       BEQ $D7B4      ; Branch if mirror bit not set
 C0/D7B0:  A9 01       LDA #01        ; Load direction I.D. for facing east
 C0/D7B2:  80 16       BRA $D7CA
 C0/D7B4:  A9 03       LDA #03        ; Load direction I.D. for facing west
 C0/D7B6:  80 12       BRA $D7CA
 C0/D7B8:  7B          TDC            ; Load direction I.D. for facing north
 C0/D7B9:  80 0F       BRA $D7CA
 C0/D7BB:  C6 C7       DEC $C7        ; unused RAM byte (transition delay)
 C0/D7BD:  AD 64 1F    LDA $1F64      ; Load most of the current map I.D.
 C0/D7C0:  C9 DD       CMP #$DD       ; Zozo main?
 C0/D7C2:  F0 2E       BEQ $D7F2      ; If so, skip everything
 C0/D7C4:  C9 F2       CMP #F2        ; Vector main?
 C0/D7C6:  F0 2A       BEQ $D7F2      ; If so, skip everything
 C0/D7C8:  A9 02       LDA #02        ; Load direction I.D. for facing south
 C0/D7CA:  99 7F 08    STA $087F,Y    ; Store direction I.D.
 C0/D7CD:  8A          TXA            ; Recall current sprite I.D.
 C0/D7CE:  C5 C6       CMP $C6        ; unused RAM byte (most recent sprite)
 C0/D7D0:  F0 04       BEQ $D7D6      ; Branch if same as current sprite
 C0/D7D2:  A9 10       LDA #$10       ; Load base transition delay
 C0/D7D4:  85 C7       STA $C7        ; unused RAM byte (transition delay)
 C0/D7D6:  8A          TXA            ; Recall current sprite I.D.
 C0/D7D7:  C6 C7       DEC $C7        ; unused RAM byte (transition delay)
 C0/D7D9:  10 12       BPL $D7ED      ; If not done, skip everything
 C0/D7DB:  29 BF       AND #$BF       ; Strip mirror bit
 C0/D7DD:  C9 28       CMP #$28       ; Is character "collapsed [0x28]"?
 C0/D7DF:  D0 04       BNE $D7E5      ; Branch if not
 C0/D7E1:  A9 09       LDA #$09       ; Load I.D. for "crouching"
 C0/D7E3:  80 0A       BRA $D7EF
 C0/D7E5:  B9 7F 08    LDA $087F,Y    ; Load current direction value (8-bit)
 C0/D7E8:  AA          TAX            ; Transfer A to X
 C0/D7E9:  BF 2D 58 C0 LDA $C0582D,X  ; I.D. for standing in current direction
 C0/D7ED:  85 C6       STA $C6        ; unused RAM byte (most recent sprite)
 C0/D7EF:  99 77 08    STA $0877,Y    ; Store sprite I.D.
 C0/D7F2:  60          RTS            ; Return from subroutine

==================================================
 c. MINIMAL VARIANT ONLY
==================================================
 
New Subroutine C0/D780:
 C0/D780:  AC 03 08    LDY $0803      ; Original C0/49EF.
 C0/D783:  B9 77 08    LDA $0877,Y    ; Load current sprite I.D.
 C0/D786:  AA          TAX            ; Temporarily store sprite I.D. in X
 C0/D787:  29 BF       AND #$BF       ; Strip mirror bit
 C0/D789:  C9 0F       CMP #$0F       ; "arms up tip toes west [0x0F]"?
 C0/D78B:  F0 50       BEQ $D7DD      ; Branch if "arms up tip toes west [0x0F]"
 C0/D78D:  C9 17       CMP #$17       ; "arms up north [0x17]"?
 C0/D78F:  F0 4C       BEQ $D7DD      ; Branch if "arms up north [0x17]"
 C0/D791:  C9 03       CMP #$03       ; "walking north 1st [0x03]"?
 C0/D793:  90 31       BCC $D7C6      ; Branch if less (if walking south)
 C0/D795:  C9 06       CMP #$06       ; "walking west 1st [0x06]"?
 C0/D797:  90 1F       BCC $D7B8      ; Branch if less (if walking north)
 C0/D799:  C9 09       CMP #$09       ; "crouching [0x09]"?
 C0/D79B:  F0 1E       BEQ $D7BB      ; Branch if "crouching [0x09]"
 C0/D79D:  90 3E       BCC $D7DD      ; Branch if less (if walking east/west)
 C0/D79F:  C9 22       CMP #22        ; "bowing head west" [0x22]"?
 C0/D7A1:  F0 08       BEQ $D7AB      ; Branch if "bowing head west [0x22]"
 C0/D7A3:  C9 2E       CMP #2E        ; "riding west" [0x2E]"?
 C0/D7A5:  B0 41       BCS $D7E8      ; Skip everything if GT. or Eq.
 C0/D7A7:  C9 12       CMP #$12       ; "eyes closed south [0x13]"?
 C0/D7A9:  B0 1B       BCS $D7C6      ; Branch if GT. or Eq. (several poses)
 C0/D7AB:  8A          TXA            ; Recall current sprite I.D.
 C0/D7AC:  89 40       BIT #$40       ; Test mirror bit
 C0/D7AE:  F0 04       BEQ $D7B4      ; Branch if mirror bit not set
 C0/D7B0:  A9 01       LDA #01        ; Load direction I.D. for facing east
 C0/D7B2:  80 14       BRA $D7C8
 C0/D7B4:  A9 03       LDA #03        ; Load direction I.D. for facing west
 C0/D7B6:  80 10       BRA $D7C8
 C0/D7B8:  7B          TDC            ; Load direction I.D. for facing north
 C0/D7B9:  80 0D       BRA $D7C8
 C0/D7BB:  AD 64 1F    LDA $1F68      ; Load most of the current map I.D.
 C0/D7BE:  C9 DD       CMP #$DD       ; Zozo main?
 C0/D7C0:  F0 26       BEQ $D7E8      ; If so, skip everything
 C0/D7C2:  C9 F2       CMP #F2        ; Vector main?
 C0/D7C4:  F0 22       BEQ $D7E8      ; If so, skip everything
 C0/D7C6:  A9 02       LDA #02        ; Load direction I.D. for facing south
 C0/D7C8:  99 7F 08    STA $087F,Y    ; Store direction I.D.
 C0/D7CB:  A9 04       LDA #$4        ; Load base duration
 C0/D7CD:  CD 1E 02    CMP $021E      ; timer semi-second byte
 C0/D7D0:  30 16       BMI $D7E8      ; If not done, skip everything
 C0/D7D2:  8A          TXA            ; Transfer X to A
 C0/D7D3:  29 BF       AND #$BF       ; Strip mirror bit
 C0/D7D5:  C9 28       CMP #$28       ; Is character "collapsed [0x28]"?
 C0/D7D7:  D0 04       BNE $D7DD      ; Branch if not
 C0/D7D9:  A9 09       LDA #$09       ; Load I.D. for "crouching"
 C0/D7DB:  80 08       BRA $D7E5
 C0/D7DD:  B9 7F 08    LDA $087F,Y    ; Load current direction value (8-bit)
 C0/D7E0:  AA          TAX            ; Transfer A to X
 C0/D7E1:  BF 2D 58 C0 LDA $C0582D,X  ; I.D. for standing in current direction
 C0/D7E5:  99 77 08    STA $0877,Y    ; Store sprite I.D.
 C0/D7E8:  60          RTS            ; Return from subroutine

________________________________________________________________________________

  2. REVISION HISTORY
________________________________________________________________________________


2016-02-20 - Version 1.0 completed.

2017-02-18 - Version 2.0 completed.
 > Fixed a bug during the Fall of Doma scene, caused by patch v1.0.
   (Other parts of the game may have also been affected.)
 > Uses 21 fewer bytes of free space.

2017-02-19 - Version 2.1 completed.
 > Smoothed out a minor sprite blip after Setzer gives the airship tutorial.
 > Uses 10 more bytes of free space than v2.0.

2019-06-03 - Version 2.2 completed.
 > When player resumes control of a character that is in the collapsed position,
   the character will be shown briefly in the crouch position before its
   standing sprite is shown. Player can interrupt this animation at any time
   by moving the character.
 > Full variant uses 33 more bytes of free space than v2.1.

2019-12-23 - Version 2.3 completed.
 > Character remains crouching after making jumps in Zozo.
 > Feature is bypassed on the Narshe snow maze.
 > Uses 27 more bytes of free space than v2.2.

2019-12-28 - Version 2.4 completed.
 > Proper Narshe snow maze support added.
 > Improved orientation detection (affects several scenes).
 > Improved transition timing from "walking south" pose.
 > Uses 8 more bytes of free space than v2.3. Who needs 'em!

2019-12-31 - Version 2.5 completed.
 > Character remains crouching after taking cover in Vector.
 > Fixed orientation detection for "bowing head left" pose.
 > Uses 8 more bytes of free space than v2.4.

2020-01-16 - Version 2.6 completed.
 > Fixed sprite ID errors affecting "bowing head left".
 > Documented all sprite IDs.

2020-01-19 - Version 2.7 completed.
 > Fixed transition out of jump animation in Daryl's Tomb.
 > Uses 8 more bytes of free space than v2.6.

2020-02-20 - Version 2.8 completed.
 > Fixed behavior when riding Magitek armor.
 > Added headerless ROM support.
 > Uses 4 more bytes of free space than v2.7.

2021-04-26 - Version 2.9 completed.
 > Resolved patching conflict with Lenophis' "Holy Randomness Batman!" (1.6).
 
________________________________________________________________________________

  3. CREDITS
________________________________________________________________________________

Imzogelmo, for his disassembly of bank C0 and his patch allocation list.
Novalia Spirit, for compiling the "100+ Bugs" list.
Master ZED, for some indirect inspiration (See the author's "Sliding Dash" fix).
Leet Sketcher, for finding a solution to the bug in version 1.0
Assassin, for suggesting space optimization for the new code in version 2.0.

Thanks to C. V. Reynolds & Squiffy for finding the bug in version 1.0.

________________________________________________________________________________

  4. LEGAL
________________________________________________________________________________

Copyright (C) 2020, 2021 David R. Thompson (SilentEnigma).

The copyright holder ("author") permits the free use of the attributed work
referenced by this document exclusively for non-commercial purposes, provided
that the following conditions are met:
1. The author and all contributors credited in this readme document shall be
 given credit for their respective contributions wherever the attributed work is
 reused, redistributed, or modified.
2. This readme document shall accompany any of the files comprising the
 attributed work wherever they are redistributed in unmodified form.

The work(s) and file(s) distributed with this document are provided "AS-IS",
WITHOUT ANY WARRANTY. The author shall not be held responsible for any damages
related to the use of work(s) and file(s) distributed with this document.

FINAL FANTASY is a registered trademark of Square Enix Holdings Co., Ltd.
FINAL FANTASY VI (C) 1994, 2006, 2014 SQUARE ENIX CO., LTD.

The author of the attributed work referenced by this document makes no claim to
FINAL FANTASY VI or any intellectual property contained therein.
