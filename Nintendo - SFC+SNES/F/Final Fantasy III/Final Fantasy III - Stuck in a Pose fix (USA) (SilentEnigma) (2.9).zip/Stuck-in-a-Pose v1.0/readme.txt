Title: Stuck in a Pose fix
Author: SilentEnigma
Version: 1.0
Release Date: February 20, 2016
Applies to: FF3us 1.0, FF3us 1.1
Tested on: FF3us 1.0, FF3us 1.1

NOTE: These patches are for HEADERED ROMs (3146240 bytes) only!

Contents:

    StuckInAPose.ips = the patch
	
    StuckInAPoseN.ips = the anti-patch
	
	readme.txt = this file
	
ROM Addresses:

    C0/49EF
	
Free space used: 38 bytes, C0/D6A2 - C0/D6C7

Urgency: Medium/Low. This bug pops up all over the place - when pausing on a staircase,
    after unequipping party members on the airship, at the end of several scenes when
	control is given back to the player... but these are fairly minor visual flaws.

____________________________________________________________________________________________


TABLE OF CONTENTS

0. Description
1. Relevant Offsets & Disassembly
2. Revision History
3. Credits
____________________________________________________________________________________________

0. DESCRIPTION

From Novalia Spirit's "100+ Bugs" Thread:

  After any event-dictated movement occurs, the hero sprite may appear to be stuck in its 
  last pose or its walking pose. The easiest way to see this is to go up and down some stairs.
  Most of the time, if you stop walking, the hero sprite should appear in a walking pose.
  Other examples of this are when you jump on a turtle, when trying to go up a conveyor belt
  to no avail, and after a scene where your party was split temporarily.
  ...
  One better example of this bug is when you're within the airship and talk to the guy 
  who can unequip your characters. While you do so, the hero sprite should look South and be 
  in a walking pose, yet, even if the said guy isn't South of the hero sprite, you can still 
  talk to him since the game still considers you're facing him.

____________________________________________________________________________________________

1. RELEVANT OFFSETS & DISASSEMBLY

Sprite I.D. table for walking animations:

C0/580D:	04 05 04 03     ; Unknown
C0/5811:	6E 6F 6E 6F     ; Unknown
C0/5815:	01 02 01 00     ; Unknown
C0/5819:	2E 2F 2E 2F     ; Unknown
C0/581D:	04 05 04 03     ; Character sprite moving Up
C0/5821:	47 48 47 46     ; Character sprite moving Right
C0/5825:	01 02 01 00     ; Character sprite moving Down
C0/5829:	07 08 07 06     ; Character sprite moving Left


Original code snippet, executed repeatedly when the player has control but is not pressing
any directional buttons:

C0/49EF:	AC0308  	LDY $0803
C0/49F2:	7B      	TDC 
C0/49F3:	997E08  	STA $087E,Y
C0/49F6:	9C8608  	STZ $0886
C0/49F9:	20A5C8  	JSR $C8A5
C0/49FC:	20F446  	JSR $46F4
C0/49FF:	20834B  	JSR $4B83
C0/4A02:	60      	RTS


Modified code:

C0/49EF: 20 A2 D6   	JSR $D6A2      ; Jump to new subroutine $D6A2

New Subroutine $D68D:

C0/D6A2:    48          PHA            ; Push previous accumulator value to stack
C0/D6A3:    B97F08      LDA $087F,Y    ; Load current direction value
C0/D6A6:    C901        CMP #$01       ; Facing right?
C0/D6A8:    D004        BNE $D6AE      ; Branch if not facing right
C0/D6AA:    A947        LDA #$47       ; Load sprite offset for standing, facing right
C0/D6AC:    8012        BRA $D6C0      ; Branch always
C0/D6AE:    C903        CMP #$03       ; Facing left?
C0/D6B0:    D004        BNE $D6B6      ; Branch if not facing left
C0/D6B2:    A907        LDA #$07       ; Load sprite offset for standing, facing left
C0/D6B4:    800A        BRA $D6C0      ; Branch always
C0/D6B6:    C900        CMP #$00       ; Facing forward?
C0/D6B8:    D004        BNE $D6BE      ; Branch if not facing forward
C0/D6BA:    A904        LDA #$04       ; Load sprite offset for standing, facing forward
C0/D6BC:    8002        BRA $D6C0      ; Branch always
C0/D6BE:    A901        LDA #$01       ; Load sprite offset for standing, facing backward
C0/D6C0:    997708      STA $0877,Y    ; Store sprite offset
C0/D6C3:    68          PLA            ; Pull previous accumulator value from stack
C0/D6C4:    AC0308      LDY $0803      ; From original C0/49EF
C0/D6C7     60          RTS            ; Return from subroutine

____________________________________________________________________________________________

3. REVISION HISTORY

February 20, 2016 - Version 1.0 completed.

____________________________________________________________________________________________

4. CREDITS

Imzogelmo, for providing a disassembly of bank C0 and for his patch allocation list.
Novalia Spirit, for compiling the "100+ Bugs" list.
Master ZED, for some indirect inspiration (See my "Sliding Dash" fix).
____________________________________________________________________________________________

Copyright (C) 2016 David Thompson (SilentEnigma).
The author intends for this readme document to accompany the distributed file.
The author expects to be given credit whenever his work is re-used or modified.
