Title: Description Expansion Megapack
Author: SilentEnigma
Version: 1.1
Release Date: 2023-11-27
Applies to: Final Fantasy III (v1.0) (U)

Archive Contents
-------------------------------

  24Mbit-to-32Mbit_H.ips        = ROM expansion patch for headered ROMs
  24Mbit-to-32Mbit_NH.ips       = ROM expansion patch for unheadered ROMs

  FF3us_Field-Menu.tbl          = hex editor char table for the FF3us field menu

  readme.txt                    = this file

  Blitz\                        = Blitz description expansion patches
    BlitzDescriptions_H.ips     = Basic (headered)
    BlitzDescriptions_NH.ips    = Basic (unheadered)
    BlitzDescriptions-BS_H.ips  = Compatible w/ "Blitz Screen" (headered)
    BlitzDescriptions-BS_NH.ips = Compatible w/ "Blitz Screen" (unheadered)

  Dance\                        = Dance description patches
    DanceDescriptions_H.ips     = (headered)
    DanceDescriptions_NH.ips    = (unheadered)

  Esper\                        = Esper ability description patches
    EsperDescriptions_H.ips     = (headered)
    EsperDescriptions_NH.ips    = (unheadered)
    EsperDescriptions-BS_H.ips  = Compatible w/ "Blitz Screen" (headered)
    EsperDescriptions-BS_NH.ips = Compatible w/ "Blitz Screen" (unheadered)

  Item\                         = Item description expansion patches
    ItemDescriptions_H.ips      = (headered)
    ItemDescriptions_NH.ips     = (unheadered)

  Lore\                         = Lore description expansion patches
    LoreDescriptions_H.ips      = Basic (headered)
    LoreDescriptions_NH.ips     = Basic (unheadered)
    LoreDescriptions-BS_H.ips   = Compatible w/ "Blitz Screen" (headered)
    LoreDescriptions-BS_NH.ips  = Compatible w/ "Blitz Screen" (unheadered)

  Magic\                        = Magic description expansion patches
    MagicDescriptions_H.ips     = Basic (headered)
    MagicDescriptions_NH.ips    = Basic (unheadered)
    MagicDescriptions-BS_H.ips  = Compatible w/ "Blitz Screen" (headered)
    MagicDescriptions-BS_NH.ips = Compatible w/ "Blitz Screen" (unheadered)

  Rage\                         = Rage description expansion patches
    RageDescriptions_H.ips      = Basic (headered)
    RageDescriptions_NH.ips     = Basic (unheadered)
    RageDescriptions-AZ_H.ips   = Compatible w/ "Alphabetical Rage" (headered)
    RageDescriptions-AZ_NH.ips  = Compatible w/ "Alphabetical Rage" (unheadered)


ROM Addresses
-------------------------------
BlitzDescriptions:     C3/5716 - C3/5717, C3/571B - C3/571C, C3/5720, C3/5724
BlitzDescriptions-BS:  C3/5727, C3/571B - C3/571E
DanceDescriptions:     C3/28AB - C3/28AC, C3/28AE - C3/28AF
EsperDescriptions:     C3/5C0A - C3/5C0B, C3/5C0F - C3/5C10, C3/5C14, C3/5C18
EsperDescriptions-BS:  C3/5724, C3/570F - C3/5712
ItemDescriptions:      C3/8309 - C3/830A, C3/830E - C3/830F, C3/8313, C3/8317
LoreDescriptions:      C3/56EC - C3/56ED, C3/56F1 - C3/56F2, C3/56F6, C3/56FA
LoreDescriptions-BS:   C3/5728, C3/571F - C3/5722
MagicDescriptions:     C3/5BE4 - C3/5BE5, C3/5BE9 - C3/5BEA, C3/5BEE, C3/5BF2
MagicDescriptions-BS:  C3/570B - C3/570E, C3/5723
RageDescriptions:      C3/28C1 - C3/28D2
RageDescriptions-AZ:   C3/28C1 - C3/28D2


Free Space Used
-------------------------------
DanceDescriptions:     C3/FD20 - C3/FD3A (27 bytes)
RageDescriptions:      C3/FD3B - C3/FD4D (19 bytes)
RageDescriptions-AZ:   C3/FD3B - C3/FD5E (36 bytes)


TABLE OF CONTENTS
-------------------------------
0. Description
1. Installation & Usage
2. Relevant Offsets & Disassembly
3. Credits
4. Revision History
5. Legal

________________________________________________________________________________

  0. DESCRIPTION
________________________________________________________________________________

        ~ In memory of Joseph Michael "Imzogelmo" Jarrell (1978-2020) ~

This is a collection of patches for expanding various ability and item
descriptions in FF3us for SNES. The following types are supported:

Moved & Expanded:
 - Blitz:  64 bytes per entry
 - Espers: 64 bytes per entry
 - Item:   96 bytes per entry
 - Lore:   64 bytes per entry
 - Magic:  80 bytes per entry

Newly Allocated:
 - Dance:  80 bytes per entry
 - Rage:   80 bytes per entry

Description entries are distributed evenly for convenient editing with a hex
editor.

Patches compatible with LeetSketcher's "Blitz Screen" and Assassin's
"Alphabetical Rage" are included.

________________________________________________________________________________

  1. INSTALLATION & USAGE
________________________________________________________________________________

Contents:

a. Patching Order
b. Description Editing

==================================================
 a. PATCHING ORDER
==================================================

The original FF3us cart size is 24 MBits.
The description patches require the ROM to be expanded to at least 28 Mbits.

 - If your ROM is not yet expanded (file size 3.0 MB), apply the appropriate
   "24Mbit-to-32Mbit" ROM expansion patch first.

 - If your ROM is already expanded (file size at least 3.5 MB), DO NOT apply the
   ROM expansion patch, as this will clear all existing data in the expanded
   portion of your ROM. Check the affected addresses of each patch for
   compatibility with your expanded data. (See section 2.a)

Once you have your expanded ROM, apply the appropriate (headered/non-headered,
compatible) patch for any of the six supported description types as desired:

 - Blitz descriptions expansion:

    > If your ROM has LeetSketcher's "Blitz Screen" applied, use the appropriate
      "BlitzDescriptions-BS" patch.

    > If your ROM does NOT have LeetSketcher's "Blitz Screen" applied, use the
      appropriate "BlitzDescriptions" basic patch.

 - Dance descriptions: Use the appropriate "DanceDescriptions" patch.

 - Esper ability descriptions expansion:

    > If your ROM has LeetSketcher's "Blitz Screen" applied, use the appropriate
      "EsperDescriptions-BS" patch.

    > If your ROM does NOT have LeetSketcher's "Blitz Screen" applied, use the
      appropriate "EsperDescriptions" basic patch.

 - Item descriptions expansion: Use the appropriate "ItemDescriptions" patch.

 - Lore descriptions expansion:

    > If your ROM has LeetSketcher's "Blitz Screen" applied, use the appropriate
      "LoreDescriptions-BS" patch.

    > If your ROM does NOT have LeetSketcher's "Blitz Screen" applied, use the
      appropriate "LoreDescriptions" basic patch.

 - Magic descriptions expansion:

    > If your ROM has LeetSketcher's "Blitz Screen" applied, use the appropriate
      "MagicDescriptions-BS" patch.

    > If your ROM does NOT have LeetSketcher's "Blitz Screen" applied, use the
      appropriate "MagicDescriptions" basic patch.

 - Rage descriptions:

    > If your ROM has Assassin's "Alphabetical Rage" applied, use the
      appropriate "RageDescriptions-AZ" patch.

    > If your ROM does NOT Assassin's "Alphabetical Rage" applied, use the
      appropriate "RageDescriptions" patch.

==================================================
 b. DESCRIPTION EDITING
==================================================

Use a hex editor with table support such as WindHex to edit description text.

A table file for the FF3us field menu is included in the archive:
"FF3us_Field-Menu.tbl"

Each entry must be terminated with the null character, 00h.
Text wrapping must be handled manually. The line break character value is 01h.

The following table gives the new starting address of the text data for each
supported description type.

                    unheadered  headered
Type     HiROM      file        file
-----    --------------------------------
Blitz    F2/5630    0x325630    0x325830

Dance    F2/1200    0x321200    0x321400

Espers   F3/E800    0x33E800    0x33EA00

Item     F3/2000    0x332000    0x332200

Lore     F2/5000    0x325000    0x325200

Magic    F3/0000    0x330000    0x330200

Rage     F3/9000    0x339000    0x339200

________________________________________________________________________________

  2. RELEVANT OFFSETS & DISASSEMBLY
________________________________________________________________________________

Contents:

a. Blitz
b. Dance
c. Espers
d. Item
e. Lore
f. Magic
g. Rage

=================================================
 a. BLITZ
=================================================

Blitz descriptions now reproduced at F2/5630 - F2/582F (64 bytes per entry)

Pointer offsets:
 F2/5830: 00 00 40 00 80 00 C0 00 00 01 40 01 80 01 C0 01


"BlitzDescriptions" Basic Only
-------------------------------
Original:
 C3/5715: A2 9E FF    LDX #$FF9E    ; Blitz description pointer offsets addr
 C3/5718: 86 E7       STX $E7
 C3/571A: A2 00 FC    LDX #$FC00    ; Blitz description data starting addr
 C3/571D: 86 EB       STX $EB
 C3/571F: A9 CF       LDA #$CF      ; Bank for Blitz description pointer offsets
 C3/5721: 85 E9       STA $E9
 C3/5723: A9 CF       LDA #$CF      ; Bank for Blitz descriptions
 C3/5725: 85 ED       STA $ED
Modified:
 C3/5715: A2 30 58    LDX #$5830    ; Blitz description pointer offsets addr
 C3/5718: 86 E7       STX $E7
 C3/571A: A2 30 56    LDX #$5630    ; Blitz description data starting addr
 C3/571D: 86 EB       STX $EB
 C3/571F: A9 F2       LDA #$F2      ; Bank for Blitz description pointer offsets
 C3/5721: 85 E9       STA $E9
 C3/5723: A9 F2       LDA #$F2      ; Bank for Blitz descriptions
 C3/5725: 85 ED       STA $ED


"BlitzDescriptions-BS" Only
-------------------------------
BlitzScreen:
 C3/5727: CF     ; Bank for Blitz description data & pointer offsets
Modified:
 C3/5727: F2     ; Bank for Blitz description data & pointer offsets

BlitzScreen:
 C3/571B: 9E FF  ; Blitz description pointer offsets addr
 C3/571D: 00 FC  ; Blitz description data base addr
Modified:
 C3/571B: 30 58  ; Blitz description pointer offsets addr
 C3/571D: 30 56  ; Blitz description data base addr


=================================================
 b. DANCE
=================================================

Dance descriptions allocated at F2/1200 - F2/147F (80 bytes per entry)

Pointer offsets:
 F2/11F0: 00 00 50 00 A0 00 F0 00 40 01 90 01 E0 01 30 02

Original:
 C3/28AA: 20 FD 0E    JSR $0EFD
 C3/28AD: 20 D4 4B    JSR $4BD4
Modified:
 C3/28AA: 20 20 FD    JSR $FD20     ; new subroutine C3/FD20
 C3/28AD: 20 2A 57    JSR $572A     ; set up the appropriate string (or blank)

New Subroutine C3/FD20 (Set up Dance descriptions):
 C3/FD20: A9 10       LDA #$10
 C3/FD22: 14 45       TRB $45
 C3/FD24: 20 FD 0E    JSR $0EFD
 C3/FD27: 20 D4 4B    JSR $4BD4
 C3/FD2A: A2 F0 11    LDX #$11F0    ; Dance description pointer offsets addr
 C3/FD2D: 86 E7       STX $E7
 C3/FD2F: A2 00 12    LDX #$1200    ; Dance description data starting addr
 C3/FD32: 86 EB       STX $EB
 C3/FD34: A9 F2       LDA #$F2      ; Bank for Dance description data & pointers
 C3/FD36: 85 E9       STA $E9
 C3/FD38: 85 ED       STA $ED
 C3/FD3A: 60          RTS


=================================================
 c. ESPERS
=================================================

Esper descriptions now reproduced at F3/E800 - F3/EEBF (64 bytes per entry)

Pointer offsets:
 F3/E7C0: 00 00 40 00 80 00 C0 00 00 01 40 01 80 01 C0 01
 F3/E7D0: 00 02 40 02 80 02 C0 02 00 03 40 03 80 03 C0 03
 F3/E7E0: 00 04 40 04 80 04 C0 04 00 05 40 05 80 05 C0 05
 F3/E7E0: 00 06 40 06 80 06


"EsperDescriptions" Basic Only
-------------------------------

Original:
 C3/5C09: A2 40 FE    LDX #$FE40   ; Esper description pointer offsets addr
 C3/5C0C: 86 E7       STX $E7
 C3/5C0E: A2 40 39    LDX #$3940   ; Esper description data starting addr
 C3/5C11: 86 EB       STX $EB
 C3/5C13: A9 CF       LDA #$CF     ; Bank for Esper description pointer offsets
 C3/5C15: 85 E9       STA $E9
 C3/5C17: A9 CF       LDA #$CF     ; Bank for Esper descriptions
 C3/5C19: 85 ED       STA $ED
 C3/5C1B: 60          RTS
Modified:
 C3/5C09: A2 C0 E7    LDX #$E7C0   ; Esper description pointer offsets addr
 C3/5C0C: 86 E7       STX $E7
 C3/5C0E: A2 00 E8    LDX #$E800   ; Esper description data starting addr
 C3/5C11: 86 EB       STX $EB
 C3/5C13: A9 F3       LDA #$F3     ; Bank for Esper description pointer offsets
 C3/5C15: 85 E9       STA $E9
 C3/5C17: A9 F3       LDA #$F3     ; Bank for Esper descriptions
 C3/5C19: 85 ED       STA $ED
 C3/5C1B: 60          RTS


"EsperDescriptions-BS" Only
-------------------------------
BlitzScreen:
 C3/5724: CF     ; Bank for Esper description data & pointer offsets
Modified:
 C3/5724: F3     ; Bank for Esper description data & pointer offsets

BlitzScreen:
 C3/570F: 40 FE  ; Esper description pointer offsets addr
 C3/5711: 40 39  ; Esper description data base addr
Modified:
 C3/570F: C0 E7  ; Esper description pointer offsets addr
 C3/5711: 00 E8  ; Esper description data base addr


=================================================
 d. ITEM
=================================================

Item descriptions now reproduced at F3/2000 - F3/7FFF (96 bytes per entry)

Pointer Offsets:
 F3/1E00: 00 00 60 00 C0 00 20 01 80 01 E0 01 40 02 A0 02
 ...
 F3/1FF0: 00 5D 60 5D C0 5D 20 5E 80 5E E0 5E 40 5F A0 5F

Original:
 C3/8308: A2 A0 7A    LDX #$7AA0    ; Item description pointer offsets addr
 C3/830B: 86 E7       STX $E7
 C3/830D: A2 00 64    LDX #$6400    ; Item description data starting addr
 C3/8310: 86 EB       STX $EB
 C3/8312: A9 ED       LDA #$ED      ; Bank for Item description pointer offsets
 C3/8314: 85 E9       STA $E9
 C3/8316: A9 ED       LDA #$ED      ; Bank for Item descriptions
 C3/8318: 85 ED       STA $ED
Modified:
 C3/8308: A2 00 1E    LDX #$1E00    ; Item description pointer offsets addr
 C3/830B: 86 E7       STX $E7
 C3/830D: A2 00 20    LDX #$2000    ; Item description data starting addr
 C3/8310: 86 EB       STX $EB
 C3/8312: A9 F3       LDA #$F3      ; Bank for Item description pointer offsets
 C3/8314: 85 E9       STA $E9
 C3/8316: A9 F3       LDA #$F3      ; Bank for Item descriptions
 C3/8318: 85 ED       STA $ED


=================================================
 e. LORE
=================================================

Lore descriptions now reproduced at F2/5000 - F2/55FF (64 bytes per entry)

Pointer Offsets:
 F2/5600: 00 00 40 00 80 00 C0 00 00 01 40 01 80 01 C0 01
 F2/5610: 00 02 40 02 80 02 C0 02 00 03 40 03 80 03 C0 03
 F2/5620: 00 04 40 04 80 04 C0 04 00 05 40 05 80 05 C0 05


"LoreDescriptions" Basic Only
-------------------------------
Original:
 C3/56EB: A2 70 7A    LDX #$7A70    ; Lore description pointer offsets addr
 C3/56EE: 86 E7       STX $E7
 C3/56F0: A2 A0 77    LDX #$77A0    ; Lore description data starting addr
 C3/56F3: 86 EB       STX $EB
 C3/56F5: A9 ED       LDA #$ED      ; Bank for Lore description pointer offsets
 C3/56F7: 85 E9       STA $E9
 C3/56F9: A9 ED       LDA #$ED      ; Bank for Lore descriptions
 C3/56FB: 85 ED       STA $ED
Modified:
 C3/56EB: A2 00 56    LDX #$5600    ; Lore description pointer offsets addr
 C3/56EE: 86 E7       STX $E7
 C3/56F0: A2 00 50    LDX #$5000    ; Lore description data starting addr
 C3/56F3: 86 EB       STX $EB
 C3/56F5: A9 F2       LDA #$F2      ; Bank for Lore description pointer offsets
 C3/56F7: 85 E9       STA $E9
 C3/56F9: A9 F2       LDA #$F2      ; Bank for Lore descriptions
 C3/56FB: 85 ED       STA $ED


"LoreDescriptions-BS" Only
-------------------------------
BlitzScreen:
 C3/5728: ED     ; Bank for Lore description & pointer offsets
Modified:
 C3/5728: F2     ; Bank for Lore description & pointer offsets

BlitzScreen:
 C3/571F: 70 7A  ; Lore description pointer offsets addr
 C3/5721: A0 77  ; Lore description data starting addr
Modified:
 C3/571F: 00 56  ; Lore description pointer offsets addr
 C3/5721: 00 50  ; Lore description data starting addr


=================================================
 f. MAGIC
=================================================

Magic descriptions now reproduced at F3/0000 - F3/10DF (80 bytes per entry)

Pointer offsets:
 F3/10E0: 00 00 50 00 A0 00 F0 00 40 01 90 01 E0 01 30 02
 ...
 F3/1140: 00 0F 50 0F A0 0F F0 0F 40 10 90 10


"MagicDescriptions" Basic Only
-------------------------------
Original:
 C3/5BE3: A2 80 CF    LDX #$CF80    ; Magic description pointer offsets addr
 C3/5BE6: 86 E7       STX $E7
 C3/5BE8: A2 A0 C9    LDX #$C9A0    ; Magic description data starting addr
 C3/5BEB: 86 EB       STX $EB
 C3/5BED: A9 D8       LDA #$D8      ; Bank for Magic description pointer offsets
 C3/5BEF: 85 E9       STA $E9
 C3/5BF1: A9 D8       LDA #$D8      ; Bank for Magic descriptions
 C3/5BF3: 85 ED       STA $ED
Modified:
 C3/5BE3: A2 E0 10    LDX #$10E0    ; Magic description pointer offsets addr
 C3/5BE6: 86 E7       STX $E7
 C3/5BE8: A2 00 00    LDX #$0000    ; Magic description data starting addr
 C3/5BEB: 86 EB       STX $EB
 C3/5BED: A9 F3       LDA #$F3      ; Bank for Magic description pointer offsets
 C3/5BEF: 85 E9       STA $E9
 C3/5BF1: A9 F3       LDA #$F3      ; Bank for Magic descriptions
 C3/5BF3: 85 ED       STA $ED


"MagicDescriptions-BS" Only
-------------------------------
BlitzScreen:
 C3/570B: 80 CF  ; Magic description pointer offsets addr
 C3/570D: A0 C9  ; Magic description data starting addr
Modified:
 C3/570B: E0 10  ; Magic description pointer offsets addr
 C3/570D: 00 00  ; Magic description data starting addr

BlitzScreen:
 C3/5723: D8     ; Bank for Magic descriptions & pointer offsets
Modified:
 C3/5723: F3     ; Bank for Magic descriptions & pointer offsets


=================================================
 g. RAGE
=================================================

Rage Descriptions allocated at F3/9000 - F3/DFFF (80 bytes per entry)

Pointer offsets:
 F3/8E00: 00 00 50 00 A0 00 F0 00 40 01 90 01 E0 01 30 02
 ...
 F3/8FF0: 80 4D D0 4D 20 4E 70 4E C0 4E 10 4F 60 4F B0 4F

Original:
 C3/28C1: 20 64 1F    JSR $1F64
 C3/28C4: B0 0C       BCS $28D2
 C3/28C6: 20 52 4C    JSR $4C52
 C3/28C9: A5 09       LDA $09
 C3/28CB: 89 80       BIT #$80
 C3/28CD: F0 03       BEQ $28D2
 C3/28CF: 20 A5 29    JSR $29A5
 C3/28D2: 60          RTS
Modified:
 C3/28C1: A9 10       LDA #$10
 C3/28C3: 14 45       TRB $45
 C3/28C5: 20 64 1F    JSR $1F64     ; original C3/28C1
 C3/28C8: B0 06       BCS $28D0     ; original C3/28C4
 C3/28CA: 20 52 4C    JSR $4C52     ; original C3/28C6
 C3/28CD: 20 3B FD    JSR $FD3B     ; New Subroutine C3/FD3B
 C3/28D0: 60          RTS
 C3/28D1: EA EA       NOP x2


"RageDescriptions" Basic Only
-------------------------------
New Subroutine C3/FD3B:
 C3/FD3B: A2 00 8E    LDX #$8E00    ; Rage description pointer offsets addr
 C3/FD3E: 86 E7       STX $E7
 C3/FD40: A2 00 90    LDX #$9000    ; Rage description data starting addr
 C3/FD43: 86 EB       STX $EB
 C3/FD45: A9 F3       LDA #$F3      ; Bank for Rage description data & pointers
 C3/FD47: 85 E9       STA $E9
 C3/FD49: 85 ED       STA $ED
 C3/FD4B: 4C AD 28    JMP $28AD


"RageDescriptions-AZ" Only
-------------------------------
New Subroutine C3/FD3B:
 C3/FD3B: A2 00 8E    LDX #$8E00    ; Rage description pointer offsets addr
 C3/FD3E: 86 E7       STX $E7
 C3/FD40: A2 00 90    LDX #$9000    ; Rage description data starting addr
 C3/FD43: 86 EB       STX $EB
 C3/FD45: A9 F3       LDA #$F3      ; Bank for Rage description data & pointers
 C3/FD47: 85 E9       STA $E9
 C3/FD49: 85 ED       STA $ED
 C3/FD4B: A2 C9 9E    LDX #$9EC9    ; original C3/572A
 C3/FD4E: 8E 81 21    STX $2181     ; original C3/572D
 C3/FD51: 7B          TDC           ; original C3/5730
 C3/FD52: A5 4B       LDA $4B       ; original C3/5731
 C3/FD54: AA          TAX           ; original C3/5733
 C3/FD55: BF D0 FA C2 LDA $C2FAD0,X ; AZ sort index translation (from AZ Rage)
 C3/FD59: 20 33 57    JSR $5733     ; new alt entry for subroutine C3/572A
 C3/FD5C: 4C B0 28    JMP $28B0

________________________________________________________________________________

  3. CREDITS
________________________________________________________________________________


dn - Base implementation for Dance & Rage descriptions
https://www.ff6hacking.com/forums/user-935.html

Leet Sketcher - Blitz Screen author
http://www.l33t5k37ch3r.altervista.org/

Assassin - Alphabetical Rage author
http://assassin17.brinkster.net/

Thanks to:

  Imzogelmo, for his disassembly of bank C3
  http://www.angelfire.com/al2/imzogelmo/patches.html

  Lord J et al., for the FF3usME utility used for ROM expansion
  http://www.angelfire.com/pq/jumparound/

________________________________________________________________________________

  4. REVISION HISTORY
________________________________________________________________________________


2021-11-27 : Version 1.0 released

2023-11-27 : Version 1.1 released
  - Added support for Esper ability descriptions

________________________________________________________________________________

  5. LEGAL
________________________________________________________________________________

Copyright (C) 2021, 2023 David R. Thompson (SilentEnigma).

The copyright holder ("author") permits the free use of the attributed work
referenced by this document exclusively for non-commercial purposes, provided
that the following conditions are met:
1. The author and all contributors credited in this readme document shall be
 given credit for their respective contributions wherever the attributed work is
 reused, redistributed, or modified.
2. This readme document shall accompany any of the files comprising the
 attributed work wherever they are redistributed in unmodified form.

The work(s) and file(s) distributed with this document are provided "AS-IS",
WITHOUT ANY WARRANTY. The author shall not be held responsible for any damages
related to the use of work(s) and file(s) distributed with this document.
