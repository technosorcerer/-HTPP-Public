|----------------------------------------------|
| Mastered Esper Icon Hack                     |
| by: madsiur                                  |
| version: 1.2                                 |
| Released on: June 29th, 2024                 |
| apply to: FF3us 1.0 (no header)              |
|----------------------------------------------|

|----------------------------------------------|
| Files                                        |
|----------------------------------------------|

mastered-nh.ips: IPS patch for vanilla ROM (user's color icon)
mastered-yellow-nh.ips: IPS patch for vanilla ROM (yellow icon)
asm/: folder containing the bass assembly files of the two hacks
asm/star.bin: 8x8 2BPP star icon used for the hack

|----------------------------------------------|
| Description                                  |
|----------------------------------------------|

This hack adds a star icon to each mastered Esper in the
Esper menu. An Esper is mastered when all its spells are
learned. There's a version of the hack that draws a yellow
star instead of the user's color (white by default). This
yellow option was made possible with bits of BNW and 
BC randomizer code (thanks to Myria and Ryo). You can 
specify a different icon and disable star icon insertion 
in any of the assembly files.

The default hack uses 130 bytes of free space while the
yellow option uses 179 bytes of free space at $EEAF01.
This free space offsets can be changed in the bass asm 
file by changing the offset of the "seek($EEAF01)" 
macro call. The hacks use no free space in bank $C3.

To assemble the hack use bass v14 by typing a command
such as "bass -o rom.smc mastered.asm".

|----------------------------------------------|
| Links                                        |
|----------------------------------------------|

bass v14:
https://www.romhacking.net/utilities/794/

|----------------------------------------------|
| Version history                              |
|----------------------------------------------|

Version 1.2 (2024/06/29):
-Replaced blue star option with the yellow one
-Removed RAN patches for now (I might restore them in the future)

Version 1.1 (2022/03/27):
-Fixed a bug with the icon when scrolling with L/R

Version 1.0 (2022/02/22):
-Initial release

|----------------------------------------------|
| Download pages                               |
|----------------------------------------------|

Personal website:
https://www.fred65816/en/romhacking/hacks/mastered-esper

FF6Hacking wiki:
https://www.ff6hacking.com/wiki/doku.php?id=ff3:ff3us:patches:madsiur:mastered

RHDN page:
https://www.romhacking.net/hacks/6717/s

