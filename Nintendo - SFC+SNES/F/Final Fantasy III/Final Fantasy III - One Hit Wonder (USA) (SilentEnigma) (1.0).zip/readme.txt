Title: One-Hit Wonder
Author: SilentEnigma
Version: 1.0
Release Date: 2024-05-19
Applies to: Final Fantasy III (v1.0) (U)
            Final Fantasy III (v1.1) (U)
            Final Fantasy VI (J)

Archive Contents
-------------------------------

  readme.txt                  = this file

  OneHitWonder_J_H.ips        = patch for headered FF6j ROMs
  OneHitWonder_J_H_Anti.ips   = anti-patch

  OneHitWonder_J_NH.ips       = patch for unheadered FF6j ROMs
  OneHitWonder_J_NH_Anti.ips  = anti-patch

  OneHitWonder_U_H.ips        = patch for headered FF3us ROMs
  OneHitWonder_U_H_Anti.ips   = anti-patch

  OneHitWonder_U_NH.ips       = patch for unheadered FF3us ROMs
  OneHitWonder_U_NH_Anti.ips  = anti-patch

  OneHitWonder_CV_H.ips       = compatible with C. V. Bug-Fix Comp. (headered)
  OneHitWonder_CV_H_Anti.ips  = anti-patch

  OneHitWonder_CV_NH.ips      = compatible with C. V. Bug-Fix Comp. (unheadered)
  OneHitWonder_CV_NH_Anti.ips = anti-patch


ROM Addresses
-------------------------------

FF6j (SFC):   C2/1D4A - C2/1D4D, C2/1D64 - C2/1D65, CF/86EA, CF/BF1C - CF/BF34

FF3us (SNES): C2/1D4F - C2/1D52, C2/1D69 - C2/1D6A, CF/86EA, CF/BF1C - CF/BF34


Free Space Used
-------------------------------

FF6j (SFC):   C2/FBF2 - C2/FC28 (55 bytes)

FF3us (SNES): C2/65B3 - C2/65BD, C2/65CF - C2/65D7, C2/65FC - C2/6617,
              C2/FBE2 - C2/FBF8 (55 bytes)

Urgency
-------------------------------
Medium. While this bug occurs on every playthrough, the original battle was
never going to be particularly difficult anyway. The issue is hardly ever
discussed or acknowleged in the FF6 community.


TABLE OF CONTENTS
-------------------------------

0. Description
1. Relevant Offsets & Disassembly
2. Credits
3. Revision History
4. Legal

________________________________________________________________________________

  0. DESCRIPTION
________________________________________________________________________________

This patch for FF3us/FF6j (SNES/SFC) fixes a bug with the monster script during
the cinematic battle with Kefka at the Sealed Gate.

The original script is fairly elaborate, specifying multiple special attacks and
counterattacks for Kefka to use. A naive reading of the script suggests that the
battle's closing scene should be triggered once "monster #1" (i.e. Kefka)
reaches KO status.

However, Kefka is programmed into the battle as a party member replacing Terra.
He is not a "monster" here, so checking for a monster being KO'd gives a false
positive. This results in the battle ending as soon as the player hits Kefka a
single time.

The issue is difficult to work around using other targeted status checks, as the
monster script operation "target self" (0xF1+0x36) is broken when used in this
battle. (The operation happens to clear all character targets, but in this rare
case, "self" IS a character!)

A straightforward fix yields less-than-ideal results. If the battle stops upon
Kefka reaching KO status, the ending scene plays out with Kefka on his back.

This patch stops the battle once Kefka has reached either KO or Critical status,
or upon Kefka getting hit after a certain amount of time has passed. If Kefka is
KO'd, he will be revived for the ending scene.

Archive includes patches compatible with FF6j, vanilla FF3us, and the C. V.
Reynolds Bug-Fix Compilation (tested with version 2.9).

________________________________________________________________________________

  1. RELEVANT OFFSETS & DISASSEMBLY
________________________________________________________________________________

Contents:

a. Assembly
b. Battle Script

==================================================
 a. ASSEMBLY
==================================================

FF3 U/SNES
-------------------------------

Original:
 C2/1D4F: 64 FC       STZ $FC       ; Clear character targets
 C2/1D51: 64 FC       STZ $FC       ; Clear them again (no known purpose)
Modified:
 C2/1D4F: 20 F2 FB    JSR $FBF2     ; new subroutine C2/FBF2
 C2/1D52: EA          NOP

Original:
 C2/1D69: 2C 1D     ; (0A) (No counter)
Modified:
 C2/1D69: CF 65     ; Special check - new subroutine C2/65CF

New Subroutine C2/65B3:
 C2/65B3: B0 08       BCS $65BD    ; if yes, return now
 C2/65B5: A9 07       LDA #$07     ; dead/KO status
 C2/65B7: 8D 2F 3A    STA $3A2F    ; second byte for FC
 C2/65BA: 4C D7 1B    JMP $1BD7    ; Command 08 for FC - check for status
 C2/65BD: 60          RTS

New Subroutine C2/65CF - Command 0A for FC:
 C2/65CF: AD 2F 3A    LDA $3A2F
 C2/65D2: 20 FC 65    JSR $65FC ; new subroutine
 C2/65D5: 4C B3 65    JMP $65B3 ; new subroutine

New Subroutine C2/65FC:
 C2/65FC: 48          PHA
 C2/65FD: 9C 2F 3A    STZ $3A2F
 C2/6600: 20 7F 1C    JSR $1C7F
 C2/6603: E2 20       SEP #$20     ; 8 bit accum./mem
 C2/6605: 68          PLA
 C2/6606: B0 0D       BCS $6615    ; if yes, return now
 C2/6608: 8D 2E 3A    STA $3A2E
 C2/660B: A9 09       LDA #$09     ; critical status
 C2/660D: 8D 2F 3A    STA $3A2F    ; second byte for FC
 C2/6610: 5A          PHY
 C2/6611: 20 D7 1B    JSR $1BD7    ; Command 08 for FC - check for status
 C2/6614: 7A          PLY
 C2/6615: E2 20       SEP #$20     ; 8 bit accum./mem
 C2/6617: 60          RTS

New Subroutine C2/FBF2:
 C2/FBF2: A5 FD       LDA $FD       ; monster mask
 C2/FBF4: F0 02       BEQ $FBF8     ; branch if empy
 C2/FBF6: 64 FC       STZ $FC       ; clear character targets
 C2/FBF8: 60          RTS


FF6 J/SFC Only
-------------------------------

Original:
 C2/1D4A: 64 FC       STZ $FC       ; Clear character targets
 C2/1D4C: 64 FC       STZ $FC       ; Clear them again (no known purpose)
Modified:
 C2/1D4A: 20 F2 FB    JSR $FBF2     ; new subroutine C2/FBF2
 C2/1D4C: EA          NOP

Original:
 C2/1D64: 27 1D     ; (0A) (No counter)
Modified:
 C2/1D64: F9 FB     ; Special check - new subroutine C2/FBF9

New Subroutine C2/FBF2:
 C2/FBF2: A5 FD       LDA $FD       ; monster mask
 C2/FBF4: F0 02       BEQ $FBF8     ; branch if empy
 C2/FBF6: 64 FC       STZ $FC       ; clear character targets
 C2/FBF8: 60          RTS

New Subroutine C2/FBF9 - Command 0A for FC:
 C2/FBF9: AD 2F 3A    LDA $3A2F
 C2/FBFC: 20 02 FC    JSR $FC02 ; new subroutine
 C2/FBFF: 4C 1E FC    JMP $FC1E ; new subroutine

New Subroutine C2/FC02:
 C2/FC02: 48          PHA
 C2/FC03: 9C 2F 3A    STZ $3A2F
 C2/FC06: 20 7A 1C    JSR $1C7A
 C2/FC09: E2 20       SEP #$20     ; 8 bit accum./mem
 C2/FC0B: 68          PLA
 C2/FC0C: B0 0D       BCS $FC1B    ; if yes, return now
 C2/FC0E: 8D 2E 3A    STA $3A2E
 C2/FC11: A9 09       LDA #$09     ; critical status
 C2/FC13: 8D 2F 3A    STA $3A2F    ; second byte for FC
 C2/FC16: 5A          PHY
 C2/FC17: 20 D2 1B    JSR $1BD2    ; Command 08 for FC - check for status
 C2/FC1A: 7A          PLY
 C2/FC1B: E2 20       SEP #$20     ; 8 bit accum./mem
 C2/FC1D: 60          RTS

New Subroutine C2/FC1E:
 C2/FC1E: B0 08       BCS $FC28    ; if yes, return now
 C2/FC20: A9 07       LDA #$07     ; dead/KO status
 C2/FC22: 8D 2F 3A    STA $3A2F    ; second byte for FC
 C2/FC25: 4C D2 1B    JMP $1BD2    ; Command 08 for FC - check for status
 C2/FC28: 60          RTS

==================================================
 c. BATTLE SCRIPT
==================================================

Common
-------------------------------

New custom "If" statement check is added to the monster script:
FC 0A xx xx

Format:

FC = if
0A = special check:
xx = the global timer has exceeded this amount, or
xx = (target) is dead or critical


FF6 J/SFC, FF3 U/SNES Vanilla
-------------------------------

Original:
 CF/86EA: 32 38 ; pointer to monster script #373
Modified:
 CF/86EA: 35 38 ; pointer to monster script #373

Original:
 ; Monster #372 (cont.)
 CF/BF1B: FC 12 00 00  ; If following monster is/are dead:
 CF/BF1F: F3 4B 00     ; Text: " [The, the door's opening!<D>] "
 CF/BF22: FB 02 00     ; Ends battle
 CF/BF25: FE           ; End If and reset targeting
 CF/BF26: FC 05 00 00  ; If monster has been attacked
 CF/BF2A: F0 EE FE FE  ; Rand. spell: Battle or Nothing or Nothing
 CF/BF2E: F8 00 81     ; 1 added to VAR000
 CF/BF31: FF           ; End
 ; Monster #373
 CF/BF32: F0 EE EE EE  ; Rand. spell: Battle or Battle or Battle
Modified:
 ; Monster #372 (cont.)
 CF/BF1B: FC 0A 40 36  ; NEW: if global timer > 40 or target 0x36 is KO/critical
 CF/BF1F: FB 0C 07     ; Monster loses status: Death
 CF/BF22: F3 4B 00     ; Text: " [The, the door's opening!<D>] "
 CF/BF25: FB 02 00     ; Ends battle
 CF/BF28: FE           ; End If and reset targeting
 CF/BF29: FC 05 00 00  ; If monster has been attacked
 CF/BF2D: F0 EE FE FE  ; Rand. spell: Battle or Nothing or Nothing
 CF/BF31: F8 00 81     ; 1 added to VAR000
 CF/BF34: FF           ; End
 ; Monster #373
 CF/BF35: EE           ; Battle


C.V. Bug-Fix Comp. Only
-------------------------------

Original:
 CF/86EA: 2D 38 ; pointer to monster script #373
Modified:
 CF/86EA: 30 38 ; pointer to monster script #373

Original:
 ; Monster #372 (cont.)
 CF/BF16: FC 12 00 00  ; If following monster is/are dead:
 CF/BF1A: F3 4B 00     ; Text: " [The, the door's opening!<D>] "
 CF/BF1D: FB 02 00     ; Ends battle
 CF/BF20: FE           ; End If and reset targeting
 CF/BF21: FC 05 00 00  ; If monster has been attacked
 CF/BF25: F0 EE FE FE  ; Rand. spell: Battle or Nothing or Nothing
 CF/BF29: F8 00 81     ; 1 added to VAR000
 CF/BF2C: FF           ; End
 ; Monster #373
 CF/BF2D: F0 EE EE EE  ; Rand. spell: Battle or Battle or Battle
Modified:
 ; Monster #372 (cont.)
 CF/BF16: FC 0A 40 36  ; NEW: if global timer > 40 or target 0x36 is KO/critical
 CF/BF1A: FB 0C 07     ; Monster loses status: Death
 CF/BF1D: F3 4B 00     ; Text: " [The, the door's opening!<D>] "
 CF/BF20: FB 02 00     ; Ends battle
 CF/BF23: FE           ; End If and reset targeting
 CF/BF24: FC 05 00 00  ; If monster has been attacked
 CF/BF28: F0 EE FE FE  ; Rand. spell: Battle or Nothing or Nothing
 CF/BF2C: F8 00 81     ; 1 added to VAR000
 CF/BF2F: FF           ; End
 ; Monster #373
 CF/BF30: EE           ; Battle

________________________________________________________________________________

  2. CREDITS
________________________________________________________________________________

Special Thanks:

  Lord J, for the FF3us Multi Editor utility
  https://www.angelfire.com/pq/jumparound/

  BTB, for the battle script tutorial/map document
  http://ngplus.net/index.php?/profile/96-btb/

  Imzogelmo, for his patch allocation document
  http://www.angelfire.com/al2/imzogelmo/patches.html

________________________________________________________________________________

  3. REVISION HISTORY
________________________________________________________________________________


2024-05-19 : Version 1.0 released

________________________________________________________________________________

  4. LEGAL
________________________________________________________________________________


Copyright (C) 2024 David R. Thompson (SilentEnigma).

The copyright holder ("author") permits the free use of the attributed work
referenced by this document exclusively for non-commercial purposes, provided
that the following conditions are met:
1. The author and all contributors credited in this readme document shall be
 given credit for their respective contributions wherever the attributed work is
 reused, redistributed, or modified.
2. This readme document shall accompany any of the files comprising the
 attributed work wherever they are redistributed in unmodified form.

The work(s) and file(s) distributed with this document are provided "AS-IS",
WITHOUT ANY WARRANTY. The author shall not be held responsible for any damages
related to the use of work(s) and file(s) distributed with this document.
