--------------------------------------------About---------------------------------------------
Patch: Final Fantasy VI - GBA Text & Final Fantasy VI - GBA Text Minus Pop-Culture References
Author: MoleMan
Version: 1.5
Date: 3/25/2024

----------------------------------------Apply Patch To----------------------------------------
Name: Final Fantasy III (USA)
CRC32: A27F1C7A
MD5: E986575B98300F721CE27C180264D890
SHA-1: 4F37E4274AC3B2EA1BEDB08AA149D8FC5BB676E7

-----------------------------------------Introduction-----------------------------------------
After playing a couple hours of Rodimus Primal's "Final Fantasy VI - Ted Woolsey Uncensored 
Edition" and hairy_hen's "Final Fantasy VI: Retranslated," I was amazed to see how fans were 
able to create and present their own visions of a beloved classic. After learning about some 
of the tools available to edit Final Fantasy 6, I felt inspired to create the translation of 
the game that I had hoped to find.

The "GBA Text" version of the patch uses the original text directly from Final Fantasy VI
Advance, including the pop-culture references. The "GBA Text Minus Pop-Culture References"
version of the patch removes or replaces these lines.

---------------------------------------Included Patches---------------------------------------
-Original Final Fantasy VI Title Screen (Yazoo)
-B Button Dash (Version C patch) (Master Zed)
-Sliding Dash (SilentEnigma)
-Kefka Final Battle Tiers Graphics (Dr Meat)
-Restore Ability Names (angelo)
-Extended item descriptions (Dr Meat)
-Gogo Yellow Streak (assassin17)
-Esper Battle Menu MP Fix (Lenophis)
-Tritoch Graphical Fix (bydoless)
-Auction Chocobo Fix (Madsiur)
-Inconsistent Gungho (assassin17)
-Gerard and Sabin (Leet Sketcher)
-Sketch Glitch Bugfix (assassin17)
-RMOVE to Remove (Gi Nattak)
-Description Disruption (SilentEnigma)
-Elemental Display (Lenophis)
-Border Crossing (Imzogelmo, Lenophis, Novalia Spirit)
-Homesick Gau (Djibriel)
-255 hours Display (Leviathan Mist)
-For What Ails Ya! (Imzogelmo, Lenophis, Novalia Spirit)
-Bad Decoration (Lenophis)
-I condemn thee to hell! (Lenophis)
-Suplex wrongfully splits damage fix (assassin17)
-Allo Ver (Death Warden) fix (using FFUSME)
-Step Mine (Traveler) missing digit fix (assassin17)
-Some MP changes don't update menus fix (assassin17)
-Pink Gogo bugfix (Imzogelmo)
-Reflect barrier shown on bodyguards fix (assassin17)
-Running Popsicle / Lead-footed Esper fix (assassin17)
-Mine Cart Fix (Imzogelmo)
-Deceptive Tapir (assassin17)
-Evade Bug Fix (Terii Senshi)
-Rippler Bug Fix (Terii Senshi)
-FC 05 Bugfix (Master ZED)
-Invisible Chests on Phantom Train fix (Shaded Magus)
-Frozen Terra Fix (Madsiur)
-Jump/Launcher and Jump/Super Ball fix (assassin17)
-Rage Restoration (Terii Senshi)
-Pincer+Row Bugfix (assassin17)
-Jump Megafix A (assassin17)
-Miscolored Command Names - Gear Based (assassin17)
-Recapture the Glory (assassin17)
-Bridge Correction (Mike Ferrell)
-Wrong Way, Idiot! (Mike Farrell)
-Banon Riding (Leet Sketcher)
-Backwards Jump (Leet Sketcher)
-Bird Bars (Leet Sketcher)
-Castle Party (Leet Sketcher)
-Chain of Command - Gear Based (Leet Sketcher)
-False Knight (Leet Sketcher)
-Imp's Rage (Leet Sketcher)
-Imp's Call (Leet Sketcher)
-Imp Skimp (Leet Sketcher)
-Item/Magic Counter (Leet Sketcher)
-Lens Cap (Leet Sketcher)
-Magitek Madness (Leet Sketcher)
-Morph Mayhem (Leet Sketcher)
-Phoenix Chest (Leet Sketcher)
-Ultimate Damage (Leet Sketcher)
-Unequipium (Leet Sketcher)
-Vanish/Runic (Leet Sketcher)
-Zombie/Tapir A (Leet Sketcher)
-Zombie/Rippler A (Leet Sketcher)
-Allergic Dog (Novalia Spirit)
-Blitz Screen (Leet Sketcher)
-GBA Monster Names, Esper Data, Ability Names, Item Data, Spell Names, etc. (Rodimus Primal)

-------------------------------------What Did You Change?-------------------------------------
-Town Dialog
-Small Window Battle Dialog
-Large Window Battle Dialog
-Basic Battle Dialog (example: "Earned [Qty] EXP." instead of "Got [Qty] Exp. Point(s)")
-Location Names
-Esper Names/Traits (returning edited ones to original values)
-Blitz Name (from "Bum Rush" to "Phantom Rush")
-Lore Name (from "Throwing Stone" to "Stone")
-Makitek ability name from "Blizzard Beam" to "Ice Beam"
-K.Behemoth (aka "SrBehemoth") now immune to Imp to prevent crash caused by "Imp Skimp" patch
-Monster Names (to match FF6 Advance or dialog text)
-Item/Weapon/Armor/Relic names (some)
-"Rare" item names and descriptions

-----------------------------------Pop-Culture References?------------------------------------
-Beavis and Butthead style chanting and chuckling at fire (replaced)
-Weapons of Magitek destruction (dropped with extreme prejudice)
-Wizard of Oz: "my [...] pretties" (changed)
-The Price is Right game-show contestant call: "Come on down!" (dropped)
-The mention of a cult spelling Kefka's name with a "C" (replaced)
-Three Dream Stooges (changed)
-The characters' dialog being compared to a self-help book (omitted)
-Vargas's bears renamed from "Ipooh" to "Ursa"

Note: Where the references were entirely superfluous, I simply removed them. When some type of 
replacement dialog was needed, I used Clyde Mandelin's "Legends of Localization" videos as a 
guide to write somewhat literal translations of the original Japanese text. A few other 
inconsequential changes were made for the sake of consistency and visual presentation.

------------------------------------------Disclaimer------------------------------------------
This patch is a rom hack that includes the independent  work of multiple parties. I know of 
no issues with the patch, but my testing is admittedly limited. If any damages are caused by 
the use of this patch, they are unintended, unforeseen, and not my responsibility.