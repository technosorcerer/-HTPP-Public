|----------------------------------------------|
| HP Gain On Each Step                         |
| by: madsiur                                  |
| version: 1.0                                 |
| released on: January 31th, 2022              |
| apply to: FF3us 1.0 (no header)              |
|----------------------------------------------|

|----------------------------------------------|
| 1- Files                                     |
|----------------------------------------------|

hp_gain_four_nh.ips: IPS patch for the stamina / 4 HP gain every step (bank $C0 free space)
asm/hp_gain_four.asm: Bass v14 assembly file of the above patch

hp_gain_four_EX_nh.ips: IPS patch for the stamina / 4 HP gain every step (bank $EE free space)
asm/hp_gain_four_EX.asm: Bass v14 assembly file of the above patch

hp_gain_eight_nh.ips: IPS patch for the stamina / 8 HP gain every step (bank $C0 free space)
asm/hp_gain_eight.asm: Bass v14 assembly file of the above patch

hp_gain_eight_EX_nh.ips: IPS patch for the stamina / 8 HP gain every step (bank $EE free space)
asm/hp_gain_eight_EX.asm: Bass v14 assembly file of the above patch

asm/maps.asm: Bass v14 assembly file to edit for every map the new map property byte

|----------------------------------------------|
| 2- Description                               |
|----------------------------------------------|

This hack increase on every step the HP of all party member. The effect
is the same as the tintinabar effect (HP gain = stamina / 4) and work
on map having the random encounter flag set plus the two world maps. There
is also a version of the hack that has the stamina / 8 formula instead
of stamina / 4. With this hack the tintinabar is useless and can now be
repurposed.

If you want to edit which maps the effect is on, you can enable it (01) or
disable it (00) in asm/maps.asm and then assemble the hack with one of the
four other files. Currently the decision to have a map HP gain property
set was solely based on the presence of the random encounter flag on that
map. The map data portion of the file was auto-generated. The only manual
modification was setting the flag for the WoB and WoR maps. The hack use
map property byte $ED8F1D which is unused in vanilla game.


The four different hacks use between 29 ($1D) and 32 ($20) byte of free
space. You can change that free space offset by changing the "seek" macro
argument in the asm file. If you want free space elsewhere than bank $C0,
choose a EX hack. The regular hack use $C0D613 and the EX hack use $EEAF01
as free space offset. You can assemble the hack with bass v14 with a
command such as "bass -o rom.smc hp_gain_four.asm" at the root of the
"asm" folder.