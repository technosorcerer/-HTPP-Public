//|----------------------------------------------|
//| HP Gain On Each Step (Stamina / 8)           |
//| by: madsiur                                  |
//| version: 1.0                                 |
//| Released on: January 31th, 2022              |
//| apply to: FF3us 1.0 (no header)              |
//|----------------------------------------------|

// assemble with bass v14

arch snes.cpu

macro seek(variable offset) {
origin (offset & $3FFFFF)
base offset
}

// base offset of unused map property byte.
variable mapProperty($ED8F1D)

include "maps.asm"

//|----------------------------------------------|
//| Bank $C0 code                                |
//|----------------------------------------------|

// in function called every step,
// we replace the hardcoded tintinabar check
seek($C04A6C)
rep #$20                // 16-bit A
lda $1F64               // load current map word
jsl free_space          // check current map
beq lbl_4A93            // skip if bit 0 is not set, we do not increase HP
jsr $AEE8               // set $1E as character's max HP
lda $161C,y             // load character's stamina
lsr
lsr
lsr                     // divide by 8
nop
nop

seek($C04A93)
lbl_4A93:               // check poison, decreace HP if poisoned, etc.

//|----------------------------------------------|
//| Bank $EE free space                          |
//|----------------------------------------------|

seek($EEAF01)           // you can change this free space offset as long as it's not in bank $C0
free_space:
and #$01FF              // isolate map ID
beq is_wob              // branch if WoB map
cmp #$0001              // compare to WoR map ID
beq is_wor              // branch if WoR map
sep #$20                // 8-bit A
lda $053D               // load new regular map property byte
bra exit                // exit subroutine
is_wob:                 // WoB branch
sep #$20                // 8-bit A
lda.l mapProperty       // load new WoB map property byte
bra exit                // exit subroutine
is_wor:                 // Wor branch
sep #$20                // 8-bit A
lda.l mapProperty+33    // load new WoR map property byte
exit:
rtl
