//|----------------------------------------------|
//| HP Gain On Each Step                         |
//| by: madsiur                                  |
//| version: 1.0                                 |
//| Released on: January 30th, 2022              |
//| apply to: FF3us 1.0 (no header)              |
//|----------------------------------------------|

// assembled with hp_gain_four.asm, hp_gain_eight.asm
// hp_gain_four_EX.asm or hp_gain_eight_EX.asm

//|----------------------------------------------|
//| Variables                                    |
//|----------------------------------------------|

// base offset of unused map property byte.
variable newOffset(mapProperty)

//|----------------------------------------------|
//| Maps                                         |
//|----------------------------------------------|

// below are the 415 maps in order from 0 to 414.
// a byte is written for each map then a
// +33 is done on the offset to get to the next map.

// $00 = no HP recover each step on the map.
// $01 = HP recover each step on the map.

seek(newOffset)
db $01        // map $0000: world of balance, world map
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0001: world of ruin, world map
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0002: serpent trench, world map
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0003: "on that day..."
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0004: shadow's dream 1
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0005: mog's explanation
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0006: blackjack, upper deck (general use)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0007: blackjack, inside
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0008: blackjack, back room
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0009: "choose a scenario"
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $000A: blackjack, upper deck (iaf sequence)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $000B: falcon, upper deck
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $000C: falcon, inside
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $000D: falcon, roof, landing on kefka's tower
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $000E: chocobo stable, outside (wob, forested)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $000F: chocobo stable, inside
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0010: chocobo stable, outside (wor, forested)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0011: falcon, upper deck
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0012: narshe, northern cliff, intro
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0013: narshe, town, beginning (wob)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0014: narshe, town (wob)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0015: narshe, north of town, beginning (wob)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0016: narshe, snow battlefield (wob)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0017: narshe, northern cliff (wob)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0018: narshe, weapons shop
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0019: narshe, armor shop
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $001A: narshe, item shop
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $001B: narshe, relics shop
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $001C: narshe, inn
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $001D: narshe, pub
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $001E: narshe, elder's house
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $001F: ___chocobo stable
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0020: narshe, outside (wor)
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0021: narshe, outside, north (wor)
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0022: narshe, outside, battlefield (wor)
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0023: narshe, outside, northern cliff (wor)
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0024: narshe, mines cart rail rooms (wor)
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0025: narshe, mines battle room (wor)
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0026: narshe, mines 1 (wor)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0027: narshe, outside, north, beginning
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0028: narshe, mines 1, beginning (wob)
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0029: narshe, mines 1 (wob)
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $002A: narshe, mines esper room, beginning (wob)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $002B: narshe, mines esper room, empty (wob)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $002C: narshe, moogle's room (wor)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $002D: ___
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $002E: ___
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $002F: ___
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0030: narshe, mines 2, from secret (wob)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0031: narshe, mines checkpoint (wob)
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0032: narshe, mines 2 (wob)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0033: narshe, mines battle room (wob)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0034: narshe, moogle's room (wob)
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0035: cave to figaro castle, room 2
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0036: figaro castle, submerging
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0037: figaro castle, outside
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0038: figaro desert, kefka & troops
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0039: figaro castle, king's bedroom
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $003A: figaro castle, throne room
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $003B: figaro castle, inside
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $003C: figaro castle, library
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $003D: figaro castle, basement 1
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $003E: figaro castle, basement 2
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $003F: figaro castle, basement 3
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0040: figaro castle, engine room
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0041: figaro castle, treasure room
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0042: figaro castle, regal crown room
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0043: figaro castle, outside, nighttime
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0044: cave to south figaro (wor)
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0045: cave to south figaro, rooms
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0046: cave to south figaro (wob)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0047: cave to south figaro, entrance
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0048: cave to south figaro, room 2
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0049: cave to south figaro, room 1
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $004A: south figaro, outside (wor)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $004B: south figaro, outside (wob)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $004C: south figaro, inn/relics
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $004D: south figaro, arsenal
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $004E: south figaro, pub
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $004F: ___
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0050: south figaro, chocobo stable
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0051: south figaro, rich man's house
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0052: ___
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0053: south figaro, basement 1
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0054: south figaro, basement 1 clock room
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0055: south figaro, item shop
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0056: south figaro, duncan's house
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0057: south figaro, basement 1 monster room
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0058: south figaro, basement 1 save point
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0059: south figaro, basement 2
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $005A: cave to figaro castle, entrance (wor)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $005B: south figaro, dock (wor)
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $005C: cave to figaro castle, room 1
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $005D: sabin's house, outside
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $005E: sabin's house, inside
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $005F: mt.kolts, entrance
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0060: mt.kolts, outside
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0061: mt.kolts, outside bridge
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0062: mt.kolts, outside vargas area
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0063: ___
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0064: mt.kolts, cave
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0065: mt.kolts, exit
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0066: mt.kolts, cliffs
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0067: mt.kolts, cave save point
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0068: narshe, school
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0069: narshe, school, adv. battle tactics
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $006A: narshe, school, battle tactics
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $006B: narshe, school, environmental science
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $006C: returner's hideout, entrance
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $006D: returner's hideout, inside
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $006E: returner's hideout, rooms
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $006F: returner's hideout, inn
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0070: tunnel to lete river
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0071: lete river
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0072: lete river cave
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0073: gau's father's house, outside
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0074: gau's father's house, inside
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0075: military base camp
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0076: ___
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0077: military base camp 2
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0078: doma castle, outside (wob)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0079: doma castle, outside poisoning (wob)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $007A: ___
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $007B: doma castle, inside
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $007C: doma castle, cyan's room
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $007D: cyan's dream, doma castle, outside
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $007E: cyan's dream, doma castle rooms
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $007F: duncan's house, outside
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0080: duncan's house, inside
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0081: ending, sky with birds
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0082: ending, phantom forest
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0083: gau's father's house, outside (wor)
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0084: phantom forest 1
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0085: phantom forest 2
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0086: phantom forest 3
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0087: phantom forest 4
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0088: ending, mountain bridge
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0089: phantom train, docking station 4
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $008A: phantom train, docking station 2
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $008B: phantom train, docking station 3
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $008C: phantom train, docking station 1
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $008D: phantom train, outside 2
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $008E: phantom train, outside 1
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $008F: cyan's dream, phantom train, outside
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0090: cyan's dream, phantom train, inside
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0091: phantom train, inside 1
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0092: phantom train, engineer's room
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0093: phantom train, restaurant
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0094: mobliz, outside during light of judgement
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0095: phantom train, inside 2
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0096: mobliz, basement 2, after phunbaba 1
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0097: phantom train, inside 3
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0098: phantom train, inside 4
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0099: phantom train, inside rooms
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $009A: mobliz, basement 2
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $009B: waterfall cave
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $009C: waterfall cliff
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $009D: mobliz, outside (wob)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $009E: mobliz, outside (wor)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $009F: veldt shore
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00A0: mobliz, inn
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00A1: mobliz, arsenal
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00A2: mobliz, relics
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00A3: mobliz, mail house
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00A4: mobliz, item shop
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00A5: mobliz, basement 1
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00A6: waterfall entrance
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00A7: veldt cave to waterfall
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00A8: veldt waterfall
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00A9: nikeah, outside
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00AA: veldt shore
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00AB: nikeah, inn
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00AC: nikeah, pub
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00AD: nikeah, chocobo stable
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $00AE: shadow's dream 2, phantom forest
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00AF: serpent trench cave 1
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $00B0: mt.zozo, outside bridge
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $00B1: mt.zozo, outside 1
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $00B2: mt.zozo, outside 2
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $00B3: mt.zozo, inside
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00B4: mt.zozo, cyan's room
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00B5: mt.zozo, cliff
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00B6: ending, relm, shadow, strago
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00B7: mobliz, basement 2, before kefka fight
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00B8: mobliz, outside, before kefka fight
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00B9: crazy man's house, outside
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00BA: crazy man's house, inside
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00BB: nikeah, ferry (wob)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00BC: kohlingen, outside (wob)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00BD: kohlingen, outside (wor)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00BE: ending, rapids
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00BF: kohlingen, inn (wor)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00C0: ___kohlingen
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00C1: ___kohlingen, arsenal
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00C2: kohlingen, general store
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00C3: kohlingen, chemist's house
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00C4: maranda, flower girl's house (wor)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00C5: kohlingen, rachel's house
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00C6: jidoor, outside
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00C7: ___nothing
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00C8: jidoor, auction house
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00C9: jidoor, item shop
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00CA: jidoor, relics
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00CB: jidoor, armor shop
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00CC: jidoor, weapon shop
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00CD: jidoor, chocobo stable
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00CE: jidoor, inn
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $00CF: owzer's house, basement
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00D0: owzer's house, art room
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00D1: owzer's house, f1
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00D2: ending, cyan 1
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00D3: ending, umaro, mog 1
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00D4: ending, gogo 1
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00D5: ending, gau 1
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $00D6: cliff, setzer waits for darill
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00D7: ending, falcon flying through sky
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00D8: esper world, lake
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00D9: esper world, outside
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00DA: esper world, gate
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00DB: esper world, house
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00DC: ___boat dock
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $00DD: zozo, outside
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00DE: ___nothing
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00DF: ___nothing
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00E0: ___nothing
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $00E1: zozo, inside house
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00E2: zozo, terra's room
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00E3: ___nothing
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00E4: ___nothing
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00E5: ___nothing
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00E6: ___nothing
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00E7: opera house, theater
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00E8: opera house, switch room
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00E9: opera house, theater play 2
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00EA: opera house, theater play 1
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00EB: opera house, ceiling
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00EC: opera house, castle balcony
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00ED: opera house, main
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00EE: opera house, dressing room
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00EF: ___opera house
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $00F0: vector, after magitek factory
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00F1: imperial castle, cranes activating
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00F2: vector, outside
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00F3: imperial castle
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00F4: imperial castle, outside roof
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00F5: vector, inn
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00F6: vector, weapon shop
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00F7: vector, pub
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00F8: vector, armor shop
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00F9: vector, healer's house
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00FA: imperial castle, inside
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00FB: imperial castle, banquet
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00FC: imperial castle, bedroom
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00FD: vector, outside, burning
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00FE: ending, cyan, mog, gogo 2
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $00FF: ending, setzer
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0100: ending, umaro 2
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0101: ___magitek factory
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0102: ending, edgar and sabin
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0103: ending, falcon taking flight from kefka's tower
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0104: ending, locke and celes 1
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0105: ending, shadow, strago, gau 2
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0106: magitek factory, room 1
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0107: magitek factory, room 2
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0108: magitek factory, room 3 (espers)
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0109: ___magitek factory
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $010A: magitek factory, elevator
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $010B: ___magitek factory
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $010C: ending, terra
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $010D: magitek factory, room 4
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $010E: magitek factory, room 5 (save)
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $010F: magitek res. facility, room 1
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0110: magitek factory, minecart dock
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0111: magitek res. facility, room 2 (number 042)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0112: magitek res. facility, espers
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0113: ___dummied
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0114: zone eater's stomach, room 1
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0115: zone eater's stomach, room 4
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0116: zone eater's stomach, room 6 (gogo)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0117: zone eater's stomach, room 2
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0118: zone eater's stomach, room 3,5
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0119: narshe, umaro's cave 1
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $011A: narshe, umaro's cave 2
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $011B: narshe, umaro's lair
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $011C: maranda, outside (wor)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $011D: doma castle, outside, abandoned
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $011E: ___nothing
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $011F: kefka's tower, inside from guardian
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0120: maranda, inn (wor)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0121: maranda, weapon shop (wor)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0122: maranda, armor shop (wor)
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0123: kefka's tower, guardian's room
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0124: kefka's tower, junk room
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0125: kefka's tower, inside from factory room
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0126: kefka's tower, inside 2
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0127: kefka's tower, inside 3
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0128: kefka's tower, factory room (top level)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0129: darill's tomb, outside
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $012A: darill's tomb, basement 1
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $012B: darill's tomb, basement 2
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $012C: darill's tomb, basement 3
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $012D: darill's tomb, staircase
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $012E: ending, thamasa, repairing burned house
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $012F: kefka's tower, inside 1
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0130: kefka's tower, assassin room
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0131: tzen, outside (wor)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0132: tzen, outside, before house collapse (wor)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0133: tzen, item shop (wor)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0134: tzen, inn (wor)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0135: tzen, weapon shop (wor)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0136: tzen, armor shop (wor)
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0137: tzen, inside collapsing house
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0138: tzen, relics (wor)
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0139: phoenix cave, big lava room, drained
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $013A: pheonix cave, big lava room
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $013B: phoenix cave, main room, drained
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $013C: phoenix cave, main room
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $013D: cyan's dream, three stooges
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $013E: pheonix cave, outside entrance
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $013F: cyan's dream, magitek caves, outside
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0140: cyan's dream, magitek caves, inside
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0141: cyan's dream, phantom train, inside 1
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0142: cyan's dream, phantom train, inside 2
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0143: albrook, outside (wob)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0144: albrook, outside (wor)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0145: albrook, inn
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0146: albrook, weapon shop
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0147: albrook, armor shop
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0148: albrook, item shop
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0149: kefka's tower, room with movers
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $014A: albrook, pub
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $014B: kefka's tower, atma's room
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $014C: albrook, ship deck
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $014D: ___kefka's tower, factory
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $014E: kefka's tower, outside
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $014F: kefka's tower, gold dragon room
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0150: kefka's tower, kefka's lair 1
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0151: kefka's tower, 4ton switch room
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0152: kefka's tower, inside from central group
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0153: kefka's tower, inside from eastern group
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0154: thamasa, outside, at leo's grave
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0155: thamasa, outside, kefka attacks
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0156: ___thamasa
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0157: thamasa, outside (wob)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0158: thamasa, outside (wor)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0159: thamasa, arsenal
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $015A: thamasa, inn
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $015B: thamasa, item shop
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $015C: thamasa, elder's house
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $015D: thamasa, strago's house
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $015E: thamasa, relics
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $015F: thamasa, inside burning house
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0160: kefka's tower, broken capsules
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0161: cave in the veldt (wor)
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0162: kefka's tower, red carpet rooms
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0163: kefka's tower, three switch room
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0164: kefka's tower, left statue room
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0165: kefka's tower, kefka's lair 2
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0166: floating continent, save point
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0167: fanatic's tower, level 2
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0168: fanatic's tower, level 3
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0169: fanatic's tower, level 4
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $016A: fanatic's tower, entrance
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $016B: fanatic's tower, level 1
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $016C: fanatic's tower, roof
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $016D: fanatic's tower, treasure room 2
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $016E: fanatic's tower, gem box room
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $016F: fanatic's tower, treasure room 3
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0170: fanatic's tower, treasure room 4
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0171: fanatic's tower, treasure room 5
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0172: fanatic's tower, treasure room 1
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0173: esper cave, statue room
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0174: esper cave, outside 2
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0175: esper cave, outside 1
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0176: esper cave, outside 3
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0177: esper cave
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0178: floating continent, destruction
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0179: imperial base
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $017A: imperial base, house
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $017B: ___imperial base
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $017C: overhead view of world map
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $017D: mountains destruction
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $017E: cave to the sealed gate, room 1
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $017F: cave to the sealed gate, basement 1
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0180: cave to the sealed gate, basement 3
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0181: cave to the sealed gate, basement 2
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0182: cave to the sealed gate, save point
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0183: ___cave to the sealed gate, basement 4
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0184: ___cave to the sealed gate
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0185: grasslands destruction
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0186: highlands destruction
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0187: sealed gate
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0188: floating continent shadow cast above jidoor
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0189: floating continent, breaking apart
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $018A: floating continent, outside
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $018B: floating continent breakaway 1
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $018C: cid's island, outside
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $018D: cid's island, inside house
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $018E: cid's island, beach
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $018F: cid's island, cliff
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0190: cid's island, beach, no fish
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0191: ancient cave 1
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0192: ancient cave 2
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0193: ___cid's island, beach
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0194: hidon's cave
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0195: hidon's cave, entrance
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0196: ancient castle, inside
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0197: ancient castle, outside
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $0198: ancient castle, eastern room
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $0199: kefka's tower, pipe room
variable newOffset(newOffset + 33)

seek(newOffset)
db $01        // map $019A: kefka's tower, factory room (bottom level)
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $019B: kefka's tower, final room
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $019C: kefka's tower, guardian path save point
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $019D: colosseum
variable newOffset(newOffset + 33)

seek(newOffset)
db $00        // map $019E: ___
variable newOffset(newOffset + 33)