Shadow's shadow Fix
-------------------
version: 1.1
released on 04/30/2025
Apply to FF3us 1.0, 1.1, FF6A (JUE)


Patches
-------
h: Patch for headered SNES ROM
nh: Patch for headerless SNES ROM
GBA: Patch for the GBA version (JUE), if no mention the patch is for FF3us 1.0 and 1.1
ANTI: Reverse patch


Description
-----------
Quoting Novalia Spirit:

"As everybody knows, the first time you step foot into South Figaro, 
you normally see Shadow walk towards the Cafe. As expected, in the 
case you follow him into the building, he'll be there. It is once 
Vargas is killed that Shadow disappears from the Cafe.

Now here's the bug: ignore South Figaro till you beat Vargas. 
Retrace your steps to South Figaro, and you will, here again, 
see Shadow walk towards the Cafe. BUT, he won't be in it.
And there's even worse: if you ignore the scene until you play Locke's 
scenario, Shadow'll be stuck behind the guard and the M-TekArmor 
sprites by the town's entrance. Note that going into a building 
will destroy your chances of seeing the bug occur, so you MUST 
beat the HeavyArmor as you make your way to Shadow."

To fix the bug, an additional check is made in South Figaro entrance
event. If Vargas is beaten or you saw Shadow walk in town, Shadow NPC
is not created and its movement queue not executed.


Code Changes (SNES)
-------------------

CA/EBA1: C0    If ($1E80($1B6) [$1EB6, bit 6] is set), branch to $CA5EB3 (simply returns)
CA/EBA7: C1    If ($1E80($00A) [$1E81, bit 2] is set or $1E80($010) [$1E82, bit 0] is set), branch to $CAEBC1
CA/ECAF: B2    Call subroutine $D1F9F8
CA/EBB3: 45    Refresh objects
CA/EBB4: 15    Begin action queue for character $15 (NPC $15), 11 bytes long
CA/EBB6: 8E        Move vehicle/entity down 4 tiles
CA/EBB7: 99        Move vehicle/entity right 7 tiles
CA/EBB8: A1        Move vehicle/entity right/down 1x1 tiles
CA/EBB9: A1        Move vehicle/entity right/down 1x1 tiles
CA/EBBA: 86        Move vehicle/entity down 2 tiles
CA/EBBB: 95        Move vehicle/entity right 6 tiles
CA/EBBC: 92        Move vehicle/entity down 5 tiles
CA/EBBD: 89        Move vehicle/entity right 3 tiles
CA/EBBE: 80        Move vehicle/entity up 1 tile
CA/EBBF: D1        Make vehicle/entity disappear
CA/EBC0: FF        End queue

D1/F9F8: D0    Set event bit $1E80($00A) [$1E81, bit 2]
D1/F9FA: 3D    Create object $15
D1/F9FC: 41    Show object $15
D1/F9FE: FE    Return

GBA code equivalent is at $7AEA53 and extra 7 bytes at $7FFBF2.


Version History
---------------
1.1 04/30/2025  Fixed entrance event code omission in the GBA patch, SNES patches remain untouched (thanks to KinCryos for the report)
1.0 03/18/2017	Initial release
