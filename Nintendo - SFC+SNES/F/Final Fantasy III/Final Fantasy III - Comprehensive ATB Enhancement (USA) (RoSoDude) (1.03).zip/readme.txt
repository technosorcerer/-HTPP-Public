Final Fantasy 6 -- Comprehensive ATB Enhancement v1.03
by RoSoDude https://rosodudemods.wordpress.com/

Final Fantasy 6's ATB system has some notable flaws compared to other entries in the series. ATB is always running in the background regardless of battle animations, so commands can quickly pile up on the queue. This functionally caps the effectiveness of the Agility stat. Furthermore, it enables "Wait tricking" abuse with the Wait mode config setting, where the player enters a command submenu to pause ATB during player animations, but lets ATB resume during enemy animations to gain a turn order advantage. Additionally, most commands have a short delay (0.53-1.07 seconds) before executing which is irrelevant if the delay coincides with a battle animation, but can also make the timing of commands less responsive, often at the cost of strategic depth. Finally, the Battle Speed config setting only serves to make enemy ATB speed slower relative to the player, instead of adjusting the actual pace of battles as the player would expect.

This hack is intended to redress all of these flaws. As such, it alters gameplay balance to some degree, but the end result should be a more tactical and robust ATB system which can be tweaked to the user's preference using the in-game config settings.

This hack makes ATB gauges and other battle timers (status effect counters, poison/regen ticks, success checks for fleeing) pause during battle animations, similar to the "nATB" system implemented by Think0028 for Brave New World, also available as a standalone "simple nATB" patch. However, this hack supports the Active/Wait mode config setting instead of defaulting to Wait. Since the original ATB fill rate was balanced around battle animation timing, pausing ATB without other changes leads to excessively slow-paced battles. To remedy this, a new ATB fill rate formula is implemented, which equally uses the Battle Speed config setting for both player and enemy characters. This fill rate is roughly 2x faster than the original on Battle Speed 1, and roughly equal to the original on Battle Speed 6. The formula is identical to HatZen08's Even Gauge, however in this hack the Battle Speed setting is also applied to status effect timers, so their effects are consistent with the turn order regardless of the config setting. 

The poison/regen/sap tick rate, the duration of status effects like reflect/freeze/stop/sleep/doom countdown, the success chance for fleeing, the morph command duration, the jump command duration, and AI battle timers were also originally balanced around battle animation timing, and thus acted too slowly with the ATB pause. All of these have been increased in frequency or decreased in duration to account for this discrepancy. The execution delay on several basic commands is removed to increase responsiveness during battle, but is maintained for other commands as an element of gameplay balance. Enemy Agility values are quadratically damped (e.g. 30->29, 99->80, 255->128) for use with difficulty hacks that increase monster Agility stats above 99, since higher Agility now makes a massive difference in turn rate.

The hack is for non-headered US ROMs (v1.0 or v1.1). It is compatible with other hacks like C.V. Reynolds' Bug-Fix Compilation patch or Revised Old-Style Edition. This hack should be patched on top of those.

Hack features:
-ATB pauses during all battle animations (Active/Wait config setting still works). This also pauses status effect timers and all other elements of battle timing
-ATB fill rate formula rewritten so that Battle Speed config setting affects the gauge fill rate for the player (not just enemies) and is generally faster to account for the ATB pause. Fill rate no longer overflows for Speed stat above 235
-ATB fill rate formula now quadratically damps enemy Agility values for use with difficulty hacks that increase monster Agility stats above 99
-Battle Speed config setting now affects status effect timers, so they act in direct proportion to ATB fill rate regardless of setting
-Doom countdown timer starts at 2x reduced time
-Success chance for fleeing from battles builds up 2x more quickly
-Poison ticks 2x more often and regen/sap tick 3x more often
-Reflect/stop/sleep/freeze status timers tick 3x more quickly
-Morph (a.k.a. Trance) decays 2x more quickly
-Battle timers for AI scripts tick 3x more often
-HP drain from seize (tentacle boss) ticks 2x more often
-Execution delays for the fight, item, steal, mug, runic, leap, row, defend, and gil toss commands are removed
-Casting delay for summon command is doubled to match the casting delay for magic, lore, pray, and shock commands
-The jump command lands after 3.73 seconds of (elapsed) air time, rather than 7.47 seconds
-Assassin's Premature Continuation v0.20 patch, Leet Sketcher's Rock Bottom v1.3 patch, and Leet Sketcher's Death Row v1.2 patch are included to maintain compatibility with bugfix patch collections which include them

Assembly code is provided in the following files as a reference for other modders:
-ATB_enhanced.asm: implements most of the features of the hack except for battle timers related to poison/regen/sap, reflect/stop/sleep/freeze, and AI scripts
-patches_compat.asm: implements the remaining features on top of Premature Continuation/Rock Bottom/Off Death Row (asm for these not included)
NOTE FOR HACKERS: This hack uses 72 bytes of ROM freespace located at $C4B4D9 and makes use of 1 byte of RAM at $ECF1

Acknowledgements:
-Think0028 for creating the original "simple nATB" hack
-C-Dude for revising "simple nATB" to reinstate the Active/Wait config setting
-Lightning Hunter for correcting the patch to work with 1.1 ROMs
-Assassin for Premature Continuation v0.20
-Leet Sketcher for Rock Bottom v1.3 and Death Row v1.2
-HatZen08 for Even Gauge v1.1d

Changelist:
v1.00 
-Initial Release
1.01
-Fixed compatibility with 1.1 US ROMs
-Increased morph decay rate by 2x
1.02
-Reflect/stop/sleep/freeze timers now tick 3x faster for compatibility with any hack that rebalances their durations for vanilla ATB (previous releases overwrote the duration values)
-Doom countdown timer now starts at 2x reduced time instead of 4x reduced time
-Jump command delay reduced from 128 frames to 112 frames (originally 225 frames)
1.03
-Fixed tentacle boss never draining HP during seize. Now HP from seize ticks 2x faster
-ATB fill rate formula now quadratically damps enemy Agility values for use with difficulty hacks that increase monster Agility stats above 99