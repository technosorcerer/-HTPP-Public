FINAL FANTASY VI - Lion Armlet
Created by Ghost XIII

This minitature hack replaces Setzer's Coin Toss with a new item the
Lion Armlet, a relic which allows Celes to replace Runic with General
Leo's command Shock. The armlet is available as soon as you gain the
airship in the World of Ruin and is found on Leo's grave.