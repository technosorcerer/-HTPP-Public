Title: Battle Dialog Page Break
Author: SilentEnigma
Version: 1.1
Release Date: 2021-09-17
Applies to: Final Fantasy III (v1.0) (U)

Contents:

  BattleDialogPageBreak_A_H.ips = patch for headered ROMs, "A" variant

  BattleDialogPageBreak_A_NH.ips = patch for unheadered ROMs, "A" variant
  
  BattleDialogPageBreak_B_H.ips = patch for headered ROMs, "B" variant

  BattleDialogPageBreak_B_NH.ips = patch for unheadered ROMs, "B" variant

  readme.txt = this file


ROM Addresses:

    C1/439B, C1/439F, C1/43A4, C1/5E5A - C1/5E5B


Free space used: 30 bytes

    C1/FFE5 - C1/FFF8 *
    C2/A684 - C2/A690

    * Due to high use of the limited free space in Bank C1, this hack may
      require significant modification in order to maintain compatibility with
      some other hacks.

--------------------------------------------------

TABLE OF CONTENTS

0. Description
1. Relevant Offsets & Disassembly
2. Credits
3. Revision History
4. Legal

________________________________________________________________________________

  0. DESCRIPTION
________________________________________________________________________________


This hack adds a page break function <$03> for the big battle dialog captions in
FF3us.

When the function is invoked, the displayed text clears, and the remaining text
continues from the top of the dialog window.

This provides hackers with an alternative to the default page scrolling behavior
used by big battle captions, and is especially useful for reformatting the script
to use quotation marks. 

The hack comes in two variants:
 - A (BattleDialogPageBreak_A): Keeps the original left/right margin widths.
 - B (BattleDialogPageBreak_B): Reduces left/right margins (more usable text area)


USAGE
=====

Page break function I.D.: $03

Page break is typically added after function $07 (pause until A button pressed).


Example using FF3usME
=====================

 In FF3usME > Monster Editor > Big Captions > Caption $00:

 Add <$03> after the first pause (<P>):

WEDGE:
Hey! What's the matter?<P><$03>
Do you know something we
don't__?<P>


 Result:

   --------------------------------
  | WEDGE:                         |
  | Hey! What's the matter?        |
  |                                |
   --------------------------------

   <Press A button>

   --------------------------------
  | Do you know something we       |
  | don't......?                   |
  |                                |
   --------------------------------


________________________________________________________________________________

  1. RELEVANT OFFSETS & DISASSEMBLY
________________________________________________________________________________

Contents:
 a. Common
 b. Variant B Only

==================================================
 a. Common
==================================================

Original:
 C1/5E5A: 47 67   ; (03)  (exits)
Modified:
 C1/5E5A: E5 FF   ; (03)  (new subroutine C1/FFE5)

New Subroutine C1/FFE5:
 C1/FFE5: 20 02 5E    JSR $5E02   ; Prepare to clear page
 C1/FFE8: DA          PHX         ; string index
 C1/FFE9: 20 D0 96    JSR $96D0   ; Clear page
 C1/FFEC: 20 95 96    JSR $9695   ; Prepare fresh page
 C1/FFEF: FA          PLX         ; string index
 C1/FFF0: 22 84 A6 C2 JSL $C2A684 ; New subroutine C2/A684
 C1/FFF4: 20 D5 5D    JSR $5DD5   ; Start fresh page
 C1/FFF7: FA          PLX         ; Pull original return address
 C1/FFF8: 60          RTS         ; Double-return

New Subroutine C2/A684:
 C2/A684: E8          INX         ; string index
 C2/A685: E8          INX         ; skip newline
 C2/A686: 8E D7 88    STX $88D7
 C2/A689: AF 1B 98 C1 LDA $C1981B ; Battle big captions bank
 C2/A68D: 8D D9 88    STA $88D9
 C2/A690: 6B          RTL


==================================================
 b. Variant B Only
==================================================

Original:
 C1/439A: 9D 45 E7   STA $E745,X    <- Margin / 8 = (0xE745 - 0xE73F) / 2
 C1/439D: 1A         INC A
 C1/439E: 9D 85 E7   STA $E785,X    <- Margin / 8 = (0xE785 - 0x40 - 0xE73F) / 2
 C1/43A1: 1A         INC A
 C1/43A2: E8         INX 
 C1/43A3: E8         INX 
 C1/43A4: E0 34 00   CPX #$0034     <- Text box width / 8 = 0x34 / 2
Modified:
 C1/439A: 9D 43 E7   STA $E743,X    <- Margin / 8 = (0xE743 - 0xE73F) / 2
 C1/439D: 1A         INC A
 C1/439E: 9D 83 E7   STA $E783,X    <- Margin / 8 = (0xE783 - 0x40 - 0xE73F) / 2
 C1/43A1: 1A         INC A
 C1/43A2: E8         INX 
 C1/43A3: E8         INX 
 C1/43A4: E0 38 00   CPX #$0038     <- Text box width / 8 = 0x38 / 2


________________________________________________________________________________

  2. CREDITS
________________________________________________________________________________

Thanks to:

  Imzogelmo, for his disassembly of bank C1
  http://www.angelfire.com/al2/imzogelmo/patches.html

  Lord J et al., for the FF3usME utility.
  http://www.angelfire.com/pq/jumparound/

________________________________________________________________________________

  3. REVISION HISTORY
________________________________________________________________________________


2020-12-26 : Version 1.0 released.

2021-09-17 : Version 1.1 released.
 - Resolved conflict with Assassin's Alphabetical Rage patch.

________________________________________________________________________________

  4. LEGAL
________________________________________________________________________________


Copyright (C) 2020, 2021 David R. Thompson (SilentEnigma).

The copyright holder ("author") permits the free use of the attributed work
referenced by this document exclusively for non-commercial purposes, provided
that the following conditions are met:
1. The author and all contributors credited in this readme document shall be
 given credit for their respective contributions wherever the attributed work is
 reused, redistributed, or modified.
2. This readme document shall accompany any of the files comprising the
 attributed work wherever they are redistributed in unmodified form.

The work(s) and file(s) distributed with this document are provided "AS-IS",
WITHOUT ANY WARRANTY. The author shall not be held responsible for any damages
related to the use of work(s) and file(s) distributed with this document.
