Title: Doubletake
Author: PowerPanda
Version: 1.0
Applies to: FF3us v1.0

Contents:	doubletake h.ips - Applies the change to a headered rom
		doubletake nh.ips - Applies the change to an unheadered rom
		
		doubletake removal h.ips - Reverts the changes to vanilla FF6 on a headered rom.
		doubletake removal nh.ips - Reverts the changes to vanilla FF6 on an unheadered rom.

--------------------------------------------------------------------------------
-=Intro and Description=-
In FF6, Steal and Mug can only work once per enemy, even though many enemies in the game have 2 different items: a common one (7/8 chance) and a rare one (1/8 chance). This patch will allow you to steal both items from enemies. Each of the items will retain its usual probability.

--------------------------------------------------------------------------------
-=Compatibility=-

This hack is done in-line with the steal code, so as long as that code has not been overwritten or re-located, it will be compatible. This lightweight approach gives it almost universal compatibility with other romhacks. 

There is only time it will not be compatible is if the patch or hack does a complete overhaul on the "Steal" routine. The only known patch that does this is Imzogelmo's "Multi-Steal Fix". Doubletake IS compatible with Assassin's "Recapture the Glory" patch. If you combine "Doubletake" and "Recapture the Glory", you should have no need for "Multi-Steal Fix", as it accomplishes the same thing.
--------------------------------------------------------------------------------
-=Code Changes=-
C2/39E4:
   7A
-> EA

C2/39E7
   F0 18
-> F0 17

C2/39FA
   99 09 33 EE 01 34 60
-> EE 01 34 7A 60 EA 7A

--------------------------------------------------------------------------------
-=Credits=-

Hacking - PowerPanda, Drakkhen, Bropedio, C-Dude
Based off of notes provided by Lufia

Programs Used
HxD Hex Editor
--------------------------------------------------------------------------------