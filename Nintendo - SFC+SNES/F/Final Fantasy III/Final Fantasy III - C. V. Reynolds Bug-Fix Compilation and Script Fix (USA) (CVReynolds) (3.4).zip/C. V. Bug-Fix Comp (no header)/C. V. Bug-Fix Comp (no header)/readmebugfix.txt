Cobbled together by C. V. Reynolds (~Coraline Violet~).

Version 3.4

Patches updated May 6 of 2025.


  "C. V. Bug-Fix Comp (no header).ips" is the primary patch of this project and will fix every bug mentioned in the list below.

  Also included is a "There's Options" folder, which is for those who'd like some flexibility in which bugs will be fixed. Mix and match the patches in the "There's Options" folder as you desire. It doesn't matter what order you apply them in.

  Every patch in this set is designed to be patched to plain "Final Fantasy III (USA).sfc" files or to any hacks that won't conflict with the patches chosen.

  For North American 1.0 version only! My apologies to anyone using the Japanese version of the game. As for 1.1 (Rev 1, Rev A) version people, I advise switching to version 1.0. This compilation includes the Sketch Bug fix, making it pointless to use version 1.1 with this compilation anyway.

  For UNHEADERED rom images only. If you have a headered file, I recommend you remove it with a hex editor or a program designed to do so. If you'd prefer to keep the header (and waste the disk space, LOL), you can use the excellent program Headerizer, created by Leet Sketcher. You can download it from Leet Sketcher's site here: https://l33t5k37ch3r.altervista.org/headerizer.html

  Don't apply newer versions of these patches over older versions of these patches unless you're sure it won't mess things up.

  The host for this compilation is ff6hacking.com. This is currently the ONLY site that may host this compilation. However, hacks and other projects may use this compilation in their code even if those hacks are hosted on another website.


The checksums needed for the rom image (prior to any hacking) are as follows:

CRC-32 : A27F1C7A
MD-5   : E986575B98300F721CE27C180264D890
SHA-1  : 4F37E4274AC3B2EA1BEDB08AA149D8FC5BB676E7


Here's the list of patches included in this compilation:

202 patches used

  Actor Data fixes:

Celes' Rushing (Djibriel)
Setzer Bandana (C. V. Reynolds)

  Battles fixes:

1-Way Status Immunity (Assassin)
Allergic Dog (Novalia Spirit)
Anchors Aweigh! (Imzogelmo/Lenophis)
Anonymous Attack (Leet Sketcher)
Auto Swordless Runic  (Assassin)
Auto-expiring statuses don't reset their timers with manual removal (Assassin)
Backstabu (Leet Sketcher)
Bird Bars (Leet Sketcher) {modified by DrakeyC}
Caravaggio (Leet Sketcher)
Carve Stone (Leet Sketcher ver) (Imzogelmo)
Chance Offering (Leet Sketcher)
Control Attacks Ignore MP Cost (Assassin)
Control Menu Responds Poorly to MP Change (Assassin)
Dead Hare (Leet Sketcher)
Dead in the Air (Leet Sketcher)
Deceptive Tapir (Assassin)
Disrespectful Zombie (Assassin)
Double Block (Leet Sketcher)
Duplicate Enemy Names (Assassin)
Esper Battle Menu (Lenophis)
Evade (Terii senshi)
False Knight (Leet Sketcher)
FC 05 enemy command (Master ZED)
Flaky True Knight protection (Assassin)
For What Ails Ya (Lenophis/Imzogelmo/Kejardon)
Genji Glove damage reduction (Assassin)
Gogo and the Cursed Shield (Imzogelmo) {modified by Leet Sketcher}
Half Knife (Leet Sketcher)
I condemn thee to hell! (Lenophis)
Imp Skimp (Leet Sketcher) {modified by SilentEnigma}
Imp's Call (Leet Sketcher)
Imp's Rage (Leet Sketcher)
Imp's Retort (Leet Sketcher)
Imp's Retort Compatibility (Leet Sketcher)
Invert Damage if Undead (Leet Sketcher version) (originally by Master ZED)
Ironic Metamorph Pack (Assassin)
Item Magic Counter (Leet Sketcher)
Jump Megafix (Version A) (Assassin)
Jump-Launcher and Jump-Super Ball (Assassin)
Killer Life 3 (Leet Sketcher)
Magitek Madness (Leet Sketcher)
Morph Mayhem (Leet Sketcher)
Muddle-Mantra (Assassin)
Muddle-Palidor (Assassin)
Multi-Steal-Fix Simplified Edition (SilentEnigma)
Mute Steals Rage Statuses (Assassin)
No X In Fight (Leet Sketcher)
Off Death Row (Leet Sketcher)
Petrified Rebel (Novalia Spirit)
Pincer + Row (Assassin)
Premature Continuation (Assassin)
Psycho Cyan (Terii senshi)
Pugs Rage (SilentEngima)
Quick Fix (v1.02) (RoSoDude)
Randomosity monster encounter (Assassin)
Recapture the Glory (Assassin)
Reflect barrier shown on bodyguards (Assassin)
Reflectable Magitek Beams (Assassin)
Rock Bottom (Leet Sketcher)
Self Sneeze (Leet Sketcher)
Shadow Copy (Leet Sketcher)
Sketch Bug (Assassin)
Sketch Bug Second Part (Assassin)
Smoke and Mirrors (Leet Sketcher)
Some MP changes don't update menus (Assassin)
Soul Saved B (Leet Sketcher)
Stackable Immunities and Permanent Statuses (Assassin)
Status Unknown (Leet Sketcher)
Step Mine MP cost (Assassin)
Step Mine's Missing Digit (Assassin)
Stone Cold (Leet Sketcher)
Stone Faced (Leet Sketcher)
Summon Aim Fix (Terii senshi)
Suplex wrongfully splits damage (Assassin)
The Cowardly Dog (Novalia Spirit)
There can be only one! Single-target (Lenophis/Imzogelmo)
Throwback (Leet Sketcher)
To Joker Doom or Not to Joker Doom (Lenophis)
Ultimate Damage (Leet Sketcher)
Unaffected Rows (Assassin) {modified in 2020 by Assassin}
Upside Down (Leet Sketcher)
Vanish Doom New Version + Fenix Undead (Assassin)
Vanish Runic (Leet Sketcher)
Zombie Rippler A (Leet Sketcher)
Zombie Tapir A (Leet Sketcher)

  Events fixes:

Alternative Rage (SilentEnigma)
Auction Chocobo Fix (Madsiur)
Bland Entrance (Leet Sketcher)
Bottomless HP and MP Well (Assassin)
Can't lose for winning (Lenophis)
Castle Party (Leet Sketcher)
Cave to the Sealed Gate Basement 3 Event Megafix (Assassin)
Equip wrong item to slot via event (Assassin)
Figaro Guard Fix (DrakeyC)
Frozen Terra Fix (Madsiur)
Game Over (Leet Sketcher)
Grand Stairway (Imzogelmo) {modified by C. V. Reynolds to not edit the script}
Ignore Kamog (Drakkhen)
Imperial Camp Dialogue Bugfix (DrakeyC)
Instant Airship (Novalia Spirit)
Lens Cap (Leet Sketcher)
Miraculous, Death-Defying Always-Left-Facing Jumps in Zozo (mblock129)
M-Tek Vehicle in Cyan's Soul event (Imzogelmo)
Multiple Events Fix (Leet Sketcher)
Naming Shadow (Novalia Spirit)
Owzer's Basement Tile Bug Fix (Gi Nattak)
Persistent Whistle (Novalia Spirit)
Precious Jewels (Leet Sketcher)
Returner's Day Off (Leet Sketcher)
Shadow Gone (Leet Sketcher)
Shadow's Shadow (Madsiur)
Shadow's Status (Leet Sketcher)
Slightly lagged battle event timer display (Assassin)
Stepping Out (Leet Sketcher)
Stuck in a Pose (SilentEnigma)
The Sleazy Lender (Novalia Spirit)
Turn Around (Leet Sketcher)
Unequipium (Leet Sketcher)
Vector's Cure-Castin' Kid no longer heals the dead (Imzogelmo)
Walk This Way (Leet Sketcher)
Wrong Way, Idiot! (Gi Nattak)
Zoneseek No Thanks (mblock129)

  Graphics fixes:

Backwards Jump (Leet Sketcher)
Bad Decoration (Lenophis)
Blush Disease (Novalia Spirit)
Bridge Correction (Gi Nattak)
Broken Gate (Novalia Spirit)
Carbuncle Complete (DrakeyC)
Coin Flip Fix (Gi Nattak)
Drained Pool Tile Fix (Gi Nattak)
Everybody Gets a Chocobo! (PowerPanda)
Hasty T-Rex (Leet Sketcher)
Overhead (Leet Sketcher)
Reflections (Leet Sketcher)
Regulation Dice (mblock129)
Shadow Chupon (Novalia Spirit)
Solar Wind (Leet Sketcher)
Stray Flash (The FF6Hacking Community)
Tritoch Animation Fix (bydoless)
Tube Job (Gi Nattak)
Zozo Sign Petty Fix (Madsiur)

  Item Data fixes:

Doom Darts and Trump name fix (Assassin)
Dusk Requium (SP) (C. V. Reynolds)
Jewel Ring Description (Assassin)
Life 2 Description (Imzogelmo)
Magicite - Strength to Vigor (C. V. Reynolds)

  Map fixes:

Agoraphobic Leader (Novalia Spirit)
Allo Ver Fix (Master ZED, Assassin)
Banquet Guards Go Back to Their Places (mblock129)
Border Crossing (Imzogelmo, Lenophis, Novalia Spirit)
Button Blunder (Gi Nattak)
Duncan Stays Put (mblock129)
Flight of Storm Drgn (Novalia Spirit)
Gau All-Inclusive Dress-Up (Maps version) (DrakeyC)
Gold Wrexsoul (mblock129)
Loud Music (Leet Sketcher)
Map Mishap (Leet Sketcher) {modified by SilentEnigma, modified by Warrax to revert Zozo fix}
Mine Cart (Imzogelmo)
Missing Light (Novalia Spirit)
Narshe's Door (Leet Sketcher)
Narshe's Secret Entrance Tile (Novalia Spirit)
Off the Hook (Leet Sketcher)
Opened Eyes Terra Alt (Madsiur)
Phantom Train Chests (darkmage) {modified by Leet Sketcher to revert map changes}
Phoenix Chest (Leet Sketcher)
Pink Gogo (Imzogelmo)
The Echoing Waters (Novalia Spirit)
The Magic Bridge (Novalia Spirit)
The Peninsula of Death (Novalia Spirit)
The Phantom Diary (Novalia Spirit)
The Sealed Door (Novalia Spirit)
Transportation Device (Novalia Spirit)
Trigger Happy (Leet Sketcher)
Vanishing Magicite (Novalia Spirit)
Verdant Respite (Novalia Spirit)

  Menu fixes:

Amnesic Cursor (Novalia Spirit)
Chain of Command (Leet Sketcher)
Description Disruption (SilentEnigma)
Equip Anything fix (Kejardon/Lenophis/Imzogelmo)
Frozen Mosaic (Novalia Spirit)
Magic Sorting (Novalia Spirit)
Menu Malarky (Leet Sketcher)
Miscolored command names (grayed version) (Assassin)
Misplaced Cursor (Novalia Spirit)
Save Point Switch (Leet Sketcher)
Shop Menu (Novalia Spirit)
Shorter Skill Name Fix (Madsiur)
Status Icon Overflow (SilentEnigma)
That Damn Yellow Streak (Assassin)
Throw down (part of) the Gauntlet (Assassin)

  Monster Formation Data fixes:

The Unilateral Blockade (Novalia Spirit)

  Monster Scripts fixes:

Blitz Tutorial Fix (C. V. Reynolds)
Bye Bye Breath (Leet Sketcher) {modified by C. V. Reynolds for potential compatibility}
Chadarnook Timer Fix (RosoDude)
Homesick Gau (Djibriel)
One Hit Wonder (SilentEnigma)
SrBehemoth (Dragonsbrethren)
The Wild Cat (Djibriel/Lord J)

  Script fixes:

Missing Dialogue (Novalia Spirit)
Various Texts' (Imzogelmo)


Patch sources:
http://www.ff6hacking.com/forums/portal.php
http://assassin17.brinkster.net/
http://drakkhen.jalchavware.com/
http://l33t5k37ch3r.altervista.org/
http://masterzed.cavesofnarshe.com/
http://slickproductions.org/
http://www.angelfire.com/al2/imzogelmo/patches.html
http://www.rpglegion.com/ff6/hack/patches.htm
https://rosodudemods.wordpress.com/
NovaliaSpirit's site