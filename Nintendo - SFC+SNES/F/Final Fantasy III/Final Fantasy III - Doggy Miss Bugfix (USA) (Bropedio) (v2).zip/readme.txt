DOGGY MISS MOD - README

Doggy Miss Modification (FF3 US) [Version 1.0 or 1.1]
Bropedio (Novermber 10, 2019)
Patch Version 2

This patch fixes a bug(?) that randomly prevents Interceptor and Golem
from blocking attacks, even after they cause the attack to miss.

After reaching the miss routine (due to Dog Block or Golem), the game
selects a miss animation at random from the combination of all available
equipment and Interceptor or Golem. If an equipment block is selected,
the miss proceeds as though it had been caused by regular evasion.

The end result is that Interceptor will appear less frequently when
Shadow's equipment enables various block animations: dagger parry,
sword parry, shield, and cape. If all 4 equipment animations are available,
the chance of Interceptor appearing is reduced from 50% to 10%, though he
will still trigger misses 50% of the time.

Additionally, this patch routes Dog/Golem past the check for
Vanish/M-Tek/Zombie status that similarly causes Interceptor or Golem to be
silently replaced with a basic "miss" animation.

NOTE: As pointed out by assassin, it's entirely possible that the so-called
bug above was intentional behavior. However, I think the unintuitive miss
attribution constitutes a misstep, at the very least. Also, be warned that
this change will increase the overall frequency of Interceptor counterattacks,
and will significantly decrease the lifetime of Golem, when summoned. It may
be necessary to increase Golem's defense or reduce Interceptor's base evasion
chance to compensate.

######################
FILES CONTAINED IN ZIP
######################

* ReadMe (you're reading it now)
* Patch files (ips) for headered and non-headered FF3 ROMs
* Assembly code (.asm) written for xkas compiler

######################
PATCH EFFECTS/BEHAVIOR
######################

* If Interceptor or Golem trigger a miss, they will always appear
* Golem and Interceptor will now try to protect the team even if
  they are riding Magitek armor or have been zombified.

##############
PATCH VERSIONS
##############

Of the two patches included in this .zip file, only apply the
one that matches your FF3 ROM.

[h] (Headered) versus [n] (Non-Headered):

Use the [h] patch if your ROM is 3,146,240 bytes
Use the [n] patch if your ROM is 3,145,728 bytes

Or, you can just try applying one, and if your emulator explodes,
you chose the wrong patch.

###############
COMMENTS & BUGS
###############

Please send any questions, comments, or bug reports to
> bropedio@gmail.com

#########
CHANGELOG
#########

Version 2:
* Fix bug causing animation-less blocks to be converted into
hits, as if Golem or Interceptor had blocked the attack.
* Change patch name to reflect uncertainty about whether the
original code constitutes a "bug", per se.

Version 1:
* Initial release
