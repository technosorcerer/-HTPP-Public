
                       ############################
                      /                            \
                     #      'Final Fantasy VI'      #
                     #                              #
                     #  ~~Character Level Control~~ #
                      \                            /
                       ############################

                       
                       
+-----------------+                                        +-------------+
|TABLE OF CONTENTS|                                        |SUMMARY      |
+-----------------+----------------------------------------+-------------+
|a01. PATCHING INSTRUCTIONS                                |PATCHING     |
+----------------------------------------------------------+-------------+
|b02. HOW TO USE                                           |PATCH USE    |
+----------------------------------------------------------+-------------+
|c03. RECOGNITION AND SALUTATIONS                          |THANKS       |
+----------------------------------------------------------+-------------+
|d04. PURPOSE OF MODIFICATION                              |EXPLANATION  |
|d05. HOW THIS HACK WAS ACCOMPLISHED                       |             |
+----------------------------------------------------------+-------------+
|e06. USE AS YOU SEE FIT                                   |DISCLAIMER   |
+----------------------------------------------------------+-------------+
==========================================================================
+------------------------------------------------------------------------+
|a01. PATCHING INSTRUCTIONS                                              |
|                                                                        |
|1. Acquire a clean unheadered American release of the Final Fantasy VI  |
|   ROM for the SNES.                                                    |
|     We used "Final Fantasy III v1.1" as a base;                        |
|       For those who are unaware, Final Fantasy VI was released in the  |
|       US as "Final Fantasy III", hence the name discrepancy.           |
|2. Acquire an SNES emulator.                                            |
|     We tested this modification on both SNES 9x and Mesen;             |
|3. Download an IPS patching program.                                    |
|     We used LunarIPS;                                                  |
|4. Run LunarIPS and apply the patch included with this file on the      |
|   Final Fantasy VI ROM that you acquired in step 1.                    |
|5. Run the ROM with your favorite emulator or use real hardware.        |
+------------------------------------------------------------------------+
==========================================================================
+------------------------------------------------------------------------+
|b02. HOW TO USE                                                         |
|                                                                        |
|'Resetting Character Level'                                             |
|When in the status screen of any character in Final Fantasy VI, simply  |
|press LEFT on the D-PAD, START and the X-button simultaneously.  Doing  |
|so will reset that character's level to 1.  This causes the following   |
|to occur:                                                               |
| 1. Character's level is reset to 1 and XP to 0;                        |
| 2. HP and MP maximums are set to their level 1 amounts;                |
| 3. HP and MP are restored to the new maximum;                          |
| 4. The four stats of Vigor, Speed, Stamina, and Mag.Pwr are reset to   |
|    the character's base amount;                                        |
| 5. None of the character's naturally learned talents or Esper magic is |
|    unlearned.                                                          |
|                                                                        |
|'Adding to Character Level'                                             |
|When in the status screen of any character in Final Fantasy VI, simply  |
|press RIGHT on the D-PAD, START and the Y-button simultaneously.  Doing |
|so will add 1 level to that character's current level.  This causes the |
|following to occur:                                                     |
| 1. Character's level adds 1 to whatever their current level is;        |
| 2. Character's XP becomes the minimum required for that level;         |
| 3. The character is checked to determine if they are already level 99  |
|    and if they are, the process is aborted;                            |
| 4. Equipped Esper's boosts are included in the increased level;        |
| 5. While maximum HP and MP are tweaked by the level up code, the       |
|    current amounts are left alone.  You might need an inn afterward;   |
| 6. If there are side effects as to character's natural talents, these  |
|    are *skipped* by this process.  Sorry about that.                   |
|                                                                        |
|To summarize how to affect character levels:                            |
| Resetting Character Level = 'D-pad Left'  + 'Start' + 'X'              |
| Adding to Character Level = 'D-pad Right' + 'Start' + 'Y'              |
|                                                                        |
|With either combination, you do not need to press all three buttons at  |
|the exact same time with one single press.  Since pressing any of those |
|buttons in the status screen does nothing at all, you can hold one      |
|button down while you then navigate to press the other two.             |
+------------------------------------------------------------------------+
==========================================================================
+------------------------------------------------------------------------+
|c03. RECOGNITION AND SALUTATIONS                                        |
|                                                                        |
|This modification was authored by FatRatKnight.                         |
|This readme was written by FatRatKnight and edited by Phaxuji.          |
|                                                                        |
|Also, compliments to the Data Crystal ROM map (presently located at     |
|https://datacrystal.romhacking.net/wiki/Final_Fantasy_VI/ROM_map ) for  |
|helping me find what I need.  The notes were good enough that I didn't  |
|need to spend hours diving into the rabbit hole of analyzing level up   |
|code when the functions were already broken up in easy pieces with      |
|useful comments.  And the RAM map helped (I sort of need to know what   |
|stats I'm tweaking).                                                    |
+------------------------------------------------------------------------+
==========================================================================
+------------------------------------------------------------------------+
|d04. PURPOSE OF MODIFICATION                                            |
|                                                                        |
|After releasing the level reset code hack (presently located at         |
|https://www.romhacking.net/hacks/7933/ ), I was requested to provide a  |
|level up code hack.  Well, here we are.  It was simplest to just keep   |
|the first level reset button code and then include an additional        |
|combination in one hack (I didn't want to worry about any sort of       |
|patching collisions).  And frankly, if you didn't want one button code, |
|you could simply... not do it?                                          |
|                                                                        |
|There were some small complications this time (like not finding my old  |
|stuff fully intact), however, there were still some pieces I was able   |
|to work from, so at least I didn't need to rework everything from       |
|scratch.  Besides, it wasn't a long project, so no huge loss either     |
|way.                                                                    |
+------------------------------------------------------------------------+
==========================================================================
+------------------------------------------------------------------------+
|d05. HOW THIS HACK WAS ACCOMPLISHED                                     |
|                                                                        |
|The code takes up 4 bytes at $C2FAAE as a long redirect to a short      |
|function and a whole bunch of bytes at $C3F091 for the main code.  And, |
|of course, I hook the code in from $C321F5, which is where the game     |
|sits on the status screen.                                              |
|                                                                        |
|I selected button combinations on the controller that don't seem to do  |
|anything at all on the status screen.  Of the twelve buttons that exist |
|on a standard SNES controller, seven of them did indeed appear to be    |
|occupied, but as a result that left five of them that were free to use. |
|I made my selection (as per the instructions above) by determining that |
|combining any three of those abandoned five shouldn't cause any         |
|conflicts.  Likewise, it should be difficult to accidentally activate.  |
|
|If you do end up somehow accidentally resetting your character's level  |
|(or inadvertently adding one), then I'm sorry for your inconvenience,   |
|but I would also question how you managed to press buttons in such a    |
|specific circumstance without meaning to.                               |
+------------------------------------------------------------------------+
==========================================================================
+------------------------------------------------------------------------+
|e06. USE AS YOU SEE FIT                                                 |
|                                                                        |
|Use this modification as you see fit.  This modification can be         |
|included and used with any other modifications.  No guarantees are      |
|implied as to its effectiveness.  This modification has not been tested |
|with any other.  Authors of their own modifications may feel free to    |
|use this one as they see fit.  No credit is necessary.                  |
+------------------------------------------------------------------------+