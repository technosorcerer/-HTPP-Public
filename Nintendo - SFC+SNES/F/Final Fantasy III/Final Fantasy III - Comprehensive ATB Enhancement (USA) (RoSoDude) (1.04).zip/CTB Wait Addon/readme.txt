Final Fantasy 6 -- Comprehensive ATB Enhancement v1.04 (CTB Wait Addon)
by RoSoDude https://rosodudemods.wordpress.com/

This patch augments the main ATB hack with an additional feature. When "Active" mode is selected in the config menu, battles work exactly as in the main ATB hack. When "Wait" mode is selected in the config menu, battles become fully turn-based, similar to FF10's Conditional Turn-Based battle system. In this mode of play, time stops when any command menu is open (not just submenus as with the default Wait mode), as well as when there are any commands waiting on the queue. The balance is nearly identical to the main ATB hack as time only proceeds between character turns, however there is no longer any real-time pressure to input commands.

Pressing the "skip turn" button also temporarily reverts to "Active" mode until the menu is fully drawn again, which can be used to pass time if the player wishes to delay a character's turn. The system also reverts to "Active" mode behavior when the player attempts to flee, enabling time to pass while the player characters roll for escape attempts.

This patch can be installed instead of OR on top of the main hack.

NOTE: When active time elements are removed, the wait time for Cyan's SwdTech (a.k.a. Bushido) gauge no longer serves any gameplay purpose, and so an alternate design that rebalances Cyan's ability timing while speeding up the gauge is desirable. HatZen08's "Sword Tech Ready Stance" patch is perfect for the job; I recommend installing the v1.1b version. Be advised that HatZen08's patch is for headered ROMs, so apply a (temporary) header before using it:
https://www.romhacking.net/hacks/995