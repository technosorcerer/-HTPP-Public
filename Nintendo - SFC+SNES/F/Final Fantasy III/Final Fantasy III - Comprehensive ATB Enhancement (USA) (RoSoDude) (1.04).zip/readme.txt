Final Fantasy 6 -- Comprehensive ATB Enhancement v1.04
by RoSoDude https://rosodudemods.wordpress.com/

Final Fantasy 6's ATB system has some notable flaws compared to other entries in the series. ATB is always running in the background regardless of battle animations, so commands can quickly pile up on the queue. This functionally caps the effectiveness of the Agility stat. Furthermore, it enables "Wait tricking" abuse with the Wait mode config setting, where the player enters a command submenu to pause ATB during player animations, but lets ATB resume during enemy animations to gain a turn order advantage. Finally, the Battle Speed config setting only serves to make enemy ATB speed slower relative to the player, instead of adjusting the actual pace of battles as the player would expect.

This hack makes ATB gauges and other battle timers pause during battle animations, similar to the "nATB" system implemented by Think0028 for Brave New World. However, this hack supports the Active/Wait mode config setting instead of defaulting to Wait. ATB speed and rates for all status effect timers are increased by 2-3x to offset the added downtime, and now scale consistently with the Battle Speed setting. The execution delay on several basic commands is removed to increase responsiveness during battle, but is maintained for other commands as an element of gameplay balance. The end result should be a more tactical and robust ATB system which can be tweaked to the user's preference using the in-game config settings.

Included alongside the main hack is an alternate "CTB Wait Addon" patch which removes all active time elements from battle when "Wait" mode is selected, similar to FF10's Conditional Turn-Based battle system. See the separate readme for details.

The hack is for non-headered US ROMs (v1.0 or v1.1). It is compatible with other hacks like C.V. Reynolds' Bug-Fix Compilation patch or Revised Old-Style Edition. This hack should be patched on top of those. Several bugfix patches are integrated into this hack to maintain compatibility:
-Assassin's Premature Continuation v0.20 patch
-Leet Sketcher's Rock Bottom v1.3 patch
-Leet Sketcher's Death Row v1.2 patch
-Leet Sketcher's Self Sneeze v2.0 patch
-Leet Sketcher's Invisible Zombie v1.0 patch
-RoSoDude's Quick Fix v1.02 patch

Source files for assembly are included as a reference for other modders.

Acknowledgements:
-Think0028 for creating the original "simple nATB" hack
-C-Dude for revising "simple nATB" to reinstate the Active/Wait config setting
-Lightning Hunter for correcting the patch to work with 1.1 ROMs
-Assassin for Premature Continuation v0.20
-Leet Sketcher for Rock Bottom v1.3, Death Row v1.2, Self Sneeze v2.0, Invisible Zombie 1.0
-HatZen08 for Even Gauge v1.1d

Changelist:
#### v1.00 ####
-Initial Release
#### v1.01 ####
-Fixed compatibility with 1.1 US ROMs
-Increased morph decay rate by 2x
#### v1.02 ####
-Reflect/stop/sleep/freeze timers now tick 3x faster for compatibility with any hack that rebalances their durations for vanilla ATB (previous releases overwrote the duration values)
-Doom countdown timer now starts at 2x reduced time instead of 4x reduced time
-Jump command delay reduced from 128*512 ATB to 96*512 ATB (originally 224*512 ATB)
#### v1.03 ####
-Fixed tentacle boss never draining HP during seize. Now HP drain from seize ticks 2x faster
-ATB fill rate formula now quadratically damps enemy Agility values for use with difficulty hacks that increase monster Agility stats above 99
#### 1.04 ####
-Integrated Self-Sneeze, Invisible Zombie, and Quick Fix patches
-Corrected jump command delay to 112*512 ATB as intended (previously 96*512 ATB)
-Fixed Palidor summon using the vanilla jump command delay (224*512 ATB)
-Increased Gil Toss execution delay back to vanilla (16*512 ATB)
-Revised ATB fill rate formula to increase effective Agility by 5 for all participants
-Revised slow/normal/haste multipliers from 32/64/84 to 43/64/96
-Eliminated integer truncation of slow/normal/haste multipliers in Battle Speed adjustment
-Revised fleeing behavior to be consistent with vanilla ATB (speedier):
	-Tripled range for random flee chance increment (previously rolled increment was doubled instead)
	-Removed filter that blocked 7 out of every 8 flee attempts, now immediate on flee chance success
	-Fixed staggered running animations on pre-emptive/side attack battles
-Added "CTB Wait Addon" bonus patches