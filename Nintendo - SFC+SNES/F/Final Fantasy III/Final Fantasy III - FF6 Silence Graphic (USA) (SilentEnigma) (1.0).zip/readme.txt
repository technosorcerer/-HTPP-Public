Title: FF6 Silence Graphic
Author: SilentEnigma
Version: 1.0
Release Date: 2020-09-08
Applies to: Final Fantasy III (v1.0) (U)

Contents:

  FF6-Silence_H_v1.0.ips = patch for headered ROMs

  FF6-Silence_NH_v1.0.ips = patch for unheadered ROMs

  readme.txt = this file


ROM Addresses:

    D2/0080 - D2/0081
    D2/0088 - D2/008B
    D2/0100 - D2/0101
    D2/0120 - D2/0123
    D2/0128 - D2/012B

    D3/0540 - D3/0587
    D3/0630 - D3/06BF
    D3/0750 - D3/07DF
    D3/08D0 - D3/095F
    D3/0A20 - D3/0A97
    D3/0AF8 - D3/0B27

Free space used: 96 bytes

    D4/C998 - D4/C9F7

--------------------------------------------------

TABLE OF CONTENTS

0. Description
1. Relevant Offsets & Disassembly
 a. Graphics Data
 b. Tile Map
2. Credits
3. Revision History
4. Legal

________________________________________________________________________________

  0. DESCRIPTION
________________________________________________________________________________


This patch accurately reverts the Mute spell graphic in FF3us to the unlocalized
FF6j version.

________________________________________________________________________________

  1. RELEVANT OFFSETS & DISASSEMBLY
________________________________________________________________________________

Contents

a. Graphics Data
b. Tile Map

==================================================
 a. Graphics Data
==================================================

The Silence spell graphic is comprised of a 6x6 matrix of 8x8 tiles (SNES 3BPP).

The following tiles are used multiple times in the FF3us Mute graphic, mirrored
as necessary:

 HiROM    Tile #
 -------  ------
 D3/01F8  0x0015
 D3/0540  0x0038
 D3/06A8  0x0047


In FF6j, the corners of the Silence graphic use this tile (also found in the
FF3us data):

 HiROM    Tile #
 -------  ------
 D3/04E0  0x0034


Most tiles from the FF6j version have a corresponding localized tile in FF3us.
FF3us Mute graphic tiles have been replaced with their FF6j counterparts as
follows:

 Source              Destination
 FF6j             |  FF3us (Modified)
 HiROM    Tile #  |  HiROM    Tile #
 -------  ------  |  -------  ------
 D3/0540  0x0038  |  D3/0540  0x0038
 D3/0558  0x0039  |  D3/0558  0x0039
 D3/0570  0x003A  |  D3/0570  0x003A
                  |
 D3/0648  0x0043  |  D3/0630  0x0042
 D3/0660  0x0044  |  D3/0648  0x0043
 D3/0678  0x0045  |  D3/0660  0x0044
 D3/0690  0x0046  |  D3/0678  0x0045
 D3/06A8  0x0047  |  D3/0690  0x0046
 D3/06C0  0x0048  |  D3/06A8  0x0047
                  |
 D3/0768  0x004F  |  D3/0750  0x004E
 D3/0780  0x0050  |  D3/0768  0x004F
 D3/0798  0x0051  |  D3/0780  0x0050
 D3/07B0  0x0052  |  D3/0798  0x0051
 D3/07C8  0x0053  |  D3/07B0  0x0052
 D3/07E0  0x0054  |  D3/07C8  0x0053
                  |
 D3/08E8  0x005F  |  D3/08D0  0x005E
 D3/0900  0x0060  |  D3/08E8  0x005F
 D3/0918  0x0061  |  D3/0900  0x0060
 D3/0930  0x0062  |  D3/0918  0x0061
 D3/0948  0x0063  |  D3/0930  0x0062
 D3/0960  0x0064  |  D3/0948  0x0063
                  |
 D3/0A50  0x006E  |  D3/0A20  0x006C
 D3/0A68  0x006F  |  D3/0A38  0x006D
 D3/0A80  0x0070  |  D3/0A50  0x006E
 D3/0A98  0x0071  |  D3/0A68  0x006F
 D3/0AB0  0x0072  |  D3/0A80  0x0070
                  |
 D3/0B40  0x0078  |  D3/0AF8  0x0075
 D3/0B58  0x0079  |  D3/0B10  0x0076


The FF3us version of the graphic uses 4 fewer unique tiles than the FF6j
version. The other tiles in this data segment are shifted up accordingly,
leaving 4 tiles' worth of contiguous free space at the end.

The 4 FF6j tiles without FF3us counterparts have been copied into the free space
as follows:

 Source           |  Destination
 FF6j             |  FF3us (Modified)
 HiROM    Tile #  |  HiROM    Tile #
 -------  ------  |  -------  ------
 D3/0588  0x003B  |  D4/C998  0x1311
 D3/0A38  0x006D  |  D4/C9B0  0x1312
 D3/0B28  0x0077  |  D4/C9C8  0x1313
 D3/0B70  0x007A  |  D4/C9E0  0x1314


==================================================
 b. Tile Map
==================================================

 > Tile map for Silence graphic starts at D2/0080.
 > Flag 0x8000 mirrors tile vertically.
 > Flag 0x4000 mirrors tile horizontally.

-------------------------------

1st (Top) Row

Original:
 D2/0080: 15 00 38 00 39 00 3A 00 38 40 15 00
Modified:
 D2/0080: 34 80 38 00 39 00 3A 00 11 13 34 C0

-------------------------------

5th Row

Original:
 D2/0100: 47 C0 6C 00 6D 00 6E 00 6F 00 70 00
Modified:
 D2/0100: 12 13 6C 00 6D 00 6E 00 6F 00 70 00

-------------------------------

6th (Bottom) Row

Original:
 D2/0120: 15 00 38 80 75 00 76 00 38 C0 15 00
Modified:
 D2/0120: 34 00 13 13 75 00 76 00 14 13 34 40

________________________________________________________________________________

  2. CREDITS
________________________________________________________________________________

Special thanks to:

  vivify93, for the commendable earlier restoration of the Silence graphic.
  https://www.romhacking.net/community/1523/

  kamesennin, for inspiring this hack.
  https://www.ff6hacking.com/forums/user-2359.html

________________________________________________________________________________

  3. REVISION HISTORY
________________________________________________________________________________


2020-09-08 : Version 1.0 released.

________________________________________________________________________________

  4. LEGAL
________________________________________________________________________________


Copyright (C) 2020 David R. Thompson (SilentEnigma).

The copyright holder ("author") permits the free use of the attributed work
referenced by this document exclusively for non-commercial purposes, provided
that the following conditions are met:
1. The author shall be given credit wherever the attributed work is reused,
 redistributed, or modified.
2. This readme document shall accompany any of the files comprising the
 attributed work wherever they are redistributed in unmodified form.

The work(s) and file(s) distributed with this document are provided "AS-IS",
WITHOUT ANY WARRANTY. The author shall not be held responsible for any damages
related to the use of work(s) and file(s) distributed with this document.
