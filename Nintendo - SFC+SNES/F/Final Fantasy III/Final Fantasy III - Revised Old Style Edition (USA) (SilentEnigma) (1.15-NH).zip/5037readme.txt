Title: Final Fantasy VI: Revised Old Style Edition
Author: SilentEnigma
Version: 1.15-NH [Unheadered ROMs only]
Release Date: 2024-01-02
Applies to: Final Fantasy III (v1.0) (U)
             - CRC32: A27F1C7A
             -   MD5: E986575B98300F721CE27C180264D890
             - SHA-1: 4F37E4274AC3B2EA1BEDB08AA149D8FC5BB676E7

Archive Contents:
-------------------------------

  FF6-RevisedOldStyleEdition_v1-15_NH.ips = the main patch
  readme.txt                              = this file

  docs\
    FF6ROSE-Name-Comparison.txt           = list of name changes
    FF6ROSE-Release-Notes.txt             = full revision highlights
    FF6ROSE-SRAM.txt                      = list of new save data event flags

  extras\
    FF6ROSE-AntiFix_v1-15_NH.ips          = bug fix removal
    FF6ROSE-FieldMainClasses_v1-15_NH.ips = class display tweak

  hacking\
    FF3us-Internal-ROM-Info_NH.ips        = FF3usME access patch
    FF3usME-Event-Fix_NH.ips              = FF3usME post-edit fix


TABLE OF CONTENTS
-------------------------------

  0. Introduction
  1. Installation
  2. Feature Details
  3. Utilities & Resources Used
  4. Credits
  5. Revision History
  6. Legal

________________________________________________________________________________

  0. INTRODUCTION
________________________________________________________________________________

Final Fantasy VI: Revised Old Style Edition is a thorough and nostalgic revision
of the text and presentation of Final Fantasy VI for SNES.

The purpose of the hack is to refine FF6's surface-level elements according to
the standard set by the PS1-era FF titles (e.g. FF Origins), while preserving
the scope and difficulty of the game as Square designed it. This is a classic
improvement-type hack intended for newcomers and veterans alike.

The dialog script has been revised based on multiple translation efforts, both
official (SNES/Woolsey, GBA/Slattery) and unofficial (kWhazit, Clyde Mandelin,
Lina Darkstar, et al.). It aims to combine the completeness and accuracy of the
GBA with the energy and pacing of the SNES, sans censorship. Much of the
official English text is retained in the updated script, particularly where the
SNES and GBA agree closely with one another. When unofficial sources are used,
the wording is adapted as necessary to maintain cohesion with the overall
script.

FF6:ROSE introduces two major advancements in its localization:

1) Numerous instances of mismatched character dialects, continuity errors, and
   unnecessary speaker ambiguity have been resolved for the first time using a
   novel method of dialog customization.

2) The names of almost all enemies and items have been retranslated at full
   length. Originally, these names were limited for technical reasons to 10 and
   12 letters, respectively. Using an expanded pool of monospace font graphics,
   the names of enemies and items now reach up to 14 and 16 letters in length,
   respectively, and only a handful require abbreviation.

FF6:ROSE is built on a modified version of C. V. Reynold's Bug-Fix Compilation.
It also includes decensored graphics and multiple quality-of-life enhancements.
Several of the new features have either been developed from scratch or updated
by the author specifically for this hack.

See the Feature Details section below for the full list of features.

FF6:ROSE has been made possible by the work of many, many FF6 fans and hackers
over the years, to whom the author is greatly indebted. See the Credits section
for a full list of acknowledgments.

________________________________________________________________________________

  1. INSTALLATION
________________________________________________________________________________

 1. Start with an unmodified FF3us SNES ROM "Final Fantasy III (v1.0) (U)".
    Only unheadered (3,145,728 bytes) ROMs are supported.

 2. Use an IPS patch utility to apply the appropriate FF6:ROSE patch to the ROM:
    - Use "FF6-RevisedOldStyleEdition_v1-15_NH.ips".

 3. Apply any tweaks from the "extras" directory as desired. (Tweaks are not
    recommended for first-time players.) See Section 2.g for details.


 Usage Note:
 -----------
  This hack uses save data not defined in the original FF3us.
  Using default FF3us save data with this hack may result in minor errors
  related to field dialog and NPCs.

________________________________________________________________________________

  2. FEATURE DETAILS
________________________________________________________________________________

Contents:

 a. Dialog Script Revisions
 b. In-Menu Text Revisions
 c. Quality of Life Enhancements
 d. Visual Enhancements
 e. Additional Modifications
 f. Bug Fixes
 g. Nonstandard Tweaks
 h. Hacking Support Patches

=================================================
 a. Dialog Script Revisions
=================================================

Prime sources in order of influence:

 1) T. Slattery (FF6 Advance)
     Pros: Official; highly accurate; Woolsey used as a starting point;
           some beneficial deviations.
     Cons: Overly eloquent phrasing, censorship, subdued style, occasional
           meta humor & pop culture references.

 2) T. Woolsey (FF3 SNES)
     Pros: Original translation; high energy; iconic Woolseyisms.
     Cons: Errors, technical constraints, not-so-beloved Woolseyisms,
           censorship.

 3) kWhazit
     Pros: Highly accurate; More literal and more succinct than Slattery;
           Retains many nuances glossed over by the official translations.
     Cons: Sometimes too literal for in-game use; unlocalized; incomplete.

 4) C. Mandelin (Tomato)
     Pros: Translates many NPCs not covered by other unofficial sources;
           Translator is a reliable professional.
     Cons: Research mostly published in unscripted video format; incomplete.

 5) FF6j Original Script (as reproduced by kWhazit)
     Pros: Zero translation errors.
     Cons: Continuity errors in the original Japanese script;
           The author of this hack does not know Japanese.
           The revised script relies on a combination of Japanese-English
           dictionaries, machine translations, and comparative analysis of
           other prime sources for accuracy.

 6) Lina Darkstar
     Pros: Special effort taken to faithfully convey characters' original
           personalities and the tone of major scenes.
     Cons: Errors, usually subtle; liberal paraphrasing; incomplete.

Secondary sources:

  - FF6 Improvement (DarkMage, incl. some content sourced from Sky Render)
  - Final Fantasy VI: Ted Woolsey Uncensored Edition c. 2015 (Rodimus Primal)
  - Final Fantasy VI: Stand Guard (Spooniest)

Additional acknowledgment:

  - Final Fantasy VI: Retranslated (hairy_hen)
      > Referenced as a quality standard during proofreading


Miscellaneous comments on the revised script:
-------------------------------------------------

Special weight has been given to Woolsey as the first official translation.
Iconic Woolseyisms, cultural references, and other minor deviations have been
retained where they benefit the script and do not obscure the original sense of
the line.

Some enjoyable Woolseyisms have been omitted (with great pain) if they were
irreconcilable with the game's plot or lore. Others have been salvaged via
compromise with more accurate renderings, or in rare cases, by simply appending
them to the end of the more accurate rendering.

Extra weight has also been given to Slattery as the highest-quality official
translation. Deviations taken by Slattery for localization purposes are often
retained where they do not hinder pacing.

Novel content is occasionally introduced by the author, usually for one of the
following reasons:
 - Replacing a Slattery novelty of higher complexity
 - Resolving a continuity error
    > Mostly minor issues related to NPCs, character acquaintances, dialects,
      party size, etc.
    > Many involve conditions not typically encountered during a typical first
      playthrough
 - Adding a speaker label to a generic caption
 - Joy

To sum up:
Hopefully more "reverent" than "revolutionary".

=================================================
 b. In-Menu Text Revisions
=================================================

The following have been revised/retranslated:
 - Enemies (ad-hoc up to 14 characters)
 - Items (ad-hoc up to 16 characters)
 - Abilities & Classes
    > Built on earlier hack "Restored Ability Names" (Angelo/SilentEnigma)
    > Dance names now retranslated without truncation
    > Field Esper list screen now displays the MP cost of the selected Esper
    > Character class names displayed in the status screen
 - Playable characters (FF6 Advance)
 - Character stats
 - Miscellaneous field menu text
 - Shopkeeper lines (based loosely on FF6 Advance)
 - Item & ability descriptions (based on kWhazit & FF6 Advance)

Additional field menu text:
 - Blitz names (based on Leet Sketcher's "Blitzscreen")
 - Dance and Rage descriptions (based on implementation by dn)

=================================================
 c. Quality of Life Enhancements
=================================================

A/B button functionality may be swapped from the config menu:
  - The swap is extended to vehicle controls and Blitz input confirmation,
    a change from FF6j's button customization feature
  - Tutorials referencing the A/B buttons adapt to the player's setting
  - Config menu mod is based on Madsiur's "Multiple Fonts" hack

"Soft Reset" v1.1 (SilentEnigma)
  - Press Start+Select+L+R to return to the title screen
  - May be used any time a full-screen menu is not open

"Optional Continue" v1.1 (SilentEnigma)
  - Player is given the choice not to continue after the party is defeated

"Docile NPCs" v1.0 (SilentEnigma)
  - Wandering NPCs defer to the player character if both are attempting to move
    into the same empty tile

"Cancel Button Dash" v1.2 (SilentEnigma)
  - Press the configured Cancel button to double walking speed on the field
  - Effect stacks with Sprint Shoes
  - During timed challenges, the countdown rate is doubled while dashing
  - Based on ff3DashB (MasterZed) + Sliding Dash fix (SilentEnigma)

"Alphabetical Lore" (SilentEnigma)
  - Lore ability lists are alphabetized

"Alphabetical Rage" (Assassin)
  - Rage ability lists are alphabetized

"Rage Checklist" (Novalia Spirit)
  - The field menu Rage list indicates in gray which rages are ready to be
    learned on the Veldt

"Y Equip/Relics" (Leet Sketcher + Subtraction)
  - Press Y in the Equip menu or the Relics menu to switch between the two

"Mastered Esper Icon Hack" (Madsiur)
  - Star icon is displayed next to each mastered Esper in the Esper menu

=================================================
 d. Visual Enhancements
=================================================

Dialog captions use the quotation format standardized by FF6's successors:
  - "Auto-Indent (Variant B)" (SilentEnigma)
  - "Battle Dialog Page Break" (SilentEnigma)

"Decoupled Color-Coded MP Digits" (SilentEnigma, based on Imzogelmo)
  - MP healing & MP damage numerals appear blue and pink, respectively
  - Reflected spells animation palette is not affected

Censored graphics are replaced by their Japanese counterparts:
  - Sprites for enemies, Espers, and mid-game bosses (Terii Senshi)
  - End-game boss art (Dr. Meat w/ additional fixing by SilentEnigma)
  - Pub signs (Dr. Meat)
  - "FF6 Silence Graphic" (SilentEnigma)

The original Final Fantasy VI intro is restored (Yazoo):
  - Splash screen preceding the title sequence is removed
  - Title sequence uses graphics & logos from the Japanese version
  - Translator slot is removed from the opening credits

"Woolsey Removed" (VoidKnave76)
  - The translator slot is removed from the closing credits

Additional visual enhancements:
  - "Color Wheel" (Leet Sketcher)
  - "King's Robes" (Leet Sketcher)
  - "Mini-Maps Upgrade" (Madsiur)

=================================================
 e. Additional Modifications
=================================================

"SwdTech Suspend" v1.0 (SilentEnigma)
 - Press X or Y from the Bushido gauge window to switch characters mid-charge

A limited selection of dummied-out dialog & NPC content has been reconstructed.
(See unused captions: 244, 250, 290, 433, 521, 1036, 1059, 1153, 2345, 2623.)

An alternate game configuration may be silently activated by holding the Select
button as a new game is about to start. The configuration is as follows:
  - Bat.Mode    Wait
  - Bat.Speed   3
  - Msg.Speed   3
  - Cmd.Set     Window
  - Gauge       On
  - Sound       Stereo
  - Cursor      Memory
  - Reequip     Optimize
  - Controller  Single
  - Btn.A/B     Swapped
  - Mag.Order   1
  - Window      4
  - Color       Font | Window
     > R        31   |  5   5   6   4  26  24   2
     > G        31   |  5   5   6   6  26  24   2
     > B        31   | 14  16  17  15  26  24   2

=================================================
 f. Bug Fixes
=================================================

The following patches are included in ROSE via C. V. Reynolds' Bug-Fix
Compilation Version 2.9 (https://www.ff6hacking.com/forums/thread-3764.html):

 * 1-Way Status Immunity         (Assassin)
   Agoraphobic Leader            (Novalia Spirit)
 * Allergic Dog                  (Novalia Spirit)
   Allo Ver Fix                  (Master Zed, Assassin)
   Alternative Rage              (SilentEnigma)
   Amnesic Cursor                (Novalia Spirit)
 * Anchors Aweigh!               (Imzogelmo/Lenophis)
 * Anonymous Attack              (Leet Sketcher)
   Auction Chocobo Fix           (Madsiur)
 * Auto Swordless Runic          (Assassin)
 * Auto-expiring statuses
    don't reset their timers
    with manual removal          (Assassin)
 * Backstabu                     (Leet Sketcher)
   Backwards Jump                (Leet Sketcher)
   Banquet Guards Go Back to
    Their Places                 (mblock129)
 * Bird Bars                     (Leet Sketcher) {modified by DrakeyC}
   Bland Entrance                (Leet Sketcher)
   Blitz Tutorial Fix            (C. V. Reynolds)
   Blush Disease                 (Novalia Spirit)
   Border Crossing               (Imzogelmo, Lenophis, Novalia Spirit)
 * Bottomless HP and MP Well     (Assassin)
   Bridge Correction             (Gi Nattak)
   Broken Gate                   (Novalia Spirit)
   Button Blunder                (Gi Nattak)
   Bye Bye Breath                (Leet Sketcher) {modified by C. V. Reynolds
                                  for FF3usME compatibility, and maybe
                                  compatibility with Blitz Tutorial}
   Can't lose for winning        (Lenophis)
 * Caravaggio                    (Leet Sketcher)
 * Carve Stone                   (Leet Sketcher ver) (Imzogelmo)
   Castle Party                  (Leet Sketcher)
   Cave to the Sealed Gate
    Basement 3 Event Megafix     (Assassin)
 * Celes' Rushing                (Djibriel)
   Chain of Command              (Leet Sketcher)
 * Chance Offering               (Leet Sketcher)
   Coin Flip Fix                 (Gi Nattak)
 * Control Attacks Ignore MP
    Cost                         (Assassin)
 * Control Menu Responds
    Poorly to MP Change          (Assassin)
 * Dead Hare                     (Leet Sketcher)
 * Dead in the Air               (Leet Sketcher)
 * Deceptive Tapir               (Assassin)
   Description Disruption        (SilentEnigma)
 * Disrespectful Zombie          (Assassin)
 * Double Block                  (Leet Sketcher)
   Drained Pool Tile Fix         (Gi Nattak)
^^ Duncan Stays Put              (mblock129)
 * Duplicate Enemy Names         (Assassin)
   Equip Anything fix            (Kejardon/Lenophis/Imzogelmo)
   Equip wrong item to slot
    via event                    (Assassin)
   Figaro Guard Fix              (DrakeyC)
 * Esper Battle Menu             (Lenophis)
 * Evade                         (Terii Senshi)
   Everybody Gets a Chocobo!     (PowerPanda)
 * False Knight                  (Leet Sketcher)
 * FC 05 enemy command           (Master ZED)
 * Flaky True Knight protection  (Assassin)
   Flight of Storm Drgn          (Novalia Spirit)
 * For What Ails Ya              (Lenophis/Imzogelmo/Kejardon)
   Frozen Mosaic                 (Novalia Spirit)
   Frozen Terra Fix              (Madsiur)
   Game Over                     (Leet Sketcher)
 * Genji Glove damage reduction  (Assassin)
 * Gogo and the Cursed Shield    (Imzogelmo) {fixed by Leet Sketcher}
   Gold Wrexsoul                 (mblock129)
   Grand Stairway                (Imzogelmo) {modified by C. V. Reynolds to not
                                  edit the script}
 * Half Knife                    (Leet Sketcher)
   Hasty T-Rex                   (Leet Sketcher)
   Homesick Gau                  (Djibriel)
 * I condemn thee to hell!       (Lenophis)
   Ignore Kamog                  (Drakkhen)
 * Imp Skimp                     (Leet Sketcher) {fixed by SilentEnigma}
 * Imp's Call                    (Leet Sketcher)
 * Imp's Rage                    (Leet Sketcher)
 * Imp's Retort                  (Leet Sketcher)
 * Imp's Retort Compatibility    (Leet Sketcher)
   Instant Airship               (Novalia Spirit)
 * Invert Damage if Undead       (Leet Sketcher ver) (Master ZED)
 * Ironic Metamorph Pack         (Assassin)
 * Item Magic Counter            (Leet Sketcher)
 * Jump Megafix (Version A)      (Assassin)
 * Jump-Launcher and Jump-Super
    Ball                         (Assassin)
 * Killer Life 3                 (Leet Sketcher)
   Lens Cap                      (Leet Sketcher)
   Loud Music                    (Leet Sketcher)
   Magic Sorting                 (Novalia Spirit)
 * Magitek Madness               (Leet Sketcher)
   Map Mishap                    (Leet Sketcher) {fixed by SilentEnigma}
   Menu Malarky                  (Leet Sketcher)
   Mine Cart                     (Imzogelmo)
^^ Miraculous, Death-Defying
    Always-Left-Facing Jumps in
    Zozo                         (mblock129)
   Miscolored command names
   (grayed version)              (Assassin)
   Misplaced Cursor              (Novalia Spirit)
   Missing Light                 (Novalia Spirit)
   M-Tek Vehicle in Cyan's Soul
    event                        (Imzogelmo)
 * Morph Mayhem                  (Leet Sketcher)
 * Muddle-Mantra                 (Assassin)
 * Muddle-Palidor                (Assassin)
 * Multi-Steal-Fix Simplified
    Edition                      (Imzogelmo, SilentEnigma)
   Multiple Events Fix           (Leet Sketcher)
 * Mute Steals Rage Statuses     (Assassin)
   Naming Shadow                 (Novalia Spirit)
   Narshe's Door                 (Leet Sketcher)
   Narshe's Secret Entrance Tile (Novalia Spirit)
 * Off Death Row                 (Leet Sketcher)
   Off the Hook                  (Leet Sketcher)
   Opened Eyes Terra Alt         (Madsiur)
   Overhead                      (Leet Sketcher)
   Persistent Whistle            (Novalia Spirit)
 * Petrified Rebel               (Novalia Spirit)
   Phantom Train Chests          (DarkMage) {modified by Leet Sketcher}
   Phoenix Chest                 (Leet Sketcher)
 * Pincer + Row                  (Assassin)
   Pink Gogo                     (Imzogelmo)
^^ Precious Jewels               (Leet Sketcher)
 * Premature Continuation        (Assassin)
 * Psycho Cyan                   (Terii Senshi)
^^ Pugs Rage                     (SilentEnigma)
 * Randomosity monster encounter (Assassin)
 * Recapture the Glory           (Assassin)
 * Reflect barrier shown on
    bodyguards                   (Assassin)
 * Reflectable Magitek Beams     (Assassin)
   Reflections                   (Leet Sketcher)
   Regulation Dice               (mblock129)
   Returner's Day Off            (Leet Sketcher)
 * Rock Bottom                   (Leet Sketcher)
   Save Point Switch             (Leet Sketcher)
 * Self Sneeze                   (Leet Sketcher)
   Setzer Bandana                (C. V. Reynolds)
   Shadow Chupon                 (Novalia Spirit)
 * Shadow Copy                   (Leet Sketcher)
   Shadow Gone                   (Leet Sketcher)
   Shadow's Shadow               (Madsiur)
   Shadow's Status               (Leet Sketcher)
   Shop Menu                     (Novalia Spirit)
   Shorter Skill Name Fix        (Madsiur)
 * Sketch Bug                    (Assassin)
 * Sketch Bug Second Part        (Assassin) {unreleased}
   Slightly lagged battle event
    timer display                (Assassin)
 * Smoke and Mirrors             (Leet Sketcher)
   Solar Wind                    (Leet Sketcher)
 * Some MP changes don't update
    menus                        (Assassin)
 * Soul Saved B                  (Leet Sketcher)
   SrBehemoth                    (Dragonsbrethren)
 * Stackable Immunities and
    Permanent Statuses           (Assassin)
   Status Icon Overflow          (SilentEnigma)
 * Status Unknown                (Leet Sketcher)
 * Step Mine MP cost             (Assassin)
 * Step Mine's Missing Digit     (Assassin)
   Stepping Out                  (Leet Sketcher)
 * Stone Cold                    (Leet Sketcher)
 * Stone Faced                   (Leet Sketcher)
   Stray Flash                   (The FF6Hacking Community)
   Stuck in a Pose               (SilentEnigma)
 * Summon Aim Fix                (Terii Senshi)
 * Suplex wrongfully splits
    damage                       (Assassin)
   That Damn Yellow Streak       (Assassin)
 * The Cowardly Dog              (Novalia Spirit)
   The Echoing Waters            (Novalia Spirit)
   The Magic Bridge              (Novalia Spirit)
   The Peninsula of Death        (Novalia Spirit)
   The Phantom Diary             (Novalia Spirit)
   The Sealed Door               (Novalia Spirit)
   The Sleazy Lender             (Novalia Spirit)
 * The Unilateral Blockade       (Novalia Spirit)
   The Wild Cat                  (Djibriel/Lord J)
 * There can be only one!
    Single-target                (Lenophis/Imzogelmo)
   Throw down (part of) the
    Gauntlet                     (Assassin)
 * Throwback                     (Leet Sketcher)
 * To Joker Doom or Not to Joker
    Doom                         (Lenophis)
   Transportation Device         (Novalia Spirit)
   Trigger Happy                 (Leet Sketcher)
   Tritoch Animation Fix         (bydoless)
   Tube Job                      (Gi Nattak)
   Turn Around                   (Leet Sketcher)
 * Ultimate Damage               (Leet Sketcher)
 * Unaffected Rows               (Assassin) {revised 2020}
   Unequipium                    (Leet Sketcher)
   Upside Down                   (Leet Sketcher)
 * Vanish Doom New Version
    + Fenix Undead               (Assassin)
 * Vanish Runic                  (Leet Sketcher)
   Vanishing Magicite            (Novalia Spirit)
   Vector's Cure-Castin' Kid no
    longer heals the dead        (Imzogelmo)
   Verdant Respite               (Novalia Spirit)
   Walk This Way                 (Leet Sketcher)
   Wrong Way, Idiot!             (Gi Nattak)
 * Zombie Rippler A              (Leet Sketcher)
 * Zombie Tapir A                (Leet Sketcher)
   Zoneseek No Thanks            (mblock129)
   Zozo Sign Petty Fix           (Madsiur)

^^ Required reapplication after FF3usME or other edits
 * Removable via nonstandard patch "FF6ROSE-AntiFix"

The following patches originally included in the C. V. Bug-Fix Compilation
version 2.9 have been superseded:

   Bad Decoration                (Lenophis)
   Doom Darts and Trump name fix (Assassin)
   Dusk Requium (SP)             (C. V. Reynolds)
   Imperial Camp Dialogue Bugfix (DrakeyC)
   Jewel Ring Description        (Assassin)
   Life 2 Description            (Imzogelmo)
   Magicite - Strength to Vigor  (C. V. Reynolds)
   Missing Dialogue              (Novalia Spirit)
   No X In Fight                 (Leet Sketcher)
   Various Texts'                (Imzogelmo)

The following patch is also included:

   One-Hit Wonder                (SilentEnigma)

=================================================
 g. Nonstandard Tweaks
=================================================

The following optional patches are included in the "extras" directory:

"FF6ROSE-AntiFix":
  - Reverts most bug fixes related to battle mechanics, including:
     > Evade
     > Psycho Cyan
     > Rippler
     > Sketch
     > Vanish+Doom
  - See marked bug fixes in Section 2.f above

"FF6ROSE-FieldMainClasses":
  - Adds class names to the field main menu and Load/Save confirmation menu

=================================================
 h. Hacking Support Patches
=================================================

The following patches are included in the "hacking" directory:

"FF3us-Internal-ROM-Info":
  - Restores the original internal ROM name "FINAL FANTASY 3     " and sets the
    internal ROM version to 1.0
  - This allows FF6:ROSE to be opened and edited (somewhat) in FF3usME

"FF3usME-Event-Fix":
  - Restores the following event patch data which get overwritten by FFusME:
     > "Miraculous, Death-Defying Always-Left-Facing Jumps in Zozo" (mblock129),
       CC/FF25-CC/FF45
     > "Duncan Stays Put" (mblock129), CC/FF46 - CC/FF50
     > "Precious Jewels" (Leet Sketcher), CC/FFB4 - CC/FFBA
  - Apply this patch AFTER making edits with FF3usME to prevent game crashes

________________________________________________________________________________

  3. UTILITIES & RESOURCES USED
________________________________________________________________________________

Utilities:
  Advanced Patch Conflict
    Finder (Leet Sketcher) http://l33t5k37ch3r.altervista.org/
  bsnes-plus (Revenant)    http://bsnes.revenant1.net/
  Cross-Knight Assembler
    "xkas" (byuu)          https://romhacking.net/utilities/269/
  FF3LE "Rogue Build"
    (d3tl4, giangurgolo,
    Lord J et al.)         http://angelfire.com/pq/jumparound/
  FF3usME (Lord J et al.)  http://angelfire.com/pq/jumparound/
  FF6Tools (Everything)    https://www.romhacking.net/utilities/1267/
  Floating IPS (Alcaro)    https://github.com/Alcaro/Flips
  Geiger's Snes9x Debugger
    (Geiger)               http://geigercount.net/crypt/
  HxD (Maël Hörz)          https://mh-nexus.de/en/hxd/
  Lunar IPS (FuSoYa)       http://fusoya.eludevisibility.org/lips/
  Notepad++ (Don Ho)       https://notepad-plus-plus.org/
  No$SNS (Martin Korth)    http://problemkaputt.de/
  WindHex32 (Bongo)        https://romhacking.net/utilities/291/
  YY-CHR (YY)              https://romhacking.net/utilities/119/

Disassembled Code:
  Banks C0/C1/C3:
    Imzogelmo              http://angelfire.com/al2/imzogelmo/patches.html
  Bank C2: Assassin
    (& Terii Senshi)       http://assassin17.brinkster.net/guides.htm

Web Resources:
  FF6 Hacking Wiki         https://ff6hacking.com/wiki/
  Final Fantasy Wiki       https://finalfantasy.fandom.com/wiki/Final_Fantasy_VI
  FantasyAnime FF6 saves   https://fantasyanime.com/finalfantasy/ff6/index.htm
  Jisho                    https://jisho.org/
  Google Ngram Viewer      https://books.google.com/ngrams
  Dictionary.com           https://dictionary.com/
  Thesaurus.com            https://thesaurus.com/
  RhymeZone                https://rhymezone.com/
  BitFontMaker2            https://pentacom.jp/pentacom/bitfontmaker2/

________________________________________________________________________________

  4. CREDITS
________________________________________________________________________________


Dialog Text.......................................

  Script revised by:
    D. Thompson (SilentEnigma)

  Source material authored by:
    T. Slattery
    T. Woolsey
    kWhazit                https://kwhazit.ucoz.net/
    C. Mandelin (Tomato)   https://legendsoflocalization.com/
    Lina Darkstar          http://icyforums.com/profile/634-lina-darkstar/
    B. Jackson (DarkMage)  https://sites.google.com/site/shadedmagus/
    Rodimus Primal         https://romhacking.net/community/2564/
    Spooniest              https://romhacking.net/community/1495/
    Sky Render             https://romhacking.net/community/1690/

  Special Thanks:
    hairy_hen              https://romhacking.net/community/5469/

In-Menu Text......................................

  Text based on revisions by:
    Angelo26               https://ff6hacking.com/forums/user-75.html
    Dr. Meat               https://sites.google.com/site/ff6relocalized/
    MetroidQuest           https://metroidquest.angelfire.com/Main.html
    James McPhee           https://ff6hacking.com/forums/user-714.html
    SilentEnigma           https://silentenigma.neocities.org/

  Source material authored by:
    T. Slattery / 'Final Fantasy VI Advance'
    Final Fantasy Wiki "Final Fantasy VI Translations" page editors:
      Adonzo, Armageddon11, AstrialJam, Bluerfn, Catuse167, Cavery210,
      Chocolancer, Chrono Cross, Clarent, DarthKitty, Dazuro, Deadlyslashsword,
      DrakeyBot, DrakeyC, Fenrir9, Flintlock Vitor, Goo Rayder, Henryacores,
      ILHI, Intangir Bot, JBed, Jeppo, Jimcloud, Johuotar, JudgeMasterKefka,
      Jvh47, Kahran042, Kaimi, Keltainentoukokuu, Kimlasca warrior, Kincyr,
      Koharu Nami, LeafShinobi, Leon95, Maverick King, Mecorx, Miphares, MMLN,
      Monterossa, Moocwisi, NeoBahamutZEROX, Odin89, Saethori, ScatheMote,
      Shockstorm, Silver Mage, Some Color Mage, Technobliterator, Telomeres,
      Tia-Lewise, Tonbery101, Violetmage, W-Crazyswordsman, WhiteSeeD, Wishtar1,
      Wyveelix, Xenomic, Xion Valentine, Yuanchosaan, Zolo6
      https://finalfantasy.fandom.com/wiki/Final_Fantasy_VI_translations

Quality of Life Enhancements......................

    Assassin               http://assassin17.brinkster.net/index.html
    Leet Sketcher          http://l33t5k37ch3r.altervista.org/
    Madsiur                https://romhacking.net/community/3360/
    Master ZED             https://masterzed.cavesofnarshe.com/
    Novalia Spirit         https://romhacking.net/community/996/
    SilentEnigma           https://silentenigma.neocities.org/
    Subtraction            https://ff6hacking.com/forums/user-2236.html

Visual Enhancements...............................

    Dr. Meat               https://sites.google.com/site/ff6relocalized/
    Imzogelmo              http://angelfire.com/al2/imzogelmo/patches.html
    Leet Sketcher          http://l33t5k37ch3r.altervista.org/
    SilentEnigma           https://silentenigma.neocities.org/
    Terii Senshi           http://rpglegion.com/
    VoidKnave76            https://www.romhacking.net/community/7536/
    Yazoo                  https://romhacking.net/community/445/

  Special Thanks:
    vivify93               https://romhacking.net/community/1523/

Additional Modifications..........................

    dn                     https://ff6hacking.com/forums/user-935.html
    Leet Sketcher          http://l33t5k37ch3r.altervista.org/
    Madsiur                https://romhacking.net/community/3360/
    SilentEnigma           https://silentenigma.neocities.org/

  Special Thanks:
    SSJ Rick               https://ff6hacking.com/forums/user-4.html

Bug Fixes.........................................

    Assassin               http://assassin17.brinkster.net/index.html
    bydoless               https://romhacking.net/community/4183/
    C. V. Reynolds         https://ff6hacking.com/forums/user-2262.html
    DarkMage               https://sites.google.com/site/shadedmagus/
    Djibriel               http://tenchinohoukai.cavesofnarshe.com/
    Dragonsbrethren        https://romhacking.net/community/296/
    DrakeyC                https://ff6hacking.com/forums/user-2064.html
    Drakkhen               http://drakkhen.jalchavware.com/
    Gi Nattak              http://ngplus.net/index.php?/profile/94-gi-nattak/
    Imzogelmo              http://angelfire.com/al2/imzogelmo/patches.html
    Leet Sketcher          http://l33t5k37ch3r.altervista.org/
    Lenophis               https://romhacking.net/community/528/
    Lord J                 http://angelfire.com/pq/jumparound/
    Kejardon               https://romhacking.net/community/725/
    Madsiur                https://romhacking.net/community/3360/
    Master ZED             https://masterzed.cavesofnarshe.com/
    mblock129              https://romhacking.net/community/3396/
    Novalia Spirit         https://romhacking.net/community/996/
    PowerPanda             https://romhacking.net/community/4292/
    SilentEnigma           https://silentenigma.neocities.org/
    Terii Senshi           http://rpglegion.com/

Special Thanks (Feedback & Error Reporting).......

    advanceblog            https://ff6hacking.com/forums/user-2451.html
    Bobolicious81          https://romhacking.net/community/6269/
    CintariZero
    chronor                https://ff6hacking.com/forums/user-2782.html
    Envinyon
    Frucella               https://ff6hacking.com/forums/user-2439.html
    HighPrincessErinys
    Jefferson T.D.M.
    kamesennin             https://ff6hacking.com/forums/user-2359.html
    Matt                   https://ff6hacking.com/forums/user-2343.html
    MegaMato
    RoSoDude               https://rosodudemods.wordpress.com/
    Rythian                https://twitch.tv/rythian
    Sia S.
    Xezcente               https://ff6hacking.com/forums/user-2919.html
    Zwei Hardt
    
FINAL FANTASY is a registered trademark of Square Enix Holdings Co., Ltd.
FINAL FANTASY VI (C) 1994, 2006, 2014 SQUARE ENIX CO., LTD.

The author of Final Fantasy VI: Revised Old Style Edition makes no claim to
FINAL FANTASY VI or any intellectual property contained therein.

________________________________________________________________________________

  5. REVISION HISTORY
________________________________________________________________________________


[See .\docs\FF6ROSE-Release-Notes.txt for cumulative release notes.]

2020-04-02 : v1.00
2020-05-13 : v1.01
2020-06-28 : v1.02
2020-10-11 : v1.03
2021-02-22 : v1.04
2021-02-27 : v1.05
2021-05-17 : v1.06
2021-10-11 : v1.07
2022-01-15 : v1.08
2022-03-01 : v1.09
2022-04-02 : v1.10
2022-08-09 : v1.11
2023-04-02 : v1.12
2023-04-02 : v1.13
2023-10-11 : v1.14
2024-01-01 : v1.15

New in Version 1.15:
--------------------
 - Fixed missing "Bushido OK" label in equipment detail screen
 - Updated "Alphabetical Lore" from v1.0 to v1.1
    > Fixes field menu Lore list errors when scrolling with L/R buttons
 - Fixed missing wait for button press after certain end-of-battle messages
 - Updated "C. V. Bug-Fix Compilation" to version 2.9
    > Integrates Status Icon Overflow update from v1.1 to v1.2
 - Made revisions to the field dialog script (#2100 - #2199 focus):
    > 36 minor edits
    > 7 major edits

________________________________________________________________________________

  6. LEGAL
________________________________________________________________________________

Final Fantasy VI: Revised Old Style Edition
Copyright (C) 2020-2024 David R. Thompson (SilentEnigma).

The copyright holder ("author") permits the free use of the attributed work
referenced by this document exclusively for non-commercial purposes, provided
that the following conditions are met:
1. This readme document shall accompany the attributed work wherever it is
   redistributed.
2. The above copyright notice and this permission notice shall accompany the
   attributed work wherever it is copied, reused, redistributed, or modified.
3. Credit shall be given to all contributors for their respective contributions
   to the attributed work as recognized in this readme document and other
   publicly available documentation.

The work(s) and file(s) distributed with this document are provided "AS-IS",
WITHOUT ANY WARRANTY. The author shall not be held responsible for any damages
related to the use of work(s) and file(s) distributed with this document.

FINAL FANTASY is a registered trademark of Square Enix Holdings Co., Ltd.
FINAL FANTASY VI (C) 1994, 2006, 2014 SQUARE ENIX CO., LTD.

The author of the attributed work referenced by this document makes no claim to
FINAL FANTASY VI or any intellectual property contained therein.
