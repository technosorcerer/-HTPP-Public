=================================
Comprehensive Arsenal Patch
for Final Fantasy III US 1.0

Version: 1.0
Author: Tomilho
=================================
This patch replaces 40-ish weapon animations (almost all weapons) with new ones designed by me, with a whole new spritework. I think the vanilla game is a bit samey with its weapon choices, specially comparing with Final Fantasy V, that due to the Job system had a lot of diversity in its arsenal.

Sprites were drawn with the objective of being as versatile as possible, able to work with most palettes (some of which were edited too), allowing many different possibilities.

You can find a spreadsheet with the replacements and some useful info about them in the .docx spreadsheet. Special thanks to DrakeyC, for creating the vanilla weapon animation spreadsheet, that was very useful in this project.

In the downloaded files, you'll find two .ips patches, the Hack-Oriented and the Plug-and-Play.

=================================
Hack-Oriented:
- Changes exclusively animation data: weapon sprites, palettes and animation scripts. Weapon name, stats, and indexing of animations remains unaltered, meaning that weapons may have animations that don't make sense, like a Mithril Claw having a Rod animation. That happens because, in the vanilla game, the animation for the claw is $32, which was replaced by the spiked rod, for example. Being compatible with FFUSME, this patch is intended for hackers who wish to create their own custom weapons or don't want the patch to overwrite weapons they may have already created.

- Applies to a FF3 Us 1.0 rom, headerless.

=================================
Plug-and-Play:
- Same as above, but with changes made to weapon data too, mainly the in the table at $ECE400, but also some weapon names, descriptions and stats. This one is intended for anyone who casually wants to shoot Kefka in the face with a shotgun, but doesn't want to bother adding the weapons by themselves. Changes made are the following:

- All weapons have an animation matching its name/type; some weapons were renamed to match their new visuals, like the "Nunchaku", and etc. Most names remain vanilla.

- Replaced Darts, Chakrams, Hawkeyes and some other stuff with 3 bows, 3 firearms and 5 maces (axe, hammer, battle mace and flails), and changed some of their stats: firearms and bows deal the same damage from back row, but maces, flails and etc don't. They are all categorized under the SPECIAL type.

- Characters who can equip firearms: Locke and Setzer (because Darts were replaced, he really needs a new type of weapon to use).

- Characters who can equip bows: Celes (I think, of all the characters, it suits her pretty well).

- All replacements here are insignifcant in terms of balancing. This is not meant to be a gameplay/systems focused patch, just cosmetic.

- Applies to a FF3 Us 1.0 rom, headerless.
