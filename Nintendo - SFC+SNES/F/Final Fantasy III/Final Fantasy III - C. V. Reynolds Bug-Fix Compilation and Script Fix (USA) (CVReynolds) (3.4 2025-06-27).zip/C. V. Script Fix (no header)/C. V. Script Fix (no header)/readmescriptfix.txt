Cobbled together by C. V. Reynolds (~Coraline Violet~).

Version 2.2 (Translating the Name Edition)

Patch updated May 31, 2025.


  For North American 1.0 version only! It might work with 1.1 as well, but I've not tested this. Beware if you try it on 1.1.

  If you plan to use the C. V. Bug-Fix Comp with this, you must apply the Bug-Fix Comp first. You can use either patch on its own as well, though. If you patch the Bug-Fix Comp over this, it'll cause two of the game's messages to display weird. But it will play otherwise. However, FEAR NOT. I've included a patch that will allow you to fix this. If you apply the Script Fix first, then the Bug-Fix second, apply the "Backward Application Fix" third. This will fix the messages to work right.

  For UNHEADERED rom images only. If you have a headered file, I recommend you remove it with a hex editor or a program designed to do so. If you'd prefer to keep the header (and waste the disk space, LOL), you can use the excellent program Headerizer, created by Leet Sketcher. You can download it from Leet Sketcher's site here: https://l33t5k37ch3r.altervista.org/headerizer.html

  Don't apply newer versions of this patch over older versions of this patch unless you're sure it won't mess things up.

  The host for this compilation is ff6hacking.com. This is currently the ONLY site that may host this compilation. However, hacks and other projects may use this compilation in their code even if those hacks are hosted on another website.


The checksums needed for the rom image (prior to any hacking) are as follows:

CRC-32 : A27F1C7A
MD-5   : E986575B98300F721CE27C180264D890
SHA-1  : 4F37E4274AC3B2EA1BEDB08AA149D8FC5BB676E7


This is the C. V. Reynolds Script Fix, "Translating the Name" Edition. The goal of this script edit is simple. I try to retain as much Woolsey as possible while fixing all the errors and inconsistencies in the script. All this was done at my discretion. I changed a lot more than I was expecting in my hunt for a "perfect" script edit. I have a few notes.

1: I tried to retain Ted Woolsey stuff whenever I could. I tried to be subtle about the changes I'd make. I also included a little Slattery at least once.

2: The goal of this project is NOT to uncensor the game. I might do an "uncensored" version in the future. But this isn't it. It still uses "perk ups" and "pearls" and such.

3: The goal of this project is to fix errors. All instances of intentional Woolsey "flavor" was left in if it didn't hurt consistency too much.

4: I tried to be non-intrusive with my writing. I don't like it when localizers "leave their mark" on the script with memes and references to stuff. That said, it's my project so it's my choice and so TOO BAD. ;P There's a reference to a Finch song that possibly nobody will ever notice. It's so indistinct, it might as well not be a reference, but it means something to me... There's also a reference to a Star Wars line that possibly everybody will notice. Anyway, I accomplished both with no changes to the meaning of the sentences. They came naturally to me while I was writing. They don't stand out as odd at all.

5: I took a liberty with the War Gods/Warring Triad. Sometimes Woolsey would call them "the Statues" and other times "goddesses". I chose to always call them Deities. I feel Woolsey could have gotten away with using this word in the 90s. Zelda and Pokemon used the word a little later. I didn't want to use the Statues because it is confusing and stupid. I didn't want to use Goddesses because one of them is actually called Goddess. I expect the strongest point of criticism of my script edit will be my use of Deities. Sorry if you don't like it.

6: I chose to make Cyan consistently use the olde English. Thou, thy, thee, and art appear consistently in his dialog throughout the game now.

7: See the included hard-to-read list of changes if you want to see what changed. Or maybe you could play through the game.

8: Was line 99 an ode to Dan Quayle? The world may never know.


Thanks to ShinxHijinx for testing this hack for me. It would have shipped with errors otherwise. He did a great job.

Thanks to Mato and Poe for the entertaining Legends of Localization streams of Final Fantasy VI. They inspired me to do this. And the vast majority of the script's errors I learned about from those streams. Knowing is half the battle!

Thanks to SilentEnigma for text entries 2814 and 2815. I couldn't think of anything close to as good as those are.

Thanks to Catone and C-Dude for discussing the Vicks/Wedge swap thing. They inspired later changes to this project.

Thanks to everyone who has supported me or will. I never thought you'd all be so good to me. I'm really just a shy nerd with OCD, but you all acted like I was somebody. Big thank you. :3