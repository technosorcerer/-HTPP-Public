Final Fantasy 6 -- Quick Fix v1.00
by RoSoDude https://rosodudemods.wordpress.com/

The "Quick" ability allows the user to enter two consecutive turns in battle while time remains paused for all other participants. However, Quick's implementation lead to two unintended consequences:
1. Status effect timers continue to tick for the Quick user while they are selecting their moves. This allows reflect to wear off, poison/regen to continue dealing damage/healing, and condemned to count down even as time is paused for everyone else
2. Characters who are in a defensive stance lose their defend status during and after Quick

Both of these oversights are due to the fact that Quick sets battle timers to stop (bits $3AA0.4 and $3AA0.6) on all participants who are not Quick in order to pause their battle timers, but leaves battle timers enabled for the Quick user. Subsequent code then clears the defend status bit ($3AA1.1) for any characters who have stopped battle timers, which in normal circumstances only applies to characters affected by KO, petrify, stop, sleep, freeze, or Tentacle's seize.

This patch refactors the subroutines at C2/083F (loop through characters to update stats and queue after each command) and C2/08C6 (check character for stopped battle timers and add pending actions to queue) to make room for a compact subroutine between the two that checks for Quick before allowing status effect timers to tick. The defend status is now cleared specifically for the intended conditions of KO, petrify, stop, sleep, freeze, and Tentacle's seize.

The patch is be compatible with v1.0 and v1.1 ROMs. It is also compatible with C.V. Reynolds' Bug-Fix compilation and SilentEnigma's Revised Old-Style Edition. Assembly is included as a reference for other modders. Thanks to Warrax for pointing out this issue.