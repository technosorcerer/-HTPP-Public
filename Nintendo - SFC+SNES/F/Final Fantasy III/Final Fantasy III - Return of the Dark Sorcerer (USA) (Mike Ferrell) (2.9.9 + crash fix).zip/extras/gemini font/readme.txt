This patch changes the default FF6 GBA small font (dialog) to that of Gemini's custom VWF he made for his Final Fantasy IV Prettified project.
All credit goes to him.