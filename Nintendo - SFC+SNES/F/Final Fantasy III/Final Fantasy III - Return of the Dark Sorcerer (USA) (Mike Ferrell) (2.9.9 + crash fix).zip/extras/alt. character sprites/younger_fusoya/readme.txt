This patch changes Fusoya's sprite and portrait to what one might imagine Fusoya to look like in his not so old/middle-aged prime, which would still be incredible old compared to our feeble human lifespans!

Credit: James White (made the sprite and portrait)