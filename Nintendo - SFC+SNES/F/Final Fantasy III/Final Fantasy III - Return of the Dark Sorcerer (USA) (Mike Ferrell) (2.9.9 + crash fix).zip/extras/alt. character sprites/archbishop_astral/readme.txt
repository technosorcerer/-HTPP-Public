This patch changes Astral's Wizard-looking sprite and portrait into that of a holy Bishop.

Credit: James White (made the sprite and portrait)