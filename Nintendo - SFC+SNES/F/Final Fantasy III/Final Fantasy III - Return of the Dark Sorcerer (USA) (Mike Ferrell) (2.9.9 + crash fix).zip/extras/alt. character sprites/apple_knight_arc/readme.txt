This patch changes Arc's Onion Knight sprite and portrait to that of a healthy green apple!
His class name however will remain 'Onion Knight', due to the dialog.

Credit: James White (made the sprite and portrait)