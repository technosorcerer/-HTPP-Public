This patch changes Avalon's sprite and portrait to that of a fully armored Shovel Knight-looking badass: Havoc Knight Avalon!

Credit: James White (made the sprite and portrait)