This patch changes Tifa's sprite and portrait to the style of Dirge of Cerberus Tifa.

Credit: James White (made the sprite and portrait)