This patch changes all the regular battle theme song instances to 8 possible random choices of 8 battle theme songs that exist in the hack.

Patch made by: Madsiur