RotDS - Restricted Esper Version (default as of version 2.0)

Firstly, a huge thanks to Synchysi for supplying the code that they used in the hack Brave New World, and greatly helping me understand how to set it up as well.

So, this patch does exactly what it says, restrics the espers to certain characters. There are 26 espers total.

There is still one character however that can equip all the espers, and that character is Aurora.

The reasoning behind this, is:
- Aurora is (Spoiler!!!) half-esper, so it makes sense that she would, keeping in mind the in-game reasoning for restriction is the characters'individual/personal affinities towards the espers, exept for Eiko, who's restriction decisions were based on her not become abusable/OP.

As for the rest of the characters, they are all restricted. There are 27 espers total but each character can equip just 10 various espers, except for FuSoYa, Golbez, who can equip 15, and Eiko who can equip 16. I took about a whooooole day figuring out a system of how to go about destributing the espers to which character, so I'm sure it could be better. I did however go about it with some planning and consideration, without changing the spells the espers teach mind you - basically I tried to match up an esper to the character's personality to some extent. For instance, Serin and Ronan are from the desert, so they get Ifrit. And they just look like they should, having red and black clothing. And Cloud, he has yellow spiky hair, so naturally he should get Ramuh/Lightning. Joking aside, in the end I just wanted most of the characters outside of the said few to have 10 possible espers to equip, in a somewhat diverse way.

I decided to not go super hardcore with the limiting and left them still a good selection of 10 (in most cases) espers each, just because I didn't want to limit the characters down too far. As I said, I didn't change around any of the spells the espers teach from the normal rotds version because I haven't devoted that much time to this as of yet and it seems pretty okay as is. Yes, the characters still share many a spell (and sometimes have the same spell to learn on different espers), but I feel this kinda has to be due to the difficulty of the hack. For instance, Cure spells and Time spells (Haste and Slow). The better tier spells are much more unique and spread out though, so no worries there.

Nothing much more to say about this, I hope it's fun to play and as always would appreciate any feedback in order to possibly make it better! And of course if you wish to not have esper restriction, there is a patch included in the hack package's 'extras' folder to have it back to normal.

~ Gi Nattak

_____


Here is a list of which character can equip which esper, and below that the spells they can learn.

Byte 1:
0 Ramuh - (cloud, avalon, serin, eiko, fusoya, mog, golbez)
1 Ifrit - (oboro, serin, ronan, eiko, arc, golbez)
2 Shiva - (cloud, ronan, tifa, mog, eiko, golbez)
3 Terra - (avalon, tifa, eiko, fusoya, otis, arc, golbez)
4 Midgar Zolom - (avalon, ronan, eiko, otis, golbez)
5 Ymir - (oboro, serin, otis, mog, golbez)
6 Madeen - (cloud, eiko, fusoya, arc, mog)
7 Leviathan - (avalon, oboro, tifa, eiko, fusoya, otis)

Byte 2:
0 K. Tonberry - (oboro, serin, ronan, eiko, fusoya, mog)
1 Ark - (serin, fusoya, otis, mog)
2 Vaalsparda - (cloud, ronan, tifa, eiko, fusoya, mog, golbez)
3 Odin - (serin, ronan, fusoya, arc)
4 Doomtrain - (avalon, oboro, ronan, golbez)
5 Bahamut - (avalon, serin, eiko, fusoya, golbez)
6 Anima - (cloud, eiko, otis, golbez)
7 Black Waltzes - (tifa, mog, golbez)

Byte 3:
0 Soul Caliber - (cloud, avalon, fusoya, arc)
1 Spiky Tiger - (avalon, cloud, tifa, eiko, fusoya, arc)
2 Yu Yevon - (avalon, serin, tifa, eiko, golbez)
3 Carbuncle - (oboro, ronan, eiko, otis, arc, golbez)
4 Search Ghost - (oboro, ronan, otis, golbez)
5 Sylph - (cloud, ronan, tifa, eiko, fusoya, mog)
6 Vysage - (oboro, serin, fusoya, otis, mog)
7 Unicorn - (cloud, avalon, tifa, eiko, fusoya, arc)

Byte 4:
0 Fenrir - (oboro, tifa, arc, golbez)
1 Hades - (oboro, serin, otis, golbez)
2 Phoenix - (cloud, fusoya, arc)

_____


Possible spells learned (outside of natural magic learning)

Aurora: all

Cloud:

Cure
Cura
Curaga
Arise
Blizzard
Dispel
Drain
Esuna
Expel
Freeze
Gravity
Icicle
Inferno
Nova
Osmose
Protect
Purify
Quake
Raise
Regen
Reraise
Scan
Scorch
Shell
Spark
Silence
Sleep
Slow
Storm
Ultima
Virus

Avalon:

Cure (comes with)
Cura
Curaga
Death
Dispel
Drain
Esuna
Expel (comes with)
Fireball
Flare
Flood
Frenzy (comes with)
Gravity
Icicle
Meltdown
Osmose
Protect
Purify (comes with)
Quake
Shell
Spark
Splash
Storm
Virus

Oboro:

Cura
Frenzy
Break
Confuse
Death
Drain
Expel
Fireball
Float
Flood
Freeze
Haste
Hex
Icicle
Meltdown
Meteor
Osmose
Plague
Protect
Reflect
Scorch
Shell
Splash
Stop
Teleport
Vanish
Vortex

Serin:

Cura
Curaga
Break
Confuse
Drain
Expel
Fireball
Flare
Float
Haste
Hastega
Hex
Holy
Meteor
Osmose
Plague
Protect
Scorch
Shell
Spark
Slow
Slowga
Splash
Stop
Storm
Teleport
Virus

Ronan:

Cure
Cura
Curaga
Frenzy
Blizzard
Confuse
Death
Drain
Expel
Fireball
Float
Flood
Freeze
Gravity
Haste
Hex
Holy
Icicle
Inferno
Meltdown
Nova
Osmose
Protect
Purify
Quake
Raise
Reflect
Regen
Scorch
Shell
Teleport
Vanish

Tifa:

Cure
Cura
Dispel
Esuna
Expel
Fireball
Flood
Freeze
Haste
Icicle
Meteo
Osmose
Protect
Purify
Raise
Regen
Scan
Shell
Spark
Silence
Sleep
Slow
Splash
Stop
Teleport
Vortex

Fusoya: has many spells learned

Eiko:

Cura
Blizzard
Confuse
Dispel
Drain
Esuna
Expel
Fireball
Flare
Float
Flood
Freeze
Gravity
Haste
Hex
Icicle
Nova
Osmose
Protect
Quake
Reflect
Scan
Scorch
Shell
Spark
Splash
Storm
Teleport
Ultima

Otis:

Frenzy
Cure (comes with)
Cura (comes with)
Death
Fireball (comes with)
Float
Flood
Freeze
Gravity
Haste
Hastega
Icicle (comes with)
Meteor
Protect
Quake
Reflect
Scorch
Shell
Spark (comes with)
Slow
Slowga
Splash (comes with)
Stop
Storm
Ultima
Vanish

Mog:

Cure
Cura
Blizzard
Break
Confuse
Expel
Float
Freeze
Gravity
Haste
Hastega
Hex
Icicle
Inferno
Meteo
Nova
Osmose
Plague
Protect
Purify
Quake
Raise
Regen
Scorch
Spark
Slow
Slowga
Splash
Stop
Storm
Teleport
Virus

Arc:

Cure
Cura
Curaga
Arise
Dispel
Drain
Esuna
Fireball
Freeze
Gravity
Haste
Holy
Icicle
Inferno
Protect
Quake
Raise
Reflect
Reraise
Scan
Scorch
Shell
Spark
Silence
Sleep
Slow
Stop
Storm
Teleport
Vortex

Golbez: has many spells learned

Shadow: whatever spells the current party has learned

_____

If anyone should want to edit who is assigned which esper, find these values starting at C3/FC97 in the ROM and change accordingly by way of boolean algebra & a binary to hex converter.

DB $FF,$FF,$FF,$FF	; Aurora
DB $45,$44,$A3,$04	; Cloud
DB $99,$30,$87,$00	; Avalon
DB $A2,$11,$58,$03	; Oboro
DB $23,$2B,$44,$02	; Serin
DB $16,$1D,$38,$00	; Ronan
DB $8C,$84,$A6,$01	; Tifa
DB $C9,$2F,$E3,$04	; Fusoya
DB $DF,$65,$AE,$00	; Eiko
DB $B8,$42,$58,$02	; Otis
DB $65,$87,$60,$00	; Mog
DB $4A,$08,$8B,$05	; Arc
DB $37,$F4,$1C,$03	; Golbez
DB $00,$00,$00,$00	; Shadow
DB $00,$00,$00,$00	; Slot 15
DB $00,$00,$00,$00	; Slot 16

; Byte 1, bit 0 = Ramuh
; Byte 1, bit 1 = Ifrit
; Byte 1, bit 2 = Shiva
; Byte 1, bit 3 = Terra
; Byte 1, bit 4 = Midgar Zolom
; Byte 1, bit 5 = Ymir
; Byte 1, bit 6 = Madeen
; Byte 1, bit 7 = Leviathan
; Byte 2, bit 0 = K. Tonberry
; Byte 2, bit 1 = Ark
; Byte 2, bit 2 = Tritoch
; Byte 2, bit 3 = Odin
; Byte 2, bit 4 = Doom Train
; Byte 2, bit 5 = Bahamut
; Byte 2, bit 6 = Anima
; Byte 2, bit 7 = Black Waltz
; Byte 3, bit 0 = Soul Caliber
; Byte 3, bit 1 = Spiky Tiger
; Byte 3, bit 2 = Yu Yevon
; Byte 3, bit 3 = Carbunkle
; Byte 3, bit 4 = Search Ghost
; Byte 3, bit 5 = Sylph
; Byte 3, bit 6 = Vysage
; Byte 3, bit 7 = Unicorn
; Byte 4, bit 0 = Fenrir
; Byte 4, bit 1 = Hades
; Byte 4, bit 2 = Phoenix
