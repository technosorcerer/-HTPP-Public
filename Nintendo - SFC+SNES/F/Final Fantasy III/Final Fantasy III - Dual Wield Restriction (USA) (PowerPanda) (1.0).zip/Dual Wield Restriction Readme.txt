Title: Dual Wield Restriction
Author: PowerPanda
Version: 1.0
Applies to: FF3us v1.0 (headered)

Contents:  dual_restrict_normal.ips - Apply to your rom to get changes. Includes equipment flags.
	   dual_restrict_normal_removal.ips - reverts your rom back to the original.

	   dual_restrict_lite.ips - Apply to your rom to get the changes. Gives code changes without setting any equipment flags. Meant mainly for hackers.
	   dual_restrict_lite_removal.ips - reverts your rom back to the original.

	   hex changes.txt - a text file that details the changes to hex and the new routines.

--------------------------------------------------------------------------------
-=Intro and Description=-
In all Final Fantasy games that include Dual Wielding, some weapons are compatible, and some are not. That is, except for Final Fantasy VI. In FFVI, if you equip the Genji Glove, you can dual-wield any weapon in the game. Two Katanas? You bet. Two 5-foot long spears? Sure! Curiously, the game does not allow this freedom with 2-Hand weapons (the Gauntlet relic); only certain weapons can be held with both hands. This is a bit of an oddity, since neither Final Fantasy V, which came immediately before, or Final Fantasy Tactics, which came immediately after, allowed for this freedom. (Technically, FFVII came before Tactics, but it did not have the 2H/Dual option.) This code makes FFVI operate like its bretheren by placing restrictions on which weapons can be dual wielded.

Why would you want this? Because creativity thrives with limitations. By restricting characters from using certain weapon combinations, you have more of an incentive to build an interesting party. Or, perhaps you are a hacker, and you want a little bit more control over how weapons are used in your party. This hack will give you an interesting dynamic to try out.

--------------------------------------------------------------------------------
-=Weapon Overview=- (Only applies to the Normal Patch)

Type	      2-Hand   Dual	
DIRK 1*		N	Y
DIRK 2*		Y	Y
SWORD 1**	Y	Y
SWORD 2**	Y	N
LANCE		Y	N
KNIFE		Y	N
ROD		Y	Y
BRUSH		N	Y
SPECIAL 1***	Y	N
SPECIAL 2***	N	Y
SPECIAL 3***	N	N
GAMBLER		N	Y
CLAW		N	Y
ATMA WEAPON	N	N

*Dirk 1 for standard dirks, like the Mithril Dagger. Dirk 2 is for "short swords" like the Gradeus, and for Shadow's special weapons, like the Blossom.
**Sword 1 is your standard sword, including the magic blades. Sword 2 is greatswords like the Ragnarok or Excalibur.
**Special 1 is for Maces and Clubs. Special 2 is for throwing weapons, like the Boomerang. Special 3 is for the Hawkeye and Sniper, which operate as a hybrid club/throwing weapon.

Note that the Brush has been changed to not be 2-Hand compatible. In addition, a few oversights have been corrected, such as the Illumina doing the same damage from the back row, and the Magus Rod enabling Runic. Both of these have been removed.

--------------------------------------------------------------------------------
-=Compatibility=-

COMPATIBLE AND RECOMMENDED:
*Genji Glove Damage Reduction (Assassin)
*Throw Down (Part of) the Gauntlet (Assassin)

"Genji Glove Damage Reduction" fixes a bug in the battle system that causes weapons used with the Genji Glove to not apply the correct damage formula. "Throw Down (Part of) the Gauntlet" fixes a display issue in the menu that makes the Gauntlet SEEM much less powerful than it actually is. I considered including both in this patch natively, but decided against it in case it would cause a conflict with other patches down the road.

COMPATIBLE
*CV Reynold's Bugfix Compilation Patch
Compatible, but you must apply the compilation patch FIRST, and this patch SECOND. Note that this compilation patch includes both recommended patches.

*Full Roster Patch
This can be applied alongside the patch that gives you 16 playable characters. They use different free space.

*Ignore Defense Patch A (Drakkhen)
This is the only other well-known patch that modifies weapon properties, adding piercing damage to weapons. It uses a different property flag and writes to different free space, so it is possible to combine the patches.

In general, "Dual Wield Restriction" is highly compatible with other patches due to 3 factors:
1. The free space used in C3 is not commonly targeted for hacks.
2. It makes most of its changes in-line, without relocating any surrounding code.
3. It rewrites the optimize sequence from top to bottom, rather than changing a few lines here and there.

As long as you apply this patch AFTER any other major patches, there's a good chance it will work.

--------------------------------------------------------------------------------
-=Under the Hood=-

In FFVI, there is a Weapon Properties byte, with the following values:
01: --			10: --
02: SwdTech Compatible	20: Same Damage from Back Row
04: --			40: 2-Hand Compatible
08: --			80: Runic Compatible

What the 4 blanks were originally meant to be, nobody knows. This hack checks the 04 bit for Dual Wielding compatibility. 04 was chosen so that it was easy to remember, as it is the inverse of the 2H bit, 40. If you are using FF3usME to make edits, it is the checkbox right underneath "SwdTech", labeled currently as a "?".

If you are using Drakkhen's Ignore Defense (aka Piercing) patch, that will claim bit 10. That leaves 2 bits (01 and 08) for future hackers.

The equip routine has been edited to allow checking for the 04 bit on each weapon if you have the Genji Glove equipped. If it is your first weapon; there is no restriction. If it is your second weapon, it will check to see if the weapon is dual wield compatible, and gray it out if it is not.

The optimize routine has been re-written from scratch, as a different logical flow was needed to make this hack possible. 3 failsafes have been built in:
1. If you have the Gauntlet equipped, but no compatible 2-Hand weapons, Optimize will equip a weapon and a shield instead.
2. If you have the Genji Glove equipped, but no compatible Dual weapons, Optimize will equip a weapon and a shield instead.
3. If you have the Gauntlet AND Genji Glove equipped, Optimize will favor the Gauntlet, and not try to equip dual weapons, even if you have no gauntlet-compatible weapons.

For displaying the Dual property from the item menu, a blank text entry was repurposed, and SwdTech/Runic/2-Hand were shifted up one line.

The final hurdle was figuring out how to enforce the dual wield restriction in battle. After 2 years of trying to figure out a way to do this, I have decided to simply disable equipping a second weapon in battle. If you need to switch out a 2nd weapon, you MUST switch it for a shield. This is not the ideal solution, but it is the only one that I can consistently get working.

--------------------------------------------------------------------------------
-=Known Issues=-

When re-equipping mid-battle, you cannot equip a second weapon, even if you have the Genji Glove equipped. This is intentional, as the code for checking compatible items has not been found yet. If there is ever a 2.0 of this patch release, it will be because this code has been found.

--------------------------------------------------------------------------------
Credits

Hacking - PowerPanda

Disassembly and Advice - Assassin, Madsiur

Programs Used
FF3usMe 6.80
Cygnus Hex Editor
Notepad++