Final Fantasy VI: Presentiment Era 3.3

The following is a mod for Final Fantasy VI (6) | Final Fantasy III (US) (SNES).
To play, you will need a SNES emulator such as Snes9x or ZSNES and an original FF3 (US) rom to patch.

Credits:
•Mr.Branford - FF6 Presentiment Era mod author.

SNES Presentiment Era:
-Focused Characters-
-Relm
-Clyde
-Carrière
-Terra

-Changes 3.3-
-Minor fixes

-Changes 3.2-
-Major fixes
-Added features
-BGM

~Changes 2.2~
-Portraits-
-Carrière
-Logo
-Spells
-Various fixes and additions
-Summon command fixes
-Summon fixes
-Minor fixes (2.1)
-extras/added features (2.1|2.2)
-text-

Clyde Full Sprites:
-Poco Loco-

Adult Relm:
-mickichiba-

Terra amano-blond:
-jcollins-

-FF3/FF6 sprite database-