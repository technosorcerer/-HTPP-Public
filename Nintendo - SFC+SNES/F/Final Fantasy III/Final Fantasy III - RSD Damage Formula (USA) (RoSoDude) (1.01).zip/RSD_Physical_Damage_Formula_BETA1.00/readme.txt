Final Fantasy 6 -- RSD Physical Damage Formula BETA 1.00
by RoSoDude https://rosodudemods.wordpress.com/

This hack is a fork of Leet Sketcher's Ultimate Damage Fix v1.4 patch, including all of its fixes in addition to the following changes:
-Physical damage formula (for player characters) changed:
	-Old formula: Damage = Attack + Level*Level*(Attack + 2*Strength)/256*(3/2)
	-New formula: Damage = Attack + Strength*Level*(Attack + Strength)/256
	-The new formula makes physical damage depend much more on the character's Strength (Vigor) stat, where originally it was mostly determined by character level
	-The new formula makes early game damage a bit higher, so it is recommended to reduce character base Strength values by 5-10 points unless you want them to be premier fighters
	-It is also recommended to tweak character abilities like Edgar's tools, Sabin's blitzes, and Cyan's bushidos to account for this increased early damage
-Strength stat now caps out in effectiveness at 255 (max possible) instead of 128
-Gauntlet relic now increases weapon attack by 1.5x instead of 1.75x to make up for higher early game damage values [NOT YET ACCOUNTED FOR IN EQUIP MENU]
-[NOT YET IMPLEMENTED:] Hyper Wrist adds +10 Strength instead of +50% Strength to account for the increased value of the stat

The hack has 10 bytes of space left over from editing Leet Sketcher's patch, so it can be tweaked a bit if you edit the .asm