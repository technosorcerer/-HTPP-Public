;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; RSD physical damage formula BETA 1.00
; edited from Leet Sketcher's Ultimate Damage
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

; Apply Ultimate Damage patch first, then this .asm on top
; IPS patch version includes both

; Old physical damage formula: Attack + Level*Level*(Attack+2*Strength)/256*(3/2)
; New physical damage formula: Attack + Strength*Level*(Attack+Strength)/256
; Gauntlet now increases Attack by 1.5x instead of 1.75x to save bytespace and due to increased early game damage
; Monster physical damage formula is still: Level*Level*(4*Attack+Strength)/256

hirom  ; don't change this
;header  ; comment out if your rom has no header

org $C22890
C22890: NOP #2 ; RSD: don't double strength when calculating hit rate (replaces ADC $A6)

org $C22B69  ; location in v1.0 and v1.1
;org $C22B64
damage_alg:
C22B69:	LDA $11AF  ; attacker's Level
C22B6C:	STA $E8  ; copy to $E8
C22B6E:	TAY  ; copy to Y
C22B6F:	LDA $11A2  ; check if attack is magical
C22B72:	LSR A
C22B73:	PHP  ; save P for future magic checks
C22B74:	STZ $EB  ; clear $EB
C22B76:	TDC  ; clear 16 bits of A
C22B77:	LDA $11A6  ; battle power if physical, spell power if magical
C22B7A:	REP #$20  ; 16-bit A
C22B7C:	BCC magical  ; branch if magical...
C22B7E:	CPX #$08  ; check if monster
C22B80: BCS quadruple ; RSD: branch if monster
C22B82: LDY $11AE  ; RSD: else copy strength to Y, overwrites level
C22B85: NOP #2 ; RSD: some leftover bytespace
C22B87:	BRA after_quad ; RSD: and branch to physical routine

magical:
C22B89:	TAY  ; store spell power if attack is magical, btw

quadruple:
C22B8A:	ASL A  ; if checks succeeded, quadruple power
C22B8B:	ASL A

after_quad:
C22B8C:	PHA  ; push power to stack
C22B8D:	LDA $03,S  ; check again if attack is magical
C22B8F:	LSR A
C22B90:	TDC  ; if it is, set A to 0
C22B91:	BCC multiply  ; if not, do the following
C22B93:	LDA $B2
C22B95:	ASL A  ; check if Gauntlet is equipped
C22B96:	ASL A
C22B97:	LDA $01,S  ; load battle power
C22B99: BCS clear_carry  ; if Gauntlet is equipped...
C22B9B:	LSR A  ; A = BP / 2
C22B9C:	ADC $01,S  ; A = BP * 3 / 2 ;;RSD: since damage is a little higher for early game, multiply by 3/2 instead of 7/4 (subtracts 3 bytes)

clear_carry:
C22B9E:	CLC

multiply:
C22B9F:	SEP #$20  ; set 8-bit A for a while

org $C22BD1
C22BD1: BRA check_relics ; RSD: skip over multiplying by 1.5 for player physical damage
C22BD3: NOP #6 ; RSD: new leftover bytespace
check_relics:
C22BD9:	TYA ; transfers battle power to accumulator to be added to damage