;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; RSD damage formula 1.01
; edited from Leet Sketcher's Ultimate Damage
; requires Assassin's Genji Glove damage reduction fix
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

; Apply Ultimate Damage patch first, then Genji Glove damage reduction fix, this .asm on top
; IPS patch version includes all three patches

; Old physical damage formula: Attack + Level*Level*(Attack+2*Strength)/256*(3/2)
; New physical damage formula: Attack + Strength*Level*(Attack+(3/2)*Strength)/256
; Gauntlet now increases Attack by 1.5x instead of 1.75x to save bytespace and due to increased early game damage
; Monster physical damage formula is still: Level*Level*(4*Attack+Strength)/256

hirom  ; don't change this
;header  ; comment out if your rom has no header

org $C20F3C ; RSD: Hyper Wrist effect moved due to Genji Glove patch
C20F3C: LDA $A6 ; load strength
C20F3E: CLC 
C20F3F: ADC #$000A ; was ADC $A6 (add 50% with the LSR value), now add +10
C20F42: STA $A6 ; store strength

org $C2288D ; RSD: strength still multiplied by 2x for use in damage calculations (effective cap 128)
; magic now also multiplied by 1.5x for damage calculations (effective cap 255->170)
; dummy speed variable not set
C2288D: LDA $A6
C2288F: ASL A
C22890: BCC not_max_strength
C22892: LDA #$FF
not_max_strength:
C22894: STA $3B2C,X     ; set vigor
C22897: LDA $A4
C22899: STA $3B19,X     ; set speed
C2289C: LDA $A2
C2289E: STA $3B40,X     ; set stamina
C228A1: LDA $A0
C228A3: JSR $47D6       ; A *= 1.5
C228A6: STA $3B41,X     ; set mag.pwr
C228A9: NOP #2

org $C22B69  ; location in v1.0 and v1.1
;org $C22B64
damage_alg:
C22B69:	LDA $11AF  ; attacker's Level
C22B6C:	STA $E8  ; copy to $E8
C22B6E:	TAY  ; copy to Y
C22B6F:	LDA $11A2  ; check if attack is magical
C22B72:	LSR A
C22B73:	PHP  ; save P for future magic checks
C22B74:	STZ $EB  ; clear $EB
C22B76:	TDC  ; clear 16 bits of A
C22B77:	LDA $11A6  ; battle power if physical, spell power if magical
C22B7A:	REP #$20  ; 16-bit A
C22B7C:	BCC magical  ; branch if magical...
C22B7E:	CPX #$08  ; check if monster
C22B80: BCS quadruple ; RSD: branch if monster
C22B82: LDY $11AE  ; RSD: else copy strength to Y, overwrites level
C22B85: NOP #2 ; RSD: some leftover bytespace
C22B87:	BRA after_quad ; RSD: and branch to physical routine

magical:
C22B89:	TAY  ; store spell power if attack is magical, btw

quadruple:
C22B8A:	ASL A  ; if checks succeeded, quadruple power
C22B8B:	ASL A

after_quad:
C22B8C:	PHA  ; push power to stack
C22B8D:	LDA $03,S  ; check again if attack is magical
C22B8F:	LSR A
C22B90:	TDC  ; if it is, set A to 0
C22B91:	BCC multiply  ; if not, do the following
C22B93:	LDA $B2
C22B95:	ASL A  ; check if Gauntlet is equipped
C22B96:	ASL A
C22B97:	LDA $01,S  ; load battle power
C22B99: BCS clear_carry  ; if Gauntlet is equipped...
C22B9B:	LSR A  ; A = BP / 2
C22B9C:	ADC $01,S  ; A = BP * 3 / 2 ; RSD: since damage is a little higher for early game, multiply by 3/2 instead of 7/4 (subtracts 3 bytes)

clear_carry:
C22B9E:	CLC

multiply:
C22B9F:	SEP #$20  ; set 8-bit A for a while

org $C22BC1
C22BC1:	LDA #$0005  ; RSD: base divisor = 64
C22BC4:	BCC magdivide ; RSD: branch if magical
C22BC6: INC A
C22BC7: INC A 
C22BC8: INC A ; RSD: now base divisor is 512 (accounts for multiplication by 2*strength earlier)
C22BC9: NOP ; RSD: leftover bytespace

magdivide:
C22BCA: CPX #$08 ; RSD: check if monster
C22BCC: BCC divide ; RSD: proceed to divide by 64 if not, otherwise divide by 32

physdivide:
C22BCE: DEC A ; RSD: divisor = 256 if monster physical, divisor = 32 if monster magical

divide:
C22BCF:	JSR $0DD1  ; v1.0 or v1.1 ; this function does the division
;C22BCF:	JSR $0DC9  ; SFC version only
C22BD2:	STA $E8
C22BD4:	PLP
C22BD5:	PLA  ; battle power if physical, spell power if magical
C22BD6:	BCC after_genjioff  ; if attack is physical, do the following
C22BD8: NOP ; RSD: leftover bytespace from deleting multiplication by 1.5
C22BD9:	TYA ; transfers battle power to accumulator to be added to damage

org $C22C08
after_genjioff: