Final Fantasy 6 -- RSD Damage Formula 1.01
by RoSoDude https://rosodudemods.wordpress.com/

This hack is a fork of Leet Sketcher's Ultimate Damage Fix v1.4 patch, including all of its fixes in addition to the following changes:
-Physical damage formula (for player characters) changed:
	-Old formula: Damage = Attack + 1.5*Level*Level*(Attack + 2*Strength)/256
	-New formula: Damage = Attack + Strength*Level*(Attack + 2*Strength)/256
	-The new formula makes physical damage scale much more with the character's Strength (Vigor) stat, where originally it was mostly determined by character level
	-The new formula makes early game damage a bit higher, so it is recommended to reduce character base Strength values by 5-10 points unless you want them to be premier fighters
	-It is also recommended to tweak character abilities like Edgar's tools, Sabin's blitzes, and Cyan's bushidos to account for this increased early damage
-Magical damage formula (for player characters) changed:
	-Old formula: Damage = 4*Spell_pwr + Magic*Level*Spell_pwr/32
	-New formula: Damage = 4*Spell_pwr + 1.5*Magic*Level*Spell_pwr/64
	-The new formula makes magical damage scale a bit less with the character's Magic stat
-Strength stat still caps out in effectiveness at 128
-Magic stat now caps out in effectiveness at 170 instead of 255
-Gauntlet relic now increases weapon attack by 1.5x instead of 1.75x to account for higher early game damage values
-Hyper Wrist adds +10 Strength instead of +50% Strength to account for the increased value of the stat

The IPS patch includes Leet Sketcher's Ultimate Damage Fix v1.4 and Assassin's Genji Glove damage reduction fix v1.01 (compatibility with C.V. Reynolds patch compilation)
The .asm file includes only the the unique changes to this hack