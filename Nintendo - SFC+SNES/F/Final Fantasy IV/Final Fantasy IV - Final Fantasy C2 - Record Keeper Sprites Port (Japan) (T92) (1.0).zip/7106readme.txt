Title: Final Fantasy C2 Record Keeper Sprites Port
Author: T92 
Version: v1.0
Released: 31/8/2022

===============
 Introduction.
===============
This hack changes the battle sprites of Final Fantasy C2 to the graphics of 
Final Fantasy Record Keeper.

The original Final Fantasy C2 used modified versions of the character battle 
sprites from Final Fantasy IV and Final Fantasy IV: The After Years. 
While some looked fine, others looked out of place, like Guy (a modified version 
of Palom from TAY), or Josef (Yang's sprite).

So I decided to port the sprites of Final Fantasy Record Keeper.
Note: I didn't replace Leonora's sprite because she doesn't appear
      in Record Keeper.

==========
 Patches.
==========
 FF C2 Version A RK sprites port v1.0.ips
	For Final Fantasy C2 Version A (Original enemy graphics)

 FF C2 Version B RK sprites port v1.0.ips
	For Final Fantasy C2 Version B (Enhanced enemy graphics)

Apply both to their respective ROMs.

========
 Bugs. 
========
Currently none (At least none introduced by this hack).
If you found a bug PM the author at RHDN to report it.

==============
 Changelog.
==============
V1.0
 - First release.

=================
 Special thanks.
=================
- Everything for FF6Tools wich was used to made this hack.
- Madruga and volo for the Record Keeper sprites.
- mrBrawndo for Anna and pig status' sprite.
