Final Fantasy II/IV - Rumbl

by kandowontu

Based off the disassembly by Everything8215

Apply patch - enjoy!

Optional alternate patches - kando mode+Rumbl:
Use this to enable:

-All characters start with insane hp/mp
-Dark cecil starts with 99 str
-Start new game right outside baron with all vehicles available and volcano open
-All vehicles can fly and land anywhere
-you can walk through walls on map and in towns (DO NOT WALK INTO CHESTS/POTS WITH ITEMS - THEY ARE ALL BAD EXITS)
-Some characters get some *extra* fun spells to start with
