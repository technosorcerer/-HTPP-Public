Final Fantasy V/5r Clean Edition
Readme & Changelog
March 2024, v1.7
----
Hello, this hack offers some interface adjustments in both FFV & FF5r (English) to make for a cleaner experience. Berserk & !Check now work as intended, Dash walk is always available (hold cancel button), Blue Magic has its own icon, L & R buttons work in the menus, and Menu button will pass the turn in battle. Many Ability, item and enemy names now match their appearance elsewhere in the FF series.

Plus more improvements (like 3, not 2, Images), and some nice bugfixes (most notably, Kiss of Blessings)! Please read the changelog to see them all.

Two patches are included; choose the correct one for your rom, apply, and enjoy the enhanced menus and more fluid battles that are closer to FFVI!

(Some minor, cosmetic patches are also included, to toggle Bartz's pants and sleeves and Lenna's sleeves on the Field/Dungeon maps, and to choose between a blue or red beret for BlueMage Krile. These will work with all known versions of the game.)

----
This FFV Clean patch is based on the RPGe translation from 1998. Minor script adjustments were made, to include renaming Cara to Krile, and Hiryuu to Dragon; more will occur as this project approaches version 2. Apply the "FFV Clean Edition" patch to an unheadered copy of FFVJ (the checksum & CRC data are listed below).
	
Additionally, this Edition can work with FF5r, yet it's designed at this time only for Serity's English version of FF5r-– gomen nasai. Find that patch at this link below, apply it to your FFVJ rom first, then apply the included "FF5r Clean Edition" patch. (No script edits were made to Serity's fine work.)

+ https://www.romhacking.net/hacks/7972/

----
For a full list of the UX/UI, Item/Magic, Job System & Text adjustments, please consult the included readme file.

With opensource content from:

+ http://x11.s11.xrea.com/ff5patches

+ https://www.romhacking.net/hacks/4537/

+ https://www.romhacking.net/hacks/3219/

+ https://www.romhacking.net/hacks/1408/

+ https://www.romhacking.net/hacks/6818/

+ https://www.romhacking.net/hacks/3216/

+ https://www.ff6hacking.com/ff5wiki/index.php/Main_Page


Thanks to Inu, noisecross, Tzepish, Leet Sketcher, Kandowontu, Chicken Knife, Nintenja, Squall, Samurai Goroh, madsiur, RaphielShiraha64, Guysons & Gen for any of these: patches, tools, guides, feedback, good vibes!
Thanks to s8fp98fd5k for “FF5r” and to Serity for its English translation!
Thank you to RPGe team for inspiring this community and delivering an epochal work, 26 years ago!
Thanks to Squaresoft for Final Fantasy V!


----
CONTENTS

Main patches:
+ FFV Clean Edition.ips
+ FF5r Clean Edition.ips

Cosmetic patches:
+ Pantz n Sleeves 3.ips (new field map sprites for Bartz n Lenna: already applied)
+ Shortz n Sleeveless 3.ips (original field map sprites for Bartz n Lenna)
+ KrileBlueBeret.ips (bluer BlueMage clothes for Krile: already applied)
+ KrileRedBeret.ips (original BlueMage clothes for Krile)
+ Cleaner Font for FFV+FF5r.ips (already applied to both, for use by other projects)

----
Known weirdness:
+ FFV: game may require soft reset upon party death ;_;
+ if a Zombified character Jumps, game will soft lock (confirmed in FFV only)
+ FFV: Config menu has ":p" instead of "Empty" for Re-equip option. Works as expected! Edit proving elusive, causes no known glitching.

----
DEVELOPMENT GOALS, WIP LOG

+ Apply any bugfixes that haven't yet been integrated
+ Complete RPGe script revisions (estimated 8% done as of this version)
+ Fix SwdSlap so it actually sets Stun/Paralyze status
+ Add extra armor icons from FF5r to FFV (will denote Clean Edition v2)

Eventually...
+ Create Clean Edition for FF5r Original (the Japanese romhack ^ↀᴥↀ^)
+ Fix Known Weirdness issues
+ Provide optional Pixel Remaster Battle sprites version! (will denote v3)
+ Inspire other FFV & FF5r romhacks by providing utility patches like the cosmetic stuff and the font patch


----
CHANGELOG

Updates in v1.7
+ *Dash is available at all times*, hold the Cancel button-- Thief Dash is faster, of course!
+ Power Drink bugfixed (IDK how I neglected this one XD, sorry)
+ new Bow weapon icon, and consistent shadows on all armor & weapon icons
+ original Scroll icon restored for the 3 Ninja Throw items with multiple targets (Flame, Water, Thunder)
+ some letter enhancements in both fonts (note "R", "v", "V", "w", "W", and some more)
+ Bartz and Lenna Field sprites bugfixed and beautified to further match their Freelancer Battle sprites
+ FFV script improved a bit, up to Worus: Faris speaks more nautically, and unapologetically; Galuf is a bit sharper, too. Boco gets a few warking credits, and Biggs and Wedge are distinct members of the Faris Pirates. Beginner's House revised slightly (go see).

(If you are using the Cleaner Font patch in your project, please note that Scroll & Diamond icons have shifted to new locations. All the new double letter tiles will show up in Battle messages, so feel free to use them in Ability, Spell and etc names!)


Updates in v1.65
+ Flail and MornStar changed to Staff weapons, to match FFVA & align better w Job equips
+ main character default name is no longer Butz in either game
+ FFV: Poisn => Poison
+ FF5r: Venom => Poison
+ Antidt => Poisna
+ Brsrk => Berserk
+ FFV: minor script fixes in early scenes
+ minor adjustments to Spell names


Updates in v1.63
+ FF5r: updates to item and ability names to align w FFV Clean Edition (as listed in v1.6 entry)
+ FF5r: !Detox => !Recover (amending a previous change)
+ FFV: script improvements up to Worus
+ adds font patch, to change the FFV RPGe font: intended for hackers to use in their own projects


Updates in v1.62
+ FFV: script improvements & fixing text that ran off the screen (unreadable)


Updates in v1.61
+ FFV: fixed 2 job names that were misspelled! Also improved a bit more dialog (up to Torna Canal)
+ slight improvements to the cosmetic patches-- some pixels were missing in Bartz & Lennas' sleeves


Updates in v1.6
+ FFV: !Dance/Waltz and !Lance BUGFIXED to correctly drain MP-- apologies for this glitch in v1.5

+ !Check now shows enemy weakness as well as HP (thanks to Inu)
+ FFV: !SwdSlap renamed !SoftHit, (bc still does not cause Stun)-- works with Berserk status though
+ Comet spell target can be chosen (credit to Inu)
+ bugfix to prevent "Kiss of Blessings" !Mix from working on certain bosses (like you've seen on YT: bravo, Inu!)

MANY name changes to to align with modern FF series:
+ FFV: Cara => Krile
+ FFV: Soft => GoldNeedl(e)
+ FFV: Revivify => HolyWater
+ FFV: Heal => Esuna
+ FFV: Safe => Prtct
+ Alert/Preemptiv(e) => FirstStrk & First Strike
+ FFV: !Pray => !Recover
+ FFV: !Capture => !Mug
+ FFV: !DragnSwd => !Lance
+ FFV: !Combine => !Mix
+ Launcher -> Artillery
+ Torrent -> Treant
+ Sol Cannon -> SoulCannon
+ StonedMask -> StoneMask
+ Rock Brain -> Strapparer
+ Bold Mani -> Dechirer
+ Barette -> Bulette
+ GajraGajri -> Galajelly
+ Merugene -> Melusine
And many more monsters, too!

+ improved "er" & "la" tiles in font
+ Bartz/Butz/Batts now wears white pants on the Field Map, like in Battle
+ Lenna also has sleeves on Field map, to match her Freelancer attire

+ FFV: many small script improvements, mainly in opening scenes





Updates in v1.51 (not publicly available)
+ FFV: fixes DualWield and 2-Handed confusion, these Abilities names were swapped ;_;
+ FFV: BuildUp => Focus
+ FFV: Elementalists => Geomancers




Changes in v1.5 - unless noted, changes apply to both games
+ bug fix patch "Galuf Gaffe "by Leet Sketcher added
+ FFV: bug fix patch "FFV Sprite Touch-ups" by Chicken Knife added
+ ** Berserk will trigger attack actions **: works w !Dance, !Jump, !Aim, etc (ASM work by Inu)
+ add support for 3 Images around a character (another fine Inu patch)
+ Giant Drink now works as expected on enemies (another fine Inu patch)
+ FF5r: added fast menu scrolling (yep, another fine Inu patch)

+ FONT IMPROVEMENT (all letters and punctuation freed of drop shadow; new combo tile "er")
+ Black magic icon changed to a black orb no outline (from grey orb w black outline)
+ Blue hat for Blue Mage Krile/Cara 🧢
+ adjust Freelancer job description slightly
+ ⚪️Size => ⚪️Mini
+ FFV: ⚪️Armor => ⚪️Safe
+ FFV: ⚫️Psych => ⚫️Aspir
+ FF5r: adjust Freelancer & Paladin description in Beginners' House
+ FF5r: edit 'Elementalists' to Geomancers in script
+ FF5r: small script typos fixed




Changes in v1.3
! BUGFIX last weapon class that was lost on Sort, KnightSwords (FF5r)

+ Applied FastROM support (thanks to Kandowontu)
+ Changed ‘Optimum’ to ‘Best’ in Equip Menu, re-equip message
+ Changed MASTER to EXPERT in Job Menu
+ Disambiguated ‘DualWield’ and ‘2-Handed’ in all occurrences
+ Fixed Weapon Descriptions in Item menu to fully agree w Ability names
+ Brawl => Barehand
+ Used new “ua” tile in several weapon & magic names




Changes in v1.2
! BUGFIX many weapon & armor classes that were lost on Sort in FF5r

+ Added support for "Better Items Menu" on FF5r after hacking in new item categories
+ Added support for "Pass Battle Turn w X Button" in FF5r
+ Added "Quick Death" to FFV & FF5r (thanks to LeetSketcher)
+ Edited Blind icon in FFV to match FF5r




Changes in v1.1
+ Added spear icon to weapon  𐃆TwnLance, removing final “Misc.” icon in items
+ Changed 🪃Full Moon to 🪃FullMoon
+ Added more patches to (attempt to) remove item handling glitches



Initial Changes, v1.0
+ L & R buttons scroll in Item Menu (Inu patch)
+ L & R buttons swap between characters in Status & Equip menus (Inu patch)
+ X button skips to next active character in battle (FFV only, also an Inu patch)
- (Skip in battle not done to respect FF5r difficulty curve)

+ Blue Magic spells now have diamond icons (🔷)
+ Mystery spell ???? now Revenge (in FFV)
+ Summon Magic spells now have category icons (⚫️⚪️🕒)

+ Boomerang icon from FFIV for 2 weapons: 🪃Full Moon, 🪃RisinSun
+ Whip icon used for: 〽Flail, 〽MornStar
+ Shuriken icon used for all throwable items (now ✦Flame, ✦Water, ✦Thunder + ✦Soot items)
+ ✦Pinwheel => ✦Fuma

+ Red Mage => RedMage
+ Dimen => Time
+ DmMgc => Time
+ ”Dimensional Magic” => “Time Magic”
