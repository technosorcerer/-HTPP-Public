Final Fantasy V/5r Clean Edition

Hello, this hack brings together some UI/UX improvements and adjusts some icons to make for a cleaner FFV and FF5r (English) experience.
Two patches are included: choose the correct one for your rom, apply, and enjoy the enhanced menus and more fluid battles that are closer to FFVI!

Romhacks this patch is built for:
- https://www.romhacking.net/translations/353/
FFV patch MAY work with other game versions (GBA Script, Spoof) but has not been rigorously tested on these.
- https://www.romhacking.net/hacks/7972/
FF5r patch is designed only for the English version of that hack-– gomen nasai. 🙇‍♂️

Interface adjustments in both FFV & FF5r
- L & R buttons scroll in Item Menu (credit to Inu)
- L & R buttons swap between characters in Status & Equip menus (credit to Inu)
- X button skips to next active character in battle (credit to Inu)
- Blind icon changed in FFV to superior FF5r version 😎🆚🌛

Blue Magic
- Spells have diamond icons (🔷) in all menus
- Mystery spell "????" = Revenge (changed in FFV)

Summon Magic
- Spells now have category icons (⚫️⚪️🕒)

Boomerang icon (🪃) from FFIV for 2 weapons:
- Full Moon
- RisinSun
Whip icon (〽) used for:
- Flail
- MornStar
Shuriken icon (✦) used for *all throwable items*:
- Flame
- Water
- Thunder
- Soot
(Now 6 throwing stars, not 2)
- Pinwheel = Fuma

Job System, Script adjustments
- Normal renamed to Freelancer
- Red Mage = RedMage
- Dimen = Time
- DmMgc = Time
- ”Dimensional Magic” = “Time Magic”

Tzepish’s “Better Items” patch applied:
Inventory now sorts by category!

LeetSketcher's "Quick Death" patch applied:
Mobs die without slowdown, even in groups!

With opensource content from:
- https://www.romhacking.net/hacks/1408/
- https://www.romhacking.net/hacks/6818/
https://www.romhacking.net/hacks/3216/
- http://x11.s11.xrea.com/ff5patches

Thanks to Inu, Tzepish, LeetSketcher, Samurai Goroh, madsiur, Nintenja for patches, tools, guides, and inspiration!
Thanks to s8fp98fd5k for “FF5r” and to Serenity for its English translation!
Thank you to rpge team for inspiring this community and delivering an epochal work, 25 years ago!
Thanks to Squaresoft for Final Fantasy V!

Changes in v1.1
- Added spear icon (𐃆) to weapon TwnLance, removing final “Misc.” occurence.
- Changed Full Moon to FullMoon.
- Added more patches to (attempt to) remove item handling glitches.
- Checked items for compatibility with Tzepish Better Item patch.

Changes in v1.2
- Added support for Pass Battle Turn w X Button in FF5r.
- Added support for "Better Items Menu" on FF5r after hacking in new item categories.
- Added Quick Death to FFV & FF5r.
- Edited Blind icon in FFV to match FF5r.
