FF5r Three Slots - by C_CliFF & clymax
------------------------------
Created for Final Fantasy 5 by C_CliFF, adjusted by clymax.

The rom must be unheadered.

"This is a simple patch that doubles EXP, Gil, and ABP to halve grinding."