This work is for

HatZen08's FFV Strategic Battle (2014)

and this patch must be applied AFTER

you patch your ROM with that patch.

https://www.romhacking.net/hacks/5955/

(Please note that it expects a headered base ROM.)

------

WHAT THIS DOES:

Gives the 4 new Abilities unique names, and descriptions.

Mantra -->  Uplift
Add 1 to level in battle. Stackable

Observe --> Secure
Gain Armor and Shell statuses

Analyze --> Bright
Gain Wall and Haste statuses. Wall is temporary

Slash --> Strike
Damage equals Max HP - HP

This patch also removes the ROM header.
LunarIPS always does this, so apologies if this bothers you. Feel free to put a copier header back on if you want. (Here is a great Windows tool to do that: https://www.romhacking.net/utilities/1638/ )

------
Stay tuned for more addenda to this great FFV mod.

- xJ4cks, 2025
https://www.notion.so/xj4cks/FF5-Mods-Review-2d56bad3142980598a61f2797c67305c