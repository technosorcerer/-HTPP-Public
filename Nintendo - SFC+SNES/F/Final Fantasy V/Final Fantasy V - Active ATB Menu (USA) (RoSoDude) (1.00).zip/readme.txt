Final Fantasy 5 -- Active ATB Menu v1.00
by RoSoDude https://rosodudemods.wordpress.com/

While generally well-implemented, FF5's ATB feels more "stop-and-start" compared to later entries
Most commands execute immediately after being entered, which blocks the next ready character's menu from opening
This patch adjusts the timing to open the next menu just before the current animation starts
This allows the player to buffer inputs during animations, speeding up battles on Active mode

This patch should be compatible with any other hack that does not radically alter the battle code.