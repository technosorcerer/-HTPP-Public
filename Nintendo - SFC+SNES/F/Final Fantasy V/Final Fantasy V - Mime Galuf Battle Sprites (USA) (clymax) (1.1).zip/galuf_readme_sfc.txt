+----------------------------------+
| Mime Galuf Battle Sprites in FFV |
+----------------------------------+

  | Introduction
  +--------------------------------------
    Mime Galuf isn’t accessible via normal means in the vanilla game. So, the developers didn’t bother with making battle sprites for that combo.

    Any tinkerer who’s tried using Mime Galuf will discover what ensues. Galuf turns invisible in battle and menu, but the game remains (otherwise) playable.


  | Features
  +--------------------------------------
    - This patch adds the “missing” battle sprites to the game.
    - This feature was first included in an update to my other hack, Whirlwind.
    - Community interest in this specific feature prompted its release as a separate patch.
    - The patch has been tested with FFVJ, as shown in the provided screenshots.
	- NEW! Version 1.1 now features custom sprites.
    - Support for this patch is available via the Whirlwind Discord.


  | Use With
  +--------------------------------------
    Database match: Final Fantasy V (Japan)
    Database: No-Intro: Super Nintendo Entertainment System (v. 20210222-050638)
    File/ROM SHA-1: E937B54FFF99838E2E853697E4F559359AA91FD6
    File/ROM CRC32: C1BC267D


  | Tools Used
  +--------------------------------------
    - Mesen2 by SourMesen
    - FF6Tools by everything8215
    - FLIPS by Alcaro


  | Related Hack
  +--------------------------------------
    Final Fantasy V: Whirlwind (SFC)
    https://www.romhacking.net/translations/7324/


  | Platform
  +--------------------------------------
    Super Famicom (SFC)


  | Game Credits
  +--------------------------------------
    - Square, developer and publisher of the original game.
    - Nintendo, licensor for the original game to be developed and published for the SFC.


  | Acknowledgment
  +--------------------------------------
    After version 1.0 was released, it was pointed out to me that another patch by another author (Grond) pre-dates my patch and achieves a similar result.  The other patch is not on RHDN but is available via the FF5 Hacking Wiki.  I was not aware of the other patch when making my patch for my Whirlwind hack.  Further, the approaches used by the two patches are believed to be different.


  | Version History
  +--------------------------------------
    Version 1.1 submitted on July 15, 2024 for release.
    Version 1.0 released on June 10, 2024.


  | License
  +--------------------------------------
    MIT License


  | Contributors
  +--------------------------------------
    clymax - hack creator
    https://cIymax.github.io/

    Zetawilk - custom sprite work for version 1.1
    https://www.romhacking.net/forum/index.php?action=profile;u=101351