Final Fantasy 5 -- Berserker ATB Fixes v1.01
by RoSoDude https://rosodudemods.wordpress.com/

FF5's Berserker is always slowest to engage the enemy, yet it has nothing to do with its Agility stat penalty. Rather, the Berserker (or any character under the zombie/confuse/berserk status) runs on its own ATB system, which can desynchronize with normal ATB under the following conditions:
-Battle start, where Berserkers receive a noticeable penalty to initiative
-Revival from death or removal of petrify status, upon which the Berserker can suddenly attack
-Due to the slow status, which does not affect zombie/confuse/berserk characters as much as it should
These discrepancies are hidden from the player as the Berserker does not show its turn progression in the ATB gauge display, but they nonetheless impact the Berserker's utility and make its behavior difficult to understand.

This patch aligns berserk ATB with normal ATB, such that the Berserker can gain first turn initiative in battle if they are built to overcome their Agility penalty, and they do not suddenly attack when revived or unpetrified. Berserk characters are properly hindered by slow, as are zombified or confused characters. Berserk characters reveal their turn progression in the ATB gauge display, while characters under the zombie and confuse status still have their true ATB hidden.

The patch incorporates/replaces Inu's kiss of blessing exploit fix (for any hacks that use bit 6 on monster data 25). Source files for assembly are included as a reference for other modders.