Final Fantasy V/5r Clean Edition
Readme & Changelog
February 2024, v1.62
----
Hello, this hack offers some interface adjustments in both FFV & FF5r to make for a cleaner FFV and FF5r (English) experience. Berserk & !Check now work as intended, Blue Magic has its own icon, L & R buttons work in the menus, Ability names match their appearance elsewhere in the FF series. Plus many more improvements!

Two patches are included; choose the correct one for your rom, apply, and enjoy the enhanced menus and more fluid battles that are closer to FFVI!

Four minor, cosmetic patches are also included, to toggle Bartz's pants and sleeves and Lenna's sleeves on the Field/Dungeon maps, and to choose between a blue or red beret for BlueMage Krile.

----
Romhacks this Edition works with:

+ https://www.romhacking.net/translations/353/

This patch MAY work with other FFV game versions (GBA Script, Spoof) but has not been rigorously tested on these.
	

This patch is designed only for Serity's English version of FF5r– gomen nasai.

+ https://www.romhacking.net/hacks/7972/

----
For a full list of the UX/UI, Item/Magic, Job System & Text adjustments, please consult the included readme file.

With opensource content from:

+ http://x11.s11.xrea.com/ff5patches

+ https://www.romhacking.net/hacks/4537/

+ https://www.romhacking.net/hacks/3219/

+ https://www.romhacking.net/hacks/1408/

+ https://www.romhacking.net/hacks/6818/

+ https://www.romhacking.net/hacks/3216/


Thanks to Inu, Tzepish, Leet Sketcher, Kandowontu, Chicken Knife, Samurai Goroh, madsiur, Nintenja & Gen for patches, tools, guides, and inspiration!
Thanks to s8fp98fd5k for “FF5r” and to Serity for its English translation!
Thank you to RPGe team for inspiring this community and delivering an epochal work, 25 years ago!
Thanks to Squaresoft for Final Fantasy V!



----
CONTENTS

Main patches:
+ FFV Clean v162.ips
+ FF5r Clean v161.ips

Cosmetic patches:
+ Pantz n Sleeves.ips (new field map sprites for Bartz n Lenna)
+ Shortz n Sleeveless.ips (original field map sprites for Bartz n Lenna)
+ KrileBlueBeret.ips (bluer BlueMage clothes for Krile)
+ KrileRedBeret.ips (original BlueMage clothes for Krile)

----
Known weirdness:
+ FFV: game requires soft reset upon party death ;_;
+ if a Zombified character Jumps, game will soft lock (confirmed in FFV only)
+ FFV: Config menu has ":p" instead of "Empty" for Re-equip option. Works as expected! Edit proving elusive, causes no known glitching.

----
CHANGELOG

Updates in v1.62

+ FFV: script improvements & fixing text that ran off the screen (unreadable)
+ adds font cosmetic patch


Updates in v1.61

+ FFV: fixed 2 job names that were misspelled! Also improved a bit more dialog (up to Torna Canal)
+ slight improvements to the cosmetic patches-- some pixels were missing in Bartz & Lennas' sleeves




Updates in v1.6
+ FFV: !Dance/Waltz and !Lance BUGFIXED to correctly drain MP-- apologies for this glitch in v1.5

+ !Check now shows enemy weakness as well as HP (thanks to Inu)
+ FFV: !SwdSlap renamed !SoftHit, (bc still does not cause Stun)-- works with Berserk status though
+ Comet spell target can be chosen (credit to Inu)
+ bugfix to prevent "Kiss of Blessings" !Mix from working on certain bosses (like you've seen on YT: bravo, Inu!)

MANY name changes to to align with modern FF series:
+ FFV: Cara => Krile
+ FFV: Soft => GoldNeedl(e)
+ FFV: Revivify => HolyWater
+ FFV: Heal => Esuna
+ FFV: Safe => Prtct
+ Alert/Preemptiv(e) => FirstStrk & First Strike
+ FFV: !Pray => !Recover
+ FF5r: !Detox => !Recover (amending a previous change)
+ FFV: !Capture => !Mug
+ FFV: !DragnSwd => !Lance
+ FFV: !Combine => !Mix
+ Launcher -> Artillery
+ Torrent -> Treant
+ Sol Cannon -> SoulCannon
+ StonedMask -> StoneMask
+ Rock Brain -> Strapparer
+ Bold Mani -> Dechirer
+ Barette -> Bulette
+ GajraGajri -> Galajelly
+ Merugene -> Melusine
And many more monsters, too!

+ improved "er" & "la" tiles in font
+ Bartz/Butz/Batts now wears white pants on the Field Map, like in Battle
+ Lenna also has sleeves on Field map, to match her Freelancer attire

+ FFV: many small script improvements, mainly in opening scenes





Updates in v1.51 (not publicly available)
+ FFV: fixes DualWield and 2-Handed confusion, these Abilities names were swapped ;_;
+ FFV: BuildUp => Focus
+ FFV: Elementalists => Geomancers




Changes in v1.5 - unless noted, changes apply to both games
+ bug fix patch "Galuf Gaffe "by Leet Sketcher added
+ FFV: bug fix patch "FFV Sprite Touch-ups" by Chicken Knife added
+ ** Berserk will trigger attack actions **: works w !Dance, !Jump, !Aim, etc (ASM work by Inu)
+ add support for 3 Images around a character (another fine Inu patch)
+ Giant Drink now works as expected on enemies (another fine Inu patch)
+ FF5r: added fast menu scrolling (yep, another fine Inu patch)

+ FONT IMPROVEMENT (all letters and punctuation freed of drop shadow; new combo tile "er")
+ Black magic icon changed to a black orb no outline (from grey orb w black outline)
+ Blue hat for Blue Mage Krile/Cara 🧢
+ adjust Freelancer job description slightly
+ ⚪️Size => ⚪️Mini
+ FFV: ⚪️Armor => ⚪️Safe
+ FFV: ⚫️Psych => ⚫️Aspir
+ FF5r: adjust Freelancer & Paladin description in Beginners' House
+ FF5r: edit 'Elementalists' to Geomancers in script
+ FF5r: small script typos fixed




Changes in v1.3
! BUGFIX last weapon class that was lost on Sort, KnightSwords (FF5r)

+ Applied FastROM support (thanks to Kandowontu)
+ Changed ‘Optimum’ to ‘Best’ in Equip Menu, re-equip message
+ Changed MASTER to EXPERT in Job Menu
+ Disambiguated ‘DualWield’ and ‘2-Handed’ in all occurrences
+ Fixed Weapon Descriptions in Item menu to fully agree w Ability names
+ Brawl => Barehand
+ Used new “ua” tile in several weapon & magic names




Changes in v1.2
! BUGFIX many weapon & armor classes that were lost on Sort in FF5r

+ Added support for "Better Items Menu" on FF5r after hacking in new item categories
+ Added support for "Pass Battle Turn w X Button" in FF5r
+ Added "Quick Death" to FFV & FF5r (thanks to LeetSketcher)
+ Edited Blind icon in FFV to match FF5r




Changes in v1.1
+ Added spear icon to weapon  𐃆TwnLance, removing final “Misc.” icon in items
+ Changed 🪃Full Moon to 🪃FullMoon
+ Added more patches to (attempt to) remove item handling glitches



Initial Changes, v1.0
+ L & R buttons scroll in Item Menu (Inu patch)
+ L & R buttons swap between characters in Status & Equip menus (Inu patch)
+ X button skips to next active character in battle (FFV only, also an Inu patch)
- (Skip in battle not done to respect FF5r difficulty curve)

+ Blue Magic spells now have diamond icons (🔷)
+ Mystery spell ???? now Revenge (in FFV)
+ Summon Magic spells now have category icons (⚫️⚪️🕒)

+ Boomerang icon from FFIV for 2 weapons: 🪃Full Moon, 🪃RisinSun
+ Whip icon used for: 〽Flail, 〽MornStar
+ Shuriken icon used for all throwable items (now ✦Flame, ✦Water, ✦Thunder + ✦Soot items)
+ ✦Pinwheel => ✦Fuma

+ Red Mage => RedMage
+ Dimen => Time
+ DmMgc => Time
+ ”Dimensional Magic” => “Time Magic”
