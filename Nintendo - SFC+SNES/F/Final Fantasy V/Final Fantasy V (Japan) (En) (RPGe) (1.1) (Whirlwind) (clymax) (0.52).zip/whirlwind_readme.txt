+----------------------------+
| Final Fantasy V: Whirlwind |
+----------------------------+

  | Introduction
  +--------------------------------------
    Improvement hack for players looking for more randomization than what the Four Job Fiesta (FJF) does.  Use only with RPGe’s FFV translation.


  | Features
  +--------------------------------------
    - Get a random job each level up.
    - All jobs are available to be assigned from the start.
    - Galuf has no Mime sprites, so protection was added to keep him from getting those rolls.
    - Equip up to three abilities instead of one.
    - Retro Achievements is supported.
    - NEW!  Beta build reenables Mime Galuf, adds auto and manual seeding, and supports saving/loading seed state with one save slot (other slots have been disabled).  This allows races.
    - The name entered for Bartz is taken as a manual seed.  If the name is "auto", however, then an auto seed will be set for you.
    - Help and discussions available via community Discord server.

    For a demonstration, see the video below.


  | Video
  +--------------------------------------
    https://www.youtube.com/watch?v=_9su_RzIIZM


  | Use With
  +--------------------------------------
    Final Fantasy V [T+Eng1.1_RPGe]
    No-Intro: Super Nintendo Entertainment System (v. 20210222-050638)
    File/ROM MD5 : 5245A6ED780D896F416CC8824AA36182
    File/ROM SHA-1: 8D5A83770C3D6F2B29B7825B5A17434616EC1C60
    File/ROM CRC32: 17444605


  | Retro Achievements
  +--------------------------------------
    Core Set
    https://retroachievements.org/game/29847
    
    Bonus Set - TBA/WIP
    https://retroachievements.org/game/29863


  | Special Thanks
  +--------------------------------------
    solidification on Retro Achievements for playtesting the hack.
    https://retroachievements.org/user/solidification

    SamuraiGoroh for his SNES RAM Map for Final Fantasy V.
    http://erick.guillen.com.mx/Codes/SNES%20Final%20Fantasy%20V.txt


  | Tools Used
  +--------------------------------------
    - Mesen2
    - HxD
    - GameHeader
    - FLIPS
    - FF6Tools


  | References Used
  +--------------------------------------
    - Final Fantasy V - Data Crystal - ROMhacking.net
    - Final Fantasy 5 Modding Wiki
    - Final Fantasy V - Code Notes - RetroAchievements, by Altomar (registration required)
    - Final Fantasy V Advance - Code Notes - RetroAchievements, by TheMysticalOne (registration required)
    - Three Slots hack by HatZen08
    - Final Fantasy V: Super Custom Classes by FlamePurge
    - Minimal PRNG implementation in 6502 asm by Arlet Ottens (Arlet)
    - 65C816 Opcodes by Bruce Clark


  | Community Discord Server
  +--------------------------------------
    Because the Discord link is not currently permanent, please check the other links in this file for the latest Discord link.


  | Issue Tracker
  +--------------------------------------
    Issues also taken via the Discord server, but the web tracker is here.
    https://github.com/cIymax/final-fantasy-v-whirlwind


  | Platform
  +--------------------------------------
    Super Famicom (SFC)


  | Game Credits
  +--------------------------------------
    - Square, developer and publisher of the original game.
    - Nintendo, licensor for the original game to be developed and published for the SFC.


  | Version History
  +--------------------------------------
    Updated hack submitted on June 7, 2024 as version 0.52 beta.  Includes a hotfix to allow saving over existing save data.
    Updated hack submitted on June 6, 2024 as version 0.50 beta.
    Hack created during May 6-31, 2024 and submitted on June 4, 2024 as version 0.47.


  | License
  +--------------------------------------
    MIT License


  | Creator
  +--------------------------------------
    clymax
    https://cIymax.github.io/