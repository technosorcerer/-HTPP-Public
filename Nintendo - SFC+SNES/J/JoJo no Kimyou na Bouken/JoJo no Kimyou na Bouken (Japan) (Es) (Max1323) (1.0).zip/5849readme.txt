"JoJo no Kimyou na Bouken" o "JoJo's Bizarre Adventure"
Traducción al Español Ver. 1.1 (18/02/2024)
por Max1323 (Traducciones Max1323).
Basada en la gran traducción de Aeon Genesis.
---------------------------------------------------
Descripción:
JoJo's Bizarre Adventure es un RPG desarrollado por WinkySoft.
La historia se centra en la tercera parte: Stardust Crusaders.
1989, Japón, la historia se centra en Jotaro Kujo, nieto de
Joseph Joestar. Creyendo que lo poseyó un espíritu maligno,
se encierra en la cárcel. 
Con la llegada de Joseph y Avdol a Japón, estos le explican a
Jotaro sobre los espíritus malignos o mejor conocidos como
"Stand". Pero eso no será lo único, también deberán enfrentarse
a DIO, un enemigo de la familia Joestar de hace 100 años.
Deberán cumplir con su destino para derrotarlo y terminar
con ese peso que lleva el linaje desde hace mucho tiempo.

Desarrollado: WinkySoft
Publicado:    Cobra Team
Lanzamiento:  05/03/1993 (JAP)
---------------------------------------------------
Acerca del proyecto:
-Se tradujo los textos y contiene los acentos españoles.

-Se cambiaron los nombres de Dio a DIO y Terence a Telence.

- (Actualización) Con la versión 1.61 de Snes9x se solucionan algunos de estos problemas.
	Es posible jugarlo hasta el fin con el emulador Snes9x
	pero con ciertos bugs. 
	Ejemplo: No poner Start antes de la intro
	del juego, va a ocurrir que la pantalla no se vea.
	Las palabras HP y MP no aparecen en las batallas y al guardar.
	Es recomendable jugar con ZSNES en PC. En android con
	Snes9x EX+

-Hay un bug en el que el menú que las palabras traducidas vuelvan a estar en inglés.

Solo ocurre cuando vas a equipar un objeto. No ocasiona ningún error cuando lo jugué.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS (PC)
Utilizar UniPatcher (Android)
Utilizar Rom Patcher JS (Parcheador Online):
https://www.romhacking.net/patch/

Archivo IPS
JoJo no Kimyou na Bouken (Japan).sfc/smc
File size     1.00 MB
File MD5      CD17D26A8C27B57E0A50043A686923B4        
File SHA-1    8F1C62568C930C47B271C960BE9BB9BB9276B782
File CRC32    56BA694A