- Patch the mentioned ROM.


Start screen:
	- On the cheat option you can press left or right to unlock a cheat. (Only one since the other one can be toggled in game)
	- Press start on the cheat menu to enter the sound test. (The screen is buggy but you can play all music and SFX)
	
While pause:
	- Hold L and press R to unlock all weapons. (select by pressing select when unpaused)	
	- Hold L and press X to toggle cheat 1. It will make the player invincable.
	
Cheats works as described here:
	CTRF: https://tcrf.net/Joe_%26_Mac_(SNES)
	
Randomizer is sadly still a bit buggy. But thanks to the cheats you can skip broken bosses with start+select.
	https://micheilskeens.com/joe-and-mac-randomizer.php
	
More cheats avalible at:
	https://gamehacking.org/game/29957	


Database match: Joe &amp; Mac (USA)
Database: No-Intro: Super Nintendo Entertainment System (v. 20210222-050638)
File/ROM SHA-1: BE48F2193AD088B6EA395CAEB2D03FA190480418
File/ROM CRC32: 3A2B6167