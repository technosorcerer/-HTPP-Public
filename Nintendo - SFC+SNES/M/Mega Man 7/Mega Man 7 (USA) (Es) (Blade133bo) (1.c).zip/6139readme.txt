Mega Man 7, llamado Rockman 7: Shukumei no Taiketsu! (ロックマン 7: 宿命の対決! Rockman 7: Shukumei no Taiketsu!?, trad. "Rockman 7: ¡Rivalidad Destinada!") originalmente en Japón, es el segundo videojuego de saga clásica para Super Famicom/SNES. Además, este videojuego introduce a Auto, el asistente de Laboratorios Light, que dirige una tienda en donde Mega Man puede comprar ítems y mejoras a cambio de pernos y tornillos. Sin embargo, también presentó a Bass y Treble, dos antagonistas principales. Este videojuego también presenta el Super Rush Jetpack.

DATOS
Como ya tenia hecha una traducción hecha para el recopilatorio de la GameCube, en la que habia usado la rom de Snes para modificarla, pero no había publicado esa versión por mi cabezoneria, cosa que el Msu-1 y otras limitaciones de la version de GameCube me animaron a revisar mi postura.
Por ahora esta version esta enfocada a la version USA del juego, aunque bebe un poco de la version japonesa en algunos puntos. Espero poder completar otra versión con la retraducción de "Hondoory"

CAMBIOS
1.a  Pequeños cambios en el script por un error inesperado, y la actualizacion del subtitulo.
     Y un parche con el refit, no es compatible con MSU-1, asi que no intenten parchearlo.

1.b  Correccion del opening y un error de tipeo, (Gracias a Leo Monzon por el dato)
     Ademas de sumar el script Japones de Hondoori, tendran que parchear sobre el juego parcheado, "Megaman_7_Español", Aunque deberia funcionar en cualquiera de las 3 opciones.

1.c  Actualizacion de los sprites de megaman, gracias a X.M.Hunter, he tenido que corregir algunos sprites que se veian mal, cuando megaman se pone de frente o coge algún item y cuando tiene el escudo. y las paletas del grafico final en sepia.
     Solo habra 2 parches, el original sin subtitulo "Megaman 7 sin subtitulo.ips", y el nuevo "Megaman 7 Español+.ips" con los sprites y convinación de todo lo mejor del refit, más la traduccion del script Japones. (Necesito ayuda para corregir la cutscene del inicio)

CREDITOS
Esta version usa como base el parche.
"Mega Man 7 Restoration"
https://www.romhacking.net/hacks/3609/
De SCD, y los assets de la version de Shinichi999 (Algunos graficos, la traducción de los textos de presentación de los Robots maestros.
https://www.romhacking.net/translations/5250/
Ademas con los sprites corregidos de Zynk Oxhyde.
http://www.romhacking.net/translations/1792/
Incluido el parche Msu-1 de DarkShock y por si fuera poco, aqui tienen los PCM con el Arranged de varix.
https://mega.nz/file/Rcc32aiQ#fjc38lz7s39NOeRaYLiU75Poenan64M34c6L_50oa88
Así que solo tienen que renombrar el rom a "megaman7_msu1.sfc" con el pack.
Y la última adición a sido el logo estilo japones de DarkSamus993.
https://www.romhacking.net/hacks/8059/
de X.M.Hunter, que para mi siempre ha sido un sueño que megaman tenga esos sprites.

Última adición el Script Japones de Hondoori.
ROM REQUERIDA
    Mega Man 7 (USA).smc
    SHA-1: 6E7C9C9DD397F771303EE4AEC29D106B9F86C832
    CRC32: 2D947536

AGRADECIMIENTOS
A RealGaea, por su inestimable ayuda en la revisión y testeo.



Reporte de cualquier error.
blade133bo@gmail.com
Copyright Š 2000. Megaman 7, and all related characters are registered trademarks of CAPCOM Co., Ltd.