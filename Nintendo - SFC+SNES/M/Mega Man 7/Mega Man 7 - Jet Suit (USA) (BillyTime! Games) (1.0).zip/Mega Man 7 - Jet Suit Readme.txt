Mega Man 7 - Jet Suit 
Jan. 17th 2025
BillyTime! Games
--------------------
This is a simple patch designed for Mega Man 7 skips the intro stage and gives Mega Man the Super Adapter early.

How to Patch:
--------------------
1.Grab a copy of Mega Man 7 (USA).sfc (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file