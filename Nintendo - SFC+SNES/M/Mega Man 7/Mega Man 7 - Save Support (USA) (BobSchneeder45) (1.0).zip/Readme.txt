--- MEGA MAN 7 SAVE SUPPORT PATCH, BY BOBSCHNEEDER45 ---

This hack automatically saves your progress in one of three save files. It's also possible to delete a save file on the main menu and passwords are still fully functional. The anti-piracy measures related to SRAM have been disabled to make this hack work.

--- PATCHING ---
A patch exists for each region, just make sure the ROM is unheadered (not an .smc file)!
There is also a version of the patch that is compatible with Mega Man 7 Restoration hack by SCD (https://www.romhacking.net/hacks/3609/). Use this on a ROM that has the Mega Man 7 Restoration patch applied already.

--- THANKS TO ---
Yoshifanatic1 for the disassembly of the game (https://github.com/Yoshifanatic1/Mega-Man-7-Disassembly), which gave a lot of helpful insight needed to make this hack.