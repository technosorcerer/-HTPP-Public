Mega Man 7 (2x Strength)
Jan. 22nd 2025
BillyTime! Games
--------------------
This is a simple patch designed for Mega Man 7 that doubles the amount of damage inflicted on enemies. Comes in two flavors.

2x Strength
--------------------
Players deal double damage from all sources.

3x Strength
--------------------
Players deal triple damage from all sources.

How to Patch:
--------------------
1.Grab a copy of Mega Man 7 (USA).sfc (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file