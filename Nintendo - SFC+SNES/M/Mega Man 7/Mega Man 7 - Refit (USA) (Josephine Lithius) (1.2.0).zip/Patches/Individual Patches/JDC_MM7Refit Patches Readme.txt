Mega Man 7 Refit - The Individual Patches
A collection of Mega Man 7 modifications by DarkSamus993 and Josephine Lithius
--

[1. (INDE) INDEX]

 1. (INDE) Index ------------------------ Do not pass go; do not collect $200!
 2. (INDU) Introduction
 3. (TAPP) The "All-Purpose" Patches
 4. (TSUP) The "Specialized Use" Patches
 5. (CLWO) Closing Words
--

[2. (INDU) Introduction]

  This documentation assumes that you obtained it from the file
  "Individual Patches.zip" contained within the "Patches" directory of a
  "JDC_MM7Refit-vxxx Complete.zip" file and assumes that you, the end user,
  understand what you're getting into.

  If you need more information about the SPECIFICS of a particular patch, check
  the Changelog in the main ZIP file.  It has ALL the spoilers~
  
  Thank you!
  J
--

[3. (TAPP) The "All-Purpose" Patches]

  As far as I'm aware, ALL of these patches can be applied in ANY order to any
  UNHEADERED, Mega Man 7 US (2,048 KB in size), as well as probably most ROM
  hacks that use that as a base.  Some patches MAY NOT WORK on hacks which
  significantly rearrange or shift the contents of the ROM, however.

- MM7Refit-v050_Faster Charge Shot.ips
  The Mega Buster takes a bit less time to charge up.
  WORKS ON: US OR JP ROM

- MM7Refit-v050_Player I-Frames Increase.ips
  Mega Man is invulnerable for a little longer than normal.
  WORKS ON: US ROM ONLY

- MM7Refit-v052_New Damage Data.ips
  Bosses and enemies have their damage data tables tweaked and modified.
  Mostly, this makes the Mega Buster a little more useful in boss battles, but
  some weapons work BETTER or don't work AS WELL against some bosses, too!
  WORKS ON: US ROM ONLY

- MM7Refit-v105_No Charge Spark.ips
  Removes the sparkling effect when Mega Man or Bass charge their weapons.
  WORKS ON: US OR JP ROM

- MM7Refit-v113_Untouchable Rush + Shield Fix.ips
  Rush can no longer be attacked by enemies, just like in the NES games.
  The Protoshield also plays the standard "deflected" noise (like when the
  player hits a shielded enemy) instead of that annoying "BRANG" sound.
  WORKS ON: US ROM ONLY

- MM7Refit-v116a_Stronger Charge Shot.ips
  Increases the power of the charged Mega Buster to be more useful against
  standard enemies.  Surprisingly, this does not break the game's balance.
  A couple other weapon data entries were tweaked, too, but nothing obvious.
  WORKS ON: US ROM ONLY
--

[4. (TSUP) The "Specialized Use" Patches]

  These ROMs are ONLY to be used with a standard, UNALTERED, UNHEADERED
  Mega Man 7 US ROM (again, 2,048 KB in size).  This is because the ROM hack
  was designed around the Mega Man 7 US ROM and pays no mind to the other
  region releases.  That said, USING THESE IN OTHER REGION ROMS IS A BAD IDEA.
 (I wouldn't suggest using these on other US ROM HACKS, either, to be honest.)

- MM7Refit-v120_Text Fixes + Password.ips
  This patch changes various things within the actual script of the game, such
  as clarifying what items do or fixing some minor typos.  Oh, and I changed
  the ending from that ridiculous "DIE WILY" nonsense.
 (Don't worry.  I left "Dr. Willy" alone~)
  This also removes the space between "Pass" and "Word" on the title screen!

- MM7Refit-v120_Graphic Changes.bps
  IMPORTANT: This patch MUST BE APPLIED FIRST, no matter WHAT you're doing.
  Changes the title screen, in-game text font, Energy Capsules and 1ups, and
  a few other little graphics to better reflect the "retro" nature of the mod.
  