Disney's Magical Quest starring Mickey Mouse, conocido en Jap�n como Mickey's Magical Adventure, es un videojuego de plataformas y acci�n de Disney publicado en 1992 para la Super Nintendo. Fue reeditado en 2002 para la Game Boy Advance. Es el primer episodio de la saga Disney's Magical Quest. El juego fue desarrollado y publicado por Capcom.

Necesitan una rom del juego Magical Quest Starring Mickey Mouse, The (USA) sin cabecera.
  NOMBRE: Magical Quest Starring Mickey Mouse, The (USA).smc
  CRC-32: 10874C70
  MD5: 649C377A7479C898B1933962C4BADAAD
  SHA-1: 30E75CF0749A99E88F6C710B44C1B36F0EC0F4A5

LO QUE ESTA HECHO
En general me gusta el resultado, pero quiz� pueda mejorar el resultado en una actualizaci�n.

LO QUE FALTA.-
Editar el grafico "time". Como el juego esta comprimido dependo de Jonny para hacerlo, pero abuse de su amabilidad, pr�cticamente hizo todo el trabajo.


INSTRUCCIONES
Tendr�n que Descargarse un parcheador ips, lo habitual con los parches de SNES.

TRADUCTOR
Blade133bo@gmail.com
Agradecimientos a:
Jonny de RPGone, sin el esto no hubiera sido posible.
Pueden reportar los fallos a "blade133bo@gmail.com"
