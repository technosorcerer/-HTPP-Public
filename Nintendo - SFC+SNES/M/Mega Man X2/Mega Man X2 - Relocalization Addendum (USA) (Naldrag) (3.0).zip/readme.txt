==============================================================================
                     MEGA MAN X2  RELOCALIZATION ADDENDUM
                                 VERSION  3.0
                                BY JAKE NAGARE
==============================================================================

-------
SUMMARY
-------
This hack is an addendum of Thirteen 1335's Mega Man X2 Relocalization, to
keep some consistency with my own relocalization project for Mega Man X. These
changes modify it to allow for three different versions, again the "Maverick
version" the "Irregular version", and the "Rockman version" along with mostly
consistent character text colors.  There have been tweaks to script to make it
more inline with NectarHime's relocalization script, and lines that weren't
modified have been tweaked to allow room for the terms, Irregular and
Repliroid for the "Irregular and Rockman versions" of the patch.

-------
CHANGES
-------
All patches:
 -	Script changes have been made to allow for consistency between the patches.
	Considerably more of NectarHime's retranslation script has also been
	included as a result.
 -	In dialog Dr. Light and Dr. Cain are labeled as "LIGHT" and "CAIN" instead
	of "DR.LIGHT" and "DR.CAIN" for simplicity's sake and to allow for more
	room in the script overall for changes.
 -	Consistent character text colors for the most part. Due to palette
	issues though Agile, Serges, and Violen's dialog are the default blue
	outside of cutscenes.  Otherwise everything else is mostly consistent.
 -	Text on the stage select and cast roll change to all caps.
 -	Implemented Metalwario64's graphics fixes for the Second Armor.

Maverick version:
 - 	Changes Sageese back to Serges and Counter Hunters back to X-Hunters.

Irregular version:
 -	Changes "Maverick" and "Reploid" to "Irregular" and "Repliroid"
	respectively.
 -	Eight bosses JP names restored.

Rockman version:
 -	All changes from Irregular version.
 -	Changes branding to Rockman branding.

----------------
CHANGES FROM 2.1
----------------
 -	Fixed some typoes in the script.
 -  Restored relocalization only patches.

----------------
CHANGES FROM 2.0
----------------
 -	Implemented considerably more script changes based on NectarHime's
	retranslation to make this patch stand out more on its own. Lines that
	couldn't really be changed too well still stick with Thirteen 1335's
	versions though.
 -	Metalwario64/DarkSamus993's title logo is included by default now.
	Reducing the number of patches included from five to three.

----------------
CHANGES FROM 1.2
----------------
 -	Rockman version of patch created.
 -	Eight bosses have their name changed in the Irregular version.
	
----------------
CHANGES FROM 1.1
----------------
 -	Fixed a typo.
 -	Modified Zero's dialog after he reunites with X in the final stage.

----------------
CHANGES FROM 1.0
----------------
 -	Modified a line of dialog during the cutscene where the X-Hunters
	introduces themselves to X and Dr. Cain.

--------------
FILES INCLUDED
--------------
MMX2_Irregular.ips
MMX2_Irregular+Logo.ips
MMX2_Maverick.ips
MMX2_Maverick+Logo.ips
MMX2_Rockman.ips
readme.txt

-------
CREDITS
-------
NectarHime: Changes in this addendum are based on their retranslation.
Thirteen 1355: Original Mega Man X2 Relocalization hack.
Metalwario64: Modified Mega Man X logo sprites. Fixed Second Armor sprites.
DarkSamus993: Implementations of Metalwario64's Mega Man X logo, JP boss name
			  restorations and Rockman X logo implementations.
Arceor Koga: Bug testing.