Mega Man X2 - Xtra Power
Dec. 4th 2023
BillyTime! Games
--------------------
Mega Man X2 - Xtra Power a fun patch designed for Mega Man X2 to provide X with additional perks for collecting all armor upgrades.

How it works:
-----------------------------
Upon collecting all four armor upgrades, X receives the following perks.
*Lvl. 2 X Buster charge replaces green shot lvl.1 X Buster charge (Full charge required for Lvl. 3)
*X receive double health from small health capsules.
*X now has 2x recovery time when taking damage
*Infinite use of non charged special weapons (G.Crush still operates as it did in the original game) 


How to Patch:
--------------------
1.Grab a copy of Mega Man X2 (USA).sfc
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file