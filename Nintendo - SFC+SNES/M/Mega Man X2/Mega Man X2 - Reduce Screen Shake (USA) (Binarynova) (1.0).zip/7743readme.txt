[Name]
"Mega Man X2 [Disable Screen Shake on Wheel Gator Stage].ips"
"Mega Man X2 [Disable Screen Shake When Landing Mech Suit].ips"

[Author]
Binarynova

[Date]
April 24, 2023

[Description]
These hacks disable a few instances of screen shake in Mega Man X2.

[Installation]
Use your favorite IPS patcher to apply this patch to the USA version of the game.
CRC-32: 947B0355
