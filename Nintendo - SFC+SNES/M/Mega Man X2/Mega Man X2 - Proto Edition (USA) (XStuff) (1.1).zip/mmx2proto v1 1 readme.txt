
MegaMan X2: Proto Edition by xstuff 
-----------------------------------

Version 1.1 - 9 23, 2019
Like the previous title, this sequel puts you in control of Protoman from the classic series.

=========
Features:
=========

1.All of X�s graphic tiles have been changed with sprites of Protoman

2.Some new dialogue

3.Protoman has his own weapon get sprite

4.Protoman has his own 1up sprite 

5.Protoman has his own menu icon 

6.Protoman has his own life bar icon  

7.Charge shot palettes are different

8.You can only access 3 upgrade enhancement capsules

9.New weapon colors

10.A smaller life bar

11.Shorter dash length 

12.New title screen

13.Level 1 charge is changed into a level 2 charge shot

14.Level 2 charge is changed into a level 3 charge shot 

15.Level 3 charge is changed into two level 3 charge shots when fully charged with the 
arm upgrade(level 1 when it's not fully charged)

16.Changed the "X" in X.Buster to P.Buster in the menu(However, this changed the "X" in EXIT making it spell EPIT) 
---------------------------------------------------------------------
=================
Planned Features:
=================  

18.Editing the wire frame model of X from the intro cutscene(if that's possible)

=================
KNOWN BUGS:
=================

If you have the arm upgrade, fully charged, and attempted to fire the second charge shot while sliding down a wall,
it'll cancel it if you've pressed the shot button fast. You can still fire the second charge shot, but you have to
wait until the first one is fired first. 

Another known bug with the arm upgrade takes place while silding down a wall. If you fire unfully charged shots while
sliding down a wall, the first and second shots will be level 2 and 3.    

It's nothing major but after you get the helmet upgrade, you'll notice that
the top of Protoman's helmet will shift a little while moving. This is due to the
way that the top part of the upgraded helmet graphics are set up. You'll also
notice part of it when he does his victory pose.
---------------------------------------------------------------------

Instructions:

To patch this, you'll need a copy of this file: Mega Man X 2 (U) [!].smc, and Lunar IPS 
or any other program, but the program I would recommend you use is flips to patch this with.

And make sure it's unheadered.
