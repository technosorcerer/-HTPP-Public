Metal Warriors Infinite Continues Romhack
Author: Omnigamer
Publish Date: 05/17/2023

Details:
This hack is a very simple modification of Metal Warriors that prevents the Continues counter from decrementing. The only change was NOP'ing the DEC instruction that occurs when a player elects to continue following a death. This accomplishes similar functionality to the existing SRAM save hack, however is more appropriate for live play competitions, such as the upcoming Super 16 speedrunning event.

This hack is as barebones as it gets - I don't expect to revisit it to add a more appropriate graphic for the Continue screen, or any other graphical edits. An additional modification for Stage Select may be an attractive QoL bonus later, but I have no realistic plans of when/if I would build it.