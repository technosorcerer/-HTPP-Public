Samus Status Screen Hack v1.1
Made by MistSonata

This is a minor hack for Infidelity's Metroid SNES port that replaces the enlarged sprites on the status screen with custom pixel art of Samus, both suited and suitless. It also modifies the text at the top of the map screen in order to better fit the font on the status screen.

This was made for the Rev-E version of the rom, and hasn't been tested with any of the other patches included with the release.

12-20-2023 - Moved the palette data to another bank, as it was causing garbage graphics to show up above the menu screen.