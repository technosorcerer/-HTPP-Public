Mega Man VI SNES - Mega Jet Suit
Sept. 21st 2025
BillyTime! Games
--------------------
This is a cheat patch designed for Infidelity's port of Mega Man VI to the Super Nintendo which grants immediate access to the jet suit with Infinite Fuel.

Note:
--------------------
*Passwords will still work, however Plantman will always remain defeated

How to Patch:
--------------------
1.Grab a copy of Mega Man VI SNES.sfc (Infidelity)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file