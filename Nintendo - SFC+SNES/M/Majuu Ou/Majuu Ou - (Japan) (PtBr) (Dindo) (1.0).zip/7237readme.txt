================================================================================
                             Majuu Ou - Demônio Rei
                                -PT-BR- v1.00
                                Dindo, badnest
                                  29-02-2024
================================================================================
0 - ÍNDICE
-------------------------------------------------- -------------------------

1 - Introdução
2 - Como aplicar o patch
3 - Progresso
4 - Equipe
--------------------------------------------------------
1 - Introdução
--------------------------------------------------------

Majyūō é um jogo de plataforma japonês de 1995 publicado pela KSS para o Super Famicom. 
A história é a de um homem chamado Abel que deve resgatar sua esposa e filha do inferno.
É um jogo de rolagem lateral 2D e permite ao jogador se transformar em vários demônios.

Lançamento 
O jogo foi lançado no Japão em 25 de agosto de 1995 para o Super Famicom e publicado pela KSS.
O jogo teve um alto valor de revenda.
Um guia de 2016 listou-o como vendido por 30.000 ienes apenas com o cartucho e 100.000 ienes com o cartucho e a caixa.
Em 2018, as lojas que revendiam cópias do jogo original poderiam vender o jogo por preços de 58.300 a 69.800 ienes.

O jogo recebeu um relançamento limitado em formato de mídia física em 24 de maio de 2018
pela Softgarage via Columbus Circle. Foi vendido por 5.580 ienes.


-------------------------------------------------- -------------------------
2 - COMO APLICAR O PATCH
-------------------------------------------------- -------------------------

***IMPORTANTE***

O patch deve ser aplicado sobre a versão japonesa do jogo.
A seguir, encontre o CRC da ROM para aplicar este patch:

Majuu Ou (J).SMC: 4737370b

Antes de aplicar o patch, certifique-se de fazer um backup da memória original.

***INSTRUÇÕES***

- Abra o programa flips, clique em "Apply IPS Patch"

- Selecione o "Majuu Ou - Demônio Rei (BR) (2023) v1.00.bps" e clique em "Abrir"

- Na tela seguinte, selecione a ROM "Majuu Ou (J).SMC"

- Clique em abrir e pronto! Seu jogo estará traduzido ;)


-------------------------------------------------- -------------------------
3 - PROGRESSO
-------------------------------------------------- -------------------------
Versão 1.00 (01/03/2024)

-------------------------------------------------- -------------------------
4 - EQUIPE
-------------------------------------------------- -------------------------
Dindo: Tradução, Revisão, Romhacking.
badnest: Romhacking, Tile map, Gráficos e Logo.
