Metal Morph (Super Nintendo)
Traducción al Español v1.0 (16/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Metal Morph (USA).sfc
MD5: c935c0d7aafb53d86bc519a756695e6f
SHA1: 51c3723214012451280b22cf3cc81b903f0f6bf4
CRC32: 0adaa9da
1572864 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --