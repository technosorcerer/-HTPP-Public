Metal Slader Glory: Director's Cut (SNES)
Debug Mode Enabled: Version 1.0

By: FCAndChill
February 9, 2019

This patch enables the debug mode in Metal Slader Glory. It's a one byte patch ... it changes the byte at 0x140423 (PC address) from #$3F to #$50. The programmer changed this address to #$3F to dummy out the debug screen... In the final game, the debug password leads you to chapter 2.

I initially made an ASM patch two days before, but it didn't display the debug message. I'm pleased I figured out how to display the message with a clean solution.

To get to the debug screen, apply the IPs patch like it's still 2008 and enter in the following password in the password screen (just like the NES version)... 

でばっぐ やろう★

It was likely disabled in this version because the debug screens is far more advanced (there's a surpirsing amount of dialogue entries for it too). Aside from having the scene selection from the NES version, it has a sound test, scene selection, CHR bank test, and more... From the scene selection, you can see quite a bit of unused scenes. There's an unused credit sequence, two Elina shower scenes, a copyright screen from the NES version, and a bird's eye view of the T-Stork. There's also a bug with one of the scene selection names because it's too long...

You can use this patch in your translation as long as you give credit. While it is a one byte patch, I did put hours of work into making it. Metal Slader Glory DX has been my first exposure to assembly. This marks my fourth hack for the game: the first was a hack to remove the line indentation; the second to load English characters into the password screen; and the third to make the password options work correctly with English text.
