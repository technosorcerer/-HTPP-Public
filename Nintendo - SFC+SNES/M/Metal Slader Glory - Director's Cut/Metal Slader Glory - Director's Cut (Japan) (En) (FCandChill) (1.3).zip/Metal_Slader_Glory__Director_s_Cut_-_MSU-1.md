[//]: <> (This readme is in the markdown format. Please preview in a markdown parser.)

# Metal Slader Glory SFC: MSU-1

Source code: [https://github.com/romh-acking/metal-slader-glory-sfc-msu-1](https://github.com/romh-acking/metal-slader-glory-sfc-msu-1)

This patch is not for rehosting on Romhacking.net.

## About
This is MSU-1 music hack for Metal Slader Glory for the Super Famicom.

When discussing translating the Super Famicom version after finishing up translating the Famicom version, Her-saki expressed interest working on it only if there was an MSU-1 patch to listen to the NES music. And so, here we are.

You won't find a link for a PCM pack here. Search on archive.org for it.

```
msg_msu1-10.pcm   msg_msu1-20.pcm   msg_msu1-2.pcm   msg_msu1-47.pcm
msg_msu1-11.pcm   msg_msu1-21.pcm   msg_msu1-30.pcm  msg_msu1-48.pcm
msg_msu1-123.pcm  msg_msu1-22.pcm   msg_msu1-33.pcm  msg_msu1-49.pcm
msg_msu1-12.pcm   msg_msu1-23.pcm   msg_msu1-36.pcm  msg_msu1-50.pcm
msg_msu1-13.pcm   msg_msu1-249.pcm  msg_msu1-37.pcm  msg_msu1-52.pcm
msg_msu1-14.pcm   msg_msu1-24.pcm   msg_msu1-40.pcm  msg_msu1-55.pcm
msg_msu1-16.pcm   msg_msu1-251.pcm  msg_msu1-41.pcm  msg_msu1-5.pcm
msg_msu1-17.pcm   msg_msu1-25.pcm   msg_msu1-42.pcm  msg_msu1-6.pcm
msg_msu1-18.pcm   msg_msu1-27.pcm   msg_msu1-44.pcm  msg_msu1-8.pcm
msg_msu1-19.pcm   msg_msu1-28.pcm   msg_msu1-46.pcm  msg_msu1-9.pcm
```

The Famicom and Super Famicom song ids don't match quite right, so some changes were made so the music cues matches the Famicom release.

## Known Issues
Known issues that show how much I care:
* I didn't create an ASM hack to support fade-ins and fade-outs.
* There may be issues in the sound test.

## Patching Instructions
The patch is an IPS. Either use the IPS patcher or patch your rom here:

[https://romhack.ing/tools/patcher/](https://romhack.ing/tools/patcher/)

## Changelog
* 1.3:
	* Okay, now the patch is actually compatible with the FXPAK Pro now.
* 1.2:
	* Patch is now compatible with FXPAK Pro
		* Special thanks to mziab for the fix!
	* Non-MSU track play fix in Chapter 5
* 1.1:
	* Now compatible with the translation patch
* 1.0:
	* Initial release

## Credits
* FCandChill:
	* Hacking
* mziab:
	* Helped with bug fix
* NewerDCD:
	* Bug report
	* Real hardware testing
