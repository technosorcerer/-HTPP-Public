[//]: <> (This readme is in the markdown format. Please preview in a markdown parser.)

# Metal Slader Glory SFC: English Version 1.0

Source code: [https://github.com/romh-acking/metal-slader-glory-sfc-en](https://github.com/romh-acking/metal-slader-glory-sfc-en)

## About
### The game
This is a translation patch for Metal Slader Glory: Director's Cut on the Super Famicom. If you're going to play the game for the first time, make sure to read the manual from the Famicom version beforehand because it covers events preceeding the game. Yup, this version didn't include a manual. Oops!

This game is actually the last officially released Super Famicom game. It was released in 2000, which is late for not only the Famicom's life but the Nintendo 64's too. It was distributed through Nintendo Power flash cartridges, a much cheaper and conservative way to distribute the game.

It's easy to write this version off a simple port with improved graphics. The name isn't just for show, it contains content cut from the original release. Reverse engineering the Famicom version, there's evidence suggesting it supports a much larger catridge size, suggesting the game was trimmed down to fix on a smaller catridge for distribution, even then, it's the biggest officially released NES game. There's scenes, most notably in chapter 5, that have unused graphics in the NES version, that are used in this version. There's also dialogue scenarios that appear in the SNES that don't in the NES version.

Just like in the NES version, there's a password that grants access to the debug menu, "Let's debug*", except that it's disabled in this version! If you want to re-enable it, please use this patch:

[https://romhack.ing/database/content/entry/ftNu5JQBNs8FWu0CjGea](https://romhack.ing/database/content/entry/ftNu5JQBNs8FWu0CjGea)

Upon accessing it, it's easy to see why it was disabled: it's extremely extensive. Have fun messing around in it!

### This project
This project was a major rom hacking learning experience and dates as far back as 2018. Due to impatience of waiting for a translation of this game, I decided to tackle it myself. This project is where I developed my own script inserter tool that I still use to this day, learned how to read assembly code, and learned how to write assembly code. The project constantly changed throughout the years. What started with me hand compiling assembly code eventually turned into a one-click compile process.

After reaching out to Her-saki to serve as a translator, it was decided to work on the NES version instead. The SNES and NES have very similar architecture, so learning to work on the NES was easy. Additionally, the SNES version's code was ported from the NES version and have very similar code structure, so patches and the script dumper / writer were easily adapted to this version.

After the NES translation project completed, work was once again transferred to this version, which included the script and improved patch work. And once the SNES translation project was completed, script improvements and patch improvements were then back-ported to the NES translation. Needless to say, there was a lot of handoffs between the two translation projects over the years.

The script received changes when converted from the NES to SNES. Whether that was minor formatting changes, added control codes, control code differences that are functionally the same, lines being split apart for no reason, new lines, etc. As you could imagine, porting the NES script to the SNES game was tedious. I created a script that automatted matching similar lines and correcting the control codes. The final result is two translations that have very similar scripts, making it easy to spot the differences and where things got axed from the NES version.

Anyway, my life, and even the world, is much different when this project finished compared to when it started. It's bittersweet to see it end, but at least now, everyone can enjoy it.

## Translation Notes
You can see the original translation's readme for changes, but one change notable to this project is the palettes. The game has a NES palette table that's referenced for 2BPP graphics. This is used for graphics in this port that weren't touched up to be 4BPP. The palette is also used for the font and since the translation projects added text shadows, palettes that were previously unused, get used, and they are very hideous choices in the original. They (as well as some used palette indexes) were touched up to be less apalling and better match a standard NES palette. This is why the grey palette used in the debug menu for the CHR viewer looks different in the fan translation.

## Patching Instructions
The patch is a Beat patch. Either use a Beat patcher or patch your rom here:

[https://romhack.ing/tools/patcher/](https://romhack.ing/tools/patcher/)

## Changelog
* 2025 September 1st, 1.1
    *  One of the passwords incorrectly displayed as "Let's go to Colony 35" instead of "Let's go back to Colony 35".
    * Thanks to @solrocknroll for spotting this.
* 2025 March 10th, 1.0
    * Initial release

## Suport the creator
Apparently, a prequel to this game was intended to be released on the 64DD but was cancelled. If you want the series to continue, consider showing your appreciation for it to the game's creator, Yoshimiru. You can do this by buying some Metal Slader Glory merch from his store and giving him a follow on Twitter:

Store: [https://mc-berrys.booth.pm/](https://mc-berrys.booth.pm/)

Twitter: [https://twitter.com/yoshimiru_SS/](https://twitter.com/yoshimiru_SS/)

He sells books detailing the games' development, including the 64DD prequel. You can't find scans of these books anywhere online.

## Credits

### Main Team
See the Famicom version for the credits, as the credits there apply here too.

* FCandChill
    * Initial ASM work
    * Utilities
    * Localizer
    * Proofreader
    * Manual
* Her-saki
    * Advanced ASM work
    * Font
    * Initial translation
    * SNES translation
* TheMajinkZenki
    * SNES translation

### Beta Testers
* dogbrainludus (Ludus)
