- Fixed Raiden's name at the end of rounds (it was Rayden)
- "Goro's Lair" screen available (only for 1 player mode)
- CPU will always apply fatality when winning
 Infinite time for player 1 or player 2 after FINISH HIM/HER
- Infinite credits against the CPU
- Raiden's Shock-Grab now also works against the CPU (previously it was not possible)
- Johnny Cage's original colors
- Jade, Noob Saibot and Smoke can be controlled (only for player 1)

Play as Jade:
down, down, down, down + select

Play as Smoke:
forward, forward, forward, forward + select

Play as Noob:
back, back, back, back + select

- One Button Fatalities are finally RELEASED for all available fighters. 

** Command list below **

Baraka
High Punch for fatality 1
Low Punch for fatality 2

Jax
Hold Low Punch for 2 seconds for fatality 1
Low Punch for fatality 2

Johnny Cage
Low Punch for fatality 1
Press "Up" for fatality 2

Kitana
High Kick for fatality 1
Hold Low Kick for 2 seconds for fatality 2

Kung Lao
Low Kick for fatality 1
Hold Low Punch for 2 seconds for fatality 2

Jade
High Kick for fatality 1
Hold Low Kick for 2 seconds for fatality 2

Liu Kang
High Kick for fatality 1
Press "Down" for fatality 2 (close to opponent)

Mileena
Low Punch for fatality 1
Hold High Kick for 2 seconds for fatality 2

Noob Saibot
High Kick to freeze then High Punch for fatality 1
Hold Low Punch for 2 seconds for fatality 2

Rayden
Hold Low Kick for 2 seconds for fatality 1
High Punch for fatality 2

Reptile
Low Punch for fatality 1
High Kick for fatality 2

Scorpion
High Punch for fatality 1
Hold High Punch for 2 seconds for fatality 2

Shang Tsung
Low Kick for fatality 1
Hold High Kick for 2 seconds for fatality 2
Low Punch for Fatality 3

Smoke
High Punch for fatality 1
Hold High Punch for 2 seconds for fatality 2

Sub-Zero
High Kick to freeze then High Punch High Punch for fatality 1
Hold Low Punch for 2 seconds for fatality 2


Credits romhackers:
nolberto82
Abystus
MottZilla