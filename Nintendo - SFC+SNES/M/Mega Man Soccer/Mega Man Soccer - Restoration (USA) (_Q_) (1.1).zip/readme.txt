==================================================================================
============                    Mega Man/Rockman's                    ============
============                  Soccer Restoration v1.1                 ============
============                                                          ============
============                       Compiled by Q                      ============
============                                                          ============
==================================================================================

View my ROMhacking.net profile here: http://www.romhacking.net/community/5090/


=== The Patch ===

Two versions of this patch are included � one for Mega Man Soccer (the U.S. version)
and one for Rockman's Soccer (the Japanese version).

Both patches do the same three things:

* Restore the endings to the Capcom Championship and Tournament Mode

* Allow you to play as Dr. Wily in Exhibition

* Allow you to set the Time and S.Shoot (Special Shots) up to 99 in the Options menu
  (in the original release of the game, Time was capped at 10 minutes and Special
  Shots were capped at 9)


=== Applying the Patch === 

Apply the appropriate patch to a headerless Mega Man Soccer of Rockman's Soccer ROM using
an IPS patching tool like Lunar IPS. You can download Lunar IPS at either of these URLs:

* https://www.romhacking.net/utilities/240/

* https://fusoya.eludevisibility.org/lips/

If you applied the patch correctly, the ROM should have a different checksum than the
unmodified ROM but will still pass a checksum test. You can check this by booting up
the ROM in the Snes9x emulator.


=== Playing as Dr. Wily ===

There's a small quirk to the way you select Dr. Wily in Exhibition. Wily is located
at the bottom right of the character select menu. You can only see the left edge of
his portrait. To select him, move your cursor to Airman, move it right to the blank
spot above Wily's portrait, then move it down to highlight Wily. If you attempt to
move your cursor to Wily from Gemini Man (i.e. from left to right), it will not work.

If you pick the blank space above Wily's portrait as your character, the game will
select Iceman.


=== Credits ===

While I compiled this patch, I didn't create any of the hacks:

* I restored the endings by patching in Pro Action Replay codes that were attributed
  to KungFuFurby by The Cutting Room Floor.
  More info here: https://tcrf.net/Mega_Man%27s_Soccer#Unused_Endings

* I restored Dr. Wily using a Game Genie code I found on cheatzilla.com. The code was
  submitted by ventureman, although I'm not sure who originally discovered it.

* The ability to set the Time and Special Shots up to 99 was added by antiheroforhire.
  It was previously released as a separate patch, but he gave me permission to include
  it in this hack.


=== Change Log ===

v1.0 - 01-22-2019

   Original release.

v1.1 - 11-10-2024

   Removed changes that were not intended, including a stat change for Mega Man.
   These changes were part of antiheroforhire's patch. Now, only the ability to
   increase the S.Shoots and Time setting to 99 are included from that patch.
