This enables FASTROM on Megaman X3 by setting bit $420D to 1 on startup and changing all banks to start at $80 instead of $00.

Disassembled with Diztinguish, reassembled with ASAR.

Big thanks to Helder for 100% running this for the decomp!

-kandowontu
twitter.com/kandowontu
patreon.com/kandowontu
discord.gg/U4CtzqDGa5