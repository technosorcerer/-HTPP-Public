
MegaMan X3: Proto Edition by xstuff 
-----------------------------------

Version 1.1 - September 25, 2019
Like the previous two, this sequel puts you in control of Protoman from the 
classic series once again.

=========
Features:
=========

1.All of X�s graphic tiles have been changed with sprites of Protoman

2.New dialogue

3.Protoman has his own weapon get sprite

4.Protoman has his own 1up sprite 

5.Protoman has his own menu icon 

6.Protoman has his own life bar icon  

7.Charge shot palettes are different

8.You can only access 3 upgrade enhancement capsules like the first title
(You can also access the red/pink capsules)

9.New weapon colors

10.Protoman has his own intro cutscene sprite 

11.Protoman has his own menu protrait

12.Protoman has his own stage select icon

13.New title screen

14.Changed X.Buster to P.Buster in the weapons menu
(This changed the spelling of the word "EXIT" making it spell "EPIT")

15.Smaller life bar

16.Shorter dash length

17.Level 1 charge is changed into a level 2 charge shot

18.Level 2 charge is changed into a level 3 charge shot(the orange/green/white double helix one)
(you can't fire any other shots until the fired charged shot is off screen)  

19.You can fire two level 2 charged shots when the upgraded buster is charged to level 3(the purple color charge)
---------------------------------------------------------------------
=================
Planned Features:
=================

.Figuring out how to fix the spelling error of the word "EXIT"

.Arrange the dialogue some more 
---------------------------------------------------------------------

Instructions:

To patch this, you'll need a copy of this file: Mega Man X 3 (U) [!].smc, and Lunar IPS 
or any other program, but the program I would recommend you use is flips to patch this with.

And make sure it's unheadered.


