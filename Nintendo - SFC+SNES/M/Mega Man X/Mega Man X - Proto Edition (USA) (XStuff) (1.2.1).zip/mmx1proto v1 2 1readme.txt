
MegaMan X1: Proto Edition by xstuff 
-----------------------------------

Version 1.2.1 - November 19, 2019
Originally know as ProtoMan 21XX, this hack enables you to play as Protoman from the classic series.

Note: Originaly, v1.2 was gonna be the final version of this hack, but after some criticism
over the lack of Protoman's scarf and shield, I decided to edit this one last time, and add those
traits in to the best of my abilities.

=================================
A recap of the previous features:
=================================

1.Buster shots are now normal buster shots 

2.Level 1 charge is changed into level 2 charge shots 

3.Level 2 charge is changed into level 3 charge shots 

4.Level 3 charge is changed into the charged rolling shield weapon

5.A small life bar

6.Some new dialogue (updated)

7.New weapon colors

8.All of X�s graphic tiles have been changed with updated sprites of Protoman. 
(some of them are edited)

9.Protoman has his own weapon get sprite (updated)

10.Protoman has his own 1up sprite 

11.Protoman has his own life bar icon  

12.Protoman has his own mugshot

13.Protoman shows up in the ending  

14.Charge shot palettes are different

15.Dash length is short

16.Changed X.Buster to P.Buster

17.New title screen

18.Protoman's name appears on the stage select screen

19.You can no longer charge special weapons with the buster
upgrade

=============
New Features:
=============

20.You can now access 4 upgrade enhancement capsules(like the original)

21.Protoman's sprites have been updated to make his scarf more noticable while standing,
running, jumping etc.

22.Protoman's shield has been added in, and acts as the armor upgrade in this hack which also means that
you can now access the capsule in Sting Chemeleon's stage to get it. However, the upgrade doesn't reduce 
the damage you take, but rather pushes you back less instead when you take damage. Also, the shield's visible 
while standing, running(appears in only two frames which shows Protoman's back), climbing ladders, and riding 
in the armor carriers. 

=================
Additional notes:
=================

. You can no longer get the buster upgrade from Zero, but you'll
still perform the charging animation(This even happens when you
already have the upgrade as well)

. If you entered a password to continue from where you left off,
the game would load the original length of the life bar(This has 
been fixed)

. The subtanks appear red in the menu(this was done so they would
match the color of the subtanks that are hidden in some of the stages) 

. A small graphical error will appear on Protoman's full body shot on the got weapon screen
if you have the armor/shield upgrade

---------------------------------------------------------------------

Instructions:

To patch this, you'll need a copy of this file: Mega Man X (U) (V1.1).smc, and Lunar IPS
or flips. Whichever one.

And make sure it has a header on it.
