******************************************************************************
Mega Man X1 - Air Dash/Wall Jump					     *
Created By: Justin3009 (xJustin3009x/Shishisenkou)			     *
******************************************************************************
Released:  3/3/2019
Bug Fixed: 3/28/2019
------------------------------------------------------------------------------
There are two versions of each patch! One is for a headered ROM and one is for an unheadered one! DO NOT MIX THE TWO TYPES TOGETHER!



Patch #1: Air Dash (NOTE: This patch includes the Wall Jump patch already!)
-------------------------------
This patch allows X to start with his dash. Once he obtains the leg part, he will be able to Air Dash like Mega Man X2/X3!



Patch #2: Wall Jump
-------------------------------
This patch allows the player to hold the 'A' button when they have the dash upgrade to do a more powerful wall jump like all future X games!
You no longer have to press the 'A' button and the 'B' button at the same time. (No more finger cramps!)