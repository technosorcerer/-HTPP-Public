
Mega Man X1: Proto Edition by xstuff 
------------------------------------

Note: 
The following is only a fan made hack, meant to give fans closure or an idea of what happened,
or could happen to their favorite characters from the Mega Man Classic series within the 21XX era.
It's in no way meant to rewitre, tarnish, or ruin the Mega Man X series, or the character X as a whole.
It's all just fun and fan fiction.  

About:
Other than being just a character replacement hack with some altered gameplay features, this mod tells
an alternate story, one that answers the question: What if Protoman had his energy core repaired?

Version 1.2.2 - 8/2/2025
Originally know as ProtoMan 21XX, this hack enables you to play as Protoman from the classic series.

With v1.2 originally being the last version that would release, following v1.2.1 as a small update,
and with some more motivation and a bit of ideas brewing, I went to work on editing Proto Edition again.
And using what knowledge I gathered through editing and coloring some graphics, along with text editing,
I think this might be the best version yet. 

So now to list the features, both new(er) and returning:

The returning features are:
. Altered title screen, showing the hack's name and title in red
. Level 1 charge shot is now a level 2 charge shot
. Level 2 charge shot is now a level 3 charge shot
. Level 3 charge is changed into the charged Rolling Shield weapon
. Smaller life bar
. Altered weapon colors
. No longer being able to charge special weapons with the buster upgrade
. The 4th capsule upgrade can be collected again (A.K.A the body armor upgrade)
  (check one of the newer features for more information)
. A password will load the correct height of the modified life bar
. The buster upgrade can no longer be obtained from Zero, but the charging animation will still be performed,
  even if it was collected from one of Dr.Light's capsules
. Protoman having his own life bar icon 
. Protoman having his own 1up sprite
. Protoman having his own mugshot
. Protoman having a shorter dash length
. Protoman having the name of his default weapon appear on the menu screen as "P.Buster"
. Protoman having his name appear on the stage select screen, before all 8 bosses are defeated
. Protoman appearing in the ending 

Newer features:
. Buster shots now do the same damage as Level 1 charge shots, their graphics even look different

. All of Protoman's sprites both gameplay (and on the weapon get screen) were edited once again to 
  fully add in his signature shield, with it covering the scarf in some animations but the scarf is there

. Dialogue has been edited again, removing some empty spaces that were there originally, along with refining 
  some spelling errors

. Text font color changes depending on which characters are speaking: Orange - Protoman and Zero,
  Cyan - Dr.Light, Purple - Vile, and Green - Sigma

. Protoman has a new reduced damage animation where he'll guard using his shield, reducing damage in the process
  (originally he was going to have it over him or from behind as the armor upgrade, much like X's body armor 
   but instead was incorparated into his sprites)

. Charge shot colors are different this time around in reference to levels of heat in which fire can change
  colors depending on how hot it can become 
  (Examples: buster shot = red, LV2 charge shot = yellow/orange, LV3 charge shot = blue)

. Charge shot palettes no longer appear discolored if fired after or if a charged Rolling Shield was used 

. The colors of the particle effects while charging the buster weapon are different, matching the new 
  charge shot colors: LV1 = yellow = LV2 charge shot, LV2 = blue = LV3 charge shot, and 
  LV3 = dark blue = charged Rolling Shield

. The graphical error that appeared on Protoman's full body appearance on the got weapon screen is fixed

. Protoman has a new idle stance, based on his appearance in Mega Man 7 

. Protoman has a new victory pose that's based on his appearance in Mega Man the Power Battle and Power Fighters

. Protoman has a new buster firing animation on his appearance in Mega Man 7 

. Protoman's life bar icon now uses shades of red that were already available within the palette
  (This also means that weapon energy pick ups will no longer be red and can use blue colors again) 

. The icon for the P.Buster is altered to reflect the new look of the regular buster shots in game
 
. The color of the menu screen is different, based on Mega Man 7's

. Subtanks no longer appear red in the menu(originally this was done so they would match the color of the subtanks 
  that were hidden in some of the stages since they shared the same palette as the life bar icon) 

. Special weapons will do +1 damage to normal enemies while bosses take +1 damage to weapons they're weak against, 
  except for Sigma who'll remain as top tier
   
. Special weapons will deplete faster upon usage to balance the power increase

. Charge shots can do a little more damage to Sigma in his first form, with the 3rd level charge shot 
  doing the same amount of damage as a charged Electric Spark

. Sigma's final form is damageable; the P.Buster can do 1 unit of damage while charge shots can do 2;
  the Rolling Shield can still be used


---------------------------------------------------------------------
Instructions:

To patch this, you'll need a copy of this file: "Mega Man X (U) (V1.1).smc", and "Lunar IPS"
or "Flips" to patch it. Also header will need to be added on before patching. The required copy
should have one added by default. If not, then Programs such as "SNEStuff", "SNES Rom Utility", 
or "Advanced SNES Rom Utility" can be used to add a header to the game file.  

Info:
Mega Man X (U) (V1.1).smc	
MD5
a7f3381ff6b5d71076caff5a7a91b6fc	

SHA1 
cd93879151434c91f910ce3587a91fb09b0ca20e	

CRC32 
d290a994	

SHA-256 
798a12d8ad1e876ae9c4cc893b66f45008a8dab7cdd0566c422bf60752c9ac1c	

SHA-512 
f6d3f85978201e14727ae10c6401c6a7f25734b4f461f1d310adc47e6509cb89cd787abe58936a0bb6c0c3fe2e93a38e1cb905623dbfe24fc76a6da0af573c36	

SHA-384 
32816fdd639e892ed5b9e721c4fc04cd7516bbf934c3ab672e03c73d694b48af9c33958d6e3d3ea2f88201e5d0272dae
---------------------------------------------------------------------
Credits:
SwiftlyTony360 - Charge shot palettes idea in reference to levels of heat and menu color change
PowerPanda - Boss Weapon Damage Disassembly documentation
DarkSamus993 - Documentations on weapon damage values and capsule upgrades
rainponcho - Additonal documentation on weapon damage values
 

