
MegaMan X1: No armor GFX by xstuff 
-----------------------------------

Version 1.0 - Originally created on April 30, 2015

Description:

Have you ever wanted to play as X without any armor enhancements, but still have the abilities
of them? Well, it's now possible with this patch. This patch removes all of X's armor graphics
and includes some new ones for the hadouken and reduced damage animations along with the
ending cutscene as well. 

Instructions:

To patch this, you'll need a copy of this file: Mega Man X (U) (V1.1).smc, and Lunar IPS
or any other program, but I recommend Lunar IPS to patch it with.

And make sure it has a header on it.
