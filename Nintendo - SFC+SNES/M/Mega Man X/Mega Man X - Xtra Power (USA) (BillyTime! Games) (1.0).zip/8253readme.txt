Mega Man X - Xtra Power
Nov. 27th 2023
BillyTime! Games
--------------------
Mega Man X - Xtra Power a fun patch designed for Mega Man X to provide X with additional perks for collecting all armor upgrades.

How it works:
-----------------------------
Upon collecting all four armor upgrades, X recieves the following perks.
*Lvl. 2 X Buster charge replaces green shot lvl.1 X Buster charge (Full charge required for Lvl. 3)
*X recieve double health from small health capsules.
*X now has 2x recovery time when taking damage
*Infinite use of non charged special weapons 


How to Patch:
--------------------
1.Grab a copy of Mega Man X (USA).sfc or Mega Man X (USA) (Rev 1).sfc
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file