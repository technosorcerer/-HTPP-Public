
Mega Man X2: Proto Edition by xstuff 
------------------------------------

Like the previous title, this sequel puts you in control of Protoman from the classic series.

Version 1.2 - 8/11/2025
With the first title being updated to combat some of the criticism over the lack of 
Protoman's scarf and shield, I went on ahead to apply the same changes to this title.

With that out of the way, I'll be recapping the previous features. Then the newer ones.

===================
Returning Features:
===================

. Altered title screen, showing the hack's name and title in red
. Level 1 charge shot is now a level 2 charge shot
. Level 2 charge shot is now a level 3 charge shot
. Level 3 charge is changed into two level 3 charge shots when fully charged with the 
  arm upgrade(level 1 shots when it's not fully charged)
. Smaller life bar
. Altered weapon colors
. A password will load the correct height of the modified life bar
. Protoman having his own life bar icon 
. Protoman having his own 1up sprite
. Protoman having a shorter dash length
. Protoman having his own icon on the stage select screen


---------------------------------------------------------------------
=================
Newer Features:
=================  

. Buster shots now do the same damage as Level 1 charge shots to some enemies and bosses
  (They'll also appear red to reflect their strength)

. Level 1 charge shots, when fired from the upgraded P.Buster if not charged fully, are reflected from all 
  enemies and bosses (This is set up to reflect the arm upgrade's imperfections, much like the shorten
  dash length)
 
. All of Protoman's sprites both gameplay (and on the weapon get screen) were edited once again to 
  fully add in his signature shield, with it covering the scarf in some animations but the scarf is there

. Dialogue has been edited again, removing some empty spaces that were there originally, along with refining 
  some spelling errors and also adding some hints on who Serges actually is, even knowing Protoman and his 
  creator, along with Sigma giving out some clues too (some of this is based on the Japanese script of X2)

. The "S-Avengers," The X-Hunters' alternate name for this hack are now called the Counter Hunters
  like in the Japanese dialouge  

. Text font color changes depending on which characters are speaking during cut scenes: Orange - Protoman, Violen;
  Cyan - Dr.Cain; Purple - Agile and Serges
  (During gameplay, however, Serges, Violen, and Agile's text speeches will always use cyan as the color for their 
  dialouge, before or after they're fought. In later gameplay Protoman and Zero will use an orange color for their
  text font while Sigma uses sea green for his)

. The sprite for Protoman's life bar icon is recolored using shades of red from the explosion graphics

. Subtanks and weapon energy collectibles appear blue again (they originally were red after changing the
  life bar icons palette)

. Subtanks no longer appear red in the menu (originally they appeared as such to match the collected subtanks 
  that appear in some stages

. Boss explosion palette is red (the reason for this change was so that the recolored life bar icon wouldn't turn 
  blue during the boss' defeat; during the boss explosion phase, the game will load a palette that's parallel to
  the one used for regular explosions, life and weapon energies, buster projectile, and life bar icons; since the
  life bar icon is recolored using colors from the regular explosion palettes, they would appear blue during
  the phase where a boss is defeated but that's fixed by changing the explosions to red like the first title)

. The 4th capsule can be accessed again in Morph Moth's stage; like in the previous title, the shield will
  act as the body armor upgrade, reducing damage by a quarter

. Protoman has a new reduced damage animation where he'll guard using his shield, reducing damage in the process

. The Giga Crush attack can instantly take out a boss, much like the Hadouken fireball easter egg in X1;
  however, some bosses like Zero or 2nd form Sigma won't take instant damage from it
 
. Charge shot colors are different as a reference to levels of heat in which fire can change
  colors depending on how hot it can become 
  (Examples: buster/LV1 charge shot = red, LV2 charge shot = yellow/orange, LV3 charge shot = blue/violet)

. The colors of the particle effects while charging the buster weapon are different to match the new 
  charge shot colors: LV1 = yellow(LV2 charge shot), LV2 = blue(LV3 charge shot), and 
  LV3 = purple(LV3 charge shot, LV1 if not fully charged)

. Special weapons will do +1 damage to all enemies while bosses take +1 damage to weapons they're weak against
  (They will also do +2 damage when charged)

. Special weapons will deplete faster upon usage to balance the power increase, and deplete more faster when
  charged fully, minus the charged Bubble Splash

. Zero(if fought) and Sigma's final form will be vulnerable to regular buster shots

. The icon for the P.Buster is altered to reflect the new look of the regular buster shots in game

. The "P" in "P.Buster" no longer affects the spelling of the word "EXIT"

. Protoman has a new idle stance, based on his appearance in Mega Man 7 

. Protoman has a newer victory pose where he'll hold his shield up, a nod to Mega Man 7 in which Megaman picks it up

. Protoman has a new buster firing animation that's based on his appearance in Mega Man 7 

. The color of the menu screen is different in reference to Mega Man 7's

. The wire frame model of X from the intro cutscene is red to reflect Protoman as being the main character of this title
 

=================
KNOWN BUGS:
=================

If you have the arm upgrade, fully charged, and attempted to fire the second charge shot while sliding down a wall,
it'll cancel it if you've pressed the shot button fast. You can still fire the second charge shot, but you have to
wait until the first one is fired first. 

Another known bug with the arm upgrade takes place while silding down a wall. If you fire unfully charged shots while
sliding down a wall, the first and second shots will be level 2 and 3.    


---------------------------------------------------------------------
Instructions:

To patch this, you'll need a "unheadered" copy of this file: "Mega Man X 2 (U) [!].smc", and "Lunar IPS" 
or "Flips." Personally I would recommend "Flips" since you can save a newly patched file without
overwriting the original.

If you're unsure if your copy is unheadered or not, then you can open it in a hex editor such as "HxD."
If you see all numbers at the top, then the rom file is unheadered. However, if you see all zero's at the
top, which adds 200 bytes of data, then the copy is headered. And if that's the case, you can use programs
such as "SNEStuff", "SNES Rom Utility", or "Advanced SNES Rom Utility" to remove it.
---------------------------------------------------------------------
Info:
Mega Man X 2 (U) [!].smc	
MD5
67905b989b00046db06df3434ed79f04	

SHA1 
637079014421563283cded6aeaa0604597b2e33c	

CRC32 
947b0355	

SHA-256 
f3246755f608a1e1dc9c848b61da3b824c7853b29b3be40df6fc7f2793a887ed	

SHA-512 
7370376fc56e14128f4a7f432a3d1270b53e85e2835ce998f9a5d907a470cc06dd166bfa96c4ce55139dd3debd75e7847e8aa9a262c01e057019d63799633b81	

SHA-384 
a43a56a0a5d9bc3d3a432aa70f70a99df3bef938915271a95325cfbd832d39a3802eed5e59a9af973a07b57e3f047558
---------------------------------------------------------------------
Credits:
SwiftlyTony360 - Charge shot palettes idea in reference to levels of heat and menu color change
Skyro14x - Fixing enemy graphics
  


