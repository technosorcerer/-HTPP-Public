"Melfand Stories"
Traducción al Español Ver. 1.1 (24/05/2024)
por Max1323 (Traducciones Max1323).
Basada en la gran traducción de Gan.
---------------------------------------------------
Descripción:
El reino antiguo de Melfand vivia en paz hasta que Nomolwa el ministro
del Rey lo traicionó. La familia real fue asesinada y Nomolwa gobernó
el reino.
Cinco años después, cuatro héroes llegaron al reino de Melfand para
devolverle al reino la paz.

Desarrollado: Sting
Publicado:    ASCII Entertainment
Lanzamiento:  25/03/1994 (JAP)
---------------------------------------------------
Acerca del proyecto:
-La mayoría de los textos están traducidos. Se agregaron
los caracteres españoles.

-Se traducieron algunos gráficos. Los demás gráficos están comprimidos.

-Se corrigieron varias cosas:
Se ajustaron algunos textos que se pasaban de la caja de texto.
Las palabras que estaban en mayúsculas ahora están en minúsculas. 
	Ej: "El Rey ha..." -> "El rey ha..."
Se corrigió el nombre de un jefe.

-Un agradecimiento a Wave que ayudó a corregir algunos textos en desde la versión anterior.
-Un agradecimiento a xCRISZx por avisar estos casos que se necesitaban
corregir para esta nueva versión.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS (PC)
Utilizar UniPatcher (Android)
Utilizar Rom Patcher JS (Parcheador Online):
https://www.romhacking.net/patch/

Archivo IPS
Melfand Stories (Japan).sfc
File Size     1.50 MB
File MD5      0B3FE2B7C34687107E91497F1AA8705A        
File SHA-1    F321FECC3EAD4F2E5EC981ED591D87EEDC068E5B
File CRC32    0928FC15