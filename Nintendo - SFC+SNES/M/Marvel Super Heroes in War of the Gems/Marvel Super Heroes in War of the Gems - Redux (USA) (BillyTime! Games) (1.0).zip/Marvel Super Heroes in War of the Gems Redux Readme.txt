Marvel Super Heroes in War of the Gems Redux
Jan. 30th 2025
BillyTime! Games
--------------------
This is a patch designed for Marvel Super Heroes in War of the Gems that revamps some gameplay aspects surronding the Inifnity Gems along with some additional tweaks and additions.

Changes:
--------------------
*Wolverine has a Passive Health Regen (Only Yellow Health)
*Captain America has a slight Defense Buff
*Hulk has a slight Defense Buff
*Equipping the Soul Gem will give players an additional defense buff
*Health pickups replenish 2x the amount of health when Soul Gem is equipped
*Reality Gem doubles amount of items collected
*Iron Man has infinite jumps when using the Space Gem
*Players have infinite air in underwater sections when equipped with the Space Gem.
*Impassible walls can be broken when Equipped with the Power Gem. 

*Cheat:
--------------------
Hold Select and hit start at introduction before the map screen. Continue to hold select until the map appears. When selecting a character, All Infinity Gems will be available.

Alternatively, Hold Up and Select and hit Start. Continue holding Up and Select until the map screen appears and you will start on the second set of levels and recieve all Infinity Gems.

How to Patch:
--------------------
1.Grab a copy of Marvel Super Heroes in War of the Gems (USA).sfc (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file