A ROMHACK by JCDenton!

A simple mod that removes the constantly blinking "PUSH START" when in single player. It works with the english of the game.


ROM / ISO Information:
No-Intro Name: Rushing Beat (Japan)
(No-Intro version  20130701-030720)
ROM/File SHA-1: 19CA57776D3B3CDBC8CC3444CB26E7DE1E40E9B9
Patched ROM/File SHA-1: F67E856F71AA8756AAFAD1E432E20629ADC15960


