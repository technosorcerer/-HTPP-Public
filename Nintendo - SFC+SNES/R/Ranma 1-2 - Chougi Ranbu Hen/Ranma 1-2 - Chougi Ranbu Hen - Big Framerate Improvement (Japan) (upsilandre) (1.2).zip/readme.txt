Ranma 1/2: Chougi Ranbu Hen big framerate improvement and bug fix Hack V1.3
by Upsilandre

You can contact me on my Twitter @upsilandre or upsilandre@Gmail.com or YouTube.

It is an IPS patch to be applied to the original ROM with software such as Lunar IPS.
The exact reference of the original ROM (No-Intro):
Ranma 1-2 - Chougi Ranbu Hen (Japan)
File/ROM SHA-1: 3754284F915C5E7281E1412B932B7BA876F05348
File/ROM CRC32: C552B1F

This patch V1.3 is now compatible with the Dynamic-Design's translation patch V1.10 but it must be applied before the translation patch (translation patch causes visual glitches on the menu, Herb boss, female Ranma and Kuno if you combine it with the wrong versions of my framerate patch).


I made a comparison video with visualization of performance:
https://youtu.be/k-fJ4srsem8?si=VRSWGjc5JqTDD-Xg
You will always find the latest version of the patch under this youtube video (easier to find).


Ranma 1/2: Chougi Ranbu Hen is a good fighting game close to SF2 but with one big flaw: Its framerate is catastrophic. The game is calibrated for 60 fps but can never reach it even if you don't touch the controller and leave the fighters idling. It varies continuously between 30 and 50 fps. With the way games used to work, this means that Ranma runs in slow motion all the time.
The other consequences are a degraded input lag and that the game also has very bad frame pacing because the duration of the frames themselves is very variable. It can vary from 1 to 4.

The hack consists on optimizing the code of the most expensive tasks (this is not a SA1 or FastROM hack). This goes from sprite management to collision management, including input management and sound effects, plus a few other little things.
The result is a game that now runs with a rock stable 60 fps framerate. There is no longer any frame drop even in the most extreme situations. It completely changes the pacing of the game. The input lag is also improved and the frame pacing is now perfect.

The original game had CPU consumption peaks of up to 350% of a frame and now the peaks are more like 92-93%.
One of the many optimizations consisted of changing the graphics format of the sprites on the ROM so that they were in a raw format. This added 1 MB of data to the ROM.

In addition, the patch also includes the correction of 4 collision bugs which very slightly change the behavior of collisions by improving precision.


Update history:
06 August 2024  Version 1.3: Now compatible with translation patch
02 August 2024  Version 1.2: Improves SFX check
31 July   2024  Version 1.1: Fixes a bug that causes the game to crash
28 July   2024  Version 1.0: Base