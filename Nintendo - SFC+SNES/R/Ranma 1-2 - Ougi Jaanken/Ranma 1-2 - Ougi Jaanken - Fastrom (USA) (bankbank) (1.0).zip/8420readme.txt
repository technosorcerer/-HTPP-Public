Obscure PC98 puzzle game SFC port, now in Fastrom!
CRC32 of original ROM: 0a5dfa05
CRC32 of patched ROM: e59b2655

if you have questions, email bank [at] bankbank dot net 

 thanks to:
 kandowontu - explaining this madness
 sour - mesen2 - great debugger
