Rockman & Forte (2x Strength)
Feb. 7th 2025
BillyTime! Games
--------------------
This is a simple patch designed for Rockman & Forte that doubles the amount of damage inflicted on enemies.


How to Patch:
--------------------
1.Grab a copy of Rockman & Forte (Japan).sfc (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file