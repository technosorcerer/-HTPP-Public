ROCKMAN & FORTE (SFC)

-------------------------------------------------
Look up "what is a ROM Header?" and choose the patch you need

Japanese patches
ROCKMAN & FORTE Better Economy (SFC NO Header).ips
ROCKMAN & FORTE Better Economy (SFC WITH Header).ips

English patches: Apply the respective Aeon Genesis' patch FIRST
ROCKMAN & FORTE Better Economy English (RMF-E)(WITH Header).ips
MEGAMAN & BASS Better Economy English (MMB-E)(WITH Header).ips

NOTE: MSU-1 patch is best to be applied LAST, compatibility has NOT been tested.


This patch does the following:

-Increases BOLT gain by 60%
-Changed prices from shops
-Shop dialogue has been corrected/adapted (english patches only)
-I. PRESENT (Renamed to Party-Ball) is now a permanent item

Get the GBA port here: https://www.romhacking.net/hacks/8623/
-------------------------------------------------

:::::::::::::::::
::Hacking Notes::
:::::::::::::::::

-------------------------------------------------
WARNING:
Everything was performed on ROM with NO HEADER
-------------------------------------------------

Current BOLTS Holding [RAM address]
B9C

Start Instruction: 1C8F6 (for bolt get? I forgor)
-------------------------------------------------
Big BOLT [ROM address]
2E5F5

Small BOLT [ROM address]
20AC9

Medium BOLT [ROM address]
20AD1
-------------------------------------------------
Ball is Permanent
1B0B [ROM Address: holds value to be deducted on RAM when losing Ball]
10 -> 00 [Changed value from "10" to "0"]
-------------------------------------------------
Rock's Shop
Original shop table [ROM values]
32 00 78 00 32 00 0A 00 64 00 3C 00
32 00 C8 00 C8 00 32 00 96 00 64 00
C8 00 2C 01 2C 01 C2 01 96 00 2C 01
64 00 2C 01

Modified shop table [ROM values]
32 00 B4 00 32 00 1E 00 64 00 78 00
32 00 2C 01 C8 00 32 00 96 00 64 00
FA 00 96 00 2C 01 2C 01 C2 01 2C 01
64 00 96 00
-------------------------------------------------
Forte's shop
Original shop table [ROM values]
32 00 78 00 32 00 0A 00 64 00 3C 00
32 00 C8 00 C8 00 64 00 64 00 C8 00
C8 00 2C 01 2C 01 2C 01 2C 01 64 00

Modified shop table [ROM values]
32 00 B4 00 32 00 1E 00 64 00 78 00
32 00 2C 01 C8 00 2C 01 32 00 2C 01
FA 00 96 00 2C 01 C2 01 2C 01 64 00
-------------------------------------------------
end