See readme of http://agtp.romhack.net

What's new?
1.1  Fixed text of database, added new logo, and temporal minilogo (You free fix the graphic)
1.0c Fixed some script erorrs and database, fixed the final graphic of King castle.
     (All tnx lilpuddy31)
Added new logo and mini logo from mi spanish version.
Fixed text of database WoodMan and PharaohMan.
Fixed bug, to delete database. (I hope)
How to use?

This addendum is for

https://www.romhacking.net/translations/621/

Use this patch in functional rom patched with MMB-E.ips 



Report any error.
blade133bo@gmail.com
Copyright Š 2000.  Rockman, Forte, and all related characters are registered trademarks of CAPCOM Co., Ltd.