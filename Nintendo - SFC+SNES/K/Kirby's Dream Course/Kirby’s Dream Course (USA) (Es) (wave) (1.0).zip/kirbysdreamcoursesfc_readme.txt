Kirby's Dream Course (Super Nintendo)
Traducción al Español v1.0 (04/10/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Kirby's Dream Course (USA).sfc
MD5: 3f2ee922cd23c9c211777be1d26ea2a8
SHA1: e1f29ad02981ec84156b68d4fb95b2182dc8cd82
CRC32: df8153d9
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --