Kirby's Avalanche
Traducci�n al Espa�ol v1.0 (18/05/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Kirby's Avalanche
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Kirby's Avalanche
-----------------
Juego de puzzle/Puyo Puyo de Kirby.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Letras peque�as de titulo y final no traducidas.
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Kirby's Avalanche (U) [!].smc
1.048.576 bytes
CRC32: 21e658b8
MD5: bddd943215857ad77ea48d2a1a138ec8
SHA1: 95e4ac5f3f95863ffd8c6519f93a52b631c97d4a

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --