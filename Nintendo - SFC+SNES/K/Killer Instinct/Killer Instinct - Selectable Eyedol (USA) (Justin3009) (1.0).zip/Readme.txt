******************************************************************************
Killer Instinct - Selectable Eyedol					     *
Created By: Justin3009 (xJustin3009x/Shishisenkou)                           *
******************************************************************************

Content
-------------
1. What's new?
2. Contact


******************************************************************************
1. What's new?								     *
******************************************************************************
This requires an unheadered 'Killer Instinct.smc' rom!!

This patch allows you to select Eyedol through the roster instead of using the
code for Cinder to unlock him.

--------------------------------------------------------------------------------
******************************************************************************
2. Contact								     *
******************************************************************************

If any bug is found that's unusual or game breaking, feel free to contact me at:
 
Email:	justin3008_diablo@yahoo.com

--------------------------------------------------------------------------------