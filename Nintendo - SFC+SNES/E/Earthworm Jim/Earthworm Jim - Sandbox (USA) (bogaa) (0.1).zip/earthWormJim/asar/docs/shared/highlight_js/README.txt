Update procedure:
* go to https://highlightjs.org/download
* select bash, dos, plaintext, powershell, python
* download
* copy only the highlight.min.js file here
