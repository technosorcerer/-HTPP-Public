- Put your ROM in this folder and rename it to "Earthworm Jim (U).smc"
- If it has a external 0x200 byte header. Remove it and check if you have the rigth ROM. 
- Double click make.bat to patch main.asm to ROM. You find modefied ROM in the root directory. 

Filename: Earthworm Jim (U).smc
CRC-32: 3a4a47eb
SHA-1: 3b666f44ea7574caafb9d64cd4d4c74dd3f81a61