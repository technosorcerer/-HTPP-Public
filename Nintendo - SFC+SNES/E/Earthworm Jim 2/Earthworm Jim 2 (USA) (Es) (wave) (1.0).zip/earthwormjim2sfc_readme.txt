Earthworm Jim 2 (Super Nintendo)
Traducción al Español v1.0 (28/11/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Earthworm Jim 2 (USA).sfc
MD5: c3ff5fd4e3f46653fec94ba60d70281d
SHA1: e4446c9f9c541a0d698e00ecbbb553df165a34f6
CRC32: 393de197
3145728 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --