﻿-- NEW DEBUG MENU --

CURRENT VERSION: 1.1




-- FOREWORD --

This is a more polished update to EarthBound's hidden in-game debug menu. EarthBound's debug menu was used by the original programmers of MOTHER 2 to test various

aspects of the game. When MOTHER 2 went overseas and became EarthBound, the debug menu was left untouched. Later, a witty PK Hacker by the name of livvy94 (also known as

vince94) created a fully translated English version of EarthBound's debug menu, boasting a general overhaul and new additions. Examples include: the ability to enable and

disable enemy spawns, toggle Event flags, and toggle Your Sanctuary melodies. Almost the entirety of the New Debug Menu was retranslated from stratch, but multiple tweaks

and some features from livvy94's original debug menu translation and the debug menu translation on the Cutting Room Floor were also used in conjunction. The New Debug Menu

also features two new menu options: the Event Center and the Arena. The Event Center enables various useful features, such as Realize PSI, whereas the Arena opens the doors

to challenge every boss fight in EarthBound! It is also important to note that the New Debug Menu is still somewhat easy to grasp, but it does not feature the explanations

provided in-game by livvy94 that present themselves as you navigate.


To access the New Debug Menu, use the Game Genie codes 6B84-7D04, 3184-7D64, and 3E84-7DA4, and then grab your handy-dandy ATM card and give it a quick look.



-- CHANGES --

Fully translated into English

Revised and less patchy menu and window navigation

Revised window overlay

ATM card, Sound Stone, and Town map added to Key items tab

Event Center added

The Arena added

Fun little beeps and boops

Removed Herobrine



-- SETUP --

Download the .zip file containing the .ips or .bps patches and apply them to a clean EarthBound ROM using ROMhacking.net's online ROM patcher or another

effective patching tool like the EarthBound patcher. https://www.romhacking.net/patch/


Any SNES emulator can be used to run the game but Mensen is recommended.


Download Mensen. https://mesen.ca/

Find the .smc files and open them with Mensen.

Enjoy the game!



-- HELPFUL RESOURCES --

https://youtu.be/suRcjE2ACXo?t=5m35s

http://www.romhacking.net/utilities/400/

http://datacrystal.romhacking.net/wiki/EarthBound:Control_Codes

https://datacrystal.romhacking.net/wiki/EarthBound:Flags

https://web.archive.org/web/20050411000031/http://starmen.net/mother2/tips/debug.php



-- CREDITS AND THANKS --

Tomato's Legends of Localization: EarthBound

PK Hack Discord Server

EarthBound debug menu translation by livvy94

EarthBound debug menu translation on the Cutting Room Floor

Datacrystal

You, for reading this
