Colinbound 2: Infina's Invasion.


Colinbound 2 is a total conversion Earthbound hack. Battle sprites, items, attacks, magicks, story, text, sprites etc. have all been changed. If you have already conquered Earthbound, this hack will still seem like a new game! I hope you enjoy it, this hack has taken me several years to complete.


In order to play this game, you will first need to expand your Earthbound ROM. You can download the expander here: 

http://pkhack.fobby.net/MacOS/downloads.php




Once your Earthbound ROM has been expanded, apply the COLINBOUND IPS patch. A good IPS patcher can be found here:

http://zerosoft.zophar.net/ipswin.php



Now all that's left is to boot it up with an emulator like ZSNES or SNEShout and there you are!









Controls:
(You'll have to set these up in your emulator)

Directional pad
Moves characters around the area, menu selections etc.

Button A
The main action button. Press this to advance a line of text, confirm a menu choice etc.

Button B
The main cancel button. Press this to "go back" one selection.

There are other minor uses for all of the other buttons, but the A and B buttons and the directional pad will get you through the game.


My E-mail: hh33@mts.net

Special thanks to Zero Diamond for some battle sprites!

Known bugs and problems:
*Sometimes when warping to the Mystic Crater, the game starts a buggy battle scene. The hack then gets scrambled and/or freezes. This happens very rarely, though.
*Spelling and grammatical errors in the text are bound to pop up here and there.
*Occasionally, (especially if your character's names are large) text won't completely fit in a window.

(If you find any other bugs, please let me know!) My E-mail address is above.
