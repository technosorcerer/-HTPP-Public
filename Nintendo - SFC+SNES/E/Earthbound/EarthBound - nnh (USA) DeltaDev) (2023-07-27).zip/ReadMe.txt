The was just my first experience making hacks, so, it's buggy.

For apply the patch, you will need a Earthbound expanded rom to 48MBit