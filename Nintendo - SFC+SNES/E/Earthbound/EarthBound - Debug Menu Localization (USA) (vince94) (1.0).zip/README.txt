This is EarthBound's hidden in-game debug menu. It was what the original programmers used, before the English translation even began, to test the inventory system, see how the game would react in unexpected situations, and generally look around to see if anything needed fine-tuning. Previously, the only way to experiment with it was through cheat codes or other shenanigans, and it was all in untranslated Japanese, as seen here - https://youtu.be/suRcjE2ACXo?t=5m35s

I used the PK Hack community's EarthBound Patcher system to make the patch, and you'll need to download it to apply it.
You can find the link in the Downloads section of this page - http://hacks.lyros.net/earthbound-patcher/
There's also an explanation as to why I chose the EBP format, put into words better than I'd be able to here.

To access the debug menu, take a closer look at Ness's ATM Card. 

Here's everything I changed and/or added:

>There was code for showing and hiding enemies from the map that had actually been dummied out of the debug menu, and was inaccessible. I put it back in, calling it "Invasion Forces." 
>I also put in a way to toggle event flags, and used menu commands to make some of the functions easier to use. 


Have fun!
vince94
www.youtube.com/haxxor199x