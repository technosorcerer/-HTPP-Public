EarthBound Zero/Beginnings Tweaks
By Q
ROMhacking.net profile: http://www.romhacking.net/community/5090/


To use these patches, you will need an IPS patching program, such as Lunar IPS.

You can download Lunar IPS here: https://fusoya.eludevisibility.org/lips/

Apply the desired patches in any order to an EarthBound Zero ROM.
You will need either the clean prototype ROM or the Demiforce v1.01 Hack-2 version.
If you have the prototype version, make sure you apply the Demiforce patch,
or the other hacks will break the game.


Demiforce hack � The patch will turn a clean copy of the EarthBound prototype ROM
into the Demiforce version. This adds the word "Zero" to the title screen, fixes
a few spelling/grammar mistakes, and disables the game's copy protection, which is
necessary if you plan to use any of the other patches. Apply this to a clean
EarthBound (Prototype) ROM before applying any of the other patches.
(If you don't like the word "Zero" being on the title screen, you can download
a patch that will remove it here: http://www.romhacking.net/hacks/999/)

Graphics restoration hack � When Mother was localized into EarthBound, several
sprites were altered in order to censor depictions of blood/gore, smoking,
religious iconography, knives, and even robotic nipples. A few other sprites
were changed for reasons that are not entirely clear. This hack replaces all the
altered sprites with the originals.

Gameplay balance hack � EarthBound Zero is known for being somewhat tedious to
play due to the high random encounter rate and the large amount of grinding the
player must do. This hack attempts to remedy this by quadrupling experience,
doubling money, and reducing the random encounter rate by approximately half.
Using this hack is just like using the "Easy Ring" mod that was created for the
Mother GBA fan translation (except that you don't need to use up an equipment
slot to benefit).

Font hack � This replaces the font with the font designed for the Mother GBA
fan translation for an improved presentation.


Feel free to use any of these patches in your own EarthBound Zero hack!