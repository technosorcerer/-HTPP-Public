XXXXXXXXXXXXXXXXXXXXXXXXXXXXX
X Earthbound - Girl Ness v1 X
XXXXXXXXXXXXXXXXXXXXXXXXXXXXX                                                             
                                                                                      
___________________________________________________________________________     
                                                                                
                                                                                   
This is a hack that makes the main character of the game into a girl.               
                                                                                  
This hack has two versions.                                                         
                                                                                      
- In version T, during the baby flashback sequence, the main character is                   
referred to with masculine terms and the name "Ness" no matter what name        
is assigned at the start of the game.                                           
                                                                                
- In version C, during the baby flashback sequence, the main character is         
referred to with feminine terms and the same name assigned to her at the                
start of the game.                                                                    
                                                                                      
This was done so that certain players may feel a closer connection to                             
their main character. I hope you enjoy the hack!                                        
                                                 
___________________________________________________________________________

Updates

7/5/2024 - v2 - fixed ness's sprite in the magicant flashback sequence

7/19/2024 - v2 is broken cuz i forgot to test it. oops! reverted to v1 with
            the incorrect sprite for the flashback sequence. i'll get on a 
            fix for v2 soon enough.

___________________________________________________________________________           
                                                                                  
Hack created by Blue "Melanie" Ribbs                                              
Additional testing done by MoonBunnyKristi                                        

If you find any issues with this hack, please send me a message on twitter
@BlueRibbs