============================================
Earth Bound Beginnings 25th Faithful Edition 
============================================
This is a title screen patch for Mother 25th Faithful Edition. This also
changes the map to say Earth Bound as well. 

Since Nintendo decided to release their originally unreleased localization of Mother
as Earth Bound Beginnings on the Wii U, I was disappointed that they didn't attempt to
clean up their game and give it a proper title screen. Before that, DragonDeplatino did 
and excellent hack known as Mother 25th Anniversary Edition. He cleaned up the graphics
AND the translation as well. Then ShadowOne333 improved on that by making the game
simpy say Mother, and to rename things to better match Earthbound (Mother 2) such as
naming Giegue to Giygas. Well, this patch is for those who want the the game to have
the title that Nintendo has decided to release the game as and enjoy the improvements 
made by DragonDeplatino and ShadowOne333.

Instructions:

-Get an Earth Bound (Proto).nes ROM. I cannot tell you where to get one.
-Download Mother 25th Faithful Edition here: http://www.romhacking.net/hacks/2318 and patch
your ROM with a patching program. I prefer Lunar IPS.
-Patch your ROM with one of the two patches included with this package.

	-Earth Bound (M25FE).ips will change the title screen to Earth Bound.
	-Earth Bound Beginnings (M25FE).ips will have the title as Earth Bound Beginnings.

Either patch will also change the Map screen to say Earth Bound instead of Mother as well. 

Credits:

-DragonDeplatino for doing an amazing job with Mother 25th Anniversary Edition.
-ShadowOne333 for improving it with the 25th Faithful Ediion.
-Nintendo for making the Mother series. 