The Mysterious Mine (Bouncin' Back Edition)
by FobbyGuy88 2006-2008,2010-2011,2021-2022
EarthBound is originally made by Nintendo Shigesato Itoi


NOTE:Use an IPS patch such as Lunar IPS to patch an EarthBound ROM.
Also, name the XML Document to the ROM that you're using (use the XML document if you're using a bsnes emulator).
This hack seems to only work with ZSNES (Title screen doesn't display right), bsnes-plus-073.3a or Snes9x 1.60

This hack is made for entertainment and NOT for profit!!!

Many of the graphics of each enemy has been changed. There has also been some minor item adjustments and some attack changes as well. If you do encounter any bugs/glitches, please let me know.

Special Thanks
STARMEN.NET (for creating the PKHack community)
JHack (older versions)
CoilSnake
PK Hack Discord
And people who have support me for making this hack.


I will not tell any spoilers but if you want to know how to find the 1/128 items in this game, please check the Enemy Drop list within the .zip file.

Order in which you should go (once you get to the mine)
Northern Cave
First Eastern Cave (when you get your first orb)
Up the ladder (when you get second orb)
*NEW* There will be a transporter that will transport you to a new area before you get to the Far Eastern cave
Far Eastern Cave(once you get the last Transport Orb which is the shiny object in the Octavian Mines (in the room as Lumine Hall).

There is a new magic skill, HustleBoost. This raises the "rush" of allies during battle. HustleBoost replaces Depressor which was basically Def.Down.

A list of when users learn magic skills have been provided.

As of 11/18/2022, the second main character has a NEW magic skill, GaiaStrike. This is an earthquake magic that can damage all enemies. However, the damage will be changed if the target has a barrier/super barrier used. Refer to the Magic Learned text file provided in the .zip file for more info.

Credits (since the credit screen is garbled up)

Story and Idea by  
FobbyGuy88

Many BattleSprites by
FobbyGuy88

CUSTOM MOTHER BATTLE SPRITES by
FrankFly

Overworld Metool sprite by
BBLIR on spritersresource.com

Thanks to Maedaez (aka felix.rodent) for custom sprite for game over screen as well as a Overworld sprite group for an enemy.

Thanks to Cooprocks123e with the title screen creation

Made with
PKHACK 5.14(older versions)
CoilSnake 3.0

EBExpand is not made by me

Some characters are property of their rightful owners

EARTHBOUND ORIGINALLY MADE BY
Shigesato Itoi

BETA TESTERS
olivers2000
kevindubrow
messianic

Well, enjoy! Who knows, I might make a sequel...

NOTE: Once you exit the Mysterious Mine, back to the real world after the second coffee scene. You might experience freezing once you go into battle, don't worry. Your game will be saved after you regroup on the hill. Just reset the game and you'll be saved on top of the hill. Also, just open the menu and you shouldn't experience this problem. You might encounter a little freezing after resting at Jack's House, just press B and the game will resume when going down the stairs.

TIPS
There are secret items you can purchase in NYC, they are called ITEM 1 and ITEM 2. The shop that you can purchase ITEM 1/ITEM 2 can be found behind the cafe in NYC. Before using this, you should create a save state. ITEM 1 will let you use the original ending for The Mysterious Mine, while ITEM 2 will let you view a scene made for fun. When you finish viewing the cutscene, just load your previous save state.