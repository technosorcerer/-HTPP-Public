﻿-- NEW DEBUG MENU --

CURRENT VERSION: 1.4




-- FOREWORD --

This is a more polished update to EarthBound's hidden in-game debug menu. EarthBound's debug menu was used by the original programmers of MOTHER 2 to test and configure 

aspects of the game during development. When MOTHER 2 went overseas and became EarthBound, the debug menu was left untouched. Later, livvy94 (also known as vince94) created a 

fully translated English version of EarthBound's debug menu, boasting a general overhaul and new additions. Examples include: the ability to enable and disable enemy spawns,

toggle Event flags, and toggle Your Sanctuary melodies. The majority of the New Debug Menu was retranslated from scratch, building off of livvy94’s original debug menu 

translation and the translation on the Cutting Room Floor. Implemented with ROM hacking in mind, the New Debug Menu has two new menu features: the Event Center and the Arena. 

The Event Center makes various debug tools easily accessible; you can view the coffee break scenes, enable flag exclusive PSI moves, and more. The Arena enables you to 

challenge every boss fight that EarthBound has to offer! It is also important to note that the New Debug Menu does not feature the explanations that livvy94 built into the

menus.



To access the New Debug Menu, use the Game Genie codes 6B84-7D04, 3184-7D64, and 3E84-7DA4, and then grab your handy-dandy ATM card and give it a quick look.



-- CHANGES --

Fully translated into English

Revised and less patchy menu and window navigation

Revised window overlay

ATM card, Sound Stone, and Town map added under Key items

Broken tools added under Goods edit

Event Center added

The Arena added

Fun little beeps and boops

Coffee break scenes added under Event Center

Cast and credits added under Event Center

Removed Herobrine



-- SETUP --

Download the .zip file containing the .ips or .bps patches and apply them to a clean EarthBound ROM using ROMhacking.net's online ROM patcher or another

effective patching tool like the EarthBound Patcher. https://www.romhacking.net/patch/


Any SNES emulator can be used to run the game but Mesen is recommended.


Download Mesen. https://mesen.ca/

Find the .smc files and open them with Mesen.

Enjoy the game!



-- HELPFUL RESOURCES --

https://youtu.be/suRcjE2ACXo?t=5m35s

http://www.romhacking.net/utilities/400/

http://datacrystal.romhacking.net/wiki/EarthBound:Control_Codes

https://datacrystal.romhacking.net/wiki/EarthBound:Flags

https://web.archive.org/web/20050411000031/http://starmen.net/mother2/tips/debug.php



-- CREDITS --

Tomato's Legends of Localization: EarthBound

PK Hack Discord Server

CCExpand by cooprocks123e

EarthBound debug menu translation by livvy94

EarthBound debug menu translation on the Cutting Room Floor

Datacrystal

You, for reading this