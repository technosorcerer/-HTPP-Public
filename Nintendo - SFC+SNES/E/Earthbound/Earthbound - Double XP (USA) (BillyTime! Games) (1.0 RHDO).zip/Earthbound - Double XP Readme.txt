Earthbound - Double XP
Nov. 27th 2023
BillyTime! Games
--------------------
This is a fun and simple patch designed for Earthbound that doubles the amount of experience earned after every fight.

How to Patch:
--------------------
1.Grab a copy of EarthBound (USA).sfc
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file