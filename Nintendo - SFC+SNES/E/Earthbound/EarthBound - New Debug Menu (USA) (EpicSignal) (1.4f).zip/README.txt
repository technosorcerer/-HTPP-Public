﻿-- NEW DEBUG MENU --

CURRENT VERSION: 1.4




-- FOREWORD --

This is a more polished update to EarthBound's hidden in-game debug menu. EarthBound's debug menu was used by the original programmers of MOTHER 2 to test and configure 

aspects of the game during development. When MOTHER 2 went overseas and became EarthBound, the debug menu was left untouched. Later, livvy94 (also known as vince94) created a 

fully translated English version of EarthBound's debug menu, boasting a general overhaul and new additions. Examples include: the ability to enable and disable enemy spawns,

toggle Event flags, and toggle Your Sanctuary melodies. The majority of the New Debug Menu was retranslated from scratch, building off of livvy94’s original debug menu 

translation and the translation on the Cutting Room Floor. Implemented with ROM hacking in mind, the New Debug Menu has two new menu features: the Event Center and the Arena. 

The Event Center makes various debug tools easily accessible; you can view the coffee break scenes, enable flag exclusive PSI moves, and more. Select the Arena and you'll be 

able to challenge every boss fight that EarthBound has to offer! It is also important to note that the New Debug Menu does not feature various explanations that livvy94 built 

into the menus.


To access the New Debug Menu, use the Game Genie codes DD6C-71F9, 6D6C-7199, and A96C-71B9, and then grab your handy-dandy ATM card and "Use" it.


DD6C-71F9 

6D6C-7199

A96C-71B9

"Use" ATM card



-- CHANGES + NEW FEATURES --

- Revised window overlay

- Revised and less patchy menu and window navigation

- Fun sound effects 

- Broken tools added under Goods edit

- ATM card, Sound Stone, and Town map added under Key items

- Event Center added

- Toggleable flags and Sanctuary melodies added under Event Center

- Coffee break scenes added under Event Center

- Cast and credits added under Event Center

- The Arena added

- Removed Herobrine



-- SETUP --

Download the .zip file containing the .ips or .ebp patches and apply them to a clean EarthBound ROM using ROMhacking.net's online ROM patcher or another

effective patching tool like LunarIPS or EarthBound Patcher. 


https://www.romhacking.net/patch/

https://www.romhacking.net/utilities/240/


Recommended emulator is Mesen for its expansive array of features, such as speeding up and slowing down ROMs via keybind. Find Mesen here:

https://www.mesen.ca/



-- HELPFUL RESOURCES --

Here are a handful of resources that may prove useful when you're diving into the New Debug Menu and ROM hacking.


https://youtu.be/suRcjE2ACXo?t=5m35s

http://www.romhacking.net/utilities/400/

http://datacrystal.romhacking.net/wiki/EarthBound:Control_Codes

https://datacrystal.romhacking.net/wiki/EarthBound:Flags

https://web.archive.org/web/20050411000031/http://starmen.net/mother2/tips/debug.php



-- CREDITS --

Tomato's Legends of Localization: EarthBound

PK Hack Discord Server

CCExpand by cooprocks123e

EarthBound debug menu translation by livvy94

EarthBound debug menu translation on The Cutting Room Floor

Datacrystal

You, for reading this