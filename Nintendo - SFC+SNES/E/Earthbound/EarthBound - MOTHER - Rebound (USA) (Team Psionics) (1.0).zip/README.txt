 _____ _                 _        _
|_   _| |__   __ _ _ __ | | _____| |
  | | | '_ \ / _` | '_ \| |/ / __| |
  | | | | | | (_| | | | |   <\__ \_|
  |_| |_| |_|\__,_|_| |_|_|\_\___(_)

for playing Mother Rebound!
Developed by Team Psionics.


Emulator
========
Snes9x was the emulator i used 4 playtesting. Probably will work fine on other emulators, but it's untested.


Glitches
========
The hack rarely locks up after a boss kills you. The music keeps playing, but the screen goes dark.
The hack also rarely locks up when you walk up in the *last room*. It can even happen in the final cutscene.
Idk why. :I


How 2 patch
===========
There's 3 different patches in the zip file. This is just 2 give more options. They're all the same Hack.


Mother_Rebound.ips	Internal Patching System.
Mother_Rebound.bps	Baked Patching sus.
==================
RomPatcher.js is probably your easiest bet.
https://www.marcrobledo.com/RomPatcher.js/
From there, put an unmodified EarthBound ROM, and the patch in, and Apply patch.
A patched ROM probably would b in downloads after that.


Mother_Rebound.ebp	EarthBound Patch.
==================
Works with this specific patcher.
https://github.com/Lyrositor/EBPatcher
(Tbh i have no idea how this 1 works)

Mother_Rebound.ebp can also be patched through CoilSnake 4.2(Way better than PKHack/JHack).
https://pk-hack.github.io/CoilSnake/
In the Apply Patch tab, there's a space 4 a clean ROM(unmodified ROM), ROM to be patched over(Patched ROM), and the patch itself.
Also works 4 Mother_Rebound.ips if ROM Header is unchecked.


      WWWWWWWWWWWWWWWWWW        
  WWWW111111111111111111WW      
WW11111111======1111111111WW    
  WW1111==,,,,==========1111WW  
WW1111==,,,,,,,,,,,,,,,,==11WW  
  WW,,,,WWWWWW,,WWWWWW,,,,==WW  
WWWWWWWW''''''WW''''''WWWWWWWW  
WW;;;;WW//////WW//////WW;;;;WW  
WW,,,,;;WWWWWW;;WWWWWW;;,,,,WW  
  WW000000,,,,,,,,,,000000WW    
    WW0000,,,,WW,,,,0000WW      
      WW00,,,,WW,,,,00WW        
        WW,,,,,,,,,,WW          
      WWbbWWWW,,WWWWbbWW        
    WWGGvvvvvvvvvvvvvvvvWW      
  WW,,bbbbbbbbbbbbbbbbbbbbWW    
WW'',,WWvvvvvvvvvvvvvvWWvv,,WW  
WW,,,,WWbbbbbbbbbbbbbbWW,,WW    
  WWWWSSSSSSSSSSSSSSWWWWWW      
    WWSSSSSSSSWWSSWWbbbbSSWW    
      WWSSSSSSWWWWbbSSSSSSWW    
      WWWWWWWWWWWWbbSSSSSSWW    
    WWbbSSWWWW  WWSSSSSSWW      
      WWWWWW      WWWWWW        


Tragic Backstory
================
10000 years ago, the dinosaurs died.
In the year 2020, NessButLess(NessExeptLess), Eghoul, Minty, PaintBucketCard, and Sbuppy made a discord chat room.
They 
Maverick was not meant to be. Idk it was some anime inspired thing or smthn. One day, people decided NICK SHOULD LIVE!
And then he did. Tragity struck.
A Lloyd appeared, and took Nick under his wing, making him real.
PantBucketCard created Astro from the soil of the earth.
And then Atlantixa descended.
HE(Me lmoa) made the hack like 50x cooler.
soon, the hack was called EARTHBOUND II: RETURN OF THE STARMEN, but that was dumb, so we called it
MOTHER REBOUND!!!!!!!!!!!
2 years later, and here we are.

Battle royale DLC coming winter 2014.