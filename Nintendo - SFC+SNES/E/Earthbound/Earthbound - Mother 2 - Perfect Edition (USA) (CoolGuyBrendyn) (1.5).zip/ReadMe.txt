--MOTHER 2: Perfect Edition (v1.5)--

EarthBound is widely and rightfully known as having one of the best localizations of any RPG at the time, BUT that doesn't change the fact that there is quite a bit about EarthBound that deviates heavily from the original vision for MOTHER 2. Much of it is relatively minor and doesn't actually really affect the game, however any tiny little thing being off is enough for me to feel is worth fixing. Art is personal, beautiful, and intricate, and I believe original creator intent should prevail through even in the tiniest details. Especially in something as special as the MOTHER series.

SO I present to you all; MOTHER 2: Perfect Edition.

This hack is what I would describe as an "uncensored re-localization". Overtly Japanese named things still have their English names and references to Japanese culture that wouldn't work in the US have still been changed, but anything and everything otherwise that was changed or gotten wrong by the original translators/editors was reverted back to its original form, no matter how small, to the absolute best of my ability leaving personal taste out of things as much as I could (Comprehensive list of changes at bottom of file).

It was created with the hope that anyone, whether you've never played before or you've played dozens of times, can patch their ROM and feel comfortable knowing that they're getting a definitive MOTHER 2 experience, just in English. Whether or not I have the authority to call my own hack the "definitive" version of a widely beloved game is up to you.

"But why did you make this when we already have MaternalBound? You must be some kind of insane person."

I am.

I owe ShadowOne333 a great debt of gratitude for laying quite a lot of the groundwork for what I did with this hack. This hack uses much of his work as a foundation upon which to build and I am by no means trying to take credit for the things he did or disrespect the considerable effort he put into creating his mod, however I feel that in his script is rather clumsy. I dislike the way he seemed to just mash lines from the EB script and literal JP translation together, it just feels awkward to me.

So what I did is try to put myself in the shoes of a professional editor and, with the help of Tom's Legends of Localization website, really examine and think about each changed line and element as hard as I could to try to come up with something that works well in English but retains original intent as closely as possible. Sometimes that means borrowing some of the wording form the EB script, sometimes that means changing the wording entirely, sometimes that means sticking close to the literal translation if it sounds okay, sometimes that means just leaving the script the way it is. I'm aware that the LoL website doesn't feature every single tiny change that was made, but I figured it at least had the main ones and if anyone has any suggestions or tips I can implement those later.

Of course, I am not a professional writer or editor, nor am I Shigesato Itoi himself. I'm just a guy with a great appreciation for words and language who loves these games a lot, and places a great deal of importance on original artistic vision. Hopefully I have been able to come up with a reasonable approximation of how he might have written the game in English.

[v1.5 changes]
	NOTE: Sorry about the long wait for a patch. I moved several months ago and didn't have access to my PC for a while, so thank you to everyone who has reached out with issues or comments! I have read all of them and while I couldn't replicate some of your issues I will continue to keep them in mind as I continue to work on this hack. Thanks for playing everyone!

	-fixed credit sequence having un changed names
	-changed "Ramma" to "Ranma" to better match Japanese pronounciation
	-fixed "You Win!/You Won!" inconitency in Mole dialogue in Happy Happy Village

[v1.41 changes]
	-fixed yet another compatibility issue with SNES 9X (I promise this is the last one)

[v1.4 changes]
	-fixed tilemapping issue that made Gumi [Tenda] Village shop unaccessible

[v1.3 changes]
	-fixed compatibility issues with SNES9X


CHANGES MADE:

-Restored Title Screen
Thanks to CoilSnake 4.1 the full title screen from the original MOTHER 2 release is now possible, so that has finally been added in to this hack after years of my wanting to include it

-Script overhaul

Massive thanks to Tomato and the Legends of Localization website for giving tons of insight into the original M2 script. The suggestions he gives were taken into great consideration and used frequently throughout the new script. Every changed line that I am aware of has been looked over and contemplated to get the smoothest sounding script I could manage while retaining the original meaning and intent behind them.

	Mistranslations restored ("My wife has left me a second time. I'm such a lucky man!")

	Awkward/confusing translations fixed ("Hint Shop Realization")

	Brick Road now has a cockney accent, as suggested by Tomato, to be more accurate to how he talks in M2.

	Metaphysical mumbo jumbo towards the end of the game is made more consistent and understandable

	Starman and robot speak is now in ALL CAPS with no sound effects

	Missing Threed NPCs also hacked back into the game

	Original character names restored

	Pokey = Porky (for continuity with MOTHER 3)

	Monotoli = Monotoly

	Runaway Five = Runaway Brothers

	Trillionage Sprout = Trillion Year Sprout

	Tenda Tribe = Gumi Tribe

	Poo's Master = Yi-Si-Qi

	Penetella = Petenella

	Ay-go Stikke = E-Go Sutekki (The English version doesn't seem to mean anything in English either so I figure might as well change it back to the original.)

	Giygas = Giygas (He's pretty universally known as Giygas, I feel like changing it would be creating distance between this hack and the rest of the community. Feel free to lmk if you disagree, I wouldn't be opposed to switching to it Geigue like he's known in M1/EB:B.)

	Basically all typos and spelling errors resolved

	Courtesy of ShadowOne333, see his "MaternalBound Ω" release info for further details.

	Inconsistent naming fixed

	"Brick Road/Brickroad" is always "Brick Road", since that seems to be the more widely used version

	"Lumine Hall/Lumine Hole" is always "Lumine Hall"

	"Balloon Monkey/Bubble Monkey" is always "Bubble Monkey"

	"Mu, the Place of Nothingness/Place of Emptiness/Place of Nothingness" is always "Place of Nothingness", since that seems to fit best with the original meaning.

-Item names restored

	Protein drink = Grownup drink

	Pair of dirty socks = Petenella's Socks

	Trout yogurt = Strawberry Tofu (Originally changed because US audiences wouldn't know what tofu is, but tofu is much more common here now than in 1993)

	Yogurt dispenser = Tofu machine

	Tendakraut = Gumi Durian (Same as above, I feel like more people know what durian is these days, also it just makes sense that a tribe living underground would have some kind of exotic fruit as their delicacy)

	Apple of Enlightenment = Apple of Wisdom (Perhaps controversial, but I agree with Tomato that it seems to make the Apple's function more clear.)

-Town names restored

	Threed = Threek

	Scaraba = Scarabi

-Newspapers restored to original names

	Twoson Tribune = Twoson Today

	Zombie Herald = Zombie World

-Graphical overhaul

Much of the graphical stuff was taken from the MaternalBound source, but I made several small additions of my own to make it more faithful to M2.

	Crying icon in battle has been restored to original teardrop

	"You Won!" at the end of battles changed back to "YOU WIN!" with original font (Might change back for consistency, since this was changed in MOTHER 3 as well)

	Original "To be continued - -" end card restored

	Magicant ATM label polished up

	Naked Ness in Magicant restored.

	Original brown color and font restored to curtain call sequence.

-All censorship removed*

*There are several points in the script that reference death, hell, heaven, god or the devil in ways that just don't really sound like the way people would naturally talk. Those have either been rewritten or kept as is from the EB script if they seem to work well to start with.

	References to God/religion restored

	References to violence restored

	Original spanking sound

	References to death/dying restored

	References to alcohol/drinking restored

	Swearing restored

	Red crosses on hospitals and nurses outfits restored

	References to copyrighted things restored (e.g. the running man/coca-cola truck)



Even with all of that there are many smaller things changed that aren't specifically mentioned here, and there are several things still that I haven't been able to implement or change because they require much more assembly language coding than I'm able to wrap my head around (the colored diamond in the text boxes is the biggest one).

But that's it! Hopefully some of you will appreciate or enjoy this version of the game as much as I have been. Feel free to give any comments or suggestions down below, or if you happen to play through the game with this mod and notice anything is broken or weird please let me know so I can try to fix it.

-CoolGuyBrendyn