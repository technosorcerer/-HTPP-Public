"Power Instinct"
Traducción al Español Ver. 1.1 (09/08/2024)
por Max1323 (Traducciones Max1323).
---------------------------------------------------
Descripción:
La familia Gouketsuji es la tercera más poderosa del mundo y por ello muchos ansían alzarse como líder del clan. Para ello, cada cinco años se celebra un torneo de artes marciales donde todos aquellos que tengan algún parentesco con los Gouketsuji puedan optar por el título de líder del clan. Oume lleva ese título desde hace 60 años y no ha sido derrotada todavía.

Desarrollado: Atlus
Publicado:    Atlus
Lanzamiento:  14/10/1999 (JAP)
	      XX/12/1994 (USA)
---------------------------------------------------
Acerca del proyecto:
-La mayoría de los textos están traducidos. Se agregaron
los caracteres españoles.
-Algunos gráficos fueron traducidos.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS (PC)
Utilizar UniPatcher (Android)
Utilizar Rom Patcher JS (Parcheador Online):
https://www.romhacking.net/patch/

Archivo IPS
Power Instinct (USA).sfc
File Size     2.50 MB
File MD5      A56617FE8A2909D17A2989309C9BD51E        
File SHA-1    88A421796BBB5EDC8000176D18B437899DA3E65F
File CRC32    CB8A4F8E