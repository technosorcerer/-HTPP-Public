Plok SRAM - Combat Arms
Oct. 26th, 2025
BillyTime! Games
--------------------
This patch is designed add a costume select and a simple save function to Plok.

Combat Arms:
--------------------
Press L/R + X to receive the following costumes

L = Hunter Suit
R = Boxer Suit
L + X = Rocket Suit
R + X = Flamethrower Suit
L + R = Return to Normal 

SRAM:
--------------------
Saving:
Game saves after each level completed and player returns to the map screen. (Normal Mode Only)

Loading:
At the title screen, Hold L and Press start. For best results, hold until Plok's House appears.
After the intro, your progress will be restored!

Note:
*Game must be reloaded each time after a Game Over
*Internal Anti-Piracy checks disabled
*Loading without a prior save will result in errors

How to Patch:
--------------------
1.Grab a copy of Plok! (USA).sfc
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file