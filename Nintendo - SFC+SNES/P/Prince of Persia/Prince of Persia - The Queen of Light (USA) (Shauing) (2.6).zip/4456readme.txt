This patch is intended to work with the USA release of Prince Of Persia (SNES).

Changes from V2.0:
- A few guards have changed positions (a few tiles to the left or to the right).
- Possible softlocks on some levels have been fixed.
- Minor new background graphics to hid sprites that shouldn't appear.

Changes from V2.1:
- New graphics (mainly in the prologue).
- Removal of a pointless puzzle.
- More softlocks fixed.
- More graphical fixes.
- One level's overall difficulty reduced.
- Guards have more HP in one of the training levels.
- Time limit expanded to 90 minutes.
- A new ''casual-players difficulty'' version is included alongside the original difficulty one, aimed for less skillful players.
  Differences between the original are overall less tight timed puzzles, less traps and loose floors, and checkpoints for the first two levels.

Change from V2.5:
- Passwords to empty levels are invalid now (Both versions).