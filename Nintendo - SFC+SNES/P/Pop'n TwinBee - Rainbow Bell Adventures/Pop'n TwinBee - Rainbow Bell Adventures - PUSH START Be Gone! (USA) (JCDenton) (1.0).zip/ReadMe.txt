A ROMHACK by JCDenton!

A simple mod that removes the constantly blinking "PUSH START" when in single player. It works with both the original Japanese release and the English fan translation.

Why patch the Japanese version and not the European?
The European version, removes the secret exits and all of the character dialog, all but the worst ending, and bleaches the map into a straight line. It also removes the battery save functionality, instead opting for a password function. I therefor recommend playing the Japanese release translated or not. 

ROM / ISO Information:
- No-Intro Name: TwinBee - Rainbow Bell Adventure (Japan)
- No-Intro version 20130701-030720
- ROM/File SHA-1: 9991B9ED49C7FE663DEEB9EC51B54A216B957A1F
- ROM CRC32: 91867AF4
