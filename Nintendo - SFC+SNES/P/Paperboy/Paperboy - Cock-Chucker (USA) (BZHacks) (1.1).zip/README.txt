A graphics and text hack of Paperboy 2 for the SNES where you throw dicks instead of newspapers.

Patch to unheadered Paperboy 2 (USA).sfc