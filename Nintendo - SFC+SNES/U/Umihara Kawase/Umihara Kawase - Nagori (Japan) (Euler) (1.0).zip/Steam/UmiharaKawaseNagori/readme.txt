Umihara Kawase Nagori Steam Version

This is a mod for the Steam version of Umihara Kawase that ports the SNES romhack "Umihara Kawase Nagori".

Download Link: https://u.pcloud.link/publink/show?code=kZlyb05Z1xKjfhTpJa8CwhoD4ih3xulXnb4X


# How to Start

1. Apply the `UmiFstWin_Nagori.bps` patch to `UmiFstWin.exe` in the original game folder.

2. Move the patched executable, `UmiFstWin_Nagori.exe` into the `UmiharaKawaseNagori` folder.

3. Copy the `snd` folder from the original game's `data` folder into `UmiharaKawaseNagori\data`.

4. Launch `UmiFstWin_Nagori.exe` directly.  
   **Do not launch it through Steam.**


# Note

* The save data for this mod is stored separately from the original game's save data.
  Save data location:   `%LOCALAPPDATA%\UmiharaKawase\UmiNag00.bin`
  Replay data location: `%LOCALAPPDATA%\UmiharaKawase\repnag`

* Field 38 can only be accessed under the 30-minute rule.

* The "Records" screen in the game will show a total of 39 fields, 52 doors, 3 endings, 8 backpacks, and 16 enemies.

* Umihacks and Fast 5 min. mode patch (by mpu) have already been applied.
  https://www.speedrun.com/umi/resources
