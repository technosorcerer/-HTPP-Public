Umihara Kawase Nagori vresion 1.0
Released by Euler


# Download
https://u.pcloud.link/publink/show?code=kZlyb05Z1xKjfhTpJa8CwhoD4ih3xulXnb4X


# About the Patch

To apply this patch, you will need the original SNES ROM of "Umihara Kawase" (CRC32: 393CCCA2).
Optionally, you can also apply additional patches such as the translation patch or HUD patch from romhacking.net.


# Changes

* All original fields have been removed and replaced with new ones.
* The 30-minute time limit rule has been removed.


# Extra Patches

* SRAMxKB.ips - Increases SRAM size (Choose from 4, 8, 16, or 32 KB)
Please note the following:
Before applying this patch, launch the game once to create the default 2KB save data. Then apply the SRAM patch and launch the game again. This will expand the SRAM size from 2KB.
If you skip this step, the game will crash before reaching the replay menu.
This patch allows more replay to be saved. However, please be aware of the following message:
>"SRAMのあきえりあがたりないので、とちゅうまでしかせーぶできません。"
>(NOT ENOUGH SPACE... SAVE WILL BE BAD)
If you save when this message appears, the game may crash and corrupt your save data.  
To avoid this, delete any unnecessary replay data to free up space before saving.
Also note: If you apply the 16 KB or 32 KB patch, numbers over 10000 may not display correctly, but this is likely harmless.

* InfiniteLives.ips - Your lives will no longer decrease.

* 0.01_SecondTimer.ips - Timer now displays to 1/100th of a second.

* SkipDemo.ips - Skips the short demo before Field 00-05.

* ShortenEndCredits.ips - The credits will close shortly after the logo appears.

* AllDoorsMode.ips - Lets you play all fields in sequence: F0 → F1 → F2 → ... starting from Field 0.  
  In fields with two doors, entering the second door will advance you to the next field.  
  This patch is for "Umihara Kawase Nagori" only.


# Update Log

* 2025-07-23
  Added AllDoorsMode.ips patch.

* 2024-12-26
  Added three optional patches:  
  0.01_SecondTimer.ips, SkipDemo.ips, and ShortenEndCredits.ips.

* 2024-11-29
  Released version 1.0.
