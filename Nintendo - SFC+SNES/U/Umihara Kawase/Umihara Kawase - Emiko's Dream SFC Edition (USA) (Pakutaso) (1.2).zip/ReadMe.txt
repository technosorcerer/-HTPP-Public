This is an arrangement and port of Emiko's Dream, which was originally a Steam Version Umihara Kawase Mod, to the SFC Version Umihara Kawase.
The palette has been changed, and some fields have been modified to prevent crashes on SFC.
I actually wanted to add new fields, but I didn't have any ideas, so I put it off.
Unfortunately, this ROM hack does not have the custom music that the original had.

Beware, not all fields have been tested so crashes are likely!

Story
Emiko is a 19-year-old girl. The day ends, and she goes to sleep. This is the story of the strange dreams that Emiko has recently started having: A dream in which she dreams of her childhood self being attacked by fish but walking along a pathless road.

Credit - Pakutaso for background https://www.pakutaso.com/  

Changelog

v1.2 - Imported Steam version palettes
       Attempted to fix game over screen
       Fixed some Emiko graphics

v1.1 - Added Engrish Translations
       Added 5 fields