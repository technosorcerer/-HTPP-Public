Umihara Kawase Nagori
Vresion 1.0
Released by Euler

# Download
https://u.pcloud.link/publink/show?code=kZlyb05Z1xKjfhTpJa8CwhoD4ih3xulXnb4X

# About the Patch

Original SNES ROM "Umihara Kawase" (CRC32: 393CCCA2) is required to apply the patch.
You can also apply translation patch, HUD patch etc. from romhacking.net as needed.

# Changes

* Added new fields (removed all existing fields)
* Removed 30 minutes time limit rule

# Extra Patches

* SRAMxKB.ips - Increase SRAM size (Select one of 4, 8, 16, or 32 KB)
Please note the following.
Before applying this patch, start the game once and create the normal 2KB save data. Then, apply the SRAM patch and start the game again, which will increase the SRAM size from 2KB. Otherwise, the game will crash before the replay menu.
This allows more replay to be saved but note the following message.
"SRAMのあきえりあがたりないので、とちゅうまでしかせーぶできません。"
(SRAM DATA IS TOO SMALL CANNOT SAVE)
Saving when these message appears will crash the game and destroy your save data.
In this case, please delete unnecessary replay data to free up space before saving.
And if you apply 16 or 32 KB patch, numbers above 10000 will be displayed incorrectly, but probably not a problem.

* InfiniteLives.ips - Your lives will no longer be reduced.
