Umihara Kawase (Super Nintendo)
Traducción al Español v1.0 (17/12/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en el de 	satsu y Green Jerry.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Umihara Kawase (Japan).sfc
MD5: abddd496bab9c4fd12007f3125db85cc
SHA1: c4da5c1aaf998f0c7114adff0436246728a2139e
CRC32: 393ccca2
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --