Beavis and Butt-Head does SNES
Dec. 9th, 2025
BillyTime! Games
--------------------
This patch is a balance patch for Beavis and Butt-Head on SNES.

Changes:
--------------------
*Lives set to 5 and full health granted when using password
*Enemy hits take less damage
*Gun pickups add 30 more ammo
*Food give more health back
*Grabbing health when full grants an extra life 
*Health Restored after finishing a level

How to Patch:
--------------------
1.Grab a copy of Beavis and Butt-Head (USA).sfc (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file