Bobby's World (Super Nintendo)
Traducción al Español v1.0 (04/05/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bobby's World (USA) (Proto).sfc
MD5: 6452748e3042c9b7a4ff37dde5e9e69b
SHA1: 93e740d37750e1f464b545dfb569b9d51c3473e4
CRC32: 18bbee33
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --