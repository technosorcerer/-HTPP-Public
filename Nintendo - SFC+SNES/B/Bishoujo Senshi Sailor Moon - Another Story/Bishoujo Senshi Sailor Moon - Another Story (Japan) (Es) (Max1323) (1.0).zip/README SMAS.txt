"Sailor Moon Another Story"
Traducción al Español Ver. 1.0 (08/08/2025)
por Max1323 (Traducciones Max1323).
Basada en la gran traducción de Bishoujo Senshi Translations, mteam, mziab, FlamePurge y Dindo.
---------------------------------------------------
Descripción:
La historia inicia en Tokio de Cristal, en el Siglo 30.
Un misterioso cometa está por llegar y, al mismo tiempo, 
un enigmático grupo conocido como las Oppositio Guardians desea 
obtener el Cristal de Plata para cambiar el destino de la Tierra.
En el presente, las Sailor Guardians han logrado acabar con la 
amenaza de las Death Busters y viven en paz… hasta que esta se ve
interrumpida por la aparición de varios enemigos que atacan la ciudad.
Esto lleva a que las Sailor Guardians vuelvan a reunirse para combatir este nuevo mal.

Desarrollado: Angel (Bandai)
Publicado:    Angel (Bandai)
Lanzamiento:  22/09/1995 (JAP)
---------------------------------------------------
Acerca del proyecto:
-La traducción fue posible gracias al trabajo de:
*mziab, FlamePurge, ffgriever, Kini, Rose, M0nsieurL por sus herramientas y traducción del inglés.
*Dindo, gracias a él se pudo realizar esta traducción.
*Bishoujo Senshi Translations: Moose M., Lina`chan, Nuku-Nuku, Janitha R., SoM2Freak, Harmony7, Xeur, FuSoYa, Kisai, Cecil, StormClaw. Fueron los que iniciaron la primera traducción.
*Wave, que me corrigió los textos.
*La página de FantasyAnime, la conocí por su guía de Front Mission y también me ayudo con su guía y mapas de Sailor Moon Another Story.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS (PC)
Utilizar UniPatcher (Android)
Utilizar Rom Patcher (Parcheador Online):
https://romhackplaza.org/patch/

Archivo IPS
Bishoujo Senshi Sailor Moon - Another Story (Japan).sfc
File Size:    3.00 MB
File MD5      5F776488E366B6D6B44F6E8A01D9953D        
File SHA-1    137F84BA5D0736B887213E0C0CABD0649BBBAFC7
File CRC32    02A442B8