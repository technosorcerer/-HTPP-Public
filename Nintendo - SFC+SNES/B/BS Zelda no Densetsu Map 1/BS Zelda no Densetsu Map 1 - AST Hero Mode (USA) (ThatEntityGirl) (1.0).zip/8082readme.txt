This hack should work for any version of Ancient Stone Tablets.

If you're not interested in the ASM source code then just ignore the "asm" folder. It's not needed.

There are three versions of the hack:
- "Hero Mode" has double damage and no heart drops akin to the Hero mode found in many Zelda games.
- "ALBW Hero Mode" has quadruple damage, but does have heart drops like in A Link Between Worlds.
- "Superhero Mode" has quadruple damage and no heart drops.

Each version has two patch files. Apply the one that says "Week_1_2" to the first and second week roms.
Apply the one that says "Week_3_4" to the third and fourth week roms.

Enjoy!

~ThatEntityGirl