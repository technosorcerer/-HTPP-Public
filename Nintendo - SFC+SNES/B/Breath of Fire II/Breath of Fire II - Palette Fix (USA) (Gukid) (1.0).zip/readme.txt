Breath of Fire Palette Fix v1.0 by gukid (zimmatic@hotmail.com)


Reason:
I wanted a portable BoF2 that didn't burn the eyes, so I broke out the APE, snespal and xi32 to insert the snes palette.  Also removed the ugly gradients and the yellow font colour in battles.  The game should look much more consistent now.


How to apply:
Get a US Bof2 gba rom (may work on the UK version, is there one?) and patch away.  I suggest LunarIPS.


HELP!
This would be a useful patch, except for the fact that the game is extremely "crippled".  Enemies give much more exp and gold to the point that after simafort, most enemies and bosses can barely even touch you.  I would love some help fixing this, by putting the enemy stats back to what they were also in the snes version, or even balance em out.

If you, or anyone you know thinks they could help, I'd love to hear from you.  Even if you can just make a simple editor for modifying the exp and gold values of the enemies, I could probably rough out the grunt work.

I'm also interested in adding in the missing intro parts from the Japanese BoF2 gba, if it's at all possible.


Special thanks to:
Lord Asaki - his SMW palette hack was what motivated me to actually try and do this.