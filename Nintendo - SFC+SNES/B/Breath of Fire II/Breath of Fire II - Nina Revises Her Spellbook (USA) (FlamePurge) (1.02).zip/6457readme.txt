                                         BREATH OF FIRE II
                                     NINA REVISES HER SPELLBOOK
                                         v1.02 (Feb 5 2024)

*****************************************************************************************************
* IMPORTANT NOTICE FOR THOSE PLAYING THE RETRANSLATION:                                             *
*  You NEED "BoFII.SRM"! Read on to learn why.                                                      *
*****************************************************************************************************
* d4s included a "checksum verification" when the game is first booted. This was intended to        *
* prevent people from distributing bad dumps and reproduction copies. As a result, if one applies a *
* mod in conjunction with the retranslation, the verification process fails and the game won't      *
* continue to the title screen.                                                                     *
*                                                                                                   *
* This can be circumvented by loading a SRM file that has already been initialized by the unaltered *
* patch. Therefore, those playing the retranslation will need BoFII.SRM, included in this archive.  *
*                                                                                                   *
* Simply ensure the name of your ROM and your SRM file match, and put the SRM file in the same spot *
* as your other saves. (e.g., if your ROM is named Breath2.sfc, rename the SRM appropriately and    *
* place it in your emulator's "Save" folder.                                                        *
*****************************************************************************************************

Quick Find: Press Ctrl + F and type in the keyword, then press Enter to search for the section.


      TABLE OF CONTENTS
     Disclaimer .. [DSC1]
     Changelog ... [CHG2]
     Credits ..... [CRD4]

====================================================================================================
Disclaimer [DSC1]
==========
- Breath of Fire II (c) Capcom. All rights reserved.

- No ownership is claimed by FlamePurge over Breath of Fire II or the franchise from which it
   originates. Commercial use of this patch, including but not limited to reproduction, sale, etc.
   is strictly prohibited.

- This unofficial, fan-made patch is provided "as-is" on a voluntary (i.e. non-profit) basis.
   FlamePurge is not liable for damage incurred to the end-user, their OS, or their hardware while
   using this patch.

- Apply this patch only to Unheadered ROMs with the following specifications.

   Breath of Fire (U) [!].sfc
   Unheadered
    SHA1 - 5774F2F5268C6AEE6112E859C57C1D28FB9F9EBF
     MD5 - A9FCC59ECB2C3DDC9F47C0161C5D2B06
   CRC32 - 7B79AECE

  Breath of Fire II - The Fated Child (T-Eng v1.2b).sfc
   Unheadered
    SHA1 - 306D950D7165ADB6E0C9CFDCB00992497848403A
     MD5 - 2C5D1DA905D8E2605237057DAC5332EC
   CRC32 - 99356961

- Players are encouraged to keep a backup of their original game file in case an error occurs.

----------------------------------------------------------------------------------------------------

Strangely, Nina learns Bomb/Simoon, Fireball/Inferno, and Missile/Sirocco in the late level 50's.
Since this is rather unintuitive, I rearranged her spells so that she will learn these three spells
at more appropriate times.

Her spell list has not been significantly modified, and the new acquisition levels for the
aforementioned triad are at times when Nina simply learned nothing in the unaltered game.

A small bug was also fixed; the game actually tells Nina that she learns Ag.Down/Slow at level 8,
which is the level she joins the team at. As a result, she quietly plays "catch up" at the next
level. This has been changed so she properly learns it at level 9.

To be clear, here is a comparison.

    Before                         After
	       OG Name   Ryusui's             OG Name   Ryusui's
   Start - Tornado   Cyclone      Start - Tornado   Cyclone
   Start - Cold      Frost        Start - Cold      Frost
   Start - Thunder   Jolt         Start - Thunder   Jolt
   Start - Spark     Flare        Start - Spark     Flare
   LV  8 - Ag.Down   Slow         LV  9 - Ag.Down   Slow
   LV 10 - Pwr.Down  Blunt        LV 10 - Pwr.Down  Blunt
   LV 12 - Exit      Exit         LV 11 - Bomb      Simoon
   LV 13 - S.Boom    Lightning    LV 12 - Exit      Exit
   LV 15 - Def.Down  Weaken       LV 13 - S.Boom    Lightning
   LV 17 - Drain     Leech Power  LV 15 - Def.Down  Weaken
   LV 20 - Flame     Fireblast    LV 17 - Drain     Leech Power
   LV 22 - Typhoon   Typhoon      LV 20 - Flame     Fireblast
   LV 24 - Freeze    Iceblast     LV 22 - Typhoon   Typhoon
   LV 26 - Angel     Kyrie        LV 24 - Freeze    Iceblast
   LV 28 - Death     Death        LV 26 - Angel     Kyrie
   LV 31 - Hail      Blizzard     LV 28 - Death     Death
   LV 36 - Bolt X    Valhalla     LV 29 - Fireball  Inferno
   LV 55 - Fireball  Inferno      LV 31 - Hail      Blizzard
   LV 56 - Bomb      Simoon       LV 33 - Missile   Sirocco
   LV 57 - Missile   Sirocco      LV 36 - Bolt X    Valhalla 
   
====================================================================================================

====================================================================================================
Changelog [CHG2]
=========
v1.02 (Feb 5 2024)

- Somehow, I messed up the entire patch again. Fun! It's actually fixed this time, I promise.

----------------------------------------------------------------------------------------------------

v1.01 (Oct 24 2022)

- Nina now learns these spells at earlier levels:

   OldLV | NewLV | OG Name | Ryusui's
   ----------------------------------
   LV 56 | LV 11 | Bomb    | Simoon
   LV 55 | LV 29 | Fireball| Inferno
   LV 57 | LV 33 | Missile | Sirocco


- The game is now told that Nina learns Ag.Down/Slow at LV 9. Practically invisible change, but
   it's tidier code.
====================================================================================================

====================================================================================================
Credits [CRD4]
=======
- Aegis Runestone: Reporting that the older incarnation of this mod broke things.

- Suplex the Cranes: Explaining data.

- ThegreatBen: Coming to the rescue when the mod's second incarnation was still somehow busted.

- Data Crystal: Explaining data.
   https://datacrystal.romhacking.net/wiki/Breath_of_Fire_II:ROM_map

- Capcom.

...and all you Breath of Fire fans out there! We Desire Breath of Fire!
====================================================================================================