 ************************************
* Breath of Fire & Breath of Fire II *
*       GBA sound restoration        *
 ************************************

** By Bregalad **
October 24th, 2017
Version 1.0a

1) Introduction

Breath of Fire and its sequel, Breath of Fire II, have been originally released by Capcom for the SNES in the mid 90s and then re-released by Capcom for the GBA in the early 2000s. Unfortunately the sound quality suffered in the GBA ports, many instruments are replaced by GameBoy Color sound channels instead of being played back by the original instruments. Yet, all the original SNES instruments are alreaedy in the GBA ROMs. All this hack does is add new music data from the SNES games that actually makes use of the SNES instruments which are already there.

Because the new music data was slightly larger in ROM size in both games, I decided to insert it elsewhere in the ROM, sometimes expanding it to the upper power of 2, rather than trying to squeeze as much data as possible where the original GBA music data was and place the leftover somewhere else. That also means the patched ROMs will still contain the original GBA sound data, that is left unused.

2) ROM sizes in bytes

Roms with a (*) are expanded when patched.

                Breath of Fire I     Breath of Fire II
                Original  Patched    Original  Patched
Europe          4194304   4194304    4194304   4292748 (*)
N.America       4194304   4194304    4194304   4292748 (*)
Japan           4194304   4194304    4194304   4194304

Note that it would be very likely to be possible to make un-expanded Europe and N.America bof2 roms, but this would be more annoying to make so I didn't bother, as I don't think any flash cart is restricted to 4MB and can't support 8MB. If it is for any reason necessary to make a version which fit in 4MB please contact me.

2) Changes made by those patches
- Music data from the SNES games is added, re-using instruments banks already present in the GBA versions
- A faster/higher quality sound mixer is used, thanks to ipatix

3) Known bugs

In the japanese version of Breath of Fire II, the intro (which is not present in neither the EU or US version) is silent, likely because the main volume is erreneously set to 0.

4) FAQ :

Q : I've never played the SNES version of Breath of Fire / Breath of Fire II. Should I play the GBA version with this patch ?
A : Yes! The original GBA versions features Game Boy Color sound which seriously hinders the enjoyability of the soundtrack, and some musical instruments were removed entierely.

Q : Does this hack affect anything else in the game ?
A : No, it shouldn't. If anything else is affected by this patch specifically this is a bug and should be reported.

Q: Will you make a hack that restores the font/dialogue boxes/palette/etc.. of the SNES game ?
A: No I won't and I'm unable to. If you want that you should as well play the SNES original.

Q: Will you make a hack that restores the music of any other SNES game ported to the GBA ?
A: Almost certainly not, I've already made 3 Final Fantasy games and 2 Breath of Fire games.

Q: I want to improve this hack/make my own hack for another GBA game. How do you do it ?
A: Before contacting me read my GBA sappy sound engine document, available on http://www.romhacking.net

Q: Will you send me a ROM ?
A: No, it's a IPS patch for legal reasons. You should be big enough to find a way to get a ROM by yourself.

Q: What is the difference between your Final Fantasy sound restoration patches and those ones?
A: Belive me or not, there are major differences. Final Fantasy patches, in their last versions, completely scrap everything sound-related from the original GBA ROM and insert new sound effects and music data that sounds like the SNES game. On the other hand, those patch for Breath of Fire games simply change the music tracks themselves. Another difference is that the Final Fantasy patches were designed to lower the CPU usage, in order to prevent the games from lagging. On the other hand, the Breath of Fire patches purposely uses a lot of CPU time to have sound quality on par with the SNES originals. The game won't lag, apparently Breath of Fire games were ported in a more efficient way by more capable programmers.

Q: I can't apply your IPS patch to my ROM / It crashes when loading.
Q: On which ROM should the patch apply ?
A: Be sure to use the correct patch for the correct game (Breath of Fire / Breath of Fire II) *and* the correct region (Europe, North America, Japan).

5) Special thanks:

- Capcom, for making the Breath of Fire series

- Nintendo, for making the SNES and the Game Boy advance hardware

- iptaix, for having reverse engineered a faster version of the GBA music mixer, and helped me a lot to make those patches. Without him those patches would not have been possible, or would be in much worse quality

- Whoever composed the soundtrack of Breath of Fire I. Really amazing work, especially considering the original (SNES) limitations.

6) Special non-thanks:

- Whoever composed the soundtrack of Breath of Fire II. It's awful, especially compared to the amazing soundtrack of its predecessor. But at least the SNES version is a little bit better than the GBA. The only reason I made a patch for this game is 1) because I could and 2) for the sake of completeness.

- Whoever at Nintendo/Capcom which had the great idea to use the weak/cheap GameBoy Color sound for music tracks weren't intended to use it.

- Whoever at Nintendo/Capcom which made a weird/non-standard VBlank handler for those games, forcing ipatix and I to do deep research on how to being able to play music without introducing graphical glitches and random crashes in the games.

7) Versions history :

v1.0, December 10th 2017
Initial release

v1.0a, October 24th 2018
Same as v1.0, except that US and EU version of Breath of Fire II expand only to data past 0x400000, and do not re-use existing ROM at all. This makes it possible for the patch to be compatible with other hacks, such as "Breath of Fresh Fire II". Other than that there should be no difference.

v1.1, January 5th 2019
Some fixes in "Breath of Fire II", where there was minor bugs in the music.

v1.2, March 24th 2019
Some fixes in "Breath of Fire II", where there was minor bugs in the music.
