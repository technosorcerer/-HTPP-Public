Bonkers ReTooned
May. 19th 2025
BillyTime! Games
--------------------
This patch is designed for Bonkers on SNES that refines a few aspects of the game  

New features:
*First Boss has slightly less health
*Collector boss has slightly less health
*Players start with 5 lives instead of 3
*Players recieve a free bomb when leveling up

*Upgradable dash 

How it works:
--------------------
Every level milestone, Bonkers dash recharges faster until finally receiving unlimited dash. Levels are unlocked by collecting badges and leveling up bombs as the game progresses.
LVL 1 - 06 BOMBS
LVL 2 - 10 BOMBS
LVL 3 - 15 BOMBS
LVL 4 - 20 BOMBS
LVL 5 - 25 BOMBS (iNFINITE DASH)

How to Patch:
--------------------
1.Grab a copy of Bonkers (USA).sfc (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file