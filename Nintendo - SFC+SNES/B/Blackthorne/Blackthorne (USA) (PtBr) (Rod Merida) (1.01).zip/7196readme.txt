================================================================================
                                 Blackthorne
                                -PT-BR- v1.00
                    Dindo, Rod Mérida e Maverick Blue Warrior
                                  27-01-2024
================================================================================

--------------------------------------------------------------------------------

-------------------------------------------------- -------------------------
EQUIPE
-------------------------------------------------- -------------------------
Tradução: Dindo
Romhacking: Rod Mérida
Dump: Maverick Blue Warrior


-------------------------------------------------- -------------------------
COMO APLICAR O PATCH
-------------------------------------------------- -------------------------

***IMPORTANTE***

O patch deve ser aplicado em todas as versões americanas do jogo.
A seguir, encontre o CRC da ROM para aplicar este patch:

Blackthorne (BR) (2024) v1.00: 856BEAB1

Antes de aplicar o patch, certifique-se de fazer um backup da memória original.

***INSTRUÇÕES***

- Abra o programa flips, clique em "Apply IPS Patch"

- Selecione o "Blackthorne (BR) (2024) v1.00.ips" e clique em "Abrir"

- Na tela seguinte, selecione a ROM Blackthorne (USA).sfc

- Clique em abrir e pronto! Seu jogo estará traduzido ;)

-------------------------------------------------- -------------------------
