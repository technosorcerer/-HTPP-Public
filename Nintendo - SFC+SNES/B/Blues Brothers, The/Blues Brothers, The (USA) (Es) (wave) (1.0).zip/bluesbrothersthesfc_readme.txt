The Blues Brothers (Super Nintendo)
Traducci�n al Espa�ol v1.0 (23/12/2018)
(C) 2018 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Blues Brothers, The (U) [!].smc
MD5: 80eba5229ad4118906fbe1404fde5af8
SHA1: ad516a2bb9e7a8c9ecccdfbb491ba3dcc92a0519
CRC32: 82b97464
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --