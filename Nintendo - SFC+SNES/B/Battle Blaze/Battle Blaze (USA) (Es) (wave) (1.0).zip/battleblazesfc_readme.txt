Battle Blaze (Super Nintendo)
Traducción al Español v1.0 (29/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Battle Blaze (USA).sfc
MD5: afcbfae9eadc31880b3216ac1519c7af
SHA1: 2a1c91b6a9ffd5b8d01e388c1322341216021a02
CRC32: d933bd8d
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --