                                           BREATH OF FIRE
                                         WAR OF THE GODDESS
                                         v1.06 (Jan 21 2024)

Quick Find: Press Ctrl + F and type in the keyword, then press Enter to search for the section.


      TABLE OF CONTENTS
     Disclaimer .. [DSC1]
     Overview .... [OVR2]
     Changelog ... [CHG3]
     Credits ..... [CRD4]

====================================================================================================
Disclaimer [DSC1]
==========
- Breath of Fire (c) Capcom. All rights reserved.

- No ownership is claimed by FlamePurge over Breath of Fire or the franchise from which it
   originates. Commercial use of this patch, including but not limited to reproduction, sale, etc.
   is strictly prohibited.

- This unofficial, fan-made patch is provided "as-is" on a voluntary (i.e. non-profit) basis.
   FlamePurge is not liable for damage incurred to the end-user, their OS, or their hardware while
   using this patch.

- Apply this patch only to an Unheadered ROM with the following specifications.

   Breath of Fire (U) [!].sfc
   Unheadered
    SHA1 - B8A9E3023B92E0F4139428F6D7A9E0F9DB70F60E
     MD5 - CDEF890E99A0FB62C4D449D867C4244A
   CRC32 - C788B696

- Players are encouraged to keep a backup of their original game file in case an error occurs.

----------------------------------------------------------------------------------------------------

- Check the Addendum Patches archive to add optional features to Breath of Fire: War of the Goddess.

    * Double experience and zenny rewards.
	* Restore the original font.
    * Change menu label icons to all use text.

   First apply the primary patch, then as many addenda as desired. Read the bundled instructions for
   more info.


- The appendices are not required to play this mod, but may assist a Breath of Fire adventure
   regardless.
====================================================================================================

====================================================================================================
Overview [OVR2]
========
TEXT:

- Completely rewritten script. This is NOT a full script retranslation; see changelog.

- Revised names of characters, items, equipment, enemies, and locations based on translations from
   Breath of Fire Wiki and KWhazit Oddities.

- Revised spell names to fit later Breath of Fire games.

----------------------------------------------------------------------------------------------------

GRAPHICS:

- Restored Karn's original graphics and skin color, but removed portrait's oversized peach lips.

- Restored skin color of the four Shamans.

- Restored graphics of Tunlan NPCs, and bathing Princess of Tunlan.

- Added icons to denote equipment type and eliminate two-letter abbreviations.

- New font from Breath of Fire II: The Fated Child retranslation by Ryusui.

- (OPTIONAL ADDENDUM) Original Font: Restore the font from retail BoFI to War of the Goddess.

- (OPTIONAL ADDENDUM) Text Icons: Menu label icons use text, rather than images, to depict menu
   functions.

----------------------------------------------------------------------------------------------------

GAMEPLAY:

- Hold the Cancel Button to dash.

- Swapped locations at which Shin and Debo fusions are acquired.

- [Applied Patch] Warp Menu Fix by Landmine36
   Settlements are now unlocked in the Warp Menu in story order.
  
- [Applied Patch] Elemental Resurgence by FlamePurge
   3.5, 5.5, and 9.5 are now Crush-elemental; Bomb, Boom, Blast, Nova, and NovaX are now Projectile-
   elemental; Comet is now Shadow-elemental; and FirDgn is now Fire-elemental.

- (OPTIONAL ADDENDUM) Doubler: Doubles post-battle experience and zenny rewards. Capped at 9999, as
   in the original.
====================================================================================================

====================================================================================================
Changelog [CHG3]
=========
v1.06 (Jan 21 2024)

TEXT:

- Corrected a typo in Romero during the Cleansing Water quest.



GRAPHICS:

- Included new addendum patch that can restore the original font from the retail game.



GAMEPLAY:

- Incorporated my patch Elemental Resurgence. Now, only the thunderbolt spells are Shock-elemental.
  Earthquakes are now Crush, explosions are now Projectile, and Comet is now Shadow. Also fixes an
  error where FirDgn was Holy; now it is properly Fire.
  
  The Magic List appendix has been revised as a result.

----------------------------------------------------------------------------------------------------

v1.05 (Apr 5 2023)

TEXT:

- Corrected accidental text reversion in prologue scroll.

----------------------------------------------------------------------------------------------------

v1.04 (Jan 15 2023)

TEXT:

- Reworded text for using HrGlas. This text is displayed when using the DkKey outside Auria before
   obtaining the LtKey, so it had to be made more generic.


- Reworded the directions for going to see the strategist east of Gant.


- Added new multi-tiles to properly spell out "RaiseDead" and "LeechPower". (Credit: Justin3009)



GAMEPLAY:

- [Applied Patch] Warp Menu Fix by Landmine36
   Settlements are now unlocked in the Warp Menu in story order, rather than the strange order in
   retail.

----------------------------------------------------------------------------------------------------

v1.03 (May 15 2022)

TEXT:

- Renamed Cort to Drack, restoring Dracula reference.



GAMEPLAY:

- In prior versions, the fusion Shin could not walk through forests, while the fusion Debo could.
   This has been fixed, now replicating vanilla behavior. (Credit: Justin3009)

----------------------------------------------------------------------------------------------------

v1.02 (Mar 2 2022)

TEXT:

- Corrected a plot hole in the prologue scroll.


- Corrected narration not being in the past tense.


- Ensured checksum of patched ROM is correct.


- Included Writer's Notes.

----------------------------------------------------------------------------------------------------

v1.01 (Feb 19 2022)

TEXT:

- Fixed various typos, as well as a Nina name label.

----------------------------------------------------------------------------------------------------

v1.00 (Feb 18 2022)

TEXT:

- The script has been completely rewritten.

   This is not a retranslation; it is a rewrite of the existing official script by Ted Woolsey and
   company. The script is expanded so the story is less a stream of events and more a full-fledged
   journey, with characters both present and with presence. The manga Breath of Fire: Warrior of the
   Dragon was referenced to help nail character personalities.

   The playable cast have more speaking roles; lore from later games is introduced; unnamed
   important NPCs are named. Please do not call this a retranslation, and remember that I never
   touted it as such. This is a script rewrite.

   I was able to grab a retranslation of the scene where you "fix the old man's back," however, so
   that made it in, along with new text based on a partial retranslation of the "fortune teller."
  (Credit: Justin3009 for script expansion routine and tools)


- Names of playable/non-playable characters, items, equipment, enemies, and locations have been
   revised, based on retranslations from the Breath of Fire Wiki and KWhazit Oddities, as well as a
   few ideas from Ryusui and Myriachan's abandoned retranslation project.


- Spell names have been revised to suit the schemes of later Breath of Fire games. Care was given to
   ensure that spells nonexistent to later titles would fit in.
  (Credit: Justin3009 for fixing tile validity)


- Revised the copyright at startup to eliminate mention of Squaresoft.



GRAPHICS:

- Karn's original skin color and portrait are restored, largely to match Breath of Fire II.
   However, the large peach lips on his portrait have been edited out.
  (Credit: Justin3009 for restoring palette, decompressing portraits)


- Similarly, restored the skin color of the four men who teach Karn his fusion spells.


- Graphics for Tunlan NPCs restored.


- "Swimming" graphics for Princess of Tunlan restored.


- As GP is now zenny, restored "Z" icon for zenny storage menu.
  (Credit: Justin3009 for decompressing icons)


- Font from Ryusui's Breath of Fire II: The Fated Child inserted.


- Added gray-and-white edits of the GBA port's equipment icons, as well as a rework of the hat icon
   from the GBC version of Dragon Warrior III. No longer does equipment have those awful two-letter
   abbreviations. (Credit: Justin3009 for fixing tile validity)


- Changed the Squaresoft logo at startup to a white Capcom logo.


- Optional addendum provided to change graphics inside menu label icons to text, though still
   within the constraints of the icon. Please bear in mind the difficulty of squeezing 5- or 6-
   letter words into a 16x16 space. (Credit: Justin3009 for decompressing icons)



GAMEPLAY:

- The Cancel Button (Default: B Button) can now be held to dash. Works in towns, dungeons, world
   maps, and on the Big Fish. (Credit: Justin3009)


- Swapped the forms, names, bonuses, and graphics of Shin and Debo fusions. This effectively swaps
   the places Karn learns these: Debo is now found in Gant, and Shin is found in Gust.
  (Credit: Justin3009)


- Optional addendum provided to double the amount of experience and zenny gained after battle.
   As with the original, this is capped at a value of 9999.
====================================================================================================

====================================================================================================
Credits [CRD4]
=======
- Justin3009: Script expansion; tools; dash button; restoring Karn's palettes; decompressing
   portraits/icons; fixing validity of new font tiles; doubler addendum; swapping Shin/Debo spells;
   and being an all-around superhuman reprogrammer.
   https://www.romhacking.net/community/1574/

- Breath of Fire Wiki, KWhazit: Providing non-script translations.
   https://bof.fandom.com/wiki/Breath_of_Fire_Translations
   https://kwhazit.ucoz.net/trans/BoF1/index.html
   
- Landmine36: Warp Menu Fix.
  https://www.romhacking.net/community/7339/

- Tomato: Retranslating the massage scene Auria.
   https://legendsoflocalization.com/is-breath-of-fires-massage-scene-really-a-massage-scene/

- Caius: Partially retranslating the scene with the woman in Bleak.

- Klarth: Atlas.
   https://www.romhacking.net/utilities/224/

- RedComet: Cartographer.
   https://www.romhacking.net/utilities/647/

- Boot, Mr. Labo: Testing.

- Capcom.

...and all you Breath of Fire fans out there! We Desire Breath of Fire!
====================================================================================================