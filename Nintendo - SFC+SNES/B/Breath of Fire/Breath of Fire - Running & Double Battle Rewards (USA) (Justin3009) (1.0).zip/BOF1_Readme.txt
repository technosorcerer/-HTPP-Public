*********************************************************************************
Breath of Fire 1 (Running & Double Rewards)

Created By: Justin3009 (xJustin3009x/Shishisenkou)
*********************************************************************************
Version 1.0 - May 15th, 2022
	- Originally included in vivify93's War of the Goddess (February 2nd, 2022)
--------------------------------------------------------------------------------

Content
-------------
01. What's new?
02. Credits
03. Contact



*********************************************************************************
01. What's new?	
*********************************************************************************
This requires an unheadered Breath of Fire (USA) ROM!

01.	Two patches are included here. One with just running via the "Cancel" button and another that also doubles battle EXP and Zenny amount.



*********************************************************************************
02. Credits
*********************************************************************************
01.	vivify93 originally for including me in the project for War of the Goddess!
		a. War of the Goddess can be found at: https://www.romhacking.net/hacks/6611/




******************************************************************************
03. Contact
******************************************************************************
For more updates on this project (if they arrive) and other projects, follow me at:
Twitter: 	https://twitter.com/Justin3009

