﻿Breath of Fire Definitive Edition 




BoF1 has a lot of things that have not aged as well as the rest of the games. The goal of this hack is to bring the outdated parts up to the standard of the later games. Changes have been made to balance, gameplay, and quality of life following the formula of later games as a guideline. 




This hack features the improved script of the War of the Goddess hack, which delivers the solid coherent story this game deserves. And it brings along its B button dash feature and a full swap of Shin and Debo giving the latter some actual function.




To fit more closely to the other games most items, and equipment have not only been properly renamed, but also had their stats and properties adjusted to match the rest of the series. 


The Dragon Blade now does extra to dragons. Mist Armor, (Silver) Tiara, Divine Helm, and Ivory Bangle, now all have their appropriate resistances. Ivory Bangle can now be bought in the flea market stage 3.




The game's embarrassingly easy difficulty has been brought up to about the level of BoF4. Most of this was accomplished automatically by the changes to equipment, but also from things like removing the "weak to all elements" condition that Zog and Sarah had.




Nina has her useless spells Zom1 and Zom2 completely removed.  ZomX is now Kyrie. It's learned earlier, costs less, and will kill almost any enemy of Zombie type in the game, the same as Kyrie does in every other game.




Bleu/Deis has had her redundant spells removed (20 damage fire spell anyone?) Her learned spells have been cleaned up so everything is useful in its time and can match naming conventions established by the later games.




Dragons underwent a small change, the 3 Whelps all do 125 damage of their corresponding type for 12 ap.
The 4 Dragons all do 250 damage of their corresponding type,  including Holy which now affects all enemy types. Fire dragon had the wrong element it has been fixed from holy/water to fire.
Rudra/Kaiser does 375 damage for 40 ap
Agni/Infinity does the same damage but can now do proper critical hits. It's use is restricted by its huge 100 AP cost. Making it only usable very end game, or through grinding.




Puka also has an increased AP cost making it usable only later and giving Doof more use.




Once you have at least 4 party members the battle formation is changed to the BoF2 default formation.




2 cut items re-added the thief arm which improves drop rates and the Coach which can be equipped by Ox, it has a unique graphical effect and grants auto run (provided Ox is party leader) both are sold in Prima.




Bo/Gary can now equip glove items as shields. 




Damage cap increased, stat caps increased.




New exp table allows nice consistent leveling throughout the whole game. Stat gains have been spread out significantly to compensate.




The flea market now has powerful items in all 3 stages, but only stage 3 has ultimate weapons. 




                 Ultimate weapons
Ryu: Gooking sword 180 attack found in flea market. Alternate Tri-Rang 150 to all enemies found behind the Pogoda.




Nina: Nothung 122 holy damage found in flea market.




Gary: Hero bow 220 damage found in dig spot near Tock.




Karn: Holy Avenger 125 holy damage found in flea market.




Gobi: Dragon spear 110 damage (extra to dragons) flea market.




Ox: Mallet 255 damage. Flea market. 




Deis: Ouroboros 92 damage flea market.




Exalt spell is now much more useful. 


Prima can now be warped to at the expense of Arad.



Version 1.2 changes.

All text errors with wrong names should be fixed.

Karn starting AP increased for earlier Puka.

Deis leveling should be fixed.

many more names now match the later games.

the huge damage jumps from story triggers are much more stable.

Ivory Charm now resists Death and elemental damage like in 3 (only works in the right slot for now)

bonus just for fun item in final dungeon grants characters a super form when used in battle.

