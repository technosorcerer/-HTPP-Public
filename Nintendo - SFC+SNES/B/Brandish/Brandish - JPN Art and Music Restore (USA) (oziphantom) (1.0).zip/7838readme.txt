Brandish SNES
-------------

This patch will restore the changed graphics in the Western release and put the Japanese versions back. 
It also restores the original openning that was removed in the Western and Renewal versions. 

It does not change any of the text or the KOEI logo.
I have not tested it but I believe that the name restore patch https://www.romhacking.net/hacks/608/ should be compatible with this patch to fix the names.

This is a rather straight forward patch, I have tested the game with both good and bad ending and didn't notice any issues.

If you find an issues please report them at https://www.romhacking.net/forum/index.php?topic=37136.0

I also have a LUA script which greatly improves the control scheme by giving you an Amiga Keyboard control scheme. I used it for testing and it greatly improved my ability to move and fight.