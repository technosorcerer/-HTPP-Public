Tradu��o em portugu�s do Brasil de Mario Kart 7 3DS v1.04.
Essa tradu��o � uma retradu��o da antiga tradu��o do autor NinjaTR.

Tradu��o PT-BR por NinjaTR
Retradu��o dos textos e edi��o gr�fica por ajkmetiuk

Vers�o 1.01: Como j� se passou um ano, no Mario Kart Tour foram adicionados praticamente todo conte�do do MK7 em PT-BR, acho que 95% j� foi localizado, ent�o adicionei o que ficou faltando no nome dos carros e pistas. Caso eles adicionem o que falta futuramente, eu fa�o outro patch.
Vers�o 1.02: Alterado mais nomes de pistas e carros de acordo com a tradu��o oficial brasileira do Mario Kart Tour.
Vers�o 1.03: Mais alguns nomes de pistas e carros de acordo com a tradu��o oficial.
Novidades da vers�o 1.04: Adicionado compatibilidade com o patch 1.2.

Todos os direitos reservados a Nintendo.

------------------------------------------------------------------------------
Requisitos para instalar a tradu��o:
------------------------------------------------------------------------------
- Um Nintendo 3DS com a custom Firmware Luma3DS + boot9strap (mais informa��es em:
https://3ds.guide/ e https://github.com/AuroraWright/Luma3DS/wiki).
- O jogo Mario Kart 7 instalado no seu 3DS.

------------------------------------------------------------------------------
Instala��o(s� � necess�rio ser feita uma vez):
------------------------------------------------------------------------------
- Extraia a pasta luma que veio neste arquivo para raiz do cart�o SD do seu 3DS.
- Mescle todas as pastas. 
- Coloque o cart�o SD de volta no seu 3DS e ligue-o segurando o bot�o "Select"
- Marque a op��o "Enable game patching" no menu do Luma3DS.
- Aperte "Start" para salvar.
- Agora � s� esperar seu 3DS ligar para iniciar o jogo.

------------------------------------------------------------------------------------
Passo exclusivo somente se quiser jogar a tradu��o com o �ltimo patch 1.2 lan�ado:
------------------------------------------------------------------------------------
Al�m dos passos acima, a vers�o 1.2 tamb�m precisa desse passo extra, sen�o os textos n�o ficar�o traduzidos.
(A vers�o 1.2 � mais para quem quiser acessar os modos online do jogo, portanto, opcional.)

Aplicando a tradu��o no .cia: com a atualiza��o do jogo em m�os no formato .cia, baixe a ferramenta HackingToolkit9DS (pode ser encontrada no site oficial: https://github.com/Asia81/HackingToolkit9DS/releases)
Utilize a vers�o que funcionar com seu .cia (usei a �ltima vers�o). Abra primeiro o SetupUS.exe e depois o HackingToolkit9DS.exe.
Na tela que aparece, digite CE e em seguida o nome da imagem (sem extens�o).
*Caso a ferramenta n�o extraia sua imagem do jogo, tente baixar vers�es mais antigas que provavelmente ir�o extrair com sucesso seu arquivo.
Com a imagem extra�da, abra a pasta ExtractedRomFS, cole e substitua todos arquivos da pasta Patch que acompanham a tradu��o.
Volte ao HackingToolkit9DS.exe e agora digite CR. Coloque o nome da imagem (exemplo: SMK1.2_BR), em seguida 0 e novamente 0.
Pronto! Agora sua atualiza��o estar� traduzida...
Passe o .cia da atualiza��o para seu 3DS, instale e pronto. O mesmo ir� dizer quando voc� entrar no jogo que h� uma atualiza��o dispon�vel, � s�
ignorar e jogar normalmente.

Encontrou algum erro?
Acesse o FURT para report�-lo.
http://www.romhacking.net.br/index.php