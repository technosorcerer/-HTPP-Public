Tradu��o em portugu�s do Brasil de Mario Kart 7 3DS v1.02.
Essa tradu��o � uma retradu��o da antiga tradu��o do autor NinjaTR.

Tradu��o PT-BR por NinjaTR
Retradu��o dos textos e edi��o gr�fica por ajkmetiuk

Novidades da vers�o 1.02: Alterado mais nomes de pistas e carros de acordo com a tradu��o oficial brasileira do Mario Kart Tour.

Todos os direitos reservados a Nintendo.

------------------------------------------------------------------------------
Requisitos para instalar a tradu��o:
------------------------------------------------------------------------------
- Um Nintendo 3DS com a custom Firmware Luma3DS + boot9strap (mais informa��es em:
https://3ds.guide/ e https://github.com/AuroraWright/Luma3DS/wiki).
- O jogo Mario Kart 7 instalado no seu 3DS.

------------------------------------------------------------------------------
Instala��o(s� � necess�rio ser feita uma vez):
------------------------------------------------------------------------------
- Extraia a pasta luma que veio neste arquivo para raiz do cart�o SD do seu 3DS.
- Mescle todas as pastas. 
- Coloque o cart�o SD de volta no seu 3DS e ligue-o segurando o bot�o "Select"
- Marque a op��o "Enable game patching" no menu do Luma3DS.
- Aperte "Start" para salvar.
- Agora � s� esperar seu 3DS ligar para iniciar o jogo.

Encontrou algum erro?
Acesse o FURT para report�-lo.
http://www.romhacking.net.br/index.php