Metroid - Samus Returns (Japan)
00040000001BFC00
CTR-P-A9AJ

PB汉化组
2019-03-16

https://www.pbteam.cn/metroid-samus-returns
https://github.com/TeamPBCN/Metroid-Samus-Returns/releases


【汉化说明】
正在看帖子的各位，好久不见！ 今天是一个特别的日子，是属于女士们的节日， 因此今天我们为大家带来一款以女性为主角的 游戏的汉化版，想必大家都对这位游戏史上 鼎鼎大名的女性非常熟悉了，她就是 ——萨姆斯·艾仁。

今天为大家带来的是去年发售的系列第二部作品的重制版： 《密特罗德：萨姆斯回归》。 这部作品容量不大，但是麻雀虽小五脏俱全， 从精妙的地图和谜题设计，到扣人心弦的Boss战斗， 无不饱含着系列的精髓。

【汉化人员】
翻译：JonirRings，凉凉
校对&润色：JonirRings，拉普达，墨白
美工：凉凉
程序：LITTOMA
测试：JonirRings，螳螂虾，拉普达，墨白

【v1.1 修改说明】
修复 补丁生成的 CIA 无法正常游戏的问题。