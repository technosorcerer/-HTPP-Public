Metroid: Samus Returns PL
Wersja 1.0

Spolszczenie dzia�a z odszyfrowan� europejsk� wersj� gry:
Metroid - Samus Returns (Europe) Decrypted.3ds
CTR-A9AP
00040000001BFB00

S� dwie metody zainstalowania t�umaczenia: podmiana plik�w w locie lub na�o�enie �atki.

Metoda nr 1 (podmiana plik�w w locie):

1. Uruchom emulator Citra.
2. Kliknij prawym przyciskiem myszy na ROM gry i wybierz "Open Mods Location".
3. Wy�wietli si� okno folderu "00040000001BFB00", skopiuj do niego folder "romfs".

Metoda nr 2 (na�o�enie �atki):

1. Uruchom xdelta UI (program mo�na pobra� z: https://www.romhacking.net/utilities/598/).
2. W pierwszym oknie (Patch) wybierz �atk� spolszczaj�c� (metroid3dspl.xdelta).
3. W drugim oknie (Source File) wybierz ROM z gr�.
4. W trzecim oknie (Output File) wpisz nazw� wraz z rozszerzeniem (np. MetroidPL.3ds) i kliknij "Patch".
5. Je�li wszystko zosta�o dobrze zrobione, pojawi si� komunikat, �e �atka zosta�a na�o�ona.

Spolszczenie dzia�a r�wnie� na przerobionej konsoli z zainstalowanym Luma3DS i boot9strap.
Wi�cej informacji znajdziesz na: https://gist.github.com/PixelSergey/5dbb4a9b90d290736353fa58e4fcbb42