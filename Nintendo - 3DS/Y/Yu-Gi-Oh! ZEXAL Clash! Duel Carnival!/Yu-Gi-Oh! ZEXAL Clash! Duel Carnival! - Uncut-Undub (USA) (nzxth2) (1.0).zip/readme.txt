Yu-Gi-Oh! ZEXAL World Duel Carnival
Uncut/Undub Patch
Nintendo 3DS

This patch aims to restore the cut content from the localized releases of Yu-Gi-Oh! ZEXAL World Duel Carnival by fully translating the original Japanese release into English. In other words, the patch requires the Japanese version of the game, known as Yu-Gi-Oh! ZEXAL Clash! Duel Carnival!.

All 41 character stories are playable in this version, as opposed to only 12 in the localized releases.

The tools used to edit the game files have also been made available on GitHub:
https://github.com/nzxth2/ygo3ds-text

Emulators as well as real (homebrew-enabled) hardware are both supported through LayeredFS game patching.

When playing on console, make sure you're running Luma3DS CFW and follow any of these guides:
https://wiki.hacks.guide/wiki/3DS:Game_modification#Patching_using_LayeredFS
https://gist.github.com/PixelSergey/5dbb4a9b90d290736353fa58e4fcbb42#enabling-luma-layeredfs-game-patching

Or in short, copy the 00040000000F6C00 folder to /luma/titles/ on your SD card and enable Game Patching in the Luma configuration menu (accessible by holding Select while booting the console).

For emulators, open the emulator folder (there should be a menu entry in the emulator that directly takes you there). Copy the 00040000000F6C00 folder to /load/mods/ (you can just create the folders yourself if they don't exist yet).

For the Present Code system, the Japanese characters were removed from all present codes leaving only the numbers, which can be easily entered on real hardware. Here's a complete list of all present codes that can be entered:

560125: Unlocks "Holactie the Creator of Light" for the player character only
766240: Unlocks "Ninja Grandmaster Hanzo", "Upstart Golden Ninja", "White Dragon Ninja" and "Ninjitsu Art of Super-Transformation" for all characters
488140: Unlocks "Night Beam", "Dust Tornado" and "Malevolent Catastrophe" for all characters
390076: Unlocks "Instant Fusion", "Zombie Warrior", "Karbonala Warrior" and "Musician King" for all characters
049881: Unlocks "Dark Bribe", "Divine Wrath", "Seven Tools of the Bandit" and "Van'Dalgyon the Dark Dragon Lord" for all characters
530076: Unlocks 6 Deck Recipes based on Charisma Duelists
863219: Unlocks "Effect Veiler", "Battle Fader", "Maxx "C"", "D.D. Crow", "Swift Scarecrow" and "Droll & Lock Bird" for all characters
196523: Unlocks "Tour Guide From the Underworld", "Crane Crane", "Card Trooper" and "Ghostrick Alucard" for all characters
481107: Unlocks "Marshmallon", "Spirit Reaper", "Arcana Force 0 - The Fool" and "Slacker Magician" for all characters
787031: Unlocks "Number 50: Blackship of Corn", "Maestroke the Symphony Djinn", "Wind-Up Zenmaines", "Number 17: Leviathan Dragon", "Number 61: Volcasaurus" and "Gaia Dragon, the Thunder Charger" for all characters
799138: Unlocks "Traptrix Nepenthes", "Traptrix Myrmeleo", "Traptrix Atrax", "Traptrix Trap Hole Nightmare" and "Void Trap Hole" for all characters
119180: Unlocks "Black Luster Soldier - Envoy of the Beginning", "Chaos Sorcerer" and "Black Luster Soldier - Envoy of the Evening Twilight" for all characters
834998: Unlocks "Photon Thrasher", "Goblindbergh", "Heroic Challenger - Extra Sword", "Summoner Monk" and "Blade Armor Ninja" for all characters
392831: Unlocks "Kachi Kochi Dragon", "Mecha Phantom Beast Dracossack", "Daigusto Emeral", "Divine Dragon Knight Felgrand", "Number 91: Thunder Spark Dragon" and "Hieratic Sun Dragon Overlord of Heliopolis" for all characters
631737: Unlocks "King of the Feral Imps" and "Kagetokage" for all characters
883614: Unlocks "Tragoedia", "Swordsman of Revealing Light", and "Gorz the Emissary of Darkness" for all characters
138478: Unlocks "Evilswarm Ouroboros", "Diamond Dire Wolf", "Gem-Knight Pearl", "Gagaga Cowboy", "Tiras, Keeper of Genesis" and "Number 11: Big Eye" for all characters
8319: Unlocks the Chibi Yuma Tsukumo Card Protector
5488: Unlocks the Chibi Kotori Mizuki Card Protector
9041: Unlocks the Chibi Kaito Tenjo Card Protector
3261: Unlocks the Chibi Ryoga Kamishiro Card Protector
4299: Unlocks the Chibi Tetsuo Takeda Card Protector
3754: Unlocks the Chibi Anna Kozuki Card Protector
3405: Unlocks the Chibi III Card Protector
5804: Unlocks the Chibi Number 32: Shark Drake Card Protector
8276: Unlocks the Chibi Constellar Ptolemy M7 Card Protector
7382: Unlocks the Chibi Evilswarm Ouroboros Card Protector
0611: Unlocks the Chibi Hieratic Sun Dragon Overlord of Heliopolis Card Protector
9487: Unlocks the Chibi High Priestess of Prophecy Card Protector
1396: Unlocks the Chibi Madolche Puddingcess Card Protector
7569: Unlocks the Chibi Mermail Abysslinde Card Protector
7105: Unlocks the Chibi Number 96: Dark Mist Card Protector
6982: Unlocks the Chibi Exodia the Forbidden One Card Protector
8581: Unlocks the Chibi Submersible Carrier Aero Shark Card Protector
3676: Unlocks the Chibi Number 61: Volcasaurus Card Protector
9672: Unlocks the Chibi Gagaga Magician Card Protector
6374: Unlocks the Chibi Gagaga Girl Card Protector
7876: Unlocks the Chibi Galaxy-Eyes Photon Dragon Card Protector
4025: Unlocks the Chibi Cyber Dragon Card Protector
1593: Unlocks the Chibi Blue-Eyes White Dragon Card Protector
2561: Unlocks the Chibi Dark Magician Card Protector
7413: Unlocks the Chibi Number 39: Utopia Card Protector
6041: Unlocks the Chibi Number C39: Utopia Ray Card Protector
9816: Unlocks the Chibi Melomelody the Brass Djinn Card Protector
3560: Unlocks the Chibi Ryko, Lightsworn Hunter Card Protector
7621: Unlocks the Chibi Number 17: Leviathan Dragon Card Protector
2197: Unlocks the Chibi Dark Magician Girl Card Protector
7118: Unlocks the Chibi Brotherhood of the Fire Fist - Tiger King Card Protector
5598: Unlocks the Chibi Mecha Phantom Beast Dracossack Card Protector
3802: Unlocks the Chibi Bujintei Susanowo Card Protector
0815: Unlocks the Chibi Rescue Rabbit Card Protector
2807: Unlocks the Chibi Gorz the Emissary of Darkness Card Protector
824696: Unlocks the Chibi Yuma/Ryoga/Kaito Duel Field
282440: Unlocks the Chibi Kotori/Anna Duel Field
792359: Unlocks an alternative Forbidden/Limited List with all cards Unlimited
679270: Unlocks "Obelisk the Tormentor", "Slifer the Sky Dragon" and "The Winged Dragon of Ra" for the player character only
520463: Unlocks the "Basic Lightsworn" Deck Recipe, and unlocks its cards for all characters; unlocks the "Judgment Dragon" Duel Field and Card Protector
812296: Unlocks the "Basic Machine-Gear" Deck Recipe, and unlocks its cards for all characters; unlocks the "Gear Gigant X" Duel Field and Card Protector
096331: Unlocks the "Runaway Express in Love" Deck Recipe, and unlocks its cards for all characters
6111: Unlocks the "Xyz Orchestra" Deck Recipe, and unlocks its cards for all characters
5505: Unlocks the "Outlaw's Kingdom" Deck Recipe, and unlocks its cards for all characters
7005: Unlocks the "Photons Guide Through the Vortex of Fate" Deck Recipe, and unlocks its cards for all characters