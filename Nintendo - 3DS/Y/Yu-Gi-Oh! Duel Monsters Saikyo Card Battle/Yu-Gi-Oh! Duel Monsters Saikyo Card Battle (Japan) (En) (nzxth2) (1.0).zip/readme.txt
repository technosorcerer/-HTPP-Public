Yu-Gi-Oh! Duel Monsters Saikyo Card Battle
English Translation Patch
Nintendo 3DS

The game is fully translated and playable.

The tools used to edit the game files have also been made available on GitHub:
https://github.com/nzxth2/ygo3ds-text

Emulators as well as real (homebrew-enabled) hardware are both supported through LayeredFS game patching.

When playing on console, make sure you're running Luma3DS CFW and follow any of these guides:
https://wiki.hacks.guide/wiki/3DS:Game_modification#Patching_using_LayeredFS
https://gist.github.com/PixelSergey/5dbb4a9b90d290736353fa58e4fcbb42#enabling-luma-layeredfs-game-patching

Or in short, copy the 0004000000188500 folder to /luma/titles/ on your SD card and enable Game Patching in the Luma configuration menu (accessible by holding Select while booting the console).

For emulators, open the emulator folder (there should be a menu entry in the emulator that directly takes you there). Copy the 0004000000188500 folder to /load/mods/ (you can just create the folders yourself if they don't exist yet).