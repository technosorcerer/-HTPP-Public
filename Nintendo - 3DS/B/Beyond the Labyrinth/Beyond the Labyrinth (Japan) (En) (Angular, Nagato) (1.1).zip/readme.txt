***Update 30-5-2025***
The information about how to fix missing names on a modded 3DS is outdated in this ReadMe. Follow these steps instead: 

- Before you start playing copy the folder 0004000000065C00 (with the file locale.txt in it) on your SD card to /luma/title/ . 

- Make sure "game patching" is turned on in the settings of Luma.

- Reboot your 3DS.

- Start the game and choose "New Game".

- Enjoy! And huge thanks to Nagato, Angular for this translation!

Ok Impala!

-------

Beyond the Labyrinth English Translation
Version: 1.1
Release Date: September 14th, 2015

Note:
All text should be translated. The last 500 or so untranslated lines were really rough as they did not have any context at all. As much as I would have liked to translate everything perfectly, with the way the scripts are setup, it's impossible for me to figure out what some of the lines were in reference to, so I tried to translate them to the best of my ability. If there are any lines that don't make sense in context, please report it and let me know what the conversation surrounding it is and I will be more than happy to correct it. The main story text should for the most part be fine.



Changelog:
PBT v0.1: Initial release
PBT v0.2: Fixed crash when reading tablet in later stage. More translated text.
PBT v0.3: Translated a lot more chatter text compared to PBT v0.2.
v1.0: All text translated.
v1.1: Some text fixes.



Patching:
1) Open xdeltaUI.exe
2) Select ENG_Beyond_the_Labyrinth.xdelta for the "Patch" field
3) Select "Labyrinth no Kanata.3ds" for the "Source File" field
4) Select a file to save the patched ROM to

Labyrinth no Kanata.3ds must match SHA-1 3EC609A8D0307CEB2DAF5982437E449C7188FCCE



Bug reports:
Please direct any bug reports to the thread on GBATemp:
http://gbatemp.net/threads/translation-labyrinth-no-kanata-beyond-the-labyrinth.379598/



Known bugs/issues:
- Character names sometimes won't appear depending on your method of launching the game.
Gateway 3DS doesn't seem to have any issues in both 3DS and CIA formats, but other methods (rxTools, Pasta, etc) all have been reported to have issues with displaying character names. The only known fix at the moment is to use a Gateway 3DS. As a workaround, please follow the instructions in nongw_name_savedata_fix\readme.txt The included save file will start you with a character named "Evo" at the first checkpoint. This method should only be used once you reach the first checkpoint since it will skip the beginning of the game!
* NOTE: I've gotten a report that the latest version of NTR CFW (3.0) works when using plugins to set the region to Japanese or something like that.

- The game defaults to Japanese on the character name input screen. Click "ABC" to get the English alphabet.

- Some of the letters on the Japanese character name input screen are replaced with letters from the English alphabet. This is a workaround for NPC character names, so it will not be fixed for now.

- The words "GAME OVER" are really large when you die. I do not know the cause of this.



Credits:
Translation: Nagato, Angular
Hacking/Programming: Nagato
Graphics: Vodka
Testers: gamesquest1, sarkwalvein, Shadowtrance
Special Thanks: Gericom (Etc1A4 code from EveryFileExplorer), Normmatt, Ambassador