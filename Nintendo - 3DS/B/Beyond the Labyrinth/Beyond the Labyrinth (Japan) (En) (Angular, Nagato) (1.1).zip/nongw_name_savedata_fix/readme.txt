CFW save fix guide (WARNING! THIS WILL REPLACE YOUR SAVE WITH A DEFAULT SAVE AT THE FIRST CHECKPOINT) 

1. Copy all the files in this folder to your 3DS SD card
2. Install BootNTR.cia via your chosen CIA installer
3. Boot into NTR by choosing it from the home screen
4. Load Beyond the Labyrinth while holding R to import the fixed save