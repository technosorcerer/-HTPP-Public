Tradu��o de Super Mario Maker para Nintendo 3DS v1.01

Um pouco sobre o jogo: 

Super Mario Maker � um jogo eletr�nico de plataforma desenvolvido pela Nintendo para o console Wii U, lan�ado em setembro de 2015.
No jogo, pode-se criar e jogar est�gios customizados baseados nos t�tulos Super Mario Bros., Super Mario Bros. 3, Super Mario World e New Super Mario Bros.
O jogo foi adaptado para o Nintendo 3DS, conhecido como Super Mario Maker for Nintendo 3DS, que foi lan�ado em Dezembro de 2016. 

Progresso:

Gr�ficos: 100%
Textos: 100%
Acentos: 100%
Menus: 100%
Cr�ditos: 100%

v1.01 - Atualizado a tradu��o para funcionar na �ltima vers�o 1.05.


Como usar:

Primeiro de tudo, mude o idioma do seu port�til/emulador para Espanhol. N�o sei o porque, mas se deixar em outros idiomas como ingl�s/portugu�s algumas coisas ficar�o sem tradu��o.

Segundo, n�o aconselho usar a tradu��o pelo Luma3DS porque o jogo n�o � compat�vel com o sistema de patch oferecido. Como fica muita coisa sem tradu��o, s� vou explicar o m�todo
inserindo diretamente no .cia/.3ds do jogo.

Terceiro, o pacote da tradu��o vem com a tradu��o para a vers�o 1.0 do jogo e a vers�o 1.05. A vers�o 1.0 voc� aplica diretamente na rom do jogo e a vers�o 1.05 � aplicada no update
do jogo, geralmente voc� ir� encontrar como 3MM Update 1.05 USA ou 3MM Update 1.05 EUR. (A vers�o 1.05 � mais para quem quiser acessar os modos online do jogo, portanto, opcional.)


Aplicando no .cia/.3ds: com a imagem do jogo em m�os, baixe a ferramenta HackingToolkit9DS (pode ser encontrada no site oficial: https://github.com/Asia81/HackingToolkit9DS/releases)
Utilize a vers�o que funcionar com sua imagem. Abra primeiro o SetupUS.exe e depois o HackingToolkit9DS.exe.
Se a sua imagem for .cia, digite CE e em seguida o nome da imagem (sem extens�o). Se for .3ds digite D e em seguida o nome da imagem (sem extens�o)
*Caso a ferramenta n�o extraia sua imagem do jogo, tente baixar vers�es mais antigas que provavelmente ir�o extrair com sucesso seu arquivo.
Com a imagem extra�da, abra a pasta ExtractedRomFS, cole e substitua todos arquivos da pasta romfs que acompanham a tradu��o.
Volte ao HackingToolkit9DS.exe e agora selecione R para .3ds ou CR para .cia. Coloque o nome da imagem (exemplo: SMMP3DS_BR), em seguida 0 e novamente 0.
Pronto! Agora sua imagem estar� traduzida... (siga o mesmo processo para aplicar a tradu��o no update 1.05 do jogo.)
Caso tenha aplicado a tradu��o no update, instale primeiro o .cia do jogo e depois o update. O mesmo ir� dizer quando voc� entrar no jogo que h� uma atualiza��o dispon�vel, � s�
ignorar e jogar normalmente.

Tradu��o/ROMHacking: ajkmetiuk

Agradecimentos especiais:
Obrigado � todos do FURT que de alguma maneira ajudaram na tradu��o com dicas nos di�logos, gr�ficos, sugest�es de nomes para inimigos, tools para extrair, etc. Vlw!!!

Contato:

ajkmetiuk@bol.com.br
Caso encontre algum bug, n�o deixe de enviar seu feedback que quando poss�vel irei verificar e corrigir os erros e assim lan�o futuras vers�es...
