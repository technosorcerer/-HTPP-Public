Tradu��o de New Super Mario Bros. 2 para 3DS

Um pouco sobre o jogo: 
Seguindo o mesmo estilo de jogabilidade de New Super Mario Bros. e New Super Mario Bros. Wii, o jogo tem uma meta de coletar o maior n�mero de moedas poss�vel e � o 2� jogo da s�rie e o 1� para port�til a apresentar 2 modos
de multiplayer: competitivo e coopoerativo pois � poss�vel jogar com mario e luigi (com 2 jogadores jogando juntos no modo hist�ria como o New Super Mario Bros. Wii).

Progresso:
 
Gr�ficos: 100%
Textos: 100%
Menus: 100%

v1.1: Depois de me familiarizar melhor como funciona os arquivos do 3DS consegui traduzir algumas coisas "extras", como a tela t�tulo e a tela final do jogo, os cr�ditos finais e adaptado alguns textos conforme as edi��es que fiz.
v1.2: Tela t�tulo traduzida pelo BMatSantos + alterado os textos que mencionavam Bros.

Como aplicar a tradu��o:

H� duas formas de usar a tradu��o: Pelo Luma3DS ou aplicando diretamente no .cia/.3ds do jogo (compat�vel com emuladores)

Pelo Luma3DS: voc� vai precisar de um Nintendo 3DS desbloqueado com a CFW Luma3DS, o jogo original ou o jogo instalado em seu 3DS. (Os procedimentos ser�o feitos uma �nica vez)

Primeiro passo: ligue seu 3DS segurando o bot�o SELECT. Na tela que ir� aparecer, marque a op��o Enable game patching e pressione START para salvar.
Segundo passo: com seu 3DS desligado, remova o cart�o SD de seu 3DS e copie a pasta luma na raiz de seu cart�o SD (substitua todos os arquivos)
Agora � s� inserir o cart�o SD em seu 3DS e jogar...

Aplicando no .cia/.3ds: com a imagem do jogo em m�os, baixe a ferramenta HackingToolkit9DS (pode ser encontrada no site oficial: https://github.com/Asia81/HackingToolkit9DS/releases)
Abra primeiro o SetupUS.exe e depois o HackingToolkit9DS.exe.
Se a sua imagem for .cia, digite CE e em seguida o nome da imagem (sem extens�o). Se for .3ds digite D e em seguida o nome da imagem (sem extens�o)
*Caso a ferramenta n�o extraia sua imagem do jogo, tente baixar vers�es mais antigas que provavelmente ir�o extrair com sucesso seu arquivo.
Com a imagem extra�da, abra a pasta ExtractedRomFS, cole e substitua todos arquivos da pasta romfs que acompanham a tradu��o.
Volte ao HackingToolkit9DS.exe e agora selecione R para .3ds ou CR para .cia. Coloque o nome da imagem (exemplo: NSMB2_BR), em seguida 0 e novamente 0.
Pronto! Agora sua imagem estar� traduzida...

*A tradu��o � compat�vel tamb�m com as vers�es EUR e JAP, bastando s� alterar o titleID da pasta e o idioma para:
JPN: 000400000007AD00 e romfs\Message\JP_Japanese
EUR: 000400000007AF00 e romfs\Message\EU_English
US:  000400000007AE00 e romfs\Message\US_English

Tradu��o/ROMHacking: ajkmetiuk
Tela t�tulo: BMatSantos

Contato:

ajkmetiuk@bol.com.br
Caso encontre algum bug, n�o deixe de enviar seu feedback que quando poss�vel irei verificar e corrigir os erros e assim lan�o futuras vers�es...
