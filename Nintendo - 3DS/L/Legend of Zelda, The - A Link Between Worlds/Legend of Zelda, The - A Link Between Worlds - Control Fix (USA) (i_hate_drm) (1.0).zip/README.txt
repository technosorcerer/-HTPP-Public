README

A hack to make Link's directional movement closer match your input.

In ALBW, Link's directional movement is off by 5 degrees.

Pressing up will make him walk up, and slightly left.

This hack sets this adjustment factor to zero.

This hack is compatible with a .3ds USA ROM of A Link Between Worlds.

You can apply this patch using Lunar IPS.


DOCUMENTATION

Address		   Old Value		     New Value
5CA8E8 to 5CA8EF | 05 A9 96 3D C5 50 C8 3C | 00 00 00 00 00 00 00 00 // Fix Down
5CACF0 to 5CACF7 | 05 A9 96 BD C5 50 C8 BC | 00 00 00 00 00 00 00 00 // Fix Right
5CB0E8 to 5CB0EF | 05 A9 96 BD C5 50 C8 BC | 00 00 00 00 00 00 00 00 // Fix Up
5CB4F0 to 5CB4F7 | 05 A9 96 3D C5 50 C8 3C | 00 00 00 00 00 00 00 00 // Fix Left