The Legend of Zelda: A Link Between Worlds PL
Wersja 1.0
________________________________________________________________

Spis tre�ci:

1. Wst�p
2. Instalacja spolszczenia
3. Autorzy
________________________________________________________________

1. Wst�p

A Link Between Worlds to sequel do wydanego na Super Nintendo A Link to the Past. W grze wcielany si� Linka, kt�ry dzi�ki zdolno�ci ��czenia si� ze �cianami, pr�buje pokona� nowego wroga Hyrule jakim jest Yuga i odkry� tajemnice zrujnowanego kr�lestwa Lorule. Ponadto gra oferuje system wypo�yczania przedmiot�w oraz przechodzenie loch�w w dowolnej kolejno�ci.
________________________________________________________________

2. Instalacja spolszczenia

Spolszczenie zadzia�a z europejsk� wersj� gry. S� dwie metody zainstalowania t�umaczenia: podmiana plik�w lub na�o�enie �atki.

Metoda 1. (podmiana plik�w):

1. Uruchom emulator Citra.
2. Kliknij prawym przyciskiem myszy na ROM gry i wybierz "Open Mods Location".
3. Wy�wietli si� okno folderu "00040000000EC400", skopiuj do niego folder "romfs".

Metoda 2. (�atka):

1. Uruchom xdelta UI.
2. W pierwszym oknie (Patch) wybierz �atk� spolszczaj�c� (albwpl.xdelta).
3. W drugim oknie (Source File) wybierz ROM z gr�.
4. W trzecim oknie (Output File) wpisz nazw� wraz z rozszerzeniem (np. ZeldaPL.3ds) i kliknij "Patch".
5. Je�li wszystko zosta�o dobrze zrobione, pojawi si� komunikat, �e �atka zosta�a na�o�ona.
________________________________________________________________

3. Autorzy

T�umaczenie oraz testowanie polonizacji:

- Voxar

U�yte Programy:

- Citra (testowanie spolszczenia i dump folderu "romfs")
- Karameru (rozpakowywanie plik�w tekstowych)
- Kuriimu (edycja plik�w tekstowych)