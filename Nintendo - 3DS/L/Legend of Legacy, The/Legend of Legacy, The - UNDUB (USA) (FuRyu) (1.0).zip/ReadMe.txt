### Patching the game:
Place a CIA, 3DS, or CCI file alongside this txt,
then simply drag and drop it onto the
"PatchIt! - Drag and drop a CIA or 3DS here.bat" batch file.
Both the encrypted and decrypted input files are supported.
You'll be prompted to input the desired options after
the batch will launch.

### LayeredFS patch:
Navigate into the directory \data and execute the
"Prepare a LayeredFS patch.bat" batch file,
then input the desired options when prompted.
Or you can just manually place the contents of the
directories that you need onto your 3DS's memory card:
...\luma\titles\[Title ID of the game]\

### NOTE: In case this needs to be spelled out, these batches
won't work on Linux & macOS. Sorry about that. If you're not
using Windows, you'll have to do this stuff manually.