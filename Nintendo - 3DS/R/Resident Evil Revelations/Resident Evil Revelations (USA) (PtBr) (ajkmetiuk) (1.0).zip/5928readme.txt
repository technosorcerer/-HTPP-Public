Tradu��o em portugu�s do Brasil de Resident Evil: Revelations vers�o 3DS.
Essa tradu��o � um port das tradu��es das vers�es de PS3/PC/X360.

Tradu��o portada por djmatheusito
Revis�o dos textos e edi��o gr�fica (do que faltou) por ajkmetiuk
Edi��o da tela-t�tulo por Sliter

Todos os direitos reservados a Capcom.

Encontrou algum erro?
Acesse o FURT para report�-lo.
http://www.romhacking.net.br/index.php

------------------------------------------------------------------------------
Requisitos para instalar a tradu��o:
------------------------------------------------------------------------------
- Um Nintendo 3DS com a custom Firmware Luma3DS + boot9strap (mais informa��es em:
https://3ds.guide/ e https://github.com/AuroraWright/Luma3DS/wiki).
- O jogo Resident Evil: Revelations instalado no seu 3DS.

------------------------------------------------------------------------------
Instala��o(s� � necess�rio ser feita uma vez):
------------------------------------------------------------------------------
- Extraia a pasta luma que veio neste arquivo para raiz do cart�o SD do seu 3DS.
- Mescle todas as pastas. 
- Coloque o cart�o SD de volta no seu 3DS e ligue-o segurando o bot�o "Select"
- Marque a op��o "Enable game patching" no menu do Luma3DS.
- Aperte "Start" para salvar.
- Agora � s� esperar seu 3DS ligar para iniciar o jogo.

------------------------------------------------------------------------------
Extra (caso prefira o t�tulo Biohazard e for jogar com �udio japon�s)
------------------------------------------------------------------------------
Quando voc� seleciona o �udio para "Japon�s" o jogo originalmente altera
somente o �udio quando voc� est� no jogo, mas a tela t�tulo e o �udio permanece
"Resident Evil", e nos v�deos ir� dizer "Biohazard" mas nas legendas aparece
"Resident Evil". Para corrigir isso foi criado um patch separado para quem quiser
t�tulo + �udio do t�tulo + legendas corrigidas para o �udio Japon�s, assim ser� 
pronunciado corretamente e tamb�m mostrado de forma correta todas cenas e v�deos
ao decorrer do jogo "Biohazard". Para aplicar:

- Fa�a o processo de instalar a tradu��o como mencionado l� em cima. 
- Inicie o jogo. Selecione a tela de Op��es/Idioma/Voz e selecione Japon�s.
- Volte para tela principal (para salvar as altera��es) e saia do jogo.
- Extraia a pasta Extra que veio neste arquivo, abra ela e copie a pasta
luma para a raiz do cart�o SD do seu 3DS e substitua todos arquivos.
- Pronto! Agora � s� iniciar o jogo...

------------------------------------------------------------------------------
Agradecimentos especiais ao djmatheusito que portou toda tradu��o e permitiu
que eu revisasse e editasse o que faltava e ao Sliter que editou a tela-t�tulo.
Valeu!

