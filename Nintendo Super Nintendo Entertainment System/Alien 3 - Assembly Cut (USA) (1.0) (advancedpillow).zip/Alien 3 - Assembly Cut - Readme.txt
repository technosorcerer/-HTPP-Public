Alien 3 (U) [!].smc

Mod includes:
- Controls
	1. R - aim diagonal-up while standing still or moving -- crouching or running.
	2. L - aim diagonal-down while standing still or moving -- crouching or running.
	3. Up on D pad aims directly up. Holding down L and R aims directly up too, even while holding Up on the Dpad.
	4. When pressing Up while crouching/kneeling, Ripley no longer aims up during the stand up animation.
	5. Holding L and R aims directly up, whether kneeling or standing. Ripley can go from standing to kneeling when hold L and R, aiming up.
	6. When pressing Down while crouching/kneeling, Ripley no longer aims down during the kneeling animation.
	7. To aim down while already firing the machine gun, the player needs to hold L and the Down button on the Dpad.
	8. While on ladders, holding either L or R keeps Ripley stationary, permitting all D pad directions to be freely used for aiming instead of climbing.
	9. Added an entry on the game options screen to switch between "ASSEMBLY" and "ORIGINAL" control schemes.
	10. When crouching, pressing Up makes Ripley stand up instead of aim up in all cases.
	11. Removed diagonal aiming with the D pad when not on ladders.
	12. Added the "BEEP 1" sound effect to the new control option toggle.
	Bug 1. Pressing forward to forward-up to up while kneeling aimed up. This now stands up, no longer dependent upon firing.
	Bug 2. Pressing forward to forward-down to down while standing aimed down. This now kneels, no longer dependent upon firing.
	Bug 3. Pressing down while kneeling and firing now aims down, no longer dependent upon L.
	Bug 4. Pressing down while aiming up aimed down. This now kneels.
	Bug 5. Hanging animations now use default controls to fire in all 8 directions while firing.
	Bug 6. Fixed animation issue resulting in looping through animations or getting stuck in place.
	Bug 7. Suspected fixed issue with getting frozen in place, related to bug 6.
	Bug 8. Disabled kneeling down when not standing and standing back up when not kneeling down.
	Bug 9. Ensured that new kneeling and standing back up controls work with navigating air vents.
	Bug 10. Relocated variables that were conflicting with sprite processing.
	Bug 11. Relocated variables that were conflicting with mission data.
- Changes to power-on screens
- Updated aim up torso sprite
- Screen scrolling bounding box reduced from 32 pixels wide x 64 pixels high to 24 pixels wide x 64 pixels high.
- Save data initialized at the minimum size of 2 kilobytes.
	SRAM test output added to the game options screen.
	On the initial boot-up and first entering the game options, this will display "SAVE NG". This is because initialized save data was not found.
	On subsequent boot-ups and first entering the game options, this will display "SAVE OK" if SRAM was properly installed and save data was found.
	The above test output has been removed.
	Bug 1. Re-enabled subroutine to play sound effects.
- Game options saving
	Saved upon changing applicable values in the game options menu.
	Loaded at startup.
	When there is no valid option save data, values default to Normal, Stereo, and Assembly.
	Saved and loaded:
		1. Game level
		2. Sound mode
		3. Controls
- Game data saving
	Saved upon pressing select on the "MISSION SELECT" terminal screen.
		This terminal screen now displays save status.
		Two saves are allowed per stage, once per "MISSION SELECT" terminal screen.
	Loaded upon selecting "LOAD SAVE" from the main menu.
	Saved and loaded:
		1. Completed mission data
		2. Current stage
		3. Mission-related variables
		4. Flamethrower type
		5. Current health
		6. Weapon ammo levels
		7. Stage saves used
		8. Current mission time
		9. Total time so far
		10. HUD inventory icon
		11. Current stage item data
		12. Current stage status data
	Main menu selection defaults to "LOAD SAVE" when there's valid game save data.
	Changed "MISSION COMPLETE TIME" to "STAGE COMPLETE TIME" on stage-end UI.
	Bug 1. Per stage save counter UI now counts down instead of up.
	Bug 2. Cleared the "load save" flag after loading.
	Bug 3. Fixed audio dropout issue triggered when clearing the entire 4 KB of SRAM.
	Bug 4. Fixed the status of egg pods and other items by loading from the save file before graphics are drawn.
	Bug 5. Fixed egg pod graphic issue.
	Bug 6. Attempted fix for additional audio issues.
		Test 1: IncrementStage
		Test 2: FinishEnteringPause, HandlePaused
		Test 3: InitializeCachedObjects, CheckCacheObjectsFromStageData
		Test 4: SafeLoadGameData
		Test 5: HandleTerminalInputCheckSave
- Delete save
	Selecting "DELETE SAVE" on the main menu immediately deletes the game save data.
	Added a failsafe "DELETE SAVE?" prompt.
	Bug 1. Deleting game save data was also wiping option save data.
- Password screen
	Changed letter entry input from only B to A, B, X, Y, or Start.
- Added cheat code in game pause
	1. Flamethrower: A B Y X L
		Changes the flamethrower type to blue.
	2. Player Speed: A B Y X R
		Toggles increasing the player's walking, kneeling, and jumping speeds by 1.5x, and grappling speed by 2x.
		Bug 1. Fixed hard-coded value comparison against jumping speed to set the landing speed properly.
- Updated ROM checksum.