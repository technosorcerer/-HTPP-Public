"Dinocity"
Traducci�n al Espa�ol Ver. 1.0 (16/11/2018)
por Max1323 (maxmuruchi@gmail.com)
---------------------------------------------------
Descripci�n:
Trabaja en equipo con los dinosaurios para una aventura.
Timmy y Jamie fueron enviados a la era prehistorica.
Para salir de alli tendras que recuperar el fusible que
fue robado.

Desarrollado: Smart Egg Pictures
Publicado:    Irem
Lanzamiento:  17/07/1992 (Jap�n)
              Septiembre 1992 (Estados Unidos)        
---------------------------------------------------
Acerca del proyecto:
Se tradujo los textos de la historia.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS
File MD5      3623EFCE83F8C52FB7E2CE173C487288        
File SHA-1    817EAC2E9E84F3A2F7263FDEE12D09181F14AC09
File CRC32    94152717                                
File Size     1.00 MB

                              
                           
                              
                              
                             
                       
