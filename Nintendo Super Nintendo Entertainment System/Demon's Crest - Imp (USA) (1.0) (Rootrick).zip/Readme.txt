  Release of Imp 1.0 patch for No Header Demon's Crest US ROM by Rootrick, no ROM expansion needed.

  This project started out much smaller a little over 11-12 years ago.  It was to just de-lag the game as much as possible, but some whatifs flew around in the brain so a little bit more ended up being done.

  Main
-Stage 5 is always available.
-Phalanx's Fortress is available at the beginning.
-No refights with Hippogriff2, Hippogriff3, Flier2 and Grewon2.  Area tiles and transitions changed so it's not just a bunch of empty space to traverse.
-Using magic or a potion will search, from left to right, to find another of the same that was used and equip.
-Use L & R to cycle through Talisman.  Checks for Fang aren't made until projectile connects.  For example, firing a shot with Fang equipped and switching to Armor won't use Fangs damage, but firing with Armor and switching to Fang before contact will do the double damage.
-Keep your current Crest/Form from stage to stage, but if you want to change back to normal gargoyle(if you know you're going to Trio The Pago mini game for example), hold A during fade out when leaving area to overworld through normal means, select a stage or a Sulfur.
-Hold any button during fade out after beating Phalanx3 at 100% to receive Infinity Crest, skip ending and return to overworld to face Dark Demon, keeping your collected money/potions etc.  Also combos with A to revert back to normal gargoyle if you want.
-No collision with jars, only break them with shots or dashing into.  Also their priority is changed to appear behind Firebrand while above him so flying underneath doesn't still have them in front.
-Some hazards(Spikes, stage 3 forest tree flames(not the debris), stage 4 branch area 2 membrane jelly stuff, stage 6 branch area 5 snake pits) and drowning do 4 damage up from 1.
-Crown Talisman has an extra ability, find it somewhere in the spell shop.
-Skull Talisman has an extra ability, updated the library description to say so.
-Stage 2 shop doors are always enterable, no need to headbutt, also removed the rock wall outside Stage 2 potion shop, as well as overworld and Stage 2 shops sell the same items.
-Hippogriffs Statue explosion, Flame Lord(Orb) and Holothurion on kill, as well as items picked up that would freeze, no longer freeze Firebrand.  Plenty of time to use a Mercury instead of 1 frame.
-Coins changed from 1/5/20 to 3/5/10.
-Jar outside library no longer gives guaranteed big coin.
-Whichever Vellum you first find comes scribed with Shadow, good for the actual first Vellum in Stage 1 for a little help against Hippogriff or Arma1.

  Ground Gargoyle
-Dash infinitely.
-Increased dash speed.
-Slower dash speed underwater.
-Reduced dash startup by 7 frames.
-Holding dash while landing from dash jump, dash will continue at top speed unless underwater.
-Air projectile speed increased when dashing at full speed so it can stay in front of you.

  Aerial Gargoyle
-Ascend infinitely.

  Tidal Gargoyle
-Forward swimming speed increased.
-Instant maximum acceleration & deceleration upon activating swim and turning, but not during attacking.
-Increased jump height leaving water(Always wanted to reach those platforms in Stage 5 without switching forms, that's all.)

  Ultimate Gargoyle
-Charge shot time halved, synced so charge is ready after one cycle of animation.
-Charged shot didn't do any extra damage, made it add 2 more damage affected by Fang up to 4. A 50% damage increase against Dark Demon's 1st form vs. a normal shot, and 100% against 2nd form vs. a normal shot.
-Projectile speed increased when dashing at full speed so it can stay in front of you.
-Regardless of Fang equipped or not, a charged shot will destroy Dark Demon's homing orbs.
-Changed the palette.

  Potions
-Changed descriptions to save some space(See Spells section), also prices changed.
-Mercury's price, 5 to 7.
-Sulfur's price, 10 to 7.
-Herb's price unchanged(25.)
-Elixir's price, 100 to 50.
-Ginseng's price, 140 to 100.
-Health fill of potions are much faster, also got rid of an extra pause of 63 frames after animation plays.
-Elixir restores 10 health up from 4.

  Spells
-Changed descriptions a tad to save some space(Mainly started on this to change Shadow's to not be confusing, but went ahead and cleaned it all up some to make room for the new code), also prices changed.
-Shadow's price, 10 to 15.
-Hold's price unchanged(20.)
-Imp's price, 25 to Lease(Initial price is free.)
-Shock's price, 50 to 45.
-Death's price, 80 to 50.
-Shadow goes through one cycle of animation instead of three, also does 4 damage up from 2.
-Imp does 2 damage up from 1 and charges you money 8 times slower.
-Shock does 10 damage up from 1.
-Death does 10 damage up from 7.

	Boss
-Somulo's first form's hp reduced to 3 from 6 like the Japanese version.
-Hippogriff will perform an action every 2 wing flaps instead of 3, outside of liftoff.
-Increased the amount of actions needed before Hippogriff turns back into a statue by 2.
-Increased Holothurion's invulnerable frames by 4.
-Phalanx3's guard properly guards.

  Make it a little more risky for getting hit without Armor.  Damages(with Time+Armor) almost identical to original: Beam +1, one more health bubble; Lightning&Lava +0.5, half a health bubble more; Orbs identical.
-Phalanx3's Beam: Base 4 to 8; Time/Armor 2 to 4; Time+Armor 1 to 2.
-Lightning: Base 4 to 6; Time/Armor 2 to 3; Time+Armor 1 to 1.5.
-Orb: Base 2 to 4; Time/Armor 1 to 2; Time+Armor 1 to 1.
-Lava: Base 1 to 6; Time/Armor 1 to 3; Time+Armor 1 to 1.5.
-Dark Demon's orb: Base 1 to 4; Time/Armor 1 to 2; Time+Armor 1 to 1.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Weakness changes, SPOILERS for those who like to try these out and figure it out on their own.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

  Crest Weaknesses
-Ovnunu & Mini Ovnunu's weaknesses to Claw: 1 to 2.
-Scula(Head&Body)'s weakness to Buster: 1 to 2.
-Flier's weakness to Fire: 1 to 2, and weakness to Air: 3 to 2
-Crawler's weakness to Claw: 1 to 3, and weakness to Time: 5 to 3.
-Holothurion: Fires reduced to 1.
-Grewon's weakness to Time: 10 to 6.
-Phalanx3's weakness to Demon Fire: 3 to 6.

  Spell Weaknesses
-Shadow does x3 damage to Flame Lord, and x2 damage to Crawler.
-Hold will freeze Crawler and Phalanx1.
-Imp will now attack: Hippogriff(For fun), Arma1&2, Scula(Head&Body(Hitbox is big enough to hit both at once)), Grewon and Phalanx3's orbs.  Imp also does x3 damage to Belth.
-Shock can hit Crawler 3 times if the eye is exposed a 2nd time immediately, Grewon 3 times if there's no late turn and Holothurion 5 times.
-Death does x2 damage to Crawler and x3 damage to Flier.  Flier doesn't gain weaknesses immediately, must wait a second or two else the spell will miss!

  New Immunities
-Belth immune to Shadow & Death.
-Flame Lord immune to Death.
-Arma3 was given his own immunities separate from Arma1&2, immune to all.
-Phalanx2 immune to all.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Weakness spoilers end.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	De-lag
-Reduced the flames spawned on death for all non boss enemies.
-Ground Gargoyles dust spawning frequency when dashing lowered.
-Tidal Gargoyles underwater shot explosion animation bubbles lowered.
-Amount of debris spawned from breaking jars, walls, statues and background objects reduced.
-Hippogriff statue explosion light size, flames, smoke and debris reduced.
-Crumbling Pillars in Stage 1 Area 2, removed their rubble.  With the addition of infinite dash and extra speed, turns out these are buggy and overwrite other entities as they continue to break off screen.  Fixed this somewhat by changing their animation a tad for less crumbling cycles with the middle and bottom breaking at the same time.
-Belth bone spawns during death reduced.
-Flaming Skulls spawn 3 fireballs instead of 5.
-Rubble spawned from Ovnunu breaking walls reduced.
-Flame Lords death flame spawn frequency reduced.
-Fliers death flame spawn frequency reduced greatly.
-Holothurion's bubbles spawned during fight and death animation lowered.
-Grewon's ice breath frequency reduced.
-Removed enemies:
-One ghoul in stage 1 area 1.
-Nine ghosts, one gargoyle statue & one merman in Stage 2 Area 2.
-Eleven zombie arms in Stage 2 Area 3.
-Three eye bats & three flaming skulls in Stage 2 Branch Area 1.
-Two bats in Stage 2 Branch Area 2.
-Three eye bats & three vines in Stage 3 Area 1.
-Three eye bats & two mermen in Stage 3 Area 2.
-Two earthworms in Stage 3 Area 3.
-One parasite nest in Stage 3 Branch Area 1.
-Two eye bats & a fish in Stage 3 Branch Area 2.
-A stone worm & pillar in Stage 4 Area 1.  Changed the area tiles to represent them not being there.
-Two amphiptere in Stage 5 Area 1.
-Twelve background fish in Stage 5 Branch Area 2.
-Three eye bats in Stage 6 Branch Area 3.
-Four bats & a zombie arm in Stage 6 Branch Area 5.
-An Imp Crossbow in Stage 7 Area 1.

  Other
-Stage 7 Area 1 & 5 tiles different for not having the refights.
-With L/R switching Talisman, disabled the ability to select L or R as configure options and changed the options menu a tad.  Drew a forward slash sprite for the "L/R".
-Shrunk the item selection UI some.  Drew a sprite for the less space.
-The change to the jars priority makes it appear in front of the bell in stage 7.  Made it spawn at the bottom to not just pop out in front.
-With the addition of extra speed, the gargoyle demo's/endings were off, synced them best as possible to keep them from dying.

  Anti-Piracy
-Removed check just before CAPCOM shimmers, which activated a check for pausing.
-Removed check for Firebrand getting hit, which activated a check inside damage script.
-Removed check when headbutting Hippogriff's statue form, which activated a check for pausing.
-Removed check for when Arma spawns, which activated a check inside damage script.
-Removed 2 checks inside damage script.
-Removed 2 checks for pausing.

  Original Bug Fixes
-Fixed 2 bugs where, jumping underwater set your speed to normal out of water speed, as did recovering from being hit.
-Fixed 2 bugs involving Hippogriff & Flame Lord(both forms) taking the final hit regardless if their flash was active or not, as long as the shot was going to kill.
-Fixed the forest fires disappearing before defeating Flame Lord.