"Super Robot Wars 3" o "Dai-3-Ji Super Robot Taisen"
Traducci�n al Espa�ol Ver. 1.1 (23/06/2020)
por Max1323 (maxmuruchi@gmail.com)
Basada en la gran traducci�n de Aeon Genesis.
---------------------------------------------------
Descripci�n:
SRW3 es un juego de estrateg�a que junta a los grandes mechas
de diferentes franquicias como Mazinger Z,Gundam,Getter Robo,etc.
La historia sucede 6 meses despu�s de su segunda entrega,
donde deber�s enfrentarte nuevamente al DC (Divine Crusaders) y 
a unos misteriosos enemigos para proteger la Tierra.


Desarrollado: WinkySoft 
Publicado:    Banpresto
Lanzamiento:  23/07/1993 (JAP)
---------------------------------------------------
Acerca del proyecto:
Se tradujo los textos y los gr�ficos.
Tambi�n se tradujo los t�tulos de los episodios gracias
a Wave y Jackic.
1.1-Se tradujeron algunos textos m�s.Y se corrigi� el texto
del men�.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS

Dai-3-ji Super Robot Taisen (Japan).smc/sfc
File Size     1.50 MB
File MD5      B5974F5306E8DAEE96D5FC625E960F0A
File SHA-1    B16375F0C1CC6E5960CBCD2F9D24D97CB824C5D4
File CRC32    DFE9CC90