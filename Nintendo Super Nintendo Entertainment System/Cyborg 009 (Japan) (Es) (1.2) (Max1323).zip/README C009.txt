"Cyborg 009"
Traducci�n al Espa�ol Ver. 1.2 (04/11/2018)
por Max1323 (maxmuruchi@gmail.com)
Basado en la traducci�n de Aeon Genesis y J2e Translations.
---------------------------------------------------
Descripci�n:
Los Cyborg se enfrentan a un enemigo desconocido.
Escoge a un equipo de 3 Cyborg para derrotar pasar
los 5 niveles.

Desarrollado: Bec
Publicado:    Bec
Lanzamiento:  25/02/1994 (Jap�n)             
---------------------------------------------------
Acerca del proyecto:
Se tradujo los textos de la historia.
Presenta un problema en la ultima misi�n, al parecer los textos
que usa son de la misi�n del �rtico.
Se introdujo los acentos y la �.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS
Cyborg 009 (J)
File MD5      0BE736BB76D0A5CCE320886570382362        
File SHA-1    5AB41E2C6CCCE1F40FB9813E8E07A49C785D88C5
File CRC32    4A5263DB                                
File Size     1.00 MB
                              
                           
                              
                              
                             
                       
