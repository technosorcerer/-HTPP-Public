Hello, person who opened up this readme! I am MS04, creator of the very hack you are (hopefully) going to play! Let's dive into some of the new content, shall we?


1) RESTORED CONTENT:

The unused songs Battle2 and Singing Mountain now play at certain points in the game, and you're bound to hear them at some point!

A few unused items like the SeraphSong are re-added into the game, and can now be purchased.

The cut "Lost Village" from the CT prerelease, now known as the Erpon Village, has appeared on the Prehistory map! Speak to some of the friendly Reptites there, and buy some new items if you want to!


2) NEW CONTENT:

In the regular version of the hack, stats for enemies are changed, making them a little tougher!

Some lines of text and inconsistencies are changed, however, this is still largely the original SNES translation.

Plenty of palette changes, like the cape of Magus, are changed to match artwork a little better.

Frog will be in his human form in all versions of the main ending, even if Magus isn't dead!

The Ocean Palace escape scene is different now, with some extra pieces of dialogue and Sealed Door playing instead of the Cathedral theme.

A few references to Chrono Cross are added here and there, including a certain alignment of rocks in the seas of 1000 AD...

Frog's strange way of speaking is explained in this hack as the way all frogs spoke in the Middle Ages, as the Frog King speaks very similarly.


3) SPECIAL THANKS:

I'd love to give a huge thanks to Geiger for creating Temporal Flux (the program used to edit almost all of the hack), Mauron who created various plug-ins for Temporal Flux which were used in this project, Boo the Gentlemen Caller for beta-testing this hack for me, and also all the people from the Chrono Compendium and beyond who were hyped for this hack! May the dream of a new adventure with Crono and his friends live on...


4) VERSIONS OF THE HACK:

You can either play the regular Master Quest version that has increased enemy difficulty & the new content or the Jr. version, which keeps all the new changes but the same enemy stats as in the original CT.


5) Q&A:

Q: Can I play/livestream the hack?
A: Sure! Just make sure to credit me for making the hack.

Q: Can I make a repro cart of the hack?
A: Sure, just do NOT sell it. I don't want people profiting off fan works, more specifically my work.

Q: What are the main differences between this hack and regular CT?
A: Not too much, mainly just some new content, cut content coming back and increased difficulty if you play the regular version of this hack. Think of it like what the Persona series does, where this is basically just a "special edition" with some additional stuff.

Q: Any future projects to look forward to?
A: Not yet. I have plans for more ROM hacks for many different games (including some more CT hacks), so make sure to check those out! I'll announce new CT hacks on the Chrono Compendium forums first.

Q: Should my Chrono Trigger ROM be headered or headerless?
A: I made this hack on a headerless ROM, so that's probably what you should use. There are ways to remove a header from a ROM, so find out for yourself.

Q: Where can I find a Chrono Trigger ROM?
A: I will not point you to directly where you can find a Chrono Trigger ROM, as it's technically piracy, which I don't condone. It would be best to backup your own ROM.