The humble pope Neige the reversing racketeer and avatar of laziness is proud
to present the Crystal Beans From Dungeon Explorer English translation patch
version 1.1.

This patch translates the Japanese game Crystal Beans From Dungeon Explorer in
English.

This patch must be applied to a ROM of
"Crystal Beans From Dungeon Explorer (J)" without an header.


Credits
Original creators: Birthday and Hudson Soft

English localization :
Romhacking, Programming, Assembler : Neige (v1.0), Hiei- (v1.1)
Graphics : Neige
Translation : Hiei-
Editing : Pennywise
Beta-test : Pennywise
Kanji table corrections : BRPXQZME
Special Thanks : mziab

Thanks:
Ilfak Guilfanov for Ida Pro, the best disassembler in the world.
  <www.hex-rays.com>
Nightcrawler for Romhacking.net.
Bessab for bessab.com.
Inverse for the defunct site Romhacking.com, the first website where I learned
about romhacking.
Ryusui for his program "TheCheat"


Game informations

Controls:
A       Confirm, talk
B       Long range attack, cancel, return to previous menu
X       Exit to the world map (only available in towns)
Y       Short range attack
L       Use a white potion
R       Use black skull(s)
Start   Pause and character menu
Select  Unused

To save your game, open the menu by pressing START, select SAVE and choose the
file where you want to save.

To continue a previously saved game, select your character and then the file
where you saved the game.

Note: You cannot save the game if you switch characters. You will need to
reselect the first character you chose.

Characters initial stats:
          HP  AG  AT  VI  IN
Fighter   18   5   8   7   4
Warrior   21   4   7   8   4
Bow-Man   15   7   4   4   6
Wizard    13   5   6   5   7
Priest    12   5   5   4   8
Monk      24   6   8   9   2
Kage      15   8   5   5   4
Witch     15   5   7   5   7
Thief     13  13   5   5   4
Bard      11   7   4   4  13
Dragon    28   9   7  13   3
Robot     18   6  13   6   6

Objects:
Beans � Additional life (press A to resume playing)
Little heart - Heal 25% of the character's HP
Large heart � Heal all the character's HP
Cape � Protects the characters from  (Intelligence x Level) points of damage
Boots � Temporarily increase the character's agility
Mirror � Make the character's projectiles rebound
Miracle gem � Increase the character's level (the color determines the stat
              that is augmented)
White potion � Used to heal the character
Black skull � Used to do a magic attack

Character's magic power calculation:
Intelligence       0-7  8-15  16-20
Magic power         3    2      1

White potions heal (Max HP / Magic power) HP.
You need (Magic power) black skulls to initiate a magic attack.
