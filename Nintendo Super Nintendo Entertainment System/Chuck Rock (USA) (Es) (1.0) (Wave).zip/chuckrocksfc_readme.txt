Chuck Rock (Super Nintendo)
Traducci�n al Espa�ol v1.0 (06/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Chuck Rock (U).smc
MD5: b6117d7ae13c9afc785d5b6b0afd8bae
SHA1: 3ffafb846909d6ef3dd8a8715362d2c4489cb3f1
CRC32: e237ec45
1.048.576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --