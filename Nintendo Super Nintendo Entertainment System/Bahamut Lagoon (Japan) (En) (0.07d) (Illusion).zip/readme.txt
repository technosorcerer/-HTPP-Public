Illusion Translations
Patch for Bahamut Lagoon (J) ->
Bahamut Lagoon (T-Eng/Illusion Translations)
v0.07d [beta] (March 25, 2002) 96%
========
-This is a public beta, not final patch. Please report all bugs!
-Don't report script errors (ie. grammer, spelling, etc)!
-Remember, always patch the original version of the ROM. That means
the Japanese version folks (so if you don't still have the Japanese version,
you need to get it for this patch to work).
-This is the same as patch v0.07c except the Prologue has been patially revised.
========
Matt, Illusion, Masamune, TetrisFrog

http://planet-emu.com/illusiontrans