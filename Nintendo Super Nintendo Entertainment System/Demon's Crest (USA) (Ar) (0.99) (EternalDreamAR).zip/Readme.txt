بسم الله والحمد لله،،
                                           
                                           
		
								 Project by:
                           #                          
                          # #   ##### #    # #####  # 
                         #   #    #   #    # #    # # 
                        #     #   #   ###### #####  # 
                        #######   #   #    # #    # # 
                        #     #   #   #    # #    # # 
                        #     #   #   #    # #####  # 
        
           ###    ##        ######  ##     ## ##       ##    ## ##     ## 
          ## ##   ##       ##    ## ##     ## ##        ##  ##  ##     ## 
         ##   ##  ##       ##       ##     ## ##         ####   ##     ## 
        ##     ## ##        ######  ######### ##          ##    ######### 
        ######### ##             ## ##     ## ##          ##    ##     ## 
        ##     ## ##       ##    ## ##     ## ##          ##    ##     ## 
        ##     ## ########  ######  ##     ## ########    ##    ##     ## 
		
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  Demon's Crest
  For Super Nintendo
  Arabic Translation Patch
  Version Beta 0.99
  My site: https://sites.google.com/view/athbistudio/
  My Twitter: https://twitter.com/tff9q
  My Patreon: https://www.patreon.com/tff9q
  MY Paypal Support us: https://t.co/67jzIrXZ5H
  
  Created by Athbi Alshlyh: Full Translation and ASM Hacking. feel free to send me feedback: q8fft8@gmail.com
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
******** This translation is not for sale or rent. ***************
********    هذه الترجمة ليست للبيع او التأجير.     ***************
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

CREDITS to:
-----------------
	Big Thanks to: الشكر الكثير إلى
	+ Mansour-
	  على الترجمة الاكثر من رائعة وايضا دعم قلب النصوص لتناسب اللغة العربية
	  بالإضافة إلى تصميم الخط الابداع..
-----------------
	All time Thanks to: الشكر في كل الاوقات
    + A7med Bamatraf- محول الحروف , http://www.romhacking.net/utilities/1012/
    + Romhacking.net
	+ Kruptar
	+ WindHex
    + And You


Project History - تاريخ بداية المشروع:
-----------------

Start project: 17-JUN-2020
End project:   07-MAY-2020



Version History - سجل تاريخ الاصدارات:
-----------------
  
   Version 0.99,    07 MAY, 2020 [17,334 bytes]
   Done. Go. Play. NOW. جهاز للعب
   
What's left - ما الذي تبقى:
-----------------

حاليا المترجم في اللعبة هو كتالي:
 - الترجمة شبه كاملة
 - بالإضافة إلى قلب النص لليمين
 
الغير مترجم:
 - الصور لم تلمس بعد

Game Notes - ملاحظات:
-----------------

  
Installing Patch - تنصيب الباتش:
-----------------
اولا: احصل على نسخة روم من اللعبة بـ اسم، (أبحث في جوجل.)ـ
Database match: Demon's Crest (USA)
Database: No-Intro: Super Nintendo Entertainment System (v. 20180813-062835)
File SHA-1: E757D1DF623605AD7A236209BE08A4A08588F5C8
File CRC32: 7C3FF750
ROM SHA-1: 743D60EE1536B0C7C24DBB8BA39D14ED5937C0D5
ROM CRC32: E8236AD2

ثانيا: تحتاج إلى برنامج لونار لتطبيق الباتش من هنا
http://www.romhacking.net/utilities/240/

ثالثاً: طبق الباتش على اللعبة.
Demon's_Crest_0.99_Arabic.ips

لا تنسى مشاهدة صورة الشرح مرفق مع الباتش.
وبس، وأوقات طيبه لك.


Copyrights - حقوق النشر
-----------------
  Demon's Crest, and all other names are trademarked to
  Capcom of Japan.


Disclaimer - إخلاء مسؤولية
-----------------
  There is no videogame company or any other company associated with
  Athbi Alshlyh. In no event shall Athbi Alshlyh be liable or responsible for
  any damages that may occur from direct, indirect or consequential results
  of the ability or disability to use or misuse any material it provides.

  In other words, you'd better own the cart for the rom that you're patching,
  and if something goes wrong, don't blame me!