======================================================
          SUPER ROBOT WARS 4 -English- v0.25
                   by Fraka & Max
                       01-06-99
======================================================

    http://volftp.tin.it/ludus/iep/sadnes/index.htm
         http://members.it.tripod.de/Fraka/

               Fraka <runstop@usa.net>
              Max <megane72@hotmail.com>

------------------------------------------------------
 INTRO
------------------------------------------------------

I have recived a lot of mail asking for a new release...
so i have decided to continue the english patch.
Thanx to all for support.

This new version is based on the italian translation and
it uses the new set of chars, i hope you like it :)

We need translators, so if you know japanese and you want to
help us, please mail me.

For suggestions, corrections, translations mail me. 

Sorry for my english :)

------------------------------------------------------
 HOW TO USE THE PATCH
------------------------------------------------------

You need the srw4 rom in SMC format.

ips robot4.smc robot4e.ips
or
ucon i robot4.smc robot4e.ips
or
with SNESTOOL, select "Use IPS" 

------------------------------------------------------
 PROGRESS
------------------------------------------------------

Added mission targets, items descriptions, robot types
(air, water ...), Demo titles.

Done:

-Robots (64%)
-Pilots (86%)
-Powers
-Items and some descriptions
-Actions
-Robots and pilots abilities
-Options menu (miss songs and demo titles)
-Inframission menu (miss some dialogs)
-During play menu (miss some dialogs)
-Character creation menu
-Robots and pilots info (pilot stats etc...)
-Mission targets (miss some)
-Demo titles

Miss:

-Some pilots and robots
-Powers descriptions
-Weapons
-Commands and descriptions
-Songs and karaoke titles
-Terrain type (mountain, forest ...)
-Story and dialogs


------------------------------------------------------
 NOTE
------------------------------------------------------

Some shortening:

M BEAST ... = MACHINE BEAST ...
C BEAST ... = COMBAT BEAST ...
F BEAST ... = FOSSIL BEAST ...
D BEAST ... = DISC BEAST ...
V BEAST ... = VEGA BEAST ...

------------------------------------------------------
 THANKS TO
------------------------------------------------------

-Masa_Notu, Dario, Masako, Son_Goku.

------------------------------------------------------
 DISCLAIMER
------------------------------------------------------

SUPER ROBOT WARS 4 is a registered trademarks of BANPRESTO.


Fraka <runstop@usa.net>
