Brandish Name Change
(version 1.5)
December 9, 2009
ZeLoz (akaBill)

Version History:
1.5 (Current): Changes "Gadobistall" and "Btowls" to "King/God Bistall" and "Bytohl" to maintain continuity with Synchronicity's Brandish 2 English Translation. Also fixed a few embarrasing slip-ups in the previous patch (There were two instances of "Berymiya" still, among other things). Thanks goes to Denpa no Sekai, who led the translation of Brandish 2 and kindly pointed out the differences between our two works. 
1.0 (11/14/2009): Original Release

What it does: 
Takes any instances I could find of "Varik", "Alexis", "Berimya", and "Berebus" and changes them to "Ares", "Dela", "Bytohl", and "God/King Bistall" respectively. I thought about changing Dela's outfit to match the Japanese version, but I couldn't find the graphics data. Actually, I guess I could find the graphics data if I would just sit down and look for it, but I have other real life things to deal with at the moment. Sorry, dood.

How to use: 
Use your favorite IPS patcher to patch an unaltered American Brandish rom (GoodSNES: Brandish (U) [!]). Depending on the rom, you must use either the "Header" patch or the "NoHeader" patch.

Roms to be used with the "Header" patch have a file size of 1,573,376 bytes (The actual rom file, or "smc").
The "NoHeader" patch will only work with the rom that's 1,572,864 bytes.

Stuff I used: 
GoldFinger for HexEditing
TileLayerPro for changing "BERIMYA" on the gameplay screen to "BTOWLS," and then to "BYTOHL."
A table file accredited to Neil_ and found on the Snakeyes Gaming Corp. website.

Disclaimer Stuff: 
I don't own Brandish, Falcom does. Support the official release and import yourself a copy of Brandish - The Dark Revenant if you have a PSP and decent Japanese literacy. I hear it's pretty good.

If ya gots any issues (which, being my first rom hack, you probably do), feel free to e-mail me at zelozerrr-kun@hotmail.com. Of course, whether or not I'll actually help you is another thing entirely, but just assume I will as long as you ask politely. Also, if anyone finds out where all of Dela's graphics are (sprite, cutscene, etc.), I would gladly accept any help with that.
