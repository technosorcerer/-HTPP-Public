"Aim to the Ace! o Ace wo Nerae!"
Traducci�n al Espa�ol Ver. 1.0 (23/02/2020)
por Max1323 (maxmuruchi@gmail.com)
Basada en la traducci�n de RPGONE.
---------------------------------------------------
Descripci�n:
Ace wo Nerae! es un juego de tenis basado en el manga y anime
de Sumika Yamamoto. La historia se centra en Hiromi Oka una 
estudiante de 1er a�o que quiere ser una tenista profesional.
Ella siente una admiraci�n por Reika Ryuzaki conocida como
Madam Butterfly. Su entrenador Jin Munakata la entrenar� para
convertirla en una tenista profesional que la llevar� a hacer
la mejor de todas. 

Desarrollado: Nippon Telenet
Publicado:    Nippon Telenet
Lanzamiento:  22/12/1993 (JAP)
---------------------------------------------------
Acerca del proyecto:
Se tradujo los textos.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS

Ace o Nerae! (Japan).sfc/smc
File Size     1.00 MB
File MD5      572CF198450D3424DA503F93D4E6AC85        
File SHA-1    065BF1BBF4662383E2E42105AD76E0ED93213A57
File CRC32    6C5F1A18
