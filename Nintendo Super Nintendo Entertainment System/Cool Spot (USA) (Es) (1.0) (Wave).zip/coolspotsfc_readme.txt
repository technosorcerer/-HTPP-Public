Cool Spot (Super Nintendo)
Traducci�n al Espa�ol v1.0 (27/06/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Cool Spot (U) [!].smc
MD5: f0d0e5294f70b037bdf1b619db41ebd4
SHA1: f5ef9d9367191c4fcdb84c4d11a322a9d03f89d2
CRC32: 44e60e58
1048576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --