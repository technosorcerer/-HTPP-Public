Le patch IPS est � appliquer sur la rom : Bishoujo Senshi Sailor Moon - Another Story (Japan).sfc (m�me si le nom peut �tre diff�rent, mais c'est pour montrer la version de base que j'ai utilis�, celle du set non-intro. Le CRC (Checksum) de la rom JAP en question est "02A442B8".

Par rapport � ce qui est fait, logiquement tout est traduit sauf certains GFX qui ne sont pas encore faits et qui sont encore en anglais (genre le "North Pole"). La b�ta permettra justement de tous les recenser et de voir ce qu'il reste � faire. En gros, je me suis dit que le mieux, c'�tait de sortir un patch avant la fin de l'ann�e, histoire de bouger un peu les choses.

Niveau �cran-titre, la version japonaise poss�de deux �crans titres diff�rents. Si on coupe l'intro en appuyant sur le bouton "Start", on tombe sur un �cran-titre japonais. Si on laisse l'intro se d�rouler jusqu'au bout, on tombe sur un �cran-titre anglais (celui que la team anglaise a r�utilis�e d'ailleurs, il provient en fait de la version japonaise, alors que je pensais que c'�tait un �cran-titre qui venaient de chez eux).

L'�cran-titre anglais a �t� laiss� tel quel. Par contre, on a modifi� celui en Japonais. Au final, je me suis souvenu qu'il existait un jeu Sailormoon sur SNES qui est sorti en fran�ais (le beat'em up) et on a donc repris le logo de ce jeu, tout en conversant le sous-titre "Another Story" qui est d�j� en anglais, m�me sur le titre japonais.

On a �galement modifi� les quelques textes de stats dans les menus. HP => PV ; EP => PM (pour que ce soit plus classique, comme dans les RPG).

LAP (qui, apr�s recherche, signifie "Link Attack Points") a �t� modifi� en PAL (Points Attaque Liens).

Le Chance est un peu d�cal� sur la gauche, mais c'�tait la seule fa�on de le mettre en entier, impossible de rajouter une lettre
vers la droite.

Pour le staff de la trad, sauf erreur de ma part :

Traduction : Aurette / Yulina
Romhack : mziab / Hiei-
Modifications graphiques : m0nsieurL
