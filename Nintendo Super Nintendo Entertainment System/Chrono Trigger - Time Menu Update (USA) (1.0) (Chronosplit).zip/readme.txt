This patch updates the time selection menu seen when you warp to another time period in the Epoch to terms seen in later translation scripts.  Dark Ages is now Antiquity, and Prehistoric is now Prehistory.  No text has been updated so anyone making a patch may use this without fear, just the image.  This is the same one used in the Bugfix and Uncensoring Patch, with my best efforts at making everything as presentable as possible.

Anyone may use this, just be sure to give credit.  According to a standard hex editor, the updated image is stored in addresses 41F400 to 41FF70.
