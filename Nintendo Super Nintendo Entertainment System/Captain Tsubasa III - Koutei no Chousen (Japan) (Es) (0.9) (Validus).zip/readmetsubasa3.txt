Captain Tsubasa III - El Desafio De Kaiser
Validus Version .90
-----------------
Those Responsible
-----------------
Spectrum XD, Story Mode Translator
Virgo 64 - Game & Player Name Translator
Validus - Merged the work of both Translators

-----------------
Translated
-----------------
All menus, Player names, Title Screen, most of the story mode.

-----------------
Not Translated
-----------------
Final Two games in story mode and quite possibly the ending (have yet to beat game)

-----------------
Patching Instructions
-----------------
Apply IPS patch to the file named Captain Tsubasa III (J) with the size of 1,048,576 bytes with no Header

I recommend you use Lunar IPS or (LIPS) or your favorite IPS patcher.

