Chrono Triggered 1.2 Updates.

	~2ndFaith & LearnMoney no longer crash the game.
	~Fixed a couple of issues with skills/items that were mysteriously crashing the game.
	~Fixed a large amount of lines that would screen wrap.
	~Cleaned up some of the text as well, removing some random apostrophes & oddly placed words.
	~Battle Text should be fixed to display properly now. 

A NOTE ON TECHS:
	I have no idea what the heck is causing the tech issue. I've attempted to clear all
	unnessecary symbols used throughout the entire game, and it still persists. I figure 
	this might be a memory leak issue, and have no idea where to even start on that. If 
	anyone ever wants to take up the torch and fix this, by all means. I have no intentions 
	of trying to fix this glitch, as it's beyond me.

---------------------------------------------------------------------------------
Chrono Triggered 1.0 Is a comedic text hack/spoof of the game "Chrono Trigger".
Creator of the translation: "Rim"
Assistant Tool "Google Translate", "Chrono Trigger Text Editor"
Languages Used: 
(Vietnamese, Mongolian, Nyanja, Italian, Serbian, Irish, Latin, Hawaiian, Scottish, English & Many More)

	There have been issues that I cannot recreate with patching this file,
	And honestly, I'm not even sure If I'm using headered or non-headered files anymore.
	Rule of thumb, if it doesn't work on one, try the other.

	Things that are known, This was done on the US/Canada version of the game.

	There are also 2 currently known issues, one of which is possibly going to be fixed in v1.2

	The other error I am earnestly scratching my head over. It's caused when you recieve a new tech. 
	For some reason, the game rolls over the text into the next bank of dialogue. Seeing as it didn't 
	crash the game in testing, This has been viewed as a minor issue. if a fix can be found, it will be
	patched.


								Enjoy The Shenanigans, ~Rim