I Love Bikes! Street Racer Soul - Rider Spirits
Bike Daisuki! Hashiriya Tamashii English Translation Project
Version 1.0
12/10/2018

MODIFIED BY MRRICHARD999 & D.D.S.
TRANSLATIONS DONE BY AGENTORANGE & THEMAJINZENKI
TITLE SCREEN DONE BY FLASHPV

Here is a full English translation of the game Bike Daisuki! Hashiriya Tamashii which is very much like a clone of Super Mario Kart. In this game though instead of cars or karts you ride motorbikes. All the menus, names, and dialogue lines have been translated to English to make playing this game much easier without the language barrier. The only portion of this game that was not translated were the credits. Be warned as this game can be very difficult at times... We hope you enjoy this project!

ORIGINAL ROM TO PATCH INFORMATION
Bike Daisuki! Hashiriya Tamashii (Japan).SFC
CRC32: B363FC99
MD5: 9BC21069D1C9EBA86DAD2BA0E994E5A1
SHA-1: D0457FC27ADFF1B0AD236535F60F91711B15F0DB
SHA-256: 3FB25A3B30E897455DE88E9E1D5FF2DF81E56B89F3FE7B7D9E0248A19A146B4B
