Chrono Trigger
Suomenkielinen kÃ¤Ã¤nnÃ¶s - versio 1.15.1 - http://bisqwit.iki.fi/ctfin/
KÃ¤Ã¤ntÃ¤jÃ¤in kommentteja - kirjoittanut Joel Yliluoma

KÃ„YTTÃ–OIKEUS
  Chrono Triggerin suomenkielinen kÃ¤Ã¤nnÃ¶s on tehty
  niinsanotulla faneilta faneille -periaatteella, eli
  se on vapaasti kaikkien kÃ¤ytettÃ¤vissÃ¤, ketkÃ¤ haluavat
  Chrono Trigger -pelinsÃ¤ suomenkielisenÃ¤.
  KeneltÃ¤kÃ¤Ã¤n ei saa periÃ¤ minkÃ¤Ã¤nlaista maksua
  tÃ¤stÃ¤ patchista.

  Patchin ohessa ei saa toimittaa ROMia, eikÃ¤
  valmiiksi patchattuja ROMeja saa levittÃ¤Ã¤.
  
  Patchia ei myÃ¶skÃ¤Ã¤n saa levittÃ¤Ã¤ ilman tÃ¤tÃ¤ tekstitiedostoa.
  Kuitenkin jotakuta kiinnostaa tÃ¤mÃ¤ teksti.

TARVITSET
  Tarvitset Chrono Triggerin englanninkielisen ROM-tiedoston.
  Sen pituus pitÃ¤isi olla 4194816 tai 4194304 tavua.
  Jos pituus on 4194304 tavua, kÃ¤ytÃ¤ tiedostoa
  ctpatch-nohdr.ips. Jos pituus on 4194816 tavua,
  kÃ¤ytÃ¤ tiedostoa ctpatch-hdr.ips.
  Sijoita englanninkielinen ROM ja suomenkielinen patch samaan
  hakemistoon samalla nimellÃ¤ (pÃ¤Ã¤tettÃ¤ lukuunottamatta, eli
  esim. chrono.smc, chrono.ips) ja pelaa. AlkuperÃ¤inen ROM
  ei muutu nÃ¤in miksikÃ¤Ã¤n.
  Jos haluat muuttaa ROMin pysyvÃ¤sti suomenkieliseksi, ota
  ensin varmuuskopio ROMistasi ja kÃ¤ytÃ¤ sen jÃ¤lkeen patchin
  kÃ¤yttÃ¶Ã¶nottoon jotain ips-patchausohjelmaa.

TILANNE
  - Ns. virallinen kÃ¤Ã¤nnÃ¶sversio on nyt julkaistu!
  - Lue uutiset tarkempia tietoja varten.

TIEDOSSA OLEVAT VIRHEET:
  - Jotkut paikannimet (esim. Chorasin majatalo) katkeavat kesken.
  - Varusteenvaihto tuottaa joskus outoja E-kirjaimia. Ã„lÃ¤ vÃ¤litÃ¤.
  - Kaupat ja varusteluruutu eivÃ¤t toimi oikealla SNES-konsolilla
    sekÃ¤ joissain emulaattoreissa. ZsnesissÃ¤ toimii vielÃ¤ toistaiseksi,
    ja Snes9x:ssÃ¤ jos sallii "out of v-blank PPU updates" -mahdollisuuden.

KAIKKIAAN LUOTU:
  - kÃ¤Ã¤nnÃ¶s (300 kB tekstiÃ¤)
  - monenlaisia laajennuksia pelin dialogifonttiin ja -koodiin
  - fontteihin suomalaiset symbolit
  - kursiivi dialogifontti
  - vaihtuvanlevyinen 8pix fontti ja ohjelmakoodit sen kÃ¤sittelyyn
  - korvattu pelin tavaranimilistat ja niiden hakurutiinit omilla
  - korvattu pelin tekniikkanimilistat ja niiden hakurutiinit omilla
  - korvattu pelin hirviÃ¶nimilistat ja niiden hakurutiinit omilla
  - elementtikuvat (ukkonen, tuli jne)
  - hahmonimien taivutus -ominaisuus ja ohjelmakoodi
  - crononick -ominaisuus (erÃ¤Ã¤n pÃ¤Ã¤henkilÃ¶n kÃ¤yttÃ¤mÃ¤ Cronon lempinimi)
  - lisÃ¤tty varustevaihtoon tavaramÃ¤Ã¤rÃ¤ kuten se oli jap. versiossa
  - lisÃ¤tty Warp ja Bisqwit peliin ylimÃ¤Ã¤rÃ¤isinÃ¤ NPC:inÃ¤ erÃ¤Ã¤seen paikkaan
  - battlemode selection -ruutu
  - kuvien pakkaus- ja purkurutiinit
  - signatuurituki ja signatuuri

UUTISET JA KEHITYSHISTORIA (uusin alhaalla):
   9.9.2002
     Aloitin Chrono Triggerin hakkeroimisen.
   11.9.2002
     Koossa on toimiva dumpperi pelin teksteille ja fonteille,
     sekÃ¤ toimiva insertor niille samoille. EnsimmÃ¤inen screenshot
     (ctquack.png) otettu! :)
   28.11.2002
     PÃ¤ivitin tÃ¤tÃ¤ README-tiedostoa. Tilanne tÃ¤llÃ¤ hetkellÃ¤
     on se, ettÃ¤ en ole pariin kuukauteen tehnyt juuri muuta
     kuin kÃ¤Ã¤ntÃ¤nyt jonkun alle sata riviÃ¤ tekstiÃ¤ suomeksi.
     Ollut vÃ¤hÃ¤n muuta hommaa. PitÃ¤isi saada nuo isommat
     esteet ratkaistua ensiksi:
       - peli pitÃ¤isi saada taivuttamaan nimiÃ¤ (snes-assemblerilla!)
       - lÃ¶ydÃ¤ kaikki tekstit ROMista
       - ratkaisu tilanpuutteeseen itemien nimissÃ¤
         (kymmenen merkin pituusraja tavaroiden, tekniikoiden
          ja hirviÃ¶iden nimissÃ¤ on aika rankka suomen kielelle.
          Miten esimerkiksi kÃ¤Ã¤ntÃ¤isit "Ruby Armor"?)
   23.6.2003
     Pari viime pÃ¤ivÃ¤Ã¤ sÃ¤Ã¤tÃ¤nyt chronotoolsin kanssa.
     Tein sille jopa oman web-sivunkin.
     Osoite: http://bisqwit.iki.fi/source/chronotools.html
     Chronotools on siis se tyÃ¶kalupaketti, jota kehitÃ¤n
     Chrono Triggerin kÃ¤Ã¤nnÃ¶ksen tuottamiseen.
     Dumppasin sillÃ¤ myÃ¶s infin ct-kÃ¤Ã¤nnÃ¶ksen, jota voi
     jatkossa kÃ¤yttÃ¤Ã¤ vertailemiseen ja ideoiden poimimiseen...
   29.6.2003 02:30
     YhÃ¤ sÃ¤Ã¤dÃ¤n chronotoolsin kanssa.
     Nyt alkaa tilanne nÃ¤yttÃ¤Ã¤ jo valoisalta nimien taivutuksen
     suhteen. PÃ¤Ã¤sin samanaikaisesti jyvÃ¤lle snes-assemblerista
     ja Chrono Triggerin ohjelmakoodista, kun perehdyin snes9x:n
     debuggaustoimintoihin ajatuksella. LisÃ¤ksi olen itse
     tekstimateriaalia kÃ¤Ã¤ntÃ¤nyt tÃ¤ssÃ¤ ohessa. Se on hauskaa.
   30.6.2003 04:04
     Nimien taivutuskoodi melkein toimii jo.
   30.6.2003 17:17
     YATTA! Se viimeinkin toimii!
     http://bisqwit.iki.fi/kala/snap/ctdevel/ct-taipus2.png
   2.7.2003 02:06
     Seuraavaksi aikomuksena olisi tehdÃ¤ variable width nx8 font.
     TÃ¤ssÃ¤ vÃ¤lissÃ¤ tein insertoriin tuen kasvattaa fonttia niin,
     ettÃ¤ voi kÃ¤yttÃ¤Ã¤ enemmÃ¤nkin erikoismerkkejÃ¤. SiitÃ¤ on varmaan
     hyÃ¶tyÃ¤ muille kÃ¤Ã¤ntÃ¤jille tulevaisuudessa.
     LisÃ¤ksi annoi muutama pÃ¤ivÃ¤ sitten palan skriptistÃ¤
     Warpille kÃ¤Ã¤nnettÃ¤vÃ¤ksi. HÃ¤n siis liittyi nÃ¤in tÃ¤hÃ¤nkin
     projektiin :)
   7.7.2003 00:23
     Variable width -fontti toimii nyt jo vÃ¤hÃ¤sen. Kiitokset DarkForcelle,
     joka on ystÃ¤vÃ¤llisesti auttanut snes-kysymyksissÃ¤ni. KyllÃ¤ se tÃ¤stÃ¤ ;)
   9.7.2003 01:59
     VÃ¤hÃ¤n pitÃ¤nyt taukoa vÃ¤lissÃ¤, mutta tÃ¤nÃ¤Ã¤n tein lisÃ¤Ã¤ tÃ¶itÃ¤
     vwf:n eteen. Nyt asetekniikat tulevat myÃ¶s tÃ¤llÃ¤ pikkufontilla.
     LÃ¤hes kaikki ongelmat tÃ¤hÃ¤n liittyen on jo korjattu, mutta
     vwf:Ã¤Ã¤ kÃ¤yttÃ¤vien listausten skrollaus bugittaa, ja equip-ruudulla
     on jumitusta, kun peli haluaa piirtÃ¤Ã¤ ruutua uusiksi koko ajan.
   21.7.2003 10:30
     NÃ¤inÃ¤ pÃ¤ivinÃ¤ vietÃ¤n kesÃ¤lomaa Raisiossa. Sellaisina pÃ¤ivinÃ¤
     kun ei huvita mennÃ¤ ulos, kÃ¤Ã¤nnÃ¤n peliÃ¤...
   22.7.2003 02:10
     Mystinen bugi on vaivannut kÃ¤Ã¤nnÃ¶stÃ¤ jo pitkÃ¤Ã¤n.
     Crono ei pysty kÃ¤yttÃ¤mÃ¤Ã¤n tekniikoita vihollisiin ollenkaan.
     Ne kohdistuvat ystÃ¤viin. Olen yrittÃ¤nyt haravoida syytÃ¤, mutta
     se ei ole 1)mikÃ¤Ã¤n lisÃ¤tty koodi, 2)mikÃ¤Ã¤n korvattu 8x8-teksti,
     3)mikÃ¤Ã¤n fonteista. MikÃ¤Ã¤n nÃ¤istÃ¤ ei riko tuota. Olen hieman
     ulalla...
   24.7.2003 20:38
     Mystinen bugi korjaantui mystisesti, kun siivosin skriptistÃ¤
     pois joitakin tyhjiÃ¤ merkkijonoja. EhkÃ¤ se vaikutti.
     LisÃ¤ksi vÃ¤sÃ¤sin ohjelmaan tuen vielÃ¤kin entistÃ¤ suuremmalle
     fontille. Nyt se tukee maksimissaan 735 merkin fonttia.
     PitÃ¤isi riittÃ¤Ã¤ nirsommillekin kÃ¤Ã¤ntÃ¤jille ;)
     LisÃ¤ksi skripti alkaa jo nÃ¤yttÃ¤Ã¤ kivalta: Pikaselauksella
     vastaan tulee enemmÃ¤n suomea kuin englantia.
     Kun tuon scrolling bugin saisi jotenkin eliminoitua...
     Pian voisi alkaa piirrellÃ¤ kuvia. NiitÃ¤ tarvitaan parille
     pelin alkuruudulle. LisÃ¤ksi hahmojen elementtityypit pitÃ¤isi
     editoida.
   26.7.2003 01:46
     Osuin eilen libstdc++:n dokumentaatiohon, ja sitÃ¤ kautta lÃ¶ysin
     SGI:n hash_mapin dokumentaation. Otin hash_mapin kÃ¤yttÃ¶Ã¶n
     insertorissa moneen paikkaan std::mapin tilalle, ja ohjelma
     nopeutui lÃ¤hes 40%, toimien silti edelleen kunnolla.
     LisÃ¤ksi olen kÃ¤Ã¤ntÃ¤nyt lisÃ¤Ã¤.
   29.7.2003 22:26
     Palasin Keravalle ja pÃ¤ivitin tÃ¤hÃ¤n aiheeseen liittyvÃ¤t web-sivut.
   1.8.2003 22:43
     Loin windows-binÃ¤Ã¤rejÃ¤. ctdumpista saa sivuilta ilmaiseksi
     windows-binÃ¤Ã¤rin jos haluaa.
     Muutoin olen lÃ¤hinnÃ¤ sÃ¤Ã¤tÃ¤nyt noita kesken olevia juttuja,
     kuten vwf8:ta varten tekemÃ¤Ã¤ni uutta kÃ¤Ã¤ntÃ¤jÃ¤Ã¤. TyÃ¶tkin
     alkaa taas kohta.
   5.8.2003 01:22
     TyÃ¶t alkoivat. SiispÃ¤ tÃ¤mÃ¤ homma hidastui nyt vÃ¤hÃ¤n.
     Huomasin muuten, ettÃ¤ tuo peli tulostaa taivutetut nimet
     (esim. "Cronon") silmÃ¤nrÃ¤pÃ¤yksessÃ¤ ilman sitÃ¤ viivettÃ¤,
     mikÃ¤ normaalisti on tekstissÃ¤. TÃ¤mÃ¤ on kosmeettinen virhe,
     joka on niin vÃ¤hÃ¤pÃ¤tÃ¶inen etten viitsi nÃ¤hdÃ¤ vaivaa sen
     korjaamiseksi.
     LisÃ¤sin peliin tuen kursiiville fontille. SitÃ¤ kÃ¤ytÃ¤n jossain,
     missÃ¤ englanninkielinen versio kÃ¤ytti lainausmerkkejÃ¤. Perun
     tÃ¤mÃ¤n ehkÃ¤, jos se ei nÃ¤ytÃ¤ hyvÃ¤ltÃ¤...
   5.8.2003 02:35
     LisÃ¤sin tÃ¤hÃ¤n dokumenttiin TODO-osiot.
   9.8.2003 02:45
     SÃ¤Ã¤din tÃ¤llÃ¤ viikolla ohjelmaan fonttien uusiksijÃ¤rjestelijÃ¤n.
     MikÃ¤ tarkoittaa, ettÃ¤ tuli taas vapaata tilaa lisÃ¤Ã¤ ROMiin.
     LisÃ¤ksi kÃ¤Ã¤nnÃ¶s on edennyt taas jonkin verran.
   10.8.2003 01:15
     Nyt sain piirrettyÃ¤ ja patchattua parit grafiikat.
   12.8.2003 01:54
     KÃ¤Ã¤nsin taas noin 2000 riviÃ¤ skriptiÃ¤.
   18.8.2003 01:49
     Kuluneen pÃ¤ivÃ¤n aikana otin ja opettelin kÃ¤yttÃ¶Ã¶n erÃ¤Ã¤n
     snes-assemblerin, xa65. Se tietÃ¤Ã¤ kÃ¤ytÃ¤nnÃ¶ssÃ¤ sen aiemmin
     mainitun kÃ¤Ã¤ntÃ¤jÃ¤projektin loppua. Mutta samalla se
     merkinnee parempaa yllÃ¤pidettÃ¤vyyttÃ¤.
   22.8.2003 00:18
     Viime merkinnÃ¤n jÃ¤lkeen olen selvittÃ¤nyt Chrono Triggerin
     kÃ¤yttÃ¤mÃ¤n kuvienpakkausmenetelmÃ¤n ja tehnyt omat pakkaus-
     ja purkurutiinini. Sen jÃ¤lkeen pitÃ¤isi alkaa muuttamaan
     niitÃ¤ sillÃ¤ keinolla saatuja kuvia - eli alkuruudun tekstiÃ¤
     ja Epochin ohjaintekstejÃ¤.
   23.8.2003 01:15
     VÃ¤hÃ¤n kÃ¤Ã¤nnÃ¶stÃ¤ taas.
     LisÃ¤sin websivulle automaatin, joka kertoo,
     milloin kÃ¤Ã¤nnÃ¶ksen kanssa on viimeksi tehty jotain.
   27.8.2003 02:20
     Noin, nyt kÃ¤Ã¤nnÃ¶s on allekirjoitettu.
       http://bisqwit.iki.fi/ctfin/dev/ctfin-screen2.png
     Lainaan siinÃ¤ vÃ¤hÃ¤n yhtÃ¤ Squaresoftin toisen pelin hahmoa.
   30.8.2003 23:10
     EnsimmÃ¤inen suurista VWF8-ongelmista ratkaistu.
     Item-listaus siis toimii nyt kokonaan vieritystÃ¤ myÃ¶ten.
     Yksi kosmeettinen vika siinÃ¤ tosin on, mutta se ei haitanne ketÃ¤Ã¤n.
   31.8.2003 00:35
     YllÃ¤olevaa linjaa seuraten tech-listan vieritysongelma ratkaistu.
   31.8.2003 01:21
     Equip-left:ssÃ¤ sama...
   31.8.2003 02:23
     Loputkin vwf8-vieritysongelmat ratkaistu.
   31.8.2003 05:05
     Pelailin vÃ¤hÃ¤n huvikseni ja tuloksena syntyi pari sataa riviÃ¤
     taas kÃ¤Ã¤nnÃ¶stÃ¤ sekÃ¤ nimien taivuttimessa olleen erÃ¤Ã¤n vian korjaus.
   4.9.2003 02:49
     Taisteluissa ei nÃ¤emmÃ¤ voi kÃ¤yttÃ¤Ã¤ DMA:ta ollenkaan omiin
     tarkoituksiin. TÃ¤mÃ¤n selvittyÃ¤ sain nyt korjattua taistelun
     tavaralistausruudun.
   17.9.2003 12:48
     Viime ja tÃ¤mÃ¤ viikko on mennyt niin, ettei tÃ¤hÃ¤n projektiin
     ole ehtinyt uhrata toviakaan.
     Joka tapauksessa aion piakkoin jatkaa.
     TÃ¤nÃ¤Ã¤n tÃ¶rmÃ¤sin sivustoon,
       http://radicaldreamers.sourceforge.net/
     Radical Dreamers -pelin kÃ¤Ã¤nnÃ¶ksestÃ¤. KyseessÃ¤ on englanninkielinen
     versio Chrono Triggerin jatko-osasta, ja kaikki kÃ¤Ã¤nnÃ¶smateriaali
     on julkaistu GPL:n alla. PitÃ¤isikÃ¶hÃ¤n tÃ¤tÃ¤kin harkita sittenkin...
   17.9.2003 13:14
     MyÃ¶s tÃ¤mÃ¤ on mielenkiintoinen idea:
       http://sourceforge.net/projects/chronomaster/
   18.9.2003 01:20
     Noin, 1.5 tuntia tÃ¤hÃ¤nkin hommaan vaihteeksi.
     LisÃ¤sin tuen VWF8:lle taistelun tech-listaimessa. Se tosin ei toimi
     vielÃ¤ kokonaan, koska lista katsoo neljÃ¤ riviÃ¤ kerrallaan, mutta
     piirtÃ¤Ã¤ nÃ¤istÃ¤ vain kolme. TÃ¤mÃ¤ vaikeuttaa tilenumeroiden laskentaa
     vieritettÃ¤vÃ¤ssÃ¤ listassa.
   27.9.2003 13:43
     Taas jokin aika viimeisimmÃ¤stÃ¤ edistymistiedotteesta.
     TÃ¤ssÃ¤ muiden tÃ¶iden ohella olen nyt koodannut assembleria.
     Siis sellaista, joka syÃ¶ symbolista 65816-konekieltÃ¤ ja tuottaa
     ulos objektitiedoston, joka odottaa linkkaamista valmiiseen snes-romiin.
     TÃ¤mÃ¤ siksi, kun tuo xa65 ei toimi aivan tarkalleen niin kuin haluan
     ja sen lÃ¤hdekoodi on liian epÃ¤selvÃ¤Ã¤ muokattavaksi.
     TÃ¤mÃ¤n tekeminen kuitenkin alkaa olla loppusuoralla. Vaikutus
     tÃ¤llÃ¤ lopulliseen tuotokseen on aika pieni, mutta saan siitÃ¤
     uuden julkaistavan ohjelman, sekÃ¤ se jÃ¤rkevÃ¶ittÃ¤Ã¤ hieman tuon
     patchinteko-ohjelman rakennetta.
     Tilanne kÃ¤Ã¤nnÃ¶ksestÃ¤ on tÃ¤llÃ¤ hetkellÃ¤ tÃ¤llainen:
      - Dialogista on muutama sata riviÃ¤ vielÃ¤ kÃ¤Ã¤ntÃ¤mÃ¤ttÃ¤.
        - KÃ¤Ã¤ntÃ¤minen ei ole ylen hankalaa, mutta jonkun se vain pitÃ¤Ã¤
          tehdÃ¤.
      - KÃ¤Ã¤nnÃ¶s on kÃ¤ymÃ¤ttÃ¤ lÃ¤pi kÃ¶mpelÃ¶n kielen varalta.
        - Etenkin Frogin lauseet pitÃ¤Ã¤ kÃ¤ydÃ¤ huolella lÃ¤pi.
      - Tekniikoiden kuvaukset pitÃ¤isi keksiÃ¤ kÃ¤Ã¤ntÃ¤Ã¤ jotenkin jÃ¤rkevÃ¤sti.
        Nykyinenkin tilanne sinÃ¤llÃ¤Ã¤n toimisi, mutta haluan parempaa.
        Tila vain on melko vÃ¤hÃ¤inen... PitÃ¤isikÃ¶hÃ¤n niille kokeilla
        kapeampaa fonttia?
      - Taistelun tekniikkaselain bugittaa, se pitÃ¤Ã¤ korjata.
        - Kun se on kunnossa, saan viimein jÃ¤rjesteltyÃ¤ nuo
          kiinteÃ¤nmittaiset taulut eri muotoon, minkÃ¤ pitÃ¤isi
          poistaa ne pituusongelmat, joiden takia tuota hommaa
          aloin yleensÃ¤kin tekemÃ¤Ã¤n.
      - Varusteluruutu tahmaa vÃ¤hÃ¤n. Ei estÃ¤ julkaisua, mutta siitÃ¤
        voi tulla valituksia joiltain. PitÃ¤Ã¤ katsoa mitÃ¤ sille voi tehdÃ¤.
      - NimiÃ¤ taivuttava koodi ei nÃ¤e oikeita nimiÃ¤ kaikkialla.
        Vika esiintyy episodin nimessÃ¤ "Maguksen linna" ja parissa
        asetekniikan nimessÃ¤, joissa taivutetaan hahmon nimeÃ¤.
   28.9.2003 02:49
     Oma assembler toimii.
   1.10.2003 02:08
     TÃ¤nÃ¤Ã¤n olisi illalla pitÃ¤nyt lukea japaninlÃ¤ksyjÃ¤, mutta se
     jÃ¤i tekemÃ¤ttÃ¤. Sen sijaan testailin tuota nimentaivutinta ja
     kÃ¤sittelin ekan windows-Chronotools -tilauksen.
   2.10.2003 16:03
     JapaninlÃ¤ksyt sain kuitenkin tehtyÃ¤ sitten pÃ¤ivÃ¤llÃ¤.
     TÃ¤nÃ¤Ã¤n julkaisin Chronotoolsin GPL:n alaisena.
     Katsoo nyt mitÃ¤ siitÃ¤ seuraa. Kukaan tuskin edes hoksaa sitÃ¤ ;)
   4.10.2003 03:07
     KÃ¤Ã¤nsin taas jonkun 1000 riviÃ¤ skriptiÃ¤.
     Pikaisesti selattuna sitÃ¤ nÃ¤kyisi olevan enÃ¤Ã¤ 100-200 riviÃ¤ jÃ¤ljellÃ¤.
     NÃ¤in sanoin kyllÃ¤ viime updatessakin... En nÃ¤htÃ¤vÃ¤sti ollut riittÃ¤vÃ¤n
     huolellinen tuolloin.
   5.10.2003 24:06
     TÃ¤nÃ¤Ã¤n olen kÃ¤Ã¤ntÃ¤nyt noita loppuja rivejÃ¤. EnÃ¤Ã¤ jÃ¤ljellÃ¤ ovat
     hankalimmat tekstit sekÃ¤ kasa hirviÃ¶iden nimiÃ¤.
     Tekniikkapuolella olen tÃ¤nÃ¤Ã¤n perehtynyt, miten muutetaan erÃ¤itÃ¤
     vuosilukugrafiikoita. SiinÃ¤ onkin vielÃ¤ sÃ¤Ã¤dettÃ¤vÃ¤Ã¤. Peli nimittÃ¤in
     pakkaa niitÃ¤ erÃ¤Ã¤llÃ¤ tavalla...
     Ongelman luonnetta havainnollistava kuvaruutukaappaus:
       http://bisqwit.iki.fi/ctfin/dev/brokengauge.jpg
   10.10.2003 01:52
     Chrono TriggerissÃ¤ on erÃ¤s hahmo, joka puhuu vÃ¤hÃ¤n hassua kieltÃ¤.
     (Ok, on siinÃ¤ useampikin.)
     Mutta tÃ¤llÃ¤ nimenomaisella hahmolla on oma lempinimensÃ¤ pelin
     pÃ¤Ã¤henkilÃ¶stÃ¤. JapaninkielisessÃ¤ versiossa pelistÃ¤ tÃ¤mÃ¤ oli
     selvÃ¤Ã¤, mutta kun peli kÃ¤Ã¤nnettiin englanniksi, tÃ¤mÃ¤ nimivÃ¤Ã¤nnÃ¶s
     otettiin pois toiminnasta, kun sitÃ¤ ei ole niin helppoa tehdÃ¤
     englannin kielessÃ¤. MinÃ¤ joka tapauksessa lisÃ¤sin sen nyt tÃ¤nÃ¤
     iltana suomenkieliseen versioon, suomen kieleen paremmin sopivassa
     muodossa. En kerro siitÃ¤ enempÃ¤Ã¤ etten spoilaa :)
     LisÃ¤ksi kÃ¤Ã¤ntÃ¤mÃ¤ttÃ¶mien repliikkien mÃ¤Ã¤rÃ¤ on nyt enÃ¤Ã¤ jotain 10-20.
     NiitÃ¤ on vÃ¤hÃ¤n siellÃ¤ tÃ¤Ã¤llÃ¤, kun vaikeimmat jÃ¤Ã¤vÃ¤t viimeiseksi.
   12.10.2003 17:27
     LisÃ¤sin viimein illatiivitaivutusmuodon ja parantelin lukuisia
     lauseita. LÃ¤hiaikoina voisi julkaista ensimmÃ¤isen testiversion,
     vaikka tuo vwf8 ei olekaan vielÃ¤ valmis ja dialogin jÃ¤rjestelmÃ¤llinen
     laaduntarkistus on suorittamatta.
   14.10.2003 01:51
     Valmisteluja ekaan testiversiojulkaisuun.
   17.10.2003 14:21
     EnsimmÃ¤inen testiversiojulkaisu. TÃ¤mÃ¤ julkaisu ei ole millÃ¤Ã¤n
     tapaa lopullinen. (1.10.0)
   20.10.2003 22:08
     Mystiset bugit ovat... mystisiÃ¤.
     Julkaisin toisen testiversion. (1.10.1)
   10.11.2003 00:26
     Tilanne on se, ettÃ¤ kÃ¤Ã¤nnÃ¶ksen laaduntarkistus on tÃ¤llÃ¤
     hetkellÃ¤ Warpin kÃ¤sissÃ¤ ja minÃ¤ pidÃ¤n lomaa tÃ¤stÃ¤ projektista,
     jotta saisin jotain muutakin aikaan. Ei riitÃ¤ aivoissa kapasiteetti
     miettiÃ¤ 8 tuntia pÃ¤ivÃ¤ssÃ¤ tÃ¶ihin liittyviÃ¤ koodaushommia ja toiset
     8 tuntia omia koodaushommia. Jatkan noiden VWF-ongelmien parissa
     sitten kun jaksan. Tieto laaduntarkistuksen tilanteesta pÃ¤ivitetÃ¤Ã¤n
     kyllÃ¤ web-sivulle.
   13.11.2003 00:12
     KÃ¤vin lÃ¤pi Warpin tÃ¤hÃ¤nastiset kommentit laaduntarkistuksesta
     ja korjasin skriptistÃ¤ bugin erÃ¤Ã¤n hahmon nimeen liittyen.
     Tarkistuksen tilanne: 27%.
     PS: Kuka keksisi nÃ¤ille suomenkieliset nimet?
          http://bisqwit.iki.fi/ctfin/dev/kisanimet.png
   30.11.2003 02:13
     Integroin eilen Warpin skriptipÃ¤ivitykset ja laitan nyt uuden
     version julkistukseen... Katsoo nyt milloin noita VWF-juttuja
     jaksaisi jatkaa. Olen tuohon DeJapin Star Ocean -projektiinkin
     osallistunut tÃ¤ssÃ¤ ohessa...
   30.12.2003 09:34
     Julkaisin version 1.12.0.
     Uutta tÃ¤ssÃ¤ on ainakin se, ettÃ¤ tavaroiden nimien pituusraja
     on viimein historiaa. Jos lÃ¶ytyy kesken katkeavia tavaroiden
     nimiÃ¤, niistÃ¤ on suotuisaa ilmoittaa meille...
   22.1.2004 20:54
     Sain MerriltÃ¤ skriptipÃ¤ivityksen (hÃ¤n tosiaan ryhtyi
     laaduntarkistustyÃ¶hÃ¶n puoli kuukautta sitten) ja otin
     siitÃ¤ osan muutoksista tÃ¤hÃ¤n mukaan.
   9.3.2004 14:19
     PitkÃ¤Ã¤n aikaan ei ole tapahtunut mitÃ¤Ã¤n.
     Olen pÃ¤Ã¤asiassa laiskotellut odottaessani laaduntarkastajilta
     pÃ¤ivityksiÃ¤. Ja pÃ¤ivittÃ¤nyt nesvideos-sivua:
       http://bisqwit.iki.fi/jutut/nesvideos/
     En ole luopunut tÃ¤stÃ¤ projektista silti - aion saattaa sen loppuun.
     En ole vaan pÃ¤Ã¤ttÃ¤nyt, milloin jatkan jÃ¤ljellÃ¤ olevien
     asioiden kÃ¤sittelyÃ¤.
   10.5.2004 00:56
     Julkaisin version 1.13.0.
     Uutta on pari bugikorjausta ja lauseen muutosta.
   6.6.2004 06:57
     Julkaisin version 1.14.0, joka saa nyt olla virallinen versio.
     TÃ¤rkeimmÃ¤t ongelmat on nyt korjattu: sekÃ¤ tekniikkalistaus ettÃ¤
     hirviÃ¶iden nimet ovat nyt rajoituksettomia pituuden suhteen,
     ja tahmausongelma varustusruudulla on enÃ¤Ã¤ varsin lievÃ¤.
   25.9.2004 03:05 
     Pari pÃ¤ivÃ¤Ã¤ 1.14.0:n julkaisun jÃ¤lkeen siitÃ¤ lÃ¶ytyi vakavia
     virheitÃ¤, joiden takia palattiin takaisin versioon 1.12.0.
     Nyt julkaisin version 1.14.1, jossa toivon mukaan ei ole
     mitÃ¤Ã¤n vakavia virheitÃ¤.
     Vakaviksi virheiksi lasketaan esimerkiksi sellaiset jos joku
     teksti nÃ¤kyy aivan vÃ¤Ã¤rin tai jokin valinta taistelussa tekee
     odottamattomia asioita.
   3.10.2004 23:25
     Julkaisin version 1.14.2. Eroa edelliseen ei ole paljoa -
     olen muuttanut paria sanaa, ja korjannut "invalid checksum"
     -ilmoituksen, jonka emulaattori voi antaa.
   7.11.2004 23:42
     Julkaisin version 1.14.3. Vastaavanlainen pikkukorjaus.
   19.11.2004 20:52
     Useampi henkilÃ¶ on ilmoittanut minulle, ettÃ¤ viimeisin
     ctfin-versio sisÃ¤ltÃ¤Ã¤ outoja ilmiÃ¶itÃ¤ taistelussa - joskus
     viholliset saavat yhtÃ¤kkiÃ¤ tyhjÃ¤stÃ¤ statuksen ja hahmot
     vÃ¤lillÃ¤ kuolevat tuosta noin vain ja muita vastaavia
     omituisuuksia. Julkaisin nyt version 1.14.4, joka korjasi
     virheen ainakin yhdessÃ¤ testatussa tilanteessa. Luultavasti
     useammassakin, toivon mukaan kaikissa.
     SyynÃ¤ virheeseen on se, ettÃ¤ SNESissÃ¤ on kiinteÃ¤ mÃ¤Ã¤rÃ¤ muistia,
     ja on hieman tuurista kiinni, sattuuko lÃ¶ytÃ¤mÃ¤Ã¤n tuota lisÃ¤ttyÃ¤
     fonttirutiinia varten sellaisen muistialueen, jota peli ei tarvitse
     samaan aikaan kuin se fonttirutiini. Aiempi valintani oli ~80 tavun
     kokoinen alue $7E6200 -osoitteesta alkaen, nyt siirsin sen
     $7EFE00-osoitteeseen.
   1.1.2005 20:00
     "Zapper---" ilmoitti, ettÃ¤ Luccan "tÃ¤hystin" toimii oudosti,
     ja sen nÃ¤yttÃ¤mÃ¤t vihollisten HP:t nÃ¤kyvÃ¤t oudon suurina lukuina.
     Vika lÃ¶ytyi helposti, ja korjasin sen.
     TÃ¤mÃ¤n johdosta siis tuli uusi julkaisu: versio 1.14.5.
     LisÃ¤ksi paransin tekstejÃ¤ Eiran pitÃ¤mÃ¤stÃ¤ juhlasta.
     USA:n poliittinen korrektius oli nÃ¤emmÃ¤ iskenyt, ja alkoholijuomat
     olivat muuttuneet lihakeitoksi. KÃ¤vin tilanteen lÃ¤pi japaniversioon
     verraten ja muutin sen vastaamaan lÃ¤hemmÃ¤ksi alkuperÃ¤istÃ¤.
     Nyt tekstissÃ¤ puhutaan viinistÃ¤. AlkuperÃ¤iskielessÃ¤ puhutaan
     sakesta. Sake on japanissa sana, joka voi tarkoittaa sakea tai
     alkoholijuomaa yleensÃ¤. En suostu laittamaan siihen "kaljaa"
     tai "viinaa", koska niistÃ¤ tulee mieleen muita kÃ¤sityksiÃ¤.
     MyÃ¶s siideri olisi harkittavissa, huomioiden valtavat mÃ¤Ã¤rÃ¤t,
     joita kyseisessÃ¤ juhlassa juodaan...
   2.1.2005 16:54
     Kokeeksi vaihdoin Aylan nimen Eiraksi, kun sen viimein onnistuin
     tekemÃ¤Ã¤n. Ks. selitys alla. Versio 1.14.5.1.
   18.9.2005 18:35
     Nyrkki1 muutettu Nyrkiksi, joitakin pieniÃ¤ dialogimuutoksia
     ja -korjauksia tehty ja Pormestarin Talo palautettu takaisin
     maailmankartalle. Versio 1.14.5.2. Kiitokset Markku JÃ¤rvenpÃ¤Ã¤lle.
     HUOM: Ã„lÃ¤ nuku Cronon huoneessa. Peli kaatuu siihen. TÃ¤mÃ¤
     korjataan seuraavassa versiossa. NiinikÃ¤Ã¤n Cronon huoneessa
     joskus kÃ¤velevÃ¤ poika ei normaalisti kuulu sinne.
   21.9.2005 01:17
     Korjattu pari bugia lisÃ¤Ã¤ ja julkaistu versio 1.14.6.
     Peli ei enÃ¤Ã¤ kaadu Cronon huoneessa. LisÃ¤ksi lisÃ¤sin osan
     kÃ¤Ã¤nnÃ¶stiimistÃ¤ erÃ¤Ã¤seen kohtaan peliÃ¤ NPC:iksi...
   29.9.2005 21:49
     Hups, versio 1.14.6 oli susi. Peli kaatui Leenen aukiolla.
     Korjattu tÃ¤ssÃ¤ julkaisussa! (1.14.6.1)
     Ja kuten tavallista, joitakin tekstejÃ¤ on jÃ¤lleen ehditty
     muuttaa nÃ¤iden kahden julkaisun vÃ¤lillÃ¤...
   4.3.2012 02:45
     Uusi versio julkaistu (1.15).
     Muutamia tekstejÃ¤ on muutettu ja jokunen bugi korjattu.
     Huom: Kaupoissa ja varusteluruuduilla kÃ¤ytetty pieni fontti
     ei toimi oikein monissa uusimmissa emulaattoreissa. NÃ¤istÃ¤
     emulaattoreista voi lÃ¶ytyÃ¤ asetus (allow PPU updates out of v-blank),
     jolla se lÃ¤htee toimimaan. Korjataan jossain tulevassa julkaisussa.
   8.12.2012 21:08
     Julkaistu versio 1.15.1. SisÃ¤ltÃ¤Ã¤ pieniÃ¤ tekstikorjailuja.

NIMET
  Kuten yleensÃ¤ on, tÃ¤mÃ¤nkin pelin nimistÃ¶ kantaa mukanaan tiettyÃ¤
  kulttuurillista historiaa. KÃ¤Ã¤nnettÃ¤essÃ¤ peli toiselle kielelle
  nÃ¤mÃ¤ kulttuurilliset tiedot saattavat jÃ¤Ã¤dÃ¤ pimentoon.
  SelitÃ¤n tÃ¤ssÃ¤ sen takia muutamia nimiÃ¤:

    Crono
      Chrono/Crono -alkuiset sanat monissa kielissÃ¤ tarkoittavat jotain
      aikaan liittyvÃ¤Ã¤. Kronologinen = ajallinen/aikajÃ¤rjestyksellinen.
    Frog
      TÃ¤mÃ¤ sana tarkoittaa englannin kielessÃ¤ sammakkoa.
      JapaninkielisessÃ¤ pelissÃ¤ tÃ¤mÃ¤n hahmon nimi oli Kaeru,
      joka tarkoittaa japanissa sammakkoa. Suomenkielinen
      sana "sammakko" ei mahdu viiteen merkkiin. Nimi "konna"
      ei ehkÃ¤ ole hyvÃ¤ vaihtoehto...
      Sitten on tietysti "olmi", joka on myÃ¶s sammakkoelÃ¤in,
      mutta moni varmaan assosioi sen enemmÃ¤n erÃ¤Ã¤seen Tolkienin
      teokseen ennemmin kuin biologiseen nimikkeeseen, joka olisi
      epÃ¤tÃ¤smÃ¤llinenkin tÃ¤ssÃ¤ tapauksessa.
    Eira:
      AlkuperÃ¤iskielessÃ¤ (japanissa) Eira, USA-versiossa Ayla.
      EpÃ¤ilen, ettÃ¤ Eira on lÃ¤hempÃ¤nÃ¤ haettua. Kyseisen nimen
      historiasta voi lukea mm. Eiran Sairaalan kotisivuilta.
      EpÃ¤ilen, ettÃ¤ Ayla on vain USA-ihmisten huono tulkinta
      japanilaisittain kirjoitetusta nimestÃ¤. Ayla on lisÃ¤ksi
      suomalaisille vaikea lukea rikkoutuneen vokaaliharmonian
      takia.
    Magus:
      Sana "magic" tarkoittaa englanninkielessÃ¤ taikaa.
      JapaninkielisessÃ¤ pelissÃ¤ tÃ¤mÃ¤n hahmon nimi oli Maou.
      Se tarkoittaa taikuuden kuningasta ja paholaista.
    Guardia:
      Sana "guard" tarkoittaa englanninkielessÃ¤ vartijaa ja vartioimista.
    Masamune:
      Masamune on Japanissa vastaavanlainen tarunhohtoinen miekka-ase
      kuin englantilaisessa kulttuurissa on excalibur. Masamune esiintyy
      lÃ¤hes jokaisessa japanilaisessa RPG:ssÃ¤.
      Erikoista kuitenkin on, ettÃ¤ tÃ¤mÃ¤n pelin japaninkielisessÃ¤
      versiossa nÃ¤mÃ¤ veikot Masa & Mune ovatkin Guran & Rion.
    Zeal:
      Englanninkielinen sana, joka tarkoittaa intohimoa.
    Janus:
      Janus on Saturnuksen kuudes kuu. Janus oli kreikan mytologiassa
      porttien ja oviaukkojen jumala, jonka nimestÃ¤ tulee myÃ¶s tammikuun
      englanninkielinen nimi January. TÃ¤llÃ¤ faktalla ei ole paljoakaan
      tekemistÃ¤ tÃ¤mÃ¤n hahmon kanssa.
    Truce:
      TÃ¤mÃ¤ englanninkielinen sana tarkoittaa aselepoa/vÃ¤lirauhaa.

  Huomioita joistakin muista nimistÃ¤:

    Dalton:
      Ei sen kummempi nimi. EhkÃ¤ joillekin tuttu Lucky Lukesta.
    Ossi:
      Englantiversiossa Ozzie.
      Japaniversiossa nimi oli Vinnegar, joka tarkoittaa ETIKKAA.
    ViiltÃ¤jÃ¤:
      Englantiversiossa Slash, japaniversiossa sotonori kenshi soisÃ´.
      SanakirjakÃ¤Ã¤nnÃ¶s tÃ¤stÃ¤ olisi
      "ulkopuoliset mittaukset miekkailija SOIJAKASTIKE".
      Ei aavistustakaan, mitÃ¤ se tarkoittaa.
    Kirppu:
      Englantiversiossa Flea, joka tarkoittaa kirppua.
      TÃ¤mÃ¤ henkilÃ¶ on japaninkielisessÃ¤ versiossa sora ma shi mayonÃª.
      Babelfishin ja sanakirjan avulla tÃ¤stÃ¤ syntyi kÃ¤Ã¤nnÃ¶s
      "tyhjÃ¤ demoninen samurai MAJONEESI". TÃ¤ssÃ¤ on yhtÃ¤ vÃ¤hÃ¤n
      jÃ¤rkeÃ¤ kuin edellisessÃ¤.
    Belsassar:
      TÃ¤mÃ¤ nimi oli englanninkielisessÃ¤ versiossa Belthasar. En tiedÃ¤,
      mitÃ¤ se oli japaninkielisessÃ¤. Kirjoitusasu on muutettu vastaamaan
      Raamatussa kÃ¤ytettyÃ¤ kirjoitusasua. Belsassarista voi lukea Raamatusta
      Danielin kirjasta. Raamatun Belsassarilla tosin ei ole mitÃ¤Ã¤n tekemistÃ¤
      tÃ¤mÃ¤n pelin Belsassarin kanssa.
    Nagaatti:
      EnglanninkielisessÃ¤ versiossa Naga-ette, japaninkielisessÃ¤
      versiossa Miannu. En tiedÃ¤, mikÃ¤ tÃ¤mÃ¤n idea on.
    Nuu:
      EnglanninkielisessÃ¤ "nu", japaninkielisessÃ¤ "nuu".
      Chrono Trigger Character Library mainitsee tÃ¤stÃ¤ hieman
      heikon japanintaitoni mukaan "tÃ¤mÃ¤n pelin masokistisin olio".
    Gonzales:
      TÃ¤mÃ¤ robotti oli englanninkielisessÃ¤ versiossa Gato,
      mutta alunperin japaninkielisessÃ¤ Gonzales. Valitsin nimen,
      jonka suomalaiset todennÃ¤kÃ¶isemmin Ã¤Ã¤ntÃ¤vÃ¤t oikein.
    Melchior:
      Japaniversiossa nimi on Bosshu. "Huh?"

  Listaa jatketaan kun jaksetaan :)

VAIKEITA PULMIA
  - Chrono Trigger on tÃ¤ynnÃ¤nsÃ¤ sellaisia ilmauksia kuin "huh?",
    "argh", "aaah", "oh", "mwa ha ha", "harharhar", "augh",
    "gyah ha ha", jne.
    NÃ¤itÃ¤ on melkoisen hankala kÃ¤Ã¤ntÃ¤Ã¤ suomeksi. Sellaiseksikaan
    ei voi jÃ¤ttÃ¤Ã¤, koska 1) suomalainen ei lue niitÃ¤ samalla
    tavalla kuin englantilainen (syntyy vÃ¤Ã¤rÃ¤ kuvitelma Ã¤Ã¤nestÃ¤)
    ja 2) ne eivÃ¤t nÃ¤ytÃ¤ suomalaisilta.
    PitÃ¤isi kai lukea enemmÃ¤n Aku Ankkaa, niin tietÃ¤isi miten
    ne pitÃ¤isi kÃ¤Ã¤ntÃ¤Ã¤... Jos joku "ohoo." tuntuu hÃ¶lmÃ¶ltÃ¤, se
    johtuu juuri tÃ¤stÃ¤.
  - Chrono Trigger on myÃ¶skin tÃ¤ynnÃ¤nsÃ¤ sellaisia ilmaisuja
    kuin "come on", "beat it", "make up", "put up", joille ei
    ole mitÃ¤Ã¤n suoraa vastaavaa ilmaisua suomen kielessÃ¤. NiitÃ¤
    on varsin hankala kÃ¤Ã¤ntÃ¤Ã¤, ja usein riippuvat tilanteesta,
    joissa niitÃ¤ kÃ¤ytetÃ¤Ã¤n.
  - Chrono TriggerissÃ¤ on paljon slangia. Sen lisÃ¤ksi ettÃ¤ niitÃ¤
    ilmaisuja on paikoin vaikea ymmÃ¤rtÃ¤Ã¤, niitÃ¤ on vaikea kÃ¤Ã¤ntÃ¤Ã¤
    suomeksi, koska ero puhekielen ja kirjakielen vÃ¤lillÃ¤ on
    kirjallisessa ilmaisussa vÃ¤hÃ¤n liiankin selvÃ¤. TÃ¤ten
    suomiversiossa on enemmÃ¤n kirjakieltÃ¤ kuin englantiversiossa...
  - Sitten on tietysti Frog, joka englantiversiossa puhuu
    shakespearen aikaista englantia, ja Eira, joka puhuu
    kuin alkuasukas ainakin...


TYÃ–RYHMÃ„
  Projektinhallinta
    Bisqwit
  Grafiikka
    Bisqwit
  Debug, Hacking
    Bisqwit
  KÃ¤Ã¤nnÃ¶s
    Bisqwit, Warp, Merri, Shiryuu

  TyÃ¶ pohjautuu Chrono Triggerin viralliseen englanninkieliseen
  versioon. KÃ¤Ã¤nnÃ¶ksen tekoon luodun tyÃ¶kaluohjelmiston kotisivu on
  http://bisqwit.iki.fi/source/chronotools.html (englanninkielinen).

LINKKEJÃ„
  Joel Yliluoma     http://iki.fi/bisqwit/ ; bisqwit @ iki piste fi
  Vesa Piittinen    http://merri.net/      ; vesa @ merri piste net
  Warp              http://iki.fi/warp/