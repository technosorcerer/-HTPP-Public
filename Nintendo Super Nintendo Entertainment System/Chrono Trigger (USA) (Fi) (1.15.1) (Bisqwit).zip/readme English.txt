
Chrono Trigger
Finnish translation - version 1.15.1 - http://bisqwit.iki.fi/ctfin/
Translator comments - written by Joel Yliluoma

ACCESS RIGHT
  Chrono Trigger's Finnish translation has been made
  the so-called fan-to-fan principle, i.e.
  it is freely available to anyone who wants it
  Chrono Trigger in Finnish.
  No one shall be charged any fee
  tÃ¤stÃ¤ patchista.

  ROMs may not be included with the patch, nor
  pre-patched ROMs may be distributed.
  
  The patch must also not be distributed without this text file.
  However, someone is interested in this text.

YOU NEED
  You will need Chrono Trigger's English ROM file.
  Its length should be 4194816 or 4194304 bytes.
  If the length is 4194304 bytes, use the file
  ctpatch-nohdr.ips. If the length is 4194816 bytes,
  use the file ctpatch-hdr.ips.
  Place the English ROM and the Finnish patch in the same place
  directory with the same name (except for the decision, ie
  e.g. chrono.smc, chrono.ips) and play. Original ROM
  does not change like this for any reason.
  If you want to permanently change the ROM to Finnish, please
  first back up your ROM and then use the patch
  introduce some ips patching software.

SITUATION
  - The so-called official translation has now been published!
  - Read the news for more information.

KNOWN ERRORS:
  - Some place names (e.g. Choras Guesthouse) are interrupted.
  - Equipment change sometimes produces strange E-letters. Don't worry.
  - Stores and equipment box do not work on the correct SNES console
    as well as in some emulators. Zsnes still works,
    and in Snes9x if you allow the "out of v-blank PPU updates" option.

TOTAL CREATED:
  - translation (300 kB text)
  - various extensions to the game's dialog font and code
  - Finnish symbols for fonts
  - italic dialog
  - variable-width 8pix font and program codes for its processing
  - replaced the game item lists and their search routines with their own
  - replaced the game's technical name lists and their search routines with their own
  - replaced the game's monster name lists and their search routines with their own
  - element images (thunder, fire, etc.)
  - character name inflection feature and program code
  - crononick feature (a Cronon nickname used by a protagonist)
  - added to the change of equipment the amount of goods as it was jap. version
  - added Warp and Bisqwit to the game as additional NPCs in one place
  - battlemode selection -ruutu
  - image compression and decompression routines
  - signature support and signature

NEWS AND DEVELOPMENT HISTORY (latest below):
   9.9.2002
     I started hacking Chrono Trigger.
   11.9.2002
     The size has a working dump truck for the game's texts and fonts,
     as well as a functional insertor for those same. First Screenshot
     (ctquack.png) taken! :)
   28.11.2002
     I updated this README file. The situation at the moment
     is that I haven’t done much else in a couple of months
     than translated someone's less than a hundred lines of text into Finnish.
     There was little else to do. Should get those bigger ones
     obstacles to be resolved first:
       - the game should get the name bent (with a snes-assembler!)
       - find all texts in ROM
       - a solution to the lack of space in the names of items
         (ten character length limit for goods, technology
          and in the names of monsters is pretty tough on the Finnish language.
          For example, how would you translate "Ruby Armor"?)
   23.6.2003
     A couple of last days with chronotools.
     I even made it my own web page for it.
     Address: http://bisqwit.iki.fi/source/chronotools.html
     So Chronotools is the toolkit we are developing
     To produce a translation of Chrono Trigger.
     I also dumped an infin ct translation that can
     will be used in the future to compare and extract ideas ...
   29.6.2003 02:30
     Still adjusting with chronotools.
     Now the situation begins to look already bright on the inflection of names
     regarding. At the same time, I got to the grain from the snes-assembler
     and Chrono Trigger program code when I became familiar with snes9x
     debugging operations with the idea. Besides I actually
     text material translated here. It is fun.
   30.6.2003 04:04
     The name inflection code almost works already.
   30.6.2003 17:17
     YATTA! It finally works!
     http://bisqwit.iki.fi/kala/snap/ctdevel/ct-taipus2.png
   2.7.2003 02:06
     The next intention would be to make a variable width nx8 font.
     In between, I did an insert in the support to increase the font so that
     that you can use more special characters. That's probably it
     benefit other translators in the future.
     Also, a few days ago gave a piece of the script
     For Warp to turn. So he joined here too
     to the project :)
   7.7.2003 00:23
     The Variable width font now works a bit. Thanks to DarkForce,
     who has kindly helped with my snes questions. Yes it is here;)
   9.7.2003 01:59
     A little had a break in between, but today I did more work
     in front of vwf. Now weapon techniques are also coming in this little font.
     Almost all the problems in this regard have already been fixed, however
     vwf: scrolling listings using bug bits, and on the equip screen
     there is a hang when the game wants to draw the screen new all the time.
   21.7.2003 10:30
     These days I spend my summer vacation in Raisio. On such days
     when you don't like to go out, I turn the game ...
   22.7.2003 02:10
     The mystical bug has been bothering the translation for a long time.
     Crono is unable to use techniques on enemies at all.
     They are aimed at friends. I tried to rake syytÃ¤, but
     it is not 1) any code added, 2) no replaced 8x8 text,
     3) None of the fonts. None of these break that. I am a little
     ulalla ...
   24.7.2003 20:38
     The mystical bug was mysteriously fixed when I cleaned up the script
     away some blank strings. Maybe it worked.
     In addition, I support the program even more
     fontille. Now it supports a maximum font of 735 characters.
     Should be enough for even picky translators;)
     In addition, the script is already starting to look nice: Quick browse
     more Finnish than English will come against.
     When that scrolling bug gets somehow eliminated ...
     Soon you could start drawing pictures. They are needed for a couple
     to the start screen of the game. In addition, the character element types should
     edit.
   26.7.2003 01:46
     I hit the libstdc ++ documentation yesterday, and that's how I found
     SGI's hash_mapin documentation. I introduced hash_map
     in the insertor in many places instead of the std :: folder, and the program
     accelerated by almost 40%, still operating properly.
     Besides, I add the kÃ¤Ã¤ntÃ¤nyt.
   29.7.2003 22:26
     I returned to Kerava and updated the web pages related to this topic.
   1.8.2003 22:43
     I created windows binaries. ctdump is available for free on the site
     windows binary if desired.
     Otherwise, I lÃ¤hinnÃ¤ sÃ¤Ã¤tÃ¤nyt those among the stuff,
     like the new compiler I made for vwf8. I work
     the point begins again.
   5.8.2003 01:22
     Work began. However, this thing has slowed down a bit now.
     By the way, I noticed that that game prints the inflected names
     (e.g. "Cronon") in the blink of an eye without delay,
     which is normally in the text. This is a cosmetic flaw,
     who is so insignificant i don't bother to see the trouble of it
     to remedy.
     I added game support for italic fonts. I'll use it somewhere,
     where the English version used quotation marks. Peru
     this maybe if it doesn't look good ...
   5.8.2003 02:35
     I added TODO sections to this document.
   9.8.2003 02:45
     I adjusted this week's program with a font reorganizer.
     Which means there was again free space to add to the ROM.
     In addition, the translation has made some progress again.
   10.8.2003 01:15
     Now I got to draw and patch a couple of graphics.
   12.8.2003 01:54
     I turned again to about 2000 lines of script.
   18.8.2003 01:49
     During the past day, I introduced and learned a batch of
     snes-assemblerin, xa65. It knows practically its past
     the end of the said translator project. But at the same time it
     means better maintainability.
   22.8.2003 00:18
     Last merkinnÃ¤n jÃ¤lkeen I selvittÃ¤nyt Chrono Trigger
     using the image compression method and made their own compression
     and my unpacking routine. After that, it should start to change
     those images obtained by that means — that is, the text on the front screen
     and Epoch's control texts.
   23.8.2003 01:15
     VÃ¤hÃ¤n kÃ¤Ã¤nnÃ¶stÃ¤ taas.
     I added a vending machine to the website that says
     when was the last time something was done with the translation.
   27.8.2003 02:20
     About, now the translation has been signed.
       http://bisqwit.iki.fi/ctfin/dev/ctfin-screen2.png
     I'll quote a little bit of Squaresoft's second game character in it.
   30.8.2003 23:10
     The first of the major VWF8 problems solved.
     So item listing now works entirely with scrolling.
     One cosmetic flaw in it though is, but it doesn’t hurt anyone.
   31.8.2003 00:35
     Following the line above, the tech list scrolling problem solved.
   31.8.2003 01:21
     Equip-left:ssÃ¤ sama...
   31.8.2003 02:23
     Remaining vwf8 scrolling issues resolved.
   31.8.2003 05:05
     I played a little for fun and the result was a couple of hundred lines
     again, from the translation, as well as the correction of a bug in the name inflector.
   4.9.2003 02:49
     In battles, no one can use DMA on their own at all
     purposes. After finding out about this, I could now fix the battle
     goods listing box.
   17.9.2003 12:48
     Last and this week has gone so far as not to this project
     have not had time to sacrifice.
     Anyway, I will continue soon.
     Today I came across a site
       http://radicaldreamers.sourceforge.net/
     About the translation of Radical Dreamers. This is in English
     a version of the sequel to Chrono Trigger, and all the translation material
     has been published under the GPL. Maybe this should be considered anyway ...
   17.9.2003 13:14
     This is also an interesting idea:
       http://sourceforge.net/projects/chronomaster/
   18.9.2003 01:20
     About, 1.5 hours for this job.
     I added support for VWF8 in the battle tech list. It doesn't work, though
     still entirely because the list looks four lines at a time, but
     draw only three of these. This makes it difficult to calculate account numbers
     in a scrollable list.
   27.9.2003 13:43
     Again, some time from the latest progress report.
     Here, among other tÃ¶iden I am now hard-coded assembly language.
     That is, one that eats the symbolic machine language 65816 and produces
     out an object file waiting to be linked to the finished snes-rom.
     This is because when that xa65 doesn't work quite exactly the way I want it to
     and its source code is too vague to edit.
     However, doing this is starting to be nearing completion. Effect
     here the final output is pretty small but i get from it
     a new program to be released, and it makes a little sense of that
     the structure of the patching program.
     The situation with the translation at the moment is as follows:
      - There are a few hundred lines of dialogue still untranslated.
        - Translating isn't overly awkward, but for someone it just keeps
          threat.
      - The translation is unnecessary in case of clumsy language.
        - Especially Frog's sentences need to be carefully reviewed.
      - Descriptions of techniques should be invented to translate somehow sensibly.
        Even the current situation would work on its own, but I want better.
        The space just is pretty small ... I should give them a try
        narrower font?
      - The battle technology browser bugs, it needs to be fixed.
        - When it's okay, I'll finally get those arranged
          fixed-sized boards in a different shape, which should
          eliminates the length issues that cause that job
          I usually started doing.
      - Equipment box slightly sticky. Not blocking the release, but about it
        there may be complaints from some. Have a look at what can be done about it.
      - Name inflectional code doesn't see real names everywhere.
        The bug appears in the episode's title "Castle of the Magus" and with
        in the name of weapon technology, in which the name of the character is inflected.
   28.9.2003 02:49
     My assembler works.
   1.10.2003 02:08
     I should have read Japanese homework tonight, but it
     left undone. Instead, I tested that name inflector and
     I processed my first windows-Chronotools order.
   2.10.2003 16:03
     However, I got to do my Japanese homework that day.
     Today I published Chronotools under the GPL.
     Now look at what follows. Hardly anyone can even hook it;)
   4.10.2003 03:07
     I turned again to someone with 1000 lines of script.
     When scrolled quickly, it would appear that there are only 100-200 lines left.
     That's how I said yes during the last update ... I didn't seem to have had enough
     careful at the time.
   5.10.2003 24:06
     Today I am kÃ¤Ã¤ntÃ¤nyt those endings rivejÃ¤. There are still
     the most awkward texts as well as a pile of monster names.
     Technology side, today I am familiar with how to change erÃ¤itÃ¤
     year graphs. It still has to be adjusted. The game was named
     pack them in a way ...
     Screenshot illustrating the nature of the problem:
       http://bisqwit.iki.fi/ctfin/dev/brokengauge.jpg
   10.10.2003 01:52
     Chrono Trigger has a character who speaks a little funny language.
     (Ok, there are more to it.)
     But this particular character has his own nickname for the game
     the protagonist. In the Japanese version of the game, this was
     obvious, but when the game was translated into English, this name version
     was taken out of action when it is not so easy to do
     in English. Anyway, I added it now today
     in the evening to the Finnish version, better suited to the Finnish language
     in terms of. I won't tell you more I won't spoil :)
     In addition, the number of untranslated replicas is now no more than 10-20.
     There’s a little bit of it out here when the hardest ones last.
   12.10.2003 17:27
     I finally added a form of illative inflection and improved numerous
     sentences. A first test version could be released soon,
     although that vwf8 is not yet complete and the dialogue is systematic
     the quality check has not been performed.
   14.10.2003 01:51
     Preparations for the first test release.
   17.10.2003 14:21
     First test release. This release is by no means
     meet the final. (1.10.0)
   20.10.2003 22:08
     Mystical bugs are ... mystical.
     I released another test version. (1.10.1)
   10.11.2003 00:26
     The situation is that the quality control of the translation is here
     currently in Warp's hands and I'm taking a vacation from this project,
     to get something else done. Not enough brain capacity
     think 8 hours a day about work-related coding chores and others
     8 hours of their own coding chores. I will continue with those VWF problems
     then when I can. Information on the status of the quality check will be updated
     yes to the web page.
   13.11.2003 00:12
     I went through Warp's comments to date on the quality review
     and fixed a bug in the script regarding the name of a character.
     Status of revision: 27%.
     PS: Who would come up with Finnish names for these?
          http://bisqwit.iki.fi/ctfin/dev/kisanimet.png
   30.11.2003 02:13
     Yesterday I integrated the Warp script updates and now I put a new one
     version release ... Now look at those VWF stuff
     could go on. I'm at that DeJapin Star Ocean project,
     participated in this attachment ...
   30.12.2003 09:34
     I released version 1.12.0.
     What is new here is at least that the length limit of the names of the goods
     is finally history. If found among the intermittent goods
     names, it is a good idea to let us know ...
   22.1.2004 20:54
     I got a script update from Merri (he actually did
     quality control work half a month ago) and I took
     of that part of the changes accordingly.
   9.3.2004 14:19
     Nothing has happened in a long time.
     I was expecting a quality pÃ¤Ã¤asiassa slacking
     updates. And updated the nesvideos page:
       http://bisqwit.iki.fi/jutut/nesvideos/
     I haven’t given up on this project anyway - I’m going to complete it.
     I haven’t just decided when to continue with the rest
     handling matters.
   10.5.2004 00:56
     I released version 1.13.0.
     What's new is a couple of bug fixes and sentence changes.
   6.6.2004 06:57
     I released version 1.14.0, which can now be the official version.
     The main problems have now been fixed: both the listing of technology and that
     the names of the monsters are now unlimited in length,
     and the stickiness problem on the equipment screen is still quite mild.
   25.9.2004 03:05 
     A couple of days after the release of 1.14.0, serious
     errors that reverted back to version 1.12.0.
     Now I released version 1.14.1, which I hope is not
     no serious mistakes.
     Serious mistakes are, for example, those if someone
     the text looks completely wrong or some choice in battle makes
     unexpected things.
   3.10.2004 23:25
     I released version 1.14.2. There is not much difference between the previous one -
     I have changed a couple words, and corrected the "invalid checksum"
     message that the emulator can issue.
   7.11.2004 23:42
     I released version 1.14.3. Similar minor repair.
   19.11.2004 20:52
     Several people have informed me that the latest
     The ctfin version contains strange phenomena in battle - sometimes
     Enemies suddenly get scratch status and characters
     in between die from that only and and the like
     oddities. I now released version 1.14.4 which fixed it
     error in at least one of the situations tested. Probably
     in several, hopefully all.
     The reason for the error is that there is a fixed amount of memory in the SNES,
     and it's a bit of luck to see if that happens to be found
     for a font routine, a memory area that the game does not need
     at the same time as that font routine. My previous choice was ~ 80 bytes
     size range starting at $ 7E6200, now I moved it
     $ 7EFE00.
   1.1.2005 20:00
     "Zapper ---" reported that Lucca's "hob" works strangely,
     and the enemy HPs it shows appear in oddly large numbers.
     The fault was easily found and I fixed it.
     As a result, a new release came out: version 1.14.5.
     In addition, I improved the texts about the party held by Eira.
     US political correctness was more struck, and alcoholic beverages
     had turned into meat soup. I went through the situation to the Japanese version
     compared and I changed it to match closer to the original.
     Now the text talks about wine. Spoken in the original language
     sakesta. Sake is a word in Japan that can mean sake or
     alcohol in general. I don't agree to put "beer" in it
     or "liquor," because they come to mind other perceptions.
     Cider should also be considered, given the huge amounts,
     who are drunk at that party ...
   2.1.2005 16:54
     As an experiment, I changed Ayla’s name to Eira when I finally succeeded
     to do. See explanation below. Version 1.14.5.1.
   18.9.2005 18:35
     Fist1 changed to Fist, some minor dialog changes
     and repairs made and the Mayor's House restored
     on the world map. Version 1.14.5.2. Thanks to Markku Järvenpää.
     NOTE: Do not sleep in Crono's room. The game crashes into it. This
     will be fixed in the next version. Likewise, in Crono's room
     sometimes a walking boy does not normally belong there.
   21.9.2005 01:17
     Fixed a couple of bugs added and released version 1.14.6.
     The game no longer crashes in Crono's room. In addition, I added a section
     turn a team into an NPC at some point in the game ...
   29.9.2005 21:49
     Oops, version 1.14.6 was a wolf. The game crashed in Lee's Square.
     Fixed in this release! (1.14.6.1)
     And as usual, some texts have been reappeared again
     change between these two releases ...
   4.3.2012 02:45
     New version released (1.15).
     A few texts have been changed and some bugs fixed.
     Note: A small font used in shops and equipment boxes
     does not work properly in many newer emulators. Of these
     emulators can be set (allow PPU updates out of v-blank),
     with which it begins to operate. Will be fixed in a future release.
   8.12.2012 21:08
     Released version 1.15.1. Includes minor text corrections.

NAMES
  As usual, the nomenclature of this game carries with it a certain
  cultural history. When translating the game to another language
  this cultural information may be left in the dark.
  Here are why I will explain a few names:

    Chrono
      Words beginning with Chrono / Crono in many languages ​​mean something
      time related. Chronological = chronological / chronological.
    Frog
      This word means frog in English.
      In a Japanese game, the name of this character was Kaeru,
      which means frog in Japan. In Finnish
      the word "frog" does not fit in the five characters. Name "frog"
      may not be a good option ...
      Then there is, of course, "Olmi," which is also an amphibian,
      but many probably associate it more with one Tolkien
      to a work rather than to a biological title that would be
      inaccurate even in this case.
    Snow:
      In the original language (Japan) Eira, in the US version Ayla.
      I suspect Eira is closer to being sought. That name
      history can be read e.g. From the Eira Hospital website.
      I suspect Ayla is just a poor interpretation of the US people
      of a name written in Japanese. Ayla is in addition
      it is difficult for Finns to read a broken vocal harmony
      because of.
    Magus:
      The word "magic" in English means magic.
      In a Japanese game, the name of this character was Maou.
      It means the king of magic and the devil.
    Guard:
      The word "guard" in English means guard and guarding.
    Masamune:
      Masamune is a similar fabulous sword weapon in Japan
      than in English culture there is Excalibur. Masamune occurs
      in almost every Japanese RPG.
      What is special, however, is that this game is in Japanese
      in the version these Veikos Masa & Mune are indeed Guran & Rio.
    Zeal:
      An English word that means passion.
    Janus:
      Janus is the sixth moon of Saturn. Janus was in Greek mythology
      the god of gates and doorways, whose name also becomes January
      English name January. There is not much to this fact
      to do with this character.
    Truce:
      This English word means ceasefire / truce.

  Notes on some other names:

    Dalton:
      Not its weird name. Maybe some are familiar with Lucky Luke.
    Ossi:
      Englantiversiossa Ozzie.
      In the Japanese version, the name was Vinnegar, which means VINEGAR.
    Viiltäjä:
      In the English version Slash, in the Japanese version sotonori Kenshi soisÃ´.
      A dictionary translation of this would be
      "external measurements of swordsman soy sauce".
      No idea what that means.
    Flea:
      In the English version, Flea, which means flea.
      This person is in the Japanese version of sorghum ma shi mayonÃª.
      With the help of Babelfish and the dictionary, a translation of this was born
      "an empty demonic samurai with your mayonnaise." Here's the same bit
      makes more sense than the previous one.
    Belsassar:
      This name was in the English version of Belthasar. I don't know
      what it was in Japanese. The spelling has been changed to match
      The script used in the Bible. You can read about Belshazzar in the Bible
      From the book of Daniel. Belshazzar of the Bible, however, has nothing to do
      with Belshazzar of this game.
    Nagaatti:
      In the English version of Naga-ett, in the Japanese version
      version of Miannu. I don't know what this idea is.
    Country:
      In English "nu", in Japanese "nuu".
      The Chrono Trigger Character Library mentions this a bit
      according to my weak Japanese skills, "the most masochistic object of this game."
    Gonzales:
      This robot was in the English version of Gato,
      but originally in Japanese Gonzales. I chose a name
      which Finns are more likely to pronounce correctly.
    Melchior:
      In the Japanese version, the name is Bosshu. "Huh?"

  The list will continue when you can :)

DIFFICULT PROBLEMS
  - Chrono Trigger is full of phrases like "huh?",
    "argh", "aaah", "oh", "mwa ha ha", "harharhar", "augh",
    "gyah ha ha", jne.
    These are quite difficult to translate into Finnish. That's it
    can't leave because 1) a Finn doesn't read them at the same time
    way than English (a false imagination arises from the vote)
    and 2) they don't look Finnish.
    I guess I should read more Aku Duck so I know how
    they should be translated ... If someone "oops." feels silly, it
    is because of this.
  - Chrono Trigger is also full of such expressions
    kuin "come on", "beat it", "make up", "put up", joille ei
    there is no direct equivalent expression in Finnish. They
    is quite awkward to translate, and often depends on the situation
    where they are used.
  - Chrono Trigger has a lot of slang. In addition to that
    expressions are difficult to understand in places, they are difficult to translate
    in Finnish, because there is a difference between spoken and written language
    in the written expression a little too clear. Thus
    the Finnish version has more literary language than the English version ...
  - Then there is, of course, Frog, who speaks in the English version
    Shakespeare's early English, and Eira, who speaks
    as a native at least ...


TYÃ – RYHMÃ „
  Project management
    Bisqwit
  Graphics
    Bisqwit
  Debug, Hacking
    Bisqwit
  KÃ¤Ã¤nnÃ¶s
    Bisqwit, Warp, Merri, Shiryuu

  The work is based on Chrono Trigger's official English
  version. The homepage of the translation software created is
  http://bisqwit.iki.fi/source/chronotools.html (in English).

LINKS
  Joel Yliluoma http://iki.fi/bisqwit/; bisqwit @ to piste fi
  Vesa Piittinen http://merri.net/; Vesa @ Merri piste net
  Warp              http://iki.fi/warp/