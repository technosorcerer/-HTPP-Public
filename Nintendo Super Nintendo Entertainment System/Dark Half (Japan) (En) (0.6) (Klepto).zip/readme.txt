               ************************************
               *                                  *
               *         Klepto Software          *
               *                                  *
               ************************************
               *      http://klepto.r8.org        *
               ************************************
                            PRESENTS

                         Dark Half v.60



ABOUT THIS PATCH
__________________________________

This patch is to convert the Super Famicom game Dark Half to english. 
Unfortunately, Enix never released this game outside of Japan.  This 
translation has been in the works for many years, and was abandoned 
for a long period of time.  Everyone who worked on this has done so 
in their free time, and hopefully we will see it completed one day!


PROGRESS
__________________________________

75% of graphics hacking completed.
75% of menus translated.
75% of monster names translated.
75% of item names translated.
50% of dialogue translated.
To Do: Item/Monster name expansion.


USING THIS PATCH
__________________________________

DO NOT apply this patch to your only copy of the ROM.  Keep a copy of
the original, as future patches must be applied to the original ROM.

If you are using ZSNES, there is online documentation on how to use a 
patch:
http://zsnes-docs.sourceforge.net/html/readme.htm#ips_patching

Otherwise, romhacking.net has an excellent FAQ on the subject:
http://www.romhacking.net/faq/


BUGS
__________________________________

This is a work in progress!  Keep in mind there are still many 
untranslated portions of this game, and we are well aware of this.  
Please help us by reporting any bugs to SirYoink at revdpimp@yahoo.com


CREDITS
__________________________________

Programming/Editing:
SirYoink

Main Script Translation:
Ein ni Hen

Spot Translations:
Emiko
Mistduheat

Special Thanks:
F.H
AnusP
Bongo
Wildbill

DISCLAIMER
__________________________________

Dark Half and all related images are trademarks of Square Enix, Ltd

Klepto Software is in no way affiliated with Square Enix, and is 
not liable for damages of any type arising from your use of any 
materials provided.

We do not condone piracy in any form.  This patch is not to be 
distributed with a game image.  If you like the game, buy the original!