ASSAULT SUITS VALKEN
ENGLISH TRANSLATION V1.00
Copyright 2004 Aeon Genesis
http://agtp.romhack.net

ToC

1.  About Assault Suits Valken
2.  Patch History
3.  Patch Credits and Contributors
4.  Known Issues
5.  Application Instructions

----------------------------
1.About Assault Suits Valken
----------------------------
ASV is a giant robot platformer with somewhat realistic
physics, a mature storyline, and plenty of huge explosions.
Easily one of my all-time SNES favorites, Valken was
released across the pond as "Cybernator", and received an
absolute butchering of a localization -- gobs and gobs of
stuff got cut from it. We're talking on par with FF4 here,
folks, maybe worse.

The game follows Jake, a normal every-day Assault Suit
pilot in the service of the United Pacific States marine
corps, as he and the crew of his mothership, the Versis,
fight to end a long war over diminishing fossil fuel
resources. Gameplay between levels is extremely well
varied, the scenarios are fun and challenging. The game's
a blast, and now it's completely uncut and in English!
Have a ball, folks!

---------------
2.Patch History
---------------
This is one I've wanted to do for a long time, and even
after I started (no, I don't remember when, maybe a year
or so ago) it took far longer than it should have. The
programmers over at NCS/Masaya must've been having fun
with the happy grass or something, the game's coding is
absolutely nuts, and that put me off of working on it
more than anything else. I don't really remember too much
of this project's history other than the past few weeks,
when I've been going absolutely nuts trying to get it
ready for release.

March 7, 2004 - Initial version 1.00 Release

---------------
3.Patch Credits
---------------
THE ASSAULT SUITS VALKEN 009 TEAM
Main Team:
Gideon Zhi - Project leader, Romhacker
Ian Kelley - Translation.

Special Thanks:
Tomato - Translation of prologue cutscene

--------------
4.Known Issues
--------------
--The name entry screen remains partially hacked and is mostly
  unusable. It shouldn't be necessary though, it's only used if
  you want to change the hero's name.

Otherwise, there are no known issues. If you find any, please post
about them on The Pantheon (http://donut.parodius.com/agtp)

--------------------------
5.Application Instructions
--------------------------
If using ZSNES, make sure that the patch has the same name as your ROM.
In other words, if your ROM is called "valken.smc" make sure the patch
is "valken.ips" okay? If you're using a Mac, a Mac IPS patcher is
available. Check the AGTP Links page. If you're using a copier, you
probably already know how to patch the ROM :) Be sure to apply the
patch to a clean copy of the ROM, and make sure your ROM HAS
A HEADER!. If you right-click the ROM and select Properties, it
should read "Size: 1.00 MB (1,049,088 bytes)". SNESTool can add
your headers for you easily, and you can find it at
http://rpgd.emulationworld.com
In the utilities section, click on the IPS Tools link.
The answers to the questions it asks you do not matter unless you're
using a copier to play the game.

An easy way to tell if the game has a header or not is that if you do
the above and the game does not run, it probably doesn't have a header.
Use SNESTool to add one. And don't whine about SNESTool not working in
Windows XP, it works fine for me and I'm running on XP Pro.