Traducción de _BATTLETOADS IN BATTLEMANIACS_
para SNES de INGLÉS a ESPAÑOL
v. 1.0
Por: Rod Mérida
Terminado el 9/10/2020

          ____  
         / __/ 
        / /    
       / /    ___                                         ° |\ 
      | |    |   \   ___    ___  _  _    ___  _           _ | \   
      | |    | |\ \ / _ \  / __|| |/ /  / _ \\ \   /\  /\| ||  \ 
      | |    | |/ /| |_| || |   | | /  | | | |\ \ / / / /| ||   \
       \ \   | | / |  _  || |   |   \  | | | | \ \ /\/ / | || |\ \ 
        \ \_ | | \ | | | || |__ | |\ \ | |_| |  \ /\ \/  | || | \ \ 
         \__||_|\_\|_| |_| \___||_| \_\ \___/    \  \/   |_||_|  \/ 



Copyright (c) 2020 R. Mérida

Porcentaje de traducción: 100%
Signos especiales del castellano: Á, É, Í, Ó, Ú, Ñ, ¡, ¿

Nota: Traducción realizada tanto a partir de ROM europea (PAL) como norteamericana (NTSC), ambas SIN cabecera de 512 bytes (identificado frecuentemente mediante la extension .SFC, y/o por un tamaño de archivo de 1.048.576 bytes)

¿Se realizan reproducciones físicas de esta ROM en cartucho? -> Sí.
	Consultar con Crackowia a la siguiente dirección: retrospectyva@gmail.com



          _____                   _______                   _____          
         /\    \                 /::\    \                 /\    \         
        /::\    \               /::::\    \               /::\    \        
       /::::\    \             /::::::\    \             /::::\    \       
      /::::::\    \           /::::::::\    \           /::::::\    \      
     /:::/\:::\    \         /:::/~~\:::\    \         /:::/\:::\    \     
    /:::/__\:::\    \       /:::/    \:::\    \       /:::/  \:::\    \    
   /::::\   \:::\    \     /:::/    / \:::\    \     /:::/    \:::\    \   
  /::::::\   \:::\    \   /:::/____/   \:::\____\   /:::/    / \:::\    \  
 /:::/\:::\   \:::\____\ |:::|    |     |:::|    | /:::/    /   \:::\ ___\ 
/:::/  \:::\   \:::|    ||:::|____|     |:::|    |/:::/____/     \:::|    |
\::/   |::::\  /:::|____| \:::\    \   /:::/    / \:::\    \     /:::|____|
 \/____|:::::\/:::/    /   \:::\    \ /:::/    /   \:::\    \   /:::/    / 
       |:::::::::/    /     \:::\    /:::/    /     \:::\    \ /:::/    /  
       |::|\::::/    /       \:::\__/:::/    /       \:::\    /:::/    /   
       |::| \::/____/         \::::::::/    /         \:::\  /:::/    /    
       |::|  ~|                \::::::/    /           \:::\/:::/    /     
       |::|   |                 \::::/    /             \::::::/    /      
       \::|   |                  \::/____/               \::::/    /       
        \:|   |                   ~~                      \::/____/        
         \|___|                                            ~~              


-------------------------------------------------------
QUEDA PROHIBIDA LA DISTRIBUCIÓN DE ESTA TRADUCCIÓN SIN INCLUIR MENCIÓN EXPRESA A SU AUTOR, O MANTENER LA QUE YA SE ENCUENTRA DENTRO DEL ARCHIVO.

QUEDA PROHIBIDA LA DISTRIBUCIÓN DE ESTE PARCHE CON ÁNIMO DE LUCRO, SIN LA AUTORIZACIÓN EXPRESA PREVIA DE SU AUTOR.

Para cualquier comentario, crítica, consejos, peticiones, o en general contactar con nosotros, háganlo a la dirección de correo electrónico:
crackowia@gmail.com .