IMPORTANT!
A certain key has been moved to where you find it in the PlayStation version, so walkthroughs written for the original SNES version might mislead you.

--- Patching ---
First apply any translation patch (not included). Then apply the corresponding Deluxe patch.

Supported translation hacks:
English, by Aeon Genesis (Headered ROM!)
Chinese, by Я929
Korean, by Cyjzero
Spanish by IlDucci (Headered ROM!)
Turkish, by knighTeen87 (Headered ROM!)
German, by RedScorpion
Portuguese, by Denver
French, by Naboo


--- Features ---
Mouse support
Lost bedroom, clown doll, zombie, extra cave event ported from the PlayStation version
Can run up and down the stairs (can also run to all hotspots)
Hold UP or DOWN to speed up the credits
Faster health regeneration
Region error screen disabled

--- Mouse ---
Left button: walk/ click things
Right button: stop/ panic button
Press SELECT to change mouse speed (on real hardware). Changes cursor speed for the gamepad instead if no mouse connected.
Move the cursor down to access the inventory. Right clicking there will switch to the default cursor.

!!! WARNING! SPOILERS BELOW !!!

--- Original bugs fixed / errors corrected ---
[Main hall]
The door on the upper floor will now actually open when you use it

[East Bedroom]
Mirror can now be shattered
Photo close-up timed rather than input required. Done for mouse support, but PlayStation version has the same change.
Faster fade-out so Jennifer isn't seen getting up after being killed by the parrot

[Bathroom]
Bobby close-up image corrected
Can no longer get inventory to clash with shower event

[Courtyard]
Shed hotspot repositioned
Shed still accessible when chased

[Shed]
Hiding place soft-lock fixed
Can no longer walk backwards out the door when Mary enters

[Phone room]
Can no longer use the light switch to overwrite Mary's palette

[Fireplace study]
Blood added on table after window scene, matching the table's description (PlayStation version moved the curtain blood there)

[Music room]
Bobby peeking won't disrupt resting pose

[Trophy room]
Head and jar will animate when their sounds are playing
Cabinet hotspot repositioned
Hotspot for box
Garbage on screen when coming from mannequin room fixed
Removed garbage tile from cabinet's opened sprite
Door using the correct sprites

[Mannequin room]
Door using the correct sprites

[Sealed room]
The close-up text can be scrolled faster just like the credits

[Caves]
You can move around and the player hotspot will follow you when it's time for that
Fade when changing appearance
Scream added to dog death
Background doors now using left/ right animations rather than simple goals
Dan's hand is no longer visible before you even get to his cradle
Can no longer run too far left and get stuck in front of Dan's cradle
Can no longer open the inventory by Dan's cradle to reset the border
Cursor hidden during chase until player gets control again
Camera will no longer show end of Dan's sprite
Portrait flashing starts when the struggle's actually starting
BG2 prepared before showing explosion to avoid visible garbage
Removed long wait at door after chase before player gets control
Kerosene can no longer respawning
Ending F no brief explosion when credits start

[Hallways]
Removed garbage tile from large left door sprite when opening
Hotspot leading to the first storage repositioned
Hotspots for a similar door and nearby window repositioned
Faster fade-out when Jennifer goes through leftmost door

[Endings]
Tower exterior fence position corrected
Friend will now be falling in front of the fence during the A ending
"I will kill you!!" won't stay on screen too long

[Other]
Bobby will open doors before entering (often walked through them in original)
Lantern inventory sprite is now colored as it looks in the room

--- Future plans ---
More events and details from the PlayStation version (including the new close-up images)
More bugfixes/ corrections
Bobby spawning in more rooms
Implement the hiding places and weapons that have sprites and animations for that

--- Tools used ---
BSNES Plus v073+3 for code inspection and debugging
SNES Professional ASM Development Kit for code inspection
Notepad++ for new code, assembled with xkas v0.06
Hex Workshop for hex editing
Custom tools for research, new sprites, animations and compression
YY-CHR for editing existing graphics

This hack has been tested on a PAL SNES system, with an original Super NES Mouse.

--- V1.2 update ---
Added patches for more translations. Also repositioned some more hotspots.

--- V1.1 update ---
Fixed a bug where the clown doll struggle wouldn't finish properly, causing a soft-lock at the next struggle encountered.