Build directions:
1) Place "asar.exe" in "\bin". The lastest release can be found here: https://github.com/RPGHacker/asar/releases
2) Place "flips.exe" in "\bin". To build the latest version: https://github.com/Alcaro/Flips or precompiled binary: https://www.smwcentral.net/?p=section&a=details&id=11474
3) Place the rom in "\rom".
4) Update the rom name variables if needed in "make.bat" and then run it.

No-Intro Name: Castlevania - Dracula X (USA).sfc
  - CRC32: 7C4887E1
  - MD-5:  DC629BE2EE515461315CDE57210E36C0
  - SHA-1: 3BDAEAFA81AA17C91A8B42D0FA8C5B26E3FD6B80