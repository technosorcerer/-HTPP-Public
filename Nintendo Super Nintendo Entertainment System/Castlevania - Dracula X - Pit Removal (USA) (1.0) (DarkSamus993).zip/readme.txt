ips = patch file (match the checksum listed below). A patcher (Flips) can be found in the "src\bin" folder.
src = source files, notes, and build directions.

No-Intro Name: Castlevania - Dracula X (USA).sfc
  - CRC32: 7C4887E1
  - MD-5:  DC629BE2EE515461315CDE57210E36C0
  - SHA-1: 3BDAEAFA81AA17C91A8B42D0FA8C5B26E3FD6B80

;================================================================================

This hack works by waiting for the map data to decompress to ram and then
overwrites the 32x32 block data and collision mask with new data to fill
in the pits of the final boss room.

I didn't feel like writing a decompressor/compressor, but I did document the
format (check the src folder for the notes on that) at least in case someone
wants to write tools for that in the future.