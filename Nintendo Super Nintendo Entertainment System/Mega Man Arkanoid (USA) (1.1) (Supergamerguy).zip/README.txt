Mega Man Arkanoid (Version 1.0)
by Supergamerguy


Table of Contents:
1. How to patch
2. Changelog
3. Background Info
4. Tools Used
5. All Characters Used in Levels with Stage Location






How to patch:
1. Download a patching program like Lunar IPS
2. Download Arkanoid - Doh It Again (USA).sfc
3. Use patching program to apply "Mega Man Arkanoid (regular).ips" or 
"Mega Man Arkanoid (Infinite Lives and Stage Select).ips" to your 
Arkanoid SNES ROM
4. Rename new file to whatever you want (Example: Mega Man Arkanoid)
5. Use a SNES emulator like BSNES or the SNES9x core in Retroarch to play!






Changelog:

Version 1.1:
- Svambo (one of the creators of ArkanEdit) helped me fix powerup bugs in 
levels 75, 84, 96, and 98. Those levels can be played with glitches removed
(including powerups now able to be found on level 75 where there were none 
before).

Version 1.0:
- Finished all levels (made all of them Mega-Man related)



Background Info:
I love the classic Mega Man series, having played every game
available (including a few obscure ones not represented in this hack). 
So one day I was scrolling through ROMHACKING.net and saw that there was 
a new program out called ArkanEdit that would allow hackers to edit every 
level in the game easily and thoroughly. I decided to make a few levels 
because I had nothing else to do at the time, and those few levels soon 
turned into a complete overhaul of the game made over a period of a couple 
months. Just about every game has at least some representation in my hack, 
so I hope both new and old Mega Man fans alike will enjoy the experience!





Tools Used:
- ArkanEdit (used to edit every level layout)



All Characters Used in Levels with Stage Location:
1. Mega Man
2. Proto Man
3. Bass
4. Rush
5. Roll
6. Dr. Light
7. Tango
8. Eddie
9. Met (or Metall, depending on what you call it)
10. Beat
11. *Boss 1*
12. Dr. Wily
13. Treble
14. Reggae
15. Auto
16. Fire Man
17. Elec Man
18. Ice Man
19. It's Guts Man!!! (DA NAHHHH)
20. Yellow Devil
21. Sniper Joe
22. *Boss 2*
23. Metal Man
24. Wood Man
25. Air Man
26. Snake Man
27. Shadow Man
28. Gemini Man
29. Dr. Cossack
30. Kalinke
31. Toad Man
32. Dive Man
33. *Boss 3*
34. Drill Man
35. Gyro Man
36. Stone Man
37. Napalm Man
38. Dark Man 4
39. Mr. X
40. Blizzard Man
41. Centaur Man
42. Flame Man
43. Guts Man G
44. *Boss 4*
45. Shade Man
46. Freeze Man
47. Slash Man
48. Sword Man
49. Grenade Man
50. Clown Man
51. Duo
52. Tengu Man
53. Burner Man
54. Cold Man
55. *Boss 5*
56. King
57. Galaxy Man
58. Splash Woman
59. Concrete Man
60. Sheep Man
61. Commando Man
62. Blade Man
63. Enker
64. Punk
65. Ballade
66. *Boss 6*
67. Quint
68. Venus
69. Neptune
70. Mars
71. Terra
72. Sunstar
73. Mega Water S.
74. Buster Rod G.
75. Hyper Storm H.
76. Mecha Dragon (MM2)
77. *Boss 7*
78. Doc Robot (MM3)
79. Fake Man (MM9)
80. Alien (MM2)
81. Gamma (MM3)
82. Green Devil (MM8)
83. Original Duo (MM8)
84. Evil Robot (MM8)
85. Ra Thor
86. Ra Devil
87. Ra Moon
88. *Boss 8*
89. Wily UFO
90. Oil Man
91. Time Man
92. Mega Man? (clone)
93. X (from Mega Man X)
94. Zero (from Mega Man Zero)
95. Aile (from Mega Man ZX)
96. Volnutt (from Mega Man Legends)
97. MegaMan.exe (from Mega Man Battle Network)
98. Mega Man (from Mega Man Starforce)
99. *Boss 9*/Final Boss
