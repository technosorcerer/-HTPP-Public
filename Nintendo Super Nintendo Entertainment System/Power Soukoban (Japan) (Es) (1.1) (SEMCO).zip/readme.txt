Use with:
Power Soukoban (Japan).sfc (No-Intro)
eb9174301c3d2ff6871cc5aef8b9eb4a
39FBAA1E