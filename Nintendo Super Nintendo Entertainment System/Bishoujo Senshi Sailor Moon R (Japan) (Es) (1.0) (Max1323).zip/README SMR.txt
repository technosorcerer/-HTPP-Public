"Bishoujo Senshi Sailor Moon R"
Traducci�n al Espa�ol Ver. 1.0 (14/07/2020)
por Max1323 (maxmuruchi@gmail.com)
Basada en la traducci�n de FuSoYa's Niche y Masamune Translations. 
---------------------------------------------------
Descripci�n:
Basado en el manga y anime del mismo nombre. La historia se centra en el arco del Clan Black Moon.
Este clan busca vengarse de la Neo Reina Serenity, viajando a traves del tiempo para llevar su plan.
Elige entre las 5 Sailor Scouts y un modo m�s f�cil
donde la protagonista es Chibi-Usa.

Desarrollado: Bandai
Publicado:    Bandai
Lanzamiento: 29/12/1993 (JAP)
---------------------------------------------------
Acerca del proyecto:
Se tradujo los di�logos del juego y algunos graficos.
La mayor�a de los gr�ficos est�n comprimidos al igual que los textos.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS

Bishoujo Senshi Sailor Moon R (J).sfc/smc
File Size     2.00 MB
File MD5    39B1E06FAE0D6176C6EC4BB98F842EB7
File SHA-1  3FE66EFA28F97579602ECA80FE1765A6F45F762D
File CRC32  4AEE5ABB

