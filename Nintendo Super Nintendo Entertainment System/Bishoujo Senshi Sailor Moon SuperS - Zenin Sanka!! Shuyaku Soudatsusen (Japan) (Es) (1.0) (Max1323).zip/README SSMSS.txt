"Sailor Moon Super S Fighter S"
Traducción al Español Ver. 1.0 (23/09/2020)
por Max1323 (maxmuruchi@gmail.com)
Basada en el gran trabajo de Metaquarius.

Vivify93, Yosenex, Sprint, ThatIdahoGuy,
Moonlight Fight Society, Metaquarius 'The madman
---------------------------------------------------
Descripción:
Basada en el manga y anime de Naoko Takeuchi.
Sailor Moon Super S es un juego de luchas donde 
podremos elegir a 10 personajes donde la historia se
centra en quien se convertirá la líder de las Sailor.

Desarrollado: Monolith
Publicado:    Angel (Bandai)
Lanzamiento:  29/03/1996 (JAP)
---------------------------------------------------
Acerca del proyecto:
Los gráficos estan comprimidos por lo que no puedo agregarle
los caracteres españoles.
Esta basado en un hack que mejora algunas cosas y que también 
trae el juego traducido al ingles.
(https://www.romhacking.net/hacks/4498/)
Wiki del juego: 
http://newchallenger.net/w/index.php?title=Sailor_Moon_Fighter_S
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS

Bishoujo Senshi Sailor Moon Super S - 
Zenin Sanka!! Shuyaku Soudatsusen (J).sfc/smc
File size     3.00 MB
File MD5      89C3D0A6ECEF80BD3E8E9AF650897626        
File SHA-1    1ADA34177E7384612AE83464288F3860E4C4426E
File CRC32    25440331
                

