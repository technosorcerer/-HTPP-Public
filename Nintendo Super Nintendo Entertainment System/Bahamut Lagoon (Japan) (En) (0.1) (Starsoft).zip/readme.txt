Starsoft Translations Presents:

Bahamut Lagoon Translation Patch v0.10

What's New?

-Fixed up untranslated names, or badly translated names
-Fixed the Battle Menu font, which was clashing with the 16x16 work
-New dialog of the intro 
-assorted fixed up things

Current Members:

Taichou-Maiku
Cecil
Byuu
Atlas
Fox Astron

Patch Helpers:

Louis Bontes
Chojin
Frank Hughes

Special Thanks to:

[cx]
Blahman
Zeio
#romhack
Asure

This patch is dedicated to a good friend, only being know as TheAngreal
