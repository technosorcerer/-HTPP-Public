"Doomsday Warrior"
Traducci�n al Espa�ol Ver. 1.0 (16/07/2018)
por Max1323 (maxmuruchi@gmail.com)
---------------------------------------------------
Descripci�n:
El juego gira en torno al Doom Squad, un grupo de siete poderosos guerreros a los que el villano Main, les ha lavado el cerebro. Aterrorizan y lo ayudan a gobernar sobre una Tierra dist�pica. Uno de ellos se libera de este control para restaurar la libertad del planeta al derrotar a los otros miembros y al propio Main.

Conocido tambien como: Taiketsu!! Brass Numbers   
Desarrollado: Laser Soft
Publicado:    Laser Soft (Jap�n)
              Renovation Products (Estados Unidos) 
Lanzamiento: 20 Noviembre 1992 (Jap�n)
                Marzo     1993 (Estados Unidos)
---------------------------------------------------
Acerca del proyecto:
Se tradujo el men�, y los di�logos de los personajes, 
lo malo es que faltan algunos textos como el del men� de opciones.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS
Doomsday Warrior (U) [!]
File MD5      49C1FBB62CD882128FBB13C9FE11AC4C
File SHA-1    5B7294665583510468D257F4896E825F642AD95F
File CRC32    CEEB7C32
Tama�o        1,00 MB