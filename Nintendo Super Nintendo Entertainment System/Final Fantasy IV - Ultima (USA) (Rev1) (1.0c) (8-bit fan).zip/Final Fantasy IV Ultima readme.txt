Final Fantasy IV - Ultima
---------------------------------------------------------
-= Complete hack v1.0c =-
Apply 'Final Fantasy IV - Ultima v1.0c no header.ips' directly to a non-headered 'Final Fantasy II (U) (V1.1).smc'
or...
Apply 'Final Fantasy IV - Ultima v1.0c headered.ips' directly to a headered 'Final Fantasy 2 (V1.1) (U).smc'
---------------------------------------------------------

What this hack does:
---------------------------------------------------------
FF2US always felt somewhat lacking and incomplete but full of potential. This hack rectifies that by adding a ton of additions to the base game while keeping the majority of the main story intact and the feel of FF2US the same. This hack can be viewed as a 'deluxe' version of FF2US.
---------------------------------------------------------

Version 1.0c changes:
---------------------------------------------------------
Edge is now able to equip Whips!
You can now return from Zemus' room.
Gave NPC hint on how to reach the Ultima Weapon sword.
Various minor map edits.
Updated various texts.
Updated various enemies' drop list.
Saves from all previous versions(1.0, 1.0a, 1.0b) will work.
---------------------------------------------------------

Version 1.0b changes:
---------------------------------------------------------
Cat Claw - Added Curse and Stun effects.
Fixed King Fabul dialog from Doom to Deathbringer to match the in-game weapon name.
Vulture now always drops Cockatrice summon.
Updated various enemies' drop list. Improving them.
Saves from both previous versions(1.0 and 1.0a) will work.
---------------------------------------------------------

Version 1.0a changes:
---------------------------------------------------------
Rising Sun - Buffed attack power from 50 to 52.
Tempest Sword - Buffed attack power from 70 to 80.
Saves from version 1.0 will work.
---------------------------------------------------------

List of features, additions and changes:
---------------------------------------------------------
1) 22 New Weapons! Including Ultima Weapon!
2) 11 New Spells! Also revamped existing spells so the useless ones are now useful!
3) New Armors and Gears.
4) New commands for characters and end-game party.
5) New events!
6) 8 New bosses!!
7) Revamped shops/equipment and balanced their progression.
8) Edge is now buffed and no longer useless!*
9) Rydia has also been buffed(slightly). It's a surprise!
10) Cecil has been buffed as a tank. He's still strong offensively, but he's now able to block physical attacks for wounded members without much problems.
11) Rosa can use more White Mage combative gears.
12) Kain has a few new offensive buffing white spells at end-game and new commands as he rejoins the team.
13) Rare items and summons now drop much easier! This hack is designed as a 'play-through' without grinding.**
14) Many enemies now have meaningful rare drops, and all end-game enemies now have rare ultimate drops!
15) New thrown weapons and back-row weapons!
16) Lots of secrets that can lead to early acquirement of better equipment!
17) Few minor tweaks to the base game such as save points, etc.
18) Useless finds now replaced with good items or equipment!
19) All weapons/armors used by characters no longer in party are now usable by at least one character from the end-game party!
20) MOST items/equipment are now non-missable. Meaning they will be acquirable in some ways at end-game. (not including unique ones such as Excalibur, Masamune, etc. so don't throw those for 100% games!)

* Edge always felt a bit useless at end-game. I see the intent was for him to be a well-rounded, jack of all trades character but I think that fell short and the end result is he's really not that good in anything. I buffed him so he's now capable both physically and magically! He has new spells, new gears, and end-game steals have good items as opposed to useless junk in the vanilla version.
** Some ULTRA rare items are still hard to come by at end-game and will likely require grinding to acquire.
---------------------------------------------------------

Other notes:
---------------------------------------------------------
As the vanilla version was a very easy game, here's what I did with this hack's difficulty:
-About 1/3 into the game, the difficulty starts to increase slightly from the vanilla game.
-At around the events after the Sealed Cave, the game's difficulty ramps up.
-After the last save point in the last dungeon, the game becomes 'Nintendo hard'. Casual players would likely not make it and might need to grind a bit. Veterans of the game should still have no problem beating it.  ;)

Ultima is my favorite RPG series growing up and Ultima from later FF games has been added to this hack, hence naming this hack: Final Fantasy IV - Ultima
---------------------------------------------------------

Tools and resources used:
---------------------------------------------------------
ff4kster, FFIV Project II, FF4ed, FlexHEX, Tile Layer Pro, snes9x, zsnes, SD2SNES, and romhacking.net.
---------------------------------------------------------

Special thanks:
---------------------------------------------------------
I would first like to give credits to Pinkpuff, vivify93, Fauntleroy and Yousei. Pinkpuff and Fauntleroy for their inspiration with Unprecedented Crisis and Golbez Edition. Pinkpuff for the AMAZING ff4kster editor! This hack would NOT have been possible without it! Yousei for the FF4ed editor as it was the only one I found that allowed me to edit the world maps! Huge thanks also to vivify93 for allowing us to use Project II as a base! I chose to use Project II because it's the closest to FF2US, with most of the dummied out content added back in.
---------------------------------------------------------

Acknowledgements and Credits:
---------------------------------------------------------
SQUARE for this amazing game.
Nintendo for licensing the game in the US.
---------------------------------------------------------

Files included in zip:
---------------------------------------------------------
Final Fantasy IV - Ultima v1.0c no header.ips
Final Fantasy IV - Ultima v1.0c headered.ips
Final Fantasy IV Ultima readme.txt
Weapons List - SPOILERS!!.ods
Weapons List - SPOILERS!!.txt
Spells List - SPOILERS!!.ods
Spells List - SPOILERS!!.txt
---------------------------------------------------------

Other info:
---------------------------------------------------------
Please check back in the future for more in-depth guides and boss strategies at:
http://www.8bitfan.info/
https://www.romhacking.net/hacks/4134/
---------------------------------------------------------

2018.9.3 v1.0 by 8-bit fan / 8.bit.fan / butz
2018.9.8 v1.0a by 8-bit fan / 8.bit.fan / butz
2018.9.15 v1.0b by 8-bit fan / 8.bit.fan / butz
2018.9.22 v1.0c by 8-bit fan / 8.bit.fan / butz