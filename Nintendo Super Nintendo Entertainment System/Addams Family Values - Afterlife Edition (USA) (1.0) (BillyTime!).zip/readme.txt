AFV - Afterlife Edition 
2019 BillyTime! Games 
Special Credit to Jlukas for all his help!

Addams Family Values – Afterlife Edition is a balance hack to Addams Family Values on the SNES which seeks to improve gameplay in various ways. Created using Geiger's SNES9X Debugger and GGGuy. Now in Two Flavors!

1.Vanilla – Gameplay Changes – Not much else
2.Simplified Dungeons and OW – Certain rooms in various dungeons have been removed in addition to the eastern forest on the overworld.

Usage: Patch Addams Family Values (U) rom using one of the above patches in conjunction with flips or any other BPS Patcher

Changes:
*Fester’s lightning  no longer degrades to green or red upon receiving damage
(Fixed 10/30)
*Cooldown time for lurch’s bowling ball between uses have been eliminated
*Fester receives a movement speed increase (Diagonally and on Stairs)
*Granny always replenishes cookies after your initial meeting with her in the opening
*Morobe (A Notorious Late Game Boss) can no longer slow you down  with her spider webs
*Fester starts with an additional skull to his health meter allowing you to end the game with a full skull meter.
*Item Menu Cursor has been been given a speed bump for faster navigation
*Several Lesser enemies give out health Skulls when defeated (credit to Jlukas!)
*Press select to call Cousin It. (Map now needs to be selected from inventory,)
*Most broken bridges have been reconnected for better navigation (credit to Jlukas!)
*Faster Dialog progression (Just hold A)
*Removed animation when Fester eats a cookie for faster health replenishment.
*Dungeon 1,2,3,4,5,7, The Greenhouse, The Morgue have been modified to cut down on puzzles and backtracking. (Simplified Dungeon Patch Only)
*Eastern Forests have been removed, The eastern exit in the gardens now redirects you to the eastern swamps. (Simplified Dungeon Patch Only)
*Trans-Mansion Express has been reshuffled to take you to dungeon 4 first before the stone gardens (Simplified Dungeon Patch Only)
*Some staircases have been re-worked in the eastern forests, stone gardens and wetlands
(Simplified Dungeon Patch Only)
*Fester’s lightning has been turned red, because its cool.
*Fester’s lightning is now a multi-hit attack, scoring two hits for every landed attack.

This patch is the result of a year’s worth of research and debugging.

Changelog:
11/30/2019:
*Trans-Mansion Express has been reshuffled to take you to dungeon 4 first before the stone gardens (Simplified Dungeon Patch Only)
*Some staircases have been re-worked in the eastern forests, stone gardens and wetlands
(Simplified Dungeon Patch Only)
*Fester’s lightning has been turned red, because its cool.
*Fester’s lightning is now a multi-hit attack, scoring two hits for every landed attack.
11/17/2019:
*Faster Dialog progression
*Removed animation when Fester eats a cookie for faster health replenishment.
*Dungeon 1,2,3,4,5,7, The Greenhouse, The Morgue have been modified to cut down on puzzles and backtracking. (Simplified Dungeon Patch Only)
*Eastern Forests have been removed, The eastern exit in the gardens now redirects you to the eastern swamps. (Simplified Dungeon Patch Only)
11/10/2019:
*Special Credit given to Jlukas upon boot up.
*Press select to call Cousin It. (Improved save function, credit to Jlukas!)
*Most broken bridges have been reconnected for better navigation (credit to Jlukas!)
10/30/2019:
*Fixed Lighting going red when In Critical Health
*Several lesser enemies give out Skulls when defeated
10/26/2019:
*Item Menu Cursor has been been given a speed bump for faster navigation
10/23/2019:
*Fester’s Diagonal Speed has been buffed
10/21/2019:
Initial Release

Special Thank you to Jlukas for his help in making this hack possible! Without him, this hack would have never existed.

Note: I also go by Moonmaster1 on Romhacking.net to help clarify some confusion.