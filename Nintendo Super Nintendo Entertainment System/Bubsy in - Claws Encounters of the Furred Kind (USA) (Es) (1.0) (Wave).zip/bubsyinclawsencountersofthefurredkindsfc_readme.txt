Bubsy in Claws Encounters of the Furred Kind (Super Nintendo)
Traducci�n al Espa�ol v1.0 (17/06/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bubsy in Claws Encounters of the Furred Kind (U) [!].smc
MD5: 6ac508bddbabc699f181d7858ccfcf0f
SHA1: 9f6ff6264e0361e074f9cfee2ec4976866a781c5
CRC32: 444a52c1
2097152 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --