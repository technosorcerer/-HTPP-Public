Goof-Troop
Projeto de tradução para o português do Brasil
Monkey's Traduções

1.Informações sobre a ROM
 Nome Original: Goof Troop (U).smc (524.288 bytes)
 Idioma: Inglês
 Header: Não (Deve ser retirada)
File/ROM SHA-1: B38560D091801DB5E833D17393FE1DF1398909B6
File/ROM CRC32: 4AAFA462
		
2.Como aplicar o IPS
 Utilize o programa Lunar IPS (http://fusoya.eludevisibility.org/lips/)

3.Equipe:
 Hyllian - Tradução dos textos, compressor
 Denim - revisão, assembly

4.Sobre a tradução:
- Adição de fonte proporcional
- Possibilidade de coletar até 99 vidas.
- Alterei cores da tela de opção (cor de fundo e cor da opção selecionada)
- A tradução está a princípio 99% completa. Não quis traduzir o nome dos personagens nos créditos finais.
- Como alterei muito o código do jogo, poderão ocorrer bugs. Peço a todos que encontrarem algum que me informem.
- O som da risada do pateta não foi traduzido (mantive o 'gwarsh' do original).
 
5.Histórico de alterações:
05/03/2013 - Versão 1.0
- Versão inicial