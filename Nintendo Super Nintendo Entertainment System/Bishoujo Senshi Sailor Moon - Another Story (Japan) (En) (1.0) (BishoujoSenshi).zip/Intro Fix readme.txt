Sailor Moon Another Story: Intro Fix v1.0
Programmed by mziab, http://mziab.grajpopolsku.pl
Released September 1st, 2012

This patch fixes the garbled intro text present in the original English patch
by Bishoujo Senshi Translations when running the game on real hardware and
accurate emulators.

Usage:
The patch should be applied to a rom pre-patched with the BST English translation,
WITHOUT a header (4,194,304 bytes). For the sake of convenience, the archive
includes the patch in both IPS and BPS formats.

Disclaimer:
No bugs were revealed during my testing of the patch. However, if you happen to
notice any defects introduced by it, be sure to contact me per e-mail (mziab@o2.pl)
and I'll see what I can do.
