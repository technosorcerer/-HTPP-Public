______________________________________________________________________

 Bishoujo Senshi Sailor Moon : Another Story RPG (SNES)
 English Translation Patch
 Version 1.00

 Created by: Bishoujo Senshi Translations (BST)
             http://www.terminaldogma.net/smrpg/
______________________________________________________________________

 CONTENTS
______________________________________________________________________

 1. Credits
 2. Introduction/History
 3. Game Controls
 4. Translation Notes from Moose
 5. Personal Comments
   A. Lina`chan
   B. Moose
   C. Cecil
   D. FuSoYa
 6. Legal Notice
 7. Contact Information

______________________________________________________________________

 1. Credits
______________________________________________________________________


 WEBMASTER:             Cecil Stormclaw

 ROM MODIFICATIONS:     FuSoYa (Defender of Relm)

 MAIN TRANSLATORS:      Moose M. (Moose-kun)
                        Lina Inverse (Lina`chan)
                        Nuku-Nuku (Atsuko Natsume)

 AUXILIARY TRANSLATORS: Janitha R. (SailorDiana)

 SPOT TRANSLATORS:      Som2Freak (konnyaku)
                        Harmony7 (harmony7)
                        Refsa/Xeur

 BETA TESTING:          Kisai


______________________________________________________________________

 2. Introduction/History
______________________________________________________________________

 Bishoujo Senshi Sailor Moon: Another Story RPG for the Super Famicon
 was made by Angel and released in Japan around 1995.  It was one of
 many console games developed for the SNES and gameboy during that
 time period based on the popular Manga and Anime show, "Sailor Moon".
 The majority of these games tend to be puzzle games, fighter games,
 and so forth.  SMRPG is distinctive however, in that it currently
 remains the only console Sailor Moon game in the RPG category to have
 been developed and released commercially.

 Unfortunately, none of these Sailor Moon games, including the RPG,
 ever saw a commercial North American release.  And given the fact
 that the 16 bit era of gaming is fast becoming nothing more than a
 distant memory in the wake of yet a second wave of next generation
 systems, it's doubtful that they ever will.

 This left only the fan and emulation community.  In 1997, Cecil began
 the initial effort of trying to bring about a translation patch of the
 game, and Bishoujo Senshi Translations (BST) was born.  He was soon
 joined by several others interested in the same goal (translator
 Moose among them), and it wasn't long till a script dump was obtained
 with Artemio's help, allowing the translation to get underway.

 But as is often the case with SNES RPG projects, the ROM would not
 give up all its secrets so easily.  The menu fonts, along with much
 of the menu text itself, were compressed beyond recognition.  Also
 the game code was designed only for a 16x16 fixed width font for the
 main story text, making english text look rather large and unsightly.

 The absence of progress on the ROM modifications combined with
 the lack of time by several key people gradually caused BST to become
 nearly comatose.  Just about everyone in the initial group slowly
 dropped out of sight.  As 1998 wore on, a few other small attempts
 were made by separate projects that tried to create their own SMRPG
 translation patches.  But they eventually failed as well.....


 Sometime during the summer of 1998, FuSoYa appeared for the first
 time and contacted Cecil with information dealing with the ROM's
 compression scheme. In turn, Cecil got back in contact with Moose.
 Within a few months, they would form the core of the restarted
 attempt to make the SMRPG translation a reality.  Cecil continued to
 handle the webpage, while Moose diligently translated material and
 FuSoYa took over the ROM modifications by starting the patch over
 from scratch.  By the Christmas of '98, the compression had been
 long defeated, the menus modified, the ROM expanded, a newly created
 VWF ASM code modification implemented, and the translation was on
 its way.

 The work continued on well into 1999.  FuSoYa continued to refine the
 patch, creating tools to add in translated signs, intro credits, etc,
 as Moose finished the lists and kept working away at the scripts.
 In July, Lina`chan (who had recently finished with SD3) joined Moose
 in translating the last of the Japanese material.  With the two's
 combined efforts, the translation was quickly completed in August,
 and testing by Kisai went underway.

 And on Mercury's birthday of September 10th, 1999...the finished SNES
 SMRPG translation patch was released to the public.


______________________________________________________________________

 3. Game Controls
______________________________________________________________________

 While walking around in towns:

 A            : Talk, confirm
 B            : Run, cancel
 X            : Main Menu
 Start        : MakeUp Links Menu
 Select       : Options Menu (text speed, color, etc)
 L/R          : Dash

 While flying on the ark:

 Up/Down      : Move ark forwards/backwards
 Left/Right   : Turn ark Left/Right
 L/R          : Move ark Left/Right without turning
 X            : View Map
 Y            : Transport to the Moon (Silver Millennium)
 A            : Transport to surface while over a town


______________________________________________________________________

 4. Translation notes from Moose
______________________________________________________________________

 This translation has tried to stay as faithful as possible to the
 original Japanese.  Therefore, name suffixes and the original
 Japanese names (eg Mizuno-san) have been left in, and not changed to
 the DiC names. For the uninitiated, a name conversion table has been
 included in the liner notes.  I recommend everyone reads the liner
 notes, even people who have seen the original anime, cause the game
 does include some elements from the manga which'll confuse the hell
 out of you if you don't know what's going on. (Although, if you read
 the manga too, that's ok ^_^)

 Oh yeah, a warning: Cause the original series was a lot more 'mature'
 than the DiC dub, this game consequentially does contain some more
 mature themes (death, love, yadayadayada).
 Be warned :).


______________________________________________________________________

 5. Personal Comments
______________________________________________________________________

    A. Lina`chan

       Yay! Another part for me on a readme! Well first of all Sailor
       Moon is one of my favorite anime! If not my favorite one! ^^ So
       I decided to give my friends of BST a little hand with the
       translation, and as you can see we've come out with a full
       translation! I hope you all enjoy this Sailor Moon game as much
       as we enjoyed working on it. Big hugs to all my friends!
       Oh! And you Sailor Moon fans! If you are into Internet
       text-based role playing games. Come visit Bishoujo Senshi Muck!
       http://members.spree.com/glaive/muck/bishoujosenshi/bishoujosenshi.html
       Or telnet to telnet://tnt.maison-otaku.net:1492
       We will be waiting for you! ^_^

    B. Moose

       Hmm. I really don't have anything to say. Funny that, I usually
       can't shut up :P.

    C. Cecil

       When I first began this project waay back in early '97 or so, I
       wasn't quite sure at the time if it'd ever get finished.  At
       the time, I was the only person I knew working on it, and the
       current well-known players of the ROM scene weren't exactly
       eager to have more people hopping around dipping their hand
       into the rom-hacking cookie jar (Som2Freak, you should be more
       polite to beginning translators :D).  It was just me, my hex
       editor, and a big sheet of graph paper I wrote the hex codes
       to all the japanese characters on.  Fortunately, however, word
       spread of the project and people flocked to my horrible
       Geocities page and offered to help.  Unfortunately, though,
       real-life time constraints being what they were, I eventually
       just took the backseat to keep the website alive while our
       expert coder FuSoYa and our translators hurried the project
       along to its goal.  But luckily it has all finally come
       together, and we can all proudly present you with the
       completely translated Bishoujo Senshi Sailor Moon: Another
       Story.
       Curiously enough, I don't think any of the original group is
       still with us now at the end, but I'd like to thank EVERYONE
       that helped in any possible way, especially the current project
       members and everyone already listed in this text file (without
       whom this wouldn't have been possible!), and of course Artemio
       Urbina for his help in developing some initial code to dump
       scripts, etc, which made our job a lot easier.  Special thanks
       as well to Newton Tron for helping to keep the project and its
       members coordinated in the early stages.  I'd also like to offer
       my acknowledgements for the literally hundreds, if not thousands
       of people who emailed offering support or kind words, and to let
       all the patient, polite folks out there know they're finally
       getting what they've been waiting for.  Thank you!

    D. FuSoYa

       I'd just like to personally thank Moose for his long hours of
       translation work, Lina`chan for graciously aiding us in getting
       past that last translation mile, and Cecil for keeping the page
       alive for so long. I'd also like to thank alt.fan.sailor-moon's
       own Kisai for beta testing the patch over the past few weeks
       for me.  And thanks to TheGun for sending me that snes9x tracer
       a while back, as well as to anyone else involved in creating
       some of the tools I've used at one point or another (ZSNES
       debugger, Yoshi's disassembler, Jeremy Gordon's 65816 assembler,
       Naga, Borland's C++ 5.02 package).

       And for putting up with all our ramblings, here's a small boon
       for anyone that's playing through the game a second time now
       that it's in english but doesn't want to waste time for a few
       initial levels.  When the Sailor Moon title screen shows up,
       hold down X and press start.  You should hear a confirmation
       chime and be taken to the load menu.  Start a new game, and the
       senshi will now begin at level 16 instead of level 1.  Enjoy!

       And since someone will likely ask this anyway: yes, that was
       there in the original game, and no you don't really have to wait
       for your second time through... assuming you don't mind cheating
       your first time through a game meant for little girls. :P
       Ack!  No wait, I didn't mean to imply...!!!

       ::FuSoYa is carried off by a band of angry female gamers and SM
         fans, never to be heard from again::
       

______________________________________________________________________

 6. Legal Notice
______________________________________________________________________

 Bishoujo Senshi Translations' Sailor Moon:Another Story RPG English
 Translation patch (hereafter referred to as the "BST Patch") is not
 official or supported by Nintendo, Angel, Bandai, Kodansha, Toei
 Animation, Naoko Takeuchi, DiC, or any other entity associated with
 the "Sailor Moon" trademark or franchise.

 The BST Patch is freeware thus it can be distributed freely provided
 the following conditions hold:(1) This document is supplied with the
 BST Patch and both the document and patch are not modified in any way
 (2) The BST Patch is not distributed with or as part of any ROM image
 in any format, and (3) No goods, services, or money can be charged
 for the BST Patch in any form, nor may it be included in conjunction
 with any other offer or monetary exchange.

 The BST Patch is provided AS IS, and its use is at your own risk.
 Bishoujo Senshi Translations and anyone mentioned in this document
 will not be held liable for any damages, direct or otherwise, arising
 from its use or presence.
 

______________________________________________________________________

 7. Contact Information
______________________________________________________________________

 Bishoujo Senshi Translations (BST)
   www:   http://smrpg.terminaldogma.net/

 Cecil Stormclaw
   email: cecil@terminaldogma.net

 FuSoYa
   "Rumors of my existence are greatly exaggerated."

 Moose M.
   email: joehigasi@usa.net

 Lina`chan
   www:   http://thor.prohosting.com/~abner/
   email: abner@lfx.org

 Nuku-Nuku
   www:   http://thor.prohosting.com/~abner/
   email: atsuko-natsume@geocities.com
______________________________________________________________________
