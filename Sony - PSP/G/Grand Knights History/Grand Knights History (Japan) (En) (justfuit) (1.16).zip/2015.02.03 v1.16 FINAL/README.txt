Version 1.16 is the final version of this patch.

Thank you to all who have helped make this project possible.

CFOR



To Patch:

1. Extract zipped patch file to folder

2. Use UMDGen and open original Japanese ISO

3. Extract PSP_GAME\USRDIR\GKH.CPK and PSP_GAME\USRDIR\OVERLAY_MO4UMD.bin to folder in (1)

4. Extract PSP_GAME\SYSDIR\EBOOT.BIN to folder in (1)

5. Create folder for patched files (eg. "Patched")

6. Copy xdelta program to folder created in (1)

7. Use xdelta to apply patch and save to folder created in (5)
	xdelta3-3.0.8.x86-64 -d -s GKH.CPK GKH.xdelta Patched\GKH.CPK
	xdelta3-3.0.8.x86-64 -d -s OVERLAY_MO4UMD.BIN OVERLAY_MO4UMD.xdelta Patched\OVERLAY_MO4UMD.BIN
	xdelta3-3.0.8.x86-64 -d -s EBOOT.BIN EBOOT.xdelta Patched\EBOOT.BIN

8. Use UMDGen to re-pack
	Drag Patched\GKH.CPK and Patched\OVERLAY_MO4UMD.BIN to PSP_GAME\USRDIR and overwrite file
	Drag Patched\EBOOT.BIN to PSP_GAME\SYSDIR and overwrite file

9. Save ISO file