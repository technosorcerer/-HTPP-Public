Here are the steps to completely undub your Gurumin ISO:
1. If you haven't already done so, download and install ruby. You can find a Ruby installer for Windows at www.rubyinstaller.org
2. Extract the files in this archive into a new folder.
3. Copy your Gurumin ISO into the folder, and rename it to "gurumin.iso" (without the quotation marks). If you don't make a copy, just remember that this patcher does not back up your original file for you.
3. Optionally you can check that your image is correct for patching. Your image must have an MD5 hash of "5539e5beb44b2873e13cd541a2d9ba47" to be patched correctly. If not, you probably have a different version of the game than I do.
4. Patch your game by running "usatojap.rb".
5. Enjoy. ;)

Changelog:

1.02 - Ruby 2.0 compatability.

1.01 - Usability improvements.

1.0 - Initial release.