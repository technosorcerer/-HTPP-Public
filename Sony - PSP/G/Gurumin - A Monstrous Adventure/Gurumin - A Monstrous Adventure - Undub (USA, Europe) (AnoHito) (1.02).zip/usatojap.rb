begin

$LOAD_PATH << Dir.pwd
require "iso9660"

stream = File.open("gurumin.iso", "rb+")
iso = ISO.new(stream)

jap = iso.root["PSP_GAME"]["USRDIR"]["vag_jp"]
usa = iso.root["PSP_GAME"]["USRDIR"]["vag"]

jap.entries.each do | name |
  jap_entry = jap.entry(name)
  usa_entry = usa.entry(name)
  
  usa_entry.extent_lba = jap_entry.extent_lba
  usa_entry.data_length = jap_entry.data_length
  
  stream.pos = usa_entry.position
  usa_entry.dump(stream)
end

entry = iso.root["PSP_GAME"]["USRDIR"].entry("aaaa.lst")
stream.pos = entry.extent_lba * iso.lba_size
buffer = File.open("aaaa.lst", "rb+").read()
stream.write(buffer)

eboot_entry = iso.root["PSP_GAME"]["SYSDIR"].entry("EBOOT.BIN")
boot_entry = iso.root["PSP_GAME"]["SYSDIR"].entry("BOOT.BIN")

eboot_entry.extent_lba = boot_entry.extent_lba
eboot_entry.data_length = boot_entry.data_length

stream.pos = eboot_entry.position
eboot_entry.dump(stream)

stream.pos = boot_entry.extent_lba * iso.lba_size
buffer = stream.read(boot_entry.data_length)

buffer[473956] = 0x98.chr
buffer[474240] = 0x98.chr
buffer[474600] = 0x98.chr
buffer[474932] = 0x98.chr
buffer[475348] = 0x98.chr
buffer[475700] = 0x98.chr
buffer[476116] = 0x98.chr
buffer[476840] = 0x98.chr

stream.pos = boot_entry.extent_lba * iso.lba_size
stream.write(buffer)

puts("Patching successful! ...probably.")

rescue => error

  puts("Error: #{error}")
  error.backtrace.each do | line |
    puts(line)
  end

end

system("pause")
exit()