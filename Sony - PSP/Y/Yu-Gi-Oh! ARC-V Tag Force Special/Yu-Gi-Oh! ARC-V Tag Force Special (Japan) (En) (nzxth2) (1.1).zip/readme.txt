Yu-Gi-Oh! ARC-V Tag Force Special
English Translation
Playstation Portable


.------------::[ Release Notes ]::-------------
|
| This release includes two patch files:
| "TFSP_english_retranslation.xdelta" is applied 
| to the original Japanese ISO and generates an 
| English patched ISO.
| "TFSP_reverse_patch.xdelta" can be applied to the 
| English patched ISO to turn it back into the original
| Japanese ISO.
|
|
| List of changes in this release:
|
| - This release is based on the Ultimate ISO V2.1
|   by FLS Gaming Projects 
|
| - The story translation is notably incomplete and is 
|   being released as-is, because a better translation 
|   patch is already in the works by GLLance99
|   
| - Story Translation Progress: 
|   DM:   All Events and Pre-/Post-Duel messages translated 
|   GX:   All Events and Pre-/Post-Duel messages translated
|   5D's: All Events and Pre-/Post-Duel messages translated
|
|   ZEXAL:
|   Events translated for Yuma, Shark & Kaito
|   Kotori & Rio untranslated
|   Pre-/Post-Duel messages translated for most of the
|   important (non-filler) characters
|
|   ARC-V:
|   Only Pre-/Post-Duel messages for main characters translated
|   Events untranslated
|
|   Other:
|   Pre-/Post-Duel messages untranslated for Game-Original-NPCs
|   Tournament messages untranslated
|
| - I've redone the In-Duel Subtitles for ~50 characters,
|   including all of the DM characters
|   I tried to fix the worst offenders, but if you want to
|   play it safe, you can always turn Duel Effects OFF
|   (in Options > Duel Settings) until a complete retranslation
|   is released. Most characters aren't voiced (yet) anyway...
|
`---------------------------------------------------


.-----------::[ Patching Instructions ]::-----------
|
| The .xdelta patch files shipped with this release 
| can be applied with the included DeltaPatcherLite.
|
| 1) Choose the original file
|
| 2) Choose the xdelta patch file you wish to apply
|
| 3) Click "Apply patch" to generate the patched ISO.
|    - The patched ISO will overwrite the original ISO
|      unless the "Backup original file" option is 
|      selected in the settings.
|
`---------------------------------------------------


.------------------::[ Credits ]::------------------
|
| Card Translations & Initial Patch:
| Omarrrio & XenoTranslations
|
| Various Fixes (Names, Deck Names, Character Bios, In-Duel Subtitles):
| FLS Gaming Projects
|
| Story Translation:
| nzxth2
|
`---------------------------------------------------