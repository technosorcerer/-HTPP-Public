import binascii
import os
import shutil
import struct
import zlib

filelist = ['SPOT_COLISEUM.NPK.ZZZ',
            'SPOT_SHOP_ARMOR.NPK.ZZZ',
            'SPOT_SHOP_ITEM.NPK.ZZZ',
            'SPOT_SHOP_WEAPON.NPK.ZZZ',
            'IF_TRAVELMAP.NPK']
offsetlist = [0x7BB0, 0xCE70, 0xCE70, 0xCE70, 0x40]
infilelist = ['SPOT_COLISEUM.tsv', 'SPOT_SHOP.tsv', 'SPOT_SHOP.tsv',
              'SPOT_SHOP.tsv', 'IF_TRAVELMAP.tsv']
def unpack():
    for filename, offset in zip(filelist, offsetlist):
        basename = filename[:filename.find('.')]
        with open(filename, 'rb') as f:
            if '.ZZZ' in filename:
                with open(filename[:-4], 'wb') as g:
                    f.seek(0x10)
                    filedata = zlib.decompress(f.read())
                    g.write(filedata)
            else:
                filedata = f.read()
        size = struct.unpack('<I', filedata[offset:offset+4])[0]
        offset += 4
        with open(basename + '.tsv', 'w', encoding='utf-8') as f:
            data = filedata[offset:offset+size].split(b'\x00')[:-1]
            f.write('\n'.join([str(i) + '\t' + x.decode('utf-8') for i, x in enumerate(data)]))            

def pack():
    missing = []
    for filename in filelist:
        basename = filename[:filename.find('.')]
        if '.ZZZ' in filename:
            if os.path.isfile(basename + '.NPK'):
                pass
            elif os.path.isfile(filename):
                with open(filename, 'rb') as f:
                    with open(basename + '.NPK', 'wb') as g:
                        f.seek(0x10)
                        g.write(zlib.decompress(f.read()))
            else:
                missing.append(filename)
        else:
            if os.path.isfile(basename + '.orig'):
                pass
            elif os.path.isfile(filename):
                shutil.copy(filename, basename + '.orig')
            else:
                missing.append(filename)
    for filename in set(infilelist):
        if not os.path.isfile(filename):
            missing.append(filename)
    if len(missing) > 0:
        print('Missing files: {}'.format(', '.join(missing)))
        quit()
    for filename, offset, infile in zip(filelist, offsetlist, infilelist):
        basename = filename[:filename.find('.')]
        inputdata = []
        with open(infile, 'r', encoding='utf-8') as f:
            for line in f:
                inputdata.append(line.rstrip('\r\n').split('\t')[2].encode('utf-8'))
        inputdata = b'\x00'.join(inputdata) + b'\x00'
        if '.ZZZ' in filename:
            filename1 = basename + '.NPK'
        else:
            filename1 = basename + '.orig'
        with open(filename1, 'rb') as f:
            filedata = bytearray(f.read())
        size = struct.unpack('<I', filedata[offset:offset+4])[0]
        filedata[offset:offset+4] = struct.pack('<I', len(inputdata))
        offset += 4
        filedata[offset:offset+size] = b'\x00' * size
        filedata[offset:offset+len(inputdata)] = inputdata
        #Uncomment for output of uncompressed files
##        with open(basename + '.unc', 'wb') as f:
##            f.write(filedata)
        if '.ZZZ' in filename:
            with open(filename, 'wb') as f:
                f.write(b'CZAA')
                f.write(struct.pack('<I', len(filedata)))
                f.write(b'\x00' * 8)
                f.write(zlib.compress(filedata))
        else:
            with open(filename, 'wb') as f:
                f.write(filedata)
