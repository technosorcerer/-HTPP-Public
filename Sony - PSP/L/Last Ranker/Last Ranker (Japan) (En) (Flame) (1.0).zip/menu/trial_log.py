import binascii
import os
import struct
import zlib

BASE_POS = 0xDD60

def text_decode(s):
    while '{' in s:
        s1 = s[:s.find('{')]
        s2 = s[s.find('{') + 1:s.find('}')]
        s3 = s[s.find('}') + 1:]
        s = s1 + binascii.unhexlify(s2).decode('ascii') + s3
    return s

def unpack():
    header_pos = 0xDD62
    with open('MENU_TRIAL_LOG.NPK.ZZZ', 'rb') as f:
        f.seek(0x10)
        filedata = zlib.decompress(f.read())
    with open('MENU_TRIAL_LOG.NPK', 'wb') as f:
        f.write(filedata)
    for i in range(0x40):
        offset = struct.unpack('<I', filedata[header_pos:header_pos+3] + b'\x00')[0] + BASE_POS
        while offset % 0x10 != 0:
            offset += 1
        header_pos += 3
        size = struct.unpack('<I', filedata[offset:offset+4])[0]
        offset += 4
        with open('TL{:0>2d}.txt'.format(i), 'wb') as f:
            f.write(b'\n'.join(filedata[offset:offset+size].split(b'\x00')))

def pack():
    header_pos = 0xDD62
    if os.path.isfile('MENU_TRIAL_LOG.NPK'):
        pass
    elif os.path.isfile('MENU_TRIAL_LOG.NPK.ZZZ'):
        with open('MENU_TRIAL_LOG.NPK.ZZZ', 'rb') as f:
            with open('MENU_TRIAL_LOG.NPK', 'wb') as g:
                f.seek(0x10)
                g.write(zlib.decompress(f.read()))
    else:
        print('File MENU_TRIAL_LOG.NPK.ZZZ not found.')
        quit()
    with open('MENU_TRIAL_LOG.NPK', 'rb') as f:
        filedata = bytearray(f.read())
    for x in range(41):
        inputdata = []
        with open('TL{:0>2d}.tsv'.format(x), 'r', encoding='utf-8') as f:
            for i, line in enumerate(f):
                line = line.rstrip('\r\n').split('\t')
                if i in (3, 4, 5):
                    inputdata[-1] += '\n' + line[1]
                else:
                    inputdata.append(line[1])
        inputdata += [''] * (43 - len(inputdata))
        inputdata = b'\x00'.join([y.encode('ascii') for y in inputdata])
        offset = struct.unpack('<I', filedata[header_pos:header_pos+3] + b'\x00')[0] + BASE_POS
        while offset % 0x10 != 0:
            offset += 1
        header_pos += 3
        size = struct.unpack('<I', filedata[offset:offset+4])[0]
        filedata[offset:offset+4] = struct.pack('<I', len(inputdata))
        offset += 4
        filedata[offset:offset+size] = b'\x00' * size
        filedata[offset:offset+len(inputdata)] = inputdata
    inputdata = []
    with open('Z0_4_0.tsv', 'r', encoding='utf-8') as f:
        for line in f:
            line = line.rstrip('\r\n').split('\t')
            inputdata.append(line[2])
    inputdata = b'\x00'.join([y.encode('ascii') for y in inputdata])
    inputdata = struct.pack('<I', len(inputdata) + 4) + inputdata + b'\x00' * 4
    offset = 0x14C60
    filedata[offset:] = inputdata
    filedata[0x8:0xB] = struct.pack('<I', len(filedata))[:3]
    if len(filedata) % 0x10 != 0:
        filedata += b'\x00' * (0x10 - len(filedata) % 0x10)
    #Uncomment for decompressed data output
##    with open('output.bin', 'wb') as f:
##        f.write(filedata)
    with open('MENU_TRIAL_LOG.NPK.ZZZ', 'wb') as f:
        f.write(b'CZAA')
        f.write(struct.pack('<III', len(filedata), 0, 0))
        f.write(zlib.compress(filedata))
