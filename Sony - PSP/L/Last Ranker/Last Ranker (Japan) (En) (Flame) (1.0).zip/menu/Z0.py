import binascii
import os
import shutil
import struct
import zlib
import pdb

filelist = [[0x00000030, [0x2]],
            [0x00005120, [0x2]],
            [0x0000A580, [0x2]],
            [0x0000E770, [0x2]],
            [0x00011CC0, [0x5]],
            [0x000170E0, [0x2, 0x14, 0x17]],
            [0x0001BDE0, [0x2]]]
def text_decode(s):
    while '{' in s:
        s1 = s[:s.find('{')]
        s2 = s[s.find('{') + 1:s.find('}')]
        s3 = s[s.find('}') + 1:]
        s = s1 + binascii.unhexlify(s2).decode('utf-8') + s3
    return s

def unpack():
    for i, (filename, offsets) in enumerate(filelist):
        with open(filename + '.orig', 'rb') as f:
            for j, offset in enumerate(offsets):
                f.seek(offset)
                offset = struct.unpack('<I', f.read(3) + b'\x00')[0]
                f.seek(offset)
                while f.tell() % 0x10 != 0:
                    f.read(1)
                read_size = struct.unpack('<I', f.read(4))[0]
                s = f.read(read_size)
                s = s.split(b'\x00')[:-1]
                output = []
                for k, x in enumerate(s):
                    output.append(str(k) + '\t')
                    output.append(x.decode('utf-8').replace('\n', '\n\t') + '\n')
                with open('Z0_{}_{}.txt'.format(i, j), 'w', encoding='utf-8') as g:
                    g.write(''.join(output))

def pack():
    filelist1 = (
        tuple('Z0_{}_0.tsv'.format(i) for i in range(7)) +
        ('Z0_5_1.tsv', 'Z0_5_2.tsv', 'Z0.NPK') +
        tuple('TL{:0>2}.tsv'.format(i) for i in range(41)))
    missing = []
    for filename in filelist1:
        if not os.path.isfile(filename):
            missing.append(filename)
    if len(missing) > 0:
        print('Missing files: {}'.format(', '.join(missing)))
        quit()
    import trial_log
    trial_log.pack()
    filename1 = 'Z0.NPK'
    if os.path.exists(filename1 + '.orig'):
        pass
    elif os.path.exists(filename1):
        shutil.copy(filename1, filename1 + '.orig')
    filedata = bytearray()
    filedata += struct.pack('<H', 7)
    filedata += struct.pack('<I', 0x20)[:3]
    filedata += b'\x00' * (0x20 - len(filedata))
    header_pos = 0x5
    for i, (offset1, offsets) in enumerate(filelist):
        if offset1 == 0x00011CC0:
            with open('MENU_TRIAL_LOG.NPK.ZZZ', 'rb') as f:
                filedata += f.read()
            filedata[header_pos:header_pos+3] = (
                struct.pack('<I', len(filedata))[:3])
            while len(filedata) % 0x10 != 0:
                filedata += b'\x00'
            header_pos += 3
            continue
        with open(filename1 + '.orig', 'rb') as f:
            f.seek(offset1)
            filedata1 = bytearray(zlib.decompress(f.read()))
        for j, offset in enumerate(offsets):
            inputdata = []
            with open('Z0_{}_{}.tsv'.format(i, j), 'r', encoding='utf-8') as g:
                for line in g:
                    line = line.rstrip('\r\n').split('\t')
                    if line[0] != '':
                        inputdata.append(line[2].encode('utf-8'))
                    else:
                        inputdata[-1] += b'\n' + line[2].encode('utf-8')
            inputdata = b'\x00'.join(inputdata) + b'\x00'
            offset = struct.unpack('<I', filedata1[offset:offset+3] + b'\x00')[0]
            while offset % 0x10 != 0:
                offset += 1
            data_len = struct.unpack('<I', filedata1[offset:offset+4])[0]
            filedata1[offset:offset+4] = struct.pack('<I', len(inputdata))
            offset += 4
            filedata1[offset:offset+data_len] = b'\x00'*data_len
            filedata1[offset:offset+len(inputdata)] = inputdata
        #Uncomment for decompressed data output
##        with open(str(i) + '.bin', 'wb') as g:
##            g.write(filedata1)
        filedata += b'CZAA'
        filedata += struct.pack('<III', len(filedata1), 0, 0)
        filedata += zlib.compress(filedata1)
        filedata[header_pos:header_pos+3] = struct.pack('<I', len(filedata))[:3]
        header_pos += 3
        while len(filedata) % 0x10 != 0:
            filedata += b'\x00'
    with open('Z0.NPK', 'wb') as f:
        f.write(filedata)
