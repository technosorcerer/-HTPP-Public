#Let's just import the entire Python standard library (this is like 1/3 of it)
import binascii
import gzip
import os
import shutil
import struct
import subprocess
import sys
import tempfile
import zlib
import pdb

import ISO_extract

target_dir = os.getcwd()
os.chdir(os.path.split(os.path.realpath(__file__))[0])

filelist = [ \
'MAP_D_CAD_00', 'MAP_D_CAD_01', 'MAP_D_CAD_02', 'MAP_D_CAD_03', 'MAP_D_CAD_04',
'MAP_D_CAN_00', 'MAP_D_CAN_01', 'MAP_D_CAN_02', 'MAP_D_CAN_03', 'MAP_D_CAN_04',
'MAP_D_DNE_00', 'MAP_D_DNE_01', 'MAP_D_DNE_02', 'MAP_D_DNE_03', 'MAP_D_DNE_04',
'MAP_D_DNE_05', 'MAP_D_DOU_00', 'MAP_D_DOU_01', 'MAP_D_DOU_02', 'MAP_D_DOU_03',
'MAP_D_HEI_00', 'MAP_D_HEI_01', 'MAP_D_HEI_02', 'MAP_D_HEI_03', 'MAP_D_KFO_00',
'MAP_D_KFO_01', 'MAP_D_KFO_02', 'MAP_D_KFO_03', 'MAP_D_KFO_04', 'MAP_D_KHI_00',
'MAP_D_KHI_01', 'MAP_D_KHI_02', 'MAP_D_KHI_03', 'MAP_D_KHI_04', 'MAP_D_KOU_00',
'MAP_D_KOU_01', 'MAP_D_KOU_02', 'MAP_D_KOU_03', 'MAP_D_KOU_04', 'MAP_D_LUK_00',
'MAP_D_LUK_01', 'MAP_D_LUK_02', 'MAP_D_LUK_03', 'MAP_D_LUK_04', 'MAP_D_LUK_05',
'MAP_D_LUK_06', 'MAP_D_LUK_07', 'MAP_D_LUK_08', 'MAP_D_MAI_00', 'MAP_D_MAI_01',
'MAP_D_MAI_02', 'MAP_D_MAI_03', 'MAP_D_MAI_04', 'MAP_D_NIS_00', 'MAP_D_NIS_01',
'MAP_D_NIS_02', 'MAP_D_NIS_03', 'MAP_D_NIS_04', 'MAP_D_OBT_00', 'MAP_D_OBT_01',
'MAP_D_OBT_02', 'MAP_D_OBT_03', 'MAP_D_OBT_04', 'MAP_D_REZ_00', 'MAP_D_REZ_01',
'MAP_D_REZ_02', 'MAP_D_REZ_03', 'MAP_D_REZ_04', 'MAP_D_RIV_00', 'MAP_D_RIV_01',
'MAP_D_RIV_02', 'MAP_D_RIV_03', 'MAP_D_RIV_04', 'MAP_D_SAB_00', 'MAP_D_SAB_01',
'MAP_D_SAB_02', 'MAP_D_SAB_03', 'MAP_D_SAL_00', 'MAP_D_SAL_01', 'MAP_D_SAL_02',
'MAP_D_SAL_03', 'MAP_D_SAL_04', 'MAP_D_SIN_00', 'MAP_D_SIN_01', 'MAP_D_SIN_02',
'MAP_D_SIN_03', 'MAP_D_SOD_00', 'MAP_D_SOD_01', 'MAP_D_SOD_02', 'MAP_D_SOD_03',
'MAP_D_SOD_04', 'MAP_D_ZEK_00', 'MAP_I_ANT_00', 'MAP_I_BAS_00', 'MAP_I_BAS_01',
'MAP_I_BAS_02', 'MAP_I_BAS_03', 'MAP_I_BAS_04', 'MAP_I_BAS_05', 'MAP_I_BAS_06',
'MAP_I_BAS_07', 'MAP_I_BAS_08', 'MAP_I_BAS_09', 'MAP_I_BAS_10', 'MAP_I_BAS_13',
'MAP_I_GAN_00', 'MAP_I_GAN_01', 'MAP_I_GAN_02', 'MAP_I_GAN_03', 'MAP_I_GAN_04',
'MAP_I_GAN_05', 'MAP_I_GAN_06', 'MAP_I_GAN_08', 'MAP_I_GAN_09', 'MAP_I_GAN_10',
'MAP_I_GAN_11', 'MAP_I_GAN_12', 'MAP_I_GAN_13', 'MAP_I_GAN_14', 'MAP_I_GAN_15',
'MAP_I_GAN_16', 'MAP_I_GAN_17', 'MAP_I_GAN_18', 'MAP_I_GAN_19', 'MAP_I_GAN_20',
'MAP_I_GAN_21', 'MAP_I_GAN_22', 'MAP_I_GAN_23', 'MAP_I_GAN_24', 'MAP_I_GAN_25',
'MAP_I_GAN_26', 'MAP_I_GAN_27', 'MAP_I_GAN_28', 'MAP_I_GAN_29', 'MAP_I_GAN_30',
'MAP_I_GAN_31', 'MAP_I_GAN_32', 'MAP_I_GAN_33', 'MAP_I_GAN_34', 'MAP_I_GAN_35',
'MAP_I_GAN_36', 'MAP_I_KAN_00', 'MAP_I_KAN_01', 'MAP_I_KAN_02', 'MAP_I_KAN_03',
'MAP_T_ANT_00', 'MAP_T_ANT_01', 'MAP_T_ANT_02', 'MAP_T_ANT_03', 'MAP_T_ANT_04',
'MAP_T_GAN_00', 'MAP_T_GAN_01', 'MAP_T_GAN_02', 'MAP_T_GAN_03', 'MAP_T_GAN_04',
'MAP_T_GAN_05', 'MAP_T_GAN_06', 'MAP_T_GAN_07', 'MAP_T_GAN_08', 'MAP_T_GAN_09',
'MAP_T_KAN_00', 'MAP_T_KAN_01']

newfilename = target_dir + '\\' + 'LRpatched.iso'
target_checksum = 0xdc47ee2e

def apply_patch(sourcefile, patchfile):
    try:
        os.remove(sourcefile + '.orig')
    except FileNotFoundError:
        pass
    os.rename(sourcefile, sourcefile + '.orig')
    subprocess.run(['xdelta', '-d', '-s', sourcefile + '.orig', patchfile, sourcefile])
    os.remove(sourcefile + '.orig')

def apply_patch_compressed(sourcefile, patchfile):
    '''Apply a patch to the decompressed version of a file, then re-compress.

    Pseudocode: decompress, apply patch, compress.
    Only supports gzip.
    '''
    with tempfile.NamedTemporaryFile(delete = False) as f:  #Decompress
        dec = f.name
        with gzip.open(sourcefile) as g:
            mtime = g.mtime
            f.write(g.read())
    with tempfile.NamedTemporaryFile() as f:                #Apply patch
        patched = f.name        #Just need a name
    subprocess.run(['xdelta', '-d', '-s', dec, patchfile, patched])
    os.remove(dec)
    with gzip.GzipFile(sourcefile, 'wb', mtime=mtime) as f:     #Re-compress
        with open(patched, 'rb') as g:
            f.write(g.read())
    os.remove(patched)

def apply_patch_compressed_ranker(sourcefile, patchfile):
    '''Apply a patch to the decompressed version of a file, then re-compress.

    Pseudocode: decompress, apply patch, compress.
    Uses zlib. Special Last Ranker file format.
    '''
    with tempfile.NamedTemporaryFile(delete = False) as f:  #Decompress
        dec = f.name
        with open(sourcefile, 'rb') as g:
            g.seek(0x10)
            f.write(zlib.decompress(g.read()))
    size = os.path.getsize(dec)
    with tempfile.NamedTemporaryFile() as f:                #Apply patch
        patched = f.name        #Just need a name
    subprocess.run(['xdelta', '-d', '-s', dec, patchfile, patched])
    os.remove(dec)
    with open(sourcefile, 'wb') as f:                       #Re-compress
        f.write(b'CZAA')
        f.write(struct.pack('<III', size, 0, 0))
        with open(patched, 'rb') as g:
            f.write(zlib.compress(g.read()))
    os.remove(patched)

def apply_patch_Z0():
    '''Multiple compressed streams in Z0'''
    with open('Z0.NPK', 'rb') as f:                         #Extract
        f.seek(2)
        offsets = []
        for i in range(7):
            offsets.append(struct.unpack('<I', f.read(3) + b'\x00')[0])
        for i in range(7):
            with open('Z{}.bin.orig'.format(i), 'wb') as g:
                f.seek(offsets[i])
                while f.tell() % 0x10 != 0:
                    f.seek(1, 1)
                f.seek(0x10, 1)
                g.write(zlib.decompress(f.read()))
            subprocess.run([                                #Apply patches
                'xdelta', '-d', '-s', 'Z{}.bin.orig'.format(i),
                'Z{}.xdelta'.format(i), 'Z{}.bin'.format(i)])
            os.remove('Z{}.bin.orig'.format(i))
    with open('Z0.NPK', 'wb+') as f:                        #Rebuild
        f.write(struct.pack('<H', 7))
        f.write(struct.pack('<I', 0x20)[:3])
        header_pos = f.tell()
        f.write(b'\x00' * (0x20 - f.tell()))
        for i in range(7):
            f.write(b'CZAA')
            size = os.path.getsize('Z{}.bin'.format(i))
            f.write(struct.pack('<III', size, 0, 0))
            with open('Z{}.bin'.format(i), 'rb') as g:
                f.write(zlib.compress(g.read()))
            pos = f.tell()
            f.seek(header_pos)
            f.write(struct.pack('<I', pos)[:3])
            header_pos += 3
            f.seek(pos)
            while f.tell() % 0x10 != 0:
                f.write(b'\x00')
            os.remove('Z{}.bin'.format(i))

def apply_patch_EBOOT(sourcefile, patchfile):
    '''decrypt EBOOT in sourcefile and apply a patch

    Involves decryption.
    '''
    with tempfile.NamedTemporaryFile() as f:
        dec = f.name            #Just need a name
    subprocess.run(['deceboot', sourcefile, dec])
    os.remove(sourcefile)
    subprocess.run(['xdelta', '-d', '-s', dec, patchfile, sourcefile])
    os.remove(dec)

print('xdelta copyright Josh MacDonald. See xdelta_README.md for details.')
print('deceboot copyright NoOneee. See deceboot_LICENSE.txt for details.')
print('Computing checksum, target = {}'.format(hex(target_checksum)))
oldfilename = 'LR.iso'
if len(sys.argv) == 2:
    oldfilename = sys.argv[1]
if not os.path.isfile(oldfilename):
    print('File {} not found.'.format(oldfilename))
    quit()
##with open(oldfilename, 'rb') as f:
##    checksum = binascii.crc32(f.read())
##if checksum == target_checksum:
##    print('Checksum {} verified.'.format(hex(checksum)))
##else:
##    print('Checksum {}. Failed verification.'.format(hex(checksum)))
##    quit()
filelist1 = [x + '.BIN' for x in filelist]
filelist2 = ['GAMEDATA\\FLD\\MAP\\{}.BIN'.format(x) for x in filelist]

print('Extracting files...')
#Call type 1 is a folder and list of files
ISO_extract.ISO_extract(oldfilename, r'GAMEDATA\FLD\MAP', filelist1)
#Call type 2 is a path. Paths can be partial
ISO_extract.ISO_extract(oldfilename, r'SYSDIR\EBOOT.BIN')
ISO_extract.ISO_extract(oldfilename, r'USRDIR\GAMEDATA\SYSTEM.VOL')
ISO_extract.ISO_extract(oldfilename, r'USRDIR\GAMEDATA\MENU',
                        ['MENU_TRIAL_LOG.NPK.ZZZ', 'Z0.NPK'])
c_list = ['SPOT_COLISEUM', 'SPOT_SHOP_ARMOR', 'SPOT_SHOP_ITEM',
          'SPOT_SHOP_WEAPON']
ISO_extract.ISO_extract(oldfilename,
                        r'USRDIR\GAMEDATA\IF\RES\IF_TRAVELMAP.NPK')
ISO_extract.ISO_extract(oldfilename, r'USRDIR\GAMEDATA\IF\RES',
                        (x + '.NPK.ZZZ' for x in c_list))

print('Applying patches...')
#Patch GAMEDATA\FLD\MAP files
for filename in filelist:
    apply_patch_compressed(filename + '.BIN', filename + '.xdelta')
#Patch EBOOT
apply_patch_EBOOT('EBOOT.BIN', 'EBOOT.xdelta')
apply_patch('SYSTEM.VOL', 'SYSTEM.xdelta')
apply_patch_compressed_ranker('MENU_TRIAL_LOG.NPK.ZZZ',
                              'MENU_TRIAL_LOG.xdelta')
apply_patch_Z0()
apply_patch('IF_TRAVELMAP.NPK', 'IF_TRAVELMAP.xdelta')
for filename in c_list:
    apply_patch_compressed_ranker('{}.NPK.ZZZ'.format(filename),
                                  '{}.xdelta'.format(filename))

print('Checking path integrity...')
with open(oldfilename, 'rb') as f:
    pathtbl = ISO_extract.getpathtbl(f)
    f.seek(16 * 0x800 + 0x50)
    lastLBA = struct.unpack('<I', f.read(4))[0]
flag = False
for a, b in zip(filelist1, filelist2):
    if not os.path.isfile(a):
        flag = True
        print('File not found: {}'.format(a))
    if not ISO_extract.get_dir_rec(b, pathtbl):
        flag = True
        print('Not found in ISO: {}'.format(b))
if flag:
    quit()
LBAlist = [dir_rec.LBA for path_rec in pathtbl[1:] for dir_rec in path_rec.dir_tbl]
LBAlist.append(lastLBA)
LBAlist.sort()

print('Making a copy of the ISO...')
shutil.copy(oldfilename, newfilename)
print('Replacing files...')
res_list = ('IF_TRAVELMAP.NPK', 'SPOT_COLISEUM.NPK.ZZZ',
            'SPOT_SHOP_ARMOR.NPK.ZZZ', 'SPOT_SHOP_ITEM.NPK.ZZZ',
            'SPOT_SHOP_WEAPON.NPK.ZZZ')
with open(newfilename, 'r+b') as f:
    for replace_file, replace_path in zip(filelist1, filelist2):
        ISO_extract.replace(f, replace_path, replace_file, pathtbl, LBAlist)
    ISO_extract.replace(f, r'SYSDIR\EBOOT.BIN', 'EBOOT.BIN', pathtbl, LBAlist)
    ISO_extract.replace(f, r'USRDIR\GAMEDATA\SYSTEM.VOL', 'SYSTEM.VOL',
                        pathtbl, LBAlist)
    ISO_extract.replace(f, r'USRDIR\GAMEDATA\MENU\MENU_TRIAL_LOG.NPK.ZZZ',
                        'MENU_TRIAL_LOG.NPK.ZZZ', pathtbl, LBAlist)
    ISO_extract.replace(f, r'USRDIR\GAMEDATA\MENU\Z0.NPK', 'Z0.NPK', pathtbl, LBAlist)
    for filename in res_list:
        ISO_extract.replace(f, r'USRDIR\GAMEDATA\IF\RES''\\' +
                            filename, filename, pathtbl, LBAlist)

print('Patching completed. Removing temporary files...')
#Clean up
for filename in filelist1:
    os.remove(filename)
for filename in res_list:
    os.remove(filename)
for filename in ('EBOOT.BIN', 'SYSTEM.VOL', 'MENU_TRIAL_LOG.NPK.ZZZ', 'Z0.NPK'):
    os.remove(filename)
print('Finished.')
