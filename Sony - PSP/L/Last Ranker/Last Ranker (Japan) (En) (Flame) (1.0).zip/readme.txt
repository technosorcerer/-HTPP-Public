Last Ranker partial (~50%)

Done:
Interface
Item lists and descriptions
Most of the main story (scripts)

Not done:
Images
Remainder of the scripts. These remain legible in Japanese.

For patching, see How to Patch.txt.

Hacking:                flamethrower
Script Translation:     EnglishSubs4All
Additional Translation: flamethrower

Tools used:
deceboot by NoOneee, http://www.romhacking.net/community/4084/
offzip by Luigi Auriemma, http://aluigi.altervista.org/mytoolz.htm (was used for investigation purposes)
xdelta by Josh MacDonald, http://xdelta.org/
armips by Kingcom, https://github.com/Kingcom/armips

All scripts are authored for Python 3.

Motivation
A nice user by the name of EnglishSubs4All made a series of subtitled YouTube videos you can find here:
https://www.youtube.com/watch?v=la_ou-TclIY&list=PLJuBs-ZY7iMpM13fIV1_L0cs4YahJK1TD

They also made their AegisSub subtitle scripts (.ass) available in the hopes someone would come along and create a patch for the game. You can find those here:
https://www.mediafire.com/?d65adgx6931owoj

I thought it would be a shame to let their good work go to waste.

-----------------------
I don't really like playing games anymore, I just like romhacking.
User Stormyu indicated that a patch could be done:
http://gbatemp.net/threads/last-ranker-translation-patch.343425/#post-4562643
http://gbatemp.net/threads/last-ranker-translation-patch.343425/#post-4562837

I contacted him but he hadn't any notes for me and also, he hadn't yet figured everything out, it seemed. 

Before this project started I didn't know what gzip headers looked like and that proved to be an obstacle. I asked for help on the script format but I ended up figuring out everything myself. Translators to help me with the rest haven't been forthcoming either; it seems like no ones cares about this game. Anyhow, I don't care about it anymore so I'm releasing this partial in the hopes someone will someday finish it.

There's two parts to this patch:
1) The current version (50% translated)
2) Tools to help you build your own version with more or changed text

Folder patchdata has everything needed to build the current version.

For building your own version, you will need UMDgen:
http://www.romhacking.net/utilities/1218/
Use UMDgen to extract files and also to put modified file back into the ISO.

You will also need my code for Google Sheets .tsv export menu code: 
http://pastebin.com/Aw4r0bkW

The build tools are distributed across four folders:

Folder EBOOT has EBOOT.asm, a script designed for use with armips. The script's function is to remove the automatic line wrapping built into the game.

Folder db has everything needed to build SYSTEM.VOL. This is the game's database file and it's always in memory during the runtime. Its various parts are decompressed as needed depending on the game situation. The text here is used in various game situations. You need GAMEDATA\SYSTEM.VOL as the source file to make these tools work. Refer to _notes_db for more information.

Folder menu has everything needed to build Z0.NPK and MENU_TRIAL_LOG.NPK, data that is used when various menus are open. Z0.NPK is the main menu and MENU_TRIAL_LOG is used when inspecting the various training boards in the game. The original menu files are located in GAMEDATA\MENU. Refer to _notes_menu.txt for more information.

Folder script has everything needed to build the game's script files (.BIN). You need the script files in GAMEDATA\FLD\MAP to make these tools work. Refer to _notes_script.txt for more information.