import binascii
import pdb
import os
import shutil
import struct

BASE_POS = 0xDD60
filename = 'fld_resident.bin'

def text_decode(s):
    while '{' in s:
        s1 = s[:s.find('{')]
        s2 = s[s.find('{') + 1:s.find('}')]
        s3 = s[s.find('}') + 1:]
        s = s1 + binascii.unhexlify(s2).decode('ascii') + s3
    return s

def unpack():
    with open('fld_resident.bin.orig', 'rb') as f:
        filedata = f.read()
    offset = 0x110
    output = []
    while offset < 0x5100:
        name1 = filedata[offset:filedata.find(b'\x00', offset)]
        offset += 0xC
        name2 = filedata[offset:filedata.find(b'\x00', offset)]
        offset += 0x28
        output.append([name1, name2])
    with open('fld_resident_1.txt', 'wb') as f:
        f.write(b'\n'.join([x + b'\t' + y for x, y in output]))
    output = []
    offset = 0x4AF8
    while offset < 0x5100 and filedata[offset] != 0:
        name1 = filedata[offset:filedata.find(b'\x00', offset)]
        offset += 23
        output.append(name1)
    with open('fld_resident_2.txt', 'wb') as f:
        f.write(b'\n'.join(output))
    output = []
    offset = 0x4C36
    while filedata[offset] > 0x80:
        name1 = filedata[offset:filedata.find(b'\x00', offset)]
        temp = filedata.find(b'\x00', offset)
        while filedata[temp] == 0:
            temp += 1
        offset += 0x2A
        output.append(name1)
    with open('fld_resident_3.txt', 'wb') as f:
        f.write(b'\n'.join(output))
    
def pack():
    if os.path.isfile(filename + '.orig'):
        pass
    elif os.path.isfile(filename):
        shutil.copy(filename, filename + '.orig')
    else:
        print('File {} not found.'.format(filename))
        return
    with open(filename + '.orig', 'rb') as f:
        filedata = bytearray(f.read())
    offset = 0x11C
    inputdata = []
    with open('fld1.tsv', 'r', encoding='utf-8') as f:
        for line in f:
            inputdata.append(line.rstrip('\r\n').split('\t')[2].encode('ascii'))
    for data in inputdata:
        filedata[offset:offset+34] = data + b'\x00' * (34 - len(data))
        offset += 0x34
    offset = 0x4AF8
    inputdata = []
    with open('fld2.tsv', 'r', encoding='utf-8') as f:
        for line in f:
            inputdata.append(line.rstrip('\r\n').split('\t')[1].encode('ascii'))
    for data in inputdata:
        filedata[offset:offset+22] = data + b'\x00' * (22 - len(data))
        offset += 23
    offset = 0x4C36
    inputdata = []
    with open('fld3.tsv', 'r', encoding='utf-8') as f:
        for line in f:
            inputdata.append(line.rstrip('\r\n').split('\t')[1].encode('ascii'))
    for data in inputdata:
        filedata[offset:offset+32] = data + b'\x00' * (32 - len(data))
        offset += 0x2A
    with open('fld_resident.bin', 'wb') as f:
        f.write(filedata)
