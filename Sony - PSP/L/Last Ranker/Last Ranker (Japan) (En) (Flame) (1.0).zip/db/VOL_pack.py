import binascii
import functools
import os
import shutil
import struct
import sys

HEADER_SIZE = 0x420

def unpack(filename = 'SYSTEM.VOL'):
    filelist = []
    pos = 0x20
    with open(filename, 'rb') as f:
        while pos < 0x408:
            f.seek(pos)
            name = bytearray()
            for byte in iter(functools.partial(f.read, 1), b'\x00'):
                name.append(ord(byte))
            name = name.decode('ascii')
            filelist.append(name)
            f.seek(pos + 0x20)
            size, offset = struct.unpack('<II', f.read(8))
            offset += HEADER_SIZE
            f.seek(offset)
            data = bytearray()
            for byte in range(size):
                data.append(ord(f.read(1)) ^ 0x55)      #Data is XOR'd w/ 0x55
            with open(name, 'wb') as g:
                g.write(data)
            pos += 0x28
    with open('SYSTEM_filelist.txt', 'w') as f:
        f.write('\n'.join(filelist))
def pack(delete=False):
    with open('SYSTEM.VOL', 'wb') as f:
        f.write(b'RTDP')                                #0x0
        f.write(struct.pack('<I', HEADER_SIZE))         #0x4
        with open('SYSTEM_filelist.txt', 'r') as g:
            filelist = g.read().split('\n')
        f.write(struct.pack('<I', len(filelist)))       #0x8 number of files
        offset = 0
        for i, filename in enumerate(filelist):
            filesize = os.path.getsize(filename)
            filelist[i] = [filename, filesize, offset]
            offset += filesize
            while offset % 0x20 != 0:
                offset += 1
        f.write(struct.pack('<I', offset + HEADER_SIZE))    #0xC archive size
        #Magic
        f.write(binascii.unhexlify('55282500000000000000000000000000'))
        for filename, filesize, offset in filelist:
            filename = filename.encode('ascii')
            f.write(filename + b'\x00' * (0x20 - len(filename)))
            f.write(struct.pack('<II', filesize, offset))
        f.write(b'\x00' * (HEADER_SIZE - f.tell()))
        for filename, filesize, offset in filelist:
            with open(filename, 'rb') as g:
                for byte in range(filesize):
                    f.write(struct.pack('<B', ord(g.read(1)) ^ 0x55))
                while f.tell() % 0x20 != 0:
                    f.write(b'\x00')
    if delete:
        for filename, filesize, offset in filelist:
            os.remove(filename)
def build():
    #Checking for input files
    files = (
        'btlsys00.tsv', 'btlsys01.tsv', 'btlsys02.tsv', 'db00.tsv',
        'db01.tsv', 'db02.tsv', 'db03.tsv', 'db04.tsv', 'db05.tsv',
        'db06.tsv', 'db07.tsv', 'db09.tsv', 'db10.tsv', 'db11.tsv',
        'db12.tsv', 'db13.tsv', 'db14.tsv', 'db16.tsv', 'db17.tsv',
        'db18.tsv', 'db19.tsv', 'db20.tsv', 'fld1.tsv', 'fld2.tsv',
        'fld3.tsv')
    missing = []
    for filename in files:
        if os.path.isfile(filename) == False:
            missing.append(filename)
    if len(missing) > 0:
        print('Missing files: {}'.format(', '.join(missing)))
        quit()
    print('Building SYSTEM.VOL...', end='')
    import btlsys
    import db_resident
    import fld_resident
    import menu_resident
    filename = 'SYSTEM.VOL'
    if os.path.isfile(filename + '.orig'):
        pass
    elif os.path.isfile(filename):
        shutil.copy(filename, filename + '.orig')
    else:
        print('File {} not found.'.format(filename))
        quit()
    unpack(filename + '.orig')
    btlsys.pack()
    db_resident.pack()
    fld_resident.pack()
    menu_resident.pack()
    pack(delete=True)
    for file in os.listdir('.'):
        if '.orig' in file and file != filename + '.orig':
            os.remove(file)
    print('Done.')
    
if len(sys.argv) == 2:
    if sys.argv[1].lower() == 'unpack':
        print('Unpacking SYSTEM.VOL...', end='')
        unpack()
        print('Done.')
    elif sys.argv[1].lower() == 'pack':
        print('Packing SYSTEM.VOL...', end='')
        pack()
        print('Done.')
    elif sys.argv[1].lower() == 'build':
        build()
