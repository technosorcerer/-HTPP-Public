import binascii
import os
import shutil
import struct
import functools

filename = 'menu_resident.npk'
def unpack():
    with open(filename, 'rb') as f:
        f.seek(0x50)
        read_size = struct.unpack('<I', f.read(4))[0]
        s = f.read(read_size)
    s = s.split(b'\x00')[:-1]
    with open(filename + '.txt', 'wb') as f:
        f.write(b'\n'.join(s))

def pack():
    if os.path.isfile(filename + '.orig'):
        pass
    elif os.path.isfile(filename):
        shutil.copy(filename, filename + '.orig')
    else:
        print('File {} not found.'.format(filename))
        return
    with open(filename + '.orig', 'rb') as f:
        filedata = bytearray(f.read())
    with open('menu_resident.txt', 'r', encoding='utf-8') as f:
        s = f.read().split('\n')
    s = b'\x00'.join([x.encode('utf-8') for x in s]) + b'\x00'
##    filedata[0x5:0x8] = struct.pack('<I', len(s) + 0x54)[:3]
    filedata[0x50:0x54] = struct.pack('<I', len(s))
    filedata[0x54:0x54+0x113] = b'\x00' * 0x113
    filedata[0x54:0x54+len(s)] = s
    with open(filename, 'wb') as f:
        f.write(filedata)
