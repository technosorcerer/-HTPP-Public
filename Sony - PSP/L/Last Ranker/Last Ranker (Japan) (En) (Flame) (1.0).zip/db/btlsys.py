import binascii
import pdb
import os
import shutil
import struct
import sys

offset_list = [0xB970, 0x1C480, 0x23C40]
filename = 'btlsys.cnk'

def unpack():
    with open(filename + '.orig', 'rb') as f:
        filedata = f.read()
    for i, offset in enumerate(offset_list):
        size = struct.unpack('<I', filedata[offset:offset+4])[0]
        offset += 4
        data = filedata[offset:offset+size]
        data = data.split(b'\x00')[:-1]
        output = []
        for j, data1 in enumerate([x.decode('utf-8') for x in data]):
            output.append(str(j) + '\t')
            output.append(data1.replace('\n', '\n\t') + '\n')
        with open('btlsys{:0>2}.txt'.format(i), 'w', encoding='utf-8') as f:
            f.write(''.join(output))
def pack():
    if os.path.isfile(filename + '.orig'):
        pass
    elif os.path.isfile(filename):
        shutil.copy(filename, filename + '.orig')
    else:
        print('File {} not found.'.format(filename))
        return
            
    with open(filename + '.orig', 'rb') as f:
        filedata = bytearray(f.read())
    for i, offset in enumerate(offset_list):
        inputdata = []
        with open('btlsys{:0>2}.tsv'.format(i), 'r', encoding='utf-8') as f:
            for line in f:
                line = line.rstrip('\r\n').split('\t')
                if line[0] != '':
                    inputdata.append(line[2].encode('utf-8'))
                else:
                    inputdata[-1] += b'\n' + line[2].encode('utf-8')
        inputdata = b'\x00'.join(inputdata) + b'\x00'
        size = struct.unpack('<I', filedata[offset:offset+4])[0]
        filedata[offset:offset+4] = struct.pack('<I', len(inputdata))
        offset += 4
        filedata[offset:offset+size] = b'\x00' * size
        filedata[offset:offset+len(inputdata)] = inputdata
    with open(filename, 'wb') as f:
        f.write(filedata)
