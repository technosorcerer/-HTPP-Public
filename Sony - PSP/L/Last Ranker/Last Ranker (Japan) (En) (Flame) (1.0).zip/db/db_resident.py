import binascii
import pdb
import os
import shutil
import struct

offset_list = [0x7530, 0x7a40, 0x8110, 0x8860, 0x96f0, 0x9d90, 0xa4d0,
               0xbf60, 0xdcb0, 0xdd80, 0xf3c0, 0x11f70, 0x13310,
               0x13f60, 0x17080, 0x1a0e0, 0x1a1b0, 0x1ade0, 0x1bc30,
               0x1c2c0, 0x1c720]
filename = 'DB_resident.npk'
print(hex(offset_list[14]))

BASE_POS = 0xDD60

def text_decode(s):
    while '{' in s:
        s1 = s[:s.find('{')]
        s2 = s[s.find('{') + 1:s.find('}')]
        s3 = s[s.find('}') + 1:]
        s = s1 + binascii.unhexlify(s2).decode('ascii') + s3
    return s

def unpack():
    with open(filename + '.orig', 'rb') as f:
        filedata = f.read()
    for i, offset in enumerate(offset_list):
        size = struct.unpack('<I', filedata[offset:offset+4])[0]
        offset += 4
        data = filedata[offset:offset+size]
        data = data.split(b'\x00')[:-1]
        output = []
        for j, data1 in enumerate([x.decode('utf-8') for x in data]):
            output.append(str(j) + '\t')
            output.append(data1.replace('\n', '\n\t') + '\n')
        with open('db{:0>2}.txt'.format(i), 'w', encoding='utf-8') as f:
            f.write(''.join(output))
def pack():
    if os.path.isfile(filename + '.orig'):
        pass
    elif os.path.isfile(filename):
        shutil.copy(filename, filename + '.orig')
    else:
        print('File {} not found.'.format(filename))
        return
    with open(filename + '.orig', 'rb') as f:
        filedata = bytearray(f.read())
    for i, offset in enumerate(offset_list):
        if i in (8, 15, 16, 17, 20):
            continue
        inputdata = []
        with open('db{:0>2}.tsv'.format(i), 'r', encoding='utf-8') as f:
            for line in f:
                line = line.rstrip('\r\n').split('\t')
                if line[0] != '':
                    inputdata.append(line[2].encode('utf-8'))
                else:
                    inputdata[-1] += b'\n' + line[2].encode('utf-8')
        inputdata = b'\x00'.join(inputdata) + b'\x00'
        size = struct.unpack('<I', filedata[offset:offset+4])[0]
        filedata[offset:offset+4] = struct.pack('<I', len(inputdata))
        offset += 4
        filedata[offset:offset+size] = b'\x00' * size
        filedata[offset:offset+len(inputdata)] = inputdata
    with open(filename, 'wb') as f:
        f.write(filedata)
