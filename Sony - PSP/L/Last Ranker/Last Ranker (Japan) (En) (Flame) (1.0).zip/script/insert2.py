import binascii, struct, io, os, gzip, pdb, itertools, textwrap, shutil

filelist = [ \
'MAP_D_CAD_00', 'MAP_D_CAD_01', 'MAP_D_CAD_02', 'MAP_D_CAD_03', 'MAP_D_CAD_04',
'MAP_D_CAN_00', 'MAP_D_CAN_01', 'MAP_D_CAN_02', 'MAP_D_CAN_03', 'MAP_D_CAN_04',
'MAP_D_DNE_00', 'MAP_D_DNE_01', 'MAP_D_DNE_02', 'MAP_D_DNE_03', 'MAP_D_DNE_04',
'MAP_D_DNE_05', 'MAP_D_DOU_00', 'MAP_D_DOU_01', 'MAP_D_DOU_02', 'MAP_D_DOU_03',
'MAP_D_HEI_00', 'MAP_D_HEI_01', 'MAP_D_HEI_02', 'MAP_D_HEI_03', 'MAP_D_KFO_00',
'MAP_D_KFO_01', 'MAP_D_KFO_02', 'MAP_D_KFO_03', 'MAP_D_KFO_04', 'MAP_D_KHI_00',
'MAP_D_KHI_01', 'MAP_D_KHI_02', 'MAP_D_KHI_03', 'MAP_D_KHI_04', 'MAP_D_KOU_00',
'MAP_D_KOU_01', 'MAP_D_KOU_02', 'MAP_D_KOU_03', 'MAP_D_KOU_04', 'MAP_D_LUK_00',
'MAP_D_LUK_01', 'MAP_D_LUK_02', 'MAP_D_LUK_03', 'MAP_D_LUK_04', 'MAP_D_LUK_05',
'MAP_D_LUK_06', 'MAP_D_LUK_07', 'MAP_D_LUK_08', 'MAP_D_MAI_00', 'MAP_D_MAI_01',
'MAP_D_MAI_02', 'MAP_D_MAI_03', 'MAP_D_MAI_04', 'MAP_D_NIS_00', 'MAP_D_NIS_01',
'MAP_D_NIS_02', 'MAP_D_NIS_03', 'MAP_D_NIS_04', 'MAP_D_OBT_00', 'MAP_D_OBT_01',
'MAP_D_OBT_02', 'MAP_D_OBT_03', 'MAP_D_OBT_04', 'MAP_D_REZ_00', 'MAP_D_REZ_01',
'MAP_D_REZ_02', 'MAP_D_REZ_03', 'MAP_D_REZ_04', 'MAP_D_RIV_00', 'MAP_D_RIV_01',
'MAP_D_RIV_02', 'MAP_D_RIV_03', 'MAP_D_RIV_04', 'MAP_D_SAB_00', 'MAP_D_SAB_01',
'MAP_D_SAB_02', 'MAP_D_SAB_03', 'MAP_D_SAL_00', 'MAP_D_SAL_01', 'MAP_D_SAL_02',
'MAP_D_SAL_03', 'MAP_D_SAL_04', 'MAP_D_SIN_00', 'MAP_D_SIN_01', 'MAP_D_SIN_02',
'MAP_D_SIN_03', 'MAP_D_SOD_00', 'MAP_D_SOD_01', 'MAP_D_SOD_02', 'MAP_D_SOD_03',
'MAP_D_SOD_04', 'MAP_D_ZEK_00', 'MAP_I_ANT_00', 'MAP_I_BAS_00', 'MAP_I_BAS_01',
'MAP_I_BAS_02', 'MAP_I_BAS_03', 'MAP_I_BAS_04', 'MAP_I_BAS_05', 'MAP_I_BAS_06',
'MAP_I_BAS_07', 'MAP_I_BAS_08', 'MAP_I_BAS_09', 'MAP_I_BAS_10', 'MAP_I_BAS_13',
'MAP_I_GAN_00', 'MAP_I_GAN_01', 'MAP_I_GAN_02', 'MAP_I_GAN_03', 'MAP_I_GAN_04',
'MAP_I_GAN_05', 'MAP_I_GAN_06', 'MAP_I_GAN_08', 'MAP_I_GAN_09', 'MAP_I_GAN_10',
'MAP_I_GAN_11', 'MAP_I_GAN_12', 'MAP_I_GAN_13', 'MAP_I_GAN_14', 'MAP_I_GAN_15',
'MAP_I_GAN_16', 'MAP_I_GAN_17', 'MAP_I_GAN_18', 'MAP_I_GAN_19', 'MAP_I_GAN_20',
'MAP_I_GAN_21', 'MAP_I_GAN_22', 'MAP_I_GAN_23', 'MAP_I_GAN_24', 'MAP_I_GAN_25',
'MAP_I_GAN_26', 'MAP_I_GAN_27', 'MAP_I_GAN_28', 'MAP_I_GAN_29', 'MAP_I_GAN_30',
'MAP_I_GAN_31', 'MAP_I_GAN_32', 'MAP_I_GAN_33', 'MAP_I_GAN_34', 'MAP_I_GAN_35',
'MAP_I_GAN_36', 'MAP_I_KAN_00', 'MAP_I_KAN_01', 'MAP_I_KAN_02', 'MAP_I_KAN_03',
'MAP_T_ANT_00', 'MAP_T_ANT_01', 'MAP_T_ANT_02', 'MAP_T_ANT_03', 'MAP_T_ANT_04',
'MAP_T_GAN_00', 'MAP_T_GAN_01', 'MAP_T_GAN_02', 'MAP_T_GAN_03', 'MAP_T_GAN_04',
'MAP_T_GAN_05', 'MAP_T_GAN_06', 'MAP_T_GAN_07', 'MAP_T_GAN_08', 'MAP_T_GAN_09',
'MAP_T_KAN_00', 'MAP_T_KAN_01']
#Uncomment to run just a single file
##filelist = ('MAP_I_GAN_09',)

def text_decode(s):
    while '{' in s:
##        print(s)
        s = s[:s.find('{')] + str(binascii.unhexlify(s[s.find('{')+1:s.find('}')]), 'ascii') + s[s.find('}')+1:]
    return s

def wrap_text(s1, l1):
    global wrapper
    if l1 == 1:
        return s1.encode('utf-8')
    wrapper.width = len(s1)
    while len(wrapper.wrap(s1)) <= l1:
        wrapper.width -= 1
        if wrapper.width == 0:
            break
    wrapper.width += 1
    return(wrapper.fill(s1).encode('utf-8'))

def build_line(lines):
    s1 = [[]]
    orig_lines = []
    for line, breaktype in lines:
        s1[-1].append(line)
        if breaktype != '':
            s1.append([])
    if textwrapping == False:
        for i, x in enumerate(s1):
            s1[i] = b'\x0a'.join([y.encode('utf-8') for y in x])
        return b'\x0c'.join(s1)
    #Automatic text wrapping
    orig_lines= [len(x) for x in s1]
    s1 = [' '.join(x) for x in s1]
    for i, s2 in enumerate(s1):
        s_len = len(s2)
        if s_len <= 28:
            l = 1
        elif s_len <= 56 or subtitle:
            l = 2
        else:
            l = 3
        if orig_lines[i] > l:
            l = orig_lines[i]
        s1[i] = wrap_text(s2, l)
    return b'\x0c'.join(s1)

def get_lines(filename, s_index):
##    print(filename, s_index)
    flag = False
    subtitle = False
    textwrapping = True
    lines = []
    with open(filename1[4:] + '.tsv', 'r', encoding='utf-8') as f:
        for line in f:
            
            line = line.rstrip('\r\n').split('\t')
            if line[0] != '':
                line[0] = int(line[0])
                if line[0] == s_index:
                    flag = True
##                    if line[0] == 77:
##                        pdb.set_trace()
            if flag:
                if line[0] not in ('', s_index):
                    break
                line[2] = text_decode(line[2])
##                if filename == 'MAP_D_KFO_01':
##                    pdb.set_trace()
                line += [''] * (5 - len(line))
                lines.append((line[2], line[3]))
                if line[4] == 'X':
                    subtitle = True
                if line[4] == 'Y':
                    textwrapping = False
        else:
            if not flag:
                print(filename, s_index, 'not found')
                return subtitle, textwrapping, []
    if lines[0][0] == '':
##            print('{} {} ref blank'.format(filename1, s_index))
        return subtitle, textwrapping, []
    return subtitle, textwrapping, lines

def build_offset_list(s):
    '''Find offset of each string within string table'''
    pos = 0
    str_offset_list = []        
    str_offset_list.append(0)
    for i, x in enumerate(range(string_num - 1), 1):
        pos = string.find(b'\x00', pos) + 1
        str_offset_list.append(pos)
    return(str_offset_list)

wrapper = textwrap.TextWrapper()
wrapper.break_long_words = False
##wrapper.drop_whitespace = False

for i, filename in enumerate(filelist):
    print(i, filename)
    #File handling
    if os.path.isfile(filename + '.orig'):
        pass
    else:
        if os.path.isfile(filename + '.BIN'):
            shutil.copy(filename + '.BIN', filename + '.orig')
        else:
            print('File {} not found.'.format(filename + '.BIN'))
            quit()
    #Read data
    with gzip.open(filename + '.orig') as f:
        filedata = f.read()
    #Get bscr
    bscr_offset = struct.unpack('<I', filedata[0xC:0x10])[0]
    bscrsize = struct.unpack('<I', filedata[bscr_offset+0x24:bscr_offset+0x28])[0]
    filedata = bytearray(filedata[bscr_offset:bscr_offset+bscrsize])     
    #------------------
    #Read bscr
    string_num, string_start, script_size, script_start = \
                struct.unpack('<IIII', filedata[0x30:0x40])
    string = filedata[string_start:script_start]
    script = filedata[script_start:script_start+script_size]
    #Get string offsets
    str_offset_list = build_offset_list(string)
    #Get script offsets
    pos = script_start
    count = 0
    scp_offset_list = []
    for x in range(script_size // 0x10):
        if filedata[pos:pos+4] == b'\x1a\xf0\xf1\x5a':
            count += 1
            str_offset = struct.unpack('<I', filedata[pos+4:pos+8])[0]
            #Where is the pointer, which string # is the pointer
            scp_offset_list.append([pos + 4, str_offset_list.index(str_offset)])
        pos += 0x10
    #Build new strings
    s = string.split(b'\x00')[:string_num]
    inputdata = []
        #Read data
    with open(filename[4:] + '.tsv', 'r', encoding='utf-8') as f:
        for line in f:
            line = line.rstrip('\r\n').split('\t')
            if line[0] != '':                       #Start of new string
                inputdata.append([int(line[0]), False, True, []])
                if len(line) > 4:                   #Check for subtitle-type string
                    if line[4] == 'X':              #Is a subtitle
                        inputdata[-1][1] = True
                    if line[4] == 'Y':              #No text wrapping
                        inputdata[-1][2] = False
            line[2] = text_decode(line[2])          #Process {} codes
            if len(line) == 3:
                inputdata[-1][-1].append((line[2], ''))
            else:
                inputdata[-1][-1].append((line[2], line[3])) #Append data (text and linebreak)
    for i, subtitle, textwrapping, lines in inputdata:
##        print(i)
        if lines[0][0] == '':                       #First line blank
##            print('{} blank'.format(i))
            continue                                #Skip
        if lines[0][0][:4] == 'MAP_':               #Reference
            filename1, s_index = lines[0][0].split(' ')
            s_index = int(s_index)
            subtitle, textwrapping, lines = get_lines(filename1, s_index)
            if not lines:                           #Reference was blank
                continue                            #Skip
##        print(i)
##        if i == 77:
##            pdb.set_trace()
        #s = string table
        s[i] = build_line(lines)
    #Insert strings
    string = b'\x00'.join(s) + b'\x00'
    if len(string) > script_start - string_start:
        print('Too long.')
        quit()
    str_offset_list = build_offset_list(string)
    #Replace string data with new
    string += b'\x00' * (script_start - string_start - len(string))
    filedata[string_start:script_start] = string
    #Update pointers
    for scp_offset, i in scp_offset_list:
        filedata[scp_offset:
                 scp_offset+4] = struct.pack('<I', str_offset_list[i])
##    with open('bscr.bin', 'wb') as f:
##        f.write(filedata)
    data_temp = io.BytesIO()
    with gzip.open(filename + '.orig', 'rb') as g:
        data_temp.write(g.read(bscr_offset))
        data_temp.write(filedata)
        g.seek(bscr_offset + bscrsize)
        data_temp.write(g.read())
    with open(filename + '.BIN', 'wb') as f:
        f.write(gzip.compress(data_temp.getvalue()))
