import binascii, struct, os, gzip, itertools

def text_encode(s):
    '''Encode non-printing characters to printing characters'''
    s1 = ''
    for char in s:
        if ord(char) < 0x20 and ord(char) != 0xA:
            s1 += '{' + '{:0>2x}'.format(ord(char)) + '}'
        else:
            s1 += char
    #Google sheets truncates leading spaces
    #This converts leading spaces to non-space characters
    #You can then run replace all command to get the spaces back once in
    #Google Sheets
    s2 = ''
    for i, char in enumerate(s1):
        if char not in (' ', '　'):
            s2 += s1[i:]
            break
        if char == ' ':
            s2 += '{20}'
        if char == '　':
            print('hit')
            s2 += '{81}'
    return s2

def dump(filename):
    global slist, slist_dbase
    size = os.path.getsize(filename)
    #Files are compressed using gzip
    with open(filename, 'rb') as f:
        filedata = gzip.decompress(f.read())
    #Offset to bscr
    offset = struct.unpack('<I', filedata[0xC:0x10])[0]
    #Within bscr section... -> length of bscr section
    size = struct.unpack('<I', filedata[offset+0x24:offset+0x28])[0]
    #Truncating filedata to bscr section only
    filedata = filedata[offset:offset+size]
    string_num = struct.unpack('<I', filedata[0x30:0x34])[0]
    start = struct.unpack('<I', filedata[0x34:0x38])[0]
    end = struct.unpack('<I', filedata[0x3C:0x40])[0]
    s = filedata[start:end].split(b'\x00')[:string_num]
    with open(os.path.splitext(filename)[0] + '.tsv',
              'w', encoding='utf-8') as f:
        for i, s1 in enumerate(s):
            s1 = s1.decode('utf-8')
            #Don't need to include this trash in dumps
            if (s1[:4] == 'func' and 'EVENT' not in s1) or s1 in ('', '\n', ' '):
                continue
            #slist = List of all strings already dumped (huge memory usage)
            #slist_dbase = file number and string number for strings in slist
            if s1 in slist:
                #Duplicate found
                index = slist.index(s1)
                duplicate = '{} {}'.format(
                    slist_dbase[index][0], slist_dbase[index][1])
            else:
                #String is unique
                slist.append(s1)
                slist_dbase.append((os.path.splitext(filename)[0], i, s1))
                duplicate = ''
            
            lines = []
            breaks = []
            #Split into lines
            #0x0A is linebreak, 0x0C is pagebreak
            while '\x0c' in s1 or '\n' in s1:
                for j, char in enumerate(s1):
                    if char == '\x0c' or char == '\n':
                        break
                lines.append(s1[:j])
                if char == '\x0c':
                    breaks.append('X')
                else:
                    breaks.append('')
                s1 = s1[j+1:]
            lines.append(s1)
            #Output
            first = True
            for line, break_char in itertools.zip_longest(lines, breaks, fillvalue = ''):
                if first == True:
                    first = False
                    f.write('\t'.join((str(i), text_encode(line), duplicate, break_char)) + '\n')
                else:
                    f.write('\t'.join(('', text_encode(line), '', break_char)) + '\n')
slist_dbase = []
slist = []
filelist = [x for x in os.listdir('.') if x.endswith('.BIN')]
for f in filelist:
    dump(f)
##filelist = ('MAP_T_KAN_00.BIN', 'MAP_T_KAN_01.BIN')
##for f in filelist:
##    dump(f)
