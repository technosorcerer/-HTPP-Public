Shit's pretty easy.
Step 1. Get Clean ISO of Danball Senki BOOST
Step 2. Use UMDGen to extract the Install.CPK
Step 3. Use XDelta to patch the Install.CPK
Step 4. Use UMDGen to reinsert the Install.CPK over the old one (Drag n drop)
Step 5. Save as a NEW ISO. Do not overwrite your original.
Step 6. Enjoy patched Danball Senki BOOST

Patch by CrashmanX
Contact me at CrashmanNoir@gmail.com if you've got more questions
Or find the topic on GBATemp