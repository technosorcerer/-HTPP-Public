Itadaki Street Portable - Prerelease 2: The "Preview" Release

Use a program like PPF-O-Matic to apply this patch to an ISO you extract through your copy of the game "Dragon Quest and Final Fantasy in Itadaki Street Portable".

Patch created by MortoQueiba.
You can contact him via youtube.com/mortoqueiba.

Dragon Quest, Final Fantasy, and all related items are copyright of Square-Enix. No copyright infringement is intended. This patch is free for anyone to use. I (MortoQueiba) make no profit off of the files contained in this package or the videos used to demonstrate the changes made to the game.