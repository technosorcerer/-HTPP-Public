Aaaan another one goes...

Full english translation patch for:
	Shinseiki Evangelion - Koutetsu no Girlfriend -Portable-

Staff:

	Graphics:	Mugi
	Hacking: 	Mugi, xyz
	Translation:	Mugi


how to use:
-----------
- get your copy of girlfriend of steel portable iso (CRC32: 4488CCC5)
- name the iso to ULJM-05456.iso
- put ULJM-05456.iso into the same folder with patchme.bat, xdelta.exe and gfos.eng.v1.01.xdelta
- run patchme.bat
- run check_result.sfv to verify that the patching was succesful. (patched iso CRC32 should be 09DD70D0)
- put gfos.eng.v1.01.iso on psp or load in emulator and play game.


changelog
-------------------
v1.01 - gfos.eng.v1.01.xdelta
	- minor text and visual fixes

v1.00 - gfos.eng.v1.00.xdelta
	- initial release
