-------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------

Shin Sangoku Musou Multi Raid 2 - English-Indonesian Menu Patch by Fried Noodle Translations

-------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------

1. Version Info
2. Creators
3. Contact Info
4. Patch Info
5. Installing Patch
5.a. English
5.b. Indonesian
6. Thanks

-------------------------------------------------------------------------------------------
1. Version Info
-------------------------------------------------------------------------------------------

Current:
--------
Version 0.2
Translated

100%
Materials (Names & Descriptions)
Chis (Names & Descriptions)
Weapons
Main Mission, Bonus Mission, Defeat & In-game Objectives
Character Names
Plot Cards (Names & Descriptions)
Abilities & Attributes

50% or less
FMVs
Community Point
Mission/Quest Names
Some In-game texts

Not Translated
Images
Story
Old Man manual
Some non-moving objects like wall, towers, statue etc because when i translated them they're not visible on screen

--------
Version 0.1

Translated
Victory, Defeat, Bonus 95% Translated
Materials, Weapons, description language is mixed (english, indonesian, japanese)
Most of FMV translations aren't accurate
NPC name 30% Translated

Not Translated:
Non-Moving objects (Statues, Pillars etc). The text doesn't appear when i translated them
Name of Quests, Descriptions, conversations.
Images


-------------------------------------------------------------------------------------------
2. Creators
-------------------------------------------------------------------------------------------

Fried Noodle Translations

-------------------------------------------------------------------------------------------
3. Contact Info
-------------------------------------------------------------------------------------------

For any mistranslations, errors, bugs, suggestions etc. can be posted to:

http://www.facebook.com/NoodleGaiden

-------------------------------------------------------------------------------------------
4. Patch Info
-------------------------------------------------------------------------------------------

This patch is for Shin Sangoku Musou Multi Raid 2 for PSP. At first, the goal of this
patch is to have most the menu stuff in Indonesian, but due to limited characters and me not
having any romhacking skill i decided to mix it with English. English speaker will understand
"quest hint" and basic menu, but item description currently in indonesian. Story won't be
translated unless there's someone fluent in japanese that want to help.

This patch is based on MrShyCity's translation patch v2.1

I hope you enjoy the patch. Expect incorrect grammar, mistranslations, and weird jokes here
and there because at first this translation is just for my personal use.

Some texts are abbreviated (like officer names) due to limited space, if you want to know the meaning please read
"Glossary.rtf"

-------------------------------------------------------------------------------------------
5. Installing Patch
-------------------------------------------------------------------------------------------

5.a. English:
To install the patch, just follow the steps I've written here.

What You Need:
-Shin Sangoku Musou Multi Raid 2 iso
-UMDGen or CDMage
-XDeltaUI or other rom patcher

1. 
---
Launch UMDGen, Click Open and Choose your copy of Shin Sangoku Musou Multi Raid 2 iso


2. 
---
Go to PSP_GAME > USRDIR and right click at "EBOOT.BIN" and click "Extract Selected" 


3. 
---
Launch XDeltaUI

Patch: Point it to "EBOOT.Xdelta"
Source file: Point it to "EBOOT.BIN" you've extracted from UMDGen
Output File: Choose destination for the patched file and Name it "EBOOT.BIN" 

4. 
---
Drag & drop patched "EBOOT.BIN" to UMDGen (PSP_GAME > SYSDIR) and click yes when prompted


5. 
---
Click Save > Uncompressed (*.iso) and name it whatever you want. Now your patched ISO is ready. 


6. 
---
If somehow your ISO is error after the patching process, try this:
After section 4, Right click the new "EBOOT.BIN", select "File Relinker" and click on "Use Selected File as Source"
Then right click the "BOOT.BIN" under the eboot, select "File Relinker" and click on "Relink To 'PSP_GAME\SYSDIR\EBOOT.BIN'" and then save.

7. 
---
If you have a game that has been patched with MrShyCity's patch (v2.1), use "reverter.xdelta" first and then
use "EBOOT.xdelta" to the "EBOOT.BIN" that has been reverted.

5.b. Indonesian:

Untuk menginstall patch, ikuti langkah-langkah berikut:

Yang diperlukan:
-Shin Sangoku Musou Multi Raid 2 iso
-UMDGen atau CDMage
-XDeltaUI atau rom patcher lainnya

1.
---
Jalankan UMDGen, klik open dan pilih Shin Sangoku Musou Multi Raid 2 iso

2. 
---
Pergi ke PSP_GAME > USRDIR dan klik kanan "EBOOT.BIN" lalu klik "Extract Selected" 

3. 
---
Jalankan XDeltaUI

Patch: Pilih "EBOOT.Xdelta"
Source file: Pilih "EBOOT.BIN" yang baru saja diekstrak menggunakan UMDGen
Output File: pilih tempat menyimpan hasil patchnya dan beri nama "EBOOT.BIN" 

4. 
---
Drag & drop file "EBOOT.BIN" hasil patch tadi ke UMDGen (PSP_GAME > SYSDIR) dan klik yes ketika diminta konfirmasi


5. 
---
klik Save > Uncompressed (*.iso) dan beri nama sesuai keinginan. ISO sudah siap dimainkan 


6. 
---
Jika ISO error setelah proses di atas, coba ini:
setelah tahap 4, klik kanan "EBOOT.BIN" yang baru, pilih "File Relinker" dan klik "Use Selected File as Source"
lalu klik kanan "BOOT.BIN" yang ada dibawah eboot, pilih "File Relinker" dan klik "Relink To 'PSP_GAME\SYSDIR\EBOOT.BIN'" lalu save.

7. 
---
Jika game kepunyaanmu sudah di patch dengan english patch dari MrShyCity (v2.1), patch dulu "EBOOT.BIN" nya dengan
"reverter.xdelta" lalu gunakan "EBOOT.xdelta" ke "EBOOT.BIN" yang sudah di-revert tersebut 
--------------------------------------------------------------------------------------------
6. Thanks
--------------------------------------------------------------------------------------------

MrShyCity	-Original English Patch
Yusuf Fauzan	-Providing original EBOOT.BIN
https://www.facebook.com/yuuzann

