Another one bites the dust...

Full english translation patch for:
	Shinseiki Evangelion - Koutetsu no Girlfriend 2nd -Portable-

Staff:

	Graphics:	Mugi
	Hacking: 	Binaryfail, Mugi
	Translation:	jjjewel


how to use:
-----------
- get your copy of girlfriend of steel 2nd portable iso (CRC32: D4AA9284)
- name the iso to ULJM-05477.iso
- put ULJM-05477.iso into the same folder with patchme.bat, xdelta.exe and gfos.II.eng.v1.02.xdelta
- run patchme.bat
- run check_result.sfv to verify that the patching was succesful. (patched iso CRC32 should be C7944E4E)
- put gfos.II.eng.v1.02.iso on psp or load in emulator and play game.


changelog
-------------------
v1.02 - gfos.II.eng.v1.02.xdelta
	- all graphics uncensored.
 	  further cosmetic fixes for text.
	  blacklabel logo removed as the group no longer exists.

v1.01 - blt-gfos.II.eng.v1.01.xdelta
	- updated script to fix spelling errors and awkward spelling mistakes.
 	  fixed an issue of one multiselection-textbox being too small for it's text.

v1.00 - blt-gfos_II_eng.xdelta
	- initial release