Another one bites the dust...

Blacklabel-translations brings you a full translation of:
	Shinseiki Evangelion - Koutetsu no Girlfriend 2nd -Portable-

Staff:

	Graphics: Mugi
	Hacking: Binaryfail, Mugi
	Translation: jjjewel


how to use:
-----------
- this patch is to be applied to the unmodified japanese iso of the game, do not attempt to
  patch this patch over the initial 1.00 release of the translation.

- get your copy of girlfriend of steel 2nd portable iso (CRC32: D4AA9284)
- name the iso to ULJM-05477.iso
- put ULJM-05477.iso into the same folder with patchme.bat, xdelta.exe and blt-gfos.II.eng.v1.01.xdelta
- run patchme.bat
- run checkresult.sfv to verify that the patching was succesful. (patched iso CRC32 should be C15864D7)
- put blt-gfos.II.eng.v1.01.iso on psp or load in emulator and play game.


changelog
-------------------
v1.01 - blt-gfos.II.eng.v1.01.xdelta
	- updated script to fix spelling errors and awkward spelling mistakes.
	  fixed an issue of one multiselection-textbox being too small for it's text.

v1.00 - blt-gfos_II_eng.xdelta
	- initial release