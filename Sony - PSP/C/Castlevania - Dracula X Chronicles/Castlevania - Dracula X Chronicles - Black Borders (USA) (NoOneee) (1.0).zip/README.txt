Dracula X Chronicles Black Borders Patch V1.0

This patches the first border from the original games included in Dracula X 
Chronicles to black.

This works on all three games:
Rondo of Blood
Symphony of the Night
Akumajo Dracula Peke

HOW TO APPLY:

You can use UMDGEN 4.0 to easily apply the PPF patches.
To do so, press the right mouse button on each file and select "Apply PPF Patch"

Apply the make_16wp_black.ppf patch to the following files:
PSP_GAME\USRDIR\res\ps\WALLPAPER\16\wp01.tm2
PSP_GAME\USRDIR\res\pce\WALLPAPER\16\wp01.tm2
PSP_GAME\USRDIR\res\peke\WALLPAPER\16\wp01.tm2

Apply the make_32wp_black.ppf patch to the following files:
PSP_GAME\USRDIR\res\ps\WALLPAPER\32\wp01.tm2
PSP_GAME\USRDIR\res\pce\WALLPAPER\32\wp01.tm2
PSP_GAME\USRDIR\res\peke\WALLPAPER\32\wp01.tm2

Save the ISO.
Select the wallpaper type 1 in the game option to use the black background.
You can try to patch one of the other backgrounds if you want. 
This should work, but I haven't tested.

DISCLAIMER
	In no event I can be responsable for any damage caused by the patches.
	You should not use the patches if you don't own the original game.
	YOU CAN NOT INCLUDE THIS IN ANY FORM WITH PIRATED COPIES OF THE GAME
	YOU CAN NOT DISTRIBUTE PRE-PATCHED VERSIONS OF THE GAME