			  Parodius Portable - Music Restoration Patch
							by Masaru
						   Version 0.2
						   
						   
Parodius Portable is (to my thought), the definitive way to play the original parodius games with
the quality of life improvements that were added to this version, like the save/load option, the possibility of playing with the 2P characters
without needing a second controller in both Gokujou Parodius and Sexy Parodius, a complete remake/overhaul of the original Parodius game on MSX
or the "Free Play" option enabled from the start (Unlike being limited to credits in the Console releases). 

However, one of the biggest downside of this version is that this version replaces various tracks for either copyright issues
or for no real reason more than remixing the song (The first stage of Sexy Parodius). This by result causes a dissonance with
the rest of the soundtrack (Tracks made in the 90's vs Tracks made in 2007) or directly tracks that sound directly worse
(The first stage of Gokujou Parodius).

This patch tries to ammend that by reverting the songs back to their arcade/console counterpart, borrowed directly from
the official album releases of the game's soundtracks. However, various tracks had to be downsampled to fit within the
limited space of the bgm.bin files, that's the best I could do without resorting to modify the EBOOT.BIN or the BOOT.BIN.

List of tracks that got reverted to their Arcade/Console counterpart:

-Parodius da!
"Hungarian Dance No. 5" to "Ah! Traveling Japan" (Stage 4)

-Gokujou Parodius
"Turkey in the Straw" to "In the Crane Game" (Stage 1) (Downsampled to 48kb)
"The Parade of the Wooden Soldiers" to "Cooking Mambo" (Stage 3 Boss) (Downsampled to 48kb)

Jikkyou Oshaberi Parodius
"Brilliant2U" from DanceDanceRevolution2ndMix to "I Remember That! (Disco Mix) ~from "That's the Way!" (KC and The Sunshine Band)" (Stage 1) (Downsampled to 48kb)

-Sexy Parodius
"Pastoral March (Portable version)" to "Pastoral March (Arcade/Console version)" (Stage 1)  (Downsampled to 66kb)
"Korobushka" to "Lovely Otohime" (Stage 3A)

One track that couldn't be restored is the original version of the Warehouse track in Sexy Parodius, due that the sample being long
and it couldn't be fit properly in the at3bgm.bin, and inserting it breaks other tracks, maybe in the future might fix this.

The replaced tracks can still be heard on the music menu, this is because of the music menu having a bgm.bin on their own, the sole
reason that it is left intact is because modifying the menu to make the names and the songs appearing correctly is a little
complex.

Apply to a Redump-compliant Japanese ISO

Parodius Portable (Japan).iso
File/ROM SHA-1: 06AD24488C1F18C5CBA29B9004101CC6830358D7
File/ROM CRC32: 9C536BC0

-Credits
Hacking: Masaru

(If there's an issue regarding a bad loop, music stopping or a game crashing bug, let me know)
