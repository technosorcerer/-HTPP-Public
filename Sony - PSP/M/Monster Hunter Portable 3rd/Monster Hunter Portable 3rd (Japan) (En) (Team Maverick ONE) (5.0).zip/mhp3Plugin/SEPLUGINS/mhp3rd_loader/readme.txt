put the mhp3rd_data.bin along with the .prx file

copy the whole mhp3_loader to seplugins folder of your psp

add this to game.txt

for PSP FAT & SLIM
ms0:/seplugins/mhp3rd_loader/mhp3patch.prx 1

for PSP GO
ef0:/seplugins/mhp3rd_loader/mhp3patch.prx 1


This plugin is adapted from codestation(really thanks to him)
Tweaked and compile by kenma9123

This should work on latest cfw!