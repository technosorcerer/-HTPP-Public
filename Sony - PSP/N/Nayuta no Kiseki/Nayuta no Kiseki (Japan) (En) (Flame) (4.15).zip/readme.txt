
Nayuta Endless Trails Translation version 4.15

==============================================



translated by Flamethrower at https://heroesoflegend.org/forums/viewforum.php?f=22





Instructions

============



apply xdelta from the command line like so:
xdelta3 -d -s "Nayuta no Kiseki (Japan) (v1.01).iso" nayuta_v4.15.xdelta patched.iso
or use xdelta UI from

https://www.romhacking.net/utilities/598/





ROM / ISO Information

=====================



Nayuta no Kiseki (Japan) (v1.01).iso



before patching:

MD5: 02adefbdef8197cca872268d5c01b277



after patching:

MD5: 6cc975153b7998db4242baa17eb8d276