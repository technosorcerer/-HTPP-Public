Fate/Extra Perfect Patch

# Patch Notes #
This patch for the US version of Fate/Extra. It adds subtitles to all the
spoken battle lines, fixes lore translations to match the common Fate canon,
subtitles the opening video, and fixes various translation issues from the
original English release. It is compatible with PSP hardware, though the
low-res ruby font is recommended when running on a physical PSP.

The Playstation Network (PSN) edition of Fate/Extra has not been tested.
Please see the # ROM Info # section for details about the expected disc image.

# Instructions #
- Option 1: Graphical Installer -
1. Double-click "Patcher.exe"
2. Select any desired experimental features:
    2a. Nero's use of "Praetor" can be changed to "Maestro" by selecting the
        "Change Nero's Praetor to Maestro" checkbox.
    2b. In order to play on a physical PSP, it is recommended to select "Use
        low-res ruby font" in order to have a font optimized for low resolutions.
3. Click "Select Fate/Extra US ISO," then navigate to the unpatched iso.
4. When completed, the iso will appear next to "Patcher.exe" as "extra-patched.iso"
5. Enjoy!

- Option 2: Command-line Installer -
1. Inside the "data" folder, find the file called "Fallback - Drag and drop
   Fate Extra US ISO on me.bat"
2. As the file commands, drag and drop the unpatched iso onto the bat file.
3. A command prompt will open up. Select any desired experimental features:
    3a. Nero's use of "Praetor" can be changed to "Maestro" by typing 'Y'
        when prompted. Otherwise type 'N'.
    3b. In order to play on a physical PSP, it is recommended to select "Use
        low-res ruby font" in order to have a font optimized for low resolutions.
        Type 'Y' to use the low-res font, otherwise select 'N'.
4. When completed, the iso will appear in this folder as "extra-patched.iso"
5. Enjoy!

- Option 3: Unix/Mac -
1. Open up a terminal shell, navigate to the extracted Fate patch folder,
then enter the "data" folder.
2. Run "patch.sh" and pass your original copy of the Fate/Extra iso as an argument.
    2a. Example: "./patch.sh /home/user/games/PSP/fate-extra-original.iso"
3. Select any desired experimental features:
    3a. Nero's use of "Praetor" can be changed to "Maestro" by typing 'Y'
        when prompted. Otherwise type 'N' then hit enter.
    3b. In order to play on a physical PSP, it is recommended to select "Use
        low-res ruby font" in order to have a font optimized for low resolutions.
        Type 'Y' to use the low-res font, otherwise select 'N' then hit enter.
4. When completed, the iso will appear in this folder as "extra-patched.iso"
5. Enjoy!

# ROM Info #
Name: ULUS10576.ISO
Size: 1284079616 bytes (1224 MiB)
CRC32: 064591E2
SHA256: 16B1A6A50929C96CB5C9AE5FD504D2AE38A86B705F2075668FEB19665EBCC1A4
SHA1: 37FDAF91A80552DF995CE99A930B88F14F954F1F

# Credits #
SnowyAria - Battle translations
Kotcrab - Hacking
ItsumoKnight - Editing
IgorAkou - Image editing

# Contact #
Find any bugs or having any issues? Feel free to join Iwakura Production's
discord server here - https://discord.gg/n3nZBcZVJj