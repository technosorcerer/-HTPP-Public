Mystery Dungeon - Shiren The Wanderer 3 Portable
Version: 0.01
http://akatranslations.wikispaces.com/

This hack simply translates the Japanese PSP version: "Fushigi no Dungeon Fuurai no Shiren 3 Portable" to match the US Wii version: Shiren the Wanderer.

=Instructions=
----
This patch will only work on the untouched Japanese ISO, it should be 1.11GB with a CRC of: 4105C2B0

1. Extract the *.7z archive to a folder.
2. Place your untouched ISO in the same folder and name it "shiren3j.iso".
3. Double-click on "patchit.bat".
4. Wait patiently for the process to finish.
** (It will probably take more than 5 minutes to complete the process.)
5. After it's finished use UMDGen 4.00 to insert the new "F4_DATA.cpk" into "shiren3trans.iso".

=Version History=
----
v0.01
* First release. The game is now over 90% English.

=Not Translated=
----
* Some graphics are not translated. This includes the very first 'warning' screen when you run the game, and the 106 'banner' graphics that are displayed for a few seconds when entering a town or dungeon. They just aren't worth the time it would take to hack them.
* There's still a lot of text that needs to be properly translated. If you can help, feel free to edit the "Help NEEDED" pages: http://akatranslations.wikispaces.com/Help+NEEDED#Mystery%20Dungeon%20-%20Shiren%20The%20Wanderer%203%20Portable
* Any text that has to do with the "Rescue" feature or online features were just quickly translated using 'Google Translate'... They're terrible translations, but better than Japanese text I suppose.

=Known issues=
----
This hack has been tested up to Chapter 14. So far everything works great, except for a few things:

* The "Spell" items still have a Kanji counter. For some reason I couldn't find that single Kanji anywhere. It's not a big deal though.
* The Wii version had bigger text boxes, so some words run outside of the text box in this PSP version, but the majority of them are completely understandable.
* Sensei's head disappears for a short time in the bar scene. I'm not sure what causes it, but I'm guessing that the camera just zooms in too close.
* One line of text is unreadable when you get the scroll from the sick Blacksmith. (It's just: *Hack!* *wheeze!*).
* Several lines of the Elder's dialogue is unreadable in Chapter 7. You'll still understand what's going on despite missing a few lines.
* The Blank Scrolls must be written using Japanese. I haven't got one yet to test if English words will work or not.

Feel free to report any unknown bugs on the wiki's message board:
http://akatranslations.wikispaces.com/message/list/Mystery+Dungeon+-+Shiren+The+Wanderer+3+Portable
