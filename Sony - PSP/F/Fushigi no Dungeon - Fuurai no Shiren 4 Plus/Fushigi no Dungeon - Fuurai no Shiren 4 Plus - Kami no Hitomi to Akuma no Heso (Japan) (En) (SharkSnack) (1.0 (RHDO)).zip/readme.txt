----- Details -----

~~~ Notes ~~~
* Game update 3.10 is included in the patch - If you have update related data on your memory card, it might cause issues.
* Ad hoc and internet related areas of the game such as Twitter Link and Item Trade have not been tested.
* Rescue passwords are in Japanese to avoid breaking compatibility with existing rare item passwords.
* Item/Monster Book's Alpha (JP) searches the item names by the original Japanese name - It's too much work to change this.
* Someone reported random crashing on PS Vita, but they seem to have solved it by reformatting their memory card.

~~~ Version 1.0.1 ~~~
* Fixed an error related to lost equipment on roof event in Gonchiki Village.
* Fixed longer player names running outside of window when sending/receiving a rescue quest from another player.
* Fixed blanked out Yes/No options to exit Twitter Link menu.

----- About -----

Shiren 4 Plus: The Eye of God and the Devil's Navel, now in English!

Four and a half years in the making, SharkSnack, Arc Impulse, and Kotcrab along with others who contributed to the project are proud to present the English translation of Shiren 4 Plus: The Eye of God and the Devil's Navel for the PSP.

Follow Shiren and his talking ferret companion Koppa as they wash ashore on a southern island and work to unravel the secrets of the island. But be careful! One wrong move and you could be sent back to the beginning with nothing more than your companion Koppa.

Shiren 4 is the 7th game in the Shiren the Wanderer Mystery Dungeon series, whose franchise includes popular series such as Pokémon Mystery Dungeon, Chocobo's Mystery Dungeon, and Torneko's Great Adventure. Like a simpler version of Dark Souls, you will collapse and lose items from time to time, but you will also level up as a player and continue to progress. Clearing the main story is only the beginning, as that's when the island truly opens up with 14 additional post-game dungeons!

If you get stuck at any point in the game, check out SharkSnack's wiki for Shiren 4: https://sharksnack.github.io/shiren-4/

Shiren the Wanderer Discord: https://discord.gg/5y7UDFc

----- Other -----

If you enjoy the game, please consider supporting the official releases!

The latest games are:

1. "Shiren the Wanderer: The Mystery Dungeon of Serpentcoil Island"
    - Releasing in English for Nintendo Switch on February 27th, 2024.
    - Official Site: https://www.spike-chunsoft.co.jp/shiren6/en/

2. "Shiren the Wanderer: The Tower of Fortune and the Dice of Fate"
    - Released for Nintendo Switch and PC (Steam) back in 2020.

----- Credits -----

SharkSnack - Translation - Full Game Translation
Arc Impulse - Hacking - Full Game Hacking
Kotcrab - Hacking - Hardware Fixes, Staff Credits, Patch Script
DhrGR - Hacking - Initial Text Extraction/Insertion
akawshi - Translation - Staff Credits
Ozidual - Translation - Editing
Keii - Other - Instructions Manual Cleanup
