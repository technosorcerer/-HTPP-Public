بسم الله والحمد لله،،
                 ________   _   __     _    _______    _
                |  ______| |_| |  \   | |  / _____ \  | |
                | |         _  | \ \  | | | |     | | | |
                | |______  | | | |\ \ | | | |_____| | | |
                |  ______| | | | | \ \| | |  _____  | | |
                | |        | | | |  \ | | | |     | | | |
                | |        | | | |   \  | | |     | | | |_______
                |_|        |_| |_|    \_| |_|     |_| |_________|
 ________    _______    __     _   _________    _______     _______   __       __
|  ______|  / _____ \  |  \   | | |___   ___|  / _____ \   / _____ \  \ \     / /
| |        | |     | | | \ \  | |     | |     | |     | | / /     \_|  \ \   / /
| |______  | |_____| | | |\ \ | |     | |     | |_____| | \ \______     \ \ / /
|  ______| |  _____  | | | \ \| |     | |     |  _____  |  \ _____ \     \ ' /
| |        | |     | | | |  \ | |     | |     | |     | |  _      \ \     | |
| |        | |     | | | |   \  |     | |     | |     | | | \_____/ /     | |
|_|        |_|     |_| |_|    \_|     |_|     |_|     |_|  \_______/      |_|

                 * * * * * * * * * * * * * * * * * * * * * * * *
                 *  FINAL FANTASY TACTICS: WotL Arabic Project *
                 *              Version Beta 0.99a             *
                 * * * * * * * * * * * * * * * * * * * * * * * *
				 
								 Project by:
                           #                          
                          # #   ##### #    # #####  # 
                         #   #    #   #    # #    # # 
                        #     #   #   ###### #####  # 
                        #######   #   #    # #    # # 
                        #     #   #   #    # #    # # 
                        #     #   #   #    # #####  # 
        
           ###    ##        ######  ##     ## ##       ##    ## ##     ## 
          ## ##   ##       ##    ## ##     ## ##        ##  ##  ##     ## 
         ##   ##  ##       ##       ##     ## ##         ####   ##     ## 
        ##     ## ##        ######  ######### ##          ##    ######### 
        ######### ##             ## ##     ## ##          ##    ##     ## 
        ##     ## ##       ##    ## ##     ## ##          ##    ##     ## 
        ##     ## ########  ######  ##     ## ########    ##    ##     ## 

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  FINAL FANTASY TACTICS: THE WAR OF THE LIONS
  For PlayStation Portable (PSP)
  Arabic Translation Patch
  Version Beta 0.99a
  My site: https://sites.google.com/view/athbistudio/
  My Twitter: https://twitter.com/tff9q
  MY Paypal Support us: https://t.co/67jzIrXZ5H
  
  Created by Athbi Alshlyh: Full Translation and ASM Hacking. feel free to send me feedback: q8fft8@gmail.com
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
********  This translation is not for sale or rent. **************
**************** هذه الترجمة ليست للبيع او التأجير. **************
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

CREDITS to:
-----------------
   Big Thanks for Supporting:	
   + Abderraouf Khemache - $5
   
   Thanks for help Translation:
   + Fawaz Alrashidi
   + Hamdi Al Harbi
   + klaus.ark66
   
   Thanks to - الشكر إلى:
   + A7med Bamatraf: محول الحروف , http://www.romhacking.net/utilities/1012/
   + Windhex
   + CrystalTile2
   + Romhacking.net
   + CDmage
   + FFTPatcher
   + Tim2View
   + Kruptar 7
   + Square Enix (to make this game)
   + And You

   
Project History - تاريخ بداية المشروع:
-----------------

Start project: 01-Mar-2018
End project:   06-Apr-2018
37 days or 1 months, 6 days.

السلام عليكم، تم وبحمد الله الإنتهاء من ترجمة الفصل الأولة للعبة فاينل فانتسي تاكتكس...
  
Version History - سجل تاريخ الاصدارات:
-----------------

  Version 0.99a,    21 May, 2020 [32,443,999 bytes]
   - مراجعة وتحسين جودة الترجمة وتعديل الكثير من الاخطاء بالنصوص
   - تحسين جودة الخط تمهيدا للباقي الفصول

  Version beta 1,    06 April, 2018 [32,130,659 bytes]
   Done. Go. Play. NOW.


What's left - ما الذي تبقى:
-----------------
  هذه الترجمة للفصل الأول للقصة فقط...
  سيتم أكمال باقي الفصول ان شاءالله..

Game Notes - ملاحظات:
-----------------
  None


Installing Patch - تنصيب الباتش:
-----------------
اولا: احصل على نسخة روم من اللعبة بـ اسم، (أبحث في جوجل.)ـ
Name:	Final Fantasy Tactics - The War of the Lions (USA) ISO (psy-fftw.iso)
File SHA-1: 5120FF66F78CFD31F6E90D8EF4BE8200ECA563F7
MD5: 18D1169CEFED2D5ED77A599694F2F871


ثانيا: تحتاج إلى برنامج ppf-o-matic3 لتطبيق الباتش اختر نسخة ويندوز أو ماك:
Windows:
https://www.romhacking.net/utilities/356/

Mac:
https://www.romhacking.net/utilities/355/

ثالثاً: طبق الباتش على اللعبة.
شغل برنامج
ppf-o-matic3
بعدها في الخانة الاولى حدد اللعبة أيزو
الخانة الثانية حدد الباتش او الرقعه
psy-fftw-ar.ppf
بعدها اضغط على زر
Apply

وبس، وأوقات طيبه لك.


Copyrights - حقوق النشر
-----------------
  FINAL FANTASY TACTICS: THE WAR OF THE LIONS, and all other names are trademarked to
  Square Enix of Japan.


Disclaimer - إخلاء مسؤولية
-----------------
  There is no videogame company or any other company associated with
  Athbi Alshlyh. In no event shall Athbi Alshlyh be liable or responsible for
  any damages that may occur from direct, indirect or consequential results
  of the ability or disability to use or misuse any material it provides.

  In other words, you'd better own the cart for the rom that you're patching,
  and if something goes wrong, don't blame me!
