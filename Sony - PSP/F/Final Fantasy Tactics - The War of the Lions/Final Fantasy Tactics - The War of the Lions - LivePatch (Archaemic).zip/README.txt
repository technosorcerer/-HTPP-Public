Final Fantasy Tactics: The War of the Lions
Patched by Archaemic

These patches require LivePatch to use.

Included are two patches:
- fast.live: removes the slowdown so the game runs at a reasonable speed
- unstretch.live: unstretches the screen so that it is no longer blurred

Please place the fftpsp folder in the livepatch folder in the root of your
memory stick, and delete the patches you do not want applied.

If you have the Japanese version of the game, there are versions of the
patches that work with this region in the fftpsp-jp folder. It is installed
the same way, but make sure to rename the fftpsp-jp folder to fftpsp when in
the livepatch folder.

Note that this is an early beta and might not work properly in all places!
If you find a place where it is broken, please email archaemic@gmail.com with
where the bug was triggered, and a savegame if possible.

Special thanks to the Final Fantasy Hacktics community for helping test the
patch and for being a good place to dump all the information I gathered while
doing the research for this patch.
