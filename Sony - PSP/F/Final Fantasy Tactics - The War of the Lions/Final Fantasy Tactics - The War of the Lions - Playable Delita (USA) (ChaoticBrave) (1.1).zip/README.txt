Playable Delita in Final Fantasy Tactics (PSP version)
======================================================

What this does:

-Completely replaces playable Ramza with Delita. You will be going through the whole game with Delita's sprites and skills. These will change as when Ramza's did in the story. 

What this doesn't do:

-Change Ramza-specific sprites, such as when he bows to the Princess at the start, to look like Delita. Ramza with Delita's colour palette will be used.
-Change story context. There will be two Delitas in the story. You will be doing the heretic's story with a Delita coat of paint.
-Change the overworld and shops. The shop graphics will still use Ramza, and the overworld will still use Ramza sprites.

If you have any issues with this patch, report them using either of the following Discord servers:

My personal Discord server: https://discord.gg/xmgKtf2tN6

General Ivalice Discord server: https://discord.gg/WZ2DbjHXJF

========

WARNING

The initial ISO which the patch used the Nexus slowdown removal patch and not the original Archaemic one. 

==========

Changelog

1.0.0 (19/05/2024): Initial release.
1.1.0 (07/07/2025): Changes the text when units turn into treasure chests or crystals so that their names are not called. This seems to crash emulators.

=========================

Delita's offensive skills:

Squire (Chapter 1):
-Focus
-Rush
-Stone
-Salve
-Chant

Holy Knight (Chapter 2 and 3):
-Focus
-Rush
-Stone
-Salve
-Chant
-Judgement Blade
-Cleansing Strike
-Northswain's Strike
-Hallowed Bolt
-Divine Ruination

Ark Knight (Chapter 4):
-Focus
-Rush
-Stone
-Salve
-Chant
-Judgement Blade
-Cleansing Strike
-Northswain's Strike
-Hallowed Bolt
-Divine Ruination
-Crush Armor
-Crush Helm
-Crush Weapon
-Crush Accessory

Delita's defensive skills (universal between classes):
-Counter Tackle
-Equip Axes
-Beastmaster
-Defend
-JP Boost
-Move +1	

(Delita cannot use Ramza's abilities such as Tailwind and Ultima)

=========================

Instructions:

1) Make sure you have Delta Patcher and open it.
2) Load your ROM in the "Original file" field.
3) Put the patch in the "XDelta patch" field.
4) Click "Apply patch".
5) Done! The opponents' births and fates will wrong them, not you!

=========================

Credits:

ChaoticBrave: For making the patch of course!
NoharOSP: For a crash course on Delta Patcher.
melonhead and Glain: For the incredible FFTPatcher Suite.
Celdia: For a guide on importing custom formation screen sprites.
J7Jase: For bringing bugs with the initial release of the PS1 version of the hack to light.
qwqwqw: For bringing up that the patch does not work with older slowdown patches.
ไก่ต้ม: For bringing up the crash when units perma-die.
Jumza, Nyzer, Tzepish: For helping to fix the crash issue.