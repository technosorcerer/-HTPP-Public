This is a patch for the USA and EUR versions of the PSP game 
"Final Fantasy Tactics - The War of the Lions". 

It allows you to remove the battle animation slowdown and/or unstretch the 
screen to the original 4:3 aspect ratio.

It is based on the patches provided by the LivePatch plugin, created by 
Archaemic ( http://ffhacktics.com/smf/index.php?topic=8490.0 ).
In fact, he is the responsable for doing the hard work of reverse engineeering 
of the game and figuring out how to fix both issues. 

I simply converted the patches for those who can't/don't want to use the 
plugins. The conversion was was fairly straight forward, as he documented things
properly.


DESCRIPTION OF FILES:

	fft_usa_eur_fast.ppf			slowdown fix
	fft_usa_eur_unstretch.ppf		unstretch screen
	
You can use the patches individually or both at the same time.


HOW TO APPLY:

STEP 0: BUY THE GAME IF YOU HAVEN'T ALREADY.

You need to apply the patches to the BOOT.BIN files of your game, and make sure
the PSP/emulator loads that instead of EBOOT.BIN.
Unfortunately, some versions of the game have a dummy BOOT.BIN (with all zeroes)
instead of the proper unencrypted executable files, so you need to decrypt your
EBOOT.BIN first.

The following steps use PPSSPP v1.2.2 to decrypt the EBOOT.BIN to a BOOT.BIN 
file, and use UMDGEN 4.0 to patch and replace the files in the ISO.


STEPS FOR DECRYPTING EBOOT.BIN TO BOOT.BIN WITH PPSSPP:
(this is not needed if you have a non-dummy BOOT.BIN, but it doesn't hurt)
	01. Install PPSSPP
	02. Go to Game Settings, More Settings
	03. Go to Tools, Developer Tools
	04. Enable "Dump decrypted EBOOT.BIN on game boot"
	05. Quit the Settings menu, load the ISO
	06. You should now have a binary file in "memstick\PSP\SYSTEM\DUMP"
	07. Rename the file to BOOT.BIN
	08. Load the ISO in UMDGEN
	09. Go to the PSP_GAME\SYSDIR folder
	09. Drag and drop the BOOT.BIN you obtained in step 7 to the ISO
	10. Confirm that you want to replace the file


STEPS FOR PATCHING THE BOOT.BIN FILE AND MAKING SURE THE PSP USES IT
	01. Open your ISO with UMD (if it isn't open already)
	02. Go to the PSP_GAME\SYSDIR folder
	03. Press the right mouse button in the BOOT.BIN file
	04. Apply the PPF patches you want (fast and/or unstretch)
	05. Press the right mouse button in the BOOT.BIN file again
	06. Use the File Relinker to Use Selected File as Source
	05. Press the right mouse button in the EBOOT.BIN file
	06. Use the File Relinker to Relink to "PSP_GAME\SYSDIR\BOOT.BIN"
	07. Save your ISO.

(instead of relinking the files, you can simply replace the EBOOT.BIN file with
the patched BOOT.BIN)
	
SPECIAL THANKS
	Archaemic for making the original patches

	
DISCLAIMER
	In no event I can be responsable for any damage caused by the patches.
	You should not use the patches if you don't own the original game.
	YOU CAN NOT INCLUDE THIS IN ANY FORM WITH PIRATED COPIES OF THE GAME
	YOU CAN NOT DISTRIBUTE PRE-PATCHED VERSIONS OF THE GAME
