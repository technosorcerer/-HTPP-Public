                                 Tales of Eternia Original Opening
                                          v1.0 (Oct 9 2015)

====================================================================================================
Disclaimer
==========
- No ownership is claimed by vivify93 over Tales of Eternia or the franchise from which it
  originates.

- Apply this patch only to an unmodified European "Tales of Eternia.iso".

- Send bug reports to vivify93 via PM on ROMhacking.net.

- If a modder wishes to use this in their project, they are asked to please credit vivify93.

- Players are encouraged to keep a backup of their original ROM or project in case an error occurs.


Though the undub already reverts this FMV, map hints and battle clips aren't subtitled. This means
the player is required to have a requisite knowledge of Japanese, or stick with the official
localization--including the rearranged, re-scored opening video.

Thus, this compromise was created. This project restores the uncut opening video, featuring the
Japanese title logo and the song Flying by Garnet Crow, while keeping the English voices.

I would like to also fix the out-of-sync dialogue between Meredy and Galenos in the opening, as
well as the wrong pointers between the Greater Craymels' dialogue later in the game, but I'm unsure
of how to go about that. Please contact me if you can help me with either issue.
====================================================================================================

====================================================================================================
Overview
========
- Replaces the English opening with the original Japanese opening, including the song Flying by
  Garnet Crow.
====================================================================================================

====================================================================================================
Credits
=======
- UMDGen team: UMDGen
- Namco-Bandai
�and all you "Tales of�" fans out there!
====================================================================================================