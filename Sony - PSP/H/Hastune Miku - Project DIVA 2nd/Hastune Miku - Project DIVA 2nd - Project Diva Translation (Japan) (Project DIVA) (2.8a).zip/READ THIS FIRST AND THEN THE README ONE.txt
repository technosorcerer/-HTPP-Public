If this is the first time you patch the game follow the README file using the 2.8a.ppf.
If you have already patched to version 2.0 use the 2.8a update.ppf
Bye ~