Hatsune Miku - Project Diva
Translation v0.02
http://projectdiva.wikispaces.com/
October 23rd 2009

------------
How To Patch
------------
First you need an UNTOUCHED ISO of Hatsune Miku - Project Diva. If you have ever modified the ISO, compressed it to a CSO, ripped the padding, or ripped the update folder then this patch probably won�t work. Also it's recomend that you don't patch over an older release. Only apply the main patch to a fresh Japanese ISO.

1. Run ppf-o-matic3.
2. Select the ISO.
3. Select the MAIN PATCH. This patch is very important and is always required.
4. Press the "Apply" button.

Included are some optional patches. If you want Romaji Lyrics and Romaji Titles, then apply them. The reason they are separate is so I can create an English Lyrics and an English Titles patch later and you'll be able to choose which ones you want. For now, there are some problems that have to first be worked out before I make those patches.

Another optional patch is a "Zero Lyrics" patch. Only use this if you don't want ANY lyrics to be shown during the game.

---------------
Version History
---------------
v0.02 MAIN PATCH
* Minor fixes to Miku's Room, Module Names, and Freeplay song names.

v0.02 Romaji Titles
* Song splash screens are now translated and converted to Romaji.

v0.01 MAIN PATCH
* New Title Screen
* New ICON0 and PIC0
* Main Menus translated
* Modules (Costumes) translated
* Miku's Rooms and Accessories translated
* Sound Effects in Rhythm Game Editor translated
* Stages in Rhythm Game Editor translated.
* Motions (dances) in Rhythm Game Editor translated.
* Expressions in Rhythm Game Editor translated.
* Most Camera Options in Rhythm Game Editor translated.
* Fixed minor graphical bug in Len/Rin's song thumbnails.
* Killed the watermark that shows up during a PV.

v0.01 Romaji Lyrics
* All lyrics converted to Romaji based on wikispaces articles.

v0.01 Romaji Titles
* All song titles converted to Romaji based on wikispaces articles.

------------------------
Problems and HELP WANTED
------------------------
*The lyrics are limited to 40 letters per line. There is nothing I could do to solve this, and I could not find any pointers to change their lengths. If someone figures out the lyric display engine and can figure out how to hack it to change the timing or lengthen the amount of letters per line, let me know. This is the main problem that has stopped me from creating an English Lyrics patch. Solving this problem would also make the Romaji Lyrics patch look better.

*I need a skilled translator to translate some script dumps: http://akatranslations.wikispaces.com/Help+NEEDED

-----
Outro
-----
This patch is not even close to complete. I decided to release it as it is now because I think fans of the game would appreciate it. I'm still working on it, and keep in mind that this is just the first patch. There are probably a lot of mistakes and this version in no way reflects what the final patch will look like.

If you want to help, go over to the wikispaces website and look over the articles. I get all my information and translations from there, so help edit the articles so they're all 100% correct.

--------------
Special Thanks
--------------
*Rolen47 - Main Romhacker
*Everyone at the ProjectDiva wikispaces who has contributed and helped build this wonderful wiki.
