divapatch: in-game prx patcher  for Project Diva Extend 0.4-r2 by codestation

Usage:

* Copy the divapatch directory to the ms0:/seplugins directory of the PSP and enable
  the plugin in game.txt: ms0:/seplugins/divapatch/divapatch.prx 1

* If you use decrypted dlc then use nploader instead of nodrm, also make sure that
  nploader.prx is listed before divapatch.prx.

changes since 0.4-r1:
- Fixed crash when giving a hanging scroll (weakness) as a present in the DIVA room
- Renamed Absolute Territory -> Zettai Ryouiki, for those who knows what this means ;)
- Modified translation samples for PD 2nd#/2nd1.01
changes since 0.4:
- Changed png quantizer (pngnq -> pngquant) to improve image quality.
changes since 0.3:
- "Edit mode" is further translated.
- "Play records" is translated.
- "DIVA room" is 99% translated.
- Rest of the titles are translated.
- Home, load, save, delete, osk, ad-hoc, and screenshot psp dialogs now are in english.
- Restored support to translate Project Diva 1st.
- Two more songs lyrics are translated to romaji (Sekiranun Graffiti and Rin Rin Signal).
- Almost all modes must be completly translated, with some exceptions:
  - 1% of the Titles.
  - Diva room events (their descriptions are translated).
  - Ad-hoc messages (don't have another psp to test this).
  - Friend system (don't have another psp to test this).
  - Data import/install one-time messages.
  - Edit mode motions, backgrounds, button sounds and other misc texts.

coming soon in 0.5 (or 1.0, maybe this gonna be the last one):
 - Finish the translation of the exceptions list above.
 - Finish romaji lyrics.
 - Finish english lyrics.

Special thanks to translation helpers: HeroKing, naki-the-curious, kienono, Sonic-DX, Loserbait, nipah, Nightsail

Project repo: https://github.com/codestation/prxpatch/tree/master/divapatch

###### Read below if you are interested in editing or translating ######

The source code for this plugin and the converter is included in the src directory.
The sdk directory contain the translation source files and the xcf master image files.

Use any decent editor and make sure that the encoding is in shift-jis. After you finish
editing the file do the following:

* windows users: drop the translation txt file in the divaconverter.exe and it will create
  a .bin filenames

* linux users: execute ./divaconvert <translation filename>.txt

description of the txt files:
 - divaext_translation.txt: main translation filename
 - divaext_embedded.txt: texts that cannot be relocated so they have size constraints
 - divaext_*_base.txt: untranslated files you they can be used as reference (if you think that
   a translation is wrong then you can use those files to make sure of it).

The xcf files are source files to be used with the Gimp (version 2.7) image editor (not sure if those are
compatible with Photoshop or similar). The texts are organized in layers for easy text editing.
After you are done editing the image just export it as png then use any png quantizer to make
them 8-bit indexed (i used pngquant for the task).