Project DIVA 1st Translation Patch, by FShadow

INSTALLATION:

This patch requires a 2-part installation.

Part 1 - Install ppf patch:

* Backup your original Project DIVA ISO

* Open PPF-O-Matic, and select your ISO and the ppf patch included with this file

* Select Apply

* Copy your newly patched ISO to the ISO folder on your PSP

Part 2 - Install divapatch:

* Copy the divapatch directory to the ms0:/seplugins directory of the PSP and enable
  the plugin in game.txt: ms0:/seplugins/divapatch/divapatch.prx 1

* If you would like Romaji lyrics, delete "diva1st_embedded.bin" and rename "diva1st_embedded - Romaji.bin" to "diva1st_embedded.bin"

** If you use decrypted dlc then use nploader instead of nodrm, also make sure that
  nploader.prx is listed before divapatch.prx.

Congratulations! Your Project DIVA game is now in English!

------------------------------------------------------------------------------------------

original 0.5 release:
- Menus are in English
- "Rhythm Game Editor" is mostly, if not completely translated.
- "Miku's Room" is translated.
- Song titles are in English
- The following songs' lyrics are in English:
  - World is Mine
  - Love is War
  - That One Second, in Slow Motion
  - The Rebel
  - Melt
  - Far Away
  - Song of Desert, Forest & Magic (All ver.)
- Included an optional romaji diva1st_embedded.bin, making the aforementioned lyrics romaji
  - NOTE: Because of technical reasons, Song of Desert, Forest & Magic will remain in English.
- Ad-hoc messages SHOULD be in English, but I have no way to test this.
- Removed watermark from PV Appreciation Mode
- Song thumbnails are in English

coming soon:
 - Finish English lyrics.
 - Change HUD font to Bitstream Vera Sans Mono (maybe)
 - Eventually port the entire project to divapatch to eliminate the need to repatch the ISO
   with every new update
 - Some behind-the-scenes technical stuff
 - Redo the thumbnail for "Requiem for the Phantasma"
 - Romanize all the names in the Visual Library

Special thanks to:

- Rolen47, for creating the original English partial patch
- lordscales91, for porting Rolen47's patch to divapatch
- codestation, for creating divapatch and lending me some assistance in working it

------------------------------------------------------------------------------------------

# The Rest of the file was written for the original Project Diva extend patch, but is still relevant


Project repo: https://github.com/codestation/prxpatch/tree/master/divapatch

###### Read below if you are interested in editing or translating ######

The source code for this plugin and the converter is included in the src directory.
The sdk directory contain the translation source files and the xcf master image files.

Use any decent editor and make sure that the encoding is in shift-jis. After you finish
editing the file do the following:

* windows users: drop the translation txt file in the divaconverter.exe and it will create
  a .bin filenames

* linux users: execute ./divaconvert <translation filename>.txt

description of the txt files:
 - diva1st_translation.txt: main translation filename
 - diva1st_embedded.txt: texts that cannot be relocated so they have size constraints
 - diva1st_images.txt: directory for images files. I think it might be a bit broken.

If you think a translation may be wrong, check the original text here
http://akatranslations.wikispaces.com/Help+NEEDED

The xcf files are source files to be used with the Gimp (version 2.8) image editor (not sure if those are
compatible with Photoshop or similar). The texts are organized in layers for easy text editing.
After you are done editing the image just export it as png then use any png quantizer to make
them 8-bit indexed (I used PNGoo).