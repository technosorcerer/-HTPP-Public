A Quick Overview of the Images
By: FShadow
-------------------------------

**PV_START_XX.XCF**

I included these so that others could translate the song title screens into their own languages. These images are to be edited in GIMP. Berkelium Type is the font used.

Basically, each file will contain 3-4 layers:

1) The English title. This will be the largest text. Feel free to translate this into whatever language you choose. The font size is 19px if there is a romaji title layer, and is 25px if there is not. Some titles are too long, so the font size is decreased to make them fit (e.g. "Song of Desert, Forest & Magic")

2) The Japanese romaji title. If the song title was already in English, this layer is omitted. I guess if you were translating this into your own language, you could add this layer and put the original English title here, and your translated title above it. The font size is usually 14px.

3) The artist information, and other onscreen display stuff. This layer was originally made by Rolen47 in his original patch, and I was too lazy to edit it, so if you're going to translate it, you'll have to mess around with it yourself. I'd recommend using Berkelium Type for this layer as well (Except the difficulties. I'd recommend some kind of modern font. Perhaps you could use the moonhouse font. Google it.)

4) Lastly, there should be a layer called either "Setter" or just "Clipboard" (I was too lazy to go through all of them). This layer is simply here so that you can select it, and center your title text by using the Alignment Tool's "Relative to Active Layer".


**EDIT.XCF**
This is simply what shows in the Rhythm Game Editor. The font used is Droid Sans, size 10px. It contains a simple drop shadow.

**EDIT_RHYTHM.XCF, MENU_BASIC.XCF, EDIT_BUTTON.XCF**
To make the outlined text, I used Droid Sans, typed the text, then went to Layers > Transparency > Alpha to Selection. I then selected Select > Grow > 1px. I then duplicated the text to a new layer behind the original text, then used the bucket tool to fill the whole selection on the duplicated layer.

**EDIT_BUTTON.XCF**
For "Display", "Expression", "Rhythm", etc, I used Droid Sans Mono with a simple drop shadow. The rest of the text is Droid Sans Bold.

**FIELD_LOAD_XX.XCF**
This is just an example of how you can make your own loading backgrounds if you wanted. (Credit to the original creator of the picture, btw.)

**FREE_THUM1.XCF**
Requiem for the Phantasma - My translated thumbnail sucks; I'll make a different image in a future update, and update this file to tell you how to make it.

+ Electric Angel - Font: Desyrel, size 28px for the "E" and 24px for "lectric". "Angel" is 22px.

+ Your Diva - Font: Angelina, size 22px. The line spacing is set to 3.0 so it streches across the length of the wings. The outline was created in the same method described above.

+ The Vanishing of Hatsune Miku - Font: Baskerville Old Face, size 15px. The pink layer is bolded, and is behind the black layer, whose letter spacing is adjusted between letters to ensure proper alignment. Making the outlined text for "Hatsune" and "Miku" was done in the same process described above. The word "of" is size 12px.

**MENU_BASIC02.XCF**
The font I used was Droid Sans, size 10px, but I want to change the font in a future update to Bitstream Vera Sans Mono. Make sure that when you update the menu_basic02_log.txt with the correct lengths and positions of your new text.

**MENU_RESULT.XCF, MENU_TITLE_XXXX.XCF**
These all use Berkelium Type. "Move" and "OK" in menu_result.xcf are both Droid Sans size 10px, but I would like to update it to Bitstream Vera Sans Mono in a future update.

-----------------------------------------------------------------------------------------------

After you are ready to save your image, save your image as a png. Then use either the included pngnqi or PNGoo programs to convert your image into the special png format used by the game.

If you use pngnqi, just drag and drop your png onto it, and it will create a converted file.

If you use PNGoo, open the program, then drag and drop your images into it, keeping the default settings. Then, specify an output folder for your converted files. Personally, I prefer PNGoo, because you don't have to rename all of your files.


IF YOU ARE CREATING A PPF PATCH:
After you have saved all your files, open DivaDataList.afs in AFSExplorer, and in the top bar, go to Action, then Import Folder. OR, just press Ctr+3. Navigate to the folder with your translated files, and wait for it to import. Now, you just need to select Update from the File menu, and viola! You are ready to put the .afs back into the ISO with CDMage!

IF YOU ARE USING DIVAPATCH:
All you need to do is drag your correctly named image into seplugins/divapatch/diva1st on your PSP! NOTE: If divapatch doesn't replace your file, try putting it directly into the ISO itself in the steps explained above.