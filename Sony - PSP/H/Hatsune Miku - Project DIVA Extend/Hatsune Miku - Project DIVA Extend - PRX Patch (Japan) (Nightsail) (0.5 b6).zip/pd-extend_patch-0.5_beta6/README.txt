divapatch: in-game prx patcher  for Project Diva Extend 0.5 beta 6 by codestation/Nightsail

Usage:

* Copy the divapatch directory to the ms0:/seplugins directory of the PSP and enable
  the plugin in game.txt: ms0:/seplugins/divapatch/divapatch.prx 1

* If you use decrypted dlc then use nploader instead of nodrm, also make sure that
  nploader.prx is listed before divapatch.prx.

changes since 0.4-r2:
- Massive translation/fixes. 2200+ changes.
- Fixed a glitch with sample lyric text for color selection in Edit mode.
- Edit mode is translated. (still being tested)
- Names for Edit mode character motions, backgrounds, effects, camera presets,
  facial expressions, etc, have been translated.
- Most Diva Room Event titles have been translated. (now verifying them)
- The PD2-to-PDE system data import and other new-game-related text has been translated.
- Almost all song lyrics have been converted to Romaji.
- Many lines have been re-written for better phrasing/grammar, consistency, and clarity.
  This includes Player Title descriptions, various menu descriptions, the playlist functions in the Diva Rooms,
  various confirmation dialogs, etc...
- All but four bottom-of-the-screen HUD control descriptors have been translated.
  Untranslated ones have red/pinkish icons. (Please let us know how to see it, if you find it in-game!)
- Tutorial translated
- Ad Hoc mode is translated. (still being tested)
- Friends system is 99% translated. (still being tested)
- A few more offsets found.
- Changed plugin. Now stores PDE replacement images in a subfolder.

changes since 0.4-r1:
- Fixed crash when giving a hanging scroll (weakness) as a present in the DIVA room
- Renamed Absolute Territory -> Zettai Ryouiki, for those who knows what this means ;)
- Modified translation samples for PD 2nd#/2nd1.01
changes since 0.4:
- Changed png quantizer (pngnq -> pngquant) to improve image quality.
changes since 0.3:
- "Edit mode" is further translated.
- "Play records" is translated.
- "DIVA room" is 99% translated.
- Rest of the titles are translated.
- Home, load, save, delete, osk, ad-hoc, and screenshot psp dialogs now are in english.
- Restored support to translate Project Diva 1st.
- Two more songs lyrics are translated to romaji (Sekiranun Graffiti and Rin Rin Signal).
- Almost all modes must be completly translated, with some exceptions:
  - 1% of the Titles.
  - Diva room events (their descriptions are translated).
  - Ad-hoc messages (don't have another psp to test this).
  - Friend system (don't have another psp to test this).

coming soon in 0.5 (or 1.0, maybe this gonna be the last one):
 - Finish the translation of the exceptions list above.
 - Finish testing error messages, etc.
 - Finish romaji lyrics.
 - Finish english lyrics.

Special thanks to translation helpers:
- HeroKing, naki-the-curious, kienono, Sonic-DX, Loserbait, nipah, Nightsail, Suyo, Steven

Project repo: https://github.com/codestation/prxpatch/tree/master/divapatch

###### Read below if you are interested in editing or translating ######

The source code for this plugin and the converter is included in the src directory.
The sdk directory contain the translation source files and the xcf master image files.

Use any decent editor and make sure that the encoding is in shift-jis. After you finish
editing the file do the following:

* windows users: drop the translation txt file in the divaconverter.exe and it will create
  .bin files

* linux users: execute ./divaconvert <translation filename>.txt

description of the txt files:
 - divaext_translation.txt: main translation filename
 - divaext_embedded.txt: texts that cannot be relocated so they have size constraints
 - divaext_*_base.txt: untranslated files for use as reference (if you think that a translation
  is wrong, then you can use those files to re-check it).

The xcf files are source files to be used with the Gimp (version 2.7+) image editor (not sure if those are
compatible with Photoshop or similar). The texts are organized in layers for easy text editing.
After you are done editing the image just export it as png then use any png quantizer to make
them 8-bit indexed (codestation used pngquant for the task; Nightsail used and included pngnqi).

Nightsail's note about the .xcf files: Windows and Linux seem to render the fonts a little differently, so I doubled the layers when I wanted them to be extra bold (edit_base_04) -- others may not need this.

The font used for the more stylish, larger parts is Berkelium (http://www.dafont.com/berkelium-type.font) and for the HUD (bottom of the screen control directions) and other places, it's Bitstream Vera Sans Mono (http://www.dafont.com/bitstream-vera-mono.font)