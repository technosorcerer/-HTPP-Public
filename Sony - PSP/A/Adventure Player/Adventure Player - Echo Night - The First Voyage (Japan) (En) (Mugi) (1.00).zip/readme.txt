Another one bites the dust...

Full english translation and standalone conversion patch for:
	Echo Night: the First Voyage

Staff:

	Graphics:	mugi
	Hacking: 	mugi, xyz
	Translation:	tom


how to use:
-----------
- get your copy of AdventurePlayer iso (CRC32: 44636A6C)
- name the iso to ULJS-00011.iso
- put ULJS-00011.iso into the same folder with patchme.bat, xdelta.exe and echo_eng.v1.00.xdelta
- run patchme.bat
- run the sfv file to verify that the patching was succesful. (patched iso CRC32 should be 11E9B3A0)
- put echo_eng.v1.00.iso on psp or load in emulator and play game.


NOTE:
-----------
Both archives contain the same patch file, but target a different source .iso
use the [A3CA9117] tagged patch file if your adventure player .iso matches
the CRC32 value, othervise use the standard patch file that targets the more
commonly available .iso with a CRC32 of: 44636A6C.



changelog
-------------------
v1.00 - echo_eng.v1.00.xdelta
	- initial release