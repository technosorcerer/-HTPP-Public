
REMEMBER TO ALWAYS MAKE A BACKUP BEFORE PATCHING, JUST IN CASE!

This patch is for the european version of 
Final Fantasy Crystal Chronicles.

There are two patches :xDelta and IPS. You can use LunarIPS and
xDeltaPatcher to patch this ISO.

Once it finishes patching, the game won't run at PAL 50, and instead
it will be a PAL 60 by default.

If you use other dump or a shrunk iso, use IPS.

--------------------------------------
--------------------------------------
Final Fantasy CC	(Only 60hz)
--------------------------------------

Final Fantasy - Crystal Chronicles (Europe) (En,Fr,De,Es,It).iso

CRC32 1C68474C
SHA-1 0B3B7C1F48319E28905CA6EFF66B815D1C09C6D3
MD-5  018B43A323A75BB73D124498327810CD

If you want to hex edit yourself:

	Original
Offset  Values
203FC0  00 00 00 04  -> 00 00 00 14
203FC4  02 80 01 C0  -> 02 80 01 C0 (No changes)
203FC8	02 10 00 28  -> 01 C0 00 28
203FCC  00 17 02 80  -> 00 10 02 80
203FD0  02 10 00 00  -> 01 C0 00 00

Notes:

Works on Nintendont; 480P compatible
The game starts up at 480i, if you force
480P on Nintendont, it will but at 480P.
--------------------------------------
--------------------------------------