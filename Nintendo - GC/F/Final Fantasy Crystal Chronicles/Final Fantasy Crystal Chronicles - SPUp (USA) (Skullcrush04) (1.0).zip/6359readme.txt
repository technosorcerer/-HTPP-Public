Final Fantasy Crystal Chronicles: Single Player Upgrade (or SPUp) is a hack aimed at improving the fun of the single player experience of FFCC, though most of it is multiplayer-compatible.

Change List:
5 out of 6 of the Spell Fusions for Stop have been changed to enable the use of 3 multiplayer spells and 2 enemy spells:
	⦁Thunder+Life+Life=Holyra (Power 15x3): Area Holy damage that not only exposes undead enemies, but is damage is virtually unresisted. It is unable to inflict any status ailments, though.
	⦁Fire+Blizzard+Thunder=Graviga: Cuts down health by a fraction in a massive area. Still one-time use.
	⦁Life+Blizzard+Fire=Slowga: Slows down enemy movement and charging in a massive area. Does not affect bosses.
	⦁Life+Blizzard+Thunder=Stop: Still stops an enemy in its tracks for a good beating, if it is not immune. Does not affect bosses.
	⦁Fire+Blizzard+Clear=Break (Single Player only): Petrifies enemies in a small area, usually when Stop fails. They gain a massive defense increase, but defense won't affect Gravity. Does not affect bosses.
	⦁Fire+Thunder+Clear=Curse (Single Player only): Decreases enemy Strength, Defense, and Magic in a small area. Can cut a powerful enemy down to size, but undead tend to shrug it off. Does not affect bosses.

Equipment and focus attacks have been added and updated for each tribe:
Clavats:
	⦁Rune Blade and Excalibur now use the focus attack Soulfire.
	⦁Excalibur strengthened.
	⦁Ultima Sword now uses the Feather Saber's model.
	⦁Added Buster Sword to Hero's Weapon Scroll. Uses the focus attack Braver.
	⦁Added Gáe Bolg to Celestial Spear Scroll. Uses the focus attack Aura Pulse.
	⦁Added Shugen Hammer to Forbidden Tome Scroll. Uses the focus attack Shock Assault.
	⦁Gaia Plate now comes from Mythic Armor Scroll (Text change).
	⦁Flame Shield now uses previously unused model.
	⦁Old Talisman of Wisdom is now called Mage's Emblem akin to the Thief's Emblem.
	⦁Soulshot is now Soulfire, which fires a burst of two Soulshots together (Power 20x2).
	⦁Added Braver, an improved Power Slash with an area of effect (Power 20x2).
	⦁Added Aura Pulse, a modified Soulshot that fires a pair of piercing shots (Power 15x2).
	⦁Added Shock Assault, an improved Bash that stuns longer (Power 20x2).
Lilties:
	⦁Highwind is now called Obelisk.
	⦁Ultima Lance now uses Halberd's model.
	⦁Changed Dragoon's Spear to the stronger Kain's Lance.
	⦁Added Demonsbane to Dark Sword Scroll. Uses the focus attack Retribution.
	⦁Added Lemuria Club to Lunar Maul Scroll. Uses the focus attack Skyfall.
	⦁Added Black Plate to Mythic Armor Scroll. Increases focus attack range.
	⦁Avalanche is now called Gavel.
	⦁Added Retribution, a large, ranged explosion (Power 15x2).
	⦁Added Skyfall, an improved Gavel with higher damage (Power 20x2)
Yukes:
	⦁Ultima Hammer now uses Mythril Hammer's model.
	⦁Added Mjollnir to Hero's Weapon Scroll. Uses the focus attack Lightning Bomb.
	⦁Added Dark Blade to Dark Sword Scroll. Uses the focus attack Soul Vortex.
	⦁Added Angel Head to Lunar Maul Scroll. Uses the focus attack Dual Gale.
	⦁Added Mystic Mail to Mythic Armor Scroll. Increases spell casting range.
	⦁Magic Bomb now charges faster and has a base power of 25, 50, or 100.
	⦁Added Lightning Bomb, an improved Shock Bomb that calls a lighning strike first (Power 20x2).
	⦁Added Soul Vortex, which surrounds the user with energy (Power 5x3).
	⦁Added Dual Gale, an improved Wave Bomb that pushes the enemy twice (Power 15x2)
Selkies:
	⦁Queen's Heel strengthened.
	⦁Ultima Maul now uses Prism Bludgeon's model.
	⦁Added Whale Whisker to Hero's Weapon Scroll. Uses the focus attack Dual Blast.
	⦁Added Highwind to Celestial Spear Scroll. Uses the focus attack Avalanche.
	⦁Added Jewel Hammer to Forbidden Tome Scroll. Uses the focus attack Shock Burst.
	⦁Added Angel Raiment to Mythic Armor Scroll. Increases focus attack range.
	⦁Meteor Blast now has a base power of 80.
	⦁Added Avalanche, an improved Stampede with an area of effect knockback (Power 20x2)
	⦁Added Shock Burst, an improved Stampede with an area of effect stun (Power 15x2)
All:
	⦁Crystal Mail defense increased by 1.
	⦁The following items may now be equipped: Charm of Wisdom, Charm of Speed, Daemon's Earring, Pixie's Earring, Lion's Heart, Wizard's Soul.
	⦁Added Guard Ring to new Defense Tome Scroll.
Clavats and Yukes:
	⦁The following items may now be equipped: Talisman of Wisdom, Devil's Earring, Twisted Spectacles, Power Goggles, Bishop's Soul.
Lilties and Selkies:
	⦁The following items may now be equipped: Talisman of Speed, Angel's Earring, Twisted Scope, Eagle Goggles, Dragon's Heart.

Some scrolls have had their locations swapped or names changed:
	⦁Celestial Weapon is now Celestial Spear.
	⦁Dark Weapon is now Dark Sword.
	⦁Lunar Weapon is now Lunar Maul.
	⦁Earth Armor is now Mythic Armor.
	⦁Secrets of Wisdom has replaced old Tome of Wisdom.
	⦁Magecraft has replaced old Secrets of Wisdom.
	⦁Tome of Wisdom has replaced Lady's Accessories.
	⦁Defense Tome has replaced old Tome of Speed.
	⦁Tome of Speed has replaced Zeal Kit.

Scroll ingredient changes:
	⦁Celestial Spear: Orichalcum, Dragon's Fang, Red Eye
	⦁Magecraft: Green Sphere, Ethereal Orb, Lord's Robe
	⦁Defense Tome: Diamond Ore, Hard Shell
	⦁Eyewear Techniques: Crystal Ball x2, Silver, Coeurl Whisker
	⦁Goggle Techniques: Crystal Ball x2, Mythril, Zu's Beak

Some Shops now have different items, several of which used to be lost by dungeon Cycle 3:
Fields of Fum Selkie Peddler (Odd Years):
	⦁Shiny Shard
	⦁Eyewear Techniques
	⦁Designer Glasses
	⦁Goggle Techniques
	⦁Designer Goggles
Shella Scroll Shop:
	⦁Tome of Magic
Leuda Scroll Shop (After Love Letter Quest):
	⦁Soul of the Lion

Installation:
Requires the US version of Final Fantasy Crystal Chronicles
Uses xDelta. Use the xDelta UI for easiest installation: https://www.romhacking.net/utilities/598/

ROM / ISO Information:
ROM: Final Fantasy Crystal Chronicles USA
CRC32: 141aeac0
MD5: a6d6064396b20c0d0d836afad97d3a4c
SHA-1: 3aced85176e0d3299fc86e06fece2fc25996e914