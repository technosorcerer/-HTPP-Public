  �a  �t       C                $=1000$R�w�i��b|$B���{-�x�O�j�I��|$<$F1$FS$F1$FCL_SANAKI|$F3$FCL_ERINCIA|$F4$FCL_IKE|$F1$PYou have done excellent work, $w2Ike.$K
Thanks to you, $w2the wound that has
scarred Begnion for many long
years$w2 can finally begin to heal.$K$PAs promised,$w3 Begnion$w2 now offers
its support to Crimea's restoration.$K$PHowever, Prime Minister Sephiran has yet to
return, $w2which limits the reinforcements
I can provide.$K
Be that as it may, what troops I can
spare await your command.$w3
Use them as you see fit.$K
$F4$PI understand. Thank you.$w4$FS That's good
news,$w2 isn't it, Princess Elincia?$K
$F3$P$FSYes. $w2Yes it is.$K
$F4$P$FA$F1$PThis has taught me a valuable lesson...$w4
Our land $w2needs the laguz.$K$PI also believe that beorc and laguz$w2
need each other to survive.$K$PThe previous apostle, my grandmother,$w3
was desirous of such a world, as were my
own parents.$K$PPrincess Elincia,$w4 your father, $w2King
Ramon of Crimea, was a true pioneer in the
area of beorc-laguz relations.$K$PIn the very near future, I will give the
imperial senate a few...$w3suggestions
on achieving a fully integrated society.$K$PI doubt the road will be easily traveled,
but I can no longer $w2turn a blind eye
to these issues.$K$PPrincess Elincia, $w2you must rebuild Crimea.$K$PIf you are sucessful,$w2 we will join forces
and change the world.$K
$F3$PEmpress Sanaki, your vision $w2surpasses
even my own...$w5 My father $w2would be
so pleased to hear your words.$K
$F4$PLooks like $w2you're through with me.$w4
I'll wait outside until you're finished talking.$K$F4$FD
$F1$P$FAHold!$w4 I am most definitely NOT
through with you.$K
$F4$FCL_IKE|$F4$PHuh?$w3 What did I do now?$K
$F1$PYou're as $w2impudent and impatient as ever.$K$PHeed me, Ike. $w5If you are to help lead the
Crimean Liberation Army, $w2you must be$w2
given a more appropriate title.$K
$F4$PIf you're talking about making me a noble,$w2
I'll decline, thanks.$w4 That's not my
kind of thing.$K
$F1$PYou are not in a position to refuse. $w5Giving
some nameless mercenary control of
Begnion's troops would be...problematic.$K$PAnd more importantly, it would affect the
troops. $w5$FSYou will resign yourself to this
and receive peerage from Princess Elincia.$K$P$F1$FD$F3$FD
$Ub$H$F4$PWhat?$w2 No, wait!$w3 This is absurd...$w4
Blast!$w4 Of all the foolish...$K
$F1$FCL_ERINCIA|$F1$PI'm...$w2sorry about this.$w4 If you're absolutely
opposed to it,$w2 I won't force you.$K
$F4$PNo, $w2I have to do what's necessary.$w4
What am I supposed to do now?
Put on a funny hat or something?$K
$F1$PUm, $w2will you...$w4lend me $w2your sword?$K$FS$PThank you.$K$FA$PNow, $w2may I ask you...$w4to kneel $w2before me?$K
$F4$FD$F1$PTh-$w2thank you.$K$PAll right...$w3 Let me begin.$K$P$Ub$H$FcIn the name of House Crimea,$w2$K$PI hereby grant you the title and rank
of lord and all the honors it conveys.$w2
Rise, Lord Ike.$K
$=0400  $=1000$R�w�i��b|$B���{-�x�O�j�I��|$<$F3$FCL_IKE2|$F1$FCL_ERINCIA|$F1$PIt is done.$K
$F3$PWhat $w2an odd feeling.$K
$F0$FS$F0$FCL_SANAKI|$F0$P$FSAha! $w2Your new rank suits you.$K
$F4$FS$F4$FCL_SIGRUN|$F4$PI completely agree.$K
$F1$P$FSYes, $w2it truly does...$K
$F3$PHmm... I suppose.$w4 Not that it
matters to me.$K
$=1500    $RGMAP��b|$O3$GWestern Begnion is home to a great forest.$K    $RGMAP��b|$O3$GAt one time,$w3 these woods were home to
the kingdom of Serenes and ruled by the
heron clan$w1 of the bird tribes.$w2$K $RGMAP��b|$O3$GFollowing the Serenes Massacre,$w4 the forest
lost its color and vitality. $w2Some said $w2it was
the sorrow of the goddess made real.$K$PFor twenty long years,$w3 the devout citizens
of Begnion$w3 trembled in shame and loathing$w3
over the crime $w2they had committed.$K $RGMAP��b|$O3$GThe Begnion Empress, $w2Apostle Sanaki,$w3
stepped forward as representative of
her countrymen.$K   $RGMAP��b|$O3$GKneeling before the surviving$w3 heron
prince $w2and princess,$w3 she gave voice
to the apology of her people.$K    $RGMAP��b|$O3$GShe spoke$w3 not as one nation to another$w4
but as neighbors on the same continent.$w5
The massacre $w2was unforgivable.$K$PHowever,$w3 hatred breeds hatred,$w4 and if
the cycle of grief and anger is not broken,$w3
it will continue $w2for time without end.$K$PIt was with this in mind that the herons$w2
accepted the apostle's apology.$K  $RGMAP��b|$O3$GAnd so it was $w6that Serenes Forest was
returned $w2to its former glory.$K $RGMAP��b|$O3$GAfterward, $w2as payment for Ike's service,$w3
Princess Elincia $w2gained the services$w2
of a regiment of Begnion army regulars.$K $RGMAP��b|$O3$GThough of common birth,$w3 Ike receives
peerage from the princess$w3 and is given
command of the army.$K    $RGMAP��b|$O3$GAs the first snow of the season falls,$w3
the newly commissioned General Ike$w3 takes
control$w4 of the Crimean Liberation Army.$K$PHe leads it toward the knife-edged
mountains$w3 that mark the border$w2
between Begnion$w3 and Daein.$K $=1000$R�w�i��b|$B���{-�N���~�A|$<$F3$FS$F3$FCL_ASHNARD|$F0$FCL_DARKKNIGHT|$F3$PSo they've left Begnion, have they?$K
$F0$PAccording to our spy, $w2they march
with a regiment of Begnion's army.$K$PThey plan to take a land route through$w2
Daein $w2and then into Crimea.$K
$F3$PHah! $w2They plan to cut across Daein?$K$PWith nothing more than a single regiment$w2
at whose core is a tattered band of
ragtag mercenaries?$K$PGawain's son leads this rabble, yes?$w4
How does he stand up to his father's
legacy?$K
$F0$PHe doesn't.$w4 He's just a boy, $w2not yet
worthy of his father's name.$K
$F3$P$FAHmph. $w2Disappointing.$K
$F0$PThough his skill with the blade is rough,$w2
there is something...uncanny about
him.$w4 People seem drawn to him.$K$PAnd not just Begnion's apostle, either.$w2
He's also gained the trust of the Serenes
survivors...and of King Phoenicis as well.$K
$F3$PThe herons are alive?$K
$F0$PIt appears that two members
of the royal family survived.$K
$F3$P$FSHeh heh...$w4 Look how nicely $w2the
table's been set for us.$K$PBring one of them to me...$w2
I care not which one.$w4
And I want the medallion as well.$K
$F0$P...As you wish.$K$=1100   $R�w�i��b|$B����-��|$<$F0$FCL_IKE2|$F1$FCL_TANIS|$F1$POnce we cross that great wall,
we'll be in Daein.$K$PLook there, atop that building!$w4
...Daein wyvern riders on patrol.$w3
They won't be happy to see us.$K
$F1$FD$F3$FCL_TANIS|$F3$PTell me, General Ike, $w2have you
faced wyvern riders in combat?$K
$F0$POnly a few times.$w3 I got the impression
that the Kilvas ravens were$w2 the more
dangerous foe.$K
$F3$PIf that's your impression, then you have
yet to fight true wyvern riders.$K
$F0$PWhat do you mean?$K
$F3$PI have no way $w2of judging the ones we see
here, but $w5I know another unit, one that
was attached to Begnion's temple guard.$K$PThey had their reasons for leaving...$w3
But the important thing to remember$w2
is that they are exceedingly powerful.$K
$F0$PWhich explains $w2why the apostle sent
you to accompany us.$K
$F3$PThat's right.$w4 Pegasus knights fare better
than most against wyvern riders.$w5
We know the skies $w2as well as they do.$K
$F0$PYeah, I prefer to keep my feet on the
ground, thank you.$w5 Can I entrust
the flying business $w2to you?$K
$F3$POf course.$w4 $FSWe'll bring honor to the
name of the apostle's sacred guards.$K
$=1000 $R�w�i��b|$B����-��|$<$F1$FCL_ERINCIA|$F3$FCL_IKE2|$F1$PMy lord Ike.$w4 Are preparations complete?$K
$F3$PYes.$w4 The enemy should not yet be aware
that we've come this far.$K$PWe're going to launch a surprise attack and
try to capture the wall on our first charge.$w4
Please wait for us at the base camp.$K
$F1$PVery well...$K
$F3$P$FSThere's no need to look so worried.$w2
We're well prepared.$w4 And we've got you
as our good luck charm.$K
$F1$PThank you for that, but...$w4
Do be careful,$w4 my lord Ike.$K
$F3$P$FAHey, don't worry! This may be our first
battle as an official army, $w2but we've
fought Daein many times.$K$PWe're going to win.$w4 After all, I can't lose
my very first battle as a snooty noble,
now can I?$K
$F1$PI believe in you,$w4 and I know that you
will be victorious. Come back safe.$K
$=0600 $R�㉺��b|$c0IKE2|$s0Is everyone $w2ready?$w4
Let's move out!$K    $R�㉺��b|$c0IKE2|$s0Is everyone $w2ready?$w4
Let's move out!$K
$c2ERINCIA|$s2Hold a moment, $w2my lord Ike!$K
In the sky...something's coming!$K
$s0Who's that?$K $R�㉺��b|$c0TIBARN|$s0Ah, Ike! Well met.$w4 It appears that
you're getting ready for your first
battle as Crimea's army.$K
$c1IKE2|$s1And $w2you're escorting the heron
siblings back to Phoenicis, right?$K
$s0That was the original plan, but...$w3
Someone here insisted that we follow
you.$w4 Quite unreasonably, I might add.$K$d0
$c0RIEUSION|$s0You treated us with courtesy, beorc.$w4
We must act accordingly.$K
Isn't that so, $w2Leanne?$K
$s2$FS$c2LEARNE|$s2#F01$O2Yes,$w2 brother.#F02$O1$K
$d2$s0You said your name was Ike, $w2correct?$K
$s1Yes.$K
$s0You aided my sister and me during a
time of danger.$w4 We herons hold
courtesy in high esteem.$K
We must repay our debt to you.$K
$s1That's really not necessary.$K
$s0We are practitioners of seid magic.$w4
We cannot fight, $w2but we can
imbue our allies with strength.$K$PIf you so wish it, $w2I $w2will travel
with you.$w4 In this way $w2I will
repay you for what you have done.$K
$s1...$K
$d0$SD$N$UB$H      $SD$R�㉺��b|$c1IKE2|$N$UB$H   Allow to join.  Refuse. $SE$s1You were lucky to find your sister;$w2
shouldn't you stay by her side?$K
$c0RIEUSION|$s0Leanne understands what I do.$K
$s1$FSI see.$w4 In that case, welcome.$K
$s0$FSThank you.$K I swear on the honor of
my clan$w2 to do all I can to strengthen
your cause.$K$w5$d1
$s1$FS$c1TIBARN|$s1It's settled then.$w4 And you'll get
aid from me as well.$w4 Janaff!$K
$s0$FA$s3$FS$c3JANAFF|$s3Right here, Your Majesty!$K
$s1You'll go with the Crimean army $w2and
protect Reyson.$K
$s3Leave it to me!$K
$d3$s1You, too, Ulki.$w4 All right?$K
$c3VULCI|$s3Of course.$K$d3
$s0Tibarn!$w4 It's too much, I cannot
accept this.$K$PYou're already watching over Leanne
and my father as well.$K
$s1These past twenty years... $w5I know
what it's been like for you living in
Phoenicis.$K$PI'm only sorry I can't do more.$K
$s0Tibarn...$w4 $FcI thank you,$w4 from
the bottom of my heart.$K
$d0$c0IKE2|$s0King Phoenicis,$w3 I will guard
Reyson well.$w2$K$PWhen Crimea is retaken, $w2I will see
him safely returned to you.$w2$K
$s1I will take you $w2at your word.$K$PYour actions$w2 have created a bond of
trust between yourselves$w2 and the
hawk and heron clans.$K$PIf $w2you find yourself in a dire position,
you can call on me. No matter what,
I will fly to your aid.$K    $SE$R�㉺��b|$c1IKE2|$s1You were lucky to find your sister;$w2
shouldn't you stay by her side?$K
$c0RIEUSION|$s0Leanne understands what I do.$K
$s1$FSI see.$w4 In that case, welcome.$K
$s0$FSThank you.$K I swear on the honor of
my clan$w2 to do all I can to strengthen
your cause.$K$w5$d1
$s1$FS$c1TIBARN|$s1It's settled then.$w4 And you'll get
aid from me as well.$w4 Janaff!$K
$s0$FA$s3$FS$c3JANAFF|$s3Right here, Your Majesty!$K
$s1You'll go with the Crimean army $w2and
protect Reyson.$K
$s3Leave it to me!$K
$d3$s1You, too, Ulki.$w4 All right?$K
$c3VULCI|$s3Of course.$K$d3
$s0Tibarn!$w4 It's too much, I cannot
accept this.$K$PYou're already watching over Leanne
and my father as well.$K
$s1These past twenty years... $w5I know
what it's been like for you living in
Phoenicis.$K$PI'm only sorry I can't do more.$K
$s0Tibarn...$w4 $FcI thank you,$w4from
the bottom of my heart.$K
$d0$c0IKE2|$s0King Phoenicis,$w3 I will guard
Reyson well.$w2$K$PWhen Crimea is retaken, $w2I will see
him safely returned to you.$w2$K
$s1I will take you $w2at your word.$K$PYour actions$w2 have created a bond of
trust between yourselves$w2 and the
hawk and heron clans.$K$PIf $w2you find yourself in a dire position,
you can call on me. No matter what,
I will fly to your aid.$K  $SE$s1I appreciate the gesture, but
I am going to refuse.$K
$c0RIEUSION|$s0Why? Do you not believe$w3
I can be of use?$K
$s1It's not that.$K$PReyson, you've been through a lot.$w2
You're lucky to be alive and with your
sister.$w4 You should stay with her.$K
$s0Oh,$w3 yet...$K
$c3TIBARN|$s3Reyson.$w4 I, too, $w2think that
is for the best.$K$PYou and Leanne $w2should go be at the
side of your father, Lorazieh.$K
$s0I see...$K
$s1$FSI am grateful for your offer.$w4
It is a selfless act that does$w2
our morale much good.$K
$s3$FSI will take you $w2at your word.$K$PYour actions$w2 have created a bond of
trust between yourselves$w2 and the
hawk and heron clans.$K$PIf $w2you find yourself in a dire position,
you can call on me. No matter what,
I will fly to your aid.$K$d3
$s0At the very least, please accept this.$K
$s1What is it?$K
$s0A clan treasure.$w4 It may one day prove
useful to you.$K
$s1$FSUnderstood.$w4 Thank you.$K
$s0...Farewell.$K$d0    $SE$R�㉺��b|$c1IKE2|$s1I appreciate the gesture, but
I am going to refuse.$K
$c0RIEUSION|$s0Why? Do you not believe$w3
I can be of use?$K
$s1No, no...$w3 It's not that.$K$PReyson, you've been through a lot.$w2
You're lucky to be alive and with your
sister.$w4 You should stay with her.$K
$s0Oh,$w3 yet...$K
$c3TIBARN|$s3Reyson.$w4 I, too, $w2think that
is for the best.$K$PYou and Leanne $w2should go be at the
side of your father, Lorazieh.$K
$s0I see...$K
$s1$FSI am grateful for your offer.$w4
It is a selfless act that does$w2
our morale much good.$K
$s3$FSYour actions$w2 have created a bond of
trust between yourselves$w2 and the
hawk and heron clans.$K$PIf $w2you find yourself in a dire position,
you can call on me. No matter what,
I will fly to your aid.$K$d3
$s0At the very least, please accept this.$K
$s1What is it?$K
$s0A clan treasure.$w4 It may one day prove
useful to you.$K
$s1$FSUnderstood.$w4 Thank you.$K
$s0...Farewell.$K$d0    $R�㉺��b|$s0$FS$c0ERINCIA|$s0We gained a strong ally $w2where we
had not thought to look for one,
didn't we?$K
$s1$FS$c1IKE2|$s1Yes.$w4 Beorc and laguz...$K$PBeast tribe and bird tribe...$w2
There's no difference between us.$w4
We finally understand one another.$K
$s0Yes,$w4 I think you're right.$K
$s1$FANow, let's really get started!$w4
Everyone, $w2move out!$K  $R�w�i��b|$B�R��-��|$<$F1$FS$F1$FCL_NAESALA|$F4$FCL_KAYACCHE|$F4$PIt appears the Crimean army has arrived.
It's time to put our plan into action.$K
$F1$PThe main body of the Kilvas army$w2
will wait atop the western summit.$K$PA small unit will remain here $w2and
cooperate with you.$w4 This is correct,
is it not?$K
$F4$PMm, $w2it is.$K  $R�w�i��b|$B�R��-��|$<$F1$FCL_KAYACCHE|$F4$FCL_DAYNE2|$F4$PWhat could His Majesty $w2be thinking?$K$PWhy does Daein ally herself $w2with
some backwater sub-human nation?$K
$F1$P...I don't know.$w4 There's no way we
can expect to $w2understand the
supreme thoughts of the king.$K$PAll we can do $w2is perform the tasks
set before us by His Highness.$w4
That is everything.$K
$F4$PYes, of course!$K
$F1$PThe Crimean army $w2has no idea we're
aware of their every move.$K$PBah! $w2What vermin...$w4
What does that untrained group of
vagabonds$w3 think they can do?$K$PI don't care how talented he is.$w4 Their
commander is nothing more than a young
mercenary $w2with delusions of grandeur.$K$PWe've nothing to fear.$K
$F4$PWe'll show them $w2what real war is like!$K$PAnd...$w4the Kilvas ravens? How should
we deal with them?$K
$F1$P$FSThose sub-human freaks! $w2Let's use them
as bait.$w4 We can sacrifice them $w2and
reduce our own human casualties.$K
$F4$P$FSA fantastic idea!$K
$F1$PMake sure that the men$w2 are thoroughly
instructed.$K
$F4$P$FAYes, sir!$K$F4$FD   $R�㉺��b|$c0KAYACCHE|$s0You there! Halt!$w4
Mmm...you're an unfamiliar face.$K
$c3CHINON|$s3You'll know it soon enough.$K
$c1DAYNE3|$s1Y-you filthy piece of offal! You will
bow your head to a superior officer!$K
$s3...$K$d3
$s0He's got $w2a lot of nerve, hasn't he?$w4
Is he one of yours?$K
$s1Yes, sir!$w4 He's a new recruit who was
only assigned to me today.$K$PPlease accept my apologies for his
lack of any training or manners
whatsoever.$K
$s0If he's good, I can overlook almost
any character flaw.$K$PGo and kill as many Crimeans as you
can!$w2 Help my name be remembered
with honor and glory.$K$d0
$s1Yes, sir!$K$d1$w6
$c1CHINON|$s1...Pah.$K  $R�㉺��b|$c0KAYACCHE|$s0Come to me, $w2dregs of Crimea!$w4
I will teach what it means$w4 to
oppose the might of Daein.$K  $R�㉺��b|$c0JANAFF|$s0Hey, hey! What are those stupid crows
doing here?$K $R�㉺��b|$c3VULCI|$s3They're siding with Daein?$w2
Unbelievable!$K    $R�㉺��b|$c1RIEUSION|$s1Ravens!$w4 They betray not only me,$w3 but
all laguz!$w4 Naesala, you dastard...$K    $R�㉺��b|$c1MIST|$s1Shi-$w2Shinon?$w3 Ohmigosh...
Why $w2are you with the Daein army?!$K
$c0CHINON|$s0...Tsk.$w3 None of your business, kid.$K
$s1But that's...$w3 Oh, what should I do?$w4
You used to be one of us.$w3
I can't fight you!$K
$s0Stop whining.$w4 Didn't you ever think
what it means $w2to be a mercenary?$w3
We're enemies, kid. Get it?$K$PI'm ready to fight when you are.$w2
So what's it going to be?$K
$s1...Um...$K
$s0...Yeah?$K
$s1No!$w4 I won't fight you!$K
$s0Gah!$w3 What ARE you going
to do then?$K
$s1Come back to the Greil Mercenaries!$K
$s0What?$K
$s1If you won't do that, then come work
for the Crimean army!$w3 Please?$K
$s0Don't be stupid.$w4 Either way, Ike's
in charge, right?$K
$s1Yes, $w2but I don't--$K
$s0I won't work for him. $w2Get it?$K$PWe used to be friends,$w3 so I'm going
to let you go. $w2Now get your$w2
naive little butt out of here!$K
$s1Shinon... Sniff...sniff...Wh-wh-why...?
Sniff... Whaaaaaaaaa!$K
$s0Crying's not going to help.$w4 Look,$w2
it doesn't matter who you send to
talk to me. My answer's the same.$K
$s1Even Rolf?$K
$s0...Yeah. Even Rolf.$w4 Get out of here.$w2
The next time I see you, $w2I'll stick
an arrow in you.$w3 Count on it.$K  $R�㉺��b|$c1LOFA|$s1Shinon?$K
$c0CHINON|$s0Rolf...$K
$s1$FSShinon! It is you!$K
$s0$FSLook at you. $w2You've grown so much...$w4
You actually look like an archer.$K
$s1Really?$w3 Ha ha!$K
$s0You always did have what it takes.$K$PIt's just like I told you--$w4you train the
right way, $w2and you'll surpass both
your brothers.$K
$s1I had a good teacher!$K
$s0Yeah, you did.$w4 You...haven't told
anyone else about that, have you?$K
$s1Nope.$w3 Never said a word.$w4
I $w2keep my promises.$K
$s0Good man.$K
$s1Ha ha ha! $w5Um...Shinon?$K
$s0What?$K
$s1$FAAre you...$w3with the enemy?$K
$s0Yep.$K$w6
$s1...Sniff...$w2sniff...$K
$s0$FAStop that.$w4 I told you things like
this happen. $w2Did you forget?$K
$s1...But...$w3it's...not...$w4
It's not...$w2fair...$w3 Sniff...$K
$s0Ready your bow.$w3 It's time for
the pupil to face his master.$K $R�㉺��b|$c1KILROY|$s1Shinon!$K
$c0CHINON|$s0...Oh, Rhys.$w4 Great.$w3 I can't believe
I've run into you.$K
$s1$FSIt is great, isn't it?$w3 Oh, it's good
to have you back.$K$PWhen you left us, $w2I was really worried
about what would happen, but--$K
$s0Hey, Rhys? $w2Shut up.$K$PIn case you hadn't noticed...$w2
we're enemies out here.$K
$s1$FAWhat? You can't... $w2You're not serious,
are you?$w4$K
$s0You honestly never thought this
could happen?$w4 You're beyond good
natured.$w2 You're a fool.$K
$s1$FSShinon...$w3 What are you saying?$w4
You've always been gruff, but...$w3
$FAAre you serious?$K
$s0$FcIt's not like this is the first time
I've called you out.$K$PYou've never considered that people
may not like you,$w2 have you?$K$Fd$PKnow what? $w2We were companions
once,$w3 but if I'm getting paid, I'll
gladly put an arrow through your eye.$K
$s1Shinon... Is there something you can't
tell us that's forcing you to do this?$K$PAre you protecting someone?$w3
Has someone you love been taken
hostage? $w2If so, we could--$K
$s0No! $w2There's nothing!$w4 Nothing
but the right price, at least...$w3
You're overestimating me.$K$PGet going, pretty boy.$w3 Stick
around any longer, and I'll start
earning my pay with you!$K   $R�㉺��b|$c0KAYACCHE|$s0And now you will realize the true
power $w2of Daein!$K    $R�㉺��b|$c0KAYACCHE|$s0You fools... $w2It must be good fortune
that has brought you this far...$K$PBut you'll need more than luck to get
over this wall.$K   $R�㉺��b|$c0KAYACCHE|$s0You vexsome beasts!$w2
Our country has a long history of
conflict with your homeland of Gallia.$K$PThe moment when we put an end
to you once and for all$w2 rapidly
draws near.$K $R�㉺��b|$c0KAYACCHE|$s0Hawks of Phoenicis!$w4 Your beastly
cousins are said to outstrip you.$w4
Do you think flying can save you?$K  $R�㉺��b|$c0KAYACCHE|$s0A white...feather?$w4 Could it be?$w2
Do the extinct Serenes herons
fly still?$K$PThey're said to have special abilities...
but if they try to oppose us,$w2
they'll wish they'd stayed dead!$K   $R�㉺��b|$c0KAYACCHE|$s0I let them get...$w3too close...$w2$K $R�㉺��b|$c0MISTs|$s0That's enough, $w2Shinon!$w4
Why must friends fight?$w3
It's all too terrible...$K
$c1CHINON|$s1This is war. $w2It's all terrible.$w4
Tears mean nothing in the heat
of battle.$w4 Remember that.$K  $R�㉺��b|$c0LOFA2|$s0Shinon...$K
$s1$FS$c1CHINON|$s1Wipe that pathetic look off your face.$w4
Come on, ready your bow.$K$POn the battlefield, emotion ain't worth
spit.$w4 I taught you that, $w2didn't I?$K
$s0$FhUh...$w2huh...$w3
Uncle Shinon...$K    $R�㉺��b|$c0CHINON|$s0Heh.$w4 I always knew it would come
to this, $w2Ike.$K
$c1IKE2|$s1Shinon...$K
$s0Watch yourself!$K  $R�㉺��b|$c0TIAMAT|$s0Shinon! $w2You...$w4
You're with Daein of all things?$K
$s1$FS$c1CHINON|$s1Long time, no see, $w2Captain.$w4
You know, $w2we didn't always see
eye to eye, but...$K$PI never once $w2minded taking
orders from you.$K
$s0To tell the truth,$w3 I really didn't mind
having to listen to your endless
complaints and insults, either.$K$PHold nothing back.$w5 Let's pay
each other...the proper respect.$K
$s1Yes, I think that's best.$w5
So in the end, we finally
agree on something, eh?$K  $R�㉺��b|$s1$FS$c1CHINON|$s1Well, well, $w2lookee here.$w4
The little boy plays soldier...
How sweet.$K$PYour job's always been just to use
that big brain of yours.$K$PThat's why you spend your time$w2
hiding behind Ike's apron.$w4
Isn't it, $w2Soren?$K
$c0SENERIO|$s0Shinon. $w2You always were dumb as a
gnat, but...$w5 A first-class archer.$w3
I'll give you that.$K$PBut with$w3 the power I now possess,$w3
it's probably in your best interest$w4
not to presume to know my strength.$K
$s1Hah!$w3 $FAYou're still a snotty
little whelp, aren't you? Get
ready to die, little man.$K   $R�㉺��b|$c0OSCAR|$s0Shinon?!$w3 Why are you with Daein?$w4
Someone with your skills could have
found work$w2 with Begnion's army.$K$PSo, $w2why this?$K
$s1$FS$s1$c1CHINON|$s1Ha!$w4 Why would I want to go to
work $w2for a bunch of stiff-necked
bluestockings?$K$PI'm a commoner. No matter how good
I am,$w3 I would never rise above a
middling commission.$K$PIt's different in Daein. $w5If you're
a skilled fighter, $w2you can rise
all the way to the top.$K
$s0Is getting promoted $w2really
that important?$K
$s1It's everything.$K$PAll right,$w4 enough with the
pleasantries.$w5
You ready to go?$K
$s0Oh, Shinon...$K    $R�㉺��b|$c0BOLE|$s0Shinon!$w4 I couldn't care less$w2
who you decide to work for...
Heck, I'd hoped you were dead!$K$PBut even so, $w2Daein? $w2You
couldn't find anything better than this?$w5
What were you thinking?$K
$c1CHINON|$s1Haven't changed a bit, have you?$w2
You're still $w2a mouthy piece of work.$K$FS$PListen up!$w4 Daein's a great place
to work right now.$K$PThe pay's great,$w3 and strength at arms
is the only thing that determines class
standing. $w5You want to join me?$K
$s0Don't be ridiculous!$K
$s1Well then, $w2only one thing to do.$w5
Out of the goodness of my heart,$w2
I'll teach you how adults fight.$K$PAnd a far as payment goes...$w2
I'll take your life.$w4
How's that sound?$K
$s0Keep talking, Shinon! $w5I'm gonna beat
the obnoxious$w3 clean out of you.$K  $R�㉺��b|$c0GATRIE|$s0Shi-$w2Shinon?$w4 SHINON?!$w2
Oh, this can't be happening!$K$PI mean, fighting you...$w3
That's $w2going to be tough.$K
$s1$FS$c1CHINON|$s1Come on, Gatrie. $w2You can't
be worried about me forever.$K$PYou're a mercenary. $w2All you need
to do is worry about your own skin.$w4
You got it?$K
$s0Well,$w3 yeah...$w4$FS
Heh heh heh$w3...$w5 Ahh...$FA
Still...$w4this will be a sad day...$K   $R�㉺��b|$c0KILROY|$s0Cut it out, $w2Shinon!$w4
Commander Greil would have
never wanted this!$K
$c1CHINON|$s1Shut your mouth, Rhys!$w4
I don't have the patience for
one of your little sermons.$K$PBesides, you should be worried about
your own life instead of mine.$K
$s0Shinon...$K  $R�㉺��b|$c1CHINON|$s1...My arrows$w4 will find you
no matter where you run.$K    $R�㉺��b|$c0CHINON|$s0$FhUnh...$w3......$w4$FS
Messed$w4 that up, didn't I...$w5
Man...what a...$w4lousy life...$w3that was...$K  $R�㉺��b|$c0CHINON|$s0$FhUnnhh...$w3
Curses...$K
$c1IKE2|$s1Don't move. $w2You'll tear the
wound wide open.$K
$s0What're you$w3 planning?$Fc
D-$w2do it...$w3now...
Finish me.$K
$s1...$K
$s0$FS...Ha...$w4$Fc Idiot...$K$d0  $R�㉺��b|$c0CHINON|$s0$FhUnnnh$w3...
Curses...$K
$c1LOFA2|$s1Shinon!$w3 Uncle Shinon!
...Sniff...N-no...$K
$s0I told you...$w3 No crying...$K
$s1...$K
$s0$FS$Fc...This is...$w2for the best...$w4
I...$w3can$w4...$K
$s1$FhUncle$w3 Shinon...$K$PNu,$w4 nuh, $w2no...$w3sniff...$K   $R�w�i��b|$B�R��-��|$<$F1$FS$F1$FCL_CHINON|$F1$PCrud, I lost...$w4 This was a plum chance$w2
for me to get a leg up in this world, too.$K$P$F3$FCL_IKE2|Shinon.$K
$F1$PHa!$w3 And I can't believe that $w2the one
who defeats me is little lord Ikie.$w4
Looks like $w2I've lost my edge.$K$PI'm ready, boy.$w3 Go on.$w2
Finish what you started.$K
$F3$PCome back to the company.$K
$F1$PI don't think so.$K
$F3$PYou've never liked me. As far back
as I can remember, you have
never liked me.$K
$F1$PThat's right. $w2Still don't.$K
$F3$PYou...$w2 You called me a weakling.$w2
Said I was nothing without the
help of my father.$K$PThat's what you said, $w2right?
That's why you hated me.$K
$F1$P...Sounds like me.$K
$F3$PDon't you get it? I just beat you.$w4
So your reasons don't hold water
anymore,$w5 do they?$K
$F1$P$FAPah!$w3 It's enough you beat me,
now you gotta talk me to death?$K
$F3$PI'll say it once more.$w4
Come back to the company.$K$PI acknowledge your abilities.$w4
As commander, I want you with us.$K
$F1$P...$K$PLet's have another go around.$w2
I win, and I'm commander.$w5
Agreed?$K
$F3$PI win, and you fall in line.$w5
Agreed?$K
$F1$P$FSDon't worry, boy.
I'll make it quick.$K
$F3$P$FSLet's go.$K
$=0500   $R�w�i��b|$B���-��|$<$F0$FCL_BEGNION2|$F3$FCL_IKE2|$F0$PGeneral!$w4 We've seized control of the
surrounding area, and the remaining Daein
troops are retreating...$w4 General?$K
$F3$POh, $w2right.$w4 Understood.$K
$F0$PI $w2beg your leave.$K$F0$FD
$F3$PGeneral, $w2eh?$w3 Weird.$K
$F1$FS$F1$FCL_NASIR|$F1$PYou know, $w2you never look relaxed.$K
$F3$PNasir. What's going on?$w4 We haven't seen
much of you $w2lately.$K
$F1$PI've $w2been a bit busy.$K$PIn order to leave Begnion, $w2I had to sell
my ship and$w2 dismiss the crew...$w4
There was a lot to take care of.$K
$F3$PIs that so?$w4 Heh. It looks like you've been
caught up $w2in our struggle after all.$K$PAre you all right with that?$w4 I mean,$w2
I know you've got a lot of your own
matters to handle.$K
$F1$PIt's not like I've abandoned my own
interests$w2 to join up with the
Crimean army.$K$PFor me, $w2I've judged that there's value
in traveling with you.$w4 So, don't
worry about it overly much.$K
$F3$PIf you say so.$w4 $FSYou're a fairly knowledgable
fellow,$w4 so it's nice having you around.$K
$F1$PHa! $w2I think that's mutual.$K$PNow then, $w2I've got some good news.$K
$F3$P$FAWhat is it?$K
$F1$P$FASenior officials in Gallia $w2are
moving to action.$K
Until now, they've been content to
take a defensive stance and wait
it out, but...$K$PIt appears this neverending stalemate$w2
has exhausted their patience.$K$P$FSIke, $w2this victory here today$w4 was a very
important thing.$K$PIt may prove to be a decisive first step
in breaking Daein's power.$K$PNews of it will spread like wildfire over
the entire continent$w4 and give countries
confidence to speak out against Daein.$K$PWith Crimea as a rallying point, $w2Gallia may
well be moved to join this war.$K$PYou just need to keep winning.$w4 If you
can do that, $w2the road will open
before you.$K
$F3$PHistory will be made...$w4
Could Daein truly fall $w2at our hands?$K
Can I make that happen? $w2Me?$K
$F1$PUse what you've been given, and great
things will happen.$K$PYou have it in you to lead, $w2Ike.$w4
For now, $w2it's merely one portion of the bird
tribes, but...$w4your relationship is established.$K$PIt's because $w2you resolved to gain their
trust, and then made it happen.$K
$F3$PIt's all due to my father...$K$PIf $w2my actions prove to be the right ones,
it will be due to the way $w2my father
raised me.$K$P"If you treat others in good faith,$w2
they will follow you of their own
volition."$w4 That's what he taught me.$K
$F1$PHe was a magnificent man, wasn't he?$K
$F3$PWhen I was younger, $w2I wanted nothing
more than to be as strong as my father.$w4
And then I wanted to surpass him...$K$PNow,$w3 that is a goal I'll never achieve.$K
$F1$P$FA...$K
$=1000    $R�w�i��b|$B����-��|$<$F1$FCL_NAESALA|$F4$FCL_CROW|$F1$PWhat's that?$w4 The border's been breached?$K
$F4$PEveryone was defeated. $w2Not only the Daein
troops, but our brigade as well.$w3
Cut down like wheat in a field.$K
$F1$P$FSHuh! Well, that was impressively done.$w4
Er, for a band of sellswords, that is.$K$P$FAThere's nothing else to do.$w2 Send a
message to the Daein command and tell
them the enemy is stronger than expected.$K
$F4$PAt once.$K$F4$FD
$F1$PWait! $w2Hold a moment.$K
$F4$FCL_CROW|$F4$PYes?$K
$F1$PSend a Daein human instead.$w4
I don't care which one.$w2
Just don't use any of our troops.$K
$F4$PBut $w2a wingless human will take such a
long time to--$K
$F1$PGeneral Petrine commands the next front.$w2
She's a very...temperamental woman...
But go if you like!$K$PTell her that the Kilvas ravens have been
defeated...$w2 She'll roast you like a
chicken and use your bones for stock!$K
$F4$PUn-$w2understood!
I will find a human!$K
$=1000   $R�w�i��b|$B�V��-��-1|$<$F1$FCL_NASIR|$F1$PWho's there?$K
$F4$FCL_SENERIO|$F4$P...$K
$F1$PSoren?$w4 What are you $w2doing here?$K
$F4$PWhat are you planning?$K
$F1$P$FSWhere did that come from?$w4
I've no idea what you're talking about.$K
$F4$PDon't play dumb with me. We're past that.$K$PGallia's decision to join in this war$w2
was based on some new information
they received,$w4 wasn't it?$K
$F1$P$FA...$K
$F4$PCat got your tongue? Fine. I'll tell you
what you've been doing here...$K$PYou were to deliver Princess Crimea$w2
to Begnion $w2to see if she could
garner any support for her cause.$K$PAnd--$w2regardless of whether she got
that assistance or not--$w2to judge if
she was worthy of laguz support.$K$PAm I wrong?$K$P$F1$P$FSIf you've figured all of this out,$w2
why remain silent?$K
$F4$PBecause your actions $w2were beneficial
to Princess Crimea.$K$PI determined that even if left to your
own devices, $w2you would not harm
the princess.$K
$F1$PIt sounds like you don't think
that's the case anymore.$K
$F4$PYou accomplished both missions,$w2
but you've come back anyway.$w4
To what end?$K
$F1$PI don't have to explain myself to you.$K
$F4$PThat's true only $w2until I reveal
your purpose to Ike.$K
$F1$PEveryone has a secret or two that he
wants to bury somewhere deep.$w3
Including you...$w5Soren.$K
$F4$P...I don't know what you mean.$K
$F1$POh, I trust that we understand each other.$K$PThe army rises early tomorrow.$w4
I suggest we turn in.$K
$F4$PThe enemy knew we were coming today.$K
$F1$PAnd you think I'm responsible?$K
$F4$PYes, I do.$K
$F1$PMy, oh, my...$w4 You really ARE suspicious,
aren't you?$w4 Good night, Soren.$K$F1$FD
$F4$P...$K
$=1500  $R�w�i��b|$B�V���l�p-��|$<$F0$FCL_BEGNION2|$F3$FCL_IKE2|$F0$PGeneral Ike.$w4 All troops $w2are ready
to move out.$K
$F3$PAll right. $w2Can you have them wait?$K
$F0$PDo you want them $w2to fall out$w3
and wait in their tents?$K
Or would you rather$w3 they form up$w2
and $w2stand at attention?$K
$F3$PGo ahead and have them stand down.$w4
I'll call them $w2when I'm ready.$K
$F0$PYes, sir!$K$F0$FD
$F3$P...$K$w4
$F0$FCL_BEGNION1|$F0$PBegging your pardon, sir!$w4 All troops
have been ordered to stand down.$K$PHowever, General Tanith requests her orders.$w3
Are her pegasus knights $w2to stand
down as well?$K
$F3$PAm I$w3 supposed to decide that, too?$K
$F0$PGeneral Ike... $w2You've been given
command of the entire army, sir.$K
We will not move $w2without your orders, sir.$K
$F3$PGeneral Tanith's troops...$w3are to follow
General Tanith's orders.$K
$F0$PUnderstood, sir!$K$PGeneral Tanith's pegasus knights$w3
will not be deployed unless there is a
request$w2 for reinforcements.$K
Those are the orders of General Tanith.$K$PBy your leave, sir!$K$F0$FD
$F3$P$Fh...$K  $R�w�i��b|$B�V��-��-1|$<$F1$FCL_TANIS|$F3$FCL_IKE2|$F3$PTanith, do you have a moment?$K
$F1$PGeneral Ike.$w4 What is it? Is there a
problem?$K
$F3$PI thought you might be able to
provide me with some information.$K
$F1$PYes?$K
$F3$PWhat can you tell me about $w2King Daein?
I'd like to know something of him
before I have to face him in battle.$K
$F1$PTruth be told, I've never fought him, either.
I cannot give you any specifics, but I
will tell you what little I do know.$K
$F3$PPlease.$w4 Whatever you can tell me$w2
would be appreciated.$K
$F1$PAshnard's coronation,$w3 let me see...$w2
Yes, it was eighteen years ago.$K$PYou see, a plague had struck the capital,
spreading out to affect the surrounding
region of Nevassa and beyond.$K$PAshnard was crowned the year after
that great tragedy finally subsided.$K$PIn the entire history of Tellius, no calamity
has claimed the lives of so many beorc
and laguz--not since the great flood.$K$PTwo years before, it struck Begnion, and
the entire population of Serenes was
nearly obliterated.$K$PThe year after that, close to a
thousand beorc--nobles and peasants
alike--perished in Daein.$K
$F3$PNobles, you say? So the royal family
fell victim to this plague as well?$K
$F1$PYes. The reigning king and queen $w2and some
twenty or so princes and princesses fell ill.$w3
And everyone who fell ill perished.$K$PFor a time, the people despaired of losing
the entire royal bloodline of Daein. It
seemed that none would survive.$K
$F3$PAnd yet$w3 Ashnard survived.$K
$F1$PHe did.$w4 It is quite interesting, in a sense.
You see, his name was never mentioned
in any talk of succession before that time.$K$PHe was of such a distant bloodline that
he was unlikely to be king. In another place
though, his name was already well known.$K
$F3$PWhere was that?$K
$F1$POn the battlefield.$w4 As you know, Daein
is home to many brave warriors.$K
At the time, then-prince Ashnard$w3 was
said to have been a match for an entire
troop of pegasus knights.$K$PBegnion and Daein$w3 both keep close
watch over their borders,$w3 and their
patrols fought in many skirmishes.$K$PAlthough there was no war to speak of,
these land disputes did end with Daein
claiming a small portion of Begnion soil.$K$PIt would be no exaggeration $w2to say
this was soley due to the strength of
one man:$w3 Ashnard.$K
$F3$P...$K
$F1$PForgive me. I have spoken longer than I
intended.$K$PIt's about time we get back to the
business of marching preparations.$K
$F3$PNo, thank you for telling me so much.$w4
If we have another chance, $w2please
share more of your stories.$K
$F1$P$FSUnderstood.$K   $R�w�i��b|$B�V��-��-1|$<$F1$FCL_IKE|$F3$FS$F3$FCL_TOPUCK|$F4$FCL_MWARIM|$F3$PIke!$w4 Which troop should we fall in with?$w4
We have received no orders yet.$K
$F1$PTormod,$w3 Muarim,$w4 I know I've
asked you many times, but...$w4
Are you sure you want to be here?$K
$F3$P$FAYou keep asking that!$w3$Fh
Maybe you don't want us here.$w4
Is that it?$w3 I don't know what to think!$K
$F3$P$Fd$F1$PNo,$w3 it's not that at all.$w4
To be honest,$w3 the battle ahead is going
to be hard...$w3 It looks bleak.$K$PI'd rather that those without direct ties
to Crimea$w3 not get involved.$K
$F3$P$FSA bleak battle? $w2What about trying to free
all the slaves in Begnion?$w3 Now THOSE
were bleak battles.$K
Bleak battles are our specialty.$w3
Right, Muarim?$K
$F4$P$FSYes, you are.$K$PYet...$w3thanks to Ike's $w2time in Begnion,$w3
things have changed completely.$K
$F1$PThat's right.$w3 The apostle has promised to
press her investigation$w3 until there's not a
single laguz slave left in the entire nation.$K$PSo, $w2there's no reason for you two to
continue fighting, is there?$w4 You don't
owe me anything--$K
$F3$P$FAWe're going to fight with you, Ike.$w4
We want to help!$K
$F4$PIt is our right to join you in this.$w5
Just as it is your right$w3 to refuse us.$K
$F1$PTo be perfectly frank,$w3 $FSI would be
willing to beg $w2to get you to join us.$w4
Both of you, $w2all right?$K
$F4$PAll right.$K
$F3$P$FSHa ha!$w4 You can count on us!$K   $R�w�i��b|$B�V��-��-1|$<$F1$FCL_SENERIO|$F3$FCL_IKE|$F1$PIke,$w3 I'd like to report the results
of our last battle.$K$N$UB$H   $F3$P$FcI see.$K$P$UB$H $F1$P$FSThere were no deaths $w2and no injuries
beyond our capabilities to heal.$w4
Everyone performed exceedingly well.$K$P$UB$H   $F1$PThat is all.$w4 With your leave,$w2
I will excuse myself.$K      M|      Y�   	  \�     R�   %  ^�   4  P�   B  Wt   P  U,   ^  S4   l  Q�   z  _�   �  M�   �  Np   �  O<   �  O�   �  P�   �  `�   �  ad   �  `    �  b|   �  g<  	  q�    u�  !  @   -  ?�  ;      I  D  W  @H  e  �  p  <  }  �  �  T  �  t  �  �  �  l  �  �  �  ,  �  �  �  |  �  �L    �x    8    �  )  X  5  7,  A  8�  M  <�  [  ?8  i  �  u  �  �   t  �  $4  �  $8  �  5�  �  $p  �  )T  �  $X  �  .H    2    $h  %  �  4  ��  E  �0  T  ��  c  H�  t  Ed  �  @�  �MS_19_BT MS_19_BT_2_BO MS_19_BT_2_GA MS_19_BT_2_IKE MS_19_BT_2_KI MS_19_BT_2_MI MS_19_BT_2_OS MS_19_BT_2_SE MS_19_BT_2_TI MS_19_BT_2_YO MS_19_BT_ETC MS_19_BT_IKE MS_19_BT_R1 MS_19_BT_R2 MS_19_BT_RI MS_19_DIE MS_19_DIE_Ike MS_19_DIE_Jofa MS_19_DIE_sinon MS_19_ED_00 MS_19_ED_01 MS_19_ED_02 MS_19_ED_03 MS_19_EV_00_u MS_19_EV_00_y MS_19_EV_C_01 MS_19_EV_C_02 MS_19_EV_r MS_19_GMAP_1 MS_19_GMAP_10 MS_19_GMAP_2 MS_19_GMAP_3 MS_19_GMAP_4 MS_19_GMAP_5 MS_19_GMAP_6 MS_19_GMAP_7 MS_19_GMAP_8 MS_19_GMAP_9 MS_19_INFO_01 MS_19_INFO_02 MS_19_INFO_03 MS_19_OP_01 MS_19_OP_03 MS_19_OP_04 MS_19_OP_06 MS_19_OP_06_2 MS_19_OP_06_s MS_19_OP_07 MS_19_OP_EV_00_A MS_19_OP_EV_00_B MS_19_OP_EV_01 MS_19_OP_EV_01_DEL MS_19_OP_EV_01_SKIP MS_19_OP_EV_02 MS_19_OP_EV_A MS_19_OP_EV_A0 MS_19_OP_EV_AA MS_19_OP_EV_B MS_19_OP_EV_B0 MS_19_OP_EV_BB MS_19_REPO_BEGIN MS_19_REPO_DIE MS_19_REPO_END MS_19_REPO_NODIE MS_19_TK_CHINON_KILROY MS_19_TK_CHINON_LOFA MS_19_TK_CHINON_MIST 