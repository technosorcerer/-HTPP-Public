  �W  ��       S                $R�w�i��b|$B�X-�`-��|$<$F1$FS$F1$FCL_LAY2|$F3$FCL_IKE|$F1$PWell, we're here!$w4
Welcome to Toha, $w2Crimea's
westernmost port city.$K
$F3$PWhat's with this place?$w4 The people are
going about their business. Why aren't they
worried about Daein? About the war?$w3$K
$F1$P$FAIt's because this area is fairly isolated.$w3
Daein's army hasn't come this far,$w4
and so life goes on as before.$K$PDaein's plan is to seize the capital, $w2then
slowly$w3 and steadily $w2expand its sphere of
influence $w2until it controls everything.$K
$F3$PSurely these people have some idea
of what's happening.$K$F1$FD
$F1$FCL_SENERIO|$PIgnorance is a form of $w2bliss, is it not?$w4
These people don't know what it's like
to lose a war.$w4 They don't want to know.$K$PCrimea as a nation has always been
blessed by peace.$w5$K$PPerhaps this is due to the temperament of
its rulers, $w2but the country hasn't seen
serious warfare for centuries.$K$PWhile minor skirmishes$w4 with the kingdom of
Daein have been legion,$w2 only the eastern
borderlands have taken damage.$K
$F3$PAnd yet $w2even I know this$w2
peace will not last.$K$PWhen we met Daein forces on our scouting
mission,$w4 they attacked us $w2merely for
being within the Crimean border.$K
$F1$PHumans are shameless creatures that$w4
carelessly ignore any misfortune which
does not befall them directly.$K$PThey can$MC--$MD$w2and often do$MC--$MD$w2turn a blind eye to
all manner of wickedness$w3 so long as it
does not touch them or their kin.$K$PThey will bow their heads, $w2condemning
those victims for bringing calamity
upon themselves,$K$Pand then they will cast their eyes toward
heaven in thanks$w2 while their neighbors
lay dying around them.$K
$F3$PBut the war is happening here.$w4
This is their home, not someone else's.$K
$F1$PWhen the Daein army darkens their
doorsteps,$w4 perhaps they will understand.$K$PWhen the peace they take for granted is
shattered, $w2and their sons and
daughters slaughtered in the streets$MC...$MD$K$PPerhaps then$w3 will they comprehend$w3 the
misfortunes they so long pretended not
to see. $FcI have no sympathy for them.$K$F1$FD
$F3$P$MC...$MD$K$P$F4$FS$F4$FCL_LAY2|$F4$PMy goodness,$w3 the nastier the truth,$w2
the blunter he gets$MC...$MD$K$PQuite a delightful $w2staff officer you
have there.$K
$F3$PHe, um$MC...$MD$w2he has an undeniable streak of
severity in him but$MC...$MD$w4but this?$w2
Something's bothering him, that's for sure.$K$P$F0$FCL_TIAMAT|$F0$PIt's to be expected.$w3 Even I'm a bit
shocked by this place.$w4 Can they truly
be as placid as they appear?$K$PSoren's a very empathetic young man.$w2
The emotions of this place$w4 may have
proven to be too much for him.$K
$F4$PIgnoring impending doom $w2because
you cannot prevent it$MC...$MD$w3 Fatalism is
by nature a disheartening beast.$K$P$FAWell, $w2for all those born with nothing,$w3
there are those born with everything.$K$PPerhaps those who never notice the
difference $w2are the ones we should envy.$K$P$F3$FD$F1$FCL_IKE|$F1$PWhat's that supposed to mean?$K
$F4$P$FSHuh? Oh, I was talking to myself.$w3
Pay me no mind.$K
$F1$PHmm$MC...$MD$K
$F4$PNow then, $w2I've got to see a man
about a ship.$K$PWhile I'm gone, $w2why don't you get
your supplies squared away?$K$PI'm sure that the journey ahead$w2
will require a lot of packing.$K
$F0$PRanulf, $w2I'll go with you.$K
$F4$PNo, no, $w1that's all right.$w4 You should
supervise the supply acquisition.$w4 You're
going to be at sea for months,$w4 you know?$K
$F0$PI know that, but$MC...$MD$K
$F1$PWhat is it, $w2Titania?$K
$F4$PShe's worried about me.$w4
She doesn't want to leave a solitary laguz$w2
wandering around a beorc city.$K
$F1$PBut $w2I thought Crimea and Gallia
were allied nations.$K$PWhy would a wandering laguz$w2
be cause for concern?$K
$F4$PWell,$w4 it shouldn't be, but$MC...$MD$K
$F0$PDo you remember what
King Caineghis told you?$K$PThe friendship between Crimea and Gallia$w2
exists only between the ruling classes.$K$PIt hasn't taken root in the minds of the
common citizenry at all.$K
$F4$PThat being said, $w2things have improved
quite a bit $w2since King Ramon
ascended to the throne.$K$PThe reports of hunts and such other
horrors have all but disappeared$MC...$MD$K$POh, don't worry! $w2I'll be fine!$w4 I've
got connections, see?$w4 It's not like I'll
be roaming the docks begging for passage.$K
$F1$PAll right then, $w2the job is yours.$w4
Please be careful.$K
$F4$PYou, too.$w4 Don't mess anything up!$K$F4$FD  $R�㉺��b|$c0IKE|$s0We should be leaving, but$MC...$MD$K
Looks like $w2everyone's going to be
a while, yet.$K
$c1ERINCIA|$s1My lord Ike, $w2are you ready to go?$K
$s0Me? $w2As long as I've got my sword,
I'm always ready.$K
$s1A sword? $w2That's it?$K
$s0If I've got my cape, I can sleep
just about anywhere.$K$PAnd as for food, well$MC...$MD$w2
Something always turns up.$K
$s1$FSHee hee!$w3 That's delightful.$K
$s0It is?$K
$s1Yes,$w3 very much so.
Tee hee hee!$K
$s0Princesses$MC...$MD$w2 I don't think I'll ever
understand them.$K  $R�㉺��b|$c0IKE|$s0What's going on?$w3 Why all
the excitement?$K
$c2ERINCIA|$s2My lord Ike!$w4 There's a crowd
gathering at the town entrance$MC...$MD$K
$s0That's$MC--$MD$K  $R�㉺��b|$c1DAYNE2|$s1Attention citizens!$w4 We've received
reports of Crimean army stragglers
hiding in this town!$K$PFrom this point forth, $w2the Daein army
will blockade all points of entry!$K$PNo one $w2comes or goes
without our leave!$K$PThe harbor is also closed!$w4
No ships will be allowed to sail!!$K$d1 $R�㉺��b|$c1TIAMAT|$s1Ike$MC...$MD$w4 Daein troops have$MC--$MD$K
$c0IKE|$s0I know.$w4 All we can do is move
toward the docks $w2and try not
to be discovered.$K
$s1Have you seen Ranulf?$K
$s0Not yet.$K
$d0$d1$c1IKE|$s1Wait, $w2here he comes now.$K$PRanulf!$w3 Over here.$K  $R�㉺��b|$c0LAY2|$s0Hoo! Things sure are heating up,
aren't they?$K
$c1IKE|$s1How are things on your end?$K
$s0Everything's set.$w4 All you
need to do $w2is sneak
down to the harbor.$K$PYou'll be met there $w2by a man
with a dusky pallor.$w3
His name is Nasir.$K$PNasir is a man you can trust.$w5 I've
explained your situation to him,$w2
and he's willing to help.$K$PIf you can reach his ship safely,$w2
he'll take care of everything
and deliver you to Begnion.$K
$s1Ranulf, $w2aren't you coming, too?$K
$s0I was planning on it, but$MC...$MD$w2Daein's
movements have me concerned. $w5I'll
stay behind $w2and see what's going on.$K    $R�㉺��b|$c1WOMAN1|$s1Oh, $w1I'm sorry!$FS$w3
I $w2wasn't watching where I
was going$MC...$MD$K
$s0$FS$c0LAY3|$s0No, $w2pardon me--
$Ub$H$s1$FAAh!$K$PEeeeeeek!$w4 Su-$w2sub-human!!$K$d1
$s0$FABlast!$K  $R�㉺��b|$c1MISTER1|$s1I-it's true!$w4 A sub-human!$w4
How dare you $w2come
prowling around here!$K   $R�㉺��b|$c0MAN1|$s0Beast!$w4 Ya stinking sub-humans
need to learn yer place!$w2
Human towns are too good for ya!$K   $R�㉺��b|$c1LADY1|$s1Eww! $w2It's so hairy!$w4
Go on! Scat!$K $R�㉺��b|$c0WOMAN1|$s0Get out of here!$w4 Monster!$K  $R�㉺��b|$c0IKE|$s0Dang!$K    $R�㉺��b|$c1IKE|$s1Mordecai!$K
$c0MORDY2|$s0Ike!$w4 We must leave!$K
$s1What? No!$w4 We have to help Ranulf$MC...$MD$K
$s0All of this noise$w4 will attract
the attention of the Daein troops.$K
$s1That's why we have to
hurry up and help$MC--$MD$K
$c2LETHE2|$s2He'll be fine!$w4
Leave him.$K
$s0Ranulf is strong.$w4 Even stronger
than me.$w4 It's all right.$K
$s1Ranulf has no intention of defending
himself! Look, he's not even
changing forms!$K$PI can't just stand by and watch
as he gets murdered!$K$d1
$s0Ike!$w2 Wait!$K
$s2$MC...$MD$w2Idiot human$MC...$MD$K  $R�㉺��b|$c1IKE|$s1Lethe!$K
$c0LETHE2|$s0Come on. Let's go.$K
$s1What? No!$w4 We have to help Ranulf!$K
$s0Do you see this crowd?$w4
The Daien soldiers will hear this
ruckus and come here.$K
$s1That's why have to
hurry up and help$MC--$MD$K
$s0He'll be fine!$w4
Leave him.$K
$s1Ranulf has no intention of defending
himself! Look, he's not even
changing forms!$K$PI can't just stand by and watch
as he gets murdered!$K$d1
$s0$MC...$MD$w2Idiot human$MC...$MD$K    $R�㉺��b|$c1IKE|$s1Mordecai!$K
$c0MORDY2|$s0Ike!$w4 We must leave!$K
$s1What? No!$w4 We have to help Ranulf$MC...$MD$K
$s0All of this noise$w4 will attract
the attention of the Daein troops.$K
$s1That's why we have to
hurry up and help$MC--$MD$K
$s0Ranulf is strong.$w4 Even stronger
than me.$w4 It's all right.$K
$s1Ranulf has no intention of defending
himself! Look, he's not even
changing forms!$K$PI can't just stand by and watch
as he gets murdered!$K$d1
$s0Ike!$w3 Wait!$K    $R�㉺��b|$c0IKE|$s0Stop!$w4 Get out of my way!$w3
Keep your hands off him!$K
$c1MAN2|$s1Who do ya think ya are?$w4
Why would a human want to
protect some sub-human?$K
$c3WOMAN1|$s3He's a friend to this monster!$w4
I saw them talking earlier!$K$d3
$s0What's that to you?$K
$d1$c1MAN1|$s1Hey, $w2the Crimean royals $w2had
sub-human companions, didn't they?$K$PMaybe $w2you're one of those
army guys$w3 the Daein
troops are searching for!$K
$d0$Ub$H$c0MISTER2|$s0You there!$w4 Daein soldier! Ho!$K$PThere are some suspicious
folk$w2 over here!$K    $R�㉺��b|$c1DAYNE2|$s1Huh?$w4 That way! $w2Hurry!$K   $R�㉺��b|$c0IKE|$s0Are you mad?! $w5Your king was$w4
murdered by Daein!$K$PAnd now you're going to
cooperate with them?$K$d0
$c1MISTER2|$s1Well, um$MC...$MD$K$d1
$c3MAN2|$s3I heard the king $w2was teamin' up
with those sub-humans!$w4
That's what got him killed!$K$d3
$c1LADY1|$s1Yeah! That's right!$w4 If we need allies,$w2
I'll take flesh-and-blood Daein humans$w2
over some fanged sub-human freak!$K$d1
$c3MAN1|$s3Yeah! $w2Yeah!$w4 At least we
know what we're getting!
Trust your own kind!$K$d3
$c0IKEa|$s0You people are insane!$K  $R�㉺��b|$c0SELFDEFENCE|$s0Where's the sub-human everyone's
screaming about?$K
$c1GRANDPA|$s1Huzzah!$w4 The Toha vigilantes are here!$K$PGrab those guys and turn them over
to the Daein army!$w3 That will prove our
allegiance and gain our village favor!$K
$s0$FSHar har! $w2If you want sub-humans
hunted down,$w4 I'm your man!$K   $R�㉺��b|$c1LAY3|$s1Ike!$K
$c0IKE|$s0Ranulf! $w2Are you all right?$K
$s1Why did you come back?$K
$s0Because some fool was going to
lay here$w2 and get beaten to
death instead of defending himself!$K
$s1Ah, Ike.$w3 What would you have me do?$w4
Gallia and Crimea have formed
an alliance.$K$PI cannot jeopardize that by harming
these people, no matter what ill they
may bear me.$K
$s0Even if none of them care two figs
for their own country?$K
$s1$FSEven if. $w2They're citizens
of Crimea, after all.$K
$s0Well, I'm not Gallian, $w2so there's no
reason for me to hold anything back!$K
$s1$FAIke! Listen to me! $w2They think that you
and I are allies!$w4 If you attack, it's no
different than if I do so myself! So...$K
$s0Let me guess...$w5you're telling me to
avoid the Daein pursuit, $w4leave the
town vigilantes alone,$K$Pget to the docks as soon as possible,$w2
find a man named Nasir $w2and get
everyone on his boat. $w4Is that it?$K
$s1$FSExactly! $w2I don't care what anyone
else says, I think you're pretty bright!$K
$s0All right, I'll play along.$w5 But mark my
words,$w4 if they attack, heads will roll!$K$d0
$s1$FAWhat? $w2Hey!$w4
That's not going to do us any good!$K $R�㉺��b|$c1IKE|$s1Titania!$w3 Soren!$w5
Get everyone together!$w4
We're getting out of here!$K   $R�㉺��b|$c0MAKKOYAR|$s0Listen to me!$w4 Do not let a single
Crimean soldier escape our grasp.$K$PSweep the entire town!$w2
Arrest anyone suspicious!$K
$c1DAYNE1|$s1General Mackoya!$K$PSir, there's a group of vigilantes$w2
who want to help us.$w4
What shall I tell them?$K
$s0Hmm$MC...$MD$w3 Very well.$w4
Let them do as they please.$K
$s1Yes, sir!$K$d1$w5
$c1NASIR|$s1Pardon me,$w3 are you the commander
of these forces?$K
$s0I am. $w2And who are you?$K
$s1I'm captain of the boat you see
moored here. $w2My name is Nasir.$K$PI stopped by to accomplish some
brief piece of business, but$MC...$MD$K$PYour soldiers are now preventing me
from setting sail. $w2I need to leave
this place.$K
$s0I apologize $w2for the inconvenience.$w4
However, we are trying to stop some
Crimean soldiers from escaping.$K$PTo that end $w2we need the cooperation
of all citizens$MC...$MD$w3ship captains included.$K
$s1My ship $w2is a simple merchant vessel,
sailing under the flag of the
Begnion Empire.$K$PIf I present such documentation,$w2
surely it will prove I have no ties
whatsoever with Crimea.$K
$s0Under Daein rule,$w3 such$MC...$MDBegnion
papers are nothing more than
fishwrap.$K
$s1Yet$MC--$MD$K
$s0You called yourself, Nasir, correct?$w3
Protest too loudly,$w2 Nasir, and we
may think you a Crimean sympathizer.$K$PIf that were to happen, who knows
what$MC...$MD$w4unfortunate fate might
your simple merchant ship$MC...$MD$K
$s1$MC...$MDI see. So be it.$K  $R�w�i��b|$B���Ƃ̓���-����|$<$F1$FS$F1$FCL_MAKKOYAR|$F1$PNow then, where is
our special guest?$K
$Ub$H$F4$FCL_DARKKNIGHT|$F4$PI'm right here,
General Mackoya.$K
$F1$POh!$w4 Sir Black Knight!$w5
I hope I didn't keep you waiting.$K
$F4$PNo, I just arrived.$w5 Let us proceed$MC...$MD$w4
I would hear your report.$K
$F1$PThere are no problems whatsoever.$w4
I've nothing to report,
save the tedium of it all.$K$PThe farther west we travel, $w2the weaker
the Crimean fighting spirit becomes.$K$PEach town $w2displays less and less resistance$MC--$MD
now they literally throw wide the gates
at first sign of our approach!$K$PWith duty as humdrum as this,$w2
I worry that my troops may become
sloppy and lose their edge.$K
$F4$PAs a fellow warrior, $w2I can
sympathize with your plight.$K
$F1$PI thank you $w2for your understanding.$K
$F4$PThis town was not scheduled for
subjugation until much later$MC...$MD$w4
Tell me, why are you here now?$K
$F1$PYes, as to that$MC... $MD$w3Mere days ago,$w2
a castle that held Crimean prisoners of war$w2
was attacked and the captives freed.$K$PThe perpetrators were Crimean soldiers
accompanied by sub-humans.$K$PAccording to our intelligence reports,$w2
their trail led here$MC...$MD$K
$F4$PI see.$K
$F1$PThe princess of Crimea is said to have fled
to Gallia. If we can capture this band,$w2
we may gain information on her location.$K
$F4$PDo you require my assistance?$K
$F1$PI thank you for the generous offer.$w2
However, if you were to enter the fray,$w2
it would be over in a twinkling.$K$PMy men are starved for combat.$w4
I would beg your restraint so that they$w2
may be allowed some$MC...$MD$w4entertainment.$K
$F4$PAs you will.$K$PThe field is yours.$w4 Turn your
soldiers loose, and may their blades
run red with glory.$K
$F1$PYour graciousness $w2is greatly appreciated.$K
$=0500  $R�㉺��b|$s0$FS$c0LAY|$s0Good luck, Ike!$w3
You'll be fine.$K$PAs for me$MC... $MD$w2I think
I'll play a little game of$w2 cat and
mouse with these Daein fools.$K    $R�㉺��b|$c0DAYNE2|$s0The Gallian sub-human!$w4
After him! $w2Don't let him get away!$K   $R�㉺��b|$c1IKE|$s1Everyone, move out for the harbor!$K$PTry to avoid $w2conflict with the
local vigilante group if you can.$K
Let's go!$K    $R�㉺��b|$c0JILL|$s0Commander Haar!$w4 Awake!
This is no time to be sleeping!$K$PA sub-human has been spotted!$w3 Come,
let us join in the thrill of the hunt!$K
$s1$Fc$c1HAAR|$s1Yaaaawn$MC...$MD$w3$Fd
Mmm$MC...$MD$w3let's not.$K$PEven if we don't lift a finger,$w2
Mackoya's pups $w2will take
care of everything.$K
$s0Battle glory awaits! $w2Would you allow$w2
others to steal this chance from
beneath your very nose?$K
$s1Yawn.$w3 Go entertain yourself, will you?
Fight a soldier or lance a peasant
or$MC...$MD$w4what you will.$K$PBut for the love of flying,$w4
stop interrupting my sleep!$K
$s0Ooh! $w2You're such a$MC--$MD$K
$s1The fighting?$w3 Um$MC...$MD$w2$Fc
Wake me when it's done.
Yaaaaawwnn$MC...$MD$w3 Zzzzzzz$MC...$MD$K$d1
$s0That's it!!$w4 I'm going by myself!$K
$c1HAAR|$s1Zzzzzz$MC..$MD$w4. Snort! Wha--?$w3
Jill, $w2hold a moment.$K
$s0$FSYes?$w4 Have you changed your mind?$K
$s1You'll wait here with the rest of us.$w4
We don't move unless we're attacked.$w5
That's the word from the top.$K$d1
$s0$FA$MC...$MDGraaarrr!$K    $R�㉺��b|$c0DARKKNIGHT|$s0All these men, and they're still
having problems?$w4
Did I make a miscalculation?$K $R�㉺��b|$c0IKEa|$s0Ah!$w4 It's him!!$K   $R�㉺��b|$c0ZIHARK|$s0Hey!$w4 Are there really
sub-humans about?$K
$c1SELFDEFENCE|$s1Oh yeah, $w2no mistake about it.$w3
And they'll as soon kill you
as look at you!$K
$s0Where are they?$K
$s1They're over there$MC... $MD$w5Cunning beasts!$w4
We're just about to start flushing
them out of hiding.$K
$s0I see.$w4 If you find one, $w2be sure
to give me a call.$K$d0$w6
$s1$FSHar har!$w4 I like that guy.$w5
He came to our little town $w2just for
the chance to hunt sub-humans!$K  $R�㉺��b|$c0ZIHARK|$s0Ah!$K
$c1LETHE|$s1Grrr! $w5Flee.$w4 You're Crimean$MC...$MD$w2
I cannot fight you.$K
$s0Hold on! Please!$w5
$MC...$MDI $w2am not an enemy to laguz.$K
$s1L-laguz$MC...? $MDHow do you$MC--$MD$K
$s0I joined this vigilante group $w2because
I knew it would afford me a
chance to help you flee.$K$PListen, I'll distract the townspeople.$w3
While they're worried about me,
you can make good your escape.$K
$s1I cannot trust the word of a human.$K
$s0$MC...$MD$w4I see. $w2Well, if I cut down these
vigilantes,$w3 will you believe me?$K
$s1Huh?$K
$s0One? $w2Two?$w4 All of them?$w4
How many do you want? Just give
the word and I'll start the cutting!$K
$s1Hsss!$w3 Quiet!$w4 Why? $w2Why would you$MC...$MD$K
$s0I want to help you.$w4
$MC...$MDThat's all.$K
$s1$MC...$MD$K$PI see$MC...$MD$w4 You're not an enemy.$w3
That much$w3 I'll believe$MC...$MD$K
$s0$FSThank you.$w4 $FANow, $w2you must hurry
away from this place.$K
$s1No, $w2I cannot flee.$w5
I have $w2fr-$w3friends with
whom I must board a ship.$K
$s0Will you not desist?$K$PIt's much too dangerous.$w4 The
vigilantes and Daeins want nothing
more$w2 than to kill laguz!$K
$s1I'm not leaving.$K
$s0I see$MC... $MD$w4If that's your stance,$w2
then I've no choice.$K
$s1Hm?$K
$s0I will join your group.$K
$s1Don't... $w2Don't be ridiculous!$K
$s0What's your name?$K
$s1I am Lethe, but$MC--$MD$K
$s0$FSThat's a good name.$K
$s1That's beside the point!$w4
You$MC--$w4$MD$Y
$s0I am Zihark. Well met, Lethe!$K$FA
Whoops! I don't think we have
time for formal introductions.$w4
Let's hurry!$K
$s1H-$w1hold it!$w5
I $w2have not agreed to this!$K $R�㉺��b|$c0ZIHARK|$s0Ah!$K
$c1MORDY|$s1You are a vigilante.$w4
We must avoid $w2vigilantes.$w4
You should flee.$K
$s0You would speak so to the$w2
vigilante group that's hunting you?$w4
You're a $w2kind laguz, aren't you?$K
$s1Hm?$w3 My words are not good.
You must go quickly.$K
$s0No, $w2you are the one who should flee.$K
Leave the rest to me.$w4 I'll confuse the
townsfolk and give you time to run.$K
$s1What? $w2Why?$K
$s0I don't $w2want to see any laguz
harmed,$w4 so I joined these
vigilantes as a double agent.$K
$s1Hmm$MC...?$MD$w3 I am $w2confused.$w5
But$MC...$MD$w3you do not smell like an enemy.$K$POur group $w2must get on that ship.
We are taking it to Begnion.$K
$s0Will you not desist?$K$PIt's much too dangerous.$w4 The
vigilantes and the Daeins desire
nothing more$w2 than to kill laguz!$K
$s1Even so,$w3 we will go.$K
$s0I see$MC... $MD$w4If that's your stance,$w2
then I've no choice.$K
$s1$MC...$MD$K
$s0I will join your group.$K
$s1You will betray your friends?$K
$s0I told you, they're not my friends.$w4
I am an ally to the laguz.$w5
What? You need proof? $w2There!$K
$s1Why do you drop your blade?$K$PThat bright metal tool
is your only fang.$K
$s0I want you to believe me.$K$P$MC...$MD$w4Please.
You must believe me.$K
$s1$MC...$MDI believe you.$K
I am Mordecai, warrior of Gallia.$w4
Who are you?$K
$s0I am Zihark. Well met, Mordecai!$K$FA
Whoops! I don't think we have
time for formal introductions.$w4
Let's hurry!$K    $R�㉺��b|$c1LETHE|$s1Grrr! Die, human!$K
$c0ZIHARK|$s0Hold on! Please!$w5
$MC...$MDI $w2am not an enemy to laguz.$K
$s1L-laguz$MC...? $MDHow do you$MC--$MD$K
$s0I joined this vigilante group $w2because
I knew it would afford me a
chance to help you flee.$K$PListen, I'll distract the townspeople.$w3
While they're worried about me,
you can make good your escape.$K
$s1I cannot trust the word of a human.$K
$s0$MC...$MD$w4I see. $w2Well, if I cut down these
vigilantes,$w3 will you believe me?$K
$s1Huh?$K
$s0One? $w2Two?$w4 All of them?$w4
How many do you want? Just give
the word and I'll start the cutting!$K
$s1Hsss!$w3 Quiet!$w4 Why, $w2why would you$MC...$MD$K
$s0I want to help you.$w4
$MC...$MDThat's all.$K
$s1$MC...$MD$K$PI see$MC...$MD$w4 You're not an enemy.$w3
That much$w3 I'll believe$MC...$MD$K
$s0$FSThank you.$w4 $FANow, $w2you must hurry
away from this place.$K
$s1No, $w2I cannot flee.$w5
I have $w2fr-$w3friends that
I must board a ship with.$K
$s0Will you not desist?$K$PIt's much too dangerous.$w4 The
vigilantes and the Daeins want
nothing more$w2 than to kill laguz!$K
$s1I'm not leaving.$K
$s0I see$MC... $MD$w4If that's your stance,$w2
then I've no choice.$K
$s1Hm?$K
$s0I will join your group.$K
$s1Don't, $w2don't be ridiculous!$K
$s0What's your name?$K
$s1I am Lethe, but$MC--$MD$K
$s0$FSThat's a good name.$K
$s1That's beside the point!$w4
You$MC--$w4$MD$Y
$s0I am Zihark. Well met, Lethe!$K$FA
Whoops! I don't think we have
time for formal introductions.$w4
Let's hurry!$K
$s1H-$w1hold it!$w5
I $w2have not agreed to this!$K   $R�㉺��b|$c1MORDY|$s1Grr!$K
$c0ZIHARK|$s0Go! Quickly now!$K
$s1Huh?$K
$s0I'll distract the townsfolk.$w2
Now's your chance.$K
$s1What? $w2Why?$K
$s0I don't $w2want to see any laguz
harmed,$w4 so I joined these
vigilantes as a double agent.$K
$s1Hmm$MC...?$MD$w3 I am $w2confused.$w5
But$MC...$MD$w3you do not smell like an enemy.$K$POur group $w2must get on that ship.
We are taking it to Begnion.$K
$s0Will you not desist?$K$PIt's much too dangerous.$w4 The
vigilantes and the Daeins desire
nothing more$w2 than to kill laguz!$K
$s1Even so,$w3 we will go.$K
$s0I see$MC... $MD$w4If that's your stance,$w2
then I've no choice.$K
$s1$MC...$MD$K
$s0I will join your group.$K
$s1You will betray your friends?$K
$s0I told you, they're not my friends.$w4
I am an ally to the laguz.$w5
What? You need proof? $w2There!$K
$s1Why do you drop your blade?$K$PThat bright metal tool
is your only fang.$K
$s0I want you to believe me.$K$P$MC...$MD$w4Please.$w3 You must believe me.$K
$s1$MC...$MDI believe you.$K
I am Mordecai, warrior of Gallia.$w4
Who are you?$K
$s0I am Zihark. Well met, Mordecai!$K$FA
Whoops! I don't think we have
time for formal introductions.$w4
Let's hurry!$K    $R�w�i��b|$B����-��|$<$F1$FCL_MISTER3|$F4$FCLME|$F1$PWhat's that?$w4 Thieves are taking
advantage of the commotion$w2
to sack our little town?$K$PWe must close the front gate!$w4
Thanks for your help!$K$POh, $w2I almost forgot! Please,
take this as a token of thanks.$w4
Go on, take it!$K   $R�w�i��b|$B����-��|$<$F1$FCL_WOMAN2|$F4$FCLME|$F1$PAAAAAAHHH! $w5S-$w1s-$w1sub-human!$w3
Noooooooo!!!$w5
H-h-h$w2eeeeelp!$K
$F4$P$MC...$MD$K  $R�w�i��b|$B�X-��|$<$F1$FCL_LADY2|$F4$FCLME|$F1$PSay, aren't you$MC... $MD$w3You are!$w4
You're one of those Crimeans that the
Daein soldiers are after,$w3 aren't you?$K$P$MC...$MD$w3Go on, get moving.$w4
I'll pretend I didn't see anything.$K$PDon't worry, $w2just go!$w5
Wait $w2a second$MC...$MD$w4
Here.$w4 Take this with you.$K    $R�w�i��b|$B�X-��|$<$F4$FCLME|$F1$FCL_LADY2|$F1$PYaaaaaaah!$w5 S-$w1stay back!$w3
Sub-human beast!$w4
Aaaaiiieeeeee!$K
$F4$P$MC...$MD$K    $R�w�i��b|$B�X-�`-��|$<$F1$FCL_WOMAN2|$F4$FCLME|$F1$POhmygosh$MC...$MDare you$MC...$MD$w3 Are you
really fighting Daein?$w5
Ooo$MC...$MD$w3that's so brave!$K$PWe've heard so many rumors about
Crimea's defeat$MC...$MD$w5 That's why everyone
in town $w2acts like they do.$K$PNo one $w2has the courage to stand up
to these fierce Daein forces.$K$PEveryone believes $w2that if they just
cooperate,$w3 life here will go on
as it always has.$K$PPlease, $w2take this magic scroll.$w4
It was my brother's$MC... $MD$w3He was murdered
by the Daein army.$w5 Fight for him, too.$w2$K    $R�w�i��b|$B�X-�`-��|$<$F1$FCL_MISTER3|$F4$FCLME|$F1$PH-h-heavens!$w4 Please don't kill me!$w3
I'll give you whatever you want$MC...$MD$w4
Here, have some yarn! $w5Uh$MC... $MDDried fish?$K
$F4$P$MC...$MD$K $R�㉺��b|$c0ZIHARK|$s0I'd rather not fight you$MC...$MD$w3
Would you please flee?$K
$c1LETHE|$s1Do you expect me to believe you?$w4
Human liar! Hsss!$K   $R�㉺��b|$c0ZIHARK|$s0$MC...$MDPlease, $w2run away$MC...$MD$w4
I don't want to hurt you.$K
$c1MORDY|$s1What $w2are you saying?$w4
Why do you look at me$w2
with such sad eyes?$K  $R�㉺��b|$c0ZIHARK|$s0I bear you no ill will, but$w4 I must$MC...$MD$w2
There are reasons I must fight.$K $R�㉺��b|$c0ZIHARK|$s0Forgive$MC...$MDme$MC...$MD$w4 I have not$MC...$MDyet$MC...$MD$w2
not yet$MC...$MD$w2saved $w2anyone$MC...$MD$Fc$w2 Oh$MC...$MD$K   $R�㉺��b|$c0JILL|$s0A-hah!$w3 Cursed sub-human!$w4
How many true humans have you slain
with those devilish fangs?$K$PAs a Daein wyvern rider,$w3
it is$w2 my duty to purge this world
of your monsterous evil!$K
$c1LETHE|$s1If you are of Daein stock,$w4
I need not restrain myself!$K  $R�㉺��b|$c0JILL|$s0$MC...$MD$K$w3
$c1MORDY|$s1Oh!$K$PYou are$MC...$MD$w3such a young beorc.$w4
I have no wish to fight you.
Go, little beorc.$K
$s0You$MC...$MD$w3you ugly sub-human scum!$w2
How dare you befoul the human
tongue!$w5 You're just half-breed filth!$K
$s1What? $w5Grr$MC...$MD$w2grrr$MC...$MD$w3
Grrrraaaaoooooowwwww!$K   $R�㉺��b|$c0JILL|$s0Father,$w4 please lend me your
protection in this, my first battle!$K $R�㉺��b|$c0JILL|$s0Ur$MC...$MD$w2rrgh$MC...$MD$w4 $FhDone in$MC...$MD$w2by a
$w3sub-human$MC...$MD$K
$c1LETHE|$s1$MC...$MD$K
$s0$FcMy $w2f-f-$w2father$MC...$MD$K$d0
$s1Sympathy$MC...$MD$K$PI feel$MC...$MD$w3no$MC...$MDsympathy$MC...$MD$K    $R�㉺��b|$c0JILL|$s0Ur$MC...$MD$w2rrgh$MC...$MD$w4 $FhDone in$MC...$MD$w2by a
$w3sub-human$MC...$MD$K
$c1MORDY|$s1$MC...$MD$K
Grr$MC...$MD$w2rrr$MC...$MD
I am$MC...$MDsorry$MC...$MD$K
$s0$FhWhy$MC...$MD$w2do you apologize$MC...$MD$K
You're$MC...$MD$w2sub-human$MC...$MD$w2 You're my$MC...$MD$w2
enemy$MC...$MD$K$P$FcFather$MC...$MD$K$d0
$s1Grrr$MC...$MD$K   $R�㉺��b|$c0JILL|$s0Fa$MC...$MD$w2ther$MC...$MD$K $R�㉺��b|$c0MAKKOYAR|$s0Hmm$MC...$MD$w3 They're not fleeing$MC...$MD$w2
They're actually headed this way.$K$PIt appears that we $w2have
underestimated the courage
of our foe.$K  $R�㉺��b|$c0MAKKOYAR|$s0Are you the leader of this company?$K
$c1IKE|$s1I am.$K
$s0You are the ones who freed the
prisoners$w2 from our castle,
were you not?$K
$s1And if we were?$K
$s0Hmm$MC...$MD$w2 It appears my assessment
was slightly inaccurate.$K$PI believed it to be the work of
Crimean soldiers who had briefly$w2
regained their morale.$K
$s1Sorry to disappoint you.$w4
We're nothing but a simple$w2
company of mercenaries.$K
$s0Ha! $FS$w4Would you, by chance$MC...$MD$K$PWould you be the same mercenaries
giving succor to Princess Elincia?$K
$s1Enough talk. $w5Move or die.$K   $R�㉺��b|$c0MAKKOYAR|$s0Hmph, your odd garb$MC...$MD$w3
It marks you as a sub-human.$K$PYou should not have left the forest.
You cannot survive$w2
in human settlements.$K    $R�㉺��b|$c0MAKKOYAR|$s0So we were the ones$w2
guilty of miscalculation$MC...$MD$w3
How shameful$MC...$MD$K$PYour Excellency$MC...$MD$w4 The rest is$MC...$MD
up to you$MC......$MD$K $R�㉺��b|$c0DARKKNIGHT|$s0We meet again, $w2son of Greil.$K
$c1IKEa|$s1$MC...$MD$K
$s0Why do you challenge me?$w4 You
are not worthy of being my foe.$w4
Flee while you are able.$K
$s1You$MC...$MD$w4$d1
$c1IKEaa|$s1You! Die! Die now!
Aaaaaaaarrrr!$K$d1
$c0DARKKNIGHT|$s0$MC...$MD$w2Fool.$K  $R�㉺��b|$s0$Fh$c0IKEa|$s0Gwa, $w2aah$MC...$MD$w5
$MC...$MDI$MC...$MD$w2I was not$MC...$MD$w3$Fc
strong$MC...$MD$w4enough$MC...$MD$K
$c1DARKKNIGHT|$s1Did you truly think to challenge me
with this pathetic band?$K$PIt appears you never learned to
exercise discretion$MC...$MD$w4 No matter$MC...$MDyou
would not have survived regardless.$K $R�㉺��b|$c0DARKKNIGHT|$s0$MC...$MDOh?$w4 You avoided my blow.$w4
Will you be so lucky next time?$K
$c1IKEaa|$s1!!$K  $R�㉺��b|$c0DARKKNIGHT|$s0$MC...$MDMove.$w4 One such as you$w2
cannot stop me.$K  $R�㉺��b|$c0DARKKNIGHT|$s0$MC...$MDA sub-human warrior$MC...$MD$w4
I would $w2test your strength.$K   $R�㉺��b|$c1DARKKNIGHT|$s1$MC...$MDThe mercenaries $w2boarded the
ship safely.$w5
Now, $w2how to proceed$MC...$MD$K   $R�㉺��b|$c0LAY|$s0You're not impeding that ship.$w2
I won't allow it.$K
$c1DARKKNIGHT|$s1One of Gallia's beast warriors$MC...$MD$w5
I've met you $w2once before.$w4 Yes$MC...$MD
at the castle near the sea of trees.$K
$s0From where I'm standing,$w2
we've actually met twice.$K
$s1Oh?$K
$s0I saw you $w2that night$MC...$MD$w4
Standing in the light of the full moon.$w3
The night $w2you murdered Sir Greil.$K
$s1Ha ha! $w2So you were the one$w3
traveling with the beast king, eh?$K$PInteresting.$w4 By measuring his aide's
strength, $w2I will naturally learn more
of the king's true power.$K
$s0Hate to tell you this, but$w2 my king$w2
is not to be measured against the
likes of me. $w2He is far beyond that.$K
$s1All the better.$w4
Now then, $w2let us begin.$K
$s0$MC...$MD$K $R�㉺��b|$c0LAY|$s0$MC...$MDUgh$MC...$MD$w2why?$w4
Why do my attacks$w3 do nothing?$K
$c1DARKKNIGHT|$s1You fight $w2impressively.$w4
However, $w2you are no match for me.$K   $R�㉺��b|$c1LAY|$s1Huh?$K
$c0DARKKNIGHT|$s0Hm?$K  $R�㉺��b|$c1CEPHERAN|$s1Rise.$w4 Leave this to me.$K
$c0LAY|$s0You$MC...$MD$w2you were one of the
prisoners$MC...$MD$K
$s1This knight will not raise
his hand to me.$w4
$MC...$MDCorrect?$K
$c2DARKKNIGHT|$s2$MC...$MD$K
$s1Go now, $w2quickly!$K
$s0$FSIf you insist!$w4 I'll give proper
thanks $w2when next we meet.$K$d0  $R�㉺��b|$c0MAKKOYAR|$s0M-$w2my lord Black Knight!$w4
A ship is departing!$K$PIf we ready our own ship $w2and
set sail without delay,$w4 we can
overtake it immediately!$K
$c2DARKKNIGHT|$s2$MC...$MD$K
$c1CEPHERAN|$s1Listen to me, Daein general.$w4
You will withdraw from this place.$K$PI will not allow you $w2to pursue
that ship.$K
$s0Who are you to speak to me so?$w4
Do you have any
idea$w2 who I am?$K
$s2Gather your men.$w4
$MC...$MD$w2Withdraw.$K
$s0Yet we$MC--$MD$K
$s2I will not repeat myself.$w4
Do it now.$K
$s0Yes$MC...$MD$w2yes, at once!$K$d0 $R�㉺��b|$c0NOSITOHI|$s0M-$w2my lord Black Knight!$w4
A ship is departing!$K$PIf we ready our own ship $w2and
set sail without delay,$w4 we can
overtake it immediately!$K
$c2DARKKNIGHT|$s2$MC...$MD$K
$c1CEPHERAN|$s1Listen to me, Daein general.$w4
You will withdraw from this place.$K$PI will not allow you $w2to pursue
that ship.$K
$s0Who are you supposed to be, $w2fool?$w4
You've no idea who you're
speaking to, do you?$K
$s2Gather your men.$w4
$MC...$MD$w2Withdraw.$K
$s0Y-$w2yet we$MC--$MD$K
$s2I will not repeat myself.$w4
Do it now.$K
$s0Yes$MC...$MD$w2yes, at once!$K$d0 $R�㉺��b|$c0JILL|$s0Commander Haar!$w4
Let us pursue the enemy ship!$K$PThey're friends of the sub-humans!$w3
We cannot allow them to escape!$K
$s1$Fc$c1HAAR|$s1Uwaaaaaahhh$MC...$MD$w3$Fo
That was a good nap.$K$PWell, $w2looks like the fighting's over.$w2
Form up. $w2It's time to withdraw.$K$d1
$s0Commander!$K
$c1HAAR|$s1Listen to me, $w2Jill.$w4
We're scheduled to return home
tomorrow.$K$PIf you were injured in a place
like this,$w2 your lord father
would not be pleased.$K
$s0It's because of my father that I must$w3
not return home empty-handed.$w2
I must have something to show him!$K$PPlease$MC--$MD$K
$s1Simmer down, girl.$w4 The Black
Knight has ordered us to withdraw.$w2
Would you ignore his word?$K
$s0Th-that$MC...$MD$K
$s1Would be suicide. Correct.$w2
So let's move out!$K$d1
$s0Blast.$K   $R�w�i��b|$B�D-�ߌ�|$<$F0$FCL_ERINCIA|$F3$FCL_IKE|$F0$PMy lord Ike!$w4 $FSHow wonderful!$w4
I didn't think you were
going to make it$MC...$MD$K
$F3$PI'm sorry to have $w2worried you.$K
$F0$POh, no, $w2I'm just happy to see you well.$w4
So very$MC...$MD$w2happy.$K
$=1000 $R�w�i��b|$B�D-�ߌ�|$<$F0$FCL_ERINCIA|$F3$FCL_IKE|$F0$PMy lord Ike!$w4 $FSHow wonderful!$w4
I didn't think you were
going to make it$MC...$MD$K
$F3$PI'm sorry to have $w2worried you.$K
$F0$POh, no, $w2I'm just happy to see you well.$w4
So very$MC...$MD$w2happy.$K$P$FD
$F1$FCL_MISTs|$F1$PBrother, you stupid fool!$w4 Fighting
a knight as strong as that$MC... $MD$w4You idiot!$K$PI was$MC...$MD$w4so scared$MC...$MD$K
$F3$PI'm sorry, Mist.$K
$F1$P$FcWho cares$MC...$MD$K
$F3$PYou really were frightened$MC...$MD$w4
I'm sorry, $w2I truly am.$K
$F1$P$Fh$MC...$MD$w2All right$MC...$MD$K
$=1000  $R�w�i��b|$B�X-�[��|$<$F4$FCL_LAY|$F4$PHuff$MC...$MDhuff$MC... $MD$w2Whew! I doubt the enemy
will pursue me this far.$K
$F1$FCL_GIFFCA|$F1$PA warrior such as you, wounded?$w4
Did a beorc give you that bruise?$K
$F4$PMaster Giffca!$K
$FcOww$Fdwww!$K
$F1$PThe king $w2told me to come
and check on you.$K$PDon't move$MC...$MD$w4 Hm, $w2you're plenty
banged up, but nothing appears to
be broken.$K
$F4$PThere's one among the Daein army$w2
whose power is overwhelming.$K$PTo move with such speed $w2with all that
armor$MC...$MD$w2 I tell you, it's not right!$K$PAnd now, $w2the king's forced to use you,
his shadow warrior, to check up on me$MC...$MD$w4
Our ministers $w2are as obstinate as ever.$K$PNo matter what happens, $w2they will not
approve of an alliance with the beorc.$K
$F1$PNothing to be done $w2about that.$w4
Every one of the older retainers has$w2
memories of laguz subordination.$K$PEven the king.$w4 If Princess Elincia were
not King Ramon's orphan, I doubt he would
be willing to aid her.$K
$F4$PPerhaps you're right$MC...$MD$w2
At any rate, the princess and the others$w2
are now safely at sea.$K
$F1$PAnd the watchdog? $w2No signs of
carelessness, I presume.$K
$F4$POf course not.$K$PEven the elders will bend their ears to
hear what that one says$MC--$MD$w4that one
is "special," after all.$K
$F1$PAnd how do you see this?$w4 Princess
Elincia's drive for the reconstruction of
Crimea.$w4 Does she have a chance?$K
$F4$P$FSEh, $w2who can say?$K$PWhich way the wheel turns $w2depends
on Ike and his mercenaries. Success and
failure are but a hair removed.$K
$F1$PSo$w2 this company, which has done nothing
but flee,$w2 controls the fate of the kingdom?$w4
That's a dangerous gamble, isn't it?$K
$F4$P$FAAll gambles are dangerous, Master Giffca.$w4
But no mistake about it, $w2Daein's next target
is Gallia.$w4 We must go home $w2and prepare!$K
$=1000  $=0500$R�w�i��b|$B����-��|$<$F1$FCL_NOSITOHI|$F1$PAre you sure that's true?$K$P$F3$FCL_DAYNE1|$F3$PYes!$w4 You can ask these two for
more details.$K$P$F3$FD
$F4$FCL_MAN2|$F3$FCL_MISTER1|$F3$PThe two of us, $w2we're here representing$w2
the townsfolk.$K
$F1$PYou say that a green-haired lass$w2
boarded that ship?$K
$F4$PY-yes!$w3 She had a very noble bearing
about her$MC... $MD$w2And she was beautiful.$K
$F3$PHer name was$MC... $MD$w2Ellie? Ellen?$w3
They called her something like that.$K
$F1$PIt's true! Princess Elincia$MC...$MD$w4
$FSHa ha!$w3 My luck has changed.$K
$F3$PAll of us, all the townsfolk, are ready to
cooperate in any way we can!$w4
If you would keep that in mind$MC...$MD$w3 Um$MC...$MD$K
$F1$PBelieve me, $w2I understand your$MC...$MDloyalty.$K
$F4$PWell $w2then$MC...$MD$K
$F1$PYou there! Come here!$K
$F0$FCL_DAYNE1|$F0$PYes, sir!$w3 Right here.$K
$F1$PGet these two worms out of here.$w5
Find the hardest physical labor in this town
and get these fools started.$K$PWork 'em from dusk to dawn without
stopping.$w4 Work 'em until they can
no longer move! You got that!$K
$F0$PYes, sir! Understood, sir!$K$F0$FD
$F4$PB-but, $w2that's$MC...$MD$K
$F3$PWhy? $w2Why would you$MC...$MD$K
$F1$PStop your whining. $w2How else am I to
reward worms vile enough$w4 to sell their
own princess to the enemy?$K$PEnjoy your payment, you greedy dastards!$w2
Ha ha ha ha ha ha!$K
$F3$POur own$MC...$MD$w2princess?$w4 That's not$MC...$MD$w2
It can't be. $w2It can't!$K
$F4$PNo$MC...$MD$w2 Nooooooo!$K$F4$FD
$=1500 $R�w�i��b|$B���{-�N���~�A|$<$F4$FS$F4$FCL_ASHNARD|$F0$FCL_DARKKNIGHT|$F4$P$MC...$MDPrincess Crimea, $w2did she board the ship
to Begnion$w3 with the remainder of
Gawain's mercenaries?$K
$F0$PYes.$K
$F4$PThe hindrance that was Gawain is dead.$K$PThe location of the medallion$MC...$MD$w3
will soon be known.$K$PHas our "worm" $w2worked itself into
the group?$K
$F0$PIt appears $w2that our worm has been accepted
as a trusted member of the company.$K
$F4$PHeh heh heh.$w3 All is going as planned.$w4
Now, $w2we let them swim as they please.$K
$F0$P$MC...$MDThere is one thing. $w2I met someone
unexpected $w2at the harbor.$K
$F4$PWho?$K
$F0$PThe prime minister $w2of the Begnion Empire$MC...$MD$K
$F4$P$FAWhat?!$w4
$MC...$MDIs that true?$K$PIf he is nosing about, $w2we must
not make any mistakes.$K$PDid he give any indication $w2he had
caught on to our plans?$K
$F0$PThat$MC...$MD$w2I do not know.$K
He did tell me to deliver a message to
you$MC...$MD$w4 "Overreaching ambition
invites disaster."$K
$F4$P$FSPah.$w3 Nonsense.$K$POur only concern is the princess of Crimea
and the medallion.$w2 We must wait and watch
until such time as we can strike.$K
$F0$P$MC...$MD$K
$F4$PIn the interim, I want you to take
charge of the invasion of Gallia.$K$PBe smart. You must not allow Gallia
to bring their full might to bear.
Understood?$K
$F0$P$MC...$MDAs you will.$K
$=2000 $R�㉺��b|$c0MAKKOYAR|$s0You there! Soldier!$K
$c1DAYNE2|$s1Sir?$K
$s0Strengthen the watch on this ship.$w5
That man $w2is up to something$MC...$MD
I can feel it$MC...$MD$K$PNo matter what happens, $w2that ship
must not be allowed to set sail.
Burn her and sink her first!$K
$s1Yes, sir!$K  $R�w�i��b|$B����|$<$F0$FS$F0$FCL_MAN1|$F4$FCL_IKE|$F0$PHey there,$w3 traveler!$w4
Do you have everything you need?$K$PIf you stop by my humble shop,$w3
you'll find the best deals in town!$w4
Whattya say?$w3 Interested?$K
$F4$PYeah, that sounds great. Listen,
can I ask you a question?$K
$F0$PNo problem!$w3 You can ask me anything.$w4
Especially if it's about my low, low prices!$K
$F4$PWhat do the townspeople $w2think of Daein?$K$PYou knew that they were coming.$w3
Didn't anyone think to $w2flee Crimea?$K
$F0$PFlee?$w4 Don't be absurd!$K
$F4$PBut $w2Crimea lost the war.$K
$F0$PYeah, I know.$w4 And honestly? That doesn't
really affect us common folk, ya know?$K$PThe truth is,$w4 we don't care who sits
on the throne.$w3 To us, they're all just
faceless beings $w2who rule from on high.$K$PIf they tried to raise taxes or something,$w4
you better believe we'd protest, but
otherwise$MC...$MD$K$PI mean, take the king of Daein. $w2He's just
another man, right?$w4 If we keep working,$w2
he can keep living the high life.$K$PSo it's not like he's going to$w3
treat us poorly or anything.$K$PAs long as we can live our lives and have
a little happiness,$w3 we aren't going to
worry about it all too much.$K$POh, $w2but$w4 if we were invaded
by Gallia, well,$w3 that's a different
story altogether.$K$PIf our country were overrun by those
savage beasts,$w4 who knows what could
happen? $w5Now THAT scares me!$K
$F4$P$MC...$MD$K$F4$FD
$F0$P$FAWhat the?$w4 Hey! Wait! Come back!$w5
What about my low, low prices?!$w4
Now what was that all about?$w3$K  $R�w�i��b|$B����|$<$F1$FS$F1$FCL_SELFDEFENCE|$F4$FCL_IKE|$F1$PPardon me, $w2buddy.$w4
I haven't seen you around town before.$w5
You a traveling mercenary?$K
$F4$PYes,$w3 I suppose you could say that.$K
$F1$PNice sword$MC...$MD$w3 You look like a man who
knows his business.$w4 If you're looking for
work, $w2I've a proposition for you.$K
$F4$PA proposition?$K
$F1$PI run a vigilante group $w2that helps
keep our fair town safe.$w4 A strong man
like you$w3 would be most welcome.$K
$F4$PThanks,$w4 but I've got something lined up.$K
$F1$POh, really?$w3 That's too bad.$w4
Heading out to sea?$K
$F4$PMaybe.$K
$F1$PHar har! Cautious to the end! I like that!$w4
Well, just in case you are$MC...$MD$w2
I want you to have this.$K
$F4$PHm?$w3 What's this?$K
$F1$PIt's a special sword.$w4 It'll come in handy
if you ever$MC...$MD$w3find yourself at sea.$w4
Not that you would! Har har!$K
$F4$PReally? You're giving me a sword?
Are you sure?$K
$F1$PWell, there is one condition$MC...$MD$w4
Once you've finished your job,$w2
you come back and see me.$K$PI'd like you to reconsider$w2
that vigilante position.$K
$F4$P$FSUnderstood.$w4 Thanks again for the blade.$K  $R�w�i��b|$B�X-�`-��|$<$F5$FCL_ERINCIA|$F5$P$MC...$MD$K
$F3$FCL_IKE|$F3$PPrincess!$K
$F5$FD$F1$FS$F1$FCL_ERINCIA|$F1$PMy lord Ike$MC...$MD$K
$F3$PWhy are you here all by yourself?
That's not very safe.$K
$F1$PI was $w2looking at the town.$K$PI'm unfamiliar with the world outside
the imperial villa where I was raised.$K$PThis is the first time $w2I've been able to see
how other people live.$w3 Everything is so
new and different to my eyes.$K$PThis$MC...$MD$w2is a town, isn't it?$w4
There's so much energy, $w2and everyone
seems to be enjoying themselves.$K
$F3$P$FSWith all the boats coming in and out of the
harbor, $w2this town's livelier than most.$w2
That's for sure.$K
$F1$P$FAIt's like $w2nothing has happened.$w4
All the death $w2and destruction we've
seen feels like a horrible dream$MC...$MD$K
$F3$P$FAMmm$MC...$MD$K  $R�w�i��b|$B����-��|$<$F5$FCL_KEVIN|$F5$PHaa!$w4 Yaaa!$w4
Hiiii-yaaaa!!$K
$F3$FCL_IKE|$F3$PWhat are you doing?$K
$F5$PI'm trying to regain the superb physique
I lost $w2when I was being held prisoner.$K
$F3$PAre you ready to board the ship?$K
$F5$PI was born ready! Hoooo-ha!
I don't need anything!$K$PEven as we speak,$w3 many of my
fellow Crimeans $w2are suffering at
the hands of Daein.$K$PIf I cannot rush to their aid today,$w3
then I can at least prepare myself
for the day when I can.$K
$F3$PI see.$w4 Well, when we're ready,
I'll let you know.$K
$F5$PUnderstood.$K
$F3$PSorry to have interrupted you.$K
$F5$FD$F1$FCL_KEVIN|$F1$PMy lord Ike!$K
$F3$PWhat is it?$K
$F1$P$FSYou rescued and cared for Princess
Elincia.$w3 You have my heartfelt thanks.$K$PShe$MC... $MD$w3For us, $w2she is our one
solitary hope.$K
$F3$P$FSYeah.$K
$F1$PRight,$w3 enough talking.$K
$F1$FD$F5$FCL_KEVIN|$F5$PUntil we make our triumphant return to
Melior,$w3 all I can do is keep training!$w5
Haaa!$w4 Nyaaa!$w4 Whaaaaaaaaaaa!!$K
$F3$PCareful! Don't pull anything$MC...$MD$K   $R�w�i��b|$B�X�O��-�`|$<$F1$FS$F1$FCL_CHAP|$F1$P$MC...$MD$K
$F3$FCL_IKE|$F3$PWhat are you looking at?$K
$F1$POh,$w3 just this. $w2It's sort of a good-
luck charm.$w3 My family gave it to me
when I left home.$K$PWe never had much money,$w3 so my parents
gathered some stones from our farm back
home and put them in this leather pouch.$K$PIt's not much to look at, but it means a
lot to me.$w5 Every day, I take them out and
talk to them like they're my family.$K$P"How is everyone?"$K
"I'm out here doing the best I can."$K
"Don't worry. I'll be home soon."$w3
Just stuff like that.$K$PI know it sounds foolish,$w4$FA
but if I don't do this$MC...$MD$w2I won't$MC...$MD$w5
I won't have the courage$w3 to fight.$K
$F3$P$MC...$MD$K
$F1$P$FSDon't worry about my feelings.$w3 You can
laugh.$w4 Acting like this at my age,
what a silly man I am!$K
$F1$P$FA$F3$PIt's not silly, Brom.$w4 You're a strong
man who has decided to fight for
the sake of his family.$K$PI know that your family$w2
is very proud of you.$K
$F1$P$MC...$MDSniff$MC...$MD$w5
S-s-sniff$MC...$MD$w3 Mm.$K$PThank you, Ike.$w4
$FcSniff$MC...$MD Thank$w3 you.$K    $R�w�i��b|$B�X-��|$<$F6$FCL_NEPENEE|$F6$PWell, that's that.$K
$F1$FCL_IKE|$F1$PAre you ready to go, $w2Nephenee?$K
$F6$FD$F3$FCL_NEPENEE|$F3$PAh!$w4 Ike$MC...$MD$K
$F1$PWhat is it?$K
$F3$P$MC...$MDUm$MC...$MD$w4
Nope! Nothin'!$w4
I'm$w3 fine.$K
$F1$PAre you sure?$K
$F3$PYeah! Sure I'm sure!$K
$F1$PYou know, it's hard being a prisoner. It's
physically and mentally demanding$MC...$MD$w4
I need to know: can you fight?$K
$F3$PNot$w3 a problem!$K
$F1$PIt's easy for you to say, $w2but you sound
like you're about to fall over.$K
$F3$PThat? Aw, no! That's$w4 a habit$MC...$MD$w3
It's just the way I talk.$w3 Just talkin'!$K
$MC...$MD$w3Sorry.$K
$F1$PNo need to apologize.$w4 As long as you're
not feeling ill, everything's fine.$K
All right, $w2I'll see you later.$K
$F3$P$FSRight then$MC...$MD$K $R�w�i��b|$B���Ƃ̓���|$<$F1$FCL_SENERIO|$F3$FCL_IKE|$F1$PIke,$w3 here's a summary of our last battle.$K$N$UB$H    $F3$P$FcI see.$K$P$UB$H $F1$P$FSThere were no casualties,$w2 and no one
suffered permanent injury.$w4
We fought excellently.$K$P$UB$H   $F1$PThat's all I have to report.$w4
If you'll excuse me.$K   l�      e�     ^$     ^�   &  _t   3  `|   @  a�   M  b�   Z  j<   g  m,   u  m�   �  s�   �  u�   �  f�   �  h�   �  i�   �  _�   �  cD   �  d8   �  e�    k`    {$    |4  ,  ~�  ;  ��  I  w�  U  ��  a  @�  n  G(  }  L�  �  R�  �  >`  �  >�  �  m�  �  n`  �  qh  �  r  �  rL    :L    8�    9`  +  9�  :  >�  I  �<  U  �L  c  ��  q  �    �4  �  ��  �      �  d  �  |  �  ,  �  h  �  |  �  �    �    ,  !  �  2  �  C    T  <  c  p  s  @  �  !$  �  #H  �  #�  �  %�  �  &�  �  +�  �  +�  �  �  �  1�    ��    �(  -  ��  <  �@  K  W�  \  X�  i  Y8  y  Z�  �  [  �  ]T  �MS_12_ALIVE_IKE MS_12_BT MS_12_BT_02A MS_12_BT_02B MS_12_BT_02C MS_12_BT_03A MS_12_BT_03B MS_12_BT_03C MS_12_BT_DARK MS_12_BT_DARK_00 MS_12_BT_DARK_01 MS_12_BT_DI_3A MS_12_BT_DI_3B MS_12_BT_IKE MS_12_BT_R1 MS_12_DIE MS_12_DIE_02 MS_12_DIE_03A MS_12_DIE_03B MS_12_DIE_03C MS_12_DIE_IKE MS_12_ED_01_AA MS_12_ED_01_BB MS_12_ED_02_B MS_12_ED_03 MS_12_ED_XX MS_12_ED_XXX MS_12_EV_00_00 MS_12_EV_00_01 MS_12_EV_00_02 MS_12_EV_00_03 MS_12_EV_DARK MS_12_EV_DARK_2 MS_12_EV_DL_1 MS_12_EV_DL_1_2 MS_12_EV_DL_2 MS_12_EV_DL_3 MS_12_EV_DL_4 MS_12_EV_JILL MS_12_EV_Lay MS_12_EV_Lay_2 MS_12_EV_START MS_12_EV_XX MS_12_INFO_01 MS_12_INFO_02 MS_12_INFO_03 MS_12_INFO_04 MS_12_INFO_05 MS_12_INFO_06 MS_12_OP_01 MS_12_OP_02_new MS_12_OP_03_00 MS_12_OP_03_01 MS_12_OP_03_02 MS_12_OP_03_03 MS_12_OP_03_04 MS_12_OP_03_06_A MS_12_OP_03_06_B MS_12_OP_03_06_C MS_12_OP_03_06_D MS_12_OP_03_07 MS_12_OP_03_08A MS_12_OP_03_08B MS_12_OP_03_08C MS_12_OP_03_09 MS_12_OP_03_10 MS_12_OP_03_11 MS_12_OP_03_11_2 MS_12_OP_03_12 MS_12_OP_03_13 MS_12_OP_03_14 MS_12_OP_03_14_02 MS_12_OP_04 MS_12_REPO_BEGIN MS_12_REPO_DIE MS_12_REPO_END MS_12_REPO_NODIE MS_12_VIL_01 MS_12_VIL_01_LM MS_12_VIL_02 MS_12_VIL_02_LM MS_12_VIL_03 MS_12_VIL_03_LM 