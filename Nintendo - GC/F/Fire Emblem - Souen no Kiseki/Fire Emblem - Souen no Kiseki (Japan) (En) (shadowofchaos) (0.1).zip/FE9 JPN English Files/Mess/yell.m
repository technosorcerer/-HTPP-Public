 }K e        �                $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_CHAP|$F3$FCL_BOLE|$F1$PGood morning! I'm Brom.$w4 I take it you're
with the Greil Mercenaries?$K
$F3$PWell, if it isn't the imprisoned papa!
$FSI'm Boyd.$w4 And I'm one of
the original Greil Mercenaries.$K
$F1$POh, that's swell!$w4 You know, you fight
pretty well for someone so young.$K
$F3$PYoung? Ha! You're one to talk!$K$P$FAI mean, look at you, pops!$w4
We had to bust you out of a prison,$w4
and you're STILL a big fatty!$K$PHow do you fight with a body like that?
Doesn't all the jiggling slow you down?$K
$F1$P$FAAw, you're right...$w4 I know it could be
trouble during a big battle.$K$PBut this body has served me well! After all,
you need a lot of girth to manage
a mule and plow!$K
$F3$PYou're a farmer, pops?$K
$F1$PThat's right!$K$PBut I hate to think that my big belly
would be a burden on you...$w3
Aw, now I feel terrible!$w3 Sniff... Sniff...$K
$F3$P$FSWha--? Hey, don't cry, pops! Look,
let's start working out together!$w4
I'll whip you into shape in no time!$K
$F1$P$FSReally? Do you mean that?$w4 That would
be great! Whip me into shape, Boyd!$w4
Oh, my wife will be so surprised!$K  $R�w�i��b|$B�x���w�i|$<$F3$FCL_BOLE|$F1$FCL_CHAP|$F1$PHuff...$w2huff...$w2huff...$w2
Phew! Hey, Boyd... I'm sorry...$w4
for being...$w3phew!...being such a drag!$K
$F3$P$FSYou can't help being a slow walker.$w4
Don't worry! You're doing fine.$K
$F1$P$FSYou really think so? Aw, thanks, Boyd!$w4
You know, I may not be in the best shape,
but I've got more tenacity than anyone.$K$PA farmer's work lasts all year 'round, after
all.$w4 You've got to have patience.$K
$F3$P$FAAll year, huh?$w4 Tell me, pops.$w2 Do you
enjoy working in the fields?$K
$F1$PYou bet!$w4 Sure, I've got my share of worries,
like bugs and animals and bad weather...$w2
But it's all worth it come harvest time!$K
$F3$PHmm...$K
$F1$P$FAWhat's wrong?$K
$F3$POh, $w2I was just thinking...$w2 The farming
life is the complete opposite of what
we mercenaries do.$K$PI mean, a farmer gets to bring life to the
world, and his work keeps everyone going.$K$PBut mercenaries? We kill people,$w2 and we
break things, and... Well,$w3 we bring
death, not life.$K
$F1$PAw, don't talk it down like that!$w4
You get to$w4 fight for what's right
and protect people!$K
$F3$PHey, $w2don't get me wrong.$w2
The Greil Mercenaries are my family,
and I do my job because I like it.$K$PBut...$w4you know what?$K
$F1$PWhat?$K
$F3$P$FSBreak time's over!$K$PUp and at 'em, pops!!$w2
Back to the training!$K$F3$FD
$F1$PW-what? Wait, it's only been a...$w4
H-hold on!$w4 Aw, shucks!
Phew... $w2Huff... $w2Puff...$K $R�w�i��b|$B�x���w�i|$<$F1$FCL_CHAP|$F3$FCL_BOLE|$F1$PWhew! Aw, shucks!$K I give up!
You got me!$w4 $FSPhew!$w2
You're too much for me, Boyd.$K
$F3$P$FSYou were close this time, pops.$w4
You've gotten a lot better.$w4
I think we can wrap up training soon.$K
$F1$PI've gotten better, huh?$w3 You really think so?$K
$F3$PYou're like a full-fledged soldier!
There's not an enemy around that
wouldn't be afraid of you!$K
$F1$POh, I'm so happy to hear that!$w4
I just didn't want to be a huge
burden on everyone anymore.$K
$F3$POh, stop it.$w4 Keep this up, and you could
even be a$w2 royal guard after the war.$K
$F1$P$FANo thank you! I'm done fighting.$w2
When this war is over, I'm going back
to farming.$K
$F3$P$FAListen, pops.$w2 Tell me the truth...$w4
How do we mercenaries seem to you?
I mean, to farmers? Simple people.$K
$F1$PWhat? I don't get you, Boyd.$K
$F3$PWell, the world is full of mercenaries,
but most of them are just scoundrels
who can't hold any other job,$w2 right?$K$PSo when there's no war to fight,
they wander the countryside
without honest work.$K$PA lot of them end up stealing from villagers
or just turn into common cutthroats.$K
$F1$PBoyd, you're not--$K
$F3$PNah, we're not like them. I know that.$w4
But...$w4you can't tell that just by
looking at us.$K$PI hear it when I walk through towns.
"Careful! The mercenaries are back."
"They're scrounging for money."$K
It kinda hurts, you know? I mean,
I don't care what you say about me,$w2
but when you talk bad about my family...$K
$F1$PWell, Boyd.$w4 Here's what I think.$K$PFolks always judge, and they're usually
wrong. That's just how they are, you know?
You can't worry about it too much.$K$PBut I like you. And I respect you, too.
Shucks, everyone in this company has been
just great!$w4 Anyway, that's what I think.$w3$K
$F3$PThanks, pops.$w4
That's...$w3good to hear.$K$P$FSAll right!$w2 Back to the training!
Let's go the extra mile this time!$K$F3$FD
$F1$PHuh!?$w4 A-again?$w4
G-$w2give me a second, $w2Boyd!$K
Phew!$w2 Huff...$w2puff...$K  $R�w�i��b|$B�x���w�i|$<$F6$FCL_BOLE|$F6$PHyaaa!$w4 Gyaaa!$w3
Hrrraaaa!$w4
...$K$PPhew...$w4 That's enough for today.$w4
I just don't feel into it.$w4
Maybe I'll take a quick nap...$K
$F7$FCDUMMY|$F7$PDone already, Boyd?!$K
$F6$FD$F3$FCL_BOLE|$F3$PHuh? Um... Gyaaa!$w4 Hyaaa!$w4
Oh, Titania! I didn't see you there.
I'm training so hard that...$w4 Huh?$K
$F1$FS$F1$FCL_MIST|$F1$PTee hee!$K$F1$FD
$F3$PWho the--?$w3 Mist!$w3 Ooo! What a jerk!$K
$F0$FS$F0$FCL_MIST|$F0$PHey, you're the one who tried
to blow off training!$K$PIf you keep ignoring your drills,
I'm going to become a better
mercenary than you!$K
$F3$P$FhBetter than me? Ha.$w3 HA! Dream on, kid!$w3
You've got some nerve saying that to me!$K
$F0$PKid? You better remember who my father is!$w4
Fighting ability runs in the blood, you know.$K
$F3$P$FdAw, that's a bunch of hooey! Survival on a
battlefield depends on experience and luck.
Nothing more!$K$PIf you dive into battle with a conceited
attitude, you'll end up dead no matter
what blood is in your veins!$K
$F0$PGee, sorry, Boyd. I was just joking...$w4$FA
Hey, don't look so angry...$K
$F3$PThis is no game!$w4 We don't fight for fun!$K$PNow get out of here...$w3 I mean it!$w4
You're in my way!$K
$F0$P...Sorry.$K$F0$FD
$F3$P...Mist, wait...$w4
Ah, heck.$K   $R�w�i��b|$B�x���w�i|$<$F1$FCL_MIST|$F1$PIke!$w3 Brother!$w4
Where did he go?$K$F1$FD
$F3$FCL_BOLE|$F3$PIke? Hey, Ike!$w3 IIIKKKEEEE!!$w5
Man alive, where did that guy get to?$K
$F1$FCL_MIST|$F1$POh... $w5Hi, Boyd.$K
$F3$PHey, $w2Mist.$w4
Um...do you know where Ike is?$K
$F1$PNope. $w2I was looking for him, too.$K
$F3$PHuh.$w4 Well, he's been pretty busy lately.$K$PMaybe I should just give up and find
someone else...$K
$F1$PYou need a training partner?$K
$F3$PYeah.$w4 I'm just not motivated
unless I'm sparring with someone.$K
$F1$PCan I...$w6 Can I be your partner?$K
$F3$PWhat, you? Seriously? Why would you want
to do that?$K
$F1$PBecause I want to prove that you're no
match for me!$K$PUm...$w3 Actually...$w4I need to
toughen up, or I might not survive
these next battles.$w4 That's why.$K
$F3$PThat's a good reason. Maybe you can
be my partner, after all.$K
$F1$P$FSReally?$K
$F3$P$FSWell, it's better than hitting a scarecrow
with a stick.$K
$F1$P$FAThat's terrible!$w4 After all,$w2 I am Greil's--$K
$F3$PYeah, yeah, you're Greil's daughter. I know.
You won't let me forget it!$K
$F1$P...$K
$F3$PHey, listen... I'm sorry about the other day.$w4
I was too harsh on you.$K
$F1$PNo, it's fine.$w4 You were right. I was naive.$K$PYou just opened my eyes a little...$w4$FS
I'm grateful to you, Boyd.$K
$F3$P$FADon't...$w3 Don't thank me for insulting you!
Sheesh!$K
$F1$PBut it was a good thing! You're making
me strong!$w5 You're so good to me...$w5$FA
Huh?$w4 Why are you blushing?$K
$F3$PQuiet! I'm not blushing!$w4
Uh...$w3 I gotta go!$K$F3$FD
$F1$PBoyd! Wait! Where are you going?$w4
Aren't we going to train?$K   $R�w�i��b|$B�x���w�i|$<$F3$FCL_BOLE|$F3$PHey, $w2Mist.$K
$F1$FCL_MISTs|$F1$PBoyd...$K
$F3$PWhat's wrong? You look depressed.
Actually, you haven't been yourself
lately.$w4 Did something happen?$K
$F1$P$FhB-Boyd, I...$w4
Sniff...$w3sniff...$w5
Whaaa!$w3$Fc Whaaaaaaaa!$K
$F3$PWhoa!$w4 What is it?$K
$F1$POh, Boyd, it's...$w3everything!
Every...$w3thing...$w3 Sniff...$w5
Boyd, I...$w4 Whaaaaaa!$K
$F3$PUm...$w4 Ah, geez...$w4 I'm not much good
at this kind of thing,$w3 but if you need
to cry, go ahead.$K
$F1$PWhaaaaaa!$w4
...Snifff...$w4 Sniff...$w5
Awaaahaaahaaahaaaaaaaaaa!!!$K
$F3$P$FSUm...$w3 Once you settle down,
we can talk. All right?$K$PBut go ahead and let it out.$w4 Let it all out.$w4
You'll feel better.$K
$F1$PWhaaaaaaa...$w3 Whaaa...$w4 Sniff...
...$w3Sniff...$w4
Tha-$w4thanks...$K
$F3$PHey, don't worry.$w4 You have me and...
everyone.$w4 You're in good hands.
We'll take care of you.$K
$F1$P...Sniff... Oh, Boyd...$K    $R�w�i��b|$B�x���w�i|$<$F3$FCL_BOLE|$F3$PNinety-eight...$w3
Ninety-nine...$w3
One hundred!$w3 Done!$K$PBleh.$w2 What's the point in
swinging an axe by myself?$K$PI should probably try to find Ike...
But maybe a quick nap first--$K
$F1$FCL_TIAMAT|$F1$PBoyd!$K
$F3$PAaah! $w2Titania!$K
$F1$PWhere do you think you're going?$w4
Are you blowing off your training again?$K
$F3$PNo! $w2I'm not slacking, I swear!$w4
I was just...$w4uh...$w3going to
work out with Ike!$K
You know me--I'm all about the fighting!$K
$F1$PBoyd, I know that training is tough.
But if you make light of it, you're closer
to death than you ever want to be.$K$PYou're a mercenary. When you're confused
or exhausted during a long battle,
instincts make all the difference.$K
$F3$PBut, Titania...$w3 I just can't get into
training when I don't have a partner.$K
$F1$P$FcCan't get into it?$w4 Boyd?$w4
Don't make me chew you out again.$K
$F1$P$Fd$F3$P$FSJoking! I-$w2I'm just joking!$w4
What I just said?$w4 All a joke!
Ha ha!$w3 Ha?$w3 Haaaaa...$K$POh, $w2I'm just dying to do some
practice swings! Hyaaa!$K$PBoy, training is so much fun!$w4
Isn't that right, $w2Titania!?
Whooo! I loooove training!$K
$F1$P$FSDarn it, Boyd, why are you so lazy?
You're a natural fighter, you know that?$K$PYou could even be a better fighter than
me if you just put your mind to it.$w4
Anyway...$w2keep practicing.$K $R�w�i��b|$B�x���w�i|$<$F1$FCL_TIAMAT|$F1$PHello, Boyd.$K
$F3$FCL_BOLE|$F3$PT-$w2Titania!?$w4 I'm not slacking!$w4
I've done my training! Look, I'll do more!
Hiiiyaaa!$w3 Kiyaaaaa!$w4 Whaaaaaa!$K
$F1$PBoyd, I haven't said a word.$K
$F3$POh, $w2yeah, I guess not.$w4
I'm so used to all our conversations
starting that way...$K
$F1$PI didn't come here to chew you out.
You don't need that anymore.$K$PWe're fighting intense battles now,
and you can't let your guard down.
But you know that, right?$K
$F3$PI guess so.$K
$F1$PYour training has become instinct.$w2
That's all you need to survive.$K$P$FSYou've learned that lesson, Boyd.
You'll be all right.$K
$F3$PShoot!$K
$F1$P$FAW-$w2what?$w4 Did I say something wrong?$K
$F3$PThis doesn't sound right, Titania.$w4
I feel like...$w3like you're praising me.$K
$F1$PWell, I am.$w4 You're a true warrior now.
One of our best.$K
$F3$POh, man, this is making my head spin...$w3
It's like a bad omen or something. I think
it's scarier than being chewed out.$K
$F1$PI see...$w4 So you want me to chew you out,
huh?$w3 $FSGreat. I can do that.$K$F1$FD
$F3$P$FAAaah!$w4 No, $w2that's not
what I meant, Titania!$K    $R�w�i��b|$B�x���w�i|$<$F3$FS$F3$FCL_BOLE|$F3$PTitania!$w4 I couldn't find you anywhere!$w3
With all the war councils and everything,
I never get to see you anymore.$K
$F1$FS$F1$FCL_TIAMAT|$F1$PHello, Boyd.$w4 You know, your recent
performance has been superb. I can't even
chew you out for old time's sake.$K
$F3$P$FAI don't want you to yell at me again.
That's not why I'm here.$w4 I just...$FS$w3
Is there anything you want, Titania?$K
$F1$PI can't think of anything in particular.$w3
Why do you ask?$K
$F3$PWe got a big reward the other day,
you know?$w4 So I wanted to buy you
something. As thanks for helping me.$K
$F1$PAha!$w3 Now that you're a true warrior,
you've learned some chivalry as well!$K
$F3$PHeh.$w3 So, name it. Anything.$w4
New chain mail? Gauntlets?$w2
How about a killer axe?$K
$F1$PThanks for the offer, Boyd.$w4
But you earned that money.$w4
You should spend it on yourself.$K
$F3$P$FADon't you get it!?$w4
I want to give you a gift!$K
$F1$P$FABoyd?$w4 What are you--$K
$F3$PEvery time I look at you, Titania...$w5
I think that you're the prettiest
person I've ever seen!$K
$F1$PUh...$w4 Um, thank you, Boyd...$w4
But I...$w4 Look, you and me, we're--$K
$F3$P$FSYou're like a really nice mom or something!$w8
Um...$w4 I mean...$K
$F1$P...$K
$F3$P$FAWait, that's not...$w5 Oh, man...$w4
Look, that's not what I meant.$w6
I mean, it is, but--$K
$F1$P$FhBoyd?$K
$F3$P$FSYeah?$K
$F1$PHow old$w3 do you think I am?$K
$F3$PWell, let me see...$w3 Are you...$w4
younger than my mother?$K
$F1$P$Fc...Um...$K
$F3$P...Yeah...$w7 Um...$w5
I gotta go!$K$F3$FD
$F1$P$FhBoyd!$w4
Wait up!$K    $R�w�i��b|$B�x���w�i|$<$F3$FCL_BOLE|$F3$PHey, there's that big hawk laguz that joined
our party. What's his name again?$K
$F1$FCL_VULCI|$F1$P...$K
$F3$POh! Hey there.$K
$F1$PCan I help you?$K
$F3$PHuh?$K
$F1$PI thought you called me.$w4
Is that not the case?$K
$F3$PWha--?$w4 Are you talking about what I
just said?$w4 You heard that?$K
$F1$PClearly.$K
$F3$PTh-$w2that's incredible! I was just mumbling,
and you were all the way over there!$K
$F1$PSo.$w3 What do you want from me?$K
$F3$PNothing.$w3 I was just noticing your features.$w4
You have such an interesting face!$K
$F1$P...$w4
Do you have a problem with my face?$w4
There's nothing special about it.$K
$F3$P$FSNo, no problem!$w4 It's so tough!$w3 Manly!
It's the best! I wish it was my face!$w4
Um...$K
$F1$P...$K
$F3$P...$K
$F1$PWell, you seem...$w5healthy.
And you have good hair.$w3 For a beorc.$w4
I also like your large arms.$K
$F3$P$FAReally?$K
$F1$POh, I have an errand to run.$w4
Good-bye.$K$F1$FD
$F3$PYeah, my arms are pretty tough, huh?$w4
You know what? $w2I bet I'll get along
with these laguz just fine!$w3 Yeah.$K   $R�w�i��b|$B�x���w�i|$<$F3$FS$F3$FCL_BOLE|$F3$PHey, it's you!$w3 What's up, my hawk brother?$K
$F1$FCL_VULCI|$F1$POh, it's the...$w4large-armed beorc.
I...um...haven't seen you lately.
Unless we're in battle.$K
$F3$PYou got that right! Oh, $w2I'm Boyd.$w4
We're buddies now, so you can
call me by name.$K
$F1$PVery well.$w4 I am Ulki.$w4
But I ask that you call me that name
instead of...$w3hawk brother.$K
$F3$PYeah, sure. Whatever you want. So, Ulki.$w4
What are you doing in a place like this?$K
$F1$PI was listening to the little birds chirp.$w4
The song soothes me.$K
$F3$PReally?$K$P...$w6
Nope.$w4 I can't hear anything.$w4
You must have really good ears.$K
$F1$PMmm...$K
$F3$PYou know,$w2 I really envy you bird tribes.$w4
Being able to fly is the greatest thing ever!$K$PYou're something else in a fight, too!$w4
I can't believe how you tear through guys.$K$POh, and it's weird how much we look alike!
I mean, when you're not shifted.
And except for the wings and stuff...$K
$F1$P...$K
$F3$POh, hey, sorry.$w4 I'm doing all the talking.
Sometimes I just start rambling on...$w4
If I'm bothering you, just say so.$K
$F1$P...$FcSorry...$K
$F3$P$FAWhat's wrong?$K
$F1$P$FdI am...the worst.$K$F1$FD
$F3$PHuh? $w2Hey!$w4
What's gotten into you?$K $R�w�i��b|$B�x���w�i|$<$F5$FCL_VULCI|$F3$FCL_BOLE|$F3$PThere you are!$w4 Wait a sec, $w2Ulki!$K
$F5$P...$K
$F3$PWhy are you avoiding me? Did I make you
mad or something?$K
$F5$FD$F1$FCL_VULCI|$F1$PBoyd...$K
$F3$PI thought we were friends.$K$PI guess we can't be friends$w2
because I'm a beorc.$w4 Is that it?$K
$F1$PNo...$w3 You are...good. It's me.$w4
I'm the worst.$K
$F3$PYou called yourself that the other day, too.$w4
What are you getting at?$K
$F1$PMmm... When you first spoke to me...$w3
I was suspicious.$K$PWhen a beorc like you speaks to a laguz
like me...$w4 I thought you were
plotting something.$K
$F3$PEr...$w4 But you said nice things
about me when we first met!$w5
Were you lying?$K
$F1$PI thought the exchanging of lies upon a
first meeting was a beorc tradition.$K$PYou also gave me a series of flattering
compliments that were not true, no?$K
$F3$PNo, they were true! Well, mostly...
Look, I was nervous! I'm not that
good at talking to new people.$K
$F1$PI checked you out when we parted company.$K$PI investigated your name. Your background.$w4
I checked everything.$K
$F3$PYowza! Really?$w4 So what did you find?$K
$F1$PBoyd of the Greil Mercenaries.$w4
You are a skilled fighter who says what's
on his mind. It is just as you seemed.$K
$F3$P...$K
$F1$PEven though you showed me goodwill
from the very beginning...$w4
I had no trust in you.$K$PI thought you were...mocking me.
Or setting me up for a trap.$K$PThat's why I am the worst.$w4
I am not worthy of being your friend.$K
$F3$PHa ha ha!$K
$F1$PWhat is it?$K
$F3$PWe're so alike! $w2At first, I was sure
that you would hate me, or claw out
my eyes, or...something.$K$PI didn't think I could just hang out with you
like Ike does. He's just so darn natural
about everything!$K$P$FSBut then I happened to talk to you,
and it was really easy! That made me
pretty happy.$K$PSo after that, I tried to get to know you.
I even followed you around the battlefield.$K
$F1$PI see.$K
$F3$P$FALook, beorc can be a bunch of jerks.$w4
I don't blame you for checking me out.
Heck, I know what we did to your people.$K$P$FSBut now it's gotta stop.$w2
Now that you know I'm clean,
you have to stop putting up walls.$K$PWe'll never understand each other
if you're like that.$K$PSo tell me straight, yes or no?$w4
Are we friends or what, Ulki?$K
$F1$PYes. I'm sorry, Boyd.$w4 If you can forgive me,$w3$FS
I want to be your friend.$K
$F3$PForgive you? Pah! I wasn't even mad!$w4
I was going to be your friend
from the very beginning!$K   $R�w�i��b|$B�x���w�i|$<$F1$FCL_CALILL|$F1$PMmm...$w2 Such a drab locale.
Not like the city at all--$w4
Aaaaah!$K$F1$FD
$F2$FCL_GEOFFRAY|$F2$POof!$w4 Look out!$K
$F1$FCL_CALILL|$F1$P$FoAh! My face! My beautiful face!$w2
No, no... I think it's still there.$K
$F2$FD$F3$FS$F3$FCL_GEOFFRAY|$F3$PAre you all right, my lady?$K
$F1$PWell...$w3 Oh my!$w3 He called me a lady.$w3
And such a handsome devil!$K$FS$P$FdY-$w2yes, good sir!$w4 Thanks to you,
I appear to be unhurt.$K
$F3$PReally?$w4 Well, that's good.$w4
I know that you were lost in thought,
but do try to watch your step.$K$F3$FD
$F1$P$FAW-$w2wait! Just a moment!$K
$F4$FS$F4$FCL_GEOFFRAY|$F4$PYes? What is it?$K
$F1$P$FSI'm...$w2 My name is Calill.$w4
What is your name, gentle sir?$K
$F4$PI am Geoffrey.$K$F4$FD
$F1$PGeoffrey...$w3 Such a nice name.$w4 A fine gent
like Geoffrey is just right for me!$K$POh...$w4 Love always comes when
you least expect it. Sweet Sir Geoffrey!
You will be mine!$K  $R�w�i��b|$B�x���w�i|$<$F3$FS$F3$FCL_CALILL|$F3$POh, $w2there you are, Sir Geoffrey!$w4
You look especially rugged
and dashing today!$K
$F1$FS$F1$FCL_GEOFFRAY|$F1$PHm?$w4 Oh, hello, Calill.$w4
How are you?$K
$F3$PHmm!$w2 How nice! You remember me...$w4
Perhaps love dares to speak its name!$K
$F1$PEh? What are you talking about?$K
$F3$PNo, no, $w2I'm just talking to myself.$K$PSay, $w2you're a knight escorting
the princess of Crimea, no?$K$PIt's such an honor to meet someone
like you! Such a noble bearing!
Such grace!$K
$F1$PUm...it's actually not a big deal.$K
You and I are on the same team, after all.$w2
We shouldn't worry about class
or social standing.$K
$F3$POh!$w4 He's even more debonair than I
first imagined!$K
Thank you for being so kind.$w3 So...decent.$w5
So handsome and strong.$w4
So filled with manly virility...$K
$F1$PUm...$w4you're welcome?$K
$F3$PBy the way, $w2Sir Geoffrey.
I don't know Princess Elincia very well.
What manner of person is she?$K
$F1$P$FAOh! Are you interested in the princess?$K
$F3$POf course!$w4 I'm interested in any woman
who could become my romantic rival!$K
$F1$PWhat did you just--$K
$F3$PNothing! Nothing at all!$w3
Just talking to myself.
La da dum de dum...$K$PI just want to know her because she's...$w4
a dear person that we must protect!$w2
Could you tell me about her?$K
$F1$P$FSI can.$w4$FA Although...$w3putting it into
words is hard...$K
$F3$PWhy is that?$K
$F1$PThe words always sound false, yet...$w4
Hmm... The princess is like--$K
$F3$PYes?$w3 Yes?!$K
$F1$P$FSEverything about her is perfect.$w2
As her retainer, some might accuse me
of bias, but it is not so!$K$PShe is...$w4invaluable.$w2
She is the treasure of Crimea...$K
$F3$P$FA$Fh$w2Ooooh, I see how it is.$w4
You're in love with her!$K$PBlast! Blast and double blast!$w4
I'm always so unlucky with men!
Oh, vile cupid!$w4 Why do you mock me!$K
$F1$P$FAWait!$w3 Wait!$K
Calill!$w4 You misunderstood!$w4
I...er...$K
$F3$P$FS$FdNo, no, good sir knight! Spare me
your wicked tongue! I cannot bear
another lashing across my heart!$K$P...$w3Ah, well.$w4 It's a shame I can't have
him for my own, but...$w4I enjoy a good
love story all the same!$K$PI'll lend a helping hand to this naive knight
and lead him to his one true love!
Princess Elincia, your man is coming!$K    $R�w�i��b|$B�x���w�i|$<$F1$FCL_CALILL|$F3$FCL_GEOFFRAY|$F1$PAh!$w2 I see!$K
$F3$PSo that's why her existence was never
made public. Instead, she was taken to
the royal villa and raised in secret.$K
$F1$PIt's a rather complicated story for a...$w4
commoner like me to understand.$K$PTo grow up like that...$w3
Hidden from the eyes of the world.$K
$F3$PI don't think the princess minded.$K$PShe grew up with the love of her
parents and Lord Renning.$K$PShe didn't have to inherit the throne.
She lived happy and free, like a
country aristocrat.$K
$F1$PShe would probably still be happy if it
weren't for that Daein attack!$K
$F3$P...$K
$F1$POh, $w2I'm sorry, Sir Geoffrey.$w4
I was careless with my words.$K
$F3$PNo, you speak the truth.$K
$F1$P$FSI think your earlier story was even more
fascinating, though!$K
I can't believe that you are the son of
Elincia's foster mother and have known
Her Highness since childhood.$K
$F3$PThose early days were the best of my life.
Crimea was at peace, and the whole land
was filled with such beauty.$K$PThe princess was especially beautiful...
I remember chasing her and my sister,
Lucia, around the villa...$K$PBut alas!$w3 She is above my station!
I can never have her, and yet...$w3
I cannot forget the past!$K
$F1$P$FAShush!$w4 You can't wallow in your
own memories like that! You have to
live in the here and now!$K$PIt's true that times are hard.
We spend every day fighting,
covered in sweat and blood...$K$PBut there is always hope! You must
find what...$w3pleasures you can
whenever possible.$K
$F3$PCalill.$w4 You are right.$w2 I must not lose hope.$w2
I regret my outburst.$K
$F1$P$FSOh, that's all right.$K
Actually, I prefer a man who's a couple
links short of a full chain.
Makes him more interesting.$K
$F3$P$FSThank you.$FA For now, I will devote
myself to rebuilding Crimea.$K$PThough I think fondly on the princess,
I know that our time together will
never be as it once was.$K$PTo serve her for life and watch
her happiness from a distance...$w4
I can live with that.$K
$F1$POr you could just elope!$K$PKidding! I'm kidding.$w2 Besides, you're too
straightlaced for that.$w4 I know you.$K$P$FAIt's a shame. The two of you
would make a nice couple.$w4$K
$F3$P...$K$FS
You're a good person, Miss Calill.$K
$F1$P$FSOh, I know it!$w4 You can't just
find a smart, attractive woman like
this on every corner, you know?$K
$F3$PYou are indeed a gem among stones.$K
$F1$POh, no!$w3 Don't try to sweet talk me now!
It's far too late for such flattery!$K$PI know how you feel about the princess.
I wouldn't want to compete.$K
$F3$PMmm...$w4 That's unfortunate.$K
$F1$PHa ha ha!$w3 Well, at least we became
good friends.$K
Expose your heart to me without fear,
brave Sir Geoffrey! I'll stand by you
to the end.$K  $R�w�i��b|$B�x���w�i|$<$F3$FCL_CALILL|$F3$PHm?$w4 Hey, you there!$w2 Hold on!$K
$F1$FCL_NEPENEE|$F1$P...?$K
$F3$PWhy is a pretty girl like you covering her
face with an unfashionable helmet like that?
The world should see your beauty!$K$PIt's a travesty, I tell you!$w4
A veritable crime against nature!$w4
Oh, and where is your makeup?$K
$F1$PWell, I ain't really...$w4a makeup kind of gal.$K
$F3$P...Ain't?$w4 Where are you from, missy?$K
$F1$PI'm from...$w4around.$K
$F3$PSuch an unsociable girl!$w4 Well,$w2 you can't fool
Calill! I know why you're not much
of a talker.$K$PYou're embarrassed about your country
accent and low speech, are you not?$K
$F1$PH-how do you...$K
$F3$PHow do I know that?$w4 Well, I used to have
a...$w4friend$w3 with the same problem.$K
$F1$PYou? But you're from the city!$w4
And you're so--$K
$F3$P$FSElegant? Yes, indeed. Quite so.$w2
Oh, but I have an absolutly splended idea...
I'll teach you to talk like a true lady!$K$PHaving a rube like you around will just
make me miss the city, anyway.$w4
I'll even show you how to put on makeup!$K
$F1$PI... $w2I ain't--$K
$F3$PTsk! A lady never says such things!$w4
I can see this will be a bit of work...$w3
Well, you leave everything to me, missy!$K
$F1$P...$K    $R�w�i��b|$B�x���w�i|$<$F3$FS$F3$FCL_CALILL|$F1$FCL_NEPENEE|$F3$POh, $w2hello again!$w4 How are you?$w4
Have you been studying your grammar?
Hmm... Let's check your makeup.$K
$F1$PCalill--$K
$F3$P$FAShush! $w2Now look up...$w4 Higher!$w4 Hmm...$w2
Not bad. A little light perhaps...$w3
But this helmet has got to go!$K
$F1$PAw, that's all right.$w4 Everyone'll stare$w2 if I
take it off.$K
$F3$PWhy, my dear missy!$w4 Are you finally starting
to believe in your own beauty?$K
$F1$POh, I ain't--$K
$F3$PTsk! True ladies don't say "ain't"!
And it's a dastardly lie, anyway.$w4
Look at you! You're gorgeous!$K$PA splended face, plus that fantastic figure,
and yet you hide it under armor?
Oooh!$w3 I'm so jealous I could scream!$K
$F1$PBut I ain--$w3 I mean, I can't hold my head up
like you.$w4 I'm just a country girl.$K
$F3$PYes, it seems like a burden to always worry
about how others see you.$K$PBut I'll tell you a secret... People in the
city are cold! They don't care about
anyone but themselves!$K
$F1$PNot you, Calill!$w4 You're kind.$K
$F3$PMe?$w4$FS Oh. $w2Hm...$w2 I guess I am.$w4
Well, perhaps not everyone from
the city is so cold...$K$PDon't you give up, Nephenee! Trust me!$w4
You have charm! You'll be the talk of the
society pages in no time!$K
$F1$P$FSThank you.$K $R�w�i��b|$B�x���w�i|$<$F3$FCL_CALILL|$F1$FCL_NEPENEE|$F3$POh?$w4 What's in the bag?$w4
Did you run an errand, Nephenee?$K
$F1$PI saw some beedle nuts on the trees
near here so...$K
$F3$POh, I see. $w2And$w2 what, pray tell,
is a beedle nut?$K
$F1$POh, they're swell! We use the oil on the
shell to treat insect bites.$K
$F3$POh? I had no idea there was such a thing.$w4
We don't have such trees in the city...
My, country wisdom is amazing!$K
Oh, but listen to me ramble!$w2
May I sample one of your nuts?$K
$F1$PWell, sure but...$w4 Oh, be careful, Calill!
The shell is real sticky! Don't touch
it with your bare hands.$K
$F3$PAh, I see.$w4 But perhaps if I hold the top
and bottom edges of the shell like so...
The oil won't contact my skin.$K
$F1$PW-what? How did you...?$K
$F3$PMmm... Delicious!$K
$F1$P...$w3You're not from the city at all!$K
$F3$PShush! You didn't see anything!$w4
I'm a sophisticated urbanite, right?$K
$F1$P...$K
$F3$P$FcWhat?$w3 Surprised?$w3 Oh, come now.$w4
You're not the only one who doesn't
want to be known as a country bumpkin.$K$P$FdThat's why I know how you feel.$K
$F1$POh...$FS But...$w2now I know that I can
be like you if I work hard.$w3
That makes me happy.$K$PI will... $w2I will work hard, Calill.$K
$F3$P$FSHallelujah! She sees the light!$w4
Now you just have to find a good man
to bring back to your village!$K    $R�w�i��b|$B�x���w�i|$<$F1$FCL_CALILL|$F3$FS$F3$FCL_TOPUCK|$F3$PExcuse me, ma'am?$K
$F1$P...$K
$F3$P$FAUm...$w4 Excuse me, Calill?$K
$F1$PHmph! I won't answer unless you call me...$w4
A lady. A pretty lady!$K
$F3$PNuts to that!$K
$F1$PWell then, you can just forget it.$w4
I won't waste my time teaching
magic to a brat like you.$K
$F3$P$FSHey, pretty lady!$w3 Beautiful lady?
Would you please teach me magic?$K
$F1$PWhat a selfish brat! What about the spells
I taught you last week?$K$PI won't teach you anything new until you've
mastered those.$K
$F3$PThose?$w3 Pshaw! I aced them!$w4
Heck, I aced everything in this book!
I'm a magic genius!$K
$F1$PBoastfulness does not become you, dear.
And your brash tongue won't make
me teach you any faster.$K
$F3$PYeah? I'll show you!$w4 Um... I mean...$w3
Can you make sure I'm doing them right?$w4
Please?$w6 Pretty lady?$K
$F1$PFine, fine. Show me what you can do.
Sigh... So much work and so little time...$K    $R�w�i��b|$B�x���w�i|$<$F1$FCL_CALILL|$F3$FCL_TOPUCK|$F1$POh, my heavens! Tormod! Aaaah!$w4
Enough! That's enough!$w4
We're done for today.$K
$F3$POh, come on!$w4 Teach me more magic!
I won't catch the drapes on fire again,
I promise!$K
$F1$PNo way!$w4 By the goddess, I'll be lucky
to get out of here with my eyebrows
still affixed to my forehead.$K
$F3$PBut I can do better! I know it!$w4
I already learned fire, thunder, and wind!$K
$F1$PYes, yes, I'll admit that you're a quick
learner.$w4 And, truth be told,
you have a lot of raw talent.$K
$F3$PYeah, I knew it!$K
$F1$PBut you lack discipline! You're impatient.
And rash.$K$PYou can learn new spells all day,$w3
but you won't truly master any of them
until you know each one intimately.$K
$F3$PYou're just mad because I'm more talented
than you!$K
You don't want me to learn anything
because you know I'm the best!$K
$F1$P$FcOh, why did I ever agree to this...$w3
$FdNow listen here, child.$w4 And listen well.$K$PIf you keep up this half-baked spell casting,
you're going to have a serious
accident someday.$K
$F3$PAn accident?$K
$F1$PMagic doesn't react well when miscast.$w4
I've seen fingers get blown off...$w4
And you'll be lucky if it's just a finger!$K$PSometimes it's an arm or a leg...$w3
And in really unfortunate cases,
it can take a life!$K
$F3$PHeck! I'm not afraid!$K
$F1$PI didn't say YOUR fingers or YOUR life!$K
$F3$PWhat? You?$K
$F1$PMe, Commander Ike, anyone!$w4 We can't
afford to have you overshoot our enemies
and rain death down on us instead!$K
$F3$P...$K
$F1$PTormod, magic is unlike any other weapon.
It does not forgive.$K$PIf you lose concentration...$w4 If you hesitate...$w4
If you fail to respect it...$w4 People will die.
Friends...$w4will die.$K
$F3$PI'm sorry.$K
$F1$PThen study the basics.$w4 After all, you don't
want to be a burden to your friends
do you?$K
$F3$PNo!$K $R�w�i��b|$B�x���w�i|$<$F1$FCL_CALILL|$F3$FCL_TOPUCK|$F3$PHey, pretty lady!$w4 What do you think of
my magic now?$K
$F1$PHmm, let's see...$K
$F3$PYeah?$K
$F1$P$FSYou've worked very hard.$w4
I have nothing more to teach you.$K
$F3$P$FSWhooo-hoo!$w4 Now I'm a mage, too!$K
$F1$PYes, I suppose you could say that.$w2
You have inspired me, Tormod.$K$PYour passion makes me want to study more
of the arcane arts. I think I'll start learning
magic again.$K
$F3$P$FAWhat?$w4 Are there still things that you
need to learn?$K
$F1$P$FAHa ha ha! Oh, Tormod.$w4
I have only shown you the tip
of the magical iceberg.$K$PAnyone can learn that much with hard work
and practice. Maybe not as quickly
as you, but...$K$PWhether you can go further, however,
depends on your own essence.$K
$F3$PMy essence?$K
$F1$PThe abilities that you were born with...
or lack.$w4 Having a certain essence
is the key to mastering magic.$K
$F3$P$FSWh-what do you think?$w4
Do I have a magical essence?$K
$F1$PSorry, Tormod. But you and I,$w2
we're nothing special. Some talent,
yes.$w4 But not the true essence.$K
$F3$P$FAThen...$w2this is it? This is as far as I'll go?$K
I can't be the world's mightiest mage,
no matter how hard I try?$K
$F1$PWell, there is a way to improve magical
abilites beyond one's essence, but...$w2
even that has limits.$w4 And a price.$K
$F3$PWhat kind of way?$K
$F1$PYou let a spirit come into your body.$w4
It's called Spirit Charming.$K
$F3$PThat sounds crazy!$K
$F1$PSome would say so.$w4 Magic comes from
these spirits--from their interactions with
the natural world.$K$PIf you take that power into your body,
your magic will see a dramatic
and powerful improvement.$K$PIn plain language, you turn your body into
bait. You get better magic, and the spirit
gets...$w3you.$K
$F3$PW-what? It...$w4it EATS you?$K
$F1$PAs I understand it...$w4the spirit will
slowly consume your soul in
exchange for essence.$K$PSo I suggest you not make such a bargain
unless you're absolutely prepared.$K
$F3$PWho would do such a thing?$K
$F1$POh, there are many people...$w4
I'm sure the intelligence officer of this
mercenary group is one of them.$K
$F3$PYou mean that Soren fellow?$K
$F1$PYou know the mark on his forehead?$w4
That's what happens when you
cut a deal with a spirit.$K
$F3$PAre you serious?$K$PWait, I've seen those marks before!$w4
The old man in the desert who taught
me magic had one on the palm!$K
$F1$PMany magic users in Begnion and Daein
hide such marks. They fear being
confused with the Branded.$K
$F3$PBranded? What's that?$K
$F1$PNever mind that! Just listen to me.
Don't cut deals with spirits.
The price is too steep.$K
$F3$PBut I want to be strong! I want--$K
$F1$P$FSYou can still improve your magic
without making such a bargain.$K
Look, we're both nobodies in the big
scheme of things. Let's just try$w2
to help each other out.$K
$F3$P$FSOh...all right. I'll work hard to be the most
average mage I can be!$K
$F1$PHa ha ha!$w2 Now you're talking!!$K $R�w�i��b|$B�x���w�i|$<$F3$FS$F3$FCL_NEPENEE|$F1$FS$F1$FCL_CHAP|$F1$PWell, howdy, Nephenee! Isn't it a
beautiful day?$K
$F3$PMmm-hmm. It sure is!$K
$F1$PI bet your hometown is real busy now,
what with harvest season approaching
and all.$K
$F3$PYeah, I bet.$w4 I'm sure my brothers
and sisters are grumblin' at Ma
for making them help in the fields.$K
$F1$PHo ho! $w2All kids ever want to do is play.
I should know!$w2 Say, how many people
are in your family, Nephenee?$K
$F3$PI have two younger sisters and three
younger brothers. The boys are triplets.$w4
They just turned six years old.$K
$F1$PThat's too much for your mom to handle
all on her own!$K
$F3$PYep, I'm sure Ma chews 'em out every day.$w4
What about you, Brom?$K
$F1$PMy kids are a little older.$w4 I hope they're
helping Mother like they're supposed to...$K
$F3$PDon't worry 'bout it, Brom.$w2
I'm sure they are.$K    $R�w�i��b|$B�x���w�i|$<$F3$FCL_NEPENEE|$F1$FCL_CHAP|$F1$PWhere are those barracks anyway?$K
$F3$PHmm... I'm not sure.$K
$F1$PHow do these guys know where to go
without getting lost?$K$PMoving from one camp to the next every
day, never resting, bad food...
Oh, it's got me all worked up!$K
$F3$PIt's a war. There ain't nothin' you can do.$w4
We just have to get used to it.$K
$F1$PI guess you're right. You and I were
strangers to war before.$K
$F3$PI know.$w4 That's why I don't quite understand
what passes for normal around here.$K
$F1$P$FSI tell ya, it sure was tough when I
first volunteered!$K
For one thing, we militiamen are nothing but
a bunch of farmers and villagers.$K$PWe had courage and determination to spare,
but we sure lacked talent!$K
$F3$P$FSI know what ya mean, Brom!$K$PThere weren't even enough gear for us!
They gave me a bow and told me
to share it with another gal.$K$PBut neither one of us knew how to
use it, anyhow.$K
$F1$PYup! I hear you well!$K$PThe war broke out so suddenly,
the only decent training we got
was how to stand for roll call!$K$PEvery time we marched, people got lost
or strayed or fled. $w2We were losing
soldiers before we even saw the enemy.$K$PThat's why I don't feel bad about being
taken prisoner...$w4 But this army is
real good compared to my last one!$K
$F3$PWell, what did you expect?$w4
We're in a real army now.$K
$FAHorsefeathers!$w2 Where are those barracks?$K
$F1$POh, enough walking! My feet hurt!$w2
And my back is sore.$w2
Let's just ask someone.$K
$F3$PA-ask someone? Um... Fine. You do it!$K
$F1$P$FAWhat?$w4 What's wrong?$K
$F3$PI...$w4 I'm not used to talkin' with city folk.$K
$F1$PWhat are you afraid of?$w4
Just talk like you always do.$K
$F3$POh no! I-I'm a country girl!
They'll all set to laughin'...$K    $R�w�i��b|$B�x���w�i|$<$F1$FCL_CHAP|$F1$PHowdy, $w2Nephenee.$K
$F3$FS$F3$FCL_NEPENEE|$F3$PWell, hello there, $w2Brom.$K
$F1$PI was just talking to one of those
younger fellas.$K$PHe said you don't talk much to
other people.$K
$F3$P$FATh-that's because I'm a country girl and...$w4
I'm embarrassed.$K
$F1$PWhat are you embarrassed about?$w2
There's nothing wrong with country!$K
$F3$PYou know I have a heavy accent!$w4
They'll make fun of me. I can't
talk well like you, Brom.$K
$F1$P$FSOh, that's cow plop and you know it!$w2
Everyone in this army is so danged nice!
They wouldn't ever laugh at you!$K$PDon't be so uptight. Just pretend you're
back in your own village.$K
$F3$P...$K
$F1$PYou smile whenever we talk, right?$K$PAw, you have a beautiful smile.$w4
It's a shame that you hide it.$w4
Come on, try smiling now.$K
$F3$PUm...$w3all... All right.$K
$F1$PCome on now, $w2smile...$w4 Smiiiiile...$K
$F3$PAw, Brom!$w4 It's embarrassing.$K
$FSLike...$w2like this?$K
$F1$PThat's right! $w2That's it! Yee haw!$w4
That's the smile I want to see.$K$PYou're a good-looking girl, Nephenee!$w2
The young fellas in the company won't leave
you alone if you keep doing that!$K$PSay, why don't you find a nice guy here
and take him back to the village!$K
$F3$PS-$w2stop Brom!$w4
I'm embarrassed!$K  $R�w�i��b|$B�x���w�i|$<$F3$FCL_ZIHARK|$F1$FCL_CHAP|$F1$PHmm...?$w4 Hey, what are you doing?$K
$F3$P$FSHi, Brom.$w4 I'm just fixing my shoulder guard.$w4
See?$w2 It's starting to rip right here.$K
$F1$POh, yeah.$w2 You don't want to go into battle
like that!$K$PThis one time, I had a...$w3 Hey!$w4
How do you know my name?$K
$F3$PHm?$w2 Oh, I'm just good at remembering
names and faces. Natural talent, I suppose.
Sorry if I got a little fresh with you!$K$PLet me introduce myself. I'm Zihark.$w4
How do you do, Brom?$K
$F1$P$FSHowdy!$w4 Nice to meet you!$K$PFixing a shoulder guard is tough work.$w4
What do you do when you're not at war?
You work in leather?$K
$F3$PNope.$w4 Just a swordsman.$K
$F1$PHuh...$w4I didn't know swordsmen could fix
something like this.$w4 That's quite a skill!$K
$F3$PI taught myself.$w4 Mercenaries don't make
good money, you know. I can't afford to
visit a tradesman...$K$PAnd...$w3done!$w3 All right, that should hold.$K
$F1$PWow...$w4 Isn't that something? I have to
teach my youngest son how to do that!$K
$F3$PHow many children do you have, Brom?$K
$F1$PI've got five sons and three daughters.$w4
In fact...my oldest girl is just about
your age.$K
$F3$PI figured you would have lots of children.$K
$F1$PHow did you figure that?$K
$F3$PJust look at you, Brom.$w2 You're a big man
with a big heart. The perfect daddy!$K
$F1$PY-$w2you think so?$w4 Oh, stop!$w3
You're embarrassing me!$K    $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_ZIHARK|$F3$FS$F3$FCL_CHAP|$F3$PHowdy, Zihark.$w4 I had a good time
with you the other day.$K
$F1$PHeya, Brom!$K$PYou're quite the talker! You made me laugh
the whole time.$w4 I haven't had such a
fun meal in a long time.$K
$F3$PAw, shucks! That makes me happy that I
invited you out.$K
$F1$POh, yeah. $w2This is my share.$w4 Take it.$K
$F3$PDon't worry about it.$w4 I invited you,
remember?$w4 It's on me.$K
$F1$PI can't let you do that, big guy.$K
You invited me on short notice, and I
didn't have any cash on me.$w4 But today
I'm ready, so let me pay for my half.$K
$F3$P$FAWell, even if you want to, I don't$w4
even remember how much I paid.$K
$F1$PThe total came to four fifty.
I'll give you two and a quarter,
and we can call it even.$K
$F3$PWell, aren't you a fine young man!$w4
You've got a good memory,
and you can do math!$K
$F1$PThat's just my nature.$w4 Most mercenaries
are basically lazy and sloppy...
I think I drive them crazy.$K
$F3$P$FSNah.$w3 That just makes you even
more of a true man!$K$PI bet you're pretty popular with
the young lasses, eh?$w4 Eh?!$K
$F1$PUm...$w3not...$w5really.$w3 It would take an...$w3
eccentric girl to love a guy like me.$K
$F3$P$FAI tell you, Zihark,$w3 sometimes I don't get
this world.$w4 I mean, even a simpleton
like me has a family!$K
$F1$PHa!$w4 I'm telling you, Brom, you're a
good man.$w4 Trust me on this one.$K
$F3$P$FSOh, I have an idea! And it's a humdinger!$w4
You should marry my daughter!$K
$F1$P$FAUm...$w4
Er...$w6
I should what?$K
$F3$PI don't mean to sound like a proud poppa,
but they're all great girls!$K$PAnd if I like you this much, I'm sure that
my daughters will like you, too.$K
$F1$PHeh...$w4 Hey, enough with the jokes, Brom...$K
$F3$PHow about it?$w2 I think you'd be a
great match for the oldest one!
You're both the same age!$K
$F1$POh, boy...$K  $R�w�i��b|$B�x���w�i|$<$F1$FCL_ZIHARK|$F3$FS$F3$FCL_CHAP|$F3$PSo, anyway...$K$PMy oldest girl is well built!$w4 Actually,
she's about my size.$w4 But don't worry!
She can still work the fields like a man!$K$PI'm sure you'll love her!$K
$F1$PUm...$w4she sounds...$w4lovely.$K
$F3$P$FAStop giving me such halfhearted answers
and$w3 start listening!$K$PI'm talking about the girl who is
going to be your future wife!$K
$F1$PBrom, listen...$w4 I didn't tell you this
the other day, but...$w4 I have no
intentions of getting married now.$K
$F3$PWhat?$w4 Aw, shucks! Why not?$K
$F1$PI had...$w3 I had an important girlfriend before.$K$PWe couldn't be together because
of...complicated reasons...$w4
But even now I still think about her.$K$PI can't get her out of my mind.
$FSI appreciate your kindness, but...
Anyway, that's why.$K
$F3$PI see.$w2 That's a real shame...$K
$F1$PBut I tell you what!$w3 The idea of joining
your family was quite appealing.$K
$F3$PHmm...$K$FS$PThen how about my second-oldest girl?!$w4
She's a little younger, but don't let
that worry you too much!$K$PShe's a sweetheart, I tell ya!$w4
Why, once when the cow got loose,
she lifted it right up and hauled it back...$K
$F1$P$FANo! Wait!$w3 That isn't what I meant...$w4
Aw, nuts.$K  $R�w�i��b|$B�x���w�i|$<$F5$Fh$F5$FCL_GATRIE|$F5$P...Huff...$K$w5
$F5$P...Puff...$K$w5
$F5$P$FdMaybe I should...$w4
Oh! Or then again, I could...$w5
Hmm...$w4 No, I won't do that...$K
$F4$FCL_CHINON|$F4$PHey.$K
$F5$FD$F1$Fh$F1$FCL_GATRIE|$F1$PHm?$Fd Oh, hey, Shinon!$K
$F4$PWhat in the heck are you doing?$w4
It's really annoying.$K
$F1$PShhh! It's a secret!$K
$F4$PWhatever.$w4 See you around.$K$F4$FD
$F1$PW-$w2wait!$w4 I'm just joking!$w4
Stop being so mean and listen
for a second!$K
$F3$FCL_CHINON|$F3$PI will if you buy dinner tonight.$K
$F1$PMmmm...$w4 Oh, all right. But you better give
me good advice!$K
$F3$P$FSOf course, of course.$w4
So, what's on your mind?$K
$F1$PI'm thinking about the reward that we're
going to get. I'm not sure what to
do with it.$K
$F3$P$FAUp to you.$w3 Spend it however you please.$K
$F1$PBut every time I spend money,
you give me a hard time!$K
$F3$PI do?$w4 How?$K
$F1$PWhat about the other day, when I bought
the Ultimate Shield?!$K
$F3$PGatrie, that was a castle gate.$w6
Hey, did you ever give that back?$w3
That guard thought you were a thief.$K
$F1$PAnd remember the SpeedBring 4000?
That secret elixir that boosts speed just
by sprinkling it over your body--$K
$F3$PYou mean that putrid snake oil?$w4
You dumped the whole bottle on your
head without smelling it first.$K
$F1$PBut that wonderful little potion worked!
I DID move faster!$K
$F3$PYou moved faster because thirty stray dogs
were chasing you.$K
$F1$PSee!$w4 You're giving me a hard time again!$K
$F3$POh, did I hurt your feelings?$w4 Wow,
it sure is fun to tell you the truth and
have you grumble at me in return.$K
$F1$PNo, no! I didn't mean to...$w4
Er...$w4 Sorry...$K
$F3$P$FSHmm... You're too honest sometimes...$K
$F1$P$FSHee hee! $w2You're embarrassing me!$K
$F3$PAll right, let's go eat!$w4
Now that's spending wisely!$K$F3$FD
$F1$P$FAYeah, let's...$w4 Wait a minute, Shinon!
You didn't help me at all!
This isn't part of the deal!$K $R�w�i��b|$B�x���w�i|$<$F3$FCL_GATRIE|$F5$FCL_CHINON|$F3$PSay, Shinon!$K
$F5$PI'm busy.$w4 Come back later.$K
$F3$PI really want to ask you something.$w6
Right now!$K
$F5$PNo, Gatrie.$K
$F3$PI'll pay for dinner again.$K
$F5$PGet lost.$K
$F3$PWe'll eat somewhere more expensive tonight.$K
$F5$PAppetizers?$K
$F3$PSure!$w4 You can order anything you want!$K
$F5$FD$F1$FS$F1$FCL_CHINON|$F1$PAll right, then.$w4 I think I can spare some
time for my brother-in-arms.$K
$F3$P$FSAw, thanks Shinon! I owe you one!$K
$F1$P$FA...$w5Well? What do you want?$K
$F3$PWell, $w2actually...$w4 What I need to ask you is...$K
$F1$PSpit it out!$K
$F3$PWell, it's...$w4 Oh, I don't know.$w4
Do you really want to hear it?$K
$F1$PDo that one more time, and I'll
put an arrow through your eye!$K$F1$FD
$F3$P$FAW-$w2wait!$w4 Just a minute!
$w4I'll tell you now...$w5
Are you ready?$K
$F1$FCL_CHINON|$F1$PAaaaaarrrgh!$K
$F3$P$FSIhaveanewgirlfriend!!!!$K
$F1$PA new girlfriend?$w4 Is she blind or something?$K
$F3$PI met her in town yesterday!$w4
She's soooo cute!$w4 I'm telling you,
she's the one for me!$K
$F1$P$FSWell, I'm happy for you.$w4
Oh, $w2I see.$K$PYou want to ask me what kind of gift
to give her, right?$K
$F3$PTee hee hee!$w3 Yeah, that's right!
What should I give her?$K
$F1$PI know everything there is to know about
gift giving, my friend.$w4 I'll tell you all
about it over a fine meal.$K
$F3$PPlease do,$w4 romance master!$K    $R�w�i��b|$B�x���w�i|$<$F5$FCL_GATRIE|$F5$P...$K
$F3$FCL_CHINON|$F3$PWhat the...?$K
$F5$P...$K
$F3$PWhy are you standing out here
like a scarecrow?$K
$F5$FD$F1$FS$F1$FCL_GATRIE|$F1$PHey, $w2Shinon.$w3
I'm just waiting for my girlfriend.$K
$F3$P$FSOh.$w3 Her.$w3 Right.$w4
You're still dating?$K
$F1$PYep! And when I gave her the gift
that you picked out for me...$w3
boy, was she happy!$K$PIn fact, I'll tell you a secret...$w5
we're getting married!$K
$F3$P$FAAren't you rushing it a little?$K
$F1$P$FAOh, no! You see, she's terminally ill.
She has Brain Stones. It's really bad.
She only had a few days left to live.$K$PAnd since she didn't have enough
money to pay for the treatment...
I thought it was time to spend my gold!$K
$F3$PYou paid for it?$K
$F1$P$FSYep! $w2Every last gold piece! And guess what?$w2
The treatment cost exactly as much
as I had!$K$PIt's fate, isn't it?$w4 Oh, with a coincidence
like this, I know that we're meant for
each other!$K$P$F3$P...$w4You've got to be kidding me.$K
$F1$PBetween the war and her illness, times
are pretty rough, so we decided
to have the wedding right away.$K$P$FAI was supposed to meet her here and then
introduce her to the company. I wanted to
do it in style, you know?$K$PBut she's not here yet...$w4 Oh, wait is that...$w4
No, that's a horse.$w4 Hmm...
I'm a little worried.$K$PI went to her house this morning,$w2
but I think I got the address wrong.$w2
All I found was an abandoned shack.$K$P$FSBut $w2it'll be all right!$w4 She knows I'm with
this army, and...$w4 And...$K
$F3$PGatrie?$w4 She's not coming.$w2
You've been conned.$K
$F1$P$FAWhaaat!?$w4 No, I don't believe it!$w5
She's such a fine girl! So pure and kind!$w3
She'd never hornswoggle ol' Gatrie!$K
$F3$PHow can someone with only days left to
live manage to walk the streets looking
for a knight with lots of money?$K
$F1$PBecause...$w4 Because she needed to meet me!
It's fate!$w3 Remember?$K
$F3$PThen why isn't she here?$K
$F1$PB-because... Um...$w5
Wolves?$K
$F3$PNo, Gatrie.$w3 It's not wolves.$K
$F1$P$FSOh...$w3 Hee hee!$w5 Hee hee hee!$w4
I guess ol' Gatrie...$w4 Whaa ha ha!$K$PI guess I got taken again! Whaa ha ha ha...$w3
Whooo! Oh man, I'll never learn.$K
$F3$PTell me what she looks like.$K
$F1$P$FAHuh? Why?$K
$F3$PAll your money? That's going too far.
I'll find her and...$w4get it back.$K
$F1$PWell...$w4 $FSNah,$w2 that's all right.
I mean,$w4 it's my fault anyway.$K
$F3$PAre you sure?$w4 She must be laughing her
head off by now.$K
$F1$PWell, at least it was a cute little head.$K
$F3$P$FcSigh...$w4$Fd You're hopeless, Gatrie.
You know that?$K
$F1$PYeah, I know. But I don't mind so much.$w4
It makes me kinda charming, right?$K
$F3$PWell, I guess you don't have to worry about
what to do with your money anymore.$K
$F1$PYeah, that's right.$w3 Hey, if you look at it
that way, it's a blessing in disguise!$K
$F3$PLet's go find a watering hole with some
cute waitresses.$w4 What do you say?$K
$F1$PHey, that's a great idea! $FAOh, but...$w4
I don't have any money.$w4 Sorry, Shinon.$w2
Maybe some other time.$K
$F3$PForget it.$w4 It's my treat.$K
$F1$PAre...$w2are you sure?$K
$F3$PYep.$K
$F1$P$FSHee hee hee!$K
$F3$PWhat's so funny?$K
$F1$PSupper on your gold piece?
$w3This is my lucky day!$K
$F3$P$FSHopeless.$K    $R�w�i��b|$B�x���w�i|$<$F0$FCL_JANAFF|$F0$PHo!$w4 You there! Halt!$K
$F6$FCL_CHINON|$F6$P...$K$F6$FD
$F0$PHey, $w2did you hear me? I said halt!$K
$F4$FCL_CHINON|$F4$PWho are you?$K
$F0$PI'll ask the questions, thanks.$w4 Hmmm...
I haven't seen your face around here before.$K$PAre you a new recruit?$w4
State your name and unit.$K
$F4$PI don't have time to answer questions
from ignorant half-breeds.$K
$F0$PW-what?$w4 What did you call me!?$w3
Hey! I'm talking to you, jerk!$K
$F4$PSay that again...$w4$FS Go ahead.
It'll be the last thing you ever say.$K
$F0$P$FSI'm not afraid of you, human!$w2
Crossing me is the worst decision
you'll ever make.$K
$F4$P$FA...$K
$F0$P$FA...$K
$F4$PYou're lucky, half-breed.$w2
I'll let you go this time.$K
$F0$PPah! It's me who's letting you go.$w4
And don't forget it, human!$K    $R�w�i��b|$B�x���w�i|$<$F4$FCL_JANAFF|$F0$FCL_CHINON|$F0$POh, look, it's the half-breed birdbrain.
What a pleasant surprise.
Peck anyone lately?$K
$F4$PDon't start with me, you human jerk.$K
$F0$PI hear you're a bodyguard for the king
of Phoenicis. Not a bad gig...$w4
considering how scrawny you are.$K
$F4$PI hear you knew Greil for ages.$w4
They say he betrayed his men and aided
Daein before fleeing to Crimea.$K
$F0$PAre you calling him a traitor?!
Dastard! You'll die for that!$K$PNo...$w4 I'm not going to do this. I'm a true
mercenary.$w4 I'm won't give you
the satisfaction of a free fight.$K
$F4$P...I don't get you, human. You have
no clan and no master...$w4
What are you fighting for?$K
$F0$PI fight to live. That's all.$w4 Doesn't everyone?
It's not like people kill each other for fun.$K
$F4$PYou don't?$K
$F0$PWhat?$K
$F4$PYou don't kill for fun? You don't enjoy it?$K
$F0$PNo.$w3 Why, do you?$K
$F4$PI thought you humans...$w3liked to kill.
That's why you make weapons.
Why you hunt animals for sport.$K
$F0$PHa!$w2 We make weapons to protect
ourselves from you half-breeds!$K$POnly wealthy bluestockings with too much
time on their hands hunt for sport!$K
$F4$P...$K
$F0$PMan, what an idiot...$K$F0$FD
$F4$PWait!$w4 I have more questions!$w4 Rrrr!$w2
Human jerk!$K $R�w�i��b|$B�x���w�i|$<$F0$FCL_CHINON|$F3$FS$F3$FCL_JANAFF|$F3$POh. $w2There you are.$K
$F0$P...$K
$F3$PShinon, right?$w4 Do you have a moment?$K
$F0$PHuh?$w2 Oh, it's the half-breed birdbrain!$w2
Life is full of surprises, and not all of them
are the good kind.$K
$F3$PDon't lash out at me, you huma...$w4
Er...$w4 I'm sorry about the other day.$K
$F0$PY-you're what?$K
$F3$PI misunderstood the beorc. I thought all
beorcs liked killing, and that we could
never learn to live with one another.$K
$F0$PWhy did you join Ike's army if you feel
that way?$w4 Did the king order it?$K
$F3$P$FANo.$w4 The relationship with our king is not
one-sided like that.$K$PIf we do not deem the king's orders to be
right and just, we will not obey them.$K
$F0$PThen why did you join?$K
$F3$P$FSCommander Ike saved one of my friends
in Serenes.$K$PThough my first duty is always as
Prince Reyson's bodyguard, I also
hope to return the favor.$K$PI trust the commander. I...$w3like him.$K
$F0$PHa! At least someone does.$K
$F3$P$FAHm?$K
$F0$PI've always hated Ike. He gets everything
handed to him and takes it all for granted.$K
$F3$PBut that's not his fault, is it?
One can't decide their parentage.$K
$F0$P...$w4Nah, I suppose it's not his fault.$w4
But you know what?$w2 It's my choice
to feel this way, so I'll keep doing it.$K
$F3$P$FSHeh. You've got that right.$K
$F0$PWait, wait.$w4 Why am I talking about this
stuff with you?$K
$F3$PYou know what, Shinon? You kind of...$w4
You remind me of me when I was young.$K
$F0$PHuh?$K
$F3$PI used to be quite the daredevil before I
grew into adulthood.$w4 Nothing ever
seemed to please me.$K
$F0$PHow old are you, anyway?$K
$F3$P$FAI'm a bit over 110 years old.$K
$F0$PWha--?!$w4 You half-br...$w3you guys
must have a different way of
counting than us humans.$K
$F3$PDon't spring, summer, fall, and winter
make a year in your calendar, too?$K
$F0$PSo if I'm twenty-seven,$w4 you must be at
least...$w4eighty-five years older than me!$K
$F3$PIndeed. So give me some respect,
you young pup.$K$P$FSIf you run into trouble in the future,$w2
come see me.$w4 I'll give you the kind of
advice that only an elder can give.$K$F3$FD
$F0$POh, $w2hey!$w4 Hold on!$w4
Um...$w4tell me more about your life.
You've seen a lot, you know?$K $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_LOFA|$F1$PUncle Shinon!$w4 Wait, Uncle Shinon!$K
$F3$FCL_CHINON|$F3$PWhat do you want, $w2Rolf?$K
$F1$PTee hee hee!$w4 Look at this!$K
$F3$PWhy are you showing me this?$w4
It's just a piece of bent wood.$K
$F1$P$FANo, Shinon. $w2It's a bow!$K$FS$PYou gave me my first bow, and I wanted
to return the favor!$w4
I'm making it one whittle at a time.$K$PI know it's not exactly the best-looking
weapon out there, but...$w3
I hope you'll use it!$K
$F3$PMeh. Maybe if I overhauled it...$w3
I may be able to...$w3call it a...$w3bow.$K$PThis thing is going to break the first time
I fire it!$w4 You want me to be unarmed
on the battlefield? Is that it?$K
$F1$P$FAI... $w2I don't--$K
$F3$PLook, $w2to begin with, you used the wrong
kind of wood.$w4
This is much too hard and inflexible.$K$PRemember the bow I made for you?$w2
It didn't look like this, did it?$K
$F1$PB-but...$w4 I worked so hard!$w4
It should be just like yours!$K
$F3$PNot even close.$K
$F1$PN-not...not even...$w3 $FcWh...$w4
Whaaaaaaa!$w4
Whaaaaaaaaaaaaaaaaa!$K
$F3$PAh, crud.$w3 Don't start bawling!$w4
Look, let me give you a quick lesson.$K
$F1$PWhaaaaa...$w3$Fd$FS Really!?$w4 Promise?
Oh, I'm so happy! Yay! Yay!$w3
I love you, Unkie Shinon!$K
$F3$PYeah, yeah, it's a promise.$w3 Now quit
clinging to me like a lost dog.$w4$FS
Hey, seriously!$w3 Rolf...!$K    $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_LOFA|$F3$FCL_CHINON|$F1$PLook, look, $w2Uncle Shinon!$w4
Doesn't it look like a bow now?$K
$F3$PI guess you could...$w3categorize it as a bow.
Maybe.$w4 If you closed your eyes.$K
$F1$PSo will you use--$K
$F3$PNo way!$w4 I don't want to die just yet.$K
$F1$P$FAWha...$w4 Whaaa...$w4 Oh, fine!$w4
I'll just use it myself.$K$F1$FD
$F3$POh, for the love of... Rolf!$w3 Wait!$K
$F1$FCL_LOFA|$F1$PWhat?$K
$F3$PGive me the bow.$K
$F1$P$FSDid you change your mind?$K
$F3$PYeah.$w4 I suddenly got this...$w3uh...
weird urge to take it.$K
$F1$PReally? All right! Whooooo!$w4
Here you go, Uncle Shinon!!$K
$F3$PThanks.$w4 Um...see you later.$K$F3$FD
$F1$PWow, $w2I bet Uncle Shinon will just love
my bow! It'll be his favorite bow ever!$K$PBut I wanna see him fire it...$w4 I know!
I'll follow him.$w4 Tee hee hee!
Here I come, Uncle Shinon!$K $R�w�i��b|$B�x���w�i|$<$F1$FCL_CHINON|$F6$FCL_LOFA2|$F1$PGet over it, Rolf.$K
$F6$P...$K
$F1$POh, come on!$w2 It was in your best interest.$K
$F6$P...$K
$F1$PPsh!$w4 What a stubborn brat. If you're going
to be like that, I'll just leave.$K
$F6$PYOU THREW MY BOW AWAY!!$K
$F1$PListen, Rolf.$w3 If I had let you onto a
battlefield with that bow, you would
have been killed.$K$PI prevented your death in advance...$w4
Heck, I saved your life!$w3
You should be thanking me.$K
$F6$FD$F3$FCL_LOFA|$F3$PI know that, Uncle Shinon, but...
I put my whole heart into that bow!
I just wanted you to be happy.$K$PThe first time I went into battle,
my feet were shaking because
I was so scared.$K$PBut then I held the bow that you made
for me, and it gave me strength.$w3
And I said, "Rolf! You can do this!"$K$PI learned absolutely everything from you!
That's how I've stayed alive
this whole time.$K
$F1$P...$w4But why on earth...$w3 Why would you
depend on me like that?$K$PI mean, I just I taught you how to fire
the bow on a whim.$K
$F3$P$FSBut it still made me happy!$FA$w3
My brothers never let me do anything.
They still treat me like a baby.$K$PIf you hadn't taught me archery,$w3
I'd be sitting at home right now!$K$PI hate waiting around while everyone is
fighting for their lives.$w4 I mean, we all
made it back yesterday but...$K$PWhat about today?$w4 Or tomorrow?$w4
At home, all you do is wait and wait
and feel terrible.$w4 I hate it!$K
$F1$PRolf, I know how you feel, but...
adults don't want to send kids to
a battlefield if they can help it.$K$POnly a complete madman wants to be
involved in the death of someone else.$w4
Especially if it's a kid.$K$PBut the sad thing is, it's more about
making ourselves feel better than
saving the life of another.$K$PThe fear of being responsible for a death
is always in the back of our minds, so we
try to lessen the guilt as much as possible.$K$PHumans...$w3most humans...$w5feel the
pain of others.$w4 Holding that back
is a lot harder than you think.$K
$F3$PWow. I never thought about that.$K
$F1$PIt's a rough lesson to learn.$w4
Bah! $w2I hate adults like nothing else.
All ego and pride...$K$PKids live a more honorable existance.$w4
But you're growing up fast. So the sooner
you learn to survive, the better.$K
$F3$P$FSSo that's why you taught me archery,
isn't it?$w4 It wasn't just a whim!$K
$F1$P...$w4Well...$w5
Maybe...$K$FS$Fc$PBut if that's what you want to think,$w2
$Fdand it puts you in a good mood,
it's fine by me.$K    $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_DALAHOWE|$F1$PLadies and gentlemen! Gather 'round!$w4
Get ready for Devdan's fantastic show!$K
$F3$FS$F3$FCL_LARGO|$F3$PAh, a street performer!$w4 Could be fun.$w4
Hmm...$w3 Looks like I'm the only one here...
Well, I'll check out the show, anyway.$K
$F1$PHo ho! Step right up...$w3and be amazed!$w4
First, Devdan draws a picture like so...$w4
$FcHum de dum...$K$P$FdVoila!$w2 All done!$w4
This is Devdan's friend...$w4 Nadved!$K
$F3$P$FANadved? $w2Waaaait a minute.$w4
This is just a sketch of some
stupid stick figure!$K
$F1$PAh! You are wrong, young one.$w4
Listen carefully...$w3and be amazed!$K
$F3$PHuh?$w5 Listen to what?
...$w4 Aw, you're crazy!$K
$F7$FCDUMMY|$F7$PHellooooooooo...$K
$F3$PWhat the...?$w4 W-who was that?!
Your lips didn't move, but I heard
something! What's going on here?$K
$F1$PThat was Nadved!$w4
Say hello to Largo, Nadved!$K
$F7$PHellooooo, Laaaaaargooooo...$w4
Whooooooooo!$K
$F3$P$FSYaaaaaaa!$w4 I mean...$w3um... Wow!
That's pretty incredible!$w4
Can it do anything else?$K
$F1$PBut of course!$w4
For Nadved's next trick...$K    $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_LARGO|$F1$PAh,$w2 what a great day! I think I'll
wander the streets and see what
trouble I can...$w4 Hello? What's this?$K$P$FAHm?$w4 Well, if it isn't Devdan's
friend, Nadved!$w4 Why are you
just lying in the street?$K
Here, let me pick you up...
Hey, Nadved! Speak!$w5 ...Speak!$w6
Speak, Nadved! I command it!$K
$F7$FCDUMMY|$F7$P...$K
$F1$POh, this is nonsense! Bah! How would
a piece of paper talk, anyway...$w5
Speak, Nadved!$w4 Speeeeak!$K$PGrrrrr! This makes me so mad!$w3
Fine, then! You don't want to talk?
I'll just crumple you up instead!$K
$F7$PAAAAAAAAAAAAAAAAAAAAAA!!!!$w3
WHAAAAAAAAAAAAAAAAAAAA!!!!$w6
GYYYYAAAAAAHAAAAAAAAAA!!!!$K
$F1$PYaaaaa! What the...?! N-no way!$w4
It screamed!$w3 Oh, I'm sorry!
Are you all right, Nadved!?$K
$F7$P...$K
$F1$POh, by the goddess...$w4 What have I done?
I'm a monster!$w2 A monster!$w4
...$w4I gotta dispose of the body!$K
$F3$FS$F3$FCL_DALAHOWE|$F3$POh, hello Largo!$w4 How are you today?$K
$F1$PWha--?!$w4 Oh, Devdan!$w3 Um...how are you?
I-it's such a nice day, and I was just...
AH! F-forgive me!$w4 Yaaaaaaaaaa!$K$F1$FD
$F3$P$FAHe ran away...$w4 Oh, poor young one.$w2
Perhaps Devdan is to blame for
showing you his trick.$K$PBut Devdan can't tell you how it's done,
because it is a...$w4secret...$w4
Oh, the shame of it all...$K    $R�w�i��b|$B�x���w�i|$<$F3$FCL_LARGO|$F3$PUm... Devdan? Do you have a moment?$K
$F1$FS$F1$FCL_DALAHOWE|$F1$PDevdan always has time for you.$K
$F3$PLook... I'm...sorry that I got scared
and ran off the other day.$K$PI've been agonizing over how to make it
up to you,$w4 but I can't think of anything
that'll make it right.$K$PSo I'll just...$w3apologize.
Sorry, Devdan.$w3
Sorry, Nadved.$K
$F1$PYou worried that much for us?$w4
Poor Largo!$w2 Nadved is fine!$K
$F3$PR-really!?$K
$F1$PI am Nadved's friend.$w4
And friends are always close by!$K$PI just have to draw a picture like so...$w3
$FcHum de dum...$K$P$FdSee! $w2It's Nadved!!$K
$F7$FCDUMMY|$F7$PLaaaaaaargoooooo!$w3
I miiiiiised yooooooou!$w3
Whooooooooooooo!$K
$F3$P$FSOh!$w4 It's you!$K
$FAI'm so sorry, Nadved!$w4
I put you through pain just
because I lost my temper.$K
$F7$PThaaaaat's all riiiiiiight,
Laaaaaargoooooooooo!$K
$F1$PNadved is right, Largo.$w4 We are all friends.
Friends forgive each other!$K
$F3$P$FSWhew! I'm so glad. $w2Thanks, you two!$w4
You're both good people! The best!$w4
Bwaaah ha ha ha haaaa!$K
$F1$PNo, no.$w2 You're the best, Largo.$w4
Let's stay friends! But first...come closer...$w5
Nadved wants to tell you something...$K
$F3$PUm...$w4yeah, all right. Let me just
take a step closer here, and...$K$PYAAAAAAAAAAAAAAAAAAAA!!$K   $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_DALAHOWE|$F1$PYoo-hoo!$w2 Hey there, little one!$w4
Devdan has something to tell you.$K
$F3$FCL_NEPENEE|$F3$PWhat...$w2is it?$K
$F1$PDevdan thinks that you look angry.
Why are you always scowling?
Small children will start to cry!$K
$F3$PYou...$w2think so?$K
$F1$PIt's frightening to look at you!$w4
You had better start to smile more...
or else!$K$PBeing too serious is a bad business.$w4
Keep it up and your life will end
much sooner than you like!$K
$F3$PUm...you're scaring me.$K
$F1$P$FAIs that right? Hmm...$w4 $FSWhat's your name?$K
$F3$PNephenee...$K
$F1$PWell then, Devdan will now teach
Nephenee how to laugh.$w4
Don't be shy! It will be fun!$K
$F3$PAll...$w3right...$w4 Please don't hurt me.$K  $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_DALAHOWE|$F3$FCL_NEPENEE|$F1$PI have something to tell you, Nephenee.$K
$F3$PAAAAH!$w4 Um...y-yes,$w4 Devdan?$K
$F1$PYou have that stern look again...$w2
You had better start to smile more...
Or else!$K$PRemember what Devdan taught you
the other day? You can laugh for
no reason at all!$K
$F3$PI'm trying! I promise! I really am...
See? Um...$w4 Heh heh...$K
$F1$PTrying?$w4 Oh, little one!$w4 All you have
to do is to laugh like Devdan. $w2Like this!$w4
Mua ha har hee ho hee hoo!$K
$F3$PWell, it's...it's hard to laugh when you're
sad...$w3and...terribly frightened.$K
$F1$PNephenee always says things like that.$w4
Talking in such a quiet voice. It makes
Devdan sad...$w4and upset!$K
$F3$PEep!$K
$F1$PBut more sad.$w4 Devdan once visited a
village that was home to a girl like you.
She was so good to poor Devdan...$K$P$FABut one day, $w2bandits came to
the village...$w3and they killed her.$K
$F3$PT-that's terrible!$K
$F1$PShe took herself too seriously. She should$w4
have stayed hidden with everyone else.$K$PInstead, she came out from hiding while
Devdan was fighting the bandits. She
thought she had to do something herself...$K$P$FSThat's why Devdan wants you to talk
more, and smile more, too! One day...$w4poof!
It could be too late for poor Nephenee!$K
$F3$PUm...C-Commander Ike!$w4 Titania?
Anyone...?$K $R�w�i��b|$B�x���w�i|$<$F3$FCL_NEPENEE|$F3$PUm... Hello, D-Devdan.$K
$F1$FS$F1$FCL_DALAHOWE|$F1$PMua ha har hee ho hee hoo!$w4
Nephenee never says hello first.$w4
That makes Devdan happy!$K
$F3$PI'm smiling! See!$w4 So...$w4happy...
$FSSmiling...so...hard...$K
$F1$P$FAIt is hard for Devdan to hear
Nephenee say such things...$K
$F3$P$FAI-I'm sorry--$K
$F1$P$FSDevdan loves to see people smile!$w4
That's why Devdan smiles, too.
$FABut seeing a pained smile is sad.$K$PYou try to smile because Devdan
asked you to,$w2 but you
are still full of sorrow.$K$PIt reminds Devdan of the dead child
that you heard about the other day...
The poor, dead child...$K$PDevdan is sorry, Nephenee.$w4
Let us speak no more of it.
I will get...upset.$K
$F3$PU-upset? D-don't do that, Devdan!$K
$F1$PMmmmm...$K
$F3$PMaybe I've been...uh...too negative!
$FSIf I think positive, I'll smile
a lot.$w3 Like you!$w4 See?!$K
$F1$P$FSOf course you will!$w4 A smile helps you
and your friends! Can you smile wider?
Here, Devdan will help!$K
$F3$PAh! Wait! No!$w3 Look, I got it!$w4
Smile, Nephenee...$w3 Smile big...$w4
Smile and back away...$K $R�w�i��b|$B�x���w�i|$<$F1$FCL_TOPUCK|$F1$PHmmm...$w2 I told him to
meet me right here. Where is he...?$K
$F3$FS$F3$FCL_DALAHOWE|$F3$PDevdan is here!$K
$F1$PWaaaaghhhhh!$K
$F3$PWhat's wrong?!$K
$F1$PGaaaah! Don't scare me like that!
My heart nearly exploded!$w4
There goes ten years off my life!$K
$F3$PDon't overreact, little Tormod.$w4
Devdan didn't scare ten years off your life...
Devdan thinks you are just stalling!$K$PBut now it's time to get to work.$w3
The commander asked us to work on
these weapons. We should get started.$K
$F1$PI'm the world's greatest mage! Why do I
have to do these stupid chores?$K
$F3$PBecause you will learn something.$K$PIt's important to know all about the
different kind of weapons you'll
encounter on the battlefield.$K
$F1$PHmmm...yeah.$w4$FS
Well, you have a good point there.$K
$F3$PMua ha har hee ho hee hoo!
All of Devdan's points are good!$K
$F1$PUm...$w3all right, then. I'll get started on
the swords!$K $R�w�i��b|$B�x���w�i|$<$F3$FCL_TOPUCK|$F3$PThat's it.$w2 I quit!$w4
I can't take any more of this cr--$K
$F4$FCL_DALAHOWE|$F4$PYou should not leave a job unfinished!$K
$F3$FD$F1$FCL_TOPUCK|$F1$PWaagghhh!$w4 Where did you come from?$K
$F4$FD$F3$FCL_DALAHOWE|$F3$PDevdan has been watching you...$w4
Mmm... Your wound has not been treated
properly. You will get an infection.$K
$F1$PAw, it's useless.$w4 I rub it with vulnerary
and dress it with a cloth, but it doesn't
do any good.$K$PI just need a priest to mumble some
magic words and wave a staff over it!$K
$F3$PGrrrr! You are a fool!$w3
That makes Devdan upset!$K
$F1$PHuh?$K
$F3$PYou can't always depend on others for help.
On the battlefield, you have to know
how to take care of yourself.$K$P$F1$PI see...$w4$FS
Hah! You do have a way with words.$K
$F3$P$FSPoor, lazy boy who knows nothing at all...
Here, hand over that bandage.$w3
Devdan will show you how it's done.$K
$F1$PThank you.$K   $R�w�i��b|$B�x���w�i|$<$F3$Fh$F3$FCL_TOPUCK|$F3$PAaaahhhhhh...$K
$F1$FS$F1$FCL_DALAHOWE|$F1$PDon't sigh, Tormod.$w4 It will only make
you more depressed.$K
$F3$P$FdOh, hello, Devdan.$K
$F1$P$FASo Devdan did not startle you?$w4
That's a bit of a letdown!$K
$F3$PIt's just not fair.$w4 It's like you
were born with a lance in your hand.
How can I compete with that?$K
$F1$PDon't be so hard on yourself. You've got
a lot of talent, Tormod.$K
$F3$PPlease don't flatter me.
I know how it really is.
Maybe I'm not cut out for magic...$K
$F1$PEveryone has a tough time learning.$K
$F3$PMaybe I'm just not any good.$K
$F1$PLearning something new takes patience.$w3
If you're always in a rush to get better,
you'll overlook important lessons.$K
$F3$PImportant lessons?$K
$F1$P$FSThink back on the first time you
used magic.$w4 How did you feel?$K
$F3$PHow did I feel?$w4 I was happy...and excited.
I'd never felt anything like it.$K
$F1$PDevdan knows that it felt good when you
started making progress in your training...
Right?$K
$F3$PYes...$w2it was fun.$K
$F1$PWhy do you think that was?$K
$F3$PI was happy because...$w4
Well, because I was getting stronger.$w3
I had the power to protect people.$K
$F1$PNever forget how that felt.$w4 Keep that
attitude, and you'll continue to improve.$K
$F3$P...$K$FS$PThanks, Devdan!$w4
You're always teaching me something
important!$K
$F1$PMua ha har hee ho hee hoo!
It is Devdan's responsibility to pass on
knowledge to the next generation.$K$PAnd you know what?$w4 You give Devdan
something in return, too...$K
$F3$PI do?$K
$F1$PHope.$w4
There's always something worth
fighting for.$K  $R�w�i��b|$B�x���w�i|$<$F5$FCL_ELAICE|$F3$Fc$F3$FCL_GATRIE|$F3$P$w2You there, young lady!$K
$F5$P...$K
$F3$P$FdHello? Yes, you...the cute one!$K
$F5$P...$K
$F3$P$FcOooh, I get it.$w2 Playing hard to get, eh?
Tee hee hee!$K
$F5$FD$F1$FCL_ELAICE|$F1$PUm...$w2 Are you...talking to me?$K
$F3$P$Fd$FSPhew, $w2I finally got your attention.$K$PAren't you a sly little minx!$K
$F1$POh...$K
$F3$PSo...what's your name, cutie?$K
$F1$PMy$w4 name?$w4 Well... It's Ilyana, but...$K
$F3$PIlyana, eh? That's a cute name.$K
$F1$POh...it is?$K
$F3$PI'm Gatrie. But I'm sure you already
knew that.$K
$F1$PUm...well, actually...$K
$F3$POf course, I'm sure you've heard all about
my victories on the battlefield. Oh, there
was that business with the dragon...$K
$F1$PExcuse me, I have to go.$K
$F1$FD$P$w5$F3$P$w2I know she'll never forget me!$w4
Ilyana... You will be mine!$K  $R�w�i��b|$B�x���w�i|$<$F1$FCL_ELAICE|$F3$FS$F3$FCL_GATRIE|$F3$P$w2Ilyana!$K
$F1$POh, hello...$K
$F3$P$w4I picked these beautiful flowers
just for you!$K
$F1$POh...$K
$F3$P$FAW-what? You don't like them?$K
$F1$PWell...$K
$F3$P$FSOh, good! So you DO like them!$K
$F1$PIt's just that...$w3 Um...$K
$F3$P$FA...No good, eh?$K$P$FSThen what about this broach? Isn't it
fashionable? I picked it up at a quaint little
curio shop I stumbled upon.$K
$F1$POh...$K
$F3$PThat's no good, either? Are you sure you
won't take it?$K
$F1$PWell... It's nice, but...$K
$F3$P$FA...$K$P$FSOh! So you love it, right?$w3
Just like you love big, strong knights?$K
$F1$PExcuse me...$K
$F1$FD$P$w5$F3$P$FAHmmm. $w2She's a tough one to swoon.
I'll just have to pour it on even thicker!$K
$FS$w2There's no way I'm going to
let such a gorgeous girl slip away!$K   $R�w�i��b|$B�x���w�i|$<$F1$FCL_ELAICE|$F3$FS$F3$FCL_GATRIE|$F3$PIlyana!$K$PI just found this exquisite seashell
on the shore. Isn't it stunning?
Here, why don't you take it?$K
$F1$POh...$K
$F3$P$FANot interested, are you?$K
$F1$PIt's not that--$K
$F3$P$FSYou don't want it, do you?$K
$F1$PNot really...$K
$F3$P$FA$w2Hmm, this tactic isn't working.$K$PTo be honest, I was thinking that if I gave
you something you liked, you might come
out to dinner with me sometime.$K
$F1$POh!$w4 I wouldn't mind joining you...$K
$F3$PFor dinner?$K
$F1$PYes...for dinner.$K
$F3$P$FSReally!?
Brilliant!$K$PI, Gatrie, will deliver you to the
finest purveyor of salacious
foods in all the realm!$K
$F1$PG-Gatrie...? Oh, that's right...
Now I remember...$K
$F3$P$FAHuh?$w4 Did you say something?$K
$F1$POh, nothing...$K
$F3$PHmmm...$w3$FS Well, $w2never mind.
I'll see you later!$K
$F3$FD$P$w5$F1$PGatrie...$w2Gatrie...$w4
Remember that name!$K$PHe's going to take me out
to the finest restaurant!
Tasty food... $w2$FS$FcOh, I can't wait!$K   $R�w�i��b|$B�x���w�i|$<$F1$FCL_ELAICE|$F3$FS$F3$FCL_LUCHINO|$F3$PWell, well... Look at this cute little thing.$w3
So you're a mage, huh?$K$PI'm Lucia. I'm a soldier in the royal
Crimean army, and I thank you
for joining our cause.$K
$F1$PI'm Ilyana...$w4
I'm with Greil's Merc...$w4
$FcOh...$K
$F3$P$FAWhat's wrong?$w4
Are you all right?$K
$F1$P$FhYes, don't mind me...$K
$F3$PLook at you! You're skinnier than
a sword edge! All this marching must
be hard on you.$K
$F1$P$FcI fall down sometimes...$w4
I just can't keep up.$K
$F3$PThat's no good!$w4 If that happens on the
battlefield, you're as good as meat.$w2
You've got to stay fit and battle ready.$K
$F1$PYes...ma'am.$K
$F3$PYou're sounding faint.$w4 Hang on.$w2
Don't collapse on me!$K$PHere, let me help you. Let's get you
back to your tent.$K
$F1$P$FhI can't move...$w4 Hungry...$w3so hungry...$K
$F3$PWait here. $w2Let me go fetch some
food.$K
$F1$P$Fd$FSReally...? You'd do that?$K
$F3$P$FSOf course.$w4 What do you think you can eat?$K
$F1$P$w4I'll take anything...$K
$F3$P$FA$w2All right. I'll try to find something big and
hearty to give you strength. Stay where you
are until I come back.$K$F3$FD
$F1$PThank you so much...$w2$K   $R�w�i��b|$B�x���w�i|$<$F1$FCL_ELAICE|$F3$FCL_LUCHINO|$F3$PAll right, Ilyana. $w2Start now.$K
$F1$PLet me give this a try...
Huuuufff... Haaaaaa...
Huuuffff... Puuufffff...$K
$F1$FD$F3$P...$K$PWait, Ilyana.$w4 Can you come back here
for a moment?$K
$F1$FCL_ELAICE|$F1$PYes?$w4 What is it?$K
$F3$PI know you're not feeling great... But I still
want you to do some running. Exercise is
important.$w3 Why not start out slowly?$K
$F1$PYes... I'll try.$w4
I... $w2I ran the best I could...$K
$F3$PHah!$K$PThat was supposed to be running?!$K
$F1$PWell...$K
$F3$P...Er... Listen, $w2Ilyana. I didn't mean to
be so harsh.$K$PNobody is born great at everything.$w4
It takes hours and hours of practice
to get better at something.$K$PSo don't feel bad when you don't
excel at something right away.
Is that clear?$K
$F1$PYes...$K
$F3$P$FSDon't worry. I'll work on it with you.$w4
Go and give it another try.$K
$F1$PAll right...$w4 I'll do my best...$K
$F3$PThen we can take a break. Perhaps you'd
like some water before you try again.$K
$F1$P$FSActually, I'm a little hungry...$K
$F3$PFood?$w2 No problem at all.
What would you like to eat?$K
$F1$PDo you remember that meal you made
me the other day? That was so tasty...$w3
I'd love that again!$K
$F3$PYou liked it that much, huh?$K
Then I'll set to work making you another
big helping! But...you'll have to run for it!$K
$F1$PIt's a deal. Thank you...$w2for everything.$K   $R�w�i��b|$B�x���w�i|$<$F3$FCL_LUCHINO|$F3$PWhere's Ilyana?$w4 I told her to wait
right here!$w4 Where did she run off to?$K
$F7$FCL_ELAICE|$F7$PLu...$w4 Lucia...$K$F7$FD
$F3$PIlyana!?$w2 Did something happen?$K
$F1$FCL_ELAICE|$F1$PNo...$w4 Just so...
Hungry...$w4 So hungry...$K
$F3$PHungry?$w4 Haven't you been eating?$K
$F1$PNo...$w4 Not enough...$K
I just had five helpings...$K
$F3$PWhat?!$K$PFive helpings?!$K
$F1$PYes... Oh, and I took Soren's lamb shank
when he wasn't looking.$K
$F3$PHow much do you usually eat?$K
$F1$PWhen I cook, I usually make...$w3
six or seven helpings...$K
$F3$PEr... You're not a laguz, are you?$K
$F1$PNo...$K
$F3$PListen, Ilyana.$w4 I've put you through some
hard training over the last few days,
and it got me thinking...$K$PThere is something seriously
wrong with you!!$K$PBut I can't leave you like this. You've made
it this far, and we'll get through whatever
it is together.$K
$F1$P$FSYes...$w4 That makes me happy.$w4
You make me delicious meals...$K$PYou're so beautiful and strong...$w4
I want to be with you, Lucia...$K
$F3$POh, $w2fine.$w4 We might as well go
get some food!$K
$F1$PYour cooking...
$FcI can almost taste it...$K
$F3$P$FS$w3You're always so hungry...$w4
All right, I'll make you whatever you want.
But you had better train hard!$w4$K
$F1$P$FdYes!$w2 Oh, I'm so happy!$K $R�w�i��b|$B�x���w�i|$<$F1$FCL_ELAICE|$F1$PAh...$K
$F1$FD$F3$FCL_MORDY|$F3$PYou look sickly.$K
$F1$FCL_ELAICE|$F1$PI...$w4 I...$w3know you...$K
$F3$PI am Mordecai. You are Ilyana.$w4
We have not met.$K
$F1$PYou're right... I keep to myself, mostly...$w3
Even though we're on the same side,$w3
I'm often forgotten.$K$P$FcAhhh...$w2 Whoa...$K
$F3$PMmm? What is wrong?$K
$F1$PI'm... I'm sorry.$w2 I got a little
dizzy, there.$K$Fd$PDon't worry about it.
It happens all the time.$K
$F3$PHmmm... You are skinny. Even for a beorc.
Can you fight?$K
$F1$PI can...$w3 Somehow.$K
$F3$PBut you are as thin as a paper.$w3
Won't the enemy tear you to shreds?$K
$F1$PThere's nothing I can do about my size.
When that happens...$w4 I'm ready...$K
$F3$PGrrr...$w4 I don't like the sound of that.$K$FS$PStay close to my side. I will keep your
skinny beorc body safe.$K
$F1$P$FSR-really? Thank you, Mordecai.$K   $R�w�i��b|$B�x���w�i|$<$F1$FCL_MORDY|$F1$PUrrrrggh!$K
$F3$FS$F3$FCL_ELAICE|$F3$PHello, Mordecai. Wow, are you carrying all
those crates by yourself? That's incredible!$K
$F1$P$FSGrrrrr!$w4 Count on me for a strong back
and a pair of paws.$w2 Uuuuuurrrrrrffffff!
These are the last ones.$K
$F3$PHow can you carry all those at once?$w4
I could never do that.$K
$F1$PEat big meals and get meat on your bones.
Then you can lift crates like me.$K
$F3$P$FAI would love to eat big meals... But I can't.
Because...well...$w2 I have no money...$K$PThat's why I faint all the time.$K
$F1$P$FAMmm? You go hungry because you
don't have money for food?
That shames us all.$K$P$FSIt will end now.$w4 Take my gold...
Go! Feast! Eat as much as you want.
Become fat and happy, little beorc.$K
$F3$PReally?$w4 Are you...$w3sure?$K
$F1$PYes.$K
$F3$PAnything?$w3 Anything at all?$K
$F1$PI would not lie to a hungry beorc.$K
$F3$P$FSThank you, Mordecai... I don't know
what to say... You're like an angel.$K
$F1$PMe? No...stop.$w4
You embarrass me.$K  $R�w�i��b|$B�x���w�i|$<$F3$FCL_MORDY|$F1$FS$F1$FCL_ELAICE|$F1$PThank you for your generosity
the other day, Mordecai...$K$PNobody has ever done anything
like that for me...$K
$F3$PDo not thank me. We are friends.$K
But you ate like a starved bear! A dozen of
me could not eat that much mutton stew!$K
$F1$PThe food was delicious.$w4
I could have eaten more!$K
$F3$PI would feed you again, but you ate
through all my beorc money.$w3
Where do you put all that food?$K
$F1$P$FAWell...in my stomach...$K
$F3$PYou are like the furry little squirrels that
live with us in the woods. Always stuffing
food in their mouths.$K$PHalf beorc, half squirrel. That's you.$K
$F1$P$FSHaha!$w2 Maybe you're right!$w4 Squirrels, huh?
That's cute.$K
$F3$P$FSSo...when do you hibernate?$K
$F1$P$FAHibernate? I don't hibernate!$K    $R�w�i��b|$B�x���w�i|$<$F6$FS$F6$FCL_WAYU|$F6$PHah! $w2Today is a good day. I'm feeling
lucky! Maybe I'll meet someone to duel...
Maybe my true archrival!$K
$F1$FCL_ELAICE|$F1$P...$K
$F6$FD$F3$FCL_WAYU|$F3$PAck!$w4 You scared me!$K$PHah! Sneaking up behind me like that...$w4
You're a crafty one!$K
$F1$PUm...sorry. Please let me pass...$K
$F3$PHuh?$w4 Oh, sure...$K
$F1$PExcuse me...$K
$F3$PSo, do you want to duel?
At dawn, perhaps? I love dueling at dawn!$K$P$FSAwww...never mind.$w4
$FAIt wouldn't be much of a challenge.$w2
You're looking a bit sickly.$K
$F1$PSorry...$w2 I'm just feeling weak.$K
$F1$FD$F3$PShe looks so...fragile. Maybe I should watch
her back. Just to make sure nothing bad
happens to her...$K$P$FSOh well...$w2back to sword practice!$K   $R�w�i��b|$B�x���w�i|$<$F1$FCL_WAYU|$F3$FCL_ELAICE|$F1$POh, $w2I remember you from the other day.$K
$F3$PHello...$K
$F1$PYou're staggering again.$w2 Is there something
wrong with you?$K
$F3$PNo... I'm fine. Really.$K
$F1$PBut you look sickly and ill.$w4
Why don't you go and see a priest?$K
$F3$PI'm quite all right. The last time I saw a
priest, he said I wasn't sick.$K
$F1$PHmm... $w2Are you sure you weren't
being bilked? Was he a real priest?$w4
You look like you're about to keel over.$K
$F3$PI'm fine.$K
$F1$PMeh. Have it your way...$w3
Can you even walk?$K
$F3$PYes, of course...$w4 I'll see you later.$K$F3$FD
$F1$PWhere are you going? That's a dead end!$K
$F3$FCL_ELAICE|$F1$PHold up for a moment. I'll come with you!
You'll never find anything without me.$K
$F3$P$FSThank you...$K    $R�w�i��b|$B�x���w�i|$<$F6$FCL_WAYU|$F6$PI can't seem to focus today. I sense my
foes out there, hiding in the trees and
snickering at me! Haaaa! Take that, foe!$K$PYou know, $w2I haven't seen Ilyana lately.$w4
I hope she's all right. $w2Hmm...$K$PWell, $w2can't do anything about it now...$w4
$FSI need to get back to practice.$w2
$FAOne...two...strike! One...two...stab!$K
Hey! What was that?$K
$F6$FD$F1$FCL_WAYU|$F1$PUgh! What did I just step on?
It feels...$w4squishy.$K
$F3$Fc$F3$FCL_ELAICE|$F3$P...$K
$F1$PAaaack! Why are you on the ground?!
Are you dead? Gravely injured?
Perhaps slightly wounded?$K
$F3$PNo, no...$K
$F1$PWell?$w2 What's wrong?$K
$F3$PI'm just...hungry.$K
$F1$PHuh? Hungry? Why don't you quit your
whining and have a biscuit?$K
$F3$P$FdSo...$w3hungry. Please...if you have anything...$K
$F1$PHold on a minute!$K$PDon't tell me you're always staggering
around and fainting because you
need a snack!$K
$F3$PYes... As soon as I finish eating, I get
hungry again. That's why I faint.$K
$F3$FD$F1$PWell, I don't have any food on me
right now.$K$P$w2I'll go get you something right
away, though. We can't have you
passed out on the ground like this!$K
$F8$FCL_ELAICE|$F8$PPlease...$w3don't leave...$K
$F1$PWhoa there!$w2 Let go!$w4
Hey! Stop trying to eat my foot!$K
$F8$FD$F2$FCL_ELAICE|$F2$PMmmm...$w4so...tasty...$K
$F1$PNo, no, no! I can't have you
feasting on my limbs!$K$PSomebody bring this girl some food!$w4
Anything, people! Old leather shoes,
fruitcake...anything!$K   $R�w�i��b|$B�x���w�i|$<$F1$FCL_ZIHARK|$F3$FCL_ELAICE|$F1$PUh...Ilyana?$w4 What are you staring at?$K
$F3$POh? Er...$w2 The bag on your hip.$K
$F1$P$FSIt's nothing special.$w3 I just carry
a vulnerary and some snacks in there.$w3
Why? Is there something wrong with it?$K
$F3$POooh...$w4 It smells delicious...$K
$F1$PReally? That's odd. It's just some
dried meat.$K
$F3$PDried meat! So...$w3savory...$w4
I'm just...$w2you know.$w4 I'm hungry.$K
$F1$PYou're hungry? But I just saw you
shoveling down some roast rabbit
a few minutes ago!$K$PYou may look frail, but you can
sure throw down the chow!$K$PWell, $w2I'm off. Talk to you later!$K
$F3$POh...good-bye.$K$F1$FD
$F3$PWhat am I going to do?$w4 I should have
told him I'm starving and nearly ready to
collapse from hunger pains.$K$PMaybe then he would have given me
some of his delicious-smelling snacks.
I need food!$K    $R�w�i��b|$B�x���w�i|$<$F1$FCL_ELAICE|$F3$FCL_ZIHARK|$F1$PEr...$w3 Hello...$K
$F3$P$FSHello, Ilyana.$w2 You're hungry again,
aren't you?$K
$F1$PNo.$w4 Maybe.$w4 Fine...yes. I'm starving!$K
$F3$PHow can you possibly eat so much and
still be hungry? Last night you swiped the
chicken wing right out of my hands!$K$PDoes casting a few spells really make
you that hungry?$K
$F1$PTo be honest, I don't know why I'm
so hungry.$w3 I'm never full. I always
get hungry as soon as I eat.$K$PNormally, I eat about as much food as five
people.$w2 Today was tough because I
only got enough food for three.$K
$F3$PWhat?!$w2 That's just...incredible!
That sounds like a serious problem.$K$PWell...good luck with that.$K$F3$FD
$F1$PEr...$w4 Excuse me?
Can you wait for a moment?$K
$F4$FS$F4$FCL_ZIHARK|$F4$PWhat?$K
$F1$PEr...$w3 Haven't you forgotten something?$K
$F4$P$FANow, let me think...$w5 Nope!
Didn't forget anything.$K
$F1$POh...$w3my mistake, then.$K
$F4$P$FSSee you later!$K$F4$FD
$F1$P...$K
Everyone gave me something to
eat but him...$K  $R�w�i��b|$B�x���w�i|$<$F1$FCL_ZIHARK|$F3$FCL_ELAICE|$F3$POh...$K
$F1$P$FSHi, Ilyana.$w4 I'm bumping into you all
over the place these days.$K
$F3$P$FS$w2Yes, you're right.$w4
...$K
$F1$PWhat's wrong?$w4 You look a little...
different today.$K
$F3$PReally? How so?$K
$F1$PYes, definitely.$w4
You're looking cuter than usual.$K
$F3$PReally?!$K
$F1$PYeah, definitely a little cuter.$K
$F3$P...$K
$F1$PYou're hungry, though. I can tell from
the feral look in your eyes.$w2$K
$F3$P$FAFeral?! Excuse me?$K
$F1$PYou're a bit of a celebrity among the
men in the unit.$K$PThey say you lure them in with your
cute face and then run off with
their snacks.$K
$F3$PThey do?$w3$K
$F1$P$FAOh, yes$w3 they do! You're a beef jerky
thief, aren't you? I know about the apple
pie incident, too. Yeah... I know your tricks.$K$PIs it true that you don't remember their
names, even after they buy you an
expensive meal?$K
That's just terrible.$K
$F3$PNo!$w4 It's just that...$w3 I collapse into a
coma when I get too hungry!$K$PThat's why I've got to accept
everyone's generous food offers.$K
$F1$PThen at least remember their names!
Even if you had ulterior motives, everyone
likes...$w2 Er...$w2 Is kind to you.$K
$F3$PSorry...$K
$F1$PDon't apologize to me.
You didn't take my apple tart.$K
$F3$PAll right.$K
$F1$P$FSWell, shall we get going?$K
$F3$PPardon me?$K
$F1$PYou're hungry, right? I feel bad about
preaching to you, so this dinner
is on me.$K
$F3$PAre you sure?$K
$F1$PI'm sure. I can't have you going hungry
on me. However, I'm not rich.
All I can afford is two dinners.$K
$F3$PThat's...so kind.$w4$FS
That should be enough.
I'm so happy!$K$POh, thank you so much... Um...
Er... Ike? No, wait! Um...
Bill? Lance? Sword guy?$K$P$F1$P$FAZihark.$K
$F3$P$FAZihark! Oh, I really appreciate it...$w4$K  $R�w�i��b|$B�x���w�i|$<$F1$FCL_ERINCIA2|$F1$PHmmm...$K
$F3$FCL_GEOFFRAY|$F3$PAre you looking for someone,
Your Highness?$K
$F1$P$FSGeoffrey. I'm glad you're here.$K
$F3$PIs there anything I can do for you?$K
$F1$PYes, actually.$w4$FA I have a small favor
to ask of you.$K
$F3$PAsk anything of me, Your Highness,
and I shall make it so.$K$FS$P$F1$PReally? You would do anything?$K
$F3$PAnything at all.$K
$F1$PWell, then here goes...$K$PGeoffrey...$w4 I need you to leave
me alone while I fight on
the battlefield.$K
$F3$P$FAWhat?! Without protection?
But, you know that is the
one thing I cannot--$K
$F1$PI don't want to hear any objections.$w4
This is...an order.$w4
You must obey.$K$F1$FD
$F3$PBut...Princess Elincia...$K    $R�w�i��b|$B�x���w�i|$<$F1$Fc$F1$FCL_ERINCIA2|$F3$FCL_GEOFFRAY|$F3$PYour Highness...$K$PPlease,$w3 I beg you to reconsider.$K
$F1$P...$K
$F3$PI am aware that you took offense to my
disobeying your order...
But...$K$PYou cannot ask me to leave you alone
and undefended! I am a royal knight.$K$PIt is my duty and honor to ride by your
side and defend you on the
field of battle.$K
$F1$P...$K
$F3$PYour Highness, please! On bended knee,
I beg this of you.$K
$F1$P$FdWould you stop defending me
if I stripped you of your title?$K
$F3$P...T-take away my knighthood?$K
$F1$P...$K
$F3$PI see. I had no idea you wanted to
avoid me this badly.$K
$F1$PNo, Geoffrey.$w4 That's not--$K
$F3$PI may have spoken out of turn, but all I
wanted was to honor my oath and shield
you from harm.$K$Fc
I'm sorry...$K$F3$FD
$F1$PWait... $w2Geoffrey!$w4
Geoffrey!$K   $R�w�i��b|$B�x���w�i|$<$F1$FCL_ERINCIA2|$F3$Fc$F3$FCL_GEOFFRAY|$F1$PI've listened to all that you've had to say,
Geoffrey.$w2 Now it's time for you
to hear me out.$K
$F3$P$FdBy your command.$K
$F1$PYou fight too hard and take too many
risks to protect me in combat.$w4$K
$F3$PIs that not what a knight is sworn to do?$K
$F1$PBut you put yourself at grave risk!$K
$F3$PIt is true.$w3 I have felt the bite
of steel several times while protecting you...
But I would do so again without a thought!$K
$F1$PYou promised me long ago that you
wouldn't needlessly jeopardize your life
for my sake.$K$PI guess you don't value your
life after all.$K
$F3$PYour Highness...$K
$F1$PI know you think I should stay at camp
and rest on silken pillows without suiting
up for battle.$K$PBut...$K$PThere's no way I could stand...$Fc$w3
Stand seeing someone so dear to me
die just beyond my grasp.$K$PSo...now you know why I asked
this of you.$K
$F1$Fd$F3$PI don't know if you realize all that
you've done for the soldiers.$K$PDo you see how you have raised the
spirits of the Crimean soldiers since
you began fighting alongside them?$K$PTheir princess herself leads the charge!$w4
She doesn't ask the soldiers to risk their
lives without risking her own.$K$PThey adore you. And that is why we
win our battles.$K$PThey fight with a ferocity no other force
could possibly match.$w4
They will win at any cost.$K
$F1$P...$K
$F3$PI admit I have been fighting recklessly.
$FS...I did so knowing you were near me.$K$PI knew you'd be by my side if I were
gravely wounded.$K
$F1$PYet...$w3 You feel me a burden.$K
$F3$PI can't imagine fighting without you
anymore. If you do hold my life dear,$w3
please keep fighting.$w4 Lead us to victory!$K
$F1$POh, Geoffrey.$w4 I'm so sorry I
brought you so much torment.$w2
I misunderstood you.$K
I am...$w2so immature.$K
$F3$PI disobeyed your direct orders. That's no
badge of honor, either.$K
$F1$P$FSI'm sure I'll keep causing you troubles...$w4
but please...never leave my side, Geoffrey.$K
$F3$P$FAPrincess Elincia...$w4
My life and blade are yours.$K $R�w�i��b|$B�x���w�i|$<$F3$FCL_IKE2|$F3$PIs there something wrong, Princess?$K
$F1$FCL_ERINCIA2|$F1$POh...$w2my lord Ike.$w4 I was getting
prepared for battle, but... I'm having a hard
time attaching this scabbard to my belt.$K
$F3$PHmm...let me see.$w4 Ah...$w2here's the
problem. The buckle on the scabbard
isn't fastened.$K$PThere's a little trick to this.$w4
Don't move for a second.$K
...$w5 All right. $w2That should do it!$K
$F1$PThank you.$K
I just can't seem to do anything right.$w4
I can't even get myself ready for battle!
Everyone else is all suited up.$K
$F3$PEveryone here was the same way
when they first started.$K
In fact, it wasn't all that long ago
when I was having a hard time
fastening my scabbard...$K
$F1$PReally?$K
$F3$PThat's right.$K
But my father drilled me hard and
tested my swordsmanship and survival
skills before I could eat breakfast.$K$PWe come from different worlds, Princess.$K
$F1$PSo that's how you learned so much...$K
$F3$PWell, you don't need to practice so hard.$w4
You weren't born to be a mercenary
like the rest of us war dogs.$K$PYou'll just get yourself killed if you
jump into this rough and nasty war
unprepared.$K
$F1$PI understand...$K
$F3$PJust don't worry about it.$K$PThere's no shame in asking for
help from the rest of us. We'll be
there to back you up.$K
$F1$PThank you, my lord Ike.$K
$F3$PAnytime, Princess Elincia.$K $R�w�i��b|$B�x���w�i|$<$F1$FCL_IKE2|$F1$PPrincess Elincia? You're still here?$K
$F3$FCL_ERINCIA2|$F3$POh, my lord Ike.$w4 W-well, $w2I was
getting a little practice in.$K$PI don't want to be a burden to
everyone else.$K
$F1$PWouldn't it be better to have
a training partner?$K
$F3$PI'd feel guilty asking someone to train
with me. It would be a waste of time...
I am no match for their skill.$K
$F1$PI meant what I said earlier... About not
hesitating to ask for help?$w2 But I guess
you decided to ignore me.$K
$F3$PN-no, no...$w2it's not like that at all.$w3
I heard what you said, but I still
feel so...$K
$F1$PI know how powerless and frustrated
you must feel.$K$PIt was a terrifying feeling when I discovered
my father had left me in command of the
Greil Mercenaries.$K
$F3$P...$K
$F1$P$FSBut there's a huge difference
between inheriting a country and
a band of mercenaries, isn't there?$K
$F1$FA$F3$PNot at all...$w3
You're absolutely right.$K$PIt's hard...$w2knowing what kind of
responsibility I have, and just how
unsuited I am to take it.$K
$F1$P$FAOver the last year, I learned a lot$w4
from all those battles...$K$PMostly, I learned that there are many
things I can't do on my own.$K$PEverything I achieved was possible only
because of the people around me.$K$PI trust them completely. And I'm not
ashamed to ask for help.$K$P$FSThat goes for you, too.$w4
You're not alone.$K
$F3$P$FSThat's a great way to look at it. Thank you!$K $R�w�i��b|$B�x���w�i|$<$F1$FCL_ERINCIA2|$F1$P...$K
$F3$FCL_IKE2|$F3$PWe finally reach the capital tomorrow.$K
$F1$PYes...$K
$F3$PHow are you feeling about it?$K
$F1$PMore than a little anxious... But...
We've finally made it.
I'm home.$K$PMore than anything, I feel relief.$K
$F3$P$FSYou've grown strong, Princess.$K
$F1$P$FSThat's only because I had such
a great role model.$w2$K
$F3$PHah! I think you meant to say
bad role model, right?$K
By the way, do you remember what
you said to me on the southern sea?$K
$F1$PW-what did I say?$w4 Hopefully, it was nothing
too embarassing.$K
$F3$PYou said, "Give them a sound thrashing!"$K
$F1$P$FAOh...er...that?$w2 That was...$w4um...$w3
I was trying to fit in, my lord Ike. To be
rough and capable like the rest of you.$K$FS$P$F3$PYou caught me off guard with that one.$K
$F1$PHee hee!$w4 It brings back memories.$K
$F3$FA$F1$P$FAWhen I fled the capital and was
told about Crimea's defeat in Gallia...$K$PI prepared myself to live in crushing,
colorless despair for the rest of my days.$K$PBut when I look back,$w3$FS
I can see there were some warm
rays of hope...$Fc$w4poking through.$K
$F3$P$FSYou're right...$K
$F1$P$Fd$FATomorrow, I will face King Daein and
reclaim Crimea...or die in the attempt.$K
It is the only thing on my mind.$K
$F3$PYou employed me as a mercenary.
I'll give you your money's worth!
...$w5No. It means more than that...$K$PTo my last breath, I will do all that I
can to ensure your dream...$w4Elincia.$K
$F1$P$FSOh, Ike...$K    $R�w�i��b|$B�x���w�i|$<$F1$FCL_MARCIA|$F3$FS$F3$FCL_GATRIE|$F3$PMarcia! How are you doing, beautiful?$K
$F1$PHuh?$w4 How do you know my name?$K
$F3$PWhy wouldn't I know the name of
a cute girl like you?!$K$PYou know, $w2there was a time when
Titania was the only woman in this
mercenary group.$K$PThings have really started to shape
up while I was away.$w3
$FcMmm... Not bad at all.$K
$F1$POh, nice line, chump. I'm swooning.$w4
Waaaait...$w3 You were a member of the
Greil Mercenaries?$K
$F3$P$FdYep.$w4 Actually, I was a senior member.$K
$F1$P$FSI knew it!$K
You were one of the guys that saved
me from those boat monkeys,
weren't you?$K
$F3$PBoat monk... You mean the pirates?
Uh...of course! That was me!$K
$F1$PAw, heck! That's fantastic!$w3
I was so grateful for the help. Lemme
do something to return the favor!$K
$F3$PThat's nice of you to say, but having
someone as gorgeous and talented
as you join us is payment enough.$K$P$FAI need nothing more!$K
$F1$P$FAWhoa...that's a lot of pressure.
I had no idea people depended on
me so much.$K
$FSIn any case, $w2I'll keep doing my
best! $w2Wish me luck!$K$F1$FD$P$F3$P$FSShe's so adorable!$w4
She will be mine... Oh, yes.
She...will...be...mine.$K $R�w�i��b|$B�x���w�i|$<$F1$FCL_MARCIA|$F3$FS$F3$FCL_GATRIE|$F1$PHeya, big fella!$w4 What are you doing today?$K
$F3$PMarcia! Good to see you.$w3 Actually,
I was just about to meet up with Ike for a
little sparring session.$K
$F1$PW-what!?$w4 You're going to fight
the commander?!$K
$F3$PYou bet I am!$w3 That's why I asked you to
stop by.$K$PI wanted to invite you along so you
could check me out in action.$K$PNow, don't get my wrong...
Ike is a strong commander.$K
But he doesn't have a chance to
match my overwhelming physical power!
It's breathtaking, really.$K
$F1$PBreathtaking? Really...$w4
$FSI can't wait to see this, Gatrie.$K
$F3$PHa ha ha! Well, what can I say?$K
Why don't you just kick back and watch
me unleash the raw fury of these
mighty arms! Hhhrraaaawwww!$K$P$F3$FD$F6$FS$F6$FCL_GATRIE|Ike!$w4 Now's your chance to give up, cur!
No?!$w3 All right, don't say I didn't warn you!$w4
Here we go!$K
$F6$FD$F1$P$FA$F8$FCL_GATRIE|$F8$PThis one's for you, Marcia!$w4
Haaaarrrgggg!!$w4
...Bwaaa!$K
$F1$POoooh, jerky!$w4 That looked painful.$K
$F8$PWhoa there, Ike.$w4 Don't make me get
tough on you... Hey! T-take it easy!
Ooof...$w3 Ooof!$w3 Ouch!$w3 Aghhhhhh!$K
$F1$PUhhh...is he going to be all right?
Gatrie? ...Gaaaatrie?$w4
Oh, crackers.$K   $R�w�i��b|$B�x���w�i|$<$F3$FS$F3$FCL_MARCIA|$F3$PHeya, Gatrie.$K
$F1$FCL_GATRIE|$F1$P$Fh...$K
$F3$P$FAWhat's the matter, big fella?$w4
You're looking down.$K
$F1$P$FcIt's better if you don't talk to me at
all, Marcia.$K$PDon't even give me a second look.$w3
I'm nothing but dirt.$w3 I'm worse than dirt...$w3
I'm...sludge!$K
$F3$POh, boy... This is about the other day,
isn't it?$K$PWhen you got beaten down by--$K
$F1$P$FdDon't remind me!$K$PI was such a fool!$w3 I can't believe
I let you see me get smacked around
like that.$K$PI might as well throw in the towel now.$w4
$FcI'm just a big loser...$K
$F3$P$FSNo you're not!$w4
So Ike beat you that time. Big deal!
Ike beats everybody!$K$PI was still impressed by your all-or-nothing
attitude.$K
$F1$P$FdReally!?$K
$F3$PReally!$w2 You're both fierce fighters.$w4
Hey, what do you say to being my training
partner one of these days?$K$PI want both you and Ike to teach me
some of your fighting skills.$K
$F1$P$FSOf course!$K
$F3$PGreat! It'll be a hoot!$w4
I'm looking forward to it!$w4
See you later!$K$F3$FD$P$w5
$F1$P$FA...$K$PI was feeling angry at Ike for humiliating
me like that...$K$P$FSBut maybe it will all work out after all.$w4
Until later, $w2my sweet Marcia!$K   $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_STELLA|$F3$FS$F3$FCL_GATRIE|$F3$PHey there, Astrid!$w4 Have I told you
yet just how glad I am that you've joined
our little band of warriors?$K
$F1$PNo, but I'm flattered that you say so.
I'm glad to be riding with you as well.$K$PI heard you were once among Ike's band
of mercenaries. Is that true?$K
$F3$POh, yeah... We go way back.$w4
I've been through a lot with them.$K$PIs there anything I can help you out
with? I'm always glad to assist such a
beautiful girl.$w4$K
$F1$POh...$w3 Thank you, Gatrie.$K
Actually...$w3 Will you teach me how to
fight like a mercenary?$K
$F3$P$FAEh? You want to fight like a mercenary?$K
$F1$P$FAI don't have much fighting experience.
I want to learn so I can hold my own
in a battle. I don't want to be a burden.$K
$F3$P$FSOh, I get it!$w4
That's very admirable, Astrid!$K$P$FAEr... $w2But now isn't the
best time for that. I'm a little sore from...
uh...lifting heavy things...$K$PBlast! Where's Titania when you need her?$w2
I don't know the first thing about
training people...$K
$F1$PSorry? I didn't catch that.$K
$F3$P$FSHa ha! $w2No, nothing at all!$K$PLet's train some other day!$w4
I want to make sure I'm totally prepared!$K
$F1$P$FS$w4Perhaps next time, then.$K
I'm looking forward to it!$K$F1$FD$P$F3$PShe's so cute...$w4 And she asked me to
teach her how to fight! That must mean...$K$PYes! I knew it!$w2 She wants me!
She's crazy for me!$w2
This is going to be fun.$K $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_STELLA|$F3$FS$F3$FCL_GATRIE|$F1$PGatrie? I'm here for my lesson.$w4
Are you ready?$K
$F3$POf course, of course!$K$P$Fc$FAEr...$w2ahem.$w4
$Fd$FSAll right then. Let's begin!$K
$F1$PI'm eagerly awaiting your first instruction.$K
$F3$PEr... Every soldier has a role, and it's
important that everyone does what
everyone is best at.$K$PWith the right strategy, three soldiers
can fight with the strength of ten!$K
$F1$PI see...$w4 So everyone must fight to
their strength.$w4 All right, $w2I got it.$K
$F3$PMy job as a knight is to bravely step up
and shield my allies from vicious, marauding
attackers! I'm like an armored wall!$K$PThen, the others can launch an attack
from behind my impenetrable frame.$K$PArchers wait safely behind me and strike
from a distance, while mounted units can
ride in and crush the enemy.$K$PWell, that's what I hear...$w4
Er, I mean...that's pretty much how
it all goes down in the heat of combat!$K
$F1$PI see, but...$K
$F3$PDon't worry! You can stay safely behind me.$K
It's far too dangerous for you to venture
away from me.$w2 Stay close...$w2 Yes,
VEEERY close!$w4 Go on, don't be shy!$K
$F1$PAll right... I'll stay close.$K$POh, $w2may I ask you just one
more question?$K
$F3$PAsk anything!$K
$F1$PSince I'm on horseback and you're on foot,
won't we move at different speeds?
What should I do?$K
$F3$PHmmm...$w2 In that case...$K
$FAUm...$w4 Yaaaaa!
I can't remember what Titania said...$K
$F1$P$FAPardon me?$K
$F3$P$FSOh, nothing! Nothing at all. Hah!$w2
Just talking to myself!$K$PWe'll get into that in your next lesson.$K
$F1$P$FSRight, of course.$w2 I sure learned a lot today.$w4
You'll coach me again, won't you?$w4
Thank you, Gatrie! Good-bye.$K$F1$FD$P$w5
$F3$PShe wants to me to teach her again!$w4
I knew she was crazy about me! And why
not...these muscles are breathtaking!$K$P$FcI can't wait to see her again!$K $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_GATRIE|$F3$FS$F3$FCL_STELLA|$F3$PI'm ready for today's lesson, Gatrie!$K
$F1$PGreat!$w4 Er...right. Let's begin where we
left off last time.$K$PDo you know what adaptation means?$K
$F3$PI certainly do.$K
$F1$PSee adaptation is...$w4 Wait...you do?$K
$F3$PIt means changing your strategy
to take advantage of different
circumstances.$K
$F1$PAhhh...$w4 So that's what it means...
Er, yes!$w2 That's exactly right!$K$PYou're smart AND beautiful, Astrid!$K
I knew what adaptation meant.$w4
I just wanted to test my favorite student,
and she passed!$K
$F3$POh, you flatter me! Thank you for your
kind words.$K
$F1$PWell, I do have one more test question...$K
$FAEr...$w2do you...$w2have a boyfriend?$K
$F3$P$FAA boyfriend?$K
$F1$PThat's right!$K
$FSOh, $w2don't worry!$w4
I don't happen to have a girlfriend.
You know...for the moment.$K
$F3$PI don't have a boyfriend.$w4
But...$w4 I do have a fiance.$K
$F1$P$FAWhat?!$K
A fiance?!$K
$F3$PYes.$K
$F1$P$FSWell, er...$w2 Congratulations!$K
$F3$PGatrie!$w4 Do you have something in
your eye?$K
$F1$POh...$w2 Don't worry about me.
...Sniff...$K
Sniff... As long as you're happy...
...Sniiiifff...$K$F1$FD
$F3$PGatrie! $w2Where are you going?$K
$F3$FD$P$w7$F5$FCL_GATRIE|$F5$PI screwed up again!$w4 I thought I had a
chance this time, too.$K$PHmmm...$w2 Wait...$w4
She said she had a fiance, didn't she?$K$PGoing out of her way to tell me that...$w4
She must want me to swoon her off her
feet and steal her away!$K$P$FSThat's it!$w4 She should have just said
so!$w4 Wait for me, Astrid!$K
$F5$FD   $R�w�i��b|$B�x���w�i|$<$F3$FCL_JILL|$F3$PCaptain Haar!$w4
Where are you?$w4
Captain Haar!!!$K
$F1$Fc$F1$FCL_HAAR|$F1$PZzzzzzzzzz...huh?! Wha--?! Who?!
Oh. Jill.$w3 Yaaaawn...$w4 Simmer down, Jill.
Can't you see I'm sleeping?$K
And do you need to shout my name
like that? You're louder than a meat
skewer salesman in a crowded market!$K
$F3$PMaybe you should try responding
when I call you!$K
$F1$P$FdI'll do that as soon as you stop
calling me captain.$K
$F3$PHow should I address you, then?$K
$F1$PWhatever works for you.$K
$F3$PSir Haar, maybe?$K
$F1$PDo I look like a knight to you?$K
$F3$PAll right. Mr. Haar.$K
$F1$PHah! That doesn't sound right at all.$K
$F3$PFine. Just Haar, then.$K
$F1$P$FSHey!$w4 That's pretty good.$K
$F3$PSorry.$w4 I can't address my
superior like that.$w4
I'll just call you Mr. Haar.$K
$F1$PWell,$w4 I can live with that.
Now, let me get back to my nap...$K   $R�w�i��b|$B�x���w�i|$<$F3$FCL_JILL|$F3$PMr. Haaaaaaaaar!$w4
Where are you!?$w4
Mr. Haar!!!$K
$F1$Fc$F1$FCL_HAAR|$F1$PI'm right behind you.$K
$F3$PWhy can't you just respond the
first time I call for you?$K$PAnd didn't you promise that
you'd respond right away if I
stopped calling you captain?$K
$F1$P$FdThat was only if I wasn't sleeping.$K
$F3$PWell, that's most of the time!$K
By the way, it seems like the only time
you acted like a professional soldier was
when you were in front of my father.$K
$F1$PAnd I recall the only time you weren't
so uptight was when you were
around Lord Shiharam.$K
$F3$PI... $w2I couldn't help it.$w4
He was my father.$w4
He was different.$K
$F1$PI'm with you on that.$w4 Lord Shiharam
was something special.$K$PI didn't want him to see me as
hopelessly lazy.$K
$F3$PMr. Haar...$K
$F1$P$FcMmm...$w3 $FhI think I'll just stretch out here...
Yeah...that's it.$w3 This moss is nice and
squishy.$w4$Fc Leave me alone. It's nap time.$K   $R�w�i��b|$B�x���w�i|$<$F3$FCL_JILL|$F3$PMr. Haar?$K
$F1$Fc$F1$FCL_HAAR|$F1$PYes?$K
$F3$P$FSThat's strange. I didn't have to call
for you a hundred times before you
answered!$K
$F1$P$FdWell, I figured this way I don't have
to listen to your whining.$K
$F3$POh, so that's how it is?$w4$FS
Well, whatever...$K
$F1$PWhat are you going to do
when this war is over, Jill?$K
$F3$P$FAHopefully go back to Daein.$w4 I want to
be near my father's grave.$K
$F1$PI see.$K
$F3$PWhat about you?$K
$F1$PIf I survive sparring with Ashnard...$w4
I don't know what I'll do.$K$PI've already thought about guarding
Lord Shiharam's grave.$K
$F3$PDoes that mean you're not happy
being with me?$K
$F1$PThat's not it. I was just thinking you
probably don't like being with me.$K
$F3$PWhy would I not like that?$K
$F1$PThen if we both survive this war, let's
start a wyvern courier service.
We'll make a lot of loot.$K
$F3$P$FSSure...$w4
If we survive.$K $R�w�i��b|$B�x���w�i|$<$F3$Fc$F3$FCL_HAAR|$F3$PZzzzz...$K
$F1$FCL_MAKAROV|$F1$PAaaack!$K
$F3$P$FhZzz-- Snort! Wha...? Huh?$K
$F1$PAgggghhh!$K
$F3$P$FdWhat's with you, man?$K
$F1$POh no! Stay away!$K
$F3$PWhat's the matter with you?$K
$F1$PAaaaack!$w4 Help!$w3 Somebody help me!$K
$F1$FD$w4$F3$P...$w4
Did he think I was a Daein soldier?$w4
Well...$w2whatever...$K$PBack to sleep...$w2$Fc...Zzzzzzz...$K $R�w�i��b|$B�x���w�i|$<$F1$FCL_HAAR|$F1$PHmm...? $w2Hey! You're that...$K
$F3$FCL_MAKAROV|$F3$PNooooo!!!$K
$F1$PYes, you are. You're that weird guy I saw
the other day.$K$F3$FD
$F1$PHey, $w2stop right there!$K
$F4$FCL_MAKAROV|$F4$PPlease...have mercy on me!$w4
I'll pay you back...I swear!$K
$F1$PWhat are you yammering on about?$K
$F4$PHonestly, I only ran off the other day
because I didn't have the money on
me. I was just...running home to fetch it.$K$PSweet mercy...I'm begging you!$w2
I'm too talented and beautiful to die!
Give me more time to pay you back!$K
$F1$PPay me back?$w4 What are you talking about?$K
$F4$PHuh?$w4 Wait... So you're not...$w3
a debt collector?$K
$F1$PA debt collector?$w3
Did you fall on your head?$K
$F4$PAre you SURE you're not a debt collector?$K
$F1$PI don't remember being one. And I think
I'd remember something like that.$K
$F4$P$FSWhat!?$w2 You're not!?$w4$K
Phew!$w2 Hah...you had me there.
I mean...just one nasty look from that
face of yours could scare a man to death!$K
$F1$PSo you're saying I'm ugly, is that it?
I look like some kind of thug to you?$K
$F4$PNo, no, no!$K$PNot at all. You're very...$w4handsome.
Ruggedly handsome...yeah...$K$F4$FD
$F1$PHmmm.$w2 That was weird.
Oh well...back to sleep.$K    $R�w�i��b|$B�x���w�i|$<$F3$Fc$F3$FCL_HAAR|$F1$FCL_MAKAROV|$F1$POh, $w2$FSthere you are!$w4
Hey, Haar!$K
$F3$PZzzzzzzz...$K
$F1$PHAAR!!!$w4
Wake up!$K$FA$POh, no! Look!$w4 Here comes General Ike!$K
$F3$PZzzzzzzz...$K
$F1$PNothing will wake him up!$K$PHe has a lot of guts sleeping before a
battle like this.$w3$FS
You have to respect that!$K$PEven debt collectors would be intimidated...
I need to be more like him! Then I'll
never have to pay anyone back!$K$PAll right!$w2 I need to get training!$w4
The first thing I need to learn is how
to sleep anywhere.$K$Fc$P...$w5
Zzzzzz...$w3$K
$F3$P...$w2$FdQuiet down!$K
Who's interrupting my nap?!$K
$F1$P...Zzzzzz... Phew...$w2$FA Grrrr...$w3
I was wrong...$w4 Sorry, Marcia!
...Zzzzzz...$K
$F3$P...$K
$F1$PLet me...zzzz...$w2borrow some money...$w4$FSzzz...$K
$F3$PLook at him, sleeping before a big battle.
It's a miracle he's survived in his state.$K$FS$PHe must be really lucky.$w4
I hope he pulls through!$K  $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_LAY|$F3$FCL_IKE2|$F1$PHey, Ike.$w4 Isn't it a little late
to be training?$K
$F3$PI haven't had a chance to train today.
I try to swing a sword every day, even if
it's just for a little while.$K$PIt helps me focus and keeps me
calm.$w4 Plus it's good practice.
Haaaa!$w4 Kyaaaaa!$K
$F1$PI see.$w4 So your strength doesn't just
come from your bloodline. It's also
a result of your persistance.$K$PNo wonder you grow more powerful every
time I see you...$w4 Nice.$w3 Very nice...$K
$F3$PHaaaaa!$w4 And one and...$w3 Hiyaaaa!$K
$F1$POh, sorry. I'm interrupting you.$w4
I'll see you la--$K
$F3$PWait.$w4 What do you want? I assume
you came out here to tell me something.$K
$F1$PNot really. I'm just being a mother cat...$w4
No matter how many times we tell you to
take it easy, you're always working.$K$PI thought you might take a break if I came
over and talked to you, but...$w3 I can
see that you're still crazy.$w3 I'll go now.$K
$F3$PYou think I'm crazy?$w4
How so?$K
$F1$P$FAWell...$w4a little crazy, yeah!$w4 I've never
worked for a leader who's as blunt and
straightforward as you.$K$PIt's pretty shocking to have a commander
who doesn't care what anyone thinks, no
matter how powerful they are.$K
$F3$PWell,$w3 that's just my style.$w4 I don't
have to be like someone else, do I?$K
$F1$PWhy are you so confident?$w2
I don't get it.$K$FS$PNormal beorc just do what people tell them
and try not to make a fuss. But not you.
I heard you even yelled at the apostle!$K
$F3$PYeah, that wasn't my brightest moment.$K
$F1$PThen again, worrying about a
beorc like this is definitely not
normal laguz behavior.$K$PI guess I'm a fish out of water myself...$w2
Wait, $w2did I just call myself a fish?$K
$F3$P$FSWha--? Ha ha!$w4 You're a cat, remember!?$w2
I thought you ate fish.$w4 Ha ha ha!$K
$F1$PHey! I made you laugh!$w4 That's good.$w4
That's a good first step.$K
$F3$PFine, fine!$w4 I'll take a break. Um...$w5
so what do I do now? Am I supposed
to drink tea or something?$K
$F1$PTea is good.$w2 And eat something.
Oh, and maybe you should take a...$w4
catnap!$w3 Wha ha ha ha!$K    $R�w�i��b|$B�x���w�i|$<$F1$FCL_IKE2|$F1$PHey, Ranulf.$K
$F3$FS$F3$FCL_LAY|$F3$PHm?$w4 Oh, hey, Ike. How goes it?$K
$F1$PAre you...$w2training?$K
$F3$POh yeah!$w3 I love training!$w3 I'd hate to
have the hardworking general Ike
leave me in his dust!$K
$F1$PThat's a good attitude.$K
$F3$P$FAUm...$w5that was a joke, Ike.$w4 I hate training.$w4
Besides, training on two legs would be
pretty useless for a laguz like me.$K
$F1$PSo what were you doing?$w4
It looked like stretching.$K
$F3$PJust stretching.$w3 You know, to unwind?$K
$F1$PHm.$w4 I was hoping that it was a kind
of special laguz technique that I didn't
know about.$K
$F3$PSorry to disappoint you, but you and I
aren't that different unless I change
forms.$w4 As you can see.$K
$F1$PI just need a tail.$K
$F3$P$FSHey, a tail is a good thing to have!$K$PIt's what gives us such great balance
in high places. You poor beorc... I can't
imagine living without a tail!$K
$F1$PDoesn't it get in your way
when you sleep?$K
$F3$POn the contrary!$w4 There's a little
trick we have...$K
$F1$PWhat kind of trick?$K
$F3$PWell, we take...$K$FA$PHey!$w3 You're smooth, aren't you?$w4
I almost fell for that one...
Nice try, Commander!$K
$F1$PHuh? $w2I just asked you a question.$K
$F3$PListen, Ike.$w4 This is a secret that concerns
the entire laguz species.$w4 I can't just run
around telling any old beorc that I know.$K
$F1$POh. I understand.$w4
I'm not that interested, anyway.$K$F1$FD
$F3$PWha--?$w4 Hey, now, come on!
You should be more persistent!$w4
It's really interesting!$K $R�w�i��b|$B�x���w�i|$<$F1$Fo$F1$FCL_LAY|$F1$P!$K
$F3$FCL_IKE2|$F3$PWhat's wrong, Ranulf?$K
$F1$P$FdAaaah!$w4 Oh, it's you, Ike...$w4Phew!$Fc
Don't scare me like that!$K
$F3$PYou all right? You've been pretty
tense lately.$K
$F1$P$FdThe closer we get to the capital,
the more the Daein king starts
to worry me.$K$PWell, I suppose it's more the
medallion than the man...$K$PAt any rate, all this negative energy
is making my hair stand up on end.
It's hard to focus...$K
$F3$PI'm amazed at how sensitive you laguz
are to such things.$K
$F1$PI'm amazed that you beorc don't notice!$w4
How can you be so calm with these
creepy auras all around us?!$K
$F3$PYou want me to leave you alone?$K
$F1$PYeah, would you?$K$PNo, wait, Ike.$w4 Hold on.$w3 Stay here.$w4
I'll calm down...$Fc Just$w3 gimme a second...$w5
...Whooooo!$K
$F3$PBetter?$K
$F1$P$FdYeah.$w4 I'm fine now. Although I can't
believe I let a beorc see me in such a
vulnerable state.$w3 I'll never live this down.$K
$F3$PRanulf, what are you saying?
Don't you trust me?$K
$F1$P$FSNo, I do! I do.$w2$FA But...$w2
well, not entirely.$K$PLook, I trust you as much as any beorc,
but...$w2 You know!$w4 The laguz are
my brothers! It's different.$K
$F3$PI trust you.$K
$F1$P$FSAnd you say it with a straight face, too.$w4
You know something? $w2You're...$K
$F3$P...$w4I'm what?$K
$F1$P$FADumb.$K
$F3$PWhat?!$K
$F1$P$FSIf you trust everybody, you're going
to get hurt in the end.$w4
Remember that!$K$F1$FD
$F3$PHey, $w2wait!$w4 Ranulf!$w4
$FSDang...$w3 Was that friendly advice
or is he just angry?$K  $R�w�i��b|$B�x���w�i|$<$F1$FCL_IKE|$F1$PHiyaaaa!$w4 Haaaaaa!$w4
Hm?$w4 Who's there?$K
$F3$FCL_LETHE|$F3$PTraining hard?$K
$F1$PLethe.$w4 Were you watching me?$K
$F3$PYep.$w4 I'm curious...$K$POur future success will depend in large part
on how well you humans fight.$w4 We laguz
can't afford to lag behind.$K
$F1$PYou always need the upper hand, eh, Lethe?$K
$F3$PRelax. $w2It's not like I'm going to claw
you in the back during a battle.
There's no point in it.$K$PBesides, you humans are the only ones
who use dirty tricks like that.$K
$F1$POh, I see.$w4 So every laguz fights
fair and square?$K
$F3$PMost of us. Not all.$w4 Although
we know when a laguz is about to
use a cheap trick.$w2 We can smell it.$K$PI can sniff out a trap from a mile away.
Even in the dark.$w4 You can hide from
my eyes, but not my nose.$K
$F1$PLethe?$w4 Will you teach me
how to fight like a laguz?$K
$F3$P$FSSure, I'll take you on.$w4
But it's going to hurt!
When I fight, it's with claws out.$K
$F1$P$FSGood. $w2I look forward to it.$K  $R�w�i��b|$B�x���w�i|$<$F3$FCL_LETHE|$F3$PHey.$K
$F1$FCL_IKE|$F1$PLethe.$w4 What's up?$K
$F3$PYou fought pretty well the other day.$w4
Better than I expected.$K
$F1$PWhat? Me?$K
$F3$PYou see anyone else?$K
$F1$PNo, but...$w3 I didn't expect that from you.$w4
You laguz have such awesome natural power,
I figure beorc look weak in comparison.$K
$F3$PTotally different styles of fighting. You don't
have the reactions or control that we do,
but you're actually kind of graceful.$K$PIt must be tough to use a weapon that's
not actually connected to your body.
No wonder you train so much.$K
$F1$PWithout teeth or claws, we need our
weapons to move like they're a part of us.
So, yeah, that takes a lot of work.$K
$F3$PMmm... I see. I may have to train more.
Which reminds me...$K
$FSDo you remember our bargain?$K
$F1$P$FSOf course!$w4 Will you do it?$K
$F3$PI should ask you. Laguz training is hard.$w4
You're going to hurt. And bleed.$w4
Are you ready?$K
$F1$PLet's do it!$K  $R�w�i��b|$B�x���w�i|$<$F3$FS$F3$FCL_LETHE|$F3$PHello, Ike.$K
$F1$FS$F1$FCL_IKE|$F1$PHey, Lethe!$w2 You ready to
punish me some more?$K
$F3$PYou're taking to my training with remarkable
skill.$w4 I need to keep up.$K
$F1$PYou think so?$w4 Wow.
A compliment from Lethe...$w4
Now that's a big deal!$K
$F3$P$FAWhat's that supposed to mean?$w4
You're not still holding a grudge about
our first meeting, are you?$K
$F1$P$FANo, nothing like that. It's just...$K$P$FSYou're powerful, you know?$w4
If you compliment me,
that means something.$K
$F3$P$FSBah!$w4 You give me too much credit.$K$P$FA...$w4Um...$w5
Say, $w2Ike?$K
$F1$P$FAWhat?$K
$F3$PWhen this war is over, you should...$w4
Why don't you come to Gallia?
I mean, not like I care, but--$K
$F1$PGallia?$K
$F3$PRight!$w4 Well, you could learn even
more if you trained in Gallia.
It's hard living for a beorc.$K$PBut if you can handle it, you could
take the swordsmanship that runs
in your blood to another level.$K
$F1$POnly if you're my sparring partner!$K
$F3$PMeh...$w4 Well, if you that's what you want...$w3
I guess I'd be all right with that.$K
$F1$PThen life in Gallia may not be so bad.$K
$F3$P$FSOh?$w4 Well, good. It's settled then.$w4
Come see us whenever you're ready.
I might even...$w5look forward to it.$K
$F1$P$FSYou have my word.$K $R�w�i��b|$B�x���w�i|$<$F3$FCL_IKE|$F3$PHey, Oscar, $w2can you spar with
me for a sec...$w4 Wait!$w2
Where are you going?$K
$F1$FCL_OSCAR|$F1$P$FSSorry, $w2Ike! No time!$w4
I have to prepare the evening
meal today.$K
$F3$PYou?$w3 Where's Mist?$K
$F1$PShe's off practicing with her staff.$w4
It's been a while since I cooked.$w2
I hope I haven't lost my touch.$K
$F3$PI haven't had one of your suppers in ages!$w4
I'm looking forward to it.$K
$F1$PReally?$K
$F3$PYeah, of course! You're a great cook!$w4
Why do you ask?$K
$F1$PWell... I never knew that.$K$PMist, Shinon, and Rhys were the only ones
who ever commented on the subtle
spices and flavors that I use...$K$PI mean, my brothers are used to my
cooking, and Soren hates everything.$w4
I think he'd stop eating if he could...$K$PSure, Commander Greil, Titania, Gatrie, and
you ate everything on the plate.$w3
But... I feel like you'd eat anything.$K
$F3$POscar, I didn't just shovel the food into
my mouth.$w2 I enjoyed it! I really did!$K$PRemember the first day that Mist took
over your cooking duties?$w3
Just thinking about it makes me ill...$K$PHa!$w3 Even my father was having trouble
choking it down!$w4 But I think Mist is
finally starting to get the hang of it.$K
$F1$PJust like you're training to improve your
swordsmanship, Mist is training
to improve her culinary skills.$K$PYou should give her more support.$w3
Hearing someone say "Delicious!" is
the best encouragement a cook can get.$K
$F3$PI see...$w4
$FSThen I'll make sure to say "Delicious!"
from now on.$K
$F1$PHa ha! $w2Thanks.$K   $R�w�i��b|$B�x���w�i|$<$F3$FS$F3$FCL_OSCAR|$F3$PHow's it going, Ike?$K
$F1$FCL_IKE|$F1$POh, hey, Oscar.$w4 I'm fine...$w4
Actually, I'm kind of worried
about something.$K
$F3$PCan I help?$K
$F1$PWell, I was trying to figure out how
we should fight the laguz bird tribes.$K
$F3$P$FAThat's odd...$w4 I was just thinking
about the same thing.$K$PWhen they turn into their true selves,
we are forced into a kind of battle that
is difficult for us.$K
$F1$PYou're right about that.$w4 The laguz are
so strong.$w3 I've even seen them shatter
boulders with a single blow.$K$PI feel like our weak points are as visible
as a lit torch for the bird tribes.$K$PWhat's more, my sword is useless
if they take to the sky...$K
$F3$P$FSMy advice is to keep engaging them. The
more we fight, the more we learn.
Of course, it won't be easy.$K
$F1$PNo, but I'm sure we can do it.$w4
That's a good idea! Thanks.$K
$F3$P$FAAh...$w5 Well...$w2sure.$w4
$FSYou're pretty amazing, Ike.
You know that?$K
$F1$PHey, come on now. You're the guy with
all the experience and talent.$K
$F3$PEverything I have accomplished comes
from hard work and practice.$K$PYou're the son of Commander Greil.$w4
You have...$w4natural talent.$w2
I'd follow you anywhere.$K
$F1$PUh...wow.$w4 Thanks, Oscar...$K  $R�w�i��b|$B�x���w�i|$<$F1$FCL_OSCAR|$F1$PIke.$K
$F3$FCL_IKE|$F3$POscar?$w4 What is it?$K
$F1$P...$w4Are you well, Ike?$K
$F3$PYeah...$w2yeah, I'm fine. Why?
Did I worry you?$K
$F1$PNo, no. $w2It's nothing that you did.$w4
It's just that...$w4our battles are intensifying.$K$PI never imagined that we'd be involved
in clashes of this magnitude.$K
$F3$PYou're right. $w2Ever since my father died,
it's been one kind of chaos after another.$w4
It's a real challenge.$K
$F1$PSo... How are you doing?$w4 Well, I mean...
are you as well as can be expected?$w4
Is there anything I can do?$K
$F3$P$FSAh, Oscar.$w4 I give you enough grief as is.
Just stick with your helplessly green
commander. That's all I ask.$K
$F1$PIke...$K
$F3$PWill you continue to believe in me?$K
$F1$P$FSYes, $w2of course!$w4 As Commander Greil
said, we are family. This is my home.$w4
I will support you to the end.$K
$F3$P$FSListen...$w2 I have an urge for your cooking.$w4
Think you can give Mist a hand tonight?$K
$F1$PHa! You don't have to ask me twice!
I'll put all of my culinary skills to work.$w2
I hope you're hungry!$K  $R�w�i��b|$B�x���w�i|$<$F1$FCL_IKE2|$F1$PReyson.$K
$F3$FS$F3$FCL_RIEUSION|$F3$POh, Ike.$w4 What can I do for you?$K
$F1$PI just came to see how things are going.$w4
How are you doing?$K
$F3$PFine.$w4 No problems.$K
$F1$PNo problems?$w2 Your face tells me otherwise.$K
$F3$P$FAWell...$w4we herons are optimistic by nature.
So it's hard for me to be on a battlefield
where the air is thick with negative energy.$K$PIt's...tiring.$w3 But I'm learning to adjust.$w3
I hope you'll let me fight beside you
to the bitter end.$K
$F1$PAs long as you take care of yourself,
I have no complaints.$K$PBut isn't there anything I can do to help?
Maybe we could have a special supper.
Certain foods tend to restore energy.$K
$F3$P$FAThat's very kind, but my diet...
Heh. It's fairly limited.$K$PYou know, I used to be disgusted by my
thin, frail body.$w4 So one time
I performed a little experiment.$K$PI got all the foods that Tibarn likes--
raw meat, cold fish, insects--and ate them.$w4
I ate them all.$K
$F1$PThat doesn't sound good.$w4
What happened?$K
$F3$PI stared death in the face for ten days.$w5
You've never seen a laguz so green!$K$PI guess we herons are just meant to
eat fruits and nuts for our entire lives.$K
$F1$P...I can't imagine.$w3 Raw meat?$w4
You must have been desperate!$K
$F3$PI wanted so much to be like Tibarn.$w3
Big body,$w2 strong wings...$K$PWith those features, I felt I could
march into Begnion and revenge
my brothers all by myself.$K$PI got on my knees and prayed to the
goddess every night.$w2 Asking her
for power...$w4 But to no avail.$K
$F1$PI think I know how you feel...$w4
But it's better this way.$K
$F3$PHow do you figure?$K
$F1$PYou get sick from negative energy.$w3
Imagine if you tried to hurt someone!$w4
You'd lose your lunch!$K
$F3$PHeh. I guess you're right...$K$PAt one time, I was so angry about my lack
of strength, $w2so consumed by despair,$w3
that I considered forfeiting my life...$K$PBut...$w3 I'm glad that I am alive.$w4
I got to see Leanne because I am alive.$K
$F1$P$FSHuh.$w2 You surprise me, Reyson.$w3
You're stronger than you look.$K
$F3$P$FSIf you're talking spiritual strength,
I think I'm the best there is!$K $R�w�i��b|$B�x���w�i|$<$F3$FCL_IKE2|$F3$PReyson!$K
$F7$FCL_RIEUSION|$F7$PI'm here, Ike.$K$F7$FD
$F1$FS$F1$FCL_RIEUSION|$F1$PDo you wish to talk strategy?$K
$F3$PYes.$w4 Your participation in the next
few battles will be critical...$w4
How are you feeling?$K
$F1$PWell...$w4I found that the negative energy
isn't so bad when I fly.$w4 Even feeling a
breeze can be a huge help.$K$PI can hold up.$w3 Don't worry about me.$K
$F3$PYou look tired.$w3 Exhausted, even.$w4 I think I
know how King Phoenicis must feel...$w4
I'm sorry for pushing you like this.$K
$F1$P$FA$FhSaying so is an insult.$w4
I choose to be here.$K
$F3$PLook, that's not what I meant...$w3
I apologize.$w4 I know that you hate
having people fuss over you.$w4 It's just--$K
$F1$P$FcIke?$w2 Be quiet.$w4 If you were
anyone else, I'd punch you in the nose
and make you be quiet.$K
$F3$PWhoa, easy, Reyson! That's not necessary!$w3
And hey... I didn't think that
herons could attack.$K
$F1$P$Fd...$w3I know how to punch!$w4
Although...$K
$F3$PYes?$K
$F1$PI suffer more damage than my target.$K
$F3$PWhat?!$K
$F1$PWhen I bashed Duke Tanas's face, he only
suffered a bloody nose, $w2but it cracked
the bones in the back of my hand.$K
$F3$PHoly...$K
$F1$PIndeed.$K
$F3$P...$w5But it felt good, right?$K
$F1$POh, yeah.$K $R�w�i��b|$B�x���w�i|$<$F3$FCL_IKE2|$F3$PReyson? How are you holding up?$w4
You look like death warmed over.$K
$F1$FCL_RIEUSION|$F1$PI know, Ike!$w3 Believe me, I know that
better than anyone.$w2 But, $w2please.
Let me do this.$w3 Let me fight to the end.$K
$F3$PWell, all right.$w4 But I don't want you
dropping dead the minute this war
is over!$K
$F1$PMy body should return to normal$w3
once the medallion settles down...$w3$K$PDon't worry.$w3 My will is still strong.
I have to confront Ashnard.$w4
I have to discover the truth.$K
$F3$P$FSI'll help you with that, Reyson.$K
$F1$PI told you not to treat me spec--$K
$F3$PAnd I need you to help me, too.$K
$F1$P...R-really?$K
$F3$PWe each possess unique powers.$w4 If we
combine our might, it will lead to victory
in future battles.$K
$F1$P$FSI see...$w4 Very well.$w4
I appreciate your help.$K
$F3$PHang in there, Reyson.$w2
The end is in sight.$K    $R�w�i��b|$B�x���w�i|$<$F1$FCL_SENERIO|$F3$FCL_IKE|$F1$PSo that's how much we spent...$w3
Supplies are running low. We need dried
meat, fresh fruit...$w4 Ike?$w4 Are you listening?$K
$F3$PHuh?$w4 Oh, sorry. I wasn't paying attention.$K
$F1$PI would have never guessed.$K
$F3$PSorry, Soren.$w4 Look, could you run
the report by me again?$K
$F1$PYou're tired, Ike. You need rest.
Go find a cot somewhere.$K
$F3$PYou can tell?$K
$F1$P$FSOf course.$w4 When you're not feeling
well, your left eye twitches.$K
$F3$PThat's...odd.$w4 I never noticed.$K
$F1$PGet some sleep.$w4 I can manage
things for a few hours.$K
$F3$PWell, I am pretty beat...$K
$F1$PGo.$K
$F3$PYou know, Soren? You're not nearly as
insensitive as the others say.$w4
Deep down, you're a big softie.$K
$F1$P$FAExcuse me?$K
$F3$P$FSOh, nothing.$w4 I'm going.$K
$F1$PMmm.$w4 Don't let the bedbugs bite.$K    $R�w�i��b|$B�x���w�i|$<$F3$FCL_SENERIO|$F3$P...$K
$F1$FCL_IKE|$F1$PDo you have a second, Soren?$K
$F3$P$FSWhat is it, Ike?$K
$F1$PWhat's wrong? You've been quiet
and moody for days.$w4
What's going on?$K
$F3$P$FAUm...$w4 Well, it's...$K
$F1$PYes?$K
$F3$P...$w3It's nothing.$w4
...$K$P...$w4You've never worried about who
you are, have you?$w4 Your family?
Where you come from?$K
$F1$PWho I am...?$w4 Well, $w2not really. No.
I guess I don't understand what you're
getting at.$K$PI had a father and a mother.$w4
I don't remember much about her,$w3
but otherwise, no complaints.$K
$F3$P$FSIt must be...nice to have loving parents.$K$P$FAYou need people to experience your
childhood. To help shape the person
you will become.$K$PWithout an adult around to affirm and
support them, a child can't know which
path to take.$w3 Or who he really is.$K
$F1$PDon't you have any memory
of your parents?$K
$F3$PNo.$w4 The woman who raised me was not
my birth mother.$w5 And she wasn't all that
fond of me, anyway...$K$PMy earliest memories are of her saying,$w3
"Why me? The world isn't fair!"$w3 or
"Stay away from me, child!"$K$PNo love.$w3 No affection.$w4 She took care
of me out of some sense of duty that she
didn't really possess.$K
$F1$P...$K
$F3$PWhen I was about four, a nearby sage
came by and asked to take me in.$w3
He said I possessed rare magical talent.$K$PI remember the day clearly. My caretaker
was delighted to give me up.$w5 In fact,
she seemed almost delirious with pleasure.$K$PSmiling like a madwoman as she handed me
over...$w4 The sage even gave her gold as
compensation.$w3 Not that it was necessary.$K
$F1$POh, Soren... I had no idea.$K
$F3$PThe sage was old,$w2 and knew that death
would soon come for him.$w3 His only goal
was to teach his art to an apprentice.$K$PAs time was short, he put me through
terribly rigorous magic training.$w3 We
worked day and night, without cease.$K$PI didn't even have time to think about
who I really was.$w4 But it was still a
better life than I had ever known.$K$PWhen the sage died two years later,$w3
I had acquired much magical skill.$w4
Perhaps too much for a child of my age...$K$PAt any rate, once I had eaten all of the
food in the sage's hovel,$w4 I left and
walked for days to find help.$K$PUpon reaching civilization, I came
to another grim realization...$w6
I couldn't speak.$w4 Not a word.$K
$F1$PSoren...$K
$F3$POh, I could read and write better than most
of the villagers. And I could understand$w4
what they said. I just couldn't talk.$K$PI couldn't help it.$K$PThe woman and the sage both used to hurl
words at me. Unkind words, usually.
But I never needed to answer, so--$K
$F1$PSoren!$K
$F3$PHuh?$K$POh...$w4 I apologize, Ike.$w4 I should not
have made you listen to such nonsense...$K
$F1$PSoren, it's no nonsense! It's awful!$w4
It's the most terrible thing I've ever heard!$K$PWhere did this happen?$w3 Was it in Begnion?$K
$F3$PNo...$w4 But, there's more.$w4 I haven't told you...
About my parents...$K$w3$PNo,$w2 that's enough.$w4$Fc I'm sorry.
Excuse me...$K$F3$FD
$F1$PWait, Soren? Soren!$w4
Blast!$K  $R�w�i��b|$B�x���w�i|$<$F5$Fc$F5$FCL_SENERIO|$F3$FCL_IKE2|$F3$PHey, Soren.$K
$F5$P...$K
$F3$PI've been thinking a lot about what
you said the other day, and there's
something I still don't understand.$K$PYou survived. You're strong. Why would
you feel insecure about who you are?$K$PTell me.$w4 Tell me everything.$K
$F5$FD$F1$FCL_SENERIO|$F1$PCurse you! Why can't you leave me be?!$K$P$FhI don't have any friends, Ike!
I don't have anyone else!$K$P$FcIf I tell you and you turn on me...
I...$w3 I...$w4 I don't think I can survive it.$K
$F3$PThat's why you have to tell me, Soren.$w4
You'll never tell anyone else.$K$PAnd if you don't tell anyone, you're just
going to keep suffering. Look at you!
You're a mess!$w4 Come on. Talk to me.$K
$F1$P$FdIke...$w4 I...$w4 I...$K
$F3$PSoren, it's me!$w3 Trust me.$w4
I don't give two figs who your parents are!
I'll stand by you.$K
$F1$P$FcIke, I...$w4sniff... No, I won't...$w4
..sniff...$w5Ah, Ike...$K$P...$w4$FdI'm... $w6Branded.$w6
I'm one of the Branded.$K
$F3$PA Branded?$w4 What's that?$K
$F1$P$FcIt's a cross between a beorc and a laguz.$w4
Such a taboo union violates every teaching
of the goddess.$w4 And of society.$K$PWe are untouchables. Abominations.
Condemned to a life of hatred and
shunning from both races.$K
$F3$PWait, wait.$w3 Hold it a second.
Let me make sure that I follow you...$w4
You're part laguz?$K
$F1$P$FdYeah.$K
This mark on my forehead is the proof.$w4
I learned about it$w3 while researching
ancient books at the Mainal Cathedral.$K$PI always thought it was a birthmark.
Others thought that it was the
mark of a Spirit Charmer.$K$w2$P$F3$PWhat's a Spirit Charmer?$K
$F1$PMagic comes from interaction with spirits.
If you let one into your body, it will give
you tremendous power...$w4for a price.$K$PThat's why the old sage was so interested
in me. He thought I had struck such a deal.$w4
But instead, I was just a filthy Branded.$K
$F3$PAll right. I understand.$w4 So?$K
$F1$P...What do you mean, "so?"$K
$F3$PSo, you have laguz blood in your veins.
So, you have a mark to prove it.$w4
So... What's the problem?$K
$F1$PWhat's the problem...?$w5
Don't you find me repugnant!?$K$PI work beside you, eat beside you.
I'm nothing! I don't belong anywhere!
Doesn't that sicken you?$K
$F3$PNo.$w4 It doesn't change anything.$w4
$FSYou're still you, Soren!$K$PYou're a capable officer of our army.$w4
And my friend.$w4 We can't keep going
unless you are with us.$K
$F1$P$Fh...$w2Ike...$w4
$FcI thought...$w3 I thought you...$K
$F3$PWhat?$K
$F1$P$Fh$FAIt was Gallia.$w4 The sage lived in Gallia.
$FcA few beorcs had settled there and...$K
$F3$P$FAGallia?$w4 Are you saying...$K
$F1$PWhen the sage died, no one would help me.
I couldn't speak. Couldn't find food.$w4
I was dying.$K$P$FdYou were the only one who helped.
You and your father.$K$P$FSThat's why you're my friend.
My...only friend.$K    $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_TIAMAT|$F1$PHey, Ike.$w4 Training?$K
$F3$FCL_IKE|$F3$PYeah. You too, huh?$w4
Hey, do you want to spar?$w4
I learn a lot when we team up.$K
$F1$PReally?$w4 I'm glad to hear that.$w4
I thought you no longer
needed my lessons.$K
$F3$PWhat are you talking about?$K$PYou're the one who put the finishing
touches on what swordsmanship
I inherited from my father.$K
$F1$PHmm.$w2 I'm honored to
hear you say so.$K
$F3$PI mean it.$K
$F1$PBut the talent you inherited from your
father is one of a kind.$w4 I want you
to cherish it.$K
$F3$PHuh...$K
Hey, Titania?$w4 When did you meet
my father?$w4 You used to be
a Crimean knight, right?$K
$F1$P$FAThat's right...$K$P$FSBut it's a long story, and we need to train!$w4
Get ready!$w4 Focus!$K
$F3$PFine...$K  $R�w�i��b|$B�x���w�i|$<$F3$FCL_IKE|$F3$PDo you have a moment, Titania?$K
$F1$FCL_TIAMAT|$F1$PIke!$w4 How can I help you?$K
$F3$PRemember what we talked
about the other day?
About when you met my father?$K
$F1$PUm... $w2Yeah...$w4
That...$K
$F3$PI know you don't want to talk about it,$w4
so I won't force you or anything.$K
$F1$PIt's not like I don't want to. It's just...
It's hard to talk about my past.$w4
Still...$K$P$FSYou deserve to know as much about
your father as possible...$w4
All right, I'll tell you.$K
$F3$PGreat!$K
$F1$PWhen I was a Crimean knight,$w3 I entered
an officer exchange program and was sent
to Gallia.$w3 Where your father was.$K$POn my first day, they held a joint training
session in the royal hall. That's where I saw
Commander Greil's might for the first time.$K$PHe took on wave after wave of knights and
defeated them like they were children.$w3
His swordsmanship was brilliant...$K$PThe other knights barely had time to lift
their weapons before Commander Greil
had them on the ground.$K$PHe was the mightiest warrior
I had ever seen. My body...$w3
trembled at the thought of it.$K
$F3$PWhoa.$K
$F1$PI tried to cross swords with him,
but he was so far out of my league...$w4
Ha! It was laughable!$K$PBut I asked him to train me, and he
agreed. After that, whenever we had
a spare hour, we would meet and spar.$K$PWe soon grew close, and$w4 after a
few weeks, he invited me to his home.
That's when I saw you.$K
$F3$PMe?$K
$F1$PYes.$w4 You were sleeping in your
mother's arms, and she was smiling.$w2
You were adorable.$K$PThe Commander looked at you with such
kind eyes...$w4 I saw a different person
than the man who wielded a sword.$K
$F3$PI see.$K   $R�w�i��b|$B�x���w�i|$<$F1$FCL_IKE|$F3$FCL_TIAMAT|$F1$PTitania?$w4 I wish to thank you.$K
$F3$PW-what?$w4 What's with all the formality?$K
$F1$PThere's no guarantee that any of us will
see tomorrow, and I want to tell you this
while it's still in my head.$w4 Will you listen?$K
$F3$PUm...$w2 All right, but...$w4what's with you?
And what have I done to
deserve your thanks?$K
$F1$PYou have done much.$K$PYou helped my father build this company.
He had lost his wife and had two young
children to care for...$K$PI wish to thank you for that.$K
$F3$P...Oh, Ike...$K
$F1$PI've taken everything in my life for granted,
and it was all possible because of you.$w4
My thanks is far too late in coming.$K
$F3$PIt's not necessary, Ike.
What I did, I did because--$K
$F1$P$FSYou loved him.$w5
Didn't you?$K
$F3$P...!!!$w4
...$w5Um...$K
$F1$P$FAPerhaps I'm wrong.$w4 Regardless...
I stand here alive today because of you.
And I still want to thank you for it.$K$PHad you not lent a helping hand,
I would most likely be dead. And my
father's life cut short as well.$K$PYou helped to keep him alive until the
Black Knight brought him down...
You made his final years happy.$K$P$FSThank you.$K
$F3$POh, Ike...
...I don't...
...$w3Sniff...$K$w2$P$Fc...Sniff...$w2
...Sniff...$K
$F1$P$FAUnlike my father, I lack both experience
and strength, but...$w4 I'm learning.
Please, keep aiding and supporting me.$K$P$FSPlease...$K
$F3$P$Fd$FS...Sniff...$w4 Of course...$w4
Of course I will, Ike.$K  $R�w�i��b|$B�x���w�i|$<$F1$FCL_JANAFF|$F3$FCL_LUCHINO|$F3$PYou must be a Phoenicis knight.$K
$F1$PEh?$K
$F3$P$FSI don't believe I've had the pleasure.$w4
I am Lucia of Crimea,$w3 a vassal of
Princess Elincia.$K$PI wish to tender my cordial thanks for
the aid and succor your country has
granted us. Will you accept it?$K
$F1$PUh...$w4 Sure, why not?$K
$F3$P$FA...$K
$F1$P$FS...I mean, um...$w3 Thanks for your courtesy.$w4
I'm Janaff.$w4 I am here at the
command of our king.$K$PSo if you really want to thank someone,
you should thank our king.$K
$F3$P$FSVery well.$K$PAlthough telling him in person would give
me much pleasure, such luxuries are not
feasible under the circumstances.$K$PPlease give my regards to King Tibarn.
Long life to him!$w2 Huzzah!$K
$F1$P...$w4All righty then...$K
$F3$P$FAWhat is it?$K
$F1$P$FSWell, I don't know that we need the
formality.$w4 I mean, we're fighting
in the same army, right? Right...?$K$PHey, I've got a better idea!$w3 Let's go have
a wild night on the town to fortify
our new friendship!$w4 I'm buying!$K
$F3$POh, I could not. My father would not
approve of me going out
without a chaperon.$K
$F1$P$FAWhat?$w4 Such a shame!$K$P$FSYou look like a gorgeous woman,
but you're still a child?$w4
I can never tell how old you beorcs are!$K
$F3$P...$K $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_JANAFF|$F3$FS$F3$FCL_LUCHINO|$F1$PMy homeland of Phoenicis is bordered
by the South Sea.$w4 It's a wonderful
place to live.$K$PThere aren't that many of us, and everyone
gets along...$w4 I've seen many countries with
my own eyes, but Phoenicis is the best!$K
$F3$PDid Phoenicis have diplomatic relations
with other countries?$K
$F1$P$FANo, we don't associate with the others.
We used to be allied with Serenes...$w3
until those cursed humans destroyed it.$K$PAnd Kilvas is ruled by a cunning and
heartless king.$w4 We have no
trust for him.$K
$F3$PDid you ever associate with
beorc countries?$K
$F1$PHa! That'll never happen!$w4 After the slaughter
of Serenes, the beorc became our enemy.$K
$F3$P$FAI do not blame you for your anger...$w4
$FSBut as I have said, $w2Crimea wishes to
establish diplomatic relations with you.$K$POur late king advocated friendship with
the laguz, and enjoyed a good rapport with
King Caineghis of Gallia.$K
$F1$PSo I hear.$w4 Look, most Phoenicians
would be perfectly happy living their entire
lives without outside contact...$K$PBut I suppose a friendship with Crimea is
possible.$w3 If our king so decides.$K
$F3$PAnd what do you think?$K
$F1$PWhat do I think?$w4 Huh...$K$PI used to loathe huma...$w4beorc. Even hearing
the word made me angry.$w3 But...$w4
Now I think friendship is possible.$K$P$FSThat's all because I met you.$K
$F3$P$FAOh... $w2Well...$w4 Thank you.$w2
I am glad to be of assistance.$K    $R�w�i��b|$B�x���w�i|$<$F1$FCL_JANAFF|$F3$FS$F3$FCL_LUCHINO|$F3$PIn Crimea, we dream of
peace for all people.$K$PFriendship that transcends nation,
creed, and race. Beorc and laguz,
living in harmony.$K
$F1$PTranscending race, huh?$w4 Crimea is
an odd country.$w4 I heard you even let
laguz live within your borders!$K
$F3$PYes, due to our bond with King Caineghis.$w3
And now, Princess Elincia hopes to establish
such alliances with other laguz nations.$K
$F1$P$FSIt's a pretty thought.$w4$FA But do you think
that a friendship which transcends nation,
creed, and race will come so easily?$K
$F3$P$FAIt will not be easy, but it can be--$K
$F1$PFor example.$K$PYou know that Phoenicis and Begnion
used to be bitter enemies, right?$K
$F3$PYes, I know.$K
$F1$PThe apostle finally recognized the Serenes
massacre, but who knows how long it'll take
that news to spread over the country?$K$PBefore that happens, there could be
more fighting.$w4 War might erupt anew.$w4
If so, whose side will you choose?$K
$F3$PI would--$K
$F1$PIt'll be Begnion.$w4 Come on! Am I wrong?$K$PAnd in the eyes of Phoenicis, Crimea is
nothing more than a Begnion colony.$w3
Which means I'll fight against you.$K
$F3$PPrincess Elincia would do everything
in her power to avoid such a war.$K$PHowever, I am her loyal vassal.$w4
In the event of conflict, my path is clear.$K
$F1$PSame here.$w4
The king's ally is my ally.$w4
And the king's enemy...$K$P$FSBut if I can help it, I'd rather not fight
a good-looking woman like you!$w4
Dinner would be much more enjoyable.$K
$F3$P$FSI agree, Janaff.$w2 When this war is over and
Crimea rebuilt...$w4let's meet again.
Not as enemies, but as friends.$K
$F1$PI hope you'll be old enough to go out
without a chaperon by then!$K
$F3$P$FAI hope so as well.$K  $R�w�i��b|$B�x���w�i|$<$F1$FCL_OSCAR|$F1$PUm...$w4 Hi there.$K
$F3$FCL_JANAFF|$F3$PYes?$K
$F1$P$FSHello!$w4
$FA...Um...$w4
Nice weather today!$K
$F3$PCan I help you with something?$K
$F1$P$FSNo, not really. I'm just...$K
$F1$P$FA$F3$PSo, you want nothing from me then?$w4
What an odd fellow.$w4
Well then, I'll be going.$K$PI don't get these beorc at all.$K
$F3$FD$P$w5$F1$PDangit, Oscar! You messed that up!
Stupid! Stupid!$K$PAw, how am I supposed to do this?!$w4
I've never dealt with these
bird tribes before...$K$PBut we're allies!$w2 We have to learn
to communicate with each other...$w4
I'll do it right next time!$K    $R�w�i��b|$B�x���w�i|$<$F3$FS$F3$FCL_OSCAR|$F3$PUh...hey there.$K
$F1$FCL_JANAFF|$F1$PYes?$K
$F3$PWe meet again! Ha ha!
Haaa...$K$PUh...sorry about the other day.$w4
I don't have much...$w4experience
talking to laguz, so...$K$PHey,$w4 is there anything you don't
understand about our company?!$w4
Maybe I can help!$K
$F1$PNo, not particularly.$w4 Why?$K
$F3$PWell, I just thought...$w4 I mean, I have a
young brother that's just about your age...$w4
...Come on, Oscar, get it together...$K$PUm...$w4 Wow, you laguz are just so
incredible!$w4 I mean, even a small kid
like yourself can fight so--$K
$F1$PDid you just call me a child?!$K
$F3$P$FAW-what's wrong?$K
$F1$PSee here!$w4 I'm not a child!$w4
I'm over 100 years old!$K
$F3$PWha...?$w4
A hundred...$w2years...?$K
$F1$PI don't know how old you are, but
no one calls me a child to my face
and lives to tell about it!$K$PDon't you EVER call me that again!$w4
Got it, human!?$K
$F3$POh yeah, got it! Totally!$w3
Look, I'm really...$K
$F1$FD$P$w4$F3$PDarn it, Oscar!$w4 Stupid!$w4 So stupid!$w4
Now you've really ticked him off!$K$PMan, what was I thinking? Now I have to
go apologize.$w3 Again!$w2 Probably screw
that up, too...$w4 Aaargh! So stupid!$K   $R�w�i��b|$B�x���w�i|$<$F3$FCL_OSCAR|$F3$PUuuummm...$K
$F1$FCL_JANAFF|$F1$PYes?$w4 Oh.$w4 You.$K
$F3$PLook, I'm really, really sorry about
what I said the other day.$w3
Please forgive my ignorance.$K
$F1$PHa!$w4 Well...$w4I guess it's all right.
As long as you don't do it again.$K$PBy the way, how old are you?$w4
I can never tell with you beorc.$K
$F3$PI'm twenty-four.$K
$F1$PTwenty-four!?$K$PTWENTY-FOUR?!$w4 You don't
even have a full set of feathers yet!$w3
You're a child!$w3 A suckling babe!$K$PI can't believe that the beorc send children
out to battle!$w3 How can you be
so cold and heartless?!$K
$F3$PUh...$w2well--$K
$F1$PWhat's your name, little one?$K
$F3$PO-Oscar?$K
$F1$PJanaff.$w4 But you can call me Uncle Janny.
No wonder you said such rude things.$w2
Heck, I'm surprised you can even talk!$K$P$F3$PYeah, it's...um...surprising all right.$w5
I'm pretty bright for my age.$K
$F1$PWell, it's the duty of an elder to guide
an ignorant child until he can fly.
I forgive your rude remarks.$K$PIf you ever need anything, come find me.$w3
If you have a bad nightmare or something,
Unkie Janny will tuck you in.$w4 All right?$K
$F3$PY-yes. Of course. Thank you.$w4
That'll be...a real help.$K    $R�w�i��b|$B�x���w�i|$<$F1$FCL_LETHE|$F3$FCL_JILL|$F3$PUm...$K
$F1$PCan I help you?$K
$F3$PI, I have a q-question.
Is that all right?$K
$F1$PIt depends on what you're going to ask.$K
$F3$PWhy don't half-bree...$w4 No, that's not right...
Why don't the laguz use weapons?$K
$F1$P...$w4
We laguz are born ready to fight.$K$PWeapons are something that you powerless
beorc created to counter our claws.$w4
We have no use for them.$K
$F3$PI, I see...$K
$F1$PIs that all you wanted to ask?$K
$F3$PUm...$w4no.$w4 There's more.
Why do you detest us...$w4
humans so much?$K
$F1$PThat's a good question.$w4
But I would hear you answer first.
Why do you beorc hate the laguz?$K$P$F3$PIt's because the half-bree...$w4
The laguz are our enemy.$K
$F1$PEnemy...?$K$PIf that's the case, we hate you, too.
As we hate all our enemies.$w4
We're done here.$K$F1$FD
$F3$PWait...$K    $R�w�i��b|$B�x���w�i|$<$F1$FCL_JILL|$F1$PLe...$w4Lethe?$K
$F3$FCL_LETHE|$F3$POh, look what the cat dragged in...$w2
It's you again.$K
$F1$PJill...$w4 My name is...Jill.$K
$F3$PFine.$w3 Jill.$w4 What brings you here today?$w4
More stupid questions?$K
$F1$PI've been thinking about things,
and I haven't been able to figure out...$K$PSee, in Daein$w3 we were taught that you
attack humans indiscriminately and without
mercy. That you are just savage animals.$K
$F3$PLaguz attacking humans? Grrrrawl!
What garbage!$K$PWe dislike even the company of humans
and want nothing to do with them.
Even mauling you would be...unpleasant.$K
$F1$PBut in Daein, everyone believes that
to be the truth! That's why...$w4
That's why I never questioned it.$K$PBut when I saw you fight beside Ike and
other humans on the South Sea,$w4
I knew that something was wrong.$K$PYou were so different from what I imagined!
Ever since I was young, they filled my head
with tales of your terrible claws and teeth...$K$PBut you stand on two legs. And you talk...
You even make jokes!$w3 ...Sometimes...$w4
You're much closer to us than a beast!$K
$F3$PSo glad to hear it.$K
$F1$PI wonder why$w4 humans and sub-humans
started fighting in the first place?$w4 Maybe
we're just destined for war.$K
$F3$PWell, I don't know much about that.$K$PIt's not for me to say if the goddess made
us a certain way or if we're just two races
that don't like each other very much.$K$PBut I know that Gallia, Phoenicis, and Kilvas
all have a reason to hate humans.$K
$F1$PW-what reason?$K
$F3$P...$w4Are you serious? I take it humans
aren't interested in passing history
down to their children...$Fc$K$P...Typical.$Fd All right...$w4 Centuries ago,
when Begnion was still a monarchy, the only
countries were Begnion and Goldoa.$K$PGoldoa was as it is today: a reclusive
nation inhabited only by dragon tribes.$K$PAll the other laguz lived in Begnion
with the humans.$K
$F1$PHumans and sub-humans used
to live together in Begnion?!
I had no idea...$K
$F3$PA human was named as the first king,
although the laguz's superior strength
led us to rule more often than not.$K$PDespite the harmony that most felt about
this arrangement, the senators wanted
nothing to do with it.$K$PIn the name of the "apostle," they claimed
that only a human could be the true ruler
of Begnion...$w3and started a civil war.$K$PLike blind, mewling kittens, the laguz kings
underestimated the situation...
We never had a chance.$K$PCaught by surprise,$w2 my brothers suffered
defeat after defeat in the face of superior
human weapons and magic.$K$P...$w4That was the start of long, dark days...$w4
The start of laguz slavery.$K
$F1$P...$K
$F3$PAfter nearly 200 years, a small number of
enslaved laguz managed to escape
their human captors in Begnion.$K$PThe beast tribes fled to the mountains and
unexplored forest areas--places where
humans were loathe to tread.$K$PThe bird tribes, on the other hand, escaped
to the distant southern islands.$w4 This is
how our laguz kingdoms began.$K$PIt took another eighty years, and the blood
of many brother laguz, until we were
formally recognized as nations.$K$PThis is why we fight.$w4 Why we hate.$w4
Humans don't want former slaves to have
countries and be treated as equals.$K$PLaguz carry the shame of the past deep
in their hearts, and struggle still for
the freedom that you take for granted.$K$PThis is the true history of Tellius...$w4
No wonder humans would bury it.$K
$F1$PI don't know wh--$K
$F3$PWhat to say?$w4 Idiot!$K$PThink!$w4 Think about what I have said.$w4
Think about what you have seen with your
eyes and heard with your ears.$K$PIf you don't even have the guts to do that,
never show yourself in my presence again!$K$F3$FD
$F1$PUm...$w3all right...$K $R�w�i��b|$B�x���w�i|$<$F1$FCL_LETHE|$F1$P...$K
$F3$FCL_JILL|$F3$POh,$w4 Lethe! I thought about what
you said, and I deci--$K
$F1$PI hear the dragon knight we fought in
Talrega was your father.$w4 Why?
Why did you stay with us?$K$PChoosing a band of mercenaries
over your own father?$K
$F3$P...$w4Fate works in strange ways.$K$PHad I not known about Commander Ike$w4
and the mercenaries...$w4 Had I not known
about you laguz...$K$PI'm sure I would be with Daein even now.$w3
Taking pride in my work as Daein soldier
and offering my life for Ashnard.$K$PI wouldn't have hesitated to smite you all.$w4
But now I have learned the truth...$K
$F1$P...And?$K
$F3$PThis isn't like the time I chased your
ship from Port Toha, hoping to win fame
and approval from my father.$K$PWhen I joined you, I acted on my own
accord.$w4 For the first time.$w4 I chose
what I thought was a righteous path.$K$PEven if my decision forced me to
face my own father...$w4 It's too
late to change things now.$K$PThat's why...$w4 I'm here.$K
$F1$PWill you...$w3shake my hand,$w4 Jill?$K
$F3$PWha...?$K
$F1$PI have heard of a huma...$w3a beorc custom
where the shaking and holding of hands
shows friendship.$K$P...I...$w4understand you, now.$w4
$FSI empathize with your choice and$w4
admire the strength it took to make it.$K
$F3$P$FSLethe...$w4 Uh...$w4 Yes.$w4 Of course.
Please, let us shake.$K
$F1$PIf we listen to each other and are$w4
willing to compromise...$K$PI know the beorc and laguz can$w4
come to live with each other.$w4
I'm sure of it.$K   $R�w�i��b|$B�x���w�i|$<$F1$FCL_JILL|$F3$FS$F3$FCL_MIST|$F3$POh, there you are.$K
$F1$PBack again, Mist?$K
$F3$PUh-huh.$w4 Because you didn't
join us for supper.$w4 Again.$K
$F1$PNo one wants to share the table
with a Daein soldier.$w4
It would ruin the meal.$K
$F3$PMy brother says he doesn't care.$K
$F1$PHe says that...$K
$F3$P$FSAnd I'm just glad to have someone
close to my age traveling with us!$w4
So come on, let's go eat something.$K
$F1$PI... I can't.$w2 Sorry.$K
$F3$PI see.$w4 Well then...$w3 I'll just have
to bring the food to you!
I'll be right back!$K$F3$FD
$F1$PB-but...$w3 Hold it a second!$K  $R�w�i��b|$B�x���w�i|$<$F1$FCL_MIST|$F3$FCL_JILL|$F1$PDoes that taste good, Jill?$K
$F3$PMmrph...$w4 Yeah, it's really good.$w4 Why?$K
$F1$P$FSBecause I made it!$w4 I'm glad you like it.$K
$F3$PYou made this?$K
$F1$PYep.$w4 I call it Mist's Magical Meatloaf!$w3
It's chock full of stuff that's good for you,
especially when you're sick.$K$PYou look real sad and you never eat,
so I thought this would make you
feel better.$K
$F3$PYou're worried about me?$w4 Why are you so...$w4
nice to me?$w4 I'm a Daein sol--$K
$F1$P$FAStop.$w4 Please stop saying that.$K
$F3$PWhy? It's true.$K
$F1$PBecause it makes me feel bad, that's why!
You're always saying, "I'm a Daein soldier!
Everyone should hate me! Blah blah blah!"$K$P$FSYou're not a bad person, Jill.$w2
I want to be your friend.$w4
And you make it really hard!$K
$F3$PM-my friend...?$K   $R�w�i��b|$B�x���w�i|$<$F1$FCL_JILL|$F3$FCL_MIST|$F1$PCan I talk to you for a second, Mist?$K
$F3$PSure, Jill.$K
$F1$PUm...$w3 I don't really have anything to say...
I...uh...$w3just wanted to be with you.
I'm kinda lonely.$K$PTell me if I'm bothering you!$K
$F3$P$FSNo! No!$w4 Actually, I was hoping
to see you! 'Cause I'm...$w3
I'm kinda lonely too.$K$PI'm glad you're here.$K
$F1$P$FSGreat!$K
$F3$PTee hee!$K
$F1$PHmm...$K
$F3$PEr...$K
$F1$PUm...$K
$F3$P...$w4Oh, hey!$w4 Wasn't that something?$K
$F1$PYeah, it sure was!$w5 Um...what?$K
$F3$PThe Serenes Forest!$K$PThe way that Reyson and Leanne sang and
made those shiny lights and brought the
whole forest back to life!$K
$F1$PY...$w2$FAyeah...$w5$Fc
That was...$w3sniff... Sniff...$w4
Whaaaaaaaa!$K
$F3$P$FAOh, no! Jill! Why are you crying?$K
$F1$PB-because...$w3that made me understand...$w4
The l-laguz...$w4aren't bad!$w4 I am!$w3
I was the one who was wrong!$K$PWrong about...$w4what I believed...
Wrong about everything!
Whaaaaaaaa!!$K
$F3$POh, Jill, no! Don't cry!
Don't...$w4sniff...$w3oh no!
Whaaaaaaaa!$K
$=0500   $R�w�i��b|$B�x���w�i|$<$F1$Fc$F1$FCL_JILL|$F3$FCL_MISTs|$F1$PWhy...$w4 Why did you lie to me,$w4 Father?$w4
I've had to endure so much pain...$w4
I wish I'd known the truth from the start.$K$P$FdMy father lied to me, Mist.
He lied to build me into a heartless warrior,$w3
a soldier worthy of Daein.$K
$F3$PThat can't be!$K
$F1$PIt is.$K
$F3$PNo father could treat his child like a tool.$w4
There must be another reason!$K$PIf he lied to you...$w4he must have thought
that it would be for the best!!$K
$F1$PMist, you don't--$K
$F3$PYou're a fool, Jill!$w4 A blind fool!$w5
I know you're feeling down, but questioning
a father's love is ridiculous!$K$P$FhBecause $w2a father wouldn't...$w4
A father wouldn't...$w4 Oh, Dad...
...Sniff...$Fc$K
$F1$PMist!$w4 Oh, Mist...$w3
I know...$w4 It's all right...$K
$F3$PFather...$w4
Dad!$w4
...Whaaaaa!$K
$F1$PMist, no! Don't cry!$w4
Don't cry, Mist!$w4
...$FSMist...?$K
$F3$P...Whaaa...$w4 Sniff...$w4 Oh, s-sorry...$K
$F1$PMist...$w4thanks for talking about
my father like that.$w4
I appreciate it...$K
$F3$P$FdJill...$K
$F1$P$FAMaybe I am a fool...$w4 Maybe you're right...
Doubting even for a second the man who
raised me with love and devotion...$Fc...$K$PSomething must be wrong with me...$w5$K$P$FdBut I...$w3 I have to choose my own path.$w4
I have to choose a path that I believe in!
I'm sure...$w4 Father will understand me.$K
$F3$P$FSI'm sure he will, Jill.
I know it.$K $R�w�i��b|$B�x���w�i|$<$F1$FCL_JILL|$F3$FCL_MIST|$F1$PCan I talk to you for a second, Mist?$K
$F3$PSure, Jill.$K
$F1$PUm...$w3 I don't really have anything to say...
I...uh...$w3just wanted to be with you.
I'm kinda lonely.$K$PTell me if I'm bothering you!$K
$F3$P$FSNo! No!$w4 Actually, I was hoping
to see you! 'Cause I'm...$w3
I'm kinda lonely too.$K$PI'm glad you're here.$K
$F1$P$FSGreat!$K
$F3$PTee hee!$K
$F1$PHmm...$K
$F3$PEr...$K
$F1$PUm...$K
$F3$P...$w4Oh, hey!$w4 Wasn't that something?$K
$F1$PYeah, it sure was!$w5 Um...what?$K
$F3$PThe Serenes Forest!$K$PThe way that Reyson and Leanne sang and
made those shiny lights and brought the
whole forest back to life!$K
$F1$PY...$w2$FAyeah...$w5$Fc
That was...$w3sniff... Sniff...$w4
Whaaaaaaaa!$K
$F3$P$FAOh no! Jill! Why are you crying?$K
$F1$PB-because...$w3that made me understand...$w4
The l-laguz...$w4aren't bad!$w4 I am!$w3
I was the one who was wrong!$K$PWrong about...$w4what I believed...
Wrong about everything!
Whaaaaaaaa!!$K
$F3$POh, Jill, no! Don't cry!
Don't...$w4sniff...$w3oh no!
Whaaaaaaaa!$K
$=0500    $R�w�i��b|$B�x���w�i|$<$F1$Fc$F1$FCL_JILL|$F3$FCL_MISTs|$F3$P$FSYou stayed behind because you
knew that, right? That's why you
left the Daein army.$K
$F1$P$FdThere's no way I can go back...$w4
I'm sure my father is ashamed of me...$Fh$w4
I'm sure he thinks me a traitor.$K
$F3$P$FAThat can't be!$K
$F1$P$FdIt is.$K
$F3$PNo father would talk about
his own daughter like that! Ever!$K$PNo matter how many times you fail,$w4
a father will smile and forgive
and say "that's all right"!$K$PBesides...$w4 I'm sure he'd be happy
to know that his child chose a path
she believed in...$K$P$FhBecause $w2a father wouldn't...$w4
A father wouldn't...$w4 Oh, Dad...
...Sniff...$Fc$K
$F1$PMist!$w4 Oh, Mist...$w3
I know...$w4 It's all right...$K
$F3$PFather...$w4
Dad!$w4
...Whaaaaa!$K
$F1$PMist, no! Don't cry!$w4
Don't cry, Mist!$K
$F3$P...Whaaaaa...$w4 Sniff... S-sorry...$K
$F1$PMist...$w4 You make all of my worries
go away when you're near me...$K
$F3$P$FdR-really?$K
$F1$PThe world is hard. Hard and cold and...
terrible.$w4 Even so, you make me...$w4
You make me want to keep going.$K
$F3$P$FhOh, Jill...$Fc$w4 ...Sniff...
Whaaaaaaaa!$K
$F1$PI told you no crying...$w4
Oh, no...$Fc$w4 Sniff...sniff...
Whaaaaaaaa!$K  $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_KEVIN|$F1$PHey, Rhys! Nice day, isn't it.$K
$F3$FS$F3$FCL_KILROY|$F3$POh, hello, Kier...$w3$FA Yaaaa!$w4
What happened to you!?$K
$F1$P$FAHuh? What is it?$K
$F3$PTh-there's blood gushing down the
side of your head!$K
$F1$PHm?$w4 Why, so there is...$w4
$FSIsn't that odd?$K
$F3$POdd?$w4 Please, hold still! Just stay there!$w4
Let me get my heal staff and--$K
$F1$PHeal staff?$w3 Bah! I'm fine.$w2 A scratch like
this will heal itself!$w3 You should have seen
the time I fought the Giant Scorpions of--$K
$F3$POh, my goodness! Are you kidding!?$w3
Please! Hold still...$K$w5$P$Fc...$w2Phew!$w4
$FdThat should do it.$w4
But...$w2how did you hurt yourself?$K
$F1$POh, I was just training over there...
Must have gotten a little crazy!$w3
Hiyaaaaaa! Whaaaaaaa!$K
$F3$PWho were you sparring with?
And why did they hit you hard
enough to draw blood?$K
$F1$PSparring? Ha! No one spars with Kieran!
I'm too much man for them!$w4
No, I was just swinging my axe around.$K
$F3$PH-how do you cut yourself swinging--$K
$F1$PRhys?$w4 I'm a Crimean knight!$w4
We fear neither blood, nor pain, nor terribly
sharp implements being inserted into our...$K
$F3$POoooooohhh...$Fc$K
$F1$P...Eh? $w2What's wrong, Rhys?$K
$F3$PI... $w2I'm sorry.$w4
I just got a little lightheaded there...$K$P$FdDo you always put yourself
through such harsh training?$K
$F1$POf course!$w4 I'm a Crimean knight!
I never cut corners in my training!$K$PWhy, even if the enemy were to lance me
with a thousand barbed and poisoned
needles, I would never stop!$K
$F3$PWell, that's an...admirable attitude...$w4
But I'm still concerned...
Oh, dear me.$K    $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_KILROY|$F1$PAh, Kieran. There you are.$K
$F3$FS$F3$FCL_KEVIN|$F3$POh, hello, Rhys!$w4
What brings you here?$K
$F1$PMay I watch you train? I figured someone
with a heal staff should be around,
just in case an accident happens.$K
$F3$PHa ha ha!$w2 Aren't you a worrywart!$w4
But being watched is good!$K$PNow I can take my training to the
next level!$w4 $FAAll right!$w4 Watch this!$K
$F1$P$FAOh, $w2er... I'm just here to see that
you don't get hurt...$w4 Oh, do be careful...$w4
No!$w3 Don't juggle the lance, too!$K
$F3$P$FSBehold the awesome power of Crimean
Royal Knight Fifth Platoon Captain Kieran!$w4
Now I call this little trick--$K$P$FANnngg...!$w4 Gaaaaa!$w4
Whaaaaaaaa!$w4
...$w4Ah, nuts.$K$F3$FD
$F1$POh, dear heavens!$w4
$FcOh, this is terrible.$K$P$FdStay right there!$w4
Let me take care of you...$K
$F8$FCL_KEVIN|$F8$PHo, I'm fine! Don't worry about old Kieran!
I just need to pull this axe out of my head
here...$w4 Whooo, that's sharp!$K    $R�w�i��b|$B�x���w�i|$<$F3$FCL_KILROY|$F3$PAre you...$w5training again, Kieran?$K
$F1$FS$F1$FCL_KEVIN|$F1$POh, Rhys!$w4 Say, thanks for helping
me out the other day!$K$PWho knew that head wounds bled so much?$w4
Of course, this one time a sellsword
tried to jam hot coals inside my--$K
$F3$PPlease, Kieran! Stop!$w4 You have to
think about your own safety!$K
$F1$PSafety?$w4 Ha ha ha!$w4 I'm not a coward!$w4
Crimean knights fear nothing!$w4 Never!
Why, not even the threat of merciless--$K
$F3$PI know!$w3 I know, but...$w4
If something happens to you,
it will ruin your reputation.$K
$F1$P$FAMy reputation?$K
$F3$PYour gravestone is going to say:$K
"Here lies Kieran the knight! He suffered
a massive hemorrhage in training and
died cold and alone."$K
Are you all right with that?$K
$F1$PHmm...$w4 Y-yes, that could be bad...
Why, no one would ever remember the time
that I fought the Mad Crocodile of Upper--$K
$F3$PPlease!$w4 Promise me that you won't
do any more dangerous training.$K
$F1$PWha--?!$w4 Oh, that's a hard pill to swallow!$w4
But if I die in training before hitting the
battlefield, it would be a shame...$K$POh, what to do...$K
$F3$PWe'd be in trouble if we lose you, Kieran!$K$PEr... $w2Oh!$w3 Yes!$w3 You see, we can't
achieve victory without our greatest soldier--
that would be you--in our army!$K
$F1$PI see. $w2$FSYes, you're right!$w4
You're absolutely right!$K$POur army's finest warrior cannot
afford to push it too far!$K$PVery well.$w4 I'm not sure how this will work,
but I will take better care of myself!
From now on...$w4simple training!$K
$F3$P$FcPhew...$w4$Fd$FS Thanks for your
understanding.$K$PI'll come check on you from time to time.
Remember! Take it easy!$K
$F1$PSure, $w2no problem!$w4 Hmmm...
I guess I'll just...sit down here and...$w3
knit...something...$w4 Ooo, look! A bear!$K
$F3$PNo, Kieran! Noooooooo!$K    $R�w�i��b|$B�x���w�i|$<$F3$FCL_KEVIN|$F3$PHo ho! $w2I would love to have a chance
to train with a pegasus knight. It could
only increase my already mighty skills...$K$P$FSOh, here comes one now!$w2
Marcia!$K
$F1$FCL_MARCIA|$F1$PHuh?$K
$F3$PAhem! Er...$w2 I would like to have
the pleasure of...$w4$FA Oh, pardon me.
I forgot to introduce myself. My name--$K
$F1$P$FSI already know who you are.$w4
Crimean Royal Knight Fifth Platoon Captain
Kieran.$w3 Did I get that right?$K
$F3$PHow do you know my name?$w4
Not to mention my post...$K$PMaybe it was the fame I won during our
last battle?$w4 No, I was only semi-glorious...$K
$F1$P$FAUm...$K
$F3$POr perhaps I have injured you and yours
with a past transgression? Are you here$w4
to revenge yourself on me?!$K
$F1$PNoooo...$K
$F3$POh ho! Then tales of my valor must have
spread to other countries! Perhaps you know
of the time I slew the Giant Spider of...$K$P$FSNaah... $w2That's pushing it.
$FABut $w2it is possible...$w4
Let's see...$w4 It's also possible that...$K
$F1$PHey!$w4 Meathead!$K
$F3$PYaaaa!$w4 W-what?!$w4
Don't scare me like that!$K
$F1$PWe all know your name.$w4
You announce yourself
every time we fight.$K$P"I am Crimean Royal Knight,
Fifth Platoon Captain Kieran!
See me and tremble!"$K
$F3$P$FSHmm... Well, that explains it...$K
$F1$P$FSSo.$w4 How can I help you?$K
$F3$P$FAHuh?$K
$F1$P$FADidn't you want to ask me something?$K
$F3$P$FSOh, that's right.$w4 Er...$w4 Hm?$w4
What did I want to ask you?
$FABlast! Was it... No, that's not it...$K
$F1$PRiiiight.$w3 Well, you come find me
whenever you remember...$K$PSheesh! I think this guy's helmet
is on too tight...$K $R�w�i��b|$B�x���w�i|$<$F1$FCL_KEVIN|$F1$PMarcia!$K
$F3$FS$F3$FCL_MARCIA|$F3$POh, hiya, Kieran.$w4
$FAHow's your horse?$K
$F1$P$FSOh, he's much better!$w4
And it's all thanks to you!$K$P$FAWhen he took ill, I didn't
know what to do, but...$w2
$FSYour first aid saved the day!$K
$F3$PPoor guy was exhausted from the constant
marching.$w4 We've been fighting everywhere.
I don't blame him for collapsing.$K$P$FSLet him rest until he gets used to
this new land. I'm sure he'll get better.$K
$F1$P$FAI had no such knowledge, for I had
never fought beyond the borders
of sweet Crimea.$K$PI thank you with all my heart!$K
$F3$PPfff!$w2 Please! It's no big deal.
I've seen much worse.$K
$F1$PNevertheless, I, Crimean Royal Knight,
Fifth Platoon Captain Kieran, shall return
the favor no matter--$K
$F3$PHey! Big fella! I told you,
thanks aren't necessary.$K$PI'm sure that we'll run into something
that you can help me with...
Er...at least, I guess that might happen...$K$PSo you can just help me out
when that situation arrives.$w4
...If it arrives.$K
$F1$P$FSSay no more!$w4 I will do so with my life!$K
$F3$P$FAPlease! Keep your life!$K$POh, that reminds me...$w2
Didn't you want to ask me
something the other day?$K
$F1$P$FAOh, that...$w2 Well, with my horse's illness
and all, I've forgotten what it was...$w4
But, by my axe, I swear that I will--$K
$F3$PKeep your axe too!$w4 Good gravy,
I can't deal with this guy!$K  $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_MARCIA|$F1$PKieran!$K
$F3$FS$F3$FCL_KEVIN|$F3$POh, Marcia!$K
$F1$PYour horse looks completely healed!$w4
I'm so glad.$K
$F3$PYes, thanks to you.$w4
Let me thank you again!
I, Crimean Roy--$K
$F1$POh, jerky! Not again!$w4 Stop doing that!
Sheesh...$w4
Say, what's with the bucket?$K
$F3$PI was going to wash my horse.
He hasn't been scrubbed down in a while,
and he could use it.$K$PBesides, with all of my amazing adventures,
my poor horse gets quite the workout.
I try to treat him well.$K
$F1$PAw, that's sweet!$K
$F3$P$FAWhat is?$K
$F1$PYou love your horse! That's so nice!
I figured you'd be too busy flexing
or something to notice...$K
$F3$P$FSHe is more than just a simple horse...$w4
He is my brother-in-arms!$K$PSome knights,$w3 some Crimean knights even,
treat their horses like mere transportation...$w3
but I don't feel that way.$K$PAnd it's not just horses.$w2 Armor!$w2 Axes!$w2
Gauntlets!$w3 Boots!$w4 Er...$w5this canteen!
All fighting tools are my brothers-in-arms!$K
$F1$PHow admirable.$K
$F3$P$FANo, Marcia, it is not admirable.$w4
It is simply common sense.$K
$F1$PHa ha! I wasn't sure that you had common
sense! You're always so forgetful and
distracted when it comes to other things...$K
$F3$PHuh!$w4 Well, I can't say that I can agree!
In fact, once while I was fighting the
Giant Whippoorwill of Southern Crimea--$K
$F1$PGood-bye, Kieran!$K   $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_OSCAR|$F1$PHi, Kieran.$w4
How are you?$K
$F3$FCL_KEVIN|$F3$PWhat the...$w3 Oscar!$w4 How I loathe that name!
Don't give me such pleasant greetings!
I care not for them!$K
$F1$P$FAWhat did I do now?$K
$F3$POh ho! Don't tell me you've forgotten
our second year of enlistment!$w4
The year we completed horsemanship?$K$PThere was a final race to end the year...$w4
My beloved horse and I were flawless,
but you beat us by the smallest of margins!$K
$F1$PHuh?$w4 Oh, are you talking about that
race you challenged me to?$K$PYeah, that was fun...$w4 But I thought
the distance between us was
at least three lengths--$K
$F3$PHa! $w2LIAR!$w4 Deceitful, lying, squinty coward!
That was the very moment I marked you as
my archrival!$w4 Don't pretend not to care!$K
$F1$PUh...wow. I had no idea--$K
$F3$PBut why!?$w4 I must know why you left
the Crimean knighthood without
a word of explanation!$K$PI devoted myself to training with my
horse!$w3 I worked day and night so
I could best my archrival...$K$PAnd thanks to my extreme devotion...$w3
I didn't realize you were gone until six
months later!$w3 Delinquent! Reneger!$K
$F1$PWait a sec... $w2Kieran.$w4
How is that my fault?$K    $R�w�i��b|$B�x���w�i|$<$F1$FCL_KEVIN|$F1$POscar!!$K
$F3$FS$F3$FCL_OSCAR|$F3$PHi, Kieran.$w2 Still hanging in there, huh?$K
$F1$PI can't take it anymore! Come back!
Rejoin the proud brotherhood
of the Crimean knights!$K
$F3$PThis is sudden--$K
$F1$PAs a former Crimean knight, surely you have
some sense of loyalty! What say you!?
Rejoin! For king and country!$K$PThe homeland is in danger!$w4
Any who used to be Crimean knights
should come rushing to her aid!$K
$F3$PYou have a point.$w4 And I'm glad I'm able
to help rebuild the homeland,
even if it's as a mercenary.$K
$F1$PI'm not here to make you glad!$w4 I'm here
to convince you to be a knight again!$K$PYou're not fulfilling your allegiance to
sweet Crimea by being a mercenary!$w4
How can you sleep at night?$K
$F3$PI love Crimea, but I'm happy here.
I want to serve Ike as a member
of the Greil Mercenaries.$w4 Forever.$K
$F1$PDarn! $w2Why!?$w4 What draws you guys
to such a life...?$K$PWhat could make the mercenary life
so appealing that you would sell your
loyalty to our glorious homeland, Crimea?$K$PA-ha!$w4 Could it be the nice fat salary!?$w4
That's it!$w4 I remember you saying that you
needed money!$w3 Ho! Loose lips sink ships!$K
$F3$PIf I wanted money, I would have stayed
with the Crimean knights.$w4 I only get
about half of that now.$K
$F1$PWhat in the--!?$w4 Bah! Wake up, man!$w4
Can't you see you're being duped!?
Honor! Fortune! Glory! It can be yours!$K
$F3$PI doubt it.$K
$F1$PBah, I say!$w2 You're hopeless!$K
$F3$PWho's hopeless...?$K  $R�w�i��b|$B�x���w�i|$<$F1$FCL_KEVIN|$F1$POscar!!$K
$F3$FS$F3$FCL_OSCAR|$F3$PHello, Kieran.$w2 Are you going to ask me
to return to the Crimean knights again?$K
$F1$PYou guessed it!$w4 I'm a Crimean knight...
and I'm very proud of that fact!
No better friend! No worse enemy!$K$PA knight distinguishes himself in battle,
returning in triumph to hear adulation
from the people and praise from his lord!$K$PWhen you make your name as a knight,
everyone knows you! The world is
laid at your feet!$K$PAnd above all else, you can defend our
beloved Crimea and her people with
your own two hands!!$K
$F3$PThat certainly sounds nice.$K
$F1$PIt's better than the life of a mercenary,
cavorting with outlaws and entering
battles from which you never return!$K$PWhy, Oscar? Why!?$w4
I just don't get it!$K
$F3$P$FA...$K
$F1$PYou're my archrival!$w4 That's an honor!
I know your true skills
better than anyone.$K$PIf you say you will come back, I'll do
everything I can to recommend your
honorable return to the knights!$K
$F3$P$FSHeh. Thanks, Kieran.$w4
But I'm not returning.$K$P$FAAfter joining the mercenaries,
I had a chance to see the world.$w4
I saw grief with my own eyes.$K$PPeople subjugated by the powerful,
losing everything and dying alone...$w4
Countries can't save people like that.$K$PIt's up to men like us--men who are
in the thick of the action--to aid those
who cannot aid themselves.$K$P$FSBesides, I have no use for honor.$w4
As long as I can defend the family called
the Greil Mercenaries,$w3 I'm happy.$K
$F1$PBla...$w4 Blast!$w4
You've outdone me again!
How can this be?$K$PI don't know why or how, but...$w2
I feel you beat me yet again!$K
$F3$PYou didn't lose.$w4 There are many things
that a brave knight like yourself can do
that we mercenaries cannot.$K$PSo let's both do our best.$w4 We may
stand on different sides of the field,
but we aspire to the same ideal.$K
$F1$PI see...$w4 Then I will ask you no more!!$K$PWatch me!$w4 When Crimea is fully
restored, my distinguished services will
resonate throughout the ages!$K$P$FSYou'll hear about it wherever you are!
I'll make sure of it!$K
$F3$P...Yes, I'm sure you will.$w4
And when I hear your brave tales,
I'll toast your success!$K   $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_LOFA|$F1$PRhys!$K
$F3$FS$F3$FCL_KILROY|$F3$PHello, Rolf.$w4 Oof!$w3 Thanks for the hug!
Why are you running like that?
Did something happen?$K
$F1$PNope. I just ran because I saw you!$w4
Say, how are you feeling?$K
$F3$PToday I feel fine, thanks.$w4
I did light exercise this morning and
finished all my breakfast.$K
$F1$POh, I'm glad to hear that!$w4
When it's hard for you, let me know!$K$P$FAI remember when you used to get
sick and stay in bed all the time!
But here you are, fighting every day.$K
$F3$PHa! I remember those days...
This new job is hard sometimes,
but it's nice to be with everyone.$K
$F1$P$FSI know!$w2 All that you and me and Mist
ever did was stay behind at the stupid fort
while everyone else was fighting.$K$P$FABeing left alone was sad and scary, huh?$K
$F3$P$FAYes, I suppose it was...$K$PRemember the time we heard Commander
Greil discussing that dangerous mission in
the strategy room?$K$PWhen our friends left the fort, the three
of us prayed so hard for their safe return...
Those were the longest days of my life.$K
$F1$PThat's why I'm scared to fight sometimes...$K
$FSBut I still think it's good that we're
fighting together now!$K
$F3$P$FSPositive thoughts are always a help.
It's pointless to focus on the negative
all the time.$K$P$F1$PYou said it, Rhys! Let's think positively!
$w4$FAOtherwise, $w2I...$K
$F3$P$FAOtherwise what, Rolf?$K
$F1$P$FSOh, um...nothing!$w4 I gotta go see Mist now.
See you later, Rhys!$K$F1$FD
$F3$PHmm...$K   $R�w�i��b|$B�x���w�i|$<$F3$FS$F3$FCL_LOFA|$F3$POh, Rhys! What's wrong?$K
$F1$FS$F1$FCL_KILROY|$F1$PHm?$w4 Nothing, Rolf.$K
$F3$P$FAAre you feeling sick?
Are you gonna barf?$K
$F1$PNo, no.$w4 What makes you think that?$K
$F3$PDon't lie!$w4 I can tell!$K$PYour hands and face always turn pale when
you're sick!$w4 Let me see your hands!$K$F3$FD
$F2$FCL_LOFA|$F1$P$FAHey, stop that! I'm only wearing gloves
because they're fashionable right
now! Don't take those...$K
$F2$PAHA! They're cold! Cold as ice!
You're supposed to tell me when
you're having a rough time of it!$K
$F1$P...Sorry, Rolf.$w4 But I'm well enough
to move around a battlefield,
so I'll be all right.$K
$F2$FD$F3$FCL_LOFA2|$F3$PYou're talking about a battlefield, Rhys!$w2
Not some fort!$K$PDon't pretend to be fine if you're not!
$FhYou'll end up dead if you keep
doing stuff like that!$K
$F1$PRolf...$w4 I...$w2 I'm sorry...$K
$F3$PHmph!$K
$F1$PI'm really sorry, Rolf.$w4
I wish... Cough! I wish I wasn't so frail.
It would be nice to be strong.$K
$F3$P$FdWell, I wish your staff could heal
sicknesses and not just big gaping
axe wounds!$K
$F1$PSo do I...$w4$FcSigh... I wish I had a better plan
than just waiting for it to pass.$K
$F3$FD$F1$P$Fd$F4$FS$F4$FCL_LOFA|$F4$PWell, I'll ask Ike to let us fight together.
At least then I can keep an eye on you.$K
$F1$P$FSThanks, Rolf...$K  $R�w�i��b|$B�x���w�i|$<$F1$FCL_LOFA|$F1$PRhys?$K
$F3$FS$F3$FCL_KILROY|$F3$PRolf?$w4 What's up?$K
$F1$P$FSYou're feeling better today, huh?
I'm glad. You were so sick last time...$K
$F3$P$FAAll I ever do is cause you to worry...$w4
Maybe I should just leave the mercenaries.
I don't want to be a burd--$K
$F1$P$FANo!$w4 You're wrong!
That's not what I meant at all!$K
$F3$P$FSI know, Rolf.$w4
$FABut...$w3 It's hard for me.$K$PThe fighting is difficult enough, but to
cause everyone grief on top of it...$K$PAnd it's not just you, either.
I cause Ike and Titania trouble, too.$w4
Maybe I'll just pack my things--$K
$F1$PN-no! I don't want you to go! If you leave,
I'll cry!$w4 I wasn't blaming you, you know?
You can't help being barfy all the time.$K
$F3$PRolf...$K
$F1$POh, that's not what I meant.$w4
Listen, just count on me, all right?
I'll help you.$K
$F3$PWhat did you say?$K
$F1$PFighting our enemies is really scary!
In fact, once I almost wet my...$w5
Anyway! I don't want anyone to die.$K$PBefore, all I could do was wait and pray,
but now I can fight and defend everyone!
That makes it easier to focus.$K$P$F3$PI understand.$K
$F1$PThat's why I want to defend you, Rhys!
If I know that I always have to defend you,
it will make me less scared.$K$PAnd the more I do it, the stronger I get!$w3
So don't you dare leave us!$K
$F3$PRolf... $w2You...$K$P$FSYou've really grown up.$w3 All right,
it's a deal! I won't hide anything
from now on.$K$PAnd I'll count on you, too!$w4 You can be
my very own knight in leather armor!$K
$F1$P$FSYeah, that'll be great!
...$w6Um, hey, Rhys? Don't tell anyone that I
almost...$w5 All right?$K    $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_TIAMAT|$F1$PHow are you feeling, Rhys?$K
$F3$FS$F3$FCL_KILROY|$F3$PGood.$w4 No fevers or shaking today!
Thanks for asking.$K
$F1$PYou know, I was just thinking about the
first time we met.$w3 It was almost a
year ago to this very day.$K
$F3$PWas it really...?$w4 Oh, you're right!
My, time does fly.$K
$F1$POf course, I don't remember much of
the initial encounter, since I was
unconscious and bleeding! Ha!$K$PRemember that? I don't know why we didn't
bring a healer with us that day...$w3
Fighting bandits without a staff? Not smart!$K
$F3$PIt was lucky that I found you. I didn't
usually venture that deep into the forest,
but I was short on medicinal herbs.$K
$F1$PYeah, those bandits were a rough lot...
Their stomping ground was right near
your village, actually.$K$PIt's all coming back to me now...
They were tougher than I'd thought.$K$PWe took most of them out with ease,
but one fled into the woods and I
gave chase.$w3 Big mistake.$K$PMy horse got hung up in the undergrowth,
and that bandit got the drop on me...$w3
At least Shinon hit him before I was killed.$K
$F3$PGatrie and Shinon were both really worried
when they brought you back to my
parents' house.$K
$F1$PReally? I didn't know that. Hmm...$w4
I didn't think Shinon ever worried
about anyone...$K$PBut they stayed with me until my wounds
were healed, I remember that.$K$PYou know, if it wasn't for your good work,
I wouldn't have been able to use an
axe anymore!$w4 I really appreciate it.$K
$F3$PNo, I should thank you. You convinced Greil
to hire me! And now I can send money
back to my parents.$K$PThey're both so old, and I'm their only
source of income.$K
$F1$PYour parents were very kind.$w2 Especially
your mother...$w4 And she made that great
wildberry pie!$K$PTo repay their kindness, I will protect their
only son no matter what.$K
$F3$POh, I appreciate that, Titania!$K    $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_KILROY|$F1$PTraining again?$K
$F3$FS$F3$FCL_TIAMAT|$F3$PYep. I get antsy if I don't train every day...$w2
Kiyaaaa!$w2 Haaaaaa!$w4
Whew!$K
$F1$PWould you mind if I joined you
for a while?$K
$F3$P$FAWhat? You want to train?$w3 Really?$w4
Well, no, of course I wouldn't mind.
Um...why?$K
$F1$PI was hoping to find some way to...$w3
defend myself$w4 I hate being a burden
on everyone.$K
$F3$PRhys!$w4 You're a healer, not a fighter.
That's not your fault.$K$PI don't even think you know which end
of a sword to stick in someone!$w4
Maybe...$K
$F1$P$FAYes, Titania?$K
$F3$PI just wonder if you'd be happier had you
not rescued me.$w4 Perhaps living in peace
with your parents is more your style.$K
$F1$P$FSOh, I don't know. That life wasn't easy.
I have a small, frail body, and there were
few jobs for me in our village.$K$PMy parents were always worried about
me. I was sick all the time, and constantly
getting bumps and scrapes...$K$PThey only agreed to let me follow you
because you were a strong mercenary
group! They figured I would be safe.$K
$F3$P...There must be safer jobs out there! You
could be a fisherman. Or a botanist!$w4
Do you like plants?$K
$F1$POh, that would bore me to tears!$w4
...Titania...I love this job.
I don't want to quit.$K$PI was a sickly child, and I didn't get out
much.$w2 I used to sit inside and
listen to the other children play...$K$PIn those years, my uncle took me under
his wing.$w2 He was a mercenary, too.$K$PHe used to spin unbelievable yarns about
his exotic travels and fantastic battles...
It inspired me.$K
$F3$PI had no idea!$K
$F1$PKinda funny, isn't it?
You know, I shouldn't say this, but...$K$PSometimes, when we fight one long battle
after another...$w4 It makes me happy.
I feel like I belong.$K
$F3$P$FSYou're a big part of our company, Rhys.
I'm glad to hear you say so.$K    $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_KILROY|$F1$PHello, Titania.$w4 Could I join your
training again today?$K
$F3$FS$F3$FCL_TIAMAT|$F3$PSure, go ahead!$w3 Looks like you're getting
your strength back.$w4 You look healthy.$K
$F1$PYes.$w2 Thanks to you.$K
$F3$POh, $w2I didn't do much...$K$w3$P$FASay, Rhys?$w4 What do you think of Ike?$K
$F1$P$FAIke?$w4 Well, I'm not the person to be
judging another's battle skills, so I guess
you want to know my take of the man...$K$P$FSIke...$w4 Well, despite his appearance...$w2
and the occasional angry outburst...$w4
he can be very thoughtful.$K$PMost importantly, he has doggedness,
determination, and grit. He possesses the
strength to turn ideal into reality.$K$PI think he is the right choice
to lead the Greil Mercenaries.$K
$F3$P$FSI agree with you.$w3
$FABut he is still young.$K$PHe still has much to learn, and I wonder
how those experiences will shape him.$w4
...Frankly, I'm a little concerned.$K
$F1$P$FAWhy is that?$K
$F3$POur company is only going to grow,
and he will soon face many hard choices...
and also some temptations.$K$POh, we'll make money...$w4 But we're
going to get job offers that will result
in people getting hurt. Or worse.$K$PAnd to feed and equip a group of this size,
we'll need jobs with a certain
amount of risk.$K
$F1$P$FSCommander Greil faced those same
problems, didn't he?$K
$F3$P$FSHe did, but Greil...$w4 He was different.
The original Greil Mercenaries were famous
for not being typical mercenaries.$K$PSometimes we took on jobs for free...
and we helped countless people at the
expense of our own coffers.$K
$F1$PI believe that Ike holds the same ideals
as Commander Greil.$K
$F3$PI'm sure he does.$w2
...Yes, I'm sure of it.$K$PIke will definitely find reasons for us to
fight and live.$w4 He'll pick the right path.
I won't have to tell him anything.$K$PAll we have to do is believe in Ike
and follow him...$w4to the end.$K
$F1$PAgreed.$K $R�w�i��b|$B�x���w�i|$<$F1$FCL_VULCI|$F3$FCL_KILROY|$F3$PUm... $w2H-hello!$w4
Hello there!$K
$F1$PMmm?$K
$F3$PEr...$w4 I'm...$w4 I'm sorry!
I didn't mean to make you mad!$w4
I just wanted to talk to--$K
$F1$PI'm not mad.$w4
Can I help you with something?$K
$F3$P$FSOoh! Oooooh!$w3 I'm so glad!
I'm Rhys!$w4 N-nice to meet you!$K
$F1$PEr...hello.$w4
I am Ulki.$K
$F3$PEr... Well...$w4
Say, you can really fly with
those wings, huh?!$K$PI saw you turn into a hawk before...$w4
It was amazing!$w4 I envy you!$K
$F1$PMrrr?$K
$F3$P$FAOh, $w2sorry...$w4 That probably sounds weird.
$FSI've always been sickly. When I was
little, I spent a lot of time in bed.$K$PSo...$w4 I used to gaze out the window
and see all the little birds
flying around the sky...$K$PIt must be fantastic!$w3 Flying wherever
you want, whenever you want?!$K
$F1$PUm... Fantastic. Yes. I suppose.$w4
I never thought of it.$K
$F3$POh, I don't blame you! After all, you've
been flying since you were born...$w4
Soaring through the skies like a puffy cloud!$K
$F1$PMmm? Clouds do not soar...$w4
I am confused.$K $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_KILROY|$F1$PUlki!$K
$F3$FCL_VULCI|$F3$POh, the sickly beorc.
Hello.$K
$F1$PI had the honor of seeing you battle
the other day!$w3 Your 360-degree
loops were extraordinary!$K
$F3$P...I did a loop?$K
$F1$PAnd right after that, you circled many times
and then dived at that soldier...$w4 BLAM!!
Hee hee! Oh, you're something else!$K
$F3$PWell...$w4 I suppose...$K
$F1$P$FcOh, how I wish I could soar through
the air like that!$K
$F3$PEr, yes. You mentioned that.$K
$F1$POn sunny days, I'd take to the skies and
land on a high mountain peak, then
gaze down on the villages below...$K$POh, just thinking about it makes
me so happy!$w4 Ahhhhh...$w4
Aaaaaaaaaahhhhhh...$K
$F3$PEr...yes. I suppose...$w4
Flying could also help you
take care of injured people.$K
$F1$P$FdHey, that's a great thought!$w4
I could just zoom right over and treat
the victim!$w4 I'd love to do it!$K
$F3$PHmm...$w2 Well...$w4 Do you want to...
give it a try?$K
$F1$P$FAHuh!?$w4 But h-how!?$w4
I don't have wings or anything...$w2
Oh, wait...$w4 Are you serious?!$K
$F3$P...$K  $R�w�i��b|$B�x���w�i|$<$F1$FCL_VULCI|$F3$FS$F3$FCL_KILROY|$F3$PUlki! Oh, my dear friend Ulki!
I'm so looking forward to the next battle!$K$PI mean,$w2 fighting is terrifying
and I'd like to avoid it and all that...$w4
But I'm going to be so useful!$K
$F1$PI'm glad to hear--$K
$F3$P$FABut I have to hang on to your back!
No matter what...$K$P$FSOh, $w2may I practice with you
just one more time? Please?
Pleeeeease?$K
$F1$PEr...$w4 No.$w3
I can't use up any more
energy before battle...$K
$F3$P$FAOh, I see...$w4 I apologize...
Yes, very sorry...$w4 Um... Say...
Does shifting tire you?$K
$F1$PYes.$K
$F3$PWhat!?$w4 Oh no!$w4 But... You let me
practice with you! For days!
Yesterday we flew for nine hours!$K
$F1$PWell...$w4 It was my fault
for not saying anything.$K$PYou looked so happy that...$w4
I didn't have a chance to bring it up.$K
$F3$PYou know what?$w3 I think you're pale...
And your eyes are all bloodshot...$K$P...$w4
$FcI'm sorry...$w4
Let's just forget it...$K
$F1$PPerhaps we should.$w4 It might be dangerous
for me to go into battle like this.$K
$F3$P$FdI agree...$K
$F1$PBut...$w4if we ever have some free time,
I will take you on a ride.$K
$F3$P$FSWhooo-hoooo!$w4 Yes, thank you!$w4
That would be great, Ulki!!$K   $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_WAYU|$F3$FCL_KILROY|$F1$POh... $w2It's you?$w3 YOU!?$w4 RHYS!?$w4
Well, can't be picky, I guess...
Hiyaaa! Take this weapon, cur!$K
$F3$PUm... Oh, hello, Mia. What is this?
A sword? Yes, I think that's right...
Ooof! It's heavy!$K
$F1$PYessir!$w4 Who would have thought
it was gonna be you!? Funny, that.
Now... Get ready! En garde!$K
$F3$PYaaaa! Wait! S-stop, please!
I don't know what's going on!$w4
I c-can't use weapons!$K
$F1$P$FAWhaaat!?$w4 Oh, come on.
You can use them a little, right?
Riiiight?$K
$F3$PNo! I've never even touched one before...$w4
B-but if you just want me to hold it, I can.$w4
Hmmm... I hold this end, right?$K
$F1$P$Fc...$w5
Oh, this is so disappointing!$K$P$FdI had my fortune read the other day,
and the old crone told me that I'd soon
come across my one true foe!$K$P$FS"With white robes flowing in the breeze,
your archrival rides toward you..."$w4
$FAOh, I was so looking forward to it!$K
$F3$P$FSUm...sorry to disappoint you.$w4
I'm pretty sure that it's not me.$K
$F1$PAw, it's not your fault, Rhys.$K$PI was just prepped for a big fight with my
archrival, and then you came walking by...
Thought maybe it was you, you know?$K
$F3$P$FAUm... I can just stand here and hold the
sword if you want to hit it a few times.$K
$F1$P$FSNah, forget it. I don't want you to
get hurt.$w4$FA I'll give up for today...$w3
$FcShucks.$K   $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_KILROY|$F3$FCL_WAYU|$F1$POh, hello, Mia.$w5 Um...$w4
You're not going to throw a sword
at me again, are you?$K
$F3$PHuh? Oh, heya, Rhys.$w4
I was hoping to run into someone today...$w3
And guess what?$w3 You showed up!$K
$F1$P$FAAhhh! Not that fortune-telling again!$w4
L-look, I d-didn't mean to interrupt you...
Let me just back away now...$K
$F3$P$FSNo! Stick around! I could be wrong.$w4
Maybe fortune-telling can't predict
the future after all...$K$PToo bad! That crone had a great reputation.$w4
$FAWait... $w2Maaaaaybe...$K
$F1$PYes?$K
$F3$P$FSDo you want to train with me, Rhys?$K
$F1$PHuh?$K
$F3$POh, why didn't I see it before!$w4
You have what it takes to be a legendary
swordsman! You just don't realize it yet.$K$PThere is awesome potential within you.
And when you finally realize it, you'll end
up clashing with me as my grand archrival!$K
$F1$PHah! Haaa.... Um... I don't think that's
likely to happen, Mia.$K$PAlthough...it's true that I once wanted to be
a fighter, back when I was a frail child.$K
$F3$PAha! I knew it!$w4 You can't give up
unharnessed talent like yours just
because you're frail!$K$PGive it a try.$w4 C'mon! I'll train you myself!
We'll start with the basics.$K
$F1$PYou...will?$K
$F3$POf course...even if I am training the man
that will one day be my most hated rival!$w4
We better get cracking!$K    $R�w�i��b|$B�x���w�i|$<$F1$FCL_WAYU|$F1$PUhhh...look, I'm really sorry.$w4
It looks like I pushed you a little hard.$K
$F3$FS$F3$FCL_KILROY|$F3$PNo...I wanted to be a myrmidon.$w4
And I had fun...$K$PWell...before the cramps started.$w4
Oooh, the cramps... Yaaaaa...$K
$F1$PAre you sure you're well? You've been
running a fever for days! Are you really
going to battle like this?$K
$F3$PIt'll be fine.$w4 I'm not overdoing it.
I'll just support everyone from
the rearguard.$K$PAnd I'll have you looking out for me, right?$K
$F1$POf course! I feel responsible for your
safety.$w4 I always try to look out for
you and make sure you're holding up.$K$PYou know, I've been thinking for a bit...$K$P$FcAnd... Um...$w4 And I've decided to
stop believing in fortune-telling.$K
$F3$P$FAWell...$w2maybe the fortune's meaning
was just mixed up--$K
$F1$P$Fd$FSHogwash! No more excuses!
It's all a bunch of hooey!$w5
$FABut hey, wait a second...$K$P"With white robes flowing in the breeze,
your archrival rides toward you..."$w4
...RIDES toward you...$K$w3$PCould he be a mounted soldier and not
a myrmidon?$K
$F3$PHuh?$K
$F1$PYou may be horse-riding material, Rhys.$w4
$FSYeah, $w2that's it!$K$PMarching is a lot easier on horseback.
Wouldn't that be better for you?$K
$F3$PWhat!?$w4 Me on h-horseback!?$K
$F1$PYeah!$w4 You wear white, too! Don't you
think you'd look dashing on horseback!?$K$PSwing your staff from the top of a horse
and I'll fight in style beside you!$K
$F3$PWhoa...hold it right there, Mia...$K
$F1$PAll right! It's settled, then!$w4
We've got to get you training!$K
$F3$PHold it!$w4 You've got the wrong guy...$K
$F1$P$FANo, I don't. We're destined to meet!$K
$F3$PWe are?$K
$F1$P$FSYes!$w4 I can't think of anyone else
that could be the man of my destiny!$K
$F3$PD-destiny!?$w4 Wait a second... I thought I
was your archrival!$K
$F1$PNever mind the details!$w4
I am counting on you, Rhys!$K   $R�w�i��b|$B�x���w�i|$<$F3$FS$F3$FCL_LARGO|$F3$PWhoa there!$K
Your arms are huge!!$w4
How'd you get that big?$K
$F1$FCL_MWARIM|$F1$P...?$K
$F3$PI mean, my arms are pretty massive...
but those babies are something else!$K
$F1$PYou have big muscles, too...$K
$F3$PBa ha ha ha!$w2 Brute force is about the
only thing I've got going for me!$w4 Hey,
why are you carrying those water jugs?$K
$F1$PI'm taking them to the well.$K
$F3$PYou're filling all those jugs?$w4 They've got to
weigh as much as an ox once you get
water in them!$K$POne, two, three, four, five...$w2
You've got quite a handful there.$w4
Let me give you a hand.$K
$F1$PYou don't have to do that.$K
$F3$PAw, heck! It's no problem!$K
I may not be able to cast a bunch of
fancy spells, but I can carry heavy stuff
as well as any man or beast!$K$F3$FD
$F1$P...All right, then. Let us go.$K   $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_LARGO|$F3$FCL_MWARIM|$F1$PHow goes it, Muarim?$K
$F3$PLargo.$w4 Thanks for your help the other day.$K
$F1$PBwa ha ha ha! That was nothing.$w4 You know,
I've traveled all around the world, and I've
never seen someone as burly as you.$K$PI'm pretty stout, but I bet you could mop
the floor with me... So who do you think
could lift the most?$K
$F3$PIt's hard to say...$K
$F1$PThe heaviest thing I ever lifted was this tree
I cut down. It was three times my size!$w4
What about you?$K
$F3$PWell...$K$POne time, I chiseled rocks from a mountain
and carried them up to repair a castle wall.$K
$F1$PRocks?! How big were they?$K
$F3$PMmm...big. Taller than me.$K
$F1$PThat's incredible! ...Hey, how do you feel
about a little strength competition? I bet
we'd be pretty evenly matched!$K
$F3$PNo, that's just...$K
$F1$PDon't be so uptight!$w4
Come on! It'll be fun!$K
$F3$P...$FcHmmm...$w4
All right...$Fd But just this once!$K   $R�w�i��b|$B�x���w�i|$<$F3$FS$F3$FCL_LARGO|$F3$PHey, Muarim!$w4 That lifting competition
we had the other day was epic!$K
$F1$FS$F1$FCL_MWARIM|$F1$PYes. It was a good time.$K
$F3$PPeople got interested when we were seeing
who could lift the most cured hams!
That crowd was huge!$K
$F1$PMmm... It got a bit out of hand when we
started lifting people.$K
$F3$PBwa ha ha! We were neck and neck right
until the end.$K$PThe last thing I stacked on my back was
that big smoked ham, but then you picked
up that girl!$K$PWhat was her name again?$K
$F1$PMist.$K
$F3$PYeah, that's her.$K$PWe could have settled the competition if we
had known which was heavier. Huh! I still
think it was the ham...$K
$F1$PYou were quite amazing.$K
$F3$PAmazing? Me?$w4 Naw, not Largo!
You were the incredible one!$K
$F1$PI'm not talking about how many hams
you lifted.$K$PYou were able to draw everyone together.
It gave them a laugh, despite the stress
of battle.$K$PEveryone had a chance to relax
and blow off some steam.$K
$F3$PWell, everybody deserves a good belly
laugh! Bwaaaaa haa haa haaaaaa!!$K
$F1$PYou also treat me and everyone else
the same. You are a good beorc.$K
$F3$PBwa ha ha!$w4 I just call it like I see it!
I don't deserve any credit for that.$K$PFor now, let's call our match a tie.
How about some arm wrestling next time?
There's no way you can beat me at that!$K$P$F1$PHah! We shall see!$K $R�w�i��b|$B�x���w�i|$<$F1$FCL_LARGO|$F1$PThat's strange...$K
$F6$FCL_TAURONEO|$F6$P...$K
$F1$P$FSHey, Tauroneo!$K
$F6$FD$F3$FCL_TAURONEO|$F3$PHmm?$K
$F1$PDon't you think this army is a little odd?$K
I mean, heck! It's not every day that you
see soldiers from this many countries all
mixed into one army.$K$PI've traveled and fought in a lot of strange
places, but this is the first time I've seen
anything quite like this.$K
$F3$PYou're right. There are even former Daein
soldiers in this army.$K
There is no shortage of nationalities,
to be sure.$K
$F1$PMy favorite part about it is we get to
sample all kinds of exotic dishes. Gwa!
I've never snacked so well in my life.$K
$F3$PWhat are you holding?$K
$F1$PThis quill?$w4 Oh, I use it to jot down
ideas so I won't forget them later.
If I don't, I just completely forget them!$K$PBut back to food...$w3 I've noticed that the
laguz sure like their food spicy!$K
And now they've started drinking with us!$w4
Bwaa ha ha! That's great! By the way,
what's your drink of choice?$K
$F3$PDrinks?$w4 I'm not picky.
The stronger the better!$K
$F1$PAnd flavor?$K
$F3$PDoesn't matter.$K
$F1$PBwaaaa ha ha haaaa!!$w4 I like your answer!
I better write that down so I don't forget.$K  $R�w�i��b|$B�x���w�i|$<$F5$FCL_LARGO|$F3$FCL_TAURONEO|$F5$PHmmmm...$K
$F3$P...$K
$F5$PAhhhh... Er... Naaaaaahhh...$K
$F3$PIs something wrong?$K
$F5$FD$F1$FCL_LARGO|$F1$PHmmm?$w4$FS Oh, $w2it's you.$K
$F3$PYou've done nothing but stare at that
piece of paper for hours.$w4
Are you crazy, man?$K$P$F1$P$FAOh, you have a point...$w4 Crazy... Craaaazy...
You may be onto something.
I'll have to write that down.$K$PBut it'll have to wait until later. I can't
think about two things at the same time.$K
$F3$PYou can't? Well, what are you thinking
about now?$K
$F1$P$FSI'm saving up the money I make here to
open my own little place.$w4 I'm thinkin'
a pub would be nice...$K$PIs that a good idea?$K
$F3$PA pub? Yes, pubs are nice. Will you make
savory meat pies? With buttery crusts?$K
$F1$PSavory! Oh, yeah. They'll be the savoriest!
They'll make your head explode! ...I don't
want my customers dropping dead, though...$K
I want everyone to be happy. Hmmm...
Hey, people like butter, right?$w3 There'll be
free sticks of butter on every table!$K$P$F3$P$FSThat's a great dream.$w4
$FAWhere are you going to open your place?$K
$F1$P$FAWell, uh...it may not look like it, but I'm
actually from Begnion.$w2
So I'll probably open my pub back home.$K$PBut from what I hear, Crimea and Daein
are nice places, too...$w4 This is going to
be a hard choice...$K$P$F3$P...$K
Do you want me to help you with the pub?$K
$F1$P$FSOh, yeah! That would be great!$w4
Two people can think about two things
at once. That will help for sure.$K$P$FAAll right, so we'll have savory meat pies...
$FcBut what about the rest of the menu?$K    $R�w�i��b|$B�x���w�i|$<$F1$Fc$F1$FCL_LARGO|$F1$PHmmm...$w4 That's not it.$w4
That's no good, either...$K
$F3$FCL_TAURONEO|$F3$PAre you thinking about your pub again?$K
$F1$P$Fd$FSHey, Tauroneo!$w4 Can you dish me up
some more of your good advice?$K
$F3$PGlad to.$K
$F1$PI'm trying to come up with a name for
my pub.$K
$F3$PWhat do you have so far?$K
$F1$PHow about "Savory Pies And Stuff"?$K
$F3$PHmmm.$w4 It's a bit...odd.$K
$F1$P$FAMaybe you're right.$w4 Let me think...$K$PI want this to be a pub where both beorc
and laguz can walk on in, get a meat pie
and a frosty beverage, and be happy.$K$PSo how about we name it the "All You
Beorc And Laguz Come On Down And
Get Yourself A Meat Pie Pub"!$K
$F3$PThat's a little long.$K
$F1$PNo good, eh? Nuts. What am I gonna do?$w2
I'm no good at thinking up stuff like this.$K
$F3$PMaybe you're trying too hard.$w4
How about naming it after something
you think is important?$K
$F1$PHey, yeah! I'll call it "Calill."$w4
She's always been my favorite.$K
$F3$P$FSNaming it after an old flame, eh?$w4
I say go with that.$K$PI'll be sure to drop in for a pie and a
brew when you open your place.$K
$F1$P$FSYou better! $w2I'll have your favorite
drink waiting for you!$K$PYour favorite drink is...$w4 Wait, I know this...$w4
I wrote it down somewhere...$K$POh, here it is...$w4 Strong!$K
$F3$PYep.$K
$F1$PBwaaa ha ha haaaa!!!$w4 Leave it to me!$K  $R�w�i��b|$B�x���w�i|$<$F3$FS$F3$FCL_WAYU|$F1$FCL_LARGO|$F3$PWow! Look at the arms on that one!$K
$F1$PHmmm?$w4 My arms?$K
$F3$PThey're huge! By the way, I'm Mia.$w4
I'm a myrmidon searching for a sworn
rival.$w4 Do you want to spar?$K
$F1$PSpar?$w4 With you?$w4
Ummm...$w4 I don't know.$K
$F3$P$FAWhat do you mean you don't know?$K
$F1$PI'm not sure how I feel about sparring
with a girl.$K
$F3$PBut I'm a dangerous myrmidon!
A graceful whirlwind of singing steel!$K
$F1$PI don't know how to put this, but...
shouldn't you be doing something more
domestic than fighting with a sword?$K$PI don't know...maybe knitting? Or cooking?
I guess you could learn to be a mage...$K
$F3$P...For your personal safety, I hope you
aren't saying that I can't fight because
I'm a woman.$K
$F1$PWell...$K
$F3$PAll right, you brought this on yourself!
Get ready to fight!$K
$F1$PUhhh...$w4 I was only saying that
people need to be more peaceful.$K$PYeah...that's it. Hey, $w2I've got an idea!
Let's see who can knit better.$K
$F3$PEnough talk! Time to fight!$K    $R�w�i��b|$B�x���w�i|$<$F3$FCL_WAYU|$F1$FCL_LARGO|$F3$PHey, Largo!$K
$F1$POh, it's you again.$w4 Hey, um....
Sorry about, you know, what I said the
other day. My arms and legs are sorry, too.$K$POh...the bruises...$K
$F3$PDon't worry about it. But you know
why I'm here!$K
$F1$PHuh?$w4 Why?! Please don't hurt me!$K
$F3$PWhat else? I came here to get more
sparring practice!$K$PI'm always in search of my true
nemesis!$K
$F1$PYou want to fight again? I know you like
to spar, but this is crazy!$K
$F3$PSo you're saying I can't win again because
I'm a woman?$K
$F1$PWhat?! No! No no!$K$PNoooooo! I didn't say that.
I don't want to spar you!$K
$F3$PI know exactly what you meant!
Well, prepare to feel the wrath of
my training sword again!$K$P$FhAnd if that doesn't teach you,
we'll train some more tomorrow!$K
$F1$PWhoa...this is all a misunderstanding!$K$PYou can't expect me to fight you
again. Look at these bruises!$K
$F3$P$FdYou should have thought about that
before spouting off about male
superiority again.$K$PGet your axe ready!$K
$F1$PBut I didn't say anything!!$K$POooh, all right.$w4 I'm going to be
sore tomorrow...$K
$F3$PHah! I'll go easy on you!$K $R�w�i��b|$B�x���w�i|$<$F3$FCL_WAYU|$F1$FCL_LARGO|$F3$PYou fought...hard...that time!
Who do you think won?$K
$F1$PIt was close, but I think you beat me again.$K
$F3$PAre you sure?$K
$F1$PYep. I'm bushed.$K
$F3$PYou didn't go easy on me because
I'm a woman, did you?$K
$F1$P$FSNot at all. It's just that I'm no match for
that sword arm of yours.$K$P$F3$P...$FSOoooh, boy...$w4 I'm beat!$K
I think I'll go grab some sleep.$K
$F1$P$FAWait....$w4 I know you're tired, but can I
ask you one question?$K
$F3$P$FASure.$K
$F1$PWhy push yourself so hard?$K$P$F3$PBecause I've been told too many times that
a sword doesn't belong in the hands
of a woman.$K$PI've got something to prove.$K
$F1$POh...I get it.$K
$F3$PI understand if I lose to someone with
better technique.$K$PWhen that happens, I can always hone my
skills and work on getting more combat
experience.$K$PIf I lose, it's not because I'm a woman.$K$PIt's because someone trained harder
than me. And if that happens, I'll hone
my skills and come back to beat them.$K
$F1$PAhhh...$K$P$FSNow I understand how you clobbered me
so badly!$K$PBut I can't just lick my wounds. I'll have to
take your advice, get back to practice,
and challenge you again one day.$K
$F3$P$FSWhen?$K
$F1$PHuh?$K
$F3$PYou said you wanted a rematch.
When do you want to do it? You want
a chance to redeem yourself, right?$K
$F1$PBwaaa ha haaaa!$w2 I'm impressed, kid!$w4
I'll just have to keep fighting you until
I win!$K
$F3$PI'll take you on anytime, Largo!$K    $R�w�i��b|$B�x���w�i|$<$F3$FS$F3$FCL_LAY|$F1$FCL_LETHE|$F3$PHey there, Lethe.$K
$F1$PAh, Ranulf.$w4 Glad you could finally join us.$K
$F3$PYes, the tide has finally turned.$K$PHow are you holding up, Lethe?$w4
You and Mordecai have shouldered all
of the burden until now.$K$PI'm glad I can finally take some of the
responsibility.$K
$F1$PApologies are meaningless unless they are
backed up with deeds.$K
$F3$PHa! I see you're as friendly as ever.$K$PBy the way, have you finally warmed
up to this band of mercenaries?$K
$F1$P...$w3In my own way.$w4
But there is still some occasional friction.$K$PI know they are beasts of habit, but must
they always wear so much armor?$K$PThey overwhelm our noses with the stink
of iron and make it difficult to sniff out
the enemy.$K
$F3$PWell, there's nothing you can do about that.$w4
You could go to Ike and ask them to fight
in the buff, but you won't have much luck.$K
$F1$PAnd their eyes are so useless!$w4
I'm amazed the species has lived this long.
Being blind in the dark is lethal.$K$P$F3$P$FAThere's nothing they can do about that,
Lethe.$K
$F1$P$FSI suppose not.$w4 Still, they've done
better than I expected.$K
$F3$P$FSI'm glad to hear they haven't completely
let you down.$K$PYou had quite the tragic look on your face
when you first learned you'd have to
travel with Ike and his merry band!$K
$F1$P$FAPah! Can you blame me?$K   $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_LAY|$F3$FCL_LETHE|$F3$PRanulf, are my soldiers back in Gallia
training hard in my absence?$K
$F1$POf course they are! They're Gallian fighters!
You can trust the defense of the country
to them.$K
$F3$PI'm not nearly so confident.$K$PThey train hard, but they also lack
discipline. They are often at each other's
throats.$K
$F1$PWell, they're just...passionate.$w4
Don't worry. It'll work out in time.$K
$F3$PHow can you be so sure?$K
$F1$POh, relax. You shouldn't be so uptight
all the time.$w2 Why don't you relax
once in a while?$K
$F3$PRelaxing on the battlefield will get
you killed.$K$PSo...is Lyre in your unit now?$K
$F1$PYes, she is. She and her friend Kysha are
giving me quite a hard time.$K
$F3$PKysha is big and strong. You'll have your
hands full if they decide to give you
trouble.$K$PRegardless, I'd still like you to show
them the ropes.$K
$F1$PSo you haven't seen Lyre in a long time?$K
$F3$P...$K
$F1$PI see you'd rather not discuss it.$w4
Fine.$w4 But you should still try to settle
your differences. She's your only sister.$K
$F3$PMind your business.$K
$F1$PFine, fine. Have it your way.$K
$F3$PMy sister aside, I am a little worried about
the unit back home.$K$PWhile you and I are here, the country
is poorly defended.$K
$F1$PYou may have a point.$w4 Maybe I'll mention
it to my superior officer.$K  $R�w�i��b|$B�x���w�i|$<$F1$FCL_LETHE|$F3$FCL_LAY|$F3$PHey, Lethe, about what we discussed the
other day? Plans are in the works to bring
some unit commanders back to Gallia.$K$PIt's not a done deal, but...$w4 I may be able
to put in a word if you want to be
transferred back to Gallia.$K
$F1$PBack to...$K
No. I will stay here.$K
$F3$PStay here?$w4 Are you sure?$K
$F1$P...Er... I wouldn't want something gruesome
to happen to the humans as soon
as I left. I think I'll stay behind.$K
$F3$P$FSHeh...$K
$F1$PWhat?! What's with that smirk?!
You have something to say?!$K
$F3$POh, nothing.$w4 It's just that...when you
used to say "human," you'd curl your
lip in disgust.$K
$F1$PWell, they are disgusting!
I can't stand them...$K
$F3$PHah! You always thrash your tail when you
lie!$w2 It's a dead giveaway.$w2 Don't worry.
I understand why you want to stay.$K
$F1$P...I have to get back to my training.
I have to chew some straw out of
a target dummy.$K$F1$FD
$F3$PWhew!$w4 Must have hit a nerve.$K
$F0$FCL_LETHE|$F0$P...Ranulf?$K
$F3$PYeeeees?$K
$F0$PI admit it. My feelings have changed.$K
$F3$PThey have, huh?$K
$F0$PI once thought your opinion about humans
was weak and disgraceful...$K$PBut now I see your viewpoint. They are
strong allies. They fight by our side.
That's why I'll stay with Ike.$K
$F3$PI see...$K$PWell then, we'll be here to party with Ike
and his ragtag mercenary crew when they
win this war!$K
$F0$PWe can't let our guard down yet.$w4
$FSBut...$w4you're right. I hope to
celebrate with them one day.$K    $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_MORDY|$F3$FS$F3$FCL_LAY|$F3$PHeya, Mordecai! What's up, ya' big cat?!$K
$F1$PRanulf!$w4 It's been a while.$K
$F3$PYes, it has.$w2 Thanks for all your work.$w4
I heard about how fiercely you've fought
alongside these mercenaries.$K
$F1$PIs that so?$w4 I am glad to help.$K$PIke is a good beorc...strong and loyal.
He is worth fighting for.$K
$F3$PDid you have a chance to get to know
some of the other mercenaries?$K
$F1$PSome.$K$PGrrr... I have a question, Ranulf.$w2
Do I speak well in this tongue?$K
$F3$PYou're fine, Mordecai.$w4 Sure, you have an
accent, and you tend to growl a lot,
but the beorc can understand.$K
$F1$PThese words are hard to me.$w4
As a cat, I need no hard words.$K$POne roar is enough for all the forest
to understand.$K
$F3$PThat may be true, but the beorc can't begin
to understand the nuance of our roars.$K$PWe would only scare them.$K
$F1$PYes.$w4 You are right.$K$PThere are good beorcs here.$w4
Scaring them would be...bad.$K $R�w�i��b|$B�x���w�i|$<$F7$FCL_MORDY|$F7$PZzzzzz...$w4 Zzzzzzz...
Puuuurrrrrzzzzz...$K
$F3$FS$F3$FCL_LAY|$F3$PHeya, Mordecai!$w4
Oh...$w4 Are you sleeping?$K
$F7$FD$F1$FCL_MORDY|$F1$PHmm... Aoooooouuughh...$w4 Ranulf?$K
$F3$POh! You're up. Boy, how can you sleep
out in the open like that?$K$PYou and Ike have one thing in common,
and that's iron nerves.$K
$F1$P$FSI trust Ike and his pack.$w4
They keep this place safe.$K
$F3$PAhh, I see...$K$FA$PSay, Mordecai...$w4 I noticed something
the last time I saw you fight.$K$PYou sometimes close your eyes when
you attack the enemy.$w3 Why is that?$K
$F1$P$FA...You have sharp eyes.$K
$F3$PSo why do you do that?$K
$F1$PI have no taste for watching my
enemies tear into long shreds.$w4$K
I must fight hard. I must kill beorc
and laguz...but I do not like it.$w4
So I close my eyes.$K
$F3$PIs that the reason you miss sometimes?$K
$F1$P...You see much.$K
$F3$PYeah, I'm just full of handy talents.$K$P$FSToo bad. It's a bit of a waste.
If it wasn't for your big ol' heart, you'd
be a more efficient soldier.$K
$F1$PI'm...sorry...$K
$F3$PDon't be sorry, Mordecai.
You are who you are.$K
$F1$P...$K  $R�w�i��b|$B�x���w�i|$<$F3$FCL_LAY|$F1$FCL_MORDY|$F1$PGrrr... I am...sorry, Ranulf.$K
$F3$PWhat's the matter, Mordecai?$K
$F1$PI have thought about what you said.
But I can't change how I fight.
It is the way I am.$K
$F3$P$FSOh...$w4 I know.$K
$F1$PI am a warrior, so I fight.$w4
I want to defend my people...and my
friends... So I fight.$K$PBut I can only fight like I know how.$K
$F3$P$FA$FSYou've always been that way. I mean,
you like to take naps with the squirrels!
Like I said, you have a big heart.$K
$F1$P...Sorry.$K
$F3$P$FSDon't apologize. Don't worry about it.$K
$F1$PMaybe...$w3 I cause trouble for Ike and
his pack.$K$PMaybe I am a burden.$w4
This pains me.$K
$F3$PYou're no burden, Mordecai.$w4
You fight hard for Ike. Now we must
continue to fight to end this war.$K
$F1$P$FSYou speak truth.$w4 I want this war to end!$K
$F3$PThen let's get out there and crush
the enemy!$K
$F1$PGrrrrrrrrrrrrrrrr!!$K   $R�w�i��b|$B�x���w�i|$<$F1$FCL_LETHE|$F3$FCL_MWARIM|$F1$PMuarim.$K
$F3$PHello, Lethe...$K
$F1$PHow are you holding up? I take it you've
never fought in an army like this before.$K
$F3$PYes, that's right.$w4 Sometimes I get
confused. I'm not used to this
way of fighting.$K
$F1$PAsk me if you have any questions.$w4
I know a lot about battle... I commanded
a unit back in Gallia.$K
$F3$P$FSYou must be a fierce fighter and
great leader. Is it common for females
to command armies?$K
$F1$PIn Gallia, it doesn't matter what your
sex is. You just have to be the best.$K$P$F3$PThat sounds fair to me.$K
$F1$PYour life may not be so fair.$K$PYou said you used to be a slave in
Begnion.$K
$F3$P$FAYou will never know the horror.$K$PYou've lived with laguz pride in your
heart, under the protection of the great
King Gallia. You do not know...$K
$F1$P...$K   $R�w�i��b|$B�x���w�i|$<$F1$FCL_MWARIM|$F3$FCL_LETHE|$F3$PHow are you, Muarim?$K
$F1$PI'm starting to feel more at home
with this army.$K$PAnd I've finally gotten used to the
curious looks from other laguz.$K
$F3$PCurious looks?$K$PMuarim...you're hauling crates around!$w4
You should leave the supply carrying
to the other soldiers.$K
$F1$PI guess it's just in my nature.$w4
I don't want to leave the work to the
beorc.$K
$F3$PWhy not?$K
$F1$P$FSThey're just like us.$K
$F3$PI see...$K
$F1$PSo you think I have no pride as
a laguz?$K
$F3$PNo...$w4 There was a time when I
wouldn't have cared if they all fell
off a cliff.$K$PBut after joining Ike and his crew,
I've learned that beorc and laguz can
get along.$K
$F1$P$FA...$K
$F3$PI don't know what to tell you. It seems
like you've already given up.$K
$F1$PGiven up?!$K
$F3$PI can't say I don't understand why.$w4
You must have led a difficult life.$K$PBut...I just can't understand how you've
abandoned your laguz heritage.$K$F3$FD
$F1$P...$K $R�w�i��b|$B�x���w�i|$<$F1$FCL_MWARIM|$F3$FCL_LETHE|$F1$PLethe.$K
$F3$PWhat is it?$K
$F1$PI'm sorry I gave you a hard time.$w4
I must have just been envious of how
comfortable you are around beorc.$K
$F3$PComfortable?$K
$F1$PYes...you can deal with the beorc
on an equal footing without losing face.$K$PIt may seem like nothing to you, but
it's something I once couldn't imagine.$K
$F3$PYou can do the same.$K
$F1$PGrrr...$w2you may be right. Yes...
I must change my attitude.$K
$F3$PI think you will feel better that way.$K$PI've never seen you with a peaceful look
on your face before.$w4 That makes me
worried...$K
$F1$PHah. Am I really that frigid?$K
$F3$PMost of the time.$w4 But I'm glad to
see that you're warming up.$K$P$FSWhy don't you tell me more about why
you are so harsh with the beorc? I might
be able to understand.$K
$F1$P...$K   $R�w�i��b|$B�x���w�i|$<$F3$FCL_LOFA|$F3$PReady...$w2aim...$K
$F1$FCL_MARCIA|$F1$PHey!$w4 You're Rolf, right?$w4
What are you doing out here all alone?$K
$F3$PI'm practicing my archery skills! See?
I just nail a target to a tree and fire away.$K$PI cover my arrow tips with burlap to
prevent accidents. You see...there was
this one incident with a marmot...$K$PWell, I just try to stay close to the target
now. It's not the best way to train, but
at least it gives me some practice.$K
$F1$P$FSAw, that's so cute! You're trying hard,
even though you're such a little guy!$K
$F3$PHey! I'm not small!$w4
I'm a dangerous mercenary!$K
$F1$PYeah, of course you are.$w4
Say, you mind if I practice with you?$K
$F3$PThat's all right.$w4
I can take care of myself.$K
$F1$PPfff! I know! I'm just offering to help.$w4
You know...I was once a knight in the
service of the world's greatest country.$K$PI also know how to handle a bow.$w4
Us pegusus knights fear archers more
than anything else, you know.$K
$F3$PYeah? Well...you better watch out
or I'll feather you like a quill!$K
$F1$PHah! Big words from a little guy!
I like you!$K$PHey, you should take a look around and
make sure nobody else is around before
you start shooting arrows.$K
$F3$PI KNOW that! Don't talk to me like a baby!$K
$F1$PSheesh! All right!$w4
Touchy...$K  $R�w�i��b|$B�x���w�i|$<$F3$FCL_LOFA|$F4$FS$F4$FCL_MARCIA|$F4$PIncredible! You hit the target twenty-six
times in a row!$K
$F3$PWell, my goal was thirty.$K
$F4$FD$F1$FS$F1$FCL_MARCIA|$F1$PThat's a lofty goal, and you came close!$w4
You're becoming an impressive archer, Rolf!$K
$F3$PBut I can't afford to miss a single shot
in battle. The man who taught me how to
fire a bow told me that once...$K$PI can't be happy with just twenty-six hits.$K
$F1$PYou push yourself hard, Rolf.$w4
That's admirable.$K
$F3$PAren't you strict with yourself, Marcia?$K
$F1$PHm?$w4 What, me? Pfff! Of course!
I'm stricter than a poached egg on toast!$K$P"Be firm with yourself and others!"$w4
That's what the first officer in my old unit
told me.$K$PBut you're still...$K
$F3$PA child?$w4 I'm not a child.$w4 Those days ended
the instant I took my first life.$K
$F1$P$FA...I suppose you're right. You've had to
grow up fast traveling with a group
of hardened sellswords like this.$K
$F3$PDo you worry about me because I'm young?$K
$F1$PWell...sure. Who wouldn't?$K
$F3$PWell, stop it. I can take care of myself.
I've grown strong.$K
$F1$PTrue enough. Sorry if I underestimated you.$K    $R�w�i��b|$B�x���w�i|$<$F1$FCL_LOFA|$F3$FS$F3$FCL_MARCIA|$F3$PYou landed every one of your shots!$K
$F1$PHitting the target isn't good enough.$K$PMy instructor once told me that I should
be able to strike the gaps between
armor plates.$K
$F3$PThat's nearly impossible...$w4but maybe you'll
be that good one day.$K$P$FAHold on...$w4 Rolf, let me see your hands.$K
$F1$PMy hands?$K
$F3$POh, barnacles! Your hands are covered
with blisters! And you're bleeding!$K$PWhy are you still practicing like this?
What's wrong with you!?$K
$F1$PIt hurt at first, but my hands went
numb after a while--so I just kept
plucking arrows out of my quiver.$K
$F3$PHoly crow, Rolf...$w4
You're tough, I'll give you that.$K$PHold still. $w2I know I have a vulnerary around
here...$w4 $FSThere, found it.
This may sting a little.$K
$F1$P$FSThank-YOOOOWWWCCHHH!!!
Hey, that hurt!$K
$F3$PThat's nothing for a deadly mercenary
like you. Right, Rolf?$w4$K
$F1$PA deadly mercenary?
You really think so?$K
$F3$PYes, and it's not just your bowmanship.
You're quite tenacious.$K$PYou're so focused on hitting your targets
that you don't even feel pain.
Few people are that determined.$K
$F1$PDoes that mean I'll be able to make
a difference? Will I be able to protect them
when they're in danger?$K
$F3$PI'll tell you one thing...the enemy better
stay out of bowshot, or you'll turn him
into a porcupine!$K
$F1$PThanks, Marcia.$w4 I promise to protect
you, too.$K
$F3$P$FARolf...$w3 I'll look out for you, too.$K$P$FhWhy...$Fc Aw, nuts.
...Did you have to grow up so fast?$K   $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_MIST|$F3$FCL_LOFA|$F1$PRolf!$w4 Oh, there you are!$K
$F3$PMist! Were you looking for me?$K
$F1$PYes.$w4 I've been meaning to talk to you.$K$PWe haven't had a chance to talk since
that day we fought for the first time.$K
$F3$P$FSI'm glad you're safe...$w4
Somehow, we're both still alive.$K
$F1$PYes...$w4we've been so lucky.$K
$F3$PMy heart was pounding and my hands
were shaking so badly that I almost shot
an arrow into Boyd's backside.$K
$F1$P$FATee hee! Good thing you didn't, or he
would have given you a smacking!$K$PI was so...$w4scared. I heard yelling...
screaming...and the most awful howls
of agony. I felt dizzy and sick.$K
$F3$PI wasn't scared at all.$K$PMaybe I was a little nervous...$w4
But by the end, I was almost hitting
my targets!$K
$F1$PYou weren't even a little scared?$K
$F3$PNo way. I can't wait for the next battle.
I'll fight better next time.$w4 You'll see.
I'll feather a horde of slobbering enemies!$K$PSee you later, Mist. I've got to go practice!$K$F3$FD
$F1$POh, Rolf!$w4
Rolf...$K    $R�w�i��b|$B�x���w�i|$<$F3$FCL_LOFA|$F3$PAim...$w4and release!$K
$F4$FCL_MIST|$F4$PCan I talk to you for a moment, Rolf?$K
$F3$P$FSSure. Just hold on and let me tighten
my bowstring. I've got to be ready...$K$PYou know, just in case some Daein
thugs try to jump us.$K
$F4$P...$K
$F3$FD$F1$FS$F1$FCL_LOFA|$F1$PSo...what do you need, Mist?$K
$F4$PLet's not fight in any more battles, Rolf.$K$PI really don't think we children should
be fighting in this war.$K
$F1$PHuh?$w4 Why are you saying this now?$K
$F4$PLet's go back to being kids. If this is what
it's like to be an adult, I don't want any
part of it.$K
$F1$PYou're right, Mist. Fighting scares you.
You don't have to fight. Don't worry...
I'll fight for you!$K
$F4$PThat's not what I meant, and you know it!
You've got to stop fighting, or it's all
meaningless.$K
$F1$P$FAI can't do that.$w4
I have to slay our enemies and defend
our own. I'm a man, now...$K
$F4$PSlay your enemies?$w4 Is it that meaningless
to you? Like picking a flower or squishing a
spider. They're human, too.$K
$F1$P...$K
$F4$PDo you understand that, Rolf?$w4
The enemy... They're human, just like us.$w4
They're not paper targets pinned to a tree.$K
$F1$PI don't want to hear it.$K
$F4$PRolf!$K
$F1$PI don't want to hear it!! Got it?!$K$PThey're trying to hurt us! Kill us!$w4
I'm just stopping them.
I'm protecting all of you.$K$F1$FD
$F4$PWait... Rolf!$w4 Oh... Please understand...$K   $R�w�i��b|$B�x���w�i|$<$F1$FCL_MIST|$F3$FCL_LOFA2|$F1$PRolf.$K
$F3$P...$K
$F1$PStop ignoring me! Can we please talk?$w4
Please?$K
$F3$P...$K
$F1$PI don't blame you.
I just wanted you to know that...$K$PNot everyone we run into is evil.
Some of them might just be caught up
on the wrong side.$K
$F3$PSo I wasn't thinking about that?$w4
Is that what you mean?$K
$F1$PWhat? No...$K
$F3$PWe're not fighting targets.$w4
I know the difference. Targets don't squirm
on the ground and gurgle in pain.$K$PTargets don't make the grass
slippery with blood.$K$PI learned that lesson the first time
I took a man down.$w4
They're fighters, just like us.$K
$F1$PRolf...$K
$F3$PBut there's a difference. They're trying
to hurt the people I love. Anyone that tries
that is an enemy of mine.$K$PThat's why I won't hesitate to feather them.$w4
If I let even one of them live, they will do
everything they can to kill one of our own.$K$PI...$w4 I'm afraid of that.$w4
I won't stop spilling blood until it's over.$K
$F1$FD$F1$FCL_MISTs|$F1$PRolf!$K
$F3$P$FhI don't want you to die! I...
I... $w2I don't want to lose anyone else...
$Fc...$w4 Whaaaa...$K
$F1$PI'm sorry, Rolf!$w4
I'm so sorry...$K
$F3$PWhaaaaaaaaa...
...Sniff... Sniff...$K
$F1$PI thought you had changed.$K$PYou used to be such a sweet boy.
I thought you'd turned hard and didn't
understand about death.$K$PI'm sorry...I didn't understand how you felt.
You've been so desperate to protect
everyone else.$K
$F3$P$FdThis will be over one day.$K$PI just want everyone to see that day.$K
$F1$PMe, too, Rolf. Me, too...$K  $R�w�i��b|$B�x���w�i|$<$F1$FCL_LOFA|$F3$FCL_TAURONEO|$F3$P...Josh?$K
$F1$PHuh?$K
$F3$PNo...$w2you can't be.$K$PSorry, I thought you were someone else.$w4
What's your name, young man?$K
$F1$PRolf.$K
$F3$PRolf, eh?$w3 What's a child like you doing
in a place like this?$K$PThe battlefield is no place for children.$w4
Why do your parents allow this?$K
$F1$PI...$w4don't have any parents.$K$PMy dad left us...and my mom died.$K
$F3$POh, no... I'm sorry.$w4 I didn't mean to
drag up such a painful memory.$K
$F1$P$FSThat's all right.$w4 This group of mercenaries
is my family now.$K$PSo... I look like someone you know?$K
$F3$PMy...$w4son.$w4 Josh. My oldest.$K$PJosh is an adult now. But he looked so
much like you, once. Long ago...$K$P$FSI can't believe I thought you were
my own son. I've grown old and senile.
Ha! Foolish old man...$K
$F1$PWhere's Josh now?$K
$F3$P$FAI don't know.$K
$F1$P$FAWhat?$K
$F3$PI divorced my wife, and she took the
children with her. I haven't seen
them since.$w4 That was years ago.$K  $R�w�i��b|$B�x���w�i|$<$F1$FCL_LOFA|$F3$FCL_TAURONEO|$F3$PFor generations, we made a reputation for
ourselves in Daein as a famed warrior
family.$K$PBoth my father and I had the honor of
serving the royal family as field generals.$w4
We were a proud family...$K
$F1$PWhat happened with Josh?$K
$F3$PI raised him to serve the Daein army,
as my father raised me. He tried to live
up to my high expectations.$K$PHe became a decorated knight at a
young age and was assigned to the
palace guard.$w4 However...$K
$F1$PWhat happened?$K
$F3$PHe took to the field as Ashnard's
personal aide.$w4 And he came home
on a litter, grievously wounded.$K$PHe escaped death, but he didn't escape
his wounds.$w4 He'll never walk again.$K
$F1$POh, no...$K
$F3$PMy wife nearly lost her mind.$K$PShe cried day and night, swearing that she
couldn't live if something like that were
to ever happen again.$K$PShe wanted to live in peace...with her mind
at ease. She pleaded with me to leave
the army.$K$PBut I couldn't accept her plea.$w4
Our family house was built on generations
of proud military command.$K$POur ancient name as a warrior family
would not allow me to simply abandon
my sworn duty.$K$PI tried to salvage our honor by training
my younger son. He was just a boy, really.$w3
I wanted him to become a Daein general.$K
$F1$PYou did what?!$K
$F3$PI know...$w4 I was a fool.$w4 I was blinded
by tradition and family reputation.$K$PBy the time I realized my error, my wife
and children had left me.$K$PSince then...$w4 I've been living alone
in my great mansion, surrounded by
countless medals and memories...$K
Alone...$w4for years...$K $R�w�i��b|$B�x���w�i|$<$F1$FCL_LOFA|$F3$FCL_TAURONEO|$F3$PAh, I was so wrong...$K$PI wish I could apologize to my family.$K
$F1$PDo you have any idea where your family is?
Any clues? Anything?$K
$F3$P...$w4 I've heard my wife left Daein and went
to live with relatives in Crimea.$K$PI suppose she is still there.$K
$F1$P$FSThen why don't you go see her!$K
$F3$PI'm sure they don't want to have
anything to do with me.$K$PEven if I did find them, reappearing now
would just reopen old wounds. I don't
want to cause any more pain.$K
$F1$P$FAThat's just crazy! I mean...
I wish I could see my dad!$K
$F3$P...$K
$F1$PI've always told my brothers that
I'm all right and I'm not lonely.$K$PBut the truth is I want to see my dad.$w4
We've got so much to talk about.$K
$F3$POh, son...$K
$F1$PMy dad is dead.$w3
I can't see him again.$w4
But your boy can. You're still alive.$K
$F3$PYou're...right.$K
But it is simply too late.$K
$F1$PIt's NOT too late!$w4 As long as you're
still alive, it's never too late.$K$P$FSGo on! Go see them!$w4
I'm sure they're waiting for you.$K
$F3$PMaybe you're right, Rolf.
Maybe I should...$K    $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_ULYSSES|$F3$FS$F3$FCL_LUCHINO|$F3$PGood day, Count Bastian!$K
$F1$PAhhh...$w4 Lady Lucia.$K$PWhat an exquisite pleasure. Would you
allow me to place a kiss upon your
creamy white hand?$K
$F3$PSorry, my lord.$w4
I've been sharpening my blade, and my
hands are covered in grime.$K
$F1$PNonsense! I have no objections, milady.
The grime merely accentuates
your beauty.$K
$F3$PI have objections, Bastian.$K
$F1$PAhhh...$w4 She addresses me so curtly,
but it only stokes my furnace of attraction!$K$PIt is only in my nature to hunt and pursue
a tantalizing beast that flees me!$K$PYou have such a devious grip on my heart!$K
$F3$PDon't even think I'm going to fall
for that trick! It might work with the others,
but I'm no doe-eyed fawn!$K$PWhy don't you just give up already?$w4$K
$F1$PAhhh, splendid!$w4 This fawn has sharp hooves!
But still she spurns my advance...
Next time, I shall woo her with words!$K  $R�w�i��b|$B�x���w�i|$<$F1$FCL_LUCHINO|$F1$PCount Bastian!$w4
Where are you?!$K
$F3$FS$F3$FCL_ULYSSES|$F3$PLady Lucia...$w4 It's not like you to be
looking for me. Or even acknowledge
my existence, for that matter! Ta ha ha!$K
$F1$PHow badly are you hurt?$w4
Do I need to tie a tourniquet?$K
$F3$PA tourniquet?$w4 Ta ha ha, aha! No, my dear.
I'm not injured. Unless you include the
heart which you have so eagerly stomped!$K
$F1$PYou aren't hurt? Really?$K$PI heard a funny-looking man with a
mustache suffered a severe injury.$K$PNaturally, I assumed it was you.$w4
But I see that wasn't the case.$K
$F3$PLady Lucia!$w2 You were so concerned
with my welfare that you rushed to
my aid!$K$PAh! You are a true delight! A magestic--$K
$F1$PThat isn't the case at all.$K
$F3$PThere's no use in fighting your feelings!
I have already given in to the bottomless
pit that is my love for you!$K
$F1$PDid you not hear me? I already told you
how I felt.$K
$F3$PThe more you try to hide it, the more
your true feelings show through!$K$PYou cannot fight true romance any more
than you can fight the tides, milady.$K
$F1$PArrrggg... Count!$w4 Will you please listen
to me?!$K $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_ULYSSES|$F3$FCL_LUCHINO|$F1$PLady Lucia, I'm not going away until
you declare the true, roaring-hot passion
you feel for me!$K
$F3$PCount Bastian...$w4
You may talk like you're completely
psychotic, but I know it's just an act.$K$P$FSAnd as much as I hate to admit it...$w4
I don't think you're all that bad.$K
$F1$PThen you feel the same?$K
$F3$PWell...$K$PWhen the war is over...$w4and Crimea is
once again back on her feet...$w2
I might consider it. Might.$K
$F1$POh, my beloved!$K
$F3$PAs hard as I've tried, you're just
impossible to hate.$K$P$FAOh no... I completely forgot!$w4
I need to go help Princess Elincia.$K
$F1$P$FAW-wait, my love!$w4
What are your plans tonight?$w4
I'd like to spend it gazing into your sweet--$K
$F3$P$FS--Sorry!$w4
I need to be with the princess.$w4
I won't be free for a long time.$K$F3$FD
$F1$P$FSOh, dear...$w4I see the road ahead will
be bumpy indeed!$K  $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_STELLA|$F3$FCL_MAKAROV|$F1$PGood day, sir.$K
$F3$PHuh?$w4 Are you talking to me?$K
$F1$PYes, sir.$w4 My name is Astrid.$w4
May I ask you your name, good sir?$K
$F3$PI'm not really a knight, so you can
drop the whole sir thing.$w3$FS
I'm Makalov. Nice to meet you.$K
$F1$PThe feeling is mutual, Makalov.$w4
By the way, you dropped these flowers.$K
$F3$P$FAAh! I didn't even notice...$K
$F1$PThey are so pretty!$K
$F3$P$FSNot bad for some wildflowers
growing in a ditch, right?$K
$F1$PYou picked them yourself?$w4
That's very sweet, Makalov.$K
$F3$P$FAUm...well...how should I put this?$w3
$FSI picked them to butter up my sister.$K
$F1$PYou're such a thoughtful brother! I'd better
give them back to you, then...$w3
There you go!$K
$F3$PGo ahead and take a couple.$K
$F1$P$FASome flowers? Are you certain?$K
$F3$PIt's my way of saying thanks for picking
them up.$K$PBesides, they look good on you.$w4
Now, if you'll just excuse me,
I have to run along now...$K$F3$FD
$F1$PThank you!$w4$FS
Oh, Makalov...$K  $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_STELLA|$F3$FCL_MAKAROV|$F1$PGood day, sir.$K
$F3$PHuh?$w4 Are you talking to me?$K
$F1$PYes, sir.$w4 My name is Astrid.$w4
May I ask you your name, sir?$K
$F3$PI'm not really a knight, so you can
drop the whole sir thing.$w3$FS
I'm Makalov. Nice to meet you.$K
$F1$PThe feeling is mutual, Makalov.$w4
By the way, you dropped these flowers.$K
$F3$P$FAOh... I didn't notice...$K
$F1$PThey are so pretty!$K
$F3$P$FSNot bad for some wildflowers
growing in a ditch, right?$K
$F1$PYou picked them yourself?$w4
That's very sweet, Makalov.$K
$F3$P$FAYeah. They're for my sister.
Well...for her grave...$w4
...She always liked flowers...$K
$F1$POh...that's so sad. I'm sorry, Makalov.
Here, take them back.$K
$F3$PAw, it's all right. Take one if you want.$K
$F1$P$FAAre you sure?$K
$F3$PIt's my way of saying thanks for picking
them up.$K$PBesides, they look good on you.$w4
Excuse me... I have to go...$K$F3$FD
$F1$PThank you!$w4$FS
Oh, Makalov...$K $R�w�i��b|$B�x���w�i|$<$F1$FCL_MAKAROV|$F3$FS$F3$FCL_STELLA|$F3$PGood day, Makalov.$K
$F1$P$FSHi, Astrid.$w3 We sure bump into each
other a lot, don't we? Do you think we're
linked by fate?$K
$F3$PI'm not sure.$w4 Though...I'd be honored
if that was the case.$K
$F1$PSpeaking of fate...$w3
I have a little favor to ask of you.$K
$F3$PWhat is it?$w4 If there's anything I can
do for you, I'd be glad to help!$K
$F1$PUm... Well, the thing is... You see...$w4
Can you lend me some money?$K
$F3$P$FAM-money?$K
$F1$PYeah! Just a few hundred! That's it!$K
$F3$PI don't think I can help you...$w4
I don't have a single gold piece
to my name.$K
$F1$P$FAWhat?! Not even one gold?$w4
What did you spend it all on?!$K
$F3$PThe last time I went to town, I stumbled
upon a destitute family. They hadn't eaten
in days... So, I gave it all to them.$K
$F1$PWHAT?!$w3 That's madness!!$K$PIf you're feeling charitable, maybe you
should think about helping out one of
your comrades, and not some stranger!$K
What were you thinking?!$K
$F3$PI'm sorry.$w4 I had no idea you were
in need of aid.$K
$F1$PArrgg!$w3 Fine.$w4 I'll go hit up someone else.$K
$F3$PWait...just a moment.$K
$F1$PHmmm?$K
$F3$PWill this help?$K
$F1$P$FSWhoooo! Hey, look at that beauty!$w4
This pendant looks expensive...
Are you sure I can take it?$K
$F3$P$FSPlease do. Anything that will help.$K
$F1$PWahooooo!$w3 Thanks, Astrid!$w4 You're the best!
I'll see ya later!$K$F1$FD
$F3$P...$K   $R�w�i��b|$B�x���w�i|$<$F5$FCL_STELLA|$F5$P...$K
$F8$FCDUMMY|$F8$P$F8$FDHey! Astrid!$K
$F5$P...$K
$F3$FCL_MAKAROV|$F5$FD$F1$FS$F1$FCL_STELLA|$F1$PHello, Makalov.$K
$F3$P$FSUh...yeah...look...$w4
Lemme give this back to you.$K
$F1$P$FAWas there something wrong with
my pendant?$K
$F3$PNo! $w2Not at all! That big gem alone could
have fetched 5,000 gold, easy.$K
$F1$PThen why are you giving it back?
Aren't you desperately in need?$K
$F3$P$FAWell, it's like this... Just as I was walking
into the pawnshop, guess who I see?$w4
My stupid sister!$K$PShe demanded to know where I got it!
She got all angry and started yelling at
me!$w4 Again!!$w3 She thought I stole it...$K
$F1$PBut I gave it to you, Makalov.$K$P$F3$POf course! And I told her that! But then
she started crying and stuff. Said that I
ripped you off and I was a big swindler...$K$PSo I thought I should give it back before
she hits me on the head with
her big lance again.$K
$F1$PI see.$K
$F3$PYou're quite lucky, you know.$K$PYou can give away an expensive pendant
like other people give away a sandwich!$K$PMy sister doesn't even have a cheap
necklace, much less a huge whopper
like that.$K$PThe goddess is so unjust. She only favors
the aristocracy.$K
$F1$PI'm...I'm sorry...$K
$F3$PHey, I wasn't asking for you to apologize.$K
$F1$PMy pendant was really worth that much?$K$PI...$w4 I only wore it because my beloved
grandmother gave it to me when I was
just a girl. I had no idea...$K
$F3$PWhoa! It's a memento!?$w4 Why the heck
did you give me something so important?$K
$F1$PThat pendant is just an object. Memories
of my grandmother always remain in my
heart, even if I let the pendant go.$K$PI suppose I thought it would do more
good if I gave it to someone in need.$K
$F3$PYou... $w2You're so...good.$w4
Look, I'm really sorry!!$K$PI'm just a crook.$w3 I tried to bum some
money off of you so I could go gambling.$K$PAh, Astrid! I'm a dirty, flea-ridden cur!
I'm nothing more than a wet sack of trash!
Please forgive me!!$K
$F1$POh Makalov...$w4$FS I'm not upset.$K
$F3$P$FSYou're more forgiving than the goddess
herself!$K
$F1$P$FAOh... That's nonsense.$K
$F3$PI'm serious! You're practically a blinding
beacon of moral greatness!$K
$F1$PPlease, stop teasing me. When a fine
gentleman like you stares at me like that...
Oh, it makes me so...$K$P...I'm so embarrassed.$K
$F3$P$FAHuh? A fine gentleman? Me?$K
$F1$POh, no...$w4 I can't believe I said that...$w4
Excuse me! I've got to go!$K$F1$FD
$F3$PWhat was that all about?$K$P$FhWhen you're raised like she was, I bet
you don't even learn to like men.$K   $R�w�i��b|$B�x���w�i|$<$F5$FCL_STELLA|$F5$P...$K
$F8$FCDUMMY|$F8$P$F8$FDHey!$w4 Astrid!$K
$F5$P...$K
$F3$FCL_MAKAROV|$F5$FD$F1$FS$F1$FCL_STELLA|$F1$PHello, Makalov.$K
$F3$P$FSUh...yeah...look...$w4
Lemme give this back to you.$K
$F1$P$FAWas there something wrong with
my pendant?$K
$F3$PNo! $w2Not at all! That big gem alone could
have fetched 5,000 gold, easy.$K
$F1$PThen why are you giving it back?
Aren't you desperately in need?$K
$F3$P$FAWell, it's like this... Just as I was walking
into the pawnshop, guess who I see?$w4 IKE!
What's he doing in a pawnshop, anyway...?$K$PHe demanded to know where I got it. And
when I told him, he got furious! Started
lecturing me about thievery and so forth...$K
$F1$PBut I gave it to you, Makalov.$K$P$F3$PAnd when I told him, he got MORE angry!
He even told me that Marcia would
be ashamed...$w3 What a low blow!$K$PSo anyway, I thought I should give it back
before he has Soren sneak into my tent and
turn me into a newt or something.$K
$F1$PI see.$K
$F3$PYou're lucky, you know?$K$PYou can give away an expensive pendant
like other people give away a sandwich!$K$PMy sister didn't even own a cheap necklace,
much less a huge whopper like that.$K$PThe goddess is so unjust. She only favors
the aristocracy.$K
$F1$PI'm...I'm sorry...$K
$F3$PHey, I wasn't asking for you to apologize.$K
$F1$PMy pendant was really worth that much?$K$PI...$w4 I only wore it because my beloved
grandmother gave it to me when I was
just a girl. I had no idea...$K
$F3$PWhoa! It's a memento!?$w4 Why the heck
did you give me something so important?$K
$F1$PThat pendant is just an object. Memories
of my grandmother always remain in my
heart, even if I let the pendant go.$K$PI suppose I thought it would do more
good if I gave to someone in need.$K
$F3$PYou... $w2You're so...good.$w4
Look, I'm really sorry!!$K$PI'm just a crook.$w3 I tried to bum some
money off of you so I could go gambling.$K$PAh, Astrid! I'm a dirty, flea-ridden cur!
I'm nothing more than wet sack of trash!
Please forgive me!!$K
$F1$POh Makalov...$w4$FS I'm not upset.$K
$F3$P$FSYou're more forgiving than the goddess
herself!$K
$F1$P$FAOh... That's nonsense.$K
$F3$PI'm serious! You're practically a blinding
beacon of moral greatness!$K
$F1$PPlease, stop teasing me. When a fine
gentleman like you stares at me like that...
Oh, it makes me so...$K$P...I'm so embarrassed.$K
$F3$P$FAHuh? A fine gentleman? Me?$K
$F1$POh, no...$w4 I can't believe I said that...$w4
Excuse me! I've got to go!$K$F1$FD
$F3$PWhat was that all about?$K$P$FhWhen you're raised like she was, I bet
you don't even learn to like men.$K   $R�w�i��b|$B�x���w�i|$<$F5$FCL_ULYSSES|$F3$FS$F3$FCL_MAKAROV|$F3$PIncredible!$w4 I had no idea this army had the
luxury of hiring a street performer.$K$PThey are clashing with the mighty Daein!
Who knew they had a taste for comedy?
Or the time, for that matter...$K
$F5$PHmmmmmmmm?$K
$F5$FD$F1$FS$F1$FCL_ULYSSES|$F1$PI take it you direct your words at me.
Lest my eyes lie, you are Sir Makalov!
A Begnion soldier of some great renown.$K
$F3$P$FAWow!$K$PH-how did you know my name?
You're just a street performer.$w4
Wait...$w3$FS Oh, I see.$K$PThat's your schtick, isn't it?$w4
I have to hand it to you...
You guessed my name right!$K
$F1$P$FAA street performer? Ha! I dare say no!
You think me one to don the cap and bells,
and gambol in the street for petty coin?$K$PBut soft, I see why you might mark me so.
Though now I am a man of some esteem,
that job was once my sole mean of employ.$K$PWhen I look back on my performing days,
I know that any hardship in my road
shall be like ashes at the fire's end!$K$PYet till Crimea sees its freedom come,
I shall pass myself as the simple fool!$K
$F3$PHa ha ha!!$w4 You're such a comedian!!
That's hilarious!$K$PHey, why don't we go get some dinner?
Maybe you can tell a few jokes!
Or juggle plates! I LOVE plate juggling!$K
$F1$P$FSIn truth, you make an offer square and just.
And though it would do my heart very well,
I fear I must decline this eve's repast.$K$PPerhaps we could meet for a meal anon?
I shall but count the minutes to the time!$K
$F3$PWha ha ha ha! Man, you're too much!
But sure, that's fine with me.
See you later, fool!$K
$F1$PExcellent! Most excellent, good and fair...
What ho? The watch! Alas, I must depart!$K$F1$FD
$F3$PHa! What a riot!$w4 I've never seen him
before! I wonder when we'll meet again.$K
$F8$FCDUMMY|$F8$PHey! You there!$w4 Show some respect!$K
$F3$PEh?$w4
$F3$FD$F1$FCL_MAKAROV|$F4$FCL_CRIMEA1|$F1$POh, a Crimean soldier. Can I help you?$K
$F4$PDon't talk to me like I'm stupid!$w4
You also fight for the Crimean army,
do you not?$K
$F1$POh, yeah... That's right.$w4$K
Now that Ike is the commander of the
Crimean army, that automatically makes me
a Crimean soldier, too.$w4 Ha ha!$K
I'm your brother-in-arms!$K
$F4$PWeeeell...$K$PBecause you're a member of General Ike's
personal mercenaries, I'll cut you a break
this time...$K$PHowever! Know that the man you were just
talking to is the Count Bastian himself!$K
$F1$P$FAHa ha... Huh?$K
$F4$PLord Bastian, the Count of Fayre, is a
distinguished member of the
Crimean royal court.$K$PHe even served as the right hand of
the late prince.$K$PHow dare you address him like some
common street fool!$K$PIf you don't want to get clobbered,
I suggest you show some respect!$w4
Is that clear!?$K$F4$FD
$F1$PThat street performer is a Crimean noble?$K$PIf that's true...$w2$FS He must be packed
to the gills with gold! Makalov, you devil...
It's time to turn on that famous charm!$K   $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_MAKAROV|$F3$FS$F3$FCL_ULYSSES|$F1$PCount Bastian,$w3 you'd consider us
close now, right?$K
$F3$PYou, sir, are as the dearest of my friends.
We drink and sup until the morning light!$K
$F1$PAll right then,$w3 why don't we play a
little game?$K$PYou may not know it. It's a favorite game
of the common folk. But once it charms
you, it never lets go!$K
$F3$PA game played by the commoners, you say?
What fun! We must this enterprise engage!
Pray tell the rules of your wondrous lark.$K
$F1$PIt's simple.$w4 You make a wager, and then
you guess the pattern on these face-down
wooden blocks right here.$K$PIf you guess right, you win money!$w3
If you guess wrong, you lose...
Simple, really!$K
$F3$PAh ha! You do not fool me, my good sir!
This lark is played in all the gaming dens,
where fool and coin are ever parting ways.$K
$F1$P$FAGulp!$w4 W-what?$w4
You mean...y-you've been to a gambling
parlor before?$K
$F3$PI know of such, but haven't in one stepped.
But I will say...my interest has been piqued.$K
$F1$P$FSThen let's go to the local gambling hall!
Come on, you can just get a taste for it.
I'll show you the way.$K$PDon't worry about being new to the game.$w4
Someone as rich as you can play all night
and still come home with a fat wallet.$K
$F3$PI shall not play. I must content myself
with watching.$K
$F1$P$FAWhaaat!?$w4 Why would you just want
to watch?$K
$F3$PMy homeland of long years is in dire peril.
I cannot play while sweet Crimea burns.$K$POh look, the moon has risen o'er the hills!
I must retire now to sleep's cold grip.
Take care to not empty your purse! Ta ta!$K$F3$FD
$F1$PAaah!$w4 Nooo! He's gone...$w4
There goes my loot! Waaaait!
Come baaaack!$K $R�w�i��b|$B�x���w�i|$<$F1$FCL_MAKAROV|$F3$FS$F3$FCL_ULYSSES|$F3$PWhatever is the problem, Makalov?$K
$F1$P...$K
$F3$PWe went unto the hall and gambled there.
We stayed until the cock did crow at dawn!
So why do you bestare me with a look?$K
$F1$PBastian...$w4
You lied to me, didn't you?!$K
$F3$PWhat, me? I did not in my--$K
$F1$PLIAR!!
"I've never been to a gambling parlor,"
you said... HA!!$K$PYou looked more at home there than I did!$w4
What's more, I lost my shirt and you
cleaned house!$K$PAnd you're telling me not to glare at you?!
Ha! Explain yourself! And no more poetry!$K
$F3$P...Sigh...$K$PI didn't lie to you, Makalov.
That was the first time I ever set foot
inside a gambling parlor.$K$PHowever...$w4 The nobles have a
similar gambling game that I was
quite familiar with.$K
$F1$PBlast!$w4 The rich just get richer!
What's wrong with this world!?$K
$F3$PThe gold I won is not that important.
I came along simply because you
wanted me to test my luck.$K$PBut...I did break the house, didn't I?$w4
I couldn't have dreamt a better ending!
It makes me positively giddy. Ta ha ha!$K
$F1$PYou don't need the money?$w4
Well, I'll gladly take it!$K
$F3$PNot a chance.$w4 War consumes money at
an astonishing pace. This goes right into
Crimea's war chest.$K
$F1$PNo need to worry about that.$w2
Crimea will win this war.$K
$F3$PHm? Is that so?$w4 Why do you say that?$K
$F1$PBecause she has a disgustingly lucky man
like you on her side.$w4 There's no way she
will lose two battles in a row.$K
$F3$PI see you have a gift for foresight.$K
$F1$P$FSSo about that money...$K
$F3$PIf Crimea is victorious, I shall fill your
coffers with so much gold that even a
team of oxen could not drag them!$K
$F1$P$FAReally!?$K
$F3$PI don't make promises I can't keep.$K$PI have many means to make money.
Don't you worry yourself over that.$K$F3$FD
$F1$P$FSYou're on!$w4 I better give this war
my best. It's the gamble of a lifetime!$K   $R�w�i��b|$B�x���w�i|$<$F1$FCL_TANIS|$F3$FCL_MARCIA|$F3$P...Oh!$K
$F1$PMarcia. It's been a while.$K
$F3$POh, chestnuts!$w4
D-Deputy Commander Tanith!?
What...are you doing here?$K
$F1$PI was just about to ask you the same thing.$w4
As deputy commander of the Holy Guard,
I took this position on imperial orders.$K$PI never would have thought I'd run into
one of my former subordinates so soon...$K
$F3$P$FSW-we've been together since we crossed
into Daein?! Oh, I had no idea!$K$PTalk about strange luck! Heh...$K
$F1$P$FSIt certainly is.$w4 I'm so glad I've come
across my...special subordinate.$K$PI've been looking for you for a long time,
you know...$K
$F3$P$FAD-Deputy Commander, $w2your eyes...
why are you squinting at me like that?$K$P$FSAre you...$w4angry?$K
$F1$POh, I'm angry.$w4 I am very angry.$w5
Very angry indeed.$K$PRight now I'm weighing my options...
Which penalty should I inflict on you for
deserting the Begnion Holy Guard?$K
$F3$P$FAI'm...$w3 I'm no deserter!$w4
Didn't you read the letter of resignation
I wrote?$K
$F1$P$FADid you think you could cast off your
sworn duty by scribbling on a piece
of paper?$K$PYou should know the weight of being
a soldier in the service of the
Begnion Holy Guard.$K
$F3$PI'm...$w4 I'm sorry!$w4
But I was in such a hurry...$K
$F1$P$Fc...Commander Sigrun is a charitable person.
She says she is willing to overlook
your desertion.$K
$F3$P$FSPhew...$K
$F1$P$FdHowever! I put an end to that nonsense!$K$PI told her that I would bring you back
at any cost and deliver the appropriate
penalty. I hope you're ready!$K
$F3$POh!$w4 I just remembered I have to be
somewhere! Somewhere really far away...$w4
Excuse me, ma'am! Yaaaaa!$K
$F3$FD$F1$PStop right there!$w2 You're not going to
get away this time!$K  $R�w�i��b|$B�x���w�i|$<$F1$FCL_TANIS|$F1$PMarcia!$K
$F3$FCL_MARCIA|$F3$PEeeeeeek!$w4
D-Deputy Commander!$K
$F1$PWhat a disgraceful little scream!$w4
You should know how to behave in
front of your former superior.$K
$F3$PBut... Deputy Commander...$w4
Are you still upset with me?$K
$F1$PI certainly am!$w4 State your reason for
deserting your duty as a pegasus knight!$K$PYou were never one to run away! Even
during the most intense missions...
You were no coward, Marcia.$K$PI've even seen some knights leave
because of a silly romantic distraction...
but not you.$K
$F3$PWell, if you must know...$K$PMy brother went missing after he accrued
a massive debt.$K
$F1$PDebt?$K
$F3$PYes. Men began coming to my barracks to
collect their money instead of hunting down
my brother. That's why I went to find him.$K$PI met Ike and his company during my
search, and I joined after they saved
me from a vicious band of boat monkeys.$K$PBut I still didn't find my brother.$K
$F1$P...$K
$F3$PI figured that if I traveled with Ike,
I'd eventually find my brother.
That's why I'm still with them.$K
$F1$PI see...$K$PSo he skipped town because of his debts.$w4
As your former superior officer, I do feel
some sympathy for you.$K
$F3$P$FSThen--$K
$F1$PNevertheless! You are still a deserter.$w4
It makes no difference why. You will still
be punished once my mission is complete.$K
$F3$P$FAAwww... Come on!$K $R�w�i��b|$B�x���w�i|$<$F1$FCL_TANIS|$F3$FCL_MARCIA|$F3$PSo, you know...$w4 I was thinking...
If possible...$w4 It would be great if
you could overlook my punishment.$K
$F1$PPunishing deserters to the harshest degree
of the law has always been an iron rule.$w4
I cannot make a special exception for you.$K
$F3$P$FhDeputy Commander...$w4 Why do you
have to be so mean?!$K
$F1$PWhy am I mean!?$w4
Because you deserted, I had to--$K
$F3$P$FdYou were always like that.$K$PUnlike Commander Sigrun, you never once
commended our unit.$K$PYou think you understand us, but you don't.
You're just heartless and frigid.$K
$F1$PDon't you get it?$w4 Why do you think
I'm coming down on you so hard!?$K
$F3$PExcuse me?$K
$F1$PI wouldn't normally say this, but...$w4
I had high expectations for you, Marcia.$K$PI thought you could take the reigns
and someday lead the Holy Guard.$K
$F3$PWhat!? Where did that come from?$K$PBack in Begnion, you said nothing about
any of this.$K
$F1$PDo you think I would say something
like that on my own?$w4
I have no choice now.$K$PI'll offer counsel to the commander, and
see to it that you have a place back on
the Guard.$K
If you come back, I might just forget all
about your desertion.$K
$F3$PDeputy Commander...$K$P$FSI...$w3 I appreciate it!$K  $R�w�i��b|$B�x���w�i|$<$F8$FCL_MIST|$F8$POh, no!$w4 Come back here, you!$K$F8$FD
$F3$FCL_MIST|$F3$PHm. Where did that thing go?$w4
I could have sworn it fell around
here somewhere...$K
$F1$FCL_MORDY|$F1$PLooking for this?$K
$F3$PWow!$w4 M-Mordecai...$w4 You scared me.$K
$F1$P$FSI am sorry to frighten you. I found
this. Is it something you lost?$K
$F3$POh, I...$w4 Yes, that's...$w3 Some of my clothes
were drying on the line, and a breeze
carried one of my scarves away...$K$P$FSThank you, Mordecai.$K
$F1$PYou are welcome.$K
$F3$P$FAUh... Mordecai?$K
$F1$P$FAYes?$K
$F3$POh,$w4 uh...$w4 Well...$K
I'm sorry; it's nothing.$K
$F1$P$FSIf you say so. I will take my
leave of you now.$K
$F1$FD$P$w4$F3$P$FcAhhh... What's wrong with me?
I can't believe I couldn't do it.$K$P$FdWhy can't I be more like Ike?$w4
He's so casual, so calm all the time.
I can't keep panicking like that.$K   $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_MORDY|$F3$FS$F3$FCL_MIST|$F3$PHello, Mordecai!$K
$F1$PYou are quite an energetic girl,
are you not?$K
$F3$PYep! I'm in a good mood today.$K
$F1$PI am glad to hear it.$K
$F3$PWell, I like to think I have a cheery
disposition. I don't like to be a
Complainy Janey, you know? Ha ha...$K$PUm... And I like cooking, too. Oh, but
I'm not so good at sewing, but my
mother was.$K
$F1$PIs that so.$K
$F3$PAnd... And...$w4 Um... I forgot
what else I was going to say.$K$PUm, $w2er...$w2
Uh...$K
$F1$PMist.$w4 You must breathe.$K
$F3$P$FA...HAAAAAA!$w5
Whew! Sorry! I'm better now...$K
$F1$PYou are nervous. You have not spoken
to many laguz before. I can tell.$K$PBut in your heart, you are trying
to be my friend. That much is
clear to me.$K$PMost clear.$K
$F3$P...$K
$F1$PDo not be nervous. In time, we will
grow to be friends.$K$PTo speak true, Mordecai feels as
nervous as you do.$K
$F3$POh, Mordecai...$K$P$FSYes...$w4 Thank you.$w4
I feel a lot better now, kind of.$K$PYou're right. $w2I shouldn't try
so hard, should I?$K
$F1$PGraow.$K  $R�w�i��b|$B�x���w�i|$<$F1$FCL_MORDY|$F3$FS$F3$FCL_MIST|$F3$POh, Mordecai.$w4
Is something wrong?$K
$F1$PHave you seen your brother, Mist?$K
$F3$POh, he's with Titania and others.$w4
But I think he'll be here soon.$K
$F1$P$FSAh.$w5 Do you...and your brother
get along well?$K
$F3$PI think so...$w3 I mean, just about as well
as any brother and sister do, you know?$K
$F1$PIke is a good beorc.$w4 He was kind to
me, even though we had just met.$K$PHe is a beorc, but I feel for him as though
he is a brother laguz.$K
$F3$PHa ha ha.$w4 Yeah, he always has been
a little weird, hasn't he?$K
$F1$PIs that so? It does not matter.
I am fond of Ike.$K$P$FAMist...$w4 I do not want you to laugh,
but I would like to tell you something.$K
$F3$P$FAWhat's that?$K
$F1$PWhen I returned your scarf, my hand
was shaking with fear.$K
$F3$PYou?$w4 Were scared?$K
$F1$PYes.$w4 I was afraid that I made you
afraid. I was afraid that you would
run.$w3 I...was afraid.$K
$F3$PWow...$w4 I didn't know that.$w4
$FSTee hee.$w2 It IS kind of funny.$K$PYou and I have a lot in common,
don't you think?$K
$F1$P$FSYes. We share much between us.$K    $R�w�i��b|$B�x���w�i|$<$F3$FS$F3$FCL_MIST|$F1$FS$F1$FCL_TIAMAT|$F1$PDoing the laundry, Mist? Here,
let me give you a hand.$K
$F3$POh, no, no...$w5 Please, you've been fighting
all day. I couldn't make you help!$K
$F1$PWe've all had our hands full around here,
and you're no exception. Now, give me
some of those...$K$PWow. Talk about a pile of laundry...$K
$F3$PYeah, I'm actually washing everyone
else's stuff while I'm at it.$K$PI thought it would be a good way to
thank the others for all their help.$K
$F1$PWell, it's a thoughtful gesture, but make
sure you don't turn it into a full-time job,
all right?$w4 Oh, this one is ripped.$K
$F3$POh, that's my brother's.$w4 He's been
fighting too long in these old things.
Look at it! It's practically falling apart!$K$PNext time we're in a town, I'm going to
make him buy a new shirt.$w4 If he's going
to be commander, he'd better look the part!$K
$F1$PSpeaking of which...$w4let me see that old
thing you're wearing.$K$PThe sleeve is coming apart.$w4 See?$K
$F3$PHey, you're right!$K
$F1$PThis is beyond repair.$w4 Your brother's not
the only one who could benefit from a
shopping trip. We'll go together, you and I.$K
$F3$P$FAI don't know, Titania... There's so much
work to be done around here. I'm not
sure I've got the time, really...$K
$F1$PI'm telling you, Mist, you're pushing yourself
too hard. Everyone appreciates your
work, but you're leaving no time to relax!$K
$F3$PYeah, but...$w4doing the chores helps me
relax!$w5 What? Don't look at me that way!$K
$F1$PMist, that's nonsense.$w4 I mean it. You need
to take some time off. Sometime soon, you
and I will go into town, just the two of us.$K
$F3$P$FSOh, all right!$K $R�w�i��b|$B�x���w�i|$<$F3$FS$F3$FCL_MIST|$F1$FS$F1$FCL_TIAMAT|$F1$PDoing the laundry, Mist? Here,
let me give you a hand.$K
$F3$POh, no, no...$w5 Please, you've been fighting
all day. I couldn't make you help!$K
$F1$PWe've all had our hands full around here,
and you're no exception. Now, give me
some of those...$K$PWow. Talk about a pile of laundry...$K
$F3$PYeah. I know I can't wash up after the
entire Crimean army, but I thought I could
at least help the Greil Mercenaries.$K$PIt's a good way to thank the others for
all their help.$K
$F1$PWell, it's a thoughtful gesture, but make
sure you don't turn it into a full-time job,
all right?$w4 Oh, this one is ripped.$K
$F3$POh, that's my brother's.$w4 He's been
fighting too long in these old things.
Look at it! It's practically falling apart!$K$PNext time we're in a town, I'm going to
make him buy a new shirt.$w4 If he's going
to be general, he'd better look the part!$K
$F1$PSpeaking of which...$w4let me see that old
thing you're wearing.$K$PThe sleeve is coming apart.$w4 See?$K
$F3$PHey, you're right!$K
$F1$PThis is beyond repair.$w4 Your brother's not
the only one who could benefit from a
shopping trip. We'll go together, you and I.$K
$F3$P$FAI don't know, Titania... There's so much
work to be done around here. I'm not
sure I've got the time, really...$K
$F1$PI'm telling you, Mist, you're pushing yourself
too hard. Everyone appreciates your
work, but you're leaving no time to relax!$K
$F3$PYeah, but...$w4doing the chores helps me
relax!$w5 What?$w3 Don't look at me that way!$K
$F1$PMist, that's nonsense.$w4 I mean it. You need
to take some time off. Sometime soon, you
and I will go into town, just the two of us.$K
$F3$P$FSOh, all right!$K    $R�w�i��b|$B�x���w�i|$<$F3$FCL_MIST|$F1$FCL_TIAMAT|$F3$PI'm sorry about the other day, Titania.$w2
I really did have a good time, even
if I didn't look like it...$K
$F1$P$FSDon't worry about it, Mist!$K
You did look awfully serious the whole
time, but that just proves to me how
much you needed the time off.$K
$F3$PAnd I did enjoy seeing the town. I'd never
seen anything quite like it! But I kept
thinking about all the chores waiting here...$K
$F1$PYou're far too considerate of others, Mist.
You're always putting our needs before
your own.$K$PYou're so much like Elena in that regard.$K
$F3$P$FSMy mother?$K
$F1$PYes. You and she are very much alike.$K$PBut you know, Mist, you are still young.
You do not need to take on all the burdens
of adulthood so soon.$K$PI worry about you.$K
$F3$POh, stop...$K$PTitania?$w3 Thank you...$K
$F1$PNo, Mist. Thank you.$K    $R�w�i��b|$B�x���w�i|$<$F3$FS$F3$FCL_MIST|$F1$FS$F1$FCL_TIAMAT|$F1$PCome over here for a second, Mist.$K
$F3$PWhat is it, Titania?$K
$F1$PHere. It's a little present from me.$K
$F3$PHey, this is that dress I saw in town the
other day. Oooo, I loved this dress!$K
$F1$PI thought so.$w4 Aren't you glad we made
that trip together?$K
$F3$POh, thank you, Titania.$K
$F1$PIt's nothing, Mist. Consider it a thank-you
for all you've done.$K$P$FATo tell you the truth, I've been a little
worried about you.$K$PYou've been doing so many chores,
and you've been helping us all on
the battlefield. It's a lot to ask of you.$K$P$FSThat's why I'm trying to make sure you stop
and take care of yourself, treat yourself
to something nice once in a while.$K
$F3$P$FATitania...$K
$F1$PListen, Mist.$K$PI know you and Ike are close, but if there's
ever anything you can't talk to him about,$w4
I want you to know you can come to me.$K$PI may not be Elena, but I do care about
you just the same.$K
$F3$P$FSI...$w4 I will... $w2Thank you...$w4 That's
very nice of you, Titania.$K$PTee hee hee...$w4 Oh, this dress is
too good for me...$K  $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_SOANVALCKE|$F3$FS$F3$FCL_MORDY|$F3$PStefan!$w4 Here you are.$K
$F1$PYeah...$K
$F3$PDo you still want to hear about Gallia?$w4
There are many things I can tell you.$K
$F1$PI was wondering... Do you like Gallia,
Mordecai?$K
$F3$PI do.$w4 Gallia is a good country. Strong.$w4
Plentiful. Very good for me and for my
friends.$K
$F1$PIt is, huh?$K
$F3$PAnd do you like Begnion?$K
$F1$PI detest it.$K
$F3$PDetest?$w4 I do not know this word.$K
$F1$PThen you're lucky.$w4 Sometimes, being
ignorant can be a blessing.$K
$F3$P$FAIgnorant?$w4 ...I have a difficult time with
beorc words. They are strange to me.$K    $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_SOANVALCKE|$F3$FCL_MORDY|$F3$PStefan!$K
$F1$PWhat is it, Mordecai?$w4
You seem upset.$K
$F3$PDetest means hatred.
Ignorant means dumb.$K$PWhy do you hate your country?$w4
Why do you insult me?$K
$F1$PYou've been studying? Impressive.$w4
Listen, I didn't mean to say you were dumb.$K
I just meant that sometimes, it's better not
to know some things... Like what it means
to hate...$K
$F3$PStefan, you do not answer my questions.$K
$F1$PSince you've been studying so much, I've
got another thing for you to look up.$K$PI'm one of the Branded.$w4 Perhaps that
will explain why I detest my country and
why ignorant laguz detest me.$K
$F3$PLaguz...hate you?$w4 Because you are...$w4
branded? Stefan, your words confuse me.$K   $R�w�i��b|$B�x���w�i|$<$F1$FCL_MORDY|$F3$FS$F3$FCL_SOANVALCKE|$F1$PStefan...$K
$F3$PHave you found your answer?$K
$F1$PYou are one of the Branded. You are
the child of beorc and laguz.$K
$F3$PI believe so, at least. My proof is
this mark upon my forehead.$K
$F1$P...$K
$F3$PYou don't need to talk to me if you're
afraid. Now that you know what I am,
I make you uncomfortable, don't I?$K
$F1$PI am unsure.$w4 A legend in Gallia speaks
of the parentless. They are bad omens.$K$PWhen a parentless one comes into being,
a century of destruction follows...$K
$F3$PYes, that's it.$w4 The laguz do call us that.
"Parentless," as if to deny our heritage.
As if to deny that we are their kin.$K$PThat's how the laguz treat us--as if
we should never have been born.$K$PThe beorc may tremble when they see
the brands we bear, but at least they do
not deny that we share blood.$K$PThat is why so many of the Branded hate
the laguz--because they have rejected
our very existence.$K
$F1$PBut how? How is it that you came to be?$K$PLaguz and beorc are different. They
cannot bear children. This is how Ashera
has made our world... It is her law.$K
$F3$PI don't know. The laguz tribes cannot
interbreed, I know that much.$K$PHowever, it seems possible, though rare,
for a child to be born to beorc and
laguz parents.$K$PBut once the bloodlines have mingled,
the trace of it can remain hidden for
countless generations.$K$PHave I violated the goddess's laws?$w4
Have my parents? No. Whatever happened
was done by some forgotten ancestor.$K$PMy parents are beorc, as were their parents
before them. I do not know who is
responsible for what I am.$K$PBut now, after many generations, their
sin has appeared in me. I bear no guilt,
but the badge of impurity is mine to wear.$K
$F1$P...$K
$F3$PMy laguz blood gives me great power.$K$PI thought about using my power to gain
revenge against the people who scorned
me,$w4 but I decided against it.$K$PI have found friends, people who live
outside the normal worlds of the beorc
and the laguz. People who bear the brand.$K
$F1$PWhat did you want from me, Stefan?
Why did you ask about Gallia?$K
$F3$PI was curious about Gallia's beast tribes.$w4
They looked different than those that
live in Begnion.$K$PThere are those among the Branded who
think that a country willing to join hands
with beorc...$K$PMight find a place for us as well.$K$PWe thought we might at last find
acceptance in Gallia and Crimea...$K$POf course, it didn't work out that way...$K
$F1$PStefan...$K
$F3$PWell, I guess that's the end of our
little "friendship" now, isn't it?$K$PI intend to stick around until this war
is over, but I won't bother you anymore.
I know how you laguz are about us.$K
$F1$PNo!$w4 I will not pretend that you are
not among us. I will not pretend that
I do not see what is in front of me!$K
$F3$P$FAWhat will you do, Mordecai? Am I so
wretched to you that you feel you
must take direct action against me?$K$PYou laguz are closer to nature than
the beorc. Are you going to enforce
the goddess's law? Is that it?$K
$F1$PI have not met the goddess. But if her
laws make you unwanted, then I will
have nothing to do with her.$K$PYou have taught me much, and I would
not like to lose your friendship.$K
$F3$P$Fc$FSHm. You'd want nothing to do with the
goddess? Funny, but for the first time
in my life, I'm grateful to her.$K
$F1$PWhy?$K
$F3$P$FdIf someone like you can be so sincere a
friend, then perhaps she's not to blame.
Perhaps her laws aren't what we think.$K $R�w�i��b|$B�x���w�i|$<$F1$FCL_VULCI|$F3$FCL_MORDY|$F3$PI have a question, Ulki.$K
$F1$PYes?$w4 What is it?$K
$F3$PThe bird tribes fly the sky.$w4
How does it feel to fly?$K
$F1$PHuh...$w4 I never think about it.
It's just something that I do.$K
$F3$PHrrrrmm...$w4 I see.$w4 It is for you like
running is for me.$K$PI have never flown. I wanted to know if
it was different.$K
$F1$PThat's what I figured...$K
$F3$PWhat kind of place is your home?
Do you have to fly there?$K
$F1$PWell...$K$PEven if you were to arrive by ship,
Phoenicis has no ports and no docks.
We have no need for them.$K$PWithout our help, it would be hard for
you to visit Phoenicis.$K
$F3$PI see...$w4 That is a shame.$K
$F1$PDo you want to come to Phoenicis?$K
$F3$P$FSI do indeed! I have met many beorc and
laguz throughout this war. Our world is
big, and I would see more of it.$K
$F1$PYou would, huh?$K $R�w�i��b|$B�x���w�i|$<$F1$FCL_VULCI|$F3$FCL_MORDY|$F1$PMordecai...$K
$F3$PIs something troubling you, Ulki?$K
$F1$PI want to ask you something.$K
$F3$P$FSHm?$w4 What is it?$K
$F1$PI understand you beast tribes can see
well even at night.$K$PWith the exception of Janaff,
my kind cannot see at all at night.$K
Even with my eyes wide open,
all I can see is the darkness.$K
$F3$P$FAIn perfect darkness, I cannot see.
If there is but a little light, however,
I can see as clearly as in the day.$K$P$FSI use the moonlight, as should you.$K
$F1$PI wish I could, but that is exactly what
I mean. Your kind can see by moonlight,
but the bird clans...$K
$F3$P$FAThey cannot?$K
$F1$PI long to soar in the sky, looking down
upon the moonlit world...$K$PI would love to see the forest at night.
What do the trees look like as night falls?$K$PWhy are there dewdrops on the leaves
in the morning even when there's no rain?$K$PThe forest at night has so many mysteries.$w4
What light can you shed on them?$K
$F3$P$FSDuring the day, the forest teems with life.$w4
It is very different from the night forest.
But the night forest is also alive in its way.$K
$F1$PIs that so? I would love to
see that, even once.$K  $R�w�i��b|$B�x���w�i|$<$F1$FCL_VULCI|$F3$FS$F3$FCL_MORDY|$F3$PI have an idea, Ulki.$K
$F1$PWhat is it?$K
$F3$PJanaff is your king's eyes. I will be yours.$K$PCarry me on your back. You will help me
fly, and I will show you the night forest.$K
$F1$P...$w4No, you'd be too heavy.
I can't carry you.$K
$F3$P$FAHrrrm... I see.$w4 I am sorry to trouble you.
I can see at night,$w2 and you can fly in
the sky.$w2 I thought it was a good idea...$K
$F1$P...$K
$F3$PIt was a foolish thought.$K
$F1$PNo, it was very kind.$w4 Well, what if...$K$PYes, suppose I grow stronger, and
you, well, lost some weight...$w4
Then we could give your idea a try.$K
$F3$P$FSI will! Then, you can take me to
Phoenicis, and I will see your home!$w4
I will do what you have asked!$K$P$FAExcept...I must lose some weight.
I do not like that.$w5 I like to eat...$K$PNo! It will be worth not eating!
I will see Phoenicis!$K$F3$FD
$F1$P...$w4Uh... It was just a thought.$w5
Let's not go overboard here...$K $R�w�i��b|$B�x���w�i|$<$F3$FCL_ZIHARK|$F3$PThat's strange.$w4 I could swear I had it
just a second ago.$w2 Where did I put...$K
$F1$FCL_MWARIM|$F1$PSomething wrong?$K
$F3$P$FSOh, Muarim.$w4 No, not really. I just...
I seem to have lost my sword powder.$K
$F1$PSword powder?$K
$F3$PIt's used to maintain swords.$K
Swords rust quickly if you don't take care
of them.$w4 A little powder, a little oil,
and a little scrubbing does the trick.$K
$F1$PDoes it come in a small bag attached
to a stick?$K
$F3$PYeah, that's it! Did you pick it up?$K
$F1$PNo, but...$w4I have seen it before. I did
not know that was its name.$K
$F3$P$FAHm. Well, it doesn't look like I dropped it
anywhere around here. Maybe I lost it
when we were marching...$K$FS$PAh, well. Maybe Commander Ike will
have some he can share.$K
$F1$PBeing a beorc has its troubles, does it not?$K
$F3$PYou said it.$K$PYou know, it's times like these I really
envy you laguz. You've always got your
weapons, and they're always at the ready.$K
$F1$P...$K $R�w�i��b|$B�x���w�i|$<$F1$FCL_MWARIM|$F3$FCL_ZIHARK|$F1$PZihark.$K
$F3$P$FSOh, Muarim. What brings you here?$K
$F1$PDid you find the sword powder?$K
$F3$PUnfortunately, no.$K
I'll need to replace it, I think. I hate to
keep borrowing from the others.$K
$F1$PCan you use this?$K
$F3$P$FAWhat's this?$w4 Oh, wow...$w4 This sword
powder looks expensive...$K$PYou're a laguz. How did you come
to have this?$K
$F1$PForce of habit.$K
$F3$PI don't follow you.$K
$F1$PI was once a slave. The nobleman who
was my master made me sharpen his
blades for him. I was quite adept at it.$K$PHe would bring them to me unannounced.
If I did not have the proper materials to
sharpen his swords, he would beat me.$K$PI still do not feel comfortable unless I
have these materials near me.$K
$F3$PI'm sorry to have brought up such
a painful memory.$K
$F1$PIt is in the past now.$w4$FS Would you
like me to sharpen your sword?$K
$F3$P$FSThank you, but a true swordsman takes
care of his own blade.$w4
I appreciate your offer, though.$K
$F1$PThen at least take this powder.$w4
I no longer have any use for it.$K
$F3$PMuarim...$K$PThanks. You saved me. I'm not just saying
this out of gratitude, but...$w4would you care
to join me for dinner?$K
$F1$PI would like that very much.$K   $R�w�i��b|$B�x���w�i|$<$F1$FCL_MWARIM|$F3$FS$F3$FCL_ZIHARK|$F3$PMuarim.$K
$F1$PWhat is it, Zihark?$K
$F3$PI picked this for you.$K
$F1$PThis is...$K
$F3$PI've heard the beast tribes are fond of
the leaves of this kind of herb.$K$PIt's fairly uncommon, but I've learned
how to spot it.$K
$F1$PUm...$K
$F3$P$FAI picked the wrong herb, didn't I?$K
$F1$PNo, no... It's fine. Unfortunately, it
is not something that we tigers
have a nose for.$K
$F3$P$FSOh... I didn't know that.$K$PSorry.$w4 An old girlfriend of mine
loved the scent of it.$K$PI guess I just assumed that all laguz
liked the smell as much as she did.$K
$F1$PYou...$w4were involved with a laguz?$K
$F3$PYeah.$K
$F1$PThat is very uncommon.$w4 I've heard
stories of love affairs between beorc
and laguz. It must have been difficult.$K$PI do not imagine either society would
have accepted it with ease.$K
$F3$PIt...$w4was too much for her. We
couldn't be married, and the pressure
was too much for her to stay with me.$K$PBut I've never loved another woman.
To this day, I think that I never shall.$K
$F1$P$FSCan I have that bundle of herbs?$K
$F3$P$FAWhat?$w4 But I thought...$K
$F1$PIt has no effect on me, it's true, but
I accept the gesture of kindness you
have shown in bringing it to me.$K$PAnd I apologize for bringing up a
painful memory of your own.$K
$F3$P$FSThanks. You're very kind.$w4 Heh. I guess
that makes us even, doesn't it?$K $R�w�i��b|$B�x���w�i|$<$F3$FCL_TANIS|$F3$POh,$w2 excuse me...$K
$F1$FCL_OSCAR|$F1$PYes?$K
$F3$PDid you just drop this cloth?$K
$F1$POops.$w4 Yes, that's mine. Thank you
for picking it up. I apologize for
troubling you, Commander Tanith.$K
$F3$PWhat is your name?$K
$F1$PSilly me. I forgot to introduce myself!$w4
I am Oscar, of the Greil Mercenaries.
It's a pleasure to meet you, milady.$K
$F3$PHm. I hadn't thought you were one of
the mercenaries. That's quite interesting.$K$PI am here with only a minimal retinue,
but I hope that we can demonstrate
the greatness of Begnion's knights.$K
$F1$P$FSI am well aware of Begnion's reputation.$w4
It's an honor to meet the leader of
such an esteemed force.$K
$F3$PYou're too kind.$K
$F1$PIt was a pleasure meeting you, milady.$K
$F1$FD$P$w5$F3$P$FSHm...$w4 Such a well-mannered young man.$K$PI always thought mercenaries were rude,
crude, and vulgar men...$w4 Ike certainly has
some fine lads under his command.$K $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_OSCAR|$F3$FCL_TANIS|$F1$PTanith, I must say, the charge you lead
the other day was spectacular.$K
$F3$PWe are knights of Begnion, after all.$K$PAnything less than a direct charge, knight
against knight, would sully the honor
of our apostle and our motherland.$K
$F1$PI'd heard stories of your bravery before,
but to see you in action was incredible!$K$PTo see so many pegasus knights swooping
onto the battlefield at once, it was like
seeing the sun break through the clouds.$K
$F3$PYou over-romanticize us.$K
$F1$P$FAOh, no, milady. It was a sight to behold.$K$PBut, and do not take offense at this,
might I share an observation with you?$K$PIt strikes me that your strategy works
only if you have the superior numbers.$K
$F3$PAdmittedly, in most battles, Begnion has the
advantage of numbers. I can't recommend
this tactic in our current campaign.$K
$F1$PI agree.$w4 Our army is constantly
undermanned. Sometimes, it's a struggle
just to get the basic necessities!$K$PIt goes without saying that we'll never
have access to all the resources
that Begnion enjoys.$K
$F3$PWell, you seem to understand how to
fight well enough with few numbers.
Tell me, what would you do?$K
$F1$PWe take advantage of our individual soldiers'
strengths. Where you would overwhelm your
foe with numbers, we cannot risk the losses.$K$PWe cannot afford to lose a single soldier,
even if his sacrifice brings us victory.$K$PAfter all, we might win a battle that way,
but we will not be able to last out
the war.$K$PDo not let honor drag you into a duel you
cannot win. Dishonor is better than death if
withdrawing means you live to fight again.$K
$F3$PRetreating from a fight is not an easy
thing to do, but I must admit, your words
make sense given our numbers.$K
$F1$PAnd I would hate to lose your
strength to preserve something
as intangible as honor.$K
$F3$PBut you know, the pegasus knights can
be stubborn. I'm not sure even I can
convince them to change their tactics.$K
$F1$P$FSThen I'll help you convince them. Maybe
my experiences will be all the proof
they need.$K
$F3$PYou'd do that?$K
$F1$PYes, of course. I don't have even half
the experience you do, but if there's
any chance I can help, I will.$K
$F3$P$FSOh, I think you can be quite persuasive.$K$PYou know, you're not what I expected
from a mercenary.$K
$F1$PI'm glad to have surprised you then, milady.$K
$F3$PWe should be going.$FA You'd best keep up
with me. I have no intention of waiting
for you and your horse!$K
$F1$P$FAWell, perhaps I'll have to surprise you
a second time!$K  $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_OSCAR|$F3$FCL_TANIS|$F3$PAre you going somewhere, Oscar?$K
$F1$PYes, milady. I was just about to prepare
supper. Is there something you needed?$K
$F3$PNo, it's nothing important...$w4
I just wanted to thank you.$K$PYour insights into mercenary tactics
have been helpful. I feel like I've learned
more here than I did at the academy!$K$PWhy, I'm starting to wish that I could take
you back to Begnion with me, so that we
could all benefit from your wisdom.$K
$F1$PThat's kind of you to say, milady.$K
$F3$PBy the way...$w4you cook?$K
$F1$PYes, milady.$w4 As I've said, we're a small
company. Each of us handles a variety of
tasks, from fighting to cooking to cleaning.$K
$F3$PYou are full of surprises!$K
$F1$P$FAYou think so?$K
$F3$PI may be a fine warrior, but... It's
embarrassing to admit, but I can't even
crack an egg without hurting someone.$K$PThe last meal I prepared at the academy
took three of our finest generals out of
action for nearly a month.$K
$F1$POh, my...$K
$F3$P$FSShocking, isn't it?$K
$F1$P$FSOh, no.$w4 I take it as a testament to
your skills as a warrior. Just...remind me
never to accept an invitation to dinner.$K$POr...you know, if you'd like, I could
teach you a little...$K
$F3$P$FAYou'd teach me$w4 how to cook?$K
$F1$POnly if you'd like.$K
$F3$PHm. I'm sure you're as good an instructor
in the cooking arts as in the military ones.$w4
$FSAll right.$w2 I accept your offer!$K    $R�w�i��b|$B�x���w�i|$<$F1$FCL_RIEUSION|$F3$FCL_TANIS|$F3$PDo you have a moment, Prince Reyson?$K
$F1$POh, you're the apostle's...$K
$F3$PYes, Your Highness.$w4 My name is Tanith,
and I lead Begnion's holy guard of
pegasus knights.$K
$F1$PWhat brings you here?$K
$F3$PI wanted to let you know that the apostle
has ordered me to keep you safe. She is
quite sincere in her desire to help.$K
$F1$PShe seeks redemption for what happened
all those years ago, does she?$w4 I have no
need for bodyguards. I can protect myself.$K
$F3$PI mean no disrespect, Your Highness,
but even the youngest child in Begnion
knows the heron clan abhors fighting.$K$PIf you refuse to fight, how will you
protect yourself?$K
$F1$PThat is my own concern. Not yours.$K
$F3$PI beg to differ. I am under imperial orders.$w4
I cannot abandon my duty, and so your
safety is very much my concern.$K
$F1$PYour beorc orders do not affect me.
I have wasted enough time with you.$w4
Now excuse me.$K$F1$FD$P$w5
$F3$PHis body seems so frail, but his will is
strong. He's not going to make it easy
for me to protect him.$K$PWhat am I to do?$K  $R�w�i��b|$B�x���w�i|$<$F1$FCL_RIEUSION|$F3$FS$F3$FCL_TANIS|$F3$PYour Highness.$K
$F1$PTanith.$K
$F3$PIt looks like you've healed quite
nicely from that wound you
sustained in our last battle.$K
$F1$P...$K
$F3$P$FAI don't mean to sound disrespectful,
Your Highness, but I feel it's reckless
for you to join us on the battlefield.$K$PSeveral soldiers from my retinue have
complained that, when they try to protect
you, you charge headlong into danger.$K$PPlease, stay out of harm's way and allow
us to guard you. Your behavior
endangers us all.$K
$F1$PI will remain on the battlefield$w3 until
Commander Ike tells me he no longer
has need of my powers.$K$PNo one else may command me.$K
$F3$PBut, Your Highness--!$K
$F1$PThat having been said, I appreciate
your concern.$K$PBut again, I need no bodyguards.$w4
Now stop following me!$K
$F1$FD$P$w5$F3$P...If it weren't for that imperial order,
he'd need a bodyguard to protect
him from ME.$K $R�w�i��b|$B�x���w�i|$<$F1$FCL_RIEUSION|$F3$FCL_TANIS|$F3$PYour Highness.$w4 I owe you my thanks.
Your songs saved my life the other day.$K
$F1$PI am glad you are safe.$K$PI have never seen your pegasus balk
before an enemy.$w4 She usually moves
so swiftly.$K
$F3$PWe've been fighting so hard lately. I think
she must have been exhausted. She
didn't want to let me down...$K$PIf you had not sung your galdr then...$w3
I don't like to think what could have
happened--to her or to me.$K$PAgain, I thank you, Your Highness.$K
$F1$PDo you still think I am of no value
because I do not fight?$K
$F3$PNo, Your Highness. I hadn't realized
how valuable you could be. I was
arrogant, and I was wrong.$K$PTo think I'd intended to protect you,
and yet you wound up saving me.
I have dishonored Begnion.$K
$F1$P$FSIt does not matter. As long as you
understand that I need no protection.$K
$F3$PNo, it matters quite a bit. I'm in over
my head. I cannot remain here, not
after this humiliation.$K$PI return at once to Begnion. There, I
shall await the judgment of the apostle.$K
$F1$P$FAYou jest!$w4 It was a minor tactical
error. You needn't abandon us for--$K
$F3$PNo...$w3 Dishonorable discharge is the only
path left for me...$w4 The apostle charged
me with a task, and I have failed her.$K
$F1$PIf you will not listen to reason,
then I see only one recourse.$K$PI appoint you as my escort.$w4
You have fulfilled your apostle's orders.$K
$F3$PBut, Your Highness,$w3 I have already
seen that I will be nothing but a burden
to you. How can I protect you?$K
$F1$P$FSI will protect you.$w4 We will protect
one another. Remain here, and fulfill
your duty.$K
$F3$PYour Highness, I would be pleased
to accept your appointment.$K$FS$PI have misjudged you once. I swear
I shall not do it again.$K  $R�w�i��b|$B�x���w�i|$<$F1$FCL_RIEUSION|$F3$FS$F3$FCL_TOPUCK|$F3$PMighty prince of the heron clan!$K
$F1$PYes, I am Reyson. Who are you?$K
$F3$PI'm Tormod.$w4 I was hoping to ask
you something.$K
$F1$PI apologize--you caught me off guard.$w4
What do you require?$K
$F3$PThat song of yours...does it work on
everything?$K
$F1$PYou mean the chant?$K
$F3$PYes, whatever it was that made that
drab forest bloom with color.$K
$F1$PYou speak of the galdr, the seid magic.$w4
What of it?$K
$F3$PWould you please sing it for all of us?$K
$F1$PAll of you?$K
$F3$PYes...$w4 For my laguz friends back
in Grann Desert.$K
$F1$PSo you're the leader of the laguz
liberation force.$w4
But you're...not much older than a child.$K
$F3$P$FADo you have a problem with that?$K
$F1$PNo problem at all.$K$PIt's just...ever since I heard whispers of a
beorc fighting to free the Begnion slaves,
I wondered what manner of man he was.$K$PYou're...different than I had envisioned.$K
$F3$PSo I'm young? So what! It doesn't make
what I'm doing any less important.$w4
So...are you going to help us or not?$K
$F1$PI'll gladly lend whatever support I can
give you, but...$w4
What would you have me do?$K
$F3$P$FSI knew you'd come through!$w4
Hmm, let's see...$K$FA$POh, wait...$K
$F1$PWhat is it?$K
$F3$PI'm not quite ready, yet.
The time isn't right.$K$FS$PI'd like to talk to you about it more in
detail, so please allow me to come back
later when I have more time!$K$PSee you later!$K$F3$FD
$F1$PBeorc children are so restless.$K   $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_TOPUCK|$F3$FCL_RIEUSION|$F1$PHello there, great prince of the heron!$K
$F3$PPlease call me Reyson.$K
$F1$PAre you sure? All right, Reyson it is.$w4
Can you spare a moment?$K
$F3$PCertainly.$w4 This is about chanting
for your laguz friends, isn't it?$K
$F1$PThat's right! You remembered!$K
$F3$PWhy don't you tell me more about what you
have in mind?$K
$F1$PWell, I was hoping you would...you know...
use your magic chant to transform all that
sand into soil.$K
$F3$PSand into soil?$K
$F1$PExactly!$w4 Rich, fertile soil that will
yield a bountiful harvest.$K$PWe'll build our village there.$K
$F3$PThat is...utterly absurd!$K$F3$FD
$F1$P$FAHmmm, he sure stormed off in a huff.$w4
For someone that has such kind-looking
eyes, he sure has a short temper.$K    $R�w�i��b|$B�x���w�i|$<$F1$FCL_TOPUCK|$F3$FCL_RIEUSION|$F1$PPlease, Reyson!$w4 You've got to help!$K
$F3$P...$K
$F1$PI know you can do it!$w4 I'm...begging you.$K
$F3$PI'm sorry. I can't.$K
$F1$PIs it because we're poor?$w4
Is that why you won't help us?$K
$F3$PAre you suggesting that I'm only willing
to help the rich?!$K
$F1$PNo...I mean...$w4$K
It was just incredible how you forgave
the apostle like that and breathed new life
back into the forest.$K
$F3$PThat was only possible under very special
circumstances.$K
$F1$PWhy?$w4 I don't get it.$K
$F3$PIt was Serenes Forest. For my people,
there is no more sacred a place.$K
And the galdr I chanted was a part of an
ancient clan ritual performed on a very
holy altar.$K$PMost importantly, my seid magic
succeeded because Leanne was
by my side.$K$PThat galdr holds little force when I chant
it alone.$K
$F1$PThen all we need is Leanne!$K
$F3$PYou're not very quick, are you?$K$PEven if both of us chanted the galdr until
we collapsed from exhaustion, there's no
way we could turn sand into soil.$K$PEven if the desert was a fertile valley eons
ago, I don't have the power to restore it.$K$PHave I made myself clear?$K
$F1$PHmmpph...$K
$F3$PWhat need do you have for such magic?$K$PIke has told me that you are now under
the protection of the apostle.$K
$F1$PThe apostle said she would do something
about the slavery of the laguz.$K$PBut the laguz still live among the beorc.
It's bound to cause hard feelings.$w4
Think about it.$K$PEven if the apostle frees the laguz,
the average beorc will still loathe them.$K$PI just don't want to see my friends live
under a cloud of hatred, fearing for
their lives.$K
$F3$PBeorc and laguz living in harmony?$w4
It's hard to imagine that.$K
$F1$PThat's why I wanted you to do something
about the desert.$K$PIf I could build a village for the laguz
there, they'd be able to get a fresh start.$K
$F3$PThis may be a long way off, but if Serenes
Forest returns to our control, would you
like to come live with us there?$K
$F1$PAre you sure!?$K
$F3$P$FSOf course.$K
$F1$P$FSThis is...unbelievable news!$w4
Everyone will be ecstatic!$K
$F3$PYou should know that hunting animals
for food is forbidden in the sacred forest.$K
$F1$P$FAIt is? Then how will we eat?$K
$F3$PFresh stream water is plentiful, and there
are more than enough nuts and berries.$K
$F1$PBut many of my friends are from the great
beast tribes--they eat meat!$K
$F3$PThey'll have to get used to it.$K
$F1$PI will talk to everyone.$K$PBut they might decide the desert is fine
with them. They do love eating meat!$K $R�w�i��b|$B�x���w�i|$<$F1$FCL_SENERIO|$F3$FCL_SOANVALCKE|$F3$P...$K
$F1$PWho goes there?$K
$F3$P$FSDon't be so alarmed.
I'm...$w4one of yours.$K
$F1$POne of ours? Unlikely.$K
$F3$PYes, one of your kind. I see that you
pretend to be something you aren't
and have lived among foreigners.$K
$F1$P...$w4 I, $w2I...$K
$F3$PHmmm...I see that I've puzzled you.$K$PI'll let you stew on what I have said.
Let's sit and talk next time our paths
cross.$K$F3$FD
$F1$P...$K  $R�w�i��b|$B�x���w�i|$<$F5$FCL_SENERIO|$F5$P...$K
$F3$FS$F3$FCL_SOANVALCKE|$F3$PYou don't fit in with this roving
band of beorc, do you?
Your stone sticks out from the wall.$K
$F5$FD$F1$FCL_SENERIO|$F1$POh. It's you again.$K
$F3$PCome down to the colony in Grann Desert.
Others live there. Others like you.$K$PYou know...the Branded.$K
$F1$PI don't know what you're babbling about,
but you're embarrassing yourself.
I belong here, thank you.$K
$F3$PI see...$w4 Well, if that's the case,
I won't twist your arm.$K$F3$FD
$F1$P...$K  $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_SOANVALCKE|$F6$FCL_SENERIO|$F1$PThis war will be over soon enough.$K$PWhy are you still pretending to be
something you aren't?$K
$F6$PWhy do you keep bringing this up?
I don't know what you're talking about!$K
$F1$PYou're Branded--there's no doubt about it.$w4
I can tell. I'm just like you.$K
$F6$P...$K
$F1$PYou've grown quite good at hiding it.
But, it's merely a matter of time before
your heritage becomes...evident.$K
$F6$P...Evident?$K
$F1$PYou may have already started to notice.
We age differently than the beorc.$K$POf course, the specifics of it depend on
the type of laguz blood that flows
in your veins.$K
$F6$PI thought I was aging normally...$w4
Well, until about three years ago.$K
$F1$PYou won't be able to remain in the same
place.$w4 Beorc aren't very observant,
but even they will soon catch on.$K
$F6$PThat may be true...$Fc But I will not leave
Ike's side.$K
$F1$P$FA...$w4
When the time comes--and you will know
when--ride to Grann Desert.$K$PYou have friends there.$K$F1$FD
$F6$P...$K  $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_STELLA|$F3$FCL_SOTHE|$F1$PTaking care of your weapons, Sothe?$K
$F3$PYeah, that's right.$K
$F1$PAhhh...splendid.$w4 May I speak to you
for a moment?$K
$F3$PWhat do you want?$K
$F1$PYou are quite skilled with a dagger.$w4
If my memory serves, swords are very
effective against axes.$K$PBut, can you tell me which weapon
axes are most suited to attack?$K
$F3$PHah! You don't even know that?
I thought you were a mercenary!$K
$F1$P$FAOh...$w2 I'm sorry. Please forgive my ignorance.$w4
It's been only a short while since I became
a mercenary. What's more, I wield a bow.$K
$F3$PWhat did you do before?$K
$F1$PI wasn't doing...$w4anything.
Nothing at all, really.$K
$F3$PNothing?$w4 It's hard to fill your stomach
doing nothing!$K$PAhh, I get it.$w3 You're a noble, aren't you?
I can tell from all that poncy talk of yours!$K$PPeh! You couldn't tell a hatchet from a
pot of rat stew! Not that you'd ever eat
rat stew...$K$PBut why is a soft-hand like you in this war?$K
$F1$P...$K
$F3$PAh, well... Who am I to judge? As long as
you feather some Daein scum, you're
all right with me.$K  $R�w�i��b|$B�x���w�i|$<$F1$Fc$F1$FCL_STELLA|$F3$FCL_SOTHE|$F1$P$FdOh...$w2 Where am I...?$K
$F3$P...$K
$F1$PWhat...$w4 What happened?$K
$F3$PYou passed out.$w4 I thought about just
leaving you there, but that would have left
a bad taste in my mouth.$K
$F1$PI'm sorry...$K
$F3$PI know it's not my worry, but aren't you
pushing yourself a bit hard?$K$PYou're having a rough time just keeping
up with the pack. You're a wreck!$K
$F1$PI had no idea...$w4how cruel and
unforgiving war would actually be.$K$PGrueling marches...day in and day out.
I can't even sleep at night because I'm
terrified of surprise attacks.$K$PIt's made me painfully aware of my frailty.$K
$F3$PNobles aren't cut out for war.$K$PAs you can see, there are no chambermaids
to attend to your every whim out here!$K$PI'm sure you've got a lavish and free life
waiting for you back home.$K
$F1$PLavish and free?$K
Lavish, maybe...but certainly not free.
I have no freedom.$K
$F3$PNo freedom? What are you talking about?$K
$F1$PMy parents have already chosen and
arranged a fiance for me. I've heard he is
thirty years older than me.$K
$F3$P...$K
$F1$PI volunteered for service with the knights of
Begnion to live on my own terms.$K
Of course, my family vehemently opposed
the idea, but they figured it was merely
a phase.$K$PThey thought I would come home crying.
I won't give them that satisfaction.$K
$F3$P...Wasn't trying to pry. Just asking, is all.$K
$F1$P$FSI know...$w4 Thank you.$K    $R�w�i��b|$B�x���w�i|$<$F1$FCL_STELLA|$F3$FCL_SOTHE|$F1$PHello, Sothe.$w4
$FSThank you...for the other day.$K
$F3$PWhat, for talking? That isn't worth thanking
me for.$K
$F1$P$FANo, you deserve thanks. I feel better.$K
$F3$PI thought you noble types were too good
to thank anyone, but...$w4
You're different...$K
$F1$PAm I?$K
$F3$PYou are.$w4 Most nobles get rich by trampling
on the commoners, then spend their lives
basking in filthy luxury.$K$PI've known them to be that way since
the day I was born.$K$PThey've never seen a blister or sweat for a
day's meal in their lives. Do you know how
lucky you are?$K
$F1$PBut there's no freedom!$K$PMy brothers are the pride of the house.
As soldiers, they lead glorious lives.$K$PBut my sisters are traded like commodities,
promised to fiances they don't even know.$K$PThey don't know love.$w3 I receive letters
from them once every few years. The pages
are warped and stained from tears.$K$P$F3$PYou didn't want to end up like them.$K
$F1$PNo, I didn't. That's why I have no
intention of leaving this war until I see
it to the end.$K
$F3$PI see...$K$PYou're nothing like the nobles I've known.
You worked hard... You're just like the
rest of us.$K
Sorry for thinking you were just another
pampered noble.$K
$F1$PThank you...$K
$F3$P$FSKeep up the good work. You've earned
your freedom.$w4 Never let them take
that away!$K
$F1$P$FSI won't!$K $R�w�i��b|$B�x���w�i|$<$F1$FCL_SOTHE|$F3$FS$F3$FCL_TOPUCK|$F3$PHey, you!$K$PYou were with us during the attack the
other day, right?$K
$F1$PI don't know what you're talking about.$K
$F3$P$FANo, I remember you! I saw you shanking
enemy soldiers with that tiny little blade
of yours.$K$FS$PYou were amazing! By the way, did you
know we're almost the same age?$K$POh, sorry... I'm Tormod.$w4 I may not look
like it, but I'm pretty much the most
dangerous mage around.$K
$F1$P...$K
$F3$PAnd you are?$K
$F1$PSothe.$K
$F3$PIt's nice to meet you, Sothe!$K$PBy the way, why are you working as
a mercenary with this army?$K
$F1$PYou don't need to know that.$K$F1$FD
$F3$P$FAHey!$w4 What's with you?!$w4
No need to be rude!$K    $R�w�i��b|$B�x���w�i|$<$F5$FCL_SOTHE|$F3$FCL_TOPUCK|$F3$PHello, Sothe!$K
$F5$P...$K
$F3$PI was thinking...$w4 We're both lethal
mercenaries and we're both about the
same age, so we should be friends!$K
$F5$PI don't think so.$K
$F3$PNo? Well, you can say that, but I'm
still going to be your friend. You'll see!$K
$F5$PYou're insane.$K$F5$FD
$F3$PYeah...? Well...maybe I am! But it's not like
being my friend is going to hurt you!$K    $R�w�i��b|$B�x���w�i|$<$F1$FCL_TOPUCK|$F3$FCL_SOTHE|$F1$PHello, friend!$K
$F3$PGive it up. We're not friends.$K
$F1$PYou're going to be my friend whether
you like or not.$K
$F3$PWhy are you so determined?$K
$F1$PIt's Muarim.$K
$F3$PMuarim? You mean that tiger?$w4
What about him?$K
$F1$PWell, he looks sad every time I see him...
He thinks it's his fault that I don't have
any beorc friends.$K$PThat's why I wanted you to be my
friend--to make him feel better.$K
$F3$PYou should have said as much. Then I
wouldn't have thought you were crazy.$K
$F1$PThat changes things?$K
$F3$PSure.$K
$F1$PWhy?$K
$F3$PHe's like a father to you. I understand why
you don't want to cause him grief.$K$PI also have...someone...who is like a
parent to me.$K
$F1$POh, I get it!$w4 Hey, you grew up a lot like
me, then!$w4$FS We're going to be
best friends forever!$K
$F3$PEr...well... We'll talk. Sometimes.$w4
But don't get the idea that we're
best friends!$K
$F1$PWhy?$w4 We have so much in common!$K
$F3$PNo offense, Tormod, but thieves are loners.
I can't have you tagging along, snapping
twigs and making lots of noise!$K $R�w�i��b|$B�x���w�i|$<$F1$FCL_TOPUCK|$F3$FCL_SOTHE|$F1$PHello, friend.$K
$F3$PGive it up. We're not friends.$K
$F1$PYou're going to be my friend whether
you like or not.$K
$F3$PWhy are you so determined to be
my friend?$K
$F1$PIt's Muarim.$K
$F3$PMuarim? You mean that tiger?$w4
What about him?$K
$F1$PWell, back when he was alive, he used
to worry about me not having any
beorc friends.$K$PThat's why I wanted you to be my
friend--to honor his memory.$K
$F3$PYou should have said as much. Then I
wouldn't have thought you were crazy.$K
$F1$PThat changes things?$K
$F3$PSure.$K
$F1$PWhy?$K
$F3$PHe was like a father to you. I understand
why you wouldn't want his spirit
to worry.$K$PI also have...someone...who is like a
parent to me.$K
$F1$POh, I get it!$w4 Hey, you grew up a lot like
me, then!$w4$FS We're going to be
best friends forever!$K
$F3$PEr...well... We'll talk. Sometimes.$w4
But don't get the idea that we're
best friends!$K
$F1$PWhy?$w4 We have so much in common!$K
$F3$PNo offense, Tormod, but thieves are loners.
I can't have you tagging along, snapping
twigs and making lots of noise!$K  $R�w�i��b|$B�x���w�i|$<$F1$FCL_VOKE|$F1$PYou there, in the bushes. You have until
the count of five to show yourself
before I start throwing sharp objects.$K
One...$w3two...$w3four...$K
$F3$FCL_ULYSSES|$F3$P$w4Oh, dear! Keep those daggers sheathed,
dearest Volke! I can see why you've
earned such a reputation.$K
$F1$POh. Hello, Bastian.$K
$F3$PYou weren't the fellow I was expecting
to see. Indulge my curiosity for a moment...$w4
Who are you working for?$K
$F1$PKnowing you, I'm surprised you haven't
already checked on what I had for
breakfast.$K
$F3$PSo, it's true, then...$w3
You are working for Crimea under
Commander Ike?$K
$F1$PI serve no nation. I work for Ike himself.$K
$F3$PAnd why is that?$K
$F1$P$FSTen thousand.$K
$F3$PTen thousand?$K
$F1$PPay me, and I'll answer that question.$K
$F3$P$FSTa ha ha! You had no intention of
answering my question, so you came up
with some outrageous sum. Very well.$K
$F1$PI'm not a charity. Get lost if you can't
afford my fee.$K$F1$FD
$F3$P$FAHmmm...what has Ike got brewing in that
brain of his that involves this scurrilous
man of the shadows?$K$PMethinks I should look into this forthwith!$K    $R�w�i��b|$B�x���w�i|$<$F1$FS$F1$FCL_VOKE|$F3$FS$F3$FCL_ULYSSES|$F1$PBack already?$K
$F3$PA little bird landed on my shoulder and
whispered some very juicy information
in my ear.$K$PMost of it matches perfectly with what
I've heard Ike tell the princess.$K$PYes, the information I'm not sharing
with you is most interesting indeed.
Delectable, even.$K
$F1$PYou never could resist a tasty morsel
of gossip.$K
$F3$PWe all our habits have. In any case, my
doubts about you and Commander Ike
have been put to rest.$K
$F1$PHow kind of you.$K
$F3$PThat's all I need say. I just thought
I'd ease your concerns. Consider it a
professional courtesy.$K
$F1$PBastian?$K
$F3$PYeeeees?$K
$F1$PYou're well suited to skulking behind
the scenes and playing the puppeteer.$K$PHave you considered a change in
employer?$K
$F3$PMy allegiance is with the Crimean royal
family. I'm sure you understand.$K$F3$FD
$F1$PSuit yourself.$K $R�w�i��b|$B�x���w�i|$<$F1$FCL_ULYSSES|$F3$FCL_VOKE|$F3$PYou still want something from me.
Otherwise, you wouldn't be here.$K
$F1$PWhen does your contract with
Commander Ike expire?$K
$F3$PHeh. Why do you ask?$K
$F1$PThere is a very delicate matter I'd like you
to attend to. It's something only you are
suited to...address.$K
$F3$PI've known you for a long time now,
and I've never seen such a desperate
glimmer in your eye.$K
$F1$PTwenty thousand.$K
$F3$PEh?$K
$F1$PI'll get you twenty thousand.$w4
But you'll have to attend to it right away.$K
$F3$PThat sounds...tasty. Unfortunately, I have
a policy against taking two jobs at once.$K$PIt will have to wait until this one is over.$K
$F1$P...$K
$F3$PDon't fret, Bastian. My contract with Ike
will only last as long as this war, and it's
already coming to an end.$K$PIt's not clear yet who will win, but it's
certainly coming to a head.
When my plate is clean, I'll find you.$K
$F1$PThis is absurd! You won't take the job?$K
$F3$POh, I'll take it. I never pass up a lucrative
offer. Plus, I've come to think you're not so
bad, Bastian.$FS$K$PYou've always paid in full and on time.
I like that in an employer.$K
$F1$P$FSSo I'm an excellent employer? Perhaps I
should set you up with a pension!
Ta ha ha!$w4$K$FA$PIn any case, it appears that I will have to
wait until the end of this miserable war to
secure your services.$K$PBut do not dawdle, Volke.$w4
It is a matter of utmost urgency.$K   
,      x          $  t   6     H     Z  *�   l  &x   �  !    �  :h   �  5�   �  1@   �  P�   �  G�   �  D(    e�  )  `|  @  [�  W  u�  n  n�  �  j�  �  ��  �  ��  �  �l  �  ��  �  �p    ��    ��  +  �<  A  ��  W  ��  m  ��  �  ��  �  �P  �  ��  �  ͔  �  �  �  �P    �    ��  0  �  I  �  b �  {  ��  �  �<  � �  � X  � �  � �   H   �  3 *�  J &�  _ #  t 3�  � 0�  � -�  � A$  � =  � 9�  � ND   J�  & H   E a`  d [�  ~ VX  � p�  � k�  � g<  � ��  � {X  
 u�    �,  6 �d  H ��  Z �L  l �d  � ��  � �P  � �T  � �  � �,  � �\  � �`  � �H   �X  # �@  5 �  G �  \ Δ  q �   � ��  � ߔ  � �  � �D  � �4  � t  � �   	�  ) "�  @ �  U `  j 9D   *�  � 'D  � D�  � I   � N�  � R�  � A�  	 ?<  	" a�  	4 ^  	I W�  	^ u,  	s o�  	� i8  	� �T  	� d  	� z�  	� �$  	� ��  
 ��  
 �@  
* ��  
@ ��  
V �8  
l ��  
� ��  
� ��  
� Ȁ  
� �  
� �d  
� ؤ  
� �P   ��  & �  = ��  T ��  k �h  ~ �P  � |  � ,  �  �  � �  � X  � t  � $�    �  % h  : 1�  O -  c '�  w A`  � ;�  � 7�  � Q�  � Kt  � G|  � ^h   Y�   V,  3 o�  K y�  d i�  } b  � f   � ��  � �D  � ��  � ��   �`  # ��  8 �l  M �<  ` ��  s �|  � �  � ��  � �`  � �X  � �`  � ��   �  % �h  9 ��  M ��  a ��  w ��  �   �    � �@  � �  �   � �   (�  $ %�  < �  T 6�  l 4x  � 2�  � D�  � ?  � :�  � N�  � R�   L�  * J$  ? _\  T [�  i WP  ~MYELL_BOLE_CHAP_A MYELL_BOLE_CHAP_B MYELL_BOLE_CHAP_C MYELL_BOLE_MIST_A MYELL_BOLE_MIST_B MYELL_BOLE_MIST_C MYELL_BOLE_TIAMAT_A MYELL_BOLE_TIAMAT_B MYELL_BOLE_TIAMAT_C MYELL_BOLE_VULCI_A MYELL_BOLE_VULCI_B MYELL_BOLE_VULCI_C MYELL_CALILL_GEOFFRAY_A MYELL_CALILL_GEOFFRAY_B MYELL_CALILL_GEOFFRAY_C MYELL_CALILL_NEPENEE_A MYELL_CALILL_NEPENEE_B MYELL_CALILL_NEPENEE_C MYELL_CALILL_TOPUCK_A MYELL_CALILL_TOPUCK_B MYELL_CALILL_TOPUCK_C MYELL_CHAP_NEPENEE_A MYELL_CHAP_NEPENEE_B MYELL_CHAP_NEPENEE_C MYELL_CHAP_ZIHARK_A MYELL_CHAP_ZIHARK_B MYELL_CHAP_ZIHARK_C MYELL_CHINON_GATRIE_A MYELL_CHINON_GATRIE_B MYELL_CHINON_GATRIE_C MYELL_CHINON_JANAFF_A MYELL_CHINON_JANAFF_B MYELL_CHINON_JANAFF_C MYELL_CHINON_LOFA_A MYELL_CHINON_LOFA_B MYELL_CHINON_LOFA_C MYELL_DALAHOWE_LARGO_A MYELL_DALAHOWE_LARGO_B MYELL_DALAHOWE_LARGO_C MYELL_DALAHOWE_NEPENEE_A MYELL_DALAHOWE_NEPENEE_B MYELL_DALAHOWE_NEPENEE_C MYELL_DALAHOWE_TOPUCK_A MYELL_DALAHOWE_TOPUCK_B MYELL_DALAHOWE_TOPUCK_C MYELL_ELAICE_GATRIE_A MYELL_ELAICE_GATRIE_B MYELL_ELAICE_GATRIE_C MYELL_ELAICE_LUCHINO_A MYELL_ELAICE_LUCHINO_B MYELL_ELAICE_LUCHINO_C MYELL_ELAICE_MORDY_A MYELL_ELAICE_MORDY_B MYELL_ELAICE_MORDY_C MYELL_ELAICE_WAYU_A MYELL_ELAICE_WAYU_B MYELL_ELAICE_WAYU_C MYELL_ELAICE_ZIHARK_A MYELL_ELAICE_ZIHARK_B MYELL_ELAICE_ZIHARK_C MYELL_ERINCIA_QUEEN_GEOFFRAY_A MYELL_ERINCIA_QUEEN_GEOFFRAY_B MYELL_ERINCIA_QUEEN_GEOFFRAY_C MYELL_ERINCIA_QUEEN_IKE_A MYELL_ERINCIA_QUEEN_IKE_B MYELL_ERINCIA_QUEEN_IKE_C MYELL_GATRIE_MARCIA_A MYELL_GATRIE_MARCIA_B MYELL_GATRIE_MARCIA_C MYELL_GATRIE_STELLA_A MYELL_GATRIE_STELLA_B MYELL_GATRIE_STELLA_C MYELL_HAAR_JILL_A MYELL_HAAR_JILL_B MYELL_HAAR_JILL_C MYELL_HAAR_MAKAROV_A MYELL_HAAR_MAKAROV_B MYELL_HAAR_MAKAROV_C MYELL_IKE_LAY_A MYELL_IKE_LAY_B MYELL_IKE_LAY_C MYELL_IKE_LETHE_A MYELL_IKE_LETHE_B MYELL_IKE_LETHE_C MYELL_IKE_OSCAR_A MYELL_IKE_OSCAR_B MYELL_IKE_OSCAR_C MYELL_IKE_RIEUSION_A MYELL_IKE_RIEUSION_B MYELL_IKE_RIEUSION_C MYELL_IKE_SENERIO_A MYELL_IKE_SENERIO_B MYELL_IKE_SENERIO_C MYELL_IKE_TIAMAT_A MYELL_IKE_TIAMAT_B MYELL_IKE_TIAMAT_C MYELL_JANAFF_LUCHINO_A MYELL_JANAFF_LUCHINO_B MYELL_JANAFF_LUCHINO_C MYELL_JANAFF_OSCAR_A MYELL_JANAFF_OSCAR_B MYELL_JANAFF_OSCAR_C MYELL_JILL_LETHE_A MYELL_JILL_LETHE_B MYELL_JILL_LETHE_C MYELL_JILL_MIST_A_a_1 MYELL_JILL_MIST_A_a_2 MYELL_JILL_MIST_A_b_1 MYELL_JILL_MIST_A_b_2 MYELL_JILL_MIST_B MYELL_JILL_MIST_C MYELL_KEVIN_KILROY_A MYELL_KEVIN_KILROY_B MYELL_KEVIN_KILROY_C MYELL_KEVIN_MARCIA_A MYELL_KEVIN_MARCIA_B MYELL_KEVIN_MARCIA_C MYELL_KEVIN_OSCAR_A MYELL_KEVIN_OSCAR_B MYELL_KEVIN_OSCAR_C MYELL_KILROY_LOFA_A MYELL_KILROY_LOFA_B MYELL_KILROY_LOFA_C MYELL_KILROY_TIAMAT_A MYELL_KILROY_TIAMAT_B MYELL_KILROY_TIAMAT_C MYELL_KILROY_VULCI_A MYELL_KILROY_VULCI_B MYELL_KILROY_VULCI_C MYELL_KILROY_WAYU_A MYELL_KILROY_WAYU_B MYELL_KILROY_WAYU_C MYELL_LARGO_MWARIM_A MYELL_LARGO_MWARIM_B MYELL_LARGO_MWARIM_C MYELL_LARGO_TAURONEO_A MYELL_LARGO_TAURONEO_B MYELL_LARGO_TAURONEO_C MYELL_LARGO_WAYU_A MYELL_LARGO_WAYU_B MYELL_LARGO_WAYU_C MYELL_LAY_LETHE_A MYELL_LAY_LETHE_B MYELL_LAY_LETHE_C MYELL_LAY_MORDY_A MYELL_LAY_MORDY_B MYELL_LAY_MORDY_C MYELL_LETHE_MWARIM_A MYELL_LETHE_MWARIM_B MYELL_LETHE_MWARIM_C MYELL_LOFA_MARCIA_A MYELL_LOFA_MARCIA_B MYELL_LOFA_MARCIA_C MYELL_LOFA_MIST_A MYELL_LOFA_MIST_B MYELL_LOFA_MIST_C MYELL_LOFA_TAURONEO_A MYELL_LOFA_TAURONEO_B MYELL_LOFA_TAURONEO_C MYELL_LUCHINO_ULYSSES_A MYELL_LUCHINO_ULYSSES_B MYELL_LUCHINO_ULYSSES_C MYELL_MAKAROV_STELLA_A_a MYELL_MAKAROV_STELLA_A_b MYELL_MAKAROV_STELLA_B MYELL_MAKAROV_STELLA_C_a MYELL_MAKAROV_STELLA_C_b MYELL_MAKAROV_ULYSSES_A MYELL_MAKAROV_ULYSSES_B MYELL_MAKAROV_ULYSSES_C MYELL_MARCIA_TANIS_A MYELL_MARCIA_TANIS_B MYELL_MARCIA_TANIS_C MYELL_MIST_MORDY_A MYELL_MIST_MORDY_B MYELL_MIST_MORDY_C MYELL_MIST_TIAMAT_A MYELL_MIST_TIAMAT_B MYELL_MIST_TIAMAT_C_a MYELL_MIST_TIAMAT_C_b MYELL_MORDY_SOANVALCKE_A MYELL_MORDY_SOANVALCKE_B MYELL_MORDY_SOANVALCKE_C MYELL_MORDY_VULCI_A MYELL_MORDY_VULCI_B MYELL_MORDY_VULCI_C MYELL_MWARIM_ZIHARK_A MYELL_MWARIM_ZIHARK_B MYELL_MWARIM_ZIHARK_C MYELL_OSCAR_TANIS_A MYELL_OSCAR_TANIS_B MYELL_OSCAR_TANIS_C MYELL_RIEUSION_TANIS_A MYELL_RIEUSION_TANIS_B MYELL_RIEUSION_TANIS_C MYELL_RIEUSION_TOPUCK_A MYELL_RIEUSION_TOPUCK_B MYELL_RIEUSION_TOPUCK_C MYELL_SENERIO_SOANVALCKE_A MYELL_SENERIO_SOANVALCKE_B MYELL_SENERIO_SOANVALCKE_C MYELL_SOTHE_STELLA_A MYELL_SOTHE_STELLA_B MYELL_SOTHE_STELLA_C MYELL_SOTHE_TOPUCK_A_a MYELL_SOTHE_TOPUCK_A_b MYELL_SOTHE_TOPUCK_B MYELL_SOTHE_TOPUCK_C MYELL_ULYSSES_VOKE_A MYELL_ULYSSES_VOKE_B MYELL_ULYSSES_VOKE_C 