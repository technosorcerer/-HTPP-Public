  ��  �$       )                $RGMAP��b|$O3$GThe Begnion Empire,$w2 the largest
nation on the continent, is a theocracy
dedicated to the goddess Ashera.$K   $RGMAP��b|$O3$GReigning from the summit of the empire$w3
and guiding the world $w2with the voice of the
goddess,$w3 the apostle Sanaki rules Begnion.$K$PAs Ashera's chosen vessel,$w3 the apostle
is showered $w2with love and respect
from the entire nation.$K$PSeven imperial senators aid the apostle$w3
in the governance of her realm.$K$PThis system of government$w3 has been
the backbone$w3 of Begnion $w2for
many long centuries.$K$PAfter Ike and his company aid the apostle,$w3
her holy guard takes them to the imperial
capital, Sienne.$K$P  $RGMAP��b|$O3$GThe upper class of Begnion society live
lives of pampered comfort and luxury.$K$PKnown as the Sainted, $w2these elite
power brokers reside in massive temple-like
homes whose spires dominate the skyline.$K$PThe Guiding Tower overlooks all from the
heart of the city. Here, $w2Ashera holds
her vigil, watching over the world.$K$PSurrounding the tower $w2is a series of
temples, both large and small, placed in
an orderly, systematic fashion.$K$POne temple, however, $w2is conspicuously
larger than the others. It is $w2the grand
temple Mainal, $w2home to the apostle.$K$PIke and his company, $w2used to the freedoms
of Crimea,$w3 find the differences in culture$w2
and custom$w3 to be very confusing.$K
$Ub$H  $R�w�i��b|$B���{-�x�O�j�I��|$<$F3$FCL_ERINCIA|$F1$FCL_SANAKI|$F1$P$FcAhem...$K$w4$Fd$PNow then,$w3 you have proclaimed yourself
to be the orphan of $w1Crimea's King Ramon.$w3
Princess Elincia Ridell Crimea, $w2correct?$K
$F3$PYes.$K
$F1$PI have heard stories that King Crimea had
a daughter in secret. My men have reported
as much to me in the past.$K$PHowever,$w3 whether you are that
princess or not$w3 is another tale.$K$PDo you have nothing that would lend
credence to your claims?$K
$F3$PNothing at all.$w4 It took all my energy simply
to avoid capture by Daein.$w4 I had no time
to secure any proof of my claim.$K
$F1$PHmph.$w4 And with Crown Prince Renning
also dead, $w2there is no one who even
knows your face.$w4 What am I to do?$K
$F4$FCL_IKE|$F4$PI will vouch for her.$K
$F3$PMy lord Ike!$K
$F4$PI have no doubt that Princess Elincia is
the true heir to the throne of Crimea.$K
$F1$POh, really?$w4 And tell me, what gives you
this strength of conviction?$K$PIf we believe her story,$w3 this woman has
not engaged with the outside world
since the day she was born.$K$PSo how is it that you,$w2 a lowly$w4 mercenary,$w2
dare to assert her authenticity?$K
$F4$PThe Daein army pursues her with
bloody-minded determination.$K$PAt every turn,$w3 they demand that we turn
Princess Elincia over to them.$K$PWhat further proof do you need?$K
$F1$PHmm... $w2If someone of...$w4proper standing
made that pronouncement,$w3 I would
accept it as irrefutable proof.$K$PBut you... You're a commoner.$w4 You
have no surname, no documented
lineage...$w3 You have nothing.$K$PI know commoners. They are poor.$w4
For a price, they will support any lie,$w3
no matter how outlandish.$K
$F4$P...$K
$F1$P$FSOh!$w3 Now,$w2 I suppose you will tell me you
are the son of some noble house?$K$PNo, $w2of course not.$w3 But wait,$w2
perhaps you're a royal knight of Crimea?$K
$F1$FA$F4$PI $w2am neither a noble nor a knight.$w4
I have no connection $w2with the
palace whatsoever.$K$PAnd no matter how much gold I stood to
gain,$w3 I would not betray my convictions.$K$PElincia has paid us, yes, but nothing more
than the standard fee to purchase our
services as her escort. Nothing more.$K$PWe have come this far only because we
believe Elincia to be a woman of integrity.$w3
We would not sell our swords to a liar.$K$PI don't care how high and mighty you might
be. I will not stand here and let you mock
the bond of trust that ties us to Elincia.$K
$F3$PMy lord Ike!$K
$F0$FCL_LEKAIN|$F0$PHow dare you!$w3 Who are you to address
the apostle $w2so crudely!$K$P$Ub$HGuards!$w2 Guards!$w4 Seize this man!$w5
For his abuse of the apostle, $w5the
penalty can be only death!$K
$F1$PHalt!$K$w6$FS$P...Ha ha! $w2Ha ha ha!$w3
Sephiran was right about you.$w4
You are very$w3 interesting.$K
$F0$PA-$w2Apostle?$K
$F4$PSephiran?$w4 That monk we rescued
from the prisons?$K
$F1$PA monk, was it?$w4 His disguises are always
so clever. It never ceases to amaze me.$w4
As always, $w2he remains an enigma.$K$PHeed my words!$w3 Sephiran is in truth
Duke Belsys,$w2 prime minister of Begnion
and my most trusted advisor.$K$PHe has been traveling the neighboring
lands for months,$w3 trying to ascertain
the condition of the people there.$K$P$F0$FD$F0$FS$F0$FCL_SIGRUN|$F0$PWe have received detailed reports$w2 on
Princess Elincia$w3 and the mercenary
company serving as her escort.$K
$F3$PSo...$w4you knew we were coming.
You knew who we were all along.$K
$F1$PYes.$w4 I apologize for testing you. You see,
life here in the palace$w2 is dreadfully dull.
I am always so very bored.$K$PThanks to the princess and her brazen
little escort,$w3 this interrogation proved
to be an amusing diversion.$K$P$F0$FD$F0$FS$F0$FCL_OLIVER|$F0$POh ho ho!$w3 So that's what this was!$w4
How very like you, Apostle. A cunning game
of wits and words.$w4 Simply smashing!$K$PEven your most loyal servant, $w2Duke Oliver
of Tanas,$w3 was on the verge of being
completely fooled. I am humbled!$K$POh ho ho!$w3 Come,$w3 Duke Lekain!$K$P$F0$FD$F0$FCL_LEKAIN|$F0$PAh-$w2ahem.$w5$FS It was all a ruse, was it?
$w4...$w2Oh, Apostle, you do tease us
so mercilessly!$K$PStill, it was not such a bad way to
amuse ourselves, was it, Duke Hetzel?$K
$F0$FD$F0$FS$F0$FCL_HETZEL|$F0$PHoo!$w3 Too true, my good duke!$K$PPrincess Crimea,$w3 it appears that you have
put quite a smile on the face of our
beloved apostle.$K$PWhat an honor that must be!$w4
Hoo hoo hoo!$K$FD
$F3$P...Ah...$w4 Um...$w2
Yes...$w5 I suppose...$K
$F4$PMadness!$K$F4$FD
$Ub$H$F1$POh, yes, $w2I almost forgot in all the fun...$w4
Sephiran has already vouched for your
identity as the true princess of Crimea.$K$PI require no further proof.$w4
You may rest easy.$K
$F3$PI am...$w3most grateful.$w4$K$P$Ub$H$F3$FD$F3$FCL_IKEa|$F4$FCL_ERINCIA|$F3$PWait a minute!$K
$F1$P$FAYes?$K
$F3$PWhat $w2is the meaning of this?$w4
You knew Elincia was Princess Crimea?$K$PAnd you continued to humiliate her for your
own entertainment?$w3 For some stupid game
of wits and words?$w4 This is no joke!$K
$F1$P...$K
$F3$PElincia's homeland is lost to her!$w4 Her family
has been hunted down and killed by the
monsters of Daein!$K$PAnd with nowhere else to turn, she endures
mortal danger and terrible heartbreak to
reach your door.$K$PAnd then you...$w4you laugh at her?!$w2 Where is
the humor in that?$w4 Where is your
decency?$K$PYou're horrible!$w4 You are all horrid people!$w4
You disgust me beyond words!$w3
And you owe Elincia a proper apology.$K
$F4$PMy... $w2My lord Ike, please--$K
$F0$FA$F0$FCL_LEKAIN|$F0$PWretched peasant!$w3 You loose that
treasonous tongue once more, and--$K
$F1$PDuke Lekain,$w3 restrain yourself!$K
$F0$PBut...$w3 But...$K
$F1$PI am speaking. $w2Be still.$K
$F0$PGrrr...$K$F0$FD
$Ub$H$F1$PNow then, $w2Ike.$w4 I fully understand
your feelings.$K$FS$PYour passion for your employer is truly a
beautiful thing.$w5 Would that my own fawning
vassals shared your commitment.$K$FA$P$FhHowever, truth be told,$w3 your behavior
does test my patience.$K$PRaise your voice once more to me,$w2 and you
will seriously damage the princess's already
precarious position. $w2Do you understand?$K
$F3$PNot really. Why don't you fill me in?$K
$F1$P$FcEven if Elincia is truly Crimean royalty,
she is at best heir to a dead country.$w2
Nothing more.$K$PWithout Begnion's support, $w2Elincia's claim
holds no meaning.$w4 $FdAm I mistaken?$K
$F3$PPah!$K
$F1$PEven if we harm her fragile feelings,$w2
for the sake of her country's future,
she must stand by and say nothing.$K$PIn fact, she is in no position to do
anything but beg for Begnion's favor.$w3
Or...$w4hadn't you noticed?$K
$F3$P...$K
$F1$P$FcI have much to consider. $FdFor now,$w3
I shall take my leave of you.$K$PI will meet with my senators soon and
discuss this state of affairs.$w3 Crimea's
future will not be uncertain for long.$K$FS$PUntil that time, $w2I suggest you rest and
relax.$w5 Perhaps you could try your hand
at our courtly games of...$w4wit and words?$K   $R�w�i��b|$B���-��|$<$F3$FCL_IKEa|$F3$PWhat $w2incredible nerve! To take advantage
of our situation and speak down to
us like that...$K$PI don't care if she's the empress $w2or the
apostle or whatever!$w3 I can't stand her!$K
$F1$FCL_TIAMAT|$F1$PListen, $w2Ike,$w4 isn't it possible$w3
that the apostle $w2saved you?$K$P$F3$FD$F3$FCL_IKE|$F3$PWhat?$K$P$F0$FCL_NASIR|$F0$PTitania is correct.$w4 Begnion is a nation$w2
ruled by time-honored custom and
ancient conventions.$K$PYou insulted the apostle--$w2the very symbol
of their way of life.$w3 The fact that you are
still breathing $w2is a miracle.$K
$F3$PI...$w4hadn't realized.$K
$F0$PAnd as her escort,$w3 your criminal behavior
would fall directly on your employer,$w3
Princess Elincia.$K$PIf you had truly $w2angered the apostle,$w4
any hope of restoring Crimea would have
vanished like a puff of smoke.$K
$F3$PThat's madness! They would sacrifice a
whole country to satisfy their own egos?$K$P$F4$FCL_SENERIO|$F4$PIke...$w4 This may not be much of an answer,
but letting madness $w2rule the day$w4
is the prerogative of nobility.$K$PThe beorc divide themselves into classes.$w3
And with classes come prejudice.$K$PFrom the moment of our birth to our final
dying gasp, we commoners know we are
not allowed to defy the upper classes.$K$P$F4$FD$F0$FD$F1$FD$w3$F1$FCL_ERINCIA|$F3$PPrincess Elincia...$w3I...$w4 I'm sorry.
My ignorance $w2does not excuse my
stupidity. $w5...$FcI truly am$w3 sorry.$K
$Ub$H$F1$P$FSNo.$w3 I...$w4 What you said, you said in
my defense and in my honor.$w6
It made me$w2 very pleased.$K
$F3$P$FdHuh?$K
$F1$PTo see you so angry $w2on my behalf...$w4$Fc
Your words filled my heart.$K
$F3$PIt wasn't as noble as you make it sound.$K
$F1$P$Fd$FAHowever,$w3 there is one point that
I would contest. It is true $w2that I've
lost my family...$w4and my home.$K$w4$FS$PBut I did have people to turn to...$w2
People to rely on.$w4 My lord Ike, $w2you
and your company were at my side.$K$PFor me, this has been a great source
of inspiration and of happiness.$K
$F3$PPrincess Elincia...$K
$F1$PMy lord Ike...$w4 Please $w2call me Elincia.$K
$F3$PHuh?$w4 That would be improper, wouldn't it?$w4
I mean, $w2you're our employer, and...$K
$F1$PYou called me so earlier.$K
$F3$PI did?$w4 Really?$K
$F1$PYou didn't notice?$K
$F3$PNo, I...$w4 Oh.$w4
$Ub$HMy apologies. $w2I'll be more careful.$w5$K$PWell, $w2I suppose we should go.$w4
They've prepared rooms for us.$K$P$F3$FD
$F1$P$FAAh, $w2my lord Ike...$w4
...$K
$=1000  $R�w�i��b|$B���-����-�x�O�j�I��|$<$F3$FCL_IKE|$F1$FCL_MIST|$F1$PI$w4 am$w4 so $w5booooored!$w4
We've been here for five days already...$w4
And there's absolutely nothing to do!$K$PThey gave me free reign to wander
the temple, $w2but I've seen everything!$w4
I'm tired of it!$K
$F4$FCL_TIAMAT|$F4$PI take it Princess Elincia $w2has been
invited to yet another social gathering?$w4
A little time off is one thing,$w4 but this...$K
$F3$PI guess I'll get in some fencing practice...$K$P$F1$FD$F0$FS$F0$FCL_NASIR|$F0$PIke,$w3 the captain of the apostle's
holy guard $w2is headed this way.$K
$F0$FD$F0$FS$F0$FCL_SIGRUN|$F0$PI beg your pardon.$w4 Are you and your
mercenary company enjoying
your stay here in Begnion?$K$PIs there anything $w2you find wanting?$K
$F3$PThere's nothing to do, $w2and Mist is bored.$K
$F1$FCL_MIST|$F1$PAh, $w2Ike!$w4 Why'd you say that!?$K
$F3$PWeren't you just complaining about that
exact same thing to me?$w4 You said you
were bored and tired of everything.$K
$F1$PThat doesn't mean you should go
spouting it to everyone! Oh,$w2
you're such an idiot, Ike!$K$F1$FD
$F4$P$FcMy apologies...$w4 Neither of them meant
any offense. They're just frustrated.$K$Fd$F4$P$F0$PYes, $w2I understand that.$w4
I will pay it no mind.$K
$F3$PDid you have $w2some reason for
coming to speak with us?$K
$F0$PI bring word from the apostle...$w2
She wishes to charge you with a task.$K
$F3$PThe apostle wants to employ us!?$K
$=1000 $R�w�i��b|$B����-��-��|$<$F3$FCL_IKE|$F1$FCL_TIAMAT|$F1$PI didn't expect this.$K
$F3$PExpect what?$K
$F1$P$FSYour reaction. $w2I'd have thought that
you would be spouting and fuming at
the thought of working for the apostle.$K
$F3$PIf Princess Elincia can tolerate endless
social gatherings to judge Begnion's
mood and garner her favor,$K$Pthe least I can do is help her earn
points by running an errand or two.$K
$F1$P$FAHmm...$K$P$F0$FCL_SENERIO|$F0$PIke, $w2they're coming.$K
$F3$PSo we lay in wait for them here, $w2right?$K
$F0$PYes.$w4 The apostle's orders were clear.$K$P"Stop the band of merchants traveling on
the old highway,$w4 and seize their cargo."$K$PThis does look to be the best spot for
an ambush.$K
$F3$PAll right.$w3 I don't know who we're facing,$w2
but we're on the job. $w2Let's do this right!$K $R�㉺��b|$c0GASIRAMA|$s0A poor crop this time around.$K$PCats, $w2tigers,$w3 and a few crows...$w4
All we've got are laborers.$w4 We're not
going to get rich with this.$K
$c1BANDIT7|$s1Aw, and we worked hard to catch
'em!$w4 Is it as bad as all that?$K
$s0$FSI've been selling half-breeds for twenty-
five years. The ones that fetch the
highest price are the trophy herons.$K$PAnd $w2if they're white-winged royals,$w3
the fanatics will $w2empty their purses
of every last coin.$K
$s1Well, $w2if that's the case, why don't
we hit Serenes Forest next time?$w4
There might be a few of 'em left.$K
$s0$FAYou've the brains $w2of a dead wyvern!$w4
Why do you think herons are so
expensive?$w4 It's because they're rare!$K$PIt's been twenty years since that mob
burned Serenes.$w4 The herons were
all roasted like chickens!$K$PNo matter how you look at it,$w3 that
was utter lunacy.$w4 All that gold,$w4
up in smoke.$K
$s1$FSOh...$w3 If they're so valuable,$w2 I'd like
to see one with my own eyes.$w4
$FcI'd $w2catch it$w3 and put it in a cage...$K
$s0...$w3Idiot...$K
$s1Think what you could buy with all
that gold.$w3 A new axe...$w4
Oh, and some furry boots, too!$K
$s0Shut up, fool!$w4
Stop your daydreaming,$w3
and look over there!$K
$s1$FA$FdWh-$w2what?$w4 Who are they?$K
$s0Bah!$w4 Look alive,$w3 lads!$w4
They're not $w2common travelers!$K   $R�w�i��b|$B����-��-��|$<$F1$FCL_GASIRAMA|$F1$PA poor crop this time around.$K$PCats, $w2tigers,$w3 and a few crows...$w4
All we've got are laborers.$w4 We're not
going to get rich with this.$K
$F3$FCL_BANDIT7|$F3$PAw, and we worked hard to catch
'em!$w4 Is it as bad as all that?$K
$F1$P$FSI've been selling half-breeds for twenty-
five years. The ones that fetch the
highest price are the trophy herons.$K$PAnd $w2if they're white-winged royals,$w3
the fanatics will $w2empty their purses
of every last coin.$K
$F3$PWell $w2in that case, why don't
we go to Serenes Forest next time?$w4
There might be some of them left.$K
$F1$P$FAYou've the brains $w2of a dead wyvern!$w4
Why do you think herons are so
expensive?$w4 It's because they're rare!$K$PIt's been twenty years since that mob
burned Serenes.$w4 The herons were
all roasted like chickens!$K$PNo matter how you look at it,$w3 that
was utter lunacy.$w4 All that gold,$w4
up in smoke.$K
$F3$P$FSOh...$w3 If they're so valuable,$w2 I'd like
to see one with my own eyes.$w4
$FcI'd $w2catch it$w3 and put it in a cage...$K
$F1$P...$w4Idiot...$K
$F3$PThink what you could buy with all
that gold.$w3 A new axe...$w4
Oh, and some furry boots, too!$K
$F1$PShut up, fool!$w4
Stop your daydreaming,$w3
and look over there!$K
$F3$P$FA$FdWh-$w2what?$w4 Who are they?$K
$F1$PBah!$w4 Look alive,$w3 lads!$w4
They're not $w2common travelers!$K $R�㉺��b|$c0IKE|$s0Here they come.$w4 Titania, $w2are we
sure this is the right bunch?$K
$c1TIAMAT|$s1This fog makes it hard to see, but$w4
their numbers $w2and appearance$w3 match
our intelligence... $w5It must be them.$K$d1
$c1SENERIO|$s1Well,$w2 they've certainly seen us.$w4
They're readying their weapons.$K
$s0Very well... $w2Get ready to fight,
everyone!$K   $R�㉺��b|$c0MAKAROV|$s0Ah...$w3 What terrible luck. My sixth
sense told me $w2that the weather
would be nice today.$K
$c1BANDIT8|$s1Hey!$w3 Grumbling and whining won't
pay off your debt!$w4 Come on,
beautiful, $w2cough up my gold!$K
$s0I'd dearly love to pay you, but$w4
unfortunately...$w4I'm broke.$K
$s1Not again!$w4 You're employed as$w2
a bodyguard! $w2Why don't you have
enough gold to pay me back?!$K$PGrr! When we get back to the base,$w2
I'll get what's mine.$w4 Try to run,$w2
and you'll pay in pain!$K$d1
$s0...$w2Threaten all you like!$w4 I can't
give you$w3 what I don't have!$w4
Ooo, I hope that sounded brave...$K$POh, dear... What am I going to do?$w4
It seems I must go crawling back to
my dear sister once again.$K$POh, she's going to be so mad...$w5 But
in the end, I'm sure she'll help! After
all, it's for the life of her brother!$K$w3$FS$PRight! $w2Tonight, $w2I pay a little
visit to the barracks of the sacred
pegasus knights!$K  $R�w�i��b|$B����-��-��|$<$F1$FCL_MAKAROV|$F1$PAh...$w3 What terrible luck. My sixth
sense told me $w2that the weather
would be nice today.$K
$F3$FCL_BANDIT8|$F3$PHey!$w3 Grumbling and whining won't
pay off your debt!$w4 Come on,
beautiful, $w2cough up my gold!$K
$F1$PI'd dearly love to pay you, but$w4
unfortunately...$w4I'm broke.$K
$F3$PNot again!$w4 You're employed as$w2
a bodyguard! $w2Why don't you have
enough gold to pay me back?!$K$PGrr! When we get back to the base,$w2
I'll get what's mine.$w4 Try to run,$w2
and you'll pay in pain!$K$F3$FD
$F1$P...$w2Threaten all you like!$w4 I can't
give you$w3 what I don't have!$w4
Ooo, I hope that sounded brave...$K$POh, dear... What am I going to do?$w4
It seems I must go crawling back to
my dear sister once again.$K$POh, she's going to be so mad...$w5 But
in the end, I'm sure she'll help! After
all, it's for the life of her brother!$K$w3$FS$PRight! $w2Tonight, $w2I pay a little
visit to the barracks of the sacred
pegasus knights!$K    $R�㉺��b|$c0IKE|$s0Hey, $w2you!$w4 Why don't you lay down
your weapons and walk out of here
with your lives?$K$PYou can posture as much as you
want,$w2 but there's no way you can
beat us!$K
$c1GASIRAMA|$s1Shut it!$w4 I don't know why you're
here, $w2but if we lose our cargo, we
lose everything! $w2It ain't happening!$K
$s0In that case, $w2we've no choice.$w4
You'll receive no mercy from us!$K   $R�㉺��b|$c0GASIRAMA|$s0They... $w1They're crushing us...$w4
They're nothing but a pack of rats,
but they fight like demons!$K$FS$PHar har! $w2But$w4 no matter how
tough they are, there's no way $w2they
can stand up to a real monster!$K$PHey!$w3 You there!$w4 Release
the feral!$K$PHar har har!$w4 Now, all we have to
do is sit back and watch 'em chew
their heads clean off!$K  $R�w�i��b|$B����-��-��|$<$F2$FCL_GASIRAMA|$F2$PThey... $w1They're crushing us...$w4
They're nothing but a pack of rats,
but they fight like demons!$K$FS$PHar har! $w2But$w4 no matter how
tough they are, there's no way $w2they
can stand up to a real monster!$K$PHey!$w3 You there!$w4 Release
the feral!$K$PHar har har!$w4 Now, all we have to
do is sit back and watch 'em chew
their heads clean off!$K    $R�㉺��b|$c0MARCIA|$s0B-$w2B-$w4-Brother?!$K
$c1MAKAROV|$s1Hey, $w2$FSMarcia!$w4 Heh... Hey,$w2 long time,
huh?$K Good timing, though! I was just
thinking$w2 about paying you a visit, Sis.$K
$s0Long time? $w2Long time?!$w3
You dungheel!$w4 Where in the
name of heaven $w2have you been?$K$PYou racked up all that debt and then
ran away? $w2You're such an
irresponsible skunk!$K$PThanks to your worthless hide,$w2
I had to leave the sacred
pegasus knights!$K
$s1$FA$s1Huh?$w4 But why?$K
$s0Because $w2there were a bunch of
debt collectors hanging around the
barracks!$w4 That's why!$K
$s1$FS$s1Oh, $w2that's... That's a shame.$K$PListen, $w2I was trying to increase
the money I borrowed and pay off the
original, but it,$w4 um...$w4vanished.$K$PAnd I swear that just kept happening!$w3
I'd almost get enough and then...$w3poof!$w4
Gone!$w4 Ha ha!$w4 Ha? $w6Hmm...$K
$s0$FcYou rat.$w5 You cheese-eating rat!
You haven't changed at all...$w4
$FdLet's go. $w1You're coming with me.$K
$s1With $w2you...$w4 Where are we going?
What am I going to do?$K
$s0You're joining my company.$w4 I'm
going to let Ike beat some sense
into you.$w2 We'll see how that works.$K
$s1$FANo, $w2wait... $w2I'm working for these
guys at the moment, and...$K$PWell, if I just up and joined with the
other side,$w3 it might cause problems--$K
$s0$FhSTUFF IT, SPONGE-BRAIN!!!
NO MORE LAME EXCUSES!!!$w3
FOLLOW ME!!!$w4 NOW!!$K
$s1Sorry, Sis! Sorry!$w2
I'm coming...$K $R�w�i��b|$B���Ƃ̓���|$<$F1$Fh$F1$FCL_CALILL|$F1$POh...bother.$w4 Buying all these
things is well and good, but I
simply can't carry it all.$K$PAnd where's Largo?! $w2He leaves me
in this backwater burg and wanders off
to goddess only knows where...$K
$F4$FCLME|$F4$PHello?$K
$F1$P$Fd$FSOh, you there!$w4 Today's your lucky day.
You've arrived at just the right time.$K$PI have something nice to give you.$w2
I just got back from a shopping spree, and
I got this as a free bonus of sorts.$K$POh, please, $w2no need to thank me.$w4 When
you're a sophisticate like me, you never$w3
want for trinkets.$w4 Or men, for that matter.$K$PWell, toodle-doo, then!$w4 Be sure to treasure
that $w2for the rest of your days!
Now...$w5which way to the nearest city?$K $R�w�i��b|$B���Ƃ̓���|$<$F1$FCL_GIRL|$F4$FCLME|$F1$PI found this in the river. But...$w3my mom said
it was dirty,$w2 and I had to throw it away.$K$PDo you...$w2 Do you want it?$K$FS$PReally?$w3 All right, you can have it.
Take care of it, please.$K  $R�w�i��b|$B���Ƃ̓���|$<$F1$FCL_GRANDMA|$F4$FCLME|$F1$PEH? DID YOU SAY CATTLE? $w2...$w4A BATTLE?$w4
STRANGER? $w2WHAT? $w2...$w4OH, DANGER!
GOODNESS!$w3 WHAT AM I TO DO?$K$POh, $w2maybe this will help, dearie.$w4
It's$w3 just lying here collecting dust...$w4
Just like me...$w4 Never a visitor...$K$PAnyway, I don't know what it does, but...$w4
it's pretty.$w4 If I gave it to my grandkids,
they might write once in a while...$K$PHERE! TAKE IT!$w4 NOW DO ME A FAVOR$w2
AND PROTECT MY HOUSE,$w4 ALL RIGHT?
...$w4NO, MY HOUSE!$w5 ...A MOUSE?! WHERE?!$K   $R�㉺��b|$c0MAKAROV|$s0Are you a mercenary too?$w4
It's a tough life being a warrior for
hire, isn't it?$K$PI don't like having to do this, but...$w4
I must pay off my debts, $w2or my
sister will have my head.$K   $R�㉺��b|$c0MAKAROV|$s0Wha...$w2what?$w4
You... $w2Could it be...$K
$c1MARCIA|$s1Huh?$w4 I don't believe it!$w3
Is that you, Makalov?$K   $R�㉺��b|$c0MARCIA|$s0$FhBrother...$w4 Wh-$w2why...$K
$c1MAKAROV|$s1$FoMarcia!$w3 Hold on!$w4
Please... $w2Don't die on me...$Fc$w2
MARCIA!!!$K   $R�㉺��b|$c0MAKAROV|$s0Ah, $w2forgive me, Marcia...$K $R�㉺��b|$c0LETHE|$s0H-$w2hey!$w4 You're a Gallian!$w4
Why are you guarding these humans?$K
$c1TIGERM|$s1Grraaaooowwwrrr!$w3$K
$s0You...$w4are not sane, are you?$w5
What have these human scum
done to you?$K
$s1Grraaoowwrr!$w4
Grrraaaooowwwrrr!$K
$s0Ah, my poor laguz brother...
I will destroy you myself...$w3
and end your pain.$K    $R�㉺��b|$c1MORDY|$s1You are like me. You are laguz.$w4
A brother tiger, you are.$K$P$c0TIGERM|$s0Grrraaaooowwwrrr!$K
$s1But...$w2you seem mad...$w3
You do not $w2recognize a friend.$K
$s0Graaaoowwwrr!$w4
Grrraaaooowwwrrr!$K
$s1I must end this.$w4 I am sorry.$K $R�㉺��b|$c0GASIRAMA|$s0You... $w2You're just like us!$w2
You eat meat, $w2you ride horses...
I mean, come on!$K$PWe're not hurting any humans here!$w4
What's wrong with buying and
selling a few half-breeds?$K $R�㉺��b|$c0GASIRAMA|$s0Trying to steal our cargo...$w3
You're no better than us!!$K$PSome of our customers are nobles!$w4
You won't get away with this
unscathed,$w2 let me tell you!$K
$c1IKE|$s1What? $w2Nobles?$K
$s0Don't play dumb with me!$w4
Take this!$K $R�㉺��b|$s0$FS$c0GASIRAMA|$s0A female... $w2Females are good.$K
You'll fetch a high price$w2
to the right buyer.$K
$s1$Fh$c1LETHE|$s1...I hate humans.$w4 But you are beyond
that word. $w2Simply killing you $w2won't
be enough.$K$PThe pain, $w2the suffering of my
brethren...$w3 I will carve payment for
that from your flesh!$K    $R�㉺��b|$c0GASIRAMA|$s0Gulp!$w4 Tiger! Tigers $w2are dangerous!$w4
I've got to trick it $w2into drinking
the medicine...$K
$c1MORDY|$s1Ggrrraaaooowwwrrr!$K  $R�㉺��b|$c0GASIRAMA|$s0How did this happen?$w4
I've lost everything...$K $R�㉺��b|$c0IKE|$s0Our duty is done.$w4
Let's grab the cargo $w2and
get out of here!$K    $R�w�i��b|$B��̒�|$<$F3$FCL_IKE|$F3$PThe Greil Mercenaries $w2have returned.$K
$F1$FS$F1$FCL_SIGRUN|$F1$PWell done.$w4 The news of your victory is
welcome, as is the cargo you seized.$w4
Now, $w2about your payment...$K
$F3$PWait.$w4 This mysterious cargo was a
bunch of really heavy crates...$w3 Would
you tell me $w2what they contained?$K
$F1$P$FAThat--$K
$F0$FCL_TANIS|$F0$PYour job $w2was to deliver the cargo.$w4
You've no need to investigate further.$K
$F3$PBut--$K
$F0$PPrincess Elincia$w4 has returned to her
quarters.$w4 You would do well to inform
her$w3 of your safe return.$K$F0$FD
$F3$P...$K
$F1$P$FSIt appears $w2that the apostle will
handle your payment on the morrow.$w4
Perhaps you can speak with her then.$K
I beg your leave.$w2 I must be going.$K$F1$FD
$F3$PVery well.$K
$=1100   $R�w�i��b|$B�S���h�A��c��|$<$F0$FCL_CAINEGHIS|$F0$PThank all of you for coming,$w3
my fellow $w2laguz kings.$K$PIt's been decades since all of us$w3
were gathered $w2in one place.$K$PI would extend my gratitude to$w2
King Deghinsea of Goldoa, who$K
arranged this meeting place at short notice.$K
$F4$FCL_DHEGINHANSEA|$F4$P$FcIt was nothing, King Caineghis.$K$F4$FD
$F0$PFellow kings and countrymen,
attend to my words!$K$PAs you no doubt have heard,$w3 Daein has
invaded Crimea$w4 and overrun her.
Of course, $w2Crimea is a beorc nation...$K
However,$w4 since the time of her founding,
she has made every effort to engage
the laguz with honor and dignity.$K$PNever has this been more true$w2
than during the thirty-year reign
of good King Ramon.$K$PDuring this era, $w2Gallia and Crimea initiated
many ambitious cultural projects in an
attempt $w2to bring our divided people closer.$K$PYet one man$w3 has always reviled our work...$w5
The Daein king,$w4 Ashnard.$w3 Why he took
this recent course,$w2 however...$w3I know not.$K$PAshnard's actions are monstrous. $w2His army
has put much of Crimea to the sword. Her
people live in terror.$w4 Her king lies dead.$K$PAnd now,$w3 the Daein forces continue their
ruinous march $w2and cross the border$w3
into laguz territory...$w4 Into Gallia.$K
$F4$FCL_TIBARN|$F4$PThat trespass,$w2 O king of lions, $w5is
because your country chooses to harbor
King Crimea's orphan.$w4 Is it not?$K
$F0$PYes, that is the justification they
would present.$K
$F4$PBut the princess of Crimea is no
longer in Gallia, $w2is she?$K
$F0$PYour spies are as efficient as ever, $w2King
Tibarn of Phoenicis.$w4 As you say, the
princess has already departed for Begnion.$K
$F4$PI know this $w2only because she came$w2
to the aid of $w2a ship carrying
Begnion's apostle.$K
$F0$P$FSAh! $w2So Princess Elincia is safe and
in contact with the Begnion Empire?
That news gladdens my heavy heart.$K
$F4$PI do not believe that Daein yet has
this information.$K$PIf word got out that the princess of Crimea
has been granted sanctuary in Begnion,
Daein might halt its invasion of Gallia.$K
$F0$FD$F1$FS$F1$FCL_NAESALA|$F1$PYour information is dated, hawk king!$w4
Have your legendary eyes and ears
abandoned you after all these years?$K
$F4$PYou have something you wish to say?$K
$F1$FD$F0$FCL_CAINEGHIS|$F0$PWould you be so kind as to explain
yourself,$w4 King Kilvas?$K$FD
$F1$FS$F1$FCL_NAESALA|$F1$PPrincess Elincia $w2barely escaped Crimea
with her life $w2and then fled to Gallia.$K$PAnd yet a certain king of beasts there,
one on whom she had pinned all hope,$w2
chose not to support her.$K
$F1$FD$F0$FCL_CAINEGHIS|$F0$P...$K
$F0$FD$F1$FS$F1$FCL_NAESALA|$F1$PWith nowhere else to turn, $w2the princess
and her retinue $w2spent two long months
at sea,$w4 arriving in Begnion mere days ago.$K$PDaein $w2knows of these events as well,
and the king has dispatched a team of
hunters to make a corpse of the girl.$K$PAnd that, dear kings, is the latest news...$w4
At least, to the best of my poor knowledge.$K
$F1$FD$F0$FCL_CAINEGHIS|$F0$PDaein knows the princess is in Begnion?!$w3
King Kilvas, $w2how did you come to possess
this information?$K
$F0$FD$F1$FS$F1$FCL_NAESALA|$F1$PWhy, there's no trick to it.$w4
I just perk up my ears and...$w4
point them in the right direction.$K
$F4$PYou expect us to believe that a
stray wind carried it to your ears?$w2
This is an odd tale, $w2Naesala.$K
$F1$PHmm?$w2 Do you think so?$w4 Well, there
is one trick to information gathering that
I know.$w4 Shall I share it with you?$K
$F4$PIf it involves dealing with human scum,$w2
I'll pass. Forgoing my laguz pride is not$w2
something I'm willing to do.$K
$F1$P$FAHa!$w4 Is that not always the way of
Phoenicis,$w2 to cling to those last tattered
remnants of pride?$K$P$FSInstead of proclaiming that you will attack
none but Begnion ships,$w3 just admit that
you don't have the power to do more!$K
$F4$PWhat did you say?$K
$Ub$H$F4$FD$F4$FCL_DHEGINHANSEA|$F4$PBoth of you will desist at once!$K
$Ub$H$F4$PKing Naesala of Kilvas,$w4 your actions of
late $w2can indeed be judged$w2
as too extreme.$K
$F1$PBlack Dragon King of Goldoa, $w2what
do you pretend to know of my actions?$w4
Please, $w2enlighten me.$K
$F4$PI would remind you $w2of the beorc ship
you attacked in Phoenicisian waters...$w2
and left stranded in Goldoan territory.$K
$F1$P$FAOh...$w3that.$K
$F4$FD$F3$FCL_TIBARN|$F3$PNaesala, $w2you lying crow!$w4
You've been sneaking $w2about in my
territory again, have you?$K$FD
$F4$FCL_DHEGINHANSEA|$F4$PI heard from my own son, Kurthnaga,$w2
that a beorc resembling Princess
Crimea was on board that ship.$K$P$F3$FCL_KURTHNAGA|$F3$PIt is true.$K$FD
$F1$FD$F0$FCL_CAINEGHIS|$F0$PWhat?$w4 King Kilvas, $w2you...$K
$F0$FD$F1$FCL_NAESALA|$F1$PDon't act surprised!$w3 I have no intention
of ruling some tiny island nation forever.$w4
I will make Kilvas a name to remember!$K$PTo that end, $w2no amount of gold is enough.$w4
Laguz or beorc, I care not. If the pay is
right, there's nothing I won't do.$K
$F4$PI care not about the reach of your
ambition, but $w2you should choose
your methods with more care.$K$PWhat good will it do you to expand
your domain only to find enemies
at your every border?$K
$F1$PI will take your words to heart$w4
for the time being.$K$FD
$F1$FCL_TIBARN|$F1$P$F4$PAnd you, too, $w2King Phoenicis.$w2
What good will your piracy do you if
it earns the wrath of Begnion?$K$PContinue at this pace, and there's no
telling when the hostilities will end.$K
$F1$PUntil the people of Begnion apologize
for the slaughter of our brother herons,$w4
I will do no such thing.$K
$F0$FCL_RIEUSION|$F4$PPrince Reyson of Serenes?$w2
Are you of the same mind?$K
$F0$PThose humans burned Serenes Forest$w2
and killed my people.$w4 No amount of human
blood can slake my thirst for vengeance.$K$PFor my siblings, $w2for my countrymen,$w4
I demand justice.$w4 I cannot even return my
bedridden father to our forest home!$K$PI am no soldier. I know nothing of war,$w2 so
King Phoenicis acts in my stead.$K$PI am most grateful to him,$w3 and I would
not see him stop until Begnion has paid.$K
$F4$PBlood leads only to blood,$w3 and violence
begets violence. Nothing more.$w5 Revenge
is simply another name for murder.$K
$F0$P...$K$F0$FD$F1$FD$F0$FCL_CAINEGHIS|
$F4$PAnd you,$w4 king of lions?$w4
What will you do about
your home of Gallia?$K$PNow that you know Daein's feint toward
Gallia $w2is merely another move in his
game of war,$w4 how will you act?$K
$F0$PThey've made no formal declaration of war.
Until they do, we watch and wait.$K
$F4$FD$F3$FCL_TIBARN|$F3$PIf it's the first step towards eradicating
all human scum,$w3 Phoenicis will help
you destroy Daein.$K$P$F0$PNo. $w2Unless this becomes a true war
among all nations, I want you to stay
your hand.$K$PAs long as Gallia is protected by
the sea of trees,$w2 we can
stave off Daein's attacks.$K
$F3$FD$F4$FS$F4$FCL_NAESALA|$F4$PAh, the luxury of a large nation!$w4 You would
waste a chance to expand your territory$w2
just to maintain the status quo?$w4 Sad.$K$FD$F0$FD
$F2$FCL_DHEGINHANSEA|$F2$PI agree with King Gallia.$K$PIf we were to form a laguz alliance against
Daein,$w3 we would drive Begnion to Daein's
side and lose a valuable ally.$K$PThe flames of war cannot be fanned
haphazardly. Above all, we must think of
Lehran's Medallion.$w4 Its location is unknown...$K$PBut it still exists. We know this. And as
long as it does, we cannot allow any war
that could stand to engulf all our nations!$K$PDo you understand, $w2laguz kings?$w4
I beg of you, do not forget it.$K  $R�w�i��b|$B���-����-�x�O�j�I��|$<$F1$FS$F1$FCL_MAID|$F3$FCL_IKE|$F1$PPsst!$w3 You wanna hear somethin'?$K
There's a rumor going 'round that a$w4
tiger sub-human has been seen on the
foggy banks of this very river!$K
$F3$P...$K
$F1$P$FAEh, wot?$w3 You don't seem surprised!$K
All right then, $w2how about this?$K$PThat sub-human?$w3 They say it's ALWAYS
in beast form!$w3 It can't change back!
Right frightening, ain't it?$K
The only way$w4 for us humans $w2to
fight them savages$w4 is to wait for 'em
to change $w2out of beast form.$K$PI mean, how can we kill 'em$w4
if they won't change?$K
$F3$P...$K
$F1$PStill no reaction, eh?$w4 What a bore!$w5$FS
'Owzabout this juicy morsel, then?$w3
Was saving it, I was, but...$K$FA$PI 'eard from my darling in the army,$w3
that tigers, cats, $w2and other four-legged
sub-humans$w3 HATE fire magic.$K$FS$PThat's a useful tidbit, ain't it?$w4
Oh, I knows things!$K
$F0$FCL_LADY1|$F0$PYou there! Serving wench...$w3
There's work to be done. Why are
you wasting time chatterin' on?$K
$F1$PWha-$w2what's wrong?$w3
Just $w2saying 'allo to one of
the new servants is all!$K
$F0$PYou fool!$w3 This is no servant!$K
$F1$P...Aye?$w3 ...Oy? $w5...Eh wot?$w4
Oh, crickey! $FA$w3Princess Crimea's $w2escort...?$K$PA guest of the apostle...?!?$w4
Oh, $w2ohnoohmygosh!$w5
Please...$w1 Please $w2forgive me!$K
$F3$P...$K$F3$FD
$F1$PWha-$w2what should I do?$w4
Ooo, he looked right angry, he did!$w4
I might get sacked!$K   $R�w�i��b|$B��̒�|$<$F1$FS$F1$FCL_GATRIE|$F1$PWell,$w3 if it isn't Ike!$w4
Out for a walk, Commander?$K
$F3$FCL_IKE|$F3$PHello, Gatrie.$w4 Yeah, if I stay in that
horrible, gaudy room for too long,$w2
I start$w3 to feel depressed.$K$PIs that why you're out here, too?$K
$F1$PNo,$w3 I'm here for different reasons.$w4
I'm just...$w4admiring the flowers.$K
$F3$POh, right. Yes, they all seem to be in
bloom this time of year.$w3 The large
yellow ones are especially pretty.$K
$F1$PNot those flowers...$w5
THOSE flowers!$K
$F3$P...$w4Gatrie, we're inside. There's nothing
here but the temple handmaidens.$K
$F1$PExactly!$w4 It's like a whole new species
of girl lives in Begnion!$w3 Everyone in
this palace is drop-dead gorgeous!$K
$F3$P$Fc...$K$F3$FD
$F1$PYou know what I mean, Ike? Tee hee!$w4
Say, which one strikes your fancy?$w4 That
buxom lass with the chestnut hair is...$K$PHey,$w3 Ike? $w5Ike?$w5 Bah!$w4
He's still just a boy!$K   $R�w�i��b|$B���-��|$<$F3$FS$F3$FCL_STELLA|$F3$PUm,$w3 Commander Ike?$K
$F1$FCL_IKE|$F1$PHm?$w4 Oh, $w2it's you.$K
$F3$PAre you trying to clear
your head as well?$K
$F1$PYeah, $w2I guess so.$w4 I'm just
walking $w2and thinking about things.$K
Begnion is so...$w2odd.$w3 I don't
understand this country at all.$K
$F3$P$FAMm...$w2I can see that.$K$PEverything's so wrapped up in form
and tradition,$w4 it feels like Begnion
has lost track$w4 of more important things.$K
$F1$PYou're $w2some noble house's daughter,
are you not?$w4 What made you
decide to become a knight?$K
$F3$PTo escape my royal family...$w3 No,$w3
not to escape...but to confront it.$w4
I want my life to be my own.$K
$F1$PHow do you like being a knight?$K
$F3$PI$w5 am still not satisfied. I may now
be a knight, but my hands still shake
when I draw my bowstring.$K$PSo perhaps my goal was not simply
to become a knight. Perhaps my true
goal was to become stronger.$K$PCommander Ike, the others say that you
never give up, no matter how bleak the
fight. That seems like true strength to me.$K$PPlease,$w4 allow me to continue fighting
by your side. If I remain with you,$w2
I will grow stronger from your example.$K
$F1$PYour skill with the bow $w2is spectacular.$w4
How could I possibly refuse your request?$w4
$FSWe're pleased to have you.$K
$F3$P$FSOh...$w2thank you!$w4
Thank you very much!$K   $R�w�i��b|$B���-����-�x�O�j�I��|$<$F1$Fc$F1$FCL_MARCIA|$F1$PAaaaahhhh...$K
$F3$FCL_IKE|$F3$PThat was quite a sigh.$K
$F1$P$FdHuh?$w4 Aw, nuts!$w4 You heard that, handsome?
Sorry about that.$K
$F3$PYou've been behaving oddly lately.$w4
Something happen?$K
$F1$PPfff! I'm fine!$w3 It's just...$w4
Well, being here in Begnion is...$w2
difficult, you know?$K
$F3$PDifficult?$w4 You were a member of the$w2
pegasus knights here, weren't you?$K$PAren't you happy to see some
of your old friends?$K
$F1$PNo, I'm not happy!!$w4$Fc
It's... $w2It's so blasted embarrassing!$w3
I can't bear to face them!$K
$F3$PWhat?$K
$F1$P$FdI've told you why I resigned my
knighthood, haven't I?$K
$F3$PYes, you're searching for your brother.$K
$F1$PIt's my brother's fault...$w4 I...$w3 I...
$FA$w4Aaargh! That no-good chum bucket!$K
$F3$PUm...$w4maybe we should just drop it.$K
$F1$P...$w3Huh? Oh, no it's--
Don't worry. I'm fine.$K
$F3$PDon't let it get to you too much. I don't
want you distracted in a fight, all right?$K
$F1$PGot it.$w4 Thanks.$K$F3$FD
$F1$PIke's a brother, too... So why is he
so different from my brother?$K
$FcGrrr! Lazy do-nothing!$K  $R�w�i��b|$B���-����-�x�O�j�I��|$<$F1$FCL_SENERIO|$F3$FCL_IKE|$F1$PIke,$w3 here's a summary of our last battle.$K$N$UB$H  $F3$P$Fc...$K$P$UB$H    $F1$P$FSThere were no casualties,$w2 and no one
suffered permanent injury.$w4
We fought excellently.$K$P$UB$H   $F1$PThat's all I have to report.$w4
If you'll excuse me.$K   [�      \�   	  ]�     W0   "  X   3  ^�   F  Z�   R  Y`   g  _|   |  Y(   �  X�   �  _�   �  `$   �  cD   �  F�   �  I�   �  Hd   �       �   �    �    ��    �l  +  �  9  �p  G  t  U   �  a  *@  m  /�  y  3  �  8X  �  =�  �  ?4  �  B�  �  ��  �  �`  �  ��  �  �x  �  Kt    Q    T    U  *MS_15_BT MS_15_BT_IKE MS_15_BT_LE MS_15_BT_MAKAROV MS_15_BT_MAKAROV_M MS_15_BT_MO MS_15_BT_MORDY_TIGER MS_15_BT_RETHE_TIGER MS_15_DIE MS_15_DIE_MAKAROV MS_15_DIE_MARCIA MS_15_ED_00 MS_15_ED_01 MS_15_ED_02 MS_15_EV_01 MS_15_EV_02_HM MS_15_EV_02_N MS_15_GMAP_1 MS_15_GMAP_2 MS_15_GMAP_3 MS_15_INFO_02 MS_15_INFO_03 MS_15_INFO_04 MS_15_INFO_05 MS_15_OP_01 MS_15_OP_02 MS_15_OP_03 MS_15_OP_04 MS_15_OP_05_A MS_15_OP_05_B MS_15_OP_06 MS_15_OP_X MS_15_OP_X2 MS_15_REPO_BEGIN MS_15_REPO_DIE MS_15_REPO_END MS_15_REPO_NODIE MS_15_TK_01 MS_15_VIL_01 MS_15_VIL_02 MS_15_VIL_03 