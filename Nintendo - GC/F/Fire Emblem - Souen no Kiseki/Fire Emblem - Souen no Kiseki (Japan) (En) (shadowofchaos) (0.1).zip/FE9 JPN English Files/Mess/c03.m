  �  �X       6                $R�w�i��b|$B����-��|$<$F1$FS$F1$FCL_KILROY|$F3$FCL_TIAMAT|$F1$POh, $w2Titania.$w4 So this is where
you've been, is it?$K
$F3$PRhys!$w4 Are you sure you're well
enough to be up?$K
$F1$PYes.$w4 My fever's completely gone.$K
$F3$PAre you sure?$w4 You still look a bit
unsteady on your feet if you ask me.$K
$F1$PWell,$w3 I've been in bed for almost
a week.$w4 I doubt anyone would be
in top form$MC--$MDeven you, my friend!$K
$F3$P$FSI certainly hope that's all it is.$w4
In any case, $w2until you're back at
full speed, you won't be doing any work.$K$PWe're mercenaries, after all, and$MC...$MD$K
$F1$P"Even the smallest lapse invites death."$w3
Right?$w4 I know, I know.$K$PMy apologies to the rest of the team, then.$w2
It looks like I'll be recuperating for a
while longer.$K
$F3$PMm, $w2it's for the best.$w4 Take your time
and get fully rested and restored.$K$PYou are our sole staff wielder, $w2Rhys$MC...$MD$w3
The harder our work, $w2the more we
depend on you to be at our sides.$K
$F1$PThank you for your kind words.$K
$F3$POh, by the way$MC...$MD$w4 That paper you've
been carrying around$MC...$MD$w2 Is it a letter?$K$PI'd intended to go into town this afternoon.
I can deliver it for you if you like.$K
$F1$POh, $w2no.$w4 This letter is for
you, Titania.$K
$F3$P$FAFor me?$K
$F1$PNot more than a little while ago, $w2I went
out for a walk around the yard and$MC...$MD$K$PA man I've never seen before came up
to me and said$MC...$MD$w3
"Give this to the red-tressed knight."$K
$F3$PHow curious$MC... $MDI wonder what it is.$K
$F1$PI imagine it's a thank-you letter from
the people of Caldea$w3 or something
to that effect.$K  $R�w�i��b|$B����-��|$<$F1$FCL_KILROY|$F3$FCL_TIAMAT|$F3$POh, no!$w4
How dare they!?$K
$F1$PTitania?$w4 What's the matter?$w4
What did the letter say?$K
$F3$P$MC...$MDRhys!$w4 Take this letter to
Oscar,$w2 and tell him to prepare
for combat and wait for me!$K$PI have to go out for a moment.$K$F3$FD
$F1$PUh, $w2but, $w2Titania?$K
$F4$FCL_TIAMAT|$F4$PI'll be right back!$w4
I'm counting on you!$K$P$F4$FD$w6$F1$PWhat on earth could that
letter have said?$K    $R�w�i��b|$B����-��|$<$F1$FCL_KILROY|$F3$FCL_TIAMAT|$F3$POh, no!$w4
How dare they!?$K
$F1$PTitania?$w4 Wh-what is it?$w4
Is it dire news? What did the
letter say?$K
$F3$P$MC...$MDRhys!$w4 Take this letter to
Ike.$w2 Tell him to prepare for combat
and wait for me here!$K$PI have to go out for a moment.$K$F3$FD
$F1$PUh, $w2but, $w2Titania?$K
$F4$FCL_TIAMAT|$F4$PI'll be right back!$w4
I'm counting on you!$K$P$F4$FD$w6$F1$PWhat on earth could that
letter have said?$K    $R�w�i��b|$B�A�W�g-�H��-��|$<$F1$FCL_KILROY|Everyone!$w4 Come quickly!$K
$F3$FS$F3$FCL_BOLE|$F3$PHey, $w2Rhys.$w4
So, $w2how are you feeling?$K
$F4$FCL_OSCAR|$F4$PWhat is it? $w2Why are you so agitated?$K
$F0$FCL_IKE|$F0$PHas something happened?$K
$F1$PIt's Mist and Rolf$MC...$MD$w4
They$MC... $MD$w2They've been taken by bandits!$K
$F3$P$FAWhat?!?$K
$F0$PWhat are you talking about?$K
$F4$PThe two of them went out early this
morning $w2to gather wildflowers$MC...$MD$w4
Sure, $w2they're not back yet, but$MC...$MD$K
$F1$PEarlier, $w2by the gate$MC...$MD$w3a man asked
me to deliver a letter to Titania.$w5
It was from a group of bandits$MC--$MDkidnappers.$K$PWhat are we going to do?$K
$F4$PLet me see it.$K
$F1$POh, if only I'd known$MC...$MD$w4
He didn't seem like a bad person$MC...$MD$K
$F4$PHm. I get it.$w4 They're after revenge.
They want retribution for the other
day at that village$MC... $MDCaldea, was it?$K$PHm. $w2Taking children as hostages?$w4
What cowards!$K
$F0$PBlast!$K$F0$FD
$F3$PWait,$w4 Ike!$w5
Where$MC... $MD$w2Where do you think
you're going?$K
$F0$FCL_IKE|$F0$PI'm going to get Mist!$K
$F1$PBut$MC...$MD$w2 No!$w3 Titania$MC...$MD$w4
She said she'd be right back. $w2You're
supposed to get ready and wait for her$MC...$MD$K
$F0$PAnd do you honestly think we've got
time to wait?$w4 I'm going!$K$F0$FD
$F3$PWhat do you think you're going to
do on your own, $w2rookie?$w4
Hold it!$w4 I'm going, too!$K$F3$FD
$F1$PStop! $w2Both of you!$w4
I$MC...$MD$w2I'm going with you.$K$F1$FD
$F4$POh, $w2c'mon! $w2Wait!$w5 This is
crazy! $w2Do you think you can just
ignore the deputy commander's orders?$K
$=0500    $R�w�i��b|$B�A�W�g-�H��-��|$<$F1$FCL_KILROY|Ike!$w4 Come quickly!$K
$F3$FCL_IKE|$F3$PWhat is it, $w2Rhys?$w4
Why the panic?$w4 Has something happened?$K
$F1$PIt's Mist and Rolf$MC...$MD$w4
They$MC... $MD$w2They've been taken by bandits!$K
$F3$PWhat are you talking about?$K
The two of them went out early this
morning $w2to gather wildflowers$MC...$MD$w4
Sure, $w2they're not back yet, but$MC...$MD$K
$F1$PEarlier, $w2by the gate$MC...$MD$w3a man asked
me to deliver a letter to Titania.$w5
It was from a group of bandits$MC--$MDkidnappers.$K$PWha-$w2what are we going to do?$K
$F3$PLet me see it.$K
$F1$POh, if only I'd known$MC...$MD$w4
He didn't seem like a bad person$MC...$MD$K
$F3$PIf they want a rematch after what
we did to them at Caldea,$w3 they're
going to get one.$w4 Filthy bandits!$K$F3$FD
$F1$PHey!$w4 Ike?$w5
Where$MC... $MD$w2Where do you think
you're going?$K
$F4$FCL_IKE|$F4$PI'm going to get Mist!$K
$F1$PBut$MC...$MD$w2 No!$w3 Titania$MC...$MD$w4
She said she'd be right back. $w2You're
supposed to get ready and wait for her$MC...$MD$K
$F4$PAnd do you honestly think we've got
time to wait?$w4 I'm going!$K$F4$FD
$F1$PWait!$w4 I$MC...$MD$w2I'm going, too!$K$F1$FD
$=0500   $R�w�i��b|$B�A�W�g-�H��-��|$<$F1$FCL_KILROY|O-$w2Oscar!$w4 Come quickly!$K
$F4$FCL_OSCAR|$F4$PRhys?$w4 What is it?$w2
Why are you so agitated?$K
$F3$FCL_IKE|$F3$PHas something happened?$K
$F1$PIt's Mist and Rolf$MC...$MD$w4
They$MC... $MD$w2They've been taken by bandits!$K
$F3$PWhat are you talking about?$K
$F4$PThe two of them went out early this
morning $w2to gather wildflowers$MC...$MD$w4
Sure, $w2they're not back yet, but$MC...$MD$K
$F1$PEarlier, $w2by the gate$MC...$MD$w3a man asked
me to deliver a letter to Titania.$w5
It was from a group of bandits$MC--$MDkidnappers.$K$PWha-$w2what are we going to do?$K
$F4$PLet me see it.$K
$F1$POh, if only I'd known$MC...$MD$w4
He didn't seem like a bad person$MC...$MD$K
$F4$PHm. I get it.$w4 They're after revenge.
They want retribution for the other
day at that village$MC... $MDCaldea, was it?$K$PHm. $w2Taking children as hostages?$w4
What cowards!$K
$F3$PBlast!$K$F3$FD
$F4$PHey!$w4 Ike?$w5
Where$MC... $MD$w2Where do you think
you're going?$K
$F0$FCL_IKE|$F0$PI'm going to get Mist!$K
$F1$PBut$MC...$MD$w2 No!$w3 Titania$MC...$MD$w4
She said she'd be right back. $w2You're
supposed to get ready and wait for her$MC...$MD$K
$F0$PAnd do you honestly think we've got
time to wait?$w4 I'm going!$K$F0$FD
$F1$PHold it, $w2Ike!$w4
I$MC...$MD$w2I'm going with you!$K$F1$FD$w4
$F4$POh, $w2c'mon! $w2Wait!$w5 This is
crazy! $w2Do you think you can just
ignore the deputy commander's orders?$K
$=0500   $R�w�i��b|$B�A�W�g-�H��-��|$<$F1$FCL_KILROY|L-listen, $w2everybody!$w4 Come quickly!$K
$F3$FS$F3$FCL_BOLE|$F3$PHey, $w2Rhys.$w4
Tell me, $w2how are you feeling?$K
$F4$FCL_IKE|$F4$PHas something happened?$K
$F1$PIt's Mist and Rolf$MC...$MD$w4
They$MC... $MD$w2They've been taken by bandits!$K
$F3$P$FAWhat?!?$K
$F4$PWhat are you talking about?$K
The two of them went out early this
morning $w2to gather wildflowers$MC...$MD$w4
Sure, $w2they're not back yet, but$MC...$MD$K
$F1$PEarlier, $w2by the gate$MC...$MD$w3a man asked
me to deliver a letter to Titania.$w5
It was from a group of bandits$MC--$MDkidnappers.$K$PWha-$w2what are we going to do?$K
$F4$PLet me see it.$K
$F1$POh, if only I'd known$MC...$MD$w4
He didn't seem like a bad person$MC...$MD$K
$F4$PIf they want a rematch after what
we did to them at Caldea,$w3 they're
going to get one.$w4 Filthy bandits!$K$F4$FD
$F3$PHey!$w4 Ike?$w5
Where$MC... $MD$w2Where do you think
you're going?$K
$F0$FCL_IKE|$F0$PI'm going to get Mist!$K
$F1$PBut$MC...$MD$w2 No!$w3 Titania$MC...$MD$w4
She said she'd be right back. $w2You're
supposed to get ready and wait for her$MC...$MD$K
$F0$PAnd do you honestly think we've got
time to wait?$w4 I'm going!$K$F0$FD
$F3$PWhat do you think you're going to
do on your own, $w2rookie?$w4
Hold it!$w4 I'm going, too!$K$F3$FD
$F1$PWait, $w2both of you!$w4
I$MC...$MD$w2I'm going with you.$K$F1$FD
$=0500   $=0300$R�w�i��b|$B�X�̑O|$<$F3$FCL_IKE|$F4$FCL_BOLE|$F4$PThe road forks here$MC...$MD$w4
Well, $w2which way do we go?$K
$F3$PHow am I supposed to know that?$K
$F4$FD$F1$FCL_BOLE|$F1$PHold it! $w2Are you saying you don't
know where we're going?$K$PUn$w4believable!$w4
You'd better learn to think before you
act, $w2you moron!$K
$F3$PShut your mouth, Boyd!$K
$F1$PYou think you can make me? $w2Come on!$K
$F0$FCL_KILROY|$F0$PB-$w2both of you,$w2
this is no time to be fighting.$K
$F4$FCL_OSCAR|$F4$PI figured we'd find you like this.$K
$F1$PWhat are you two doing?$K$PSo you're coming after all?$w2 It's not
like you two chambermaids to be disobeying
orders.$w4 What's the world coming to?$K
$F3$POscar, you know this road, don't you?$w4
Which way do we go?$K
$F4$PYou're going to the bandit stronghold,
right?$w2 It's the left fork.$K
$F3$PGot it!$K$F3$FD
$F1$PI'm still talking here!$w2
Let me finish what I$MC--$MD$K
$F0$PCome on, Oscar. $w2Let's go, too!$K
$F4$PI guess we've no choice.$K
$F0$FD$F4$FD$F1$PUh$MC...$MD$w2 HEY!$w4
You're not leaving me behind!$K
$=0500  $=0300$R�㉺��b|$s0$FS$c0IKANAU|$s0So you came, $w2did you, boys?$K$PIs it just you, then? You came alone?$w2
You seriously underestimate what
we're capable of doing to you.$K$PNow, $w2where's that snobby, red-haired
wench you ride with?$K
$c1IKE|$s1Titania's not here.$w4
It's just us.$K$PAll I want to know right now$w2
is whether Mist and Rolf are safe.$K
$s0Yeah, $w2of course.$w4
We've got 'em locked up safe and
sound in that little shack back there.$K$PWe got no problem with those brats.$K$PWhat we're after $w2is a little revenge.$w4
We want the redhead and her pups.$w4
And that'd be you boys.$K
$d1$c1BOLE|$s1Then hurry up $w2and let those two go!$w4
We're here, aren't we? $w2You've got
no more reason to hold them.$K
$s0You're here, but Red ain't.$w4
We'll just keep the brats$w2
until she arrives.$K
$s1Dang it!$K
$d1$s0If you're so impatient,$w2 I guess
we can start by killing you whelps.$w2
You all ready to die?$K$PHey!$w4 Come on out!$w2
It's time to play, lads!$K    $=0300$R�㉺��b|$s0$FS$c0IKANAU|$s0So you came, $w2did you, boys?$K$PIs it just you, then? You came alone?$w2
You seriously underestimate what
we're capable of doing to you.$K$PNow, $w2where's that snobby, red-haired
wench you ride with?$K
$c1IKE|$s1Titania's not here.$w4
It's just us.$K$PAll I want to know right now$w2
is whether Mist and Rolf are safe.$K
$s0Yeah, $w2of course.$w4
We've got 'em locked up safe and
sound in that little shack back there.$K$PWe got no problem with those brats.$K$PWhat we're after $w2is a little revenge.$w4
We want the redhead and her pups.$w4
And that'd be you boys.$K
$s1Then hurry up $w2and release them!$w4
We're here, aren't we? $w2You don't
need hostages anymore.$K
$s0You're here, but Red ain't.$w4
We'll just keep the brats$w2
until she arrives.$K
$s1Dang it!$K
$d1$s0If you're so impatient,$w2 I guess
we can start by killing you whelps.$w2
You all ready to die?$K$PHey!$w4 Come on out!$w2
It's time to play, lads!$K  $R�㉺��b|$c3KILROY|$s3There$MC... $MD$w2There are so many$MC...$MD$w4
But$MC...$MD$w3we must not lose!$K
$c1OSCAR|$s1Rhys, $w2move to the rear!$w5
If anyone gets injured, $w2we'll need
you on hand with your staff.$K
$s3Understood!$K
$d1$d3$w5$s0$FS$c0IKANAU|$s0Take 'em, $w2lads!$w4
Without the red-haired knight,$w2
they're no match for us!$K
$c3BOLE|$s3What'd you say, $w2dirtbag?$K
$c1IKE|$s1We'll make you regret those words!$K   $R�㉺��b|$c3KILROY|$s3There$MC... $MD$w2There are so many$MC...$MD$w4
But$MC...$MD$w3we must not lose!$K
$c1IKE|$s1Rhys, $w2get back!$w5 I'll take the
lead,$w4 but if I get hurt, $w2I'll need
you to heal me with your staff.$K
$s3Understood!$K
$d1$d3$w5$s0$FS$c0IKANAU|$s0Take 'em, $w2lads!$w4
Without the red-haired knight,$w2
they're no match for us!$K
$c1IKE|$s1I'll make you regret those words!$K   $R�㉺��b|$c3KILROY|$s3There$MC... $MD$w2There are so many$MC...$MD$w4
But$MC...$MD$w3we must not lose!$K
$c1OSCAR|$s1Rhys, $w2move to the rear!$w5
If anyone gets injured, $w2we'll need
you on hand with your staff.$K
$s3Understood!$K
$d1$d3$w5$s0$FS$c0IKANAU|$s0Take 'em, $w2lads!$w4
Without the red-haired knight,$w2
they're no match for us!$K
$c1IKE|$s1We'll make you regret those words!$K    $R�㉺��b|$c3KILROY|$s3There$MC... $MD$w2There are so many$MC...$MD$w4
But$MC...$MD$w3we must not lose!$K
$c1IKE|$s1Rhys, $w2get back!$w5 I'll take the
lead,$w4 but if I get hurt, $w2I'll need
you to heal me with your staff.$K
$s3Understood!$K
$d1$d3$w5$s0$FS$c0IKANAU|$s0Take 'em, $w2lads!$w4
Without the red-haired knight,$w2
they're no match for us!$K
$c3BOLE|$s3What did you say, $w2dirtbag?$K
$c1IKE|$s1We'll make you regret those words!$K   $R�w�i��b|$B�q��|$<$F3$Fc$F3$FCL_LOFA2|$F1$FCL_MIST|$F3$POh$MC...$MD$w3sniff$MC...$MD$K
$F1$PKeep your chin up, $w2Rolf!$w4
Boys aren't supposed to cry!$K
$F3$P$FdBut$MC...$MD$w3I'm so scared$MC...$MD$w4
Aren't you$w3 even a bit scared, $w2Mist?$K
$F1$POf course I am, but$MC...$MD$w4$FS
Listen, $w2we'll be fine!$w4 My brother$w2
will definitely come rescue us.$K
$F3$P$FSMm$MC...$MD$w2yeah.$w4 You're right!$w4
And I'm sure that my brothers$w2
will be right there with him.$K
$F1$PI'm sure they will, too!$w4
So no more crying!$w3 Got it?$K
$=0300  $R�w�i��b|$B�q��|$<$F3$Fc$F3$FCL_LOFA2|$F1$FCL_MIST|$F3$POh$MC...$MD$w3sniff$MC...$MD$K
$F1$PKeep your chin up, $w2Rolf!$w4
Boys aren't supposed to cry!$K
$F3$P$FdBut$MC...$MD$w3I'm so scared$MC...$MD$w4
Aren't you$w3 even a bit scared, $w2Mist?$K
$F1$POf course I am, but$MC...$MD$w4$FS
Listen, $w2we'll be fine!$w4 My brother$w2
will definitely come rescue us.$K
$F3$P$FSMm$MC...$MD$w2yeah.$w4 You're right!$w4
And I'm sure that my brother$w2
will be right there with him.$K
$F1$PI know he will$MC...$MD$w4
So no more crying!$w3 Got it?$K
$=0300    $R�w�i��b|$B�q��|$<$F3$Fc$F3$FCL_LOFA2|$F1$FCL_MIST|$F3$POh$MC...$MD$w3sniff$MC...$MD$K
$F1$PKeep your chin up, $w2Rolf!$w4
Boys aren't supposed to cry!$K
$F3$P$FdBut$MC...$MD$w3I'm so scared$MC...$MD$w4
Aren't you$w3 even a bit scared, $w2Mist?$K
$F1$POf course I am, but$MC...$MD$w4$FS
Listen, $w2we'll be fine!$w4 My brother$w2
will definitely come rescue us.$K
$F3$POh, yeah$MC... $MD$w4You've still got$MC...$MD$w4
Ike to $w2look after you.$K
$F1$P$FAOh,$w4 I'm sorry$MC...$MD
I didn't mean$MC...$MD$K
$F3$PIt's all right. I know.$K
$F1$PRolf, $w2really$MC...$MD$w4
I'm sorry.$K
$F3$PIf my brothers were still alive$MC...$MD$w4
they'd come get me, wouldn't they?$K
$F1$P$FSYes,$w4 of course they would.$K
$F3$P$FSSo I shouldn't keep crying, should I?$w4
I mean, $w2we are going to be rescued.$K
$F1$PThat's right!$w4 And we should
be ready,$w4 all right?$K
$=0300   $R�㉺��b|$c0TIAMAT|I'm sure I told them to wait for me$MC...$MD$w4
I should have known they'd disobey
orders.$w4 They have no discipline$MC...$MD$K$PAs deputy commander of the Greil
Mercenaries,$w2 I cannot allow any
more of our people to be harmed.$w2$K    $R�㉺��b|$c0IKE|$s0Titania!$w4 I, $w2uh$MC... $MDI'm sorry.$w4
I ran off on my own without$MC...$MD$K
$c1TIAMAT|$s1We'll talk about it later.$w4
For the time being, $w2keep
your mind on the battle, Ike.$K
$s0Right!$K  $R�㉺��b|$c0IKANAU|Graaw!$w3 We won't lose,$w3
not to the likes of you!$K $R�㉺��b|$c1IKE|$s1Will you let the two of them go now?$K
$s0$FS$c0IKANAU|$s0Sure, you can have 'em both.$w4
If you can beat me, $w2that is!$K    $R�㉺��b|$s0$FS$c0IKANAU|$s0Heh heh heh.$w3 I've been waiting
for you,$w3 you red-haired demoness.$K$PYou$w3 are going to hurt$MC--$MDand hurt bad.$w4
This is for my mates who fell before
you in Caldea!$K
$c1TIAMAT|$s1No matter your motives,$w3 you've taken
helpless innocents as hostages.$w3
You're not fit to be called human.$K$PMay the blessings of the goddess$w3
be kept from you for all eternity!$K   $R�㉺��b|$c0IKANAU|This$MC... $MD$w3This can't be$MC...$MD$w4
I don't deserve to lose$w4
to $w1sellswords $w1like $w1you$w1$MC...$MD$K    $R�w�i��b|$B�X�̑O|$<$F3$FCL_IKE|$F3$PAll right!$w4 Somehow we did it.$K
$F4$FS$F4$FCL_BOLE|$F4$PSomehow? $w2What do you mean,$w2 somehow?$w4
We did it$w2 because we're better
than them!$K
$Ub$H$F4$P$FA$F1$FCL_TIAMAT|$F1$P$Ub$HBoyd,$w2 calm yourself.$K$PWhat you DID...was in direct defiance of
the orders I explicitly gave you.$w4 How it
all turned out is another issue altogether.$K
$F4$FD$F3$FD$F4$FCL_OSCAR|$F4$PDeputy Commander, $w2I take full
responsibility. The failure is mine$MC...$MD$K
$F3$FCL_KILROY|$F3$PAccept our apologies.$K
$F1$POscar, $w2Rhys$MC...$MD$w4
What am I supposed to do with you two?$K$PSigh...$w4 I think I'll leave you two to the
commander.$w4 He'll know how to handle you,
I'm sure. $w6Now, let's find Mist and Rolf.$K
$F4$FD$F3$FD$F3$P$F3$FCL_IKE|According to the bandit chief,$w2
they're in that shack back$MC--$MD$K
$F7$FCDUMMY|$F7$PEeek!$K
$F3$PWhat?$w4 Mist!$K    $R�w�i��b|$B�X�̑O|$<$F3$FCL_IKE|$F3$PLooks like we did it.$K
$F4$FCL_BOLE|$F4$PI guess.$K
$Ub$H$F1$FCL_TIAMAT|$F1$P$Ub$HIke, $w2Boyd!$K$PWhat you did was in direct defiance of
your orders.$w4 How it all turned out is
another issue altogether.$K
$F4$FD$F3$FD$N$UB$H  $R�w�i��b|$B�X�̑O|$<$F3$FCL_IKE|$F3$PLooks like we did it.$K
$F4$FCL_BOLE|$F4$PI guess.$K
$Ub$H$F1$FCL_TIAMAT|$F1$P$Ub$HIke, $w2Boyd!$K$PWhat you did was in direct defiance of the
orders I explicitly gave you.$w4 How it all
turned out is another issue altogether.$w4$FcUrgh!$K
$F4$PAre$MC... $MD$w2Are you feeling all right,$w4 Titania?$K
$F1$P$FdIt's nothing to worry yourselves about.$K
$F3$PYou need help.$w4 You're having a rough
time even standing, $w2aren't you?$K
$F1$PI told you, I'm fine!$K
$F4$FD$F3$FD$N$UB$H   $R�w�i��b|$B�X�̑O|$<$F3$FCL_IKE|$F3$PLooks like we did it.$K
$Ub$H$F1$FCL_TIAMAT|$F1$P$Ub$HI suppose.$w4 Yet$MC...$MD$K$PYou realize that you disobeyed orders,
don't you?$w4 You have to understand
that and$MC...$MD$w4$Fcurgh!$K
$F3$PTitania!$w4 Are you well?$K
$F1$P$FdIt's nothing to worry yourself about.$K
$F3$PYou need help.$w4 You're having a rough
time even standing, $w2aren't you?$K
$F1$PI told you, I'm fine!$K$F3$FD$N$UB$H  $R�w�i��b|$B�X�̑O|$<$F3$FCL_IKE|$F3$PLooks like we did it.$K
$Ub$H$F1$FCL_TIAMAT|$F1$P$Ub$HIke$MC...$MD$K$PYou disobeyed orders.$w4
What on earth were you thinking?$K$F3$FD$N$UB$H   $F4$FCL_OSCAR|$F4$PDeputy Commander, I've no excuse$MC...$MD$K
$F1$POscar, $w2what am I supposed to do with you?$K$PSigh$MC...$MD$w4I think I'm going to leave you to
the commander.$w4 He'll have some ideas, I'm
sure. $w6Now, let's find Mist and Rolf.$K
$F0$FCL_IKE|$F0$PAccording to the bandit chief,$w2
they're in that shack back$MC...$MD$K
$F7$FCDUMMY|$F7$PEeek!$K$FD
$F0$PWhat?$w4 Mist!$K $F4$FCL_KILROY|$F4$PTitania$MC...$MD$w4I'm very sorry$MC...$MD$K
$F1$PRhys, $w2I can't believe you would go
along with this.$K$PSigh$MC...$MD$w4I think I'm going to leave you to
the commander.$w4 He'll have some ideas, I'm
sure. $w6Now, let's find Mist and Rolf.$K
$F0$FCL_IKE|$F0$PAccording to the bandit chief,$w2
they're in that shack back$MC...$MD$K
$F7$FCDUMMY|$F7$PEeek!$K$FD
$F0$PWhat?$w4 Mist!$K $F1$PSigh$MC...$MD$w4I think I'm going to leave you to
the commander.$w4 He'll have some ideas, I'm
sure. $w6Now, let's find Mist and Rolf.$K
$F0$FCL_IKE|$F0$PAccording to the bandit chief,$w2
they're in that shack back$MC...$MD$K
$F7$FCDUMMY|$F7$PEeek!$K$FD
$F0$PWhat?$w4 Mist!$K    $R�㉺��b|$c0MIST|$s0Please, $w2let us go!$w4
I said let us go!$K
$c1IKE|$s1Mist!$K
$s0$FSBrother!$w4 Everyone!$w4
You came!$K
$d0$d1$c0LOFA2|$s0Oh$MC...$MD$w4I'm scared.$K
$c1OSCAR|$s1Rolf!$K
$s0Oscar?$w4
Help me!$K
$c3BOLE|$s3Rolf!$w4
I'm here, too!$K
$s0Boyd?$w4$Fh
Wa$MC...$MD$w4waah!$K
$s3$FSStop crying!$w4 You don't need to
worry! We'll get you outta there!$K
$s1$FSThat's right! $w2Buck up, buddy!$K
$s0$Fd$FSUh$MC... $MDI'll try!$K
$d3$d1$d0$c1IKE|$s1You! $w2Harm either of them,$w4
and I'll see you dead!$K
$c0BANDIT2|$s0Shut up!$w4 Shut $w2your $w2stinking trap!$K$PIf you want these two alive,$w2 you'll
throw your weapons down.$w4
If you don't, $w2I'll start with the girl$MC...$MD$K
$c2MIST|$s2Eek!$w4 No!!!$K
$s1Stop!$K
$d2$c3TIAMAT|$s3Wait!$K
$s1Huh?$K$d1
$s0Yeah?$K
$Ub$H$s3I'm putting down my weapons.$w4
See?$K
$Ub$H$K$s0$FSHeh$MC...$MD$w4heh heh.$w4
Smart move, $w2wench!$K
$c1OSCAR|$s1Deputy Commander$MC...$MD$K
$s3We're here to save them.$w4
Now all of you back off.$K
$s1OK$MC...$MD$K
$Ub$H$d1$d3$c1IKE|$s1Dang!$K
$Ub$H$c3BOLE|$s3This stinks!$K
$Ub$H$d3$s0Heh heh heh$MC...$MD$w4 All right,$w2
so now you're all unarmed.$K$PWhich means$MC...$MD$w2all you can do
is watch while I gut this whiny
brat like a fatling pig!$K
$s1Ah!$K  $R�㉺��b|$c0MIST|$s0Please, $w2let us go!$w4
I said let us go!$K
$c1IKE|$s1Mist!$K
$s0$FSBrother!$w4 Everyone!$w4
You came!$K
$d0$d1$c0LOFA2|$s0Oh$MC...$MD$w4I'm scared.$K
$d0$c1IKE|$s1You! $w2Harm either of them,$w4
and I'll see you dead!$K
$c0BANDIT2|$s0Shut up!$w4 Shut $w2your $w2stinking trap!$K$PIf you want these two alive,$w2 you'll
throw down your weapons.$w4
If you don't, $w2I'll start with the girl$MC...$MD$K
$c2MIST|$s2Eek!$w4 No!!!$K
$s1Stop!$K
$d2$c3TIAMAT|$s3Wait!$K
$s1Huh?$K$d1
$s0Yeah?$K
$Ub$H$s3I'm putting down my weapons.$w4
See?$K
$Ub$H$s0$FSHeh$MC...$MD$w4heh heh.$w4
Smart move, $w2wench!$K
$c1IKE|$s1Titania?$K
$s3We're here to save them.$w4
Now back off.$K$d3
$s1All right$MC...$MD$K
$Ub$H$s0Heh heh heh$MC...$MD$w4 All right,$w2
so now you're all unarmed.$K$PWhich means$MC...$MD$w2all you can do
is watch while I gut this whiny
brat like a fatling pig!$K
$s1Ah!$K $R�㉺��b|$c0MIST|$s0Please, $w2let us go!$w4
I said let us go!$K
$c1IKE|$s1Mist!$K
$s0$FSBrother!$w4 Everyone!$w4
You came!$K
$d0$d1$c0LOFA2|$s0Oh$MC...$MD$w4I'm scared.$K
$c1OSCAR|$s1Rolf!$K
$s0Oscar?$w4
Help me!$K
$d1$d0$c1IKE|$s1You! $w2Harm either one of those two,$w4
and I'll see you dead!$K
$c0BANDIT2|$s0Shut up!$w4
Shut $w2your $w2stinking trap!$K$PIf you want these two alive,$w2
you'll throw down your weapons.$w4
If you don't, $w2I'll start with the girl$MC...$MD$K
$c2MIST|$s2Eek!$w4 No!!!$K
$s1Stop!$K
$d2$c3TIAMAT|$s3Wait!$K
$s1Huh?$K$d1
$s0Yeah?$K
$Ub$H$s3I'm putting down my weapons.$w4
See?$K
$Ub$H$s0$FSHeh$MC...$MD$w4heh heh.$w4
Smart move, $w2wench!$K
$c1OSCAR|$s1Deputy Commander$MC...$MD$K
$s3We're here to save them.$w4
Now all of you back off.$K
$s1OK$MC...$MD$K
$Ub$H$d1$d3$c1IKE|$s1Dang!$K
$Ub$H$s0Heh heh heh$MC...$MD$w4 All right,$w2
so now you're all unarmed.$K$PWhich means$MC...$MD$w2all you can do
is watch while I gut this whiny
brat like a fatling pig!$K
$s1Ah!$K    $R�㉺��b|$c0MIST|$s0Please, $w2let us go!$w4
I said let us go!$K
$c1IKE|$s1Mist!$K
$s0$FSBrother!$w4 Everyone!$w4
You came!$K
$d0$d1$c0LOFA2|$s0Oh$MC...$MD$w4I'm scared.$K
$c1BOLE|$s1Rolf!$K
$s0Boyd?$w4$Fh
Wa$MC...$MD$w4waah!$K
$s1Stop crying!$w4 You don't need to
worry! We'll get you outta there!$K
$s0$Fd$FSUh$MC...$MDOK!$K
$d1$d0$c1IKE|$s1You! $w2Harm either one of those two,$w4
and I'll see you dead!$K
$c0BANDIT2|$s0Shut up!$w4 Shut $w2your $w2stinking trap!$K$PIf you want these two alive,$w2 you'll
throw down your weapons.$w4
If you don't, $w2I'll start with the girl$MC...$MD$K
$c2MIST|$s2Eek!$w4 No!!!$K
$s1Stop!$K
$d2$c3TIAMAT|$s3Wait!$K
$s1Huh?$K$d1
$s0Yeah?$K
$Ub$H$s3I'm putting down my weapons.$w4
See?$K
$Ub$H$s0$FSHeh$MC...$MD$w4heh heh.$w4
Smart move, $w2wench!$K
$c1IKE|$s1Titania?$K
$s3We're here to save them.$w4
Now all of you back off.$K
$s1All right$MC...$MD$K
$Ub$H$d3$c3BOLE|$s3This stinks!$K
$Ub$H$d3$s0Heh heh heh$MC...$MD$w4 All right,$w2
so now you're all unarmed.$K$PWhich means, $w2all you can do
is watch while I slaughter
this whiny brat!$K
$s1Ah!$K $R�㉺��b|$c0BANDIT2|$s0Beh heh heh!$w4 DIE!!!$K
$c1LOFA2|$s1$FcWah!$K $R�㉺��b|$c0BANDIT2|Arrr$MC...$MD$w4 Uhh$MC......$MD$K$d0 $R�㉺��b|$s2$Fc$c2LOFA|Ohh$MC... $MDUhnnng$MC...$MD$K $R�㉺��b|$c0MIST|$s0Rolf!$w4 Can you hear me?$K
$c3BOLE|$s3Mist!$w4 Is Rolf$MC--$MD Is he...$K
$s0$FSHe's fine.$w4 He just fainted is all.$w4
There's not a scratch on him.$K
$s3Whew$MC...$MD$w4$FS
Don't do that to me.$K
$s1$FS$c1OSCAR|$s1I'm just glad $w2to see you both alive
and well$MC...$MD$w5 You're both so brave.$K
$s0Yep!$w4 Thanks.$K
$d3$d1$d0$c1IKE|$s1This guy's dead.$w4
This arrow$MC--$MD$w2who shot it?$K
$Ub$H$s0$FS$c0CHINON2|$s0A single arrow, right between the
eyes?$w4 Who else could make a shot
like that?$w2 No one, that's who!$K
$s1That voice!$K $R�㉺��b|$c0MIST|$s0Rolf!$w4 Can you hear me?$K
$c1IKE|$s1Mist!$w4 Is Rolf$MC--$MD Is he...$K
$s0$FSHe's fine.$w4 He just fainted is all.$w4
There's not a scratch on him.$K
$s1That's a relief. If something happened
to Rolf,$w4 I'd never forgive myself. Not
after losing both Oscar and Boyd.$K
$s0Ike$MC...$MD$K
$d0$s1This guy's dead.$w4
This arrow$MC--$MD$w2who shot it?$K
$Ub$H$s0$FS$c0CHINON2|$s0A single arrow, right between the
eyes?$w4 Who else could make a shot
like that?$w2 No one, that's who!$K
$s1That voice!$K  $R�㉺��b|$c0MIST|$s0Rolf!$w4 Can you hear me?$K
$c1OSCAR|$s1Mist!$w4 Is Rolf$MC--$MD Is he...$K
$s0$FSHe's fine.$w4 He just fainted is all.$w4
There's not a scratch on him.$K
$s1$FS$MC...$MDReally?$w4$FS
That's$MC...$MDgood$MC...$MD$K$FA
After Boyd$MC...$MD$w4
The idea of losing Rolf, too$MC...$MD$w4$FS
Thank goodness.$w4 Oh, thank you$MC...$MD$K
$s0$FAOscar$MC...$MD$K
$d1$d0$c1IKE|$s1This guy's dead.$w4
This arrow$MC--$MD$w2who shot it?$K
$Ub$H$s0$FS$c0CHINON2|$s0A single arrow, right between the
eyes?$w4 Who else could make a shot
like that?$w2 No one, that's who!$K
$s1That voice!$K   $R�㉺��b|$c0MIST|$s0Rolf!$w4 Can you hear me?$K
$c1BOLE|$s1Mist!$w4 Is Rolf$MC--$MD Is he...$K
$s0$FSHe's fine.$w4 He just fainted is all.$w4
There's not a scratch on him.$K
$s1Whew$MC...$MD$w4$FS
Don't do that to me.$K$FA$PIf I failed to protect him$MC...$MD$w5
I'd never be able to face Oscar$MC...$MD$K
$s0$FABoyd$MC...$MD$K
$d1$d0$c1IKE|$s1This guy's dead.$w4
This arrow$MC--$MD$w2who shot it?$K
$Ub$H$s0$FS$c0CHINON2|$s0A single arrow, right between the
eyes?$w4 Who else could make a shot
like that?$w2 No one, that's who!$K
$s1That voice!$K   $R�w�i��b|$B����-��|$<$F1$FS$F1$FCL_CHINON|$F1$PDon't you children owe me a little
gratitude? I did just save your lives.$K
$F0$FCL_GATRIE|$F0$PDeputy Commander$MC...$MD$w4Shinon$MC...$MD$w4hah$MC...$MDhah$MC...$MD$w4
You're$w1 both$w3 so$w3 cruel.$w2 With this armor on,$w2$Fh
you know I can't run$w1 that$w2 fast$MC...$MD$K
$F3$FCL_IKE|$F3$PShinon!$w3 Gatrie!$K
$F4$FCL_KILROY|$F4$PSo, $w2that's where you went, Titania?$K
$F0$FD$F0$FS$F0$FCL_TIAMAT|$F0$POf course. $w2I knew we'd need reinforcements.$w4
I'm glad it wasn't a waste of time.$K$F3$FD$F4$FD$F0$FD
$F3$FS$F3$FCL_TIAMAT|$F3$PWell done, $w2both of you.$K
$F1$PIn the end, $w2I got to feather someone.$w4
So it was worth the rush.$K
$F0$Fh$F0$FCL_GATRIE|$F0$PAll I$MC...$MD$w3did$MC...$MD$w2was sweat$MC...$MD$w4
That$MC...$MD$w2was h-$w1hard$MC...$MDwork$MC...$MD$K$P$F0$FD$F1$FD$F3$FD$w6
$F1$FS$F1$FCL_MIST|$F1$PBrother!$K
$F3$FCL_IKE|$F3$P$FSMist$MC...$MD$w4
You did well, Sis.$w4
You must have been frightened.$K
$F1$P$FAUh-huh$MC...$MD$w4 Uh-unh!$FS$w4
I never stopped believing.$K$PI knew that you$w4 and the others
would come and rescue us.$w2
$w2I knew you'd come!$K$PSo,$w4 I was fine!$K
$F3$PReally?$K
That's an improvement on your usual
sobbing and nose-running.$K
$F1$P$FAYou jerk!$w4
I$MC... $MD$w2My nose does not run!$K
$F4$FS$F4$FCL_TIAMAT|$F4$PAll right, $w2come on!$w4
Let's head for home.$K$PMy goodness$MC...$MD$w4
What a day this has been.$K
$=1500    $R�w�i��b|$B����-��|$<$F1$FS$F1$FCL_CHINON|$F1$PDon't you children owe me a little
gratitude? I did just save your lives.$K
$F0$FCL_GATRIE|$F0$PDeputy Commander$MC...$MD$w4Shinon$MC...$MD$w4hah$MC...$MDhah$MC...$MD$w4
You're$w1 both$w3 so$w3 cruel.$w2 With this armor on,$w2$Fh
you know I can't run$w1 that$w2 fast$MC...$MD$K
$F3$FCL_IKE|$F3$PShinon!$w3 Gatrie!$K
$F4$FCL_KILROY|$F4$PSo, $w2that's where you went, Titania?$K
$F0$FD$F0$FS$F0$FCL_TIAMAT|$F0$POf course. $w2I knew we'd need reinforcements.$w4
I'm glad it wasn't a waste of time.$K$F3$FD$F4$FD$F0$FD
$F3$FCL_TIAMAT|$F3$PWell done, $w2both of you.$K
$F1$PIn the end, $w2I got to feather someone.$w4
So it was worth the rush.$K
$F0$Fh$F0$FCL_GATRIE|$F0$PAll I$MC...$MD$w3did$MC...$MD$w2was sweat$MC...$MD$w4
That$MC...$MD$w2was h-$w1hard$MC...$MDwork$MC...$MD$K$P$F0$FD$F1$FD$F3$FD$w6
$F3$FCL_IKE|$F1$FS$F1$FCL_MIST|$F1$PBrother!$K
$F3$P$FSMist$MC...$MD$w4
You did well, Sis.$w4
You must have been frightened.$K
$F1$P$FAUh-huh$MC...$MD$w4 Uh-unh!$FS$w4
I never stopped believing.$K$PI knew that you$w4 and the others
would come and rescue us.$w2
$w2I knew you'd come!$K$PSo,$w4 I was fine!$K
$F3$PReally?$K
$F4$FCL_TIAMAT|$F4$PAll right, $w2come on!$w4
Let's head for home.$K$PMy goodness$MC...$MD$w4
What a day this has been.$K
$=1000   $R�w�i��b|$B����-��|$<$F1$FS$F1$FCL_CHINON|$F1$PSing my praise, $w2whelps.$K
$F0$FCL_GATRIE|$F0$PDeputy Commander$MC...$MD$w4Shinon$MC...$MD$w4hah$MC...$MDhah$MC...$MD$w4
You're$w1 both$w3 cruel.$w2 With this armor on,$w2$Fh
you know I can't run$w1 that$w2 fast$MC...$MD$K
$F3$FCL_IKE|$F3$PShinon!$w3 Gatrie!$K
$F4$FCL_KILROY|$F4$PSo, $w2that's where you went, Titania?$K
$F0$FD$F0$FCL_TIAMAT|$F0$POf course. $w2I knew we'd need reinforcements.$w4
I'm glad it wasn't a waste of time.$K
Well done, $w2both of you.$K
$F1$PIn the end, $w2I got to feather someone.$w4
So it was worth the rush.$K$F1$FD
$F1$Fh$F1$FCL_GATRIE|$F1$PAll I$MC...$MD$w3did$MC...$MD$w2was sweat$MC...$MD$w4
That$MC...$MD$w2was h-$w1hard$MC...$MD$K$P$F1$FD$F4$FD$F0$FD
$F1$FS$F1$FCL_MIST|$F1$PBrother!$K
$F3$P$FSMist!$w4
You did well, Sis.$w4
You must have been frightened.$K
$F1$P$FAUh-huh$MC...$MD$w4 I mean, uh-unh!$FS$w4
I never stopped believing.$K$PI knew that you$w4 and the others
would come and rescue us.$w2
$w2I knew you'd come!$K$PSo,$w4 I was fine!$K
$F3$PReally?$K
$F4$FCL_TIAMAT|$F4$PAll right, $w2come on!$w4
Let's head for home.$K$PMy goodness$MC...$MD$w4
What a day this has been.$K
$=0300  $R�w�i��b|$B����-��|$<$F1$FS$F1$FCL_CHINON|$F1$PDon't you children owe me a little
gratitude? I did just save your lives.$K
$F0$FCL_GATRIE|$F0$PDeputy Commander$MC...$MD$w4Shinon$MC...$MD$w4hah$MC...$MDhah$MC...$MD$w4
You're$w1 both$w3 so$w3 cruel.$w2 With this armor on,$w2$Fh
you know I can't run$w1 that$w2 fast$MC...$MD$K
$F3$FCL_IKE|$F3$PShinon!$w3 Gatrie!$K
$F3$PSo, Titania$MC... $MD$w2That's where you went, is it?$K
$F4$FCL_TIAMAT|$F4$POf course. $w2I knew we'd need reinforcements.$w4
I'm glad it wasn't a waste of time.$K
Well done, $w2both of you.$K
$F1$PIn the end, $w2I got to feather someone.$w4
So it was worth the rush.$K
$F0$PAll I$MC...$MD$w3did$MC...$MD$w2was sweat$MC...$MD$w4
That$MC...$MD$w2was h-$w1hard$MC...$MDwork$MC...$MD$K$P$F0$FD$F1$FD$F4$FD$w6
$F1$FS$F1$FCL_MIST|$F1$PBrother!$K
$F3$P$FSMist$MC...$MD$w4
You did well, Sis.$w4
You must have been frightened.$K
$F1$P$FAUh-huh$MC...$MD$w4 I mean, uh-unh!$FS$w4
I never stopped believing.$K$PI knew that you$w4 and the others
would come and rescue us.$w2
$w2I knew you'd come!$K$PSo,$w4 I was fine!$K
$F3$PReally?$K
$F4$FCL_TIAMAT|$F4$PAll right, $w2come on!$w4
Let's head for home.$K$PMy goodness$MC...$MD$w4
What a day this has been.$K
$=0300  $R�w�i��b|$B����-��|$<$F1$FS$F1$FCL_CHINON|$F1$PDon't you children owe me a little
gratitude? I did just save your lives.$K
$F0$FCL_GATRIE|$F0$PDeputy Commander$MC...$MD$w4Shinon$MC...$MD$w4hah$MC...$MDhah$MC...$MD$w4
You're$w1 both$w3 so$w3 cruel.$w2 With this armor on,$w2$Fh
you know I can't run$w1 that$w2 fast$MC...$MD$K
$F3$FCL_IKE|$F3$PShinon!$w3 Gatrie!$K
So, Titania, $w2that's where you were?$K
$F4$FCL_TIAMAT|$F4$POf course. $w2I knew we'd need reinforcements.$w4
I'm glad it wasn't a waste of time.$K
Well done, $w2both of you.$K
$F1$PIn the end, $w2I got to feather someone.$w4
So it was worth the rush.$K
$F0$PAll I$MC...$MD$w3did$MC...$MD$w2was sweat$MC...$MD$w4
That$MC...$MD$w2was h-$w1hard$MC...$MDwork$MC...$MD$K$P$F0$FD$F1$FD$F4$FD$w6
$F1$FS$F1$FCL_MIST|$F1$PBrother!$K
$F3$P$FSMist$MC...$MD$w4
You did well, Sis.$w4
You must have been frightened.$K
$F1$P$FAUh-huh$MC...$MD$w4 I mean, uh-unh!$FS$w4
I never stopped believing.$K$PI knew that you$w4 and the others
would come and rescue us.$w2
$w2I knew you'd come!$K$PSo,$w4 I was fine!$K
$F3$PReally?$K
$F4$FCL_TIAMAT|$F4$PAll right, $w2come on!$w4
Let's head for home.$K$PMy goodness$MC...$MD$w4
What a day this has been.$K
$=0300  $R�w�i��b|$B����-��|$<$F5$FCL_TIAMAT|$F5$P$Fc$MC...$MDWhew$MC...$MD$K
$F3$FCL_IKE|$F3$PTitania!$K
$F5$PWhat?$K
$F3$PAbout Rhys$MC...$MD$K
$F5$P$FdWe will discuss it once we're home.$K
$F3$PI'm sorry$MC...$MD$K
$F5$PI have only one thing to say to you.$w4
Never do anything $w2as reckless as
this again.$K$PI'm sure you understand, but$MC...$MD$w4
You mustn't ever, ever forget$w4 the
lives that need not have been lost.$K
$=2000   $R�w�i��b|$B����-��|$<$F5$FCL_TIAMAT|$F5$P$Fc$MC...$MDWhew$MC...$MD$K
$F3$FCL_IKE|$F3$PTitania!$K
$F5$PWhat?$K
$F3$PAbout Oscar$MC...$MD$K
$F5$P$FdWe will discuss it once we're home.$K
$F3$PI'm sorry$MC...$MD$K
$F5$PI have only one thing to say to you.$w4
Never do anything $w2as reckless as
this again.$K$PI'm sure you understand, but$MC...$MD$w4
You mustn't ever, ever forget$w4 the
lives that need not have been lost.$K
$=2000  $R�w�i��b|$B����-��|$<$F5$FCL_TIAMAT|$F5$P$Fc$MC...$MDWhew$MC...$MD$K
$F3$FCL_IKE|$F3$PTitania!$K
$F5$PWhat?$K
$F3$PAbout Boyd$MC...$MD$K
$F5$P$FdWe will discuss it once we're home.$K
$F3$PI'm sorry$MC...$MD$K
$F5$PI have only one thing to say to you.$w4
Never do anything $w2as reckless as
this again.$K$PI'm sure you understand, but$MC...$MD$w4
You mustn't ever, ever forget$w4 the
lives that need not have been lost.$K
$=2000   $R�w�i��b|$B����-��|$<$F5$FCL_TIAMAT|$F5$P$Fc$MC...$MDWhew$MC...$MD$K
$F3$FCL_IKE|$F3$PTitania!$K
$F5$PWhat?$K
$F3$PAbout Oscar and the others$MC...$MD$K
$F5$P$FdWe will discuss it once we're home.$K
$F3$PI'm sorry$MC...$MD$K
$F5$PI have only one thing to say to you.$w4
Never do anything $w2as reckless as
this again.$K$PI'm sure you understand, but$MC...$MD$w4
You mustn't ever, ever forget$w4 the
lives that need not have been lost.$K
$=2000   $R�w�i��b|$B����-��|$<$F5$FCL_TIAMAT|$F5$P$Fc$MC...$MDWhew$MC...$MD$K
$F3$FCL_IKE|$F3$PTitania!$K
$F5$PWhat?$K
$F3$PAbout Oscar and Boyd$MC...$MD$K
$F5$P$FdWe will discuss it once we're home.$K
$F3$PI'm sorry$MC...$MD$K
$F5$PI have only one thing to say to you.$w4
Never do anything $w2as reckless as
this again.$K$PI'm sure you understand, but$MC...$MD$w4
You mustn't ever, ever forget$w4 the
lives that need not have been lost.$K
$=2000 $R�w�i��b|$B����-��|$<$F5$FCL_TIAMAT|$F5$P$Fc$MC...$MDWhew$MC...$MD$K
$F3$FCL_IKE|$F3$PTitania!$K
$F5$PWhat?$K
$F3$PAbout Oscar$MC...$MD$w4and Rhys$MC...$MD$K
$F5$P$FdWe will discuss it once we're home.$K
$F3$PI'm sorry$MC...$MD$K
$F5$PI have only one thing to say to you.$w4
Never do anything $w2as reckless as
this again.$K$PI'm sure you understand, but$MC...$MD$w4
You mustn't ever, ever forget$w4 the
lives that need not have been lost.$K
$=2000  $R�w�i��b|$B����-��|$<$F5$FCL_TIAMAT|$F5$P$Fc$MC...$MDWhew$MC...$MD$K
$F3$FCL_IKE|$F3$PTitania!$K
$F5$PWhat?$K
$F3$PAbout Boyd$MC...$MD$w4and Rhys$MC...$MD$K
$F5$P$FdWe will discuss it once we're home.$K
$F3$PI'm sorry$MC...$MD$K
$F5$PI have only one thing to say to you.$w4
Never do anything $w2as reckless as
this again.$K$PI'm sure you understand, but$MC...$MD$w4
You mustn't ever, ever forget$w4 the
lives that need not have been lost.$K
$=2000     <,      <x   	  =     >�   &  B�   0  G�   <  C�   K  E�   Z  ?0   k  H8   w  I�   �  KT   �  Lp   �  QX   �  T�   �  X�   �  ]   �  ]L   �  ]�   �  ]�     _�    b    dX  *  f�  8  l  F  q0  T  u�  b  z�  p  H  ~  ��  �  ��  �  �X  �  �  �  ��  �  ��  �  2�  �  4�  �  6�  �  :L  
        d  "  0  0  
  >  h  L    Z  �  h   0  v  $`  �  ,   �  -�  �  /H  �  0�  �  (<  �  ;P  �MS_03_BT MS_03_BT_IKE MS_03_BT_TIAMAT MS_03_DIE MS_03_ED_00 MS_03_ED_00_bd MS_03_ED_00_td MS_03_ED_00_tdbd MS_03_ED_01 MS_03_ED_01_A MS_03_ED_01_B MS_03_ED_01_C MS_03_ED_02_A MS_03_ED_02_B MS_03_ED_02_C MS_03_ED_02_D MS_03_ED_02_XX MS_03_ED_03 MS_03_ED_04 MS_03_ED_04_A MS_03_ED_04_B MS_03_ED_04_C MS_03_ED_04_D MS_03_ED_05_A MS_03_ED_05_B MS_03_ED_05_C MS_03_ED_05_D MS_03_ED_05_E MS_03_ED_06_A MS_03_ED_06_B MS_03_ED_06_C MS_03_ED_06_D MS_03_ED_06_E MS_03_ED_06_F MS_03_ED_06_G MS_03_EV_01_A MS_03_EV_01_B MS_03_EV_01_C MS_03_EV_02 MS_03_OP_01 MS_03_OP_02_A MS_03_OP_02_B MS_03_OP_03_A MS_03_OP_03_B MS_03_OP_03_C MS_03_OP_03_D MS_03_OP_04 MS_03_OP_05 MS_03_OP_05_2_A MS_03_OP_05_2_B MS_03_OP_05_2_C MS_03_OP_05_2_D MS_03_OP_05_B MS_03_TK_01 