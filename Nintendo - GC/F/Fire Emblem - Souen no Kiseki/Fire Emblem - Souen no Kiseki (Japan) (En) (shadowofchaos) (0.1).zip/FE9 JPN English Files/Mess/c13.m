  `�  \�       .                $RGMAP��b|$O3$GHaving narrowly escaped Daein's grasp,$w3 the
Greil Mercenaries $w2are pleased to feel the
ocean beneath their feet as they set sail.$K$PAccording to Captain Nasir, $w2the voyage to
Begnion$w3 will take roughly two months.$K    $RGMAP��b|$O3$GBlessed with temperate weather,$w4 the ship's
journey southward is smooth and steady.$K$PAs it passes the midpoint of its trip,$w2 the
ship sets a course along the coastline$w2
and begins to head east.$K $RGMAP��b|$O3$GThese seas belong to Phoenicis and
Kilvas,$w5 the kingdoms of the bird tribes.$K    $RGMAP��b|$O3$GBoth nations $w2prey on human vessels
for supplies and wealth,$w3 and their flying
corsairs$w2 are feared across the seas.$K    $RGMAP��b|$O3$GAdditionally,$w3 the southern portion of
the continent $w2contains the realm of the
dragon tribe: $w2the monarchy of Goldoa.$K  $RGMAP��b|$O3$GThis country has remained isolated since its
founding centuries past,$w3 preserving its
closed culture $w2behind a veil of mystery.$K$P$UB$H    It is these laguz-controlled waters$w2
that Ike and company must now cross.$K
$Ub$H $R�w�i��b|$B�D-��|$<$F3$FCL_IKE|$F3$P...$K
$F1$FCL_MIST|$F1$PIke?$K
$F3$P...$K
$F1$P$FSWhat's bothering you? $w2You've been moping
around ever since we came aboard.$K
$F3$PI'm...just a little seasick.$K
$F1$PSeasick? You're such a bad liar.$w4
You never even get regular sick.
You're not the type to get seasick!$K
$F3$PReally, $w2it's nothing.$K
$F1$PCome on, talk to me.$w4 You've been
doing so much lately.$w3 I just want the
chance to help you for a change.$K
$F3$PWell...$w2 All right. I'll tell you what's
been bothering me.$w4 It's that incident
back in Toha.$K
$F1$PGo on.$K
$F3$PWhen everyone discovered Ranulf was
a laguz,$w4 all those people--$w2they
changed, just like that.$K$PUp until that instant, $w2they'd seemed
like such kind and decent people.$K$PI just...$w4 I had no idea beorc prejudice
against the laguz was so strong.$K$PWhy $w2do they hate them so much?$w4
How are we so different, Ranulf and I?$K
$F1$P$FAI have to say,$w4 at first,$w4 I was scared, too.$K$PWhen I saw how they could change...$K$PThey can do things that we hu--$w4 I mean,$w2
we beorc $w2can't do. They're not like us...$K
$F3$PMist, $w2you can't honestly feel...$K
$F1$PIt's different now!$w4 Everyone's$w3 so very nice.$K$PBut, you know, $w2that's because of
all the time we've spent together.$K$PI've seen how they are; $w2I've gotten to
know them.$w4 That's why I've changed.$K$PI'm not scared or nervous around them,$w3
but other people don't get that chance.$w5
I think that's why they're frightened.$K
$F3$PMaybe you're right...$w4 Maybe people like
me are the odd ones, the people who
accept others as they are.$K
$F1$PI wish more people were like that.$w2
I mean, no one really wants to fight,$w5 do
they? Doesn't everyone WANT peace?$K$PI guess it's just hard to put all of
those fears behind us.$K
$F7$FCDUMMY|$F7$PYou're right. $w2It is very hard.$K$P$FD
$F0$FCL_NASIR|$F1$FD$F4$FCL_MIST|$F4$PNasir!$w4 What's the big idea,
eavesdropping on us like that?$K
$F0$P$FSHow do you find sailing?$w4
Have you gotten sick at all?$K
$F3$PWe're fine. But answer a question for me,
would you? Why are you here? Why
do you associate with the laguz?$K
$F0$PWhy? $w2Besides the obvious financial benefits,
I suppose I do so because I am one.$K
$F4$PWhat?$w4 No, you're not a laguz!
I don't see any tail or anything!$K
$F0$PBecause I've chosen to live among
beorc, I've taken$w3 certain steps to
make sure I'm not recognized.$K$PI've had to change my attire, my
feeding habits...$w5 I've done$w3 many things.$K
$F3$PWhy would you do that?$K
$F0$P$FALaguz cannot survive in isolation,$w4
nor can beorc.$w3 If both races are
to thrive, they must learn to coexist.$K$PI have spent many years$w2 searching
for a way to make this happen.$K
$F3$PYou think that laguz and beorc can live
together?$w4 After everything you must
have seen?$w3 I'm impressed.$K
$F0$PIke, $w2you will never truly understand
a matter unless you look at it from
each party's perspective.$K$PAs you say, the laguz are indeed now
persecuted by the beorc.$w3 But long
ago, these roles were reversed.$K
$F3$P...$K$PWhatever happened in the past does not
justify what we do to the laguz now.$K
$F0$P$FSThat is the thinking of an honest man.$w4
Keep things simple and pure. $w2I like that.$K$P$FAStill, the strength of your conviction
comes from your youth$w2 and your
innocence. Trust me: it will be tested.$K$PWhen your journey is over, $w2how
will you be changed?$w5 I pray your
conviction is not lost to despair.$K
$F3$PTalking to you $w2is hard work.$K
$F0$P$FSSomeday, you'll understand.$w4 For now,
my role is simply to deliver you
safely to Begnion.$K$PRanulf has paid me quite handsomely
with money from the king of Gallia
himself,$w3 and I will not let him down.$K
$F3$PWe're out of our element here at sea,$w2
so you're all we have to depend on.$w4
Thank you for your help.$K
$F0$P$=1000I will do what I am able.$K    $R�w�i��b|$B�D-�D��|$<$F1$FCL_IKE|$F4$FCL_SENERIO|...$w2Report details.$K
$F1$PI'm working on them.$K  $R�w�i��b|$B�D-�D��|$<$F1$FCL_IKE|$F4$FCL_SENERIO|...And that's that.$K
$F1$PI see.$K  $R�w�i��b|$B�D-��|$<$F1$FCL_NASIR|$F3$FCL_IKE|$F3$PNasir,$w4 what is it?$K
$F1$PNothing.$w4 Nothing we can do anything
about, at any rate.$w2 We're being
followed$w4 by pirates.$K
$F3$PReally?$K$PI don't see any ships...$K
$F1$PNot by sea.$w2 By air.$w4 Look up.$K
$F3$FD$F6$FCL_IKE|$F6$PAre those...$w4birds?$w4 If they
are, they must be huge...$K$P$F1$FD$F1$FCL_TIAMAT|$F1$PThose are laguz,$w4 Ike.$K$P$F0$FCL_SENERIO|$F0$PRavens from Kilvas.$w4 Their black wings
are an ill omen for all who see them.$K
$F6$FD$F3$FCL_IKE|$F3$PTitania, $w2Soren,$w4 you noticed them
coming as well?$K
$F1$PYes,$w4 Soren and I saw them when we were
discussing our plans from the aft decks.$K
$F3$PI'd heard stories, but...$w3they're really
flying.$w2 Wow.$K
$F4$FCL_NASIR|$F4$PWe're still out of their range, but airborne
foes can be especially troublesome.$K$PI'd prefer to avoid them altogether.$w4
Let's see if we can outrun them.$K$FD
$F1$PFrom what I've been told, the flying
corsairs of Kilvas and Phoenicis are
far more cruel than any beast laguz.$K$P$F3$PWinged pirates...$w2 How am I supposed
to fight against that?$K$P$Ub$HWha-$w4what was that?$K
$F1$POof... $w2It felt like we hit something.$K
$F4$FCL_NASIR|$F4$PBlast...$w4 We've run aground!$w2 We must
be caught on a reef or something!$K$PMove it, lads!$w4 Get the ship free!$K$F4$FD
$F0$PIke, $w2the crows are coming!$K
$F3$PPull everyone together!$w3 Looks like we're
in for a fight!$K    $R�㉺��b|$s1$FS$c1CHIGU|$s1Predictable humans.$w4 Sailed right
into our trap without fail.$K
$c3CROW|$s3Let's finish this quickly!$K
It won't be long before Phoenicis or
Goldoa takes an interest in what's
happening here!$K    $R�㉺��b|$c0IKE|$s0Soren!$w4 Do you have a plan?$K
$c1SENERIO|$s1I've done research in the past.$w4
All members of the bird tribes are
vulnerable to wind magic.$K$PI think it's safe to assume that they
are also as susceptible to arrows as
any other flyer.$K
$s0Wind magic $w2and bows...$K
All right!$w4 Everyone gather your
weapons $w2and prepare to meet
the enemy on the deck!$K$PI want a small group to remain
belowdecks$w2 to protect Princess
Elincia and the crew.$K$PWe've never faced an enemy like this.$w4
I want everyone $w2to stay together.$K
Let's go!$K    $R�㉺��b|$c0JILL|$s0Caught up...at last.$w4
I'll do this on my own.$w4
I will not $w2let them escape!$K$PHuh?$w4 What are those things?$w3
Giant birds?$K$PDisgusting! Could they be...$w2
Are they...$w4bird half-breeds?$K  $R�㉺��b|$c1JILL|$s1You!$w4 Why are you lollygagging about?$w2$K
$c0IKE|$s0Who are...$K
$s1I am Jill Fizzart,$w4 wyvern rider of
Daein,$w2 attached to Commander Haar's
battalion.$w4 I offer a truce!$K$PI cannot sit by $w2and allow a human
vessel to be attacked by sub-human
degenerates!$w4 I $w2will fight with you!$K
$s0We will accept no help from Daein!$K
$s1This is no place for foolish pride!$w4
At this rate,$w2 the sub-humans will
devour you--$K
$s0I will not accept aid$w3 from anyone
who thinks laguz are $w2sub-human.$K
$s1What are you babbling about?$w4 I'm on
your side!$w4 We'll talk $w2after I chase
off these crows!$w4 Bleed the half-breed!$K$d1
$s0Hold it!$w4 What...$w2 What in the
world is going on?$K    $R�㉺��b|$c0JILL|$s0Fa$Fc...$w2ther...$K  $R�㉺��b|$s0$FS$c0CHIGU|$s0Plunder away!$w4 King Naesala$w2
has given us his blessings!$K $R�㉺��b|$c1IKE|$s1Urg...$K
$s0$FS$c0CHIGU|$s0Not used to fighting on these
confined decks, are you, human?$K$PFunny, but I don't feel confined at
all! Without wings, you're nothing
but food for crows!$K
$s1Don't get...$w2ahead of yourself!$K    $R�㉺��b|$c0CHIGU|$s0Ah!$w4 A Gallian?$w4
What are you $w2doing here?$K
$c1LETHE|$s1You're a disgrace to all laguz!$w4
I will not let you $w2continue
like this!$K    $R�㉺��b|$c0CHIGU|$s0G-$w2Gallian!$K
$c1MORDY|$s1Stealing is wrong.$w4 I must punish
you if others will not!$K    $R�㉺��b|$c0CHIGU|$s0$FhArgg...$w4I'm $w2falling...$K $R�w�i��b|$B�D-��|$<$F3$FCL_IKE|$F3$PIs everyone $w2all right?$K$P$F1$FCL_SENERIO|$F1$PI'll check on injuries.$K$P$F1$FD
$F0$FCL_TIAMAT|$F0$PThose crows$w4 make fierce opponents.$K$P$F0$FD
$F3$PNasir, $w2how's the ship?$K$P$F0$FCL_NASIR|$F0$PCompletely immobilized.$w4 We can't shake
free of this reef.$K
$F3$PI feel useless just waiting around here.
There has to be something I can
do to help.$K   $R�㉺��b|$c1MIST|$s1Hey!$w4 Ike!$w4 Where are you going?
Should you be leaving the ship!?$K
$c0IKE|$s0Nothing's getting done sitting around
here.$w3 I just want to go ashore and
see what I can see.$K   $R�㉺��b|$c1NASIR|$s1What?$w4 Hold on, Ike!$K$PYou $w2can't...$w4
That's--$K
$c3MIST|$s3Ah! $w2Ike!$w4 Behind you!$K$d1$d3
$c0REDDRAGON|$s0You there! $w2What are you doing?$K
$Ub$H$c1IKE|$s1Huh?$K
$d1$c1NASIR|$s1This could be trouble...$K    $R�w�i�Ȃ���b|$F3$FCL_IKE|$F0$FCL_REDDRAGON|$F0$PThis is Goldoan territory.$w4
Outsiders are not permitted.$K
$F3$PNo, wait, you don't understand!$w4 Our ship
has run aground.$w3 There's nothing
we can do! We're stuck here!$K
$F0$PThen return to your ship.$w4 What happens
to beorc $w2is none of our affair.$K
$F3$PThat's ridiculous! $w2You're a complete--$K
$F0$PYou have been warned.$w4 You will not
be warned a second time.$K   $R�㉺��b|$c1IKE|$s1Hey!$K
$Ub$H$c0KURTHNAGA2|$s0Cease this at once!$w4 What do you
think you're doing?$K  $R�w�i�Ȃ���b|$F4$FCL_IKE|$F3$FCL_REDDRAGON|$F1$FCL_KURTHNAGA|$F0$FCL_GORT|$F3$PMy... $w2My lord prince.$K$F3$FD
$F1$PMan of the beorc.$w2 My countrymen were
discourteous.$w5 I ask that you forgive them.$K
$F4$PWho are you?$K
$F1$PI am Kurthnaga,$w4 prince of Goldoa.$K
$F4$PThe prince?$w4 Now we're getting somewhere.$K$PThanks to some Kilvas pirates,$w2 our ship's
run aground.$w4 Can you lend us any help?$K
$F1$P...$K
$F4$PWhat is it?$w4 You can't help us, $w2can you?$K
$F1$PI am not used to being addressed in such
a direct manner.$w5 I was...taken off guard.$w4$Fc
My apologies.$K$F1$Fd
$F4$PNo, $w2I didn't--$w4 If anyone should
apologize here, $w2it's me.$K$PMy father had a great deal to say about
my lack of etiquette.$w4 I'm sorry.$w2
I didn't mean to offend you.$K
$F1$P$FSPlease, $w2pay it no mind.$K$P$FAI am more concerned with the
misfortune your journey has met.$K$POf late, the ravens have grown ever
more barbarous, and this cannot stand.$K$PMy father will lodge a formal protest
with Kilvas, I assure you. In the meantime,
we shall help you with your ship.$K$PGareth, $w5direct the others to push
their ship free.$K
$F0$PAt once!$K   $R�㉺��b|$s0$FS$c0MIST|$s0Dragons! They're all dragons! They're
huge!$w2 And so strong! It's incredible!$K
$c2ERINCIA|$s2It's overwhelming...$K
$c1IKE|$s1Yeah...$w2it is.$K$d0$d2
$s0$FS$s0$c0TIAMAT|$s0Goldoa is the land of the dragons.$w2
More than any other laguz tribe, they
are known for their longevity.$K$PI've heard tales of Goldoans still living
who flew the skies when the goddess
herself still walked the land.$K
$s1How is it you know so much about
Goldoa?$K
$s0Everything I've learned comes from
books.$w3 Goldoa itself no longer has
any contact with the outside world.$K$PSeeing them now, it's like a dream...$K
$s1So this is good fortune, is that what
you're saying?$K
$s3$FS$c3MIST|$s3She's saying we got lucky! For once,
your recklessness actually got us
OUT of trouble!$K
$s1What's that supposed to mean?$K$d3$d1$d0
$Ub$H$s0$FS$c0KURTHNAGA|$s0We have moved your ship safely and
without harm to you or your vessel.$K    $R�w�i�Ȃ���b|$F0$FCL_GORT|$F1$FS$F1$FCL_KURTHNAGA|$F3$FCL_IKE|$F1$PMy subjects tell me your ship was indeed
lodged against a reef.$w4 However, there
was no structural damage to your ship.$K$PYou need not interrupt your journey.$K
$F3$P$FSThat's good news. $w2Thank you.$K
$F1$PIs there anything else $w2you require?$w4
If you need food or fresh water, $w2we
can replenish your supplies.$K
$F3$PThat $w2would be most appreciated.$w4
We are beginning $w2to run low on water.$K$PAs for food, any$w3 fruit, meat, $w2fish...$w2
anything fresh would be wonderful.$K
$F1$PIt shall be done.$K$PGareth, will you see to it?$K
$F0$PYes, $w2at once.$K$F0$FD
$F3$P$FAI know that Goldoa does not engage
in trade with other nations,$w4 but will
you accept gold in payment?$K
$F1$P$FSDo not worry about payment.$K
$F3$PBut you've done so much for us when
you could have left us to die out there.$w4
We must repay you somehow.$K
$F1$PSweet courtesy is ever the herald of
hospitality.$w4 Will this suffice to
explain my actions?$K
$F3$PHospitality?$w4 Isn't that for guests?$K
$F1$P$FAAs you know, Goldoa prefers isolation. We
rarely see foreigners,$w2 especially beorc,$w4 and
even more rarely do we treat with them.$K$PChance has brought us together, and I am
grateful for this opportunity.$w4 In fact, I
wish we could feast a while and converse.$K$PHowever, my father would never allow it.$K
$F3$PYou can't expect us to accept so
generous a gift--$K
$F1$P$FSBut I do.$w4 I insist that you consider it
a personal gift from Goldoa's prince.$K$P$FAHowever, $w2I have made you uncomfortable,$w3
so if you feel you must decline...$K
$F3$PNo, of course not.$w4 $FSWe will be$w2
happy to accept your gift.$w4
We appreciate it.$K
$F1$P$FSI'm so pleased you understand.$K
$F4$FCL_TIAMAT|$F4$PIke!$w4 Captain Nasir $w2wants to depart
as soon as possible.$K
$F3$P$FAUnderstood.$K$F4$FD
$F3$PWell then, $w2I beg your leave.$K$P$FSPrince Kurthnaga, $w2I won't forget your
kindness. $w5Thank you!$K$P$F1$PIt was my pleasure.$w4 Take care.$K   $R�㉺��b|$s0$FS$c0KURTHNAGA|$s0Farewell,$w4 beorc!$K$PMay your journey be safe!$K $R�w�i��b|$B�D-�ߌ�|$<$F3$FCL_IKE|$F1$FCL_ERINCIA|$F1$PMy lord Ike, $w2is something amiss?$K
$F3$PFirst, those ravens attack us, and then
a band of Goldoan dragons rescues us.$K$PI can't understand how they are all
considered laguz. Is that strange?$K
$F1$PNo, I see what you're saying...$w4 Just as there
are both good and evil beorc,$w3 there must
be good and evil laguz as well.$K$PBut they are so distinct in appearance...$w3
It is tempting to assume each race is,$w2
as a whole,$w2 intrinsically good or evil.$K
$F3$PAye, that it is. The beast tribes of Gallia
and the dragons of Goldoa seem so
honorable...$K$Pand the birds of Kilvas and Phoenicis
seem so cruel. It seems so easy to
reduce them all to good or evil.$K
$F1$PI'm sure $w2it can't be as simple as
that...$K
$F3$PLook at us beorc:$w4 Daeins are evil,$w2 and
Crimeans are not. It's as simple as that.$K$PWell, wait...$w3 There were those prejudiced
fools we met in port.$w2 They weren't all
that honorable. Maybe you're right.$K$P$F0$FS$F0$FCL_NASIR|$F0$PMuch of what seems good and evil
is simply a matter of perspective, Ike.$K$PMany conditions affect our judgment.$w4
Drawing a definitive line is nigh impossible.$K
$F3$PNasir!$w4 Where $w2have you been?$w5
You vanished without a trace.$K
$F0$P$FAI am$w2 uncomfortable around dragons.$K$PI thought it would be better if I stayed
below in my cabin.$w5 My apologies.$K
$F3$PNow that you mention it, Soren seems
to have disappeared as well.$w4
Have you seen him?$K
$F0$PPerhaps he's feeling nauseated.$w4 For
one unaccustomed to sea travel,$w2
it's not uncommon.$K
$F3$PRight...$w4 I think I'll check up on
him later.$K
$F0$PThe wind is picking up. $w5$FSI believe$w2
I will go and check on the condition of
our sails.$K$PKeep yourselves warm up here. It's a
chill wind that blows in these waters.$K$F0$FD$w4
$F3$PPrincess Elincia, $w2you should be
returning to your cabin.$K
$F1$PWhat about you, my lord Ike?$K
$F3$PI'll stay on deck a while longer.$w5
I$w3 have a lot to think about.$K$P$w5
$F1$PWould you mind$w4 if I stayed here
with you? I won't be any bother.$K
$F3$PHm?$w4 It's all right with me...$K
$F1$P$FSOh, thank you.$K
$=1500  $SD$R�w�i��b|$B�D-��|$<$F6$FCL_IKE|$F6$P...$K
$F7$FCDUMMY|$F7$PAh, $w2Ike!$w4
Grab that boy!$K
$F6$FD$F3$FCL_IKE|$F3$PWhat's going on?$K$P$F1$FCL_SOTHE|$F1$PMm!$K
$F0$FCL_NASIR|$F0$PNo more running for you.$K
$F1$FD$F5$FCL_SOTHE|$F5$P...$K
$F3$PNasir,$w3 who is this?$K
$F0$PA stowaway.$w5 I gather he boarded
the ship at Toha.$K
$F3$PWhat are you doing here? $w2Why did
you sneak aboard the ship?$K
$F5$P...$K
$F3$PYou won't talk?$w4 In that case...$K
$F5$PHm?$K$P$F5$FD$F2$FCL_SOTHE|$F2$P$FcOw...$w3ooouuuch!$K
$F0$PIke,$w4 there's no need to be so rough!$K
$F3$PI'm not going to waste my time
playing games with this urchin.$K$PYou want me to let you go?$w4
Open your mouth $w2and start talking.$K
$F2$POwowow!$w4 Quit it!$w3 I'll talk!!$K
$F2$FD$F1$FCL_SOTHE|$F1$P$Fh...$w2That hurt!$w4 I thought you
were gonna break my face...$K
$F3$PWell?$w4 What's your name?$K
What are you doing here?$K
$F1$P$FdI'm...$w3Sothe.$K
I'm...$w2 I'm a thief, but...$w3 I didn't come
onboard this ship $w2to steal anything.$K
$F3$P...$K
$F1$PStop scowling at me like that! You're
making me uncomfortable.$K
$F0$PIt's not just you. $w2Ike always looks
like that.$w4 Don't mind him; just
keep talking.$K
$F1$PI'm...$w2looking for someone.$w5 I heard
this ship was sailing for Begnion,$w4
so I decided to climb aboard.$K
$F0$PThis person you're after is in
Begnion?$K
$F1$PI don't know. $w5The trail went cold in
Toha, and...$w4I couldn't think of
anywhere else to go from there.$K
$F3$PIs it family?$K
$F1$PHuh?$K
$F3$PThe person you're looking for.$K
$F1$PYeah. $w5I mean, we're not related by
blood or anything, but...$w4we're
definitely family.$K
$F3$P...$K$N$UB$H Aid Sothe   Don't aid Sothe $SE$F3$PAll right.$K
Nasir, $w2my mercenary company will
look after this boy.$w4 He won't be a
burden to you or your crew.$K
$F0$PIf that's what you want to do,$w4
it's fine with me.$K
$F1$PAre you sure?$K
$F3$PYou're going to be put to work.$w4
I hope you're prepared.$K
$F1$P$FSSure,$w3 no problem!$w4 I'll...$w2
I'll do whatever you need!$K $SE$F3$PI wish we could help you, but we
have our own troubles to deal with.$K
$F0$PI see your point...$w4 This is a very$w2
difficult time for all of you.$K
$F1$P...$K
$F0$P$FSI see no other option.$w5 I'll $w2take you
on as a junior member of my crew.$K
$F1$PReally?$K
$F0$PIt's either that or I toss you
overboard, and I suspect you'd
prefer I didn't.$K
$F1$P$FSThank you! $w5I'll repay you somehow!
I swear it!$K
$F0$PDon't worry about the boy, Ike.
We'll take care of him.$K
$F3$PIt's your ship.$w4 You can do as
you please.$K
$F0$PWell then, it's settled.$w5 Sothe, was it?$w3
Come,$w2 and I'll introduce you to the
rest of my crew.$K
$F1$PSure!$K
$F3$P$FSYou're a lucky boy.$K
$F1$PI'm just happy I don't have to
hide anymore!$K $R�w�i��b|$B�D��|$<$F3$FCL_IKE|$F3$PBattle information 13/2.$K $R�w�i��b|$B�D��|$<$F5$FCL_IKE|$F5$P...$K$PVolke?$K
$F4$FS$F4$FCL_VOKE|$F4$PRight here.$K
$F5$FD$F1$FCL_IKE|$F1$PGah!$w2 Where've you been?$K$PYou disappeared the moment we
got on this ship!$K
$F4$PDon't worry about it.$w4 I'll be there
when you need me.$K
$F1$PIt's not me; $w2it's my sister.$w5 You've
never once shown up for a meal,$w3 and
she thinks you're dying of hunger.$K
$F4$PDid we ever eat together$w3 while we
were on land?$K
$F1$PAll right, listen.$w2 Land? $w2Big. $w2Ship?$w2
Small.$w3 It's not the same thing!$K$PI don't want Mist$w3 roaming the ship$w2
with a plate of food anymore. $w2So
please,$w4 eat one meal a day with us.$K
$F4$POne hundred gold.$K
$F1$PYou're going to charge me?$w4 To make
you eat? And that's more than you
charge to pick a lock! $w2Why?$K
$F4$PI don't like large groups.$K$PBye.$w4 Call me $w2if you decide it's
worth it.$K$F4$FD
$F1$P$FhMaybe I should just tell
Mist he's dead...$K  $R�w�i��b|$B�D-��|$<$F3$FCL_IKE|$F3$PDo you have a minute?$K
$F1$FS$F1$FCL_ZIHARK|$F1$POf course,$w4 Commander Ike.$K
$F3$PYou and I haven't had very many
opportunities to talk, and I--$K
$F1$P$FAYou don't think you can trust me?$K
$F3$PNo, it's not that.$K$PI'm just curious--$w3I was surprised
to see anyone in Toha who chose
to fight on the side of the laguz.$K
$F1$PI joined the Toha vigilantes$w3 solely for
the purpose of saving laguz.$K$PI'm not from Crimea, but$FS when I
heard she had joined with Gallia,
I envisioned my perfect world,$K$Pone in which the laguz could live
normal lives, free of oppression.$K$P$FAHowever, when I came to Crimea, I
found things were no different there
than in any other beorc nation.$K
$F3$PIt was the same for me. I couldn't
allow myself to ignore these problems
any longer.$K
$F1$P$FSI'm happy to hear it.$w4 Of all the
beorc I've ever met,$w3 you're the
only one who shares my conviction.$K
$F3$PZihark,$w4 is there...some other reason
you defend the laguz?$K
$F1$P$FAI don't follow you.$K
$F3$PYou see, I was born in Gallia,$w2 or so
I've been told.$w4 I just wondered if
you had a similar reason guiding you.$K
$F1$P...Of course I have my reasons.$w4
Would you be upset $w2if I didn't
want to discuss them?$K
My reasons are...extremely personal.$K
$F3$PNo, $w2it's no problem.$w4 I wanted a
better understanding of what kind of
man you are, and I have that now.$K
$F1$P$FSCan I ask $w2what that is?$K
$F3$P$FSYou are$w3 a good man.$w4
I'm glad to have you along.$K
$F1$PI'm glad to be here. I feel I'm
finally able to do the kind of
good I've longed to do for years.$K $R�w�i��b|$B�D��|$<$F1$Fc$F1$FCL_ELAICE|$F1$POoo...$K
$F3$FCL_IKE|$F3$PYou don't look so well.$w4 Are
you all right?$K
$F1$P$FdI'm...$w2seasick...$K$PWhen I was traveling with$w3 the
merchants, $w2we sometimes
used...ships...$K$PEvery time was the same... Urp...$w4$Fc
I'm...sorry.$K
$F3$PDid you travel with Muston and
the others for a long time?$K
$F1$P$FdAbout four years, all told.$w3 I had just
left home, you see...$w4 I was all
alone, $w2and I couldn't find work.$K$PIn my hometown, $w2I had so many people
I could$w3 depend on...$w2but$w4 once I
left,$w3 everything changed.$K$PIf Muston's group hadn't found me by
the side of the road, I'd probably
be dead by now.$K
$F3$PHm...$w2 You seem to have led quite
an adventurous life. $w2It's a bit$w3
surprising.$K
$F1$PI get that a lot.$K
$F3$PI find it hard to imagine that you
couldn't find work, though. Your
magic skills are amazing.$K$P$F1$P$FSAren't they, though?$w4
Hee hee!$w4 I'm always happy$w3
when people notice...$K$PWhew...$w3 Wow! I feel so much better now.$w4
I'm actually starting to get hungry.$K
$F3$P$FSI'm glad to hear it.$w3 Just stay above deck,$w2
and when you start to feel sick, look off
at the horizon, all right?$K  Yes No  $R�w�i��b|$B�D-�D��|$<$F1$FCL_SENERIO|$F3$FCL_IKE|$F1$PIke,$w3 here's a summary of our last battle.$K$N$UB$H   $F3$P$Fc...$K$P$UB$H    $F1$P$FSThere were no casualties,$w2 and no one
suffered permanent injury.$w4
We fought excellently.$K$P$UB$H   $F1$PThat's all I have to report.$w4
If you'll excuse me...$K     �      t      �     !,   #  "�   0  "$   <  #@   H   �   R  #x   a  %   m  %�   y  &�   �  (x   �  (�   �  -h   �  1   �  8�   �  9D   �  �   �  �   �       �   �    �    4    �  (  T  5  �  B  A�  O  HD  ]  I�  q  H4  �  H(  �  L|  �  L�  �  P\  �  V�  �  H  �  4  �  �  �  �    [d    [�  $  \\  3  [�  B  [`  S  [\  cMS_13_BASE_E MS_13_BASE_O MS_13_BT MS_13_BT_IKE MS_13_BT_MO MS_13_BT_RE MS_13_DIE MS_13_DIE_JILL MS_13_ED_01 MS_13_ED_02 MS_13_ED_02_2 MS_13_ED_03 MS_13_ED_04 MS_13_ED_05 MS_13_ED_06 MS_13_ED_06_2 MS_13_ED_07 MS_13_ED_08 MS_13_EV_01 MS_13_EV_X MS_13_GMAP_1 MS_13_GMAP_3 MS_13_GMAP_4 MS_13_GMAP_6 MS_13_GMAP_7 MS_13_GMAP_8 MS_13_GMAP_9 MS_13_INFO_01 MS_13_INFO_01_02_2A MS_13_INFO_01_02_2B MS_13_INFO_01_02_N MS_13_INFO_01_02_Y MS_13_INFO_02 MS_13_INFO_03 MS_13_INFO_04 MS_13_INFO_05 MS_13_OP_01 MS_13_OP_02 MS_13_OP_03 MS_13_OP_XX MS_13_REPO_BEGIN MS_13_REPO_DIE MS_13_REPO_END MS_13_REPO_NODIE MS_INFO_13_02_N MS_INFO_13_02_Y 