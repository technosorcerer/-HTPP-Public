  2�  0$                       $R�w�i�Ȃ���b|$F1$FCL_DARKKNIGHT|$F3$FCL_ENA|$F1$PWhy$w3 did you return to Crimea?$w4
You had the perfect opportunity $w2to escape.$K
$F3$P...$w2I'm going to the capital.$K
$F1$PNo. You are not.$w4 The king $w2has ordered
me to put an end to you.$K
$F3$PI thought as much...$w2$Fc So be it.
I am prepared.$K
$F1$PWill you not resist?$K
$F3$PI do not believe $w2I could prevail
against one of your power.$K
$F1$PHow extremely$w3 frank.$K
$F3$PMy only wish was to be beside the
one I love. If that is not to be, then$w4 it
matters not what happens to me.$K
$F1$PAs my last act of compassion, I shall make
your end a swift and merciful one.$w4
Do you have any $w2final words?$K
$F3$P$Fd...If you see Nasir,$w4 tell him that Ena
was sorry.$K
$F1$PIf I have the opportunity, $w2I will so tell him.$w4
Rest in peace.$K   $R�㉺��b|$s0$Fc$c0ENA|$s0...My...$w4love...$K
$Ub$H   $R�㉺��b|$c1IKE2|$s1Turn and face me,$w4 Black Knight!$K
$c0DARKKNIGHT|$s0Hmph.$w4 I've been waiting for you, child.$K    $R�w�i�Ȃ���b|$F0$FCL_DARKKNIGHT|$F4$FCL_IKE2|$F4$PAh!$w4 Did you kill that girl?$K
$F0$PDespite my promise, the blow was not
clean.$w4 She $w2breathes still.$K
$F4$PI'll take her.$K
$F0$PYou'll have to do so by force. You brought
the sacred sword Ragnell,$w2 did you not?$K
$F4$PIt's right here. If using it is $w2the only
condition I need fulfill to defeat you,$w3
I will not hesitate!$K
$F0$PIt appears you've grown smarter.$w3 Good.
There is no challenge in killing a fool.$w4
Shall we $w2begin?$K  $R�w�i�Ȃ���b|$F0$FCL_DARKKNIGHT|$F4$FCL_IKE2|$F4$PAh!$w4 Did you kill that girl?$K
$F0$PDespite my promise, the blow was not
clean.$w4 She $w2breathes still.$K
$F4$PI'll take her.$K
$F0$PYou'll have to do so by force. You brought
the sacred sword Ragnell,$w2 did you not?$K
$F4$PIt's right here. If using it is $w2the only
condition I need fulfill to defeat you,$w3
I will not hesitate!$K
$F0$PIt appears you've grown smarter.$w3 Good.
There is no challenge in killing a fool.$w4
Shall we $w2begin?$K  $R�w�i�Ȃ���b|$F0$FCL_DARKKNIGHT|$F3$FCL_IKE2|$F4$FCL_MIST|$F4$PBrother!$K
$F3$PMist? No! Stay back!$K
$F4$PI...$w4 I will$w4 fight you!$K$PI'll never$w3 let you kill my brother!$K
$F3$PMist,$w3 you--$K
$F0$PGawain's daughter, eh?$w4 Good. Now I can
pull out the entire family tree by the root.$K
$F3$PYou're not to interfere, Mist!$w4 This craven
wretch$w3 is mine!$K
$F0$PHmph!$w3 Do as you will.$w4
This time, $w2we begin in earnest!$K $R�㉺��b|$c0DAYNE3|$s0Protect the Black Knight!$K
$c1DARKKNIGHT|$s1Do not interfere!$w4 This man $w2is my
prey!$w4 I need no assistance.$K
$s0Oh!$w4 Then...$w2uh... Hey, get that girl!$w4
Kill her before she flees!$K
$d1$c1IKE2|$s1Get out of here, Mist!$K
$d0$c0MIST|$s0No!!$w4 I'm not leaving you!$w4 I can
protect myself.$w4 I won't run away!$K    $R�㉺��b|$c0DAYNE3|$s0Protect the Black Knight!$K
$c1DARKKNIGHT|$s1Do not interfere!$w4 This man $w2is my
prey!$w4 I need no help!$K
$s0Uh...$w4 Yes, sir! $w2Understood!$K
$d1$c1IKE2|...$K  $R�㉺��b|$s1$Fh$c1IKE2|$s1Urg$w2gg...$w5I...$w2 I'm...$w3$Fc
not...$w4strong...$w2enough...$K
$c0DARKKNIGHT|$s0...$w4
Good-bye.$K $R�㉺��b|$c0DARKKNIGHT|$s0What an odd fate.$w4 This will be the
third time I have defeated you.$K$PThe first was in the forest of Gallia.$w4
The second at Delbray in Crimea.$K
$c1IKE2|$s1We've met twice, and I've lost twice.
But the third time$w4 will be different.$K
$s0Oh?$K
$s1My sword-fighting skills were given to
me by my father.$w4 If I stay true to
them,$w2 I cannot lose.$K
$s0Did you never think that $w2using your
father's techniques on the man who
killed him$w4 would be futile?$K
$s1My father robbed himself of using his
stronger arm. If he had, $w2he would
not have lost to the likes of you.$K
$s0Hah...$w3 You think so?$w5
Let us test your stronger arm then.$K$PCome, son of Gawain...$w4 Show me
your strength.$K   $R�㉺��b|$c0MIST|$s0...Sniff...$w4sniff...$K
$c1DARKKNIGHT|$s1Do you tremble in fear, little daughter
of Gawain?$K$PHow...entertaining.$w4 But if you value
your life, $w2you will leave this
place at once.$K
$s0You...$w2you took my brother$w2
and my father! My sword may not
even scratch you, but I don't care.$K$PThis one blow...$w2will contain...$w2
all my anger...$w3and all my pain...$w4
Rrrraaaaa! I'll kill you!$K    $R�㉺��b|$c0DARKKNIGHT|$s0Will you flee?$w4 How appropriate.$w2
Tuck tail and run, child of Gawain!
It is what dogs do best, after all.$K$PI like how you tremble with fear at
the realization that you are no match
for me. It suits you.$K
$c1IKE2|$s1Foul villain!$K$PI do not flee.$w4 I will never turn
my back on you and run away!$K   $R�㉺��b|$c0NASIR|$s0Ike!$K
$c1IKE2|$s1Is that you, Nasir?$w4 What $w2are you
doing here?$K
$s0Ike, $w2I'll take over from here.$w4
Hurry and leave this place.$K
$s1You know $w2I can't do that.$K
Besides, $w2the Black Knight can't
be defeated--not without this blade.$K
$s0Ike,$w4 I cannot allow you to die here.$K$PPlease...$w4take care of the girl, Ena.$K $R�㉺��b|$c0DARKKNIGHT|$s0Nasir...$w4I didn't expect to see
you here. What a fool.$K  $R�㉺��b|$s1$Fc$c1ENA|$s1...Aahh...$K $R�㉺��b|$s1$Fh$c1ENA|$s1...$FdAh!$w4 Nasir!$K    $R�㉺��b|$c0DARKKNIGHT|$s0Uargh...$w4 Yet, $w2that's
not nearly enough...$K   $R�㉺��b|$c0DARKKNIGHT|$s0What's this?$w4 It can't be...
this entire castle...$w2I...$K$PUngh!$w2 I-I can't move! This c-can't
be...happening...$K
$d0$s0$Fc$c0NASIR|$s0...$K$Fh
Ike. Now's your chance...$w4
Take...Ena.$w4 Take care of Ena!$K
$c1IKE2|$s1Nasir!$K
$d0$c0ENA|$s0Nasir...$K  $R�㉺��b|$c0DARKKNIGHT|$s0You've grown stronger...$w4
I...commend you...$K    $R�㉺��b|$c0IKE2a|$s0Haaaah... Haaaaa...$K$d0
$c1DAYNE3|$s1Th-$w2the Black Knight's fallen!$w4
How can this be?$K$PD-don't... $w2Don't think you're going
to walk out of here, though!$w4
Now! $w2Activate the traps now!$K   $R�㉺��b|$c0IKE2|$s0What's going on? $w2This rumbling...$K    $R�㉺��b|$c1NASIR|$s1Ike!$w4 The castle's collapsing!!$w4
Get out now!$K  $R�㉺��b|$s1$Fc$c1ENA|$s1...$K$Fd$w4$P    $R�㉺��b|$c0ENA|$s0...Nasir?$K
$c1NASIR|$s1Ena!$K $R�㉺��b|$c0IKE2|$s0Mist, $w2we have to go!$K
$c1MIST|$s1A-$w3all right...$K
$s0Hurry!$K  $R�w�i��b|$B���-��-��|$<$F3$FCL_IKE2|$F3$P...Father...$w4
...I...$w3finally...$K$P$Ub$HI stopped him...$w4
$FcFather...$K
$F1$FS$F1$FCL_MIST|$F1$PB-$w2Brother!$w4 Thank goodness...$w4
I'm so happy$w4 you're alive!$K
$F3$P$Fd$FSMist...$w4 I $w2avenged Father.$K
$F1$PI know.$K
$F3$P$FAEven now, though, $w2I'm not as good
as Father was.$w4 There's no way I could
ever defeat him...$K$PDefeating the Black Knight was my way...
I wanted to show him$w4 how strong
Father really was.$K
$F1$PI know, Ike.$w4 I know.$K
$F3$P$FSOur Father was the best in the world...$w4
$FcA great man.$K$Fd$P$F1$PThat's right!$w4 Dad was great...$w4
and so was Mom...$K$PAnd $w2so are you, Brother.$w4 I $w2love you all!$w3
I'm so proud of my fantastic,$w2
wonderful family!$K $R�w�i��b|$B���-��-��|$<$F3$FCL_IKE2|$F4$FS$F4$FCL_MIST|$F1$FS$F1$FCL_TIAMAT|$F0$FCL_SENERIO|$F1$PIke!$w4 Mist!$w4 Both of you...$w2
You did so well...$K
$F0$P$FS...$K
$F3$P$FSI really had you worried, didn't I?$w4
But $w2now it's--$K
$F1$PDon't say anything.$w4 I understand.$K
$F3$PLet's get back to the others...$w4
$FcI can't $w2do anything else today.$K
$F4$P$FSRight!$K
$=1500    $=0700$R�w�i��b|$B�V��-��|$<$F3$FCL_IKE2|$F1$FCL_TIAMAT|$F3$PHow's she doing?$K
$F1$P$FSShe's going to be all right.$w4
She's sleeping in the back.$K
$F3$PAnd Nasir?$K
$F3$FA$F1$PHe's there with her.$w4 He's $w2been taking
care of her the entire time.$K
$F3$PI see.$K    $=0700$R�w�i��b|$B�V���l�p-��|$<$F3$FCL_IKE2|$F1$FCL_NASIR|$F3$PNasir.$K
$Ub$H$F1$PIke.$w4 I am sorry for escaping and...
causing all the problems I did.$K$P$FcWhen we arrived in Crimea, I sensed
Ena...$w4 I had to go $w2and look for her.$K
$F3$PIs that so?$K
$F1$P$FS$FdYou...$w4you saved her, didn't you?$w4
I don't know how to thank you.$K
$F3$PI'm not worried about it. $w2I just want
you to talk to me.$w4 What's the connection$w2
between you and Ena?$K
$F1$P$FAEna...$w4is my only granddaughter.$K
$F3$PYour granddaughter?$w4 That can't be.$w4
You're not old enough to...$K
$F1$P$FSIt may be difficult for you beorc to believe,
but...$FA$w3 We $w2of the dragon tribe live for
a very, very long time.$K$PWhen we reach a certain maturity, we stop$w4
showing almost all signs of further aging.$K$PFor example, $w2do you remember
Prince Kurthnaga whom you met in
Goldoa?$K
$F3$PYeah, $w2he was a nice kid.$K
$F1$PThe prince is the youngest in all of Goldoa,
yet for all his apparent youth, he's at least
a hundred years old.$K
$F3$PA hundred...$K
$F1$PIke...$K
$F3$PYes?$K
$F1$PWhy $w2did you save Ena?$w4 She was$w2 your foe,
after all...$K
$F3$PYou were willing to put yourself in danger
so she could escape.$w4 I assumed
she must be dear to you.$K
$F1$PYou did that for a dirty traitor?$w4 Under the
guise of providing information to Gallia,
I gave the same information to Daein.$K$PI also $w2took Mist's medallion and$w3 gave
it to King Ashnard...$w5 And even so,$w3 you...$K
$F3$PYou $w2helped us many times over.$w5
If there are reasons for all this, $w2would
you tell me about them?$w4 I'd like to help.$K
$F1$PI cannot.$w4 $FcAt least $w2not yet...$K
$F3$PThat's not the answer I wanted, Nasir.$K
$F1$P$FdPlease. I want you to believe me.$w4
I $w2am not your enemy.$K$PKing Daein had Ena with him.$w2 For her sake,$w4
there was nothing else I could do.$w3
Forgive me.$K
$Ub$H$F3$PTell me, $w2are you willing to display
your loyalty?$K
$F1$PWhat do you mean?$K
$Ub$H$F3$PAshnard is in the Crimean capital.$K$PIf we hope to defeat him,$w3 it would help to
have the cooperation of one who's been
close to him.$K$P$FSIf you're not our enemy, $w2then prove it
by aiding us.$K
$F1$P$FSAll right,$w4 I understand.
On the strength of your belief in me,$w4
I swear$w4 I will not betray you again.$K
$F3$P$FAThere's one other thing $w2I need to hear.$w3
How much do you know about the
medallion?$K$PDid you realize what it was $w2when you
gave it to Ashnard?$K
$F1$P$FAI'm fairly sure that I know more about it
than you do.$K$PI can't go into details, but...$w3 Merely
gaining possession of the idol does not
allow King Daein to release the dark god.$K
The reason for that is--$K
$F3$PThe only one who can sing the galdr of
release $w2is a girl named Altina. $w1Right?$K
$F1$PThat's correct.$w4 I, too, $w2investigated Palmeni
Temple.$K
$F3$PYet $w2King Daein doesn't know that, and he's
kidnapped Leanne. $w5Based on what happened
in the past, $w2who knows what he may do...$K
$F1$PEarlier, I was able to speak briefly with Ena.$K
It sounded like she knew where the heron
princess is being held.$w4 When she awakes,$w2
we shall ask her about it.$K
$=2000  $=0700$R�w�i��b|$B�V���l�p-��|$<$F3$FCL_IKE2|$F1$FCL_TIAMAT|$F1$PIke. $w2She's awake.$K
$F3$PGood.$K$F1$FD$w6
$F0$FCL_ENA|$F3$PHow are you feeling?$K
$F0$PWhere $w2am I?$K
$F3$PIn our camp.$K
$F0$P...$w4You saved me, didn't you?$w4
Why?$K
$F3$PBecause Nasir asked me to.$K
$F0$PWhat?$w4 Where is he?$K
I...$w2I must speak to him!$K
$F3$PNasir $w2is dead...$K
$F0$PWhat?$K
$F3$PHe protected me $w2and engaged the
Black Knight.$w4 The castle fell around
them both...$K
$F0$PIs that...$w4so...$w5
So,$w4 it wasn't $w2a dream...$w4$Fc
...$K
$F3$PJust who...$w2who were you to him?$w4
Why were you serving King Daein?$K
$Ub$H$F0$PI am Ena...$w4 He... $w5Nasir was $w2my grandfather.$K
$F3$PYou're Nasir's granddaughter?$K
$F0$PIt seems impossible for beorc to
believe it, but we $w2of the dragon
tribe live for thousands of years.$K$POnce we reach a certain maturity,$w4
we show no further outward signs of
aging.$K
$F3$PA thousand years... I can't begin to
imagine.$K
$F0$PAnd...$w2um...$w4about Nasir...$w3
You must be aware that he betrayed you.$K$PAnd yet $w2you saved me. I, who had
once been your enemy.$w3 Why?$K
$F3$PNasir helped us time and time again.$w4
No matter what, $w2I couldn't see him
as a true enemy.$K$PIf there are reasons for all this, $w2would
you tell me about them?$w4 I'd like to help.$w5
In Nasir's stead.$K
$F0$P$FcI...$w2I can't tell you now.$K
$F3$PThat's not the answer I was hoping for.$K
$F0$P$FdHowever, $w2in payment of my debt to you,
I can provide information. I will tell you
where the heron princess is being held.$K
$F3$PAh. That's a good start.$K
$=2000      0           �     �   )  �   9     I  �   Y  l   i  �   y  �   �  �   �      �      �  p   �  L   �  x   �  �   �      �    �  %  )�  5  �  E  	�  U  
�  c      q  0  }  h  �  �  �  �  �  �  �MS_29_BT_IKE MS_29_BT_MIST MS_29_DIE_IKE MS_29_ED_01_01A MS_29_ED_01_01B MS_29_ED_01_02A MS_29_ED_01_02B MS_29_ED_01_03A MS_29_ED_01_03B MS_29_ED_01_03_2A MS_29_ED_01_03_3A MS_29_ED_01_04A MS_29_ED_01_04B MS_29_ED_01_05A MS_29_ED_01_05B MS_29_ED_01_06B MS_29_ED_01_07B MS_29_ED_02 MS_29_ED_03 MS_29_ED_04_01A MS_29_ED_04_01B MS_29_ED_04_02A MS_29_EV_04_A MS_29_EV_04_B MS_29_OP_01 MS_29_OP_02 MS_29_OP_03 MS_29_OP_04_A MS_29_OP_04_B MS_29_OP_05_A 