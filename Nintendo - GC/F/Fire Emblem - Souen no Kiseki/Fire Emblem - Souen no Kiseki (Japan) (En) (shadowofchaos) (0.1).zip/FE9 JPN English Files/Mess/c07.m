  Y/  V       #                $RGMAP��b|$O3$GThe continent of Tellius,$w5 blessed by the
goddess. To the northwest lies the land of
Crimea,$w4 home of the Greil Mercenaries.$K  $RGMAP��b|$O3$GWithout warning, Crimea's eastern neighbor,$w2
the kingdom of Daein, $w2launches an attack
on Crimea's capital city of Melior.$K    $RGMAP��b|$O3$GIke leads a handful of mercenaries to Melior$w2
to confirm Soren's news of the attack.$K$PEn route,$w3 they happen upon a young woman,
unconscious but unharmed. Fearing for her
safety, they take her to their stronghold.$K   $RGMAP��b|$O3$GWhen she awakens, the woman gives her
name as Elincia$w3 and lays claim to the
title of princess of Crimea.$K$PShe relates the sad tale$w2 of her flight from
Crimea$w4 and of her parents' murder at the
hands of Ashnard, king of Daein.$K$PThe Greil Mercenaries answer Princess
Elincia's plea for help and $w2agree to
escort her to the kingdom of Gallia.$K  $RGMAP��b|$O3$GLocated to the southwest of Crimea,$w2
Gallia is home to the laguz, a race quite
unlike Ike and his fellow beorc.$K $RGMAP��b|$O3$GCrimea and Gallia$w2 have long struggled
to overcome their differences.$K$PIn recent years,$w2 the two kingdoms
have done much to ease the prejudice
between the laguz and beorc factions.$K
Their combined efforts have forged a
bond of trust and friendship that may
yet overcome years of intolerance.$K    $RGMAP��b|$O3$GIke and company$w2 escape the Daein army,
abandoning their longtime base. From there,
they begin the long march toward Gallia.$K$PTheir task clear and their destination far,$w3
they slip into an ocean of trees.$K    $R�w�i��b|$B���C|$<$F1$FCL_GATRIE|$F1$PBlazes,$w4 why $w2does it have to be so
blamed humid?$w4 If we weren't being chased,$w2
I'd strip off this armor $w2here and now!$K
$F4$FCL_TIAMAT|$F4$PThen I'm almost glad that we ARE being
pursued. $w2I suppose you'll have to grin
and bear it, won't you?$K
$F1$P$FhHm, $w2I suppose I will.$K
$F4$P$FSRight. $w2So enough of your griping.$w4
You're merely wasting energy.$K$w4$FA$PStill, $w2this heat is appalling.$K
$F1$FD$F0$FCL_CHINON|$F0$PDense forests such as these $w2are
not made $w2for us delicate humans.$w4
The sub-humans love 'em, though.$K
$F3$FCL_IKE|$F3$PThese$MC...$MDsub-humans$MC...$MD$w2 Are they really
so different from us?$K
$F0$PWhat, you mean to tell me$w2 you've
never seen a beast-man before?$K
$F3$PNo, $w2never.$K
$F0$P$FSWell, I have.$w4
They're a hairy bunch, I'll tell you.$K$PAnd ugly as sin, too. $w2Their faces are
all fangs and whisker.$w4 Their claws are like
daggers,$w2 razor sharp$w2 and deadly.$K$PAnd even though $w1they can speak our
language, $w2they're beasts through and
through.$w4 Savages, every one.$K
$F3$PAre there more than one type?$K
$F4$FD$F4$FCL_SENERIO|$F4$PThe ones Shinon calls "sub-humans"$w2
can be divided into three groups, each one
named for its physical characteristics.$K$PFirst, the beast tribe,$w2 next, the bird
tribe,$w2 and finally, $w2the dragon tribe.$w4
They are traditionally called "laguz."$K$PThe laguz tribe residing here in Gallia
is the beast tribe,$w2 who possess those
feline qualities of which Shinon spoke.$K
$F0$PTo the south are the islands where the
bird-men live.$w2 The dragons are in Goldoa.$w4
It's something $w2every mercenary should know.$K$PLooks like you $w2know even less$w2 than
I gave you credit for, $w2Ike, my boy.$K
$F3$PHm$MC...$MD$w6 Perhaps.$K
$F4$P$MC...$MD$w1A little farther, and we'll be
out of these trees, $w2Ike.$K
$F0$PReally?$w4 That means$w2 Gallia proper!$w4
Compared to this forest, $w2even a kingdom
of half-breeds $w2will seem like heaven.$K
$=0800    $R�w�i��b|$B�X-��|$<$F1$FCL_MIST|$F1$PHaa$MC..$MD$w4huu$MC...$MD$w3
It's so$MC...$MD$w2wet and sticky$MC...$MD$w4
This forest is so hot$MC...$MD$K
$F3$FCL_IKE|$F4$FCL_TIAMAT|$F4$PAre you all right, $w2Mist?$w4
Do you want to rest?$K
$F1$PUh, $w2uh-uhn. $w2I'm all right.$K
But what about you, Titania?$w2
Isn't all that armor hot?$K
$F4$PDaein is hot on our trail, $w2so it would
not be wise to take it off. What if we were
surprised? I'd be at a serious disadvantage.$K
Still, $w2this heat is appalling$MC...$MD$K
$F3$PIs Gallia $w2beyond this forest?$K
How do the people who live here$w2
tolerate this heat?$K
$F1$FD$F0$FCL_SENERIO|$F0$PGallia is a country of sub-humans.$K
The climate they prefer $w2is quite
different than what we would choose.$K
$F3$PThese$MC...$MDsub-humans$MC...$MD$w2 Are they really
so different from us?$K
$F0$PThese sub-humans,$w2 or "laguz,"
can be divided into three groups, each one
named for its physical characteristics.$K$PFirst, the beast tribe,$w2 next, the bird
tribe,$w2 and finally, $w2the dragon tribe.$K$PThe bird tribes live on the islands south
of Tellius.$w2 The dragons live to
the south as well, in Goldoa.$K$PThe laguz residing here in Gallia are
part of the beast tribe,$w2 who possess
feline qualities$MC--$MDlike razor-sharp fangs.$K
$F3$PThe beast tribe$MC...$MD$K
$F1$FS$F1$FCL_MIST|$F1$PIke!$w4 Everyone's saying we're almost
out of the sea of trees. Is it true?$K
$F4$P$FSOnce we cross that river ahead,$w2
we'll be in Gallia.$K
Just a bit more now. $w2Step lively!$K
$=0800   $R�w�i��b|$B�V���l�p-��|$<$F1$FS$F1$FCL_PRAGUE|$F4$FCL_DAYNE2|$F4$P$MC...$MDAnd that's when we lost track of them.$w4
I assigned a squad to pursue them and
returned so I could give you this report.$K
$F1$PUnderstood. $w2You may step down.$K$F4$FD
$F1$PSo Princess Elincia is making her way
through the forest to Gallia$MC...$MD$w2$K$PEna!$K
$F4$FCL_ENA|$F1$PIt appears your advice was sound.$w4
Well done.$w3 You have earned my praise.$K
$F4$P$FcThank you.$K
$F1$PWhen the king assigned me a tactician,$w3
I wondered what I had done to lose
his trust. When I saw it was a young girl,$K$PI burned with anger at the king's judgment.
Still, it's worked out better than I had
expected. $w2Keep up the good work.$K
$F4$P$FdOf course.$K$F4$FD
$F1$PNow then,$w3 it's time for the hunt
to begin.$K
$=0600 $R�w�i��b|$B�X�𔲂���|$<$F1$FCL_GREIL|$F1$PHold it right there, everyone.$w4
We're coming to $w2the edge of the forest.$w4
Form up. Combat positions.$K
$F3$FCL_TIAMAT|$F3$PI don't suppose $w2our Daein pursuers
were willing to let us just slip away.$K
$F4$FCL_SENERIO|$F4$PThere is no doubt $w2that they will attack
again.$w4 Without knowing their numbers,$w2
it is difficult to advise a course of action.$K
$F1$PTake your best guess, Soren.$K
With the limited information we have,$w2
what is the best way to proceed?$K
$F4$P$MC...$MD$w2Some of our group cannot fight.$w2
If we are caught, $w2we'll have a difficult time
defending them and attacking the Daeins.$K$PI propose we separate into two groups:$w2
a small fighting force to engage the enemy
and buy the main group some time,$K$Pand the rest of us$MC--$MD$w2who will escort
the princess to Gallia at full speed.$K
$F0$FCL_OSCAR|$F0$PYou want to divide our combat strength?$w4
The main force aside, $w2don't you think the
risk to the smaller group is too high?$K
$F4$PI believe $w2this is the only way to achieve
our goal$w4 and keep casualties
to a minimum.$K$PIt's possible $w2there's an ambush waiting
for us at the edge of the forest.$w5$K$PIf we proceed with no plan, $w2we may be
caught between the pursuit $w2and the ambush,$w4
which would be the end of us all.$K
$F1$PLooks like we've no choice but to
give it a go.$K
$F0$P$FD$F3$P$FD$F4$P$FD$N$UB$H $R�w�i��b|$B�X�𔲂���|$<$F1$FCL_GREIL|$F1$PHold it right there, everyone.$w4
We're coming to $w2the edge of the forest.$w4
Form up. Combat positions.$K
$F3$FCL_TIAMAT|$F3$PI don't suppose $w2our Daein pursuers
were willing to let us just slip away.$K
$F4$FCL_SENERIO|$F4$PThere is no doubt $w2that they will attack
again.$w4 Without knowing their numbers,$w2
it is difficult to advise a course of action.$K
$F1$PTake your best guess, Soren.$K
With the limited information we have,$w2
what is the best way to proceed?$K
$F4$P$MC...$MD$w2Some of our group cannot fight.$w2
If we are caught, $w2we'll have a difficult time
defending them and attacking the Daeins.$K$PI propose we separate into two groups:$w2
a small fighting force to engage the enemy
and buy the main group some time,$K$Pand the rest of us,$w2 who will escort
the princess to Gallia at full speed.$K
I believe $w2this is the only way to achieve
our goal$w4 and keep our own casualties
to a minimum.$K$PI suspect $w2that there may be an ambush
awaiting us at the edge of the forest.$w5$K$PIf we proceed with no plan, $w2we may be
caught between the pursuit $w2and the
ambush,$w4 which would be the end of us all.$K
$F1$PGood thinking,$w2 Soren.$w4 I guess that's the
best we can do with what little we know.$K
$F3$P$FD$F4$P$FD$N$UB$H $F1$PAll right, $w2let's split up.$w4 The diversionary
team will be $w2Gatrie, $w2Shinon, $w2and me.$K$PThe rest of you guard Princess Elincia$w2
and proceed to Gallia straightaway.$w2
Got it?$K
$F3$FCL_IKE|$F3$PAre you sure $w2you're taking enough men?$K
$F0$FCL_CHINON|$F0$PIdiot pup.$w4 Smaller numbers $w2mean better
mobility.$w4 Your time would be better spent$w2
worrying about yourself than about us.$K
$F3$P$MC...$MD$K$F0$FD$F3$FD
$F1$PListen up! $w2This will probably prove to be$w2
the biggest fight $w2this company's faced.$K$PRemember$MC--$MDyou've got only one life.$w4
I don't want any of you dying on me.$K$PIn times like these, it matters not$w2 what
our blood ties are.$w4 We are family.$K$PIf you don't want to cause your family any
grief, $w2then live!$K$PIke $w2will be commanding the main force.$w4
Titania, you're his support.$w4 All right,$w2
let's move out!$w4 See you all in Gallia!$K   $F1$PAll right, $w2let's split up.$w4 The diversionary
team will be $w2Shinon $w2and me.$K$PThe rest of you guard Princess Elincia$w2
and proceed to Gallia straightaway.$w2
Got it?$K
$F3$FCL_IKE|$F3$PAre you sure $w2you're taking enough men?$K
$F0$FCL_CHINON|$F0$PIdiot pup.$w4 Smaller numbers $w2mean better
mobility.$w4 Your time would be better spent$w2
worrying about yourself than about us.$K
$F3$P$MC...$MD$K$F0$FD$F3$FD
$F1$PListen up! $w2This will probably prove to be$w2
the biggest fight $w2this company's faced.$K$PRemember$MC--$MDyou've got only one life.$w4
I don't want any of you dying on me.$K$PIn times like these, it matters not$w2 what
our blood ties are.$w4 We are family.$K$PIf you don't want to cause your family any
grief, $w2then live!$K$PIke $w2will be commanding the main force.$w4
Titania, you're his support.$w4 All right,$w2
let's move out!$w4 See you all in Gallia!$K   $F1$PAll right, $w2let's split up.$w4 The diversionary
team will be $w2Gatrie $w2and me.$K$PThe rest of you guard Princess Elincia$w2
and proceed to Gallia straightaway.$w2
Got it?$K
$F3$FCL_IKE|$F3$PAre you sure $w2you're taking enough men?$K
$F0$FS$F0$FCL_GATRIE|$F0$POf course!$w4 The commander and I together$w2
can wipe out $w2one or two hundred of
those Daein mice $w2without breaking a sweat!$K
$F1$PIn this type of battle, $w2smaller numbers
mean greater mobility.$K
$F3$PI got it.$K$F0$FD$F3$FD
$F1$PListen up! $w2This will probably prove to be$w2
the biggest fight $w2this company's faced.$K$PRemember$MC--$MDyou've got only one life.$w4
I don't want any of you dying on me.$K$PIn times like these, it matters not$w2 what
our blood ties are.$w4 We are family.$K$PIf you don't want to cause your family any
grief, $w2then live!$K$PIke $w2will be commanding the main force.$w4
Titania, you're his support.$w4 All right,$w2
let's move out!$w4 See you all in Gallia!$K  $F1$PAll right, $w2let's split up.$w4 I'll handle
the diversionary duties myself.$K$PThe rest of you guard Princess Elincia$w2
and proceed to Gallia straightaway.$w2
Got it?$K
$F3$FCL_IKE|$F3$PFather!$w4 That's impossible!$w2
No matter how good$MC...$MD$K
$F1$PThere's no need to worry, Ike.$w4 I need
you to focus on getting yourself, the
princess, and everyone else to Gallia safely.$K
$F3$PFather$MC...$MD$K$F3$FD
$F1$PListen up! $w2This will probably prove to be$w2
the biggest fight $w2this company's faced.$K$PRemember$MC--$MDyou've got only one life.$w4
I don't want any of you dying on me.$K$PIn times like these, it matters not$w2 what
our blood ties are.$w4 We are family.$K$PIf you don't want to cause your family any
grief, $w2then live!$K$PIke $w2will be commanding the main force.$w4
Titania, you're his support.$w4 All right,$w2
let's move out!$w4 See you all in Gallia!$K $R�w�i�Ȃ���b|$F3$FCL_IKE|$F3$PSo $w2they're waiting for us after all$MC...$MD$K
$F4$FCL_SENERIO|$F4$PThere are$MC...$MD$w2more of them than
I'd imagined there would be.$K$PI thought they would have been
spread out across the forest border$MC...$MD$w4 I
didn't expect to see so many$w2 in one place.$K
$F3$PDo we rethink our strategy?$K
$F4$PNo, $w2we've already split up.$w2
It's too late to reconsider now.$K
$F3$PIsn't there some way $w2we can at
least get the princess, Mist, and Rolf$w3
to the far shore safely?$K
$F4$PThere are two bridges$MC...$MD$w4
This thicket $w2extends to the edge
of the westernmost bridge.$K$PIf we can use the trees as cover,$w3
we might be able to reach the bridge
undetected.$K$PFrom there, $w2we can launch a
surprise attack.$K
$F3$PWe'll be creating a diversion, $w2right?$K
$F4$PCorrect.$K$PWhile we keep the enemy's attention,$w2
the princess and the others$w2
can cross the bridge to safety.$K
$F3$PWe've no time for discussion.$w4
That's the plan we go with.$K
$F0$FCL_ERINCIA|$F0$PMy lord Ike, $w2I$MC...$MD$w4
I $w2will fight with you!$K
$F3$P$MC...$MD$w1No, $w2you won't.$K
$F0$PMy lord?$K
$F3$PI cannot let you expose yourself
to danger of any kind.$K$PEveryone here $w2is risking his life
to ensure your safety.$K$PIf you understand that,$w2 you'll
cooperate and do as I ask.$K
$F0$PI$w2 see$MC...$MD$w5
I will do my part.$K
$F4$P$MC...$MD$K
$F0$FD$F4$FD$F4$FCL_TIAMAT|$F4$PIt's settled then.$K
$F3$PRight! $w2Let's break through
their lines!$K
$F1$FCL_MIST|$F0$FCL_LOFA|$F3$PMist!$w3 Rolf!$w4
Take care of the princess.$w4
Do not $w2let yourselves be seen!$K
$F1$PRight!$w4
Be careful, $w2everyone!$K
$F0$PLeave it to us, Ike!$w4 We'll just pretend
it's a game of hide-and-seek.$w3 And
I never lose at hide-and-seek!$K   $R�w�i�Ȃ���b|$F3$FCL_IKE|$F3$PEveryone ready?$w3 Let's go!$K  $R�㉺��b|$c0TIAMAT|$s0Ike, I want you to be careful.$w4 At
times like these, $w2if you're not used to
combat, it's easy to be impatient$MC...$MD$K
$c1IKE|$s1Titania$MC...$MD$w4 Please take care of the
princess $w2and the others.$K
$s0I will. $w2Don't worry.$K   $R�㉺��b|$c0IKE|$s0Soren, $w2I want you to go with the
princess and the others.$K
$c1SENERIO|$s1$MC...$MDAll right.$w4 But, Ike, $w2be careful.$K $R�㉺��b|$c0EMAKOU|$s0We've spotted the mercenaries!$w4 You
there! $w2Inform General Petrine at once!$w4
Request that she gather the troops!$K
$c1DAYNE2|$s1Yes, sir!$K   $R�㉺��b|$c0EMAKOU|$s0What's this? $w2They're not bad!$w4
Let's go, men! $w2Hit those mercenary
scum with everything you have!$K  $R�㉺��b|$c1DAYNE2|$s1Reinforcements have arrived!$K
$c0EMAKOU|$s0Very good! $w2Let's crush these
sellswords once and for all!$K  $R�㉺��b|$c0EMAKOU|$s0Try me!$w4 I'll not let even a single
soldier get past!$K   $R�㉺��b|$c0EMAKOU|$s0I will not allow you$w3
to take one step more!$K
$c1IKE|$s1Then I've no choice $w2but to cut
you down and walk over you!$K  $R�㉺��b|$c0EMAKOU|$s0Oooh$MC...$MD$w3 My life ends here$MC...$MD$w4
But$MC...$MD$w2though you flee to Gallia$MC...$MD$w3
you will$MC...$MD$w2fall to $w2Daein$MC...$MD$K $R�w�i��b|$B����-�쉈��|$<$F3$FCL_IKE|$F3$PI don't know how,$w2 but
we made it$MC...$MD$K
$F1$FS$F1$FCL_MIST|$F1$PBrother!$K
$F0$FS$F0$FCL_ERINCIA|$F0$PMy lord Ike!$K
$F3$PMist!$w4 Princess, Rolf$MC...$MD$w4
Are you all well?$K
$F0$FD$F0$FS$F0$FCL_LOFA|$F0$PYep!$w4 We're fine.$K$FD
$F1$P$FAIs this Gallia?$w4 We made it,$w2 didn't
we? We're safe now, right?$w4 I thought
I would feel different,$w4 but I don't.$K$FD
$F0$FS$F0$FCL_ERINCIA|$F0$PThis is all $w2due to your efforts.$w4
$FcThank you$MC...$MD$w2$K
$F3$PPrincess Elincia$MC...$MD$K
$F4$FCL_SENERIO|$F4$PIt's still too early $w2to rest easy.$w4
The others haven't rejoined us yet.$K$P$F0$P$Fd$FAAh!$K
$F4$FD$F4$FCL_TIAMAT|$F4$PWe are talking about the commander.$w2
I don't think there's anything to worry
about.$K
$F3$PFather$MC...$MD$w4Shinon$MC...$MD$w2Gatrie$MC...$MD$K
$F4$FD$F4$FCL_SENERIO|$F4$P$MC...$MD$K
$F3$P$MC...$MD$w2Princess Elincia,$w2 I'm afraid$w2
we're going to have to part ways here.$K$P$F0$PBut $w2what do you mean?$K
$F3$PWe're going back $w2to aid our companions.$K$PSo I want you $w2to continue with Mist
to the royal palace of Gallia.$K
$F1$FCL_MIST|$F1$PWhat?$w4 No,$w2 Ike! I'm going
to stay with you!$K
$F3$PListen to me, $w2Mist!$w4
We must do it this way so that
everyone gets out of here alive!$K$P$F1$FD$F1$FCL_MISTs|$F1$PMm$MC...$MD$K
$F3$PFather and I $w2will catch up to you right
away!$w5$FS Don't worry.$w4 Have Father
or I ever broken a promise to you?$K
$F1$PWell$MC...$MD$w2no.$w4
All right, then. $w2We'll go ahead.$K
$F4$FD$F4$FS$F4$FCL_TIAMAT|$F4$PThank you, $w2Mist.$w4
We'll see you soon.$K
$F1$PAll right.$w4 Titania$MC...$MD$w4 Please take care
of my brother.$w2 Promise?$K
$F4$PYou have my word on it.$K
$=0300 $R�w�i��b|$B����-�쉈��|$<$F3$FCL_IKE|$F3$PI don't know how,$w2 but
we made it$MC...$MD$K
$F1$FS$F1$FCL_MIST|$F1$PBrother!$K
$F0$FS$F0$FCL_ERINCIA|$F0$PMy lord Ike!$K
$F3$PMist!$w4 Princess, Rolf$MC...$MD$w4
Are you all well?$K
$F0$FD$F0$FS$F0$FCL_LOFA|$F0$PYep!$w4 We're fine.$K$F0$FD
$F1$P$FAIs this Gallia?$w4 We made it,$w2 didn't
we? We're safe now, right?$w4 I thought
I would feel different,$w4 but I don't.$K$FD
$F0$FS$F0$FCL_ERINCIA|$F0$PIt is almost like a dream$MC...$MD$w4
This is all $w2due to your efforts.$w4
$FcThank you$MC...$MD$w2$K
$F3$PPrincess Elincia$MC...$MD$K
$F4$FCL_SENERIO|$F4$PIt's still too early to rest easy.$w4
The others haven't rejoined us yet.$K$P$F0$P$Fd$FAAh!$K
$F4$FD$F4$FCL_TIAMAT|$F4$PWe are talking about the commander.$w2
I don't think there's anything to worry
about.$K
$F3$P$MC...$MD$K
$F4$FD$F4$FCL_SENERIO|$F4$P$MC...$MD$K
$F3$P$MC...$MD$w2Princess Elincia,$w2 I'm afraid$w2
we're going to have to part ways here.$K$P$F0$PBut $w2what do you mean?$K
$F3$PWe're going back $w2to aid our companions.$K$PSo I want you to continue with Mist
to the royal palace of Gallia.$K
$F1$FCL_MIST|$F1$PBrother?$w4 No,$w2 I'm going to
stay with you!$K
$F3$PListen to me, $w2Mist!$w4
We must do it this way so that
everyone lives!$K$P$F1$PMm$MC...$MD$K
$F3$PFather and I $w2will catch up to you right
away!$w5$FS Don't worry.$w4 Have Father
or I ever broken a promise to you?$K
$F1$PWell$MC...$MD$w2no.$w4
Fine. $w2We'll go ahead.$K
$F4$FD$F4$FS$F4$FCL_TIAMAT|$F4$PThank you, $w2Mist.$w4
We'll see you soon.$K
$F1$PAll right.$w4 Titania$MC...$MD$w4 Please take care
of my brother.$w2 Promise?$K
$F4$PYou've my word on it.$K
$=0300    $R�w�i��b|$B����-�쉈��|$<$F3$FCL_IKE|$F3$PSomehow, $w2we made it$MC...$MD$K
$F1$FS$F1$FCL_MIST|$F1$PBrother!$K
$F0$FS$F0$FCL_ERINCIA|$F0$PMy lord Ike!$K
$F3$PMist!$w4 Princess, Rolf$MC...$MD$w4
Are you all well?$K
$F0$FD$F0$FS$F0$FCL_LOFA|$F0$PYep!$w4 We're fine.$K$F0$FD
$F1$P$FAIs this Gallia?$w4 We made it,$w2so
we're safe, right?$w4 I thought I
would feel different, but I don't.$w4$K$FD
$F0$FS$F0$FCL_ERINCIA|$F0$PIt's like a dream$MC...$MD$w4
This is truly $w2due to your efforts.$w4
$FcThank you$MC...$MD$w2$K
$F3$PPrincess Elincia$MC...$MD$K
$F4$FCL_SENERIO|$F4$PIt's still too early $w2to rest easily.$w4
The others haven't rejoined us yet.$K$P$F0$P$Fd$FAAh!$K
$F4$FD$F4$FCL_TIAMAT|$F4$PWe're talking about the commander.$w2
I don't think there's anything to worry
about.$K
$F3$PFather$MC...$MD$K
$F4$FD$F4$FCL_SENERIO|$F4$P$MC...$MD$K
$F3$P$MC...$MD$w2Princess Elincia,$w2 I'm afraid$w2
we're going to have to part ways here.$K$P$F0$PBut $w2what do you mean?$K
$F3$PWe're going back $w2to aid our companions.$K$PSo I want you to continue with Mist
to the royal palace of Gallia.$K
$F1$FCL_MIST|$F1$PBrother?$w4 No,$w2 I'm going to
stay with you!$K
$F3$PListen to me, $w2Mist!$w4
We must do it this way so that
everyone lives!$K$P$F1$PMm$MC...$MD$K
$F3$PFather and I $w2will catch up to you right
away!$w5$FS Don't worry.$w4 Father and I$MC...$MD$w3 Have
either of us ever broken a promise to you?$K
$F1$PWell$MC...$MD$w2no.$w4
Fine. $w2We'll go ahead.$K
$F4$FD$F4$FS$F4$FCL_TIAMAT|$F4$PThank you, $w2Mist.$w4
We'll see you soon.$K
$F1$PAll right.$w4 Titania$MC...$MD$w4 Please take care
of my brother.$w2 Promise?$K
$F4$PYou have my word on it.$K
$=0300  $R�w�i��b|$B����-�쉈��|$<$F3$FCL_OSCAR|$F4$FCL_BOLE|$F1$FCL_LOFA2|$F1$POscar$MC...$MD$w3Boyd$MC...$MD$w4 Don't get
killed out there, all right?$K
$F3$PRolf$MC...$MD$K
$F4$P$FSKnock it off, both of you!$w2
You're like a couple of old women.$K$PWe're gonna be fine.$w2 Nothing bad's
gonna happen while I'm around!$K
$=0300  $R�w�i��b|$B����-�쉈��|$<$F5$FCL_KILROY|$F3$FCL_ERINCIA|$F3$PPardon, my lord Rhys$MC...$MD$K$P$F5$FD$F1$FCL_KILROY|$F1$PY-yes?$K
$F3$PTake this with you, please.$K
$F1$PThis is a mend staff, isn't it?$w4
Er, $w2are you sure this is all right?$K
$F3$PEvery one of you$w3 is putting yourself
in harm's way on my account.$K$PI only hope that staff can mitigate
your risks even slightly.$K$w4$N$UB$H       $R�w�i��b|$B����-�쉈��|$<$F3$FCL_ERINCIA|$FS$F1$FCL_KILROY|$N$UB$H    $F1$P$FSThank you very much!$w3 This will help
greatly.$w5 I will use it to aid the others$w3
in your name.$K
$F3$P$FS...Thank you.$w5
Please...be careful.$K
$F1$PIf you'll excuse me.$K$P$F1$FD$w5
$F3$P$FA$FcO benevolent Ashera...$w3
Grant them all $w2your blessings...$K
$=0300  $R�w�i��b|$B����-�쉈��|$<$F3$FCL_IKE|$F0$FCL_MIST|$F1$FCL_LOFA|$F0$PAll right,$w3 we're going to go now.$K
$F3$PGood luck.$w3 Watch your step,$w2
and be careful.$K
$F0$FD$F1$FD$F0$FCL_ERINCIA|$F0$PWe'll see all of you again...$w2 I'm sure of it!$w5
I know you will all be safe.$K$F0$FD
$F3$PLet's get moving!$w4
Where to, $w2Soren?$K
$F1$FCL_SENERIO|$F1$PWe go east $w2on the road we used before.$w4
Let's find the commander $w2before
the enemy reinforcements show up.$K
$=1500   :�      :�   	  ;�     <0      B�   .  Ih   <  O�   J  Q0   X  S   f  R�   v  R�   �  T$   �  8�   �  9�   �  :   �       �   �   �  (   �     �  �        P    8  -    ;    I  ,  U  �  f  !�  w  %X  �  (�  �  ,�  �  0$  �  7  �  7L  �  8T  �MS_07_BT MS_07_BT_IKE MS_07_DIE MS_07_ED_01_A MS_07_ED_01_B MS_07_ED_01_C MS_07_ED_02_A MS_07_ED_02_B MS_07_ED_02_B_2 MS_07_ED_02_B_DEL MS_07_ED_02_B_DISP MS_07_ED_03 MS_07_EV_01 MS_07_EV_02 MS_07_EV_03 MS_07_GMAP_01 MS_07_GMAP_02 MS_07_GMAP_03 MS_07_GMAP_04 MS_07_GMAP_06 MS_07_GMAP_07 MS_07_GMAP_08 MS_07_OP_01_A MS_07_OP_01_B MS_07_OP_02 MS_07_OP_03_01_A MS_07_OP_03_01_B MS_07_OP_03_02_A MS_07_OP_03_02_B MS_07_OP_03_02_C MS_07_OP_03_02_D MS_07_OP_04 MS_07_OP_04_x MS_07_OP_05_01 MS_07_OP_05_02 