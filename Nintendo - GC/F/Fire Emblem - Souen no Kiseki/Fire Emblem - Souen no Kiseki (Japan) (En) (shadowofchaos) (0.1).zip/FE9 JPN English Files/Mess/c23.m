  ��  ��       .                $RGMAP��b|$O3$GOvercoming many hardships,$w3 Ike and
company finally arrive in the Daein capital
of Nevassa.$K$PHowever, $w2much to their dismay,
King Ashnard$w3 is nowhere to be found.$K$P$Ub$HAccording to intelligence reports, $w2the
king is in Crimea's capital of Melior,$w3
preparing to wage war against Gallia.$K$PIn addition, $w2at least half of the Daein army,
including its most elite forces,$w3
remain unharmed and at his side.$K$PThe Crimean army is again forced to march.$w3
This time, however,$w3 the battlefield$w2
will be their own homeland.$K$PEagerly awaiting their arrival $w2is a Daein
army more powerful than anything
they have faced so far.$K$PThis fact,$w3 coupled with Nasir's act of
betrayal,$w4 has filled Ike with
apprehension and disappointment.$K$PYet, $w2it is then, when all hope seems faint,
$w3that unexpected good news arrives.$K$Ub$H $R�w�i��b|$B���-����-�f�C��|$<$F0$FCL_BEGNION2|$F3$FCL_IKE2|$F0$PGeneral Ike!$w4 Sir, reinforcements have arrived
from Begnion!$K
$F3$PReinforcements?$w4 I haven't heard anything
about this.$K
$F4$FCL_ERINCIA|$F3$PHave you, Princess Elincia?$K
$F4$PNo, $w2not a word.$K
$F3$PAre you sure $w2they're Begnion troops?$K
$F0$P$FSYes, sir! They fly Begnion's insignia.$w2
There can be no doubt of their authenticity.$K$PAnd the man in command is one of
Begnion's most beloved heroes,$w3 General
Zelgius!$w4 There's no mistaking him, sir!$K$F0$FD
$F3$PAllow me to meet with him first.$K
$=0500   $R�w�i��b|$B���{-�f�C��|$<$F3$FCL_IKE2|$F1$FCL_ZELGIUS|$F1$PI beg your pardon.$w4 Are you $w2General Ike?$K
$F3$PI am. $w2And you are?$K
$F1$PI am $w2Zelgius, earl of Kadohl.$w4
I've been dispatched from Begnion with
a battalion$w3 to support your army.$K
$F3$PYour assistance is much appreciated, but...$w4
This is very unexpected.$K
$F1$PI understand your surprise.$w4 For Begnion's
imperial senate, $w2this decision was made
with unusual haste.$K
$F3$PI imagine so.$w4 It took forever just to get
the soldiers I have now.$K
$F1$PWell, there's a reason behind this expedited
decision.$w4 Duke Persis$w2 has returned home.$K
$F3$PDo you mean Sephiran?$K
$F1$PCorrect.$w4 Duke Persis $w2is also senior
statesman of the imperial senate.$K$PThe duke returned from his travels and$w2
began working immediately to settle
pressing affairs of state.$K$PFirst, $w2he met with the apostle,$w2
and they exchanged reports on both
foreign and domestic matters.$K$PThen they discussed Begnion's position in
relation to the current conflict,$w2
and possible courses of action.$K$PIn less than half a day, $w2they brought the
entire imperial senate into line $w2and
sent us here to you.$K
$F3$P...$w4So you're saying that Begnion $w2has
allied itself with Crimea.$w2 Is that it?$K
$F1$P$FSThat's it exactly.$w4 I am at your service,$w2
General Ike.$K
$F3$POh... Um...$w4wow. $w2Thank you.$K
$F1$P$FANow then, $w2please tell me what you would
have my men do. I'm ordered to help in
any way possible.$K
$F3$PUm...$w4 You've caught me off guard.$w2
I can't think of anything right now.$K
$F1$PIn that case, $w2do I have permission to
make camp around the palace $w2and
rest my troops?$K
$F3$PYes, please do.$w2 That's no problem.$K
$F1$P$FSThank you. $w5$FAPlease do not hesitate to call
if you have need of us.$w4
We are at your disposal.$K
$=0800    $R�w�i��b|$B���-����-�f�C��|$<$F0$FCL_TIAMAT|$F3$FCL_IKE2|$F0$PBegnion reinforcements...$w4 That was
unexpected, wasn't it?$K
$F3$PIt certainly was!$w4 It seems the apostle
and Sephiran $w2did the impossible by
getting them to us.$K
$F4$FCL_ERINCIA|$F4$PAll for our little army...$w4 It's hard to
believe they would go to all this trouble.$K
$F0$P$FSFirst we take Daein's capital, and now this.
Things are looking up.$K
$F3$PYou're right.$w4 Even if we don't receive
help from Gallia,$w2 we still may be able
to defeat Ashnard.$K
$F4$P$FSThat's true.$w4 It's...like a dream.$K
$F1$Fc$F1$FCL_SENERIO|$F1$PI have to $w2disagree.$K
$F4$P$FA$F0$P$FAOh, look.$w4 Soren is upset again. Who knew?!$w4
What is it this time?$K
$F1$P$FdIf the Crimean army is not the crux of
Daein's defeat, this war means nothing.$K
$F0$PWhat does that have to do with the$w2
arrival of these reinforcements?$K
$F1$PThe battalion that just arrived $w2is greater in
numbers than the one we originally received.$K$PNot only that, $w2but all of these soldiers are
marching under Begnion's name.$K
$F3$PSo?$K
$F1$PSo... $w2If these reinforcements are responsible
for defeating King Daein, what do you think
will happen?$K$PThat achievement, the very victory itself,$w2
will belong to the Begnion Empire.$w3
Not to Crimea.$K$PIf that happens, $w2Crimea will be rebuilt
however Begnion sees fit, and Princess
Elincia will be a mere figurehead.$K$PAnd then, $w2the deeds of an unknown
mercenary company will be expertly
covered up.$K$P$FcWe'll receive some $w2paltry sum of money
and be swept under a rug somewhere.$w4
Mark my words.$K
$F4$PSoren, $w2you're being so rude!$w4
Surely the apostle, of all people, would
never do such a thing!$K
$F3$PAnd this General Zelgius seems sincere
enough to me.$K
$F0$PCome, Soren.$w4 I have heard of situations
like that which you describe, but whether
this is such a case...$K$PWe've been fortunate to receive this good
will. $w2Must we always search for such
ulterior motives?$K
$F1$P$FdYes!$w3 We must!$w4 Have you forgotten Nasir?!
It's that sort of naive attitude $w2that allowed
him to remain undetected for so long!$K
You people don't seem to get it.$w4
We $w2are at WAR!$w5 All doubts, no matter
how small, must be extinguished.$K$PIf they aren't,$w4 we could well be ignoring
something that will lead to our defeat.$w2
Or to our death.$K
$F0$P...$K
$F4$P...$K
$F3$PLet's take Soren's comments under
consideration and discuss this at length.$w4
We meet in one hour.$K
$=1000  $R�w�i��b|$B���-��|$<$F1$FCL_IKE2|$F4$FCL_ZELGIUS|$F4$PSo you're going to lead a small unit out
on a survey mission?$K
$F1$PYes, that's the plan. However...$w3
Though we've taken the castle, there
are still pockets of Daein resistance.$K$PIt's possible they may try to mount an
attack and retake the palace.$w4 I want
you to be in charge of the watch.$K
$F4$PThat is, of course, not a problem.$w4
However, you're taking the princess along.$K$PDon't you think it would be safer to take
more troops? Even if we split our battalion,
we have enough men to handle both tasks.$K
$F1$PI'm just not used to moving around
with such a large group.$K$PAnd $w2for this mission...$w4 I'd like to keep
the number of people involved as low
as possible.$K
$F4$PIt's not that I don't understand how you
feel, but...$w4$FSwe will compromise.$K
$F1$P$FSYou know, $w2for someone from Begnion,
you're pretty flexible.$w4 It speeds things
up considerably.$K
$F4$PTo be a soldier, $w2one must be able
to quickly adapt to circumstances
around him.$K
$F1$P$FAAll right. We'll be back later.$K
$F4$P$FATake care.$K
$=1000   $R�w�i��b|$B����-��|$<$F3$FCL_IKE2|$F4$FCL_ERINCIA|$F3$PThis is the place Nasir mentioned.
Palmeni Temple.$K$PI hope whatever he was trying to tell
me $w5will become clear once we$w2
get inside and look around.$K
$F4$PI still can't believe $w2Nasir was on Daein's
side...$w4 I just can't.$K$PAnd he let that dragon girl get away...$w4
Although I'm sure he had reasons for that,
as well.$K
$F1$FCL_MISTs|$F1$PI wonder... $w2Was it really Nasir?$K$PAlthough, besides my family, the only people
I showed the medallion to were Titania,$w2
Princess Elincia,$w3 and Nasir...$K$P$Fh$w2$w4I thought I could trust him... $w2I really did.$w5
Why?$w3 Why did he do it?$K
$F4$PMist...$K
$F3$PThinking about the past isn't going to help.$w4
Let's take a look at this temple.$K
$=1500 $R�w�i��b|$B�p�����j�[��O|$<$F3$FCL_IKE2|$F3$PHere we are.$w4 This is Palmeni Temple.$K
$F4$FCL_MIST|$F4$PIke!$w4 Look! There's a big white bird
on top of the roof!$w3 Wait, is that...?$K
$F3$PYep.$w4 It looks like he's spotted us.$w4
Here he comes.$K
$Ub$H$F0$FCL_RIEUSION|$F0$P$Ub$H......Ugh!$Fh$K
$F4$PReyson!$K
$F3$PWhat happened?$w4 I thought you'd gone
to Phoenicis$w3 to have your wounds
taken care of.$K
$F0$P$FdI'm not truly sure I understand what's
happening.$w4 I felt like something was
calling me here.$K$PNo... That's not right.$w4 I wasn't called...$w3
I picked up a very strong thought that said
"Palmeni Temple."$K
Even though I've never been here,$w2
I knew exactly what it looked like...$w2
And where to find it, as well.$K$PI was beginning to suspect $w2that
someone had led me here. And now,
your arrival would seem to confirm it.$K
$F3$PIt appears $w2this place harbors many secrets...$w4
Let's go inside.$K
$=1000  $R�w�i��b|$B�p�����j�[��O|$<$F3$FCL_IKE2|$F3$PHere we are.$w4 This is Palmeni Temple.$K
$F4$FCL_MIST|$F4$PIke!$w4 Look! There's a big white bird
on top of the roof!$w3 Wait, is that...?$K
$F3$PYep.$w4 It looks like he's spotted us.$w4
Here he comes.$K
$Ub$H$F1$FS$F1$FCL_RIEUSION|$F1$P$Ub$HIke! $w2Mist!$w4 It's been quite a
while, hasn't it?$K
$F4$PReyson!$K
$F3$PWhat are you doing here?$w4
I thought you'd gone back to Phoenicis
with the hawk king and Leanne.$K
$F1$P$FAI had...$w4 But then I suddenly felt $w2as if
someone was calling me.$K$PNo... That's not right.$w4 I wasn't called...$w3
I picked up a very strong thought that said
"Palmeni Temple."$K
Even though I've never been here,$w2
I knew exactly what it looked like...$w2
And where to find it, as well.$K$PI was beginning to suspect $w2that
someone had led me here. And now,
your arrival would seem to confirm it.$K
$F3$PYou came by yourself?$K
$F1$P$FSTibarn and the others were on patrol,$w3
and Leanne was sleeping.$w4 I think I can
fly off on my own for a while.$K
$F3$PWell, $w2you can't fight,$w3 so I'd
question your decision to come to
Daein on your own.$K
$F1$P$FAWhy?$w4 We heard from Gallia that you'd
captured the capital. This territory's under
your control, isn't it?$w4 I should be safe here.$K
$F3$PWe haven't conquered the whole country.$w4
There are still many Daein soldiers traveling
about.$K
$F1$PWell, $w2I didn't transform until I found you.$w3
So as you can imagine, I was safe
all along.$K
$F3$PAll I can imagine are your guardians flying
here in a blind panic.$K
$F4$PMe, too.$K
$F1$P$FcMmm...$w4 What's done is done.$w4
I will apologize later.$K
$F3$PWe're going to investigate this place.$w4
Why don't you go ahead and return to
Phoenicis.$K
$F1$P$FdNo, $w2I've come this far,$w4 I want to see
who or what guided me here.$w4
You'll let me come, won't you?$K
$F4$P$FSThat would be all right,$w3 wouldn't it, Ike?$K
$F3$PI suppose so.$w4 There's something I wish
to discuss with Reyson anyway.$w4
It's settled.$w4 Let's go in.$K
$=1000    $R�w�i��b|$B�p�����j�[�_�a|$<$F1$FCL_SIRKUKO|$F3$FCL_BISHOP|$F1$PWhat did you say?$w4 The Crimean army
is here?$K
$F3$PThey want to investigate the temple.$w4
What should I tell them?$K
$F1$PCrud! This ain't good.$K
I don't know what they're after,$w4 but if
they find us mercenaries who sided with
Daein,$w3 they'll wipe us out!$K
$F3$P$FcIt is all $w2the will of the goddess.$w4
Resign yourself to your fate...$w3 Accept it.$K
$F1$PBat dung!$w4 No one's gonna roll over
and die! Dying's for sissies!$w3 So tell me,$w4
how many are there?$K
$F3$P$FdThere appears to be ten or so,
including the women.$K
$F1$P$FSGahar har har! $w2That's good news!$K
$F3$PIt is?$K
$F1$PIf that's the lot of them, $w2we can take
care of this on our own.$w3 It'll be like
stealin' a baby from the cradle!$K$PRight, then, here's the plan. Pretend like
you wanna help 'em,$w2 then lead 'em inside.$K$P$FAAnd listen good! $w2You'd best not whisper
a word $w2about us being here! Or else...$w5
Kkkkccchhhhh!$K
$F3$PB-$w2but I couldn't...$w4 What you ask
is beyond me--$K
$F1$PKKKKCCCCHHHHH!!!$K$PDon't forget,$w4 we've got all the other priests$w2
under our control.$w4 Unless you want 'em to
meet the goddess early, $w2do as you're told!$K
$F3$POh dear...$K    $R�㉺��b|$c1IKE2|$s1All right, $w2we'd like to take a look
around.$w4 Please show us each room.$K
$c0BISHOP|$s0Um...$w2very well...$w3 Th-th-this...$w4is...
Er... A v-very large room... Um...$K
$s1Are you all right?$w4 Why are you
shaking like that?$K
$s0$FcOh, Goddess...$w3 Please...$w2forgive me...$K$d0
$Ub$H$s1It's a trap!$K $R�㉺��b|$s0$FS$c0SIRKUKO|$s0Gahar har har har!$w3 You did it!$K
$s3$Fc$s3$c3BISHOP|$s3Please...$w2forgive me...$K$d3$w4
$c1IKE2|$s1I thought something like this might
happen.$K
$s0I don't know how you got wind of us,$w2
but showing up in such a small
group means you're outta luck!$K$PNone of ya are gettin' outta here
alive!$K
$s1We've just fought our way to the
Daein capital.$w4 You're not even
going to slow us down!$K
$s0Cocky, ain't ya?$w3 But who said
this was gonna be a fair fight?$K
$c3BISHOP|$s3Eh?$K  $R�㉺��b|$c3BISHOP|$s3What, $w2what are you doing?$K
$s0$FS$c0SIRKUKO|Hey!$w3 Bring out the others!$K $R�㉺��b|$s0$FS$c0SIRKUKO|$s0You fools$w3 are gonna be our shields.$K
$c2BISHOP|$s2What?$K
$s0Gahar har har!$w4 Gahar har har har!$w4
See? You ain't so useless after all!$K
$c1IKE2|$s1You filthy dogs!$w4 Those are innocent
people!$w3 You can't...$K
$s2Oh...$w2mercy... $w2Please help me...$K
$s0Hey! If ya don't want them perty
robes of yours to turn red,
you'll attack these scum!$K$PIf ya even think about betraying us,$w3
I'll kill every one of ya!$K
$s2B-but...you can't...$K
...$w3
Crimeans, please...$w3 $FcForgive us...$w4
We cannot allow our brothers $w2to die.$K   $R�㉺��b|$c1IKE2|$s1This cowardice will not stand!$w4 These
priests $w2are being made to fight
against their will.$K$PWe've got to try and save as many of
them as possible!$w4 Let's go!$K   $R�㉺��b|$c0BISHOP|$s0If this is punishment for betraying
the gods...$w3 Let us accept it.$K  $R�㉺��b|$c0SIRKUKO|$s0Hey, robes!$w3 If I get so
much as scratched,$w4 you
better get to healing!$K  $R�㉺��b|$c0SIRKUKO|Bah! $w2So you've made it this far,
have you?$K$P$FSTell me, $w2how many pathetic priests
did you have to kill to get here?$K$PCome on, five?$w4 More?$w4 They're pretty
scrawny... You could probably take
ten or so without breakin' a sweat.$K
$c1IKE2|$s1Cowardly cur! Time to stop hiding
and fight like a man!$K    $R�㉺��b|$c0SIRKUKO|$s0Yeowch!$w4 Look at that ugly
thing! $w2It's a...$w3sub-human!$K    $R�㉺��b|$c0SIRKUKO|$s0Fly-$w2flying freak!$w4 Bows!$w2
Get your bows!$w4 Bring 'em down!$K   $R�㉺��b|$c0SIRKUKO|$s0Heh heh heh.$w4 Now here's a familiar
face! $w2It's one of Daein's old generals!$K$PLook, I'm a coward, $w2and you're a
traitor!$w4 Let's be friends!$w3
Whattya say?$K    $R�㉺��b|$c0SIRKUKO|$s0I'm pretty sure you herons don't know
how to fight.$K
Lucky me! $w2I'm gonna kill ya,
stuff ya, and mount ya in my den!$K  $R�㉺��b|$c0SIRKUKO|$s0...Gwaar...$w3 Haaaarr... Haaaaaa...
Shoulda brought...more priests...
Or some...babies...$w4 Dang...$K    $R�w�i��b|$B�p�����j�[�_�a|$<$F0$FCL_IKE2|$F1$FCL_ERINCIA|$F4$FCL_BISHOP|$F4$PThank you very much.$w4 I never imagined
that$w3 we would be rescued $w2by soldiers
of an enemy nation.$K
$F0$PThere was no way we'd cut down innocent
priests being forced to fight against
their wills.$K
$F1$PFather, we bear no ill will toward the
kingdom of Daein itself.$K$PWe wish only to reclaim the homeland which
was unjustly taken from us.$w4 That is the
reason we fight.$K$PWe had no$w4 desire to invade this land.$w3
If nothing else, please believe that.$K
$F4$PI beg your pardon. $w2May I have the favor
of your name?$K
$F1$PElincia $w1Ridell $w1Crimea.$w4 I'm the sole
survivor of the Crimean royal family.$K
$F4$P$FSOh!$w3 You...$w4 Let us give thanks that
you are alive and well!$K$P$FAAnd please, $w2I beg your understanding
as well.$w3 There are many Daeins$w4 who
do not support the king's actions.$K
$F1$P$FSI understand.$K
$F0$P...$K
$F4$P$FSMy young general, $w2this is for you.$K
$F0$PHuh?$K
$F4$PAs thanks$w3 for saving our lives.$K$N$UB$H     $R�w�i��b|$B�p�����j�[�_�a|$<$F0$FCL_IKE2|$F1$FCL_ERINCIA|$F4$FCL_BISHOP|$N$UB$H       $R�w�i��b|$B�p�����j�[�_�a|$<$F0$FCL_IKE2|$F1$FCL_ERINCIA|$F4$FCL_BEGNIONB|$F4$PThank you very much.$w4 I never imagined
that$w3 we would be rescued $w2by soldiers
of an enemy nation.$K
$F0$PThere was no way we'd cut down innocent
priests being forced to fight against
their wills.$K
And yet, we were not able to save
everyone...$K
$F4$P$FSPeace, my lord.$w4 We were expecting
to be killed at once.$w3 Yet somehow you
rescued so many of us...$K$PI'm sure that even our departed Bishop
Tomenami is grateful for your aid.$K
$F1$PFather, we bear no ill will toward the
kingdom of Daein itself.$K$PWe wish only to reclaim the homeland which
was unjustly taken from us.$w4 That is the
reason we fight.$K$PWe had no$w4 desire to invade this land.$w3
If nothing else, please believe that.$K
$F4$P$FAI beg your pardon. $w2May I have the favor
of your name?$K
$F1$PElincia $w1Ridell $w1Crimea.$w4 I'm the sole
survivor of the Crimean royal family.$K
$F4$P$FSOh!$w3 You...$w4 Let us give thanks that
you are alive and well!$K$P$FAAnd please, $w2I beg your understanding
as well.$w3 There are many Daeins$w4 who
do not support the king's actions.$K
$F1$P$FSI understand.$K
$F0$P...$K
$=1200    $R�w�i��b|$B�p�����j�[�_�a|$<$F0$FCL_IKE2|$F1$FCL_ERINCIA|$F4$FCL_BISHOP|$F4$PThank you very much.$w4 I never imagined
that$w3 we would be rescued $w2by soldiers
of an enemy nation.$K
$F0$PThere was no way we'd cut down innocent
priests being forced to fight against
their wills.$K
And yet, we were not able to save
everyone...$K
$F4$P$FSPeace, my lord.$w4 We were expecting
to be killed at once.$w3 And yet you rescued
so many of us...$K$P$F1$PFather, we bear no ill will toward the
kingdom of Daein itself.$K$PWe wish only to reclaim the homeland which
was unjustly taken from us.$w4 That is the
reason we fight.$K$PWe had no$w4 desire to invade this land.$w3
If nothing else, please believe that.$K
$F4$P$FAI beg your pardon. $w2May I have the favor
of your name?$K
$F1$PElincia $w1Ridell $w1Crimea.$w4 I'm the sole
survivor of the Crimean royal family.$K
$F4$P$FSOh!$w3 You...$w4 Let us give thanks that
you are alive and well!$K$P$FAAnd please, $w2I beg your understanding
as well.$w3 There are many Daeins$w4 who
do not support the king's actions.$K
$F1$P$FSI understand.$K
$F0$P...$K
$=1200  $R�w�i��b|$B�p�����j�[�_�a|$<$F5$FCL_IKE2|$F4$FCL_ERINCIA|$F5$PIn the end, $w2we were unable to save
even one of them...$K
$F4$PMy lord Ike...$w4 I know that we bear no ill
will toward the kingdom of Daein itself.$K$PWe wish only to reclaim the homeland which
was unjustly taken from us.$w4 That is the
reason we fight.$K$PYet...$w2to this end...$w4 The sacrifices
we have witnessed...$K
$F5$PThis is a battle of life and death.$K$PIf we are attacked, we must act in kind$w4
or be killed--no matter the circumstances.$w4
That is the essence of war.$K
$F4$PI will harden my heart $w2and grow
stronger.$w4 I am the defender of the
realm. I am the daughter of House Crimea!$K
$F5$PYes. $w2To gain something desired,$w3
there is always a price to be paid.$K
$=1200   $=0500$R�w�i��b|$B���[���A�̕����ʎ�|$<$F3$FCL_IKE2|$F3$PNow it's time to search this place.$K
$F4$FCL_ERINCIA|$F4$PMy lord Ike. $w2May I join you?$K
$F3$PSure, why not? $w2Everyone's lending a--$K
$F7$FCL_MIST|$F7$PIke!$w4 Ike! $w2Where are you?$K
$F3$PMist? $w2I'm over here.$K
$F0$FCL_MIST|$F0$PIke! $w2This way!$w4 Quickly!
Reyson's in trouble!$K
$F3$PWhat?$K    $R�w�i��b|$B���[���A�̕����ʎ�|$<$F3$FCL_IKE2|$F3$PNow to search each room, one by one.$K
$F4$FCL_ERINCIA|$F4$PMy lord Ike. $w2May I join you?$K
$F3$PSure, why not. $w2Everyone's lending a--$K
$F0$FCL_RIEUSION|$F3$PReyson? Your wound looks pretty bad.$w4
If you keep moving around, it's just going
to get worse.$K
$F0$PSomething...$w2is calling me.$w4
Is it that way?$K
$=0500   $R�w�i��b|$B���[���A�̕���|$<$F5$FCL_RIEUSION|$F3$FCL_IKE2|$F3$PReyson?$w4 What is it?$K
$F5$P...$K$F5$FD
$F4$FCL_MIST|$F4$PHe's been like this from the moment$w2
he set foot in this room.$w4 He's just
staring at the walls.$K  $R�w�i��b|$B���[���A�̕���|$<$F5$FCL_RIEUSION|$F3$FCL_IKE2|$F3$PReyson!$w4 You've taken a terrible wound...$w4
What do you think you're doing?$K
$F5$P...$K$F5$FD
$F3$PReyson?$K
$F4$FCL_MIST|$F4$PHe's been like this from the moment$w2
he set foot in this room.$w4 He's just
staring at the walls.$K   $R�㉺��b|$c0IKE2|$s0What $w2is all this?$K
$c2ERINCIA|$s2Every wall has the same pattern
on it.$K$d2
$c1SENERIO|$s1It's not a pattern.$w4 It's an ancient
language.$w4 All chants and spells in
magic scrolls are written thusly.$K
$s0Can you read it, $w2Soren?$K
$s1Some, but not all. Spells are simple,
whereas this is a complex narrative.$w4
I think Prince Reyson could read it.$K
$s0I bet this is the same language
that Leanne was speaking.$K
$s1It is.$w4 It's the Serenes' language...$w4
Their chants are all in this
language, too.$K$d1
$c3MIST|$s3So $w2Reyson$w4 is reading
what's written on the walls?$K$d3
$c2TIAMAT|$s2It appears that way...$K$d2
$s0Shall we leave him be?$w3
There's a lot of writing here.$w2
This could take hours.$K
$c2ERINCIA|$s2I think that's a good idea.$K    $R�w�i��b|$B���[���A�̕���|$<$F3$FCL_SENERIO|$F3$PIke!$K
$F0$FCL_IKE2|$F0$PWhat is it?$K
$F3$PFrom what I could gather, I think
a person was locked in this room
sometime in the past.$K
$F0$P...$w3You don't know who it was, do you?$K
$F3$PI wasn't able to $w2read enough
of the writing, but...$w4 I found
this $w2under the bed.$K
$F0$PIs this...?$K
$F3$PI think it may have belonged to
whoever was imprisoned in
this room.$K
$F0$P...$K
$=1000  $R�w�i��b|$B���[���A�̕����ʎ�|$<$F1$FCL_RIEUSION|$F3$FCL_IKE2|$F1$PI apologize.$w4 I took up much of your time.$K
$F3$PReyson, $w2you don't look so good.$w4
Why don't you rest for a bit?$K
$F1$PNo, $w2I'm fine.$w4 It's more important
that we talk.$K
$F3$PAbout the owner of this feather?$K
$F1$P...$w4Was it in that room?$K
$F3$PSoren found it.$w4 Whose was it?$K
$Ub$H$F1$P$Fc$w5Lillia...$w4 My older sister. The writing on
the walls is hers.$K
$F4$FCL_ERINCIA|$F4$P...You have an older sister, too?$K
$F3$PWill you tell us about it?$K
$F1$P$FdShe was kidnapped twenty years ago,
on the night of the Serenes Massacre.$K$PI...$w2I thought that Lillia had been murdered
along with my other brothers and sisters.$w4
I believed that until today...$K
$F3$PWho took her?$K
$F1$PThe walls say only that he was a large
human. She probably never knew
who it was.$K$PHe thrust a clan treasure at $w2her and
demanded that she use her magic to revive
the thing sealed inside it.$K$PHe exhorted her again and again, but to no
avail. Lillia refused his request every time...$w4
because she did not possess that power.$K
$F4$PSomeone wanted to revive the dark god...$K
$F1$PShortly after she was brought here,$w4
Lillia fell ill and collapsed.$K$PI'm not surprised...$w3it was a terrible time...$Fc$w4
She was imprisoned in that tiny room$w4
with no view of earth or sky...$K
$F4$FD$F4$FCL_MISTs|$F4$POh, that's awf...$w4sniff......$w4
$Fc...sniff...$K
$F0$FCL_TIAMAT|$F0$PMist...$K
$F4$P$FhI'm $w2sorry...$w4I just feel...$w4
so sad for Lillia...$w4and for...$w4
for Reyson, too...$K$F0$FD$F4$FD
$F1$P$FdI beg your pardon. $w2Let me continue.$K
A young beorc began coming to the room
to care for Lillia.$w4 She had bluish hair
and blue eyes...$K
And her heart was unusually pure for a
beorc.$w4 In time, $w2Lillia and she came
to be friends, and shared a mutual trust.$K
$F4$FCL_MISTs|$F4$PAh!$K
$F3$P...$K
$F1$PLillia decided to entrust her hopes to
the woman. They shared no common
language,$w2 so it took some time.$K$PBut eventually, the beorc woman $w2understood
what it was Lillia wanted...$K$PWhich was to$w3 take the treasure and the
song...$w3and flee this temple.$K
$F4$PB-$w2Brother!$K
$F3$PWas there anything else written about this
beorc woman?$w3 A name, $w2perhaps...$K
$Ub$H$F1$P#F01$O2Elena...#F02$O1$K$PTranslated into our language,$w2
it was probably $w2Elena.$K
$Ub$H$F4$PI knew it!$w4 Mother!$w4 It was our mother!$K
$F1$PWhat?$K
$F0$FCL_ERINCIA|$F0$PAre, $w2are you sure?$K
$F3$POur mother's name was Elena. Like me,
her hair was blue...$w3as were her eyes.$K$PReyson, $w2the object you refer to as
your clan treasure was an aged, bronze
medallion, wasn't it?$K
$F1$PHow... $w2How did you know that?$K
$F3$PThe medallion$w4 became my mother's
keepsake.$w4 The song, too... My parents
both gave their lives to protect it.$K
$F1$PIke! You and Mist are Elena's children?$w4
Then $w2Lehran's Medallion is here?$K
$F4$PUm...$K
$F3$PThe medallion was stolen.
Probably by Daein.$K
$F1$PIt can't...$w4 This is...unbelievable.$w4
Can a thing like this be chance?$K
$F3$PTo be honest, $w2I don't fully understand
all that's happened. But...$w4it all makes sense.
It all comes together...$K
$F1$PAh!$K   $R�w�i��b|$B���[���A�̕����ʎ�|$<$F4$Fc$F4$FCL_MIST|$F3$FCL_IKE2|$F1$FCL_RIEUSION|$F0$FCL_ERINCIA|$Ub$H$F0$PMist...$K$PThat's the song that...$w4 But...$w4the melody's
a little different, isn't it?$K
$F3$PIt's similar to the song Reyson and Leanne
sang in the forest. My mother used to sing
it as a lullaby.$K
$F1$PIt is the song of release.$w4 The one Lillia$w5
entrusted to Elena.$K
$Ub$H$F4$P$FdB-but...I wore the medallion and sang that
song almost every single night!$w3
And nothing ever happened.$K
$F1$PThe magical effect of the song $w2is awakened
by the power of the singer.$w4 ...It can't
be unleashed by just anyone.$K$PThe true song of release $w2can only be sung
by a girl named Altina...$K$PLillia wanted your mother $w2to take the
melody to Altina $w2and return the medallion$w4
to its rightful place $w2in Serenes Forest.$K    $R�w�i��b|$B���[���A�̕����ʎ�|$<$F4$FCL_MIST|$F3$FCL_IKE2|$F1$FCL_RIEUSION|$F0$FCL_ERINCIA|$F3$PThe story's becoming clearer and clearer.$w2
My father fled Daein to protect my mother,
who was carrying the amulet.$K
$F0$FD$F0$FCL_TIAMAT|$F0$PIke?$w4 How did you know--$K
$F3$PVolke told me. He told me about my
father's past,$w4 and the amulet,$w3
and the dark god, too.$K
$F0$PSo you know everything...$K
$F1$PKing Ashnard took Lillia,$w3 didn't he?$K
$F3$PThat would be the final piece of the puzzle.$w4
After all, the man who found my father$w4
was the king's henchman.$K
$F0$PIke!$w4 Are you saying you know$w2
who killed Commander Greil?$K$PYou never said anything about that!$w4 We all
thought his murderer $w2was unknown...
Why didn't you say anything?$K
$F3$P...I don't know.$w4 I$w3 never felt like
talking about it.$K
$F0$PHe was a Daein soldier, wasn't he?$w4
Who was it? Who was the man who
killed Commander Greil?$K
$F3$P...$K
$F0$PIKE!! TELL ME!!$K
$F4$FD$F4$FCL_SENERIO|$F4$PCan we discuss this later?$K
$F3$P$Fd...$K
$F0$P...$w4Oh...$w4 Yes... Yes. Of course.$K$F0$FD
$F4$PUp to this point, $w2we've all been
fighting for the liberation of Crimea.$K$PEven if we now add to that $w2stopping the
dark god from being released $w2and
punishing Commander Greil's killer...$K$POur enemy remains unchanged. $w5King Daein
and his henchman are the ones we must
defeat.$K
$F0$FCL_ERINCIA|$F0$PIt's mysterious, isn't it?$w4 I mean, Reyson
said the same thing earlier, but...$w4 Could
all of this really be mere coincidence?$K$PThe fall of Crimea... $w2Ike's parents... $w2The
death of Reyson's sister...$w4 The fact that
everything leads back to Daein...$w2$K$F0$FD
$F1$PIf true,$w4 it changes the meaning
behind this war...$K$PThe treatment of Lillia is one thing but...$w4
The assassination of the former apostle?$w2
The framing and destruction of my nation?$K$PIf it was all part of Daein's plan $w2to steal$w2
the medallion and the song, then I...
I...$w4$Fc The reason I fight...$K
$F3$P...$K
$=2000  $R�w�i��b|$B���[���A�̕����ʎ�|$<$F4$FCL_MIST|$F3$FCL_IKE2|$F1$FCL_RIEUSION|$F0$FCL_ERINCIA|$F3$PThe story's becoming clearer and clearer.$w2
My father fled Daein to protect my mother,
who was carrying the amulet.$K
$F0$FD$F0$FCL_TIAMAT|$F0$PIke?$w4 How did you know--$K
$F3$PVolke told me. He told me about my
father's past,$w4 and the amulet,$w3
and the dark god, too.$K
$F0$PSo you know everything...$K
$F1$PKing Ashnard took Lillia,$w3 didn't he?$K
$F3$PThat would be the final piece of the puzzle.$w4
After all, the man who found my father$w4
was the king's henchman.$K
$F0$PIke!$w4 Are you saying you know$w2
who killed Commander Greil?$K$PYou never said anything about that!$w4 We all
thought his murderer $w2was unknown...
Why didn't you say anything?$K
$F3$P...I don't know.$w4$Fc I never felt like
talking about it.$K
$F0$PIt was a Daein soldier, right?$w4
The man who killed Commander Greil,$w4
who was it?$K
$F3$P...$K
$F0$PIKE!! TELL ME!!$K
$F4$FD$F4$FCL_SENERIO|$F4$PCan we discuss this later?$K
$F3$P$Fd...$K
$F0$P...$w4Oh...$w4 Yes... Yes. Of course.$K$F0$FD
$F4$PUp to this point, $w2we've all been
fighting for the liberation of Crimea.$K$PEven if we now add to that $w2stopping the
dark god from being released $w2and
punishing Commander Greil's killer...$K$POur enemy remains unchanged. $w5King Daein
and his henchman are the ones we must
defeat.$K
$F0$FCL_ERINCIA|$F0$PIt's mysterious, isn't it?$w4 I mean, Reyson
said the same thing earlier, but...$w4 Could
all of this really be mere coincidence?$K$PThe fall of Crimea... $w2Ike's parents... $w2The
death of Reyson's sister...$w4 The fact that
everything leads back to Daein...$w2$K$F0$FD
$F1$PIf true,$w4 it changes the meaning
behind this war...$K$PThe treatment of Lillia is one thing but...$w4
The assassination of the former apostle?$w2
The framing and destruction of my nation?$K$PIf it was all part of Daein's plan $w2to steal$w2
the medallion and the song, then I...
I...$w4$Fc$K
$F3$PReyson.$K
$F1$P$FdPlease, Ike. $w5Allow me to go with you.$w4
I... $w2I must confirm the truth of this!$K
$F3$PNo matter what happens,$w3 you must
promise to stay off the battlefield.$w2
If you do that, then I say yes.$K
$F1$PUnderstood.$w4 I will stand by my word.$K$F1$FD$w6
$F3$P...$K
$=2000   $R�w�i��b|$B���[���A�̕����ʎ�|$<$F3$FCL_IKE2|$F7$FCL_MIST|$F7$PIke!$w4 Ike! $w2Where are you?$K$FD
$F3$PMist! $w2I'm over here.$K
$F1$FCL_MIST|$F1$PIke! $w2Quickly!$w4 This way!$w4
Reyson's in trouble!!$K
$F3$PWhat?$K $R�w�i��b|$B���-��|$<$F1$FCL_IKE2|$F3$FCL_ANTIQUE|$F3$PHey, Ike! Er... General Ike! Wait up!$K
Say, if there's an enemy in my way,$w3
but I don't want to kill him,$w4
what do you think I should do?$K
$F1$P...$w4Is this about that stupid game again?$K
$F3$PWell, it's all your fault!$w4 You had to go
and tutor Daniel, and now I've been on
this losing streak!$K
$F1$PTutor?$w4 You mean back when we were
onboard the ship? $w2It was just one hint!$K
$F3$PDaniel isn't like me! $w2He's smart.$K$PI'm the one who thought up this game,$w3
but he's the one $w2who's getting better
and better.$w4 I hardly ever win anymore!$K
$F1$PInstead of playing that game,$w2
why don't you try some real combat?$K
$F3$P$FSStop joking around.$w4 We're happy-
go-lucky traveling merchants.$w4
We don't know anything about fighting.$K
$F1$PGive me a break!$w4 It's nice you're
having fun and all, but please...$K$PCan you save your stupid game for
someone who's not fighting for their
life day in and day out?$K
$F3$P$FAWell, $w2what do you expect?$w4
Everything's war, war, war,$w4 and
there's no place for us.$K$PAll we can do is play this game.$w4
Sorry... I'll just go lose again...$K
$F1$POh, for heaven's sake...$K$PLook, if there's an opponent you don't want
to kill,$w3 just shove him out of the way.$w2
Then you don't have to fight him.$K
$F3$PHuh?$w4 $FSOh, $w2t-thanks.$w3 ...Um...$w4
You know, we are what we are,$w2
but we'll be with you till the end.$K$PI hope we can continue $w2to be of service.$w4
All right?$K
$F1$P$FSYeah,$w3 thanks.$w4 Sorry for being so irritable.$K
$F3$PThat's all right.$w4 I know how much stress
you've been under.$K
$F1$P...$K    $R�w�i��b|$B���-��|$<$F1$FCL_SOTHE|$F1$P...$K
$F3$FCL_IKE2|$F3$PSomething on your mind?$K
$F1$POh, $w2Commander Ike!$w3 Oops!$w4
I guess I'm supposed to call you
General now, huh?$K
$F3$PCommander's fine.$K
So what's going on?$w3 Are you thinking
about that person you were looking for?$K
$F1$PThat's...$w2all settled.$w4 Actually, no...$w3
it's not really $w2settled.$K$PIt's just...$w3I figured that worrying about it
all the time wasn't doing me any good.$K$PI turned over every rock in Begnion during
my search, but...$w4 It's just easier to assume
that everything's going well...somewhere...$K
$F3$PWell, as long as you're happy, $w2I won't
say a word.$w4 So...what were you
thinking about then?$K
$F1$PI...$w3I didn't say anything before,
but$w2 Daein is my homeland.$K
$F3$PIs that so?$K
$F1$PYeah. Until a few years back, $w2I lived in the
slums of Nevassa$w3 and stole for a living.$K
$F3$P...$K
$F1$PSo anyway, $w2I went back to my old stomping
grounds and saw some friends.$K$PThe rest of the city's empty,$w3 but they're
still here.$w4 They've got no other place to
go, $w2you know?$K
$F3$PAnd what did they have to say?$K
$F1$PEvery one$w3 was mad that Crimea had won.$w4
They said if the king had been here, there's
no way they would've been defeated.$K$PIt's so weird. $w5Until now, $w2all they had ever
done was complain about this place.$K
$F3$PI see.$K
$F1$PYou know, Ashnard $w2wasn't such a bad king.
At least, as far as we could see.$K$PIf you were strong enough,$w3 you could
rise up and become a knight one day.$w4
You could escape the filthy slums.$K$PHe was the only king$w3 who ever gave us
that chance. That hope.$K
$F3$P...$K
$F1$PDon't get me wrong. $w2I don't mind fighting
with all of you.$K$PBut still,$w3 seeing your homeland scarred
and trampled like this is tough.$K$PI'm sorry.$w4 I know Crimea is suffering
in the same way, but... $w5I can't change
how I feel.$K$F1$FD
$F3$P...$K  $R�w�i��b|$B���{-�f�C��|$<$F1$FCL_SENERIO|$F3$FCL_IKE|$F1$PIke,$w3 I'd like to report the results
of our last battle.$K$N$UB$H $F3$P$FcI see.$K$P$UB$H $F1$P$FSThere were no deaths $w2and no injuries
beyond our capabilities to heal.$w4
Everyone performed exceedingly well.$K$P$UB$H   $F1$PThat is all.$w4 By your leave,$w2
I will excuse myself.$K    5x      5�   	  70     7�   "  7�   .  8�   :  9D   F  5   P  >4   c  B�   p  G      J   �  K�   �  tl   �  M   �  M�   �  O   �  R,   �  S�   �  `l   �  c�    k�    9�     >0  1  =�  D  =�  Y      o  uH  }  {�  �  d  �  �  �  �  �  �  �  �  �  �  �  !�  �  )�  �  .`  �  /�    1�    2  +  4X  :  �<  I  ��  Z  �X  i  ��  xMS_23_BT MS_23_BT_IKE MS_23_BT_R1 MS_23_BT_R2 MS_23_BT_R3 MS_23_BT_RI MS_23_DIE MS_23_DIE_TOMENAMI MS_23_ED_00A MS_23_ED_00A_B MS_23_ED_00B MS_23_ED_01 MS_23_ED_01_X MS_23_ED_01_X2 MS_23_ED_02A MS_23_ED_02B MS_23_ED_02X MS_23_ED_02XX MS_23_ED_03 MS_23_ED_03_2 MS_23_ED_03_3 MS_23_ED_03_4 MS_23_ED_SPECIAL MS_23_ED_SPECIAL_2 MS_23_ED_SPECIAL_DEL MS_23_ED_SPECIAL_DISP MS_23_GMAP_01 MS_23_INFO_02 MS_23_INFO_05 MS_23_OP_01 MS_23_OP_02 MS_23_OP_03 MS_23_OP_04 MS_23_OP_05 MS_23_OP_05_X MS_23_OP_05_XX MS_23_OP_06 MS_23_OP_07_01 MS_23_OP_07_02 MS_23_OP_07_03 MS_23_OP_07_04 MS_23_OP_07_05 MS_23_REPO_BEGIN MS_23_REPO_DIE MS_23_REPO_END MS_23_REPO_NODIE 