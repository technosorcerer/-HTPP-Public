  ۍ  �,       m                $R�w�i��b|$B���-���O�Y-��|$<$F0$FCL_NEALUCHI|$F3$FCL_TIBARN|$F3$PIs that it?$K
$F0$PWait, there's more!$K$PIt seems that Prince Reyson was able to
escape Duke Tanas's villa$w3 and make
his way safely to Serenes Forest.$K$PHowever...$w3we have word that Tanas's
men have entered the forest in hopes
of recapturing the prince.$K$PWe've not a moment to waste!$K$PPlease, O king of hawks! $w2Reach out your
mighty talons, strike down these wretched
humans, $w2and rescue Prince Reyson.$K$PI implore you, $w2Your Majesty,$w3
take wing at once!$K
$F3$P$FcWhy is Naesala not here?$K
$F0$PThat...er...$w3 His Highness $w2must not
be seen here at this time...$w3 It's--$K
$F4$FCL_JANAFF|$F4$PWhat's going on, $w2you old buzzard?$K
King Kilvas is the White Prince's
friend, isn't he?$K
$F0$PWell...$w3how do I put this?$w4
Hm, $w2it's all very complicated...$K
$F4$FD$F3$P$FdI care not for excuses.$w2 If anything happens
to Reyson,$w4 blood will be spilled.$K
$F0$POh, $w2no!$w3 Please!$w4 There's no cause for worry.$K$PDuke Tanas treats his works of art
with a delicacy so extreme that it
could best be called...$w3abnormal.$K$PHe would never let any harm
befall Prince Reyson.$K$P...He probably can't even bring
himself to touch him.$w2
The king himself told me so.$K$PThat is the only reason he
accepted this proposal--$K
$F4$FCL_VULCI|$F4$PProposal?$K
$F0$PAh!$w4 Um... What I mean is...
Er...$K
$F4$FD$F4$FCL_JANAFF|$F4$PHold it!$w3 You crows set the prince up?!$K
$F0$PS-$w2set up?$w4 Set up? Oh, no, no!$w4
Well...not exactly.$w2 Um...$w4
Please don't $w2hurt me!$K
$F4$FD$F3$PSo that's the truth of it, eh?$K$PNaesala treated Reyson like a piece
of merchandise$w3 and sold him.$w4
To a human...$K
$F0$PNo, $w2that's not...$w4 The only one who referred
to him as merchandise$w2 was Duke Tanas.
We never--$K
$F3$PIt doesn't matter!$K$PClaiming ignorance does not grant you
innocence.$w2 You treated Reyson
like a trinket in a public market!$K
$F0$POooh, dear...$K
$F3$PIf Reyson hadn't escaped on his own,$w2
perhaps the crow king would have rescued
him $w2when things cooled down.$K$PRegardless, $w2Reyson trusted in his
friend and followed him into the trap...$w3
And Naesala spit on that friendship.$K$PThat, I cannot forgive!$K
$F0$PYour assessment of this old bird is correct.
I am a worm, $w2nothing more.$K
But please, $w2I beg of you...$w4
Temper your outrage.$w2 Let it cool.$K
$F4$FCL_JANAFF|$F4$PYou're unbelievable.$w4 What is it
with you crows, anyway? $w2Everything
you do is so dirty and deceptive.$K$PWe will never understand your ways.$w4
Do you hear me, $w2greywings?$K
$F0$PI hear you well, young hawk.
But our nation... $w2Our nation has...$w4
It has its own issues.$K
$F4$FD$F0$PPlease, this is not the time to yell
at a tired old man.$w4 You must hurry
to Prince Reyson's side!$K$POnce he is safe, $w2you can punish me$w2
in any way that you see fit...
Tear me limb from limb if you wish...$K$PBut please!$w4 Go to Prince Reyson!$w3
I beg of you!$K
$F3$PThis begging is unseemly $w2and unwanted.$w2
We would rescue Reyson regardless
of this pathetic show of tears.$K$PReturn to Kilvas $w2and report these
events to your accursed king.$K$PTell him that when this is over, $w2King Tibarn
of Phoenicis will be paying him a visit.$K
$F0$P...Y-$w3yes, Your Highness!$K$F0$FD
$F4$FCL_JANAFF|$F4$PSigh...$w4 I know he deserves it,$w2
but I still feel bad for badgering
the old coot.$K
$F0$FCL_VULCI|$F0$PYour Majesty, $w2what will we do now?$K
$F3$PUlki, $w2use your ears to pick out the
sound of Reyson's wings, $w2then tell me
the direction from which it comes.$K
$F0$PAt once!$K$F0$FD
$F3$PJanaff, $w2use your eyes to peer between
the trees $w2and find me a road.$K
$F4$P$FSYou got it!$K$F4$FD
$F3$PHuman scum...$K$PIf you think to replay that night from
twenty years ago, $w5you'll get
no quarter from me.$K  $R�w�i��b|$B���-����-�x�O�j�I��|$<$F1$FCL_IKE|$F3$FCL_SENERIO|$F1$PHm?$w3 Is that you, Soren?$w5 You're up early.$K
$F3$P$FSActually, I'm always awake at this time.$K
$F1$P$FSReally?$K
$F3$PYes.$w3 You're the one who's up
earlier than normal.$K
$F1$P$FAI want to finish our mission today.$w2
I think my nervous energy woke me up.$K
$F3$P$FAI understand...$w3 The last two days spent
searching Serenes Forest for that heron
have been frustrating and fruitless.$K$PI'm sure he's in there somewhere, but...$K
$F1$PI agree.$w4 And Duke Tanas's men are still
hunting away.$w4 They must think the
heron is there as well.$K
$F3$PThe only place left is the forest's heart.$w4
That's where we should go today. With luck,
we may finally locate our target.$K
$F1$PI get the feeling it's going to be a
long day.$K $R�w�i��b|$B�X-�Z���m�X|$<$F4$FCL_SENERIO|$F3$FCL_IKE|$F4$PI believe this is the place $w2where we
ended our search yesterday.$K
$F3$PI realized something a couple of days ago...$w4
Even in this forest, $w2you always know exactly
where you are, $w2don't you?$K
$F4$PHm?$K
$F3$PHow do you do that? I think it's the lack
of color, but$w2 these woods are starting
to look the same to me.$K
$F4$PYes, that's a problem...$K
$F1$FCL_NASIR|$F1$PIke!$w4 We're approaching a large clearing.
I think we should have the apostle$w2 and
some of the others wait there.$K
$F3$PGood idea.$w4 Even if we find the heron
today, $w2there's no need for them to
tramp through the forest with us.$K
$F1$FD$F3$FD$F4$PMmm...$K
$F4$FD   $R�w�i��b|$B�X-�Z���m�X|$<$F4$FCL_ERINCIA|$F3$FCL_SANAKI|$F0$FCL_IKE|We're going to head deeper into the
forest and continue the search.$w3
Please wait here.$K
If we find the heron, $w2we'll send
for you immediately.$K
$F4$PI understand.$w4 My lord Ike, $w2everyone,$w2
please be careful.$K
$F3$P...$w2We're counting on you.$K
$F4$FD$F3$FD$F3$FCL_SIGRUN|$F4$FCL_TANIS|$F0$PSigrun? $w2Tanith? $w2May I entrust the princess
to your care?$K
$F3$P$FSOf course.$K
$F4$PYou've no need to worry.$w2
We will protect her with our lives.$K
$F0$PVery well. $w2Until later.$K    $R�㉺��b|$c0IKE|$s0All right. Greil Mercenaries,$w2
move out!$K   $R�㉺��b|$c0OLIVER|$s0Gah!$w3 Haven't you fools found
my precious little bird yet?$K$PI've no doubt $w2the poor thing is
even now quivering with
loneliness and cold.$K
$c1BEGNION1|$s1Duke Tanas!$w4 I've just received word
that the mercenaries who invaded your
villa $w2are in this forest!$K
$s0Blast!$w3 Those wretches...$w4 They're
here to steal my bird! $w2Their souls are
black with greed and jealousy!$K$PI have found beauty incarnate, and$w4
I will not relinquish it! $w5Only I, Duke
Tanas, can appreciate its worth!$K
$s1Um...$K$PI'm...$w4sure that's true, Your Grace,$w3
but what about the mercenaries?$w2
What should we do about them?$K
$s0Hunt them down like dogs!
Let none leave this forest alive!$w3
They will not rob me of my prize.$K
$s1But, Your Grace, $w2they serve at the
pleasure of the apostle herself!
Striking them would be--$K
$s0Leave the apostle to me! $w2I can deal
with her once this is finished!$K$PAll I need from you is silence and
obedience. Is that clear?$K
$s1Yes, Your Grace!$w4 I beg your pardon.$K   $R�㉺��b|$c0BEGNION1|$s0There they are! Do as Duke Oliver
commanded!$K$PSlay them where they stand!
Let none leave the forest alive, not
man, woman, or child!$K  $R�㉺��b|$c1IKE|$s1Oh, not the duke's soldiers again...$w4
I think it's about time we$w3
put an end to these fools.$K$PListen up, everyone!$w3
Let's end this here!$K $R�w�i��b|$B���C-�Z���m�X|$<$F1$FCL_IKE|$F1$PCurses!$w3 They just keep coming!$w2
How many soldiers does he have?$K
$F3$FCL_SENERIO|$F3$PThere's no telling.$w4 He is a bishop and a
senator, and he holds peerage, and that
means he could command many men.$K$N$UB$H $R�w�i��b|$B���C-�Z���m�X|$<$F1$FCL_IKE|$F1$PCurses,$w3 they just keep coming and coming.$w2
How many soldiers does he have?$K
$F3$FCL_NASIR|$F3$PThere's no telling.$w4 He is a bishop and a
senator, but he holds peerage, and that
means he could command many men.$K$N$UB$H    $F4$FCL_TIAMAT|$F4$PCommander,$w4 what do you think$w2
about calling in reinforcements?$K
$F1$PThat's not a bad idea.$w3 And while we wait,$w3
we could take a breather and reorganize
our attack strategy...$w4 Let's do it.$K $F4$FCL_NASIR|$F4$PPerhaps we, too,$w2 should call in a few
reinforcements. $w2What do you think?$K
$F1$PThat's not a bad idea.$w3 And while we wait,$w3
we could take a breather and reorganize
our attack strategy...$w4 Let's do it.$K   $F3$PPerhaps we, too, $w2should call in a few
reinforcements. $w2What do you think?$K
$F1$PThat's not a bad idea.$w3 And while we wait,$w3
we could take a breather and reorganize
our attack strategy...$w4 Let's do it.$K $R�㉺��b|$c1TIBARN|$s1What was that sound?$K
$c0JANAFF|$s0I heard something, too.$K
$c2VULCI|$s2It came from the northeast.$w2
It's unlike anything I've ever heard.$K
$s0To the northeast...?$w4 Aha!$w3 There are
ruins over there.$K$PPerhaps $w2the White Prince found them
to be a good hiding place.$K
$s1Let's check it out.$w4 Maybe we can find
him and escape while the humans fight
amongst themselves.$K
$s0What are those humans thinking?$w4
Why would they be trying$w2
to lop each others' heads off?$K
$s2Shall I make an inquiry?$K
$s1Leave them.$w4 They're nothing
but trouble.$K
$s0$FSI second that!$w4 Now, if we want to
avoid the human skirmish, we should
head...$w3thataway!$w3 Through these trees!$K
$s1Let's go.$K
$s2Yes, sir!$K $R�w�i��b|$B���C-�Z���m�X|$<$F0$FCL_IKE|$F0$PAll right, let's figure out where to go next.$K
$F1$FCL_MIST|$F1$PBrother!$K
$F0$PWhat is it, Mist?$K
$F1$PDid you...$w4hear $w2a sound just now?$K
$F0$PHuh?$w4 No, $w2I didn't.$K
$F1$PReally?$w4 I guess it was just me then.$K
$F3$FCL_LETHE|$F3$PThat sound you heard, was it high-pitched,$w2
like the chiming of a bell?$K
$F1$P$FSAh! $w2Yes, it was!$w4 That's it exactly!$K
$F4$FCL_MORDY|$FS$F4$PI heard it, too.$w3
It was very beautiful.$K
$F0$PI didn't hear a thing.$K
$F3$PIt created only a slight disturbance in
the air.$w4 It could only be heard by those
possessed of extraordinary hearing...$K$PSo, $w2your sister's hearing is on par
with that of the laguz.$K
$F1$PWow! Did you hear that?$w3 Neat!$K
$F0$PDon't let it go to your head.$K
A sound that beorc can't hear...$w2
Hmm...$w3 That's interesting.$K
$F4$FD$F4$FCL_NASIR|$F4$PIt is said that those of the heron clan
all practice the art of seid magic.$w4
Perhaps this sound is related to that?$K
$F1$P$FASeid magic?$w3 What's that?$K
$F4$PIt involves arcane songs known as galdrar.$w4
The effects of galdrar on the listener$w2
depend on the lyrics and melody.$K$PFor example, a galdr can restore lost
strength and vitality to those who hear it.$K$PAnd if the singer is of royal blood,$w3 the
galdr may be powerful enough to move
its listener to extraordinary feats.$K$PI've even heard tales of a galdr that could
give one the speed to do the work of
two men. The galdrar grant many powers.$K
$F1$P$FSWow...$w3 That sounds incredible,$w2
doesn't it, Ike!$K
$F0$PYeah.$w3 But even with all that
power, they were still wiped out
by the beorc.$K
$F1$P$FARight...$K
$F4$PHerons are highly attuned to the forces
of balance.$w5 Even if they had the means to
resist,$w2 I doubt they would have used them.$K$P$F4$FD$w4$F0$P...$K
We leave as soon as our reinforcements
arrive.$w4 Duke Tanas must not succeed!$w4
Let's rescue the heron while there's time!$K
$F1$PAll right!$K$F1$FD
$F3$PWe should head toward the ruins in
the northeast.$w3 I sense something
odd there.$K
$F0$P$FSGot it.$w4 Thanks for the information.$K
$F3$P$FSIt is nothing.$w4 It is only natural...$w3
to aid one's companions.$K
$F0$PI couldn't agree more.$K$P$F0$FD$F3$FD$w4$F4$FCL_NASIR|$F4$P...$K$F4$FD   $R�w�i��b|$B���C-�Z���m�X|$<$F0$FCL_IKE|$F0$PAll right,$w2 let's figure out where
to go next.$K
$F1$FCL_MIST|$F1$PBrother!$K
$F0$PWhat is it, Mist?$K
$F1$PJust now, did you...$w4hear $w2a sound?$K
$F0$PHuh?$w4 No, $w2nothing special.$K
$F1$PReally?$w4 I guess it was just me then.$K
$F3$FCL_LETHE|$F3$PThat sound you heard, was it high-pitched,$w2
like the chiming of a bell?$K
$F1$P$FSAh! $w2Yes, it was!$w4 That's it exactly!$K
$F0$PI didn't hear a thing.$K
$F3$PIt created only a slight disturbance in
the air.$w4 It could only be heard by those
possessed of extraordinary hearing...$K$PSo, $w2your sister's hearing is on par
with that of the laguz.$K
$F1$PWow! Did you hear that?$w4 Neat!$K
$F0$PDon't let it go to your head.$K
A sound that beorc can't hear...$w2
Hmm...$w3 That's interesting.$K
$F4$FCL_NASIR|$F4$PIt is said that those of the heron clan
are all practitioners of seid magic.$w4
Perhaps this sound is related to that?$K
$F1$P$FASeid magic?$w4 What's that?$K
$F4$PIt involves arcane songs known as galdrar.$w4
The effects of galdrar on the listener$w2
depend on the lyrics and melody.$K$PFor example, a galdr can restore lost
strength and vitality to those who hear it.$K$PAnd if the singer is of royal blood,$w3 the
galdr may be powerful enough to move
its listener to extraordinary feats.$K$PI've even heard tales of a galdr that could
give one the speed to do the work of
two men. The galdrar grant many powers.$K
$F1$P$FSWow...$w3 That sounds incredible,$w2
doesn't it, Ike!$K
$F0$PYeah.$w3 But even with all that
power, they were still wiped out
by the beorc.$K
$F1$P$FARight...$K
$F4$PHerons are highly attuned to the forces
of balance.$w5 Even if they had the means to
resist,$w2 I doubt they would have used them.$K$P$F4$FD$w4$F0$P...$K
We leave as soon as our reinforcements
arrive.$w4 Duke Tanas must not succeed!$w4
Let's rescue the heron while there's time!$K
$F1$PAll right!$K$F1$FD
$F3$PWe should head towards the ruins in
the northeast.$w3 I sense something
odd there.$K
$F0$P$FSGot it.$w4 Thanks for the information.$K
$F3$P$FSIt is nothing.$w4 It is only natural...$w3
to aid one's companions.$K
$F0$PI couldn't agree more.$K$P$F0$FD$F3$FD$w6$F4$FCL_NASIR|$F4$P...$K$F4$FD   $R�w�i��b|$B���C-�Z���m�X|$<$F0$FCL_IKE|$F0$PAll right,$w3 let's figure out where to go next.$K
$F1$FCL_MIST|$F1$PBrother!$K
$F0$PWhat is it, Mist?$K
$F1$PJust now, did you...$w4hear $w2a sound?$K
$F0$PHuh?$w4 No, $w2nothing special.$K
$F1$PReally?$w4 I guess it was just me then.$K
$F3$FCL_MORDY|$FS$F3$PI heard it, too.$w3 It was high-pitched
and clear, like a bell.$K
$F1$P$FSAh! $w2Yes, it was!$w4 That's it exactly!$K
$F3$PIt was very beautiful.$K
$F0$PI didn't hear a thing.$K
$F3$PIt was a small sound.$w4 Your ears would
need to be very sharp to hear it.$K$PMist, $w2your beorc ears are as
good as my laguz ones!$K
$F1$PWow! $w2Did you hear that?$w3 Neat!$K
$F0$PDon't let it go to your head.$K
A sound that beorc can't hear...$w2
Hmm...$w3 That's interesting.$K
$F4$FCL_NASIR|$F4$PIt is said that those of the heron clan
are all practitioners of seid magic.$w4
Perhaps this sound is related to that?$K
$F1$P$FASeid magic?$w4 What's that?$K
$F4$PIt involves arcane songs known as galdrar.$w4
The effects of galdrar on the listener$w2
depend on the lyrics and melody.$K$PFor example, a galdr can restore lost
strength and vitality to those who hear it.$K$PAnd if the singer is of royal blood,$w3 the
galdr may be powerful enough to move
its listener to extraordinary feats.$K$PI've even heard tales of a galdr that could
give one the speed to do the work of
two men. The galdrar grant many powers.$K
$F1$P$FSWow...$w3 That sounds incredible,$w2
doesn't it, Ike!$K
$F0$PYeah.$w3 But even with all that
power, they were still wiped out
by the beorc.$K
$F1$P$FARight...$K
$F4$PHerons are highly attuned to the forces
of balance.$w5 Even if they had the means to
resist,$w2 I doubt they would have used them.$K$P$F4$FD$w4$F0$P...$K
We leave as soon as our reinforcements
arrive.$w4 Duke Tanas must not succeed!$w4
Let's rescue the heron while there's time!$K
$F1$PAll right!$K$F1$FD
$F3$PWe should head towards the ruins in
the northeast. I smell something...$K
$F0$P$FSGot it.$w4 Thanks for the information.$K
$F3$P$FSYou're welcome.$w4 I am always
happy $w2to help Ike.$K$P$F0$FD$F3$FD$w6$F4$FCL_NASIR|$F4$P...$K$F4$FD    $R�w�i��b|$B���C-�Z���m�X|$<$F0$FCL_IKE|$F0$PAll right, let's figure out where to go next.$K
$F1$FCL_MIST|$F1$PBrother!$K
$F0$PWhat is it, Mist?$K
$F1$PJust now, did you...$w4hear $w2a sound?$K
$F0$PHuh?$w4 No, $w2nothing special.$K
$F1$PReally?$w4 I guess it was just me then.$K
$F4$FCL_NASIR|$FS$F4$PA high-pitched sound? $w2Like the
chime of a bell?$K
$F1$P$FSAh! $w2Yes, it was!$w4 That's it exactly!$K
$F0$PI didn't hear a thing.$K
$F4$PIt came from the ruins to the northeast.$w4
It was a very slight sound indeed--$w4one
that required extraordinary ears to hear.$K$PWhich means that $w2your sister has hearing
par on with that of the laguz.$K
$F1$PWow!$w3 Did you hear that?$w4 Neat!$K
$F0$PDon't let it go to your head.$K
A sound that beorc can't hear...$w2
Hmm...$w3 That's interesting.$K
$F4$PIt is said that those of the heron clan
are all practitioners of seid magic.$w4
Perhaps this sound is related to that?$K
$F1$P$FASeid magic?$w4 What's that?$K
$F4$PIt involves arcane songs known as galdrar.$w4
The effects of galdrar on the listener$w2
depend on the lyrics and melody.$K$PFor example, a galdr can restore lost
strength and vitality to those who hear it.$K$PAnd if the singer is of royal blood,$w3 the
galdr may be powerful enough to move
its listener to extraordinary feats.$K$PI've even heard tales of a galdr that could
give one the speed to do the work of
two men. The galdrar grant many powers.$K
$F1$P$FSWow...$w3 That sounds incredible,$w2
doesn't it, Ike!$K
$F0$PYeah.$w3 But even with all that
power, they were still wiped out
by the beorc...$K
$F1$P$FARight...$K
$F4$P$FAHerons are highly attuned to the forces
of balance.$w5 Even if they had the means to
resist,$w2 I doubt they would have used them.$K
$F0$P...$K
We leave as soon as our reinforcements
arrive.$w4 Duke Tanas must not succeed!$w4
Let's rescue the heron while there's time!$K
$F1$PAll right!$K$P$F0$FD$F1$FD$w4$F4$P...$K$F4$FD   $R�w�i��b|$B���C-�Z���m�X|$<$F1$FCL_IKE|$F1$PAll right, let's figure out where to go next.$K
$F3$FCL_LETHE|$F3$PWe should head towards the ruins in
the northeast.$w3 I sense a presence
there.$K
$F1$PA presence?$K
$F3$PIt happened a moment ago and was a mere
whisper. Only laguz ears could have heard
it. $w2Perhaps it was a signal of some sort.$K
$F1$PA sound that beorc can't hear...$w2
Hmmm...$w3 That's interesting.$K
$F4$FCL_NASIR|$F4$PIt is said that those of the heron clan
are all practitioners of seid magic.$w4
Perhaps this sound is related to that?$K
$F3$PSeid magic?$w4 What's that?$K
$F4$PIt involves arcane songs known as galdrar.$w4
The effects of galdrar on the listener$w2
depend on the lyrics and melody.$K$PFor example, a galdr can restore lost
strength and vitality to those who hear it.$K$PAnd if the singer is of royal blood,$w3 the
galdr may be powerful enough to move
its listener to extraordinary feats.$K$PI've even heard tales of a galdr that could
give one the speed to do the work of
two men. The galdrar grant many powers.$K
$F3$P...$w3What amazing power.$K
$F1$PYeah.$w3 But even with all that
power, they were still wiped out
by the beorc.$K
$F3$PAh!$w2$K
$F4$PHerons are highly attuned to the forces
of balance.$w5 Even if they had the means to
resist,$w2 I doubt they would have used them.$K$P$F4$FD$w4$F1$P...$K
We leave as soon as our reinforcements
arrive.$w4 Duke Tanas must not succeed!$w4
Let's rescue the heron while there's time!$K
$F3$PI understand...$K$F3$FD$w4
$F1$PLethe, hold on a moment.$K
$F3$FCL_LETHE|$F3$PWhat is it?$K
$F1$P$FSThe sound and the ruins...$w2
Thanks for telling me about them.$K
$F3$PIt is nothing.$w4 $FSIt is only natural...$w3
to aid one's companions.$K
$F1$PI couldn't agree more.$K$P$F3$FD$F1$FD$w4$F4$FCL_NASIR|$F4$P...$K$F4$FD $R�w�i��b|$B���C-�Z���m�X|$<$F1$FCL_IKE|$F1$PAll right, let's figure out where to go next.$K
$F3$FCL_MORDY|$F3$PIke!$w4 We should go to the ruins
in the northeast.$w4 I sense something
odd there.$K
$F1$PSomething odd?$K
$F3$P$FSYes.$w4 There was something...$w2
A sound $w2only laguz could hear.$w4
It was very $w2beautiful.$K
$F1$PA sound that beorc can't hear...$w2
Hmm...$w3 That's interesting.$K
$F4$FCL_NASIR|$F4$PIt is said that those of the heron clan
are all practitioners of seid magic.$w4
Perhaps this sound is related to that?$K
$F3$P$FASeid magic? What's that?$K
$F4$PIt involves arcane songs known as galdrar.$w4
The effects of galdrar on the listener$w2
depend on the lyrics and melody.$K$PFor example, a galdr can restore lost
strength and vitality to those who hear it.$K$PAnd if the singer is of royal blood,$w3 the
galdr may be powerful enough to move
its listener to extraordinary feats.$K$PI've even heard tales of a galdr that could
give one the speed to do the work of
two men. The galdrar grant many powers.$K
$F3$P$FSThe Serenes are amazing, aren't they?$K
$F1$PYeah.$w3 But even with all that
power, they were still wiped out
by the beorc.$K
$F3$P$FAYou're right...$w4 Why did that$w2
have to happen?$K
$F4$PHerons are highly attuned to the forces
of balance.$w5 Even if they had the means to
resist,$w2 I doubt they would have used them.$K$P$F4$FD$w4$F1$P...$K
We leave as soon as our reinforcements
arrive.$w4 Duke Tanas must not succeed!$w4
Let's rescue the heron while there's time!$K
$F3$PThat's right!$w4 And I will$w2
do all that I can to help!!!$K$P$F1$FD$F3$FD$w6$F4$FCL_NASIR|$F4$P...$K$F4$FD    $R�w�i��b|$B���C-�Z���m�X|$<$F1$FCL_IKE|$F1$PAll right, let's decide.$K
$F4$FCL_NASIR|$FS$F4$PWe should move towards the ruins
in the northeast.$w4 I sense something
odd there.$K
$F1$PSomething odd?$K
$F4$PYes...$w3 There was a very faint sound,$w2
something only a laguz could hear.$w4
I think it was $w2a signal of sorts.$K
$F1$PA sound that beorc can't hear...$w2
Really?$w3 That's interesting.$K
$F4$PIt is said that those of the heron clan
are all practitioners of seid magic.$w4
Perhaps this sound is related to that?$K
$F1$P$FASeid magic?$w3 What's that?$K
$F4$PIt involves arcane songs known as galdrar.$w4
The effects of galdrar on the listener$w2
depend on the lyrics and melody.$K$PFor example, a galdr can restore lost
strength and vitality to those who hear it.$K$PAnd if the singer is of royal blood,$w3 the
galdr may be powerful enough to move
its listener to extraordinary feats.$K$PI've even heard tales of a galdr that could
give one the speed to do the work of
two men. The galdrar grant many powers.$K
$F1$PYeah.$w3 But even with all that
power, they were still wiped out
by the beorc.$K
$F4$P$FAHerons are highly attuned to the forces
of balance.$w5 Even if they had the means to
resist,$w2 I doubt they would have used them.$K
$F1$P...$K
We leave as soon as our reinforcements
arrive.$w4 Duke Tanas must not succeed!$w4
Let's rescue the heron while there's time!$K
$F1$FD$w4$F4$P...$K$F4$FD   $R�㉺��b|$c1RIEUSION|$s1Cursed humans...$w3 How dare they defile
this forest again!$w4 I will brook their
savagery $w2no more!$K$PThe forest whispered earlier,$w3 but I
must drive these wretches out$w2
before I can speak to it further.$K$PI will go to the altar...$w4
I will give voice to the forbidden
magic and destroy the humans utterly!$K    $R�㉺��b|$c0BEGNION1|$s0There they are! $w2The Crimean
mercenaries!$w4 Surround them!$w3
They must all die!$K$d0  $R�㉺��b|$c1IKE|$s1Listen, everyone! $w2We must make our
way to the ruins in the northeast.$w4
Fight if you must, $w2but keep up!$K
$c2SENERIO|$s2Ike!$w3 What about the reinforcements?$K
$s1They'll have to catch up.
We can't wait any longer!$K
$s2Understood.$K  $R�㉺��b|$c1IKE|$s1Listen, everyone! $w2We must make our
way to the ruins in the northeast.$w4
Fight if you must, $w2but keep up!$K
$c2NASIR|$s2Ike!$w3 What about the reinforcements?$K
$s1They'll have to catch up.
We can't wait any longer!$K
$s2Understood.$K    $R�㉺��b|$c1IKE|$s1Listen, everyone! $w2We must make our
way to the ruins in the northeast.$w4
Fight if you must, $w2but keep up!$K
$c2SENERIO|$s2Understood!$K   $R�㉺��b|$c1IKE|$s1Listen, everyone! $w2We must make our
way to the ruins in the northeast.$w4
Fight if you must, $w2but keep up!$K   $R�w�i��b|$B���C-���|$<$F1$FCL_IKE|$F1$PWhew...$w2we finally made it.$w4
Let's split up and search the
surrounding area.$K
$F4$FCL_TIAMAT|$F4$PCommander,$w4 do you think $w2we
should call more reinforcements?$K
$F1$PThe duke's army seems nearly limitless,
and I'm worried about our weapon situation.$w3
Let's do it.$K $R�w�i��b|$B���C-���|$<$F1$FCL_IKE|$F1$PWhew...$w2 We finally made it.$w4
Let's split up and search the
surrounding area.$K
$F4$FCL_NASIR|$F4$PIke,$w4 what do you think of
calling in more reinforcements?$K
$F1$PThe duke's army seems nearly limitless,$w4
and I'm worried about our weapon situation.$w3
Let's do it.$K   $=0700$R�w�i��b|$B���C-�Z���m�X|$<$F1$FCL_IKE|$F1$PHey, what's this?$K
$F0$FCL_TIAMAT|$F0$PWhat is it, $w2Commander?$K
$F1$PLook here.$w4 This is the only place in these
ruins where I've seen healthy grass growing.$K
$F0$PYou're right. I wonder why?$K
$F1$PAnd I found this...$K
$F0$PA white feather?$w4 So we were right.$w2
The heron is around here somewhere.$K
$F1$PIt's possible, but...$K
$F7$FCDUMMY|$F7$PIke!$w4 Over here!$K
$F1$PWhat now?$K$=0500   $=0700$R�w�i��b|$B���C-�Z���m�X|$<$F1$FCL_IKE|$F1$PHey, what's this?$K
$F0$FCL_NASIR|$F0$PWhat is it, Ike?$K
$F1$PLook here.$w4 This is the only place in these
ruins where I've seen healthy grass growing.$K
$F0$PYou're right.$K
$F1$PAnd I found this.$K
$F0$PA white feather?$w3 Of course.$w4
So this is where...$K
$F1$PWhere what?$K
$F0$PThis way.$w4 Come with me.$K
$F1$PWhat now?$K$=0500  $=0500$R�㉺��b|$c1IKE|$s1Nasir!$w4 What have you found?$MC$w3$Y
$c0NASIR|$s0$MC...$MDA heron.$K   $R�㉺��b|$c1LEARNE|$s1#F01$O2Whatever is this...?#F02$O1$K$d1$w5
$c0IKE|$s0...Um...$w4 That's a girl.$K
Nasir, you said that the male heron
we met $w2was the only surviving
member of the race.$K
$c2NASIR|$s2I believed it to be true.$w4
To find another survivor...$w3
It's a miracle.$K  $R�㉺��b|$c0LEARNE|$s0#F01$O2...Who are you?#F02$O1$K $R�㉺��b|$c0IKE|$s0Hey, $w2wait, please!$w4
I must speak--$K  $R�㉺��b|$c0LEARNE|$Fc$s0#F01$O2Yaaaa$MC...!$MDStay away, human!#F02$O1$K $R�㉺��b|$c0IKE|$s0Come $w2on. $w2Wake up.$K
$s1$Fc$c1LEARNE|$s1#F01$O2$MC......$MD#F02$O1$K
$d0$c0TIAMAT|$s0She's fainted dead away.$K
$d1$c1IKE|$s1I guess there's nothing I can do
but wait for her to come around.$w4
I wasn't trying $w2to frighten her.$K   $R�㉺��b|$c0IKE|$s0Come $w2on. $w2Wake up.$K
$s1$Fc$c1LEARNE|$s1#F01$O2$MC......$MD#F02$O1$K
$d0$c0NASIR|$s0She's lost consciousness.$K
$d1$c1IKE|$s1I guess there's nothing I can do
but wait for her to come around.$w4
I wasn't trying $w2to frighten her.$K   $R�㉺��b|$c1OLIVER|$s1Oh! $w2Oh! $w2Oh!$K
I've found you at last!$w2
My beautiful treasure!$K
$c0IKE|$s0It's about time you showed your
bloated face, Duke Tanas!$K
$s1Oh! $w2Oh...$w4 No mistake about it.$w4
That $w2is the spectacular work of art
I paid so much to obtain...$K
$s0$FhYou still claim ownership, do you?$K    $R�㉺��b|$c1OLIVER|$s1No, $w2wait...$w4 Something's different...$w4
This is...a female!? You mean to
tell me that yet another lives?$K$PHow spectacular!$w2
Men!$w3 Bring me that heron!
But do her no harm!$K
$c0IKE|$s0You'll never have her!$K $R�㉺��b|$c0IKE|$s0$FdAgain?$w4 Will this corpulent
windbag never learn?$K$PForm up, troops!$w4
We must protect the heron!$K  $R�㉺��b|$c0OLIVER|$s0Aaa...$w3aaarrrrrgggghhhh!$w4
What vexatious wretches!
I am...overmatched!$K$PI can't believe$w3 I'm saying this, but...$w4
there's another $w2white heron!$K$PRe-$w2retreat!$w4 Leave them their
prize!$K  $R�㉺��b|$c1IKE|$s1Blast! $w2Duke Tanas has escaped!$K
$c0SENERIO|$s0Ike? $w2Perhaps trying to fight
with that heron on your back$w2
is not the wisest of ideas.$K$PWhy don't we $w2take her to the
apostle before moving on?$K
$s1We've finally got $w2Duke Tanas on the
run!$w4 I don't intend to stop until we've
captured or killed that monster!$K
$s0I understand, $w2but shouldn't we at
least let someone else carry the
heron?$K
$s1Truth be told,$w3 she's unbelievably light.
I barely know she's there.$K
$s0Is... $w2Is that so?$K$d0
$s1$FSI think she weighs... Oh, I'd say
about half as much as Mist.$K
$c3MIST|$s3Wow!$w3 I'm surprised!$K
$d1$s1$FS$c1BOLE|$s1I'll bet you are...$K
$d3$s0$Fh$c0MIST|$s0What are you grinning about,$w3 Boyd?$K
$s1Oh, nothing...$w4 I'm just amazed...
Did you know you're two times
heavier$w2 than she is!?$K$PI'm glad I don't have to carry
you around!$w3 It'd be like wearing
an extra suit of armor!$K
$s0$FdYou... You pig!$w4 You're the worst!$K    $R�㉺��b|$c1BOLE|$s1Gaaa!$K$d1
$c0IKE|$s0All right, maybe I exaggerated a bit.
But $w2she's still lighter than you.$K
$c3MIST|$s3Well, what do you expect?$w4
She's a bird!!!$K   $R�㉺��b|$c1IKE|$s1Blast! $w2Duke Tanas has escaped!$K
$c0SENERIO|$s0Ike, $w2trying to fight$w3 with that
heron on your back $w2is not
a good idea.$K$PWhy don't we $w2take her to
the apostle before moving on?$K
$s1We've finally got $w2Duke Tanas on the
run!$w4 I don't intend to stop until we've
captured or killed that monster!$K
$s0I understand, $w2but shouldn't we at
least let someone else carry the
heron?$K
$s1Truth be told,$w3 she's unbelievably light.
I barely know she's there.$K
$s0Is... $w2Is that so?$K
$s1$FSI think she weighs... Oh, I'd say
about half as much as Mist.$K
$c2MIST|$s2Huh?$w3 You're kidding, right?$K
$s0Mmm...$w3 I see.$K
$s2You see?$w3 What's that supposed to
mean, $w2Soren?$K$PYou know that Ike's making fun of
me, don't you?$w4 He's just a big jerk!!$K
$s1All right, maybe I exaggerated a bit.
But $w2she's still lighter than you.$K
$s2Well, what do you expect?$w4
She's a bird!$K $R�㉺��b|$c0IKE|$s0Blast! $w2Duke Tanas has escaped!$K
$c1NASIR|$s1What will you do, Ike?$w4 Shall we go
and report back $w2to the apostle?$K
$s0We've finally got $w2Duke Tanas on the
run!$w4 I don't intend to stop until we've
captured or killed that monster!$K
$s1It's your choice.$K
$=0500   $R�㉺��b|$c0TIAMAT|$s0Commander,$w4 if this battle is going to
continue, $w2I think we should get
more reinforcements.$K$=0500    $=0500$R�㉺��b|$c0NASIR|$s0If this conflict is going to drag on,$w2
I think it best for us to call up some
reinforcements.$K$=0500    $R�㉺��b|$c1RIEUSION|$s1Avoiding those human scum cost me
time...$w4but I've almost made it to
the altar.$K   $R�㉺��b|$c0TIBARN|$s0Reyson!$w4 Are you well?$K
$c1RIEUSION|$s1Tibarn!$w4 How did you--$K
$s0Nealuchi told us everything.$K
$s1Oh...$w4 Allow me to apologize.$K$Fc$PI left on my own $w2without a word to
you, and this $w2is what happened.$K
$s0$FSAs long as you're unharmed,$w2
all is well.$w4 Let's go home.$K
$s1$FoPlease, $w2give me a little time.$w4
I cannot allow these humans
to remain in the forest.$K
$s0$FAI understand how you feel,$w3 but we're
completely outnumbered.$w4 Let us
wait for another day--$K
$s1Once I stand at the altar,$w3
I can take care of them.$w4
Every one of them.$K
$Ub$H$s0You can't mean... $w5Are you thinking
of using the forbidden magic?$K
$s1...Yes.$w4 I will sing those monsters
the$w2 dirge of ruin.$K
$s0Are you mad?! You mustn't!$w3
I can't allow it!$K
$s1With permission or without, I do what
I must! It is retribution for genocide!$w4
Retribution for this forest!$K
$s0Reyson!$w3 You must not let yourself
be ruled by despair!$K$PEach member of the heron tribe is an
embodiment of balance!$w4 Do this,$w4
and you warp your very existence!$K
$s1That's what they all said...$w3
My family.$w2 My tribe.$w4$Fc
And then...$w2they died.$K$PThe humans were drunk with joy.
They laughed!$w4 They sang!$w4 ...And then
they slaughtered us like livestock.$K$PMy mother, $w2my brother, $w2my elder
sisters...$w3 Even my infant sister,$w2
Leanne!$w4 All killed $w2in a single night.$K
$s0Reyson...$K
$s1$FdI know.$w4 This thing I intend to do$w3
brings dishonor to my house.$w4
And yet...$w2I cannot forgive.$K
And their past actions weren't enough;$w2
now, they violate the sanctity of the
forest$w2 without a trace of regret!$K$PAccursed humans...$Fc
I will never forgive them!$K
$s0Don't you think we understand that?$K
$s1$Fd...$K
$c2JANAFF|$s2That's right!$K$PPrince Reyson, there's no need for
you to reject your honor based on
the likes of them!$K
$d2$c2VULCI|$s2The tragedy of the herons...$w4
The horror and pain of that night...$w2
lives on in all of us.$K$d2
$Ub$H$s0Let's return to Phoenicis,$w3 and think
of a plan.$Ub$H$K$FS$PYou are right. $w2This will not stand.$w5
The full power of the hawk nation is
behind you. $w2The humans will pay.$K
$s1...$w4As you wish...$K$=1000  $R�㉺��b|$c1IKE|$s1Enough already!$w4 Lay down
your arms and surrender.
We will let you live!$K
$c0OLIVER|$s0Grrrrrr...$w4 No! Never!
I'm not giving up!$w3
I'm not finished yet!$K$POut of my way, penniless wretches!$w4
Your very existence is an insult
to all that is beautiful!$K
All you really want is my wealth$w4
and beauty!$w2 Miserable curs...$w3 You
reek of poverty and envy!$K$POh, but I understand your emotions...$w2
Yes, I do.$w4 How could you sad
vagabonds $w2not want to be me?$K
$s1...$w2That's the last thing in the world--$K
$s0Silence!$w4 I am not one to be daunted
by mean beggars such as you.
Oh ho ho ho!$K$PIn the name of the goddess,
I, Oliver, duke of Tanas,$w3
will smite your hideous evil!$K
$s1$FhUm...$K
$s0To arms! To arms!$w4 Defend me$w2
with all the strength you possess!$K$POh, and $w2bring me the little
bird that blue-haired lout is
carrying while you're at it...$K
$s1...Oh, please.$K    $R�㉺��b|$c1IKE|Here they come!$w4 Combat formation,
everyone!$K  $R�㉺��b|$c0JANAFF|$s0Uh-oh!$w3 They're still going at it
over here.$w4 Shall we go around?$K
$c1TIBARN|$s1I suppose so.$w4 Two human armies
bashing one anothers' brains out...$w3
I wonder what they're after.$K
$c3RIEUSION|$s3Ah!$K   $R�㉺��b|$c1TIBARN|$s1There's that sound again.$w4
Reyson, $w5are you doing that?$K
$s3$Fc$c3RIEUSION|$s3...$K
$s1No, I suppose not.$K
$s3...The forest$w4 is whispering something.$K$P#F01$O2What is it?#F02$O1$K$P#F01$O2$MC...$MDWhat are you$w2 trying to$w4 tell me?#F02$O1$K
$c0JANAFF|$s0King Tibarn!$w4 Prince Reyson!$w4
Look! $w2There!$K
$Ub$H$s1Eh?$K
$s3$FoAh?$K
$s0The blue-haired human is carrying
something on his back...$w3
No, it can't be...$K
$s1Is that...$w3another heron?$K
$s3...But...that's not...$K$d3
$s1I think some of the humans might be$w3
fighting to protect the heron.$K$PGrr...$w3 It's against my nature, but...
we shall aid them!$w4 Janaff! $w2Ulki!$w3
To me!$K
$c2VULCI|$s0Right$MC!$w4$MD$Y
$s2Yes, sir!$K
$d1$d0$d2$w6$c1RIEUSION|$s1Tibarn!$w4
$Ub$HPlease... $w2Allow me $w2to go with you.$K
$c0TIBARN|$s0$FSIf you forswear the forbidden
magic, $w2you may come.$K
$s1$FSAgreed.$K    $R�㉺��b|$c0RIEUSION|$s0$FhUrgh...$K
$c1TIBARN|$s1Reyson, withdraw! $w5Leave the rest
to us.$w4 Do you understand?$K
$s0$FcI'm sorry...$K $R�㉺��b|$c0RIEUSION|$s0Urgh...$K
$c1TIBARN|$s1Reyson!$w4 This way.$K$PPah!$w3 Who are these humans?$w5
They're ridiculously strong!$K    $R�㉺��b|$c0JANAFF|$s0Yeowch! $w2Ah...$K
$c1TIBARN|$s1Pull back, Janaff! $w5You've nothing$w2
to prove to me.$w4 I'll not forgive you if
you go and get yourself killed.$K
$s0$FhI'm $w1ashamed...$K  $R�㉺��b|$c0VULCI|$s0Aaa!$K
$c1TIBARN|$s1Withdraw, Ulki! $w5You've fought a good
fight.$w4 I won't lose you now.$K
$s0$Fh...Understood.$K $R�㉺��b|$c0TIBARN|$s0...Urk! $w5Impossible...$K$PLooks like $w2I need to pull back.$K    $R�㉺��b|$c0OLIVER|$s0Listen to me, you boors!$w3
You cannot possibly understand
the pursuit of beauty.$K$PYou are savages! $w2You are a blight
on the world, and you must die!$K $R�㉺��b|$c0OLIVER|$s0You lowborn, vulgar, penurious vermin!$w5
Return my little bird to me!$K$PObjects of beauty must be admired!
Only by my side can they fulfill the
purpose for which they are created!$K
$c1IKE|$s1I$w3 am$w4 SO TIRED of listening $w2to your
nonsense, you massive gasbag!$w5
This ends $w2here and now!$K $R�㉺��b|$c0OLIVER|$s0Oh, $w2such a hideous creature!$w5
Noooo! Stay back,$w3 you filthy beast!$K
$c1MORDY|$s1I am Mordecai. $w3I am not filthy...$w2
It is your soul that is unclean.$K  $R�㉺��b|$c0OLIVER|$s0Shoo! $w2Go away now!$w5
Nobody wants a monster feline...$w3
Gyaaa! $w2Get out of here!$K
$c1LETHE|$s1$FhYou're the type of scum $w2that
cause laguz to detest beorc!$w3
I will enjoy this, fat man!$K  $R�㉺��b|$s1$FS$s1$c1DALAHOWE|$s1Devdan $w2likes pretty things, too.$K
$c0OLIVER|$s0Wh-$w2who are$w3 you?$K
$c1DALAHOWE|$s1But things are only pretty where you
find them.$w4 Locking them away $w2is sad.
It makes Devdan upset...$K
$s0Grrr...$w3 That peculiar face...$w4
I've seen it$w3 somewhere before.$K$PUm...err... $w5It's no use. Your ill-favored
face clouds my memory.$K
$s1You have a bad memory, large man.$w3
Let Devdan give you a present that
you will not forget...$K   $R�㉺��b|$c0OLIVER|$s0$FhOhhh...$w3ahhh...$K
I...$w2cannot...$w2fall here...$w2
It cannot...$w2be...$w4$Fc
Such a...$w4loss...$w2to beauty...$K   $R�w�i��b|$B���C-�Z���m�X|$<$F3$FCL_IKE|$F0$FCL_RIEUSION|$F3$PIt's you!$K
$F0$POn your back...$w4 Who is it $w2you carry?$K
$F3$POh, the girl?$w4 I think she may be$w2
somebody you know, but...$K
$Ub$H$P$Ub$H$F4$Fc$F4$FCL_LEARNE|$F4$P#F01$O2$MC...$MD$w4#F02$O1$K
$F0$P#F01$O2Leanne!#F02$O1$K
$F4$P$Fd#F01$O2Reyson, my brother?#F02$O1$K$P#F01$O2Brother!$w3 Brother!!#F02$O1$K
$F0$P#F01$O2Is it really you,$w2 Leanne?#F02$O1$w4
#F01$O2This is no$w2 dream?#F02$O1$K$PHow is this possible? How did you
survive all this time?$K $R�㉺��b|$c0TIBARN|$s0Leanne? $w2Do you know who I am?$K
$c1LEARNE|$s1#F01$O2Tibarn?#F02$O1$w5
#F01$O2Of the hawk tribe,$w2 yes?#F02$O1$K
$s0$FSThat's right.$w4 You remember my name.$K$P$FAHave you been here by yourself
for all these years?$K
$s1#F01$O2I don't $w2know...#F02$O1$w5
#F01$O2That night$MC...$MD My sisters $w2took me#F02$O1
#F01$O2and hid me $w2in the small shrine.#F02$O1$K$P#F01$O2I'm sure $w2they sang a galdr to me$MC...$MD#F02$O1$w5
#F01$O2And then$w2 I became so sleepy...#F02$O1$K
$d1$c2RIEUSION|$s2The forest protected her.$w4
It kept her asleep for so long...$K
There's no way to express
my gratitude.$K$Fc$P#F01$O2Thank you...#F02$O1$w4
#F01$O2With all that I am,$w2 I thank you.#F02$O1$K
$Ub$H$d2$s0You there, $w2beorc.$K
$c1IKE|$s1Me?$K
$s0I am Tibarn, $w2king of Phoenicis.$K
Since the loss of their homeland,$w2
the Serenes royal family has been
under my guardianship.$K$PWho are you, and why do you
aid $w2the herons?$K
$s1My name is Ike.$w4 I am commander
of the Greil Mercenaries.$K$PI am $w2under orders of the
empress,$w4 the apostle Sanaki,$w2
to protect the herons.$K
$s0The empress of this country $w2wants
to protect the herons?$w4 $FSHa!$w2
That is an interesting tale.$K$P$FAThe herons were blamed for the
assassination of the last empress.$w2
They were massacred on hearsay.$K$PAnd now her ancestor $w2wants
to help them?$w4 Touching.$K
$s1The empress $w2Sanaki knows$w2 that
the herons are not murderers.$K$PAnd now, $w2she is trying to atone
for the crimes of her people.$K
$c2RIEUSION|$s2...$w4No. I cannot believe that.$K
$s0...$K
$s2Pathetic apologies and half-baked
platitudes are easily spoken!$K$PHumans burned Serenes Forest.$K
They killed my family.$w4 I cannot trust
one who allies himself with them.$K
$s1Please, withhold judgment until you$w2
speak with the apostle.$w4 She's
waiting $w2at the forest's edge.$K
$s2The apostle $w2is here?$K  $R�㉺��b|$c0RIEUSION|$s0So you...$w4are the apostle?$K
$c1SANAKI|$s1I am.$K
$s0...$K  $R�㉺��b|$c1SANAKI|$s1...I'm...$w4$Fcsorry...$K$Fd$PI am ignorant as to what words of
contrition$w4 will be appropriate
to one of the heron tribe.$K$PYet$w4 I stand before you $w2as a
representative of my people...$w4$K$PFrom the depths of my heart$w2
I apologize to you...$K$Fc$PI am sorry...$w4 So truly sorry...$K  $R�㉺��b|$c1SIGRUN|$s1Emp-$w2Empress Sanaki!
What are you doing?$K$PYou are the apostle! You cannot
bend your knee to another!$K
$c2IKE|$s2Peace!$K
Let her speak her heart.$K
$s1I...um...$K $R�㉺��b|$c0RIEUSION|$s0...$K
$s1$Fc$c1SANAKI|$s1I'm sorry...$w4
I'm sorry...$K
$c2LEARNE|$s2#F01$O2That is$w2 enough...#F02$O1$K
$s1$Fd...?$K
$s0Leanne?$K
$s2$FS#F01$O2Please rise, Apostle Sanaki.#F02$O1$K
$s1You... What is it you want?$w4
Are you telling me$w3
to stand?$K    $R�w�i��b|$B���C-�Z���m�X|$<$F1$FS$F1$FCL_LEARNE|$F3$FCL_SANAKI|$F3$PYou...$K
$F1$P#F01$O2It is$w2 enough.#F02$O1
#F01$O2It was not your$w2 fault.#F02$O1$K$F1$FD
$F0$FCL_RIEUSION|$F0$PLeanne!$K
$F4$FCL_LEARNE|$F4$P$FA#F01$O2Brother$MC...$MD$w3it is enough, is it not?#F02$O1$w4
#F01$O2Forgive this child.#F02$O1$w5
#F01$O2Her apology is$MC...$MD$w4so sincere.#F02$O1$K
$F0$PLeanne! You cannot ask me$w2 to forgive them!$w4
You were asleep... $w5You don't know
what these humans did to us...$K
$F4$P#F01$O2$MC...$MDI do know.#F02$O1$w5
#F01$O2The forest$MC...$MD$w3told me everything.#F02$O1$K
$F0$PYou...$w3know?$K
$F4$P#F01$O2...Everyone#F02$O1$Fc$w4
#F01$O2...is...gone, $w2aren't they?#F02$O1$K
$F0$PThat's right... $w5Everyone$w4 is gone.$w5
That's why I cannot release my hatred.$K
$F4$P$Fd#F01$O2Brother$MC...$MD$w3 My loving brother, $w2Reyson.#F02$O1$w5
#F01$O2The pain and sadness $w2is in you, Brother.#F02$O1$w2
#F01$O2It clouds your very soul.#F02$O1$K$P#F01$O2To see you like this,$w3 to watch you.#F02$O1$w3
#F01$O2It hurts me.#F02$O1$w5
#F01$O2Please$MC...$MD$w4do not lose yourself$w2 to hate.#F02$O1$K
$F0$P#F01$O2Leanne, my sister.#F02$O1$K$Fc$PI understand.$w4 If that is how you feel...$K
$F3$P...$K
$F0$P$FdApostle Sanaki...$w4 We $w2accept your apology.$K$PWe may not be able to release our hatred
of hum--$w5 of beorc, but...$K$PYou need not let the fate of Serenes
Forest $w2trouble you any longer.
You are absolved of that guilt......$K
$F3$P$FSTh-$w4thank $w1you...$K
$F0$FD$F4$FD$F4$FS$F4$FCL_IKE|$F4$PThat was well done.$K
$F3$PYes...$K
$=0800    $R�w�i��b|$B���C-���|$<$F4$FCL_ERINCIA|$F3$FCL_IKE|$F4$PMy lord Ike, $w2what will happen now?$K
$F3$PThe heron siblings $w2said there
would be some sort of ceremony,
but I don't know what that entails.$K
$F0$FCL_JANAFF|$F0$PYou there! $w2Beorc mercenaries!$w4
Prince Reyson $w2wants all of you to come
to the Serenes altar.$K$PThe presence of Princess Crimea and
the apostle is also requested.$K
$F3$PAltar?$K
$F0$PJust come with me.$w3 It's this way.$K$F0$FD
$F4$PEmpress Sanaki, $w2Commander Sigrun,$w4
let us go.$K$F4$FD
$F4$FCL_SANAKI|$F4$PVery $w2well.$K$F4$FD
$F1$FCL_MIST|$F1$PLet's hurry, $w2Ike!$K
$F3$PRight.$K
$=0800   $R�㉺��b|$s0$FS$c0TIBARN|$s0That was excellent.$K
$s1$FS$c1ERINCIA|It's so beautiful...$K
$d0$d1$w6$s3$FS$c3SANAKI|$s3The Serenes Forest,
beloved of the goddess,$w4
is alive once more.$K
$s1$FS$c1SIGRUN|You spoke so well earlier,$w2
Empress Sanaki.$w4$Fc
You fill my heart with pride... Sniff...$K
$s3$FAHere now! $w2None of that.$w4
This is no place for tears!$K
$s1$FdI'm $w2sorry...$w4 I'm just$w4 so happy...$K    $R�w�i��b|$B���C-�Ւd|$<$F2$FS$F2$FCL_NASIR|$F2$PAh, excellent. $w2The gap between laguz
and beorc has been bridged.$K
I think this may be enough...$K$P$F2$FD$w6$F3$FCL_SENERIO|$F3$P...$K
$F4$FS$F4$FCL_TIAMAT|$F4$PWhat's wrong, $w2Soren?$w4 You look so grim.$w4
What are you looking at?$K
$F3$PIt's nothing.$w4 Nothing at all.$K
$F3$FD$F4$P$FAWait, $w2Soren! $w5What in the world$w3
is wrong with him?$K
$=2000 $R�㉺��b|$c0OLIVER|$s0St-$w2stay back!$K$PA filthy beast like you...$w3
How dare you approach a sanctified$w2
personage such as myself!$K
$c1MWARIM|$s1Who is it$w3 that decided that
a laguz life is worth less
than a human?$K$PDo you believe the goddess Ashera,$w2
whom you claim to worship,
would want it to be so?$K
$s0Aaaaaaah!$w4 Monster!$w3 Hideous,
vile monster!$w4 You will not defile
the name of the goddess!$K
$s1Monster? $w2Which of us is
the true monster?$K   $R�㉺��b|$c1OSCAR|$s1Is everyone all right? Hang in there!$w4
I'll be with you in a moment!$K $R�㉺��b|$s1$FS$c1BOLE|$s1Sorry to keep you waiting...$w4
Leave the rest of these jerks $w2to me!$K   $R�㉺��b|$c1LOFA|$s1Whew! I made it!$w4
I... I won't let you down!$K  $R�㉺��b|$c1TIAMAT|$s1Looks like I'm just in time.$w5
Now that I'm here,$w3 the enemy$w2
does not stand a chance!$K   $R�㉺��b|$c1SENERIO|$s1Soren reporting for duty.$w4 Do not
worry about their numbers. My magic
will make short work of them.$K    $R�㉺��b|$s1$FS$c1GATRIE|$s1...Puff... Puff... Whew!$w4 There you are!$w5
Hold on, $w2everyone!$w4 Your knight
in shining armor has arrived!$K    $R�㉺��b|$c1MIST|$s1Hey, Brother!$w4 How goes the battle!$w2
...Looks like you're outmanned!$w4
Let me help!$K    $R�㉺��b|$c1KILROY|$s1Oh, dear. Is anyone injured?$w4
Let me attend to them.$K    $R�㉺��b|$s1$FS$c1WAYU|$s1Here we go, boss!$w4
The real fighting$w2 starts now!$K $R�㉺��b|$s1$FS$c1MARCIA|$s1Oh, jerky!$w4 That's a lot of dudes...$w4
Well, I'm ready to go.$w4 Let's make
hash out of these guys!$K  $R�㉺��b|$c1LETHE|$s1Hsss! What took you so long?$w3
My claws long for the feel
of human flesh!$K $R�㉺��b|$c1MORDY|$s1The beorc who hurt this forest$w3
will answer $w2to me.$K    $R�㉺��b|$s1$FS$c1VOKE|$s1If I'm called in for emergencies,$w2
I charge double the standard rate.$w4
I get overtime, too.$K   $R�㉺��b|$c1KEVIN|$s1Captain Kieran, Crimean Royal Knight,
Fifth Platoon, ready for duty!$w4
Look upon me and tremble!$K  $R�㉺��b|$c1CHAP|$s1Yeah, uh...$K
Are you sure I'm the one you
wanted?$w4 Ooh...$w3 I hope
this is over quickly.$K    $R�㉺��b|$c1NEPENEE|$s1Reporting for duty.$K  $R�㉺��b|$c1ZIHARK|$s1Sorry$w3 to have taken so long!$w4
I'll be with you in a moment.$K  $R�㉺��b|$c1ELAICE|$s1...Ran...puff...all the way...puff...here...$w3
Hold on... Puff... Kinda dizzy...$w4
...And so hungry...$K  $R�㉺��b|$c1SOTHE|$s1Wow... This forest is...um...$w4
kinda spooky...$w4 Yaaaah!
What was that?!$K    $R�㉺��b|$c1JILL|$s1Reinforcements are here!$w4
I'm ready $w2to do my share.$K    $R�㉺��b|$c1STELLA|$s1As a fellow citizen of Begnion,$w3 I find
this situation deplorable.$w4 Repent now,
if you like.$w4 Your time grows short.$K    $R�㉺��b|$c1MAKAROV|$s1What?$w3 I have to fight? Already?$w4
That vacation $w2was far too short.$w3
Maybe I can just hide in the back...$K    $R�㉺��b|$s1$FS$c1SOANVALCKE|$s1Now then, $w2first things first!$w4
Anyone who gets too close, gets cut.$K    $R�㉺��b|$s1$FS$c1TOPUCK|$s1My magic and I have arrived!$w4
Step back $w2and behold the most
powerful mage in the world!$K    $R�㉺��b|$c1MWARIM|$s1Sorry to have kept you waiting.$w4
I'll join the fray directly.$K   $R�㉺��b|$s1$FS$c1DALAHOWE|$s1Don't make Devdan upset.$w4
You wouldn't like Devdan
when he's upset...$K   $R�w�i��b|$B���-����-�x�O�j�I��|$<$F1$FCL_IKE|$F3$FCL_TANIS|$F3$PCommander Ike!$w4 A priest from$w2
Duke Tanas's villa$w3 insists on$w2
speaking with you.$K$F3$FD
$F4$FCL_BEGNIONB|$F1$PYes? What is it?$K
$F4$PUm...$w2 Master mercenary.$w4 It is my
understanding$w3 that you...$w4
you pursue Duke Tanas.$K$PI hear that you're searching Serenes
Forest$w3 in hopes of capturing him.$K
$F1$PAnd $w2if I am?$K
$F4$PDuke Tanas's property borders the forest,
and he knows much about its layout.$K$PFor quite some time now,$w3 he's been sending
men into the forest$w3 to look for any
herons who may still live there.$K
$F1$PI see...$w3 So you're saying that his troops
know the forest well.$K
$F4$PI, too, have been taken into the forest.$K
$F1$PYou?$w2 Why take a priest?$K
$F4$PHe thought that herons would make
themselves known if a priest
called to them.$K$PHe's also taken dozens $w2of chaste maidens$w3
and tried having them call to the herons
as well.$K
$F1$PBut he didn't find any, did he?$K
$F4$PNo.$w4 And yet, $w2this time...$K$PThe joy he expressed $w2after paying such
an exorbitant price for the Serenes royal$w4
was aberrant.$w4 It was...$w3not natural.$K$PThe duke has gone mad.$w3 To think that
he would dare to defy the apostle...$w3
He is damned.$K
$F1$PAnd $w2here you stand.$K$PYou're going to tell me what you remember
about the forest,$w2 even though it means
you're betraying Tanas...$w4right?$K
$F4$PHmm... You read me well.$w4 To begin with,
the heart of the forest$w3 was divided into$w2
three large sections.$w3 Maybe more.$K$PIt was nearly colorless, $w2and difficult
to see far.$w3 The muddy floor pulled
at our feet, and progress was slow.$K$PMany of the soldiers around me were afraid
that they didn't bring enough supplies.$K$PThey said a person would need them if
he got lost, $w2because getting out
again would be no easy task.$K
$F1$PWhat can you tell me about Duke Tanas's
forces?$K
$F4$PThere were a lot of them...$w3
He had soldiers of every type.$K$PIt was said that$w2 his mounted units
and magic users$w3 were especially
powerful.$K$PSo at the very least, $w2you should be
prepared to deal with those two groups.$K
$F1$PThank you.$K
$F4$P...$w3My parents...$w4 They both participated
in the Serenes massacre.$K$PThey're nearing the ends of their lives,
but $w2even now they lie awake at night
and$w3 beg the goddess for forgiveness.$K$PI$w3 became a priest in order to help my
parents, but$w3 then I was assigned to work
at Duke Tanas's villa...$K$PI knew of his terrible deeds,$w3 but his
position as an imperial senator frightened
me.$w3 I have been silent for far too long.$K$PMaster mercenary...$w3 You must rescue
that Serenes youth. I beg of you.$w4
May the goddess guide your hand.$K$P$F1$PDon't worry.$w4 I have no intention of
letting that villain $w2steal him from
before my very eyes.$K   $R�w�i��b|$B���-����-�x�O�j�I��|$<$F1$FCL_JILL|$F4$FCL_IKE|$F4$PHere you are.$K
$F1$P...$K
$F4$PWe've been in Begnion $w2for a
while now.$w4 So tell me something...$w2
Why are you still here?$K$PAre you pretending to be our friend$w3
so you can lance us in the back?$K
$F1$P...You have to understand...$K$PI...$w3I didn't know anything. $w5I was born and
raised in the Talrega region of Daein.$w3
It's a very remote area.$K$PMy father was a soldier,$w3 and I grew up
thinking that I, too,$w3 would one day be a
soldier.$w2 A soldier to make my father proud.$K$PMy life was simple...$w4 I questioned nothing.
Doubted nothing.$K
$F4$P...$K
$F1$PDo you know the first thing$w3 we're taught
in Daein schools?$K$PSub-humans are evil.$w4
Sub-humans are the enemy.$w4
Sub-humans $w2must be eradicated.$K$PThe army stages periodic sub-human hunts.
We'd find refugees from Begnion hiding$w2
in our mountains and forests...$K
$F4$P$FcYou participated?$K
$F1$PYou don't get it!$w4 That's just how things
are in Daein!$K$PNo one taught me the word laguz!$w3 No one
taught me that sub-humans could be...
could be like this.$w4 No one cared.$K
$F4$P$Fd...$K
$F1$PWhen I saw the bird tribes at sea,$w4 I was
convinced that the teachings were true.$w5
They were inhuman monsters.$K$PBut later,$w4 I saw the dragons push your
ship off of the reef, and$w4 it confused me.$K$PWhat if I had been raised to believe a lie?$w4
My heart pounded at the thought of it.$w3
And my doubts only grew with time.$K
$F4$PSo$w3 you decided to remain aboard
in order to ascertain the truth.$w3
That's your true motive, isn't it?$K
$F1$PHow did you know?$K
$F4$PI've known a lot of soldiers, and none$w3
would ever accept charity $w2from an enemy.$w2
It would wound their pride.$K$PYou obviously have pride to spare,
so I knew there was some other
factor at play.$K
$F1$P$FcOh...$K
$F4$PWell,$w3 have you reached a conclusion?$w4
What will you do?$K
$F1$P$FdI...$w2want to stay here.$w4 At first, I thought I
could protect my old life, that I could
prove the sub-humans were monsters.$K
But I was wrong. And now things$w2
are different. The sub-hu--$w2
I'm sorry,$w3 the laguz...$K$PI want to know the truth about them,
and I need to base that on what I see,
not what I am told by others.$K
$F4$PIn that case, $w2you can stay as long
as you like.$K
$F1$PI appreciate it.$w4 I think meeting all of you...
was a very good thing.$K  $R�w�i��b|$B��̒�|$<$F1$FS$F1$FCL_DALAHOWE|$F1$PLa la $w2la! La la laaaaaa! Hmmmm...$w4
La $w2laaaa$w4 hmmmmmlaaaaaa!
La de di da de laaaaaa...$w2$K
$F3$FCL_IKE|$F3$P...$w4Um... Hey there, $w2you.$w4 Have a minute?$K
$F1$POh,$w3 Captain!$w4 How are you today?$K
$F3$PIt's $w2commander. Not captain.$w4
Well...you seem to be enjoying yourself.$K
$F1$PThat's because this garden is so pretty.$w4
Devdan $w2loves all plants and flowers.$w4
How about you, $w2Commander?$K
$F3$PThey're all right, I suppose.$K
$F1$P$FAThat makes Devdan $w2rather sad.
All right is not a very strong feeling.$K$PIt is boring. You should be a more
emotional commander.$K$PEven things you're used to $w2will show you
something new$w3 if you look hard enough.$w4
And discoveries $w2are exciting!$K$PThat's what life is all about!$w5 At least,
that's what Devdan thinks. Some disagree...$w4
and that makes Devdan upset!$K
$F3$P...$w4You may be$w3 on to something.$K$PIn Crimea,$w3 when my father was still alive,$w3
I think I was more open to such things.$w4
But now...$w4I just don't have the time.$K$PHonestly,$w4 all I can think about $w2is
defeating Daein.$w4 I've no energy left to
spend on flowers.$K
$F1$P...$w2If you talk like that,$w3
you will never defeat Daein.$K
$F3$PWhat did you say?$K
$F1$PThe war $w2is new.$w4 If you are already so
focused on preparations,$w3 you'll wear out
before the fighting begins.$K$F1$FD
$F3$PHold on a minute!$w5
...$K $R�w�i��b|$B���-����-�x�O�j�I��|$<$F1$FCL_SENERIO|$F3$FCL_IKE|$F1$PIke,$w3 I'd like to report the results
of our last battle.$K$N$UB$H    $F3$P$FcI see.$K$P$UB$H $F1$P$FSThere were no deaths $w2and no injuries
beyond our capabilities to heal.$w4
Everyone performed exceedingly well.$K$P$UB$H   $F1$PThat is all.$w4 By your leave,$w2
I will excuse myself.$K    ��      ��   	  ��     ��   "  ��   .  ��   :  �l   F  �H   P  �0   a  ��   t  ��   �  �   �  �    �  �   �  �t   �  ��   �  �   �  ��   �  ��   �  �  
  �(    ��  "  �  1  �  ?  �  O   �  _  �  p  ]�  �  ^�  �  !x  �  $\  �  -<  �  5�  �  >0  �  E�  �  L�    S    X�  (  Zt  8  [|  I  \�  \  ](  m  Z   �  j�  �  t�  �  u4  �  kl  �  o@  �  o�  �  s�  �  c�    `0    a�  +  c�  >  e  O  e<  c  e|  t  e�  �  f�  �  g�  �  i  �  j  �  ��  �  ��  �  u�  �  v,    ~�    �t  ,  ��  <  ��  L  �L  \  ��  p  ��  �  ��  �  �  �  ��  �  ��  �  �d  �  �p  �  �X  �  �<    �D    ��  -  �  ?  ��  R  �$  c  �   v  �  �  ��  �  ��  �  �p  �  ��  �  �  �  �<  �  ��    ��    �(  !      /  �  ;    I  �  U    c  \  o  h  {    �  ��  �  �P  �  ��  �  �h  �MS_18_BT MS_18_BT_DA MS_18_BT_IKE MS_18_BT_LE MS_18_BT_MO MS_18_BT_MW MS_18_DIE MS_18_DIE_JANAFF MS_18_DIE_RIEUSION MS_18_DIE_RIEUSION_2 MS_18_DIE_TIBARN MS_18_DIE_VULCI MS_18_ED_01 MS_18_ED_02 MS_18_ED_03_1 MS_18_ED_03_1_2 MS_18_ED_03_1_3 MS_18_ED_03_2 MS_18_ED_04 MS_18_ED_05 MS_18_ED_06 MS_18_ED_06_00 MS_18_EV_A_ed MS_18_EV_A_ed_B MS_18_EV_A_ed_N MS_18_EV_A_ed_N2 MS_18_EV_A_ed_T MS_18_EV_B_ed MS_18_EV_B_ed_B MS_18_EV_B_op MS_18_EV_B_op_1 MS_18_EV_B_op_2_A MS_18_EV_B_op_2_B MS_18_EV_B_op_2_C MS_18_EV_B_op_2_D MS_18_EV_B_op_2_E MS_18_EV_B_op_2_F MS_18_EV_B_op_3 MS_18_EV_B_op_4A MS_18_EV_B_op_4A_B MS_18_EV_B_op_4B MS_18_EV_B_op_4B_B MS_18_EV_B_op_4_0 MS_18_EV_C_ed MS_18_EV_C_ed_A MS_18_EV_C_ed_B MS_18_EV_C_ed_XA MS_18_EV_C_ed_XA_2 MS_18_EV_C_ed_XB MS_18_EV_C_ed_XC MS_18_EV_C_op_000 MS_18_EV_C_op_00_A MS_18_EV_C_op_00_B MS_18_EV_C_op_01 MS_18_EV_C_op_01_B2 MS_18_EV_C_op_02 MS_18_EV_C_op_03 MS_18_EV_C_op_04 MS_18_EV_C_op_04_B MS_18_EV_C_op_05 MS_18_EV_C_op_05_2 MS_18_EV_C_op_05_3 MS_18_EV_D_ev MS_18_EV_D_ev_2 MS_18_EV_D_op MS_18_EV_D_op_2 MS_18_EV_D_op_4 MS_18_EV_D_op_5 MS_18_EV_Z_BOLE MS_18_EV_Z_CHAP MS_18_EV_Z_DALAHOWE MS_18_EV_Z_ELAICE MS_18_EV_Z_GATREE MS_18_EV_Z_JILL MS_18_EV_Z_KEVIN MS_18_EV_Z_KILROY MS_18_EV_Z_LETE MS_18_EV_Z_LOFA MS_18_EV_Z_MAKAROV MS_18_EV_Z_MARSHA MS_18_EV_Z_MIST MS_18_EV_Z_MORDY MS_18_EV_Z_MWARIM MS_18_EV_Z_NEFENEE MS_18_EV_Z_OSCAR MS_18_EV_Z_SENERIO MS_18_EV_Z_SOANVALCKE MS_18_EV_Z_SOTHE MS_18_EV_Z_STELLA MS_18_EV_Z_TIAMAT MS_18_EV_Z_TOPUCK MS_18_EV_Z_VOKE MS_18_EV_Z_WAYU MS_18_EV_Z_ZIHARK MS_18_INFO_01 MS_18_INFO_02 MS_18_INFO_04 MS_18_OP_01 MS_18_OP_01_2 MS_18_OP_02 MS_18_OP_02_2 MS_18_OP_03 MS_18_OP_04 MS_18_OP_05_01 MS_18_OP_05_02 MS_18_REPO_BEGIN MS_18_REPO_DIE MS_18_REPO_END MS_18_REPO_NODIE 