 s^ O�      |                $RTUT��b|$s1$FS$c1ANNA|Hi! If you're just starting the game,
you'll want to know a little about Ike.$K$PYoung Ike is the son of Greil,
and he's the hero of this game.$K   $RTUT��b|$s1$FS$c1ANNA|Our story revolves around
Ike and his adventures.$K$P$s1$FAIf at any time during the game
Ike loses all of his HP, or hit points,$w3
your game will end.$K$PAnd you know what that means, right?$w3
It means you have to try again.$w4
So be careful out there.$K$P$s1$FSWhat next$MC...$MD$w2 Oh, yes, there are some
commands only the main character can
use.$w2 They are Order$w1 and Direct.$K$PI'll tell you what these commands
do some other time.$K$PFor now, $w1the important thing
to remember is that the main
character is the key to the game.$K  $RTUT��b|$s1$FS$c1ANNA|So that's about everything you need
to know about Ike$MC...$MDfor now, at least!$K  Would you like
to see this again?   #S50 - Demonstration - #s   $RTUT��b|$s1$FS$c1ANNA|Now it's time to learn about the map
menu.$K$POn the map menu,$w2 you can manage
allies and the overall game settings.$w3
Press #P033#P034 to view it.$K    $RTUT��b|$s1$FS$c1ANNA|The map menu has five options: Unit,$w2
Guide,$w2 Options,$w2 Suspend,$w2 and End.$K$PPay attention while I give you a quick
explanation of each one.$K $RTUT��b|$s1$FS$c1ANNA|Let's start with the Unit command.$w3
Use this to see information on
all allied units in the field.$K   $RTUT��b|$s1$FS$c1ANNA|As you can see, this handy display
provides a lot of information about
the members of your party.$K $RTUT��b|$s1$FS$c1ANNA|Move #P02C left or right or
press left or right on #P031
to turn menu pages.$K$PSort your units by different headings
by selecting that heading and then
pressing #P027.$K$PHere,$w2 I'll demonstrate for you.$K    $RTUT��b|$s1$FS$c1ANNA|The heading selected$w3 and the order
in which it appears are shown inside
the box with the red frame.$K    $RTUT��b|$s1$FS$c1ANNA|Next is Guide.$w3 You can see basic
game instructions here. As you play,
more topics will appear in this list.$K    $RTUT��b|$s1$FS$c1ANNA|Guide topics become available as
you progress through the game.$w2
You can access them at any time.$K$PTopics you've already reviewed are
in white,$w3 and ones you haven't
reviewed flash green.$K$PTopics shown in gray text$w2
are not yet available$MC...$MD$K$PDon't worry, though$MC--$MDyou'll open
them all eventually.$K$PIf you forget how something works$w1
or want to see a Guide topic again,$w1
select Guide from the map menu.$K    $RTUT��b|$s1$FS$c1ANNA|Let's move to Options next.$w3
This is where you can adjust
all sorts of game settings.$K   $RTUT��b|$s1$FS$c1ANNA|From this menu, you can set the
message speed$w3 and turn display
windows on or off, for example.$K$PGo ahead and adjust the settings
as you see fit$w3 and customize the
game however suits you best.$K    $RTUT��b|$s0$FS$c0ANNA|Now let's take a look at Suspend.$w3
Use Suspend to save your game
midchapter so you can quit anytime.$K    $RTUT��b|$s0$FS$c0ANNA|If you select this, you'll be asked if
you really want to suspend your game.$K$PChoose Yes to save your progress
up to that point.$K$PYou can continue a suspended game
by choosing Resume Chapter$w2 from
the file menu.$K$POnce you resume a game,$w2 your
suspended data is gone for good,
so be careful.$K  $RTUT��b|$s0$FS$c0ANNA|And last but not least is End.$w3
Select this to finish your turn$w3
and begin the enemy phase.$K   $RTUT��b|$s1$FS$c1ANNA|Use this when you want to end
your turn without moving all of
your units.$K $RTUT��b|$s1$FS$c1ANNA|Well, that's it for your introduction
to the map menu!$K$PRemember, the map menu can be
accessed at any time during the
player phase,$w2 so use it wisely.$K    $RTUT��b|$s1$FS$c1ANNA|All right, now it's time to learn
about turns.$K$PIn this game, $w2the player controls
the $Ub$Hallied units,$w3 and the computer
controls the $Ub$Henemy units.$K$PEach side takes turns moving,$w3
and that's how the game progresses.$K  $RTUT��b|$s1$FS$c1ANNA|So here's how it works:$w2
One side issues and follows orders,$w3
then the other side does the same.$K$PEach turn is made up of a number of
phases. During a phase, one side
moves all of its units.$K$PAnd when the enemy moves its
units, why, that's called the$MC--$MD$K    $RTUT��b|$s1$FS$c1ANNA|That's right! The enemy phase!$K$PWhen it's your turn to move,
it's called the$MC--$MD$K    $RTUT��b|$s1$FS$c1ANNA|Exactly. The player phase.$K$PAnd the combination of both
phases makes up one turn.$K$PRemember,$w1 it takes both the player
and enemy phases to make a turn.$w2
This is important!$K   $RTUT��b|$s1$FS$c1ANNA|Well, that wraps it up for my
explanation of turns.$K   $RTUT��b|$s1$FS$c1ANNA|Let me tell you a little about
movement range now.$K$PMovement range, as you might have
guessed, $w2shows the maximum number
of spaces a unit can move.$K$PBefore you can move a unit, you'll
need to know about the cursor.$K$PYou can move the cursor with either
#P02C$w2 or #P031.$K$Ub$H
$PTo start off, $w2place the cursor on
the unit you want to move.$K   $RTUT��b|$s1$FS$c1ANNA|Once the cursor is on the unit,$w2
press #P027.$K$PThis will select the unit$w2 so that
you'll be able to control him.$K    $RTUT��b|$s1$FS$c1ANNA|Voila! $w2Can you guess what the
different colors of the lit area mean?$K$PThe blue area shows movement range,$w3
and the orange spaces $w2show the
maximum attack range.$K$PMovement ranges $w1and attack ranges$w2
vary between units. Be sure to keep
that in mind.$K$PI guess it's about time we actually
moved somebody, isn't it?$w2 First,
$w2you need to choose a destination.$K$PIf you move #P02C, $w2an arrow will extend
from the unit.$w3 The arrow marks the
path the unit will take.$K   $RTUT��b|$s1$FS$c1ANNA|Move the arrow to the destination
space, $w2and press #P027
to send the unit to that space.$K   $RTUT��b|$s1$FS$c1ANNA|All right then! $w2I'm going to give this
unit his marching orders!$K   $RTUT��b|$s1$FS$c1ANNA|When the unit finished moving,$w3
a menu appeared over to the
right, didn't it?$K$PThis is the command menu, which
displays unit commands.$K$PCommands are the orders you
can issue to your units.$K$Ub$H
$PI'm going to order the unit I just
moved to wait.$K$PUse #P02C to select Wait,$K$Ub$H
$Pthen press #P027 to confirm$w2
and end the unit's movement.$K   $RTUT��b|$s1$FS$c1ANNA|And that wraps up the movement-
range tutorial!$K   $RTUT��b|$s1$FS$c1ANNA|It's time now for me to tell you how
to engage an enemy in direct combat.$K$PAs you can see, $w2there are two
units on the battlefield: a blue unit
and a red unit.$K$PThe blue unit is the player-controlled
allied unit, $w2and the red unit is the
computer-controlled enemy unit.$K$PNow I'll move the allied unit $w2next to
the enemy unit.$w4 Here goes!$K   $RTUT��b|$s1$FS$c1ANNA|Look at the command menu.$w2
You see the Attack command,
$w1right?$K$PBe warned: if you don't have
a weapon you can attack with,$w2
the Attack command will not appear.$K$POnce you've chosen to attack,$w3
you'll see a window with all of
the unit's available weapons.$K $RTUT����b|$ND$W2This display shows all of
the weapons this unit
can use to attack.$K$PUse #P02C$w2 to choose the
weapon you want to use.$K$Ub$H
$PThe window below$w2 shows
info on the weapon
you've highlighted.$K$PSo, choose a weapon,$w2
press #P027 to equip it,$K$Pand get ready to move
into combat.$K    $RTUT����b|$ND$W1Before engaging in combat,$w2
information on your unit$w2 and
the enemy unit will be displayed.$K$PThis is the display shown here
on the left.$w4 It's called $w2the
combat-information window.$K$Ub$H
$PThe information in the blue portion
of this window$w2 refers to
your unit.$K$Ub$H
$PThe information in the red portion
of this window$w2 refers to
the enemy unit.$K$Ub$H
$PNext, $w2select your enemy.$K$PIf there are multiple enemies
within your attack range,$w2 use the
cursor to pick one of them.$K$PIn this case, there's only one
enemy, $w2so all you have to
do is press #P027.$K    $RTUT��b|$s1$FS$c1ANNA|And that's it for your lesson in
direct combat!$K   $RTUT��b|$s1$FS$c1ANNA|Now it's time for a quick lesson
on the Shove command.$K$PWith the exception of mounted
units, $w1all units are able
to shove.$K$PAnd, $w2as long as the conditions
are right, $w2you can shove
anyone you choose.$K$PFirst, $w2I'll shove an enemy unit.$K$PTo start off, $w2I'll move the allied
unit next to the enemy unit.$K   $RTUT��b|$s1$FS$c1ANNA|You can see Shove in the
unit menu, right?$K$PSelect this $w2to hit an
adjoining unit$w1 and move it
out of the space it's in.$K$PMove the cursor to Shove,$w2
and press #P027 to select it.$K  $RTUT��b|$s1$FS$c1ANNA|Next, $w2you'll see a window
displaying the weight of
both units.$K$PA unit can shove another if its
weight is no more than 2 below
the other unit's weight.$K$PI know that sounds complicated,
so let's look at the window here$MC...$MD$K$Ub$H
$PThe unit wanting to shove has
a weight of 10,$K$Ub$H
and the unit to be shoved has
a weight of 12, $w1right?$K$PThat's within 2, $w2so the
Shove command is viable.$K$PAll right, $w2let's give it a try.$K  $RTUT��b|$s1$FS$c1ANNA|Well, $w2that's that.$K$PA note of caution, though:$w2 shoving$w2
pushes a unit a space away,$w2
but it does no damage.$K$PAdditionally,$w2 you can shove
not only enemy units, but also$K$Pallied units,$Ub$H$K$Pgreen Other units,$Ub$H$K$Pand yellow Partner units, too.$Ub$H
As I said earlier,$w1 you can shove
anyone you choose. So, shove away!$K   $RTUT��b|$s1$FS$c1ANNA|That's all you need to know
about the Shove command.$K$PTo summarize,$w2 there are two
conditions that must be met.$K$P1. Mounted units$w4 cannot shove.$K$P2. A unit shoving another cannot
be more than 2 lighter than the
shoved unit.$K$PRemember this, and everything
will be all right.$K $RTUT��b|$s1$FS$c1ANNA|Now we move on to the fun part of
the tutorial: leveling up!$K$PWhen you engage in combat$w2 or
use staves$w2, you gain experience
points $w2and become stronger.$K$PThe amount of experience you gain is
shown on-screen. $w2It differs in
relation to the results of your attack.$K$PWell, $w2here goes!$K    $RTUT��b|$s1$FS$c1ANNA|Uh-oh$MC...$MD$w4
That attack, um, $w2missed.$K$PIf you fail to hit the enemy,$w2
you still get experience points$MC...$MD$w2
just not very many.$K$PAll right, $w2let's try that again.$K  $RTUT��b|$s1$FS$c1ANNA|Good.$w2 That attack found its mark.$K$PWhen you hit your opponent,$w3 you
receive more experience points.$K$PThe enemy should be weakened after
that.$w4 Time to deliver the finishing
blow. Go on!$K  $RTUT��b|$s1$FS$c1ANNA|All right!$w3 The enemy's been defeated!$K$PWhen you vanquish a foe, $w2you'll
receive a lot of experience points.$K$PSo basically, $w2you build up experience
by engaging in battle after battle.$K$PThen, $w2when you gain 100 experience
points, $w1you level up!$K  $RTUT��b|$s1$FS$c1ANNA|When you level up,$w2 your stats
like Strength $w1and Defense $w1go up.$K$PThe higher your stats,$w3 the better
you do in combat. $w2So, higher stats
means a better warrior.$K$PIt's important to remember$w2 that
when you reach 100 experience points,$w2
you always level up.$K$PSo if you have 120 experience points,$w2
you'll level up$w2 and carry over the
extra 20 points.$K  $RTUT��b|$s1$FS$c1ANNA|And that covers the basics
of leveling up.$K$PAs you progress through the game,$w2
you'll get more and more characters
to control.$K$PIf you want to create a strong team,$w2
try to get each character as many
experience points as possible.$K    $RTUT��b|$s1$FS$c1ANNA|Let's talk items now.$K$PTo begin with, $w2I'm going to show you
how to use a vulnerary $w1to regain HP.$K$PFirst, $w2I'll select the character with
the cursor and press #P027.$K  $RTUT��b|$s1$FS$c1ANNA|The movement range will appear,$w2
but for now, $w2I'll just stay where
I am and press #P027 again.$K   $RTUT��b|$s1$FS$c1ANNA|Now you see the command menu.$w4
From the command menu, I'll move
the cursor to Items and press #P027.$K    $RTUT����b|$ND$W2The display shows all of
the weapons $w2and items
the unit is carrying.$K$PNow, $w2I'll use the cursor
to select a vulnerary.$K   $RTUT����b|$ND$W3When I select the
vulnerary with the cursor$w1
and press #P027,$K$Ub$H
$Pa menu showing what
I can do with it will
appear.$K$Ub$H
$PThis time, $w2I'll select
Use and press #P027.$K  $RTUT��b|$s1$FS$c1ANNA|So, that's how vulneraries$w2
can be used to restore HP.$K  $RTUT��b|$s1$FS$c1ANNA|That's it for how to select
and use items.$K$PIn this example, $w2I stayed stationary
and used an item, $w2but the process for
using one after you move is the same.$K$PIf enemies are nearby, $w2it may be a
good idea to move to a safe place
before using such an item.$K    $RTUT��b|$s1$FS$c1ANNA|And now for some
information on skills.$K$PWhat are skills, you ask?$w2
Skills are the various talents
and abilities units possess.$K$PFor example,$w4 if a unit
with no skills assigned to it
is attacked by an enemy,$K   $RTUT��b|$c1ANNA|the unit will face the enemy's attack$w3
and then launch its own counterattack,$w2
in that order.$K   $RTUT��b|$s1$FS$c1ANNA|How do you think this scenario would
be different if the unit possessed
a skill like Vantage?$K $RTUT��b|$s1$FS$c1ANNA|Vantage allows the possessor of the
skill to attack first.$K$PSo, if a unit with Vantage were
attacked in this exact same scenario$MC...$MD$K   $RTUT��b|$s1$FS$c1ANNA|Look!$w3 The allied unit attacked
first, didn't it?$K$PThat's the power of Vantage!$w2
It allowed the allied unit to turn
the tables on its attacker.$K$PSkills do things like this$MC--$MD$w2they
improve abilities$w2 and allow units to
do things they couldn't do otherwise.$K  $RTUT��b|$s1$FS$c1ANNA|That's all I have to share with
you on skills.$K$POf course, $w2there are other
skills that give units different
special abilities as well.$K$PHowever, $w2some skills can be
assigned only to specific units or only
if certain conditions have been met.$K    $RTUT��b|$s1$FS$c1ANNA|Sometimes, you just have to take a
break from the hurly-burly of warfare.
So, let's talk about visits now.$K$PAs you play the game,$w2 you'll
encounter maps with houses
and taverns.$K$PIf the door on a building is open,
you can visit it. But if it's closed,$w3
you can't get in.$K$PYou see how the door on this
house is open?$w4
That means you can visit it.$K
Let's try this.$K$PFirst, $w2move the unit to the
entrance of the building.$K   $RTUT��b|$s1$FS$c1ANNA|Visit appears in the command menu.
Select it to visit the building.$K$PAll right then. $w2Let's move the cursor$w2
over Visit and select it with #P027.$K   $R�w�i��b|$B��-��|$<$F3$P$FCLME|$F1$FS$F1$FCL_GRANDPA|Hm?$w4 What brings you to such an
out-of-the-way place? Would you
like some tea? Or perhaps a biscuit?$K$POh, sorry... You've got a battle to get
back to, don't you? Hm. I'd hate to
see you leave empty-handed...$K$PHere, take this vulnerary with you.$K $RTUT��b|$s1$FS$c1ANNA|Easy, right?$K
Often times, you'll get items,
information, and other goodies when
you take the time to visit.$K$PSo, if you see a house or a tavern,
make sure to pay it a visit.$w4
Something good is waiting for you.$K   $RTUT��b|$c1ANNA|Visiting isn't all just vulneraries,
pleasant chats, and nice cups of tea.$K$PYou may enounter bandits or thieves in
your travels. Unlike other enemies,$w2
they can attack and destroy homes.$K$PSo, don't let your guard down!$K    $RTUT��b|$c1ANNA|If a house or a tavern is destroyed,$w3
you can't visit it.$K$PBut you'll be fine $w2if you visit it
before any ruffians get there.$K$PAfter you enter, the door will close,
and the area will be secured.$K$PRemember, no house or tavern is truly
safe when bandits and thieves are
around--not until you pay a visit!$K    $RTUT��b|$s1$FS$c1ANNA|That's about it for the Visit tutorial.
Happy visiting!$K   $RTUT��b|$s1$FS$c1ANNA|Let's talk about mounted units now.$K$PThe mounted units ride on$w2
horses, $Ub$Hpegasi, $Ub$Hand $Ub$Hwyverns.$K   $RTUT��b|$s1$FS$c1ANNA|Besides having superior mobility,$w2
mounted units can also move
twice in a single turn.$K$PLet me briefly explain this$w2
using the mounted unit on the left.$K    $RTUT��b|$s1$FS$c1ANNA|First, $w2move the allied unit$w2
next to the enemy unit.$K $RTUT��b|$s1$FS$c1ANNA|Let's attack the enemy.$w2$K    $RTUT��b|$c1ANNA|This is where a unit normally stops
moving.$w2
But see the unit's movement range?$w3$K    $RTUT��b|$s1$FS$c1ANNA|That's right!$w2 This unit can use the
rest of his movement, even after
you've given him a command!$K$PThis "second move" is a unique
feature of mounted units.$K
Let's move again and select Wait.$K   $RTUT��b|$s1$FS$c1ANNA|All right. That's enough about moving
your units. Now it's time for ME to
get moving!$K $RTUT��b|$s1$FS$c1ANNA|This ends the mounted-unit tutorial.$K$PUsing your second move, you can bolt
from an enemy after attacking it.$K$PWhat this means $w2is that you can
do a hit-and-run attack.
Very handy, huh?$K    $RTUT��b|$s1$FS$c1ANNA|We've reached one of my favorite
parts of the tutorial: weapons!$K
$Ub$HSwords, $Ub$Haxes, $Ub$Hlances, and $Ub$Hbows.$Ub$H
Ah, the possibilities seem endless,
don't they?$K
Each weapon is either strong$w2 or weak
against another weapon.$K
This relationship is called the
Weapon Triangle. Master it to
gain the edge in any battle!$K$PLet's talk swords and axes first.$w2
$Ub$HSwords $Ub$Hare $Ub$H$w4strong against $Ub$Haxes,$Ub$H
so axes are weak against swords.$Ub$H$K$PNext come axes and lances.$w4
$Ub$HAxes are $Ub$H$w4strong against $Ub$Hlances,$Ub$H
so lances are weak against axes.$Ub$H$K$PLet's consider swords and lances last.$w4
$Ub$HLances are $Ub$Hstrong against $Ub$Hswords,$Ub$H
so swords are weak against lances.$Ub$H$K$P$Ub$HAnd there you have it!$w4
Swords, axes, and lances all fall
into the Weapon Triangle.$K$P$Ub$HYou might have noticed that I didn't
mention bows.$Ub$H$K$PThis is because bows are not affected
by $Ub$Hthe Weapon Triangle.$K$PI know, this is a lot to chew on,$w2
so let's see it in action.$K  $RTUT��b|$s1$FS$c1ANNA|See the allied unit and
$w2the enemy unit here?$K   $RTUT��b|$s1$FS$c1ANNA|The allied unit has an$w3 iron sword.$K $RTUT��b|$s1$FS$c1ANNA|The enemy has$w3 an iron axe.$K$PIn other words, this battle is between
a sword and an axe.$w4
Let's watch.$K   $RTUT����b|$ND$W1Do you see the arrows next to the
weapons that they have?$K
They show the advantage each
weapon has based on its place
in the Weapon Triangle.$K$PBecause swords$w1 are stronger than
$w1axes,$K$Ub$H
$Pthe allied unit with the $w1iron sword
has an up arrow and$K$Ub$H
the enemy with the $w1iron axe
has a down arrow.$K$P$Ub$H
$PThe allied unit would normally deal
10 HP of damage, $w2but in this case,
he does 11 HP instead!$K$P$Ub$H
$PIn contrast, the enemy would
normally do 6 HP of damage,$w3
but he can do only 5 HP here.$K
Let's take a peek at them in battle.$K  $RTUT��b|$s1$FS$c1ANNA|See?$w3 It's just as we expected.$K$P   $RTUT��b|$s1$FS$c1ANNA|That wraps up the Weapon Triangle
tutorial. Swords, $w2axes, $w2lances,
and$w2 bows$MC...$MD$K
Remember where they fall in the
Weapon Triangle, and you'll be
the master of every battle!$K $RTUT��b|$s1$FS$c1ANNA|Everyone likes to be a hero
sometimes, so let me tell you
about rescuing.$K$PRescue lets you carry allied units,$Ub$H
Other units,$Ub$H and Partner units.$Ub$H
Not all at once, of course. Ha ha!$K    $RTUT��b|$s1$FS$c1ANNA|You can rescue by bringing units
right next to each other.$K    $RTUT��b|$s1$FS$c1ANNA|Let's try this now.$w4
First, move an allied unit $w2next to
another unit.$K    $RTUT��b|$s1$FS$c1ANNA|As you can see from the command
menu,$w4 Rescue has appeared.$K$PMove the cursor over it and
press #P027.$w3
Next, select a unit to rescue.$K   $RTUT��b|$s1$FS$c1ANNA|This window tells you the weight
of both units.$K$PA unit can rescue another unit if the
rescued unit's weight is at least 2
less than the rescuing unit's weight.$K$PYou see in this window that$K$Ub$H
the rescuing unit weighs 23$w1$K$Ub$H
and the rescued unit weighs 10.$K
Because the difference in weights is
over 2, the rescue can take place.$K
Let's press #P027$w2 and rescue him!$K   $RTUT��b|$s1$FS$c1ANNA|He's safe now.$K$PThe Trv icon appears on a rescuing
unit. Because a rescuer can travel
with only one rescued at a time,$K$Pyou can't rescue other units when
you have this icon.$K$PKeep in mind also that when traveling
with a rescued unit, the rescuer's
speed and skill are reduced by half.$K$PHowever, the rescued unit will sustain
no damage from enemy attacks.$K$PWhen the HP of the rescuing unit
reaches zero,$w2 the rescued unit
will be dropped off nearby.$K$PAnother thing to keep in mind is
that mounted units can rescue others,$w2
but they can't be rescued themselves.$K$PNext, $w2let me show you how to
drop off the rescued unit.$K $RTUT��b|$s1$FS$c1ANNA|First, select the rescuing unit$w2
to display the command menu.$K$PWe're not moving it now, $w2but
you can do this after moving, too.$K $RTUT��b|$s1$FS$c1ANNA|To drop off a rescued unit, move the
cursor over the unit and press #P027.
A command menu will appear.$K$PSelect Drop on the command menu.
Adjacent spaces will turn orange.$K$PYou can drop a rescued unit onto
any orange space, but not spaces
occupied by other units$K
or on terrain where you can't move.$K$PChoose where to drop the rescued
unit off and press #P027.$K $RTUT��b|$s1$FS$c1ANNA|Keep in mind that a rescued unit
must stay where you've dropped it off
for that turn, so be careful.$K  $RTUT��b|$s1$FS$c1ANNA|That's it for the rescue tutorial.$K    $RTUT��b|$s1$FS$c1ANNA|One of best parts of working
in a team is sharing stuff, so you'll
need to know how to trade items.$K$PTwo allied units can trade items
when they are in adjacent spaces.$K$PTo give you an idea of how this
works, let's look at a trade in action.$K$PFirst, move a unit next to the unit
you want to trade with and press #P027.$K   $RTUT��b|$s1$FS$c1ANNA|Now take a look at the command
menu that has appeared.$K$PSee the Trade command?$w4
Move the cursor over it and
press #P027.$K  $RTUT��b|$s1$FS$c1ANNA|Next, $w2pick the unit to trade
items with.$K$PThere are two adjacent units here.$w4
Let's exchange with the one on
the right.$K$PMove the cursor over the right unit
$w2and press #P027.$w2
Now watch what happens.$K  $RTUT��b|$s1$FS$c1ANNA|Both units' items appear.$K$Ub$H
$PLet's give the left unit's vulnerary to
the unit on the right.$K$PMove the cursor over to the vulnerary
and press #P027.$K   $RTUT��b|$s3$FS$c3ANNA|See how the cursor is hovering
over a blank space in the right
unit's item list?$K$PPress #P027 here and you'll move
the vulnerary from the unit on the
left to the unit on the right.$K$PHere, I'll show you.$K    $RTUT��b|$s3$FS$c3ANNA|You have now traded items.$K$P$s3$FAWhat's that you say?$w4 That
was just giving an item as
opposed to a real trade?$K$P$s3$FSRelax.$w4 You can swap items by
moving the cursor that you placed
over the blank space to an item.$K$PVoila! The items are swapped.$K$PYou can trade both weapons
and items.$K$P  $RTUT��b|$s1$FS$c1ANNA|What's more, you can keep moving
$w2even after trading items.$K $RTUT��b|$s1$FS$c1ANNA|That's it for the Trade tutorial.$K
Oh yes. One more thing. Keep
in mind that you can only carry
four weapons and items at a time.$K    $RTUT��b|$s1$FS$c1ANNA|Besides dropping off a unit that
you've rescued,$w2 you can give
it to another unit.$K$PYou can also take someone else's
rescued unit.$K$PI find it's always easier to learn from
a visual example, so here goes.$K $RTUT��b|$s1$FS$c1ANNA|Oh, no!$w4 The unit is surrounded
by enemies.$K$PWhat's more, he's rescued another
unit, so his speed and skill are lower
and he can't fight as well.$K$PHe should drop off the rescued unit,
but he's surrounded by enemies,
so that's not an option.$K$PThe Give command comes in handy
in a time like this.$w4 Let's get him
out of this jam.$K  $RTUT��b|$s1$FS$c1ANNA|You see Give in the command menu?$K$PThis command lets you pass a rescued
unit to another unit.$K$PBut remember, just like when you
originally rescued the unit,$K
the rescued unit must weigh at least
2 under the weight of the ally
taking the unit.$K$PAnd if the unit taking the rescued unit
already has a rescued unit, $w2you can't
give either.$K$PLet's "give" it a try. Hee hee!$w3
Select Give from the command menu
and press #P027.$K $RTUT����b|$ND$W2The weight of the
rescued unit is 10,$K$Ub$H
$Pand the taking unit
weighs 23.$w1$K$PThe taking unit weighs
more than 2 over the
rescued unit.$K
Therefore, it can take
the rescued unit.$K$PLet's press #P027 now.$K$P    $RTUT��b|$s1$FS$c1ANNA|Even after you give a
rescued unit,$w4 you can
keep moving.$K$Ub$H
$PLet a rescued unit escape to safety$w2
by moving the allied unit that took it.$K$PThe status of the giving unit goes
back up$w3 after the transaction,
so it will fight better than before.$K  $RTUT��b|$s1$FS$c1ANNA|That's it for the Give tutorial.$w4
Make good use of Give to elude
danger.$K$PNext on the agenda is how to
take a rescued unit.$K$P $RTUT��b|$s1$FS$c1ANNA|Just like before, there's a unit
with a rescued unit, and they're
surrounded by enemies.$K$PHis skills and speed are down,$w3
so he can't fight well.$K$PThe rescued unit will come
under attack if dropped off$MC...$MD$w3$K$PIt's a very dangerous situation.$K$PBut there's an allied unit on
the opposite bank across the river.$K$Ub$H
$PLet's have that allied unit take the
rescued unit$w3 and get out of
this jam.$K$PMove the unit alongside the troubled
pair$w2 to accept the rescued unit.$K   $RTUT��b|$s1$FS$c1ANNA|You should see the Take command.$K$PYou use the Give command to give
a unit to someone else, and you use
the Take command to take that unit.$K$PObviously, you can't do so unless
the taking unit weighs at least 2
more than the rescued unit.$K$PAnd the unit can't take the rescued
unit if it is already carrying one.$w3
This is the same as before.$K$PLet's take the rescued unit.$w4
Select Take from the command menu
and press #P027.$K   $RTUT����b|$ND$W2The rescued unit
weighs 10$K$Ub$H
$Pand the taking unit
weighs 23,$K$Pover 2 more than the
rescued unit.$K    $RTUT��b|$s1$FS$c1ANNA|You can keep moving even after
taking.$K$PMounted units can cancel moves with
#P028 or perform a second move.$K$PLet's cross over to the other side of
the river.$K $RTUT��b|$s1$FS$c1ANNA|Good. We're out of the woods.$K$PThat's how you pass a rescued unit
and move it to safety.$K    $RTUT��b|$s1$FS$c1ANNA|And that's that! Both commands
can help you out of sticky situations,
so use them well!$K   $RTUT��b|$s1$FS$c1ANNA|Achoo!$w4
Oh. You said "seize," not sneeze.
My mistake.$K$PIn certain battles, you'll have to have
Ike capture--or seize--key map points
in order to clear the map.$K   $RTUT��b|$s1$FS$c1ANNA|Generally, though, an enemy leader
(also called a boss) will be guarding
the seize point.$K$PSo, you need to defeat the boss$w2
before seizing that location.$K$PEven though Ike is the only one
able to use the Seize command,$K
you can defeat the boss with
other characters, too.$K$PLet's try this out.$K  $RTUT��b|$s1$FS$c1ANNA|The boss is defeated!$w4
I'll move Ike to the seize point next.$K   $RTUT��b|$s1$FS$c1ANNA|Seize appears in the command menu.$K$PWhen you select this and press #P027,
you'll be asked if you really want
to seize.$K$PSelect Yes to seize the point$w3
and clear the battle map.$K    $RTUT��b|$s1$FS$c1ANNA|That's how it goes.$w4
Now that you have cleared this map,$w3
let's move on to the next map.$K$Ub$H
$PYour battle objective appears
under the terrain-information
window in the map's upper left.$K$PWhen you advance to a new map,$w2
check it to see what you need
to do to clear the map.$K  $RTUT��b|$s1$FS$c1ANNA|And that wraps up the Seize tutorial!$K $RTUT��b|$s1$FS$c1ANNA|I'll explain the rout victory condition.$K$PA rout means that$w2 you defeat
every enemy on the map.$K$PYou could always count the enemies$MC...$MD$w3
but that's kinda boring. It's easier to
press START and$w2 view the map.$K$PLet's check it out.$K $RTUT����b|$ND$W1Look at the left window.$K$PDo you see how the number of
ally and enemy units is displayed?$K $RTUT��b|$s1$FS$c1ANNA|You have three ally units,$w2$K$Ub$H
and there are four enemy units.$K$PIf you reduce the enemy units to zero,$w3
you'll meet the rout conditon.$K$P$s1$FABut$MC...$MD$K    $RTUT��b|$c1ANNA|Look!$w4 More enemies showed up!$K$P$s1$FSOn some maps,$w2 the enemy
may send in reinforcements like this.$K$PLet's look at the map again and check
how many enemy units there are now.$K $RTUT��b|$s1$FS$c1ANNA|We had four enemies earlier, but the$w3
reinforcements brought in two more.$Ub$H
Now there are six enemies!$w4 Boo!$K$PReinforcements aren't a problem if you
eliminate the original enemies
before they arrive,$K$Pbut if they do show up,$w3
you can't clear the map until
you defeat them, too.$K$PWhat's more,$w2 reinforcements may
arrive more than once.$K$PBe careful.$K    $RTUT��b|$s1$FS$c1ANNA|Well, that takes care of winning
by a rout. Fun stuff, no?$K    $RTUT��b|$s1$FS$c1ANNA|Let's talk about staves.$K$PThere are many kinds of staves.$w3 Some
restore HP, some heal abnormal
states, and some$w3 do other things.$K$PThe range of a staff depends on
which one you use.$w4
In most cases$MC...$MD$K   $RTUT��b|$s1$FS$c1ANNA|you can use one only if you
move next to a unit. $w2But$MC...$MD$K  $RTUT��b|$s1$FS$c1ANNA|there are some staves that heal allies
from a distance like this. $w2And$MC...$MD$K $RTUT��b|$s1$FS$c1ANNA|there are also staves that you can
use against a far-off enemy.$K   $RTUT��b|$s1$FS$c1ANNA|Let me show you how a staff$w2
is actually used.$K$PThis is a Heal staff.$w4
It's a common staff that restores HP.$K$PFirst, move next to an ally$w2 and
choose Staff from the unit menu.$K$PNext, grab a staff$w2 and pick a unit
to use it on.$w4 It's just like
attacking with a weapon.$K   $RTUT��b|$s1$FS$c1ANNA|See? His HP has been restored.$w3
Aren't you nice!$K$PAs you can see,$w2 your Exp
goes up after using a staff.$K$PThe amount of Exp earned will
depend on which staff you use.$K$PAnd while you have a 100% chance of
success with healing staves,$w3
attack staves will sometimes fail.$K$PIf that happens, you'll earn less
Exp than normal.$K    $RTUT��b|$s1$FS$c1ANNA|That's all for the staves tutorial.$w2
Neat, huh?$K $RTUT��b|$s1$FS$c1ANNA|Hey, it's you again!
Let's talk about terrain.$K$PPlains,$w2 cliffs,$w2 rivers,$w2 seas$MC...$MD$w4
They're all different kinds of terrain.$K$PAnytime a nonflying unit fights,$w2
it will be affected by the terrain
in some way.$K$PThat's called the terrain effect.$K$Ub$H
$PLet me show you what I mean.$w4
I'll move the cursor first,$w2
so watch the upper left-hand window.$K  $RTUT��b|$s1$FS$c1ANNA|Did you see the info change$w2
when I moved the cursor?$K$PThe window is called a terrain window,$w2
and it shows terrain info for the
square where the cursor is.$K$PInformation such as terrain names$w1
and terrain effects$w3 are displayed
in this window.$K$PThe name is just the terrain's name,
but the green letters represent stats
that can affect you during a battle.$K$PI know,$w3 it's crazy. Hold on a sec and
I'll explain the terrain effects that
appear in the window.$K$Ub$H
$PAvo (Avoid) shows how terrain
affects incoming attacks.$K$PThe higher this number is, the easier
it is to dodge enemy attacks.$K$PConversely, $w2if an enemy is positioned
at a higher-numbered spot, your attack
is more likely to miss.$K $RTUT��b|$s1$FS$c1ANNA|Def (Defense)$w4 shows how the
terrain affects your defense.$K$PThe higher the number, the less
damage you suffer from
enemy weapon attacks.$K$PIt works the same way for enemies,
too,$w3 so watch out.$K  $RTUT��b|$s1$FS$c1ANNA|MDf (Magic Defense)$w4 shows how
terrain affects magic defense.$K$PThe higher the number, the less
damage you suffer from
enemy magic attacks.$K$PConversely$MC...$MD$w3well, you already
know how that works, don't you?$w4
You're such a smarty!$K$Ub$H
$PIn this example,$w3 we'll attack
the enemy on the right.$K$PWhile you can move to the left-hand
side of the enemy$MC...$MD$K    $RTUT��b|$s1$FS$c1ANNA|there would be no positive
terrain effect.$K$PI wonder if there's a better place
to launch an attack$MC...? $MDNow if I$w4
move the cursor below the enemy$MC...$MD$K   $RTUT��b|$s1$FS$c1ANNA|Look at the terrain info window!$w4
The Avo and Def numbers went up.$K$PYou will avoid more attacks and$w2
suffer less damage$w1 in a thicket
than$w1 on an open plain.$K   $RTUT��b|$s1$FS$c1ANNA|This wraps up the terrain
tutorial. Fun stuff, no?$K$PIf you keep terrain effects in mind
while on the move, you'll kick tail
in any battle.$K  $RTUT��b|$s1$FS$c1ANNA|Hey, you$MC...$MD$w3welcome back!
Let's cover enemy movement range.$K$PIt's just like checking on an ally.$w3
If you put the cursor on an enemy,$w3
you'll see his move and attack ranges.$K    $RTUT��b|$s1$FS$c1ANNA|Press #P027$w3 while the cursor
is still over the enemy$MC...$MD$K  $RTUT��b|$s1$FS$c1ANNA|The enemy's attack range appears
as a bunch of orange squares.$K$PAn attack-range icon also appears
on top of the enemy whose range
is being displayed.$K$PMovement $w2and attack ranges usually
vanish when you move the cursor, but$w2
you can keep them active if you want.$K    $RTUT��b|$s1$FS$c1ANNA|See, if you move the cursor to
another enemy$w3 and
press #P027 like so$MC...$MD$K  $RTUT��b|$s1$FS$c1ANNA|The two attack ranges
are now overlapped.$K$PAnd if you do the same thing
to the enemy below$MC...$MD$K $RTUT��b|$s1$FS$c1ANNA|His range is also overlapped.$w4
Piling attack ranges on top of one
another can be super handy!$K$PBut as you see,$w2 the ally unit
is in a bad position, and about to
suffer a direct enemy attack.$K$PThat's no good! Use your new info
and move him to an area where the
enemies can't touch him.$K  $RTUT��b|$s1$FS$c1ANNA|Well, that's the gist of it.$K$POh, and you can use #P028$w2
anytime you want to hide an
enemy's attack range.$K$PIf you move the cursor over the
enemy and press #P028 once$MC...$MD$K $RTUT��b|$s1$FS$c1ANNA|See?$w3 It disappeared.$K$PAnd if you move the cursor to an
empty square$w3 and hit #P028 once$MC...$MD$K   $RTUT��b|$s1$FS$c1ANNA|You can hide all of the
visible attack ranges.$K    $RTUT��b|$s1$FS$c1ANNA|That's the end of the enemy-
movement and attack-range tutorial.$K$PMoving allies out of harm's way is
fun! And important, too$MC...$MD$w4
Arm yourself with knowledge!$K   $RTUT��b|$s1$FS$c1ANNA|Now it's time to learn some advanced
direct-combat attack strategies.$K$PWhen you move next to an enemy,$w2
select Attack from the command
menu and choose a weapon$MC...$MD$K  $RTUT����b|$ND$W1The combat window will appear
just like this.$K$PThe first direct-combat tutorial
covers how to attack, $w2so take
a look if you$w3$MC...$MDer$w4$MC...$MDforgot.$K$Ub$H
$PThis time, $w2I'll briefly
describe$w2 the four stats
shown in this window.$K  $RTUT����b|$ND$W1First up is HP,$w3 or the hit points
a unit has.$K$PIf this number falls to zero,$w2 then
that unit can no longer fight in
battles.$w4 Ever!$w4 I'm totally serious!$K$PAlways keep your allies' HP above
zero, $w2and fight to take your
enemy's HP down to zero.$K  $RTUT����b|$ND$W1Next up is Mt, or might. This
number reflects the damage
you inflict on an enemy.$K$PBefore you attack, subtract this
number from an enemy's HP to
learn how much HP he'll have left.$K$PHere, your Mt is 4 and the$w2
enemy's HP is 19, so he'll have
15 HP left after you strike.$K$PConversely, if the enemy attacks,
you'll also have 15 HP left.
It's just 19 minus 4$MC...$MD$w3see?$K  $RTUT����b|$ND$W1Next up is Hit,$w3 or the
percentage chance of landing
a successful attack.$K$PThe larger this number,$w2
the more likely your
attack will hit home.$K$PHere, the enemy will strike you
with a 98% chance of a
successful attack.$K$PLooking at the Hit rating,$w2
you're probably going to get
spanked. Too bad!$K   $RTUT����b|$ND$W1Last but not least is Crit,$w3
or the odds of landing a
critical blow.$K$PIf you deliver a critical strike,
your Mt rating is tripled!
Hot stuff!$K$PSo, if you have an Mt of 4 and
Crit is invoked, you'll inflict
12 HP of damage.$K    $RTUT��b|$s1$FS$c1ANNA|So that's a brief description of each
item appearing in the combat window.$K$PThe information changes$w2
depending on the enemies
that you face.$K$PNow cancel out with #P028 $w2and
check out the info of the
right-hand enemy$MC...$MD$K  $RTUT����b|$ND$W1Compared to the last enemy,
this guy's a big wimp$MC...$MD$w4 Wow, it
sure is helpful to compare units!$K $RTUT��b|$s1$FS$c1ANNA|This wraps up the advanced
direct-combat tutorial.$K$PRemember to use the combat window
and compare multiple enemies$w2 so
you can kick bootie in battle.$K $RTUT��b|$s1$FS$c1ANNA|Let's talk about the preparation
screen now.$K$PIn this screen, you can make various
troop adjustments before you fight.$K$PLet me go over each one briefly.$K$Ub$H
$PChoose Units$w4 lets you choose
which units you want to deploy
on the battlefield.$K  $RTUT��b|$s1$FS$c1ANNA|The numbers here show how many
units you can deploy on each map.$K$PThe number on the right is the
maximum amount,$w3 while the left shows
how many units are already deployed.$K$POh, and you don't have to deploy the
maximum amount if you don't want.$K $RTUT��b|$s1$FS$c1ANNA|Reposition$w4 lets you switch the
starting points for all your units.$K $RTUT��b|$s1$FS$c1ANNA|First, move the cursor to the first
unit and press #P027.$K$PThen move the cursor to the second
unit and press #P027 again.$K$Ub$H
$PSee how they switched positions?$w4
You can do this with any unit you
want.$K$PYou can also move a unit to any
empty blue square.$K    $RTUT��b|$s1$FS$c1ANNA|View Map$w4 lets you look at the map
you're about to fight on.$K    $RTUT��b|$s1$FS$c1ANNA|You can check out terrain $w2and
enemy positions on the map like so.$K$PIt's pretty handy if you're trying
to plan the perfect attack.$K    $RTUT��b|$s1$FS$c1ANNA|Choose Items$w4 to exchange
weapons and items among
party members.$K    $RTUT��b|$s1$FS$c1ANNA|When you pick a unit, you'll also see
the options Equip and Discard. You
can use those in addition to trading.$K$PAlso, you can trade with any unit$MC--$MD
even if it isn't deployed at the time.$K    $RTUT��b|$s1$FS$c1ANNA|Conditions$w4 lets you see the map.
You'll also see stats like the number
of foes and success conditions.$K $RTUT��b|$s1$FS$c1ANNA|You can view the same map by
pressing START during a battle.
Don't forget, now!$K   $RTUT��b|$s1$FS$c1ANNA|Options lets you change a variety
of gameplay settings. You may have
fiddled with this already.$K   $RTUT��b|$s1$FS$c1ANNA|Here you can change settings such as
message speed $w2and camera angles.$K$PDuring a battle, you can also view
this screen from the map menu.$K $RTUT��b|$s1$FS$c1ANNA|Save$w4 lets you save game data$MC...$MD$w4
I'll bet you couldn't have figured
THAT out on your own!$K  $RTUT��b|$s1$FS$c1ANNA|You can either write over existing
game data$w3 or save to a new file.$K    $RTUT��b|$s0$FS$c0ANNA|Once you're ready to go, select
Fight$w4 and go to the battle map.
Then it's time to fight$MC...$MDright?$K$PWrong! Even if you press #P027,$w4
the battle won't begin immediately.$K   $RTUT��b|$s0$FS$c0ANNA|First, you will be asked if you
want to start the battle.$K$PSelect Yes if you are ready$w3 or
No if you forgot something.$K$PYou can't return to the preparation
screen $w2once the battle begins, so take
the time to make sure you're ready!$K   $RTUT��b|$s1$FS$c1ANNA|Well, that wraps up the preparation
tutorial! That wasn't so hard,
now was it?$K    $RTUT��b|$s1$FS$c1ANNA|Let me tell you about bonus
damage.$w6 It's crazy!
You're going to love it!$K$PThis effect allows you to cause
more damage than normal when
you meet certain conditions.$K$PAn archer attacking an airborne
unit,$w2 such as a pegasus
knight,$w2 is one example.$K $RTUT����b|$ND$W1You're looking at the status
screen of an ally unit.$K$PCheck out the menu item in the
lower left.$w4 It says$w2
Flying $w2next to Effect.$K$PThis indicates which units will
receive bonus damage from
your current weapon.$K$PSince the peg knight is airborne,
$w2she'll suffer bonus damage$w2
if struck by the arrow.$K  $RTUT����b|$ND$W1Now look at the archer's
weapon icon. $w2See how it's
blinking?$K$PThis means his target will
suffer bonus damage.$K$PThis window is an easy way to
see if you'll inflict bonus damage
or not.$K$PWant to see this in action?
Of course you do, silly!$w4
Let's go!$K $RTUT��b|$s1$FS$c1ANNA|Wow! Did you see that?$w4
Nasty!$K$PThat arrow caused bonus damage,
and now the airborne unit is reeling!$K$PThere are other weapons that
trigger bonus damage, too,
but only against specific units.$K$PLongswords$w2 work well against units
on horseback, $w2and Armorslayers
help you mow down knights.$K$PAnyway, when you get a new weapon,$w2
or if the enemy has one, be sure to
check it out!$K    $RTUT��b|$s1$FS$c1ANNA|Oh, wait, hold on! I have to tell you
about the laguz!$w4 When they're
in human form$MC...$MD$K $RTUT����b|$ND$W1no special bonus damage applies
to them. You'll just see the normal
combat information.$K $RTUT��b|$s1$FS$c1ANNA|But once they change into
their animal form$MC...$MD$K  $RTUT����b|$ND$W1bonus effects apply again.$w4
That's $w2because the unit's
characteristics have changed.$K$P  $RTUT��b|$s1$FS$c1ANNA|That's it for the bonus damage
tutorial. You made it through without
falling asleep! Yay for you!$K$PRemember, bonus damage occurs
only under specific conditions,$w3
so heed the unit-weapon relationship.$K   $RTUT��b|$s1$FS$c1ANNA|Let's talk about long-range and
indirect-attack strategies.$K$PFirst,$w3 let's check out some
indirect-attack strategies.$K$PAn indirect attack means attacking
an enemy who is one square away.$K$PIt's often done with a $w2javelin or
a hand axe$MC...$MD$K$Palthough you can do it with a$w2
bow or magic spell, too.
Let's try it out!$w4$K$PFirst, I'll move the ally one square
away from the enemy.$K   $RTUT��b|$s1$FS$c1ANNA|Next, I'll pick Attack from the unit
menu and press #P027. Boom! Simple!$K$POther than being able to attack from
a distance, $w2it's just like
using a direct attack.$K $RTUT����b|$ND$W1But don't get cocky! If the
enemy's weapon can also
deliver an indirect attack$MC...$MD$K $RTUT��b|$s1$FA$c1ANNA|you'll be counterattacked
just like this!$K$P$s1$FSSome weapons can deliver both
direct and indirect attacks, $w2so check
your enemy before rushing into battle.$K  $RTUT��b|$s1$FS$c1ANNA|Let's talk about long-range
attack strategy next.$K$PA long-range attack is one that
strikes an enemy from
two squares away.$K$POnly some bows and spells can do
this, and$w3 counterattacks are
really rare.$K$POh, and another thing$MC...$MD$K$Ub$H
This weapon is called a ballista.
It's huge$MC...$MDand powerful, too!$K$PIf you hop in, $w2you can use
its massive bow to$w2 hit enemies
that are really far away.$K    $RTUT��b|$s1$FS$c1ANNA|But only certain units, such as archers
and snipers, can use a ballista.$K$PEnemies can use it, too,
$w3so don't go all nuts and
let them walk right up to it.$K    $RTUT��b|$s1$FS$c1ANNA|Ahem$MC... $MDThus concludes the indirect-
and long-range attacks tutorial.$K$PDon't forget this, now! It's nice
to fight people without being
counterattacked all the time.$K  $RTUT��b|$s1$FS$c1ANNA|Let's go over how to win by
defeating an enemy leader.$K$PAlmost every enemy army has
a leader$MC...$MD$w4or a boss,
as he's often known.$K$Ub$H
$PSlaying the boss will end a battle
when the defeat leader condition
is active. Pretty basic, no?$K$PNot sure which fellow is the boss?$w4
Press START to open up the
map $w2and find out.$K  $RTUT��b|$s1$FS$c1ANNA|See the overhead map
on the right?$K$PThe blue dots are allies,$w2
and the red dots are enemies.$K$PAnd that big, glowing dot
at the top is the boss.$K$PIf you press #P027 here,
the victory and defeat conditions
will appear.$K  $RTUT��b|$s1$FS$c1ANNA|You'll clear this map by defeating the
enemy leader.$w4 Without the boss,
the rest of those losers are helpless.$K$Ub$H
$PIf there are houses or whatnot that
you haven't visited,$w3 do that first.$w2
When the boss goes, they go, too.$K $RTUT��b|$s1$FS$c1ANNA|That's it for the tutorial on
mowing down enemy leaders.$K$PSometimes a boss is easier to defeat
than you think, and the battle will
end quickly.$K$PBe sure to take care of
unfinished business before
you slice him to ribbons.$K $RTUT��b|$s1$FS$c1ANNA|Let's go over the conditions screen.$K$PPress START during a battle
to bring up this screen.$K$PFrom there, you can see$w3 how many
allies or enemies there are,$w3 victory
and defeat conditions,$w3 and the map.$K$PLet's press START $w2and
see it in action!$K  $RTUT��b|$s1$FS$c1ANNA|Voila! The conditions screen.$K$PLet me briefly go over
what shows up here.$K$Ub$H
$PThe very top window displays
$w2the current chapter$w2
and its title.$K$Ub$H
$PThis window shows $w2how many turns
you've taken $w2and how much money
you currently have.$K    $RTUT��b|$s1$FS$c1ANNA|The big window in the center shows a
small version of the current map.$K$PBlue dots are allies, $w2yellow dots are
Partners,$w2 green dots are Others,
and red dots are enemies.$K$PBlinking, circled dots
represent $w2a leader.$K $RTUT����b|$ND$W1This window shows how many units
each army has.$K$PYou can also see how many units
an army has on the map.$K$PLook what happens
when I press #P027$MC...$MD$K $RTUT��b|$s1$FS$c1ANNA|More info! This shows what it takes
to clear a map $w2and what an army's
leader$w2 is like.$w4 Want details?$K$Ub$H
$PThe window near the center shows
how to win or lose$MC...$MD$w6
Er$MC...$MD$w6try not to lose.$K$PSome maps may have multiple
victory conditions, so watch out.$K $RTUT��b|$s0$FS$c0ANNA|The leader unit window
appears at the very bottom
of the screen.$K$PThe leader of each army appears here.$K$PAnd if I move the cursor over
one of these enemies$MC...$MD$K  $RTUT��b|$s0$FS$c0ANNA|The boss appears!$K$PSometimes you can view the leader of
$w2Other $w2and Partner groups,$K$Pbut not always.$K$P    $RTUT��b|$s1$FS$c1ANNA|Um$MC... $MDSo, I guess that's it for the
conditions-screen tutorial.$K$PThe conditions screen is chock full
of valuable information,$w2
so take advantage of it.$K $RTUT��b|$s1$FS$c1ANNA|Let's talk about the
Trinity of Magic$MC...$MD
Oh, come on. It'll be fun!$K$P$Ub$HThe Trinity of Magic works
in a similar way$w2
to the Weapon Triangle.$K$PRemember the triangle?$w4
Swords beat axes and all that?$w4
Of course you do!$K$P$Ub$HThere are four kinds of magic:$w4 fire,$Ub$H
$w4wind, $Ub$H$w4thunder, $Ub$H$w4and light.$Ub$H$K$PI know that doesn't sound like a
trinity, but just you wait!$K$PFirst, we'll talk about$w3 fire and$w3 wind.$w3
$Ub$HFire$Ub$H is strong $Ub$Hagainst $Ub$Hwind,$Ub$H$w4
and wind is weak against fire.$Ub$H$w4$K$PNext is$w3 wind and$w3 thunder.$w3
$Ub$HWind is strong $Ub$Hagainst $Ub$Hthunder,$Ub$H$w4
and thunder is weak against wind.$Ub$H$K$PFinally, we have thunder and fire.$w4
$Ub$HThunder is strong $Ub$Hagainst $Ub$Hfire,$Ub$H$w4
and fire is weak against thunder.$Ub$H$K$P$Ub$HThis is the Trinity of Magic,$w4
where fire, wind, and thunder spells
fight it out for dominance!$K$P$Ub$HThere's one more thing: $w2the trinity of
magic has no impact on$w4 $Ub$Hlight magic.$Ub$H
That's just the way it is.$K$PBut enough of the talking! It's
time we saw the Trinity of Magic
in action!$K $RTUT��b|$s1$FS$c1ANNA|There are two mages here:$w3
an ally and an enemy.$K    $RTUT��b|$s1$FS$c1ANNA|The allied mage is equipped
with Fire.$K    $RTUT��b|$s1$FS$c1ANNA|And $w2the enemy mage is equipped
with Wind.$K$PLook what happens when they
meet in battle$MC...$MD$K   $RTUT����b|$ND$W1Check out the magic each mage
has equipped.$w4
See the arrows?$K$PThey show their respective attack
advantages and disadvantages
based on the Trinity of Magic.$K$PSince fire magic is strong
against wind magic$MC...$MD$K$Ub$H
$PIt has a green arrow pointing up.$K$P$Ub$H
$PAnd the wind magic has a red
arrow pointing down.$K$Ub$H
$PNormally,$w3 Fire would cause
8 points of damage, but in
this case, it does 9.$K$Ub$H
$PAnd when the mage uses Wind,$w2
he'll do only 6 points of
damage instead of 7.$K$PNow,$w4 watch them fight!$K  $RTUT��b|$s1$FS$c1ANNA|See?$w4 The battle happened just
the way I said it would!$w4
I'm pretty smart, don't you think?$K$P $RTUT��b|$s1$FS$c1ANNA|And thus concludes my
Trinity of Magic tutorial.$K$PPay attention to it, because it could
give you the edge in any battle!$K    $RTUT��b|$s1$FS$c1ANNA|Let me talk about the
help display now.$K$PWhen you see an unfamiliar word,
$w3pressing #P02A will open up a
simple description.$K$PThis is called the help display
or help window.$K$PLet's try it!$w4
Move the cursor over a unit and press
#P02A to open the status screen.$K    $RTUT��b|$s1$FS$c1ANNA|Sure, the information on this status
screen is awfully helpful, but it
doesn't end there!$K$PWith just the touch of a button,
we can see some even more
detailed information!$K$PPress #P02A, and see what comes up$MC...$MD$K  $RTUT��b|$s1$FS$c1ANNA|My goodness! Look at that! The help
window opens like so,$w3 giving
you even more detail!$K$PIf you move the cursor now,$w3
you can get help on just about
anything on the screen.$K    $RTUT��b|$s1$FS$c1ANNA|Press #P028 or #P02A again
to close the display.$K$PThere are lots of help displays!
In fact, you can find such
useful details as$MC...$MD$K    $RTUT��b|$s1$FS$c1ANNA|unit screens$MC...$MD$K $RTUT��b|$s1$FS$c1ANNA|battle-information windows$MC...$MD$K   $RTUT��b|$s1$FS$c1ANNA|and the map menu! Most will
give you brief descriptions
before you even open them.$K    $RTUT��b|$s1$FS$c1ANNA|So if you find yourself in trouble$w3
or have any other questions, always$w2
press #P02A first! Don't forget!$K $RTUT��b|$s1$FS$c1ANNA|Maybe a song will help you remember!
Oh, the help display is so$MC...$MD$w4um$MC...$MD$w7
Never mind. Go back to the game.$K    $RTUT��b|$s1$FS$c1ANNA|Let's chat for a bit about
the status screen.$K$PWhen I move the cursor over
a unit on a battle map and
press #P02A like so$MC...$MD$K  $RTUT��b|$s1$FS$c1ANNA|I can bring up a screen that gives me
detailed information about a unit.$w4
This is called the status screen.$K$Ub$H
$PThe status screen has three pages.$w3
Move #P02C left and right
to scroll through them.$K    $RTUT��b|$s1$FS$c1ANNA|Lots of stuff, huh? Don't panic.
Lemme tell you about the items
you'll see on the status screen.$K$PFirst up is the yellow window that
you see at the very top.
This appears on all the pages.$K$Ub$H
$PThe name of the unit is
in the top-left corner.$K$Ub$H
$PAnd this is how he or she looks
on the battle map.$K$Ub$H
$PNext to the picture, you'll see
the unit's class, current level,
experience points, and hit points.$K$PThe light green arrow in the
background relates to biorhythm$MC...$MD
$w4We'll talk about that later.$K$Ub$H
$PThe unit's face appears in the middle.
Oooo$MC...$MD$w4aren't you a handsome devil!
I bet the ladies love you!$K$Ub$H
$POh, so here you see how far a unit
can move and how much it weighs.$K$PIf a unit is carrying someone he
rescued, that info appears as well.$K$PAnd if the unit has status problems,
like being poisoned or whatnot,
an icon will appear here.$K$Ub$H
$PAs you can see, the top
window is mostly basic
information.$K$PLet's learn a little about the
windows in the other pages,
shall we?$K $RTUT����b|$ND$W0This page$MC--$MDwhich is always
the first one you'll see$MC--$MDhas
three main windows.$K$Ub$H
$PThis blue window labeled Personal
Data shows the unit's statistics,
like strength and speed.$K$Ub$H
$PThis window shows battle stats.
Most of this information relates to
your currently equipped weapon.$K$Ub$H
$PAnd the item window here
shows what this unit is carrying.$K $RTUT��b|$s1$FS$c1ANNA|So, the first page is mostly about
statistics and items. Good so far?$K$PGreat! On to the next page$MC...$MD$K  $RTUT����b|$ND$W0This page has four
main windows.$K$Ub$H
$PBuild shows the unit's body size.
This helps determine a unit's
weight, among other things.$K$Ub$H
$PThe window labeled Type shows
the unit's race.$w4 This affects
bonuses, not to mention skills.$K$Ub$H
$PThis window shows what weapons
a unit can use, and their
current skill level with each.$K$PIf the unit is a laguz, the
transformation gauge
appears here instead.$K$Ub$H
$PThis window shows the unit's
current skills and capacity
to learn new ones.$K   $RTUT��b|$s1$FS$c1ANNA|So the second page is all
skills $w2and attributes.
Still with me?$K$PGreat! Let's check out the
third and final page.$K    $RTUT����b|$ND$W0The third page has five main
windows.$K$Ub$H
$PThe unit's attribute is in this
window. It determines a unit's
affinity with other fighters.$K$Ub$H
$PThis window shows a unit's
biorhythm. When it's high, the unit
fights better. But when it's low$MC...$MD$K$Ub$H
$PThis window shows any orders or
instructions that the unit
has received from Ike.$K$Ub$H
$PIf you have any support bonuses,
their effects will be shown in this
yellow window here.$K$Ub$H
$PAnd this window shows which
characters, if any, will give a
support bonus to the unit.$K  $RTUT��b|$s1$FS$c1ANNA|So the third page is all about
your rapport with other units
and your own biorhythm.$K$PIf you want even more info,
press #P02A to bring up
the help display.$K $RTUT��b|$s1$FS$c1ANNA|That's all there is to the status-
screen tutorial! It couldn't be
easier!$K    $RTUT��b|$s1$FS$c1ANNA|Back for more, are you?
Well, let's go over how
to drop items.$K$PA unit can carry a maximum
of four weapons and four items.
No more than that, you hear?$K$PBut what if your pack is full and
you want to grab something else?$K$PIf you have access to the merchant
convoy, you can always send
your extra items there.$K$PHowever, if your convoy isn't around,
well, you'll have to drop something
to free up a little room.$K$PLet me show you how to
do that now.$K   $RTUT��b|$s1$FS$c1ANNA|First, when the unit menu appears,
$w2select Items.$K   $RTUT����b|$ND$W2See those weapons and
items that he's carrying?$K$PLet's try dropping$MC...$MD
oh$MC...$MD$w4the hand axe.
Why not, right?$K$PWhen I put the cursor
on the axe and press #P027,$K$PI get a question asking
what I want to do.$K   $RTUT��b|$s1$FS$c1ANNA|Next, I move the cursor to Drop
and press #P027 again$MC...$MD$K    $RTUT��b|$s1$FS$c1ANNA|I do want to drop this,$w3 so
I select Yes$Ub$H
and press #P027 once more!$K$Ub$H
$PIf I had chosen No,$w3
I would have backtracked
one step in the process.$K  $RTUT��b|$s1$FS$c1ANNA|Oh, there's one more thing:$w3
you can't drop essential items that
are required to finish the game.$K   $RTUT��b|$s1$FS$c1ANNA|That's about all you need to
know about dropping stuff$MC...$MD$K
But be careful with it!
If you drop something, it will be
gone forever! FOREVER!!!$K  $RTUT��b|$s1$FS$c1ANNA|Let me tell you about
the Fog of War map.$K$PFog of War means when
your vision is limited to
what's around ally units.$K$PEnemies lurk because it's
dark or foggy elsewhere.$K$PSo, if you run into an enemy
while you are moving $w2or$K   $RTUT��b|$s1$FS$c1ANNA|when you get there,$w3 you'll be
forcibly stopped like this.$K$PYour vision range will not change
until you're done moving, so it's
dangerous to move in a blind panic.$K$POn Fog of War maps, most units can
only see a 3-square range around
them, but some can see even farther.$K   $RTUT��b|$s1$FS$c1ANNA|What you're looking at is a thief.$w4
See? $w2His vision range is clearly
much wider than the last unit's.$K$PEven if you don't have a thief with
you, there's an item that allows
you to expand the vision range.$K    $RTUT����b|$ND$W3This is that item.$w3
It's called a torch.$K$PThe unit using a torch
can expand the vision
by a 4-square range.$K$PLet's light this bad boy!$K    $RTUT��b|$s1$FS$c1ANNA|I'll count the range that he sees.$w4
From where he is, hm...$w3 1, 2, 3$MC...$MD$w4
He can see a total of 7 squares.$K$PBesides his normal 3-square range,
the torch lets him see an additional
4-square range for a total of 7.$K$PBut$MC...$MD$K $RTUT��b|$s1$FS$c1ANNA|Did you see that?$w4
His vision range shrank.$K$PWith a torch, the more turns
you play, the less vision range
you will have.$w4 Careful.$K  $RTUT��b|$s1$FS$c1ANNA|You're now out of the dark
on the Fog of War map.$K$PEnemies often lurk in unexpected
places on the Fog of War map.$K$PFight vigilantly using items and
units.$w4 OK?$K $RTUT��b|$s1$FS$c1ANNA|Hey!$w4 You don't always have to smite
your enemies, you know? You can
clear some maps just by defending!$K $RTUT��b|$s1$FS$c1ANNA|Defending means that you guard
a specific point on the map
for a certain number of turns.$K $RTUT��b|$s1$FS$c1ANNA|The number of turns is shown
by the digit that appears
in the upper left-hand corner.$K$Ub$H
$PYour current turn count is the big
yellow number below that.$w4
Watch both of them carefully.$K$Ub$H
$P$s1$FADefending works a little differently
from the other victory conditions
that you've seen so far.$K$PThere's less of a focus on attacking
enemies and more on staying put and
taking out whoever comes your way.$K$PIf you rush the enemy in a
blind panic and end up losing
the defense position$MC...$MD$K  $RTUT��b|$s1$FA$c1ANNA|Game over, man!$w4
Game over!$K$POh, and like in any other battle,
your game will also end if you
lose Ike.$w4 So watch that.$K$P   $RTUT��b|$s1$FS$c1ANNA|However, just hanging out on the
defensive point isn't always
the smartest move.$K$PIf you have a chance to
eliminate an enemy that wanders
into range, take it!$K  $RTUT��b|$s1$FS$c1ANNA|The best defense is a good offense$MC...$MD
I think I heard that somewhere.$K$PAnyway, just because you're guarding
something doesn't mean you should
let enemies swarm you.$K  $RTUT��b|$s1$FS$c1ANNA|And that's how you win by defending!
Strategy plays a huge role
in a defensive victory.$K$PAttack or wait?$w4 Fight or flight?
Plan each move carefully,$w4
and you'll be fine!$K   $RTUT��b|$s1$FS$c1ANNA|Let's talk a little more about
trading items.$K$PWe already went over how
mounted units can move
again after their initial move.$K$PWell, there's a little technique
that uses that trick$MC... $MD$w4What?
Of course I'll show you, silly!$K$PSee that enemy soldier at the
top of the screen? The one
in the red shirt?$K$PWell, two spaces below him$K$Pyou'll see an allied fighter and
and an allied knight.$K$PLet's check out the weapon that
the fighter has equipped$MC...$MD$K    $RTUT����b|$ND$W2His weapon has a
range of 1.$K$PThat means he can't
atttack unless he's right
next to an enemy.$K$PAnd even if he does,
he'll get counter-
attacked.$K$PNext, let's take a peek
at the knight.$K  $RTUT����b|$ND$W2His weapon range
is 1 to 2 squares.$K$PThis means he can stand
one space away from a
foe and attack.$K$PNow, let's combine his
weapon and the mounted
unit for some trickery$MC...$MD$K   $RTUT��b|$s1$FS$c1ANNA|First, select Attack and have the
knight hit the soldier
with his hand axe.$K   $RTUT��b|$s1$FS$c1ANNA|Since he didn't go very far,
the mounted unit can move again.$K$PLet's put him next
to that big fighter.$K  $RTUT��b|$s1$FS$c1ANNA|Now, put the cursor on the fighter,
$w2and open the unit menu.$K    $RTUT��b|$s1$FS$c1ANNA|See how there's no Attack
command in the unit menu?$K$PThe iron axe has a range of 1,
so he can't use it unless he
moves next to the enemy.$K$Ub$H
$PBut he CAN select Trade and
get a hand axe from the knight that
just rode up next to him$MC...$MD$K    $RTUT��b|$s1$FS$c1ANNA|and then return to the unit menu
by pressing #P028 like so.$w4
Now watch this$MC...$MD$K    $RTUT��b|$s1$FS$c1ANNA|Do you see how the
Attack command showed up
in the unit menu?!$K$PSince he has the hand axe and a
larger attack range, the fighter
can now attack that soldier.$K$PLet's watch, shall we?$w4 Select
Attack and then hand axe$MC...$MD$K $RTUT��b|$s1$FS$c1ANNA|Yeowch! He got served!$K
Making good use of mounted units
and the Trade command
helps you fight effectively.$K  $RTUT��b|$s1$FS$c1ANNA|And$MC...$MD$w4that's the end of the
extended trading tutorial.
Now try it on the battlefield!$K    $RTUT��b|$s1$FS$c1ANNA|You can clear some missions by
escaping from the battle.
Let's learn how!$K $RTUT��b|$s1$FS$c1ANNA|In this battle, you'll earn a victory if
Ike reaches the escape point$MC--$MD$w3
which is those yellow squares there.$K$Ub$H
$PIke isn't the only guy who can escape,
by the way. Your fighting companions
can also make a run for it.$K$PBut as soon as Ike goes, the mission
will end. Here, I'll show you! Let's
send Ike's friend to the exit.$K    $RTUT��b|$s1$FS$c1ANNA|The Escape command will appear
whenever a unit moves
to an escape point.$K$PIf you select Escape and then
choose Yes, the unit will
leave the battlefield$MC...$MD$K    $RTUT��b|$s1$FS$c1ANNA|See how the battle's still going?
That's because Ike is still there.
So why let your allies flee, you ask?$K$PWell, I can't say too much, but$MC...$MD
something nice might happen if
your allies escape.$w5 Ooo, mysterious!$K$PAnyway, now I'll let Ike escape$w3
and earn myself a victory!$K    $RTUT��b|$s1$FS$c1ANNA|There's that Escape command again.$K$PLet's choose it and then confirm
that we want to leave$MC...$MD$K $RTUT��b|$s1$FS$c1ANNA|That's it! I satisfied the escape
condition and cleared the map,$w3
so it's time for the next fight.$K$P    $RTUT��b|$s1$FS$c1ANNA|That's all there is to escaping!$w5
$MC...$MDWhat?$w6 Oh, don't be so macho!$w4
Everyone has to flee sometimes$MC...$MD$K   $RTUT��b|$s1$FS$c1ANNA|It's time you learned about how
to equip your items.$K$PFirst, point the cursor at a
party member and use #P027 to
open up his unit menu.$K$PYou can do this before or
after you've moved him,
as long as he's still active.$K  $RTUT��b|$s1$FS$c1ANNA|So when I select Items from
the unit menu and press
#P027 thusly$MC...$MD$K $RTUT����b|$ND$W2His items are revealed!$w4
Wow, this guy is poor$MC...$MD$K$PAnyway, look where the
cursor is pointing.$K$Ub$H
$PSee that letter E next
to the iron sword?$K$PIt means that the
sword is currently
equipped.$K$PNow let's change his
weapon and see what
happens.$K$PWhen I move the cursor
to the steel sword
and press #P027$MC...$MD$K $RTUT��b|$s1$FS$c1ANNA|It will ask me what I want
to do with the weapon.$K$Ub$H
$PSo I'll move the cursor to
Equip and press #P027 again$MC...$MD$K    $RTUT��b|$s1$FS$c1ANNA|Look at the screen!$w4
The big E has moved from the iron
sword to the steel sword.$K$PE stands for "Equipped," by the way$MC...$MD
But I'm sure you knew that, right?$w5
You did?!$w4 Oh, you're such a smarty!$K$PBut back to business.$w4 This guy used
to have his iron sword at the ready,$w2
but now the steel sword is at hand.$K$PBecause he'll counterattack with
whatever weapon is equipped,$w2
this kind of action is quite important.$K$PEquipping weapons doesn't end your
turn, so feel free to do it
whenever you want.$K    $RTUT��b|$s1$FS$c1ANNA|So that's how you equip weapons.$K$PNow get out there and
go nuts with it!$K    $RTUT��b|$s1$FS$c1ANNA|We have to talk...about talking!$K$PSometimes units can speak to
each other in midbattle.$w4
First, select your initial unit$MC...$MD$K $RTUT��b|$s1$FS$c1ANNA|and move him next to the unit
that he wants to talk to.$K   $RTUT��b|$s1$FS$c1ANNA|See how the Talk command
appeared in the unit menu?$K$PWatch what happens when
I point the cursor to Talk
and press #P027$MC...$MD$K    $R�㉺��b|$c0SOLDIERB|Nice helmet! Where'd you get it?$K
$c1SOLDIERB|Stole it from a dead guy$MC...$MD$K   $RTUT��b|$s1$FS$c1ANNA|There you have it! The miracle of
modern communication.$K$PIn addition to allies, you can also
talk to enemies, Other units,
and Partner units.$K$PYou can only talk to certain people
at certain times, but do it whenever
you have the chance!$K$PYou might gain important information
$w4or even convince other units
to join your cause!$K$PTalking doesn't take a turn, either,
so you can still move or fight or
whatnot after your nice conversation.$K  $RTUT��b|$s1$FS$c1ANNA|That's it for the talk tutorial.
Now go out there and talk
the ear off a cornstalk!!$K  $RTUT��b|$s1$FS$c1ANNA|So you want to know about
Other units, huh? Weeelll$MC...$MD$w5
all right. I'll tell you.$K $RTUT��b|$s1$FS$c1ANNA|Sometimes you'll encounter a green
unit like this fellow here. They are
known as Other units.$K$PBeing neutral, Other units don't
work for you or the enemy$MC--$MD
so you can't control them.$K    $RTUT��b|$s1$FS$c1ANNA|Other units take their turns
during the Other phase
of battle.$K    $RTUT��b|$s1$FS$c1ANNA|This happens after the
enemy's turn is over.$K  $RTUT��b|$s1$FS$c1ANNA|Sometimes Other units will join
your party if you talk to them.$K   $R�㉺��b|$c0SOLDIERB|Good sir knight!
Will you join our quest?$K
$c1SOLDIERG|Sure! I'm tired of being
green anyway.$K $RTUT��b|$s1$FS$c1ANNA|Even if the unit won't join your
party, there are$MC...$MD"other" good
things that can happen! Hee hee!$K$PAnyhow, the point is that you
always want to try and speak
to Other units.$K $RTUT��b|$s1$FS$c1ANNA|And that's all you need to
know about Other units!$w4
See, they're not so scary.$K  $RTUT��b|$s1$FS$c1ANNA|Hey, I have a great idea$MC...$MD
Let's talk about treasure chests!
Everyone loves treasure!$K  $RTUT��b|$s1$FS$c1ANNA|Sometimes you'll find chests
sitting on a battlefield.$K$PSince they have TREASURE inside$MC...$MD$w4
they're usually locked$MC... $MDSo most
units can't just pop them open.$K $RTUT��b|$s3$FS$c3ANNA|But if a unit happens to have a
chest key$MC...$MD$w4it's open sesame!$K    $RTUT��b|$s1$FS$c1ANNA|Let's try it.$w4 First, move the unit
with a chest key next to
the treasure chest.$K    $RTUT��b|$s1$FS$c1ANNA|Because he has a key, a Chest
option appears in the unit menu.$K$PLet's select Chest and press #P027
to open it.$K  $RTUT��b|$s1$FS$c1ANNA|What$MC--?$MD$w4 An elixir?$w4 But I wanted
money! Ah, well... Anyway, any unit
can open a chest if he has a key.$K$PThere's only one kind of key,
so you don't have to worry about
matching them up.$K$PAnd another thing$MC... $MDThieves can open
treasure chests without a key.$K
But sometimes they'll charge you
for this service, $w2so be careful.$K    $RTUT��b|$s1$FS$c1ANNA|That's it! Now go find some
buried treasure, me hearties!
Yar har ho!$K $RTUT��b|$s1$FS$c1ANNA|Back for more, eh? Well,
let's see how Order works.$K$POrder is a command that
lets Ike tell his allies what
action they should take.$K$PIke's the only guy who can use it.$w2
It won't even appear for other units,
so don't sit around and wait$MC... $MDOK?$K$PEssentially, Order lets the CPU
control ally units that weren't given
specific commands during combat.$K$PWhen Ike issues a command,
any unit that hasn't moved yet
will do so when you end your turn.$K$PI know$MC...$MDthat's a lot to take in.$w4
Let me show you how it works.$K  $RTUT��b|$s1$FS$c1ANNA|First, select Order from
Ike's unit menu.$K$Ub$H
$PA list of commands
will then appear.$K$PThe light blue item indicates
the order that is currently
in effect.$K$PThere are four possible orders,$w4
so let's take them from the
top and work our way down.$K  $RTUT��b|$s1$FS$c1ANNA|Rally is the first one.$w4
When this is in effect, allied units
will gather around Ike.$K$PIt's useful when you want to
round up units that are scattered all
over the map.$w5 Or if you're lonely.$K   $RTUT��b|$s1$FS$c1ANNA|Halt is next.$w4 It orders ally
units to remain where they are
and wait for your command.$K$PHalt is the default command. If you
issue it, troops will behave like they
did in the first part of the game.$K$PChoose this command if you want
allies to stay put,$w3 or if you don't
want the CPU moving them around.$K $RTUT��b|$s1$FS$c1ANNA|Target is the next one.$w4 It tells
ally units to converge on a spot
of your choice.$K$PThis one is nice if you need people
to cross a long distance and don't
want to hassle with moving them.$K   $RTUT��b|$s1$FS$c1ANNA|In case you're curious,
the target spot will appear as
a light blue ring like this.$K   $RTUT��b|$s1$FS$c1ANNA|Lastly, you have Avoid.$w4 It orders
allies to find a safe spot where the
enemy is unlikely to attack them.$K$PIf there's no truly safe spot,$w3
the units will move to the
safest area they can find.$K    $RTUT��b|$s1$FS$c1ANNA|Orders are strictly for moving people
around. Units under orders will ignore
enemies unless they're attacked.$K$PIf you want to strike an enemy,$w3
you'll have to take control
of the allied unit.$K$PBe careful, now! If you take control
of a unit yourself, he won't follow
your order until the next turn.$K   $RTUT��b|$s1$FS$c1ANNA|Phew! We covered a lot, $w2but this
concludes the Order tutorial.
I know$MC... $MDYou're beat, huh?!$K$PJust remember that orders are
basically for moving units over long
distances or gathering them up.$K$PIt's more to ease the hassle of
getting around than for strategic
reasons. Don't go crazy with 'em!$K $RTUT��b|$s1$FS$c1ANNA|Let's talk about Support.$K$PSupport happens when two units
form a degree of attachment and
trust between them.$K$PTo do that, they will need be
deployed next to each other
for a period of time.$K$PIf the bond forms, the units
can then return to a base
and support each other.$K$Ub$H
$PHow do you support someone?$w4
First, choose Support when it
appears in the base menu.$K  $RTUT��b|$s1$FS$c1ANNA|That opens up the list of units
like so, and$MC...$MD$K$Ub$H
$Pit shows which units have
grown closer and can
support each other.$K$Ub$H
$PLet's pick Ike for now.$w3$K $RTUT��b|$s1$FS$c1ANNA|Next, I choose which unit
I want him to support.$K$PAll supportable units' names appear
in white text. Units that can't be
supported are in gray.$K$Ub$H
$PLet's give it a shot, shall we?$w3
Since Titania is the only one in
white, we'll pick her.$K$Ub$H
$PI'm asked if I want to engage in
a support conversation.$w4 I'm fine
with that, so I choose Yes.$K   $RTUT��b|$s2$FS$c2ANNA|Then Ike and Titania have a chat
that strengthens their friendship.$w4
Um$MC...$MD$w3we'll skip the talking for now.$K$Ub$H
$PIf units that support each other grow
even closer, they can have more
conversations in the future.$K$P$s2$FABut wait!$w4 Be careful!$w4
Each unit can only have five
support conversations!$K$PSo if they talk again, they will have
a higher level of support, but less
future support opportunities.$K  $RTUT��b|$s2$FS$c2ANNA|Here, watch. This support level will go
from C$w4 to B$Ub$H to A. $Ub$H$w4That's
three levels for one partner.$K$Ub$H
$PBut if you do that, it will use three
of that character's five support
chances$MC--$MDleaving only two more.$K$PThink carefully when you support
each other! Consider both your
partners and what level you want.$K $RTUT��b|$s1$FS$c1ANNA|$Ub$HSo what does supporting each other
do for you?$w4 I'm glad you asked!$K$PUnits that can support each another
get stat bonuses while battling.$K$PThese bonuses only happen when the
units are within three squares$Ub$H
of each other, however.$K$Ub$H
$PBonuses vary, but basically the
supported units will fight
much better than before.$K$PIf you want, you can use the status
screen to determine the exact effect
of two units who support each other.$K$P  $RTUT��b|$s1$FS$c1ANNA|Put the cursor on the unit and press
#P02A to open the status screen.
Bonuses are in the third window.$K$PWhen Titania is supporting him, Ike's$w3
defense goes up by 1, his hit rises
by 7, and his avoid rises by 15!$K$PBut like I said,$w3 support has no
effect unless the units are within
three squares of each other.$K $RTUT��b|$s1$FS$c1ANNA|Whew! So much to process!
But that's the end of
the support tutorial.$K$PYou'll enjoy the game a lot more if
your units support each other.
Not only will you fight better,$K$Pbut you'll learn a lot of interesting
backstory info, too! Keep that in
mind when supporting one another.$K  $RTUT��b|$s1$FS$c1ANNA|Let me tell you about the Direct
command.$K$PAs troop leader, only Ike can use this
special command to lead Partner units.
Let's look at an example.$K  $RTUT��b|$s1$FS$c1ANNA|First, $w2select Direct from Ike's
command menu and press #P027.
$w4Now watch$MC...$MD$K$Ub$H
$PA menu will appear.$K$PThe yellow command is the one that's
currently activated.$K$PThere are four Direct commands.
If you don't issue a command,$w2
Partner units will act on their own.$K
Let me go over each one from
the top.$K $RTUT��b|$s1$FS$c1ANNA|The first command is Roam.$w4
When given this command, Partner
units will act on their own.$K$PThis is the default setting $w2when
Ike has not directed them to
do anything.$K$PUse this command when you don't
have any particular instructions
for Partner units.$K   $RTUT��b|$s1$FS$c1ANNA|When Partner units receive orders to
Halt, they will stop moving and stay
where they are.$K $RTUT��b|$s1$FS$c1ANNA|Use Target to move Partner units
to a particular space.$K$PThis is the same command you use
to move your allied units to a
specific location.$K$PEven if a Partner unit can't reach
the target space in one turn, you
can still use this command.$K $RTUT��b|$s1$FS$c1ANNA|A yellow circle appears on the space
that Ike instructs a Partner unit to
move to.$K$PIf that space is also the target of an
Order command, both blue and yellow
circles will appear.$K $RTUT��b|$s1$FS$c1ANNA|The last Direct command is Avoid.$K$PAvoid instructs Partner units to
move to safety where enemy attacks
may not reach them.$K$PIf no safe place is available,$w2
they will move to a less
vulnerable square.$K $RTUT��b|$s1$FS$c1ANNA|The Target command is the same
when issued to an allied unit or a
Partner unit.$K$PTheir primary goal is to get to
their target destination,$K$Pso they won't attack, even if the
enemy is in their way.$K$PBut if you command them to Roam,$w3
Partner units may attack $w2because
they are acting on their own.$K$PPartner units move during a Partner
phase, which occurs after the player
phase $w2and before the enemy phase.$K    $RTUT��b|$s1$FS$c1ANNA|That's it for the tutorial on
directing your partners.$K$PSimilar to Other units, $w2you can't
move Partner units.$K$PBut you do have some control over
their action.$K$PUse them against a formidable enemy$w3
or as a shield for allied units.
$w4Use them to your advantage.$K   $RTUT��b|$s1$FS$c1ANNA|Let me explain transformation.$K    $RTUT��b|$s1$FS$c1ANNA|Units belong to one of two tribes:$w4
the beorc and the laguz.$K    $RTUT��b|$s1$FS$c1ANNA|Under normal circumstances, they
look alike, $w2but the laguz
change themselves to fight.$K$PThis is called transformation.$K$PThe transform gauge $w1$Ub$Hshows
the power built up for transformation
into beast form.$K   $RTUT��b|$s1$FS$c1ANNA|The transform gauge increases by 4
after every turn and$K   $RTUT��b|$s1$FS$c1ANNA|increases by 2 more when
the laguz are attacked.$K  $RTUT��b|$s1$FS$c1ANNA|When the gauge reaches 20,
the laguz transforms.$K  $RTUT��b|$s1$FS$c1ANNA|Transformed units are very powerful.$K  $RTUT��b|$s1$FS$c1ANNA|But their altered state is temporary.$K$PAfter they've changed, $w2the gauge
drops by 3 after every turn, and it
falls another 1 if they fight.$K$PThe gauge will eventually drop
down to zero.$K   $RTUT��b|$s1$FS$c1ANNA|And the process will repeat itself.
Take advantage of the laguz's special
ability$w2 to gain an edge in battle.$K   $RTUT��b|$s1$FS$c1ANNA|That's it for the transformation
tutorial.$K$PDon't blindly go after enemies
just because you've transformed.$K$PBe sure to pay attention to the
transform gauge as you fight.$K    $RTUT��b|$s1$FS$c1ANNA|Let me explain the Equip command
for you now.$K$PSome items work when you use
them,$w2 but others take effect only
when you equip them.$K$PFor instance$MC...$MD$K  $RTUT����b|$ND$W2Look at your items.$w4
See the laguzguard?$K$PLet's press #P02A to open
the help window and see
what the item does.$K $RTUT��b|$s3$FS$c3ANNA|See how it says "when equipped"
there in the item description?$K$PThat means$w2 this item takes effect
only when a unit has it equipped.$K$PEquipping an item is the same as
equipping a weapon.$K  $RTUT��b|$s1$FS$c1ANNA|Now your unit can benefit from the
item's effects.$K$PBut not everyone can equip all items,
$w2so be careful.$K $RTUT��b|$s1$FS$c1ANNA|That wraps it up for the tutorial
on equipping items.$K$PI don't mean to repeat myself,
$w2but items like these are
useless $w2unless you equip them.$K$PThey won't do you any good if
you just carry them around!
Don't forget that.$K $RTUT��b|$s1$FS$c1ANNA|Let me take a moment to explain
airborne units.$K$PA subset of mounted units$w2, these
units include $w1pegasus $w1and
wyvern mounts.$K$PBecause they are airborne, $w2they
can travel places that mounted units
can't, such as rivers.$K   $RTUT��b|$s1$FA$c1ANNA|But they also don't get the combat
benefits of terrain because they're
in the air.$K$PWhat's more...$K  $RTUT��b|$s1$FA$c1ANNA|They're very vulnerable to bow attacks.
$w2In fact, they can often be brought
down with a single shot.$K$PSo, be very careful where you move
them, or$w2 they'll become an
easy target.$K   $RTUT��b|$s1$FS$c1ANNA|That's about it for airborne units!
Happy flying!$K $RTUT��b|$s1$FS$c1ANNA|Pssst$MC... $MDDo you want to steal
something?$w4 You do?
Oh, how naughty!$K$PWell, this is your lucky day!
Thieves can steal items
from enemy units.$K$PBut they can't steal items
that are already equipped.
Only extra stuff.$K$PLet's have this nice thief here
demonstrate how to steal
something from an enemy.$K$PFirst, move your thief
next to the unwary mark.$K  $RTUT��b|$s1$FS$c1ANNA|You have to be right next to an
enemy in order to steal something,
so get all up in his grill like this.$K$PNext,$w3 select Steal from the
unit menu$w3 and decide which
enemy unit to steal from.$K    $RTUT����b|$ND$W1This window will show you
any weapons or items
that an enemy has.$K$PHmm$MC...$MDit looks like this fellow has
an iron sword and a vulnerary.$K$PBecause the sword is equipped,
it can't be stolen$MC...$MD$K$PSo let's take the vulnerary instead!$w4
Choose it and press #P027.$K   $RTUT��b|$s1$FS$c1ANNA|Presto!$w4 You just stole
that guard's vulnerary!$w3
What a sucker!$K$PBut don't think you can
just steal from everyone.
There are a couple of rules.$K$PFirst, your speed must be
1 point higher than the
target's speed.$K$PAnd second, your strength
must be 1 point higher
than the weight of the item.$K   $RTUT��b|$s1$FS$c1ANNA|That's it for the tutorial on
the art of stealing. Now go
get some five-finger discounts.$K $RTUT��b|$s1$FS$c1ANNA|Let me tell you about doors now.
What? You know about doors?
Not these doors, buddy! Just listen!$K $RTUT��b|$s1$FS$c1ANNA|As you play the game,$w3
you'll find rooms sealed behind
closed doors$MC...$MD$w5like this one!$K   $RTUT��b|$s3$FS$c3ANNA|If your unit has a door key in his
inventory, he can open it right up.$K$PNo key?$w2 Let a thief do it!$w2
Thieves can pick the lock and
open the door just like that.$K$PHowever, thieves will sometimes
charge you for their services$MC...$MD$w3
so use a key if you can.$K  $RTUT��b|$s1$FS$c1ANNA|Allrighty then, let's try opening
a door with a key-carrying unit.$K$PFirst, you have to move the unit
next to the door.$w4
Yeah, I know.$w4 Basic, right?$K    $RTUT��b|$s1$FS$c1ANNA|If the unit has a key,$w3 the
Door command will appear in
the unit menu.$K$PLet's select it and
see what happens$MC...$MD$K $RTUT��b|$s1$FS$c1ANNA|Voila!$w4 Ze doors,
zey have opened!$K$PYou can also choose the key
right out of your item menu
if you so desire.$K$PAnd that concludes the$MC...$MD$w6 Oops!$w3
I forgot something!$w5 Oh, don't roll
your eyes! This is really cool$MC...$MD$K$PYou can attack doors and
break them down!$w4
See? I told you it was cool.$K$PSo if you don't have a key
or a thief handy, just walk
up to the door and smash it.$K$PI hear that axes work really well.
But$MC...$MD$w4um$MC...$MD$w4 I don't have any personal
knowledge or anything$MC...$MD$K   $RTUT��b|$s1$FS$c1ANNA|Anyway, this REALLY concludes
the door tutorial.
See ya later!$K    $RTUT��b|$s1$FS$c1ANNA|Let's discuss upgrading classes.$w4
No, I'm not talking about school.
Sheesh!$K$PMoving from one class to another
is called "upgrading." Like an
archer becoming a sniper, for example.$K$PMost beorcs can upgrade from one
class to another if they meet
certain conditions.$K$PWhen a unit upgrades his class, he
will get stat bonuses and also gain
the ability to use different weapons.$K$PThere are two ways to upgrade.
$w2I'll show you both of them,
so pay attention!$K  $RTUT��b|$s1$FS$c1ANNA|The first way is to increase
a unit's level to 20, then gain
an extra 100 experience points.$K$PYou might think he would just
level up to 21,$w4 but in this case$MC...$MD$K    $RTUT��b|$s1$FS$c1ANNA|his class changes, like so! He's
upgraded from one class to another!$K$PAlthough his level resets and his
experience points drop to zero,$w2
his stats shoot through the roof.$K$PBut let me show you another way.$K    $RTUT��b|$s1$FS$c1ANNA|There's a level 12 unit here.$w4
Let's take a look at his items.$K  $RTUT��b|$s3$FS$c3ANNA|See how this fellow has an item
called Master Seal?$K$PThe Master Seal allows any unit
at level 10 or higher to upgrade
classes instantly.$K$PBecause this soldier is a level 12 unit,
$w3he can use the Master Seal.$K$PA unit can only upgrade once.$w4
When he reaches level 20, he won't
get any more experience points.$K$POh, and if a unit is already a high
class to begin with, like Titania,
the unit won't ever change classes.$K    $RTUT��b|$s1$FS$c1ANNA|Well, that's it for the tutorial
on upgrading classes.$w4
Class dismissed! Hee hee!$K   $RTUT��b|$s1$FS$c1ANNA|Can't get enough of Anna, huh?$w4
Well, let me show you how to earn
the Arrive victory condition.$K$PUnlike the Escape and Seize victory
conditions, $Ub$H$w2Arrive lets you clear
a map with someone other than Ike.$K$PBasically, Arriving means either Ike$w4 or$Ub$H
another allied unit
reaches a certain point on the map.$K$PSince Ike is such a big glory hog,
I'll let this fellow here
show us how it's done.$K   $RTUT��b|$s1$FS$c1ANNA|When the ally moves to the flashing
blue square, $w2the Arrive command
appears in the unit menu.$K$Ub$H
$PThen you just have to choose Yes$w2
and press #P027 to clear the map.$K$PHere, watch$MC...$MD$K   $RTUT��b|$s1$FS$c1ANNA|Whoo! It's so easy! And you can even
use the Arrive command while
enemies are still roaming around.$K$PRemember$MC...$MD$w4anyone in your
party can reach the Arrive point
and end the mission.$K$PI don't mean to sound like a broken
record$MC... $MDBut it's pretty cool,
don't you think?!$K    $RTUT��b|$s1$FS$c1ANNA|Also, on some maps you must
reach the blue square within
a specific number of turns.$K$PSo if you take your sweet time
and lollygag around$MC...$MD$w4
D'oh!$w4 Sucks to be you!$K$POn the missions with such a limit,
you can see the remaining number
of turns right here in the corner.$K$PSo if there's no number here,
take all the time you want!$K   $RTUT��b|$s1$FS$c1ANNA|And that's it! One could say that
you$MC...$MD$w5 Arrived at the end!
Tee hee!$K    $RTUT��b|$s1$Fc$s1$FS$c1ANNA|Zzzzz$MC...$MD
Yar$MC...$MDI'm a pirate$MC... $MDYar$MC...$MD
Zzzz$MC...$MD$K$P$s1$Fd$c1ANNA|Wha--?$w5 Huh?$w4 Oh, it's you$MC...$MD
Um$MC...$MD$w3 Er$MC...$MD$w4 Let's talk about
movement cost! Yeah, that's it$MC...$MD$K$PSimply stated, movement cost
numerically indicates the difficulty
of moving through terrain.$K$PFor example, this mounted fellow
here is sitting in the middle of
some desert terrain.$K   $RTUT��b|$s1$FS$c1ANNA|Watch what happens when I try to
move him around$MC...$MD$K $RTUT��b|$s1$FS$c1ANNA|See how his range is so much smaller
in the desert than the plains?$K$PIt's tough for horses to move in sand,
so mounted units have a high
movement cost in the desert.$K$PLet's extend the arrow and see
how much movement range
he loses.$K   $RTUT��b|$s1$FS$c1ANNA|Yipes!$w4 The arrow is so much
shorter! But different units have
trouble in different terrain types.$K$PHeavily armored units such as
generals, for example, will have
a tough time moving on plains.$K$PHowever, there are some that can
move just about anywhere
without any difficulty at all.$K $RTUT��b|$s1$FS$c1ANNA|Let's check out the unaffected units$MC...$MD$w3
$Ub$HThieves$MC...$MD$w4and $Ub$Hairborne units.$K $RTUT��b|$s1$FS$c1ANNA|First up is the thief.$w3 As you see,
he can move with equal ease
on both terrain types.$K  $RTUT��b|$s1$FS$c1ANNA|The airborne unit is next.$K    $RTUT��b|$s1$FS$c1ANNA|No difference here either!$K$PBecause airborne units fly around,
they are rarely affected by terrain.$K $RTUT��b|$s1$FS$c1ANNA|We're using desert and plains here to
illustrate the point, $w2but each
terrain has a movement cost.$K$PThat cost changes depending
on the unit, so keep a close eye
on it, all right?$K    $RTUT��b|$s1$FS$c1ANNA|And that's the end of the
movement-cost tutorial$MC...$MD$w5
Man, I'm so sleepy$MC...$MD$K  $RTUT��b|$s1$FS$c1ANNA|Let's talk about the incredibly handy
Chant command. Doesn't that
sound like fun?$K$PChant lets a player move twice
in the same turn.$K$PPrince Reyson is the only one who
can use Chant, so let's put him next
to an ally who has already moved.$K $RTUT��b|$s1$FS$c1ANNA|Doing so will open up the Chant
command in the unit menu.$K$PUsing it is just like attacking.$w3
Select Chant from the menu, pick a
unit to use it on, and press #P027.$K   $RTUT��b|$s1$FS$c1ANNA|Did you see that unit's color return?$K$PThis is because he can now move
again. What a deal!$K$PIn this fashion, you can use Chant
to let units who have already
acted move again.$K$POh, and Reyson will gain ten
experience points for chanting,
so you should use it on every turn.$K    $RTUT��b|$s1$FS$c1ANNA|Because Reyson is a laguz,$w3
he can shift.$K   $RTUT��b|$s1$FS$c1ANNA|And if he uses Chant after shifting$MC...$MD$K$P    $RTUT��b|$s1$FS$c1ANNA|Holy crow!$w4 He restored a turn to
every unit that was standing
next to him!$K$PThat means up to four units can
regain their movement capabilities.
Think of the possibilities$MC...$MD$K  $RTUT��b|$s1$FS$c1ANNA|Anyway, that's it for chanting.
I hope you're suitably impressed.$K   t      x     �         0  �   @  �   P  D   h  �   �  t   �  �   �  �   �  `   �  �   �  	�    
,  (    @  �  X  �  p  X  �  �  �      �   �  �  �  �  &  �  '`  �  (4    )    *4     +�  .  1x  <  2l  L  2�  \  3\  l  4  |  50  �  4  �  �  �  D  �  D  �  �  �    �  �  �  �  �  `    �    �  (    6  ,�  D  -�  R  .  `  .�  n  /4  |  /�  �  0P  �  `  �   �  �  !�  �  #l  �  $�  �  Z�  �  [�    ]    ^�  "  _�  4  `�  D  a�  T  c�  d  eT  t  e�  �  f�  �  g  �  =�  �  >  �  >�  �  ?,  �  ?d  �  ?�  �  @�  
  A     J�  &  Kl  4  K�  B  L,  P  L�  ^  Np  l  Q  z  Q�  �  S0  �  S�  �  S�  �  UP  �  U�  �  V�  �  W�  �  X|  �  Y�    Z    g|  "  h<  0  i�  >  i�  L  j�  Z  k�  h  A�  v  F  �  Fh  �  F�  �  G0  �  Ix  �  I�  �  6H    8    :   ,  :�  :  ;�  H  =<  V  8�  d  �4  s  ��  �  �  �  �   �  ��  �  ��  �  ��  �  ��  �  �t  �  q     r    rp    r�  )  s8  5  tp  A  u�  M  l,  Y  m<  g  m�  u  np  �  o<  �  p�  �  v(  �  w�  �  z�  �  {�  �  }  �  }�  	  ~�  	  D  	+  �  	;  �x  	K  ��  	[  �  	k  ��  	{  ��  	�  ��  	�  �$  	�  �p  	�  �  	�  ��  	�  �p  	�  ��  
  ��  
  �P  
%  �  
7  �8  
I  �T  
W  �p  
e  �l  
s  �  
�  �L  
�  �  
�  ��  
�  �(  
�  �<  
�  �P  
�  ��  
�  ��  
�  �0  
�  ��    �4    �  +  ��  9  �  G  ��  U  �(  c  ��  q  �    ��  �  ��  �  ��  �  �<  �  �8  �  �<  �  �T  �  �p    ��    ��  #  �|  1  ��  ?  �`  M  ��  [  �   i  ��  w  �`  �  �L  �  �l  �  ��  �  �x  �  �|  �  �    �@    ��  +  �$  ?  �P  O  �H  _  �  o  ��    ��  �  �0  �  ��  �  �(  �  �`  �  �D  �  Ҕ  �  ӈ  �  ��    Ԝ    �  /  �X  ?  ��  U  �(  k  �l  �  ��  �  �  �  ��  �  ��  �  ��  �  ��  �  �  	  ��    �x  )  ��  9  ��  I  �\  Y  �\  i  ��  y  ��  �  ��  �  �   �  ��  �  ٔ  �  ڠ  �  �D  �  �  �  ܈  �  ��    �    ߨ  #  �d  1  �,  ?  ��  M  ��  [  �$  i  �  w  �  �  �<  �  �`  �  ��  �  �4  �  ��  �  �0  �  �  �  �4  �  ��    �`    �<  /  ��  E  ��  [  ��  q  ��  �  �<  �  ��  �  �h  �  �0  �  ��  �    �  �  �   	  ��    �D  %  ��  3  ��  A  �|  O  �8  ] �  m 8  { �  � t  � 4  � �  � x  � �  � h  � �  � �  � �   �   �  # 	,  3 
  A \  O !T  ] !�  k !�  y "�  � #4  � #�  � #�  � $  � $�  � %t  � &@  � &�  � '�   (`   (�  / )�  ? *�  M +l  [ ,@  i   w �  �   � 0  � �  � �  � �  � h  �  (  � 7�  � 9�   :|  ' ;l  ? ;�  W =�  o ,�  � .  � .�  � 0  � 1`  � 1�  � 2P  � 2�  � 3�  � 4�  � 5@  	 7l   >   ! ?�  / @�  = A�  K CH  Y C�  g El  { E�  � F�  � H  � H�  � H�  � I,  � I�   J�   J�  / L   = L�  K M�  Y N@  g N�  u O`  �  t  �  P  �MS_T00�^�[��_01 MS_T00�^�[��_02 MS_T00�^�[��_03 MS_T00�^�[��_04 MS_T00�^�[��_05 MS_T00�}�b�v���j���[_01 MS_T00�}�b�v���j���[_02 MS_T00�}�b�v���j���[_03 MS_T00�}�b�v���j���[_04 MS_T00�}�b�v���j���[_05 MS_T00�}�b�v���j���[_06 MS_T00�}�b�v���j���[_07 MS_T00�}�b�v���j���[_08 MS_T00�}�b�v���j���[_09 MS_T00�}�b�v���j���[_10 MS_T00�}�b�v���j���[_11 MS_T00�}�b�v���j���[_12 MS_T00�}�b�v���j���[_13 MS_T00�}�b�v���j���[_14 MS_T00�}�b�v���j���[_15 MS_T00��l��_01 MS_T00��l��_02 MS_T00��l��_03 MS_T01Lvup_01 MS_T01Lvup_02 MS_T01Lvup_03 MS_T01Lvup_04 MS_T01Lvup_05 MS_T01Lvup_06 MS_T01�X�L��_01 MS_T01�X�L��_02 MS_T01�X�L��_03 MS_T01�X�L��_04 MS_T01�X�L��_05 MS_T01�X�L��_06 MS_T01�ړ�_01 MS_T01�ړ�_02 MS_T01�ړ�_03 MS_T01�ړ�_04 MS_T01�ړ�_05 MS_T01�ړ�_06 MS_T01�ړ�_07 MS_T01�U��_01 MS_T01�U��_02 MS_T01�U��_03 MS_T01�U��_04 MS_T01�U��_05 MS_T01����_01 MS_T01����_02 MS_T01����_03 MS_T01����_04 MS_T01����_05 MS_T01����_05_02 MS_T01����_06 MS_T01�̓�_01 MS_T01�̓�_02 MS_T01�̓�_02_02 MS_T01�̓�_03 MS_T01�̓�_04 MS_T02���p��_01 MS_T02���p��_02 MS_T02���p��_03 MS_T02���p��_03_2 MS_T02���p��_04 MS_T02���p��_05 MS_T02���p��_06 MS_T02���p��_07 MS_T02���p��_07_2 MS_T02���p��_08 MS_T02���p��_09 MS_T02���p��_10 MS_T02�R��_01 MS_T02�R��_02 MS_T02�R��_03 MS_T02�R��_04 MS_T02�R��_05 MS_T02�R��_06 MS_T02�R��_07 MS_T02�R��_08 MS_T02�~�o_01 MS_T02�~�o_02 MS_T02�~�o_03 MS_T02�~�o_04 MS_T02�~�o_05 MS_T02�~�o_06 MS_T02�~�o_07 MS_T02�~�o_08 MS_T02�~�o_09 MS_T02�~�o_10 MS_T02����_01 MS_T02����_02 MS_T02����_03 MS_T02����_04 MS_T02����_05 MS_T02����_06 MS_T02����_07 MS_T02����_08 MS_T02����_01 MS_T02����_02 MS_T02����_03 MS_T02����_04 MS_T02����_05 MS_T02����_06 MS_T02����R������_01 MS_T02����R������_02 MS_T02����R������_03 MS_T02����R������_04 MS_T02����R������_05 MS_T02����R������_06 MS_T02����R������_07 MS_T02�K��_01 MS_T02�K��_02 MS_T02�K��_04 MS_T02�K��_05 MS_T02�K��_06 MS_T02�K��_07 MS_T02�K��_VIL MS_T03�U���Q_01 MS_T03�U���Q_01_2 MS_T03�U���Q_02 MS_T03�U���Q_03 MS_T03�U���Q_04 MS_T03�U���Q_05 MS_T03�U���Q_06 MS_T03�U���Q_07 MS_T03�U���Q_08 MS_T03��_01 MS_T03��_02 MS_T03��_03 MS_T03��_04 MS_T03��_05 MS_T03��_06 MS_T03��_07 MS_T03�S��_01 MS_T03�S��_02 MS_T03�S��_03 MS_T03�S��_04 MS_T03�S��_05 MS_T03�S��_06 MS_T03�n�`����_01 MS_T03�n�`����_02 MS_T03�n�`����_03 MS_T03�n�`����_04 MS_T03�n�`����_05 MS_T03�n�`����_06 MS_T03�n�`����_07 MS_T03�G�͈�_01 MS_T03�G�͈�_02 MS_T03�G�͈�_03 MS_T03�G�͈�_04 MS_T03�G�͈�_05 MS_T03�G�͈�_06 MS_T03�G�͈�_07 MS_T03�G�͈�_08 MS_T03�G�͈�_09 MS_T03�G�͈�_10 MS_T04�ԐڍU��_01 MS_T04�ԐڍU��_02 MS_T04�ԐڍU��_03 MS_T04�ԐڍU��_04 MS_T04�ԐڍU��_05 MS_T04�ԐڍU��_06 MS_T04�ԐڍU��_07 MS_T04��_01 MS_T04��_02 MS_T04��_03 MS_T04��_04 MS_T04��_05 MS_T04��_06 MS_T04��_07 MS_T04��_08 MS_T04�i��_01 MS_T04�i��_02 MS_T04�i��_03 MS_T04�i��_04 MS_T04�i��_05 MS_T04�i��_05_2 MS_T04�i��_06 MS_T04�i��_07 MS_T04�i��_08 MS_T04�i��_09 MS_T04�i��_10 MS_T04�i��_11 MS_T04�i��_12 MS_T04�i��_13 MS_T04�i��_14 MS_T04�i��_15 MS_T04�i��_16 MS_T04�G���̌��j_01 MS_T04�G���̌��j_02 MS_T04�G���̌��j_03 MS_T04�G���̌��j_04 MS_T04����_01 MS_T04����_02 MS_T04����_03 MS_T04����_04 MS_T04����_05 MS_T04����_06 MS_T04����_07 MS_T04����_08 MS_T04����_09 MS_T05�p�����[�^_01 MS_T05�p�����[�^_02 MS_T05�p�����[�^_03 MS_T05�p�����[�^_04 MS_T05�p�����[�^_05 MS_T05�p�����[�^_06 MS_T05�p�����[�^_07 MS_T05�p�����[�^_08 MS_T05�p�����[�^_09 MS_T05�p�����[�^_10 MS_T05�w���v_01 MS_T05�w���v_02 MS_T05�w���v_03 MS_T05�w���v_04 MS_T05�w���v_05 MS_T05�w���v_06 MS_T05�w���v_07 MS_T05�w���v_08 MS_T05�w���v_09 MS_T05�̂Ă�_01 MS_T05�̂Ă�_02 MS_T05�̂Ă�_03 MS_T05�̂Ă�_04 MS_T05�̂Ă�_05 MS_T05�̂Ă�_06 MS_T05�̂Ă�_07 MS_T05���@�R������_01 MS_T05���@�R������_02 MS_T05���@�R������_03 MS_T05���@�R������_04 MS_T05���@�R������_05 MS_T05���@�R������_06 MS_T05���@�R������_07 MS_T06�����Q_01 MS_T06�����Q_02 MS_T06�����Q_03 MS_T06�����Q_04 MS_T06�����Q_05 MS_T06�����Q_06 MS_T06�����Q_07 MS_T06�����Q_08 MS_T06�����Q_09 MS_T06�����Q_10 MS_T06�����Q_11 MS_T06���G_01 MS_T06���G_02 MS_T06���G_03 MS_T06���G_04 MS_T06���G_05 MS_T06���G_06 MS_T06���G_07 MS_T06�h�q_01 MS_T06�h�q_02 MS_T06�h�q_03 MS_T06�h�q_04 MS_T06�h�q_05 MS_T06�h�q_06 MS_T06�h�q_07 MS_T07����_01 MS_T07����_02 MS_T07����_03 MS_T07����_04 MS_T07����_05 MS_T07����_06 MS_T07���E_01 MS_T07���E_02 MS_T07���E_03 MS_T07���E_04 MS_T07���E_05 MS_T07���E_06 MS_T07���E_07 MS_T08�������j�b�g_01 MS_T08�������j�b�g_02 MS_T08�������j�b�g_03 MS_T08�������j�b�g_04 MS_T08�������j�b�g_05 MS_T08�������j�b�g_06 MS_T08�������j�b�g_07 MS_T08�������j�b�g_Talk MS_T08��_01 MS_T08��_02 MS_T08��_03 MS_T08��_04 MS_T08��_05 MS_T08��_06 MS_T08��_07 MS_T08�b��_01 MS_T08�b��_02 MS_T08�b��_03 MS_T08�b��_04 MS_T08�b��_05 MS_T08�b��_Talk MS_T09�x��_01 MS_T09�x��_02 MS_T09�x��_03 MS_T09�x��_04 MS_T09�x��_05 MS_T09�x��_06 MS_T09�x��_07 MS_T09�x��_08 MS_T09����_01 MS_T09����_02 MS_T09����_03 MS_T09����_04 MS_T09����_05 MS_T09����_05_2 MS_T09����_06 MS_T09����_07 MS_T09����_08 MS_T10���g_01 MS_T10���g_02 MS_T10���g_03 MS_T10���g_03_1 MS_T10���g_03_2 MS_T10���g_03_3 MS_T10���g_04 MS_T10���g_05 MS_T10���g_06 MS_T10���g_07 MS_T10�����Q_01 MS_T10�����Q_02 MS_T10�����Q_03 MS_T10�����Q_04 MS_T10�����Q_05 MS_T10��s_01 MS_T10��s_02 MS_T10��s_03 MS_T10��s_04 MS_T10�v��_01 MS_T10�v��_02 MS_T10�v��_03 MS_T10�v��_04 MS_T10�v��_05 MS_T10�v��_05_2 MS_T10�v��_06 MS_T10�v��_07 MS_T10�v��_08 MS_T11�N���X�`�F���W_01 MS_T11�N���X�`�F���W_02 MS_T11�N���X�`�F���W_03 MS_T11�N���X�`�F���W_04 MS_T11�N���X�`�F���W_05 MS_T11�N���X�`�F���W_06 MS_T11����_01 MS_T11����_02 MS_T11����_03 MS_T11����_04 MS_T11����_05 MS_T11��_01 MS_T11��_02 MS_T11��_03 MS_T11��_04 MS_T11��_05 MS_T11��_06 MS_T11��_07 MS_T12���B_01 MS_T12���B_02 MS_T12���B_03 MS_T12���B_04 MS_T12���B_05 MS_T16�ړ��R�X�g_01 MS_T16�ړ��R�X�g_02 MS_T16�ړ��R�X�g_03 MS_T16�ړ��R�X�g_04 MS_T16�ړ��R�X�g_05 MS_T16�ړ��R�X�g_06 MS_T16�ړ��R�X�g_07 MS_T16�ړ��R�X�g_08 MS_T16�ړ��R�X�g_09 MS_T16�ړ��R�X�g_10 MS_T19���_01 MS_T19���_02 MS_T19���_03 MS_T19���_04 MS_T19���_05 MS_T19���_06 MS_T19���_07 MS_T_Demo MS_T_r 