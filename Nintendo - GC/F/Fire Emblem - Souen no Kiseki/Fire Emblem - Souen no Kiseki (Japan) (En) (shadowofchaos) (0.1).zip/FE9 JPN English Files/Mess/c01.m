  !  |                       $R�㉺��b|$s0$FS$c0MIST|$s0Are you all right?$K
$c1IKE|$s1Nn$MC... $MD$w3Yeah, I'll be fine.$K $R�㉺��b|$s0$FS$c0GREIL|$s0So, the sleeping prince awakens!$K
$c1MIST|$s1Father!$w4 I can't believe you!$K$PI know those are practice swords,
but they're still heavy! You have
no right to be so rough on Ike.$K
$s0If this is too much for the boy,$w3
he'll never make it as a mercenary.$K
$s1But$MC--$MD$K
$d0$c0IKE|$Ub$HMist, $w2you don't have to worry.
I told you, I'm fine.$K
$d1$s1$FS$c1GREIL|Ha! $w2You'd better be.$w5 Now
grab your sword and get ready!$K
$d0$c0MIST|$s0What? $w2Don't tell me$w3 you're
going at it again!$w3 But$MC--$MD$K
$d1$c1IKE|$s1Just until I land a single blow.$w4
I'm not giving up until I can get
one good hit in on Father.$K
$d0$s0$FS$c0GREIL|$s0I like your resolve, Ike.$w4 But $w2it takes
more than a strong will to$MC... $MD$w4Hm?$K  $R�㉺��b|$s0$FS$c0BOLE|$s0Aha!$w3 I knew I'd find you here!$K $R�㉺��b|$s1$FS$c1MIST|$s1Hi,$w3 Boyd.$w3
What brings you here?$K
$s0$FS$c0BOLE|$s0Nothing special.$w4$K$PYou said you were going to get the
boss, $w2but you never came back.$w4
I got picked to check up on you.$K
$s1Oh! Sorry, I got caught up with
Ike and my father.$K
$s0It's nothing.$w2 Besides, I figured I'd
get a good laugh$w2 watching Ike get
worked over by the boss.$K
You$MC...$MD$w4look fine.$w4 What happened?$K
$d1$c1IKE|$s1Nothing at all.$w3 I'm sorry
to disappoint you.$K
$d0$s0$FS$c0MIST|$s0You just missed it.$w5 Just a minute
ago,$w2 he was out cold.$K
$s1Mist!$K
$s0Ha ha!$w2 Sorry.$K
$d1$d0$s0$FS$c0GREIL|You came at just the right time, Boyd.$K$PYou can be Ike's sparring partner.$K
$c1BOLE|$s1What?$w3 Me?$K
$s0I'm beginning to think it would be
better if he sparred with someone$w2
closer to his own skill.$K
$d1$c1IKE|$s1$MC...$MDI understand.$K
$d0$s1Thanks for your help, $w2Boyd.$K
$c0BOLE|$s0$FSHmph!$w3 I don't know about this "closer
to his skill" business,$w2 but I'm ready!$K $R�㉺��b|$s1$FS$c1BOLE|$s1All right. $w2I'm ready for you!$w5
Let's go!$K $R�㉺��b|$c0MIST|$s0Not that way,$w3
Ike!$K   $R�㉺��b|$c0MIST|$s0Did you hear me?$w3
Not that way!$K   $R�㉺��b|$c0MIST|$s0Hey!$w4
Are you even listening to me?$K   $R�㉺��b|$s1$FS$c1BOLE|$s1Hey! $w2What's the holdup?$w4
Let's get started already.$K
$c0IKE|$s0I'm coming.$w3 Wait right there!$K $R�㉺��b|$s0$FS$c0GREIL|$s0Your swordsmanship was decent
enough, Ike.$w5 Don't forget how
it felt. It won't always be this easy.$K
$c1IKE|$s1I know.$K
$s0Now that you're done warming up,$w2
it's time for you to face me again.$K
$s1I was hoping you'd say that.$K
$s0But first$MC...$MD$w3
Mist!$K
$d1$s1$FS$c1MIST|$s1Right here!$K  $R�㉺��b|$s0$FS$c0MIST|$s0Here you go,$w2 Ike!$w4
It's a vulnerary.$K $R�㉺��b|$s0$FS$c0MIST|$s0I'd recommend using it now,$w2
before you fight Father.$w3 Last time,
he knocked you silly.$K   $R�㉺��b|$s0$FS$c0GREIL|$s0Always take time to heal your wounds
in a battle$MC--$MDeven small ones.$K$PBy the time you think you're in
trouble,$w2 it's probably too late$MC...$MD$w3
Don't get into that situation.$K    $R�㉺��b|$s0$FS$c0GREIL|$s0Get ready, Ike$w3$MC--$MDhere I come!$K    $R�㉺��b|$s0$FS$c0GREIL|$s0Come on, boy!$w3 You going to give
me a challenge this time around?$K
$c1IKE|$MC...$MD$K   $R�㉺��b|$s1$FS$c1BOLE|$s1Hurry up, will you?$w4
Or $w2are you afraid of me?$K    $R�㉺��b|$c1BOLE|$s1Come on! $w2What are you doing?$w4
Are you sure you really want to
learn how to fight?$K  $R�㉺��b|$s1$Fh$c1BOLE|$s1Yaaaawn$MC...$MD$w5
You know, $w2I'm getting sleepy.$K  $R�㉺��b|$s1$FS$c1BOLE|$s1Ha ha!$w3 I'm not done yet.$w2
We're just getting started.$K    $R�㉺��b|$c1BOLE|$s1Whoa!$w4 Come on!$w5
What's that all about?$w3
You're wasting our time!$K $R�㉺��b|$c0MIST|$s0Ah!$K $R�㉺��b|$c0MIST|$s0I can't believe this!$w4
If you throw your weapon away,$w2
how do you expect to fight?$K$PLet me help$MC...$MD$w3$FS
Here you go, Ike.$w4 Here's your sword.$K
$c1IKE|$s1Oh$MC...$MD$w2thanks.$K
$s0$FS$c0MIST|$s0Try to be a little more careful!$K  $R�㉺��b|$s0$FS$c0MIST|$s0You can do it!$w4 Boyd's got
nothing!$w2 Take him out!$K
$c1BOLE|$s1"Nothing"!? I don't have nothing.$w5
I mean, I have$MC--$MD$w3 I mean$MC...$MD$K    $R�㉺��b|$s1$FS$c1BOLE|$s1That$MC--$MD$w2that wasn't too bad.$K
$s0$FS$c0MIST|$s0Boyd, $w2you're such a loser.$K
$s1$FAShut your trap!$K
$d0$s0$FS$c0GREIL|$s0Good work, Boyd.$w4
That's enough.$K
$s1Oh, $w2all right!$K $R�㉺��b|$s0$FS$c0GREIL|$s0Give it your all!$K    $R�㉺��b|$c0GREIL|$s0Ungh$MC...$MD$K  $R�㉺��b|$c0IKE|$s0Oof$MC...$MD$w2I can$MC...$MDkeep going$MC...$MD$K
$c1MIST|$s1Ike!$w3 That's enough!$K
$d1$c1GREIL|$s1Ike,$w4 if this training is still too much
for you$MC...$MD$w4you're not ready to take
the field.$K
$s0$MC...$MD$K   $R�㉺��b|$s0$FS$c0MIST|$s0Ike! $w2You were great!$K
$c1IKE|$s1Father,$w4 you were holding back,
weren't you?$K
$s0$FAWhat? $w2Is that true?$K
$d0$s0$FS$c0GREIL|$s0If you could tell the difference,$w3
that means $w2you're improving.$K $R�w�i�Ȃ���b|$F0$FS$F0$FCL_GREIL|$F3$FS$F3$FCL_MIST|$F4$FCL_IKE|$F1$FS$F1$FCL_BOLE|$F1$PYou know, $w2I wasn't really giving
it my all either$MC...$MD$K
$F3$PThat is such a lie.$K
$F1$PBah.$K
$F4$PSo, Father, $w2does that mean$w2 you finally
admit that I'm ready?$K
$F0$PWhat, to join the company? To take on a job?$K
$F4$PYeah.$w4 I mean, Boyd's already out there
on the battlefield.$w4 I'm ready.$w2
I'm tired of being a trainee.$K
$F1$PListen, $w2the difference between you
and me$w2 is that I'm a professional.$K
$F3$PA professional who just got beat.$K
$F1$PThat was just random chance.$w4
Ran$w2dom $w2chance.$K
$F0$PYou've got a point, Ike$MC...$MD$w3 All right.$w4
Tomorrow will be your first day as a
full-fledged mercenary.$K
$F4$P$FSReally?$K
$F0$PBut! If I think it's too much,$w2 you're back to
trainee status.$w4 You'd better work hard.$K
$F4$PNo problem.$w4 Watch$MC--$MD$w2I'll catch up to
everyone in no time.$K
$F0$PWe'll see.$w5
We'd better be heading back to the
fort.$w3 Everyone's waiting.$K
$=1000     h      x     �     D   -  �   6  �   D  |   P  �   \     k  H   z  �   �  	   �  
X   �  
�   �     �  �   �  @   �  �   �     �  |    �    ,  .  �  =  �  L      [   `  g  `  s  �  �  �  �MDIE_BOLE_MAP1 MDIE_GREIL_MAP1 MDIE_IKE_MAP1 MS_01_BT MS_01_BT_BOlE MS_01_ED_01 MS_01_ED_02 MS_01_EV_01_01 MS_01_EV_01_02 MS_01_EV_01_03 MS_01_EV_02 MS_01_EV_03_01 MS_01_EV_03_02 MS_01_EV_03_03 MS_01_EV_03_04 MS_01_EV_04 MS_01_EV_05 MS_01_EV_07_01_01 MS_01_EV_07_01_02 MS_01_EV_07_01_03 MS_01_EV_07_02 MS_01_EV_07_03 MS_01_EV_08_01 MS_01_EV_08_02 MS_01_OP_01 MS_01_OP_02 MS_01_OP_03_01 MS_01_OP_03_02 MS_01_OP_04 