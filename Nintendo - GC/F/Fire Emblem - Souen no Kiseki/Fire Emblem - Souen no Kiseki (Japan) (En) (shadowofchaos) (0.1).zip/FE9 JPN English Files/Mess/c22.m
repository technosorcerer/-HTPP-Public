  p�  m�       &                $RGMAP��b|$O3$GDuring the battle for Talrega,$w3
Ike and the rest of his company
come to a bleak realization.$K$PWherever the Crimean army marches,$w3
the land becomes a battlefield.$w4
The damage is immense.$K$PWarfare and floodwaters claim homes,$w3
crops,$w3 and hope.$w4 Villagers seeking shelter
and safety stumble blindly through the snow.$K$PTo them,$w3 there is no doubt $w2that the
Crimeans are an invasion force.$K$P$Ub$HHowever,$w3 the Crimeans have their
own homeland to save.$K$PFocused as they are on that overriding goal,$w2
they cannot stop even to help the$w3
innocent victims of war.$K$PThe only way they can help the people
of Daein is to keep marching.$K$P$Ub$HThe faster they reach Daein's capital
of Nevassa$w3 and put an end to the
war, the better for everyone.$K $R�w�i��b|$B���-����-�f�C��|$<$F1$FCL_KASATAI|$F4$FCL_DAYNE2|$F1$PWhat?$w4 Are you telling me that His Majesty$w2
has not yet returned?$K$P$F4$PYes, sir!$w3 We've sent many messengers,$w2
but we have yet to receive any sort of
official response.$K$P$F1$PThe Crimean army $w2is on our doorstep...$w4
What is His Highness thinking?$K$PIf we want to protect the capital,$w3 we need
a leader equal to one of the Four Riders.$w4
Just in case...$K$P$F4$FD$F4$FCL_ENA|$F4$PI'm sure the king has considered this.$K
$F1$PLady Ena!$w4 I don't understand how you're
able to remain so calm!$K
$F4$PDaein soldiers $w2are the most elite warriors
on the continent.$K$PIn addition, our numbers are far superior
to the Crimeans.$K
$F1$PAnd, $w2and yet they march on Nevassa!$K
This is the Daein capital!$w4 If there's any
danger of it falling into enemy hands, we
can let nothing stop us from protecting it!$K$PNo offense,$w3 Lady Ena,$w2 but as a general,
I do not feel you're ready for
such a vital command.$K
$F4$PI...$w3I think you are exactly right.$K
$F1$PTh-then...$w4 When this command was given
to you, $w2why did you not firmly refuse?$K
$F4$PDo you really think that wise, General?$w4
Would you refuse a direct order$w2
from the king?$K
$F1$PUm...$K
$F4$P...$w4
Let me tell you something
that $w2I've discovered.$K$PIf we are...unable to hold the capital,$w2
I do not believe $w2the king will be
all that upset.$K$PAshnard does not hold a strong attachment$w4
to the country of Daein.$K
$F1$PWhat are you talking about?$w5 Do you...$w3
Do you understand exactly what it is
you are saying?$K
$F4$PYes.$K
$F1$PRidiculous!$w4 There isn't a monarch in the
world $w2who would not be moved by
the loss of his own country!$K$PSuch a preposterous notion is beyond
comprehension!$K
$F4$PGeneral Kasatai.$w4 Do not avert your
eyes from reality.$K
$F1$PReality?$w4 Ha! $w2What reality is that?$w5
All I see is your $w2guesswork.$K
$F4$PThen tell me...$w2why did the king suddenly
order the invasion of Crimea?$K
$F1$PAs...$w2as...$w3sanctions for that nation choosing
to ally itself with those evil and treacherous
sub-humans.$K
$F4$POn the surface, that would seem to be so.$K
But doesn't the action strike you as odd?$w4
To apply sanctions properly, $w2it would be
necessary to speak with Begnion first.$K$PBegnion is the suzerain state, and Crimea
answers to her. We needed Begnion's leave
to make a formal declaration of war.$K$PDaein's disregard for that process made
us a pariah in the eyes of our neighbors,$w3
and opened us to attack from all sides.$K$PAnd yet, not only did the king not do this,$w2
but he chose to invade without warning.$w4
It was the worst possible strategy.$K$PFurthermore, once the king conquered
Crimea through strength of arms,$w4
he seized the castle and set up residence.$K$PAnd now$w3 he uses it as a stepping stone
for an invasion of Gallia.$K$PWhich means, the king's goal $w2was never to
apply sanctions, or even to defeat Crimea.$K$PIf Ashnard moves against Gallia, $w2it's easy to
envision Phoenicis, $w2Kilvas, $w2and Goldoa
joining the conflict.$K$PAnd if that happens,$w3 Begnion would be
forced to ally itself with Daein rather than
side with the sub-humans.$K$PLook where that leads us...$w4
A continent embroiled in war.$w4
Is that not$w3 the true desire of the king?$K
$F1$PIf...$w2 If you consider it in that way,$w2
your words do begin to make sense.$K$PYet...$w2to accomplish that,$w3 the citizens
of Crimea would have to be sacrificed.$w4
That would be $w2an act of madness!$K
$F4$PLet's return to the topic at hand.$K$PThe king has gained himself a new castle,
and I believe he$w3 considers whatever
land he occupies to be his kingdom.$K$PDaein and its people$w3 are already behind
him.$w3 He need not look back.$K
$F1$PPah! If the king wished to rule the world,
he would want as much military strength
as possible!$K$PTo forsake even a portion of the strength
he currently possesses willingly, why,
it would be $w2sheer folly...$K
$F4$PThat doesn't matter. What's important $w2is
that we recognize the chance$w2
which Daein has been given.$K$PWe must stop the Crimeans here.$w4
If we do not show the king our value,$w5
we are doomed.$w4 Make no mistake about it.$K
$F1$PThis is complete lunacy...$K
$F4$PWe will receive no reinforcements.$w4
We must hold nothing back.$w4
It is our only chance of survival.$K
$F1$PThis...$w2I cannot...$w4 Why is this--$K
$F4$PBe strong.$w4 The king has provided us,
and the capital, with one final measure.$K$PWe will use it$w3 to weather this storm.$K$PHowever, to use it,$w4 I need you, General
Kasatai. Your cooperation is imperative.$w4
If you want to win, $w2you must trust me.$K
$F1$P$MC...$MDUnderstood.$w4 In this time, let us cling to
any hope we can find. Lady...$w2 No...$w3
General Ena,$w4 I place my trust in you.$K
$=1100 $R�w�i��b|$B�V��-��-3|$<$F1$FCL_IKE2|$F1$PSo this is the Daein capital, eh?
If we can just defeat King Ashnard,
this war will be over.$K
$F4$FCL_NASIR|$F4$PIke... $w2Here you are.$K
$F1$PWhat is it, $w2Nasir?$K
$F4$PAre you sure that you have enough
soldiers to lay siege to the capital?$K$PYour opponent is called "Mad King Ashnard,"
after all.$w3 Who knows what sort
of traps he has in store for you?$K
$F3$FCL_TIAMAT|$F3$PHe may indeed have something planned.$w4
Surely they've received reports of our
advancement.$w4 Yet it's so quiet...$K
$F0$FCL_SENERIO|$F0$PIt looks like every able-bodied man has been
conscripted into the army, while women
and children$w4 have evacuated the area.$K
$F1$PWe're not invaders.$w4 We wouldn't lay a
hand on the citizenry...$K
$F0$PThere's no way $w2for them to know that.
They do know $w2what their army did to the
people of Crimea, however.$K$PIf they fear they will be punished for that,
I'm sure they decided to err on the side
of caution.$K
$F4$FD$Ub$H$F4$FCL_ERINCIA|$F4$PWhat?$w2 What happened to the Crimean
people? Surely only the soldiers were
imprisoned or killed...$K
$F0$P...$w4You truly have no idea how to rule
a nation.$w4 Do you know what happens
to a country that loses a war?$K$PEverything is destroyed. Homes, $w2land,$w2
crops...everything.$w4 And the citizens...$w4
They're not even treated as human.$K$PCrimeans,$w4 especially those near the capital
where Daein's presence is strongest,$w3 are
treated worse than sub-hum...than laguz.$K$P$F4$PThat's...$w4 Why would they...$w4
That's horrible...$K
$F0$PThe people understand this, $w2which is why
they pay for protection$w3 in the form
of taxes.$K$PFor the royals and nobles who are charged
with protecting the people, $w2there is no
greater sin than to be defeated in war.$K$PIt is the ultimate betrayal of the people's
trust.$K
$F4$P$FcSniff...$w4 Ah, by the goddess, I am a fool...$w4
...Sniff...$K
$F1$PSoren!$w4 Enough!$K
$F0$P...$K
$F3$PPrincess,$w4 be that as it may, $w2the majority
of people want to see the royal family
restored to power.$K$PThey believe $w2that you will help them
reclaim their old lives and restore peace.$K
$F1$PNow it's time for us to throw down Ashnard
and drive his army from Crimean soil.$K$PYou're the only one who can do that.$w4
Do you understand?$K
$F4$P$FdYes...$w2yes, I do.$K$PI...$w3 I will save the people of Crimea.$w4
This I swear.$K
$Ub$H$F4$FD$Ub$H$F4$FCL_NASIR|$F1$PAs I've said before,$w4 I won't be turned away.$w4
If there are traps, we just fight our way
through.$w5 This war ends here!$K
$F3$PYes! $w2I'm with you all the way!$K
$F0$P$FSI hope it all goes as planned.
$FAI will do my best to make it so.$K
$F4$P$Fc...$K    $R�w�i��b|$B���-��|$<$F0$FCL_BEGNION2|$F3$FCL_IKE2|$F0$PGeneral Ike!$w4 Sir, the castle gates are open!$K
$F3$PThat's not good.$w4 What are they planning?$K
$F0$FD$F4$FCL_ERINCIA|$F4$PIt must be a trap.$K
$F1$FCL_SENERIO|$F1$PThis is unexpected.$w2 Making us lay siege
would be far and away to their advantage.$w4
I have no idea what they're playing at.$K
$F0$FCL_TIAMAT|$F0$PEven so, $w2we will not back down.$w4
Right, Ike?$K
$F3$PRight. $w2If we can't tell what they're planning,
it matters not how we proceed.$w4
Let's just fight as we go.$K$PMove out!$w4 Keep your guard up, everyone!$K
$=1000    $R�㉺��b|$c3DAYNE2|$s3Enemy troops have entered
the castle!$K$d3
$c1KASATAI|$s1They're moving already?$K$PSuch recklessness!$w3
Don't they suspect a trap?$w5
I can't believe they've fallen for it.$K
$c0ENA|$s0Crimea follows a general named Ike.
Perhaps he follows no procedure.$w2
Perhaps he relies solely on instinct.$K
$s1I don't know if he's brave $w2or merely
reckless.$w4 It's unbelievable...$K
$s0Regardless, we continue as planned.$K$PClose the gate and seal off their
escape route.$w4 This contest will be
decided here.$K
$s1N-now then,$w4 it's time for the final
measure you spoke of earlier.$w2 Will you
show us what His Majesty left for us?$K$PWhat could possibly allow us to
destroy an army in one fell swoop...$w3
provided we can herd them here?$K
$s0General Kasatai...$K
No matter what I show you,$w2 do not
be shocked. You must continue to
trust me without question.$K
$s1I swear it. $w5On my name as a royal
knight of Daein,$w3 I will not betray
you,$w2 General Ena.$K
$s0Thank you...$K$Fc$P...$K$d0   $R�㉺��b|$c1KASATAI|$s1Ge-$w2General Ena! $w5You're...$K
$s0$Fc$c0ENA|$s0...$K
$s1$FcAaaaaaah!$K
$s0$FdGeneral Kasatai!$w4 Have you forgotten$w2
your vow? No matter what happens,$w3
we will protect the capital, $w2yes?$K
$Ub$H$s1$FdAh... Ah...$w3 Yes,$w4 of course...$w5
I...$w2understand.$w3 This is His Majesty's--$w2
Why he left you here...$K
$s0$FcYes.$K$d0
$s1We will win this battle! $w5A legendary
dragon of Goldoa is on our side!$w3 It is
a powerful omen!$w4 Daein cannot lose!$K$PThe Daein army is indestructible!$w4
We will crush the dogs of Crimea and
use their skulls as goblets!$K$d1
$c3DAYNE1|$s3Glory to Daein!$K
$c1DAYNE2|$s1Victory $w2to Daein!$Ub$H$K  $R�w�i��b|$B���-��|$<$F0$FCL_BEGNION1|$F0$PSir!$w4 The gates have just closed behind us!
Look out!$K$F0$FD
$F4$FCL_BEGNION2|$F4$PWe're trapped in this castle!
Run! Ruuuun!$K$F4$FD
$F1$FCL_BEGNION1|$F1$PAttack!$w3 We're under attack!
They're going to kill us!$K$F1$FD$w6
$F1$FCL_IKE2|$F1$PStop, all of you! Get ahold of yourselves!$w4
You must not panic! No one has attacked!$K
$F3$FCL_TIAMAT|$F3$PIke!$K
$F1$PTitania!$w4 Where is Princess Elincia?$K
$F3$PShe's fine.$w4 She's with the supply convoy.$w4
They're all under very close guard.$K
$F1$PSoren,$w3 is this the enemy trap?$K
$F4$FCL_SENERIO|$F4$P...$w2It could be...$K
$F3$PIf so, $w2to what end?$K
$F4$PWell, the goal obviously isn't to divide our
troops$w3 and reduce our fighting strength.
We're all packed in here together.$K$PWhatever they are planning, $w2it appears
that they$w3 want us all to experience it
at the same time.$K
$F3$PDaein must have something $w2which they
believe gives them an insurmountable
advantage. Some kind of ultimate weapon.$K
$F1$PSo they're$w2 absolutely sure they'll
win, is that it?$w4 King Ashnard of Daein...$w4
You'll regret underestimating us.$w2$K
$F4$PNo matter what, $w2we must be cautious.$K$PWe can spare no efforts to protect the
princess.$w4 We should put together an elite
team$w4 and head for the throne room.$K
Choose the members of this team with care.$w2
Everything will rest on their shoulders.$K
$F1$PUnderstood.$K    $R�㉺��b|$c1IKE2|$s1Ashnard!$w3 Show yourself!$K
$s0$Fc$c0ENA|$s0...$K
$s1Huh? $w5A Goldoan dragon?$K
$s0$FdI've been waiting for you.$w4
You are General Ike, are you not?$K
$s1How did...$w4 Who are you?$K
$s0My name is Ena.$w4 By the orders of
the king, $w2I am the protector of
this capital.$K
$s1Withdraw.$w4 I've no desire to fight
a useless battle with you.$w2
It's Ashnard I'm after.$K
$s0I regret to inform you $w2that the king
is not here.$K
$s1What?$K
$s0The king and the main body of the
Daein army $w2remain in Crimea,$w3
where they have been since it fell.$K
$s1What are you saying?$w4 The king's
abandoned the capital?$K
$s0...$w3I share your desire to see this
conflict end.$w2 So rather than see you
travel to Crimea to fight Ashnard,$K$PI felt it would be much faster for me
to defeat you and your army here.
Don't you agree?$K
$s1That's $w2one way to look at it.
The problem is that I'll never let you
do as you please with Crimea!$K
$s0We cannot have it both ways.$w4 We
both want what is in our own interest,$w2
and that is why we have conflict.$K$PIf neither one of us will yield,$w3 our
conflict will continue until only the
stronger of us remains.$K$PI have my own reasons for fighting...$w3
And I will see you fall.$K
$s1Hi-yaaaah!$K  $R�㉺��b|$c0KASATAI|$s0For us there is no tomorrow.$w4
We cannot be beaten,
nor can we withdraw!$K$PWe must defeat the Crimean army$w2
and bring His Majesty back to us.$K    $R�㉺��b|$c0KASATAI|$s0Sir Tauroneo!$w4 I can't believe that you
would...$w2betray Daein.$K
$c1TAURONEO|$s1...$w2Forgive me...$K
$s0You...$w2fool!$K  $R�㉺��b|$c0KASATAI|$s0I cannot...$w2stop your march...$K
But...$w3we are not yet $w2defeated...$w4
General...$w2Ena...$Fc$w5
Protect...$w2the...$w2capital...$K  $R�㉺��b|$c0IKE2|$s0Hyaaaa! Take this!$w4 ...What is it?$w4
Why are you staring at me like that?$K
$c1TAURONEO|$s1I am Tauroneo,$w4 a general of Daein.
Young general of Crimea, $w2I have
but one question to ask you.$K$PYour swordsmanship is familiar... Who
taught you to fight in this way?$K
To the best of my knowledge, $w2that
style was used by only one man--$w2
an old friend of mine.$K
$s0My father. He taught me to use a sword.$K
$s1$FSIs that so?$w4 Then you are
Gawain's son...$K
$s0Wait!$w4 Are you a friend $w2of
my father's?$K
$s1We were good friends...long ago.$w4
How is the old goat?$K
$s0...My father $w2no longer lives.$w4
He was defeated and slain by a
Daein general.$K
$s1$FAThat can't be!$w4 For the Gawain I knew
to be beaten...$w4 Who was it?
Who took him down?$K
$s0A knight encased $w2in black armor.$K
$s1The Black Knight, eh?$w4
I did not know his strength had
grown so much...$w4 Interesting.$K
$s0...$K
$s1Do you have any brothers or sisters?$K
$s0I have one sister.$K
$s1In that case, $w2I will not fight you.$K
The world must not lose Gawain's
style of swordsmanship.$K$PI surrender.$w4 You may lock
me away $w2or execute me$w3
or what you will. I care not.$K
$s0Are you sane?$K
$s1Very much so.$w4 I had already decided$w2
that I would die in this place.$K$PI have served this country for
many years--$w2since the time
of the previous king.$K$PBut the current regent... $w2He rules
through fear $w2and wants nothing
but war.$w4 I can abide it no longer.$K
$s0If you plan on dying anyway, join us.$w4
We have need of strength
such as yours.$K
$s1You would take a former Daein general?$w2
I cannot.$w4 Your fellow Crimeans would
resist. They would never accept it.$K
$s0Our army $w2does not have the luxury
of being so picky. Please...$w4
Lend us your strength.$K
$s1...As you will.$FS I've already thrown my
life away.$w4 If it can serve you somehow,$w2
you may use it as you see fit.$K    $R�㉺��b|$c0TAURONEO|$s0Ah ha ha!$w4 I will cut you down
with ease $w2and leave your corpse
for the rats!$K   $R�㉺��b|$c0TAURONEO|$s0What's the world coming to?$w4
Why is it children such as you$w2
must be thrown into battle?$K    $R�㉺��b|$c0TAURONEO|$s0Combat...was my life...$w3
Now...it is...$w2my death...
Ah, how fitting...$K  $R�㉺��b|$c0ENA|$s0If you had wished to extend your
short life span, $w2then you should
not have appeared before me.$K    $R�㉺��b|$c0IKE2|$s0Why is a Goldoan dragon$w4 in the
service of King Daein?$K
$c1ENA|$s1...I...$w3 I merely want to be near
the one I love...$K$PHe is...$w2my everything. That is why
I must defeat you, or...$w3I...$w2I...$K  $R�㉺��b|$c0ENA|$s0Beast-tribe cousin,$w4 I will warn you
but once.$w4 Change your shape and
flee from this place.$K$PNot even you $w2can defeat a dragon.$K  $R�㉺��b|$c0ENA|$s0Bird brother of Phoenicis...$K$PYou $w2know the power of the
dragon tribes.$w4 Do you still think
to challenge me?$K   $R�㉺��b|$c0ENA|$s0Prince of Serenes...$w4
You have no reason to be here.$w3
Do you wish to perish in this place?$K   $R�㉺��b|$c0MIST|$s0Y-you...$w3 You're one of the dragon
tribe, aren't you?$K$PWhen we ran into trouble in the
southern sea, the dragon prince$w2
rescued us!$K$PI don't want to fight you!$w3
D-do I...$w2have to?$K
$c1ENA|$s1You have met Prince Kurthnaga?
I've no desire to steal the life of
one who received his aid.$K
$s0$FSWhoo-hooo!$K
$s1Ah, forgive me, little one.$w5 For even
so... $w2I cannot quit fighting.$K   $R�㉺��b|$c0ENA|$s0...$K  $R�w�i��b|$B���{-�f�C��|$<$F1$FCL_ENA|$F1$PYou are $w2strong.$w4 I have lost.$K
$F3$FCL_IKE2|$F3$PThen calm yourself and surrender.$w4
There's no reason for you to die.$K
$F1$PThat$w4 I cannot do.$K
$F3$PWhat?$K
$F1$PI...$w4 I must go to him...$K$F1$FD
$F3$PNo!$w4 Wait!$K   $R�㉺��b|$c0IKE2|$s0Nasir!$w4 Good timing. $w2Grab her,
will you?$K
$c1NASIR|$s1...$K $R�㉺��b|$c1NASIR|$s1I'm sorry.$K
$c0IKE2|$s0Nasir?$K $R�㉺��b|$c0IKE2|$s0Urgh!$K   $R�㉺��b|$c1SENERIO|$s1Ike!$K
$c3TIAMAT|$s3Nasir!$w4 What are you doing?$K    $R�㉺��b|$c1NASIR|$s1Go now. Hurry!$K
$c0ENA|$s0...$K$d0  $=0800$R�w�i��b|$B���{-�f�C��|$<$F1$Fc$F1$FCL_NASIR|$F3$FCL_IKE2|$F3$PSo you were the traitor?$K
$F1$P...$K
$F3$PSomeone's been giving information to
the enemy.$w4 Was that you, too?$w4
And...$w4Mist's medallion?$K
$F1$P...$K
$F3$PAre you telling me you've been working
for Daein this whole time?$w4 But you're
a laguz!$w4 Why?$K
Talk to me!$w6 Ah, this is useless.
Get him out of here!$w3 His traitorous
face is making me ill!$K$P$F1$P...$K
$F3$PBlast!$K
$F1$P...$K
$F3$PUntil this has been cleared up,$w2
you'll be held in custody.$K
$F0$FCL_BEGNION2|$w5$F3$PI won't question you anymore.
When you decide to talk, let me know.$K
$F1$P...$K$F0$FD$F1$FD
$F3$P...$K   $R�㉺��b|$s0$Fc$c0NASIR|$s0...Go to Palmeni Temple.$K $R�㉺��b|$c0IKE2|$s0What did you say?$K
$s1$Fc$c1NASIR|$s1...$K
$s0...$K
$=1200   $R�w�i��b|$B���{-�N���~�A|$<$F1$FS$F1$FCL_ASHNARD|$F4$FCL_PRAGUE|$F1$PSo the capital's fallen, eh? Ha!$w4
I knew it would come to this!$w2
Still...how disappointing.$K$PIt doesn't matter how well you train an
army--$w2if they don't fight,
they become weak.$K$PWhat's the life of a soldier without a
steady diet of war?$w3 Blood and pain are
the foods of a true warrior!$K
$F4$PSuh-$w2speaking of soldiers, Your Highness...$w4
The majority of our forces have been
moved here--$K
$F1$PI left more than enough soldiers!$w4
And yet they could not prevail...$w4
I may have overestimated Ena.$K$PEven if she is a dragon, $w2I suppose
that was the best she could do.$K
$F4$PI suppose...$K
$F1$PBut the important thing is the Black Knight.$w4
Where's he gotten to?$w4 Did you see
him in the capital?$K
$F4$PI did.$w4 He bid me present this to$w2
Your Majesty...$K
$F1$PAh! It's found its way back to my hands
at long last.$w4 Unwrap it!$w2 Quickly!$w2
Unwrap it and show it to me...$K
$F4$PV-very$w4 well--$K
$F1$PDo be careful not to touch it, Petrine.
It wouldn't do to have you go mad...$w4
I'd hate to have to kill you! Aha ha ha!$K
$F4$PH-here it is, Y-Your Majesty...$K
$F1$PBehold...$w4 Ah, how wonderful!$w4
See how it reacts to the war I have
brought to this pathetic land?$K
$F4$PTh-$w2this is $w2Lehran's Medallion?$K
$F1$PYes.$w4 And inside...$w2inside is a dark god
of immeasurable power and cruelty.$K$PIt once caused a flood so great that all
continents save Tellius were submerged
in a watery tomb.$K
$F4$PThat...blue light...$K
$F1$PYou...$w2 Me...$w2 Even this very castle itself...$w4
We all radiate various forms of chaotic
energy, and the dark god is pure chaos!$K$PThe light you see is that energy calling out
to the chaos around us. That is why some
scholars refer to it as the Fire Emblem.$K
$F4$P...$K
$F1$PHeee! Heee har har!$w4 Look how you tremble!$w4
This light has the power to bewitch
the human soul, you know?$K$PIt calls to our chaotic impulses--$w2like the
urge to slaughter every living thing
in sight...$K$PDo you feel its invitation?$w4 The permission
to act on any base emotion that resides in
your heart, no matter how unspeakable?$K
$F4$PI... $w2My report...$w4is not...$w4
finished...$K
$F1$PHeee har har! Ah, Petrine...$w4
Guard!$K$P$F0$FCL_DAYNE3|$F0$PYes, Your Highness?$K
$F1$PWrap the medallion $w2and place it in
the vault.$K
$F0$PAt once!$K$F0$FD
$F1$P...Go on.$w3 The report?$K
$F4$PO-of course... Yes...$K$PAs Your Majesty ordered, the Black Knight$w2
moves to capture Princess Serenes. At last
report, he was on his way to Phoenicis.$K
$F1$PI see. $w2So he's decided on the princess
and not the prince, eh? Did he give any
reasons?$K
$F4$PYes, Your Highness.$w4 It was based on the
findings of a group of scholars.$K$PBecause the princess was isolated for over
twenty years, they feel her magic will be
stronger than her brother's.$K
$F1$PYet...$w4 Can the Black Knight outwit the
hawk king of Phoenicis and steal her away?$K
$F4$PThe hawk king $w2is not always at her side.
Plus, as you know, $w2the Black Knight is in
possession of warp powder.$K$PIf someone of his might $w2has the ability
to appear and disappear at will,$w4 it may
be that he is without equal...$K$PW-with the exception of Your Majesty,
of course!! I... I mean...$K
$F1$PHa ha.$w4 I will have to test that someday...
But not today.$w3 It's not often that one
finds a tool as useful as he is.$K
$F4$PWell spoken, Your Majesty.$K
$F1$PNow then, $w2Petrine.$w4 My dear Petrine...
You have made one blunder after another.
How will you prove your worth to me...?$K$PIf you wish to remain in my service,$w2
you must show me results.$K$PUnless you, too, $w2wish to become food
for Rajaion here?$Ub$H$K
$Ub$H$F4$PY-Your Majesty! I will redouble my efforts!
I won't... I won't let you down again!$K
$F1$PYou can be a general or you can be dinner.
I don't really care which...$w4 But do try
to show a little initiative, won't you?$K
$F4$PYes, Your Highness...$w4 B-$w2by your leave...$K
$F1$PHold. I forgot one thing.$w4 What happened to
Ena when the capital fell?$K
$F4$PAccording to all reports, $w2she escaped.$w4
Her current location is unknown. However...$w4
This is Ena we're speaking of.$K$PShe will return to Your Majesty,
will she not?$K$P$F1$PKill her.$K
$F4$PWhat?$K
$F1$PI've no further use for her.$w4 Oh, but if
it's too much for you to kill her outright...
Use her trust and stab her in the back.$K
$F4$PAs...$w2as you wish...$K
$=1500 $=0500$R�w�i��b|$B����-��|$<$F0$FCL_IKE|$F3$FCL_JILL|$F3$PUm, $w2General?$w4$Fc Thank you.$K
$F0$PHm?$K
$F3$P$FdThe people of Talrega were the enemy,
yet you treated them with kindness.$w4
I don't know how to thank you.$K
$F0$POh, the provisions? It wasn't enough,$w3
but I wanted to do whatever I could.$w4
It's nothing for you to worry about, though.$K
$F3$PGeneral Ike...$K
$F8$FCDUMMY|$F8$PMy, $w2my lady!$w4 Is that you?
Lady Fizzart?$K$F8$FD
$F3$PHuh?$K
$F3$FD$F1$FCL_JILL|$F3$FCL_WOMAN1|$F3$P$FSOh, $w2it is you!$w4 Lord Shiharam's lovely
daughter!$w4 Thank heavens you're still alive!$K
$F1$PYou're...$w3from Talrega.$K
$F3$PThat's right.$K$PI'm Sophie, $w2from the village of Luma!$w4
I can't live there anymore,$w4 so I brought
my two sisters $w2here to the capital.$K$PAfter that battle,$w4 I was sure that you'd
been claimed by the Dark Angel, just
like Lord Shiharam.$w3 But here you are!$K
$F1$P...$K
$F0$P...$K
$F3$PIs this$w3 your bodyguard? Ooo, so strong!$w4
You watch out for milady, $w2you hear?
She's Lord Shiharam's precious little girl!$K$PYou keep an eye on her,$w2 and don't let
those nasty Crimeans get near her!$K
$F0$PUm...$K
$F1$PActually...$w4 We're...$K
$F3$P$FAPlease listen to me, $w2milady!$w4
We understand all about those floodgates!$K$PLord Shiharam would've never done such a
thing if he had any other choice! We know
it was those Crimeans that did it!$K$PWhy, when he wasn't on duty,$w3 Lord
Shiharam and his men used to help us
with the plowing and the planting.$K$PAnd once when my sister got sick,$w3 he
loaded her up onto his own wyvern$w3 and
brought her to the capital to see a doctor.$K$PHe's the only one$w3 who ever cared about
us country folk. $w2He opened his heart to
each and every one of us.$K
$F1$PHe... He was a good man...$K
$F3$P$FoThose dirty Crimeans are to blame!$K
If they'd never come to Daein,$w3 that
battle wouldn't have happened.$w4$Fc
And Lord Shiharam $w2would still be with us.$K$Fd$P$F4$FCL_GIRL|$F4$PSister...$w4 I'm hungry...$K
$F3$FD$F6$FCL_WOMAN1|$F6$P$FSYou're going to be all right.
I'll find you something to eat in a little
while.$w2 Just be patient.$K
$F4$PThat soldier over there gave me this.$w4
Can I eat it?$K
$F6$P$FADon't be stupid!$w4 Throw that away
right now! We'll starve to death before we
take charity from Crimean killers!$K
$F4$P$FcWaaaaaa...$w3
Waaaaaaaaaaaa!$K$P$F4$FD$F6$FD$F3$FCL_WOMAN1|$F3$PMilady! The Crimean army is nearby! Run!$K$PYou must escape and survive.$w5
We're gonna live.$w3 Even if we have to eat
mud $w2and weeds,$w3 we'll do it.$K$PAnd one day$w4 we'll have our revenge$w2
on those bloodthirsty Crimeans.$K$PIf I can't do it, $w2my children will...$w4
And if they can't, $w2then my grandchildren
will!$w4 We'll get them someday! I swear it!$K$P$FSI have to go.$w3 Promise me, milady.$w5 You must
go on for Lord Shiharam's sake.$w4
You mustn't get yourself killed!$K$P$F3$FD$F1$PUm...$K
$F0$P...$K
$F1$P$Fh...$w5
S-$Fc$w1sorry.$w4
...Oh, I'm so sorry...$K
$F0$PDon't be...$K
$=1000 $=0500$R�w�i��b|$B�V��-��-3|$<$F1$FCL_IKE2|$F1$PMist.$K
$F3$FCL_MISTs|$F3$P...Ike.$K
$F1$P...$w5
Are you all right?$K
$F3$P...We've come a long way, haven't we?
Do you think we can beat King Ashnard?$K
$F1$POf course we can! We have to.$w3
If we lose, Crimea may never be rebuilt.$K
$F3$P...$w5What are we going to do, $w2Brother?$w4
I'm...$w3frightened...$K$PThe medallion was my protection.$w3
Now that it's gone,$w4 my confidence has
vanished.$K
$F1$PMist...$K
$F3$PFor as long as I can remember, $w2I would
talk to the medallion$w3 like I was talking to
Mother.$K$PAfter Father $w2died,$w4 I felt like I was
talking to them both...$Fh
Where could it have gone?$K
$F1$P$FSWe'll find it.$w4 And even though it's gone,$w3
Father $w2and Mother$w4 are looking down
on us and protecting us.$K
$F3$P$Fd...$w4 $FSYou're right...$w3 I'm sorry.$K$PFather$w3 and Mother are in my heart,$w5
and $w2I've got you$w2 and everyone else
at my side.$K$PSo $w2even without the medallion,$w3 I'm all right.$Fc
Everything's $w2going to turn out fine.$w5$Fd
I know it.$K
$F1$PThat's the spirit.$K
$F4$FCL_NASIR|$F4$PIke, $w2Mist,$w4 if you're going to chat,$w3
why not go inside?$w3 Even if the snows are
beginning to melt,$w3 it's still cold out here.$K
$F3$FD$F0$FCL_MIST|$F0$POh, $w2hi, Nasir.$K
$F1$PYou're right. $w2I do feel a bit cold.$w4
Shall we go back to the tent?$K
$F0$P$FSUh-huh!$w4 Let's go, $w2Ike!$w3
You, too, Nasir!$K$F0$FD$F1$FD
$F4$P...$w5$Fc
Forgive me.$K
$F0$FS$F0$FCL_MIST|$F0$PNasir? $w2What's wrong?$w4
Hurry up!$K
$F4$P$FdOh... $w2Of course.$K$P$F0$FD$w4$F4$P$Fc...$K
$=1000    $R�w�i��b|$B�V��-��-3|$<$F1$FCL_SENERIO|$F3$FCL_IKE|$F1$PIke,$w3 I'd like to report the results
of our last battle.$K$N$UB$H   $F3$P$FcI see.$K$P$UB$H $F1$P$FSThere were no deaths $w2and no injuries
beyond our capabilities to heal.$w4
Everyone performed exceedingly well.$K$P$UB$H   $F1$PThat is all.$w4 By your leave,$w2
I will excuse myself.$K    3�      4�     5      =D   (  =�   4  >0   F  5�   S  >�   c  ?   l  A�   y  ?�   �  @�   �  A$   �  C@   �  C\   �  Dp   �  D�   �  E    �  E    �  Ep   �  E�    HH    H�    H�  %  .�  1      =  Z<  K  e�  Y    g  �  v   \  �  "�  �  &�  �  )T  �  l$  �  l�  �  m@  �  l�  �MS_22_01_BT MS_22_01_BT_R3 MS_22_01_DIE MS_22_02_BT MS_22_02_BT_CHILD MS_22_02_DIE MS_22_02_TK_IKE MS_22_BT MS_22_BT_IKE MS_22_BT_MI MS_22_BT_R1 MS_22_BT_R2 MS_22_BT_RI MS_22_DIE MS_22_ED_01 MS_22_ED_02 MS_22_ED_02_2 MS_22_ED_03 MS_22_ED_03_2 MS_22_ED_03_3 MS_22_ED_04 MS_22_ED_05 MS_22_ED_06 MS_22_ED_07 MS_22_EV_XX MS_22_GMAP_01 MS_22_INFO_02 MS_22_INFO_04 MS_22_OP_01_00 MS_22_OP_02 MS_22_OP_03 MS_22_OP_04 MS_22_OP_04_1 MS_22_OP_05 MS_22_REPO_BEGIN MS_22_REPO_DIE MS_22_REPO_END MS_22_REPO_NODIE 