  ^  Z�       $                $R�w�i��b|$B���-��|$<$F4$FCL_ZELGIUS|$F1$FCL_IKE2|$F4$PIf that's the decision you've reached,$w4
we'll respectfully comply.$K
$F1$PIf we can march quickly and know that
someone's protecting our backs,$w3
it would be a huge relief.$K
$F4$PAs you wish.$w4 May the fortunes of war
be with the Crimean army.$K$PIf you have need of soldiers, $w2send word.$w4
We'll move out at top speed.$K
$F1$PI'll be counting on it.$K
$=0700    $RGMAP��b|$O3$GThe information gathered at Palmeni Temple
leads Ike ever closer to the hidden truths
behind the war.$K$PThe assassination of Begnion's former
apostle led to the massacre of Serenes.$K$PA Serenes princess was kidnapped.$w4
The medallion is stolen.$K$PA complex skein seemed to connect
these events, and now those threads
have become clearer and cleaner.$K$PAshnard's motives are still a mystery,$w4 but
his silhouette lurks in the shadows of
all that happens.$K$P$Ub$HIke returns from the temple$w3
$Ub$Hand renounces all rights to the rule of
Daein.$K$PThose rights are then passed through
General Zelgius of Begnion to the apostle
herself.$K$PThe Crimean army$w3 absorbs another troop
from Begnion,$w3 and with its might increased,
marches on the Daein/Crimean border.$K$PIts next goal is the Riven Bridge, a massive
structure that connects the two countries.$K $R�w�i��b|$B�V��-��|$<$F1$FCL_IKE2|$F3$FCL_ERINCIA|$F3$PMy lord Ike, $w2may I have a moment?$K
$F1$POf course.$w4 What is it?$K
$F3$PThe soldiers say $w2that tomorrow$w2
we'll be able to see the great bridge.$w4
Once we cross it,$w3 we'll be in Crimea.$K
$F1$PThat's what I've been told.$K
$F3$PIt feels like $w2I've been away for many years.$w3
Crimea is the land where I was born and
raised. $w6To feel so removed from it...$K$PI feel now, at this late juncture, that I know
almost nothing of my own country.
It is an unreal experience.$K
$F1$PI know what you mean. I don't have the
sense that we're on the brink of being
back in Crimea, either.$K
I don't even remember this area at all.$w4
Maybe it's because I was born in Gallia$w3
and raised in the countryside.$K$PBut countries are joined together like this
all over the continent.$w4 I'm really
in awe of it all.$K
$F3$P$FSSo am I!$w3 For one who knew nothing of life
outside the royal villa...$w4 Everything...$w2is...$w5
So$w3 very big.$K
$F1$PBig?$w4 Hmm...$w4 Yeah, I guess you're right.$K$PWhen we left Crimea,$w3 it was spring...$w4
The snows were melting,$w4 the days were
getting longer, $w2and the weather was mild.$K
$F3$P$FAIt's been almost a year since we departed.$K$POnly a year,$w3 but the distance we've traveled
to get here has been long and hard...$w5
It feels like many years have passed us by.$K$P$FcYet this is the land where I was born
and raised...$w4 Ah, my dear, sweet Crimea...$w5
How is it that you feel so far away?$K
$F1$P$FSFor me, too,$w4 Crimea is my homeland.
We're almost there... Let's go home.$K
$F3$P$Fd$FSIt is as you say, $w2my lord Ike.$w4
...Let's go home.$K
$Ub$H$F7$FCDUMMY|$F7$POooh, $w2what a romantic setting.$w4
Makes it hard to make an appearance!
I guess I could just leave you two...$K$F7$FD
$F1$FD$F4$FCL_IKE2|$F4$PHuh?$w4 I know that voice...$K
$F1$FS$F1$FCL_LAY|$F1$PHey there, $w2Ike!$w4 Looks like we stayed
alive long enough to be reunited!$w2
Aren't we the lucky ones?$K
$F4$P$FSRanulf!$K
$F3$PMy lord Ranulf!$w4 How nice to see you again!$K
$F1$PMy princess Elincia! $w2Welcome home!
I'd curtsy, but the tail makes it look silly.$K
$F4$PWhat are you so darned chipper about?$K
$F1$POnce I heard the news $w2that the Crimean
army had taken the Daein capital,$w4
I ran all this way to greet you.$K
$F4$P$FAHow go things in Gallia? $w5You're not
engaged in open hostilities with Daein,
are you?$K
$F1$P$FANot yet.$K
$Ub$H$F4$PWhat's that supposed to mean?$K
$F1$P$FSIn light of your army's success, the elders$w2
have finally agreed on something.$K$PGallia $w2will lend its full support to Princess
Crimea's efforts to liberate her homeland.$w4
It's a done deal!$K
$F3$P$FAReally?$K
$F4$PSo, $w2is the Gallian army going to--$K
$F1$PWe're going to establish communications
with them and create a united front.$K$PThat being said, $w2Gallia is here to support
you.$w4 The Crimean army will always be at
the center of the effort. $w2Don't forget that.$K
$F4$PKing Gallia $w2is being most gracious.$w4
That posture will allow Crimea to lay claim
to any victories we achieve.$K
$F1$P$FADon't say things like that!$w4 I'm shocked that
you would understand such subtleties.$w2 Who
are you, and what have you done with Ike?$K
$F4$PI don't believe you have the right to speak
to me like that.$K
$FSKidding. Actually, $w2Soren just lectured me
on the same situation when we received
reinforcements from Begnion.$K
$F1$P$FSOf course.$w4 You were tutored by your
nervous little staff officer. Now I get it...$w4
Has he snapped yet? He seems high-strung.$K
$F3$PKing Caineghis is always thinking of Crimea,
isn't he? How can I ever repay him?$K
$F1$PPrincess...$w4 Let's win your country back.$w5
When that's done, $w2please rebuild the bonds
of friendship between our nations.$K$PThat would be the ultimate way to say
thank you, wouldn't it?$K
$F3$P$FSYes! Yes, of course!$K    $R�w�i��b|$B���-��-��|$<$F1$FCL_PRAGUE|$F4$FCL_DAYNE3|$F1$PSo they're finally here, are they?$w4
Has the work on the bridge been finished?
And your answer had better be yes!$K
$F4$PY-yes, General!$w4 Do you think it will work?$K
$F1$PSometimes the simplest of traps$w2 offer up
the best results.$K$PLure the enemy in, $w2and then finish them
off one by one.$w4 Got it?$K
$F4$FD$F1$PListen up, dogs! $w2There will be no retreating
today! We stop Crimea's advance here!$K$PWe will not allow them to gain the comfort
of their homeland! Any who do not
fight to the death will face my lance!$K  $R�w�i��b|$B�R��-�C����|$<$F3$FCL_LAY|$F4$FCL_IKE2|$F4$PThere's the bridge... Wow, it's huge...$w4
I doubt if Daein's going to let us
cross over $w2without objection.$K
$F3$PYeah, $w2I think that's highly unlikely.$K
$F1$FCL_TIAMAT|$F4$PTitania!$w4 It's time to march!$w2
Make sure the troops stay alert and
move with caution!$K
$F1$PUnderstood, Commander!$K$F1$FD$F3$FD
$F1$FCL_LAY|$F1$PSay, $w2Ike.$w4 There's one thing$w2 I've been
meaning to ask you.$K
$F4$PWhat is it?$K
$F1$PI haven't seen Nasir around.$w4
What's happened to him?$K
$F4$PHe was declared an enemy combatant and
locked up.$K
$F1$PWhat? Hey, I understand you being irked
that he didn't$w2 mention testing you and all,$w2
but treating him like a criminal is too--$K
$F4$PTesting me? What are you talking about?$K
$F1$PHuh?$w4 Oh, um...$w4 Nice weather, eh?$K
$F4$PWe're going to talk. Now.$K
$=0800    $=0500$R�w�i��b|$B�R��-�C����|$<$F1$FCL_LAY|$F3$FCL_IKE2|$F1$PNasir is a Daein spy?$w4 No way!$w4
That's not possible! He was our spy!$K
$F3$PYou're telling me he was a Gallian spy?$w4
None of this makes sense to me...$K
$F1$PHe worked for us on behalf of the king.$w2
But...Daein? As a laguz, he would have
absolutely no reason to work for them.$K
$F3$PBut there was a Goldoan named Ena who
was working as a general for Daein.$K
$F1$P...$w4Are you serious?$K
$F3$PYes, we were forced to fight her in the
Daein capital.$K$PWhen we attempted to capture her,$w2
Nasir intervened and allowed her
to escape.$w4 He betrayed us.$K
$F1$P$FhWhat? $w5Hold on a minute...$K
$F1$FD$F5$Fc$F5$FCL_LAY|$F5$PMaybe that was... $w5If that's the case,$w2
then I can see why...$K$P$FhNo, $w2even so, $w2teaming up with Daein
is just too much...$w4$Fchmm......$K
$F3$PI hate to interrupt whatever it is you're
doing, $w2but we've arrived at the bridge.$K
$F5$FD$F1$FCL_LAY|$F1$PLet me speak to Nasir.$w4 Please!$K
$F3$POnce we've finished this battle,$w3
we can go together.$w4 All right?$K
$F1$POf course.$K   $=0700$R�w�i��b|$B�R��-�C����|$<$F1$FCL_PRAGUE|$F1$PAll right, Haar! Time for you to go to work.$K
$F4$Fc$F4$FCL_HAAR|$F4$PZzzzz$w2...$w2 No, Mom, five more minutes...
Zzzzzzzzzz...$K
$F1$PDozing off on the battlefield...$w3 You've got
a lot of nerve, don't you? $w5Hey!$w4
Wake up $w2or I'll burn you to a crisp!$K
$F4$P$FdZzzzz... Snort! Huh? Wha--? Uh... Right!
Has the enemy arrived?$K
$F1$PYes,$w3 they just got here. $w5Now get out there$w2
and do your job.$K
$F4$POh, I'm all over it. $w5$FcYaaaawwwnnn...$K$F4$FD
$F1$PWhat an absolute fool.$K $R�㉺��b|$s1$FS$c1LAY|$s1Well, here we are!$w4 And there's the
Daein army on the other side as
expected!$K$PThey're already in battle formation $w2and
waiting to give us a warm welcome.
Aw, that's charming!$K
$c0IKE2|$s0That's just what I want.$K
$s1Oh ho! Well said.$w4 And by the way,
I thought I'd join you today.$K
$s0Not as a Gallian, $w2but as part of our
army, right?$K
$s1$FAIf it's a problem, $w2I can always sit this
one out.$K
$s0$FSOf course not!$w4 Thanks for your
continued support, Ranulf!$K
$s1$FSHa! The pleasure's all mine! Let's go
carve us some Daeins!$K    $R�㉺��b|$c3LUCHINO|$s3Is that$w4 the Crimean army?$K
$c1ULYSSES|$s1What ho! It is the army come again!
I see the Crimean flag in the rear...
But lo! Who do I spy in the distance?$K$P$FSGreen hair...orange dress...
and eyes bewitching fair...$w4
Elincia comes! Let us to her aid ride!$K$d3
$c0LUCHINO|$s0$FSThe princess$w4 has returned!$w4
$FACount Bastian, $w2return to the castle
and inform Geoffrey at once.$K$PI will $w2move ahead and inform the
princess that her retainers are here
to meet her.$K
$s1$FALady Lucia, $w2keep your wits about you.
That we are excited is fair to say...$K$PBut show the enemy no weaknesses,
lest he does cut us down like
autumn's wheat.$K
$s0$FSGood advice.$w4 $FAAnd you watch that
you aren't waylaid$w2 on the way back to
the castle.$K
$s1$FSEven if Daein unleashes on myself
the full force of their army's wrath...
They are no match for clever Bastian!$K$PI'll meet you at the castle gate anon.$K
$s0$FSRight!$K   $R�㉺��b|$c0LUCHINO|$s0Are you ready to fight?!$w3 Are you
ready to die?! We must give our all
to protect Princess Elincia!$K
$d0$c0CRIMEA1|$s0My fellow Crimeans!$w4 Now is the
time $w2we stand and fight for the
life of our homeland!$K$d0    $R�㉺��b|$c0HAAR|$s0Attention...$w4 Let's...yaaawwnn...go.
Hmm...maybe I can catch a nap
while we fly...$K    $R�㉺��b|$c0HAAR|$s0...Now then...$w2
Let's see how things look.$K    $R�㉺��b|$c0JILL|$s0Captain Haar?$K
$s1$FS$c1HAAR|$s1Greetings, Jill. $w2So you're still alive,
eh? Good to see.$K
$s0That's what I was going to say
to you!$w4 You survived!
I'm very pleased.$K
$s1General Shiharam left me in charge.
I'm supposed to get our survivors$w2
and their families to Begnion.$K$PI can't die until that's done.$K
$s0Oh, I see...$w4 But then... $w2Captain,
why are you still in Daein?$K
$s1I... $w2Believe it or not, I'm a
vindictive man. $w5Revenge for the
general is something I couldn't let go.$K
$s0Oh!$w4 But...that...$K
$s1Don't get the wrong idea.$w4
You're not the enemy I'm seeking.$K
$s0Huh?$w3 But...$K
$s1The ones responsible for General
Shiharam's death, $w2are the Daeins.$K$PI pretended to return to the fold so I
could get close to General Petrine...$w3
I'm just waiting for my chance.$K$PBut I think they may be on to me.
My unit's a bunch of tough guys who
serve as Petrine's watchdogs.$K$PPlus, $w2I've been ordered to charge the
Crimeans head-on.$w4 It's Daein's way
of killing two birds with one stone.$K
$s0Don't do it!$w4 Come fight by our sides!
If you're looking to kill Daeins,$w2
then we share the same goal!$K
$s1Jill... I, um... $w2I don't trust Crimea
anymore than I do Daein.$w2
I'm sick to death of serving countries.$K
$s0Captain...$K
$s1Still... I can't abandon the daughter of
the man to whom I owe so much...
Guess I'm changing sides again.$K
$s0$FSReally?$w3 Oh, thank you, Captain!$K
$s1No, $w2you've got that backwards.$K
$s0$FAPardon?$K
$s1I'm a new recruit... $w2So I'm under you.$w4
$FSThanks in advance,$w2 Captain.$K$d1
$s0What?$w3 Don't be silly!$w4 Wait...$w4
Ah, $w2Captain!!!$K  $R�㉺��b|$c0HAAR|$s0...$w4Combat. Tsk. $w2It's one of
those things you simply cannot
control.$K   $R�㉺��b|$c0HAAR|$s0Oh, $w2so you want to try me?$w4
I trust you're going to show me$w2
how much you've improved!$K
$c1JILL|$s1What!!!$w4 It can't be...$w2
Captain Haar?$K   $R�㉺��b|$c0HAAR|$s0The Dark Angel...$w4 She's found me
at last... At least I can sleep now...$K  $R�㉺��b|$s0$FS$c0PRAGUE|$s0Ha ha!$w3 Do you like your meat rare?$w4
Or do you like it charbroiled?$K$PLet me know, $w2and I'll cook you up
just as ordered! Wha ha ha ha ha!$K   $R�㉺��b|$c0IKE2|$s0You...$w4 You're the knight
that my father battled.$K
$c1PRAGUE|$s1You!$w4 If I'd known you were going to
grow to be such a thorn in our side...$K$FS$PI would have reduced you to ashes
when I had the chance... Guess it's
not too late, though! Die!$K $R�㉺��b|$c1PRAGUE|$s1You... $w5That mark on your brow...$w2$FS
That's not a charm of the dead, is it?
You're no Spirit Charmer!$K$PHmph!$w4 You may be able to fool
others with that, but not me.
It's because we're the same, see?$K
$c0SENERIO|$s0$Fh...The same?$w4 Don't be ridiculous.
I'm nothing like you.$K$PYou kill for sport, and hide your fear
behind a wall of bravado. Now let me
show you true fear!$K   $R�㉺��b|$s0$FS$c0PRAGUE|$s0Let me tell you what I despise more
than anything else in this world...$w5
$FAYou half-breed beasts! Die now!$K   $R�㉺��b|$c0PRAGUE|$s0Bah!$w3 Accursed half-breed hawks!$K
I'll roast you like a goose and use
your feathers for pillow stuffing!$K   $R�㉺��b|$c0PRAGUE|$s0So the traitor appears... I'm going to
cook you alive! I bet your armor will
make a fine cauldron!$K    $R�㉺��b|$s0$FS$c0PRAGUE|$s0What's this?$w3 If you can't fight,
you should know better than to be
here.$w4 Stupid half-breed!$K   $R�㉺��b|$c0PRAGUE|$s0$FSJust as I expected. $w5I thought
to give you a chance to clear the
stain from your name...$K$PYet you and Shiharam are treachery$w3
in the flesh. Useless migrants!$K
$c1HAAR|$s1To think $w2we endured this for
eighteen long years.$K$PIt seems General Shiharam and I$w3
were not to be blessed $w5with any
masters worthy of serving.$K
All we found were paltry pretenders...$K
$s0$FAYou insult His Majesty?$w4 You know not
your place, you louse-ridden oaf!$w3 Your
failings are yours, and yours alone!$K
It's time for you to burn!
Don't worry, I'll let the dogs
snack on what's left!$K    $R�㉺��b|$c0PRAGUE|$s0Y-Your...$w2 Your Majesty...$w4
Forgive me...$w4$Fcplease... Oh,
I don't want to die... So...scared...$K    $R�w�i��b|$B���-��-��|$<$F3$FCL_ERINCIA|$F1$FS$F1$FCL_LUCHINO|$F1$PPrincess Elincia!$w4 Welcome home!$w2
It's so good to see you safe!$K
$F3$PLucia?$w4 Lucia!$w4 Is it really you?$K
$F1$PI am no spirit.$w4 See? $w2Flesh and bone,
through and through.$K
$F3$P$FSAh, $w2Lucia!$w4 You have no idea how I've
longed to see you.$K
$F1$PAnd I you,$w4 Princess Elincia.$w5
When my brother Geoffrey $w2told me you
had been lost,$w4 my world went dark.$K$PWhen I learned$w4 you were still alive...$w4
$FAI was...$w4so...$w4
$Fc$w4$w4$K$F1$P$Fd$F3$P$FAThen Geoffrey is safe as well? Happy day!
Are there others? $w5How many Crimean
retainers$w4 have survived?$K
$F1$P$FSWell,$w4 there's Count Bastian. That
silver-tongued rascal is as loquacious
as ever.$K$PAlso, General Tagio, Marquis Katol's orphan,
Silok, and Marquis Mitnala$w2 are all with us.$K$PThe soldiers we have contacted so far do
not even number one hundred.$K$PBut if they know you've returned, $w2retainers
hiding throughout the land will surely come
pouring in.$K
$F3$PYet, $w2my existence...$w4 It is not known
to the general populace...$K
$F1$PThere's no need to worry about that!$w3
Tales of your exploits in Daein have reached
every corner of Crimea.$K$PIn every village, in every town, the people
are talking.$K$P"Our fair king had a hidden child," they say.$w4
"The secret princess of Crimea is fighting
to save us all!"$K$PIn addition, $w2Daein soldiers have been
frantically searching for a mysterious and
elusive "Princess Crimea."$K$PAll they've succeeded in doing$w3 is convincing
the people that you truly are their princess.$K$PAll of Crimea $w2has been anxiously awaiting
your return.$K
$F3$POh, Lucia, do you speak truly?$w4 They have...$w2
acknowledged my existence?$w5
...I never...expected this day...$K
$=0600  $R�w�i��b|$B�R��-�C����|$<$F3$FCL_IKE2|$F1$FCL_LAY|$F1$PNews of your actions in Daein reached the
ears of King Gallia through Nasir. I then
told Lucia, $w2who passed it to the citizenry.$K$P...You know, the thought that Nasir is a
traitor just doesn't feel right to me.
I can't believe it.$w2$K
$F3$PYou think $w2I don't see that?$w5
Look at what we know about the medallion.$w4
We discovered it thanks to his hints.$K$PHe's helped us throughout our entire
journey.$w4 $FcIn that, at least, he was not false.$w2$K$Fd$PYet, $w2if he will not speak,$w4 there is
nothing I can do to save him.$K
$F1$PLet's go see him.$w4 One way or another,$w2
I will loosen his tongue.$K
$F3$PThis way.$K  $R�w�i��b|$B�R��-�C����|$<$F3$FCL_IKE2|$F1$FCL_LAY|$F1$PIke!$K
$F3$PRanulf!$w4 Are you well?$K
$F1$P$FSNo, not really...$w2 As good as I am,$w3
I made a mess of that fight.$K$PI won't be of use in combat for a while,$w3
but I'd like to be your guide. $w5I've got to
do something, or Giffca will have my hide.$K
$F3$PAs long as your life's not in danger, but...$w3
Don't you think you're doing too much?$K
$F1$PHey, it's me!$w4
$FA$K$PIke... News of your actions in Daein has$w5
reached the ears of King Gallia via Nasir.$K$PI then $w2told Lucia, $w2who passed it on
to the citizenry. The idea that he is a
traitor just doesn't fit.$w2$K
$F3$PYou think $w2I don't see that?$w5
Look at what we know about the medallion.$w4
We discovered it thanks to his hints.$K$PHe's helped us throughout our entire
journey.$w4 $FcIn that, at least, he was not false.$w2$K$Fd$PYet, $w2if he will not speak,$w4 there is
nothing I can do to save him.$K
$F1$PLet's go and see him.$w4 One way or another,$w2
I will loosen his tongue.$K
$F3$PThis way.$K
$=0600 $=1000$R�w�i��b|$B�V��-��|$<$F3$FCL_IKE2|$F4$FCL_LAY|$F3$PHe's being kept in this supply tent.
We wanted to keep him away
from the other soldiers.$K$P$Ub$HHuh?$K
$F4$PWhat is it?$K
$F3$PHe's... He's gone!$K
I brought him breakfast this morning!$w3
He was here...$K
$=2000    $R�w�i��b|$B�V���l�p-��|$<$F6$FCL_SENERIO|$F6$PHmm...$K
$F7$FCDUMMY|$F7$PSoren!$w4 Are you in here?$K$F7$FD
$F6$FD$F3$FCL_SENERIO|$F3$PYes...$K
$F1$FCL_IKE2|$F3$PIke?$w3 It's late. What do you want?$K
$F1$PShhh!$K
$F3$PUm...Ike?$K
$F7$FCDUMMY|$F7$POh, no...$w4 How strange. $w5I was sure
he'd come this way. Yooo-hooo?!$K$F7$FD
$F3$PThat voice... $w2It's the woman from the
item shop, isn't it?$K
$F7$FCTOOL|$F7$PCommander!$w3 Ike?$w4 Where have you
gone, handsome?$K
$F1$PCrud.$K
$F3$P...Did you run in here to escape?$K
$F1$PLook, whenever that woman corners me, it
takes forever to get away.$w4 Let me hide
in here until things simmer down.$K
$F3$PWe begin marching tomorrow morning...$w2
This is a waste of valuable time. I'll go$w2
and chase her away.$K$F3$FD
$F1$PWait! Soren!$K $R�w�i��b|$B�V��-��|$<$F1$FCL_TOOL|$F1$PIiike! Ikey-poo! Where aaaaare you?$K
$F3$FCL_SENERIO|$F3$PAimee?$K
$F1$POh. Soren. Ew.$w4 I mean, um...hi.
Why are you out so late?$K
$F3$PDo you have some business $w2with Ike?$K
$F1$P$FSWell, yes I do. I found a special something$w2
that I'd like to give to him.$w4 Do you
know where he is?$K
$F3$PIke is...in a war meeting.$w4 If you have
something for him,$w2 I can hold on to it
for you.$K
$F1$P$FAHmm...$w4 What should I do?
You see, I have this new staff...$K$PThe staff is VERY valuable.$w4 I'm not sure
if I feel comfortable simply handing it over
to someone who doesn't...understand that.$K
$F3$PThat's a Hammerne, is it not?$K$PA rare staff that can take any item, no
matter how battered and worn, $w2and
repair it completely.$K
$F1$PWhy...that's right.$w4 You're quite
knowledgeable, aren't you?$K
$F3$PIf I may continue,$w3 I believe that there is
only one of these in all the world.$w2
It truly is priceless.$K
And you want to give this $w2to Ike?$K
$F1$P$FSWell,$w3 I do want to be helpful.$K
$F3$P...If you truly wish to capture Ike's
attention, bringing him staves and
whatnot will avail you nothing.$K
$F1$P$FAWhat? Really? Oh, dear... I was so hoping
he would like it.$K
$F3$PFood, however, would be much more
effective than a staff.$w4 He's particularly
fond of spicy meat dishes.$K
$F1$P$FSIs that so?$w4 Cooking is not something
that I'm skilled at, but...$w3 Oh, I've got it!$w4
I know the perfect dish!$K
$F3$PAh, good! He will be very pleased!
Um...what about the staff?$K
$F1$PHee hee!$w4 You can keep it as payment
for the cooking tip!$w4 Take good care of it.$K$F1$FD
$F3$P...$w4 Well, she's unexpectedly $w2generous.$w4
$FSI received something quite nice from your
admirer, Ikey-poo!$w4 Thank you so much!$K
$F4$FCL_IKE2|$F4$P$FhHey, $w2wait a minute!$K    $R�w�i��b|$B�V��-��|$<$F3$FCL_IKE2|$F0$FCL_BEGNION1|$F3$PUnderstood.$w4 Proceed as ordered.$K
$F0$PSir, yes, sir!$K$F0$FD
$F3$PWhat's next...$w4 Huh?$w4 Who's there?$K
$F1$FS$F1$FCL_CHINON|$F1$PSir, yes, sir... Hey,$w3 it's General Ike
the Great!$w4 I heard all about it, you know?$w5
Those guys went and made you...a NOBLE!$K
$F3$PShinon?$K
$F1$PGood for you, huh? Har har! ...Hic!$K$PYou're in love with a pwetty wittle princess,$w4
you're fighting side-by-side with yer
sub-human pals. $w2Yes! Yer moving up!$K
Oooo, look at you!$w3 It's big mister Ike!
Leading the good life!$K
$F3$PThey're not sub-humans.$w4 They're laguz.$K
$F1$P$FA...$w4$FS
Yeah, $w2whatever.$K$PHere's the deal...$w3 Now that yer a high-
class noble, $w2you can't be running around
with a...buncha broke mercenaries.$K$PAll the other nobles...are gonna LAUGH
at you!$w3 So...give it up!$w4 I'll do you
a favor and take over.$K
$F3$PI don't think so.$w4 I'm going to continue as
commander of the Greil Mercenaries.$K
$F1$P$FAScrew you!$w4 You always get everything!$w4
Don't you ever want to give up anything?
Nooooo! Not big important mister Ike!$K$PYou've always been like this!$w4 You act
like you're not interested in something,$w3
then you swoop in and...$w3$FhSTEAL IT AWAY!$K$F1$FD
$F3$PHey!$w4 Shinon?$K$w4
$F0$FCL_CHINON|$F0$P......Wh-$w2what?$w4 WHAT?! And watch how
you say$w3 my name, boy! Boy, boy, boy...
Wittle boy Ike... Wittle Ikey...$K
$F3$P...Shinon,$w3 what's wrong with you?$w3
Are you feeling all right?$K
$F0$PWhat do you care, you snotty whelp?!$w2
It's none of yer business!$K$PAND another thing! About the command$w3 of
the company.$w4 If you refuse to give it up...$w3
at least $w1change$w1 the name!$K$PYer NOT...$w2Commander Greil!$w3 Just because
you're his son...$K$PThat doesn't...give you the right...$w2
to use his name...$K
$F3$PShinon, $w2are you sure you're all right?$K
$F0$P...YEAH! I'm fine! I'll be fine... Fine, fine...$w4
Ugh...$w4$FhI don't feel so good.$w3
Ooh...$Fo$w2BLAARRRGGGHHHH!$K$P$F0$FD
$F3$PIt was never about the commandership...$w4
It was about $w2my father.$w4
...$K $R�w�i��b|$B�V��-��|$<$F1$FCL_SENERIO|$F3$FCL_IKE|$F1$PIke,$w3 I'd like to report the results
of our last battle.$K$N$UB$H $F3$P$FcI see.$K$P$UB$H $F1$P$FSThere were no deaths $w2and no injuries
beyond our capabilities to heal.$w4
Everyone performed exceedingly well.$K$P$UB$H   $F1$PThat is all.$w4 By your leave,$w2
I will excuse myself.$K    /�      5x   	  .�     0�   #  .�   0  3\   <  3�   H  4t   T  4�   `  1�   l  7�   x  /�   �  8`   �  ?\   �  B   �  F   �  "�   �  &d   �  'X   �  '�   �  �   �  G0    JD    Qh  !      /    ;  D  G  �  S  �  _  @  m   h  y  Y�  �  Z  �  Z�  �  Z0  �  (  �MS_24_BT MS_24_BT_HA MS_24_BT_HAAR MS_24_BT_IKE MS_24_BT_JI MS_24_BT_R1 MS_24_BT_R2 MS_24_BT_R3 MS_24_BT_RI MS_24_BT_SE MS_24_DIE MS_24_DIE_HAAR MS_24_ED_01 MS_24_ED_02_A MS_24_ED_02_B MS_24_ED_03 MS_24_EV_01 MS_24_EV_02 MS_24_EV_03 MS_24_EV_04 MS_24_GMAP_01 MS_24_INFO_02 MS_24_INFO_02_2 MS_24_INFO_04 MS_24_OP_00 MS_24_OP_01 MS_24_OP_02 MS_24_OP_03 MS_24_OP_03_2 MS_24_OP_04 MS_24_OP_05 MS_24_REPO_BEGIN MS_24_REPO_DIE MS_24_REPO_END MS_24_REPO_NODIE MS_24_TK_01 