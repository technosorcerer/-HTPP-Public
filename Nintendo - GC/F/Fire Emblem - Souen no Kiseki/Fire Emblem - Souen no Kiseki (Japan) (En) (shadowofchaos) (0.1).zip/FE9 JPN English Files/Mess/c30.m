  {�  x4       )                $RGMAP��b|$O3$GThe Black Knight, $w2cold-blooded murderer
of Ike's father,$w3 has disappeared$w3 within
the collapsed castle.$K$PHowever, $w2Nasir has been lost with him.$K
In the end, $w2he did not reveal the contents
of his heart,$w3 but instead left another
mystery with his enigmatic parting words.$K$PWhat $w2was he trying to tell Ike?$w4
What did he hope to gain in this war?$w4
What was he searching for?$K$PWith yet another memory to shoulder,$w4
Ike must fight on.$K$PThe Crimean army and its laguz allies $w2have
passed the trial of Nados Castle.$K$P$Ub$HAt last, $w2they've arrived at their final
destination: the Crimean capital.$K$PYet $w2the opponent that awaits them$w3
is none other than Ashnard, king of Daein.$K$PIf they lose here, $w2all of their hardships will
have been for naught.$w4 Preparations for the
attack $w2proceed with the utmost care.$K$PThe final battle is approaching.$K$PAn air of exaltation pervades the camp,$w3 but
Ike remains focused on the road ahead,$w2
readying himself for what is to come.$K$Ub$H    $RGMAP��b|$O3$GIke has avenged his father $w2by defeating the
Black Knight in single combat.$w4 That night,$w3
he sleeps until well past dawn.$K$PIt is the first time$w3 since Greil's death $w2that
he has done so.$K$P$Ub$HThe Crimean army and its laguz allies $w2have
passed the trial of Nados Castle.$K$P$Ub$HAt last, $w2they've arrived at their final
destination: the Crimean capital.$K$PYet $w2the opponent that awaits them$w3 is none
other than Ashnard, king of Daein.$K$PIf they lose here, $w2all of their hardships will
have been for naught.$w4 Preparations for the
attack $w2proceed with the utmost care.$K$PThe final battle is approaching.$K$PAn air of exaltation pervades the camp,$w3 but
Ike remains focused on the road ahead,$w2
readying himself for what is to come.$K$Ub$H   $R�w�i��b|$B�V���l�p-��|$<$F3$FCL_ENA|$F1$FCL_IKE2|$F3$PMaster Ike. The heron princess is being kept
a little ways south of here, in a place
called Gritnea Tower.$K
$F1$PHow do you know that?$K
$F3$PI was searching for information,$w4 and that
search led me to a troop of Daein soldiers
who had been assigned to the tower.$K$PThat was $w2the extra knowledge I needed.$K
$F1$PYou won't tell me any more than that,$w2
will you? No matter how important it might
be to our upcoming fight.$K
$F3$P...I'm sorry.$K
$F1$PI figured as much.$w4 I've already decided
to trust you, so all that's left to do is
move out.$K
$F3$P...$K$F1$FD   $R�w�i��b|$B�V���l�p-��|$<$F3$FCL_NASIR|$F1$FCL_IKE2|$F3$PIt appears that Leanne $w2is being held
in Gritnea Tower, to the south.$K$P$FSThat's right, isn't it, Ena?$K
$F4$FCL_ENA|$F4$PYes. $w2That is correct.$K
$F1$PHow do you know that?$K
$F4$PI was searching for information,$w4 and that
search led me to a troop of Daein soldiers
that had been assigned to the tower.$K$PIt was $w2the extra knowledge I needed.$K
$F1$PYou won't tell me any more than that,$w2
will you? No matter how important it might
be to our upcoming fight.$K
$F4$P...$K
$F3$P$FA...I beg your pardon.$K
$F1$PI figured as much.$w4 I've already decided
to trust you, so all that's left to do is
move out.$K $R�w�i��b|$B�V����c�p|$<$F1$FCL_TIAMAT|$F0$FCL_SENERIO|$F3$FCL_IKE2|$F3$PTitania! $w2Soren!$w4 At daybreak,$w3 I'll be taking
a small force south to Gritnea Tower.$K
$F1$PFor what purpose?$K
$F3$PThat's where they're holding Leanne.$K
$F1$FD$F0$FD$F0$FCL_RIEUSION|$F0$PAre you certain?$K
$F3$PFairly certain, yes.$K
$F1$FCL_TIBARN|$F1$PAll right, $w2then I'll go with you.$K
$F0$PAs will I.$K
$F3$POf course.$K
$F4$FCL_SENERIO|$F4$PAnd the main army? $w2Have you thought
about what it will do?$K
$F3$PYes, I have.$K
$F0$FD$F1$FD$F1$FCL_ERINCIA2|$F3$PPrincess Elincia, $w2may I count on you?$K
$F1$PNaturally.$K
I will remain here $w2and see to it that
preparations for storming the capital
continue as planned.$K$PHowever, $w2you must promise to return.$w5
And $w2to bring my lady Leanne with you.$K
$F3$P$FSI hear you.$K $R�w�i��b|$B�O���g�l�A-����|$<$F0$Fc$F0$FCL_LEARNE|#F01$O2$MC...$MDAhh? ...Where am I...#F02$O1$K$F0$Fh
$F2$FCL_IZUKA|$F2$P$FSWhee hee hee!$w4 It appears that she's finally
coming around!$K
$F0$FD$F2$P$FAWe brought this girl here $w2on direct orders
from His Majesty. Simple stuff, yes?
Very easy, very nice.$K$PThen he gives all these special commands!$w4
Don't let her escape. $w2Don't let her get
sick.$w2 Don't let people kill her...$K$PMore than anyone else, $w2His Highness
should know how hard it is to keep
one of these birdies healthy...$K
$F4$FCL_DAYNE3|$F4$PIs there a problem?$K
$F2$FD$F1$FCL_IZUKA|$F1$PEh?$w4 Who do you think you are?$w4
Why is it you disturb my meditations!$w4
I'm thinking here!$K
$F4$PUm...$w4 I'm here to relieve you on guard duty.$K
$F1$PStanding guard, eh?$w4 Don't see much
reason for a guard in this place.$K$PBut armies always have all their rules and
regulations and appearances and hullabaloo...
Ah, $w2no way around it, I suppose.$K
$F4$PI believe that guards and watches are
important.$K
$F1$PWheee! In other places, yes.$w4 But $w2Gritnea
Tower $w2is currently overflowing with
veteran soldiers.$K$PNot to mention those repulsive beasts...$w4
Those Feral Ones, you know?$K$PTrying to escape from this place$w2
is the same as committing suicide!
Not that I've tried, mind you.$K
$F4$PSo a watch is necessary.$K
$F1$PHmmm? Wheee! What's that now?
Who said that?! Oh, it's you.
Important, eh? Why's that?$K
$F4$PWeeell...if the girl were to leave her room,$w2
we would be unable to stop her from
getting killed.$K
$F1$P$FSOoo!$w3 You found a blind spot!$K$PThat's the problem with us scholars!$w2
We concentrate on one thing and miss
something as fundamental as--$K  $R�w�i��b|$B�O���g�l�A-����|$<$F1$FCL_IZUKA|$F4$FCL_DAYNE3|$F1$PBlast!$w3 They're getting riled up again...$K
Listen, $w2you!$w4 You stay right here
and stand guard.$K$PDon't let that heron girl take one step
outside this room! $w2Do you understand me?
Wheee! I told you we needed guards!$K
$F4$P...Sigh...$w4 Don't worry. I'll take care of
everything.$K
$F1$PBah! $w2Always when I'm in the middle
of something...$w4 Snaggle-toothed,
cheese-stealing...$K$P$F1$FD$w6
$Ub$H$F4$PFinally! Methinks that guy fell a little far
from the nest...$K$w4$FS$PHello, $w2little heron girl.$w4 There's nothing
to be afraid of. I won't hurt you.$w2
Just sit there and be quiet, all right?$K
$F0$FCL_LEARNE|$F0$P#F01$O2Where is$MC...$MDthis place?#F02$O1$w4
#F01$O2Who are you?$MC......$MD#F02$O1$K
$=1000 $R�w�i��b|$B����-�[��|$<$F3$FCL_IKE2|$F1$FCL_ENA|$F3$PThat's Gritnea Tower, right?$K
$F1$PIt is.$K
$Ub$H$F4$FCL_LAY|$F4$PSay, $w2Ike...$w4 There's something...$w4
really odd about that tower... Sniff...
I mean REALLY odd...$K
$F3$PWhat is it?$K
$F4$PI sense several of the beast tribe,$w4 but...$w4
what is that?$w4 ...Sniff... Ugh! Something
smells terrible!$K
$F1$PThe tower $w2holds laguz who have been
given toxins, foul potions that warp their
true shape.$K
$F3$PAre you talking about the laguz that
can't change forms? Like the ones
we fought in Begnion?$K
$F1$P...Yes.$K
$F4$P$FSDo you know how many $w2and what
type are in there?$K
$F1$PAs far as numbers...$w4a conservative
estimate would be thirty.$K
Types?$w4 There are tigers and cats from
the beast tribes, $w2hawks and ravens from
the bird tribes,$w4 and...$w4dragons...$K
$F4$P$FAThere are some from the dragon tribes
as well?$K
$F1$PNo more than ten.$w4 Er...
Probably no more than ten...$K
$F3$PWe have to fight ten dragons $w2like you?$K
$F1$PThey are not like me, Master Ike.
They are much stronger.$K
$F3$P...That's hardly encouraging...$K
$F1$FD$F1$FCL_TIBARN|$F1$PRegardless, we must hurry.$w4
It's going to be dark soon.$K$PIt's rather embarrassing, $w2but we of the bird
tribes $w2don't move well in the dark.$K$P$F0$FCL_RIEUSION|$F0$PSad but true. $w2Of course, $w2the same can be
said for those on the enemy side as well.$K
$F4$POn the other hand, $w2darkness means next
to nothing for my kind. Depending on who
we face, $w2it could prove to be a significant--$K
$F0$FD$F1$FD$F1$FCL_ENA|$F1$PThere are more of the beast tribe than any
other.$w4 It is because we are close to Gallia.$K
$F4$PListen, $w2you...$w4 Are you sure
you want to be on our side?$K
$F1$P...Hm?$w4 Yes,$w2 of course.$w4
That is why I provide accurate information.$K
$F3$PSo once it gets dark, we're going to be at
a disadvantage.$w2 Right? All right, as long
as we know that, we can plan for it.$K
$F4$P$FhYou're too calm about this for my tastes.$w4
This is going to be a--$K
$F3$PEnough, Ranulf!$w4 We don't have time for
complaints. $w2We need to find the entrance
to the tower.$K
$F4$P$FcYeah, yeah. I'm coming.$K
$=0900    $R�w�i��b|$B����-�[��|$<$F3$FCL_IKE2|$F1$FCL_NASIR|$F3$PSo that's Gritnea Tower, is it?$K
$F1$PI believe so.$K
$Ub$H$F4$FCL_LAY|$F4$PSay, $w2Ike...$w4 There's something...$w4
really odd about that tower... Sniff...
I mean REALLY odd...$K
$F3$PWhat is it?$K
$F4$PI sense several of the beast tribe...$w4 But...$w4
what is that?$w4 ...Sniff... Ugh! Something
smells terrible!$K
$F0$FCL_ENA|$F0$PThe tower $w2holds laguz who have been
given medicine... These drugs warp their
true shape.$K
$F3$PAre you talking about the laguz that
can't change forms? Like the ones
we fought in Begnion?$K
$F0$P...Yes.$K
$F4$P$FSDo you know how many $w2and what
type are in there?$K
$F0$PAs far as numbers...$w4a conservative
estimate would be thirty.$K
Types?$w4 There are tigers and cats from
the beast tribes, $w2hawks and ravens from
the bird tribes,$w4 and...$w4dragons...$K
$F4$P$FAThere are some from the dragon tribes
as well?$K
$F0$PNo more than ten.$w4 Er...
Probably no more than ten...$K
$F3$PWe have to fight ten dragons $w2like you?$K
$F0$PThey are not like me, Master Ike.
They are much stronger.$K
$F3$P...That's hardly encouraging...$K
$F0$FD$F1$FD$F1$FCL_TIBARN|$F1$PRegardless, we must hurry.$w4
It's going to be dark soon.$K$PIt's rather embarrassing, $w2but we of the bird
tribes $w2don't move well in the dark.$K$P$F0$FCL_RIEUSION|$F0$PSad but true. $w2Of course, $w2the same can be
said for those on the enemy side as well.$K
$F4$POn the other hand, $w2darkness means next
to nothing for my kind. Depending on who
we face, $w2it could prove to be a significant--$K
$F0$FD$F1$FD$F0$FCL_ENA|$F1$FCL_NASIR|$F0$PThere are more of the beast tribe than any
other.$w4 It is because we are close to Gallia.$K
$F4$PListen,$w4 are you sure you want to be
on our side?$K
$F0$P...Hm?$w4 Yes,$w2 of course.$w4
That is why I provide accurate infor--$K
$F4$PNasir!$K
$F1$P$FSWhat do you think, Ranulf?$w4 My grandchild
is impressive, is she not?$K
$F4$P$FhThat's not what I was going to
say, Grandpa--$K
$F0$FD$F1$FD$F4$P$Fd$F3$PSo once it gets dark, we're going to be at
a disadvantage.$w2 Right? All right, as long
as we know that, we can plan for it.$K
$F4$P$FhYou're too calm about this for my tastes.$w4
This is going to be a--$K
$F3$PEnough, Ranulf!$w4 We don't have time for
complaints. $w2We need to find the entrance
to the tower.$K
$F4$P$FcYeah, yeah. I'm coming.$K
$=0900    $R�w�i��b|$B�O���g�l�A-�J��|$<$F2$Fc$F2$FCL_IZUKA|$F2$PThat took longer than I'd expected.$w4
Cursed sub-humans...$w4flea-bitten wretches...$K$w3$Fd$PHuh?$w4 Where's the heron girl?$w4
And the...guard? Helloooo?$w4 Guard?$w4
Bird girl?$w4 Wheeeeee?$K$PThis can't...$w4 NO! $w2I've been had!$w4
Nooooooooo!$K$PWhat do I do? $w2If this is discovered,$w2
His Majesty will... He'll hang me up by my
thumbs! Oh, no... Oooooh noooo...!$K
No, $w2no,$w4 no! $w2I will not report this!$K$PUm... Uh... Think, Izuka, think! Hmmm...
If I can somehow divert attention
from myself...$K
$F7$FCDUMMY|$F7$PMaster Izuka!$K
$F2$PGyaaaa!$K$F2$FD
$F1$FCL_DAYNE2|$F1$PMaster Izuka!$w3 We've got trouble!$w4
A strange group of insurgents approaches
the tower! They are well armed, sir!$K$P...Master Izuka?$K
$F4$FCL_IZUKA|$F4$PEh? Insurgents? Wheeee-- Um...$w3 Ahem!$w4
Did you say insurgents have appeared?$K
$F1$PYes, sir!$w4 A mixed group of sub-humans and
humans.$K
$F4$PAh... $w2I see, I see.$w4 $FSThen we must$w2 give them
a warm reception, no?$K
$F1$PGeneral Heddwyn's mages have engaged
them, but they're not nearly enough.$K$PWe must apply to the capital for more
reinforcements to--$K
$F4$PRelease the Feral Ones.$K
$F1$PTh-those monsters?$w4 But...$K
$F4$PNo need to worry.$w4 I have just given them
their medication. They've all been trained
not to attack any Daein soldiers.$K
$F1$PV-very well, I--$K
$F4$PDo it now!$w4 The enemy must not be allowed
inside the tower.$K
$F1$PY-yes, $w2sir!$K$F1$FD$w5
$F4$P...Feh feh feh!$w4 Wheeeeeeee!!!
What fortuitous timing.$K$PNow then, $w2I will take this moment $w2and
prepare to make my escape.$K  $R�㉺��b|$s0$FS$c0TIBARN|$s0Look at this, will you? $w5What a
glorious mix of$w3 birds, beasts, and
dragons $w2we have to greet us.$K
$c3LAY|$s3King of hawks!$w4 This $w2is no joking
matter! They--$K
$s0$FAHold on, my brothers. Just a little
longer.$w3 Soon, $w2I will grant you
all release.$K$d0
$s3Oh...$K
$c1RIEUSION|$s1Tibarn is not the only one $w2who is
filled$w3 with rage. To warp the gift
that the goddess has granted us...$K$PThis crime$w3 shall not go unpunished!$w4
$FcYaaaaa!!$K$d1
$s3Prince Reyson...$K
$c0IKE2|$s0Come, Ranulf,$w3 let's join them.$K$PWe must rescue Leanne as soon
as possible...$w3for Reyson's sake as
much as anything else.$K
$s3Those poor laguz... Someone will
die for this today!$K   $R�㉺��b|$s0$FS$c0TIBARN|$s0Look at this, will you? $w5What a
glorious mix of$w3 birds, beasts, and
dragons $w2we have to greet us.$K
$c3LAY|$s3King of Hawks!$w4 This $w2is no joking
matter! They--$K
$s0$FAHold on, my brothers. Just a little
longer.$w3 Soon, $w2I will grant you
all release.$K$d0
$s3Oh...$K
$c1RIEUSION|$s1Tibarn is not the only one $w2who is
filled$w3 with rage. To warp the gift
that the goddess has granted us...$K$PThis crime$w3 shall not go unpunished!$w4
$FcYaaaaa!!$K$d1
$s3Prince Reyson, $w5it must be difficult to
not be able to fight on your own...$K
$c0IKE2|$s0Come, Ranulf,$w3 let's join them.$K$PWe must rescue Leanne as soon
as possible...$w3for Reyson's sake as
much as anything else.$K
$s3Those poor laguz... Someone will
die for this today!$K  $R�㉺��b|$s0$FS$c0TIBARN|$s0Look at this, will you? $w5What a
glorious mix of$w3 birds, beasts, and
dragons $w2we have to greet us.$K
$c3LAY|$s3King of Hawks!$w4 This $w2is no joking
matter! They--$K
$s0$FAHold on, my brothers. Just a little
longer.$w3 Soon, $w2I will grant you
all release.$K$d0
$s3Oh...$K
$c1RIEUSION|$s1Tibarn is not the only one $w2who is
filled$w3 with rage. To warp the gift
that the goddess has granted us...$K$PThis crime$w3 shall not go unpunished!$w4
Yaaaaa!!$K$d1
$s3Prince Reyson...$K
$c0IKE|$s0Ranulf,$w3 will you do me a favor$w2
and wait someplace safe?$K
$s3Those... Those poor laguz...$K$d3$d0$w6
$c1LAY|$s1Ike!$w4 One thing...$K
$c0IKE|$s0Yes?$K
$s1My brothers are out there...$K$PIf there is no way to heal them,$w2
would you please...$K
$s0I understand.$w4 You can count on me.$K
$s1Thank you.$K  $R�㉺��b|$s0$FS$c0TIBARN|$s0Look at this, will you? $w5What a
glorious mix of$w3 birds, beasts, and
dragons $w2we have to greet us.$K
$c3LAY|$s3King of Hawks!$w4 This $w2is no joking
matter! They--$K
$s0$FAHold on, my brothers. Just a little
longer.$w3 Soon, $w2I will grant you
all release.$K$d0
$s3Oh...$K
$c1RIEUSION|$s1Tibarn is not the only one $w2who is
filled$w3 with rage. To warp the gift
that the goddess has granted us...$K$PThis crime$w3 shall not go unpunished!$w4
$FcYaaaaa!!$K$d1
$s3Prince Reyson...$K
$c0IKE2|$s0Ranulf,$w3 will you do me a favor$w2
and wait someplace safe?$K
$s3Yeah...$K$d3$d0$w6
$c1LAY|$s1Ike!$w4 One thing...$K
$c0IKE2|$s0Yes?$K
$s1My brothers are out there...$K$PIf there is no way to heal them,$w2
would you please...$K
$s0I understand.$w4 You can count on me.$K
$s1Thank you.$K$PPrince Reyson and I $w2await your return.$K $R�㉺��b|$c1DAYNE3|$s1...Whew.$w4 I thought as much when I
first snuck in here, $w2but this really is
an unbelievable place.$K$PWhat in Ashera's name is going on?
Why are all these crazed laguz
creeping about?$K
$c0LEARNE|$s0#F01$O2I hate this!#F02$O1$K
$s1Hm?$w4 $FSOh, $w2you don't like this, eh?$w4
Neither do I. $w2This helmet and armor
are horribly restrictive, you know?$K    $R�㉺��b|$s1$FS$c1NAESALA|$s1How's that, $w2Leanne?$w4
It's been twenty years, $w2but I'm still
quite an eyeful.$w4 Don't you agree?$K
$s0$FS$c0LEARNE|$s0#F01$O2Uh-huh. You're very handsome, Naesala.#F02$O1$K
$s1Yeah, I haven't changed much, eh?$w4
And you knew it was me back there
right away, didn't you?$K$PAh, $w2I'm glad you survived.$w4 It's very
good to see you again.$K
$s0#F01$O2Yes$MC...$MDI am also pleased.#F02$O1$K
$s1$FANow, $w2on to the problem at hand.$K$PWe went to the trouble of escaping
that tower, $w2so I'd hate to end up a
meal for one of our insane cousins.$K$POur objective is to rendezvous $w2with
Nealuchi.$K$PHere we go, $w2Leanne.$w4 Hold on
tight.$K
$s0#F01$O2I will!#F02$O1$K    $R�㉺��b|$c0NAESALA|$s0What's going on?$w4 They're all looking
the same direction.$K
$s1$FS$c1LEARNE|$s1#F01$O2Naesala! Over there!#F02$O1$K
$s0$FSTibarn and friends, eh? $w5Oh,$w2
very good.$K
This will work out nicely...$K  $R�㉺��b|$c1NEALUCHI|$s1Ne-$w2nestling!!$w4 We've found you
at last!$K
$s0$FS$c0NAESALA|$s0Nealuchi!$w4 You're here sooner than
expected.$K$PYou pushed your old wings$w3
to the limit, didn't you?$K
$s1$FSI couldn't be late to the rescue of
the dear lady Leanne, $w2now could I?$K
$s3$FS$c3LEARNE|$s3#F01$O2Nealuchi! You came for me, too?#F02$O1$K
$s1Oh!$w4 What a glorious sight...$K$PYou look so much like your dear,
departed mother...$w3$FA
Sniff...$K
$s3$FA#F01$O2Don't cry, Nealuchi!#F02$O1$K
$s0$FAHey, $w2save your tears for later.$w5
While Tibarn and the others take care
of the enemy, $w2we must escape.$K
$s1Y-yes, $w2of course!$w4 This way!$K  $R�㉺��b|$c0TIBARN|$s0Oof! $w5I can't believe I'm saying
this, but...$K$PI must withdraw.$K   $R�㉺��b|$c0KOYUJO|$s0This is not good...$w3 They're closing in.$K
There are not enough Feral Ones.$w4
Someone! $w2Anyone?$w4 Haaaalp!
Go $w2find Master Izuka at once!$K $R�㉺��b|$c0KOYUJO|$s0That one...$w3 He has the look of a
commander.$w4 If I can only hit him...$w2
Well, here goes nothing!$K    $R�㉺��b|$c0KOYUJO|$s0That's a Feral One, isn't it?$w4
They all look alike to me...$w4
Eh? Wh-why is it coming this way?$K$PAaah! I don't like this at all!$w3
I think I'll destroy it just to be safe.$K $R�㉺��b|$c0KOYUJO|$s0Is that a Feral One?$w4
Or is it an enemy...?
I can't tell the difference!$K
I'll attack it just in case.$K $R�㉺��b|$c0KOYUJO|$s0Reinforcements at last!
No, wait a moment...$w4
Could that be...$K  $R�㉺��b|$c0KOYUJO|$s0E-Ena?$w4 It can't be...$w3
You were supposed to be executed!$K $R�㉺��b|$c0KOYUJO|$s0None of the Feral Ones is that
color.$w4 Which means $w2it's an enemy!
Yaaaaaa!$K   $R�㉺��b|$c0KOYUJO|$s0Master Izuka...$w4 Call...$w3him...$K   $R�w�i��b|$B�O���g�l�A-�J��|$<$F4$FCL_LAY|$F4$PIke! Any sign of her?$K
$F1$FCL_IKE2|$F1$PNo, I don't see her anywhere.$K
$F1$FD$F1$FCL_RIEUSION|$F1$PLeanne...$w3 Where have you gone?$K
$Ub$H$F4$FD$F4$FS$F4$FCL_NAESALA|$F4$PHello, $w2everyone. Are you having some sort
of problem?$K
$F1$PNaesala!$K
$F1$FD$F1$FCL_IKE2|$F1$POh. King Kilvas.$w5 How nice.$K
$F4$PI believe I have what you seek
right here.$K$F4$FD
$F3$FS$F3$FCL_LEARNE|$F3$P#F01$O2Brother! Oh, my brother!#F02$O1$K
$F1$FD$F1$FCL_RIEUSION|$F1$P$FSLeanne! You're safe!$K
$F3$P#F01$O2Brother! Brother!#F02$O1$K
$F3$FD$F1$FD$F1$FCL_IKE2|$F1$P...You? $w2You rescued her?$K
$F4$FCL_NAESALA|$F4$PListen, and listen good.$w4 I don't want there
to be any misunderstandings here.$w4
It was Tibarn!$w4 He forced me to do this.$K$PIt wasn't any sense of charity or anything.$w4
$FcIt was a sort of...payment for the
debt I had incurred.$K
$F0$FS$F0$FCL_TIBARN|$F0$PI knew choosing you would pay off.$w4
Excellently done.$K
$F4$P$FdFlatter me all you like, hawk king.
You'll get nothing in return.$K$PAs promised, $w2the Duke Tanas account
has been completely settled.$K
$F0$PYes, as agreed.$K
$F4$PWell then, $w2I take my leave of you.$K
$F0$PThere's no need to rush off. Is there?$w4
Since you've come all this way,$w4 why
not stay and help us with King Daein?$K
$F1$PWhat a splendid idea.$K
$F4$PWhat? Enough of your nonsense. I prefer to
keep my life intact, thank you.$K
$F0$FD$F0$FCL_LEARNE|$F0$P#F01$O2Naesala, $w2are you leaving?#F02$O1$K
$F4$PListen to me, $w2Leanne.$w4
I have no good reason $w2to fight
the king of Daein.$K
$F1$FD$F1$FCL_RIEUSION|$F1$PNo good reason?$K
And what about your fellow Kilvans?$w2
King Daein$w3 has taken their natural
identity and warped it beyond repair!$K
$F4$PThey left Kilvas of their own accord.$w2
How far should my responsibility for
them extend?$K
$F1$PYou...$K
$Ub$H$F4$FD$F4$FCL_NASIR|$F4$PI hate to interrupt, $w2but...$K
$F0$FD$F1$FD$F1$FCL_IKE2|$F1$PWhat is it, Nasir?$K
$F4$PI have something $w2I want to show you all.$w4
Will you please come below?$K
$F0$FCL_TIBARN|$F0$PThis tower has a basement?$K
$F4$PWe just discovered a hidden staircase.$K
$F1$PLet's go.$K
$=1000  $R�w�i��b|$B�O���g�l�A-�J��|$<$F4$FCL_LAY|$F4$PIke! Any sign of her?$K
$F1$FCL_IKE2|$F1$PNo, I don't see her anywhere.$K
$F1$FD$F1$FCL_RIEUSION|$F1$PLeanne...$w3 Where have you gone?$K
$Ub$H$F4$FD$F4$FS$F4$FCL_NAESALA|$F4$PHello, $w2everyone. Are you having some sort
of problem?$K
$F1$PNaesala!$K
$F1$FD$F1$FCL_IKE2|$F1$POh. King Kilvas.$w5 How nice.$K
$F4$PI believe I have what you seek
right here.$K$F4$FD
$F3$FS$F3$FCL_LEARNE|$F3$P#F01$O2Brother! Oh, my brother!#F02$O1$K
$F1$FD$F1$FCL_RIEUSION|$F1$P$FSLeanne! You're safe!$K
$F3$P#F01$O2Brother! Brother!#F02$O1$K
$F3$FD$F1$FD$F1$FCL_IKE2|$F1$P...You? $w2You rescued her?$K
$F4$FCL_NAESALA|$F4$PListen, and listen good.$w4 I don't want there
to be any misunderstandings here.$w4
It was Tibarn!$w4 He forced me to do this.$K$PIt wasn't any sense of charity or anything.$w4
$FcIt was a sort of...payment for the
debt I had incurred.$K
$F0$FS$F0$FCL_TIBARN|$F0$PI knew choosing you would pay off.$w4
Excellently done.$K
$F4$P$FdFlatter me all you like, hawk king.
You'll get nothing in return.$K$PAs promised, $w2the Duke Tanas account
has been completely settled.$K
$F0$PYes, as agreed.$K
$F4$PWell then, $w2I take my leave of you.$K
$F0$PThere's no need to rush off. Is there?$w4
Since you've come all this way,$w4 why
not stay and help us with King Daein?$K
$F1$PWhat a splendid idea.$K
$F4$PWhat? Enough of your nonsense. I prefer to
keep my life intact, thank you.$K
$F0$FD$F0$FCL_LEARNE|$F0$P#F01$O2Naesala, $w2are you leaving?#F02$O1$K
$F4$PListen to me, $w2Leanne.$w4
I have no good reason $w2to fight
the king of Daein.$K
$F1$FD$F1$FCL_RIEUSION|$F1$PNo good reason?$K
And what about your fellow Kilvans?$w2
King Daein$w3 has taken their natural
identity and warped it beyond repair!$K
$F4$PThey left Kilvas of their own accord.$w2
How far should my responsibility for
them extend?$K
$F1$PYou...$K
$Ub$H$F4$FD$F4$FCL_ENA|$F4$PMaster Ike, I am sorry to interrupt, $w2but...$K
$F0$FD$F1$FD$F1$FCL_IKE2|$F1$PWhat is it, Ena?$K
$F4$PI have something $w2I need to show you.$w4
Will you please come to the basement?$K
$F0$FCL_TIBARN|$F0$PThis tower has a basement?$K
$F4$PWe have discovered a hidden staircase.
What lies below is...unsettling.$K
$F1$PLet's go.$K
$=1000   $R�㉺��b|$c0IKE2|$s0What $w2is that smell?$K
$c1NASIR|$s1...It is...corruption.$K$d1
$s0It's too dark to see anything.$w4
We need light...$K
$Ub$H$c1LAY|$s1...What,$w3 what is this?
Oh, by the goddess...$K
$Ub$H$c3NASIR|$s3...$K
$s1$w5W-what is this...?!$w5
Nasir! Answer me!$K
$s0Ranulf?$K
$d3$c2ENA|$s2Laguz...$w4 $FcAt one time,
they were...$w3laguz...$K $R�㉺��b|$c0IKE2|$s0What $w2is that smell?$K
$c1ENA|$s1...It is...corruption.$K$d1
$s0It's too dark to see anything.$w4
We need light...$K
$Ub$H$c1LAY|$s1...What,$w3 what is this?$K
$Ub$H$c3ENA|$s3...$K
$s1W-what is this...?!$w5
Answer me!$K
$s0Ranulf?$K
$s3Laguz...$w4 $FcAt one time,
they were...$w3laguz...$K   $R�̂݉�b|$w4$F1$FCL_IKE2|Oh, this is...$w5so horrible.$K  $R�w�i��b|$B�V��-��|$<$F0$Fc$F0$FCL_ENA|$F1$FCL_ERINCIA2|$F3$FCL_IKE2|$F1$PI hope Ranulf and the others are all right.$w4
They behaved as if nothing had happened,
but...$w4I could sense they were in pain.$K
$F3$PThat dungeon was the most vile thing I
have ever seen.$w4 I'm glad you weren't there.$K
$F1$PWas it that bad?$K
$F3$PIt was barbaric beyond description... There
were more laguz corpses than we could
count...$K$PThey had been tortured. Twisted and
warped beyond all recognition.$K
$F1$PAh...such horrors...$K
$F3$PWhy would Ashnard do such things?
What could be his purpose here?$K
$F0$P$Fd...$w4The king $w2called powerful beorc to his
cause. But he had to see if they
were worthy.$K
He would test them by pitting them against
those laguz.$K$PAshnard considers laguz to be tools in
service to his own mad ends.
Nothing more.$K$PThey are instruments to be used as he sees
fit.$w4 I heard that he ordered his scholars$w4
to perform all kinds of experiments...$K$PThey used elixirs $w2to drive them mad$w2
and keep them locked in their changed
states...$K$PTheir life spans were much shortened,$w4
but for a brief time, they became extremely
powerful...$w4$Fcthey...$K
$F1$P...$K
$F3$P...$w5Thank you $w2for telling us.$K$PThanks to you, $w2we found Leanne.$w4
You're free now. $w2You can do whatever
you like.$K
$F0$P...I will go to the capital.$w4 Please accept me
into your army.$K
$F3$PYou don't have to do that.$w4 Fighting against
your former companions could prove
difficult.$K
$F0$P$FdTake me with you.$w4 There is$w2 something that
I have to do.$w4 Please, Master Ike.$K
$F3$P...Very well.$w4 Let's fight together.$K
$=1000  $R�w�i��b|$B�V��-��|$<$F0$Fc$F0$FCL_ENA|$F4$FCL_NASIR|$F1$FCL_ERINCIA2|$F3$FCL_IKE2|$F1$PI hope Ranulf and the others are all right.$w4
They behaved as if nothing had happened,
but...$w4I could sense they were in pain.$K
$F3$PThat dungeon was the most vile thing I
have ever seen.$w4 I'm glad you weren't there.$K
$F1$PWas it that bad?$K
$F3$PIt was barbaric beyond description... There
were more laguz corpses than we could
count...$K$PThey had been tortured... Twisted and
warped beyond recognition.$K
$F1$P...$K
$F3$PWhy would Ashnard do such things?
What could be his purpose here?$K
$F4$PEna.$K
$F0$P$Fd...$w4The king $w2called powerful beorc to his
cause. But he had to see if they
were worthy.$K
He would test them by pitting them against
those laguz.$K$PAshnard considers laguz to be tools in
service to his own mad ends. Nothing more.$K$PThey are instruments to be used as he sees
fit.$w4 I heard that he ordered his scholars$w4
to perform all kinds of experiments...$K$PThey used elixirs $w2to drive them mad$w2
and keep them locked in their changed
states...$K$PTheir life spans were much shortened,$w4
but for a brief time, they became extremely
powerful...$w4$Fcthey...$K
$F1$P...$K
$F3$P...$w5Thank you $w2for telling us.$K$PThanks to you, $w2we found Leanne.$w4
You're free now. $w2You can do whatever
you like.$K
$F0$P...I will go to the capital.$w4 Please accept me
into your army.$K
$F3$PYou don't have to do that.$w4 Fighting against
your former companions could prove
difficult.$K
$F0$P$FdTake me with you.$w4 There is$w2 something that
I have to do.$w4 Please, Master Ike.$K
$F4$PI ask it of you as well. Please.$K
$F3$P...I understand.$w4 Let's fight together.$K
$=1000    $R�w�i��b|$B�V��-��|$<$F3$FCL_IKE2|$F1$FCL_CRIMEA1|$F1$PGeneral Ike, $w2the army has arrived at
the outskirts of Melior.$K$PWe await your deployment orders, sir.$K
$F3$PVery well. Tell the men to stand down
and await my command.$K
$F1$P...At last, $w2we face the king of Daein.$K
$F3$PYes...$w4 The war $w2is coming to an end.$K
$F1$PIt appears so.$K
$F3$PHm?$w4 Is there $w2something bothering you?$K
$F1$PNo, $w2of course not.
It's nothing like that.$K
But...$K
$F3$PBut what?$K
$F1$PSome...$w4 Some of the soldiers are saying
that when the war's over, $w2their chances
for promotion will dry up.$K
$F3$PThey want to continue fighting?$w4 Even
though Crimea--$w2and Daein, too--$w3
have suffered so much?$K
$F1$PNo, $w2that's not what I mean...$w4
I apologize. I will go inform the men.$K$F1$FD
$F3$P...$K
$=2000 $R�w�i��b|$B�V��-��|$<$F3$FS$F3$FCL_TANIS|$F3$PWell done!$w4 You've improved dramatically
in a very short period of time.$K
$F1$FCL_ERINCIA2|$F1$PDo $w2you think so?$K
$F3$PI $w2do not know how to lie or offer
false praise.$K$PI am deputy commander of the apostle's
bodyguards.$K$PIf you were not destined for greater things,
I would petition the apostle herself
for your enlistment.$K
$F1$P$FSOh, $w2thank you!$w4 I can't believe it myself.$K$PIf not for your instruction, Tanith...$w3
This would not be possible.$K
$F3$PTraining new recruits $w2has long been my
duty. And yet...$w2I believe this is the first
time anyone has been so appreciative.$K$PMy other pupils commonly referred to me as
the Great Demon.$w3 Isn't that so, Marcia?$K
$F0$FCL_MARCIA|$F0$PGreat Demon? Mutton chops, no!
D-don't be silly!$K$FS
We all adored our sincere and devoted
deputy commander. Great Demon. Pfff!
More like Great...uh...$w4Angel...Lady...$K
$F3$PHa!$w3 Sure.$K$FA$PSeriously though,$w4 you've improved
so much, Princess...$w4 Perhaps we should
try something special...$w2$K
$F0$P$FAWhat? $w2N-not that!$w4 She's not ready for that!
You're crazy!$K
$F1$PTanith,$w3 I...$w2I'm not sure that I'm ready...$K
$F3$PListen to me, $w2Princess.$w4 The foes we are
facing$w3 are Daein's elite troops,
led by King Ashnard himself.$K$PHow do you expect to fight them$w3 without
at least one killing attack under your belt?$K
$F1$P...$K
$F0$P$FSYou do it, Deputy Commander,$w3 and we'll
keep practicing.$w4 Right, Princess Elincia?$K
$F1$PI...$w3 I will try it.$K
$F0$P$FAWhaaaaat?!$K
$F1$PI want...to grow stronger.$w4 To reach that
goal,$w2 I will do whatever it takes.$K
$F3$PWell spoken!$w4 Now then...$w3to match your
desire, $w5I will fall back on the methods I
used$w2 while training the apostle's bodyguards.$K
$F1$PAll...right...$K
$F0$POh, horsemeat...$K
$F3$PCome,$w3 we have little time for niceties.$w4
Both of you, follow me! $w2Now!!!$w3 Come on,
maggots, do you want to live forever?!!!$K
$F1$P$FoY-yes, $w2ma'am!$K
$F0$P$FhUgh...$w4 She really is a demon.$K
$=0700   $R�w�i��b|$B�V��-��|$<$F3$FCL_IKE2|$F3$PHmm... The three of them look...busy...$w4
I think I'll wait until later $w2to talk to them.$K $R�w�i��b|$B�V���l�p-��|$<$F1$FCL_SENERIO|$F3$FCL_IKE|$F1$PIke,$w3 I'd like to report the results
of our last battle.$K$N$UB$H   $F3$P$FcI see.$K$P$UB$H $F1$P$FSThere were no deaths $w2and no injuries
beyond our capabilities to heal.$w4
Everyone performed exceedingly well.$K$P$UB$H   $F1$PThat is all.$w4 By your leave,$w2
I will excuse myself.$K    F      F�   	  G<     H   "  H�   .  H�   :  I@   F  I�   R  E�   \  ]�   m  [    {  \�   �  I�   �  Rl   �  ^    �  dl   �  k   �  =�   �  ?p   �  B8   �  C  	          )  n<  9  vL  G  (  W  H  d  	�  r  H    !�  �  1p  �  7L  �  4@  �  :�  �  �  �  0  �  +  �  v�  �  wX    w�    wp  %MS_30_BT MS_30_BT_IKE MS_30_BT_R1 MS_30_BT_R2 MS_30_BT_R3 MS_30_BT_R4 MS_30_BT_RI MS_30_DIE MS_30_DIE_TIBARN MS_30_ED_00XX MS_30_ED_00X_A MS_30_ED_00X_B MS_30_ED_00_A MS_30_ED_00_B MS_30_ED_03 MS_30_ED_03_B MS_30_ED_04 MS_30_EV_05_01 MS_30_EV_05_02 MS_30_EV_06_01X MS_30_EV_06_02X MS_30_GMAP_A_01 MS_30_GMAP_B_01 MS_30_INFO_05 MS_30_INFO_05_2 MS_30_OP_01A MS_30_OP_01AB MS_30_OP_01B MS_30_OP_02A MS_30_OP_02B MS_30_OP_03X MS_30_OP_03X_1 MS_30_OP_03X_2 MS_30_OP_03X_3 MS_30_OP_X MS_30_OP_X2 MS_30_OP_XX MS_30_REPO_BEGIN MS_30_REPO_DIE MS_30_REPO_END MS_30_REPO_NODIE 