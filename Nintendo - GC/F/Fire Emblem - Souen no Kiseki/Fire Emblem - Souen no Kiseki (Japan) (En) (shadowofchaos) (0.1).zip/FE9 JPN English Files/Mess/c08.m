  m  g�       =                $R�w�i��b|$B�X�̑O|$<$F3$FCL_IKE|$F3$PThey're not here either$MC...$MD$w2$K
$F1$FCL_SENERIO|$F1$PIke, $w2pursuing them any farther may
be dangerous.$w4 I think it would be best$w2
if we returned to Gallia for now.$K$PIt's possible the commander$w2 may
have followed another road into Gallia.$w3
It's something we should consider.$K
$F3$P$MC...$MDYou're right.$w4 Getting killed looking
for them would waste $w2everything
they accomplished by breaking away.$K$PI guess all we can do $w2is trust that
they're well $w2and withdraw.$K
$F0$FCL_TIAMAT|$F0$PIke, $w2there's a fort over there.$w4 Just
now, for a moment only$MC...$MD$w2 I thought
I saw someone. $w4Shall we investigate?$K
$F3$PWhat? $w3Really?$w5
Yes, $w2let's go take a look.$K  $R�w�i��b|$B���-��-�r|$<$F3$FCL_IKE|$F4$FCL_SENERIO|$F4$PIt seems as though this place has
been abandoned for a long time.$K
$F4$FD$F4$FCL_TIAMAT|$F4$PThere's no one here$MC...$MD$w4 Hm. I could've
sworn I saw a silhouette, but$MC...$MD$w3
I guess it was a trick of the light.$K
$F3$PLet's take a quick look around.$w3
If we don't find anything here,
we'll head back to Gallia.$K
$F4$PVery well$MC...$MD$K
$Ub$H$F1$FCL_DAYNE2|$F1$PHere they are!$w3 I've found the
Crimean mercenaries!$K
Surround them!$K
$F3$PCurses! $w3Daein troops$MC...$MD$K   $R�㉺��b|$c0SENERIO|$s0It seems as though this place has
been abandoned for a long time.$K    $R�㉺��b|$c1TIAMAT|$s1There's no one here$MC...$MD$w4 Hm. I could've
sworn I saw a silhouette, but$MC...$MD$w3
I guess it was a trick of the light.$K
$c0IKE|$s0Let's take a quick look around.$w3
If we don't find anything here,
we'll head back to Gallia.$K
$s1Very well$MC...$MD$K   $R�㉺��b|$c0DAYNE2|$s0Here they are!$w3 I've found the
Crimean mercenaries!$K
Surround them!$K    $R�㉺��b|$c1IKE|$s1Curses! $w3Daein troops!$K $R�㉺��b|$c0IKE|$s0Titania! $w3Are you all right?$K
$c1TIAMAT|$s1Ooh$MC...$MD$K
I think I can move, $w2but$MC...$MDthere's
no way$w5 I can fight$MC...$MD$K
$s0Get yourself to safety, then,$w2
and wait until this is all over.$K
$s1I understand.$w4 Watch your back, $w2Ike$MC...$MD$K $R�㉺��b|$c0IKE|$s0Soren!$K
$c1SENERIO|$s1I'm sorry, Ike.$w4 I don't think I can
fight anymore.$K
$s0That doesn't matter, not as long as
you're still alive.$w4 Find someplace
out of harm's way, $w4understood?$K
$s1I'll do that.$w4
And, Ike$MC...$MD$w4watch yourself$MC...$MD$K  $R�㉺��b|$s0$FS$c0PRAGUE|$s0Ha ha ha$MC...$MD$w2 Found you at last.$w4
You provided more entertainment
than I thought you would.$K
$c1IKE|$s1Who are you?$K
$s0Me? I am General Petrine, and my
arrival marks your doom.$K$PLament your fortune,$w3 dear children,$w4
for all hope is lost.$w4 You will not
leave this place alive.$K
$d1$d0$c1SENERIO|$s1Petrine$MC...$MD$w4 Of the Four Riders
of Daein?$K
$c0IKE|$s0Do you know her, Soren?$K
$s1If she's who I think, then she's one
of the four generals who are King
Daein's most trusted confidants.$K$PShe is said to wield a flame lance$w2
of terrible arcane might.$K$P$d0$d1$s0$FS$c0PRAGUE|$s0Ha ha ha$MC...$MD$w3 You've heard of me?
Why,$w2 I'm flattered.$w4 I'll try to
make this easy on all of you.$K$PGive me the princess, $w2and do it now.$K$PIf I roast the girl along with you curs,$w2
I won't be able to present her head
to His Majesty.$K
$c1IKE|$s1Sorry to tell you this, $w2but the princess
isn't here.$w4 She's been in Gallia for
quite some time now.$K
$s0$FAWhat$MC...$MD$w2nonsense is that?$w4
Do you expect me to believe you?$K$PThere's no way $w2mercenary scum like
you could get past my troops!$K
$d1$c1GREIL2|$s1They say that blind arrogance$w2 sows
the field of its own destruction.$K$PSomething tells me they were
talking about you.$K
$s0Who$MC--$MD$K   $R�㉺��b|$s0$FS$c0PRAGUE|$s0Ha ha ha$MC...$MD$w2 Found you at last.$w4
You provided more entertainment
than I thought you would.$K
$c1IKE|Who are you?$K
$s0Me? I am General Petrine, and my
arrival marks your doom.$K$PLament your fortune,$w3 dear children,$w4
for all hope is lost.$w4 You will not
leave this place alive.$K
$d1$d0$c1SENERIO|$s1Petrine$MC...$MD$w4
Of the Four Riders?$K
$c0IKE|Do you know her, $w2Soren?$K
$s1She may be one of the four
generals who are King Daein's
most trusted confidants.$K$PShe is said to wield a flame
lance$w2 of terrible arcane might.$K
$d0$d1$s0$FS$c0PRAGUE|$s0Ha ha ha$MC...$MD$w3 You've heard of me?
Why,$w2 I'm flattered.$w4 I'll try to
make this easy on all of you.$K$PGive me the princess, $w2and do it now.$K$PIf I roast the girl along with you curs,$w2
I won't be able to present her head
to His Majesty.$K
$c1IKE|$s1Sorry to tell you this, $w2but the princess
isn't here.$w4 She's been in Gallia for
quite some time now.$K
$s0$s0$FAWhat$MC...$MD$w2nonsense is that?$w4
Do you expect me to believe you?$K$PThere's no way $w2mercenary scum like
you could get past my troops!$K
$d1$Ub$H$c1GREIL2|$s1They say that blind arrogance$w2 sows
the field of its own destruction.$K$PSomething tells me they were
talking about you.$K
$s0Who$MC--?$MD$K $R�㉺��b|$s0$FS$c0PRAGUE|$s0Ha ha ha$MC...$MD$w2 Found you at last.$w4
You provided more entertainment
than I thought you would.$K
$c1IKE|$s1Who are you?$K
$s0Me? I am General Petrine, and my
arrival marks your doom.$K$PLament your fortune,$w3 dear children,$w4
for all hope is lost.$w4 You will not
leave this place alive.$K
$s1Petrine?$K Is that supposed to mean
something? You must be one of
Daein's generals, huh?$K
$s0$FAAre you saying you don't know me?$w3
You anger me, boy, you know that?$K
$FSNo time for a lesson now, though.$w4
Give me the princess, $w2and do it now.$K$PIf I roast the girl along with you curs,$w2
I won't be able to present her head
to His Majesty.$K
$d1$c1IKE|$s1Sorry to tell you this, $w2but the princess
isn't here.$w4 She's been in Gallia for
quite some time now.$K
$s0$FAWhat$MC...$MD$w2nonsense is that?$w4
Do you expect me to believe you?$K$PThere's no way $w2mercenary scum like
you could get past my troops!$K
$d1$Ub$H$c1GREIL2|$s1They say that blind arrogance$w2 sows
the field of its own destruction.$K$PSomething tells me they were
talking about you.$K
$s0Who$MC--$MD$K   $R�㉺��b|$c1IKE|$s1Father!$K
$c0GREIL|$s0What're you doing back here,$w2
you dumb pup?$K
$s1We got $w1the princess safely$w2
into Gallia.$K$PWhen you didn't rejoin us, we decided
to look for you. The mission wouldn't
be complete until you returned.$K
$s0$MC...$MDWhat am I to do with you?$K
$FSStill, $w2you did well.$w4
Good work, Ike.$K
$d0$d1$c0PRAGUE|$s0Ha!$w5$FS Ignoring me proves you've
got more guts than common sense.$K$PSo you're the commander, eh?$w5 Hmph!
$w3And I was $w3waiting for some great
hero.$w2 You're just another sellsword.$K
$c1GREIL|$s1$FAAm I?$K
$s0$FSHa ha.$w3 You know, I think I'll
keep you!$K$PHis Majesty, $w2well$MC... $MD$w1Let's just say$w1
he enjoys strong men.$w5 Yes, $w2I do
think you'll make a grand souvenir.$K$PYou don't have to come along quietly,$w4
but I must have you alive.$w2 Dead
men have no value, after all.$K
$s1$MC...$MDSo the rumors of mad King
Ashnard's twisted games $w3are
true, are they?$K
$d0$d1$c0GATRIE|$s0Shinon$MC...$MD$w2 What are these "twisted
games" the boss is talking about?$K
$c1CHINON|$s1There's rumor that King Daein gathers
strong men from around the continent$w2
and sets them to fight one another.$K$PThose who live, $w2regardless of their
birth, are given influential positions.$w4
Don't know if it's true, though.$K
$s0Oh$MC...$MD$w3 So that weird dame's got her
eye on the boss now, does she?$K
$d1$c1GREIL|$s1Shinon! $w2Gatrie!$w4
I'll distract the woman.$K$PYou two $w2grab Ike and the
others $w2and get out of
here now!$K
$d0$c0CHINON|$s0Got it!$K
$d1$c1GATRIE|$s1But, Commander!$w3 We can't leave
you here$w2 on your own!$K
$s0Idiot! $w3That woman's$w1 no threat
to the commander.$w2 All right?$w4
Come on! $w1Let's go!$K$d0
$d1$c1GREIL|$s1Move it! $w4We'll regroup in Gallia!$K
$s0$FS$c0PRAGUE|$s0You'll not escape me.$w5 Not you$w3
or your little friends.$w5 You're far too
tasty a treat to pass up.$K
$s1You said your name was Petrine,$w2 is
that right?$w5 Listen up.$w2 This place
is nowhere near big enough.$K$PThere's not enough room for a true
contest between the two of us.$w4
I'm going elsewhere. $w4You coming?$K
$s0Do you actually think I'm going to
fall for such a simple ruse?$K
$s1$FSYou and I, $w2we've got more power than
the average person.$w4 We don't come
across a chance like this too often.$K$PI'd like to flex my muscles$w2 without
any distractions getting in the way.$w3
You?$K
$s0Ha ha$MC... $MD$w3You really do know how
to sweet talk a girl, don't you?$w5
All right, $w2I'm coming.$K
$s1Over here.$K$d1
$s0All right, men.$w3 I'm leaving
you in charge here.$K$PDon't let even one of these$w2
Crimean vermin escape!$K$PUnderstood? $w3I want them
exterminated by the time I return.$K    $R�㉺��b|$c1IKE|$s1Father!$K
$c0GREIL|$s0What're you doing back here,$w2
you dumb pup?$K
$s1We got $w1the princess safely$w2
into Gallia.$K$PWhen you didn't rejoin us, we decided
to look for you. The mission wouldn't
be complete until you returned.$K
$s0$MC...$MDWhat am I to do with you?$K
$FSStill, $w2you did well.$w4
Good work, Ike.$K
$d0$d1$c0PRAGUE|$s0Ha!$w5$FS Ignoring me proves you've
got more guts than common sense.$K$PSo you're the commander, eh?$w5 Hmph!
$w3And I was $w3waiting for some great
hero.$w2 You're just another sellsword.$K
$c1GREIL|$s1$FAAm I?$K
$s0$FSHa ha.$w3 You know, I think I'll
keep you!$K$PHis Majesty, $w2well$MC... $MD$w1Let's just say$w1
he enjoys strong men.$w5 Yes, $w2I do
think you'll make a grand souvenir.$K$PYou don't have to come along quietly,$w4
but I must have you alive.$w2 Dead
men have no value, after all.$K
$s1$MC...$MDSo the rumors of mad King
Ashnard's twisted games $w3are
true, are they?$K
$d0$s1Ike!$w2 I'll distract the woman.$K$PTake the others $w2and get out of
here now!$K
$c0IKE|$s0But, Father$MC...$MD$K
$s1I thought I told you there was
nothing to worry about.$K
Now move!$w4 We'll regroup in Gallia!$K
$d0$s0$FS$c0PRAGUE|$s0You'll not escape me.$w5 Not you$w3
or your little friends.$w5 You're far too
tasty a treat to pass up.$K
$s1You said your name was Petrine,$w2 is
that right?$w5 Listen up.$w2 This place
is nowhere near big enough.$K$PThere's not enough room for a true
contest between the two of us.$w4
I'm going elsewhere. $w4You coming?$K
$s0Do you actually think I'm going to
fall for such a simple ruse?$K
$s1$FSYou and I, $w2we've got more power than
the average person.$w4 We don't come
across a chance like this too often.$K$PI'd like to flex my muscles$w2 without
any distractions getting in the way.$w3
You?$K
$s0Ha ha$MC... $MD$w3You really do know how
to sweet talk a girl, don't you?$w5
All right, $w2I'm coming.$K
$s1Over here.$K$d1
$s0All right, men.$w3 I'm leaving
you in charge here.$K$PDon't let even one of these$w2
Crimean vermin escape!$K$PUnderstood? $w3I want them
exterminated by the time I return.$K $R�㉺��b|$c1IKE|$s1We join up with Shinon,$w3
and we get out of here!$K
Come on, $w2don't fall behind!$K  $R�㉺��b|$c1IKE|$s1We join up with Shinon,$w3
and we get out of here!$K
Come on, $w2don't fall behind!$K  $R�㉺��b|$c1IKE|$s1We're all breaking out of here!$K
Come on, $w2don't fall behind!$K $R�㉺��b|$s0$FS$c0WAYU|Uh-oh. $w4Daein soldiers here, too.$K$PNow, $w2where's that exit$MC...$MD$w4
$FAHm?$w5 What's that sound?
Someone...fighting?$K    $R�㉺��b|$c0BARUMA|$s0How goes the battle?$K
$c1DAYNE2|$s1There aren't very many of those
mercenaries,$w2 but they're fierce.$K
$s0And you're having a rough time, eh?$w4
Bah! $w2What an embarrassment.$K
$s1I$w2 apologize$MC...$MD$K
$s0It will work out. $w4Reinforcements$w3
will be arriving soon.$K$POnce they're here, $w3I want you to
end this farce at once!$K
$s1Yes, sir!$K  $R�㉺��b|$c0IKE|More enemy troops$MC...$MD$K  $R�㉺��b|$s0$FS$c0WAYU|$s0Your name wouldn't happen to
be $w1Ike, $w3would it?$K
$c1IKE|$s1It is, but$MC...$MD$w3who are you?$K
$s0I'm Mia.$w4 I'm a mercenary, hired by
Crimea to bolster the army's numbers.$K
$s1An army mercenary, huh? $w1So,$w2
uh,$w2 what are you doing here?$K
$s0I got careless and was captured.$w4
They were about to send me to a
prison camp $w3when Greil saved me.$K
$s1You've seen my father?$w3
Where?$K
$s0Just a little bit north of here.$w3
Not too far away, though.$K
$s1Really?$w4$FS So he's safe$MC...$MD$K$FA
$s0Tell me, $w2who exactly$w3 are you guys?$K
$s1We're the Greil Mercenaries.$w4
As you can see, $w2we're fighting
against Daein.$K
$s0Huh$MC...$MD$w2 You're taking on a whole
Daein battalion$w2 with these numbers?$w4
Nice. $w3That settles it then!$K
$s1Settles what?$K
$s0This battle. $w2I'm coming in on
your side.$w4 You don't mind, do you?$K
$s1It's fine with me, but$MC...$MD$w4
I don't know if you'll get paid$w3
just because I let you fight.$K
$s0We'll worry about the details later!$w5
Great,$w2 so that's all taken care of.$w3
What next, $w2boss man?$K   $R�㉺��b|$s0$FS$c0WAYU|$s0Your name wouldn't happen to
be $w1Ike, $w3would it?$K
$c1IKE|$s1It is, but$MC...$MD$w3who are you?$K
$s0I'm Mia.$w4 I'm a mercenary, hired by
Crimea to bolster the army's numbers.$K
$s1An army mercenary, huh? $w1So,$w2
uh,$w2 what are you doing here?$K
$s0I got careless and was captured.$w4
They were about to send me to a
prison camp $w3when Greil saved me.$K
$s1My father saved you? Interesting.$K
$s0So... Who are you guys?$K
$s1We're the Greil Mercenaries.$w4
As you can see, $w2we're fighting
against Daein.$K
$s0Huh$MC...$MD$w2 You're taking on a whole
Daein battalion$w2 with these numbers?$w4
Nice. $w3That settles it then!$K
$s1Settles what?$K
$s0This battle. $w2I'm coming in on
your side.$w4 You don't mind, do you?$K
$s1It's fine with me, but$MC...$MD$w4
I don't know if you'll get paid$w3
just because I let you fight.$K
$s0We'll worry about the details later!$w5
Great,$w2 so that's all taken care of.$w3
What next, $w2boss man?$K  $R�㉺��b|$c0IKE|$s0Well met, $w2Shinon. Are you
unharmed?$K
$s1$FS$c1CHINON|$s1Do I look injured? I'm as fit as ever.$w4
You must be disappointed Daein hasn't
stuck me full of holes yet.$K
$s0$MC...$MD$K
$s1Guess it's time to tighten our belts$w2
and move on.$K$PNow that I'm gonna be dragging your
worthless carcass around again,$w4
I'll have to work twice as hard.$w2$K   $R�㉺��b|$c0IKE|$s0Gatrie!$K
$s1$FS$c1GATRIE|$s1Hey, $w2is that you, Ike?$w5 I heard
you got the princess to Gallia.$w4
Nice work! $w3You're quite the hero.$K$P$MC...$MD$FABut wait!$w4
So what in blazes are you
doing back here?$K
$s0You'll think it foolish,$w2 but I
was worried about all of you.$K
$s1$FSAww$MC...$MD$w5 You're going to make me cry,$w2
you silly pup!$K$PAll right$MC...$MDsniff$MC... $MDGet it together,
Gatrie.$w4 Tonight, $w2you and I will
share a meal $w2and sing a song or two!$K  $R�㉺��b|$c0WAYU|Awrr$MC...$MD$w3 My blade$MC...$MD$w2
was$MC...$MDnot$MC...$MDenough$MC...$MD$K  $R�㉺��b|$c0BARUMA|Hmph. $w2You wretches$MC...$MD$w3
You're not worthy of$w2
General Petrine's attention.$K$PI will roast your bones $w2and present
them to her as a trophy!$K    $R�㉺��b|$c0IKE|$s0Whoa!$w3 So you're a mage, are you?$K
$c1BARUMA|$s1I am, vermin, $w2and I will see
you burn to cinders!$K  $R�㉺��b|$c0BARUMA|Ur$w2gg$MC... $MD$w3Ahh$MC...$MD$K $R�w�i��b|$B���-��-�r|$<$F3$FCL_IKE|$F3$PI have to find my father.$w4
Where did he go?$K  $R�㉺��b|$c0IKE|Titania!$w4
Is my father$MC...$MD$K
$c1TIAMAT|$FSDon't worry.$w4 Commander Greil's the
better fighter. He'll be fine.$K   $R�㉺��b|$c0PRAGUE|$s0Dog's breath! Who are you, man?$w4
You look like a common sellsword,$w2
but you fight like a demon!$K
$s1$FS$c1GREIL|$s1What's wrong?$w2 Ready to surrender?$K
$d1$s0And admit defeat?$w4
Me? $w3Don't be absurd$MC...$MD$K $R�㉺��b|$c0DAYNE2|$s0Here they are!$w4
Over here!$K  $R�㉺��b|$c1IKE|$s1Blast. $w2Enemy reinforcements!$K$PFather! $w2Let's get out of here!$w3
There are too many$MC--$MD$K
$c3GREIL|$s3$MC...$MDLooks like I've got no choice.$K $R�㉺��b|$c1PRAGUE|$FSHa ha ha ha$MC...$MD$w4 So now, the
tide has turned, $w2hasn't it?$K    $R�㉺��b|$c0PRAGUE|All troops, $w2attack!$w4
Kill them! Kill them all!$K  $R�㉺��b|$c0GREIL|$s0Hm$MC...$MD$w2 Looks like our luck's run out.$K
$c1IKE|$s1Father!$K
$s0You have to survive this, $w2Ike.$K$PI'm not going to lose you,$w2 not
in this place.$w5 Are you ready?$K
$s1Yes, Commander!$K
$d0$d1$s0$FS$c0PRAGUE|$s0You've nowhere to run.$w6
Curse whatever gods you hold,$w2
for they have abandoned you!$K $R�㉺��b|$c1IKE|What was that?$K  $R�㉺��b|$c0DAYNE1|$s0B-b-$w2beasts!$w4
Gallian beast soldiers!$K
$c1DAYNE2|$s1R-r-$w2run!$w4 We're going to
be torn to shreds!$K $R�㉺��b|$c1PRAGUE|$s1Stand your ground, $w4all of you!$w4
Don't panic!$K$PI will personally slaughter$w2 the first
man to turn his back on the enemy!$K
$c0DAYNE2|$s0Noooo!$K    $R�㉺��b|$c0DAYNE1|B-$w2b-$w2beasts!$K    $R�㉺��b|$c0PRAGUE|Pfeh.$w4 Worthless cowards,
one and all.$K $R�㉺��b|$c0LAY|Attention, Daein soldiers!$w4
Leave this place at once!$K$PIf you do not comply immediately,$w2
you will face Gallia's full strength!$K   $R�㉺��b|$c0PRAGUE|Threaten me all you like.$w5
It's not going to frighten me off.$K$PIf I leave, $w2His Majesty will have
me executed.$w4 I'd rather die here
in battle, with my honor intact.$K $R�㉺��b|$c1DARKKNIGHT|$s1Withdraw, $w2General Petrine.$K
$c0PRAGUE|$s0The Black Knight$MC...$MD$K
$s1As for your king,$w2 you have nothing
to fear.$w4 I'll explain things to him.$w4
Take your men $w2and go.$K
$s0Tsk!$K$PAll troops, fall back!$K $R�㉺��b|$c0DARKKNIGHT|$s0$MC...$MD$K
$c1GREIL|$s1Hm?$K
$c3IKE|$s3He's staring at you, $w2isn't he, Father?$K
$s1Yeah. He is.$K   $R�㉺��b|$c0LAY|Hey!$w4 Are you planning on taking
us all on by yourself?$K
$c1DARKKNIGHT|$MC...$MD$K$d0  $R�㉺��b|$c0GREIL|$MC...$MD$K
$c1IKE|Father?$K    $R�w�i��b|$B���-��-��|$<$F3$FCL_IKE|$F4$FCL_GREIL|$w6$F1$FS$F1$FCL_MIST|$F1$PFather! $w4Brother!$K
$F3$PMist!$K
$F0$FCL_ERINCIA|$F0$P$FSMaster Greil, $w2my lord Ike$MC...$MD$w3
I am pleased you are well.$K
$F3$PPrincess Elincia$MC...$MD$w4
Why did you return here?$K
$F1$FD$F0$FD$F0$FS$F0$FCL_LAY|$F0$PThe princess $w2came and requested
Gallian aid for your mercenary company.$K$PThat is $w2what brings us here.$K
$F3$PAre you $w2one of Gallia's$w4
sub-humans?$K
$F0$P$FASub-human?$w4 Ha! $w2What arrogance
it takes to coin such a name!$K$PYou think yourselves the only ones
worthy of the name "human," and so$w2
we laguz must be beneath you?$K$PAnd thus you call us "sub-human." We
are less than human to you, is that it?$K
$F3$PI'm sorry$MC...$MD$w2 I don't know any other
name for you.$w4 If I have offended
you,$w2 I apologize.$K$PWhat should I call you? Laguz?$w4
Would that be more appropriate?$K
$F0$P$FSHuh?$w4 You show manners?$w4
How odd.$w4 I like that.$K$PNow, $w2you are$MC...$MD$w4 Who, exactly?$K
$F3$PMy name is Ike.$w4
Ike of the Greil Mercenaries.$K
$F0$PI'm Ranulf, $w2a warrior of Gallia.$K$PWe did not know what to think$w2 when
this group of beorc$w2 came tramping
through Gallian fields$MC...$MD$K$PImagine our surprise to learn that one of
them is Princess Elincia.$K$PNow, that was a shock. $w4Two days ago,
Daein proclaimed their conquest.$w2 We
thought Crimea's royals had all been killed.$K
$F3$PConquest? They've laid claim to Crimea?$w4
So $w2that means Crimea must be$MC...$MD$K$P$Ub$H$F0$P$FA$F1$FCL_ERINCIA|$F1$PI$MC...$MD$w2also heard this news from my
lord Ranulf$MC...$MD$K$PAfter$MC...$MD$w2after I fled the capital$MC...$MD$w4
My lord uncle Renning$MC...$MD$w4$Fc He$MC...$MD$K$PI$MC...$MD$w4I am$MC...$MD$w3all alone.$K
$F3$PPrincess Elincia$MC...$MD$K$F1$FD
$F0$PThis is why $w2our king $w2ordered
extra patrols along the nation's border.$K$PIt wasn't mere chance$w2 that brought
my warriors here to offer you support.$K
$F3$P$w2I see$MC...$MD$K
$Ub$H$F0$P$FSFirst of all, $w2I must present Princess
Elincia $w2to the king.$K$PAs for the rest of your men, $w4Ike,$w2 I must
get orders from my superiors.$w2 Until then
you may rest at an old castle inside Gallia.$K$PSorry, but $w3I cannot bring so large a group
of foreigners to the palace$w2 without warning.$K
$F3$PI understand.$w4 Commander, that's
not going to be a problem, is it?$K
$F4$P$MC...$MD$K
$F3$PCommander?$K
$F4$PHm? $w4What was that?$K
$F3$PWhat's wrong? $w2You're not paying
attention. $w4It's not like you.$K
$F4$PI was thinking about something.$w4
So, $w2what's been decided?$K
$F3$PPrincess Elincia is $w2going on to the
palace with Ranulf.$K$PWe're going into Gallia $w2and setting up
camp at an old castle.$w4
Which way to this castle, $w3Ranulf?$K
$F0$PI shall prepare a guide to take you.$K$POne of you! Quickly!$K
$F4$PNo, don't go to the trouble. $w4If it's nearby,$w2
we cross the river on the border and
head west.$w2 It's Gebal Castle, right?$w4$K$PYou go ahead. $w2Get the princess$w2 to
King Caineghis as fast as you can.$K
$F0$P$MC...$MDUnderstood. $w2What thoughtful guests
you are. $w4If you'll excuse me.$K$POh, and if it's not overly presumptuous,$w2
I'll have food delivered to you later.$K
$F4$P$FSWe'd appreciate it. The road has been
hard,$w2 and we had little time to pack more
than salted meat and hard biscuits.$K
$F0$PThen we shall provide!$w2
Princess Elincia,$w4 shall we leave?$K$P$F1$FCL_ERINCIA|Farewell, $w2everyone$MC...$MD$w4
Until later.$w5
I will see you soon, won't I?$K
$F4$PMm.$K
$F3$PTake care.$K
$=1500   $R�㉺��b|$c0IKE|$s0Father!$K
$c1GREIL|$s1Ike? $w4What are you doing
still awake?$K
$s0I couldn't sleep, $w2so I was
lying there staring outside,$w4
and I saw you leave the castle.$K$PWhere are you going at this hour?$K
$s1It's nothing to do with you, boy.$w4
Go back inside and get to sleep.$K
$s0Will you stop treating me like a child?$w4
I'll do as I please, $w2got it?$K
$s1$FSHmph. $w4You always were a
stubborn pup.$w4 What say we
take a walk$w2 and chat a bit?$K
$s0$MC...$MDYeah.$K  $R�㉺��b|$s1$FS$c1GREIL|$s1Tell me, Ike, $w4are you getting used
to the ins and outs of the mercenary
life?$w2 The way we approach combat?$K
$c0IKE|$s0I'm definitely a better fighter.$w4
But $w2I don't understand$MC... $MD$w2Why would
you put a recruit like me in charge?$K
$s1What is it with all the complaining?$w4
You have a problem with authority?$K
$s0Just give me a straight answer.$K$PI've only just started. I'm barely able
to handle my own duties around here.$K$PI shouldn't be in charge of anyone.$K
$s1You can learn it all at once.$w4
It'll all fall into place as soon as
you start to get some experience.$K
$s0It's just strange is all$MC...$MD$w4
A while ago, you never would have
said or done anything like this.$K
$s1$FA$MC...$MD$K
$s0Is something wrong, $w4Father?$w4
Why are you in such a rush?$K
$s1$MC...$MD$K$P$Ub$HIke$MC...$MD$w2 Do you $w2remember anything at
all about your mother?$K
$s0What? $w2Where$w2 did that come from?$K
$s1$FSJust answer the question.$K
$s0Let's see$MC... $MD$w2She was kind,$w4
I$MC...$MDthink$MC...$MD$K$PI don't really remember.$w4 And you've
never said much about her either.$K
$s1Hm. Is that so$MC...$MD$K  $R�㉺��b|$c0IKE|$s0Father? $w4What is it?$K
$c1GREIL|$s1We're done.$w4 Leave me
and go back to the castle.$K
$s0What? $w2Just like that?$K
$s1You heard me. That's a direct order!$w4
Return to the castle immediately!$K
$s0I$MC...$MD$w4 Fine$MC...$MD$w4
$MC...$MD$K$d0
$s1$MC...$MD$K $R�㉺��b|$c1DARKKNIGHT|$s1$MC...$MDUnbelievable.$w4
Is this truly what has become
of my teacher?$K
$c3IKEa|$s3Father! $w4Father!!$K
$s0$Fh$c0GREIL|$s0I$MC...$MD$w4Ike$MC...$MD$K$d0
$s3Hold on!$K$d3
$s1Now then, $w3will you give me
what I came for?$K
$s0$Fh$c0GREIL|$s0I$MC...$MD$w2don't$MC...$MD$w4have it$MC......$MD$w4
$MC...$MD$w2I threw$MC...$MD$w4it away$MC...$MD$K
$s1Ha. $w4You, who knows better than any
what it truly is,$w3 threw it away?$K$PSurely you can craft a more plausible
lie.$w2 You're not even trying anymore.$K
$s0I'm done$w4 talking to you.$K
$s1So there's no way for me to get
my answers,$w2 is that it?$K$PThe dead keep their secrets,$w3 or
so it is said.$w5 But you,$w3 however$MC...$MD$w3
You are not$w3 dead$w3 yet.$K$PI wonder$MC...$MD$w1 Will watching your
son's face $w2grow pale, his eyes
grow dim as his life bleeds away$MC...$MD$K
And then your daughter$MC...$MD$w2
Oh, the horrors I will visit upon her.
Will that loosen your tongue, perhaps?$K$PI suppose we will simply have to see.$K
$c2IKEaa|$s2What?$K
$s0No! $w4Ike!!!$K $R�㉺��b|$c2IKEa|$s2$Fc$MC...$MDUrk$MC...$MD$K$d2
$c0GREIL|$s0Ike!!!$K
$c1DARKKNIGHT|$s1I won't check my hand again.$K$PGive me $w2what I am after.$w5
If you offer no more resistance,$w3
I will leave your child alive.$K
$s0$FhS-stop$MC...$MD$w4 You will not$w3 touch$w4 my son!$K$P $R�㉺��b|$c0DARKKNIGHT|$s0$MC...$MDWhat is this?$w3 The king of beasts?$w5
How bothersome.$w4 Do I retreat?$K$PEh?$K  $R�㉺��b|$c0IKEa|$s0You're not going anywhere.$K
$c1DARKKNIGHT|$s1Tell me, $w2is the son$w2
as stupid $w2as the father?$K $R�㉺��b|$s0$Fc$c0GREIL|$s0$MC...$MDNng$MC...$MD$w2 Ahh$MC...$MD$K
$c3IKE|$s3Father!$K
$s0$FhIke, stop.$w4 There's no
way you can win.$K
$s3But$MC...$MD$K
$s0$FdIke!$K$w4
$c1DARKKNIGHT|$s1You will not continue?$w4
Then $w2I will finish$MC...$MD$K    $R�㉺��b|$c1DARKKNIGHT|$s1$MC...$MDSo close.$K
Now $w3is not the time$w2 for me to
deal with him.$w5 Hmph. $w3You get
to keep your head today, $w2boy.$K  $R�㉺��b|$c0GREIL|$s0Blast.$K $R�㉺��b|$s0$Fh$c0GREIL|$s0So willful. So arrogant$MC...$MD$K$FS$w5$POf course$w3$MC... $MDThe one who$MC...$MD$w4
made him that way$MC...$MD$Fc
was$MC...$MD$w2m-$w4me$MC...$MD$K$d0
$c1IKEa|$s1$MC...$MDFather?$K
Father! $w5Hold on!$K$PI can't do anything here$MC...$MD$w4
I've$MC... $MD$w2I've got to get you back
to the castle!$K    $R�̂݉�b|$F1$FCIKE|$MC...$MDNngh$w4$MC...$MD$K    $R�̂݉�b|$F1$FCGREIL|I-$w1I$w3ke$MC...$MD$K$F1$FD$P$F1$FCIKE|Father? $w3You're awake!$K$F1$FD$P$F1$FCGREIL|I$MC...$MD$w1 There's $w2something$w4
I need $w2to $w3tell you.$K$F1$FD$P$F1$FCIKE|Tell me later.$w4 Right now,$w2 I'm getting
you back to the castle.$K$F1$FD$P$F1$FCGREIL|Forget $w2about $w3revenge...$w4
Leave $w4that knight $w3alone...$w4
Stay $w1away...$K$F1$FD$P$F1$FCIKE|What? $w2Father?$K$F1$FD$P$F1$FCGREIL|Stay $w2with $w4the king of Gallia...$w3
Live$w4 here.$w1 Live$w3 in$w2 peace...$K$F1$FD$P$F1$FCIKE|Father, $w3stop talking.$w4
You're wasting your strength.$w6
Please...$K$F1$FD$P$F1$FCGREIL|I need you$w2 to$w4 take
care$w2 of$w2 everything...$w3$K$PThe company...$w4
Mist$w4...$K$F1$FD$P$F1$FCIKE|Wait...$w3 You mustn't $w4say such things!$K$PIt'll be light soon. $w2You'll be fine...$K $R�̂݉�b|$F1$FCIKE|A little longer$MC...$MD$w5
Stay a little longer$MC...$MD$K
$=2300   9�      :�   	  ;,     9�      ;d   /  ;�   ;  <L   J  =@   Y  =x   j  >(   {  >�   �  >�   �  @$   �  @H   �  @�   �  A�   �  A�   �  A�   �  B�   �  CL    DD    D�     E4  /  Eh  ;  SL  G  U8  S  Y�  _  Z�  k  _   w  `  �  `�  �  a  �  b  �  b�  �  b�  �  d  �  dL  �  gx  �  	L    p    x    �  )  "X  7  *�  E  *�  Q  +d  _  +�  m  ,X  y  -�  �      �  �  �    �  h  �  �  �  �  �    �  4  �  .    2T    6$  !  7�  -MS_08_BT MS_08_BT_IKE MS_08_DIE MS_08_DIE_WAYU MS_08_ED_01 MS_08_ED_01_02 MS_08_ED_02_01 MS_08_ED_02_01_2 MS_08_ED_02_01_3 MS_08_ED_02_02 MS_08_ED_03 MS_08_ED_04_01 MS_08_ED_04_02 MS_08_ED_05_01 MS_08_ED_05_02 MS_08_ED_05_03 MS_08_ED_06 MS_08_ED_07 MS_08_ED_08 MS_08_ED_08_02 MS_08_ED_09 MS_08_ED_09_02 MS_08_ED_10 MS_08_ED_11 MS_08_ED_12 MS_08_ED_13 MS_08_ED_14 MS_08_ED_15 MS_08_ED_17_01 MS_08_ED_17_02 MS_08_ED_18 MS_08_ED_19_01 MS_08_ED_19_02 MS_08_ED_20 MS_08_ED_21 MS_08_ED_22_A MS_08_ED_22_B MS_08_ED_22_C MS_08_EV_01 MS_08_EV_01_A MS_08_EV_01_B MS_08_EV_02_A MS_08_EV_02_B MS_08_EV_03 MS_08_EV_03_A MS_08_EV_03_B MS_08_EV_04 MS_08_EV_05 MS_08_EV_06 MS_08_OP_01 MS_08_OP_02 MS_08_OP_02_01 MS_08_OP_02_02 MS_08_OP_02_03 MS_08_OP_02_04 MS_08_OP_03_01 MS_08_OP_03_02 MS_08_TK_01_01 MS_08_TK_01_02 MS_08_TK_02 MS_08_TK_03 