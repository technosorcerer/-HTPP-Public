  ��  ��       ,                $R�w�i��b|$B�R��-�C����|$<$F3$FS$F3$FCL_TIAMAT|$F4$FCL_IKE|$F3$PThis place brings back such memories.$w4
It hasn't changed in the slightest.$K
$F4$PTitania, $w2have you been to Gallia before?$K
$F3$PA long time ago$MC...$MD$w4
When I was still a knight of Crimea.$K$PI volunteered for a military officer
exchange program $w2and spent some
time studying at Gallia's royal palace.$K
$F4$PI get it now$MC... $MD$w2That's why you weren't
surprised when we saw the laguz.$K
$F3$PThat's right.$K$PAh, I've missed the sea.$w5 When the setting
sun strikes the water,$w2 it's almost as
though the horizon itself is on fire.$K$F3$FD
$F4$PHmm. Now that I think about it, $w2my father
knew where that old castle was$MC...$MD$K$PHe sure acted like someone who'd been
to Gallia before. $w5Was he here with you?$K
$F1$FS$F1$FCL_TIAMAT|$F1$PMm-hm.$w4
And we weren't the only ones.$w4
You've been here, too, Ike.$K
$F4$PWhat?$K
$F7$FCDUMMY|$F7$PIke!$K$F7$FD
$F1$PIt's Mordecai.$w4
You'd better answer him.$K
$F4$PYeah, $w2but$MC...$MD$K
$F1$PWe can finish our talk later,$w2 after
we've reached the castle.$K$F1$FD
$Ub$H$F4$PWell, that was cryptic.$K  $R�㉺��b|$c0IKE|$s0What is it, $w2Mordecai?$K
$s1$FS$c1MORDY|$s1Do you tire?$w4
Should we rest here?$K
$s0$FSNo, I think we're all right.$K
$s1Good.$K    $R�㉺��b|$c1LETHE|$s1Beorc are such a weak species.$K$PA distance like this is nothing.$w5
Any laguz worth his claws could
cross it$w2 in a single bound.$K
$c2MORDY|$s2Lethe!$K
$s1Hmph!$w4
It is the truth!$K
$s2If you persist in this way,$w2
you will shame the king.$w4
You sound like a fool.$K
$s1Hsss! $w2You are my subordinate!$w3
Never speak to me in such a way!$K
$s2What's wrong $w2is wrong.$K$PYou $w2are a fierce warrior, Lethe,$w3
but when it comes to the beorc,$w2
you are far too stubborn.$K
$s1What did you say?!$K
$c0IKE|$s0Come on now,$w3
both of you$MC...$MD$w2
Let's calm down.$K   $R�㉺��b|$c1LETHE|$s1$Fh$MC...$MDMordecai?$K
$c3MORDY|$s3$MC...$MDWait$MC...$MD$K
$c0IKE|$s0What is it?$K
$s3That smell on the wind$MC...$MD$w6
It's iron.$K$P$Ub$HIt is the smell of weapons.$w2
The smell of beorc.$w5
Heavily armored. Well armed.$K
$s0Are you sure?$K    $R�㉺��b|$c1DAYNE1|$s1General Kotaff!$w4
The Crimean mercenaries$w2 have
entered our area of operations!$K
$s0$FS$c0KOTAHU|$s0Ha!$w3 They're trapped!$w5
$FACall every last man. $w2Ready for battle!$w4
We stop the enemy here!$K    $R�w�i��b|$B�R��-�C����|$<$F3$FCL_IKE|$F4$FCL_SENERIO|$F1$FCL_LETHE|$F0$FCL_MORDY|$F4$PBlack armor$MC...$MD$w2 They're Daein men,
all right.$K
$F3$PYou're saying that some of the invasion
force is still around?$K
$F4$FD$F1$PDaein worms$MC...$MD$w4
They strut about the Gallian forests$w2 as
though they own them.$w5 I won't stand for it!$K
$F0$PGrrr$MC...$MD$w4 The castle to the south.$w5
Many beorc are inside.$K$PThey carry iron weapons.$w4
I$w4 smell them.$K
$F3$PNot good$MC...$MD$w5
Titania!$w4
Gather everyone together!$K
$F4$FCL_TIAMAT|$F4$PHa!$w4 $FSUnderstood!$K$F4$FD$w6
$F1$PWhat now?$K
$F3$PWhat do you mean?$K
$F1$PIf you hope to crush the worms,$w2
you'd do well to capture the ruins
in the south.$K$PSince you probably want to flee,$w2
there is an escape route$MC...$MD$K
$F3$PWe're going to fight.$K
$F1$POh?$K
$F3$PThere are times when running has
its advantages, $w5but I don't
think we'll lose here.$K
$F1$P$MC...$MDI see.$K
$F0$PI will also fight.$K
$F3$PGood. We could use the help.$K
$F0$FD$F1$FD$F4$FCL_TIAMAT|$F4$PIke!$w4
Everyone's here!$K
$F4$FD$F3$PAll right, let's go!$K
$F0$FCL_WEAPON|$F1$FS$F1$FCL_ANTIQUE|$F3$PI want you two to take Mist and Rolf
and retreat to the rear.$K
$F0$POf course.$K
$F1$PWe're counting on you.$w4
Be careful!$K
$F0$FD$F1$FD$F0$FCL_TIAMAT|$F1$FCL_SENERIO|$F3$PEveryone who can fight,
grab a weapon!$K$PGreil Mercenaries$MC...$MD$w4
Move out!$K   $R�㉺��b|$c0MIST|$s0Ike!$K
$c1IKE|$s1Mist!$w4
You and Rolf clear out of here!$w4
Stay back, $w2no matter what!$K
$s0No, $w2Ike!$w4 We're going to
fight with you$MC--$MDboth of us.$K
$s1What?$w4 No.$w4
That's not going to happen.$K$PBe serious, Mist$MC...$MD$w2 The two of you
can't even wield weapons.$K
$s0$FSI've got this!$K
$s1A heal staff?$K
$s0Yeah! $w2I made Rhys teach
me how to use it.$K$PI can heal injuries! $w2I mean, just
little ones, but still$MC...$MD$K
$s1Little ones? No. There's no way I'm
letting you on this battlefield$MC...$MD$w4 Huh?$K $R�㉺��b|$c0MIST|$s0Ike!$K
$c1IKE|$s1Mist!$w4
You and Rolf clear out of here!$w4
Stay back, $w2no matter what!$K
$s0No, $w2Ike!$w4 We're going to
fight with you$MC--$MDboth of us.$K
$s1What?$w4 No.$w4
That's not going to happen.$K$PBe serious, Mist$MC...$MD$w2 The two of you
can't even wield weapons.$K
$s0$FSI've got this!$K
$s1A heal staff?$K
$s0Yeah! $w2I learned to use it
while we were at church.$K$PI can heal injuries! $w2I mean, just
little ones, but still$MC...$MD$K
$s1Little ones? No. There's no way I'm
letting you on this battlefield$MC...$MD$w4 Huh?$K    $R�㉺��b|$c0BOLE|$s0Rolf! Stop being such a brat,$w2
you little twerp!$K
$c1LOFA|$s1I'm going to fight, too!$w4
I'm good with a bow!$K
$s0Really? $w2That's news to me.$w4
Is that the best lie you
could come up with?$K
$s1It's no lie!$K
$c3MIST|$s3That's right! $w2He's not lying.$K
$s0Of course he is!$K
$d0$d3$d1$c0IKE|What are you talking about, Mist?$K
$s1$FS$c1MIST|$s1Rolf's always practicing with his bow.$w2
And he's really good! $w2Aren't you?!$K
$s3$FS$c3LOFA|$s3I sure am!$K
$d3$d1$s0And when did you learn
to use a bow?$K
$c1LOFA|$s1Well, $w2let's see$MC...$MD$w4
Um$MC...$MD$w2 I guess I just$MC...$MDsorta$MC...$MD
picked it up$w5 naturally?$K
$d0$c0BOLE|$s0Stop lying,$w2 you
booger-eating brat!$K$PYou can't just pick up a weapon and
start firing away! Someone has to
teach you the basics!$K
$s1Well, $w2maybe I'm just a prodigy,$w4
'cause I learned it all myself!$K
$d1$s0You little$MC...$MD$K
$c1MIST|$s1You don't know anything, Boyd!$K
$c3LOFA|$s3That's right!$K
$s0$w2This$w3 is$w3 ridiculous!$K
$d0$d3$d1$c0IKE|Enough.$w2 You two go back.$K
$c1MISTs|$s1No! $w2We don't want to!$K$PAll Rolf and I do$w4 is sit and wait
and worry about all of you.$K$PWe're tired of waiting!$w2
We want to fight by your side!$K
$s0Is that so?$K
$d0$d1$c0BOLE|$s0How about it, $w2Rolf?
Is that how you feel, too?$w4$K
$c1LOFA|$s1Uh-huh.$w4 No doubt,$w2
we'd rather be with you.$K
$s0$FhSigh$MC...$MD$K
$d1$s0$FdWhat now, Commander?$K
$d0$c0IKE|$s0We take them with us.$w4
We're too pressed for time to
sit around here bickering.$K$PAnd at least if they're nearby,$w2
they'll be easier to protect.$K
$s3$FS$c3MIST|$s3Are you serious?!$K
$s1$FS$c1LOFA|$s1Yes! $w2You won't regret this,
Ike!$w4 I promise!$K
$d0$s0$FS$c0BOLE|$s0I hope not.$K    $R�㉺��b|$c0OSCAR|$s0Stop this foolishness.$K
$c1LOFA|$s1I'm going to fight, $w2too!$w4
I'm good with a bow!$K
$s0Why would you lie like that?$K
$s1It's no lie!$K
$c3MIST|$s3That's right! $w2He's not lying.$K
$s0Mist?$K
$d0$d3$d1$c0IKE|What're you talking about?$K
$s1$FS$c1MIST|$s1Rolf's always practicing with his bow.$w2
And you're really good! $w2Right?$K
$s3$FS$c3LOFA|$s3I sure am.$K
$d3$d1$s0When did you learn
to use a bow?$K
$c1LOFA|$s1Well, $w2let's see$MC...$MD$w4
Um,$w2 I guess I just$MC...$MDsorta$w4
picked it up$MC...$MD$w5naturally$MC...$MD$K
$d0$c0OSCAR|$s0Listen to me, Rolf.$K$PA weapon is a serious business.$w2
It's not something you just$MC...$MD$w4do.
You have to learn the basics first.$K
$s1In that case,$w4
I must be a prodigy.$K$P'Cause I learned how to do it
on my own!$K
$d1$s0Rolf.$w4 If you don't behave,
I'm going to get upset.$K
$c1MIST|$s1Don't you dare get mad!$K
$c3LOFA|$s3I'm not lying!$w2 I'm not$MC...$MD$K
$s0Oh, great.$K
$d0$d3$d1$c0IKE|$s0Enough.$w2 Head back, you two$MC...$MD$K
$c1MISTs|$s1No! $w2We don't want to!$K$PAll Rolf and I do$w4 is sit and wait
and worry about all of you.$K$PWe're tired of waiting!$w2
We want to fight by your side!$K
$s0I see.$K
$d0$d1$c0OSCAR|$s0$s0How about you, $w2Rolf?
Is that how you feel, too?$w4$K
$c1LOFA|$s1Uh-huh.$w4 Boyd$MC...$MD$w3
He went off to fight,$w5
and he never came back.$K$PIf something happened to you,
Oscar, I'd be all alone$MC...$MD$w4 I$MC...$MD$K
$s0Rolf$MC...$MD$K
$s1So that's why$MC...$MD$w4
That's why we're coming with you!$K
$d1$s0What say you,$w3 Ike?$w5
You are our commander.$w2
This is your decision.$K
$d0$c0IKE|$s0I understand.$w4
Very well. We'll take them with us.$K$PAt least if they're nearby,$w2
they'll be easier to watch over.$K
$s3$FS$c3MIST|$s3Are you serious?$K
$s1$FS$c1LOFA|$s1Yes! $w2You won't regret this!$K
$d0$s0$FS$c0OSCAR|$s0I think we've been had.$K  $R�㉺��b|$c1LOFA|$s1Ike, sir?$w4
Please take Mist and me with you.$K$PI, um,$w2 I can use this bow to
watch over her.$K
$c0IKE|$s0Rolf?$w4 When$MC... $MD$w2When did you
learn to wield a bow?$K
$c3MIST|$s3Rolf's been practicing a lot$w2
And you're really good! $w2Aren't you!?$K
$c1LOFA|$s1I have some skill, yes.$K$PBut I want to do something brave$w6
to honor$w4 my brothers' memory.
So please let us go with you, sir.$K
$d3$s0I understand, but$MC...$MD$K
$c3MISTs|$s3We can't stand this!$K$PAll Rolf and I do$w4 is sit and wait
and worry about all of you.$K$PWe're tired of waiting!$w2
We want to fight with you!$K
$s0I see,$w4 Mist.$K$d3
$s1It's just that, Oscar...$w4$Fc
and Boyd,$w4 they...$w5
they're both$w4 gone, and...$K$P$FdI want to$w4 fight.$w4
I won't be left alone again.$w4 I won't!$K
$d0$c0IKE|$s0I understand.$w4
You can both come.$K$PHaving you nearby$w2 will make it
that much easier to keep you safe.$K$P$s3$FS$c3MIST|$s3Are you serious!?$K
$s1$FSThank you, Commander!$w4
You won't regret this.$K
$s0$FSWe're all in this together.$w4
We fight as one, no matter what.$w1
Do you understand?$K    $R�㉺��b|$c1LETHE|$s1By the way$MC...$MD$K
$c0IKE|$s0What is it?$K
$s1If there is some special task$w2
you would ask of us,$w4
we are willing to listen.$K
$s0What are you talking about?$K
$s1Bah! Open your ears!$K$PIf you wish it, we shall$MC...$MD$w4
follow your orders. Hssss!$w4
But you must$w3 Direct us.$K
$s0Really? You're willing to take
orders from me?$K
$s1This is a beorc fight.$K$PIf you don't Direct us, then we
have no reason for being here.$w4
So spoke our king.$K
$s0But last night, you$MC...$MD$K
$s1THAT$MC...$MD$w4
That was an$MC...$MD$w4emergency.$K
$c3MORDY|$s3We thought you were in danger.$K
$s0You thought correctly. $w2We were in
danger. $w5$FSI thank you.$w4 We were
greatly aided $w2by your arrival.$K
$s3$FSYou are welcome.$K
$s1Hmm.$K$d1
$s3Very well.$w5
Let us fight together.$K$PIf you choose not to Direct us,$w2
we shall do as we please.$w3
Do you find this acceptable?$K
$s0Of course.$w4
$FAWell then, $w2good fortune to us all.$K   $R�㉺��b|$c0MARCIA|Let's see now$MC...$MD$w4 Where are they?$w4
$FSAha! $w2I've found them!$K $R�㉺��b|$s0$FS$c0NEDATA|$s0Yar $w1har $w1ho!$K
$d0$s1$FS$c1BANDIT4|$s1Yo $w1ho $w1har!$K
$d1$s0$FS$c0NEDATA|$s0Scallywags $w2of the sea are we!$K
$d0$s1$FS$c1BANDIT4|$s1We fight like beasts, $w2an' men do flee!$K
$d1$s0$FS$c0NEDATA|$s0We earn our gold$w2 with axes bold$MC...$MD$w4
Yar! Ye scurvy bilge rat!
Why aren't ya singin'?$K
$d0$c2BANDIT4|$s2Har! Over there, Nedata!$w5
Fix yer eyes on that.$w4
Do ye sees what I sees?$K
$c0NEDATA|$s0Oh ho ho! $w2What's this, then?$K$PHumans $w2battling humans here
in Gallia?$w3 What in the briny beard
of Shanty Pete is going on?$K
$s2Oy! $w2Do ya think they may be
the king's curs out to capture us
and claim the bounty?$K
$s0Gahar har har!$K
$s2Shall we unfurl the mainsail$w2
and steer for calmer waters?$K
$s0Bite yer tongue, ye kelp-brained idjit!$w4
We're pirates!$w2 We don't turn tail
from government scum!$K$PI'm goin' ashore!$w4
Watch me,$w2 and you'll see
a true sea-dog in action.$K$d2
$s1$FS$c1BANDIT4|$s1$FSYar, well said!$w4
You've set me blood aboil!$w5
I'm with ye all the way, matey!$K
$s0$FSAarrr!$w4
Let's see what we can see then!$K
$s1Yar! Me axe is sharp,
and me spirit is bold!$K$d1
$s0Yar $w1har $w1ho!$K$d0
$s1$FS$c1BANDIT4|$s1Yo $w1ho $w1har!$K$d1   $R�㉺��b|$s0$FS$c0MARCIA|$s0Ike!$K
$c1IKE|You! You're that$MC...$MD$K
$s0That's right. $w2It's me!$w3 Marcia!$w4 As
promised,$w2 I'm here to pay my debt$MC...$MD$w4
I'm going to join your group!$K
$s1Join us?$w4 But$w2 I thought you were
one of the holy pegasus knights
of Begnion$MC...$MD$K
$s0Pfff! I resigned!$K$PSo what do you say?$w2
Are you going to let me in or what?$w4
Come on!$K
$s1Are you sure about this?$w5
I mean,$w4 I'll be honest with you.
We're a destitute band of mercenaries.$K$PYour wages will be a pittance
compared to what you're used to.$K
$s0$FASo,$w3 what? Are you saying no?$K
$s1No, I'm simply pointing out that
you'll be losing almost all of$MC...$MD$K
$s0Pfff! I won't lose out on anything!
Plus, I'll work twice as hard
as anyone else.$K$PC'mon, please let me join?$w4
PLEEEEASE!$K
$s1Well, if that's what you want,$w4
I guess we'll give it a shot.$K$PWe're shorthanded though,$w3
so you're going to be busy.$K
$s0$FSHuzzah! That's great!$w4
Just tell me what needs doing!$K  $R�㉺��b|$c0BOLE|$s0Rolf, stay by my side.$K
$s1$FS$c1LOFA|$s1You got it!$K
$s0$FSHold a minute.$w3
That was too easy.$w4
What's going on?$K
$s1Nothing. But if I'm close to you,$w2
I can protect you.$w4
So you have no need to worry.$K$d1
$s0$FAWhat? Hey, $w2that's my line!$K   $R�㉺��b|$c0OSCAR|$s0Rolf!$K
$c1LOFA|$s1I'm$MC... $MD$w1I'm sorry!$K
$s0Huh?$w4 Why are you apologizing?$K
$s1What?$w4 But$MC...$MD$w5
Aren't you here to yell at me?$K
$s0Why? Did you do something
to make me mad?$K
$s1I thought maybe my whole
decision to fight and stuff$MC...$MD$w3
I made that on my own.$K$PI thought that it might$w2
upset you.$K
$s0$FSI won't complain about$w2
the commander's decisions.$K
$s1So, $w5you're all right with it?$K
$s0I suppose.$w4
But$w3 I want you to stay close,$w2
so I can watch out for you.$K
$s1$FSGot it!$K
$s0$FAWait! $w6There is one thing.$w4
When did you learn
to use a bow?$K
$s1$FAUm,$w8 it's a secret!$K$d1
$s0That's no answer.
Rolf! Blast!$w4
I told you to stay close!$K $R�㉺��b|$c0OSCAR|$s0Rolf, $w2do not leave my sight.$w4
Do you understand?$K
$c1LOFA|$s1Yes, $w2I understand.$K
$s0I can't let you die.$w5
When Boyd$MC...$MD$w3
When we lost Boyd$MC...$MD$K$PI don't$MC...$MD$w5 I don't ever want
to feel that kind of pain again.$K
$s1I know.$K  $R�w�i��b|$B��-�C|$<$F1$FCL_CATWOMAN|$F4$FCLME|$F1$PEeeek! $w5Hu-$w2hu-$w5humans!$w3
Yaaaaah!$Fc$K
$F4$PUm$MC...$MD$K
$F1$PUrk!$w4
Urk!$w4
Ahhh$MC...$MD$w3$Fo Oh, come on!$K$PYou are so rude!$w4
If you can't tell,$w4 I'm playing dead.$w2
So go away!$K$PHuh?$w4 Why? $w5Because my mother
told me, $w2"If you ever meet a beorc,$w4
play dead, and it will leave you be."$K$PIt's not true, is it?$w4 Hsss!$w4
I knew it wasn't true!$w2 I knew it!$K$PWell then,$w3 take this,$w2
and get out of here! Quickly!$K$PI $w5HATE humans!$w4
I don't want to talk to you!$w5
Hsss!$w4 SHOO!!$K    $R�w�i��b|$B��-�C|$<$F1$FCL_CAT|$F4$FCLME|$F1$PYou're from Crimea, aren't you?$K
I'm $w2a warrior of the beast tribe.$w4
Lord Ranulf spoke of you.$K$PDoubtless you have noticed that$w2
Fort Tatana has been taken$w3
by Daein forces.$K$PWatch your step around that bunch.$w4
There's a dangerous mage with them.$K$PWe of the beast tribe find magic,$w4
and especially fire magic,$w2
particularly threatening.$K$PI am waiting for friends$w2 and cannot
take leave of this house, but$MC...$MD$w5
I would give you this.$K$PIf you use it, your magical resistance will
increase. It will help you fight that mage.$w5
Take care.$K $R�㉺��b|$c0MARCIA|$s0Huh?$Fh$w4 Oh, fiddle$MC...$MD$w4 Not yet$MC...$MD$w5
I$MC... $MD$w2I have to keep$w4$Fc
my$MC...$MD$w5promise.$K   $R�㉺��b|$c0NEDATA|$s0Scallywags of the sea $w2are we!$K
We earn our gold with axes bold!$K   $R�㉺��b|$s0$FS$c0NEDATA|$s0Ya $w1ha $w1ho!$K
$c1IKE|$s1Huh?$K
$s0Yo $w1ha $w1ha.$K
$s1What a ragged bunch.$K
$s0Scallywags of the sea $w2are we.$w4
We'll not lose to the likes of thee!$w2$K    $R�㉺��b|$c0NEDATA|$s0Ya har! Beasties!$w2 No need to panic!
Try to hit them while they're
in human form!$K
$c1LETHE|$s1Thieving worms!$w4
Prepare to die!$K  $R�㉺��b|$c0NEDATA|$s0Ya har! Beasties!$w2 No need to panic!
Try to hit them while they're
in human form!$K
$c1MORDY|$s1Beorc fools.$w2
I will punish you.$K  $R�㉺��b|$c0NEDATA|$s0Scallywags of the sea$MC...$MDare we$MC...$MD$w4
An end like this $w5is quite$MC...$MD$w5worthy!$K  $R�㉺��b|$c0LETHE|$s0$MC...$MD$w2No! Disgraceful$MC...$MD$w4
Losing to garbage such as this$MC...$MD$K
$c1IKE|$s1Lethe!$w3
We'll take over from here!$w4
You must withdraw!$K
$s0$MC...$MDHsss$MC...$MD$w5
Until I have seen you to the
palace,$w2 I cannot fall!$K$PAgainst my wishes$MC...$MD$w4
I$w5 withdraw$MC...$MD$K   $R�㉺��b|$c0MORDY|$s0Graarr!$w4 What's wrong?
My body. It grows$MC...$MDheavy.$K
$c1IKE|$s1Mordecai!$K$PNo matter how strong you are, you
can't take much more!$w4 We'll take
over now! $w2You must withdraw!$K
$s0Grawr$MC...$MD$w4 I understand.$w4
I will do as you ask.$K $R�㉺��b|$c0KOTAHU|$s0Death to the rogues who defy Daein!
Defend our brethren!$w4
Erase their shame!$K    $R�㉺��b|$c1KOTAHU|$s1So, $w2you are the new commander$MC...$MD$w4
Tell me, boy, $w2what cowardly tactics
did you employ to fell our brothers?$K$PYou must have deceived them.$w2
There's no way rabble like you could
defeat Daein troops in a fair fight.$K
$c0IKE|$s0From the very beginning, every last
one of you has underestimated us.$K$PWill you never learn?$w4 Your refusal to
recognize our strength will forever
keep victory at arm's length.$K
$s1Silence!$w4
Silence, $w2you idiot child!$K
$s0You're right.
No more talk.$K  $R�㉺��b|$c0KOTAHU|$s0Bah! $w2So the sub-humans have
come crawling out of their dens, eh?$K
$c1LETHE|$s1Beorc maggot! Those who call us by
that hateful name shall earn a swift
and merciless death!$K    $R�㉺��b|$c0KOTAHU|$s0At last we meet, $w2sub-human!$w4
I will exterminate you with my own
two hands! My$w6 HUMAN hands!$K
$c1MORDY|$s1Sub$MC...$MD$w2 Sub-human?$w3
Grrraaaaaa!$K    $R�㉺��b|$c0KOTAHU|$s0Arrgh$MC...$MD$w3urr$MC...$MD$w2urg$MC...$MD$w4
In the name$MC...$MD$w2of the empire$MC...$MD$w3
Cleanse$MC...$MD$w2my shame$MC...$MD$K $R�w�i��b|$B���-��-��|$<$F1$FCL_IKE|$F1$PWe defeated their commander,$w5
but we still don't know what
they were after.$K
$F0$FCL_TIAMAT|$F0$PIt seems unlikely that they were merely
pursuing Princess Elincia.$K$PI wonder if Daein is planning to invade
Gallia. $w2Perhaps Crimea was only
a stone on which to whet their blades.$K
$F3$FCL_SENERIO|$F3$PNo matter the motive,$w2 the fact
remains that Daein crossed the border.$K$PUnder such circumstances, $w2hostilities
between Daein and Gallia could break out
at any time.$K
$F1$PSo, $w2it's war$MC...$MD$w3 Again.$K
$F0$PIf war erupts between the beorc and laguz,$w4
it's only a matter of time before other
nations become involved.$K$PCould Daein truly mean $w2to set the
land aflame in a blaze of war?$K$PIf that happens,$w4 many of our
citizens$w3 will be sacrificed on
the altar of their ambition.$K
$F3$PWe, too, $w2need to choose which way
to move,$w4 whose side to take$MC...$MD$K
$F0$PWhose side?$w4 We shall never support
Daein! $w2Unthinkable!$K
$F3$PCaptain Titania,$w3 we are human.$w2 Would
you truly have us side with sub$MC--$MD$w1with laguz
against other humans?$w4 THAT is unthinkable.$K
$F1$PBeorc$w2 and laguz$MC...$MD$K$F0$FD$F3$FD
$F3$FCL_LETHE|$F3$P$w3Are you going to sit here and argue$w2
about a war that hasn't started?$w4
You beorc are all so timid! It's pathetic.$K
$F4$FCL_MORDY|$F4$PLethe!$w4
You must not$w2 say such things.$K
$F1$PMordecai? Lethe? $w2What do you think?$w4
Will it come to war?$K
$F3$POur claws are sharp.$w4 If Daein invades
Gallia,$w3 we are ready for battle.$w4
If our king wills it,$w4 war will come.$K
$F4$PI $w2like it not$MC...$MD$w3$Fc
War$w4 brings pain.$w4 Sorrow.$K$F4$FD
$F1$PThis is troubling$MC...$MD$K
$F3$PEnough. We have lost much time.$w4
Let us make for the palace.$K$PWe must reach tonight's camp
before the sun sets.$K
$F1$PIs the palace still far?$K
$F3$POn your skinny beorc legs,$w6
it is very far.$w4
But we will do as we can.$K
$=1000    $R�w�i��b|$B���{-�K���A|$<$F1$FCL_ERINCIA|$F3$FCL_IKE|$F1$PMy lord Ike!$w4
Everyone!$K
$F3$PPrincess Elincia.$K
$F1$PI heard about$MC...$MD$w4Commander Greil.$K$PI$MC...$MD$w4 I don't know what to say.$K
$F3$PDon't worry.$w4 We're all right.$w4
We're$w4 getting by$MC...$MD$w4somehow.$K
$F1$P$MC...$MDOh, Ike$MC...$MD$K
$F0$FCL_CAT|$F0$PThe king has arrived.$K$F0$FD$F1$FD
$w4$P$F1$FCL_CAINEGHIS|$F3$PUm$MC... $MDHey there.$K
$Ub$H$F1$PThank you for coming to Gallia Palace.$w4
I am Caineghis, ruler of the kingdom of
Gallia.$K
$F3$PThese are the Greil Mercenaries.$w2
I am Ike, their commander.$K
$F1$P$FSYou have been raised well, young pup.$w4
I didn't recognize you.$K
$F3$PWhat?$K
$F4$FS$F4$FCL_TIAMAT|$F4$PWhen last you were here,$w2
you were still a small child.$K
$F1$PIs that you, Titania?$w4
It's good to see you.$K
$F4$PThe pleasure is all mine, $w2Your Majesty.$K
$F3$PThe two of you are friends?$w4
How$MC...$MD$w3 How does the king know me?$K
$F1$P$FAMm.$w4
I have something I must tell you$w2
about your father, Greil$MC...$MD$K
$F3$P$FD$F4$P$FD$F3$FCL_LETHE|$F4$FCL_MORDY|$P$F1$PLethe. $w2Mordecai.$w2
Leave us now.$K$PPrepare rooms,$w2 so our guests may have
a place to rest and heal their wounds.$K
$F3$PAt once, my lord!$K$F3$FD$F4$FD
$F3$FCL_IKE|$F4$FCL_ERINCIA|$F4$PWould it be best if I were
to leave as well?$K
$F1$PNo, Princess. $w2I would have you stay.$w4
And this one $w2also will stay.$K$F1$FD
$F0$FCL_GIFFCA|$F0$P$MC...$MD$K$P$F0$FD$F1$FCL_CAINEGHIS|This is Giffca, $w2my shadow.$w4
Pay him no more heed $w1than
you would the air.$K
$F3$PUnderstood.$w4
I would have Titania and Soren
stay with me, as well.$K
$F4$FD$F4$FCL_SENERIO|$F4$PMe?$K
$F1$PSo be it.$w4
Now then, $w2where to begin?$K$F4$FD$F4$FCL_TIAMAT|
$F1$PTitania?$w4
How much did Greil tell his son?$K
$F4$PIke was raised $w2with no
knowledge of Gallia whatsoever,$w4
nor does he recall ever having been here.$K
$F1$PIs that so?$w4 Then it is best for me to
tell him all that I know.$K$P$MC...$MDAlthough $w2that is not much.$K
$F4$FD$F3$PThat's all right. $w2Whatever you can
tell me would be much appreciated.$w4
I want to know more of my father.$K
$F1$PHmm$MC...$MD$w4$FS
You have good eyes. Honest and brave.
I see your father in them.$K$P$FALong ago, Greil$MC...$MD$w4your father$MC...$MD
worked as a mercenary for Gallia.$K
We forged a strong bond, he and I.$K$PTo speak truly,$w2 I still do not
trust the beorc.$w4
But $w2your father $w6was different.$K$P$F1$PPrincess Elincia's father, King Ramon,$w2
and his brother, Lord Renning,$w4
are also of a different kind.$K$PAll$w2 are$MC...$MD$w5or were$MC...$MDexceptional men.$w2
Men in whom one could put his trust.$K$P$F4$FCL_TIAMAT|$F1$P$FSOh ho! $w2Titania!$w2
You are an exception as well!$w4
Among beorc females, $w2you are unique.$K
$F4$P$FSYou are most gracious, Your Majesty.$K$F4$FD
$F3$PMy father was a mercenary for Gallia$MC...?$MD$K
$F1$P$FACorrect. And you and your sister?$w2
You were both born here in Gallia.$K$PYou stayed only for a short time,$w2
but part of your childhood was
spent within these borders.$K
$F3$PMist and I were born here? Is that so?$w4
I don't remember any of this at all.$K
$F1$PI feel $w2your parents were
carrying a dark secret.$K$PSomeone was$w3 hunting them,
I'm sure of it.$K$POnce,$w4 over ten years ago$MC...$MD$w4and after
your mother had been slain$MC...$MD$w6
Your father chose to leave Gallia.$K$PBefore he left, I went to him $w2and asked
him to share his tale.$K$PI asked him, "Why are you being chased?$w5
Is there anything I can do to help?"$w4
But $w2I was unable to loosen his tongue.$K$PAnd then I heard he had returned to Gallia,$w2
and I thought I had another chance$w2
to hear his tale.$K$P$FcHis fate was$w4 black indeed.$w4
If I had been faster,$w4 if I had hastened my
steps,$w4 perhaps things would be different.$K
$F3$PWait!$w4 Now I understand. $w2The voice I
heard$MC...$MD$w4 That was you, wasn't it?$K
$F1$P$FdHis wound was fatal. $w2I could do nothing.$w5
I thought it best not to interfere in his final
moments,$w4 so I remained hidden.$K$PTell me, Ike$MC...$MD$K
At his last,$w3 did he confess
anything to you?$K$PThe identity of the Black Knight$MC...$MD$w2
Did he reveal it?$K
$F3$PThe Black Knight?$w5
No. I don't know who he was.$K$PMy father $w2entrusted me with his
command,$w5 told me to trust King
Caineghis $w2and to live peacefully in Gallia.$K
He said to forget everything else.$K
$F1$PIs that so?$w4
Well then, $w2let me do as I can.$K$PIf any of your mercenaries$w2
desire to live here,$w3
I will so arrange it.$K$PI will vouchsafe them homes $w2and land.$K
$Ub$H$F3$PYour kindness is truly appreciated.$w4
But, $w2speaking for myself,$w2 I couldn't
live here in peace.$w4 Not now.$K$PI will avenge my father.$w4$Fc
I cannot so quickly forget the past$MC...$MD$w6
Or the Black Knight.$w2$K$P$F4$FCL_TIAMAT|$F4$PBut, $w2Ike!$w4
That's not$MC...$MD$K
$F3$P$FdI know.$w4
I'm not$MC...$MD$w4 I'm not strong enough.$K$PAn opponent who could defeat my father$w4
is well beyond my reach$MC...$MD$K$PBut that's why$w4 I've devoted
myself to growing stronger.$K$PI will lead my father's mercenaries$w4
and prepare for the day when
my chance for revenge arrives.$K
$F1$P$FSA prudent course of action.$w4 You look
as one who would be more impulsive,$w2
but $w2you are Greil's son after all.$K
$F4$P$FSHa!$w4 You've matured, $w2Ike.$w5
It seems like yesterday$w2 that you
were merely a child.$K
$F3$PTitania$MC...$MD$K
$F1$P$FAAnd now,$w2 I would ask a boon of you.$K
$F0$FCL_ERINCIA|$F1$PThe strength of your mecenary band, Ike,$w5
would you lend it to Princess Elincia?$K
$F3$PAre you serious?$K
$F0$PKing Caineghis!$K
$F1$PGallia and Crimea are allied nations,
that cannot be denied.$K$PHowever, $w2this alliance in reality binds
only the royal families.$w3 It is not
respected by our citizenry.$K
$F4$P$FAThe people of Gallia are seldom seen
in Crimea, are they?$K$PEven though our nations are friends,
the people of Crimea have little real
understanding of the laguz.$K$PMany of our people still use that
undignified name, "sub-human," when
they speak of the laguz...$K$P$F0$P$MC...$MDMy father's heart was filled with shame
and sorrow over what you describe.$K$PMore than any king in our history,$w2
he wanted to deepen relations between
our people, $Fc$w4and then$MC...$MD$K
$F1$PPerhaps that is why $w2Daein targeted him.
Their hatred of the laguz is well known.$K
$F3$PCould it be$MC...?$MD$K
$F0$P$Fd$F1$PIn my heart of hearts,$w2 I would like
to take guardianship of Princess Elincia$w2
and assist in the rebuilding of Crimea.$w2$K$PHowever, $w2anti-beorc sentiment
is running high here in Gallia.$K$PIf we were to offer safe harbor to
Elincia, $w2I feel many of our
elder statesmen would protest.$K$PThey would say$w2 that we are giving
Daein an ideal excuse to attack.$K
$F3$PWhich means$w4 Gallia can't $w2offer
Princess Elincia any relief at all$MC...$MD$w4
Is that it?$K
$F1$PUnfortunately, $w2it is true.$K
$F0$PMy lord Ike,$w4 King Caineghis has advised
me to turn to the Begnion Theocracy for
aid in Crimea's restoration.$w2$K$PHe says we should make of Begnion
a formal request $w2and gain the
support of their shields.$K$P$F4$PPassage to Begnion will require
several months at sea.$w4
An escort will be necessary$MC...$MD$K
$F3$PAs you know, $w2we lack the numbers$w1
to serve as a complete mercenary
army.$K$PSo, $w2if the princess were willing
to hire us as an escort,$w2 it would
be an offer beyond our expectations.$K
$F4$FD$F0$FD$F1$FD$F3$PTitania!$w4 Soren!$w4
I think perhaps we should accept the
king's offer. What do you say?$K
$F1$FCL_TIAMAT|$F0$FCL_SENERIO|$F1$P$FSIt's what you want, right, Commander?$w4
Well $w2then, it's our job to follow you.$K
$F0$P$FSHowever you wish to proceed$w4 is fine.$w4
I will do all in my power to ensure that
our road $w2leads to success.$K
$F3$P$FSUnderstood.$w4 $FAAs of now, $w2the Greil
Mercenaries$w2 shall assume the honor of
serving as escort to the princess of Crimea.$K
$F0$FD$F1$FD$F0$FCL_ERINCIA|$F3$PPrincess Elincia, $w2our journey together
will undoubtedly be a long one.$w4
May we serve you well.$K
$F0$P$FSOh, $w2thank you very much!$w4
I only pray that I, in turn,$w2
may be worthy of your service!$K
$=1500   $R�w�i��b|$B���-���O�Y-��|$<$F3$FCL_SENERIO|$F3$PHmm.$K
$F1$FCL_IKE|$F1$PWhat's wrong,$w3 Soren?$w4
Are preparations complete?$K
$F3$PYes,$w4 everything's ready.$K
$F1$PYou have only a few robes and musty
books.$w5 I'm taking a bit less,$w3 but it
looks as though you travel light as well.$K
$F3$PThe burden of unnecessary items$w2
is something I detest.$K
$F1$PMe too.$w4 We're alike in that, aren't we?$K
$F3$PHmm.$K
$F1$PWhat is it?$w4 You've got that
worried look again.$K
$F3$PWell, $w5um$MC...$MD$w3
It's nothing. Never mind.$K$P$MC...$MD$w3Everyone's $w2really slow, aren't they?$w4
Shall I $w2go and see what's taking them?$K
$F1$PSoren$MC...$MD$w3
Don't worry about it.$K
$F3$PHm?$K
$F1$PSitting here in the morning, in the
sunlight$MC...$MD$w3 It helps me to understand.$K
I'm alive.$w4
I have trustworthy friends.$K$PThat's how I know I can go on.$K
I just hope I'm not$MC...$MDfooling myself.$K
$F3$PNo, you're not!$w4
You're not.$K
$F1$P$FSWell then, $w2it's business as usual.$w4 I know
we'll have troubles,$w3 but let us set our
shoulders straight$w2 and get on with it.$K
$F3$P$FSUnderstood.$K $R�w�i��b|$B���-���O�Y-��|$<$F3$FCL_MIST|$F3$PAh, $w2Ike$MC...$MD$w5$FS
Good morning.$K
$F1$FCL_IKE|$F1$PMm. $w2Morning.$w4
$MC...$MD$w2Are you all right?$K
$F3$PIf I said I were, $w2I'd be lying.$w4
But $w2I'm doing my best.$K$PYesterday,$w3 I was so confused.$K
Then, $w2I awoke this morning$w3 and saw
the blue sky,$w4 felt the sun on my face$MC...$MD$w2
And I thought, $w2I'm alive.$K$PThe sunlight was so warm.$w4
I mean, it's always warm, but$MC...$MD$w3
for some reason, $w2it made me want to cry.$K
$F1$POh, Mist$MC...$MD$K
$F3$PIt's up to us. $w2We must live the
fullest lives we can.$K$PWe have to live for Mother$w2
and for Father.$w4
We mustn't$w3 dishonor their memory.$K$PSo$MC...$MDum$MC...$MD$K
I may think about them,$w2 and
I may cry every now and then,$w4
but$w1 I'll$w3 carry on!$K
$F1$P$FSYou're right$MC...$MD$w5
Everything you said is right.$w4
We will carry on together.$K
$F3$PRight!$K$FA
Oh!$w3 Sorry, $w2I have to hurry and get ready!$w4$FS
I'll see you later,$w3 Brother!$K$F3$FD
$F1$PYes, look at the time!$w2
Get a move on, will you?$K $R�w�i��b|$B���-���O�Y-��|$<$F3$FCL_IKE|$F1$FS$F1$FCL_OSCAR|$F1$PHey, good morning, $w2Ike.$w4
How're you feeling today? Yesterday's
battle was a rough one, wasn't it?$K
$F3$PHi, Oscar.$K
Yeah, $w2I'm sore all over. Every muscle
in my body hurts.$w2 Hopefully, I'll feel
better after I move around for a while.$K
$F1$PI hope for the same.$w4 When I woke up,$w2
it was all I could do to get out of bed.$K$PWe're truly lucky to be alive.$K$PIf those two beast fighters hadn't
arrived when they did,$w4 we might
have all been wiped out.$K
$F3$P$MC...$MDYeah$MC...$MD$K
$F1$P$FAIke,$w3 I can't say I know what you're
going through or how you feel.$K$PBut$w3 you should try to remember$w2
all that happened last night.$K$PThe men we fought$w4 were professionals.$w3
Well trained and$w2 under the command
of a cunning tactician$MC...$MDbut not invincible.$K
$F3$P$MC...$MDYou're saying$w3 they follow certain
rules? $w2Specific patterns?$K$PYes, I see. If I can learn what they are,$w3
they become vulnerable.$w4
The next time we meet,$w3 we won't lose.$K
$F1$PHar!$K
$F3$PWhat?$K
$F1$PFor an instant there, $w2looking at you$w4
was like looking at Commander Greil.$K
$F3$PI'm his son.$w4 I'm supposed to
look like him, aren't I?$K
$F1$PIt wasn't that. $w2And it wasn't an aura or
a hunch or anything like that.$K
I don't know what to call it.$w4
It was more like$w3 the core of your
character$MC...$MD$w2 It felt$w2 the same as his.$K
$F3$PHuh$MC...$MD$K
$F1$P$FSHa ha.$w3 Sorry.$w4
That must've sounded pretty stupid.$K
$F3$POscar?$K
$F1$PCommander?$K
$F3$PFrom now on, when I practice,$w2
would you join me?$K
I would be more familiar with the
fighting style of knights.$K
$F1$POf course!$w4
If there's anything I can do to help,$w3
you need only to ask.$K $R�w�i��b|$B���-���O�Y-��|$<$F3$FS$F3$FCL_WAYU|$F3$POh, $w2Boss!$w4
Morning!$K
$F1$FCL_IKE|$F1$PGood morning.$w4
Are you ready to go?$K
$F3$PAll set!$K$PIt doesn't matter how late I go to sleep,$w3
I'm always awake before the sun rises!$w4
I can leave whenever!$K
$F1$P$MC...$MD$w2Um, I'm sorry.$w5 You know,$w2
for everything that's happened.$w4
It's all so sudden.$K
$F3$P$FAOh, it's nothing.$w4
But it's been rough on you, hasn't it?$K
$F1$PI could say the same to you.$w4
It can't have been easy joining a band of
wanted mercenaries and fighting every day.$K
$F3$POh, it's not so bad$MC...$MD$K
$F1$PYou were forced to join us by the
whims of fate, not by choice.$K$PI know my father said $w1you had a debt to
repay, $w2but he's not here anymore.$w4
If you want to leave, $w2I won't stop you.$K
$F3$P$FcUm$MC...$MD$w4
Er$MC...$MD$w8
Aaaaah!$K
$F1$PAaah! What!?$K
$F3$P$FdOooh!$w4 Times$MC...$MD$w2 Times like this$MC...$MD$w3
I never have any idea of what
I'm supposed to say. $w2None!$K$PUh,$w3 darn! Hold on.$w4
Yesterday$MC...$MD$w3in the middle of that giant mess,$w3
you didn't give up, Boss.$w4 And I knew.$K$PThat$w2 is how a true man lives!$w4$FS
So now I have to follow you.$w2 You see?$K
$F1$PI$MC...$MDthink so.$K
$F3$PThat's my story, Boss.$w4 So do me a
favor and don't tell me to get lost.$w4
I'm good to have around. $w2You'll see!$K
$F1$PIf that's how you feel,$w3 I guess I
understand.$w4 I'm counting on you.$w2
Don't let me down.$K
$F3$PNever!$w4 I wouldn't know how!$K  $R�w�i��b|$B��-��|$<$F1$FS$F1$FCL_MORDY|$F1$PIke.$w4
Are you prepared?$w5
Can we depart soon?$K
$F3$FCL_IKE|$F3$PIt's taking more time than I thought.$w4
I'm sorry for making you wait.$K
$F1$PI see.$w4
Then $w2I will talk with you$w2
as we wait.$K$w4$FA$PGrr$MC... $MDMy words, $w2are they well?$w4
Can you $w2understand them?$K
$F3$PSure, no problem.$w4
I understand you.$K
$F1$P$FSThat is good.$w4
Mordecai is$w2 not so good$w3
with this language.$K
$F3$PWhat language do you normally use?$K
$F1$PWith others of my tribe,
I need no words.$K$PI say all that I must with gestures$w2
and with$MC...$MD$w2how do you say$MC...$MD$w5growls?$K
$F3$PThat sounds convenient.$K
$F1$PYes.$w4 But$w3 our tongue does not
let us talk $w2to other tribes.$K$PThat is not good.$w4
That is why $w2we learn
these$w2 modern words.$K
$F3$PI would think that would be enough,$w3
being able to speak with only your
friends, wouldn't it?$w3$K
$F1$PIt is not.$K$PIf there is danger or conflict$MC...$MD$w3
We can use words $w2to avoid a
fighting that need not be.$K$PSo using words$w3 that many
can hear $w2is good.$K
$F3$PHmm$MC... $MDUsing words to avoid
unnecessary fighting$MC...$MD$K$FS$PThat's one way to think about it.$K  $R�w�i��b|$B���-���O�Y-��|$<$F3$FCL_IKE|$F1$FCL_SENERIO|$F1$PGood morning, $w2Ike.$w5
May I have a moment of your time?$K
$F3$PWhat is it?$w3 I'm listening.$K
$F1$POur expenses,$w3 our ability to fight$MC...$MD$w4
The current status of our troops$MC...$MD$w5
These are all things $w2that you must know.$K
$F3$PI see.$w4 Having a grasp of that $w2is part
of the commander's job, too, right?$K$PUnderstood.$w3 Let me hear it.$K
$F1$PVery well.$K$F3$FD$F1$FD$N$UB$H    $F3$FCL_IKE|$F1$FCL_SENERIO|$F1$P$F1$PAnd that's it.$K
$F3$P$FoUgh$MC...$MD$K
$F1$PIke?$w4
Is something wrong?$K
$F3$PEven though I was aware of the numbers,$w3
hearing it in a report like this is$MC...$MD$w4hard.$K
$F1$PDo you mean the$w3 casualites and refugees?$K
$F3$PDeath and destruction $w2are all part of war.$K$PMy father said that a lot.$w5
"The first casualties of war $w2are those
without strength$w3 and those without luck."$K$P"And $w2there's nothing you can do about it.$w4
Live with bravery, $w2be daring and
fearless.$w3 Live for those who have died."$K$PAnd yet$MC...$MD$w4I can't help but think$w5 if I were
more powerful$MC...$MD$w3 I could save more people.$w5
Couldn't I?$K
$F1$PIke$MC...$MD$K
$F3$P$Fc$MC...$MD$w5Blast!$K
$F1$PIndeed.$K$w6
$F3$P$FdForgive me. $w2I got carried away.$K
$F1$PNo, not at all$MC...$MD$w5
Um, perhaps I should$MC...$MD$K
$F3$PThank you for the report.$w4
I will need more of the same from here on.$w3
Keep up the good work.$K
$N$UB$H    $F3$FCL_IKE|$F1$FCL_SENERIO|$F1$P$F1$P$MC...$MD$w3That's it.$K
$F3$PI think I've got most of it.$K
$F1$PI'll give you a report before each battle.$w4
I hope that it helps.$K
$F3$PI'm sure it will. $w2Thank you.$w4
I'm relying on you $w2for all the details.$w3
Keep up the good work.$K
$N$UB$H    $F1$P$FSThank you, Commander.$w3 I will do my best.$w5
But if I have your leave,$w2 I must be going.$K    <�      =L     >     >�   +  ?P   :  B   G  B�   P  D�   ]  Ed   i  F   u  ?�     <`   �  A   �  F�   �  Nd   �  )�   �  )�   �  %�   �  nx   �  r�   �  v�    }�    ��  #      1  p  <    I  d  X  t  e  	\  s  �  �    �  D  �    �  !t  �  �h  �  �<  �  �@  �  �  �  .�    2�    3�  $  6�  1  7�  >  9�  KMS_10_01_BT MS_10_01_BT_IKE MS_10_01_BT_LE MS_10_01_BT_MO MS_10_01_DIE MS_10_BT MS_10_BT_IKE MS_10_BT_LE MS_10_BT_MO MS_10_DIE MS_10_DIE_LETE MS_10_DIE_MARCIA MS_10_DIE_MORDY MS_10_ED00 MS_10_ED01 MS_10_EV01 MS_10_EV02 MS_10_EV_yellow MS_10_INFO_01 MS_10_INFO_02 MS_10_INFO_03 MS_10_INFO_04 MS_10_INFO_05 MS_10_OP01 MS_10_OP01_2 MS_10_OP01_2_2 MS_10_OP01_3 MS_10_OP01_3x MS_10_OP01_4A MS_10_OP02_01_A MS_10_OP02_01_B MS_10_OP02_02A MS_10_OP02_02B MS_10_OP02_02C MS_10_REPO_BEGIN MS_10_REPO_DIE MS_10_REPO_END MS_10_REPO_NODIE MS_10_TK01 MS_10_TK02 MS_10_TK03_A MS_10_TK03_B MS_10_VIL_01 MS_10_VIL_02 