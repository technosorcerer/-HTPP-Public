 )X |       �                $RGMAP��b|$O3$GThe Crimean royal palace, located in the
center of Melior, is famed for its beautiful
gardens where the world seems at peace.$K$PBut times have changed. $w2Countless battles
have raged in these idyllic confines, $w2and a
new dark lord now sits upon the throne.$K$PThe palace itself has not suffered--$w3it
remains a study in dignity and elegance.$K$PYet there is no peace on this day. A grim
tension fills the air,$w4 engulfing all it
touches in deafening silence.$K  $RGMAP��b|$O3$GWithin the heart of the palace sits the
author of this war:$w3 Ashnard, $w2king of Daein.$K $RGMAP��b|$O3$GIke, supreme commander of the Crimean
army,$w3 and Elincia, $w2princess of Crimea,
have completed their battle preparations.$K$PNow, they spend a tense morning waiting
for the decisive battle that will conclude
their yearlong odyssey.$K$PThey wait for the beginning of the end.$K
$Ub$H   $R�w�i��b|$B�V��-��|$<$F4$FS$F4$FCL_ULYSSES|$F4$PPrincess?$w4 It's time.$K
$F3$FS$F3$FCL_ERINCIA2|$F3$PIt's right there... I can see the capital...$K
$FcFather, $w2Mother,$w3 my lord Uncle...$w4
Your Elincia $w2has returned...$K
$F1$FS$F1$FCL_LUCHINO|$F1$POur soldiers are in formation and awaiting
your word, Princess.$w4 For good or ill,
this will be our final battle.$K$PBefore they march, would you...
speak to them?$K
$F3$P$Fd$FAWhat?$w4 Y-y-$w1you want me to...$w3
address the troops?$K
$F0$FS$F0$FCL_GEOFFRAY|$F0$PThis fight will determine if Ashnard falls
and if we can all return to our beloved
homeland. Today, Princess, we risk all.$K
Giving men the courage to fight is the
duty of a leader.$K
$F3$PI...I don't know how well I'll do, but...$w4
I will try.$K
$=0600    $R�w�i��b|$B�V��-��|$<$F4$FS$F4$FCL_TIAMAT|$F4$PPrincess?$w4 It's time.$K
$F3$FS$F3$FCL_ERINCIA2|$F3$PIt's right there... I can see the capital...$K
$FcFather, $w2Mother,$w3 my lord Uncle...$w4
Your Elincia $w2has returned...$K
$F1$FS$F1$FCL_CRIMEA1|$F1$PPrincess Elincia! The troops await your
command! Before they march, would you...
would you speak to them?$K
$F3$P$FA$FdWhat?$w4 Y-y-$w1you want me to...$w3
address the troops?$K
$F4$PThis fight will determine if Ashnard falls.
It may well determine the fate of all
Tellius.$w4 Today we risk all.$K
Giving men the courage to fight is the
duty of a leader.$K
$F3$PI...I don't know how well I'll do, but...$w4
I will try.$K
$=0600 $R�w�i��b|$B�V��-��|$<$F4$FS$F4$FCL_GEOFFRAY|$F4$PPrincess?$w4 It's time.$K
$F3$FS$F3$FCL_ERINCIA2|$F3$PIt's right there...I can see the capital...$K
$FcFather, $w2Mother,$w3 my lord Uncle...$w4
Your Elincia $w2has returned...$K
$F1$FS$F1$FCL_LUCHINO|$F1$POur soldiers are in formation and awaiting
your word, Princess.$w4 For good or ill,
this will be our final battle.$K$PBefore they march, would you...
speak to them?$K
$F3$P$FA$FdWhat?$w4 Y-y-$w1you want me to...$w3
address the troops?$K
$F4$PThis fight will determine if Ashnard falls,
and if we can all return to our beloved
homeland. Today, Princess, we risk all.$K
Giving men the courage to fight is the
duty of a leader.$K
$F3$PI...I don't know how well I'll do, but...$w4
I will try.$K
$=0600  $R�w�i��b|$B�V��-��|$<$F4$FS$F4$FCL_ULYSSES|$F4$PPrincess?$w4 It's time.$K
$F3$FS$F3$FCL_ERINCIA2|$F3$PIt's right there... I can see the capital...$K
$FcFather, $w2Mother,$w3 my lord Uncle...$w4
Your Elincia $w2has returned...$K
$F1$FS$F1$FCL_LUCHINO|$F1$POur soldiers are in formation and awaiting
your word, Princess.$w4 For good or ill,
this will be our final battle.$K$PBefore they march, would you...
speak to them?$K
$F3$P$FA$FdWhat?$w4 Y-y-$w1you want me to...$w3
address the troops?$K
$F1$PThis fight will determine if Ashnard falls
and if we can all return to our beloved
homeland. Today, Princess, we risk all.$K
Giving men the courage to fight is the
duty of a leader.$K
$F3$PI...I don't know how well I'll do, but...$w4
I will try.$K
$=0600   $R�w�i��b|$B�V��-��|$<$F4$FS$F4$FCL_ULYSSES|$F4$PPrincess?$w4 It's time.$K
$F3$FS$F3$FCL_ERINCIA2|$F3$PIt's right there... I can see the capital...$K
$FcFather, $w2Mother,$w3 my lord Uncle...$w4
Your Elincia $w2has returned...$K
$F1$FS$F1$FCL_GEOFFRAY|$F1$POur soldiers are in formation and awaiting
your word, Princess.$w4 For good or ill,
this will be our final battle.$K$PBefore they march, would you...
speak to them?$K
$F3$P$FA$FdWhat?$w4 Y-y-$w1you want me to...$w3
address the troops?$K
$F1$PThis fight will determine if Ashnard falls
and if we can all return to our beloved
homeland. Today, Princess, we risk all.$K
Giving men the courage to fight is the
duty of a leader.$K
$F3$PI...I don't know how well I'll do, but...$w4
I will try.$K
$=0600  $R�w�i��b|$B�V��-��|$<$F3$FCL_ERINCIA2|$F4$FS$F4$FCL_ULYSSES|$F4$PPrincess?$w4 It's time.$K
$F3$PIt's right there... I can see the capital...$K
$FcFather, $w2Mother,$w3 my lord Uncle...$w4
Your Elincia $w2has returned...$K
$F1$FS$F1$FCL_CRIMEA1|$F1$PPrincess Elincia! The troops await your
command! Before they march, would you...
would you speak to them?$K
$F3$P$FA$FdWhat?$w4 Y-y-$w1you want me to...$w3
address the troops?$K
$F4$PThis fight will determine if Ashnard falls
and if we can all return to our beloved
homeland. Today, Princess, we risk all.$K
Giving men the courage to fight is the
duty of a leader.$K
$F3$PI...I don't know how well I'll do, but...$w4
I will try.$K
$=0600    $R�w�i��b|$B�V��-��|$<$F4$FS$F4$FCL_LUCHINO|$F4$PPrincess!$w4 It's almost time for us to
get started.$K
$F3$FS$F3$FCL_ERINCIA2|$F3$PIt's right there... I can see the capital...$K
$FcFather, $w2Mother,$w3 my lord Uncle...$w4
Your Elincia $w2has returned...$K
$F1$FS$F1$FCL_CRIMEA1|$F1$PPrincess Elincia! The troops await your
command! Before they march, would you...
would you speak to them?$K
$F3$P$FA$FdWhat?$w4 Y-y-$w1you want me to...$w3
address the troops?$K
$F4$PThis fight will determine if Ashnard falls
and if we can all return to our beloved
homeland. Today, Princess, we risk all.$K
Giving men the courage to fight is the
duty of a leader.$K
$F3$PI...I don't know how well I'll do, but...$w4
I will try.$K
$=0600 $R�w�i��b|$B�V��-��|$<$F4$FS$F4$FCL_GEOFFRAY|$F4$PPrincess!$w4 It's almost time for us to
get started.$K
$F3$FS$F3$FCL_ERINCIA2|$F3$PIt's right there... I can see the capital...$K
$FcFather, $w2Mother,$w3 my lord Uncle...$w4
Your Elincia $w2has returned...$K
$F1$FS$F1$FCL_CRIMEA1|$F1$PPrincess Elincia! The troops await your
command! Before they march, would you...
would you speak to them?$K
$F3$P$FA$FdWhat?$w4 Y-y-$w1you want me to...$w3
address the troops?$K
$F4$PThis fight will determine if Ashnard falls
and if we can all return to our beloved
homeland. Today, Princess, we risk all.$K
Giving men the courage to fight is the
duty of a leader.$K
$F3$PI...I don't know how well I'll do, but...$w4
I will try.$K
$=0600    $R�w�i��b|$B�N���~�A�x�O|$<$F2$FCL_ERINCIA2|...Ahem!$K$w4$Fc
...$K$Fd$PHear me! Brave fighting men of Crimea!
Much have you lost in service to your land.$K$PHear me! Beloved friends of the laguz!
You, too, have given all for our fair cause.$K$PHear me! My trusted company of old!
You men of Greil did see me to this day.$K$PI stand before you made of flesh and bone,
alive because you risked your lives for me.$Fc
A word cannot my thanks express in kind...$K$Fd$PWe march today into the jaws of fate;
our enemy lies in wait o'er this hill.$K$PIf on the 'morrow, Ashnard lives no more,
my fondest dream is to among you walk
and give you each my heartfelt thanks anew.$K$PLet not this dream dissolve into dispair!
We will defeat the dreaded king of Daein!
We will reclaim this land we hold so dear.$K$PLend me your strength!
Lend me your weary hearts!
Today we make our fate for good and all.$K$POne life can make a mark upon this world.
One life can move the wheel of history.
Be that one life! Fight well! Fight brave!$K$PFight true.
$Ub$H$K$=0600    $R�w�i��b|$B����-��|$<$FS$F3$FCL_LAY|$F4$FCL_IKE2|$F3$P...Where did that come from?!$w5 That was
magnificent!$w4 It seems the princess, too,$w2
has grown stronger.$K
$F4$PIt's said we grow into the roles we're
given, isn't it?$K$PElincia $w2will make a splendid queen.$K
$F3$FD$F1$Fh$F1$FCL_LAY|$F1$P...$K
$F4$PThat's...$w2 That's just what Nasir said!$K$PWhat?$w3 It's true!$w3 Stop it! Don't give me that
I-can't-believe-what-I-just-heard look.$K
$F1$P$Fd$FSNasir $w2said it, right? $w2Whew!$w4 That's a relief!$w4
I thought the world had gone mad.$K
$F4$P...Stupid cat.$K
$=0900  $R�w�i��b|$B�V��-��|$<$F3$FCL_IKE2|All right, $w2let's go!$w4 This ends today!$K
$F1$FS$FCL_TIAMAT|$F1$PI'm $w2ready.$K
$F0$FCL_SENERIO|$F0$PI have everything I need.$K
$F3$PVery well, $w2we're ready--$K
$F1$PSay, $w2Ike!$K$PThis is the end of the end, you know?$w2
So...rather than just giving orders...$w2
Why don't you say a word, too?$K
$F3$PI think Princess Elincia said enough!$K
$F4$FS$F4$FCL_MIST|$F4$PI want to hear what you have to say,
Brother!$w4 Father always did it,$w2
didn't he?$K
$F3$PYou want me to say something...$w2like Father
would have done?$K
$F4$PUh-huh!$K
$SD$N$UB$H       $SD$R�w�i��b|$B�V��-��|$<$F3$FCL_IKE2|$F1$FCL_TIAMAT|$F0$FCL_SENERIO|$F4$FCL_MIST|$N$UB$H  Speak to the army.  Don't speak.    $=0700  $R�w�i��b|$B�N���~�A�x�O|$<$F2$FCL_IKE2|$F2$PUm...hey there...$K$PBefore this final battle, $w2there's only
one thing $w2I want to tell all of you...$w5
I don't want any of you dying on me!$K$PRemember--you only have one life!$w4
At a time like this, it doesn't matter$w2 what
our blood ties are.$w4 We are family.$K$PThat's what my father always used to say.$w3
And today...$w2for the first time...$w3 I understand
why he said it...$w4 Because we are a family.$K$PSo if you don't want to cause your family
any grief, $w2then live!$K$PDon't drop your guard!$w2 Don't turn your
back! Use every drop $w2of your strength!
Our road has been long, but it ends today!$K$PLet's liberate Crimea $w2and free our friends...$w3
and our families...$w3from Daein's tyranny!$K$PMen of Crimea...$K
Laguz of Tellius...$K
Greil Mercenaries...$K$PMOVE OUT!!$K  $=0700$SE$F3$PNo, $w1that's not me.$w4 I'm not going to do it.$K
$F4$P$FAWhat?$w4 How boring!$K
$F3$PI'm perfectly happy being boring.$w4
Come on, $w2it's time to go.$K$F3$FD
$F1$P$FSWhat else can we do?$w4
He's just being Ike, after all.$K$PI suppose we should go, too.$K
$F4$PPtthtththtthtp!!!$K
$=1200    $R�w�i��b|$B���{-�N���~�A|$<$F1$FS$F1$FCL_ASHNARD|$F8$FCDUMMY|$F8$PAttack!$w4 We're being attacked!$K$P$F4$FCL_DAYNE3|$F4$PThe castle gate has fallen!$w4 The
Crimean army cannot be stopped!$K$P$F4$FD$w4$F4$FCL_BURAISU|$F4$P...$w5It appears the end is near.$w4
Your Majesty, please use the rear gate
and withdraw. We will cover your retreat.$K
$F1$PI am not leaving.$K
$F4$PBut if...$w4 If we lose Your Majesty,$w2 the
Daein royal bloodline itself will be lost!$K
$F1$PAre you saying I will lose?$w4 Hm?
Is that what you wish to say?$K
$F4$P...Of course not!$K$PHowever, our army is in dire straits.$w4
It is merely an act of prudence,
Your Majesty.$K$PI humbly ask that you consider the
continuance of the bloodline above
all else.$w4 Of course, your judgment--$K
$F1$PThe value of the thirteenth generation
of Daein's royal family is not so high as
to warrant your pathetic display.$K$PI AM Daein. If I am to be destroyed,$w2
then let Daein be destroyed with me.$K
$F4$PYour... Your Majesty...$w4 That is--$K
$F1$PI have no need of inconstant retainers.$w5
You are an obstacle.$w4 Away with you.$K
$F4$P...B-but, Your Majesty...$K
$F1$PMy sole desire is to rule through strength.$w4
The weak perish, $w2and the strong live on...$w4
This is the law of nature.$K$PIt is the law the goddess herself created
when she forged this world.$K
$F4$P$Fc...$w4$FdIt appears that further conversation
would only be a waste of time.$K$PThough even if His Majesty desires it not,
I will remain and protect him.$K$PI cannot allow the legacy of Daein to
end here!$K
$F1$PTell me, Bryce...$w4 You were my father's
retainer, were you not?$K
$F4$P...From the fifteenth year of my life...and
for twenty more years until his death...$w4
I did serve him faithfully.$K
$F1$PThe thing that killed my father was not
plague, nor was it another illness.$w5
It was me.$K
$F4$PWh-what?$K
$F1$POh, but it doesn't end there.$w4 There was
my stepmother, too. And every brother who
stood to be a legitimate heir...$K$PAll of them $w2died by my hand.$K
$F4$P...$K
$F1$PAre you still $w2determined to protect me?
Knowing this truth?$K
$F4$P...$w4I am...$K$PEven knowing now as I do...$w2you are still
your father's son. The blood of Daein's
kings flows in you. You are all that remains.$K$P$Fc...By your leave.$K$P$F4$FD$w4$F1$PSuch loyalty to a corpse...$K
In truth, there is nothing in this world$w2
more humorous than a knight.$K
$=1300   $R�㉺��b|$c1IKE2|$s1Hey!$w4 Look out!$K$d1
$c1ERINCIA2|$s1Is... $w2Is that...$K   $R�㉺��b|$c3ERINCIA2a|$s3...$K
$c1IKE2|$s1Elincia, what are you doing?!$w4
Get back!$K
$s3...Ashnard...$K
$s1Wh-what did you say?$w4
THAT is the king of Daein?!$K$d1
$Ub$H$s0$FS$c0ASHNARD|$s0Heh heh heh heh...$w4
It's been a long time,$w2
Princess Crimea.$K
$s3...$K
$s0You look quite different than you did
the day that I cut your father and
mother down like cattle...$K$PI can hardly believe you're the same
little girl who did nothing but tremble
and stare at me.$K
$s3You... You craven--$w4 I've returned
to see you defeated!$K$PI will no longer allow you to treat
Crimea any way you please!$K
$s0Haaa haa haa! How brave and
noble of you. However, $w2you are
not the one I seek.$K  $R�㉺��b|$s1$Fc$c1ERINCIA2a|$s1Aaah!$K$d1
$c1IKE2a|$s1Elincia!$K  $R�㉺��b|$s0$FS$c0ASHNARD|$s0Are you the one they claim is
the son of Gawain?$K
$c1IKE2a|$s1King Ashnard of Daein!$w4
Your treachery dies on my blade!$K
$s0Oh ho? Ah ha ha ha haaaa!$w4
I see that blade in your hand...$K$PIt is a sacred blade, is it not?$w4
The only type of blade that can
pierce my armor.$K$PHm. It matters not how famous the
blade. $w2If the wielder lacks skill,$K
the greatest sword is nothing but
blunted steel.$K
$s1Don't worry. You will see for yourself
how blunt it is.$K
$s0I expect good things from you,$w2
son of Gawain.$K$PWhat you see before you are my
elite, handpicked soldiers.$K$PHow will you deal with them?$w3
I'm looking forward to watching you.$w5
Don't disappoint me!$K$d0
$s1Hold!$K  $R�㉺��b|$c1IKE2|$s1Any of you whose arms remember
what it is like to battle, step forth!$w4
I would take of your strength now!$K $R�㉺��b|$s0$Fc$c0ERINCIA2|$s0...$K
$c1IKE2|$s1Are you nervous?$K
$s0$FdYes.$w4 And you, my lord Ike?$K
$s1No. $w5I'm actually pretty calm,$w2
in a strange way...$K
Now that we're finally here, I can
focus on defeating King Daein.
Nothing else seems to matter.$K
$s0I wonder if we shall win...$K
$s1We will win. I didn't come this far
to lose.$K
You've come all this way as well,$w2
so believe in yourself!$K
$s0...$w3You're right!$K $R�㉺��b|$c0ERINCIA2|$s0My lord Ike!$K
I will go $w2and command our forces
battling Daein in the city streets.$K$P...I will...$w4see you once all is done.$K
$c1IKE2|$s1Very well.$w4 Leave King Ashnard to me!$K
$s0Understood.$K    $R�㉺��b|$c1ENA|$s1Master Ike. $w5In surveying the field, I
believe it likely that we may incur a
high rate of casualties.$K$PMay I suggest calling in aid from one
of the other battalions?$w4 A single
warrior could make all the difference.$K $R�㉺��b|$c1NASIR|$s1...Ike! $w5I don't like these odds! I think
it likely that we may take a lot of
casualties.$K$PWhat do you think of pulling in
one of the other commanders
to lend us a hand?$K  $R�㉺��b|$c1ENA|$s1...I see.$w4 Very well, $w2I bow
to your judgment.$K$PYet, $w2please take care to keep
your guard up at all times.$w4
You must exercise caution.$K $R�㉺��b|$c1NASIR|$s1...I see.$w4 All right then, $w2it's up
to you after all.$K$PMove cautiously!$w4 Any lapses in
concentration could cost us dearly.$K $R�㉺��b|$c1TIBARN|$s1$FSSorry to have kept you waiting.$K$PBut $w2now that I'm here, you
can breath easier.$K$P$FAI promise you $w2that King Daein
will fall at my hands.$K  $R�㉺��b|$c1NAESALA|$s1I'm here, but heed my words! I'm only
here to aid you! $w5Don't try to put the
burden of this battle on my shoulders.$K    $R�㉺��b|$c1GIFFCA|$s1I have answered your call.$K$PSo, Daein's elite soldiers $w5are giving
you some trouble, $w2are they?$K $R�㉺��b|$s0$FS$c0ASHNARD|$s0Will you not come to me?$w4 In that case,$w2
I will bring the fight to you.$K    $R�㉺��b|$s0$FS$c0ASHNARD|$s0...Do you think $w2you can defeat me?$K
Ggrrraaahh haarr haaarr haaaarrrhhh...$w4
GGGRRAAAAAGGGGHHHH!!!$K$PIt's $w2not over yet.$w4 I haven't$w4 seen$w2
all you are capable of.$K
$c1IKE2|$s1What...are you doing?$K
$s0Now is the time $w2to use this!$K
$s1NO! You blind, stupid fool!$K  $R�㉺��b|$c0IKE2|$s0Flee!$w4 Get away, $w2everyone!$K
$Ub$H$s1$FS$c1ASHNARD2|$s1$Ub$HGGGRRAAAAAGGGGHHHH!!!$w4
GGRRAAAHH HAAA HAAA HAAA!!!$K
...It...feels...so...GOOOOOOD...$K
$s0He's touching the medallion!$w4
But $w2he's still sane...$K
$s1YAAARRRRGGGHHHH!!$w4
GGGWWAAARRRHHHHHH!!!$K  $R�㉺��b|$c1ENA|$s1Master Ike! $w5We cannot win without
aid.$K$PPlease petition one of the other
battalion commanders for help!$K $R�㉺��b|$c1NASIR|$s1Ike! $w5We can't win like this!$w4
Call one of the battalion commanders!$w3
Do it now!$K Tibarn  Naesala Giffca  Don't call. $R�㉺��b|$c1TIBARN|$s1$FSSorry to have kept you waiting...$K$FA$PIs that King Daein?!$K
He's become a monster! The
medallion's chaotic energy is
overflowing from his body.$K$P...No matter. $w2Leave him to me.
I promise you this!$w4 $FSAshnard
will fall at my hands.$K   $R�㉺��b|$c1NAESALA|$s1...Yeah, yeah, I'm here... What's
everyone so worked up abou--$K$PHoly goddess above!!!$K
Is that thing...$w2King Daein?$w3
H-he's a monster!$K$PWait...$w3 You want me to fight THAT?$w5
Are you insane?!$K$PI think you've got the wrong bird!$w4
Blast... This is going to get worse
before it gets better...$K $R�㉺��b|$c1GIFFCA|$s1I have arrived.$K$PWhat is that thing? $w5So...Ashnard
tried to use the medallion, did he?$w4
...Fool...$K  $R�㉺��b|$c1ENA|$s1...A-are you sure?$w4$Fc
...
...$FdI understand.$K$PIf $w2this is the road you choose
to travel,$w4 I will not try to
dissuade you.$K  $R�㉺��b|$c1NASIR|$s1What?! Are you crazy?$w4$Fc
...$FdWell... All right.$K$PIf $w2this is how you want to proceed,$w4
I won't second-guess you.$K$P...$FSI $w2believe in you.$K  $R�㉺��b|$s0$Fc$c0LAY|$s0Ah,$w3 this is awful.$w4 What am I
supposed to do if I can't fight?
I'd make a terrible farmer...$K$w4$Fd$PBlast! Sorry, Ike! I have to withdraw.
Stay safe and win!$K   $R�㉺��b|$s0$Fc$c0ENA|$s0Urrr...$w4$Fd
Only a...$w3little farther...$w2and I
will be with him...$K
$c1IKE2|$s1Ena!$w4 You can't go on with that
wound!$w4 You must retreat!$K
$s0No...$w4 No!$w4 Please, $w2General Ike!$w4
Please let me go...$w4$K
$s1If you were thinking clearly, $w2you'd
see that you've become a burden.$K
$s0Oh!$K
$s1You came here because you have
something you must do, correct?$w2
Please trust us,$w4 and let us help you.$K
$s0...$w2$FcVery well...$K $R�㉺��b|$c0NASIR|$s0Not...$w2here...$w4 I'm $w2so close...$w4
...Ack!$K
$c1IKE2|$s1Nasir!$w4 You can't go on in that
condition!$w4 Get out of here now!$K
$c0NASIR|$s0Ike,$w3 please!$w4 I've come so far.
Please...$K
$c1IKE2|$s1Are you $w2telling me that$w2
you're ready to die here?$K
$c0NASIR|$s0...$K
$c1IKE2|$s1You promised $w2to never again
betray my trust, didn't you?$w4
Then $w2withdraw now.$K$PI don't think $w2you're the type to let
your emotions rule the day.$K$PI won't allow you $w2to prove me
wrong by choosing to die here.$K
$c0NASIR|$s0...$FcI understand...$w4
I'm sorry, $w2Ike.$K  $R�㉺��b|$c0BURAISU|$s0So you're $w2the enemy general, eh?$w4
You're much younger than I had
imagined.$K
$c1IKE2|$s1My age matters not.$w3 The palace will
be ours this day.$K
$s0We $w2will not relinquish it so easily.$K
But allow me to introduce myself as
befits a warrior.$w4 I am Bryce of Daein.$K
$s1And I am Ike of the Greil
Mercenaries.$K$PNow... Let us begin!$K   $R�㉺��b|$c0BURAISU|$s0I am Bryce, general of Daein!$K    $R�㉺��b|$c0BURAISU|$s0Ena... $w5You, too, $w2have had your
fate warped by the king.$K$PYou should pray $w2that you at least
know peace in your final moments.$K  $R�㉺��b|$c0BURAISU|$s0Ah, Tauroneo...$K
I see that you have found another
path to follow. Perhaps you were
inspired by my old friend$w4 Gawain.$K
$c1TAURONEO|$s1Tell me, Bryce.$w4 Beyond mountains of
corpses, $w2what do you see Ashnard
bringing to the future of this place?$K
$s0...I see nothing, save for a land of
absolute darkness and terror.$K
$s1Then why fight by his side?$K
$s0Some men can change, Tauroneo.
Others cannot...$K
I am of the latter type.$w3
There is no other reason.$K    $R�㉺��b|$c0IKE2|$s0Your name was Bryce, was it not?$w4
You fought...$w4a good fight.$K
$c1BURAISU|$s1As...$w4did you...$w2Ike. I...commend you...$K
Your style of$w4 fencing...is unique...$w4
Who was your teacher?$K
$s0My father.$w4 Greil.$K
$s1I thought...$w4I recognized $w2that style.$w4
You truly are Gawain's...$K$P$FSI see it...$w4now...$w4
$FcThe resemblance...$w4is strong...$K
$s0Farewell, knight.$K  $R�㉺��b|$c0BURAISU|$s0...My strength$w2...was not enough...$K
I could not...protect...$w3
my homeland...$w4 Forgive me...$K$Fc
Daein...$K    $R�㉺��b|$c0IKE2|$s0...$K
$s1$FS$c1ASHNARD|$s1Heh heh heh.$w3 I remember
that stance well.$K$PSo your father taught you swordplay,
did he?$w4 How very happy that
makes me.$K
$s0Mad King Ashnard!$w4 I will cut you
down with this blade and end
your reign of terror!$K
$s1You? Cut me down?$w2 Heee...$w4 Good.
If you possess the strength to do so,
then so be it.$K$PThat process $w2is the principle on
which my ideal world operates.$K
$s0What are you talking about?$K  $R�㉺��b|$s0$FS$c0ASHNARD|$s0Heh heh...$w2 Heeee heeee heh...$w4
So you're still alive, are you?$K
$c1ENA|$s1...$K
$s0Do you really want to do this?$w4
Do you believe $w2you can defeat me?$K
$s1I...$w4 I was mistaken.$w4 You are
truly mad...$K$P...Even so...$w4 I wanted to be near
you. $w5If I could have been near you,
it would have been all right...$K
$s0Did you think $w2I would allow that?
Whaaaa haa haa haaaaa!$K
$s1King Ashnard $w2of Daein.$w4
You will die at my hand!$K    $R�㉺��b|$c0ASHNARD|$s0...Eh?$w4 You're not human.$K$PBut your aura... $w2You're not a beast,$w2
nor a bird... $FSYou must be$w2 a dragon!$K
$c1NASIR|$s1King Daein...$w4 There is a reason$w2
I had to meet you.$K
$s0And that is?$K
$s1I would have you tell me how to heal
my warped and twisted laguz brothers.$K$PIf you created them,$w3 you should know
how to restore them.$K
$s0That... That is what you want?
Whaaa haaa haaa haaaaa!
Fool! There never was $w2such a cure!$K
$s1$Fc...$w4 What have you...$w3done...$K$PIt is...already...$w5too late...$K
$s0Tell me, dragon,$w4 were you our Worm?$K$PHeh heh heh.$w3 I see... So your goal
is to stop the Goldoans from fighting.$K
Tsk, tsk, tsk!$K
$s1$FdWe dragons are known for our wrath.
Even spilling your blood today will
not atone for what you have done!$K
$s0Despise me! Loathe me!
Whaaa haa haa haaaaaa!
I will feast on your hatred!$K
Let $w2your hate build, dragon!
Attack me with everything you have!$w5
I know your strength is not gone yet!$K   $R�㉺��b|$s0$FS$c0ASHNARD|$s0A white dragon! $w5To meet with you
here...$w4 Wheeee haa haa haaaa!$w3
For me, $w2there is no greater joy!$K
$c1NASIR|$s1There is a reason I had to meet you,
King Daein.$K
$s0And that is?$K
$s1I would have you tell me how to heal
my warped and twisted laguz brothers.$K$PIf you created them,$w3 you should know
how to restore them.$K
$s0That... That is what you want?
Whaaa haaa haaa haaaaa!
Fool! There never was $w2such a cure!$K
$s1$Fc...$w4What have you...$w3done...$K$PIt is...already...$w5too late...$K
$s0Tell me, dragon,$w4 were you our Worm?$K$PHeh heh heh.$w3 I see... So your goal
is to stop the Goldoans from fighting.$K
Tsk, tsk, tsk!$K
$s1$FdWe dragons are known for our wrath.
Even spilling your blood today will
not atone for what you have done!$K
$s0Despise me! Loathe me!
Whaaa haa haa haaaaaa!
I will feast on your hatred!$K
Let $w2your hate build, dragon!
Attack me with everything you have!$w5
I know your strength is not gone yet!$K  $R�㉺��b|$c0ERINCIA2a|$s0Ashnard!$K
$s1$FS$c1ASHNARD|$s1What?$w4 You again, Princess Crimea?
I told you, you are not the foe
I seek.$K
$s0You may not think so... $w2Yet my
purpose here$w3 is to defeat you.$K$PIn the name of my father, my mother,
my lord uncle, and the countless
citizens of Crimea...$K
You murdered them all!$w4 And I will
never forgive you that!$K
$s1In the world I am creating, only
those with power will be allowed to
live. $w5Hurry and die,$w4 weakling!$K  $R�㉺��b|$c0MIST|$s0As long as you're alive, $w2this war can
not end. How many lives $w2have you
stolen with your selfishness?$K
$c1ASHNARD|$s1You ask that of me? You? A girl?
Pah! Trivial.$w4 You're not worth the
effort it would take to kill you.$K
$s0Give me back my medallion!$w4
You aren't supposed to have it!$K
$s1Are you...$w4Gawain's daughter?$K
$s0I am! And like my father and mother
before me, $w2I will protect the
world from your madness!$K
$s1$FSHeh heh... Hwah hah hah hah...
Wheeee haaa haaa haaaaaarrr!
Perhaps I'll kill you after all!$K
If you are their child, you get special
privileges!$w4 Show me your might!$K    $R�㉺��b|$s0$FS$c0ASHNARD|$s0Galdr singer,$w4 did you come here
today so that I might take
ownership of you?$K
$c1RIEUSION|$s1I have something to ask you.$K
Were you the one who stole the
medallion$w3 and my sister, Lillia,$w2
from Serenes Forest?$K
$s0You know that already, do you not?$K
Why would you come all this way to
ask something you already know?$w4
Do you wish me to deny it?$K
$s1If the dark god is awakened, the
world will once again be flooded.$K$PAnd this time, even our continent
will fall.$K$PYou will not survive that event...
Do you truly desire such an end?$K
$s0I do. Oh, how I do...$K$FA$PIt's true.$w3 The world may be destroyed
by the coming of the dark god.$w4 Then
again, it may not.$K$PI question the way in which our
society is designed.$K$PNo matter what strength a person has,
it is the station he is born into that
controls his destiny.$K$PAnd you cannot control where you
will be born.$K
Do you believe that a person of low
birth should simply endure the curse
of his station?$K$PI think not. $w5If you are stronger
than those around you, $w2$FSyou
should benefit from your strength.$K$PThis is why $w2I will use my strength
to remake this world.$K$PClass and rank will not matter.$w3
Human and sub-human will not matter.$K$PThe strong will possess everything.
The weak will submit to their will.$w4
Is this $w2not the meaning of peace?$K
$s1Are you saying that the lives of those
without strength $w2have no value?$K
$s0That is the natural order.$w4 The only
way for the weak to survive is to
cling to the strong.$K$POur discussion is over. $w5Tell me, frail
little bird who cannot fight;$w4 which do
you choose?$w3 Submission? Or death?$K
$s1...$w3Life proffered to me by your hand
is something I would never accept!$K
$s0Very well... Then I will give you the
alternative! You will be a weight
around my neck no more!$K $R�㉺��b|$s0$FS$c0ASHNARD|$s0That is not the extent of your might,
beast tribe warrior!$K$PI will not allow you to die while the
great power within you still
slumbers.$K$PRelease your rage!$w4 Release your hate!
Show me the fury you keep inside!$K$P $R�㉺��b|$s0$FS$c0ASHNARD|$s0Hawks of Phoenicis!$w4 How strong
are you that Begnion should fear
you so?$K$PI trust I may expect good things
from our battle.$K    $R�㉺��b|$s0$FS$c0ASHNARD|$s0Is that you, $w2Tauroneo?$w4 As I thought...$w2
You betrayed me after all.$K
$c1TAURONEO|$s1...$K
$s0In my father's time, there was a
man who was one of the
Four Steadfast Riders.$K$PThat man grew old and useless,$w3
and retired from the front lines.$K$PHow does his story end, you ask?$w2
Come, let us write it together.$K
$s1Oh, my king...$K
In all of Daein's history, $w5perhaps no
other ruler has used the talents at his
command $w2to the degree you have...$K$PBut all the same,$w4 no other king has
chosen a path so incredibly stupid.$K
$s0Heh heh heh... Will history judge me
to be just or evil? We will not know
until all of this is finished.$K
$s1...Now that I've confronted you
and traded words with you, I have
come to a decision.$K$PThroughout Daein,$w3 I, Tauroneo,
will be known as the king killer.$w3
Come! Let me earn my name!$K  $R�㉺��b|$c0ASHNARD|$s0Who are you, dog?$K
$s1$FS$c1HAAR|$s1You don't seem to recall my name...$w4
I'm a man who was once a part of
your army, if just barely.$K
$s0You're some nobody who turned traitor
and joined the Crimeans?$w5
I've no interest in you.$w4 Begone.$K
$s1I'll leave as quickly as I'm able.$FA$w4
Right after I've taken your head!$K   $R�㉺��b|$c0ASHNARD|$s0Annoying little insect. Whose path is
it that you think to block?$K
$c1JILL|$s1...My father died because of you.$w4
He tried so hard...to prove he was
a loyal citizen of Daein.$K$PAnd you never recognized his efforts.
Not even once.$K
$s0Are you complaining to me?$w4 Come
back some other time.$w4 I'm busy.$K
$s1Answer me!$K My father was General
Shiharam! Why did he have to die?$K
$s0Eh? Who are you talking about?$w4
The name is unfamiliar... I don't think
we ever had such a general.$K
$s1What?$K
$s0This is a waste of time.$w4
Leave my sight at once.$K$d0
$s1...$w4
Ashnard...$K$PAshnard!!$K
ASHNARD!!$K$PI...$w2will never forgive you!$w5
NEVER!!!$K    $R�㉺��b|$s0$FS$c0ASHNARD|$s0Oh, the king of hawks!$w4 Meeting
your feathered carcass here today is...$K$PFantastic!$w3 I am so pleased!$K
$s1$FS$c1TIBARN|$s1As am I.$K$PI want to rake my talons across your
face so much, I can hardly control
myself.$K
$s0Waaaaa haaaa haaa! Heeee heee haaa!$w4
Perfect!$w3 PERFECT!!!$w3 That $w2is
what war is all about!$K
$s1$FACome.$w3 Let's get started.$K   $R�㉺��b|$c0NAESALA|$s0Just thinking about fighting you makes
me want to forget the whole thing.$w4
Heck, it's not like I'm getting paid...$K$P$FSSay... Do you want to hire me?$K
$s1$FS$c1ASHNARD|$s1What's this? $w2Do you wish to return
to Daein's loving embrace?$K
$s0I do... If you agree $w2to make me very,
very rich.$K
$s1Enough of your lies,$w3 crow.$w4
Even now, $w2your beady eyes look
to find a chink in my armor.$K
$s0Ah...you found me out.$w4 All right,$w2
let's proceed in earnest. $w2No more
tricks...$w4 Oh, look over there!$K$P$FADidn't work, eh? Then die, $w2madman!$w5
I won't be doing you any favors$w2
if I let you live.$w2$K   $R�㉺��b|$s0$FS$c0ASHNARD|$s0You're the one they speak of in
whispers... The lion king's shadow.$K$PWhat are you doing so far from
your body, shadow? Am I so terrible
that your king hides in fear?$K
$c1GIFFCA|$s1Your strength, King of Daein,$w3 is not
sufficient. That is why I am here.$K$PIf I fail to stop you today, $w2then
your next opponent will be our king.$K$PBut first, this imposter will measure
your fighting prowess.$K$d1
$s0What impudence!$w4 Are you prepared
to become a pile of bones for your
king? You'll make a fine snack!$K  $R�㉺��b|$s0$FS$c0ASHNARD|$s0One blow.$w4 For nameless wretches
like you, one blow is more
than enough.$K $R�㉺��b|$s0$FS$c0ASHNARD|$s0Heh heh...$w3excellent...$w4
Excellent! $w2So good!$K
More...$w3more, I say!$K
At this time of ascension,$w2
it's not enough...$w4not enough...$K    $R�㉺��b|$s0$FS$c0ASHNARD2|$s0Oh, the king of hawks!$w4 Meeting
your feathered carcass here today is...$K$PFantastic!$w3 I am so pleased!$K
$s1$FS$c1TIBARN|$s1As am I.$K$PI want to rake my talons across your
face so much, I can hardly control
myself.$K
$s0Waaaaa haaaa haaa! Heeee heee haaa!$w4
Perfect!$w3 PERFECT!!!$w3 That $w2is
what war is all about!$K
$s1$FACome.$w3 Let's get started.$K  $R�㉺��b|$c0NAESALA|$s0Seeing you like this makes me want to
forget this whole fighting thing.$w4
Heck, it's not like I'm getting paid...$K$P$FSSay... Do you want to hire me?$K
$s1$FS$c1ASHNARD2|$s1What's this? $w2Do you wish to return
to Daein's loving embrace?$K
$s0I do... If you agree $w2to make me very,
very rich.$K
$s1Enough of your lies,$w3 crow.$w4
Even now, $w2your beady eyes look
to find a chink in my armor.$K
$s0Ah...you found me out.$w4 All right,$w2
let's proceed in earnest. $w2No more
tricks...$w4 Oh, look over there!$K$P$FADidn't work, eh? Then die, $w2madman!$w5
I won't be doing you any favors$w2
if I let you live.$w2$K    $R�㉺��b|$s0$FS$c0ASHNARD2|$s0You're the one they speak of in
whispers... The lion king's shadow.$K$PWhat are you doing so far from
your body, shadow? Am I so terrible
that your king hides in fear?$K
$c1GIFFCA|$s1Your strength, King of Daein, even
with your medallion,$w3 is not
sufficient. That is why I am here.$K$PIf I fail to stop you today, $w2then
your next opponent will be our king.$K$PBut first, this imposter will measure
your fighting prowess.$K$d1
$s0What impudence!$w4 Are you prepared
become a pile of bones for your
king? You'll make a fine snack!$K  $R�㉺��b|$s0$FS$c0ASHNARD2|$s0Heh heh...$w3excellent...$w4
Excellent! $w2So good!$K
More...$w3more, I say!$K
At this time of ascension,$w2
it's not enough...$w4not enough...$K   $R�㉺��b|$c0IKE2|$s0Now...it is truly over.$K $R�㉺��b|$c0IKE2|$s0Now...it is truly over.$K $R�㉺��b|$c1IKE2|$s1Ena, $w2stay back!$w4
The king's mount is still alive!$K
$Ub$H$c0ENA|$s0...$K $R�㉺��b|$c1IKE2|$s1Stay back!$K  $R�㉺��b|$c1IKE2|$s1Ena!$K
$c3ERINCIA2|$s3No!$Fc$K    $R�̂݉�b|$F1$FCIKE2|$F1$PWhat's going on?$w4 His mount is
so calm...$K$F1$FD$P$F1$FCNASIR|$F1$PIke...$w4 Let them be.$K$F1$FD$P$F1$FCIKE2|$F1$PNasir, $w2what's this all about?$K$F1$FD$P$F1$FCNASIR|$F1$PThat...$w2is her mate. $w5As death nears,
he has regained his sanity.$K$F1$FD$P$F1$FCIKE2|$F1$PKing Daein's mount$w3 is Ena's...$w2mate?$K  $R�̂݉�b|$F1$FCL_IKE2|$F1$PHuh?$K $R�̂݉�b|$F1$FCL_ENA2|$F1$P...Rajaion...$K    $R�㉺��b|$c0LEARNE|$s0#F01$O2Say, Brother...#F02$O1$K
$c1RIEUSION|$s1Leanne?$w4 What is it?$K
$s0#F01$O2That dragon with the big wings...#F02$O1
#F01$O2I wonder if he's a laguz?#F02$O1$K
$s1A laguz... No, it can't be. Ashnard's
mount was a wyvern...$w4
Wasn't it?$K
$s0#F01$O2I can't tell for sure,#F02$O1
#F01$O2but it feels that way.#F02$O1$K
$s1#F01$O2If he is a laguz,#F02$O1
#F01$O2the transform galdr may#F02$O1
#F01$O2restore him to normalcy.#F02$O1$K
$s0#F01$O2Then let us sing.#F02$O1$K$d0
$c0IKE2|$s0What are you doing?$K
$s1Be patient,$w3 please.$w4 There's
something we want to try.$K$d1
$s0Huh?$K
$c1NASIR|$s1...$K   $R�㉺��b|$c0LEARNE|$s0#F01$O2Say, Brother...#F02$O1$K
$c1RIEUSION|$s1Leanne?$w4 What is it?$K
$s0#F01$O2That dragon with the big wings...#F02$O1
#F01$O2I wonder if he's a laguz?#F02$O1$K
$s1A laguz... No, it can't be. Ashnard's
mount was a wyvern...$w4
Wasn't it?$K
$s0#F01$O2I can't tell for sure,#F02$O1
#F01$O2but it feels that way.#F02$O1$K
$s1#F01$O2If he is a laguz,#F02$O1
#F01$O2the rebirth galdr may#F02$O1
#F01$O2restore him to normalcy.#F02$O1$K
$s0#F01$O2Then let us sing.#F02$O1$K$d0
$c0IKE2|$s0What are you doing?$K
$s1Be patient,$w3 please.$w4 There's
something we want to try.$K$d1
$s0Huh?$K   $R�㉺��b|$s0$Fc$c0RAJAION|$s0...$K
$c3IKE2|$s3Reyson...$w2that's...$K
$c1RIEUSION|$s1Leanne $w2told me that dragon's
true form had been warped.$w4
So we sang the galdr of rebirth...$K   $R�㉺��b|$c3ENA2|$s3Ra...$w4Rajai...$w3on...$K
$s0$Fh$c0RAJAION|$s0Err...$w2aah...$K
$s3...Rajaion? $w6D-do you know who I am?$K
$s0$Fd...E...$w4 Ena?$K
$s3$FSYes... $w6Yes! You recognize me!$K
$s0You were made...to suffer...because of
me... $w6$FcI'm sorry.$K
$s3...Sniff... Rajaion! Rajaion!
Oh, Rajaion...$K
$s0$Fd$FS...Ena... $w5Let's return to Goldoa.$w6
The two of us...$w3together.$K
$s3I will go anywhere, my love, $w2as long
as it is with you.$K
$s0Ena...$w5from this day forward...$w4$Fh
For$w2ever...$K$Fc
...$K$d0
$s3$FA...$w4$Fc
Sniff...$K$P...sniff...$w4$w4
Ah, Rajaion...$K$d3   $R�㉺��b|$c1NASIR|$s1...$K
$c3IKE2|$s3He was one of the dragon tribe?$K
$s1That's right.$w4 He and Ena $w2were
engaged to be married...$K$PAnd then,$w4 he was driven mad by
King Daein, $w2and his form warped.$K
$s3...I see.$K $R�㉺��b|$c0IKE2|$s0He was one of the dragon tribe?$K
$c1RIEUSION|$s1Yes.$K
$c3LEARNE|$s3#F01$O2Poor thing...#F02$O1$K$w6 $R�㉺��b|$c0MIST|$s0Hmm...$K$d0$w6
$c3MIST|$s3Hmmm...$K$d3$w5
$c2MIST|$s2Aha! Is that... Nope! Dang...$K$d2$w6
$c1MIST|$s1Hmm...$K
Ah!$w3 $FSHere it is!$K
$c0IKE|$s0What is it, $w2Mist?$w4
Did you find something?$K
$s1The medallion, Ike! The medallion!$w5$Fc
I finally...$w2have it back...$K
$s0Mist, $w2that medallion is--$K
$s1$FdYeah...$w4 I know.$K$d1$d0$w6
$c0MIST|$s0Reyson! Leanne!$K
$c3LEARNE|$s3#F01$O2Hm? What is it, Mist?#F02$O1$K
$c1RIEUSION|$s1What?$K
$s0$FSHere.$K
$s1$Fo...Oh!$K
$s3#F01$O2The medallion.#F02$O1$K
$s0$FA$FcThe medallion belongs in
Serenes Forest.$K$Fd$FS$PMy mother...$w4was only holding it$w2
for Lillia.$K
$s1...$Fc$w5$Fd
Leanne, $w2you take it.$K
$s3#F01$O2Thank you, little Mist.#F02$O1$K$d3$w5
$s0...$K
$c2IKE2|$s2...$K
$s1$FcThank you,$w3 daughter of Elena.$K$w4$Fd$PIn the memory of my departed sister...$w5
I accept the medallion from you.$w6$K$Ub$H  $R�w�i�Ȃ���b|$F2$FS$F2$FCL_IKE3|$F2$PFor the past year, $w2I've been focused
on winning this war.$K$PI stand here today $w2as a testament to
your fortitude and commitment.$K$PI understand this will never suffice,$w4
but $w2I wanted to take a moment
to say something to you all.$K$PThank you.$K
I hope I may continue to rely on you.$K$w6$N$UB$H   $F2$FD$F1$FS$F1$FCL_IKE3|$F3$FS$F3$FCL_SENERIO|$F3$PThere's only one place for me
to be, Ike...and it's by your side.$K$N$UB$H  $F2$FD$F1$FS$F1$FCL_IKE3|$F3$FS$F3$FCL_SENERIO|$F3$POf course.$w4 I hope that I may
continue $w2to be of service.$K$N$UB$H  $F4$FS$F4$FCL_TIAMAT|$F4$PYou've become a great man, Ike.$w4
For now and ever more, please$w2
continue to be our commander.$K$N$UB$H    $F4$FS$F4$FCL_TIAMAT|$F4$PYou've grown so much...$w4 I would like
nothing better$w4 than if Commander
Greil $w2and Elena could see you now...$K$N$UB$H  $F4$FS$F4$FCL_OSCAR|$F4$PWhat a long road we've traveled! $w2And yet,
in many ways, it seemed to pass so quickly.$w4
I'm proud to have fought beside you, Ike.$K$N$UB$H $F4$FS$F4$FCL_OSCAR|$F4$PWhat a long road we've traveled! $w2And yet,
in many ways, it seemed to pass so quickly.$w4
I'm glad it's finally over.$K$N$UB$H   $F3$FD$F3$FS$F3$FCL_MIST|$F3$PWe did well, $w2didn't we?$w4
I'm sure Mom and Dad $w2would
be proud of us.$K$N$UB$H  $F4$FS$F4$FCL_BOLE|$F4$PGreat job, $w2Ike!$K
Of course,$w3 if I hadn't been by your
side the whole time, victory might have
slipped away...$K$N$UB$H    $F3$FS$F3$FCL_LOFA|$F3$PIke! Ike! Er...$w3 I mean, $w2Commander Ike!$K
I'm $w2going to keep practicing so I can
be better than ever! Thanks for having
faith in me!$K$N$UB$H    $F4$FS$F4$FCL_KILROY|$F4$PFinally...$w3it's finally over.$w4
At long last, we can return to a
life without war.$w3 Praise the goddess.$K$N$UB$H $F3$FS$F3$FCL_GATRIE|$F3$PIke!$w4 Are we $w2going to go back to being
mercenaries? $w5I'm a great soldier $w2and all,
but...$K$PThe easygoing life of a mercenary $w2is
the only life for me. Tee hee!$w4 Now let's
go find some good-looking lasses!$K$N$UB$H  $F4$FS$F4$FCL_CHINON|$F4$P...Bah. I suppose you want some kind of
congratulations now, right?
Well, too bad.$K
You're a snot-nosed whelp, and I'm
still better than you.$w4
Don't ever forget that.$K$N$UB$H    $F3$FS$F3$FCL_WAYU|$F3$PHeya, Boss!$w4 We did it! Whooo-hooo!
You know, $w2I am completely
in love $w2with your fighting style.$K$PIf I could train under you, it would be
great!$w4 So let me stick around for
a while.$w4 All right?$K$N$UB$H $F4$FS$F4$FCL_VOKE|$F4$PI've no more work here.$w3 I will be leaving
you shortly. $w5If you have need of my
services, $w2you know how to reach me.$K        $R�w�i�Ȃ���b|$F3$FS$F3$FCL_IKE3|$F3$PElincia. $w5You've had to wait a long time,$w3
but I finally fulfilled my contract.$w5
The mission is complete.$K
$F1$FS$F1$FCL_ERINCIAh|$F1$PMy lord Ike...$w4 On behalf of all Crimea$w2 and
my departed father, mother, and uncle,$w4
I $Fcthank you once again...$K$F1$FD
$F3$P$FAOh, stop!$w3 Come on, will you please stop
doing that?$K
$F1$FCL_ERINCIAh|$F1$PPardon?$K
$F3$PI think I've gotten used to a few of these
noble customs and whatnot, but I still
can't handle the bowing.$K$PIt looks painful, $w2and it's so cold
and formal.$w4
$FSJust talk to me without all the ceremony.$K
$F1$PMy lord Ike... $w5That's, um...$K
$F3$PYeah?$K
$F1$PN-$w2nothing!$K
$FSIt's nothing...$w3$K$P$F1$FD$w6$N$UB$H $R�w�i�Ȃ���b|$F3$FS$F3$FCL_IKE3|$F3$PElincia. $w5You've had to wait a long time,$w3
but I finally fulfilled my contract.$w5
The mission is complete.$K
$F1$FS$F1$FCL_ERINCIAh|$F1$PMy lord Ike...$w4 On behalf of all Crimea$w2 and
my departed father, mother, and uncle,$w4
I $Fcthank you once again...$K$F1$FD
$F3$P$FAOh, stop!$w3 Come on, will you please stop
doing that?$K
$F1$FCL_ERINCIAh|$F1$PPardon?$K
$F3$PI think I've gotten used to a few of these
noble customs and whatnot, but I still
can't handle the bowing.$K$PIt makes me antsy...$w2and itchy, too.$K
$F1$P$FSOh, my lord Ike...$K
Hee hee!$w3$K$P$F1$FD$w6$N$UB$H  $F1$FS$F1$FCL_ULYSSES|$F1$POh, $w2glorious day of sweet victory!
Praises upon the day the goddess did
see fit to send Sir Ike to save our land.$K$N$UB$H    $F0$FS$F0$FCL_LUCHINO|$F0$PThank you, $w2General Ike.$K$PBecause of you, I believe we better
understand $w2how best to serve
Princess Elincia.$K$N$UB$H $F1$FS$F1$FCL_GEOFFRAY|$F1$PThrough your strength, $w2the dark clouds that
blanketed Crimea have been dispelled.$K$PFrom this day forth, $w2we will give our all
to see the restoration of this land
and its people.$K$N$UB$H   $F0$FS$F0$FCL_KEVIN|$F0$PGeneral, $w2you are Crimea's savior!$w3
For your meritorious service, I salute you!
Huzzah! Nay, a thousand huzzahs!$K$N$UB$H  $F1$FS$F1$FCL_CHAP|$F1$PWhew! $w2Am I glad that's over!$w4
When I saw King Daein, I was sure I was
done for! Or that he'd torture me...$K$PBut you were a bull!$w4 Thank you!
Now I can go home and see my
family once more!$K$N$UB$H   $F0$FS$F0$FCL_NEPENEE|$F0$PWhen I get back to the countryside,$w3
I'm gonna boast to all my family and
friends that I fought under you.$K$N$UB$H    $F1$FS$F1$FCL_CALILL|$F1$PLargo and I $w2are going to stay here and
open up a shop.$K
$F0$FS$F0$FCL_LARGO|$F0$PWith Crimea undergoing reconstruction,$w2
there are going to be a lot of people
moving about.$K$PWe'll open an inn with good food and
drink.$w3 And free butter on every table!
We'll be rich in no time!$K
$F1$PWe'll let you know when everything's all
set up. $w2You can drop in anytime.$K
$F0$PWe'll even give you special rates!$w4
Hmm... Maybe we should call it
General Ike's Inn!$K$N$UB$H    $F1$FS$F1$FCL_CALILL|$F1$PGeneral,$w4 I owe you a debt of gratitude.$w4
I'm going to stay in Crimea and open a
shop in the city. I do hope you'll come by!$K$N$UB$H $F0$FS$F0$FCL_LARGO|$F0$PYou know, $w2I owe you a lot.$w4 I think
I'm going to stick around and open
an inn.$w4 Hope you'll come by and visit.$K$N$UB$H     $R�w�i�Ȃ���b|$F3$FCL_IKE3|$F1$FCL_TANIS|$F1$PGeneral Ike, I will be taking my leave
of you for the time being.$K$PI must return to Begnion and present
a report on the war's outcome.$K
$F3$PAren't you going to take Begnion's soldiers
with you? You lent us quite a few.$K
$F1$P$FSThough the war may be over, it will take
many weeks to see the country secure.$K$PI spoke with the princess earlier, and she
asked that we help if possible. So I'll leave
them in your care a while longer.$K
$F3$PWe really do owe Begnion a lot, don't we?
In the end, $w2we got not only you, but a
whole battalion of reinforcements.$K$PGeneral Zelgius and his troops are the
reason we were able to minimize casualties
during the final battle.$K$PHe and his men took care of the
retreating Daeins and allowed us to
focus on the enemies before us.$K
$F1$PNo matter the assistance you had,
the victory itself is a result of your
strength and leadership.$K$PI know two people who will be very
pleased to learn of your triumph.$K
$F3$P$FSPlease give my thanks $w2to both the
apostle and Sephiran.$K$PI plan to go and thank them myself
someday, but...$K
$F1$P$FcUnderstood.$K$Fd
Fare well, $w2General Ike.$w3
I look forward to seeing you again.$K
$F3$PFare well.$K$F1$FD$N$UB$H   $R�w�i�Ȃ���b|$F3$FCL_IKE3|$F1$FS$F1$FCL_ZELGIUS|$F1$PIt was a glorious victory, $w2General.$K
$F3$PGeneral Zelgius!$w4 What are you$w2
doing here?$K
$F1$P$FALooking at it now, and it all may seem a bit
impertinent, but...$K$PI came with reinforcements in case things
took a turn for the worst.$K$PYour opponent was $w2the Mad King Ashnard
after all, and if worse had come to worst...
well, you might have needed the help.$K$PDuke Perseus ordered us to join in the
fight and rescue Princess Elincia at the
very least.$K
$F3$POh, I see.$K
$F1$PMy apologies.$K
$F3$PNo, no...$w2 I appreciate the concern.$w4
It was a dangerous day.$K
$F1$P$FSYour Crimean army proved up to the task.
Let me offer you my congratulations.$K$PYou did well to win the day.$w4
I'm certain the troops we lent you, and
the apostle herself, are quite pleased.$K
$F3$POur success was $w2thanks to the Begnion
shield protecting our flank.$K
Not the soldiers you lent us, $w2but your
reinforcements capturing and holding the
retreating Daein soldiers.$K$PBecause of that, we were able to
concentrate on the enemies before
us without concern for our rear guard.$K
$F1$PI was merely following the orders of
my superiors.$K
$F3$PIn that case, $w2please express my appreciation
to the apostle and Sephiran.$K$POne day, $w2I will go and thank them in
person.$K
$F1$PUnderstood.$w4 $FANow then, $w2I will return
to Daein.$K
$F3$PWhat about the troops you've lent us?$K
$F1$PThough the war may be over, it will take
many weeks to see the country secure.$K$PI spoke with the princess earlier, and she
asked that we help if possible. So I'll leave
them in your care a while longer.$K
$F3$P$FSI see.$w4 It's very appreciated.$K
$F1$P$FSIt's our pleasure.$w4 By your leave.$K$F1$FD$N$UB$H    $F1$FS$F1$FCL_MARCIA|$F1$PIke! Hey, handsome!$w4 I've decided to return
to service in the Begnion pegasus knights!
Cool beans, huh?!$K$POh, I owe so much to you, $w2Ike.$w4
Thank you so very much!
I'll see 'ya around!$K$N$UB$H  $F0$FS$F0$FCL_MAKAROV|$F0$PI think I may try to start over in Begnion.
Maybe it's too much, too soon...$K$PBut I just want to live a more responsible
life. Plus I'm tired of men threatening
to break my knees... Good-bye, Ike!$K$N$UB$H  $F1$FS$F1$FCL_STELLA|$F1$PGood-bye, $w2General Ike.$K$PThis war has given me the confidence$w2
to enter the service of the Begnion
knights.$K$PThank you so much!$K$N$UB$H  $F0$FS$F0$FCL_DALAHOWE|$F0$PDevdan is glad all the fighting stopped.$w3
Devdan $w2prefers the peace and quiet.$w4
War is not good for anything.$K$N$UB$H    $F1$FS$F1$FCL_TOPUCK|$F1$P...Well, we're $w2going home.$K$PAll of our desert friends are waiting for
us. And wow, do we have some stories
to share with them!$K$N$UB$H  $F0$FCL_MWARIM|$F0$PLaguz and beorc...$w3 Perhaps the
gap between us has narrowed.$K$PWar is horrible.$w4 $FSYet, maybe
we've gained something of value,
after all.$K$N$UB$H    $F0$FS$F0$FCL_SOANVALCKE|$F0$PFind me when you come to the dunes.$w4
We can sit and talk, $w2with no fighting.$K$N$UB$H $R�w�i�Ȃ���b|$F1$FS$F1$FCL_IKE3|$F3$FS$F3$FCL_LAY|$F1$PAre you leaving already?$K
$F3$PYep! I'm outta here. I've got some
important guests to convey to the king.$K
$F1$P$FAGuests?$K$P$F4$FS$F4$FCL_LEARNE|$F4$P#F01$O2Master Ike!$w4 Thank you for everything.#F02$O1$K$F3$FD
$F3$FS$F3$FCL_RIEUSION|$F3$PHe's talking about us.$w4 We're taking my
father to visit Gallia for a while.$K$PWe herons $w2prefer to live near
the forests, after all.$K$PTibarn spoke with King Caineghis on
our behalf.$K
$F1$PYou're not returning to Serenes?$K
$F3$P$FAWhile we made our peace with the apostle,
we're not ready to live there again.$K
$F1$P$FSI see.$K
You'll be able to return someday.
Beorc and laguz will come to understand
and respect one another.$K
$F3$P$FSYou may be right.$w4
I hope you are.$K$F3$FD$F4$FD
$F4$FCL_GIFFCA|$F4$PAre you ready?$w4 We should be leaving
soon.$K
$F1$PGiffca, I'm in your debt as well.
Gallia's a very special place to me...
I'd like to visit again someday, if I may.$K
$F4$P$FSCome whenever you are able.$w4
The king will be pleased to see you.$K$P$F4$FD
$F3$FS$F3$FCL_LAY|$F3$POh, and another thing. You'll be
seeing me again soon.$K$PGallia's decided not to spare any effort
in aiding Crimea's reconstruction.$K$PI'll be back shortly with a whole army
of workers and laborers. $w2Look for us!$K
$F1$PAll right, we'll be waiting.$K$F1$FD$F3$FD$N$UB$H $R�w�i�Ȃ���b|$F1$FS$F1$FCL_IKE3|$F3$FS$F3$FCL_LAY|$F1$PAre you leaving already?$K
$F3$PYep! I'm outta here. I've got some
important guests to convey to the king.$K
$F1$P$FAGuests?$K$P$F4$FS$F4$FCL_LEARNE|$F4$P#F01$O2Master Ike!$w4 Thank you for everything.#F02$O1$K$F3$FD
$F3$FS$F3$FCL_RIEUSION|$F3$PHe's talking about us.$w4 We're taking my
father to visit Gallia for a while.$K$PWe herons $w2should live somewhere near
a forest, after all.$K$PTibarn spoke with King Caineghis on
our behalf.$K
$F1$PYou're not returning to Serenes?$K
$F3$P$FAWhile we made our peace with the apostle,
we're not ready to live there again.$K
$F1$P$FSI see.$K
You'll be able to return someday.
Beorc and laguz will come to understand
and respect each other.$K
$F3$P$FSYou may be right.$w4
I hope you are.$K$F3$FD$F4$FD
$F4$FCL_GIFFCA|$F4$PAre you ready?$w4 We should be leaving
soon.$K
$F1$PGiffca, I'm in your debt as well.
Gallia's a very special place to me...
I'd like to visit again someday, if I may.$K
$F4$P$FSCome whenever you are able.$w4
The king will be pleased to see you.$K$PAnd one more thing... Gallia will not spare any
effort in aiding Crimea's reconstruction.$K$PWe will be sending supplies and workers
to you shortly.$K
$F1$PThat is much appreciated.$K$F1$FD$F4$FD$N$UB$H   $F1$FS$F1$FCL_MIST|$F1$POh, $w2wait!$w4 Reyson!$w3 Leanne!$K
$F3$FS$F3$FCL_RIEUSION|$F4$FS$F4$FCL_LEARNE|$F3$PWhat is it?$K
$F1$PUm...$w3do you think...$w3I could
touch the medallion one last time?
For my mom? ...And dad?$K
$F4$P#F01$O2Yes. $w2It's all right, isn't it,$w4 Brother?#F02$O1$K
$F3$POf course.$w4 Go ahead, $w2put out your
hand.$K
$F1$PAll right.$Fc$w4
...$w6$Fd
Thank you very much.$K
$F3$P$FAIs that enough?$K
$F1$PYes.$w4 I just wanted to...$w3
say good-bye.$K
$F3$P$FSThank you.$K
$F1$PHm?$K
$F3$PAnd you, too, Ike.$K
$F0$FS$F0$FCL_IKE3|$F0$PWhat?$K
$F3$PAnd $w2I'd also like to give our heartfelt
thanks to your parents as well.$K$PFor fulfilling the hopes$w3 of our
sister...$w3 Thank you.$K
$F4$P#F01$O2Thank you,$w3 our kind-hearted#F02$O1$w2
#F01$O2Beorc friends.#F02$O1$K
$F1$PYou...$w3 You're welcome!$K$w6
$F3$PSo, Ike,$w4 when you come to Gallia,$w2
you must visit us as well. $w5Understand?$K
$F0$PYes, $w2I'll be there.$w4 Take care.$K$N$UB$H  $F1$FS$F1$FCL_MIST|$F1$POh, $w2wait!$w4 Reyson!$w3 Leanne!$K
$F3$FS$F3$FCL_RIEUSION|$F4$FS$F4$FCL_LEARNE|$F3$PWhat is it?$K
$F1$PUm...$w3do you think...$w3I could
touch the medallion one last time?
For my mom...and dad?$K
$F4$P#F01$O2Yes. $w2It's all right, isn't it,$w4 Brother?#F02$O1$K
$F3$POf course.$w4 Go ahead, $w2put out your
hand.$K
$F1$PAll right.$Fc$w4
...$w6$Fd
Thank you very much.$K
$F3$P$FAIs that enough?$K
$F1$PYes.$w4 I just wanted to...$w3
say good-bye.$K
$F3$P$FSThank you.$K
$F1$PHm?$K
$F3$PAnd you, too, Ike.$K
$F0$FS$F0$FCL_IKE3|$F0$PWhat?$K
$F3$PAnd $w2I'd also like to give our heartfelt
thanks to your parents as well.$K$PFor fulfilling the hopes$w3 of our
sister...$w3 Thank you.$K
$F4$P#F01$O2Thank you,$w3 our kind-hearted#F02$O1$w2
#F01$O2beorc friends.#F02$O1$K
$F1$PMmm...yes!$K$N$UB$H   $F3$FD$F3$FS$F3$FCL_MORDY|$F3$PIke!$w4 I will help rebuild Crimea, too.$K
I will lend you much strength!$K$N$UB$H   $F4$FD$F4$FS$F4$FCL_LETHE|$F4$PI don't know when, but...$w4 If that thing we
talked about happened...that would be fine.
I guess.$w5 Not that I care.$K$PSo...good-bye.$K$N$UB$H    $F4$FD$F4$FCL_LETHE|$F4$PI can't believe I'm doing this, $w2but...
I must admit that you've done well.$K$P$FSYou were a $w2good fighter.$w4
Too good $w2to leave with these beorc.$K
We'll $w2meet again.$K$N$UB$H  $R�w�i�Ȃ���b|$F3$FS$F3$FCL_IKE3|$F1$FS$F1$FCL_TIBARN|$F1$PWell,$w4 it's about time for us to take wing.$K
$F3$PWe've built quite a close bond,
haven't we?$K
$F1$PThis is true.$w4 We're especially grateful
for your help in Serenes Forest.$K$PThe next time you're visiting the southern
coast, $w2come to Phoenicis. The entire
country will celebrate your arrival.$K
$F3$PThe country of the hawk tribe, eh?$w4
That would be fun. I'm interested in what
kinds of food you eat.$K
$F1$PWe collect berries from trees on peaks that
no beorc could climb.$w4 The juices and
desserts made from it are beyond compare.$K$PWe have ocean delicacies, $w2mountain
treats...$w3 We have everything.$K
$F3$PI'll pass on the desserts... But I'll take
extra helpings of meat!$K
$F1$PHa ha!$w3 Leave it to me.$K
$F0$FCL_NAESALA|$F0$P$FSI hate to interrupt your gleeful chat,$w2
but I thought I should tell you...$K$PYou don't have to visit Kilvas. $w5It's our
policy $w2not to invite beorc into our home.
Unless they pay well...$K
$F3$PAh, King Kilvas... $w5Despite all of your
posturing,$w2 you came to our aid
in the end!$K$PYou turned out to be a better ally $w2than
I dared hope for.$K
$F0$P$FAPah!$w4 Keep your foolish tongue inside
your foolish head! ...And don't tell anyone!
I have a reputation to think of.$K$P$F0$FD$w4
$F1$PFare well.$w4 And I'm serious about
Phoenicis, too. $w2Come anytime!$K$F1$FD$w6$N$UB$H   $F1$FCL_VULCI|$F1$PGeneral, the bird tribes are in your debt.
$FS$w4...We are grateful.$w5 Please
take care.$K$N$UB$H   $F0$FS$F0$FCL_JANAFF|$F0$PIf you ever have need of the king's eyes,$w4
fire a flaming arrow $w2from a high place.$w4
I'll see it $w2and come flying!$K$PUm, $w2that is,$w3 if I'm not busy on an
errand for the king.$K$N$UB$H  $R�w�i�Ȃ���b|$F3$FS$F3$FCL_IKE3|$F3$P...$K$N$UB$H $F1$FCL_JILL|$F1$P...General Ike.$w4 I, $w2I will never,$w3
ever forget you. Thank you for showing
me the error of my ways.$K$N$UB$H    $F0$FCL_HAAR|$F0$P$FSI'm just glad that it's finally over.$w5
Maybe now, $w2I can get some sleep.
Yaaawwwnn... Zzzzzzz...$K$N$UB$H  $F0$FCL_SOTHE|$F0$PThings are going to be rough $w2in Daein, too.$w4
I don't know what the future holds, but I'm$w4
heading back.$K$FS
It's my$w3 homeland, after all.$K$N$UB$H $F1$FCL_TAURONEO|$F1$P...I have played my part. $w6All that remains$w2
is for me to take my leave of this place.
History will judge my actions...$K$N$UB$H  $F0$FS$F0$FCL_ELAICE|$F0$PMuston and the others are going
to Daein, and I think I'm going to go
with them.$K$PThank you for everything, General Ike.
Hmm... I hope they packed enough food...
I'm pretty hungry...$K$N$UB$H $F1$FCL_ZIHARK|$F1$PCrimea's an interesting place,$w3 but
I've decided to travel to Daein.
...$w3We never did have our match, did we?$K$POf course, $w2I'm no longer in the same
class as you...$FS I'll be training hard for the
next time we meet!$K$N$UB$H   $F1$FCL_ZIHARK|$F1$PCrimea's an interesting place,$w3 but I've
decided to travel to Daein.$FS Perhaps
fate will bring us together again.$K$N$UB$H   $=1500$R�w�i��b|$B��̒�|$<$F3$FCL_IKE3|$F1$FCL_ENA2|$F3$PHow odd, Ena. We've been both enemies
and allies.$K
$F1$PThanks to you, Rajaion was saved.
And...$w3so was I...$w4 $FSThank you.$K
$F3$PSo, you were with King Daein because
you were trying to save Rajaion?$K
$F1$P$FAYes.$K
$F0$FCL_NASIR|$F0$PEna's fiance went missing many years ago.$w4
After Ena finally found him, she came to me
for help.$K$PShe told me that Rajaion was with King
Daein, and that he had been warped
almost beyond recognition.$K$PLong ago,$w4 Ena's parents died, and I
was unable to do anything for her. Even
so, she still came to me for help.$K$PNo matter what,$w4 I had to help her...$K$PIt was to that end that I used you......$w4
$FcI am so sorry.$K
$F3$P$FSIt's all in the past now.$w4 There's nothing
for you to worry about any longer.$K
$F0$P$FdThank you, Ike.$K
$F3$P$FAWill Ena $w2return to Goldoa?$K
$F1$PYes.$K
We must take Rajaion $w2back to his
hometown.$K
$F3$PWe? Are you going, too, Nasir?$K
$F0$P$FSYes, I am.$K
For the first time in decades, I will walk
on Goldoan soil.$K
$F3$PThat'll be nice. $w2Take care of yourself.$w4
And give my regards to $w2Kurthnaga.$K
$F1$P$FSI will.$w4 Until we meet again.$K$P$F0$FD$F1$FD$w4
$F3$PNasir!$K
$F0$FCL_NASIR|$F0$PHm?$K
$F3$PI don't know what you thought, $w2but
I... $w2I always trusted you.$K$PExcept for that one moment when I
learned of your deception, I never
thought of you as an enemy.$K
$F0$P$FSHuh. Even now you defy my prediction.$K
$F3$PPrediction?$K
$F0$PWhen we were sailing off the coast of
Phoenicis, $w2remember?$K
I said that war would change how
you look at things.$K$P$FAAnd yet...$w4 Through all that's happened,$w2
you've remained the same.$K
$F3$P$FSI just can't pretend to be anything I'm not.
I've never been any good at that.$K
$F0$P$FSPlease stay that way, Ike.$w4
Don't change for anyone.$K
$F3$PI'll see you again, $w2won't I?$K
$F0$PYes, $w2I'm sure of it.$K $=1500$R�w�i��b|$B��̒�|$<$F3$FCL_IKE3|$F1$FCL_ENA2|$F3$PHow odd, Ena. We've been both enemies
and allies.$K
$F1$PThanks to you, Rajaion was saved.
And...$w3so was I...$w4 $FSThank you.$K
$F3$PSo, you were with King Daein because
you were trying to save Rajaion?$K
$F1$P$FAYes.$K
Rajaion is the most important$w2
thing in my...life...$K$PSome nineteen years ago,$w3 he said he
wanted to broaden his knowledge and left
Goldoa. $Fc$w4He...never...returned...$K$PWhen I $w2finally found him, it was$w4
too late.$K$PHe had been so twisted$w4 that he was
no longer able to recognize me.$K$Fh$PAnd yet...$w2I wanted to be near him...$w4
With Nasir's help, $w2I, too, came to Daein...$w5$Fc
...$w4Oh, Grandfather...$K
$F3$PMaybe it's because I never saw his body,
but...it doesn't feel like Nasir's really dead.$w4
It's like he's out there somewhere.$K
$F1$P$FdHave you forgiven him?$K
$F3$PHe does not need my forgiveness.
Except for that one moment when I
learned of his deception...$K$PI never thought of him as an enemy.$K
$F1$P$FSThat's good.$K
$F3$PAre you returning to Goldoa, $w2Ena?$K
$F1$PYes.$K
I must help Rajaion return to his hometown.$K
$F3$PTake care. Give my regards to Kurthnaga.$K
$F1$PThank you. I will.$K$F1$FD  $R�̂݉�b|The war is over.$w6$PThe Crimean people,$w5 who suffered gravely
during the harsh Daein occupation,$w3
have at last regained their freedom.$w6$PThese same Crimeans have a saying:$w4
"No matter how harsh the winter,
spring will ever follow."$w6$PThis popular proverb proves true$w4 as the
warm winds of change begin to blow
across the countryside.$w6$PThe war has left the country in ruins,$w3 but
the people rise from the ashes$w5 and take the
first steps towards rebuilding their nation.$w6$PThough once scorned and despised as$w3 sub-
humans, the laguz put aside past enmity$w3
and come to the aid of their neighbors.$w6$w2    $R�̂݉�b|And the Crimeans$w3 never forget it was Gallia$w4
that fought beside them$w3 and helped free
them from the yoke$w3 of Daein oppression.$w6$PLed by the examples of Elincia and her
retainers,$w3 Crimea begins transforming$w3
into the land its king had dreamed of.$w6$PA land where beorc and laguz live together$w4
in harmony and equality.$w6$PAs the reconstruction efforts progress,$w4 the
administrative government announces the
enthronement of Elincia$w3 as the new queen.$w6$PAnd now,$w3 the day of her crowning arrives.$w6$w2$Ub$H $=1000$R�w�i��b|$B���-����|$<$F3$FCL_IKE3|$F1$Fc$F1$FCL_MIST|$F1$PHah...$w4I'm so tired I could fall over!
$FdPeace is all well and good, but it sure
is busy.$w6
$F3$PWe're rebuilding a country that was
completely devastated by war.
It's bound to be tough.$w6
$F1$PYou're right. I bet Princess Elincia and the
people in the palace are twice as busy.$w6
$F3$PSpeaking of Elincia,$w3 what's she doing?$w6
$F1$PShe's in that room over there, surrounded
by court officials. They seem really busy.
I feel so sorry for her.$w6
$F3$PAs long as she's getting at least a little
bit of rest, I'm not worried.
But she probably isn't...$w6
$F1$P$FSMaybe if I sang her a lullaby... $w5$FAAh!$w4
Oh, no! $w5I forgot!$w6
$F3$PYou forgot what?$w6
$F1$PI gave the medallion to Reyson,$w3
but I forgot all about the galdr!$w4
Ike, what should we do?!$w6
$F3$PHey, yeah...$w4 We never did find out who
Altina is, did we? She was the only one
who could sing the galdr...$w6$PWell,$w3 when things calm down, we'll
have to head out and search for her.$w6
$F7$FCDUMMY|$F7$PIs that Altina you speak of? One of the
three who defeated the dark god?$w6
$F1$FD$F1$FS$F1$FCL_CEPHERAN2|$F4$FCL_MIST|$F4$PHey!$w6
$F3$PSephiran! So you made it, did you?$w6
$F1$PI arrived mere moments ago. Let me
congratulate you on a successful
end to your journey.$w6
$F3$PThank you. Please tell me,$w3 do you
know who Altina is?$w6
$F1$POf course. Altina founded my homeland
of Begnion.$w6
$F3$POh, then it was a mistake...$w4
We can't give a song$w3 to someone
who died so long ago...$w6
$F1$PThere is one who yet shares both
bloodline and name--the true heir of Altina.$w6
$F3$PWho is it?$w6
$F1$PSanaki $w2Kirsch$w3 Altina...$w5
None other$w3 than the apostle herself.$w6
$F3$PThe apostle? Is this something everyone$w3
in Begnion would be aware of?$w6
$F1$P$FANo, there are very few who know that
name. Why do you ask?$w6
$F3$PThe apostle is Altina...$w6
$F4$P$FSOh, I'm so relieved! And exhausted, too!$w4
Ike, I'm going back to my room. See you
later,$w3 Sephiran.$w6$F4$FD
$F1$PThat was rather sudden.$w4
Did I say something to cause her distress?$w6
$F3$P...No,$w3 nothing like that. $w5It's just that
so much has happened between Begnion
and Serenes...$w6
$F1$P$FSWould you tell me about it? I would hear
what you have to say on this matter.$w6
$F3$PSure.$w3 To tell the truth...$w6$=0500  $=1000$R�w�i��b|$B���-����|$<$F3$FCL_IKE3|$F1$FCL_CEPHERAN2|$F1$PI see... $w5The assassination of the apostle,$w4
the Serenes massacre,$w4 and the use of the
medallion to revive the dark god...$w6$PAll of it$w3 was part of Ashnard's grand
scheme.$w6
$F3$PThat's the conclusion$w4 we came to.$w6
$F1$P$FS...You have me at a loss.$w6
$F3$PWhy is that?$w6
$F1$PFor many years, I have walked these lands.
Watching... Listening... And never did I
uncover what you have found.$w6$PNow that you have presented me with this
information,$w4 I don't know what to say.$w6
$F3$PI merely fulfilled the hopes of my
father and mother.$w6
$F1$PNow you speak from hindsight.$w6$PRescuing Princess Crimea,$w4 winning$w3
the apostle's trust,$w4 and defeating
King Daein...$w6$PWith laguz at your side, no less!$w6$PYou have accomplished all of these
miraculous things.$w6
$F3$PI had trusted and valiant companions
at my side. It was only through their
support that I was able to do these things.$w6
$F1$PEver the humble one, eh?$w6$PNow then, before I return home,
may I hear the galdr of release? I must
convey it to the apostle.$w6
$F3$PYou would do that?$w6
$F1$PNone of you can leave Crimea. The new
queen will need your strength.$w6
$F3$P...I suppose that will be the case for a
little while, won't it?$w6
$F1$P$FA...A little while?$w6
You are the hero of Crimea, General Ike.
If you wish it,$w3 no post will be
beyond your reach.$w6
$F3$PI don't care about any of that.$w6$PIt's more trouble than it's worth.$w3 And I
don't see the value of being some
fancy lord.$w6$PWhen the country's safe,$w3 I'm giving up that
title and everything and going back to
being a simple mercenary.$w6
$F1$P$FSHa ha... $w5T-$w3truly...$w5you are a...
Wha ha ha ha ha!$w6
$F3$PIs something strange?$w6
$F1$PYes. $w5It's very...$w5
$FcHaaaa ha ha haaaaa!$w6
$F3$PUm, I think that's enough.$w6
$F1$P$FdI'm...$w3I'm s-s-sorry.$w5
$Fc...Hee! Hee... Ahem...$w6
$F3$PUnbelievable. Despite all appearances,
you're really quite rude.$w6
$F1$P$Fd$FA$F4$FS$F4$FCL_TIAMAT|$F4$PCommander? May I have a minute?$w6
$F3$PSure. $w5What is it, Titania?$w6
$F4$PPrincess Elincia...$w3$FA Oops!$w3
$FSIt's Queen Elincia, isn't it?$w6$PThe court ministers want Queen Elincia
and you to come out onto the
balcony and greet the people.$w5
$F3$PWhat? Greet the people?
...Me?$w6
$F4$PYes,$w3 you. $w5I've done what I was asked
to do! $w5Now hurry up and get going!$w6$F4$FD$P$F3$PH-$w2hey! $w5Titania! Ah, nuts!
Why do I...$w3 What's going on?$w6
$F1$P$FSThe people of Crimea wish to see their
hero and to sing his praises--even if the
hero himself protests.$w6
$F3$PIf they want a greeting, surely their new
queen, Elincia, would suffice.
I'll go speak to her.$w6$F3$FD
$Ub$H$w6$F1$P$FA$Fc...Thus$w4 do heroes give birth$w3
to new chapters in history...$w3$Fd
Ike,$w4 I doubt if you've even noticed...$w6$PYour story,$w4 the everyday mercenary who
becomes a hero$w3 will awaken ugly appetite
and ambition in many.$w6$PIt will be the cause of strife and discord
throughout the land.$w4 I'm certain Ashnard
saw the truth in this.$w6$PIn a way,$w3 Ashnard's dream may have been
fulfilled. $w5The seeds of war have indeed$w3
been sewn across the continent.$w6$PIt appears your trials are just beginning,
my gallant, young hero...
May the goddess ride with you.$w7
$=1500       $F0$FD$N$UB$H   $F1$FD$N$UB$H   $F2$FD$N$UB$H   $F3$FD$N$UB$H   $F4$FD$N$UB$H   $R�㉺��b|$s0$FS$c0ASHNARD|$s0Heh heh heh heh.$w4 You've done well
to have grown so strong.$K$PAt last,$w3 I have gained a foe worthy
enough to test my sword.$K$PExcellent!$w4 Enjoy my might
to your heart's content!$K  $R�w�i��b|$B�V���l�p-��|$<$F0$FCL_IKE2|$F3$FCL_NASIR|$F4$FCL_ENA|$F0$PI've brought her, Nasir.$K
$F1$FCL_MIST|$F1$P...$K
$F3$P...$w5$FcI'm sorry, $w2Mist.$K
$F1$P...$K
$F3$P$FdI knew how much the medallion meant
to you, $w5and I stole it nevertheless.$K$PNo matter the words I use to apologize,$w4
I did something unforgivable.$K$PI gained your trust--and Ike's--$w2and betrayed it.
Then I compounded my dishonor by fleeing.$w4
...I am so very sorry...$Fc$K
$F1$P...$w3$K$FS
Thanks for coming back, $w2Nasir.$w4
I... $w2I wanted to see you again.$w3
And $w2I'm glad I did. $w2Welcome back.$K
$F3$P$Fd...$w2Ah, Mist. I do not deserve your kindness...$K
$F4$P...Mist, $w2please allow me to apologize as well.$w4
I am the one who is truly at fault here.$w4
What Nasir did, $w2he did for me.$K
$F1$PI'm sure$w3 there's some very important
reason for all of this. And it's probably still
unresolved.$K$PI'm honestly quite curious.$w4 Plus, I want
to help! But...$w4 But I doubt that I can.$K$PSo, $w2I'm going to wait.$K
I've decided to wait until the two of you can
tell me about whatever it is. So...$w5you don't
need to worry about it anymore. All right?$K
$F3$P$FS...Thank you, $w2Mist.$K
$F4$P$FcThank you.$K
$F0$P$FS...$K   $R�w�i��b|$B�V��-��|$<$F0$FCL_JANAFF|$F2$FCL_VULCI|$F0$PHar!$w4 So tomorrow's the day
we take on the capital. I'm ready!
Whooooo!$K$P$FSIt doesn't matter how hard the fight you're
facing might be,$w3 I always feel excited$w3
the night before!$K
$F2$PI'd like to tell you how wrong that is,$w2
but I can't. I...$w3can't seem to calm
my nerves, either.$K
$F0$PWe're going to win, you know?$w3
King Daein won't survive the day.$K
$F2$PMmm...I wonder.$K
$F4$FCL_IKE2|$F4$PAre you two on guard duty?$K
$F0$POh, $w2it's you. Heya, Ike.$K
$F2$FD$F1$FCL_VULCI|$F1$PDo you have some need of the king?$K
$F4$PYeah,$w4 will you tell him I'm here?$K
$F1$PWe will.$w3 Wait here.$K
$F0$FD$F1$FD$F4$P...$K$w6
$F1$FS$F1$FCL_TIBARN|$F0$FCL_RIEUSION|$F1$PSo, tomorrow it is. Did you come by to
check on our preparations?$K
$F4$PYou know me too well.$K$w4
You're going to circle the capital and ensure
that no airborne enemies escape. That's
clear, isn't it?$K
$F1$PYes. I think encircling the capital's a good idea.$K$PWe'll guard the west and take care of airborne
combat as well. The Phoenicis and Kilvas
armies are unbeatable in that regard.$K
$F4$PKilvas $w2is going to help out?$K
$F0$POf course.$K
$F1$PAfter what we saw in the dungeons of
Gritnea Tower,$w3 we all agreed that
King Ashnard must pay.$K$PReyson and Leanne helped to sway certain
opinions.$w4 It was tough, but in the end,
we understood what needs to happen.$K$PThat having been said,$w4 the crows are
traitorous by nature.$w4 If worse comes to
worst,$w2 it may be just us hawks out there.$K
$F4$PThat will be enough.$w4 At least I know I
can rely on you.$K
$F1$PWell, $w2to be perfectly honest...$w4
I wouldn't mind a chance to remove
Ashnard's head from his shoulders.$K
$F4$PIt's just like the time I fought the Black Knight...$w3
You're being kept away from the main fight.
My apologies, hawk king.$K
$F1$PThat's all right.$w4 But if you find yourself
overwhelmed, give me a call.$K
$F4$PUnderstood.$K
$F1$P$FAAnd as for you, Reyson.$w4 I'm sure
you're tired of hearing this, but--$K
$F0$P$FSI know, I know. Be careful. Don't die.$K
Don't worry, I won't die.$w4 I'm not going to
leave Leanne and my father all alone.$K
$=0700  $R�w�i��b|$B�V��-��|$<$F3$FCL_NAESALA|$F4$FCL_NEALUCHI|$F4$PNestling.$w4 It appears$w3 they're
discussing tomorrow's battle.$w4
Shouldn't you join them?$K
$F3$P...No, I think not.$K$PIt's just Tibarn after all.$w4 He doesn't$w3
really want help from Kilvas anyway.$K
$F4$PThe hawk king may not care, but...$K$PPrince Reyson$w3 would surely feel that
you had betrayed him yet again, Nestling.$K
$F3$PWhat?$K
$F4$POh, and dear lady Leanne as well.$w4
If you $w2were to flee in the face of the
enemy,$w3 it would break her heart.$K$PHah......$w4 It would be so sad...$w4
HAAAH...$w3 Heeee!$K$F4$FD
$F3$PSenile old crow. You think if you bring
those two into it,$w2 I'll do as I've been
told and fight...$w5 Curse you!$K   $R�w�i��b|$B�V��-��|$<$F0$FCL_IKE2|$F3$FS$F3$FCL_LAY|$F3$PThis war$w3 has been waged for over a year...$w2
But it could all be over by midday tomorrow.$w4
How do you feel, Ike?$w4 Think we'll win?$K
$F0$PWe'll win.$K
$F3$PI knew you'd say that!$w4 Ha!$w5
You don't fool me anymore.$K$PBut even so...$w2I appreciate your
bravado tonight.$K
$F4$FCL_GIFFCA|$F4$PWithout such courage,$w3 it would be
impossible to face King Daein.$K
$F3$FD$F1$FCL_LAY|$F1$PMaster Giffca!$w4 What are you doing here?$K
$F4$PThe king felt uneasy knowing you were
here on your own.$w4 I come in his name.$K
$F1$PSo,$w3 are you going to fight with us?$K
$F4$PThat is my purpose.$w4 That is, $w2if
Lord Ike grants his permission.$K
$F0$POf course.$K$PThe Daein army is large,$w3 so we're going
to be attacking them from the front$w3
and holding the two eastern gates.$K
I'd be very appreciative$w3 if you would agree
to take command of that front.$K
$F4$PIf that is your wish, I can but agree.$K
$F1$PWhat's this now?$w4 You weren't satisfied
with the work I was doing?$K$PI mean,$w3 I know that I'm no Master Giffca,
but please...$K
$F0$PRanulf,$w3 I want you to be with me.$w4
Is that all right?$K
$F1$P$FSOh, now I see.$w4 Sure, that would be fine!$w4
Getting to be part of the main pack$w2
is the highest of honors.$K
$=0300 $R�w�i��b|$B�V��-��|$<$F0$FCL_GIFFCA|$F3$FS$F3$FCL_MORDY|$F3$PMaster Giffca!$K
$F4$FCL_LETHE|$F4$PIt's been a long time.$w4 How is
the king?$K
$F0$PHe's in good health. $w5The king...$w3
has given me a message for you two.$K
$F4$PA $w2message?$w4 Not orders?$K
$F0$PThat's right.$w4 He said $w2to be sure
you make it home alive.$K$PAnd then he said that your work in the past
year$w4 has been most satisfactory$w2 and
that he's sincerely grateful to you both.$K
$F4$P...That's...$w3$FSsuch an honor!$K$P$F3$PWe $w2have fought hard.$w4
But...$w2it wasn't a bother.$K$PIke and the others are good beorc...$w4
We are happy$w3 to fight with them.$K
$F0$P$FSI see.$K  $R�w�i��b|$B�V��-��|$<$F1$FCL_SENERIO|$F3$FCL_IKE|$F1$PIke,$w3 I'd like to report the results
of our last battle.$K$N$UB$H $F3$P$FcI see.$K$P$UB$H $F1$P$FSThere were no deaths $w2and no injuries
beyond our capabilities to heal.$w4
Everyone performed exceedingly well.$K$P$UB$H   $F1$PThat is all.$w4 By your leave,$w2
I will excuse myself.$K    y|      S   	  T�     V�   !  Z�   -  ^�   ;  z�   G  sH   S  |(   `  t�   l  `t   y  b�   �  ~�   �  w\   �  N   �  L�   �  NX   �  N�   �  j0   �  k,   �  k�   �  o<     p�    y�    ��  $  Hx  0  P�  >  R�  L  G�  Z  JP  h  Cp  x  Ch  �  Cx  �  C`  �  ��  �  ��  �  ��  �  �`  �  ��  �  ��  �  �    �8    �h    ��  *  �D  8  �   D  �T  P  �8  \  ��  j  ��  w  �,  �  �$  �  �4  �  �D  �  �T  �  �d  �  �   �  �X    ��    ?�  %  �t  1  @  ?  AL  N  Bl  ]  :�  m  Fd    <�  �  E�  �  ?   �  D�  �  >�  �  B�  �  ;�  �  G     =@    C�  3  =�  C  �D  U  �(  e  �|  u  ��  �  �   �  ��  �  �p  �  ��  �  �  �  �@  �  ��    �t    �  %  ��  7  �  I  ��  [  ��  m  ��    �x  �  �  �  ��  �  �  �  ՘  �  ��  �  �@  �  �L    ��  #  �t  5  �t  I  ��  ]  �  k  ߌ  {  �@  �  �  �  ��  �  �D  �  �@  �  ʴ  �  �h  �  �0  	  �`    �8  )  �8  ;  ��  M  ��  _  ��  q  ��  �  ��  �  ��  �  �<  �  �,  �  Ѵ  �  ��  �  �  �        �    P  '  P  4   B �  P t  ` �  n  �  ~  �  �  	8  �  ,  �     �    �  �  �  �  �  t  �  �  �   �  	  #,  	  #0  	$  #�  	5  #�  	C  '  	Q  #�  	_  #�  	m  (8  	|  1�  	�  1�  	�  4�  	�  4�  	�  7�  	�  8@  	�  9�  	� $  	� �  	� <  
  �  
  �P  
   �  
4  �  
HMS_31_BT MS_31_BT_01 MS_31_BT_02 MS_31_BT_03 MS_31_BT_03_2 MS_31_BT_04 MS_31_BT_05 MS_31_BT_05N MS_31_BT_06 MS_31_BT_06N MS_31_BT_07 MS_31_BT_08 MS_31_BT_09 MS_31_BT_09N MS_31_BT_G MS_31_BT_G01 MS_31_BT_G02 MS_31_BT_G03 MS_31_BT_R1 MS_31_BT_R2 MS_31_BT_R3 MS_31_BT_R4 MS_31_BT_R5 MS_31_DIE_1 MS_31_DIE_2 MS_31_DIE_ENA MS_31_DIE_G01 MS_31_DIE_G02 MS_31_DIE_LAY MS_31_DIE_NASIR MS_31_DLG_GIFFCA MS_31_DLG_NAESALA MS_31_DLG_NO MS_31_DLG_TIBARN MS_31_ED_00 MS_31_ED_00N MS_31_ED_03 MS_31_ED_04 MS_31_ED_04_2 MS_31_ED_05 MS_31_ED_05_N MS_31_ED_06 MS_31_ED_08 MS_31_ED_08_N MS_31_ED_09 MS_31_ED_10 MS_31_ED_12 MS_31_ED_12_N MS_31_ED_13A MS_31_ED_18 MS_31_ED_19 MS_31_ED_FACE_DEL_1 MS_31_ED_FACE_DEL_2 MS_31_ED_FACE_DEL_3 MS_31_ED_FACE_DEL_4 MS_31_ED_FACE_DEL_5 MS_31_ED_WINDOW_DEL MS_31_ED_XX_01 MS_31_ED_XX_02 MS_31_EV_01 MS_31_EV_01_N MS_31_EV_02_01 MS_31_EV_02_02 MS_31_EV_ENA_01 MS_31_EV_ENA_01_N MS_31_EV_ENA_02 MS_31_EV_ENA_02_N MS_31_EV_GIFFCA MS_31_EV_GIFFCA_N MS_31_EV_NAESALA MS_31_EV_NAESALA_N MS_31_EV_NASIR_01 MS_31_EV_NASIR_01_N MS_31_EV_NASIR_02 MS_31_EV_NASIR_02_N MS_31_EV_TIBARN MS_31_EV_TIBARN_N MS_31_GED_Beg_a MS_31_GED_Beg_b MS_31_GED_Beg_dal MS_31_GED_Beg_mak MS_31_GED_Beg_mar MS_31_GED_Beg_mwa MS_31_GED_Beg_soa MS_31_GED_Beg_ste MS_31_GED_Beg_top MS_31_GED_Cri_Del MS_31_GED_Cri_a MS_31_GED_Cri_b MS_31_GED_Cri_cal MS_31_GED_Cri_cha MS_31_GED_Cri_geo MS_31_GED_Cri_kev MS_31_GED_Cri_lar MS_31_GED_Cri_luc MS_31_GED_Cri_nep MS_31_GED_Cri_pair MS_31_GED_Cri_uly MS_31_GED_Day_Open MS_31_GED_Day_ela MS_31_GED_Day_haa MS_31_GED_Day_jil MS_31_GED_Day_sot MS_31_GED_Day_tau MS_31_GED_Day_zih_a MS_31_GED_Day_zih_b MS_31_GED_Del MS_31_GED_GOL_a MS_31_GED_GOL_b MS_31_GED_Gal_2_a MS_31_GED_Gal_2_b MS_31_GED_Gal_a MS_31_GED_Gal_b MS_31_GED_Gal_mor MS_31_GED_Gal_ret_a MS_31_GED_Gal_ret_b MS_31_GED_Mer MS_31_GED_Mer_bol MS_31_GED_Mer_chi MS_31_GED_Mer_gat MS_31_GED_Mer_kil MS_31_GED_Mer_lof MS_31_GED_Mer_mis MS_31_GED_Mer_osc_a MS_31_GED_Mer_sen_a MS_31_GED_Mer_tia_a MS_31_GED_Pho MS_31_GED_Pho_jan MS_31_GED_Pho_vul MS_31_GED_vol MS_31_GED_way MS_31_GMAP_1 MS_31_GMAP_2 MS_31_GMAP_3 MS_31_INFO_03 MS_31_INFO_04 MS_31_INFO_04_2 MS_31_INFO_05 MS_31_INFO_05_2 MS_31_OP_01_A MS_31_OP_01_B MS_31_OP_01_C MS_31_OP_01_D MS_31_OP_01_E MS_31_OP_01_F MS_31_OP_01_G MS_31_OP_01_H MS_31_OP_02 MS_31_OP_03_A MS_31_OP_04 MS_31_OP_04_DEL MS_31_OP_04_DISP MS_31_OP_04_N MS_31_OP_04_Y MS_31_OP_05_N MS_31_OP_05_Y MS_31_OP_05_Y2 MS_31_OP_06 MS_31_OP_07 MS_31_OP_08 MS_31_OP_09 MS_31_OP_10 MS_31_OP_11 MS_31_OP_12_A MS_31_OP_12_B MS_31_REPO_BEGIN MS_31_REPO_DIE MS_31_REPO_END MS_31_REPO_NODIE MS_32_GED_Mer_osc_b MS_32_GED_Mer_sen_b MS_32_GED_Mer_tia_b 