  �v  �       3                $R�w�i��b|$B�D��|$<$F3$FCL_IKE|$F1$FCL_NASIR|$F1$PIke, there's someone here claiming to be an
envoy from the theocracy of Begnion.$K$PShe's been asking if the princess of Crimea
is aboard$MC...$MD$w4 What do you want to do?$K
$F3$PA Begnion envoy?$w4
How did she know about this ship?$K
$F1$PHmmm$MC...$MD$w2
Perhaps she had word from King Gallia$MC...$MD$K$POn the other hand,$w2 this is Begnion
we're speaking of.$w3 I imagine it has
spies in every corner of the continent.$K$PPerhaps one of those spies is
the source of her information.$K
$F3$PSo we shouldn't be surprised that she
knows about Princess Elincia, right?$K
$F0$FCL_SENERIO|$F0$PNo, but$w3 it's extremely unusual for Begnion
to send an envoy to meet a princess
whom they do not even acknowledge.$K
$F3$PWhat do you mean?$K
$F0$PIt is a complicated matter.$K$PYou see,$w2 the envoy is essentially an
extension of the empress herself.$K$PBoth Crimea and Daein were once part
of Begnion. $w2Both nations have only
recently splintered from the theocracy.$K$PI can't fathom why the empress would
extend the courtesy of an envoy to a nation
she must consider somewhat beneath her.$K
She must be planning something.$K
$F1$P"Beneath her"?$w2 That is somewhat
harsh, don't you think?$K
$F0$P$FcHarsh, perhaps, but it's true.$w4
Clothing it in sweet words will
not hide its bitterness, will it?$K
$F3$PSoren, even I would question the
tactfulness of your words.$K
$F0$P$FdI will$w2 try to be more diplomatic.$K
$F4$FCL_ERINCIA|$F4$PIke, $w2Nasir.$w4 You've no need to
scold Soren.$w4 His words are just
that. They do me no harm.$K
$F1$PI'm glad to hear that, Princess,
but he should mind his manners.$K
$F0$P$MC...$MD$K
$F3$PDeciding how we ought to treat with this
envoy is a more pressing issue.$w4 Princess,
will you meet her and hear her message?$K
$F4$PI believe I must.$w4 We gain nothing
by refusing to see her.$K$PLet us meet with the envoy.$K
$=0800 $R�w�i��b|$B�D-��|$<$F4$FCL_IKE|$F3$FCL_ERINCIA|$F1$FCL_TANIS|$F1$PPrincess Elincia of Crimea,
I presume$MC...$MD$K
$F3$PYes.$K
$F1$PIt is an honor to meet you.$w4 My name
is Tanith. I am deputy commanding officer
of Begnion's holy guard.$K
$F3$PI must ask,$w4 what would Begnion
want of me that she would send
her holy guard to greet me?$K
$F1$PThe apostle has learned of you, Princess
Elincia, $w2and she has come here to meet
with you personally.$K$PThe duty falls upon me to take you
to her now.$K
$F3$PThe apostle?$w4
Am I to meet$MC--$MD$w4 Surely the apostle
has better things to do than$MC...$MD$K
$F1$PWill you accompany me?$K
$F3$PI suppose that I$w4$MC...$MD$K
$F4$PWe are the princess's escorts, and
we will be coming with her.$w2 I hope
you understand.$K
$F1$P$FSOf course.$K
$F3$PThen yes, I will go with you.$w4
Thank you.$K$P$F3$FD$F4$FD$F1$FA
$F0$FCL_PEGASUSKNIGHT|$F0$P$Ub$HBad news, $w2ma'am.$w4
We've sighted laguz near the apostle's
position. Birdmen. Crows, most likely.$K
$F1$PHmph!$w2 We've seen their kind before.$w4
They fancy themselves pirates without
a ship,$w3 but they're thieves plain and simple.$K$PCommander Sigrun is with the apostle,$w4
and it will take more than a few winged
scavengers to get past her.$K$PLet's remain calm.$K
$F0$PI$w2$MC... $MDActually, I'm afraid we aren't$w4
quite sure where the apostle is.$K$P$F1$FD$F3$FCL_TANIS|$F3$PWhat!? They've kidnapped the apostle!?$K
$F0$PNo, no!$w2 I$MC...$MD$w4 From what the commander
said,$w2 the apostle grew$w4 impatient and
had another of her more$MC...$MD$w4willful moments.$K$PI asked at the docks,$w4 and sure enough,
one of the longshoremen heard her$w5
order the ship to set sail without us.$K
$F3$PWhat!?$w4 Where were her attendants?
What was she doing without her guard?$w4
Why can she never just stay put?$K$PI've told her time and time again that
the seaports here are rampant with
pirates and crow thugs!$K$P$MC...$MD$w4Right. Where is she now?$K
$F0$PThe wind is poor today,$w2 so we think
her ship should not be too far from us.$w2
I came here as quickly as I could.$K
$F3$PUnderstood.$w4 We'll move immediately.$K$P$F0$FD
$F3$FD$F1$FCL_TANIS|$w6$F4$FCL_IKE|$F3$FCL_ERINCIA|$F3$PExcuse me,$w2 but is something wrong?$K
$F1$PYour Highness,$w4 I must apologize,
but an urgent matter has arisen, and
I must attend to it immediately.$K$PI will return for you later.$w5
Await my return!$K$P$F1$FD
$F4$PWhat was that all about?$K
$F1$FCL_TIAMAT|$F1$PJudging from her expression,$w4 I'd say
something has happened to the person
she's meant to be protecting.$K
$F0$FCL_MIST|$F0$PSay, do you think that ship over there
is involved?$w4 The envoy is flying
in that direction.$K
$F4$PIf so, then the pegasus knight's fears have
already been realized$MC...$MD$w4 They're under attack.$w4
It's the ravens they spoke of, isn't it?$K
$F0$FD$F0$FCL_SENERIO|$F0$PIke, $w2why don't we go lend them a hand?$K
$F4$PAre you feeling all right, $w2Soren?$w4
It's not like you to offer to help anyone.$K
$F0$PIt's a great opportunity to put the
empress in our debt.$w4 We'd be fools
to pass that up, wouldn't we?$K
$F4$PI should have known you'd have an
angle.$w4 What do you want to do, Titania?$K
$F1$P$FSI don't approve of Soren's motivations,$w2
but I agree that we should help.$K$F0$FD$F1$FD
$F4$PWell, then that's what we'll do.$w2
Will you be all right on your
own,$w4 Princess?$K
$F3$FD$F1$FCL_ERINCIAh|$F1$PYou're doing the right thing. I would
not dream of stopping you.$K$PI know those pirates are no match
for your strength.$K$PGive them$MC...$MD$w5 Give them a
sound thrashing!$K
$F4$PHuh$MC... $MD$w2You're starting to sound
like one of us, aren't you?$w3
All right then, $w2we'd better go!$K    $R�㉺��b|$c0TANIS|$s0Ugh! $w2No matter how many we defeat,
there are more waiting to attack!$K$PAnd not just those ravens of Kilvas,
either$MC--$MDthere are beorc, too.$w4
What do they all want here!?$K    $R�㉺��b|$c1IKE|$s1Need a little help?$w2$K   $R�㉺��b|$c0TANIS|$s0You!$w4
Aren't you $w2Princess Crimea's escort?$K
$c1IKE|$s1Yes. The princess ordered us to come
to your aid.$w4 May we join the fray?$K
$s0That would be $w2appreciated.$K
We'll keep the ravens at bay. $w2In
the interim,$w2 why don't you go ahead
and move onto that ship.$K$PThe big vessel is ours.$w4 I'm not sure
who the small one belongs to.$K$PThere are human soldiers aboard,$w3
but if they're in this part of the sea,$w2
they must be pirates. Cut them down!$K
$s1Right.$w4 We'll take care of them!$K    $R�㉺��b|$c1BEGNION2|$s1Where on earth is the holy guard?$w4
Between those crows and the
pirates, we're outnumbered!$K$PIt's only a matter of time before
we're overwhelmed.$K    $R�㉺��b|$c0STELLA|$s0I will fight, too.$K
$c1BEGNION2|$s1Y-you$MC...$MD$w3 You're one of the passengers
from House Damiell, aren't you?$K$PI can't permit someone of your
stature to throw herself into
harm's way!$K
$s0I was once a knight of Begnion,$w2
albeit for only a short while$MC...$MD$K$PI won't get in your way.$K
$s1No, I can't$MC--$MD$K
$s0We must defend the apostle, right?$w5
We do not have the luxury of
choosing how to do so.$K$PCome, we must get ready.$w4
The enemy$w2 is coming!$K
$s1You$w4 are right. We need every able
fighter. $w2Accept my apologies,$w4
and thank you for your help.$K   $R�㉺��b|$s0$FS$c0GATRIE|$s0Lady Astrid!$w4 Allow me to serve
as your shield!$K
$c1STELLA|$s1Gatrie$MC...$MD$w4 I'm so sorry that I've
gotten you involved in this, too$MC...$MD$K
$s0Oh, please!$w4 This is nothing.$w2 I'm fine!!$K
Before I was hired as your bodyguard,$w2
I was a top-notch mercenary!$K$PI can handle this many opponents
all by myself.$w2 This is nothing.$K
$s1$FSIs that so?$w4 Your confidence is
impressive, to say the least$MC...$MD$K
$s0Tee hee!$w4 Well$MC...$MD$w3trust me, my
confidence is backed with my blade!$w4
I'm ready to fight!$K $R�㉺��b|$c1BEGNION1|$s1Oh, no!$w4
There are more of them!?$w4
We're doomed!!$K$d1
$c0BEGNION2|$s0No, $w2don't panic!$w4
We must protect the apostle
no matter what!!$K$PListen up, pirate scum!$w4 You
may outnumber us,$w2 but we
will not yield an inch!$K
$c1IKE|$s1Wait, wait!$w2 Don't get confused.$w4
We're here to help you!$w3
We're your reinforcements.$K$PThe deputy commander of the holy
guard asked us to help drive
the enemy from this ship.$K
$s0$FSOh!$w4 Commander Tanith sent you?$w4
We're saved!$K$PThe apostle has taken refuge
in the cabin belowdecks.$K   $R�㉺��b|$c0BEGNION2|$s0Until the holy guard arrives,$w2 we
need you to defend the entrance
to the ship's cabins.$K$d0
$c1IKE|$s1Got it!$w4
Weapons ready,$w2 everyone!$K $R�㉺��b|$s0$FS$c0NAESALA|$s0Tell me, $w2walker, are my
soldiers proving useful?$K
$c1NOSITOHI|$s1K-$w2King Kilvas!$K
$s0What? $w2Aren't you happy to see me?$K
$s1Grrr$MC...$MD$w5 Look at this mess!$w4
I paid you good money$w3 to help me
outmaneuver everyone else$K$Pand catch the Crimean princess's
ship first. Everything seemed to be
going exactly as we'd planned.$K$PBut now, we're being attacked
by a squad of pegasus knights!$K$PWe're flying no flags! We've stripped
our armor of any crests! They should
have no clue who we are!$K$PWhy are they attacking us!?$K
$s0Didn't you know?$w4 That is a Begnion
ship you're attacking.$K
$s1What?!?$w4 That's$MC...$MD$w2a Begnion ship?$K$PIt was your featherbrained lackey$w2
who told us that Princess Crimea was
aboard that vessel!$K
$s0Call it a miscommunication$MC...$MD$w4 One of
those unfortunate misunderstandings
that seem to happen now and again.$K
$s1You deceitful$MC...$MD$w2 King Kilvas!$w4
I wouldn't be surprised if you'd
planned this treachery from the start!$K
$s0Such unkind words! $w2You wound me.$w4
I would never intentionally lie to you.$w4
And as proof, I bring good news.$K$PI have it on unshakable authority that
the ship that just sailed up alongside
Begnion's carries the Crimean princess.$K
$s1Oh$MC... $MD$w4But$w2 unless we can break through
the Begnion ranks, there's nothing
we can do$MC...$MD$K
$s0Would you care for some assistance?$K
$s1And $w2what would it cost
me this time?$K
$s0You learn quickly, my friend.$w4 Let's see,
you'd be receiving my own royal
assistance, so$MC...$MD$w4double$MC--$MDno, triple rates.$K
$s1Ludicrous!$w4
So much gold$MC... $MDWhere would I$MC...$MD$K
$s0I suppose I could defer payment until
later.$w4 Of course, $w2that does bring up
the question of interest$MC...$MD$K
$s1Leave my sight!$w4
I wouldn't seek your aid if the world
were burning down around me!$K
$s0Very well, $w2we've no more to discuss.$w4
Call me if you change your mind.$w4 I'll
find a nice perch and enjoy the show.$K$d0
$s1Curse you!$w4 You're no better than
your feral cousins!$K $R�㉺��b|$s1$FS$c1NAESALA|$s1Those humans take themselves far too
seriously.$w2 It's almost as though being
obstinate is a way of life to them.$K$PThey let their foolish pride stand in
the way, and what do they get in
the end? A swift and stupid death.$K$P$FANow I'm getting terribly bored merely
watching their foolishness.$K
$c0NEALUCHI|$s0Ne-$w2Ne-$w2Nestling!$w4
I can sense you're up
to no good again!$K
$s1$FcStop calling me "Nestling"$MC...$MD$w4
$FdReally, $w2how many times must I
tell you that,$w4 Nealuchi?$K
$s0To me, you will always be Nestling,$w2
Nestling.$w4 You can tell me as many
times as you like, but I can't stop.$K$PYou may be king now,$w2 but in my eyes,
you will ever be my little nestling with
eggshell stuck to your tail feathers!$K
$s1Oh$MC...$MD$w3curses!$w5
Senile old fool.$K$PForget it.$K  $R�㉺��b|$s0$FA$c0NAESALA|$s0Hey, $w2you there!$K
$c1CROW|Yes, sir!$K
$s0We should take advantage of the
confusion of battle to help ourselves
to the cargo.$K$PThese humans seem interested only
in fighting their fellow men.$K$PIf they can't be bothered to defend
their treasure, I think it fair to say
they've lost their claim to it.$K
$s1Right you are, sir!$K$d1
$s0$FSHmph.$w4 Fight. Fight till you drop,$w4
ground-bound humans.$K$PWe Kilvas will be sharpening our
black beaks in the mean.$K $R�㉺��b|$c0TIBARN|$s0Hm. A battle$MC...$MD$w4
Tell me what you see, $w2Janaff.$K
$d0$s0$FS$c0JANAFF|$s0It's a bit far off, but with no fog,
it shouldn't be a problem.$K$w5$FA$Fh$PHmm$MC...$MD$w3 The middle ship$MC... $MDI see beorc
aboard. By their crests, I'd say they
serve the hated Begnion empire.$K$PAnd the other ships$MC...$MD$w4
I'm not sure who they belong to.$K$PNeither flies any flag$MC...$MD$w2and I see no
crest, but I can make out more beorc.$K$Fd$PFrom their behavior$MC...$MD$w2I would say that
one side fights Begnion, while the
other rushes to Begnion's aid.$K
$d0$c0TIBARN|$s0A battle between beorc ships?$w4
I do not understand this at all.$K$PUlki,$w3 tell me what they are saying.$K
$c1VULCI|$s1Just a minute, sir$MC...$MD$K$Fc$P$MC...$w4$MDThe apostle is$MC...
$w3$MDaboard the Begnion ship.$K$PAnd coming to her aid$MC...$MD$w3
Soldiers serving Crimea's princess?$w4
They appear to be mercenaries.$K$PAnd on that last ship$MC...$MD$w3$Fd More
soldiers, although I do not know
which country they serve.$K$PIt seems they had a contract of
some sort with the raven king.$K
$s0The apostle!?$K$PThat would explain the presence of
those graceless pegasus knights.$K
$s1What would you like to do, $w2Your
Majesty? We will fight if you
give the word.$K
$s0The apostle$MC... $MDThis is a tempting
opportunity.$K$PHowever, we are no scavengers,
feeding on others' scraps. When we
fight, it will be with honor.$K$PWe're going back home.$w4
Do some scouting $w2and report
back to me with what you find.$K
$s1Yes, sir!$K $R�㉺��b|$c0SIGRUN|$s0Finally! There they are!$w4
I hope we'll find Empress Sanaki$MC...$MD
safe and sound$MC...$MD$K$PLadies, $w2chaaaarge!$w4
Show them what we've got!!$K  $R�㉺��b|$c0IKE|$s0Are you all right?$K
$c1STELLA|$s1Who are you?$K
$s0My name's Ike.$w2 I'm with the Greil
Mercenaries. I came to defend this
ship$w3$MC--$MDand the apostle, if I can.$K
$s1$FSIs that so?$K
I am Astrid, of House Damiell.$K
$s0A blueblood, huh?$w5 Well, unless
you're good with a sword,$w2 you'd
better hide yourself in a cabin.$K
$s1$FAI'll do no such thing.$w5 I once trained
with knights and cavaliers. I may
be of noble birth$MC...$MD$K$Pbut I know something of battle.$w2
I can fight.$K
$s0Well, if you can fight, we can
use you. Let's work together.$w5
You going to be all right with that?$K
$s1$FSMore so than I would be with
hiding belowdecks, certainly.$K  $R�㉺��b|$c0STELLA|$s0$FSGatrie$MC...$MD$K
$c1GATRIE|$s1Lady Astrid!$w4
Are you all right?$K
$s0$FAWhat do you mean? I'm
fine. Why shouldn't I be?$K
$s1I saw you talking to that rough,
blue-haired lad earlier$MC..$MD$w4
What did he say to you?$K$PWas he rude? Did he try to tell
you to run for safety while he
fought for your honor?$K
$s0$MC...$MD$w2Words to that effect, yes.$K
$s1Oh, $w2what a fool!$w4
I tell you, he'll never learn!$K$PYou already have an unbeatable
bodyguard$w4$MC--$MDme! I'll have to
remind him of that later.$K
$s0You know that Ike person?$K
$s1He is the son of a man under whom
I had the honor of serving.$w4 He's
not a bad person, by any means.$K$PBut he has no manners whatsoever$MC...$MD$K
$s0$FSI see.$w4 Well, he seemed more
concerned than rude.$K$PWhen I told him I would prefer to
fight, he seemed to understand.$K
$s1Hm$MC...$MD$K
Oh.$w2 Oh, of course!$w4$FS
I see it now!$w4 How silly of me.$w4
Not rude, you say?$K$PI should have known my presence
would have changed the boy for the
better! I'm the ideal role model!$K $R�㉺��b|$c1IKE|$s1Gatrie!$K
$s0$FS$c0GATRIE|$s0Well,$w4 if it isn't Ike!$w4 Good to see
you. You're looking well, my boy.$K
$s1Yeah.$K
$s0Well, I'm glad to see it.$K$PI've been worried sick about how
the Greil Mercenaries held up after
I left. Did you ever recover?$K
$s1We managed just fine.$w4
Uh$MC...$MD$w2 What are you doing
here, anyway?$K
$s0Me?$w4 Oh, I'm on a vital mission.
Absolutely critical, I am.$K
You see, these men keep
attacking this ship,$w4 and I am
to continue driving them back!$K
$s1I see$MC...$MD$w2 Are you working for
the Begnion apostle?$K
$s0No, no.$w4 My employer is
far more charming!$K
$s1Is that so$MC...$MD$w3
From the sound of it,$w2
it must be a young lady.$K
$s0Aye,$w3 after a fashion.$w4
Judging by the look of things,
you must be on Begnion's side, yes?$K
I certainly hope so. I'd hate to
have to slay you after all we've
been through.$K
$s1No, you're right. We're here
to defend the apostle.$K
$s0Well, that's a relief.$K
There's nothing more awkward than
having to kill a friend because of his
poor taste in employers, I tell you.$K
Still, I guess that's the hazard of
life as a mercenary. It's good to see
you, Ike. Let's finish this together!$K
$s1$FSI'm with you, Gatrie.$K    $R�㉺��b|$c1IKE|$s1Hey, Gatrie!$w4 What's with that
sour look on your face?$K
$c0GATRIE|$s0You know, I think it must be fate.
Why else would we be here, fighting
side by side once again?$K$PIt makes me wish I hadn't abandoned
you so quickly after your father,
Commander Greil, died.$K
$s1It's not like you to say things
like that, Gatrie$MC...$MD$K
$s0You look like none of this matters
to you. Aren't you mad at me or
anything? I abandoned you all!$K
$s1No. I understand how you must
have felt when you left.$K$PAnd it's only because you left $w2that
you met this nice new employer.$w4
I see no problem.$K
$s0$FSYes,$w4 you do have a point.$w4
So I guess it all worked out!$K$PI can't believe I wasted all
this time worrying!$K
$s1$FSThe fact that you worried tells me
that you never really abandoned us
after all.$K
$s0Hm.$w4 You're right again!
I am truly glad to see you, Ike.$K    $R�㉺��b|$c1TIAMAT|$s1Gatrie?$w4 Is that you?$w4
Well, I'll be. It IS you!$K
$s0$FS$c0GATRIE|$s0Oh!$w4 Titania!$w4
It's been such a long time!$w4
How have you been?$K
$s1$FSBusy, of course.$w4 The mercenary
life is a busy one.$w5 Have you
been doing well since you left us?$K
$s0Yes!$w4 In fact,$w2 I'm on a very
serious mission right now!$K$FA$PI can't afford to lose.
A life hangs in the balance!$K
$s1My$MC...$MD$w4
I've never seen you so serious before.$K
Whoever your new employer is, he
must be quite special$MC...$MD$w2or$MC...$MDwould
I be safe in saying "she"?$K
$s0$FSTee hee!$w2 You know me too well!$w4 But
I do love the work she gives me. I'm
so happy, I don't know what to do!$K$PWell, $w2it is nice seeing you again!$K
$s1You, too. $w2Good luck, Gatrie!$K    $R�㉺��b|$c0GATRIE|$s0Hm?$w4 Hey, it's you!$K
$c1SENERIO|$s1$MC...$MD$w4
Hello, Gatrie.$K
$s0What's wrong?$K
Are you still holding a grudge
because I abandoned the Greil
Mercenaries so abruptly?$K
$s1No, $w2not really.$w4
I'm just waiting to find out which
side you're working for.$K$PIf you're on our side, fine$MC...$MD$w4
Please fight till you drop.$w2 It will
only improve our chances of winning.$K
$s0$FSI, uh$MC... $MD$w2Of course!$w4 You know, you
can always count on me!$K
$s1Hm.$w3 "Always."$w5 Of course.$K$d1
$s0$FA$FhPhew$MC...$MD
That boy hasn't changed a bit.$K   $R�㉺��b|$c1MIST|$s1Gatrie?$w4
That is you, isn't it?$K
$c0GATRIE|$s0Well, $w2if it isn't Mist!$w4
$FSLong time, no see!$w4
How have you been?$K
$s1$FSOh, you know! Hanging in there.$K
$s0$FALook at you! You're out here
on the battlefield now? How
do you like it?$K
$s1No worries$MC...$MD$w2 Not so far, anyway.$w4
How about you?$w4 Are you
doing well?$K
$s0$FSYes!$w4 In fact,$w2 I'm on a very
serious mission right now!$K$PI can't afford to lose.
A life hangs in the balance!$K
$s1I'm glad things are working out.$w3
I knew they would, but I was
worried$MC...$MD$w3 Just a little.$K
$s0Tee hee hee. $w2You never need
to worry about me, dear Mist.$w2
I've never been happier!$K
$s1I'm glad to hear that.$K
$s0Well,$w2 the battle awaits.
Stay sharp, and stay safe!$K
$s1The same goes for you, Gatrie!$K    $R�㉺��b|$c1OSCAR|$s1$MC...$MD$w4
Well if it isn't Gatrie!$K
$s0$FS$c0GATRIE|$s0Is$MC... $MD$w4Is that you, Oscar!?$w4
My word,$w4 Oscar!$w4
So,$w4 how is it going?$K
$s1$FSWell, $w2I'm hanging in there.$K
How about you?$w2 How have you been?$w4
Is everything going well with your job?$K
$s0Yes!$w4 In fact,$w2 I'm on a very
serious mission right now!$K$PI can't afford to lose.
A life hangs in the balance!$K
$s1I'm glad to hear that.$K
I knew you'd be fine, $w2but I
still worried about you.$K
$s0Oh, there's never any need to
worry about me.$w4 Why, I can't
recall ever having been happier.$K
$s1Is that right?$K
$s0But enough chitchat. There's
a battle to finish!$K
$s1You got that right.$K    $R�㉺��b|$c1BOLE|$s1It can't be$MC... $MD$w2Gatrie!?$K
$s0$FS$c0GATRIE|$s0Boyd?$w4 Why, Boyd!$w4
Long time, no see!$w4
How have you been?$K
$s1$FSSince you left?$w3 I've been fine,
thanks.$w2 We've all been just fine.$w2
Uh$MC...$MD$w3 What are you doing here?$K
$s0Working, of course!$w4 I'm on a
very serious mission right now.$K$PI can't afford to lose.
A life hangs in the balance!$K
$s1Hm.$w3 Well, I$w3 am glad to hear that.$w4
You do seem much happier now than
when you were when you left us.$K
$s0Ha ha ha.$w2 You always were an
observant one.$w3 Let me tell you,
I've never been happier.$K
$s1$Fh$FAIf I know you,$w4 this has something
to do with a woman, doesn't it?$K
$s0Huh?$w3 What was that?$K
$s1$Fd$FSOh, $w2nothing.$w4 I was just
talking to myself.$K
$s0But enough chitchat. There's
a battle to finish!$K
$s1You got that right.$K $R�㉺��b|$c1LOFA|$s1Gatrie?$w4
It IS you!$K
$c0GATRIE|$s0Hey! $w2Rolf?$w4 Rolf!$w4
$FSIt's been a long time!$w4
How have you been?$K
$s1Well$MC...$MD$w4$FS
Yes.$w3 I've been well!$K
$s0$FAThey have you fighting
for them, too, do they$MC...$MD$w4
Are you doing all right?$K
$s1Oh, yeah. I'm fine.$w2
I've been doing just fine.$w4
How about you, Gatrie?$K
$s0$FSGreat!$w4 In fact,$w2 I'm on a very
serious mission right now!$K$PI can't afford to lose.
A life hangs in the balance!$K
$s1Sounds exciting! I guess
I didn't need to worry about
you after all.$K
$s0You were worried?$w4 That's
nice, but to tell the truth, I've
never been happier, my boy!$K
$s1I'm glad to hear that.$K
$s0But enough chitchat. There's
a battle to finish!$K
$s1I'll second that.$K    $R�㉺��b|$c1KILROY|$s1Hm?$w2
Is that$MC... $MD$w2Gatrie, is that you?$K
$s0$FS$c0GATRIE|$s0Hm?$w4 Rhys?$w4 Rhys, look at
you! It's been so long!$w4
How are you doing?$K
$s1$FSOh$MC... $MD$w2I'm hanging in there.$K
And you?$w2 How has it been since
you left?$w4 Is the new job going well?$K
$s0You bet!$w4 In fact,$w2 I'm on a very
serious mission right now!$K$PI can't afford to lose.
A life hangs in the balance!$K
$s1I'm glad to hear everything's going
well for you.$K
I knew it would, but I was
worried$MC...$MD$w3 Just a little.$K
$s0Tee hee!$w2 You don't need to worry
about me. Why, I can't remember
when I've been this happy.$K
$s1I'm relieved to hear that.$K
$s0But enough chitchat!$w2 There's a
battle that needs fighting.$K
$s1Agreed.$w4 It's nice to fight at
your side again, even if we're
working for different people.$K  $R�㉺��b|$c0GATRIE|$s0$FhUgh$MC...$MD$w3 Lady Astrid$MC...$MD$w4
I wanted$w4 nothing more$w2 than to$w4
serve you$w4 well$MC...$MD$K  $R�㉺��b|$c0STELLA|$s0I$MC...$MD$w2wanted$MC...$MD$Fh
to live$MC...$MD$w2more freely$MC...$MD$w4$Fc
Grand$w3mother$MC...$MD$K $R�㉺��b|$c0NOSITOHI|$s0Blast!$w2 All my plans are falling apart.$w4
I'll cut you all down!$K $R�㉺��b|$c0NOSITOHI|$s0Ugh$MC...$MD$w2 You've come this far!?$K
You've ruined my plans and killed my
men! By rights, the princess should
have been long dead by now!$K
$c1IKE|$s1What we agreed to do$MC...$MD
was to protect the cabin.$K$PBut I can accomplish that mission$w2
if I crush you now.$K   $R�㉺��b|$c0NOSITOHI|$s0First birds, then beasts?$w4
You inhuman fiends!$K    $R�㉺��b|$c0NOSITOHI|$s0Accursed crows$MC...$MD$K
You ruined$MC...$MD$w3
all of$MC...$MD$w2my plans$MC...$MD$K    $R�㉺��b|$c0IKE|$w4Oh, no!!$K $R�w�i��b|$B�D-��|$<$F1$FCL_NOSITOHI|$F1$PPegasus knights? Begnion sent their
holy guard here?$K
Blast! $w2Accursed crows$MC...$MD$w4
My plan was perfect!$K$PIt's over$MC...$MD$w4 Men, into the seas!$w3
Swim for your lives!$K$PAnd if you get caught, tell 'em
nothing! Not a word about our
homeland, or your life is forfeit!$K  $R�w�i��b|$B�D-��|$<$F1$FCL_NOSITOHIB|$F1$PPegasus knights? Begnion sent their
holy guard here? And Norris lost
the battle?$K
It's over$MC...$MD$w4 Into the seas, men!$w3
Swim for your lives!$K$PAnd if you get caught, tell 'em
nothing! Not a word about our
homeland, or your life is forfeit!$K  $R�w�i�Ȃ���b|$F1$FS$F1$FCL_NAESALA|$F1$PI saw this coming, of course.$w4 You know$MC...$MD
If they'd just paid me more, I'd have
been willing to lend a hand.$K$POh, well. $w2What do a few human
lives matter to us? They're none
of our concern.$K
$FAWe're done here. Let's go.$K
$F3$FCL_CROW|$F3$PYes, sir!$K    $R�w�i�Ȃ���b|$F3$FCL_IKE|$F1$FCL_TIAMAT|$F1$PThat's it.$w4 It looks like the dust
is finally starting to settle.$K
$F0$FCL_SENERIO|$F0$PLooks like those crows took flight
as soon as the holy guard arrived.$w2
The other assailants fled, too.$K
$F3$PThen our job here is done.$w4 Crows
are one thing, but what were
those men doing with them?$K
$F1$PYes,$w2 I thought that was odd, too.$K
$F3$PThey looked like pirates,$w4 but
they certainly didn't act like them.$K
$F1$PTrue.$w4 They weren't interested
in treasure, and their soldiers
definitely were trained fighters.$K
But who were they? Which country
did they serve? Was this an attempt
on the apostle's life?$K
$F4$FCL_NASIR|$F4$PIt's possible.$w4
The apostle is the symbol of
the Begnion Empire itself.$K$PThe apostle is its empress. If
she were to perish,$w3 it's fair to say
Begnion itself would perish as well.$K
$F3$PI see$MC...$MD$K
$F0$FD$F7$FCDUMMY|$F7$PThe apostle is missing!?$w4
What do you mean!?$K$F1$FD
$F4$PThat voice$MC...$MD$K
$F3$PSomething must have happened.$w4
Let's go find out.$K    $R�w�i��b|$B�D��|$<$F4$FCL_BEGNION2|$F1$FCL_TANIS|$F1$P$MC...$MD$FcUgh. This business$w2 is
becoming quite the headache.$K
$F4$PI-I'm sorry, ma'am!$w4 If I can offer
up my life in repentance for$MC--$MD$K
$F1$P$FdOh, stop it.$w4 If you want to repent,$w2
go do something useful and find
the apostle.$K
$F4$PYes, ma'am!$K$F4$FD$w5
$F3$FCL_IKE|$F3$PDid I hear correctly?$w4
Is the apostle missing again?$K
$F1$POh, you're that mercenary$MC...$MD$K
$F3$PMy men guarded the cabin entrance.$w4
As far as I know, $w2we kept it safe
from the enemy$MC...$MD$K
$F1$PFrom what I have been told,$w4
the apostle slipped out of the
cabin on her own in the chaos$MC...$MD$K
$F3$POn her own?$w4 Now why would
anyone called "the apostle" do
something as stupid as that?$K
$F4$FCL_TIAMAT|$F4$PHey, $w1Ike!$w4
Watch your words.$w3
You're being rude.$K
$F1$P$FSIt's all right, dame knight.$w5$FA
I have more important matters
on my mind.$w3 I hate to ask,$w3 but$K$Pwould I be able to enlist your help
in searching for the apostle?$K
$F4$P$FSOf course!$w4 You don't
mind helping, do you, Ike?$K
$F3$PNah.$K
$F1$PWe'll search the enemy ship.$w2
Would you search your ship, just
to be sure?$K$PI would appreciate it.$K
$=1500   $R�w�i��b|$B�D-��|$<$F3$FCL_IKE|$F3$PI'll do what I can to find her,$w3
but I don't even know who
I'm looking for$MC...$MD$K$P$F4$FCL_SENERIO|$F4$PI think it's safe to assume
she will be a woman of stature,
a noblewoman of some sort.$K
$F3$PHuh.$K$P$F0$FCL_MIST|$F1$FCL_TIAMAT|$F1$PWell, I suppose all I have to do is
keep my eyes peeled for any
stowaway$MC--$MDanyone I don't know.$K$PLet's split up.$w4 It will go faster if
we search separately.$w4
Mist and I will check this side.$K
$F3$PThen Soren and I will search
the rest of the ship.$K
$=0500 $R�w�i��b|$B�D-�D��|$<$F1$FCL_SENERIO|$F3$FCL_IKE|$F3$PSoren$MC...$MD$w2 About what I
said this morning$MC...$MD$K
$F1$PYes?$K
$F3$PAbout the way you phrase things.$K
$F1$P$FcI$MC...$MD$w2 I ought to apologize
for that.$K
$F3$PNo, $w2don't apologize.$w4
I know you.$w4 I know it's been
bothering you, hasn't it?$K
$F1$P$FhNo.$w5 Well$MC...$MD$K
$F3$PDon't take it personally.$w5
I'm no better, you know.$K
Your ability to speak plainly the
things others won't is part of
what makes you brilliant.$K
Others are too bound by courtesy$MC...$MD
With you, I trust that what you
say is exactly what you think.$K
$F1$P$Fd$FSWell$MC...$MD$w4yes$MC...$MD$w4
Thank you, Ike.$K
$F3$PNow, $w2about that missing apostle$MC...$MD$K
$F1$P$FAOh$MC...!$MD$K
$F3$PYou found her?$K
$F1$PNo, I don't think so. But there's
a child stowing away in here!$K
$F3$PWhat!?$w4 What is a child doing
hiding on our ship!?$K
$F1$PShe must be some aristocrat's
daughter. Probably slipped on
from the Begnion ship$MC...$MD$K
It was a hectic battle. She must
have been frightened and hid
herself here in the confusion.$K
Are you going to help her?$K
$F3$PWell, we can't just leave her.$K
$=0500   $R�w�i��b|$B�D-�D��|$<$F1$Fc$F1$FCL_SANAKI|$F3$FCL_IKE|$F3$PHey, $w2are you all right?$K$P$F1$PI-$w2I'm$MC...$MD$w4fine$MC...$MD$K
$F3$PHey, $w2don't be scared!$K
$F1$PUh$MC... $MD$w4$FdWh-who might you be?$K$PYou don't look like a$w4 laguz.$w4
Perhaps a new recruit?$K
$F3$PNo. $w2I'm a mercenary. I was
hired by Princess Elincia.$K
$F1$PThe Crimean princess?$w4$Fc
Ouch!$K
$F3$PWhat's wrong?$w4 Oh, you hurt
your foot.$w4 Let me see.$K
$F1$P$FdHold!$w4 Do not approach me!$K$PHey, $w2I told you not to$MC--$MD$w4$Fc Oooouch!$w3
$FdYou're hurting me!$w4 You fool!!$K
$F3$PLooks like the bone's not broken.$w4
Still, we'd better have Mist take
a look at it $w2just in case.$K
$F3$FD$F2$FCL_IKE|$F1$POh?$w4 What?$w4
What are you doing!?$K
$F2$PJust hush up and hold on to me.$w4
There's my sister.$w4 She can heal
that foot of yours right up.$K
$F1$PAre you trying to help me?$w4
Shouldn't you be elsewhere?$K
$F2$PI'm supposed to be looking for
some sort of apostle person.$K$PBut I think there are enough
other people looking,$w4 and I'd
rather help the injured first.$K
$F1$PHa$MC...$MD$w4
I see. $w2This is indeed$MC...$MD$K
$F2$PHm? What is it?$K
$F1$POh, $w2nothing.$w4
If that's the case, $w2I accept your help.$K
$F7$FCL_MIST|$F7$PIke!$w4
Any luck finding the apostle?$K
$F2$FD$F0$FCL_IKE|$F0$PNope. $w2All I found was a
little lost child.$K
$F4$FS$F4$FCL_TIAMAT|$F4$PHey, she's quite a cutie.$K
$F0$PMist, $w2do you think you could
use your staff to heal this kid?$K
$F7$FD$F3$FS$F3$FCL_MIST|$F3$PYeah.$w4 Is she hurt?$K
$F0$PJust her foot$MC... $MD$w4But maybe she
bumped her head, too.$K
She's been mumbling$w2 complete
gibberish since I picked her up.$K
$Ub$H$F1$P$FcI kept silent, $w2blaming these antics
on your ignorance,$w4 $Fdbut I can no
longer$w4 tolerate your manners!$K
$F0$PHuh?$w4 What's wrong?$w2
It's your foot, isn't it?$K
$F1$PPrepare yourselves, $w2peasants!$K
$F0$PPrepare? For what?$K
$F3$P$FA$F4$P$FA$F1$PYou stand in the presence of Sanaki,
empress of Begnion!$w4 I am the
apostle, the voice of the goddess!$K
$F0$PEmpress?$w4
What did she say?$K
$F4$PWhat? $w2Then she is$MC...$MD$K
$F3$POh, no$MC... $MDIs she really$MC...?$MD$K
$F0$PNo, $w2she can't be.$K
$F3$FD$F3$FCL_SENERIO|$F3$PNo way.$K
$F4$P$FSHold your judgment$MC...$MD$w4 Even if she's
lying, $w2there must be a reason$MC...$MD$K
$F1$PY-$w1you$MC...$MD$w1ignorant$MC...!$MD$K
$F3$FD$F7$FCDUMMY|$F7$PAre you all right,$w4 Empress!?$K $R�w�i��b|$B�D-��|$<$F3$FCL_SANAKI|$F0$FCL_SIGRUN|$F0$PMy apologies!$w4 We were unable to
reach you, and we left you in terrible
peril. I accept full responsibility.$K
$F3$PYou're late, Sigrun!$K$PWhat would you have done had
something happened to me?$K
$F0$P$FcPlease, Empress, I beg your forgiveness.$K
$F0$P$Fd$F3$PThat won't be necessary.$w4
I am also$w2 partly to blame
for what happened.$K$F3$FD
$F1$FCL_SANAKI|$F3$FCL_IKE|$F1$PLet's focus instead on our rescuers.$w4
As a reward for rescuing me, I would
like to invite them to visit our court.$K$PAnd be sure that the one they serve,
that girl who claims to be the princess
of Crimea, is invited as well.$K$F1$FD
$F0$PPrincess Elincia's bodyguards, I presume.$w4
I am sorry for the trouble you've gone to.$K
$F3$PAnd you are$MC...?$MD$K
$F0$P$FSI beg your pardon.$w4 My name is Sigrun.$w2
I'm a commander of Begnion's holy guard.$K$PNo word of thanks will ever repay you
for saving the empress.$K$P$F4$FCL_MIST|$F4$PWait$MC... $MD$w4So $w2it's true?$K
$F4$FD$F4$FCL_TIAMAT|$F4$PAre you saying $w2that little child$MC...$MD$K
$F3$Pis Begnion's$MC...$MD$K
$F4$FD$F4$FCL_SENERIO|$F4$PEmpress$MC... $MD$w4Hm. It appears so.$w4
I can't say I quite believe it,
but she seems sincere.$K$PBesides, how many people do
you know who command a
legion of pegasus knights?$K
$F0$PThe empress has invited us to
join her at Sienne, the capital
of Begnion.$w4 I think we should go.$K
Where is the princess? We should
ask her permission before agreeing.$K
$F3$PShe must be in the cabin.$w4
I'll take you to her.$K
$=1500    $R�w�i��b|$B�D-�D��|$<$F1$FCL_IKE|$F6$FS$F6$FCL_TRAIN|$F6$PCommander, how are you?$w4
Staring at the sea, I see$MC...$MD$K
$F1$PI know you$MC...$MD$w2 You're$w4 Jorge, right?$w3
You make weapons for us.$K
$F6$PNo.$w4 Jorge buys used ware.$w3
I'm his twin brother.$w5 Well, mostly his
twin. He has blond hair, you see.$K
My name is Daniel.$w4 Just remember
that I have brown hair and that
Jorge has blond, and you'll be fine.$K
$F1$PBrown hair, Daniel, and weapons$MC...$MD$w4
Blond hair, Jorge, and items$MC...$MD$w5
I think I'll remember.$K
$F6$PFantastic.$w3 Say, can I ask you
a quick question?$w4 You're a battle
expert, right? You've fought a lot?$K
$F1$PEnough, yeah. What is it?$K
$F6$P$FAPicture this.$K$PLet's say there are two ships.$w4 And
suppose there are planks connecting
the ships at three different points.$K
$F1$PAll right. I'm picturing it.$K
$F6$PNow then, soldiers from one ship are
about to attack the other one.$K$PImagine that the defending side has
fewer soldiers.$w4 If they want to mount
a solid defense, what should they do?$K
$F1$PIt seems clear enough to me. Position the
soldiers with the best defense on the
planks, soldiers like cavaliers and knights.$K
$F6$P$FSI see.$w2 So you would hold the enemy
at bay by using your strongest allies
to block the primary crossing points!$K
$F1$PThen, you'd want to have your long-
range attackers line up behind the
tougher units barring the bridges.$K$PI'm talking about anyone with $w2javelins,
$w2axes, $w2or magic.$w3 You'd be able to
do a lot of damage without much risk.$K
$F6$PSounds like a good plan but$MC...$MD$w3$FAit seems
rough on the soldiers defending the bridges.$K
$F1$PYou would want to heal them often,
obviously,$w3 but maybe there's a way to
reduce how much damage they take.$K
$F6$PIt's a stretch, but$w3 what if I don't have them
attack at all?$w4 That way, they won't run the
risk of getting any counterattacks!$K
$F1$PHmm$MC... $MD$w3That's not a bad idea.$K
$F6$P$FSGreat!$w4 Thanks.$w3
That gave me some good ideas.$K
$F1$PIdeas? For what?$K
$F6$POh, my brother and I have been playing
a wargame.$w4 I've lost four times in a row.$K
$F1$PA wargame?$K
$F6$PWe'll let you join$w3 if you bring some
parchment and a quill.$w4 Come see us
anytime $w2if you're curious.$K
See you later.$K$F6$FD
$F1$P$FhMaybe I shouldn't have been
so serious with him$MC...$MD$K  $R�w�i��b|$B�D��|$<$F1$FCL_IKE|$F3$FS$F3$FCL_TOOL|$F3$PWell, well!$w2 If it isn't our commander!$w4
What brings you down here?$K
$F1$PI was just on my way to the deck.$K
$F3$POh, $w2I see.$w4 That's too bad.$w5
I had a story I wanted to share
with you.$K
$F1$PA story?$K
$F3$PHm mm.$w4 And quite a ripping
yarn it is, too. Interested?$K
$F1$PWell$MC... $MD$w2Not really.$K
$F3$P$FAOh,$w3 you're so rude!$w4
And after you were so sweet
the other day!$K
$F1$PWhat are you going on about?$K
$F3$PWhen those crows attacked$MC...$MD$w4 I had
wanted to see what they looked like,
so I was hiding on the deck, watching.$K$PI had heard they could fly, of course,$w4
but I had no idea they could fight!$K
I thought one of them had the drop
on you, and I couldn't help myself!$K$PI cried out,$w3 "Commander, watch out!"$K
$F1$PI thought I'd heard a strange,$w3
shrieking sound.$w4 That was you?$K
$F3$PAnd upon hearing my sweet voice,
Commander,$w4 you turned around$K$Pand brought down that crow with one shot!$w4$FS
It was$w2 awe inspiring.$K
$F1$PNot really.$w2 He was exhausted from
the battle. He could barely move.$K
$F3$PAnd$w4 that's when you first caught my
eye, my$w2 dynamic young commander!$K
$F1$PIs that why your hand always$w3
lingers on mine when you hand
me my equipment?$K
$F3$POh, no!$w4 Have I been too$MC...$MD
obvious?$K
$F1$PMaybe I should send one of the
others down to pick up our gear
from now on$MC...$MD$K$F1$FD
$F3$PHm.$w4 You're embarrassed, aren't you?
You're so cute when you're being coy!$K$PBut once I set my sights on a man,$w2
I never let him get away.$w4 Remember that.$K $R�w�i��b|$B�D-��|$<$F1$FCL_IKE|$F1$PHey.$K
$F3$FCL_JILL|$F3$PWhat do you want?$K
$F1$PIs there any reason you're still
on our ship?$K$PThe crows are gone.$w4
The truce is over, isn't it?$K
$F3$P$MC...$MD$K
I have a duty. As a Daein soldier, I cannot
allow a Crimean princess and her band
of mercenaries to run free where they will.$K
$F1$PIf you want to start a fight,$w4
you're on the right path.$K$PThink you can take us all on your own?
Because if you want to get your friends,$w3
I won't stop you from leaving the ship.$K
$F3$PWatching you all fight those crows
like a band of street rats with sticks,$w3
I could see you were no match for me.$K
But even if I were to leave this ship,$w4
the land is too far away for me to reach.$K
$F1$PNonsense.$w4 I can see land in the distance
from time to time, and I thought you could
go anywhere on that wyvern of yours.$K
$F3$PNo wyvern could fly that far without
resting,$w5 and these islands are
thick with half-beast scum.$K$PEven if I wanted to,$w3
I couldn't leave this ship.$K
$F1$PThen let me ask you,$w4 why did you
follow us alone $w2knowing that?$K
$F3$PI wanted$w3 to be recognized$MC...$MD$w5
I wanted my deeds to earn me fame.
A soldier has little else to strive for$MC...$MD$K
$F1$PAnd yet you soldiers sneer at mercenaries.$w5
At least we fight for something real.$w2
There are some dumb soldiers in this world.$K
$F3$P$MC...$MD$K
$F1$PYou leave us no choice.$w4
I'll take you as far as Begnion.$K
$F3$P$MC...$MD$K
$F1$PBut$w3 as long as you're on my ship,
you will not utter the phrase "half-beast."$K
If you can't agree to this condition,$w3
I'll kick you off the ship right now.$K
$F3$PI$MC-- $MD$w2All right$MC...$MD$K
$F1$P$MC...$MD$K$F1$FD
$F3$P$Fc$MC...$MD$K  $R�w�i��b|$B�D-�D��|$<$F0$FCL_BOLE|$F1$FCL_LOFA|$F3$FCL_OSCAR|$F0$PI'm just saying,$w4 there has to be
something more we can do.$K
$F3$PBoyd$MC... $MD$w3You're not making any sense.$w4
I understand your enthusiasm to help Ike,
but try to explain what you mean$MC...$MD$K$PWe can't do anything $w2until we know
exactly what it is you want to do.$K
$F0$PYou're so impatient, Oscar.$w4
I was just getting to it, all right?$K
$F3$PImpatient?$w2 You're calling me impatient?$w4
You're so impatient you can barely be
bothered to put your armor on!$K
$F0$PNag, nag, nag.$K$w4$FS$PListen,$w3 I think we should come up
with an unstoppable killer attack,$w5
something only we can do!$K
$F1$P$FSAn unstoppable attack!?$w4
That sounds good$MC...$MD$K
$F0$PDoesn't it?$w4
I'm glad you approve, $w2peewee!$K
$F1$P$FADon't call me peewee!$K
$F3$PIt is a fine plan,$w3 but you haven't
explained what this new attack
is supposed to be.$w5 How do we do it?$K
$F0$PHey, I came up with the idea. It's your
job to figure out the details.$w4
Make it cool, though, Oscar.$K
$F3$PBoyd, this plan sounds$MC...$MD$w3
Oh, dear$MC...$MD$w5 How do I put it?$K
$F1$P$FSLet me do it!$w4 I'll think up a great one!$K
$F0$P$FANo way. $w2Forget that.$w4
It's too much for your little peewee brain.$K
$F1$P$FAI told you, $w1don't call me that!$K
$=0500  $R�w�i��b|$B�D-�D��|$<$F3$FCL_IKE|$F3$PThey may not like to admit it,
but they certainly are close.$K  $R�w�i��b|$B�D-�D��|$<$F1$FCL_SENERIO|$F3$FCL_IKE|$F1$PIke,$w3 I'm here to report
the results from the last battle.$K$N$UB$H   $F3$P$Fc$MC...$MD$K$P$UB$H  $F1$P$FSWe suffered no casualties$w2
or irreparable harm.$w4
Everyone was at their best.$K$P$UB$H   $F1$PThat concludes my report.$w4
Excuse me.$K    Y�      Z<   	  [h     [�   "  X�   ,  Y\   =  \L   M  ]�   Y  ^�   g  h�   s  _�     d   �  j�   �  o�   �  y    �  !$   �  )4   �  ,l   �  .\   �  4\   �  \,        �P     ��  .  �P  <  �x  J      Z  |  f  �  r  �  ~  �  �  @  �  �  �    �  �  �   x  �  ��  �  �`  �  ��    �|    5  !  7�  ,  ;�  7  @�  E  D  S  G   `  Id  m  L�  z  OH  �  R�  �  U�  �MS_14_BT MS_14_BT_IKE MS_14_BT_R1 MS_14_DIE MS_14_DIE_GATRIE MS_14_DIE_STELA MS_14_ED_01 MS_14_ED_01_2 MS_14_ED_02 MS_14_ED_03 MS_14_ED_03_00 MS_14_ED_03_01 MS_14_ED_04 MS_14_ED_05 MS_14_ED_06 MS_14_EV_01 MS_14_EV_02_01 MS_14_EV_02_02 MS_14_EV_03 MS_14_EV_04 MS_14_GAMEOVER MS_14_INFO_01 MS_14_INFO_02 MS_14_INFO_03 MS_14_INFO_04 MS_14_INFO_04_2 MS_14_OP_01 MS_14_OP_02 MS_14_OP_03 MS_14_OP_04_01 MS_14_OP_04_02 MS_14_OP_05 MS_14_OP_05_0 MS_14_OP_05_00 MS_14_OP_05_0_2 MS_14_OP_06 MS_14_REPO_BEGIN MS_14_REPO_DIE MS_14_REPO_END MS_14_REPO_NODIE MS_14_TK01 MS_14_TK02 MS_14_TK_G_1A MS_14_TK_G_1B MS_14_TK_G_2 MS_14_TK_G_3 MS_14_TK_G_4 MS_14_TK_G_5 MS_14_TK_G_6 MS_14_TK_G_7 MS_14_TK_G_8 