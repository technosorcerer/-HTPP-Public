  0c  -x                       $R�w�i��b|$B�A�W�g-��펺|$<$F1$FCL_GREIL|$F4$FCL_IKE|$F0$FS$F0$FCL_TIAMAT|$F0$PGood morning, Ike.$w4 Today's your first day
as a professional soldier, isn't it?$K
$F4$PYeah,$w4 and I'm ready to go.$K
$F1$PWhat you are$w4 is late.$w4 The others were
suited up and ready at the break of dawn.$K
$F4$PSorry.$w3 I'll get up earlier from now on.$w5
So, $w2what's my first job?$K
$F1$PI'm talking with Titania right now.$w4
Wait outside until we're done.$K
$F4$PYes, sir.$K
$F4$FD$F0$FD$F3$FS$F3$FCL_TIAMAT|$F3$PVery well, Commander Greil,$w4
shall we continue?$K
$F1$PYou were telling me about some bandits
that needed taking care of, weren't you?$K
$F3$PCorrect.$w4 The request comes from a
nearby village.$w4 According to our reports,$w2
the bandits are not all that strong.$K$PI think it best if I ride out and take a look.$w2
I plan on taking Oscar and Boyd
along with me.$K
$F1$PJust the brothers? Hm. Go ahead and
add Ike to your team.$K$PShinon, Gatrie, and I can handle the
other two jobs easily enough.$K$PTitania,$w3 I'm leaving Ike in your care.$w4
I'm trusting you to show him the ropes.$K
$F3$PUnderstood, Commander.$K$F1$FD$F3$FD
$F1$FS$F1$FCL_TIAMAT|$F3$FCL_IKE|$F1$PCome on, Ike. Let's get you set up.$K$F1$FD
$Ub$H$F3$PAll right$MC...$MD$w3 My first job.$K  $R�㉺��b|$s0$FS$c0OSCAR|$s0Captain Titania.$w4
Preparations are complete,$w2
and I'm ready to go.$K
$s1$FS$c1TIAMAT|$s1Impeccable timing.$w4
It's nice to know we can always count
on you to be at the ready, $w2Oscar.$K
$d0$s0$FS$c0BOLE|$s0Don't forget about me!
I'm ready for action!$K
$s1Is that so, Boyd?$w4
That's a surprise.$K
$s0Ha!$w2 Not today it isn't.$K
$d1$s0As of today,$w2 I am going to be the
absolute model of perfection.$w4
I need to set a good example for Ike!$K
$c1IKE|$s1I'll$w3 take your word for it.$K
$d0$s0$FS$c0OSCAR|$s0Your first campaign at last.$w4
I know you've wanted this for
a while. Are you nervous, Ike?$K
$s1I think I was more nervous$w2
last night. I could hardly sleep.$K$PThis morning,$w2 I'm feeling pretty
good. It's the calm before the storm.$K
$s0You should try to relax.$w4 You're not
going to be out there alone.$K
$s1$FSYeah, you're right.$K
$d1$d0$s0$FS$c0TIAMAT|$s0Right. $w2Everyone ready?$w2 Let's go.$K $R�㉺��b|$s0$FS$c0TIAMAT|All right, let me explain what's
going on.$K $R�㉺��b|$s0$FS$c0TIAMAT|This is a map of Caldea. They've
hired us to drive off some bandits.$K
We're the blue marks here.$Ub$H$K$P$Ub$HThe red dots $w2are the bandits.$Ub$H$K
$Ub$H$s0There aren't many of them,$w2 but we
can't get careless.$w4 The one in front of
the building up north $w2is their leader.$K   $R�㉺��b|$s0$FS$c0TIAMAT|Our mission is to take him out$w2
and recapture that building.$K$P   $R�㉺��b|$s1$FS$c1TIAMAT|This is the village of Caldea.$w4
The bandits are few,$w2 but
we mustn't get careless.$K$POur goal is to take out the bandit
leader in front of the large building,$w3
and then secure that building.$K  $R�㉺��b|$s0$FS$c0BOLE|$s0Ike!$w3 Listen up!$w4
All this stuff is old news to me, but I
can give a rookie like you a few tips.$K$PFirst off, don't let yourself get worked
up and jump out in front of everyone.$w4
You'll just end up getting hurt.$K    $R�㉺��b|$s0$FS$c0OSCAR|$s0Don't try to do too much, Ike.$w4
When things get dangerous,$w2
you can$MC--$MDand should$MC--$MDrely on us.$K
$PAs long as you watch how the enemy
moves carefully, you'll be fine.$w4
Think of this as$w2 a training mission.$K
$c1IKE|I'll do that.$w5
Oscar, Boyd,$w2 thanks
for your help.$K
$s0Don't mention it.$K
$s2$FS$c2BOLE|Just sit back$w2 and watch how
a professional handles things!$K
$d0$d2$d1$c1TIAMAT|Enough chitchat, you three!$w4
We've got work to do!$K   $R�㉺��b|$s0$FS$c0TIAMAT|$s0Ike,$w3 before you engage an enemy,
take a good look at his weapon.$K$PThe weapon you use$w3 often determines
who has the upper hand in a fight.$K$PFor example, $w2the axe I'm wielding
serves me well against lances,$w4
but it fares less well against swords.$K
$s2$FS$c2OSCAR|And my lance is great against
swords$w2 but not against axes.$w5
And to complete the triangle$MC...$MD$K
$c1IKE|Ah! My sword. It's strong against
axes$w2 but weak against lances. Right?$K
$d2$s0Yes, $w2exactly.$w5
If you can remember that,$w2
you'll be more effective in combat.$K
$d0$s0$FS$c0BOLE|That's just the basics, though.$w4
This'll come in handy
soon enough,$w2 so don't forget it.$K
$s1Swords over axes$MC...$MD$w3 I won't forget.$w2
Not if I remember that I'll always
have the advantage over you, Boyd.$K
$s0$FhDo you think you could maybe find
a different way of remembering?
Yeah, thanks.$K    $R�㉺��b|$s0$FS$c0TIAMAT|$s0And one more thing$MC...$MD$w3
Don't forget to visit the locals.$K$PWe're here to help, after all.$w3 The
villagers should welcome our presence.$K    $R�㉺��b|$c0ZAWANAR|What's going on out there?$w3
Is that some sort of army?$K
$PPah.$w2 A bunch of mercenaries
looking for their next meal.$w2
The villagers must've hired 'em.$K
$PListen up, lads!$w4
Hurt 'em, and hurt 'em bad!$K
$PWe let this bunch live, and we'll
have hordes of hired swords
hounding us the rest of our days!$K    $R�㉺��b|$s0$FS$c0BANDIT1|It's those fool villagers$MC...$MD$K$PThey think they can buy a bunch of
sellswords to chase us away. It ain't
gonna work out how they wanted.$K$PAll they get for their trouble is a
bunch of ruined houses. Tear
'em down, boys! That'll teach 'em!$K $R�㉺��b|$s0$FS$c0BANDIT1|My work here is done.$w3
This house is totalled!$K$PTime to move on to bigger things.$w4
Now,$w3 I smash me some mercenaries.$K $R�w�i��b|$B��-��|$<$F4$P$FCLME|$F1$FS$F1$FCL_GRANDPA|Oh, you're the mercenaries, right?$w4
Glad you could make it.$K$PIf it's all the same to you, I'd like
you to take this. It's my old sword.$K$PTwenty years younger, and I'd
be fighting these scum, too.$w2
Can't defeat Father Time, though.$K $R�w�i��b|$B��-�R|$<$F1$FCL_WOMAN1|$F4$FCLME|$F1$PSince those bandits took over, we
can't even sleep at night.$K$PPlease!$w4
Help us save our village.$K$P$w2Here. My mother left me this.$w4
I hope it serves you well.$K $R�w�i��b|$B��-��|$<$F1$FS$F1$FCL_MISTER1|$F4$P$FCLME|$F1$PAh,$w3 you're with the mercenaries, right?$w4
Thank you for coming.$K$PWe've heard a lot about you.$w4
Here, take this weapon.$K$PWe're farmers, not fighters.$w3 Maybe
you'll get some use from it.$K  $R�㉺��b|$c0ZAWANAR|$s0You looking for something, fool?$w4
You looking for a fight?$K$FS$PHeh heh$MC... $MDYou came to the right
place.$w4 I'll give you a tussle!$K  $R�㉺��b|$s0$FS$c0ZAWANAR|$s0Hey, $w2you're nothing but a boy.$w4
Well, every brat needs a beating
now and then. Are you ready for it?$K
$c1IKE|$s1Not today.$w4
If you want to run away,$w2
now's your chance.$K
$s0Heh heh heh.$w2 Imagine that, $w2you
sassing me.$w2 Don't that beat all?$K   $R�㉺��b|$c0ZAWANAR|$s0Urhg!$w3
I$MC...$MDI'm meant for better than this$MC...$MD
I don't want to die here$MC...$MD$K $R�w�i��b|$B��-�R|$<$F1$FCL_TIAMAT|$F1$PThat's the end of it.$w4 Ike, are you all right?$K
$F3$FCL_IKE|$F3$PYeah, I'll be fine.$K$N$UB$H   $F3$PBut$MC...$MD$w3Oscar and Boyd$MC...$MD$K
$F1$P$MC......$MD$w2Listen to me, Ike.$K$PThe life we've chosen$MC...$MD$w3 It does not
forgive even the smallest error.$w4
Such a lapse means$MC...$MD$w3someone dies.$K
$F3$P$MC...$MD$K
$F1$P$MC...$MDWe've wasted enough time.$w3
Let's get going.$w4 Commander Greil,$w2
he'll want to hear about this.$K    $F1$PDespite my own warnings,$w4 I let
my guard down, $w2and I got beaten.$w3
Ha ha$MC...$MDurgh$MC...$MD$K
$F3$PTitania, $w2you shouldn't move.$K$N$UB$H   $F1$PI$MC...$MDwas lucky.$w4
I doubt if I'll ever be able to fight as
well again, but$MC...$MD$K
$Pat least I'm still alive.$w5
$MC...$MDIt's better than nothing.$K$F3$P$Fc
$F3$P$MC...$MD$K
$F1$POscar and Boyd$MC...$MD$w4
They're not coming back$MC...$MD$K$P$F3$P$Fd$F1$P$MC...$MD$w2Listen to me, Ike.$K$PThe life we've chosen$MC...$MD$w3 It does not
forgive even the smallest error.$K$PYou must never$MC...$MD$Fc$w3forget that$MC...$MD$K
$F3$P$MC...$MD$K
$F1$P$MC...$MDWe've wasted enough time.$w3
$FdLet's get going.$w4 Commander Greil,
$w2he'll want to hear about this$MC...$MD$K
$=2000   $F1$PI$MC...$MDwas lucky.$w4
I doubt if I'll ever be able to fight as
well again, but$MC...$MD$K
$Pat least I'm still alive.$w5
$MC...$MDIt's better than nothing.$K$F3$P$Fc
$F3$P$MC...$MD$K   $F1$P$FSYou know, you surprised me.$w4
To think that you've come so far.$K
$F3$PLook at my father, though.$w2
I've still got such a long way to go.$K
$F1$PThere's nothing you can do about that.$w4
After all, Commander Greil is$MC--$MD$K
$F3$PHuh?$w3 What about my father?$K
$F1$POh,$w4 nothing.$K
$F3$P"Nothing"?$w2 Now I'm really curious.$K
$F1$PDon't worry. $w2You'll learn all about it someday.$K
$F3$P$MC...$MD$K$N$UB$H $F3$PBut$MC...$MD$w3
But Boyd's$MC...$MD$K
$F1$P$MC...$MD$w2Listen to me, Ike.$K$PThe life we've chosen$MC...$MD$w3 It does not
forgive even the smallest error.$K$PSuch a lapse means$MC...$MD$w3someone dies$MC...$MD$K
$F3$P$MC...$MD$K
$F1$P$MC...$MDWe've wasted enough time.$w3
Let's get going.$w4 Commander Greil,
$w2he'll want to hear about this$MC...$MD$K$N$UB$H   $F3$PBut$MC...$MD$w3
Oscar's$MC...$MD$K
$F1$P$MC...$MD$w2Listen to me, Ike.$K$PThe life we've chosen$MC...$MD$w3 It does not
forgive even the smallest error.$K$PSuch a lapse means$MC...$MD$w3someone dies$MC...$MD$K
$F3$P$MC...$MD$K
$F1$P$MC...$MDWe've wasted enough time.$w3
Let's get going.$w4 Commander Greil,
$w2he'll want to hear about this$MC...$MD$K$N$UB$H  $F1$FD$w6$F1$FS$F1$FCL_BOLE|$F1$PHey, Ike!$w3 That wasn't bad for your first battle.$w4
Not as flashy as my first time, though!$K
$F0$FCL_OSCAR|$F0$PYeah, you were a real standout.$w4
I'll never forget the sight of you so
keyed up you broke your own axe.$K
$F1$P$FAOscar!$w3 Dang it!$w2
You didn't have to bring that up!$K
$F0$FS$F0$PAnyway, Ike.$w4 Congrats on finishing
your first mission.$K
Welcome to the group.$K
$F4$FS$F4$FCL_TIAMAT|$F4$PEveryone's all right?$w4 Then let's get going.$w5
I'm sure Mist has a nice, hot meal
waiting for us.$K
$=1500   $F1$FD$w4$F0$FCL_OSCAR|$F0$PCaptain!$K
$PIke, $w2I'm going on ahead to take
Captain Titania back to the base.$K$PBoyd,$w3 will the two of you be all right?$K
$F4$FCL_BOLE|$F4$PYeah,$w2 don't worry about us.$w3
Just take care of the captain!$K
$F0$PLook after my horse!$K$F0$FD
$F3$PI can't believe it$MC...$MD$w3 Captain Titania
got beaten.$K
$F4$PNo matter how strong you are,$w3 the smallest
opening can cost you your life.$K
$PDid you see that wound?$w3 I bet
she'll never be able to fight again.$w4
Curse those bandits!$K
$F3$PTitania$MC...$MD$K   $F1$FD$w6$F1$FS$F1$FCL_OSCAR|$F1$PWell, Ike.$w4 Congratulations on
completing your first mission.$K$w4
Welcome to the group.$K
$F3$POscar$MC...$MD$w3
About Boyd$MC...$MD$K
$F1$P$FA$MC...$MD$w2I know.$w3
Nothing we can do.$K$PThis job we do$MC...$MD$w3
Every day, $w2we risk our lives$MC...$MD$K
$F3$P$MC...$MD$K
$F1$PKeep your chin up, Ike.$w3
My brother$MC--$MD$w3Boyd would want it that way.$w4
We$MC... $MDWe$MC...$MD$K
$F3$P$MC...$MDIt's all right.$K
$=2000   $F1$FD$w6$F1$FS$F1$FCL_BOLE|$F1$PHey, Ike!$w3
That wasn't bad for your first battle.$w4
Not as flashy as my first time, though!$K
$F3$PBoyd$MC...$MD$w3
About Oscar$MC...$MD$K
$F1$P$MC...$MD$w4Yeah$MC...$MD$w2
Nothing we can do about it.$K
$P$w4It's our job.$w3 Every day,
we gamble with our lives$MC...$MD$K
$F3$P$MC...$MD$K
$F1$PStop making that face.$w4
I won't have to listen to him yapping
at me all the time. It's a relief.$K$PEvery single day$MC...$MD$FA$w4
All he ever did was $w1$Fctell me what
I was doing wrong$MC...$MD$w3$K
Oscar$w3$MC...$MD$K
$F3$PBoyd$MC...$MD$K
$=2000    �      T   	  x     �      |   /  �   E   �   X  "0   g  #�   x  x   �  �   �  %   �  '8   �  )`   �  +0   �  `   �  �    �    �      )      5  �  A  
�  P  �  _  �  n  
0    t  �  p  �  �  �  �  �  �  �MS_02_BT MS_02_BT_IKE MS_02_DIE MS_02_ED_01_01 MS_02_ED_01_01_OB_OIE MS_02_ED_01_02_DIE MS_02_ED_01_03 MS_02_ED_01_03_2 MS_02_ED_01_03_3 MS_02_ED_01_03_DIE MS_02_ED_01_03_DIE_B MS_02_ED_01_04_A MS_02_ED_01_04_B MS_02_ED_01_04_C MS_02_ED_01_04_D MS_02_EV_00 MS_02_EV_000 MS_02_EV_01 MS_02_EV_01_02 MS_02_EV_03 MS_02_OP_01 MS_02_OP_01_02 MS_02_OP_02_00 MS_02_OP_02_01 MS_02_OP_02_01_2 MS_02_OP_02_04 MS_02_OP_03_01 MS_02_OP_03_02 MS_02_VIL_01 MS_02_VIL_02 MS_02_VIL_03 