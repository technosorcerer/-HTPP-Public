Fire Emblem: Souen no Kiseki convert to English
Version: 0.1
Released: 08/22/2012
By: shadowofchaos

Special Thanks to:
VincentASM - For helping me figure out the FE9/FE10 filesystem and how text pointers work.
SandwichSage and Nintenlord - For both making LZ77 compressors and decompressors. I used them both even though they're interchangable.
BSV -  For creating Gamecube Rebuilder.

It's not even much hacking really... it's copying and pasting, and fixing pointers.

This "patch" is performed by running the included GCRebuilder to rebuild the image by using the included files.

It replaces the Japanese text for the story and menus with the English Path of Radiance text.

Obviously, this requires the Japanese FE9 ISO.

Why do this if there's an English version already? It's because of Maniac Mode. It was replaced by Easy Mode in non-Japanese versions.


Obviously, there are issues with text spacing on menus and unit information, but it's usable.
Same with skill names.

I don't really know if I'll work on this any more, or if I'm gonna attempt to convert Maniac mode into the US FE9, but who knows.
I may... I may not. I might not even have the skills right now to do so.

If anyone knows how release a patch for the ISO, please tell me how. At the current time, Nintenlord's UPS format for GBA Fire Emblem hack patching doesn't work because the Gamecube has a file system that shifts offsets and causes the UPS patcher to basically make a copy of the entire ISO.

Please report any GAME BREAKING bugs at the Serenes Forest thread. Any text problems will be ignored. Like I said, it's not likely I'll go back to this.

How to use:

1. Open up GCRebuilder.
2. Click "Image", then Open. Select your FE: Souen No Kiseki ISO file.
3. Right click on "root" on the very right with the file tree.
4. Click "export" and select somewhere to extract all the files.
5. When it is finished, replace the files in the "root" folder with all the files included in the "FE9 JPN English Files".
6. Click "Image" then "Close" on GCRebuilder.
7. Click "Root" then "Open"
8. Select the "root" folder that you replaced the files in
9. Click "Save" and select your old ISO, or even a new one.
10. Click Rebuild.
11. Once it's finished, enjoy your Maniac mode in English if you so desire.

Note #1: The system.cmp is larger than the original, so using "import" when you open an image to replace the file doesn't work. Not even with Wiiscrubber.
Note #2: The movie files are still Japanese voiced, because the thp files are large. I didn't want to include it in this package.