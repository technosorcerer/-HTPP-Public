Super Robot Wars GC English Patch
Version 1.0.2

--------------------------------------
Patch Instructions
--------------------------------------
In order to play this translation, you'll need to use an Xdelta patcher in order to apply the included
"srw_gc_english.xdelta" file to a disc image of the original game in ISO format. It's recommended not
to use an online patcher due to the size of the game in this case.

Some patchers can be found below, though only the Windows option has been tested to date:
 - Delta Patcher (Windows): http://www.romhacking.net/utilities/704/
 - Multipatch (Mac): http://www.romhacking.net/utilities/746/
 - YADP (Linux): http://www.romhacking.net/utilities/1159/

Please be sure to create a copy of your ISO prior to patching, as such programs may overwrite your
original copy with the English version during the patching process. This will also ensure that you
can apply any subsequent patches if released.

Checksums for the verified version of the original ISO are:
 - MD5: e7094d70e1df2cf104b7aa590945aa52
 - SHA-1: b200ff936716c2b096a0e3895798c861a2fc5254
 - SHA-256: AD4CB99FFB3C0383802A2AB87963F98BA417DFC5184ED3FE3DFE077DA02DB229

As this translation was created for free, by fans for fans, we do not authorize any use of this patch for
commercial use. We'd also ask that you please only use this with a backup made of your original copy
of the game, as well as not to contact the authors in regards to where to download a copy of the game.

--------------------------------------
Patch Details
--------------------------------------
 - IMPORTANT: For Dolphin users, please ensure that the "Texture Cache" is set to Safe. Otherwise, battle text
   will not display correctly. This option can be found under the "Graphics" menu, in the "Hacks" tab. For 
   Android versions, this will instead be labeled as "High" under "Texture Cache Accuracy".
 - The game title may also show up as Japanese in Dolphin, as the base game and translation both share
   the same Game ID.
 - Original save files should still work correctly with the translation, though a GC memory card may not be
   able to support saves from multiple regions on it at the same time if playing on console.
 - As to date the patch has been confirmed to boot on a standard Wii as well as a Gamecube. If you test on
   any other actual consoles, please let us know if it works for you! The game has also been confirmed
   as working on Dolphin, though users of the Android version may experience issues.
 - Any bugs present in the original game (eg, the Gaza-C capture bug) still remain in this translation. Some
   of the more common ones are listed later in this file.
 - All in-game text and graphics should be translated excluding the credits, due to the name readings
   for the staff. Some interactions may also sound a little odd due to the original JP terms, such as any
   underground units being able to "Land" to return to the surface.
 - At times the in-battle pop-ups for events like criticals may revert to the Japanese versions. This is
   a known issue, but if you are able to submit a save where this can be reproduced, please get in touch
   with the team.

--------------------------------------
Base Game Bugs
--------------------------------------
For ease of access, the following are some of the more prominent bugs in the base game that have not been
adjusted by this patch:
 - Capturing a Gaza-C in any form may cause issues where entire scenarios may be skipped. This cannot be
   fixed at this time, even after selling/scrapping the unit in question.
 - Allied pilots who only appear as sub-pilots may learn the SP Ace Bonus, but this will not be saved to
   the memory card. They will retain it for an entire play session without powering off however.
 - After joining, Bernie and Chris have a Speak command prompt that has no effect.
 - Funnel weapon range is not affected by the Newtype/Cyber Newtype pilot skills.

--------------------------------------
Changelog
--------------------------------------
v1.0.2
 - Added growth rates for playable pilots assigned the default one. This affects Shirou, Alan and female
   Akimi when selecting the Soul Saber.
 - Fixed some story text lines from the generic Dragoon pilots.
 - Adjusted one of Kouji's Mazinkaiser battle lines.
 - Fixed the Disrupt Spirit description text displaying incorrectly.
 - Added notes on some known bugs from the base game to the readme file.

v1.0.1
 - Fixed a number of typos across the battle and story text.
 - Adjusted the wording on some Spirit descriptions.
 - Adjusted some readme details to reflect new compatibility information.

v1.0
 - Initial release.

--------------------------------------
Credits & Contact
--------------------------------------
Staff:
 - Dashman: Programming, Graphics
 - Oppai Missile: Translation (Main Story, Battle Lines, Library Entries)
 - SteveO: Translation (Menus), Graphics
 - Bring Stabity: Programming, Editing
 - Arc Impulse: Programming, Graphics, Editing

Special Thanks:
 - BlackDog61, for helping get the project shifted away from emulator-specific graphics editing.
 - starseeker and the others who helped on series translations and terminology.
 - Those of you who supplied any reports on things to be fixed post-launch.
 - Everyone who read and bumped the threads throughout the years for your support!

Contact:
 - You can contact us via the game's thread on romhacking.net here with any queries or reports:
   http://www.romhacking.net/forum/index.php?topic=29971.msg392416#msg392416
 - Arc Impulse can be reached via RHDN messages as well for any issue reports:
   http://www.romhacking.net/forum/index.php?action=profile;u=69187
 - The translator can also be reached more directly via Twitter:
   https://twitter.com/OppaiMissile