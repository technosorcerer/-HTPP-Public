
 Skies of Arcadia Legends Maeson Public Release 1.49 (Internal Version 4.9A)

 Guess what: I'm still horrible with naming  rom hacks!

  The "useless" things first
  -------------------------------  
  1 - How to Install
  2 - Why the heck you did this?!
  3 - General Idea of this Hack/Mod
  4 - Version History and Notes
 
  The things that matter, I guess
  ------------------------------
  5 - How the characters are now
  6 - About enemies
  7 - Magic Changes
  8 - Supermove and Crew Member Actions Changes
  9 - Weapon & Cupil, Armor and Accessories Changes
 10 - Item and Fish Changes
 11 - Ship Equipment Changes
 12 - Drop Ship Changes
 13 - List of Beta Items rescued
 14 - F.A.Q.
 15 - Credits


 WARNING: If you've never played this game before, you may get some minor spoilers here (Mostly names, though), be careful nonetheless!

 ---------------
 How to Install:
 ---------------

 Very easy, actually. This comes as a XDelta patch, and I recommend using XDeltaGUI. 

 First get a copy of Skies of Arcadia Legends NTSC-US with this checksum:

 CRC32	23e347b6
 MD5	3e7fa5033c4a2704434fb6ba98195ecd
 SHA-1	46105320553c858f25fafc5fd357566b505a4940

 Then is as easy as to patch it like any other ROM. Get your favourite xDelta Patcher 
 (Like xDelta UI or xDeltaManager) and do as yo would patch any other game.
 	 
 It will take a while because this is not your typical Cartridge based game, but that's just the 
 only difference. After it finishes you'll have a patched ISO! After that, just boot it the way you chose,
 either using your Wii or Dolphin.

 I personally played this through Nintendont with my Wii.

 

 ---------------------------
 Why the heck you did this?!
 ---------------------------

 Short answer: Because I can/want, of course!

 Long answer...

 Skies of Arcadia was a game that I never got to play as a kid. I always heard good things about it, but I didn't own a Dreamcast at that time,
 and the Gamecube version was really, really fucking hard to find here in Spain.

 It wasn't until a few years ago that I managed to import an american version to play on my Wii, and man, I would have loved this thing growing up,
 but even now I find it's lighthearted and fun characters so refreshing compared to the silly ammounts of brooding and "trying too hard" of today.

 My only complain is that I find that the bad guys don't grow in power that much as you advance, so it feels pretty easy, even if you're under-leveled.

 In any case, something I always tend to do with games that I enjoy A LOT (Since a kid), is to ask myself of how could I give it a 
 new spin for future playthroughs. Back then I used to impose rules or challenges as a way to do it, but now that I kind of ( a very BIG Kind of) 
 understand enough to try rom hacking things, I can directly change the game itself.

 But as I looked into it, I could not only give it a new spin, but also try to improve it here and there to make this game even better.

 That way I could have a new version (Gameplay wise at least) of this game, and I could share it with others if someday I would finish it.

 And thanks to my life being absolute crap for almost a year because of personal reasons, the free time I was forced to have was used 
 to make this.
 

 ---------------------------------------------------------------
 General idea of this Hack/Mod, or whatever you want to call it:
 ---------------------------------------------------------------

 Well... Just like my attempt of a mod for Final Fantasy III (Famicom), I just wanted to mess with everything to make it feel different enough.

 This means that pretty much everything gameplay wise has suffered alterations:

-Magic is much, much more useful and powerful, and the ammount of SP costs has been modified so the player can use magic much more often
-Super Moves have been balanced here and there, to make them more or less even between the characters, and useful trhough the entire game.
-Character growth has been tweaked a bit

-Restoration/buff items have been balanced in different ways, to make healing magic more useful, and the game more challenging as they were pretty broken 
 (Same effect as magic and cheap as hell, thus making healing magic and super moves absolutely useless and could turn the game into an "Item Spam" fest)
-Fish, previously mostly useless, now have an array of effects outside of battle (Like healing mor than normal restoration items, for example). Not only 
  that, they are also a decent way to make money in the early parts of the game, trying to give the fishing aspect of the game a bigger point.
-Weapons, armors and accessories have been modified (Alongside Cupil), and accessories are less stingy with the character limitations

-The entire bestiary has been changed, with pretty much all of the enemies having improvements on their stats to make them more challenging, with their 
 special attacks being changed here and there
-Bosses are now quite a bit harder, being tougher and more dangerous, but also having minions (Or companions) helping them in most cases
-During the early parts of the game, big groups of enemies will yield a bit more Magic Experience to make fighting them a little more rewarding and learning
 magic a little bit faster

-All (But one) of the enemy ships have suffered big ammounts of changes, from stats and resistances to the power of their equipment. They are now much harder 
 and will make you pay more attention, or at least I hope so!
-Ship Equipment has been changed a bit here and there, and I also added all the ship equipment that ended being unused in the vanilla game!
-Magic Cannon attacks are also much more useful too, and most enemy ships have some weakness
-Many airship battles will reward you with equipment that they didn't have before, and much more Gold

-The White map's effect of reducing random encounters now is better, making you fight even less while trying to find those pesky discoveries, or walking
 around in dungeons. Also, you start with an accessory that is a less effective version, so you can recuce random fights until you get a proper map. 
-The Gamecube extra Boss Fights now give extra items too, so you may have a reason to fight them early


 ...In general, I guess, this aims for higher difficulty (Without being a HardType mod), while also improving what you characters can do in 
 different ways to make them still feel powerful with a lot of other modifications around that.

 

 --------------------------------
 Version History and Notes
 --------------------------------

 1.0 Initial Release
 1.1 Fixed Curia Crystal, edited Risan Spell and added an optional patch to use with Dolphin, as the emulator didn't like one boss fight.
 1.2 Fixed the drops of one optional boss fight, remade the patch to be for both Wii and Dolphin, corrected some descriptions, changed the Readme.
 1.3 Modified the ammount of Magic Exp that characters need for learning new spells.
 1.4 Modified the Magic Exp. Chart again, rectified several descriptions, made the introduction a little easier, and other small changes.


 As of 1.2, both Wii and Dolphin use the same patch. The only difference was a single Boss fight, and it's just not enough to make a different patch 
 for each, even less when each one has a size of 7MB.

 Important!!!

 As of 1.3, older save files are NOT COMPATIBLE. This means that if you want to play with 1.3, you'll have to star a new game. This is because if you
 load an old save file, your character's magic learning process won't behave as it should (Your characters could end un not learning magic).
 
 This is true for 1.4 too. It needs to start from the beginning. If the new Magic Exp chart flows right, this "starting from scratch" won't
 be needed after this version.

 

 --------------------------
 How the characters are now
 --------------------------

 There is exact data on how the super moves and spells are now, but the characters got a few edits in how their stats grow.

 About stats:

 HP    -> Hit points. I don't think you need me to explain this if you're really reading a Readme for a mod of an somewhat obscure RPG. I hope, at least.

 MP    -> Magic Points. Unlike other games, every spell in this game just costs 1 MP, it's the ammount of SP (Action points in other games) that increases.

 Power -> Increases the physical damage you will do with normal attacks and physical supermoves

 Will  -> Increases the magical damage you will deal with spells and magical supermoves.
 
 Vigor -> This acts as both your defense, and magic defense. The more you have, the less damage you get AND more resistant to poison damage you are.

 Quick -> Just any other games' speed or agility. High agility let's you attack sooner, but it's not guaranteed (Although high Quick can be a life-saver)

 Agile -> Evasion, plain and simple. 1 Point in Agile means 1% more of evasion, which is used to dodge normal attacks. 

 SP    -> Spirit Points. Each Character has an ammount of total SP, and actual SP. They are used to give commands to the characters, and each action
	  has an ammount of SP that is used. I'll put an example:
	
	  Vyse has 2 SP of a total of 4, Aika has 2 of a total of 3, and Fina has a total of 1 of 3. That's 5 out of 10. Each turn your group will get
	  5 SP, that you can use to give characters orders whatever you see fit. As you level up they grow (And the grow is fixed).

	  You can use the command Focus to give up a character's action to recover an ammount of SP equal to his "actual SP", in the example above, 	
	  Vyse would get 2.
  

 Without wasting more of your time (HA, there's a lot of text yet!), this is what you have to know about the characters themselves:

 Both Vyse and Aika have now better Will growths, and are tied at the second best place as spell casters. 
 Aika, besides de Will, now get's a little more strength, and a little more starting HP.
 Fina gets a higher growth in Will and she's still takes the first place as spell caster. Also has more starting HP and a little more Strength
 Drachma gets a little more Will and Speed
 Enrique grows more Strength and Speed
 Gilder, like Drachma, get's an increase in Will and Speed

 In short, it means that...

 Vyse and Aika are well rounded and pretty damn good at everything without being the best in every aspect. Tied for second best offensive magic users.
 Fina is pretty much a mix of your typical mages and priests. Not much strength or HP, but thankfully Cupil helps there, and her forte is magic, so...
 Drachma and Gilder are your physical guys. High HP, attack and defense, but not that great with offensive magic.
 Enrique is... Well, mixed. He has physical skills, can use magic decently and be a good healer, but he is not very fast and his defense is not the best.
 Jack of all trades, masters of none (Except airsickness, he's great at that).


 If for some reason, you want some type of table ordering them in each stat, well...

 -----------------------------------------------------------------------------
     HP		MP	  Power        Will          Vigor	Quick
 -----------------------------------------------------------------------------
  Drachma      Fina     Drachma	       Fina        Drachma       Aika
   Gilder   Enrique      Gilder     Vyse, Aika      Gilder       Vyse
     Vyse      Aika        Vyse       Enrique         Vyse	 Fina
     Aika      Vyse        Aika        Gilder         Aika     Gilder
  Enrique    Gilder     Enrique       Drachma      Enrique    Enrique
     Fina   Drachma        Fina			      Fina    Drachma
 -----------------------------------------------------------------------------
 
 There. 
 Please, have in mind that just because, for example, Fina is the last one in Attack power, doesn't mean she is useless in that regard.
 
 In fact using that example, through the use of normal attacks she & Cupil can do average to decent damage (Pretty useful for finishing 
 random monsters) and they have high hit ratio, something that for example Drachma lacks. On the other hand remember that buff/debuff/status/healing 
 magic doesn't require high Will to be useful, so if you need desperate healing, you can still use Drachma or Gilder for that.

 And that's without counting equipment, or the fact that you can get stat-increasing items, but for that read below. 

 -----------------------------------------------
 -----------------------------------------------

 -----------------------------------------------
 About Enemies
 -----------------------------------------------

 Well... Not much to say here. They are stronger, their HP is not laughable anymore (Seriously, final dungeon enemies with less than 300 hp? Damn), and 
 don't die by just looking at them... Or by Lambda Burst/Rain of Swords spam. But don't worry, random fights shouldn't be long if you take advantage of
 your own abilities and magic.

 Enemy drops have been messed around a little. Some of the most hard to get items are a little easier (If only to reduce the overleveling) too.

 Enemy abilities have been changed around as well, so previously insignificant skills may now be a little more dangerous. 
 Enemies also have more powerful magic.

 But even tougher are the bosses, which have suffered quite a few improvements. 
 And they didn't come alone, as most of them have lackeys (or companions, if it is something bigger).

 I tried to make the game at least a little more challenging without getting into the cheap "you have to luck out" feel. 

 That said, there is no need to grind at all. In my test playthroughs I was able to beat the game around Lvl 45, to give you an idea.

 But if you overlevel for some reason, well, probably the last bosses will feel a little easy. Thankfully that's why the optional bosses are there.
 You can fight them anytime once they appear, but they get stronger depending your own levels. And they were designed originally to be tougher than
 most bosses (Heck, the game also does the "The secret boss is the strongest thing form in this universe" too).

 If you want challenging fights, let them alone until you're around lvl 50/60 for their strongest points. Except the secret one, if you really want to
 give yourself headaches, he gets up to lvl 99. 

 Ludicrous. On the other hand, it's not like they're easy when you can fight them first, and they drop interesting items that you may want to take
 advantage off.
  

 -----------------------------------------------
 Magic Changes
 -----------------------------------------------


 Magic is changed around A LOT with the mindset of being something not only useful, but something you want to use through the entire game. 
 
 Offensive magic in the original game was seen as underwhelming. Not only was somewhat weak, but the cost of SP was a little too high to 
 excuse the use of magic, much less to become an ability to use often, like other games in the genre.

 ... Not anymore.

 Magic is now SP cost-efficient, and the more powerful the spell the more it takes YET it's low enough to let you use magic with several characters
 in the same round, and that balance works through the game, as you get new spells while your SP grows too...

 Also, the fourth stage of the offensive spells gets a last big boost in power. By the time you get those (If you don't grind for them), you'll be 
 on the latter parts of the game, and unlike physical supermoves, magic damage doesnt scale as much as physical (Just like in many RPGs, for some reason).

 Mostly because physical supermoves just multiply damage several times, which makes much easier to reach high damage. With that big boost, spells remain
 powerful for the last parts, and make traveling through previously explored zones easier as they will be capable of 1HKO most of the old enemies.

 The only exceptions are Nox spells. They stop at the second (Noxus), so it can't get as powerful. But still does very decent damage considering it's 
 main point was to poison enemies, and you'll only find it get behind at the end of the game.

 For Ship magic, offensive spells are miles better than in the original game. Specially Purple, which was very weak and mostly useless. Sacri spells heal
 a little more than repair and deluxe kits.

 New in 1.3 is that characters have modified Magic Exp rates. Some characters will need a bit less experience to learn new spells.
 This is very true for characters like Drachma, which was slow as molasses. Now he learns magic at a much faster rate (But he's still the slowest one).


 In any case, here are listed the changes in all magic, both on foot and ship battle.
 
 Green:
 
 Used on foot								 			Used on a Ship Battle

 Sacri	  Heals   500 HP, 1 SP, One Ally				 			Heals Ship for  5000 HP 2 SP
 Sacres	  Heals  1000 HP, 2 SP, One Ally 				 			Heals Ship for 10000 HP 4 SP
 Sacrum   Heals  1500 HP, 4 SP, All Allies		
 Sacrulen Heals 10000 HP, 6 SP, One Ally				 			Heals Ship for Full HP 6 SP 
 
 Noxi     160 Power, Green Element, 1 SP,  One Target, High Poison Chance
 Noxus    400 Power, Green Element, 3 SP, All Enemies, Moderate Poison Chance
 
 Red:  

 Used on foot										 	Used on a Ship Battle

 Pyri	 140 Power, Red Element, 1 SP, All Enemies			 			Charges a Cannon with Red Magic 120 Power 2 SP
 Pyres	 260 Power, Red Element, 2 SP, All Enemies      				 	Charges a Cannon with Red Magic 180 Power 4 SP
 Pyrum	 400 Power, Red Element, 4 SP, All Enemies      		 			Charges a Cannon with Red Magic 240 Power 6 SP
 Pyrulen 750 Power, Red Element, 5 SP, All Enemies      		 			Charges a Cannon with Red Magic 320 Power 8 SP
 
 Increm   Raise Attack/Defense, 8  SP, One Ally				 			Increases Attack & Defense of the Ship for 2 Turns  7 SP
 Incremus Raise Attack/Defense, 20 SP, All Enemies 			 			Increases Attack & Defense of the Ship for 4 Turns 12 SP
 
 Purple:
 
 Used on foot								 			Used on a Ship Battle

 Cristali  180 Power, Purple Element, 1 SP, One Target  		 			Charges a Cannon with Purple Magic 120 Power 2 SP	
 Cristales 320 Power, Purple Element, 2 SP, One Target  		 			Charges a Cannon with Purple Magic 180 Power 4 SP
 Cristalum 460 Power, Purple Element, 3 SP, One Target  		 			Charges a Cannon with Purple Magic 240 Power 6 SP
 Crystalen 900 Power, Purple Element, 4 SP, One Target  		 			Charges a Cannon with Purple Magic 320 Power 8 SP
 	
 Sylenis   Moderately High Silence Chance, 2 SP, One Target		 			Silences the crew of the enemy ship for 2 Turns	   2 Sp
 
 Panika	  Moderate chance of Confusion, 2 SP, One Target
 
 Blue:
 
 Used on foot								 			Used on a Ship Battle

 Wevli	  160 Power, Blue Element, 1 SP,  Small Area Around One Target   			Charges a Cannon with Blue Magic 120 Power   2 SP
 Wevles	  280 Power, Blue Element, 2 SP, Normal Area Around One Target   			Charges a Cannon with Blue Magic 180 Power   4 SP
 Wevlum   420 Power, Blue Element, 4 SP,    Big Area Around One Target  			Charges a Cannon with Blue Magic 240 Power   6 SP
 Wevlen   800 Power, Blue Element, 5 SP,   Huge Area Around One Target   			Charges a Cannon with Blue Magic 320 Power   8 SP
 
 Quika    Raise Speed, 7 SP, All Allies  							Increases the Quick of the Ship for 2 turns  5 SP

 Slipara  Moderate Sleep Chance, 4 SP, All Enemies

 Yellow:

 Used on foot										         Used on a Ship Battle

 Electri   170 Power, Yellow Element, 1 SP, Affects All between Caster & Target,  Small Width   Charges a Cannon with Yellow Magic 120 Power 2 SP
 Electres  290 Power, Yellow Element, 2 SP, Affects All between Caster & Target, Normal Width   Charges a Cannon with Yellow Magic 180 Power 4 SP
 Electrum  440 Power, Yellow Element, 4 SP, Affects All between Caster & Target,    Big Width   Charges a Cannon with Yellow Magic 240 Power 6 SP
 Electren  850 Power, Yellow Element, 5 SP, Affects All between Caster & Target, Bigger Width   Charges a Cannon with Yellow Magic 320 Power 8 SP
 
 Driln     High Chance of Weaken,     4 SP, One Target						Reduces At. & Def. to enemy ship for 2 Turns 3 SP
 Drilnos   Moderate Chance of Weaken, 8 SP, All Enemies 					reduces At. & Def. to enemy ship for 4 Turns 6 SP

 Silver:

 Curia	   Heals every status effect besides Unconscious, 1 SP

 Risan	    85% Chance of Reviving an Ally with  50% HP, 3 SP
 Riselem   100% Chance of Reviving an Ally with 100% HP, 6 SP

 Eterni    460 Power, Silver Element,  3 SP,  One Target, Removes beneficial effects on target **
 Eternes   400 Power, Silver Element,  4 SP, All Enemies, Moderate Chance of Stone **
 Eternum   900 Power, Silver Element, 10 SP,  One Target, 100% Chance of Instant Death unless Inmune, if Imnune, does damage


 ** Eterni and Eternes are now Silver elemental attacks. The 1HKO effect was seen as useless by many, and many monsters were resistant to it, so 
    I decided to make it plain damage with special effects, making them much more useful and a way to do neutral magic damage (Well, to all except 
    Yellow enemies, which will receive more, and Silver ones will resist it) if you don't have anything better (Although they do pretty good damage).

    These spells are still 1HKO moves if used by enemies. The chances are lower than in vanilla, but watch out!
 
 ----------------------------------------------

 How each Element reacts to the others:

 Each enemy has an element (Or Color) asociated to them. Your charactes will always have an element asociated to their attacks, 
 and defensively speaking, they are neutral to all elements unless wearing protective gear that gives them resistance to some element.

 Elements are a rather important part of the game because how much control you have over it, and in this mod, they work like these:


  Defense>     Green	Red   Purple   Blue  Yellow  Silver
 ---------------------------------------------------------
O  Green        100%    80%    120%   120%    80%    100%
F  Red          120%    50%    140%    80%   100%    100%
F  Purple        80%   140%     50%   120%   100%    100%
E  Blue          80%   120%     80%   100%   120%    100%
N  Yellow       120%   100%    100%    80%    80%    120%
S  Silver       100%   100%    100%   100%   120%     80%
E

 This means that Green enemies will resist Purple and Blue, and they are weak against Red and Yellow, for example.
 Also, even if it's "only" 20% more damage, it makes a big difference when you play around with the elements to your advantage, even more remembering
 that in the original game you just got 10% extra damage for taking advantage of a weakness (And it was only reduced 10% too).

 And, of course, this works for normal attacks, magic, and supermoves all the same. 
 Also, there are a few enemies that may react in a different way, but for the vast majority, that chart will be true.

 ...One last thing: Enemy Ships also had their resistances changed, so they may resist some elements and be weak to others.
 That, alonside the changes in magic, will make the Magic Cannon something useful during the entire game instead of just in the 
 beginning, like some people seem to feel with the original game.

 ----------------------
 Magic Experience Chart
 ----------------------
 
 Vyse    Lv1   Lv2      Lv3     Lv4     Lv5     Lv6
 ---------------------------------------------------
 Green    8 	36 	120 	240 	500 	1100
 Red      4 	36 	100 	231 	468 	856
 Purple  10	50 	140 	300 	660 	1200
 Blue     8	36 	108 	258 	530 	940
 Yellow   9 	40 	110 	300 	600 	1100
 Silver  20 	90 	270 	660 	950 	1800
 
 Aika   Lv1   Lv2      Lv3     Lv4     Lv5     Lv6
 ---------------------------------------------------
 Green 	 4 	27 	75 	174 	375 	720
 Red	 8 	45 	122 	320 	660 	1150
 Purple	 8 	34 	100 	235 	470 	870
 Blue	 8 	36 	116 	270 	555 	970
 Yellow	10 	45 	125 	330 	650 	1170
 Silver	18 	75 	230 	540 	820 	1600

 Fina   Lv1   Lv2      Lv3     Lv4     Lv5     Lv6
 ---------------------------------------------------
 Green	 2 	20 	52 	140 	300 	500
 Red	 6 	34 	99 	250 	500 	920
 Purple	 7 	33 	93 	225 	450 	830
 Blue	 7 	32 	95 	220 	440 	800
 Yellow	 7 	34 	100 	240 	500 	920
 Silver	11 	48	140 	340 	685 	1250

 Drachma Lv1   Lv2      Lv3     Lv4     Lv5     Lv6
 ---------------------------------------------------
 Green	12 	55 	200 	350 	700 	1300
 Red	10	55 	180 	360 	800 	1400
 Purple	14 	65 	210 	440 	800 	1500
 Blue    8 	40 	150 	310 	620	1000
 Yellow	13 	70 	180 	500 	820 	1350
 Silver	35 	130 	350 	780 	1100 	2000

 Enrique Lv1   Lv2      Lv3     Lv4     Lv5     Lv6
 ---------------------------------------------------
 Green	 7 	33 	93 	220 	450 	800
 Red	11	45 	120 	270 	540 	976
 Purple	 8 	35 	102	245 	500 	930
 Blue	11 	44 	116	260 	545 	940
 Yellow  8 	30 	80 	175	340 	600
 Silver	14 	70	220 	530 	800 	1550

 Gilder Lv1   Lv2      Lv3     Lv4     Lv5     Lv6
 ---------------------------------------------------
 Green  10 	50	180 	350 	700 	1250
 Red	12	50	142	330 	670 	1228 
 Purple 12 	50 	140	320 	640 	1170
 Blue	12 	50 	155 	340 	720 	1150
 Yellow 15 	63 	174 	399 	801 	1461
 Silver 30 	130 	330 	760 	1050 	1950

 -----------------------------------------------
 -----------------------------------------------

 -----------------------------------------------
 Supermoves and Crew Member Action Changes
 -----------------------------------------------

 Vyse

 Cutlass Fury	 X3.5 Normal Damage,    7 SP, One Target
 Pirate's Wrath  X6.0 Normal Damage,   14 SP, One Target

 Rain of Swords  X2.4 Normal Damage,   10 SP, All Enemies

 Counterstrike   Counter Attack Effect, 1 SP, Casted on Vyse 
 Skull Shield    Counter and Protect,   4 SP, All Allies


 Aika

 Alpha Storm     280 Power, 4 SP, All Enemies, Element of your Weapon
 Lambda Burst    230 Power, 3 SP, All Enemies, Red Element Only
 Omega PSyclone  450 Power, 5 SP, All Enemies, Red Element Only

 Delta Shield	 Blocks ALL Magic aimed to the Team, 4 SP

 Epsilon Mirror  Restores 10 MP, 7 SP, Casted on Aika


 Fina

 Lunar Glyph     240 Power, Silver Element, 1 SP, One Target, Moderately High Chance of Stone
 Lunar Winds     400 Power, Silver Element, 4 SP, All Enemies, Removes Good Status Effects

 Lunar Blessing  Regenerates 300 HP per turn,            6 SP, All Allies
 Lunar Cleansing Heals all Status besides Unconscious,   5 SP, All Allies
 Lunar Light     Heals and Revives The Team to Full HP, 18 SP, All Allies


 Drachma

 Tackle		x4.0 Normal Damage,  8 SP, One Target
 Hand of Fate   x7.5 Normal Damage, 18 SP, One Target, 100% Chance of Instant Death if not inmune 

 Spirit Charge	Defense and Double SP Regen, 0 SP, Casted on Drachma


 Gilder

 Gunslinger	x2.6 Normal Damage, 10 SP, Area Surrounding One Target
 The Claudia    x3.3 Normal Damage, 15 SP, All Enemies 

 Aura of Denial  Creates a Barrier against Status Effects, 3 SP, All Allies


 Enrique

 Royal Blade     x3.5 Normal Damage,  7 SP, One Target
 The Judgement   x6.0 Normal Damage, 14 SP, One Target

 Justice Shield  Reduces Physical Damage by 50% for that turn, 6 SP, All Allies

 
 The Entire Team (All must be alive)

 Blue Rogues	Your crew will attack or help you depending on each active crew member, Maximum PS, All Allies/All Enemies
 Profecy	Combined attack of the four characters,				      , Maximum PS, All Allies/All Enemies


 -------------------
 Crew Member Actions
 -------------------

 (P) Pasive	(A) Active
 
 Lawrence (P)	Increases Quick by 35
 Don      (P)	Increases Dodge by 18%

 Brabham  (P)	Increases Defense by 25
 Hans	  (P)	Increases M.Defense by 25

 Belle	  (P)	Increases Secondary Cannon damage by 60
 Khazim	  (P)	Increases Main Cannon damage by      40
 
 TikaTika (P)	Increases Torpedo Accuracy to 80%
 Dominguo (A)	Increases Chance of Critical Damage 5 SP
 
 Osman		Finds secret item drops at the end of a Ship battle (Not the same as Kalifa)
 Kalifa 	Finds secret item drops at the end of a Ship battle (Not the same as Osman)
 
 Izmael   (P)	Increases the power of the Moonstone Cannon by 100
 Kirala	  (A)   Restores the Ship HP to 100%

 Polly	  (A)   Restores 10 MP to a Character 4 SP
 Uralla   (A)   Maxes out SP 15 SP

 Ryu-Kan  (A)   Raises Attack & Defense for 1 round 15 SP
 Ylchimis (A)   Raises All stats for 1 round 10 SP

 Marco 	  (A)   Doubles the restore rate of SP for one round 6 SP
 Robinson (A)   Halves the comsumption of SP for one round  6 SP

 Pow      (A)   Increases chance of attacking First
 Merida   (P)   Increases the Quick of the ship by 15*

 Moegi    (A)   Blocks all magic damage for 1 round    12 SP
 Pinta    (A)   Blocks all physycal damage for 1 round 12 SP

 Remember, you can only use an active command once per battle.

 *Merida no longer gives Value to the ship.
 -----------------------------------------------
 -----------------------------------------------

 --------------------------------------------
 Weapon & Cupil Changes
 --------------------------------------------
 
 Not much to say here. I changed weapons around a little. There are more status effects, some characters got a boost in their weapons and I also added a
 new effect to each weapon.

 There is space in the code for an extra bonus effect, and it's used very, very little. Originally, it was to add Elemental resistance to a few weapons,
 and curiously enough I haven't seen this being said in guides (although I may be wrong). I used it to make each weapon a little more interesting.
 
 Also, remember you can change your equipment (Not only weapon!) in the middle of a battle!

 Oh, a last note: If something gives bonus Vigor, it means it gives both Defense and Magic defense.

 Vyse:
+-------------------------------------------------------------+
|Name		 Attack	 Hit  Status Eff.   Extra Effect      |
+-------------------------------------------------------------+
 Cutlass	   20     90  Nothing	    Nothing
 Pirate Cut.	   33     90  Silence	    Quick  +5
 Sky Cutlass	   45     90  Nothing	    Vigor  +5
 Assassin B.	   58     90  Poison	    Will   +5
 Nasr Cutlass	   70     95  Nothing	    First Strike Chance 10%
 Hunter's Sword	   87     90  Confusion	    Confusion Resistance
 Stonecutter	  100     95  Silence	    Stone Resistance
 Iron-Cutter	  112     90  Nothing	    Weaken Resistance
 Sword of Daccat  120     90  Sleep	    Causes enemies to Flee
 Admiral Cutlass  128     90  Nothing	    Vigor +10
 Dream Cutlass    137     90  Nothing       Blue Resistance
 Suiran Blade	  141     95  Nothing	    Will  +10
 Windslicer	  155     90  Poison	    Quick +10
 Thunder Cutlass  165     95  Nothing	    Yellow Resistance
 Soul sword	  178     90  Death	    Dodge +10
 Vorlik Blade	  210     90  Nothing	    Silver Resistance
 Tuna Cutlass	  160     90  Sleep	    Will +15
 Sky Fang	  255    224  Nothing	    Nothing (It's already the best non-Cupil weapon, so whatever)
 -------------------------------------------------------------
 
 Aika;

+-------------------------------------------------------------+
|Name		 Attack	 Hit  Status Eff.   Extra Effect      |
+-------------------------------------------------------------+
 Boomerang	   20    110  Nothing	    Nothing
 L. Crescent	   30    110  Sleep	    Dodge +5
 Throwing Blade    40    120  Nothing       Will  +5
 Valuarang	   50    110  Nothing	    Vigor +5
 Scout Wing	   60    110  Sleep	    Sleep Resistance
 Dancing Arc	   68    120  Nothing	    Silence Resistance
 Storm Wing	   80    110  Weaken	    Blue Resistance
 Hunting Arc	   93    110  Nothing       Will  +10
 Grendel Wing	  112    130  Nothing	    Green Resistance
 Skywing	  120    110  Nothing	    Quick +10
 Wing of Hope	  131    120  Nothing	    Confusion Resistance
 Yin Wing	  142    110  Sleep	    Dodge +10
 Ice Splitter	  157    120  Nothing	    Purple Resistance
 Flutter Blade	  165    110  Confusion	    Vigor +10
 Moon Wing	  175    120  Stone	    Silver Resistance
 Hydra Wing	  200    115  Nothing	    Quick +15   
 Swirlmerang      155    180  Confusion	    Will  +15
 -------------------------------------------------------------
 
 Drachma:

+-------------------------------------------------------------+
|Name		 Attack	 Hit Status Eff.   Extra Effect       |
+-------------------------------------------------------------+
 Artificial Arm    50    80  Nothing	   Vigor   +5
 Hook Hand	   58    80  Silence       Poison Resistance
 Beak Hand	   66    80  Confusion     Quick   +7
 Excavation Arm    75    80  Stone	   Will    +10
 Mace Hand	  130    40  Nothing	   Defense +12
 De Loco Drill	  100    80  Death	   Resist Confusion
 Ruin Arm	  115    85  Nothing	   Stone Resistance
 Mining Arm	  180    80  Stone	   Dodge +8
 Dragon Arm	  230    80  Nothing	   Vigor +15
 Silver Arm	  205    85  Sleep	   Silver Resistance
 -------------------------------------------------------------
 
 Gilder:

+-------------------------------------------------------------+
|Name		 Attack	 Hit  Status Eff.   Extra Effect      |
+-------------------------------------------------------------+
 Gilder's Own     110    100  Nothing	    Quick +5
 Nasr Pistol	  118    100  Confusion	    Red Resistance
 Daccat Custom	  127    100  Sleep	    Dodge +7
 MarksMan Gun     100    200  Death	    Will  +10
 Valuan Pistol	  175    110  Weaken	    Yellow Resistance
 Gilder Special   188    100  Silence	    Vigor +10
 Warrior Pistol	  205    105  Nothing       Dodge +12
 -------------------------------------------------------------
 
 Enrique:

+-------------------------------------------------------------+
|Name		 Attack	 Hit  Status Eff.   Extra Effect      |
+-------------------------------------------------------------+
 Rapier		  127     95  Silence	    Quick +5
 Blade of Slumb.  143    100  Sleep	    Will  +10
 Frostblade	  157     95  Confusion	    Purple Resistance
 Imperial Blade	  168     95  Silence	    Vigor +10
 Stoneblade	  185     95  Stone	    Stone Resistance
 Serpent Strike	  200     95  Stone	    Quick +15
 -------------------------------------------------------------

 Fina & Cupil: 

+-----------------------------------------------------------------------------------------------------
|Name		 Attack	  Hit  Status Eff.  Extra Effect       	0 Abirik Chams Route - Focus on Hit
+-----------------------------------------------------------------------------------------------------
 Cupil    	    65    120  Nothing	    Nothing
 Blade  	    75    125  Sleep        Quick +5
 Cone        	    80    125  Weaken       Vigor +5
 Sword       	    95    125  Sleep	    Dodge +5
 Star       	   110    130  Silence      Will  +10
 Cutlass           130    130  Sleep        Dodge +12
 Spear             155    130  Poison       Quick +12
 Claymore          175    130  Sleep	    Will  +15
+-----------------------------------------------------------------------------------------------------
|Name	 	 Attack	  Hit  Status Eff.  Extra Effect	 1 Abirik Cham Route - Focus on Attack
+-----------------------------------------------------------------------------------------------------
 Cannon     	   100    105  Weaken	    Quick +7
 Club       	   115    110  Confusion    Vigor +7
 Lance      	   130    110  Silence	    Dodge +7
 Spike      	   150    105  Confusion    Will  +12
+-----------------------------------------------------------------------------------------------------+
|Name	 	 Attack	  Hit  Status Eff.  Extra Effect	 2 Abirik Cham Route - Focus on Attack|
+-----------------------------------------------------------------------------------------------------+
 Hammer     	   130    120  Stone 	    Vigor +10
 Pan        	   145    120  Confusion    Dodge +10
 Weight     	   190    110  Confusion    Vigor +15
+----------------------------------------------------------------------------------------------------+
|Name	 	Attack	  Hit Status Eff.   Extra Effect         3 Abirik Cham, 30 Chams             |
+----------------------------------------------------------------------------------------------------+
 Final      	   350   110  Nothing       (Nothing, It's already the most powerful weapon)
  
 
 Chart of Transformations (No changes here, but added for the sake of completion)
 
   Cupil 00/0
   |
   Cupil Blade    02/0 ->->->- Cupil Canon 02/1
   |		               |
   Cupil Cone     04/0         Cupil Club  08/1->-->-->-->--
   |			       |                           |
   Cupil Sword    08/0         Cupil Lance 12/1->->->->->->->->->->->->-> Cupil Pan    12/02    
   |                           |			   |		  |
   Cupil Star     12/0         Cupil Spike 16/1    Cupil Hammer 08/2	  Cupil Weight 24/02
   |			       |  |	                   | 		  |
   Cupil Cutlass  16/0         |  ---<---<---<---<---<---<--              |
   |		 	       |					  |
   Cupil Spear    20/0 -<-<-<--- 					  |
   |									  |
   Cupil Claymore 24/0 							  |
   |									  |
   ->--->--->--->--->--->--->--->--->--->--->--->--->--->--->--->--->---> Final Cupil  30/3
 
 -------------------------------------------------------

 -------------
 Armor Changes
 -------------

 Not many changes here, just a bit of extra effects and some ajustments. Some prices were changed too.

  Men Clothes
 +----------------------------------------------------------------------------------------------------+-------------+
 |Name	 	       Defense    M.Defense           Effect 1		        Effect 2	      |	V A F D G E |
 +----------------------------------------------------------------------------------------------------+-------------+
  Drachma's Shirt	    45           42           ---	                ---			X X X O X X
  Heavy Armor   	    58           53           ---			---			O X X O O O
  Flame Mantle		    75		 70           Red resistance		---			O O O O O O
  Miner's Overalls	    90		 80           Stone Resistance		---		        O X X O O O
  Nasr Uniform		   104		 96	      ---			---		        O X X O O O
  Scale Mail		   141	        130           ---			---			O X X O O O
  Vengeance Armor	   165		150           Counter Attack 20%        ---			O X X O O O
  Berzerker Mail	   150		150	      Attack +20		Hit +20			O O O O O O		
 --------------------------------------------------------------------------------------------------------------------

  Women Clothes
 +----------------------------------------------------------------------------------------------------+-------------+
 |Name	 	       Defense    M.Defense           Effect 1		        Effect 2	      |	V A F D G E |
 +----------------------------------------------------------------------------------------------------+-------------+
  Aika's Shorts		    19		 21 	      ---			---			X O O X X X
  Mystic Dress	            42           50           Weak Resistance		---			X O O X X X
  Female Armor              92           99           ---			---			X O O X X X
  Maiden's Armor	   103		112	      ---			---			X O O X X X
  Moonlight Robe           134	        145           Dodge +20			---			X O O X X X
  Swift Dress              155          170           Quick +20			---			X O O X X X
  Light Dress		    70           70           Dodge +30			Quick +30		X O O X X X
  Focus Robe		    70           70           Will +100			---			X O O X X X
 --------------------------------------------------------------------------------------------------------------------

  Sailor Outfits
 +----------------------------------------------------------------------------------------------------+-------------+
 |Name	 	       Defense    M.Defense           Effect 1		        Effect 2	      |	V A F D G E |
 +----------------------------------------------------------------------------------------------------+-------------+
  Vyse's Uniform	    20		 20	      ---			---			O O X X O X
  Valuan Uniform	    33		 33 	      ---			---			O O X O O X
  Sailor Uniform	    45 		 45 	      Quick +5			---			O O X O O X
  Raincoat		    56	         56	      Blue Resistance		---			O O X O O X
  Daccat's Armor	   108          108           Sleep Resistance          ---			O O O O O O
  Naval Uniform		   112          112           ---                       ---			O O X O O X
  Ghost Mail		   128          128           --- 			---			O O X O O X
  Soranchu Robe		   136          136           ---			---			O O X O O X
  Captain Cloak 	   148          148           Will +25			---			O O O O O O	
  Gaia Cape		   168		168           Will +40                  ---			O O O O O O 
 --------------------------------------------------------------------------------------------------------------------

  Regal Dress
 +----------------------------------------------------------------------------------------------------+-------------+
 |Name	 	       Defense    M.Defense           Effect 1		        Effect 2	      |	V A F D G E |
 +----------------------------------------------------------------------------------------------------+-------------+
  Agile Robe		    65           70	      Hit +10			Dodge +5		X X O X X O
  Light Coat		   103	 	113	      Hit +10			Dodge +5		X X O X X O
  Enrique's Coat	   120		130	      Hit +10			Dodge +5		X X O X X O
  Moss Armor		   126		140           Hit +20			Dodge +10		X X O X X O
  Long Robe 		   130          145           Hit +20			Dodge +10		X X O X X O
  Blessed Robe		   142		160	      Hit +25			Dodge +15		X X O X X O
  Robe of Faith		   161		180           Hit +25			Dodge +15		X X O X X O
 --------------------------------------------------------------------------------------------------------------------

  Armor
 +----------------------------------------------------------------------------------------------------+-------------+
 |Name	 	       Defense    M.Defense           Effect 1		        Effect 2	      |	V A F D G E |
 +----------------------------------------------------------------------------------------------------+-------------+
  Valuan Armor		    52		 45	      ---			---			O X X O O X
  Ceramic Armor		    75           65           Dodge +5			---		    	O X X O O X
  Golden Armor		    90		 77	      Attack +5			---			O X X O O X
  De Loco Mail		    99 		 84	      ---			---			O X X O O X
  Caravan Armor		    75		 75	      Red Resistance		Purple Resistance	O O O O O O
  Gilder's Mail		   116		100	      Hit +10			---			O X X O O X
  Battleworn Armor	   133		114	      ---			---			O X X O O X
  Fiber Mail		   165		140	      Attack +10	        ---			O X X O O X
  Plated Armor		   181		154	      ---			---			O X X O O X
 --------------------------------------------------------------------------------------------------------------------

  Magic Garment
 +----------------------------------------------------------------------------------------------------+-------------+
 |Name	 	       Defense    M.Defense           Effect 1		        Effect 2	      |	V A F D G E |
 +----------------------------------------------------------------------------------------------------+-------------+
  Light Robe		    30		 37	      Will +5			---			X O O X X O
  Fina's Robe		    55	 	 65 	      ---			---			X O O X X O
  Ancient's Robe	    69		 82	      ---			---			X O O X X O
  Fiber Robe		    75 		 95	      Will +10			---			X O O X X O
  Holy Robe		    92		108	      ---			---			X O O X X O
  Miracle Robe		   114		133	      ---                       ---			X O O X X O
  Moon Robe		   140		165	      Will +10			---			X O O X X O
  Robe of Truth		   154          181           ---			---			X O O X X O
 --------------------------------------------------------------------------------------------------------------------

  General Clothing
 +----------------------------------------------------------------------------------------------------+-------------+
 |Name	 	       Defense    M.Defense           Effect 1		        Effect 2	      |	V A F D G E |
 +----------------------------------------------------------------------------------------------------+-------------+
  Elastarmor		    54		 54	      Yellow Resistance		---			O O O O O O
  Nasrean Mail		    66           66           Red Resistance		---			O O O O O O
  Nasr Combat Mail	    66           66           Attack +5			Will +5			O O O O O O
  Victory Mail	 	    90		 90	      Attack +5			Will +5			O O O O O O
  Ixa'takan Armor	   109		109	      Green Resistance		---			O O O O O O
  Daccat's Tunic	   121          121           Blue Resistance		---			O O O O O O
  Insulated Mail	   145		145	      Purple Resistance		---			O O O O O O
  Silver Armor		   160		160           Silver Resistance		---			O O O O O O
 --------------------------------------------------------------------------------------------------------------------

 -------------------
 Accessories Changes
 -------------------

 I took the liberty to reorganize the order of the items in the menu to make them easier to look through, (That is, when pushing Y while on the 
 item screen, each group would be organized by name, or by it's internal code number). The order is the one in these lists. 

 Just like the others, some prices were changed.

  Rings
 +--------------------------------------------------------------------------------------+--------------+
 |Name	 	        Effect1         Effect2         Effect3         Effect4         | V A F D G E  |
 +--------------------------------------------------------------------------------------+--------------+
  Meditation Ring	Will    +8	---		---		---		  O O O O O O
  Lover's Ring		Will   +12	M.Def   +12	---		---		  O O O O O O
  Moondust Ring		Will   +45	M.Def   +10     ---		---		  O O O O O O
  Jade Swirl Ring	Will   +40      M.Def   +40     ---		---		  O O O O O O
  Gemstone Ring		M.Def  +22	---		---		---		  O O O O O O
  Prophet's Sand        M.Def  +65      Will    +10	---		---		  O O O O O O
  Cupil Ring		Will  +100      M.Def  +100	Death Resist.   Silver Resist.    X X O X X X
  Warrior's Heart	Spirit Recov.   Attack  +10	Will  +10	---		  O O O O O O
  Fortune Ring		Dodge +100 	Defense +10     ---		---		  O O O O O O		
 ------------------------------------------------------------------------------------------------------

  Braceletes
 +--------------------------------------------------------------------------------------+--------------+
 |Name	 	        Effect1         Effect2         Effect3         Effect4         | V A F D G E  |
 +--------------------------------------------------------------------------------------+--------------+
  Throkyryn's Scale     Attack  +10     ---	        ---	       ---		 O O O O O O
  Thryllak's Scale      Attack  +40     Defense  +10    ---	       ---		 O O O O O O
  Vigoro's Chain        Attack  +25     Hit      +30    ---	       ---		 O O O O O O
  Marocca's Shell       Defense +10     ---	        ---	       ---		 O O O O O O 
  Burocca's Shell       Defense +40     Attack   +10    ---	       ---		 O O O O O O
  Defensive Aura        Defense +40     Invulnerable    ---	       ---		 O O O O O O
  Crylhound's Claw      Hit     +30     Attack    +5    ---	       ---		 O O O O O O
  Hunter's Hand	        Hit     +45     Attack   +10    ---            ---		 O O O O O O
  Thief's Aura	        Dodge   +13     Defense   +5    ---	       ---		 O O O O O O
  Quetya Feather        Dodge   +25     Defense  +10    ---	       ---		 O O O O O O  
  The Unseen Hand	Dodge   +10     Quick    +30    ---            ---		 O O O O O O
  Sailor's Buckler      Defense +15     M.Def.   +15    Dodge   +15    ---		 O O O O O O
  Warrior's Rune        Attack  +15     Defense  +10    Hit     +20    Dodge   +10       O O O O O O 
  Ancient Bracer        Attack  +25     Defense  +20    Hit     +40    Dodge   +20       O O O O O O
  Counter Bracer        Attack  +20     Hit      +20    Counter +20     ---		 O O O O O O 
 ------------------------------------------------------------------------------------------------------

  Stones
 +--------------------------------------------------------------------------------------+--------------+
 |Name	 	        Effect1         Effect2         Effect3         Effect4         | V A F D G E  |
 +--------------------------------------------------------------------------------------+--------------+
  Ivy Band		Defense +10     M.Def.   +10    Poison  Resist. Green   Resist.   O O O O O O
  Eye of Truth	  	Defense +10     M.Def.   +10    Confus. Resist. Red     Resist    O O O O O O
  Revered Voice		Defense +10     M.Def.   +10    Silence Resist. Purple  Resist    O O O O O O
  Wind Gem Ring		Defense +10     M.Def.   +10    Sleep   Resist. Blue    Resist.   O O O O O O
  Behemoth's Ring	Defense +10     M.Def.   +10    Weak    Resist. Yellow  Resist.   O O O O O O
  Silvite Ring		Defense +10     M.Def.   +10    Death   Resist. Silver Resist.    O O O O O O
  Everlasting Gem	Defense +15     M.Def.   +15    Fatigue Resist. ---               O O O O O O
  Gem of Fluidity	Defense +15     M.Def.   +15    Stone   Resist. ---	          O O O O O O
  Chance Ring		Defense +75     M.Def.   +75    Can't Resist Status Effects	  O O O O O O
  Constitution Gem	Defense +15     M.Def.   +15    Resists All Status.		  O O O O O O
 ------------------------------------------------------------------------------------------------------

  Headgear
 +--------------------------------------------------------------------------------------+--------------+
 |Name	 	        Effect1         Effect2         Effect3         Effect4         | V A F D G E  |
 +--------------------------------------------------------------------------------------+--------------+
  Mage's Bane		Attack   +5	Will      +5    Defense  +5	M.Def  +5 	  O O O O O O
  Blue Rogue Patch	Attack  +20     Will     +20    Defense +20     M.Def +20 	  O O O O O O 
  Nomadic Veil		Defense +12	M.Def    +12    ---		---		  O O O O O O
  Radiant Fur		Defense +30     M.Def    +30    Counter 15%	---		  O O O O O O
  Sand Storm Ring       Attack  +10     Will     +10    ---		---		  O O O O O O
  Skull Cap		Attack  +25     Will     +25    ---		---		  O O O O O O
  Assassin Ring		Hit     +40     First Strike    ---		---		  O O O O O O
  Nocturnal Sight	Hit     +60     Attack   +15    Will    +15     ---		  O O O O O O
  Critical Vision       Hit     +50     Attack   +20	Will	+20     ---		  O O O O O O
  Stealth Ring		Run Away	Quick    +15    Dodge   +10     ---		  O O O O O O
  Crescent Amulet	Quick   +20     Defense  +30    M.Def   +30     ---		  O O O O O O
  Dhabu Hide		Quick   +50     Attack   +10    Will    +10	---		  O O O O O O
  Ominous Mask		SP No Recovery  Attack   +75    Defense +75     ---		  O O O O O O
  Captain's Hat		Attack  +80	---		----		---		  O O O X X X 
 ------------------------------------------------------------------------------------------------------

  Pipes
 +--------------------------------------------------------------------------------------+--------------+
 |Name	 	        Effect1         Effect2         Effect3         Effect4         | V A F D G E  |
 +--------------------------------------------------------------------------------------+--------------+
  Gem of Purity		Defense +10     Low Resitance to all Status			  X X X O O O 
  Immunity Ring		Defense +20	Medium Resistance to all Status			  X X X O O O
  Shard of Purity	Defense +40     High Resistance to all Status			  X X X O O O
 ------------------------------------------------------------------------------------------------------

  Special
 +--------------------------------------------------------------------------------------+--------------+
 |Name	 	        Effect1         Effect2         Effect3         Effect4         | V A F D G E  |
 +--------------------------------------------------------------------------------------+--------------+
 *Skyseer Goggles*	Hit      +5	Lower Random Encounters		---		  O X X X X X 
  Flash Ribbon		Quick    +5	Dodge +3	--- 		---		  O O O O O O
  Black Eyepatch	Attack   +8     Counter +15     ---		---		  O O O O O O
  Silver Veil		Will    +16	M.Def.  +16	---		---		  O O O O O O
  Gilder's Amulet	Defense +12	M.Def.  +12     Attack  +12	Will  +12	  O O O O O O
  Imperial Crest	Defense +25	M.Def.  +25     ---		---		  O O O O O O
  Valuan Medallion	Defense +30     M.Def.  +30     Death Resist.			  O O O O O O  
  Thermo Ring		Red Resist.	Purple Resist.	Quick   +10 	Will  +10 	  O O O O O O
  Slayer Ring		Will	+12	Defense +10	Hit 	+15	Quick +10	  O O O O O O
  Mesh Tights 		Attack +40	Will  +40       ---		---		  O O O X X X
  Black Map		First Strike +  Double Random Encounters 	Enemies Run Away  O X X X X X
  White Map		First Strike -  Lower Random Encounters More    You Run Away 100% O X X X X X
 ------------------------------------------------------------------------------------------------------

 The Skyseer Goggles have been "promoted" to be a lighter version of the White map. I made so because some people feel that SOA has a very high
 encounter ratio (and the Dreamcast version was crazy with it, honestly). The GC version (The one you're going to use for this mod) has reduced 
 the ammount of encounters, but some may think it could be lower, mostly because they can get annoying while looking for discoveries and such.

 Because you take some time to get a White Map (Although in the GC version you can get one MUCH, MUCH EARLIER than in the Dreamcast version),
 I thought that giving you an item to reduce encounters from the beginning, if you so desire, was a neat idea. 

 The effect of the Skyseer Goggles is not as strong as the White Map, but it will be enough to proof useful until you get the proper item.
 Because of this, I had to make it "Vyse-Only", which is not much of a loss, really...

 Vyse starts with it equipped, so if you want you can remove it the moment you gain control of the game at the beginning. Also, don't be a douche and sell
 it, because you can't get another one.

 -----------------------------------------------
 -----------------------------------------------

 -----------------------------------------------
 Items & Fish Changes
 -----------------------------------------------

 If you don't see it here, it probably didn't get any changes (Or just the price).
 But in any case dont worry, all items have updated descriptions to reflect whatever
 they had changed!

 Also remember, fish are items only usable outside of battle!

 -----------------------------------------------
 Restorative Items
 ---------------------------------------------------------------
 Name             Effect		         Price/Reselling %
 ---------------------------------------------------------------
 Sacri Crystal	  Restores  300 HP		   20 Gold, 50%
 Sacres Crystal   Restores  700 HP		  150 Gold, 50%
 Sacrum Crystal   Restores  800 HP All Allies	  700 Gold, 50%
 Sacrulen Crystal Restores Full HP		 2000 Gold, 50%
	
 Magic Droplet	  Restores    1 MP		   60 Gold, 50%
 Magic Dew  	  Restores   10 MP		  800 Gold, 50%
 Kabal Skewer     Restores   20 MP               1500 Gold, 50%
 Mom Skewer	  Restores Full MP		  200 Gold,100%
 Ilchymix	  Restores Full MP All Allies    --------------

 Risan Crystal	  50% Resurrection, 50% HP        750 Gold, 50%
 Riselem Crystal  100% Resurrection, 100% HP     2000 Gold, 50%
 
 Curia Crystal	  Restores from Status Effects  

 Healing Salve	  Regen. Effect, 250HP 1 Char.    500 Gold, 50%

 Urala's Lunch    Heals Full HP and MP		  200 Gold,100%
 Polly's Special  Heals Full HP and MP		  200 Gold,100%
 ---------------------------------------------------------------
 Other Items
 ---------------------------------------------------------------
 Name             Effect		         Price/Reselling %
 ---------------------------------------------------------------
 Paranta Seed	  Permanent increase Power +5	10000 Gold,  1%
 Icyl    Seed	  Permanent increase Will  +5   10000 Gold,  1%
 Zaal    Seed     Permanent increase Vigor +5   10000 Gold,  1%
 Dexus   Seed     Permanent increase Agile +1   10000 Gold,  1%
 Sylph   Seed     Permanent increase Quick +5   10000 Gold,  1%
 Vidal   Seed     Permanent increase HP    +50  10000 Gold,  1%
 Magus   Seed     Permanent increase MP    +5   10000 Gold,  1%
 Tropica	  Permanent increase HP    +200  1000 Gold,100%
 ---------------------------------------------------------------
 Battle Buffing Items
 ---------------------------------------------------------------
 Name             Effect		         Price/Reselling %
 ---------------------------------------------------------------
 Glyph of Might	  Increases stats 1 Character	 8000 Gold, 50%
 Glyph of Speed	  Increases Speed On Team	 4000 Gold, 50%
 -----------------------------------------------
 Ship Restorative Items
 ---------------------------------------------------------------
 Name             Effect		         Price
 ---------------------------------------------------------------
 Repair Kit	  Restores 4000 HP to the Ship    150
 Deluxe Kit	  Restores 8000 HP to the Ship    350
 Complete Kit	  Restores 30,000 HP to the Ship 2000
 Gear Grease	  Increases SP 			 3000
 Apa Wax	  Increase Atk & Def 2 Turns     1500
 Apo Wax	  Increase Atk & Def 4 Turns     3500
 Speed Wax	  Increases Speed 1 Turn	 1000
 Hybrid Wax 	  Increases All Stats 1 Turn	 1500
 ---------------------------------------------------------------
 Restorative Fish 				   Selling Price
 ---------------------------------------------------------------
 Sky Sardis	Restores  400 HP		    40 Gold
 Red Sardis	Restores  900 HP		   120 Gold

 Grule		Restores 1000 HP to the Team	   480 Gold
 Drajik		Restores 1500 HP to the Team      3000 Gold

 Flying Fish	Restores  2 MP			    80 Gold
 Spiked Sunfish Restores  6 MP 			   200 GOld
 Romuhai	Restores 10 MP   		   400 Gold
 ---------------------------------------------------------------
 Stat Increasing Fish				   Selling Price
 ---------------------------------------------------------------
 Spear Squid	Increases HP by   5 Points	   360 Gold 
 Kite ray	Increases HP by  15 Points	   320 Gold 
 Red Dragon	Increases HP by  30 Points	  1500 Gold	 

 Stealth Ray	Increases MP by 1 Point 	   640 Gold
 Drill Squid	Increases MP by 3 Points	   680 Gold

 Rainbow Grule	Increases Power by 2 Points	   640 Gold
 Silverfish	Increases Will  by 2 Points	   500 Gold
 Hamahai 	Increases Vigor by 2 Points        640 Gold
 Gr. Nerath Eel Increases Quick by 2 Points        520 Gold
 Gold Dragon	Increases Agile by 1 Point	  1600 GOld

 Selling Fish
 -----------------------------------------------
 Sky Jellyfish  No use, but is good for selling    500 Gold
 Nerath Eel     No use, but is good for selling    800 Gold


 ------------------------------------------
 About Stat-Increasing Items:
 ------------------------------------------

 Unlike other games, that have fixed stat growths, either by having a table for each level up (Like, for example, Breath of Fire 3),
 or a fixed ammount of points in each stat for each level up (Like, for example, Final Fantasy Tactics Advance), this games works with
 a somewhat randomized system.

 Characters have a supposed way to be (Fina is a mage-like character, Drachma is your stereotypical beefy Warrior), and a personal growth for each stat, 
 but the way they gain stats isn't fixed. You may repeat a level up and get different results (For example, gaining 3 Will one time, and another 6 points).

 If one character levels up 1 point on something, by the next level he/she will gain a lot more to compensate, It's much better than real randomized
 RPGs, like the first Shining Force, for example. 

 Why is this important? Well, because the stats gained by stat increasing items, count as stat gains. That means, that if you give Aika many items 
 to increase her Power, she wont get a single point of Power until she is supposed to be at that range when you reach the necessary level.

 So, at least in my eyes, stat-increasing items are more of a "Hey, X Character grew very little in Y stat! Let's give him/her a boost". 
 Mostly because you would be wasting items that way.

 Now, this holds true for Power, Will, Vigor and Quick. Agile (which affects Dodge%) doesn't grow, and if you want to increase it, you do it by using items.

 That's, of course, until your characters are level 65. After that it seems that level ups are totally random and, because of that, these items are not
 a waste anymore. 

 Not only that, but HP and MP growth is not affected by using HP/MP Increasing items.

 But of course, you shouldn't need to be at that level to end the game. Not even close to be needed, in fact. Heck, stat-increasing items are not even
 a necessity in this game unles you want to actually use them for those bad level ups or just plain abuse, (Except maybe increase Fina's HP, which could 
 be really handy, I guess, just like increasing MP a little). You can ignore them and you'll be fine.

 WARNING!!! 

 Either if you want to abuse these items or just make the game easier for whatever reason, be aware to not go overboard with stat increasing 
 items against the last boss. 

 It kind of backfires in your face if the game wants to. This is also true for the original game, though. With the mod just could be even more dangerous.

-----------------------------------------------
-----------------------------------------------

-------------------------
Ship Equipment New Stats:					      
-------------------------

Main Cannons
				    Shop
 Name              Att  Hit Sp  Lim  Price   Location                         Ship
 ----------------------------------------------------------------------------------------------------
 Main Cannon        35  80   4    0    450   Little Jack comes with it        Little Jack
 Standard Cannon    40  83   4    0   1000   Sailors' Island After 1st Escape Little Jack
 Heavy Cannon       45  85   5    0   1900   Maramba Ship Parts Shop          Little Jack
 G-Type Cannon      60  90   5    0   3000   Horteka BlackMarket              Little Jack
 B-Type Cannon	    75  80   5    0   4000   Chamaleon First Fight            Little Jack
 Prototype Cannon  100  85   6    0   5000   Delphinus comes with it          Delphinus
 Advanced Cannon   150  90   7    0   5500   Nasrad, Esperanza Shop           Delphinus       
 Yamato Spirit     250  90   8    0   6700   Yafutoma Ship Parts Shop         Delphinus
 Ancient Cannon    300  95   8    0   8500   Crescent Island Shop             Delphinus
 X Cannon          400  97   9    0  11000   Sailors' Island                  Delphinus
 Moon Cannon       500  99   9    0   1000   Hydra Fight                      Delphinus
 Pyril Cannon      300 120   6    0  13200   Sailors' Isle   -Red Element-    Delphinus
 Crystil Cannon    550  70   4    0   1000   Galcian's Elite -Purple Element- Little Jack & Delphinus
 ----------------------------------------------------------------------------------------------------    

 Secondary Cannons 
 (Reinserted previously unused S. Cannons are marked with  "**" )

				    Shop
 Name              Att  Hit Sp  Lim  Price   Location                         Ship
 ----------------------------------------------------------------------------------------------------
 3"Cannon           70  80   1    1    700   Maramba, Sailors' Isle           Little Jack                                           
 3"Blaster          80  83   2    1   1015   Lynx Fight, Moonstone Mt.        Little Jack
 5"Cannon           90  80   3    1   1330   Black shipMarket                 Little Jack
 8"Cannon**	   100  82   3	  2   2100   Valuan Spellship		      Little Jack
 12"Cannon         180  95   2    2   3500   Auriga Fight                     Delphinus
 10"Cannon Coil    220  80   3    3   3710   Nasrad, Esperanza                Delphinus
 10"Cannon**	   200  88   3    3   3640   Gregorio Cruiser		      Delphinus
 12"Blaster**	   250  85   4    2   3850   Piastol 2� Fight		      Delphinus
 3'Cannon          280  87   4    3   4690   Yafutoma                         Delphinus
 5'Cannon          330  90   5    2   5110   Yafutoma                         Delphinus
 Moon Gun          400  99   4    3   1000   Gadianos if defeated in 1 Turn   Delphinus
 Wevl Cannon       220 120   3    3  10200   Crescent Isle -Blue Element-     Little Jack & Delphinus
 ----------------------------------------------------------------------------------------------------

 Torpedoes
 (Reinserted previously unused Torpedoes are marked with  "**" )
 
				    Shop 
 Name              Att  Hit Sp  Lim  Price  Location                       Ship
 ------------------------------------------------------------------------------------------------
 Light Torpedo      120  60   3    2   1520  Maramba                       Little Jack
 Guided Torpedo**   100  80   2    2   1720  Piastol 1st Fight		   Little Jack
 Shock Torpedo      140  75   3    2   2000  Black shipMarket              Little Jack
 Hunter Torpedo	    160  60   3    3   2240  Chameleon Second Fight	   Little Jack
 valuan Torpedo     220  60   3    2   2400  Nasrad, Esperanza             Delphinus                                          
 Heavy Torpedo      250  75   4    3   4400  Anguila Fight                 Delphinus
 Serpent Torpedo    300  65   4    2   5360  Yafutoma                      Delphinus
 Flash Torpedo**    350  55   4    3   6320  Tenkou Spellship Fight	   Delphinus
 Arcwhale Torpedo   400  70   6    3   6500  Crescent Isle                 Delphinus
 Dragon Torpedo**   450  60   6    2   8800  Draco Fight		   Delphinus
 Electril Torpedo** 500  60   4    3   1000  Eliminator Boss		   Delphinus
 Moon Torpedo       600  75   4    3   1000  Hydra Fight                   Delphinus
 ------------------------------------------------------------------------------------------------


 Defensive Ship Equipment
 (Reinserted previously unused equipment parts are marked with  "**" )
 
 Figures
 
 Name               De  Ma  Do  Qu  Price   Location                       Ship
 ------------------------------------------------------------------------------------------------
 Rogue Figure        0  20   0   0    800   Maramba                        Little Jack, Delphinus
 Pryn Figure         0  30   0   0   2400   Black shipMarket               Little Jack, Delphinus
 Pyrynn Figure       0  45   0   0   4400   Nasrad, Esperanza              Little Jack, Delphinus
 Archwale Figure**   0  60   0   0   4640   Rupee & Barta Fight            Little Jack, Delphinus
 Quetya Figure**     0  80   0   0   4880   Pera, Lira, Tara Fight	   Little Jack, Delphinus
 Giant Figure**      0 100   0   0   5120   Gregorio Gunboat Fight	   Little Jack, Delphinus
 Bluheim Figure      0 130   0   0   5360   Yafutoma                       Little Jack, Delphinus
 Goddess Figure      0 160   0   0   6800   Crescent Isle                  Little Jack, Delphinus
 Vyse Figure**	     0 190   0   0   8800   Obispo Fight		   Little Jack, Delphinus
 Spherical Figure    0 300   0   0  13500   @The Blackbeard-2              Little Jack, Delphinus
 ------------------------------------------------------------------------------------------------ 
 
 Decks
 
 Name               De  Ma  Do  Qu  Price   Location                       Ship
 ------------------------------------------------------------------------------------------------
 Armored Deck       10   0   0   0   1000   Sailors' Isle                  Little Jack, Delphinus
 Steel Deck         20   0   0   0   1900   Maramba                        Little Jack, Delphinus
 Compound Deck      40   0   0   0   5500   Nasrad, Esperanza, Sailor's I. Little Jack, Delphinus
 Heavy Armor Deck   55   0   0   0   6700   @The Auriga                    Little Jack, Delphinus
 Alloy Deck         70   0   0   0   7300   @Obispo                        Little Jack, Delphinus
 Dragon Deck**	   110   0   0   0   8500   Daikokuya Fight		   Little Jack, Delphinus
 Ancient Deck**    150   0   0   0   8500   Roc Fight			   Little Jack, Delphinus
 Silver Deck**	   200   0   1   3  11000   Vigoro Second Fight		   Little Jack, Delphinus
 Sparkling Deck    500   0   2   6  13500   Gadianos if defeated in 1 Turn Little Jack, Delphinus
 ------------------------------------------------------------------------------------------------  


Engines

Name               De  Ma  Do  Qu  Price   Location                       Ship
------------------------------------------------------------------------------------------------
Engine Cover        0   0   3  10    800   Sailors' Isle                  Little Jack, Delphinus
Turbo Kit           0   0   5  20   1520   Maramba                        Little Jack, Delphinus
Bore-up Kit         0   0   8  30   2400   Black shipMarket               Little Jack, Delphinus
Twin Propellers     0   0  10  40   3200   Centime (After Saving him)     Little Jack, Delphinus
Air Intake          0   0  12  80   6800   Crescent Isle                  Little Jack, Delphinus
Twin Turbo          0   0  15  90   8800   The Chameleon-3                Little Jack, Delphinus
Timing Valve        0   0  17 100  10800   Anguila (Osman), Blackbeard 2  Little Jack, Delphinus
Triple Turbo        0   0  20 130  12800   Valuan Spectre                 Little Jack, Delphinus
High Torque Kit**   0   0  23 150  14800   Piastol Third Fight		  Little Jack, Delphinus
Double Shaft        0   0  26 200  16640   Galcian`s Elite                Little Jack, Delphinus
------------------------------------------------------------------------------------------------

Decorational Parts
				   Value &
Name               De  Ma  Do  Qu  Price   Location                       Ship
------------------------------------------------------------------------------------------------
Floor Heater        0   1   0   0   3000   Black shipMarket               Little Jack, Delphinus
Enhanced Kitchen    1   0   0   0   5500   Nasrad                         Little Jack, Delphinus
Air Purifier        0   2   0   0   5800   Alania (Kalifa)                Little Jack, Delphinus
Yafutoman Alcove    0   2   0   0   6700   Yafutoma                       Little Jack, Delphinus
Soundproofing       1   0   0   0  11000   Raja                           Little Jack, Delphinus
Chandelier          1   0   0   0   9300   Crescent Isle                  Little Jack, Delphinus
Wooden Doll         0   0   0   0   7300   Roc (Kalifa)                   Little Jack, Delphinus
Intercom**	    0   0   0   0   1000   Alania			  Little Jack, Delphinus
Expensive Wheel**   0   0   0   2   8500   Daikokuya Fight (Jouyin)	  Little Jack, Delphinus
Indoor Plant**	    0   1   0   0  10100   Alania   			  Little Jack, Delphinus
------------------------------------------------------------------------------------------------


-----------------------------------------------
-----------------------------------------------

-------------------
Drop Ships Changes:
-------------------

The names in parenthessis means to have that crew member selected to be the active one in order for that item to appear.

Valuan Cruiser   - Gold 2000, 3'' Cannon
(Fight while escaping Valua, First time)

Valuan Spellship - Gold 2000. Bomb, Wave Bomb 50%, 8"Cannon 50%
(In front of the Grand Fortress until Soltis)

Valuan Phantom   - Gold 2000, Big Bomb, Frost Bomb
(Near Moonstone Mountain before fighting Grendel)

Valuan Gunboat   - Gold 3000, Shredder Bomb, Deluxe Kit
(North Ocean, only with the Little Jack)

Valuan Mage Ship - Gold 4000, Frost Bomb, Thunder Bomb
(Around Valuan Airspace, and as a Boss before the Hydra)

Valuan Spectre   - Gold 6000, Triple Turbo, Floor Heater (Kalifa)
(Around Mid Ocean and Sailor's Island Airspace, with the Delphinus)

Galcian Elite    - Gold 8000, Double Shaft, Complete Kit, Crystal Cannon (Kalifa)
(Soltis Airspace)

Gregorio Cruiser - Gold 4000, Speed Wax, Advanced Cannon, 10" Cannon
(Esperanza Ship Fight Part 1)

Gregorio Gunboat - Gold 5000, Shredder Bomb, Giant Figure, Crystal Ball (Osman)
(Esperanza Ship Fight Part 2)

Black Pirates    - Gold 2500, Heavy Cannon 50%, Rogue Figure 50% 
(Near Maramba)

Spell Pirates    - Gold 3000, Pyro Bomb, Wave Bomb 50%, Magic Shell 20%
(North Ocean)


Armada Boss Fights

Lynx        - Gold 3500, Magic Cannon, Captain Stripe, 3'' Blaster 100% **
Chameleon   - Gold 4000, Captain's Stripe, B-Type Cannon
Chameleon 2 - Gold 4000, Captain's Stripe, Hunter Torpedo
Auriga	    - Gold 5200, Captain's Stripe, Heavy Armor Deck, 12"Cannon
Draco 	    - Gold 6100, Captain's Stripe, Gold Bullion, Dragon Torpedo
Chameleon 3 - Gold 7000, Captain's Stripe, Twin Turbo, Magic Shell

Gigas:

Recumen  - Nothing
Grendel  - Captain's Stripe, Grendel Wing, Complete King
Bluheim  - Captain's Stripe
Plergoth - You don't fight it
Yeligar  - Captain's Stripe, Thunder Cutlass
Zelos    - Captain's Stripe


Monster Ship Fights

Anguila      - Gold  5400, Concussion Bomb, Heavy Torpedo, Timing Valve (Osman)
Raja         - Gold  5500, Deluxe Kit 50%, Soundproofing 50%, Crystal Ball (Kalifa)
Obispo       - Gold  5600, Alloy Deck, Vyse Figure**, Crystal Ball (Osman)
Roc:         - Gold  6900, Ancient Deck**, Wooden Doll (Kalifa), Gold Bullion
Alania       - Gold  6500, Air Purifier (Kalifa), Intercom, Indoor Plant
Giant Looper - Gold 13000, thermal Grease 100%, Captain's Stripe 100%, Hex Shell 100%
-------------------

-----------------------------------------------
-----------------------------------------------

-----------------------------------------------
List of Beta items rescued:
-----------------------------------------------

Secondary Cannons

12"Blaster	 -> Piastol, Second Fight
8"Cannon	 -> Valuan Spellship		  
10"Cannon	 -> Gregorio Cruiser		    

Torpedoes

Guided Torpedo   -> Piastol, First Fight
Flash Torpedo    -> Tenkou Spellship Fight
Dragon Torpedo   -> Draco Ship Fight
Electril Torpedo -> Eliminator Boss

Figures

Archwhale Figure -> Rupee and Barta Optional Boss Fight
Quetya Figure 	 -> Tara, Lira and Pera Optional Boss Fight
Giant Figure 	 -> Gregorio Gunboat
Vyse Figure	 -> Obispo

Decks

Dragon Deck 	 -> Daikokuya Optional Boss Fight
Ancient Deck	 -> Roc
Silver Deck	 -> Vigoro Second Boss Fight

Engine

High Torque Kit  -> Piastol, Third Fight

Decoration

Expensive Wheel  -> Daikokuya Optional Boss Fight (Youjin Minion)
Intercom	 -> Alania
Indor Plant	 -> Alania
 
 ---------------------------------------
 Frequent Answers and Questions
 ---------------------------------------

Just a few questions probably some people have...

Q: "Could I play this as my first time with the game?"

A: ...Yeah, you could. My hack ramps up the difficulty a fair ammount, but 
   it never reaches a "You should have known that before it happened!" moment
   you can see in some Hardtype hacks, and the game does a nice job at pointing things. 
   The original game is very easy.

   But have in mind that guides telling you about strategies and such may not be
   accurate with how monsters, spells, and supermoves work now. For example I tried
   to avoid the incredibly boring "Buff Vyse/Drachma, spam supermove" strategy that several 
   guides tell you to do, or some saying to ignore magic.

   ...You will go horribly wrong if you ignore magic in this mod.

   For other things like shops, plot progress, item drops, discoveries and such guides will be
   as useful as always.

   Also, you shouldn't worry about dying with bosses (On foot or ship battle), as 
   when you die, the game will ask you if you want to restart from the beginning of
   that fight, which is fantastic as sometimes there are several boss fights in a row.

   If you're new to this game, let me warn you: RUNNING FROM BATTLES CAN BE DANGEROUS!!!
   The game works wth a system of fame, in which Vyse gets different ranks , like...

   "Vyse the Competent", or "Vyse the Daring". This system is named Swashbuckler Rating.
   You get points for winning fights, and making the right choices when asked through the story.

   As you get more famous, people will say different things about you, and you will also get 
   access to different things (Like recruiting a character for your ship, or start a sidequest)...
    
   Problem with running, is that it lowers your fame. Unlike some people will tell you, or whatever you read
   in forums, running from battle from time to time isn't going to ruin your game (That's pretty inaccurate and silly), 
   but if you run constantly from battles you may gain the title of "Vyse the Coward", which is one of 
   the lowest ranks.

   The issue with that, is that it will take an awful ammount of time to recover from that rank, and you will
   not be able to do some things because you don't have a good enough ranking. Most people prefeer to reset
   the game and start from the beginning because it will take less time and... Yeah, it can be true.

   So remember, don't flee from battles too often, and answer the questions correctly and you'll be fine.
   If you need to run to save your life, do it. In all my test playthroughs I've run from battles here and there, 
   and it never, never hurt my rank.

   Just to give you an idea. If I fought 400 battles, and fleed from 30. Those 30 would not affect my rank. 

   Also, there's no rank that forces you to never run, so don't worry. 
   And once you get one of the special GC ranks, you can run as much as you want, it won't go down anymore.

   You can get an accessory to reduce random encounters too, and magic can make quick work of random encounters.

   Another tip: Use several save slots as you progress. Sometimes you may want to go back
   for whatever reason, and it's better to lose the last 20 minutes than start an entire 
   new playthrough, although that would be kinda extreme.

   ----------------------------------------------------------

Q: "I can't damage this boss, I do very low damage!"

A:  Well, if you try physical damage and goes bad, just try magic! And this is not just for on foot bosses, but
    for ship bosses too!
   
    Also, mind your enemies' elements. Skies of Arcadia works on a "Pok�mon" kinda system, where every enemy
    and also every attack (Except most ship equipment) you and your enemies do has an element. There is no Neutral element here 
    (Although you can do neutral damage)!
 
    As you play you unlock elements to change (You get them all very early in the game, don't worry). You can cycle through
    these elements during battle to adapt to any situation. And depending on what elements you have when you finish a battle,
    your characters will get Magic Experiencie (Needed to learn spells, of course!)

    You can find how each element reacts to another in the Magic Section.

   ----------------------------------------------------------

Q: "Okay... Magic Experience points, how do they work?"

A: Another question I saw a lot while reading through forums and such. Okay, this is how it goes:

   Each character always has one element activated. At the end of the fight, the game looks at which elements you have and gives
   the group M.Exp for each element present.

   Each enemy group (Yeah, Magic Experience goes by groups, no monsters) has a fixed ammount of M.Exp. when you finish a fight.
   It never goes very high, as the biggest ammount of M.Exp. you get in a single fight is 4.

   You may think it's low and well, sounds like it, yeah. But there is more than that:

   You see, if Vyse has Red element, and Aika has Green element, both will get experience for both elements! And if they have 
   the same element, you raise it faster too.

   Characters gain the ammount of M.Exp based on what elements are used and who many has those elements, plus extra points for his
   his/her own element.

   One example: 

   Vyse has Red element, Aika has Green. You win a fight and get 1 M.Exp.

   Vyse will get 1 Red M.Exp, and 1 Green Exp. But also, will get an aditional 1 Red M.Exp point for having Red Element. So 2 Red, 1 Green.
   Aika will get 1 Red M.Exp, and 1 Green Exp. But also, will get an aditional 1 Red M.Exp point for having Green Element. So 2 Green, 1 Red.
  
   Now let's say that you have four characters and win a fight with 2 M.Exp. And this time, they have the same element:

   Each character would get 2x4 (Because four characters used the element) plus another 2 because of the M. Exp. itself. 
   Each character would get 10 M.Exp points.

   And if they  had 2 elements between the four...

   Characters would get 2x2+2 (6 M.Exp Points) of an element, plus 4 of the one they're not using.

   Also, remember that each character learns spells at their own speed.

   Vyse is pretty fast with Red, Blue and Yellow, while is average with green and kinda slow with Purple and Silver, while Aika
   Is faster with those but slower in others like Red.

   Fina is the quickest, and Drachma is the slowest by far (He learns four times slower than Fina, if I remember right!).

   ----------------------------------------------------------

Q: "Okay so... What's the best approach for learning Magic?"

A: I don't know for others, but for me is just to put all characters with the same element I want to priorize.

   Let's say, at the beginning of the game I put both Vyse and Aika with Red, until they get Pyri. Then I switch to Green and
   learn Sacri and Noxi, and now the get an AoE spell, a healing spell, and another attack that can also poison. 

   Then you switch to whatever you want or need as you progress, and when you get a new element, is best to get a couple of levels on it too.

   By having all your characters learning one element, I usually waste much less time than trying to get different elements at the same time.
   Maybe you could try with two elements, I guess, but that won't work that well while enemies give you only 1 or 2 M.Exp. points.

   I always give more importance to learn magic than to use elements for physical attacks, as once you've learn a spell you can use it to 
   attack enemies without worrying about which element you have in your weapon, which means you can learn other spells with less worries.

   Also, Vyse, Aika and Fina get priority, as they are characters you will always have, while the fourth slot changes from timte to time.

   That said, it would be in your best interest to learn the Sacri line (Healing) and Risan/Riselem (Resurrection) as fast as you can, as
   items heal quite a bit less HP, and can get expensive.

   Also, eventual battles (Like bosses, plot related fights with lesser enemies, or fights that will always happen in certain points) give more
   M.Exp than normal. You may want to use that as a way to learn spells faster if you have the chance. Optional boss fights give more too!
   
   -----------------------------------------------------------

Q: "I got a defensive gear that protects me from an element, but how much it does?"

A: As far as I know, it's a 20% reduction of damage with that element. And you will need it in some boss fights. Also, you can have several
   protections (For example, an accessory can give two, or combine one element from armor and another from accessory).

   For status protection, there are several levels of resistance, so depends on the item. And about weapons with status effects (like causing sleep),
   they have a chance of 20% to activate.

   -----------------------------------------------------------

Q: "Oh god, I didn't equip the Little Jack with a Secondary Cannon, now I won't be able to get past Recumen!"

A: Well... it's not a question, but it seems to be a problem that happened to quite a few people in several places I looked. 
   First of all, you could still "win" that fight, with an unmodified Little Jack on the origignal game, it was just harder.
   
   But for this mod, things are different. Little Jack starts with a 3"Cannon in the third slot, and you get another one after advancing the plot
   (Yet before even going to the Nasr Region).

   Also, be careful, because he can wipe you out with one laser in this mod if you're unlucky (So defend until you descover what to do).

   ----------------------------------------------------------

Q: "Wow, enemy ships are destroying me!, What Can I do?"

A: Well, they are generally quite a bit stronger than before, because that was the point. If you want general tips, You can use Increm to give
   your ship higher defenses for a few turns, so when you see a lot of yellow and red turns, you might want to cast it.

   Also, equipment, you must have your ship well equipped always. Also bring some repair kits, although they are more expensive compared to the original
   game. Use the Sacri Spells to recover HP to your ship, Sacrulen been incredibly useful when enemies get really strong.

   Calculating when your ship will get attacked to heal right after is pretty useful, because in the next round the enemy may get the upper hand, you
   don't want to start a round with very little HP.
   
   Don't waste your time trying to attack enemies in yellow/red turns, or when they are too far away; you most probably miss, instead use those turns to
   heal or cast/use items on your ship.

   Remember to use Driln/Drilnos or Sylenis to put you on an advantage, if things are getting too intense (Although I rather have a challenge, lol).
   DON'T FORGET THE MAGIC CANNON! It can do pretty beast damage if you discover to what your enemy is weak against.
   
   And of course, search high and low for crew members when you get your second ship, as their special abilites can help you a lot.
   (Some are too good even!).

   I personally don't like to abuse items while in battle, and the mod (Not only ship battles) has been made and tested in a way that you don't 
   need them to win, just if you want to make fights easier or to use them in a pinch; yet with magic and S.moves in mind, as it still requires 
   SP and MP management. So I guess you could take advantage of them.

   Funny enough, the game itself makes a comment about pirates not wanting to use items during battle too and use their abilities instead.

   ----------------------------------------------------------

Q: "Wai-What?! Why I'm a "Fallen Pirate"?!"

A:  You may want to talk to shopkeepers and the Sailor's Guild to get some clues...

   ----------------------------------------------------------

Q: "I think I've seen Aika somewhere else..."

A: Probably. Her design was ripped off (Although you may want to say "used as inspiration") to make Sticks The Badger, a Sonic Boom Character... 
   That also is some sort of copy of another Sonic Character, Marine the Racoon. Call it a combination of both. And not a very subtle one.

   I don't know why the hell would yo do that, but it is.

   ----------------------------------------------------------  

Q: "It's me or Vigoro has a key around his neck?"

A: Yeah... it IS a key. A key that opens his... Erh... Cannon look-a-like crotch protector "of manliness"... Somewhat shaped as his own battleship,
   which also has been pointed by many as overcompensation of some kind... 
   
   ...Yeah, he has issues. And a problem with body hair, if you look at the japanese version (Why would anyone shave it that way?!).
   
   And still, I can't get enough of this guy. He's so incredibly silly that becomes awesome, and the developers knew. I miss those types of characters.
   
   ----------------------------------------------------------
   

Q: "What did you use to do this?"

A:  Well as far as tools, I started with GameCube Rebuilder So I could extract files from a GC ISO file, Start.Dol holds most of the information.
    Then I tried "Skies of Arcadia Legends Editor". And while useful at the beginning, it adds many bugs to the game.

    Some examples are:

    Bugs in the element resistance of equipment (Will cause very weird things if you're wearing one and get attacked)
    Bugs in the status resistance of equipment
    Bugs in the chance of "comsumption, putting it to 0% for each item you look with the application, even if you put 100% (Meaning that you would get infinite uses for each item)
    Bugs with percentages in spells
    Bugs with item descriptions (It reachs a point in the Consumable item list where it shows the description of other items)
    
    You could fix these with Hex Editor after each time you edit Start.Dol if you compare a clean Start.Dol and a edited one, but it gets really old...

    So I ended doing pretty much everything with a Hex Editor, HxD. But don't worry, Skies of Arcadia Legends is pretty easy to work with in a Hex Editor.

    Most things are easy to find, you just have to search the name, for example the Valuan Spellship, and you'll find it's data. 

    Start.Dol has all magic data, supermoves data, enemy attacks, Characters starting and growth stats, Ship data, item data, equiprment data
    (Weapon, armor, accessories), crew members and item/magic/equipment/crew/discoveries descriptions. In short, all but enemy data, and enemy formations.

    Which brings me to this: Besides SOAL Editor and GCR, I also used some very neat Ruby Tools named ALX, Skies of Arcadia Legends Examiner.
    They are a bunch of tools programmed with Ruby that you can use to edit the game around, and files that are not Dol.Start.

    But here's the catch: These tools are made for the PAL release of the game, which means that several of those tools will be useless and can CORRUPT
    YOUR GAME ISO if used in the NTSC-US version.

    Yet, they were invaluable for me because, thanks to the God of the Contrived Coincidences, the Enemy data and Enemy formations files are exactly the
    same in both versions of the game! Exactly the two I just needed, and they worked...

    The ALX tools you can (And will need to) use if you want to edit enemies are:

    Export_Enemies.rb & Import_Enemies.rb
    Export_Groups.rb & Import_Groups.rb
    Export_Events.rb & Import_Events.rb

    Exporting creates a txt file where you can edit things, and then you insert them in the games' files with the Import tool.
    Also, don't look at the txt files for too long, because you can get your sight very, very tired (Just like reading this thing, but worse!).

    Enemy data seems to be encrypted, so you can't change it with Hex Editors like the rest.

    Enemies.rb has all the data of on foot enemies, bosses included.
    Groups.rb has all the random encounter groups that you can edit around.
    Events.rb has all the boss fights and scripted battles, and all of the boss fights.

    One warning, dont you ever try to mix enemies without looking at which files they are stored! Don't try to put a random enemy alongside a boss, if it's
    data is not present in the same file as the bosses' for example. You will only crash the game.

   ----------------------------------------------------------------    

Q: "Why do you make such long readmes?"

A: ...Why not? Maybe most won't read it, but I can practice my english, and also is a pretty useful way to check that everything goes well
   with the hack/mod. For example, while writting the ship equipment section I saw that I screwed up with a pair of tiny things, and I corrected them.

   The same with fishes. And while I write it, I may get ideas or rethink something. I even changed bosses around because of that.
   Putting the changes into "paper" is useful and can help you.


   So, even if it's bound to be ignored, it helped me to make the hack better. I also can pretend to be funny while I'm not.

  ------------------------------------------------------------------

Q: "What are you going to do now?"

A: REST. The little free time I had for months has gone to this thing. I'll forget rom hacking for a while. I want to remember what is to play something
   without worrying about trying everything to see if the game explodes, stopping to fix it, then build the ISO again, and going back to see where it
   explodes next.

   It was a good way to put my mind in other things during these months after life being a bitch, but it really gets tiring (I guess it's the 
   problem with hacking 60+ gametime hours RPGs with no save states...). My brain needs a break and my eyes to no look at hex strings for some time... 
   Or that enemies.txt file.

   Knowing myself, it won't take too long for me to want to mess with another game but for now there's not much to announce. Maybe someday I'll finish
   my Shining Force 2 hack. Or try something with Mario & Luigi Superstar Saga.

   ----------------------------------------------------------------

 -------------------------------------------------------
 -------------------------------------------------------

------------------------
 Credits... Of sorts.
------------------------

 I want to thank Overworks and Sega for making this great game, and porting it to the Cube too, why not.
 I want to thank the Skies of Arcadia Wiki and Esoarcadia for the loads of information that helped me with all the silly names and data.
 I want to thank Tortigar for developing the ALX tools, without it there would be no monster changes.
 I want to thank ADnova for Skies of Arcadia Legends Editor, helped me quite a bit at the beginning, before going full Hex editor.
 I want to thank my brain for not giving up and comitting suicide after the several test playthroughs, and all the time inverted into this.
 And of course, to you too. Either if you enjoy this or not, thanks for at least showing some interest.

 

