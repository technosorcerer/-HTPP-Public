
 Guess what: I'm still horrible with naming  rom hacks!

  Table of Contents
  -------------------------------  
  1 - How to Install
  2 - Why the heck you did this?!
  3 - General Idea of this Hack/Mod
  4 - Version History and Notes
  5 - Character Information
  6 - Enemy Information  
  7 - Magic System
  8 - Element Matchup and Magic Learning Rates
  9 - Supermove and Crew Member Actions
 10 - Weapon & Cupil, Armor and Accessories
 11 - Item and Fish
 12 - Ship Equipment
 13 - Drop Ship Changes
 14 - List of Beta Items rescued
 15 - F.A.Q.
 16 - Credits


 WARNING: If you've never played this game before, you may get some minor spoilers here 
 (Mostly names, though), be careful nonetheless!

 -------------------
 1 - How to Install:
 -------------------

 Very easy, actually. This comes as a XDelta patch.
 It was made with DeltaPatcher, so use that if you want. 

 First make a backup of Skies of Arcadia Legends NTSC-US with this checksum:

 CRC32	23e347b6
 MD5	3e7fa5033c4a2704434fb6ba98195ecd
 SHA-1	46105320553c858f25fafc5fd357566b505a4940
 
 If it matches, you can continue. This data confirms is a verified
 good dump of the game. 

 Then is as easy as to patch it like any other ROM.
 First, get DeltaPatcher. Select the target ISO on the first box,
 my patch on the second, and click on Apply Patch. 
 	 
 It will take a while because this is not your typical Cartridge based game, 
 but that's just the only difference. After it finishes you'll have a patched
 ISO! After that, just boot it the way you chose either using your Wii or Dolphin.

 I personally played this through Nintendont with my Wii.
 
 Oh, by the way. This 1.50 Release comes with its own game banner, title and 
 game description (which is just a reference for one of my favourite silly 
 little lines in this game). The Game's ID is the same as the original game. 
 
 I wanted to make a different ID so save files for the original game and my 
 mod were separate, but apparently this game doesn't like it at all when 
 trying to save or read memory cards, so I left it as it was.
 
 I'll leave a screen capture on the 7zip file if you're curious about how it 
 looks on a GC.
 
 After installing the main patch, you can choose to also install one extra 
 tiny patch:
 
 Made by someone that goes by the name cleartonic, this hacker created a 
 modification for the game to temporarily disable random encounters while 
 the B Button is held. It works on foot, and sailing around too.
 
 Here's a link:
 https://www.romhacking.net/hacks/5314/
 
 But, that patch will not be compatible with my mod. It requires a specific 
 patch, which you can find on the 7zip file you also found this readme and 
 the main hack patch.
 
 I'ts a very light, simple IPS patch. Just apply it with LunarIPS or another 
 IPS tool to an ISO already patched with my main hack before. 
 
 Credits absolutely go to cleartonic for their work. I only adapted it to 
 be compatible with my own hack.

 That's all you need to know about installation. 

 -------------------------------
 2 - Why the heck you did this?!
 -------------------------------

 Short answer: Because I can/want, of course!

 Long answer...

 Skies of Arcadia was a game that I never got to play as a kid. I always heard good things 
 about it, but I didn't own a Dreamcast at that time, and the Gamecube version was really,
 really freaking hard to find here in Spain.

 It wasn't until a few years ago that I managed to import an american version to play on my Wii, 
 and man, I would have loved this thing growing up to bits, but even now I find its lighthearted
 and fun characters and world so refreshing and endearing compared to the often found broody,
 overly serious or overly dramatic stuff you can find everywhere that has stood in my heart 
 since the first time I tried it.  
 
 I loved the world, I loved all the details you could find exloring with the discoveries, 
 I liked the idea behind the Magic system, and the Battle System while quite straightforward,
 I enjoyed too, with the little things like how there's some sort of grid-system in which the 
 characters/enemies ocupy squares and that can change how certain abilities or Spells work,
 having to manage the Spirit points and choose between less, stronger actions, or more weaker 
 ones, or having to sacrifice dealing damage to heal and such. 

 My main complain is that the difficulty goes down tremendously the more you progress, 
 instead of being more challenging, even if you're under-leveled. And Magic not being
 too useful, with items being too easy to exploit. 

 In any case, something I always tend to do with games that I enjoy A LOT (Since a kid), 
 is to ask myself of how could I give it a new spin for future playthroughs. Back then I 
 used to impose rules or challenges as a way to do it, like not using the most powerful 
 Supermoves (which I still do out of habit) or not using Items in battles, but now that 
 I kinda can understand enough to try rom hacking things, I can directly change the game
 itself and make something I can enjoy as-is and even let others try it too.

 That way I could have a new version (Gameplay wise at least) of this game, so I can still 
 enjoy it in different ways.
 
 And hey, years laters I come back to give it a new fresh coat of paint, which I felt it 
 was needed. I polished up a lot compared to the 1.49 version, and I added more stuff 
 into it. 
 
 Sort of like my 1.30 release of Final Fantasy III, I suppose. A rework of sorts to 
 improve all I could.  

 ---------------------------------
 3 - General idea of this Hack/Mod
 ---------------------------------

 Well... Just like my attempt of a mod for Final Fantasy III (Famicom), 
 I just tweaked on many gameplay aspects in order to create a different, 
 fresh experience for me to keep enjoying the game on a new light.

-Magic is much, much more useful overall, and the ammount of SP costs has been modified 
 so the player can use Magic often. Also requires far less grinding to learn.
-Supermoves have been tweaked too. SP Costs, damage, or special effects were altered 
 in order to find a balance between earlier ones and late moves, and Magic.  
-Character growth has been tweaked.

-Usable Items have been balanced in different ways, in order to make healing Magic 
 more useful, and the game more challenging as they were pretty broken, with same effect
 as Magic with no SP & MP cost or need to be learnt, thus making healing Magic and 
 Supermoves absolutely useless and could turn the game into an "Item Spam" fest. 
 No longer is that. 

-Fish, previously mostly useless, now have an array of effects outside of battle 
 like healing more than normal restoration items, for example. Not only that, 
 they are also a decent way to make money in the early parts of the game, trying 
 to give the fishing aspect of the game a bigger point.

-Weapons, armors and accessories have been modified (alongside Cupil), and accessories
 are less stingy with the character limitations. Overall, there's more versatility 
 and weapons have more special traits. Cupil is a lot more interesting, providing 
 Fina with bonuses too, and the two routes it can morph into have different focuses. 

-The entire bestiary has been changed, with pretty much all of the enemies having 
 improvements on their stats to make them more challenging, with their special attacks
 being changed here and there too. Resistances, and group compositions where altered 
 too in some cases.  

-Bosses are now quite a bit harder, being tougher and more dangerous, but also having 
 minions (Or companions) helping them in most cases. They are also now susceptible to 
 Poison, it helps on long battles. 

-During the early parts of the game, big groups of enemies will yield a bit more Magic 
 Experience to make fighting them a little more rewarding and learning magic a little 
 bit faster.

-All of the enemy ships have suffered big ammounts of changes, from stats and resistances
 to the power of their equipment. They are now much harder and will make you pay more 
 attention, or at least I hope so!
 
-Ship Equipment has been changed significantly, and I also added all the ship equipment
 that ended being unused in the vanilla game! Decorative gear has been shaped into things 
 that now are actually useful to equip, and provide some variety on how to set up a ship.

-Magic Cannon attacks are also much more useful, with enemy ships also sporting weaknesses 
 and resistances. More Spells can now be used in ship battles, most important Sacrum being 
 usable, filing a hole in the healing capabilities that was in the original game. 

-Many airship battles will reward you with equipment that they didn't have before, and 
 much more Gold. 
 
-The Gamecube extra Boss Fights now give extra items too, so you may have a reason to fight
 them early, although they'll be a challenge. 


 ...In general, this aims for higher difficulty (Without being an exagerated HardType mod), 
 while also providing better abilities and gear to the player, to have more varied ways 
 to play the game, and try to cut down things like easy Item abuse. All in an attempt 
 to create a different experience. 
 

 --------------------------------
 4 - Version History and Notes
 --------------------------------

 1.50 Changelog:
 
 * Character Stats and Stat Growths slightly tweaked. For example, 
   Fina gets a bit more Power and Vigor, and Drachma gains a bit 
   more Will. 
   
   Experience curves for most characters slightly tweaked. Now, 
   Aika and Fina will level up closer to Vyse (specially Fina, as 
   she had a significantly slower growth and she was away from 
   the party a couple times causing a larger difference) and both 
   Drachma and Gilder grow significantly less slowly, with a 
   growth rhythm closer to Enrique.
   
   Also, Fina now starts at Level 11 (close to reach Level 12)
   instead of 1, to keep the rhythm better once she joins.
   She also joins with some Magic Exp. to improve the pace. 
   
   Drachma now joins with some Magic Exp. too, not only to avoid
   him getting way too behind throughout the progress of the game, 
   but also to provide some useful things early on, namely, a 
   character with Risan before Fina can join the party and you 
   can start learning Silver Magic. 
 
 * Magic Exp. curve tweaked again. I cut a significant amount of 
   nonsense grinding you have to do on the later ranks for each 
   element, and I also sped up certain ranks to make Status Effect 
   spells such as Sylenis and Panika need less experience, 
   as it made little sense to me that you took the same time to 
   learn how to cause Silence to a foe than to learn Pyrum or 
   Noxus, and it also made certain elements a bit of a slog 
   to train to get better offensive Spells, such as Purple 
   and Blue. 
   
   I also tweaked the Magic Exp. given by battles, as some 
   early ones gave a single point when they should give two,
   and late battles' Magic Exp. was cut down as they gave too 
   much and it was no longer necessary, as you don't have to 
   grind for 400+ Magic Exp. points for a single spell anymore. 
   
   I hope I got a balance between still having to make choices 
   on what to focus to learn on a given moment, but also making 
   things a bit more brisk and having your characters know most 
   of the Spells by the late game.    
   
   I also changed to which elements some of them are most 
   proeficient. For example, Gilder learns Purple Magic the
   fastest, but it's the least proeficient with Red Magic.
 
 * A few changes in Character Equipment. Nothing too crazy, 
   fixing some mistakes, improving the differences of late 
   gear, making some accessories more interesting, etc. 
 
 * Small changes to usable Items. Magic Dew has been nerfed from restoring 
   10 MP down to 6 Mp, as it can be used in battle, and makes Polly's Ship 
   Action more useful during ship battles and Aika's Supermove on normal ones.

   Also, the Drill Squids' Mp-raising properties went down from 3 to 2
   (they were a bit too good). Flying Fishes now restore 3 MP instead 
   of 2, as they can only be used outside battles.
   
   Sacrulen crystals no longer heal 10.000 Hp. They now heal 3.000 HP, which 
   I find still pretty good all things considered. I don't know why I didn't 
   change that back then, they made the Sacrulen spell basically useless.  
   
   I fixed the effect of an Item, Aura of Justice I think it was, as it had 
   an incorrect one. I also fixed a few equipment pieces, specially the 
   Caravan Armor, which was broken in ways I never noticed but were dangerous.
   
   I also changed around some Ship Items, as they offered the same effects 
   to Crew Member abilities and Spells, but they were too cheap AND very 
   abusable. Now, besides cost changes, the effects might be slightly less
   pronounced, or last less turns to compensate. 
 
 * Shield of Justice had its Spirit cost raised to 8. 
   It was too low at 6. 
   
   Risan SP cost lowered from 3 to 2, Riselem SP Cost lowered from 6 to 5.
   Certain Spells got their Power or chances to work (Status) tweaked. 
   
   Significant changes to some  Spells. Eterni and Eternes now work for 
   enemies the same way as you do, unlike prior versions that kept their 
   Insta-Death nature. Now they deal Silver Damage with extra effects. 
   
   Status Spells are more reliable. Chances for them to work are better 
   if the enemy in question is in fact supposedly weak to it, and now 
   you might feel the need to use Driln to weak certain foes, specifically 
   the larger ones that are stronger than before. 
   
   This only applies to Spells that specifically cause a Status, not 
   to Spells that do damage and also could inflict one, such as Noxi, 
   or Eternes. Those work like they used to.
   
   Now you can use Noxi, Noxus, Sacrum, Eterni and Eternes on Ship 
   battles! Sacrum is a fantastic addition as it fills a very big hole 
   in the progression of healing Magic during ship Battles, as before 
   you jumped from Sacres to Sacrulen, with nothing in betweeen and 
   getting to the latter was a long, long process. 
   
   The others work as any other elemental attack. This also means you 
   now can deal damage of any Element during ship battles! Enemies 
   will have resistances and/or weaknesses to these Elements, they 
   behave exactly like them, although the Silver spells have no animation. 
 
 * Elements' weaknesses and resistances were modified. Red and Purple
   having larger weaknesses but higher resistances really didn't 
   add any strategy, it made them just easier to deal with by receiving 
   more damage as the player can use any element at will. 
   
   I also made Silver a more "normal" element, having the same number of 
   Weaknesses, Resistances and "Neutral" match ups.
   
 * Enemy tweaks. The idea was to smooth down certain spots, while 
   boosting certain enemy types that might had lower damaging capabilities
   than they should for whichever part of the game they are in. 
   
   For example, I made the back-to-back Boss battles of Bleigoc and the 
   Executioner a bit less difficult, as it's a choke point where you can 
   end with very little healing items, NO way of reviving your characters, 
   and overall they ran a bit too long. 
   
   On other points, I made certain enemies that felt rather inconsistently 
   easy a bit more challenging. Or make a couple of the very rarely seen 
   monsters (like the Dracolurg) more common. Overall I think it should be
   a smoother experience early on and more cohesive as it goes on.
   
   Status Effects should be a lot more useful and desired now, specially 
   since some, like Driln can become vital against larger normal enemies
   that can deal a lot more damage. 
   
   I also increased the chance some enemies have to drop equipment; 
   like having an easier time getting the Elemental resisting accessories, 
   or having drop-only weapons be less annoying to get. 
   
   I also fixed some enemy layouts and a couple of screw ups I did in 
   older versions. 

 * Ship equipment got a large number of changes, as I wanted to make the 
   known "decorative" parts actually useful. 
   
   Even if you aim to get the Swashbuckler Rating of "Vyse the Extravagant",
   their Value effect is useless as, as far as I know, it's just the fact
   of you owning the Ship equipment itself and not its effect what helps
   attaining that Rating... And even then, it's on the lower end of the
   lower Special ranks, meaning it will get replaced as soon as you get 
   a higher Rating than that, you ain't seeing "the Extravagant" ever 
   again. So, yeah, useless. 
  
   But that's what happens when you keep a mechanic from early on during 
   development where you could buy and sell ships I suppose. 

   Nonetheless, I reworked all defensive Ship parts so the "decorative"
   ones become something the player wants to use. Please check the Ship
   equipment section.  
   
   The power of Spells using the Magic Cannon during ship battles got a 
   small boost too. 
   
   * A couple of changes in Treasure Chest contents' to bring back 
   another unused piece of Ship gear, and to move away one of 
   Alania's Ship gear reward to a chest, as that boss gave you 
   three pieces of equipment, it was a bit too much. 
   
   I took the opportunity to also make some adjustments, like adding 
   some Risan Crystals during your incursion to Valua, so you can 
   actually revive your characters might they fall during the boss 
   fights, or a few Repair Kits on Pyrin Temple so you have something
   to heal on the sections after it, problems that the original game 
   also had (you can find old messages of people having to restart 
   the game because they were locked without recovery items on that 
   specific part, funny enough) among other small chest changes. 
 
 * A few crew members had a few changes, usually boosts. Merida now 
   raises the Quick of your ship, which is better than the "nothing" that 
   it was to raise the Value of the ship. Belle and Khazim's effect was 
   slightly nerfed, they were a bit too good. 
   
 * Numerous but subtle changes to the enemies in ship battles. Weaknesses 
   and resistances were tweaked and made more uniform (as far as how much 
   extra damage or reduced damage they take from each element), some stat 
   changes here and there, I also reduced the HP of a couple of enemies 
   to reduce the length two of the longest battles as they can get too long...
   
   Which by the way, their HP values were the original, I never changed them!

 1.4 Modified the Magic Exp. Chart again, rectified several descriptions, made the 
     introduction a little easier, and other small changes.
 1.3 Modified the ammount of Magic Exp that characters need for learning new spells.
 1.2 Fixed the drops of one optional boss fight, remade the patch to be for both Wii 
     and Dolphin, corrected some descriptions, changed the Readme. 
 1.1 Fixed Curia Crystal, edited Risan Spell and added an optional patch to use with
     Dolphin, as the emulator didn't like one boss fight.
 1.0 Initial Release.
 

 As of 1.2, both Wii and Dolphin use the same patch. The only difference was a single Boss 
 fight, and it's just not enough to make a different patch for each, even less when each one
 has a size of 7MB and RHDN has a limit size.


 --------------------------
 5 - Character Information
 --------------------------
 
 Probably weird to put on a hack readme, but I think starting with what 
 each Statistic does would be pretty useful, specially since this game 
 uses different names for some things.
 About stats:

 HP:      Hit points. I don't think you need me to explain this if you're really reading 
          a Readme for a mod of a well-beloved but somewhat obscure RPG. I hope, at least.

 MP:      Magic Points. Unlike other games, every spell in this game just costs 1 MP,
          it's the ammount of SP (Action points in other games) that increases.

 Power:   Increases the physical damage you will do with normal attacks and physical.
		  Supermoves. 1 Power equals 1 Attack. 
		  
		  On Ship Battles, it increases the damage done with the Main Cannon type of 
		  weapons. The Hunter's Hand and the Captain's Hat raise Power, and thus, 
		  raise Main Cannon's damage. 

 Will:    Increases the magical damage you will deal with spells and magical supermoves.
 
          In Ship Battles, the Will of the character affects the damage done with the 
		  Magic Cannon by enchanting cannon balls with spells they know. Remember that 
		  the Will obtained by equipment also counts when on a ship battle!
 
 Vigor:   A Character's natural Defense and Magic defense. The more you have, the less
          damage you get AND more resistant to poison damage you are.
		  
		  During Ship battles, the Vigor of the character affects the damage taken during 
		  the particular turn you assign them on. It adds some damage reduction, so 
		  a character such as Drachman will help the ship take less damage if assigned 
		  on a turn where the enemy would attack, thus, members with high Vigor would 
		  benefit you to act during Red and Yellow turns.

 Quick :  Just any other games' Speed or Agility. High agility let's you attack sooner,
          but it's not guaranteed. High Quick can still be a life-saver to heal fast, 
		  and on boss fights the Spell Quika can be tremendously useful.

 Agile :  Basically an analogue for "Luck" in other games, plain and simple. 
		  1 Point in Agile means 1% more of evasion, which is used to dodge 
		  normal attacks. Higher Agile also increases the chance to do Critical 
		  Hits with normal attacks.
		  
		  Agile does matter in Ship Battles, as it helps with dodging or doing 
		  a Critical Hit to the enemy. You don't get a notice about doing so, 
		  but you'll easily see you do a lot more damage than usual. 

 SP    :  Spirit Points. Each Character has an ammount of total SP, and actual SP. 
          They are used to give commands to the characters, and each action
	      has an ammount of SP that is used. I'll put an example:
	
	      Vyse has 2 SP of a total of 4, Aika has 2 of a total of 3, and Fina has a 
		  total of 1 of 3. That's 5 out of 10. Each turn your group will get
	      5 SP, that you can use to give characters orders whatever you see fit. 
		  As you level up they grow (And the grow is fixed).

	     You can use the command Focus to give up a character's action to recover an 
		 ammount of SP equal to his "actual SP", in the example above, Vyse would get 2.
 
 
 Again, just remember that this game has a variable stat gain system for 
 HP, Power, Will, Vigor and Quick. This not only means that of course not
 every level will grant you the same Stat gains, but it also means that if a 
 character is below what would be considered the intended amount, it will 
 add some extra points on that level up. On the other hand, if it had a 
 large gain in a stat when leveling up, next time that character gains 
 a level it will gain less than the normal, so it averages out. 
 
 This means that you don't really have to worry about a character's growth, 
 but it also has that small variation. It's in a way very similar to what 
 another RPG from SEGA does, Shining Force 2. 
 
 This also means that if you give many Stat-raising items to your characters
 in a row, be prepared to not gain any stat for several levels, as the game 
 finds out that, hey, you're way above what should be considered the normal, 
 so no stat gains for you!

 But anyway, on with the characters. 

 Vyse and Aika are well rounded and pretty good at everything without being the strongest
 in neither physical or magical sides of the spectrum. Vyse has slightly more HP, Aika
 slightly more MP. Vyse slightly more Power and Vigor, and Aika has higher Quick and Agile. 
 Tied for second best offensive Magic users, and you'll probably use a lot of Magic.
 
 Vyse will tend to do higher damage with Normal Hits than Aika, but Aika's boomerang skills
 provide significantly better Accuracy, which will be of great help with foes that can 
 easily avoid attacks. 
 
 Vyse's offensive Supermoves deal Physical Damage. Cutlass Fury and Pirate's Wrath are 
 great tools against beefier enemies or bosses, and Rain of Swords gives you the chance 
 to hit all foes with physical damage of any element. His Support abilities protect 
 the entire team from Normal Hits, and countering all of them, really useful with 
 certain types of enemies.
 
 Aika's offensive Supermoves deal Magical Damage. Omega Psyclone is of particular note 
 because it's the only way you can do magical AoE damage of Purple element. Her Support 
 abilities nullify Magic (all of it, foe or friend) and restore Aika's MP. 
 
 Fina is pretty much a mix of your typical mages and priests. Without being bad, she has the
 lowest Power and Vigor growth, but has the highest MP and Will growth by far. Thankfully 
 Cupil helps Fina a lot doing physical damage, whenever there's need for that. 
 
 Her offensive Supermoves deal Silver magical damage, and have useful secondary effects. 
 Lunar Glyph offers pretty respectable damage for little Spirit cost, and Lunar Winds
 can be of great use with enemies that like to use magic to raise their stats, as it 
 erases benefitial effects on the enemies.

 Her Support moves are the most Healer-like. Curing Status Effects, granting Regeneration, 
 or a super-healing ability that completely restores the HP and revives any fallen allies, 
 although it requires a lot of Spirit points to use, and its use needs to be planned ahead.

 Drachma and Gilder are your physical, warrior-like characters. High HP, Power and Vigor, 
 but not that great with offensive Magic. Not terrible, mind you, just falling behind the 
 main trio. Fortunately, they still do a great job with healing and Status-related Spells, 
 as those don't need Will to be useful.
 
 Drachma's Supermoves are, by far, the most powerful, only dealing damage to a single foe,
 but hurting like nothing else. He cannot support the party, but it can provide large 
 amounts of Spirit by charging for one round, while defending himself. Useful.
 
 Gilder's Supermoves are less powerful than Drachma's, but he can hit several enemies in 
 exchange. His support move is Aura of Denial, which prevents any negative Status Effect 
 to be inflicted to your party. It's far more useful than it sounds initially, as it not 
 only blocks abilities that do cause Status Effects as their main point, but also anything 
 that potentially cause one, like Noxi/Noxus Poison, Normal Hits with properties, and even 
 protecting your from Eternum's Instant Death effect. Underrated. 

 Lastly, Enrique is also versatile and well rounded, close to Aika and Vyse. The best Magic 
 user out of the three guests character no doubt, although he can't take as much punishment 
 as Drachma and Gilder. 
 
 His offensive Supermoves are basically the same as the single-hit moves of Vyse, which are 
 pretty darn useful, albeit Royal Blade a bit silly looking (the spin always gets me!). On 
 the Support side, he has Justice Shield, that halves any damage received in half for the 
 entire team. One of the best moves, if you can read the enemie's actions, and have the 
 Spirit points to use it. 

 
 Overall, while there are marked character differences, feel free to use each at their fullest.
 There's no reason at all to not use Drachma for Magic, there's no reason to not use Fina for 
 doing normal attacks, if either of the two can make a difference. 
 
 -----------------------------------------------
 -----------------------------------------------

 -----------------------------------------------
 6 - Enemy Information  
 -----------------------------------------------

  
 Well... Not much to say here that you cannot imagine.


 They are stronger, their HP is not laughable anymore (Seriously, final dungeon enemies
 with less than 300 hp? Damn), and won't die by just looking at them... Or by Lambda 
 Burst/Rain of Swords spam. But don't worry, random fights shouldn't be long if you take
 advantage of your own abilities and Magic.

 Enemy drops have been messed around a little. Some of the most hard to get items are a 
 little easier (If only to reduce the overleveling) too. Moonstones still are 1% as they 
 always have been. I can't believe the several messages I got asking if they were easier 
 to get, when I didn't even touch that particular item in any capacity. 
 
 Heck, in the last test-playthroughs I've done I wasn't even getting enough Moonberries 
 to learn the last Supermove of any character. I still beat the game without them.

 Enemy abilities have been changed around as well, so previously insignificant skills may 
 now be a little more dangerous. Enemies also have more powerful Magic, and the other 
 Stats have also been raised to levels that made sense the more you progressed.

 But even tougher are the bosses, which have suffered quite a few improvements. 
 And they didn't come alone, as most of them have lackeys (or companions, if it 
 is something bigger).

 I tried to make the game at least a little more challenging without getting into the
 cheap mindset of "you have to luck out/know exactly what to do to not die in one turn"
 feel that I've seen in some hacks for other games. 

 That said, there is no need to grind at all. In my test playthroughs I generally beat the 
 game around Level 45, with my lowest being Level 41 to give you an idea.

 But if you overlevel for some reason, well, probably the last bosses will feel a little easy.
 
 Thankfully that's why the optional bosses are there. You can fight them anytime once they
 appear, but they get stronger depending your own levels. And they were designed originally
 to be tougher than most bosses (Heck, the game also does the "The secret boss is the strongest
 thing form in this universe" too).

 If you want challenging fights, let them alone until you're around lvl 50/60 for their strongest
 points. Except the secret one, if you really want to give yourself headaches, he gets up to Lvl 
 99, which is entirely absurd and you shouldn't waste so much time grinding for it...

 ...But damn if he doesn't get quite the upgrade when fighting at that level. 

 Ludicrous. On the other hand, it's not like they're easy when you can fight them first, not 
 only you have more humble stats, you also have less magic and supermoves to defend yourself.
 But battling early they drop  interesting items that you may want to take advantage off.
  

 -----------------------------------------------
 Magic Changes
 -----------------------------------------------
 
   Warning: Pretty long wall of text. Beware!
 
  I always enjoyed the idea behind both the magic system as a mechanic, and also the 
 in-world explanation of it. Unfortunately, Magic in the vanilla game was mostly left 
 underwhelming. Damage was subpar, the amount of Spirit points was ridiculous for such 
 little payoff, it required ridiculous amount of grinding, and the worst part of all...
 
 ...Most of the Spells left with some "usefulness" after all the above were made not 
 worth your time because you could get Items that did the exact same thing, whith no 
 Spirit cost, no MP cost, and no need to learn anything. Yeah...

 As much as I love the game, these design ideas can sour the experience for me. 
 
 In fact, this very first thing is what made me want to change how this game played, 
 similar in fashion as to how I started my Final Fantasy III (the NES/Famicom one) 
 hack too. 
 
 So... Many things have been changed. My point is that I want to make Magic useful 
 throughout the game. Something the player actually wants to have at its disposal, 
 play around with elements, use Status Effects, rely on healing Spells to keep 
 the team healthy. What I think an actual fan of RPGs would enjoy, I suppose.  
 
 The first thing was to adjust Spirit costs. Magic now offers pretty reasonable 
 SP costs depending on both the "tier" of the Spell and its overall usefulness. 
 
 Offensive Magic now is significantly more powerful than in vanilla, and damage 
 keeps consistent and useful all throughout, with the last level of each, the 
 "-len" Spells, have a final stronger increase in damage, as they're almost in 
 every case, the last Spell to learn, and it's both a good reward for the time 
 spent training in an element and also helps keeping the Physical/Magical balance 
 for the very late areas of the game where you will most probably start learning 
 them. 
 
 While Noxus is left behind somewhat, its Poison effect is truly useful, 
 specially on Boss battles where the accumulated damage throughout the battle 
 really adds up or larger normal enemies, with much higher HP. 

 The Silver Spells Eterni and Eternes have been changed around. In the vanilla game 
 All three Etern- Spells are basically "Instant Death" Spells. This means that the 
 earlier ones became useless, and that the player has no way of doing magical Silver 
 damage with characters that are not Fina.
 
 While Eternum stays the same, Eterni and Eternes now act as normal, damaging Spells 
 with secondary effects. The first one being able to remove benefitial Status from 
 the target, the second being an Area of Effect attack that has low chance to cause 
 Stone. Eterni specifically can be of great use against bosses or tougher foes.

 Status Magic has been made more accurate, which works in your favour and against you 
 if enemies cast it, of course. This makes Status-resisting equipment more useful too. 

 Healing Magic has gotten few improvements. Sacrum heals 1.500 HP instead of 1.000, 
 for example, but the biggest change is the SP costs, being for the most part halved, 
 Sacrum now costs 4 SP.
 
 To compare, again, Sacrum costs 8 SP in vanilla, making it hard to use, as chances 
 are you'd receive a strong hit while also throwing all you have to your foes, meaning 
 you probably don't have enough SP to use Sacrum next turn at all, or just barely 
 leaving you with nothing special to do during the turn you're healing. 
 
 But now with more sensible SP costs, the Sacri line of Spells is far easier to use
 and fall back to, and with the increase in difficulty of this hack, you really 
 need a reliable way of healing. 
 
 The biggest improvement for Healing Magic is indirect, though. Items' effects 
 are far more subdued. Healing can no longer match the effect of the actual Spells,
 with the exception of reviving Items, the Risan and Riselem Crystals, as there's
 no way to change them without making them useless and taking away resurrection 
 items feels way too unfair. 
 
 
 In any case, the way Magic is set up now makes it far more dynamic, easy and rewarding 
 to use, while still having to manage your Spirit Points and Magic Points, and of course, 
 having to put the effort in learning them in a timely fashion. Comparing them to the
 Supermoves, more specifically Physical ones, is slightly more complex than in vanilla. 
 
 In vanilla, there was no comparison. They were much better, not only because the damage 
 disparity between Spells and Supermoves, but also because the Spirit Costs were too high 
 in the case of Magic so they also lost in efficency. 
 
 In this hack, Physical Super Moves still do hold higher potential for damage in a single 
 hit. They're good to deal quick amounts of damage in less moves. But, Magic is a lot more
 efficient in exchange! For the price of, let's say one Cutlass Fury, 7 SP, you can cast 
 three second tier Spells, or two Crystalum/Eterni, usually causing more damage in total 
 than a single Cutlass Fury. Or you could, for the price of that Cutlass Fury, heal, cause 
 Status Effects AND hit the enemy with a Spell, or whatever combination you want. 
 
 Of course, this difference grows larger with more powerful Supermoves with higher SP cost.


 To end this section, the Magic Experience curves have also been tweaked so grinding is toned
 down significantly. I simply see no reason to have such high requirements, it introduces an 
 incredible amount of grinding. No one is going to reach let's say, the 1400~ points needed 
 by Vyse and Aike to master Yellow Magic playing normally through the game, not even close;
 even less reach the 1700 Vyse needs to master Green Magic, and the biggest joke of all, the 
 over 5.500 points required by Drachma to master Silver magic. I cannot imagine how many tens
 of hours would be needed to reach that, as the most points you could get per battle is around
 20, and only right at the very end of the game, during the majority of it you will gain half 
 of that... And that's if you're using all four characters with the Silver Element in their 
 weapons, if you want to use other things will be even slower!
 
 I sincerely cannot imagine how much time that would take, specially playing on a Dreamcast.
 
 Rates for each character were also sort of adjusted so each one will have
 elements it does better than others. Vyse for example does better with Red and Blue 
 magic while Aika does better with Green and Purple. In any case, here are listed the 
 changes in all magic, both on foot and ship battle.
 
 Anyway, here's the list of Spells you can use while on foot.
 For the Ship Battle Spells, look on its section below.
	   
o------------------------------------------------------------------------------------------o
|Green Magic: used on foot.                                                                |
|Name        SP Power   Effect                                                             |
o------------------------------------------------------------------------------------------o                      
|Sacri        1  ---    Heals exactly    500 HP to one ally.                               |
|Sacres       2  ---    Heals exactly  1.000 HP to one ally.                               |
|Sacrum       4  ---    Heals exactly  1.000 HP to the entire team.                        |
|Sacrulen     6  ---    Heals exactly  10.00 HP to one ally.                               |
|Noxi         1  160    Deals Green element damage, very high chance of Poison.            |
|Noxus        4  400    Deals Green element damage, high chance to Poison all foes.        |
o------------------------------------------------------------------------------------------o
| Order of learning: Sacri L1, Noxi L2, Sacres L3, Noxus L4, Sacrum L5, Sacrulen L6.       |
o------------------------------------------------------------------------------------------o

o------------------------------------------------------------------------------------------o
|Red Magic: Used on foot.                                                                  |
|Name        SP Power   Effect                                                             |
o------------------------------------------------------------------------------------------o                      
|Pyri         1  140    Deals Red element damage to all foes.                              |
|Pyres        2  260    Deals Red element damage to all foes.                              |
|Pyrum        4  400    Deals Red element damage to all foes.                              |
|Pyrulen      5  650    Deals Red element damage to all foes. May cause Confusion.         |
|Increm       8  ---    Increases Attack and Defense of one Ally during that battle.       |
|Incremus    20  ---    Increases Attack and Defense of all Allies during that battle.     |
o------------------------------------------------------------------------------------------o
| Order of learning: Pyri L1, Increm L2, Pyres L3, Pyrum L4, Pyrulen L5, Incremus L6.      |
o------------------------------------------------------------------------------------------o

o------------------------------------------------------------------------------------------o
|Purple Magic: Used on foot.                                                               |
|Name        SP Power   Effect                                                             |
o------------------------------------------------------------------------------------------o                      
|Crystali     1  180    Deals high Purple element damage to a single foe.                  |
|Crystales    2  320    Deals high Purple element damage to a single foe.                  |
|Crystalum    3  500    Deals high Purple element damage to a single foe.                  |
|Crystalen    4  850    Deals high Purple element damage to a single foe.                  |
|Sylenis      2  ---    High probability to inflict Silence to a single foe.               |
|Panika       2  ---    Moderate probability to inflict Confusion to a single foe.         |
o------------------------------------------------------------------------------------------o
| Order: Cristali L1, Cristales L2, Sylenis L3, Panika L4, Crystalum L5, Crystalen L6.     |
o------------------------------------------------------------------------------------------o

o------------------------------------------------------------------------------------------o
|Blue Magic: Used on foot.                                                                  |
|Name        SP Power   Effect                                                             |
o------------------------------------------------------------------------------------------o                      
|Wevli        1  170    Deals Blue element damage to any foe in a small circular area.     |
|Wevles       2  290    Deals Blue element damage to any foe in a medium circular area.    |
|Wevlum       4  450    Deals Blue element damage to any foe in a large circular area.     |
|Wevlen       5  750    Deals Blue element damage to any foe in a very large circular area.|
|Quika        7  ---    Increases the Quick of all allies.                                 |
|Slipara      5  ---    Moderate probability to inflict Sleep to all foes.                 |
o------------------------------------------------------------------------------------------o
| Order of learning: Wevli L1, Quika L2, Wevles L3, Slipara L4, Wevlum L5, Wevlen L6.      |
o------------------------------------------------------------------------------------------o
 
o------------------------------------------------------------------------------------------o
|Yellow Magic: Used on foot.                                                               |
|Name        SP Power   Effect                                                             |
o------------------------------------------------------------------------------------------o                      
|Electri      1  170    Yellow damage to all in a straight line to the target, small width.|
|Electres     2  290    Yellow damage to all in a straight line to the target,medium width.|
|Electrum     4  450    Yellow damage to all in a straight line to the target,  good width.|
|Electren     5  750    Yellow damage to all in a straight line to the target, large width.|
|Driln        3  ---    Lowers all the Stats of a single foe.                              |
|Drilnos      7  ---    Lowers all the Stats of all foes.                                  |
o------------------------------------------------------------------------------------------o
| Order: Electri L1, Driln L2, Electres L3, Electrum L4, Drilnos L5, Electren L6.          |
o------------------------------------------------------------------------------------------o

o------------------------------------------------------------------------------------------o
|Silver Magic: Used on foot.                                                               |
|Name        SP Power   Effect                                                             |
o------------------------------------------------------------------------------------------o                      
|Eterni       3  460    Deals Silver damage to one foe and removes any benefitial effect.  |
|Eternes      4  400    Deals Silver damage to all foes, with low chances to Petrify.      |
|Eternum     10  850    Causes Instant Death. If immune, it deals high Silver damage.      |
|Curia        1  ---    Heals every Status Effect besides Unconscious to an ally.          |
|Risan        3  ---    Has a 85% Chance to revive an ally with 50% of it's total HP.      |
|Riselem      6  ---    Lowers the Attack and Defense of all foes.                         |
o------------------------------------------------------------------------------------------o
| Order: Curia L1, Risan L2, Eterni L3, Riselem L4, Eternum L5, Eternes L6.                |
o------------------------------------------------------------------------------------------o

 
o--------------------------------------------o
|8-  Element Matchup and Magic Learning Rates|
o--------------------------------------------o
 Each enemy has an element (Or Color) asociated to them. Your charactes will always have 
 an element asociated to their attacks, but defensively speaking, they are neutral to all
 elements unless wearing protective gear that gives them resistance to some element, and
 that resistance usually is around 20%.

 Elements are a rather important part of the game because how much control you have over it, 
 and in this mod, they work like these:


   DEFENSE>     Green    Red   Purple  Blue  Yellow  Silver
  ---------------------------------------------------------
 O  Green        100%    80%    100%   120%    80%    120%
 F  Red          120%   100%    120%    80%   100%     80%
 F  Purple        80%   120%    100%   120%    80%    100%
 E  Blue          80%   120%     80%   100%   120%    100%
 N  Yellow       120%   100%     80%    80%   100%    120%
 S  Silver       100%    80%    120%   100%   120%     80%
 E

 This means that Green enemies will resist Purple and Blue, and they are weak against 
 Red and Yellow, for example. Also, even if it's "only" 20% more damage, it makes a big 
 difference when you play around with the elements to your advantage, even more remembering
 that in the original game you just got 10% extra damage for taking advantage of a weakness.

 And, of course, this works for normal attacks, Magic, and supermoves without a forced 
 element all the same. Also, there are a few enemies that may react in a different way,
 than on this chart but for the vast majority, that chart will be true.

 ...One last thing: Enemy Ships also had their resistances changed, so they may resist some
 elements and be weak to others. The only way to know about it is just old-school trying.
 There's no hint on their Icon, although some weaknesses are easy to imagine. 

 ----------------------
 Magic Experience Chart
 ----------------------
 
 To learn new Spells, a character needs to gain enough Magic Experience after battles.
 Each element has its own progression system, and to gain Magic Exp. for an element, 
 you need to have your characters using that specific element you want on their weapons.

 Every character will get Magic Exp. from the element of the other teammates. 
 
 If Vyse has Red, Aika has Green, and Fina has Silver, all three would get 
 Red, Green and Silver at the end of the battle, with each character getting a 
 small extra for the element each one is holding.

 You can swap elements during battle quickly, and the more characters use the same
 element, the more Magic Exp. for that element you will get. I recommend this as 
 it speeds up the process by focusing on one Spell at a time while also maintaining 
 all characters learning that element at the same rhythm. 
 
 Each character needs different amounts of Magic Exp. for each element, with each one 
 growing faster on certain elements and slower in others. 
 
 Remember: The numbers here show the specific amount you need for that Level. 
		   The total given on the right is just to make easier to see which 
		   character grows faster in each element. 
		   
 o----------------------------------------------------------------------o
 |Green Magic                                                           |
 |          Sacri    Noxi     Sacres  Noxus    Sacrum   Sacrulen   M.Exp|
 |          Exp.L1   Exp.L2   Ex.L3   Exp.L4   Exp.L5   Exp.L6     Total|
 |----------------------------------------------------------------------o
 |Vyse         6       20      70      120      165      220        601 |       	
 |Aika         4       16      55      120      145      200        540 |
 |Fina         2       10      40      120      135      200        502 |
 |Drachma      8       20      85      140      180      235        668 |
 |Enrique	   4       15      55      115      155      210        554 |
 |Gilder       8       20      85      140      180      235        668 |
 o----------------------------------------------------------------------o

 o----------------------------------------------------------------------o
 |Red Magic                                                             |
 |          Pyri     Increm   Pyres   Pyrum    Pyrulen  Incremus   M.Exp|
 |          Exp.L1   Exp.L2   Ex.L3   Exp.L4   Exp.L5   Exp.L6     Total|
 |----------------------------------------------------------------------o
 |Vyse         4       16      55      100      200      200        575 |       	
 |Aika         6       20      70      115      215      220        646 |
 |Fina         2       10      40      115      215      225        607 |
 |Drachma      4       16      65      110      210      200        606 | 
 |Enrique      6       20      70      115      215      225        651 |
 |Gilder       8       20      80      120      230      225        693 |
 o----------------------------------------------------------------------o

 o----------------------------------------------------------------------o
 |Purple Magic                                                          |
 |        Cristali Cristales Sylenis  Panika Cristalum Cristalen   M.Exp| 
 |          Exp.L1   Exp.L2   Ex.L3   Exp.L4   Exp.L5   Exp.L6     Total|
 |----------------------------------------------------------------------o
 |Vyse         6       30      55       80      180      220        571 |       	
 |Aika         4       20      55       70      160      200        509 |
 |Fina         2       12      40       75      180      220        529 |
 |Drachma      8       32      65       95      200      230        630 |
 |Enrique      6       30      70      115      200      230        641 |
 |Gilder       4       20      40       79      150      200        480 |
 o----------------------------------------------------------------------o
			
 o----------------------------------------------------------------------o
 |Blue Magic                                                            |
 |          Wevli    Quika    Wevles  Slipara  Wevlum   Wevlen     M.Exp|
 |          Exp.L1   Exp.L2   Ex.L3   Exp.L4   Exp.L5   Exp.L6     Total|
 |----------------------------------------------------------------------o
 |Vyse         4       20      55       90      165      220        554 |       	
 |Aika         6       24      65       90      175      240        600 |
 |Fina         2       12      40       95      185      250        604 |
 |Drachma      4       16      50       80      150      200        500 |
 |Enrique      8       24      65      100      175      240        661 |
 |Gilder       6       20      65       95      180      240        606 |
 o----------------------------------------------------------------------o	
 
 o----------------------------------------------------------------------o
 |Yellow Magic                                                          |
 |          Electri  Driln  Electres Electrum  Drilnos Electrulen  M.Exp|
 |          Exp.L1   Exp.L2   Ex.L3   Exp.L4   Exp.L5   Exp.L6     Total|
 |----------------------------------------------------------------------o
 |Vyse         6       16      70      130      150      230        602 |       	
 |Aika         6       16      70      130      150      230        602 |
 |Fina         2       12      70      135      160      240        619 |
 |Drachma      8       24      75      130      170      250        657 |
 |Enrique      4       16      50       95      160      210        530 |
 |Gilder       6       20      65      135      170      250        646 |
 o----------------------------------------------------------------------o 
		 	
 o----------------------------------------------------------------------o
 |Silver Magic                                                          |
 |          Curia    Risan    Eterni  Riselem  Eternes  Eternum    M.Exp|
 |          Exp.L1   Exp.L2   Ex.L3   Exp.L4   Exp.L5   Exp.L6     Total|
 |----------------------------------------------------------------------o
 |Vyse         6       14      70      115      170      250        705 |       	
 |Aika         6       14      70      115      170      250        705 |
 |Fina         4       14      65      105      155      230        648 |
 |Drachma      6       14      70      115      170      250        705 |
 |Enrique      6       14      70      115      170      250        705 |
 |Gilder       6       14      70      115      170      250        705 |
 o----------------------------------------------------------------------o

  -----------------------------------------------
  -----------------------------------------------

 -----------------------------------------------
 9 - Supermove and Crew Member Actions
 -----------------------------------------------
 
 Supermoves is the other type of ability you have at your disposal. 
 
 They are developed by eating Moonberries, pretty scarce fruits that you can 
 get rarely from battles, or found in chests sometimes. 
 
 Each character has completely different Supermoves. They do not need MP to work, 
 but they tend to consume more Spirit Points than Magic. 
 
 Beaucse Moonberries are scarce, and you need to eat several to learn late moves, 
 and you need to learn them in order, I sort of recommend to distribute the berries
 equally around your characters. Rushing a single character is not going to help
 you that much.
 
 Learning Pirate's Wrath soon is not going to help you all that much, for example.
 Your Attack won't be high enough to be all that powerful, specially when needing 
 14 Spirit points, you will waste turns gaining Spiirt for one single attack, 
 when you could use several Magic Spells, or other Supermoves and get a lot more 
 out of them. 
 
 So yeah, don't waste them. 
 
o------------------------------------------------------------------------------o
|Vyse                                                                          |
|Name            Effect                                 Elem.  SP  Target   MB | 
o------------------------------------------------------------------------------o
|Cutlass Fury	 x3.5 times the damage of a Normal Hit  Weapon  7  One Foe   --|
|Pirate's Wrath  x6.0 times the damage of a Normal Hit  Weapon 14  One Foe    4|  
|Rain of Swords  x2.4 times the damage of a Normal Hit  Weapon 10  All Foes   2| 
|Counterstrike   Defend + Counter any Normal Hit        ----    1  On  Self   1|
|Skull Shield    Blocks a Normal Hit automatically      ----    4  All Allies 2|
|                and counters it with another hit.                             |
o------------------------------------------------------------------------------o

o------------------------------------------------------------------------------o
|Aika                                                                          |
|Name            Effect                                 Elem.  SP  Target    MB| 
o------------------------------------------------------------------------------o
|Alpha Storm     220 Magic Power                        Weapon  3  Wide Line  1|
|Lambda Burst    300 Magic Power                        Red     4  All Foes   2|
|Omega PSyclone  450 Magic Power                        Weapon  6  All Foes   4|
|Epsilon Mirror  Restores 10 MP to Aika                 ----    7  On Self    2|
|Delta Shield	 Blocks ALL Magic aimed to the team     ----    4  All Allies 1|
|                also your support/healing magic!                              |
o------------------------------------------------------------------------------o

o------------------------------------------------------------------------------o
|Fina                                                                          |
|Name            Effect                                 Elem.  SP  Target    MB| 
o------------------------------------------------------------------------------o
|Lunar Glyph     250 Magic Pow.+ Chance to Petrify      Silver  1  One Foe    1|
|Lunar Winds     400 Magic Pow.+ Erase Positive Status  Silver  4  All Foes   2|
|Lunar Blessing  Regenerates 300 HP per turn            ----    6  All Allies 1|
|Lunar Cleansing Heals all Status besides Death         ----    5  All Allies 2|
|Lunar Light     Restores All HP and revives allies     ----   18  All Allies 4|
o------------------------------------------------------------------------------o 

o------------------------------------------------------------------------------o
|Drachma                                                                       |
|Name            Effect                                 Elem.  SP  Target    MB| 
o------------------------------------------------------------------------------o
|Tackle          x4.0 times the damage of a Normal Hit  Weapon  8  One Foe    1|
|Hand of Fate    x7.5 times the damage of a Normal Hit  Weapon 18  One Foe    4|
|Spirit Charge   Charges up Spirit, gainin twice the    ----    0  On Self    2|
|                normal amount and defends himself.                            |
o------------------------------------------------------------------------------o 

o------------------------------------------------------------------------------o
|Gilder                                                                        |
|Name            Effect                                 Elem.  SP  Target    MB| 
o------------------------------------------------------------------------------o
|Gunslinger      x2.6 times the damage of a Normal Hit  Weapon 10  Wide Line  1|
|The Claudia     x3.3 times the damage of a Normal Hit  Weapon 15  All Foes   4|
|Aura of Denial  Protects all teammates fron any Status ----    0  All Allies 2|
|                Effect, both Spells/abilities and from                        |
|                Normal Hits too, Eternum included.                            |
o------------------------------------------------------------------------------o 

o------------------------------------------------------------------------------o
|Enrique                                                                       |
|Name            Effect                                 Elem.  SP  Target    MB| 
o------------------------------------------------------------------------------o
|Royal Blade	 x3.5 times the damage of a Normal Hit  Weapon  7  One Foe    1|
|The Judgement   x6.0 times the damage of a Normal Hit  Weapon 14  One Foe    4|  
|Justice Shield  Halves any damage taken on that Round  ----    8  All Allies 2|
o------------------------------------------------------------------------------o 

o------------------------------------------------------------------------------o
|Team-based Supermoves (All teammates must be alive)                           |
|Name            Effect                                 Elem.  SP  Target      | 
o------------------------------------------------------------------------------o
|Blue Rogues	 Causes damage and heals your team based  --  All  Everyone    |
|                on the crew members active.                                   |
|Prophecy        All four characters combine their power  --  All  All Foes    |  
|                to damage all enemies on the field.                           |
o------------------------------------------------------------------------------o 


 -------------------
 Crew Member Actions
 -------------------
 
 Once you get a big enough ship, you can start sailing around the world, trying to 
 find people to join your cause! Each crewmember can do something special, and there's 
 two people for each position.

 Crewmembers can be divided between Passive Effects, which are constantly working, but 
 tend to give more subtle improvements, and Active Effects, which work like Supermoves.
 
 I can't really tell you which are "the best" because it depends a lot on at what point 
 of the game you are, how do you like to get your ship battles done and such.
 
 Special mention to Osman and Kalifa. Their ability to find unique items in, often, 
 ship battles you can only do once is very important. You should recruit them as soon 
 as possible.
 
 For Osman, right after she loses her business.
 For Kalifa, right after you come back from Yafutoma with a Suiran Blade (from the shop).
 
 Below you have a list of what battles need which character on duty to receive the extra 
 rewards.

 o------------------------------------------------------------------------------------o
 |Name      Type    Effect                                                            |
 o------------------------------------------------------------------------------------o
 |Lawrence  Pasive  Increases Quick by 40.                                            |
 |Don       Pasive  Increases Dodge by 20%.                                           |
 o------------------------------------------------------------------------------------|
 |Brabham   Pasive  Increases Defense   by 40.                                        |
 |Hans      Pasive  Increases M.Defense by 40.                                        |
 o------------------------------------------------------------------------------------o
 |Belle     Pasive  Increases by 45 the damage of Secondary Cannons.                  |
 |Khazim    Pasive  Increases by 35 the damage of Main Cannons.                       |
 o------------------------------------------------------------------------------------o
 |TikaTika  Pasive  Increases Torpedo Accuracy.                                       |
 |Domingo   Active  Increases Chance of causing Critical Damage.                  5 SP|
 o------------------------------------------------------------------------------------o
 |Osman     Pasive  Makes extra items appear in specific Ship Battles.                |
 |Kalifa    Pasive  Makes extra items appear in specific Ship Battles.                |
 |Note:             Each member finds different things in different battles!          |
 o------------------------------------------------------------------------------------o
 |Izmael    Pasive  Increases the power of the Moonstone Cannon by 100.               |
 |Kirala    Active  Restores the Ship's HP completely.                                |
 o------------------------------------------------------------------------------------o
 |Polly	    Active  Restores 10 MP to the Character that uses this command.       4 SP|
 |Uralla    Active  Maxes out the Spirit Points.                                 15 SP|
 o------------------------------------------------------------------------------------o
 |Ryu-Kan   Active  Raises Attack & Defense higly for 1 Round.                   15 SP|
 |Ylchimis  Active  Raises All Stats moderately   for 1 round.                   10 SP|
 o------------------------------------------------------------------------------------o
 |Marco     Active  Doubles the amount of Spirit restored for one Round.          6 SP|
 |Robinson  Active  Halves  the cost of Spirit for one Round.                     6 SP|
 o------------------------------------------------------------------------------------o
 |Pow       Active  Increases chance of attacking First for 1 Round.              4 SP|
 |Merida    Pasive  Raises Quick by 20.                                               |
 o------------------------------------------------------------------------------------o
 |Moegi     Active  Blocks all magical  damage received for 1 Round              12 SP|
 |Pinta     Active  Blocks all physical damage received for 1 Round              12 SP|
 o------------------------------------------------------------------------------------o

 Remember, you can only use an active command once per battle!
 -------------------------------------------------------------------------------------

 --------------------------------------------
  10 - Weapon & Cupil, Armor and Accessories
 --------------------------------------------
 
 Not much to say here. I changed weapons around a little. There are more 
 Status Effects, some characters got a boost in their weapons and I also 
 added a new effect to each weapon.

 There is space in the code for an extra bonus effect, and it's used very,
 very little. Originally, it was to add Elemental resistance to a few weapons,
 and curiously enough I haven't seen this being said in guides (although I may
 be wrong). I used it to make each weapon a little more interesting.
 
 Also, remember you can change your equipment (Not only weapon!) 
 in the middle of a battle!

 Oh, a last note: If something gives bonus Vigor, it means it gives both 
 Defense and Magic defense.

 Vyse:
+-------------------------------------------------------------+
|Name		     Attack  Hit  Status Eff. Extra Effect        |
+-------------------------------------------------------------+
 Cutlass           20     90  Nothing     Nothing
 Pirate Cutlass    33     90  Silence     Quick  +5
 Sky Cutlass       45     90  Nothing     Vigor  +5
 Assassin Blade    58     90  Poison      Will   +5
 Nasr Cutlass      70     95  Nothing     First Strike Chance 10%
 Hunter's Sword    87     90  Confusion   Confusion Resistance
 Stonecutter      100     95  Silence     Stone Resistance
 Iron-Cutter      112     90  Nothing     Weaken Resistance
 Sword of Daccat  120     90  Sleep       Causes enemies to Flee
 Admiral Cutlass  128     90  Nothing     Vigor +10
 Dream Cutlass    137     90  Nothing     Blue Resistance
 Suiran Blade     141     95  Nothing     Will  +10
 Windslicer       155     90  Poison      Quick +10
 Thunder Cutlass  165     95  Nothing     Yellow Resistance
 Soul sword       178    100  Silence     Will  +25
 Vorlik Blade     210     90  Nothing	  Silver Resistance
 Tuna Cutlass     160    110  Sleep	      Dodge +15
 Sky Fang         230    100  Nothing     Nothing
 -------------------------------------------------------------
 
 Aika;

+-------------------------------------------------------------+
|Name		     Attack  Hit  Status Eff. Extra Effect        |
+-------------------------------------------------------------+
 Boomerang         20    110  Nothing     Nothing
 L. Crescent       30    110  Sleep       Dodge +5
 Throwing Blade    40    120  Nothing     Will  +5
 Valuarang         54    110  Nothing     Vigor +5
 Scout Wing        62    110  Sleep       Sleep Resistance
 Dancing Arc       70    110  Weaken      Silence Resistance
 Storm Wing        80    110  Weaken      Blue Resistance
 Hunting Arc       93    110  Nothing     Will  +10
 Grendel Wing     112    130  Nothing     Green Resistance
 Skywing          120    110  Nothing     Quick +10
 Wing of Hope     131    120  Nothing     Confusion Resistance
 Yin Wing         142    110  Sleep       Dodge +10
 Ice Splitter     157    120  Nothing     Purple Resistance
 Flutter Blade    165    110  Confusion   Vigor +10
 Moon Wing        170    110  Stone       Will  +25
 Swirlmerang      150    160  Confusion   Dodge +15
 Hydra Wing       200    115  Nothing     Silver Resistance
 -------------------------------------------------------------
 
 Drachma:

+-------------------------------------------------------------+
|Name		     Attack  Hit Status Eff. Extra Effect         |
+-------------------------------------------------------------+
 Artificial Arm    50    80  Nothing     Vigor   +5
 Hook Hand         58    80  Silence     Poison Resistance
 Beak Hand         66    80  Confusion   Quick   +7
 Excavation Arm    75    80  Stone       Will    +10
 Mace Hand        130    40  Nothing     Defense +12
 De Loco Drill    100    80  Death       Resist Confusion
 Ruin Arm         115    85  Nothing     Stone Resistance
 Mining Arm       180    80  Stone       Dodge +8
 Dragon Arm       230    80  Nothing     Vigor +15
 Silver Arm       210    85  Sleep       Silver Resistance
 -------------------------------------------------------------
 
 Gilder:

+-------------------------------------------------------------+
|Name		     Attack	 Hit  Status Eff. Extra Effect        |
+-------------------------------------------------------------+
 Gilder's Own     110    100  Nothing     Quick +5
 Nasr Pistol      118    100  Confusion   Red Resistance
 Daccat Custom    127    100  Sleep       Dodge +7
 MarksMan Gun     100    200  Death       Will  +10
 Valuan Pistol    175    110  Weaken      Yellow Resistance
 Gilder Special   188    100  Silence     Vigor +10
 Warrior Pistol   200    110  Nothing     Dodge +12
 -------------------------------------------------------------
 
 Enrique:

+-------------------------------------------------------------+
|Name            Attack  Hit Status Eff. Extra Effect         |
+-------------------------------------------------------------+
 Rapier           127    95  Silence     Quick +5
 Blade of Slumb.  143   100  Sleep       Will  +10
 Frostblade       157    95  Confusion   Purple Resistance
 Imperial Blade   168    95  Silence     Vigor +10
 Stoneblade       185    95  Stone       Stone Resistance
 Serpent Strike	  200    95  Stone       Quick +15
 -------------------------------------------------------------

 Fina & Cupil: 

+---------------------------------------------------------------------------------------------+
|Name		 Attack	  Hit  Status Eff.  Extra Effect     0 Abirik Chams Route - Focus on Hit  |
+---------------------------------------------------------------------------------------------+
 Cupil    	    65    120  Nothing	    Nothing          00 Chams 
 Blade          75    125  Sleep        Quick +5         02 Chams 
 Cone           80    125  Weaken       Vigor +5         04 Chams 
 Sword          95    125  Sleep	    Dodge +5         08 Chams 
 Star          110    130  Silence      Will  +10        12 Chams 
 Cutlass       130    130  Sleep        Dodge +12        16 Chams 
 Spear         155    130  Poison       Quick +12        20 Chams 
 Claymore      170    130  Sleep	    Will  +25        24 Chams 
+---------------------------------------------------------------------------------------------+
|Name	 	 Attack	  Hit  Status Eff.  Extra Effect	 1 Abirik Cham Route - Focus on Attack|
+---------------------------------------------------------------------------------------------+
 Cannon        100    105  Weaken	    Quick +7         02 Chams, 1 Abirik Cham 
 Club          115    110  Confusion    Vigor +7         08 Chams, 1 Abirik Cham 
 Lance         130    110  Silence	    Dodge +10        12 Chams, 1 Abirik Cham 
 Spike         150    105  Confusion    Will  +15        16 Chams, 1 Abirik Cham 
+---------------------------------------------------------------------------------------------+
|Name	 	 Attack	  Hit  Status Eff.  Extra Effect	 2 Abirik Cham Route - Focus on Attack|
+---------------------------------------------------------------------------------------------+
 Hammer        130    120  Stone 	    Vigor +10        08 Chams, 2 Abirik Chams
 Pan           145    120  Confusion    Dodge +10        12 Chams, 2 Abirik Chams 
 Weight        200    100  Confusion    Vigor +25        24 Chams, 2 Abirik Chams
+---------------------------------------------------------------------------------------------+
|Name	 	Attack	  Hit Status Eff.   Extra Effect         3 Abirik Cham, 30 Chams          |
+---------------------------------------------------------------------------------------------+
 Final         350    110 Nothing      (Nothing, It's already the most powerful weapon)
 ---------------------------------------------------------------------------------------------
 
 Chart of Transformations (No changes here, but added for the sake of completion).
 
----------------------------------------------------------------------------------------------
   0 Abirik Chams            1 Abirik Cham             2 Abirik Chams           3 Abirik Chams
----------------------------------------------------------------------------------------------
  00 Cupil Normal 
  02 Cupil Blade  --------> 02 Cupil Cannon            
  04 Cupil Cone             08 Cupil Club   --------> 08 Cupil Hammer ---o
  08 Cupil Sword            12 Cupil Lance  --------> 12 Cupil Pan       |
  12 Cupil Star             16 Cupil Spike            24 Cupil Weight    |
  16 Cupil Cutlass               |       |                          |    |
  20 Cupil Spear  <--------------o       0--------<-------------<---�----o
  24 Cupil Claymore                                                 |
       |                                                            |
	   o---------------------------------------------------------------------> 30 Final Cupil 
	   
----------------------------------------------------------------------------------------------


 -------------
 Armor Changes
 -------------

 Not many changes here, just a bit of extra effects and some ajustments. Some prices were 
 changed too.
 
 Remember that, if a piece of equipment offers a particular elemental resistance, the effect 
 is a 20% damage reduction. So if an attack would do 800 damage, it would absorb 160. 

  Men Clothes
 +--------------------------------------------------------------------------+-----------+
 |Name	 	       P.Def. M.Def  Effect 1		        Effect 2	        |V A F D G E|
 +--------------------------------------------------------------------------+-----------+
  Drachma's Shirt     45     42  ---	                ---	                 X X X O X X
  Heavy Armor         58     53  ---                    ---	                 O X X O O O
  Flame Mantle        75     70  Red Ele. Resistance    ---	                 O O O O O O
  Miner's Overalls    90     80  Stone Resistance		---	                 O X X O O O
  Nasr Uniform       104     96  ---                    ---	                 O X X O O O
  Scale Mail         141    130  ---                    ---	                 O X X O O O
  Vengeance Armor    165    150  Counter Attack 20%     ---	                 O X X O O O
  Berzerker Mail     155    155  Attack +25             Hit +15              O O O O O O		
 ---------------------------------------------------------------------------------------

  Women Clothes
 +--------------------------------------------------------------------------+-----------+
 |Name	 	       P.Def. M.Def  Effect 1		        Effect 2	        |V A F D G E|
 +--------------------------------------------------------------------------+-----------+
  Aika's Shorts       19     21  ---                    ---                  X O O X X X
  Mystic Dress        42     50  Weak Resistance        ---                  X O O X X X
  Female Armor        92     99  ---                    ---                  X O O X X X
  Maiden's Armor     103    112  ---                    ---                  X O O X X X
  Moonlight Robe     134    145  Dodge +20              ---                  X O O X X X
  Swift Dress        155    170  Quick +20              ---                  X O O X X X
  Light Dress         70     70  Dodge +30              Quick +30            X O O X X X
  Focus Robe         110    110  Will  +75              ---                  X X O X X X
 --------------------------------------------------------------------------------------------------------------------

  Sailor Outfits
 +--------------------------------------------------------------------------+-----------+
 |Name	 	       P.Def. M.Def  Effect 1               Effect 2	        |V A F D G E|
 +--------------------------------------------------------------------------+-----------+
  Vyse's Uniform      20     20  ---                    ---                  O O X X O X
  Valuan Uniform      33     33  ---                    ---                  O O X O O X
  Sailor Uniform      45     45  Quick +5               ---                  O O X O O X
  Raincoat            56     56  Blue Resistance        ---                  O O X O O X
  Daccat's Armor     108    108  Sleep Resistance       ---                  O O O O O O
  Naval Uniform      112    112  ---                    ---                  O O X O O X
  Ghost Mail         126    126  Will +10               ---                  O O X O O X
  Soranchu Robe      136    136  Will +15               ---                  O O O O O O
  Captain Cloak      145    145  Will +20               ---                  O O O O O O	
  Gaia Cape          155    155  Will +35               Quick +5             O O O O O O 
 --------------------------------------------------------------------------------------------------------------------

  Regal Dress
 +--------------------------------------------------------------------------+-----------+
 |Name	 	       P.Def. M.Def  Effect 1               Effect 2	        |V A F D G E|
 +--------------------------------------------------------------------------+-----------+
  Agile Robe          65     70  Hit +10                Dodge +5             X X O X X O
  Light Coat         103    113  Hit +10                Dodge +5             X X O X X O
  Enrique's Coat     120    130  Hit +10                Dodge +5             X X O X X O
  Moss Armor         126    140  Hit +20                Dodge +10            X X O X X O
  Long Robe          130    145  Hit +20                Dodge +10            X X O X X O
  Blessed Robe       142    142  Hit +25                Dodge +15            X X O X X O
  Robe of Faith      155    155  Hit +25                Dodge +15            X X O X X O
 --------------------------------------------------------------------------------------------------------------------

  Armor
 +--------------------------------------------------------------------------+-----------+
 |Name	 	       P.Def. M.Def  Effect 1               Effect 2	        |V A F D G E|
 +--------------------------------------------------------------------------+-----------+
  Valuan Armor        52     45  ---                    ---                  O X X O O X
  Ceramic Armor       75     65  Dodge  +5              ---                  O X X O O X
  Golden Armor        90     77  Attack +5              ---                  O X X O O X
  De Loco Mail        99     84  ---                    ---                  O X X O O X
  Caravan Armor       75     75  Red Resistance         Purple Resistance	 O O O O O O
  Gilder's Mail      116    100  Hit +10                ---                  O X X O O X
  Battleworn Armor   133    114  ---                    ---                  O X X O O X
  Fiber Mail         165    140  Attack +10             ---                  O X X O O X
  Plated Armor       190    170  ---                    ---                  O X X O O X
 --------------------------------------------------------------------------------------------------------------------

  Magic Garment
 +--------------------------------------------------------------------------+-----------+
 |Name	 	       P.Def. M.Def  Effect 1               Effect 2	        |V A F D G E|
 +--------------------------------------------------------------------------+-----------+
  Light Robe          30     37  Will +5                ---                  X O O X X O
  Fina's Robe         55     65  ---                    ---                  X O O X X O
  Ancient's Robe      69     82  ---                    ---                  X O O X X O
  Fiber Robe          75     95  Will +10               ---                  O O O X X O
  Holy Robe           92    108  ---                    ---                  X O O X X O
  Miracle Robe       114    133  ---                    ---                  X O O X X O
  Moon Robe          140    165  Will +10               ---                  X O O X X O
  Robe of Truth      170    190  ---                    ---                  X O O X X O
 --------------------------------------------------------------------------------------------------------------------

  General Clothing
 +--------------------------------------------------------------------------+-----------+
 |Name	 	       P.Def. M.Def  Effect 1               Effect 2	        |V A F D G E|
 +--------------------------------------------------------------------------+-----------+
  Elastarmor          54     54  Yellow Resistance      ---                  O O O O O O
  Nasrean Mail        66     66  Red Resistance         ---                  O O O O O O
  Nasr Combat Mail    66     66  Attack +5              Will +5              O O O O O O
  Victory Mail        90     90  Attack +5              Will +5              O O O O O O
  Ixa'takan Armor    109    109  Green Resistance       ---                  O O O O O O
  Daccat's Tunic     121    121  Blue Resistance        ---                  O O O O O O
  Insulated Mail     145    145  Purple Resistance      ---                  O O O O O O
  Silver Armor       160    160  Silver Resistance      ---                  O O O O O O
 --------------------------------------------------------------------------------------------------------------------

 -------------------
 Accessories Changes
 -------------------

 I took the liberty to reorganize the order of the items in the menu to make them easier 
 to look through, (That is, when pushing Y while on the item screen, each group would 
 be organized by name, or by it's internal code number). The order is the one in these lists. 

 Just like the others, some prices were changed.
 They've been separated in groups depending on their effects, and to make it easier to read.

 +----------------------------------------------------------------------------------+-----------+
 |Name	 	        Effect1         Effect2         Effect3         Effect4         |V A F D G E|
 +----------------------------------------------------------------------------------+-----------+
  Meditation Ring   Will    +8      ---             ---             ---              O O O O O O
  Lover's Ring      Will   +12      M.Def   +12     ---             ---              O O O O O O
  Moondust Ring     Will   +30      M.Def   +15     Def +15         ---              O O O O O O
  Jade Swirl Ring   Will   +40      M.Def   +30     ---             ---              O O O O O O
  Cupil Ring        Will   +50      M.Def   +30     Death Immunity  Silver Resist.   X X O X X X
  Gemstone Ring     M.Def  +25      Defense +15     ---             ---              O O O O O O
  Prophet's Sand    M.Def  +65      Will    +10     ---             ---              O O O O O O
  Warrior's Heart   Spirit Recov.   Attack  +10     Will  +10       ---              O O O O O O
  Fortune Ring      Dodge +100      Defense +10     ---             ---              O O O O O O		
 -----------------------------------------------------------------------------------------------
  Note: On a practical level, Fortune's Ring "Dodge +100" effect makes you impossible to hit 
        by normal attacks, and normal attacks only. 

 +----------------------------------------------------------------------------------+-----------+
 |Name	 	        Effect1         Effect2         Effect3         Effect4         |V A F D G E|
 +----------------------------------------------------------------------------------+-----------+
  Throkyryn's Scale Attack  +10     ---             ---             ---              O O O O O O
  Thryllak's Scale  Attack  +30     Defense  +15    ---             ---              O O O O O O
  Vigoro's Chain    Attack  +25     Hit      +30    ---             ---              O O O O O O
  Marocca's Shell   Defense +10     ---             ---             ---              O O O O O O 
  Burocca's Shell   Defense +40     Attack   +10    ---             ---              O O O O O O
  Defensive Aura    Defense +40     Invulnerable    ---             ---              O O O O O O
  Crylhound's Claw  Hit     +30     Attack    +5    ---             ---              O O O O O O
  Hunter's Hand     Hit     +30     Power    +20    ---             ---              O O O O O O
  Thief's Aura      Dodge   +13     Defense   +5    ---             ---              O O O O O O
  Quetya Feather    Dodge   +25     Defense  +10    ---             ---              O O O O O O  
  The Unseen Hand	Dodge   +10     Quick    +30    ---             ---              O O O O O O
  Sailor's Buckler  Defense +15     M.Def.   +15    Dodge   +15     ---              O O O O O O
  Warrior's Rune    Attack  +15     Defense  +10    Hit     +20     Dodge   +10      O O O O O O 
  Ancient Bracer    Attack  +25     Defense  +20    Hit     +30     Dodge   +15      O O O O O O
  Counter Bracer    Attack  +20     Hit      +20    Counter +20     ---              O O O O O O 
 ------------------------------------------------------------------------------------------------------
  Note: Hunter's Hand "Power +20" effect does raise the damage of Main Cannons during Ship 
        battles. 

 +----------------------------------------------------------------------------------+-----------+------------+
 |                                                                                  |           | Only       |
 |Name	 	        Effect1         Effect2         Effect3         Effect4         |V A F D G E| Dropped by:|
 +----------------------------------------------------------------------------------+-----------+------------+
  Ivy Band          Defense +20     M.Def.   +20    Poison  Resist. Green   Resist.  O O O O O O  Varkris,  Dralnog,   Medulizk
  Eye of Truth      Defense +20     M.Def.   +20    Confus. Resist. Red     Resist.  O O O O O O  Azbeth,   Slothstra, Feralisk
  Revered Voice     Defense +20     M.Def.   +20    Silence Resist. Purple  Resist.  O O O O O O  Scorfly,  Scorpon 
  Wind Gem Ring     Defense +20     M.Def.   +20    Sleep   Resist. Blue    Resist.  O O O O O O  Tsurak,   Langry 
  Behemoth's Ring   Defense +20     M.Def.   +20    Weak    Resist. Yellow  Resist.  O O O O O O  Dung Fly, Durel Beetle
  Silvite Ring      Defense +20     M.Def.   +20    Death   Immun.  Silver  Resist.  O O O O O O  Azbeth,   Jynnus
  Everlasting Gem   Defense +25     M.Def.   +25    Fatigue Resist. ---              O O O O O O
  Gem of Fluidity   Defense +25     M.Def.   +25    Stone   Resist. ---              O O O O O O
  Chance Ring       Defense +60     M.Def.   +60    Can't Resist Status Effects      O O O O O O
  Constitution Gem  Defense +15     M.Def.   +15    Resists All Status.              O O O O O O
 -------------------------------------------------------------------------------------------------------------

 +----------------------------------------------------------------------------------+-----------+
 |Name	 	        Effect1         Effect2         Effect3         Effect4         |V A F D G E|
 +----------------------------------------------------------------------------------+-----------+
  Mage's Bane       Attack   +5     Will      +5    Defense  +5     M.Def  +5        O O O O O O
  Blue Rogue Patch  Attack  +20     Will     +20    Defense +20     M.Def +20        O O O O O O 
  Nomadic Veil      Defense +12     M.Def    +12    ---             ---              O O O O O O
  Radiant Fur       Defense +30     M.Def    +30    Counter 15%     ---              O O O O O O
  Sand Storm Ring   Attack  +10     Will     +10    ---             ---              O O O O O O
  Skull Cap         Attack  +25     Will     +25    ---             ---              O O O O O O
  Assassin Ring     Hit     +40     First Strike    ---             ---              O O O O O O
  Nocturnal Sight   Hit     +60     Attack   +15    Will    +15     ---              O O O O O O
  Critical Vision   Hit     +50     Attack   +20    Will	+20     ---              O O O O O O
  Stealth Ring      Run Away        Quick    +15    Dodge   +10     ---              O O O O O O
  Crescent Amulet   Quick   +20     Defense  +30    M.Def   +30     ---              O O O O O O
  Dhabu Hide        Quick   +50     Attack   +10    Will    +10     ---              O O O O O O
  Ominous Mask      SP No Recovery  Attack   +60    Defense +60     ---              O O O O O O
  Captain's Hat     Power   +30     Will     +30    Quick   +20     ---              O O O X X X 
 ------------------------------------------------------------------------------------------------
  Note: Captain's Hat "Power +30" effect does raise the damage of Main Cannons during Ship 
        battles. 

  Companion Only Accessories
 +----------------------------------------------------------------------------------+-----------+
 |Name	 	        Effect1         Effect2         Effect3         Effect4         |V A F D G E|
 +----------------------------------------------------------------------------------+-----------+
  Gem of Purity     Defense +10     Low Resitance to all Status                      X X X O O O 
  Immunity Ring     Defense +20     Medium Resistance to all Status                  X X X O O O
  Shard of Purity   Defense +40     High Resistance to all Status                    X X X O O O
 ------------------------------------------------------------------------------------------------

  Special
 +----------------------------------------------------------------------------------+-----------+
 |Name	 	        Effect1         Effect2         Effect3         Effect4         |V A F D G E|
 +----------------------------------------------------------------------------------+-----------+
 *Skyseer Goggles*  Hit      +5     Lower Random Encounters         ---              O X X X X X 
  Flash Ribbon      Quick    +5     Dodge +3        ---             ---              O O O O O O
  Black Eyepatch    Attack   +8     Counter +15     ---             ---              O O O O O O
  Silver Veil       Will    +16     M.Def.  +16     ---             ---              O O O O O O
  Gilder's Amulet   Defense +15     M.Def.  +15     Attack  +10     Will  +10        O O O O O O
  Imperial Crest    Defense +25     M.Def.  +25     Will    +10     ---              O O O O O O
  Valuan Medallion  Defense +30     M.Def.  +30     Death Resist.   ---              O O O O O O  
  Thermo Ring       Red Resist.     Purple Resist.  Quick   +10 	Will  +10        O O O O O O
  Slayer Ring       Will	+12     Defense +10     Hit 	+15     Quick +10        O O O O O O
  Mesh Tights       Attack +40      Will  +40       ---             ---              O O O X X X
  Black Map         First Strike +  Double Random Encounters        Enemies Run Away O X X X X X
  White Map         First Strike -  Lower Random Encounters More    You RunAway 100% O X X X X X
 -----------------------------------------------------------------------------------------------

 The Skyseer Goggles on older versions of this hack had the sort of important ability to 
 lower the Encounter Rate, which is kinda high, and was higher on the original Dreamcast 
 version. 
 
 This effect is still existing, but now you can use the extra patch mentioned in the 
 "How to Install" section at the top of this readme to have a better way of avoiding battles.

 Please don't abuse it much or your Levels will get behind and make things harder for yourself.

 -----------------------------------------------
 -----------------------------------------------

 -----------------------------------------------
 11 - Item and Fish
 -----------------------------------------------

 Items in Skies of Arcadia, to me, have always been one of the most exagerated
 elements in the game. Exceedinly cheap, effects just as strong as Magic, but 
 without MP or SP costs. 
 
 So one of the most important changes on this hack was to adjust them to be 
 more of an aid than a cheap, cheap substitute to the Magic System or even 
 some Supermoves. 
 
 Effects, duration in some cases, prices and such were tweaked. 
 
 In case of Fish, I went ahead and made most of them do something. In vanilla,
 most of them were useless, only for selling and even then they gave little gold.
 
 Now almost every Fish sports some effect, with many being harder to get but 
 much more useful healing items that you can use only out of battles. 

 A Sardis is better restoring your HP than a Sacri Crystal, for example.  
 
 Some Fish can improve slightly your Stats, too, but as mentioned above, 
 it's not something you can abuse without paying a price. But some can 
 be useful to raise your HP a few points whenever you find a school of fish.

 -----------------------------------------------
 Restorative Items
 ---------------------------------------------------------------
 Name             Effect                       Price/Reselling %
 ---------------------------------------------------------------
 Sacri Crystal	  Restores  300 HP One Ally         20 Gold, 50%
 Sacres Crystal   Restores  700 HP One Ally        150 Gold, 50%
 Sacrum Crystal   Restores  800 HP All Allies      700 Gold, 50%
 Sacrulen Crystal Restores 3000 HP One Ally       2000 Gold, 50%
 ---------------------------------------------------------------
 Magic Droplet	  Restores    1 MP                  60 Gold, 50%
 Magic Dew  	  Restores    6 MP                 800 Gold, 50%
 Kabal Skewer     Restores   20 MP (Only one!)    1500 Gold, 50%
 Mom Skewer       Restores Full MP (Only one!)     200 Gold,100%
 ---------------------------------------------------------------
 Risan Crystal	   50% Resurrection,  50% HP       750 Gold, 50%
 Riselem Crystal  100% Resurrection, 100% HP      1500 Gold, 50%
 ---------------------------------------------------------------
 Curia Crystal	  Cures non-Death Status Effects    50 Gold, 50%
 ---------------------------------------------------------------
 Healing Salve	  Regen. Effect, 250HP 1 Char.     500 Gold, 50%
 ---------------------------------------------------------------
 Urala's Lunch    Restores Full HP and MP.         200 Gold,100%
 Polly's Special  Restores Full HP and MP.         200 Gold,100%
 ---------------------------------------------------------------
 Other Items
 ---------------------------------------------------------------
 Name             Effect		         Price/Reselling %
 ---------------------------------------------------------------
 Paranta Seed	  Permanent increase Power +5	10000 Gold, 15%
 Icyl    Seed	  Permanent increase Will  +5   10000 Gold, 15%
 Zaal    Seed     Permanent increase Vigor +5   10000 Gold, 15%
 Dexus   Seed     Permanent increase Agile +1   10000 Gold, 15%
 Sylph   Seed     Permanent increase Quick +5   10000 Gold, 15%
 Vidal   Seed     Permanent increase HP    +50  10000 Gold, 15%
 Magus   Seed     Permanent increase MP    +5   10000 Gold, 15%
 Tropica          Permanent increase HP    +200  1000 Gold,100%
 ---------------------------------------------------------------
 Battle Buffing Items
 ---------------------------------------------------------------
 Name             Effect                       Price/Reselling %
 ---------------------------------------------------------------
 Glyph of Might   Raises Atk & Def of one Char.	 8000 Gold,  50%
 Glyph of Speed   Raises the Speed of the Team.  4000 Gold,  50%
 ---------------------------------------------------------------
 Ship Restorative Items
 ---------------------------------------------------------------
 Name         Effect                                       Price
 ---------------------------------------------------------------
 Repair   Kit Restores  4.000 HP to the Ship                 150
 Deluxe   Kit Restores  8.000 HP to the Ship                 400
 Fabulous Kit Restores 20.000 HP to the Ship                5000
 Gear Grease  Increases SP                                  8000
 Apa Wax	  Increase Atk & Def 1 Turn                     3000
 Apo Wax	  Increase Atk & Def 2 Turns                    6000
 Speed Wax	  Increases Speed 1 Turn                        2500
 Hybrid Wax   Increases All Stats 1 Turn                    8000
 ---------------------------------------------------------------
 Restorative Fish Effect                           Selling Price
 ---------------------------------------------------------------
 Sky Sardis       Restores  400 HP                       40 Gold
 Red Sardis	      Restores  900 HP                      120 Gold
 Grule            Restores 1000 HP to the Team          480 Gold
 Drajik           Restores 1500 HP to the Team         3000 Gold
 Flying Fish	  Restores  2 MP                         80 Gold
 Spiked Sunfish   Restores  6 MP                        200 GOld
 Romuhai          Restores 10 MP                        400 Gold
 ---------------------------------------------------------------
 Stat Increasing Fish                              Selling Price
 ---------------------------------------------------------------
 Spear Squid     Increases HP by   5 Points             320 Gold 
 Kite ray        Increases HP by  15 Points             360 Gold 
 Red Dragon      Increases HP by  30 Points            1500 Gold	 
 Stealth Ray     Increases MP by   1 Point              640 Gold
 Drill Squid     Increases MP by   2 Points             680 Gold
 Rainbow Grule   Increases Power by 2 Points            640 Gold
 Silverfish      Increases Will  by 2 Points            640 Gold
 Hamahai         Increases Vigor by 2 Points            640 Gold
 Gr. Nerath Eel  Increases Quick by 2 Points            640 Gold
 Gold Dragon     Increases Agile by 1 Point            1600 GOld
---------------------------------------------------------------
 Selling Fish                                      Selling Price
 ---------------------------------------------------------------
 Sky Jellyfish  No use, but is good for selling         500 Gold
 Nerath Eel     No use, but is good for selling         800 Gold

 ------------------------------------------
 About Stat-Increasing Items:
 ------------------------------------------

 Already explained above, but here's the thing again.
 
 Using Stat-raising items will make the next Level Up provide you 
 with less Stat gains, as the game works on a system that checks 
 what the average Stats a character should get based on their personal 
 growths. If it's above, it will give you less points for that Stat.

 So, at least in my eyes, stat-increasing items are more of a "Hey, X 
 Character grew very little in Y stat! Let's give him/her a boost". 
 Mostly because you would be wasting items that way.

 Now, this holds true for Power, Will, Vigor and Quick. Agile (which affects Dodge%) 
 doesn't grow, and if you want to increase it, you do it by using items.
 
 After Level 65, character's Stat gains seems much more randomized, and Stat
 raising items do not get affected by the growth it seems. 
 
 But there's no reason to level that high. You can beat the game 20 Levels before
 that, and grinding to that points is going to get very, very old for nothing.
 
 HP and MP are not affected by this; but before you go running to get some Items,
 remember that HP raises very slowly, and regardless of how much MP you have,
 you still have to learn Spells and deal with the Spirit costs.
 
 WARNING!!! 

 Either if you want to abuse these items or just make the game easier for whatever reason, 
 be aware to not go overboard with stat increasing items against the last boss. 

 It kind of backfires in your face if the game wants to. This is also true for the
 original game, though.

  -----------------------------------------------
  -----------------------------------------------

 -------------------------
 12 - Ship Equipment					      
 -------------------------

 Having your vessel well prepared is vital to keep you alive, and there's a lot of gear 
 for you to choose from!
 
 I did some tweaking to the Ship gear. In case of weapons, I wanted to mark some 
 differences between things you would get more or less at the same points in the 
 game. For example, if you would get two Secondary Cannons close to each other, 
 one could offer more Accuracy, and the other more Power, or something to that effect.
 
 For defensive gear, in the vanilla game things were exceptionally simple. Decks 
 only gave Defense. Figures only Magic Defense, and Engines Quick and a bit of Dodge.
 
 Now there's more variety, specially with the "Decorative" parts now granting stat
 boosts, expanding the possibilities to set up, and also bringing pieces of equipment
 that was left unused in the game. 

 o------------o
 |Main Cannons|
 o------------o
 As their name imply, their the main weapon of choice during Ship Battles to cause 
 physical damage. 

 At first sight it might look like Secondary Cannons are more powerful by comparing their 
 Attack values but make no mistake, the Main Cannon's come on top because they use the Power
 of the character using it, making them significantly stronger, specially if used by Drachma 
 or Gilder. 
 
 Equipment that increases Attack on your characters does not increase the damage of using 
 Main Cannons, but a couple of accessories increase Power, which does raise it, so you 
 might want to equip them before sailing around. 

 Khazim can add power to Main Cannons, and is the favourite crew member of many sailors out there.
				    Shop
 Name              Att  Hit Sp  Lim  Price   Location                         Ship
 ----------------------------------------------------------------------------------------------------
 Main Cannon        35  80   4    0    450   Little Jack comes with it        Little Jack
 Standard Cannon    40  83   4    0   1000   Sailors' Island After 1st Escape Little Jack
 Heavy Cannon       45  85   5    0   1900   Maramba Ship Parts Shop          Little Jack
 G-Type Cannon      60  90   5    0   3000   Horteka BlackMarket              Little Jack
 B-Type Cannon	    75  80   5    0   4000   Chamaleon First Fight            Little Jack
 Prototype Cannon  100  85   6    0   5000   Delphinus comes with it          Delphinus
 Advanced Cannon   150  90   7    0   5500   Nasrad, Esperanza Shop           Delphinus       
 Yamato Spirit     250  90   8    0   6700   Yafutoma Ship Parts Shop         Delphinus
 Ancient Cannon    300  95   8    0   8500   Crescent Island Shop             Delphinus
 X Cannon          400  95   9    0  11000   Sailors' Island                  Delphinus
 Moon Cannon       500  80   9    0   1000   Hydra Fight                      Delphinus
 Pyril Cannon      330 120   6    0  13200   Sailors' Isle   -Red Element-    Delphinus
 Crystil Cannon    550  75   4    0   1000   Galcian's Elite -Purple Element- Little Jack & Delphinus
 ----------------------------------------------------------------------------------------------------    

o-----------------o
|Secondary Cannons|
o-----------------o 
 Secondary Cannons are quite different to Main Cannons. They do not take advantage of 
 the user's Power, but they grant the possibility of attacking several turns in a row!
 
 In fact, you can even organize them so they attack during the early turns of the next 
 round! And not using the Power of your characters isn't that bad as it gives you 
 the chance of using whoever is available, making it more flexible. 
 
 It takes more Spirit to attack several times, of course, but thanks to that, you can 
 combine a Main Cannon and a Secondary Cannon on the same round, possibly a Critical 
 round, and cause some extra damage. Even more if you can string several combos! 
 
 Belle can strengthen the power of Secondary Cannons, and it can be very handy if you 
 like to make long strings of attacks, specially in combination with the Magic Cannon.
				    Shop
 Name              Att  Hit Sp  Lim  Price   Location                         Ship
 ----------------------------------------------------------------------------------------------------
 3"Cannon           60  80   1    1    700   Maramba, Sailors' Isle           Little Jack                                           
 3"Blaster          80  95   1    2   1015   Lynx Fight, Moonstone Mt.        Little Jack
 5"Cannon           90  80   1    2   1330   Black shipMarket                 Little Jack
*8"Cannon          100  82   2	  2   2100   Valuan Spellship                 Little Jack
 10"Cannon Coil    180 100   2    2   2500   Nasrad, Esperanza                Delphinus
*10"Cannon         200 105   2    3   4000   Gregorio Cruiser                 Delphinus
*12"Blaster        230  95   3    2   4800   Piastol 2nd Fight                Delphinus
 12"Cannon         270  80   3    3   3500   Auriga Fight                     Delphinus
 3'Cannon          330 120   3    2   5110   Yafutoma                         Delphinus
 5'Cannon          380  90   3    2   5110   Yafutoma                         Delphinus
 Moon Gun          440  90   4    3   1000   Gadianos if defeated in 1 Turn   Delphinus
 Wevl Cannon       250 150   3    3   6000   Crescent Isle -Blue Element-     Little Jack & Delphinus
 ----------------------------------------------------------------------------------------------------

o---------o
|Torpedoes|
o---------o 
 Torpedoes are like a mix of the Main and Secondary Cannons. Their damage is close to a cannon 
 blast, as they do high damage, although they do not use the character's Power to raise damage.
 
 Like the Secondary Cannons, you can make them attack on a specific turn (but not during the
 one you launched them!) so they can also be combined with the other weapon types or Magic.
 
 While they do great damage, their accuracy is the lowest of all attacks, so they can be 
 a bit of a risky move. Fortunately, if you have Tikatika as an active crew member, he 
 will raise the accuracy of Torpedoes, making them more reliable. 
 
 Name              Att  Hit Sp  Lim  Price  Location                       Ship
 ------------------------------------------------------------------------------------------------
 Light Torpedo      120  60   3    2   1520  Maramba                       Little Jack
*Guided Torpedo     100  80   2    2   1720  Piastol 1st Fight             Little Jack
 Shock Torpedo      140  75   3    2   2000  Black shipMarket              Little Jack
 Hunter Torpedo	    160  60   3    3   2240  Chameleon Second Fight        Little Jack
 valuan Torpedo     200  65   3    2   2400  Nasrad, Esperanza             Delphinus                                          
 Heavy Torpedo      250  75   4    3   4400  Anguila Fight                 Delphinus
*Flash Torpedo      300  85   4    2   5360  Tenkou Spellship Fight        Delphinus
 Serpent Torpedo    350  60   4    2   5360  Yafutoma                      Delphinus
 Arcwhale Torpedo   400  75   5    3   6500  Crescent Isle                 Delphinus
*Dragon Torpedo     450  60   5    2   8800  Draco Fight                   Delphinus
*Electril Torpedo   500  70   6    3   1000  Eliminator Boss               Delphinus
 Moon Torpedo       600  60   6    3   1000  Hydra Fight                   Delphinus
 ------------------------------------------------------------------------------------------------
 Note: Hunter Torpedo causes Green elemental damage!

o------------------------o 
|Defensive Ship Equipment|
o------------------------o

o-------o
|Figures|
o-------o 
 Figures' main purpose in a ship is to offer Magical Defense against other ships' Magic Cannon 
 attacks and giant creatures' magical abilities, but they also provide some other benefits.
 
 Name               De  Ma  Do  Qu  Price   Location                       Ship
 ------------------------------------------------------------------------------------------------
 Rogue Figure        4  20   0   4    800   Maramba                        Little Jack, Delphinus
 Pryn Figure         7  30   3   7   2400   Black shipMarket               Little Jack, Delphinus
 Pyrynn Figure      10  45   3  10   4400   Nasrad, Esperanza              Little Jack, Delphinus
*Archwale Figure    25  60   8  25   7000   Rupee & Barta Fight            Little Jack, Delphinus
*Giant Figure       17  80   5  17   5120   Gregorio Gunboat Fight         Little Jack, Delphinus
*Quetya Figure      35 100   5  45   8000   Pera, Lira & Tara Fight        Little Jack, Delphinus
 Bluheim Figure     20 120   5  20   5360   Yafutoma                       Little Jack, Delphinus
 Goddess Figure     25 150   5  25   9000   Crescent Isle                  Little Jack, Delphinus
*Vyse Figure        35 170   5  35   8800   Obispo Fight                   Little Jack, Delphinus
 Spherical Figure   20 200   5  20  13500   The Blackbeard-2               Little Jack, Delphinus
 ------------------------------------------------------------------------------------------------ 

o-----o  
|Decks|
o-----o
 Decks offer the largest increases on Physical Defense, and with most attacks directed at 
 you being physical in nature, you'd do well to always have the best Deck available on 
 your ship. They do not give nearly as much other benefits, but sure are they essential. 
 
 Name               De  Ma  Do  Qu  Price   Location                       Ship
 ------------------------------------------------------------------------------------------------
 Armored Deck       10   3   0   0   1000   Sailors' Isle                  Little Jack, Delphinus
 Steel Deck         20   6   0   2   1900   Maramba (Chest, Shop)          Little Jack, Delphinus
 Slanted Deck       30   9   0   4   3000   Horteka, Sailor Island (Shop)  Little Jack, Delphinus
 Compound Deck      40   9   0   4   5500   Nasrad, Esperanza, Sailor's I. Little Jack, Delphinus
 Heavy Armor Deck   55  12   0   6   6700   The Auriga                     Little Jack, Delphinus
 Alloy Deck         80  50  10  50   8000   Obispo                         Little Jack, Delphinus
*Dragon Deck       150  25   5  10  11000   Daikokuya Fight                Little Jack, Delphinus
*Ancient Deck      150  15  10  15  11000   Roc Fight                      Little Jack, Delphinus
*Silver Deck       150  10   5  25  11000   Vigoro Second Fight            Little Jack, Delphinus
 Sparkling Deck    300   0   0   0  13500   Gadianos if defeated in 1 Turn Little Jack, Delphinus
 ------------------------------------------------------------------------------------------------  

o-------o
|Engines|
o-------o
 Engines provide Quick as its most important feature. Being able to move before your opponent 
 on each turn of each round will absolutely make it far less deadly out there, specially if 
 in need of osme quick healing.
 
 Name               De  Ma  Do  Qu  Price   Location                       Ship
 ------------------------------------------------------------------------------------------------
 Engine Cover        2   2   0  10    800   Sailors' Isle                  Little Jack, Delphinus
 Turbo Kit           2   2   2  20   1520   Maramba                        Little Jack, Delphinus
 Bore-up Kit         4   4   2  30   2400   Black shipMarket               Little Jack, Delphinus
 Twin Propellers     6   4   4  40   3200   Centime (After Saving him)     Little Jack, Delphinus
 Air Intake         10   8   6  80   6800   Crescent Isle                  Little Jack, Delphinus
 Twin Turbo         12  10   8 100   8800   The Chameleon-3                Little Jack, Delphinus
 Timing Valve       20  20  10 110  10800   Anguila (Osman), Blackbeard 2  Little Jack, Delphinus
 Triple Turbo       10  15  15 130  12800   Valuan Spectre                 Little Jack, Delphinus
*High Torque Kit    30  30  15 140  14800   Piastol 3rd Fight              Little Jack, Delphinus
 Double Shaft       20  20  15 160  16640   Galcian`s Elite                Little Jack, Delphinus
 ------------------------------------------------------------------------------------------------

o----------o
|Other Gear|
o----------o
 These pieces of equipment were originally terrible and only existed for you to get the 
 "Vyse the Extravagant" title... Well, some of them, others were left unusued. 
 
 The point is, they existed only to pad your item list, really. That's why I converted 
 them into new ones, that can actually provide you with useful bonuses and offer a new 
 little twist on customizing your ship instead of the old Deck/Figue/Engine setup. 
 
 Name               De  Ma  Do  Qu  Price   Location                       Ship
 ------------------------------------------------------------------------------------------------
 Chained Shields    15  15   0  20   2500   Black ShipMarket,Spectre (Kalifa) Lit.Jack, Delphinus
 Exquisite Cover    20  20   5  20   3000   Nasrad                         Little Jack, Delphinus
 Moon Hull         100  20   0  20   8000   Crescent Isle                  Little Jack, Delphinus
 Yafutoman Hull     25 100   5  60   6000   Yafutoma                       Little Jack, Delphinus
 Ancient Sail       50  50  10 120   ----   Roc (Kalifa)                   Little Jack, Delphinus
 Velvet Hides       70  70  20  70   ----   Raja                           Little Jack, Delphinus
*Expensive Wheel    70  80   5 100   ----   Daikokuya Fight (Jouyin)       Little Jack, Delphinus
 Odd Machinery      80  80   5  80   ----   Alania (Kalifa)                Little Jack, Delphinus
*Blazing Hull      100  70   5  80   ----   Alania                         Little Jack, Delphinus
*Moon Mirrors  	    70 100   5  70   ----   Ruins of Ice                   Little Jack, Delphinus
 ------------------------------------------------------------------------------------------------

o----------o
|Ship Magic| 
o----------o
 After a certain point in the game, you get your hands on a Magic Cannon.
 
 This enables you to charge cannonballs with specific Spells that your characters know,
 granting elemental properties and also making them do magical damage instead of physical. 

 Of course, they need Spirit Points and Magic Points like normal magic. One thing you need 
 to remember is that magic attacks on Ship Battles cannot fail like normal attacks. 

 Well, that's not entirely true: if you try to do it when your enemy is behind you,  
 or extremely far away it will fail, just like any attack you try on that situation. 
 
 But if there's any chance to realistically hit your foe, any hit with the Magic Cannon
 WILL hit. Just have it in mind if you find a foe that's too evasive for you! 

 In this mod, Ship Magic has made a lot more useful and desirable to use. 
 
 The power for elemental attacks has been raised to be worth using, and the originally 
 rather underused system of Weaknesses and Resistances for enemy ships has been tweaked
 significantly to make the most of it. Of course, there's a bit of trial and error as 
 you cannot know the elemental properties of enemies like when on foot, you have to try!
 
 Healing Magic was made better too, recovering more HP than the Kits you can buy. 
 Something I added is a third Healing Spell, Sacrum, to the ship battles!
 
 In the vanilla game, the player had a rather large hole in how much it could recover to the 
 Ship by itself, without abusing items. Sacri restored 4.000, Sacres 8.000, and then... Nothing
 until you master Green Magic and you get Sacrulen, which can take a really looong time.

 in my Hack, you get to use Sacrum during ship battles! It recovers 30.000 HP and costs 6 SP. 
 It really hits the spot as the player should start learning it around when you get to Yafutoma, 
 which is when enemies start to hit more and more, so to me, it fits well into the game.
 
 Not just that, the player now can also use Noxi and Noxus during ship battles too! 
 They will deal Green magical damage, and basically act like the other elemental attacks, 
 but sadly because there's no more spells, Noxus' damage caps at tier 3 of Spell damage.
 But it's still pretty useful, as some foes will be weak to it!
 
 I also added the Etern- spells to the repertoire of usable Spells in ship battles. 
 Just like Noxi and Noxus, they do Silver damage to the foe. Now you can deal magical
 damage of all elements!
 
 But two minor things: Unfortunately, I cannot put descriptions to these. I tried but the game 
 screws up things. Not a big issue because well, you have this readme, and I really think people 
 ignore the descriptions after reading them once. 
 
 The other thing, using any of the three Silver Spells won't have a special animation. With any 
 other element, its seal will appear around the ship, but because Silver did not have any Spell 
 useable in vanilla, I guess they didn't program any seal animation. But they work fine, as 
 they look like normal Main Cannon attacks. 
 
o------------------------------------------------------------------------------------------o
|Green Magic: Used during Ship Battles.                                                    |
|Name        SP Power   Effect                                                             |
o------------------------------------------------------------------------------------------o                      
|Sacri        2  ---    Restores  5.000 HP to the Ship.                                    |
|Sacres       4  ---    Restores 10.000 HP to the Ship.                                    |
|Sacrum       6  ---    Restores 30.000 HP to the Ship.                                    |
|Sacrulen     8  ---    Restores all the HP to the Ship.                                   |
|Noxi         4  210    Magically charges a Cannon Ball with Green Magic, adding damage.   |
|Noxi         6  280    Magically charges a Cannon Ball with Green Magic, adding damage.   |
o------------------------------------------------------------------------------------------o
| Order of learning: Sacri L1, Noxi L2, Sacres L3, Noxus L4, Sacrum L5, Sacrulen L6.       |
o------------------------------------------------------------------------------------------o

o------------------------------------------------------------------------------------------o
|Red Magic: Used during Ship Battles.                                                      |
|Name        SP Power   Effect                                                             |
o------------------------------------------------------------------------------------------o                      
|Pyri         2  140    Magically charges a Cannon Ball with Red Magic, adding damage.     |
|Pyres        4  210    Magically charges a Cannon Ball with Red Magic, adding damage.     |
|Pyrum        6  280    Magically charges a Cannon Ball with Red Magic, adding damage.     |
|Pyrulen      8  350    Magically charges a Cannon Ball with Red Magic, adding damage.     |
|Increm       7  ---    Increases Attack and Defense of the Ship for 2 turns.              |
|Incremus    12  ---    Increases Attack and Defense of the Ship for 4 turns.              |
o------------------------------------------------------------------------------------------o
| Order of learning: Pyri L1, Increm L2, Pyres L3, Pyrum L4, Pyrulen L5, Incremus L6.      |
o------------------------------------------------------------------------------------------o

o------------------------------------------------------------------------------------------o
|Purple Magic: Used during Ship Battles.                                                   |
|Name        SP Power   Effect                                                             |
o------------------------------------------------------------------------------------------o                      
|Crystali     2  140    Magically charges a Cannon Ball with Purple Magic, adding damage.  |
|Crystales    4  210    Magically charges a Cannon Ball with Purple Magic, adding damage.  |
|Crystalum    6  280    Magically charges a Cannon Ball with Purple Magic, adding damage.  |
|Crystalen    8  350    Magically charges a Cannon Ball with Purple Magic, adding damage.  |
|Sylenis      2  ---    High probability to inflict Silence to the enemy Ship for 2 turns, |
|                       making your foes unable to cast spells or use the Magic Cannon.    |
o------------------------------------------------------------------------------------------o
| Order: Cristali L1, Cristales L2, Sylenis L3, Crystalum L5, Crystalen L6.                |
o------------------------------------------------------------------------------------------o

o------------------------------------------------------------------------------------------o
|Blue Magic: Used during Ship Battles.                                                     |
|Name        SP Power   Effect                                                             |
o------------------------------------------------------------------------------------------o                      
|Wevli        2  140    Magically charges a Cannon Ball with Blue Magic, adding damage.    |
|Wevles       4  210    Magically charges a Cannon Ball with Blue Magic, adding damage.    |
|Wevlum       6  280    Magically charges a Cannon Ball with Blue Magic, adding damage.    |
|Wevlen       8  350    Magically charges a Cannon Ball with Blue Magic, adding damage.    |
|Quika        5  ---    Increases the Quick of the Ship for 2 turns.                       |
o------------------------------------------------------------------------------------------o
| Order of learning: Wevli L1, Quika L2, Wevles L3, Wevlum L5, Wevlen L6.                  |
o------------------------------------------------------------------------------------------o

o------------------------------------------------------------------------------------------o
|Yellow Magic: Used during Ship Battles.                                                   |
|Name        SP Power   Effect                                                             |
o------------------------------------------------------------------------------------------o                      
|Electri      2  140    Magically charges a Cannon Ball with Yellow Magic, adding damage.  |
|Electres     4  210    Magically charges a Cannon Ball with Yellow Magic, adding damage.  |
|Electrum     6  280    Magically charges a Cannon Ball with Yellow Magic, adding damage.  |
|Electren     8  350    Magically charges a Cannon Ball with Yellow Magic, adding damage.  |
|Driln        3  ---    Lowers the Attack and Defense of the enemy Ship for 2 turns.       |
|Drilnos      6  ---    Lowers the Attack and Defense of the enemy Ship for 4 turns.       |
o------------------------------------------------------------------------------------------o
| Order: Electri L1, Driln L2, Electres L3, Electrum L4, Drilnos L5, Electren L6.          |
o------------------------------------------------------------------------------------------o

o------------------------------------------------------------------------------------------o
|Eterni       4  210    Magically charges a Cannon Ball with Silver Magic, adding damage.  |
|Eternes      6  280    Magically charges a Cannon Ball with Silver Magic, adding damage.  |
|Eternum      8  350    Magically charges a Cannon Ball with Silver Magic, adding damage.  |
o------------------------------------------------------------------------------------------o
| Order: Eterni L3, Eternes L5, Eternum L6.                                                |
o------------------------------------------------------------------------------------------o

  -----------------------------------------------
  -----------------------------------------------

 -------------------
 13 - Drop Ships Changes:
 -------------------

 I shuffled things a bit in order to make certain battles more rewarding, now 
 that all ship battles are considerably more challenging. 
 
 One thing that I have to point out is that, for Boss Battles, or whatever 
 fight that can only be fought once, the chance for items to drop is 100%.
 
 I see no point in making the player reset the game several times to have 
 a chance to win an item. Specially if won early enough, as it would end up 
 being outdated as the player progress through the game, making it... dumb. 

 Even more because with fights being harder, it would get old much faster. 
 
 The names in parenthessis means to have that crew member selected to be 
 the active one in order for that item to appear.

 Random Battles: 
 ----------------------------------------------------------------
 Valuan Cruiser   - Fight while escaping Valua, First time.
 Rewards: 2000G   - 3'' Cannon
 ----------------------------------------------------------------
 Valuan Spellship - In front of the Grand Fortress until Soltis.
 Rewards: 2000G   - Bomb, Wave Bomb 50%, 8"Cannon 50%
 ----------------------------------------------------------------
 Valuan Phantom   - Near Moonstone Mountain before fighting Grendel. 
 Rewards: 2000G   - Big Bomb, Frost Bomb
 ----------------------------------------------------------------
 Valuan Gunboat   - North Ocean, only with the Little Jack. 
 Rewards: 3000G   - Shredder Bomb, Deluxe Kit
 ----------------------------------------------------------------
 Valuan Mage Ship - Around Valuan Airspace, Boss before the Hydra.
 Rewards: 4000G   - Frost Bomb, Thunder Bomb
 ----------------------------------------------------------------
 Valuan Spectre   - 6000G, Triple Turbo, Floor Heater (Kalifa) 
 Around Mid Ocean and Sailor's Island Airspace, with the Delphinus.
 ----------------------------------------------------------------
 Galcian Elite    - Soltis Airspace.
 Rewards: 8000G   - Double Shaft, Fabulous Kit, Crystal Cannon (Kalifa)
 ----------------------------------------------------------------
 Gregorio Cruiser - Esperanza Fight Part 1.
 Rewards: 4000G   - Speed Wax, Advanced Cannon, 10" Cannon
 ----------------------------------------------------------------
 Gregorio Gunboat - Esperanza Fight Part 2.
 Rewards: 5000G   - Shredder Bomb, Giant Figure, Crystal Ball (Osman)
 ----------------------------------------------------------------
 Black Pirates    - Near Maramba. Try before entering the town! 
 Rewards: 2500G   - Heavy Cannon 50%, Rogue Figure 50% 
 ----------------------------------------------------------------
 Spell Pirates    - North Ocean. 
 Rewards: 3000G   - Pyro Bomb, Wave Bomb 50%, Magic Shell 20%
 ----------------------------------------------------------------


 Armada Boss Fights:
 -------------------
 Lynx         - 3500G Captain Stripe,   3'' Blaster 100%, Magic Cannon
 Chameleon    - 4000G Captain's Stripe, B-Type Cannon
 Chameleon 2  - 4000G Captain's Stripe, Hunter Torpedo
 Auriga	      - 5200G Captain's Stripe, Heavy Armor Deck, 12"Cannon
 Draco 	      - 6100G Captain's Stripe, Gold Bullion,     Dragon Torpedo
 Chameleon 3  - 7000G Captain's Stripe, Twin Turbo,       Magic Shell

 Gigas:
 ------
 Recumen      - Nothing
 Grendel      - Captain's Stripe, Grendel Wing, Complete Kit
 Bluheim      - Captain's Stripe
 Plergoth     - The only thing you get is sadness
 Yeligar      - Captain's Stripe, Thunder Cutlass
 Zelos        - Captain's Stripe


 Monster Ship Fights:
 --------------------
 Anguila      -  5400G, Timing Valve  (Osman),  Concussion Bomb,     Heavy Torpedo 
 Raja         -  5500G, Velvet Hides  (Kalifa), Deluxe Kit 50%,      Crystal Ball (Kalifa)
 Obispo       -  5600G, Crystal Ball  (Osman),  Alloy Deck,          Vyse Figure 
 Roc          -  6900G, Ancient Sail  (Kalifa), Ancient Deck,        Gold Bullion
 Alania       -  6500G, Odd Machinery (Kalifa), Blazing Hul,
 Giant Looper - 13000G, Captain's Stripe 100%,  Thermal Grease 100%, Hex Shell 100%
 -------------------

 -----------------------------------------------
 -----------------------------------------------

 -----------------------------------------------
 14 - List of Beta items rescued:
 -----------------------------------------------

 Secondary Cannons 
 -----------------
 12"Blaster	 -> Piastol, Second Fight
 8"Cannon	 -> Valuan Spellship		  
 10"Cannon	 -> Gregorio Cruiser		    

 Torpedoes
 ---------
 Guided Torpedo   -> Piastol, First Fight
 Flash Torpedo    -> Tenkou Spellship Fight
 Dragon Torpedo   -> Draco Ship Fight
 Electril Torpedo -> Eliminator Boss

 Figures
 -------
 Archwhale Figure -> Rupee and Barta Optional Boss Fight
 Quetya Figure 	 -> Tara, Lira and Pera Optional Boss Fight
 Giant Figure 	 -> Gregorio Gunboat
 Vyse Figure	     -> Obispo
 
 Decks
 -----
 Dragon Deck 	 -> Daikokuya Optional Boss Fight
 Ancient Deck	 -> Roc
 Silver Deck	     -> Vigoro Second Boss Fight

 Engine
 ------
 High Torque Kit  -> Piastol, Third Fight

 Decoration
 ----------
 Expensive Wheel  -> Daikokuya Optional Boss Fight (Youjin Minion)
 Blazing Hul	     -> Alania
 Moon Mirrors     -> Treasure Chest in Glacia
 
 ---------------------------------------
 15 - Frequent Answers and Questions
 ---------------------------------------

Just a few questions probably some people have...

Q: "Could I play this as my first time with the game?"

A: ...Yeah, you could. My hack ramps up the difficulty a fair ammount, but 
   it never reaches a "You should have known that before it happened!" moment
   you can see in some Hardtype hacks, and the game does a nice job at pointing things. 

   The original game is very easy and very easy to exploit, really.

   But have in mind that guides telling you about strategies and such may not be
   accurate with how monsters, spells, and supermoves work now. For example I tried
   to avoid the incredibly boring "Buff Vyse/Drachma, spam supermove" strategy that 
   several guides tell you to do, or some saying to ignore magic.

   ...You will go horribly wrong if you ignore magic in this mod.

   For other things like shops, plot progress, item drops, discoveries and such 
   guides will be as useful in most cases as I made small changes for some, but
   for the most part the same.

   Also, you shouldn't worry about dying with bosses (On foot or ship battle), as 
   when you die, the game will ask you if you want to restart from the beginning of
   that fight, which is fantastic as sometimes there are several boss fights in a row,
   or long cutscenes between a save point and the battle itself.

   If you're new to this game, let me warn you: 
   RUNNING FROM BATTLES CAN BE DANGEROUS!!!
   
   The game works wth a system of fame, in which Vyse gets different ranks like...

   "Vyse the Competent", or "Vyse the Daring". 
   This system is named Swashbuckler Rating.
   
   You get points for winning fights, and making the right choices
   when asked through the story.

   As you get more famous, people will say different things about you, and you
   will also get access to different things (Like recruiting a character for your
   ship, or start a sidequest)...
    
   Problem with running, is that it lowers your fame. Unlike some people will tell
   you, or whatever you read in forums, running from battle from time to time isn't
   going to ruin your game (That's pretty inaccurate and silly) but if you run 
   constantly from battles you may gain the title of "Vyse the Coward", which is
   one of the lowest ranks.

   The issue with that, is that it will take an awful ammount of time to recover from
   that rank, and you will not be able to do some things because you don't have a good
   enough ranking. Most people prefeer to reset the game and start from the beginning 
   because it will take less time and... Yeah, it can be true.

   So remember, don't flee from battles too often, and answer the questions correctly 
   and you'll be fine. If you need to run to save your life, do it. In all my many  
   playthroughs I've run from battles here and there, and it never, never hurt my rank...

   Just to give you an idea. If I fought 300 battles, and fleed from 30. 
   Those 30 would not affect my rank. 

   Also, there's no rank that forces you to never run, so don't worry. 
   And once you get one of the special GC ranks, you can run as much as you want, 
   as it won't go down anymore because you can no longer get lower grade ranks.

   You can get an accessory to reduce random encounters too.
   Or use the extra patch with a small modification made by RHDN user cleartonic 
   to avoid battles happening while holding the B Button.
   
   It works great, but that causes another "issue": If you hold it all the time, you 
   will make yourself weaker as you progress, as you don't get Experience, so you 
   don't level up. Don't abuse it and everything should be fine. 

   Another tip: Use several save slots as you progress. Sometimes you may want to go back
   for whatever reason, and it's better to lose the last 20 minutes than start an entire 
   new playthrough, although that would be kinda extreme.

   ----------------------------------------------------------

Q: "I can't damage this boss, I do very low damage!"

A:  Well, if you try physical damage and goes badly, just try Magic! 
    And this is not just for on foot bosses, but for ship bosses too!
	
	Some will have higher Physical Defense, others will have large 
	Magical Defense. You need to see what works best. 
	
	Taking advantage of Status Effects will also be useful. Most 
	bosses are actually susceptible to Poison, no doubt it will 
	help you by adding damage over time. Some bosses might also 
	have chances to be weak to other specific Status. Try!
   
    Also, mind your enemies' elements. Skies of Arcadia works on the typical
	Elemental Weakness/Resistance kinda system, where every enemy and also every
	attack (except most ship equipment) you and your enemies do has an element. 
	
	On foot there is almost no Neutral element damage here, beyond very specific
	attacks! This makes accessories that lower elemental damage really useful.
 
    As you play you unlock elements to change (You get them all very early in the game,
	don't worry). You can cycle through these elements during battle to adapt to any 
	situation. And depending on what elements you have when you finish a battle,
    your characters will get Magic Experiencie (Needed to learn Spells, of course!)

    You can find how each element reacts to another in the Magic Section.

   ----------------------------------------------------------

Q: "Okay... Magic Experience points, how do they work?"

A: Another question I saw a lot while reading through forums and such. 
   Okay, this is how it goes:

   Each character always has one element activated. At the end of the fight,
   the game looks at which elements you have and gives the group M.Exp for 
   each element present.

   Each enemy group (Yeah, Magic Experience goes by groups, no monsters) 
   has a fixed ammount of M.Exp. when you finish a fight.
   It never goes very high, as the biggest ammount of M.Exp. 
   you get in a single fight is about 4.

   You may think it's low and well, sounds like it, yeah. 
   But there is more than that:

   You see, if Vyse has Red element, and Aika has Green element, 
   both will get experience for both elements! And if they have 
   the same element, you raise it faster too.

   Characters gain the ammount of M.Exp based on what elements are used 
   and how many characters on the team are using said elements, plus extra 
   points for his his/her own element.

   One example: 

   Vyse has Red element, Aika has Green. You win a fight and get 1 M.Exp.

   Vyse will get 1 Red M.Exp, and 1 Green Exp. But also, will get an aditional
   1 Red M.Exp point for having Red Element. So 2 Red, 1 Green.
      
   Aika will get 1 Red M.Exp, and 1 Green Exp. But also, will get an aditional 
   1 Red M.Exp point for having Green Element. So 2 Green, 1 Red.
  
   Now let's say that you have four characters and win a fight with 2 M.Exp. 
   And this time, they have the same element:

   Each character would get 2x4 (Because four characters used the element) 
   plus another 2 because of the M. Exp. itself. 
   Each character would get 10 M.Exp points.

   And if they  had 2 elements between the four...

   Characters would get 2x2+2 (6 M.Exp Points) of an element, plus 4 of the 
   one they're not using.

   Also, remember that each character learns spells at their own speed.

   Vyse is pretty fast with Red, and Blue, while is average with green and kinda 
   slow with Purple and Green, while Aika is the opposite.

   By Version 1.50 the grinding for Magic Experience has been cut tremendously, 
   you shouldn't worry too much as long as you don't forget to use the elements 
   in your weapons for the Spell group you want. 
   ----------------------------------------------------------

Q: "Okay so... What's the best approach for learning Magic?"

A: I don't know for others, but for me is just to put all characters with the same 
   element I want to priorize.

   Let's say, at the beginning of the game I put both Vyse and Aika with Red, 
   until they get Pyri. Then I switch to Green and learn Sacri and Noxi, and 
   now they get an AoE spell, a healing spell, and another attack that can also 
   cause Poison. 

   Then you switch to whatever you want or need as you progress, and when you
   get a new element, is best to get a couple of levels on it too.

   You can get "more" Magic Experience if you use 4 different elements in a battle,
   but while you might get a highet total, you're growing so, so much slower in 
   comparison. Doing so is, basically, stretching yourself too thing, as you'll take 
   much, much longer to learn a single Spell that way. 
 
   I always give more importance to learn magic than to use elements for physical
   attacks, as once you've learn a Spell you can use it to attack enemies without 
   worrying about which element you have in your weapon, which means you can learn 
   other Spells with less worries.

   Also, Vyse, Aika and Fina get priority, as they are characters you will always 
   have, while the fourth slot changes from timte to time. Fortunately, they still 
   get M.Exp when they're not on the time so when they come back you'll find that 
   they have learnt new Spells that they did not know before. 

   That said, it would be in your best interest to learn the Sacri line (Healing) 
   and Risan/Riselem (Resurrection) as fast as you can, as items heal quite a bit
   less HP, and can get expensive early on.

   Also, event battles (Like bosses, plot related fights with lesser enemies,
   or fights that will always happen in certain points) give more M.Exp than normal. 
   
   You may want to use that as a way to learn spells faster if you have the chance. 
   Optional boss fights give more too!
   
   -----------------------------------------------------------

Q: "I got a defensive gear that protects me from an element, but how much it does?"

A: As far as I know, it's a 20% reduction of damage with that element. And you will 
   need it in some boss fights. Also, you can have several protections (For example
   an accessory can give two, or combine one element from armor and another from accessory).

   For Status protection, there are several levels of resistance, so depends on the item. 
   And about weapons with status effects (like causing sleep), they have a chance of 20% 
   to activate.

   -----------------------------------------------------------

Q: "Oh god, I didn't equip the Little Jack with a Secondary Cannon, now I won't be able 
   to get past Recumen!"

A: Well... it's not a question, but it seems to be a problem that happened to quite 
   a few people in several places I looked with the original game too. 
   
   First of all, you could still "win" that fight, with an unmodified Little Jack
   on the origignal game, it was just harder.
   
   But for this mod, things are different. Little Jack starts with a 3"Cannon in the 
   third slot, and you get another one after advancing the plot (Yet before even going 
   to the Nasr Region).

   Also, be careful, because it can wipe you out with one laser in this mod if you're 
   unlucky (So Defend until you discover what to do).

   ----------------------------------------------------------
   
Q: "Wait, I'm supposed to get 100.000 Gold to build the base and continue the game?"

A: Yeah, that parts catches us all unprepared. Fortunately there are ways to make 
   money:
   
   Between Nasr and Crescent Island, you can find these Plant-like creatures. 
   They drop 1.000 Gold for each and can also drop an item that can be sold 
   for even more! They tend to appear in groups of 4 to 6, so that right 
   there can be a pretty fast way of gaining Gold, if you can defeat them 
   fast enough.
   
   You can catch fishes and sell them on large quantities, that also adds up 
   money. It also helps with one of the Special Ranks. 
   
   You could try some Ship Battles, as they give quite a bit of money and you 
   can sell whatever they reward you after winning for extra Gold. 
   
   Discoveries! Remember you get paid for them whenever you inform a Sailor's 
   Guild. You can make lots of Gold that way!
   
   As a last resort, you could sell Daccat's Coin for 20.000 on Nasr's Sailor's 
   Guild, but I honestly rather keep it. It's not enough money for something 
   you cannot get back. 
   
   Chances are you have a decent amount of money for when you reach this 
   point, seeing the different events you go through in a short amount 
   of time and you having limited chances to buy stuff through it. 

   ----------------------------------------------------------  

Q: "Wow, enemy ships are destroying me!, What Can I do?"

A: Well, they are generally quite a bit stronger than before, because that was the point. 

   Early on, with the Little Jack, remember that it's a small, fishing ship, so it's 
   completely understandable that you get rocked here and there. 
   
   If you want general tips, You can use Increm to give your ship higher defenses for a 
   few turns, so when you see a lot of yellow and red turns, you might want to cast it.

   Also, equipment. You must have your ship well equipped always. Also bring some repair 
   kits, although they are more expensive compared to the original game. Learn the Sacri 
   Spells to recover HP to your ship, they are all incredibly useful when enemies get 
   really strong.

   Calculating when your ship will get attacked to heal right after is pretty useful, 
   because in the next round the enemy may get the upper hand, you don't want to start 
   a round with very little HP, unless you can guarantee you'll go first.
   
   Don't waste your time trying to attack enemies in yellow/red turns, or when they are
   too far away; you most probably miss, instead use those turns cast healng Magic or 
   use items on your ship.
   
   Remember that, when Defending, give that action to the character with the highest Vigor, 
   as their natural defenses actually help lowering damage a bit. 

   Remember to use Driln/Drilnos or Sylenis to put you on an advantage, if things are getting
   too intense (Although I rather have a challenge). 
   
   DON'T FORGET THE MAGIC CANNON! It can do pretty beast damage if you discover to what 
   your enemy is weak against. And talking about Magic, if you find yourself missing attacks, 
   try offensive Magic! If the enemy's in range, it WILL hit it. 
   
   And of course, search high and low for crew members when you get your second ship, 
   as their special abilites can help you a lot.

   I personally don't like to abuse items while in battle, and the mod (Not only ship battles)
   has been made and tested in a way that you don't need them to win, just if you want to make 
   fights easier or to use them in a pinch. Healing Magic and Crew Member Actions are overall 
   better to maintain your ship's HP, but it's always good to carry a few Repair Kits.

   Funny enough, the game itself makes a comment about pirates not wanting to use items 
   during battle too and use their abilities instead. So... I guess it's sort of in line 
   with the game's world. 

   ----------------------------------------------------------

Q: "Wai-What?! Why I'm a "Fallen Pirate"?!"

A:  You may want to talk to shopkeepers and the Sailor's Guild to get some clues...

   ----------------------------------------------------------

Q: "I think I've seen Aika somewhere else..."

A: Probably. Her design was ripped off (Although you may want to say "used as 
   inspiration") to make Sticks The Badger, a Sonic Boom Character... That also 
   is some sort of copy of another Sonic Character, Marine the Racoon. Call it a
   combination of both. And not a very subtle one.

   Not that I have anything against Sticks, it's just too obvious. 
   ----------------------------------------------------------  

Q: "It's me or Vigoro has a key around his neck?"

A: Yeah... it IS a key. A key that opens his... Erh... "Cannon look-a-like Crotch 
   Protector of Manliness +1"... Somewhat shaped as his own battleship,
   which also has been pointed by many as overcompensation of some kind... 
   
   ...Yeah, he has issues. And a gigantic ego. And he doesn't get that 
   no means no until he gets his head bonked several times. And a problem
   with body hair... If you check on the japanese version (Why would anyone
   shave it that way?!).
   
   So yeah, all of that makes kicking his butt is always satisfying. 
   And yet still, I can't get enough of this guy. He's so incredibly silly 
   that becomes fun, it kinda grew on people.
   
   And the developers knew, seeing what they did with him on the GC re-release...
   
   ----------------------------------------------------------

Q: "What did you use to do this?"

A:  Well as far as tools, I started with GameCube Rebuilder So I could extract 
    files from a GC ISO file, Start.Dol holds most of the information.
	
    Then I tried "Skies of Arcadia Legends Editor". And while useful at the beginning, 
	it adds many bugs to the game.

    Some examples are:

    Bugs in the element resistance of equipment (Will cause very weird things 
	if you're wearing one and get attacked).
    
	Bugs in the status resistance of equipment.
	
    Bugs in the chance of "comsumption, putting it to 0% for each item you 
	look with the application, even if you put 100% (Meaning that you would 
	get infinite uses for each item).
	
    Bugs with percentages in Spells.
	
    Bugs with item descriptions (It reachs a point in the Consumable 
	item list where it shows the description of other items). 
    
    You could fix these with Hex Editor after each time you edit Start.Dol 
	if you compare a clean Start.Dol and a edited one, but it gets really old...

    So I ended doing pretty much everything with a Hex Editor, HxD. But don't worry, 
	Skies of Arcadia Legends is pretty easy to work with in a Hex Editor on the 
	most basic stuff.

    Most things are easy to find, you just have to search the name, for example 
	the Valuan Spellship, and you'll find it's data. 

    Start.Dol has all magic data, supermoves data, enemy attacks, Characters starting 
	and growth stats, Ship data, item data, equiprment data (Weapon, armor, accessories),
	crew members and item/magic/equipment/crew/discoveries descriptions. In short, 
	all but enemy data, and enemy formations.

    Which brings me to this: Besides SOAL Editor and GCR, I also used some very neat 
	Ruby Tools named ALX, Skies of Arcadia Legends Examiner.
	
    They are a bunch of tools programmed with Ruby that you can use to edit the game 
	around, and files that are not Dol.Start too.
	
	ALX has evolved over the years it seems and newer versions are easier to work 
	with, and now supports pretty much every version of Skies of Arcadia. 
	
	Here's a link: 
	https://github.com/Taikocuya/ALX

    One warning, dont you ever try to mix enemies without looking at which files they 
	are stored! Don't try to put a random enemy alongside a boss, if it's data is not 
	present in the same file as the bosses' for example. You will only crash the game.
	
	...And make your ears hurt.

   ----------------------------------------------------------------    

Q: "Why do you make such long readmes?"

A: ...Why not? Maybe most won't read it, but I can practice my english, and also is a 
   pretty useful way to have all things in check. For example, while writting the ship 
   equipment section I saw that I screwed up with a pair of tiny things, and I corrected them.

   The same with fishes. And while I write it, I may get ideas or rethink something. 
   I even changed bosses around because of thinking things twice and reconsidering. 
   
   Putting the changes into "paper" is useful and can help you. Not to mention you 
   can actually communicate with people and explain why you do the changes you do.
   
   So, even if it's bound to be ignored, it helps me to make hacks better. 
   Also I can pretend to be funny while I'm not. That's seemingly important on 
   the internet from what I've observed... Not that I want to spend more time 
   in this hellhole of constant arguing than I strictly need, though. 

  ------------------------------------------------------------------

Q: "What are you going to do now?"

A: Well, when I came back to this since 2017, I was in the middle of several 
   other things. And that's without mentioning all the other stuff I've done
   since 2017 too. I've never really stopped romhacking. But it's tiring.

   It takes way, way too much time for these long RPGs. Every single time, 80% of 
   the time goes into testing to see if everything flows correctly. If not, or 
   I find something can be tweaked for the better, it often forces me to start the 
   game again. Things like Experience charts or any progression-related thing pretty 
   much forces you to start from the beginning, other changes still benefit from 
   going through them again, like weapon/spell power, whatever enemy changes you 
   do need to be seen with the level of power the player would see, and such.
   
   Imagine playing a 70 hour RPG three times, with several half-playthroughs in 
   between because you want, or need to touch up on something because it's not 
   working as you wished or simply you get new ideas to improve it. 
   
   ...And that's why I kinda want to stop for now. But knowing me, I'm too stubborn
   and curious to not keep messing around with games, so who the hell knows. 

   ----------------------------------------------------------------

  -------------------------------------------------------
  -------------------------------------------------------

 ------------------------
 16 - Credits... Of sorts.
 ------------------------

 I want to thank Overworks and Sega for making this great game, and porting it to
 the Cube too, why not. In all honestly, I enjoy the Sega of that time era a lot.
 
 I want to thank the Skies of Arcadia Wiki and Esoarcadia for the loads of information
 that helped me with all the silly names and data.
 
 I want to thank Tortigar and Taikokuya for developing the ALX tools, they came in 
 very handy for things that are compressed.

 I want to thank ADnova for Skies of Arcadia Legends Editor, helped me quite a bit 
 at the beginning to understand how data was structured, before going full Hex editor.

 I want to thank my brain for not giving up and blowing up after the several test 
 playthroughs, and all the time inverted into this across the years.
 
 And of course, to you too. Either if you enjoy this or not, thanks for at least
 showing some interest.

