Skies of Arcadia Legends
Hold B to skip encounters

Description:
This is a no-frills hack that simply allows you to press the B button while traveling in encounter areas to avoid dealing with random fights. There is no menu hacking or other signals. Just hold B while walking, and if the player would like to have encounters, stop holding B and the regular encounter system will resume. 

Patching:
Use a xdelta patcher to apply `patch.xdelta` directly to an uncompressed ISO of Skies of Arcadia Legends (US), filesize 1,459,978,240 bytes. 

Usage:
When in game, when either walking around in areas with random encounters or when flying on the world map in areas with random encounters, hold B to reset the step threshold back to zero.

Technical:
$80346D2A holds 2 bytes of step counter information, which slowly accumulates while walking around until it randomly hits a breaking point and a fight is triggered. Keeping the value at 0x0001 ensures no encounters occur. 

$800C1FC8 is where the game increments the step counter. This function was hooked into and modified to accomodate the hack, however free space was an issue.

An inefficient function at $80305a5c was identified, and was optimized via a loop to carve out free space for the custom function above. 

Created by @cleartonic / https://twitch.tv/cleartonic