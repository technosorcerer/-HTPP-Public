 -------------------
   How to Install:
 -------------------

 Very easy, actually. This comes as a XDelta patch.
 It was made with DeltaPatcher, so use that if you want. 

 First make a backup of Skies of Arcadia Legends NTSC-US with this checksum:

 CRC32	23e347b6
 MD5	3e7fa5033c4a2704434fb6ba98195ecd
 SHA-1	46105320553c858f25fafc5fd357566b505a4940
 
 If it matches, you can continue. This data confirms is a verified
 good dump of the game. 

 Then is as easy as to patch it like any other ROM.
 First, get DeltaPatcher. Select the target ISO on the first box,
 my patch on the second, and click on Apply Patch. 
 	 
 It will take a while because this is not your typical Cartridge based game, 
 but that's just the only difference. After it finishes you'll have a patched
 ISO! After that, just boot it the way you chose either using your Wii or Dolphin.

 I personally played this through Nintendont with my Wii.
 
 Oh, by the way. This 1.50 Release comes with its own game banner, title and 
 game description (which is just a reference for one of my favourite silly 
 little lines in this game). The Game's ID is the same as the original game. 
 
 I wanted to make a different ID so save files for the original game and my 
 mod were separate, but apparently this game doesn't like it at all when 
 trying to save or read memory cards, so I left it as it was.
 
 I'll leave a screen capture on the 7zip file if you're curious about how it 
 looks on a GC.
 
 After installing the main patch, you can choose to also install one extra 
 tiny patch:
 
 Made by someone that goes by the name cleartonic, this hacker created a 
 modification for the game to temporarily disable random encounters while 
 the B Button is held. It works on foot, and sailing around too.
 
 Here's a link:
 https://www.romhacking.net/hacks/5314/
 
 But, that patch will not be compatible with my mod. It requires a specific 
 patch, which you can find on the 7zip file you also found this readme and 
 the main hack patch.
 
 I'ts a very light, simple IPS patch. Just apply it with LunarIPS or another 
 IPS tool to an ISO already patched with my main hack before. 
 
 Credits absolutely go to cleartonic for their work. I only adapted it to 
 be compatible with my own hack.

 That's all you need to know about installation. 
