Sonic Gems Collection (Gamecube)
Japanese to English patch
Version 1.0
Created by Masaru

Backports the english menu textures, logos and text from the American version of Sonic Gems Collection
to the japanese version of the game, giving access to both the Japanese OST of Sonic CD
and the Streets of Rage.

Nothing outside of the Textures, Logos and Texts were changed, that means the
Street of Rage games and the Manuals will still be in japanese.

There might be cases where there are games misnamed, this is in the case
of games that recieved a different name in japan

(Ex. Streets of Rage = Bare Knuckle, Sonic Triple Trouble = Sonic & Tails 2)


To patch the game, Use xdelta patching tools like Delta Patcher or Xdelta3 and Patch it to the following ISO:

Sonic Gems Collection (Japan).iso
NKit RVZ [zstd-19-128k] (RVZ file has to be converted to ISO through Dolphin or Nkit)
File/ROM SHA-1: D7024535CB8DE9936AC690C2A4AD6286ADAEC28C
File/ROM CRC32: 8266D5C5