====================================================
	  SSX Tricky: 4-Button Grab Mod (GameCube)
====================================================

		Written and made by: z_pucK

		  Date: February 11, 2022

====================================
	  -=Patch Instructions=-
====================================

	1. Drag game onto "DRAG GAME ONTO HERE.bat".

	Note: If your game is on a network drive, move or copy it to this folder first.

	2. Follow instructions on-screen.

	3. Look inside folder for a new, modded game.

	An unmodified dump of SSX Tricky (.gcm/.iso format) is required,
		or SSX Tricky NKIT (.nkit.gcz format).

	Full-sized games are required for .gcm/.iso format. (1,459,978,240 bytes for Gamecube)

	4. If using a 4-shoulder-button controller (i.e. not the original GameCube controller),
		bind your controller's L1 button in Dolphin's settings and make it act as the GameCube's "X" button.


============================
	  -=Introduction=-
============================

	SSX Tricky was released on the PS2, Xbox, and GameCube, but several grabs were made
	inaccessible in the final version of the GameCube release, likely because the GC controller
	lacks a 4th shoulder button.

	This mod assigns the X button on the GameCube controller to be that 4th-button, restoring
	the lost grabs on the GameCube's version.

	You can choose either "Default" or "Pro" controller settings in SSX Tricky, by going to
	"Options," and then "Configure Controller," and selecting settings for Player 1 and Player 2.


================================
	  -=Mod Descriptions=-
================================

	1. PS2 Grabs Fix

	This controller setting changes all the grabs to match the PS2 version of Tricky.
	The GameCube's "X" button becomes L1. You need to remap your controller's L1 button in Dolphin
	to the "X" button. Choose the "Default" controller setting in Tricky to use "PS2 Grabs" with this option.
		**Select this option to play using a controller with 4 shoulder buttons, or to play using the original grab combos.

	2. Pro Grabs Mod

	This controller setting changes 4-button grabs to be comfortable for controllers with 3 shoulder buttons.
	The "X" button becomes the 4th grab button. Use the X button in combination with L, R, and Z, to grab.
	The "A" button acts as a trick (tweak) modifier, in addition to jump. Be careful! You can activate ubers using "A".
	Choose the "Pro" controller setting in Tricky to use "Pro Grabs" with this option.
		**Select this option if you are using a GameCube controller, or a controller with 3 shoulder buttons.

	3. PS2 Grabs Fix + Pro Mod

	PS2 Grabs will become the "Default" controller setting, while Pro Grabs will become the "Pro" controller setting.
		**Select this option if you switch between different controllers.

====================================================
	  -=PS2 Grabs Fix Trick List (Mac/Marty)=-
====================================================

These grabs with these buttons combos should be identical to the PS2.

GRABS for Mac / Marty (freestyle board)

L2			METHOD
R1			INDY
R2			STALEFISH
L1			MUTE

R1 R2		TAILGRAB
L1 L2		NOSEGRAB
R2 L1		SWISS CHEESE
R2 L2		FLYING SQUIRREL
R1 L1		STIFFY
L2 R1		STALEMASKEY

L1 R1 R2	SPAGHETTI
R1 R2 L2	SLOB
R1 L1 L2	LEIN
R2 L1 L2	CRAIL
L1 L2 R1 R2	EXPERIMENTAL

UBERS for Mac / Marty

L2			HAND IN HAND
R1			SAD SACK
R2			SCOOTER
L1			PADDLE WHEEL
R1 R2		WALKING THE DOG


================================================
	  -=Pro Grabs Trick List (Mac/Marty)=-
================================================

These grabs with these button combos are for the Pro Mod (recommended for controllers with 3 shoulder buttons).
"A" acts also as a modifier, please be aware you can Uber trick with the A button.

Note: The original grab combinations are unchanged - grabs with "X" are new (I've marked them).
Ubers are unchanged.

GRABS for Mac / Marty (freestyle board)

L			Method
Z			Indy
R			Stalefish
X			Swiss Cheese		<--

Z R			Tailgrab
X L			Flying Squirrel		<--
R X			Stiffy				<--
R L			Mute
Z X			Stalemaskey			<--
L Z			Nosegrab

X Z R		Lein				<--
Z R L		Experimental
Z X L		Slob				<--
R X L		Spaghetti			<--
X L Z R		Crail				<--

UBERS for Mac / Marty

L			Hand in Hand
Z			Sad Sack
R			Scooter
R L			Paddle Wheel
Z R			Walking the Dog


=============================
	  -=MD5 Checksums=-
=============================

Search the web if you need help finding a file's checksum or hash.
These are mostly used for troubleshooting purposes (if something fails, check the checksum of the game you are modding).

Example:

MD5		47C64F8E60ECD70161B772ADB7F25109	SSX Tricky (USA) Original (.iso/.gcm)
^Your original copy should match this MD5 checksum.

MD5		F6004E90E18ECBFA0FA4419132955BB4	SSX Tricky (USA) (Pro Mod)
^Your modded game will match this MD5 checksum.


SSX Tricky valid checksums

MD5					47C64F8E60ECD70161B772ADB7F25109	SSX Tricky (USA) .iso/.gcm
SHA1		7ADECBF91FFF0C2B5907B2FD725A11D060EF95E0	SSX Tricky (USA) .iso/.gcm

MD5					5FDFB5A9C5CC20098823F965FDCAB8C4	SSX Tricky (USA) .nkit.gcz
SHA1		8AFA62F5BB9AC22D80D1090A0F121FE59FD7CDDE	SSX Tricky (USA) .nkit.gcz

MD5					54CABB3C41F91AF0134E761A980B7DA8	SSX Tricky (Europe) .iso.gcm
SHA1		360C53B9E61F9BEED6D31FF2E4782A60CDC111E3	SSX Tricky (Europe) .iso.gcm

MD5					DBD4D388DE30E1CA1B18F0BD4FEA2F68	SSX Tricky (Europe) .nkit.gcz
SHA1		7B3E0D5F5EEB576BA8455131C2AA7F09A8B99305	SSX Tricky (Europe) .nkit.gcz

MD5					BEA4DA9C3D9F965BD3C386F6EADB7DE6	SSX Tricky (Japan) .iso/.gcm
SHA1		4241AA2D9C6F9722250CC388B5040B7F71DA4985	SSX Tricky (Japan) .iso/.gcm

MD5					B132C960032DEC123A887630B41EF1D2	SSX Tricky (Japan) .nkit.gcz
SHA1		E4DB2B53BC90C225310AC0BE72AE8C307A06478D	SSX Tricky (Japan) .nkit.gcz


Modded MD5s


USA			297D58B06FD8A688F715DF29BFE854E5	PS2 Grabs Fix

Europe		F92337B6D16D374296D8BA98F04C1973	PS2 Grabs Fix

Japan		BC844BCCCC59B9A83F72B7435F05C6CD	PS2 Grabs Fix


USA			F6004E90E18ECBFA0FA4419132955BB4	Pro Mod

Europe		53A8F3E03D56E70E4FE9A0979FB74261	Pro Mod

Japan		03A3E0D81C0D1AE8293120B26D8D2E35	Pro Mod


USA			C4BFBF338CB969C54F86F6FA6F02FEBC	PS2 Grabs Fix + Pro Mod

Europe		B88C9B2C36B55465E45CD6BB2F235DD9	PS2 Grabs Fix + Pro Mod

Japan		BC5C9807F557E3F229C0FB99A4F66979	PS2 Grabs Fix + Pro Mod


======================================
	   Troubleshooting
======================================

1. Patch tells me to look in the folder for a game, but there isn't any.

Fix:	Please confirm your game is compatible using the table above, and
	try again.

2. A message pops up with a blue screen saying "Windows protected your PC."

Fix: 	Right below the error message, click on "More info" and then select "Run"
	or "Continue" to run the patch.

3. A black window pops up and then quickly closes, or the patch seemingly does nothing.

Fix:	Try running the patch from the CMD prompt. You have to open the
	CMD prompt. Click on the folder location bar at the top of your window
	where your patch folder is located, and in the bar, type cmd and hit enter.
	Once the cmd prompt opens, type Drag and then hit "Tab" once, and it should
	auto-complete to "Drag game onto here.bat" with quotes, just like that.
	Insert a space after, followed by the name of your game (e.g. "SSX Tricky (USA).iso")
	also in quotes, if it has spaces, and hit enter to run the patch on that file.
	Make sure the game is located in the same folder as the patch. You can auto-complete
	entries and cycle through available names in the folder using the "Tab" key.

4. Still doesn't work.

Fix:	Right-click on the patch file and select "Create shortcut."
	Right-click on the shortcut you just created and go to "Properties".
	On the properties page, look up to the box that says "Target", with the
	name of the patch "DRAG GAME ONTO HERE.bat" inside of it. Put your cursor at
	the end of that name, and put a space after the quotation mark. Type in
	the full file name of the game you are trying to patch, and make sure it
	is surrounded by quotes. For example, it should say
	Target: ..."DRAG GAME ONTO HERE.bat" "SSX Tricky (USA).iso"
	or whatever your game name is, just like that. Note the space in between the
	two names, between the different quotation marks. Make sure the typed file is
	EXACTLY the same as how the name of the actual file is, including the extension.
	You can rename your game to make it simpler, or you can right click your game and
	go to "Properties" and look at the top there. The full file name will be in
	a box. The file name must have quotation marks around it, like the example
	above. Make sure you have everything saved correctly, and then
	double-click the shortcut file.
	NOTE: If you right-click and go to the shortcut's "Properties" page and
	click "Advanced" in there, an option to "Run as administrator" will become
	available. Do not select this option at first - selecting it may cause the patch
	not to run at all. However, in the case that the patch didn't run anyway, you
	can try selecting this box afterward anyway and try it again. Just make
	sure that the file name is exact: you must have quotes and you must also have
	the file extension and have the extension inside those quotes. Refer to the
	example above as a guide.

Fix:	Re-download the patch and extract the files again, double-check all of the steps,
	and make sure you've read any error messages closely.


================================
	  -=Acknowledgements=-
================================

z_pucK
Game research, documentation, mod and patch creation, testing, writeups

shoutouts
Dybbles, for help getting everything started with the first project
Minty Meeo - getvalue.exe