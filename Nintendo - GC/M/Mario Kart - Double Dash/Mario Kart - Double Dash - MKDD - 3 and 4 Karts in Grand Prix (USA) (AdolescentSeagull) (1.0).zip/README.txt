3 and 4 Karts in Grand Prix by AdolescentSeagull
This patch enables the Grand Prix mode for 3 and 4 playable karts, previously 3 and 4 Players could only play the Grand Prix mode if coop mode is used (e.g. P1 and P2 vs P3).

All patch files are intended to be used directly on the main.dol file which must be extracted from the ISO file and then added back to the ISO file. This can easily be done by using the program "GameCube File Tools".

NTSC-U.ips is for the American version, NTSC-J.ips is for the Japanese version, PAL.ips is for the European version.