3 and 4 Karts in Grand Prix by AdolescentSeagull
This patch enables the Grand Prix mode for 3 and 4 playable karts, previously 3 and 4 Players could only play the Grand Prix mode if coop mode is used (e.g. P1 and P2 vs P3).

NTSC-U refers to the American version, NTSC-J refers to the Japanese version, PAL refers to the European version.


===== Version History =====
V1.1:
.ips and .xdelta files (with suffix _ISO) have been provided to be used directly on the ISO file. xdelta UI and Delta Patcher can be used to patch the .xdelta files. Lunar IPS can be used for the .ips patch, or via the website https://www.marcrobledo.com/RomPatcher.js/


If you want to apply this patch on the vanilla, unhacked version of the game, make sure that you obtain the game in the uncompressed .ISO format. This should have a size of 1.35GB (1,459,978,240 bytes). Alternatively, you can try patching the main.dol file with GameCube File Tools, with steps detailed below.


V1.0:
Originally contained only the main.dol ips patch files. These files have now been moved to the "main.dol patch files".


===== How to patch the main.dol file from an ISO file =====
Your file can be a ISO file (1.35GB) or an .nkit.iso file.
To patch the main.dol directly, follow the steps using GameCube File Tools:

1. Click on the "Import GCM" file.
2. Locate your .iso file. 
3. Find your main.dol file, which should be under "sys".
4. Right click and click on "Extract File", then save this somewhere safe.
5. Apply the NTSC-U_main_dol.ips, NTSC-J_main_dol.ips or PAL_main_dol.ips patch to your extracted main.dol file. Ideally, the new patched file should be called "main.dol"
6. Go back to GameCube File tools, right click on main.dol again and click on Replace File.
7. Find your newly patched main.dol file.
8. click on "Export GCM".
9. Save your newly patched ISO file somewhere safe and enjoy!