INFORMAÇÕES DO JOGO:

NOME: Metroid Prime 2: Echoes
VERSÃO/REGIÃO: Europeia
PLATAFORMA: Nintendo GameCube
GÊNERO: Exploração
DESENVOLVEDORA: Retro Studios
DISTRIBUIDORA: Nintendo
JOGADORES: 1 no Modo Single-Player e até 4 no Modo Multiplayer

STATUS DA TRADUÇÃO:

MAPA: 100%
TEXTOS GERAIS: 100%
MENUS: 100%

FERRAMENTAS:

Tradução Principal: PrimeWorldEditor
Extração de Arquivos da ISO: GCRebuilder
Extração de Arquivos PAK: PakTool
Editor de STRG final: STRGEditor

COMO APLICAR A TRADUÇÃO:

Esta tradução foi produzida na VERSÃO EUROPEIA do jogo, e por isso, só funcionará na versão europeia de Metroid Prime 2: Echoes.
Para aplicar a tradução, use o arquivo MP2PTBR.xdelta com o programa xdelta UI. Caso não o tenha, baixe neste link: https://www.romhacking.net/download/utilities/598/

HISTÓRIA DA TRADUÇÃO:

O desejo de traduzir este jogo surgiu em 2021. Eu não tinha noção nenhuma de romhacking e meu inglês é bem básico, mas ainda assim, queria poder jogar Metroid Prime 2
em Português do Brasil. Então, fui atrás de ferramentas para extrair os arquivos da ISO do jogo. Só que um problema que nunca consegui lidar, foi abrir os arquivos
.pak, que são extensões proprietárias da Retro Studios. Há ferramentas criadas pela comunidade de Metroid que abrem esses arquivos, mas eu nunca consegui abrir e
isso me fez desistir de traduzir. Mas quando esse desejo voltou, decidi tentar a sorte com um programa que o usuário "angel333119" sugeriu: o PrimeWorldEditor.
Ele permite modificar um monte de coisas nos jogos da Retro Studios, incluindo textos. Inicialmente, comecei a traduzir a primeira versão do Metroid Prime 1 
lançada nos Estados Unidos. Apesar de já existir uma tradução para a versão Europeia, eu queria poder jogar com as quebras de sequência da versão original. No 
entanto, percebi que valia mais a pena traduzir os outros jogos da Trilogia Metroid Prime que ainda não tinham tradução. Então, comecei a mexer no Prime 3
(meu segundo jogo favorito da Trilogia), mas desisti depois de perceber que ele era pesado demais para o notebook que eu estava usando. Aí, finalmente comecei a
mexer no Prime 2. Inicialmente, fiquei traduzindo a versão norte-americana do jogo, mas quando fui testar, ela simplesmente não abria. Não sei o motivo, mas
penso que foi devido eu ter colocado textos com acentuação e cedilha. Decidi apagar toda a tradução já feita e recomeçar com a versão europeia, que abriu com a
tradução. Ao todo, lidei com quase 1400 arquivos de texto.

AGRADECIMENTOS ESPECIAIS:

Meu tio, por ter me dado um Nintendo GameCube, que me introduziu na franquia Metroid;
Meu amigo Jorge, por ter me cedido um Nintendo Wii que me permitiu adentrar ainda mais na franquia;
Minha mãe, por ter tido paciência comigo com o conserto do Wii e a tradução deste jogo;
Ao romhacker angel333119 e Solid One por me ajudarem a corrigir o problema na tradução que impossibilitava zerar o jogo;
A comunidade Metroid, pelas suas contribuições que mantém essa franquia viva até hoje.

ERROS E BUGS:

Se achar erros de ortografia e bugs, me informe através do fórum romhacking. Link do fórum: http://www.romhacking.net.br/index.php?action=profile;u=3438