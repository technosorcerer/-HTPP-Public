SAMUS GOES TO THE FRIDGE TO GET A GLASS OF MILK 3D
A Metroid Prime hack by kkzero

PATCHING INSTRUCTIONS:
Required game version: USA 0-00
After extracting this folder to a convenient spot, follow the steps below:
1. Launch step1-extractfiles.bat, and enter the name or path of your iso. Proceed to 2 if nodtool reports a Success.
	TIPS:
	-Enclose the path in double quotes ("") if it has spaces.
	-In fact, it might be more helpful to just move the iso to the folder this is in so you can just type the filename.
2. Launch step2-patchfiles.bat. If all goes well, you're good to proceed to 3. Optionally, you may just launch main.dol in Dolphin to play if you're emulating.
3. Launch step3-reinsertfiles.bat. If all goes well, then "milk3d.iso" will appear in this folder, and you can now play this hack.