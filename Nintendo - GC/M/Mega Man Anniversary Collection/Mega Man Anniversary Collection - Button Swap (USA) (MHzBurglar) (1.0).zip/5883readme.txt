=====================================================
Mega Man Anniversary Collection GCN Button Patch
=====================================================
Addendum patch by MHzBurglar
Original patch by Nudua at http://nudua.blogspot.com
Original Patch URL: http://www.romhacking.net/hacks/2286/

This patch swaps the Gamecube's A and B buttons.
Please keep in mind that THIS ALSO APPLIES TO THE MENUS, so while the controls
in-game will be fixed, A and B in the menus will now be reversed as a result.

This "addendum" was made to target the more easy-to-find redump.org iso of
Mega Man Anniversary Collection instead of the old iSOSPHERE "scene" dump which
is next-to-impossible to find these days.

The target redump.og ISO details are as follows:
--------------------------------------------------
Name	Mega Man Anniversary Collection (USA).iso
Region	USA
CRC32	0b24ea35
MD5	ce11389361d3b5c60f30ccb1d197f169
SHA-1	80da199d62493396d201e32dc9cb9e00da6ea2fd
--------------------------------------------------

Patching Instructions:

1) Extract the patch and xdelta executables to a folder of your choice
2) Acquire/locate your UNMODIFIED Mega Man Anniversary Collection ISO
3) Apply the mmac.xdelta patch to your unmodified ISO using xdeltaUI.exe

After patching, you can 'scrub' the ISO/convert to nkit if you wish.