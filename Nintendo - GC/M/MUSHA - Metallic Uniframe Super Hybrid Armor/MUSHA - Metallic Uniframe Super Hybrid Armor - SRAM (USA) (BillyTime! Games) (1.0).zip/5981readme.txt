This mod has been in the making for the past 3 months (alongside the same type of mod for Metroid Prime 2: Echoes.) Its the first full scale enemy mod that has actually been released for any of the Prime games, and after working on it for so long, I now know why.... (hint: it was quite hard)

The file that you download is a xDelta file, which is used to patch an unmodified .iso (not gcm) of Metroid Prime (has to be Version 1.02)

All you have to do is use the Delta Patcher included and the patching should be simple!. (It may freeze for a little bit during patching, don't worry this is normal)

I would like to give a big shout out to Aruki﻿ and everyone else on the Metroid Prime Hacking Discord﻿ for making Prime World Editor thus making this mod possible! (Seriously, allot of the people on the discord are way smarter than I am and without the level editor, I wouldn't be able to do anything)

-----------------------------------------------------------------------------------------------------------------------------

						KNOWN ISSUES (important)

﻿						﻿INTRO LEVEL

• Reactor Core - Not really an issue but I made Parasite Queen a bit smaller due to 2 of them normally being to big and clipping out of the shield.

						MAGMORE CAVERNS

• Triclops - They slow down when near other Triclops, this makes it so that when they pick up Samus, they sometimes very slowly drag you to the throw spot.

• Fiery Shores - the 2 Triclops I added don't notice you even if you go into morph ball mode.

• Plated Parasites - They sometimes don't follow their waypoints correctly.

						CHOZO RUINS


• Gathering Hall - Due to potential Freezes, I have deleted the Mushrooms from the room. still lags for a few seconds when you enter the room from "save station 2" (only on dolphin though...seems like it lags even in vanilla, just not as much)

						PHAZON MINES

• Omega Research - Duplicated Elite Pirate isn't visible (though its grenade launcher is) until the shield breaks.

• Elite Quarters - Due to how hard this fight is with 2 of them, I halved the damage the boss's deal to you.

• Metroid Quarentine B - One of the plasma pirates in front of the shield acts.... odd

						IMPACT CRATER

• Metroid Prime Spider Form - Duplicating doesn't work, so I did a little....something instead :) (Ghost/Phazon form is doubled just fine though)

						ALL

• Due to what I would assume is a tactic to save memory, When creatures are far away from you, sometimes they will just freeze until you get close. this makes it so that the path that they follow will be off timed compared to nearby creatures.

• I didn't double the wasp hives (cause I was lazy, though due to what happened in the 2nd game, i'm not inclined to try to duplicate them here) so instead I just made it so that they spawn twice as many wasps twice as fast.



Feel free to tell me if you come into any issues that were not listed above.

						Version 1.15 - 2021-06-21 FIXES


• Flaghara now works! Unfortuantly it crashes while doubled, so I did something special instead :)

• Omega Pirate now for sure sure sure sure doesn't spawn inside the other when in cloaked form.....for sure.

						VERSION 1.13 - 2021-06-20 FIXES


• The last update actually broke the Omega Pirate room and made it crash upon loading, this has been fixed. Also should be even less likely ( or impossible ) for the omega pirate to spawn in the same place as another omega pirate during cloaking.


						VERSION 1.12 - 2021-06-17 CHANGES/FIXES


• Improved Omega Pirate death scenes and NOW it shouldn't crash any more.....Also it should now be less likely that the omega pirate will spawn in the same place that another Omega Pirate is healing at (if both are in their cloaked mode)

• Parasite Queen Barrier Buffed.


						VERSION 1.1 - 2021-06-07 CHANGES/FIXES


						MAJOR CHANGES

• Hive Totem is now "truly" doubled.

• Due to a rare crash during the Omega Pirate Death Cutscene, I removed the cutscene entirely.


						MINOR CHANGES


• Doubled a couple things I forgot to double.

• Fixed snow particles remaining for duplicated sheegoth.

• The first Ridley that dies now deactivates correctly.

• Moved a couple things around.

• You can no longer see the duplicated Elite Pirates Grenade Launcher in Elite Control.

• Fixed camera when you pick up the morph ball bomb that I accidently doubled.









						DIFFERENCES BETWEEN A NORMAL 1.0 ISO

• Fixed a softlock in Phendrana Drifts - Research Core Access.

• Fixed the morph ball camera getting stuck on the Double Bomb Jump ledge in the underwater version of Biohazard Containment. If the camera gets stuck on that ledge, it will reset when you touch the bottom floor of the room.

• Added a trigger in Phazon Mines - Ore Processing that alerts the Wave Trooper on the top floor if the player enters from Main Quarry.

• Minor collision adjustments in Metroid Quarantine B on the wall to the right of the Quarantine Access B door. In particular, it looks like they fixed a couple vertices that were pulled out too far in 0-00. This has the side effect of decreasing the size of the collision bounding box, which means the aether is a bit closer to the room in 0-01.

• Fixed the bug in the intro for the Metroid Prime battle where the white flash stays up permanently if you skip the cutscene at the wrong time.

• After defeating the Phazon Elite in Elite Research, the doors will remain locked until the Artifact of Warrior is collected. If you defeated the Phazon Elite and left the room without picking up the artifact in previous revisions, it would disappear, preventing you from beating the game.

• The root in Chozo Ruins - Ruined Shrine that could be used for sequence breaking is removed.

• The Hunter Metroid in Phendrana Drifts - Frost Cave is removed.