[Francais]

Note de Adonf :

Winning Eleven 6 Final Evolution sur Nintendo GameCube est l'unique jeu de football de la console. H�las il n'est sorti qu'au Japon et le jeu est int�gralement en japonais. J'ai commenc� � jouer � ce jeu en 2006, et j'en avais marre de devoir utiliser les documents de traduction pour avancer les menus. Alors j'ai commenc� � le traduire en Anglais juste pour moi. Actuellement les menus principaux sont traduits, les noms des �quipes, les menus des options, etc. J'ai traduit l'essentiel, je n'ai pas perdu de temps sur les menus d'aides. Il reste encore des menus en japonais, je continuerai peut etre la traduction suivant les retours de ce patch.

Utilisation :

Pour traduire ce jeu, j'ai utilis� plusieurs logiciels : AFS Explorer, WinHex, Gc-Tool et Firefox.
Utiliser le logiciel ppf-o-matic3.exe pour appliquer le patch sur l'iso du jeu.
WinningEleven6FE_GCN_english_ADONF_v03.ppf

Remerciements:

Traduction par ADONF (V03)
Merci � JSR et Lorenzolamas
Merci � la team EXPERiENCE
KEEP THE GAMECUBE SCENE ALIVE


[English]

Note from Adonf :

Winning Eleven 6 Final Evolution is the only game of the PES Serie on Nintendo GameCube. Unfortunately, it was only released in Japan and in Japanese only. I begun to play this game in 2006 and i was fed up using (game)faqs to use the menu. So i begun to translate the game for myself. Actually, most of the menu are in English, team name, Option menu... I translated the essential, i didn't lose my time with help menu. So There are still some part in Japanese. I will continue eventually depending of the feedback.

How to Use :

To translate this game, i used several software such as : AFS Explorer, WinHex, Gc-Tool and Firefox.
Use ppf-o-matic3.exe to patch your backup copy of the game.
WinningEleven6FE_GCN_english_ADONF_v03.ppf

Thanks to :

Translation by ADONF (V03)
Thanks to JSR and Lorenzolamas
Thanks to team EXPERiENCE
KEEP THE GAMECUBE SCENE ALIVE