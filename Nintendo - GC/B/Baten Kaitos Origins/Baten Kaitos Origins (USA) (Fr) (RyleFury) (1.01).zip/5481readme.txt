

      ...................................................................
      .                                                                 .
      .    Baten Kaitos Origin                                          .
      .                                                                 .
      .              Patch FR v1.01                                      .
      .                                                                 .
      .                       par MYTH-Project & Atelier Traduction     .
      .                                                                 .
      ...................................................................




SOMMAIRE :


   I ..... INTRODUCTION 
   II .... HISTOIRE DU JEU
   III ... HISTOIRE DU PROJET
   IV .... L'EQUIPE
   V ..... REMERCIEMENTS
   VI .... NOTES DE L'EQUIPE
   VII ... TRADUCTION
   VIII .. INSTRUCTIONS PATCHS FR ET UNDUB
   IX .... SUPPORTS FONTIONNELS
   X ..... CHECKSUMS
   XI .... RAPPORT DE BUGS
   XII ... VERSION
   XIII .. CONTACTS
   XIV ... REMARQUES LEGALES


------------------
I - INTRODUCTION :
------------------

Le premier opus qui se déroule après était sorti en Europe également sur GameCube en 2003,
soit trois ans plus tôt, avec une équipe composée des anciens membres de Chrono Trigger,
Chrono Cross et Xenosaga (l'influence se fait sentir, non ?). Ce jeu est sorti en Europe
localisé mais malgré de bonnes critiques, il n'eut pas un très grand succès,
potentiellement dû au manque de publicité faite autour du jeu. Le second opus traduit en
français que nous vous proposons aujourd'hui n'est sorti qu'au Japon et en Amérique, certainement
à cause de ces mauvais résultats, même s'il a été annoncé à plusieurs reprises.
 

----------------------
II - HISTOIRE DU JEU :
----------------------

Entre 20 et 1000 ans avant le premier opus...

L'histoire se passe dans un monde d'îles flottant dans le Ciel. Mille ans avant le début
du jeu, un dieu maléfique nommé Malpercio envahit le monde. Il fut défait par cinq héros
magiciens qui scellèrent le dieu maléfique dans les cinq « Magnus ultimes », chacun
caché dans une des cinq îles principales. Les magiciens quittèrent la Terre polluée et
firent léviter les îles dans le Ciel. La majorité des humains se vit ensuite pousser des
« Ailes du cœur ».

(Source : Wikipédia)


--------------------------
III - HISTOIRE DU PROJET :
--------------------------

Ça fait sept ans que rien n'était sorti de nos chaudrons, depuis Parasite Eve 3rd
Birthday en 2013, précisément. Baten Kaitos a été commencé il y a de nombreuses années
(la phase de traduction a débuté en août 2012), et ayant connu de profonds
bouleversements dans sa mise à bien, tous ceux qui ont participé à ce projet sont très
fiers de vous présenter la localisation française intégrale de Baten Kaitos Origin, par
MYTH Project et Atelier Traduction sans qui cette sortie n'aurait pu avoir lieu.

La taille du projet, le temps passé à la traduction et les aléas de la vie réelle ont
fait que l'équipe semblait morte et disparue, mais il n'en est rien. Bleachya43vier et
Pinktagada sont toujours fidèles au poste, Lyan53 doit traîner pas loin de sa tanière
même s'il est en relative hibernation et RyleFury d'Atelier Traduction est venu prêter
main forte au groupe pour terminer le projet.


---------------
IV - L'EQUIPE :
---------------

BadTetsuo (Groupe : Atelier Traduction)
  -- Bêta-test
	 
BahaBulle (Groupe : Génération IX)
  -- Aide et soutien moral
  
Barbe Folle (Groupe : Génération IX)
  -- Traduction

Bleachya43vier (Groupe : MYTH-Project)
  -- Traduction, bêta-test, corrections et harmonisation

Happexamendios (Groupe : Génération IX)
  -- Traduction des textes secondaires

Kipy (Groupe : Chaos RomHack)
  -- Programmation d'outils dédiés à la gestion des scripts

Lyan53 (Groupe : MYTH-Project)
  -- Chef de projet
  -- Hack général
  -- Gestion des outils espagnols

pinktagada (Groupe : MYTH-Project)
  -- Gestion du projet
  -- Traduction scripts principaux et secondaires
  -- Bêta-Test, corrections et harmonisation

RyleFury (Groupe : Atelier Traduction)
  -- Création d'outils pour remplacer les outils espagnols
  -- Création d'outils d'extraction/insertion graphiques
  -- Création des patcheurs FR et Undub
  -- Reprise du hack et de la gestion du projet après la pause de Lyan53
  -- Hack ASM et graphique
  -- Edition graphique
  -- Bêta-test, corrections et harmonisation


-------------------
V - REMERCIEMENTS :
-------------------

A l'équipe espagnole qui a fourni les outils initiaux afin de
commencer le travail de hack.

A tous les membres de la TRAF et romhack.org qui nous supportent
quasi quotidiennement pour leur soutien et leurs conseils avisés

A tous les membres de MYTH-Project et Atelier Traduction qui nous
suivent, nous encouragent et nous soutiennent

A tous ceux qui de près ou de loin ont participé au projet et en
espérant n'avoir omis personne dans la section "L'EQUIPE"


------------------------
VI - NOTES DE L'EQUIPE :
------------------------

Le quart d'heure pinktagada :
*****************************

Que dire, que dire. Jamais le diction plus c'est long plus c'est bon n'aura été
plus faux. Au départ enthousiaste car c'est quand même un projet assez cool,
la taille gargantuesque du script a été le pire des fardeaux. Il a fallu tant
d'années pour terminer la partie traduction, que dire pour la phase de test
qui n'arrivait jamais. C'est la pire indigestion que j'ai pu avoir, à en vomir
et être écœurée d'allumer l'émulateur.

Concernant ma traduction, je suis restée fidèle à moi-même. En essayant de rendre
les dialogues aussi vivants que possible et fidèles aux personnages. Il est certain
que comme toujours, ça ne plaira pas à tous, car on pourra le trouver peu conventionnel.
Qu'à cela ne tienne. Alors, content ou pas content, c'est pareil. Si ça ne vous plaît
pas, essayez-vous au romhack, et faites votre propre traduction.

Je voudrais remercier particulièrement les personnes qui m'ont assistée dans
cette trad mais il y en a bien trop pour tous les citer. 

Merci à ceux qui se sont investis avec nous : Ryle et Yoan en particulier.
Merci aussi à ceux qui supportent mes traductions dans la vie réelle,
Alex qui était à mes cotés au début du projet, Rémi et mon petit Antoine qui
partagent ma vie aujourd'hui, ma famille et mes amis de chair et d'os pour qui
je ne suis que peu disponible.
Et surtout, surtout, les personnes avec qui je bosse.
Les gens de MYTH et de la TRAF. En particulier mon compagnon de souffrance,
Lyan, sans qui on n'irait (je n'irais) vraiment pas loin. Merci à toi pour tout
ce chemin qu'on a parcouru ensemble. Et pardonne-moi d'être relou, pénible,
insupportable, de faire du harcèlement. Je ne m'en rendais pas compte, j'en
suis désolée. Pardon. Sans toi rien de tout ça n'aurait été possible. Ni tant
d'autres choses. Merci mon ami.

Cette traduction n'est pas pour vous, qui allez jouer à ce jeu en français,
mais pour ceux qui sont là quotidiennement à mes cotés, à me supporter
et me soutenir. Ceux qui sont devenus des amis, pourtant à distance.
Des amis auxquels je tiens profondément.

Merci, les copains. Je vous aime.


It's Bleachya's time!
*********************

Wow, quel projet de grande haleine ! Bien qu'ayant participé à plusieurs projets
de traduction depuis mon arrivée en 2012 (!), c'est le premier projet auquel j'ai
participé de bout en bout et qui sort enfin ! Je suis absolument honoré de vous
livrer cette traduction avec mes partenaires (Lyan, pinky, Ryle et confrères...)
sans qui rien de tout cela n'aurait été possible. Ils sont vraiment tous incroyables.
Merci de me compter parmi vous. Pinky, ou Marjo, un salut spécial pour toi, ma maman
de traduction : recevoir ta validation m'a toujours touché au plus profond de mon cœur.
Merci merci merci !

Il va sans dire que ce ne fut pas sans douleur, et tant de choses ont changé depuis
le début de ce projet. Je ne compte même plus les années, ça fait quoi, 7 ans ? Plus ?
J'ai fini par oublier.

J'espère que vous apprécierez la qualité de ce jeu, et le cœur qu'on a mis à écrire
ces textes. Personnellement, c'est je pense la meilleure traduction que j'ai pu
donner à l'heure actuelle (d'autres sont à venir, je l'espère, mais chut).

À très bientôt pour de nouvelles aventures !

Le blabla de RyleFury :
***********************

Je suis le hackeur et le leader d'Atelier Traduction, aussi graphiste, traducteur et correcteur.
Ce projet n'a pas été aussi long pour moi que mes partenaires pinktagada et Bleachya43vier.
Lorsque la trad était terminée, on m'a au départ demandé de m'occuper d'un hack ASM assez complexe
et de hacker la partie graphique du jeu. Lorsque j'avais terminé mon travail, Lyan était censé
éditer les images et gérer le projet jusqu'au bout, mais malheureusement, il est parti sans donner
signe de vie depuis des années maintenant. Afin que le projet ne tombe pas à l'eau, j'ai dû reprendre
le hack du jeu, les outils et le gérer à ma manière. J'ai ainsi édité toutes les images, fait tout
le hack ASM nécessaire pour corriger les divers bugs et améliorer au maximum l'expérience du jeu.

Après que pinktagada en ait terminé avec sa partie lors de la phase de beta-test, j'ai testé
le jeu moi-même de A à Z en tant que correcteur de bugs et de textes. Nous y avons mis tout notre coeur,
et personnellement, j'ai tout fait afin que le résultat soit le plus professionnel possible avec la
trad la plus fluide possible.

Je tiens à dire que pinktagada et Bleachya43vier sont des traducteurs avec beaucoup de potentiel.
Pinktagada a été presque la seule à accepter de participer à la beta de mes deux premiers projets
en français : Atelier Iris et Mana Khemia, et je lui en serai toujours reconnaissant pour ça.

Pour ma part, bien que je me concentre surtout sur les projets de mon équipe d'Atelier Traduction,
ça ne m'empêchera pas d'aider MYTH de temps en temps principalement pour des hacks compliqués ou
hacks/éditions graphiques, sachant que l'édition graphique donne des boutons à pinky x)

Ce qui m'a surtout touché, c'est que bien qu'une certaine personne qui se reconnaîtra est très têtue,
les gens avec qui j'ai travaillé sur ce projet ont été sérieuses jusqu'au bout, et c'est ce qui
a permis de mener ce projet à bien :)

J'espère vraiment qu'un grand nombre d'entre vous pourront en profiter pleinement, ce serait la
meilleure forme de récompense pour nous (du moins pour moi ^^).


------------------
VII - TRADUCTION :
------------------

Le patch FR traduit le jeu à hauteur de 100%.

Tout le jeu devrait être traduit normalement sauf si de manière incroyable
et malgré toutes les vérifications quelque chose serait passé au travers.


---------------------------------------
VIII - INSTRUCTIONS PATCHS FR ET UNDUB:
---------------------------------------

Patch Undub :
*************

Pour ceux qui souhaitent jouer avec les voix jap, RyleFury a créé un patch
Undub (voix jap) compatible avec notre traduction FR. Le patch Undub est à
appliquer après le patch FR.

Le patch Undub est disponible à cette adresse :
http://myth-project.fr/ftp/patchs/BKO_undub_patcher.rar

Si le lien ne fonctionne plus, le patch Undub est aussi disponible à cette adresse :
https://ateliertraduction.forumgaming.fr/t40-le-patch-de-baten-kaitos-origins-est-disponible


Comment appliquer le(s) patch(s) :
**********************************

Les patcheurs FR et Undub sont compatibles avec Windows uniquement.

- Placez les 2 fichiers ISO de Baten Kaitos Origins (2 disques) en version US
  (nommé n'importe comment *.iso) dans le répertoire "Patch".

- Lancez "Patcheur_BKO_FR_v1.01.exe".

- (Optionnel) Utilisez le patch Undub téléchargeable à part sur la version FR du jeu.


---------------------------
IX - SUPPORTS FONTIONNELS :
---------------------------

Le jeu a été testé entièrement sur :

- L'émulateur Dolphin (privilégiez les versions beta de l'émulateur car mieux optimisées)
- La Wii avec la rétrocompatibilité GameCube sur DVD gravé
- La Wii et la Wii U avec Nintendont sur support USB (super fluide, sans le moindre bug ni lag audio)


---------------
X - CHECKSUMS :
---------------

Version US - ISO disque 1 (CRC32) : ADF9FCB3
Version US - ISO disque 2 (CRC32) : B835FE56
Version FR v1.01 - ISO disque 1 (CRC32) : 8640ADA7
Version FR v1.01 - ISO disque 2 (CRC32) : CE2A8F82


----------------------
XI - RAPPORT DE BUGS :
----------------------

Dans le but de nous aider à améliorer notre patch, si vous rencontrez dans
ce dernier des fautes d'orthographe, des bugs graphiques ou autres coquilles
à coté desquels nous serions passés, n'hésitez pas à nous le signaler dans
la section dédiée à cet effet ou sur les forums "ROMhack.org" ou "MYTH-Project"
afin que nous puissions les corriger dans un futur patch correctif.
Nous avons besoin de vos retours pour ce faire, merci.

(Pour nous trouver, voir dans "CONTACTS" ci-dessous)


---------------
XII - VERSION :
---------------

 ~ Version 1.01 ~ 21 juillet 2020

     - Quelques fautes plus ou moins importantes corrigées.

 ~ Version 1.0 ~ 03 avril 2020

     - Sortie publique du patch avec 100% des textes et images traduits
     

-----------------
XIII - CONTACTS :
-----------------

N'hésitez pas à nous faire part d'éventuelles questions ou remarques, à nous
rapporter de possibles bugs, fautes de français, ou même de passages non
traduits qui nous auraient échappés, aux adresses suivantes :

   + MYTH-Project : http://myth-project.fr/
   + Forum FR hack et trad de JV console : http://www.romhack.org/ 
   + Site de la TRAF : http://traf.romhack.org/


-------------------------
XIV - REMARQUES LEGALES :
-------------------------

Atelier Traduction & MYTH-Project vous proposent une traduction non-officielle
réalisée dans un but non lucratif par des amateurs bénévoles. Elle n'est
en aucun cas supportée par Nintendo ou Monolith Software.

Vous avez le droit de distribuer ce patch comme bon vous semble, et de le faire
paraître sur un support quelconque (CD, web, ...) tant que vous ne modifiez pas
le contenu de l'archive, ni que vous fassiez payer les utilisateurs qui
obtiennent ce patch (hormis les éventuels frais de port et/ou de support). 

En aucun cas vous n'avez le droit de distribuer une version prépatchée du jeu,
ni de distribuer ce patch avec le jeu associé dans un même package. Vous devez
avoir en votre possession le jeu original afin d'utiliser cette traduction. Ce
patch n'est nullement produit dans le but de favoriser la distribution illégale
du jeu.

Ce patch est livré sans aucune garantie. En tant qu'utilisateur, vous
reconnaissez en faire usage à vos risques et périls. Nous ne pouvons en aucun
cas être tenus pour responsables de dommages éventuels causés par l'usage de ce
patch.

                                     (c) 2011/2020 Atelier Traduction & MYTH-Project
                                         Tous droits réservés
										 