Baten Kaitos Origins Uncensor Patch v1.0 by Helsionium
------------------------------------------------------

########################
# 1. PATCH DESCRIPTION #
########################

This patch consists of two independently selectable patches that remove censorship from the USA version of Baten Kaitos Origins.

a) Vega Building Site patch:
   Replaces the metal block to which Sagi is temporarily bound with a cross, matching the original Japanese version.
   
b) Chaotic Dance patch:
   Restore the original version of the battle BGM "Chaotic Dance 2", the lyrics of which have been censored for the American release.

#########################
# 2. APPLYING THE PATCH #
#########################

 - Prerequisite: Java 8 or higher must be installed
 - Drop the BKOUncensorPatch_v100.jar file into a folder containing BOTH of the Baten Kaitos Origins images you want to patch
 - Execute the patcher by launching BKOUncensorPatch_v100.jar (typically by double-clicking on the file, if Java is properly installed)
 - Select which of the two patches you want to apply in the patch program's user interface and click on the "Patch" button
 - The program does not overwrite the original images. If your image was named disc1.iso, the patched file will be named disc1_patched.iso
 - Close the patch program when the process is finished (you can't close it during the patching process) 

####################
# 3. COMPATIBILITY #
####################

The patch is compatible with a wide range of images, including shrunk image files.

Vega Building Site patch:
 - Fully compatible with the original USA version and the undub patch (Text when checking the cross will be changed appropriately)
 - Partially compatible with the French fan translation by MYTH-Project, versions 1.00 and 1.01 (French text will not be changed)
 - Limited compatibility with all other translations, as long as they don't modify file E00079BC.
   (Some item-related texts in the room affected by the patch will revert to English)
 
Chaotic Dance patch:
 - Compatible with all versions based on the USA version, including undub patch and all current and future fan-translations, as long as they don't modify file 7000F48B
 
#############
# 4. AUTHOR #
#############

Patch and patcher created by Helsionium while working on a German fan-translation of BKO (https://bko.helsionium.eu)
 
Third-party code used in this patcher:
- BKO decompression code courtesy of RyleFury (Atelier Traduction)
- Public domain LZMA code written by Lasse Collin (https://tukaani.org/xz/java.html)

Contact information: bko AT helsionium DOT eu

If you want me to update this patch to fully support your fan translation, I need the following information about your version:
 - Name of the valuable item "Magnus Pack Coupon", names of the Magnus "Zelos Kune" and "Mixer" in your language
 - If you changed the name of Sagi, his new name
 - Your uncompressed file 60006009
 - optionally, a second version of your file 60006009, with the "iron block" in dialogue number E00079BE:391392D replaced by a cross

###############
# 5. VERSIONS #
###############

v1.00 - November 23, 2020
- Initial release