DEUTSCH:

Dieser Patch beinhaltet unter anderem eine vollständige Übersetzung des Spiels "Baten Kaitos Origins".

Benötigt werden:
 - ein unterstütztes Image
	- USA-Originalversion von Baten Kaitos Origins
	- USA-Version von Baten Kaitos Origins mit Undub-Patch
	- Auch verkleinerte (scrubbed/shrunk) Images werden unterstützt
	- NICHT UNTERSTÜTZT: frühere Versionen der deutschen Übersetzung
	- einzelne Patches (außer der Übersetzung) können mit anderen Sprachversionen kompatibel sein
 - Java 8 oder höher
 
Anwendung:
 1. Die Images und das Patch-Programm in denselben Ordner geben.
 2. Das Patch-Programm ausführen. Unter Windows genügt in der Regel ein Doppelklick auf das Programm, wenn Java installiert ist. Unter anderen Betriebssystemen funktioniert das eventuell anders.
 3. Wähle die Patches aus, die du anwenden möchtest, und klicke auf "Patches anwenden".
    BEACHTE BITTE, dass ein Patch zur Behebung eines Absturzes auf dem Schlachtfeld zu Atria in jedem Fall angewendet wird, EGAL WELCHE Patches sonst ausgewählt werden.
 4. Dabei werden die Originaldateien werden nicht überschrieben, sondern neue Image-Dateien erzeugt.

Falls sich der Patch bei "FILE_50006100" länger als eine Minute aufhängt:
 - Beende das Patch-Programm zwangsweise (bei Windows über den Taskmanager)
 - starte den Patcher mit der "patch.bat"-Datei (Windows) oder über die Kommandozeile "java -Xmx1200M -jar BKO-PatchTool-DE-v1.2.jar" (Linux/andere Betriebssysteme)

Für weitere Details bitte https://bko.helsionium.eu/deutsch/ besuchen.

#######################################################################

ENGLISH:

This patch contains a complete German translation of the game "Baten Kaitos Origins", among other patches.

Required:
 - a supported image
	 - original US version of Baten Kaitos Origins
	 - US version of Baten Kaitos Origins with "undub" patch
	 - Scrubbed/shrunk images are supported as well
	 - NOT SUPPORTED: earlier versions of the German translation
	 - some patches (except the German translation) may be compatible with other language versions
 - Java 8 or higher
 
How to use:
 1. Place the images and the patch program into the same folder.
 2. Run the patch program. On Windows, double-clicking on the program is usually sufficient if Java is installed. On other operating systems it may work differently.
 3. Select the patches you want to apply and click on "Apply patches"
    PLEASE NOTE that it will apply a bugfix to prevent a possible crash in the Battlefields of Atria NO MATTER WHAT patches you select.
 4. The original files will not be overwritten, new image files will be created.

If the patcher hangs at "FILE_50006100" for more than a minute:
 - Force-terminate the patcher (e.g. via Task Manager on Windows)
 - start the patcher via the "patch.bat" file (on Windows) or via command line "java -Xmx1200M -jar BKO-PatchTool-DE-v1.2.jar" (Linux/other OSes)

For more details, please visit https://bko.helsionium.eu/deutsch/ (in German only)