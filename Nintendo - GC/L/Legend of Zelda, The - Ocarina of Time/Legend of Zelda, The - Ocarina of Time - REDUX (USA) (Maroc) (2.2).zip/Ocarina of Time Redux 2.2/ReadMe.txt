//---------------------------------------------------------
//	OCARINA OF TIME REDUX
//---------------------------------------------------------
Romhacking release: https://www.romhacking.net/hacks/5138/

Ocarina of Time Redux is a hack aims at improving the original experience of Ocarina of Time by adding some QoL improvements by applying the ASM patches provided by the Ocarina of Time Randomizer project by Roman971 and its contributors. (NOTE: For a full list of the Credits per-dev, please check the ReadMe. Adult Link 3D model made by SkilarBabcock, with permission to use for this project: https://youtu.be/x6MIeEZIsPw))

NB: Use an Ocarina of Time US 1.0 ROM for patching, for both the normal Ocarina of Time Redux and Master Quest Redux patches.

//------	FEATURES

The main Ocarina of Time Redux features:

* Text speed now goes 2 times as fast as the original.
* Text revamp, restored and revised based on subsequent releases of Ocarina of Time.
* Fixed graves behaviour like in subsequent versions.
* Properly center the "Navi" text in the C-Up button.
* Collecting Gold Skulltulla Tokens no longer freezes the player but allows it to continue moving. This is similar to what happens in Majora's Mask spider houses.
* D-PAD can be used to quickly access ocarina and iron/hover boots.
* Rupee color of the rupee count indicator now changes in color to reflect the wallet upgrade possessed.
* Stone of Agony now works even without rumble. An icon will appear over the rupee count when in proximity of a hidden grotto.
* Farore's Wind does not get dispelled through time travel and can be used independently by child and adult Link.
* The bunny hood now works like in Majora's Mask boosting movement speed when worn.
* Bombchu Bowling prizes now appear in fixed order instead of random (Rotation being: piece of heart, purple rupee, bomb bag capacity upgrade, bombs).
- Fishing made easier by guaranteeing biting, but keeps the fish size RNG from the original game.
* Biggoron has you wait 2 days instead of 3 to forge the Biggoron Sword.
* Default Z-targeting is automatically set to HOLD by default.
* Burning Kakariko cutscene now starts by entering Kakariko from any entrance instead of only the main one.
* Song of Storms cooldown is removed, additionally it can be used in every ambient.
* Warp songs and Farore's Wind can now be used inside Gerudo Training Grounds and Ganon's Castle.
* Lab diving heart piece can now be obtained at all times.
* Increased speed of block pushing.
* Subscreen delay fix.
* Extended draw distance.
* Requires All Medallions to unlock the bridge for Ganon's Castle (original game only requires Shadow and Spirit).
* Unlocked Tunics for Young Link.
* Updated Young and Adult Link 3D models. Young Link is based on his MM 3D model, and Adult Link is a custom MM Adult Link 3D model made by SkilarBabcock, given permission by him to use for this project: https://youtu.be/x6MIeEZIsPw
* All other vanilla features (Rewards, Cutscenes and Animations) are retained.


Master Quest Redux:
* Same features as Ocarina of Time Redux by default
* All Dungeons set to Master Quest layouts
* Master Quest title screen
* MQ text dialogue colors
* Change Button Colors: GC OoT Button Colors
* Censored Fire Temple song from v1.2 and GC releases
* Censored Gerudo textures from v1.2 and GC releases
* Censored blood (Green) from v1.2 and GC releases


//------	CUSTOMIZATION

But what if you want to have the censored Fire Temple in OoT Redux, and not exclusive to the Master Quest patch?
Or you want the censored Gerudo textures, or you want a higher text speed (like 3x) or want certain features, and not others?
That can easily be changed, thanks to an amazing software called Patcher64+ Tool, which allows you to toggle whatever feature you want on or off according to your liking, so you can create your own custom Ocarina of Time / Master Quest Redux ROM!
You can download the software here if you want to customize your own ROM patch:
[link=https://github.com/Admentus64/Patcher64Plus-Tool/releases]Patcher64 Tool[/link]

//------	PATCHING INFO

ROM / ISO Information:
* Database match: Legend of Zelda, The - Ocarina of Time (USA)
* Database: No-Intro: Nintendo 64 (v. 20180814-043336)
* File/ROM SHA-1: AD69C91157F6705E8AB06C79FE08AAD47BB57BA7
* File/ROM CRC32: CD16C529


//------	CREDITS

AmazingAmpharos:
	- Text speed now goes 3 times or 2 times as fast as the original (Download includes both patches).
	- Bombchu Bowling prizes now appear in fixed order instead of random (piece of heart, purple rupee, bomb bag capacity upgrade, bombs).

Roman971:
	- Collecting Gold Skulltulla Tokens no longer freezes the player but allows it to continue moving. This is similiar to what happens in Majora's Mask spider houses.
	- Rupee color of the rupee count indicator now changes in color to reflect the wallet upgrade possessed.
	- Song of storms cooldown is removed, additionally it can be used in every ambient.
	- Lab Diving heart piece can now be obtained at all times.
	- Warp songs and Farore's Wind can now be used inside Gerudo Training Grounds and Ganon's Castle.
	- Fishing made easier by removing most RNG and guaranteeing biting.

Krimtonz:
	- D-PAD can be used to quickly access ocarina and iron/hover boots.
	- The bunny hood now works like in Majora's Mask boosting movement speed when worn.
    Dampe's digging tour prize is guaranteed first try instead of random. Additionally he can dig anywhere instead of only on dirt patches.
    Burning Kakariko cuscene now starts by entering Kakariko from any entrance instead of only the main one.

Fig:
	- Increased speed of block pushing.

rlbond86:
	- Stone of Agony now works even without rumble. An icon will appear over the rupee count when in proximity of a hidden grotto.
	- File select screen now displays all collected items instead of simply showing hearts and medallions/stones.

KevinPal:
	- Farore's Wind does not get dispelled through time travel and can be used independently by child and adult Link.

junglechief:
	- Additionally a lonely big fish is added in the top-left region.
	- Biggoron has you wait 2 days instead of 3 to forge the Biggoron Sword.

TestRunnerSRL:
	- Default Z-targeting is automatically set to HOLD by default.

Maroc:
	- All other vanilla features (Rewards, Cutscenes and Animations) are retained.
	- Several bugfixes and rework of Randomizer features to work on vanilla OoT

Zel:
	- Subscreen Delay Fix

SkilarBabcock:
	- Custom MM Adult Link 3D model: https://youtu.be/x6MIeEZIsPw

Admentus:
	- Patcher64+ Tool

ShadowOne333:
	- Text script revision and restoration from other OoT versions
	- Master Quest dungeon port from GC releases to v1.0
	- Master Quest custom title screen for v1.0 (Images & flame colours)
	- Fire Temple song port from v1.2 to v1.0
	- Gerudo textures port from GC to v1.0
