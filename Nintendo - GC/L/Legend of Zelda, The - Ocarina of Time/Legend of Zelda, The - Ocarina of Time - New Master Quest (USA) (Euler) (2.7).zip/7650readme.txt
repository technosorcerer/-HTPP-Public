# Patch Information

New Master Quest Version 2.7
Released by Euler

Download Link: https://www.romhacking.net/hacks/7650/

# How to patch

Ocarina of Time 1.0 ROM (CRC32: CD16C529) is required for the patch.

There are four types of patch files. 
1. OoT New Master Quest v2.7 Normal Edition (ENG).bps
2. OoT New Master Quest v2.7 Normal Edition (JPN).bps
3. OoT New Master Quest v2.7 Master Mode Edition (ENG).bps
4. OoT New Master Quest v2.7 Master Mode Edition (JPN).bps 

Select one of the four patch files and apply it to 1.0 ROM.

Master Mode Edition adds the following options to Normal Edition.
1. Some cutscenes, such as the opening, will be skipped.
2. All damage Link receives will be doubled.
3. Boss and Mini-Boss HP will be doubled.
4. Recovery Hearts will not drop from grass or enemies.
5. The amount of recovery by potions and fairies will be reduced.

# Changes

All dungeons changed
Several other maps changed
Gold Skulltula and Big Poe rewards changed
Some enemies behavior changed slightly
Gravestones in Kakariko Village Graveyard can be moved even during the day (Child Link)

And the following changes were made using Patcher64+ Tool. Thank you to all the hackers in the community.

The latest Redux for OoT - Credits "Admentus"
Redux Options Menu - Press L in Pause Screen - Credits "Admentus"
D-Pad Dual Set - Press L + R ingame to swap between layouts - Credits "Admentus"
Fast Bunny Hood - The Bunny Hood makes Link run faster just like in Majora's Mask - Credits "Ported from Redux"
Bombchu Drops - Bombchus can now drop from defeated enemies, cutting grass and broken jars - Credits "Ported from Redux"
Stone of Agony Indicator - The Stony of Agony uses a visual indicator in addition to rumble - Credits "Ported from Redux"
Allow Warp Songs - Allow warp songs in Gerudo Training Ground and Ganon's Castle - Credits "Ported from Rando"
Allow Farore's Wind - Allow Farore's Wind in Gerudo Training Ground and Ganon's Castle - Credits "Ported from Rando"
Poacher's Saw - Obtaining the Poacher's Saw no longer prevents Link from obtaining the second Deku Nut upgrade - Credits "Ported from Rando"
Require All Medallions - All six medallions are required for the Rainbow Bridge to appear before Ganon's Castle - Credits "Ported from Rando"
Bombchu Bowling - Bombchu Bowling prizes now appear in fixed order instead of random - Credits "Ported from Rando"
Difficulty - Boss HP, 2x Damage, No Heart Drops - Credits "Admentus, Three Pendants & Rando"
Harder Enemy - Stalfos, Wolfos, Dark Link - Credits "BilonFullHDemon"
Pause Screen Delay - Removes the delay when opening the Pause Screen by removing the anti-aliasing - Credits "zel"
Remove Fishing Anti-Piracy - Removes the anti-piracy check for fishing that can cause the fish to always let go after 51 frames - Credits "Ported from Rando"
Spirit Temple Mirrors - Fix a broken effect with the mirrors in the Spirit Temple - Credits "ZethN64, Sakura, Frostclaw, Steve(ToCoool) & GhostlyDark (ported)"
Boomerang - Fix the gem color on the thrown boomerang - Credits "Aria"
Force Hires Link Model - Always use Link's High Resolution Model when Link is too far away - Credits "GhostlyDark"
Majora's Mask Interface - Credits "Ported by GhostlyDark"
Rupee Icon Colors - The color of the Rupees counter icon changes depending on your wallet size - Credits "Ported from Redux"
Empty Bomb Fix - Fixes Empty Bomb Glitch - Credits "Ported from Redux"
Show File Select Icons - Show icons on the File Select screen to display your save file progress - Credits "Ported from Redux"
Big Goron Fix - Fix bug when trying to trade in the Biggoron Sword - Credits "Ported from Redux"
Dampe's Digging - Dampe's Digging Game is always first try - Credits "Ported from Rando"
Dampe Fix - Prevent the heart piece of the Gravedigging Tour from being missable - Credits "Ported from Redux"
Hyrule Guards Softlock - Fix a potential softlock when culling Hyrule Guards - Credits "Ported from Redux"
3x Text Speed - Set the dialogue text speed to be three times as fast - Credits "Ported from Redux"
Disable low health beeping - Credits "Ported from Rando"

Download Link: https://github.com/Admentus64/Patcher64Plus-Tool

# Known issue

Only when playing on Wii VC, after getting the magic jar, the magic meter is disabled.
This can be resolved by disabling the D-Pad (Pressing L button on the pause screen)

# Changelog

## v2.7
Fixed possible crash in Morpha's room when playing on Wii VC
Gravestones in Kakariko Village Graveyard can be moved even during the day and Fairy's Fountain in Graveyard is now available without bomb
Harder Gerudo Fighter, Flare Dancer, King Dodongo
Small update some maps

## v2.6.X
Harder Iron Knuckle, Meg
Harder Volvagia, Morpha, Twinrova, Ganondorf
Small update some maps
