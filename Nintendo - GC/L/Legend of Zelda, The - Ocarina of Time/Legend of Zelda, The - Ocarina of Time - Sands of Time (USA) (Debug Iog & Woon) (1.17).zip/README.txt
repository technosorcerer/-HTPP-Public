Please google "how to patch n64 rom bps”, and make sure you have OoT 1.0 USA .z64 rom if you're not sure how to play the game.
All my testing was done on Project 64 3.0 with the GlideN64 graphics plugin and it’s stable enough.

Update Log

2024/11/29
1.17 ver main compatibility fix
Added one tip about Song of Flame
Removed a torch in the Desert Fortress scene that could cause sequence break 
Reduced the difficulty of a sneaking section in the Desert Fortress scene
Changed the position of a golden Skullwalltula in the Factory scene to make it available
Changed the position of a Heart Piece in Dampe’s chase scene to make it more fair
Fixed a random crash when entering the boss room in Abyss scene on Ares
Fixed a crash when entering the Dead Hand room in Dampe’s chase on Ares
Fixed a crash when attacking a Like Like on more accurate emulators

2024/11/28
1.16 ver Hot Fix
Fixed a bug where save & reloading in sweatshop would return your items
Fixed a crash in dog sidequest room
Added insurance that the long sword will come back to inventory after reloading
(For a rare inventory bug that may occur after you getting the heart piece in the fishing pond)
Fixed a crash issue in Death Temple scene

1.15 ver for some reasons wasn’t uploaded correctly. I apologize for the inconvenience

1.14 ver main compatibility fix
Changed a few of platform jumping in the Factory scene to reduce difficulty
Fixed a crash on the final boss when playing on more accurate emulators.
Fixed flawed collisions in several scenes
Reduced the size of rom significantly by removing unused vanilla content

2024/11/26
1.13 ver Hot Fix
1.12 is broken according to reporting
Remove accidentally used duplicate flags
Fixed a crash caused by shooting arrows into water in more accurate emulator
Fixed a crash caused by opening lens of truth chest
Fixed the issue where big goron's sword not be selectable after escaping the sweatshop (if you've beaten this dungeon, buy a nail sword to fix it)

1.12 ver
Fixed a typo in map title card 
Reduced the difficulty of several puzzles in Forest Valley scene
Reduced the difficulty of one of the silver rupee in Swamphell scene
(I’m sorry they were being kaizo before)
Fixed potential sequence breaking issues in Desert Fortress, Ganon’s Tomb and Abyss scenes
Changed the structure of Abyss scene slightly to reduce the difficulty of navigation
Corrected collisions in several scenes
Fixed poe collector that can reward repeatedly when you killed all of the poes
Fixed a flag issue in the Forest Valley scene.
Corrected several dialogues
Added several hints.
Some small changes

2024/11/25
1.11 ver
Fixed bottle swap bug
Changed actor configuration for Landfill scene.
Fixed the intro cutscene not looping correctly.
Renamed a provided option. 
Removed the “void out” property of the fan actor in the Fishing Pond scene
Fixed the lifting platform might not move anymore in the Abyss scene
Removed custom GI model for lens of truth

1.10 ver
Fixed respawn point bug in Big Brother’s Trial.scene
Fixed some of texture glitches in The Factory scene 
Fixed small key counter not showing up in The Factory scene 
Fixed poe collector disappear when you hit 2000 poe points

Thanks to:
Jinnosuke
Shoopey
StoneeBadLuck
Nokaubure
Pugsly
X dude awesome
Owl
Richie
Syeo
Goblinlord
Grandlovania
Sklitte

Special Thanks:
Cursed Crafts

Pack used:
Hylian Actor Pack, check out the link for full credit list: https://github.com/hylian-modding/hm-actor-pack
z64rom MM Skybox, by ZeldaBoy
Ball of Bones Custom Miniboss, by Jinnosuke
Majora's Mask actor pack for OoT by X dude awesome
Stalmaster by Grandlovania
Texture Pack from OoT, OoT3D, MM and MoT by xor, doncamilo, CrookedPoe

Tool used:
z64rom, Blender, Sharp Ocarina, Zelda64 Text Editor, zztexview, SceneTatl, Fast64, FL Studio, Sekaiju

If I've used original content that you've created and your name isn't noted in the credits, please contact me.

