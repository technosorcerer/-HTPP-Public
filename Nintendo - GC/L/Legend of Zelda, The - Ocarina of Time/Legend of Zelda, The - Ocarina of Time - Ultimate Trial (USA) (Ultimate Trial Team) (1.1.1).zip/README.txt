****
INFO
****

You can use this link to patch a mod: https://hack64.net/tools/patcher.php. You would need to provide the rom and the patch.

The patch is for US 1.0 ROM.

This mod is compatible with most emulators, hardware and Wii. For the best possible experience, it's recommened to use hardware or emulator.

Please note that although it is possible to finish the game on Wii, the Motion Blur is incompatible and is therefore disabled on Wii.

The game is NOT compatible on Bizhawk. Several freezes and crashes have been observed while using this emulator.
There might be some little lags on N64. There are some z-fighting on some textures in some scenes.

For Wii users:
There's a secret in this game that we're sorry to say can't be used on Wii, you'll be informed once you find it.

For PJ64 users:
Activating the "Always use interpreter core" option is highly recommended.

If you notice any issue or have any feedback, suggestion, feel free to let us know on our Discord Server! There, you can find a guide for the game so you know how to unlock certain things if you get stuck.


***************
CHANGELOG 1.1.1
***************

https://github.com/RichieUltimate/ultimate-trial


*************
COMPATIBILITY
*************

The game has been tested with:
Simple64, N64, Dolphin, RetroArch, Ares, Project64
 

*******
CREDITS
*******

Ultimate Trial Team:
Richie, Syeo, ZeeRoX, hiisuya, ShuggyTheBuggy, aegiker, Zeraphyr, Woon

Tools used:
Fast 64, Decomp, OOT Scene Tool by rogual, Reaper, FL Studio, Seq64 1.5, Sekaiju, gzinject, z64compress

Helpers:
Debuglog, Le Seducteur, Space World Devs, Kentonm, Yanis, Tharo, Dragorn421, thinedave, rogual, Fig, owl is not a cat

Asset Creators:
Le Seducteur, Amara, Space World Devs, Kentonm, Salom, Rikugo.studio, CDi-Fails, scittykitty

Playtesters:
ShuggyTheBuggy, DezZival, Mark Kurko, Tharo, bradyOne

Translators :
Babou Linet (French translator), Only1_Rudeboy (German translator), RetroEggy (German translator)



Special Thanks to HylianModding for the community and Nintendo for creating TLoZ: Ocarina of Time

This is a non-commercial and fan-based project!

Thanks for playing Ultimate Trial!



