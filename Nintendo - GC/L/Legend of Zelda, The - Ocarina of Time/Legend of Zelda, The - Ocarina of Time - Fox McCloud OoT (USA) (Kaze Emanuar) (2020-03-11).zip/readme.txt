This is a 1.0 US ROM of The Legend of Zelda: Ocarina of Time.

The BPS patch will work online but with glitches. The other players will appear as Link with glitched out textures. Those players still see on their screen that they are Fox

The decompressed ROM works with OoT Randomizer 2.0.0.

Credits:

Model: https://www.models-resource.com/nintendo_64/supersmashbros/model/29125/
Model Import: Zeldaboy14
Sounds and gun: Kaze Emanuar

Special thanks to Kaze Emanuar. Please support his Patreon for more romhacks.