=== OoT Multiplayer v1.0.3 ===

BREAKING NEWS! The 4 Player codes and 2 Player codes are fused into one cheat list!

Two versions are included:
- Original 4 Player version
- New 2 Player version

Add/removal notes: (* = Recently added)
- Subscreen Delay Fix Implemented
- Removed Controller 2's Debug Memory Editor
- Pressing D-Pad on Controller 1 no longer controls cutscenes
- Input Display removed
- Debug Camera for Controller 3 removed
- Credits cutscene crash fixed
- Navi's voice is no longer used during Z-Targeting
- Removed Low-Poly
-*When starting a new game, skips to Navi waking Link up
-*On the title screen, the words PRESS START are replaced with OoT2P Co-Op or OoT4P Co-Op depending which one you're playing

Cheat list notes:
- Fixes a lot of entrance issues for players
- Fixes many cutscenes from crashing
- Fixes Z-Targeting camera for all players
- Fixes some item glitches, like players being locked after throwing boomerang
- Fixes Player 1 from freezing after a cutscene
- Fixes when players are invisible after song warping
- Fixes players from push/pull blocks forever
- Fixes sword swinging when trying to use a Spin Attack
-*New version of code that allows players to bypass doors/walls
-*In Help > About Config Files, you can see in the .cht section that the creator is Sho'

Extra notes:
- Before playing either version, make sure to ALWAYS have the following codes checked before starting the game...
   - Enable "4 Swords Codes" if you're playing the regular 4 Player OoT Multiplayer
   - Enable "OoT 2 Player Codes" if you're playing the 2 Player version
   - DO NOT USE ONE ON THE OTHER VERSION OR THE GAME MAY HAVE ISSUES OR CRASH
- On 2 Player Version, Player 2 Link is controlled by Controller 4
- If playing Netplay on 2 Player Version, server host needs to have 3 controllers connected

Credits:
- spinout182 (original OoT Multiplayer hack)
- jmanx990 (original cheat list for OoT Multiplayer hack)
- Sho' (readding broken functions & newer cheat codes)


