Sands of Time by Debug Log, Woon

Please google "how to patch n64 rom bps”, and make sure you have OoT 1.0 USA .z64 rom if you're not sure how to play the game.
All my testing was done on Project 64 3.0 with the GlideN64 graphics plugin and it’s stable enough.

Update Log

1.22 ver Hot Fix
(Thanks Nokaubure for fixing subscreen map editor to make it possible)
Added subscreen maps for 10 scenes including all major dungeons
Added compasses and maps items in the corresponding scenes
Fixed a soft lock in Desert Fortress scene
Some small changes
Disabled debug features

1.21 ver subscreen maps update

1.20 ver main dialogues fix
Grammar and typo fix (Thanks to The Lady Zelda)
When Link gets pushed off from a cliff by a fan, he will not grab the ledge unless he’s in iron boots
Display title cards every time you enter the scene
More hints
Some small changes

1.19 ver 100% completion fixes
Fixed all missing GS and heart pieces, making 100% possible
Added new 120 GS reward
Fixed a nasty bug that can overwrite data
Removed the sinking attribute for the ground of the Landfill dungeon
Reduced the difficulty of multiple levels
Make time block easier to trigger by Song of Slave on hardware
Added more hints based on feedback
If you leave the sweatshop scene without Nayru's Love, you can trigger the auction event again.
If you lost your Zora Workwear in the previous version, you can get it back by talking to uncursed skulltula people again.
Playing Song of Flame in boss scenes will warp you to the corresponding dungeon.
Fixed a flag issue on a shutter door in Big Brother's Trial scene
Corrected the positions of several floor switches to make them easier to press
Added supplies to several areas
When you die and respawn, your life value will be at maximum capacity(Same to when you open your save)
Calibrated cameras in two 2D scroll levels
Removed extra heart pieces from the Mining Facility scene
Removed cobweb obstacle in flappy bird level (due to the actor’s janky collider)
Reduced the difficulty of Phantom Ganon fight slightly
Added a hookshot target in the vault scene to prevent softlock
Lots of small changes

2024/12/2
1.18 ver 
Hot Fix: Changed the height of initial fire temple platform in Tankhell so you can progress in this scene
Fixed a bug where if you didn't choose to continue when you died, your inventory can be replaced with the debug save.
Removed an assert that could occur when you’re repeatedly out and in some rooms(especially in Sweatshop scene)
Fixed a random crash in a room of the Factory scene
Fixed a random crash in Swamphell scene
Fixed disabling teleportation not working sometimes
Fixed a bug where actors fail to load when switching between 2 rooms in certain areas
Fixed a bug where you could use long sword when saving & loading in Sweatshop scene
Fixed a bug where if you just open the bar and leave the train, the Kokiri trapped will not be rescued unless you talk to him
Changed the location of a song warp point for Big Brother's Trial sceneChanged the location of a Golden Skulltula in Flame Dancer scene
Changed the location of a Golden Skulltula in Factory scene
Reduced the damage value of normal Iron Lizard
Shrinked Club Moblin's collider
Removed a fence in swamphell to reduce difficulty
Removed 2 Time Block actors before the entrance of a dungeons
Reduced the difficulty of Tankhell scene
Increased bomb damage against Iron Guard
Added navi text hints to Iron knuckle and Iron Guard, implying a relation between electricity color and attack behavior.
Fixed a ladder in the Goron Shop scene not climbable when you you try to get down
Giving Shadow Medallion when completing the final dungeon
Added a check for three medallions before entering the Death Temple scene.
Changed Light Medallion decoration to Spirit one in Death Temple scene
Changed navi text for Iron Fire Lizard
Corrected 2 dialogs
Changed the sale price of blue fire (You can still farm it to some extent)
Changed the height of the two crates in balana dump, so you can return from the Moblin Mountain scene without a hookshot.

2024/11/29
1.17 ver main compatibility fix
Added one tip about Song of Flame
Removed a torch in the Desert Fortress scene that could cause sequence break 
Reduced the difficulty of a sneaking section in the Desert Fortress scene
Changed the position of a golden Skullwalltula in the Factory scene to make it available
Changed the position of a Heart Piece in Dampe’s chase scene to make it more fair
Fixed a random crash when entering the boss room in Abyss scene on Ares
Fixed a crash when entering the Dead Hand room in Dampe’s chase on Ares
Fixed a crash when attacking a Like Like on more accurate emulators

2024/11/28
1.16 ver Hot Fix
Fixed a bug where save & reloading in sweatshop would return your items
Fixed a crash in dog sidequest room
Added insurance that the long sword will come back to inventory after reloading
(For a rare inventory bug that may occur after you getting the heart piece in the fishing pond)
Fixed a crash issue in Death Temple scene

1.15 ver for some reasons wasn’t uploaded correctly. I apologize for the inconvenience

1.14 ver main compatibility fix
Changed a few of platform jumping in the Factory scene to reduce difficulty
Fixed a crash on the final boss when playing on more accurate emulators.
Fixed flawed collisions in several scenes
Reduced the size of rom significantly by removing unused vanilla content

2024/11/26
1.13 ver Hot Fix
1.12 is broken according to reporting
Remove accidentally used duplicate flags
Fixed a crash caused by shooting arrows into water in more accurate emulator
Fixed a crash caused by opening lens of truth chest
Fixed the issue where big goron's sword not be selectable after escaping the sweatshop (if you've beaten this dungeon, buy a nail sword to fix it)

1.12 ver
Fixed a typo in map title card 
Reduced the difficulty of several puzzles in Forest Valley scene
Reduced the difficulty of one of the silver rupee in Swamphell scene
(I’m sorry they were being kaizo before)
Fixed potential sequence breaking issues in Desert Fortress, Ganon’s Tomb and Abyss scenes
Changed the structure of Abyss scene slightly to reduce the difficulty of navigation
Corrected collisions in several scenes
Fixed poe collector that can reward repeatedly when you killed all of the poes
Fixed a flag issue in the Forest Valley scene.
Corrected several dialogues
Added several hints.
Some small changes

2024/11/25
1.11 ver
Fixed bottle swap bug
Changed actor configuration for Landfill scene.
Fixed the intro cutscene not looping correctly.
Renamed a provided option. 
Removed the “void out” property of the fan actor in the Fishing Pond scene
Fixed the lifting platform might not move anymore in the Abyss scene
Removed custom GI model for lens of truth

1.10 ver
Fixed respawn point bug in Big Brother’s Trial.scene
Fixed some of texture glitches in The Factory scene 
Fixed small key counter not showing up in The Factory scene 
Fixed poe collector disappear when you hit 2000 poe points

Contributors:
Jinnosuke
Shoopey
StoneeBadLuck
Nokaubure
Pugsly
X dude awesome
Owl
Richie
Syeo
Goblinlord
Grandlovania
Sklitte
The Lady Zelda

Special Thanks:
Cursed Crafts

Pack used:
Hylian Actor Pack, check out the link for full credit list: https://github.com/hylian-modding/hm-actor-pack
z64rom MM Skybox, by ZeldaBoy
Ball of Bones Custom Miniboss, by Jinnosuke
Majora's Mask actor pack for OoT by X dude awesome
Stalmaster by Grandlovania
Texture Pack from OoT, OoT3D, MM and MoT by xor, doncamilo, CrookedPoe

Tool used:
z64rom, Blender, Sharp Ocarina, Zelda64 Text Editor, zztexview, SceneTatl, Fast64, FL Studio, Sekaiju

If I've used original content that you've created and your name isn't noted in the credits, please contact me.

