//---------------------------------------------------------
//	MAJORA'S MASK REDUX
//---------------------------------------------------------
Romhacking release: https://www.romhacking.net/hacks/5122/

Ocarina of Time Redux is a hack that aims to improve the original experience of Majora's Mask by adding some QoL improvements by applying the ASM patches provided by the Majora's Mask Randomizer project (https://github.com/ZoeyZolotova/mm-rando) by Saneki (https://github.com/saneki) and its contributors.
Documentation for the rest of the features can be here:
https://github.com/ShadowOne333/Zelda64-Redux-Documentation

NB: Use a Majora's Mask US 1.0 ROM for patching

//------	FEATURES

The main Majora's Mask Redux features:

- D-Pad can now be used to access all three transformation masks and the ocarina, allowing a total of seven items to be accessible at all times. Note that this means that the map is no longer possible to toggle off.
- When using the bow, magic arrows can be cycled in a similar fashion to wind waker's magic arrows by setting one and pressing the "R" button.
- Ocarina can now be used underwater as Zora Link.
- Increased block pushing speed.
- Increased Mikau pushing speed to shore.
- All vanilla elements (cutscenes, introduction and first cycle, rewards) are retained.


//------	CUSTOMIZATION

What if you want to have the censored Skull Kid wooden face from the US release?
Or maybe you like the original Deku Palace route instead of the Japanese one?
That and MUCH more can easily be changed, thanks to an amazing software called Patcher64+ Tool, which allows you to toggle whatever feature you want on or off according to your liking, so you can create your own custom Majora's Mask Redux ROM!
You can download the software here if you want to customize your own ROM patch:
[link=https://github.com/Admentus64/Patcher64Plus-Tool/releases]Patcher64 Tool[/link]


//------	PATCHING INFO

ROM / ISO Information:
* Database match: Legend of Zelda, The - Majora's Mask (USA)
* Database: No-Intro: Nintendo - Nintendo 64 (BigEndian) (20200502-232230)
* File/ROM SHA-1: D6133ACE5AFAA0882CF214CF88DABA39E266C078
* File/ROM CRC32: B428D8A7


//------	CREDITS

Saneki (Main Majora's Mask Randomizer features):
	- Mask transformations and Ocarina in D-Pad.
	- Magic arrows toggle with R Button.
	- Underwater Ocarina as Zora Link
	- Increased Blocks & Mikau pushing speed

Maroc:
	- All other vanilla features (Rewards, Cutscenes and Animations) which are retained.
	- Several bugfixes and rework of Randomizer features to work on vanilla MM

GhostlyDark:
	- Correct rupee colors

darklord92:
	- Permanent Razor Sword

fkualol:
	- 4th Piece of Heart Sound Effect fix (Publicly available: https://www.tapatalk.com/groups/zelda64/mm-piece-of-heart-sequence-numbers-t969.html?sid=be5374d9252ef4f5c14b2678f97f5b30#p10168)

ozidual:
	- Mushroom Bottle Get Item fix (Publicly available: https://wiki.cloudmodding.com/mm/Talk:Ovl_player_actor/Get_Items)

Admentus:
	- Patcher64+ Tool

ShadowOne333:
Full Documentation for most of the points made here can be found at:
https://github.com/ShadowOne333/Zelda64-Redux-Documentation

	- Restored Title Screen colors to match that of the Japanese title screen (ZELDA in purple, THE LEGEND OF & MAJORA'S MASK in a yellow-ish color)
	- Text script revisions and restorations from other MM versions (including Japanese v1.0, PAL and even from Majora's Mask 3D)
	- Missing or misplaced Sound Effects that play alongside the script have been properly restored
	- Retranslations for the Great Bay Turtle, Lulu's Diary and Deku Butler's texts, localized based on the Japanese release.
	- New Area titles, unused titles missing in MM (U) v1.0 from MM (J) v1.0 have been restored, and new ones restored back from Majora's Mask 3D.
	- Uncensored Skull Kid face and beak ported from MM (J) v1.0.
	- Cleansed Southern Swamp map fixes ported from the Poisoned Swamp map data from MM (U) v1.0.
	- Restored the Deku Palace grotto, ported from MM (J) v1.0.
	- Move the Bomber Kid when doing the Hide & Seek to be next to the bell in East Clock Town, ported from MM (J) v1.0.
	- Zora Physics ported over from MM (J) v1.0
	- Fix the Goht cutscene so he doesn't run over Link, ported from MM (J) v1.1.
	- Restore the Shop Music to have its full intro, like in MM (J) v1.0.
	- Custom Troupe Leader's Mask item name graphics
	- Custom Romani Ranch fixed sign
	- Comma graphic fix ported from MM PAL.
	- Ikana Canyon's Fairy Fountain color fix (with help from Dybbles)
	- (WIP - Missing code for switching) Custom Ocarina icons for other instruments. 
	New instruments overwrite unused items, which can be loaded for testing via cheat codes:
	Slingshot ($0B) for Deku Pipes, Blue Fire ($1C) for Goron Drums, and Hylian Loach ($26) for Zora Guitar. Deku Pipes are completely new, Goron Drums and Zora Guitar ported over from unused assets from MM (J) v1.0.

