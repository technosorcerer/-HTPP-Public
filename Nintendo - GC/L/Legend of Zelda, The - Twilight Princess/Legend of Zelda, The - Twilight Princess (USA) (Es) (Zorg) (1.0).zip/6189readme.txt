Hola!!, con este parche podras jugar el juego "The Legend of Zelda: Twilight Princess" de region NTSC(U) para Game Cube en español (solo textos).

Aplicar el parche a la siguiente iso
------------------------------------------------
Nombre: Legend of Zelda, The - Twilight Princess (USA).iso
CRC-32: 0AB54D43
------------------------------------------------
En primer lugar quiero aclarar que yo no he traducido el juego, sino que inserte los archivos de 
idioma español de la version PAL a la version NTSC(U), el objetivo es poder difrutar el juego en este idioma ya que la version americana admite resolucion progresiva (480p).
Bueno hice este parche para facilitarle el trabajo a ustedes, para asi obtener y disfrutar el juego en idioma español.
*************
INSTRUCCIONES
*************
Para aplicar el parche tendrás que descargar un parchador xdelta, puedes
descárgalo desde aquí:
https://www.romhacking.net/utilities/598/

¡Que lo disfrutes!

Zorg © 2021
