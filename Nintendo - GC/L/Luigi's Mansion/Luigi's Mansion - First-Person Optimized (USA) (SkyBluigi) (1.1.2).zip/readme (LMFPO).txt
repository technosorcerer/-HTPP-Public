
-------------------------------------
Luigi's Mansion: First-Person Optimized v1.1
-------------------------------------

[DESCRIPTION]
____________________

A fairly basic modification (in concept) aimed to optimize almost
everything in the game to accommodate a first-person perspective,
made possible using an Action Replay code by Laser Crusader.

In other words, this hack makes Luigi's Mansion completely playable
from the direct viewpoint of the titular green plumber, transforming
the experience into something almost like an FPS; featuring frequent,
personal encounters with spirits of the dead and constant, hair-raising
battles with ghostly underlings, who seek your death with playful malice
in their smiles.

Now at v1.1.2, this hack also features:

	-Full console-compatibility, first and foremost.

	-The ability to not only explore the Lab, but also
	 walk to the adjacent rooms and go up to the mansion,
	 and back.
	 (Portrificationizer Room is off-limits, however.)

	-Added dialogue to E. Gadd's tips during training,
	 so he's more helpful as a coach to new players.

	-Higher overall difficulty, due to increased attack
	 damage by 5 hit points (10 in the Hidden Mansion),
	 as well as edited enemy stats so it's slightly more
	 tricky to reel ghosts in.

	-A more unforgiving Hidden Mansion, with the removal
	 of all heart drops from furniture.

	-No automatic HP refill after clearing an area.
	 (This means that a 'no-hearts' run can be attempted,
	 if desired.)

Still couldn't include a free-roam mode, as it proved to be a little
too hard to get working completely. But it's not really necessary,
anyway. :\


Instructions and utilities to patch this to the game are included, as
well as a few optional patches you can use.

[NOTE: Unlike with v1.0, these optional patches don't apply ON TOP
of the base FPO patch anymore, but work directly on the original ISO,
streamlining the process. No more double patching!]

Here's what they are:

	Inverted C-Stick Controls
	(The default Y-Axis is: Up=Down & Down=Up.
	This patch inverts that so it's: Up=Up & Down=Down.)

	Better FOV [Experimental]
	(Increases the field-of-view slightly so
	that you can see farther to the sides of
	your vision.
	However, mirror reflections get messed up
	pretty badly with this, so only use this
	if you're okay with that.)

	Better FOV + Inverted C-Stick
	(The above two patches combined.)

Also included is a handy cheat code + GCT file that allows you to
toggle the flashlight on/off by just pressing the B Button, instead
of having it on by default and needing to hold down the button to turn
it off.
(This feature would've been made an optional patch, too, but the code
can't be injected into the game as it is. So this cheat solution will
have to do, for now...)


Hopefully, you'll all enjoy playing through this meticulous passion project.
(With a side of jank; this hack's not perfect!)  :)

It's recommended you start a new save file for this to see all the changes.
Also, PLEASE use the Sidestep control style, as the Standard style makes
controlling Luigi incredibly more nauseating and difficult.

Finally, on that note, if you want to reduce possible motion sickness, try not
to wiggle the stick left and right too much while catching ghosts. For the most
part, just pull back. :)



{CHANGELOG}
-----------
3/31/2022  v1.1.2 - Restored the double suction power that was
used for the Hidden Mansion, in order to accomodate speedrunners
of the vanilla game. (This does reduce the difficulty of the HM a
little, but that's not a big deal.)

In addition, some redundant dialogue, from the training sequence and
from the call prior to entering the first hallway, has been removed.

Oh, and don't worry--this is NOT an April Fools' update! Trust me.
-----------
1/12/2022  v1.1 - Fixed a number of bugs and coding oversights,
and introduced the following:
	
	--New loading zones added to the Lab, so you can travel to
	  your desired destinations on foot, giving functionality
	  to the map.

	--Edited E. Gadd dialogue during training, so he's more helpful.

	--Slightly increased damage from ghost attacks. (5 additional
	  hit points, doubled to 10 in the Hidden Mansion.)

	--Edited stats for nearly all ghosts so it's a little harder to
	  reel them in (to compensate a bit for ghost-catching being a
	  LOT easier in first-person).

	--Disabling of the increased suction power you normally get in
	  the Hidden Mansion. (Credit goes to Bryce!)

	--Overwritten furniture drops in the Hidden Mansion so that you
	  can no longer get hearts to refill HP, except from catching
	  ghosts. (Instead, you'll find poison mushrooms and banana
	  peels in their place.)

	--The ability to use the front doors to the mansion to go back
	  to the Lab, so you don't have to quit the game and reload your
	  file to get there.

	--Some other miscellaneous changes not worth noting.

-----------
12/30/2021  v1.0 - Initial release
-----------


Requirements:

   -An unmodified ISO of the North American (USA) version
    of Luigi's Mansion, ripped from a physical retail
    disc. (Anything that differs even slightly from that
    criteria will probably not work.)

   -Dolphin Emulator or a way to play on real hardware.
    (Like Nintendont on the Wii. That's what I use.)

============
How To Patch
============

-------
On Windows:
---
  Step 1 - Open xdeltatUI.exe. You should see the application
  launch a window with three blank boxes inside a tab labeled
  'Apply Patch'.

  Step 2 - Click on the 'Open...' button that's right of the 
  'Patch' box. It'll open a file explorer window where you
  need to search for an .xdelta patch.

  Step 3 - Locate the 'Luigi's Mansion FPO v1.1' xdelta patch
  that you should have extracted from the .zip package, OR one
  of the optional patches, if you want.

  Step 4 - Once you've selected the FPO patch of your choice,
  click 'Open' on the bottom right of the window. The 'Patch'
  box in the main xdelta window should now have the patch
  location stored inside it.

  Step 5 - Now click the 'Open' button next to the 'Source
  File' box. Now you need to find and select a Gamecube ISO
  disc image, which in this case needs to be an ISO of the
  USA version of Luigi's Mansion, untampered and ripped from
  a physical retail disc.

  Step 6 - Once you've located your Luigi's Mansion ISO (that
  should hopefully fit the description above), select it and
  click 'Open'. Now the 'Source File' box should have the ISO
  location stored.

  Step 7 - Now click the 'Open' button for the 'Output File' box.
  Just select whatever location you want to save your new patched
  ISO. (In a folder, on the desktop, on an SD card or USB drive...)

  -------
  If you're planning on playing on real hardware as opposed to Dolphin,
  and don't ALREADY have a way of doing so, you can easily look up a
  number of different methods on how to do it. I recommend Nintendont
  for the Wii (since I've only used that).
  -------

  Step 8 -Type in the file name box 'Luigi's Mansion FPO.iso', or
  something else if you want. (As long as you have the '.iso' extension
  at the end, it should be fine.)
  Now click 'Save'. The 'Output File' box should have the selected
  location for your patched ISO stored.

  Almost done now!  :)

  Step 9 - Now just click the 'Patch' button at the bottom of the
  window. It should start creating a patched copy of your original
  Luigi's Mansion ISO, using the FPO patch.

  Step 10 - All you need to do now is wait for the patching process
  to finish. If it's taking a really long time, don't panic! It should
  still be working.
  Eventually, it should finish patching and give you a message saying
  'File patched successfully.'


You're basically all done now! Now just go ahead and boot up FPO
in Dolphin/Nintendont/etc. The game should load without a problem.

If, on the other hand, the game doesn't boot up or crashes after a
certain point, check your settings for whatever you're using to see if
maybe a certain setting or something is causing the problem. If that
doesn't fix anything, you could either attempt to patch again, or
contact me for help.

-------
On macOS:
---
Use the included MultiPatch application. It should
work basically the same as xdeltaUI does.  :P

(I have no way of testing it myself, because I have no Mac...)

-------
On Linux:
---
Since there are so many different branches of linux operating
systems, I'm not sure where to start with writing patching
instructions for people using those. So unless you're willing
to look up how to possibly use .xdelta patches on your linux
distro, you'll need to switch to Windows or macOS for this.

Sorry.  :|

======================================
	
If you need more helpful instructions (or want to give ME
more helpful instructions to include in this), you can
contact me on YouTube, Discord, or Romhacking.net.

YouTube channel: https://www.youtube.com/channel/UCbGsyv1ubw9idAAv6t-b5Mw.

Luigi's Bigger Mansion Discord: https://discord.gg/CmukbCh

