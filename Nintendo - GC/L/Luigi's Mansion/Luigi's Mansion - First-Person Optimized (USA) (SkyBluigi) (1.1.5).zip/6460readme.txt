
-------------------------------------
Luigi's Mansion: First-Person Optimized (v1.1.5)
By Sky Bluigi
-------------------------------------

https://www.romhacking.net/hacks/6460/


[DESCRIPTION]
____________________

A simple modification aimed to optimize the game-play of
Luigi's Mansion to accommodate a first-person perspective,
made possible using an Action Replay code by Laser Crusader.

This novelty hack makes the game fully playable through
the eyes of Luigi, transforming the Gamecube classic into
an unusual sort of FPS; one focused on hunting ghosts in a
spooky mansion, presented as a lighthearted adventure with
some eerie undertones.


Besides the adjustments made for first-person, this hack also
contains the following changes:

	-You can now freely explore the Lab and walk to
	 the adjacent rooms (besides the one with the
	 Portrificationizer).
	 
	-You can now climb the ladder in the Lab to get up to the
	 mansion, and also return to the Lab through the mansion's
	 front doors as necessary.

	-There is some new dialogue to E. Gadd's training tips in
	 order to teach players the best way to play in first-person.

	-The overall difficulty has been made a bit higher, due to
	 increased enemy damage by 5 hit points (10 in the Hidden Mansion),
	 as well as slightly altered enemy stats to help balance the
	 'tug-of-war' with each ghost in first-person.

	-The Hidden Mansion is now less forgiving, since heart drops
	 will no longer spawn from furniture. Instead, you might find
	 something else...

	-Your HP will no longer refill after clearing an area. (This is
	 simply to make a 'no-hearts' run possible to attempt for hardcore
	 players.)


Instructions and utilities to patch to the game are included in the
download, as well as a few alternative patches you can use:

	Inverted C-Stick Controls
	The default Y-Axis is: Up=Down & Down=Up.
	This patch inverts it to: Up=Up & Down=Down.

	Better FOV [Experimental]
	This patch increases the field-of-view slightly
	so that you can see farther to the sides of your
	vision. It's useful, but it causes mirror reflections
	to look squashed, so keep that in mind.

	Better FOV + Inverted C-Stick
	This patch is a combination of the other two.
	

In addition, a handy cheat code + GCT file is provided, which allows you
to toggle the flashlight on/off by simply pressing the B Button, instead
of having to hold it down to keep the light off.


There are still some kinks to iron out before this hack is considered
'done', but hopefully you'll enjoy what it currently has to offer!  :)


!!QUICK NOTE BEFORE PLAYING!!
Please make sure to use the Sidestep control scheme, either by selecting
it on the PAUSE Screen or in the Options Menu. If you don't, controlling
Luigi will be much more difficult and unpleasant.

Also, to help reduce possible motion sickness, try not to wiggle the
left stick too much while catching ghosts. For the most part, just keep
a steady pull backwards to drain their HP.



{CHANGELOG}
-----------
4/1/2023  v1.1.5 - Luigi's idle routine will no longer activate,
making it more practical to aim while standing still. (Credit goes
to LMFinish for providing the code!)

There might be some other new things, too... Can you find them?

-----------
3/31/2022  v1.1.2 - Restored the double suction power for the
Hidden Mansion in order to accomodate speedrunners.

In addition, some redundant dialogue has been removed; from the
training sequence and the call prior to entering the first hallway,
respectively.

-----------
1/12/2022  v1.1 - Fixed a number of bugs and coding oversights,
and introduced the following:
	
	--New loading zones added to the Lab, so you can travel to
	  your desired destinations on foot, giving functionality
	  to the map.

	--Edited E. Gadd dialogue during training, so he's more helpful.

	--Slightly increased damage from ghost attacks. (5 additional
	  hit points, doubled to 10 in the Hidden Mansion.)

	--Edited stats for nearly all ghosts so it's a little harder to
	  reel them in (to compensate a bit for ghost-catching being a
	  LOT easier in first-person).

	--Disabling of the increased suction power you normally get in
	  the Hidden Mansion. (Credit goes to Bryce!)

	--Overwritten furniture drops in the Hidden Mansion so that you
	  can no longer get hearts to refill HP, except from catching
	  ghosts. (Instead, you'll find poison mushrooms and banana
	  peels in their place.)

	--The ability to use the front doors to the mansion to go back
	  to the Lab, so you don't have to quit the game and reload your
	  file to get there.

	--Some other miscellaneous changes not worth noting.

-----------
12/30/2021  v1.0 - Initial release
-----------



Requirements:

   -An unmodified ISO of the North American (USA) version
    of Luigi's Mansion, ripped from a physical retail
    disc with a filesize of 1.4GB

   -Dolphin Emulator, or a way to play on a Gamecube/Wii


============
How To Patch
============

-------
On Windows:
---
  Step 1 - Open xdeltatUI.exe. You should see the application
  launch a window with three blank boxes inside a tab labeled
  'Apply Patch'.

  Step 2 - Click on the 'Open...' button that's right of the 
  'Patch' box. It'll open a file explorer window where you
  need to search for an .xdelta patch.

  Step 3 - Locate the 'Luigi's Mansion FPO' xdelta patch
  that you should have extracted from the .zip package OR one
  of the optional patches, if you want.

  Step 4 - Once you've selected the FPO patch of your choice,
  click 'Open' on the bottom right of the window. The 'Patch'
  box in the main xdelta window should now have the patch
  location stored inside it.

  Step 5 - Now click the 'Open' button next to the 'Source
  File' box. Now you need to find and select a Gamecube ISO
  disc image, which in this case needs to be an ISO of the
  USA version of Luigi's Mansion, untampered and ripped from
  a retail disc. (It should be about 1.4GB in size.)

  Step 6 - Once you've located your Luigi's Mansion ISO, select it
  and click 'Open'. Now the 'Source File' box should have the ISO
  location stored.

  Step 7 - Now click the 'Open' button for the 'Output File' box.
  Just select whatever location you want to save your new patched
  ISO. (In a folder, on the desktop, on an SD card/USB drive...)


  -------
  If you're planning to play on original hardware as opposed to Dolphin
  (and don't ALREADY have a way of doing so), you can easily look up a
  number of different methods to load GC games on an actual Gamecube/Wii.
  
  I recommend Nintendont for the Wii, since that's the easiest to set up.
  -------


  Step 8 - Type in the file name box 'Luigi's Mansion FPO.iso' or
  whatever else you want to call it. (As long as you have the '.iso'
  extension at the end, it should be fine.)
  Now click 'Save'. The 'Output File' box should have the selected
  location for your patched ISO stored.

  Almost done now!  :)

  Step 9 - Now just click the 'Patch' button at the bottom of the
  window. It should start creating a patched copy of your original
  Luigi's Mansion ISO, using the FPO patch.

  Step 10 - All you need to do now is wait for the patching process
  to finish. If it's taking a really long time, don't panic! It should
  still be working.
  Eventually, it should finish patching and give you a message saying
  'File patched successfully.'


You're basically all done now! Now just go ahead and boot up FPO
in Dolphin/Nintendont/etc. The game should load without a problem.

If, on the other hand, the game doesn't boot up or crashes after a
certain point, check your settings for whatever you're using to see if
something in your configuration is causing the problem. If that doesn't
fix anything, you can either attempt to patch again, or contact me for help.

-------
On macOS:
---
Use the included MultiPatch application. It should
work basically the same as xdeltaUI does.  :P

(I have no way of testing it myself...)

-------
On Linux:
---
Since there are many different branches of linux operating
systems, I'm not sure where to start with writing patching
instructions for people using those. So unless you're willing
to look up how to use .xdelta patches on your linux distro,
you'll need to switch to Windows or macOS for this.

Sorry.  :|

======================================
	
If you need more helpful instructions (or want to give ME
more helpful instructions to include in this guide), you can
contact me on YouTube, Discord, or Romhacking.net.

My YouTube Channel: https://www.youtube.com/channel/UCbGsyv1ubw9idAAv6t-b5Mw.

Luigi's Bigger Mansion Discord: https://discord.gg/uRSyNCZHeZ
(I finally replaced the broken link that was here. Sorry it took so long!)
