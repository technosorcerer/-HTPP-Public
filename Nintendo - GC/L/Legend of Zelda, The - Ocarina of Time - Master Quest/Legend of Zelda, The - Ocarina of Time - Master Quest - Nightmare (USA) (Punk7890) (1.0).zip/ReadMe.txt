**********
*ROM info*
**********
Format: N64 ROM (big-endian)
Database match: Legend of Zelda, The - Ocarina of Time (Europe) (Debug) (GameCube)
Database: No-Intro: Nintendo 64 (v. 20210220-053642)
File/ROM SHA-1: CEE6BC3C2A634B41728F2AF8DA54D9BF8CC14099
File/ROM CRC32: 5D1B2996


*************
*How to play*
*************
1. You'll need a N64 emulator that is able to play The Legend of Zelda: Ocarina of Time.
2. Download the correct The Legend of Zelda: Ocarina of Time ROM (see ROM info)
3. With http://www.romhacking.net/hash/ you can check whether you have the correct ROM.
4. Go to: https://www.romhacking.net/patch/ to patch the ROM.
5. Start the patched ROM in your emulator.
6. Have fun!