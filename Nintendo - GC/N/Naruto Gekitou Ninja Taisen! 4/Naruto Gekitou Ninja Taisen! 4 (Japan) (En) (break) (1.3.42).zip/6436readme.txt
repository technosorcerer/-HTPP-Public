[Nintendo Gamecube] SUPER Naruto Gekitou Ninja Taisen! 4 v1.0

Gamecube english translation of the game "Naruto Gekitou Ninja Taisen! 4" 
Fully translated and tested on real hardware and emulator (01/02/2021)
Menus 100% complete and bug free.
For inquiries, can be reached via Discord and Youtube :

Discord-- https://discord.gg/wyNpXKx
Youtube-- https://youtu.be/dOD7lcfIBvY

Legend:
⦁ 2,4,5,6,8 are down, back, neutral, forward, and up respectively; therefore 5B is pressing B without a direction on the stick
⦁ RA is running A
⦁ JB is jumping B
⦁ 6A(A) means that we are talking about the second A press in the 6A string
⦁ Act4A means the activated part of a 4A counter. This can also be seen on command grabs such as Tsunade's Jump A as ActJA.
⦁ GRKnJ and ARKnJ are ground and air attack substitutions; LKnJ is the non attack version
⦁ 5X8 is an example where the move begins with 5X but needs a press of 8 to do something different. This essentially works like 8X, but it is different solely for comboing into the move as if you input 8X and release the 8, you will do 5X. These moves are seen at the first active frame of the move in most cases
⦁ DI: This is on a few air moves. This allows you to hold forward or back as you begin the move to change how your momentum is applied
⦁ Ring: A combo string with multiple options depending on direction pressed

Overall:
⦁ Translation in progress
⦁ Training mode default settings changed: 2P action is 2P control, Chakra recovery changed to OFF, Show inputs changed to OFF
⦁ Training modes updated. 3MC training is now 1v1 training. 1v1 training is now Debug Mode
⦁ Screen doesn't slow down on character death
⦁ Music doesn't stop on pause
⦁ Default option for time changed from 60 to 90 seconds, time options changed
⦁ Stage select screen has diagrams with sizes for the stages
⦁ Unlocks everything by default
⦁ Stand resets intangibility
⦁ Jump land, throw miss, more hit states can be grabbed
⦁ Turn around is three frames faster
⦁ Dash transitions to run on frame 6 (from 8)
⦁ Overhead throws cannot be subbed for the first ten frames after being thrown
⦁ Backflips replaced with a faster backdash
⦁ Landing face first, small bounce on your back or face, and crumple restores your ability to substitute
⦁ Air and Ground grab breaks have guard frames that guard against normal and special attacks
⦁ Jump land doesn't high crush
⦁ Pressing X no longer counts as an input to break throws
⦁ GRKnJs have at a minimum 17 intangible travel frames and will hit on at least frame 29
⦁ 4As are grabbable the entire duration
⦁ Sleep state (Kabuto 2X) cannot sub until later; resets the combo counter
⦁ Can select which RKnJ you use while in the air. If pressing R, then your character will do the air sub, if pressing 2R then they will do the ground sub
⦁ Getup attacks (Wake Up Kick: Aka WUK) added. If holding A or B on frame 15 of a neutral getup, the character will transition to a get up attack. These are fully intangible for four frames and then immune to mids and highs until the hitbox disappears. They are -21 on block

3MC: (Three Man Cell)
⦁ Z moves do not work so you cannot switch characters
⦁ Characters now switch after KOs
⦁ holding A on entry does the entering character’s GRKnJ, holding B does the entering character’s ARKnJ.
⦁ Certain characters have entrances unique to this mode. Kankuro, in particular, has both attacks exclusive to his entering state to compensate for his unique KnJs.
⦁ 6X supers removed
⦁ New entry coded to fix glitches and issues
⦁ Passive meter gain disabled

Stages:
⦁ Silent Shrine replaces Fog Bridge
⦁ Heaven and Earth Bridge replaces Ice World
⦁ Cell Games replaces Uchiha District
⦁ Asian Gate replaces Chuunin Roof
⦁ Aquarium replaces Hot Springs
⦁ Gamecube Galaxy replaces Sunset Ramen

Characters:

Anko:
⦁ Walking animation reworked
⦁ Air Throw added
⦁ Health: increased from 200 to 210
⦁ Guard: increased from 1600 to 1680
⦁ Grabbable moves: The following moves can be grabbed before the snake projectiles come out 2A, JA, 2BBB(A), and 8B landing
⦁ 5B: Hitbox lasts one frame longer, elbow hitbox does not appear on the first frame
⦁ 5B(B): changed to be old GNT4 6B animation with old 5B(B) damage Move ends quicker
⦁ 6B: uses an animation similar to Orochimaru; turns around back turned people has more stun and it is slightly later on transition to follow ups
⦁ 4B: does 2 more damage; hitbox appears one frame sooner
⦁ 4B and 4BA(Y): have improved windows on states as well as ending sooner and can be grabbed during their "sit" frames
⦁ 4B(B): is an unblockable hitgrab that also hits OTG; hitbox appears one frame sooner
⦁ 4B(A): transitions 8 frames faster
⦁ 4BA(Y): can be subbed in the first few frames
⦁ 2B(B): has more lift
⦁ JB: does chip damage and does 4 more damage
⦁ RB: replaced with RA, lift increased
⦁ 2BBB(B): hitbox appears one frame later
⦁ 2BBB(A): snakes lift and do chip; does 2A in string; ends 5 frames sooner
⦁ 8B: is a blockable hitgrab that is untechable
⦁ 5A: charge time decreased  from 10f to 8f
⦁ 6A: lifts higher on hit and now lifts on block
⦁ 2A: snakes do chip damage, animation changed to be the finisher of 5X
2BBB2(A) will end with upward snakes instead of 2A snakes
⦁ 4A: changed to be a teleport that can teleport to either side
⦁ JA: momentum applies sooner
⦁ JA and 6AA(A): snakes adjusted to do chip damage and lift
⦁ RA: 4BA(A) changed to be a teleport into the air RKnJ position into normal fall; A and B strings added
⦁ RA and 6AA(A): have three grabbable frames before the teleport
⦁ 5Y: is a side switch throw
⦁ 2Y: is a new throw that bounces the opponent
⦁ 5X: has an improved launch angle to stop resetting the combo against high up opponents; requires 75% meter, but costs 100%; three less frames of super freeze; hitbox starts and ends one frame later; elbow hitbox smaller
⦁ 2X: starts moving five frames sooner in super freeze and has an extended activator hitbox
⦁ 6X: is a command grab that puts opponent into an untechable, unsubbable state; immune to highs and mids frames 1-9 after super freeze then immune to highs until after the hitbox disappears; requires and costs 75%l does 10+30 damage
⦁ GRKnJ: appears slightly further behind the opponent


Chouji:
⦁ Overall: When large (moves that increase Chouji physical size for the duration of the move), Chouji has guard frames and is grabbable
⦁ Air Throw added, does a modified A8A animation
⦁ Health: increased from 225 to 240
⦁ Guard: increased from 1800 to 1920
⦁ 2A: chips increase Chouji's strength. He requires 8 chips to get to his maximum strength. When he is at maximum chips, he gets a 1.5X damage multiplier. 2A maxes out strength (1.5x) at 8 chips from 13. Builds 1/16th of a bar of meter. Each chip adds .5X damage multiplier
He also loses chip gains for certain moves which are:
1 chip lost: GRKnJ
2 chips lost: 6A, Act4A, RA, JA
4 chips lost: 5X, 2X, 4X
⦁ 2A maxes out strength (1.5x) at 6 chips from 13. Builds 1/16th of a bar of meter
⦁ 5B: has slightly more stun on hit and block; transition to 5B(A) is one frame faster
⦁ 5B(B): has slightly more lift, shoulder hitbox does not appear on the first frame, SFX comes out one frame later, 3 frames less disadvantage on block
⦁ 5B(A): hitbox appears one frame sooner; transitions one frame faster
⦁ 5BA(A): added as 2A
Holding A allows you to keep eating chips
⦁ 5BB(B) and 8B: is an uppercut
⦁ 5BBB(B) and 8B(B): is also an uppercut, but has spinning knockback and hits higher
⦁ 6B: damage (+3) and stun increased
⦁ 6B(B): is the strong uppercut (8B(B))
⦁ 6B(A): is a small bounce instead of stagger; can be done on whiff; transitions two frames slower; duration on the attack is increased by 2
⦁ 4B: is untechable and high for the first two frames of the hitbox, then mid and techable; hitbox appears and disappears one frame later; hitboxes are slightly larger
⦁ 8B to 8B(B): transition is slightly slower
⦁ 8B(A): is 8A
⦁ RB: ends sooner
⦁ 5A: has one more frame on the end for grab, super armor ends on frame 30 down from from 55, damage increased from 25 to 30, thrown trajectory changed, can tech roll and sub right before landing
⦁ A5A: is hittable after Chouji throws the opponent
⦁ 6A: links into the final hit better, ending hits twice, the first is a bounce and second hit is a hard knockdown
⦁ 4A: counter window improved, can be activated from all sides
⦁ A4A: is unblockable and unsubbable, slight adjustment to size, damage increased to 25 from 20
⦁ 8A: Hitboxes adjusted to not grab behind as easily, super armor ends when Chouji leaves the ground, hitboxes appear 4 frames earlier, damage increased from 40 to 30 and opponent can sub after Chouji removes his hands from the opponent
⦁ A8A: is hittable after Chouji gets off the opponent
⦁ RA: size adjusted, hitbox duration better matches animation, pushes on block
⦁ JA: does increased guard damage, falls faster, hard knockdown, pushes on block, size adjusted
⦁ GRKnJ: size adjusted to match RA
⦁ 5X: starts moving 4 frames sooner during super freeze
⦁ 4X: is a real time super similar to Act4A with immunity to highs and mids on startup; requires and uses 75%


Gaara:
⦁ Guard: increased from 1760 to 2000
⦁ 5B: elbow hitbox removed; hitbox made smaller; active frame 2,  hitbox size increase
⦁ 5B(B): hitbox disappears two frames earlier
⦁ 5BB(B): turns back turned opponents around
⦁ 5BBA(A): has three grabbable frames at the startup, doesn't teleport as high
⦁ 5BBBB(A): hitbox appears two frames earlier; teleports a frame later when coming from B moves (ex: 6BB(A) instead of 8AB(A))
⦁ 6B: turns back turned opponents around
⦁ 6B(B): (taijutsu flip kick) blockstun increased, start up is 4 frames later, toe hitboxes slightly bigger; "lands" 2 frames later; recovers 10 frames faster on landing
⦁ 4BB(B): increased duration, lower angle, hand knockdown
⦁ 2B: lift increased
⦁ 2BA(A) and 2BAA(A): adjusted hand to clasp on Gaara's arm properly
⦁ 8B: ends significantly sooner, cannot do A or B follow ups after Gaara lands
⦁ 5A: charge time decreased from 11f to 9f
⦁ 6A: appears 12 frames sooner; can be grabbed for the whole duration
⦁ 4A: counter window improved
⦁ A4A: appears behind opponent into custom RA that is an unblockable sweep
⦁ 2A: comes out faster, can be grabbed
⦁ 8A: is immune to high attacks on frames 9-20, cannot be thrown 15-until the pillar appears, then can be grabbed after; hands curl around the arm properly
⦁ 8A(B): (sand flip kick) "lands" two frames later; recovers 8 frames faster
⦁ JA: projectile has more stun; air momentum only affects his upwards lift
⦁ 5X: hitbox appears 5 frames sooner
⦁ 2X: comes out faster, recovers quicker, requires and costs 75% meter, blocks everything while the orb is active, safe(r) on hit; grabbable until frame 30 on startup (13 frames after super freeze ends for the opponent) and as the sphere disappears; does 40 damage
⦁ GRKnJ: is RA; teleports 1 frame faster


Gai:
⦁ 5B: has more lift on hit
⦁ 5B(B): has an additional endlag frame
⦁ 5BBA(A): has more lift on hit
⦁ 6B: animation changed to be the 4B(B) animation and staggers, when done in string it is vanilla
⦁ 6B(A): has more lift on hit can be super canceled has less blockstun; if holding 6 when it comes out does 6A
⦁ 2B: hitbox duration increased by 1 frame, launches, lift adjusted
⦁ 8B: both hits have slightly more lift on hit
⦁ 8B(B): added as JB
⦁ RB: Changed to be plus frame on block, launches upwards, hitbox duration increased by 8 frames
⦁ JB: doesn't float as high in the startup; has slightly more height and launch angle change
⦁ 5A: Super cancel added, turns back turned opponents around; slightly more lift
⦁ 6A: Second hit launches far and away, Y cancel removed
⦁ 4A: window improved, can move immediately on appearance
⦁ 2A: launches instead of sweeps with more lift on hit
⦁ 8A: teleports in front of the opponent; can be grabbed; cannot do follow ups on whiff
⦁ 5Y: does 20 damage with no gate or 1 gate open
⦁ 2Y: does a knockdown throw that does 30 damage
⦁ 5X: slightly bigger shoulder hitbox, more duration, begins moving 2 frames sooner, activator does 10 damage in both gated form; damage on activation changed from 71 to 66 and 76
⦁ 2X: can be done with no gates open, activator does 10 damage in both gate forms; activated does 80 and 90 damage from 90
⦁ GRKnJ: made to work like RB, but is a mid instead of a high


Haku:
⦁ 5B: made high
⦁ 2B: hitbox appears one frame sooner; hit direction changed slightly to assist follow ups
⦁ 2B(B): first hit launches
⦁ 2B(A): replaced in combos by 6A(A); added after 6B(B) and other such kicks; properly low crushes
⦁ 2BA(A): is unblockable
⦁ JB(A): Added as JA
⦁ 6A: hits twice; damage is distributed between the two hits; can hold 8 during startup to do flip
⦁ 4A: window improved
⦁ A4A: appears above 14 frames faster, activation is unblockable and unsubbable; hitboxes are bigger and better placed; moves quicker
⦁ 8A: needles have slightly more lift on hit
⦁ RA: replaced with 2B(A) and follow ups
⦁ JA: spawns 5 needles instead of 10, holding each needle drains 6 chakra per frame instead of 3 (was pairs before)
⦁ 5X: hitbox appears 4 frames earlier
⦁ 2X: Stomp hitbox changed to be a shockwave hitbox instead of on his shin; immune to highs and mids at startup; does not teleport
⦁ GRKnJ: Made a mid instead of a high


Hinata:
⦁ 6BBB(B) and 6BBB(6B) added
⦁ Health: Increased from 185 to 205
⦁ Guard: increased 1480 to 1520
⦁ Combo list updated:
5BBA(A), 6A(A) added to the combo strings
⦁ Hyuuga Cancels: now uses the same animation as 2X
⦁ Grabbable moves: 8A, JA, 2X
⦁ 5B(B): hitbox appears and disappears one frame later
⦁ 5BB(A): has stagger, has one more frame blockstun, turns better on hit
⦁ 5BBBB(6B): changed to RB animation and properties
⦁ 6B: has one more frame blockstun
⦁ 6B(B): has one more frame blockstun and can be super canceled; Hyuuga Cancel is four frames sooner
⦁ 4B: no longer staggers or pushes block, significantly stronger on hit and block stun
⦁ 2B: has slightly less lift on hit and  high crushes from 14-40 to better match the visuals
⦁ 2B(B): changed to be 5BB(B) with A follow up still intact
⦁ 8B: second hit lifts on block, both hitboxes appear one frame later, slightly bigger hitboxes on the second hit; recovers slightly faster
⦁ RB: when done in a string does 5BBB(B) with the A follow up intact
⦁ 5A: charge time decreased from 11f to 8f
⦁ 4A: uses the same animation as 2X, starts up 4 frames sooner, ends 8 frames later
⦁ A4A: can only be subbed on the first frame
⦁ 6A: stagger added, turns better on hit, more lift, first three frames are intangible
⦁ 2A(A): added as 6A(A)
⦁ 5X: damage increased from 65 to 80, starts moving in super freeze three frames sooner; two more active hitbox frames
⦁ 2X: requires 75% meter to use, window starts up 3 frames faster and ends when the animation starts to change like other counters; drains slightly more than 12.5% meter on a miss at the end of the move; activation gives opponent no chakra on hit
⦁ GRKnJ: changed to her RA; appears closer to the opponent


Hinata (Awakened):
⦁ Air Throw added
⦁ Guard: increased from 1760 to 1800
⦁ Grabbable Moves: 8A, JA, 2X
⦁ 5B(B): hitbox appears and disappears one frame later
⦁ 5BB(A): turns better on hit; given same stun as 6A
⦁ 5BBBB(A): damage increased from 12 to 20
⦁ 4B: remove stagger and push on block
⦁ 8B: hitboxes for the second hit appear one frame later, slightly bigger hitboxes on the second hit
⦁ RB: given Hyuuga Cancel
⦁ JB: can be adjusted to go further or shorter by holding 4 or 6
⦁ 5A: charge changed from 11f to 8f
⦁ 6A: Turns better on hit; intangible on the first three frames; not intangible in strings
⦁ 6A(A): damage increased from 15 to 20
⦁ 4A: drains meter at a rate of 120 units per frame instead of 180
⦁ A4A: is unsubbable and untechable and does 10 more damage
⦁ 2A(A): added as 6A(A)
⦁ 5X: activates if only hitting the second hit, damage reduced from 75 to 70; first hit turns back turned opponents around; hitboxes and lift adjusted for consistency
⦁ 2X: starts 3 frames faster and ends 8 frames later; drains slightly more than 12.5% meter on a miss at the end of the move; activation gives opponent no chakra on hit
⦁ GRKnJ: appears closer to the opponent


Ino:
⦁ Air Throw added
⦁ Win pose against Sakura properly closes both hands
⦁ JB(B) and JB(2B) are string added
⦁ Health: increased from 185 to 205
⦁ Guard: increased from 1480 to 1640
⦁ Grabbable Moves: 8A, JA
⦁ 5B: shoulder hitbox does not appear on the first active frame
⦁ 5B(B): hitbox appears and disappears one frame later; can do 8B instead
⦁ 5BB(A): does a delayed 6A
⦁ 5BB(B): launches on hit and block, lift and direction adjusted; can do 8B instead
⦁ 5BBB(A): has three grabbable frames at the startup; can press 4 before the teleport stay on the same side
⦁ 5BBBB2B: does 4BB(B)
⦁ 5BBBBB(B): has more lift on hit
⦁ 6B: increased lift on hit,  ends quicker, does not lift on block; has more lift when not in a string
⦁ 6B(B): has three grabbable frames at the startup before the teleport; can change direction with 4B
⦁ 4B: bounces closer to Ino
⦁ 4BB(B): adjustments to hitbox timing, landing, and crush. High crushes on landing
⦁ 8B: is a backflip with strings followed up from it
⦁ JB: hitbox appears 1 frame later and disappeares 3 frames later
⦁ 5A: charge time decreased to 7 frames from 11
⦁ 4A: has an improved window
⦁ A4A: is unblockable, hard knockdown, and is sped up with the hitboxes increased in size and damage (15 to 20); teleports slightly more behind the opponent
⦁ 2AB(B): transition timing adjusted to match 6B(B); cannot transition upon landing
⦁ RA: hit sizes increased with more stun on hit
⦁ JA: in combos teleports with 6 or 4
⦁ 5Y: has a new animation; does 20 damage
⦁ 2Y: throw has a new animation; does 20 damage and side switches
⦁ 5X: is a close range attack with less recovery on miss
⦁ 2X: does vanilla 5X animation activation into GNT4 2X activated super; starts moving slightly sooner; slightly less damage
⦁ 4X: is a real time super with startup immunity to highs and mids that knocks away
⦁ GRKnJ: travels one frame slower; transitioned to be further from the opponent on reappearance, more lift on hit; changed to be a mid from a high


Iruka:
⦁ Scar added to model's face
⦁ Air Throw added
⦁ Grabbable moves: 6B(A), 6A, 8A, JA
⦁ 5B: hitbox appears one frame sooner, slightly smaller hand hitbox; elbow hitbox removed; hand hitbox larger on frame 2
⦁ 5BB(A): changed to be a modified RA with 6A(A) follow up
⦁ 6B: has more stun, more lift, and turns back turned people around
⦁ 6B(B): made a mid from a high, replaced with 2B(B)
⦁ 6BB(B): replaced with 6B(B); does 22 damage from 20; transition on the follow up made until the move ends instead of only 10 frames
⦁ 6BB(A): replaced with 6A(A)
⦁ 6BBB(A): with follow ups exists
⦁ 4B: has more lift on hit
⦁ 2B: has stronger hit and block stun
⦁ 2B(B): had spinning knockback removed, made mid instead of high, and has less lift; replaced with 6B(B); comes out one frame slower
⦁ 8B: replaced with 2B(B); does 20 damage from 26; transition is faster
⦁ JB: made to launch with spinning knockback instead of stagger
⦁ RB: hitbox appears one frame later, move recovers earlier; first frame of the hitbox is techable, the rest are untechable
⦁ 5A: charge time reduced from 13f to 10f; done with 8 does 8A; has slightly more lift on uncharged when used in a string
⦁ 4A: has a better window
⦁ A4A: is unblockable and comes out faster
⦁ 6A: teleports behind the opponent no matter the range, when done in a string it does normal teleport with quicker action
⦁ 6A(A): hitbox disappears three frames sooner
⦁ 2A: has slightly more lift on hit and  damage increased from 18 to 23
⦁ RA: lifts on block
⦁ 5X: first hit turns around back turned people
⦁ 2X: does 2X activator that goes into 5X super, it starts two frames sooner the hitboxes are bigger, first hit turns around back turned people, activated super does more damage; activated hits four additional times when the shurikens hit the opponent
⦁ 4X: is a real time super with start immunity to highs and mids that does Kabuto's 5X animation; has a unique super freeze animation; cannot be Y cancelled
⦁ GRKnJ: hitbox appears one frame later; appears much further back


Itachi:
⦁ Health: decreased from  230 to 210
⦁ Guard: decreased from 1840 to 1680
⦁ RA, 6A(B), 8A(B), 6AA(A), 5BBBBA(A), 6BBA(A): 3 grabbable frames added before teleporting
⦁ 5B: elbow hitbox doesn't appear on the first active frame; given slightly more stun and blockstun
⦁ 5B(B): first active frame is a high, elbow hitbox is slightly bigger, hand hitbox is slightly smaller, hitbox disappears one frame sooner; animation moves forward slightly more
⦁ 5BB(B): ends four frames earlier
⦁ 6B: ends 3 frames earlier
⦁ 4B: animation replaced with 5BBBBB(B) and added more block stun.
⦁ JB: hitbox improved
⦁ 6A(B): has more lift on hit and has had its hitbox improved
⦁ 8A: hitbox disappears one frame sooner
⦁ JA: has changed momentum; clone appears higher
⦁ 5X; damage reduced from 85 to 70 and starts moving 2 frames sooner in super freeze; damage is applied on the stab and meter drain still applied at the end
⦁ 2X: defends back; missed 2X drains just over 12.5% meter at the end of the move; requires 75%; can be grabbed
⦁ GRKnJ: appears further back
⦁ ARKnJ: has 12 frames less endlag to match the others; lift reduced on hit.


Jiraiya:
⦁ New costume added
⦁ Grabbable Moves: 2A, 6A, 8A
⦁ 5B(B): stun on block and hit improved; move recovers earlier
⦁ 5BB(A): increased block stun and hitbox disappears one frame sooner
⦁ 5BBA(A): is unblockable
⦁ 5BBAB(A): replaced with 2A
⦁ 6B: has slightly less lift; has more stun when done raw; ends slightly sooner
⦁ 2B: hitbox appears 4 frames earlier, first frame is an untechable bounce, then stagger; elbow hitbox appears on frame 2; hand hitbox smaller; bounces further from Jiraiya
⦁ 2B(B): hitbox appears one frame earlier without the elbow, first frame is a bounce, then normal hit
⦁ 2BB(B): bounces closer to Jiraiya, recovers sooner; done with 6 will do RAB(B)
⦁ JB: hitbox appears and disappears one frame sooner
⦁ RB: pushes on block and ends sooner; slightly more lift
⦁ 5A: charge time decreased from 11 frames to 9; when done in a string it does 5BBA(A)
⦁ RA: has more lift on hit
⦁ RA(B): replaced with 2B(B) with follow ups intact
⦁ RAB(B): replaced with 2BB(B); done with 6 does vanilla. Foot "lands" two frames earlier, hard knockdown, cannot Y cancel, hitboxes slightly bigger
RAB(2B): longer duration, lower angles, hard knockdown
⦁ RAB(A): added as 2A
⦁ 4A: has more stun and the looping of the animation is adjusted to 14 frames from 20; aerial hit lift adjusted to be lower with less hits
⦁ 2A: (not in a string) has less recovery for Jiraiya; opponent can sub if hit out of puddle
⦁ 2Y: added as a sideswitch throw
⦁ 2X: is immune to highs and mids until Jiraiya begins to lower his hands, immune to highs only when his hands touch the ground; frog hitbox duration reduced from 60 frames to 38
⦁ GRKnJ: has the reduced endlag of RB; changed to a mid from a high


Jirobo:
⦁ Throw damage reduced from 22 to 20
⦁ 2Y throw added (Slam throw)
⦁ Air Throw added
⦁ Health: increased from  230 to 240
⦁ Guard:  increased 1840 to 1920
⦁ Grabbable moves: JA, 6A, 5BBBA(A)
⦁ 5B(B): has better advantage on hit and block, ends sooner
⦁ 5BB(B): does 10 less block damage
⦁ 5BBB(B): has 9 less endlag frames
⦁ 5BBBA(B): does 1 more damage; pushes on block; does not high crush
⦁ 5BBBA(A): does 1 less damage, grab follow ups removed, but makes an unsubbable knockdown; knockdown starts getting up faster
⦁ 5BBBAA(A): added as a blockable command grab; does 5+40 damage and is breakable. Also on: 2BAA(A), 8BBA(A), 2BBA(A), 2BBBBA(A), 6BBAA(A); can press/hold 4 at the start to turn around and do the throw
⦁ 6B: shoulder hitbox does not appear on the first active frame, hand hitbox is smaller for the first frame; becomes an untechable bounce with regular hitboxes on the second active frame; delay to 5B(B) changed to be an 8 frame wait instead of 10
⦁ 2B: has more stun on hit and block 
⦁ 2B(A): changed to be 6A
⦁ 2BA(A): added with stone clap
⦁ 8B: has more lift on block 
⦁ 8B(B): starts up one frame later; transitions 3 frames later
⦁ RB: ends 12 frames earlier
⦁  charge changed from 9 frames to 6 frames; done with 6 does 6A
⦁ 5A1C: single charge of 5A is a hard knockdown; less lift on hit
⦁ 6A: has slightly more lift on hit,  comes out one frame earlier when done in a string
⦁ 6A(A):  added as stone clap
⦁ 4A: window improved, when done in a combo it does 6A
⦁ A4A: hit into a spinning knockdown that is unblockable; has an A and B follow ups
⦁ 2A: has endlag on both sides, reduced from 25 to 10 on behind (same for front)
⦁ 8A: super armor ends when Jirobo leaves the ground
⦁ A8A: ends three frames sooner when the animation ends and is hittable after he gets off the opponent
⦁ RA: has guard frames when Jirobo is in the air and can be thrown, hits twice; high crush on landing
⦁ 5X: has two less frames super freeze
⦁ 2X: made immune to highs and mids from frames 0-14 after super freeze instead of intangible 0-1, 42-end
⦁ ARKnJ: intangibility removed
⦁ GRKnJ: has faster englag to match RB, flags fixed from vanilla


Kabuto:
⦁ Health: increased from 180 to 190
⦁ Grabbable moves: RA, JA, 8A, 2A landing
⦁ 5B: hitbox appears two frames later, slightly smaller hand hitbox; elbow hitbox removed; hand hitbox larger on frame 2; one more frame blockstun
⦁ 5B(B): has slightly more stun; hitbox appears and disappears a frame later; slightly more lift on hit
⦁ 5BBAB(B): transition time adjusted to match 6B(B); slightly more lift on hit (not on 6B(B))
⦁ 5BBAA(A): guard frames changed to be start to 22 instead of the entire move; pushes on block
⦁ 6B(B): has four frames less endlag
⦁ 6BA(B): high crush added to frame 18-21
⦁ 2B: high crush from 11-31; transition to 2B(B) window increased by 10 frames
⦁ 2BB(B): replaced with a custom 6BA(B) that knocks away on hit and block; hitbox appears one frame later
⦁ 2BB(A): has guard frames from 1-22
⦁ 8B: high crushes on landing; 4 less recovery frames
⦁ RB: changed to strong and pushes on block, bigger hitbox
⦁ JB: launches instead of staggers
⦁ 6A: has high crush on frames 9-21
⦁ 6A(A): has more stun
⦁ 6AA(A): now also lifts on block
⦁ 4A: window improved
⦁ A4A: comes out quicker and ends quicker
⦁ 2A: flags adjusted to match the animation better, cannot sub during the animation, unscaled damage applies to both players
⦁ A2A: can be hit at the peak of his jump
⦁ 5X: activator has the hitbox appear 4 frames sooner and begins moving 3 frames sooner
⦁ 2X: does slightly more damage, drains chakra, second frame to end is unblockable; hit airborne launches higher; stuns much longer when not putting into sleep
⦁ GRKnJ: replaced with 5BBBB(A); adjusted to hit quicker without reducing travel time


Kakashi:
⦁ Alternate costume changed to be ANBU Kakashi
⦁ J2Y: Air Throw is custom; non sharingan version puts Kakashi in sharingan mode and does not build meter, requires and costs 25% meter; in sharigan it does more damage and builds meter
⦁ Sharingan Health drain: cut to 1 health every 90 frames (from 1 every 20); Kakashi takes 1.25x damage in sharingan mode
⦁ Grabbable moves: 8A, JA, RA, 5A, 2A landing
⦁ 5B: hitbox appears one frame sooner, slightly smaller hand hitbox; elbow hitbox removed; hand hitbox larger on frame 2; Sharingan mode has 2 more frames of block stun
⦁ 5B(B): has increased stun, hitbox appears and disappears one frame later
⦁ 5BB(B): lifts on block and has more lift
⦁ SBB(B): has super cancel and staggers; hitbox appears one frame sooner with one more frame of block stun; B follow up transition timing made slightly longer
⦁ 5BB(A): is a custom kunai slash forward that lifts on hit and block, super cancelable; sharingan version does not lift on block
⦁ 5BBB(B): does 5 more damage and is a hard knockdown
⦁ S5BBB(B): comes out one frame slower
⦁ 5BBB(A): hitbox added to knee and size adjusted, doesn't lift on block, more lift on hit
⦁ 6B: hitbox appears one frame earlier, more lift to match S6B's second hit
⦁ S6B: first hit has slightly more blockstun; second hit pushes on block with a slightly bigger knee hitbox and the hitbox disappears one frame earlier
⦁ 4B: floats higher
⦁ 8B: hitbox appears two frames later
⦁ RB: add super cancel
⦁ JB: add super cancel, better descent angle
⦁ 6A: has more lift
⦁ S6A: first hit has more lift on hit, second hit lifts on block, 2 more frames on duration
⦁ 4A: uses animation from stance cancel
⦁ S4A: has 9 additional frames added to the activator to better match the animation
⦁ A4A: moves into launch hit faster, unblockable
⦁ S4A: changed Mizuki 5X properly copied
⦁ Act2A: is hittable at the peak of the jump; adds hits to the combo meter: +1 damage
⦁ 5X; duration improved from 1 frame to 7, fully charged from 1 to 8; damage adjusted to the cinematic portion of the attack
⦁ S5X: is 5X; on transition to capture state leaves sharingan mode; requires and costs 75%
⦁ S2X: is GNT4 S5X, activator duration increased by 2 frames; damage reduced slightly; on transition to capture state leaves sharingan mode
⦁ 4X: requires and costs 25%
⦁ GRKnJ: travels two frames slower; appears further back


Kankuro:
⦁ 3ME entrances are modified: airborne option is the same air sub as everyone else, grounded version is RB
⦁ Health:  decreased from 185 to 180
⦁ Grabbable moves: 6B(A), 8B, 5A, 6A, 6A(A), 4A, 2A, 2A(A), 2AA(A), 2AAA(A), 2AAAA(A), RA, RA(A), 8A, JA
⦁ Health: 185 to 180
⦁ 5B: elbow hitbox appears on the second active frame; two less damage; more float
⦁ 5B(B): hitbox appears and disappears one frame later
⦁ 6B: hitbox disappears one frame sooner
⦁ 6B(A): has six more frames endlag; staggers on hit
⦁ 6BA(B): transition made to end at the normal timing
⦁ 8B strings removed; duration changed from 49 frames to 44 frames (lands on 40)
⦁ 6A: when done in strings has five more frames of endlag
⦁ 5X: starts moving two frames sooner in super freeze


Karasu:
⦁ (K) affects Kankuro's puppet use too
⦁ (K) Backdash ends 5 frames sooner
⦁ (K) Sleep stun lasts significantly longer
⦁ (K) Grabbable moves: 8B, 8A, JA
⦁ 5B: strong on block, staggers; elbow hitbox appears on the second active frame
⦁ 6BAAA(A) added by changing 6BAA(A) to RA
⦁ 2B(B) added as 8B
⦁ 8B(B) removed
⦁ (K) 2A, 2A(A), 2AA(A), 2AAA(A) have 4 more damage each
⦁ (K) Air throw added


Kiba:
⦁ Health: increased from 200 to 205
⦁ Guard: increased from 1600 to 1640
⦁ Grabbable moves: 8A, JA, JB(B) ending
⦁ 5B: hitbox appears and disappears one frame later; shoulder hitbox does not appear on the first frame
⦁ 5B(B): hitbox appears one frame later and disappears one frame sooner, improved disadvantage on block, move ends sooner
⦁ 5BBB(A): hitbox appears one frame sooner and disappears two frames sooner, more lift on block 
⦁ 6B(B): bounces closer, ends sooner, does more damage
⦁ 6B(2A): added as 5A
⦁ 4B: staggers instead of bounces
⦁ 2B: has more lift on hit
⦁ 5A: can be grabbed during the entire animation
⦁ 5A: Kunai cannot be charged by holding down the A button 
⦁ 4A: better activation window
⦁ A4A: ends a bit faster, unblockable, does more damage
⦁ 2A: Akamaru startup adjusted; is active after 9 frames instead of after 1
⦁ RA(B): changed to be 6B with follow ups
⦁ 5X6: does Kidomaru's 5X activator into vanilla 5X, low crushes; has a unique super freeze animation
⦁ GRKnJ: travels two frames slower
⦁ 3MC A Entry: Changed to be RA animation that knocks down

Akamaru:
⦁ (K) affects Kiba’s dog use too
⦁ Guard: decreased from 1120 to 1000
⦁ Aerial select sub added
⦁ (K) 5BBB(B) has more lift
⦁ 6A projectile staggers instead of launches
⦁ 5X requires 50% meter


Kidomaru:
⦁ Air Throw added
⦁ Ring Combo: 8A is 8A; 6A is 6A; 2A is 2A; 4A is 4A; 5A is 5BBB(A)
⦁ WUK animation: is 2B(B); has one additional frame of intangibility before fuse and the hitbox starts and ends one frame later
⦁ 3MC: 6A and 8A killing in no longer locks out the use of the same moves
⦁ Grabbable Moves: 6A, 2A, JA, 8A, 5BBBB(A), 2BBB(A), 5BBAB(A), 2BBAB(A)
⦁ 5B: has more lift on hit
⦁ 5B(B): stuns longer by 2 frames on hit and 3 frames on block
⦁ 5BB(B): hitbox adjusted slightly, hitbox active one more frame, animation ends 5 frames earlier; can delay into A follow up longer
⦁ 5BBA(R): ring transition made one frame later
⦁ 5BBB(B): flags cleaned up; recovers faster
⦁ 5BBB(A): is now ring combo
⦁ 5BBBB(B): increased damage
⦁ 5BBAB(B): has no knockback on the first two hits and none of the hits pushes block
⦁ 5BBAB(A), 5BBBB(A): now sends opponent flying across the screen instead of bouncing
⦁ 5BBAB(A): follow up does not last as long; changed to match others
⦁ 6B(B): has one more frame duration and slightly more lift on hit
⦁ 6B(A): added as ring
⦁ 6BB(B): does more damage; 3 frames before the teleport that are grabbable added; can be delayed 14 frames longer
⦁ 6BB(A): now leads to ring
⦁ 4B: first two hits link into the third better
⦁ 2B: has sweep added with less lift
⦁ 2BB(B): has more lift; flags adjusted; ends earlier
⦁ 2BBB(B): flags adjusted
⦁ 2BBAB(B): does more damage
⦁ 8B(R): ring added
⦁ JB: hitbox appears a frame earlier
⦁ RB: flags adjusted to better fit the move; ends 9 frames earlier
⦁ 5A: has no charges but releases the charged projectile
⦁ 4A: def starts frame 12, loop that drains chakra starts at frame 2 (from 20), drains 190 units per frame (from 180)
⦁ A4A: activates into a single frame of blocking if needed
⦁ 6A: does 1+10 damage instead of 5 damage
⦁ RAA(B): transition much faster with an end window
⦁ RAA(A): now leads to ring combo
⦁ JA: staggers
⦁ 5X: transfers into the activated animation quicker; hitboxes appear one frame sooner, all hitboxes made slightly bigger; middle arm hitbox moved to waist
⦁ 2X: is immune to mids and highs until he begins to lower his hands; spider hitbox is bigger
⦁ GRKnJ: changed to a custom animation using the 5X activator; moved back a bit


Kimimaro:
⦁ WUK: uses the 2A(A) animation
⦁ Grabbable Moves: JA
⦁ 5B: elbow hitbox removed; hand hitbox made smaller for first frame only
⦁ 5B(B): improved by 6 frames on hit and block
⦁ 5BBB(B): has more lift on the second hit; does not lift on block
⦁ 6B: turns back turned people around on hit, more lift
⦁ 6B(B): more stun
⦁ 6BB(B): replaced with 4B
⦁ 6BAA(A): added as 6AAA(A)
⦁ 2B(B): now launches
⦁ 8B: has spinning knockback and ends sooner, more lift on hit
⦁ 6A: more hitstun, more lift on hit, swapped with 6A(A); hitbox appears one frame sooner
⦁ 6A(B): increased hit stun
⦁ 6A(A): made a strong hit, swapped with 6A
⦁ 6AA(A): made a strong hit, launches
⦁ 6AAA(A): does one more damage on each hit with less lift and better connection in the air
⦁ 8A(B): less lift on hit
⦁ 8A(A): less lift on hit
⦁ 4A: window for activation increased
⦁ A4A: all hits are unblockable except the last, links better on airborne
⦁ 2A(A): has more lift on hit
⦁ 2AA(A): added as 6AAA(A)
⦁ 5X: hitbox appears 5 frames sooner with adjusted hitbox
⦁ 2X: bones that did 6 damage now do 5 damage
⦁ GRKnJ: intangibility removed; made a mid from a high
⦁ ARKnJ: intangibility removed


Kisame:
⦁ Health: decreased from 240 to 230
⦁ Guard: decreased from 1920 to 1840
⦁ 5Y: does normal overhead throw
⦁ 2Y: is slam throw
⦁ Grabbable Move: JB Ground Hit
⦁ All non sword moves: do -2 damage (except 5B and 5B(B))
⦁ 5B: elbow hitbox appears on active frame 2
⦁ 5BBB(B): can now be delayed
⦁ 6B: turns back turned opponents around; more lift on hit
⦁ 2B: ends sooner
⦁ 2B(A): changed to be 6A
⦁ 8B: high crushes on frame 6
⦁ 8B(B): added as 6B with follow ups
⦁ JB: shockwave hitbox is now -1 on hit (was -8)
⦁ 5A: +5 damage and block damage, more lift on hit
⦁ 5A(A): has more lift on hit
⦁ 6A: uncharged juggles better, hitbox appears one frame sooner, hilt hitbox is larger; final hit on all is a sweep
⦁ 6A2C: is unblockable; sweep ender is untechable
⦁ 4A: Window for activation improved
⦁ A4A: is unblockable and drains chakra
⦁ 8A: high crush changed from 1-end to 11-32 to match the animation better
⦁ JA: phantom sword glitch applies to both players; hitbox is active for one more frame
⦁ 5X: hitbox appears one frame sooner; drains 50% meter (GNT4 is 47.8%)
⦁ 2X: requires and costs 75%; shark juggles better
⦁ GRKnJ: changed to a custom 6B


Lee:
⦁ Works like a level up character with 2G mode having no passive lift or meter drain
Damages adjusted between all forms:
5B:  9,13,17 > 9,12,15
6B: 11, 17, 22 > 11,15,19
4B: 12,18,23 > 12,16,20
4B1C: 18, 27, 35 > 18,26,34
2B: 10,15,19 > 10,14,18
RB: 15,22,28 > 15,21,27
5A: 11,17,22 > 11,15,19
6A: 9,14,18; 18, 24, 30 > 9,13,17 > 18,22,26
2A: 11,17,22 > 11,15,19
JB: 21,28,34 > 21,25,29
JA: 13,19,24 > 13,17,21
8B: 8,12,15
8A: 0,7,9; 10,13,17 > 0,7,9; 10,12,14
5BB: 8,12,15
6BA: 18,26,30 > 18,22,26
4BB: 12,18,23 > 12,16,20
5BBAA: 15,22,28 > 15,19,23
8BA: 15,22,28 > 15,19,23
5BBA: 12,22,28 > 12,16,20
⦁ 6B(A):, JB, 6A second hit, 8A, Throw damage adjusted across the three states
⦁ 5B: has more lift
⦁ 5B(B): recovers one frame slower
⦁ 5BBA(A): has more lift and a hyuuga cancel before he leaves the ground
⦁ 6B: replaced with 4B(B) animation, no launch, when done in a string does vanilla 6B that ends 6 frames sooner
⦁ 6B(A): Hyuuga cancel added
	- 1G: Untechable knockdown
	- 2G: Untechable bounce
⦁ 4B: charged:
	- 1G: 3x guard damage
	- 2G: Instant guard break
⦁ 4B(B): high crush from 13-36
⦁ 2B: changed to have better hit and block stun
⦁ 8B: first hit lifts on block
⦁ JB: has slighty adjusted launch direction and slightly more lift
⦁ 5A: has more lift, turns the opponent around on back turned
	- 1G: Deflects projectiles
	- 2G: Staggers on hit
⦁ 6A: first hit has increased hitstun , lifts higher on block, direction of hit changed; second hit size increased
	- 1G: First hit lifts on block, second hit pushes on block
	- 2G: Second hit hard knockdown
⦁ 4A:  active window is increased
⦁ A4A; can only be subbed the first frame
⦁ 2A has more lift on hit
	- 1G: Ends sooner
	- 2G: Lifts instead of sweeps
⦁ 8A: has more block damage, made strong on block
	- 1G: Has an initial hit on the way up
	- 2G: Untechable bounce on the second hit
⦁ RA: is unchanged in no gates, is a set distance teleport with 1G open, is a set distance appearance teleport with 2G open and less startup than 1G
⦁ JY:
	- 0G: Nothing
	- 1G: Normal Air throw
	- 2G: Special lotus air throw
⦁ 5X: does Gaara version of the super on everyone, damage is 55; activator does 10 damage
⦁ 1G5X: does 65 damage with the vanilla version; activator does 10 damage
⦁ 2G5X: does 110 damage from 146
⦁ 4X: requires 50% and takes 50%
⦁ 1G4X: requires 75% and takes 100%; hard knockdown
⦁ GRKnJ: moved further back on appearance; made a mid from a high


Mizuki:
⦁ 2Y: added as a knockdown throw for 40 damage
⦁ Grabbable Moves: 6B(A), 6BB(B), 6A, 8A, JA
⦁ 5B: hitbox appears one frame sooner, slightly smaller hand hitbox; elbow hitbox removed; hand hitbox larger on frame 2
⦁ 6B: now staggers
⦁ 6B(B): has one more frame of hitbox
⦁ 6BB(B): Y cancels properly now
⦁ 6BB(A): is now  8A; transition is later
⦁ 2B: made strong, change to hit direction
⦁ 2B(B): made a mid
⦁ 2BBA(B): hitbox disappears three frames sooner
⦁ 8B: pushes back on block
⦁ RB: starts a frame later; move ends sooner
⦁ 5A: charge time decreased from 13f to 8f
⦁ 6A: when used in string teleport backwards; faster action after; unique follow ups for string or raw (A and B)
⦁ 6A(B): changed to be 2BA(B)
⦁ 6AB(B): removed
⦁ 4A: window improved; can activate on projectiles
⦁ A4A: teleports up and behind the opponent
⦁ 8A: projectiles have an additional frame gap between their spawn
⦁ JA: now throws two shurikens
⦁ 5X: is GNT4 activator into 2X animation with less damage; first hitbox turns backturned opponents around; does less hits on the dance
⦁ 2X: is GNT4 2X activator with large size and better duration on hitboxes; first hitbox turns backturned opponents around; activation does more damage than 5X; slightly less super freeze timing
⦁ 4X: is a super projectile that begins with a jump backward; unblockable; requires and uses 75% meter; can be charged with X for more damage
⦁ GRKnJ: made into 4B; hand is now closed; travel time is faster


Naruto:
⦁ New costume added
⦁ Grabbable Moves: JA, 8A, 
⦁ 5B: elbow hitbox appears on frame 2
⦁ 5B(B): hand hitbox does not appear until frame 2
⦁ 5BBB(B): can be replaced with the clone active version with 8B
⦁ 5BBBB(B): does slightly more damage, pushes further away, and doesn't teleport as far
⦁ 5BAA(A): starts up and ends one frame later; staggers
⦁ 6B: has an untechable bounce after the first active frame; first frame is a high; properly low and high crushes
⦁ 4B: bounces closer on hit
⦁ 8B: hitbox appears one frame later, more lift
⦁ 6A(A),  6A(8A): added as 2A and 8A
⦁ 2A: has a new animation
⦁ RA: has more lift on hit
⦁ 5X6: activates into 5X and uses 6B attack; has a different super freeze animation; low and high crushes
⦁ 2X: has less super freeze and more duration
⦁ 4X: requires 50% meter; has more lift on hit


Naruto (ZTK):
⦁ Takes 1.25x as much damage (instead of 1.5x); no passive health drain and passive meter gain reduced to 2 units per frame (from 40)
⦁ Grabbable Moves: 2A
⦁ 5BBBB(B): bounces closer on hit
⦁ 5BA(B): has more lift on hit, hitbox appears three frames later, made normal lift instead of spinning
⦁ 5BAA(A): replaced with 8A
⦁ 5BAAA(A): replaced with 8A(A)
⦁ 6B: low crushes
⦁ 8B: lifts on block
⦁ 8B(B): has more lift on hit
⦁ 8B(A): added as 8A(A)
⦁ 5A: given more float
⦁ 5A(A): given more float and super cancel
⦁ 6A: given more float and super cancel
⦁ 4A:  activation window improved
⦁ A4A: goes into RA
⦁ 2A: does activated 4A, adjustments to size; duration; and hitbox
⦁ 8A: has slightly more vertical range on the bottom
⦁ 8A(A): does slightly more damage and doesn't bounce
⦁ RA: ends 4 frames sooner; has three grabbable frames at the beginning
⦁ 5X: third to last hit staggers; second to last hit doesn't jump as far forward, fixed animation glitch (added one hit); first hit lift adjusted to not sometimes reset the combo
⦁ 5X6: uses 6B attack into Z5X; has a different super freeze animation


Naruto (OTK)
⦁ Health: decreased from 220 to 180
⦁ Grabbable Moves: 6A, JA, 2B(A), 8A landing
⦁ 5B: has more blockstun
⦁ 5B(B): hitbox appears one frame later
⦁ 4B: no longer pushes on block
⦁ 4B2A: is 2BA with 6 additional startup frames
⦁ 2B(A): changed to be 6A, 2B2A added as old 2BA
⦁ 8B(A): has 8 frames less blockstun; cannot be transferred into after hitting the ground; does not bounce
⦁ 8BB(B): damage reduced from 18 to 16
⦁ 8BBBB; 8BBBA: added as new strings to match 5BBBBBB and 5BBBBBA
⦁ 4A: increased activation window
⦁ A4A: has a slightly smaller hitbox and made to do more damage and be unsubbable and untechable
⦁ 2A: hitbox appears one frame later
⦁ 8A: on block or OTG "lands" 11 frames later; has two more frames endlag; actually low crushes the frame before the hitbox appears
⦁ A8A: victim transitions to get up 14 frames faster; OTK is hittable and grabbable shortly after he does damage
⦁ RA, 6BAA(A) given three grabbable frames before the teleport
⦁ 2X: high crush frames removed
⦁ GRKnJ: no longer intangible anymore


Neji:
⦁ Grabbable Moves: 8A, JA
⦁ 5B: elbow hitbox appears on frame 2; slightly smaller
⦁ 5B(B): hitbox appears and disappears one frame later
⦁ 5BBB(A): is a custom capture state move
⦁ 5BBBB(A): damage increased from 14 to 20
⦁ 4B: remove stagger, made strong, more stun
⦁ 2B(B): changed with 5BBB(B) with A follow up
⦁ 8B: more lift on hit, hitbox appears later, no Y cancel
⦁ RB: replaced with RA with B follow ups
⦁ RB(B): can be done on whiff; transition is 5 frames slower
⦁ 5A: charge time reduced from 11 frames to 8
⦁ 6A: launches on the last hit, damage and lift on hit adjusted; first two hits juggle slightly better without a wall
⦁ A4A: unblockable and unsubbable
⦁ 2A(A): added as 6A
⦁ RA: is a custom poke
⦁ 5X: starts moving 3 frames sooner, activates if only hitting the second hit; first hit turns back turned opponents around; hitboxes and lift adjusted for more consistency


Orochimaru:
⦁ Grabbable Moves: JA, 8A, 2A(A), 2AA(A), 6A, 2B(A)
⦁ 5B: has slightly more stun on block and more lift on hit
⦁ 5B(B): improved advantage on hit and block; move ends four frames sooner; can follow up on whiff
⦁ 6B: can do A follow up on whiff
⦁ 6B(B): added as 2BBB(B) with follow ups
⦁ 2B: can follow up on whiff
⦁ 2BBB(B): has more lift
⦁ 2BBB(A): changed from RA to 4A
⦁ 2BBBB(B): bounces closer on hit
⦁ 8B: has guard frames until Oro jumps; done in string replaced with 2BBB(B) with follow ups
⦁ RB: lifts on block
⦁ RB(B): added as 2BBBB(B)
⦁ JB: can be DIed in the air with 6 or 4
⦁ 5A: charge time changed from 11 frames to 8
⦁ 5A(A): added as 2AA(A)
⦁ 4A: "attachment" window changed from 10 frames to 14
⦁ 2A: has more stun on the second hit, less hitbox duration
⦁ 2AB(B): added as 2BBBB(B)
⦁ 2A(A): has slightly more stun
⦁ RA: is an untechable sweep
⦁ 2BBBB(A): and 2AA(A) snakes do chip
⦁ 2Y: staggers on hit, opponent cannot be grabbed, opponent cannot shake the stagger
⦁ 5X: damage reduced 65 to 50
⦁ 2X: hits better on both hits; damage on the activated portion, first hit lifts on block and is blockable; ends sooner
⦁ GRKnJ: changed to be RB


Sakon:
⦁ Sakon (but not Ukon) has a new idle
⦁ Pressing (or holding) Z on the first frame of back dash switches the brothers; can be done on match startup
⦁ 5B: more stun on hit and block; elbow hitbox doesn't appear until the third active frame
⦁ 5B(B): hitbox appears and disappears one frame sooner; better stun on hit and block; move ends sooner
⦁ 5BB(B): hits mid
⦁ 5BBA(A): transition adjusted to be quicker
⦁ 6B(B): replaced with 8B with follow ups
⦁ 4B: doesn't push on block
⦁ 8B: has slightly more lift on hit
⦁ 8B(B): has slightly more lift
⦁ 8BB(B): hitbox appears one frame sooner
⦁ 8BB(A): has slightly more lift; string added for Ukon
⦁ 5A: charge changed from 11f to 8f
⦁ 6A: done as Sakon doesn't launch, super cancel, pushes on block
⦁ 4A: window for counter improved; swaps the brothers when the activation window starts
⦁ Sakon Act4A: is unblockable and unsubbable
⦁ Ukon Act4A: does 2A(B)
⦁ 2A: stagger removed
⦁ 2A(B): has more lift and ends earlier; transition slowed down
⦁ 2AB(A): does 8BB(A)
⦁ 2A(A): staggers and has increased lift
⦁ 8A: hitbox appears one frame sooner
⦁ RA: has less lift, 3 more frames duration, lifts on block
⦁ RA(A): does spinning knockdown, less lift, ends sooner; transitions later
⦁ JA, 8BB(A): hits 3 times instead of 4, more damage, stun, and guard damage
⦁ JY: Sakon (but not Ukon) has an air throw
⦁ 5X: starts moving 4 frames sooner during super freeze
⦁ 4X: swaps Sakon to Ukon the first active frame of the hitbox and swaps Ukon to Sakon on frame 2 of the activator. Goes into 5X on activation
⦁ 2X: now a mid instead of a high
⦁ GRKnJ: hitboxes changed to properly match RB


Sakura:
⦁ 2Y throw added; 30 damage and knockdown
⦁ Throw has a new animation and does damage
⦁ Health: increased from 185 to 205
⦁ Guard: increased from 1480 to 1640
⦁ Grabbable Moves: 5A(A), 5AA(A), 8(A), 8B(A), JA, JA(A), JAA(A)
⦁ 5B: has more lift on hit; elbow hitbox appears on second active frame; slightly bigger hitbox
⦁ 5B(B): shoulder hitbox slightly smaller, hitbox appears and disappears one frame later
⦁ 5BB(B): "lands" two frames sooner; ends 9 frames sooner
⦁ 5BB(A): input can now be buffered up to 23 like in vanilla, but also can be input anytime to the end of the move; cannot follow up on whiff
⦁ 5BBB(B): is a hard knockdown
⦁ 6B(B): has more lift
⦁ 4B: cannot be followed up on on whiff
⦁ 4B(B): has flying screen added, hitbox appears one frame earlier
⦁ 4B(A): replaced with a custom 2A; does not lift on block
⦁ 2B: launches instead of sweeps
⦁ 8B: lift decreased on hit,  duration adjusted to fit the animation better, 3 more damage, ends sooner
⦁ 8B(B):  no longer sends you flying across the screen on hit, adjusted lift on hit, size, and duration
⦁ 8B(A): made 5A with follow ups
⦁ RB: is now an untechable bounce and a high for the first two frames; techable and mid after the first two frames; hitbox disappears two frames sooner
⦁ 5AA(A): now staggers
⦁ 5A2C: now staggers
⦁ 6A: has old 6A startup, but teleports up and behind the opponent; has strings into A and B
⦁ 4A: replaced with 6A, teleports behind the opponent
⦁ 2A: cannot be followed up on on whiff
⦁ 2A(B): added
⦁ 2AA(A): replaced with RA
⦁ 8A: spaced out the projectiles more
⦁ RA: has three grabbable frames added to the startup
⦁ JA: can transition faster; has forward or backwards momentum with 6 or 4
⦁ JA(A): air momentum changed, can transition faster; has forward or backwards momentum with 6 or 4
⦁ JAA(A): has forward or backwards momentum with 6 or 4
⦁ 5X: is vanilla with one more frame duration on hitbox
⦁ 2X: has better super freeze, hitbox appears one frame sooner and disappears two frames later
⦁ 4X: is a real time super with startup immunity to mids and highs
⦁ GRKnJ: bounce changed to be closer; travels one frame faster


Sarutobi:
⦁ Air Throw added
⦁ Ring Combo: 5A = 5BB(A); 8A = 8A; 6A = Flames; 2A = 2A; 4A = 4A
⦁ Health: increased from 200 to 220
⦁ Guard: increased from 1600 to 1760
⦁ Grabbable Moves: 6A(A), 8A, 2A, JA
⦁ 5B(B): hitbox appears and disappears one frame later; better advantage on block; move ends sooner
⦁ 6B: can follow up on whiff
⦁ 6B(B): has less endlag; can follow up into A on whiff
⦁ 2B: can continue to 2B(A) on whiff; does one more damage; last active frame has less lift
⦁ 2B(B): is now spinning knockback, less lift; A transition made later
⦁ 2BB(B): ends sooner; transitions to B follow up quicker
⦁ 2BB(A): comes out later; does ring combo
⦁ 2BBB(B): links into the second hit better
⦁ 2B(A): damage increased by 2
⦁ 2BA(B): has more lift on hit, hitbox duration adjusted to juggle better, ends much sooner
⦁ 2BAB(B): damage increased from 23 to 25
⦁ 8B: more blockstun; hitbox stays out one more frame; transition to A made 8 frames slower
⦁ RB: made untechable frame 22 to the end
⦁ 5A: charged time reduced from 10f to 8f
⦁ 6A: damage decreased by one damage
⦁ 6A(A): goes to ring combo
⦁ 4A: acts like a normal counter, still works against projectiles
⦁ Act4A: cannot be subbed, teched, or blocked, high crushes on frame 14, hitbox comes out one frame later
⦁ 2A: hits 8 times instead of 3 per rock; damage per hit reduced from 8 to 3; when done in a string goes to ring combo; pushes on block
⦁ 8A: does chip damage, made strong, lifts on block; when done in a string goes to ring combo
⦁ RA(A): is ring combo
⦁ JA: staggers on hit and damage adjusted, appears one frame sooner; lift slightly increased
⦁ 5X: hitboxes appear sooner, last one more frame
⦁ GRKnJ: travels one frame slower; appears further back


Sasuke:
⦁ 2Y throw added that knocks down
⦁ Grabbable Moves: JA, RA, 8A, 6A, 8B landing, SJX, S8X
⦁ 5B: has a super cancel; elbow hitbox removed; fist hitbox made larger on second active frame
⦁ 5B(B): hitbox appears and disappears one frame later
⦁ 5BBBB(B): has more lift
⦁ 5BBBBB(B): appears one frame sooner and disappears 3 frames sooner, bounces closer
⦁ 6B: hand hitbox does not appear on the first frame
⦁ 2B(B): launches higher, launches on block, mid instead of high, comes out two frames later
⦁ 8B: cannot be subbed until later
⦁ A8B: is hittable after releasing the opponent
⦁ 5A: charge changed from 10f to 8f
⦁ 6A: is grabbable until release
⦁ 4A: hitbox starts up much later to match the animation, staggers, ends earlier
⦁ 2A: hitbox appears three frames later
⦁ 2A(A): staggers
⦁ 2AA(A): does 6A
⦁ RA: can now be done at any time during run and does not have to wait for a looped animation to begin
⦁ GRKnJ: travels one frame slower; appears slightly further back
Sharingan Sasuke:
⦁ 4A: counter window sped up
⦁ A4A: can only be subbed on the first frame
⦁ RA: has three grabbable startup frames
⦁ 5X: adjustments to duration, sizes, and damage is applied on the cinematic portion; does 10+65 from 10+50
⦁ 5X8: added with anti air chidori that does 10+60
⦁ SJX: fireballs have slightly more lift and stagger
⦁ S8X: added doing a modified SJX


Sasuke (Curse Seal 2):
⦁ Health: decreased from  220 to 200
⦁ Grabbable Moves: 6A, 2A, JA, 8B landing
⦁ 5B: hitbox appears one frame later, elbow hitbox does not appear on frame 1
⦁ 5B(B): hitbox appears one frame later; slightly less lift
⦁ 4B: hitbox appears one frame later to better match the animation, can be grabbed on startup; moves and appears 3 frames sooner; same strike timing
⦁ 2B(B): launches higher, launches on block, mid instead of high, hitbox appears later
⦁ 8B: cannot be subbed until later
⦁ A8B: is hittable after releasing the opponent
⦁ 5A: hitbox appears two frames later
⦁ 5A(A): adjusted high crush frames to make more sense
⦁ 6A: animation adjusted to not look so jumpy; strings into this new timing adjusted
⦁ 4A: activation window improved
⦁ A4A:  is unblockable
⦁ 2A: all hitboxes reduced to 93% of their size; damages adjusted: 0C (15 to 11); 1C (15 to 13); 2C: (15)
⦁ 8A: damage and block damage reduced from 14,10,10,10 to 9,6,6,6 
⦁ RA, RA(A): given three grabbable frames at the startup before the teleport
⦁ JA: now builds meter and lifts airborne opponents; can be subbed and teched
⦁ 2X: comes out faster, requires and uses 75%; damage reduced from 80 to 60
⦁ GRKnJ: moved backwards


Shikamaru:
⦁ Health: increased from 200 to 205
⦁ Grabbable Moves: 8A, JA
⦁ 5BB(A): launches with more lift, one frame less on the hitbox
⦁ 6B: made a sweep, less lift
⦁ 6B(B): more lift
⦁ 2BBB(B): ends sooner and has more lift
⦁ 8B: replaced by a modified SBB(B) with better knockback, high crush 7-15
⦁ 8B(A): can only be done after landing
⦁ RB: starts up three frames later
⦁ 4A: has faster action and high crushes at frame 6; can super cancel into 5X and 2X
⦁ 4A(Y): recovers faster
⦁ 2A: not in a string is an untechable sweep
⦁ SB: Teleports behind the opponent; remove stagger, more lift on hit can be done with 6 to change sides or 2 to empty teleport; can be grabbed before the teleport; slightly less stun
⦁ SB(B): more lift on hit
⦁ SBB(B): replaced with SABB(B)
⦁ SA: can be done with 6 to change sides or 2 to empty teleport; can be grabbed before the teleport; has a puff of smoke on reappearance on both sides; disappears two frames slower (same travel time) and closes hand before teleporting
⦁ SABB(B): more damage
⦁ SA(A): now staggers
⦁ SAA(A): replaced with 8A
⦁ S2B, S2A: are both empty teleports
⦁ 5X: starts moving 4 frames sooner in super freeze
⦁ 2X: has less super freeze and comes out faster, can move faster when hitting from further away than right next to the opponent, opponent falls slower, opponent cannot sub until they hit the ground or are hit; resets combo counter
⦁ GRKnJ: replaced with RA


Shino:
⦁ Health: increased from 195 to 205
⦁ Guard: increased from 1560 to 1640
⦁ Air throw added
⦁ Grabbable Moves: 5BB(A), 6A, JA
⦁ 5B(B): hitbox appears and disappears one frame later
⦁ 5BB(B): lifts on hit and block, ends sooner
⦁ 6B(B): now staggers
⦁ 6BB(B): has one less active hitbox frame and has slightly more lift on hit
⦁ 6BBA(B): has two more frames duration on the hitbox; can be transitioned into quickly
⦁ 6BBA(8B): added as 8B
⦁ 4B: hitbox appears 1 frame sooner
⦁ 4B(B): launches on hit, ends sooner
⦁ 4B(A): changed to be 6A
⦁ 2B: made strong
⦁ 2B(B): has more lift and ends sooner; hitbox appears and disappears one frame later
⦁ 8B: does 1 more damage; ends sooner; hitbox appears one frame later and disappears one frame earlier; hard knockdown
⦁ RB: duration changed, ends sooner
⦁ JB: given a better decent angle; more lift
⦁ 5A; charges in 14 frames from 27
⦁ 6A: releases bugs slightly sooner, hits 5 times instead of 3, more range
⦁ 4A: better counter window
⦁ A4A: recovers significantly faster, walking bugs are unblockable
⦁ 2A: comes out faster
⦁ 8A: comes out faster
⦁ RA: replaced with a set distance teleport
⦁ JA: has bugs come out one frame sooner and hits 5 times instead of 3
⦁ 5Y: is immune to mids and highs during the startup
⦁ 2Y: added; victim is immune to mids and highs until they are released
⦁ 5X: hitbox appears one frame sooner; one less frame of super freeze
⦁ 2X: bugs spawn faster, each hit does 1 more damage; slightly less lift


Tayuya:
⦁ All Doki Demon summons in strings are 6A; if holding 8 when it starts it will do 8A; holding 2 will do 2A; More ring combos are notated in strings
⦁ 3ME entry option replaced with vanilla GRKnJ
⦁ 5A, Act4A, JA, and 2X all stop projectiles while the hitboxes are active
⦁ Health: increased from 180 to 210
⦁ Guard: increased from 1440 to 1680
⦁ Grabbable Moves: 5A, JA
⦁ 5B: given more stun on hit and block; elbow hitbox appears on the second active frame
⦁ 5B(B): less disadvantage on block, move ends sooner
⦁ 5BBB(B): made into 6BB(B)
⦁ 5BBBB(B): sit on frame 7 and stand on 14 instead of sit 14 to the end; foot down GFX 14 frames later and the other foot down 4 frames after that; +2 damage
⦁ 5BBA(B): does 3 more damage, ends sooner, hard knockdown
⦁ 6BB(B): has 2 more frames of hitstun; +1 damage
⦁ 4B: stagger removed, does small bounce, hits closer to Tayuya, +2 guard frames, state flags better match the animation, ends earlier, can be grabbed
⦁ 2B: has more lift with adjusted hitbox times to better match the animation
⦁ 2B(B): lifts on block, ends sooner, adjusted frames and knockbacks
⦁ 8B: has the 2B(B) changes
⦁ 8B(B): transition window ends two frames sooner
⦁ 5A: charge time decreased from 19 to 9 frames, more lift on hit, last hit staggers, better on block, doesn't hit as far away (uncharged too); increased duration by one frame
⦁ 5A1C: does more damage; has slightly more endlag
⦁ 4A: counter window improved, doesn't slide backwards when guarding
⦁ A4A: is unblockable
⦁ 2A: now ends sooner
⦁ 2AX: is a string into 2X
⦁ RA: has defense frames and can be grabbed during airborne frames
⦁ JA: staggers on the last hit, slightly more gravity for Tayuya; first four hits don't move the opponent
⦁ 5X; requires 75% meter and has one more frame duration; damage increased to 50 from 40
⦁ 2X: duration decreased; two less super freeze frames; doesn't push on hit
⦁ GRKnJ: summons a 6A monster that hits for a small bounce; Tayuya teleports a bit further back, monster has intangibility up until around the hitbox appears
Doki Demons:
⦁ 6AA(A): floats higher
⦁ 2A: made strong
⦁ 8A: made strong; hitbox appears one frame later and disappears one frame sooner
⦁ 8A(A): made strong


Temari:
⦁ Grabbable Moves: 5A(A), 5AA(A), 2A, 8A, 8A(A), 8AA(A), JA
⦁ 5B: hitbox appears for 1 more frame; two frames more blockstun
⦁ 5BB(A): removed stagger and add chip damage
⦁ 5BBA(A): added stagger and chip
⦁ 5BBAA(A): is 2B(A); can hold 6 at startup to do 6A
⦁ 6B: given stagger, made weak on block from strong; ends 5 frames sooner; more lift
⦁ 6B(B): changes to 8B(B); 3 grabbable frames on the startup; made strong
⦁ 4B: guard frames extended from 1-18 to -22, ends earlier, more lift, grabbable; 7 frames less blockstun
⦁ 2B(A): replaced with 2A; follow ups adjusted to be in line with raw 2A
⦁ 2BB(A): increased in damage by 7
⦁ 8B(B): replaced by Act4A; has three grabbable frames at the startup; made strong
⦁ RB: ends about 12 frames sooner
⦁ JB: does 11 damage (from 16) and 11 block damage (from 16) but has the same guard stun; hitbox removed from head and butt; less lift
⦁ J2B: added with as a glide that can be cancelled early with Y which has A and B follow ups and always faces the opponent
⦁ 5A8: does 8A
⦁ 5AAX: is a new string
⦁ 6A: is an untechable bounce; does 7 more damage
⦁ 4A: window improved
⦁ A4A: is unblockable, can't be subbed or teched; made strong
⦁ 2A: in string ends sooner; transitions to A follow ups slower (same as raw 2A)
⦁ 8AAX: is a new string
⦁ JAX: is a new string
⦁ RA: hitbox duration increased by 1 frame, last three active frames are untechable, move is no longer immune to highs as she stands up
⦁ 5X: starts moving three frames sooner; drains all meter on miss or hit from Temari
⦁ GRKnJ: hitbox duration increased by one frame, travel time is one frame longer


TenTen:
⦁ New idle animation added
⦁ Health: increased from 185 to 205
⦁ Guard: increased from 1480 to 1640
⦁ Grabbable Moves: 5BB(A), 5BBB(A), 5AC(A), 5A2CA(A), 4A, 8A, RA, JA, JA(A), JAA(A), JAAA(A), JX, 8X
⦁ 5B: hand hitbox does not appear on the first frame; better advantage on block, more lift
⦁ 5B(B): appears and disappears a frame later, better advantage on block, more lift
⦁ 5BB(A): and 5BBB(A) are both 5BB(A), but 2A does 5BBB(A)
⦁ 5BBB(B): more lift
⦁ 6BB(B): does the spinning knockdown
⦁ 2B: sweeps
⦁ 2B(B): has more lift on hit
⦁ 2B(A): has less hitbox duration
⦁ 2BB(B): is an untechable bounce, pushes on block
⦁ 2BA(B): transition with B changed to be frames 32 (vanilla start) - 35 (when the second foot makes a dust cloud)
⦁ 8B: ends sooner and has more lift on hit
⦁ RB: made strong and pushes on block
⦁ JB: has one more frame active hitbox
⦁ 6A: Made a techable bounce and a high on the first frame only; the hitbox appears one frame sooner with slightly smaller hitboxes; stuns longer on non bounce hit
⦁ 6A(B): does 6B
⦁ 4A: activates automatically
⦁ A4A: does not high crush, can be grabbed
⦁ RA: can now be done at anytime during run and does not have to wait for a loop of the animation
⦁ JA: can transition faster; has forward or backwards momentum with 6 or 4
⦁ JA(A): can transition faster; has forward or backwards momentum with 6 or 4; knives do more damage
⦁ JAA(A): can transition faster; has forward or backwards momentum with 6 or 4; claws do more damage
⦁ JAAA(A): can transition faster; has forward or backwards momentum with 6 or 4; sickles do more damage
⦁ JAAAA(X): added as JX when having 75% meter
⦁ 5X: hitbox comes out two frames later and disappears one frame later, starts moving two frames earlier, bigger hitbox
⦁ 8X: does JX from the ground with modified momentum; requires and costs 75%
⦁ J6X: added where TenTen hops slightly forward before doing the super instead of slightly back
⦁ GRKnJ: moved further back; made a mid instead of a high


Tsunade:
⦁ Air Throw added; does modified ActJA
⦁ New walking animation added
⦁ Health: increased from 210 to 220
⦁ Guard:  increased 1680 to 1760
⦁ Grabbable moves: 2A
⦁ 5B: hitbox appears one frame sooner, elbow hitbox removed; hand hitbox larger on frame 2
⦁ 5B(B): can be hyuuga cancelled
⦁ 5BB(A): charge time reduced by 2; ends two frames sooner to match animation
⦁ 6B: stuns longer; hitboxes slightly larger
⦁ 2B(B): pushes back on block
⦁ 2BA(A): charge time reduced by 1
⦁ RB: first hitbox frame is a high, untechable bounce and second frame is a mid techable bounce; hitbox disappears one frame earlier
⦁ RB(A): has more lift on hit hitbox adjusted to not hit OTG
⦁ JB: landing hit has one more frame duration; grabbable; more stun
⦁ JA: is unblockable; has 10 frames super armor on startup, has forward or backwards momentum with 6 or 4; three frames less landing lag
⦁ 5A: hand hitbox does not appear on the first frame; slightly more lift
⦁ 5A(B): stuns longer; knee hitbox does not appear on the first frame; slightly more lift
⦁ 4A: window improved; works against projectiles
⦁ Act4A: comes out faster, unblockable, untechable, and unsubbable, teleports closer to opponent
⦁ 2A: cannot be teched
⦁ RA: made a hard knockdown; hitbox appears one frame later; elbow hitbox moved to waist; done in a combo is not a hard knockdown and is an instant guard break
⦁ ActJA: can be subbed later
⦁ 2Y: is a slam throw
⦁ 2X: activates without hitting someone
⦁ GRKnJ: replaced with 8A animation


Zabuza:
⦁ All non sword attacks do -2 damage (except 5B and 5B(B))
⦁ 5B: elbow hitbox does not show up on the first frame
⦁ 5B(B): appears and disappears one frame later
⦁ 5B(A): changed to be RA
⦁ 6B: turns back turned opponents around on hit
⦁ 5BBB(B): can be delayed
⦁ 2B: has less endlag, hitbox appears two frames later and disappears one frame later, pushes on block
⦁ 8B: has less endlag; transitions to A faster; more lift; can transition on whiff
⦁ JB: ground hit stuns longer; grabbable
⦁ 5A: hitbox appears one frame sooner as an untechable bounce as a high hit; frame 3 to the end does not bounce; hilt hitbox does not appear on the two frames
⦁ 5AAA follow ups changed:
	- A does vanilla; is a hard knockdown
	- 2A does vanilla B follow up
	- B follow up changed to be a custom 8A teleport
⦁ 6A: charge is faster, 1C breaks guard easier, other charges do less guard damage; 3C is a hard knockdown
⦁ 4A: window improved
⦁ A4A: teleports and recovers quicker
⦁ 2A: Lift reduced
⦁ 2AA: Added with B follow up
⦁ 8A: can be canceled before the teleport
⦁ JA: phantom sword works with both players; has one more active frame
⦁ J6A: added as a new move
⦁ 5Y: made overhead throw
⦁ 2Y: is slam throw
⦁ 4Y: is a blockable anti air command grab. Hard knockdown
⦁ 2X: is immune to highs and mids on startup, requires 75% meter, links better on air hits, damage reduced; hilt hitbox on first revolution is slightly bigger


Cosmetic:
Anko:
Second to last hit of 5X has kunai in her hand with the proper GFX

Chouji:
4A hand signs are removed when Chouji can no longer counter

Gaara:
4A hand sign put away on ending
2A fingers close after release of sand

Hinata:
Y cancel fingers adjusted

Iruka:
Y Cancel does the correct hand sign
4A hand sign is put away on ending or on activation

Jirobo:
8A ends properly at the end of the animation

Kabuto:
4A hand sign is put away on ending

Kakashi:
SAct4A on Iruka and Mizuki 5X hands fixed

Kiba:
4A hand sign is put away on ending

Kisame:
4A releases the sword two frames earlier

Mizuki:
Y Cancel makes appropriate hand sign
5X and 2X hands are fixed on the activator
4B GFX adjusted

Naruto (OTK):
Fixed a GFX glitch on Act4A
8A GFX and SFX adjusted on "landing" when blocked

Orochimaru:
2X ends properly at the end of the animation with the correct graphics

Sasuke:
8B GFX and SFX adjusted on "landing" when blocked
Air thrown animation added in properly

Sasuke (CS2):
Air thrown animation added in properly

Zabuza:
6A releases sword 3 frames later and opens hand

