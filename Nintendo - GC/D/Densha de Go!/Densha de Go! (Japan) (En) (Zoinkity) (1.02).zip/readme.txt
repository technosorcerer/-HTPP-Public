﻿Densha de Go! 64 Localization Patch v1.02 (2024)

  Densha de Go! 64 is one of many iterations of a train simulator found in arcades and across various consoles.  This patch translates the HUD and menus to English, leaving the Japanese voices intact.  It also supports the USA VRU, converting all the voice prompts for the voice recognition unit to locale-specific English.  The train controller and Rumble Pak are still supported, but additional Transfer Pak and 64DD bonus features have also been included.

  Patching information can be found at the (>^o^)>
  Notes on how the game is played can be found at {,`_`},
  Known issues and version notes can be found at the (_x.x)_

  Huge thanks to mikeryan for identifying and translating a boatload of images, as well as some excellent content suggestions!

  One thing that is only mentioned in the manual is that you can reset your save file on the title screen.
  Hold Z+B and press Start on controller one or press B+Select+Start on the train controller to bring up the save erase message.

  There are several Easter Eggs.  Try to catch them all!  I'm certain some will be revealed over time ;*)

+_+

  Voice Recognition Unit, a.k.a. "Easy Mode"

  Use a USA VRU.  The Japanese VRS is now incompatible.  This is not a bug.
  The VRU must be plugged into port four before you turn on the console.  The game only probes what's in the ports at boot, so you cannot plug new controllers in after starting the game and expect them to work.

  You get bonus points in arcade mode for calling out signals properly.  There's no detriment for missed signals or mucking them up.
  This is a real-life safety practice.  As signals are seen they are repeated out-loud by all crew.  It helps you remember the most recent signal, and makes it obvious if somebody missed the most recent one.  The voice you hear in the cab is calling out the signals per protocol, not telling you what to do as some claim.

  When run in PAL mode (either via a PAL console or bootloader) British pronunciations will be used instead of American ones.  So long as you speak somewhat like the samples found on the Cambridge English Dictionary's website you'll be good ;*)  Worst case, it is guaranteed to recognize those mp3s when played through your PC's audio out jack.  Seemed a nice touch since so many of you are train aficionados.
  In NTSC/MPAL mode, the VRU will use "standard" American English pronunciations.  If you're from Boston or Jersey I'm very sorry--plus you'll have some trouble using the VRU.  Bostonians might have some luck using the Brit ones though since they also seem to abhor the letter "R".

  Usage In-Game:
  The "Arcade Mode" label will indicate whether or not the voice recognition system is in use.  The first time the VRU is attached you may need to go into the options menu to activate the VRS features.
  Iron-chan will appear in the left column when you can call out a word, even when using the "Prompts Off" option.  "Prompts Off" only inhibits messages that appear in the left column, such as "depart", "passing", and "stopping".  You have five seconds to respond to the prompt.
  For the most part, you repeat the name of the signal that appears on the right.  The full list:
	"Proceed"
	"Express"
	"Stop"
	"Warning"
	"Stopping"
	"Passing"
	"Restricted"
	"Caution"
	"Reduced"
	"Restricted-Depart"
	"Caution-Depart"
	"Reduced-Depart"
	"Depart"
  
  When a speed limit is posted, say only the number part.  The full list:
	"One-Twenty-Five"
	"One-Twenty"
	"One-Fifteen"
	"One-Ten"
	"One-Oh-Five"
	"One-Hundred"
	"Ninety-Five"
	"Ninety"
	"Eighty-Five"
	"Eighty"
	"Seventy-Five"
	"Seventy"
	"Sixty-Five"
	"Sixty"
	"Fifty-Five"
	"Fifty"
	"Forty-Five"
	"Forty"
	"Thirty-Five"
	"Thirty"
	"Twenty-Five"
	"Twenty"
	"Fifteen"
	"Ten"
	"No-Limit"

  VRU Quirks (applies to all games)
  The recommended setup is to pass-through or split your microphone through a speaker so you can hear what the VRU/VRS recieves.  If you try this, you'll understand why a better microphone than the one that came with the VRU is recommended.  Why?  Well...

  The VRU/VRS hardware "trains" by averaging (among other things) the volume and noise of previous inputs.  If you accidentally blow into the microphone or shout into it, you'll find the next few inputs will be completely ignored.  The only ways to fix this is to reset the device or give it enough inputs to level back out.  Inputs are only read when a request is sent though.
  Densha de Go uses a different listening principle than Hey You Pikachu.  In Pikachu you activate and deactivate the device, so it get reset quite often.  Densha de Go, on the other hand, does this once and leaves it permanently on.  It isn't constantly listening, but it is constantly on and rarely reset.  Causing a communication error can force a reset, but reinitialization causes a noticable 1-2 second delay in-game.

+_+

Rumble Pak Support

  It isn't well known (because nobody reads manuals) but when a normal controller is used there is Rumble Pak support.
  Obviously the dedicated train controller doesn't have a rotor built-in, but you could wire a device or slot to it.  It's the same chip every other normal device uses.

+_+

Transfer Pak Support (Added!)

  As a bonus feature, arcade mode will try to detect if a Densha de Go! or Densha de Go! 2 Game Boy Color cartridge is in a Transfer Pak inserted in either controller slot 1 or 2.  If either game is found, all routes will be unlocked.  Due to the implementation, the transfer pak can be hotswapped without cycling the power.

  Transfer Paks can be finicky, so if it doesn't detect the game immediately you can backtrack to the main menus, adjust the pak and game, then re-enter arcade mode to retest.  No indication is given that the game is detected properly except all routes unlocking.  (To be fair it was a last-minute addition...)

  Only the game header is read, so it should be more widely compatible with GB/C flashcarts.  Incompatiblity with the Transfer Pak is directly related to power consumption.  If your flashcart uses an FPGA it likely consumes as much power as the entire rest of the GB all on its lonesome and will, maybe, get one or two good reads in before the Transfer Pak can't use it anymore.

+_+

64DD Support (Added!)

  As a bonus feature, different title screens will appear if you have a 64DD attached.  This feature also works with emulators that support the 64DD.
  Summercarts do support 64DD hardware emulation, including the clock.  At time of testing (2024.10.15) simply unlocking its registers won't make the clock available, a disk must be mounted.  Any disk.

+_+

PAL Support (Added!)

  The ROM is region-free and will switch to PAL video output when the console, emulator, or bootstrap provides the PAL flag.  Video output uses the VI scaling feature to stretch the output vertically, filling the screen.  Audio playback and in-game time though still use the PAL 50Hz clock as reference, so both will be slightly slower than NTSC.
  As mentioned before, British pronunciations are used by the VRU when PAL is detected.

+_+

HAL Printer Support & Screenshot Gallery (Added!)

  Screenshots can be taken during gameplay or on the stop evaluation screens when a flashcart is in use by pressing c-up on controller 2.  A mildly amusing voice will be heard.  These are saved to cartrom starting at 0x2000000; each image is a 320x240 c16 binary, 0x25800 bytes long.  If you take more than 218 pics, the list resets.
  You can rip them from the cart but this is rather obtuse.  As of patch version 1.02, a hidden gallery was added to the main menu.
  
  After taking screenshots, you can enter the gallery.  On the main menu, press c-up on controller 2.  It's a bit awkward, but controller 2 is used to control the gallery (controller input in this game is bonkers and this is riding on the debug interface).  The gallery always opens on the last image.
  Press any type of right or up on controller 2 to view the next image, and any type of left or down to view the previous one.  A, B, or Z will exit the menu.  Pressing Start...well, see below.
  
  Screenshots are only available when a flashcart is in use and addresses 12000000 through 13FE0000 are writable.  These are automatically set writable on 64drives and summercarts at boot.
  There's a known edge case where the screenshot will be incompletely drawn if the game is frameskipping too heavily.  That's what happens when you copy the framebuffer and it isn't completely drawn...  Normal gameplay is usually unaffected, but the graphic overlay for practice/training modes almost guarantees corruption.  The moments VRU input is evaluated are hit & miss.  For the most part though you'll get decent screenshots.


  The gallery also supports the HAL printer if found in controller 2's controller slot!
  This (useless) bonus feature lets you print saved screenshots from the gallery when you press the Start Button.
  Better known as the "Pokemon Print Station" printer (and only named "HAL printer" in a debug comment in a game that didn't use it), this is a video printer interface implemented as a controller slot device.  If a device with ID 0x85 is attached to the controller in slot 2 you will be able to print out saved screenshots instead of dumping the image data using a USB port.  Just like the Transfer Pak, you should be able to hotswap this device.
  
  Realistically, with how few people own a print station (and who knows how Lawson did their stickers) it's expected you're using a DIY device instead, and the cheapest and most readily available video printers nowadays (or at least the paper) are used for endoscopy.  These print fixed-width images in a strip, one at a time--ideal when the number of images is unknown.  There's no need for smartcards or any other form of economy, the setup doesn't need to be disabled at any point, nor is the typical system reset when the purchase is completely unnecessary.  To be fair, you could just reach over and press the print button yourself, there's no automation in the gallery after all...
  tl;dr: it's not compatible with an actual print station setup, only simpler DIY setups.

  The commands sent are structured around what's needed for my *own* setup, so unless you want to rewrite this you're stuck with what's below.  The image is already displayed so there's no need to insert additional delays for rendering.  Each image will be printed individually.  Some printers may not require saving the image to memory before printing if there's only one but mine does, just adapt your microcontroller to ignore the additional commands or something.  A command can be ignored by simply not sending the wait signal (08).

  It is assumed you're in single print mode.  When the user presses the Start Button, the following happens on the N64:
  1) The control block (address C000) is read until busy (8) is clear.
  2) Command 01 is sent to control to clear any stored images.
  3) Insert a delay of 200 cycles, then read if busy set.  Repeat as necessary.
  4) Command 02 is sent to control to store the image in memory.
  3) Insert a delay of 200 cycles, then read if busy set.  Repeat as necessary.
  4) Command 04 is sent to control to print the image.
  5) Insert a delay of 20 cycles, then read if busy set.  Repeat as necessary.  If everything is working correctly the register will only clear once the print job is complete.

  The microcontroller (or whatever) must minimally do this:
  *) If a block of 0x85 sent to address 8000, respond in kind and initialize the unit if necessary.  Technically, any other value should return zero as policy was to disguise the device IDs.  Minimum, it cannot return 0xFE or initialization will fail.
  *) Retrieve printer state and write 08 to address C000 during any operation to force the N64 to wait for completion.
  *) Send "monitor/erase" button code when command 01 received.
  *) Send "memory" button code when command 02 received--unless your printer only needs the "print" button for single pages, in which case you can return a 0 and skip this step.
  *) Send "print" button code when command 04 received.
  Remember that controller pak devices are asynchronous!

  Note that just like HAL's implementation (or really anything that HAL ever implemented) there's basically no error detection and it could, theoretically, wait forever under the wrong circumstances.  Works fine for me though ;*)

{,`_`},

How You Play

  Firstly: this is not a racing game!  The idea here is to operate a train on-schedule as it passes through and stops at stations.  You are expected to stop the train no more than a meter past the designated stopping position.  Typically you accelerate to a speed that ensures your arrival time, then coast most of the distance there while minding signals.  As signals are given you will need to adjust the train's speed to maintain the schedule.  Just as in actual trains, it will probably be helpful to have a pocketwatch handy to help calculate speeds and distances.

  You get bonus time for being on time, varying on difficulty level.  You also get time and stars for stopping at stations within centimeters of the target distance--and a gold if you do so at the correct arrival time.
  You also receive time for using your horn when about to cross a bridge, when entering most tunnels, when engineers are present trackside, and when wildlife is nearby.  You won't receive bonus time when the horn signal is given.
  If the voice recognition system is in use, a prompt will appear on the left side of the screen when a signal is sighted.  If you repeat the signal name into the device you will receive an additional point.  There is no penalty if a signal is not spoken.  See the section below about the voice unit for more details.

  You lose time for poor operation: overrunning stops, using the emergency brake outside of emergencies, hard braking, exceeding speed limits, failing to obey signals, ramming another train, etc.
  You also gradually lose time for each second you are late to a station.  You receive no bonus for arriving early.
  If you exceed the speed limit for too long, the automatic braking system kicks in and grinds you to a halt.  Most likely you will not be able to finish the route when this happens.

  Weather will affect the train's deceleration rate and stopping distance.  Each train has its own dynamics as well.  Several special events may occur during gameplay, usually on higher difficulties.

  After each route is complete you are graded on your performance.  High scores will net you a bronze, silver, or gold medal for the route.  Additional routes are unlocked when you obtain 16 bronze, 16 silver, and 16 gold medals.  All-clear is obtained when you attain 21 golds.

  The game is surprisingly easier to play when you maintain the schedule.  If you're running too early for too long, they slow your train down by posting a speed reduction.  Depending on your speed when this happens you may not be able to slow down in time to avoid a speeding penalty.

  There is an excellent in-game tutorial for first-time players.  It walks through all the gauges, explains most of the signals, and generally shows you how not to lose badly.  The tutorial is on-rails; any wrong presses are corrected, and all times are perfectly synchronized.
  Practice mode is a subset of routes--a mix of local and express--and gives you maximum bonus time.

+_+

Some Translation Notes

  The mascot's name is followed by an honorific (Iron-chan) not because I'm particularly anal about using them (I'm not) but because "Iron" a weird enough name that you probably wouldn't realize it +was+ a name unless it is either followed by an honorific or you happen to read the TL notes.  Clarity > style.

  From the beginning I was never going to touch the audio.  Ultimately these are Japanese trains filled with Japanese passengers traveling through Japan.  The only audio that isn't directly related to the train or its operation would be Iron-chan's dialog at the end of the game.  Those samples are shared with other train-related VO, so the only real option that doesn't involve mutilating existing audio is creating a new soundbank specifically for these 4-5 messages.  Can those messages be subtitled?  Yes, but would thanking you for playing really necessitate the hassle?

  Yes, the title screen says "Densha de Go", not "Let's Go By Train".  Do a Google-y search and see which one is more recognized in English-exclusive circles.

  The HUD is pretty busy, and as it is some messages overlap despite all efforts otherwise.  In general, most decisions (for better or worse) were made to maximize readability in tight spaces.  The standard here was if it was at least mostly legible on an 8" CRT screen.  If some glasses-wearing nerd can read the tiny train names on an 80's era 8" CRT you have absolutely nothing to complain about.
  "Express" was used instead of "High-Speed".  I prefer the later of the former, but both the HUD message and VRU entry just weren't working.  To be fair, the message only appears with express trains during their high-speed segments.  Encoding and detecting signal words did influence the final signal names, in particular the "depart" and "passing" messages.

  "セクション通過", lit. "Section Passed", refers to the unpowered segments of tracks between different electrical systems.  Japan uses a combination of DC and AC power at 50Hz and 60Hz.  Ideally you coast through these sections of track, and if you do so in-game you get a small bonus.  The message for this now reads "Safe [Electrical] Transition", mostly so you don't have to read some TL note to understand why they just threw some bonus points at you.
  This raises a point: don't rely entirely on the HUD.  The electrical transition signals will only be seen along the trackside; no indication on the HUD is given like in some other DdG titles.  You'll also notice there is a round sign indicating where the train should stop at the station.  Your environment can also give you clues about those nasty "speed traps".

  All of the messages present in the game were translated, but that doesn't mean that they were all triggered in-game.  Honestly, not sure if the coupling event before the ATC bonus game is present, but all its resources sure are.  Some definitely are never used, such as a range of prompt labels.  Sadly, the fancy "Voice Bonus" message probably isn't either.

  Care was taken to attempt to get all the names in the credits right.  It's basically impossible to know how to read somebody's name when written in Kanji; government forms require you +not+ write it that way, it's such a problem.  The default is to use the most common reading and hope for the best.  In this case, other works by the same company or with roughly similar readings were compared, crossreferenced by role to try to discern who is who.  Hopefully they're mostly correct, and apologies if they aren't.

(>^o^)>

Patching

  Only apply the patch to a Densha de Go! 64 ROM in native (big-endian) format.  Xdelta patches can be applied with the aptly-named xdelta patcher; use version 3.0.8 or up.  (In other words, one from the last decade.)  The final ROM will be somewhat smaller than the original-don't be too alarmed.
  
  For identification, your presumably self-dumped ROM should have checksums of:
Internal	17C54A614A83F2E7
MD5	772FA166E5DB51EFFC77FB8D832AC4D2
SHA512	1B19191C1B9AE83FA707FF966C4B9632D196857BF3FEFE58004E61348A599D667AE9D067CCBEE7F7F6BDF8E205780368FE2107ADFCA96DDB56D260289260D843

  The output file should have checksums of:
Internal	3F829BDF4DADCE40
MD5	5F2E0325EADAE819B8A32F77E073AB6C
SHA512	3C46496030D20F5EC9455374A9EA586A6E8FF3E05A2FC86B85F4E7AA88C409EEF4304E8A907B46E439E0431CA4A743FEBBF52F8174AE90DD678C0AEE79F2AA9D

(_x.x)_

Version History

  v1.02:	2024.10.15 (actually 2024.11.07)
  SHA512	3C46496030D20F5EC9455374A9EA586A6E8FF3E05A2FC86B85F4E7AA88C409EEF4304E8A907B46E439E0431CA4A743FEBBF52F8174AE90DD678C0AEE79F2AA9D
  *) Summercart is now fully supported and shares the same bonus features as 64drive.  That includes full debug access, screenshots, and holding its button for the doge title screen.  Note that using the memory reset code on this title screen accesses the Densha de Go!Go! title.  Additionally, in any 64DD mode that enables the clock the four seasonal title screens are used.
  *) Fixed message alignment for some conditional multi-part messages, like when you start stuck at a station or need to stop for another train.
  *) Fixed a couple images that sometimes--but not always--shared palettes.
  *) Localized the backdrops of several menus and the dozen or so images with backdrops embedded in them.
  *) Screenshots now use the opposing framebuffer.  They should always be completely drawn, but there's still an edge case when frameskipping...  Whatever, it's better than it was.
  *) Screenshot gallery added, including HAL printer support if device 0x85 found in port 2.  Since it lacks economy the setup is a little different than usual.  Read the "HAL Printer" section above for setup details.
  *) Technically the internal date is accurate to pre-gallery necessary fixes, not actual release, but thought an auspicious date more suitable.
  *) Purposefully revealed in the version history more hidden nifty things ;*)

  v1.01:	2017.04.17
  SHA512	E6FC45C96D1DA22B25FEA2B708CCF269E80DBA0397E3E7D9BBB5C863E70E4BA61A5E786BCE4D626FBF052FFD76A672EC771BF8C5B12416998F08C30E67E27D2C
  *) Circumvented a permanent loop specific to Everdrive64 version 3 devices.
  *) Fixed typo on Uragawara route "flippy sign thingy".
  *) Build date now displays properly in the debug menu.
  *) Screenshots can be taken during gameplay or on the stop evaluation screens when a flashcart is in use by pressing c-up on the in-game debug interface.  These are saved to cartrom starting at 0x2000000; each image is a 320x240 c16 binary, 0x25800 bytes long.  If you take more than 218 pics, new ones overwrite the oldest.
  *) Purposefully revealed in the version history two of the hidden nifty things ;*)

  v1.00:	2017.04.01
  SHA512	1B19191C1B9AE83FA707FF966C4B9632D196857BF3FEFE58004E61348A599D667AE9D067CCBEE7F7F6BDF8E205780368FE2107ADFCA96DDB56D260289260D843
  *) Initial release.

Known Issues

*) The title screen will probably not appear if you are using a SCART cable, in this mod or in the original game.  If your SCART setup cannot handle enhanced-definition signals it most likely will not display the title screen.
*) The title screen can also cause issues with TV that are picky about input, such as variable-output CRTs that use the first signal to determine what mode to display in.  This is especially a problem in PAL mode, since VI scaling will probably be generating too many lines.
*) There's also a bug within the N64 that causes short segments of erroneous data specifically with large interlaced images.  You may notice odd half-fields of reversed image data on the title screen as a result.  The video glitch is sporadic and uncorrectable in software.
*) Screenshots are incompletely drawn when the game frameskips too heavily.
*) Using a GameShark/Pro Action Replay will not work and, more than likely, will crash the game at boot.  This includes the support found in Everdrives.  Codes still work in emulators however, since they operate on a different principle.  That's entirely intentional, but there are other ways to cheat if you're so inclined ;*)

Wish List, in order of impracticality

*) Reversing the PC version to add in the final incomplete route.
*) Aleck64 port.
*) Printing your score as a ticket via GB Printer.

+_+

Running

  This patch is designed to be run on the 64drive, Summercarts, Everdrive64, and in most modern emulators.  Piracy is a criminal act and measures have been taken to troll those who burn this to a cartridge.  I suggest if you plan on doing that to have a no-returns policy ;*)

  To make something clear:
  It's possible to make a patch within the limits of the law,
  but reproducing and distributing something you don't own is piracy.

  The game can be played in its entirety with just a standard controller.

  64drive, Summercarts, and ED64s should work without any additional complication.  Use 16k eeprom and a 5167 CIC.  * You may need to manually set this!
  Summercart will work through a bootloader (menus or normal "upload" USB method), direct mode is not recommended.
  64drive & summercart have (minor) additional features unique to them!

  Emulation from the 1.02 patch onward is largely untested.  If it runs on console, emulators will (eventually) catch up.
  If you're having problems with a specific emulator, refer to its documentation and whatever support the developers provide.  I'm afraid I can't even run a fair number of them, much less give you any advice.
  
  Bug reports for console however--missing sound, torn images (besides screenshots), crashes & hangs--can be reported to nefariousdogooder@yahoo.com

-Zoinkity
