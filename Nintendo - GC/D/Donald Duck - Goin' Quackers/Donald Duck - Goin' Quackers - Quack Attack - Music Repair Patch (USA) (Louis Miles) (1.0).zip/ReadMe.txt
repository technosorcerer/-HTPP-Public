========================================================
Goin Quackers/Quack Attack N64 - Music Repair Patch v1.0
========================================================

Repairs the faulty midi music so that it sounds as intended by the composer!

The music was supposed to be a midi arrangement of the PC/Dreamcast version's music with a different style, even with exclusive songs, but due to extremely flawed conversion and subsequent "editing" of the midis and instruments by the developers, arguably one of the most flawed soundtracks in video game history was created.

Until now, because all these mistakes and botches have now been painstakingly corrected and repaired!


---------
Features:
---------

-Every midi has been carefully repaired, with countless inaudible notes now audible.
-All instrument samples are now played correctly and at the correct pitch
-All incorrect values in the sound bank, such as release values, have been correctly adjusted
-All reverb values from each midi have been adjusted correctly and improved.
-All incorrect sounding effects have been repaired
-Various sound bugs, glitches and other oddities have been fixed


------------------------------------
High quality rips can be heard here:
------------------------------------

All in one video with some info:
https://youtu.be/Ipm1PVvkvdE?si=Da4xms92Yc5mD2RV

Playlist:
https://www.youtube.com/playlist?list=PLO4jlmGoc6uAUWM_hR6zraa5qljOt3gEv


------------------
Patch Instructions
------------------

- Be sure that your ROM is not byteswapped. You can check and fix this with this online tool: https://hack64.net/tools/swapper.php

- Get the patcher tool Floating IPS (Flips) (at least version 1.31). (Link: https://www.smwcentral.net/?a=details&id=11474&p=section)

- Open "flips.exe" and click the "Apply Patch" button.

- Select "EU-QuackAttackFIX" if you have the European version, or "US_GoinQuackersFIX" if you have the American version.

- Find your copy of the Donald Duck ROM and select it.

- A final window will open. Select a place where you want to save the repaired rom and press the "Save" button on the window.

- A new ROM file should have been created in the directory you chosed.

- Enjoy!


TIPP: There are also online patchers that do the same, such as this one: https://www.smwcentral.net/?p=onlinetools&tool=bps



---------------
Additional info
---------------

-This patch does not change anything in the actual gameplay, only the audio. This means that the game can be used for speedrunning with or without the patch

-Also works with the MiSTer FPGA core


-------------
Emulator Info
-------------

There is a known emulator issue (has nothing to do with this patch; happens with the original too) that happens with some emulators, where the game softlocks when you speak to someone, which is required to unlock levels.
You can fix this as follows:


Project64:
-In settings/config set "Counter Factor" to 3. This makes the framerate worse, so you might want to do it temporary only to talk to the nephews. 1 is for best framerate. Restart the game for it to take effect.

Wii64/Not64:
-Set CPU Clock Divider to 3. This makes the framerate worse, so you might want to do it temporary only to talk to the nephews. 2 is better framerate
-Not64 Plays the game smoother than Wii64

Mupen64plus (Simple64 version) and Ares do not seem to have this problem, but seem to play the game not so smooth


I could not find a fix for Parallel Launcher (v7.7.0) and RetroArch general. Other emulators have not been tested. 



--------------
Special Thanks
--------------

-SubDrag, Ice Mario and Zoinkity: For their helpful N64 bank editors and Midi import and export tools!
-CarlaVST Dev Team: For their helpful modular audio plugin host!
-Tom Szilagyi: For his Reverb Plugin with which I was able to recreate a reverb very close to that of In-Game!
-Cakewalk Community: For help and tipps!
-Derek "Turtle" Roe: For converting the patch to the US Version and for testing!
-Anterag/RingsOfGeonosis: For Feedback!
-L.Spiro: For some info and tipps about reverb!