Dinomod Enhanced Patch

This patch includes Dinomod 2.4 with fully restored Sabre.
It adds various new bugfixes and improvements to the game.

Changelog:

- Text referencing Star Fox reverted to mention Sabre/Planet Animus.
- Enabled Subtitles when Rocky teaches Tricky's Distract Command.
- Enabled Cape Claw Sharpclaw Cutscene.
- Temporary Cape Claw Log Fix. (This is the most important one for me) :3
- Diamond Bay "Another Spellstone" Cutscene Crash Fix.
- Enabled VFPT Spellstone 2 Placement.
- Golden Plains Shrine Fix. (No longer auto teleports to Diamond Bay)
- Golden Plains Teleporter Fix. (To Test of Knowledge Shrine)
- Walled City Moon Pressure Pad Fix.
- Enabled Walled City King Earthwalker Cutscene after obtaining Spellstone.
- Walled City Moon/Sun Side Doors Fix.
- Enabled Walled City Teleporter. (Replaces Duster on top of the temple)
- Blackwater Canyon Log Hard Crash Fix.
- Enabled Blue Snowhorn in Northern Wastes
- Lightfoot Village Log Fix
- Sabre Breath Misalignment Fix
- Cape Claw Test of Character Shrine Fix (Obtain Spirit after defeating clone)
- Golden Plains Bonfire + Better DFPT Spellstone Fix
- Enabled Moon Seeds after DFPT.
- Walled City Loaded State Patch.
- Walled City Sun/Moon Pressure Switch Crash Fix.
- Removed Swapstone Hollow to Walled City Invisible Barrier.
- Removed Swapstone Hollow to Willow Grove Invisible Barrier.
- Darkice Mines Cogwheels Bridge Fix.
- Darkice Mines Invisible Keyholes Fix.
- Darkice Mines Pressure Switch Crash Fix.
- Test of Fear Shrine Guardclaw no longer blocks the way.
- VFPT Spellstone 1 can be placed and disappears from inventory.
- Snowhorn Wastes Name Display Fix.
- Sabre Small Foodbag Available in Store.
- Enabled Cape Claw Shrine Teleporter (When you get Krazoa Tablet)
- Enabled Krazoa Tablet Cutscene when moving from BWC to Discovery Falls.
- Enabled Warlock Mountain Randorn Cutscene with Sabre.
- Horn of Truth Item Description Fix.
- Treasure Chest Key Name Fix.
- Queen Earthwalker 10 White Mushrooms Quest Partial Fix.

Update 2022-04-24:

Removed:

- Walled City Pressure Pad Fix (Had a chance of crashing)
- Darkice Mines Pressure Pad Fix (Had a chance of crashing)
- Discovery Falls Krazoa Tablet Cutscene (Wasn't supposed to be in the patch)
- Partial Queen Earthwalker 10 White Mushrooms Fix.
- Get Moon Seeds after DFPT Patch.

Added:

- Diamond Bay River Falling Rocks Crash Fix.
- Diamond Bay Cave Noise Crash Fix.
- Swapstone Hollow Replace Nearby Duster with Log (To reach Diamond Bay).
- Cape Claw Respawning Kyte Prison Cell Sharpclaw Fix.
- Walled City Sun/Moon Temple Bridge Temporary Fix.
- Moon Mountain Pass Bridge Temporary Fix.
- Enabled Walled City Music Upon Entering.
- Enabled Discovery Falls Music Upon Entering.
- Disabled Moon Mountain Pass Shrine Guardclaw Collision.
- Enabled Swapstone Circle Lightfoot Cloudrunner Fortress Key.
- Queen Earthwalker 10 White Mushrooms Needed.
- Warlock Mountain Warp Crystal Memory Corruption Fix.
- Increased Save File Size (No More Items Disappearing from Inventory)
- Volcano Force Point Temple 2nd Spellstone Visit Fixed.
- Placing the 2nd Spellstone gives you a Moon Seed.
- Swapstone Circle Leaf Texture Fix. (Thanks to MusicalProgrammer)
- Warlock Mountain 3rd Spirit Skeetlas Cutscene Fix.
- Enabled Warlock Mountain 3rd Spirit Placement.
- Warlock Mountain 3rd Spirit Opens Walled City Sun/Moon Doors.

Update 2022-04-26:

- Removed "Beware of the mines" Text after Galadon Fight.
- Cloudrunner Fortress Treasure Chest Key Memory Corruption Fix.
- Swapstone Circle Leaf Texture Fix now works on Real Hardware.
- Cape Claw Guardclaw Music Doesn't Play in Fortress.
- Removed Walled City Stray Duster on top of the Wall.
- Removed Sundial Object in Willow Grove to allow access to Dragon Rock.

(Most fixes were created/shared by Jeebs2kx on the DP Discord)
(Sabre's facial animations were reconstructed by MusicalProgrammer)
(Dinomod was created by nuggs)
(Ren Fuchsfein put this xdelta patch together)

Apply this xdelta patch to "rom_crack.z64".

Have fun!

Some Helpful Advice for a broken puzzle:

In Darkice Mines, after the short speeder section you land on a conveyor belt 
with flames. And Tricky is separated from you.

He is supposed to be locked inside a prison cell right next to Belina Te.
But currently this puzzle is broken.

To make Tricky spawn inside the prison cell and avoid problems later in the dungeon
you should save and then reload your game once you left the conveyor belt.
You can do this as soon as the normal Darkice Mines music starts playing.

Several people reported being unable to fight Galadon, the boss of Darkice Mines.
This little workaround helps until we found a way to fix this properly.