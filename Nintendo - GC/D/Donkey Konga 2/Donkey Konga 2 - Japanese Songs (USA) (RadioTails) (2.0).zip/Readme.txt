   Name: DONKEY KONGA 2 (JAPAN)
Console: Nintendo GameCube
Version: 2.0

Original ISO Info (USA):
    -  Name: Donkey Konga 2
    -   MD5: 583506969AB42C376309946EBC3F1E40
    - SHA-1: 0DD09785CCF7EA60B112DCF916FF5D1FC19D9D6D

Original ISO Info (JPN):
    -  Name: Donkey Konga 2: Hit Song Parade
    -   MD5: 34E4135C7E887F2E8BD8D05E07BE4A86
    - SHA-1: 22BD6425C9D69A18A888F80707DD7FF937678F38

-------------------------------------------------------------------------------------------------

Credits:

  Modder:
    - RadioTails

  Translation:
    - Pepsi-man

-------------------------------------------------------------------------------------------------

About ROM Hack

  This hack imports all the songs from the Japanese version of Donkey Konga 2 into the 
  USA version of Donkey Konga 2.

  For those wondering why they don’t just play the Japanese version, well that version
  has the following issues:
    - All the text will be in Japanese, making it difficult to navigate through the menus
      for those who don’t speak the language.
    - You have to use a Japanese/Korean GameCube/Wii (or use a modified console/software
      that can use the Japanese GameCube BIOS) to save the game.
    - The Jam mode from the first Donkey Konga was reused. This mode wasn’t that fun
      because all the notes are hidden, and you have to remember which ones to hit.
      The international versions replace this with the improved Beat-Mix mode, where
      the notes are randomized each time.

  A few improvements have also been made:
    - Changed the Game ID from “GY2E” to “G2JE”. A new save file will be created, and
      your original “GY2E” will not be affected.
    - The Sound Sets from the first Donkey Konga game will display by default. Before,
      you needed to have a USA save file of Donkey Konga saved on the same Memory Card,
      and that Sound Set must have also been bought from the first Donkey Konga. 
    - All the Sound Sets have been swapped to use more interesting ones from the
      Donkey Konga series.
    - Made improvements to the English text.  
    - The date format for the High Scores has been updated to use: Month/Day/Year
    - The European font is used to use the better letters: “ ‘
    - The European graphic title is used.

  Future updates:
    - Update all 100 of Dixie’s Notes to reflect any changes.
    - Translate the Debug Menu text into English.
    - Change texture and position of the "Song Number" in Challenge to be the
      same as the European version.
    - Move the "NEW" icon graphic so it doesn't appear in font of the "Player" text.
    - Restore the "Red B Arrow" (used to tell the player that pressing Left and Right
      on the DK Bongos acts like the B Button).
 
-------------------------------------------------------------------------------------------------

Required Files/Tools

  You will need to obtain the following GameCube ISO files:
    - Donkey Konga 2 (USA).iso
    - Donkey Konga 2: Hit Song Parade (Japan).iso

  If you own both copies of the game, use CleanRip (https://wiibrew.org/wiki/CleanRip) to
  make the 1.4GB ISO backups. Alternatively, you can download them from the Internet.

  These will need to be in the 1.4GB ISO format. To reduce the size, downloads from the
  Internet are usually in the RVZ or NKIT format. Check the following links on how to
  convert to ISO:
    - RVZ to ISO (https://www.youtube.com/watch?v=08JE-XC2kvQ)
    - NKIT to ISO (https://www.partitionwizard.com/partitionmanager/convert-nkit-to-iso.html)

  You will need to download the following tools (these only work on Windows):
    - gcr_v1.0 - https://www.romhacking.net/utilities/619/
    - GCMUtility - https://www.gamebrew.org/wiki/GCMUtility_Wii
    - Wiped GCM Fixer - https://www.zophar.net/utilities/gamecube/wiped-gcm-fixer.html
    - xdeltaUI - https://www.romhacking.net/utilities/598/

-------------------------------------------------------------------------------------------------

Patching Instructions:

  To make things easier, the "Donkey Konga 2 (Japan Version) - G2JE01" folder will be
  referred to as the "main" folder.

   1 - Open: gcr_v1.0.exe
   2 - Click: Image > Open...
   3 - Open: Donkey Konga 2 (USA).iso
   4 - Right click: root 
   5 - Click: Export...
   6 - Select folder: main
   7 - Click: OK
   8 - Click: Image > Close
   9 - Close "Success" message.
  10 - Close: gcr_v1.0.exe

  11 - Go to: main > root > stream > score
  12 - Delete all the ".dsp" files.

  13 - Open: gcr_v1.0.exe
  14 - Click: Options > Modify system files
  15 - Click: Options > Do not use 'game.toc'
  16 - Click: Root > Open...
  17 - Select folder: main > root
  18 - Click: OK  
  19 - Click: Root > Save...
  20 - In the main folder, save as: USA No Songs.iso
  21 - Click: Root > Rebuild
  22 - Close "Success" message.
  23 - Click: Root > Close
  24 - Close: gcr_v1.0.exe

  25 - Open: GCMUtility.exe
  26 - Click: Add ISO
  27 - Open: USA No Songs.iso
  28 - Tick the box next to the banner.
  29 - Click: Shrink
  30 - In the main folder, save as: DK2 US.gcm
  31 - Close: GCMUtility.exe

  32 - Delete file: USA No Songs.iso
  33 - Delete folder: root

  34 - Open: xdeltaUI.exe
  35 - Click: Open... (next to Patch:)
  36 - Open: Donkey Konga 2 (Japan) - V2,0.xdelta
  37 - Click: Open... (next to Source File:)
  38 - Open: DK2 US.gcm
  39 - Click: ... (next to Output File:)
  40 - Save as: DK2 JP.gcm
  41 - Click: Patch
  42 - Close: xdeltaUI.exe

  43 - Delete file: DK2 US.gcm

  44 - Open: Wiped GCM Fixer GUI.exe
  45 - Click: File > Open Image
  46 - Open: DK2 JP.gcm
  47 - Click to convert file: 1.4 GB Image
  48 - This will create a file called: DK2JP~1_fstfix.GCM
  49 - Rename that file to: Donkey Konga 2 (Japan) No Songs.iso

  50 - Delete file: DK2 JP.gcm

  51 - Open: gcr_v1.0.exe
  52 - Click: Image > Open...
  53 - Open: Donkey Konga 2 (Japan) No Songs.iso
  54 - Right click: root 
  55 - Click: Export...
  56 - Select folder: main
  57 - Click: OK
  58 - Close "Success" message.
  59 - Click: Image > Close
  60 - Close: gcr_v1.0.exe

  61 - Delete file: Donkey Konga 2 (Japan) No Songs.iso

  62 - Open: gcr_v1.0.exe
  63 - Click: Image > Open...
  64 - Open: Donkey Konga 2: Hit Song Parade (Japan).iso
  65 - Double click on folder: stream 
  66 - Click on folder: score
  67 - Right click on folder: score 
  68 - Click: Export...
  69 - Select folder: main > root > stream
  70 - Click: OK
  71 - Close "Success" message.
  72 - Click: Image > Close
  73 - Close: gcr_v1.0.exe

  74 - Go to folder: main > root > stream > score
  75 - Delete folder: CVS

  76 - Open: gcr_v1.0.exe
  77 - Click: Options > Modify system files
  78 - Click: Options > Do not use 'game.toc'
  79 - Click: Root > Open...
  80 - Select folder: main > root
  81 - Click: OK  
  82 - Click: Root > Save...
  83 - In the main folder, save as: Donkey Konga 2 (Japan).iso
  84 - Click: Root > Rebuild
  85 - Close "Success" message.
  86 - Click: Root > Close
  87 - Close: gcr_v1.0.exe

  88 - Open: MD5_SHA-1 Utility.exe
  89 - Click: Browse
  90 - Open: Donkey Konga 2 (Japan).iso
  91 - Check the MD5 and SHA-1 match the following:
	   -   MD5: BCB419930A3C4CFA00265DF077350A45
	   - SHA-1: 0B5F630DD6C73F83BB19358DF2E63E37408B0EF2
  87 - Close: MD5_SHA-1 Utility.exe

-------------------------------------------------------------------------------------------------

Using the DK Bongos/GameCube Controllers

  You must use an Official GameCube Controller Wii U Adapter, or a MAYFLASH GameCube Adapter
  (one that has a Wii U| PC toggle on the back) to use DK Bongos/GameCube Controllers on
  Dolphin Emulator (see this guide on setting up: https://www.youtube.com/watch?v=hvRzdaLKDls),
  or Nintendo Wii U (just make sure the toggle on the back is set to: Wii U)

  If playing on the Nintendo Wii, make sure it has GameCube controller support. Also, when
  using nintendodont, make sure that Native Controls are set to ON in the Settings. If this is
  set to OFF, the DK Bongos will not work.

-------------------------------------------------------------------------------------------------

FAQ (Frequently Asked Questions)

  Q: Will my original USA Save (GY2E) be affected if I play this hack?

  A: Don’t worry, I have changed the game ID to “G2JE”, so a separate USA Save will be
     created. You original USA Save file will not be affected.


  Q: Will the save file from Version 1.0 be compatible?

  A: Yes, the save file from Version 1.0 will still work. The actual order of the song data
     is the same, but I modify the visual order to match the Japanese version.  


  Q: Will this work on real hardware?

  A: This hack will work perfectly fine on a GameCube/Wii.


  Q: Do I have to use the DK Bongos?

  A: You can either play with the DK Bongos or the GameCube Controllers.

-------------------------------------------------------------------------------------------------

Version History

  V2.0:
    - The genre for each song is displayed on the song panels.
    - The correct colors are used for the song panels.
    - The songs appear in the same order as the Japanese version.
    - The volume balance plays “Donkey Konga Theme” song.
    - Replaced the DK Bongos graphic to have the Green A pointing to the START button.
    - Using the ASCII font from the European version of Donkey Konga 2. 
    - The High Score board uses the follow format for the dates: M/D/Y 
    - The Sound Sets from the first Donkey Konga are unlocked automatically, and replaced
      with the following:
	 o Quiz
	 o Electric Drums
	 o Mario
	 o Konga Crew
	 o Toy
	 o Dogs
	 o Space Lasers
	 o Ding
	 o Barnyard
	 o Cats
	 o Jungle
	 o Kirby
	 o Alarms
	 o Horns
	 o Country
	 o Gong
	 o Latin Percussion
	 o Zelda

  V1.0:
    - All 33 songs from the Japan version of Donkey Konga 2 have been inserted.
    - Changed the Game ID to (creates a different save to the original game): G2JE
    - Save file name changed to: Donkey Konga 2 (US) 
    - Replaced the title screen with the EU one.
    - Replaced the Drum Sets you buy from the Shop:
	 o Smash Bros.
	 o Drums
	 o Western
	 o Sea Mammals
	 o Star Fox
	 o Birds
	 o Pac-Man
	 o Disc Jockey
	 o Tambourine
	 o Starfy
	 o Dinosaurs
	 o Triple Bongos
	 o R.B.I. Baseball
	 o Pikmin
	 o Monkeys
	 o Samba