1. Open your game ISO using GCRebuilder (supplied with the hack download)
2. Expand the folder called "Common"
3. Right-click the file called "USATxt.dat" and click Import 
4. Navigate to the USAtxt.dat file supplied with the hack and click Open 
5. After "Done" appears click Save Changes in GCREbuilder 
6. Load the Nightfire ISO in Dolphin, Nintendont on your Wii/Wii U, or modded Gamecube.