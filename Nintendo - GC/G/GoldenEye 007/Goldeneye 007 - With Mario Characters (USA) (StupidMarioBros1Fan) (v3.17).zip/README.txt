Created by StupidMarioBros1Fan with help from Graslu00, Carnivorous, Sogun, Subdrag, Wreck and Kode-Z. More info down below & in the Game's Credits.

Tested on Emulator and Console by both StupidMarioBros1Fan and Graslu00.

v3 Changelog included in download as a lot of stuff has been fixed, improved & changed.

Rebuilt with Carnivorous' Footsteps Patch.

This a Free, Non-Profit fan made Mod, Any & All Reproduction Carts are Unofficial.

Installation:

Use the GoldenEye Setup Editor or XDelta UI and apply the proper XDelta file to a clean GoldenEye 007 (NTSC-U) ROM
Download XDelta UI - web.archive.org/web/20170523022132/files.catbox.moe/immoym.zip
Download the GESetup Editor - github.com/carnivoroussociety/GoldEditor

Description:

This mod replaces all of the characters with ones from the Mario universe along with edited Dialog to make more sense with the characters, however the story itself is mainly the same as the original. Some minor changes have been made to the Levels to work better with the characters, as well as incorporate scrapped and/or new content. More details and changes are explained in the Changelog.

Characters:
James Bond -> Mario Mario
Natayla Simonova -> Peach Toadstool
Alec Trevelyan -> Luigi Mario
Xenia Onnatop -> Daisy
Arkady Ourumov -> Bowser Koopa
Boris Grishenko -> Yoshi
Dimitri Mishkin -> Donkey Kong
Valentin Zukovsky -> Wario
May Day -> Pauline, 
Oddjob -> Toad
Jaws -> Waluigi
Baron Samedi -> Rainbow Bowser, the Powered-Up version of Bowser from Super Mario 64.
M -> Rosalina
Q -> Professor Egad
Moneypenny -> Toadette
Jack Wade -> Toadsworth

Soldiers/Civilians/Scients -> Koopa Troopas
Heads are now different expressions to make use of the Random Head system, which has been replaced with the improved version from Goldfinger 64. This change allows multiple groups of Heads as well as lets Female Koopas have more than 1 Random Head loaded in a mission.

Mishkin/Donkey Kong is no longer the Defense Minister, that role now goes to May Day/Pauline with Donkey Kong being the Head of Special Forces. This was done to give Pauline a role in the story, as well as explain why the "Great Guards" use DK's body.

Dr Doak is now Oddjob/Toad to give him some sort of role in the story, as a result the idea of Toad "blending in" with the other scientists is ridiculous.

In-Game Credits go into more detail but here are the important ones:

Custom Model Edits & Vertex Coloring by StupidMarioBros1Fan
Models imported into Game by StupidMarioBros1Fan
Height & Ground Offset by StupidMarioBros1Fan
Bounding Boxes by StupidMarioBros1Fan
Custom POV for Single Player by Carnivorous & StupidMarioBros1Fan
Custom POV for Mulitplayer by StupidMarioBros1Fan
Custom Animations by StupidMarioBros1Fan
Custom Portrait Pictures by StupidMarioBros1Fan
Lighting Fixes for First-Person Models by Carnivorous
Rendering Fixes by Carnivorous
Level & Text Edits by StupidMarioBros1Fan
Level & Character Pictures by StupidMarioBros1Fan
Silver & Gold PP7 Pickup Models ported from GoldenEye X by StupidMarioBros1Fan
Testing on Actual Hardware by Graslu00 & StupidMarioBros1Fan
SM64 Multiplayer Maps & Level Pictures originally by Sogun, ported by StupidMarioBros1Fan
Some GE XBLA Multiplayer Maps recreated by StupidMarioBros1Fan
Some GE: Source Multiplayer Maps recreated by StupidMarioBros1Fan
Surface 1 X Custom Music by Kode-Z
2019 Luigi Custom Model for Super Mario 64 by Cjes, and CyberTanuki with Special Thanks to Dudaw, Flotonic and Subdrag


HUGE Thanks to:

Graslu for Help, Testing and Advice
Carnivorous for Help, Advice, and the Footsteps Patch
Zoinkity for the GE Documentation on GitHub, and the 7MB Expansion Pack
Wreck for Help, Advice, Tutorials, and some stuff with the Memory Peek/Poke function
SubDrag for the Setup Editor, Help, Advice, and sharing Zoinkity's Patch for Goldfinger 64's Random Head System
Sogun for the Multiplayer Maps and Advice
Kode-Z for making the Custom Music
Everyone involved with the Development of the Original Game
Everyone involved with the Development of GE X
Everyone involved with the Development of GE XBLA
Everyone involved with the Development of GE: Source
The GoldenEye Modding Community


Links to check out:

n64vault.com - for more GoldenEye 007 & Perfect Dark mods as well as other N64 games
youTube.com/StupidMarioBros1Fan - My YouTube channel for mods of multiple games
youTube.com/Graslu00 - Graslu00's channel for videos on various GE007 & PD mods
youTube.com/MusicAl1250 - Kode-Z's channel for videos of GE007 & non-GE007 music
http://www.shootersforever.com/forums_message_boards/ - GE007/PD Modding Forums

Notes:

As a result of most characters being resized to have the guns to look bigger in their hands, a lot of characters run slowly in Single Player. The levels have been edited to combat this, usually by making them run instead of walk, but in general characters move slower. Multiplayer is completely fine, all characters move at normal speed due to being controlled by players.

Train on 00 Agent has been rebalanced to be easier to complete, more info in Changelog.

For Multiplayer: Various characters have a lot of textures, while nothing should Freeze or Crash during a Match, expect frame drops especially if playing with 4 players and/or playing on the bigger Maps.

There are a couple of Minor Bugs that you should know about so make sure to check out the included Text File.



All Previous Versions are included in the Download.