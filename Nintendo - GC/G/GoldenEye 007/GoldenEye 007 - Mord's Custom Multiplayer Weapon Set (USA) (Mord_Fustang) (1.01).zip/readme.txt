Mord's Multiplayer Weapon Set for Goldeneye 64 (v1.01)

April 18, 2019 - v1.0
July 13, 2019 - v1.01 (fixed AR33 weapon image)

Custom weapon set if you want something different to play with with your friends.  Not a Klobb in sight!

Made with Goldeneye Setup Editor.  Thanks to the makers of this fantastic editor.

ROM to patch:

GoldenEye 007 (U) [!].z64
CRC32: B6330846
MD5: 70C525880240C1E838B8B1BE35666C3B
SHA-1: ABE01E4AEB033B6C0836819F549C791B26CFDE83

After patching:

GoldenEye 007 (U) - Mord's Weapon Set.z64:
CRC32: C1564A45
SHA-1: F39E07664CE0AC494242AF41773DEE2BFC43EF1B
MD5: C6C188216E8AE3F0B255F02964BF8970

GoldenEye 007 (U) - Mord's Weapon Set X.z64:
CRC32: EEDA2C5E
SHA-1: A229113D10416607B09E62E8F68AC1961D5E8DAE
MD5: FCF1A40085FB4E793B06E5CEE4B022D1

---

There are 2 patches to choose from:

Mord's Weapon Set:

-Only the Multiplayer default weapon set has been changed.

Mord's Weapon Set X:

-Weapon set has been changed
-All multiplayer levels are unlocked by default and playable with up to 4 players.
-All multiplayer characters unlocked.
-Stack and Basement have been replaced with Statue and Cradle.  If you didn't know, Statue and Cradle are in the original game's code as fully playable multiplayer maps, but only accessible with a cheat device like a Gameshark.

Includes .bps patches (to be used with "beat") and .xdelta patches (to be used with Goldeneye Setup Editor).

Tested with Project64 & Everdrive 64 2.5.


---

Weapon Set List:

Remote Mines Only:

x8 Remote Mines

Mix 1:

x2 Phantom
x2 RCP 90
x2 Laser
x1 Silver PP7
x1 Gold PP7


Mix 2 (Golden Gun Remix):

x2 RCP-90
x2 Lasers
x2 Remote Mines
x1 Silver PP7
x1 Golden Gun


Rifles & SMGs:

x1 AR33
x1 D5K
x1 D5K Silenced
x1 Phantom
x1 ZMG
x1 KF7
x1 Sniper Rifle
x1 RCP-90


Phantom & Remote Mines:

x4 Phantom
x4 Remote Mines


All Explosives:

x2 Rocket Launcher
x2 Grenade Launcher
x1 Grenades
x1 Timed Mines
x1 Remote Mines
x1 Proximity Mines


Launchers & Remote Mines:

x3 Rocket Launchers
x3 Grenade Launchers
x2 Remote Mines


Mines only:

x3 Timed Mines
x3 Remote Mines
x2 Proximity Mines

  
Shotguns/RC-P90/Remote Mines:

x2 Shotgun
x2 RC-P90
x2 Auto Shotgun
x2 Remote Mines


PP7s only:

x2 Silenced PP7
x3 PP7
x2 Silver PP7
x1 Gold PP7


Shotguns:

x4 Shotgun
x4 Auto Shotgun


Non Multiplayer Weapons (guns that are not available normally in MP):

x2 Hunting Knives
x2 D5K Silenced
x2 Shotgun
x2 Phantom


Knives + Taser:

x3 Hunting Knives
x3 Throwing Knives
x2 Taser


Tank rounds only! (only 1 round per ammo spawn point, try this on License to Kill!):

x8 Tank rounds

---

Enjoy!!