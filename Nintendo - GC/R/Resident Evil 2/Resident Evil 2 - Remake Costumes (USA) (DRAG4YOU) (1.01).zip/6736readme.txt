 
  RE 2 Remake Costumes Mod v1.0

  Section 1 "What is this mod?"
  Section 2 "How to install it"


  Section 1 
  What is this mod?

  This is a mod that replaces the original clothes from RE 2 to the Komizo
  ones. Pretty much a cosmetic mod.

  Note: I have permission to upload this mod from Komizo.


  Section 2
  How to install it:
  
  To install this mod you will need
  - GCRebuilder v1.1
  - Resident Evil 2 .iso
 
  For this tutorial I will explain how to install it with GCRebuilder
  
 - First you need to open your RE 2 .iso file from the "Image" tab, 
   then right click on the "root" option with the disc symbol and 
   export it to a folder. (Note: Not the "Root" tab, the "root" option).
  
 - Once you have that done copy the "PI0" and "PI1" folders from the
   RE 2 Remake Costumes.zip into the "root" folder you extracted and replace
   the files in there.

 - Then go back to GCRebuilder and open your root folder from the "Root"
   tab. Then go to the "Options" tab and click on "Modify system files". 
   When that is done it will show a blue checkmark next to it.

   This is very important because if you don't do that it will not rebuild
   correctly.

 - Now, go to the "Root" tab and click on "Save..." to name it. It can be
   named whatever you want it to be. Then click "save" in your folder of 
   choice.

 - Finally, go to the "Root" tab and click "Rebuild".
 

  Note:

 - If someone can make a patch for this mod i would greatly 
   appreciated.


  Known issues:

- Haven't find any yet.
 