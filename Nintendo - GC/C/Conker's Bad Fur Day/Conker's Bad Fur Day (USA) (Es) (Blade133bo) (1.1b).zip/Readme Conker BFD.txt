Cambios de la versi�n 1.1
Se agrego la fuente, (Todo el merito es de Mairtrus)
Peque�os retoques de contexto y ortografia.
Faltar�a editar los gr�ficos, pero hasta que desarrollen un descompresor y compresor especifico nada m�s puedo hacer.
Si quieren descargar un retexturado de conker de la siguiente pagina. (aun en desarrollo)
http://www.emutalk.net/threads/54704-CONKER-BFD-Retexture-%28Started-recently%29

Enlace texturas: No pienso hacer otras, al no hacer falta.
https://www.dropbox.com/sh/pkvsbd2j3rimhid/AACan1sQWF7dB-R7MGQivju9a

Utilidades usadas.
Universal N64 Compressor (subdrag)
Translhextion
ROM REQUERIDA
Name   : Conker's Bad Fur Day (U) [!].z64
CRC-32 : CE8CC172
MD5    : 00E2920665F2329B95797A7EAABC2390
SHA-1  : 4CBADD3C4E0729DEC46AF64AD018050EADA4F47A

El modo historia es una adaptaci�n de "Conker: Live & Reloaded"
por lo cual me tomo poco tiempo.
el multiplayer traducido. (su mayor parte)
Cualquier error grave reportarlo "blade133bo@gmail.com"

El parche pueden aplicarlo con Xdelta ui http://www.romhacking.net/utilities/598/

Como siempre, no llueve igual para todos, sois libres de usar el original si esta version no os gusta.
Saludos.