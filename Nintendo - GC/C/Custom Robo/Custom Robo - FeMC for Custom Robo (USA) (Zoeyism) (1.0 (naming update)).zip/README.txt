Hi there! The total mod has a fair number of files, but the installation is not too complicated. You will need only three things:
	1. The Mod Files, obviously
	2. The Custom Robo rom file (I am using the USA/NTSC version of the rom, but it shouldn't matter)
	3. GameCube Rebuilder, AKA GCRebuilder (or Dolphin, I have not used Dolphin to open up/change files before, but it should also work)

GCRebuilder can be found on the ROMHacking website at https://www.romhacking.net/utilities/619/ and was very helpful for developing this mod.

Step 1: Open the Custom Robo ROM in Gamecube Rebuilder.  
	a. Make a spare copy of your ROM file to overwrite. Then, in GCRebuilder, go to the Image section and click "Open". Find your ROM file
	   location, and open the file. (If you don't see it, change the extension that the software is looking for from .iso to .gcm or vice versa)

Step 2: Import Updated Player Model Files
	a. For the Trish model update, there are 3 files to import. In GCRebuilder, go to the folder "scenario_us",
	   right click rpg_f_models.BIN, click Import, and then select the "rpg_f_models basic_overwrite.BIN" file to import it.
	   A pop-up should appear saying DONE, click OK to continue.
	b. Repeat the steps above for "rpg_t_models.BIN", and "snr_chara.BIN".

	c. OPTIONAL: If you want to change Ray 01 to be Athena's model, overwrite chara.BIN in the main directory with the same file
		     in the "Ray 01 to Athena Change" folder. Does not change animations/stats, and is slightly janky, but fully works.

Step 3: Import Updated Dialogue Files
	a. There are a significant number of files to import, unfortunately. In the same folder as from Step 2 ("scenario_us"),
	   import all of the provided BMG files (in the "She-Her Pronouns Update" folder). Be careful not to overwrite the snr_f files 
	   with the snr_t files, or vice-versa; it shouldn't let you do so in most cases, but still, be careful.

	   NOTE: There are less files given than there are in the folder, that is normal as the
	   remaining BMG files are unrelated or unaffected by the changes. There should be a total of 43 files to update.

Step 4: Import Updated Voice File
	a. Navigate to the "sound" folder. Scroll down to SNR_SE.ssm; right click the file, select import, and use the 
	   "SNR_SE.ssm" file in the "Femme Voice Update" folder. 

Step 5: Import Player Portrait File
	a. Navigate to the "sprite" folder, right click the "us_scenario.tpl" file, select import, and replace with the 
	   "us_scenario.tpl" file in the "Trish Player Portrait Update" folder.

Step 6: Save and Exit
	a. Click on "Save changes" in the bottom left, and you should be all set from there. Enjoy!