#!/bin/bash

if [ -d "root" ]; then
   echo "Please remove the \"root\" folder."
   exit
fi

if [ -f "$1" ]; then
  echo "Welcome to the Pikmin 2 Multiplayer Edition linux installer!"
  echo "Extracting Pikmin 2 iso...(Close WineConsole when its not blank)"
  wineconsole gcr.exe $1 root e .
  echo "iso extracted.."
  chmod -R o+rw root
  echo "What version of Pikmin 2 is this?"
  select choice in US PAL LandsOfTorture
  do
  case $choice in
  "US")
  cp -f ./Patch/pikis.szs* ./root/user/Kando/piki/pikis.szs
  cp -f ./Patch/Start.dol* "./root/&&systemdata/Start.dol"
  break
  ;;
  "PAL")
  cp -f ./Patch/Start_pal.dol* "./root/&&systemdata/Start.dol"
  cp -f ./Patch/ISO_pal.hdr* "./root/&&systemdata/ISO.hdr"
  cp -f ./Patch/pikis.szs* ./root/user/Kando/piki/pikis.szs
  break
  ;;
  "LandsOfTorture")
  cp -f ./Patch/Start.dol* "./root/&&systemdata/Start.dol"
  cp -f ./Patch/pikis_lot.szs* ./root/user/Kando/pikis.szs
  break
  ;;
  esac
  done
  cp -f ./Patch/wife.bti* ./root/wife.bti
  cp -f ./Patch/opening.bnr* ./root/opening.bnr
  cp -f ./Patch/arc.szs* ./root/user/Kando/map/forest/arc.szs
  cp -f ./Patch/res_ground.szs* ./root/new_screen/eng/res_ground.szs
  cp -f ./Patch/res_groun3.szs* ./root/new_screen/eng/res_groun3.szs
  cp -f ./Patch/res_groun4.szs* ./root/new_screen/eng/res_groun4.szs
  cp -f ./Patch/res_cave.szs* ./root/new_screen/eng/res_cave.szs
  cp -f ./Patch/res_cav3.szs* ./root/new_screen/eng/res_cav3.szs
  cp -f ./Patch/res_cav4.szs* ./root/new_screen/eng/res_cav4.szs
  cp -f ./Patch/res_challenge_3p.szs* ./root/new_screen/eng/res_challenge_3p.szs
  cp -f ./Patch/res_challenge_4p.szs* ./root/new_screen/eng/res_challenge_4p.szs
  cp -f ./Patch/play1.ini* ./root/thp/play1.ini
  cp -f ./Patch/play1.ini* ./root/thp/play2.ini
  cp -f ./Patch/play1.ini* ./root/thp/play3.ini
  cp -f ./Patch/play1.ini* ./root/thp/play4.ini
  cp -f ./Patch/play1.ini* ./root/thp/play5.ini
  cp -f ./Patch/play1.ini* ./root/thp/play6.ini
  cp -f ./Patch/caveCameraParms.txt* ./root/user/Nishimura/Camera/caveCameraParms.txt
  cp -f ./Patch/groundCameraParms.txt* ./root/user/Nishimura/Camera/groundCameraParms.txt

  echo "Now building new iso...(Close WineConsole when its not blank)"
  wineconsole gcr.exe root Pikmin2_4player.iso
  rm -r ./root
  echo "done! :)"
  read
else
  echo "Pikmin 2 iso file not found. Please run the sh with a Pikmin 2 iso in the arguments."
  read
fi
