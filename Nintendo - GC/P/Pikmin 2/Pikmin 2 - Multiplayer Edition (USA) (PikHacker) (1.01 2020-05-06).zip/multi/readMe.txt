Version 1.01
Pikmin 2 Multiplayer Editon
-Made by PikHacker

To get an iso of this romhack, simply drag a Pikmin 2 .iso file onto the included .bat file.
While creating the patch, it will ask what version of the game you gave it.
Also make sure that the iso file you patch is moved to the same folder as this patcher.
Note that as of now, it is only compatible with the gamecube version of Pikmin 2.

The supported Pikmin 2 versions at the moment are:
Pikmin 2 US
Pikmin 2 PAL
Pikmin 2: Lands of Torture (Made by Quote Balrog)
(Yes I'm aware theres no 251 support, that will come in the future most likely)

After this the installer will patch the iso with all the needed custom files.
It will then output a file called pikmin2_4player.iso, which you can use to play the hack.

Once you've patched an iso, you're ready to go! The hack is fully compatible with 
dolphin or real hardware using homebrew tools such as Nintendont.
You can play with other people via Netplay or Parsec, or just play with actual people irl of course.

Make sure you have NO other gecko codes enabled, as they won't work with this hack
unless they're made for USA Demo 1. Even still, they may conflict with my code, so its best to not use them.

Before the title screen is a menu with a few options:
Player changes how many players are in the game, 2 3 or 4.
Punching Mode makes it so captains can punch each other for a small amount of damage.
Console Viewports fixes an issue where viewports are positioned strangely in Dolphin. Enable this option only if playing on console.
Begin takes you to the title screen.

In game, things should all be fully functional for all players.
The percentage in the corner of each players screen is their life.
Note that all players share a spray count.
All players can navigate most menus past file select.
Note that the best I could do is make it work in a sort of priority system, if player 1 is pressing no buttons,
read player 2s input, if they aren't pressing any buttons, read player 3s input, and so on.
Also in order to adjust zoom in the pause map, you will have to hold down another button as well unless you're player 4.

One issue that I was not able to fix after nearly a week of trying is the volume of sound effects,
so they are still only based on the position of player 1 for now, hopefully I can fix this in a future
update to the hack.

As for side modes, challenge mode is fully functional. In fact, it skips over choosing the player count on
the menu, as that is set already. Note that I didn't bother doing much of anything for 2 player challenge 
mode, since you're better off using the normal game for that.
For now, due to how complicated it would be to make, versus mode has been disabled. This may be added in the future,
but in my opinion a 4 player versus mode is more suited to be its own full hack instead.

A final disclaimer that there are a LOT of factors that go into making this hack work perfectly, ESPECIALLY
regarding captains dying. I've made it so everyone is alive at full life at the start of each cave floor to
reduce these problems. Additionally, the dayend cutscenes when captains dying is involved is one of riskiest
areas of the game, so while there should be no crashes I can't guarentee 100% some really specific situation I
wasn't aware of could exist and make a crash happen. If you do run into any problems, please let me know on discord.
This is a link to my pikmin hacking server: https://discord.gg/WHSaSS5

Full Credits:

Yoshifirebird: Helped initially getting 2 new viewports to load, helped make lighting, particle effects, and other things work in 4 viewports.
mr brocoli: First to make 4 playable captains load at once, helped make all players fill in the radar map.
Kai: Created the Olimars wife model for player 4.
KIRBYMIMI: Helped brocoli and Yoshifirebird with some miscellaneous coding for the things they did.
Yoshi2: Creator of the Pikmin 2 C-kit that makes this hack possible.
People who helped playtest the hack: Ambrosia, Pat277, Untitled-1, Kai, Minty Meeo, mr brocoli, Jerry, Rhea, Quote Balrog.