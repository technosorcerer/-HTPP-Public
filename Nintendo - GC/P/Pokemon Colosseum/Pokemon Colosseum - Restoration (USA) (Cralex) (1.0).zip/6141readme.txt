Pok�mon Colosseum Restoration
Version 1.0
By Cralex

The goal of this patch is to restore various changes made to the US version of Pokemon Colosseum from the Japanese Version. In order to work, use an Xdelta patcher program to apply one of the included patches to a clean, untrimmed ISO of the US version. Two patches are included:

Changes in the �Restored Title� Patch
* Restores the title screen from the Japanese version. (The Japanese title screen features a wall made of sandstone dramatically rising from the desert that is painted with the Japanese name of the game in black and red, and the English title �Pokemon Colosseum� below it in white.)
* Un-Censors Rui�s outfit on the title screen, cutscenes, world map, walking around, and when she sees a shadow Pokemon.

Changes in the �Localized Title� Patch
* Uses the default US title screen, where the camera pans through some ruins in the desert and the blue and yellow �Pokemon� logo appears in a flash of light, followed by the word �Colosseum� in red beneath it.
* Un-Censors Rui�s outfit on the title screen, cutscenes, world map, walking around, and when she sees a shadow Pokemon.

As of version 1.0, the following changes have NOT been made in either patch:
* Blue Nintendo Logo (The logo when the game starts is Red in the US version, and blue in the Japanese version. I did not bother with this change since it�s such a minor thing, but I may include it in a later version if there�s demand.)
* Japanese Demo Movie (The Japanese version of the first video that plays if you sit on the Title screen has a sequence showing a battle, with Japanese text, plus some walking around in different environments. Rui�s outfit is technically visible in the walking segments, but because of the Japanese text in the battle segments I skipped replacing the movie.
* E-Reader Room (The Japanese version has a room that lets you scan compatible E-Reader cards to access extra content.) According to https://tcrf.net/Pok�mon_Colosseum , this room is technically functional in the US game if you are able to access it, but it�s partly untranslated. But because this feature requires both a Japanese e-Reader and the accompanying cards, and because I lack the knowledge of how to translate and restore the room, I have made no attempt to do so.)

Tools Used:
This modification would not be possible without Colosseum Tool by StarsMomodu (@StarsMmd), an all-in one tool for hacking Colosseum available for Mac and in beta forWindows. (There's also a version avaliable for Pokemon XD.) If you are at all interested in hacking Gamecube Pokemon Games or if you want to take advantage of a variety of useful and interesting game patches. be sure to check out this tool! The release page is at https://projectpokemon.org/home/files/file/2463-gale-of-darkness-tool-osx-colosseum-tool/

As a novice at GameCube modding, I also made use of GameCube Rebuilder by BSV (bsv798@gmail.com) to help me include the Japanese title screen, since the file is larger than the US one. I downloaded it from http://www.romhacking.net/utilities/619/

Technical Information:
Many of the files on the game disc have the .fsys extension. These are all archives that contain the actual files needed to run the game. Replacing the US ones with ones from the Japanese game work to an extent, but you're likely to replace other things that you don't want to change, such as dialogue data or part of the text drawing system. (Or you could just crash the game.) Instead, you should extract them and replace only the specific files you need.

For the Japanese title screen, my tests showed that simply replacing the �title� file as-is works with no ill effects, although it is larger than the US one which complicates the importing process somewhat. It may be possible to trim it down if not all of the contents are used, but I got a little tired of working on this project. :) Maybe in a later version.

For Rui, the relevant files are in different places, because she has multiple models used for different situations. Her internal name is Hizuki, so anything with that name is referring to her.
* "title" contains her picture used on the title screen (t_vs_c4.gtx.png)
* "M1_out" contains her model and graphics for when you first release her from the bag.
* "field_common" contains her model and graphics for walking around following the player.
* "pkx_hizuki" contains her model and graphics for when she sees a Shadow Pok�mon in battle.
* �world_map� contains her model and graphics for riding in Wes� bike.

Rui�s also has another model elsewhere (people_common?) but it�s unused in the final game, and actually unchanged from the original Japanese. Either way, the .png files in the .fsys archives define the texture applied to her models, and the other files define the form of her models. Both needed to be swapped out to match her Japanese appearance.

There are various game patches available in Colosseum Tool (see above) but I have not tested them for compatibility with this project. Most likely, I�m guessing they would work, especially with the Localized Title version.

Checksums:

Unpatched ISO
CRC32: 0704554F
MD5: E3F389DC5662B9F941769E370195EC90
SHA-1: 96B2B686D202A13DD15261FB7CFFBCB2F08C0A77

After "Restored Title" is applied:
CRC32: 3AFB027E
MD5: 1B8A55C09293927D0988E07C7B5E6EC5
SHA-1:  A17C73370740D76DBBA71D0B482BC25CE68AB35E

After "Localized Title" is applied:
CRC32: 70BF5970
MD5: C33F16F9FF237FA9AB9FF939C49A17DE
SHA-1: 301322F01B9C2452A8743C528ABFC7376050369C 