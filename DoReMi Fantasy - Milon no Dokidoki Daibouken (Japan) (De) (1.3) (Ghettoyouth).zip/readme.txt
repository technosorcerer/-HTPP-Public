DoReMi Fantasy : Milon's Quest - version 1.3 (05.10.2019)
---------------------------------------------------------------------
�bersetzung (Englisch->Deutsch): Ghettoyouth
�bersetzung (Neuer Abspann): Ice Man
ASM: Jonny
Betatester: Ice Man, Agi, Nibbler und meine wenigkeit  (>_>) 

Japanisch->Englisch:
by Gaijin Productions of CTC
Romhacker & Script Editor - recluse
Main Translator - Rom aka Unicorn
Early Translation - Musashi
Item Menu Translator - Faraday
Beta Testers - Farbanti & Balaraddak

Version 1.3 (05.10.2019)
------------------------
Neuer Abspann hinzugef�gt

Version 1.2 (19.11.2018)
------------------------
Kleines Update

Version 1.1 (9.11.2018)
------------------------
Code aktualisiert und neuer Intro-Bildschirm

Version 1.0 (27.08.2007)
------------------------
Sollte keine Bugs enthalten. Falls doch bitte �ber Romhacking.net bescheidsagen!
Empfohlene Emulatoren: BSNES, Snes9x und Zsnes.

�ber das Spiel
--------------
Do-Re-Mi Fantasy: Milon's Abenteuer ist die Fortsetzung 
zu Milon's Secret Castle f�r den NES.
Ja, der niedliche kleine Milon ist zur�ck!
Diesesmal mit der Power des SNES. Das spiel macht viel
Spass, k�nnte f�r erfahrene Gamer auch ein bisschen einfach sein.

Von dem Spiel gibt es nur eine ROM, also sollte es mit dem pactchen keine Probleme geben.
Name der ROM: Do-Re-Mi Fantasy - Milon no Dokidoki Daibouken (J).smc

Was ist fertig
--------------
-Alle Item beschreibungen
-Alle Dialoge
-Alle Mini Games
-...eigentlich alles ^_^

Dank geht an Jonny f�rs Dekomprimieren der Grafiken :)
Nun viel Spass beim Spielen!

P.S.
ROM anfragen werden ignoriert! Google ist euer freund.

