Switchblade II (Atari Lynx)
Traducción al Español v1.0 (25/09/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking contiene el cargador de Harry Dodgson.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Switchblade II (USA, Europe).lnx
MD5: 4971dd8b47d3475dc8d31b5325c14459
SHA1: 256d55e8e9478c53e340321c858df6710a9f69a6
CRC32: 13657705
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --