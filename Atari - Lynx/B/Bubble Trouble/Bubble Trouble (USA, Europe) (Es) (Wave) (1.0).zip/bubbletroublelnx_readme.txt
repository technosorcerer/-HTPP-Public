Bubble Trouble (Atari Lynx)
Traducción al Español v1.0 (02/10/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking contiene el cargador de Harry Dodgson.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bubble Trouble (USA, Europe).lnx
MD5: 90841f8fed54862f8a8750ddf212eb84
SHA1: cb9f78ffb02216979a03abb66301e4d3a8f01bfe
CRC32: 333daece
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --