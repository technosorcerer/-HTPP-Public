Dinolympics (Atari Lynx)
Traducción al Español v1.0 (30/10/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking contiene el cargador de Harry Dodgson.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dinolympics (USA, Europe).lnx
MD5: 9496be61fd0675553f05345c5fc2d15c
SHA1: 0dad2286934c6a317407db066f00233c27f54bbe
CRC32: 50386cfa
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --