Kung Food (Atari Lynx)
Traducción al Español v1.0 (03/07/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking contiene el cargador de Harry Dodgson.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Kung Food (USA, Europe).lnx
MD5: e5e42190918847b8c6056e78316ee91d
SHA1: ae1bd18b30dd9ae67472c4c532f4d65d23324555
CRC32: cd1bd405
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --