//////////////////////////////////////////////////////////////////////
*           
*           |      |  |------|  |\   |  |------  \     /
*           |\    /|  |      |  | \  |  |         \   /
*			| \  / |  |      |  |  \ |  |------    \ /
*			|  \/  |  |------|  |	\|  |------     | 
*
*
*           -----  ------\  |------|  |
*             |    |     |  |      |  |
*             |    |     |  |      |  |
*             |    |     |  |      |  |
*           -----  ------/  |------|  |------
*           
*           
*           |------  \  /  |------|  |      |     o     |\   |  |------ |------  /------↑
*           |         \/   |         |      |    / \    | \  |  |       |        |      /
*           |------   /\   |         |------|   -----   |  \ |  |   --- |------  |------|
*           |------  /  \  |------|  |      |  /     \  |   \|  |-----| |------  |       \  (Neo-Geo)
*            
*          ______________________________________
*		    
*           Parche de Money Idol Exchanger (v. 1.0) 100% en español
*           
*           by Her-Saki.
*
*           15/01/2017.
*
*           Parchar miexchng.zip (ROMs 231-p1.bin y 231-s1.bin).
*
*           Jugar (¿qué más?).
*
*           Esta versión aplica a todas las versiones del juego, tanto en AES como en MVS, se recomienda no jugar la versión de Asia/Europa (demasiado genérica), y utilizar
*
*           en cambio la versión americana (genérica/recortada pero no tanto como la europea).
*
*           Se recomienda también usar Final Burn Alpha (mejor aún, el emulador contenido en la plataforma Fightcade).
*
*           Cualquier duda o queja o carta a documento (o si quieres colaborar en este u otros curryliciosos proyectos) puedes mandarla a hersakiarc@gmail.com.
*             
*           Money Idol Exchanger (c) 1997 by Face.
*           
*           Traducción (c) 2017 by Saki.
*
*           Mantén este parche y todos los parches lejos de la rom para que sigan siendo libres y gratis...
*
//////////////////////////////////////////////////////////////////////