Language patch (text only)
Language: Dutch

--------------------------
dr1_prg7 (Dangerous Seed, Arcade)
--------------------------

Vertaling naar het Nederlands
Versie: 1.0
Datum: 29/07/2019
(c) 2019 Kana Translations

--------------------------
Opmerkingen bij deze patch
--------------------------
Deze vertaling en hack is geheel oorspronkelijk.

--------------------------
Patch-instructies
--------------------------
De patch heeft de IPS-indeling, en kan worden toegpast
met LunarIPS of Floating IPS.

--------------------------
Spelinformatie
--------------------------
Gebruikt oorspronkelijk bronbestand:
Title: Dangerous Seed (MAME 0.78/MAME 2003 - FBA 2012)
  
Patch only the file(s) below
File:dr1_prg7.bin
MD5: 2eb84dbb3e13ce1c11e6d3195a01ad4f
SHA1: a08ca7ac0c36c8f06f516bbfb9f541b77e53e864
CRC32: d7d2f653
131072 bytes

--------------------------
Dankwoord/Credits
--------------------------
Kana - Nederlandse vertaling en hack

--------------------------
Very special thanks
--------------------------
Wave - voor het briljante programma Hextractor, website:
traduccioneswave.blogspot.com

== Source inlcuded ==
I have included the source files.

-- EINDE --