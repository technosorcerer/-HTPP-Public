To patch the game, you need a patcher called "beat". After you download it, follow these steps:

 - First, click on "Apply Patch".

 - Then, choose the BPM file.

 - Choose the folder with the game's ROMs.

 - Create a folder for the new patched ROMs, and choose it.

If a message saying "Patch application was successful" pops, voila! You can play this on MAME now!