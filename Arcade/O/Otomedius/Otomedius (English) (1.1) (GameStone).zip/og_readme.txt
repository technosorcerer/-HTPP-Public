====================================================================================================

GameStones Otomedius AC English Translation - Changelog

  OOO    TTTTT    OOO     MM MM     EEEE   DDDD    IIIII   U   U    SSSSS
 O   O     T     O   O    MM MM    EE      D   D     I     U   U   SS
 O   O     T     O   O    M M M     EEEE   D   D     I     U   U     SS
 O   O     T     O   O    M   M    EE      D   D     I     U   U       SS
  OOO      T      OOO    MM   MM    EEEE   DDDD    IIIII    UUU    SSSSS

Otomedius - Arcade (c) Konami Digital Entertainment Co., Ltd. - 2007-2008
オトメディウス - アーケード - (c) 株式会社コナミデジタルエンタテインメント

The arcade release will not store your progression as it uses the e-amusement network which you will
not have access too, this is more of a demo and a proof of concept to show that I can translate a
game.

The best way to play Otomedius is to buy Otomedius Gorgeous on the Xbox360, this is a more complete
game that has the original Arcade mode and the newer much improved widescreen Gorgeous mode.

v1.0 - 12th May 2016

====================================================================================================

  This is a quest to translate Otomedius into English, all the GUI, text and menus.

  The speech and intro tune will not be translated, this is difficult as you would need voice actors
  and would sound crap anyway.

  Some of the text is not stored as images and would require hacking the otomedius.exe file, this is
  beyond my ability so this may not be translated.


-Disclaimer-----------------------------------------------------------------------------------------

  This translation is fan made and is in no way connected to Konami.


  ***IMPORTANT NOTE***

  These files are for the Arcade release - GGG-J-A-A-2008041801 (18th April 2008).

  They will NOT work with the initial release - GGG-J-A-A-2007092100 (21st September 2007).

  Always Backup your original files before you start messing around and replacing files.

  See the changelog at the bottom for all the update details.


=Information========================================================================================

-GGG-J-A-A-2007092100 (21st September 2007)---------------------------------------------------------

  There are a few releases of this game in the arcade and it's also been updated a number a times.

  This is the release you would get from a fresh install of the game from the three CD's on your
  original arcade hardware.

  The game software originally came on three compact discs (CDs).

-System Disc----------------------------------------------------------------------------------------

  Contains windows XP Embedded, 

  GGG-JA-A01 2007-05-15 0

  システムディスク
  System Disc

  PN 111793420000
  GGG
  JA
  A01

-Application Disc 1---------------------------------------------------------------------------------

  Contains the program files for the game.

  GGG-JA-A02 2007-09-25 0
  アプリケーションディスク　１
  Application Disc 1

  PN 111793460000
  GGG
  JA
  A02

-Application Disc 2---------------------------------------------------------------------------------

  Contains all the data files (Music, SoundFX and Graphics) files.

  GGG-JA-A03 2007-09-25 0

  アプリケーションディスク　２
  Application Disc 2

  PN 111793990000
  GGG
  JA
  A03


-GGG-J-A-A-2008041801 (18th April 2008)-------------------------------------------------------------

  This is the last version and the version number used in the Xbox 360 release, this updated version
  adds three new characters and lots of other tweaks, note that this does not include Easter Island
  or the last two extra characters (Esmeralda and Coon Poini)

  This translation patch is for this release of the game and will not work with the initial release
  or the extra Easter Island release due to some files that changed.


=How to play========================================================================================

  Make sure you have an E:\ and an F:\ drive on your system, you can get away with just F:\ but no
  bookeeping info will be recorded, if you haven't got a harddrive with that drive letter you can
  use two pen drives or two ramdisks.

  The original arcade game runs on a rather modest PC running Windows XP Embedded x86 (32bit).

  Developed, fully tested and working on Windows 7 x64 and x86 (32 and 64 bit system).

  Note: - The game doesn't work on Windows 10 at all.

  1.  To play with the translated files, simply overwrite the files in the game directory.

  2.  bms_GGG.exe must be running before you start the game.

  3.  If you want to play the Versus Missions you will need e-amuemu.exe (not included), also add
      this line to your HOSTS file.

      127.0.0.1 services.eamuse.konami.fun

  3.  boot.bat to run the game.

-System and Player Comtrols-------------------------------------------------------------------------

     F6             Test

     F7             Insert Coin

     A              Start

     Cursor Up      Moves the Player Up
     Cursor Down    Moves the Player Down
     Cursor Left    Moves the Player Left
     Cursor Right   Moves the Player Right

     Z              Power Up

     X              Shoot

     C              Burst Attack


=Error List=========================================================================================

  Do not set FREE PLAY in the MAIN MENU or the game will crashes on startup.
  
  If nvmem on E: and  F: are from an older release of the game or have become currupt the game will
  lockup on the 'NOW INITIALIZING' screen, delete GGG and nvmem directories on E: and nvmem on the
  F: drive and restart the game again.

-Application Error - 5-1600-1080--------------------------------------------------------------------

  Misc Error.

-File Is Corrupt - 5-1504-0000----------------------------------------------------------------------

  Files have been tampered with, files cannot be modified or you will get this error.

  ファイルが壊れています
  5-1504-0000

  File is Corrupt
  5-1504-0000

-IO Board Error - 5-1500-0014-----------------------------------------------------------------------

  If you don't have an E: or F: hard drive.

  I/O基板エラー
  5-1500-0014

  I/O Board Error
  5-1500-0014

-System Boot Error - 7-1000-0000--------------------------------------------------------------------

  The program bms_GGG.exe is not running, this needs to be running or the game will give this error.

  システム起動エラー
  7-1000-0000

  System Boot Error
  7-1000-0000

-Unable to communicate with the Center Server - 2-2002-1013-----------------------------------------

  This error comes up when there are no nvmem which are created when you first go into the test menu
  (files on the E: and F: drives), just go into the test menu with [F6] and the select GAME MODE
  using the cursors and [A].

  センターサーバーと通信できません
  2-2002-1013
  ルーターからインターネット回線までの、
  全ての接続機器の電源が入っているか確認
  して下さい。
  ルーターからインターネット回線までの、
  全ての接続機器が正しく接続されているか
  確認して下さい。
  SERVICE BUTTON = GAME MODE (STANDBY) TEST BUTTON = TEST MODE

  Unable to communicate with the Center Server
  2-2002-1013
  From the Router to the Internet line,
  Make sure you have turned on all
  of the connected devices.
  From the Router to the Internet line,
  Make sure all of the connected device
  are connected correctly.
  SERVICE BUTTON = GAME MODE (STANDBY) TEST BUTTON = TEST MODE

-Backup File Error - 5-2502-0003--------------------------------------------------------------------

  This error comes up when it first creates the nvmem files on the E: and F: drives, just go into
  the test menu with [F6] and the select GAME MODE using the cursors and [A].

  バックアップファイルエラー
  5-2502-0003
  バックアップファイルを初期化しました
  TEST BUTTON = TEST MODE

  Backup File Error
  5-2502-0003
  Initializing the Backup File
  TEST BUTTON = TEST MODE


=Changelog==========================================================================================

-v1.0 - 12th May 2016-------------------------------------------------------------------------------

  Finally inspired to start this project again.

  This time with the newer release of the game - GGG-J-A-A-2008041801 (18th April 2008).

  Most of my first release graphics have been ported to the later release newer files, some have
  been updated as looking at them now, some where not quite up to scratch and I was not too happy
  with some of them, over the years I've learnt new graphics technique and got a little better at
  the translations.


-v0.5 - 12th September 2010-------------------------------------------------------------------------

Last version to support GGG-J-A-A-2007092100 (21st September 2007)

  More custom graphics in the same style as the original images.

  Mission Complete, Results Notification and Play Again.

  Also changed the character names and menus in Records section.


-v0.4 - 11th September 2010-------------------------------------------------------------------------

  Quite a big change.

  Changed all the weapon text, all the character text and some of the user interface text.

  I've created some scripts to automate the building of the binary files so after the translations
  and artwork are complete, making the archive files is a lot quicker.


-v0.02 - 29th August 2010---------------------------------------------------------------------------

  A few text boxes have been changed here and there, the demo screens have some translation done.


-v0.01 - 21st August 2010---------------------------------------------------------------------------

  Only the title image has been changed so far, it's quite intensive to edit and recode the images
  files.


=Credits============================================================================================

English Otomedius Logo by GameStone

Translations and translation graphics by GameStone

Extra translations by deadmario

Gradius Home World
www.gradiushomeworld.co.uk

====================================================================================================