Super Puzzle Fighter II for color-blind people

File: spf2t.zip

Instructions:
- Extract the file "pzf.04" found inside of spf2t.zip
- Apply the patch and replace the old one with the new one

pzf.04 before the patch: b80649e2
pzf.04 after the patch:  01bf5ff5


Thanks to:
https://www.reddit.com/r/MAME/comments/2y2cx3/creating_a_color_blind_friendly_version_of_super/
