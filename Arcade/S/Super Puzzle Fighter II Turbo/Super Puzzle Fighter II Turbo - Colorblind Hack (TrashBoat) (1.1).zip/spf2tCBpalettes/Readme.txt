Super Puzzle Fighter II Turbo Colorblind Gem palettes.


How to mod.

1. Unzip your puzzle fighter rom
2. Patch pzf.04 with either one of the ips files
2a. these are two different colorblind palettes. pzf1 is more general, but PZF02 has prettier colors
3. Rezip the ROM.



Extra: if you have the palmod program, you can recolor the gems, or even the characters more to your liking. 