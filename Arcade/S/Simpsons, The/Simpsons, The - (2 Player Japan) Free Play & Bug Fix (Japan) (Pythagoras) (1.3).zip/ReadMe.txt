-----------------------------------------------------
The Simpsons 2 Player Japan. Free Play Patch 240427
-----------------------------------------------------

1. Download FLIPS Patcher.
https://www.romhacking.net/utilities/1040

2. Create a folder.
3. Extract the "simpsons2pj_fp.zip" to the folder.
4. Copy the following roms from simpsons2pj (From a Mame set.)

"072-s02.16c" CRC(265f7a47) SHA1(d39c19a5e303f822313409343b209947f4c47ae4)
"072-t01.17c" CRC(91de5c2d) SHA1(1e18a5585ed821ec7cda69bdcdbfa4e6c71455c6)
"072-213.13c" CRC(b326a9ae) SHA1(f222c33f2e8b306f2f0ef6f0da9febbf8219e1a4)
"072-212.15c" CRC(584d9d37) SHA1(61b9df4dfb323b7284894e5e1eb9d713ebf64721)

(Rom 16c are not modified and will be used as it is.)

5. Copy "flips.exe" to the same folder as the roms.
6. Open a commandline window and type "patch.bat"


The Patch modifies the following.

Additions:

Free Play Option. Accessable from the Service Mode.
(8.Coin, Game Options -> 8-1 Coin Setting)

Attract Mode is always running. (No static screen when coin is inserted)

Bugfixes:
The extensive read from the eeprom. (Service Mode, Coin setting 1P)
Active selection is always reset to the first entry. (Service Mode, Coin settings 1P/2P)

Tweaks:
The Continue timer is lowered from 20 sec to 10 Sec.


Paypal Donation?
-------------------------------------------------------------------
If you like my work and the time I've spent to make this patch.
A small donation to my paypal would be very much appreciated,
Since I not have any job or income at the moment.

The donation will be used for some pizza to get energy
to finish a patch I have on my harddrive.
It is another game from 1991 but not from Konami ;)

https://paypal.me/Mindshadow84
-------------------------------------------------------------------
