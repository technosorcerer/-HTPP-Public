Language patch (text only)
Language: Dutch

--------------------------
08m_05t (Senjyo, Arcade)
--------------------------

Vertaling naar het Nederlands
Versie: 1.0
Datum: 05/08/2019
(c) 2019 Kana Translations

--------------------------
Opmerkingen bij deze patch
--------------------------
Deze vertaling en hack is geheel oorspronkelijk.

--------------------------
Patch-instructies
--------------------------
De patch heeft de IPS-indeling, en kan worden toegpast
met LunarIPS of Floating IPS.

--------------------------
Spelinformatie
--------------------------
Gebruikt oorspronkelijk bronbestand:

Title: Senjyo.zip (MAME 0.78/MAME 2003 or FBA 0.2.97.39-42)
 
Only patch the file(s) below:
File: 08m_05t.bin
MD5: fdc8067bd594ed755791385d5fd30e5f
SHA1: 59997164dfb740fce1862d89754be7517303161a
CRC32: b1f3544d
8192 bytes

--------------------------
Dankwoord/Credits
--------------------------
Kana - Nederlandse vertaling en hack

--------------------------
Very special thanks
--------------------------
Wave - voor het briljante programma Hextractor, website:
traduccioneswave.blogspot.com

-- EINDE --