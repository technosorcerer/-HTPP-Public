﻿Super Real Mahjong VS Retail N64 Hack

  This series of patches allow a retail N64 console to run the various Aleck64 titles.  It mimics the hardware registers used for the DIP and hardware switches and pushes N64 controller output to the mahjong controller input.
  Version 2.0 adds in support for the Randnet keyboard on port 1, in place of a standard controller.
  You'll need an 8MB expansion pak, and optionally a 4K or 16K eeprom to save settings.

Patch Application:
  Standalone patches were abandoned in favor of an autopatcher.  This requires either 64bit Windows or something compatible.
  The patcher supports both version 1.0 (nus-zsej-0.u2) or version 1.1 (nus-zsej-1.u2) of the game, regardless of endianess.
  Load the ROM, select any applicable DIP switches, then output an N64-compatible ROM usable on hardware.  Output is native byteorder (big endian), using a 5101 CIC.


Controls:
Standard Controller Mapping
  With 14 unique keys it is impossible to have an individual key for each button.  Instead, button combinations are used.  The best option is to hold the c-buttons down before pressing L or R to register the press.
  Only the controller in port 1 is read, and only one key will register at a time.
A	L + cleft
B	L + cupleft
C	L + cup
D	L + cupright
E	L + cright
F	L + cdownright
G	L + cdown
H	R + cleft
I	R + cupleft
J	R + cup
K	R + cupright
L	R + cright
M	R + cdownright
N	R + cdown
Chii	B
Pon	+up
Kan	+right
Ron	+down
Reach	A
P1Start	Start
P2Start	Start + cright
P1 coin	+left
P2 coin	+left + cright
Service	Z
Test	Z + cright

Randnet Keyboard
  The keyboard uses the default MAME mapping scheme.
  Only the controller in port 1 is read, and only one key will register at a time.  CapsLock and NumLock are not implemented, and only the first of up to three multiplexed values will be read.
A	A
B	B
C	C
D	D
E	E
F	F
G	G
H	H
I	I
J	J
K	K
L	L
M	M
N	N
Chii	Spacebar
Pon	Alt
Kan	Ctrl
Ron	Z
Reach	ShiftL
P1Start	1
P2Start	2
P1 coin	5
P2 coin	6
Service	9
Test	F2


DIP Switches:
  These can be found at 0xC00 in the ROM and may be freely editted without recalculating the checksum.
  Values are inverted.
8000	free play
0700	coin settings
	0	1 coin, 1 credit
	1	1 coin, 2 credits
	2	1 coin, 3 credits
	3	1 coin, 4 credits
	4	2 coins, 1 credit
	5	3 coins, 1 credit
	6	4 coins, 1 credit
	7	5 coins, 1 credit
0080	test mode
0040	default audio mode: monaural if high, stereo if low
	*Only used if EEPROM does not exist!  Ignored if present but no good!
	If EEPROM present is overridden by selected CONFIG option, defaulting to mono.
	Selects soundbank_2.ctl where all pan values are forced centered (Use with JAMMA speaker).
0020	turn on sound in demos
0010	disable continues
0008	disable kuitan
0007	difficulty
	0	normal
	1	easiest
	2	very easy
	3	easy
	4	normal+
	5	hard
	6	very hard
	7	hardest


Notes:
  This title utilizes an additional 4MB "ram" buffer for tiles.  So yes, this 12MB title has been magically diminished to 8MB.
  All test mode features should work properly as of this patch revision, including the two hidden options.


Revision Log:
V2.0	August 31, 2021
	Support added for Revision A (NUS-ZSEJ-1).
	Added Randnet keyboard support.
	Minor extension to standard controller input.
	Fixed test mode input and memory tests.  Both actually work!
	Gamma correction removed.  Aleck's RGB out doesn't use it!
	Audio DIP used when EEPROM is initialized.
	Timestamp added at 0x34 for easier future identification.
V1.0	August 13, 2015
	Initial Release

-Zoinkity
