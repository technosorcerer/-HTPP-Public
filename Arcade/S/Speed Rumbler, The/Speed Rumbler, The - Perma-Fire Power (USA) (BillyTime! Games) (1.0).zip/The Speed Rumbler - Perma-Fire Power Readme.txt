The Speed Rumbler - Perma-Fire Power
Jan. 7st 2026
BillyTime! Games

This patch is designed to prevent weapon degradation in The Speed Rumbler.

How it works:
--------------------
This patch prevents the loss of firepower upgrades when losing a life, completing a level or continuing.


How to Patch:
--------------------
1.Grab a copy of srumbler.zip
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Extract rc04.14e from rom
4.Patch your rom with the corresponding IPS file (Check parenthesis for correct rom name) 
5.Drag and drop newly patched rom file to zip