This hack was originally started to address the lag issues in SFA2 (arcade version). While progress was made to mitigate the lag present in many of the stages, this aspect of the hack has not been completely finished.

changelog:

* gameplay: specials A3-style, LP/MP/HP for lvl 1/2/3
* chrsel: random character select (right off of Dan) (joystick left turns off random select and drops them at Dan)
* chrsel: each of the 6 buttons as a color, adding the two 'manual' colors
* chrsel: shin akuma selectable (left off Akuma) (joystick right moves back to regular akuma)
* gameplay VS: music always random (31 songs)
* gameplay: remove stage sprites (injection later to add back select stage sprites)
* chrsel: remove countdown timer (infinite picking time)
* gameplay: fix variable input issues - do not clear input buffer based on some condition (implement 3x: button specials, start specials, SPD specials)
* gameplay: remove taunt limitation for non-Dan characters
* using coins doesn't subtract them from coin counter
* chrsel: 2nd method for selecting evil ryu, sf2 dhalsim, sf2 zangief
* disable free select autoblock completely
* chrsel: 2nd Shin Akuma Color (no same color mirror matches) (chrsel palette updated also)

issues:
* gameplay SP: same song repeats

how to patch:
NOTE that this patches "sfa2u" *NOT* "sfa2". sfa2u is the community standard and how the game is played on fightcade2.
remove 'sz2u.03a' from sfa2u.zip
patch using the included .bps file
place the newly updated 'sz2u.03a' file back into sfa2u.zip

If you’re playing it with MAME, you MUST launch modified ROMs from the command line for example, in windows, hit start, run, type “CMD” to bring up a command line. now go to where MAME is installed, and run the game using this command: MAME soldam

It should load up fine in fbneo and fightcade2, it’ll give an error about the crc32 being incorrect but just ignore it

enjoy!

bankbank