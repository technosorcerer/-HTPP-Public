~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
~----- SSF2T Selectable Original Character Colors + Realistic Alts -----~
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Patch version: v1.0

Author: Riggles

Platform: Arcade

Date: 2024-01-15

--- About ---------------------------------------------------------------

The orignal Super Street Fighter II: Turbo didn't have the original 
character palettes selectable unless you picked an older version of the 
character. 

The main patch does the following:
- Light Punch (LP) selects the original character color.

- All the alternative color selections more are more tasteful/realistic,
meaning that only clothing colors change. Not things like skin tone or
hair, to keep the characters faithful rather than feeling completely 
random and out of place. (See the All Characters .png)

- Portraits for characters with orange or beige blood were restored 
to match the rest of the cast. (See the Blood Fix .png)

- Balrog (Boxer), Blanka and Dhalsim had their palettes slightly 
tweaked to reflect their portrait colors.

- Older character version palettes are subtly different, in the case of 
an old version character is up against a Super-T LP palette character, 
you can tell them apart.


The Optional Patch does the following instead:
- Light Punch (LP) selects the original character color. 

- Older character version palettes are subtly different
so that in the case of a old version character is up against a Super-T
LP palette character, you can tell them apart.

No other palette tweaks.

I highly recommend using Bankbank's difficulty fix patch first, it fixes 
a bug that causes the service mode difficulty settings
to be non-functional and always be set to very hard AI.

--- Patching Instructions -----------------------------------------------

Extract the ssf2t.zip into an empty folder, apply the .ips patches to the
files of the same name, sfxe.03c.ips onto sfxe.03c and sfxe.04a.ips onto 
sfxe.04a.

Zip your files back into a new hsf2.zip, browse the new .zip to make sure
it's structured the same inside and doesn't have any additional files 
or folders compared to the original hsf2.zip. 7-zip can be used for this.

Lunar IPS can be used to apply the patch.

The patches can be applied to a ROM that previously was patched 
with Bankbank's difficulty bugfix. https://www.romhacking.net/hacks/8347/
But it's technically still compatible with an unmodified hsf2.zip rom.

--- Playing Instructions -----------------------------------------------

In MAME simply replace the old ssf2t.zip with this new one in 
your MAME ROM folder. (If using RA, make a different path for patched
MAME ROMs and a playlist that points at your patched ROMs so you can
keep them separate from main MAME release ROMs)

In FBN, navigate to the /patches/ folder (system/patches/ in RA) and 
put the patched ROM in there, don't replace the untouched one in 
your FBN ROM folder.

Remember to enable Patched ROMs in the FBN emulator/core settings.
 
The patched ROM should be compatible on real hardware as well as FPGA.

--- Base ROM confirmed to work with the translation and this -----------

hsf2.zip (MAME 0.261 (Merged) verified dump)
CRC32: 87f583f0
MD5: cc19617ed9b7ab83a791b5f557f6b6fc
SHA-1: a24dcddf11724b69d6b3b161e995364ee0234c22

--- Tools ---------------------------------------------------------------

PalMod 1.79


