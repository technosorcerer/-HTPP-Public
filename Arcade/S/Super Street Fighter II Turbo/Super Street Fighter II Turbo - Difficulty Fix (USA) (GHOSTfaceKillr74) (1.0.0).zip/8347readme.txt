SUPER STREET FIGHTER II TURBO difficulty fix.

When set to any non-Japan region, the games AI CPU will always play at an extremely fierce difficulty regardless of what setting the player selects in the machine options.
This patch allows you to change the AI level for Super Street Fighter II Turbo world (940223) region only to match that of the Japanese region.

Credits to Abystus for finding the area to be modified.
Credits to bankbank for starting it off with hsf2 difficulty fix. Super Street Fighter II Turbo definitely deserves a fix too!

You will need to patch the file sfxe.03c which is located inside ssf2t.zip rom.
CRC when playing should state 2b8989d5