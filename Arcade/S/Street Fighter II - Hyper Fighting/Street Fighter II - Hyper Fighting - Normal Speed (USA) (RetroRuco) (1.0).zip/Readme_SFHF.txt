Street Fighter II 'Hyper Fighting (Normal Speed)
Hacked by RetroRuco
2020

--------------
Date Released:
--------------
September 2020
changes
v1.0 Normalize Speed

------------
Description:
------------
-Speed for competition and tournaments is now in normal, the same used in Street Fighter I - II - III - IV - V - VI

-SF 'Hyper Fighting, this game was released in response to the rainbow versions with their high speed and crazy movements, correcting several unbalances between overpowered and underpowered characters in SF Champion Edition.

-The version is very good and fun, but many underestimate it due to the increased speed, which leads to more surprise attacks than skill-based battles. Because of this modification, less people wants to play this version.

-Searched for many years for a ROM that was playable at normal speed, but they all contained glitches and errors, so then modified it myself based on those faulty ROMs, and today, want to share it.

Note: If want to play competitively, both players must have the modified file.


------------
Instructions:
------------
Be careful not to overwrite your original file "sf2hf.zip". Make a copy of your zip file first. You must extract the "s2te_23.8f" file, patch it with the "s2te_23.ips" file, and then reinsert it. This will permanently overwrite the zip file. To use it, make sure the patched file is "sf2hf.zip" in the ROMs folder because that's the one the emulator will read. If you don't know how to use patched files in emulators, look for a tutorial first, as many emulators will refuse to read a modified file.

---------
ZIP file:
---------
* SF2HF
  * s2te_23.ips
* This Readme file

----------
Other ROMS
----------
-Flying_Peach_Sis
https://www.romhacking.net/hacks/9316/
-Super Princess Sis - Two Drunk Princess (Two Players Hack)
https://www.romhacking.net/hacks/4715/
-SUPER MARO INVALIDO FRIO (COLD)
https://www.romhacking.net/hacks/4387/

----------------
ROM Information:
----------------
s2te_23.8f
File/ROM SHA-1: 4411353C389669299C27AC183C7E1CAA3D4CEC90
File/ROM CRC32: 2DD72514


--------
Credits:
--------
RetroRuco - Hacking

---------------
Special Thanks:
---------------
Romhacking.net - for hosting the patch

--------
Contact:
--------
https://www.youtube.com/channel/UCHWPnHR_yKmom4D_OH9Urpg
https://www.youtube.com/@YoSoyRetroClassicGames

----------------------------
Disclaimer and Terms of Use:
----------------------------
* RetroRuco is not related or affiliated with the publisher of the original game.
* Do not sell this patch and the contents with it.
* Do not sell the pre-patched ROM into reproduction cartridges or disks.
* You may distribute or host this patch provided that all files that come with it are intact.
