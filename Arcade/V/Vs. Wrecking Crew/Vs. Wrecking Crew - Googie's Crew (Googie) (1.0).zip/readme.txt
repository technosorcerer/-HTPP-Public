Vs. Googie's Crew - Googie's Vs. Wrecking Crew hack
---------------------------------------------------

This is a graphics hack of Vs. Wrecking Crew with with a dash of Googie's Googie Toons! Help Googie demolish walls and ladders and avoid the Leepleeps and Smorswords, you also have to avoid Anti Googie "the Googie in pink" he wants to see you dead! Help Googie out so he can get paid, baby!

Thanks goes out to the following fellas...

Zynk Oxhyde - for doing the Googie sprites and the level graphics

pacandsacdave - for doing the title screen and the enemies

----------------------------------------------------

+ Googie Toons is owned by Victor Alonzo +

----------------------------------------------------

Here's all of my social media pages in one link, feel free to support me

https://linktr.ee/googietoons

-----------------------------

Take care & enjoy the hack, more hacks will be coming soon. Don't worry I'm still active but at a slower pace. Wanna contact me? My email is 

googietoons(REMOVE_THE_OBVIOUS)@gmail.com

~ Googie   