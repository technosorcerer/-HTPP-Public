---------------
|Vs. Dr. Luigi|
---------------

Released: January 05, 2019
A hack of Vs. Dr. Mario and also an arcade "port" of Shugo's Vs. Dr. Luigi NES hack.


---------------------------
|How to apply the patches?|
---------------------------

1. Get Vs. Dr. Mario.
2. Put "drmario.zip" into the "roms" folder.
3. Then, unzip "drmario.zip" to a "drmario" folder (in the "roms" folder).
4. Apply the 3 patches to the proper files (that are in the "drmario" folder).
5. Have fun!


---------
|Credits|
---------

� 1990 - Nintendo: creator of Vs. Dr. Mario/Dr. Mario and Dr. Luigi for Wii U
� 2014 - Shugo: creator of Dr. Luigi NES hack
� 2019 - Szemigi: creator of Vs. Dr. Luigi hack