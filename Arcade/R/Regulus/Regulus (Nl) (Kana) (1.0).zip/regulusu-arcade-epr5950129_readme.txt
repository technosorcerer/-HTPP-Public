Language patch (text only)
Language: Dutch

--------------------------
Regulus (Arcade, 1983)
--------------------------

Vertaling naar het Nederlands
Versie: 1.0
Datum: 30/07/2019
(c) 2019 Kana Translations

--------------------------
Opmerkingen bij deze patch
--------------------------
Deze vertaling en hack is geheel oorspronkelijk.

--------------------------
Patch-instructies
--------------------------
De patch heeft de IPS-indeling, en kan worden toegpast
met LunarIPS of Floating IPS.

--------------------------
Spelinformatie
--------------------------
Gebruikt oorspronkelijk bronbestand:

Title: regulusu (USA, decrypted version)
 
Patch only the following file(s):
File: epr-5950.129
MD5: 1313ce9a29653c1ccb7812924c5d9ea1
SHA1: 0164cb919a50013f23568f59caff19ff2d0bf11f
CRC32: 3b047b67
8192 bytes

--------------------------
Dankwoord/Credits
--------------------------
Kana - Nederlandse vertaling en hack

--------------------------
Very special thanks
--------------------------
Wave - voor het briljante programma Hextractor, website:
traduccioneswave.blogspot.com

-- EINDE --