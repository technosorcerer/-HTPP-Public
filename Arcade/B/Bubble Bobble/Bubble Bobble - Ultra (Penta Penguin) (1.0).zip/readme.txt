Patch a78-05.ips to a78-05.52, a78-06.ips to a78-06.51 and a78-08.ips to a78-08.37.

I think that this game can only be played through the Raine emulator. Also, it is a hack of Bubble Bobble, not Bobble Bobble, Bubble Bobble (US mode select), Bubble Bobble (US) or Super Bobble Bobble.
