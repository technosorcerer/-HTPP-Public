﻿Mayjinsen 3 Japanese & English Localization v1.1

line  12	.: Introduction :.
line  27	.: Patching :.
line  62	.: DIP Switch Reference :.
line 101	.: Hardware :.
line 139	.: Gameplay Notes :.
line 153	.: Translation Notes :.
line 170	.: Other Notes :.
line 214	.: Patch Revisions :.

.: Introduction :.
  A short and simple single-player speed shogi arcade title with AI developed by Kazuro Morita, namesake of the Morita Shogi game line.  There are two difficulty levels and two game modes--JK and cosplay--with three opponents each.  Unlike the Aleck64 mahjong titles, this one is entirely wholesome (drunken cosplaying bear waitresses aside).

  The UI is but a thin veneer over a more complicated game.  The 2D shogi engine is derived from SeTa's PSX titles ("Kanazawa Shogi '95", "Morita Shogi" in 1997, & "Kanazawa Shogi Tsuki" in 1999), Saturn releases ("Shogi Matsuri" & "Kanazawa Shogi", both in 1995), and PC titles ("Kanazawa Shogi '98", likely others).  AI was provided by Random House and is byte-for-byte identical to "Saikyo Habu Shogi" and "Morita Shogi 64".  Although (arguably) not published until January of 2000, the final revision date is April 20th, 1999, making it among the last works attributed to Random House following their acquisition by Yuki Enterprise in 1999.  It is also one of the last projects before SeTa's acquisition by Aruze the same year.

  The patched game is compatible with SeTa E92 boards and retail consoles (not iQue!).  It is partially compatible with E90 boards, only when JAMMA controls are not in use.

  Features include:
  *) There is automatic hardware detection.  The CPU's Config register is tested to determine if a retail or arcade unit is used.  Several behaviors change in home console mode to virtualize the hardware consoles lack like DIP switches, coin slots, etc.  You can tell what mode it's in by the logo on the opening (Aleck64 or N64).  See "Gameplay Notes" for more information on console button mappings for hardware switches.
  *) English and Japanese can be freely selected using a DIP switch, effective on reset.  Four different tilesets can be selected via DIP switches as well: the original rounded tiles, more traditional tiles (a relic from development), Hidetchi ideographic tiles, and alphabetical tiles.
  *) A built-in EEPROM manager is available if you hold SERVICE at boot (see "Other Notes" for more information).  The Test Menu is still available if you hold TEST at boot or press the button during the attract sequence.
  *) The bug preventing the designation for drops is fixed.
  *) The title, demo, and hi-score screens should have allowed the test menu to open but the events were never raised within the modules (though the event is caught by the manager).  Pressing the Test button during any part of the attract sequence should open the menu.


.: Patching :.
  The official MAME name for the ROM is nus-zscj-0.u3, as printed on the maskrom and using the IC board's label as an extension.  The original dumps were little-endian on account of the dumping software used; later verification redumps were in native byte order (big-endian).
  Two patches are provided: one for big-endian data (mayjinsen3-BE.xdelta) and one for little-endian (mayjinsen3-LE.xdelta).  The patches will only apply to an original, unpatched ROM in their respective orientation.  Attempting to patch something else will result in a completely unhelpful checksum error.  The final, patched ROMs will be significantly smaller, roughly ~6.25 MB.
  Xdelta patches can be applied with the aptly-named xdelta patcher; use version 3.0.8 or up, these support secondary compression.  (In other words, one from the last decade.)
  Files have been tested on an N64 console using three different flashcarts (with and without EEPROM) and on an Aleck64 by flashing & swapping a MSP55LV128 on an ALK-ROM01 board.  Note the MSP55LV128 expects 16bit byteswapped data.  Emulation remains untested, but know the emulator MUST correctly set COP0 Config[30:28] to 7 for retail or 0 for Aleck64 boards.
  
  Common Names
  	nus-zscj-0.u3
  	Mayjinsen 3 (Japan)

  Original File Checksums
  Little-Endian
  SHA-1
  	B5834BFDE5B8A7E20415B2593ABD76EC95AB27C7
  SHA-512
  	60611EC1C91CF032F7140FA460AD530331062B7D420249D4F5C1342CC1E6FB9ADC9DD0A5CB3D328D9E0E50FF47FB6F224A166E837D3EAD01F883B73BEB67B8BF
  Big-Endian
  SHA-1
  	DA401FC96A2B69DB81970D879A2255E54DB88E34
  SHA-512
  	721D762CEDC35EB4ABBB7275AD55B3A07E20BE8732AF3C9C1C8A163898CE7ED0751C36F08FA1F521711D9CC191BF67F03F3FE43BF96A46DB873DACFF7ECB9490

  Patched File Checksums
  Little-Endian
  SHA-1
  	ABD0EECA41CB803FB071FDB35F5EC8770A25CC3A
  SHA-512
  	05864A4A8AEA15936669F03E826937222E87F7A3C2C242FB05CD73F291E946BA3F561F5AA31BD97DBE01E46C89A2CF0F4FC62B302DADAF613E20B26C89D7F364
  Big-Endian
  SHA-1
  	975A146B77673FC51A57E88C2830C5A33ADB89A2
  SHA-512
  	6B26ADD7EAC4CA01B748190D8A045338CA3B8EC041A1536306308D41E557E8194EB05512F80C32E22A5C49BC7C7A8201D302AAC6E05D4E186B5670935D442E3E


.: DIP Switch Reference :.
  Language and Hidetchi tileset options have been added to the original DIPSW options.  On home consoles, hold P1 Start at boot to access software DIP settings.
6000	added time
	0000	60 seconds
	2000	45 seconds
	4000	90 seconds
	6000	120 seconds
1800	match time
	0000	4 minutes
	0800	3 minutes
	1000	5 minutes
	1800	6 minutes
0700	coin settings
	0000	1 coin /1 credit
	0100	1 coin /2 credits
	0200	1 coin /3 credits
	0300	1 coin /4 credits
	0400	2 coins/1 credit
	0500	3 coins/1 credit
	0600	4 coins/1 credit
	0700	5 coins/1 credit
0080	test mode (0:off, 1:on)
0040	language (0:Japanese, 1:English)
0020	sound in attract demo (0:off, 1:on)
0010	arcade: JAMMA control panel input (0:off, 1:on) / retail: analog (0) vs digital input (1)
000C	tileset
	0000	default rounded tiles
	0004	old traditional tiles (see "Other Notes")
	0008	Hidetchi tiles
	000C	alphabetical tiles
0003	difficulty
	0000	normal
	0001	easy
	0002	hard
	0003	expert

  Note: When "JAMMA control panel input" is OFF, you must plug a dedicated Aleck64 input panel/N64 controller into port 1.


.: Hardware :.
General Setup:
*) You'll need a 4K or 8K EEPROM to save settings and scores.  Like all Aleck64 titles, the game is fully playable without one.
*) It will also *require* a 5101 CIC to boot.  Its seed values are both 0xAC, crc 93E983A8F152.  Not all emulators provide this support!  Those with debuggers can skip the permaloop at 800001BC to proceed normally.

Aleck Setup:
*) Up to two coin slots are supported.
*) This title was originally designed for a four-button cabinet.  Only Buttons A, B, and Start are needed for play.  Buttons C & D are only used to reset EEPROM.  Although the game is single-player, either controller 1 or 2 can be used for play.  Whichever controller presses Start on the title screen has control during play.
*) As of version 1.1, both JAMMA sticks and N64/dedicated Aleck64 input panels are fully supported.  These cannot be mixed however.  Aleck64 input panels digital vs analog modes are detected as usual.  If a retail controller is used on an arcade cab if follows (or should) the home console DIP settings below.
*) Hold SERVICE at boot to open the EEPROM manager's statistics screen.
*) Hold TEST at boot, set the "test mode" DIP, or press TEST during the attract sequence to open the service menu.  The "test mode" DIP no longer loops the menu while active; remember to manually set it back when no longer in use.

Home Console:
*) Coin errors will only occur on Aleck boards, not when played on a retail N64.
*) When a home console is detected the "JAMMA control panel input" DIP selects between analog (OFF) and digital (ON) input.
*) Retail N64 consoles behave differently at boot.
   When an EEPROM is not found or saved settings cannot be found on it, the game will boot to a menu.  This will allow you to set DIP switch options and save them (if EEPROM is present).  You may also hold Start or TEST (C-Up) at boot to open this menu or set it to appear each time you launch the game.
   Apologies that these menus are solely in English.
   The default configuration is: analog control, English w/ original tileset, normal difficulty, 4 minute matches, 1 minute time extensions, sound in attract mode, 1 coin for 1 credit, and boots to game when saved settings found.  These settings are encoded at 0x18 in the ROM and can be changed freely.
   Note that changing the control method is effective only when the game starts.  The menus continue to use the original controls.  This menu is not available during gameplay either; changing some of these options could be catastrophic.
*) Although the service menu is available, note that many of its features serve no purpose outside arcades.  The SDRAM test should fail--this isn't available and isn't simulated--and the input test checks the hardware state of most switches, not software simulation of them.

N64 Controller Port Controls:
 Start Button	Start
 movement	+ Pad
 Button A	B
 Button B	A
 Button C	R
 Button D	C-Right
 Button E	(unused) C-Left
 Button F	(unused) L
Only valid on controller 1:
 Test Switch	C-Up
 Service Switch	Z
 Coin Slot 1	C-Down
 Coin Slot 2	(unmapped)


.: Gameplay Notes :.
About Conceding:
  You can give up a failing game during your turn at the cost of 30 seconds.  You'll then restart a new game after being mocked slightly.  The game ends when you run out of time.

Play Record Format:
  The play record only displays the last move.  Promotions for P(awns)/B(ishops)/R(ooks) use T(okin)/D(ragon)/H(orse) instead of +P/+B/+R.  Drops are designated with "*", promotions with "+", no promotion with "=".
  An older Hodges standard for ranks is used (A-I, not 1-9).  Frankly I don't understand why they ever moved away from it, it eliminates any source of confusion.  Why do they think the Japanese started using two different number systems on their boards?  It wasn't like that in the beginning.

Enforced Rules:
  Ties only occur via "draw by repetition", the unlikely chance either player can't move, or if too many moves occurs and they can't be logged further (theoretically at least, it's a limit of the engine under the veneer).  Players moving their kings to opposing sides will never result in a tie.
  "Perpetual check" will automatically lose the game of any who try it.  "Drop Pawn Mate" and "Double Pawns" are enforced.
  The same message is used for impossible moves as for when the king is in check: cannot move there.


.: Translation Notes :.
*) The title is interesting.
   Below the title (五月陣戦) is the intended reading for the kanji (めいじんせん), and this has been officially romanized two different ways.  In the first arcade game it was "Meijinsen" but in subsequent releases "Mayjinsen".
   "Meijinsen" is the name of one of the oldest and important real-life tournaments held since the 17th century, now under the domain of the JSA and integral to its founding.  Although the katakana is also めいじんせん ("meijin" for the title of masterful person, "sen" for a battle/tournament), the *kanji* used for the tournament is "名人戦", reading the same.
   "Mayjinsen" itself is a pun via English.  "五月" is May (lit. 5th month; pre-Meiji month names were more fun), existing solely for the sound.  "陣戦" is something along the lines of "speed matches".  Despite a completely different meaning, 陣 is read the same as 人.
   This would hardly be the first or last time a company used alternate kanji to produce the same reading as something they don't have a license for, but it might have caused some trouble plastering it across the screen in romaji that first time.
   The new English title screen throws the reading under the bus and splits the difference on the main title with "Blitz Shogi Championship 3".
*) Names use international order (personal family) to remain consistent with promotional materials.  It also retains those names instead of trying to rework the cosgirls' puns.  The 3rd year JC is localized as "Jr. H.S." and the JKs are "H.S."; high schools are what they're called in the USA, your experience may vary.
*) In case you're wondering why メトロポリス/Metropolis is Cosmopolis, the latter is used in the removed EEPROM data viewer (see below) and frankly is a much more fun and sensible name.
   In case you're wondering why ベストテン/Best Times is Best Scores, it's because they list best scores and not best times.
*) 酒 (sake) was left untranslated on the bottles.  Redrawing that would be a pain and what, put an "X" on it like in old cartoons?  Leave it blank?
*) 占い師 is lit. an experienced fortune teller.  "Mystic" is used instead of "psychic" so there isn't confusion that she's no ESPer.  It's not that common a term now but I've grown to dislike the most realistic alternative, "medium".  魔力 is a very generic term for spooky powers, she's no mage but def. cringe enough to "swoon" ;*)  Not apologizing for a late 90's game saying "dude" either, especially after a 20-something coworker said exactly that earlier this week.
*) Hidetchi and alphabetical pieces are provided as options, available on DIP switches, but this does not affect the title screen.  That would be pretty bonkers.
   Flipping the switches also won't do anything if the pieces are already loaded in memory.  That would be even more bonkers.  Next time tiles load you'll see the change; the switches are read at runtime, not read from memory like most settings.
   If you don't like them, don't use them (I don't, they're confusing).  If you don't like the *concept* of them complain on 2chan, they're a receptive audience.


.: Other Notes :.
*) Detecting Aleck hardware *was* hard.  (Major change as of v1.1.)
   All E90 & E92 addresses fall at or above 00000000C0000000.  As it so happens, all address access from 0000000080000000 to 00000000FFFFFFFF--including the RDB--do not behave like lower addresses.  DMAs will not be posted; all values returned are zero.  Normally, the lower HW of the 16x2 multiplexed address will be repeated as data on account of shared address and data lines (an open-bus response).  IO load & store instructions only work if a device responds.  Address read error exceptions are *usually* raised if you poke at something that doesn't exist, so hooking a condition for this in the exception handler and setting up very specific test conditions can--usually--get a response from arcade without locking retail.
   In the initial release the controller port is probed, testing if retail controllers are in use--highly unideal and only partially automatic.  It also limited the usable controller setups.
   As of version 1.1, the clock divider setting is read from the COP0 Config register.  This is hardwired, and all (known) retail consoles return a 7 (which should be "default").  Aleck64 boards return an explicit 0 (clock/2).  This is incredibly simple, only requiring 2-3 opcodes depending how fussy you want to be.  Moving forward, testing if (Config >> 0x1C) & 7 == 0 is the recommended method of sorting Aleck64 from retail units (or probably iQue for that matter).

   THE SECTION PEOPLE ACTUALLY CARE ABOUT:
   Some unused data is rolled over from related titles.  Please note addresses mentioned here are from the original, unmodified game.
*) An additional set of non-rounded, woodtone shogi tiles are at vaddr 04019810.  They were originally linked to board 1 at 0x424624/0x424628.  The size here was never updated.  Instead, they're replaced with a call to the second set of tiles--themselves nearly identical to the third, differing only in the stroke at the base of the jeweled general being one pixel higher and less distinct.  So yes, there's an overallocation as a result.
   These tiles are available in this patch by setting the "tileset" DIP to "traditional".
*) The hidden "gamedata" module provides a detailed report of saved statistics.  "A" swaps between Normal and Easy mode.  It also allows you to reinitialize EEPROM.  In other Aleck64 games this option would appear in the service menu.
   It's a micromanager's delight.  All saved data is viewable from this menu.  It breaks down wins, loses, ties, and continues for each round of each path on both difficulties.  Play time per credit per coin is also given.
   Statistics are read from the copy of EEPROM at 8004A400.  A few are peculiar.  ACADEMY's play count is stored, but COSMOPOLIS is the total plays minus ACADEMY's plays.  Like many arcade games, the total score tacks on two zeroes.
   It only displays properly with the final 8x8 font.  That places it as a later addition than the green menus below.
*) A set of 16x16 numerals (0123456789+- ) at vaddr 0402C9E0, used across other SeTa titles.
*) Messages for replays, saving, loading, interrupting/pausing, suspending, and continuing games are among many strings rolled over from other console titles.  Both the gameplay module (taikyoku.bin) and the main runtime have multiple unused printers for play records in Japanese and ASCII--none of which go anywhere--in addition to the main runtime using a copy of the same to generate full play records from a 2-byte from/to encoded value and the move number.  These strings are reparsed by taikyoku to generate the (much, much simpler) "last play record" fields by using string comparisons.  If this seems abstract and confusing, it is, and it's why drop symbols weren't appearing.
   The drop bug was in the main runtime; it would only add the drop symbol to the play record string when the count of tabled pieces was greater than one, but that counter only incremented when a piece wasn't dropped.  The taikyoku reparser picks out the symbol without any coercion, but only when it was included in the lower-level, more complicated string.
*) "GAME CLEAR", 320x240 cyan text on white background at vaddr 042118D8.
*) 0x420660 contains code for a test menu, unrelated to the service menu, internally called "main menu" (メインメニュー).  It's displayed in a green window, assembled from a list of element types & assigned labels/lists--very similar to Motif.  Element selection and movement is based on its index in this list, counting labels, etc.  Some elements are dynamic; widths of drop-down boxes are calculated from the widest strlen unless overridden.  Its default values--which they didn't use--expect "hi-res" 640x480 resolution.
   There are options to check c16 & ci8 image output, open the service menu, or start the game normally.
   Menu modules can't directly load other code; all use the same memory range.  The runtime calls the menu, and the menu returns a value handled by the runtime to swap menus or trigger other effects.  Without its attached code to manage it, this menu loses its functionality.  Selecting any option falls back to the caller.
   Returned values correspond to menu order: 1 for 対局/Play Game, 2 for 女の子テスト２５６色/Gal Test 256 Colors, 3 for 女の子テスト３２０００色/Gal Test 32000 Colors, テストモード/Test Mode is 4, and オープニング/Opening is 5.
*) A text-based game settings menu can be found at 0x4304E0, named "tsettei".  Handicaps, time, and multiplayer options are available.  It's also in a green window and appears to be a repurposing of a play record save menu.  Unused options include date input, short and long string entry (the interface works but isn't on screen), 3-digit move input, and numerical lists with and without suffixes.
   Scrolling help text *should* be printed at the bottom of the screen.  Each message replaces the first depending on context.  An allocation is made after finding the longest of the string lengths from a list.  It isn't mapped as a window element; it uses the same printer as Test Mode.
   The main window is 256 x 240.  When created, the message is placed 48 pixels up, at 192.  However, when the message is scrolled and displayed, the y position is doubled to 384, clipping the string off.  Typically SeTa games have 640x480 windows, somebody clearly forgot to update the remaining code.
   There are two messages:
  J) 設定を変更したい箇所にカーソルを合わせてＡボタンを押してください。「対局開始」で対局を開始します。「中止」で設定を中止します。
  E) Hover your cursor where you want to change a setting and press the A Button.  "Start Game" starts play, "Cancel" cancels setup.
  J) 十字ボタンの上下で選択してＡボタンを押してください。Ｂボタンでキャンセルします。
  E) Select with up & down on the + pad and press the A button to confirm.  Press the B Button to cancel.
   Walking through the UI:
     The top-most box selects the board & piece set.  The left and right columns set the players; by default it's Black, then White.
     From top to bottom, the fields are 対局者/Player, 手合割/Handicap, 持時間/Total Time, and 秒読み/Countdown (turn time).
     Options for ｺﾝﾋﾟｭｰﾀﾚﾍﾞﾙ/COM Player Levels 1-6 do not display the halfwidth moji correctly.  The ASCII portion (first 0xA00) was replaced with 8x8 tiles when the EEPROM details and test menus were revamped, overwriting the Japanese with a second copy of capitals.  Replacing this with the 8x14 images from Saikyo Habu Shogi or Morita Shogi 64 displays the text properly, though causes layout issues on the EEPROM & test menu.
     Handicaps are 平手/Even, 香落/No Lance, 角落/No Bishop, 飛落/No Rook, 飛香落/No Rook or Lance, 二枚落/2 Pieces, 四枚落/4 Pieces, 六枚落/6 Pieces, and 八枚落/8 Pieces.
     Your total play time can range 50 to 5 minutes, 10 seconds, 設定通り/Use (DIPSW) Setting, 無制限/Unlimited, or なし/None--as in no time at all, leading to an automatic loss!
     Turn time countdowns can range from 60 to 5 seconds or be set to 切れ負け/Loss Due to Time Exceeded (aka no turn limit).
     The bottom-most buttons are 対局開始/Start Game and 中止/Cancel.  Starting returns 1, canceling returns 2.  There is no known manager.
   Settings are stored back to memory, with mixed results.  With a bit of coercion, redirecting the call to module 2 (taikyoku) will start a game with a subset of the selected options.  Total time, COM level, and play field are preserved.  Handicaps are only applied to the top field irregardless who they're set for.  You can start a game between two humans but both use controller 1.
   What's interesting is the handicap positions for bottom field are present in memory, the table simply doesn't provide for assigning them.  P1 handicaps are indicies 5, 
*) Field backdrops are double-implemented.  There are three and each is stored as its own file.  However, the way the board/piece select value (8004A578) is implemented is twofold: it selects one of three frame offsets in the current sprite file from a list, and also selects which sprite file to load.  You could replace the individual files with a single one...but you'd have to rewrite the attract sequence.  Unlike actual gameplay, it expects individual files.  The post-game comments are a similar situation.
*) Controller Pak detection was implemented but no save support was added.  This is typical, especially when EEPROM is involved; sorting devices includes basic init and filesystem support.  Shame they never took a page from SNK with arcade memory cards.  It is *awfully* fun to clip a rotor to the bottom of your joystick...


.: Patch Revisions :.
v1.1	2024.11.20	BE 975A146B77673FC51A57E88C2830C5A33ADB89A2 / LE ABD0EECA41CB803FB071FDB35F5EC8770A25CC3A
  Platform now detected using a difference in COP0 Config's clock divider setting, a hardwired difference between retail consoles and arcade hardware.  As a result, arcade units can now use retail controllers, plus analog vs digital is properly detected.

v1.0	2024.03.10	BE C9FC5DC7196FD87415C63825DF9B976B0FB5409B / LE 5A01DADF2EE6BF07950BC4A8110BF183814B2859
  Initial release.

-Zoinkity
