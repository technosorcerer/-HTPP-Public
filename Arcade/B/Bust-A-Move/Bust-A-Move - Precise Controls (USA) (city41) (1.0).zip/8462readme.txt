# Puzzle Bobble Precise Controls Hack

A simple hack that brings the "slow controls" from the SNES port into the Neo Geo version.

By holding down B, the joystick will only change one position at a time. This works for P1 or P2.
