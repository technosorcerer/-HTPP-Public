Language patch (text only)
Language: Dutch

--------------------------
1-n5 (1942, arcade)
--------------------------

Vertaling naar het Nederlands
Versie: 1.0
Datum: 26/07/2019
(c) 2019 Kana Translations

--------------------------
Opmerkingen bij deze patch
--------------------------
Deze vertaling en hack is geheel oorspronkelijk.

--------------------------
Patch-instructies
--------------------------
De patch heeft de IPS-indeling, en kan worden toegpast
met LunarIPS of Floating IPS.

--------------------------
Spelinformatie
--------------------------
Gebruikt oorspronkelijk bronbestand:
Title: 1942 (MAME 0.78 / MAME 2003)

Patch the file below
File: 1-n5.bin
MD5: 8442d4f462a5370f2356f02a471b07e5
SHA1: 24b66827f08c43fbf5b9517d638acdfc38e1b1e7
CRC32: 835f7b24
16384 bytes

--------------------------
Dankwoord/Credits
--------------------------
Kana - Nederlandse vertaling en hack

--------------------------
Very special thanks
--------------------------
Wave - voor het briljante programma Hextractor, website:
traduccioneswave.blogspot.com

-- EINDE --