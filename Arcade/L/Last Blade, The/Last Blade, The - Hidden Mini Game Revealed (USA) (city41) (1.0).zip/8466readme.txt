The Last Blade: hidden mini game hack

The developers of Last Blade hid a little mini game inside of it.
It is normally very well hidden. This hack has it launch right away.

To patch
--------
1. unzip lastblad.zip from MAME somewhere
2. patch 234-p1.p1 with the patch (234-p1.bps)
3. Replace the original 234-p1.p1 with the patched one
4. rezip up all the files into a lastblad.zip

MAME will not run the patched version from the UI,
because it will detect it has changed. You can launch
from the command line instead to work around this.

mame lastblad

or

mame -w -nomouse lastblad

