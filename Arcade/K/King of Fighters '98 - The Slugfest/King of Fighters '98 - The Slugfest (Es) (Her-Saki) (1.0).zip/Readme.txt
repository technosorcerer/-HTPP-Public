﻿/------------------------------------------------------
/
/
/  
/         The King of Fighters '98 (Neo-Geo)
/     
/      
/            El Dream Match nunca termina
/                           -----
/
/
/------------------------------------------------------
/
/  
/
/
/
/
/   K.O.F '98 100% en español (bajo el objetivo de la traducción original)
/
/   by Her-Saki (9/5/2017).
/
/   Parchar 242-p2.bin con Lunar IPS.
/
/   [Usar el emulador contenido en Fightcade o FBA.]
/
/   -Sufrir con la contundencia de las frases- eh, ¡divertirse!
/
/   Este parche aplica a la primera versión del juego (la normal, kof98.zip).
/
/   Colaboraciones en el parche (a nivel técnico y de desencriptación), dudas o manuscritos sagrados a hersakiarc@gmail.com.
/   
/   The King of Fighters '98 © 1998 by SNK.
/
/   Re-localización © 2017 by Saki.
/
/   ¡Diviértete!
_______________________________________________________