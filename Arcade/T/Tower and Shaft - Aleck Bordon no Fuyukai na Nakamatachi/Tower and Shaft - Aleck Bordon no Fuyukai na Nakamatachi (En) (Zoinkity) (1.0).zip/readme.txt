﻿# Tower & Shaft English Localization #
  This series of patches localizes the Aleck64 title "Tower & Shaft" to North American English and optionally modifies it to run on Nintendo 64 hardware.
  A revised cartridge conversion method is used, consistent with later conversion releases.  This should act as a replacement for the original N64 conversion release.

  The game's an arcade license of the Mac titles NS-Tower and NS-Shaft, originally written by Akihiko Kusanagi of Nagi-P Software and distro'd through NIFTY-Serve.
  Gameplay couldn't be simpler.
    In Tower, you hold and release button 1 to jump as Aleck paces left and right automatically.
    In Shaft, move left and right to fall on the platforms.  Don't fall off the screen or get squished by the spikes above.
  Endless mode is endless.  Yes, it stops counting floors at 999 but will continue until you die.  High scores are only kept for endless.
  DIP switches don't dictate settings.  The Test button accesses options such as coin settings, ADS counters, test modes, etc.  All settings are saved to eeprom.
  The arcade version uses JAMMA controls, not the N64-style controller setup.  Only button 1 and the start button are used.

  N64 version controls:
+pad	movement
A	button 1
start	start button
L	test button
R	service button
c-up	coin slot 2
c-down	coin slot 1


# Patching #
  Use xdelta to apply the xdelta patch to the original arcade ROM.  It's MAME name corresponds to its label:
ua3012--all02.u3
MD5
0036AB25DE533E572AE48E47EEA67953
SHA512
63ED3A29D5166A6FDC02973412960935F5352BA370D1D4B17462DB55939F8E8258D68B41F0ACA3FD9A49CA51B6D51CE00142EF684C363702ACE2CF0B44AF4F1B

  Note that this file is and should be little-endian!  Unlike typical maskroms these are effectively flashcarts, so the data is big-endian but storage and access expects little.
  Attempting to use any other file or byteswapped data will result in a "invalid checksum" error.
  * All patches should be applied to ua3012--all02.u3 and no other file *
  * Do NOT attempt to patch the previous N64 conversion of the title *
    ua3112--all02.u3.xdelta			English Aleck64 ROM file, usable in MAME or replacing the U3 chip on an Aleck cart.  Little-endian.
    Tower&Shaft (USA).n64.xdelta		English N64 ROM file, using a modified 5101 cic to limit piracy.  Big-endian.
    Tower&Shaft (Japan) (Rev A).n64.xdelta	Japanese N64 ROM file, using a modified 5101 cic to limit piracy.  Big-endian.

  IC and file names above are recommended names.  Any further Aleck64 English patches will also use hardware IDs +100 of their current value.
  Patch sizes are borderline absurd due to byteswapping.


# Playing #
  Aleck version:
    Yes, the translation works on Aleck64 hardware.  The easiest method is to program the game onto a Fujitsu MSP55LV128 and place it in the U3 slot on an appropriate board, such as the ALK-ROM01.  These boards already are socketed making replacement incredibly easy, and don't have size limitations like the SLOSSEUM boards.
    Actual data size is 0x437340, so a single 8MB chip is perfectly adequate.  The U4 slot does not need to be filled, or for that matter does not need to be unfilled.
    If you're using MAME, run the Aleck64 version.  The consolification method shouldn't work under N64 emulation.  Registry will eventually make it to public distribution, but until then you should be able to load it directly via command line options.

  N64 version:
    Newer generation flash carts support Aleck64 conversions, such as the 64drive.  Console is the recommended method.  Note though that there is no "safe zone" so video stretches to the very edge of the screen, which may cut off a bit of the window on a typical CRT screen.  Colors may appear differently than an arcade unit due to hardware differences.
    Not all emulators support Aleck64 conversions.  Cen64 does, and it's possible to coerce those with debuggers to as well.  Refer to your emulator's documentation or support.


# Cast #
  Not all the cast appears in the attract sequence but they did on the cab's graphics.  Here's a who's who.

Aleck Bordon
  Protagonist extraordinaire.

Horus
  Aleck's dog, proving his expertise is not in Egyptian archaeology.

Marik Bordon
  Aleck's brother, and the reason you took this job in the first place.  Likes magic.

Anubis
  Marik's dog.

Dolphin Boy
  A hero of sorts that uses magic.  Whoever could he be?

Atlus
  Dolphin Boy's canine sidekick.

The K
  Antagonist extraordinaire.
  A demonic bunny of pure darkness running a shady underground cult that's attempting to gain the power of the gods to attain world domination.

Miss X
  Every female Bond and Indiana Jones villain rolled into one.

Tower Scorpion
  A gift shop manager with an unnamed life-long grudge against Aleck.  You will know him by his distinctive red fez.

Minions of Scarab
  Three snide girls who work in Tower Scorpion's gift shop.  Fans of Scarabmoon, the "group" that performed the music for the game.

Michael Shaft
  Psychotic toy company CEO who makes his own friends.  So cold-hearted he's turned blue.

Mechanical Aleck
  A favorite "plaything" of Michael Shaft operated by a goldfish.

Tomy the Mechanical Animal
  The most hideous mechanical lizard chimera to ever been assembled.

Winston Feather-Field
  An angel guarding the ruins who watches over your progress.

Kei-Chan
  A mysterious girl with a butterfly on her head.


# Notes #
  I'm leaving a credit out of this, as I'm not terribly pleased with the final product.  There's a number of reasons, such as:
1) Grammar went out the window.  It's as bad as NES titles: an 8x3 window that could only be extended to a max of 36 printed glyphs, and that was rather forced if not outright sloppy.
2) Characterizations aren't very consistent.  Their "voice" can change between lines, and they aren't always true to the Japanese.
3) The translation's pretty dodgy to begin with.
4) All caps.

  What a bother.

  There's two lines that will never appear.  When you finish episode 1 or 2 of story mode F-Field has a unique line of text.  There's also a line for episode 3, but you'll never see this since the credits run in place of the results screen.
  Two Marik results screen messages about magic that were 1:1 copies of Dolphin Boy lines now use Dolphin Boy's graphic.  Sorry?

  This may come as a surprise, but it's really difficult to maintain a passive-aggressive tone under such tight constraints.  I'd like to use the more accurate "Try not to die..." but that phrase alone is 1/3 of maximum drawable text tiles and over two lines of text box.  Tomy... I never knew what to do with Tomy.
  Text is caps because I didn't want to bother with the added complexity of vertical offsetting.  The source font is (probably) HGP Soei Kakupoptai.  Adding the additional glyphs would be easy enough, as would updating the lookup table.  An additional table would be needed for repositioning (there's some punctuation that could use it too).  The VWF was a total hack though.  They don't necessarily initialize character positions before setting the characters, so there was a bit of code shuffling to prevent the existing VWF positions getting overwritten in the first place.  Plus, text positioning in the bubbles would need to change to afford a pixel or two space between, say, a y over an I.  Spacing between lines effects how fast you can read them, after all.
  The credits and legal screen don't use the VWF to avoid rewriting yet another set of text print functions and their tile generation stuff.  SeTa and redundant code go hand in hand.
  So, apologies for the quality.  With any luck somebody will come along and produce a better patch.
  All errors are my own, unless you'd like to take credit for them.

  Of the more questionable choices, these come to mind:
    Honorifics are gone.  The game is unplayable.
    Voices weren't touched.  Also unplayable.
    "Breath of Hades" became a vaguer "Underworld", since it both referred to the unnatural cold soul-sucking miasma of the Shaft and a real place (person?) that was producing it.
    Left the "Performer of the *" stuff in the credits.  Everything else I could think of sounded only marginally less foolish than pure engrish.
    "Child's play." was the single worst line written.
    Ellipses abuse.  In large part that's due to irregular or jilted phrasing to work around the message length issues, but any more than zero is usually a bad thing.
    Couldn't draw an acceptable "S" for "Congratulation!!".  Sorry, only a single congratulation to go around.
    The line between "localization" and "translation" is often a muddy one, but euphemisms and metaphors are the cleanest distinction you'll encounter, usually rendered into local phrases with similar meaning.  That said, sometimes a gem sticks out that should, nay, must find its way into your own language by any means necessary.  タニシ野郎 literally means "snail bastard", and I for one will do my part entering it into the English consciousness.

  With deepest condolences,
-Zoinkity
