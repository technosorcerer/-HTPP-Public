=======================================================
=== Tetris: The Grand Master ZN-2 to PSX conversion ===
=======================================================

This patch modifies the Tetris: The Grand Master ZN-2 binary to allow it to run on regular retail PlayStation hardware.

All the ZN-2 board specific hardware accesses (ROM, EEPROM, 4MB RAM, JAMMA I/O, QSound, Country ROM) have been replaced or patched out.

The button mapping is configured to match the Namco Arcade Stick / Hori RAP2 layout. 

In order to run this you will need to:
- extract the game binary and data from the ROMs (ate-05m.3h and ate-06m.4h), you can use the included extract_tgm.sh script for this
- patch the MAIN.BIN binary with the included IPS patch(es). The core patch (tgm_psx_v1.2a.ips) is required, the others are optional
- if you want to add music tracks, apply cdda_music.ips and follow the instructions in cdda_music.txt
- compile bin2exe_tgm.c and convert the patched MAIN.BIN binary to a PSX-EXE ("./bin2exe_tgm MAIN.BIN MAIN.EXE")
- master a disc with the extracted ROM contents, the converted PSX-EXE, and the included SYSTEM.CNF file ("mkpsxiso TGM_PSX.xml" or "mkpsxiso TGM_PSX_CDDA.xml")


v1.2a changes:
- Fixed issue with CD-DA music playing at double speed under certain circumstances

v1.2 changes:
- Fixed the short freeze on section change
- Improved compatibility with some emulators when using CD-DA music
- The previously optional CdSearchFile replacement patch is now included directly in the main patch

v1.1a changes:
- Added an optional patch that adds support for CD-DA music playback (see cdda_music.txt for more information)

v1.1 changes:
- Expanded button mapping to allow for easier playing on a regular PlayStation controller
- Fixed bad offsets for some files in extract_tgm.sh (oops!)
- Included bin2exe_tgm.c (a quick hack of: https://github.com/simias/psxsdk/blob/master/tools/elf2exe.c ) to make the PSX-EXE creation easier.
- Included TGM_PSX.xml sample disc layout file for use with mkpsxiso ( https://github.com/Lameguy64/mkpsxiso  )
- Included an optional patch that replaces CdSearchFile() with a faster version that uses fixed LBAs (based on the TGM_PSX.xml layout).  This makes the disc mastering requirements more strict but allows for faster loading from disc.

