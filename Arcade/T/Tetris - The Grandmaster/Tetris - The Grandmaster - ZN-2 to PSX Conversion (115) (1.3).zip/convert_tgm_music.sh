#!/bin/sh

VGM2WAV="./vgmplay-0.40.9/VGMPlay/vgm2wav"

${VGM2WAV} "01 QSound Logo.vgz" track02.wav
${VGM2WAV} --loop-count 18 "02 Hardening Drops (Normal Mix) - Under Level 500.vgz" track03.wav
${VGM2WAV} --loop-count 18 "03 Hardening Drops (Instant Death Mix) - Over Level 500.vgz" track04.wav
${VGM2WAV} --loop-count 5 "04 Happy Happy - Ending.vgz" track05.wav
${VGM2WAV} "05 Game Over.vgz" track06.wav
${VGM2WAV} "06 Results.vgz" track07.wav
${VGM2WAV} "07 Break Into.vgz" track08.wav
${VGM2WAV} --loop-count 10 "08 Let's Live Variously - Battle BGM.vgz" track09.wav
${VGM2WAV} "09 Speaker Check.vgz" track10.wav

