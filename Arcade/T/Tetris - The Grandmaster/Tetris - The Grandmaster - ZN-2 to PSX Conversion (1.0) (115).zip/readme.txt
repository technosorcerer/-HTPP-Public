=======================================================
=== Tetris: The Grand Master ZN-2 to PSX conversion ===
=======================================================

This patch modifies the Tetris: The Grand Master ZN-2 binary to allow it to run on regular retail PlayStation hardware.

All the ZN-2 board specific hardware accesses (ROM, EEPROM, 4MB RAM, JAMMA I/O, QSound, Country ROM) have been replaced or patched out.

The button mapping is configured to match the Namco Arcade Stick / Hori RAP2 layout. 

In order to run this you will need to:
- extract the game binary and data from the ROMs (ate-05m.3h and ate-06m.4h), you can use the included extract_tgm.sh script
- patch the MAIN.BIN binary with the included IPS patch
- convert the patched MAIN.BIN binary to a PSX-EXE
- master a disc with the extracted ROM contents, the converted PSX-EXE, and a SYSTEM.CNF file

