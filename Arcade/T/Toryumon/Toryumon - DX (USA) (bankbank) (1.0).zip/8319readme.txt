Toryumon DX

changes:
1) sonic drop - press UP on the joystick to drop the piece at the fastest possible speed. you can still control it as it's falling and landing.
2) 2nd rotation - the original game only has 1 rotation button, clockwise. this adds a 2nd button. but it's not programmed in the driver or something, cus when I went to play it on my android device with fbneo ra core I can't map button 2 lol

Patch the following TWO files:
"epr-17689.a2"
"epr-17688.a1" 
(you will need to remove them from toryumon.zip, patch, then replace)

if you have any problems, email bank [at] bankbank [dot] net

expected crc32:
epr-17689.a2 - 61d0dd76
epr-17688.a1 - 6a1a354f