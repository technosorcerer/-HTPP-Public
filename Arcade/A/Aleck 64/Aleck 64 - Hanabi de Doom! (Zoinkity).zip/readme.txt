﻿Hanabi de Doon! Don-chan Puzzle Retail N64 Hack

  These patches allow a retail N64 console to run the Aleck64 title.  It mimics the hardware registers used for the DIP and hardware switches and pushes N64 controller output to the joystick registers.  The bootstrap has one additional opcode to pass the correct seed byte.
  You'll need an 8MB expansion pak and 4K eeprom to save settings and scores.

Controls:
movement	+pad
Button A	B
Button B	A
Button C	R
Start Button	Start
Test Switch	L
Service Switch	Z
Coin Slot 1	c-down
Coin Slot 2	c-up

Patch Application:
  It's a bit of a pain to apply this patch.  For these purposes I'll use MAME's naming conventions for the chip dumps.
  You'll need to append ua3003-alh01.u4 to the end of ua3003-all01.u3.  Byteswap the file, then apply either the IPS or BPS patch.
  Any IPS patcher should be able to apply the ips patch.  BPS files can be applied using Beat.

Additional Files:
Hanabi de Doon.txt
	List of the files contained in the ROM and their formats.  No compression is used.
hackery.txt
	Notes taken while creating the patch.  May prove useful to others introspecting it.

-Zoinkity
