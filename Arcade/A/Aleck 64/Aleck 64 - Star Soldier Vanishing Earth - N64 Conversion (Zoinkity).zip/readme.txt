﻿Star Soldier: Vanishing Earth (Aleck) Retail N64 Hack

  These patches modify the Aleck64 Star Soldier: Vanishing Earth ROM so it's playable on a retail N64 console.  It isn't dramatically different from the N64 counterparts, but there you have it.
  The game requires an 8MB expansion pak.  If you don't have one the internal debugger will appear when it catches the bad addresses.
  One opcode has been added to the Aleck bootstrap to set the seed byte to the appropriate value.

  Not all the Aleck hardware registers are mapped this time.  The coin slot timeouts are very short (less than half a second) and do not reset, so to avoid inevitable problems only the service key was mapped.  This happens to give you a credit when pressed and has no timeout.  The start buttons a mirrored on the controller input and not necessary.
  Oddly, control is only mapped to the +pad, not the analog stick.  None of the button mappings were altered by the patch.

Controls:
movement	+pad
button A	A	fire
button B	B	roll
button C	R	exArms
button D	c-right	speed toggle
start button	Start
service button	L

Patching:
  Apply either the ips or the bps file to an unbyteswapped ROM.  The MAME name would be nus-zhbj-0.u3.  Any IPS patcher can apply the patch; bps patches can be applied with Beat.

Other Files:
hackery.txt
	Outlines DIP switch settings and notes on the patch itself.  Note the controller setting must be 0 (N64) or a joystick error screen will appear at boot.

-Zoinkity
