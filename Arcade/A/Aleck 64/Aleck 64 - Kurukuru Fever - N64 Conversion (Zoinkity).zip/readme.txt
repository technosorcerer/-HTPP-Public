﻿Kuru Kuru Fever Retail N64 Hack

  Another Aleck64 title ported to retail N64 consoles.  It's an overly-cute matching puzzle game with an interesting gimmick.  Each animal has a "favorite fruit" that, when cleared, causes the play area to flip upside down.  Subsequent matches cause further flips and reduce the number of adjacent tiles needed for a match.
  Despite the cuteness factor the game has a fairly steep difficulty curve and can get inhumanly fast at times.

  The patch simulates the arcade hardware registers and redirects controller feed to the joystick registers.  It requires an 8MB expansion pak and 4k eeprom.  DIP switches appear to serve little purpose; use the test menu to save game options and coin settings to eeprom.  To clear room for a controller feed translation function two other functions were rewritten to reduce their size.
Controls, same for player 1 and 2:
+pad	movement
A	button 1
B	button 2
Start	start
L	test button
R	service button
c-down	coin slot 1
c-up	coin slot 2

Patching:
  This one can a pain in the butt to patch.  For clarity we'll use the MAME filenames.  First, append ua3088-alh04.u4 to the end of ua3088-all01.u3.  Byteswap the file so it's big-endian, then apply one of the patches.
  IPS can be applied with any IPS patcher or BPS can be applied with Beat.

Other Files:
Kurukuru Fever.txt
	A filelist containing all file offsets and their types to aid extraction.
src/diminish.txt
	Source code for the reduced functions.  Written in ASM.
src/hackery.txt
	Notes on runtime activity and other code when developing the patch.

Random Notes:
  The bootstrap has been hacked to pass the correct seed value into the checksum algorithm.  It differs from the 5101 bootstrap by one opcode.
  As an interesting point, normal controller tests were implemented.  Controller reading was disabled by setting 800A6728 True when the attract screen starts running, but even when enabled the results are ignored.

-Zoinkity
