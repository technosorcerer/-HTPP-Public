Apply sargex4 to spr_4e
Apply sargex5 to spr_5e
Apply sargex6 to spr_6e
Apply sargex8 to spr_8e

When you load up the game, you will get a message telling you that "One or more ROMs/CHDs for this game are incorrect. The game may not run correctly."

Just continue and the game should run fine If you did everything right.

This hack was made by Gatinho.