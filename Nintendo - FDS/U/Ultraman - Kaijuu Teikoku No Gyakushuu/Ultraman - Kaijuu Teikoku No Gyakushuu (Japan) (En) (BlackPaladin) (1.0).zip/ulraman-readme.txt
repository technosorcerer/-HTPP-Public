----------------------------------------------------------------------
-BlackPaladin's Ultraman: Wrath of the Kaiju Empire Translation Patch-
----------------------------------------------------------------------

***************************************
*Ultraman: Kaijuu Teikoku no Gyakushuu*
***************************************

This patch was made out of boredom and a budding curiosity with the Ultraman franchise.  The only editing done on this game was the title screen.  That's it, really.

Ultraman is a classic tokusatsu series that started in 1966 by Tsuburaya Productions, which is still going strong even in the present day.  
Ultraman: Kaijuu Teikoku no Gyakushuu is the second Ultraman video game released and the first game released for the Famicom Disk System.  (The first Ultraman video game was released for the MSX.)

The patch comes in two flavors...

Ultraman - Wrath of the Kaiju Empire (English).ips
--English translation patch for the original version of the game (IPS Format)
Ultraman - Wrath of the Kaiju Empire (English).bps
--English translation patch for the original version of the game(BPS Format)
Ultraman - Wrath of the Kaiju Empire (English) (Disk Writer).ips
--English translation patch for the Disk Writer version of the game (IPS Format)
Ultraman - Wrath of the Kaiju Empire (English) (Disk Writer).bps
--English translation patch for the Disk Writer version of the game (BPS Format)

The original version of the ROM is required for the patches to work.  (Use only the "original" patches for this ROM.)

File/ROM SHA-1: 120580CB6025C68B27DDA91607EA8D9C7E3B9E6B
File/ROM CRC32: CC64BA9B

If you use either IPS or BPS patch on the "original" version of the ROM, it'll result in a ROM with the following hashes.  (Don't use both patches.)

File/ROM SHA-1: BD42652B91AAB5A2386D48759CE773819CEA4EED
File/ROM CRC32: 9B9F0120

The "Disk Writer" version of the ROM is required for the patches to work. (Use only the "Disk Writer" patches for this ROM.)

File/ROM SHA-1: 1C9E86B169562C4945CAFC11B0A3F27F9DDD2944
File/ROM CRC32: 9A2F16CF

If you use either IPS or BPS patch on the "Disk Writer" version of the ROM, it'll result in a ROM with the following hashes.  (Don't use both patches.)

File/ROM SHA-1: FC62B5880561B213392FAB7AD6051758A5FDB0BA
File/ROM CRC32: A16EB874

What's done?

Translated Title Screen

v1.0

Initial Release

Special Thanks

FCEUX Team (Used their emulator for testing purposes)
Mesen Team (Used their emulator for testing purposes)
YY-CHR Team (Used their graphic editor)

All credits to "Ultraman: Wrath of the Kaiju Empire" belong to their respective creators and programmers.  This patch is mainly for pure entertainment for those who cannot enjoy the game.  All right reserved.  (Bandai, Tsurubaya Productions, please don't come after me!)