----------------------------------------------------------------
-BlackPaladin's Transformers: The Headmasters Translation Patch-
----------------------------------------------------------------

*******************************
*Transformers: The Headmasters*
*******************************

Transformers: The Headmasters is a action platformer game, released by Takara, on the Famicom Disk System.  This game, a sequel to the infamous "Transformers: The Mystery of Optimus Prime", is based on the anime-only release of the same name.

Patching Instructions:

The game comes in two patches...

Transformers - The Headmasters (English).ips
--English Translation Patch (IPS Format)
Transformers - The Headmasters (Engilsh).bps
--English Translation Patch (BPS Format)

Use either the IPS or the BPS patch on the FDS file with the following hashes. (Don't use both patches)

File/ROM SHA-1: F9B7F47BD85FDDD18BD20F21C1AF65039518FCE4
File/ROM CRC32: A6D5E984

The end results is a patched ROM with the following hashes...

File/ROM SHA-1: 5888A475B80167124B43E549D106A57536E135D5
File/ROM CRC32: E3165537

What's done:

Translated Title Screen
All Robots' Names in English
Fixed almost all "English" in-game

v1.0

Initial Release

Special Thanks
Mesen Team (Emulator uses in testing the patch)
YY-CHAR team (Tool used for editing graphics)

All credits to "Transformers: The Headmasters" belong to their respective creators and programmers.  This patch is mainly for pure entertainment for those who cannot enjoy the game.  All right reserved.  (Takara, please don't come after me!)