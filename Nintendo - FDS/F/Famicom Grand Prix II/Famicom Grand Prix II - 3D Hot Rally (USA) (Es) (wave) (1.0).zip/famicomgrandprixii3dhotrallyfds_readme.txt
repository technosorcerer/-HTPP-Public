Famicom Grand Prix II - 3D Hot Rally (Famicom Disk System)
Traducción al Español v1.0 (12/02/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en la de MrRichard999, AgentOrange y Alkeides.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Famicom Grand Prix II - 3D Hot Rally (Japan).fds
MD5: e1ebf6eb0e296ee789cb1f191f906c68
SHA1: b35e98154f2b6ad6690e42fe40d9b039b12ef667
CRC32: 0857c4e8
131000 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --