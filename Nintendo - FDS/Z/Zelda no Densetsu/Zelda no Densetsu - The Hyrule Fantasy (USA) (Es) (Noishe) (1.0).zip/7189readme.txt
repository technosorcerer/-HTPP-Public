Zelda no Densetsu - The Hyrule Fantasy
Parche de traducción al castellano
(C) 2023, 2024 Noishe Translations
--------------------------------------

Indice:
¯¯¯¯¯¯
1. Introducción y datos del parche
2. Como aplicar el parche
3. Versiones
4. Agradecimientos
5. Contacto
6. Aviso


1. Introducción y datos del parche
¯¯¯¯¯¯¯¯¯¯¯¯¯¯
Este parche de traducción se ha hecho desde la rom japonesa desde cero, sin usar ningun otro trabajo o parche previo de ninguna otra persona o comunidad.
Tanto los textos, los gráficos editados y ciertas partes de programación han sido realizadas completamente por mi mismo.
La pantalla para escribir el nombre de la partida se pudo finalizar correctamente gracias a la ayuda de Wave.
No he querido expandir la rom ni alterar su estructura más allá de la edición de gráficos, punteros y algunas instrucciones. Esto a sido
así porque la intención es poder jugar en hardware original, sea a traves de una unidad de disco del Famicom Disk System, por un
emulador del lector del FDS como el FDS Key o incluso en un everdrive, aunque en este último el audio no irá igual. Para más información
del sonido y del everdrive teneis esta entrada de mi blog:

https://noishekun.blogspot.com/2024/01/everdrive-n8-pro-y-fds-key.html

Por tanto he tenido que reducir los textos lo máximo posible. Es probable que algunas frases puedan sonar algo confusas por culpa de estas
limitaciones, pero dentro de dichas limitaciones he hecho mi mayor esfuerzo, de hecho, la traducción se empezó después
de la de Super Mario Bros.3 en el año 2020 y no se finalizó la beta hasta diciembre del 2023, arreglando finalmente algunos errores en
enero del 2024. Por tanto a pesar de ser un juego con poco texto ha sido el parche más pesado, complicado y tedioso de hacer de todos
los que he realizado. No le deseo a nadie pasar por esto, espero que al menos se pueda disfrutar.

Por cierto, no se japonés y la rom es japonesa. La traducción se basa en los textos de la web de https://legendsoflocalization.com/the-legend-of-zelda/
-------------------------------------------------------------------------------

2. Como aplicar el parche
-----------------------------
Este parche hay que aplicarlo a la versión 1.1 del Famicom Disk System (NO ES UN PARCHE PARA NINGUNA ROM DE NES).

La ROM original es esta:

Database match: Zelda no Densetsu - The Hyrule Fantasy (Japan) (Rev 1)
Database: No-Intro: Famicom Disk System (v. 20210111-132854)
File/ROM SHA-1: 1429FBE3E62059994B6FF7C5E5E2A330831FAF63
File/ROM CRC32: 8F2202BF

Hay varias maneras de aplicar el parche a la ROM, una de ellas es con el
programa "Lunar IPS", se puede descargar aquí:
https://www.romhacking.net/utilities/240/

Es muy sencillo, una vez tengais la ROM y el parche por separado ejecutáis
el programa, pulsáis "Apply IPS patch", seleccionais el parche y luego la ROM.
NOTA: Al ser una rom con extensión .fds que no es tan común como por ejemplo .nes
no te aparezerá para visualizarla desde el principio, tienes que darle a la
pestaña para ver "All files" en vez de "Most Commond ROM Files".

---------------------------------------------------------------------------
3. Versiones

- 1.0 Versión final inicial (22/01/2023)
      Todo traducido, creo que no falla en ningun lugar ni falta nada pero no he contado esta vez con betatesters.
- 0.99 Beta (02/01/2024)
      Se lanzó una Beta para que se testeara en mi blog que hice a finales del 2023. Al final la testeé yo...

----------------------------------------------------------------------------

4. Agradecimientos

- A Wave por la ayuda.
- A Tomato por su web de legends of localization, sin su información este parche hubiera sido imposible al no dominar el
  japones.
--------------------------------------------------------------------------------

5. Contacto
----------------------------------
Este parche ha sido realizado por Alejandro Mateo, conocido en los foros como
Noishe. Si encontrais cualquier fallo o teneis dudas sobre alguna de mis traducciones
podeis escribirme al este correo: noishekun@gmail.com.

----------------------------------
6. Aviso
----------------------------------
Este parche de traducción traduce el primer Zelda en su versión japonesa
original para el Famicom Disk System al castellano. Se distribuye en forma de 
parche porque no queremos en ningún caso fomentar la piratería.
El autor no ha tenido ningun beneficio económico y por tanto, espera que nadie lo
use para fin comercial. Tampoco está permitido distribuir el juego con el parche 
ya aplicado ni se autoriza a la creación de reproducciones ni "repros" o como lo 
querais llamar de ninguna de las maneras. Es responsabilidad del usuario el uso del parche de
manera legal: NUNCA seré responsable del uso ilegal o del mal uso que se le 
pueda hacer.

Todas las marcas comentadas en este documento pertenecen a sus propietarios.
Zelda es una marca registrada de Nintendo Co. Ltd.
El autor del parche no está afiliado a Nintendo ni a ninguna otra compañía
implicada en este videojuego.

-------------------------------------------------------------------------------

Documento escrito en Badalona el 22 de enero del 2024.