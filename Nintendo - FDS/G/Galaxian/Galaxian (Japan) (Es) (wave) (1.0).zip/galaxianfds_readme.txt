Galaxian (Famicom Disk System)
Traducción al Español v1.0 (28/08/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Galaxian (Japan) [b].fds
MD5: c18ed13af351e7e84c91f5624c4fe4d1
SHA1: d1f87c32567bf748e5a7379b872538b4859c6d87
CRC32: c7c8866b
65500 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --