"Kamen Rider Black El Enfrentamiento Contra Shadow Moon"
Traducción al Español Ver. 1.0 (16/12/2022)
por Max1323 (Traducciones Max1323)
Basado en el gran trabajo de BlackPaladin.
---------------------------------------------------
Descripción:
Kamen Rider Black está basado en la serie de
televisión del mismo nombre. Kohtaro Minami deberá
enfrentarse a diversos monstruos para que al final
se enfrente contra Shadow Moon.

Desarrollado: Human Entertainment
Publicado:    Bandai
Lanzamiento:  15/04/1988 (JAP)
---------------------------------------------------
Acerca del proyecto:
-La mayoría de los textos están traducidos, 
se agregaron algunos acentos.

***ATENCIÓN***
El juego tiene que ser una ROM FDS CON HEADER.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS (PC)
Utilizar UniPatcher (Android)

Archivo IPS
***ATENCIÓN***
El juego tiene que ser una ROM FDS CON HEADER.

Kamen Rider Black - Taiketsu Shadow Moon (Japan).fds
File Size     127 KB
File MD5      4BBE62896BC3E105D82C56DFD9E478A9        
File SHA-1    A9E7E53CB13DA3F8FF1EB27560E4543B6CC2F11F
File CRC32    E6F3B2AD