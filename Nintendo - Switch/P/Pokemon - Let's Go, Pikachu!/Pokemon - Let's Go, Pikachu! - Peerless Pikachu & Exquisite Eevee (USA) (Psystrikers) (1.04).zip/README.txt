INSTALLATION GUIDE

Extract the .zip folder containing the mod.
If you are playing Peerless Pikachu: Copy the 010003F003A34000 folder into the atmosphere\contents folder on your SD card.
If you are playing Exquisite Eevee: Copy the 0100187003A36000 folder into the atmosphere\contents folder on your SD card.