POKEMON DIVINE SWORD & BLESSED SHIELD

Please refer to the documentation and various forum posts for documentation

Installation (CFW):
1. This is assuming you have Atmosphere CFW installed on your switch. I will not be providing a tutorial on how to do this
2. If you are playing Divine Sword, move the folder titled "0100ABF008968000" to atmopsphere\contents, "01008DB008C2C000" for Blessed Shield
3. Launch the game

Installation (Yuzu Emulator)
1. Right click on Sword/Shield in Yuzu and select "Open Mod Data Location"
2. In the folder opened, create a new folder titled "Divine Sword/Blessed Shield"
3. Put the romfs folder from within "0100ABF008968000" if you are playing Divine Sword into this folder. "01008DB008C2C000" if you are playing Blessed Shield
4. Confirm it is enabled in the game's properties
5. Launch the game

An easy way to tell if the mod is working is if the Mystery Gift menu option is replacede with "Divine Sword & Blessed Shield", among other text edits.

English is the only supported language.

If you want to use healing items in battle, please use the "Usable Healing Items" download and follow these instructions:
Place the item.dat file in romfs\bin\pml\item, and select "yes" to replace the old one.

PLEASE ENSURE YOU ARE PLAYING ON SWSH VERSION 1.3 OR ABOVE, OR ELSE IT WILL NOT WORK.

I CANNOT troubleshoot emulator issues, as it is inconsistent per user. For many it works, for many it does not. The game intentionally crashes on Pokejobs in order to prevent an exp/ev exploit.

THE ISLE OF ARMOR AND CROWN TUNDRA ARE NOT EDITED YET. Neither are the Champion's Cup rematches.