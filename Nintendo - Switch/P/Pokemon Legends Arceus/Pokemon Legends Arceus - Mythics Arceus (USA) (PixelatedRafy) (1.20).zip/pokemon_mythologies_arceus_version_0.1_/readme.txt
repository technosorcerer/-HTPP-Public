To install:
Simply drag folder into atmosphere/contents folder if playing on modded actual firmware. 
If you're playing with other mods, put the romFS title into the "01001F5010DFA000" folder. 
For yuzu, simply extract in mods folder.
