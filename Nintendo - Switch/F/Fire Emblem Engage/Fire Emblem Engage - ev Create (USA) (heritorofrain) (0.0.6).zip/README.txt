DO NOT INSTALL WITH ANY OTHER MODS. BACK UP YOUR SAVES AND UNINSTALL OTHER MODS BEFORE PLAYING.
idk about plugin mods eg triabolical, add at your own risk

It is *HIGHLY* recommended to go into settings and set voice volume to 0 before starting, due to odd behavior with dialogue.

Install as normal through cobalt following the path to [/mods/]

