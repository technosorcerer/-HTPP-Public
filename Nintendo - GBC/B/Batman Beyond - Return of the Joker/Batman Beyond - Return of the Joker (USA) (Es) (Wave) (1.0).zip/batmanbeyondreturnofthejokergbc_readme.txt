Batman Beyond - Return of the Joker (Game Boy Color)
Traducción al Español v1.0 (24/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Batman Beyond - Return of the Joker (U) [C][!].gbc
MD5: dd9e7c40f202f2c3963930e195d75f4d
SHA1: 8c69eb7ec5bc809edc8caa255576f919ea722dad
CRC32: b32f4586
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --