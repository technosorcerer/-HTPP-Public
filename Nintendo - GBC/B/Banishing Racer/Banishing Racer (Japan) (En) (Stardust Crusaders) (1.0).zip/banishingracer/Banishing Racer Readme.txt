=======================================================
=====================Banishing Racer===================
==========================V1.00========================
Genre: Action/Platformer

Source language: Japanese

Platform: Gameboy

Patch language: English

Author: Pennywise

E-mail: yojimbogarrett@gmail.com

http://yojimbo.eludevisibility.org/
 
======================================================
About Banishing Racer
======================================================
Background: 

I stumbled onto this game a few years back and thought
it was wacky. Recently I decided to pick up some misc
GB projects and translated this one. It was quite easy.

Only the credits needed translation and a little bit
of graphic work as well.

======================================================
Patching Instructions
======================================================
The patch is in either IPS or BPS format and can be
applied with FLIPS which can be found here:

http://www.romhacking.net/utilities/1040/

The patch must be applied to the Japanese ROM:

Banishing Racer (Japan).gb

We would be highly grateful, if you find some time to 
contact us with proposals or corrections. Information
on found bugs or corrections would be highly 
appreciated.

P.S.

Support the game industry by buying used games!

Even if the money doesn't go to the developers
directly, as the games become rare and harder
to find, the price goes up, and people become
more inclined to buy new releases "while they can!"

======================================================

Credits go to:

Pennywise - hacking, text editing

Ryusui - translation

FlashPV - title screen design, misc graphic design, graphics hacking

======================================================


Compiled by Pennywise. January 2018.