Boarder Zone (Game Boy Color)
Traducción al Español v1.0 (10/05/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Boarder Zone (USA).gbc
MD5: 8907aab5acf0ed74753d6f573e81be91
SHA1: 116020a7c2d87ed16436e7710cfed7a93e81289a
CRC32: a7152869
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --