Bubble Bobble (Game Boy Color)
Traducci�n al Espa�ol v1.0 (10/06/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bubble Bobble (U) [C][!].gbc
MD5: 4bc8467ed91a94ba23648706b551cef5
SHA1: 6e3739c0538467c220750f2e8d474433692bac09
CRC32: c1b22246
1048576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --