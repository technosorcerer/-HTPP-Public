Dragon Warrior III (GameBoy Color) Spell Name Update

By Dragoon ZERO (gt_dragoon AT yahoo DOT com)

Changes in v1.1: 
Both of these were pointed out by gamerdude535. Thank you very much!
- Firebolt was incorrectly named Kafrizzle, it has been corrected to Kasizzle
- Disperse has been renamed Blasto which comes form the IOS/Android versions

For better or for worse (I think there's a little of both), this patch updates the
spell names to those used in Dragon Quests IV DS, V DS, and VIII. Some names didn't
require changes, some didn't have updated names available, and I made a few changes
based on nothing more than my personal preferences.

I wasn't aware of the patch for the NES version until I was almost finished with
this. I did use it to check my work and I know I took at least one name (Morph)
from there, so I thank Reiska for that. Spell names that appear anywhere in dialogue
have NOT been updated. I'll try to fix that if I get around to updating the rest of
the game.

Apply the patch to a clean US version ROM. The changes are listed below.

---------------------------
Blaze - Frizz

Upper - Buff

IceBolt - Crack

Increase - Kabuff

Firebal - Sizz

Return - Zoom

Bang

SlowAll - Deceleratle

BlazeMore - Frizzle

RobMagic - Drain Magic

SnowStorm - Crackle

BlizMost - Kacrack

Firebane - Sizzle

TwinHits - Oomph

Boom

Bounce

BlazeMost - Kafrizzle

PanicAll

Blizzard - Kacrackle

BeDragon - Puff!

Firebolt - Kafrizzle - Kasizzle (corrected in v1.1)

Transform - Morph

Explodet - Kaboom

Chance - Hocus Pocus

Outside - Evac

X-Ray - Peep

StepGuard - Safe Passage

Passtime - Tick-Tock

CurseOff - Sheen

Invisible

Open

Sap

Heal

Expel - Poof

Antidote - Squelch

Infernos - Woosh

SpeedUp - Acceleratle

Surround - Dazzle

Sleep - Snooze

Defense - Kasap

HealMore - Midheal

Beat - Whack

NumbOff - Tingle

Infermore - Swoosh

StopSpell - Fizzle

Disperse - Remove - Blasto (changed in v1.1, taken from IOS/Android)

Awaken - Cocka-Doodle-Do

Barrier - Insulatle

HealAll - Fullheal

Defeat - Thwack

HealUs - Multiheal

Infermost - Kaswoosh

Vivify - Zing

Sacrifice - Kamikazee

Revive - Kazing

Ironize - Kaclang

Zap

Thordain - Kazap

HealUsAll - Omniheal

Repel - Holy Protection

Recall

Forget

Remember

Recollect

Excavate

YellHelp - Yell Help

EagleEye - Eagle Eye *menu thing, Eye For Distance is excessively long*

Location

Tiptoe - Padfoot

MapMagic - Snoop

Smell - Smell Loot *menu thing, Nose For Treasure is excessively long*

Whistle