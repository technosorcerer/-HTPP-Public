All this hack does is replace certain breeding combinations with others to make every monster in the game obtainable by breeding, including the promotional giveaways. This patch was made using "Tara's Adventure" but should work for both versions since the games are mechanically identical. The ONLY monster that cannot be bred even with this patch is Darck because that would be a bit awkward. Purchase his egg as you normally would instead.

For the following list, keep in mind that Slime family is different than the species named Slime and Dragon family is different than the species named Dragon. Monsters with an asterisk (*) are only available via the combinations included in this patch. Here are the new combinations:

Slime (Species) x Bigroost = Wonderegg*
Foohero x Orligon = Warubou*
Warubou* x Wonderegg* = Watabou*
Slime family x Watabou* = Kagebou*
Slime family x Warubou* = Kagebou*
Dragon (species) x Darck = Dimensaur*
Dragon (species) x Aquahawk = Skydragon
Vampirus x Azurile = Lamia*
Almiraj x Aquahawk = Bigroost
Almiraj x Kitehawk = Bigroost
Hammerman x ArmyAnt = Gohopper
Hammerman x StagBug = Gohopper
Beastnite x Servant = Copycat
Beastnite x Lazamanus = Copycat

Note that Slime x Bigroost already resulted in Wonderegg, but only when breeding over a link cable. Now it always works instead.