This file was downloaded from http://www.pokeusa.com

DONE SO FAR
--- newest version 22.04.2002 ---
100% - Title screen - by Jazz
100% - Intro - by Jazz
100% - Graphic repointering - by Jazz
20% - Game text by Jazz and Chiklit
100% - Town names, repointered and translated - by Jazz
80% - Monster names - by Jazz
20% - items - by Jazz
95% - menus - by Jazz
100% - game text box movements and editing - by Jazz (e.g the continue screen is different)

 - Practically we are at 50% - I have done about 49% of the work on this but i did get some help from dmm from his good japanese skills and some help from chiklit.
