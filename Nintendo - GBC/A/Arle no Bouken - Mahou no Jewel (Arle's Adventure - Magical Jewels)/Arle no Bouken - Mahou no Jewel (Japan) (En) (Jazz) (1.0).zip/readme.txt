v1.0 completed - 10 December, 2020
Arle's Adventure - English Translation by Jazz

Adventures of Arle
Aruru no Bouken

However you prefer to call it... is now in english and fully playable.

Extensive hacking, care, translating and effort has been put into this project slowly over 15 years and I'm very proud to finally be able to release it on its 20 year anniversary. Hope you enjoy this game.

Special thanks to:
	Toruzz - rebuilding and finishing the VWF.
	66ccff - finishing off half of the translation.
	Dr.Slump - for translating the first half of the script.
	Ryusui - Starting the VWF and giving a nice base to complete it.