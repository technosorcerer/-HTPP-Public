﻿Arle's Adventure - Magical Jewels - English Translation
Version release: v2.1 
ASM hacking & translation by Jazz

Adventures of Arle - Jewels of Magic (Alternative Name)
アルルの冒険　まほうのジュエル　Aruru no Bouken - Mahou no Jueru (Japanese Name)

COMPLETED
 100% 	Title Screen & Graphics
  99% 	Start Button Menu & Options
 100% 	Card Bank Menu & Options
 100% 	Status Pages / Index
  99% 	Monster Card Names
  90% 	Battle Challenger's Names
  70% 	Items
 100% 	Battle Move Names
 100% 	Battle Move Descriptions
 100% 	Card Trade
 100% 	Battle Link
  90% 	Battle Text (Some parts need formatting)

DIALOGUE
Roughly 15% of the dialogue. There's enough core dialogue there to get you started and understand the basic plot of the game and what you need to do. Dialogue after the Lightning Tiger Cat Veneris fight is completed with spot translations done there after to NPC's.

NOTES
With card names, battle moves and characters I had to change and shorten a lot of these names due to allocated space. I do apologise. I have however kept it as much as I could inline with the original and the series.

**Fixed bug with the first battle that crashed the text if you lose.

CREDITS
Spot translation credits: LostTemplar, BRPXQZME, 730 & MZ @ RHDN Community Forums www.romhacking.net
Other credits: Ryusui / Tauwasser