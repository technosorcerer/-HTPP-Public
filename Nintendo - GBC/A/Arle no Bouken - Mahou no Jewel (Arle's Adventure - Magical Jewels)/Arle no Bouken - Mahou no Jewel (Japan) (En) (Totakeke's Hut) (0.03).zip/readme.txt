---------------------------------------------------------------------
THE ADVENTURES OF ARLE
- jewel of magic -
version 0.03
---------------------------------------------------------------------

The latest version of this patch can always be found at

http://totakeke.fr.st
    - or -
http://totakeke.h4x0rz.com

---------------------------------------------------------------------
CURRENTLY FINISHED IN THIS VERSION (0.03)
---------------------------------------------------------------------

TEXTWISE:

* Welcome to Adventures of Arle Text

MENUS/ETC.:

* Title Screen. Also relocated the Compile and Sega Enterprises text
to the beginning so I can put "Translated by" at the top and not
leave Sega out ^^
* A lot of Monster's Names
* About 1/2-3/4 people enemies are done
* Card Computer and Main Menus are done (main menu isn't overflowing
anymore, but is still a bit buggy. It's not going to improve unless
I get someone to help repointer it. I have no clue about repointering
GBC games.
* Some battle text
* A bit more attacks than 0.02. (Also, reduced them to 8 letters,
because if it's any bigger, viewing it in the status menu will make
the text overflow.)

---------------------------------------------------------------------
TRANSLATION NOTES
---------------------------------------------------------------------

After stumbling onto this game during the summer of 2001 while
searching for POK�MON Gold and Silver translations, I played it a
bit, and then stuck it on a floppy, and put with a few other games. I 
recently rediscovered this game, and decided now, that I know how to 
ROM-hack, to pick this game up as a project.

---------------------------------------------------------------------
ABOUT THIS VERSION (0.03)
---------------------------------------------------------------------

This project's looking great. In the next release, all place names
will be done, thanks to Alerith :D

I'll start on dialogue after everything else is done.

---------------------------------------------------------------------
CREDITS
---------------------------------------------------------------------

ROM Hackers - Totakeke
Translators - Alerith

Special Thanks to:
saBA - for helping make the Japanese table file!
TPC - for talking with those times I was bored. :P

---------------------------------------------------------------------
LEGAL STUFF
---------------------------------------------------------------------

ARLE, and the ADVENTURES OF ARLE: JEWEL of MAGIC is
copyright (c) 2000 Compile and Sega Enterprises. We are not
affiliated with any of these companies. This is a fan translation, 
and is not and will never be for SALE.