rgbasm -o savepatch.o savepatch.asm
if [ ! -f savepatch.o ]; then
	echo "Error Building patch object file."
	exit 1
fi

rgblink -O "$1" -o "$2" savepatch.o
if [ ! -f "$2" ]; then
	echo "Error Building patched ROM."
	exit 1
fi

# 0x1B is the ROM Header value for MBC5+RAM+BATTERY, 0x02 is the RAM size for 8kb (Technically could be 4kb with the undocumented 0x01, but I'd rather keep this simple)
rgbfix -m 0x1B -r 0x02 -v -O "$2"
rm -f savepatch.o
echo "$1 Patched succesfully!"