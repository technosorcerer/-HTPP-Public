[Project Start Date = 02/09/2022]
[v0.07]




**** Pokemon 2 ****

** Gen1&2 DLCs **



* Quick Guide *


- Red IPS = Red Rom.

- Blue IPS = Blue Rom.

- Green IPS = Blue Rom.

- Rainbow IPS = Red Rom.

- Yellow IPS = Yellow Rom.


- Gold IPS = Gold Rom.

- Silver IPS = Silver Rom.

- Crystal IPS = Crystal Rom.

- Copper IPS = Gold Rom.

- Nickel IPS = Silver Rom.



* Full Guide *


- Use "Quick Guide" to "Navigate" what game 'Rom' to use for each 'IPS' patch.

- Make Copies, when needed, of game 'Rom' for each 'IPS' patch;
Do !NOT! use multiple 'IPS' patches on same game 'ROM' when applying.

- Recommend:
'Windows OS' "Lunar IPS Lips 102"
	!!!!OR!!!
'Android OS' "My Old Boy"
to apply mod when patching.

- These mods are !ONLY! for "Pokemon Gen1 & Gen2" games.



* Pokemon 2 Basic Timeline *


- Gen1:

Year 1 Red/Blue/Green Version

Year 2 Rainbow/Yellow Version






- Gen2:

Year 4 Gold/Silver Version

Year 5 Crystal Version

Year 7 Copper/Nickel Version
