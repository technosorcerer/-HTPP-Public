;Moves with additional categories

PunchMoves::
	dw COMET_PUNCH
	dw MEGA_PUNCH
	dw FIRE_PUNCH
	dw ICE_PUNCH
	dw THUNDERPUNCH
	dw DIZZY_PUNCH
	dw MACH_PUNCH
	dw DYNAMICPUNCH
	dw -1

FangMoves::
	dw BITE
	dw HYPER_FANG
	dw CRUNCH
	dw THUNDER_FANG
	dw ICE_FANG
	dw FIRE_FANG
	dw -1

SharpMoves::
	dw CUT
	dw SLASH
	dw FALSE_SWIPE
	dw FURY_CUTTER
	dw PSYCHO_CUT
	dw -1
