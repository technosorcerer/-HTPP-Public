# Moves

**Added:**
Accelerock,
Aerial Ace,
Astonish,
Bounce,
Bug Bite,
Bullet Seed,
Dark Pulse,
Dazzling Gleam,
Dive,
Dragon Pulse,
Dragon Tail,
Earth Power,
Facade,
Fairy Wind,
Flash Cannon,
Giga Impact,
Hail,
Luster Purge,
Mist Ball,
Moonblast,
Nasty Plot,
Play Rough,
Poison Jab,
Power-Up Punch,
Psystrike,
Rock Blast,
Rock Climb,
Seed Bomb,
Shadow Bone,
Shadow Claw,
Shadow Sneak,
Shell Trap,
Signal Beam,
Spectral Thief,
Venoshock,
Volt Tackle,
Water Pulse,
Zen Headbutt

**Removed:**
Beat Up,
Bide,
Bind,
Bone Club,
Constrict,
Detect,
Frustration,
Fury Cutter,
Hidden Power,
Jump Kick,
Kinesis,
Lovely Kiss,
Mega Drain,
Mega Kick,
Mega Punch,
Milk Drink,
Mind Reader,
Nightmare,
Pain Split,
Pound,
Powder Snow,
Present,
Psych Up,
Psywave,
Razor Wind,
Rolling Kick,
Sharpen,
Skull Bash,
Sky Attack,
Snore,
Spider Web,
Spite,
Twister,
Vicegrip

## TMs

- TM01 *Power-Up Punch* (Dept Store)
- TM02 *Dragon Pulse* (Route 69)
- TM03 *Water Pulse* (Route 55 Underwater)
- TM04 *Dark Pulse* (Sewer)
- TM05 *Venoshock* (Sewer)
- TM06 Toxic (Sewer)
- TM07 *Hail* (Danny)
- TM08 Whirlpool (Route 63)
- TM09 *Bullet Seed* (Pinkan Island)
- TM10 Fissure (Unnamed Island 2)
- TM11 Sunny Day (Sunburst Island)
- TM12 Lock-On (Route 66)
- TM13 Ice Beam (Trovitopolis Dept. Store)
- TM14 Blizzard (Game Corner)
- TM15 Hyper Beam (Trovitopolis Dept. Store)
- TM16 Dragonbreath (Route 56)
- TM17 Protect (Butwal West)
- TM18 Rain Dance (Murcott Island)
- TM19 Giga Drain (Ascorbia Island)
- TM20 *Dragon Tail* (Crystal Cave)
- TM21 *Shadow Claw* (Victory Road)
- TM22 Solarbeam (Trovitopolis Dept. Store)
- TM23 Iron Tail (Route 63)
- TM24 Thunderbolt (Trovitopolis Dept. Store)
- TM25 Thunder (Game Corner)
- TM26 Earthquake (Route 62)
- TM27 Return (Show Lapras to its Family on Route 71, Unnamed Island 2)
- TM28 Dig (Dept Store)
- TM29 Psychic (Luana)
- TM30 Shadow Ball (Wrecked Ship)
- TM31 Bubblebeam (Cissy)
- TM32 Double Team (Rudy)
- TM33 *Earth Power* (Dept Store)
- TM34 *Giga Impact* (Dept Store)
- TM35 Flamethrower (Trovitopolis Dept. Store)
- TM36 Sludge Bomb (Trovitopolis Sewer)
- TM37 Sandstorm (Mandarin Desert)
- TM38 Fire Blast (Game Corner)
- TM39 *Dazzling Gleam*  (Dept Store)
- TM40 *Aerial Ace* (Unnamed Island 3)
- TM41 *Flash Cannon* (Dept Store)
- TM42 *Facade* (Moro Island)
- TM43 Zap Cannon (Dept Store)
- TM44 Rest (Unnamed Island 2)
- TM45 Seed Bomb (Route 67)
- TM46 Thief (Mandarin North)
- TM47 Steel Wing (Unnamed Island 1)
- TM48 Rock Slide (Unnamed Island 2)
- TM49 Tri Attack (Victory Road)
- TM50 Flash (Trovitopolis)

## HMs

- HM01 Cut (Mandarin Underground)
- HM02 Fly (Moro Island)
- HM03 Surf (Tangelo Island)
- HM04 Strength (Primas School)
- HM05 Rock Smash (Trovita Island)
- HM06 *Dive* (Ascorbia Island)
- HM07 Waterfall (Unnamed Island 3)
- HM08 *Rock Climb* (Shamouti Island)

## Tutors

- MT01 Fire Punch (Dept Store)
- MT02 ThunderPunch (Route 52)
- MT03 Ice Punch (Dept Store)
- MT04 Comet Punch (Dept Store)
- MT05 Mach Punch (Route 56)
- MT06 DynamicPunch (Dept Store)
- MT07 Headbutt (Moro Island)
- MT08 *Zen Headbutt* (Route 69)
- MT09 Swords Dance (Route 71)
- MT10 Body Slam
- MT11 Counter
- MT12 Substitute
- MT13 Endure
- MT14 Swagger
- MT15 Sleep Talk
- MT16 Attract (Route 67)
- MT17 Play Rough
- MT18 *Poison Jab*
- MT19 *Bug Bite* (Route 49)
- MT20 *Signal Beam*
