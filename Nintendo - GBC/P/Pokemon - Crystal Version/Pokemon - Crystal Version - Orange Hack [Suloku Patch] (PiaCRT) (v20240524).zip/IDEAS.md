**Fukuhara No.4**

Pretty deep cave using mostly rock smash mechanics, the deepest recesses
require strength and this cave has Rockets Cassidy and Butch with their final
appearance before turning themselves into police upon finally giving into the
fact team rocket is dissolved. Wild Kabuto and Omanyte appear here. Tyrunt
fossil is also here, not reviveable until Seyda Island is visited in Kanto.

**Wrecked Ship**

small underwater dungeon. similar to RSE abandoned ship. Ghost types and Marshadow event
take place here.

**Route 60**

Water route to Golden Island. Wrecked Ship found underwater here.

**Route 61**

Long water route with 3 connections

East leads to Murcott Island, West to Mandarin South, and South to Unnamed
Island 2

**Murcott Island**

Fair sized city, wild scyther are on this island. Tracey Battle 3 here.

**Unnamed Island 2**

Uninhabited Island it appears at first, but a small building hidden on the
corner of the island reveals there is a fishermans club here. Rare pokemon can
be caught in a fishing contest here and prizes are given out in a contest
similar to the Bug Catching Contest. On the main island, wild Farfetch'd appear.

**Mandarin South**

Mandarin South is not just a singular location, it is split into 3 parts.
Route 62, Mandarin Desert and Trovitopolis.

**Route 62**

Large canyon route, rock climb to hooh event here post game. Salandit found here

**Mandarin Desert**

A desert not unlike the one from RSE, Cubone and Trapinch appear here.
Sandshrew along with other ground types also appear here. Lots of areas
blocked off by Rock Smash.

**Trovitopolis**

Like Mandarin North, very large city. Team Rocket reappears here (Jessie and
James), and are working with the mayor to launder money from the citizens of
the island.

Ship to Trovita is blocked off till the plot is foiled. Lorelei can be found
here, and after Drake is defeated can be battled. She is shown at first
speaking with Lance, informing him she is retiring from the Elite Four.

POKECOMM CENTER

**Trovita Island**

Surrounded by vicious rocks and whirlpools, it can not be reached except by
ferry from Trovitopolis. It has a small but intricate area filled with trees
and grass, the

Trovita Gym lies in the middle of it. Misty is reencountered here, and will
give you an EGG containing Togepi upon beating Rudy. Rudy rewards you with
Rock Smash.

**Route 63**

water route north of unnamed island 1 to cleopatra island.

**Cleopatra Island**

At first, it is an empty island. Several hidden items here but no wild pokemon
or anything else. Later on Red can be found here.

**Route 64**

A long water route leading to Ascorbia Island. Lots of items here requiring
HMs to access, and a single grass patch with Ditto.

**Ascorbia Island**

Has a city and also contains Route 65. Rockets Jessie and James appear here
again to stir up trouble, but with the help of Tracey, you drive them out.
Tracey battle 4
reward is DIVE
DAYCARE CENTER

**Route 65**

Land route with ponds and rocky cliffs that require rock climb.

**Route 66**

Water Route to Butwal Island
Dive needed to get to butwal

**Butwal island**

A mountainous route with plenty of wild pokemon and berry trees.

**Route 67**

A large water route with open ocean that leads to Kumquat island. Similar to
Route 55.

**Kumquat Island**

Huge island resort, Luana owns the largest hotel there. When you meet her, she
mentions Red, whom she thinks looks exactly like her own son. Island itself
has no wild pokemon, the gym battle will require you to do several puzzles in
the hotel luana runs. Luana rewards you with whirlpool.

hotel has warps like silph co.
game corner

**Route 68**

Water route leading to Rind Island

**Rind Island**

only place in the game where Magikarp are available.

magikarp house where they are weighed
magikarp seller will sell you a shiny karp for $99,000

**Route 69**

Water Route leading to Deserted Island 3

**Deserted Island 3**

A sick woman lives here who asks for you to find her Salveyo Weed which will
cure her illness. Finding the weed will require a battle with a Politoed who
drops it. She rewards you with Waterfall

**Route 70**

Another water route leading to Pummelo Island. Victory Road weaves in and out
here. Sandbars with cooltrainers and high level pokemon in grass patches
and the water itself. At one point you will need to waterfall to cross a large
cliff. Tracey battle 5 is here

**Victory Road**
Like RSE victory road

**Pummelo Island**

large city with the pokemon league. cannot battle drake till GS Ball is delivered

beating drake rolls credits

**Route 71**

small water route to Tarroco Island

**Tarroco Island**

a no capture zone. Jessie and James make their final stand here when they
attempt to poach. Along with Officer Jenny, you put a stop to them and they
are arrested. Rock climb is awarded to the player for this feat

also given permission to capture pokemon there

**Route 72**

water route. Lapras' family it was separated from is here, If Lapras is shown
to its mother here, the colony will be overjoyed and reward you with a TM.

Pirate trainer NPCs

**Hamlin Island**

Has a fairly large, circular city with a bridge to their port (which is
actually just a smaller city). There is also a path to a field where wild
Diglett and Voltorb can be found.

Samson Oak is here, and he is delighted to see you. After sharing his story of
coming from Alola, and a spiel about Alolan Variants, he will take the GS Ball
and tell you that he will do some research on it. After the credits roll
Hamlin Port will go to Vermillion Port, and after completing several postgame
events, Samson will inform you he has solved the mystery of the GS Ball. The
ball is revealed to contain Celebi, which is given to the Player.
