Patch to "Pokemon - Crystal Version (USA, Europe).gbc"

MD5: 12F14BF81CE6FCC201811C708F19B03B
SHA1: 44D8DB16A8D58D2FF94B761127310D650D589B1F
SHA-256: 055E9DCBD6A1E5EB6A735E20333ADC49AFB0888D4BEB3533F59BCD0EC4CE46C2

This patch allows the player to change the real-time clock while in the Pokegears clock menu.
Simply press up to advance and down to turn back the time. Holding the A button allows you to change it faster.

There already exists a patch similar to this one but there are a few differences:
-ASM code is a little more compact
-The old patch had a bug that made the up and down button also change time while talking to a person
-This patch allows you to hold the A button to change time faster