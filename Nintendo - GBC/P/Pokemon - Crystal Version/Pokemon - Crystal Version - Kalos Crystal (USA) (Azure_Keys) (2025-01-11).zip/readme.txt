Pokemon Kalos Crystal

Created by Azure_Keys

This ROM hack was made possible by the PokeCrystal Disassembly. Credits to Rangi, as well as Mateo, Crystal, and Danny-E33 whose advice and code snippets aided in the coding of this hack. 

Huge credits to the artists whose in-battle sprite work was used in this hack: Chamber, Solo993, Gen VI 64x64, N-Kin, Zorgoth120, WAH!, PiaCarrot, XY Sprite Proj., Incufan120, Fexiled, Hooded_Bird, Kyledove, Zerudez, Monnotonnous Pixels, Vale98PM, Dragonball253, Axel-Comics, Noscium, Faintster, Mylittlekeldeo, Tor2005, Lakeofdance, Neslug, Jozzer26, Pokemon Grape, Fenne-King, Falgaia, Lepragon, and COMBOY. Other custom sprites, such as overworld sprites, were made by me.

Kalos Crystal is a sequel to my previous hack, Unova Red. This is a re-imagining of Generation 2, where the first generation of Pokemon were the Unova Pokedex, and the new second generation Pokemon are the Kalos Pokedex. This game features all Pokemon from generations 5 and 6, and like in Unova Red, all Pokemon in the Pokedex are obtainable within a single playthrough.

Aside from the new Pokemon, the game functions primarily the same as the original. The biggest difference is the inclusion of Fairy types. This game also adjusts the type matchup chart to the modern chart first used in Gen 6. All new attacks added into Unova Red are still here, as well as several new attacks to fill out the new Fairy type, as well as add some signature moves to Gen 6 Pokemon, and simply flesh out some underrepresented types. An equivalent number of moves were removed from the game as well, mostly signature moves of Gen 1 & 2 Pokemon, or simply moves that did not fit well with the Gen 5 & 6 Pokemon.

Like in Unova Red, all standard trade evolutions have been changed to standard level-up evolutions, and some of the stone evolutions were modified as well. All Gen 5 Pokemon evolve identically to how they did in Unova Red. A full list of evolution methods can be found in the spoiler logs.

Some TMs have been altered, and a full list can be found in the spoiler logs. Notably, like in Gen 2, TMs are still only one time use. Also, like in Gen 2, moves are still classified as Physical or Special based on type. The only exception (as in Unova Red) is that Ghost is classified as SPECIAL, while Dark is classified as PHYSICAL. Also, the new Fairy type is classified as SPECIAL.

SOME NOTABLE CHANGES:
-Pokedex includes Gen 5 & 6 Pokemon (Victini through Volcanion)
-Fairy Type added
-New moves added, replacing some old ones
-Ghost is SPECIAL, Dark is PHYSICAL
-Some TMs changed
-Some evolutions changed/made easier
-New locations added for evolution stones (they are notoriously rare in Gen 2)
-Ruins of Alph event requires all 4 puzzles to be solved, so don't be discouraged when nothing happens after the first puzzle.
-New Pokemon encounters/gifts have been added, so keep an eye out!
-The final Rival encounter is now a one time battle, and not based on the day
-The Elite Four become stronger after collecting all KANTO gym badges

HOW TO PLAY:
This game can be played with the same software as any other Gameboy Color ROM. For those unfamiliar with Gameboy ROMs, you will need an emulator. The one I have is Visualboy Advance. Once you run VBA, you can select "Run Gameboy" from the file menu, and select Kalos Crystal.