Hi y'all!

My weird hobby since college has been making spreadsheets detailing conceptual games, getting into the real nitty gritty of stats and theoretical balance. I have no programming experience, so I was content with what was essentially game design fanfic, but I realized in early 2023 that with enough patience I could probably figure out how to convert these ideas into an actual mod!

While this began as a relatively vanilla improvement, early into the process I became aware of Pokemon Crystal Legacy, a mod with the same mission and many of the same concepts I'd thought developed. Keeping the original type-based Physical/Special system but swapping Ghost and Dark? Expanding Gym Leaders' type coverage? Giving Red a Mewtwo and letting you catch Mewtwo afterwards? Well rats, another guy beat me to the punch with the same ideas, making the same kind of game. By this point I'd already started expanding on my core concept, but Legacy inspired me to expand even further; no point in keeping my original scope when someone else was already laser focused on doing that!

POKEMON: CUBIC CRYSTAL is a remix of Crystal that's recognizable but distinct, a sort of "what if Crystal's story was as different from Gold/Silver as future same-gen sequels?" approach. The gym leaders have a greater role in your adventure, the order of events and map progression is slightly altered, and sideplots like the Rocket, Suicune, and Ruins of Alph bits are more tightly woven into the main story (don't worry, the Radio Tower Takeover is actually streamlined!). Kanto is expanded as well, with a sidequest that sees you hunting for the Legendary Birds and further integration of gym leaders to the plot.
Quality of Life upgrades abound, from a move relearner in Violet City to the ability for mons to use HM moves in the field without wasting move slots on them. TMs remain single-use, but all of them can be repurchased at various points in the game; this makes the initial choice important, but doesn't limit teambuilding forever. The level curve is improved for both trainers and wild mons, berries and apricorns are dropped two at a time, Kurt works instantly, Morning-only Pokemon appear in Daytime as well to avoid inconvenience, it's all generally smoothed out.

Pokemon have been adjusted to generally create a baseline of 400 BST at the weakest for fully evolved mons, 450 for early game weakmons, and 500 BST as the standard. Typings have been adjusted for more diversity, and movesets as well as moves themselves have been greatly improved. Trainers have better teams, including my favorite idea: a rival that steals *both* of Elm's other starters instead of doing all that work breaking into the lab and only nabbing one.

Remember how this all started with me loving to make spreadsheets? Documentation is what I live for, so every major change to mons, locations, moves, and major battles have been catalogued in an easy-to-navigate spreadsheet.

While Cubic Crystal has been playtested, I'm sure there are issues that have gone unnoticed. If anyone plays it and notices something off, whether a glitch, a typo, or just general feedback on taste, let me know! This is very much a first project, but I only wanted to publish it as a polished, complete game, so I'm happy to learn even more through strangers playing through it.

Enjoy!

WHAT YOU NEED:
A fully legal, definitely legitimate Pokemon Crystal ROM (USA/Europe).
Lunar IPS or another patcher: https://fusoya.eludevisibility.org/
This patch (attached)

DOCUMENTATION:
All right here: https://docs.google.com/spreadsheets/d/1wKsjoYFUskdhTnfAEhmEg2xHZB1iMuR-9qSMEcGHhSU/edit?usp=sharing
I'd suggest downloading your own copy to more easily sort and browse these files. 

ACKNOWLEDGEMENTS:
Thank you to literally anyone who even slightly helped create the pokecrystal disassembly, as without them this project would just be a spreadsheet of concepts: https://github.com/pret/pokecrystal

Thank you to all tutorial writers for simplifying so many complicated coding issues for a dummy like me: https://github-wiki-see.page/m/pret/pokecrystal/wiki/Tutorials

Credit to Tom Wang and Seasick for providing running animation sprites (Kris's minor standing/walking/running sprite edit is my own, I hate that pixel of "hair" so away it went): https://github.com/pret/pokecrystal/wiki/Running-Shoes

HUGE thanks to the pret pokecrystal discord for helping me caveman my way through assembly. The following users in particular were critical in getting me through tricky spots:
-BlueZangoose
-Damien
-FrenchOrange
-Grate Oracle Lewot
-Idain
-Maeve Sea Galaxy
-Pum
-Pyrois
-Silvie
-SonicRay
-Thoth33
-Xaerochill

Thank you to ScottsThoughts, Jrose11, FlygonHG, and Mah-Dry-Bread for hours upon hours of entertainment; without their wonderful Pokemon challenges, I likely wouldn't be so inspired to revisit Crystal Version.

Thank you to Drayano for making me realize that Pokemon games could be modded in the first place, and for setting such an incredible bar. Renegade Platinum remains the definitive Pokemon experience!

And finally, thank you to my wife, not only because she's the love of my life (which is enough!), but for generously engaging with my geeking out about this project despite not giving a shit about Pokemon. She ruuuules.
