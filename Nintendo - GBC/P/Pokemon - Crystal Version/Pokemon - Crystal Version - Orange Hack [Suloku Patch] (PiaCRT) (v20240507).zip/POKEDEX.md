# Pokédex

001-151 are the Gen 1 Pokémon.

152. *Tropius* (**TODO:** Butwal Island)
153. *Kecleon* (**TODO:** Mandarin Desert Cave, Other locations)
154. *Chatot* (**TODO:** Route 63)
155. *Pikipek* (Route 49, Route 50)
156. *Trumbeak*
157. *Toucannon*
158. *Munchlax* (Breed Snorlax)
159. *Rockruff* (Route 50, Route 57)
160. *Lycanroc* (Evolve Rockruff, **TODO:** Victory Road)
161. *Wingull*  (Everywhere)
162. *Pelipper* (Route 63+)
163. *Chingling* (Route 56, Crystal Cave, Route 62)
164. *Chimecho* (Route 62)
165. *Salandit* (Route 62)
166. *Salazzle* (Evolve Female Salandit)
167. *Finneon* (Underwater)
168. *Lumineon* (Underwater)
169. Crobat (Evolve Golbat)
170. Chinchou (Fishing)
171. Lanturn (Fishing)
172. Pichu (Breed Pikachu)
173. Cleffa (Breed Clefairy)
174. Igglybuff (Breed Jigglypuff)
175. Togepi (Trovitopolis Dept Store Roof)
176. Togetic (Evolve Togepi)
177. *Togekiss* (Evolve Togetic with Shiny Stone)
178. *Azurill* (Breed Marill)
179. Mareep (Route 56)
180. Flaffy
181. Ampharos
182. Bellossom (Evolve Gloom)
183. Marill (Crystal Cave, Murcott Island)
184. Azumarill (Evolve Marill)
185. *Mime Jr.* (Breed Mr Mime)
186. Politoed (Evolve Poliwhirl, Unnamed Island 3)
187. Hoppip (Route 50)
188. Skiploom
189. Jumpluff
190. *Stunfisk* (Underwater Rock Smash)
191. Sunkern (Murcott,**TODO:** Route 64)
192. Sunflora (**TODO:** Route 64)
193. *Leafeon* (Mossy Stone on Butwal Island)
194. *Glaceon* (Icy Stone in Mt. Navel)
195. *Sylveon* (Evolve Eevee with Shiny Stone)
196. Espeon
197. Umbreon
198. *Relicanth* (Underwater)
199. Slowking (Evolve Slowpoke via Trade Stone)
200. *Mimikyu* (Wrecked Ship)
201. *Spinda* (Route 53)
202. *Skrelp* (Underwater)
203. *Dragalge* (Evolve Skrelp)
204. *Trapinch* (Mandarin Desert)
205. *Vibrava*
206. *Flygon*
207. *Turtonator* (**TODO:** Cinnabar Volcano)
208. Steelix (Evolve Onix via Trade Stone)
209. *Wailmer* (Route 55, various water routes)
210. *Wailord*
211. Qwilfish (Fishing Contest)
212. Scizor (Evolve Scyther via Trade Stone)
213. Shuckle (Rock Smash)
214. *Mareanie* (Underwater)
215. *Toxapex*
216. *Sandygast* (Mandarin Desert, Route 60)
217. *Palossand*
218. Slugma (**TODO:** Cinnabar Volcano)
219. Magcargo (**TODO:** Cinnabar Volcano)
220. *Carvanha* (Tangelo Jungle)
221. *Sharpedo*
222. Corsola (Fishing, Underwater)
223. Remoraid (Various water routes, Route 51)
224. Octillery
225. *Mantyke* (Breed Mantine)
226. Mantine (**TODO:** Route 64+)
227. Skarmory (Route 62)
228. *Magmortar* (Evolve Magmar via Trade Stone)
229. *Electivire* (Evolve Electabuzz via Trade Stone)
230. Kingdra (Evolve Seadra via Trade Stone)
231. Phanpy (Route 56)
232. Donphan
233. Porygon2 (Evolve Porygon using Upgrade)
234. *Porygon-Z* (Evolve Porygon2 using DubiousDisc)
235. *Lickilicky* (Evolve Lickitung with Rollout)
236. Tyrogue
237. Hitmontop
238. Smoochum
239. Elekid (Trade in Kinnow Island, Breed Electabuzz)
240. Magby (Breed Magmar)
241. *Happiny* (Breed Chansey)
242. Blissey
243. *Cutiefly* (Route 52, 62)
244. *Ribombee* (Route 62)
245. *Tangrowth* (Evolve Tangela with Ancientpower)
246. *Rhyperior* (Evolve Rhydon with Trade Stone)
247. *Magnezone* (Evolve Magneton in Mandarin Desert)
248. *Marshadow* (Sunray Cave Peak)
249. Lugia (Shamouti Island)
250. Ho-oh (Sunray Cave Peak)
251. Celebi (GS Ball on Hamlin Island)
252. *Latias* (post Alto Mare Roaming)
253. *Latios* (post Alto Mare Roaming)

**Removed:**
Chikorita/Bayleef/Meganium,
Cyndaquil/Quilava/Typhlosion,
Totodile/Croconaw/Feraligatr,
Sentret/Furret,
Hoothoot/Noctowl,
Ledyba/Ledian,
Spinarak/Ariados,
Natu/Xatu,
Sudowoodo,
Aipom,
Yanma,
Wooper/Quagsire,
Murkrow,
Misdreavus,
Unown,
Wobbuffet,
Girafarig,
Pineco/Forretress,
Dunsparce,
Gligar,
Snubbull/Granbull,
Heracross,
Sneasel,
Teddiursa/Ursaring,
Swinub/Piloswine,
Delibird,
Houndour/Houndoom,
Stantler,
Smeargle,
Miltank,
Raikou,
Entei,
Suicune,
Larvitar/Pupitar/Tyranitar