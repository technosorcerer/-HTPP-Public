-------------Welcome to Pok�mon Bronze!-------------

A Pok�mon Gold ROM hack created by Freako and Torotix

The Story:

Set shortly after the events in Pok�mon Gold/Silver, you and your rival are living in Cartridge Town of the Kohto
region about to start their Pok�mon journey. You collect your starter from the resident Professor Koa and get a Pok�dex
from Professor Oak and begin your quest of defeating the 8 gyms of Kohto and then the Pok�mon league.

However... with Team Rocket recently disbanded another group is stepping up to the plate to cause trouble!

Pok�mon Bronze aims to be a new Pok�mon adventure in the Gold/Silver era.
Our goal was to make something that feels like an actual game that would have been released during Gen II.

---------------Patching The Rom---------------------

You'll need an .ips patching program.

Make sure you have an ENGLISH Pok�mon Gold ROM. (I recommend the one you can get from CoolROM.)
-Unzip the Pok�mon Bronze.ips from the .rar to a folder of your choice.
-Launch the Lunar IPS program and click "Apply IPS Patch".
-Navigate to the Pokemon Bronze.ips you extracted and select it.
-Navigate to your unmodified Pok�mon Gold ROM and select it.
-It's patched and ready to go, you're done!

For Girl Patch:

After patching the Pokemon Gold rom with the Pokemon Bronze.ips, patch the rom again with the Girl Patch.ips.
Now the player character and rival have been swapped and you can play as a girl.

-----------------------------------------------------

Alternatively, using VisualBoyAdvance emulator:
Re-name your Pokemon Gold.gbc to Pokemon Bronze.gbc and place it in the same folder as
Pokemon Bronze.ips and then launch the ROM and it should work that way.

Note: you cannot play as a girl if you use this method.

--------------Continuing Save From Demo--------------

If you are continuing your progress from the demo, save inside of the nearest Pokemon Centre
before loading your save file in the full game to ensure compatibility.

Make sure to rename your save file to the same as the rom name of the full version so it will load.

Also I should note that some events that took place in the demo have been changed slightly so it may also
be wise to just start the game again, but you don't have to.

-------------------Updates Since 1.0--------------------

-Fixed some spelling and grammar issues.
-Fixed some unchanged text from Gold.
-Changed some wild Pok�mon locations.
-Changed a map tile.
-Fixed the game incorrectly counting beating the unofficial gym as a badge gained.
-Fixed some more spelling mistakes
-Fixed woman in Russet Town Pok�mon Center so they no longer walk in front of nurse joy.
-Fixed some more spelling and grammar issues.
-Fixed bug which allowed you to fight FLYNN multiple times.
-Fixed a bug which made a crucial item ball unobtainable for some people.
-Fixed being able to view town map on house walls where there was no map.
-Changed a gift TM.
-Removed a Pok�mon from an elite four team.
-Fixed more spelling and grammar issues.
-Fixed an incorrect collision value in MEMORIA TOWN.
-Changed some phone conversations.
-Changed some wild Pok�mon locations.
-Removed a hidden item that crashed the game.
-Fixed a bug that would almost destroy your game save if you saved in ACRE FOREST.
-Moved the egg holding daycare sister.
-Added water to RELIC CAVERN.

-----------------Notes/known bugs:-------------------

-The Town Map still has unused locations listed.
-People that call you for a rematch will give you the incorrect location.

--------------------------------------------------
www.pokemonbronze.net