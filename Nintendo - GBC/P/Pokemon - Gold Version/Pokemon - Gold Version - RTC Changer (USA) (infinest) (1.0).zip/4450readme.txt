This patch allows the player to change the real-time clock while in the Pokegears clock menu.
Simply press up to advance and down to turn back the time.
Holding the A button allows you to change it faster.

Patch to "Pokemon - Gold Version (USA, Europe) (SGB Enhanced).gbc"
MD5	a6924ce1f9ad2228e1c6580779b23878
SHA-1	d8b8a3600a465308c9953dfa04f0081c05bdcb94
SHA-256	fb0016d27b1e5374e1ec9fcad60e6628d8646103b5313ca683417f52b97e7e4e