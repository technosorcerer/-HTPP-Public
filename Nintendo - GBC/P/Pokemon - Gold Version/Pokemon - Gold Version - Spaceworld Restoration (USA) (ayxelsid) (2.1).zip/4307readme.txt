CURRENT VERSION

v2.1
- Added new trainer sprites Prof Oak, Gold (Hero), Falkner, Bugsy, Morty, Jasmine, Silver (Rival) (First Form), Youngster, Schoolboy, Lass, Cooltrainer (Male), Cooltrainer (Female), PokeManiac, Rocket Grunt, Teacher, Bug Catcher, Swimmer (Male), Super Nerd, Biker, Burglar, Firebreather, Juggler, Blackbelt, Kimono Girl & Twins
- Gym leader Morty and relating text changed to demo leader Enoki
- BICYCLE and relating text changed to "CRUISER" skateboard from demo
- Added new overworld sprites Gold (Hero), Gold (Hero) (On Cruiser), Mother, Falkner, Bugsy, Morty (Enoki), Jasmine, Generic Girl, Time Capsule Nurse, Biker, Medium


v2.0

- All Pokemon 1-9 sprites replaced with demo versions (including shinys) using original color palettes
- All Pokemon 150-251 sprites replaced with demo versions where available (including shinys) using original color palettes. Not including new Pokemon.
- All names restored to Japanese demo names where available
- Restored evolution data for Borubeaa, Akua, Pachimee, Flaaffy, Pichu, Cleffa, Igglybuff, Golbat, Kokumo, Paon, Remoraid, Gongu, Poponeko, Rippu, Erebebii, Magby, Chansey, Scyther, Debiru & Onix
- Cyndaquil & Totodile along with their evolution chains changed to new Pokemon Honooguma & Kurusu along with their evolution chains
- Corrected Prof. Elm text confirming your selection choice
- Beauty, Medium, Swimmer (Female) and Fisher trainer sprites swapped with original demo versions
- Sage trainer sprite swapped with Japanese/Korean version and changed to demo color palette