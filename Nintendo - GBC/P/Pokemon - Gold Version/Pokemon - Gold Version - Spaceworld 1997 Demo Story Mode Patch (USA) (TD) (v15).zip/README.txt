
*******************************************************
*******************************************************
*****Pokémon Gold Spaceworld 1997 Story Mode Patch*****
*******************************************************
*******************************************************

This is an in progress patch for reimplementing the extremely limited story mode for of the Spaceworld 1997 Demo of Pokémon Gold Version. Below you will find the change logs for the patch, the planned future changes, as well as which version of the ROM that you must acquire to be able to use this patch. If you would like to help with getting this ROM hack further, please feel free to reach out as I would absolutely love to make a finished version of this patch.

You will need to get a copy of the ROM named exactly "Pokémon Gold - Spaceworld 1997 Demo (Debug) (Header Fixed).sgb" which is relatively easy to find if you know where to look. Sadly I will not be able to point you in the best direction to attempt to reduce the likelihood of the original ROM being lost to time again.

*****CHANGE LOGS*****
Story Mode V15
-Shiny Pinkmon sprite palettes have been corrected for SGB users (eisnerguy1 code https://github.com/pret/pokegold-spaceworld/commit/724922d535d179323c7d981a2ecaca8006c08173)
-Enabled the use of the Poison Stone and Heart Stone evolutions (tips from eisnerguy1)
--Most mon that use these stones can't be caught in the wild so not sure what to do about this yet
-Old Town map file reversion to utilise below change
-Old Town, High Tech, and North PokeMarts sizes corrected (eisnerguy1 code https://github.com/pret/pokegold-spaceworld/commit/538bef1988b1a43f24857db20f52152b3b2714b8)
-Extended Debug Warp menu to include the hidden 29 maps
--Some maps are not explorable outside of the Field Mode as it requires the ability to walk through walls that is exclusive to that mode (may add to Story but unlikely)
-Finally removed the Demo Lab Lockout (I think)
-Demo Blackout Reset is FINALLY gone!
--Party does not automatically heal so make sure not to get into another encounter before healing manually
--If you lose against a trainer, that trainer is still marked as defeated and cannot be rematched for some reason

Story Mode V14-2
-Attempting to fix issue with patch not applying properly on baserom

Story Mode V14
-Debug PC now acts as a full PC instead of just Pokémon storage
--This inadvertently allows you to use the PC in the Player's bedroom as a full PC as well after acquiring your starter
-Nanami will now give several new items in place of the Pokéballs
--Masterballs, Rare Candies, & Placeholder TM at the very least (Can only give 8 items counting holders so not sure what to give)
-Fixes all Ball items to actually be stored in the Ball Holder like TMs/HMs are in the TM Holder
--Also included TM Holder for testing
-Adds Debug Cut to the Debug Menu
--This is at the bottom of the second page

Story Mode V13
-Fixed bug introduced in either V12 or V11 that caused Rival Battle to become bugged like it originally did
-Adjusted Old City's Mart to properly fit in the smaller size that it was adjusted to at some point in development that caused map corruption
--This is an approximation based on other Mart maps but in the smaller 6 tile width instead of the seemingly standard 8 tile width

Story Mode V12
-All used tilesets have been updated/corrected
--Will eventually go back for the unused tilesets like Cave, Power Plant, SS Anne, and SS Anne Dock once they are needed/accessible
--The world is now technically 100% functional (including wild Pokémon but not including scripts after Route 1 Gate to Old City)

Story Mode V11
-Sadly brings back the locked door text for Oak's Lab as this was causing the game to crash for some reason.
-Added proper collision data for Old City, West (City), Baadon (City), all of their connecting routes (that share the same tilesets), and all route gates
--This opens up roughly 30-40% of the map as mostly functional (including wild Pokémon but not including scripts after Route 1 Gate to Old City)

Story Mode V10
-Implemented the Continue Game option on the title screen
--Selecting this option without having saved before will cause the game to crash
-Removed locked door text for Oak's Lab so that the player may now enter freely
-Made the forced Rival end demo text at the end of Route 1 not trigger automatically
--Talking to the Rival will cause the dialogue to trigger as normal and send the player back to the title screen (need a better solution)

Story Mode V9
-Added partial support for the Debug Menu version of Bill's PC
--This will crash the game if accessed before getting your starter Pokémon
--There is only one box with roughly 20 spaces but the release feature does function properly from my limited testing
-Adjusted the amount of PokéBalls that Nanami gives you after you defeat your rival from 6 to 99
--Her dialogue still states that she is giving you 6 because this is only temporary while I work on better systems of implementation for getting items

Story Mode V8
-Changed start menu to show the save option
--Save does not actually work at this moment in time
-Added in Field Debug Menu (Activated by holding B and Start at the same time)
--This allows users to heal their party as well as some other features

Story Mode V7
-Removed the demo barricades at the North and East exits of Silent Hill
--DO NOT GO TO THE EAST UNTIL YOU HAVE RECEIVED YOUR STARTER!!!! Doing so will cause a soft lock of the game.

Story Mode V6
-Implemented Rival battle
--The Rival's name is currently messed up (Shows the text of "<rival's name>'s has started a battle!") but attempting to fix this later

Story Mode V5 (Beginning of rewrite)
-Enable Story Mode
-Change Title Menu Option from "Play Pokémon" to "New Game"
-Re-enabled all Pokémon evolutions

*****KNOWN BUGS*****
**_New Bugs:_**
-Blackout doesn't heal party (heal before next encounter or you WILL crash)
-Blackout to trainer marks them as defeated instead of unbattled (no rematches)
**_MAJOR:_**
-Selecting the Continue Game option on the title screen without having a save made will cause the game to crash
-Encountering a wild Pokémon to the East (and possibly North) of Silent Hills before receiving your starter will cause a soft lock that requires a restart to resolve.
-Opening the Debug Menu version of Bill's PC  or the one in the Player's bedroom before getting your starter Pokémon will cause the game to crash
-Talking to the rival at the end of Route 1 will still trigger the end demo dialogue and reset the game
-Storing Pokémon in the PC will corrupt them over time
--Not exactly sure what causes them to corrupt so save states and limited usage of PC is recommended (likely either having too many mon in the PC or saving the game with the start menu and loading from the continue button on the title screen but could be other things too)
_**Minor:**_
-Nanami's dialogue incorrectly states that she is giving you 6 PokéBalls because the items that she gives you are a temporary workaround for the lack of functional shop
-Rival battle has grammatical error during the intro text
-Currently no way of acquiring more items besides the items that the player receives from Nanami after defeating their Rival.
-Start menu does not update along with the story flags being achieved
-Title screen menu does not update along with existing/missing save data
-Debug Cut bugs:
--Can cut tall grass but doesn't seem to remove the wild encounter chance
--Cannot walk on tile where the cut tree was unless you step away and walk back
---This is risky since the tree will reset if you are unlucky and get in a wild encounter after cutting the tree as it will reset upon battle exit
--Doesn't work in Old Town for some reason so will have to look into that
---Likely related to map data so might be able to fix when I unblock more blocked off map areas and maybe make connections between water bridges that used to be for ship travel

*****PLANNED CHANGES*****
-Implement a temporary blockade to the East (and possibly North) exit of Silent Hill, similar to Blue at the West exit
--This is because if you encounter a wild Pokémon before receiving your starter, the game will soft lock and require a restart
-Re-enable Pokémon Center features in Silent Hill
--Re-enable healing feature
--Re-enable the PC features
-Fix start menu to actually update with the story mode flags
-Fix the title menu to show Continue Game only after the player saves the game at least once

*****STRETCH GOAL FEATURES*****
-Enable the ability to enter all Pokémon Centers within the game as well as both healing and PC boxes if possible
-Enable the ability to enter and purchase from PokéMarts everywhere in the game if possible
-English translation (This is almost a zero percent chance thanks to my limited skillset but I am very much open to help with this as well as any of the other features listed above)
-If I can either get the help or learn enough to do all of the above features, I would like to maybe make a separate version of the patch that would essentially be a Gold 97 Reforged situation. Though this would require a lot of additional research into as much info that can be found about the original plans for Generation 2 prior to them being scrapped for the versions that were officially released to us. This is including, but not limited to; adding the boat to travel between Fonto, High Tech, and West, adding the proper connections for Cave and Power Plant if actually intended to be used, story events found in other leaked sources, etc.
