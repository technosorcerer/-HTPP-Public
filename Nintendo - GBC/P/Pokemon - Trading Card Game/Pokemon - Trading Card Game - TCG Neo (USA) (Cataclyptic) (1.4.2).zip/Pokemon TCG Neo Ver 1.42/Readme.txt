How to patch this file:

1) Get an unmodified ROM of the Pokemon TCG for Gameboy, English version
2) Click on the IPS patcher, included in the .ZIP
3) Select the IPS file and then the unmodifed ROM
4) Wait for it to patch
5) Play the game!

Readme:

It is recommended to play at around 200-300% speed, as the base game is pretty slow. Or, select the fastest speed in the config menu.

There are two versions of this game: V 1.4 and Legacy Version. V 1.4 is the 'official' version of the game, which contains balance changes and whatever I thought was fun. Legacy version by contrast, tries to make all the cards as close as possible to their original counterparts. 

Thanks for playing!

You can hack this game yourself by going to https://github.com/RealCataclyptic/Pokemon-TCG-Neo and git pull-ing it to your computer. However, this game requires RGBDS version 0.6.1. It does not make on later versions. 