-Readme-
So a few things:
To Patch the game you would need the USA version of Original Game's Rom (Pokemon Trading Card Game (USA)), second you can use any patcher that you want to aplly the patch, From LunarIps to just this page (https://www.marcrobledo.com/RomPatcher.js/). After you apply the patch the game wold be ready to play.

If you need help you can consult in the PokeCommunity page (https://www.pokecommunity.com/threads/pok%C3%A9mon-tcg-generations-1-7.504206/) or the PokeTCG Hacking Disocord Server (https://discord.gg/K2kfTx2xRf), Feel free to join if you want to just talk or see other hacks =)

And a little thing, Here i made a TierList page if you want to make one of those: (https://tiermaker.com/create/pokmon-tcg-generations--v17--17294300)

And well that would be all, remember this hack was made by only 1 person (Me xd), so if you find any errors please let me know, and that's it, have a Nice Day!