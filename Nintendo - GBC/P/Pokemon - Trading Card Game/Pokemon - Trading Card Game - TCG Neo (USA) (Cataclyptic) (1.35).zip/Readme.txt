How to patch this file:

1) Get an unmodified ROM of the Pokemon TCG for Gameboy, English version
2) Click on the IPS patcher, included in the .ZIP
3) Select the IPS file and then the unmodifed ROM
4) Wait for it to patch
5) Play the game!

Readme:

It is recommended to play at around 200-300% speed, as the base game is pretty slow. Or, select the fastest speed in the options menu.

There are two versions of this game: the Boy version and the Girl version. As stated plainly, the main characters gender changes depending on which version you patch: Mark or Mint (default names). Pick the one you like. 

Thanks for playing!