---------------------------------------------------------------------------------------------------------------------------
	Introduction
---------------------------------------------------------------------------------------------------------------------------

Hello, Tallgeese here.

Normally, when X equips all four of his Armor Parts in Xtreme 2, his capacity for Parts made from DNA Souls is suddenly and irreversibly reduced from 4 to 2. This has led to players employing strategies such as not completing the armor by having Zero use his identical head piece, as Zero does not receive a similar nerf for fully collecting his Power-Up Parts. To address that discrepancy, this simple hack sets fully-armored X's Part capacity to 4.

The patch labeled MMXtreme2-ArmoredX4PartCapacity is for the US version, while the one labeled RMX2SoulEraser-ArmoredX4PartCapacity is for the Japanese version.

After applying one of the patches, you may need to fix the ROM's checksum. Looking up Gameboy Checksum Fixer on your preferred search engine should lead to an appropriate tool.

---------------------------------------------------------------------------------------------------------------------------
	Modifications Mode
---------------------------------------------------------------------------------------------------------------------------

Only one instruction was changed. The address differs based on the version.

ROM Address (US): 1D:54AD
ROM Address (JP): 1D:54A7
Modified Instruction: 0604 (ld b, 04)
Original Instruction: 0602 (ld b, 02)

---------------------------------------------------------------------------------------------------------------------------
	Credits
---------------------------------------------------------------------------------------------------------------------------

Encouragement: Hollow Zero (https://x.com/hollow0zero)
Testing: rokusasu.xiii on Discord
And You as Mega Man X