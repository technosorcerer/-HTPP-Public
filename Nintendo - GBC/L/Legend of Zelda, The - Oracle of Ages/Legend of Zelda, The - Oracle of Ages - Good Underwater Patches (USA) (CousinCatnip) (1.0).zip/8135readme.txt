- - -

The Legend of Zelda: Oracle of Ages - Good Underwater Patches
Created by CousinCatnip & Menblock
For the USA/Australia Version

- - -

Two different patches for The Legend of Zelda: Oracle of Ages for the Game Boy Color that fix the infamous underwater waves and swimming controls.
You can apply these patches at any point in your quest so do not worry about breaking your save!

GOOD SWIMMING = You can swim with the Mermaid Suit using regular movement now without having to tap the d-pad each time
NO WATER WAVES = When underwater with the Mermaid Suit, there will no longer be the wavy underwater line effect on screen anywhere

- - -

How to Patch:
-Choose which patches you want to apply (the order does not matter if you use both) 
-Open the patch(es) with an IPS Patcher like Lunar IPS
-Apply the patch(es) to the USA/AUSTRALIA VERSION of The Legend of Zelda: Oracle of Ages

- - -

Thank you!
If you encounter any issues or glitches, please let me know!

- - -
