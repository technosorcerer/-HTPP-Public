In the Zatch Bell Makai Reborn discord someone brought up how odd
the stage title for the "Tia stage" looks, it reads "Mtn" I got curious
and checked with the original Japanese ROM and found that graphic to be
a single kanji, so I thought that's why they couldn't write "Mountains"
in there.

Fast-forward a few weeks, I've reached a point in my translation effort
for the 2nd GBA Zatch game where certain graphics would look a lot nicer
if only I could get a little more space!

After some research I found that many GBA games expose their tilemaps
as is on the ROM, so I start up the game on an emulator go to the spot
with the graphics and look at the active RAM, after locating the map
I start documenting which tiles are which.

After that, I just take the tiles from something else and use that new
space for my longer graphics.

For Electric Arena 1, the stage name "Mysterious Boulder Island" has
all the needed tiles for writing "Mountains" by taking out the bit that
says "Boulder" and arranging the tiles again.

One could go the extra mile and use better tiles for the space but I
found this to be good enough.

The included cheats file an be loaded with mGBA, it allows viewing an unused item in the Zatch Collection mode. The Japanese text reads: "Kind King Certificate" the cheat code won't save your data, but the item CAN be unlocked with a modified savefile.

I also added some capitalization to the items in the collection.



You can find my other works here: https://www.youtube.com/channel/UCJD47CREoqENE_iLx1ZS73A

The fan translation of Electric Arena 2 is almost finished...!
