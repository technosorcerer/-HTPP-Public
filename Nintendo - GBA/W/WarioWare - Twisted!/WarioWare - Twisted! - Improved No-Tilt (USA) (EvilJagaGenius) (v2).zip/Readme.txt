WarioWare - Twisted!  Improved No-Tilt
by EvilJagaGenius

The existing no-tilt patch for WarioWare Twisted works rather well on original hardware, but on some emulators like mGBA and VBA-M it causes the game to become uncontrollable.  This patch should fix those issues, allowing you to play the game on machines with those emulators but without a gyroscope.  Use the D-pad to spin, press B to spin faster.  I have not tweaked anything else.

I'm not sure who created the original no-tilt patch, but whoever it was, I thank them for their work.  I claim very little credit here, I just made it work in mGBA.

Apply to "WarioWare - Twisted! (USA).gba", CRC32 CB4E844B

Enjoy!
- Jaga
