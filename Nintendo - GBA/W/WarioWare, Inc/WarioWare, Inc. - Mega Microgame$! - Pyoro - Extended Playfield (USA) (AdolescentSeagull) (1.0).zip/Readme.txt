WarioWare Inc - Pyoro Extended Playfield v1.0
Submitted on 11th May 2024
Created by AdolescentSeagull

This ROM hack extends the playfield, from 20 blocks to 28 blocks, with some inspiration taken from the DSi version of Pyoro, specifically for the background.

There are 4 .ips patch files and 4 .xdelta patch files, one for each region:

madeinwario is the Japanese version
warioware_us is the American version
warioware_eu is the European version
waliouzhizao is the Chinese version (iQue)
