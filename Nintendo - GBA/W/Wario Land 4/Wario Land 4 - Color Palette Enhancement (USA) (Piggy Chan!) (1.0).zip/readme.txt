------------------------------------------------
Wario Land 4 - Color Palette Enhancement
Version 1.0 by Piggy Chan! (June 2024)
------------------------------------------------
Many Game Boy Advance games have overly bright and washed out colors, as a compensation for the lack of a backlit screen on the GBA hardware.
Wario Land 4 is one such game. This patch is an attempt to give the game a more vivid and darker color palette, to be easier on the eyes and more
palatable on modern viewing hardware and monitors.

No changes were made to the game's sprite work or pixel art whatsoever - every visual change to the game was a matter of simple color palette
adjustments. It has not been tested with any other ROM hacks, but should be perfectly applicable to those which do not move or alter the game's
visuals or visual data. The only tools used were Visual Boy Advance 1.8.0 511, SNES Palette Editor, paint.exe, and LunarIPS.

Please apply the IPS file patch to a copy of Wario Land 4 (UE) [!]. It has not been tested with any other versions of the game.

Please report any bugs or flaws to the author.

Tools Used:

Lunar IPS
SNES Palette Editor
paint.exe