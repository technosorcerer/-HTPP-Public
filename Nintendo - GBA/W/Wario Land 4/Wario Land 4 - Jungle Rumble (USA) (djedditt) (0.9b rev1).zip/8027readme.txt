Wario Land 4: Jungle Rumble! v0.9b by djedditt
Release date: 21/08/2023
Last update:  24/08/2023

DESCRIPTION
================================
Exciting news for Wario Land 4 enthusiasts! A groundshaking update has burst onto the scene to make your Wario adventures more vibrant—literally. Read on to discover how we're shaking things up with this "Wario Land 4: Jungle Rumble!" patch!

Rumble Functionality
    Just like the unique rumble feature originally found in "Drill Dozer" and "WarioWare: Twisted!", this patch adds comprehensive rumble support, providing tactile feedback for many in-game actions and events. Feel every smash, dash, and transformative twist as Wario battles quirky bosses and uncovers hidden riches on his Game Boy Advance expedition.

Game Boy Player Compatibility
     Not limited to the handheld experience, this patch also adds rumble compatibility with the Game Boy Player for GameCube, allowing you to enjoy the game on the big screen with controller rumble. That's right, this is the first patch ever to add Game Boy Player rumble support to an offically released game!

Supported Platforms
    This patch works on most hardware and/or emulation platforms, including:

    - GameCube with Game Boy Player
    - EZ-FLASH Omega Definitive Edition flashcart
    - insideGadgets 32MB 256Kbit FRAM rumble flashcart
    - MiSTer
    - Analogue Pocket*
    - mGBA


Enough chat—let’s get greedy! Snatch the opportunity now and dive straight into Wario Land 4: Jungle Rumble! And if it shakes up your game the way Wario would shake down a treasure chest, feel free to leave a review on ROMhacking.net

----
*Note: openFPGA-GBA core users would have to apply the included hackfix


ROM/ISO INFORMATION
================================
Filename taken from the No-Intro database.

- Wario Land 4 (USA, Europe)
- CRC32: D6141609
- MD5: 5FE47355A33E3FABEC2A1607AF88A404
- SHA-1: B9FE05A8080E124B67BCE6A623234EE3B518A2C1


CHANGELOG
================================
21/08/2023 - v0.9
- Initial public release
- It's Wario Land 4's birthday, happy 22nd anniversary!

22/08/2023 - v0.9a
- Hotfix for crash when keyzer enters lock after completing a level

24/08/2023 - v0.9b
- Hotfix for crash when Diva mask picks up Wario


CONTACT
================================
If you have any questions, want to report bugs or just say hi, don't hesitate to contact me at djedditt@msn.com


