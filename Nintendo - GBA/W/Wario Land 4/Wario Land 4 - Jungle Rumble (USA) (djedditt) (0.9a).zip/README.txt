Wario Land 4: Jungle Rumble patch v0.9a by djedditt
Release date: 21/08/2023
Last update:  22/08/2023

DESCRIPTION
================================
Introducing the elusive Wario Land 4: Jungle Rumble patch, which injects an exciting tactile dimension into your treasure-hunting adventure for Game Boy Advance.

Rumble Functionality
    This patch adds comprehensive rumble support, immersing you deeper in the world of Wario Land 4. Experience the dashing, stomping, kicking and earthshaking action with new intensity as you navigate your way through the Golden Pyramid, nestled within the heart of the jungle.

Game Boy Player Compatibility
    Not limited to the handheld experience, this patch also adds rumble compatibility with the Game Boy Player for Nintendo GameCube, allowing you to enjoy the game on the big screen with controller rumble. That's right, this is the first patch to add Game Boy Player rumble support to a previously released game!

Supported Platforms
    This patch works on most hardware and/or emulation software, including:

    - Nintendo GameCube with Game Boy Player
    - EZ-FLASH Omega Definitive Edition flashcart
    - insideGadgets 32MB 256Kbit FRAM rumble flashcart
    - MiSTer hardware emulators
    - mGBA emulator

Transitioning seamlessly from supported platforms to exciting possibilities, get ready for a rumble-enhanced adventure that's set to redefine your Wario Land 4 experience. Enjoy!


ROM/ISO INFORMATION
================================
Filename taken from the No-Intro database.

- Wario Land 4 (USA, Europe)
- CRC32: D6141609
- MD5: 5FE47355A33E3FABEC2A1607AF88A404
- SHA-1: B9FE05A8080E124B67BCE6A623234EE3B518A2C1


CHANGELOG
================================
21/08/2023 - v0.9
- Initial public release (v0.9)
- It's Wario Land 4's birthday, happy 22nd anniversary!

22/08/2023 - v0.9a
- Hotfix for crash when keyzer enters the lock after completing a level


CONTACT
================================
If you have any questions, want to report bugs or just say hi, feel free to send me a message at djedditt@msn.com
