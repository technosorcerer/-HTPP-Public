+----------------------------------------+
| Galuf Bonus Job Battle Sprites in FFVA |
+----------------------------------------+

  | Introduction
  +--------------------------------------
    Galuf can’t access the bonus jobs or mime via normal means in the vanilla game. So, the developers didn’t bother with making battle sprites for those selections.

    The bonus jobs include Necromancer, Oracle, Cannoneer, and Gladiator.

    Any tinkerer who’s tried accessing those jobs or mime using Galuf will discover what ensues. Galuf turns invisible in battle, but the game remains (otherwise) playable.


  | Features
  +--------------------------------------
    - This patch adds the “missing” battle sprites to the game.
    - This is a GBA version of a similar patch for Mime Galuf on SFC, based in turn on the Whirlwind hack.
    - Community interest in this specific feature prompted its release as a standalone patch.
    - The patch has been tested with the US version of FFVA, as shown in the provided screenshots.
	- NEW! Version 1.1 now features custom sprites.
    - Support for this patch is available via the Whirlwind Discord.


  | Use With
  +--------------------------------------
    Database match: Final Fantasy V Advance (USA)
    Database: No-Intro: Game Boy Advance (v. 20210227-023848)
    File/ROM SHA-1: 492789276EAA3E94152B143AD92F310B8A3D5366
    File/ROM CRC32: 7A24AB0C


  | Tools Used
  +--------------------------------------
    - Mesen2 by SourMesen
    - FF6Tools by everything8215
    - FLIPS by Alcaro


  | Related Hack
  +--------------------------------------
    Final Fantasy V: Whirlwind (SFC)
    https://www.romhacking.net/translations/7324/


  | Platform
  +--------------------------------------
    Game Boy Advance (GBA)


  | Game Credits
  +--------------------------------------
    - TOSE, developer porting the game from SFC to GBA.
	- Square, publisher of the GBA port.
    - Nintendo, licensor for the game to be developed and published for the GBA.


  | Version History
  +--------------------------------------
    Version 1.1 submitted on July 15, 2024 for release.
    Version 1.0 released on June 12, 2024.


  | License
  +--------------------------------------
    MIT License


  | Contributors
  +--------------------------------------
    clymax - hack creator
    https://cIymax.github.io/

    Zetawilk - custom sprite work for version 1.1
    https://www.romhacking.net/forum/index.php?action=profile;u=101351