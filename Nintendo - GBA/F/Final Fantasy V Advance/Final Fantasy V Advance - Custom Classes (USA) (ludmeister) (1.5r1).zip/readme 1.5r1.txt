Final Fantasy 5 Advance for GBA- Ludmeister's Custom Classes Mod v1.5, rev. 1
	http://jeffludwig.com/
******************************************************************************

This patch kit will convert a stock version of Final Fantasy 5 Advance to 
Final Fantasy 5 Advance for GBA- Ludmeister's Custom Classes Mod v1.5.  Here's 
exactly what this will accomplish:

This mod aims to improve the customization options for your party in Final
Fantasy 5 Advance.  You are allowed the maximum leeway granted by the game's
engine to assign commands and abilities that you have earned as you progress
through the game.  More care must be taken so that you don't employ unwinnable
strategies (such as forgetting to set a "Fight" command to your characters...!)

Spells and monsters have been modified slightly and hopefully are balanced
with the customization options available to the player.


Notice, effective March 1st, 2012 
******************************************************************************

	For this release and all new releases, I am discontinuing the use of 
	IPS2EXE to create patches that can be applied without an IPS patching 
	program.  These executable patches set off certain virus and malware 
	scanners.  



Version 1.5 Changelog
******************************************************************************

  * The order that Jobs are opened during the game has been altered significantly.
    The final four Advance jobs are opened before you leave the first world, 
	leaving only the Mime class to be learned later.
	
  * Character stats are now calculated differently.  Jobs are less important
    in the stat makeup of characters.  Bartz, Lenna, Galuf, Faris, and Krile 
	lend their personalities to the job they are in, so Faris might have more
	agility than magic power, even as a Black Mage!  
	
  * When characters set their abilities, they no longer establish a minimum for
    their dependent stats (for instance, White Lv. 1 ensured that the character
	would have at least 39 in Magic Power).  Instead, they confer bonuses to their
	respective stats.  Almost all abilities grant a bonus to stats (for instance,
	Item gives +5 Agility).

  * Each job now has the correct passive abilities automatically assigned.
  
  * When a job which has passive abilities is mastered, those passive abilites
    become permanent on the character, no matter which job they currently are
	studying.  For instance, master the Ninja class and you will always be able 
	to equip two one-handed weapons!  The only exception to the passive skill rule
	is Berserk-- thankfully.
	
  * Due to the early opening of the Necromancer job, the monsters that confer
    Dark Arts magic when killed have been realigned.  You can learn a few of them
	before you fight Exdeath in the merged world!

  * Due to the early opening of the Cannoneer job, some special shops have Shot type
    items in their inventory.

  * Due to the early opening of the Time Mage and Summoner jobs, the Tule magic shop
    carries two Time Magic spells and one Summoning spell.

  * Minor changes to starting equipment.
  
  * Some jobs now require a bit more ABP to master, based on the relative ease
    of opening certain jobs, and their early game availability.
	
  * A few of the early weapons shops carry a few extra weapons.  
  
  * The power of various weapons are modified.  Knives are less effective, axes
    are more effective.  The Power Staff now does damage, in addition to berserking
	targets.

  * Silver Harps, Dream Harps, and Lamia Harps do much more damage than they used to.
    On average they do 4x more damage.  Harps are a viable strategy to use now.
	
  * Like Final Fantasy 3 DS, the Freelancer can cast Lv. 1 White and Black magic, 
    but without actually learning those skills.  However, true to Custom Classes form,
	those abilities can be reassigned to whatever you want.
	
	


Version 1.0 Changelog
******************************************************************************

  * All classes allow you to choose 3 commands, allowing maximum customization 
	of your party. 
	
  * Most classes have a class specific ability in their first slot.  For 
	example: the Monk has Kick for 1st slot ability.  Note: this means that 
	unless the character is in a stock warrior-type class, the first ability
	does not default to "Fight", and no character has "Item" as their default
	fourth ability... so extra care will have to be taken as abilities are
	assigned.
	
  * All characters have automatically "learned" the Fight and Item abilities, 
    and as such can assign them as one of their three abilities.
	
  * Certain classes have had their learned abilities tweaked slightly.
  
  * Generally speaking, weapons and armor restrictions are a bit more lenient 
	than stock FF5.  For instance, thieves are capable of using shields, or
	bows.
	
  * Slightly changed the powers of certain spells to balance out the skill sets.
    
	  o	Spells edited include: Aero, Aera, Aeroga, Cure, Cura, Fire, Blizzard, 
		Thunder, Fira, Blizzara, Thundara, Drain, Bio, Firaga, Blizzaga, Thundaga.
	
	  o Poison inflicts damage as well as inflicting "Poison" status. It still only 
		targets one enemy.
		
	  o Holy and Flare can target one/all enemies.
	  
	  o Dark Arts abilities inflict damage based on their level (this wasn't 
	    well implemented in stock Final Fantasy 5 Advance.)
		
  * All monsters give at least some experience and gil.  This change is 
	particularly significant concerning bosses.

  * Monsters show more varied in HP and defense ratings.

		

To convert your stock Final Fantasy 5 Advance ROM:
******************************************************************************

The following applies this and all future releases of the Ludmeister's FF5a: Custom Classes mod.

0. First of all, you will need to obtain a clean GBA ROM of Final Fantasy 5 Advance. 
   You are on your own for this step, as it is illegal to provide ROMs of copyrighted
   material. There are sites that do provide this ROM though, and you should be able
   to obtain it.

1. When you get it, make a backup of it if you would want to play the stock version, 
   play another mod, or, in case I post an updated version of the mod here... I am not 
   going to make version 1.0 to "version whatever" patches for my mods, for instance.
   
2. Download Ludmeister's Custom Classes mod.
  
3. Use the IPS patching program of your choice to apply the .ips patch to the 
   correct ROM.  As I use IPS XP (http://home.arcor.de/minako.aino/ipsXP/) to
   create my patches, I recommend using this program to patch your ROM.
	    
4. I hope you enjoy it!

