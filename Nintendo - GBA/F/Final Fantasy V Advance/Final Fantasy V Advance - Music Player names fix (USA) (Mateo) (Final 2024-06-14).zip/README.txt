Final Fantasy V Advance Music Player names fix
by Mateo

For some strange reason, Square Enix used the names from the PS1 translation for Lenna (Reina) and Exdeath (X-Death) in Final Fantasy V Advance's Music Player only. These names are only used there and are inconsistent with the names used in the rest of the game, which uses the names from the GBA translation. It's also worth noting that Reina is actually a mistranslation (レナ in katakana can be Romanized as Lenna/Lena/Renna/Rena, while レイナ can be Romanized as Reina (notice the extra i/イ)).

This patch simply changes those names to the proper accurate names that are used elsewhere in the game. Useful for those who would like everything in the game to be consistent and those who prefer the Japanese-accurate names used since Final Fantasy V Advance (as well as the SNES/SFC RPGe Fan Translation).

For use with the American version only, if you have the European one, you should use FlamePurge's "Final Fantasy V Advance Font Facelift" instead, which also changes this.

Instructions
-------------
Rename the patch to the same name as your ROM or alternatively patch the ROM with your favorite IPS patching utility (this allows it to be used with other patches).

Special Thanks
---------------
Romhacking.net for hosting this patch and several other awesome patches.
FuSoYa for the still great Lunar IPS patching utility.
Square Enix for having made this classic.
You, for trying out my patch :)