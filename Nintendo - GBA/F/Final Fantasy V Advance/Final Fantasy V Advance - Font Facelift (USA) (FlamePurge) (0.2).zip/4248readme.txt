                                      FINAL FANTASY V ADVANCE
                                       EUROPEAN FONT FACELIFT
                                         v0.2 (Sep 29 2021)

Quick Find: Press Ctrl + F and type in the keyword, then press Enter to search for the section.


      TABLE OF CONTENTS
     Disclaimer .. [DSC1]
     Changelog ... [CHG2]
     Credits ..... [CRD3]

====================================================================================================
Disclaimer [DSC1]
==========
- Final Fantasy V Advance (c) Square Enix. All rights reserved.


- No ownership is claimed by FlamePurge over Final Fantasy V or the franchise from which it
   originates. Commercial use of this patch, including but not limited to reproduction, sale, etc.
   is strictly prohibited.


- This unofficial, fan-made patch is provided "as-is" on a voluntary (i.e. non-profit) basis.
   FlamePurge is not liable for damage incurred to the end-user, their OS, or their hardware while
   using this patch.


- Apply this patch only to "Final Fantasy V Advance (E) (Eternity).gba" with the following
   specifications.

     Hashes: CRC32 - 7197117E
               MD5 - EBC874A9FFABAACD7EA1A3E128DD97D3
              SHA1 - 4FC4BC7C1C3ABE9D2F9C59A3AE4172B5CB57BD2C


- Players are encouraged to keep a backup of their original game file in case an error occurs.


- There are 2 patches enclosed. Choose 1 of the following.

   * FFVA_FontFacelift_v02_SLIM.ips
      Evens out and cleans up the thin menu font intended for the PAL release of the game. The width
      of the letters remains unchanged,

   * FFVA_FontFacelift_v02_THICK.ips
      Widens various lowercase letters for readability. There are text spillovers with the four
      non-English languages.
====================================================================================================

====================================================================================================
Changelog [CHG2]
=========
v0.2

- For both the slim and thick variants, modified the lowercase l of the menu font to appear more
   like that of the dialogue font. This distinguishes the I and l more easily.


- For both the slim and thick variants, modified the lowercase g to resemble the one used in FFIV
   DS.


- In the Music Player, corrected Lenna's name in all other relevant languages.

----------------------------------------------------------------------------------------------------

v0.1

- Modified the menu font to look more like the one used in the US release. It�s still the same size,
  just prettier. The Music Player font followed suit.


- Made a thicker variant of the menu font; the Music Player font is still its original width in this
  patch. There will be two patches.


- In both patches, replaced the white mallet icon with FFIV's hammer icon.


- In both patches, embellished the broadsword icon so it's more distinguishable from the longsword
  icon.


- In both patches, thinned the exclamation and question marks (As well as the inverted ones) in the
  dialogue font.


- In both patches, changed the names of a few music tracks.
 (Reina�s Theme         > Lenna�s Theme
  X-Death�s Castle      > Exdeath�s Castle
  The Evil Lord X-Death > The Evil Lord Exdeath)
====================================================================================================

====================================================================================================
Credits [CRD3]
=======
- Stealth Translations: Windhex32

- HoRRoR: Square Enix Remakes Font Editor

- Dragonsbrethren: Original font research

- Square Enix

...and all you Final Fantasy fans out there!
====================================================================================================