Final Fantasy 5 Advance for GBA- Ludmeister's Custom Classes Mod v1.0
	http://jeffludwig.com/
******************************************************************************

This patch kit will convert a stock version of Final Fantasy 5 Advance to 
Final Fantasy 5 Advance for GBA- Ludmeister's Custom Classes Mod v1.0.  Here's 
exactly what this will accomplish:

This mod aims to improve the customization options for your party in Final
Fantasy 5 Advance.  You are allowed the maximum leeway granted by the game's
engine to assign commands and abilities that you have earned as you progress
through the game.  More care must be taken so that you don't employ unwinnable
strategies (such as forgetting to set a "Fight" command to your characters...!)

Spells and monsters have been modified slightly and hopefully are balanced
with the customization options available to the player.



Notice, effective March 2nd, 2012 
******************************************************************************

	For this release and all new releases, I am discontinuing the use of 
	IPS2EXE to create patches that can be applied without an IPS patching 
	program.  These executable patches set off certain virus and malware 
	scanners.  



Version 1.0 Changelog
******************************************************************************

  * All classes allow you to choose 3 commands, allowing maximum customization 
	of your party. 
	
  * Most classes have a class specific ability in their first slot.  For 
	example: the Monk has Kick for 1st slot ability.  Note: this means that 
	unless the character is in a stock warrior-type class, the first ability
	does not default to "Fight", and no character has "Item" as their default
	fourth ability... so extra care will have to be taken as abilities are
	assigned.
	
  * Certain classes have had their learned abilities tweaked slightly.
  
  * Generally speaking, weapons and armor restrictions are a bit more lenient 
	than stock FF5.  For instance, thieves are capable of using shields, or
	bows.
	
  * Slightly changed the powers of certain spells to balance out the skill sets.
    
	  o	Spells edited include: Aero, Aera, Aeroga, Cure, Cura, Fire, Blizzard, 
		Thunder, Fira, Blizzara, Thundara, Drain, Bio, Firaga, Blizzaga, Thundaga.
	
	  o Venom inflicts damage as well as inflicting "Poison" status... and can 
		target one/all enemies.
		
	  o Holy and Flare can target one/all enemies.
	  
	  o Dark Arts abilities inflict damage based on their level (this wasn't 
	    well implemented in stock Final Fantasy 5 Advance.)
		
  * All monsters give at least some experience and gil.  This change is 
	particularly significant concerning bosses.

  * Monsters show more varied in HP and defense ratings.

		

To convert your stock Final Fantasy 5 Advance ROM:
******************************************************************************

The following applies this and all future releases of the Ludmeister's FF5a: Custom Classes mod.

0. First of all, you will need to obtain a clean GBA ROM of Final Fantasy 5 Advance. 
   You are on your own for this step, as it is illegal to provide ROMs of copyrighted
   material. There are sites that do provide this ROM though, and you should be able
   to obtain it.

1. When you get it, make a backup of it if you would want to play the stock version, 
   play another mod, or, in case I post an updated version of the mod here... I am not 
   going to make version 1.0 to "version whatever" patches for my mods, for instance.
   
2. Download Ludmeister's Custom Classes mod.
  
3. Use the IPS patching program of your choice to apply the .ips patch to the
   correct ROM.  As I use IPS XP (http://home.arcor.de/minako.aino/ipsXP/) to
   create my patches, I recommend using this program to patch your ROM.
	    
4. I hope you enjoy it!

