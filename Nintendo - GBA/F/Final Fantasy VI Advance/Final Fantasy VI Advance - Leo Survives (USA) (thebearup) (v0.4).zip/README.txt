FF6 GBA Leo Patch v0.4
A very simple hack that replaces Gogo with Leo.
You should be able to recruit him either in Thamasa (WoR) or Gogo's cave.
Apply the patch using Beat patcher (https://www.romhacking.net/utilities/893/)
Bugs/Warnings
- This patch should be applied before recruiting Gogo/Leo.
  Various essentials (palette, skills, etc) are set upon recruitment.
  So if you've already recruited Gogo (prior to applying the patch)
  you'll have mixed results :)
- Leo will "learn" magic in the same way as Gogo (not from espers, but from other
  party members).
- You can modify Leo's skills (just like Gogo). But if you replace Shock,
  you cannot reselect it.
- Gogo/Leo cannot equip swords, so if you unequip the Crystal sword, you can't
  reequip it.

The zip file now includes a .srm file. 
The party is just outside of Thamasa, so you can quickly recruit Leo :)

This patch was made using ff6tools; credit to everything8215 for making this
excellent toolset.
https://github.com/everything8215/ff6tools