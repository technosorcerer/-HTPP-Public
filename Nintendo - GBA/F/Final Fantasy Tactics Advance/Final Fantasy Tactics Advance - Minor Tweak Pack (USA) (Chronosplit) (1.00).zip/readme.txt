﻿Instructions: Apply this patch on a clean ROM.  All of these things can be used together.  This whole collection should be able to be used with most hacks as well, outside of those which alter jobs available at the start of the game to something else (and Hume jobs in general for Marche’s specific patches, however that would only effect that one specific altered job).

Alternate Party: remixes the beginning party in a way that shakes things up a little, but keeps the original's versatility.  I believe it goes like this:
Montblanc>Animist (also edits the tutorial battle with the Bangaas, just to change Montblanc's class and starting gear.)
Bangaa>Warrior
Nu Mou>Black Mage
Viera>White Mage
Human>Archer

Equipment is the best equal I could manage to the original party.

Marche Jobs: sets Marche's Job to what name it states on the patch from the start (any Hume job), but with equipment to match the low level of Marche's original kit.  So the weakest weapon is given, Cuirass is switched to Leather Garb/Feather Hat to replace the shield when needed, etc..  Other than that, he basically behaves like any recruited character in that he knows no abilities of any other jobs.  A couple of things to note:
-The beginning battle was used to make this change like with Montblanc (you can use both this and Alternate Party at the same time), however the text in this event is unchanged.
-Blue Mage also gives you Goblin Punch, because you have no abilities and you'd be getting it in the first scenario anyway.
-Illusionist unfortunately has the Firewheel Rod, due to it being the earliest weapon with an ability attached.  At least Paladin doesn't have a Knightsword...
-For some unknown reason Marche's innate Combo ability is hard to fandangle.  He starts in the tutorial battle with Combat Combo, and keeps it on the map.  However I have also given Marche is class's combo ability, and once you go to his ability menu and choose that Combat Combo goes to the grave unless you teach it to him as a Soldier.

Missing Items: Ensures that you won’t miss out on abilities or “secret” characters
-Refunds a Wyrmstone in A Dragon’s Aid, and an Elda’s Cup in Caravan Guard.
-Mythril Rush has the same chance as Missing Prof. To get the “secret” recruit from that mission.
-Clans Tricky Spirits and Wild Monsters now have a Goblin and Thundrake respectively.
-The missions which occur when you recruit and then kick out “secret” characters (384-387) will now have Zeus’ Mace, Materia Blade, Dark Gear, and Genji Armor as rewards.

Special thanks to:
Darthatron’s AIO editor
Thanks to Taelia, Missing Items is based on their work.
