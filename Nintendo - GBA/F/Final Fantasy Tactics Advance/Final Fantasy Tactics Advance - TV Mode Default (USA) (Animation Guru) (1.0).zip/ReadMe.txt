Like many Gameboy Advance title, the palette of Final Fantasy Tactics Advance was adjusted for bright display on GBA's notoriously dark screen.  This makes the game somewhat ugly on later platforms with better displays.  Fortunately, Square-Enix had the forethought of a TV Mode that displayed better on more vibrant screens.

Since you probably aren't playing the game on a stock Gameboy Advance anymore, this mod sets the game to TV Mode by default.  It also comes with a patch to set LCD Mode 2 as the default if, for whatever reason, you desire that.

It's a simple mod that only changes a single value, so I anticipate that there will be absolutely no bugs.  It should also be completely compatible with all other mods of the game.