[Summary]
Play as secret characters unlocked from the start:
 ● Rebel Edition: Ezel, Ritz, Shara, Doned
 ● Royal Edition: Babus, Cid (mounted), Llednar, Remedi

Both versions differ only in starting rosters. Original secret characters can still be recruited, allowing duplicates. Cid rides a chocobo and has a reworked skillset due to the removal of laws. Aside from Cid, whose mount grants improved mobility and speed, NPC stat growths were preserved. Llednar and Remedi already have defined growths in the base game despite being unplayable, and this hack uses them as-is.

[Instructions]
 ● You'll need a clean rom and a .bps patcher, such as Flips (Floating IPS):
   https://www.romhacking.net/utilities/240/
 ● Once downloaded, open flips.exe and click "Apply Patch"
 ● Select the desired .bps file, then your clean rom, then choose where to save the patched rom

[Leonarth's Hacks]
 ● JP is now earned alongside EXP and can be used to purchase abilities
 ● Laws and Judges removed
 ● Opening tutorials skipped
 ● Steal shoes via Steal: Accessory
 ● Press START to rename Marche or non-special characters

[Skillset Tweaks]
 ● Montblanc: uses standard Nou Mou jobs
 ● Babus: Explode power 40 ➜ 50
 ● Ezel: learns Meteor instead of Astra
 ● Cid: skillset reworked (see below)

[Judgemaster (Cid) Abilities]
(Some of these moves are unchanged from the base game.)
 ● Sentence: Doom and/or Immobilize + Quick
 ● Confiscate: Takes weapon and/or casts Stop
 ● Judgement: Instant KO against non-undead
 ● Judge Sword: Deals 2× damage
 ● Bind: Unchanged
 ● Counter: Unchanged
 ● Concentrate: Unchanged
 ● Palaistra: Unchanged

[Mechanics]
 ● Sentence and Confiscate check each debuff separately.
 ● If both Sentence effects land, the target dies before they can move again (unless cured).
 ● Sentence always casts Quick:
   ▫ Starts Doom counter at 2
   ▫ Additional casts reduce it by 1
   ▫ On units immune to Doom/Immobilize, functions as a long-range Quicken
   ▫ If both debuffs miss, Quick may benefit the enemy (mitigated with Concentrate)
 ● Special Flags:
   ▫ Some units (e.g., Babus, Remedi, Llednar) have a Special Flag, a base-game mechanic that blocks most negative and some positive status effects (e.g., Haste, Auto-Life)
   ▫ Cid’s flag has been removed, as the Royal team already has high resistance to debuffs
 ● By design, Remedi cannot equip or use itms. To compensate for this, her stats were adjusted (see below).

[Stat Tweaks]
 ● Remedi: Movement 3 ➜ 4, Unarmed Power 10 ➜ 33
 ● Judgemaster (Cid): Speed Growth 2.4, Movement 5, Jump 4
 ● Cid: Special Flag removed, Status Def 80 ➜ 50

[Known Issues / Quirks]
 ● Llednar becomes invincible when The Quiet Sands becomes available. This is due to both Llednars sharing an Invincibility Flag, which is cleared by completing the mission.
 ● Sentence and Confiscate work properly in execution but occasionally display inaccurate hit rates:
   ▫ Sentence shows Doom chance only (not Immobilize or Quick)
   ▫ Confiscate shows weapon steal chance only (not Stop)
 ● The Link option has been disabled
 ● If you unequip Llednar’s or Remedi’s secondary skillsets (Wicca / Flair), you won’t be able to re-equip them until you’ve unlocked at least one ability from that skillset.

[Final Notes]
 ● This is a casual, NG+-style hack, not a challenge mod
 ● Save often and back up your files as standard practice
 ● Big thanks to Leonarth and Darthatron for their incredible hacking tools (linked below)

[Hacking Tools]
 ● [WindHex32](https://www.romhacking.net/utilities/291/)
 ● [HxD](https://mh-nexus.de/en/hxd/)
 ● [FFTA Engine Hacks](https://github.com/LeonarthCG/FFTA_Engine_Hacks) by Leonarth
 ● [FFTA All-In-One Editor](http://ffhacktics.com/smf/index.php?topic=9764.msg189278#msg189278) by Darthatron
