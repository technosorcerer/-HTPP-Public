Please, note that this is a .ups format patch, people seem to get confused over this.
It is not the same as an .ips patch.
Visit https://www.romhacking.net/patch/ or just use a search engine to find an ups patcher.

-- 1.3 --
Updated the engine hacks again, this solves issues with jp display, animations and item effect stacking and others
	Check https://github.com/LeonarthCG/FFTA_Engine_Hacks for details
Added nickanming, you can now change the name of your monsters! (and also Marche's)
Added intro cutscene skip, the game now goes directly to the push start screen
Fixed an issue with the titlescreen's palette not being updated when changing color mode

-- 1.2 --
Updated the engine hacks, this solves issues with item ability display, graphics, judge jp rewards and others
	Check https://github.com/LeonarthCG/FFTA_Engine_Hacks for details
Removed the "- taken" or "X soul taken" message when capturing a monster
Pub options have been reordered for quicker access (Missions is now first)

Many times people have complained that the first mission ends up being very difficult for them.
In order to address the difficulty concerns, some extra changes have been made:
Added a level 2 Goblin and a level 2 Thundrake to the starting party, feel free to release them if you want a harder fight
Capture rate increased by a flat 10%
Starting Capture Orbs raised from 6 to 10

-- 1.1 --
Made the game possible to 100%* by tweaking the requirements for the "Fiend Run" mission.
	*Link missions not included.

-- 1.0 --
Main changes:
All starting clan members have been removed, except Marche and Montblanc
The Monster Bank has been removed
Jail has been removed
The job requisites for dispatch missions are ignored, any monster can go on any dispatch mission
Cureall has been renamed to Capture Orb, which works like the Capture ability, but has a fixed range of 4
Capture Orb is available from the start, all shops have it
You start with 6 Capture Orbs, but start with no Antidotes or Bandages
Capture now sends monsters to the party instead of to the Monster Bank (although it also unlocks them in the Monster Bank)
Capture now works with all monster species (obviously not totemas and such)
Capture rate calculation changed from [(max hp - curr hp)/4]% to [max hp - curr hp]%
Humanoid recruits (should be) removed
You CAN spam the "X Wanted" missions for 20 AP I guess, but you won't get new units and it's a waste of 300 gold, I think
All Soul weapons sell value has been set to 0

Other engine hacks, available in my github page as standalones:
JP learning is included, which is the only way to teach monsters new abilities
	Units earn JP whenever they earn EXP
	Combos and Totema summoning are disabled
	To purchase abilities go to the abilities menu and select an ability
Judges are gone, laws do nothing
Quick Start is in so the tutorial is skipped
Shoes are stealable with Steal: Accessory
Manual Sorting is in, you can swap units around in the party menu

You can find the engine hacks here: https://github.com/LeonarthCG/FFTA_Engine_Hacks
