******************************************
Fire Emblem: The Second Scouring
        --- by THE 1 ---

******************************************

About

This is a fan-made sequel to Fire Emblem:
The Binding Blade. It features a new, lore
friendly (to the best of my abilities)
story with Roy returning as the main
protagonist. It was made in a two-month
period using FEBuilder in my spare time.

The goal of this hack is to provide people
who enjoy the gameplay of the original
Binding Blade with new challenges, new
strategies and a new story. Players are
recommended to have played through the
original game on hard mode before playing
this hack, as it was designed with a
challenging but fair difficulty in mind.

******************************************

Features

- A new story with many twists and turns.
- 24 brand new chapters, some on familiar
grounds, but most on newly designed
terrains.
- 7 new playable characters with newly
written support conversations.
- Altered stats for the returning
cast, though they mostly stay true to
their characteristics in the original
game.
- Altered weapon balancing, though the
more common weapons were not changed
greatly.
- Adjusted support conversations to keep
the dialogue consistent with events that
transpired in the Binding Blade.

******************************************

How to play

1. Unpack the .rar file.

2. Patch the original Japanese ROM that
you have using the unpacked UPS file. It
is a very simple process, most easily done
using this tool:
https://www.romhacking.net/patch/

Note: Only clean ROMs can be patched,
meaning they cannot already be translated
or otherwise modified.

******************************************

Special thanks

- Nintendo, for making the incredible
game that this hack is based on.
- The person/people who made the
unofficial English translation, making
this possible.
- RHDN user MageBoy, for helping with
debugging and general feedback. 
- The people behind FEBuilder.