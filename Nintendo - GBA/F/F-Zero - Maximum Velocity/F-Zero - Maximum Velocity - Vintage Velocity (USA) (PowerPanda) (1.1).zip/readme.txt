F-ZERO: VINTAGE VELOCITY

-=Story=-
In the decades since the F-Zero races began, mankind's search for new horizons has brought F-Zero racing to many new planets. With Synobazz and Beacon Port now household names, many have forgotten where F-Zero racing all began. The 15 original courses have fallen into disuse and disrepair.

Now, a quarter century later, after receiving a grant from an anonymous donor, the F-Zero organizers have restored the vintage tracks to their former glory, inviting the top racers of their day to a special, limited Grand Prix. With all of the changes to racing over the years, can the new generation master the courses that made their childhood heroes famous... the Vintage Grand Prix?

----------------------------------------------------------------------------
-=Overview=-
Vintage Velocity is a remake of the 15 courses and 3 Series (Knight, Queen, King) from the original SNES game within the Maximum Velocity game engine. Play through these familiar courses with a very different feel. You can play solo, or link up to 4 other people running the same rom to race with up to 4 players. A mysterious new series, the Rook series, can be unlocked by beating the 3 regular series on Expert.

The data for the courses is pulled from GP Legend and Climax's Platinum Cups, whenever possible. Some modifications were made to courses to account for Maximum Velocity's differing physics engine. The 5 SNES courses that were not present in GP Legend or Climax have been remade within the GBA format.

----------------------------------------------------------------------------
-=Version 1.1=-

Version 1.1 adds a new title screen by TSP184 to the International version of the patch. The Japanese patch remains the same, since the title "F-Zero for Gameboy Advance" still applies to Vintage Velocity.

----------------------------------------------------------------------------
-=Patching Instructions=-

Two files are included in the package: VintageVelocityJP.ips, which applies to the Japanese version of the game, and VintageVelocityINT.ips, which applies to the International version of the game released in the US and EU. You can apply the IPS patch to an unmodified copy of the US/EU Maximum Velocity rom. This can be done either through Romhacking.net's online patcher, or through an IPS patching program such as Lunar IPS.

----------------------------------------------------------------------------
-=Box Art=-

You can find the box art, liner notes, and logo here:
https://imgur.com/a/RMhuhZl

----------------------------------------------------------------------------
-=Compatibility and Multiplayer=-

Vintage Velocity has been tested on all common emulators, original hardware, DS, and 3DS. It should run on anything that runs Maximum Velocity. It DOES support multi-pak multiplayer via link cable. You can race against friends on any of the courses. It does not support single-pak multiplayer, and the option has been removed from the menu.

Multi-pak multiplayer does work, both on original hardware and on emulation. Please refer to guides for your specific emulator on how to get linked games working; there are no special steps for Vintage Velocity. As a side-note, Vintage Velocity and Maximum Velocity can link up, with players racing on 2 different courses. While this is great for comedic value, for obvious reasons, it cannot be recommended.

----------------------------------------------------------------------------
-=Q&A=-

Q: How were these made? Is there a Maximum Velocity editor?
A: A basic editor was built for the purposes of this project. It is not designed, intended, or suitable for public distribution.

Q: Why did you allow the Port Town skip (or other skips)?
A: Maximum Velocity does not have a UFO to bring you back to a defined point on the track. A few alternatives were tested, but utlimately, we decided to not penalize skips, IF you managed to make them.

Q: Do you have a Patreon?
A: These projects are made from our passion for the series. Since they port data from other games in the series, we do not feel it is ethical to accept money for our work.

----------------------------------------------------------------------------
-=Credits=-

GuyPerfect: Programming, Data Extraction, Level Editor
PowerPanda: Project Coordination, Course Editing and Creation
Porthor: Port Town Pathing
Title Screen: TSP184

QA Testing: Porthor, Alejandro, Catador, NeoMasterZX, Xterra, Zephyrum25, Emily Vasquez, FighBat