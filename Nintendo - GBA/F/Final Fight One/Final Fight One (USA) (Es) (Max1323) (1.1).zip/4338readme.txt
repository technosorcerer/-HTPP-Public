"Final Fight One"
Traducci�n al Espa�ol Ver. 1.1 (28/06/2019)
por Max1323 (maxmuruchi@gmail.com)
---------------------------------------------------
Descripci�n:
El clasico beat 'em up llega a GBA. La historia transcurre en 
Metro City, la capital del crimen. Los miembros de Mad Gear han 
secuestrado a Jessica la hija del nuevo alcade, Mike Haggar.
Escoge entre Cody, Guy o Haggar para enfrentarte a los miembros
de Mad Gear y rescatar a Jessica.  
 
Desarrollado: Sun-Tec
Publicado:    Capcom
Lanzamiento:  25/05/2001 (Jap�n) 
              26/09/2001 (USA)
              28/09/2001 (Europa)  
---------------------------------------------------
Acerca del proyecto:
Se tradujo los di�logos.
Se arreglaron ciertas palabras y traducir algunas cosas al final.
Agradecimiento a jonathan por buscar las palabras.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS

Final Fight One (USA).gba
File MD5      C6AF74AEEABFD6D7EE2875E355F49AF2        
File SHA-1    17918E125BCAFD44FCF3B21813575C2CCB19BD45
File CRC32    052C9997                                
File Size     4.00 MB
                              
                           
                              
                              
                             
                       
