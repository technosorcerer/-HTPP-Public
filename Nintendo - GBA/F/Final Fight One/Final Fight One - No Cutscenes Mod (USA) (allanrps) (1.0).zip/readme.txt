This is a simple hack that skips the cutscenes before and after bosses, allowing you to play the game through with no interuptions.

Credit goes to infval on reddit, who figured this out.
