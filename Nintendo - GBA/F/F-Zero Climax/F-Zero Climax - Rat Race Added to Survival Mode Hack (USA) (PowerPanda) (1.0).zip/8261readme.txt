Title: F-Zero Climax - Rat Race Added to Survival Mode
Author: PowerPanda
Version: 1.0
Applies to: F-Zero: Climax (All Versions)

Contents:	fzc_ratrace.ips - The patch for all roms

--------------------------------------------------------------------------------
-=Intro and Description=-

F-Zero Climax, like GP Legend and Maximum Velocity before it, has a race course that is exclusive to a single-pak multiplayer game. That is, 2 GBAs joined by a link cable with one GBA having an empty cartidge slot. The track's name is "Fire Field - Rat Race". When played, the track contains no music, due to the link cable data transfer limitations. While this required a specific setup on original hardware and was hard to access, it is completely inaccessible on most emulation setups.

Climax has a Survival Mode, which contains a mix of Grand Prix courses and exclusive courses. There are 4 levels of difficulty: Tour, Challenge, Battle, and Violence. The final course of the Tour difficulty is a 3-lap race around "Fire Field: Heat Circuit". This patch replaces Heat Circuit with the otherwise inaccessible Rat Race, enabling every course to be played.

--------------------------------------------------------------------------------
-=Patching Instructions and Compatibility=-

This patch can be applied to the Japanese original rom and both the English and Spanish translations done by the "F-Zero Climax: Translation Project Team". Neither of the translation projects re-order the portions of the rom that hold the course lists. It can be applied with Lunar IPS.

--------------------------------------------------------------------------------
-=Credits=-
Hacking: PowerPanda

Programs Used: HxD (Hex Editing), no$gba (Debugging), VBA (Testing)
--------------------------------------------------------------------------------
-=Code Changes=-

09/93F8 > Change from 0B (Fire Field: Heat Circuit) to 36 (Fire Field: Rat Race)