Title: F-Zero: GP Climax
Author: PowerPanda
Version: 1.1
Applies to: F-Zero: Climax (JP original and translations)

Contents:	fz_gp_climax.ips - The patch for all versions

--------------------------------------------------------------------------------
-=Intro and Description=-

F-Zero Climax has the largest list of playable courses of any F-Zero Game. Grand Prix mode alone has 53 courses, split across the Novice/Standard, Expert, and Master difficulties. Just like its predecessor, GP Legend, almost all of the courses in the game have harder variants when you get to the Expert and Master difficulties. Some even have a 3rd level of difficulty. Unlike GP Legend though, it's not always clear which courses are harder variants of which.

There are two things that obscure the courses' relations. First, many of the variants don't share a name with the track they are based on. For example, based on name alone, there's no way to know that "Big Blue: Arch Hill" is a harder variant of "Big Blue: Slalom", but has no relation to "Big Blue: Slip Down". Second, the courses do not always appear in the same cups, or even the same race slots. "Big Blue: Slalom" is the 1st race of the Silver Standard Cup, but "Big Blue: Arch Hill" is the 3rd race of the Bronze Expert Cup. Overall, this makes Climax feel like a less-cohesive game than GP Legend. (It also make finding a specific track in Time Attack a chore!)

This patch, GP Climax, presents the courses in the same way as GP Legend, with harder versions of courses appearing in the same cup, and for the most part, the same race slot. 10 of the 53 courses have been swapped between Cups, and 5 of the 9 Cups have had their tracks re-ordered. This gives each Cup its own self-contained identity. Because this patch simply re-orders content from the original game, without changing any of the content, it is appropriate to use during a first playthrough.

Lastly, GP Climax contains the smaller patch "Rat Race Added to Survival Mode". This patch is somewhat self-explanatory... in Survival Mode, Tour difficulty, the Grand Prix course "Fire Field: Heat Circuit" is replaced with "Fire Field: Rat Race". Rat Race was previously only accessible through a single-pak link cable game, and was inaccessible for most emulation setups. Fire Field: Heat Circuit is still in Grand Prix mode, so it is still playable.

--------------------------------------------------------------------------------
-=Grand Prix Course Listings=-

Key
+Course Replaced
#Course Reordered

ORIGINAL ROM				|	PATCHED ROM
=====================================================================================
=BRONZE		NOVICE/STANDARD=	|	=BRONZE		NOVICE/STANDARD=
Mute City	Six Carat		|	Mute City	Six Carat
Sand Ocean	High Speed Edge		|	Sand Ocean	High Speed Edge
Port Town	Sky Highway		|#	White Land	Wolf
White Land	Wolf			|#	Port Town	Sky Highway
Fire Field	Heat Circuit		|+	Red Canyon	Inside Out
					|
=BRONZE		EXPERT=			|	=BRONZE		EXPERT=
Mute City	Eight Carat		|	Mute City	Eight Carat
White Land	White Wolf		|+	Sand Ocean	High Speed Edge II
Big Blue	Arch Hill		|#	White Land	White Wolf
Port Town	Sky Highway II		|	Port Town	Sky Highway II
Red Canyon	Inside Out II		|+	Fire Field	Heat Circuit
					|
=BRONZE		MASTER=			|	=BRONZE		MASTER=
Red Canyon	Barrel Roll		|#	Mute City	Ten Carat
Sand Ocean	High Speed Edge III	|	Sand Ocean	High Speed Edge III
Lightning	G-Trace			|#	White Land	Last Wolf
Mute City	Ten Carat		|+	Red Canyon	Inside Out II
White Land	Last Wolf		|+	Fire Field	Burnt Out Rink
________________________________________|___________________________________________
=SILVER		NOVICE/STANDARD=	|	=SILVER		NOVICE/STANDARD=
Big Blue	Slalom			|	Big Blue	Slalom
Red Canyon	Inside Out		|+	Mute City	Cactus Circuit
Mist Flow	Double Link		|	Mist Flow	Double Link
Fire Field	Front Line		|	Fire Field	Front Line
Silence		Nightmare		|	Silence		Nightmare
					|
=SILVER		EXPERT=			|	=SILVER		EXPERT=
Sand Ocean	High Speed Edge II	|+	Big Blue	Arch Hill
Lightning	Trust Jump		|	Lightning	Trust Jump
Mist Flow	Mist Ring		|	Mist Flow	Mist Ring
Mute City	Cactus Circuit		|+	Red Canyon	Barrel Roll
Fire Field	Burnt Out Rink		|+	Silence		Nightmare Fear
					|
=SILVER		MASTER=			|	=SILVER		MASTER=
Mute City	Cactus Circuit II	|#	Lightning	Loss Landing
Mist Flow	Puzzle Ring		|#	Mute City	Cactus Circuit II
Lightning	Loss Landing		|#	Mist Flow	Puzzle Ring
Fire Field	Front Line II		|	Fire Field	Front Line II
Silence		Nightmare One		|	Silence		Nightmare One
________________________________________|___________________________________________
=GOLD		NOVICE/STANDARD=	|	=GOLD		NOVICE/STANDARD=
Lightning	R-Trace			|	Lightning	R-Trace
Port Town	Half Dome		|	Port Town	Half Dome
Sand Ocean	Key Break		|	Sand Ocean	Key Break
Big Blue	Slip Down		|	Big Blue	Slip Down
Illusion	Lost Way		|	Illusion	Lost Way
					|
=GOLD		EXPERT=			|	=GOLD		EXPERT=
White Land	Hornet			|+	Lightning	G-Trace
Silence		Nightmare Fear		|#	White Land	Hornet
Big Blue	Single Course		|#	Sand Ocean	Key Break II
Sand Ocean	Key Break II		|#	Big Blue	Single Course
Illusion	Lost Way II		|	Illusion	Lost Way II
					|
=GOLD		MASTER=			|	=GOLD		MASTER=
Port Town	Half Dome II		|	Port Town	Half Dome II
White Land	Hornet House		|	White Land	Hornet House
Sand Ocean	Key Break III		|	Sand Ocean	Key Break III
Big Blue	Twin Course		|	Big Blue	Twin Course
Illusion	Lost Way III		|	Illusion	Lost Way III
________________________________________|___________________________________________
=PLATINUM	ALL DIFFICULTIES=	|	=PLATINUM	ALL DIFFICULTIES=
Mute City	Multiply		|	Mute City	Multiply
Big Blue	Big Billow		|	Big Blue	Big Billow
Silence		Silence II		|	Silence		Silence II
Port Town	Great Wings		|	Port Town	Great Wings
Red Canyon	Red Canyon II		|	Red Canyon	Red Canyon II
Sand Ocean	Sand Ocean		|	Sand Ocean	Sand Ocean
White Land	White Land II		|	White Land	White Land II
Fire Field	Fire Field		|	Fire Field	Fire Field
					|
=CHAMPIONSHIP=				|	=CHAMPIONSHIP=
White Land	Eagle Circuit		|	White Land	Eagle Circuit
________________________________________|___________________________________________


--------------------------------------------------------------------------------
-=Patching Instructions and Compatibility=-

This patch can be applied to the Japanese original rom and both the English and Spanish translations done by the "F-Zero Climax: Translation Project Team". Neither of the translation projects re-order the portions of the rom that hold the course lists. It can be applied with Lunar IPS.

--------------------------------------------------------------------------------
-=Credits=-
Hacking: PowerPanda, GuyPerfect
Special Thanks: Porthor, Victor Hedgehog

Programs Used: HxD (Hex Editing), 010 (Hex Editing), no$gba (Debugging), VBA (Testing)

--------------------------------------------------------------------------------
-=Code Changes=-

07/FBC6-07/FBFA	Time Trials Course List
08/603C-08/609B	Grand Prix Course List
63/A100-63/A17F	Pre-Race Preview Screen Course List
63/D0B8-63/D137	Post-Race Results Screen Course List
09/93F8		Address where Rat Race course was added