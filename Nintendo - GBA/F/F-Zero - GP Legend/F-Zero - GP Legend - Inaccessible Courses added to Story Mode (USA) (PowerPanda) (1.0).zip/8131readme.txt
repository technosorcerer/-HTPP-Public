Title: F-Zero GP Legend - Inaccessible Courses added to Story Mode
Author: PowerPanda
Version: 1.0
Applies to: F-Zero - GP Legend (All Versions)

Contents:	us_courses.ips - The patch for the US rom
		eu_courses.ips - The patch for the European rom
		jp_courses.ips - The patch for the Japanese rom

--------------------------------------------------------------------------------
-=Intro and Description=-

F-Zero GP Legend has 2 fully-programmed courses within its code that are inaccessible through normal play.
1) Big Blue: Calm Sea - This course is exclusive to a single-pak multiplayer game. That is, 2 GBAs joined by a link cable with one GBA having an empty cartidge slot. When played, the track contained no music, due to the link cable data transfer limitations. While this required a specific setup on original hardware and was hard to access, it is completely inaccessible on most emulation setups.
2) Mute City II - This course is actually a remake of the SNES Mute City III. It is speculated that the Platinum Cup would have contained Expert mode variants, but this was the only track completed. It is not used anywhere in the game.

GP Legend also has a story mode, which contains a mix of Grand Prix courses and exclusive courses. This patch replaces 2 of the story mode courses that borrow from Grand Prix with the 2 inaccessible courses.

Big Blue: Calm Sea
The final chapter of Rick's, Jack's, and Zoda's stories is an anticpated race on the planet Big Blue. When you get to the race, you find out that the course is simply Big Blue: Slip Highway, a track easily accessible in the Grand Prix Silver Cup. This patch replaces Slip Highway with Calm Sea. Calm Sea has the Big Blue music added.

Mute City: Mute City II
In Jody's and Rick's story, there is a chapter where their platoon has to race against each other. The course used for this is Mute City: Tradition Park, the first track of the Grand Prix Bronze Cup. This patch replaces Tradition Park with Mute City II. 

--------------------------------------------------------------------------------
-=Patching Instructions and Compatibility=-

Apply the correct IPS patch to your version of the rom. You may apply this before or after other patches. This patch is a low-impact patches that change single bytes in-line with the code. Unless you apply a patch that targets the same story mode chapters, this will likely be compatible.

These have been tested with, and are compatible with:
Anthony Ryuki's Port Town music fix
GuyPerfect's e+ Complete patch, which unlocks all e-reader content.
Both patches are recommeded to be used in combination with this patch, as that will allow you to play all of the F-Zero GP Legend content.

--------------------------------------------------------------------------------
-=Credits=-
Hacking: PowerPanda
Special Thanks: GuyPerfect

Programs Used: HxD (Hex Editing), no$gba (Debugging), VBA and mGBA (Testing)
--------------------------------------------------------------------------------
-=Code Changes=-

CALM SEA
All of the following addresses were changed from a value of 2A (Big Blue: Slip Highway) to 22 (Big Blue: Calm Sea):
US rom			JP rom
09/34E4			09/D830
09/388C			09/DBD8
09/3D6C			09/E0B8
50/FEE1			58/5EAF
52/1336			59/40BF
53/3F07			5A/3077

EU rom
En		De		Fr		Es		It	
09/8FA4		--		--		--		--
09/934C		--		--		--		--
09/982C		--		--		--		--
52/82EF		55/20C3 	58/034D		5A/B9C5		5D/2A0E
53/973A		56/5A6D		59/2BA2		5B/BF58		5E/4928
54/C305		57/A80D		5A/6631		5C/D421		5F/7DEA

MUTE CITY II
All of the following addresses were changed from a value of 28 (Mute City: Tradition Park) to 00 (Mute City II):
US rom			JP rom
09/3720			09/DA6C
09/3858			09/DBA4
51/B543			58/F4A0
52/0666			59/361F

EU
En		De		Fr		Es		It	
09/91E0		--		--		--		--
09/9318		--		--		--		--
53/394B		55/EF38		58/C6B6		5B/677F		5D/E776
53/8A6A		56/4BCD		59/1D9E		5B/B380		5E/3C00