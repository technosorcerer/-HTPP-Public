# Fire Emblem 7 Legacy

Fire Emblem 7 Legacy is an enhancement hack which sits as a side project in [TheSmithPlays](https://www.youtube.com/@smithplayspokemon) Legacy Series of Romhacks. If you know Smith, one of his guilty pleasures outside Pokemon Crystal is the original western Fire Emblem 7. After the completion of the Legacy trio, Smith, as per usual, decided to explore a creative project, which led to the Creation of Fire Emblem 7 Legacy. 

The Legacy games were designed with the philosophy of what Smith refers to as the “perfect” version of the game. This simply aims to imagine the the game at it’s fullest potential with 20 years of retrospect. This is achieved by making changes to make the game as optimal, engaging and fleshed out as possible while still retaining its original identity. This involves quality of life changes, tons of balancing, small map tweaks, and a lot of other small tweaks to make an overall improved or “perfect" version of the game. We want people to play this and feel like they are still playing the original game and get that blast of nostalgia but with an improved experience.

Tons of work went into this project with basically a whole new team to support it. There are so many testers and other projects we used things from that we have a whole section down below called [Credits](#credits-for-fire-emblem-7-legacy) if you want to look. We made a list of contributors to this project and a list of projects and their creators we took ideas from. We recommend checking out the games on this list if you are a fan of Fire Emblem as there are a ton of great romhacks here.

We hope you get a blast of nostalgia and enjoy playing this game with the Legacy treatment. If you enjoyed it please let us know on our [Discord, Pokemon Legacy (which has a specific Fire Emblem channel)](https://discord.gg/Wupx8tHRVS), so you can talk about it with other people and try out some of our other Romhacks on the server. 

## Download and Play

* To download the patch, see [RELEASES](https://github.com/thesmithplays/FireEmblemLegacy/releases) and download the zip file for the latest patch. Unzip the folder, then follow the instructions in one of the readme files in the `Patching Instructions` folder.


## A complete list of features can be found here:
- [The Main Doc](https://docs.google.com/document/d/1NJh9DqqKv7DK41ukvpfnqRTphNN_hftbmQ1VOZxJ2Ec/copy) is the primary source of info for Fire Emblem 7 Legacy
- These videos also provide an overview of the hack and the ideology behind it:
    - [Release 1.0](https://youtu.be/uaVsDEgaIUU)


## Our Other Projects
* [Pokemon Crystal Legacy](https://github.com/cRz-Shadows/Pokemon_Crystal_Legacy)
* [Pokemon Yellow Legacy](https://github.com/cRz-Shadows/Pokemon_Yellow_Legacy)
* [Pokemon Emerald Legacy](https://github.com/cRz-Shadows/Pokemon_Emerald_Legacy)
* [Pokemon Battle Simulator](https://github.com/cRz-Shadows/Pokemon_Trainer_Tournament_Simulator)


## Discussion and Community
* [Fire Emblem Channel](https://www.youtube.com/@SmithPlaysFireEmblem)
* [Pokemon Channel](https://www.youtube.com/@smithplayspokemon)
* [Discord](https://discord.gg/Wupx8tHRVS)
* [Reddit](https://www.reddit.com/r/PokemonLegacy)
* [Twitter](https://twitter.com/TheSmithPlays)
* [Instagram](https://www.instagram.com/thesmithplays/)

## Credits For Fire Emblem 7 Legacy:

### Developer:
- Patrick Smith ([TheSmithPlays](https://www.youtube.com/@SmithPlaysFireEmblem))
- Neil Logtenberg (Lord Niru)
- Kyle S (Sonic The Hedgedawg)


### Playtesters:
- Neil Logtenberg (Lord Niru)
- Kyle S (Sonic The Hedgedawg)
- Braden Huffman (Siel)
- ArsSanctum (Ars)
- EphemeralBlitz (Eph)
- Bailey Voigt (Minnchilla)
- TangoMangoPango420
- Σmerald Sage Cipherus
- Anguis
- ChipaWhich
- Aigis_System
- Mike O’Brien (GreilMercs)
- Shinigami Miroku
- [Imported Cheese](https://www.youtube.com/watch?v=wAO4OBjUedI)
- JanitorOPplznerf (Pokemon Legacy Team)
- Disq (Pokemon Legacy Team)


### Blind Testers:
- Codyanskaya
- Elius404
- Lord Jakob
- Sepherimorth
- Sethg98
- MoonFox91
- Manav A (edgespresso)
- Surge247
- Alder
- Verran
- Ludger K.
- neixom


### Documentation:
- Neil Logtenberg (Lord Niru)
- Aerogod223 (Pokemon Legacy Team)

### Patches installed:
- Patch Name:CasualMode  @FE7U
    - Author / Source: circleseverywhere
- Patch Name: CSA_Creator_For_FE7U  @FE7U
    - Author / Source: circleseverywhere
- Patch Name: CSA_Creator_For_FE7U_ver2  @FE7U
    - Author / Source: circleseverywhere
- Patch Name: Map Danger Zone (Select: Toggle)  @FE7U
    - Author / Source: circleseverywhere
- Patch Name: FE7-Battle Stats with Anims Off  @FE7U
    - Author / Source: [Tequila](https://feuniverse.us/t/teqs-minor-assembly-shenanigans/1655/51)
- Patch Name: Display Growths  @FE7U
    - Author / Source: [Tequila](https://feuniverse.us/t/teqs-minor-assembly-shenanigans/1655/84)
- Patch Name: HPBars and warnings  @FE7U
    - Author / Source: Circles , Transport FE7U: Tequila
- Patch Name: Staff Range Fix 2019_11_30  @FE7U
    - Author / Source: [Tequila](https://feuniverse.us/t/teqs-minor-assembly-shenanigans/1655/7)
- Patch Name: Fixes ranking to work properly on hector mode  @FE7U
    - Author / Source: [stan](https://feuniverse.us/t/need-help-with-fe-gba-hacking-fe8-fe7-seems-to-be-solved/6370/8)
- Patch Name: 01command_hack  @FE7U
    - Author / Source: Animation Hacks by Hextator  Transplant:7743
- Patch Name: Anti-Huffman  @FE7U
    - Author / Source: Anti-Huffman Patch by Hextator   Transplant:7743
- Patch Name: Press L when initiating combat to toggle animations on/off  @FE7U
    - Author / Source: [Tequila](https://feuniverse.us/t/teqs-minor-assembly-shenanigans/1655/80)
- Patch Name: MapAddInRange Efficiency Fix 20211219  @FE7U
    - Author / Source: 7743
- Patch Name: Expanded the setting of the ring effect used by dancers.(Installer)  @FE7U
    - Author / Source: 7743
- Patch Name: EXP Value in dance, steal, etc. EXP+10  @FE7U
    - Author / Source: 7743
- Patch Name: Change Effectiveness damage coefficient of the weapon(Installer)  @FE7U
    - Author / Source: 7743
- Patch Name: Enemy HP Limit(Foe HP Limit)  @FE7U
    - Author / Source: 7743


### Custom Animations:

- [Hector Base Sword Animation by Avernathy](https://github.com/Klokinator/FE-Repo/tree/main/Battle%20Animations/Lords%20-%20Vanilla%20and%20Custom/%5BFE7%20Hector-Base%5D%20%5BM%5D%20T1%20Vanilla%20%2BWeapons)
- [Eliwood Base Lance Animation by Spud](https://github.com/Klokinator/FE-Repo/tree/main/Battle%20Animations/Lords%20-%20Vanilla%20and%20Custom/%5BFE7%20Eliwood-Base%5D%20%5BM%5D%20T1%20Vanilla%20%2BWeapons)
- [Female Mercenary by TheBlindArcher](https://github.com/Klokinator/FE-Repo/tree/main/Battle%20Animations/Infantry%20-%20(Swd)%20Mercenaries%20and%20Heroes/%5BMercenary-Reskin%5D%20Generic%20%5BF%5D%20by%20TBA)
- [Prince Zephiel by Link, Teraspark](https://github.com/Klokinator/FE-Repo/tree/main/Battle%20Animations/Lords%20-%20Vanilla%20and%20Custom/%5BFE7%20Eliwood-Variant%5D%20%5BM%5D%20T1%20Prince%20Zephiel%20by%20Teraspark)
- [Merlinus Promoted by IS](https://github.com/Klokinator/FE-Repo/tree/main/Battle%20Animations/Bards%2C%20Dancers%2C%20Suppliers%2C%20Misc/%5BMisc-Supply%5D%20%5BU%5D%20T1%20Merlinus%20Transport%20%2BWeapons)
- [Matthew Assassin Reskin by Greentea](https://github.com/Klokinator/FE-Repo/tree/main/Battle%20Animations/Infantry%20-%20(Swd)%20Thieves%2C%20Rogues%2C%20Assassins/%5BAssassin-Reskin%5D%20%5BM%5D%20Matthew%20by%20Greentea)
- [Dart Berserker Reskin by Greentea](https://github.com/Klokinator/FE-Repo/tree/main/Battle%20Animations/Infantry%20-%20(Axe)%20Brigs%2C%20Pirates%2C%20Zerkers/%5BBerserker-Reskin%5D%20Dart%20%5BM%5D%20by%20Greentea)
- [Erk Sage Reskin by Greentea](https://github.com/Klokinator/FE-Repo/tree/main/Battle%20Animations/Magi%20-%20Nature-Type/%5BSage-Reskin%5D%20%5BM%5D%20Erk%20by%20Greentea)
- [Nino Sage Reskin by Greentea](https://github.com/Klokinator/FE-Repo/tree/main/Battle%20Animations/Magi%20-%20Nature-Type/%5BSage-Reskin%5D%20%5BF%5D%20Nino%20by%20Greentea)
- [Priscilla Valkyrie Reskin by Greentea](https://github.com/Klokinator/FE-Repo/tree/main/Battle%20Animations/Mounted%20-%20Valks%2C%20MKs%2C%20Magi/%5BValkyrie-Reskin%5D%20%5BF%5D%20Priscilla%20by%20Greentea)
- [Florina Falcoknight Reskin by Greentea](https://github.com/Klokinator/FE-Repo/tree/main/Battle%20Animations/Mounted%20-%20Pegs%2C%20Wyverns%2C%20Griffons/%5BPeg%20T2%20Reskin%5D%20%5BF%5D%20Falcoknight%20Florina%20by%20Greentea)
- [Fiora Falcoknight Reskin by Greentea](https://github.com/Klokinator/FE-Repo/tree/main/Battle%20Animations/Mounted%20-%20Pegs%2C%20Wyverns%2C%20Griffons/%5BPeg%20T2%20Reskin%5D%20%5BF%5D%20Falcoknight%20Fiora%20by%20Greentea)
- [Farina Falcoknight Reskin by Greentea (Palette edit by SmithPlays)](https://github.com/Klokinator/FE-Repo/tree/main/Battle%20Animations/Mounted%20-%20Pegs%2C%20Wyverns%2C%20Griffons/%5BPeg%20T2%20Reskin%5D%20%5BF%5D%20Falcoknight%20Farina%20by%20Greentea)
- [Heath Wyvern Lord Reskin by Greentea](https://github.com/Klokinator/FE-Repo/tree/main/Battle%20Animations/Mounted%20-%20Pegs%2C%20Wyverns%2C%20Griffons/%5BWL%20Reskin%5D%20%5BM%5D%20Heath%20by%20Greentea)
- [Kent Paladin Reskin by Greentea](https://github.com/Klokinator/FE-Repo/tree/main/Battle%20Animations/Mounted%20-%20Cavs%2C%20Paladins%2C%20Rangers/%5BPaladin-Variant%5D%20%5BM%5D%20Kent%20by%20Greentea)
- [Sain Paladin Reskin by Greentea](https://github.com/Klokinator/FE-Repo/tree/main/Battle%20Animations/Mounted%20-%20Cavs%2C%20Paladins%2C%20Rangers/%5BPaladin-Variant%5D%20%5BM%5D%20Sain%20by%20Greentea)
- [Rebecca Sniper Reskin by Greentea](https://github.com/Klokinator/FE-Repo/tree/main/Battle%20Animations/Infantry%20-%20(Bow)%20Snipers%20and%20Ballistae/%5BSniper-Reskin%5D%20Rebecca%20%5BF%5D%20by%20Greentea)
- [Wil Sniper Reskin by Greentea](https://github.com/Klokinator/FE-Repo/tree/main/Battle%20Animations/Infantry%20-%20(Bow)%20Snipers%20and%20Ballistae/%5BSniper-Reskin%5D%20Wil%20%5BM%5D%20by%20Greentea)
- Neil Logtenberg (Lord Niru)
    - Miscellaneous fixes/ Tweaks to some animations to fix incorrect sound effect events/ or bugs that caused the game to freeze(like 1 Range short bow)


### Class Cards:

- [Mercenary (F) Sword by Uncredited](https://github.com/Klokinator/FE-Repo/tree/main/Class%20Cards/Infantry%20-%20(Swd)%20Mercenaries%20and%20Heroes)
- [Hero (F) Gerik-Style Sword by RobertFPY](https://github.com/Klokinator/FE-Repo/tree/main/Class%20Cards/Infantry%20-%20(Swd)%20Mercenaries%20and%20Heroes)
- [Swordmaster (F) Sword by L95](https://github.com/Klokinator/FE-Repo/tree/main/Class%20Cards/Infantry%20-%20(Swd)%20Myrms%20and%20Swordmasters)
- [Myrmidon (F) Sword and Pants by GigaExcalibur](https://github.com/Klokinator/FE-Repo/tree/main/Class%20Cards/Infantry%20-%20(Swd)%20Myrms%20and%20Swordmasters)
- [Archer (F) Improved by HyperGammaSpaces](https://github.com/Klokinator/FE-Repo/tree/main/Class%20Cards/Infantry%20-%20(Bow)%20Archers%20and%20Hunters)
- [Sniper (F) Riding Boots Bow by L95, Meteor](https://github.com/Klokinator/FE-Repo/tree/main/Class%20Cards/Infantry%20-%20(Bow)%20Snipers%20and%20Ballistae)
- [Nomad (F) Sword by Jey the Count, Pushwall](https://github.com/Klokinator/FE-Repo/tree/main/Class%20Cards/Mounted%20-%20Cavs%2C%20Paladins%2C%20Rangers)
- [Nomad Trooper (F) Bow by Jey the Count, Pushwall](https://github.com/Klokinator/FE-Repo/tree/main/Class%20Cards/Mounted%20-%20Cavs%2C%20Paladins%2C%20Rangers)
- [Mage (F) Magic by Uncredited](https://github.com/Klokinator/FE-Repo/tree/main/Class%20Cards/Magi%20-%20Nature-Type)
- [Sage (F) Magic by L95](https://github.com/Klokinator/FE-Repo/tree/main/Class%20Cards/Magi%20-%20Nature-Type)
- [Druid (F) Magic by L95](https://github.com/Klokinator/FE-Repo/tree/main/Class%20Cards/Magi%20-%20Dark-Type)
- [Shaman (F) Magic by Uncredited](https://github.com/Klokinator/FE-Repo/tree/main/Class%20Cards/Magi%20-%20Dark-Type)
- [Bishop (F) by L95](https://github.com/Klokinator/FE-Repo/tree/main/Class%20Cards/Magi%20-%20Holy-Type)
