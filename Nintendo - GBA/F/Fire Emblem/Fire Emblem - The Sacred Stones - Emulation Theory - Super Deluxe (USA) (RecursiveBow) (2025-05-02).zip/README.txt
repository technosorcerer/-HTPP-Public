Thank you for downloading Fire Emblem: Emulation Theory (SUPER DELUXE)! This readme contains useful information to read before playing the hackrom. I hope you enjoy!

 Index

1. Contents
2. Hackrom summary
3. QoL changes
4. Secret events + Misc shenanigans
5. Known, unintentional bugs
6. Credits

############################################################## 1. Contents ##############################################################

The compressed .rar file contains three files:

- The .ups hackrom, to be patched using a vanilla, US version of Fire Emblem: The Sacred Stones.
- A .txt file, titled "A message": It serves as an introduction to the hackrom, but can be ignored if you wish. Note that the message is part of the Emulation Theory experience, too: it is fiction.
- This readme!

############################################################## 2. Hackrom summary ##############################################################

This is a crossover, story-driven metagame that follows Princess Eirika of Renais as she discovers the truth about Magvel and the Fire Emblem GBA games. Can she make it back home, before it and the rest of the worlds are destroyed?

That's the premise of the hack. It is (technically) 34 chapters long, and has two main difficulties: Normal and Hard.

Normal mode is the intended way to play the game. It is the one that had the most testing, and it dictates the balance of the units. It can be completed.

Hard mode not only has increased enemy stats, but also every single unit has a 25 hit bonus! Money gained is also mostly halved throughout the hackrom.
Each world has its own (prejudicial and beneficial) special hard mode changes. For example, the FE7 maps may have more of those pesky Pegasus Knights the Vanilla game likes so much...
This mode is experimental, and highly untested. The first chapters are actually beatable, and I'm sure the rest are, but those weren't tested for the release.

This hack does not include any ambush spawns. Even in The Binding Blade maps.

This hack has the skill system! There are three types of skills:

- Personal skills, which are granted to most of your own units and most bosses, too.

- Prowess skills, which are granted only to unpromoted allies, at certain levels.
Units in fighting class (that is, classes that can defend themselves) get theirs at level 17.
Units in support classes (priests, troubadours, dancers) and Manaketes get theirs at level 15.

- Class Mastery Skills, which are granted to ALL (friends and foes alike) promoted units at level 10.

When it comes to weapons, most remain unchanged. With the exception of the Blade swords, that now has the Weary Fighter skill (which prevents double attacks from ever occurring, only if you're able to retaliate (that is, at one-range)).

There's also new items: Glitched weapons! These weapons have either special skills attached to them, or break the rules of the game in some special way! Some of them are hidden, but others you can obtain normally. Since you're so kind to read the readme, here's one secret one: In chapter 10, look for a seemingly out-of-reach house...

############################################################## 3. QoL Changes ##############################################################

Multiple Quality of Life changes are introduced in order to make the experience better:

- Battle animations are now faster overall, and can be sped up by pressing the R button.

- Press select to see the danger zone.

- You can toggle between battle animations ON and OFF by holding the L button before a battle.

- Map battles now have the stats (hit, attack, crit...) displayed.

- You can now do actions after a support, or after attacking (this may cause some visual bugs)

- The Music Room and Support Room are now unlocked! But DO NOT enter the support room until after beating the game: it contains heavy spoilers of the game, both by displaying all future playable characters and the support conversations themselves can contain spoilers.

- You can disable healing/dancing animations in the settings. Note that this also disables HP bars on the map!

############################################################## 4. Secret Events + Misc. Shenanigans ##############################################################

############################################################## (SPOILER WARNING FOR THIS SECTION)

There are some conversations that give you certain things if you deploy two units under certain conditions. These events can only be unlocked on certain parts of the game, on any of the maps on that part:

- Deploy Lilina and Nino in the same map on part 2, except the chapter in which Lilina is recruited.

- Reach A support between Lilina and Dozla, and deploy them in the same map on part 3.

- Reach level 20 with Eirika before chapter 19, in part 3.

- Talk to Mark with Eirika in Chapter 19 (I'm not sure this one's even possible: let me know if you achieve this) 

- Talk to Lyn with Dorcas in Chapter 20

- Deploy Yoder, Dorcas, Rennac, Canas, Dayan, Perceval, Saul, AND The Messenger at the same time in Part 3 or Part 4 (Not counting the map where you can deploy everyone!), then talk to The Messenger with Dorcas.

- Reach A support between Gerik and Dayan, promote Gerik to a Nomad Trooper BEFORE chapter 23 (strictly before), and deploy them in the same map on part 4 (Not counting the one where you can deploy everyone!).

There are several optional dialogue that gives you nothing, but are interactions between the characters. If you don't want to miss those, they are listed here (only listed are the ones that require you to deploy one non-forced unit). Note that I do not recommend deploying units you are not going to use, just to read these conversations.

- Perceval - Heath - Chapter 5

- Eirika - Franz - Chapter 8

- Thea - Mark - Chapter 13

- Gerik - Eirika - Chapter 14 (trigger the conversation before turn 7!)

- Eirika - L'arachel - Chapter 16

- Thea - Shanna - Chapter 17 (will trigger at the end of the chapter regardless, if Thea's alive)

- Canas - Eirika - Chapter 18

- Jose - Mark - Chapter 19

- Eirika - Nino - Chapter 20 (Make sure they can reach eachother at the start)

- Sue - Chapter 20 (You just need to deploy her)

- Eirika - Lloyd - Chapter 22

- Thea or Shanna - Messenger - Chapter 23

- Eirika - Zephiel - Chapter 23

- Leila - Hector - Chapter 23 (Optional way to recruit him)

- Messenger - Eirika - Chapter 24

- Leila - Eirika - Chapter 25

Some supports that act different than usual, and this will be documented here:

- Marisa/Saul and Rennac/Dozla will never go past C support in the story (but their conversations might...).

- Nino/Lilina can only grow their support via the secret event, and will never get above or below a B support.

- Mark/Merlinus support will not grow naturally, instead it's unlocked via conversations in chapters 13, 18 and 24. If you miss one, you miss the next ones.


############################################################## 5. Known (unintentional) bugs ##############################################################

The main known bug is related to the Sacred Tomes Forblaze and Aureola, and Zephiel's sword: these have weird, broken animations. This will be fixed, soon.

At the end of chapter 27, the intro cutscene will play again. This is unintentional, and there's no way to delete it. Skip it if you wish.

############################################################## 6. Credits ##############################################################

Here are all the good people that helped, one way or another, to make this hack!

### General/Misc

- The crew that made FEBuilder! 7743, alongside others (I... think?)

- Intelligent Systems, naturally, for... You know, Fire Emblem for the Game Boy Advance.

- Gringe, from Serenes Forest, for the english translation of FE6! It was used at several times during development.

### Graphics

- The Github Repo!

- Lenh (I... Think?) For the FE6 cast recolored using FE8's colours.

- An unknown angel, for the FE7 cast recolored using FE7's colours. (If someone knows the author, please let me know!)

- Airavat, for specifically just the Brunnya recolor.

- Batima, for their Dragonstone+ item icon.

- Agro, for the sword cavalier map animation.

- Raspberry, for the axe hero map animation.

- RobertFPY, for the sword paladin map animation.

- Unknown, for the axe wyvern map animation (If someone knows the author, please let me know!).

- Blademaster, for the Axe General map animation.

- Marlon0024, for the FE7 Dragon battle animation.

- SHYUTERz for the Nergal repalette + Fix.

- TheBlindArcher, for the Wyvern Axe battle animations! (Wyvern Rider and Lord)

#### FEBuilder Patches

- Vesly and 7743. If I had to list every patch of them that helped me, we'd be here all day.

- Leonarth, for the 256 colour backgound and the less annoying fog.

- aera, for the switch animation ON/OFF and the deny deployment for preparations patches.

- circleseverywhere, for the danger zone, actions after talk/support, drumfix, HP bars (alongside Tequilla), convert text to chapter titles, and one tiny patch called the Skill System!

- Speaking of which: the folks of SkillSystem! Monkeybard & Black Mage for most of the skill icons; Blaze for Stances skill icons. And Tequila, Rossendale, StanH, Leonarth, Teraspark, sd9k, Kao, blademaster, Snakey1 for skills. This hack uses a custom build with few changes.

- Scraiza, for the "switch portrait images by class" and the NarrowFont.

- Stan, for the ExModularSave, Skip World Map Fix.

- Venno, for the "lose ranks upon promotion" patch.

- The lost souls that I forgot to include in this area, but surely made a patch that I used.
