-----Fire Emblem 7 - The Neo 2026 PME by Lavender-----
Available on FEUniverse | Made on FEBuilderGBA by 7743

------------------------------------------------------

[ HACK – PATCHES ]
- Anti-Huffman by Hextator, 7743.
- 01/48 Command Hack by Hextator, 7743.
- SOUND_NIMAP (Native Instrument Map) by Mariobro3828, Kirb1337.
- 16 Tracks 12 Sounds by Agro, Brendor.
- Drumfix Patch by Derwolf19.
- Unlock Sound Room by CT075, SageMatthis.
- Unlock Mode Select by Doesnt.
- Tutorial Disabler by 7743.
- Skip Opening (OPENING_CUT) by Gray.
- Game Text Speed (Fast) by Vesly, SageMatthis, EgalLau37.
- Fix CAM1/CAM2 Going Out of Bounds by Stan.
- Prevent AI Healer Mistarget by Magrika, 7743.
- Use HandAxs Generic Motion Patch by 7743.
- Map Danger Zone (Select: Toggle) by Circles.
- HP Bars and Warnings by Circles, Tequila.
- Null Move Display by 7743.
- Show Heal Amount by Contro.
- Display Growths Patch by Tequila.
- Gain Support At Various Ranges by Venno, 7743.
- Stat / Class Expansion FE7 by Vesly.
- Fimbulvetr Glitch Fix (Barely) by 7743.
- Exceed Portrait Hackbox Patch by Tiki, Area.
- Change Effectiveness Damage Patch by 7743.


[ BATTLE – ANIMS ]
- [Archer-Variant] Der's Improved [M] Repal by DerTheVaporeon, Flasuban.
- [WL Reskin] [M] Heath Repalette by Greentea, RobertFPY, UltraFenix, CranJam.
- [Manakete-Variant] Horse Manakete by Jj09, Jotari.
- [Manakete-Base] [F] Vanilla FE6 Fire Dragon by Marlon0024, Eldritch Abomination, SHYUTERz.
- [Manakete-Custom] [F] Adult Tiki by Akkuma407, UltraBlade.
- [Hector-Reskin] Vagabond [M] by Kyrads, Zane Avernathy.
- [Custom Polearm] Sergeant [M] by Spud, Leolink, Iscaneous, Nuramon, ltranc.
- [Thief-Reskin] Matthew Repal [M] by RedBean, Seliost1.
- [Assassin-Reskin] Matthew [M] by RedBean.
- [Cavalier-Base] [F] Vanilla by Skitty, Pushwall, DerTheVaporeon, Kao, Aurora, Seliost1.


[  MAP – SPRITES ]
- Hunter [F] by MeatOfJustice.
- Wyvern Knight [U] Bow by Knabepicer, MeatofJustice, Eden.
- Troubadour [F] Thaumaturge by Pikmin, DerTheVaporeon.
- Manakete [F] Adult Tiki by Akkuma407.
- Fighter [M] FE10-Style Sword by L95, Warpath.
- Sergeant [M] by Spud.


[  ITEM – ICONS  ]
- Smithblade by JPN.
- Drakebane by REALxViPerZ.
- Ancient Stone by 2WB.
- Combat Bow by Eldritch Abomination, Serebii01, Tactics Ogre LUCT.
- Maligtite by SacredStones.


[  MAGIC – ANIMS ]
- WIP 


[  SOUND – ROOM  ]
- WIP


Please enjoy and have fun!