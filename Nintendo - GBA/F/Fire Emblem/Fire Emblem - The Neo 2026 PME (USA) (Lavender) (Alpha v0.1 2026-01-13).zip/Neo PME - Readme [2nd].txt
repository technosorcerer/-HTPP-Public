-----Fire Emblem 7 - The Neo 2026 PME by Lavender-----
Available on FEUniverse | Made on FEBuilderGBA by 7743

------------------------------------------------------

[ GAMEPLAY – CHANGES ]
- Effective weapons multiplier reverted to the Japanese values (3x on most weapons).
- Valkyries now equip Light magic instead of Anima magic, all maps adjusted.
- Exp gained from healing/dancing/stealing from 10 to 15.
- All weapons now grants at least 2 WExp per use.
- Vulnerary heal increased from 10 to 15 per use.
- Some items/weapons now have different names.
- Secret Book now increases Skill by 4 points.
- Divine Icon now increases Luck by 4 points.
- Supports are gained at up to 3 tiles away.
- Crit Boost increased from +15 to +30.


[ PLAYABLE – CREDITS ]
- Sylvester by Shadow_the_halberdier | Portrait by Shadow_the_halberdier
- Ireone by Starshadow_Melody        | Portarit by Garytop, RedBean, AlemOwl, Starshadow_Melody
- Atanas by ItsJustin                | Portrait by LittleKying
- Alexis by ItsJustin                | Portrait by LaurentLacroix, ItsJustin
- Trevor by Sir_Lancelot             | Portrait by PKLucky
- Nyastro by Shadow_the_halberdier   | Portrait by Saihua, ItsJustin
- Hideno by Shadow_the_halberdier    | Portrait by WhatIsAnAubin
- Daedra by ItsJustin                | Portrait by RedBean, ItsJustin


[   BOSS – CREDITS   ]
- Wario by GeorgeCalibur69420        | Portrait by Sme
- Waluigi by GeorgeCalibur69420      | Portrait by Sme


[    NPC – CREDITS   ]
- WIP


Please enjoy and have fun!