******************************************
        Fire Emblem: Accursed Fate
             --- by THE 1 ---

******************************************

About

Fire Emblem: Accursed Fate is a fan-made
prequel to Fire Emblem: The Blazing Blade,
created over the course of one year of
development. It tells the story of House
Cornwell's final moments before its
downfall at the hands of House Ostia and
various ominous forces.

The story takes place a decade before the
events of Blazing Blade. It incorporates
elements referenced in said game, as well
as brand new plot points made from
scratch. All in an effort to deliver an
intriguing story which respects the
established lore.

******************************************

Features

- An original story based on new and
canonical events referenced in Blazing
Blade.
- 22 chapters, a prologue, and an
epilogue.
- A cast of new and familiar characters
from the Elibe series.
- Several new weapons, including the
thief/assassin-exclusive daggers.


******************************************

How to play

1. Unpack the file using whichever method
you prefer.

2. Patch the FE7 (U) ROM that you have
using the unpacked UPS file. It is a very
simple process, most easily done using
this tool:

https://www.romhacking.net/patch/

******************************************

Special thanks to

- Nintendo, for making the incredible game
that this hack is based on.
- The people behind FEBuilder.