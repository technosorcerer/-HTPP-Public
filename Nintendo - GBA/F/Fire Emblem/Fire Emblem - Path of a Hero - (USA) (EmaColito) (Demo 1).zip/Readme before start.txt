The Hector Route is different from the vanilla version 
and will allow you to play a completely different story with its own ending, 
separate from the main story, 
before starting playing, save the game in one of the other two available slots.
If you downloaded the previous version and haven't progressed past Lyn Mode, 
you can continue playing Hector Mode on the same Rom, continuing the story from where you left off.