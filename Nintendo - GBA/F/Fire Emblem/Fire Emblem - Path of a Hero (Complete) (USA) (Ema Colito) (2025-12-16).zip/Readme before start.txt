The Hector Route is different from the vanilla version 
and will allow you to play a completely different story with its own ending, 
separate from the main story, 
before starting playing, save the game in one of the other two available slots.

Hard mode is intended for veterans of the game.
I don't recommend selecting it 
if it's your first time playing Path of a Hero.
Hard mode makes enemies more powerful and dangerous, 
and the experience gained after completing Lyn mode and starting Eliwood mode is halved.

The "one year later" text doesn't belong to the Path of a Hero story but to the vanilla version of Fire Emblem 7.
The events of Hector mode and Eliwood mode take place one month after the end of Lyn mode.