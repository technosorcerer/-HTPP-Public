Fire Emblem: New Mystery of the Emblem - NES Style Palette Mod v.1.0

Features:
The colour palettes of several classes, both in battle and on the map, have been altered to restore the consistent blue/red colour scheme for player and enemy units used in the NES games. This also extends to the enemy Dracoknights' mounts, which have been changed to green.
Consider this a sequel to the previously released FE11 NES Palette Mod.

Compatibility note:
This mod has been tested and is confirmed to work with both versions of the Heroes of Shadows English translation patches. We cannot guarantee compatibility with other mods, but if you wish to install another patch, we suggest attempting to do so after installing this one and disabling Delta Patcher's checksum validation in its settings.

Installation:
- Obtain by your own means an unmodified ROM of the game.
- Obtain a program to apply xdelta patches. A recommended tool is Delta Patcher, which is obtainable form romhacking.net.
- Select the unmodified ROM (or the ROM with the Heroes of Shadows translation patch applied) to use as the source file, followed by the FE12_NSP.xdelta patch.
- Click on the button to apply the patch. The modified ROM will then be created. Note that the default setting in Delta Patcher will cause it to overwrite the original ROM, so we suggest ensuring to have a backup of the file or changing the program's settings.

Changelog:
- v.1.0: Initial release.

Credits:
EnDavio - Hacking, graphic editing
CedAodh - Graphic editing support
