This is just a demo of the story.
There may be some errors with the dialogs with some events, for any errors please notify me.

The Demo ends in Chapter 13: The beginning of End.
If you go beyond that chapter the game will revert to the original story.

Thank you for playing.