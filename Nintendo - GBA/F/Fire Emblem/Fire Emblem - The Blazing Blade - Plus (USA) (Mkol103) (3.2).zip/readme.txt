---Hack by Mkol103---

Hi, thanks for downloading!
The goal of this project is to take all the amazing hacks
from the Fire Emblem GBA hacking community and put them
into the base game experience. These are designed for
veteran players and newcomers alike!
The changes are designed to be uncontroversial enough
so that this isn't seen as an "alternate" way to
play the game but an "enhanced" way.
The major changes are QOL and bugfixes.
The only gameplay changes come from removing
localization changes.
View all the specific changes under the patch descriptions.
Make sure to use whichever patch you want onto a US version of Fire Emblem (GBA)

This game has multiple patches;
I'll describe each briefly

Fixed:
Fixed refers to an alternate way of character growth. This mode is recommended for veteran players. Inexperienced players can ignore this.
In the vanilla game, each character has a growth value out of 100. When they level up, they have that percentage change to gain a stat in that category.
(e.g. Roy has an 80 HP growth, so every time he levels up, he has an 80% change to gain a point of HP. Theoretically, he gains 4 points of HP in 5 level ups).
Fixed growths uses a formula to determine growths. Essentially, every character starts with 50 "Growth Points (GP)" per stat.
Whenever they level up, their growth is added to their growth points. When this number exceeds a multiple of 100, they level up.
(e.g. Roy has an 80 HP growth and 50 HP GP. First level up: GP is 130 [he gains a point]. Second level up: GP is 210 [he gains a point]. Third level up: GP is 290 [he doesn't gain a point]. Fourth level up: GP is 370 [he gains a point]. Fifth level up: GP is 450 [he gains a point]. Here, what is theoretically suppose to happen occurs each playthrough.)

Original vs JP:
The JP version includes extra, minor changes to bring the game more in line
with the Japanese original. Both games are fairly similiar,
and whichever one you pick is up to your preference. 

I would recommend the Original version to a newcomer, but the Japanese version is equally valid.

Below is a list of all the changes made to the game:

(Edits by 7743)
-Patches Fimbulvetr Glitch
-Disables Tutorials for Lyn Mode
-Fixes AI Healing Error
-Unlocks every mode/difficulty from the start
-Completely unlocks Sound Room and Support Viewer
-Fixes Hector Mode rankings bug
-Adds Casual Mode
-Changes certain weapon descriptions to the European version to fix graphical glitches
-Fixes translation issues/vaguries

(Edits by Tequila)
-Danger zone (Press select to see the enemy's range)
-Move and Con getters (includes Show – Mov if in Guard Mode hack)
-Show hp healed to target when using a staff
-L-toggle (toggles animations on/off by holding L when starting combat)
-HP bars and warnings (HP bars appear on the map screen under characters without full health. Warning icons appear when a character has a -bane weapon or a killer weapon)
-Display battle stats with animations off
-Display growths on the character screen (Press select while viewing a character's stats)

(Edits by Brendor):
-Change Default settings (Fast text speed, movement speed fast, etc.)
-Fix enemy control glitch

(Edits by Gryz):
-Remove beating the game requirement to hold A to increase unit's map speed

JP Version (All edits made by me):
-Restored Boss stats (Most bosses from chapter 23 and onward now have +2 skill, +3 speed, and +1 Str/Def/Res)
-Terrain bonuses reverted to Japanese version
-Effectiveness reverted to 3x (In the NTSC and PAL version of the game, the effectiveness bonus is only 2x)
-Lloyd and Linus reverted to using Runeswords in Cog of Destiny
-The doors in the final chapter open at the Japanese rate (2 doors open at a time every other turn in the JP version)
-Guy/Priscilla's paired epilogue restored (In the JP version, they elope. In the NTSC and PAl version, they break up)