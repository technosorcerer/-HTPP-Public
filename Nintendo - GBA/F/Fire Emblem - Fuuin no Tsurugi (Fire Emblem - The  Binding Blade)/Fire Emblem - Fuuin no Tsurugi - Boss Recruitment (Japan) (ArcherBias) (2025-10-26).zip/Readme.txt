Loose Inspiration - Serif's FE7 Boss Swap, Fire Emblem Fates Capture/Kidnap

In this hack, you can recruit one boss from each of the sections in Fire Emblem 6. The sections are as follows:
Earlygame: Chapter 1-8
Western Isles: Chapter 9-12
Etruria: Chapter 13-15
Ilia/Sacae: Chapter 16-20
Gaidens: 8x, 12x, 14x, 16x, 18x, 20xS, 20xI, and 21x.
Bosses from maps 21-25 (excluding 21x Peres) are not recruitable. Every boss is recruited by talking with Roy.

Known oddities:
- Loading save files has been known to cause bosses to turn into regular characters. Savestates are recommended.
- The credits crash the game, as bosses do not have endings.
- If you lose a recruited boss in some map, you may stop the reinforcements.
- Peres is not recruitable in Chapter 21, only in Chapter 21x. Same goes for the Djute in Chapter 20.

Credit to Gringe for the translation, and credit to IntSys for creating Fire Emblem.

