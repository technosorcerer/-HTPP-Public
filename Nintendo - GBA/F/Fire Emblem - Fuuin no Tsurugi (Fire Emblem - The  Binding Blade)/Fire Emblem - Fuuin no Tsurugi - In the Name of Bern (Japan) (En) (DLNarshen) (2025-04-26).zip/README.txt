---In the Name of Bern V1.0---

Apply the .UPS patch to a CLEAN, japanese ROM of FE6. No translation patches or
other modifications applied beforehand.

mGBA emulator is recommended.

Link to guide (contains spoilers): 
https://docs.google.com/spreadsheets/d/1zVEXFNvOkpNRQB8NM-g9_MLjXj572yIb85ggUQC8nWE/edit?gid=0#gid=0 