﻿How to patch
-----------------------------

Patch to a vanilla fe6 JP Rom.


-------------------------------------

Versions
-----------------------------

FE6 - Dual Lords.ups
&
FE6 - Dual Lords - Fixed Growths.ups

As the tile suggests, one has fixed growths (once growth % reaches 100 stat goes up.) , and the other has random growths. Note that stats were balanced around fixed growths.


------------------------------------

changelog :


(V1.1)
---------------------

Rebalance of all characters stats – the game is more difficult than in 1.0 (I tried to make it about even with vanilla).


Refined animations to make them feel weightier.


(V1.0)
---------------------

Everyone can sieze maps.

No ambush reinforcements.
    Repeated reinforcements are also gone.
    Post CH.16 reinforcements are promoted.

No more status staffs.
    Some enemies still have them, but they will never use them.

Optional casual mode.
    You will be asked if you want it after the intro cutscenes.

Story changes :
    lilina joins from the start, and is present throughout the game.
        Lilina is in most cutscenes as well.
    A small non-cannon addition made to make lilina's dragon slaying prf weapon make sense, and not come out of nowhere.
    A scene was added after defeating the final boss to make sense of why you don't have to beat the final boss with the binding blade.

New Classes :
    Lilina now has her own Lord and Great Lord classes with unique animations and map sprites.
    Both male and female thieves promote to Rogues. A custom female Rogue animation and map sprite was made for Cath. Male Rogues were backported from fe8.
    Player cavaliers were split among two classes to diferientate them.
        No enemy cavaliers/paladins were changed.
        Both umpromoted and promoted from both classes use the same weapons. the difference is class stats and animation.
        Crusaders promote into Paladins. They have higher speed and Resistance.
        Cavaliers Promote into great Knights (backported from fe8). they have higher strength and defence.

New weapon types :
    Roy can use swords and lances from the start and gets bows upon promotion.
    Lilina can use anima and stalves from the start, and gets light magic upon promotion.
    Everyone can attack! (no enemies were given new weapon types) :
        Priests and Clerics use light magic.
        troubadours use anima magic.
        Dancers use swords.
        Bards use light magic.

Complete rework of item mt, hit, weight, and rank required for use. 
    Some highlights are :
        Weapon durability has generally increased and weapons/items are cheaper to buy from vendors and armories.
        Higher availabilty of lightbrands (available to buy wherever you buy javelins amd hamd axes).
        New mid tier ranged swords, lances, and axes. available in armories ch 17 on and in chests ch 20.
        killer weapons have 20 crit. Wo Dao and Devil Axe, which is now the axe equivalent to Wao Dao have 25 crit and are much stronger than killer weapons.
            Devil Axe is exclusive to the berserker line.
        magic triangle reworked to in ascending order of power (Anima -> Light -> Dark),
        Fimbulvetr is now a reaver spell (strong against dark), and seige tomes are now magic longbows 2-3 range.
        All bows besides longbow have 1-2 range. Only short bow is effective vs fliers.

Delphi Shield negates all effectiveness. a shield was given to all of the wyvern generals (Gale included).

Legendary weapons are only effective vs dragons (not wyvern rider/lord), and nothing is effectve against the finqlal boss.
    Along with this you do not have to beat the final boss with the binding blade to get the true ending.

Zephiel's weapon is effective vs dragons (fae) and gives stat bosts (Str/Def+3).

Lockpicks and Fae's dragonstone are infinite

Major base stat boosts to player characters. Growths are boosted and/or redistributed on both player units.
    for player growths, ~290 is standard for non-prepromotes, 350-380 for prepromotes, and 310 for Roy and Lilina.

Many maps redesgined for easier transversal.
    many recruitable allied units now start as player controlled.

More enemies in the final chapter to make it more interesting.


Promotion changes :
    There is now one promo item all units use : the Emblem. It is a renamed Hero crest.
    Roy promotes with an emblem.
    All promotion bonuses Hp + 5, and other stats (besides con) are +3.

Movement changes :
    Knights and generals have infantry movement (both movement ammount and terrain).
    All units traverse deserts easier, and more units can cross water.
    Roy, Lilina, Thiefs/Rogues, Bard, and Dancer have 1 extra mov. 6 unporomted, and 7 promoted.

Promoted stat caps changed to be mostly 28 and 2 extra stat points allocated for "primary stats". Ex. Berserker has 29 pwr and 29 spd.
   The exceptions are Roy, and Lilina both have a stat cap of 30 on all stats when promoted.

Misc. Gamplay changes :
    vunaries heal 20 Hp thanks to 7743. more info in credits.
    HB bars appear below max hp. Also warnings are shown for enemies with effectiveness vs selected unit or more than 25 crit. This is thanks to the amazing patch by circles and Vesly.  more info in credits.
    Minimum EXP earned from encounters is 5. see credits.
    Weapon ranks increase faster. Stalves are included in this (thanks to CedAodh. More in credits).

Visual changes :
    Roy has new Lord animatiioms and DIFFERENT Great Lord animation and map sprites.
    Lilina has new Lord and Great lord animations and map sprites.
    New female Rogue animations and map sprite.
    New Dancer sword animation.
    New bard animations.
    New priest animations.
    New cletic animations.
    backported Great Knight and male rogue animations and map sprites.
    Item icons either touched up or redone.
    Desaturation of colors/palettes.
        Intended to look like fe6, just not give you a headache from how bright it is.



--------------------------------------------------------------

Credits:

circles for making the amazing HP bar and warnings patch and Vesly for porting it to FE6.

Hexator for making the animation loop hack and 7743 for porting it to FE6.

circleseverywhere for making the casual mode patch and 7743 for porting it to FE6.

The anti-huffman patch made by Hexator and 7743 for porting it to FE6.

Fixed growths made by TR143

NULL Move display made hy 7743

Updated L button cycleing made by AuraWolf.

Weapon Lock EX by 7743.

Continue music after battle patch by 7743.

Play and dance music patches... Unfortunately FEbuilder does list an author. If you made this let me know and I will credit you.

FE 6 analysis material for the patch that makes delphi shield negate all efectiveness.

7743 for Don't stop BGM when Defeat Idun.

FE 6 analysis material for limitless trading.

FE 6 analysis material for Hard selectable from the beginning

Magrika is Now Canon for making Prevent Healer Mistarget and 7743 for porting it to FE6.

set staff expierence - again no author listed si just let me know.

FE 6 analysis material for preportaion store even on hard.

Set Default Option "Message Speed & etc" - once again no author listed.

FE 6 analysis material for stop price increase the Preparation shop

Attack Miss EXP - No author listed

7743 for the patch that let me set vunlary heal amount to 20.

7743 for the patch that me set the transport unit to Roy.

CedAodh forthe patch that let me increse staff Wexp per use.
