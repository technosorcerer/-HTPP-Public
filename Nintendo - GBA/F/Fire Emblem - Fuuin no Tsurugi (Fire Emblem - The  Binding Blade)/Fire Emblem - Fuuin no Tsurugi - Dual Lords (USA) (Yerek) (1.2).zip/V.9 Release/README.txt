How to patch
-----------------------------

Patch to a vanilla fe6 JP Rom.


-------------------------------------

Versions
-----------------------------

FE6 - Dual Lords.ups
&
FE6 - Dual Lords - Fixed Growths.ups

are the mostly vanilla versions



FE6 - Dual Lords - DC.ups

Is my original vision of the hack for anyone who wants it. Note about the DC version - 

Currently there is only a fixed growth version as that is how it was 'balanced'. When I say "balanced" it was designed to be what I concider fun in an FE Game. It was designed around hard mode, so normal mode will likely be easy.



------------------------------------

Extra DC changes :

Update 0.95 :

------------------------------------

Ranged swords, spears, and axes are back. they now are 2 mt weaker than iron weapons but have the utility of being ranged. weapon distribution has been slightly altered to accomaidate this.

Fixed Gwendolyn accidentally carrying the binding blade when she appears in Ch. 8.

Rapier is returned to it's original form. Regal lance is now a stronger javelin.

Dieck and Lot now start with B rank in sword and axes respetively.

** only thing left to do before full release is one more playtest, and fixing whatever problems appear. **

------------------------------------

0.9 changelog :

Weapon Durability is Infinite.

Complete rework of item mt, hit, weight, and rank required for use. 
    Some highlights are killer weapons require A rank, magic triangle reworked to in ascending order of power (anima -> Dark -> Light),
    thunder is now a reaver spell (strong against dark), and seige tomes are now magic longbows.

Delphi Shield negates all effectiveness.

Legendary weapons are only effective vs dragons (not wyvern rider/lord), and give no bonus stats.

Zephiel's weapon is effective vs dragons (fae).

Lockpicks are infinite

Weapons are distributed through events and chests and armories carry staffs (not inifinite use).

Major stat boosts to player character bases. Growths are boosted and/or redistributed on both player and enemy units. 
for player growths, 300 is standard for non-prepromotes, 350 for prepromotes, and 325 for Roy and Lilina.

Many maps redesgined for easier transversal.

Harder chapter 21, 23, and final to account for weapon changes

New Prf weapon for Roy with Rapiers vanilla effect, and rapier is a more accurate wo dao.

Weapon ranks start at c, including new types gained through promotion. Light magic starts at A rank to allow for more use of the light legendary weapon.

All promotion bonuses are +3.

Kights and generals have infantry movement (both movement ammount and terrain).

Stat caps changed to be mostly 28 and 2 extra stat points allocated for "primary stats". Ex. Berserker has 29 pwr and 29 spd.
   The exceptions are Roy, and Lilina both have a stat cap of 30 on all stats and 80 max HP (neither will reach 60 without angel robes).



