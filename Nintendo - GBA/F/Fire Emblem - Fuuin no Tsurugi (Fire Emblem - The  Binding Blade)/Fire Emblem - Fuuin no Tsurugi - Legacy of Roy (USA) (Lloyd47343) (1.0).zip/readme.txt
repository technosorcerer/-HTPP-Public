THANK YOU for downloading my hack!!!

To patch, acquire a unmodified Japanese copy of Fire Emblem: Fūin no Tsurugi by some means up to your discretion, and follow the directions of your UPS patcher of choice. NUPS is cool.

CREDITS
----------
Patches:
CasualMode Flag 0x8C 20221005 by circleseverywhere, 7743
FE6-Droppable Items by Tequila
01command_hack by Animation Hacks by Hextator
Anti-Huffman Patch by Hextator
SOUND_NIMAP(Native Instrument Map) by Alusq

Made using the FE6 Localization Patch by gringe

Built using FEBuilderGBA by 7743

All maps, sprites and music are either present in base FE6 or sourced from FE7/8

KNOWN BUGS:
Part of the Assassin crit animation plays an electric sound effect which I think comes from Idunn's crit?
Cath's death quote broke somehow and will not trigger
The transformation animation of enemy Divine Dragons looks odd

CHANGES
--------
Weapons:
Eclipse's hit rate is now up to FE7 standards, raised from 10% to a whopping 30%. Yay...
Armads and the Wyrmslayer are now effective against the Demon Dragon class
Armads now also weighs 18 like in FE7
The rapier is no longer a prf weapon 
All weapons effective against armored units are now effective against the King class
Finally, all weapons effective against cavalry are now effective against nomads, valks, etc.

Characters:
All characters have had their growth rates increased by 5%
All characters have had their base weapons levels increased by 1 rank
Cath can now promote

Items:
All stat boosters increase their respective stat by 5 (except for boots, those are unchanged)
The Fell Contract has been implemented, allowing thieves to promote into assassins

Classes:
Assassins have been implemented. While largely identical to their FE7 appearance, they now retain the ability to steal
and have received a +30% crit boost to compensate for the lack of lethality in FE6