                                      FINAL FANTASY IV ADVANCE
                                       EUROPEAN FONT FACELIFT
                                         v0.2 Jan 26 2019)

Quick Find: Press Ctrl + F and type in the keyword, then press Enter to search for the section.


      TABLE OF CONTENTS
     Disclaimer .. [DSC1]
	 Overview .... [OVR2]
     Changelog ... [CHG3]
     Credits ..... [CRD4]

====================================================================================================
Disclaimer [DSC1]
==========
- Final Fantasy IV Advance (c) Square Enix. All rights reserved.


- No ownership is claimed by FlamePurge over Final Fantasy IV or the franchise from which it
   originates. Commercial use of this patch, including but not limited to reproduction, sale, etc.
   is strictly prohibited.


- This unofficial, fan-made patch is provided "as-is" on a voluntary (i.e. non-profit) basis.
   FlamePurge is not liable for damage incurred to the end-user, their OS, or their hardware while
   using this patch.


- Apply this patch only to "Final Fantasy IV Advance (Europe) (En,Fr,De,Es,It).gba" with the
   following specifications.
   
    CRC32: 27F2BC67
    MD5: 2FF590AA635590C2F8140C88CBB19025
    SHA-1: B09D50D782B184C8641AEA6DD904AE46C3CC72E6
    SHA-256: BFEE8D0E3B4637EF269242DE07BCAC1369EBA8BA9C0FF3892853B34933F755BF


- Players are encouraged to keep a backup of their original game file in case an error occurs.


- There are 2 patches enclosed. Choose 1 of the following.

   * FFIVA_FontFacelift_v02_SLIM.ips
      Evens out and cleans up the thin menu font intended for the PAL release of the game. The width
      of the letters remains unchanged,

   * FFIVA_FontFacelift_v02_THICK.ips
      Widens various lowercase letters for readability. There are text spillovers with the four
      non-English languages.
====================================================================================================

====================================================================================================
Overview [OVR2]
========
- There are 2 patches: one that slightly widens the 8x8 font, and one that slightly beautifies it
  while keeping the same width.

- The hammer icon is now represented by a hammer, instead of a wrench.

- The shield icon is replaced by that of FFV and VI Advance.

- In the English localization, Yang's command "Power" is now "Focus", and the term "Babel" is now
  "Babil".
====================================================================================================

====================================================================================================
Changelog [CHG3]
=========
v0.1
- In both patches, updated the following characters in the 12x12 dialogue font:
  ! y ? � A � j � � J � � � 1 � 2 3 4 � 0 5 6 9 7 8 � ... � [ ]

- Updated the following characters in the slim 8x8 menu font:
  d b � � � � Y x � � � � / X ... � # $ [ � ] ^ ` ~
  (This font is used in both patches' Music Player.)

- Made a wider variant of the 8x8 menu font, based off of the updated slim version. There will be
  two patches.

- Swapped around the hammer and wrench icons.

- Changed the shield icon to the one used in FFI, V, and VI Advance.

- In the English script, changed one of Yang's commands from "Power" to "Focus".

- In the English script, amended the Config option "B Button Dsh." to "B Button Dash".

- In the English script, the term "Babel" is now "Babil".
====================================================================================================

====================================================================================================
Credits [CRD4]
=======
- Stealth Translations: Windhex32
- HoRRoR: Square Enix Remakes Font Editor
- Dragonsbrethren: Supplied values for Square Enix Remakes Font Editor, and made original Font
  Enhancement project
- Square Enix
...and all you Final Fantasy fans out there!
====================================================================================================