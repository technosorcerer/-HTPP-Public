 

		This readme has been done with Notepad ++ and it is 
		recommended to use it to read it.


		Version 1.1 Changes:
		
		· Crystal Equipment got a slight rise in Defense. 
		· Several Gloves got reworked entirely Stats, 
		  which Classes can use it, and descriptions too.
		· Along with the above, a few Chests were changed.
		· Fixed a small issue with a shop showing Phoenix Down twice.
		· Equipment that Casts damaging Spells got changed. 
		  Items Multi-Targeting Spells like the Mage's Staff 
		  now have a weaker version of the real Spell, and 
		  Thor's Hammer holds Thunder, but a stronger version.
		· The encounter ratio of some dungeon floors got lowered,
		  like the Cavern of Earth L1, Mount Gulg L2, and some 
		  Soul Dungeon floors too.
		· Adjusted a couple of weapons' Stats. Nothing big though.
		· Added an optional patch with a bit more Magic Charges 
		  for Levels 1 to 4. 
		  
		Version 1.2 Changes: 
		
		· 100% Chance of Garland dropping a weapon when defeated.
		· The Scourge Spell from the Black Robe now is less powerful 
		  than the real Spell. Scourge Spell cannot be learnt by 
		  Black Mage, it has to wait to be a Black Wizard. 
		· Encounters have been brought back for Chaos Temple B5. 
		· Turbo Ethers no longer exist, they've been replaced with 
		  an Item that can be sold for some Gil, dropped by Monsters.
		· Ninja got its HP slightly bumped at late Levels.
		· Four Fiend rematches grant more Experience Points. 
		
		Version 1.3 Changes:
		
		· Mage's Staff no longer casts Fira, now it casts Confuse, 
		  it was swapped with Wizard's Staff which now has Fira. 
		· Wizard's Staff Fira and Gauntlet's Blizzara casting effects 
		  got lowered further, with a Spell Power of 12 now. 
		· A couple of Treasure Chest's on Mr. Duergar had their 
		  contents swapped, it was an oversight.
		· Fixed some typos in Item descriptions.  
		· Very slight tweaks to some Monsters' Stats. Minor stuff. 
		
		Version 1.3a change:
		
		· It's a bugfix release. I re-enabled the random battles 
		  in Earthgift's Dark Forest floor, because it turns out 
		  the obligatory battles by talking to monsters require 
		  that the random battles are possible to appear. 
		  
		  So they're back for everything to work... But I still 
		  gave that floor the lowest chances possible for random 
		  encounters to happen. It works.
		

		Updated on 12/04/23
		
		· The main part of the hack has not been changed, but an 
		  optional patch has been added if the player wants to 
		  raise the Level Cap to 99 from the intended 50.
		  
		  Experience charts have been edited accordingly, and the 
		  fixed Stat gains too. Players will get very sparse stat 
		  gains from L51 to L70, and after that there's no fixed 
		  gains at all and whatever the player gets it's by luck. 
		  
		  I personally don't quite like this much as it can break 
		  the sense of challenge by giving the possibility to grind 
		  to a point where your HP is so high you shrug off attacks
		  like nothing, but as an optional thing I guess it's fine.


		Version 1.3b
		
		· The hack has been updated to update Kea's Vancian System, 
		  as it was updated twice in 2023 to fix a couple of issues.
		  
		  
		Version 1.3c 
		
		· I fixed several descriptions of Items and equipment that 
		  named a Spell that no longer exists (NulDeath is now NulTerra).
		  
		· I improved Focus and Focara's Evasion-reducing powers.
		
		· I Fixed an oversight when making the patches that would remove 
		  the increased extra Attack when using weapons that caused extra 
		  damage to specific enemy types depending on which ones you used. 
		  
		  Optional patches, aren't they fun?
		
		· I remade the patches so the "More MP" is an extra patch instead 
		  of the full patch with only that change. 
		
		· I also did a cleanup of the readme, it was needed...

	    o--------------------------------------------o
	    |Final Fantasy I: Dawn of Souls Maeson Readme|
		o--------------------------------------------o
						Version 1.3c
	
	01 - Installation
	02 - Introduction
	03 - Main points of this Hack 
	04 - Information about Classes 
	05 - Information about Spells 
	06 - Information about Weapons 
	07 - Information about Armor 
	08 - Information about Monsters
	09 - Information about other Gameplay changes
	10 - Average Level Progression and Tips
		
	Thanks and Credits to: 
	
	Kea, for creating awesome hacking notes for many aspects of this game:
	
				http://www.romhacking.net/documents/750/
				
	exline, for the Data Extraction/Insertion tools
	and his feedback after playing my hack:
	
				http://www.romhacking.net/utilities/1291/
				
		Note: Since I published my hack, exline and me have been 
		talking quite a bit. He was able to fix the bug I found 
		on his editor and add new features, and his feedback also 
		helped me to improve and tweak certain things to make 
		a better hack. It was a great experience all around!
				
	JeffLudwig, for his Mod of Balance and hacking notes: 
	
				http://jeffludwig.com/finalfantasy/download.php

		o----------------o
		|01- Installation|
		o----------------o
		
 Very simple process, really. It's an IPS Patch, so you 
 need something like Lunar IPS and a clean US rom. 
 
 You grab the Main Patch and apply it to the Rom with 
 a tool such as Lunar IPS, and you're done. 
 
 This hack is compatible with two other Hacks made by 
 other people, these being:

 Kea's "Unrunnable Battle Notifications", which will 
 warn you when you won't be able to run from a specific 
 battle (like from Piscodemons, or Bosses). 
 
 http://www.romhacking.net/hacks/2958/
 
 And Rabite's Improved Equipment Viewer, which is also 
 great and offers a much, much better way of seeing 
 equipments specific stats (by "using" the equipment 
 on the Items menu). 
 
 http://www.romhacking.net/hacks/5685/
 
 I totally recommend using them, both with an unmodded 
 version and with my hack.
 
 Also, after applying my patch, and these two if you want,
 you can apply one of my optional patches too. 
 
 They're very simple, really. One changes the palette of 
 the Ninja so it's red like in the original game as, funny 
 as I find it to be, some people found it to be a "betrayal"
 to change it to green. 
 
 It wasn't hard to do so why the hell not add it as an extra 
 option. 
 
 The second optional patch lowers the difficulty slightly, for 
 those that I guess don't want to be challenged much. Enemies
 physical and magical power will be toned down, and that's the 
 only change it introduces. 
 
 The third optional patch brings back the Level 99 Cap from the 
 original GBA version. My hack puts a Level 50 Cap as it was on 
 the origignal NES game, but some people apparently like to grind 
 a lot. You will get fixed Stat Gains from Level 51 up to Level 70
 but they are smaller than on prior Levels. After that, it's all 
 about lucky stat gains.
 
 The fourth one raises the number of Magic Points your characters 
 get for Levels 1 to 4, mostly made for party setups that might 
 not be to usual, so there's a few more casts to help them out.
 
 The last one increases the HP of Bosses a so boss battles take
 a bit longer, as sometimes I kinda feel like I wanted them to 
 last a bit more, but that might be just me. Nothing else is changed.
 
------------------------------------------------------------------------------------------------- 
------------------------------------------------------------------------------------------------- 		
		o----------------o
		|02- Introduction|
		o----------------o
		
 Welcome to yet another ridiculous project of mine. 
		
 At this point, what to say... I wanted to do something with FF1, 
 but there were many cool projects already with the NES Version, 
 and I always wanted to mess around with this remake, because 
 I have a soft spot for it, even with its downside which 
 believe me, annoys me, but I can look beyond that.
 
 FF1 in this Dawn of Souls collection is built from the Easy Mode 
 from Final Fantasy Origins, the PS1 remake based on the Wonderswan
 Color remake, and the PS1 version was my first contact with FF1, 
 being european and the NES version never releasing here, ya know...
 
 The BIG issue with this version being made from the Easy Mode, is 
 that the Experience curve has been altered so much it basically 
 destroys any semblance of challenge and game design from the original.
 
 I'll give you some quick numbers:
 
 In older versions of FF1, you would finish the game at around Levels
 26 to 28 give or take, some people a bit earlier, some a bit later,
 from what I can see in guides and forums across many years. 
 Maximum Level was 50. 
 
 This low level has to do with the inspiration that Squaresoft got 
 from RPG franchises such as Dungeons and Dragons and Wizardry, which 
 had much lower Levels than what we're used to today. It was the norm. 
 
 But with the Easy Mode changes, the Exp. needed for each Level has 
 been reduced dramatically, so people can reach Level 60, 70, heck,
 I've seen guides recommend to get to Level 80 or higher to finish 
 the game... And of course, the Max. Level went from 50 to 99. 
 
 So getting to much higher Levels already can break the overall feeling
 of the game, specially by getting more HP and MP... But here's the 
 actual problem with all of this: 
 
 Non-Boss Monsters' stats were NOT CHANGED at all. They're exactly 
 the same as they were on the NES days. And Bosses were marginally 
 improved, but changes are so little that they're kinda pointless.
 
 The only thing to get seriously improved is the Final Boss, and they 
 went so hard on making it powerful that's hilarious if you ask me, 
 when you compare how 95% of the bestiary got nothing tweaked. 
 
 That's why people have been issues with pretty much all Final 
 Fantasy "modern" versions since then.
 
 ...In any case, with this hack I wanted to take advantage of all 
 the good things this version has compared to the NES original, 
 and create a more challenging adventure that also offers some new 
 toys and a few new things.
 
 For this end, I will base this hack on Kea's Vancian MP System patch
 that she developed. It is a fantastic, fantastic piece of work, 
 not only it works wonders, the original MP system also is a really 
 important part of the experience to many. 
 
 Nothing against the "general MP system", if you're asking, when 
 MP values for Spells, Max MP and such is well balanced, it is a 
 great system too, and many of my favourite RPGs use it. 
 
 But I was so surprised with Kea's work that it was what made me 
 consider doing this hack in the first place, because I could make 
 something that would feel different from Jeff Ludwig's own hack, 
 the well known Mod of Balance. 
 
 In any case, the actual offender on this matter on the modern 
 FF1 versions isn't the "general MP System", but how you can get 
 infinite Ethers or other MP restorative items, making managing 
 MP non-existent, which is what actually hurts the game.
 
 If you couldn't recover MP so easily you would actually have 
 harder restrictions on MP usage, because with Vancian you at 
 least can use lower Magic Levels and save the higher ones for 
 harder battles.
 
 ...Of course, at least that's how I see it. It's not like the 
 Easy Mode from the PS1 release isn't ridiculous on its own, 
 either. Check it out for yourself.

 Anyway, let's go on with the show. 
 
------------------------------------------------------------------------------------------------- 
------------------------------------------------------------------------------------------------- 
 
		o----------------------------o
		|03- Main points of this Hack|
		o----------------------------o

 The goals and features of this hack are as follow:
 
 First and foremost, increase the challenge of the game, while also 
 removing those random 1HKO moments. I'm looking at you, Ice Cavern...
 
 This is done through several ways, such as making monsters stronger, 
 obviously, but also by tweaking their AI, abilities, your equipment,
 modifying the Exp. Curve for slower levelling up, and lowering the 
 Max. Level cap to 50 instead of 99. Add to that things like the
 Vancian MP System and not being able to buy MP restorative Items,
 that also does wonders.
 
 There's a pretty strong focus on the use of the Nul-Spells, as it is 
 a feature of this game that I always found quite defining, so it'll 
 be of the upmost importance to use them well, particularly against 
 Bosses. Fortunately they can be learnt by half of the Classes. 
 
 Tweaked Weapons to make each type distinct and useful on their own way, 
 also modifying defensive gear to make it more useful and versatile. 
 Knives give extra hits more easily, Standard Swords are well balanced,
 and Axes are strong and raise HP, but are inaccurate and slow, for 
 example. 
 
 Tweak Magic to replace some of the "useless" or repetitive Spells with 
 something more useful, making Intelligence more important, and also 
 expanding the Elements available to Black Magic with Poison and Mind. 
 
 Classes have also gone through some modifications. They still resemble 
 their original visions of course, but changes were made to many aspects 
 to make them a bit more versatile in most cases. 
 
 Shops, Treasure Chests, and the Soul Dungeons have been also extensively 
 tweaked, the latter having special attention to create strong but beatable
 Bosses as you go through the game, granting you cool equipment to use in 
 your adventure.

 I also removed some cheap things, like being able to buff your Attack or 
 Defense up to 255, a "classic" thing of this title that, I honestly never 
 liked much. Limit has been put at 40, and believe me, it's more than enough.

 Encounter rate has actually been lowered a bit. FF1 can be rather brutal, 
 sometimes throwing you in a battle one step before the one before it. 
 Of course, because how it works, sometimes you will notice, other times 
 you won't as much. The Soul Dungeons tend to be less harsh, thankfully. 

 Oh, and talking about the Soul Dungeons... The monsters there give no 
 Experience. They reward you with Gil and Items, though. I did this 
 because, to me, the many battles you go in these places will ALWAYS 
 make your Levels go very high, which in turn destroys the challenge 
 for both these dungeons' Bosses and the main adventure.
 
 I'm sure someone out there will get mad at it, but I really don't 
 care. I much rather not not disrupt Level progression like it can
 and often does happen in the original game. 

 All the relevant text that needed to be edited for equipment, spells and 
 Items has been corrected, too. 
 
 Oh, and by the way, I fixed two "glitches" on this game, one of them being 
 the... Rather long-lived "Weapon Critical Hit Glitch", even if in reality 
 is not a glitch in the code at all, but entirely on the developers' not 
 paying attention or simply being confused.
 
 What this "glitch" is about is that they confused the Weapon ID and the 
 Critical Hit ratio values. Knife is weapon 1, and it has 1 Critical Hit
 ratio value, the Mythril Axe is weapon 19, and it has 19 Crit, the Healing 
 Staff is weapon 30, and it has 30 Crit and such. They literally used the 
 Crit value list as the weapon ID list, even when there was already a 
 weapon ID list. 
 
 And thats something that wasn't fixed until after later versions of this 
 game.
 
 The other is also an oversight, too, and it's with the Angel Ring.
 Supposedly, you could get it from one of the Soul Dungeons on a very 
 specific floor, but because a mistake it cannot appear. It is obtainable
 in my hack, but there's no luck involved, as it is one of the rewards for 
 defeating one of the Soul Dungeon Bosses.  
 
 I also fixed a glitch with Intelligence, but that wasn't noticeable in the 
 original game... But it certainly put me in panic mode when I found it and 
 I had to stop everything, and almost had to rework the entire hack based on 
 it. Thank goodness I was lucky enough to get it to work!
 
		o------------------------------o
		|04 - Information about Classes| 
		o------------------------------o
 
	This is a quick table to show the Starting Statistics of each Class, and also 
	the Minimum Stats it will reach at Level 50. Remember you have a small chance 
	to have an increase of an Stat randomly. HP is quite hard to pin down because 
	how random it is, even if I don't count the Strong HP gains. 
							
	Class		  HP	Str	Agi	Vit	Int	Luc		Acc	MDL    Hit Eva	MDF							
	-------------------------------------------------------------------
	Warrior		  35	 10   5  10   5  5		 +3  +2		10  50   10
	   LV50 Min. 700~	 40  20  35  20 20		 +4  +3
	------------------------------------------------------------------
	Thief		  33	  5	 10	  5   5 10		 +4	 +2		12  65   12
	   LV50 Min. 555~~	 30  40  20  20 25		 +4  +3
	-------------------------------------------------------------------
	Monk		  38	 10	 10   5   5  5		 +2  +2		10	55	 12	* Less Acc. needed, Monk
	   LV50 Min. 720~	 30  30  40  20 10		 +2  +4					  gets two hits per bonus
	-------------------------------------------------------------------   
	Red Mage 	  33	  7   7   7   7  7		 +3  +3		10  50   20
	   LV50 Min. 555~	 30  25  20  35 20		 +4  +4
	-------------------------------------------------------------------
	White Mage	  30	  5   5   5  10 10		 +2  +4		10	50	 25
	   LV50 Min. 510~	 20  25  20  45 20		 +3  +5
	-------------------------------------------------------------------
	Black Mage    30	  5  10   5  10  5		 +2  +4		10	55	 25
	   LV50 Min. 490~	 15  35	 15  45 25		 +3  +5
	-------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------------------------
Warrior / Knight 
-------------------------------------------------------------------------------------------------------------------------
					    HP Str Agi Vit Int Luc   Hit  M.Def Eva  
		Starting Stats  35  10   5  10   5   5   10+3 10+2   50
	Min. Lv. 50  Stats 700~ 40  20  35  20  20     +4   +3 
				Max MP: 6/6/5/5/4/0/0/0					Higher MP Version: 8/7/6/6/5/0/0/0
-------------------------------------------------------------------------------------------------------------------------
 The Warrior is, for the most part, a rather simplistic and direct Class.  High HP, good
 physical stats, and it's good at holding pointy sticks and swing them at bad guys. 
 That's pretty much it, on paper at least. 
 
 But those "pointy sticks" aren't created equal, and in fact, each Weapon type offers something
 different, and depending which one the Warrior wants to use, it may need to shuffle other pieces
 of gear too to make most of them. Please check the Weapon's section for more details. 

 Thus, to make most of each type of Weapon, and the Warrior too, one must pay attention to the
 rest its equipment. Looking for Agility-granting  gear to boost Accuracy and gaining a higher
 of hits while wielding heavier weapons is of upmost help, but if you don't reach a new Accuracy
 threshold (every 32 points), then you'll want to get Strength-raising gear, to make each hit
 deal more damage, which goes a long way.
 
 Something similar happens with defensive gear. The more protective it is, the larger the
 Evasion cut will be. This Class is by far the beefiest one, combining its tremendous HP and
 access to the toughest Armor, and if fully geared with the strongest defensive gear, it will 
 also have the lowest Evasion rate. The Warrior can also equip every Shield, which grans it
 access to Elemental resistances without the need to change the other gear, a very useful thing. 
 
 Upon promotion, the Warrior becomes a Knight. The biggest change is that it can know learn 
 a number of Spells, mostly White, from Levels 1 to 5. The Knight does not have the magical
 prowess to become a fastantic healer, but as a side support it can be useful. The Knight
 even gets a unique spell, Guard, a stronger version of Protect, granting twice the Defense,
 you probably will find use for it during Boss fights, to provide survivality to fragile
 Classes such as the Black Mage/Wizard. 
 
 Overall, the Knight is a reliable Class that can make use of most of the treasure you will find.
-------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------
Thief / Ninja 
-------------------------------------------------------------------------------------------------------------------------
					    HP Str Agi Vit Int Luc   Hit  M.Def Eva  
		Starting Stats  33   5  10   5   5  10   15+4 12+2   65
	Min. Lv. 50  Stats 555~ 30  40  20  20  25     +4   +3 
				Max MP: 6/6/5/5/4/0/0/0					Higher MP Version: 8/7/6/6/5/0/0/0
-------------------------------------------------------------------------------------------------------------------------
 The Thief is, in a way, a nimbler version of the Warrior. Less HP, Strength, and smaller 
 repertoire of equipment, but higher Agility, Accuracy, Evasion and it has access to gear
 unavailable to the Warrior. And just like the Warrior, no Magic at all. 
 
 Unlike the Warrior though, this Class makes the choice for you, and it focus on lighter Weapons
 with higher Accuracy, and of course, higher number of Hits. Having access to Daggers, Standard
 Swords and Katanas still grant the Thief lots of variety, just not as much as the Warrior. On 
 the other hand, it can't take hits like the Warrior, but it avoids hits more often which helps
 with the lesser HP. 
 
 Just like with the Class above, to unlock the full potential of the  Thief you will need to manage
 its defensive gear to provide Agility or Strength boosts depending on the situation. The Thief's 
 Accuracy grows really fast, and doesn't have a limit of 255 points, so it can get the largest number
 of Hits compared to any weapon user with little competitition. 

 Comparing its overall physical damage performance with the Warrior, the Warrior deals higher damage 
 per Hit (specially if using Heavy Swords and Axes), while the Thief does less powerful Hits in a 
 higher quantity. All of this means that the Warrior deals better with Monsters with higher Defense, 
 as your Attack Power doesn't suffer as much of a drop, while the Thief does better against creatures 
 with higher Evasion, which also tend to have less Defense. Both can work fine overall, though. 
 
 Upon promotion, the Thief becomes a Ninja. The Ninja gets some new equipment options, and a selection
 of varied Magic Spells through Level 1 to Level 5. While its Intelligence is not nearly as high as needed
 to compete with a Black Wizard (or even a Red Wizard), with proper gear setup it can become a decent
 spellcaster to deal with large Monster groups. Of higher use will be Status Effect Spells, which don't
 require as much Intelligence and no fiddling with equipment, and of course, the Spells that improve
 physical capabilities such as Temper. 
 
 Overall, the Ninja is a bit riskier than the Knight, with less survivality, but has some extra
 tricks on the offensive side, and can deal with groups on enemies, which the Warrior can't do. 
-------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------
Monk / Master 
-------------------------------------------------------------------------------------------------------------------------
					    HP Str Agi Vit Int Luc   Hit  M.Def Eva  
		Starting Stats  38  10  10   5   5   5   10+2 12+2   55
	Min. Lv. 50  Stats 710~ 30  30  40  20  10     +2   +4 
				Max MP: 6/6/5/5/4/0/0/0					Higher MP Version: 8/7/6/6/5/0/0/0
-------------------------------------------------------------------------------------------------------------------------
 The Monk is... Yet another variation on your usual front line fighter. It ends up being quite
 different than the other two Classes above, but early on functions very similar.
 
 In comparison with the Warrior and Thief, the Monk has the high HP and Strength of the former,
 but the more nimbleness of the later, with a completely different set of gear and its own
 features that develop over time. No Magic too, of course.

 The defining aspect of this Class is it's ability to fight unarmed, a skill that improves
 alongside the Monk as it Levels Up. That said, though, the power of its fists develops a
 bit slowly early on, and the Monk will need to rely on Weapons for a time. 

 Which is fine, as it has a few exclusive Weapons to itself, Martial Arts gear. Nunchucks and
 the Crossier will keep the Monk being a reliable physical damage dealer until it's ready to
 pummel foes with its bare hands.
 
 What makes this Class' fists so powerful is that they get one hit more than other Classes with
 each 32 Accuracy. So while a Warrior might do 2 Hits with the same Accuracy, a Monk will do 4.
 Where a Thief will do 3, the Monk will do 6! Late into the adventure, it shouldn't be surprising
 that this Class ends up being the most powerful physical damage dealer.
 
 That said, the Monk is not perfect, and it has some weak points. No Weapons means no extra effects,
 elements or bonuses, no Accuracy or Critical increases either, and as pointed out, it takes some time
 to get good with its fists, and Agility-granting gear is really, really useful for it. Also, this 
 Class has a very limited defensive gear selection, and it's in a distant third (or even fourth if
 we count the Red Wizard) place on pure Defense, closer to the White and Black Mages than the others. 
 
 Fortunately, it has above average Evasion, and its equipment does not weight nearly as much as Armors,
 so it will avoid hits more often than the Knight, and its high HP will make it hard to kill in few hits. 
 
 Upon promotion, the Monk becomes a Master. Not much changes, as he doesn't use Weapons after a while,
 and gear is limited, but it gets a number of White Spells from Levels 1 to 5, and can do some pretty
 good support to the team in the way of the Nul-Spells to lower Fire, Ice and Thunder damage. It can
 also heal single allies and provide an Evasion boost with Invis, so it plays a quite nice role in
 a team during Boss fights, as it removes some stress from the Red and White Wizards.

 While the Master does not increase its Accuracy gains, its Magic Defense gains double, becoming 
 better at resisting magical damage than the Knight or Ninja, to contrast those Classes' higher
 physical Defense, although its effect is not as noticeable as to make it that much better. 
 
 Overall, the Master takes some to develop, and has moments of "equipment drought" but ends up
 being a Class that can dish great damage while having some significant support for the team. 
-------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------  
 White Mage / White Wizard 
-------------------------------------------------------------------------------------------------------------------------
  					    HP Str Agi Vit Int Luc   Hit  M.Def Eva  
		Starting Stats  30   5   5   5  10  10   10+2 25+4   50
	Min. Lv. 50  Stats 510~ 20  25  20  45  20     +3   +5 
				Max MP: 10/10/10/10/10/10/10/10					Higher MP Version: 18/16/14/12/10/10/10/10
-------------------------------------------------------------------------------------------------------------------------
 The White Mage is... Well, you can imagine it just by the name, don't you? 

 A specialist on White Magic, it's capable of learning almost every Spell under that group, and
 it has the Intelligence and MP Charges to back it up quite well, making it simply the best support
 Class in the game. 

 Healing, elemental protection, granting survivality bonuses to Defense and Evasion, being able to silence
 enemy spellcasters, revive allies... Even some damage dealing Spells; but most of those only affect
 Undead enemies, which are numerous early on. 
 
 Now, while being mainly a spellcaster, and of course being able to wield Staves, the White Mage also
 gets access to  Hammers, which hold colsiderable power and in hands of the White Mage can work decently,
 often enough to take out weakened foes, or doing some lucky critical strike. Not just that, it is also
 able to wield the Braveheart, and with proper support can be a decent fighter.
 
 At least, damage-wise. Just remember to help it with some Agility-boosting equipment to reach higher
 number of hits if you can get to a multiplier. 
 
 At the end of the day, it is a mage though, and it has lower HP, and the White Mage's defensive gear
 selection is typical of a mage, with robes, hats and such. It can equip Armlets, which help, specially
 since some raise HP, but do not let it take too many hits. One advantage of Hammers is that also raise
 HP a bit, which is always useful, although it can create the debate between giving it Staves for Intellect
 bonuses (for better healing) or use Hammers for more survivality and better damage, good in normal battles. 

 Upon promotion, the White Mage becomes a White Wizard, gaining access to Level 8 White Magic, a few more
 pieces of equipment,  and... Well, better Accuracy and Magic Defense gains. There's really not much change,
 because this Class doesn't need to reinvent itself, it's already reliable and for many, necessary.
 
 And that part is really all that needs to be said. The White Wizard is often an essential part of the team. 
-------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------
 Black Mage / Black Wizard 
-------------------------------------------------------------------------------------------------------------------------
  					    HP Str Agi Vit Int Luc   Hit  M.Def Eva  
		Starting Stats  30   5   5   5  10  10   10+2 25+4   50
	Min. Lv. 50  Stats 490~ 15  35  15  45  25     +3   +5 
				Max MP: 10/10/10/10/10/10/10/10					Higher MP Version: 18/16/14/12/10/10/10/10
-------------------------------------------------------------------------------------------------------------------------
 Guess what the Black Mage does? Yeah, total surprise. 
 
 The Black Mage is physically weak. Low Strength, low Stamina, low HP. Surprisingly good Agility though, and 
 excellent Intelligence. Hitting things is not this Class' main objective (yet it has the tools to be able to),
 but to cast great Black Magic. 
 
 The Black Mage's bread and butter is taking away groups of Monsters with elemental Spells, causing nasty 
 Status Effects to make its team survive longer, and provide some support, specifically to physical attackers
 of the group. Of course, one has to use Magic with a bit of brain. MP Charges are limited, and restoring MP
 is not easy. Ethers are sparse, and once in a dungeon, you cannot rest. 
 
 Talking about elements, the Black Mage has access to all: Fire, Ice, Thunder, Earth, Poison, Mind and
 Neutral, so it can take advantage of them, and needs to learn which monsters resists each in order
 to not waste MP, or risk taking longer to end a battle, translating into more damage taken by the team. 
 
 This Class' favourite Weapon is, by far, Staves. They increase Intelligence, which improves Spell damage.
 With that said, it is an adept user of Daggers, and with the Temper, Saber and Haste Spells, it can transform
 into a decent physical fighter in a pinch, although of course, it is better to support teammates. 
 
 Talking about support, the Spell Swift will be very useful during many Boss Fights. It protects the team from 
 Slow Status, which is very nasty and has no reliable way of healing it beyond getting knocked out and be revived,
 so it is quite useful. In the same way, Slowra will be useful against Bosses, as some really like using Haste, 
 or boosting their Attack power, so slowing them down is an indirect way of helping your team. 
 
 Its defensive gear is the same as the White Mage, with light and medium gear available. Differences are that
 the White Mage can reach higher HP thanks to Hammers, but the Black Mage has higer Evasion, and with a Cloak
 a character can stop hits sometimes.
 
 Upon promotion, the Black Mage becomes the Black Wizard. It gets access to quite a few Spells that couldn't
 learn before, not just Level 8, but also for lower Levels, like Haste, Harm or Quake. Just like the White Wizard,
 a few equipment pieces become available and the Accuracy and Magic Defense gains grow, both Classes having
 spectacular Magic Defense, a payoff for their very low HP. 

 The Black Wizard might be fragile, but the risks involved certainly pay off, and will make your life easier 
 and the travelling safer... By spelling doom to evildoers.
-------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------
Red Mage / Red Wizard  
-------------------------------------------------------------------------------------------------------------------------
					    HP Str Agi Vit Int Luc   Hit  M.Def Eva  
		Starting Stats  33   7   7   7   7   7   10+3 20+3   50
	Min. Lv. 50  Stats 555~ 30  25  20  35  20     +4   +4 
				Max MP: 8/8/8/8/8/8/8/0					Higher MP Version: 14/12/10/10/8/8/8/0
-------------------------------------------------------------------------------------------------------------------------
 The Red Mage is, basically, a mix of the other Classes besides the Monk. It can wield a good variety of weapons and gear 
 like the Warrior and Ninja, and it can use Magic on a level closer to the Black and White Mages... Yet is not better than 
 any other Class doing their specialty when compared under the same conditions. Can get really close on some, though.  
 
 And that's basically most of what it needed to be said. It's an extremely versatile Class that can fit in many roles and 
 most teams. Having access to Daggers, Standard Swords, most Katanas and even some Heavy Weapons and some Staves, plus a  
 good variety of heavy, medium and light defensive gear, with some exclusive items to its name give the Red Mage many ways
 to set up. Having access to damage-dealing Spells to wipe out groups of Monsters, being able to raise its physical power, 
 and heal or provide elemental resistances is way too great of an asset.  
 
 But that's also its weakness. Forget not being able to wield the most powerful weapon, or learn the most powerful Spells, 
 the real weakness of the Red Mage is that's impossible to be geared for all roles it can play at the same time, and while 
 the variety of Spells it can learn is amazing, it has to deal with the limitation of three per Spell Level, which hurts 
 the Red Mage so much more than any other Class. 
 
 These two things force your feet back to the ground and consider what you really need or want in your team.
 You could run into issues like having to change its Spells and wasting money, and affect other team members' purchases
 because of it. 
  
 Upon promotion, the Red Mage becomes a Red Wizard. Not a radical change. It can learn a few more Spells, can equip 
 a few more things, but it's basically the same. Its Accuracy and Magic Defense gains become quite great, which balance 
 its moderate HP and Evasion. 
 
 No matter how you look at this Class, it always can have something of value to offer. The problem is being able to 
 get it fit squarely in your team, depending on what you need, or what you can get it to do at that point in the 
 adventure. But if you can find the right set up? Man, it's something else... 
-------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------

													White Magic Availability

				o--------------------------------------o				o--------------------------------------o
				|	White Magic:	KNI	NIN	MAS	RED	WHI|				|	White Magic:	KNI	NIN	MAS	RED	WHI|
				|L1	Cure			 X	     X	 X	 X | 				|L5	Curaga			 X 	 	 X	 X 	 X |
				|	Dia				 		  		 X |				|	Healaga			 X           X   X |
				|	Protect			 X		     X	 X |				|	Life			 X		 X   X   X |
				|	Blink 				 X	 X	     X |				|	Diaga					 X       X |		
				o--------------------------------------o				o--------------------------------------o
				|L2	Silence 		 X	 X   X   X   X |		        |L6  Stona			 			 X   X |
				|	Invis			 X	     	 X	 X |				|	Exit 						 X   X |
				|	Guard 			 X	    		   |				|	Protera 					 X   X |
				|	NulShock		  		 X	 X	 X |				|	Invisira					 X   X |
				o--------------------------------------o				o--------------------------------------o
				|L3	Cura 			 X		 X	 X	 X |				|L7	Curaja						     X |
				|	Heal 			 X			 X	 X |				|	Healaga						 X   X |
				|	Diara 					 X       X |				|	NulTerra					 X   X |
				|	NulBlaze			 	 X	 X	 X |				|	Diaja							 X |
				o--------------------------------------o				o--------------------------------------o
				|L4	Rest			 X			 X	 X |				|	Full Life						 X |
				|  	Poisona 		 X		 X	 X	 X |				|	NulAll							 X |
				|	Vox				 X		 X		 X |				|	Dispel							 X |
				|	NulFrost				 X	 X	 X |				|	Holy 							 X |
				o--------------------------------------o 				o--------------------------------------o

													Black Magic Availability

				o--------------------------------------o 				o--------------------------------------o
				|	Black Magic:	KNI	NIN	MAS	RED	BLA|				|	Black Magic:	KNI	NIN	MAS	RED	BLA|
				|L1	Fire			     X       X   X |				|L5 Firaga				 X       X   X |
				|   Thunder				 X       X   X |				|	Scourge						 X   X |
				|	Focus 			 X   X   X   X   X |				|	Slowra				 X		 X   X | 
				|	Sleep 				 X       X   X |				|	Teleport 		 X   X   X   X   X |
				o--------------------------------------o				o--------------------------------------o
				|L2	Blizzard		     X       X   X |				|L6  Thundaga					 X   X | 
				|	Dark 				 X       X   X |				|	Harm							 X | 
				|	Slow 				 X		 X   X |				|	Quake 							 X | 
				|	Temper 				 X       X   X |				|	Death 						 X   X |
				o--------------------------------------o				o--------------------------------------o
				|L3	Fira 				 X       X   X |				|L7  Blizzaga					 X   X |
				|	Thundara			 X       X   X |				|	Break 						     X | 
				|	Focara			 X   X   X   X   X |				|	Saber 						 X   X |
				|	Hold 				 X	     X   X |				|	Swift 						 X   X |
				o--------------------------------------o				o--------------------------------------o
				|L4	Blizzara		     X       X   X |				|L8	Flare 							 X |
				|	Confuse 		     X       X   X |				|	Stop							 X |
				|	Sleepra 		  	 X       X   X |				|	Kill 							 X |
				|	Haste 			  	 X       X   X |				|	Warp 							 X |
				o--------------------------------------o 				o--------------------------------------o

-------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------

		o-----------------------------o
		|05 - Information about Spells|
		o-----------------------------o 
		
 Quite a few changes here. For one, some spells are gone. 
 
 Fear no longer exists, and in its place comes Rest, a Spell that heals Battle-only
 Status effects, Blind, Darkness and Paralysis/Stun.

 Because Rest already heals Darkness, away goes Blind, and here comes Guard, a Knight
 exclusive Spell. It provides 20 Defense instead of Proctect's 10, and it's aimed 
 to give a slight support role to the Knight so it can help squishier Classes survive 
 physical Hits. 

 Nul-Spells also got a slight upgrade. Each one resist an element and a Status effect.
 NulShock lowers Thunder damage, protects from Paralysis/Stun.
 NulBlaze lowers Fire damage, protects from Sleep. 
 NulFrost lowers Ice damage, protects from Silence. 

 Nuldeath has been changed too, now it is NulEarth. It resists Earth element damage, 
 and helps resist Instant Death moves (Death, Kill, Petrification, and enemies that
 cause Death with their attacks), so you get help to resist all four main elements.

 Stun is gone too. Having two Spells that did the same wasn't great, specially since 
 Hold has been improved. Stun was replaced by Harm, a strong, single target Spell of 
 the Mind element. Mind acts as any other element you know. Some enemies resist it, 
 a few might be weak to it. It's there to provide a good single target option for the 
 Black Wizard, which I kinda miss in this game. Some Monsters do use it, be careful!

 Another change is to lower the number of Instant Death Spells. Seriously...
 Death, Kill, Scourge, Quake, Break, Warp... Do we really need all these?
 
 That's why Quake and Scourge are no longer that, but elemental Spells too, offering 
 damage from elements we never got to use. They're slightly stronger than  -Aga Spells, 
 and they also have been moved to later parts of the game with prices coherent for their 
 new state. They being resisted slightly more often offsets their slightly superior power
 to keep them all useful. 

 Blind is also gone, because Darkness exists already, it is multi-target already and it  
 works better now. It has been replaced with Swift, a quite important Spell for Boss fights, 
 as it protects your team from the Slow "Status Effect". 

 Slow CANNOT be healed unless you're KO'd, and it lowers a character's hit to 1, basically 
 rendering them useless physically. That's why is important to protect yourself from it!
 The reason why it can't be healed by something like a Remedy it's because code-wise it
 is not a Status Effect, but more akin to the "auras" that the Nul-Spells, Protect and 
 such cause. 

 Status Spells got overall more useful, to the point you probably want Slowra for tough 
 monsters such as Tyrannosaur or Bosses, specially those that like to cast Haste. 

 And if you find the power of most spells lower than they would normally be, it's not 
 a mistake. In the original NES/PS1 game, Intelligence did nothing. Really, it's glitched. 

 This is why some people find the Red Mage better, because the Black Mage did offer little to 
 compensate. It's honestly one of the glitches that bothers me the most in those versions. 

 Thankfully the NES version at least got some accomplished hackers to create patches 
 to correct this. I wish something could be done for the PS1 version, though...

 In the Dawn of Souls version, Intelligence works, at long last! ...But it is very limited,
 as it only offers a small bonus of damage every 10 points, and because stat gains have been 
 slowed down because of the super-fast levelling rhythm of this version, you only feel it ever
 so slightly. 

 At Level 50 a Black Mage would have around 37 Intelligence without any lucky random stat 
 increases (a Black Mage on the NES/PS1 at Level 25 would have a minimum of 44 Intelligence, 
 to give you an idea of what a change it is) so you'll only get like 3 or 4 times said bonus
 throughout the game and probably won't notice it all that much.  

 In my hack, that changes so every 3 points of Intelligence any character will get said bonus
 to damaging spells. Because these small upgrades happen much more often, you will find that 
 that each individual spell keeps their usefulness way, waaay longer than in the original game. 
 
 You will find yourself using Fire and Thunder, Level 1 Spells to deal with monsters well after 
 having access Levels 2 and 3, maybe even 4. And the same goes for the -Ara Spells, even when
 you have access to the -Aga Spells you will still rely on lower Spells, both because they're
 still worth using and to preseve Magic Charges (or MP if you call if that) of higher Levels 
 for stronger foes, or for the boss of whatever area you're on.  

 Of course, there's a difference of power between tiers of spells, it's not like Fira and Firaga
 would cause the same damage. Oh, and talking about that, All three -Ara and all three -Aga Spells
 do share the same Power, simply because they way Magic Damage scales is so solid that I don't find 
 necessary to do what the original game did, which made Blizzaga stronger than Thundaga, which was 
 stronger than Firaga, for example.  

 The changes made to Intelligence and the effect it makes on spells is now so important that  
 the entire thing needed to be retooled, Monster Stats and AI included. 

-----------------------------------------------------------------------------------------------------------------
				White Magic:			
-----------------------------------------------------------------------------------------------------------------
	Level 1:	Name	Power	Acc		Elem.	Target	Price	
				Cure	  20	 --		Healing	S.Ally	   50	Restores a small amount of HP to an ally. 
				Dia		  20 	 --		Other	All En.	   50	Causes good damage to Undead, and Undead only.
				Protect	  --	 --		Status	S.Ally	   50	Raises the Defense of an ally by 10.
				Blink	  --	 --		Status	Caster	   50	Raises the Caster's Evasion by 80.
				-------------------------------------------------------------------------------------------------
	Level 2:	Name	Power	Acc		Elem.	Target	Price	
				-------------------------------------------------------------------------------------------------
				Silence	  --	 64		Status	All En.   250	Tries to prevent foes from casting Spells. 
				Invis	  --	 --		Status	S.Ally	  250	Raises the Evasion of an ally by 50. 
				Guard	  --	 --		Status	S.Ally   4000	Raises the Defense of an ally by 20.
				NulShock  --	 --		Status	Party	  250	Lowers Thunder damage, protects from Paralysis.
				-------------------------------------------------------------------------------------------------
	Level 3:
				-------------------------------------------------------------------------------------------------
				Cura	  40 	 --		Healing	S.Ally	 1200	Restores a decent amount of HP to an ally. 
				Heal 	  10	 --		Healing Party    1500	Restores a low amount of HP to the party.
				Diara	  40	 --		Other	All En.  1000	Causes large damage to Undead, and Undead only.
				NulBlaze  --	 --		Status  Party	 1000	Lowers Fire damage, protects from Sleep. 	
				-------------------------------------------------------------------------------------------------
	Level 4:	
				-------------------------------------------------------------------------------------------------
				Rest	  -- 	 --		Status	S.Ally	 1500	Heals Darkness, Paralysis and Sleep from one ally.
				Poisona   --	 --		Status  S.Ally   1500	Removes Poison from an ally. 
				Vox		  --	 --		Status	S.Ally   1500	Removes Silence from an ally.
				NulFrost  --	 --		Status  Party	 2000	Lowers Ice damage, protects from Silence. 	
				-------------------------------------------------------------------------------------------------
	Level 5:	
				-------------------------------------------------------------------------------------------------
				Curaga	  70	 --		Healing	S.Ally	 6000	Restores a very high amount of HP to a single ally.
				Healara   32	 --		Healing Party	 8000	Restores a moderate amount of HP to the party.
				Life	  --	 --		Status	S.Ally   4000	Revives one Ally with 1 HP. 
				Diara	  60	 --		Other	All En.	 5000	Causes heavy damage to Undead, and Undead only.
				-------------------------------------------------------------------------------------------------
	Level 6:
				-------------------------------------------------------------------------------------------------
				Protera   --	 --		Status  Party	15000	Raises the Defense of the party by 15. 
				Invisira  --     --		Status 	Party	25000	Raises the Evasion of the party by 40. 
				Stona	  --	 --		Status	S.Ally   5000	Heals one ally from Petrification 
				Exit	  --	 --		Other	Party	 8000	Takes you out of the Dungeon, Cave or such.
				-------------------------------------------------------------------------------------------------
	Level 7:
				-------------------------------------------------------------------------------------------------
				Curaja    --	 --		Healing	S.Ally	25000	Restores all the HP of a single ally.
				Healaga	  48	 --		Healing	Party	30000	Restores a large amount of HP to the party. 
				Diaja 	  80	 --		Other   All En. 20000	Causes very heavy damage to Undead, and Undead only. 
				NulEarth  --	 --		Status	Party   25000	Lowers Earth damage, protects from Death and Petrif. 				
				-------------------------------------------------------------------------------------------------
	Level 8:	
				-------------------------------------------------------------------------------------------------
				Holy	  40	 --		Neutral All En. 40000	Hits all foes for large damage. 
				Nul-All	  --	 --		Status	S.Ally	35000	Protects against all Status and Elements, except Slow.
	Change		Dispel	  --	 --		Status	S.Enem. 30000	Removes resistances and benefitial effects from target. 
				Full-Life --	 --		Healing	S.Ally	35000	Revives an ally with full HP. 
				-------------------------------------------------------------------------------------------------
 
-----------------------------------------------------------------------------------------------------------------
				Black Magic:			
-----------------------------------------------------------------------------------------------------------------
	Level 1:	Name	Power	Acc		Elem.	Target	Price	
				-------------------------------------------------------------------------------------------------
				Fire	  12	 --		Fire	S.Enem.	   50	Basic Fire spell. 
				Thunder   12 	 --		Thunder	S.Enem.	   50	Basic Lighting spell.
				Focus	  --	 64		---		S.Enem.	   50	Lowers a Foe's evasion by 20. 
				Sleep	  --	 36		Status	All En.	   50	Tries to put all foes to sleep. 
				-------------------------------------------------------------------------------------------------
	Level 2:	Name	Power	Acc		Elem.	Target	Price	
				-------------------------------------------------------------------------------------------------
				Blizzard  17	 --		Ice		S.Enem.   250	Basic Ice Spell. 
				Dark	  --	 36		Status	All En.	  200	Tries to Blind all enemies, so they miss attacks. 
				Slow	  --	 48		Status	All En.   400	Lowers foes' Hit Rate, hitting less times. 
				Temper	  --	 --		Buff	S.Ally	  800	Raises one ally's Attack & Accuracy by 10. 
				-------------------------------------------------------------------------------------------------
	Level 3:
				-------------------------------------------------------------------------------------------------
				Fira	  25 	 --		Fire	All En.	 1500	Medium Fire spell, hits all enemies. 
				Thundara  25	 --		Thunder All En.  1500	Medium Lightning spell, hits all enemies. 
				Focara	  --	 64		---		All En.   800	Lowers all Foes' Evasion by 30. 
				Hold	  --	 75		Status  S.Enem.	 1500	Tries to Paralyze one Foe, preventing any action.
				-------------------------------------------------------------------------------------------------
	Level 4:	
				-------------------------------------------------------------------------------------------------
				Blizzara  25	 --		Ice		All En.	 2500	Medium Ice spell, hits all enemies. 
				Confuse	  --	 64		Status  All En.  1800	Tries to confuse all foes into hitting themselves. 
				Sleepra	  --	 80		Status	S.  En.	 2500	Puts a single foe to sleep with high chances. 
				Haste	  --	 --		Buff	S.Ally	30000	Raises the number of physical hits by 2. 
				-------------------------------------------------------------------------------------------------
	Level 5:	
				-------------------------------------------------------------------------------------------------
				Firaga	  35	 --		Fire	All En.	 8000	Highest Fire spell, hits all enemies. 
				Scourge   38	 --		Status  All En.	30000	Deals Poison damage to all enemies. 
				Slowra	  --	 70		Status	S.Enem.  5000	Lowers one foe's number of attacks to one.  
				Teleport  --	 --		Other	Party	 3500	Takes you to the previous floor. Only out of battle.
				-------------------------------------------------------------------------------------------------
	Level 6:
				-------------------------------------------------------------------------------------------------
				Thundaga  35	 --		Thunder All En.	15000	Highest Lightning spell, hits all enemies. 
				Harm	  45     --		Mind	S.Enem.	25000	Hits a single foe for great damage.
				Quake	  38	 --		Quake	All En. 30000	Causes Earth damage to all enemies. 
				Death     --	 36		Death	S.Enem.	 8000	Tries to kill a single foe outright. Lower Accuracy. 
				-------------------------------------------------------------------------------------------------
	Level 7:
				-------------------------------------------------------------------------------------------------
				Blizzaga  35	 --		Ice		All En.	25000	Highest Ice spell, hits all enemies.
				Break	  --	 70		Status	S.Enem.	20000	Petrifies a single foe. High chances.
				Saber 	  --	 --		Status  S. Ally 30000	Raises an Ally's Attack by 20.
				Swift	  --	 --		Status	Party   15000	Protects the team against Slow. 				
				-------------------------------------------------------------------------------------------------
	Level 8:	
				-------------------------------------------------------------------------------------------------
				Flare	  55	 --		Neutral	All En. 50000	Hits all foes for massive damage. 
				Stop	  --	 60		Status	All En.	35000	Paralyzes all foes with good chances of working. 
				Kill	  --	 75		Death	S.Enem. 40000	Outright kills an enemy. Has high chances to work.
				Warp	  --	 36		Death 	All En.	35000	Tries to make all enemies disappear, basically killing them. 
				-------------------------------------------------------------------------------------------------
 
-------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------
 

			o------------------------------o
			|06 - Information about Weapons| 
			o------------------------------o 

 This Dawn of Souls version of FF1 was the first to add a bunch of content to the original game,
 with a large amount of new weapons being part of it. The original game wasn't short of them, 
 either, specially compared to games such as the original Dragon Quest.  
 
 In the original game, there wasn't too much in the way of balancing the different types of weapons, 
 and between that and the "Weapon Critical Hit Glitch" it was mostly simply about equipping whatever 
 last weapon you got as it would have the highest numbers, and that's it. 

 So I tried to make each weapon type have something to stand out, to keep all useful. A small comment 
 for each type will be above each weapon type list. 
 
 Here's a small legend about each stat:
 
			Pow: Weapon's Attack value, 		    Acc: Weapon's Accuracy value. Besides the obvious, it also 
			     combined with Strength/2. 			     raises the amount of Hits a character does each 32 Acc. 
													     This value is added to the characters' own Accuracy.
				 
			Cri: Critical Hit Ratio of the Weapon.	Spell: Which Spell it casts when used as an Item
				 The higher it is, the more common	       in battle. It doesn't waste the Weapon. 
				 it lands critical hits. 
			
		  Elem.: With which Element the Weapon		Extra: To which type of enemy will cause extra damage.
				 strikes. FF1 can't do weapons			   It can be effective to more than one type. 
				 with Status Effects. 
			
			St Ag:  Bonuses to a Character's Main 	Eva: Evasion Bonus given by the Weapon. 
			Vi In   Stats. Some times it can lower
					a Stat instead of raising it!   MHP: Maximum Hit Points bonus, given in percentages. 
			
			Where can be found: Well, exactly what it says. Now, it doesn't mean it's the ONLY 
								place where it can be found, some can be obtained in more ways.
			
		Usability: Which Classes can use it.  

			This are the differen types that can receive Extra damage: 
				Regen:		Regenerative foes, they heal up a bit after each round. 
				Magical:	Spellcasters or creatures with magical abilities. 
				Aquatic:	Creatures that live on the sea, rivers and such. 
				Beasts:		Both werebeasts and beast-like creatures, like wolves or tigers. 
				Undead:		Zombies and the like. 
				Giants: 	Humanoids like Goblins, larger ones like Gigas, and bigger creatures like Ankhegs. 
				Dragon:		Includes both the aforementioned Dragons but also reptile creatures. 
				Evil:		Enemies such as Gargoyles, dark-themed Knights and the Elementals.
			
			Note: Wizard's Staff Fira is weaker than the real Spell you learn. It has 12 Power compared to 25.
				  It's a tad too strong otherwise, having in mind you can spam it infinitely...
				  Thor's Hammer's Thunder is stronger than the real Spell. It has 25 Power instead of 12. 
				  By the point you get it Level 1 Spells are pretty outdated, so it doesn't break anything.
				
---------------------------------------------------------------------------------------------------------------------------------------------
Daggers: Nimble weapons. They offer less Power than other types but really high Accuracy, granting
		 higher potential for extra Hits than any other Weapon, plus a bonus to Evasion. 
---------------------------------------------------------------------------------------------------------------------------------------------
Name			Pow	Acc Cri		Spell	Elem.	Extra	St Ag Vi In Eva MHP	Usability 								Where can be found
---------------------------------------------------------------------------------------------------------------------------------------------
Knife			  5  10   2		---		---		---		-- -- -- -- + 2 ---	WA|KN TH|NI   |   RM|RW   |   BM|BW		Cornelia Shop
Dagger			  9  20  15		---		---		---     -- +2 -- -- + 3 ---	WA|KN TH|NI   |   RM|RW   |   BM|BW 	Pravoka  Shop 
Mythril Knife	 14  24  20		---		Poison	---		-- +3 -- -- + 5	---	WA|KN TH|NI   |   RM|RW   |   BM|BW 	Elfheim  Shop, Marsh Cave
Mage Masher		 22  30  25		Silence	---		Magical -- -- -- +3 + 7 ---	WA|KN TH|NI   |   RM|RW   |   BM|BW 	Mount    Gulg, Whisp. Cove 
Cat Claws		 30  40  35		---		---		Wereb.	-- +4 -- -- + 7 ---	WA|KN TH|NI   |   RM|RW   |   BM|BW 	Gaia     Shop
Gladius			 34  50  25		Protect	Mind	Aquatic -- -- -- -- + 8 ---	WA|KN TH|NI   |   RM|RW   |   BM|BW 	Kraken   Boss, Whisp. Cove 
Orichalcum		 38  55  30		---		Drain	---		-- -- -- -- +10 ---	  |KN   |NI   |     |RW   |     |BW 	Flying  Fortress 
Assassin Dagger	 40  60  35		Death	---		Evil	-- +4 -- +4 +11 ---	  |     |NI   |     |RW   |     |BW		Cagnazzo      
---------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------
Staves: The favourite of the spellcaster. As Weapons, they offer the lowest Power, yet they have 
		pretty okay Accuracy and Critical Hit ratio, all things considered. Yet their real 
		asset is increasing Intelligence, and can be used to cast some useful Spells too.  
---------------------------------------------------------------------------------------------------------------------------------------------
Name			Pow	Acc Cri		Spell	Elem.	Extra	St Ag Vi In Eva MHP	Usability 								Where can be found 
---------------------------------------------------------------------------------------------------------------------------------------------
Staff			  4  10   6		---		---		---		-- -- -- +2 --- ---	WA|KN TH|NI MO|MA RM|RW WM|WW BM|BW		Cornelia Shop
Power Staff		 10  18  25		---		---		Regen	-- -- -- +4 --- ---	  |   TH|NI MO|MA RM|RW WM|WW BM|BW		Western Keep (Key) Piscodemon 
Mage's Staff	 15  20  20 	Confuse	Poison	---		-- -- -- +6 + 5 ---	  |     |     |   RM|RW   |   BM|BW		Melmond Shop       
Healing Staff	 20  15  35 	Heal	---		---		-- -- -- +8 --- ---	  |     |     |     |   WM|WW   |  		Citadel of Trials 
Wizard's Staff	 22  30  33 	Fira	---		---		-- -- -- +8 + 5 ---	  |     |     |     |     |   BM|BW		Sunken Shrine
Sage's Staff	 30  30  20		Life	Quake	Holy +	-- -- -- +6 --- + 7	  |     |     |   RM|RW WM|WW BM|BW		Flying Fortress
Rune Staff		 25  26  20    NulTerra Mind	---		-- -- - +10 +12 ---   |     |     |     |   WM|WW   |  		Orthros
Judgement Staff	 25  26  20 	Kill	Mind 	---		-- -- - +10 +12 ---   |     |     |     |     |   BM|BW		Atomos 
---------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------
Swords: Standard Swords are the most balanced Weapon type, and also the most numerous. 
		Certain Swords might stand out in a particular area, like the Bravehear having 
		great Accuracy, at the cost of lower Crit. Hit ratio, or the Enhancer raising Int. 
---------------------------------------------------------------------------------------------------------------------------------------------
Name			Pow	Acc Cri		Spell	Elem.	Extra	St Ag Vi In Eva MHP	Usability 							Where can be found
---------------------------------------------------------------------------------------------------------------------------------------------
Rapier			  8   8   5		---		---		---		-- -- -- -- --- ---	WA|KN TH|NI   |   RM|RW   |     |  	Cornelia Shop
Saber			 13  10  20		---		---		---		-- -- -- -- --- ---	WA|KN TH|NI   |   RM|RW   |     |  	Pravoka  Shop
Longsword		 14  32  15		---		---		---		-- +3 -- -- --- ---	WA|KN   |NI   |   RM|RW   |     |  	Elfheim Shop
Werebuster		 22  15  18		---		---		Wereb.	-- +2 -- -- --- ---	WA|KN TH|NI   |   RM|RW   |     |  	Chaos Shrine (Key)
Rune Blade		 22  15  18		---		---	 Magic,Evil -- -- -- +2 --- ---	WA|KN TH|NI   |   RM|RW   |     |  	Chaos Shrine (Key)
Wyrmkiller		 22  15  18		---		---		Dragons	-- -- +2 -- --- ---	WA|KN TH|NI   |   RM|RW   |     |   Mt. Duergar  (Key)
Ice Brand		 23  20  15		Ice		---		---		-- -- +2 +3 --- ---	WA|KN   |NI   |   RM|RW   |     |  	Mt. Gulg
Mythril Sword	 24  15  25		---		Poison	---		-- -- -- -- --- ---	WA|KN TH|NI   |   RM|RW   |     |   Melmond  Shop, Cres. Lake Shop 
Flame Sword		 27  15  20		Fire	---		Undead	+3 -- -- -- --- ---	WA|KN   |NI   |   RM|RW   |     |  	Cavern of Ice 
Coral Sword		 27  20  25		---		---		Aquatic	-- -- -- -- + 5 --- WA|KN TH|NI   |   RM|RW   |     |  	Citadel of Trials
Razer			 28  22  20		Death 	---		---		-- -- -- -- --- ---   |KN   |NI   |     |RW   |     |  	White Shark 
Vorpal Sword	 35  32  40		---		---		---		-- -- -- -- +10 ---   |KN   |NI   |     |RW   |     |   Mirage Tower
Enhancer		 38  28  20		---		---		---		-- -- -- +8 +10 ---	WA|KN   |NI   |   RM|RW   |     |  	Flying Fortress, Blue Dragon
Braveheart		 38  45  15 	Rest	---		Evil	-- -- +3 -- + 5 ---	WA|KN   |NI   |     |RW   |WW   |  	Tiamat,          Yamato Orochi
Duel Rapier		 40  45  10		----	---		---		-- -- -- +3 +60 ---	WA|KN TH|NI   |   RM|RW   |     |  	Death Knight,    Pharaoh 
Sun Sword		 44  26  25		---		---		Undead  -- -- -- +3 --- + 7	WA|KN   |NI   |   RM|RW   |     |  	Mirage Tower 
Deathbringer	 48  26  35		Death	---		Regen	+4 +4 +4 +4 -14 ---	  |     |     |     |RW   |     |  	Chaos Temple  
Excalibur		 50  30  25		---	Evil,Undead,Dragon	-- -- +4 +4 --- + 5	  |KN   |     |     |     |     |   Smith Quest (after Flying Fortress) 
Lightbringer	 55	 30	 20		Curaga	  Evil, Undead	-- -- +5 +5 +10 ---	  |     |     |     |RW   |     |  	Typhon
---------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------
Heavy Swords: These powerhouses possess really high Power, good Critical Hit ratio, and even 
			  raise the wielder's HP! But such extreme pros also carry some cons, like very 
			  low Accuracy, meaning less Hits, and a penalty to Evasion. 
---------------------------------------------------------------------------------------------------------------------------------------------
Name			Pow	Acc Cri		Spell	Elem.	Extra	St Ag Vi In Eva MHP	Usability 							Where can be found 
---------------------------------------------------------------------------------------------------------------------------------------------
Broadsword		 22   6  13		---		---		Giants	-- -- -- -- -10 +10	WA|KN   |NI   |   RM|RW   |     |  	Pravoka  Shop, Marsh Cave 
Great Sword		 37   8  25		---		---		---		-- -- -- -- -10 +10	WA|KN   |NI   |     |RW   |     |  	Mt. Gulg 
Defender		 47  15  30		---		---		Giants	-- -- -- -- + 5 +10	  |KN   |     |     |RW   |     |  	Waterfall Cave 
Dark Claymore	 55  15  40		Death	---		Dragon	-- -- -- -- +10 + 5	WA|KN   |     |     |     |     |  	Barbariccia  
Ragnarok		 65	 18	 20		Break	---		---		+3 +3 +3 +3 -13 + 5	  |KN   |     |     |     |     |  	Shinryu
Ultima Weapon	100  15  20		---		---		---		-- -- -- -- --- --- WA|KN TH|NI MO|MA RM|RW WM|WW BM|BW	Death Gaze 
				^Damage depends on the wielder's HP/10, tops at 100 with 999 HP. 
				 So, on a character with 650HP, its power would be 65, for example. 
---------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------
Axes: Very similar to Heavy Swords, trading a bit of Power for higher Critical Hit ratio. 
	  Unlike those, though, there's a couple of accurate, lighter Axes, and late ones offer 
	  a greater HP bonus, at the expense of a bigger penalty to Evasion. 
---------------------------------------------------------------------------------------------------------------------------------------------
Name			Pow	Acc Cri		Spell	Elem.	Extra	St Ag Vi In Eva MHP	Usability 							Where can be found
---------------------------------------------------------------------------------------------------------------------------------------------
Battle Axe	 	 18   4  24		---		---		---		-- -- -- -- -10 +10	WA|KN   |     |   RM|RW   |     |  	Pravoka Shop
Great Axe		 26   6  28		---		---		Giants	-- -- -- -- -10 +10	WA|KN   |     |     |     |     |  	Elfheim Shop
Mythril Axe		 33   8  40		---		---		---		-- -- -- -- -10 +10	WA|KN   |     |     |     |     |  	Mount   Gulg,   Crescent Lake 
Light Axe		 36  24  20		---		Lightn.	---		-- -- -- -- - 5 + 5	WA|KN   |NI   |     |     |     |  	Sunken  Shrine
Rune Axe		 43  28   5		Focara  Mind	Magical -- -- -- +6 -10 + 5	WA|KN   |     |     |RW   |     |BW	Gaia    Shop 
Gigant Axe		 50  15  45		---		---		Dragons	-- -- +4 -- -10 +10	WA|KN   |     |     |     |     |  	Mirage  Tower 
Viking Axe		 55  15  40				Wereb.	Aquatic	-- -- -- -- -15 +13	WA|KN	|     |	    |     |     |  	Chaos   Temple, Whisper. Cove 
Ogrekiller		 65  18  20		---		---		Giants  -- -- -- -- -15 +15	  |KN   |     |     |     |     |  	Omega
---------------------------------------------------------------------------------------------------------------------------------------------
Long Swords: Also named Katanas, this Weapon type is mostly used by Thieves and Red 
			 Mages. They offer generally less Power than Standard Swords, but their 
			 Accuracy and Critical Hit ratio tends to be higher, giving them higher 
			 potential... If you are lucky, of course. 
---------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------
Name			Pow	Acc Cri		Spell	Elem.	Extra	St Ag Vi In Eva MHP	Usability 							Where can be found
---------------------------------------------------------------------------------------------------------------------------------------------
Scimitar		 10  16   8		---		---		---		-- -- -- -- --- ---	WA|KN TH|NI   |   RM|RW   |     | 	Pravoka Shop 
Falchion         20  10  40		---		---		Aquatic	-- -- -- -- + 5	---	WA|KN TH|NI   |   RM|RW   |     |  	Melmond Shop 
Kotetsu			 28  32  15		---		Mind	Magical	-- -- -- -- +10 ---	  |   TH|NI   |   RM|RW   |     |   Marilith
Ashura			 34  35  35		---		Poison	Regen.	-- -- -- +6 --- ---	  |   TH|NI   |   RM|RW   |     |   Cerberus
Murasame		 40  45  25		Blink	---		---		-- -- -- -- +15 ---	  |     |NI   |     |     |     |BW Scarmiglione
Sasuke's Katana  44  50  30		---		---		Werewb.	-- +2 +2 +2 --- ---	  |     |NI   |     |RW   |     |  	Flying Fortress
Masamune         48  32  55		---		---		---		-- -- -- -- --- ---	WA|KN TH|NI MO|MA RM|RW WM|WW BM|BW	Chaos Temple
Kikuichimonji	 53  45  30		---		---		All		-- -- -- -- +10 ---	  |   TH|NI   |     |     |     |  	Gilgamesh 
---------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------
Hammers: A small group for sure, but they're the favourite of the White Mage when 
		 it wants to bash some baddies. They hold pretty great power for something 
		 that a spellcaster would wield, and raise HP slightly, but also lower Evasion. 
---------------------------------------------------------------------------------------------------------------------------------------------
Name			Pow	Acc Cri		Spell	Elem.	Extra	St Ag Vi In Eva MHP	Usability 							Where can be found
---------------------------------------------------------------------------------------------------------------------------------------------
Hammer		 	 12	  4  12		---		--- 	---		-- -- -- -- --- ---	WA|KN   |NI MO|MA   |   WM|WW   |  	Cornelia Shop	
Mythril Hammer	 22  10  15		---		Mind	--- 	-- -- -- -- - 5 + 5	WA|KN   |NI MO|MA   |   WM|WW   |  	Crescent Lake  Shop
Thor's Hammer	 35  16  35	 Thunder Lightning	Aquatic	-- -- -- -- - 5 + 5	WA|KN   |   MO|MA   |   WM|WW   |  	Citadel of Trials 
War Hammer	 	 48  24  30		---		--- 	Undead	-- -- -- +3 - 8 + 5	  |KN         |MA   |     |WW   | 	Mirage  Tower
---------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------
Martial Arts Weapons: Exclusive to the Monk/Master, these will undoubtly be useful 
					  when starting out, while its fists get stronger. 
---------------------------------------------------------------------------------------------------------------------------------------------
Name			Pow	Acc Cri		Spell	Elem.	Extra	St Ag Vi In Eva MHP	Usability 							Where can be found
---------------------------------------------------------------------------------------------------------------------------------------------
Nunchaku		 16  10  10		---		---		---		-- -- -- -- --- ---	  |     |   MO|MA   |     |     |  	Pravoka Shop	
Iron Nunchaku	 24  14  20		---		---		---		-- -- -- -- + 5 ---	  |     |   MO|MA   |     |     |  	Melmond Shop 
Crosier			 33  25  20		---		---		Evil	-- +3 -- -- --- ---	  |     |   MO|MA	|     |     |  	Crescent Lake Shop
---------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------

		o----------------------------o
		|07 - Information about Armor|
		o----------------------------o

 In a way, Defensive Gear has been tweaked a lot more than Weapons, as I made it a bit more open in certain ways
 and also more fair. It never made sense to me that the sturdiest armors also were barely heavier than mage 
 equipment while those giving far less, only for the helms and gloves for Knight or Ninja give a large bonus 
 to Evasion. It felt too one-sided, which mind you, it's something old school RPGs did too often...

 In any case, I divided Armor in three categories, depending on their Defense VS Evasion ratios, usability
 and such. Headgear is separated into lighter ones, like hats, and heavier helms. Hand equipment has suffered 
 the biggest change, and I made something akin to my FF3 hack, changing it from "temporal upgrades" like they 
 often were and into more "swappable" Items you can equip depending on the situation. 
 
 For example, the Runic, Might and Agile Gloves. Each one offers a bonus to Intelligence, Strength or Agility, 
 and basic Defense value, and they help you getting a higher Magic Damage multiplier, a higher Hit Multiplier, 
 or raising your Attack. You also have the Protect Ring which grants higher Defense but no Stat upgrades, 
 or the Giant Gloves which raise HP but less Defense and are a bit heavier. 
 
 In any case, here's the legend: 

				Def: Pretty selfexplanatory, how much 	Wei: The Weight of the gear. It is substracted from your 
					 Physical Defense it offers. 			 Evasion, after substracting the gears' own Evasion. 
					 
			  Spell: Which Spell it casts when used 	Eva: The Evasion that the gear grants. Evasion and Weight
					 as an Item. it doesn't waste it.		 from gear conflict with eachother, so if we had an 
															 armor with a weight of 5, but also offers a gain
			  Resis: Which Status or Elements it gives		 in Evasion of 7, it will give +2 Evasion. Flip the 
					 protection from. 						 numbers, and it will give -2 Evasion. Agility given 
															 by gear grants Evasion too, 1 Agi. point is 1 Eva.
															 
			St Ag:  Bonuses to a Character's Main 		     But for the most part if there's Weight there's no
			Vi In   Stats. Some times it can lower           Evasion, and viceversa, only some gear has both.
					a Stat instead of raising it!  		MHP: Maximum Hit Points bonus, given in percentages. 
	
			Where can be found: Well, exactly what it says. Now, it doesn't mean it's the ONLY 
								place where it can be found, some can be obtained in more ways.
								
			Note: Gauntlet's Blizzara is weaker than the real Spell you learn.
				  Its Power is 12, instead of 25.

-----------------------------------------------------------------------------------------------------------------------------------------
Heavy Armor 	Def	Wei Eva		Spell	Resistances		St Ag Vi In MHP	Usability 								Where can be found
-----------------------------------------------------------------------------------------------------------------------------------------
Leather Armor	  4	  3   0		---		---				-- -- -- -- ---	WA|KN TH|NI MO|MA RM|RW WM|WW BM|BW		Cornelia Shop
Chain   Mail	  8	  8	  0		---		---				-- -- -- -- ---	WA|KN TH|NI   |   RM|RW   |     |BW		Cornelia Shop 
Iron    Armor	 12	 12	  0		---		---				-- -- -- -- ---	WA|KN   |NI   |   RM|RW   |     |  		Pravoka  Shop
Mythril Mail	 12	 10	  0		---		---				-- +2 -- -- ---	WA|KN TH|NI   |   RM|RW   |     |  		Crescent Lake 
Flame   Mail	 20	 12	  0		---		Ice 			-- -- -- -- ---	WA|KN TH|NI   |   RM|RW   |     |  		Cavern of Ice  
Ice     Armor	 20  12   0		---		Fire 			-- -- -- -- ---	WA|KN TH|NI   |   RM|RW   |     |   	Mount    Gulg
Dragon  Mail	 25	 20	  0		---		Fire/Ice/Light.	-- -- -- -- ---	  |KN   |NI   |     |RW   |     |  		Mirage   Towe
Genji   Armor	 28  15   0		--- 	Stone/Deth/Posn	+2 +2 +2 +2 --- WA|KN   |NI   |     |RW   |     |  		Flying   Fortress
Diamond Armor	 30  18   0		---		Lightning		-- -- -- -- ---	WA|KN   |     |     |RW   |     |  		Sunken   Shrine 
Knight  Armor	 30  25	  0		---		---				+2 -- +2 -- + 8	WA|KN   |NI   |     |     |     |  		Melmond  Shop
Crystal Mail	 45  30   0		---		Stone/Blnd/Conf	-- -- -- +3 ---	  |KN   |     |     |     |     |  		Gaia     Shop
-----------------------------------------------------------------------------------------------------------------------------------------
Medium Armor 	Def	Wei Eva		Spell	Resistances		St Ag Vi In MHP	Usability 								Where can be found
-----------------------------------------------------------------------------------------------------------------------------------------
Copper Armlet	  6	  3	  0 	---		---				-- -- -- -- ---	WA|KN TH|NI MO|MA RM|RW WM|WW BM|BW		Elfheim   Shop
Silver Armlet	 10	  6	  0		---		---				-- -- -- -- +10	WA|KN TH|NI MO|MA RM|RW WM|WW BM|BW		Melmond   Shop
Element Arml.	 10  15   0		---		Fire/Ice/Light.	+2 +2 +2 +2 ---	WA|KN TH|NI MO|MA RM|RW WM|WW BM|BW		Waterfall Cave, Clay Golem 
Kenpo  Gi		 16   5  13		---		Stun			-- +3 +3 -- ---   |     |   MO|MA   |     |     |  		Crescent  Lake Shop
Blak   Garb		 20   0  25		---		Blind			+2 +5 -- +2 ---	  |   TH|NI   |MA   |     |     |  		Waterfall Cave 
Red    Jacket	 22  18   0		---		Fire			+3 +3 +3 +3 + 5	  |   TH|NI   |   RM|RW   |     |  		Black     Dragon 
Thief  Armlet	 23   5  15 	---		Sleep			-- +5 -- -- ---	  |   TH|NI   |     |     |     |  		Sunken    Shrine 
Power  Vest		 23  10   8		---		Death			-- +3 -- +3 + 5	  |     |   MO|MA   |     |     |  		Mirage    Tower 
Ruby   Armlet	 24  12	  0		---		Stun/Slp/Stone	-- -- -- -- +10	WA|KN TH|NI MO|MA RM|RW WM|WW BM|BW		Gaia      Shop
-----------------------------------------------------------------------------------------------------------------------------------------
Light Armor 	Def	Wei Eva		Spell	Resistances		St Ag Vi In MHP	Usability 								Where can be found
-----------------------------------------------------------------------------------------------------------------------------------------
Clothes			  1	  0	  3		---		---				-- -- -- -- ---	WA|KN TH|NI MO|MA RM|RW WM|WW BM|BW 	Worn at the beginning 
Bard's Tunic	  8   3   8 	---		Silence			-- +3 -- -- ---	  |   TH|NI MO|MA RM|RW WM|WW BM|BW		Melmond Shop 
Sage  Surplice	 12   3   8		---		Ice/Stun		-- -- -- +3 ---	  |     |     |   RM|RW WM|WW BM|BW		Mount  Gulg,  Cres. Lake
Light Robe		 16   6  10		---		Lightning/Blind	-- -- -- -- + 5	  |     |   MO|MA   |   WM|WW BM|BW		Citadel of Trials
Gaia  Gear		 20  10   0		---		Quake/Stone		-- -- -- -- +10	  |     |   MO|MA   |   WM|WW BM|BW		Two-Headed Dragon 
White Robe		 22	 10	  0	   Invisira	Stone/Death		-- -- -- +4 ---	  |     |     |     |   WM|WW BM|BW		Flying Fortress 
Black Robe		 22	 10	  0		Scourge	Stone/Poison	-- -- -- +4 ---	  |     |     |     |   WM|WW BM|BW		Flying Fortress 
-----------------------------------------------------------------------------------------------------------------------------------------
Shields		 	Def	Wei Eva		Spell	Resistances		St Ag Vi In MHP	Usability 								Where can be found
-----------------------------------------------------------------------------------------------------------------------------------------
Leather Shield	  3   3   0		---		---				-- -- -- -- ---	WA|KN TH|NI MO|MA RM|RW   |     |  		Pravoka  Shop
Iron    Shield	  7   5   0		---		---				-- -- -- -- ---	WA|KN   |     |   RM|RW   |     |   	Elfheim  Shop
Mythril Shield	  6   8   0		---		Poison			-- -- -- -- ---	WA|KN   |     |   RM|RW   |     |   	Crescent Lake 
Flame   Shield	  6	  8	  0		---		Ice				-- -- -- -- ---	WA|KN   |NI   |     |RW   |     |   	Mount    Gulg 
Ice     Shield	  6   8   0		---		Fire 			-- -- -- -- ---	WA|KN   |NI   |     |RW   |     |   	Cavern of Ice 
Diamond Shield	  6   8   0		---		Lightning 		-- -- -- -- ---	WA|KN   |NI   |     |RW   |     |   	Gaia     Shop 
Aegis   Shield	  6	  8	  0		---		Earth			-- -- -- -- ---	  |KN   |NI   |     |RW   |     |   	Mirage   Tower, Sunken Shrine
Genji   Shield	  6	  8	  0		---	  	Mind			-- -- -- -- ---	  |KN   |NI   |     |RW   |     |   	Death Manticore
Crystal Shield	 10	 10	  0		---		Stone			+2 -- +2 -- ---	  |KN   |     |     |     |     |   	Killer Shark 
Hero's  Shield	  7	 15	  0		---		All Status		-- -- -- -- + 5   |KN   |NI   |MA   |RW   |WW   |BW		Death Train
-----------------------------------------------------------------------------------------------------------------------------------------
Light Shields 	Def	Wei Eva		Spell	Resistances		St Ag Vi In MHP	Usability 								Where can be found
-----------------------------------------------------------------------------------------------------------------------------------------
Buckler			  4	  3	  0		---		---				-- -- -- -- ---	WA|KN TH|NI MO|MA RM|RW WM|WW BM|BW		Elfheim Shop
Protect Cloak	  3	  0	  5		---		Poison			-- -- -- -- ---	      TH|NI MO|MA RM|RW WM|WW BM|BW		Lich,   Several Chests 
Zephyr  Cape	  3	  0	  5		---		Fire			-- -- -- -- ---	      TH|NI MO|MA RM|RW WM|WW BM|BW		Caravan
Elven   Cloak	  3	  0   5		---		Mind			-- -- -- -- ---       TH|NI MO|MA RM|RW WM|WW BM|BW 	Echidna, Flying Fortress
-----------------------------------------------------------------------------------------------------------------------------------------
Helms		 	Def	Wei Eva		Spell	Resistances		St Ag Vi In MHP	Usability 								Where can be found
-----------------------------------------------------------------------------------------------------------------------------------------
Helm			  3	  2	  0		---		---				-- -- -- -- ---	WA|KN   |NI   |     |     |     |  		Pravoka Shop
Great   Helm	  5	  3   0		---		---				-- -- -- -- ---	WA|KN   |NI   |     |     |     |  		Elfheim Shop
Mythril Helm	  6	  4	  0		---		---				-- -- -- -- ---	WA|KN   |NI   |     |     |     |  		Melmond Shop
Diamond Helm	  8	  6	  0		---		Blind			-- -- -- -- ---	  |KN   |     |     |     |     |  		Gaia    Shop
Healing Helm	  5	  5	  0		Heal	---				-- -- -- +2 ---   |KN   |NI   |     |     |     |  		One cave 
Genji   Helm	  8	  0	  5		---		Slow/Confusion	-- -- -- -- --- WA|KN TH|NI   |     |     |     |		Flying Fortress, Chaos T. 
Crystal Helm 	 12	 10   0		---		Stone 			+3 -- -- -- --- WA|KN TH|NI   |     |     |     |		Flying Fortress
-----------------------------------------------------------------------------------------------------------------------------------------
Hats		 	Def	Wei Eva		Spell	Resistances		St Ag Vi In MHP	Usability 								Where can be found
-----------------------------------------------------------------------------------------------------------------------------------------
Leather Cap		  1	  0	  1		---		---				-- -- -- -- ---	WA|KN TH|NI MO|MA RM|RW WM|WW BM|BW		Pravoka Shop
Ribbon			  2	  0	  8		---		All STATUS		-- -- -- -- ---	WA|KN TH|NI MO|MA RM|RW WM|WW BM|BW		Several places 
Black Cowl		  4	  0	  8		Sleep	---				+2 +2 +2 -- ---	  |   TH|NI								Hellhound 
Twist Headband	  4	  5	  0		---		Confusion		+2 +2 +8 -- ---	WA|KN TH|NI MO|MA RM|RW WM|WW BM|BW		Fire/Ice Gigas,  Purple Worm 
Tiger Mask		  4	  5	  0		---		Confusion		+8 +2 +2 -- ---	WA|KN TH|NI MO|MA RM|RW WM|WW BM|BW 	Rakshasa, Weretiger
Feather Cap		  4	  0	  2		---		Slow/Sleep		-- +3 -- -- ---	  |   TH|NI MO|MA RM|RW WM|WW BM|BW		Melmond Shop		
Wizard Hat		  5	  0	  3		---		Silence			-- -- -- +3 ---	  |     |     |   RM|RW WM|WW BM|BW 	Gaia Shop 
Sage's Mitre	  4  15	  0		---		Fire/Ice/Light. -- -- -- +3 + 5	  |     |     |   RM|RW WM|WW BM|BW		Rubicante 
Red    Cap		  5	 10	  0		---		---				+2 +2 +2 +2 + 5   |     |     |   RM|RW   |     |  		Red Dragon, Tyranosaur
-----------------------------------------------------------------------------------------------------------------------------------------
Hand Gear	 	Def	Wei Eva		Spell	Resistances		St Ag Vi In MHP	Usability 								Where can be found
-----------------------------------------------------------------------------------------------------------------------------------------
Leather Gloves 	  2   1   0		---		---				-- -- -- -- ---	WA|KN TH|NI MO|MA RM|RW WM|WW BM|BW		Cornelia Shop
Might   Gloves    4   6   0		---		---				+4 -- -- -- + 3 WA|KN TH|NI MO|MA RM|RW WM|WW BM|BW		Elven Castle,   Earth Cave 
Agile   Gloves    4   2   0		---		---				-- +3 -- -- ---	WA|KN TH|NI MO|MA RM|RW WM|WW BM|BW		Elven Castle,  Several Chests  
Runic   Gloves    4   2   0		---		---				-- -- -- +3 --- WA|KN TH|NI MO|MA RM|RW WM|WW BM|BW		Astos,         Several Chests 
Crystal Ring	  3   5   0		Slowra	---				-6 -- -- +6 ---   |KN   |NI   |MA   |RW   |WW   |BW		Flying Fortress, Holy Dragon
Swift   Ring 	  5   3   0		Swift	---				-- +8 -- -3 ---   |KN   |NI	  |MA   |RW   |WW   |BW		Waterfall Cave, Sahagin Prince
Giant's Gloves	  6	 11	  0		Protect	---				+8 -4 -- -- + 6	WA|KN   |NI   |MA	|RW   |WW   |BW 	Sunken Shrine,  Flare Gigas 
Gauntlets		  5   8   0	   Blizzara	---				-- -- -- -- +10   |KN   |NI   |     |RW   |     |   	Citadel of Trials 
Power   Gloves    5   0   0		---		---			   +10 +5 -- +5 ---	  |     |     |MA   |     |     |   	Rubicante
Angel   Ring	  5   5   0		Restores HP each round	-- -- -- -- --- WA|KN TH|NI MO|MA RM|RW WM|WW BM|BW		Ahriman,       Flood Gigas 
Genji   Gloves	  7   4   0		---		Slow/Stun		-- -- -- -- ---	  |KN   |NI   |MA   |RW   |WW   |BW		Iron Golem,    Sahagin Queen 
Protect Ring 	  8   6   0		---		Death			-- -- -- -- ---	WA|KN TH|NI MO|MA RM|RW WM|WW BM|BW 	Gaia Shop  
Crystal Gloves 	 12  10   0		---		Stone 			-- -- -- +2 ---   |KN   |NI   |     |     |     |   	Yellow Dragon  
-----------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------
 
			o-------------------------------o
			|08 - Information about Monsters|
			o-------------------------------o
			
 As I said early on this readme, this version the FF1 is based off the Easy Mode 
 of the PS1 release, and while their stats are the exact same as the original NES,
 you level up so fast that Monsters become super easy the further you progress, 
 as your HP raises so high that they can't really do much to you. 
 
 So they've been heavily modified to make their stats scale better in relation 
 with your own power. Abilities, drops, resistances and weaknesses have been
 tweaked too. Many Monsters drop useful things, from consumable Items to equipment. 
 
 Three things I need to address, though:
 
 The original game put a lot of its weight on giving some Monsters huge Defense
 ratings, specially Bosses. I guess they do that in order to limit the power 
 of Physical attacks and keep HP low, so they don't go too out of hand, 
 specially with buffing Spells Temper/Saber and Haste, and what imbalance 
 between Physical attacks and Magic can make. 
 
 My problem with this approach is that makes unbuffed attacks super weak, 
 almost useless, so you're kinda forced to buff yourself, but then Bosses 
 died super quickly and battles became anticlimatic. 
 
 In my hack, I went with much higher HP, and lowered Defense ratings, while 
 also put some limits to buffing. This makes it so unbuffed attacks are now 
 decent, buffing feels good and useful but not broken, and the balance between 
 Physical and Magic damage is better, with Magic being more powerful usually 
 because of its very limited use, but on late areas of the game Physical hits 
 when buffed will rival and sometimes be a bit higher than Magic, depending 
 on the setup of your characters. 
 
 Second, and this one caught me off guard: Magic Resistance on enemies does NOT 
 lower Magic damage received. No, really, it does nothing on that front. 
 It seems it only protects from Status Effects, with the higher value meaning 
 harder to make Status Effects to stick. I mean, it's typical of Old School
 RPGs now that I think about it but... Still, I was surprised. 
 
 Third, I changed around quite a few Monster abilities, and as I mentioned too 
 early in the introduction section, a huge focus of this hack is relying on the 
 Elemental protection spells; and many abilities from Monsters had added or changed 
 their Elements, both to reflect the nature of some abilities that had no Element, 
 and to make protection from said Elements more useful and valuable.
 
 
 Below I put a list of the Monster's damaging skills, so you can recognize them
 and act accordingly. Just remember Monsters can also use Spells and non-damaging 
 Skills that cause Status Effects that aren't listed here. 
 
 Oh, and remember: The damage received depends on the Monster's Intelligence too!
 Their Intelligence bonus works just like yours, every 3 points of Int. 
 Check out the Bestiary to not get nasty surprises. 
 
	--------------------------------------------------------------------------------
	Fire Skills 	Pow	Description
	--------------------------------------------------------------------------------
	Flame			Var	Deals Fire damage to all characters, power varies with user. 
	Inferno			 40	Deals high Fire damage to all characters. 
	Scorch			 60	Deals very high Fire damage to a single foe. 
	--------------------------------------------------------------------------------
	Ice  Skills 	Pow	Description
	--------------------------------------------------------------------------------
	Icestorm		Var	Deals Ice damage to all characters, power varies with user. 
	Tsunami			 40	Deals high Ice damage to all characters.
	Tidal Wave		 50	Deals very high Ice damage to all characters. 
	--------------------------------------------------------------------------------
	Thunder Skills	Var	Description
	--------------------------------------------------------------------------------
	Thunder			 30	Deals Thunder damage to a single character. 
	Thunderbolt 	 40	Deals high Thunder damage to all characters. 
	Cyclone			 40	Deals high Thunder damage to all characters. 
	--------------------------------------------------------------------------------
	Earth   Skill	Pow	Description
	--------------------------------------------------------------------------------
	Earthquake		 40	Deals high Earth damage to all characters. 
	--------------------------------------------------------------------------------
	Poison  Skills	Pow	Description
	--------------------------------------------------------------------------------
	Poison Gas		 40	Deals high Poison damage to all characters. 
	Acid Rain		 50	Deals very high Poison damage to all characters. 
	--------------------------------------------------------------------------------
	Mind Skills 	Pow	Description
	--------------------------------------------------------------------------------
	Gaze of Pain	 35	Deals strong Mind damage to a single character. 
	Mind Blast		 35 Deals strong Mind damage to all characters. 
	Wave Cannon 	 40	Deals high Mind damage to all characters. 
	--------------------------------------------------------------------------------
	Neutral Skills	Pow	Description				   Neutral Damage can't be resisted!
	--------------------------------------------------------------------------------
	Wind Slash		 16	Deals strong Neutral damage to all characters. 
	Nuke			 40	Deals high Neutral damage to all characters. 
	Comet			 45	Deals very high Neutral damage to a single character. 
	--------------------------------------------------------------------------------
 
------------------------------------------------------------------------------------------------- 
------------------------------------------------------------------------------------------------- 

			o---------------------------------------------o
			|09 - Information about other Gameplay changes|
			o---------------------------------------------o
 
 I will point out some mechanic changes in this section.
 
 The main one, of course, is bringing back the Vancian System through Kea's 
 own hack. I did a lot of tweaks to it, because after all, as Kea points out, 
 it needs to be tailored to the hack you're making. 
 
 MP growth, Max MP, MP Restoration and such have been accordingly modified. 
 The rhythm at each Class raises MP is different from the original FF1, and 
 the Warrior, Thief and Monk do get MP gains from the beginning, even if 
 they can't use spells yet. This is so once you change Classes, you can 
 actually use Magic a bit, instead of start getting MP one you change, 
 as it did originally. It felt a bit too little to late for me. 
 
 Boosting Attack and Defense has been capped at 40, instead of the 255 original. 
 
 Accuracy's limit of 255 has been raised. This only really helps the Ninja, which 
 is the only Class than can reach such high natural Accuracy. Mind you, the 
 cap of 255 was only from your character and equipment, you could rise it further
 during battles through Temper for example. 
 
 Intelligence needed to reach a new Magic Damage Multiplier is now 3 instead of 10. 
 This works for both your characters and monsters.
 
 Slow and Slowra are now Slow Element. This might sound dumb to you right now, but 
 let me explain. In the original game, these two Spells are of Neutral Element. If 
 you equipped something that resisted Slow, it would do nothing. 
 
 This is because with how the game is coded, equipment does not protect you from 
 Status Effects, but from Elements. Paralysis is an Element, just like Confusion, 
 Sleep and the rest. But if a Spell is not listed with the correct Element they're 
 "supposed" to be, any protection against it won't work. So I fixed that for all 
 Status Effects, Slow included.  
 
 Haste has been changed so it grants two more Hits instead of doubling them. 
 This is because I made a number of changes in Weapons, Stats and Monster Stats, 
 and it would make the original effect too broken (and I argue it already was). 
 Read more on the Monster Section.
 
 Max. Level has been lowered from 99 to 50. Experience per Level has been increased,
 so gaining Levels will be noticeable slower than in the original DoS, but it won't 
 be as slow as the original FF1, I want to make those 50 Levels useful. 
 
 Chests' contents have been highly modified in order to give appropiate Items for 
 the moment when you find them, and overall give better things. 
 
 Shops also received changes to improve what they sell, remove Ethers (which you 
 will only find scarcely on Chests now) and alter prices. Some Spells have been 
 moved to later Shops. 
 
	o---------------------------------------o 
	|10 - Average Level Progression and Tips|	
	o---------------------------------------o
 
 Because I know delving into a modded RPG can leave a feeling of being lost, 
 here I wrote up what Levels I was through my several test playthroughs.
 
 There was no moment where I grinded for EXP or Gil, only battles fought as I 
 progressed. Also, this was avoiding all the random HP Bonuses, just to ensure
 even with the worst luck you can beat the game. 

 But remember this is just my experience, if you want to be higher, do so.
 Lower though... Probably tough! It also depends on your team, of course.

 Boss				Levels	Commentary 
-----------------------------------------------------------------------------------------------
 Garland			  4		Experience ramps up and levelling slows down.
							Level 4 is enough, though.
-----------------------------------------------------------------------------------------------
 Pirates			 5~6	Make good use of Sleep and damaging Magic and you should be okay. 
							If not I suppose you could Level up to 7, but I'd rather fight'em
							and then train a bit once you can battle sea enemies on the ship.
-----------------------------------------------------------------------------------------------						
 Piscodemons		  11	You travel the Sea, the area surrounding Elfheim and the Marsh 
							Cave, so you'll Level up. Don't get too cocky with these guys! 
-----------------------------------------------------------------------------------------------
 Astos				  12 	As long as you use well the Elemental protection Spells, this 
							level should be more than enough. But that recommendation goes
							for ALL bosses, though. 
-----------------------------------------------------------------------------------------------
 Lich				17~19 	Depends on how many battles you're forced to go through the Cave.
							I'm nice so I put an Emergency Exit on your first trip to Floor 3,
							so you can go back to the surface after getting the Star Ruby. 
-----------------------------------------------------------------------------------------------
 Marilith			21~22 	Level 21 was enough for me, 22 if you feel less daring, your team 
							will get a nice HP increase. I did not go for the Airship first. 
-----------------------------------------------------------------------------------------------
 Cl. Change			24~25  	I haven't tried to do it early, monsters are quite hard both getting
							to the Citadel and inside. There's no point in rushing here, though.
-----------------------------------------------------------------------------------------------
 Earthg. Shrine		25~27	Level 25 should be just enough to defeat Cerberus or Echidna. 
							For the other two, around Level 27~28 would suffice, depending
							on team, spells and play style. I've even defeated them without 
							changing Classes in one playthrough. NO Healaga, by the way.
-----------------------------------------------------------------------------------------------
 Kraken				  30	I did just fine most times I battled him with this Level. At this
							point your HP is okay and you have Spells to deal with him.
-----------------------------------------------------------------------------------------------
 Hellf. Chasm 		30~33	I went right after visiting the Waterfall Cave. The four fiends
							are a fair bit harder than the Earthgift Shrine bosses. With proper 
							preparations you can beat them at Level 30, but of course, depends 
							on your team, and how nasty they decide to be using their abilities.
							Mind you, I battled them WITHOUT Healaga or any L8 Spells, those
							will surely do things easier, but I don't like to "power play". 
-----------------------------------------------------------------------------------------------							
 Tiamat 			 38		Quite a few fights going through both dungeons, so my level went up 
							more than I expected. It was for the best, Tiamat hits hard.  
-----------------------------------------------------------------------------------------------
 Lifesp. Grotto		 38		Right after beating Tiamat. It has quite a few floors where you do 
							not have to fight anything, at this point it felt kinda refreshing.
							Bring protection for Poison and Mind, they're REALLY useful here. 
-----------------------------------------------------------------------------------------------
 Whisper. Cove		 40		After the Grotto, right before going to Chaos Temple. The bosses 
							are fine at this level, but again, I like a bit of risk and challenge.
-----------------------------------------------------------------------------------------------					
 4 Fiends Again  	 41		Difficulty with these is a bit hard to say. Lich gave me a lot of 
							trouble, but they're not as hard as some of the Soul Dungeon bosses. 
-----------------------------------------------------------------------------------------------					
 Chaos				 42		With his constant barrage of spells and abilities, I'd kinda recommend 
							you to Level up to 45. I managed to do it at 42, but I was constantly 
							scrambling... Which made it more fun and exciting, but that's just me!
-----------------------------------------------------------------------------------------------						

 I will list some tips and advices here. I'm sure you know how to play FF1 well already, but 
 for completion's sake, I'll add them.
 
 * With the increased difficulty and limited Max. Level, creating a balanced party 
   is more necessary than in standard FF1 DoS. With only six choices, and most people 
   not repeating Classes, it's not hard to make up a well rounded party, fortunately. 
   
   White Magic is probably the most necessary tool all around, with healing Spells and 
   Nul-Spells being the most vital. Good Black Magic can cut a lot of the damage received 
   by the party on long trecks through dungeons and the overworld by inflicting Status or 
   simply taking out groups of foes. And Physical attacks, unlike Magic, are an infinite 
   resource or damage. 
   
   But just because Magic is a powerful ally, doesn't mean you need to support too heavily 
   on it. Learning Spells is expensive, and the more Magic-adept members a team has, the 
   more Gil will be invested in learning Magic, which will limit money for other things. 
   
   Equally, a party that goes all on with melee hitters will also pay for it, as it will 
   drown out battles longer, receiving more damage and having to make a bigger use of 
   healing Spells and Items, which will shorten your ability to explore before resting. 
   
 * Make a habit to review your characters' equipment every few levels or so. More specifically, 
   check if you can optimize the Accuracy and Attack power of your melee fighters. Every 
   32 Accuracy you get an extra Hit, but when you reach a multiplier of that number, it's 
   better to switch your Agility-granting gear for gear that gives Strength or Intelligence, 
   if you don't need it.
   
   In the same vein, if a less powerful weapon that you have equipped can reach a higher 
   Hit Multiplier, maybe switching to it to see if your damage is better might pay off!
   
 * With the Vancian System, and limited MP restorative Items, it's back to manage your  
   MP again. It's always better to use your lower Level Magic Spells, specially the  
   -Ara Spells will serve you well for a long, long time. Look at the bestiary to see 
   enemy resistances in order to save up MP and not spend it on monsters that resist a 
   particular Element or Status Effect!
   
 * Use Gil cleverly! Buying Weapons and Armor whenever you get to a new town might not 
   be the best choice. Remember, lots of treasure lie in chests, so you might buy something
   only to find that exact equipment (or something of similar usefulness) on a chest a short 
   while after. So, I kinda recommend you to delay your purchase of equipment to after exploring 
   at least part of your next cave, dungeon or fortress. 
   
   Magic is an completely different thing, though. You can't find Magic books anywhere, the only 
   way to learn a new Spell is simply paying to be teached it to you, so investing on Spells the 
   first time you visit a town has a higher priority. In the same way, remember to always carry 
   some Healing Items with you, remember that reviving characters is complicated early on. 
   
 * Going with the above, fight the urge to sell your Items. You never know when a piece of Armor 
   will be useful to you later, either for its stat bonuses, its Elemental Resistances and such.
   Some pieces of equipment can't be recovered easily if you sell them, and others, can't be got 
   back at all! So do not make this mistake. Monsters will start rewarding more Gil as you advance.
   
   With that said, if you find something none of your characters can use, then there's not much to 
   feel sorry about, unless you're one of those that like to have a "full inventory", of course. 
   
 ---------------------------------------------------------------------------------------------------

	And that's it, I guess. 

      
    I hope you have fun with this, and if not... Hey, thanks for giving it a chance anyway!
