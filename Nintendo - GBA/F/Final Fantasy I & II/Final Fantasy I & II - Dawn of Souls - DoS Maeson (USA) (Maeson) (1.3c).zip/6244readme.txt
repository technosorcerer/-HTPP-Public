
		o------------o
		|Installation|
		o------------o
		
 Very simple process, really. It's an IPS Patch, so you 
 need something like Lunar IPS and a clean US rom. 
 
 You grab the Main Patch and apply it to the Rom with 
 a tool such as Lunar IPS, and you're done. 
 
 This hack is compatible with two other Hacks made by 
 other people, these being:

 Kea's "Unrunnable Battle Notifications", which will 
 warn you when you won't be able to run from a specific 
 battle (like from Piscodemons, or Bosses). 
 
 http://www.romhacking.net/hacks/2958/
 
 And Rabite's Improved Equipment Viewer, which is also 
 great and offers a much, much better way of seeing 
 equipments specific stats (by "using" the equipment 
 on the Items menu). 
 
 http://www.romhacking.net/hacks/5685/
 
 I totally recommend using them, both with an unmodded 
 version and with my hack.
 
 Also, after applying my patch, and these two if you want,
 you can apply one of my optional patches to. 
 
 They're very simple, really. One changes the palette of 
 the Ninja so it's red like in the original game as, funny 
 as I find it to be, some people found it to be a "betrayal"
 to change it to green. 
 
 It wasn't hard to do so why the hell not add it as an extra 
 option. 
 
 The second optional patch lowers the difficulty slightly, for 
 those that I guess don't want to be challenged much. Enemies
 physical and magical power will be toned down, and just that. 
 
 The third optional patch brings back the Level 99 Cap from the 
 original GBA version. My hack puts a Level 50 Cap as it was on 
 the oriignal NES game, but some people apparently like to grind 
 a lot.
 
 The fourth one raises the number of Magic Points your characters 
 get for Levels 1 to 4, mostly made for party setups that might 
 not be to usual, so there's a few more casts to help them out.
 
 The last one increases the HP of Bosses bit so boss battles take
 a bit longer, as sometimes I kinda feel like I wanted them to 
 last a bit more, but that might be just me. Nothing else is changed.
 
-------------------------------------------------------------------------------------------------