FINAL FANTASY I: DAWN OF SOULS
Vancian Magic System Patch
by Kea


I. General Information

This patch overhauls Final Fantasy 1's spell system to a Vancian system. Instead
of having a single pool of Magic Points (MP) for all spells, characters possess
eight successive pools of spell charges, one for each level of spell. All spells
cost one charge from their corresponding spell level to cast. In short, the game
will operate on a system very similar to that used by the original NES version.

As part of the process of constructing this patch, many areas of the game have
received minor modifications, and a few supporting systems have been introduced.
For instance, when leveling up a character's spell charges will increase
deterministically according to their class; items and spells that restore or
modify MP have had their formulas changed (eg Faerie Tonics do nothing now); and
various routines that display or otherwise handle MP have been rewritten for
Vancian magic. Because one character's spell charge data takes up sixteen bytes
instead of four, the Bestiary has been slightly downsized in order to make room:
it will only count up to 99 kills per monster species, down from 999.

This patch is intended for other hackers to use as a basis for making their own
mods. While it is fully playable and functional by itself, no changes to game
balance beyond the most cursory and essential have been made, being out of the
scope of this project. It is up to the user to make those considerations.

II. Files

The core of this patch is "FF1a - Vancian MP System.bps", a .bps patch meant to
be applied to an unmodified Final Fantasy I & II - Dawn of Souls ROM. It can be
applied using Beat, Floating IPS or any other program that handles .bps patches.

For those wishing to understand the inner workings of this patch such as changed
or new data formats, formulas, and other things to keep in mind when working
with this system, "Technical Information.txt" provides a summary of pertinent
modifications and locations of new and changed data, code and text.

In addition, the full source and notes of this project, containing an exhaustive
accounting of all changes made, is located in the Source folder under the main
directory. Compiling the .asm source files requires devkit Pro, but take note:
not all of these files can be assembled! A few are disassemblies of changes made
using a debugger and are included for reference only.

Finally, the Addons folder contains additional .ips patches which can be applied
after the main patch. These addons consist of changes which may be helpful or
interesting, but are not required for the main patch. Further details on each
individual patch can be found in their matching text files.

III. Version History

Version 1.1.3 - June 10 2023
	-Fixed lingering Bestiary display bugs. Every indexing to the Bestiary
	struct should properly use byte-sized data now.

Version 1.1.2
	-Fixed fatal bug wherein selecting an empty spell slot on a level you have
	charges for would softlock the game.

Version 1.1.1
	-Fixed bug regarding miscalculation of MP to restore from Ethers.

Version 1.1
	-Adjusted position of character names and sprites in pause menu so they didn't
	jut against "Lv. X".
	-Fixed bug wherein Ethers would softlock the game when used in the field.
	-Adjusted Red Mage's default MP progression...it was using wrong values before.

Version 1.0 - May 22 2017
	-Initial release.
	-Includes addon "Monster-cast Spells use Spell's GFX ID".

IV. Contact
I can be contacted on RHDH (romhacking.net) as Kea, or by email as rpgkea at Gmail.