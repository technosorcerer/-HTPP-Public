Final Fantasy 1 and 2: Dawn of Souls
	Ludmeister's Mod of Balance v2.2
	http://jeffludwig.com/
*********************************************************

This patch kit will convert a stock version of Final Fantasy 1 and 2: Dawn of Souls 
to Ludmeister's Mod of Balance v2.2. Here's exactly what this will accomplish:

This mod aims to improve the gameplay of both Final Fantasy 1 and Final Fantasy 2. 

The Final Fantasy 1 mod was originally intended to restore the difficulty of this
GBA version of the game to the difficulty of the original NES version, so it can
be enjoyed with all of the modern trappings of the GBA version.  Version 2.0 was
a step beyond the previous one, and was intended to provide enhancements to the 
gameplay and address user critcisms of version 1.2.  The current version is mostly
a bugfix version.

This patch also is a small rebalance for Final Fantasy 2 GBA: Mod of Balance.
The ambition behind this mod is simple: "unbreak" the character development
mechanics.  The GBA version already fixed the select-action-cancel-action-and-gain-skill-
ad-nauseam bug, but still required players to grind in all the wrong ways. Unlimited
actions should increase slower than actions that are limited by mana or resources.
I hope I have succeeded in making Final Fantasy 2 play much more smoothly. Secondarily,
weapons were much too underpowered in the endgame as enemy defense rendered them mostly
useless versus spells. Warrior-heavy and magic-heavy party builds should have the
potential to be equally successful.


Credits
*********************************************************

Huge kudos to Rabite.  He's had a ton of great ideas and given me great feedback.

Credits and thanks are due to LeviathanMist and Robert August de Meijer for their
critical insight and constructive criticism.  You helped to raise the bar for this mod.

John Dane, MegaFlux, and DesmondRai in particular from GameFAQs have also weighed in, 
and offered inspiration and good ideas for the version 2.0 update.  

Thanks to Vertigo 1 for finding the Protera bug.

Thanks to all the fans of the previous version of the Mod of Balance who let me know 
you enjoyed it.  

If you'd like to weigh in as well, here's a forum for discussing the FF1 portion of 
the mod:
	http://www.gamefaqs.com/boards/920240-final-fantasy-i-and-ii-dawn-of-souls/60914390

And this is the companion thread for FF2:
	http://www.gamefaqs.com/boards/920240-final-fantasy-i-and-ii-dawn-of-souls/62688920
	
Of course, you can always contact me directly via jeffludwig.com.



Notice, effective March 1st, 2012 
******************************************************************************

	For this release and all new releases, I am discontinuing the use of 
	IPS2EXE to create patches that can be applied without an IPS patching 
	program.  These executable patches set off certain virus and malware 
	scanners.  



	
Version 2.2 Changelog
*********************************************************

	Final Fantasy 2

		  *	The times that spells become available should be more balanced. In particular,
		    Berserk, Toad, and Blink are available later, and Slow, Sleep, and Haste are
			available more soon.  
		
		  * The extremely rare spells Break, Stop, and Confuse are not as rare anymore.
		  
		  * A few spell shops have been tweaked.  Most notably, Blink and Fog are no longer
		    for sale.  Sleep and Slow are now purchasable, Haste is available in shops, and
			very late in the game you may purchase Osmose.  Sleep and Slow sell for much
			less than they used to be, to compensate for this.
			
		  * Sap is now more powerful than Osmose.  As it should be...
		  
		  
	Final Fantasy 1:

		  * The Mute spell was confirmed to not silence characters, but paralyzed them 
		    instead when enemies succeeded in affecting them.  Thus, the Mute spell has been
			removed from all enemies' AI.
			
		  * The Load game screen only showed 3 HP/MP digits.  It now shows 4 HP/MP digits as
		    it should.
			
		  * A group of monsters consisting of 2 Death Machines and at least 2 Prototypes would
		    overflow the 16-bit Experience reward, and would therefore yield a paltry amount of
			experience.  The Experience rewards for these two enemies has been adjusted to
			sidestep this bug.
			
		  * Speaking of the Death Machine, it has been renamed for all you nostalgic types...
		    to WarMECH.
			
		  * WarMECH is now encounterable on the fifth floor of Tiamat's Floating Castle.  Again.
		  
		  * Soul of Chaos enemies now award slightly more experience.  Big Eyes give more EXP
		    and gold.  
			
		  * The Sahagin Queen is less likely to use Acid Rain (that's deadly to a 35th level 
		    party).  The Devil Wizard has less Intellect.  Their Flare was just too wicked 
			before... Also, the Skuldier is less cowardly than before (it's undead after all).
		  
		  * Stat items now only increase their respective stats by 1.  No more reloading to get
		    +2 or +3 bonuses... sorry power gamers ;-(
			
		  * A bug with Intellect was determined in which equipment was able to increase Int over
		    255, overflowing its byte.  This has been fixed; Intellect is properly capped at 255.
			
		  * Evasion is now gained at a rate of +1 per level for all characters.  Before, Evasion
		    would increase at level up ONLY if they had also gained Agility that level.
			
		  * The Inn now properly heals party members by +9999 HP/MP.  The Cottage has the same
		    effect as sleeping at an Inn.  Tents now heal +400 HP and restore +150 MP, and
			Sleeping Bags recover +150 HP.
			
			
		  
		  
		  

Version 2.1 Changelog
*********************************************************

	Final Fantasy 1:

		  * Sidestepped the Protera bug as found by Vertigo 1.  When a monster casts Protera and
		    there are more than 6 monsters present, it caused the game to freeze.  Dark Fighters 
			now may only appear in groups of six or less.
		  
		  * Many weapons and armors are re-valued.  In almost every case, this resulted in lowered 
		    purchase prices (and selling prices).
			
		  *	Fixed a couple of textual display issues.  When a character is paralyzed during
		    battle, their name renders as "Stunned" rather than "Paralyzed" so you can see 
			the character's HP.  Also fixed is the battle Equipment listing displays the 
			item quantities clearly.
			
		  * After casting the Comet spell, the caster now returns to the party lineup properly.
		  
			
			

Version 2.0 Changelog
*********************************************************

	Final Fantasy 2:

		  *	Weapons and magic levelling are hopefully balanced now.  Magic is easier 
		    to level, weapons take a fair bit longer.
		  
		  *	Practicing a weapon or spell always increases a character's skill, even 
		    if the monster attacked is significantly weaker than the character.
		  
		  * Fixed a display bug concerning the number of hits connected when a character 
		    is using a shield.
			
			  If a character used a weapon in their primary hand, and a shield in their 
			  secondary hand, they struck with the shield, and if they hit did no damage. 
			  This has been corrected.
			  
			  This bug still is in effect if the character uses a weapon in their secondary 
			  hand, and a shield in their primary hand.
		
		  * Monsters take double damage if vulnerable to a spell's element.  This is 
		    reduced from x4 damage. Don't worry, this is still *plenty* of damage.
		  
		  * If an elemental weapon strikes a vulnerable monster, its Attack rating is 
		    increased by 25 (increased from 20).
		  
		  * If a weapon which has an affinity for damaging a specific family of monster 
		    hits that kind of monster, its Attack rating is increased by 25 (increased 
			from 20).
		  
		  * Strength increases more often. The chance was (number of "fight" 
		    selections / 45), and it is now (number of "fight" selections / 32).
		  
		  * Agility increases are more regulated- more likely early in the game and less 
		    likely later on. Before, a random number was rolled between 0 and 255, and if 
			that was lower than a fourth of the character's Evasion, Agility increased. 
			Now, the random number rolled is now between 0 and 250, and the Evasion is a 
			little less important in determining increase.  Base chance to increase Agility 
			is 2.0%, and maximum chance is 6.8%.
		  
		  * Intellect increases more often. The chance was (number of black magic 
		    castings / 25), and it is now (number of black magic castings / 16).
		  
		  * Spirit increases LESS often. The chance was (number of white magic castings / 15),
		    and it is now (number of white magic castings / 20).
		  
		  * MP increases more often. The chance should be about 25% more likely than it was 
		    before.
		  
		  * When a character gains HP, the increase is halved. The increase is (STA / 2). 
		  
		  * Magic evasion gains take a bit longer. The threshold to gain Magic evasion 
		    was 99, and it is now 159.
		  
		  * Characters start with different stats. 
		  
		  * NPCs also begin with different stats, and should be more balanced with the 
		    party when you meet them.  Leon and Gordon also join the party already equipped 
			with spells.
		  
		  * Weapons, armor, and spells have been rebalanced.  Enemy direct damage spells will
		    be a bit more dangerous and require more planning to thwart.
		  
		  * Monster stats have been modified slightly to moderately.  Expect that the final 
		    bosses will not go down with a couple of well-placed elemental spells.
		  

	Final Fantasy 1:
	
		Version 2.0: New Features
		
		  * Samurai is recast as a Rogue. Their arsenal has changed slightly, but still cast 
		    the same spells (except Slow has been swapped in for Blizzard). Of course Ninjas 
			are still the same old Ninjas :-)
		  
		  * There have been several slight tweaks to the starting stats and early level ups 
		    for each class. In particular, I felt that Red Mages received no love in early 
			level ups, and so I fixed this.
		  
		  * Accuracy equation has been changed slightly.  It is now
			  o Attackers Accuracy - Defender's Evasion + 120 = chance to hit out of 161.
			  o The chance to hit is 10% minimum, and 90% maximum.  
			  o The base chance to hit is 75%, ie when Attacker's Accuracy and Defender's 
			    Evasion are equal. This is increased from 67%.
			  
		  * Spells that grant bonuses to Attack and Defense are now limited in their 
		    stackability.  The cap on the bonuses was 255 before, now the cap is 50.  No more 
			one-shotting Soul of Chaos bosses.
		 
		  * Damage spells inflict much more randomized damage.  Damage is between 1/2 to 3/2 of 
		    spell's base power, before applying resistances.  Luck and Intellect play an even 
			larger part in the equation. Of course, this goes for enemies and allies.
		
		  * The status screen now shows a character's number of strikes per round and their 
		    magic defense.
		  
		  * The chance to be attacked in several dungeons has been tweaked slightly.
		  
		  * Chaos Temple level 5 now has very interesting, dangerous, and rewarding encounters.
		  
		  * Astos' Northwest Castle now has numerous Undead-themed random encounters. No walking 
		    around this haunted castle with impunity!
		  
		  * The Sages' Staff has been realigned, and is now a White Wizard only staff named the 
		    "Holy Staff". It is pretty awesome, and it *is* rare.
		  
		  * The more powerful restorative items have had their prices increased dramatically.
		  
		  * Staves in general are more useful. Defensive type weapons give bonuses to Evasion.
		  
		  * Elixirs and Megalixirs drop less often.
		  
		  * The Paladin can now cast Curaga.
		  
		  * The Hermes' Shoes now cast Haste as advertised. This was an issue in v1.2, as they 
		    used to cast Temper. 
		  

Version 1.2 and prior Changelog
*********************************************************
		  
	Final Fantasy 1

		  * Fighter/Knight has been renamed to Knight/Paladin, and Thief/Ninja has been renamed 
		    to Rogue/Ninja.
		  
		  * Knight/Paladin is more defensive than offensive. Rogue/Ninja is a lightning fast 
		    assault trooper.  Monk/Master is ever the unconventional, survivalist type.  The 
			White Mage/Wizard is the healer and defensive specialist, and can take quite a 
			beating too.  The Black Mage/Wizard is the undisputed master of the magical nuke, 
			and the Red Mage/Wizard can do a bit of everything, but only to a point.
		  
		  * Changes to starting stats for the character classes, and their developmental curves.
		  
		  * Item proficiencies have changed:
			  o Knights and Paladins cannot use most dark weapons, or weapons of cruelty.
			  o Rogues can use heavier swords as did the Thief, including some katanas. 
			    Ninjas cannot use axes. Both classes only wear light armor and cannot use most 
				conventional shields.
			  o Masters can use some katanas, if that is to your liking.  Nunchukas are useful 
			    for a bit longer in this game.
			  o Black Mages cannot use the best daggers.
			  o White Mages and Wizards are proficient with almost all armor, and their 
			    hammers have been upgraded quite a bit.
			  o Red Mages now are more limited in the weapon choices, but can use a bit more 
			    armor.
		
		  * All of the classes possess at least some magical ability:
			  o Knights gain certain level 1-4 White Magic spells, and Paladins can learn 
			    up to level 5 White Magic spells.
			  o Rogues can learn certain level 1-4 Black Magic spells, and Ninjas extend 
			    that up to level 6.
			  o Monks learn special level 1-3 spells (might be classified either as Black or 
			    White), and Masters can learn level 4 spells.
			  o The spell ability of Red, White, and Black magicians have not been altered.
		
		  * Characters gain less HP and MP per level, but have a slightly better chance of 
		    increasing stats at level up.
		  
		  * Hit Rate increases at a different rate as stock FF1, and the rate changes after 
		    class change:
			  o Knight:	+2/level, Paladin +3/level
			  o Rogue: +3/level, Ninja +4/level
			  o Monk: +2/level, Master +2/level
			  o Red Mage: +2/level, Red Wizard +2/level
			  o White Mage: +1/level, White Wizard: +2/level
			  o Black Mage: +1/level, Black Wizard: +1/level
			  
		  * Likewise, Magic Defense increases at these rates:
			  o Knight:	+2/level, Paladin +4/level
			  o Rogue: +1/level, Ninja +2/level
			  o Monk: +2/level, Master +3/level
			  o Red Mage: +3/level, Red Wizard +4/level
			  o White Mage: +4/level, White Wizard: +5/level
			  o Black Mage: +4/level, Black Wizard: +5/level
			
		  * Revamped the Monk's defense algorithm. Monks now receive a defense bonus if 
		    no armor is equipped, based on their Stamina, Intellect, and Agility. Masters will 
			receive a constant defense bonus (regardless of armor), based on those same 
			statistics. Specifically:
			  o Monk/Master old algorithm: Armor (STA/2) + Helm (STA/8) + Gloves (STA/8)
			  o Monk new armor rating: (STA/2) + (STA/8), or Armor equipped
			  o Monk new helm rating: INT/4, or Helm equipped
			  o Monk new gloves rating: AGI/4, or Gloves equipped
			  o Master new armor rating: STA/2 + Armor equipped
			  o Master new helm rating: INT/8 + Helm equipped
			  o Master new gloves rating: AGI/4 + Gloves equipped
			  
		  * White Mages and Monks gain a +5 Attack bonus when using weapons.
		  
		  * Comprehensive changes to weapons, armor, magic, monsters, experience curve, etc.

		  * Comprehensively reworked all monster's Hit Rate and Evasion stats, and realigned 
		    the Evasion statistic for all character classes. Obviously, Rogues and Monks are 
			the best at Evasion!

		  * Shops are completely realigned, and many shops sell more than five items!

		  * Direct damage magic increases in power much more smoothly.  The nitty gritty: 
		    The damage used to increase in a stair-step manner, adding 1 to the multiplier 
			to damage every 10 Intellect points. Now, the multiplier increases every 2 
			Intellect points, but each "stair" is less steep to make up for the added number 
			of "stairs".
		  
		  * Some magic has been swapped out for other more interesting spells. 
		  
		  * Did I mention that many changes have been made to the monster's stats? They are 
		    significantly tougher.  The farther you go in the game, the more you will realize 
			that they will not go down with a couple of well-placed sword blows.
		  
		  * Soul of Chaos bosses have been actually demoted in power a bit to make them 
		    possible to defeat, given that you will reach them at a lower level than you might 
			have otherwise in stock Dawn of Souls.
		  
		  * Every monster that you beat may drop an item. As you beat new monsters, make sure 
		    you visit the bestiary to see what you might earn with repeated victories. You 
			can even earn the previously unattainable Angel's Ring!
		  
		  * The gold earned from defeating most foes is significantly lowered. You will 
		    earn a much greater percentage of your gold, especially in the early to mid 
			game, by finding treasure chests in the main storyline.  Gold management will be 
			key to early advancement.
		  
		  * Minor adjustments to the AI of various monsters. For instance, Goblin Guards now 
		    cast some magic and Yellow Ogres don't run as often.

		  * Minor adjustments to where monsters may appear in the game.		  
		  
		  * When striking a monster prone to the elemental or racial properties of a 
		    weapon, the bonus to attack power has increased from 4 to 25. Use weapons that 
			exploit the weaknesses of your enemy, especially in the early to mid game!
		  
		  * All critical hits gain an additional 50% bonus to attack power (previous bonus 
		    was 25%).
		  
		  * Direct damage magic has been realigned slightly.  The most powerful spells 
		    (Firaga, Thundaga, Blizzaga, Diaga, Holy and Flare) grow in power faster. 
			The lower powered spells (Fire, Thunder, Blizzard, Pain, and Dia) have a lower 
			base damage, making them initially less powerful.
		  
		  * Dia family spells effect evil and demonic creatures as well as the undead. 
		    Yes, it will even work against Garland and Astos! It also works against the 
			FF4 elemental fiends.
		  
		  * Temper increases Attack by 25. Zeal increases Attack by 16 for all allies.  
		    Saber increases Attack by 25 and Hit Rate by 30.
		  
		  * The White Magic Rally spell now cures the Mute condition.
		  
		  * Ninjas may cast the Level 6 Black Magic spell Death.
		  
		  * Removed the 255 cap for damage-per-hit.  The code actually limited each hit 
		    to 255 damage.
		  
		  * Soul of Chaos bosses now correctly award experience; they didn't in previous 
		    versions due to a hard-coded conditional check.
		  
		  * Golden and Silver Apples, as well as Soma Drops now increase HP and MP beyond 
		    999.
		  
		  * Characters kneel in battle when they have less than 1/5 HP.  Previous threshold 
		    was 1/10 HP.
		  
		  * Removed the 2,000,000 experience cap, allowing for the full development of
		    your characters with my experience curve.
		  
		  * Removed the 999 cap for HP and MP.  The cap is now 9999, if you can ever get 
		    that many Golden and Silver Apples.
		  
		  * Raised the cap for Strength, Agility, Stamina, Intellect, and Luck to 255.  
		    Previous cap was 99.
		  
		  * Removed the 255 cap for a character's base Hit Rate. Extraordinarily high 
		    level Ninjas will appreciate this.
		  
		  
		  

Known issues
*********************************************************

	Final Fantasy 1: 
	
		  * None currently known in version 2.2.
			
	  

To convert your Final Fantasy 1 and 2: Dawn of Souls ROM
*********************************************************

The following applies this and all future releases of the Ludmeister's Mod of Balance.

0. First of all, you will need to obtain a clean GBA ROM of Final Fantasy 1 and 2: 
   Dawn of Souls. You are on your own for this step, as it is illegal to provide ROMs
   of copyrighted material. There are sites that do provide this ROM though, and you 
   should be able to obtain it.

1. When you get it, make a backup of it if you would want to play the stock version, 
   play another mod, or, in case I post an updated version of the mod here... I am not 
   going to make version 1.0 to "version whatever" patches for my mods, for instance.
   
2. Download the newest version of Ludmeister's Mod of Balance. 
  
3. Use the IPS patching program of your choice to apply the .ips patch to the 
   correct ROM.  As I use IPS XP (http://home.arcor.de/minako.aino/ipsXP/) to
   create my patches, I recommend using this program to patch your ROM.
	    
4. I hope you enjoy it!

