Final Fantasy 1 and 2: Dawn of Souls
	Ludmeister's Mod of Balance v1.0
	http://jeffludwig.com/
*********************************************************

This patch kit will convert a stock version of Final Fantasy 1 and 2: Dawn of Souls 
to Ludmeister's Mod of Balance v1.0. Here's exactly what this will accomplish:

This mod aims to improve the gameplay of Final Fantasy 1. 

The Final Fantasy 1 mod is intended to restore the difficulty of this GBA version 
of the game to the difficulty of the original NES version, so it can be enjoyed 
with all of the modern trappings of the GBA version.  



Notice, effective March 2nd, 2012 
******************************************************************************

	For this release and all new releases, I am discontinuing the use of 
	IPS2EXE to create patches that can be applied without an IPS patching 
	program.  These executable patches set off certain virus and malware 
	scanners.  



Version 1.0 Changelog
*********************************************************

	Final Fantasy 1

		* Weapons tweaked a bit; rare weapons are generally better, rewarding 
		  your forays into the bonus dungeons.
		  
		* Removed the 2000000 experience point cap, allowing for the full 
		  development of your characters.
		  
		* Removed the 999 cap for HP and MP! The cap is now 9999, if you can 
		  ever get that many Silver and Golden Apples...
		  
		* Reset the cap for Strength, Agility, Intellect, Stamina, and Luck to 
		  255. Previous maximum was 99.
		  
		* Removed the 255 cap for a character's base Hit Rate. Extraordinarily 
		  high level Ninjas will appreciate this.
		  
		* Direct Damage spells increase in power much more smoothly now. The nitty 
		  gritty: The damage used to increase in a stair-step approach, adding 1 to 
		  a multiplier to damage every 10 Intellect points. Now, every 2 Intellect 
		  points increases the Intellect multiplier by 1, but damage-wise, each "stair" 
		  is less steep to make up for the added "interim stairs".
		  
		* Many White Magic spells have been reordered, which may lead to a couple 
		  new surprises.
		* Many high level Black Magic spells are more powerful, especially when the 
		  castor's Intellect rises.
		  
		* Elven Balm now behaves as expected in battle.
		
		* The targeting screens for the Poisona and Warp spells, as well as the items 
		  Antidote, Mind Balm and Elven Balm now report their description properly.
		  
		* Blood Tigers reward party with more experience.

		
Version 0.998 Changelog
*********************************************************

	Final Fantasy 1

		* Fighter/Knight has been renamed to Knight/Paladin, and Thief/Ninja has been 
		  renamed to Samurai/Ninja.
		  
		* Knight/Paladin is more defensive than offensive. Samurai/Ninja is a lightning 
		  fast assault trooper. Monk/Master is ever the unconventional, survivalist 
		  type. The White Mage/Wizard is the healer and defensive spellcaster. The 
		  Black Mage/Wizard is master of the magical nuke, and the Red Mage/Wizard 
		  shows flashes of the defensive spellcasting of the White Mage, the offensive 
		  spellcasting of the Black Mage, all while retaining moderate physical prowess.
		  
		* Item proficiencies have subtly changed:
		  o Knights and Paladins cannot use most dark weapons, or weapons of cruelty.
          o Samurais use heavier swords than did the Thief. Ninjas cannot use axes. 
		    Samurais and Ninjas can use only light armor and cannot use conventional 
			shields.
          o Masters can use some katanas, if that is to your liking. Nunchukas are 
		    useful for a bit longer in the game.
          o Black Mages cannot use the best daggers.
          o White Mages and Wizards are proficient with almost all armor, and their 
		    hammers have been upgraded a bit.
          o Red Mages now are more limited in their weapon choices, but can use a few 
		    more of the armors.
		  
		* All of the classes have at least some magical ability:
          o Knights gain certain level 1-4 White Magic spells, and Paladins can learn 
		    up to level 5 White Magic spells.
          o Samurais can learn certain level 1-4 Black Magic spells, and Ninjas extend 
		    that up to level 5.
          o Monks learn special level 1-3 spells (might be classified either Black and 
		    White), and Masters can learn up to level 4.
          o The Red, White and Black magicians' spell ability is not significantly 
		    changed.
			
		* The experience curve has been modified, making levels harder to attain.
		
		* Characters gain less HP/MP per level, and have a slightly better chance of 
		  increasing stats at level up.
		  
		* Hit rate increases at a different rate, and the rate can increase after class 
		  change:
          o Knight: +2/lvl, Paladin: +3/lvl
          o Samurai: +3/lvl, Ninja: +4/lvl
          o Monk: +2/lvl, Master: +2/lvl
          o Red Mage: +2/lvl, Red Wizard: +3/lvl
          o White Mage: +1/lvl, White Wizard: +2/lvl
          o Black Mage: +1/lvl, Black Wizard: +1/lvl
		  
		* Likewise, Magic Defense increases at these rates:
          o Knight: +2/lvl, Paladin: +4/lvl
          o Samurai: +1/lvl, Ninja: +2/lvl
          o Monk: +2/lvl, Master: +3/lvl
          o Red Mage: +3/lvl, Red Wizard: +4/lvl
          o White Mage: +4/lvl, White Wizard: +5/lvl
          o Black Mage: +4/lvl, Black Wizard: +5/lvl

		* Many weapons and armor are changed. The game's graphics are exactly the same 
		  but the strength and properties of each item has been meticulously re-tooled, 
		  and the in-game descriptions have also been changed to match.
		  
		* Some of the spells have changed. For now, you'll just need to play the mod to 
		  find out what exactly has changed! The attack spells gain in power significantly 
		  as the caster's intellect increases.
		  
		* The hit rate of characters used to have an absolute cap of 255. That cap has 
		  been lifted, so characters can normally attack more than eight times.
		  
		* When striking a monster prone to the elemental or racial properties of a weapon, 
		  the bonus to attack power has increased from 4 to 25. Use weapons that exploit 
		  the weaknesses of your enemy!
		  
		* When striking a monster prone to the elemental or racial properties of a weapon, 
		  the bonus to attack power has increased from 4 to 25. Use weapons that exploit 
		  the weaknesses of your enemy, especially in the early to mid game!
		  
		* All critical hits gain an additional 50% bonus to attack power (previous bonus 
		  was 25%).
		  
		* The Dia spell family is effective against evil and demonic creatures, not just
		  against the undead. Yes, it will even work against Garland and Astos!
		  
		* Monsters are significantly tougher. The farther you go in the game, the more you 
		  will realize that they will not go down with a couple of well-placed sword blows.
		  
		* The gold earned from defeating most foes is significantly lowered. You will earn 
		  a much greater percentage of your gold by finding treasure chests in the main 
		  storyline, so gold management, especially in the early game, is a must.
		  
		* Some of the Soul of Chaos bosses are actually demoted in power a bit to make them 
		  possible to defeat, given that you will reach them at a lower level than you would
		  have in vanilla Dawn of Souls.
		  
		* Every monster that you beat may drop an item. As you beat new monsters, make sure 
		  you visit the beastiary to see what you might earn with repeated victories!
		  
		* Almost every shop in the game has been tweaked, if even just slightly.

		  

Known issues
*********************************************************

	Final Fantasy 1: 
	
		* When loading a save game from the game menu, that screen only shows three 
		  of the digits in their HP/MP (thousands digit is not shown).
		  
		* The quantity of items shown in battle equip screen is not displayed cleanly.
		
		* After casting the Comet spell, the castor returns the party lineup, and 
		  steps back yet again.
		  
		* The graphic for the Haste spell displays when a Clay Golem is casting Temper 
		  (as well as a few other slight related anomalies regarding monster's spell 
		  graphics).

		* Text overlaps in battle when a character is paralyzed.
		  
		* The Sage's Staff makes the Holy spell too powerful.
		  
		* Certain party buff spells stack far too much.
		  
		  

To convert your Final Fantasy 1 and 2: Dawn of Souls ROM
*********************************************************

The following applies this and all future releases of the Ludmeister's Mod of Balance.

0. First of all, you will need to obtain a clean GBA ROM of Final Fantasy 1 and 2: 
   Dawn of Souls. You are on your own for this step, as it is illegal to provide ROMs
   of copyrighted material. There are sites that do provide this ROM though, and you 
   should be able to obtain it.

1. When you get it, make a backup of it if you would want to play the stock version, 
   play another mod, or, in case I post an updated version of the mod here... I am not 
   going to make version 1.0 to "version whatever" patches for my mods, for instance.
   
2. Download the newest version of Ludmeister's Mod of Balance. 
  
3. Use the IPS patching program of your choice to apply the .ips patch to the 
   correct ROM.  As I use IPS XP (http://home.arcor.de/minako.aino/ipsXP/) to
   create my patches, I recommend using this program to patch your ROM.
	    
4. I hope you enjoy it!

