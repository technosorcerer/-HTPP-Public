                                 FINAL FANTASY I & II: DAWN OF SOULS
                                FINAL FANTASY ADVANCE AUTO-NAME UPDATE
                                         v0.2 (Jan 26 2019)

====================================================================================================
Disclaimer
==========
- Final Fantasy I & II: Dawn of Souls (c) Square Enix. All rights reserved.

- No ownership is claimed by FlamePurge over Final Fantasy I, Final Fantasy II, or the franchise
   from which they originate. Commercial use of this patch, including but not limited to
   reproduction, sale, etc. is strictly prohibited.

- This unofficial, fan-made patch is provided "as-is" on a voluntary (i.e. non-profit) basis.
   FlamePurge is not liable for damage incurred to the end-user, their OS, or their hardware while
   using this patch.

- Apply this patch only to a ROM with the following specifications.

    1805 - Final Fantasy I & II - Dawn of Souls (U).gba
    MD5: 5D29999685413C4D2BEC10D3160F6EE6
    CRC32: 1B39CDAB

- Players are encouraged to keep a backup of their original game file in case an error occurs.

----------------------------------------------------------------------------------------------------

FFI Advance introduced an Auto-Name feature, where the four faceless avatars could be given names
based off of NPCs from FFIII, IV, V, VI, and IX. The localization team even did their homework, and
checked the previous official English releases of games in the series, ensuring that returning
players would catch the references.

However, this caused a problem when later games received their re-localizations. Suddenly, the names
in FFI Advance didn't match up anymore! This patch seeks to rectify that.
====================================================================================================

====================================================================================================
Overview
========
- 17 of the 60 possible auto-names have been updated to modern Final Fantasy series standards.

- The dialogue font was slightly updated.
====================================================================================================

====================================================================================================
Changelog
=========
v0.2
- Fixed the shadow on the dialogue font's number 8. This affects both games.

- Updated the comma. This affects both games.

v0.1
- Updated 4 possible Warrior names.
(Zeza   > Xezat
 Desh   > Desch
 Arus   > Alus
 Sasun  > Sasune)

- Updated 3 possible Thief names.
(Daryl  > Darill
 Kelga  > Kelger
 Tuss   > Tsuze)

- Updated 2 possible Monk names.
(Walz   > Walse
 Drogan > Dorgan <Dorgann>)

- Updated 4 possible Red Mage names.
(Gill   > Ghido
 Lalibo > Ralibo <Rallybo>
 KluYa  > Kluya
 Kory   > Corio)

- Updated 4 possible White Mage names.
(Kuku   > Molulu
 Sarina > Salina
 Sherko > Shelco
 Elia   > Aria)

- Due to a 6-letter limit, was unable to expand Dorgan to Dorgann, Ralibo to Rallybo, or Delila to
  Delilah.

- Was unable to find if Gilles in Final Fantasy III Remake still has a name.

- Slightly updated the 12x12 dialogue font: exclamation mark, question mark, inverted exclamation
  mark, inverted question mark, lowercase a, all of the numbers, and all of the accented lowercase
  a's and e's. This affects both games.
====================================================================================================

====================================================================================================
Credits
=======
- Stealth Translations: Created Windhex32
- HoRRoR: Created Square Enix Remakes Font Editor
- Dragonsbrethren: Supplied values for above editor
- Square Enix
...and all you Final Fantasy fans out there!
====================================================================================================