Final Fantasy 1 and 2: Dawn of Souls
	Ludmeister's Mod of Balance v3.3, rev. 2- 12 classes
	http://jeffludwig.com/
*********************************************************

This patch kit will convert a stock version of Final Fantasy 1 and 2: Dawn of Souls 
to Ludmeister's Mod of Balance v3.3, revision 2. Here's exactly what this will 
accomplish:

This mod aims to improve the gameplay of both Final Fantasy 1 and Final Fantasy 2. 

The Final Fantasy 1 mod was originally intended to restore the difficulty of this
GBA version of the game to the difficulty of the original NES version, so it can
be enjoyed with all of the modern trappings of the GBA version.  Version 2.0 was
a step beyond the previous one, and was intended to provide enhancements to the 
gameplay and address user critcisms of version 1.2.  

Version 3.0 represented a major change in the gameplay of Final Fantasy 1, in that you
can choose any of 12 classes at the start of your campaign.  No class change happens.
This allows for a much wider variety of gameplay experiences, and removes the impetus
to sprint through Earth Cave, get the Canoe, punish yourself in Ice Cave, get the 
Airship, then canoe/fly to Castle Ordeals at a severely low level to class change as
soon as possible.  After class change, the rest of the game seems somewhat 
anti-climactic from a difficulty standpoint.  This version attempts to address this
pet peeve of mine and smooth the rather forced difficulty curve.

This patch also is a small rebalance for Final Fantasy 2 GBA: Mod of Balance.
The ambition behind this mod is simple: "unbreak" the character development
mechanics.  The GBA version already fixed the select-action-cancel-action-and-gain-skill-
ad-nauseam bug, but still required players to grind in all the wrong ways. Unlimited
actions should increase slower than actions that are limited by mana or resources.
I hope I have succeeded in making Final Fantasy 2 play much more smoothly. Secondarily,
weapons were much too underpowered in the endgame as enemy defense rendered them mostly
useless versus spells. Warrior-heavy and magic-heavy party builds should have the
potential to be equally successful.


Credits
*********************************************************

Huge kudos to Rabite.  He's had a ton of great ideas and given me great feedback.

Credits and thanks are due to LeviathanMist and Robert August de Meijer for their
critical criticism.  You helped to raise the bar for this mod.

John Dane, MegaFlux, and DesmondRai in particular from GameFAQs have also weighed in, 
and offered inspiration and good ideas for the version 2.0 update.  

Thanks to Vertigo 1 for finding the Protera bug.

Thank you to Teddy for quickly reporting the Magic Resistance display bug.

A hacker named Billy tipped me off as to where the Final Fantasy 1 Treasure rewards
were found in the ROM.  Thank you.

Another hacker called Sting Chameleon found the character palette, which provided 
the impetus for the v3.0, rev 1 release.  Awesome work, Sting Chameleon.

Also, ZekuMusashi and AramilOfTusmit from GameFAQs provided helpful contructive
criticism that made this version be what it is.  With_Knives has also weighed in 
with some good insight on how the the classes have performed. Thank you all!

Thanks to all the fans of the previous version of the Mod of Balance who let me know 
you enjoyed it.  

If you'd like to weigh in as well, here's a forum for discussing the FF1 portion of 
the mod:
	http://www.gamefaqs.com/boards/920240-final-fantasy-i-and-ii-dawn-of-souls/60914390

And this is the companion thread for FF2:
	http://www.gamefaqs.com/boards/920240-final-fantasy-i-and-ii-dawn-of-souls/62688920
	
Of course, you can always contact me directly via jeffludwig.com.



Notice, effective March 1st, 2012 
******************************************************************************

	For this release and all new releases, I am discontinuing the use of 
	IPS2EXE to create patches that can be applied without an IPS patching 
	program.  These executable patches set off certain virus and malware 
	scanners.  


	
Version 3.3, Revision 2 Changelog
*********************************************************

	Final Fantasy 1
	
		  * Fixed a rather nasty display bug in the status screen, which could cause panic
			when your first character gets more than 255 Magic Resistance.  The bug was
			cosmetic; that character would still utilize their full MR for resisting melee
			status effects and magic damage.
			
	
	
Version 3.3, Revision 1 Changelog
*********************************************************

	Final Fantasy 1
	
		  * The incessant "menu song" has been removed! When you go into your status screen,
		    the music will not change.  A slight annoyance in this changes is that if you go 
			into the Bestiary, the battle music for that monster will play over the current
			music, but (IMHO) opinion that's a small price to pay for having the menu song
			removed.
			
		  * Soul of Chaos dungeons have been exhaustively looked through to make the rate of
		    encounters less cumbersome in some tedious floors, and more frequent in some
			floors (like floors that are full of lava, because you can't be attacked while
			on lava).
			
		  * A character's Magic Resistance stat has been overhauled a bit again.  First of all, 
		    the 255 MR cap has been removed.
			  
		  * Second, when a character increases in Luck (whether via level up or by using a 
		    Luck Plus item), that character's MR is also increased by 1.
				
		  * Third, a character's Magic Resistance (as well as Hit Rate!) goes up rhythmically, 
			on a 4 level cadence.  Before, each character increased HR and MR by a flat rate 
			every level.  This table shows the modified increases, every 4 levels:
			
							Starting MR		MR increase		Hit Rate Increase
				Knight			 8				 7				10
				Rogue			20				13				16
				Master			18				 5				12
				Paladin			30				12				 8
				Ninja			25				 6				14
				Ranger			16				 8				12
				Enchanter		18				 9				11
				Battlemage		15				10				 6
				Monk			12				15				 9
				Priest			20				16				 4
				Archmage		24				14				 5
				Sage			22				18				 3
			
		  * Fixed a bug with the Elven Balm item, which was introduced when I changed the 
		    formula for calculating magic healing power.  It was using bogus data for the
			Intellect value... now it uses the leader's Intellect for determining healing
			strength.
		  
		  * The Magic Resistance of a few Soul of Chaos bosses (most notably the ones in 
			Earthgift Shrine) was too low.  This has been tweaked slightly.
			
		  * The Basilisk now drops a Remedy (was dropping Holy Water; didn't make sense after I
		    repurposed the Gold Needle).
			
		  * The Paladin can now equip an Angel's Ring (as can the Master).
		  
		  * Clarity has been bound to the Protect Ring.
		  
		  * Elfheim and Crescent Lake's item shops now sell the correct number of items.
		  
		  * The Destroy Spell now costs 33 MP, and X-Zone costs 35 MP.
				
		  * Qi Strike has been toned down a little bit.  Base chance to hit was 210 before,
		    now is 180. It's MP cost is now increased to 25.
	

	

Version 3.3 Changelog
*********************************************************

	Final Fantasy 1
	
		  * Weapons that strike at an opponent's weakness now increase their wielder's
		    effective Hit Rate by 15 (previous bonus was 40).  They also increase their
			wielder's effective Attack rating by 3x/2 (previous bonus was +25).
		  
		  * Magical healing now stairsteps like attack magic; it increases in power every
		    2 Int points.  As such, all healing magic has been rebalanced.
			
		  * Modified the algorithm for debuff spell effects.  It is interesting to note that
		    Slow, Focus, and Dispel still will not follow this rule.  Of course, all debuff
			spells and all debuffing monster attacks have been rebalanced.
		  
			  o The old algorithm was x = (Spell Power + 148 - Monster's Resistance).  
				x is increased by 40 if target is vulnerable to spell; and decreased by 148 
				if it is protected versus it.  Then, a number is rolled between 0 and 200, 
				and if the random number is less than x, the spell succeeded.
				
			  o The new algorithm is x = (Spell Power + (2 * Int) - Monster's Resistance).
			    x is increased by 50 if target is vulnerable to spell, and decreased by 100
				if it is protected versus it.  The same roll of 0 to 200 applies, with the
				same rule of success.  Note, that it is possible to still be affected by a 
				spell that you are protected against!		  
		
		  * Exhaustively rebalanced the Monster's Magic Resistance stat; it seemed that many
		    enemies had much too much Magic resistance.  However, not every monster got a 
			nerf to MR... !  Generally, the earlier monsters received nerfs, but several
			later monsters were strengthened.
		
		  * Characters should now correctly resist the monster's condition-inflict attacks.
		  
		  * Fixed a bug with my implementation of Esuna when using it in the status screen.  It
		    used to only affect the first three characters.
			
		  * Fixed a lingering bug with the Mute spell, whereby it also paralyzed its target.
		    As such, it has been added back into the mix for certain monsters to cast...
			
		  * Some monsters now inflict conditions, where they didn't before.
		  
		  * The Blind, Silence (Mute), and Paralysis conditions are now persistent after 
		    battle... you will be forced to deal with them!
			
		  * Sleeping at an inn will now cure all maladies except Stone and KO.
			
		  * Blind is a more serious malady than before; it used to levy a -40 penalty to
		    the sufferer's Hit Rate.  Now, it halves their Hit Rate.  If that weren't 
			enough, it also causes the character to take 50% more damage from enemy
			melee attacks (just like if they were asleep or paralyzed)!
			
		  * The Rally spell has been renamed to Clarify.  This is a single-target only 
		    version of the spell that it was before (cures Blind, Paralysis, Sleep and
			Silence).  It can be used in the status screen.  The Mind Balm item, which
			is bound to Clarify's effect, can now be used in the status screen as well.
			
		  * The Remedy item didn't cure Stone before.  Now, it acts like an Esuna spell.
		  
		  * In v3.2, the Gold Needle acted just as the Esuna spell did, and this was a
		    bug (oversight on my part).  The Gold Needle has been removed from the game;
			in its place is the Holy Water, which yields a Diara effect.
			
		  * Because there are only two known remedies to the Stone condition (Esuna, and
		    the item Remedy), Remedies have been made more common; they are sold in Elfheim
			and Crescent Lake.  The Vivify spell may also counteract Stone.
		  
		  * Powered up the Nuldeath spell, and renamed it to Nulmagic.  It protects the
		    party against all magic excepting Fire, Ice, and Lightning.
			
		  * Changed the Nulall spell to a single target HP Max spell, named Vivify. Curaja, 
		    by contrast, is now simply a more powerful version of Curaga which can now also
			be cast by Monks.  It also is much less costly to buy.
			
		  * The Hold and Invis spells have been removed.  Invis has been replaced with 
		    Meditate, which is a caster-specific buff to Attack and Accuracy, available to 
			Monk, Master, and Priest.  Blind is now a 3rd level Black spell, and in the 4th 
			spell level, Qi Strike has been included.  It is usable by Ninja, Monk, and 
			Master, and is a death strike that has no resistances that protect against it.
			In other words, only the target's Magic Resistance can help them!
			
		  * The level 8 Black spell Kill spell has been replaced with the Destroy spell.  
		    Instead of being a high-powered death spell, it does an automatic 1500 damage
			to any enemy, bypassing resistances (even to your allies!)
			
		  * Flay can now be cast by Battlemages.
			
		  * The Saber spell has been renamed to Enchant, and may now be cast on any member
		    of the party.  Invisara has been renamed to Vanish.
			
		  * The MP Cost of many spells (especially Cures and Debuffs) have been tweaked.  
			
		  * A few minor tweaks to where spells are sold have been introduced, since the
		    Monk-based spells have been tweaked.
			
		  * The Master has been given a new Spell Level progression, due to being able to use
		    a level 3 and a level 4 spell.  That progression is now 5/ 10/ 15/ 20.
			
		  * Fixed the Priest's bonus attack power, as in v3.2 the Priest got the Knight's
		    attack bonus!
		  
		  * The Devil Wizard has been given a significant nerf to its Agility, and now casts
		    Quake first, then Flare.  You now have a small hope of victory when three or more
			show up.
			
		  * Unicorns now have 40 Intellect; that's down from 50.
		  
		  * The Holy Dragon now has 37 Intellect, that's down from 50.
		  
		  * A few (very minor) changes to monster AI, to allow for the new spell roster.
		  
		  * The moderately rare Neochu has been powered up significantly.
		  
		  * The Giant's Glove now casts Meditate, and not Pummel as before.  The Lightbringer
		    now casts Nulmagic (not Blind), and the White Robe casts Protera (not Nulmagic).
			Finally, the Murasame casts Qi Strike!
		  
		  * The Ragnarok, and especially the Excalibur, now are effective against fewer 
			creatures (don't worry, it's still a lot!).
			
		  * The Master can now equip the Ribbon.
		  
		  * Garland now drops a Scimitar (he used to drop a Broadsword).  Paladins can equip
		    the Scimitar.
			
			
	
	
Version 3.2 Changelog
*********************************************************

	Final Fantasy 1
	
		  * Converted 6th level White Magic spell "Stona" to "Esuna".  This spell is a 
		    super-powerful Rally spell, which can cure all maladies (excluding KO) currently
			affecting all party members.  It can still be used anywhere, for 20 MP.
			
		  * Paladins can now cast 6th level spells.  Their new spell progression is 
			4/ 8/ 14/ 19/ 26/ 34.
		
		  * All normal Final Fantasy 1 Fiends have been given an HP boost to make them more
		    challenging.
			
		  * Several classes have been awarded an attack power bonus when wielding a weapon.  
		    The old attack bonus was +5 for Knights, Monks, Paladins, and Battlemages.  Now,
			
			  o Knights and Monks gain + (lvl / 4) + 8.  Bonus ranges from 8 to 32.
			  o Paladins and Battlemages gain + (lvl / 8) + 6.  Bonus ranges from 6 to 18.
			  o Rogues, Rangers, and Priests gain + (lvl / 8).  Bonus ranges from 0 to 12.
			  o Masters, Ninjas, Enchanters, Archmages, and Sages still get no bonus.
			  
		  * The Ninja has been granted the Monk's unarmored bonus.  It will operate differently
		    for the Ninja than the Monk though, since the Ninja's stats are much more 
			disparate than the Monks.  
			
		  * Gave the Enchanter and Battlemage a couple of strong MP gains early on to give
		    them a magical boost over against the secondary fighter classes.
			
	
	
Version 3.0, Revision 2 Changelog
*********************************************************

	Final Fantasy 1
	
		  * Significantly increased Gold rewards for defeated creatures.  There will be enough
		    gold to make some additional weaponry purchases and the like, especially if you take
			a Master along ;-)
			
		  * Changed the algorithm that drives strong HP and MP increases.  A strong HP gain yields
		    (STA / 4) + 5 to 15 HP (changed from STA / 4 + 8 to 13.  A strong MP gain yields
			(INT / 4) + 0 to 6 MP (changed from INT / 4 + 7 to 9), and a weak MP gain yields
			(INT / 8) (down from INT / 4)!  Therefore, strong HP gains show more variance, 
			and MP gains are about half as much as they used to be!  Lower level characters,
			and especially those with low INT scores, will feel the MP pinch.  Don't expect your 
			Master to gain many MP, ever.
			
		  * Sages spell level progression was unduely harsh in revision 1.  It is now
			1/ 4/ 8/ 12/ 18/ 25/ 33/ 42.
			
		  * A couple of spells were tweaked:  Dia now costs 7 MP.  Pain now costs 6 MP.  Aero now 
		    does a bit more damage.
			
		  * One minor (albeit helpful) treasure chest swap.
			

	
Version 3.0, Revision 1 Changelog
*********************************************************
	
	Final Fantasy 1
		
		  * Almost all character sprites have been modified, and now look much more like members
		    of their professions.  
			
		  * Rebalanced classes due to feedback.  Here are the changes:
				Knight: Begin with 35 HP, 24 Str, 5 Agi, 1 Int, 16 Sta, 5 Luck.
				Rogue: Begin with 32 HP, 13 Str, 16 Agi, 1 Int, 6 Sta, 15 Luck.
				Monk: Begin with 45 HP, 12 MP, 8 Str, 12 Agi, 11 Int, 7 Sta, 12 Luck.
				Sage: Begin with 20 HP, 25 MP, 2 Str, 6 Agi, 15 Int, 4 Sta, 18 Luck.  
					Level up: -2 Int and +1 Luck every 8 levels.  Spell progression 
				Enchanter: Begin with 25 HP, 10 MP, 8 Str, 13 Agi, 13 Int, 5 Sta, 11 Luck.
					Level Up: -1 Str every 8 levels.
				Archmage: Begin with 30 HP, 22 MP, 4 Str, 10 Agi, 16 Int, 6 Sta, 12 Luck
				Paladin: Begin with 40 HP, 5 MP, 18 Str, 7 Agi, 8 Int, 20 Sta, 1 Luck.
					Level Up: +1 Agi every 8 levels.
				Ninja: Begin with 27 HP, 5 MP, 9 Str, 18 Agi, 5 Int, 2 Sta, 20 Luck.
					Level Up: +1.5 Int every 8 levels.
				Master: Begin with 33 HP, 12 Str, 10 Agi, 6 Int, 15 Sta, 9 Luck
				Ranger: Begin with 36 HP, 8 MP, 14 Str, 10 Agi, 8 Int, 11 Sta, 9 Luck
					Level Up: +1 Sta every 8 levels.
				Priest: Begin with 28 HP, 20 MP, 10 Str, 3 Agi, 18 Int, 12 Vit, 5 Luck
				Battlemage: Begin with 24 HP, 10 MP, 12 Str, 4 Agi, 12 Int, 10 Vit, 12 Luck
					Level Up: +1 Sta every 8 levels.

		  * The Sage also receives a new spell level progression: 1/ 4/ 9/15/21/28/38/50.  The
		    Sage was admittedly wildly overpowered in v3.0, and now will not steamroll the 
			opposition so easily.		    
	
	
Version 3.0 Changelog
*********************************************************

	Final Fantasy 1
	
		  * Your four party members may choose from among 12 classes now.  They will not 
		    change classes throughout your adventure.  A short description of those 12 classes
			are as follows:
			
			  o Primary warriors:		(They focus almost entirely on physically dominating opponents)
					Knight:		Excellent equipment.  Strong attack and defense, moderate speed.  
					            No magic.
					Rogue:		Supremely fast.  Decent defense, excellent luck-based magic 
					            resistance.  No magic.
					Master:		Tremendously powerful while unarmed.  Constant defense bonus.  Very 
					            low magic resistance. A few Monk-based abilities.
					
				Secondary warriors:		(Above-average fighters with supplemental magical capabilities)
					Paladin:	Holy Knight.  Highest defense.  Slower than Knight, but casts 
					            healing magic.
					Ninja:		Very fast.  Decent with attack magic.  Low defense, but evasion 
					            is high.  Low magic defense.
					Ranger:		Good at all tasks, but excels at nothing.  Slightly better fighter 
					            than caster.
					
				Secondary spellcasters:	(Above-average casters with at least one glaring physical weakness)
					Enchanter:	Offensive physically (speedy and lightly armored), but specializes 
					            in healing and buffing allies.
					Battlemage:	Defensive physically (heavily armored and slow), but casts offensive 
					            attack magic and warding magics.
					Monk:		Best unarmored (but a cloak always helps).  Decent with weapons or 
					            unarmed, and is quite effective with many types of magic (excluding 
								most direct attacks). 
					 
				Primary spellcasters:	(Their magic is extremely powerful, but have serious physical limitations)
					Priest:		These casters keep their allies alive.  They are defensive specialists.
					Archmage:	They can cause serious pain to their enemies.  They specialize in 
					            area-effect attacks.
					Sage:		They can cast almost all known spells, but are exceptionally frail 
					            due to their single-minded magical focus.

			
		  * Some items have been moved.  A few have been tweaked. In particular, all Armlets 
		    have been replaced.
			
		  *	Bahamut's reward, replacing the Class change, is instead a +50 HP bonus for all 
		    party members.
			
		  * The Quake spell now does damage instead of dealing instant death.  The enemy's 
		    Earthquake ability is still instant death, however.

	
	
Version 2.2 Changelog
*********************************************************

	Final Fantasy 2

		  *	The times that spells become available should be more balanced. In particular,
		    Berserk, Toad, and Blink are available later, and Slow, Sleep, and Haste are
			available more soon.  
		
		  * The extremely rare spells Break, Stop, and Confuse are not as rare anymore.
		  
		  * A few spell shops have been tweaked.  Most notably, Blink and Fog are no longer
		    for sale.  Sleep and Slow are now purchasable, Haste is available in shops, and
			very late in the game you may purchase Osmose.  Sleep and Slow sell for much
			less than they used to be, to compensate for this.
			
		  * Sap is now more powerful than Osmose.  As it should be...
		  
		  
	Final Fantasy 1:

		  * The Mute spell was confirmed to not silence characters, but paralyzed them 
		    instead when enemies succeeded in affecting them.  Thus, the Mute spell has been
			removed from all enemies' AI.
			
		  * The Load game screen only showed 3 HP/MP digits.  It now shows 4 HP/MP digits as
		    it should.
			
		  * A group of monsters consisting of 2 Death Machines and at least 2 Prototypes would
		    overflow the 16-bit Experience reward, and would therefore yield a paltry amount of
			experience.  The Experience rewards for these two enemies has been adjusted to
			sidestep this bug.
			
		  * Speaking of the Death Machine, it has been renamed for all you nostalgic types...
		    to WarMECH.
			
		  * WarMECH is now encounterable on the fifth floor of Tiamat's Floating Castle.  Again.
		  
		  * Soul of Chaos enemies now award slightly more experience.  Big Eyes give more EXP
		    and gold.  
			
		  * The Sahagin Queen is less likely to use Acid Rain (that's deadly to a 35th level 
		    party).  The Devil Wizard has less Intellect.  Their Flare was just too wicked 
			before... Also, the Skuldier is less cowardly than before (it's undead after all).
		  
		  * Stat items now only increase their respective stats by 1.  No more reloading to get
		    +2 or +3 bonuses... sorry power gamers ;-(
			
		  * A bug with Intellect was determined in which equipment was able to increase Int over
		    255, overflowing its byte.  This has been fixed; Intellect is properly capped at 255.
			
		  * Evasion is now gained at a rate of +1 per level for all characters.  Before, Evasion
		    would increase at level up ONLY if they had also gained Agility that level.
			
		  * The Inn now properly heals party members by +9999 HP/MP.  The Cottage has the same
		    effect as sleeping at an Inn.  Tents now heal +400 HP and restore +150 MP, and
			Sleeping Bags recover +150 HP.
			
			
		  
		  
		  

Version 2.1 Changelog
*********************************************************

	Final Fantasy 1:

		  * Sidestepped the Protera bug as found by Vertigo 1.  When a monster casts Protera and
		    there are more than 6 monsters present, it caused the game to freeze.  Dark Fighters 
			now may only appear in groups of six or less.
		  
		  * Many weapons and armors are re-valued.  In almost every case, this resulted in lowered 
		    purchase prices (and selling prices).
			
		  *	Fixed a couple of textual display issues.  When a character is paralyzed during
		    battle, their name renders as "Stunned" rather than "Paralyzed" so you can see 
			the character's HP.  Also fixed is the battle Equipment listing displays the 
			item quantities clearly.
			
		  * After casting the Comet spell, the caster now returns to the party lineup properly.
		  
			
			

Version 2.0 Changelog
*********************************************************

	Final Fantasy 2:

		  *	Weapons and magic levelling are hopefully balanced now.  Magic is easier 
		    to level, weapons take a fair bit longer.
		  
		  *	Practicing a weapon or spell always increases a character's skill, even 
		    if the monster attacked is significantly weaker than the character.
		  
		  * Fixed a display bug concerning the number of hits connected when a character 
		    is using a shield.
			
			  If a character used a weapon in their primary hand, and a shield in their 
			  secondary hand, they struck with the shield, and if they hit did no damage. 
			  This has been corrected.
			  
			  This bug still is in effect if the character uses a weapon in their secondary 
			  hand, and a shield in their primary hand.
		
		  * Monsters take double damage if vulnerable to a spell's element.  This is 
		    reduced from x4 damage. Don't worry, this is still *plenty* of damage.
		  
		  * If an elemental weapon strikes a vulnerable monster, its Attack rating is 
		    increased by 25 (increased from 20).
		  
		  * If a weapon which has an affinity for damaging a specific family of monster 
		    hits that kind of monster, its Attack rating is increased by 25 (increased 
			from 20).
		  
		  * Strength increases more often. The chance was (number of "fight" 
		    selections / 45), and it is now (number of "fight" selections / 32).
		  
		  * Agility increases are more regulated- more likely early in the game and less 
		    likely later on. Before, a random number was rolled between 0 and 255, and if 
			that was lower than a fourth of the character's Evasion, Agility increased. 
			Now, the random number rolled is now between 0 and 250, and the Evasion is a 
			little less important in determining increase.  Base chance to increase Agility 
			is 2.0%, and maximum chance is 6.8%.
		  
		  * Intellect increases more often. The chance was (number of black magic 
		    castings / 25), and it is now (number of black magic castings / 16).
		  
		  * Spirit increases LESS often. The chance was (number of white magic castings / 15),
		    and it is now (number of white magic castings / 20).
		  
		  * MP increases more often. The chance should be about 25% more likely than it was 
		    before.
		  
		  * When a character gains HP, the increase is halved. The increase is (STA / 2). 
		  
		  * Magic evasion gains take a bit longer. The threshold to gain Magic evasion 
		    was 99, and it is now 159.
		  
		  * Characters start with different stats. 
		  
		  * NPCs also begin with different stats, and should be more balanced with the 
		    party when you meet them.  Leon and Gordon also join the party already equipped 
			with spells.
		  
		  * Weapons, armor, and spells have been rebalanced.  Enemy direct damage spells will
		    be a bit more dangerous and require more planning to thwart.
		  
		  * Monster stats have been modified slightly to moderately.  Expect that the final 
		    bosses will not go down with a couple of well-placed elemental spells.
		  

	Final Fantasy 1:
	
		Version 2.0: New Features
		
		  * Samurai is recast as a Rogue. Their arsenal has changed slightly, but still cast 
		    the same spells (except Slow has been swapped in for Blizzard). Of course Ninjas 
			are still the same old Ninjas :-)
		  
		  * There have been several slight tweaks to the starting stats and early level ups 
		    for each class. In particular, I felt that Red Mages received no love in early 
			level ups, and so I fixed this.
		  
		  * Accuracy equation has been changed slightly.  It is now
			  o Attackers Accuracy - Defender's Evasion + 120 = chance to hit out of 161.
			  o The chance to hit is 10% minimum, and 90% maximum.  
			  o The base chance to hit is 75%, ie when Attacker's Accuracy and Defender's 
			    Evasion are equal. This is increased from 67%.
			  
		  * Spells that grant bonuses to Attack and Defense are now limited in their 
		    stackability.  The cap on the bonuses was 255 before, now the cap is 50.  No more 
			one-shotting Soul of Chaos bosses.
		 
		  * Damage spells inflict much more randomized damage.  Damage is between 1/2 to 3/2 of 
		    spell's base power, before applying resistances.  Luck and Intellect play an even 
			larger part in the equation. Of course, this goes for enemies and allies.
		
		  * The status screen now shows a character's number of strikes per round and their 
		    magic defense.
		  
		  * The chance to be attacked in several dungeons has been tweaked slightly.
		  
		  * Chaos Temple level 5 now has very interesting, dangerous, and rewarding encounters.
		  
		  * Astos' Northwest Castle now has numerous Undead-themed random encounters. No walking 
		    around this haunted castle with impunity!
		  
		  * The Sages' Staff has been realigned, and is now a White Wizard only staff named the 
		    "Holy Staff". It is pretty awesome, and it *is* rare.
		  
		  * The more powerful restorative items have had their prices increased dramatically.
		  
		  * Staves in general are more useful. Defensive type weapons give bonuses to Evasion.
		  
		  * Elixirs and Megalixirs drop less often.
		  
		  * The Paladin can now cast Curaga.
		  
		  * The Hermes' Shoes now cast Haste as advertised. This was an issue in v1.2, as they 
		    used to cast Temper. 
		  

Version 1.2 and prior Changelog
*********************************************************
		  
	Final Fantasy 1

		  * Fighter/Knight has been renamed to Knight/Paladin, and Thief/Ninja has been renamed 
		    to Rogue/Ninja.
		  
		  * Knight/Paladin is more defensive than offensive. Rogue/Ninja is a lightning fast 
		    assault trooper.  Monk/Master is ever the unconventional, survivalist type.  The 
			White Mage/Wizard is the healer and defensive specialist, and can take quite a 
			beating too.  The Black Mage/Wizard is the undisputed master of the magical nuke, 
			and the Red Mage/Wizard can do a bit of everything, but only to a point.
		  
		  * Changes to starting stats for the character classes, and their developmental curves.
		  
		  * Item proficiencies have changed:
			  o Knights and Paladins cannot use most dark weapons, or weapons of cruelty.
			  o Rogues can use heavier swords as did the Thief, including some katanas. 
			    Ninjas cannot use axes. Both classes only wear light armor and cannot use most 
				conventional shields.
			  o Masters can use some katanas, if that is to your liking.  Nunchukas are useful 
			    for a bit longer in this game.
			  o Black Mages cannot use the best daggers.
			  o White Mages and Wizards are proficient with almost all armor, and their 
			    hammers have been upgraded quite a bit.
			  o Red Mages now are more limited in the weapon choices, but can use a bit more 
			    armor.
		
		  * All of the classes possess at least some magical ability:
			  o Knights gain certain level 1-4 White Magic spells, and Paladins can learn 
			    up to level 5 White Magic spells.
			  o Rogues can learn certain level 1-4 Black Magic spells, and Ninjas extend 
			    that up to level 6.
			  o Monks learn special level 1-3 spells (might be classified either as Black or 
			    White), and Masters can learn level 4 spells.
			  o The spell ability of Red, White, and Black magicians have not been altered.
		
		  * Characters gain less HP and MP per level, but have a slightly better chance of 
		    increasing stats at level up.
		  
		  * Hit Rate increases at a different rate as stock FF1, and the rate changes after 
		    class change:
			  o Knight:	+2/level, Paladin +3/level
			  o Rogue: +3/level, Ninja +4/level
			  o Monk: +2/level, Master +2/level
			  o Red Mage: +2/level, Red Wizard +2/level
			  o White Mage: +1/level, White Wizard: +2/level
			  o Black Mage: +1/level, Black Wizard: +1/level
			  
		  * Likewise, Magic Defense increases at these rates:
			  o Knight:	+2/level, Paladin +4/level
			  o Rogue: +1/level, Ninja +2/level
			  o Monk: +2/level, Master +3/level
			  o Red Mage: +3/level, Red Wizard +4/level
			  o White Mage: +4/level, White Wizard: +5/level
			  o Black Mage: +4/level, Black Wizard: +5/level
			
		  * Revamped the Monk's defense algorithm. Monks now receive a defense bonus if 
		    no armor is equipped, based on their Stamina, Intellect, and Agility. Masters will 
			receive a constant defense bonus (regardless of armor), based on those same 
			statistics. Specifically:
			  o Monk/Master old algorithm: Armor (STA/2) + Helm (STA/8) + Gloves (STA/8)
			  o Monk new armor rating: (STA/2) + (STA/8), or Armor equipped
			  o Monk new helm rating: INT/4, or Helm equipped
			  o Monk new gloves rating: AGI/4, or Gloves equipped
			  o Master new armor rating: STA/2 + Armor equipped
			  o Master new helm rating: INT/8 + Helm equipped
			  o Master new gloves rating: AGI/4 + Gloves equipped
			  
		  * White Mages and Monks gain a +5 Attack bonus when using weapons.
		  
		  * Comprehensive changes to weapons, armor, magic, monsters, experience curve, etc.

		  * Comprehensively reworked all monster's Hit Rate and Evasion stats, and realigned 
		    the Evasion statistic for all character classes. Obviously, Rogues and Monks are 
			the best at Evasion!

		  * Shops are completely realigned, and many shops sell more than five items!

		  * Direct damage magic increases in power much more smoothly.  The nitty gritty: 
		    The damage used to increase in a stair-step manner, adding 1 to the multiplier 
			to damage every 10 Intellect points. Now, the multiplier increases every 2 
			Intellect points, but each "stair" is less steep to make up for the added number 
			of "stairs".
		  
		  * Some magic has been swapped out for other more interesting spells. 
		  
		  * Did I mention that many changes have been made to the monster's stats? They are 
		    significantly tougher.  The farther you go in the game, the more you will realize 
			that they will not go down with a couple of well-placed sword blows.
		  
		  * Soul of Chaos bosses have been actually demoted in power a bit to make them 
		    possible to defeat, given that you will reach them at a lower level than you might 
			have otherwise in stock Dawn of Souls.
		  
		  * Every monster that you beat may drop an item. As you beat new monsters, make sure 
		    you visit the bestiary to see what you might earn with repeated victories. You 
			can even earn the previously unattainable Angel's Ring!
		  
		  * The gold earned from defeating most foes is significantly lowered. You will 
		    earn a much greater percentage of your gold, especially in the early to mid 
			game, by finding treasure chests in the main storyline.  Gold management will be 
			key to early advancement.
		  
		  * Minor adjustments to the AI of various monsters. For instance, Goblin Guards now 
		    cast some magic and Yellow Ogres don't run as often.

		  * Minor adjustments to where monsters may appear in the game.		  
		  
		  * When striking a monster prone to the elemental or racial properties of a 
		    weapon, the bonus to attack power has increased from 4 to 25. Use weapons that 
			exploit the weaknesses of your enemy, especially in the early to mid game!
		  
		  * All critical hits gain an additional 50% bonus to attack power (previous bonus 
		    was 25%).
		  
		  * Direct damage magic has been realigned slightly.  The most powerful spells 
		    (Firaga, Thundaga, Blizzaga, Diaga, Holy and Flare) grow in power faster. 
			The lower powered spells (Fire, Thunder, Blizzard, Pain, and Dia) have a lower 
			base damage, making them initially less powerful.
		  
		  * Dia family spells effect evil and demonic creatures as well as the undead. 
		    Yes, it will even work against Garland and Astos! It also works against the 
			FF4 elemental fiends.
		  
		  * Temper increases Attack by 25. Zeal increases Attack by 16 for all allies.  
		    Saber increases Attack by 25 and Hit Rate by 30.
		  
		  * The White Magic Rally spell now cures the Mute condition.
		  
		  * Ninjas may cast the Level 6 Black Magic spell Death.
		  
		  * Removed the 255 cap for damage-per-hit.  The code actually limited each hit 
		    to 255 damage.
		  
		  * Soul of Chaos bosses now correctly award experience; they didn't in previous 
		    versions due to a hard-coded conditional check.
		  
		  * Golden and Silver Apples, as well as Soma Drops now increase HP and MP beyond 
		    999.
		  
		  * Characters kneel in battle when they have less than 1/5 HP.  Previous threshold 
		    was 1/10 HP.
		  
		  * Removed the 2,000,000 experience cap, allowing for the full development of
		    your characters with my experience curve.
		  
		  * Removed the 999 cap for HP and MP.  The cap is now 9999, if you can ever get 
		    that many Golden and Silver Apples.
		  
		  * Raised the cap for Strength, Agility, Stamina, Intellect, and Luck to 255.  
		    Previous cap was 99.
		  
		  * Removed the 255 cap for a character's base Hit Rate. Extraordinarily high 
		    level Ninjas will appreciate this.
		  
		  
		  

Known issues
*********************************************************

	Final Fantasy 1: 
		  * The Character Class select screen does not display well, but is clear of
		    all show-stopping bugs.  The last 6 classes do not display correctly,
			either as avatars or in the list.  When selecting them, pay attention to
			the description at the bottom of the screen.
		
		  * In the Bestiary, the traveling music and battle music play simultaneously.

			

To convert your Final Fantasy 1 and 2: Dawn of Souls ROM
*********************************************************

The following applies this and all future releases of the Ludmeister's Mod of Balance.

0. First of all, you will need to obtain a clean GBA ROM of Final Fantasy 1 and 2: 
   Dawn of Souls. You are on your own for this step, as it is illegal to provide ROMs
   of copyrighted material. There are sites that do provide this ROM though, and you 
   should be able to obtain it.

1. When you get it, make a backup of it if you would want to play the stock version, 
   play another mod, or, in case I post an updated version of the mod here... I am not 
   going to make version 1.0 to "version whatever" patches for my mods, for instance.
   
2. Download the newest version of Ludmeister's Mod of Balance. 
  
3. Use the IPS patching program of your choice to apply the .ips patch to the 
   correct ROM.  As I use IPS XP (http://home.arcor.de/minako.aino/ipsXP/) to
   create my patches, I recommend using this program to patch your ROM.
	    
4. I hope you enjoy it!


*NOTE*

So here I am violating my own rule.  Since this patch represents a major difference 
from the gameplay of Final Fantasy 1, having removed the class change which was one
of the most innovative things about the game, I elected to make a version 2.2 to 3.3
patch.  You may elect to apply the v2.2 patch to a stock ROM, and then apply the
v2.2 to v3.3 patch at a later time if you so choose.



