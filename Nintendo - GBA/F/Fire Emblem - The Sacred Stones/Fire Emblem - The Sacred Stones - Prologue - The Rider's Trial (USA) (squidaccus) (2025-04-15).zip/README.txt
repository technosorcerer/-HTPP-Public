Patch as you would any other FEGBA rom. I use FLIPS for this, personally.

Important notes:
Hold L to skip combat animations in player phase. Hold A to skip them in enemy phase, and L+A to not skip them while still speeding up enemy phase.
The avoid formula was adjusted and all weapons have higher hit, with most having lower weight too. The short bow is 1-2 with no crit.
Alyne is your only loss condition. The other three retreat on defeat.
Select toggles the danger radius. Any crit below 10 becomes 0.

If anyone is missing from the credits whose work was utilized in this project, please let me know.
CREDITS:

Portraits: squidaccus

Patches: Agro, Brendor, Leonarth, aera, 7743, gamma, circleseverywhere, Tequila, Vesly, Hextator, Zane, tiki, Scraiza, Alusq

Music:
Army of Agustria: SurfingKyogre
Night of Fate: Azula
Anxiety: Alusq

ASM: Venno, masterofcontroversy

Battle Animations:
Cavaliers (M): SALVAGED
Cavaliers (F): SALVAGED, CelestiaHeart
Paladins (M): SALVAGED, Leo_Link, Pikmin1211, The_Big_Dededester
Paladins (F): SALVAGED, Leo_Link, Flasuban, The_Big_Dededester
Scout (M): eCut, Pikmin1211, Maiser6
Wyvern Novice: eCut, Flasuban
Soldier (M): Alusq
Myrmidon (F): Vilk
Archers: DerTheVaporeon, Flasuban

Map Sprites:
Cavaliers: SALVAGED
Paladins: Leo_Link, DerTheVaporeon
Wyvern Novice: Flasuban
Fighter: ZoramineFae
Soldier: Feier, Flasuban

Misc:
Tileset (Village): Flasuban, N426, ZoramineFae, Venno
Status screen: Jiege
Battle UI: Cynon
Hit/Dmg/Crit text: ExoBlitz120