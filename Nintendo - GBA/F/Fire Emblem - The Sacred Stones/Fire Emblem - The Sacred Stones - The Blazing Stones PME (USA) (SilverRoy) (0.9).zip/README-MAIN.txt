--Fire Emblem - The Silver Wolves Red--
---------------------------------------
By SilverRoy

Original Topic Link:
https://feuniverse.us/t/fe8-released-fire-emblem-the-blazing-stones-pme-v0-9-dl-available-feat-promotable-dancers-bards-manaketes/28590

Made on FEBuilder by 7743.
Using FE8: Blazing Stones V1.6 as a base, hack made by OK_Dude (used with permission).

Thank you for downloading this hack, and I hope that you enjoy it!
Remember that this hack was made to be free to use, without any wish for financial gain.
If you have paid money to download these files, you have been robbed!

Use a .ups file patcher (like NUPS) to patch a vanilla, USA Fire Emblem 8 Rom.

Two patches are available: 'Default' and 'Flashy'.

'Flashy' patch makes it so that the last landed hit against a boss always shows critical animations.
'Default' patch, in turn, is the standard one with the original, organic critical animation rules.
No mechanical changes exists between patches, it's only for pure visual preference.

/Work In Progress\


--------------FINAL THANKS--------------
----------------------------------------
Huge thanks to everyone in FEUniverse, as well as it's Discord server, for helping me with the development of this hack.

Cheers!