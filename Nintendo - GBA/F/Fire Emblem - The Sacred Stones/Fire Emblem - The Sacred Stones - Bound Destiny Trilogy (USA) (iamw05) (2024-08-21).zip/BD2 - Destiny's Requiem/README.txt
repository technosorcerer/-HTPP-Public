Thank you for downloading Bound Destiny 2: Destiny's Requiem!

Before you play, it's highly recommened to play the first game, Bound Destiny.

You can find a download for Bound Destiny here: https://drive.google.com/file/d/12UrPkyKVassMPifSNx-9deefqfJmF1Aq/view?usp=sharing

-=Installation=-:

WHAT YOU NEED:

- Some way to apply a .UPS patch:

	Option A: Online Patcher at https://www.marcrobledo.com/RomPatcher.js/

	Option B: upset by Near: https://www.romhacking.net/utilities/677/

- An unmodified english ROM of Fire Emblem: The Sacred Stones

- An emulator, preferably mGBA: https://mgba.io/

HOW TO PLAY:

1. Launch 'upset', and specify the source file as BD2 - Destiny's Requiem.ups

2. Select your unmodified English ROM of Fire Emblem: The Sacred Stones as the destination file

3. Click Patch.

4. Your FE: Sacred Stones ROM has been converted to Destiny's Requiem.

5. Launch the converted ROM with mGBA.

Have Fun!

-= Transfer Tutorial =-

Destiny's Requiem supports clear data transfers from the original Bound Destiny.

Generate a transfer code by visiting the second house from the left of the arena
in the epilouge chapter. Carefully write down the two codes that are given.

When beginning a new game in Destiny's Requiem, select "BD1 Transfer Codes"
on the top menu and input the two codes you were given in Bound Destiny.

Unmissable characters who reached level 30 in Bound Destiny will begin
Destiny's Requiem with a bonus +5 HP and +2 STR/MAG/SPD/SKL/LCK/DEF/RES.

The same bonus will be applied to the following characters as long as they
were purchased in the epilouge specialties shop:

- Grovyle
- Staraptor
- Swampert
- Mightyena

Additional rewards can be earned by completing the following tasks:

- Generate a transfer code while having at least 10,000 Gold
- Clear the game on Hard mode
- Clear the trial map "Worthy Inheritance"

-=More Info=-

Recruitment Guide: https://docs.google.com/document/d/15eZpdCniRL-rz1w3g5q66Kq6ECiXWS4LFzD261MxKbI/edit?usp=sharing

Character Art (CONTAINS SPOILERS): https://drive.google.com/drive/folders/1dQb6lRr1MlkLAzLvSdxBVf4vrlIbxIV-?usp=sharing

Tier List Maker: https://tiermaker.com/create/fe-destinys-requiem-units-15800368