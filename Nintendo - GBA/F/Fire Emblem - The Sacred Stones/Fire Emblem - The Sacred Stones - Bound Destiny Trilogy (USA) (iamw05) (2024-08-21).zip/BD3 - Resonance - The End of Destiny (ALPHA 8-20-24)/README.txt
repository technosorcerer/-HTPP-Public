Thank you for downloading Bound Destiny 3: Resonance - The End of Destiny!

Before you play, it's highly recommened to play the previous games, Bound Destiny & Destiny's Requiem.

You can find a download for Bound Destiny here: https://drive.google.com/file/d/12UrPkyKVassMPifSNx-9deefqfJmF1Aq/view?usp=sharing

As well as a download for Destiny's Requiem here: https://drive.google.com/file/d/1QSEKt4-s-8tuJ2lgBe11-886nxQw2Xaf/view?usp=sharing

-=Installation=-:

WHAT YOU NEED:

- Some way to apply a .UPS patch:

	Option A: Online Patcher at https://www.marcrobledo.com/RomPatcher.js/

	Option B: upset by Near: https://www.romhacking.net/utilities/677/

- An unmodified english ROM of Fire Emblem: The Sacred Stones

- An emulator, preferably mGBA: https://mgba.io/

HOW TO PLAY:

1. Launch 'upset', and specify the source file as BD3 - Resonance TEOD.ups

2. Select your unmodified English ROM of Fire Emblem: The Sacred Stones as the destination file

3. Click Patch.

4. Your FE: Sacred Stones ROM has been converted to Resonance: The End of Destiny.

5. Launch the converted ROM with mGBA.

Have Fun!

-= Accessing the BD Demo =-

Resonance contains a special vertical slice demo prepared specially for FEE3 2024.
To play the demo chapter, begin a new game and select "Chapter Select" from the
top menu. Inside the chapter list, Select "Demo - FEE3 2024".

The demo chapter is designed to be played multiple times. Experiment with different
characters and equipment to see how effectively the map can be cleared.

Lucia and Tarkha have increased stats relative to the other characters in the demo.
Deploy them if you're having trouble clearing the map.

-= Transfer Tutorial =-

Resonance supports clear data transfers from Bound Destiny 2: Destiny's Requiem.

Generate a transfer code by visiting the the unlocked yellow house underneath
the barracks in Sanctuary after clearing the main story.

When beginning a new game in Resonance, select "BD1/2 Transfer Codes"
on the top menu and input the two codes you were given in Destiny's Requiem.

Characters who reached level 20 in Destiny's Requiem will begin
Resonance with a bonus +5 HP and +2 STR/MAG/SPD/SKL/LCK/DEF/RES.

Additional rewards can be earned by completing the following tasks:

- Generate a transfer code while having at least 10,000 Gold
- Clear the game on Hard mode

-=More Info=-

Recruitment Guide: N/A

Character Art (CONTAINS SPOILERS): https://drive.google.com/drive/folders/1UJFzznejGba3rcPVn37q6uepXb3NKjEs?usp=sharing

Tier List Maker: https://tiermaker.com/create/resonance-the-end-of-destiny-units-15800368