First off thank you for choosing to 
play our game!  It was tireless effort of 
that took almost 4 years.
We hope you enjoy!

TO INSTALL:
You need to get a fresh ROM of Fire Emblem 8: The Sacred Stones (US) and patch the clean ROM using an UPS patcher (e.g. NUPS).  From there you can simply run the game and boom your done! :D

Bug workaround:
You can now hold L to turn off the battle animations in case of animation breaking events!

Some known bugs:
- If you get the cursor sounding like it's scrolling toggle to the next unit
- Similar to the bug above but more game breaking is when the cursor looks like it's selecting
on a tile without your unit on it and moving it will crash the game.  To fix this simple just toggle to 
the next unit without moving the cursor and it will work.


All assets that are not our own belong to their respective creators.  Credit goes to them. (Credits list is posted on FE Universe and there is a Credit's list in the credit screen at the end of the game as well.