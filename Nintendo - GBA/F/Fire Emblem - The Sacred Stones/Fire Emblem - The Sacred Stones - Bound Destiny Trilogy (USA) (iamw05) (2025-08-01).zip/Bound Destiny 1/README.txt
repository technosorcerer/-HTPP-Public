Thank you for downloading Fire Emblem: Bound Destiny!

-=Installation=-:

WHAT YOU NEED:

- Some way to apply a .UPS patch:

	Option A: Online Patcher at https://www.marcrobledo.com/RomPatcher.js/

	Option B: upset by Near: https://www.romhacking.net/utilities/677/

- An unmodified english ROM of Fire Emblem: The Sacred Stones

- An emulator, preferably mGBA: https://mgba.io/

HOW TO PLAY:

1. Launch either UPS patching option, and specify the source file as Bound Destiny 1.ups

2. Select your unmodified English ROM of Fire Emblem: The Sacred Stones as the destination file

3. Click Patch.

4. Your FE: Sacred Stones ROM has been converted to FE: Bound Destiny.

5. Launch the converted ROM with mGBA.

Have Fun!

-=More Info=-

Recruitment Guide: https://docs.google.com/document/d/1uYTWoLN9ctY0i2NqGkikMxGW67eRj-BExieVwsoKTdc/edit?usp=sharing

Character Art & Full Res CG's (CONTAINS SPOILERS): https://drive.google.com/drive/folders/1Kn2bXD1M5LErFwwRrBoFokBvXK49FrFr?usp=share_link

Tier List Maker: https://tiermaker.com/create/fe-bound-destiny-units-15800368
