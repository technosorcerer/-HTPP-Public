Thank you for downloading Fire Emblem: Emulation Theory (SUPER DELUXE)! This readme contains useful information to read before playing the hackrom. I hope you enjoy!

 Index

1. Contents
2. Hackrom summary
3. QoL changes
4. Known, unintentional bugs
5. Spoiler stuff
  a. Secret events
  b. Optional dialogue
  c. Skill info
6. Credits

############################################################## 1. Contents ##############################################################

The compressed file contains three files:

- The .ups hackrom, to be patched using a vanilla, US version of Fire Emblem: The Sacred Stones.
- A .txt file, titled "A message": It serves as an introduction to the hackrom. Note that the message is already part of the Emulation Theory experience.
- This readme!

############################################################## 2. Hackrom summary ##############################################################

This is a crossover, story-driven metagame that follows Princess Eirika of Renais as she discovers the truth about Magvel and the Fire Emblem GBA games. Can she make it back home, before it and the rest of the worlds are destroyed?

That's the premise of the hack. It is (technically) 34 chapters long, and has two main difficulties: Normal and Hard.

Normal mode is the intended way to play the game. It is the one that had the most testing, and it dictates the balance of the units. It can be completed.

Hard mode not only has increased enemy stats, but also every single unit has a 25 hit bonus! Money gained is also mostly halved throughout the hackrom.
Each world has its own (prejudicial and beneficial) special hard mode changes. For example, the FE7 maps may have more of those pesky Pegasus Knights the Vanilla game likes so much...
This mode is experimental, and highly untested. The first chapters are actually beatable, and I'm sure the rest are, but those weren't tested for the release.

This hack does not include any ambush spawns. Even in The Binding Blade maps.

This hack has the skill system! There are three types of skills:

- Personal skills, which are granted to most of your own units and most bosses, too.

- Prowess skills, which are granted only to unpromoted allies, at certain levels.
Units in fighting class (that is, classes that can defend themselves) get theirs at level 17.
Units in support classes (priests, troubadours, dancers) and Manaketes get theirs at level 15.

- Class Mastery Skills, which are granted to ALL (friends and foes alike) promoted units at level 10.

When it comes to weapons, most remain unchanged. With the exception of the Blade swords, that now has the Weary Fighter skill (which prevents double attacks from ever occurring, only if you're able to retaliate (that is, at one-range)).

############################################################## 3. QoL Changes ##############################################################

Multiple Quality of Life changes are introduced in order to make the experience better:

- Battle animations are now faster overall, and can be sped up by pressing the R button.

- Press select to see the danger zone.

- You can toggle between battle animations ON and OFF by holding the L button before a battle.

- Map battles now have the stats (hit, attack, crit...) displayed.

- You can now do actions after a support, or after attacking (this may cause some visual bugs)

- The Music Room and Support Room are now unlocked! But DO NOT enter the support room until after beating the game: it contains heavy spoilers of the game, both by displaying all future playable characters and the support conversations themselves can contain spoilers.



############################################################## 4. Known (unintentional) bugs ##############################################################

The main known bug is related to the Sacred Tomes (Forblaze and Aureola), and Zephiel's sword: these have weird, broken animations.

At the end of chapter 27, the intro cutscene will play again. This is unintentional, and there's no way to delete it. Skip it if you wish.



############################################################## 5. SPOILERS STUFF ##############################################################

Obviously, there are spoiler warnings for the entire game in this part.

###### a. SECRET EVENTS

There are some conversations that give you certain things if you deploy two units under certain conditions. These events can only be unlocked on certain parts of the game, on any of the maps on that part:

- Deploy Lilina and Nino in the same map on part 2 (except the chapter in which Lilina is recruited), then talk to Lilina with Nino.

- Reach A support between Lilina and Dozla, deploy them in the same map on part 3, and talk to Dozla with Lilina.

- Reach level 20 with Eirika in part 3 to access her promotion item earlier. She will get it at chapter 19 if you don't do so.

- Talk to Mark with Eirika in Chapter 19 (I'm not sure this one's even possible: let me know if you achieve this) 

- Talk to Lyn with Dorcas in Chapter 20, and keep the Lyn Mode Squad alive.

- Deploy Yoder, Dorcas, Rennac, Canas, Dayan, Perceval, Saul, AND The Messenger at the same time in Part 3 or Part 4 (Not counting the map where you can deploy everyone!), then talk to The Messenger with Dorcas.

- Reach A support between Gerik and Dayan, promote Gerik to a Nomad Trooper BEFORE chapter 23 (strictly before), deploy them in the same map on part 4 (Not counting the one where you can deploy everyone!), then speak to Dayan with Gerik.

###### b. OPTIONAL DIALOGUE

There are several optional dialogue that gives you nothing, but are interactions between the characters. If you don't want to miss those, they are listed here (only listed are the ones that require you to deploy one non-forced unit). Note that I do not recommend deploying units you are not going to use, just to read these conversations.

- Perceval - Heath - Chapter 5

- Eirika - Franz - Chapter 8

- Thea - Mark - Chapter 13

- Gerik - Eirika - Chapter 14 (trigger the conversation before turn 7!)

- Eirika - L'arachel - Chapter 16

- Thea - Shanna - Chapter 17 (will trigger at the end of the chapter regardless, if Thea's alive)

- Canas - Eirika - Chapter 18

- Jose - Mark - Chapter 19

- Eirika - Nino - Chapter 20 (Make sure they can reach eachother at the start)

- Sue - Chapter 20 (You just need to deploy her)

- Eirika - Lloyd - Chapter 22

- Thea or Shanna - Messenger - Chapter 23 (You need to have both Thea and Shanna alive)

- Eirika - Zephiel - Chapter 23

- Leila - Hector - Chapter 23 (Optional way to recruit him)

- Messenger - Eirika - Chapter 24

- Leila - Eirika - Chapter 25

Some supports act different than usual, which will be documented here:

- Marisa/Saul and Rennac/Dozla will never go past C support in the story (but their conversations might...).

- Nino/Lilina can only grow their support via the secret event, and will never get above nor below a B support.

- Mark/Merlinus support will not grow naturally, instead it's unlocked via conversations in chapters 13, 18 and 24. If you miss one, you miss the next ones.


###### e. Skill information

As stated above, each unpromoted character gets a skill at level 17/12 (depending on the class). These are the unpromoted units with their respective skills:

- Eirika - Sol: Restore damage dealt as HP. (Skill % activation)

- Mark - Reposition: Allows unit to pull an adjacent ally to its opposite side.

- Franz - Chivalry: When foe is at full HP, attack and def/res +2.

- Nino - Paragon: Experience gain is doubled.

- Dorcas - Boon: Cure bad status effects at the beginning of each turn.

- Saul - Powerstaff: Get another action after using a staff. (Unlocked at level 12)

- Perceval - Resolve: When HP < 50%, gain 1.5x Str, Skl, & Spd.

- Heath - Desperation: If HP < 50%, double attacks occur immediately.

- Jose - Swordbreaker: +50 Hit/Avo when enemy has a sword equipped.

- Sue - Wind Disciple: +10 Hit and Avoid when HP is not at max.

- Lilina - Flare: Halve enemy resistance. (Skill% activation)

- Ephraim - Luna: Negates enemy defenses. (Skill % activation)

- Forde - Tantivy: +10 Hit/Avoid if there are no allies within 3 tiles.

- Kyle - Heavy Strikes: Add weapon weight to critical chance.

- Thea - Alert Stance: +15 Avo when defending.

- Canas - Seal Defense: Debuff opponent's Def by 6 after combat. (Recover 1/turn)

- Gerik - Swordfaire: +4 damage when equipping a sword.

- Tethys - Celerity: Movement +2.

- Marisa - Life and Death: +10 to damage dealt and taken.

- L'arachel - Holy Aura: Gain +1 damage, +5% hit, +5% avoid, +5% crit when using light. (Unlocked at level 12)

- Rennac - Pass: Can move through enemy units.

- Knoll - Tomebreaker: +50 Hit/Avo when enemy has a tome equipped.

- Dart - Aptitude: +20% to all growth rates.

- Zephiel - Voice of Peace: Enemies within 2 tiles deal -2 damage.

Next, these are the class skills everyone gets for reaching level 10 in their promoted/special classes.

- Great Lord (Ephraim) - Death Blow: +6 Attack when initiating battle.

- Great Lord (Eirika) - Bond: All allies within 3 tiles
recover 10% HP each turn.

- Paladin - Trample: +5 damage to
unmounted units.

- General - Barricade: Damage taken is
halved after first being struck.

- King - Spectrum Stance: +2 attack, speed, defense, and resistance when foe initiates battle.

- Hero - Foresight: Avoid the damage
from enemy Critical Hits and
Skill Activations.

- Swordmaster - Vantage: If HP < 50%,
strike first when attacked.

- Assassin - Galeforce: Move again after
attacking and defeating an enemy.

- Sniper - Hawkeye: User will
always hit the enemy.

- Nomad Trooper - Acrobat: All traversable
terrain costs 1 movement.

- Wyvern Lord - Nullify: Unit is protected
from all effective attacks.

- Wyvern Knight - Death and Life: Grants
+5 Str/Mag/Spd, -5 Def/Res.

- Sage - Tomefaire: +4 damage
when equipping a tome.

- Mage Knight - Opportunist: +4 damage
if the foe cannot counter.

- Bishop - Mercy: Enemies are left
with at least 1 HP.

- Druid - Lifetaker: Restore up to 50% HP after
attacking and defeating an enemy.

- Summoner - Devil's Pact: Immune to Devil Reversal. Curses the enemy with Devil Reversal. (31-Luck % chance of Devil Reversal).

- Tactician - Swap: Allows unit to swap positionswith an adjacent ally. They also get Gridmaster: Movement skills do not end your action.

- Rogue - Steal+: Unit can steal unequipped weapons and staffs if con>weight.

- Great Knight - Steady Stance: +6 defense when foe initiates battle.

- Great Lord (Roy) - Fiery Blood: +4 damage when HP is not at max.

- Great Lord (Hector) - Axefaire: +4 damage when equipping an axe.

- Manakete - Blood Tide: Atk and Hit +5 to adjacent allies.

- Warrior - Fury: +2 Atk/Spd/Def/Res. Unit takes 6 damage after combat.

- Berserker - Heavy Strikes: Add weapon weight to critical chance.

- Falcoknight - Quick Draw: +4 Damage when initiating battle.

- Valkyrie - Renewal: Restore 30% of max HP at the start of each turn.

- Dancer - Inspiring Tune: Refreshing a unit grants them +2 Pow/Def until the next turn.

- Solder - Lancefaire: +4 damage when equipping a lance. (Unlocked at level 20)

- Necromancer - Seal Resistance: Debuff opponent's Res by 6 after combat. (Recover 1/turn)


###### d. Extra...?

There are special, glitched weapons that are hidden throughout the whole game. Some have skills, and others break normal game conventions. 
There won't be a guide on how to get them, but they're not totally obscure. For some, you'll just have to know what a house really is...



############################################################## 6. Credits ##############################################################

Here are all the good people that helped, one way or another, to make this hack!

### General/Misc

- The crew that made FEBuilder! 7743, alongside others (I... think?)

- Intelligent Systems, naturally, for... You know, Fire Emblem for the Game Boy Advance.

- Gringe, from Serenes Forest, for the english translation of FE6! It was used at several times during development.

### Graphics

- The Github Repo!

- Lenh (I... Think?) For the FE6 cast recolored using FE8's colours.

- An unknown angel, for the FE7 cast recolored using FE7's colours. (If someone knows the author, please let me know!)

- Airavat, for specifically just the Brunnya recolor.

- Batima, for their Dragonstone+ item icon.

- Agro, for the sword cavalier map animation.

- Raspberry, for the axe hero map animation.

- RobertFPY, for the sword paladin map animation.

- Unknown, for the axe wyvern map animation (If someone knows the author, please let me know!).

- Blademaster, for the Axe General map animation.

- Marlon0024, for the FE7 Dragon battle animation.

- SHYUTERz for the Nergal repalette + Fix.

- TheBlindArcher, for the Wyvern Axe battle animations! (Wyvern Rider and Lord)

#### FEBuilder Patches

- Vesly and 7743. If I had to list every patch of them that helped me, we'd be here all day.

- Leonarth, for the 256 colour backgound and the less annoying fog.

- aera, for the switch animation ON/OFF and the deny deployment for preparations patches.

- circleseverywhere, for the danger zone, actions after talk/support, drumfix, HP bars (alongside Tequilla), convert text to chapter titles, and one tiny patch called the Skill System!

- Speaking of which: the folks of SkillSystem! Monkeybard & Black Mage for most of the skill icons; Blaze for Stances skill icons. And Tequila, Rossendale, StanH, Leonarth, Teraspark, sd9k, Kao, blademaster, Snakey1 for skills. This hack uses a custom build with few changes.

- Scraiza, for the "switch portrait images by class" and the NarrowFont.

- Stan, for the ExModularSave, Skip World Map Fix.

- Venno, for the "lose ranks upon promotion" patch.

- The lost souls that I forgot to include in this area, but surely made a patch that I used.
