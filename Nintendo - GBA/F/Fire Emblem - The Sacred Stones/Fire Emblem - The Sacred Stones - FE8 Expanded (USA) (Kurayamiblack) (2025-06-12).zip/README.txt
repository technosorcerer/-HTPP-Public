Mod by Kurayamiblack for "Fire Emblem 8: The sacred Stones" (U)

CONTENTS:
This mod was originally created for 2RN, but a 1RN mode was added for the fun of it.
Both are available in this directory.

Inside the "Behind the Scenes" folder, you will find:
- A Development Changelog
- A Script Changes log
- Credits for the mod's production and borrowed assets


THE SIMPLE IDEA:
FE8 Expanded is a project that strives to expand on the original Sacred Stones in as many ways as possible.
I hope you enjoy playing it, and please support the official release!


INSTALLATION:
For help installing these patches, please copy this link to FEUniverse into your browser and follow the instructions:
https://feuniverse.us/t/how-to-use-ups-files/8502
