Fire Emblem: The Sacred Stones Reloaded (or FE8Reloaded) is a hack made by Dennis el Azul to improve both graphics and mechanics of the game and give it a bit more of variety.
Fire Emblem 8 Reloaded was made thinking both in Iron man runs that want better graphics and to be use as a base for new hacks.
Fire Emblem 8 Heroes Crossover was made for fun, you have new characters, more challenging enemies (only a bit) and new backgrounds.
IF YOU DON'T KNOW WHAT HACK TO PICK, I recommend Fire Emblem 8 Heroes Crossover with Final Fantasy backgrounds. You can choose having the tiles or having the backgrounds. I worked hard porting those backgrounds to Fire Emblem and editing the background tables to make them fit.

This hack comes in different versions (choose only one):

FE8 Reloaded X including the original cast and the changes of the Heroes Crossover version. This version was created after FE8 Reloaded Heroes Crossover, play this if you want to play with the original cast of characters from Sacred Stones. Still the extra characters come from other Fire Emblem games and they include the new classes inspired in Fire Emblem Heroes.

FE8 Reloaded Heroes Crossover: This version includes changes in the mechanics:
- New classes and some changes in others (for example, trainees now move 5 instead of 4).
- Doubled the weapon triangle effectivity.
- Support points are gained by deploying units in the same map, and the bonusses are increased.
- Iron weapons price halved and preparation shop prices don't increase. More weapon abailability in the preoparation shop.
- Some weapons change, now the Levin Sword is available, you can purchase Frozen Lances (they make magic damage), short bows allows you to attack adjacent enemies (but they're not effective against flyers) and some spells have more range. Be careful, this also works for the enemy!
- More booty in the Tower and in the Ruins.
- More experience gain.
- You can re-promote units and restart their level to 1 (like in Fire Emblem Awakening).
Do you think this makes the game easier? Not at all!
- Enemies have +20% growth for health and +10% growth for the other stats! Also some bosses change and they can be very hard (be careful with Gheb).
- Remember the new enemy classes? Have fun with the witches.
- Some characters change, and more characters from other Fire Emblem games appear. Will include exclusive classes. You receive extra characters in chapter 4, some with exclusive classes (or can promote to exclusive classes), you don't need to use them if you don't want (exclude them in your Ironman runs if you wish).
- I added Final Fantasy backgrounds from Final Fantasy I & II Advance, Final Fantasy IV Advance and Final Fantasy V Advance.
- You can buy cheat weapons and the legendary or exclusive weapons of the game, they're separated by a stone that say "Cheat Codes" in the first map stores. They're great if you want to test something and you need to improve an unit fast.

FE8 Reloaded Heroes Crossover PVP: Now your friend can control the enemy units! There's a graphic bug when attacking with an enemy unit, but the game runs fine. Thanks to Circleseverywhere for the code, you can find it here: https://feuniverse.us/t/control-enemy-npc-units-fe8/1897

FE8 Reloaded X Chicken: Tired of revenants and entombed being very slow? They are now chickens!

CREDITS:

I thank the Fire Emblem community for creating and sharing their content for hacks. I also thanks the creators of FEBuilderGBA, thanks to their tool this hack was possible.

Anims used (got in https://emblem-anims.herokuapp.com/):

[T1][AXE][Brigand](Fe13)[M]{Leo_Link, Iscaneus}
[T1][AXE][Fighter](FE9 Repalette)[M]{Glenwing, MK404}
[T1][AXE][Pirate](DS-Style)[M]{DerTheVaporeon}
[T1][AXE][Pirate](DS-Style No-Bandana)[M]{DerTheVaporeon}
[T1][CAV][Cavalier](SALVAGED Edit)[F]{Flasuban, Team SALVAGED}
[T1][LNC][Soldier](Amelia)[F]{Spud}
[T1][MAG][Mage](Light Mage Long Hair Edit)[F]{Leo_Link, L95, flasuban}
[T1][MAG][Mage](Light Mage)[M]{Leo_Link, L95, flasuban}
[T1][MISC][Refresh](Dancer Tethys +FE7, Staff, Sword)[F]{IS, Circleseverywhere, Kao, Marlon0024}
[T2][LNC][Halberdier](Amelia)[F]{Spud, TBA, Black Mage, Temp, Wan}
[T2][LRD][Great Lord](Ephraim Infantry)[M]{Nuramon}
[T2][MAG][Custom Magi](Witch Repalette)[F]{Aruka, Kenpuhu, Orihara_Saki, Venno}
[T2][MAG][Sage](Yggdra Lute)[F]{Aruka, Kenpuhu}
[T2][MON][Demon](Bael - Queen)[U]{Seal}
[T2][MON][Demon](Custom Deathgoyle)[U]{Teraspark, L95}
[T2][SWD][Assassin](Ponytail +Bow)[F]{Keks_Krebs, Beccarte, SD9K}
[T2][SWD][Hero](Armored +Short Hair)[F]{Flasuban, Nuramon}
[T2][SWD][Hero](Armored)[M]{Nuramon}
[T2][SWD][Swordmaster](Marisa Alt RB)[F]{Red Bean, Marlon0024}
[T3][CAV][Master Knight](Eirika_s palette)[F]{St jack,Belle}
[T3][MAG][Necromancer](Generic)[M]{Eldritch Abomination, Shin19}
[T3][MAG][Necromancer](High Magus)[F](MrNight, DerTheVaporeon)
[T3][SWD][Custom Sword](Dread Fighter)[F]{Nuramon}
[T3][SWD][Custom Sword](Dread Fighter)[M]{Nuramon}
[T1][ARM][Knight](SALVAGED)[M]{Team SALVAGED}
[T1][CAV][Cavalier](SALVAGED)[M]{Team SALVAGED}
[T1][LNC][Soldier](FE10-Style)[M]{flasuban}
[T1][SWD][Mercenary](Armored +Axe)[M]{Alusq, Maiser6}
[T2][ARM][General](Shield v2 +Cape)[U]{TBA, DerTheVaporeon, Nuramon}
[T2][ARM][General](Vanilla +Weapons)[U]{IS, TBA, DerTheVaporeon, GabrielKnight, JPN}
[T2][FLY][Wyvern Lord](Armored)[U]{Nuramon}
[T2][SWD][Swordmaster](Marisa Alt RB)[F]{Red Bean, Marlon0024}
[T3][CAV][Master Knight][F]{St jack}
[T3][CAV][Master Knight][M]{St jack}
[T1][LRD][Lord](Ephraim-Style Alt)[F]{ZoramineFae, DerTheVaporeon, Pikmin1211}
[T2][LRD][Great Lord](Hector Brave)[M]{Nuramon}
[T1][FLY][Wyvern Rider](Vanilla +Weapons)[U]{IS, Mikey Seregon, Alfred Kamon, PrincessKilvas, Spud, Blue Druid}
[T1][LRD][Lord](Hector +Sword)[M]{IS, Vilkalizer, Zane Avernathy}
[T2][LRD][Great Lord](Hector Repalette)[M]{Temp}
[T2][MAG][Sage](Nino)[F]{Greentea, DerTheVaporeon}
[T2][MAG][Custom Magi](Nino Pale Flower)[F]{RedBean, Mikey Seregon, Marlon0024, yikes}
[T3][MAG][Saint][F]{Melia}
[T2][BOW][Ranger](Bernadetta)[F]{RedBean, Marlon0024, Jj09}
[T1][BOW][Archer](Improved)[M]{Flasuban, DerTheVaporeon}
[T1][MAG][Clergy](Cleric Improved Repalette)[F]{Flasuban, Eldritch Abomination}
[T1][MAG][Custom Magi](Witch)[F]{Pikmin1211, Retrogamer}
[T2][MON][Demon](Tarvos - Elder)[M]{Seal}
[T2][MON][Undead](Wight)[U]{Teraspark, Wan}
[T3][CAV][Master Knight](Gold Knight)[U]{Nuramon}
[T1][MAG][Clergy](Priest Improved Repalette)[M]{Flasuban, Eldritch Abomination}
[T2][AXE][Warrior](Warrior 2.0)[M](Leo_Link, Nuramon, Spud)
[T2][BOW][Sniper](Neimi)[F]{Aruka, Frostlax, Kenpuhu}
[T0][MISC][Miscellaneous](Chicken)[U]{EldritchAbomination}
[Soldier-Custom][M]FE15-Style by Nuramon

Map Sprites:

[T1] Mage (M) (Hatless) Moving {Pikmin1211}
[T1] Mage (M) (Hatless) Standing {Pikmin1211}
[T1] Shaman (F) Moving {IS}
[T1] Shaman (F) Standing {IS}
[T1][ARM] Knight (FE10-Hybrid-Style) Lance Moving {Nuramon, flasuban}
[T1][ARM] Knight (FE10-Hybrid-Style) Lance Standing {Nuramon, flasuban}
[T1][AXE] Fighter (M) (FE10-Style) Axe Moving {L95}
[T1][AXE] Fighter (M) (FE10-Style) Axe Standing {L95}
[T1][AXE] Pirate (DS-Style) Axe Moving {DerTheVaporeon}
[T1][AXE] Pirate (DS-Style) Axe Standing {DerTheVaporeon}
[T1][LNC] Soldier (M) (Shield) Lance Moving {Rexacuse, Peerless, Alusq}
[T1][LNC] Soldier (M) (Shield) Lance Standing {Rexacuse, Peerless, Alusq}
[T1][LRD] Lord (F) (Hector) Axe Moving {Shin19}
[T1][LRD] Lord (F) (Hector) Axe Standing {Shin19}
[T1][LRD] Lord (F) (Lucina) Sword Moving {BatimaTheBat}
[T1][LRD] Lord (F) (Lucina) Sword Standing {BatimaTheBat}
[T1][LRD] Lord (M) (Hector) Axe Moving {IS}
[T1][LRD] Lord (M) (Hector) Axe Standing {IS}
[T2] Battle Sage (M) (Mage Fighter) Magic Moving {L95}
[T2] Battle Sage (M) (Mage Fighter) Magic Standing {L95}
[T2] Custom Pale Flower Nino Moving {StreetHero}
[T2] Custom Pale Flower Nino Standing {StreetHero}
[T2] Druid (F) Moving {IS}
[T2] Druid (F) Standing {IS}
[T2] Witch (F) Moving {Aruka, Kenpuhu}
[T2] Witch (F) Standing {Aruka, Kenpuhu}
[T2][AXE] Berserker (M) (Barbarian) Axe Moving {Glaceo}
[T2][AXE] Berserker (M) (Barbarian) Axe Standing {Glaceo}
[T2][LRD] Great Lord (M) (Ephraim-Infantry) Lance Moving {Snewping}
[T2][LRD] Great Lord (M) (Ephraim-Infantry) Lance Standing {Snewping}
[T2][LRD] Great Lord (M) (Hector) Moving {IS}
[T2][LRD] Great Lord (M) (Hector) Standing {IS}
[T3] Necromancer (M) (Generic) Moving {Rasdel}
[T3] Necromancer (M) (Generic) Standing {Rasdel}
[T3][SWD] Dread Fighter (F) Moving {Nuramon}
[T3][SWD] Dread Fighter (F) Standing {Nuramon}
[T3][SWD] Dread Fighter (M) Moving {Nuramon}
[T3][SWD] Dread Fighter (M) Standing {Nuramon}
Bael (Queen) Moving {Seal}
Bael (Queen) Standing {Seal}
[T1][AXE] Fighter (F) (FE10-Style) Axe Moving {Pikmin1211}
[T1][AXE] Fighter (F) (FE10-Style) Axe Standing {Pikmin1211}
[T1][CAV] Cavalier (F) Lance Moving {Tordo45}
[T1][CAV] Cavalier (F) Lance Standing {Tordo45}
[T1][CAV] Cavalier (F) Sword Moving {Agro}
[T1][CAV] Cavalier (F) Sword Standing {Agro}
[T1][LRD] Lord (F) (Lyn) Sword Moving {IS}
[T1][LRD] Lord (F) Lyn Sword Standing {IS}
[T1][BOW] Nomad (F) Moving {IS}
[T1][BOW] Nomad (F) Standing {IS}
[T2][LRD][Great Lord](Brave Lyn)[F]{Red Bean, Marlon0024}
[T1][LRD][Lord](Lyn +Axes)[F]{IS, Vilkalizer}
[T3] Saint (F) Moving {Melia}
[T3] Saint (F) Standing {Melia}
[T2][BOW] Nomad Trooper (F) Moving {IS}
[T2][BOW] Nomad Trooper (F) Standing {IS}
[T1] Clergy (F) (Cleric Improved) Staff Moving {flasuban}
[T1] Clergy (F) (Cleric Improved) Staff Standing {flasuban}
[T1] Clergy (M) (Priest Improved) Staff Moving {flasuban}
[T1] Clergy (M) (Priest Improved) Staff Standing {flasuban}
[T1] Mage (F) Moving (Awakening) {blood}
[T1] Mage (F) Standing (Awakening) {blood}
[T2][SWD]Hero (M) (Blue Shield Edit) Sword Moving {Pikmin1211}.png
[T2][SWD]Hero (M) (Blue Shield Edit) Sword Standing {Pikmin1211}
Deathgoyle Lance Moving {L95}
Deathgoyle Lance Standing {L95}
Tarvos (M) Elder Centaur (Axe) Moving {Seal}
Tarvos (M) Elder Centaur (Axe) Standing {Seal}
[T2][CAV] Gold Knight Lance Moving {Hypergammaspaces}
[T2][CAV] Gold Knight Lance Standing {Hypergammaspaces}.png
[T1][AXE] Fighter (M) (Improved) Axe Moving {flasuban}
[T1][AXE] Fighter (M) (Improved) Axe Standing {flasuban}
[T2][LRD] Blade Lord (F) (Brave Lyn) Bow Moving {StreetHero}
[T2][LRD] Blade Lord (F) (Brave Lyn) Bow Standing {StreetHero}
[T2][AXE] Berserker (M) (Dartserker) Axe Moving {WarPath}
[T2][AXE] Berserker (M) (Dartserker) Axe Standing {WarPath}

Class Cards:

[ARM] Knight (M) (SALVAGED) Lance {team SALVAGED}
[MAG] Witch {Aruka, Yggdra}
[MON] Bael (Queen Bael) {Seal}
[MON] Tarvos (M) (Elder Centaur) {Seal}

Mugs used:

Hector recolored by me.
Fire Emblem 7 recolors by Eldritch Abomination
Titania, Bernadetta and Lysithea by SomeDenseGuy
Arvis by BorsDeep(Atey)
Edelgard and Claude by Melia
Cordelia by Jeorge_Reds
Linhardt by HyperGammaSpaces
Ike by Nickt
(Minerva by Zelkami, Nickt) <- Changed in new versions
Michalis by Obsidian_Daddy
Silque by Blade
Lucina by TheImperialKnight
Heroes Anna by MiiK
Minerva from a recolored Gwendolin by me (more fitting with the GBA style, that's the reason I changed it, the palette is based in Minerva from FE1 artwork)

CG Backgrounds by ZoramineFae based on FGO and WAve CG images.

Some backgrounds come from FE8 Sacred War assets (I changed the colors of one of them for the class change screen), others are modified versions by me to eliminate the upper black part.

Final Fantasy I & II Advance backgrounds ripped by Vanarus and Ryan914; Final Fantasy IV Advance backgrounds ripped by Bean; Final Fantasy V Advance backgrounds ripped by Valoc Dakmyre; I got them from Spriters Resource. All backgrounds were ported by me (Dennis el Azul).