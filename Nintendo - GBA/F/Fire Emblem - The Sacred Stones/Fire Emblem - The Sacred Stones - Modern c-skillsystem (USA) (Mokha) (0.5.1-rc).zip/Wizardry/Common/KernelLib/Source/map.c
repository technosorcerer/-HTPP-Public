#include "common-chax.h"
#include "kernel-lib.h"

inline bool IsPositionValid(s8 x, s8 y)
{
    if (x < 0)
        return false;

    if (y < 0)
        return false;

    if (x > gBmMapSize.x)
        return false;

    if (y > gBmMapSize.y)
        return false;

    return true;
}

struct Unit * GetUnitAtPosition(s8 x, s8 y)
{
    s8 uid;

    if (!IsPositionValid(x, y))
        return NULL;

    uid = gBmMapUnit[y][x];
    if (!uid)
        return NULL;

    return GetUnit(uid);
}

void MapAnim_CommonInit(void)
{
    EndAllMus();
    RenderBmMap();
    RefreshEntityBmMaps();
    RefreshUnitSprites();
}

void MapAnim_CommonEnd(void)
{
    ResetMuAnims();
    InitBmBgLayers();
    LoadUiFrameGraphics();
    LoadObjUIGfx();
}
