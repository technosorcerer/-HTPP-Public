#pragma once

#include "common-chax.h"

void HbPopuplate_Page3Skill(struct HelpBoxProc * proc);
void HbRedirect_Page3Skill(struct HelpBoxProc * proc);
