Greetings!
Thank you for reading and downloading my Fire Emblem Hack!
I hope that you have a good time playing it!

If you have any feedback, questions, or criticism, I would like to hear it.
I'm trying to make a good, fun and balanced game after all.
Every tiny bit of advice may help!

