
# CrossoverHack2.0

## About this project
This is a passion project that started in 2009 with the silly idea of "What if Eirika, Ephraim and Roy were in FE7?"
At first it was going to be a crossover between the GBA FEs, with the main lords and their *canon\** love interests, but then __Atey__ got interested in the project and volunteered to make portraits. With her in the team we extended the scope from FE1 to FE12.

The story wasn't going to have major changes, mainly because Event Assembler was new and I didn't know how to use it, so we focused on FE7 with characters from other FEs. Once I learned EA, we thought it was better to change a bit of the story, and that's when __Ikethekiller__ entered the picture. The first draft didn't deviate too much from FE7 main plot, but the focus was shifted to our OCs. As the story developed, we started to ditch some ideas, and when we changed from FE7 to FE8, we ditched Lyn's entire plot and made something new.

Now this project includes characters from FE1 to Engage, with some references to FE Heroes.

We hope you enjoy this project as much as we enojyed making it.

<sub>* = Based mainly in our *subjective opinion*. </sub>

## Characters
As for the character selection, we added the main lords, then some polls were made to choose the best character to join the lord. The final roster is:
* Sora <sup>1</sup>
* Thar <sup>1</sup>
* Riku <sup>1</sup>
* Soleil <sup>1</sup>
* Marth
* Caeda/Sheeda
* Alm
* Celica
* Berkut <sup>2</sup>
* Sigurd
* Deirdre
* Seliph
* Julia
* Lewyn
* Leif
* Nanna
* Osian
* Saias
* Roy
* Lilina
* Lugh <sup>3</sup>
* Raigh <sup>3</sup>
* Eliwood
* Ninian
* Hector
* Florina
* Lyn
* Rath
* Nino
* Jaffar
* Legault <sup>3</sup>
* Eirika
* Seth
* Ephraim
* Tana
* L'Arachel <sup>3</sup>
* Lyon
* Ike
* Soren
* Titania
* Elincia
* Jill <sup>3</sup>
* Micaiah
* Sothe
* Haar <sup>3</sup>
* Volke
* Sephiran
* Robin <sup>2</sup>
* Leo <sup>2</sup>
* ?????? <sup>1</sup>
* ?????????? <sup>2</sup>
* ??????? <sup>2</sup>
* ???????? <sup>2</sup>
* ??????? <sup>2</sup>
* ??????? <sup>2</sup>

<sup>1</sup> = Original character.

<sup>2</sup> = Added as new entries in the saga were released.

<sup>3</sup> = Added to replace a dropped character.

There are some characters that we dropped due to relevancy
<details>

* Julian

* Linoan

* Dean

* Eda

* Sanaki

* Mia

* Chrom

* Lucina

* Holmes

* Zeek
</details>

## Progress

<table>
<thead>
<th>Chapter</th><th>Map</th><th>Script</th><th>Events</th><th>Translation</th>
</thead>
<tbody>
<tr>
<td>Prologue</td><td>Done</td><td>Done</td><td>Done</td><td>N/A</td>
</tr>
<tr>
<td>Ch. 1</td><td>Done</td><td>Done</td><td>Done</td><td>N/A</td>
</tr>
<tr>
<td>Ch. 2</td><td>Done</td><td>Done</td><td>Done</td><td>N/A</td>
</tr>
<tr>
<td>Ch. 3</td><td>Done</td><td>Done</td><td>Done</td><td>N/A</td>
</tr>
<tr>
<td>Ch. 4</td><td>Done</td><td>Done</td><td>Done</td><td>N/A</td>
</tr>
<tr>
<td>Ch. 5</td><td>Done</td><td>Done</td><td>Done</td><td>N/A</td>
</tr>
<tr>
<td>Ch. 6</td><td>Done</td><td>Done</td><td>Done</td><td>N/A</td>
</tr>
<tr>
<td>Ch. 7</td><td>Done</td><td>Done</td><td>Done</td><td>N/A</td>
</tr>
<tr>
<td>Ch. 8</td><td>Done</td><td>Done</td><td>Done</td><td>N/A</td>
</tr>
<tr>
<td>Ch. 9</td><td>Done</td><td>Done</td><td>Done</td><td>N/A</td>
</tr>
<tr>
<td>Ch. 9x</td><td>Done</td><td>Done</td><td>Done</td><td>N/A</td>
</tr>
<tr>
<td>Ch. 10</td><td>Done</td><td>Done</td><td>Done</td><td>N/A</td>
</tr>
<tr>
<td>Ch. 11</td><td>Done</td><td>Done</td><td>Done</td><td>N/A</td>
</tr>
<tr>
<td>Ch. 12</td><td>Done</td><td>Done</td><td>Done</td><td>N/A</td>
</tr>
<tr>
<td>Ch. 13</td><td>Done</td><td>Done</td><td>Done</td><td>N/A</td>
</tr>
<tr>
<td>Ch. 14</td><td>Done</td><td>Done</td><td>Done</td><td>N/A</td>
</tr>
<tr>
<td>Ch. 15</td><td>Done</td><td>Done</td><td>Done</td><td>N/A</td>
</tr>
<tr>
<td>Ch. 16</td><td>Done</td><td>Done</td><td>Done</td><td>N/A</td>
</tr>
<tr>
<td>Ch. 17</td><td>Done</td><td>Done</td><td>Done</td><td>N/A</td>
</tr>
<tr>
<td>Ch. 17x</td><td>Done</td><td>Done</td><td>Done</td><td>N/A</td>
</tr>
<tr>
<td>Ch. 18</td><td>Done</td><td>Done</td><td>Done</td><td>N/A</td>
</tr>
<tr>
<td>Ch. 19</td><td>Done</td><td>Done</td><td>Done</td><td>N/A</td>
</tr>
<tr>
<td>Ch. 20</td><td>Done</td><td>Done</td><td>Done</td><td>N/A</td>
</tr>
<tr>
<td>Ch. 20x</td><td>Done</td><td>Done</td><td>Done</td><td>N/A</td>
</tr>
<tr>
<td>Ch. 21</td><td>Done</td><td>Done</td><td>Done</td><td>N/A</td>
</tr>
<tr>
<td>Ch. 22</td><td>Done</td><td>Done</td><td>Done</td><td>N/A</td>
</tr>
<tr>
<td>Ch. 23</td><td>Done</td><td>Done</td><td>Done</td><td>N/A</td>
</tr>
<tr>
<td>Ch. 24</td><td>Done</td><td>Under revision</td><td>In Progress</td><td>N/A</td>
</tr>
<tr>
<td>Ch. 25</td><td>Done</td><td>In Progress</td><td>N/A</td><td>N/A</td>
</tr>
<tr>
<td>Ch. 26</td><td>Done</td><td>In Progress</td><td>N/A</td><td>N/A</td>
</tr>
<tr>
<td>Ch. 27</td><td>N/A</td><td>Drafted</td><td>N/A</td><td>N/A</td>
</tr>
<tr>
<td>Ch. 27x</td><td>N/A</td><td>Drafted</td><td>N/A</td><td>N/A</td>
</tr>
<tr>
<td>Ch. 28</td><td>N/A</td><td>Drafted</td><td>N/A</td><td>N/A</td>
</tr>
<tr>
<td>Ch. 28x</td><td>N/A</td><td>Drafted</td><td>N/A</td><td>N/A</td>
</tr>
<tr>
<td>Ch. 29</td><td>N/A</td><td>Drafted</td><td>N/A</td><td>N/A</td>
</tr>
<tr>
<td>Ch. 29x</td><td>N/A</td><td>Drafted</td><td>N/A</td><td>N/A</td>
</tr>
<tr>
<td>Ch. 30</td><td>N/A</td><td>N/A</td><td>N/A</td><td>N/A</td>
</tr>
<tr>
<td>Ch. 31</td><td>N/A</td><td>N/A</td><td>N/A</td><td>N/A</td>
</tr>
<tr>
<td>Ch. 31x</td><td>N/A</td><td>N/A</td><td>N/A</td><td>N/A</td>
</tr>
<td>Final</td><td>N/A</td><td>N/A</td><td>N/A</td><td>N/A</td>
</tr>
</tbody>
</table>


## Credits

### Tools
* Skill System by circleseverywhere (The core of this hack)
* TMX2EA by circleseverywhere (Map converter)
* Animation Assembler by circleseverywhere (Battle animation converter)
* Spell Animation Creator by circleseverywhere (Spell animation converter)
* FE_Builder_GBA by 7743 (For debugging and testing)
* lyn by StanH (ASM to EA converter)
* Event Assembler by Nintenlord and improved by Crazycolorz5
* Tiled by Thorbjørn Lindeijer (Map creator/editor)
* Usenti by Cearn (Graphics editor)
* Anvil Studio by Willow Software (Midi creator/editor)
* HxD by Maël Hörz (Hex editor)

### Portraits
* Atey (Anything not listed below nor made by IS)
* Stitch (Jill)
* NICKT (Jill, Brickenden, Kenvern)
* SomeDenseGuy (Titania)
* MageBoy (Leo, Gazehelm)
* HyperGammaSpaces (Berkut, Rinea, Walsh)
* Glaceo (Alcryst)
* Enex (Alvin)
* Lenh (Aurik)
* LaurentLaicrox (Fyra, Kearney, Female Bandit 1, Female Bandit 2, Male Villager 9)
* CapibarainSpace (Andra)
* Blade (Eduardo)
* Zoisite (Leoncio)
* P33RL355 (Ett)
* KKAfterbrun (Femte)
* Imperial (Young Female Villager 7)
* Wasdye (Jake)
* Eldritch Abomination (Anna FE Warriors)
* Garytop (Aversa, Anna {Awakening}, Anna {Heroes})
* TheBlindArcher (Lombard)
* Random Wizard (Bandit 1, Bandit 5)
* Zmr (Bentley)
* WAve (Dhima, Anna {Halloween})
* Smokeyguy77 (Godwin, Ronmel)
* DerTheVaporeon (Kromell)
* Zeldacrafter64 (Qatai)
* MonkeyBard (Walsh)
* Melia (Bandit 5, Anna {Fates})
* Feier (Anna {Telius})
* BuskHusker (Anna {TLP})
* Kanna (Anna {Merchant})
* 

### Animations
* Halberdier <details>Myrmidon-Reskin Black Pants</details>
* Leo_Link <details>Myrmidon-Reskin Black Pants, Trickster V.2, Hunter Male, Paladin-Variant Female, Ranger-Variant Male, DarkKnight Female, General-Reskin Baron Cape, WyvernRider-Reskin Repal</details>
* Greentea <details>Swordmaster-Variant Stefan, Assassin-Reskin Jaffar, Assassin-Reskin Leila, Sage-Reskin FE6 Style with Boots Male, Sage-Reskin Erk, Sage-Reskin Nino, Valkyrie-Reskin Ursula, PegasusKnight-Reskin Florina, FalcoKnight-Reskin Florina, FalcoKnight-Reskin Fiora, Ballista Wil</details>
* RobertFPY <details>Swordmaster-Variant Stefan</details>
* ltranc <details>Swordmaster-Variant Stefan</details>
* Pikmin1211 <details>Thief-Base Matthew Repal, Thief-Base Cath Repal, Hero-Reskin Raven Armor Coat, Fighter-Variant FE9 Female, Nomad-Base Repal Male, Trobadour-Variant Thaumaturge Male, Trobadour-Variant Thaumaturge Female, Troubadour-Reskin FE7 RepalWyvernKnight-Custom Malig Knight v2</details>
* Maiser6 <details>Thief-Base Matthew Repal, Thief-Base Cath Repal, Nomad-Base Repal Male, Trobadour-Variant Thaumaturge Female, Troubadour-Reskin FE7 Repal</details>
* Skitty <details>Thief-Base Matthew Repal, Thief-Base Vanilla FE7 Legault Repal, Thief-Base Cath Repal, Rogue-Reskin Long Hair, Brigand-Reskin Barbarian Female, Berserker-Reskin Armored Female, GreatKnight-Base Repal</details>
* GabrielKnight <details>Thief-Base Matthew Repal, Thief-Base Cath Repal, Mage-Reskin Hatless, Trobadour-Variant Thaumaturge Male, Trobadour-Variant Thaumaturge Female, Roy-Reskin Redesign</details>
* Eldritch Abomination <details>Thief-Base Vanilla FE7 Legault Repal, Rogue-Base Repal, Monk-Base Repal Female, Monk-Base Repal Male, Priest-Base Repal v2, Cleric-Base Improved Repal, Bishop-Base Repal Male, Bishop-Base Repal Female, Manakete-Base Generic Dragon Transformation</details>
* eCut <details>Rogue-Reskin Long Hair, Brigand-Reskin Barbarian Female, Berserker-Reskin Armored Female, WyvernRider-Reskin Repal</details>
* Epicer <details>Trickster V.2</details>
* Kanto Emblem <details>Trickster V.2</details>
* DerTheVaporeon <details>Assassin-Base Knife Alt, Assassin-Reskin Leila, Pirate-Custom DS-Style, Berserker-Variant Sideslash, Archer-Reskin Wil, Archer-Reskin Short Hair Female, Sage-Reskin Erk, Sage-Reskin Nino, Trobadour-Variant Thaumaturge Male, Trobadour-Variant Thaumaturge Female, General-Reskin Shield v2</details>
* Nuramon <details>Assassin-Reskin Jaffar, Hero-Variant Armored, Soldier-Custom FE10-Style, Pirate-Reskin Variant Female, Sniper-Reskin Quiver Male, Sniper-Variant Marksman Male, Sage-Custom Yggdra Lute Long Hair, General-Reskin Shield v2, General-Reskin Baron Cape, WyvernLord-Reskin Armored Repal, Lord Custom Alm T1, Lord Custom Alm T2, Grand Paladin Generic Repal, Eliwood-Reskin Master Eliwood, Hector-Base Repal T1, Hector-Custom Brave, Ephraim-Custom Heavy Infantry</details>
* Team SALVAGED <details>Mercenary-Variant Male, Cavalier-Variant Generic Male, Paladin-Variant Male, Paladin-Variant Female, Paladin-Variant Titania, Knight-Variant Generic</details>
* Jey the Count <details>Mercenary-Variant Female, Ranger-Variant Male, PegasusKnight-Reskin FlorinaWyvernKnight-Custom Malig Knight v2</details>
* Pushwall <details>Hero-Reskin Raven Armor Coat, Warrior-Base Repal Leather</details>
* WarPath <details>Hero-Variant Echidna</details>
* RedBean <details>Hero-Variant Echidna, Mage-Reskin Lilina, Sage-Reskin Lilina, Archsage Lilina, Ranger-Custom Bernadetta, FalcoKnight-Variant Nino, Eirika-Variant Priestess Celica T1, Eirika-Variant Priestess Celica T2, Eliwood-Reskin Master Eliwood, Eliwood-Reskin Brave, Lyn-Reskin T2, Lyn-Style Brave, MK-Variant L'Arachel, Trobadour-Reskin L'Arachel</details>
* flasuban <details>Soldier-Custom FE10-Style, Brigand-Reskin Fully-Clothed Headband Repal, Priest-Base Repal v2, Cleric-Base Improved Repal, Paladin-Variant Female, Roy-Reskin Redesign</details>
* Alusq <details>Custom Lance Militia</details>
* TheBlindArcher <details>Custom Halb Halberdier Male, Troubadour-Reskin FE7 Repal, General-Reskin Shield v2, General-Base Bow, FalcoKnight-Reskin Black Beauty</details>
* Black Mage <details>Custom Halb Halberdier Female</details>
* MK404 <details>Fighter-Variant FE9 Repal Male</details>
* Glenwing <details>Fighter-Variant FE9 Repal Male</details>
* Maiser6 <details>Fighter-Variant FE9 Female, Griffon v1 Repal</details>
* UltraFenix <details>Brigand-Reskin Fully-Clothed Headband Repal, WyvernRider-Reskin Repal, Roy-Reskin Master Lord</details>
* MarioKirby <details>Pirate-Reskin Variant Female</details>
* Wan <details>Pirate-Reskin Variant Female</details>
* Aruka <details>Berserker-Variant Sideslash, Sniper-Variant Neimi, Sage-Custom Yggdra Lute Long Hair, Grand Paladin Seth v2, MageKnight-Base Male, MageKnight-Base Female, Valkyrie-Reskin L'Arachel v2, Grand Paladin Generic Repal</details>
* Kenpuhu <details>Berserker-Variant Sideslash, Sniper-Variant Neimi, Sage-Custom Yggdra Lute Long Hair, Grand Paladin Seth v2, MageKnight-Base Male, MageKnight-Base Female, Valkyrie-Reskin L'Arachel v2, Grand Paladin Generic Repal</details>
* MeatOfJustice <details>Hunter Male</details>
* Spud <details>Hunter Male, Eliwood-Base Slash, Eliwood-Reskin Master Eliwood</details>
* Swain <details>Sniper-Reskin Quiver Male</details>
* Temp <details>Sniper-Reskin Quiver Male, Hector-Base Repal T2</details>
* Frostlax <details>Sniper-Variant Neimi</details>
* Lisandra_Brave <details>Mage-Reskin Ponytail</details>
* 7743 <details>Mage-Reskin LilinaWyvernKnight-Custom Malig Knight v2</details>
* tristan_hollow <details>Sage-Reskin FE6 Style with Boots Male</details>
* Levin64 <details>Sage-Reskin Erk, Sage-Reskin Lute FE8 VariantBishop-Variant Holy Priestess, Nomad Trooper-Reskin FE6 Male, Nomad Trooper-Reskin FE7 Male</details>
* HyperGammaSpaces <details>Sage-Reskin Erk, Lord Custom Alm T1, Lord Custom Alm T2</details>
* Faolin <details>Sage-Reskin Lucius Hair v2</details>
* Shin19 <details>Archsage Lilina</details>
* St jack <details>Sage-Variant Battle Sage, Ballista Wolt</details>
* The_Big_Dededester <details>Sage-Variant Battle Sage, Paladin-Variant Female, General-Reskin Shield v2, General-Reskin Baron Cape</details>
* Aviv <details>Sister</details>
* Melia <details>Bishop-Variant Holy Priestess</details>
* Knabepicer <details>Bishop-Variant Holy Priestess, Lord Custom Seliph Repalette</details>
* Feier <details>Bishop-Variant Holy Priestess</details>
* RiriK <details>Bishop-Variant Holy Priestess, Summoner-Reskin FEGirls-Style Hair Color Fix, Lyn-Style Brave</details>
* FEGirls Project <details>Summoner-Reskin FEGirls-Style Hair Color Fix</details>
* Obsidian Daddy <details>Paladin-Variant Male, Lord Custom Sigurd, Lord Custom Seliph Repalette, Lord Custom Leif</details>
* blood <details>Grand Paladin Seth v2, Valkyrie-Reskin L'Arachel v2</details>
* Arkth <details>Grand Paladin Seth v2</details>
* Victor Pouderoux <details>Paladin-Variant Titania</details>
* BatimaTheBat <details>Troubadour-Reskin Ponytail Repal, MK-Reskin Female Repal - Short Hair</details>
* RobertFPY <details>Valkyrie-Reskin Ursula, PegasusKnight-Reskin Florina, FalcoKnight-Reskin Florina, FalcoKnight-Reskin Fiora</details>
* seergiioo <details>Valkyrie-Reskin Ponytail Diadem</details>
* Apolo15 <details>DarkKnight Female, Eliwood-Reskin Master Eliwood</details>
* Iscaneus <details>General-Reskin Baron Cape</details>
* OreoStyx <details>PegasusKnight-Basa Repal</details>
* shadowofchaos <details>FalcoKnight-Reskin Black Beauty, Monster-Custom Ice Dragon</details>
* Sme <details>FalcoKnight-Reskin Black Beauty</details>
* Shtick <details>FalcoKnight-Reskin Black Beauty</details>
* RRSKAI <details>WyvernLord-Reskin Armored Repal</details>
* Feaw <details>WyvernKnight-Base Repal</details>
* Blue Druid <details>Griffon v1 Repal</details>
* Jj09 <details>WyvernKnight-Custom Malig Knight v2, Lord Custom Leif</details>
* qiuzf007 <details>Ballista Wil</details>
* Blaze <details>Eliwood-Variant Marth Thrust-Stab</details>
* Jeorge_Reds <details>Eirika-Variant Priestess Celica T1, Eirika-Variant Priestess Celica T2, Roy-Reskin Master Lord, Eliwood-Reskin Master Eliwood, Hector-Base Repal T1, Eirika-Base Repal T1</details>
* ZoramineFae <details>Lord Custom Sigurd, Lord Custom Seliph Repalette</details>
* SurfingKyogre <details>Eliwood-Reskin Roy T2</details>
* Fiuke_Bnuy <details>Lyn-Base Repal T1</details>
* Kermy <details>Eirika-Base Repal T1</details>
* Khrene Kleaver <details>Lord Custom Ike</details>
* Cipher Lee <details>Lord Custom Micaiah</details>
* SHYUTERz <details>Manakete-Base Fire Dragon</details>
* SqRtOfPi <details>Monster-Custom Ice Dragon</details>
* L95 <details>Monster-Custom Mage Dragon, Monster-Custom Earth Dragon, Gargoyle-Reskin T2</details>
* Teraspark <details>Gargoyle-Reskin T2</details>
* a3d3 <details>Warrior-Base Repal Leather</details>
* Furious <details>Shaman-Base Repal</details>
* NamelessX <details>Sniper-Reskin Female AS Runa</details>


### Map Sprites
* Team SALVAGED <details>Knight Axe, Cavalier Axe Male, Knight Bow, Knight Lance, Cavalier Lance Female, Cavalier Lance Male, Knight Sword, Cavalier Sword Female, Cavalier Sword Male</details>
* L95 <details>Paladin Axe Female, Black Beauty Lance T2, Earth Dragon, Fighter FE10 Style Male, Fire Mage FE4 Style Male, Horse, Magic Dragon, Thunder Mage Female, Thunder Mage Male, Wind Mage Male</details>
* RobertFPY <details>Paladin Axe Male v2, Paladin Sword Male v2</details>
* Nuramon <details>Marshall Axe, Dark Knight, General Shield Lance</details>
* Pikmin1211 <details>Berserker Hawkzerker Axe Female, Dark Knight, Fighter FE10 Style Female, Cavalier Lance Female, Malig Knight Axe, Thaumaturge Female, Thaumaturge Male, Cavalier Sword Female</details>
* DerTheVaporeon <details>Berserker Hawkzerker Axe Female, Dark Knight, Thaumaturge Female, Thaumaturge Male, Pirate Axe DS Style Male</details>
* NYZgamer3 <details>Berserker Hawkzerker Axe Male</details>
* flasuban <details>Bow Knight Female, Bow Knight Male, Brigand Axe Male Improved, Cleric Improved, Wyvern Lord Helmless Axe Male, Pirate Axe Female, Priest Improved</details>
* Skitty <details>Brigand Axe Female</details>
* HyperGammaSpaces <details>Fighter Alm, Hero Alm, Priestess Celica, Princess Celica</details>
* Alusq <details>Militia Lance, Soldier Alt Lance Male</details>
* Ultra-Fenix <details>Druid Hoodless Female</details>
* Velvet Kitsune <details>Druid Hoodless Female, Summoner Female</details>
* Ash3wl <details>Fire Mage FE4 Style Male, Thunder Mage Female, Thunder Mage Male, Wind Mage Male</details>
* StreetHero <details>Custom Nino</details>
* N426 <details>Griffon Rider Sword</details>
* TheBlindArcher <details>Halberdier 2.0 Male, Halberdier 2.0 Alt Helmet Male</details>
* Topazlight <details>Halberdier 2.0 Alt Helmet Male</details>
* milom <details>Great Lord Ephraim Sword</details>
* MeatOfJustice <details>Hunter Male</details>
* MK404 <details>Micaiah T1</details>
* FireEmblemier <details>Leif T1</details>
* Kirb <details>Marth</details>
* Leif <details>Generic Lord Sword, Thunder Mage Female, Thunder Mage Male</details>
* Jeorge_Reds <details>Roy T2</details>
* Agro <details>Mercenary Sword Female</details>
* Teraspark <details>Ranger Rebecca Bow</details>
* Permafrost <details>Paladin Sword Female Revision</details>
* Dominus_Vobiscum <details>Thunder Mage Female</details>

### Tilesets
* ZoramineFae <details>Revamped Fields, Updated Cave, Updated Desert, Frontier Remake, Village Remake</details>
* N426 <details>Revamped Castle, Village Remake</details>
* HyperGammaSpaces <details>Updated Cave Palette, Updated Desert</details>
* Venno <details>Updated Desert, Village Remake</details>
* flasuban <details>Frontier Remake, Village Remake</details>
* WAve <details>Frontier Remake</details>

### Misc. Graphics
* LordGlenn <details>Affinity icons, Weapon rank icons, Item icons</details>
* GabrielKnight <details>Item icons</details>

### Music
* VGMusic (Unspecified author) <details>"Golbez, Clad in the Dark" (Final Fantasy IV), "Battle with Hearless" (Kingdom Hearts)</details>
* Catmaster (VGMusic) <details>"Just Wondering" (Kingdom Hearts - Re:Chain of Memories)</details>
* Jay Reichard (VGMusic) <details>"Within These Castle Walls" (Castlevania 2), "Anxiety (Remix)" (Castlevania 3), "Demon Seed" (Castlevania 3), "Act 4 Stage 3/Apprehensive Moments" (Ninja Gaiden)</details>
* Disquietude (Musescore) <details>"Encounters and Reunions" (Fire Emblem - Thracia 776)</details>
* Sme <details>"Cats at Play" (Fire Emblem - Path of Radiance), "Life at Garreg Mach Monastery" (Fire Emblem - Three Houses), "Strike!" (Fire Emblem - Shadow Dragon), "Adversary" (Fire Emblem - Shadow Dragon), "Ally's Attack" (Fire Emblem - Genealogy of the Holy)</details>
* Blue_Nocturne (VGMusic) <details>"Thirteenth Discretion/Tension" (Kingdom Hearts - Chain of Memories)</details>
* Dolkar <details>"Destiny" (Fire Emblem - Thracia 776), "Boss Battle" (Fire Emblem - Thracia 776), "Team Plasma Plots/Plasma Sage Encounter" (Pokémon Black/White)</details>
* Untranslated (VGMusic) <details>"With Us!/Recruitment Theme" (Fire Emblem - Path of Radiance)</details>
* HyperGammaSpaces <details>"The Fiend's Rapture/Defend" (Fire Emblem - Gaiden), "Disquieting Steps/Celica Enemy Phase" (Fire Emblem - Gaiden), "The Air of Brutality/Alm Enemy Phase" (Fire Emblem - Gaiden), "Sally Fort" (Fire Emblem - Thracia 776), "Unity" (Fire Emblem Echoes - Shadows of Valentia), "Truth" (Fire Emblem Echoes - Shadows of Valentia)</details>
* SurfingKyogre <details>"Conversation 1" (Fire Emblem - Genealogy of the Holy War), "Crisis" (Fire Emblem - Thracia 776), "Recruitment" (Fire Emblem - Thracia 776), "Thracia" (Fire Emblem - Thracia 776), "Dance in the Skies" (Fire Emblem - Genealogy of the Holy)</details>
* Catrione (Musescore) <details>"Good Company in Brodia" (Fire Emblem - Engage)</details>
* Uzel <details>"A Distant Promise" (Fire Emblem Echoes - Shadows of Valentia)</details>
* The_Burger_King_420 <details>"A Distant Promise" (Fire Emblem Echoes - Shadows of Valentia)</details>
* 雨原 <details>"Unity" (Fire Emblem Echoes - Shadows of Valentia), "Truth" (Fire Emblem Echoes - Shadows of Valentia)</details>
* SevenChaos (VGMusic) <details>"Self-Discipline (Rock Arrangement)" (Riviera: The Promised Land)</details>
* Mars Jenkar (VGMusic) <details>"Escape" (Metroid Zero Mission)</details>
* SaXor the Nobody <details>"Clash" (Fire Emblem - Path of Radiance), "Onset" (Fire Emblem - Shadow Dragon), "March" (Fire Emblem - Radiant Dawn), "The Devoted" (Fire Emblem - Radiant Dawn)</details>
* Jorge D. Fuentes (VGMusic) <details>"Nightmare" (Castlevania 3), "Heart of Fire" (Castlevania - Aria of Sorrow)</details>
* Pandan <details>"Defend" (Fire Emblem - Thracia 776)</details>
* Solis (VGMusic) <details>"Big Battle" (Castlevania 3)</details>
* B1itz Lunar (VGMusic) <details>"Vaati Transfigured" (The Legend of Zelda - Minish Cap)</details>
* Cerberiga (VGMusic) <details>"With Mila's Divine Protection" (Super Smash Bros. Brawl/Fire Emblem - Gaiden)</details>
* Chao (VGMusic) <details>"Forgotten Challenge" (Kingdom Hearts - Chain of Memories), "Oblivion Castle" (Kingdom Hearts - Chain of Memories)</details>
* CatBee (Musescore) <details>"Hymn of the Righteous" (Fire Emblem - Radiant Dawn)</details>
* Chris Ng (VGMusic) <details>"Assault" (Final Fantasy X)</details>
* Agro <details>"Scout for Enemies" (Fire Emblem - Thracia 776), "Pressing Threat - Base A" (Fire Emblem - Thracia 776)</details>
* RSflame <details>"Seeking Victory - Base" (Fire Emblem - Thracia 776), "Silesia Army" (Fire Emblem - Genealogy of the Holy), "Endless Battle" (Fire Emblem - New Mystery of the Emblem)</details>
* RoyLili500 <details>"The Time to Act" (Fire Emblem - Shadow Dragon & the Blade of Light)</details>
* MrGreen339 <details>"Enemy's Attack" (Fire Emblem - Genealogy of the Holy), "Ascent" (Fire Emblem - Radiant Dawn)</details>
* Dethraxx <details>"The Black Knight" (Fire Emblem - Path of Radiance), "Fate Unstoppable" (Fire Emblem - Path of Radiance)</details>
* Mycahel <details>"A Dark Fall" (Fire Emblem - Fates)</details>
* Kaidras <details>"Bright Sandstorm" (Fire Emblem - Engage)</details>

### Patches/ASM/Hacks/Reworks/Fixes/Etc.
* Ganzapy <details>"Modern" Brave Weapon Effect Rework, Three Houses Restore</details>
* Huichelaar <details>Multipalette Colour BGs</details>
* Gryz <details>Allow 254 generic minimugs</details>
* 7743 <details>Allow 254 generic minimugs, Unique Battle Music per Unit, Chapter Titles as text, Setting battle BGM of a many dancer in battle animation, Disable Mini Map, Expand the sound room, Get Unit Status, Give Exp. Points, Set multiple Staff BGMs, Multiple Supply units, Multiple Seize units, Multi Tile Marker, Character Custom Animation, Simple setting of Sacred Weapons, Silent Give Item, Tile Change triggers flag, Add trap, Remove trap, Stat screen redesign, Rework for Prep Screen Right Top Image, Continue Battle BGM Between Map and Combat</details>
* Leonarth <details>256 colors titlescreen background</details>
* Vesly <details>Battle Stats With Anims Off, Extend Weapon Description Box, Modular Summon</details>
* Snakey1 <details>Base Conversations, Scripted Battle Numbers</details>
* HyperGammaSpaces <details>Battle Palette Rework, Chapter Titles as text, Fill AI Danger Map Efficiency Fix</details>
* Tequila <details>Battle Transformations, Fancy Thief Animations, Text Engine Rework, Modify CHAI, Set Status, Modify Staff Exp, Walking Sounds Fix</details>
* Aera <details>Battle Transformations, Give Exp. Points</details>
* circleseverywhere <details>Battle Transformations, Chapter Titles as text, More than 5 supports fix</details>
* Sme <details>ASMC Check Suite, More Shop Types, Split Promotion Items, Status Expansion</details>
* P33RL355 <details>ASMC Check Suite</details>
* StanH <details>Talk AI, AI doesn't attack if it can't do damage</details>
* Teraspark <details>Custom/Fancy Staves</details>
* Pikmin1211 <details>Equippable Items</details>
* 2WB <details>Portrait Height</details>
* TR143 <details>GBA RNG Randomizer</details>
* Scraiza <details>Shopping Edits</details>
* AuraWolf <details>Shopping Edits</details>
* Contro <details>Show Heal Amount Glow</details>
* Kirb <details>Stat screen redesign</details>
* Zeta <details>Arena Limits+Non Lethal Arena</details>
* Zane <details>Modular Minimug Box</details>

### Special Thanks
* Sol HolyYogurt (Moral support, crazy ideas suggestion, character idea, honorary member)
* Kanningu (Character idea, former member)
* Alen Cotapos (Formerly known as Kaneda, character idea)
* Klokinator (Asset repository)
* Kirb, Snakey1, Pikmin1211, Huichelaar, Vesly, 7743 (For helping me to figure out the secrets of wizardry and dealing with my BS)
* Tequila (ASM documentation)
* MK404 (For inspiring me to getting into the FE ROM hacking universe)
* You, the player