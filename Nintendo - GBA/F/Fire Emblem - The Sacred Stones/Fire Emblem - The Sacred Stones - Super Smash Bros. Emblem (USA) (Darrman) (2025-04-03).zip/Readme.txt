Apply patch to FE8.
Sit back and relax.

Credits:
Super Smash Bros. Melee opening
Faces added by Darrman