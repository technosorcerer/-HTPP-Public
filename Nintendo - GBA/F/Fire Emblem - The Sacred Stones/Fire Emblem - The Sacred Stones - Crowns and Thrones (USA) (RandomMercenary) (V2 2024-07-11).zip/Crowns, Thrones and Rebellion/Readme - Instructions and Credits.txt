Instructions:
1. Download the patch.
2. Apply the patch by using a patching program like 'NUPS' for example. The patch only works on a clean US version of a Fire Emblem 8 'The Sacred Stones' rom.
3. Play the patched rom on an emulator. I suggest using 'VisualBoyAdvance', but any GBA emulator should be fine.
4. Have fun playing.


Credits:

Animations:
[FE5 Lord Custom] [M] Leif Lord by Obsidian Daddy.

[FE8 Eirika-Base] [F] T1 Beta Eirika Fixed by Jono the Red.

[Cavalier-Variant] [M] Generic by SALVAGED.

[Grand Paladin] [M] Seth v2 by Aruka.

[Great Lord-Custom] [M] Master Knight by St Jack.

[Paladin-Variant] [M] Kent by Greentea.

[Paladin-Variant] [M] SALVAGED +Weapons.

[Berserker-Variant] [M] Skinnyzerker Ross by Zomaxiee.

[Archer-Variant] [M] Der’s Improved Repal.

[Crossbowman] [M] Bowgunner by Epicer.

[Sniper-Reskin] [F] Quiver by Nuramon.

[Sniper-Reskin] [M] Quiver by Nuramon.

[Soldier-Custom] [M] FE15-Style by Nuramon.

[Hero-Reskin] [F] Generic +Brown Shield by IS, Pikmin1211, Pushwall, St jack.

[Hero-Reskin] [M] FE7 Coat +Brown Shield by Swain, Pikmin1211, ltranc.

[Mercenary-Reskin] [M] Armored +Axe by Alusq.

[General-Reskin] [M] Baron Cape +Weapons by Leo_link, Nuramon, Iscaneus, The_Big_Dededester.

[Knight-Variant] [M] Generic by SALVAGED.

[Marshall] [M] Zelgius v3 by Nuramon.

[FE7 Eliwood-Base] [M] T1 Vanilla +Weapons by Jj09, PrincessKilvas, Spud.

[FE7 Lyn-Reskin] [F] T2 FE7if Karla by FE7if.

[FE8 Ephraim-Custom] [M] T2 Heavy Infantry by Nuramon.

[FE8 Ephraim-Variant] [M] T1 Vanilla Repack +Weapons by DerTheVaporeon, Pikmin1211.

[T3.1 Bishop] [M] Patriarch by MrNight48.

[Mage-Custom1] [F] Light Mage by L95.

[Mage-Custom1] [M] Light Mage by L95.

[Sage-Custom] [F] Gaiden Priestess by Gamma.

[Sage-Variant] [F] Battle Sage +Sword by St jack.

[Sage-Variant] [M] Battle Sage +Weapons by St jack, The_Big_Dededester, Dolkar.

[Devisian-Custom] [M] Magician v2 by Devisian_Nights.

[WL Reskin] [U] Armored by Nuramon.

[WR Base] [U] Vanilla +Weapons by Mikey Seregon, Alfred Kamon.

[Dark Knight] [U] Great Knight-Style by Primefusion.

[MK-Base] [F] Vanilla +Weapons by Aruka, Kenpuhu.

[MK-Base] [M] Vanilla +Weapons by Aruka, Kenpuhu.

[Troubadour-Reskin] [F] Ponytail Repal +Weapons by Pikmin1211, Maiser6, Lisandra_Brave, TBA.

[Paladin-Custom] [M] Leo’s Duke Knight by Leo_Link.

[Marshall] [U] FE10-Style by Nuramon.

[Eliwood-Variant] [M] Mage Lord by TytheBub.

[Tent Standing] by Gabrielknight.


Tilesets:
FE5’s fields by flasuban


Music:

FE4 - Another Assault (Tristan_Hollow).
FE4 - Army of Grannvale 1 (SurfingKyogre).
FE4 - Castle Captured (SurfingKyogre).
FE4 - Conversation 1 (SurfingKyogre).
FE4 - Defense (MrGreen3339).
FE4 - Enemy Message 3 (SurfingKyogre).
FE4 - From Enemy to Friend (pandan).
FE4 - Glory to Grannvale (SurfingKyogre).
FE4 - Victory 1 (SurfingKyogre).
FE4 - Victory is Near! (SurfingKyogre).
FE4 - When The Rush Comes (MrGreen3339).
FE5 - Advance (Dolkar).
FE5 - Adversity (Dolkar).
FE5 - Conquest (SurfingKyogre).
FE5 - Crisis (SurfingKyogre).
FE5 - Defend (pandan).
FE5 - In Search of Victory - Leif (SurfingKyogre).
FE5 - Map A (Dolkar).
FE5 - Pressing Threat (MrGreen3339).
FE5 - Pressing Threat Base A (Dolkar).
FE5 - Recruitment (SurfingKyogre).
FE5 - Searching the Enemy (SurfingKyogre).
FE5 - Squadron B (Dolkar).
FE5 - Victory (Dolkar).
FE5 - Victory Minor (Dolkar).
FE11- Under this Flag (Sme).
Zelda II - Battle (Pandan).


CG artwork:

‘100 years war-french warriors’ from Italeri.


For FeBuilder and patches I want to thank:

7743 - FeBuilder.
CirclesEverywhere, Tequila, Rossendale, StanH, Leonarth, Teraspark- Skillsystems.
laqieer - Autosave Killer.
Venno - Autocursor Fix.
Zeta - Leadership SkillSystems Version.
