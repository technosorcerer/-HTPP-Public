
First off thank you for choosing to 
play our game!  It was tireless effort of 
that took almost 4 years.
We hope you enjoy!

TO INSTALL:
You need to get a fresh ROM of Fire Emblem 8: The Sacred Stones (US) and patch the clean ROM using an UPS patcher (e.g. NUPS).  From there you can simply run the game and boom your done! :D

Bug workaround:
You can now hold L to turn off the battle animations in case of animation breaking events!

Some known bugs:
- If you get the cursor sounding like it's scrolling toggle to the next unit
- Similar to the bug above but more game breaking is when the cursor looks like it's selecting on a tile without your unit on it and moving it will crash the game.  To fix this simple just toggle to 
the next unit without moving the cursor and it will work.


All assets that are not our own belong to their respective creators.  Credit goes to them. (Credits list is posted on FE Universe and there is a Credit's list in the credit screen at the end of the game as well.


Patch Log:

Patch 1.1 Changes:
	Added:
	- The main title screen of The Return of Kris
	- A new battle animation for ??????!
	- New portraits for ??? and ????.
	- New Suna portraits
	- A new Kelly portrait
	- Added the title screen!


	Balancing:
	- Made it more difficult to kill Honest Serpent's dogs on Chapter 11
	- Added the Watchful skill to a boss in Chapter 12
	- Rebalanced the weapons. Swords now have lower weight overall and added weight to some lance weapons.
	- Vantage+ now negates enemy crits when the user is attacked.  The description has been updated to reflect this change.
	- Heaven Seals are now added to your inventory automatically instead of dropping.
		- For the 1st Heaven Seal you must finish Ch.12
		- For the 2nd Heaven Seal you must now talk to Zephiel with Grapefruit.
		- For the 3rd Heaven Seal you must finish Ch.14
	- Luck buff to some characters
	- Alvis defense growth buff
		
	Bug Fixes:
	- Fixed Sophia not being able to promote from a Dreadfighter into a Druid
	- Fixed Sophia keeping the sword rank if you decline the Dreadfighter upgrade
	- Fixed the player sending boss items to inventory
	- Fixed text errors
	- Fixed some wrong convos being played
	- Fixed Sarada being able to promote multiple times
	- Fixed bosses' spawns being blocked
	- Fixed a map tile issue in Chapter 17
	- Fixed Kelly being able to promote with Master Seals and Knight's Crests
	- Fixed the ??? event not giving him S rank in lances
	- Fixed Arden and Alec not retaining skills when they promote
	- Fixed bosses spawning in the wrong locations
	- Fixed enemies despawning during an event in Ch.20
	- Fixed the random chests giving you nothing
	- Fixed Ch.14 restarting after you finish the chapter

Patch 1.01 Changes:
- Severe bug fixed when at Marc's house
- Fixed Paige being able to promote
- Slight rebalancing of Ch. 16 The Pig Squeals