#include "common-chax.h"
#include "battle-system.h"

const u8 WeaponHpCostConfig[0x100] = {
	[ITEM_AXE_DEVIL] = 20,
};
