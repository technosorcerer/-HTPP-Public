#include "common-chax.h"
#include "battle-system.h"

const u8 WeaponHpDrainConfig[0x100] = {
	[ITEM_DARK_NOSFERATU] = 50,
	[ITEM_SWORD_RUNESWORD] = 50,
};
