#include "common-chax.h"
#include "kernel-lib.h"

#define LOCAL_TRACE 0

void GameInit_InitCache(void) {}
