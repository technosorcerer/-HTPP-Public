$("#uk").click(function()
{
	//UI
	$("#intro").text("Introduction");
	$("#histo").text("Story");
	$("#chara").text("Characters");
	$("#mecha").text("Mechanics");
	$("#credi").text("Credits");
	$("#conta").text("Contact");

	//Intro
	$("#introText").text("Fire Emblem - Crossover Hack 2.0 is a project that started in 2009 as a simple hobby. It was a simple idea to unite all the characters from the saga in a single game*.");
	$("#introText2").text("It can be said that this project is on a 70% of development, but what remains isn't necessary the easiest part. We won't drop this project, we'll continue until it's finished.");
	$("#textNote").text("* = This started long before Fire Emblem Heroes was a concept");
	
	//Characters
	$("#tharinfo1").text("Class: Nomad");
	$("#tharinfo2").text("Appears in: N/A");
	$("#thar1").text("A powerful warrior and general of the Arcanest Army. He's able to spread chaos in the battlefield thanks to his bow, Ixion.");
	$("#thar2").text("This mysterious nomad is rather peculiar. He looks like a know-it-all, but his strong suit are topics related to war and not much else.");
	$("#thar3").text("He decides to join Lyn just to have somebody that can guide him through Elibe, which is an unknown territory for him. He makes strong bonds with Riku, Sora and Soleil, whom he considers warriors worthy of his interest.");
	$("#rikuinfo1").text("Class: Myrmidon");
	$("#rikuinfo2").text("Appears in: N/A");
	$("#riku1").text("This peculiar swordsman just wants to find his brother, whom he hasn't seen since he was a child. He's always searching new enemies to test his blade. Riku believe that, if he becomes a renown swordmaster, his brother might find him.");
	$("#riku2").text("He's very social and charismatic, but he talks a lot and he tends to be overconfidant, which makes it hard for other people to take him seriously. Apparently, it's rather easy for him to talk to women, whom trust him pretty soon.");
	$("#riku3").text("He considers himself as the responsible of cheering the group and always looks for a conversation with Sora and Thar so they are not so serious.");
	$("#lyninfo1").text("Class: Lord");
	$("#lyninfo2").text("Appears in: FE7, FE13, FEH, FEW, Super Smash Bros.");
	$("#lyn1").text("A nomad from Sacae and the last survivor of the Lorca tribe. She has dedicated most of her time to improve her sword skills to be able to avenge the death of her parents up until she sets on a journey with Thar and Riku that changes her life.");
	$("#lyn2").text("Her ability to persuade and recruit warriors to join her cause shows Lyn's inherent skills to command an army. She wants to help all her allies that come from other continents while she takes care of her own family issues.");
	$("#lyn3").text("She feels a deep love for the plains she grew up in and would never live far from them.");
	$("#florinainfo1").text("Class: Pegasus Knight");
	$("#florinainfo2").text("Appears in: FE7, FE13, FEH");
	$("#florina1").text("A Pegasus Knight from Illia and Lyn's childhood friend. She's extremely shy and gets very nervous in the presence of men, to the point she can't even say a word in front of them.");
	$("#florina2").text("Being the youngest of 3 siblings, she always had a complex for her combat skills. Despite this, a strong desire to protect Lyn leads her to surpass her limits and that makes her stronger. She enjoys metting new flying knights.");
	$("#florina3").text("Even if she has a hard time making new friends due her shyness, most people that get to know her think she's kind, sympathetic and a very pleasant person to have around.");
	$("#eirikainfo1").text("Class: Lord");
	$("#eirikainfo2").text("Appears in: FE8, FE13, FEH");
	$("#eirika1").text("The young and kind princess of Renais and also Ephraim's twin sister. Despite she has the proper education of a princess, she weilds her sword to defend her cause and to protect innocents without hesitation.");
	$("#eirika2").text("She has a deep bond with his twin brother and has been searching for him for a long time since he abandoned Renais' castle during the war against Grado. Eirika is very mature and reasonable, but sometimes her kindness leads her to make mistakes.");
	$("#eirika3").text("She's very sociable and gets to befriend everyone. That, however, doesn't distract her from her strong desire to reunite with her loved ones.");
	$("#celiceinfo1").text("Class: Lord");
	$("#celiceinfo2").text("Appears in: FE4, FE5, FE13, FEH");
	$("#celice1").text("The legitimate heir of the Chalphy house and descendant of the Crusader Baldo, whose holy blood runs through his veins.");
	$("#celice2").text("Becoming an orphan at young age, he lived in exile for years until he decided to face Grandbell Empire and free Jugdral from its tyranny.");
	$("#celice3").text("He's an heroic warrior with a great sense of justice who wishes to be someone as noble and honest as his father. He protects Yuria by Levin's request and together, they seek the way to return home.");
	$("#yuriainfo1").text("Class: Sister");
	$("#yuriainfo2").text("Appears in: FE4, FE5, FE13, FEH");
	$("#yuria1").text("Direct descendant of the Crusader Heim, whose holy blood runs through her veins. Despite possessing a huge magic power, she's a very sweet and kind person.");
	$("#yuria2").text("She remembers almost nothing about her origins and is still alive thanks to Levin, who took care of her when she was seriously wounded. After some time, Levin leaves Yuria under Celice's protection, and as a consequence, Yuria develops a deep bond of trust with him.");
	$("#yuria3").text("Thanks to her skills with both light tomes and staves, Yuria is an invaluable ally to the group.");
	$("#sorainfo1").text("Class: Wind Mage");
	$("#sorainfo2").text("Appears in: N/A");
	$("#sora1").text("A mysterious errant mage that seeks a powerful wind tome through the continent. It seems to know more that the others, because he recognizes every foreign warrior, but nobody knows why or how.");
	$("#sora2").text("Serious in character, he decides to join Lyn and later Eliwood to help them with their respective missions without revealing his origin or nature.");
	$("#sora3").text("Despite all, his partners rely on him and are thankful of his knowledge and guidance, especially Thar, Riku, and Soleil, who become his closest allies.");
	$("#celicainfo1").text("Class: Thunder Mage");
	$("#celicainfo2").text("Appears in: FE2, FE13, FE15, FEH, FEW");
	$("#celica1").text("A priestess from the continent of Valentia. Of softhearted nature, she strongly believes in the teachings of godess Milla and abhors violence in all its forms. She's convinced that all the conflicts can be resolved through pacific means, which sometimes turns out to be way too naive for her own good.");
	$("#celica2").text("She knows Alm since her childhood and he's an important person to her. Even if she seems to be a transparent person, she hides a great secret. Now she's on an unknown land for her, and seeks a way to return to her home and help her new friends.");
	$("#ninianinfo1").text("Classes: Bard/Dancer");
	$("#ninianinfo2").text("Appear in: FE7, FEH");
	$("#ninian1").text("Two young musicians with mysterious powers that travel through Elive fleeing from a group os assassins. Nils is a bard and Ninian a dancer, and their art has revitalizing effect on their allies.");
	$("#ninian2").text("Despite being siblings, they're very different: Nils is direct, serious and distrustful, while Ninian is shy, silent and idealist. Even so, they are strongly united and never separate from each other.");
	$("#ninian3").text("These siblings are surrounded by absolute mystery.");
	$("#micaiahinfo1").text("Class: Light Mage");
	$("#micaiahinfo2").text("Appears in: FE10, FEH");
	$("#micaiah1").text("A young lass known as \"the Silver-Haired Maiden\" that leads a revolutionary group called the Dawn Brigade. She has supernatural powers, among which stand out healing without using staves or predict future events and the outcome of battles.");
	$("#micaiah2").text("She's kind and affectionate, but as she can read the heart of others, sometimes it can be hard to talk to her, because she anticipates the conversation. A bird named Yune is always near her, whom she loves.");
	$("#micaiah3").text("She was traveling with Sothe, whom she considers as a brother and the most important person to her, but when they appear on Elibe, they get separated. She then starts a journey in search of Sothe.");
	$("#rathinfo1").text("Class: Nomad");
	$("#rathinfo2").text("Appears in: FE7");
	$("#rath1").text("A nomad from Sacae and a member of the Kutolah tribe. Despite being the son of the leader, he left his tribe when he had three years to avoid the bad omen that the tribe's shaman foresaw if he remained there.");
	$("#rath2").text("He's a mysterious man of few words who doesn't open to anybody but Lyn, whom he trust for being a nomad like him. He works as a mercenary until he quits his job to help Lyn on her journey, who becomes the only reason he stays in the group.");
	$("#rath3").text("Despite not being sociable, he's a skilled warrior that inspires terror on the enemies and confidence on his allies.");
	$("#ikeinfo1").text("Class: Ranger");
	$("#ikeinfo2").text("Appears in: FE9, FE10, FE13, FE14, FE15, FEH, Codename: STEAM, Super Mario Maker, Super Smash Bros.");
	$("#ike1").text("The leader of Greil Mercenaries. He's a stoic and altruistic boy that helps anyone without caring too mucho about money. Of strong character and serious look, his fault of manners sometimes cause him troubles and misunderstandings.");
	$("#ike2").text("His only wish is to become as stronger as his father, that's why he trains without rest everyday. Despite his personality, every person that has fought under his command confirms that they felt as if they were part of a big family.");
	$("#ike3").text("As his contract with princess Elincia still stands, his main goal is to return to Tellius and help her, however, he takes advantage of his stance on Elibe to strengthen himself with the help of the other foreigners.");
	$("#julianinfo1").text("Class: Thief");
	$("#julianinfo2").text("Appears in: FE1, FE3, BSFE, FE11, FE12");
	$("#julian1").text("A slippery thief from Medonia. He was a former member of a bandit group, but left it after he met priestess Lena. Since then, he fights in justice's side and assists prince Marth on his mission.");
	$("#julian2").text("Despite his change of heart, some things never change. Now, in Elibe, Julian continues using his great skills as thief and spy, stealing from enemies, gathering information and opening chests, while seeking the way to return home.");

	//Mechanics
	$("#mechanics").empty();
	$("#mechanics").append('<ul class="list-group"><li class="list-group-item list-group-item-dark"><b>Magic:</b> like in moderm games of the FE saga, magic stat has been added. Now magic tomes and magic weapons use it to calculate damage. Additionally, the anima magic is divided in fire, thunder, wind and ice. Each element is linked to certain classes and each one has a different effect.</li><li class="list-group-item list-group-item-dark"><b>Steal:</b> on the 2.0.1 version, it was possible to steal weapons from the enemy without restrictions. This affected thieves, whose speed had to be nerfed to compensate. Now, the system is better balanced; it\'s identic to FE10 system, where you can only steal weapons if the enemy doesn\'t have them equipped and additionaly, your strength must be higher that the weapon\'s weight. With this improvement, thieves are the fastest units of the game once more.</li><li class="list-group-item list-group-item-dark"><b>Weapon Level:</b> as in entries after FE11, now the weapon level gives small boosts depending on the weapon type and weapon level.</li><li class="list-group-item list-group-item-dark"><b>Skip animations:</b> if you don\'t want to watch certain battles, now you can just hold the [L] button before starting a battle. This is useful to avoid some error with the animations.</li><li class="list-group-item list-group-item-dark"><b>Enemy range:</b> this is another improvement introduced. By pressing the [Select] button, you can see the enemy range.</li></ul>');

	//FAQ/Legal
	$("#credits").empty();
	$("#credits").append('<ul class="list-group"><li class="list-group-item list-group-item-dark"><b>Mikey Séregon/oracle_of_fire:</b> Main Programmer</li><li class="list-group-item list-group-item-dark"><b>Luzan/Atey:</b> Main Artist</li><li class="list-group-item list-group-item-dark"><b>Volug Vanguard/Ikethekiller:</b> Main Writer</li><li class="list-group-item list-group-item-dark"><b>FEUniverse Community:</b> Most of the ASM hacks featured in this hack were made there.<br>Special thanks to Crazycolorz5, CT075, Venno, circleseverywhere, Teq, 7743 and so many more people that contribuited directly or indirectly in the creation of this project.</li></ul>');

	$("#faq").empty();
	$("#faq").append('<div class="panel-body"><ul class="list-group"><li class="list-group-item list-group-item-dark">1. I can\'t understand anything. Why isn\'t this hack in English?<br>A: Because this hack is in Spanish. You can use a translator while I work on a translation. But the translation will be released only after finish the project... someday.<br>If somebody is willing to make a translation, contact us through the e-mail <a href="mailto:dyugdrah@gmail.com?Subject=Crossover Hack Translation" target="_top">dyugdrah@gmail.com</a></li><li class="list-group-item list-group-item-dark">2. The game freezes when I use new spells!<br>A: Just reset the game and hold the [L] button to deactivate the animation for that battle.</li><li class="list-group-item list-group-item-dark">3. Can I use a .sav from a previous version?<br>A: No. Due several changes between demos, you can no longer use previous .sav.</li><li class="list-group-item list-group-item-dark">4. I want to store my .sav file for a future demo. Will I be able to use it?<br>A: No. The next demo will be made for FE8 and the .sav aren\'t compatible.</li><li class="list-group-item list-group-item-dark">5. I found a glitch. What info should I send?<br>A: Actually, it doesn\'t matter if there are some bugs on this version. Since we are moving to the FE8 engine, any problem found in FE7 won\'t happen on FE8.</li><li class="list-group-item list-group-item-dark">6. I like some assets of this hack, can I use them for my own project?<br>A: Absolutely NO. You can visit FEUniverse, there are plenty of things free to use. Some are even used here.</li></ul></div><div class="panel-body"><p>We don\'t own the "Fire Emblem" games, any character, music and/or scenario from said game used here is property of Nintendo and Intelligent System.If we\'re using something of your property without permission, please contact us.</p></div>');

	$("#cont").text("Everything we receive as donation will be used to improve this project. How? By commissioning ASM hacks in FEUniverse. This is optional, we won't charge anybody to play this hack.");
})

$("#es").click(function()
{
	//UI
	$("#intro").text("Introducción");
	$("#histo").text("Historia");
	$("#chara").text("Personajes");
	$("#mecha").text("Mecánicas");
	$("#credi").text("Agradecimientos");
	$("#conta").text("Contacto");

	//Intro
	$("#introText").text("Fire Emblem - Crossover Hack 2.0 es un proyecto que inició en 2009 como un simple pasatiempo, una simple idea de reunir a todos los personajes de la saga en un solo juego.*");
	$("#introText2").text("Se podría decir que el proyecto está en un 70% en desarrollo. Aunque lo que falta no necesariamente es la parte más fácil, no dejaremos el proyecto de lado, seguiremos hasta terminarlo.");
	$("#textNote").text("* = Esto se empezó mucho antes de que Fire Emblem Heroes fuera un concepto.");

	//Personajes
	$("#tharinfo1").text("Clase: Nómada");
	$("#tharinfo2").text("Aparece en: N/A");
	$("#thar1").text("Poderoso guerrero y general del ejército de Arcanest. Es capaz de sembrar el terror entre las filas enemigas gracias a su arco, Ixión.");
	$("#thar2").text("Este misterioso nómada es bastante peculiar, ya que a pesar de dar la impresión de ser un sabelotodo, su fuerte son los temas relacionados con la guerra y poco más.");
	$("#thar3").text("Decide unirse a Lyn solo para tener cerca a alguien que conozca Elibe, un territorio desconocido para él. Forma un estrecho vínculo con Riku, Sora y Soleil, a quienes considera guerreros dignos de su interés.");
	$("#rikuinfo1").text("Clase: Myrmidon");
	$("#rikuinfo2").text("Aparece en: N/A");
	$("#riku1").text("Este peculiar espadachín solo desea encontrar a su hermano, a quien no ha visto desde que era un niño. Siempre está buscando nuevos enemigos con los que probar su espada, confiando en que si se vuelve un espadachín de renombre, su hermano pueda reconocerlo.");
	$("#riku2").text("Es muy sociable y carismático, pero habla por los codos y suele confiarse demasiado, lo que hace que la gente no suela tomarle en serio. Parece tener cierta facilidad para hablar con las mujeres, quienes confían rápidamente en él.");
	$("#riku3").text("Se considera el responsable de animar al grupo y siempre busca conversaciones con Sora y Thar para que no estén tan serios, algo que en el fondo ellos le agradecen.");
	$("#lyninfo1").text("Clase: Lord");
	$("#lyninfo2").text("Aparece en: FE7, FE13, FEH, FEW, Super Smash Bros.");
	$("#lyn1").text("Nómada de Sacae y última superviviente de la tribu Lorca. Dedicó parte de su vida a entrenarse para vengar la muerte de sus padres hasta que emprendió un viaje con Thar y Riku que cambió su vida.");
	$("#lyn2").text("Gracias a su facilidad para persuadir a diversos guerreros a que se unan a su causa, Lyn demuestra ser una lider innata. Desea ayudar a todos los miembros de su ejército que provienen de otros continentes, además de resolver sus propios conflictos familiares.");
	$("#lyn3").text("Siente un gran amor por las praderas en las que creció y jamás podría vivir alejada de ellas.");
	$("#florinainfo1").text("Clase: Jinete Pegaso");
	$("#florinainfo2").text("Aparece en: FE7, FE13, FEH");
	$("#florina1").text("Jinete de pegaso de Illia y amiga de Lyn desde que eran pequeñas. Es extremadamente tímida y se pone muy nerviosa en la presencia de hombres, hasta el punto que apenas puede pronunciar unas palabras en su presencia.");
	$("#florina2").text("La menor de 3 hermanas, siempre se ha sentido algo acomplejada por sus capacidades en el combate, pero un fuerte deseo de proteger a Lyn la lleva a superar sus límites y a hacerse más fuerte. Su vínculo con su pegaso es muy fuerte y le encanta conocer a nuevas jinetes voladoras.");
	$("#florina3").text("Aunque le cuesta hacer nuevos amigos por su timidez, la mayoría de las personas que llegan a conocerla la ven como alguien amable, simpática y muy agradable.");
	$("#eirikainfo1").text("Clase: Lord");
	$("#eirikainfo2").text("Aparece en: FE8, FE13, FEH");
	$("#eirika1").text("La joven y bondadosa princesa de Renais, es además la hermana gemela de Ephraim. A pesar de que ha tenido una educación propia de una princesa, no duda en usar las armas para defender su causa y proteger a los inocentes.");
	$("#eirika2").text("Tiene una conexión muy profunda con su hermano gemelo y ha pasado mucho tiempo buscándolo desde que abandonó el castillo de Renais durante la guerra contra Grado. Es muy madura y sensata, pero a veces su bondad y dulzura la llevan a cometer errores al dejarse llevar por sus emociones.");
	$("#eirika3").text("Es muy sociable y no tarda en hacerse amiga de todos, sin embargo, esto no la distrae de su intenso deseo por volver a reunirse con sus seres queridos.");
	$("#celiceinfo1").text("Clase: Lord");
	$("#celiceinfo2").text("Aparece en: FE4, FE5, FE13, FEH");
	$("#celice1").text("Heredero legítimo de la casa Chalphy y descendiente del cruzado Baldo, cuya sangre santa corre por sus venas.");
	$("#celice2").text("Se volvió huérfano cuando solo era un bebé y vivió en el exilio durante años hasta que decidió plantar cara al Imperio de Grandbell y liberar Jugdral de su tiranía.");
	$("#celice3").text("Es un guerrero heróico con un gran sentido de la justicia, ya que desea seguir los pasos de su padre. Protege a Yuria por petición de Levin y juntos buscan la forma de volver a casa.");
	$("#yuriainfo1").text("Clase: Hechicera");
	$("#yuriainfo2").text("Aparece en: FE4, FE5, FE13, FEH");
	$("#yuria1").text("Descendiente directa del cruzado Heim, cuya sangre santa corre por sus venas. A pesar de que posee un enorme poder mágico, es una persona muy dulce y amable.");
	$("#yuria2").text("No recuerda casi nada de sus orígenes y solo sigue con vida gracias a Levin, quien se encargó de sanar sus graves heridas. Luego de un tiempo, Levin le encomienda su protección a Celice, con quien Yuria ha desarrollado una gran confianza y cercanía.");
	$("#yuria3").text("Gracias a su maestría con los tomos de luz y los bastones a partes iguales, Yuria es una aliada invaluable para el grupo.");
	$("#sorainfo1").text("Clase: Mago Viento");
	$("#sorainfo2").text("Aparece en: N/A");
	$("#sora1").text("Misterioso mago errante que anda buscando un poderoso tomo de viento por el continente. Parece saber mucho más de lo que aparenta, ya que reconoce a todos los guerreros extranjeros pero nadie sabe por qué ni cómo.");
	$("#sora2").text("Este mago de carácter serio decide viajar primero con Lyn y después con Eliwood para ayudarlos en sus respectivas misiones, sin revelar en ningún momento su origen ni naturaleza.");
	$("#sora3").text("A pesar de todo, sus compañeros confían en él y agradecen su sabiduría y consejos, especialmente Thar, Riku y Soleil, quienes se vuelven sus aliados más cercanos");
	$("#celicainfo1").text("Clase: Maga Trueno");
	$("#celicainfo2").text("Aparece en: N/A");
	$("#celica1").text("Una sacerdotisa originaria del continente de Valentia. De naturaleza bondadosa, cree firmemente en las creencias de la diosa Milla y aborrece la violencia en todas sus formas. Está convencida de que todos los conflictos pueden resolverse de manera pacífica, lo que en ocasiones la hace pecar de ingenua.");
	$("#celica2").text("Conoce a Alm desde que eran niños y es una persona muy importante para ella. Aunque parece una persona muy transparente, en el fondo oculta un gran secreto. Ahora en una tierra desconocida para ella, busca la forma de volver a casa y ayudar a sus nuevos amigos.");
	$("#ninianinfo1").text("Clases: Bardo/Bailarina");
	$("#ninianinfo2").text("Aparecen en: FE7, FEH");
	$("#ninian1").text("Dos jóvenes músicos con poderes misteriosos que recorren Elibe huyendo de un grupo de asesinos. Nils es bardo y Ninian es una bailarina. Su arte tiene un efecto revitalizante en sus aliados.");
	$("#ninian2").text("A pesar de ser hermanos son bien distintos: Nils es más directo, serio y desconfiado, mientras que Ninian es más tímida, callada e idealista. Aún así, están fuertemente unidos y nunca se separan el uno del otro.");
	$("#ninian3").text("Son dos hermanos envueltos en el más absoluto misterio.");
	$("#micaiahinfo1").text("Clase: Maga Luz");
	$("#micaiahinfo2").text("Aparecen en: FE10, FEH");
	$("#micaiah1").text("Joven doncella conocida como La Dama del Alba que lidera a un grupo revolucionario llamado la Brigada del Alba. Tiene poderes sobrenaturales, entre los que destaca poder curar sin usar bastones o predecir acontecimientos futuros y el devenir de las batallas.");
	$("#micaiah2").text("Es bondadosa y cariñosa, pero al ser capaz de leer el corazón de los demás a veces puede resultar molesto hablar con ella, pues se anticipa a la conversación. Junto a ella siempre está su pájaro, Yune, a quien quiere mucho.");
	$("#micaiah3").text("Viajaba con Sothe, a quien considera un hermano y la persona más importante para ella, pero al llegar a Elibe se separa de él. Viaja por el continente para encontrarlo.");
	$("#rathinfo1").text("Clase: Nómada");
	$("#rathinfo2").text("Aparecen en: FE7");
	$("#rath1").text("Nómada de Sacae perteneciente a la tribu Kutolah. A pesar de ser el hijo del líder, abandonó a su tribu cuando solo tenía 3 años para evitar que se cumpliera el mal presagio que el brujo de la tribu predijo ocurriría si se quedaba.");
	$("#rath2").text("De carácter misterioso y pocas palabras, no se abre a nadie salvo a Lyn, en quien confía al ser una nómada como él. Trabaja como mercenario hasta que renuncia para acompañar a Lyn en su viaje, quien es la única razón por la que permanece en el grupo.");
	$("#rath3").text("A pesar de no ser muy sociable, es un guerrero hábil que inspira temor en los enemigos y confianza en sus aliados.");
	$("#ikeinfo1").text("Clase: Mercenario");
	$("#ikeinfo2").text("Aparecen en: FE9, FE10, FE13, FE14, FE15, FEH, Codename: STEAM, Super Mario Maker, Super Smash Bros.");
	$("#ike1").text("Líder de los mercenarios de Greil, es un joven estoico y altruista que ayuda a los demás sin importarle demasiado el dinero. De carácter fuerte y mirada seria, su falta de modales en ocasiones le causa problemas y malentendidos.");
	$("#ike2").text("Su único deseo es hacerse más fuerte que su padre, por lo que entrena sin descanso día tras día. A pesar de su carácter, todos los que han luchado bajo su mando afirman haberse sentido como en una gran familia.");
	$("#ike3").text("Como su contrato con la princesa Elincia sigue vigente, su principal deseo es volver a Tellius y ayudarla, pero aprovechara su estancia en Elibe para fortalecerse con la ayuda de los demás extranjeros.");
	$("#julianinfo1").text("Clase: Ladrón");
	$("#julianinfo2").text("Aparecen en: FE1, FE3, BSFE, FE11, FE12");
	$("#julian1").text("Escurridizo ladrón de Medonia. Es un antiguo miembro de un grupo de bandidos, que termina por abandonar tras conocer a la sacerdotisa Lena. Desde entonces, lucha del lado de la justicia y asiste al príncipe Marth en su misión.");
	$("#julian2").text("A pesar de su cambio de bando, algunas costumbres nunca cambian. Ahora en Elibe, Julian continúa haciendo uso de sus magnificas habilidades como ladrón y espía, robando a enemigos, recopilando información y abriendo cofres, mientras busca la forma de volver a casa.");

	//Mecanicas
	$("#mechanics").empty();
	$("#mechanics").append('<ul class="list-group"><li class="list-group-item list-group-item-dark"><b>Magia:</b> como otras entregas más modernas de FE, ahora se ha agregado el stat de Magia, por lo que ahora los tomos de magia y las armas mágicas lo utilizan para calcular daño. Adicionalmente, la magia anima está separada en fuego, trueno, viento y hielo. Cada elemento está ligado a una clase determinada y cada una tiene un efecto diferente.</li><li class="list-group-item list-group-item-dark"><b>Robar:</b> en la versión 2.0.1 era posible robar armas al enemigo sin ninguna reestricción, lo que terminó afectando a los ladrones, cuya velocidad tuvo que ser reducida para compensar. Ahora el sistema está mejor balanceado; es idéntico al sistema presente en FE10, donde solo puedes robar armas si el enemigo no las tiene equipadas y adicionalmente tu fuerza debe ser mayor al peso del arma. Con esto, los ladrones vuelven a ser las unidades más rápidas del juego.</li><li class="list-group-item list-group-item-dark"><b>Rango de Armas:</b> al igual que en entregas posteriores a FE11, ahora el rango de arma otorga pequeños bonos dependiendo del tipo y rango de arma.</li><li class="list-group-item list-group-item-dark"><b>Saltar animaciones:</b> ahora si no quieres ver animaciones en batallas específicas, basta con mantener presionado el botón [L] antes de empezar una batalla. Esto es muy útil cuando se presentan errores en ciertas animaciones.</li><li class="list-group-item list-group-item-dark"><b>Rango enemigo:</b> otra mejoría que se introduce. Presionando el botón [Select] puedes ver el rango de ataque enemigo.</li></ul>')

	//Agradecimientos
	$("#credits").empty();
	$("#credits").append('<ul class="list-group"><li class="list-group-item list-group-item-dark"><b>Mikey Séregon/oracle_of_fire:</b> Programador Principal</li><li class="list-group-item list-group-item-dark"><b>Luzan/Atey:</b> Artista Principal</li><li class="list-group-item list-group-item-dark"><b>Volug Vanguard/Ikethekiller:</b> Escritor Principal</li><li class="list-group-item list-group-item-dark"><b>Comunidad de FEUniverse:</b> Casi todos los hacks ASM utilizados en este hack fueron hechos allí.<br>Agradecimientos especiales a Crazycolorz5, CT075, Venno, circleseverywhere, Teq, 7743 y mucha más gente que contribuyo directa o indirectamente a la creación de este proyecto.</li></ul>');

	//FAQ/Legal
	$("#faq").empty();
	$("#faq").append('<div class="panel-body"><ul class="list-group"><li class="list-group-item list-group-item-dark">1. El juego se congela después de utilizar los nuevos tomos.<br>R: Solo resetea el juego y mantén presionado el boton [L] para saltarse las animaciones de batalla.</li><li class="list-group-item list-group-item-dark">2. ¿Puedo utilizar un .sav de una versión anterior?<br>R: No. Debido a varios cambios entre versiones, los .sav anteriores no son compatibles.</li><li class="list-group-item list-group-item-dark">3. Planeo guardar un .sav de este juego, ¿lo podré usar en futuras versiones?<br>R: Probablemente no. Las próximas versiones se harán en FE8, por lo que no serán compatibles.</li><li class="list-group-item list-group-item-dark">4. Encontré un bug/glitch, ¿que información debo enviar?<br>R: La verdad no importa que hayan bugs en esta versión. Dado a que nos pasaremos al sistema de FE8, cualquier error encontrado en FE7 no ocurrirá en las demos posteriores.</li><li class="list-group-item list-group-item-dark">5. Me gustan muchas de las cosas que veo en el hack, ¿puedo usarlas en mi propio proyecto?<br>R: Absolutamente NO. Puedes visitar FEUniverse, allí hay varias cosas que son de libre uso. Algunas incluso se usan aquí.</li></ul></div><div class="panel-body"><p>Nosotros no somos dueños de los juegos "Fire Emblem". Cualquier personaje, música, y/o escenarios de dicho juego utilizados aquí son propiedad de Nintendo e Intelligent System.<br>Si estamos utilizando algo de tu propiedad sin permiso, por favor contáctanos.</p></div>');

	//Contact
	$("#cont").text("Todo lo que recibamos como donación será utilizado para mejorar el hack. ¿Cómo? Mediante comisiones en FEUniverse para crear hacks/mejoras. Esto es totalmente opcional, no le cobraremos a nadie para jugar este hack.");
})