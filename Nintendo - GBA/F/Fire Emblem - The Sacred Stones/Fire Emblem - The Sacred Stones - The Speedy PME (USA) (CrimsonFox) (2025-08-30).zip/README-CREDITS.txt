FIRE EMBLEM - THE RADIANT STONES V1.0 (The Speedy PME)
-------------------------------------
Reskin/Overhaul Of Fire Emblem 8 Made By CrimsonFox

Featuring new weapons, classes, animations, music and more!
Several detailed informations regarding the new changes featured in the in-game Guide.
Patch a vanilla, unmodified Fire Emblem - The Sacred Stones ROM file with an UPS patcher program.


FULL CREDITS LIST
-----------------
-|HACK-ASMS|-
-------------
- Anti-Huffman by Hextator, 7743.
- 01/48 Command Hack by Hextator, 7743.
- 16 Tracks 12 Sounds by Agro, Brendor.
- SOUND_NIMAP2 (Native Instrument Map) by Alusq, Circleseverywhere.
- FillAIDangerMap Efficiency Fix by HyperGammaSpaces, 7743.
- AutoGenLeftOAM Dynamically Creating LeftToRightOAM by 7743.
- Casual Mode (Ver Flag 0xB0) by Circleseverywhere, Vesly.
- DrumFix by Circleseverywhere.
- Fix LZ77 Decompress by Tequila.
- ExModularSave with Supply 200 by Stan, Vesly.
- Heroes Movement Standalone by Stan, 7743.
- Multiple Classes Discover Desert Treasures by 7743.
- Multi-Class Pick Skil by Kao, 7743.
- Display Growths Patch by Tequila.
- Battle Forecast Fix by Contro.
- Fix CG Fade Glitch by 7743.
- Change Status Background by 7743.
- ModularMinimugBox: VisionQuest Style with ItemList by Pandan, Scraiza, Zane.
- Actions After Talk/Support (Contemporary Style) by Circleseverywhere, 7743.
- CSA Creator for FE8U v2 by Circleseverywhere.
- CSA Creator Fix Dodge to Front Glitch by Snakey1.
- HPBars with Warnings Cache by Circleseverywhere, Tequila, Zane.
- Map Danger Zone (Select: Toggle) by Circleseverywhere.
- Show Heal Amount by Tequila.
- Null Move Display by 7743.
- Battle Stats with Anims Off by Tequila.
- Dance/Staff Display Animations Option by 7743.
- Magic Sword Rework by Sme.
- Use HandAxs Generic Motion/Skip Wait for Return by 7743.
- Fix SetupNewWMRoute Road Draw by 7743.
- Fix Issue with Mine/Trap Glitch by 7743.
- HP Bar and Cloudy Graphics Fix by Tequila.
- Remove Pierce/Enemy Control Glitch by Brendor, 7743.
- Narrow Font by Scraiza, MintX.
- Unit Action Rework by Stan.
- Exceed The Portrait Hackbox 4 Tiles by Tiki.
- Fixed Growths Mode by TR143.

-|BATTLE-ANIMS|-
----------------
- [Cavalier-Variant] [M] [F] Generic by SALVAGED, Flasuban.
- [Paladin-Variant] [M] [F] Vanilla-Style Repal/Base by SALVAGED, Jey the Count, HyperGammaSpaces, Levin64, RJ_Exists, Obsidian_Daddy.
- [Cavalier-Variant] [M] [U] Leo's Sword Cavalier +Long Hair by Leo_Link, Pushwall.
- [Paladin-Custom] [U] Gold Knight v2 by Nuramon, HyperGammaSpaces.
- [Knight-Variant] [M] Generic by SALVAGED.
- [General-Reskin] [M] Baron Cape +Weapons by Leo_Link, Nuramon, Iscaneus, The_Big_Dededester, UltraFenix.
- [Mercenary-Variant] [M] Vanilla Style [F] +Pants by SALVAGED, Jey the Count, UltraFenix, Pushwall, Citrus.
- [Hero-Reskin] [M] FE7 Coat [F] Generic +Blue Shield by Swain, Pikmin1211, ltranc, Pushwall, St Jack.
- [Myrmidon-Reskin] [M] [F] Alt by Leo_Link.
- [Swordmaster-Base] [M] [F] Vanilla FE7 TLP v2 by Seliost1.
- [Soldier-Reskin] [M] [F] FE10-Style by Flasuban.
- [Custom Lance] [M] [F] Militia (Deserter) by Alusq, Knabepicer.
- [Custom Halb] [M] [F] Halberdier by TheBlindArcher, Spud, MeatOfJustice, Black Mage.
- [Custom Polearm] [M] [F] Sergeant by Spud, Leo_Link, Iscaneous, Nuramon, Dora Drago, Itranc.
- [Fighter-Reskin] [M] Tellius-Style Clothing by Leo_Link, Pushwall, UltraFenix.
- [Fighter-Reskin] [F] Long Hair Repalette V2 by BlackMage, SageHapuiaJDJ, Itranc.
- [Warrior-Base] [M] Vanilla +Magic Axe by UltraFenix. 
- [Warrior-Reskin] [F] Repal Long Hair by Temp, Pushwall, tatutachang.
- [Brigand-Reskin] [M] Headband [F] Barbarian by Eldritch Abomination, Skitty, eCut, ltranc, Chi-Chi.
- [Pirate-Reskin] [M] [F] Variant by Nuramon, MarioKirby, Wan, ltranc.
- [Berserker-Base] [M] Vanilla Repal by Blue Druid, Raulster/Alice, DerTheVaporeon.
- [Berserker-Reskin] [F] Piratezerker by Alice, eCut, Skitty, Natsumi/Serif, DerTheVaporeon.
- [Brigand-Style] [M] [F] Mounted Marauder by Spud, TytheBub.
- [Archer-Variant] [M] [F] Improved by DerTheVaporeon, Flasuban.
- [Hunter] [M] [F] Hunter by MeatOfJustice, Leo_Link, Spud.
- [Sniper-Reskin] [M] [F] Adventurer by ltranc, Leo_Link.
- [Nomad-Reskin] [M] Non-Sacaen [F] Long-Hair Repal by eCut, Pikmin1211, Maiser6.
- [Nomad Trooper Reskin] [M] FE6 Style by Levin64.
- [Nomad Trooper Base] [F] Repal by Pikmin1211, Maiser6, ltranc, Valak.
- [Ranger-Base] [M] [F] Vanilla +Lance by Skitty, Feaw, SaintRubenio.
- [Thief-Base] [M] [F] Repal +Knife by Pikmin1211, Maiser6, Alice, Skitty, Gabriel Knight, UltraFenix, Seliost1.
- [Assassin-Base] [M] Jaffar Vanilla Repal Brown Boots by Pushwall, Glenwing, Jj09, UltraFenix, Huichelaar.
- [Assassin-Reskin] [F] Ponytail + Skirt Repal by FPZero, Moocavo, Riku, Pushwall, Jj09, Raulster/Alice, Itranc.
- [Rogue-Base] [M] Repal (Community Effort) by Pikmin1211, Maiser6, Ukelele, SD9k, Temp, Black Mage, Wan, Orihara_Saki, ltranc, eCut, Skitty.
- [Rogue-Reskin] [F] Long Hair +Knife by eCut, Skitty, Mikey Séregon.
- [Peg T1 Base] [F] Vanilla Repal by OreoStyx.
- [Peg T2 Variant] [F] Falcoknight v2 by Flasuban.
- [Peg T2-Variant] [F] Sky Knight by JeyTheCount.
- [WR Reskin] [M] Repal by UltraFenix, Leo_Link.
- [WL Reskin] [U] Armored by Nuramon.
- [WK Reskin] [U] Fellbeast Knight (Cursed Spear) by Nuramon.
- [Mage-Base] [M] Vanilla FE7-8 +Fixes by Shin19.
- [Mage-Reskin] [F] Basic Hat by CelestiaHeart.
- [Sage-Reskin] [M] FE8 Repal by UltraFenix, Shin19, Levin64, HyperGammaSpaces.
- [Sage-Base] [F] Vanilla FE8 Lute +Fixes by Shin19.
- [MK-Reskin] [M] [F] No Shoulder Pads +Headband by DatonDemand, Vyland.
- [Monk-Base] [M] [F] Repal by Eldritch Abomination.
- [Priest/Cleric-Base] [M] [F] Improved Repal v2 by Eldritch Abomination, Flasuban.
- [T2 Bishop-Base] [M] [F] Repal by Eldritch Abomination, Mikey Seregon.
- [Devisian-Custom] [M] Parson by Devisian_Nights.
- [Mage-Custom1] [M] Mage Lord v1 by Eldritch Abomination.
- [Cleric-Variant] [F] Sassy Healer by Alusq.
- [Custom DM] [M] [F] Awakening Dark Mage by BatimatheBat, Leo_Link.
- [T3 Necromancer-Reskin] [M] [F] Lyon Repal by TytheBub.
- [T2 Summoner-Base/Reskin] [M] Vanilla +Fixes [F] FEGirls-Style Hat by Eldritch Abomination, Unknown.
- [Troubadour-Reskin] [F] Ponytail [M] Deacon v2 Repal by Pikmin1211, Gabriel Knight, Maiser6, Lisandra_Brave, TheBlindArcher.
- [Valkyrie-Reskin] [F] Ponytail [M] Templar Repal by UltraFenix, Seergiioo, Gabriel Knight.
- [Dancer-Base] [F] FE8 Tethys Repalette by Sirknite31.

-|MAP-SPRITES|-
---------------
- SALVAGED, Flasuban, Pikmin, Nuramon, CelestiaHeart, Agro, ltranc, RobertFPY, DerTheVaporeon, ArcherBias, Ash3wl, L95, Bowgun, Blood, NYZgamer3, Pushwall, Duckbeard, Alusq, FEGirls, Skitty, StreetHero, Brober, Spud, LonkFC, TyTheBub, Dei, Dondon151, Yellowtoad, Epicer, Dora Drago, MeatOfJustice, CamusZekeSirius, Teraspark, Tdim, Permafrost, ZeroXA, Unknown.

-|ITEM-ICONS|-
--------------
- Batima, Topazlight, Seal (SacredWar), Beansy, Plant Academy, Celice, Leif, LordGlenn, FuriousHaunter, Lisandra Brave, Zarg, 2WB, Lovemachine, Kyrads, Snakey1, Ereshkigal, SacredStones, XVI.

-|CLASS-CARDS|-
---------------
- SALVAGED, Topazlight, SamirPlayz, Cygnus, Flasuban, RobertFPY, MeteorSR23, Nuramon, N426, Ghast, HyperGammaSpaces, Leif, Scraiza, Sword of HaE, ltranc, Leo_Link, DerTheVaporeon, NoelWoodsoul, TheBlindArcher, Rasdel, Epicer, Spud, Aruka, Yggdra, Pushwall, Unknown.

-|MAGIC-ANIMS|-
---------------
- [Other] Sword Wave by Lovemachine, Mikey Seregon.
- [Ice] Aqua by Alusq.
- [Wind] Wind Fast Long by JeorgeReds, Alice.
- [Thunder] Thundaga by 7743.
- [Light] Hvitrwolf by Orihara_Saki.
- [Light] Divine Sigil by SHYUTERz.
- [Light] Artemis by Arch.
- [Dark] Svartrsnake by Orihara_Saki.
- [Dark] Svartr Calamity Gate by Orihara_Saki.
- [Dark] Imhullu - Heroes by Norikins.

-|SOUND-ROOM|-
--------------
- 03: Fire Emblem 5 - Map A by Dolkar. © Intelligent Systems/Nintendo
- 05: Fire Emblem 4 - Disturbance in Agustria by SurfingKyogre. © Intelligent Systems/Nintendo
- 06: Fire Emblem 4 - Army of Grannvale 2 by SurfingKyogre. © Intelligent Systems/Nintendo
- 17: Fire Emblem 10 - Ascent by SurfingKyogre. © Intelligent Systems/Nintendo
- 23: Daggerfall - Privateer's Hold by MeteorSR23. © Bethesda
- 25: Chrono Trigger - Battle 2 by Tristan Hollow. © Square Enix
- 26: Fire Emblem 10 - The Devoted by SaXor the Nobody. © Intelligent Systems/Nintendo
- 27: Final Fantasy Mystic Quest - Boss Battle by Sme. © Square Enix
- 28: Chrono Trigger - Boss 2 by RandomWizard. © Square Enix
- 29: Fire Emblem 4 - Vs Arvis by SaXor the Nobody. © Intelligent Systems/Nintendo
- 30: Fire Emblem 5 - Vs Veld by SurfingKyogre. © Intelligent Systems/Nintendo
- 33: Fire Emblem 6 - Healing [Imported Directly]. © Intelligent Systems/Nintendo
- 34: Fire Emblem 6 - Curing [Imported Directly]. © Intelligent Systems/Nintendo
- 35: Fire Emblem 11 - Leaps and Bounds by SaXor the Nobody. © Intelligent Systems/Nintendo
- 50: Fire Emblem 9 - With Us by Sme. © Intelligent Systems/Nintendo
- 55: The Legend of Zelda: Twilight Princess - Shop by Sme. © Nintendo
- 56: The Legend of Zelda: Ocarina of Time - Shop by Sme. © Nintendo
- 58: Final Fantasy VIII - Mods de Chocobo by RSflame. © Square Enix
- 59: Fire Emblem 6 - Attack! by Tristan Hollow. © Intelligent Systems/Nintendo
- 71: Fire Emblem 6 - Within the Magnificent Nature [Imported Directly]. © Intelligent Systems/Nintendo
- 72: Fire Emblem 7 - Shadow Approaches [Imported Directly]. © Intelligent Systems/Nintendo

-|MISCELLANEOUS|-
-----------------
- Velvet Status Screen by Cynon.
- FF9 Inspired Battle Screen by Cynon.
- Staff/Dance option's icon by Blood (Sacred Trilogy).
- All of the hacking tutorials made at FEUniverse.
- FEBuilderGBA for FEGBA hacking by 7743.


Enjoy And Have Fun Playing FE8:TRS!