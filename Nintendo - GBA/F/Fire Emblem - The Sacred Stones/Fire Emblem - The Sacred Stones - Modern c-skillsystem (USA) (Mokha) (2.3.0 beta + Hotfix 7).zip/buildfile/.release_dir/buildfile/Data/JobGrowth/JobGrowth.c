#include <common-chax.h>
#include <lvup.h>

struct JobGrowthEnt const gJobGrowthList[0x100] = {};
