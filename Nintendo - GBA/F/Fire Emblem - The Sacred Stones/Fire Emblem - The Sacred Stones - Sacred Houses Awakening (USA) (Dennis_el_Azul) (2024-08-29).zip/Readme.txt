Fire Emblem: Sacred Houses Awakening is a kind of PME (Pick My Edits) romhack of Fire Emblem: The Sacred Stones. At first I only wanted to do a "Can you beat FETSS with the FETH lords?" but I changed my mind and added other FETH characters (with the available portraits in the FE-Repo) and also Awakening characters.

The hack is made for fun, don't care if something makes the game more easy (and still there some changes that make it more challenging), play the way you want and have fun. This is for people who like to replay FETSS but with a twist and using characters from another game.

I plan to do two more versions, but I still need to test a bit more the main one:
- Extra experience (so you can switch more your characters for different strategies and make the game more easy for you).
- Fun Version (What are those creatures? Why the chickens are letal? THIS IS SPARTAAAAAA!)

The game includes some gameplay changes:
- Changes in some weapons (the Relic Weapons are there).
- Unlock extra units by playing (some are a bit overpowered, use them if you want).
- Growth rates changed to fit the characters and, in the case of FETH characters, I chosed one of their usual final class to change the growths in FETSS.
- From the main characters the only one that has their stats changed is Edelgard, since she uses axes insted of swords it fits better for her having Hector stats instead of Erika stats.
- Some bows have more range.
- Some classes were changed or at least reskinned.
- The weapon triangle is doubled in accuracy and tripled in damage. Because of this, swords designed to fight against lance units (knights or wyverns) got +30 of accuracy. Some green units that can be recruitable were given reaver weapons to avoid them be killed, so they can defend themselves. Other not recruitabled green units were buffed.
- Promotion branches were changed in some classes.
- Gain support points by being near instead of adjacent.
- Added a buyable Flamestone to continue using the manakete (not as effective as the Dragonstone).
- The behaviour of some enemies change.
- If you find yourself lacking money, you can buy free weapons from the preparation shop that are joke weapons with no extra damage, but it can be useful for not softblocking yourself or against weak enemies.
- If you find yourself with a lot of money, you can buy promotion items from the preparation shop.
- The tower of Valni and the Ruins bosses give you money, that's to avoid softlock but I know some players avoid using the tower to train, so it's something you don't need but there's if you want.
- For the sake of testing, I added cheat weapons, you can use them if you want (but you'll be labeled as a cheater).

The selection of characters is my own and is also based in the available portraits and how well they can fit in the position of some characters.

- I know Kent and Sain are not from FEA neither from FETH, they are the only exception (and maybe the first Christmas cavalliers of many Fire Emblem players).
- Lysithea can use dark magic, maybe that broke a bit the character (or not because she doesn't have a lot of constitution), I made that because she uses mainly dark magic in FETH (and she can also use Fire if changed to be a mage).
- There's a reason why Hilda have an Orion's Bolt, I think you can suppose why she appears with one.
- Edelgard and Dimitri have two promotion options, if you don't use the bracelets when given the option you can use them later and choose what you want.
- The growthrates of Shez are weird, but since she comes from a musou instead from a tactics game can be understandable. She's based in her mirmidon class, if I've choosen a more advanced class her growths would be more crazy!

CREDITS:

I thank the Fire Emblem community for creating and sharing their content for hacks. I also thanks the creators of FEBuilderGBA, thanks to their tool this hack was possible.

I got the resources I used from https://github.com/Klokinator/FE-Repo, some of the items used in development are not final but I add them in the credits because I used them in development and I think they have the quality to be mentionet.

Portraits:

If you want to discover by yourself the new roster, don't look!

Alois {UltraxBlade}
Anna {NickT, Stitch}
Aversa {Garytop}
Basilio {Garytop}
Bernadetta (Redbean)
Brady (ShadowFlygon)
Byleth {Sterling Glovner}
Catherine {Garytop}
Cherche {BuskHusker}
Chrom (Atey, Wasdye)
Claude {Melia}
Cordelia (BuskHusker)
Dimitri {Melia}
Donnel {Garytop}
Edelgard {Redbean}
Ferdinand {MeatOfJustice}
Flayn {Redbean}
Frederick {Garytop}
Gaius {Garytop}
Gatekeeper {Exca}
Gerome {Garytop}
Henry {Garytop}
Hilda {Garytop}
Hubert {Raymond}
Kellam {Garytop}
Kent Eldritch Abomination
Kjelle {Garytop}
Leonie (Post-timeskip) {Tobiki}
Libra {Garytop}
Linhardt (Post-timeskip)  {HyperGammaSpaces}
Lon'qu {Lonkfromcalifornia}
Lucina (New) (TheImperialKnight)
Lysithea (Post-timeskip) {RedBean}
Marianne {Tobiki}
Meg {NickT, Stitch}.png
Mercedes {Blade}
Nah {Garytop}
Nowi {Garytop}
Oliver {NickT, Stitch}
Olivia {RedBean}
Raphael (Three Hopes) {Stitch}
Ricken {Garytop}
Robin Male (SatoshiKura)
Sain Eldritch Abomination
Severa {Garytop}
Shamir {Wasdye}
Shez (Female) {Kanna}
Stahl {Garytop}
Sumia {Garytop}
Sylvain (Post-timeskip) {ZeMedic}
Tharja {Garytop}
Yuri {HyperGammaSpace}


Battle Animations:

[Assassin-Reskin] Leila by SHYUTERz
[Cavalier-Variant] F  Generic SALVAGED
[Cavalier-Variant] Generic SALVAGED
[Dancer-Base] Vanilla Tethys +Weapons
[FE8 [F] Heavy by Nuramon
[FE8 [F] Vanilla +Weapons
[FE8 [M] Heavy by Nuramon
[FE8 [M] Vanilla +Weapons
[Fighter-Reskin] Tellius-Style by Leo_Link
[General-Reskin] Amelia Ponytail
[General-Reskin] Amelia Redbean
[Hero-Reskin] FE7 +Blue Shield
[Knight-Variant] Amelia SALVAGED
[Ranger-Custom] Bernadetta Redbean
[Sage-Custom] Limstella by +Palettes
[Soldier-Custom] FE15-Style Nuramon
[Swordmaster-Variant] Fir Redbean
[T2 [F] Priestess Repal
[Trickster] Trickster by Leo_Link
[WL [U] by Nuramon
[Zephiel-Reskin] Bulwark by Link
[Archer-Reskin] [F] Der's Short Hair
[Archer-Reskin] [M] Der's Wil
[Assassin-Base] [M] Hood by Jey the Count
[Brigand-Reskin] [M] FE13-Style by Iscaneus
[Brigand-Reskin] [M] Wolf by CookieMaster
[Brigand-Reskin] [U] Lizard Brigand Wildling
[Cavalier-Variant] [F] Generic v2 by SALVAGED
[Cavalier-Variant] [M] Generic by SALVAGED v2
[Centaur-Variant] [M] CentaurZerker by Alexsplode
[Cleric-Reskin] [F] FE13-Style
[Custom Halb] [F] Halberdier - Gwendolyn by UltraFenix
[Custom Magi] [F] Witch v2 Repal by Aruka
[Dancer-Base] [F] Vanilla FE8 Tethys +Weapons
[Dragon-L95] [U] Divine Dragon Tiki by Jotari
[FE7 Eliwood Variant] [F] Generic -Titania Knight
[FE7 Lyn-Variant] [M] T1 Blader Myrmidon
[Fighter-Reskin] [M] Tellius-Style Clothing by Leo_Link
[General-Reskin] [M] Baron Cape +Weapons
[Great Lord-Custom] [M] Master Knight by St Jack
[Knight-Variant] [M] Generic by SALVAGED
[Monk-Base] [M] Repal by Eldritch
[Monster-Custom] [U] Phantom by TBA
[Myrmidon-Reskin] [F] Fir by Redbean
[Paladin-Custom] [U] Gold Knight v2 by Nuramon
[Ranger-Variant] [F] Leo-Style +Weapons
[Skeleton-Reskin] [U] Legion by Seal (1)
[Skeleton-Reskin] [U] Legion by Seal
[Sniper-Variant] [F] Neimi by Aruka
[Soldier-Custom] [M] FE15-Style by Nuramon
[Spider-Reskin] [F] Older Bael Queen
[Sword FE16 Custom] [F] Dread Fighter by Nuramon
[Sword FE16 Custom] [M] Dread Fighter by Nuramon
[Swordmaster-Variant] [F] Fir by Redbean
[Swordmaster-Variant] [F] Trueblade by Steaming Tofu
[T2 Bishop-Base] [F] Repal by Eldritch
[T3 Necromancer] [M] Generic by Eldritch
[Trickster] [F] Trickster V.2 by Leo_Link
[Trickster] [M] Trickster V.2 by Leo_Link
[Warrior-Custom] [F] Camilla by SteamingTofu
[WL Reskin] [U] Armored by Nuramon
[Zombie-Custom] [U] Gore by Alexsplode
[Custom DM] [F] Dark Mage Tharja by SteamingTofu
[Custom Magi] [F] Witch Rinea (Vestal) by Nuramon
[FE13-Custom] [F] War Cleric Dress edit by TytheBub
[FE13-Custom] [M] War Monk by DerTheVaporeon
[Fighter-Variant] [M] FE9 Repal by Glenwing
[Great Lord-Custom] [F] Master Knight by St Jack
[Mage-Reskin] [F] Long-Hair by Solum
[Myrmidon-Reskin] [F] Leo_Link's Alt
[Soldier-Reskin] [F] Ponytail by Dr0zz
[Swordmaster-Reskin] [F] Karla Repalette by Greentea
[T3 Necromancer Alt] [M] Warlock by Jey the Count
[Troubadour-Base] [F] Vanilla FE7 +Swords by TBA

Class Card:

Bael Widow {MeatOfJustice}
Bonewalker Legion {Seal}
Gold Knight (U) Lance {Nuramon}
Mage (F) Hoodless {L95}

Map Sprites:

Bael (F) Queen {Seal}
Dread Fighter (M) {Nuramon}
Druid (F) {IS}
Gold Knight (U) Lance {Hypergammaspaces}
Great Lord (M) Ephraim-Infantry Lance {Snewping}
Knight (U) FE10-Hybrid-Style Lance {Nuramon, flasuban}
Lord (F) Eirika Axe {FE7if}
Lord (F) Hector Axe {Shin19}
Marshall (U) Axe {Nuramon}
Saint (F) {Melia}
Sergeant (F) {Spud, Dora Drago}
Shaman (F) {IS}
Soldier (M) Shield Lance {Rexacuse, Peerless, Alusq}
Warrior (F) Camilla {SteamingTofu}

Icons:

{Zelix} Modern FE Weapons (271)
Also icons from: Beansy, Blitz, SMITHYGCN, SacredStones (if I forget someone let me know)

Backgrounds:

Final Fantasy I & II Advance backgrounds ripped by Vanarus and Ryan914; Final Fantasy IV Advance backgrounds ripped by Bean; Final Fantasy V Advance backgrounds ripped by Valoc Dakmyre; I got them from Spriters Resource. All backgrounds were ported by me (Dennis el Azul).