Apply .ups patch to a clean US FE8 ROM

KNOWN ISSUES
- On rare occasions, the game may softlock at the end of a chapter. Should this happen, close the game/emulator, open it again and resume the suspended game until the game proceeds as normal.
- The unit statsheet's "talk" display does not work properly and may be incorrect at camp. Ignore it, select Kyra and check which units have talk icons over their heads instead.
- The repair hammer's menu display and animations are slightly glitchy. This is only a visual issue, disregard it.
- Standing on a ballista while attacking will glitch out the attack range display. This is a common and as of yet unsolved bug with SkillSys. Ignore it, as it is merely visual.
- On fixed growths mode, growth modifying skills cease to function. This does not affect the mind scroll, but it does affect the personal skills of two units, who only have them for flavor and will have a worse performance due to this. Turning off fixed growths will restore the skills' functionality.
- If you notice anything else, typos, mistakes, glitches, don't hesitate to let me know!

TIER LIST CREATORS
Chapters: https://tiermaker.com/create/fire-emblem-the-hag-in-white-chapter-tier-list-16617653
Characters: https://tiermaker.com/create/fire-emblem-the-hag-in-white-character-tier-list-16617653

CHARACTER POPULARITY POLL
https://docs.google.com/forms/d/e/1FAIpQLSe5T-Vb1XcROIqjTWb_T0xxqxihc42bRLptKG97lT_VfPSp3A/viewform