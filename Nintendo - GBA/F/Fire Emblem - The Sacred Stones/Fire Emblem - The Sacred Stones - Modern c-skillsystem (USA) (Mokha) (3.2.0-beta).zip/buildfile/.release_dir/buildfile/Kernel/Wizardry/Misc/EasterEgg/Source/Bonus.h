#pragma once

#include <common-chax.h>
#include <stdnoreturn.h>

void GiveKernelBonus(void);
noreturn void StartKernelBonusScreen(void);
