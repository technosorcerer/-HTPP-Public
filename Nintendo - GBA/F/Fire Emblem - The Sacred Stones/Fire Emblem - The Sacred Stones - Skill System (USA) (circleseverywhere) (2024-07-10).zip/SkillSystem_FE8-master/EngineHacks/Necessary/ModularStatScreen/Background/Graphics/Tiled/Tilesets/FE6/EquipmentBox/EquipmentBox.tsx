<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="2020.12.18" name="EquipmentBoxTiles" tilewidth="8" tileheight="8" tilecount="96" columns="32">
 <image source="EquipmentBox.png" width="256" height="24"/>
</tileset>
