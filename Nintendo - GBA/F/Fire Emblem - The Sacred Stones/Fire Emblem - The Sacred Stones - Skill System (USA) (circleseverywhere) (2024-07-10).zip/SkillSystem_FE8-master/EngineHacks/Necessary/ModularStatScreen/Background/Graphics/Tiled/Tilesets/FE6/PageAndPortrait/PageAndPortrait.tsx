<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="2020.12.18" name="PageAndPortraitBoxTilesFE6" tilewidth="8" tileheight="8" tilecount="128" columns="32">
 <image source="Blue.png" width="256" height="32"/>
</tileset>
