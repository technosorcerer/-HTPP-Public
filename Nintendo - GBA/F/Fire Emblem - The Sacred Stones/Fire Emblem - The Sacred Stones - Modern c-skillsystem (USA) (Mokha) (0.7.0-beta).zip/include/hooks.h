#pragma once

#include "common-chax.h"

extern struct CharacterData const * const gpCharacterData;
