Credits

Animations (Format: Contributor - Repo Animation Name):
TBA - Knight(Sword), Knight(Axe), Mercenary(F), General, Falcoknight(Black Beauty)
Orihara_Saki - Soldier(Sword)
Nuramon - Pirate(F), General, Wyvern Lord(Armored)
MarioKirby - Pirate(F)
Wan - Pirate(F), Wight(Axe/Handaxe)
Pikmin1211 - Nomad(Non-Sacaen Repalette), Natserker, Spartan
Maiser6 - Nomad(Non-Sacaen Repalette), Mercenary(M)
eCut - Nomad(Non-Sacaen Repalette), Natserker
Mikey Seregon - Wyvern Rider(Axe), Nino Pale Flower
Alfred Kamon - Wyvern Rider(Axe), Wicked Flier
Arthur Pendragon - Soldier(Sword)
Flasuban - Priest(Improved Repalette), Pegasus(Improved), Falcoknight(Improved)
Eldritch Abomination - Priest(Improved Repalette)
Vilkalizer - Bonewalker(Axe/Handaxe), Spartan
Teraspark - Wight(Axe/Handaxe), Ranger(Rebecca)
Alusq - Mercenary(M)
DerTheVaporeon - General, War Cleric, Swordmaster(Lloyd Alt), Paladin(Bow)
GabrielKnight - General(Bow Cannon), Samurai
Serif - Natserker
Skitty - Natserker
shadowofchaos - Falcoknight(Black Beauty)
St Jack - Wyvern Knight(Axe), Hero(F,Reskin)
Blue Druid - Wicked Flier
Leo_link - War Cleric, Trickster(M)
Iscaneus - War Cleric
RedBean - Nino Pale Flower, Sage(Lilina)
Marlon0024 - Nino Pale Flower
yikes - Nino Pale Flower(Staff)
Greentea - Swordmaster(Lloyd Alt)
Cybaster - Trueblade
Dolkar - Rifleman
Shtick - Sage(Fast F)
L95 - Sage(Fast F)
Russell Clark - Swordmaster(F)
Huichelaar - King, Executioner
Obsidian Daddy - King
KirbyFreak - King
Shin19 - Sage(Lilina)
JonoTheRed - Supplier(F)
Marlon&Louis - Sonneteer
Beansy - Bishop(M, Sword)
BwdYeti - Swordmaster(F, Scarf)
FEif - Swordmaster(F, Scarf), Limstella v1
SixThousandHulls - Pegasus Knight(M)
Itranc - Paladin(Bow)
Genocike - Paladin(Bow)
Kao - Paladin(Bow)
Gamma - Sage(Gaiden Priestess)
knabepicer - Knight(Staff)

Icons (Format: Contributor - Item Name in Hack):
Beansy - Converge, Sloth, Glock 19
CamTech075 - Hail, Pride
LordGlenn - Haste Banner, Scathe, Rend, Gluttony, Fortune Rune
Peerless - Vesper, Catastor
Zane - Cipher, Ooze, Rush Lance, Valor, Water
Zelix - Rage Banner, Steyr AUG, Lucky Lance
Lisandra_Brave - Heal Spray
Snakey1 - Shock
SacredStones - Envy
Celice - Mind Banner, Azure Bow, Agility Rune
Seal - Chalice, Judgment, Vainglory
Zarg - Lionheart Badge

Map Sprites (Format: Contributor - Class Name in Hack):
Agro - Mercenary(F)
DerTheVaporeon - Captain, War Cleric, General
Unknown - Questant, Sunblade
FE7if - Traveler
flasuban - Armor Cleric
Nuramon - Trueblade
Elibean Nights - General
L95 - General
Pikmin1211- General
Huichelaar - General, Executioner
N426 - Merchant
Marlon&Louis - Troubadour
MeatOfJustice - Adventurer
Lexou - Executioner

Maps (Format: Contributor - Referencing Chapter):
Aurawolf - 3, 4, 14, 15
ZoramineFae - 19, 20

Mugs (Format: Contributor - Character Name in Hack):
Obsidian - Luna
Xenith - Mika
Guiltykappa - Raiden
XVI - Grace, Jupiah, Naio, Goldbrandt
NICKT - Guha, Victor
MrGreen3339 - Taki
LaurentLacroix - Dahak, Haruna, Kenzou, Belle, Elise, Gonta, Cassandra, Jorgandr, Ashura, Fenrir
P33RL355 - Osen
flasuban - Michael, Faye
Mycahel  Michael
Zoisite - Lennart
SSHX - Curtis, Masaya
cravat - Sharon, Vijay
knabepicer - Maitreya
Nobody - Ballor
RandomWizard - Agron, Uahd, Wudash
GabrielKnight - Hunter
FEier - Dion, Anna
Melia - Dago
Lenh - Takeuchi
Robinjonator - Mika
Miguel-Rojo - Kagemusha
CanDy - Chaos
Raymond - Fenrir
CapibaraInSpace - Fenrir
Splinterocke - Fenrir
Glaceo - Generic Unit
Mr_Karkino - Generic Unit
HyperGammaSpaces - Generic Unit
Mycahel - Alioth
Citrus - Ilya

Music (Format: Ripper/Composer - Song(Source)):
Pandan - Treasure Hunt(Yoshi's Story), Jolly Roger Bay(Banjo Tooie)
SaXor_the_Nobody - Maria Sortie!(Knights in the Nightmare), Sortie Formation(Knights in the Nightmare)
RandomWizard - Sky Peak Final Pass(Pokemon Mystery Dungeon Explorers), The Demon King Odio(Live-A-Live)
Alusq - Anxiety(Final Fantasy Tactics), Decisive Battle(Final Fantasy Tactics)

Spell Animations (Format: Contributor - Repo Animation Name):
Alusq - Aqua
Mikey_Seregon - Hail
Arch - Dulam, Mire-Slime, Static, Artemis
SHYUTERz - Luce
Seal - Divinestone
Sacred War - Divinestone
Orihara_Saki - Svartrblade