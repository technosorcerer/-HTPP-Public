# Portraits:
- Marth: Alusq
- Sheeda: FE3 Book 2 (Darrman)
- Chiki: FE3 Book 2 (Darrman)
- Marich: Alusq
- Rody: FE3 Book 2 (Darrman)

- Mario: Super Mario RPG (Darrman)
- Luigi: Super Mario World (Darrman)
- Peach: Super Mario RPG (Darrman)
- Bowser: Super Mario RPG (Darrman)
- DK: Mario Kart Wii (Sme)
- Toad: Super Mario RPG (Darrman)
- Wario: Mario Kart Wii (Sme)
- Daisy: Mario Kart Wii (Sme)
- Yoshi: Mario Kart Wii (Sme)
- Waluigi: Mario Kart Wii (Sme)

- Ash: Pokemon Anime (Darrman)
- Misty: Pokemon Anime (Darrman)
- Brock: Garytop
- Jessie: Pokemon Anime (Darrman)
- James: Pokemon Anime (Darrman)
- May: Pokemon Anime (Darrman)
- Dawn: Pokemon Anime (Darrman)
- Serena: Pokemon Anime (Darrman)

- Link: BatimaTheBat
- Samus: Fenreir
- Kirby: Super Smash Bros (Darrman)
- Fox: Super Smash Bros (Darrman)
- Pikachu: Pokemon Red/Blue (Darrman)
- Falcon: Garytop
- Jigglypuff: Pokemon Red/Blue (Darrman)

- Ness: Earthbound (Darrman)
- Paula: Earthbound (Darrman)
- Jeff: Earthbound (Darrman)
- Poo: Earthbound (Darrman)
- Pokey: Earthbound (Darrman)

- Cecil: Final Fantasy 4 (Darrman)
- Butz: Final Fantasy 5 mobile (Darrman)
- Terra: Final Fantasy 6 (Darrman)

- Lucina: Garytop
- Lyn: FE7
- Leaf: FE4 (Darrman)
- Byleth: FE16 (Darrman)
- Alear: Jey the Count
- Kris: FE12 (Darrman)

- Caesar: FE3 (Darrman)
- Ryan: FE3 (Darrman)
- Luke: FE3 (Darrman)
- Boucheron: FE17 (Darrman)
- Clanne: FE17 (Darrman)
- Vander: FE17 (Darrman)
- Alfred: FE17 (Darrman)
- Celine: FE17 (Darrman)
- Diamant: FE17 (Darrman)
- Alcryst: FE17 (Darrman)
- Ivy: FE17 (Darrman)
- Hortensia: FE17 (Darrman)
- Timerra: FE17 (Darrman)
- Fogado: FE17 (Darrman)
- Veyle: FE17 (Darrman)
- Louis: FE17 (Darrman)
- Alfonse: FEH (Darrman)

- Alm: Atey
- Chalphy descendant/Celice: FE4 (Darrman)
- Eliwood: FE6 (Obsidian Daddy)
- Lilina: FE6 (Obsidian Daddy)

# Animations:

- Marth: Blaze/Abzel
- Chiki: L95 (dragon), Tykky (human), Jotari (transformation)
- Infantry: Advance Wars (Amyd, Dark)
- Anti-Air: Advance Wars (Amyd, Dark)
- Tank: Advance Wars (Amyd, Dark)

# Map Sprites:
- Marth: Dominus_Vobiscum, Snewping

# Maps:

- Somniel: Darrman
- Warren: FE1 Ch8 (Darrman)
- Lefcandy: FE1 Ch7 (Glaceo for GFE1R)
- Devil Mountain: FE1 Ch3 (Sme, Nickt for GFE1R)
- Outside Pales: FE1 Ch11 (Shuusuke, Nickt for GFE1R)
- Pales: FE1 Ch12 (Sme for GFE1R)
- Garda: FE1 Ch2 (Kirb, Nickt for GFE1R)
- Talis Castle: Darrman
- Talis: FE1 Ch1 (Kirb, Nickt for GFE1R)

# CGs:
- Mario: Super Mario 64
- DK: Donkey Kong Country
- Link: The Legend of Zelda: A Link to the Past
- Samus: Super Metroid
- Yoshi: Yoshi's Island
- Kirby: Kirby Super Star
- Fox: Star Fox 64 3D
- Pikachu: Pokemon Red/Blue
- Luigi: Super Mario Bros 2
- Peach: Mario and Luigi: Superstar Saga
- Bowser: Super Mario World
- Toad: Mario Party 8
- Wario: Wario Land 2
- Daisy: Mario Party 6
- Waluigi: Mario Tennis
- Ash: Pokemon Anime
- Misty: Pokemon Anime
- Brock: Pokemon Anime
- Jessie: Pokemon Anime
- James: Pokemon Anime
- May: Pokemon Anime
- Dawn: Pokemon Anime
- Serena: Pokemon Anime
- Falcon: F-Zero GX
- Jigglypuff: Pokemon Red/Blue
- Ness: Super Smash Bros
- Paula: Earthbound guidebook
- Jeff: Earthbound guidebook
- Poo: Earthbound guidebook
- Pokey: Earthbound guidebook
- Cecil: Final Fantasy 4
- Butz: Final Fantasy 5
- Terra: Final Fantasy 6
- All converted by Darrman.


# Music

- All FE3 music converted by Sme.
- FE11 Battle Preps: RSFlame

- Voice lines from:
- Marth: Fire Emblem Heroes
- Sheeda: Fire Emblem Heroes
- Chiki: Fire Emblem Heroes
- Mario: Super Mario 64
- DK: Donkey Kong 64
- Link: Super Smash Bros Melee
- Samus: Super Metroid
- Yoshi: Mario Kart Wii
- Kirby: Super Smash Bros Melee
- Fox: Super Smash Bros Melee
- Pikachu: Super Smash Bros Melee, Pokemon Red/Blue
- Luigi: Mario Kart 64
- Falcon: Super Smash Bros Melee
- Ness: Super Smash Bros Melee
- Jigglypuff: Super Smash Bros Melee, Pokemon Red/Blue
- Peach: Mario Party 1
- Bowser: Mario Kart Wii
- Toad: Mario Kart 64
- Wario: Mario Party 1
- Daisy: Mario Kart Wii
- Waluigi: Mario Kart Wii

- Converted by Darrman

# Other Graphics
- Status Screen: SaXor the Nobody

# Skill System Credits:

## Skill contributors

- Tequila
- Rossendale
- StanH
- Leonarth
- 2WB
- Teraspark
- Darrman
- SD9k
- Kao
- blademaster
- Snakey1
- Zeta
- Kirb
- Sme
- Ganzap
- Mikey Seregon

## Other

- 7743: various bugfixes
- RobertFPY, Pikmin1211, and Snakey1: Str/Mag Split Finalization

## Icons

- Monkeybard, Black Mage
- Blaze: Stances
- vlak: Drives
- Pikmin1211: Miscellaneous
- 2WB: Miscellaneous
- Zaim: Indoor March
- Reds: Quick Riposte

