Hi, thank you for opening this file. Please check the thread for more gameplay details.

If you want to use the resources I made for this game, please contact me beforehand.

Credits:
All resources from other people were taken from F2U sources. If I screwed up and you don't want to see your stuff here, just
contact me and I'll remove them. Also let me know if I missed someone.

Eventing and writing:
Shiza

Art:
All portrait splices made by me (Shiza). Some of the eyes were taken by Lehn's FE6 mugset. Charlie's, Lily's and Jacob's sprites were improved by Bwan.
Custom animations from the repo were made by:

-Ayr
-Beccarte
-Cipher Lee
-Circleseverywhere
-DerTheVaporeon
-Dis
-Greentea
-HIROTO
-Keks_Krebs
-Luerock
-MrNight
-Nuramon
-Pikmin1211
-SDK9
-SHYUTERz
-Teraspark
-ZoramineFae

Tilesets:
-N426
-Nathan
-HeartHero

Music:
-Alusq
-Dolkar
-Sme
-SurfingKyogre
-Mycahel
-MysteriousDancer
-pandan
-Swift Saturn
-The rest were arranged by me.

MIDI charters:
-8giraffe8
-Samidare
-ryoya1295
-ezequiel
