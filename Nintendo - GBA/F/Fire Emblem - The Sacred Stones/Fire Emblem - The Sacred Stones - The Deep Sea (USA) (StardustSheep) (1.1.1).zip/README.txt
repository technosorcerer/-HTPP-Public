All credits taken from FEBuilderGBA, created by 7743	
Essential Fixes	
Anti-Huffman	by Hextator
01command_hack	by Hextator
16 Tracks 12 Sounds	by Agro, Brendor
Remove Enemy Control Glitch	by Brendor
Handaxe Wildcard	by 7743
Fix Weak Promoted Enemies	by Gryz
EXP Formula Fix	by Vennobennu
Pierce Fix	by Brendor
Fimbulvetr Fix	by 7743
CAM1&2 Fix	by Stan (hail)
Enemy Growth Fix	by Stan (hail)
Prevent Healer Mistarget	by Magrika Is Now Canon
Bard Sound Fix	by 7743
Skip H&S, Splash Screens and New Game Intro	by circleseverywhere, Fati
Engine Hacks	
Autosave function	by aera
Change Level Penalties into Bonuses	by Shuusuke
Set Preps BGM per chapter	by aera
Set Battle & Victory BGM per chapter	by 7743
Convert Chapter Titles to Text	by circleseverywhere, 7743
Modern Talk & Support	by circleseverywhere
Continue BGM between map and combat	by 7743
Map Danger Zone	by circleseverywhere
drumfix	by circleseverywhere
Hide Creature Campaign and Link Arena	by aera
Battle Stats with Anims off	by Vesly, Tequila
FE8 Text Engine Rework	by Tequila, Zahlman, Stan, Black Mage and Eliwan, The Awful Emblem team
Enable Prf Staves and Items	by Tequila, jjl2357, 7743
Melee Magic Fix	by Tequila, Hextator, 7743
FillAIDangerMap Efficiency Fix	by hypergammaspaces, 7743
Fix dodge to front glitch	by Snakey1
lz77decompress fix	by Tequila
Range Display Fix	by Stan, 7743
HP Bars with warnings fix	by circleseverywhere, Tequila
Leader AI Fix	by Stan
Less Annoying Fog	by Leonarth
m4a hq mixer	by Ipatix
MapAddInRange Fix	by 7743
REDFE style MMB	by 7743, ZaneAvernathy
Unfuck portraits	by tiki
Narrow Font	by Scraiza, MintX
RNG Scrambler	by TR143
Show Heal Amount	by Tequila
Steal with full inventory	by Vesly
Faster Level Ups	by Tequila
Raise Dance and Steal EXP	by 7743
Slightly widens the song name display field in the sound room	by 7743
Faster Status Screen	by Contro
Unfuck Aircalibur	by aera
Make goal window text slightly longer	by Vesly
Make Lockpick available to anyone	by Shuusuke
Monster Weapon display fix	by Brendor
Omission of 1-second wait when displaying chapter titles	by 7743
Prevent uncounterable items from becoming forced range animations	by Vennobennu
Make combat faster	by 7743
Remove the menu that displays the support list from the preparation screen	by Shuusuke
Remove R text on the save screen	by Snek
Modify S-Rank Limits	by Tequila
Toggle Difficulty Select Skip	by Stan
Limitless Trading	by aera
Thracia Rescue Trading AKA Infinite Give and Take	by MintX
Unlock various restrictions of chapter 5x.	by Tequila
Tutorial Disabler	by 7743
Updated L Button Cycling	by Aurawolf
Native Instrument Map	by Alusq

Music
Tearring Saga ~ Prelude to Battle by sme
Valkyrie Profile ~ Nethov Swamp/Hopeless Resolution by myself
Runescape ~ Sea Shanty 2 by Lemon Tart
FE: Blazing Sword ~ The Inn by myself

Sprite Work
Warship sprites by ZarG
Fleet fixed standing sprites by Pushwall
Crescent Moon portrait by CardCafe
Title background ~ View of the Port of Brest by Jean Francois Hue according to pixels.com (February 25th, 2024)
Hammer sprite by Ereshkigal
Orange sprite by MeatOfJustice
Open Fire! sprite by Beansy
Yikes! Snipers! sprite by LordGlenn
Yarr, Matey! sprite by LordGlenn

If I have forgotten anything, *please* let me know.