﻿TheMasterAtNothing Ruins Fire Emblem 8: The Sacred Stones


Champion's Emblem: The Goat's Zenith of Receding Hairlines


“Instead of asking why, we ask ‘Why Not?’”




Summarization


This is a hack of Fire Emblem 8 created by TheMasterAtNothing, a random person. I picked up FEBuilder and proceeded to create this trainwreck of a romhack.
The hack has been… “balanced”... around Difficult/Hard mode.
I would NOT recommend this to any casual player, it’ll just be a huge headache. However, if you want to see Fire Emblem 8: The Sacred Stones ruined beyond repair, this is the hack for you.
This hack is what’s known as a “PME” (Pick My Edits) where I get bossed around by random people to add stuff into the game. As someone who literally picked up FEBuilder for the first time,
this being my first ever hack, this has actually been a wonderful learning experience that I’d recommend others to try out if they want to pick up FEBuilder.

2 tips you want to be 100% sure of:

Check enemy weapons.
gun

Credits are at the bottom of the file.










Don’t go any further if you wish to be surprised by this hack’s contents.










Full Changelog






-=Changes=-






=-Of my own volition (By TheMasterAtNothing):-=


Hitrates nerfed by 10, few exceptions instead nerfed by 5
Silver, Brave, and Effective weaponry have increased durability.
All weapons have at least 20 Uses, unless it’s a siege tome.
Silver, Slim, and Effective weapons have increased crit.
Hammer and Devil Axe now have more Might, but more Weight.
Silver weapons have more Might.
Blades are cool now.
Eirika starts at level 3.
Lute has Forseti.
Light tomes have more crit.
Most statboosters have halved effects, but 2 uses.
Rapier is now a D rank sword.
Eirika has a new Prf with low Might and the Brave effect.
Eirika has a Speed Ring, which increases Speed by 5 and Move by 1.
Seth now starts as a Level 16 Cavalier with stats to match. Seth also has a “Power Limiter” sword with low Might, lots of Weight, and a Defense Bonus.
Joshua has Gamble.
Neimi has a Brave Bow and Colm has a Silver Sword, both with appropriate Weapon Ranks.
The Crusader Scrolls from Fire Emblem 5: Thracia 776 exist now, distributed throughout the game. Time to train Colm.
Bazba has a Knight Crest, for Seth. This is in Colm’s joining chapter.
Garcia has a Skill Ring to help with self-defense to compensate for lowered hitrates.
All trainee units have Paragon.
The Ephraim Gang have been given an Iron Lance and an Iron Blade.
Pent has Forblaze.
Joshua comes prepared.
Full list of new weapons: Durandal, Armor Destroyer, Armor Deleter, Balmung, Forseti, Ragnell, FE9 Iron Sword, Slimmer Lance, Falchion, Falchion,
FE11 Iron Lance, FE5 Iron Axe, FE5 Iron Bow, Mani Katti, FE4 Brave Sword, FE5 Brave Sword, Wolf Beil, Wing Spear, Tyrfing, Fujun Yumi, Binding Blade,
Lady Blade, Unyielding Blade, Iron Sword & Shield, Rex Hasta, Rienfleche, Armads.
Promoted classes have a max HP stat of 80.
Green Units have been granted more levels and equipment to compensate for stronger enemies. (And to fight green unititis)
Everyone has personal skills, mostly loosely based off of FEMSPaint’s video on the matter.
Most enemy units have been granted more powerful weapons, and weapon drops are more common.
Promoted Class Max Stats increased.
Metis’s Tomes have been distributed throughout the game. There are more on Ephraim’s route, but they’re also harder to get.
Class Promotion Gains tripled. Promoted Max Stat Increases doubled.
Some bosses have been granted level bonuses, they were too easy.
Any enemy in the last few chapters with a level of 10 or lower have been granted 10 extra levels. For example, a Swordmaster on Chapter 17 has 32 speed.


=-By suggestion:-=


-=FEMSPaint’s Discord:
Natasha has Hammerne.
Ewan now has Grafcalibur.
Assassins have a strength cap of 30, and gain 10 speed on promotion.
Naglfar has been buffed.
Kyle and Forde now have improved bases in their weak spots.
Duessel no longer exists, say hello to Duessell.
Juna Fruits are now purchasable in the Preparations Armory.
A new character named Koishi will appear on a few maps. Be prepared.
Marisa is now a very funny unit.


FEMSPaint:
Say “Bye Knoll”! Say hello to Goku.


-=Mythril Zenith’s Discord:
Eirika has another Prf in the form of Ragnell with 12 Weight.
Sieglinde has 1-2 Range.
Seth’s kneecaps have been broken, granting him a large bonus of -5 Speed.
Gilliam now starts as a Level 10 General with heavily increased Bases.
Gilliam also owns a Slimmer Lance.
Saleh no longer exists, and has been replaced by Pent.
Lute now has an “Airhorn” Tome.
All enemies have +25% (Additive) to their growths. DEF, RES, and LCK were excluded because I’m not a sadist, just evil.


Mythril Zenith:
Placed most of the Crusader Scrolls.


-=BadAtFireEmblem’s Discord:
Female Mages, Sages, and Mage Knights now fly, and have flier weaknesses.
Innes now has the Fujun Yumi.
Valter moves on Turn 10.
Summoners no longer exist.
Say hello to Axe Druids!
Eirika summons Phantom Ephraims.
Artur has been erased from this plane of existence.
Welcome Grieg.


-=Mekkah’s Discord:
1-2 Range has largely been removed from the entire game.
Neimi no longer exists, and has been replaced by Archer Mozu. Brave Bow is intact.


I could've had more weapon locks, but it looks like the SkillSystems patch or whatever kinda stopped me from doing that.





Credits (aka stuff I used from other people because they make cool stuff):
Fujun Yumi, Binding Blade, Lady Blade, Double Bow, Ragnell, Parthia, Forseti sprites by Batima
Grieg portrait by oersted_lal on Discord
Mozu portrait from https://feuniverse.us/t/garytops-display-cabinet/16303/173


Battle Animation Credits:
[Swordmaster-Reskin] Marisa : F2U/F2E Animation by Red Bean. Scripting by Marlon0024. Improved + Fixed script by Seliost1 and 7743.


[Swordmaster-Reskin] Guy : F2U/F2E Made by Eldritch Abomination.


[Assassin-Reskin] Marisa : Made by Red Bean. Scripted by Sable Mage. 1. Sword (Knife Ranged) by Seliost1.


[Thief-Reskin] Matthew Repal : F2U/F2E Made by Red Bean. Repal by Seliost1.


[Peg T1 Base] Repal v2 + Weapons : Sword/Lance/Axe/Handaxe/Unarmed/Repalette by Flasuban. Unarmed palette fix by UltraFenix. Magic by UltraFenix, using Light Mage by Leo_link and L95 as base.


[Peg T2 Variant] Falcoknight v2 +Weapons: Improved Falcoknight by Flasuban. Bow by Knabepicer, Nuramon.


[WK Base] Repal +Weapons: Repalette by Feaw. Sword by Lord_Tweed. Axe and Handaxe by St Jack. Bow by ltranc. Note that this repalette basically replaces the vanilla animation. With all the new weapon types and the superior repaletted colors, there's no real reason to use the vanilla version.


[WL Reskin] Helmetless +Axe: Helmetless version by Flasuban. Axe and Handaxe by TBA.


[WR Reskin] Repal : Vanilla animation by IS. Sword by SamirPlayz. Axe and Handaxe by eCut Bow by PrincessKilvas, Spud, Blue Druid. Repal by UltraFenix. Extra frames inspired by Leo_link's Armless Wyvern animation


[General-Reskin] Female General : Female/Long haired General By RiriK/Rikki Original General Sword Chain animation by Knabepicer Credit to Redbean for certain parts Credit to Marlon&Louis Fire Hacks' patches that included the original map sprites for [Marshal], who I believe is by Nuramon, so also credits to him as well (Marshal (M) Zelgius Helmless Sword Map Sprite) Credit to GabrielKnight for the original Bow (Cannon) General


[Knight-Custom] FE10-Style : Base still made by Iscaneus. Animation and scripting by Nuramon and Jeorge Reds. Magic by flasuban. Unarmed with quiver and critical recoil bow edits by Topaz Light.


[Knight-Variant] Amelia : Animation by RedBean.


Infantry Unit Animations are by Amyd Dark, IS, Yera.


[T2 Summoner-Base] Vanilla +Axes : F2U/F2E Vanilla animation by IS. Axe and handaxe by Spud, TBA. Fixes to the magic animation(???) by Eldritch Abomination. Skeleton Bow summon by Jotari.


[T2 Druid-Reskin] Buff : F2U/F2E Original Druid by IS. Hoodless variant by Jey the Count. Sleeveless variant by Teelvade. Clawless version by Pushwall.


Gun Sprite by Beansy.


All of these people do amazing work, and I truly appreciate it.