Credits ReadMe (Ongoing Updates)
16tracks12sounds-Agro/Brendor
256Colortitle-Leonarth
Additional AI:Talk AI-aera
Anim numbers Damage pop-up-Huichelaar
Area of Effect-Vesly
AutoGenleftOAM-7743
Auto-Newline-Zeta
DisablePreps-7743
BF Fix-Contro
Fix CG Fade-7743
DynamicChapterSong-7743
Change min poison per ch-7743
Change shop bgm per map-7743
Change battle bgm per map-7743
Convert Ch titles to text-circleseverywhere
Actions after Support-circleseverywhere/7743
Actions after talk-circleseverywhere/7743
Continue battle bgm between map and combat-7743
Crit cap fix-Contro
CSA creator FE8U-Circleseverywhere
Map danger zone-circleseverywhere
draw attack effect on map-Vesly
drumfix-circleseverywhere
remove enemy control glitch-brendor
display escape menu-7743
Event:Make all unit bad status-7743
Event:Character retreat-7743
Event:Change unit allegiance to 4th army-Shuusuke
Event:Give unit exp-7743/aera/vesly
Event:Force rescue to event-circles everywhere
Event:Simple escape event-7743/aera
EX:Modular Save/w supply patches-Stan
Expand list of battle floor terrain/battle BG
Fates exp system-Crazycolor
FE8 Battle stats with anim off-Tequila/vesly
Rogue robbery-Tequila/Zahlman/Stan/Black Mage/Eliwan
Enable locked weapon prf constraints on staff/items-tequila/7743
01 command hack-Hextator
48command hack-hextator
anti huffman-hextator
fill ai danger map efficiency fix-7743/HyperGammaSpaces
fix dodge to front glitch-Snakey1
fix_lz77decomp-tequila Group AI-Vesly/PhantomSentine
Use Hand Axe motion generic for thrown axe-7743
HP Bars with warnings-CirclesEverywhere/Tequila
HP Bars simple-Circles/Zane
Character custom animation ver 2 table-7743
Special Event per item-Vesly
Deny Deploy from Preps-aera/7743
Leader AI fix-stan
Less annoying fog-leonarth
m4a hq mixer-impatix
magic sword rework-sme
define multiple dancers-7743
setting battle bgm of multiple dancers-7743
Display multiple exits on map-7743
multiple vulnerary patch-7743
murder sticks-Zeta/7743
NarrowFont-Scraiza/MintX
switch death quote patch-7743
Remove Easy mode-nintenlord
switch prep shop per map-7743
Promote Command-Vesly
AddEvent:Shoot Arrow-Vesly
Show Heal amount-Tequila
SkillSys-Circleseverywhere Monkeybard & Black Mage for most of the skill icons; Blaze for Stances skill icons Tequila, Rossendale, StanH, Leonarth, Teraspark, sd9k, Kao, blademaster, Snakey1 for skills Primefusion for the test map
Skip event using world map-???
SoundNIMAP-circleseverywhere
SoundNIMAP2-Alusq Stairs-Snakey 1
Add blink to portrait-Stan
Steal w/ full inventory-vesly
Torch weapons-7743/boy
unit action rework-Stan
Auto Level Player Unit-Shuusuke/vesly

Portrait Credits:
TheBlindArcher
LaurentLacroix
Levin64
JeyTheCount
Rising Solaris
JiroPaiPai
Dolkar
Nickt
Garytop
MexicanCactus
BatimatheBat
HyperGammaSpaces
Imperial
Glac
Mr_Markino
Kanna
Kyrads

Animation Credits
DertheVaporeon
LeoLink
Ecut
Knabepicer
Skitty
Team SALVAGED
Flasuban
Jj09
Pikmin1211
Nuramon
Maiser6
MK404
Iscaneus
The_Big_Dededester
Sax-Marine
Deranger
bonemanseth
Zelix
Solum
Russell
Clark
Orihara_Saki
Alusq
Arch
Temp
EldritchAbomination
Redbean
Valak
ltranc
Jeorge_Reds
Dinar
Pushwall
Shin19
Jey
UltraFenix
Rexacuse
RiriK
Jotari
Jj09
7743
VelvetKitsune
Alexsplode
Gabriel Knight
Cipher Lee
Sphealnuke

Classcard credits
Der
RobertFPY
SALVAGED
Pikmin
Jj09
EldritchAbomination
Nuramon
TBA
Sphealnuke
flasuban
VelvetKitsune
ZoramineFae
Jj09
Leif
Max Limit
CanDy

Tilesets/Maps
Zarg
ZoramineFae
flasuban
wave
randomwizard
Beast
n426
Venno
MaxtheMageLord

Music Credits
Mycahel
Sme
MysteriousDancer
SurfingKyogre
MonopolyRunar
Kaidras
MeatofJustice
SaxortheNobody
Dolkar
RSFlame
mrgreen3339
Cynon
Dark Wastes-If you can tell me if you're
the author, let me know! I lost the credits
to this one and am planning to replace it
with my own once I get around to it.
Spell Animations
Shyuterz-Darkcalibur
Sme/Compile (edited)-Ice Shard

UI/Other GFX
7743
CanDy-FE10 Status Screen
LordGlenn-Affinity/Weapon Icons
Zelix-Spirit Dust Icon
Sokaballa-Battle UI
Alice