-Seer does not get another dragonstone after the one she starts with.
-Alessia can promote with Armorer's Proof or Master Seals.


Credits:
All the original COTA's credits

 		credits for new icons
wing lance	seal
stelle's remedy	ereshkigal
gale bow	zelix
croissant axe	edit of original
shellbreaker	zarg
spirit slayer	zelix
berserk blade	zarg
burdockivus	lordglenn
Amenonuhoko	lisandrabrave (anim -> shyuterz, hiroto, fenreir, 7743)
abyssal flame	orihara saki
stonecrusher	ereshkigal
rhomphaia	lordglenn
wakizashi	ereshkigal
ancient bow	zane
dushala		zane
guard naginata	lordglenn
one-slash	gabrielknight
dragonic lance	ereshkigal
ascension	zarg
cloudburst	lordglenn

staff pupil anim - citrus
curate map anim - permafrost
drifter anim - nuramon
drifter map anim - hypergammaspaces
male dancer anim/map anim - L95

palettes - randomwizard, dainn, knabepicer (who?)

1.2 with help from subwaybossemmett