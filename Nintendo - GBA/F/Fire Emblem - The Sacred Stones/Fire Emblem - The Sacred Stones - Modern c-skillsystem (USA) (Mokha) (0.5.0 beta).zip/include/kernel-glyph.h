#pragma once

extern const int gConfigUseGlyph;
