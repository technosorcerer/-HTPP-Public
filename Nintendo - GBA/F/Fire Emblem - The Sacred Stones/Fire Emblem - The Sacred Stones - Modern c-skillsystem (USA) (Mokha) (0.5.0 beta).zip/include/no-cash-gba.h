#ifndef NO_CASH_GBA_H

void NoCashGBAPrint(const char * pBuf);
void NoCashGBAPrintf(const char * pBuf, ...);

#endif /* NO_CASH_GBA_H */
