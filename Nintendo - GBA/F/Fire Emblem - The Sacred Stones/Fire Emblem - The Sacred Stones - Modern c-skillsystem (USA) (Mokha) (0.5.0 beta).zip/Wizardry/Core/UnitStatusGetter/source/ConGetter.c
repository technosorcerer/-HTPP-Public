#include "common-chax.h"
#include "skill-system.h"
#include "status-getter.h"
#include "constants/skills.h"

int _GetUnitCon(struct Unit * unit)
{
    int status = UNIT_CON(unit);
    return status;
}
