****************PATCHING INSTRUCTIONS************************************
Patch onto an FE8U ROM


Credits:

Huge thanks to RandomWizard for assisting with text formatting

AA Objection/Hold it/Take That images, Mia Fey voice clips - court records.net
PWvsPL Darklaw/Espella voice clips - ripped by Bolt Storm
TGAA Gregson, Ryunosuke voice clips - ripped by Wilson Parker

Recolored FE7 portraits - EldritchAbomination
FE6 portraits with blinking - Lenh, ObsidianDaddy
Hellene with mini - Redlightning
Civilian Class Card - Ghast, Hypergammaspaces
Ava map sprites - Sme, MeatOfJustice

Yard Map icon - Celice
Badge icon - Zarg

Anti-Huffman - Hextator
Hackbox extension - aera, tiki
Skip intros, health and safety screen - circleseverywhere
prevent freezes for nonexistent unit commands - 7743
Set Unit Status - 7743
Skip Difficulty Select - nats
Change Tile Name editor - 7743
Tile Event - vesly
UNCM/UNCR - tequila
set/get game option - 7743
item possession check - 7743
silent give item - 7743
m4a sound mixer - ipatix,7743
narrowfont - scraiza, mintx, 7743
unlock soundroom  - 7743
special event per item - Vesly
check tactician name event, set tactician name event - 7743
expand tact name chars to 9 - circleseverywhere
display split menu - Stan, circleseverywhere
256 color background patch - huichelaar
special event per unit - 7743
odd letter setname crash fix - 7743
256 color title screen background - leonarth
