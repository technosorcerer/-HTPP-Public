Apply .ups patch to a clean US FE8 ROM

KNOWN ISSUES
- The unit statsheet's "talk" display does not work properly and may be incorrect at camp. Ignore it, select Kyra and check which units have talk icons over their heads instead.
- The repair hammer's menu display and animations are slightly glitchy. This is only a visual issue, disregard it.
- The recruitment of the recruitable enemy in chapter 5 *may* not work properly. I think I fixed the problem before release, but the issue was inconsistent and difficult to test, so I cannot be certain. Please let me know if there's anything odd about that.
- If you notice anything else, typos, mistakes, glitches, don't hesitate to let me know!