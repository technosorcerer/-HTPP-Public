Patching Instructions

Download the Fire Emblem - Pillars of the Horizon.ups file.
Use a patching program of your choice (such as NUPS) and apply it to an unmodified US ROM of Fire Emblem - The Sacred Stones. I recommend creating a copy of this unmodified copy of the game, to make sure you don't lose it
Use a GBA emulator (such as mGBA) and run the modifed ROM file. You're done!