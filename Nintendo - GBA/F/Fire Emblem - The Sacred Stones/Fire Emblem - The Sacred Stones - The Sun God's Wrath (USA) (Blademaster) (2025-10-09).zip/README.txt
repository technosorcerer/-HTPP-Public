Sun God's Wrath Final Release.

This is the final release of Sun God's Wrath, which covers the full 27 chapters of this hack. There are no gaiden chapters, no further planned chapters, and no further planned updates.


What patch should I use?

This hack is intended to be played with fatigue using normal growth rates i.e. with Fatigue/Final.ups.

Use the others to varying degrees of enjoyment as you wish.

If you want to play with Fatigue, use the patches in the fatigue folder.

If you want to play without Fatigue, use the patches in the no fatgiue folder.

If you want to play with 0% growths, use a 0% growth patch.

If you want to play with 100% growths, use a 100% growth patch.

All patches are final, so you should see the final notice in the top right.

This hack was meant to be played with fatigue, so if you play without fatigue, just sell the fatigue reducing items.



If you have already been playing SGW, you should be able to apply the most recent patch to a clean rom
and use your old .sav without issue.


How to patch:

Apply the UPS patch to a clean FE8 Rom using NUPS/any UPS patching program.

Instructions on how to patch a rom can be found here: http://serenesforest.net/forums/index.php?showtopic=349

Please remember to read the credits. Feedback is always welcome.



Emulator compatibility issues:

0. It is recommended to play this hack using either Visual Boy Advance 1.8.0 Beta3 or My Boy! emulator for mobile

1. VBA-RR and versions of VBA older than 1.8 have been reported to have unknown freezing issues with this hack. Has only ever been produced on chapter 17.

2. mGBA 0.8.4 has been reported to have minor bugs



Known Glitches/Errors:

1. If a halberdier doubles for zero damage, the game seems to freak out for a bit and then returns to normal.

2. If a battle animation by some odd chance freezes, just exit, resume the chapter, and skip the animations by holding the GBA L button

3. Multiple mugs have odd pixels when blinking

4. In chapters 24 and up, in the preperation menu, depending on the amount of characters you have recruited and their class combinations, there can be an issue where their standing map sprite isn't working properly. This is a purely cosmetic issue. The best way to fix this is to make sure you have at most 4 combinations of two characters sharing the same standing map sprite.

5. The support room also suffers from the above. There is also an odd bug in the extra support room that can occasionally occcur and cause the ROM to freeze if you interact with the dummy unit. It seems that suspending and going to the extra support room causes it.

6. There may occasionally be an issue in the item menu where a character's name gets displayed in a place holder where
no character exists. This is purely cosmetic.

7. If animations are off, there is a cosmetic only issue when a unit gets a boost to their con or movement. The unit is not losing con or mov, but gaining.

8. If you engage in a support convo with a mounted unit and try to canto away, the conversation will repeat. You can only
attack or wait.

9. If a unit is on a dragon vein or a space the torch staff was used on, the unit on that tile cannot activate canto and galeforce.

10. The unit sorter has issues with sorting alignment and order

11. If you drop a captured enemy unit on position 0,0, their unit data may not be erased from memory and linger for the purposes of the enemy range fix.

12. One unit in the final chapter can't display their personal data. This is purely fluff and doesn't provide any important information for completing the game.

13. There is a display bug when a unit in resolve range attacks an enemy with Nihil. You will not have resolve bonuses if you attack an enemy with nihil.

14. If the spells wind, tornado/flying stone, jormungand, or blizzed miss, there are some graphic oddities.

15. The death spell causes issues in the battle background

16. If a unit's magic is much lower than a foes resistance and they use a status staff on them, the hit may display incorrectly
for negative values

17. Kind of an intentional bug, but if you play without fatigue, you gain fatigue in the final chapter (it was just easier for me to implement no fatigue this way)



Exp formula:

If you attack or get attack and do no damage, you do not gain exp

If you attack and do damage, the formula is the same as vanilla:

(31 + enemy level - player level)/Class power

If you are using an unpromoted unit and kill your foe:

(enemy level * 3) - (character level * 3) + 20 + boss bonus{40 if enemy is a boss}

If you are using a promoted unit and kill your foe

(enemy level * 3) - ([character level + 3] * 3) + 20 + boss bonus{40 if enemy is a boss}


Class power is 3 for tier 1 player units and all enemies

Class power is 4 for tier 2, 3, and some EX player units.



Gameplay changes:

1. Skills have been added in. Skills are both class and character based and are gained on level up and class change.

2. Units now have a con and move growth.

3. Promoted units do not have the "promoted" flag set for EXP calculation

4. Staff weapon level is set based on class and does not grow.

5. Growth altering hold items exist (crusader scrolls). See their item description to see the bonus they give.

6. A unit may promote once they reach level 10. Upon promoting, their level does not change. 

7. The level cap is now 30.

8. Units now get various bonuses depending on their weapon level. These bonuses are dropped when a unit has a weapon triangle disadvantage.

9. Hold L to skip battle animations. Try using this if you run into a bug with the animations

10. You can view a units growth rates on the stat screen by pressing L (or R, but pretty sure it's L)

11. Weapon level bonuses are as follows:

Swords:

C: +1 Attack

B: +2 Attack

A: +3 Attack

S: +4 Attack, 5 Crit

Lance:

C: +1 Def

B: +1 Def, +5 Hit

A: +1 Attack, +1 Def +5 Hit

S: +2 Attack, +2 Def +5 Hit

Axe:

C: +5 Hit

B: +1 Attack, +5 Hit

A: +1 Attack, +10 hit

S: +1 Attacl, +10 Crit, +10 hit

Bow:

C: +5 Avoid

B: +5 Avoid, +5 Crit

A: +1 Attack, +5 Avoid, +5 Crit

S: +2 Attack, +10 Avoid, +5 Crit

Anima:

C: +1 Attack

B: +1 Attack, +5 hit

A: +2 Attack, +5 hit

S: +3 Attack, +10 hit

Light:

C: +5 Crit

B: +10 Crit

A: +15 crit

S: +25 Crit

Dark:

C: +1 Attack

B: +2 Attack

A: +3 Attack

S: +5 Attack

12. The weapon Triangle is greatly altered. 
Bows are always advantageous against magic and have better bonuses when attacking a magic user. The bonuses given depending on which weapon is weak in the triangle is also changed.

13. The exp formula is much stricter.

14. HP bars and icons indicating enemies have effective or high crit weapons now show up

15. It is possible to check enemy range.

16. You always crit when you kill a boss

17. When a unit promotes, they learn their class line skills a few levels later.

18. Support bonuses have changed. They are as follows per level:

Fire: +1.5 attack, +2.5 hit, +2.5 crit avoid
Thunder: +5 Hit, +2.5 avoid, , +2.5 crit, +2.5 crit avoid
Wind: +5 hit, +5 avoid, +2.5 crit avoid
Ice: +1.5 defense, +2.5 avoid, +2.5 crit avoid
Dark: +1 attack, +5 crit, +2.5 crit avoid
Light: +.5 attack, +.5 defense, +2.5 hit, +2.5 avoid, +2.5 crit avoid
Earth: +1 attack, +1 defense, +2.5 crit avoid

19. Pursuit critical has been implemented. When a unit is using a double attack, their critical rate is increased
by their pursuit critcal coefficient for the second attack. This value can be found under a unit's weapon level. So a unit with a PCC of 3 and 10 critical will have 30 critical in their pursuit attack.

20. Capture: Capturing enemies is now possible. To do so requires having more aid than the foe's con. You can only capture at 1 range. You cannot capture mounted or enemies with the watchful skill. Sleeping enemies or those with no equipment are not automatically captured. Once you've captured an enemy, you can trade their items to your units. After you've traded a captured foe's inventory, you can release them.[A][N]


21. Fatigue has been implemented. When a unit's fatigue goes over their durability (see under their weapon level) they cannot be deployed next chapter

22. You can always use mercy against enemies to assist in capturing.

23. Adept, Aether, and Astra do not consume extra weapon uses.

24. When a unit is silenced or slept, they cannot recover from the status without a restore staff or the chapter ending. Bosses cannot be slept or silenced.