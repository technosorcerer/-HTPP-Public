Apply .ups patch to a clean US FE8 ROM

KNOWN ISSUES
- On rare occasions, the game may softlock at the end of a chapter. Should this happen, close the game/emulator, open it again and resume the suspended game until the game proceeds as normal.
- The unit statsheet's "talk" display does not work properly and may be incorrect at camp. Ignore it, select Kyra and check which units have talk icons over their heads instead.
- The repair hammer's menu display and animations are slightly glitchy. This is only a visual issue, disregard it.
- Standing on a ballista while attacking will glitch out the attack range display. This is a common and as of yet unsolved bug with SkillSys. Ignore it, as it is merely visual.
- On fixed growths mode, growth modifying skills and items cease to function. This affects the mind scroll and the personal skills of two units, who only have them for flavor and will have a worse performance due to this. Turning off fixed growths will restore the skills' functionality.
- If you notice anything else, typos, mistakes, glitches, don't hesitate to let me know!

TIER LIST CREATORS
Chapters: https://tiermaker.com/create/fire-emblem-the-hag-in-white-chapter-tier-list-16617653
Characters: https://tiermaker.com/create/fire-emblem-the-hag-in-white-character-tier-list-16617653

CHARACTER POPULARITY POLL
https://docs.google.com/forms/d/e/1FAIpQLSe5T-Vb1XcROIqjTWb_T0xxqxihc42bRLptKG97lT_VfPSp3A/viewform

VERSION CHANGELOG
v1.1
Updated guide to reflect lack of magic trinity.
Added a visual indicator for both escape tiles in chapter 3, since before it wasn’t clear that both tiles could be used to escape.
Removed bug warning in the readme for chapter 5 (by now it’s pretty clear the bug doesn’t exist anymore) and changed the wording to hopefully make the recruitment a little bit more clear.
Fixed funny bug in chapter 9.

v1.2
Updated clumsy and poison strike descriptions to note that the damage cannot kill the unit.
Updated maelstrom description to reflect the fact that it deals magic damage.
Slightly modified some chapter 7 dialogue to reflect the fact that allied units will not be targetted by the enemy.
Tweaked chapter 10 a bit, removing a few wonky reinforcements and adding some thieves.
Modified a couple entries in the class roll.
Tweaked the promotion gains of swordmaster, spellsword, berserker, falcoknight, wyvern lord and malig knight.
Increased gold requirements of a certain character’s events.
New version of Valour Against All Odds, courtesy of the great ArcherBias!
-2 HP, +2 str, +3 mag, -5% mag growth, +1 skl, +1 spd, -1 luck, +1 def to Pluto. Moderately rewrote Nikolaos/Pluto base convo.
Fixed a mistake with the blood demon.
Fixed a number of reported bugs and errors.

v1.3
Improved some parts of the act 2 map palette.
Fixed chapter 19 recruitment conversations not being cancelled out when the recruitment is done.
Buffed Ofelia’s HP growth.
Tweaked chapter 13 slightly to prevent the berserker jumpscare.
Updated readme and known issues section.

v1.4
Increased SPOILER’s HP by 2 and luck by 1 to prevent him being one-rounded by the boss’s sword.
Fixed an enemy knight in chapter 11 being misplaced if you go to camp and return.
Fixed chapter 22 statboost camp convo not properly being skipped if it’s already been obtained.
Attempted to fix up the arena enemy list.
Adjusted a chapter 22 reinforcement.
Updated some weapon descriptions.

v1.5
Fixed a few major bugs that happened from lap 2 onwards of the postgame.
Made a couple of minor text and tileset revisions.

v1.6
Swapped Agari’s camp convo boosts from Str to Def.
Swapped Soter’s camp convo boosts from Def to Str.
Added warning for trip delay to the tunnel house in 22.
Removed a forest tile in chapter 17 so the new recruits can more reliably kill a reinforcement.

v1.7
Fixed Laertes price ask text being incorrect in his final convo.
Added a master seal to chapter 23 shop.
Added text to specify you need to rescue the greenies in 20 and 22.
Adjusted spear, tomahawk and runesword prices.

v1.8
Added a camp convo between SPOILER and Nikolaos in chapter 19.
Rewrote Jason/Nikolaos slightly.
Cleaned up base camp in the postgame to make sure all convos can be read and display in the proper order. It’s still a little wonky in a few minor ways, but it should now properly function as a support viewer of sorts.
Fixed give all command not giving items after command has 100 items, thanks to Ditto.
Fixed issue with the chapter 13 outro’s event when skipping scenes.
Fixed the chapter 23 outro’s scripted battle having a 100 miss.
Fixed certain units not getting their skills when they join in the postgame after not being recruited in the main campaign.
Fixed an enemy in chapter 4 of the postgame having a weapon they cannot use.
Fixed a couple of minor issues in the secret chapter and made a small addition to it.
Fixed a rare bug in the postgame where sometimes the ability to change the battle formation would be disabled.
Added stagger status effect to signal final boss’s movement behavior. Also polished some of its behavior a bit.
Moved escape command higher in the command menu order list. I originally moved it due to it causing accidental escapes in chapter 7, but certain enemies at the bottom of the map were moved after the fact, so that no longer applies.
Delayed chapter 2 thief by one turn.
Increased Vortex’s accuracy.

v1.9
Added casual mode.
Added fixed growths mode.
Added the ability to toggle casual mode, fixed growths and difficulty at base camp.
Added alternative camp dialogue in chapter 18 if the secret recruitment is performed.
Tweaked functionality of an event in final 1 to be more in-line with regular game mechanics.

v1.10
Fixed unit inventories being duplicated upon retreat on casual mode.
Fixed Fazang’s inventory not properly being sent to the convoy when he dies.

v1.11
Fixed an issue with level 9 of the postgame on lap 2, and on lap 1 in rare occasions.
Fixed unit list in roadside stop causing issues and crashes.
Fixed thief in chapter 2 potentially not spawning depending on when you open the first door.
Fixed a cavalier in chapter 14 being mistakenly set to attack villages.
Fixed some incorrect WEXP values.
Fixed a visual glitch that sometimes happened in the turn 1 cutscene in chapter 9.
Fixed a few minor issues found by Pushwall.
Plato has gained a new theme song.