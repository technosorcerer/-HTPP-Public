sorry,I am still in the middle of translation.


* FE8 Kaitou

Discord: https://discord.com/channels/145137778710151168/
FEU:     https://feuniverse.us/t/fe8-kaitou-patch-all-64-chapters-2-village-jp-en/2984/
Update1: https://ux.getuploader.com/FE4/search?q=fe8_kaitou
Update2: https://fecentral.org/?page=hackinfo&hackid=125

This work is a secondary creation work of FE 8.
It has nothing to do with official.

All stories are fiction.
It has nothing to do with anything in reality.

No warranty self-responsibility, please.
Please enjoy and enjoy within the range of common sense.


The patch is in ups format, so you can use FEBuilderGBA to extract it.
Please extract it in FEBuilderGBA and press F5 to play.

FEBuilderGBA: https://github.com/FEBuilderGBA/FEBuilderGBA/
Installer:    https://github.com/FEBuilderGBA/FEBuilderGBA_Installer/releases/download/ver_20200130.17.1/FEBuilderGBA_Downloader.exe


We rewrite scenarios and maps, characters, music, others.
Various plagiarism pakuri are many in various characters and setting etc.

Please play with self responsibility all.
The hero is a bad person because he is a thief.

Let's play other works if you want to see the story of a friend of justice.

*About types of ups
fe8kaitou.ups
Japanese Orignal Version.

fe8kaitou.en.ups
English translation version.

The translation was done using deepl and google translate as a base.
Therefore, I think there are many mistranslations.
If you find any mistranslations, please give me feedback.



Story plot.
Steal treasures from all over the continent out of a desire to see them, escape from prison, steal national treasures and get chased off by special forces, then attack tax collectors in retaliation and steal the funds coming from the provinces, scatter them as weapons to revolutionary organisations in neighbouring countries, cause mayhem in neighbouring countries and bring their troops to a standstill, then take advantage of the opportunity and AirShip and flee outside the continent.


In Hidden is a story about helping that revolutionary organisation.

1. republic->communist
the validate an overreaching capitalist, dysfunctional democratic government and help the revolutionary army to make a successful communist revolution.
The only problem is that its organisation is worse.
Ultimately, they are assassinated and killed because they are jealous of the loss of popular support to the protagonists.

2. communist->empire
The murdered protagonist wakes up in a port town just before going to Hidden.
Her's memory is vague. I seems to have had some kind of bad dream. I can't remember it well. But there is something different about this world.
In this world, the Republic had become a communist state and was corrupt as well.
Help the revolutionary organisations to save the people.

They had a leader who was not good at war but had excellent principles.
However, the leader was killed in the course of the war.
The leader dies, leaving the protagonists to take over.

She takes over and tries to make the revolution a success.
However, the leader's idiot son uses a forged will as a weapon to seize command of the revolutionary forces.
His foolish manoeuvre threatens to destroy it, but the protagonist's struggle manages to drive out the enemy.

However, the capable protagonist is resented.
After the victory party, the protagonist is still killed.
The protagonist remembered everything before he died, but could not prevent it.
The protagonist's consciousness disappears into the darkness, vowing never to forget if he has another chance to start over.

3. empire->republic
You don't have to say it anymore.
When the murdered protagonist woke up, it was in a port town just before he went to Hidden.
This time, the country has become an empire.
Support the revolutionary organisation that aims to overthrow the empire and become a republic, and make the revolution a success!

Here, too, the twin brother of the leader of the revolutionary organisation appears in the middle of the game and takes command of half the army.
He brainwashes his soldiers with magic and drugs and tries to carry out a war involving the whole continent in order to overcome his former trauma.
This time, thanks to his inherited memories, he is able to avoid assassination.
If he cannot change the fact that he will be stabbed, he will change the outcome.

However, he has perfected a barrier magic called Mafoo, which cannot withstand the damage from ordinary attacks.

The (twin) brother of the murdered former leader had secretly developed Starlight, which penetrates Mafoo, in order to stop his brother.
However, he is being held prisoner and used as a puppet.

He sneaks into the tower where he is imprisoned, but he dies, leaving everything to the protagonist.
His spirit did not last as he desperately tried to hail the brainwashing.

Starlight is hidden in another tower.
Security there is tight.

We are the Phantom Thieves(kaitou). Let's go and steal the Starlight.

She will steal the Starlight and win pierce Mafoo.

Epilogue.
All the other leaders are dead, so the protagonist becomes king and works for reconstruction.
She establishes a good government and makes the country wealthy, mainly through trade.
The thief has stolen the country.

However, she has had enough of the tedious work of the king.
She is a thief. She wants to see things she has not seen yet. For this reason, she enjoys stealing.
She made the country a republican state and created a democratic constitution so that it would not become a corrupt democracy as she first saw it.
She then leaves everything to the new elected leaders and sets off on her adventure.

The End.



There is a stolen list in the readme.

121 Ronness's jewel.    Prologue from the start.(Always obtain)

122 Bandit's treasure.  Steal from Bonn in Chapter 6.

123 diamond of light.   Obtained by event during event in Chapter 6. (Always obtain)

124 The property of a slave merchant. Steal from the bamboo in chapter 12.

125 Hero's Painting.    Obtained by event after clearing Chapter 13.(Always obtain)

126 Blue Garnet.        Obtained by event after clearing Chapter 20.(Always obtain)

127 Graded gold coin.   Get it at the event at the start of Chapter 21.(Always obtain)

128 Renes government bonds.  Get it at the event at the start of Chapter 21.(Always obtain)

129 Grado government bonds. Get it at the event at the start of Chapter 21.(Always obtain)

130 Sapphire of darkness. Steal from Heart-sama like 23 chapter.

131 Silver Cross Medal.  Steal from O'Neal in Chapter 23.

132 Siegelinde.          Obtained at the event during chapter 25.(Always obtain)

133 Gold Key             Visit to the village which appears in the lower right ONLY one turn in Chapter 26.

134 Renes' Taxes.        Obtained by event after clearing Chapter 28. or steal from enemies in chapter 27.	Always obtain / stolen goods that you get in multiple hands

135 Silver Star Medal.   Steal from Breguet in Chapter 29.

136 Black belt of Baritsu. Steal from Holams(Holmes) in the upper left in chapter 30.

Design document(Magical ship Bruce Partington's design document) Obtained by event during chapter 31.(Always obtain)

The selling price of the stolen goods is 65535 gold.
There is no stolen goods on the extra story.
Instead, there is a powerful weapon and red,white,black or blue...


*Continent national feeling with this patch

**The Kingdom of Rennes.
This country has wide remarks throughout the continent as the hero's nation which punished the resurrected demon king.
As the leader of the continent, the Rueness man acts under the name of justice.

However, there are times when it is kept away by that much of justice.
(Siegmund has been lost in the fight with the Devil and the remaining Sieglind is a national treasure.)


**Kingdom of Frelia 
A country of a frontier border that is a friendly nation of Renes.
Security is very loose.
However, the people may be the happiest.
An idyllic landscape is spreading.

**Kingdom of Jahana(present Rahanes' Jahana protected territory)
The fire burned the royal palace and fell under the desert sand.
Treatment as Runez's protected territory now.

**Grado country
Friendship of Renes.

This country was manipulated by demon king and invaded all the continent 's countries.
And, lost in the battle, the country was exhausted.

Furthermore, it was devastated by the subsequent catastrophe.
However, with the help of Renes' Queen Eirika, and miraculously revived.

From such circumstances, it is a very friendly relationship with Renes.
It is close to the real protected territory.
This country is not a military state, but is striving to achieve economic development.

**Republic of Calcino
Commercial state of Republic.Continental economy big country.

It requires the largest trading port Kiris of the continent, and trade with another continent is actively carried out.
Democracy, capitalism, liberalism are raised, there are rich commercial cities called free cities.
However, on the other hand, it is a harsh inequality society that anything can be done if only gold is done, if we lose the competition it will end.

If you pay even money, you can buy the life of a person.
It is the only country that still retains slavery still in the continent.

Who is free for this country's freedom?

**Roston saintly country.
A country that was a sacred nation, but now has become a scientific nation on the continent.

Science and technology developed highly, as the spare priests spent their free time exploring the truth.
Roston is the country with the most advanced science and technology in the continent.



*Existing Issues

Problem 1. There is no supportive conversation.

A:
Since support conversation alone will account for nearly half of the total text volume,\r\n
I would die if I had written all of that.
Let's give up.
Or you will make it.

Patches and forks are welcome.


Problem 2.
The problem of spelling errors.

I am rewriting all the text of FE 8 and still writing a scenario that I would like to go through by using a part of the dictionary area and supporting conversation area because it is not enough.
Because there are enormous scenarios, mistakes are often common.
If there is something like Indians to the right, All your base are belong to us, please report a bug after taking a medicine and laughing.



If there are other problems or bugs,
"I will be buggggggggggged!! " cried,
Please do as it is in the question that is likely to be good.


"Let's finish rather than aim at perfection.
Mr. Berg said something wrong, so I left it for something that does not go well even if I tried it over and over.
Please fix someone.


*FAQ

Q: I do not know how to apply patches.
A: Use Google.

Q: What is the recommended emulation?
A: I recommend VisualBoyAdvance-M (sourceforge).

Q:
Can all the fellows use "stealing"?


A:
Because the heroes are kaitou guards, the companion can use a command to steal everyone.



Q:
Cleric ister can use light magic and shaman can use wand ...

A:
All magical workers can use attack magic and a staff.
It is tough to practice wasting hands with a staff, and it is becoming like this because recovery is troubles if a cane can not be used.
Is not it ok if you just play tied up if you do not like it?


Q:
There are 2 to 3 bow ranges ...

A:
I learned about Dream of Five V4 and extended the range.
I think that it will be easier to use even people who are not good at using bows.
Conversely, enemy sniper is supposed to be scary.



Q:
The character is plagiarism.
You stole it.
Is not it terrible?

A:
Yes It is plagiarism. But what is it?
If someone writes a character picture, it may not be necessary to replace it, so please kindly write and replace it.



Q:
I do not have enough money.

A:
Let's sell the stolen goods.
There is no event that Tada can get neither like FE5.
If you don't sell your stolen goods, you will be jittery.

Q:
I do not want to sell stolen goods.

A:
Do you play tied up?
you are Hentai.
Let's steal and sell the enemy's magic bullet.
Because the esters are a kaito group, you can use the \"steal all\" command.
If you enemy's HP 1 digit you can catch it, so let's sell it by peeling weapons.
Or let the enemy sleep.

Around a Fortify with a good conversion rate is the target.


Q:
There are too many reinforcements.


A:
This is Mashimashi.
As a blogogue says, the shito retrofit seems to be a mass reinforcement on a wide map, so I tried that.


Q:
The character is too weak

A:
Although the growth rate is good overall, if it is still painful,\r\n
Since the enemy has a large amount of statbooster items, let's use it gang.
In this game, the initial placement character always has a doping item, so if you do not use it, it is a loss.
Whether you are going to use it at the end, like the strawberry cake strawberries, you are going to eat it last, which will put pressure on the transport team stock.


Q:
The character is too strong

A:
Do you like playing with statbooster items?
Also, how about a defensive play that does not attack from here?
I do not know whether it can be cleared, but ...


Q:
Enemy is too hard

A:
Let's play together.
Almost all enemies can not be defeated easily because HP has a high bullet on top of it.
Therefore, it is necessary for all the fellows to play.
Moreover, as It is strengthening weapon triangle and support, we must consider compatibility.
I wanted to eliminate the play that strengthens only some of the units to the strength like Lu Fab and make a few elite.
In this area I referred to the game balance of the fe7if.
It is so lonesome that the warriors around me are so inclined to be a strong man and full of haircuts.
Also, by making an act of stealing the enemy's item, the number of actions decreases once, so I think that it will get harder and harder if it is a few elite.

Q:
Does not the enemy's Elixir do manage?

A:
Let's steal Elixir.
Because we are kaitou gang, let's strip the enemy's mouth before attacking.
Let's all do a one-turn kill with the people.

Q:
Strengthening weapon triangle and support?

A:
It is strengthening it more than 3 times.
If the weapon is incompatible with the weapon triangle, it can be disastrous.

Weapon Triangle  Attack correction: 0  Hit correction: 50%
Support        Attacks: 0  Defenses: 0 Hits: 6 Avoid: 7 Crit: 0 AvoidCrit: 8

Q:
It is hard to accumulate support points.

There are a total of 2 cities that can be reached via the world map.
You can earn SUPPORT points there at a rate of 30 times faster than in the other map, so take advantage of it.

Q:
I was able to rescue the enemy.

A:
I am using enemy capture patch
Rescue is bigger than the enemy 's physique, enemy HP can capture one - digit or sleeping enemies with rescue.
Items can be exchanged freely while standing enemies.
Let's peel items like a leaf.
Enemy Capture Procedure Unlike the patch original, it is an enemy that meets the rescue condition by physique etc. It can capture if it is in a sleep state with HP one digit (HP: 9 or less).
Cavalry can also be caught.




Q:
There are unbelievable enemies even though they meet the rescue conditions.

A:
Beginning with Las Boss,
Some special bosses are trying not to bite.
If it can do it will break the setting.
Let's give up.


Q:
I knocked down the enemies who have valuable items to the least extent;_;

A:
This is my condolences.

Although it may be possible to play normally, I want to make a game balance that is painful if I aim for perfection.
So it is necessary to compromise to a certain extent, and if you aim to be perfect then reset and become friends or state save.


Q:
If you used Swiftsole, your physique also increased ...

A:
Using Swiftsole, the mobility and the physique increase in sets.
The more you use the Swiftsole in the flight system, the more you receive the penalty of rescue, so use is planned.

Q:
Is there any way to reduce my physique?

A:
You can reduce it with items called Diet Drag.
As the enemies in the latter half have it in Male, let's steal.
There are not so many numbers.


Q:
How can I raise a recruit slave recruiter? 

A:
It is love.
Love does not hesitate.
Remove the weapon of Esther and Lee to Gandhi and make it a shield,
Please do hit the enemy with an ice sword (sword: E) and a short spear (spear: E) indirect attack.
The recruitment rate is good, and it will become the strongest corps with five mutual support, so let's nurture somehow.
Q:
How can promotion?

A:
Promotion can be done with Master Seal.
The level rises up to 31.

The parameter goes up to 36 equally for "all class".
un-promotion jobs have up to twenty parameters, but I think that it will be nearly twenty if it exceeds the level 25 level.

If you want to aim for the strongest you should pull CC to level 31, and if you want to take a profit you think that it will be Promotion at last.
Please do so now ...

Q:
Where is Master Seal?

A:
Get it at the village visit.
We are preparing necessary number of people + a minutes, so please be relieved.


Q:
The hero can not be Promotion.

A:
Please wait until the end of chapter 23.

Q:
Why did you make the hero a bad person?

A:
Because all of the judges of justice are making it.
I made a villain called Kaito, which seems not to be officially made, as the main character.
(I think that it is serious as various kinds of present times pick up the noise.
I would like to see more of the story that made a villain like GTA the hero.
)
However, in order not to get dark, I made it a bright, pop animated style full of characters.

However, a bad guy's thief ester is doing,

Both the trespassing robbery and the hijacking,
It is that allies of justice are doing it.

Remember the work of the protagonists of successive FE hero and RPG game.
Basically, what you are doing does not change justice or bad guys.
It is a difference whether there is a punishment for justification because of justice because of cause.


Q:
Are the esters a mass killer?

A:
No.
Because it worsens awakening, it is Nazika Dengeki Strategy, an anesthesia gun like Aika, an era of era play? 
There are many enemies who have defeated the evidence, and only to make them stunned by gag anime-like opportunism.



Q:
Is the biggest evil person in the play an ester? Is Moriarty? Or hood man?


A:
No.
The biggest evil person in the play is the father of the weapons shop.
To buy stolen goods is because He is confident that it will sell at a higher price.
It is a terrible evil party.
He will sell more weapons at a higher price.
There is no more evil person.


Q:
To say that the thief is gracefully elegant,
Are the esters doing thrusting robber well?

A:
Because it is SRPG.



Q: Lunatic is too difficult.

A:
I warned you to quit at a difficult level.
Still, you chose Lunatic.



Q: 
I can not get into the tower / I can not see any demons.

A: 
Peace has returned to the world as the devil is defeated.
There is no such thing as a demon.



Q:
Is there no Manakate?

A:
Maybe it seems to have been extinct.



Q:
All types of weapons are sold at weapons stores and tool stores from maps?

A:
In this world, since we adopt a purely capitalist economy, even if we can pay money,
You can use as much expensive weapons as you can.
(There are exceptions though)

Let's hit it with a bundle like social game.


Q: 
Do you have a secret shop / silver card?

A: 
No



Q: 
Are there any special weapons?

A:
No
What kind of theory do weapons that only royal blood drawers can use?
There is no such thing as it can not be explained.
(However, there are exceptions.)


Q: 
Is not it a guardian of Fili or a guardian of Hopron?

A:
No.
Whether to avoid luck or support.
Let's pray to the god of random numbers.「愛だろ。愛で避けるだろう。」



Q:
Are fallen ally not resurrected?

A:
If you have chosen casual mode, they will be resurrected in the next chapter.
But if you're a gamer, reset when your character dies.

Q:
Is it possible to play a ironman play?

A:
It is possible if your game's skill is good.
It is impossible if you fail.

By the way, the maximum sortie is 20 people.
Because the balance is adjusted on the premise that the basic, sorting frame is used up,
I think that it is difficult if the character cuts 20 people.

Q:
It is a pain to sell Elixir.

A:
I made an event that collects bullet medicine at the beginning of the chapter.


Q:
Item column will be too small.
I will be filled with stolen right away.

A: 
It is useless because GBA's FE is such a specification.
Let's use the estell transport team well.



Q:
What is the tactics of early stage capture?
First of all, it is to grow an estell.
Next is to grow Lee.
Then let's grow up the characters around us.
Let's raise recruits at the end.

About 1-4 chapter strengthening of estell and lee
About 7 or 8 chapters, Esther and Lee arrived at level 31, Lee was pomotion goal.
The goal is to strengthen surroundings in parallel and to Promotion about 16-17 chapters.
The goal is to raise recruits of liberation slaves from chapter 13 and to make it Promotion around 18 to 20 chapters.
If you go up to the superior class, you should be able to do it by about 20 chapters.
Since enemies come to kill a little from chapter 24, let's use the character which we raised well.


Q: 
Is the police of this world all-incompatible?

A: 
If it is competent, it will not be a game.
It is the end of the prologue.
The policemen in the play is a jealous role.


Q:
Is the detective and the Kaitou beat with a sting?

A: 
There was a beating in Milky Holmes.
In this world, this is a detective, a kaitou.


Q: 
How do I open a treasure box?
A: 
When the ester stands by waiting on the treasure box, it will be opened.
Because there are no Thief, treasure chests only appear at the event.
So there are only two treasure boxes in the play.
Together, it opens when the ester waits on the treasure box.


Q:
How do I open the door?

A:
The door opens only at the event.
Please fire on event.

If there is no event, it is just a wall treatment so I will never open it.
There is a broken wall near such a door that does not open.
Let's break the wall.


Q:
What is a triangle attack?

A:
Three Pegasus can do it.

Q: 
What is your translation?

A:
Please feel free.


Q:
How about donation? 

A:
No.
I do not intend to make any profits in this game of secondary creation.
If you really want to donate, donate it to a charitable organization that counters expression restrictions such as the Electronic Frontier Foundation (EFF).
Other, modification / Fork / reprinting / redistribution / live comment / analysis / capture site / various others are within the range of common sense and can not be liked by self responsibility.

Because it is the purpose to enjoy the game,
Do these for free, and if profits are raised, such as advertising revenue,
Please donate to organizations, etc. to counter the expression restrictions including the Electronic Frontier Foundation (EFF).

And if you get angry from anywhere, please apologize instead of me.


Q: 
What is all about chapter?

A: Prologue + final chapter + 32 chapters totaling 34 chapters.
There is no Gaiden,

There is a extra map that you can go after clearing the main part.
Since the extra map has 30 chapters, it is 64 chapters in total.



Q:
Extra map?
A:
Let's go to the Mercana coast after clearing.


Q:裏面(おまけマップ)が難しすぎます。
A:裏面はガチで手ごわいシミュレーションです。
普通のステージは誰でもクリアできる難易度を目指していますが、裏面はそうではありません。
裏面が難しいのは、夏が熱いというのと同じく当たり前と考えてます。
トラキア一週目目のような理不尽さをどぞ。
手強いシミュレーションなんだから、攻めるも守るも無い知恵を絞るんだ。


Q:裏面終盤はどうにかならないの？
A:裏面終盤は攻撃が非常によく当たるので、全パラカンストはもちろん、支援、すくみを考慮して戦いましょう。
また、敵が持っているチート武器を盗んで、ハマーンで直しながら戦う必要があります。
敵のチート武器に勝つにはこちらもチート武器を使うしかないのです。
資金はすべてハマーン代につぎ込みましょう。

Q:裏面をクリアしたら終わりですか?
クリアデータを利用して闘技場の図鑑を埋めるモードがあります。
OPクラス紹介にあるように、ゲームには登場しなかったたくさんの敵が闘技場にはいますし、
OPクラス紹介に登場しなかった隠しクラスもあります。
ぜひ図鑑を完成させましょう。

Q:このゲームは巨大すぎる。
改造FE界のラーメン二郎を目指しています。
32MBの限られたROM容量にいかにたくさんデータをいれれるかを競ってます。


Q: 
Which is Adler or Moriarty smart?
In the play, I am setting up like this.
Adler is a genius who analyzes and understands unknown events.
Moriarty is a genius that maximizes his interests in a known mechanism.

Moriarty is puzzled if unknown circumstances do not understand, Adler instantly finds the essence.
On the contrary, Adler can not make a dramatic leap in order to maximize my share in the existing mechanism.



Q:杖Sにする意味はありますか？
A:通常はありません。リザーブは杖Bやハマーンは杖Aです。
裏面に杖Sが一つだけでてます。

Q:CC分岐のおすすめは？
A:個人的に 特殊 > 空飛べる > 機動力 > 必殺 > それ以外 だと思っています。
特殊クラスはアイドル(バードと踊り子の上位クラス)などの特殊なことができるクラスです。
空飛べるクラスは、陸路で行くのが難しいステージなどが多いのでとても役に立ちます。Dマスタ、ファルコンはサイトどうもできるので機動力の条件も満たしとても強いです。
機動力は再移動ができる騎兵です。盗むとの相性がとてもよいです。
必殺は、硬い敵をぶった切るのに便利です。(ただし機動力が問題)



Q: 
Is the formula of the hit ratio different?
A: It is corrected as follows.


命中率=装備品の命中率＋技×2＋幸運÷2＋支援効果＋3すくみ補正+難易度補正
Accuracy=Accuracy of Equipment + Technique * 2 + Fortune / 2 + Assistance Effect + 3 Strusion Correction + Difficulty Level Correction

Difficulty level correction is usually 0, but difficulty level: In Lunatics, + 40% senior position will be + 20% in the case of attack from enemies.



Q:敵多すぎ時間かかりすぎ
Q: The enemy takes too much time

A:戦闘アニメOFF 且つ、エミュレータのフレームスキップ推奨です。
A: Battle animation OFF and frame skip recommendation of the emulator.

がんがん飛ばしていきましょう。
Let's skip ahead.



Q:
Why do mercenaries (bouncers) of this world betray soon?\r\n

A:
In the first place, it is such a mercenary.
So, the premier is on a mercenary who does not betray it.
If everyone does not betray, there is no value for mercenaries who do not betray.



Q:
Are there no erotic scenes?

A:
There is absolutely no obscene.
This is a very healthy work.

Q:
I can't see all the songs in the sound room.

A:
A:
We changed the setting and it is no longer fully open from the beginning.
If you play the song, it will be registered, and if you clear the game and see the ending, the entire sound room will be released.

*Sound Room
I changed the settings and no longer open all the way from the beginning.
To see the sound room, you must first clear ch3.
Then, if you listen to the song, it will register and you can listen to it.
Also, once you clear the game and see the ending, all music in the sound room will be released.

The game has been modified to display computer graphics in the background like FE7, so you can listen to music while looking at various pictures.
Some of the interesting backgrounds may be found only in the sound room.
In the sound room, press the L button to hide the sound room UI and switch to the CG viewing mode.


*FEBuillderGBA WorkSupport
This work supports the FEBuilderGBA work support feature, which allows for automatic updates by playing with FEBuilderGBA.
It also supports the automatic feedback function.
Feedback can be given completely anonymously, using only the information in the game.
Your feedback will help us improve the game, so please help us.
You can change this setting at any time from "FEBuilderGBA Menu->Run->Work Support".

If you play with automatic feedback enabled, you will get a Master Seal as a bonus.



*Stage commentary
**Prologe	Kaitou coming	怪盗参上

Since this is the first chapter of the game, this chapter introduces basic rules such as stealing, statbooter handling, capure, weapn triangle, etc.
As for the strategy, you can usually win if you have Estelle waiting in the forest.


**Ch.1	Return late	遅すぎた帰還
The esters who hurried back to the hide by avoiding the trace of the police force.
However, the hide was found in the police force.

The FE classic Cleric in Pursuit appears.
This stage also has many roles.
You get to see that the Sister can use light magic, you get to see the
to see the increase in the sword->lance penalty of the three-sided sword->lance
This is also the stage where the players learn that they can carry a dying enemy.

The purpose is also to train Esther by sending out mass reinforcements.

The characterization of Breguet was a problem for me until the very end.
I really think we should have had a character before him who had a solid sense of justice, but it was difficult to scale so it was rejected and we ended up with what we have now.

At first I had trouble handling the enemy capture patch, pulling it off and freezing when I tried to exchange it with an enemy that had none.
(Maybe it still happens. But the frequency of occurrence should be very low. If you get a similar bug and it freezes, reset and start over from interruption.)

If we were to compete with Yodobashi Camera, it would be that Big Camera is the only way to go.
The BGM of the tool shop became that.
(Big Camera is an electronics store that operates nationwide in Japan. The background music for the advertisement was a variation of "Soon Beyond.)

Since this is only the first chapter, we are giving out hint messages here and there.
We have made the enemies as weak as possible to make the game as stable and clear as possible.

We had a lot more social knights and lance soldiers in the beginning.
Since we have strengthened the three arms, they will be harder to defeat with the ester, so we have eliminated all of them and made the enemies mainly axes with weaker stats.
I also put a soldier special attack on the rapier so I think it will be easier to proceed.

If the enemy's status plunged into the negative, it would underflow and burst all the way to the max value when interrupted, so it was hard to adjust it to just barely 0.


*ch.2 Battle Hideout	アジトでの攻防

The objective was to survive 20 turns.
Estelle and her team managed to return to their hideout, but police reinforcements were closing in on the hideout.
Estelle decides to abandon the hideout and flee to Frelia's hideout.
She leaves the injured Lina in the care of Mulder and Shelly, and must keep the police force at bay until the girls can escape sufficiently.

**ch.3 To Frelia	フレリアへ
Esther and her friends decide to abandon their hideout and flee to the neighboring country of Freria.
However, police forces were closing in to prevent their escape.
Estelle and her friends planned to escape by flying over the border mountains in a dragon.

---
Ester that reached Frelia's retreat.
The injured Lina was to be hospitalized in a hospital that Mulder's old friend is doing.
Ethers were puzzled by fellow injuries, but she decided to keep on kaitou.

///
The escort made a journey to do a thief with Grado until the bloom cooled.
The next objective is the light diamond in Celestial city of Grado.
Serafew is a city prospering as the main trade route of Grado and Lunes.
There was one of the largest banks to keep wealth born in trade between the two countries.
Diamond of light sleeping in this bank 's underground safe.
That is the target of this time.
And here is the area of Lunes territory boundary Im if we go beyond here it is the Grad area.


**ch.4	My Aesthetics	怪盗の美学

Ester who heard the information that there is light diamond in Celebuju Bank decides to steal.
Due to the problem in Renes, I made plans to reach the Grad region beyond the remote area.
The esters traveling in the remote area encountered the village where the bandits were attacked by the villagers.

"Certainly, we are the kaitou group, but unlike the bandits who plunder from weak ones unnecessarily.
Stolen treasures in more difficult conditions, that is the aesthetic of kaitou."
Certainly, kaitou is a thief. But, they have a belief.
For kaitou, the thieves who plunder things from the weak people unnecessarily are acts of defying their aesthetics.
Esters decided to fight with the bandits to protect their own beliefs and the village.

Conversation.
Estelle->Arabella joins the group
Arabella->Lito joins

The esters who saved the village to preserve the belief in the aesthetic of Kaitou.
The villagers welcomed the esters as a hero who protected the city.
In such circumstances, we can not say that we are kaitou groups.

They intended to leave this place early and leave.
She told a lie that I let him use it to protect this land from the center of Rennes.
She planned to survive on this occasion,
In that case, the villager asked me to destroy the hideout of the bandit group.


**ch.5	Bandit killer	山賊キラー

The esters who are confused as to why this kind of development started.
Still, because I have promised with the villagers, I have to fight the bandits.

"The bandits are hiding something treasures.Bandits will have treasures. Let's steal it."
Esther is good at switching feelings.


**ch.6	Put on treasure	宝置いてけ

Esters who have destroyed the Bazba Brigades.
However, the treasury was empty.
The bandits have escaped with treasure.
"It is a good grasp to escape treasure from a kaitou."
The pursuit of the kaitou's pride begins.

Ruthe joins the group by visiting the village.


**ch.7	Trade city	交易都市

Esters reached the city of Celebillus.
In this town, the garrison guarded by Saar police guards protect the city.
However, they are not aware of the kaitou Group.

Sneak stage.
I wanted to make sneaky stage like midnight sun and Barbarossa 's last stage of AoE 2 campaign so I made it.
Saar likes to talk long, he is speaking to his followers endlessly.
Let's approach the village in the midst of his long wasteful conversation.

Conversation
Shelly->Lucy joins the group


**ch.8	Under vault	地下金庫
At last, the esters who arrived at Celebieus Bank.
An underground safe blocked by thick walls and guards to protect it.
Can esters bring treasure?

Treasures of the underground safe can be obtained by having estell wait on the treasure chest.
Let's move esters from the upper right staircase to the roof, once you have the treasure.


**ch.9	Escape	大脱走

The esters who steal the treasure and fled to the roof of Celeboyu Bank.
The bank was besieged by the police force.
The escort must break this siege net and move to the southeast ruins.

Conversation
Shelley->Maikou joins our group
Armin->Maikou joins our group


**ch.10	探偵参上	Detective coming

The esters managed to escape through the siege.
In the evening it started to rain, so I gave up the mountain and was preparing the homeless.
The siege of the police force broke through, so it's okay now, sudden visitors come to the place where we were careless.
"Esther, be careful. This guy is not just a thing."
Lee stands up quickly.

The man quietly said.

"Kaitou is steal treasure.
And, my job is detective to capture you."

A detective started to catch a kaitou.



---
A detective that hits the rival of the estell appears.
Because there are Holmes, Adler comes out.
I have dealt with BGM remodeling just to put the theme of Sherlock Holmes here.

It is clear if you trace their pursuits and reach the ruins in the north.


**ch11	Rogue career	悪党のキャリア

The estelle were helped by a woman named Adler, the crisis of desperate situation.
She is from Imm village who was attacked by bandits.
She heard that her hometown is attacked by bandits, and she came back from the capital city of Lunes.
Together with Adler, the esters going over the mountain to Im village.

However, in the mountain, Bazuba who was stolen treasure by the esters and was destroyed the organization, was asking opportunities for revenge.
He hired mercenaries with all the assets to revenge on estelle.
He was destroyed Organization by the estelle and stolen the treasure.

In this way, his career as a rogue is over.
Nobody would support him.
In order to recover his career, he had to take revenge.

--
Therefore, Bazuba put all it into this revenge.
Still, he could not beat Esther.
Bazuba was lost everything.
He intended to die.
Bazuba asked Esther to kill himself.


"I brought everything to this fight.
There is nothing left in me.
kill me."


Adler who was listening to it.
"You should not die easily.
If you want to die so much,die after you apologize to everyone in Ide village you vandalized."


"Anyway I am the same as dead.
Do whatever you like."

Bazuba is taken to Adler and taken to Im village.
They will reappear after only a long time left.


-Serafew section is over. Next is Carcino.
Esters who grabbed information that caricino seems to have expensive paintings.

When she heard stories from treasure, she completely forgotten that she was in crisis with Cerefu.
The quickness of this change is also her appeal.

"Treasure is there to be stolen by a kaitou. Let's go steal quickly."



**ch12	Free market		自由市場

Esters who came to the continental first trade port Kiris in Carcino.
Carcino is a country of business, and everything is sold.
Among them, Esther finds slaves to be sold.

On this continent only the carcino is still maintaining slavery.
A slave merchant is a legitimate business approved from the State of Carinchino.
"Slaves are caricino problems and should not intervene."

More than anything, causing a riot here makes it difficult to work.
Still, I could not put up with Esther as my siblings were torn apart and sold.

"This slave will steal this kaitou ester.
Now, unleash the chain of these children and leave!"

It is a stage where justice and evil tips over.
From our viewpoint of modern times, slaves are absolutely evil, but in caricatures in the play it is an ordinary commodity.
Esters that obstruct it, policemen trying to kill slaves trying to escape, which one is justice? 
The dialogue of the estell is a parody of FE's first Noda's slave market.

The name of the slave merchant received from the name of the person who made the temporary staff who can be said as a modern slavery system or social status system.


◆13章 パブロ亭にて		制圧 (2つのスイッチを踏む必要がある)
◆ch13 At Pablo's House

調査の結果、高価な絵画は、カルチノで一番の有力者パブロが保有していることがわかった。
As a result of the survey, it was found that expensive paintings are possessed by Pablo, the biggest influential person in Carcino.

エステル達は、パブロ亭に忍び込んだ。
The estell crept into Pablo.

エステルは気づいていませんでしたが、この行動は探偵に察知されていた。
The estell was not noticed, but this behavior was sensed by the detective.

探偵は、パブロに忠告します。ですが、パブロは怪しい風体の小男を信じませんでした。
The detective advises Pablo.
But Pablo did not believe in a dubious wind body god.

彼には、強力な傭兵団と秘密の隠し部屋があったのです。
He had a strong mercenary group and secret hidden room.



秘密の部屋に入るために、左右のスイッチを押す必要があるステージです。
It is a stage that you need to press the left and right switches in order to enter a secret room.

そのため、二軍にわかれて進撃する必要があります。
Therefore, it is necessary to advance by being divided into two armies.

単純に攻めたり守ったりするステージに、そろそろ飽きてくるだろうと思って作ってみました。
I tried making it on the stage that simply attacks and protects it will get tired of it.

封印のベルン城みたいな感じかな。
It seems like a sealed Bern castle.

本来は、烈火の魔封じのものみたいに手毬寿司っぽくしたかったけど、綺麗なマップが書けずに断念しました。
Originally, I wanted to do Temari sushi like a fiery sealed evil, but I abandoned it because I could not write a beautiful map.

解放奴隷を育てるステージでもあります。
It is also the stage of raising a liberation slave.

下の部隊に解放奴隷を集めて、エステルとリィを手ぶらにして壁を作り、チクチク敵を攻撃させるとか、やるといいと思います。
I think that it is good to gather liberation slaves in the lower troops, make handbills with eskeri and lee, make walls, attack tingling enemies, and so on.

もう一人の探偵ポワロならぬ、ポロロが登場します。
Pororo will appear as another detective Poirot.

探偵ポワロなので、「コックを探せ」で「お前はコックでも探してろ！」で、
Because it is a detective poor, in "The Adventure of the Clapham Cook" to "You are looking for a cook!"

「誘拐された総理大臣」で「誘拐事件の解決が得意」なんですが、果たしてどれくらいの人が理解してくれただろうか。
"The Kidnapped Prime Minister" is "good at solving kidnapping cases", how much people understood how much?


それと、
Also,

コマンドーネタが仕込まれているギャグステージという面も持ち合わせています。
I also have the aspect of gag stage where Commando stuff is put on.

Commando is a movie starring Arnold Schwarzenegger, which is partly popular with cults.
(Commando is a meaningful story and a funny translation, which requires a cultous popularity.)


烈火と違い、CGのカットインがほぼない聖魔で、唯一EDに出てくるリオンとエイルークたちの1枚絵をいい感じに使ってみました。
Unlike the FE7, I tried to use a picture of the one of Rion and eirika who appears in ED only because it is a holy devil whose CG cut-in is almost nothing.


◆14章 プランＢ			拠点到着 (夜)
◆ch14 Paln.B			拠点到着 (夜)
パブロを人質に、脱出用の船へと急ぐエステル達。
The esters took Pablo as a hostage and hurried to the ship to escape.

しかし、この計画は探偵に察知されていた。
However, this plan was sensed by a detective.

探偵に人質を奪い返され、船も奪われ、逆に包囲されるエステル達。
The hostages are taken back by the detective, the ship is also deprived, and the esters which are surrounded in the contrary.

海がダメなら、陸で逃げるしか無い。プランBだ。
If the sea is not good, there is no choice but to escape on land.
It is plan B.


夜の街で、ひたすら逃げるステージです。
It is a stage that escapes in the city of the night.

今までは、増援を狩ってきたかもしれませんが、このマップで増援を狩ろうとすると、事故につながる罠ステージです。
Until now, you may have hunted reinforcements, but trying to hunt reinforcements on this map is a trap stage leading to an accident.


◆15章	スラム街	敵全滅(雨)
◆ch15	Slum area.

エステルたちは、逃げるうちにカルチノのスラム街に迷い込んでいた。
The escort escaped into the slums of Carcino while escaping.

カルチノは大陸一裕福な国家である。
Carcino is a rich continent.

しかし、それはスラム街に全ての負担を押し付けているからにほかならない。
However, it is absolutely necessary as it imposes all burdens on the slums.

エステルたちは、大陸一裕福なカルチノの裏の顔を見ることになる。
The estell will see the face behind the continent, wealthy carcino.



主人公が怪盗いう悪人で、敵が警官隊ということもあり、敵にならず者を使いにくい怪盗パッチにおいて、それを両立させるシナリオを作ってみたかった。
I wanted to make a scenario where the hero is a bad guy who stole a thief and the enemy is sometimes a police corps and in a kaito patch that is hard to use a rogue in the enemy, it makes it compatible.

「警官隊はならず者放置して怪盗に突撃していくなんておかしいじゃないか。普通、住民が困っているならず者を先に退治するべきだろう」
"It's strange that the police force will abandon a rogue and attack the kaito. he's should get rid of the rogue in trouble first."

などと言われるだろうから、それに対する回答になります。
It will be said that it will be answered to that.

ジョージ・オーウェルの小説1984年好きなので、二重思考という単語を出してみました。正義と悪が引っ繰り返ったような、劇中のカルチノを表せたらなと思います。
I like George Orwell's novel 1984, so I tried out the word double thinking.
I wish I could express the carinos in the play that justice and evil were overturned.


ステージの最後に、裏面に絡んでくるフードの男がちょっとだけ出てきます。
At the end of the stage, a man with a hood entangled on the extra stage comes out for a moment.

裏面まで遊んで人は、このマップをもう一度思い出してくれると嬉しいです。
People playing until the extra stage will be glad if you remember this map again.


◆16章 書類をどうぞ		制圧
◆ch16 Papers, Please

スラムを抜け、ルネスとの国境にやってきたエステル達。
Esters who went through the slum and came to the border with Renes.

追っ手を撹乱するため、敢えて、フレリアではなくルネスを経由して帰路に着く計画だった。
In order to disturb the pursuers, it was a plan to arrive on the way back through Renes, not Frelia.

偽造したパスポートも用意している、何も問題はないはずだった。
We also prepared counterfeit passports, there should have been no problem.


しかし、エステルたちは、パブロの影響力を見くびっていた。
However, the estell's were deceiving the influence of Pablo.


アルストツカに栄光あれ！ に感銘を受けて作ったステージです。
しかし、むかついたからという理由で国境破りするヒロインって、どうなんですかね・・・


-カルチノ編 完  グラド編-

なんとかフレリアのアジトへ戻ったエステル。

これ以上、危険はやめようというリィの忠告をエステルは聞き流す。
"これ以上、危険はやめよう"というリィの忠告を、エステルは無視します。
Lee's advice that "I will stop danger any more" is ignored by Esther.

グラド銀行が資本力強化のために、大量に金貨を集めているという情報を聞きつけたのだ。
She heard the information that Grado Bank is gathering a large amount of gold coins to strengthen capital strength.

これは盗まないといけない。
This must be stolen.

こんなお宝の前には、怪盗は引き下がれないのだった。
Before such a treasure, the kaitou could not withdraw.


◆17章 古戦場				20ターン防衛
◆ch17 old battleground

グラドに行くには、ルネスまたはカルチノを通らないといけない。
しかし、両国で問題を起こしたエステル達は、通ることができなかった。
辺境の海沿いを通ってグラド西端の港町ベスロンにたどり着くことにした。

この辺境地帯は、過去の起きたフレリア-グラド戦争で荒れ果てて廃墟になっていた。
その後、フレリアの財政難、グラド首都の震災とトラブルが続き、破棄されていた。

怪盗パッチの"ガラハド"と"アイスソード"について補足する。
I will supplement about the "Galahad" and "Ice Sword" of Kaitou Patch.

"ガラハド"と"アイスソード"は、ロマンシングサガというRPGからです。
"Galahad" and "Ice Sword" are from RPG called Romancing Saga.

https://en.wikipedia.org/wiki/Romancing_SaGa

ファイナルファンタジーを作ったスクウェアから1992年に発売されました。
It was released in 1992 from Square Soft which made Final Fantasy.

フリーシナリオのRPGで、主人公たちは、いいこともできますし、悪いことも出来ます。
In the RPG of the free scenario, the hero can do good things, and can do bad things.

ガラハドは名刀を探している旅人でした。
Garahado was a traveler looking for a sword.

冒険の末、彼はアイスソードという強力な剣を手に入れます。
After the adventure, he gets a powerful sword called Ice Sword.

あまりの嬉しさに、彼は武器を周りに自慢していました。
Too much pleasure, he was proud of its weapons around.

"ねんがんのアイスソードを手に入れたぞ。"
"I got a Ice Sword!"

問題は、彼がプレイヤーにそれを自慢してしまったことです。
The problem is that he bragged about it to the player.

プレイヤーたちも、この名刀アイスソードを探していたのです。
Players were also looking for this sword ice sword.

画面に選択肢が出ます。
The choices appear on the screen.

1."そう、関係ないね"
1."Oh, whatever."

2."頼む譲ってくれ"
2."Please give it to me."

3."殺してでもうばいとる"
3."Kill him even to rob it"

どれを選ぶか？
Which one to choose?

"3"を選ぶと、プレイヤーはガラハドを殺害し、剣を入手します。
If you select "3", the player will kill Garahad and get the sword.

イベントの関係上、プレイヤーは"3"を選ぶことが多いです。
In terms of events, players often choose "3".

プレイヤーがキャラを殺害して、武器を奪うという設定は斬新でした。
The setting that the player killed the character and robbed the weapon was innovative.

それ以来、アイスソードは血塗られた魔剣のイメージが定着しました。
Since then, Ice Sword has established the image of a blooded mage sword.


会話
カルロ->ガラハドが仲間に加入


◆18章 騒乱の港町			ボス撃破
◆ch18 Commotion in a port town

ベスロンの港町にたどり着いたエステル達。
Esters reached the port town of Beslon.

こんな辺境まで追っ手は来ないと油断していたエステルは、警官隊に正体を見破られてしまう。
Esters that had been careful not to pursue a pursuer until such a frontier will see the identity in the police force.

逃げるエステル。追う警官隊。
Escape esters. Following the police force.

いつもの光景かと思われたが、そこへ海賊たちが大挙して押し寄せてきた。
It seemed like usual sight, but the pirates crowd in there in the crowd.

海賊の目的は、港の略奪。
The purpose of the pirates is the looting of the port.
この街の警備責任者は、街を守るために、怪盗エステルと手を組むという異例の決断をした。



この街の警備責任者は、街を守るために、怪盗エステルと手を組むという異例の決断をした。
The security officer in this city made an exceptional decision to combine hands with Kaitou Esther to protect the city.

19章は、警官隊との共闘ステージです。
Chapter 19 is a stage of fighting with the police force.

警官隊は、いつものようにestellを追いかけます。
The police force chase estell as usual.

しかし、そこに海賊が襲来して街を襲いだします。
However, pirates attack there and attack the city there.


この街の保安官Duesselは、estellよりも住民を守ることにしました。
The sheriff of the city Duessel decided to protect the inhabitants more than estell.

それを察知したestellは、警官隊と一時休戦をし、海賊たちから村を守ることにしました。
Estell, who was aware of it, decided to hold a temporary truce with the police force and protect the village from the pirates.

困難な状態で宝を盗み出すことがestellたち怪盗の誇りです。
It is pride of a kaitou estell who steals treasure in a difficult state.

村人から略奪することは、kaitouの誇りに反します。(これはch4 "怪盗の美学"でも登場したテーマです。)
Plundering from villagers is contrary to kaitou's pride. 
This is the theme that appeared in ch4 "Aesthetics of Kaitou".

このステージのボス撃破のボスとは、海賊のボスのことです。
The boss of defeating Boss of this stage is about the boss of the pirate.

それに、Duesselを倒せという目標はどこにも提示されていません。
Besides, the goal of defeating Duessel is not presented anywhere.

より強力な敵が現れることで、今までの敵対していた人たち同士が手を結んで戦う、そんなステージを描いています。
By the appearance of a stronger enemy, I draw such a stage where people who had been hostile to each other fight with each other.

"もし宇宙船で宇宙人が攻めてくれば、われわれはタリバンとだって同盟を組むでしょう"
"If an alien attacks on a spaceship, we will alliate with the Taliban"

これは、そんなステージです。
This is such a stage.

このステージは、ゲーム的に見ると、完璧なクリアをするのはかなり難しいです。
It is quite difficult to make perfect clearance from this stage, from a game point of view.


なぜなら、急がないとDuesselはallyになってしまうため、彼からアイテムを盗めません。
Because, if you do not hurry, Duessel will become ally, so you can not steal items from him.

また、海賊たちもいいアイテムを持っています。
Also, pirates also have good items.

それと、敵は大群で襲ってくるので、新兵のレベル上げにも最適です。
Also, because the enemies attack with hordes, it is ideal for raising the recruits' level.

まずは、急いで進軍し、警官隊からアイテムを盗み、その上でマップ左上で陣形を組み直して、敵を撃破することになるでしょう。
First of all, you will hurry to advance, steal items from the police force, then rebuild the formation at the top left of the map and destroy the enemy.

新兵は、この次のマップぐらいから、一軍として戦えるようにならないといけません。
The recruitment has to start to be able to fight as a union force from about this next map.

そうしないと、難易度が上がってくる中盤以降が難しくなります。
Otherwise it will become difficult after the midfield when the difficulty level rises.


Duesselは、仲間になりません。
Duessel does not become a companion.

Duesselは、最初は敵として登場し、数ターン後にally(green unit)になります。
Duessel first appeared as an enemy, turning into ally (green unit) after a few turns.

このステージでは、彼の生死は関係ありません。
In this stage, his life and death is irrelevant.

盗むものだけ盗んだら、放置してください。そのあと彼がどうなろうと我々は関係ない。
If you only steal things you steal, please leave it.
Regardless of what he will be after that, we have nothing to do with it.


17章、18章は斧の敵が大量に湧いてくるので解放奴隷の新兵を育て上げるのにちょうどいいステージかなと思います。
Chapters 17 and 18 think that it is just a good stage to raise recruits of liberation slaves because a lot of enemies of ax springs up.

19章からは、ソードキラーをもっている敵がいるので、18章までにそれに対抗出来るだけの力をつけさせる調整用のステージです。
From chapter 19, since there are enemies with sword killer, it is an adjustment stage that will give you enough power to counter it by chapter 18.




◆19章 海賊船				ボス撃破(雨/霧)
海賊を追い払い、船を入手したエステル。
Esther who pushed the pirate away and got the ship.

「海賊というからには、お宝をもっているだろう」
"Because they are pirates, they will have treasure"

グラド首都に行く前に、海賊のアジトへと向かっていた。
Before going to the capital of Grado, he was headed for a pirate hideout.





私は、20章について、あらすじを翻訳しました。
I translated the synopsis of Chapter 20.

少し長くなりますが、ここに書きます。
It will be a little longer, but I will write it here.


◆20章 始まりの島			ボス撃破
◆20 Beginning island		boss destroyed

エステルは、海賊のアジトとされる島"始まりの島"を発見した。
Esther discovered the island "Beginning Island" which is regarded as a pirate hideout.

しかし、海賊たちには何やら事情があるらしい。
However, there seems to be some circumstances in the pirates.

この始まりの島は、いろいろな部族に分かれて長い間、戦争を続けてきましたが、モスティンとガザックによって、統一されました。This beginning island has been divided into various tribes and has been in war for a long time but it was united by Mostin and Gazzak.

長い戦乱で島は荒れ果てましたが、ようやく平和になりました。
The long war caused the island to desolate but finally it became peaceful.

しかし、島を統一したことで新たな問題が発生しました。
However, the unification of the island raised new problems.

荒れ果てた島の復興を目指すモスティンと、さらなる領土獲得を目指すガザックの意見の相違です。
It is the difference between Mostin aiming for reconstruction of the desolated island and Gazak aiming for further territory acquisition.

島を統一した両英雄は意見の違いから、仲違いを始めていた。
Both heroes who unified the island started misunderstanding from the difference of opinion.

海賊と思われたものは、ガザックが大陸領土の獲得を目指して動かしていた軍隊でした。
What seemed to be a pirate was an army that Gazzak was moving to win the continental territory.

モスティンは、ガザックたちの武力を使って、島を統一した。
Mustin unified the island  with the military power of Gazaks.

しかし、島が統一され平和になってしまうと、ガザックたちの軍人の重要性は下がってしまった。
However, when the islands became unified and peaceful, the importance of the soldiers of Gazzaks has declined.

ガザックは、より広い領土と活躍の場を求めて、周辺諸島へ侵攻を主張しました。
Gazak claimed the invasion to the surrounding islands seeking a wider territory and a place of activity.

一方、モスティンは、長い部族間の争いで荒廃した島の復興を目指していた。
Meanwhile, Mustin was aiming for the rebuilding of the islands, which was devastated by long tribal conflicts.

これが20章開始時点の状況です。
This is the situation at the beginning of chapter 20.




このパッチでは、"FE1のタリスを襲ったガザック海賊団は、実はタリス正規兵では？"という説を採用しています。
In this patch, I am adopting the theory that "Gazak pirates who attacked Talis of FE1 are actually Talis regular soldiers?"

この説の根拠は、次のとおりです。
The basis of this theory is as follows.

アカネイア暦579年、シーダの父親である、モスティン1世はタリス島を統一しました。
In Akaneia years 579, Mostin who the father of Cedar , unified the island of Thalas.

ゲームでは、モスティン王は温厚な老人に見えます。
In the game, King Mustin looks like a gentle old man.

しかし、彼は、部族間で争っていた島を統一した王です。
However, he is the king who unified the islands which had fought among the tribes.

それでは、彼の軍隊はどこにありますか？
So where is his army?

タリス王宮が海賊に襲われているのに、タリス軍が一向に現れません。
Thalis troops are attacked by pirates, but Thalys troops do not show up at all.

王の軍隊はいったいどこで何をしていたのか？
Where and what were the king's troops the doing?

かつて島を統一した軍隊だというのに。
Even though it was an army that unified the island once.


ここから、驚くべき説が登場しました。
From this point, an amazing theory appeared.

タリス王宮を襲った海賊は、海賊ではなく、彼らこそが、タリス正規兵では？
Is the pirate who attacked the Talith Kingdom not a pirate, Are they the regular Thalis troops?


仮にそれが事実だとしたら、なぜ反乱が起きてしまったのか？
If that was the case, why did the rebellion occur?

タリスのモスティンは、ガザックたちの武力を使って、タリス島を統一した。
Tallis' Mustin unified the island of Tararis with the military power of Gazaks.

しかし、島が統一され平和になってしまうと、ガザックたちの軍人の重要性は下がってしまった。
However, when the islands became unified and peaceful, the importance of the soldiers of Gazzaks has declined.

平時の勇者は哀れです。
The brave in peace is pathetic.

一方で、モスティン王は、人手不足を補うため、そして、大陸との外交のために、落ち延びてきたマルスたちを東端の島の砦に住まわせた。
Meanwhile,King Mustin, to make up for the shortage of manpower, and due to diplomacy with Continent, the Marth who have spread have dwelled in the fort of the easternmost island.

ただ、ガザックから見ると、モスティンがよそ者を招き入れたことになり、彼はさらに不満だった。
However, from the viewpoint of Gazzak, Mostin had invited outsiders, Gazzak was even more dissatisfied.

この意見の食い違いから、ついには反乱が発生したのかもしれない。
From this discrepancy in opinion, at last the rebellion may have occurred.

もちろん、大国であったアカネイアの敗北などの外交要因も彼の反乱を後押ししたのでしょう。
Of course, diplomatic factors such as the defeat of Akaneia who was a big country also helped his rebellion.

こんなお話です。 
It is such a theory. 

この説を元に20章は作られています。
Based on this theory 20 chapters are made.

もちろん、これは二次創作です。
Of course, it is secondary creation.

以上です。
これを翻訳するのに、数時間かかった・・・


ガザックは実はタリス正規軍という説は、このブログの方が最初に提唱されました。
The theory that Gazzak is actually Talis regular army, this blog was the first to be advocated.

http://togege.at.webry.info/201402/article_1.html

このブログは、いろいろなゲームに対して、深い考察と大胆な理論を展開されていて面白いです。
This blog is fascinating for deep thought and bold theory developed for various games.

日本語なので、翻訳ツールを使って読んで下さい。
Since it is in Japanese, please read it with translation tool.


I really hope to see more people experiment with nonstandard FE portrait styles with tools like this showing up

私は実際にこのようなツールを使って非標準のFEポートレートスタイルを実験する人が増えていくことを期待しています\r\n


Now that you mentioned RPG Maker, there really is a huge amount of resources for it that can be used in FE hacks.


21章は、シャーロック・ホームズの赤毛連盟をベースにしたお話です。
Chapter 21 is based on Sherlock Holmes' The Red-Headed League.

エステルは、グラド銀行の地下にトンネルを作ります。
Esther makes a tunnel in the basement of Grado Bank.

しかし、それを探偵に察知されてしまい、彼女たちは危機に陥ります。
However, they are detected as detectives, and they fall into a crisis.

トンネルを逆走して逃げ出すのが目的です。
The goal is to run backwards through the tunnel and run away.





◆21章 赤パッチ組合		拠点到着
◆ch21 

なんとかグラド首都にやってきたエステル達。
The esters who came to the capital of Grado somehow.

グラド銀行を偵察するも、あまりの警備の厳重さに手を出せないでいた。
Though they scouted the Grado Bank, they were unable to handle too much security.

しかし、エステルは一つのアイディアを思いつく。
But, Esther comes up with one idea.

「確かに警備が厳重ではあるが、それは地上と空だけだ。地下からの侵入は可能ではないか？」
"Although security is certainly strict, it is only the ground and the sky.
Is it possible to invade from underground? "

エステルは、銀行付近の家を借り、地下トンネルを掘り始めた。
Esther borrowed a house near the bank and began digging the underground tunnel.

ルーテの発明した掘削機で地下トンネルを掘り進めるエステル。
An ester that digs the underground tunnel with the excavator invented by Rute.

エステル達は、地下トンネルを通って地下金庫に忍び込む。
The escort sneaks into the underground safe through the underground tunnel.

完ぺきな作戦だった。
It was a perfect strategy.

しかし、その戦略は、探偵たちに察知されていたのだった。
However, the strategy was sensed by the detectives.






この22章や、14章 PlanB は、夜の索敵マップですが
This 22 chapter and 14 PlanB are the search maps of the night...

ゴール地点が明るくなっていますよね。
The goal point is getting brighter.

普通に、夜のマップを作ると、ゴール地点も暗くなってしまいますが、
Normally, when you create a night map, the goal spot will also become dark,

この改造では、FE5のように、ゴール地点に明かりを灯しています。
In this remodeling, like the FE5, the lights are lit at the goal spot.


ゴール地点の近くの壁の中に、友軍の透明なGorgon Egg(ステータスを確認できないクラス)があります。
In the wall near the goal point, there is a ally and transparent Gorgon Egg (class whose status can not be checked).

敵AIには、その透明な友軍を攻撃しないように指示しています。
I instruct enemy AI not to attack its transparent friendly troops.

友軍とは視界が共有されますので、ゴール地点を明るく照らすことが出来ます。
Visibility is shared with ally, it is possible to light the goal spot brightly.

can you please not have bishops that have sleep staves that have the range of the entire goddamn map

あなたは眠っている司教たちに、地図全体の範囲を持つ譜表を持ってはいけないのですか？\r\n
what am i supposed to do
both of my units are asleep


Restoreを使いましょう。
Let's use Restore.

Restoreは店で売っています。
Restore is sold at the store.

詰まないように、進撃準備の店でも販売しています。
I sell it even at shop preparation shops so as not to clog.

そのステージは、18人ぐらい出せたように思う。
I think that the stage was about 18 people.

複数のRestore使いを出せばいいと思う。
I think that you can issue multiple restore usage.

いろいろなところで何度か説明していると思うが、
I think that it explains several times in various places,

このパッチは、少数精鋭だと、このあたりからどんどん難しくなってきます。
This patch will become more and more difficult from this point if it is a minority elite.



◆22章 深夜の大包囲網		35ターン以内に拠点到着(夜)



増援を狩るステージには、いい加減に飽きてくる頃だと思うので、変化球としてターン制限ステージを作ってみました。

ターン制限をされると、プレイヤーに見えない焦りを与えられて、
通常の難易度にプラスαの難易度を与えられそうです。

制限35ターンの半分以下のターン数で、クリアできるステージなのですが、所見プレーはなかなか焦るステージだったと思います。
ターン制限は、ゲーム後半ぐらいに出すと、いい感じのスパイスになると思います。


-グラド編完  ルネス編-
包囲網をやぶって船へと逃げるエステル。

しかし、船はルネス警官隊によって押さえられていた。
However, the ship was held down by the Ronesse police force.


なぜ、ルネスの警官隊がグラド領に？
Why is Renes' police force in the Grad region?

怪盗エステルを捕らえるべく、カルチノ、ルネス、グラドが手を結び包囲網を完成させていた。
In order to capture the Kaito Esther, Carcino, Renes and Grado joined hands and completed a surrounding net.

そこへ名探偵の二人の知恵が加わり、エステルは敗北を喫した。
Two wisdom of the greate detective joined there, and the ester lost the defeat.

こうして、怪盗エステルはついに警官隊に捕らえられた。
In this way, the Kaito Esther was finally caught by the police force.

正義は勝ったのだ。
Justice won.


◆23章 牢獄				拠点到着
◆23 Prison.


エステルは、死刑を宣告され、処刑場でもある砂漠の牢獄へと送られた。


怪盗ものの定番、脱獄ステージ(ネタバレ)。
エステルの輸送隊の恩恵を思い出させるステージでもあります。

このステージをクリアすると、
モリアーティとアドラーという終盤の重要人物がすべて揃い、エステルが大怪盗にCCして、物語は終盤へと進みます。

会話
リィ->アドラー|バズバが仲間に加入


◆24章 ルネスの国宝		王座を守りながら、女性で戦士系キャラだけでボス撃破

北にある宝の部屋に入れるのは、女性で戦士系のユニットだけです。
It is only women's and warrior-based units that put in the treasure room in the north.

以下のユニットになります。
It becomes the following unit.


エステル Estelle(kaitou)
シェリー Sherry(Dancer)
キャシー Cathy(Archer)
アラベラ Arabelle(Myrmidon)
ネイミー Neimi(Archer)
マリカ Marisa(Myrmidon)
アメリア Amelia(Soldier),
リナ Lina(Pegasus Kn)

ルパン3世のくたばれ!ノストラダムス　みたいに、仕掛けを突破するお話を作りたかったステージです。
女性で戦士系だけでボスを倒さないといけないし、玉座も守らないといけないしで、割り振りに苦労するところです。

仲間になった、アドラーとモリアーティは即1軍になれるだけのステータスはあるんですが、HPが低いので苦労するかもしれません。
怪盗パッチでは、このキャラは、このステータスだけは上がりにくいというのを作っていて、ドーピングアイテムをまんべんなく盗ませる動機づけにしています。


◆25章 川下り				20ターン生存
マップ全体が変化するステージがあってもいいよね。ということで作ったステージです。終盤最初の難所です。
一つの船に味方を全て集めて、支援スクラムを作るのがコツだと思います。

また、マップ変化がやっと自在に使えるようになったのと、村チップの上でしか訪問メニューが出ないことがわかったので、それを組み合わせて、1ターンしか出てこない村を作ってみました。
この村で、盗品の金の鍵を拾えますが、The Last Promiseの伝説の武器とかみたいに、盗品リストをコンプしようとすると、まずとり忘れるやりこみ用のアイテムになります。


◆26章 国賊となった女		20ターン生存またはボス撃破
なんとかフレリアのアジトへ帰り着くエステル。
そこへルネスの特殊部隊が向かっていた。

国宝を盗まれたことで、ルネス国の正式な敵と認定されたエステルを、速やかに斬首するためルネスの特殊部隊が動き出したのだ。


赤すぎる人たちが引き起こしたらしいなんとか山荘事件みたいに、壁を壊して突撃してくる特殊部隊を描きたかったステージです。
もちろん、主人公は悪人なので、突撃される側なんですけどね・・・

ルネスの特殊部隊は超高価な装備をもっているので剥ぎ取ると稼げるステージです。こんなにいい武器を支給しまくっていて、ルネスの財政は大丈夫なんでしょうか。

◆27章 もっと国賊らしく	15ターン以内にボス撃破
燃え落ちるアジトから命からがら逃げ出したエステル。
「人の家を壊してくれてこの修理代は高くつくぞ。」

なんとか逃げ延びたのはいいが、今後を考えるエステル。
そこへ悪の軍師モリアーティが面白い提案をする。
モリアーティ「この時期、ルネスは各地から徴税した税金を馬車に乗せて運ぶのです。面白くありませんかな？」
リィ「しかし、そんなことをすればルネスを激怒させてしまいます」
エステル「もう既に怒っているじゃない。死刑を宣告されて特殊部隊を送り込まれたわ。」
モリアーティ「その通り、死刑より酷い罰はないし、国賊より酷い称号はない。気にする物は何もない。」
エステル「そうね。アジトの修理代をいただきにいきましょう。」
どこまでもポジティブなモリアーティとエステルだった。




こんなひどい悪人が今までいただろうか。
と、プレイヤーをうならせるステージです。

ボスを倒せばクリアですが、怪盗のダークサイドに落ちたプレイヤーは、国賊と化したエステルたちのように、執拗な追い剥ぎを始めるでしょう。

何も考えれば、ジェネラル壁に穴開けて、ボスを倒せばいいだけなので、
1ターンクリアも可能です。
でも、怪盗として宝を盗まないとかありえないと思います。そして、盗もうとすると、敵がかなり強いので難易度が跳ね上がるマップです。


しかし、FEシリーズの軍師って兵力分散好きだよなあ・・・


◆28章 逃走と闘争			奪った馬車を南東の砦までつれていく

ルネスの徴税官を襲い、大量のルネス金貨を入手したエステル。

Esther who attacked Ruth's tax collector and obtained a large amount of Ruthness gold coins.

想像以上の金貨に驚くも、ゆっくりしている場合ではない。
She is surprised at gold coins beyond imagination, but now she has to get away in a hurry.

すぐに追っ手が来るだろう。
A pursuer will come soon.

私たちは奪った馬車を山奥の砦まで持っていかなくてはいけない。
We have to take the robbed carriage to the mountain front.


奪った馬車を山奥の砦まで誘導してください。
Please guide the robbed carriage to the fortress in the mountains.

馬車を山奥の砦に連れて行けばクリアです。
It is clear if you take the carriage to the fort in the mountains.

序盤からずっと活躍してくれたルネス警官隊たちの最後の戦いでもあります。
It is also the last battle of the Renez cops who have been active since the beginning.

この辺りから、味方も結構育ってきて、増援を狩るのが、武器の無駄でしかなく、デメリットにしかならなくなると思います。
From this neighborhood, friends are also growing quite well, hunting reinforcement is only a waste of weapons, I think that it will only become disadvantage.


◆29章 闇の中で			20ターン生存またはボス撃破(夜)
エステルたちの襲撃を受け、ルネスは税収の10%を失った。
Renes lost 10% of the tax revenue following the attacks of the esters.

その報告を聞いた官僚は卒倒し、王は激怒した。
The bureaucrat who heard the report fainted and the king was furious.

「なんとしても、エステルたちを殺すのだ」
"Anyway, kill the esters!"

王の命令に暗殺部隊が動き出した。
An assassination unit started moving at the command of the king.

一方エステルたちは、山奥の砦に潜み、今後の方針を決めようとしていた。
モリアーティは驚くべき案をエステルに話した。
「エステル殿、この金貨の一部でカルチノの反政府勢力に武器を提供してはどうか。」

カルチノは激しい格差社会を生み出し、社会不満は反政府勢力を産んだ。
しかし、まだまだ勢力は小さく、資金も武器もなかった。
そのため、大規模な反乱まではいかなかったのだが、
モリアーティは、そこに資金と武器という火薬を流し込もうというのだ。

「そうすれば、ルネスは我々よりカルチノを助けるため動かざる終えまい。その隙に我々は次の行動に出れば良い。」

リィは反論する。「しかし、それではカルチノの人民を我々の盾に使うことになる。」

「確かに見方によってそう見えるだろう。しかし、格差のためにただ死んでいくのと、自ら未来を勝ち取るために戦う機会を得られるのの違いだ。あなた達はスラム街を見ただろう。もしかすると、革命がうまくいき、より素晴らしい社会が作られるかもしれない。選ぶのはカルチノ人自らだ。私は彼らに選択肢を与えよういうのだ。」
モリアーティは不敵に笑った。

最終的に、モリアーティに説得され、資金の一部を反政府勢力に渡すことにしぶしぶ同意したエステル。

一ヶ月後、モリアーティたちは反政府勢力と交渉を終えて戻ってきた。
エステルたちは、警官隊を交わすために、なんどか拠点を変えながらも、追撃を逃れていた。



◆30章 ロストンアカデミー	拠点到着
潜入ステージ。やることがいくつかあるので忙しいマップです。
Sneak stage.
There are several things to do and it is a busy map.

まず、ドズルを倒して、鍵を入手します。
First of all, beat the dizzle and get the key.

そうすると、右側の部屋に入れるようになります。
Then you will be in the right room.

右側の部屋の宝箱の上にエステルを待機させると、魔導線の設計図を入手できます。
If you let Esther stand on the treasure chest of the room on the right side, you can get the design drawing of the magic wire.

魔導線の設計図を入手すると、左側の部屋に入れるようになります。
When you obtain the design drawing of the magic wire, it will come to be in the room on the left side.

左側の階段の上に、エステルをつれていくとクリアです。
It is clear when you bring esters on the left stairs.

敵の増援をはねのけながら、ステージを横断する必要があるステージです。
It is a stage that needs to cross the stage while taking over enemy reinforcements.

これでエステルたちは大陸にあるすべての国に喧嘩を売ったことになります。
もちろん、本人たちは、まったく気にしていなさそうです。

This means that the esters have sold fights to all the countries in the continent.
Of course, the principals do not seem to care at all.





◆終章 テイクオフ			ボス撃破(エネルギーチャージ)
◆last chapter take-off

絵がかけないけど、でかいラスボスを出したいので、マップチップを利用してでかいキャラを表現してみました。
I do not draw pictures, but I want to get big rasubos, so I tried to express big characters using map chips.

また、武器補正パラメータをつかって、何かできないか？と思い、こんなラスボスを出してみました。
Also, can you do something with the weapon correction parameters? 

当初は、飛んでいる魔導船をハイジャックするなんてシナリオも考えていたのですが、CoDみたいなFPSだと良いかもしれないが、SRPGとしてどうなるんだ、ラスボスは機長とかになるの？増援はどこから来るの？となり没になりました。
Originally, I thought of scenario to hijack the flying magic ship, but it may be good if it is FPS like CoD, but what happens as SRPG, will Rasubos become captain or something?  It became such a thing and it got submerged.


魔道士をたくさん育てて、支援スクラムがあれば、1ターンクリアもできてしまう謎ステージです。
It is a mystery stage where you raise a lot of mages and if you have a support scrum, you can clear one turn.


一応、3ターン目に、魔道書切れで詰んでしまうのを回避するために、
For the first time, in order to avoid stuffing with magical book breaks in the third turn,

高額な魔道書をタダでゲットできるイベントがあるので、それまで撃破をまったくれたら嬉しいんだけどねえ・・・
There is an event where you can get an expensive mage by Tada, so it will be nice if you could defeat it until then ...


ホームズとモリアーティが出会ったら、こうなるendしか思いつきませんでした。
When Holmes met Moriarty, I could think of only end like this.

映画のシャーロック・ホームズでも、ドラマのシャーロックでも、
Even in movie Sherlock Holmes, drama Sherlock,

結局こうなるわけで、この二人が出会うとやっぱりこういうendになってしまうんだろうなと思いました。
After all it was eventually so I thought that if these two people met they would end up like this.



-裏面-
ここから正義の話です。
-extra stage-
Here is the story of justice.



ルネスの国宝を盗んだことで、エステルはルネスから国賊として命を狙われました。
By stealing the national treasure of Renes, Esther was targeted as a rogue from Renes.

国王は、フレリアのエステルのアジトに特殊部隊を送り込み、彼女を暗殺しようとしました。
The king sent special forces to the hideout of Frelia 's Esther and tried to assassinate her.

エステルたちは何とか逃げ出しましたが、アジトは焼け落ちてしまいました。
The escorts escaped somehow, but the hide was burned down.

モリアーティは、エステルに、アジトの修理代をルネスに請求する作戦を立案しました。
Moriarty planned an operation to charge Lenes to repair the hideouts for Esther.

ルネスはこの時期になると、各地から税金を集め中央に送金します。
In this period, Renes collects taxes from various areas and sends money to the center.

モリアーティの作戦は、この徴税管の輸送体を襲い、ルネス金貨を奪取することでした。
Moriarty's strategy was to attack the transport body of this tax collector and take Rueness gold coins.

エステルたちは、徴税管の輸送体を襲い、ルネスの税収の10%にある額を奪うことに成功しました。
The esters attacked the transport body of the tax collection pipe and succeeded in robbing the amount which is 10% of the tax revenue of Renes.

この知らせを聞いたルネス王は激怒し、エステルを斬首する部隊を送り出しました。
King Renes who heard this news was furious and sent out a unit to decapert the ester.

エステルはその金貨を山奥の隠れ家に隠し、今後の計画を話し合っていました。
Esther hid its gold coins in a hideout in the mountains and was discussing plans for the future.

そこでモリアーティは、また驚くべき提案をします。
So Moriarty will also make amazing suggestions.

その計画は、入手した金貨を武器に変えて、カルチノの反政府勢力に配ろうというのです。
The plan is to convert the gold coins you acquired into weapons and distribute it to the caricino rebels.


カルチノは、資本主義と民主主義を前面に推し進めた国家です。
Carcino is a nation that pushed capitalism and democracy forward.

それにより、カルチノは大陸一裕福な国家になれました。
By doing so, Carcino became a rich country on the continent.

しかし、一方で過度の競争により、貧富の差は絶望的に広がっていました。
However, due to excessive competition, the gap between rich and poor had spread desperately.

競争に敗れたものは、スラム街へ追いやられました。
Those losing the competition were driven to the slums.

また、選挙制度も形骸化し、票の買収や不正がまかり通っていました。
In addition, the electoral system became funeral, and the acquisitions and injustices of votes were prosperous.

そのため、本来不正をただす民主主義は機能不全に陥っていました。
As a result, democracy that originally misrepresented was in dysfunction.

金持ちたちにより、より金持ちに有利なルールが作られて作られていました。
It was made by rich people, making more rich favorable rules.

こうした絶望的な状況に、反政府勢力が生れていましたが、彼らは、資金も武器もなく、組織だった抵抗ができずにいました。
In these desperate circumstances, rebel factions were born, but they had no funds or weapons and were unable to resist the organization.

モリアーティの計画は、反政府勢力に武器と資金を提供することで、カルチノで革命を発生させようというものです。
Moriarty's plan is to make revolution in the carincho by providing weapons and funds to the rebels.

ルネスにとって、隣国のカルチノで革命が発生すると、見過ごすわけにはいきません。
For Renes, if a revolution occurs in the neighboring carnocino, it can not be overlooked.

また、ルネスは魔王を倒した英雄の国として、大陸全土へ強い発言力がある国です。
In addition, Renes is a country with a strong voice in the whole continent as a hero's country that has killed the Devil.

ルネスは、この大陸のリーダーとして振る舞わなければなません。
Renness must act as a leader on this continent.

もし、カルチノから救援を求められたら、ルネスは軍隊を派遣しなければならないでしょう。
If asked for relief from the carnino, Renes would have to dispatch an army.

そうなると、ルネス軍は怪盗エステルを追いかけている場合ではなくなります。
Then, the Lunes troops are no longer chasing after a kaitou estell.


エステルは、この間に、ロストンアカデミーで開発されている魔導線を盗んで、別大陸に逃げる作戦を立てました。
In the meantime, Esther stepped the magic line developed at the Loston Academy and made a strategy to escape to another continent.

エステルがロストンへ移動すると、哨戒にあたっていたルネス軍に発見され、森へ追い詰められ、絶体絶命の危機に陥ります。
As Esther moves to Roston, it is discovered by the Renes army who was patrolling, trapped in the forest, and falls into a crisis of desperate situation.

丁度その時、カルチノで革命が勃発し、ルネス全軍にカルチノ国境に集結するようにという指令が発せられました。
At that time, the revolution broke out in the carcino and a command was issued to bring all the troops of Renes to the Carcino border.

エステルは、この隙をついて逃げ出し、ロストンへたどり着いたのでした。
Esther escaped with this gap and reached Roston.

このままロストンで魔導線を盗んで、別大陸に逃げれば、怪盗パッチのメインシナリオをクリアになります。
If you steal a magic wire in Roston and escape to another continent, you will clear the main scenario of Kaito patch.


ここからはエピローグで語られる内容になります。
From here it will be the content to be talked about in epilogue.

エステルは、このあと、別大陸であるアカネイア大陸に到着します。
Esther will then arrive on the continent, Akaneia, another continent.

彼女はそこでも怪盗を続けました。
She kept on kaitoba even there.


そして、彼女はアカネイア大陸のラーマン神殿にて 5つの輝くオーブと盾を発見しました。
And she found five shining orbs and shields at the Rahman Temple of the Akanea Continent.

彼女はこのオーブを売り払い、より強力な軍隊を組織し、
She sold this orb, organized a more powerful army,

部族間の対立で混乱していたアカネイア大陸を統一するべく、戦いを開始したそうです。
He seems to have started fighting to unify the continent of Akaneia who was confused by tribal confrontation.

-Continue to FE1-



ここで、ロストンで船を盗まずに、カルチノの反政府勢力を助けに行くのがextra stageです。
Here, it is the extra stage that goes to help the reckless forces of Carcino without stealing the ship at Roston.

エステルは、カルチノの人たちを、自分たちが逃げるための盾に使うことができませんでした。
Esther could not use the people of the Carcino as a shield for them to escape.

そのため、モリアーティたちの反対を押し切り、彼女はカルチノの反政府勢力を助けます。
Therefore, by opposing Moriarty's opposition, she will help the reckless forces of Carcino.

劇中でカルチノは3回革命が発生します。
In the play Carucino will have three revolution.

カルチノは腐敗した資本主義国家です。
Carcino is a corrupt capitalist state.

この腐敗した資本主義国家を壊滅するべく、カルチノの反政府勢力 "カルチノ人民解放会議"が立ち上がりました。
Carcino 's anti - government force "Carcino People' s Liberation Conference" launched to destroy this corrupt capitalist state.

カルチノ人民解放会議の、ゼーリン議長は貧富の差とは、資本の暴走であると考えて、資本を否定し、共産主義政権を作り上げます。
In the Carcino People 's Liberation Congress, Chair Zehlin thinks that the gap between rich and poor is the runaway of capital, denies the capital and creates a communist regime.


すべては国の直営にし、計画経済による発展こそが、最も進んだものだと彼は盲信しています。
He makes everything directly to the state, he is blind to believe that development by the planned economy is the most advanced one.

しかし、ゼーリン議長は演説はうまいのですが、統治の能力がありません。軍事的才能もありません。
However, Chair Zehlin is a good speaker, but he has no ability to rule.
I do not have military talent either.


そのため、彼の軍隊は、正規軍に押されて危機に陥っていました。
Therefore, his army was in a crisis pushed by the regular army.

エステルは彼を助けるために活躍します。
Esther works to help him.


エステルの活躍もあり、革命軍は危機を乗り越えます。
With the success of esters, the revolutionary army overcomes the crisis.

しかし、革命軍の一部は、エステルの制止を無視して、必要に敵を追撃しました。
However, a part of the revolutionary army pursued enemies as necessary, ignoring the restraint of esters.

案の定、革命軍は政府軍の罠に落ちてしまいました。
Sure enough, the Revolution Army has fallen into the trap of the government army.

エステルは、見殺しにはできないと救援に向かいます。
Esther heads for relief that you can not kill it.

しかしこれこそが政府軍の本当の罠でした。
But this was the real trap of the government army.

救援に向かったことで、革命軍のアジトの警備が手薄になってしまいました。
By going to relief, security of the hideout of the revolutionary army became weakened.

政府軍は、そこを襲撃し、革命軍のアジトを占拠したのでした。
The government army attacked there and occupied the hideout of the revolutionary army.

革命軍は、帰る家を失いました。
The Revolutionary Army has lost a home to return home.

ゼーリン議長は、こうなったのは救援を行ったエステルのせいだと、エステルに責任転嫁します。
Chief Seelin told the escort that this was due to the escaped escort, it will pass on to the ester.

いわれなき非難にエステルは驚きます。
Esther is amazed at blaming accusations.

モリアーティはなんとか両者の中を仲裁します。
Moriarty will arbitrate among them.

"だから、彼らにかかわるなといったのです。 しかしかかわってしまったもの仕方ありません。何か方法を探しましょう"
"So it was said that they did not concern them. But it has nothing to do with things involved. Let's look for something "

アドラーとリィは近くに敵の補給基地があることを発見します。
Adler and Lee discover that there are enemy supply bases nearby.

この基地を襲撃し、補給と新たな拠点にする作戦に出ます。
It attacks this base and puts out a strategy to supply it and make it a new base.


エステルたちは、補給基地を襲撃し、物資と新しい拠点を手に入れました。
The escortists attacked the supply base, got supplies and a new base.

基地には、物資の他に、別大陸の武器を模倣して作られた試作武器がありました。
At the base there was a prototype weapon made by imitating a weapon of another continent in addition to supplies.

これは、全パラメータにボーナス+10が入る優れた武器です。
This is an excellent weapon with a bonus of +10 for all parameters.

この武器はhammernで修理することができます。
This weapon can be repaired with hammern.

ここからはFE5のように、武器を修理しながら戦うことになります。
From here we will fight as we repair weapons like FE5.

敵の薬を盗めば資金になります。それを売却してハマーンを買いましょう。
If you steal enemy medicine you will be funded.
Let's sell it and buy Hammern.

敵のボスにも試作武器を持ったものが出てくることがあります。
Some enemy bosses also have prototype weapons.

彼らからは武器を奪いましょう。
Let 's take away weapons from them.

武器の耐久は60あるので、どんどん使って、10ぐらいになったらハマーンで回復させましょう。
Since there are 60 durable weapons, let's use it more and more and let us recover with Haman when we get around 10.


エステルたちは、補給基地を拠点に戦い、ついにカルチノの首都とスラム街を隔てる城壁へとやってきました。
Esters fought at the supply base as a base and finally came to the wall that separates the capitol of the Carcino from the slums.

ここグレートウォールと呼ばれている難攻不落の要塞です。
It is an impregnable fortress called Great Wall here.

どうやっても城門は開かないので、壁を壊すか、空を飛んで仲間を内部へ侵入させましょう。
Since the castle gate will not open anyway, let's break the wall or fly the sky and let the companion invade inside.

村人の家を訪ねると、共産主義者が来たといって逃げ出します。
When You visit the villagers' house, they escape by saying that the Communists came.
マップ南西の建物を占拠するとクリアです。

マップ南西の建物を占拠するとクリアです。
It is clear to occupy the map southwest building.

この建物が城門を制御している装置です。
This building controls the castle gate.

これにより、カルチノ革命軍はカルチノ首都へ突入します。
By doing this, the Carcino Revolution Army enters the Capuchin capital.

議事堂を始め重要な施設を革命軍は占拠していきます。
The Revolutionary Army will occupy the important facilities including the Parliament House.

こうして、カルチノ首都は陥落したのでした。
In this way, the capuchin capital has fallen.

ここから平和なカルチノがうまれる・・・はずだったのですが、
It was supposed to be a peaceful carcino from here .... However,

ゼーリン議長は、自分の理論、理想の実現のためのみに固執します。
Chair Zehlin sticks only to realize his theory, ideals.

彼の資本への敵対心は、果てしないものがあり、すべての資本、ブルジョアを恨んでいました。
His hostility towards capital was endless, and He had a grudge against all capital, bourgeois.

その結果、都市に暮らしていたものは、都市に暮らしていたことを理由に処刑され、都市は略奪されました。
As a result, what was living in the city was executed for the reason that he lived in the city, and the city was plundered.

エステルは、それを止めようとします。
Esther will try to stop it.

市民から略奪するとは何事です。
It is nothing to loot from citizens.

しかし、ゼーリン議長は聞き入れません。
However, Chair Zeelin does not listen.

エステルは、ゼーリン議長から煙たがられ、キリス港にいる残党狩りを押し付けられます。
Esther is smoked out by Chairman Sheulin and is pushed for remnant hunting at Kiris Port.

エステルは、ゼーリン議長に愛想を尽かしていました。
Esther was curious about Chairman Zeelin.

エステルは、キリスを平定したら、そのまま船でこの地を立ち去るつもりでした。
Esther, after flattening Kiris, was going to leave this place with a ship.


なんとかキリスを平定したエステルは、そのまま船を調達し、この大陸を離れようとしていたころ、早馬がやってきます。
Esther who scooped Kiris managed to procure a ship as it is, when Horima is about to leave this continent.

ルネスがこのカルチノ革命に介入し、ゼーリン議長がいる首都を陥落させたというのです。
Renes intervened in this caricino revolution, he fell down the capital where Zoynin is located.

ゼーリン議長は、命からがら逃げだしたものの、敵に囲まれて絶体絶命というのです。
Chief Executive Zealin escaped for life, but it is surrounded by enemies and desperate stuff.


"確かに彼はあんな人物だが、見殺しにするわけにはいかない"
"Surely he is such a person,but I can not let you kill him"

エステルは、ゼーリンを助けるべく引き返すことに決めました。
Esther decided to return to help Zealin.


なんとか敵の包囲網を破りゼーリン議長を助けたエステル。
Ester who helped Chair Zein broke the enemy's enclosing net somehow.


"助けに来るのが遅い!"

"You are late to come to help!"
ゼーリン議長は助けに来てもらったにもかかわらず、エステルを叱りつけます。
Despite Chairman Seelin coming to help, he scolds Esther.

あまりのことにエステルも怒ります。
Too much ester is angry, too.

"そうですか。それでは、私たちはこれで引き揚げさせてもらう。あとは一人でやってください。"
"Is that so. Well then, let us go home with this. Please do it youself."

それを聞いて、ゼーリン議長は青ざめます。
When listening to it, Chief Sealin pales.

エステルがいなければ、ルネス軍を追い払うことはできないでしょう。
If there is no Esther, you will not be able to drive Renness troops away.

彼の態度は一変し、エステルに泣き叫んで慈悲を乞います。
His attitude changes completely, begs for mercy by crying for Esther.

彼は子供のように泣き叫び慈悲をこいました。
He cried like a child and had mercy.

"なんということだ。これがカルチノの新しいリーダーだというのか"

"I can not believe that. Is this a new leader of the carcino?"
"So, I told you not to be involved with these people"

エステルは、ゼーリンに対して、約束を迫ります。
Esther approaches promises to Zealin.

ゼーリンは仕方なくそれを受け入れます。
Zeelin will accept it without any help.

"1.私の許可なく軍を動かすことを禁じる"
"1.Forbidding the movement of the army without my permission\"

"2.市民への略奪を禁止する"
"2.Prohibit looting to citizens"

"3.ルネスを追い払った後は、ルールを制定し、そのルールに従った公平な国を作るようにする"
"3.After chasing away Ruthnes, enact rules and establish a fair country according to that rule"

ゼーリンから、軍の指揮権を譲り受けたエステルは、ルネス軍をカルチノから追い出すべく作戦を開始した。
From Zeelin, Esther who got the command of the army started a strategy to drive out the Renness army from the carncino.

まずは、奪われた首都を再奪還しないといけない。
First of all, we must recapture the deprived capital.

首都では、ルネスの魔道将軍が率いる精鋭が待ち構えていた。
In the capital, the elite led by Renes' mage general was awaiting.



ルネス軍から首都を奪還したエステル。
Esther who recaptured the capital from the Lunes army.

首都の統治は、当面の間は住民の自治にまかせることにした。
We will decide to govern the capital by the residents' autonomy for the time being.

まだまだカルチノには、ルネス軍の救援がいます。
There is still relief of the Lunes Army on the carncino.

これらを国境まで退けなければならない。
We must reject these to the border.

エステルは、カルチノにある草原で、ルネス軍の大群と対峙することになった。
Esther was a grassland on the carnino, confronting the hordes of the Lunes army.

この戦いの成果で戦いの流れが変わるだろう。
The result of this fight will change the flow of fighting.


草原の戦いで、ルネス軍の大群に勝利したエステルは、ついにルネス国境までルネス軍を退却させることに成功した。
Esther who won the hordes of the Renes army at the battle of the grassland finally succeeded in retiring the Renness army until the Lunes border.

ルネス軍としても、ここで負けるわけにはいかない。
As Lenes' army, we can not lose here.

大陸のリーダーとしての軍隊が、反政府勢力に敗北するわけにはいかない。
The army as the leader of the continent can not defeat the rebel faction.

両者の最後の戦いが始まる。
The last battle of both begins.



ルネス軍は敗北した。
The Renness army was defeated.

彼らは、ルネス国境の向こうまで退却した。
They retreated to the other side of the Lunes border.

両者の間では、講和が結ばれ平和が訪れるだろう。
Peace will come between peace and peace.

"エステル殿。われわれを救ってすくっていただきありがとうございます。どうか、今後もカルチノをどうか導いていってください。""Estelle.
Thank you for rescuing us and scooping up.
Please continue to guide Carcino in the future.".

兵士たちは、エステルを救国の英雄として歓迎した。
The soldiers welcomed the esters as heroes of salvation.

エステルの活躍は誰の目にも明らかだ。
The activity of Esther is clear to everyone's eyes.

彼女には軍事的才能と、市民をいたずらに虐待しない統治者としての才能があった。
She had a military talent and a talent as a ruler not abusing civilians unnecessarily.

彼女は公平だったし、命を懸けてカルチノのために最前線で戦った。
She was fair and she fought for life with a forefront for carcino.

兵士や、カルチノの市民たちは、エステルならばカルチノを正しい方向に導いてくれると信じのだ。
Soldiers and citizens of the Carcino believe that if it is an ester it will lead the carcino in the right direction.

"エステル、ついに盗んでしまいましたね。国を盗むなんてなかなかできることではないですよ。"
"Esther, You finally got stolen. Stealing the country is not quite what you can do."

仲間から言われてエステルも気がした。
Esther also felt from my friends.

なるほど、私たちはカルチノという国を盗んでしまった
Indeed,  We have stealed the country of carin.



ゼーリン議長はこれを快く思わなかった
Chair Zehlin did not feel comfortable with this

革命のリーダーは自分である。
The revolutionary leader is myself.

それなのに、国民はエステルをリーダーとして扱う。
Yet, the people treat esters as leaders.

自分の理想の国家を作る上でエステルは邪魔である。
Esther is an obstacle in making your ideal state.

公平な社会を作るには、自治などいうものは不要である。
In order to create a fair society, things like autonomy are unnecessary.

すべての方針は自分が決め、それに従って実施される計画経済こそが、この国を発展させるのだ。
It is the planned economy that decides all the policies themselves and will be implemented accordingly, develop this country.

敵も追い払ってくれたことだし、そろそろエステルには消えてもらわないといけない。
It is that the enemies have driven away, and it is about time for the esters to disappear.

この国のために。私の理想のために。エステルを殺さなければならない。
For this country. For my ideals. I have to kill the ester.

静まった夜に、その時が来た。
The time came at a quiet night.

エステルの寝室に血を流したリィが倒れこんできた。
Lee who was shed blood in Esther 's bedroom fell down.

"エステル・・・早く逃げてください"
"Esther ・ ・ ・ Please escape quickly"

驚くエステル。だが体が動かない。食事に毒を盛られていたようだ。
An astonishing ester.
However, the body does not move.
He seems to have been poisoned by the meal.


そこに、毒場のナイフをもったゼーリン議長が入ってきた。
There, Chairman of Zealin with a venomous knife came in.

"エステル。あなたの役目は終わった。"
"ester. Your task is over."

ゼーリンのナイフは、エステルの腹部を貫いた。
Zeelin's knife penetrated the abdomen of the ester.

血がシーツを赤く濡らす
Blood wets the sheet red.

"エステル。おれはお前の国葬で泣いてやる。お前はカルチノ残党の民主主義の手にかかって死んだことにしてやる。それを口実に民主主義やブルジョアどもを皆殺しにするぞ。そして、カルチノは私の統治する理想の国として変わるのだ。"

"ester.
I will cry in your funeral.
You make it that you died in the hands of democracy of the remnant of the Carcino.
With it as an excuse you will kill democracy and bourgeoisters.
And the carncino changes as the country of my ideal rule."

ゼーリンの凶器にも似た笑い声とともに、エステルの意識が遠のいていく。
Along with laughter similar to Zealin's weapon, the consciousness of Esther goes away.

もう何も見えない。何も聞こえない。
I can not see anything anymore.
I can not hear anything.

エステルに後悔の念が押し寄せる。
Regret brings to Esther.


"ああ、私は馬鹿だ。 みんながカルチノに行くのを反対していたのに。私のせいでこんな結果を招いてしまった。"
"Oh, I am a fool.
Everyone was opposed to go to the carcino.
I resulted in such a result."

"みんなごめん、リィ・・・"
"Everyone sorry, Lee ..."


エステルの意識は闇に吸い込まれていた。
The consciousness of Esther was sucked into the dark.



--カルチノ戦記 共産革命編 -完-
- Carcino Senki Commemoration Revolution Edition - Complete -


"エステル、起きてください。いつまで寝ているんですか？"
"Esther, please get up.
How long are you going to sleep? "

エステルは突然の声に目を覚ました。
Esther woke up with a sudden voice.

そこには、リィの姿があった。
There was Lee 's figure there.

他の仲間の姿があった。
There were other fellow figures.


"ここは？ 私はいったい？"
"Where am I?"

"エステル、何を寝ぼけているんですか？ ここはメルカナ港です。 "
"Esther, what are you sleeping, this is Mercana harbor."

"カルチノ連合を倒すために、反政府勢力のカルチノ解放戦線のレオン将軍に会いにいんでしょう？"
"In order to defeat the Kalchino federation, are you going to meet Leon 's general of the rebels' caricino liberation front?"


カルチノ解放戦線？
Carcino Liberation Front?

レオン将軍？
General Leon?

聞いたことがない名前にエステルは困惑した。
Esther was puzzled to a name he had never heard of.


"カルチノ人民革命会議議長のゼーリン議長を支持するのではなくて？"
"Do not we support the Chairman of the Carcino People 's Revolutionary Council Chair Zehlin?"

"なんですか、それは。 ゼーリンは、カルチノ連合のトップ。私たちが倒すべき敵ですよ。"
"What is it?
Zealin is the top of the carcino coalition.
It is the enemy we should beat."

ここでは、カルチノは大陸で唯一の共産主義国家である。
Here, Carcino is the only Communist state on the continent.

ゼーリン議長率いるゼーリン人民党による一党独裁政権が、すべてを統制している。
The one - party dictatorship by the People 's Party of the People' s Party led by Chair Seulin governs everything.

ただし、その政権は腐敗し、国民の暮らしは貧窮する一方である。
However, the administration is corrupt and the people's livelihood is poor.


そこで反政府勢力であるカルチノ解放戦線が立ち上がり、そのリーダーはレオンというひげずらの男である。
So the rebel faction, the Carcino Liberation Front, was launched, and its leader is a lewd man called Leon.

(個人的に、チェ・ゲバラぽいイメージ。ただ、彼が目指しているのは民主化であり、チェ・ゲバラとは違うけど。)
(Personally, Choi ・ Guevara image-like image. However, he is aiming at democratization, different from Che Guevara.)


エステルは、前の記憶がだんだん薄れていく。
As for Esther, the memory of the previous time is getting faded.

何か悪い夢を見ていたようだ。
It seems that she was dreaming of something bad.

エステルは、船に乗って、カルチノ解放戦線のレオン将軍に会いに行くことになる。
Esther will take a boat and go to see the general of Leon of the caricino liberation front.


レオン将軍と対面するエステル。
Eston which confronts General Leon.

レオン将軍は、しっかりとした人物のようだ。
General Leon seems to be a solid figure.

そこへ、黒いフードをかぶった男がやってくる。
A man with a black hood comes over there.

このフードの男は、悪夢に出てきたゼーリン議長にそっくりである。
The man in this hood looks exactly like Chairman of Zealin who came out in a nightmare.

エステルは悪夢を思い出しておびえました。
Esther remembered of a nightmare scared.

エステルは、恐る恐る聞いてみた。
I tried asking Esther terribly.

"あなたとは、依然どこかでお会いしませんでしたか？"
"Have not you met with you somewhere yet?"

男は答えた。
The man answered.

"いえ、初めてお会いするはずです。"
"No, we should meet you for the first time."

彼は、レオン将軍の副官を務めるモルドと人物らしい。
He seems to be a man and Mold who is a deputy general of Leon.

それにしてはあまりにも似ている。
That's too much like that.


そんな中、伝令がやってきた。
Meanwhile, the messenger came.

カルチノ解放戦線の兵士が、政府軍に包囲されているというのだ。
The soldiers of the Carcino Liberation Front are surrounded by government forces.

エステルたちは、救出に向かうことにした。
The escort decided to head for rescue.




なんとか兵士を救出したエステルたち。
Esters who managed to rescue soldiers.

エステルは、昔の悪夢を思い出し、追撃をしないように命令してほしいとレオンに頼んでいた。
Esther was asking Leon to remind me of the old nightmare and instruct him not to pursue.

しかし、カルチノ解放戦線の兵士は、寄せ集めの軍隊で指揮系統が弱く、その命令を無視して、敵を追撃してしまっていた。
However, the soldiers of the Carcino Liberation Front were poorly commanded, with weak commanded lines, ignoring the order and pursuing enemies.




敵を追撃していった部隊は、逆に敵に包囲されていた。
The troops pursuing enemies, on the other hand, were surrounded by enemies.

エステルの悪夢が繰り返されたのだ。
The ester nightmare was repeated.

なんとかして、彼らを助けなければならない。
Somehow, I must help them.

エステルは、悪夢を思い出し、レオンにアジトの防衛を確認しました。
Esther remembered the nightmare and confirmed the defense of the hide to Leon.

レオンはアジトの防衛を副官のモルドにゆだねていた。ある程度の軍隊を配置しているとのこと。
Leon had ordered the hideout's defense to Mold as an adjutant.
He said that he was arranging a certain amount of troops.

これならば、そうそうに陥落することはないだろう。
If so, it will not fall so.

エステルは、味方の救出のみに専念すればよかった。
The ester should have been devoted solely to rescue the ally.




なんとか味方を救出したエステル。
Ester who managed to rescue his ally.

しかし、そこに早馬がやってくる。
However, Horse racing will come over there.

なんと、アジトが陥落したというのだ。
It is said that the hide was fallen.

副官のモルドは命からがら逃げだしてきたという。
Mold of the aideman said that she ran away for life.


カルチノ解放戦線は戻るべき家を失ってしまった。
The Carcino Liberation Front has lost the house to go back to.

この絶体絶命の危機の中で、リィとアドラーは、敵の補給基地を発見する。
In the crisis of this desperate situation, Lee and Adler find enemy supply base.

この基地を奪えば、補給と基地の両方を得ることができるだろう。
If you take this base, you can get both supply and base.




基地を陥落させ、物資を手に入れたエステルたち。
Esters who dropped the base and got supplies.

エステルたちは、レオンとともに軍を建て直し、勢いを取り戻した。
The escortes rebuilt their troops with Leon and regained their momentum.


カルチノ解放戦線は、ついにカルチノの首都まで進撃することに成功した。
The Carcino Liberation Front finally succeeded in advancing to the capital of Carcino.

カルチノの首都はグレートウォールと呼ばれる城壁で守られている。
The capital city of Carcino is protected by a wall called the Great Wall.

エステルたちはこの城壁を超えて、進行しないといけない。
The esters have to proceed beyond this wall.

民家を訪れると、自由主義者が来たといって、親子は逃げ出してしまう。
When visiting a private house, parents and children will run away saying that liberals came.

この国では、自由主義者はテロリストなのだ。
In this country, liberals are terrorists.

そのテロリストたちは、ついに建物を制圧し、城門を開け、首都へなだれ込む。
The terrorists eventually control the building, open the castle gate, and poured into the capital.


兵士「門が開いたぞっ! 市街へ流れこめっ。
Soldier: "The gate has opened! It flows into the city."
Mold: "We loot from dogs of Allied Leaders who oppress us"

エステル:"ちょっと待って！ 市民から略奪しちゃダメよ。"
Esther: "Wait a moment! Do not take away from citizens."

レオン:"何をやっておるか！
一般人からの略奪は許さん。
軍規を正すのだ。
略奪したものは軍規に則り反逆者として処刑するぞ！
Leon: "What are you doing!
Pillage from the public is not allowed.
Right up the military rules.
Those who plunder will be executed as rebels according to military rules!

レオンは兵士たちを一括した。
Leon bundled soldiers.

レオンは立派な人物のようだ。彼ならばカルチノを正しい方向に導いてくれるだろう。
Leon seems to be a fine person.
He will lead the carcino in the right direction.


レオンたちカルチノ解放戦線は、カルチノ首都を制圧した。
Leon and the Carcino Liberation Front suppressed the Calcino capital.

しかし、カルチノのゼーリン議長をはじめとする、党幹部は姿を消していた。
However, party executives including Carmine's Chairman Seelin have disappeared.

彼らが逃げるとしたら、キリスか、ルネスか。
If they ran away, Kirisu or Renes?

彼らは首都を抑えたが、カルチノには、大陸最大の港キリスがあり、ここにはまだカルチノ人民党を支持する軍隊が駐屯している。
Although they held down the capital, Carcino had the continent's largest port Kiris, where an army supporting the Carcino People's Party is still stationed.

また、首都の守りも必要だ。
Also, we need to protect the capital.

レオンは、エステルに首都の守りを任せて、自分の軍隊でキリスを平定すると言った。
Leon said he would leave the estell to protect the capital and to flatt out Kiris with his army.

これに副官のモルドは反対する。
Mold of the aide is opposed to this.

"こんなよそ者のkaitouに首都を任せるのですか？"
"Do you leave the capital to this stranger kaitou?"


"何を言うか。エステル殿がいたからこそ、我々はここまでこれたのではないか。"
"What to say? Due to Esther's dwellings, we have not been here so far."
"二度とそのようなことを言うな!"
"Never say such a thing again!"



レオンと副官のモルドは、キリスを平定をするために、首都を離れた。
Molde of Leon and his adjutant left the capital to flattrate Kiris.

カルチノ市街の守備を任されたエステルは守備だけではなく治安の回復にも尽力した。
Esther who was appointed defense of the city of Calcino was devoted not only to defense but also to recovery of security.

カルチノ市街の市民たちは、最初はこの侵略者に対して怯えていたが、エステルたちが略奪や暴行をしなかったことが伝わると、次第にそれも収まった。
Citizens of the city of Calcino were initially frightened of the invaders, but gradually they fell as the escorts reported that they did not loot or assault.

エステルたちは、カルチノ連合のゼーリンが作った悪法を次々に無効にした。
The estell invalidated the evil laws made by Zealin of the Carcino Association one after another.

エステルは、平等に分配されるべき物資を、着服したり横流ししていた不正役人を、次々に摘発した。
Esther caught successively the corrupt officials who were dressed or crossed flowing supplies to be distributed equally.
怪盗からものを隠すことなどできるはずがないのだ。
It can not be hidden from things like a kaitou.

怪盗は盗むことには情念をかけるが盗んだ後にそれを独占しない。
Kaitou takes passion on stealing but does not monopolize it after stealing.

成果は仲間たちと分け合うものだ。
The outcome is to share with our colleagues.

彼女は、摘発した膨大な不正備蓄を、すべて市民たちに開放した。
She opened up all the enormous invalid stockpiles she caught to citizens.

そして、
And,

自由な商取引の復活、公平な裁判制度の復活、住民の自治の復活、表現や集会の自由の保証などの改革を発表した。
Reviving free commercial transactions, reviving the fair trial system, restoring the residents' autonomy, guaranteeing freedom of expression and assembly.

怪盗はフェアで、自由を好むのだ。
Kaitou is a fair and likes freedom.

これらは、いずれもゼーリンたちがやっていたことと真逆の開放的な政策であった。
These were both open-minded policies that were opposite to what they were doing.

抑圧されてきた市民たちは、開放的な政策に熱気しエステルたちの統治を歓迎し始めた。
The citizens who have been oppressed have begun to welcome the reign of the esters with enthusiasm for open policies.

だが・・・・
But ....



ルネスがついに動き出したのだ、
Lenneness finally started moving,\r\n

どうやら、ゼーリン議長はルネスに泣きついたたらしい。
Apparently, Chairman Seelin would have cried Renes.

ルネスは、大陸のリーダーとして反乱を鎮圧するべく軍隊を派遣してきたのだ。
Renes has dispatched troops to suppress the rebellion as the leader of the continent.

"レオン将軍から預かった街です。なんとしても守り抜きましょう"
"It is the city that I got from general Leon. Let's protect it at any cost "





なんとかカルチノ首都を守り切ったエステル。
負傷者の治療と、破壊された都市の復旧を進めるエステルたち。

しかし、そんな中、早馬がエステルのもとに届いた。

キリスに向かったレオン将軍が敵の猛攻を受けて危機に陥っているというのだ。





レオン将軍は敵のスナイパー部隊に包囲されていた。
レオンは死を覚悟し、味方に投降を命じた。
しかし、兵士たちは最後までレオンのために戦うという。

指揮は高いが、状況は圧倒的に不利だ。
エステルの救援は間に合うのだろうか？




エステルはレオン将軍を発見した。
しかし、将軍は敵の攻撃を受け、ひん死の重傷である。

エステル:"レオン将軍しっかりしてください"

レオン:"その声はエステル殿か・・・
エステル殿　申し訳ない。
私はこれまでのようだ。
全軍の指揮を貴方に任せる・・・
どうかカルチノに自由を・・・"

それがレオンの最後の言葉だった。
カルチノ解放戦線としてカルチノに自由をもたらそうとしたレオン将軍は亡くなった。



エステルはレオン将軍の後を継ぐ決心をした。
まずは、一番近いキリス港を平定する。
そのあとで、ルネスの援軍をカルチノから追い出さなければならない。

キリス港には、カルチノ人民党の強力な軍隊がいる。
そして、カルチノの貿易の拠点でもある。
なんとしても、ここを奪還する必要がある。
レオンが果たせなかった平和で豊かなカルチノを取り戻すために、エステルは戦う。











◆裏面1周目の外伝1章 同士ゼーリン	目的:ボス撃破

It is a story in the case of cooperating with the carcino revolution.
A massive rebellion occurred in the carcino, but the rebel army is losing by the government army.

Esther cooperates with rebels that Moriarty has supplied weapons.

This is a story of an ally of justice that saves carinos with Revolutionary Zealin.
Let's save the carncino from sneaky capitalists.
They are aiming for a communist revolution in order that everyone aims a fair society.

Come with each other.
Take weapons.
Kill capitalists!

・ ・ ・ It is different from the side of justice I thought?
There are many kinds of justice.


◆裏面1周目の外伝2章 深入り	目的:ボス撃破

With the cooperation of Esther, the revolutionary army crisis escaped.
However, the revolutionary army who was on tone started pursuing enemies.

Unplanned deep progression is reckless.
The esters tried to stop it but did not hear Chairman Zeelin without military talent.

There arrived a report that the revolutionary troops pursued were in danger of being destroyed by the enemy's trap.


◆裏面1周目の外伝3章 補給基地	目的:制圧

包囲された革命軍の危機を救ったエステルたち。
Esters who saved the envied revolutionary crisis.

そこへ新しい報告が届きます。
A new report will arrive there.

革命軍のアジトが敵の総攻撃を受けて陥落してしまいました。
The hideout of the Revolutionary Army has fallen in response to the enemy's total attack.

エステルたちを誘い出したのは敵の罠だったのでした。
It was the enemy's trap that invited the esters.

本拠地を失い、帰る家を失った革命軍。
A revolutionary army who lost his home and lost home to return home.

ゼーリン議長は、こうなった責任はすべてエステルにあると、責任転嫁をします。
Chairman Sheein will pass the responsibility that all these responsibilities are in the ester.






◆裏面1周目の外伝4章 グレートウォール	目的:制圧

ここも3回にわたって登場するステージです。
1周目では、特に何の変哲もないマップです。

壁を壊すも良し、壁をドラゴンなどで乗り越えるも良し、
好きな方法でクリアしましょう。


◆裏面1周目の外伝5章 キリス解放	目的:制圧

FE暗黒竜パロディのセリフがいろいろでてくるステージです。
難易度はそれほどでもないと思いますが、
増援がうざいのでとっととクリアしてしまいましょう。

◆裏面1周目の外伝6章 救出作戦	目的:ゼーリンとの会話

ゼーリン同士を助けるマップです。
ゼーリン同士はそこそこ強いのでほっておいてもなかなか死にませんが、ドーピングアイテムをもっている敵を倒されるとまずいので、突撃するしか無いと思います。

もうちょい難易度を上げればよかったと思っています。
魔道士達は、トラキアのベルクローゼンぽくしたかったんですが、なんかイマイチなんだよなあ・・・。

マップは聖魔の蛍石の誓いからの流用です。

友軍(革命軍)を1体以上生存させてクリアすると、リザーブをもらえます。


◆裏面1周目の外伝7章 カルチノの乙女	目的:制圧

タイトルの由来は、ジャンヌ・ダルクのオルレアンの乙女ですね・・・　まぁ、そのまんまんなんですけど・・・
窮地を救ったことでゼーリンから全権を奪い、カルチノを解放するステージです。

増援がうざいマップですので、とっとと制圧してしまうのがいいと思います。

街訪問すると、魔剣スリープの剣がもらえます。


◆裏面1周目の外伝8章 草原の戦い	目的:ボス撃破

難所です。
森に隠れて、地の利をいかして攻めるといいと思います。
(と、いうか、これを読んでいるということはクリアしているわけでどうやってクリアしましたか？)

レイス将軍を倒すと、敵は全軍撤退となり、勝利します。
ロマサガ3のマスコンバットのパロディのつもりです。


◆裏面1周目の外伝9章 国境の戦い	目的:ボス撃破

最終ステージです。
It is the final stage.

最終ステージなのに、敵がstat boosterを持っているとか、まだまだ続くことを表していますね。
Even though it is the final stage, it means that the enemy has a stat booster, or that it will last more.


このステージはアイテムを盗むとつらいです。
逆に、盗みをせずに速攻撃破すると結構楽ですが、
これ以降のステージで辛くなってきます。
どちらをとるかですね。


◆裏面2周目の外伝1章 レオン将軍	目的:ボス撃破

レオン将軍はチェ・ゲバラみたいな髭面で、
解放戦線なんていかにもな名前ですが、
彼らは、共産化したカルチノ連合を倒し、自由主義を確立するために戦う人たちです。
ただ、レオン将軍は言っていることは立派ですが、本人が弱すぎてすぐ死ぬので、がっちり守る必要があります。

解放戦線を1体以上生存させてクリアするとスリープがもらえます。
BGMはインドネシア民謡？のパルチザンの歌です。
(本当は、フランスのパルチザンの歌を流したかったんですが、midiをみつけられませんでした・・・)


◆裏面2周目の外伝2章 繰り返す悪夢	目的:ボス撃破

前と同じように、敵が勝手に深入りするマップです。
マップは封印のマップを流用しています。

カルチノは、カルチノ人民党(国民党)が一党独裁で支配している国になっていて、将軍とかの重役はみんな党員ということになっています。
だから、マップ冒頭で、武勲を立てて党に入って栄達する機会をえろよというのです。

解放戦線を1体以上生存させてクリアするとブーツがもらえます。


◆裏面2周目の外伝3章 補給基地	目的:制圧

2周目は雨が降っています。
このマップを制圧すると、別大陸の武器がゲットでき、結構楽になると思います。

◆裏面2周目の外伝4章 グレートウォール	目的:制圧

武器屋が速攻で潰されます。
純粋な共産圏ですので仕方ないですね。彼らは一切の通貨を認めていないのです。だから、裏面2周目では、店は辺境にしかありません。
秘密警察を恐れて商売しているわけですね。

◆裏面2周目の外伝5章 カルチノ防衛戦	目的:20ターン防衛

防衛マップです。
ウルスラはバーサクを使い終えると、勝手に突っ込んでくるので、眠らせるなどして捕らえましょう。


◆裏面2周目の外伝6章 救出作戦	目的:レオンと会話

窮地に陥ったレオン将軍を助けるマップです。
上から陸路で行くと間に合わないので、空を飛んで行く事になります。

友軍(解放戦線)を1体以上生存させてクリアすると、スリープの剣をもらえます。

このマップは遺跡の5Fの上に作っているので、毒の霧がたまに出てきます。


◆裏面2周目の外伝7章 キリスの戦い	目的:制圧

魔封じ結界が出てくる初見殺しマップです。


◆裏面2周目の外伝8章 草原の包囲戦	目的:20ターン生存

なぜ敵より少ない人数で包囲戦をするのか・・・　というマップです。

解放戦線を助けても何もいいことはないので、なんとかして20ターン生存しましょう。
モルドがいた高台に逃げこむとソーサラーしかやってこなくなるというバグがあります。

◆裏面2周目の外伝9章 国境の戦い	目的:ボス撃破

1周目の外伝9章と同じですが、
チート武器があるので、難易度は下がっていると思います。

◆裏面3周目の外伝1章 カルチノ自由同盟	目的:20ターン生存

世界一有名な革命歌、フランス国歌のラ・マルセイエーズをBGMに、20ターン防衛するマップです。

同盟軍を生存させたままクリアすると、ゼーンフトの槍がもらえるので、なんとかして守ってください。
マップは、烈火のマップからの流用です。

◆裏面3周目の外伝2章 敗走	目的:拠点到着

スラム街を逃げるマップです。
左上の民家に入ると、通報されて秘密警察が出てきますが、レイクボルトをもっているので、奪いましょう。

◆裏面3周目の外伝3章 補給基地	目的:制圧

ボスが2体いるマップです。

増援でドラゴンナイトが以外な場所からやって来るので、何も考えていないとヒースを殺されてしまう初見殺しのマップです。

◆裏面3周目の外伝4章 グレートウォール	目的:制圧

壁が修理されてしまい、壁を飛んで超えるか登るしかなくなるマップです。
ボスはGBA FEの悪役司祭3人組です。

◆裏面3周目の外伝5章 カルチノ防衛戦	目的:20ターン防衛

魔導砲が街を壊しまくるマップです。
魔導砲を食らうとHPが1になってしまいます。
(本来は即死だったが、うまく作れなかったので瀕死にした。)

2周目と同じ作戦で挑むとひどい目にあうマップです。

◆裏面3周目の外伝6章 高原の戦い 目的:制圧

南の村の市民を守りつつ、敵陣を制圧するタワーディフェンス的にマップです。

◆裏面3周目の外伝7章 刺客 目的:敵全滅

裏面きっての運ゲーです。
盗まないでザクザク切りかかれば余裕なんですが・・・
それでも盗みたくなるのが心情というものです。


◆裏面3周目の外伝8章 国境の戦い 目的:パブロと会話

イベントステージです。
特に難しいところは何もありません。
エステルがパブロと会話するだけです。

ただ、敵軍は貴重なアイテムを持っているので、怪盗としては間に割って入って盗みたいところですね。

パブロ軍が死んだら、自爆させて周りにダメージを与えるとかやりたかったなあ・・・


◆裏面3周目の外伝9章 兄弟 目的:ヒースと会話

上に長い潜入ステージです。

英雄戦争のソウルフルブリッジのハーディン様のように、数ターン経過すると、マフーで無敵のパブロが突っ込んでくるので、それまでにクリアしましょう。

◆裏面3周目の外伝10章 スターライト 目的:制圧
横に長いステージです。
本来は、空を飛んで行くしかないようにしたかったのですが、ゲームとしてつまらなかったので、陸路も作りました。
後ろから迫り来る増援から、逃げながら前に進みましょう。

ヒースが残してくれた、どんな防御も貫通する魔法スターライトを手に入れましょう。
Let's learn the magic starlight that Heath left, passing through any defense.


◆裏面3周目の外伝11章 空中回廊 目的:ボス撃破
It is the last map.
It is the last fight with Pablo.
Let's settle this crazy FE remodeling.

The aerial corridor connecting the four towers in the carnino is the stage of the battle.



Pablo will come over here, so let's just defend.
At this stage, the weather changes according to the magic of Pablo.

It is only starlight that can damage Pablo who has muffoo.
Please note that star light has no debuff effect.

If the light mage is up, I think that You can turn 1 Pablo using cheering etc.


*Rewind one turn
Reset returns to the start of the player turn.
You can also choose to resume from the point in the middle of the player turn by selecting "Interrupt".


*Casual mode
In FE, a unit that dies is permanently lost.
This specification is changed.
When set to Casual Mode, even if a unit dies, it will be automatically resurrected in the next chapter.



◆List of fellow characters (Spoiler Alert!)

Estelle, Kaitou (CC Grate Kaitou)
	Female thief(kaitou). She is the main character of this work.
	She is a companionable person, but has an eye for treasures.
	She has her own sense of ethics and worldview.
	The character is taken from Karina of The Last Promise without permission.
	The origin of the name is just a guess. It has nothing to do with the Tearing Saga.
	
	Appears from the beginning of the game. The game is over when she is defeated.

Lee, Dragon Knight (Promotion: Dragon Master)
	A dragon knight who is Estelle's best friend. A master of scouting and surprise tactics.
	I like having a D-Knight from the beginning of the game, as it appears to give me more variety in my strategy.
	He can steal->remove->dance->steal->remove->dance->steal->play->steal->remove->remove->transport squad to strip enemies naked in one turn.
	You can do anything you want, such as abducting a dying enemy because of your size advantage.
	The character is taken from Arthur of The Last Promise without permission.
	The name is derived from General Lee, who was a hero in the Civil War even though he was on the losing side.

	He appears in the game from the beginning. The game is over when he is defeated.

Poron, Cleric (Promotion: Bishop or Valkyria)
	Sister of Esther's best friend. She is a wielder of light magic and a wand.
	A childish character.
	The character is taken from Sophiya of "Sword of the Seal" without permission.
	The origin of her name is just a guess. It has nothing to do with Tokimeki Popolon.

	She joins the group from chapter 1.

Armin Bard (Promotion: Idol)
	Traveling poet.
	Joins Esther Kaito to write the best poems.
	The character is taken without permission from Wolt of the Sealed Sword.
	The name is taken from a dictionary of names.

	She joins the group from chapter 1.

Cathy Archer (Promotion: Sniper or Forest Knight)
	A bowman. The range of the bow is extended to 2 to 3 squares.
	Personally, I'm not good with bow characters, so I'm strengthening it a lot.
	The character was appropriated without permission from Rebecca of Sword of Fire.
	The name was taken from a dictionary of people's names.

	She joins the group from chapter 2.

Morda, Shaman (Promotion: Druid or Sorcerer)
	A former priestess, but a heretic who became addicted to dark magic.
	She escapes from the Inquisition and meets Esther and her friends.
	He is the oldest and most dignified person in Esther's hideout.
	He is always experimenting with mysterious dark magic in the basement.

	She joins the group in Chapter 4.

Shelley, Dancer (Promotion: Idol)
	A traveling dancer. For some reason, she has joined the band of thieves.
	Like Mr. Paan of Thrace, a dancer may be indispensable for thieves and bandits.
	The character is taken from "Lalam of the Sword of the Seal" without permission.
	The name is taken from a dictionary of names.

	She is a member from chapter 4.

Arabella, mercenary (Promotion: Sword Master or Master Knight)
	She is a mercenary. She is poor and does various things such as mercenary and bandit to feed her brother.
	He loves cute things and money.
	The character is taken from Kaara of "Sword of Fire" without permission.
	He chose his name randomly from a dictionary of names.
	She joins the group in chapter 4. (Talking with Esther)

Rito, Warrior (Promotion: Berserker or Warrior)
	Arabella's younger brother. He is a quiet axe-user who has a good speed.
	I tried to make him like the twins in Black Lagoon, but he is different.
	The character is an unauthorized adaptation from the beautiful King of the Rotting King from Sword of Fire.
	His name is not Lucky Sketch.
	He becomes a member from chapter 4. (Talking in Arabella)

Rute Mage (Promotion: Sage or Marge Knight)
	Mr. Superior.
	In this patch, he is also an inventor who develops technology for the application of magic.
	He joins the bandits to raise funds for his research.

	He joins the group from Chapter 6. She joins the group when she visits a village in the northeast.

Lucy Troubadour (Promotion: Priest or Witch)
	A delinquent sister girl.
	Her name is taken from a dictionary of names.
	The character is taken from Sailor of "Sword of Fire" without permission.

	She joins the group from Chapter 7. She appears after the reinforcements have been exhausted. She becomes a friend when you talk to her as "Shelly".
	(Actually, I wanted to change Shelly to Fina and Lucy to Marysia. But I couldn't draw a picture, so I gave up.)


Lina Pegasus Knight (Promotion: Falcon Knight)
	P Knight. Entered the game in the middle of the beginning.
	In the first chapter, she is treated quite badly, but it can't be helped because she is cute.
	She is good at housework in general and is the caretaker of Esther's band of thieves.
	The character is taken from Alice of "The Last Promise" without permission.

	She joins the group in Chapter 9.

Maiko, Mage (Promotion: Idol)
	She wants to be a wizard who can sing and dance. But he is weak.
	The character is taken from "Hyu" of "The Sword of the Seal" without permission.

	He joined the group in Chapter 9. When you visit a village, you will see him as a friend, so you can talk to him as Shelly or Armin.
	The growth rate is one of the worst, but she can become an idol with CC, so she may play an active role in the bonus map.

Adler, Valkyria
	The woman who saves Estelle's life. Genius.
	The character is taken from Leila of "Sword of Fire" without permission.
	Her name comes from "Adler" of Sherlock Holmes.

	She joins the group once in Chapter 11, but leaves at the end of the chapter.
	She officially joins the group in chapter 23. She becomes a friend when you talk to her in Lee.
	The game is over when she is defeated.

Marika, Swordsman (Promotion Sword master or Sword Dragon)
	A girl who is a freed slave. She is talented with a sword.
	She was kidnapped at the place where she was sent as a mercenary.

	She has been a member since Chapter 13.

Amelia, Soldier (Promotion: General or Falcon Knight)
	A girl who is a freed slave. Talented with lance.
	She set out to become a soldier of Grado, but she seems to have lost her way and was kidnapped.

	She joins the group from Chapter 13.

Navy, Archer (Promotion: Sniper or Forest Knight)
	A girl who is a freed slave. She is talented with a bow.

	She will join the group in Chapter 13.

Ewan, Mage (Promotion: Sage or Marge Knight)
	A boy who is a freed slave. He has a talent for magic.
	His sister is dead.

	He joins the group from Chapter 13.

Myrrh, Shaman (Promotion: Sorcerer or Bishop)
	A girl who is a freed slave. She has a talent for magic.
	There is no Mamukut.

	Becomes a companion from Chapter 13.

Carlo Soldier (Promotion: Scout or Monk)
	Soldier guy. He is a Soldier with the unhappy attribute. Sadly weak. An unlucky man.
	The character is taken without permission from Auger of the Sword of the Seal. Because he seems to be a shadowy character.
	Go and see the origin of his name, Carlo.

	He becomes a member from chapter 13.
	
	His growth rate is the worst class, but he can become a special class by CC, so he might become the strongest if he doped up a lot. I think he is an active character on the back side.


Galahad, Sword Master
	He is a promoted sword master. He has a magic sword, Ice Sword.
	The character was taken without permission from the Rogue of the Holy Demon.
	The name comes from the unfortunate swordsman who has an ice sword.
	By the way, his hair is full of hair.

	He becomes a friend when you talk to him in Carlo in Chapter 17.

Daros, Sailor
	A promoted axeman. He is a sailor who yearns to be a thief.
	The character is more than Daros of GFE1R.

	He becomes a companion from Chapter 19.


Buzzba, Berserker
	A former bandit leader.
	He was defeated in battle twice, reformed, and saved Esther and her friends in their time of need.
	He looks like Meng Hui of the Nanban in the Romance of the Three Kingdoms.

	He has been a member since Chapter 23. (You can talk to him in Ri.)

Oleg, Hero
	A psycho who slaughtered dozens of people to avenge his wife's death.
	Unfortunately, he may not be very strong.
	The character is taken from "Oleg" of "Sword of Fire" without permission. (This is Oleg, right?)
	A brave man who can use a lance.

	He joins the group from Chapter 23.

Moriarty, Bishop.
	A priest of the thief. Former math professor. Called "professor" by everyone.
	A military strategist of evil. He is thrilled by Esther, who makes his boring daily life interesting for him.
	He is a dangerous man who would even abandon a country for himself.
	The character is taken from "Renate" of "Sword of Fire" without permission.
	His name is taken from Professor Moriarty of Sherlock Holmes.

	He becomes a member from Chapter 23. The game is over when he is defeated.

Mostyn, General.
	The man who unified the island of the beginning.
	The character is taken from Hector of Sword of the Seal without permission.
	The name comes from King Talis, the first dark dragon.
	He appears as an enemy to be defeated in Chapter 20, but becomes a friend from Chapter 24.
	(You have to defeat him in chapter 20 to clear the game.)

Sheida, Falcon Knight.
	A princess, daughter of Mostyn.
	The character was appropriated without permission from Lilina of the Sword of the Seal.
	The name comes from Sheeda, the first dark dragon.
	She appears as an enemy to be defeated in Chapter 20, but becomes a companion from Chapter 24.
	(The result does not change whether you defeat her in Chapter 20 or not.)

Mars, Master Knight.
	A guest of Mostyn. Essentially the most protagonist-like character...
	The character was appropriated without permission from Roy of the Sword of the Seal.
	The name comes from Mars, the first dark dragon.
	He appears in Chapter 20 as an enemy to be defeated, but becomes a friend from Chapter 24.
	(You have to defeat him in Chapter 20 to clear the game.)

Total of 28 people. 14 men, 14 women.
On the extra map (back side), no characters become friends.

◆マップ一覧
序章 怪盗参上			ボス撃破
1章 遅すぎた帰還		制圧 (編成不可)
2章 アジトでの攻防		20ターン生存 (編成不可)
3章 フレリアへ			制圧 (編成不可)
4章 怪盗の美学			敵全滅(編成解禁)
5章 山賊キラー			制圧
6章 宝置いてけ			敵全滅
7章 交易都市			制圧
8章 地下金庫			拠点到着
9章 大脱走				拠点到着
10章 探偵参上			制圧 (夜/雨)
11章 悪党のキャリア		ボス撃破(雨)
12章 自由市場			奴隷たちを20ターン防衛
13章 パブロ亭にて		制圧 (2つのスイッチを踏む必要がある)
14章 プランＢ			拠点到着 (夜)
15章 スラム街			敵全滅(雨)
16章 書類をどうぞ		制圧
17章 古戦場				20ターン防衛
18章 騒乱の港町			ボス撃破
19章 海賊船				ボス撃破(雨/霧)
20章 始まりの島			ボス撃破
21章 赤パッチ組合		拠点到着
22章 深夜の大包囲網		35ターン以内に拠点到着(夜)
23章 牢獄				拠点到着
24章 砂漠をこえて		拠点到着
25章 ルネスの国宝		王座を守りながら、女性で戦士系キャラだけでボス撃破
26章 川下り				20ターン生存
27章 国賊となった女		20ターン生存またはボス撃破
28章 もっと国賊らしく	15ターン以内にボス撃破
29章 逃走と闘争			奪った馬車を南東の砦までつれていく
30章 闇の中で			20ターン生存またはボス撃破(夜)
31章 ロストンアカデミー	拠点到着
32章 魔導研究所			拠点到着
終章 テイクオフ			ボス撃破(エネルギーチャージ)

+裏面


◆盗品リスト
121 ルネスの宝石		序章スタート時から(必ず入手する)
122 山賊の宝			6章でボンから盗む
123 光のダイヤ			8章中にイベントで入手(必ず入手する)
124 奴隷商の財産		12章でバンブーから盗む
125 英雄の絵画			13章クリア後にイベントで入手(必ず入手する)
126 青いガーネット		20章クリア後にイベントで入手(必ず入手する)
127 グラド金貨			21章スタート時にイベントで入手(必ず入手する)
128 ルネス国債			21章スタート時にイベントで入手(必ず入手する)
129 グラド国債			21章スタート時にイベントで入手(必ず入手する)
130 闇のサファイア		23章でハート様から盗む
131 銀十字勲章			23章でオニールから盗む
132 ジークリンデ		25章中にイベントで入手(必ず入手する)
133 金のカギ			26章中に1ターンだけ右下に現れる村訪問
134 ルネスの税金		28章でイベント入手他(必ず入手する/唯一複数手に入る盗品)
135 銀星勲章			29章でブレゲから盗む
136 バリツの黒帯		30章でホームズ(左上)から盗む
137 設計図				31章中にイベントで入手(必ず入手する)

盗品の売値はどれも同じく 65535ゴールドです。
黒の宝玉とかと違い、アイテムに盗品番号を振っておいたので、
アイテムコレクターは、盗品を売れずに縛りプレイをすることになりますね。大変ですね。

裏面での盗品はありません。


◆上位クラスのスキル一覧
大怪盗
	スキル:再移動 + 高い山や壁を超えられる

賢者
	スキル:全魔法
	(理 光 闇 杖の全部の魔法が使える。ただしSにできるのは一つだけ。)

司祭
	スキル:全魔法
	(賢者と一緒)

マージナイト
	理と杖
	スキル:再移動

ヴァルキュリア
	光と杖
	スキル:再移動
	(マージナイトと一緒)

ドルイド
	闇と杖
	スキル:必殺
	(魔法のソドマス的存在)

ソーサラー
	闇と杖
	スキル:空移動(弓弱点がないのにペガサス見たく空が飛べる)
	(girlsのウィッチのパクリ)
	(本当は奇術師ってしたかったんだけどOPのクラス紹介のフォント容量が・・・)

ウィッチ
	光と杖
	スキル:空移動(弓弱点がないのにペガサス見たく空が飛べる)


ソードマスター
	スキル:必殺補正

スナイパー
	スキル:必中

フォレストナイト
	剣+弓
	スキル:再移動

バーサーカー
	スキル:必殺

ウォーリア
	斧+弓
	スキル:なし

パラディン
	槍+剣
	スキル:再移動

ジェネラル
	スキル:大盾

ファルコンナイト
	槍+剣
	スキル:再移動

ドラゴンマスター
	槍+剣
	スキル:再移動

ソードドラゴン
	剣
	スキル:再移動 + 必殺
	(剣専門のドラゴンマスター 空飛ぶソドマス的な)

マスターナイト
	剣・槍・斧・弓
	(すべての武器が扱える騎乗ユニット)

アイドル
	スキル:再移動
	バードと踊り子の上位クラス。

僧侶
	スキル: 悟り いきなり杖Sが使え、一部パラメータがカンストする。
	(戦士に向いていないと悟ったものが武器を捨て出家する)

斥候
	スキル: 再移動 + 視野拡大 一部パラメータがカンストする。

霧で視界確保できるのは、
怪盗のエステル、モリアーティ、そしてクラス:斥候にCCしたカルロです。


◆勝手にThanks(敬称略)
◆Thank you
MarkyJoeのマップ書き換え方法の動画
Fire Emblem Hacking: Map Insertion Tutorial [Redone]
https://www.youtube.com/watch?v=cKQtfAuzml8

これがあったから改造FEをやろうと思えました。
日本語だとこーゆー初心者向けのわかりやすいチュートリアルがないから困る。
初心者には最初から最後までがわかりやすく伝わる絵本になっていることが大切だよね。そういう意味で、動画を上げてくれてほんとうに助かったよ。
ありがとう。あなたのおかげで作ることができたよ。


Chap@FE8_GIRLS の解析資料
フリーマップ禁止を適応しました
オープニングのクラス紹介を参考にしました
戦闘スキル発動クラス変更を参考にしました
CC時に武器表示無しを適応しました
塔及び遺跡でセーブ可能を適応しました

NGMansionの資料
エイリーク編序盤の特殊経験値係数削除を適応しました
[FE8]オープニングカットのおまけを適応しました
エイルカリバーの音を出すを適応しました
最大レベルを参考に31まで引き上げ
進撃準備に章名を適応しました
幸運上限の引き上げを適応しました
ユアン理消滅処理を参考にしました
瞬殺不可クラスを参考にしました
幸運上限を適応しました
きずぐすりの回復量を参考にしました
0xB4～0xEB 辞書用を参考に、これらのフラグを立てないようにした
はやい ＞ もっとはやい（A押しっぱと同速）を適応しました
・アイテムの交換 無制限を適応

NGMansionのサイト と aera
敵捕縛術を使いました。
状態異常剣を使いました。
midi移植の解説を大いに参考にしました。
顔画像移植の解説を大いに参考にしました。
ワールドマップのイベント解析を参考にしました
マップ設定の解析でフラグ0x04の意味を知ることができました。
逆汗講座を参考にしました。
敵解放でフラグと経験値を適応しました。


名軍師のサイト
イベント解説がとても参考になりました。
OP画像改変がとてもわかりやすかったです。


FEMapCreatorの作者
マップ改造に使っているよ。
自動生成とリペアのおかげで山を並べられてます。
手でやるとか頭がおかしくなって死にそうなのでとても助かっています。


Projects_FE_GBAの作者
便利なツールをありがとう。
ただもうちょい直してほしいところもあるけど、
このツールのおかげで改造をやる気になれたし、
バイナリエディタとにらめっこは辛いのでとても助かっています。


FEditor_Adv J 0.3 と FEditor_Advの作者
顔画像変換が楽にできて助かってます。
ソースを付属してくれたおかげでいろいろ直せました。

sappy
その多機能さに、こんなこともできるかと毎回驚いています。
VB6でさえなければ・・・

GBA Song Editor
曲移植が楽に出来て助かっています。
LL言語のため、追加機能を楽に開発できました。


その他、以下のツールにお世話になっています。
VisualBoyAdvance / NLZ-GBA Advance / MAR array inserter / mar_conv_Changes2 / 世界樹 / edge / FEFont / GBA Graphics Editor / goldroad / no$gba debugger / Stirling / sakura editor / WinMargeU / tsukuyomi


FE HARDの作者
FEが改造できることを証明してくれて感激しました。
最初の方のバージョンから毎回あそんで、10週ぐらいしたよ。

FE 烈火IFの作者
素晴らしい改造をありがとう。
エリとヘクトルでそれぞれ3周ぐらいしたよ。
ハードはむずすぎて途中で投げちゃったけど・・・・
BGMを勝手にいろいろ使わせてもらっいました。
また、ゲームバランス調整の参考にしました。
剣姫のマップアニメを利用させてもいました。

FE8 Girlsの作者
改造資料も参考にしたけど、
ゲームも面白かった。3周ぐらいクリアしたよ。
全員に封印の剣手を入れるまでひたすら遺跡に潜ったりしたよ。そして密偵と毒のコンボに泣いた。
ウィッチとかいろいろ参考にしたよ。
本当のgirlsでやっているようにステータス上限50とかやりたかったけど、
方法がわからず、力及ばずで諦めた。
こんなすごい改造ができるなんて羨ましい・・・

瞬殺をHP:1で瀕死にするルーチンは参考にさせていただいた。
というか、コピペさせてもらいました。
0x0002b436 付近と、 飛ばし先の 0x00E4F7A0 付近を。

ウィッチの画像もコピペさせてもらいました。
女性アサシンを使いました。
司祭セーラを使いました
オートセーブFix

The Last Promiseの作者
FEを完全書き換えしてオリジナルが作れることを照明してくれた偉大な作品。
裏面も含めて3周ぐらい完クリしたよ。
裏面のアイディアやキャラクターを参考にしたよ。
キャラがかっこよすぎたから、勝手に使わせてもらったよ。ありがとうね。


FE 聖魔　緑の作者
聖魔でも追加のマップ移動ができることを証明してくれた。
もちろん、完クリしたよ。
おかげでいろいろ追加マップを作ってみたよ。

FE 天地の剣の作者
日本人でもThe Last Promiseみたいに完全改変ができることを証明してくれた偉大な作品。
2周ぐらいクリアやったよ。
このパッチのおかげで今回改造してみる気が起きたよ。

ダールの絵とかを勝手に使わせてもらいました。
トラキアの将軍の絵も使わせてもらいました。


Dream of Five V4の作者
序盤での育成ステージを増やす参考にしたよ。
ターン制限という恐怖を与えることの参考にしたよ。
弓の射程を2から3にする参考もしたよ。
ゲームは未完っぽいのでシナリオ分岐したあとで#19でバグって落ちるところまでクリアしたよ。(両方の分岐をそれぞれプレーして同じく落ちるところまで進んだよ。)

Fire Emblem Midnight Sunの作者
FEで潜入ステージを作れることを証明してくれた。
ただ、作れはするけどSRPGとして面白いかは別ってことだよね・・・
この潜入ステージとAoE2のステージとかを参考にして街へ潜入するステージを作ったよ。
ゲームは未完なのでシナリオ分岐でゲームオーバーになるところまでプレイしたよ。

レトロゲームの改造ブログの人
烈火ifの楽曲データの移植方法を参考にしたよ。

ニコ動で【改造FE】ファイアーエムブレム聖魔の光石をあげていた人
コードに直ガキされていてる輸送隊の解禁フラグについて、逆汗解析資料を参考しにしました。
あれがなければ、輸送隊を序章から解禁できませんでした。
貴重な資料をありがとうございました。

kenpuhu
戦闘アニメーション変更の方法を教えていただきました。
トールハンマー　ファラフレイムの武器アイコンをもらいました。
クラス:ウィッチを使わせてもらいました。
ドボルザークの顔画像
マリカの戦闘アニメ
大盾のスキルアニメーション
メイドの戦闘アニメ

以下のアイコンはユグドラから
ミストルティン
メリクルソード
ボルガノン
ノーブルレイピア
グラディウス
バルムンク


以下のアイコンはFE7ifより
バルフレチェ
ラグネル

シークコの家のブログ
戦闘アニメーション変更の方法を詳しく解説されているブログ。
参考にしました。

sophia
フォルセティの武器アイコンを使わせてもらいました。

St Jack
マスターナイト女全武器を使わせてもらいました。
マントパッチを使わせていただきました。
フレアとエルニーニョを使いました

laqieer
ワールドマップ改造やTSAについていろいろ教えてくれてありがとう。
貴方のおかげでさまざまな謎が解明された。
知識量には感服する。

Resire
Credit: MisakaMikoto

MisakaMikoto
Resire

Donbettyr , Aqua
Credit: Alusq

Scott_Field_airship_hangar_interior_1942
背景に使用


誤字脱字をpdfで14ページも指摘してくれた名無しさん
ありがとう。我ながらよくここまでtypoしたものだと思いました。


2chのFE改造スレ
玉石混交かもしれないが、
日本における改造feのコミュニティだから、
参考にさせてもらっているよ。

Discord NGMationの人たち
いつも長い話を聞いてくれありがとう。


FE8Archives Wiki http://ngmansion.webcrow.jp/wiki/hackfe/
お世話になっています。
私も知り得たことをちょくちょく書いてます。
何か知ったことがあれば書いてくれれば嬉しいな。


まほーパッチv2
追加魔法エフェクトとして使いました。

まほーパッチv2を適応したことによるライセンス表記
This patch is based on Custom Spell Animation System in FEditor Adv by Zeld/Xeld/Hextator.
(transfered and edited.)

Spells:
-Ground Dasher 
Fire Blazer/Keriku and Bonzai

-Aqua Edge
Fire Blazer/Keriku and Bonzai

-Meteor
Blazer/Keriku and Jubby

-Swarm
Blazer/Keriku and Jubby

-Aura
Mikey_Se'regon, VincentASM, Jubby, 
shadowofchaos, and Ryrumeli

-Excalibur
Mikey_Seregon, VincentASM, Jubby, 
shadowofchaos, and Ryrumeli

-Thunder
Mikey_Seregon, VincentASM, Jubby, 
shadowofchaos, and Ryrumeli

-Bolganone
Mikey_Seregon, VincentASM, Jubby, 
shadowofchaos, and Ryrumeli

-Shaver
Mikey_Seregon, VincentASM, Jubby, 
shadowofchaos, and Ryrumeli

-ModularMinimugBox
Zane

All FE6 Mugs with Blinking Frames by Shin19

-GFE1R Project
Darros		by Frigid

-Arcfalchion
Karina
Arthur
Alice

-Stan
DancerAI
Range Display Fix

-circle
会話をしても行動済みにしない
支援会話をしても行動済みにしない

Assasin F	by RobertFPY
https://feuniverse.us/t/map-sprite-class-card-repository/186/158

斥候 by MeatOfJustice
https://feuniverse.us/t/map-sprite-class-card-repository/186/173

Dancer ClassCard by Orihara_Saki
https://feuniverse.us/t/map-sprite-class-card-repository/186/153

ヨツムンガンド (Jormungand)  by Orihara_Saki

Zane's Icons
ヴラスキャルヴ
ウェリネ
ロムファイア
クライディレド


Zelix's FE13 and FE14 Icons in GBA Colors
トライデント

sofia 女王の剣
ヴラスキャルヴ(ティティスの氷石)
戦車

Seal, Sacred War -Divinestone-
クライディレド

Faeriefruit
マイコウの杖アニメ NilsCrit

Berserker M (Dart)
Greentea and DerTheVaporeon

Sword Animation for the Dartzerker
Credit: Spud, Greentea, DerTheVaporeon, Raspberry, BwdYeti

[T2][SWD][Swordmaster](Fir)[F]
RedBean, Jj09
速度を少し早くなるように修正しています。

マスターナイト弓　回転モーションの追加
- 東郷

まふー
Duma Ocular Beam
- SHYUTERz,HIROTO

Miko
[Custom Magi] [F] Miko by RedBean. Scripted by Dolkar. Repallet by Lisandra_brave.

[T0][MISC][Crossover](Kirby - King Dedede)[M]{Volke0}
[T0][MISC][Crossover](Mario)[M]{Volke0, Superstar Saga}
[T2][CAV][Custom Cavalry](Grand Mahout)[U]{Orihara_Saki, CamusZekeSirius, SHYUTERz}
Lyon's Steel Tome Naglfar - Obsidian_Daddy , ZoramineFae

リト ウォーリア
[T2][AXE][Warrior](Tellius-Style Warrior Rework)[M](Leo_Link, Nuramon, Spud)

リト バーサーカー
[T1][AXE][Fighter](Gladiator)[M]{Waleed}

ダロス
Berserker M (Dart)
Greentea and DerTheVaporeon

ミルラ司祭
# [[T3.1 Bishop] [F] Matriarch by MrNight48]

ウィッチ杖
7. Staff (Venno)-20210709T235224Z-001

リィ
[T2][FLY][Wyvern Lord](Armored)[U]{Nuramon}

斥候 Scout
[WL Reskin] [M] Heath by Greentea
Animation by Greentea. Scripting by RobertFPY.

青いカーバンクル
https://en.wikipedia.org/wiki/Carbuncle_(gemstone)

# [[Shaman-Base] [F] Vanilla FE6 +Staff]
Staff by Jeorge_Reds.

# [[Pupil-Base] [M] Vanilla FE8 +Staff by Citrus]
Staff by Citrus.

# [[Mage-Reskin] [F] Hat by RetroGamer]
Made by Retrogamer

キャシーのフォレスト
# [T2][BOW][Ranger](Leo style)[F]{Leo_link]

Blueprint of Bruce Partington
https://ja.m.wikipedia.org/wiki/%E3%83%95%E3%82%A1%E3%82%A4%E3%83%AB:Priroda_-_Mir_module.png

[Monster-Custom] [U] AMOGUS Impostor by Link_DX
[Paladin-Custom] [U] Gold Knight by Nuramon
[Paladin-Custom] [M] Bow Knight by Spud
[Bard-Base] [M] Elffin Fancy +Magic
[T3 Custom] [U] Executioner (Assassin+Druid)
Catapult variant by Spud, Ren_Ookami.

チャトランガ
https://upload.wikimedia.org/wikipedia/commons/7/78/National_Museum_of_Ethnology%2C_Osaka_-_Catur-a%E1%B9%85ga_-_Rajasthan_in_India.jpg


[Sage-Custom] [F] Gaiden Priestess by Gamma
Animation by HyperGammaSpace, Jono.

[T3 Necromancer] [F] Archsage Lilina by Redbean
Made by Red Bean.
Scripted by Shin19.

[Non-FE] [F] Metroid - Samus by SurfingKyogre

[Villager-Custom] [F] Villager by Nuramon

[Misc-Supply] [U] T2 Merlinus Hot Air Ballon by Knabepicer

[Sword Custom] [F] Fencer by GabrielKnight

[Sage-Variant] [M] Red Mage by Reyk

[Custom Drag] [U] Dragoon by Mercenary Lord

[FE7 Lyn-Base] [F] T2 Vanilla +Weapons

[Lyn-Style] [F] Brave Lyn Nomad by RedBean

[Ranger-Custom] [F] Bernadetta by Redbean

[Custom Magi] [F] Witch by Pikmin

[Custom Magi] [F] Nino Pale Flower Flier by RedBean

[FE8 Eirika-Variant] [F] Priestess Celica T2 by RedBean

[Assassin-Reskin] [F] Ponytail +Skirt

[Sword Custom] [M] Samurai - Taijutsu Rogue

[Custom Lance] [M] Spartan by Vilkalizer

[Peg Custom] [F] Harrier Tethys by Ayr

[Paladin-Variant] [F] SALVAGED-Style Titania

[WL Reskin] [F] Marisa by 7743

[Gunner-Custom] [U] Promoted Gunner by Obsidian Daddy

[General - Reskin] Female General

[Sage-Custom] [M] Gaiden-Style by Spud

[Custom Magi] [F] Light Mage Micaiah by Cipher Lee

[Cleric-Base] [F] Vanilla FE7 Serra +Sword
Sword animations both added by Maiser6 and Raiden.
Repaletted by Furious

[Custom Oracle] [F] Oracle Repal +Staff
GabrielKnight, Seal, Sacred War

[Rogue-Reskin] [M] Trickster by Leo_Link

[T3 Custom] [M] Dark Prince Julius by Obs

[Warrior-Custom] [F] Camilla by SteamingTofu

[Myrmidon-Reskin] [F] Fir by Redbean

[Monster-Custom] [F] Tiki Half-Dragon by Tykky

[T2 Bishop-Variant] [F] Holy Priestess v2 Repal

[Devisian-Custom] [M] Occultist v1 by Devisian_Nights

[Custom DM] [F] Dark Mage by Pikmin

Plant_Academy's sophia

[Lyn-Reskin] [F] T1 Awakening-Style Myrmidon

[Sniper-Reskin] [F] Louise by Greentea

[Journeyman-Custom] [M] Boxer by Neph

[Swordmaster-Reskin] [F] Marisa by Redbean

[Griffon] [U] Griffon v1 Repal by Maiser6

[FE13-Custom] [M] War Monk by DerTheVaporeon

[FE13-Custom] [F] War Cleric by DerTheVaporeon

[Hero-Variant] [F] Echidna by Redbean

[Sage-Reskin] [F] Magician by BBHood217

[Sage-Reskin] [F] Nino by Greentea

[Sage-Custom] [F] Limstella v2 by Greentea

[Mage-Custom1] [F] Light Mage by L95

[Dancer-Base] [F] Vanilla FE7 Ninian +Weapons

[Dancer] [F] FE6 Larum by RedBean

[Lance][F]Nephenee by RedBean, なが夫

[Non-FE] [M] Sonic

Sophia by RedBean, ねねるね

[Cleric-Reskin] [F] Long Hair by Yangfly

[Swordmaster-Variant] [F] Mia by Redbean, knabepicer

[GK-Base] [U] Repal by Skitty

[Monk-Base] [F] Repal +Staff by Teraspark

[Monk-Reskin] [F] FEGirls-Style Skirt Pupil

[Cleric-Reskin] [F] FE13-Style by BatimaTheBat

[Cleric-Reskin] [F] FE13 Lissa by BatimaTheBat

[Bishop-Reskin] [F] Short-Hair TLP Style by Puppet

[Swordmaster-Variant] [M] Stefan by Solusaeternus

[Valkyrie-Reskin] [F] Non-Religious by Der

[MK-Variant] [F] Holy Knight by Teraspark

[Valkyrie-Reskin] [F] L'Arachel by Aruka v2 by Seal

[MK-Base] [F] Vanilla +Weapons

[MK-Base] [M] Vanilla +Weapons

[Troubadour-Variant] [F] Thaumaturge by Pikmin

[Priest-Reskin] [M] Buff Moulder +Muscles by Vilkalizer

[Sage-Variant] [F] Battle Sage +Sword by St jack

[Misc-Supplier] [F] Bandana Alt by JonoTheRed

[Devisian-Custom] [M] Seer by Devisian_Nights

[Bard-Style] [M] Elffin Sonneteer by Marlon0024

[Eirika-Base] [F] T1 Beta Eirika Fixed by Jono the Red

[Eirika-Base] [F] T1 Repal +Weapons

[Eirika-Variant] [F] Priestess Celica T2-Style by EA

[Eirika-Reskin] [F] T1 Custom Dress by Teraspark

[Peg Custom] [F] Deva by Ayr

[Peg Custom] [F] Nephilim by Ayr

N426's Pirate Shark Animation

[Bard-Custom] [M] Muse by Garytop

Female Generic variant of Eliwood's Knight Lord by RiriK

Celica Valkyrie by Plant_Academy

[WK Custom] [F] Camilla Malig Knight by SteamingTofu

[Sword Custom] [F] Ninja - Kagerou by SteamingTofu

[Nomad-Reskin] [F] Sue by RedBean

[T2 Druid-Reskin] [M] Buff by Pushwall

[Ranger-Reskin] [F] Naginata by RedBean

[Knight-Variant] [F] Wendy by RedBean

[Sage-Reskin] [F] Lilina by RedBean

[Sage-Reskin] [F] Lilina by RedBean

[Dancer-Variant] [F] Dancer by Redbean

[FE8 Eirika-Base] [F] T1 Vanilla +Weapons\1. Sword (Beta Backflip) by Struedelmuffin

[Berserker-Reskin] [F] Jacket by RedBean

Chokobo Rider by SkidMarc25

[T2 Summoner-Reskin] [F] Plague Doctor by DATonDemand

[Devisian-Custom] [M] Parson by Devisian_Nights

[FE7 Lyn-Variant] [F] Akiyama Blade Lord by VelvetKitsune

[Swordmaster-Reskin] [F] Kung Fu Monk by Reyk_Retro0337

Niimes re-paleete by Plant_Academy

Batima's Icon Collection

{Beansy} Torch.png

[Peg Custom] [F] Harrier by Ayr

[Peg Custom] [F] Harrier (Ayr) + Dagger by DatonDemand

[Custom Magi] [F] Miko V.2 by RedBean

[Axe-Custom] [F] Oni Chieftain by Dora Drago

[Shaman-Custom] [F] Idunn by SteamingTofu

[Myrmidon-Reskin] [F] Marisa by Redbean

[T3.1 Sage] [F] High Magus by MrNight48

[Swordmaster-Variant] [F] Larcei by SteamingTofu

勇士(女ウォーリャー) tatutachang

[Custom-Lord] [F] Halberd Brighid by Sphealnuke

FE8_Eirika-Reskin_F_T1_Leotard_and_no_cape by 真 Kimeru el perro

[Custom DM] [F] Dark Mage Tharja by SteamingTofu

Swordmaster-Custom_F_Trueblade_by_SteamingTofu

08.魔道士(ツインテール) tatutachang
09.賢者(ツインテール) tatutachang
Lion_Magnus tatutachang
山賊女 tatutachang
ポニテ ハルバーディア tatutachang
修道女(monk_girl) tatutachang

[Pegasus Knight 3rd Tier] [F] Seraph Knight by Dinar87

[Magic-Custom] Orochi by Sphealnuke

ヨツムンガルドアイコン
{2WB} (Icon Blitz 1) Slime.png

毒の槍+
{2WB} (Icon Blitz 1) Spear.png

Princess Peach by Uncle Mikey

[T3 FE7] [M] Archsage Athos by Red Bean

[Swordmaster-Custom] [F] Baiken by SteamingTofu

誤字脱字を指摘してくれた人

ネットでmidiを公開されている方へ
いろいろ勝手に使わせてもらいました。ごめんね。
すいません、許してください。何でもしますから？
今何でもしますっていったよなァ。
お兄さん許して、勘弁して下さい。


◆厨房用よくありそうな質問と回答
Q:パクリですか？
A:パクリですがそれが何か？

Q:恥ずかしくないんですか？
A:いやーそれほどでもー

Q:改変したい。
A:どうぞご自由に。

Q:話がくそすぎる。/ つまらない。/ 難しすぎる。/ 簡単すぎる。
A:それじゃあお前が作れよっ！(アラスカのシェフ大泉風に)

Q:このキャラがー　この設定がー　この話がー　この用語がー　おかしいんじゃないんですかー
A:それじゃあお前が作れよっ！(エビチリを作った時のシェフ大泉風に)

Q:キャラ絵があっていない。
A:細かいこと気にしていると、胃に穴空くか、髪の毛抜けてハゲるぞ。

Q:漢字の使い方がおかしいだろう。バカですか？そんな奴があれこれ語るなよ。
A:国語の大先生お疲れ様です。
あと、誤字脱字はバグ報告してネ。

Q:クリアできない。
A:勝手に改変してプレーしてね。

Q:クソゲーですか？
A:神ゲーかもしれません。

Q:神ゲーですか？
A:クソゲーかもしれません。

Q:どっちですか？
A:さあ？
プレーしてみればいいのでは？

Q:死ねよ
A:よくいわれます。

Q:バカにしているんですか？
A:とんでもない。

Q:こんなの現実でありえない / これはあれこれを風刺しているのでは？
A:フィクションに何言ってる？バカなの？

Q:悪人を擁護するのか？
A:フィクションに何いってんだこいつ・・・

Q:思想的に右と左どっちなんですか？
A:上かなあ・・・
私は上を見上げるのが好き。

Q:このパッチ、ムカつく
A:こんなゲームにまじになっちゃってどうするの？暇なの？

Q:もう作るんじゃねぇよ。クソが。
A:いわれなくても、改造FEの新作は多分もう作らないヨ。
これを作るのにどれだけ大変だったと思っているんだヨ。
もう二度と作りたくねーよ。
だから次はお前が作れよ。
オレ様がお前のクソゲーをあそんでやるよ。

Q:バナナはおやつに入りますか？
A:弁当箱に入っていれば弁当の一部なのでおやつではありません。

これでだいたいの問題は解決したと思います。
それでも、これ以外の質問がありましたら、
深夜2時に、全裸で、ベランダか屋根に上り、白鳥の湖の舞を舞いながら片足を上げて、そのまま思っていることを大声で空に向かって叫びましょう。
いろいろなことが解決するかもしれませんヨ。
なお、その結果はすべて自己責任でお願いします。


ちょっと煽りすぎたかな？
わかんないことあったら聞いてねww


このパッチはFE8聖魔の光石の二次創作作品です。公式とは一切関係ありません。
お話はすべてフィクションです。現実のいかなるものとも関係ありません。
無保証　自己責任でお願いします。
常識の範囲内で遊んでください。
