---Hack by Mkol103---

Hi, thanks for downloading!
The goal of this project is to take all the amazing hacks
from the Fire Emblem GBA hacking community and put them
into the base game experience. These are designed for
veteran players and newcomers alike!
The changes are designed to be uncontroversial enough
so that this isn't seen as an "alternate" way to
play the game but an "enhanced" way.
The major changes are QOL and bugfixes.
The only gameplay changes come from removing
localization changes.

Each game folder has multiple patches;
I'll describe each briefly

Fixed:
Fixed refers to an alternate way of character growth. This mode is recommended for veteran players. Inexperienced players can ignore this.
In the vanilla game, each character has a growth value out of 100. When they level up, they have that percentage change to gain a stat in that category.
(e.g. Roy has an 80 HP growth, so every time he levels up, he has an 80% change to gain a point of HP. Theoretically, he gains 4 points of HP in 5 level ups).
Fixed growths uses a formula to determine growths. Essentially, every character starts with 50 "Growth Points (GP)" per stat.
Whenever they level up, their growth is added to their growth points. When this number exceeds a multiple of 100, they level up.
(e.g. Roy has an 80 HP growth and 50 HP GP. First level up: GP is 130 [he gains a point]. Second level up: GP is 210 [he gains a point]. Third level up: GP is 290 [he doesn't gain a point]. Fourth level up: GP is 370 [he gains a point]. Fifth level up: GP is 450 [he gains a point]. Here, what is theoretically suppose to happen occurs playthrough.)


FE6:
Original vs Numbers:
There are very few Qol changes made to the Original because there are few ROMhackers interested in FE6 in the community. The experience nearly mirrors playing without the patch (though there are some worthwhile additions)
The numbers patch was created by Gringe and includes a variety of changes.
Some of them being: 
change of weapon stats to mirror FE7,
removal of ambush spawns, 
hard mode bonuses given to more units, 
stats/growths altered slightly.
These are all done to make the game more accessible.
For someone determined to play the game as it was intended, play the original.
For a more casual fan or someone who just wants to experience the game without getting a headache, play the Numbers patch.

I would recommend the Numbers version to a newcomer.

FE7:
Original vs JP:
The JP version includes extra, minor changes to bring the game more in line
with the Japanese original. Both games are fairly similiar,
and whichever one you pick is up to your preference. 

I would recommend the Original version to a newcomer, but the Japanese version is equally valid.

FE8
Original vs Mix vs JP:
The localization changes in the Original introduced some more major balancing changes. 
The Mix version restores the original hard mode bonuses for enemies and fixes a glitch which made promoted enemies weaker.
The JP version undoes nearly all of the changes brought about by the localization (though these changes don't make the game necessarily easier or harder. Just different)
The Mix version is for someone (like myself) who is familiar
with the base game and wants to experience the game like that, but tweaked slightly to match the original intent more closely.
The JP version is for someone who wants a larger difference from
the original or is a purist. The Original version is for someone who
wants the game to play exactly as it did when it first came out Internationally.

I would recommend the Original version or the Mix version for newcomers.


QoL changes:
All:
Casual mode is a mode where characters return from dying the next map. In the vanilla game, dead characters stay dead forever. Select it at the beginning of the game to use.

FE7 & FE8:
Press select on the map to toggle the range of enemy units. In FE8, you can maually toggle the ranges of specific units with select.
Hold L during combat to switch the animation mode (from ON to OFF or vice verse)

FE7 only:
Press select to view a character's growths

For anyone who wants to see a fuller list of changes, 
read the readme in each game's folder.

Patch FE7 and FE8 with a US rom. Patch FE6 with a clean JP rom.

Thanks to FEBuilderGBA for assisting me with hacking, Tequila for the original FE7 QOL patch that inspired this, Gringe for their FE6 translation patch, and TCRF for detailing localization changes