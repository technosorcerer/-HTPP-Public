---Hack by Mkol103---

Hi, thanks for downloading!
The goal of this project is to take all the amazing hacks
from the Fire Emblem GBA hacking community and put them
into the base game experience. These are designed for
veteran players and newcomers alike!
The changes are designed to be uncontroversial enough
so that this isn't seen as an "alternate" way to
play the game but an "enhanced" way.
The major changes are QOL and bugfixes.
The only gameplay changes come from removing
localization changes.
View all the specific changes under the patch descriptions.
Make sure to use whichever patch you want onto a US version of Fire Emblem Sacred Stones (GBA)

This game has multiple patches;
I'll describe each briefly

Fixed:
Fixed refers to an alternate way of character growth. This mode is recommended for veteran players. Inexperienced players can ignore this.
In the vanilla game, each character has a growth value out of 100. When they level up, they have that percentage change to gain a stat in that category.
(e.g. Roy has an 80 HP growth, so every time he levels up, he has an 80% change to gain a point of HP. Theoretically, he gains 4 points of HP in 5 level ups).
Fixed growths uses a formula to determine growths. Essentially, every character starts with 50 "Growth Points (GP)" per stat.
Whenever they level up, their growth is added to their growth points. When this number exceeds a multiple of 100, they level up.
(e.g. Roy has an 80 HP growth and 50 HP GP. First level up: GP is 130 [he gains a point]. Second level up: GP is 210 [he gains a point]. Third level up: GP is 290 [he doesn't gain a point]. Fourth level up: GP is 370 [he gains a point]. Fifth level up: GP is 450 [he gains a point]. Here, what is theoretically suppose to happen occurs each playthrough.)

USA vs MIX vs JPN:
The MiX version is the same as the USA version, but it also makes minor adjustments to make the game more in line with the Japanese version. Specifically, it fixes a bug which made promoted enemies units weaker than they should have been. Also, it changes the difficulty bonuses so that enemy levels are the same as the JPN verson.
The JP version includes extra, minor changes on top of MIX to bring the game more in line
with the Japanese original. This includes enemy inventories, chaaracter stats/growths, shop items, etc.

I would recommend the USA version to a newcomer. People who have played the game should try out MIX or JPN.

Below is a list of all the changes made to the game:

All versions:
(Edits by 7743)
-Enable faster movement
-Fimbulvetr gltich fix
-Pierce glitch fix
-Fix Enemy Control Glitch
-Display battle stats with animations off
-Change default settings
-Fix Stone Map Animation
-Prevent Misheal bug
-Unlocks Sound Room from the start
-HP bars with warnings
-Show HP healed to target when using a staff
-Toggle Animations with L button
-Causal Mode added
-Minor typos in Supports fixed
-Sped up AI
-Fixed Large level-up display issue
-Fixed display glitch when display time 100-110 hours
-Danger Radius

MIX & JPN Version:
-Fixed promoted enemy bug
-Difficulty Mode Bonuses restored

JP Version:
-Enemy inventory and map changes restored
--Some enemies (mostly bosses) have reverted equipment 
--Joshua will now attack Natasha if she is in range in Ch. 5 
--In Chapter 15, the locations of the bosses were reverted from forts into standard tiles
--Fomortiis summons reverted to their weaker Japanese version
-Reverted item stats back to Japanese Version
--Rapier and Reginleif no longer are effective against Mage Knights, Tarvoses, and Maelduins
--Certain weapons now have modified might, crit, worth, or stat bonuses
-Character/Class stats reverted to Japanese Version
--Base stats/growths reverted to Japanese version 
--Class stats/growths/stat caps reverted to Japanese version 
--Gorgon movement type reverted to from mage to flier 
-Armory/Vendor/Secret Shop inventories reverted to Japanese Version