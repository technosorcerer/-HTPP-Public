#pragma once

#include "common-chax.h"

void PrologueCallBack(void);
