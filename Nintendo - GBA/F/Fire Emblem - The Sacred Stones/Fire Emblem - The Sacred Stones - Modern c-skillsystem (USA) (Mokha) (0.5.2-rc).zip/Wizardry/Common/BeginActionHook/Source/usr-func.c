#include "common-chax.h"
#include "action-expa.h"

void InitActionExpa(struct Unit * unit)
{
    memset(&gActionDataExpa, 0, sizeof(gActionDataExpa));
}
