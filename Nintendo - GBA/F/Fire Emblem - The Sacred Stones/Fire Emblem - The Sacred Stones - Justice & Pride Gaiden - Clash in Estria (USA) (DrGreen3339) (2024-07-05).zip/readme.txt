Gaiden Chapters
All are optional and can be declined
3x - Automatic
10x - Karin & Marisha are alive
15x - Nestor fights Yureon (outcome doesn't matter, the battle quote just needs to display)
22x - Nestor is alive
26x - Automatic
27x - Automatic if 26x was cleared (escaping doesn't count)

Ending Split
There is an ending split. It's not really a good or bad ending, but rather separate outcomes. Which one you get is determined
by whether or not ch 26x is completed without escaping.

Recruitment
Ambrose - Automatic in Prologue
Geraint - Automatic in Prologue
Isabella - Automatic in Prologue
Kip - Automatic in Prologue
Erin - Ch 1, Automatic on turn 2
Ringo - Ch 1, Automatic on turn 2
Taylor - Visit the village in Ch 1
Zane - Ch 2, talk w/ Ringo
Karin - Ch 2, talk w/ Ambrose. Joins after chapter if not recruited
Janice - Ch 2, talk w/Ambrose or Karin. Joins after chapter if alive but not recruited
Rowan, Lucian, and Stella - Ch 3, Automatic on Turn 1
Peter - Visit the village in Ch 3x
Rolfe - Automatic after finishing Ch 4
Lucille - Ch 5, talk w/ Ambrose
Faust - Ch 6, automatic on Turn 1
Michael - Visit western village in Ch 7
Annabelle - Ch 8, automatic
Jen & Sami - Ch 9, automatic
Boey & Marisha - End of Ch 9, automatic
Paloma - Ch 12, talk w/Ambrose or Annabelle
Jolene - Ch 13, automatic on Turn 1
Mordecai - Ch 13, talk w/ Jolene
Laurence - Ch 14, automatic
Nestor - Ch 15, automatic
Azaria & Alicia - Ch 16, talk w/Ambrose or Annabelle
Furia - Ch 17, visit the SW house
Shachar & Evelyn - Ch 19, automatic on Turn 1
Colt - Ch 20, visit north village
Nina - Ch 21, talk w/Ambrose
Clarice - Ch 22, talk w/Ambrose. Joins after chapter if not recruited
Wesley - Joins w/ Clarice. Joins after chapter if alive but not recruited
Dan - Ch 22x, joins at end of chapter
Celine - Talk w/Ambrose or Taylor
Bart - Talk w/Ambrose
Ferris - Visit NW village in ch 26
Caterina - CH 28, automatic