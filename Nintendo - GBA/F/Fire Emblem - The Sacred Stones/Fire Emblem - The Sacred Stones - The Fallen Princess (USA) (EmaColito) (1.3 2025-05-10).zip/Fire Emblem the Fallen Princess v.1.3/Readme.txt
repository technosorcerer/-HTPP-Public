To play, download a FE 8 USA ROM and install it using NUPS.
NUPS link: https://www.romhacking.net/utilities/606/


If you find any errors of any kind that can ruin the game or story, just let me know.
Thanks for your help.