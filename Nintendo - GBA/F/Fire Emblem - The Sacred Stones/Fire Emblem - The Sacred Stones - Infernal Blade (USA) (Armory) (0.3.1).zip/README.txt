==README==

This is an FE8 hack, you will need to find a unmodified FE8 (U) rom somewhere from the internet. I have playtested this on Mgba so if that is the emulator you use then you should be good to go, however, other emulators should work. You will also need the NUPS program to patch to the rom itself which should be easy to find.

The hack is mostly playable up to chapter 25 with the story done up to 10, the last three chapters aren't complete yet but they will be completed eventually, some other chapters may also get updates/changes.

The story is nonexistent after 10 other than a few recruitment texts here and there, though these will likely get changed, you are free to skip any text after chapter 10. Supports are in in terms of who supports who but text is left unchanged.

For those wanting guides such as recruitment, secret shops etc. then you'll have to wait a little while longer. Though I will say the two lords DO recruit most characters.

==About==

I won't go into too much detail about the hack's story itself as I just want you to play and see it goes. I started this hack myself about a year ago, obviously with very rough looking chapters and slowly but surely I found myself thinking of a story, but since I'm not really a writer, I found a good friend to help with the writing and story. 

Other than myself and him, I have evented all the chapters whilst he wrote the script, if anything looks strange when playing up to chapter 10 then just let me know.

There are also many references to other stuff that some will and won't understand, if you can spot them all, your clever.

==Known bugs so far==

After multiple playtests myself there aren't any I have found except one.

For some reason, a generic halberdier enemy attacking Tizi may hang the animation slightly for about a half a minute, however, this is very rare.

Some late game playables, bosses and death quotes have been unchanged from vanilla as well as a few not having any yet, these will be added in later patches.

==Features==

There are NO skills other than the class skills from vanilla, I want this to be a more traditional hack.

There are nearly 50 playable characters, with varying classes, good for ironman players as prepromotes are quite competent.

Some new classes such as Halberdier, Wolf Rider etc.

New monsters!

Music from other games, and some memey ones because why not?

A variety of chapter objectives such as Arrive, Escape, Survive etc.

Many other small features!

==Last note==

I put a lot of hard work into this hack in terms of ironing out the small errors for now other than the known one, there shouldn't be any bugs but if there are any then do not hesitate to contact me. ALso, I wan't to give a big personal thanks to the cummunity as this hack would not be possible without the many amazing F2U assets from the repo, FEU and SF.

Please enjoy the hack nevertheless!