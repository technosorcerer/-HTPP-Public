>Use this patch on a FE8 [USA version] ROM clean.
