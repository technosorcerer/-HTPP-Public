Mod by Kurayamiblack for "Fire Emblem 8: The sacred Stones" (U)

CONTENTS:
This mod was originally created for 2RN, but a 1RN mode was added for the fun of it.
The difference between 1RN and 2RN is how the game internally rolls for luck based events like Hit, Crit, and level ups. 1RN is true RNG where the game only rolls for chances once. 2RN rolls for each even twice instead, resulting in more lenient and forgiving results. Most official FE games including vanilla FE8 run on 2RN by default.
Both are available in this directory.

Inside the "Additional Mod Information" folder, you will find:
- A "Development Changelog" showing the development process.
- A "Script Changes log" that shows the dialogue changes to the original game.
- A "Character Guide" explaining each playable character's new characteristics in detail.
- A "Class Guide" explaining each Class's new characteristics in detail.
- Credits for the mod's production and borrowed assets
- A "New Character Quick Guide" giving fast, simple info on the 6 new characters added to the game.


THE SIMPLE IDEA:
FE8 Alternative is a project that experiments with a new system of base stats, class roles, and weapon effectiveness to see if the changes can be utilized in a way that is still enjoyable. To see if what was "bad" in one mod can be "Good" or at least okay in a setting that actually takes those changes into consideration when balancing other things. It also strives to provide a replayable game where new playthroughs can yield different feeling experiences and the value of things can be different from run to run.
I hope you enjoy playing it, and please support the official release!


INSTALLATION:
For help installing these patches, please copy this link to FEUniverse into your browser and follow the instructions:
https://feuniverse.us/t/how-to-use-ups-files/8502
