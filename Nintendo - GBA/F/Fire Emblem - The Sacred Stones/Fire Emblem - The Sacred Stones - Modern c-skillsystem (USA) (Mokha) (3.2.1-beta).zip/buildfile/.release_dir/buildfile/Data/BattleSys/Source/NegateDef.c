#include "common-chax.h"
#include "battle-system.h"

struct NegateDefConfEnt const gNegateDefConf[] = {
	{
		ITEM_DARK_LUNA, 100, 0
	},
	{
		ITEM_MONSTER_WRETCHAIR, 100, 0
	},
	{ 0 }
};
