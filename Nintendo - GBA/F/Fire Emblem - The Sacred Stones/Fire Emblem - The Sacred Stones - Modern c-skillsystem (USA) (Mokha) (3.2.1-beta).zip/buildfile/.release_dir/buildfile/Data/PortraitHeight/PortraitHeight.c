#include <common-chax.h>

const u8 HighPortraitFidLut[] = {
	FID_LUTE,
	FID_AMELIA,
	FID_EWAN,
	FID_DOZLA,
	FID_MYRRH,
	0
};
