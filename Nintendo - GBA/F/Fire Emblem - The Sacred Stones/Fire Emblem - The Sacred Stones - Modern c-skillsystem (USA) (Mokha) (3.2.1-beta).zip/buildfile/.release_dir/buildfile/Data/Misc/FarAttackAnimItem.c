#include "common-chax.h"

const u16 FarAttackAnimItems[] = {
	ITEM_SWORD_RUNESWORD,
	ITEM_AXE_HANDAXE,
	ITEM_AXE_TOMAHAWK,
	ITEM_AXE_HATCHET,

	ITEM_NONE,
};
