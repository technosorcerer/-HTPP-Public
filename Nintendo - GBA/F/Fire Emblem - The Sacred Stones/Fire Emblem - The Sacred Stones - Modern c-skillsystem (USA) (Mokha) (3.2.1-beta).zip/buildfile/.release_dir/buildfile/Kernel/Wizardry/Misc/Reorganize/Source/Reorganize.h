#include <common-chax.h>

u8 ItemSubMenu_ReorganizeUsability(const struct MenuItemDef *def, int number);
u8 ItemSubMenu_ReorganizeEffect(struct MenuProc *menu, struct MenuItemProc *menuItem);
