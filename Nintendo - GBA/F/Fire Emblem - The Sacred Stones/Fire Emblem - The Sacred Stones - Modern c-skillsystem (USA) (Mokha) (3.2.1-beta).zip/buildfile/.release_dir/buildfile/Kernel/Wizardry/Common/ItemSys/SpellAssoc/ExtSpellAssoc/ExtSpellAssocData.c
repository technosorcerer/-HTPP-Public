#include "common-chax.h"

const struct SpellAssoc ExtSpellAssocData[] = {
	SPELL_ASSOC_DATA_WPN_DEFAULT(0xFFFF),
};
