Chessmaster
Niemann Rumble Patch v1.0 by djedditt
Release date: 10/08/2023


DESCRIPTION
================================
Get secret vibration hints in Chessmaster for Game Boy Advance with this Niemann rumble patch! Just hover over the pieces until you feel a vibration. Pick it up, and start moving it around until you feel another vibration. That's a move suggested by the Chessmaster hint system, without explicitly asking for a hint through the menu. Vibration hints are enabled after after playing two moves.

The rumble functionality is compatible with both emulators and real hardware. It will work on any flashcart with a rumble motor such as insideGadget's rumble cartridge or an EZ-Flash OMEGA Definitive Edition.


ROM/ISO INFORMATION
================================
Filename and hashes from the No-Intro database.

- Chessmaster (Europe)
- CRC32: 27E7FD09
- MD5: 358C87FE02D8CE7207FB101839BBB820
- SHA-1: 78F9BD1C4FA2292C9EDDD83A425517F89D4525C2


CHANGELOG
================================
10/08/2023
- Initial release


CONTACT
================================
If you have any questions or just want to say hi, feel free to send me a message at djedditt@msn.com
