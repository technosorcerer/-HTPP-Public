
 This download contains three patches for Castlevania: Circle of the Moon for GBA:
 
	- JP Exp Patch: Replaces the experience table in the US ROM with that of the JP ROM's exp table
	
	- Level 1 Cap: Removes the ability to gain experience and level-up through any means
	
	- Level 1 Cap (IG Fix): Same as the Level 1 Cap hack except it removes the Iron Golem boss's ability to heal to make
	  a Fighter Mode playthrough possible
 
 
 
 Created by Rexius55
 
 If you have anything concerning/relating to this hack or any of my other work, contact me at:

	- The Castlevania Modding Boards, whether through PMs or my project threads
	- Twitter/X
	- Reddit

 Enjoy the hacks!