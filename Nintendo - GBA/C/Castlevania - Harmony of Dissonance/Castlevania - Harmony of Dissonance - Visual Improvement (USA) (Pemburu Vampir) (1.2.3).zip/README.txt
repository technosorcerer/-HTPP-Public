There are 4 patches and another 4 with different translation 
Choose whichever you like!

Patch only work on clean dump of the USA Version of the game, other versions may not work.
Patch is in .ips format use ips patching tool

NZ is the one with ncoZ's Juste sprites
DA is the one with Devilart's Juste sprites

C-Whip is for Chain Whip, if you don't see C-Whip in the file name, it means it's the original whip