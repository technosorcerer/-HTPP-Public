By GoodLuckTrying

Castlevania HoD (USA) - Visual Improvement.ips
Removes outlines from Juste, Maxim and Bat enemy.
Contains blue title screen.

Separate Patches:
- Castlevania HoD (USA) - No Outlines (Juste, Maxim and Bat).ips
Removes outlines from Juste, Maxim and Bat enemy.


- Castlevania HoD (USA) - No Outlines (Only Juste and Maxim).ips
Removes outlines from only Juste and Maxim.

Individual Patches (Self-Explanatory; can patch on top of original or patched rom)
- Castlevania HoD (USA) - No Blue Border (Juste).ips
- Castlevania HoD (USA) - No Blue Border (Maxim).ips
- Castlevania HoD (USA) - No Blue Border (Bat).ips

Title Screen Patches (Can patch on top of original or patched rom)
- Black Selector and Game Start.ips
- Blue Selector and Game Start.ips
- Red Selector and Game Start.ips
- Dark Blue Selector and Game Start.ips