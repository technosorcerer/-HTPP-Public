There are 4 patches: (1) original whip and (2) with Devilart's sprites and (3) chain whip and (4) with Devilart's sprites. Choose whichever you like!
Patch only work on clean dump of the USA Version of the game, other versions may not work.
Patch is in .ips format use ips patching tool

use the one with the name "DA" for Devilart's sprites