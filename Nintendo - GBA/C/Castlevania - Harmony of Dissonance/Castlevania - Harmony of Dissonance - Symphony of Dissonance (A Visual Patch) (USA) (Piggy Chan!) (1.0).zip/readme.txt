Castlevania: Harmony of Dissonance is a contentious game to many, in part due to its overly brightened color palette.
This ROM hack attempts to correct this, by giving its visuals a re-mastering that is inspired by Castlevania: Symphony
of the Night (an obvious influence on the title), but also that is nevertheless faithful, for the most part, to the makeup of
the original game. 

This hack utilizes Pemburu Vampir's HoD Palette Hack as a base, utilizing most of their spritework, and is released
with their permission.

This is a standard IPS patch, please use Lunar IPS to apply it to a copy of a clean ROM*. It has not been tested on
other versions or ROM hacks. Please feel free to use this patch on personal projects, with due credit given.

*The ROM in question is as followed: 

0612 - Castlevania - Harmony of Dissonance (U)(Independent).gba