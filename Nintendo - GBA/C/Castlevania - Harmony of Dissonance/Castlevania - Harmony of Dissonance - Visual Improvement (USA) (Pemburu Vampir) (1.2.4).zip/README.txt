There are 4 patches. 2 with original translation and another 2 with different translation 
Choose whichever you like!

Patch only work on clean dump of the USA Version of the game, other versions may not work (but it seems Europe version works too, I haven't tried).
Patch is in .ips format, use ips patching tool to patch the game

C-Whip is for Chain Whip, if you don't see C-Whip in the file name, it means it's the original whip