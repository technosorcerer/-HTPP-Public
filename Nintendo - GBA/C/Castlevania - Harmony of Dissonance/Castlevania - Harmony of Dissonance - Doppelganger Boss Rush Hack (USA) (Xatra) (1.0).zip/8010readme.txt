CAUTION: This hack has only been tested to work with the NTSC-U (USA) release of Castlevania: Harmony of Dissonance and only tested to run as intended on mGBA.
Castlevania: Harmony of Dissonance - Doppelganger Boss Rush
Made by Xatra.

The Doppelganger Boss Rush rom hack puts you into a linear series of boss arenas, in which you must face your Doppelganger, as well as a "Guardian." Once the Guardian is defeated, you can either move on to the next room, or go back and save.

Playing as Maxim in this rom hack is **REQUIRED**! There is a save bundled in with the patch that allows you to play as Maxim right from the start.

How to apply:
1) Go to https://romhacking.net/patch
2) Next to "ROM file," select "Choose File."
3) Locate your Castlevania: Harmony of Dissonance rom and upload it to the site.
4) Next to "Patch file," select "Choose File."
5) Locate the folder this document is in, and upload "Harmony of Dissonance Doppelganger Boss Rush.ips" to the site.
6) Select "Patch."
The patched rom will be downloaded automatically.
There is also a hardmode add-on that can be applied after doing these steps. See "About Hardmode.txt" for steps on how to apply it.
You will need to rename "Completed Save.srm" to the same name as the patched rom or most emulators will not recognize it.

Enemy Name Changes:
Maxim -> Doppelganger
Golem -> Rock Armor+
Peeping Big -> Eyeclops
Skull Knight -> Undead Crusader
Living Armor -> Great Armor
Giant Bat -> Bat Lord
Devil -> Cursed Demon
Death (Phase 2) -> Death Lv2
Max Slimer -> King Slime
Giant Merman -> Megalodon
Talos -> Final Guard
Dracula Wraith -> Dracula

Balancing changes:
(All enemy changes here are based off the enemy stats used in Maxim Mode. These stats are seperate from Juste's modes.)
Maxim's Mirage has had it's MP cost decreased from 100 to 35. A heart cost of 4 was added on top of the MP cost.
Maxim's Shuriken has had it's heart cost decreased from 5 to 2. The maximum amount of Shurikens that can be on screen at one time has been increased from 2 to 5.
Maxim's Healing Spell has had it's heart cost reduced from 50 to 2. an MP cost of 25 was added on top of the heart cost.
Doppelganger has had their ATK reduced to 37. This only affects damage taken from melee attacks, this does not affect Shuriken and Mirage.
Rock Armor+ has had their HP increased to 3000.
Rock Armor+ has had their ATK reduced to 0. This only affects the damage taken when running into the enemy, not the damage taken from their special abilities.
Eyeclops has had their HP increased to 3000.
Undead Crusader has had their HP raised to 2400. (This is their total HP, not their per phase HP.)
Undead Crusader has had their ATK reduced to 0. This only affects damage taken when running into the enemy, not the damage taken from their special abilities.
Great Armor has had their HP increased to 3000.
Great Armor has had their ATK reduced to 80. This only affects the damage taken when running into the enemy, not the damage taken from their special abilities.
Bat Lord has had their HP increased to 3000.
Bat Lord has had their ATK reduced to 0. This only affects the damage taken when running into the enemy, not the damage taken from their special abilities.
Cursed Demon has had their HP increased to 3500.
Cursed Demon has had their ATK reduced to 0. This only affects the damage taken when running into the enemy, not the damage taken from their special abilities. Taking damage from a fire laser will flip this around, making special abilities do no damage and running into the enemy do great damage.
Minotaur has had their HP increased to 3500.
Minotaur has had their ATK reduced to 0. This only affects the damage taken when running into the enemy, not the damage from their special abilities.
Minotaur Lv2 has had their HP increased to 3500.
Minotaur Lv2 has had their ATK reduced to 0. This only affects the damage taken when running into the enemy, not the damage from their special abilities.
Death has had their HP reduced to 2000. (This is their per phase HP, not their total HP.)
Death has had their ATK reduced to 0. This only affects the damage taken when running into the enemy, not the damage from their special abilities.
Death Lv2 has had their ATK reduced to 80. This only affects the damage taken when running into the enemy, not the damage from their special abilities.
King Slime has had their HP increased to 4000.
Megalodon has had their HP increased to 4000.
Megalodon has had their ATK reduced to 80. This only affects the damage taken when running into the enemy, not the damage from their special abilities.
Shadow has had their HP increased to 4000.
Cyclops has had their HP increased to 5000. 
Cyclops has had their ATK reduced to 0. This only affects the damage taken when running into the enemy, not the damage from their special abilities.
Pazuzu has had their HP increased to 5000.
Pazuzu has had their ATK reduced to 0. This only affects the damage taken when running into the enemy, not the damage from their special abilities.
Final Guard has had their HP increased to 5000.
Dracula has had their HP increased to 6000.

Music changes:
The music in Marble Corridor A has been changed to Vampire Killer.
The music in Marble Corridor B has been changed to Vampire Killer.
The music in Luminous Caverns B has been changed to Vampire Killer.
The music in The Wailing Way B has been changed to Vampire Killer.
The music in Castle Treasury B has been changed to Vampire Killer.
The music in Clock Tower A has been changed to Vampire Killer.
The music in Clock Tower B has been changed to Vampire Killer.

Known issues:
Opening the map in the first few rooms of the game causes a graphical glitch.
Visual bugs occur in all arenas.
Maxim cannot use any subweapons, Healing Spell, or Maxim Mirage after Doppelganger dies. Maxim's sword sprite also despawns, but the hitbox remains the same.
On some emulators, the boss doors do not appear.
Undead Crusader cannot be hit until you take damage.
A visual bug occurs when entering Minotaur's arena if the "CLOCK TOWER" name graphic is still on screen.
The Pazuzu arena is silent.
