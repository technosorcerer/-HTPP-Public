Castlevania Aria of Sorrow - Thief mode Patch

This mode tries to replicate the same feeling of the luck / thief mode
in symphony of the night and circle of the moon.
You start with maxed Luck and a Rare ring making drops almost 
guaranteed. 

Something new about the mod is the weapons, all the enemies that carry a weapon
in their hands can drop it, also they don't drop souls, you encounter them
around the castle. This makes it a little more difficult and encourages
farming weapons, armor and healing items.

Thanks:

The mod was entarely made with the DSVania Editor developed by LagoLunatic
https://www.romhacking.net/utilities/1271/

it uses the Soul Containers Don't Seek asm patch by Xanthus1 
https://github.com/Xanthus1/aos_patches/tree/main?tab=readme-ov-file

also it uses the LCK fix patch released by Rabite making this possible
https://www.romhacking.net/hacks/5645/

A lot of thanks to them.
