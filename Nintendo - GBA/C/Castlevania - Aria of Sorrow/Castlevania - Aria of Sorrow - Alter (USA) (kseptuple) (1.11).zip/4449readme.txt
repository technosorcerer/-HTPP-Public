FAQ:
Q: I suddenly encounterd the Game Over screen.
A: Use all souls and all items cheatings are not allowed. Also, do not use original AoS game save data.

Q: I opened this rom in DSVania Editor, and the editor crashed.
A: An modified editor is needed to edit this rom. Maybe I will release an modifiable version of this. 

Q: But my editor is no longer launchable!
A: Some older version of editor may keep crashing after you try to load this rom, if this happened, open settings.yml in your editor folder, and remove all text in the same line after ":last_used_folder:".

Q: Can I repost this to somewhere else?
A: Do if you want.
