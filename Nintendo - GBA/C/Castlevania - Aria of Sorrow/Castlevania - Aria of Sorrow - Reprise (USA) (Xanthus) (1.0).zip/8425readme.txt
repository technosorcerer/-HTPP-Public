﻿Mod Name: Castlevania Aria of Sorrow: Reprise (Roguelike/Endless Mode)
Author: Xanthus
Latest Release: 1.0 - 2/2/24
Discord to stay up to date and give feedback: https://discord.gg/PytA9rr6nz
Other Credits:
	LagoLunatic for DSVania Editor and Aria of Sorrow documentation!
	Dev Anj for LCK/INT fix patches
	FuseCV for code to add souls to the shop, and the original Kicker Skeleton without Malphas patch
	Testers:
		31Silver
		Alkali Man
		Berix
		Derxu
		Erdasin
		EvilQueenEzra
		goldenspacedragon
		Ixsai
		NuWar
		PeyoteAsesino
		rabite
		Stavvy

Description:
A roguelike mod for Aria of Sorrow with a procedurally generated castle
along with custom rooms, extensive new features, effects and rebalancing!
Explore randomized areas, clear rooms, and then fight the boss
to advance the game. Experiment with new equipment and soul abilities!

Install:
Apply the patch to a Castlevania Aria of Sorrow (USA) ROM using an IPS patching utility like Floating IPS.

Main Features:
	- Procedural generation using the filename as the seed.
		- There are six generated areas, each contains rooms from two 'vanilla' areas
			- Each area has a special feature in the 3rd room (Stat pickup, a different shop, money, etc.)
			- Most rooms have been customized to better fit this mod.
		- When you defeat a boss, the castle is randomized, stronger enemies/ items can spawn, and a new item is added to the shop.
		- Randomized progression. There are progression soul indicators outside each area.
	- There are 19 randomized effects which affect certain rooms (e.g. poisonous enemies, higher knockback, or changing physics, etc.).
	- Weapons, Armor, and Accessory pickups are spawned in a mostly progressive order with some randomization.
	- Soul item pickups are randomized
	- New Equipment and Soul effects / balancing (full details in Balance section)
	- Four available difficulties, optional setting to delete your save on death.
		- Hard/Nightmare don't have potions in the first shop and get more difficult over time.
	- Game saves after leaving a boss room.
	- Outer walls in rooms can contain hidden breakable items.
	- Includes patches authored by Dev Anj to make LCK more impactful, and INT improves red souls instead of STR.
	- Other gameplay changes such as diving with a single jump, faster slides, better bounce on divekick.
	- Julius mode: Hold L while hitting start on the file name entry screen.

Balance details:
	* General:
		* Resistance for enemies reduces damage to 25% instead of 50%.
		* Soul / Item drop chances increased.
		* Limits quantity for pickups / buying to 5.
		* Selling gives 25% of the price rather than 50%.
		* You can divekick with a single jump, slides are faster/shorter, and divekick has a better hitbox and bounces up more.
		* Equipment pickups are replaced with chest graphics. When you pick up an item, it will flash over your head.
		* Meat strips can be found in random candles (1/256 chance)
		* Minimum damage you take is either 5, or 2x the difficulty counter
			(number to the lower right of hp) if it's higher.
		*	Soma doesn't automatically stand after unpausing
		* Fixed vanilla bug in which Soma could get trapped in the pushable crate without slide.
	* Equipment/Items:
		* All spears have Pierce effect
			* If you hit with the first frame a spear is fully extended, penetrate enemy DEF
		* Final Strike effect (adds extra damage if it will kill).
			* Broadsword, Claymore, Great sword: +50% Final strike
			* Hammer: +100% final strike
			* Warhammer: +150% final strike
			* Tallhammer: +200% final strike
			* Battle Axe: +50% final strike
			* Death's Scythe: +100% final strike.
		* Backstab effect for knives (2x damage if you attack an enemy from behind)
		* Punch weapon effect - stronger at lower HP
		* Changed Kunitsuna to a knife that gives +5 MP on hit
		* MP Refund for red souls on Pendant (2 MP), Silk Robe (5 MP), Elven Robe (10 MP)
		* Heart pendant gives double MP when you pick up hearts.
		* Cloak + 20 Max MP
		* Crimson Cloak +40 Max MP
		* Scarf: +20 Max HP
		* Red Scarf: +40 Max HP
		* Dainslef: +40 Max MP
		* Soft Landing effect on Gym Clothes, Ninja Suit, and Black cloak.
		* Samurai armor - Any weapon will cancel on landing. Nerfed DEF from 20 to 18.
		* Skull necklace has Peeping eye ability.
		* Rapier and Estoc have Slashing(Sword) type removed.
		* Scimitar has a faster attack speed
		* Ancient Belt +150% Final strike
		* Meat Strip gives 50 HP instead of 29 HP.
		* Some items have altered prices.
	* Souls:
		* Skula and Undine are always active if you have them.  Undine deactivates if you are falling too fast.
			* Better jumping out of the water with Skula (you don't lose your double jump until higher out of the water)
		* Added more possible soul combinations for red souls that can be used with Giant bat. If the enemy for a
			red and yellow soul use the same sprite, you can use the red soul if both are equipped.
		* Zombie Officer Soul actually heals you 5 hp when you jump out of knockback.
		* Succubus only heals 2 HP on hit
		* Final hitbox range of bat soul increased
		* Witch / giant ghost blue souls will destroy tiny devil projectiles when reflected.
		* Ukoback soul spawns a little further from Soma
		* Great armor soul sets STR to 150% instead of 120%. MP cost reduced from 60 to 30.
		* Medusa head soul will cancel all momentum after you un-pause. (Momentum is no longer stored)
		* Ghost Dancer and Gremlin give +8/+16 luck instead of +4/+8
		* +50% Final Strike added to the Dead Crusader Yellow Soul
		* Red Crow: +40 Max MP
		* White Dragon: +40 MaxHP
		* Soft Landing effect Gorgon soul
		* Invulnerability on hit on Ghost Dancer and on Nemesis (while it's active)
		* Dead Crusader - +50% Final Strike effect.
		* Rush souls cost 50MP instead of 30 MP.
		* Weretiger: Hold jump to gain height in midair when doing an uppercut.
		* Giant bat: More MP cost (30 MP)
		* Imp and Alastor attack more often
		* Witch soul gives 25% chance to Guard.
		* Giant Ghost protects against up to 50% of damage, using MP to block instead.
		* Undead Warrior will use a weapon at the same time when using a red soul (retaining the ability to cancel an attack with a soul)
		* Quezlcoatl - Hold jump on landing to bounce.
				* Une buff (out for longer, animation extended for extra hits)
		* Arachne can stun on hit
		* Mudman can blind certain enemies.
		* Merman shoots further, pierce effect added.
		* Early kill added to Rock Armor, Zombie Soldier, Bomber Armor, Balore, WereJaguar, and Big Golem.
		* Larger and quicker explosions for Zombie Soldier and Bomber Armor.
		* Great armor gives 200% STR.
		* Cagnazzo, Buer, and Imp get stronger over time.
		* Bone Pillar and Catoblepas get stronger over time, and you can now move while using them.
		* Headhunter increases the damage of red and blue souls based on the number of duplicates.
			* e.g. 5 bat souls will deal almost 3x the damage of 1 bat soul.
		* Basilisk gives 50% damage reduction and no flinching while you are crouched.
		* Killer fish does more damage
		* Skeleton Knight increases pierce effect.
		* Nemesis doubles backstab effect
		* Medusa Head allows horizontal movement
		* Dryad nerf to heal 4 hp per hit.
		* Giant worm heals 25% of HP that was lost from your last hit after 8 seconds.
		* Zombie - Stay poisoned while equipped (to take advantage of the STR bonus for longer)
		* Ectoplasm - Stay cursed for longer, Curses keep MP at max
		* Poison Worm - Retaliates with poison damage on hit
		* Gargoyle - Resist slash damage.
		* Winged Skeleton - Added pierce effect.
		* Mimic makes rush soul transformations quicker.
		* Giant Worm heals 33% of last hit after 8 seconds of no damage.
	* Enemies:
		* Iron Golem health is reduced.
		* Disc armor changes so hopefully the disc doesn't go flying with certain level geometry.
		* Killer fish does more damage.

Room Randomization details:
	- There are six generated areas, each contains rooms from two 'vanilla' areas
		- Each area has a special feature in the 3rd room (Stat pickup, a different shop, money, etc.)
		- Most rooms have been customized to better fit this mod.
		- When you defeat a boss, the castle is randomized, stronger enemies/ items can spawn, and a new item is added to the shop.
		- Randomized progression. There are progression soul indicators outside each area.
		- If the randomizer fails to randomize to a room not visited recently, it will randomize to a room from Castle Corridor.
	- There is a counter showing how many rooms have been cleared (at least 1 enemy killed in a room)
		- Certain enemies don't count toward room clears (respawnable enemies, really weak enemies like Une)
	- There is a limit to how many rooms each generated area can hold. If you reach the limit, you'll find a dead-end Chaos room.
	- At certain distances from the lobby, you'll find 4-way branching rooms which contain a Book of Return.
	- List of Room Modifiers (occur after 4-way branching rooms):
		- Poisonous enemies
		- Cursed enemies
		- Petrifying enemies
		- Double hp enemies
		- Winged swarm (room has 4 respawning winged skeletons, enemies changed to bats)
		- Ghost swarm (room has 4 respawning Ghosts, enemies changed to more Ghosts)
		- Red souls disabled
		- High knockback
		- Spectral Enemies (spawns invincible, transparent enemies)
			- Spectral Tiny Devil
			- Spectral Crow
		- Poisonous Hearts (Hearts apply poison and 10 damage)
		- Cursed Gold (Gold applies curse and 10 damage)
		- Low Gravity	- decreases falling speed
		- High Gravity - increases falling speed and causes hard landings at lower speeds
		- No Potion/Foods 
		- Windy Room - Alternates between wind that pushes you to the left and right.
		- Bouncy Room - Causes player to bounce upon landing with some speed.
		- Slippery Room - Decreases friction on the ground, as well as slightly in the air
		- No Air Control
		-	Hyper Enemies - Enemies update at ~137% speed
		- Slow Weapons - Weapons attack slower and don't cancel upon landing.
		- Hazards - Candles, Flames, and Destructibles are replaced with moving spiked skulls.

Known Bugs / Issues:
- Rare sprite glitches where an enemy or special object (like a moving platform) will have an all-black sprite, or using armor souls will have glitched sprites.
- If you teleport from a room with a fog layer, the background in the lobby will be wavy.

Roadmap/ Wishlist for future features:
	- More rooms!
	- (Maybe) Some type of randomization within a room (allowing for enemies / items to spawn in different locations)

Rom/ISO information:
Rom: Castlevania: Aria of Sorrow (USA)
UNMODDED MD5: E7470DF4D241F73060D14437011B90CE
UNMODDED SHA-1: ABD71FE01EBB201BCC133074DB1DD8C5253776C7
