=============================================================================
Castlevania Aria of Sorrow - Recolor fix by GoodLuckTrying
=============================================================================
All of the games' backgrounds, animations, characters, and enemies have been recolored by JonataGuitar.

Sprite fix and Bestiary restoration was made by GoodLuckTrying.

Original Rom:
Filename: Castlevania - Aria of Sorrow (USA).gba
CRC-32: 35536183
SHA-1: abd71fe01ebb201bcc133074db1dd8c5253776c7

Credits:

JonataGuitar - Artist responsible for overhauling all of the palettes for a new visual style.
LagoLunatic - creating DSVEdit