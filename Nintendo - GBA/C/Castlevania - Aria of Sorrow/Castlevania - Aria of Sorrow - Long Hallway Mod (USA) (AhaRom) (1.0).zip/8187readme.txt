What if Aria of sorrow was linear, but linear linear, kind of Final Fantasy XIII levels of linearity, 
so much so that you could call it a long hallway *wink* *wink*
 
That's what this mod tries to do, it removes all the metroidvania stuff and makes it very linear. 
You can get 100% of the map and all the objects without going too far off the path, 
all the objects are within a maximum of 2 screens, but you always return to the main path. 
It is divided into areas and at the end of each area you have a save room and a teleport to talk to Mina or buy things. 

It is a new way to enjoy the game by going through all the screens, enemies, bosses, 
objects and even though it is linear, it is always worth investigating to discover hidden objects. 

It was made with DSVania so many thanks to LagoLunatic for the amazing work.

Changed some item locations and the shop, but nothing big.
