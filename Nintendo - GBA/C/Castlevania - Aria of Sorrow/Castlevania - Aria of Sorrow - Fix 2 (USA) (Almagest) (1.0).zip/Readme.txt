﻿Castlevania - Aria of Sorrow Fix 2
----------------------------------
By Almagest
Latest update: December 15, 2014


This hack is based on Radagast's hack, Aria of Sorrow Fix. It reverts his changes taken from Symphony of the Night
(accidentally included in the optional patch), fixes the remaining mistranslations, and brings the translation a bit
closer to the Japanese version. However, the dialogue, character names, and certain changes in the localisation were kept
(such as Soma Cruz being a foreigner living in Japan rather than a native Japanese student). Cultural references, such as
Tsuchinoko, also remain unchanged.


=Installation================================================================================================================
To apply it, I recommend using Lunar IPS. It's a very simple tool: just click on “Apply IPS Patch”, then select the patch,
and then select the ROM you want to apply.

But first, make sure that you've applied the original Aria of Sorrow Fix, most specifically the aos-fix.ips file (and not
aos-sotn-fix.ips). It's important to apply it first because my patch is a complement. Likewise, it was made ONLY for the
North American release, so do NOT apply it in the European or the Japanese version; it might corrupt your ROM.


=Changes=====================================================================================================================
The changes are listed below. The descriptions I've fixed are not included in this readme.

WEAPONS:
Milican's Sword (ミリカンの石刀)-> Millican's Sword (Still unsure about its origin; it's either “Millican” or “Millikan”)
Mystletain (ミストルティン)-> Mistilteinn (Hrómundr Gripsson's sword, from Iceland)
Laevatain (レーヴァテイン)-> Laevateinn (Norse sword from the poem Fjölsvinnsmál)
Dainslef (ダインスレイブ)-> Dainsleif (King Högni's sword, from the Norse mythology)
Vjaya (ヴィジャヤ)-> Vijaya (based on the bow of Karna, from Mahabharata)
Claimh Solais (クラウ・ソラス)-> Claiomh Solais (Literally “Claidheamh Soluis”, the Irish sword of light; adapted to the
reformed spelling)
Death's Sickle (デスサイズ)-> Death's Scythe (Literally “Deathscythe”)
Gabolg (ゲイボルグ)-> Gae Bolg (The spear of Cúchulainn from the Irish mythology)
Valmanway (ヴァルマンウェ)-> Valmanwë (A reference to J.R.R. Tolkien; it combines two Quenya words he created,
ヴァル (“Val”= power), and マンウェ (“Manwë”= “blessed one”); Manwë is the king of the Valar, and lord of the winds
and airs; this alone would explain why the sword means “blessed wind”(祝福されし風), as described in Dawn of Sorrow)


ARMOR:
Pitch Black Suit (漆黒のスーツ)-> Jet Black Suit
Olrox's Suit (オルロックスーツ)-> Orlok's Suit (Count Orlok's suit, from the movie Nosferatu; “Olrox” was a mistranslation
from the Japanese Konami back in 1997, when SotN came out)
Elfin Robe (エルフのローブ)-> Elven Robe
Armor of Fire (かりゅうのよろい)-> Firewyrm Mail (Literally “Fire Dragon Armor”)
Armor of Water (すいりゅうのよろい)-> Waterwyrm Mail (Literally “Water Dragon Armor”)


ACCESSORIES:
Cape (マント)-> Mantle (Literally “Manteau”)
Crimson Cloak (真紅のマント)-> Crimson Mantle (Literally “Deep Crimson Manteau”)
Black Cloak (漆黒のマント)-> Midnight Mantle (Literally “Jet Black Manteau”; “Jet Black Mantle” wouldn't fit)
Flame Necklace (ブリーシンガメン)-> Brisingamen (Freyja's necklace)
Satan's Ring (魔王のゆびわ)-> Count's Ring (While 魔王 CAN be localised as “Satan”, it's alluding to Dracula, actually)


ITEMS:
Super Potion (エクスポーション)-> X-Potion
Anti-Venom (アンチドーテ)-> Antidote
Uncurse Potion (アンカース)-> Uncurse
CASTLE MAP 1 (しろのちず１)-> Castle Map 1
CASTLE MAP 2 (しろのちず２)-> Castle Map 2
CASTLE MAP 3 (しろのちず３)-> Castle Map 3


ENEMIES:
#05 Axe Armor/Axe Knight (アックスアーマー)-> Axe Armor
#06 Skull Archer/Bone Archer (スカルアーチャー)-> Skull Archer
#13 Zombie Soldier (ゾンビアーミー)-> Army Zombie
#14 Skeleton Knight/Bone Scimitar (スケルトンナイト)-> Skeleton Knight
#19 Rock Armor/Rock Knight (ロックアーマー)-> Rock Armor
#20 Giant Ghost/Skull Lord (ビッグゴースト)-> Giant Ghost (Literally “Big Ghost”)
#21 Winged Skeleton/Winged Guard (ウイングスケルトン)-> Winged Skeleton (Literally “Wing Skeleton”)
#25 Fleaman (のみ男)-> Flea Man (Literally “Flea Man”)
#27 Quezlcoatl (ケツァルクァトル)-> Quetzalcoatl (The Aztec god)
#32 Killer Doll/Marionette (キラードール)-> Killer Doll
#33 Zombie Officer (ゾンビソルジャー)-> Zombie Soldier
#39 Nemesis/Hunting Girl (ネメシス)-> Nemesis
#40 Kyoma Demon (キョウマ)-> Mirror Demon (I assume the translator(s) couldn't guess the kanji of きょう; キョウマ is 鏡魔)
#43 Witch/Salome (まじょ)-> Witch
#44 Curly/Khali (カーリー)-> Kali (The Hindu goddess of destruction)
#48 Dead Warrior/Valhalla Knight (デッドトルーパー)-> Dead Trooper
#53 Disc Armor/Discus Lord (ディスクアーマー)-> Disc Armor
#59 Bomber Armor/Bomb Knight (ボンバーアーマー)-> Bomber Armor
#62 Une/Thornweed (ウネ)-> Une (Word probably derived from “Alraune”)
#77 Ukoback (ユコバック)-> Ukobach (A lesser demon who keeps the cauldrons of Hell lit)
#78 Alura Une/Venus Weed (アルラ・ウネ)-> Alra Une (Apparently a play on words referencing “Une” and “Alraune”)
#79 Biphron/Lossoth (ビフロン)-> Bifron (Bifrons is a demon, Earl of Hell. It's usually called ビフロンス or ビフロンズ in Japanese,
but the “s” sound is dropped here for some reason)
#90 Beam Skeleton/Nova Skeleton (スケルトンビーマー)-> Beam Skeleton (Although “Skeleton Beamer” fits, it didn't look well in the
Soul Set and Enemy Data screens)
#100 Lubicant/Rubicant (ルビカンテ)-> Rubicante (From Dante Alighieri's Divine Comedy)
#110 Balore (バロール)-> Balor (A giant from the Irish mythology, king of the Fomorians)
#111 Belmont (ユリウス)-> Julius


ABILITY TYPE SOULS:
Grave Keeper (グレイブキーパー)-> Gravekeeper

=Credits=====================================================================================================================
Radagast