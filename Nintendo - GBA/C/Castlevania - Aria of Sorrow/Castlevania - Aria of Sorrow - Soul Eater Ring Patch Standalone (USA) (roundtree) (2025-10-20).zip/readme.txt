Aria of Sorrow
Soul Eater Ring Patch
by roundtree

This is a set of standalone patches for the Soul Eater Ring in Castlevania - Aria of Sorrow on Gameboy Advance. Since these patches are IPS format, you may use them on original Aria of Sorrow or any modded version. The patches change the price of the ring to 30k, 50k, 100k, 150k, or 200k, depending on which one you choose. Floating IPS or Lunar IPS are great choices to apply this patch.

All credit for this idea goes to Mureisky who made the Improved Drop Rates patch.
https://www.romhacking.net/hacks/8694/

A standalone patch was created in case someone would not want to apply the improved drop rates in case they are using a patch which already alters the drop rates of the items and/or souls. For one example, Maria of Sorrow does alter the drop rates of items and souls, so I wanted to change the ring price only. It gets a bit tedious using the Ripper Room/Black Panther/Gold Ring method to earn 300k, even if a faster method to earn gold has not been found.
