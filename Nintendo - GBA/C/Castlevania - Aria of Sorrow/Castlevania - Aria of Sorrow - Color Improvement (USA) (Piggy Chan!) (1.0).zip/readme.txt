This is a far-reaching color palette improvement hack for Castlevania: Aria of Sorrow, made with
the goal of enhancing the game with a more vivid color palette, which is easier on the eyes, 
yet which is nevertheless faithful to the overall presentation of the original game.

Foreground and background tiles, menus, character and monster sprites, character portraits, icons,
cut scenes and titles have all been editted by Piggy Chan!. Only color palettes have been edited.

Please apply this patch to the following ROM:

Castlevania - Aria of Sorrow (USA)