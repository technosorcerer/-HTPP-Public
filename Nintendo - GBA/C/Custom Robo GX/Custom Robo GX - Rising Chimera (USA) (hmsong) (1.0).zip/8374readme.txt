
================================================================================
Custom Robo GX -- Rising Chimera
v1.0

by hmsong
================================================================================

Custom Robo is a franchise where you get to customize your robos and make them
battle each other in various stages.  There is story too, but that's not really
important.  Custom Robo GX is a game for GBA, and because the system is far more
limited than N64, GC, and NDS, the developers had to recreate the mechanics of
the game.  And yet, it was still pretty good, considering the limits they had to
work with.

There are numerous "secrets" in the game that can be unlocked if you connect to
the J version of Custom Robo Battle Revolution (GameCube).  Rising Chimera fight
is one of those secrets.

However, pulling that off now is pretty much impossible for most people, so
things were changed around, so that Rising Chimera fight can be unlocked through
Lady P's password.  The password is "ライジング" for the J version, or "Rising"
for the hmsong's English patch version.

And yes, there are 2 patches -- one for the original J version, and one for the
hmsong's English version.

There is some sort of "bug" though -- once unlocked, then even if you don't
save, Rising Chimera fight will still be unlocked.  I'm guessing it has
something to do with "being connected to GC" or something.

BIG thanks goes to Thunderdisk.  He's the one who figured out all the mechanics
and taught me that.  I could not have done this without him.

If you have any questions, suggestions, requests, or anything else, please PM me
on Romhacking.net (click my name, then click my name next to "Forum Account",
then click "Send PM").



Applying Notes:

- There are 2 patches: (J) patch, and (Eng) patch.  Apply the (J) patch on the
  vanilla Japanese ROM, or apply the (Eng) patch AFTER applying hmsong's English
  translation patch first. If there is a translation patch other than hmsong's
  English patch, then please let me know, and I will check for compatibility.
- This is compatible with all other patches by hmsong, including his English
  translation patch (apply the English translation patch first).



Change Logs:

1.0
 - Initial release.
