
================================================================================
Custom Robo GX -- Stat Changes
v1.0

by hmsong
================================================================================

Custom Robo is a franchise where you get to customize your robos and make them
battle each other in various stages.  There is story too, but that's not really
important.  Custom Robo GX is a game for GBA, and because the system is far more
limited than N64, GC, and NDS, the developers had to recreate the mechanics of
the game.  And yet, it was still pretty good, considering the limits they had to
work with.  It was truly a shame that this game never got released outside of
Japan (nor have the fan translation), at least at the time of this writing.

Still, I felt that this game could use some love, so I decided to improve some
of the minor things to make the game experience a little better, mostly to
balance out the parts.

- Changed the displayed stats in the menu screen for most robos, guns, bombs,
  and pods, so that the displayed stats are more accurate to the actual stats
  (relative to each other, and after the changes below).

- Bodies:
  - Dash time is the same for all styles.  In vanilla, dash time was shorter for
    the Speed style, while it was longer for the Armor and Power styles,
    probably to make the dash distance the same (bad idea imho).
  - Speed style has movement speed +5%, and Armor style has movement speed -5%.
  - Shining Fighters have faster dash speed (and therefore longer dash distance)
    and slightly less dash start and recoil.
  - Aerial Beauties have lower Endurance (900), but has longer dash time (and
    therefore longer dash distance) and significantly less dash recoil.
  - Metal Grapplers have slightly more dash recoil.
  - Strike Vanishers have slightly less dash recoil.
  - Misty Mirages have higher Endurance (1100), slightly less dash start, and
    significantly less dash recoil.
  - Dodecane Turbo has lower Defense stat, so that it won't outclass all of
    Aerial Beauties and Metal Grapplers (as much).
  - The illegal robos have better stats than before (below stats are relative to
    vanilla, after the above changes), while AIRS has lower overall stats than
    before, to make things more fair between the illegal robos.  AIRS still
    outclasses them all in overall stats, although nowhere near as much as
    before.
    - Messier has dash speed +5%.
    - Devil Rex has slightly lower Defense (+5% instead of +6%), but has higher
      Endurance (1400 instead of 1300).
    - Hellfire has dash time +5% and faster dash turning speed.
    - Claymore has slightly lower dash time (+13% instead of +17%), but has less
      dash recoil and Power +5%.
    - Bigfoot has slightly lower Defense (+10% instead of +12%), but has
      movement speed +5%.
    - Demon Blaze has slightly lower dash speed (+10% instead of +12.5%), but
      has higher Endurance (1200 instead of 1100).
    - AIRS's overall stat caps around +5% (instead of +18%), except for
      Endurance, which is now 600 (instead of 800).

- Guns:
  - Basic Gun's stun time (A) increased.
  - Rayfall Gun's initial power (B) increased.
  - Hornet Buster's power (B) increased.
  - Wide Vulcan's initial homing increased.
  - Star Layer's KD damage increased.
  - Pulse Knuckle's speed (A) and power (B) increased, but distance (A) decreased.
  - Meteor Flicker's power (A) and stun time (A) decreased, but KD damage (B)
    increased.
  - Multiple Missile's power and KD damage (B) increased.
  - 5-Way Laser pushes up/down the target, instead of pushing back the target.
  - Plasma Ball's fast ball's power matches the slow ball.
  - Spread Shell's power and KD damage increased.
  - Fang Blow's speed and power (A) decreased.
  - Burning Shot's power (B) and KD damage (B) increased.
  - Blizzard Rain's initial homing increased.
  - Darkness Blow's speed, power (A), and distance (B) decreased.
  - Nikaidou Gun's power (A) and stun time (A) decreased.
  - Garapon Gun's power and stun time (A) increased.
  - ARS-G02's power (B) decreased.

- Bombs:
  - Pillar Bombs' power increased.
  - Idling Bombs' speed decreased.
  - Bound Bombs' speed increased.
  - Twin Snake Bombs' speed increased, and their explosion time decreased.
  - Geo Trap Bomb's idling distance increased.
  - Ryuujin Bomb's power and speed increased, and its explosion time decreased.
  - Camilla Bomb's power and speed decreased.
  - Gaiou Bomb's power increased.
  - Yanai Bomb's knock speed decreased, but its power and stun time increased.
  - Nikaidou Bomb's speed increased.

- Pods:
  - All of legal P, U, and D explosion pods have the same power, and all of
    legal R explosion pods have the same power (R pods have less power).
  - Feint Pods' chase-stop range got shorter.
  - Throwing Pods' chase-speed increased.
  - Camilla Pod's chase-activation range increased.

- Gunners:
  - Most Gunner's existence time was adjusted, so that the time that wasn't used
    near the end was removed.
  - The Gunner's return speed increased.
  - The slow bullet's speed increased.
  - Trap Gunner's reload speed decreased.
  - Feint Gunner's bullet range decreased, but its chase-stop range got shorter.
  - Twin Gunner's reload speed decreased.
  - 4-Way Gunner's reload speed decreased.
  - Illegal 4-Way Gunner's reload speed decreased.
  - Circulation W's reload speed increased.

- Applied the Bugfix patch, after the above changes.  See the Bugfix document
  (attached to the Bugfix patch) for detail, but it fixed the bugs with Phoenix,
  Burning Shot, Garapon Gun, Standard Bomb R, Lizard Bomb R, Lizard Bomb S,
  Submarine Bombs, Idling Bombs, Gemini Bombs, Twin Snake Bombs, Ryuujin Bomb,
  Yajyuu Pod R, and Feint Gunner.

- Other minor changes.


If you have any questions, suggestions, requests, or anything else, please PM me
on Romhacking.net (click my name, then click my name next to "Forum Account",
then click "Send PM").



Applying Notes:

- This patch is for the J version of Custom Robo GX (which is the only version
  that's available at the time of this writing).  If there is a translation
  patch in the future, please let me know, and I will check for compatibility.
- This is NOT compatible with the original Bugfix patch -- Stat Changes patch
  has its own Bugfix version applied (as addressed above).
- This is compatible with all other patches by hmsong.
