
================================================================================
Custom Robo GX -- Shops and Prizes
v1.0

by hmsong
================================================================================

Custom Robo is a franchise where you get to customize your robos and make them
battle each other in various stages.  There is story too, but that's not really
important.  Custom Robo GX is a game for GBA, and because the system is far more
limited than N64, GC, and NDS, the developers had to recreate the mechanics of
the game.  And yet, it was still pretty good, considering the limits they had to
work with.  It was truly a shame that this game never got released outside of
Japan (nor have the fan translation), at least at the time of this writing.

Having said that, there were few things that could have made the game better.
So this patch does the following:

- Increased the shop's possible items, so that you'd have access to few more
  items early (most items that the opponents in the same league have).  See the
  shop items below.  In addition, the "rarity" of items were reduced a bit, so
  that some rare items, such as Dodecane Turbo, aren't as absurdly rare (some of
  the post-game rare items were 1/500 and even 1/3000 -- they were reduced to
  1/100 and 1/200 -- you can get one of all those items from either the Password
  or the Commander Check), and all rare items with 1/8 or rarer are available by
  other means.

- Changed the prices of items, generally to make the legal item prices a bit
  more reasonable.  In addition, the prize items's prices increased, in order
  for you to sell them at higher prices if you decide to do so (which shortens
  the money farming time).

- Increased the prize money for most tournaments, although some tournaments'
  entry fees increased too -- the profit will still be higher, especially for
  the post-game tournaments.

- Changed the order of some prize items for B and A tournaments.

- Removed one possible "common" prize items from S, GX, and Dark tournaments, so
  that the prizes for those tournaments are more consistent (the missing ones
  are available by other means).

- Changed the possible prize items from Lady P's Limit Battles (see below),
  especially to prevent being locked out of those if you sold off Gatling Gun or
  all of Lightning Skyers too early (for whatever reason).

- Raised the necessary score for the "rare" items in the Dark tournaments from
  90,000 to 110,000 points (to match S and GX tournaments).  In the original
  game, winning the Dark tournament while getting below 90,000 points was
  actually more difficult, because you had to intentionally get hit and drag out
  the fight, just to lower the score.

- Changed the free items you get in the Creepy Mansion.



* = Rare Items (more * = rarer)

Shop 1 - Basic Shop
  Shotgun
  Bubble Smasher
  Energy Dagger
  Standard Bomb P
  Standard Bomb R
  Lizard Bomb R
  Standard Pod P
  Standard Pod R
  Speed Pod R

Shop 2 - Medium Shop
  Sonic Rifle
  Eagle Cutter
  Reflect Laser
  Fang Blow
  Standard Bomb U
  Standard Bomb D
  Pillar Bomb R
  Pillar Bomb D
  Gemini Bomb U
  *Gemini Bomb D
  Cross Gunner
  Seeker Pod P
  Seeker Pod R
  Sideways Pod P
  *Satellite Pod P
  Tornado Beat

Shop 3 - Master Shop
  Phoebe
  Iron Leo
  Cross Bone
  Rayfall Gun
  *Hornet Buster
  5-Way Laser
  Spread Shell
  Wall Bomb P
  Submarine Bomb U
  Submarine Bomb D
  Idling Bomb D
  Idling Bomb P
  Lizard Bomb U
  Lizard Bomb D
  *Geo Trap Bomb
  4-Way Gunner
  Yajyuu Pod P
  Yajyuu Pod R
  Feint Pod D
  Dolphin Pod P
  *Dolphin Pod R
  Throwing Pod U
  *Throwing Pod D
  **Short Slash
  Light Protector

Shop 4 - Marvellous Shop
  ***X-Ray
  Neo Metal Bear
  ***Garapon
  ***Dodecane Turbo
  Glider Wing
  Star Layer
  Pulse Knuckle
  Meteor Flicker
  ***Cross Scissors
  Submarine Bomb S
  **Lizard Bomb S
  Bound Bomb U
  Bound Bomb D
  Twin Snake Bomb U
  Twin Snake Bomb D
  **Feint Gunner
  Throwing Gunner
  Smash Gunner
  Reflect Pod R
  Satellite Pod U
  Break Tackle
  Break Tornado

Shop 5 - Dark Shop
  Dark Sam
  Messier
  Devil Rex
  ***Bigfoot
  ***Hellfire
  ***Demon Blaze
  ****A.I.R.S
  Blizzard Rain
  Darkness Blow
  Viking Axe
  Ryuujin Gun
  ***Camilla Gun
  Yanai Gun
  ***Nikaidou Gun
  ****ARS-G02
  I.Wall Bomb
  Ryuujin Bomb
  Camilla Bomb
  ***Yanai Bomb
  ***Nikaidou Bomb
  ****Supernova
  I Seeker Gunner
  I 4-Way gunner
  ***Ryuujin Pod
  Camilla Pod
  Yanai Pod
  ***Nikaidou Pod
  ****Circulation W
  ****Force Protector



Robo Limitation Lv 01~05
  Luna
  Tiger Glare
  Kunai
  Patriot
  Yoshitsune

Robo Limitation Lv 06~10
  Photon
  Pluto
  Death Metal Bear
  Falchion
  Masakado

Parts Limitation Lv 01~06
  Gatling Gun
  Wall Bomb U
  Wall Bomb D
  Twin Snake Bomb P
  Feint Gunner
  Dolphin Pod R
  Satellite Pod P

Parts Limitation Lv 07~12
  Basic Gun
  Gemini Bomb D
  Lizard Bomb S
  Strike Bomb
  Satellite Gunner
  Throwing Pod D
  Smash Pod P

Fixed Customization Lv 01~03
  Hornet Buster
  Traction Ring
  Geo Trap Bomb
  Garapon Pod

Perfect Challenge Lv 01~02
  Gaiou Gun
  Gaiou Bomb
  Gaiou Pod

Garapon Challenge
  Claymore
  Short Slash



BIG thanks goes to Thunderdisk and Tony H.  They were the ones who found the
method to change the shop items.


Applying Notes:

- This patch is for the J version of Custom Robo GX (which is the only version
  that's available at the time of this writing).  If there is a translation
  patch in the future, please let me know, and I will check for compatibility.
- All of my Custom Robo GX patches are compatible with each other.



If you have any questions, suggestions, requests, or anything else, please PM me
on Romhacking.net (click my name, then click my name next to "Forum Account",
then click "Send PM").
