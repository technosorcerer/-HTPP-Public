
================================================================================
Custom Robo GX -- English Translation
v0.2

by hmsong
================================================================================

Custom Robo is a franchise where you get to customize your robos and make them
battle each other in various stages.  There is story too, but that's not really
important.  Custom Robo GX is a game for GBA, and because the system is far more
limited than N64, GC, and NDS, the developers had to recreate the mechanics of
the game.  And yet, it was still pretty good, considering the limits they had to
work with.

This is an English translation of the game (albeit incomplete).  The following
things were translated:

- Part/stage names and the status screen details.
- Menus (tournaments, shops, maps, options, scripts, etc)
- Passwords
  - Dark Arena:
    - RaySky (the in-game hints were changed to indicate this)
  - Lady P's Lab:
    - Snowman
    - Inferno
    - Demon
    - SecretGn
    - HiddenBm
    - TerrorPd
    - ChampGn
    - X-RayPls
    - PassKR2
    - The other unimportant passwords changed to the English words
- Advices
- Game directives, to point where to go for the next plot point.
- Many other minor things.

There were many words I had to shorten in order to fit them into the given text
windows.  For exmaple, most gun names were supposed to have their unique gun
type names, such as "Cannon" or "Smasher", but I renamed them all to "Gn",
because there just wasn't enough spaces.  I also had to do that with some of the
character names (such as Shinsaku's name being shortened to Shinsak, due to 7
letters limit).

Sometimes, I had to ignore some sentences or even change the whole descriptions,
just to make the words fit (ex: part descriptions and Advice).  English isn't a
very space-friendly language.

In any case, with this patch, you are unlikely to get lost, and you'll be able
to navigate through the game relatively easily.

This is the first time I translated anything, and I only took a year of Japanese
a long time ago, so there may be many flaws.  I would really appreciate anyone
who can give me some feedbacks.  Any feedback.

Known issues:
- When you see the members in the tournament menu, the tournament type's name
  may top the tournament's name.
- Before the battle, when you preview the Holoseum (there was an 8 letter limit,
  so I couldn't spell it correctly), its name may top the word, "Holoseum".
- In the Free Battle section, a part of the word, "FreeBattle" will be topped by
  the other options.
- Some character names in script remain in Japanese, because I couldn't change
  them.

In addition to this patch, I strongly recommend you apply at least the Bugfix
patch (https://www.romhacking.net/hacks/7921/), assuming you're not using the
Stat Change patch (https://www.romhacking.net/hacks/8054/).

BIG thanks goes to Thunderdisk.  He's the one who figured out all the mechanics
and taught me that.  I could not have done this without him.

If you have any questions, suggestions, requests, or anything else, please PM me
on Romhacking.net (click my name, then click my name next to "Forum Account",
then click "Send PM").  Or send me an email at hmsong01@gmail.com.



Applying Notes:

- This patch is for the J version of Custom Robo GX.
- This is compatible with all other patches by hmsong, but whatever you do,
  apply this translation patch FIRST, then apply other patches.



Change Logs:

0.2
 - Translated the Advice section.
 - Translated the Lounge clues for the Dark Arena tournaments.
 - Translated the S/GX/Dark tournament prizes.
 - Translated "英文字" to "ABC" in the letter input screen.
 - Minor changes/fixes.

0.1
 - Initial release.
