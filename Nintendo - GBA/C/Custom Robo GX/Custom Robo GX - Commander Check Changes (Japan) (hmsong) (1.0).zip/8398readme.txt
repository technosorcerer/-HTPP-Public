
================================================================================
Custom Robo GX -- Commander Check Changes
v1.0

by hmsong
================================================================================

Custom Robo is a franchise where you get to customize your robos and make them
battle each other in various stages.  There is story too, but that's not really
important.  Custom Robo GX is a game for GBA, and because the system is far more
limited than N64, GC, and NDS, the developers had to recreate the mechanics of
the game.  And yet, it was still pretty good, considering the limits they had to
work with.

After beating the main game, you can do something called Commander Check
(PlayerCheck in hmsong's English patch) in Lady P's Lab, where if you fulfill a
certain condition, Lady P gives you a free item or unlocks a stage.  4 of those
conditions require you to play against other players, which is probably
difficult for most of you.

This patch changes those conditions to:
- Win 100 battles
- Win 200 battles
- Win 300 battles
- Have 20 different robos

However, the original game's final Commander Check ("Have 70 robos/parts"), was
changed to "Have 70 parts".

There are 2 patches -- one for the original J version, and one for the hmsong's
English version.

BIG thanks goes to Thunderdisk.  He's the one who figured out all the mechanics
and taught me that.  I could not have done this without him.

If you have any questions, suggestions, requests, or anything else, please PM me
on Romhacking.net (click my name, then click my name next to "Forum Account",
then click "Send PM").


Applying Notes:

- There are 2 patches: (J) patch, and (Eng) patch.  Apply the (J) patch on the
  vanilla Japanese ROM, or apply the (Eng) patch AFTER applying hmsong's English
  translation patch first.  If there is a translation patch other than hmsong's
  English patch, then please let me know, and I will check for compatibility.
- This is compatible with all other patches by hmsong, including his English
  translation patch (apply the English translation patch first).



Change Logs:

1.0
 - Initial release.
