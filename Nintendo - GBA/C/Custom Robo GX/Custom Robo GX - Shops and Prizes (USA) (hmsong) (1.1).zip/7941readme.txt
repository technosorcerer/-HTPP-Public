
================================================================================
Custom Robo GX -- Shops and Prizes
v1.1

by hmsong
================================================================================

Custom Robo is a franchise where you get to customize your robos and make them
battle each other in various stages.  There is story too, but that's not really
important.  Custom Robo GX is a game for GBA, and because the system is far more
limited than N64, GC, and NDS, the developers had to recreate the mechanics of
the game.  And yet, it was still pretty good, considering the limits they had to
work with.  It was truly a shame that this game never got released outside of
Japan (nor have the fan translation), at least at the time of this writing.

Having said that, there were few things that could have made the game better.
So this patch does the following:

- Increased the shop's possible items, so that you'd have access to few more
  items early (most items that the opponents in the same league have).  See the
  shop items below.  In addition, the "rarity" of items were reduced a bit, so
  that some rare items, such as Dodecane Turbo, aren't as absurdly rare (some of
  the post-game rare items were 1/500 and even 1/3000 -- they were reduced to
  1/100 and 1/200 -- you can get one of all those items from either the Password
  or the Commander Check), and all rare items with 1/8 or rarer are available by
  other means.

- Changed the prices of items, generally to make the legal item prices a bit
  more reasonable.  In addition, the prize items's prices increased, in order
  for you to sell them at higher prices if you decide to do so (which shortens
  the money farming time).

- Increased the prize money for most tournaments, although some tournaments'
  entry fees increased too -- the profit will still be higher, especially for
  the post-game tournaments.

- Changed some of the prize items for B and A tournaments (ex: tournament A-2
  gives Javelin Mk 2).

- Removed one possible "common" prize items from S, GX, and Dark tournaments, so
  that the prizes for those tournaments are more consistent (the missing ones
  are available by other means).

- Changed the possible prize items from Lady P's Limit Battles (see below),
  especially to prevent being locked out of those if you sold off Gatling Gun or
  all of Lightning Skyers too early (for whatever reason).

- Raised the necessary score for the "rare" items in the Dark tournaments from
  90,000 to 110,000 points (to match S and GX tournaments).  In the original
  game, winning the Dark tournament while getting below 90,000 points was
  actually more difficult, because you had to intentionally get hit and drag out
  the fight, just to lower the score.

- Changed the free items you get in the Creepy Mansion.


  (the number is for the rarity of 1/n)

Shop 1 - Basic Shop
	1   Shotgun
	1   Bubble Smasher
	1   Energy Dagger
	1   Standard Bomb P
	1   Standard Bomb R
	1   Lizard Bomb R
	1   Standard Pod P
	1   Standard Pod R
	1   Speed Pod R

Shop 2 - Medium Shop
	2   Sonic Rifle
	1   Eagle Cutter
	1   Reflect Laser
	1   Fang Blow
	1   Standard Bomb U
	1   Standard Bomb D
	2   Pillar Bomb R
	1   Pillar Bomb D
	1   Gemini Bomb U
	8   Gemini Bomb D
	1   Cross Gunner
	1   Seeker Pod P
	2   Seeker Pod R
	2   Sideways Pod P
	8   Satellite Pod P
	1   Tornado Beat

Shop 3 - Master Shop
	4   Phoebe
	1   Iron Leo
	1   Cross Bone
	4   Rayfall Gun
	8   Hornet Buster
	1   5-Way Laser
	1   Spread Shell
	1   Wall Bomb P
	1   Submarine Bomb U
	1   Submarine Bomb D
	4   Idling Bomb D
	1   Idling Bomb P
	1   Lizard Bomb U
	1   Lizard Bomb D
	8   Geo Trap Bomb
	1   4-Way Gunner
	1   Yajyuu Pod P
	4   Yajyuu Pod R
	4   Feint Pod D
	1   Dolphin Pod P
	8   Dolphin Pod R
	1   Throwing Pod U
	8   Throwing Pod D
	20  Short Slash
	6   Light Protector

Shop 4 - Marvellous Shop
	100 X-Ray
	1   Neo Metal Bear
	100 Garapon
	100 Dodecane Turbo
	1   Glider Wing
	1   Star Layer
	1   Pulse Knuckle
	1   Meteor Flicker
	100 Cross Scissors
	4   Submarine Bomb S
	20  Lizard Bomb S
	1   Bound Bomb U
	1   Bound Bomb D
	1   Twin Snake Bomb U
	1   Twin Snake Bomb D
	20  Feint Gunner
	1   Throwing Gunner
	1   Smash Gunner
	1   Reflect Pod R
	1   Satellite Pod U
	4   Break Tackle
	4   Break Tornado

Shop 5 - Dark Shop
	1   Dark Sam
	1   Messier
	1   Devil Rex
	100 Bigfoot
	100 Hellfire
	100 Demon Blaze
	200 A.I.R.S
	1   Blizzard Rain
	1   Darkness Blow
	1   Viking Axe
	5   Ryuujin Gun
	100 Camilla Gun
	1   Yanai Gun
	100 Nikaidou Gun
	200 ARS-G02
	1   I.Wall Bomb
	1   Ryuujin Bomb
	5   Camilla Bomb
	100 Yanai Bomb
	100 Nikaidou Bomb
	200 Supernova
	1   I Seeker Gunner
	5   I 4-Way gunner
	100 Ryuujin Pod
	1   Camilla Pod
	5   Yanai Pod
	100 Nikaidou Pod
	200 Circulation W
	200 Force Protector


Robo Limitation Lv 01~05
	Luna
	Tiger Glare
	Kunai
	Patriot
	Yoshitsune

Robo Limitation Lv 06~10
	Photon
	Pluto
	Death Metal Bear
	Falchion
	Masakado

Parts Limitation Lv 01~06
	Gatling Gun
	Wall Bomb U
	Wall Bomb D
	Twin Snake Bomb P
	Feint Gunner
	Dolphin Pod R
	Satellite Pod P

Parts Limitation Lv 07~12
	Basic Gun
	Gemini Bomb D
	Lizard Bomb S
	Strike Bomb
	Satellite Gunner
	Throwing Pod D
	Smash Pod P

Fixed Customization Lv 01~03
	Hornet Buster
	Traction Ring
	Geo Trap Bomb
	Garapon Pod

Perfect Challenge Lv 01~02
	Gaiou Gun
	Gaiou Bomb
	Gaiou Pod

Garapon Challenge
	Claymore
	Short Slash


BIG thanks goes to Thunderdisk and Tony H.  They were the ones who found the
method to change the shop items.


If you have any questions, suggestions, requests, or anything else, please PM me
on Romhacking.net (click my name, then click my name next to "Forum Account",
then click "Send PM").



Applying Notes:

- This patch is for the J version of Custom Robo GX (which is the only version
  that's available at the time of this writing).  If there is a translation
  patch in the future, please let me know, and I will check for compatibility.
- This is compatible with all patches by hmsong.
