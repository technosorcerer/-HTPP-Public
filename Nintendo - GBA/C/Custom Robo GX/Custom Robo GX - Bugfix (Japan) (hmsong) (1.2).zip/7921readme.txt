
================================================================================
Custom Robo GX -- Bugfix
v1.2

by hmsong
================================================================================

Custom Robo is a franchise where you get to customize your robos and make them
battle each other in various stages.  There is story too, but that's not really
important.  Custom Robo GX is a game for GBA, and because the system is far more
limited than N64, GC, and NDS, the developers had to recreate the mechanics of
the game.  And yet, it was still pretty good, considering the limits they had to
work with.

However, there were some minor bugs that needed to be fixed:

- Phoenix was supposed to have decrease defense stat than its "Normal"
  counterpart (it was a trade-off for its increased power stat), just like all
  other "Power" styled robos.  But instead, it had the increased defense stat in
  addition to the normal increased power stat, making it the most powerful legal
  Lightning Skyer model in the game.  So, its defense stat was decreased to
  match the other Power styled robos.

- Burning Shot was supposed to be able to land all its flame shots to the
  intended target at close range (and not stun the target for long).  But
  instead, each flame shot pushed back the target too quickly, which made most
  of the following flames miss, which essentially made this gun worthless.  So,
  its knock speed and stun time were decreased.

- Garapon Gun's A-Shot had a bug that at the tip its range before disappearing,
  it would do 0 damage.  So, that was fixed.

- Standard Bomb R and Lizard Bomb R's stun times were longer than the other
  non-S explosion types of bombs, making them unusually good normal bombs.  So,
  their stun times (and their knock speeds) were changed to match the other
  explosion types.

- Gemini Bombs, Twin Snake Bombs, and Ryuujin Bomb's stun times were shorter
  than other bombs, probably unintentionally.  So, their stun times were changed
  to match the other bombs.

- Submarine Bombs and Idling Bombs exploded prematurely, even though they
  probably were not supposed to.  So, they were changed to not do that.

- Lizard Bomb S was probably supposed to be stronger than Standard Bomb S (just
  like all other explosion types of Standard Bombs and Lizard Bombs), but it
  was not.  So, its power was increased.

- Strike Bomb's stat screen displayed that it cannot wall-phase, but it clearly
  can.  So its displayed stat was changed.

- Yajyuu Pod R's homing ability was much slower and choppier than its other
  counterparts.  So, its stats were matched to its counterparts.

- Feint Gunner's bullets were not suppose to hit the target if it was standing
  still.  However, if the Feint Gunner came from below the target (for some
  angles), the bullets would hit the target.  So, the overall bullet distance
  was decreased to prevent that.

- Illegal Smash Gunner's stat screen displayed that it can only have 1 gunner on
  the field, but it clearly can have up to 2 gunners.  So, its displayed stat
  was changed.

- Other minor fixes, mostly to fix the inconsistent knock speeds of multiple
  Bombs and Pods to their counterparts.


If you have any questions, suggestions, requests, or anything else, please PM me
on Romhacking.net (click my name, then click my name next to "Forum Account",
then click "Send PM").



Applying Notes:

- This patch is for the J version of Custom Robo GX.  If there is a translation
  patch other than hmsong's English patch, then please let me know, and I will
  check for compatibility.
- This is NOT compatible with the Stat Changes patch (it has its own bugfix).
- This is compatible with all other patches by hmsong, including his English
  patch (apply the English patch first).



Change Logs:

1.2
 - Corrected some of the text errors.

1.1
 - Added more corrections (all minor).
 - Removed the 5-Way Laser change, since that wasn't technically a bug.

1.0
 - Initial release.
