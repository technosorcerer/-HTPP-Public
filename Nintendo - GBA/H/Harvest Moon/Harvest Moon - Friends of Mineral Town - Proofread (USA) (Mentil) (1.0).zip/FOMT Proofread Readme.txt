Friends of Mineral Town Proofread v1.0

Instructions: Apply the .bps file to a ROM of 'Harvest Moon - Friends of Mineral Town (USA).gba'. Other regions are untested but aren't directly patchable. Since it's a .bps patch file (due to moving much dialog around), it'll have to be applied first.
If so desired, the optional .ips can be applied afterward for gameplay balance effects. This may work with other regions but is untested.
'More Friends of Mineral Town' uses different addresses so the patches will not work with that version.


Changes:
- Thousands of errors in spelling, grammar, and formatting have been hand-fixed, as well as other typos and mistakes.

- Names and terms have been changed to be more faithful to the original Japanese, and also match those used in the remake:

Names Changed:
Mary->Marie
Ann->Ran
Elli->Elly
Won->Huang
Gotz->Gotts
May->Mei
Barley->Mugi
Stu->Yu

Card Collector Chisato:
	Ranch Tales->Harvest Moon (the localization at the time for 'bokujou monogatari')

Racers F314:
	Eucomyth->Eucomis
	Sylvia->Silvia

Orichalc->Orichalcum
Mystrile->Mithril

Muffin Mix->Dumpling Powder (used to make Moon Dumplings)

The basic tutorials in 'Life on the Farm' shown at the beginning of the game are now labeled 'BEGINNER' instead of 'ADVANCED', whereas the ones that air later are the other way around.

(Note: Due to bugs in the 'HMMT Dumper/Inserter' tool by Pinguimbozo, which was used to make this hack, lines of exactly 28 or 29 characters were split automatically but not always necessarily. Thus, some strings were slightly modified to account for this, whereas most TV programs were left alone due to the inordinate amount of work required to reformat them. Some TV programs already used lines less than 28 characters in length and should display fine. The vast majority of character dialog was already formatted such that it did not require reformatting.)


- An untranslated line of dialog by Zack was translated to English (this modification was apparently done automatically by the HMMT tool.)




Additional changes for the optional Grind-Reduction patch:
- Below Level 0 in the mines, the stairs leading down are now automatically revealed and placed one square to the lower-right of the stairs leading up. Hidden stairs are removed.
(Note: Whatever was in the square where stairs down were placed will be unobtainable, and some rare/floor-specific items ARE able to spawn in the vicinity of stairs. Therefore, saving before entering an important level is recommended.)

- The Vacation House now costs 2.5Million Gold instead of 100Million.

- Getting the Mountain Cottage (and triggering the event where you get it) now only requires waiting 5 years instead of 50.




This hack may be modified or used as a base for other hacks, with attribution. Hack made by Mentil.