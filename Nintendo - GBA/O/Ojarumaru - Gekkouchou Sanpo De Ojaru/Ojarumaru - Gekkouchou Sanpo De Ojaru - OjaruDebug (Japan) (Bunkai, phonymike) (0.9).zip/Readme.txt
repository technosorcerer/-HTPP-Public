﻿>>> Ojarumaru - Gekkouchou Sanpo de Ojaru (Japan) for GBA - Debug mode Patch <<<

BASE ROM HASHES:
CRC32: 6043595e
MD5: fd1d6711a0cca4c15a627183aec0a854
SHA-1: 694cacc60f4b9abf82356a9dcfa127406262c8c8

RESULTED ROM HASHES:
CRC32: b37e8eb8
MD5: 5f1b4aadcd68daa55d3d35225c01b804
SHA-1: c4086dca8fc8169b94c46d6bbf4e2113ddc27ed2


GOALS:
Being able to load the debug menu persistenly, and by defult,to check all the features included.

HOW TO USE:
Go to your IPS patcher of choice, for example https://www.romhacking.net/patch/
And use this "OjaruDebug.ips" file with your vanilla gba rom.

KNOWN "BUGS": 
- Since it hijacks the normal game loading, the normal game can't be played using this rom.
- The ASM overwrite instructions (uses memory) from the debug mode to make the hijack, this means, some
debug options will not work with this rom, however you can make a save state and load it in your original rom
to reproduce those.

WARNING: This game has autosaving features, and debug rom save is cross-compatible with vanilla.
If you use a save state in the debug menu to load it in vanilla, you will be able to reproduce
all features from the debug but you will also overwrite your previous save of it (and your default game will reload after exiting that option).

CREDITS:
Debug menu discovery and patch creation by bunkai.
ASM hacking by phonymike

