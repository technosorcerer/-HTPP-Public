README
v1.2.1: January 2, 2024

Welcome to Robopon 2: 0xOS version, a ROM hack of Robopon 2: Ring version! This is an improvement hack that retunes each individual Robopon, revamps how Parts work, and makes a few other tweaks.
My intention for this hack was to increase the customization of each Robopon while also making them functionally distinct.
I aimed to make every Robopon viable for endgame use with minimal need for grinding, making it approachable for new and experienced players.

How to Download and Install:
1. Download a GameBoyAdvance emulator of your choice (I'd recommend mGBA or VisualBoyAdvance-M)
2. Find and download a ROM of Robopon 2: Ring Version; the specific name of the one I used is "0475 - Robopon 2 - Ring Version (U)(Mode7)"
   ~Create a backup of this file, since patching it replaces it!
   ~Legally, you're on your own to find one; Be careful about which links you click
3. Download LunarIPS here: https://www.romhacking.net/utilities/240
4. Open LunarIPS and choose "Apply IPS Patch"
5. Select the IPS patch included in this .zip file (Robopon 2 - 0xOS Version v1.2.1), then the game file (0475 - Robopon 2 - Ring Version (U)(Mode7))
6. Set the game to open with your emulator of choice, run it, and have fun!

Patching to New Versions:
All patches should be applied to the original Robopon 2: Ring Version, NOT an old version of this hack.
Saves from old versions function on newly patched versions, but any rebalancing via patches cannot be retroactively applied to Robopon you own.
To resume a saved game on a new patch, rename your .sav file to the filename of the newly patched ROM (Minus the .gba part).

New Features:
-Parts changed: Any ARM part may be equipped to any ARM-type Robopon, and any MOVE part may be equipped to any MOVE-type Robopon. A part's archetype (PUNCH, GUNNR, DEVIL, SEA, etc.) now defines the stats a part specializes in, and do not limit which Robopon may equip the part. Parts now have more varied attack animations and sound effects!
-All Robopon have been rebalanced against each other, both to account for this new parts system and to equalize the power level of Robopon while making each one distinct mechanically, be it through stat distribution, natural Software pool, or inherent special abilities. This also increases the incentive to strategize and make use of all of your tools.
-Revised spark chart removes many failed sparks, making many Robopon available earlier in the game. Many late-game sparks are replaced with pre-enhanced Robopon, which can reduce the need to backtrack and grind for a new team member. Every Robopon is obtainable in one playthrough without Link Spark.
-A few minor changes, like high-level Hoffman Tower shops now selling all batteries, parts, and software, tweaking some enemy teams to make the game easier or harder, making status effects more useful, and some text changes.

Known Problems:
-Some spark combinations recommended by NPCs may spark into an enhancement or something completely different
-Text may display incorrectly in rooms where the text has been changed due to how the game compresses text
-The hack is not balanced with Link Spark in mind, and using Link Spark may give you Robopon that are more powerful than intended

Changelog:
v1.2.1
- Due to frequency of crashes related to text edits, removed most of them. Apologies for NPCs lying to you for now.

v1.2
- Fixed a crash in Box Tower that resulted from a text editing error
- Fixed the included Spark Chart to align properly with order-based combinations
- Altered stats documentation to record HP and EP at the Max Level instead of Level 99
- Equalized elemental resistances such that Robopon with naturally high WIL did not also have high resistances across the board
- Replaced Ruby with Meddy in the pool of Robopon in Galileo Windmill
- Increased the levels of Emilio, Maskman, and Rena/Utada
- Decreased the levels of Xardon, Zero, and Zero Sr.
- Rebalanced various Robopon to fall more in line with new standards, with a focus on powering up software skills

v1.1
- Altered some text relating to part descriptions and some battery combos to be consistent with this hack's changes
- Replaced Xardon's Platnum and Prime with SSTBot and SST1337 respectively
- Replaced Zero's Curser with Trigon
- Lowered the levels of Galileo Windmill's wild Robopon
- Swapped the wild locations of Wobble, who is now in the UFO, and Timzup, who is now in Nenji Valley
- Made the combination of Normal and Alkali batteries spark Sun-02 instead of Sunny 
- Fixed an issue where Bulbot and Gear learn only one of their three skills at level 99
- Rebalanced the following Robopon:
  ~Disco Q now has more WILL and HP
  ~Chef-Fe now learns GaiaFist instead of AllClear
  ~The Hexbot line's EP has been increased, and Curser now learns Kisses instead of ViruStrk
  ~Gtacbot's max level has been decreased, and its growths have increased to compensate
  ~The Viper2 line now learns Rust skills, and learns Hack skills earlier
  ~NexTrik's ATK has been increased
  ~The Ping line's ATK has been decreased
  ~Platnum has much higher base stats in exchange for 0 growths in all stats except HP and EP
  ~Prime now has more SPD
  ~Bulbot and Gear have more HP and EP
  ~Nebulus's max level has been decreased, and it no longer reaches 255 in every stat
v1.0.1
- Fixed an error where one spark combo for Zap sparks BigZap instead
v1.0
- Initial Release

Acknowledgements:
-Lymia (GameFAQs, lymiahugs@gmail.com), for their Robopon 2 Stat Dump
-Kactuar (Reddit u/-Kactuar), for their work on the Nightmare 2 modules used to create this hack
-BoopRaptor (Reddit u/BoopRaptor), for the first Robopon 2 hack (Big Rebalance Edition) that inspired mine, and for helping me test this hack
-EonKayoh (Reddit u/EonKayoh), for moderating the r/Robopon subreddit, investigating the game's meta, and keeping this community alive

Contact me on my social medias for any questions or comments about this hack! All feedback is appreciated!
Reddit : u/GodCloakBurmy
Twitter: @GodCloakBurmy
Discord: GodCloakBurmy