Sacred Cards MC for RoD

This patch simply replaces the player character of Reshef of Destruction with the player character from Sacred Cards. I've also added an alternate version of the patch that gives him a black outline. Should be compatible with anything that doesn't edit the same character.

ROM / ISO Information:
Yu-Gi-Oh! - Reshef of Destruction (USA)
MD5: c06decdf51468503434dcb5e7bbdcca5
CRC32:09e0c559