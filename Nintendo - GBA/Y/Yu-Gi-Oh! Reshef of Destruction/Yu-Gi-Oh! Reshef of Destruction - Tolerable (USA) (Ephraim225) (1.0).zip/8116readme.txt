Tolerable Reshef Patch
for Yu-Gi-Oh! Reshef of Destruction (USA)
by Ephraim225

Reshef of Destruction became infamous for numerous, numerous frustrations throughout its gameplay. This patch makes numerous balance and quality of life changes to the vanilla game, and also introduces a few new cards as well as balancing existing cards. The following changes are made:

-Selling a card gives you 50% of the card's price
-Cards can be sold even at 1 copy remaining
-Card prices never change
-Life points always start at 8000 for the player
-Life points always start at 8000 for all opponents outside the Hall of Eternity
-Duelist level no longer does anything
-Permanent effects show text only once per card
-The permanent effect cursor no longer has to take 2 seconds of your time to scan the board
-New Deck Cost formula implemented with adjustments

And the following changes to the cards themselves:
-Dark-Eys Illusionist, Nightmare Penguin, Barox, Dark Chimera, King of Yamimakai, Castle of Dark Illusions, Reaper of the Cards, and Metal Guardian now have accurate TCG stats
-Exodia and the Petit Moth cards now have orange card colors
-Fire Reaper, Ooguchi, Rainbow Flower, Jinzo #7, and Queen's Double can now attack directly
-Infinite Dismissal was given Negate Attack's graphic
-Torrential Tribute was given Mirror Force's graphic
-Former Ritual Monsters are no longer Divine attribute
-Ritual Summoning no longer possible. The Ritual spells were replaced with three brand new cards.

Note that a second patch is included that applies ONLY quality of life changes, without the changes to the cards or card effects. This is for players who want to keep the original game experience pure, but without the cursor lag as mentioned.