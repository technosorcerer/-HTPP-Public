**************************
Created by Kartal
karsahyena@protonmail.com
**************************

Yu-Gi-Oh! The Sacred Cards Kartal Rebalance is a mod created by Kartal (karsahyena@protonmail.com).

The rebalance mod was created with full respect to Konami, Kazuki Takahashi, Nintendo.
The rebalance mod was tested by Ephraim225.
Special thanks for the information uncovered about Reshef on DataCrystal. I could use it as a base for getting started. ...and to yugipedia.com for their card list (so that I didn't have to make one myself) and DM4 equip spell compatibility lists.

Features:

- New decks for every duelist
- New starter deck
- Wider variety of cards in starting trunk
	The Winged Dragon of Ra in starting trunk because it's unobtainable normally
- Rebalance of card costs:
	Monsters with DEF higher than ATK have their costs reduced in proportion to the difference between the too.
	Monster types which don't benefit from any field (fairy, reptile, machine, pyro) have -30% cost.
	No-tribute monsters with at least 1650 ATK and 1-tribute monsters with at least 2250 ATK have increased cost.
	Some useful effect monsters have increased cost.
	Magic and trap costs adjusted based on usefulness.
- Card changes:
	PaniK's monsters have their weird ATK/DEF (e.g. 920/1930) values restorted
	Direct damage magic damage values adjusted to resemble the original values from DM1 (200/500/800/1000/2000) - no 5000LP damage Tremendous Fire, sorry.
- New limited/semi-limited list:
	Exodia and Destiny Board pieces were unlimited.
	Some limited magics were semi-limited.
	Many effect monsters were added.

New Limited
	337	Raigeki
	342	Dian Keto the Cure Master
	781	Brain Control
	784	Change of Heart
	861	Ancient Lamp
	897	Torrential Tribute

New Semi-Limited
	72	Cocoon of Evolution
	73	Kairyu-Shin
	83	Castle of Dark Illusions
	195	Doron
	224	Trap Master
	336	Dark Hole
	348	Swords of Revealing Light
	661	Crush Card
	672	Harpie's Feather Duster
	731	Relinquished
	789	Pot of Greed
	810	Revival Jam
	894	Heavy Storm
	895	Monster Reborn

Patching:
The next two sections tell you which ROM you need to patch and where to find a patcher program.
IMPORTANT: You need the EU ROM, not the American one!!!

The rest of the information in this txt is my hacking notes.

**************************
Base ROM
**************************

Use this ROM as a base:
Yu-Gi-Oh! - The Sacred Cards (Europe) (En,Fr,De,Es,It).gba

Hash

Database match: Yu-Gi-Oh! - The Sacred Cards (Europe) (En,Fr,De,Es,It)
Database: No-Intro: Game Boy Advance (v. 20210227-023848)
File/ROM SHA-1: 9A23AD34F67AC1F1343B7009F11AC95C77B782EF
File/ROM CRC32: D19DB37C

(confirm your ROM here: http://www.romhacking.net/hash/) 

**************************
Applying the Patch
**************************

The patch was created with Lunar IPS.
https://www.romhacking.net/utilities/240/

Alternatively, use this online patcher:
https://www.romhacking.net/patch/

**************************
Data Crystal ROM Map
**************************

Special thanks for the information uncovered about Reshef. I could use it as a base for getting started.

https://datacrystal.romhacking.net/wiki/Yu-Gi-Oh!_The_Sacred_Cards:ROM_map
0B53F8	limited_cards_array
0B5410	semi_limited_cards_array
https://datacrystal.romhacking.net/wiki/Yu-Gi-Oh!_Reshef_of_Destruction:ROM_map
https://yugipedia.com/wiki/List_of_Yu-Gi-Oh!_The_Sacred_Cards_cards
http://forums.warsworldnews.com/viewtopic.php?f=11&t=13599&p=397062#p397062

**************************
General Notes
**************************

02020C3C	Deck Capacity
02020C40	Duelist Level
0202347C	Current LP
EE5320	free space start

Tristan
E151BC	pointer to "Wroooarrr! It's a duel!" (52 2B E1 08)

EE4FD0	Fake Trap description pointer

**************************
Enemy Data
**************************
28 long
+0	Enemy ID
+2	Field ID
	00 - None
	01 - Forest
	02 - Wasteland
	03 - Mountain
	04 - Meadow (Sogen)
	05 - Sea (Umi)
	06 - Darkness (Yami)
+4	Deck
+8	Normal Drop
+C	To Shop Drop
+10	Lv1 Ante Drop
+14	Player LP
+16	Enemy LP
+18	Deck Capacity increase
+1C	Min Domino
+1E	Max Domino
+20	? (adds more domino)
+24	Music

note: there's 200 entries and 200 decks generated, not even quarter are used

-

(with Tristan Deck)
0B5CA8	Tristan

(with Clock Tower Square Deck)
0B58E8	Clock Tower Square - Middle - Girl
0B5938	Clock Tower Square - Right - Purple Boy
0B5960	Clock Tower Square - Right - Blue Boy
0B59B0	Clock Tower Square - RightDown - Yellow Hair
0B59D8	Clock Tower Square - Down - Orange Jacket
0B5A00	Clock Tower Square - LeftDown - Green Jacket
0B5A28	Clock Tower Square - Left - Gray Hair
0B5BE0	Clock Tower Square - Game Shop - Grey Jacket
0B5CF8	Art - Man

(with Alley Zombie Deck)
0B5B18	Clock Tower Square - Alley - Bonz Guard Down
0B5B40	Clock Tower Square - Alley - Bonz Guard Middle
0B5D98	Clock Tower Square - Alley - Bonz Guard Up

(with Bonz Deck)
0B5780	Boss - Bonz (Rematches)
0B58C0	Boss - Bonz
0B5D70	Boss - Bonz (After Seeker)
0B6090	Boss - Bonz (Ghouls Chapter)

(with Espa Brother Deck)
0B5AC8	Clock Tower Square - Street - Espa Brother 1
0B5AF0	Clock Tower Square - Street - Espa Brother 2

(with Espa Roba Deck)
0B56E0	Boss - Espa Roba (Rematches)
0B5820	Boss - Espa Roba

(with KC Deck) (Roland to custom deck)
0B5AA0	Clock Tower Square - KC - Roland
0B6338	Clock Tower Square - KC - Duel Robot

(with Rex Raptor Deck)
0B5730	Boss - Rex Raptor (Rematches)
0B5870	Boss - Rex Raptor

(with Seeker Deck)
0B5690	Duplicate - Seeker Deck
0B5988	Boss - Seeker

(with Joey Deck)
0B54D8	Clock Tower Square - Grampa Shop - Joey
0B5910	Aquarium - End - Joey

(with Bakura Deck)
0B5578	Art - Bakura

(with Shop Man Deck)
0B5FA0	Shop - Man

(with Park Deck)
0B5DC0	Park - NW - White Hair
0B5DE8	Park - NW - Yellow Hair
0B5E10	Park - NE - Green Clothes
0B5E38	Park - NW - Afro
0B5E60	Park - NE - Orange Woman
0B5E88	Park - Entrance - Yellow Hair
0B5EB0	(Park Deck)

(with Weevil Guard Deck)
0B5A50	Park - SE - Weevil Guard Left
0B5A78	Park - SE - Weevil Guard Middle
0B5D20	Park - SE - Weevil Guard Right

(with Weevil Underwood Deck)
0B5708	Boss - Weevil (Ghouls Chapter)
0B5848	Boss - Weevil
0B5D48	Boss - Weevil (Rematches)

(with Arkana Deck)
0B56B8	Boss - Arkana

(with Bridge Deck)
0B5EB0	Bridge - Entrance - Orange Jacket
0B5ED8	Bridge - Entrance - Kaiba Fan Girl
0B5F00	Bridge - Left - Green Guy
0B5F28	Bridge - Right - Purple Hair

(with Strings Deck)
0B5668	Boss - Strings

(with Building Deck)
0B5CD0	Building - 1F - Man
0B5FF0	Building - Outside - Man
0B6018	Building - Outside - Kaiba Fan Girl
0B6360	Building - 2F - Yellow Jacket Man
0B6388	Building - 2F - Businessman
0B63B0	Building - 2F - Businesswoman
0B63D8	Building - 2F - Miniskirt Woman
0B6400	Building - 3F - Guy
0B6428	Building - 3F - Purple Jacket Man

(with Mai Deck)
0B5550	Mai Valentine

(with Aquarium Deck)
0B5B68	Aquarium - Outside - Guy
0B5B90	Aquarium - Whale - Etsuko
0B5F50	Aquarium - Whale - Takeshi
0B5F78	Aquarium - End - Girl

(with Mako Deck)
0B5758	Boss - Mako Tsunami (Rematch Aquarium)
0B5898	Boss - Mako Tsunami
0B6298	Boss - Mako Tsunami (Rematch Pier)

(with Ghoul Deck)
0B6040	*Ghoul - Clock Tower Square - Espa Alley
0B6068	*Ghoul - Art
0B60E0	Ghoul - Clock Tower Square - Cemetery
0B6108	*Ghoul - Bridge - Entrance
0B6130	Ghoul - Bridge - End
0B6158	*Ghoul - Aquarium - Whale
0B6180	Ghoul - Aquarium - End
0B61A8	Ghoul - Park - Entrance
0B61D0	Ghoul - Park - NW
0B61F8	Ghoul - Park - NE

(with Bandit Keith Deck)
0B60B8	Boss - Bandit Keith (Park)
0B6248	Boss - Bandit Keith (Pier)
0B62C0	Boss - Bandit Keith (Rematches)

(with Lumis Deck)
0B5618	Boss - Lumis

(with Umbra Deck)
0B5640	Boss - Umbra

(with Evil Joey Deck)
0B57D0	Boss - Evil Joey

(with Pier Deck)
0B62E8	Pier - Blue Hair
0B6310	Pier - Orange Hair

(with Mokuba Deck)
0B6220	Mokuba

(with Magnum Deck)
0B6270	Jean-Claude Magnum

(with Ishizu Deck)
0B5528	Boss - Ishizu Ishtar

(with Kaiba Deck)
0B54B0	Boss - Seto Kaiba

(with Odion Deck)
0B55A0	Boss - Odion

(with Yami Yugi Deck)
0B5488	Boss - Yami Yugi

(with Yami Marik Deck)
0B57F8	Final Boss - Yami Marik

-

0B5438	
0B5460	
0B5488	Boss - Yami Yugi
0B54B0	Boss - Seto Kaiba
0B54D8	Clock Tower Square - Grampa Shop - Joey
0B5500	
0B5528	Boss - Ishizu Ishtar
0B5550	Mai Valentine
0B5578	Art - Bakura
0B55A0	Boss - Odion
0B55C8	
0B55F0	
0B5618	Boss - Lumis
0B5640	Boss - Umbra
0B5668	Boss - Strings
0B5690	Duplicate - Seeker Deck
0B56B8	Boss - Arkana
0B56E0	Boss - Espa Roba (Rematches)
0B5708	Boss - Weevil (Ghouls Chapter)
0B5730	Boss - Rex Raptor (Rematches)
0B5758	Boss - Mako Tsunami (Rematch Aquarium)
0B5780	Boss - Bonz (Rematches)
0B57A8		unused Bakura
0B57D0	Boss - Evil Joey
0B57F8	Final Boss - Yami Marik
0B5820	Boss - Espa Roba
0B5848	Boss - Weevil
0B5870	Boss - Rex Raptor
0B5898	Boss - Mako Tsunami
0B58C0	Boss - Bonz
0B58E8	Clock Tower Square - Middle - Girl
0B5910	Aquarium - End - Joey
0B5938	Clock Tower Square - Right - Purple Boy
0B5960	Clock Tower Square - Right - Blue Boy
0B5988	Boss - Seeker
0B59B0	Clock Tower Square - RightDown - Yellow Hair
0B59D8	Clock Tower Square - Down - Orange Jacket
0B5A00	Clock Tower Square - LeftDown - Green Jacket
0B5A28	Clock Tower Square - Left - Gray Hair
0B5A50	Park - SE - Weevil Guard Left
0B5A78	Park - SE - Weevil Guard Middle
0B5AA0	Clock Tower Square - KC - Roland
0B5AC8	Clock Tower Square - Street - Espa Brother 1
0B5AF0	Clock Tower Square - Street - Espa Brother 2
0B5B18	Clock Tower Square - Alley - Bonz Guard Down
0B5B40	Clock Tower Square - Alley - Bonz Guard Middle
0B5B68	Aquarium - Outside - Guy
0B5B90	Aquarium - Whale - Etsuko
0B5BB8	
0B5BE0	Clock Tower Square - Game Shop - Grey Jacket
0B5C08
0B5C30	
0B5C58
0B5C80
0B5CA8	Tristan
0B5CD0	Building - 1F - Man
0B5CF8	Art - Man
0B5D20	Park - SE - Weevil Guard Right
0B5D48	Boss - Weevil (Rematches)
0B5D70	Boss - Bonz (After Seeker)
0B5D98	Clock Tower Square - Alley - Bonz Guard Up
0B5DC0	Park - NW - White Hair
0B5DE8	Park - NW - Yellow Hair
0B5E10	Park - NE - Green Clothes
0B5E38	Park - NW - Afro
0B5E60	Park - NE - Orange Woman
0B5E88	Park - Entrance - Yellow Hair
0B5EB0	Bridge - Entrance - Orange Jacket
0B5ED8	Bridge - Entrance - Kaiba Fan Girl
0B5F00	Bridge - Left - Green Guy
0B5F28	Bridge - Right - Purple Hair
0B5F50	Aquarium - Whale - Takeshi
0B5F78	Aquarium - End - Girl
0B5FA0	Shop - Man
0B5FC8	
0B5FF0	Building - Outside - Man
0B6018	Building - Outside - Kaiba Fan Girl
0B6040	*Ghoul - Clock Tower Square - Espa Alley
0B6068	*Ghoul - Art
0B6090	Boss - Bonz (Ghouls Chapter)
0B60B8	Boss - Bandit Keith (Park)
0B60E0	Ghoul - Clock Tower Square - Cemetery
0B6108	*Ghoul - Bridge - Entrance
0B6130	Ghoul - Bridge - End
0B6158	*Ghoul - Aquarium - Whale
0B6180	Ghoul - Aquarium - End
0B61A8	Ghoul - Park - Entrance
0B61D0	Ghoul - Park - NW
0B61F8	Ghoul - Park - NE
0B6220	Mokuba
0B6248	Boss - Bandit Keith (Pier)
0B6270	Jean-Claude Magnum
0B6298	Boss - Mako Tsunami (Rematch Pier)
0B62C0	Boss - Bandit Keith (Rematches)
0B62E8	Pier - Blue Hair
0B6310	Pier - Orange Hair
0B6338	Clock Tower Square - KC - Duel Robot
0B6360	Building - 2F - Yellow Jacket Man
0B6388	Building - 2F - Businessman
0B63B0	Building - 2F - Businesswoman
0B63D8	Building - 2F - Miniskirt Woman
0B6400	Building - 3F - Guy
0B6428	Building - 3F - Purple Jacket Man
0B6450	
0B6478	
0B64A0	
0B64C8	
0B64F0	
0B6518	
0B6540	
0B6568	
0B6590	
0B65B8	
0B65E0	
0B6608	
0B6630	
0B6658	
0B6680	
0B66A8	
0B66D0	
0B66F8	
0B6720	
0B6748	
0B6770	
0B6798	
0B67C0	
0B67E8	
0B6810	
0B6838	
0B6860	
0B6888	
0B68B0	
0B68D8	
0B6900

0B7350	(last entry)

**************************
Decks
**************************
0F09A4	Decks, 0x50 long entries (card IDs)
note: 200 decks + starter deck

0F09A4	(Null)
0F09F4		unused Yugi deck
0F0A44	Yami Yugi Deck
0F0A94	Kaiba Deck
0F0AE4	Joey Deck
0F0B34		unused Ra
0F0B84	Ishizu Deck
0F0BD4	Mai Deck
0F0C24	Bakura Deck
0F0C74	Odion Deck
0F0CC4		unused weak monsters
0F0D14		unused headless Exodia
0F0D64	Lumis Deck
0F0DB4	Umbra Deck
0F0E04	Strings Deck
0F0E54	Seeker Deck
0F0EA4	Arkana Deck
0F0EF4	Espa Roba Deck
0F0F44	Weevil Underwood Deck
0F0F94	Rex Raptor Deck
0F0FE4	Mako Deck
0F1034	Bonz Deck
0F1084		unused Bakura deck
0F10D4	Evil Joey Deck
0F1124	Yami Marik Deck
0F1174	Tristan Deck
0F11C4	Alley Zombie Deck
0F1214	Clock Tower Square Deck
0F1264	Espa Brother Deck
0F12B4	KC Deck (Roland, Duel Robot)
0F1304	Shop Man Deck (duplicate of Clock Tower Square Deck)
0F13A4	Weevil Guard Deck
0F13F4	Park Deck
0F1444	Bridge Deck
0F1494	Aquarium Deck
0F14E4	Building Deck
0F1534	Pier Deck
0F1584		unused weak water monsters
0F15D4		unused Weevil deck
0F1624		unused (same as previous)
0F1674	Ghoul Deck
0F16C4		unused not as weak monsters
0F1714	Bandit Keith Deck
0F1764	Mokuba Deck
0F17B4	Magnum Deck
0F1804		unused weak water monsters 2
0F1854		(same as previous)
0F18A4		unused stronger Strings
0F18F4		unused 3x cards 01-0E
0F1944		unused 3x cards 0E-1B
0F1994		unused 3x cards 1B-28
0F19E4		unused 3x cards 29-36
0F1A34		unused 3x cards 36-43
0F1A84		unused weakest monsters
* every following deck is the same (repeats 145 times)

0F4824	Starter Deck

**************************
Drop Lists
**************************

4 byte long,
+0	Card ID
+2	Drop Chance (cumulative, range of 0000 - 07FF)

0B7A74	(Beaver Warrior)
0B7A7C	Yami Yugi Drop (Dark Magician)
0B7A84	Kaiba Drop (Blue-Eyes Ultimate Dragon)
0B7A8C	Joey Drop
0B7B0C	Ishizu Drop (Cosmo Queen)
0B7B14	Mai Drop (Harpie Lady) (changed to Cyber Harpie)
0B7B1C	Bakura Drop (Portrait Secret) (changed to Dark Necrofear)
0B7B24	Odion Drop (Mystical Beast Serket)
0B7B34	Lumis Drop (Masked Beast Des Gardius)
0B7B3C	Umbra Drop  (The Masked Beast)
0B7B44	Strings Drop (Revival Jam)
0B7B4C	Seeker Drop (Gear Golem the Moving Fortress)
0B7B5C	Espa Roba Drop (Jinzo)
0B7B54	Arkana Drop (Dark Magician (red))
0B7B64	Weevil Drop (Insect Queen)
0B7B6C	Rex Raptor Drop (Sword Arm of Dragon)
0B7B74	Mako Drop (The Legendary Fisherman)
0B7B7C	Bonz Drop (Pumpking)
0B7B88	Evil Joey Drop (Red-Eyes B. Dragon) (changed to Meteor B. Dragon)
0B7B90	Yami Marik Drop (nothing)
0B7B94	Espa Roba Rematch Drop
0B7BF0	Weevil Rematch Drop
0B7D38	Rex Raptor Rematch Drop
0B7D60	Mako Rematch Drop
0B7D98	Bonz Rematch Drop
0B7DB4	Tristan Drop
0B7E68	Alley Zombie Drop
0B7E78	Clock Tower Drop (except Art - Man)
0B7F88	Espa Brother Drop
0B7FD8	KC Drop

0B803C	Shop Man Drop (identical to Clocktower Drop)

0B838C	Weevil Guard Drop

0B84B8	Park Drop
0B8548	Bridge Drop
0B85D8	Aquarium Drop
0B8670	Building Drop
0B8708	Pier Drop
0B87A0	Art - Man Drop (identical to Clocktower Drop)
0B88B8	Ghoul Drop
0B8948	Keith Park Drop (Barrel Dragon)
0B8950	Mokuba Drop (Invitation to a Dark Sleep)
0B8958	Keith Pier Drop (Zera The Mant)
0B8960	Magnum Drop (Prisman)
0B8968	Keith Rematch Drop
0B89A8	LV1 Drop

-

To Shop Drop
same structure, but chance is 0000 - 752F
0C72C0	To Shop Drop (has 886 cards)

**************************
Custom
**************************

EE5320	Alley Zombie Custom Drop (LV1 drop too) (Eternal Rest)
EE5328	KC Deck Roland Custom Drop (LV1 drop too) (F.G.D.)
EE5330	KC Deck New Roland
EE5380	Park Deck New Custom Female
EE53D0	Park Deck New Custom Beast
EE5420	Park Custom Beast Drop (LV1 drop too) (Sleeping Lion)
EE5428	Clock Tower Drop New (+ Shop - Man, Art - Man)
EE5470	Park Drop New (+ Weevil Guard Drop)
EE54AC	Tristan duel text
EE5560	Tristan Drop New
EE559C	LV1 Custom Drop Tristan
EE55C0	
EE55CC	Bridge Drop New
EE55EC	Custom Kaiba Fan Girl Deck
EE563C	Custom Kaiba Fan Girl Drop (Crush Card) (LV1 too)
EE5644	Bonz Drop New
EE569C	LV1 Custom Drop Bonz
EE56B4	Espa Family Custom Drop
EE56F4	LV1 Custom Drop Espa Family
EE570C	Rex Raptor Rematch Drop New
EE5768	LV1 Custom Drop Rex
EE577C	LV1 Custom Drop Female
EE5794	Limited New
EE57A4	Semi-Limited New
EE57C4	

EE5890	Park Female Custom Drop
EE58A8	Weevil Rematch Drop New
EE58FC	LV1 Custom Drop Weevil
EE5928	LV1 Custom Drop Mai (Amazon Archers)
EE5930	Building Drop New
EE5974	Aquarium Drop New
EE59A8	Aquarium Deck New Custom Etsuko
EE59F8	Aquarium Etsuko Custom Drop
EE5A1C	Aquarium Deck New Custom Takeshi
EE5A6C	Aquarium Takeshi Custom Drop
EE5A90	Joey Deck New Custom Aquarium
EE5AE0	Mako Rematch Drop New
EE5B58	LV1 Custom Drop Mako
EE5B7C	Ghoul Drop New
EE5BD8	Ghoul Deck New Custom Invigoration
EE5C28	Ghoul Deck New Custom Art
EE5C78	Ghoul Deck New Custom Bridge
EE5CC8	Ghoul Deck New Custom Aquarium
EE5D18	Ghoul Deck New Custom Park
EE5D68	Pier Drop New
EE5D94	Keith Rematch Drop New
EE5DF8	LV1 Custom Drop Keith
EE5E10	Mokuba Custom Drop New (Master of Dragon Soldier) (LV1 too)
EE5E18	Ishizu Drop New
EE5E2C	LV1 Custom Drop Ishizu
EE5E44	Yami Marik Custom Drop (Fake Trap) (LV1 too)
EE5E4C	Fake Trap credits
EE602C

EE6220	Bandit Keith Deck New Custom Park
EE6270	Bonz Deck New Custom Ghouls
EE62C0	Weevil Deck New Custom Ghouls
EE6310	Bandit Keith Deck New Custom Pier
EE6360	Bandit Keith Deck New Custom Rematches
EE63B0	Mako Deck New Custom Pier
EE6400	

**************************
Starting Trunk
**************************

086F1C	(amount for each card, 1 byte stating from Null card, 385 long)
0B4790	Deck Capacity Array

**************************
Limited Lists
**************************

Lists of card IDs, ending in 00 00.

https://datacrystal.romhacking.net/wiki/Yu-Gi-Oh!_The_Sacred_Cards:ROM_map
0B53F8	limited_cards_array (pointer: 015E3C)
0B5410	semi_limited_cards_array (pointer: 015E58)

EE5794	Limited New
EE57A4	Semi-Limited New

New Limited
337	Raigeki
342	Dian Keto the Cure Master
781	Brain Control
784	Change of Heart
861	Ancient Lamp
897	Torrential Tribute

New Semi-Limited
72	Cocoon of Evolution
73	Kairyu-Shin
83	Castle of Dark Illusions
195	Doron
224	Trap Master
336	Dark Hole
348	Swords of Revealing Light
661	Crush Card
672	Harpie's Feather Duster
731	Relinquished
789	Pot of Greed
810	Revival Jam
894	Heavy Storm
895	Monster Reborn

(unlimit exodia, destiny board)

**************************
Card Stats
**************************

0887C4	Card DEF, 2 long entries
088ECE	Card ATK, 2 long entries
0895D8	Card Costs, 4 long entries
08A3EC	Card Summon, 1 long entries
08A771	Card Level, 1 long entries
08AAF6	Card Type, 1 long entries
08AE7B	Card Frame, 1 long entries
	00 - Normal
	01 - Effect
	02 - Fusion
	03 - Spell
	04 - Trap
	05 - Ritual
	06 - Obelisk
	07 - Osiris
	08 - Ra
08B200	Monster Effect, 1 long entries
	01 - Destroy 1 trap (Reaper of the Cards)
	02 - Restore 1000 LP (Fairy's Gift)
	03 - Sacrifice: Steal enemy (Relinquished)
	04 - Sacrifice: Steal enemy + Power-Up x2 self (Thousand-Eyes Restrict)
	05 - Draw 1 card (Skelengel)
	06 - Power-Up Harpie's Pet Dragon (Harpie Lady)
	07 - Power-Up x2 Harpie's Pet Dragon (Harpie Lady Sisters)
	08 - Transform Baby Dragon, Dark Magician (Time Wizard)
	09 - Field: Darkness + Facedown own (Castle of Dark Illusions)
	0A - Power-Up Blue-Eyes (Mystical Elf)
	0B - Field: Wasteland (Curse of Dragon)
	0C - Destroy enemy dinosaurs (Flame Swordsman)
	0D - Field: Arena (no field?) (Giant Soldier of Stone)
	0E - Destroy enemy fire types (Battle Ox)
	0F - Power-Up Dungeon Worm (Monster Tamer)
	10 - Power-Up Armored Zombie, Dragon Zombie, Clown Zombie (Pumpking the King of Ghosts)
	11 - Power-Down all enemies (Mammoth Graveyard)
	12 - Sacrifice monsters for damage (Catapult Turtle)
	13 - Sacrifice: Draw 1 card (Goddess of Whim)
	14 - Field: Mountain (Spirit of the Mountain)
	15 - Destroy enemy dragons (Dragon Seeker)
	16 - Set Acid Trap Hole (Trap Master)
	17 - Sacrifice: destroy 1 enemy (Fiend's Hand)
	18 - Disable all enemies (Illusionist Faceless Mage)
	19 - Disable 1 enemy (Electric Lizard)
	1A - Power-Up self if Dark Magician in GY (Dark Magician Girl)
	1B - Power-Up self for own plants (Wodan the Resident of the Forest)
	1C - Power-Up M-Warrior #2 (M-Warrior #1)
	1D - Power-up M-Warrior #1 (M-Warrior #2)
	1E - Disable and Power-Down 1 enemy (Red Archery Girl)
	1F - Restore 500 LP (Lady of Faith)
	20 - 50 LP direct damage (Fire Reaper)
	21 - Field: Sea (Kairyu-Shin)
	22 - Power-Up 500- ATK monsters (Gyakutenno Megami)
	23 - Reveal enemy hand (Monster Eye)
	24 - Clone self (Doron)
	25 - Power-Up Lava Battleguard (Swamp Battleguard)
	26 - Power-Up Swamp Battleguard (Lava Battleguard)
	27 - Field: Forest (Trent)
	28 - Power-Up self for own Labyrinth Walls (Labyrinth Tank)
	29 - Summon Boo Koo (Spirit of the Books)
	2A - Power-Up own for 1000 LP (Hourglass of Life)
	2B - Sacrifice: destroy all (Beastking of the Swamps)
	2C - Disable all (Nemuriko)
	2D - Summon Frog the Jam (Toad Master)
	2E - Power-Up own light, Power-Down own dark (Hoshiningen)
	2F - Disable all enemies (Invitation to a Dark Sleep)
	30 - Power-Up own dark, Power-Down own light (Witch's Apprentice)
	31 - Direct attack (Mystic Lamp)
	32 - Direct attack (Leghul)
	33 - Power-Up self for own insects (Insect Queen)
	34 - Destroy all enemies, 4000 LP direct damage (Obelist the Tormentor
	35 - Power-Up x3 self for cards in hand (Slifer the Sky Dragon)
	36 - Decrease LP to 1 and direct damage with the decreased amount (The Winged Dragon of Ra)
	37 - (unused) "Blue-Eyes White Dragon was activated. Blue-Eyes Ultimate Dragon will be summoned."
	38 - (unused) nothing
	39 - (unused) "Blue-Eyes White Dragon was activated. Blue-Eyes Ultimate Dragon will be summoned."
	3A - (unused) nothing
	3B - Power-Up Harpie's Pet Dragon (Cyber Harpie)
	3C - Power-Up self if Dark Magician in GY (Toon Dark Magician Girl)
	3D - Fuse with Beta and Gamma (Alpha The Magnet Warrior)
	3E - Fuse with Alpha and Gamma (Beta The Magnet Warrior)
	3F - Fuse with Alpha and Beta (Gamma The Magnet Warrior)
	40 - Separate into Alpha, Beta, and Gamma (Valkyrion the Magna Warrior)
	41 - Sacrifice: Power-Down all enemies (Beast of Gilfer)
	42 - Steal enemy (Dark Necrofear)
	43 - Power-Down self, destroy 1 enemy (Zombyra the Dark)
	44 - (unused) "Amazon Chain Master was activated and sent to the graveyard. The player also loses 1,000LP. In return, the player draws a card from the foe's hand."
	45 - Destroy all enemies (Gilford the Lightning)
	46 - Destroy 1 enemy, Power-Up self (Mystical Beast Serket)
	47 - Destroy all enemy traps (Jinzo)
	48 - Power-Up self for enemy dragons (Buster Blader)
	49 - Destroy 3 enemies with 2-in-1 success (Barrel Dragon)
	4A - Sacrifice: direct damage equal to strongest enemy (Reflect Bounder)
	4B - Destroy 1 enemy, switch place (Parasite Paracide)
	4C - Sacrifice: restore 500 LP (Skull-Mark Lady Bug)
	4D - Sacrifice: summon insect from hand (Pinch Hopper)
	4E - Power-Down 1 enemy (Rocket Warrior)
	4F - Clone self (Revival Jam)
	50 - Power-Up self for own dragons (Master of Dragon Soldier)
	51 - Power-Up self (Legendary Fiend)
	52 - Summon La Jinn the Mystical Genie of the Lamp (Ancient Lamp)
	53 - Destroy 1 enemy, 500 LP direct damage (Des Volstgalph)
	54 - Direct attack, Power-Down self (Exarion Universe)

Card Costs New.raw
E14 long

Card Frame New.raw
385 long

**************************
Changing Direct Damage Spells
**************************

Sparks				200
Hinotama			500
Final Flame			800
Ookazi				1000
Tremendous Fire		2000

Misc
023E20	Max LP
020237D8	01 - AI's turn
0202347C	Current LP

-

Healing (separate values for P1, P2)
02C238	(0802C1E0)	Soul of the Pure
	mov r0, 0xfa
	lsl r0, r0, 0x03
02C340	(0802C2A0)	Dian Keto 

104668	Dian Keto ASM pointer

-

02C360	Sparks ASM
Damages:	02C39C 02C3B4 02C408
all to C8

Hinotama, Final Flame changed to load the damage from the next spell's ASM area, 2 lines can be saved by changing ldrb to ldrh at the beginning of the code.

02C414	Hinotama ASM
Damages:	02C450 02C468 02C4BC
to ldr r0's
1D 48
17 48
02 48

104674	Final Flame ASM pointer (changes: +4)
02C4C8	Final Flame ASM
10 B5 10 4B 10 4A 90 78 98 70 D0 78 D8 70
to:
F4 01 00 00 10 B5 0F 4B 0F 4A 50 88 58 80
Damages:	02C504 02C51C 02C570
to ldr r0's
1D 48
17 48
02 48

104678	Ookazi ASM pointer (changes: +4)
02C57C	Ookazi ASM
10 B5 11 4B 11 4A 90 78 98 70 D0 78 D8 70
to:
01 BC 00 47 20 03 00 00 10 B5 10 4B 10 4A
Damages:	02C5B8 02C5D4 02C628
all to FA 20 80 00

02C638	Tremendous Fire ASM
Damages:	02C674 02C690 02C6E8
all to FA 20 C0 00

-

E3B61C	Tremendous Fire Effect Text
‚Q% = "2,"

**************************
Cost Change
**************************

First Change:
New formula for monsters with higher def than atk:
0 Tribute	(Def's cost - Atk's cost)/2 + Atk's cost
1+ Tribute	(Def's cost - Atk's cost)*0.3 + Atk's cost, -70% if too low
Ritual		Above + 100

Second Change:
Fairy, machine, pyro, reptile costs -30% because they have no beneficial field.

Third Change:
+50% Cost:
	LV1-4 from ATK 1700
	LV5-6 from ATK 2300
+40% Cost:
	LV1-4 from ATK 1650 and fairy/machine/pyro/reptile
	LV5-6 from ATK 2250 and fairy/machine/pyro/reptile
(Fairy/machine/pyro/reptile change is 70%x140%=98% in total.)

**************************
Original Costs
**************************

0 Tribute
0		10
250		14
300		16
350		19
400		22
450		25
500		29
550		33
600		37
650		42
700		47
750		53
800		59
850		65
900		72
950		79
1000	87
1050	95
1100	103
1150	112
1200	121
1250	130
1300	140
1350	150
1400	161
1450	172
1500	183
1550	195
1600	207
1650	220
1700	233
1800	260
1850	274
1900	289
2000	319
2100	350
2200	384
2500	493
2600	532

1 Tribute
1350	5
1500	7
1600	14
1650	19
1700	25
1750	32
1800	41
1850	50
1900	61
1950	73
2000	86
2030	95
2100	116
2150	132
2200	150
2250	168
2300	188
2400	231
2500	279
2600	331
2800	449
3000	585

2 Tribute
2200	3
2300	6
2350	9
2400	12
2450	16
2500	20
2600	30
2650	37
2800	58
3000	95
3200	142
3300	168
3500	229
3850	357

3 Tribute
3200	5
5000	169
