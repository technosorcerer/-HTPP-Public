package com.dabomstew.pkrandom.updaters;

public enum MoveUpdateType {
    POWER, PP, ACCURACY, TYPE, CATEGORY
}
