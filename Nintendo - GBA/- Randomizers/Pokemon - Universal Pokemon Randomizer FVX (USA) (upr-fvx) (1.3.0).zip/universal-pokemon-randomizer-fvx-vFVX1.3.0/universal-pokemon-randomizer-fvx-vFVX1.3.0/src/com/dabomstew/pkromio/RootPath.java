package com.dabomstew.pkromio;

public class RootPath {

    // This is intentionally non-final so applications can change it.
    // Yes, you are right, this is kind of hacky.
    public static String path = "./";
}
