package com.dabomstew.pkrandom.updaters;

public enum BSUpdateType {
    HP, ATK, DEF, SPDEF, SPATK, SPEED, SPECIAL
}
