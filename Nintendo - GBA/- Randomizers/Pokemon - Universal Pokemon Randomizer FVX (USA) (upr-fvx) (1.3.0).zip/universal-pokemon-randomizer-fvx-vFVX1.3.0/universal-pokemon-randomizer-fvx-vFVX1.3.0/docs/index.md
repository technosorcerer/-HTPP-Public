---
layout: default
title: Home
---
# Welcome!

This is a site for the **Universal Pokémon Randomizer** in general, and its **FVX** branch in particular. 

For an overview of what the Randomizer is and can do, and its history, see [About]({{ site.baseurl }}/about.html). For contributions and credits, see [Acknowledgements]({{ site.baseurl }}/acks.html). For more detailed info of how to use it, and how certain options work, see [Wiki]({{ site.baseurl }}/wikipages/home.html). And for downloads, see... [Downloads]({{ site.baseurl }}/downloads.html).
