---
layout: default
title: Downloads
---
Downloads are hosted on GitHub. Click the link(s) below and follow the instructions for "How to use". The Randomizer assumes you have ROM files for the games you want to randomize on your computer. For legal reasons, you will have to find these yourself.

[Latest version](https://github.com/upr-fvx/universal-pokemon-randomizer-fvx/releases/latest)

Older versions:
- [FVX versions](https://github.com/upr-fvx/universal-pokemon-randomizer-fvx/releases) 
- [foxoftheasterisk's versions](https://github.com/foxoftheasterisk/UPR-ZX-closer-to-vanilla/releases) / [voliol's versions](https://github.com/voliol/universal-pokemon-randomizer/releases) 
- [ZX versions](https://github.com/Ajarmar/universal-pokemon-randomizer-zx/releases)
- [Original UPR versions](https://web.archive.org/web/20231226230806/https://pokehacks.dabomstew.com/randomizer/olddownloads.php)