This "players_unused" folder contains Custom Player Graphics,
which for one reason or another should NOT be included in releases of the randomizer.

They may be unfinished, or be intended for a game that doesn't have CPG support yet.