---
name: Contribution Idea
about: If you have an idea for something you want to contribute.
title: "[Contribution Idea]"
labels: Contribution Idea
assignees: ''

---

<!-- This is not the template for feature requests ("Feature Request" is). Please only use this template if you have an idea for something you want to contribute to the codebase yourself. -->

**Is your idea a new setting, a change to an existing setting, or something else? Please describe clearly:** 

**What problem would your contribution solve? Please describe:** 

**Additional context:**

<!-- Your issue will be closed unless you check this box (by putting an X between the brackets) below! -->
**I understand that I am expected to implement this change myself in the randomizer's codebase: [ ]**
