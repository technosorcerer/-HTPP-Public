#!/bin/bash
cd "$( dirname "$0" )"
java -Xmx4608M -jar UPR-FVX.jar please-use-the-launcher
