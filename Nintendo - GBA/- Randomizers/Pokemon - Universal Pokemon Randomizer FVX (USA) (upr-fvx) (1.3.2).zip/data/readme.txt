This "data" folder contains files that are used by the randomizer, but may still be edited by the user.
They allow for some extended customability.