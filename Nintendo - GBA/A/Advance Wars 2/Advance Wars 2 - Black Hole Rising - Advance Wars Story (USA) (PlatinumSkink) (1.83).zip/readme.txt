Advance Wars Story is an Advance Wars 2 romhack by PlatinumSkink.

It uses the findings and work of XenesisXenon, Mark999/Ephraim225, Kartal, Vivi the Blossom,
x0_000, Tequila, Mr Dev, EgalLau37 and more from Wars World Forums to produce a 
custom campaign.

It features a full custom normal campaign comprised of 34 missions,
some CO balancing and a couple new/modified units.

The custom units do not support battle animations and become strange things.
If you see that, know it's not an unintended glitch. We just can't do animations.
You may want to turn off battle animations if you don't want to see that.

War Room and Versus is untouched, minus my CO and unit changes. There is no hard mode/advanced campaign.

LunarIPS is recommended to use to patch the hack onto a clean
unmodified USA/Australia version of Advance Wars 2: Black Hole Rising.
If it doesn't work, you may want to try applying the cleaner patch by
XenesisXenon that I have included for your convenience.

This hack could have been called "Advance Wars Fanfiction", but
that, while accurate, doesn't sound as good. :P

Advance Wars 2: Black Hole Rising by Intelligent Systems and Nintendo.