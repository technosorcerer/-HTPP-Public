**************************
Created by Kartal
karsahyena@protonmail.com
**************************

This simple patch re-adds both versions of Sturm into the War Room and Vs. Mode, and unlocks all COs in BattleMaps for purchase by default (purchase for free).

Both versions of Sturm look the same. The Campaign version (unlocked by default) comes before the Vs Mode version (purchased from Hachi).

Note: To quickly progress to the main game, beat the last Field Training mission and then earn coins by completing another mission (Campaign/War Room) to unlock BattleMaps.

**************************
How to Patch
**************************

Use this ROM as a base:
Advance Wars (USA).gba

Hash

Database match: Advance Wars (USA)
Database: No-Intro: Game Boy Advance (v. 20210227-023848)
File/ROM SHA-1: D0A0A4CFE9B95AC7118F7EF476F014CA0242EB65
File/ROM CRC32: DBEF116C

(confirm your ROM here: http://www.romhacking.net/hash/) 

The patch was created with Lunar IPS.
https://www.romhacking.net/utilities/240/

Alternatively, use this online patcher:
https://www.romhacking.net/patch/

**************************
**************************
Changes
**************************
**************************

Below is a list of changes done to the ROM. (The price changes are not documented.)

**************************
Adding Sturm
**************************

(Allow both Sturms in WR/Vs)

28573C	CO Order
01BCFC	CO Order Setup ASM
	01BD04	Check for Campaign Sturm's ID
	01BD08	Check for Vs Sturm's ID

01BD04	Check for Campaign Sturm's ID
	0A 2D to: 06 E0

**************************
Battle Maps
**************************

0803EA60	Nell unlock ASM
	03EA72	0B 20 to: 08 E0

0803EA98	Grit unlock ASM
	03EAAA	01 20 to: 08 E0

0803EAD0	Kanbei unlock ASM
	03EAE2	03 48 to: 07 E0

0803EAFC	Sonja unlock ASM
	03EB0E	03 20 to: 08 E0

0803EB6C	Eagle unlock ASM
	03EB7E	05 20 to: 08 E0

0803EB34	Drake unlock ASM
	03EB46	04 20 to: E0 08

0803EBA4	Sturm unlock ASM
	03EBB6	05 20 to: 1C E0

-

2E7B84	BattleMaps, 18 long entries, 798 long, 51 entries
+0	Name
+4	Price
+8	Unlock condition
+C	Purchase effect
+10	?
+14	Purchase dialogue

Note: The icon is included in the name text string.
09 80	CO
09 81	Map
09 82	Map Case
09 83	Menu (Advance Mode)
09 84	xCoin

00	Nell
01	Grit
02	Kanbei
03	Sonja
04	Eagle
05	Drake
06	Sturm
07	Shark Strait
08	Royal Channel
09	Moji Island
0A	Pivot Isle
0B	Kita Straight
0C	Ridge Island
0D	Mial's Hope
0E	Bounty River
0F	Toil Ferry
10	Twin Isle
11	Egg Islands
12	Terra Maw
13	Stamp Islands
14	Rivers Four
15	Ring Islands
16	Last Mission
17	Star Islands
18	Eon Springs
19	Sabre Range
1A	Asphalt Maze
1B	Zero Wood
1C	Switchback
1D	Ruby Keys
1E	Rainy Haven
1F	Rail Strait
20	Tribe Islands
21	Piston Dam
22	Hat Harbor
23	Swan Cove
24	Go Islands
25	Clover Keys
26	Keyhole Cove
27	Fork River
28	Channel City
29	Shield Hills
2A	Peril Maze
2B	Devil's Inlet
2C	Shear Port
2D	Liar's Cove
2E	Nail Canal
2F	Atlas River
30	Eel Channels
31	Jab Peninsula
32	Thorn Islands
33	Crop River
34	Loop Road
35	Plus Canal
36	Patriot Cove
37	Web River
38	Cap Narrows
39	Jay Islands
3A	Spring Lakes
3B	Tatter River
3C	Island X
3D	Traitor River
3E	Fable Hills
3F	South Cape
40	Glory Islands
41	Moon Isle
42	Mint Plateau
43	Wrench Island
44	Rapid Ferry
45	Scarab Road
46	Pointing River
47	Liaison Wood
48	Poem Cape
49	Blue Lake
4A	Leaf Haven
4B	Battle Cube
4C	Special Map (Map Case)
4D	Vs. Map (Map Case)
4E	3-Player Map (Map Case, Unused)
4F	Advance Campaign
50	Null