You can read about all changes in : 

https://mamby.com/p/dragon-72f295e2

Please, if you like my work,  consider donating.

Thanks.