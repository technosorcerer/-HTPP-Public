GBA Doom II PC Conversion pack! - Revision 1.3.1

NOTE:
You might also want to recompile it with the "Recompile.exe Topmost" setting otherwise certain sprites
that had holes in the original rom will have parts of their faces probably missing, like the player.

Changelog:

Rev 1.3.1
* After a couple years, I've returned to simply fix the pistol sprite to not have a chunky white square on the firing frame. It's been bugging me this whole time.
This was done via a manual hex edit, so in the "Pistol Sprite HEX fix\" directory, search the for the hex string contained in "search.bin" and replace it with the contents of "replacement.bin"

Rev 1.3
* Blood particles now fall down somewhat, to try an match the PC version.
  This works by taking advantage of the new YSTART/YSTOP rearranging introduced in the 
  GBA Doom II Modding Tools 0.2 Beta version.

Rev 1.2
* Fixed a very minor palette issue with using the radiation suit and the chaingun.
* Extremely minor fix for the Colormap for spectres in the dark glitchy areas in the original game.

Rev 1.1
* Fixed a graphical glitch when walking far away from the Brick2 texture.
  It was fixed via adding new *.LOC files so the texture would point to a new blank spot. 
  (On the original release it was borrowing off some red brick texture perhaps?)


Rev 1.0:
* Original release.

Credits:

Marcus Lewis - For playtesting for graphical glitches. Thanks man!
Id Software - For making such a great game.
And MagicTeam - For making this all possible by handing me their Russian editor, which I was then able to figure out the graphic formats and program the tools.

Thanks dudes appreciate ya! ~ Kippykip
https://kippykip.com/index.php?threads/gba-doom-ii-pc-conversion-pack-revision-1-0.434/