This hack was made by Roebloz using Kippykip's hacking tools for Doom 2 GBA!
You are free to build upon this hack or take the custom textures from it, as
long as you credit me. 

Have fun playing your low-def Doom II!