"Double Dragon Advance"
Traducción al Español Ver. 1.0 (05/06/2018)
por Max1323 (Traducciones Max1323).
---------------------------------------------------
Descripción:
Luego de una guerra nuclear que dejo devastado a gran parte del mundo, las pandillas surgen para controlar la ciudad de
Nueva York.
Los hermanos gemelos Billy y Jimmy Lee sobreviven a tal
evento con sus artes marciales conocido como Sou-Setsu-Ken.
Pero un día Marian es secuestrada por unos matones llamados los "Shadow Warriors." 
Tendras que ir a rescatarla por direfentes lugares cargado
de enemigos y jefes.

Desarrollado: Million
Publicado:    Atlus
Lanzamiento:  14/11/2003 (USA)
	      05/03/2004 (JAP)
---------------------------------------------------
Acerca del proyecto:
-La mayoría de los textos están traducidos.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS (PC)
Utilizar UniPatcher (Android)
Utilizar Rom Patcher JS (Parcheador Online):
https://www.romhacking.net/patch/

Archivo IPS
1266 - Double Dragon Advance (U)(Mode7).gba
File Size     4.00 MB
File MD5      86A7A0FA851FA7C2C9320EC31C4ED673        
File SHA-1    2035D68DC034E9EEFD69FB0C4D26A9F2FCB01800
File CRC32    352B1E1F