Here it is: a real restoration project for the infamous Donkey Kong Country for GBA.
It wasn't a bad port after all, the gameplay was completely intact and also had the new Hero and Attack modes.

It's still a little behind from the SNES version due to the resolution reducement and soundtrack (which sounds worse, but still sounds good!). But it's an undeniable improvement.

This wasn't the typical SNES to GBA palette restoration. This was hell.
After Rare reduced all sprites and tilesets, none of the palettes matched so I had to repalette it manually using Photoshop and a custom tool made exclusively for this.

What's missing:
* probably a few bonus rooms
* all new palettes not coming from the SNES version (basically, minigames and map)


Needed ROM:
Donkey Kong Country (Europe) (En,Fr,De,Es,It).gba
CRC32: 41d277fe
MD5:   c1fb9badf816b6d7836f4990f8119815
SHA-1: 8995f0be99a9cff66474a8975b8499bd69fb4c45


by marc_max