This patch moves the Heart Piece obtained through the incredibly arduous and boring Figurine side quest to the instantly accessible part of the house it resides in. 
The reward for the Figurine quest is now the music player, while all Heart Pieces can now be obtained without going through this absolute slog. 

Made with Minishmaker0.6.1a
https://docs.minishmaker.com/