The Legend of Zelda: The Minish Cap
European Backport Edition v1.0
by Prof. 9, 20th December 2013


INTRODUCTION
The Legend of Zelda: The Minish Cap for the Game Boy Advance was first released
in Europe, and subsequently in Japan and North America. Since the European
version was an earlier build, there are various differences between it and the
later versions.

This patch backports the most important differences to the European version: the
third bomb bag upgrade, the fix for Eenie's Kinstone fusion and calling Zeffa
from the rooftop of the tower at Cloud Tops.

Contrary to popular belief (i.e. what's on TCRF), the third bomb bag not
appearing in the shop is not a glitch; there is no text or object placement
data for it. I've added translations for all the different European languages
based on the Boomerang's text (which is how it was done in the North American
and Japanese versions). As for the Kinstone glitch, it is caused by the dev team
forgetting to check the fusion result before marking it as finished in Eenie and
Meenie's NPC scripts.

The bomb bag upgrade saves, and you can transfer your save to your physical
cartridge afterwards to keep it. However, this won't re-enable Eenie's Kinstone
fusion if you already missed it.


FEATURES:
- The third Bomb Bag upgrade has been added, which lets you carry up to 99
  Bombs. It can be purchased from Stockwell's store after obtaining the third
  wallet upgrade and buying the Boomerang.
- Eenie's Kinstone fusion glitch has been fixed. In the European version, if you
  initiate a Kinstone fusion with Eenie but then cancel it, you can never try it
  again, and you won't be able to get the fourth Bottle, the Mirror Shield and
  the final Kinstone fusions.
- The Ocarina of Wind can be used from the rooftop of the Wind Tribe's Tower in
  Cloud Tops (where the entrance to the Palace of Winds is).


HOW TO USE:
Apply the included IPS file to a clean European The Legend of Zelda: The Minish
Cap ROM using your favorite IPS patching tool. The ROM should have a CRC32 of
E8637292. I recommend Lunar IPS, version 1.02 by FuSoYa for Windows users.


SOURCE:
Source is included in the "src.asm" file. Feel free to do whatever you want with
it. Use Kingcom's ARMIPS assembler v0.7d to compile. You need to provide ARMIPS
and an input ROM yourself.


CONTACT:
You can contact me (Prof. 9) in the following ways:
- Twitter: Prof9
- E-mail: chocoreep31@gmail.com
- PM: romhacking.net


LICENSE:
This ROM hack and readme come without any warranty, to the extent permitted by
applicable law. You can redistribute it and/or modify it under the terms of the
Do What The Fuck You Want To Public License, Version 2, as published by Sam
Hocevar. See http://www.wtfpl.net/ for more details.