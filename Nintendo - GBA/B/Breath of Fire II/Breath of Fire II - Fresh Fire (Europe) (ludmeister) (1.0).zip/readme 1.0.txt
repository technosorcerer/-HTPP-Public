*************************************************************************
***	The Breath of Fresh Fire modification 							  ***
***		for															  ***
***	  Breath of Fire 2 for Game Boy Advance							  ***
*************************************************************************

Version:	v1.0 � Released March 24th, 2011.
Author: 	ludmeister (aka Jeff Ludwig)
Website: 	http://jeffludwig.com


The aim of this mod is simply to create a fresh Breath of Fire 2 experience, 
and to allow for more liberal use of Dragon powers.


Notice, effective March 1st, 2012 
******************************************************************************

	For this release and all new releases, I am discontinuing the use of 
	IPS2EXE to create patches that can be applied without an IPS patching 
	program.  These executable patches set off certain virus and malware 
	scanners.  



Changelog
******************************************************************************

    * Spells are modified, especially their AP costs, names, and damage done.
	
    * Every character casts different spells, and some have different starting 
	  spells as well.
	  
    * Starting stats, and level up progressions for all characters, including 
	  Bleu have been meticulously reworked. Some of the characters will play 
	  much differently than stock Breath of Fire 2, making your strategies different.
	  
    * Items have been renamed (no 2 character demarcation at the end of each item). 
	  This allowed for 8 characters for each item name (6 for stackable items). 
	  There are numerous items with different properties, and almost all 
	  non-equipable items are stackable.
	  
    * Dragon Magic has been significantly changed. No more zero-ing out of the 
	  Dragonbrood's AP when using Dragon abilities! They have been given an AP 
	  cost, and do damage based off of hero level (not AP remaining).
	  
    * Fixed a bug in the original code that prevented the Dragon abilities (Fire, 
	  Ice and Thunder Dragon) from inflicting damage according to their elemental 
	  classification.
	  
    * I have meticulously realigned the Shaman combo system. The Holy and Devil 
	  shamans are more powerful on their own. In face, a bug in the original code 
	  (namely, Luck was not affected as it should have been) meant that the Holy 
	  shaman by itself was worthless. I bypassed this by allowing the Holy Shaman 
	  to increase other attributes. I have also added new Shaman combos. For
	  example, Nina + Fire + Water... is very powerful!
	  
    * The "Special" message when character's critically hit monsters always annoyed 
	  me. It has been changed to "Smoked!"
	  
    * Of course, to compensate for the various nifty new powers your characters have, 
	  your enemies' power had to be increased proportionally. To keep things interesting.



Installation instructions

The following applies this and all future releases of the Breath of Fresh Fire mod.

    * First of all, you will need to obtain a clean GBA ROM of Breath of Fire 2. 
	  The ROM title that you are looking for is "0510 - Breath of Fire II (E).gba". 
	  You are on your own for this step, as it is illegal to provide ROMs of 
	  copyrighted material. There are sites that do provide this ROM though, 
	  and you should be able to obtain it.
	
	* Note: This patch does not work with the "0403 - Breath of Fire II (U).gba" ROM!
	  
    * When you get it, make a backup of it if you would want to play the vanilla 
	  version (or, in case I post an updated version of the mod here... I am not 
	  going to make version 1.0 to "version whatever" patches for my mods, for 
	  instance).
	  
    * Download the Breath of Fresh Fire mod.
	
	* Use the IPS patching program of your choice to apply the .ips patch to the
	  correct ROM.  As I use IPS XP (http://home.arcor.de/minako.aino/ipsXP/) to
	  create my patches, I recommend using this program to patch your ROM.
	    
     * I hope you enjoy it!
