SRW-OG2 Easier

This is an PPF patch for the GBA "Super Robot Wars ORIGINAL GENERATION 2".

SRW-OG2 All patches = SRW-OG2 Pilot enhancement + SRW-OG2 Easier

Changes:
- SP consumption of allied pilots reduced to 1/3.
- Airframe modification cost reduced to 1/10.
- Weapon modification cost reduced to 1/3.
- Reduced PP for pilots to gain special skills by 1/4.
 (PP required to increment pilot parameters changed from 4 to 3.)

Update Sep-11
- Increased hit rate and defense of allied pilots by 10%.

Enjoy!

-------------------- Don't tell everyone! --------------------
OG2 hack patch collection
https://ux.getuploader.com/kikerogaupl/download/159
DL Pass Tips: Contributor's name
--------------------------------------------------------------
