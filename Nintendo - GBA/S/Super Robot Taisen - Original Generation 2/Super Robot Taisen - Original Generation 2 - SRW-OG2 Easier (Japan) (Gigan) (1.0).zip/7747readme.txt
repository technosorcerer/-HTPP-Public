SRW-OG2 Easier

This is an PPF patch for the GBA "Super Robot Wars ORIGINAL GENERATION 2".

Changes:
- SP consumption of allied pilots reduced to 1/3.
- Airframe modification cost reduced to 1/10.
- Weapon modification cost reduced to 1/3.
- Reduced PP for pilots to gain special skills by 1/4.
 (PP required to increment pilot parameters changed from 4 to 3.)

Enjoy!
