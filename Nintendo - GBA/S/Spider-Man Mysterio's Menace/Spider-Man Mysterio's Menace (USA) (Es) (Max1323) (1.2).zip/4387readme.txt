"Spider-Man Mysterio's Menace"
Traducci�n al Espa�ol Ver. 1.2 (30/06/2019)
por Max1323 (maxmuruchi@gmail.com)
---------------------------------------------------
Descripci�n:
Mysterio, el maestro de la ilusi�n, est� usando sus poderes para convertir a la ciudad de Nueva York en su propio parque de atracciones siniestro. Por suerte para la Gran Manzana, ha olvidado una cosa: eres Spider-Man, y para un s�per villano hambriento de poder, eso significa que el tiempo de juego ha terminado.

Desarrollado: Vicarious Visions
Publicado:    Activision
Lanzamiento:  19/09/2001 (USA)
              21/09/2001 (EUR)
              26/04/2002 (JAP)
---------------------------------------------------
Acerca del proyecto:
Se tradujo los di�logos del men� y de la historia principal.
Se termino de traducir los textos de la pantalla de continuar.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS

Spider-Man Mysterio's Menace (USA, Europe).gba
File MD5      FBDA16CBC7E3F81AA5B90DA955D3E114        
File SHA-1    EF80933054D6BE9532D5D35BEE6F715438301755
File CRC32    6E135B4D                                
File Size     8.00 MB
                              
                           
                              
                              
                             
                       
