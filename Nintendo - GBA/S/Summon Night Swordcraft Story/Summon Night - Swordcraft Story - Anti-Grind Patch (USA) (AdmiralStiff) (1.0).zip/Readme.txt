Summon Night Sword Craft Story (USA): Anti-Grind patch

SmnNiteSwrdcrftStry Anti-Grind (USA).ips

This patch does the following:

-Amulet item lasts x8 times the amount of original steps
-Enemies yield x4 the amount of money

Known bugs:
-Guardian Beast assisted foes: EXP = (Money x 4)

:::::::::::::::::
::Hacking Notes::
:::::::::::::::::
-------------------------------------------------
Current Amulet Steps [RAM address]
200007c
Original Value
019000
00 90 01

Amulet Steps [ROM address]
68584 [Base read value]
68586 [Multiplier]
4902 -> 0903 [lsl r1, r1, 9h -> r1, r1 0Ch]// x8 Lasting effect
-------------------------------------------------
Handles money after battle, (redundant/unused code?)
2F68C [ROM address]
0004 -> 8000 [lsl r0, r0, 10h -> r0, r0, 2h] //Multiply current read money by 4
2F68E [ROM address]
000C -> C046 [lsr r0, r0, 10h -> nop] //Do nothing

UPDATE: Battles against foes assisted by a Guardian Beast seem to calculate their EXP from here for some reason...
-------------------------------------------------
"Money multiplier" code found online
Only multiplies then adds last read value, regardless of enemy quantity, after battle
2F694 [ROM address]
0918 -> 8100 [add r1, r1, r0 -> lsl r1, r0, 2h]
-------------------------------------------------
end