this package is the result of months of work, i started working
on it as soon as i opened my account 3/4 months ago. Thanks @Xgone for the kirby mod,
@Backslash for the collaboration in the creation of the bandana dee,thanks megagamer923 for the mario mod
@BenjaminTheHedgefox for the collaboration in the creation of
pac-man and I thank @Prof.Lavenfurr for helping me along this path,
both in putting up with me daily and in always being available to help
me along with the support of Backslash, @Eitz and others of you that I don't remember,
THANKS TO ALL!

mario over sonic by megagamer923
kirby over tails by Xgone
bandana dee over knuckles by me and Backslash
mega-man x over shadow by me
yoshi over rouge by me
luigi over amy by me
donkey kong over cream by me
samus over e-102 by me
pikachu over chaos by me
pac-man over emerl by Benjamin the Hedgefox and me
master hand over eggman by me
ALL effect by me

for the file IPS use lunarIPS on your computer,
for the sheet sprite use SBHS which works with Java

BY son_VegenKs#3341 on discord or
son_VegenKs on gamebanana, and soon also on youtube.....
