This is a graphical hack that replaces the ugly bird ship with the Vic Viper as seen in Gokujou Parodius.
Other player related assets have also been changed to fall in line with the Gradius theme.
Level and enemy assets, and subsequently the aesthetic impression of the game, remain intact.
Unfortunately I wasn't able to change the HUD icon and ship name text, due to how the game was coded.

The game is much more fun when you're not thinking "I wish I wasn't an ugly bird plane!"
