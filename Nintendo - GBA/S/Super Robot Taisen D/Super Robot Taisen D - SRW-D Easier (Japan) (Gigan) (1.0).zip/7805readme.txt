SRW-D Easier

This is an IPS patch for the GBA "Super Robot Wars D".

Changes:
 - Song EN/SP consumption and weapon/aircraft modification costs are reduced.
 - Halved the cost of aircraft repairs, Tripled the funds acquired
 - Allied pilot ability (defense/hit rate) increased by 10%
 - Pilot transfer range expanded
 - Boss Borot, Robot Jr. and Kelot are strengthened.
 - For VF-19 Custom F Valkyrie (Basara), VF-11MAXL Custom (Milene) and VF-17T Custom Nightmare (Viheeda) were enabled to attack with the aircraft type F/G.

Please be aware that the game difficulty will be easy.
The goal was non-stress and exhilaration.

Enjoy!

--
Publisher : Banpresto
Release   : August 8, 2003
