:::::::: -- SONIC ADVANCE 2 SP -- ::::::::
::::::::::: -- VERSION 1.01 -- :::::::::::: 

Sonic Advance 2 SP is a ROM hack geared at improving some of the less-loved aspects of Sonic Advance 2. 

Changes included:
- Adjusted enemy placements to prevent many 'cheap shots', such as item boxes bouncing you into enemies
- Many bottomless pit areas replaced with new routes, or made harder to fall into at a moment's notice.
- More plentiful Special Ring placement, allowing a more freeform approach to entering Special Stages
- Special Stage entry requirement reduced to 5 SP Rings

That said, Advance 2 is still a challenging game! Bosses haven't been touched, and in the later half of the game you should expect plenty of enemies
and the return of the dreaded bottomless pits. I've tried to balance things in a way that feels fair, but also rewards memorisation for repeat play
and speedrunning - without *as* harsh a penalty for not doing so. 

	:: -- HOW TO PLAY -- ::

Download XDelta UI (https://www.romhacking.net/utilities/598/) and run it. Select 'Sonic Advance 2 SP.xdelta', and then select your Sonic Advance 2 ROM file.
Sonic Advance 2 SP expects the US ROM for Sonic Advance 2 (SHA1 Hash 7bcd6a07af7c894746fa28073fe0c0e34408022d). 
Then name the output file (such as Sonic Advance 2 SP.gba) and click Patch. The game should now load as Advance 2 SP. 

	:: -- WHY DO I HAVE EVERYTHING UNLOCKED? -- ::

The Sonic Advance games have a somewhat funny debug state where, if an SRAM chip is not found (such as on a damaged or bootleg cartridge), all game content will be unlocked
immediately. Make sure your emulator or flashcart supports the SRAM chip.  

	:: -- CAN I USE THIS ON NINTENDO 3DS? -- ::

This hack has been lightly tested on 3DS, and seems to work fine. Use the Ultimate GBA VC Injector tool, and use the recommended settings during the
.cia creation process - it should work fine. 

	:: -- ARE YOU GOING TO DO ADVANCE 1/ADVANCE 3 SP? -- ::

Maybe? But Advance 1 only has one or two *really* crap levels. And while Route 99 and Chaos Angel kind of suck, I actually already love Advance 3. So they're not on
my list of priorities right now, but maybe in the future. 

	:: -- SPECIAL THANKS -- ::

This hack would not be possible without the work of MainMemory, who created the tools and Tiled extensions that allowed for stage editing in the first place, as well
as responding lightning-fast to every way in which I managed to break her tools. 

In addition, a huge thanks to freshollie, Jace, and all other members of the Sonic Advance 2 decompilation project for their hard work and Discord assistance. 

Thanks to Cornholio309, who created the original patch to reduce the SP Ring requirement and also provided the values that were edited in its README file. 

Thanks to SEGA, Sonic Team and Dimps for creating the original game. Much as I've complained about it, I'd have nothing to work from without it. That, and
Ice Paradise Act 2 slaps. 

No Thanks to THQ for having the publishing rights to these games, which means they're in limbo outside of Japan. Seriously, where even are the re-release rights?!

Many thanks to those who tested this hack, or provided feedback:
- Arrietty
- Voltic.exe 
- CyclonX
- RobotFaker
- Azookara
- Wraith 
- Solkia
- Silva
- Rawrdom
- Cola64
- Michafrar
- Tomothy 
- SunnyD
- Stiv 

Many thanks to my Twitter followers for the unwavering support in getting this finished. Seeing all the excitement really pushed me forward!

And many thanks to my girlfriend Hal, for putting up with me rambling about tilesets and co-ordinates and SP Rings for the last two weeks. She's the one. 

Please follow me @Tracker_TD on Twitter for news on any updates or bugfixes for this release. 

CHANGELOG

-- 1.01
- Fixed a header change that caused errors with certain flashcart boot settings 