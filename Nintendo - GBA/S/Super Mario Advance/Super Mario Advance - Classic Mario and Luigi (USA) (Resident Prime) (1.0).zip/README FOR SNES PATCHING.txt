Super Mario Advance - Classic Mario and Luigi Hack
by Nilrem on MFGG.net
-----

If you are intending on patching a vanilla Super Mario Advance (US) rom, apply the patch with lunar ips.

If you are intending on using a rom patched with the Snes Color Restoration hack made by Mister Man on Romhacking.net, apply his patch first, then apply the Classic Mario and Luigi Palette patch of your choice.

Thank you, and enjoy!
-----

Mister Man's Snes Color Restoration Hack can be found here:
https://www.romhacking.net/hacks/6439/

Tools Used:
Gold Finger
Advanced Palette Editor