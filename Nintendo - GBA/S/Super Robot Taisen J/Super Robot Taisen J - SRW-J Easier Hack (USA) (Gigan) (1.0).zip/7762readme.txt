SRW-J Easier

This is an PPF patch for the GBA "Super Robot Wars J".

Changes:
- Change the name of the main character.
- SP consumption reduced to 1/5
- Added the influence of the main character's friendship and affection.
- Expanded the range of aircraft that can be piloted (*There is a bug that causes display errors).
- Increased the upper limit of the remodeling stage by 25%.
- Increased funds and experience by 10%.
- Reduction of modification costs (1/10 for aircraft, 1/2 for weapons)

Please be aware that the game difficulty will be very easy.

Enjoy!

--
Publisher : Banpresto
Release   : September 15, 2005
