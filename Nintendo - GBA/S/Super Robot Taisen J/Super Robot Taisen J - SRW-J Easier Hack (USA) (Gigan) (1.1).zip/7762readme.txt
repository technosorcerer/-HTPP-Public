SRW-J Easier

This is an PPF patch for the GBA "Super Robot Wars J".

Changes:
- Change the name of the main character.
- SP consumption reduced to 1/5
- Added the influence of the main character's friendship and affection.
- Expanded the range of aircraft that can be piloted (*There is a bug that causes display errors).
- Increased the upper limit of the remodeling stage by 25%.
- Increased funds and experience by 10%.
- Reduction of modification costs (1/10 for aircraft, 1/2 for weapons)

Updated June 25, 2023:
- Aircraft modification limit increased.
- Expansion of the range of aircraft that pilots can change aircraft (*Scenario development may be interfered with by replacing the main character or other pilots with aircraft that differ from the original. Please try with caution.)
- Enhancement of Mobius-Zero, and LAYZNER's members can now also ride.
- Improved performance of Estevaris, Skyglasper
- Power up the power of the chain gun by 1.5 times (Full Metal Panic!)
- Improved mobility of the Strike Gundam
- Improved aircraft performance and attack CT correction for G Gundam series
- Other minor adjustments, such as changing the range of BRAIN POWERED shots.
- Cheat codes added for use of hidden aircraft.

Please be aware that the game difficulty will be very easy.

Enjoy!

--
Cheat code to use the hidden aircraft "Volrent" from the beginning

VBA: 02033E93:04
PAR: C07B239EDE7F3BF8
XTA: 32033E93 0004
AR3: B77E9008 56FDA947

1. after selecting the main character, turn on cheat on the aircraft selection screen.
2. Press the left and right buttons to bring Volrent to the screen.
3. Turn the cheat OFF and then press the decision button.
