SRW-R Easier

This is an IPS patch for the GBA "Super Robot Wars R".

Changes:
- SP consumption and weapon/aircraft modification costs are reduced.
- Weapons/aircraft modification limit up
- Halved the cost of aircraft repairs, Tripled the funds acquired
- Allied pilot ability (defense/hit rate) increased by 10%
- Akito, Ryoko, Hikaru, and Izumi in the movie version have slightly higher abilities than in the TV version.
- Pilot transfer range expanded
- Boss Borot and Kelot are strengthened.
- Dendo in normal form, Black Salena can recover a little EN.
- Reinforced Jegan as Jegan custom

Please be aware that the game difficulty will be easy.
The goal was non-stress and exhilaration.

Enjoy!

--
Publisher : Banpresto
Release   : August 2, 2002
