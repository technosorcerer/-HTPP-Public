Super Ghouls 'N Ghosts - Maiden Hack (USA, Europe) v1.1 - by GoodLuckTrying (https://github.com/GoodLuckTrying)

This is a Super Ghouls 'n Ghosts (USA, Europe) sprite hack that changes Arthur's sprites into those of a Maiden.

Survey to determine preferred version: https://forms.gle/6TnRSPFfntWedo8n7

Version 1.1 Changes:
- Incorporated the shield back and made a new idle pose that fits it better.
- New patch added to restore both the original pose and basket.
- Fixes to some sprites.
Version 1.0 Changes:
- 4 versions alternating between starting armor/dress and briefs/nightgown.
- Dress, Gray, Purple and Gold Armor will have unique sprites for the item drop.
- Magician will have unique visuals for the player for all 4 transformations.
- Every costume (But the Nightgown/Briefs/Baby Transformation paired with the Gray Armor, these will have dark gray yes) will have blue eyes.
- Extra patch to replace basket with shield if desired.

Versions:
Maiden Edition [Briefs + Dress + Armor].ips
0: Briefs
1: Dress
2: Purple Armor
3: Gold Armor
Maiden Edition [Briefs + Full Armor].ips
0: Briefs
1: Gray Armor
2: Purple Armor
3: Gold Armor
Maiden Edition [Nightgown + Dress + Armor].ips
0: Nightgown
1: Dress
2: Purple Armor
3: Gold Armor
Maiden Edition [Nightgown + Full Armor].ips
0: Nightgown
1: Gray Armor
2: Purple Armor
3: Gold Armor
Replace Basket with Shield.ips

Rom Information: Super Ghouls'n Ghosts (USA, Europe)
Database: No-Intro: Game Boy Advance (v. 20210227-023848)
File/ROM SHA-1: 31E7D1D405185BA2D7A9FFCC2B847D4457088CF0
File/ROM CRC32: 1EF2ACF3

Tools used:
- Tlp
- Tilemolester 0.21
- HxD
- ImHex
- Photoshop
- GIMP

Credits:
poody - Hacker behind the first version of the girl hack.
SfcStuff - Hacker behind the Japanese version of this armored hack.