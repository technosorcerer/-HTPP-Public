These IPS files can be used to change the instruments in Super Mario Advance 2: Super Mario world
to make them sound more like the SNES version of the game

=== Requirements ===
- A Super Mario Advance 2: Super Mario world rom
- Lunar IPS Tool

=== Usage ===
You can decide whether you want the restored Yoshi Bongo sound, or the lower pitched horn, or both.

Simply open up 'Lunar IPS' and click 'Apply IPS Patch'.
Select one of the IPS files and then select your Super Mario Advance 2 rom.
Your rom should now be patched to use the new instrument sample, enjoy!