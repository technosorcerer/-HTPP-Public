This hack is so special for me, because i have to investigate a lot about sma2 coding
(almost 3 years), so enjoy this little hack, in the future i wish make lots of sma2 hacks.
This hack was maked using the smallhacker's transplant tool, lunar magic, a little bit of hex coding
and a lot of time.

I am happy because I belive that this micro-hack is the first step to make a great project if you can help. I hope you have read this.

												-oquendo.