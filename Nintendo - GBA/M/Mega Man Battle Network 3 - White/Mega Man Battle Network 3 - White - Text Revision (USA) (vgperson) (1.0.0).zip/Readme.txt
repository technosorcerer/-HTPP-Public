Mega Man Battle Network 3: Translation Revision
by vgperson

This is a patch for Mega Man Battle Network 3 Blue/White that aims to generally improve the quality of the English script while mostly keeping to the original localization.

For clarity, things this patch does NOT do:
- It does not retranslate everything from scratch; it is working off the base of the original English script, retaining lots of text that didn't warrant changing and most localization decisions.
- It does not, for the most part, change any localized names/terms to their Japanese ones (Netto, RockMan, Electopia to Japan, etc.). See further down for a few arguable exceptions.
- It does not change the font to be variable-width or expand character limits, so the abbreviated names for things like chips and items are generally untouched.
- It does not change localized jokes and the like (such as with the Humor program) to more literal translations.
- It does not restore the jack-in and Navi Customizer animations cut from the English version, or add in any bonus content in general.
- It does not modify the gameplay itself in any way.

What this patch DOES do is fix and improve many lines, the result of a more or less full script comparison with the Japanese text.

In general, this patch:
- Fixes typos and other text mistakes.
- Improves strange or incorrect wording resulting from a lack of context.
- Retranslates numerous lines that were missing details or nuances, or were outright mistranslated.
- Overall edits the script as a whole to read better.
See below for a more detailed list of how the text has been revised.

Also, two small changes are made to the font: using a larger (2x2-pixel) period character like in MMBN1 and 2, and making a new bottom-aligned ellipsis character.

----------

Usage:

There are two patches for the two versions of the game: MMBN3Revision-Blue.ips and MMBN3Revision-White.ips.
Apply the patch for the corresponding version to a clean dump of the North American release of the game, using an IPS patcher such as Lunar IPS.
You may want to make a copy of the ROM file to apply the patch to, and keep the original intact.

Some emulators also support patch loading without directly modifying the original file.
In mGBA, giving the ROM and IPS patch the same name should automatically apply the patch, or you can load the patch after loading the game from the File menu.

----------

Notable edits made to the script:

- Retranslated all sorts of text to add missing detail from the Japanese.
- Fixed some hints that were lost or not as clear in translation, such as "the back pillars," "where evil falls," and the Haniwa statue "puzzle."
- Added normal ending punctuation to all environmental check dialogue.
- Standardized ellipses to use the bottom-aligned ellipsis character. Ellipses with pauses in-between use regular periods (replacing centered dots in some cases).
- Aimed to standardize and improve the way text is formatted in general.
- Fixed Legends references: "Kasket Kids" to "Caskett Kids," "Family Boone" to "Family Bonne," and Yai's "data doll" to "Data doll."
- Changed references to Serenade to use gender-netural language, in line with comments from Masakazu Eguchi.
- Restored a few Japanese cultural references; most obviously, "gin rummy" is now "mahjong" (itself a bit of a localization of the less recognizable "donjara," a variation meant for kids).
("Corn-on-the-cob" was kept, mostly because the graphics had been edited for it, and also it's kind of funny.)
- Fixed the 4-panel gambling game's final reward displaying the wrong chip code (but still giving you the right one).

Character name changes:

- Program -> Mr. Prog (localized name from later games, when appropriate)
- Glide -> Glyde (in line with Legends series)
- FlamMan -> FlameMan (no idea why it wasn't always this)
- Cossak -> Cossack (in line with classic series, no clear reason for spelling it different)
- JapanMan -> YamatoMan (in line with classic series, and original name from Japanese version)
- Anna Mori -> Anna Morishima (original full name from Japanese version)
Also, the one-off instance of "Shun" instead of "Sean" was fixed.

Other than the above, I kept all localized names, as de-localization isn't one of my aims with this; familiarity for English fans is more important here.
But here are some notes on names just for fun. (This contains some spoilers if you haven't played the game before.)

- Yai's name is shortened from her Japanese name, Yaito (last name Ayanokoji).
- Ms. Mari's name is shortened from her Japanese name, Mariko.
- Dex's Japanese name is Dekao, and Chisao's name is play on that: "deka(i)" means huge, and "chiisa(i)" means small. Ideally, they would have localized this to something clearly playing off "Dex," but I didn't see a point in me doing that here.
- Tora's name is shortened from his Japanese name, Torakichi (last name Aragoma), and in his first appearance, he calls himself the "tiger (tora) of Swapopolis."
- People sometimes call Lan's dad by his first name Yuichiro, but this was always localized to things like Lan's mom calling him "honey" or most others calling him "Dr. Hikari," to avoid confusion from players who might not realize that's his first name.
- The BBS message that brings up "the inventor of the PET, the father of the creator of MegaMan," in Japanese, actually mentions him by name as Tadashi Hikari prior to the name otherwise coming up in the story.
I could've added that back in, but because Yuichiro doesn't get named in English, I could've seen it resulting in confusion, maybe even thinking that Lan's dad was named Tadashi.
- Ura Inn and Mamoru's last name Ura were shortened from "Urakawa." The Undernet is also called the "Ura (back/undersurface/reverse side/etc.) Internet" in Japanese, so the throughline there was sort of lost.

----------

Credits:

Script extraction and insertion done using Prof. 9's TextPet.
https://github.com/Prof9/TextPet

Font modifications made using YY-CHR.
https://www.romhacking.net/utilities/119/

All other editing and translation work done by vgperson.