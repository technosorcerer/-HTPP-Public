"Marvel Ultimate Alliance"
Traducción al Español Ver. 1.1 (27/08/2023)
por Max1323 (Traducciones Max1323).
---------------------------------------------------
Descripción:
Crea a tus cuatro mejores miembros con los 15 personajes
legendarios de Marvel. Luego pelea como tus héroes
favoritos, en las feroces batallas contra el mal en 
este épico RPG de acción.

Desarrollado: Barking Lizards
Publicado:    Activision
Lanzamiento:  24/10/2006 (USA)
	      03/11/2006 (EUR)
---------------------------------------------------
Acerca del proyecto:
-La mayoría de los textos están traducidos.
-Los acentos ya estaban agregados y fueron usados.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS (PC)
Utilizar UniPatcher (Android)

Archivo IPS
Marvel - Ultimate Alliance (USA).gba
File Size     8.00 MB
File MD5      1A9CC177B098FA1762B0E9872590916C        
File SHA-1    FE621B8D156B85ED2EE77DBC1D2B84D16F330E67
File CRC32    A74294DB