"Max Payne"
Traducción al Español Ver. 1.0 (20/12/2024)
por Max1323 (Traducciones Max1323).
---------------------------------------------------
Descripción:
Max Payne es un implacable juego con una trama potente acerca de un hombre que vive al límite y lucha por lo que cree que es justo mientras descubre giros argumentales y matones retorcidos en las entrañas de Nueva York durante la peor ventisca del siglo.

Desarrollado: Mobius Entertainment
Publicado:    Rockstar Games
Lanzamiento:  16/12/2003 (USA)
	      19/03/2004 (EUR)
---------------------------------------------------
Acerca del proyecto:
-La mayoría de los textos están traducidos. 
El juego ya contaba con los caracteres españoles.
-Esto más bien no sería una traducción completa de mi parte, ya que los textos son sacados de la traducción oficial. Por mi parte solo pude traducir el menú y algunos textos que no se encontraban en la traducción oficial.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS (PC)
Utilizar UniPatcher (Android)
Utilizar Rom Patcher (Parcheador Online):
https://romhackplaza.org/patch/

Archivo IPS
Max Payne (USA).gba
File Size     16.00 MB
File MD5      7B79AD84814D56986566F49AB9DE6423        
File SHA-1    BC242869661602E918B880850DFCC4EED7B43617
File CRC32    296E1092