Mega Man Zero 3 e reader edition GBA By Kevin Hacks

e-Reader content added to the game:


The character Andrew is now younger and has a secret dialogue box.

A new room has been added next to Andrew.

New design for the Buster Shot bullets.

New design for the Life Container.

New design for the E-Crystals.

New design for the Secret Discs.

New design for the Z Panel (in-game lives).

New design for the Hacker Elf.

New design for the Nurse Elf.

New design for the dialogue box.

New design for the elevator in the base.

New PC in Ciel's room.

New title screen.

Mega Man EXE enemies added to the game (only appear in cyberspace).



Hello, I hope you like this hack that I made with a lot of effort. Share it with your friends. If you're going to publish it in a group or page, please give me the credit.

This hack adds some e-reader content to the Mega Man Zero 3 game. I made this hack because the e-reader content of Mega Man Zero 3 isn't very well-known outside of Japan.




