Mega Man Zero 3 - Zero as MMX1 Zero v1.0 - by GoodLuckTrying (https://github.com/GoodLuckTrying)

This hack modifies the American release of Mega Man Zero 3.

Changes:
- Zero is now replaced with Zero’s original MMX1 design.
- A patch is included that makes Omega retain its MMZ visuals, so it turns into X1 Zero vs MMZ Zero for the finale.

Files:
- Mega Man Zero 3 [Zero as X1 Zero).ips
- Mega Man Zero 3 [Zero as X1 Zero).bps
- Mega Man Zero 3 [Zero as X1 Zero, Omega as MMZ Zero)
- Mega Man Zero 3 [Zero as X1 Zero, Omega as MMZ Zero).bps

Credits to Ray Tsai for the X1 Zero sprites.

Base Rom: Mega Man Zero 3 (USA)
Database: No-Intro: Game Boy Advance (v. 20210227-023848)
File/ROM SHA-1: 403A78F2CAD93D41E4B0F2E520CE08026531664B
File/ROM CRC32: 2784F3F2