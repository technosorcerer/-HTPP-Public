Thanks for downloading Mario Kart R Advance!
Patch over an US rom.

The original hack (for Super Mario Kart) was made by
d4s in 2004, so check it out if you haven't!
Link to the original hack: https://www.romhacking.net/hacks/162/

If you have any issues or glitches with the hack, message me on discord: @blueyoshi57, youtube: @BlueYoshi or in the Advanced Mario Kart Hacking Server: https://discord.gg/VaCJwbExyp
In particular, extra tracks should be unlocked by default but it might be a tad unstable.


What is and is not in the game (compared to mkr)
All tracks were remade (layout, palettes)
Coin placement was ajusted when it went over walls or boost panels...
Menus and title screen were modified

Kirby is not present (nor koopa)
Battle tracks are not here but they might be added in a future update


!!!!!SPECIAL THANKS to...!!!!!
...dforce3000 for the original hack = layout, palettes, sprites, etc

...8-NabBit for various tools and documents, the current modding server, and the help he provided to this project

...blackman1467 for the original hacking server, and for helping a lot with MKSC hacking in general - check out his hack Mario Kart Super Circuit Deluxe (more info in the hacking server or on his youtube)! 

...Dirtbag and R4M0N for the hacking spreadsheet

...Stifu for Epic Edit

...Nintenlord for NLZ-GBA Advance and NL's Compressor

...the VBA and mGBA teams for emulators and various gba tools

...YY-CHR and HxD teams

...Cracker for GBAATM

+++++Changelog++++++
v1.0 (19 oct 2023)
-Original release

v1.1 (20 oct 2023)
-Fixed a bug where the wrong track would play in a Grand Prix
-Cup selection is limited to the extra cups