Thanks for downloading the SNES battle course restoration hack for MKSC by BlueYoshi_57EML!
This is just a simple hack that replaces the GBA battle courses with the SNES battle courses, which were originally
cut from the game, fixing the bugs that they originally had.
Patch the hack to a US version of the game.
If you have any problem playing the hack, contact me on YouTube: @BlueYoshi or on Discord: @blueyoshi57

Changelog:
v1.0 (27 jan 2024)
Initial release