-----------------------------------------------------------
| Mario Kart: Super Circuit - Mario Kart 64 Yoshi's Voice |
|                   v1.0 by Mister Man                    |
-----------------------------------------------------------
| Introduction                                            |
-----------------------------------------------------------
Mario Kart: Super Circuit reuses most voice samples from the Japanese version of Mario Kart 64. One notable exception is Yoshi, who instead uses his voice samples from Yoshi Story.

This hack replaces Yoshi's voice samples with the ones from Mario Kart 64, which were based on the ones from Super Mario World.

Note that this hack is also compatible with other sound-related hacks, like Emilianomario27's "Localized Voices" hack and RunTheCoins' "Music Restoration" hack.

-----------------------------------------------------------
| Changelog                                               |
-----------------------------------------------------------
| v1.00                                                   |
-----------------------------------------------------------
* Initial release

* Replaced Yoshi's voice samples with the ones from Mario Kart 64 (Nintendo 64).

-----------------------------------------------------------
| Patching                                                |
-----------------------------------------------------------
To apply these patches, any program that supports the IPS patch format (like LunarIPS) is required.

Below you can find the patch's name and which versions of the game is it compatible with:

* "MKSC - MK64 Yoshi Voice_JPN.ips"
  * Mario Kart Advance (Japan)
  * Mario Kart Advance (Japan) (Virtual Console)
  * Mario Kart Advance (Japan) (3DS Virtual Console)

* "MKSC - MK64 Yoshi Voice_World.ips"
  * Mario Kart - Super Circuit (USA)
  * Mario Kart - Super Circuit (USA) (Virtual Console)
  * Mario Kart - Super Circuit (Europe)
  * Mario Kart - Super Circuit (Europe) (Virtual Console)
  * Maliou Kadingche - Chaoji Saidao (China) (Proto)

-----------------------------------------------------------
| Tools Used                                              |
-----------------------------------------------------------
* FlexHEX
* Audacity
* LunarIPS
* mGBA

-----------------------------------------------------------
| Special Thanks                                          |
-----------------------------------------------------------
* SCD: Besides giving the idea for the hack, provided me the relevant voice clips for usage in this hack.