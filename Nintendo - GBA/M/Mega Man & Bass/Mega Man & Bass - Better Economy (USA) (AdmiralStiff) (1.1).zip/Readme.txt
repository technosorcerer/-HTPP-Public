MEGAMAN & BASS (GBA)

-------------------------------------------------
MEGAMAN & BASS Better Economy (GBA).ips:

-Increases BOLT gain by 60%
-Changed prices from shops
-Shop dialogue has been corrected/adapted
-I. PRESENT is now a permanent item
-------------------------------------------------

:::::::::::::::::
::Hacking Notes::
:::::::::::::::::
Current BOLTS Holding [RAM address]
201632E

Start Instruction: 1C8F6 (for bolt get? I forgor)
-------------------------------------------------
Big BOLT [ROM address]
2FDC6

Small BOLT [ROM address]
1C9DA

Medium BOLT [ROM address]
1C9E2
-------------------------------------------------
Ball Persists deaths and gameovers
3370 [ROM Address, sets value(?)]
1070 -> 46C0 [Changed instruction to "do nothing"]

Ball Persists EXIT and CLEAR
332A [ROM Address, sets value(?)]
1070 -> 46C0 [Changed instruction to "do nothing"]
-------------------------------------------------
Rock's Shop
Original shop table [ROM values]
32 00 78 00 32 00 0A 00 64 00 3C 00
32 00 C8 00 C8 00 32 00 96 00 64 00
C8 00 2C 01 2C 01 C2 01 96 00 2C 01
64 00 2C 01

Modified shop table [ROM values]
32 00 B4 00 32 00 1E 00 64 00 78 00
32 00 2C 01 C8 00 32 00 96 00 64 00
FA 00 96 00 2C 01 2C 01 C2 01 2C 01
64 00 96 00
-------------------------------------------------
Bass' shop
Original shop table [ROM values]
32 00 78 00 32 00 0A 00 64 00 3C 00
32 00 C8 00 C8 00 64 00 64 00 C8 00
C8 00 2C 01 2C 01 2C 01 2C 01 64 00

Modified shop table [ROM values]
32 00 B4 00 32 00 1E 00 64 00 78 00
32 00 2C 01 C8 00 2C 01 32 00 2C 01
FA 00 96 00 2C 01 C2 01 2C 01 64 00
-------------------------------------------------
end