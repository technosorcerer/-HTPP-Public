@size 17

script 0 mmbn4s {
	"DOUBLE DELETE!"
	end
}
script 1 mmbn4s {
	"TRIPLE DELETE!"
	end
}
script 2 mmbn4s {
	"VS"
	end
}
script 3 mmbn4s {
	"TIME UP!"
	end
}
script 4 mmbn4s {
	"    1   "
	end
}
script 5 mmbn4s {
	"    2   "
	end
}
script 6 mmbn4s {
	"    3   "
	end
}
script 7 mmbn4s {
	"    4   "
	end
}
script 8 mmbn4s {
	"    5   "
	end
}
script 9 mmbn4s {
	"    6   "
	end
}
script 10 mmbn4s {
	"    7   "
	end
}
script 11 mmbn4s {
	"    8   "
	end
}
script 12 mmbn4s {
	"    9   "
	end
}
script 13 mmbn4s {
	"   10   "
	end
}
script 14 mmbn4s {
	" COUNTER HIT! "
	end
}
script 15 mmbn4s {
	"LEFT "
	printBuffer
		buffer = 0
		minLength = 2
		padZeros = false
		padLeft = true
	" "
	end
}
script 16 mmbn4s {
	"LEFT  0 "
	end
}
