Mega Man Battle Network 4: Translation Revision
by vgperson

This is a patch for Mega Man Battle Network 4 Red Sun/Blue Moon that aims to generally improve the quality of the English script while mostly keeping to the original localization decisions.

For clarity, things this patch does NOT do:
- It does not retranslate everything from scratch; it is working off the base of the original English script, retaining text that didn't warrant changing and most localization decisions.
- It does not, for the most part, change any localized names/terms to their Japanese ones (Netto, RockMan, Electopia to Japan, etc.).
- It does not expand character limits, so the abbreviated names for things like chips and items are generally untouched.
- It does not change localized jokes and the like (such as with the Humor program) to more literal translations.
- It does not fix gameplay bugs, or modify the gameplay itself in any way.

What this patch DOES do is fix and improve many lines, the result of a more or less full script comparison with the Japanese text.
It revises much of the game's translation, both addressing basic typos and other text mistakes from the original, as well as catching many mistranslations and missing nuances.
See below for a more detailed list of how the text has been revised.

Also, a few small changes are made to the font: using a larger (2x2-pixel) period character like in MMBN1 and 2, making a new bottom-aligned ellipsis character, and a more normal positioning for the "j."

----------

Usage:

There are separate patches for the two versions of the game: MMBN4Revision-RedSun.ips and MMBN4Revision-BlueMoon.ips.
These are the default patches, in which Mr. Progs speak with normal capitalization like they do in the Battle Network 1-3 localizations.
However, also provided for each game version is a PROG (Preserve Resizing Of Glyphs) patch, which has them speak in all-caps like in the original Battle Network 4-6 localizations.

Apply the desired patch for the corresponding version to a clean dump of the North American release of the game, using an IPS patcher such as Lunar IPS.
You may want to make a copy of the ROM file to apply the patch to, and keep the original intact.

Some emulators also support patch loading without directly modifying the original file.
In mGBA, giving the ROM and IPS patch the same name should automatically apply the patch, or you can load the patch after loading the game from the File menu.

----------

Notable changes made to the script:

- Retranslated all sorts of text to fix mistranslations and add missing detail from the Japanese.
- Standardized ellipses to use the bottom-aligned ellipsis character. Ellipses with pauses in-between use regular periods (replacing centered dots in some cases).
- Aimed to standardize and improve the way text is formatted in general. The original very often broke up text across boxes in awkward ways - this tries to do so less often and more naturally.
- Where possible, fixed abbreviation of names and terms in situations where they didn't need to be abbreviated, at least to that extent (particularly SerchMan -> SearchMan and BurnMan -> BurnerMan).
- Though the Japanese text was similarly vague about this, made it a bit more clear that "sacrificing" chips for DublSoul does not mean permanently losing them.

Notable name changes:

- MelSquare -> TaleSquare (Was "Meruhien," a corruption of "meruhen (Märchen)," the German word for "fairy tale" which is often used to refer to that kind of theming in Japanese.)
- WizMonkey -> WizCat (Likely the whole reason for him being a monkey was because of a Japanese phrase akin to "like cats and dogs," making for an awkward discrepancy. See below for more details.)
- Scissor Island -> Alohaha (The relocalized name from Mega Man Star Force 3. "Scissor" came from reading "shiisaa" literally, when it's in reference to Okinawan statues named "shisa.")
- Glide -> Glyde (In line with the Legends series.)

Miscellaneous notes:

- The hotdog stand was a takoyaki stand in Japanese. They put a fair bit of effort into that localization, changing the graphics and, in the case of the SparkMan scenario, a puzzle solution.

- Nanako usually refers to herself in the third person in Japanese (likely putting it on to sound cute), which makes it easier for the player to know her name for the quiz in GutsMan's scenario.
(Side note: when you find her working at Castillo, she doesn't say her name in third person, which may support the idea it's just a thing she does at Higsby's.)
In English, her name only appears a handful of times, like early on when she's hired, or in NumberMan's scenario (though that's normally a Blue Moon exclusive, while GutsMan's is Red Sun exclusive).
If you miss those few mentions, there's not really an in-game way to find out, leaving you to just guess.
I could've tried to address this, but it didn't seem worth making some lines sound less natural for a relatively minor issue.

- I opted to change AquaMan's tic to "drip" to match the BN6 localization, and since it just sounds better as one to me.
That said, the original "woosh" was more true to the Japanese complaint about the washing machine, but dripping works there too - whether that was even considered when they changed it in BN6, who knows.

- Lan not making the connection that TopMan might be the Navi of the old man who makes tops is... at least slightly less silly in Japanese, I think.
The main reason seems to be that his name is written "TappuMan," as in the English word "top," while tops are just called "koma" in Japanese.
Using the word "tappu" for "top" is not common in Japanese at all (and more suggests "tap"), so it's reasonable that someone wouldn't recognize it as the English word for "koma."
(Incidentally, the English word "top" in the sense of "the best/highest" IS quite common in Japanese, where it is instead written as "toppu.")

- Yuko calls Lan "onii-chan" pretty much exclusively, which can be either "big brother" or something akin to "mister" depending on context.
Her scenario obviously blurs the line between these, as it's not like she's immediately deciding Lan's her big brother, yet it reinforces the idea of them becoming like siblings.
It's also why all the NPCs after the scene where they play tag can only assume she's Lan sister, because she was calling him "onii-chan" constantly.
Since this doesn't work the same way in English, she just calls him "mister" or his name, and filled some gaps with the sister assumptions.

- There's a particular detail the Japanese version was consistent about, but that the original translation switched up at times:
The ghosts in Yuko's scenario are called "Navi ghosts," while the refight Navis, noted as being immune to CyberSutras, are called "ghost Navis" ("yuurei" in both cases, so the order is the only distinction).

- In Japanese, Lan recognizes Tetsu as an archetypal "bancho" when they first meet. (The original translation both fumbles this context, and words it like Lan is recognizing him as a particular person.)
This is why it does the joke of playing the sound of his geta sandals as he walks off.
Just using the word bancho wouldn't fit with the general localization style, so I landed on Lan calling him "a real-life honorable delinquent" (with the already-present context of being a manga archetype).

- Castillo's original full name was Cielo Castillo, Spanish for "castle in the sky." MegaMan comments on this meaning in the description on the map, as do some NPCs.
This is also part of why the Castillo stadium is "AirStadium" (in the sense of "up in the air"); I opted to retranslate it as "SkyStadium" to make that a little more evident.

- The reason the WizDog story originally had a dog and monkey being rivals is because of the Japanese phrase "ken-en no naka," basically "getting along like a dog and monkey."
The equivalent in English would be "like cats and dogs," so that's how the phrase in the story was translated - yet since "WizMonkey" was not localized accordingly, it had an incongruous result.
I did worry it might cause some confusion, as "WizCat" was originally included as an incorrect answer. But ultimately I went for it, as the other character is never depicted, and no details even had to change.

- When Atsuki talks about "driving a Fire Float" at a festival, that's a localization of him carrying a mikoshi, a portable shrine that gets carried around in Japanese festivals.

----------

Credits:

Script extraction and insertion done using Prof. 9's TextPet.
https://github.com/Prof9/TextPet

Font modifications made using YY-CHR.
https://www.romhacking.net/utilities/119/

All other editing and translation work done by vgperson.