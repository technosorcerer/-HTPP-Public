The UPS patch file can be applied with Tsukuyomi UPS Patcher, which you can find on this very site 
(aka Romhacking.net), NOTE: The patch should ONLY be applied to Mother 3 ROMs that have been patched 
with version 1.2 of the English Translation. DO NOT try to patch a Japanese Mother 3 ROM with this hack, 
it will cause many errors and issues if you do.


As for the differences between the versions, here are the main changes:

"Normal" Version barely changes the gameplay at all, the only thing that is changed is Claus learns
PK Thunder and Kumatora does not, but they learn all the other PSI they regularly have. This is to provide
an experience for people who only want to experience the story and not gameplay changes.

"Moveswap" Version swaps the PSI movesets Claus and Kumatora learn in the "Normal" version (except for PK Thunder),
that stays with Claus. So Kumatora will learn all the Defensive/Support PSI like Lifeup and Offense/Defense Up,
while Claus will learn all the Offensive/Debuff PSI like Offense/Defense Down and PK Freeze/Fire.

"Combined PSI" version makes the PSI movesets of Claus and Kumatora similar to those of Paula and Poo from the 
previous game Earthbound. What that means is, both Claus and Kumatora learn a fair amount of both offensive AND
defensive PSI, which radically changes up how you can play the game and strategize. For example, both Claus
and Kumatora now learn PK Freeze (Claus only learns up to Gamma level) and can use it in fights, and Claus
has only Psychic Shields/Counters he can cast, and Kumatora has only Physical Shields/Counters she can cast.

All 3 versions have been balanced to work in Normal Mode AND Hard Mode, and the game is balanced for a player
who does not grind too much, but usually fights all the enemies they meet along the path.
(For those of you who do not know, Hard Mode is activated by naming yourself, The Player, into "HARD MODE". This
was not added by me and is a bonus added into the original English Translation.)

EDIT: In this new, finalized version of the hack, version 1.04, there are 2 major changes that affect
certain parts of the game. First is, the toilet dungeon and Porky's mini games now have added dialogue
that weren't in the original hack, as they got cut from the files by accident as I tried to keep
track of the 3 different versions. There is also polished up dialogue in the final battle and 
other areas of the game. Secondly, there is a gameplay change that applies to all versions of the hack.

I altered the King Porky Statue boss to have a decent amount of HP to the point that he can be defeated normally
(for the Combined PSI version he has 10,000 HP, for the Moveswap/Normal versions he has 8,000 HP, due to
how much stronger your characters are in the Combined PSI version by sheer future of having 2 good healers AND
PSI attackers.)

I made it so you can no longer use a New Years Eve bomb to destroy the boss, you'll have to fight and beat him 
normally if you want to win. I made it so he gives slightly more Experience as a reward, as well as either
Lucas or Kumatora's Ultimate Weapon as a prize too (it's a 50/50 chance, I'd have edited it so you get both weapons
at once as rewards, but M3's code makes it so you can only get one item reward at a time from battle, sadly.
If you don't get the weapon you want, you could always reload the game and try again).
If you already have both Ultimate weapons though, I made it so you can sell the 2nd ultimate weapon for a hefty
amount of DP as compensation.

If you need help patching the ROM, or just want to talk and ask questions, feel free to contact me on discord,
my username is spiderfreak1011#5510. Hope you fellow Mother 3 fans have fun with this finalized version of the
patch, which has some bonus and polished dialogue changes that the new one doesn't. ;)