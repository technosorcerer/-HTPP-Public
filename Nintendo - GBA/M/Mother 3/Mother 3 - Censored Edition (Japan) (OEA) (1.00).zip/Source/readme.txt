See the online documentation on how to use these tools and files.

http://mother3.fobby.net/tools/