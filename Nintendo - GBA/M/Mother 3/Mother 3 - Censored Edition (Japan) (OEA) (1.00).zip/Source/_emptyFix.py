# This script has already been run, do NOT run it again.

# Basically, this source code combines the 1.3 Translation Patch source files with the ones it is missing from the translation tools, and the text files
# from the latter had empty translation strings (because you're supposed to fill them in yourself). Since this hack mostly does not modify the English
# translation, I made this script to copy the "original" lines in said text files over to the translation lines.

# Usage: Run "python3 _empty.fix.py" to change the files. This will make backups of the original; if something in the process goes wrong, you can (and
# indeed must) run "python3 _empty.fix.py -r" to remove the new files and rename the backups to the original names.

import os
import sys

def allButFirst(s, lim):
    temp = list(s.split(lim)).copy()
    s2 = ""
    if (len(temp) > 1):
        for i in range(1, len(temp)):
            s2 = s2 + temp[i] + lim
        s2 = s2[0:-1]
    return(s2)

bad = []
if ((len(sys.argv) > 1) and (sys.argv[1] == "-r")):
    ext = ".bak"
else:
    ext = ".txt"
for root, dirs, files in os.walk("./"):
    for file in files:
        if (file.endswith(ext) == True):
            try:
                f = open(file, "rt")
                r = f.read()
                f.close()
                if (("-E: \n") in r):
                    bad.append(file)
                    print(file)
            except:
                pass

for fi in bad:
    out = []
    curr = ""
    if ((len(sys.argv) > 1) and (sys.argv[1] == "-r")):
        os.remove(fi.replace("_BACKUP.bak", ".txt"))
        os.rename(fi, fi.replace("_BACKUP.bak", ".txt"))
        # pass
    else:
        f = open(fi, "rt")
        r = f.read()
        f.close()
        lines = list(r.split("\n")).copy()
        for i in range(len(lines)):
            if ((lines[i] == "") or (":" not in lines[i]) or (lines[i][0:2] == "\\\\")):
                out.append(lines[i])
            elif (("-E:") not in lines[i]):
                curr = allButFirst(lines[i], ":")
                out.append(lines[i])
            else:
                out.append(lines[i].strip() + curr)
        os.rename(fi, fi.replace(".txt", "_BACKUP.bak"))
        new = open(fi, "at")
        for i in range(len(out)):
            new.write(out[i])
            if (i != (len(out) - 1)):
                new.write("\r\n")
        new.close()
