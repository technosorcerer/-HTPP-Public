# M3_Overworld_Debug_Menu
Repository for development of a "Overworld Debug menu enabling" Mod for M3

The idea is to make it so if you're holding a certain combination of buttons while loading a room(Select+Start),
the overworld debug menu is enabled.

You can then press R and L to switch between having control of the debug menu or the characters.

To build, place a ROM named mother3.gba in the folder with these files, then use i.bat.
