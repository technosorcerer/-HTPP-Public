Mega Man Battle Network 2: Translation Revision
by vgperson

This is a patch for Mega Man Battle Network 2 that aims to generally improve the quality of the English script while mostly keeping to the original localization.

For clarity, things this patch does NOT do:
- It does not retranslate everything from scratch; it is working off the base of the original English script, retaining lots of text that didn't warrant changing and general localization decisions.
- It does not change any localized names/terms to their Japanese ones. (Netto, RockMan, Electopia to Japan, etc.)
- It does not change the font to be variable-width or expand character limits, so the abbreviated names for things like chips and items are generally untouched.
- It does not modify the gameplay itself in any way.

What this patch DOES do is fix and improve many lines, the result of a more or less full script comparison with the Japanese text.

In general, this patch:
- Fixes typos and other text mistakes.
- Improves strange or incorrect wording resulting from a lack of context.
- Redoes a lot of the questionable/broken-English dialogue for many "foreigner" characters.
- Retranslates numerous lines that were missing details or nuances, or were outright mistranslated.
- Overall edits the script as a whole to read better.
See below for some more details on how the text has been revised.

As a disclaimer: while this aims to curtail culturally-offensive dialogue from the original translation, certain things are just part of the plot or otherwise beyond the reach of a script edit.
Thus, be aware there are still some cultural stereotypes and xenophobic undertones (as you may know if you've played the game before).

----------

Usage:

Apply the patch (MMBN2Revision.ips) to a clean dump of the North American release of MMBN2, using an IPS patcher such as Lunar IPS.
You may want to make a copy of the ROM file to apply the patch to, and keep the original intact.

Some emulators also support patch loading without directly modifying the original file.
In mGBA, giving the ROM and IPS patch the same name should automatically apply the patch, or you can load the patch after loading the game from the File menu.

----------

Notable edits made to the script:

- Retranslated all sorts of text to add missing detail from the Japanese.
- Fixed some hints that were not as clear in translation.
- Added an ellipsis character to help save space in messages. Ellipses meant as long pauses still use regular periods.
- Aimed to standardize and improve the way text is formatted in general, and cut down on odd hyphenation of linebroken words.
- Changed "Glide" to "Glyde" to be in line with the Legends series.
- Reverted a few localized names on the BBS to match ones that return in BN3: "Kiddo" to Koetsu, "Candy" to Amayan, "Mr.beLLz" to "Mr.Beltz" (though it is just "Beltz" in BN3, so they could be different).

Miscellaneous translation notes (contains some spoilers):

- "The" Square (in Den Area) is known as "Official Square" in Japanese; there were a few uses of this name even in the original English, which could've made it seem like a separate thing.
The shortening is understandable since it's often unwieldy for text space reasons, but there needed to be a proper name for it when people in other areas were talking about "Official Square" and not their local Square.
So I brought the Official Square name back in select places to (hopefully) clearly establish it as its... well, official name, so it could then be used in such cases.
I considered having it be called "Den Square," which would be more in line with later games, but this could seem odd (albeit maybe a believable detail, and already present with Den/Koto Area) considering Kotobuki, which has its own Square, is also part of DenCity.

- There's a bunch of weirdness around the names of Count Zap (from BN1) and Gauss in localization. They're brothers, but things aren't very clear from this game alone.
Gauss mentions his brother "Jack," and the Quiz King reveals said brother's full name as "Jack Electricity" in the original English (it's more like "Elecitel" in Japanese).
Count Zap's Japanese name is basically shortened from that last name, so Japanese players could more easily make the leap there.
The implication is Gauss changed his last name, but it's complicated by English releases swapping the name order from "Gauss Magnets (formerly Gauss Elecitel)" to "Magnus Gauss."
All this is to say I changed the Quiz King answer to "Jack Zap" so people could actually pick up on the connection, even if it's arguably a bit inaccurate.
("Ann Zap" in BN6 does seem to suggest the English localizers gave up on the detail of the "Zap" in Count Zap not being his actual last name.
If I were to reincorporate it, I'd probably make the family's actual last name "Zapelli," but using that for just this one instance would only be confusing.
Also amusing is that one of the wrong answers for the quiz question is "Ampere" Gauss - the same unit Ann Zap gets her name from, as it's written like "an-pe-a" in Japanese.)

- The quiz answers for the "popular Netopian robot cartoon" are all meant to be references to real mecha series: Gundam, Mazinger Z, and Getter Robo.
Specifically, in Japanese, they changed the first part of each name to "Amero" (from Netopia's Japanese name "Ameroppa," combining America and Europe), as well as changing Mazinger's "Z" to an "X."
I fixed some of the lost wordplay here (original English had "Rondam" and "RottaRobo," missing any context for why "Ro"), although "Ameronger Z" posed some difficulties.
Given the 8-character item name limit for the associated souvenir, and not wanting to change it too much to account for people looking at a guide for the quiz, I just went with "NetRoboX" instead of trying to force a reference.

- "ArmyData" is kind of a stretch of a translation; it's "SoldierData" in Japanese, with the description implying it's because a soldier "strives for the next rank" (or "promotion" in the original English).
I considered changing it to "SldrData" or something, but that's not very parseable and again could lead to confusion with guides.

----------

Credits:

Script extraction and insertion done using Prof. 9's TextPet and RockmanEXEZone's MMBNLC scripts.
https://github.com/Prof9/TextPet
https://github.com/RockmanEXEZone/MMBNLC-Scripts

All other editing and translation work done by vgperson.