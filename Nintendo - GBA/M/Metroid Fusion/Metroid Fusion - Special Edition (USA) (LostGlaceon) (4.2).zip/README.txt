--METROID FUSION: SPECIAL EDITION v4.2--
-Uses "Sequence Breaking Fusion" as a base.

--INSTALLATION--
-Patch is for the US version of the game.
-Simply apply it to the .gba file using any patcher that accepts .ips patches, such as Lunar Patcher.
-If you'd like to play with the hard mode patch, apply it your patched MFSE v4.2 rom.

--FEATURES--
-Much of the game recolored to give it a less overly-saturated (but still colorful) look.
-Better map screen and HUD graphics.
-More compact font (with text tweaks to center better with the width of said font).
-Bomb-jumping and single-wall wall-jumping reimplemented.
-Many new sequence breaks added (early Power Bombs are the most important step).
-Faster door transitions and elevators.
-Optional (and slightly customized) hard mode.
-Many small level design tweaks.
-Some old/unused content restored.
-You can stand on most of the computers (yes, really).

--CHANGELOG--
v1.0 - Initial Release
-First public release of the hack.

v2.0 - UI Overhaul
-Proper custom title screen.
-UI got a facelift in several areas.
-Map color palette changed to be a bit more inline with ZM for consistency while still remaining unique.
-Door softlocking fix WAS implemented, but the build I released was actually missing it.

v2.1 - Minor Patch #1
-Fix for the door transitions softlocking has been included this time.
-Changed the color of the minimap grid to match the map screen's grid.
-Added version numbering on the title screen.

v3.0 - Area 5/6 Update + Various Graphical Tweaks
-Area 5's blindingly vibrant icy areas have been toned down to a more realistic palette, while still remaining colorful.
-Area 6's lit-up caverns were changed to actually look dark, rather than being neon hell.
-The colors of Area 3's purple stone and metal was desaturated and adjusted slightly.
-All the broken doors had their color palettes changed to actually look like they should, rather than being overly faded for no good reason.
-Interactable floor panels (buttons?) in each room have been made consistent, rather than half being green while others are silvery.
-The silvery unused data room computer has been reimplemented, along with the beta ship cockpit BG.
-A certain set of unused rooms was readded to the Main Deck, each having a nice little bonus to collect.

v3.1 - Minor Patch #2
-Very minor level design changes.
-The "disco blocks" in Sectors 3 and 6 have been fixed.
-You can stand on ~80% of the computers in the game.
-SA-X can be damaged at any point with the charge beam for fun (good luck killing it, though).

v3.2 - Minor Patch #3
-Critical bug that prevents players from finishing the game fixed.
-More level design changes, some allowing secrets to be obtained earlier than usual.
-Updated design for the Missile/Power Bomb tanks.

v4.0 - New Sequence Breaks + Polishing Up
-Getting Space Jump early is now possible as long as you have Hi-Jump and have killed Nettori.
-Super Missiles obtainable without Speed Booster or Lv. 2 access.
-Wave Beam and Screw Attack can be obtained without ever even unlocking Lv. 3 doors (VERY challenging).
-Much easier to get 0%, as the difficult-to-avoid missile tank in Sector 3 has been moved to an optional spot in Sector 5.
-Many graphical changes (such as a nice location marker instead of a flashing white square).
-Some annoying small tiling errors were removed/changed.
-Credits and intro text edited to better fit the romhack.

v4.1 - Minor Patch #4
-Finally gave Sector 1's grassy caves a proper recolor.
-Dark areas are much darker, as they should be.
-Various other graphical and level design changes.
-MFSE now has an optional hard mode patch, which includes some extra changes.

v4.2 - Minor Patch #5
-More brand new map graphics.
-A few small shortcuts added.
-Fixed the missing changes in Zazabi's hard mode arena.

--CREDITS--
-Nintendo for creating the original Metroid Fusion.
-Kazuto for creating the "Sequence Breaking Fusion" hack that this is built on.
-Cosmic for making the original font and map tile graphics.
-Jumzhu for the sped-up room transitions patch.
-Raygun and Cpt. Glitch for a few .asm patches.
-Wildfire for helping me test it so many times that I lost count, along with giving me many fantastic ideas and suggestions.
-Lostglaceon (me) for doing most of the graphical and level editing work, reimplementing some cut content, and putting this hack together.