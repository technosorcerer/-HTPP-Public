--METROID FUSION: SPECIAL EDITION--
-Uses "Sequence Breaking Fusion" as a base.
-Redoes all the block palettes and combines several patches created by other people to make the "definitive" Fusion experience.

--INSTALLATION--
-Patch is for the US version of the game.
-Simply apply it to the .gba file using any patcher that accepts .ips patches, such as Lunar Patcher.

--CHANGELOG--
v1.0 - Initial Release
-First public release of the hack.

--CREDITS--
-Nintendo for creating the original Metroid Fusion.
-Kazuto for creating the "Sequence Breaking Fusion" hack that this is is built on.
-Cosmic for making the font and map tile graphics.
-Jumzhu for the sped-up room transitions patch.
-Raygun and Cpt. Glitch for a few .asm patches.
-Lostglaceon for doing the repalettes and adjusting the some of the text to fit better with the new font.