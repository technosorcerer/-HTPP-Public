--METROID FUSION: SPECIAL EDITION--
-Uses "Sequence Breaking Fusion" as a base.

--INSTALLATION--
-Patch is for the US version of the game.
-Simply apply it to the .gba file using any patcher that accepts .ips patches, such as Lunar Patcher.

--FEATURES--
-Palettes of all blocks (and a few specific sprites tweaked) to replace the maroon outlines with more fitting colorful ones.
-Completely redone map graphics.
-Visual tweaks to many parts of the UI.
-More compact font (with text tweaks to center better with width of said font).
-Bomb-jumping and single-wall wall-jumping reimplemented.
-Faster door transitions.

--CHANGELOG--
v1.0 - Initial Release
-First public release of the hack.

v2.0 - UI Overhaul
-Proper custom title screen.
-UI got a facelift in several areas.
-Map color palette changed to be a bit more inline with ZM for consistency while still remaining unique.
-Door softlocking fix WAS implemented, but the build I released was actually missing it.

v2.1 - Minor Patch #1
-Fix for the door transitions softlocking has been included this time.
-Changed the color of the minimap grid to match the map screen's grid.
-Added version numbering on the title screen.

--CREDITS--
-Nintendo for creating the original Metroid Fusion.
-Kazuto for creating the "Sequence Breaking Fusion" hack that this is is built on.
-Cosmic for making the font and map tile graphics.
-Jumzhu for the sped-up room transitions patch (and thank you to caauyjdp for providing a fix for all the crashes!).
-Raygun and Cpt. Glitch for a few .asm patches.
-Lostglaceon for doing the repalettes and adjusting the some of the text to fit better with the new font.