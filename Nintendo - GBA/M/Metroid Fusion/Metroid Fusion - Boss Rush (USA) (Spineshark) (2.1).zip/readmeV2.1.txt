Fight Metroid Fusion's bosses in a race against the clock.
Choose your own difficulty via optional item pickups.

Version 2 was built from scratch, using vanilla Fusion as a base.
The boss rooms were left unchanged, so the fights should be identical to vanilla.
Further changes from verion 1 include:
	-improved title screen
	-one second of in-game time is now 60 frames instead of 64
	-post credits screen shows in-game time with seconds
	-gadora has a proper door now
	-removed a potential BOX skip with shinespark
	-some smaller changes here and there

-SpineShark, April 2024


Version 2.1:
	-small graphical touch-ups
	-no gameplay changes


Credits:
biospark - MAGE & end screen seconds
Conner - "Conner MAGE"
Cpt.Glitch - Item Orbs ASM
Sapphron - Event Sprites ASM
biospark, somerando, interdpth - helping me with ASM
Metconst/MAGconst - hextweaks and general help

