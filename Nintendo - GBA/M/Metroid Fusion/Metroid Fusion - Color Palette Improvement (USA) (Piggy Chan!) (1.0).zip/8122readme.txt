

Being an early Game Boy Advance title, Metroid Fusion was designed with a bright, somewhat
blown out color palette in order to be more easily seen on the dark screen. This patch attempts
to give the game a darker color palette - in particular, effort was made to place the game in a
similar visual universe to its predecessor, Super Metroid, while being largely faithful to the 
visuals of the original game.

This patch is in no way affiliated with the "Special Edition" hack, or the "Better Suit Colors" hack, 
both of which make various changes to the game's visuals. 

This hack makes few changes to game menus, and none to the game's cinematic cut scenes.
It is primarily aimed at changes to the visuals seen in gameplay or using gameplay sprites.

Please apply the patch to:

 Metroid Fusion (USA, Australia) 

It will not work with other versions of the game. A patch for the EU version of the game may happen
in the future.

Known bugs:
 - Console in the Habitation Deck flashes in and out existence during its 'orange' cycle. When the
console is activated, it ceases to flash. Other, similar consoles are not affected.

Log:
v1.0
Initial release

