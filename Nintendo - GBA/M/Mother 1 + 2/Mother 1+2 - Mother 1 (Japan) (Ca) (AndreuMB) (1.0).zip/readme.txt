

	██▒░  ░▒██   ▒▓██████▓▒   ██████████ ██      ██  ████████  ██████▒
	███▓▒▒▓███  ▒██████████▒      ██     ██      ██  ██        ██   ▒██
	████▓▓████  ████████████      ██     ██      ██  ██        ██    ██
	██▒████▒██  ████████████      ██     ██████████  ███████   ██████▓▒
	██  ██  ██  ████████████      ██     ██      ██  ██        ██  ▓██░
	██      ██  ▒██████████▒      ██     ██      ██  ██        ██   ▒██
	██      ██   ▒▓██████▓▒       ██     ██      ██  ████████  ██    ░██

                                                                              ▓██▒
                                                  ██               ████        ▓██
                                                  ██                 ██
 ░██████▒  ▒███████          ▓██████   ██████▓  ██████    ██████▓    ██       ██████▓
 ██▒  ▒██  ███   ██         ▓██▒           ▒██    ██          ▒██    ██           ▒██
 ████████  ██    ██         ██        ░███████    ██     ░███████    ██      ░███████
 ██        ██    ██         ███░      ██▓░  ██    ██     ██▓░  ██    ██      ██▓░  ██
 ░██████▓  ██    ██          ▓██████  ▓██████▓    ▓███   ▓██████▓    ▓███    ▓██████▓


ÍNDEX

1. Introducció
2. Com aplicar el pedaç
3. Versions
4. Problemes coneguts
5. Agraïments
6. Avís legal
_____________________________________

1. INTRODUCCIÓ

Aquest pedaç consisteix en una traducció al català del port per a Game Boy Advance del videojoc Mother (també conegut com a Earthbound Beginnings), creat per Shigesato Itoi i publicat originalment per Nintendo l'any 1985.

Aquesta traducció s'ha dut a terme mitjançant les eines de traducció de Mother 1+2 creades per Tomato i Jeffman, així com la traducció a l'anglès no oficial de Tomato, la qual és notablement més fidel al text original que la traducció oficial realitzada per Phil Sandhop.
_____________________________________

2. COM APLICAR EL PEDAÇ

Per aplicar el pedaç necessitareu:
- Una ROM sense modificar del joc Mother 1+2 per a la GBA
- Un programa capaç d'aplicar pedaços en format UPS. Si no en teniu cap, podeu fer servir aquest:
https://www.romhacking.net/utilities/606/

Si no sabeu com aplicar el pedaç, aquí teniu una breu explicació de com fer-ho:

 1. Obriu el programa NUPS (el podreu descarregar a l'enllaç anterior) i seleccioneu l'opció "Apply a UPS patch to a file"

 2. En seleccionar aquesta opció, s'obrirà una finestreta nova amb dos camps per omplir:

   - Al primer camp, etiquetat com a "File to patch", heu de seleccionar el fitxer de la ROM no modificada del joc (haurà de tenir l'extensió ".gba"). 

   - Al segon camp, etiquetat com a "UPS patch", heu de seleccionar el fitxer del pedaç (l'arxiu amb extensió ".ups")

 3. Prem el botó "Patch" a la cantonada inferior dreta de la finestra. Si apareix el missatge "Patching has been done." voldrà dir que tot ha anar bé i que la ROM que abans era original i sense modificar ara és una ROM traduida, la qual podràs gravar en un cartutx flaix per jugar en una consola original o bé obrir amb un emulador (si no en tens cap, et recomano l'mGBA).
_____________________________________

3. VERSIONS

1.0: Primera versió revisada i corregida disponible al públic.
_____________________________________

4. PROBLEMES CONEGUTS

Igual que a les altres entregues de la saga, no ha estat possible aplicar els articles dels personatges jugables en totes les situacions (especialment a l'overworld), així com el nom del jugador, el qual no presenta article en cap cas.
_____________________________________

5. AGRAÏMENTS

Per les seves contribucions al projecte, m'agradaria donar les gràcies:

- Al Projecte Ce Trencada, pel seu suport continuat durant el procés de traducció d'aquesta trilogia que per fi arriba al seu final.

- A en Jumpman, ja que la seva traducció del joc al francès ha estat emprada com a base per aquesta traducció

- A en Tomato i en Jeffman, per crear les eines de traducció en les quals es basa la traducció d'en Jumpman.

- I, finalment, a tots aquells que gaudiran del joc, ja que, sense ells, tota aquesta feinada que ha durat més d'un any no tindria cap sentit.

_____________________________________

6. AVÍS LEGAL

Aquest projecte ha estat realitzat de manera desinteressada i sense cap ànim de lucre. Llevat de la traducció, tot el contingut del joc, així com els seus personatges, història, etc, són propietat intel·lectual de Nintendo. No existeix cap incentiu per part del creador d'aquest projecte a la descàrrega il·legal de ROMs de videojocs a través d'internet.