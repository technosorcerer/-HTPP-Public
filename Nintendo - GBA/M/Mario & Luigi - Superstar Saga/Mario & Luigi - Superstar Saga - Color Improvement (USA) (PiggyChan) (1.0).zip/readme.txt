Mario & Luigi: Superstar Saga Color Improvement v1.0
by Piggy Chan!

This is a ROM hack meant to improve the colors on the game in question, giving it greater contrast and overall sharper and more
vivid imagery. This project was very thorough, coloring almost everything the eye can see, with the exception of most mini-games
(whose color palette data may be compressed). 

Please apply the included patch to a copy of...

 - Mario & Luigi - Superstar Saga (Europe) (En,Fr,De,Es,It).gba -

It will likely not work with other versions of the game.

Feel free to incorporate this patch in your own projects, with due credit to myself.

November 26, 2024