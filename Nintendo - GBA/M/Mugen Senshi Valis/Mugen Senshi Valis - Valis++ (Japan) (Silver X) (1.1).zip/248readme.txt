 				   @@@
  -----------------------------------@_________
<  Valis++ v1.1 		    @*########|
  -----------------------------------@~~~~~~~~~
  2017 Sliver X & satsu		   @@@


About
~~~~~
This is a 100% complete translation of Valis (NES),
plus some fairly major hacks to increase playability
by leaps and bounds.

Intially released ten years ago, I was informed of
a game crashing bug related to two statues in the
Ruins level when using the Hammer item. This
update fixes that issue.

Usage
~~~~~
This hack/trans was based on the ROM known as
"Valis - The Fantastic Soldier (J)" in the
GoodNES set. Usage of any other ROM version
may result in glitches or other strange errors.


Misc.
~~~~~
I find this game to be pretty poor do to some terrible
design flaws, so I took it upon myself to correct a lot
of them. This includes the following:

1: You always have a map, which is accessed by hitting Select.
The maps are also marked with points of interest, such as
exits, the bosses in Stage 1, etc.

2: You take half damage at all times. This grants 10 HP
normally, and 20 with the Shield item.

3: Exit markers display for both Up and Down exits; this
corrects one of the biggest flaws in the original game, IMO.

There is also a vanilla translation of the game with
no gameplay tweaks, if you prefer a purist experience.

Please check either my homepage or ROMHacking.net
(http://www.romhacking.net) for this version of
the game.


Credits
~~~~~~~
Translation: satsu
ROM hacking/Programming: Sliver X
Assistant Programmer: Disch.
Beta testing: Onyxyte.


Version History
~~~~~~~~~~~~~~~
v1.1: Fixed game crashing dialogue with two statues in Ruins level when using the Hammer.

v1.01: Fixed the bug in the half damage hack relating to the Shield.
Changed some text of people who give maps (Since they don't give anything in ++).

v1.0: Initial Release

Contact
~~~~~~~
If you find anything that needs fixed, I can be contacted by the
following methods:

Email: panicus@gmail.com
Web: http://panicus.googlepages.com