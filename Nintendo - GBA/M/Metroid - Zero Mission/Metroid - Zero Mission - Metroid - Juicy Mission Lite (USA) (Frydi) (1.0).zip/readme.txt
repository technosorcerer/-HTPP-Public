People wanted a Samus goes to the fridge version for Zero Mission so I started making Juicy Mission... (Release planned at the end of the month)
But the hack got out of control and will be a proper hack, so this "lite version" gives speedrunners their fix :)
It's simple gameplay my friends and the hack can be completed in about a minute.

Disclaimer: Hard mode is hard, but the escape is nowhere near the TAS time. 

Special Thanks: 
- The Mageconst community for dealing with my questions and the fundamentals asm
- Jiffy for a Mage crash course waaay back which I completely forgot already when starting
- CaptGlitch for his timer patch that makes hard mode escape very fun to play
- PietroA and LucentW for music suggestions and PietroA help with converting/importing
- Fpiz, Jakoliath, Jiffy, baria, mikefood and benchjuice for testing