Metroid: Zero Mission - Combat Improvement Pack

The Combat Improvement Pack is hack of Metroid: Zero Mission that aims to rebalance aspects of the original game that 
diminished it's potential for better combat. This includes nerfing overpowered items, buffing underpowered items, and adding
Metroid Fusion's charge beam mechanics back into the game, courtesy of raygun and biospark. Contact Amso#0765 on Discord 
to give feedback or suggestions for a future update.
Made with MAGE.
Note: The "Zero Mission - Better Combat Pack" IPS file is just version 1.0. So if you want the newest and most up to date 
version, just use the v1.1 IPS file.

Credits
Amso- Damage and Health Edits
raygun- Charge Flare ASM
Biospark- R Shot ASM, MAGE Program

v1.0, 2/7/23
- Every Charge Beam does significantly more damage
- Super Missiles now do half damage
- Kraid, Ridley, and Mecha Ridley have been given more health
- Muzzle flare added to the game
- Power Bombs buffed to do 50 damage

v1.1, 2/8/23
- R Shots added to the game
- Charge Plasma damage values buffed
- Acid worm health buff
- Extra text in charge beam description