Metroid: Zero Mission is one of the most beloved games on the Game Boy Advance, but like many games on the system, its blown out and overbright visuals don't hold up well when viewed on modern
monitors. This patch attempts to make a version of Metroid: Zero Mission which is easier on the eyes, with greater contrasts across the color spectrum, exclusively through editting color palettes (no 
tiles or sprites have been changed, otherwise). It is primarily inspired by the darker visuals of Super Metroid.

Please apply the patch to Metroid - Zero Mission (U) [!].gba. I have not tested it with any other versions, or ROM hacks utilizing this version. 

Please note that the colors of this patch tend towards the dark, and so it may be hard to see on various GBA hardware. It was made with televisions and monitors in mind.

Color Palettes That Have Been Changed:
 - Virtually every sprite. All variations of Samus, items, projectiles, explosions and enemies. Even the dummied out Crocomire has a new color palette! You'll have to hack the game to find him, but there 
he'll be. The Plasma Beam and Wave Beam also have their own colors, though it takes hacking and/or some serious sequence breaking to see them without the effects of the ice beam overlaying their
color.. 
 - Most backgrounds and background effects, and all map tiles (unless I am missing something...), have been editted.
 - The red border on the tiles has been eliminated throughout.
 - The map screen. The map screen, both in the top corner and on the menu, has been editted to appear as aesthetically similar to Super Metroid as possible.

Color Palettes Which Have NOT Changed
 - All cinematic cut scenes. The prospect of doing so is simply mind boggling – well beyond my skill level and comfort zone - and since the primary focus of this project is on the gameplay, I decided 
against doing so myself, without outside help, at this time.
 - Much of the menus. While I did do some work on the in-game menus, their visuals mostly do not distract from the experience, nor is their interface comparable to that of Super Metroid, so I decided
 it was not necessary to edit them. This may change in future updates of the patch if I am so inspired.
 - Most of the backgrounds in the Chozodia ruins. While the walkable tiles have all been changed, giving them a reddish stone color, I did not bother with the background. This may change in
a future patch, but for now I am satisfied.
 - Various bits and bobs. The red dust in Kraid's battle room, the blue haze just before the big battle in Tourian, in particular. I experimented with a few ideas, and determined that all of them were
worse than what was present in the original, so I let them alone.

Color Palettes Changed, But Not Entirely Satisfied With
 - The Imago nest. The nest itself, in its original inception, was a bit of an incoherent nightmare, with eggs having contrasting and rather nonsensical colors. Most people
don't notice, but it might be even more noticeable after my changes. Tile editting would be necessary to rectify this.
 - The kiru giru enemy. It is supposed to have a purple coloration on its body (both the in-game sprite and the artwork reflect this). However, none of my efforts were able to present this coloration
in a way that I found presentable. As a result, for now, the kiru giru is merely varying shades of greem.

Feel free to make use of this patch as part of your own personal projects, with due credit.