
--------------------------------------------------------------------------------
   _____                   _            __  __ _         _               ___  
  / ____|                 | |          |  \/  (_)       (_)             |__ \ 
 | (___  _ __   ___   ___ | | ___   _  | \  / |_ ___ ___ _  ___  _ __      ) |
  \___ \| '_ \ / _ \ / _ \| |/ / | | | | |\/| | / __/ __| |/ _ \| '_ \    / / 
  ____) | |_) | (_) | (_) |   <| |_| | | |  | | \__ \__ \ | (_) | | | |  / /_ 
 |_____/| .__/ \___/ \___/|_|\_\\__, | |_|  |_|_|___/___/_|\___/|_| |_| |____|
        | |                      __/ |                                        
        |_|                     |___/                                         
		
--------------------------------------------------------------------------------



+-----------+
|           |
|    FAQ    |
|           |
+-----------+

Q. Which version of ZM do I apply the patch to?
A. US version

Q. What is the total item count of the game?
A. 100 items, including your 2 starting abilities. Tanks and abilities count the same.

Q. How many of each tank are there?
A. 12 E Tanks, 50 Missiles, 15 Supers, and 9 Power Bombs

Q. What am I supposed to be doing to beat the hack?
A. Find the five green flames to unlock the gate to the Polar Express, there may be a map somewhere to help you locate them...

Q. What is the purpose of the purple flames?
A. They lower the lava level in their area.

Q. Help! I don't have enough ammo to kill [insert boss here]
A. All custom bosses should have drops if you are out of ammo

Q. How many items are required for low%
A. Your minimal item count will be 11%, aka 11 items

Q. Is there a secret ending?
A. No, you filthy degenerate

+------------------+
|                  |
|    Known Bugs    |
|                  |
+------------------+

- Power bombs cause music to stop in certain moments
- A few amount of bad background elements, ignore those please
- Imago

+---------------+
|               |
|    Credits    |
|               |
+---------------+

Developers:
	- CaptGlitch
	- Caauyjdp
	- Conner
	- Ing Ing
	- Jiffy
	- JRP
	- M3D
	- NathanTech
	- OneOf99
	- Whalerynth

Testers:
	- Bob4224
	- Boomerang
	- Caauyjdp
	- Shaktool7