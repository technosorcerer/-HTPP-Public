Metroid: Return to Zebes, release 2.5.4, by alexman25

CREDITS

IF YOU THINK THAT SOMEONE IS MISSING FROM THE CREDITS, PLEASE LET ME KNOW IMMEDIATELY!

-CREATION CREDITS-

(Name:                   Contributions)

-ASM-

 Yohann:                 End Mecha Escape Sprite

 Raygun:                 Unmorph Jump, Tractor-Beam, Transparent Map Fix,

 Capt. Glitch:           Tractor-Beam, Rewritten Timer Routine, No Pirate Ambiance, Faster Item Grabbing, Cliphax Fixed

 Biospark:               Unknown Items, Add Elevators, Remove Samus Closeup, Add Minimap Tiles, Disable Chozo Hints, PB Pirate Fix, Power Bombs before Bombs, Scale End %, 2 Line TXT, R-Shot

 Trunaur68:              Item Toggle Menu, Cliphax

 somerando(cauuyjdp):    5x3 Minimap
 
 Quote58:                Tractor-Beam

 FelixWright:            Tractor-Beam, 




-PROGRAMS-

 Biospark:               Metroid Advance Game Editor
 
 Nintenlord:             NLZ-GBA Advamce
 
 The Helmeted Rodent:    Sappy 2006



-MUSIC-

 Lily:                    Green Brinstar




-MISC CREDITS-

(Contribution:           Names)

 Design Advisory:        Metroid Violinist

 Art Advisory:           Metroid Violinist
 
 Playtesting:            somerando(cauuyjdp), Metroid Violinist, LetsPlayNintendoITA, The Brothers Crafters, Metroid Crafter, King Atlas the Metroid Battler of SR388, Handy, Tocom, Shaktool7, Exister, They Call Me Xander

 Wants to be in credits: Conner the Con Conner
 
 SRAM Issue fix:         somerando(cauuyjdp)