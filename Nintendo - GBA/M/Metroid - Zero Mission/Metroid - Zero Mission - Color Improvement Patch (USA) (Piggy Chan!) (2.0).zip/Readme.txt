Metroid: Zero Mission is one of the most beloved games on the Game Boy Advance, but like many games on the system, its blown out and overbright visuals don't hold up well when viewed on modern
monitors. The goals of these two patches are to remedy that, in different ways. Version 1 attempts to give the game's atmosphere more resonance with Super Metroid, on the Super NES / Super
Famicom, solely through color palettes. Version 2, on the other hand, reflects the original game's color scheme but attempts to give it a more vibrant color scheme, allowing for more contrast.
Version 2 is a more thorough effort than version 1, but In both patches, the visuals in the game's cut scenes are untouched.

Please apply the patches to Metroid - Zero Mission (U) [!].gba. I have not tested them with any other versions, or ROM hacks utilizing this version. 

Please note that the colors of these patches tend towards the dark, and so it may be hard to see on various GBA hardware. They were made with televisions and other backlit monitors in mind.

Feel free to make use of this patch as part of your own personal projects, with due credit.