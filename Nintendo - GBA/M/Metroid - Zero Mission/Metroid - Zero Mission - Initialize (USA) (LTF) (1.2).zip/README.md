Space pirates have landed near a civilian sector of the galactic federation. It is your mission to defeat them before they can establish a base.

INITIALIZE!

This quick play hack features a new single area map, custom graphics, music, end screens, imported fusion bosses, and more! Play with walljumps and bomb jumps for a short, nonlinear experience, or play without them for a longer and more linear hack. Either way, they are not required for scaled 100% item collection. You will be required to do some shinesparks though!

"Initialize" took just over 2 weeks to make, and is the first ROM hack I have made. Thank you to the MAGconst discord for sharing resources and being so so helpful in answering my constant questions!

Map file is included in Zip if you are stuck/cant find 100%

Credits:

Mage - Biosp4rk

Asm and tweaks - -
Capt. Glitch
Yohann
Raygun
Somerando

Gfx - -
Ivy
Justaicon
jiffy
oneof99
Glacierwolf
