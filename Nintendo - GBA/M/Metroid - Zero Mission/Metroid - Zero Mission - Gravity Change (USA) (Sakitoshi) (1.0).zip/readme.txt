this patch aims to make samus less heavy by adjusting gravity to be less severe making her fall slightly slower. jumping height has been adjusted to match the vanilla game as closely as possible and bomb timer has been delayed a bit to make double/multi bomb jump still possible and not disrupt normal gameplay.
the result is that samus retains her speed in all directions but down, resulting in maneuverable movement without feeling gravity weighing samus down.
apply to Metroid - Zero Mission (USA) rom.

Changelog:
v1.0
-changed gravity value
-changed jump values to match vanilla height under the new gravity value
-adjusted bomb timer
