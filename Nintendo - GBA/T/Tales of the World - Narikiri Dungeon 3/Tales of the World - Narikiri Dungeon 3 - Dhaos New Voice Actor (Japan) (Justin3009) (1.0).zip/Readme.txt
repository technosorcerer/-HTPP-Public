******************************************************************************
Tales of the World - Narikiri Dungeon 3 (Dhaos's New VA)		     *
Created By: Justin3009 (xJustin3009x/Shishisenkou)			     *
******************************************************************************
Version 1.0 - September 21st, 2014
--------------------------------------------------------------------------------

Content
-------------
1. What's new?
2. Credits
3. Contact


******************************************************************************
1. What's new?								     *
******************************************************************************
This requires a CLEAN Tales of the World - Narikiri Dungeon 3 GBA Rom!

    Feature
    -------------------------------
1. Replaces Dhaos's original voices with his new voice actor.
	(I ADORE the original Dhaos's VA, but since he passed away, I thought I'd release a mini patch with his new voice actor for people who prefer him.

--------------------------------------------------------------------------------
******************************************************************************
2. Credits								     *
******************************************************************************
Namco for creating such a wonderful game series!

--------------------------------------------------------------------------------
******************************************************************************
3. Contact								     *
******************************************************************************

If any bug is found that's unusual or game breaking, feel free to contact me at:
 
Email:	xxJustin3009xx@hotmail.com

--------------------------------------------------------------------------------