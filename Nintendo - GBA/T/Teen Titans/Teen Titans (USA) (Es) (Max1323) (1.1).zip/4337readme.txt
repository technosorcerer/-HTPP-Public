"Teen Titans"
Traducci�n al Espa�ol Ver. 1.0 (25/03/2019)
por Max1323 (maxmuruchi@gmail.com)
---------------------------------------------------
Descripci�n:
Basado en los comics de DC y la serie "Teen Titans" (Los J�venes Titanes).
Brother Blood (Hermano Sangre) ha clonado a los Titanes, y es hora de
ponerle fin a su plan. Juega con Robin, Starfire, Beast Boy , Cyborg o Raiven.
 
Desarrollado: Artificial Mind and Movemente
Publicado:    Majesco
Lanzamiento:  26/09/2001 (USA)
---------------------------------------------------
Acerca del proyecto:
Se tradujo algunos nombres y los di�logos.
Parece que se tenia planeado sacar en otros idiomas como 
Espa�ol, Italiano y Alem�n. Ya que cuenta con los di�logos
para dicho idioma.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS

Teen Titans (U).gba
File MD5      148C4190C830886BECE41EB380EA3533        
File SHA-1    94BF3FC459321450FF2B1E75A0B98EFACFFD2D0B
File CRC32    12A0442C                                
File Size     8.00 MB
                              
                           
                              
                              
                             
                       
