Disclaimer:
This is mod ends after Vault.  While you can play beyond that point, there is no adjustments made and plays exactly like the orginal Golden Sun 1.


=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
Set-up
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
- Have your copy of Golden Sun for the GBA ready 
	- This mod only works with the US release of the first Golden Sun game 
	-Make sure you use a clean copy, patching something already patched is not recommended.
- Apply the patch
- (Optional) Apply any of the patches from the "Optional Patches" folder that you feel will improve your gameplay.
	-AutoRun: Swaps inputs so you run by default and holding down the "B button" makes you walk instead.

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
Credits
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
Modded by JackitK through the support of various tools and patches.

Tools Used:
- Majority of Patching done via Atrius/TLA Editor. Made by Atrius with updates by Teacopter.
- Text Updates done with Golden Sun Translation Toolkit.
Optional Patches:
- Auto-Running Patch provided by Straylite of the GoldenSun modding community

Special Thanks to the Golden Sun modding community.
Forums: http://forum.goldensunhacking.net/index.php

All Rights to Golden Sun belong to Camelot Software Planning and Nintendo. This is a non-profit project and does NOT have any association to either Camelot nor Nintendo.

Please support Golden Sun via purchasing the game through legal means provided by the orginal rights owner; via Nintendo Switch Online or any ports/remakes the orginal rights owners may provide in the future. 

This project does NOT endorce piracy. Please play this via patching a legal copy of this game you've dumped, soley for personal use. I do not hold any responsibly for those who obtained their copy of the game through other means. This project is free to download and play. If you paid money for this in any form, including but not limited to the purcahse of a physical cart, you've been scammed. Please reach out to whoever you bought it from and demand a refund.
