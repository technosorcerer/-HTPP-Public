=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Table of Contents

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

I.) Overview

II.) Adjustments to Overworld Abilities/Quality of Life Updates

a1 Retreat

a2 Avoid

a3 Addressing Grinding

a4 Default Psynergy

a5 Psynergy Items

III.) Known Bugs/Issues

IV.) FAQ

V.) Credits

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

I.) Overview

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

This mod implements the Quality-of-Life features used in Dawn of Djinn in a setting that better reflects the original game. For players who wish to experience the original world of Golden Sun with those features.

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

II.) Adjustments to Overworld Abilities/Quality of Life Updates

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

a1 Retreat

Retreat not only warps you to the start of a dungeon or town but now functions similarly to teleport when used on the world map. Using Retreat pulls up the map and you can select any town that you've previously visited to instantly return there. The linearity of Golden Sun doesn't make this as needed as other RPGs, but it does open up some options that would be unreasonable in the original game, such as Retreating back to Imil to restock on Hermes Water.

a2 Avoid

Avoid now behaves as a random encounter toggle rather than a wear off effect. Using it once turns off 100% of random encounters, using it again turns them back on. 

a3 Default Psynergy

Building off the built in Psynergy the Randomizer provided, many utility Psynergy like Growth, Whirlwind, and even Avoid are built right into party members so they have them, regardless of your class. In addition, Psynergy not tied to battle no longer cost Psynergy to use. Though they have different names to distinguish from their battle equivalents. For example in battle Growth still cost Psynergy to use, but outside of battle it is refer to as “Sprout” but otherwise functions the same.

a4 Psynergy Items

Psynergy items also behave differently as well. Often when you first encounter them they won't be items, but rather weapons and armor you can equip to party members to get the effect without wasting an extra item slot. When the equipment becomes out-classed, you can sell it at a shop and a more traditional Psynergy item will appear in any item shop's Artifact section. You can sell and re-buy the items as you please, freeing up inventory space if you're familiar enough with the game to know when you do and don't need them.

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

III.) Known Bugs/Issues

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Occasional visual effects when using Retreat in the overworld:
I believe this is a carry-over from the Golden Sun Randomizer and if so, I'm not sure if I have the ability to fix it.

Avoid can be buggy with it's new implementation:
If one saves and quits the game while Avoid is still toggled on, they may have problems turning it back off once they reopen the game. Most consistent solution I've discovered to fixed this from a player's end is to toggle it on and off, transition to a new area, toggle it on and off again. If done correctly, this will make it toggle like normal. As for correcting this problem from the creator side. I'm not sure if this is possible as the Avoid changes were carried over from the Golden Sun Randomizer and I don't have access to the original code. Best measure of avoiding this issue is to make sure it's off before saving the game.

Toggling encounters back on results in odd text:
This is a by product of modifying code I didn't make in order to get the Retreat fast travel.  Since it doesn't affect gameplay, it isn't a huge priority to fix. But it is on mind when/if I properly revisit this mod to update it.

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

IV.) FAQ

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

How do I install and play?

1. Download the patch. 

2. Have your copy of Golden Sun for the GBA ready 

-Make sure you use a clean copy, patching something already patched is not recommended. 

3. Use Lunar IPS to patch it to your copy of Golden Sun (Choosing between No Prologue or Prologue)

4. If using patches from the "Add On" folder, apply them afterwords.



What is the difference between the patches?

GSTBS_QoL_Prologue: Prologue and Djinn tutorial left in the game.

GSTBS_QoL_NoPrologue: Starts the game off right as Isaac and Garet are leaving Vale, as well as skips the Flint tutorial. Intended for people already well familiar with Golden Sun and don't need to experience the story.

Neither of these patches remove the dialogue, like in Dawn of Djinn V1, however this patch is compatible with the cutscene skip patch used in Golden Sun 1 speedruns (Not included). The two can be used in combination to skip the prologue and go through cutscenes as quickly as possible.

What do the Add-on Patches do?
AutoRun: Makes it so you run by default (holding down B makes you walk)
Cutscene Skip: Abridges cutscenes to not only skip the majority of dialogue, but make them play out faster.  Intended for people already well familiar with Golden Sun and don't need to experience the story.



=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

V.) Credits

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
Credits
Modded by JackitK through the support of various tools and patches.

Tools Used:
- Majority of Patching done via Atrius/TLA Editor. Made by Atrius with updates by Teacopter.
- Text Updates done with Golden Sun Translation Toolkit.

Optional Patches:
- Auto-Running Patch provided by Straylite of the GoldenSun modding community
- No Cutscene Patch created by Marvin_XLII for the Golden Sun Speedrunning community.	https://www.speedrun.com/gsun/resources

Special Thanks to the Golden Sun modding community for tools and inquiries answered throughout the modding journey.
Forums: http://forum.goldensunhacking.net/index.php

All Rights to Golden Sun belong to Camelot Software Planning and Nintendo. This is a non-profit project and does NOT have any association to either Camelot nor Nintendo.

Please support for Golden Sun via purchasing the game through legal means provided by the orginal rights owner; via Nintendo Switch Online (when they eventually decide to release it) or any ports/remakes the orginal rights owners may provide in the future. 

This project does NOT endorce piracy. Play via patching a legal copy of this game you've dumped, soley for personal use. If you paid money for this mod in any form, including but not limited to the purcahse of a physical cart, you've been scammed. Please reach out to whoever you bought it from and demand a refund.