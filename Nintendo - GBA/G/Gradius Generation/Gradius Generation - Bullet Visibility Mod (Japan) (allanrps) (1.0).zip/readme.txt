This is a simple hack that makes the basic enemy bullet sprite slightly larger so as to be more easily visible.

This is for the Japanese version of the game, 'Gradius Generation'. It can be combined with the "Parodius Penetration - Ship Mod".

Database match: Gradius Generation (Japan)
Database: No-Intro: Game Boy Advance (v. 20210227-023848)
File/ROM SHA-1: B1DB63DD449153B82B16ABCADF1EEB7C7A100DBB
File/ROM CRC32: 6C20EA42
