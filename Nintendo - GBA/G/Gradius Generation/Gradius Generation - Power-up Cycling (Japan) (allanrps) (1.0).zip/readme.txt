This is a hack that alters the behavior of the speed and shield power-ups to be more user friendly. The 0 and 4 speeds, which are quite impossible to use, have been eliminated. The player ship now starts at speed 1, and if the player upgrades speed past level 3, the ship's speed will cycle back to 1. This slightly aids in checkpoint recovery and eliminates deaths caused by accidentally over-upgrading speed.

It is now possible to select the shield power-up when the shield is active. This will cause the shield to reactivate, replenishing it's hp. In the case of the front facing shield, it will also cause the gears to re-enter from screen right, dealing damage to enemies they contact on the way. This re-balances the front facing shield to be more viable, and adds some gameplay intrigue.

This hack is not intended to make the game easier, and it is not believed to affect the core difficulty of the game. It does eliminate some compulsive actions, replacing them with meaningful choices, and move the balance very slightly away from the Gradius 'die once and reset'

Database match: Gradius Generation (Japan)
Database: No-Intro: Game Boy Advance (v. 20210227-023848)
File/ROM SHA-1: B1DB63DD449153B82B16ABCADF1EEB7C7A100DBB
File/ROM CRC32: 6C20EA42
