This is a graphical hack that replaces all ship sprites with the Vic Viper and a modified Lord British from Gokujo Parodius. Each ship retains its characteristic coloring, while offering more detail than the stock sprites. Other player related graphics are modified to be consistent with the new ships.

This is for the Japanese version of the game, 'Gradius Generation'. It can be combined with the "Gradius Generation - Bullet Visibility Mod".

Database match: Gradius Generation (Japan)
Database: No-Intro: Game Boy Advance (v. 20210227-023848)
File/ROM SHA-1: B1DB63DD449153B82B16ABCADF1EEB7C7A100DBB
File/ROM CRC32: 6C20EA42
