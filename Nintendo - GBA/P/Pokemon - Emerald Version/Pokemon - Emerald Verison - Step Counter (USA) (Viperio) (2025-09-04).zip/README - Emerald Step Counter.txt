Emerald - Step Counter

- There is a step counter in the bottom right corner of the screen.