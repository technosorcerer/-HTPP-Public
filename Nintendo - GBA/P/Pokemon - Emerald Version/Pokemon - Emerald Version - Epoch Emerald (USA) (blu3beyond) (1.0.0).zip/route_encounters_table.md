# Route Encounters (Land / Water / Fishing)

| Route / Area                             | Method   | Pokémon                                                                                                            |
|:-----------------------------------------|:---------|:-------------------------------------------------------------------------------------------------------------------|
| Abandoned Ship Hidden Floor Corridors    | water    | Tentacool, Tentacruel                                                                                              |
| Abandoned Ship Hidden Floor Corridors    | fishing  | Magikarp, Tentacool, Tentacruel                                                                                    |
| Abandoned Ship Rooms B1F                 | water    | Tentacool, Tentacruel                                                                                              |
| Abandoned Ship Rooms B1F                 | fishing  | Magikarp, Tentacool, Tentacruel                                                                                    |
| Advent Cave                              | land     | Psyduck, Paras, Venonat, Anorith, Lileep, Bagon, Beldum, Larvitar, Crobat                                          |
| Altering Cave                            | land     | Zubat                                                                                                              |
| Altering Cave                            | land     | Mareep                                                                                                             |
| Altering Cave                            | land     | Pineco                                                                                                             |
| Altering Cave                            | land     | Houndour                                                                                                           |
| Altering Cave                            | land     | Teddiursa                                                                                                          |
| Altering Cave                            | land     | Aipom                                                                                                              |
| Altering Cave                            | land     | Shuckle                                                                                                            |
| Altering Cave                            | land     | Stantler                                                                                                           |
| Altering Cave                            | land     | Smeargle                                                                                                           |
| Artisan Cave 1F                          | land     | Smeargle                                                                                                           |
| Artisan Cave B1F                         | land     | Smeargle                                                                                                           |
| Cave Of Origin 1F                        | land     | Zubat, Sableye, Golbat                                                                                             |
| Cave Of Origin Entrance                  | land     | Zubat, Golbat                                                                                                      |
| Cave Of Origin Unused Ruby Sapphire Map1 | land     | Zubat, Sableye, Golbat                                                                                             |
| Cave Of Origin Unused Ruby Sapphire Map2 | land     | Zubat, Sableye, Golbat                                                                                             |
| Cave Of Origin Unused Ruby Sapphire Map3 | land     | Zubat, Sableye, Golbat                                                                                             |
| Desert Underpass                         | land     | Ditto, Whismur, Loudred                                                                                            |
| Dewford Town                             | water    | Tentacool, Wingull, Pelipper                                                                                       |
| Dewford Town                             | fishing  | Magikarp, Tentacool, Wailmer                                                                                       |
| Ever Grande City                         | water    | Tentacool, Wingull, Pelipper                                                                                       |
| Ever Grande City                         | fishing  | Magikarp, Tentacool, Luvdisc, Wailmer, Corsola                                                                     |
| Fiery Path                               | land     | Numel, Koffing, Machop, Torkoal, Slugma, Growlithe, Grimer, Cyndaquil, Charmander, Torchic                         |
| Granite Cave 1F                          | land     | Mankey, Makuhita, Tyrogue, Abra, Phanpy, Geodude, Larvitar                                                         |
| Granite Cave B1F                         | land     | Zubat, Aron, Murkrow, Sableye, Makuhita, Misdreavus, Gastly                                                        |
| Granite Cave B2F                         | land     | Zubat, Aron, Sableye, Abra, Misdreavus, Murkrow, Beldum                                                            |
| Granite Cave Stevens Room                | land     | Aron, Makuhita, Abra, Trapinch, Beldum                                                                             |
| Jagged Pass                              | land     | Numel, Machop, Spoink                                                                                              |
| Lilycove City                            | water    | Tentacool, Wingull, Pelipper                                                                                       |
| Lilycove City                            | fishing  | Magikarp, Tentacool, Wailmer, Staryu                                                                               |
| Magma Hideout 1F                         | land     | Geodude, Torkoal, Graveler                                                                                         |
| Magma Hideout 2F 1R                      | land     | Geodude, Torkoal, Graveler                                                                                         |
| Magma Hideout 2F 2R                      | land     | Geodude, Torkoal, Graveler                                                                                         |
| Magma Hideout 2F 3R                      | land     | Geodude, Torkoal, Graveler                                                                                         |
| Magma Hideout 3F 1R                      | land     | Geodude, Torkoal, Graveler                                                                                         |
| Magma Hideout 3F 2R                      | land     | Geodude, Torkoal, Graveler                                                                                         |
| Magma Hideout 3F 3R                      | land     | Geodude, Torkoal, Graveler                                                                                         |
| Magma Hideout 4F                         | land     | Geodude, Torkoal, Graveler                                                                                         |
| Meteor Falls 1F 1R                       | land     | Zubat, Lunatone, Solrock, Larvitar, Bagon                                                                          |
| Meteor Falls 1F 1R                       | water    | Zubat, Solrock, Staryu                                                                                             |
| Meteor Falls 1F 1R                       | fishing  | Magikarp, Staryu, Goldeen, Barboach, Feebas                                                                        |
| Meteor Falls 1F 2R                       | land     | Golbat, Solrock, Larvitar, Bagon                                                                                   |
| Meteor Falls 1F 2R                       | water    | Golbat, Solrock, Staryu                                                                                            |
| Meteor Falls 1F 2R                       | fishing  | Magikarp, Goldeen, Barboach, Whiscash, Feebas                                                                      |
| Meteor Falls B1F 1R                      | land     | Golbat, Solrock, Pupitar, Shelgon                                                                                  |
| Meteor Falls B1F 1R                      | water    | Golbat, Solrock                                                                                                    |
| Meteor Falls B1F 1R                      | fishing  | Magikarp, Goldeen, Barboach, Whiscash                                                                              |
| Meteor Falls B1F 2R                      | land     | Golbat, Bagon, Solrock                                                                                             |
| Meteor Falls B1F 2R                      | water    | Golbat, Solrock                                                                                                    |
| Meteor Falls B1F 2R                      | fishing  | Magikarp, Goldeen, Barboach, Whiscash                                                                              |
| Meteor Falls Stevens Cave                | land     | Golbat, Solrock                                                                                                    |
| Mirage Tower 1F                          | land     | Sandshrew, Trapinch                                                                                                |
| Mirage Tower 2F                          | land     | Sandshrew, Trapinch                                                                                                |
| Mirage Tower 3F                          | land     | Sandshrew, Trapinch                                                                                                |
| Mirage Tower 4F                          | land     | Sandshrew, Trapinch                                                                                                |
| Mossdeep City                            | water    | Tentacool, Wingull, Pelipper                                                                                       |
| Mossdeep City                            | fishing  | Magikarp, Tentacool, Wailmer, Sharpedo                                                                             |
| Mt Pyre 1F                               | land     | Misdreavus, Shuppet, Murkrow                                                                                       |
| Mt Pyre 2F                               | land     | Misdreavus, Murkrow, Shuppet                                                                                       |
| Mt Pyre 3F                               | land     | Misdreavus, Murkrow, Shuppet                                                                                       |
| Mt Pyre 4F                               | land     | Misdreavus, Murkrow, Shuppet, Duskull                                                                              |
| Mt Pyre 5F                               | land     | Murkrow, Misdreavus, Shuppet, Duskull                                                                              |
| Mt Pyre 6F                               | land     | Murkrow, Misdreavus, Shuppet, Duskull                                                                              |
| Mt Pyre Exterior                         | land     | Shuppet, Vulpix, Wingull, Growlithe                                                                                |
| Mt Pyre Summit                           | land     | Sneasel, Shuppet, Duskull, Chimecho                                                                                |
| New Mauville Entrance                    | land     | Voltorb, Magnemite                                                                                                 |
| New Mauville Inside                      | land     | Voltorb, Magnemite, Electrode, Magneton                                                                            |
| Pacifidlog Town                          | water    | Tentacool, Wingull, Pelipper                                                                                       |
| Pacifidlog Town                          | fishing  | Magikarp, Tentacool, Wailmer, Sharpedo                                                                             |
| Petalburg City                           | water    | Marill, Lotad, Feebas                                                                                              |
| Petalburg City                           | fishing  | Magikarp, Staryu, Goldeen, Corphish, Feebas                                                                        |
| Petalburg Woods                          | land     | Poochyena, Wurmple, Shroomish, Roselia, Silcoon, Cascoon, Taillow, Slakoth, Gastly                                 |
| Resevoir Cave                            | water    | Psyduck, Staryu, Horsea, Feebas, Lapras                                                                            |
| Resevoir Cave                            | fishing  | Clamperl, Staryu                                                                                                   |
| Route101                                 | land     | Wurmple, Poochyena, Weedle, Caterpie, Zigzagoon, Teddiursa, Togepi                                                 |
| Route102                                 | land     | Poochyena, Wurmple, Lotad, Zigzagoon, Nidoran♀, Ralts, Nidoran♂, Seedot                                            |
| Route102                                 | water    | Marill, Dratini, Mudkip                                                                                            |
| Route102                                 | fishing  | Magikarp, Goldeen, Corphish                                                                                        |
| Route103                                 | land     | Poochyena, Spearow, Vulpix, Zigzagoon, Nidoran♂, Nidoran♀, Totodile, Chikorita                                     |
| Route103                                 | water    | Tentacool, Wingull, Pelipper, Feebas                                                                               |
| Route103                                 | fishing  | Magikarp, Tentacool, Wailmer, Sharpedo                                                                             |
| Route104                                 | land     | Poochyena, Wurmple, Rattata, Marill, Wingull, Nidoran♂, Taillow, Gastly, Squirtle, Bulbasaur                       |
| Route104                                 | water    | Wingull, Pelipper, Feebas                                                                                          |
| Route104                                 | fishing  | Magikarp, Clamperl, Feebas                                                                                         |
| Route105                                 | water    | Tentacool, Wingull, Pelipper, Dratini                                                                              |
| Route105                                 | fishing  | Magikarp, Tentacool, Wailmer, Feebas                                                                               |
| Route106                                 | water    | Tentacool, Wingull, Pelipper, Omanyte                                                                              |
| Route106                                 | fishing  | Magikarp, Tentacool, Wailmer, Feebas                                                                               |
| Route107                                 | water    | Tentacool, Wooper, Wingull, Pelipper, Chinchou                                                                     |
| Route107                                 | fishing  | Magikarp, Tentacool, Horsea, Wailmer, Seadra, Feebas                                                               |
| Route108                                 | water    | Tentacool, Wingull, Pelipper, Kabuto                                                                               |
| Route108                                 | fishing  | Magikarp, Tentacool, Horsea, Seel, Wailmer, Feebas                                                                 |
| Route109                                 | water    | Tentacool, Wingull, Pelipper, Poliwag                                                                              |
| Route109                                 | fishing  | Magikarp, Tentacool, Shellder, Wailmer, Feebas                                                                     |
| Route110                                 | land     | Ponyta, Electrike, Gulpin, Trapinch, Minun, Oddish, Mareep, Magnemite, Plusle                                      |
| Route110                                 | water    | Tentacool, Wingull, Pelipper, Chinchou                                                                             |
| Route110                                 | fishing  | Magikarp, Tentacool, Surskit, Wailmer, Octillery, Feebas                                                           |
| Route111                                 | land     | Sandshrew, Trapinch, Baltoy, Swinub, Phanpy, Cacnea, Beldum, Larvitar                                              |
| Route111                                 | water    | Marill, Wooper, Goldeen                                                                                            |
| Route111                                 | fishing  | Magikarp, Goldeen, Barboach, Feebas                                                                                |
| Route112                                 | land     | Numel, Marill, Growlithe, Houndour, Ponyta, Cyndaquil, Torchic, Charmander                                         |
| Route113                                 | land     | Spinda, Slugma, Cubone, Ditto, Exeggcute, Skarmory, Eevee, Scyther                                                 |
| Route114                                 | land     | Swablu, Lotad, Jigglypuff, Lombre, Seviper, Wartortle, Bulbasaur                                                   |
| Route114                                 | water    | Marill, Starmie, Goldeen                                                                                           |
| Route114                                 | fishing  | Magikarp, Goldeen, Staryu, Barboach, Feebas                                                                        |
| Route115                                 | land     | Combusken, Marshtomp, Wartortle, Charmeleon, Eevee, Swellow, Quilava, Porygon, Aerodactyl                          |
| Route115                                 | water    | Tentacool, Slowbro, Wingull, Pelipper, Lapras                                                                      |
| Route115                                 | fishing  | Magikarp, Tentacool, Kabuto, Wailmer, Feebas                                                                       |
| Route116                                 | land     | Poochyena, Whismur, Nincada, Abra, Taillow, Pineco, Hoothoot, Natu, Togetic, Gastly                                |
| Route117                                 | land     | Poochyena, Oddish, Marill, Volbeat, Illumise, Seedot, Hitmontop, Teddiursa                                         |
| Route117                                 | water    | Marill, Goldeen                                                                                                    |
| Route117                                 | fishing  | Magikarp, Goldeen, Corphish                                                                                        |
| Route118                                 | land     | Grimer, Electrike, Zigzagoon, Furret, Linoone, Koffing, Wingull, Krabby, Lickitung, Drowzee, Exeggcute, Kangaskhan |
| Route118                                 | water    | Tentacool, Wingull, Pelipper                                                                                       |
| Route118                                 | fishing  | Magikarp, Tentacool, Carvanha, Sharpedo                                                                            |
| Route119                                 | land     | Zigzagoon, Linoone, Sunkern, Oddish, Aipom, Hoppip, Tropius, Bulbasaur, Bayleef, Grovyle                           |
| Route119                                 | water    | Tentacool, Wingull, Pelipper                                                                                       |
| Route119                                 | fishing  | Magikarp, Tentacool, Carvanha                                                                                      |
| Route120                                 | land     | Poochyena, Mightyena, Oddish, Marill, Roselia, Absol, Anorith, Snorlax                                             |
| Route120                                 | water    | Marill, Starmie                                                                                                    |
| Route120                                 | fishing  | Magikarp, Goldeen, Barboach, Feebas                                                                                |
| Route121                                 | land     | Poochyena, Shuppet, Mightyena, Absol, Oddish, Gloom, Ariados, Gligar, Pinsir, Heracross                            |
| Route121                                 | water    | Tentacool, Wingull, Pelipper                                                                                       |
| Route121                                 | fishing  | Magikarp, Tentacool, Wailmer                                                                                       |
| Route122                                 | water    | Tentacool, Octillery, Wingull, Corsola, Mantine                                                                    |
| Route122                                 | fishing  | Magikarp, Tentacool, Wailmer, Sharpedo                                                                             |
| Route123                                 | land     | Poochyena, Shuppet, Mightyena, Oddish, Gloom, Dodrio, Dugtrio, Machoke, Kangaskhan                                 |
| Route123                                 | water    | Tentacool, Wingull, Pelipper                                                                                       |
| Route123                                 | fishing  | Magikarp, Tentacool, Wailmer                                                                                       |
| Route124                                 | water    | Tentacool, Wingull, Pelipper, Slowbro                                                                              |
| Route124                                 | fishing  | Magikarp, Tentacool, Clamperl, Sharpedo, Wailmer, Feebas                                                           |
| Route125                                 | water    | Tentacool, Wingull, Pelipper, Mantine                                                                              |
| Route125                                 | fishing  | Magikarp, Tentacool, Remoraid, Sharpedo, Wailmer, Seadra, Feebas                                                   |
| Route126                                 | water    | Tentacool, Wingull, Pelipper, Crawdaunt                                                                            |
| Route126                                 | fishing  | Magikarp, Tentacool, Horsea, Wailmer, Sharpedo, Mudkip, Feebas                                                     |
| Route127                                 | water    | Tentacool, Wingull, Pelipper, Dratini                                                                              |
| Route127                                 | fishing  | Magikarp, Tentacool, Horsea, Wailmer, Sharpedo, Squirtle, Feebas                                                   |
| Route128                                 | water    | Tentacool, Wingull, Pelipper, Swablu                                                                               |
| Route128                                 | fishing  | Magikarp, Tentacool, Luvdisc, Wailmer, Corsola, Omanyte, Kabutops                                                  |
| Route129                                 | water    | Tentacool, Wingull, Croconaw, Pelipper, Wailord                                                                    |
| Route129                                 | fishing  | Magikarp, Tentacool, Wailmer, Sharpedo, Quagsire, Lapras, Vaporeon                                                 |
| Route130                                 | land     | Wynaut, Primeape, Bellsprout, Nidoking, Grovyle, Torchic, Bulbasaur, Charmander                                    |
| Route130                                 | water    | Tentacool, Wingull, Pelipper                                                                                       |
| Route130                                 | fishing  | Magikarp, Tentacool, Wailmer, Sharpedo                                                                             |
| Route131                                 | water    | Tentacool, Wingull, Pelipper, Cloyster                                                                             |
| Route131                                 | fishing  | Magikarp, Tentacool, Wailmer, Sharpedo, Marshtomp, Lapras, Blastoise                                               |
| Route132                                 | water    | Seel, Chinchou, Pidgey, Pelipper, Lombre                                                                           |
| Route132                                 | fishing  | Magikarp, Tentacool, Wailmer, Sharpedo, Horsea, Clamperl, Feebas                                                   |
| Route133                                 | water    | Tentacool, Wingull, Pelipper, Sealeo                                                                               |
| Route133                                 | fishing  | Magikarp, Tentacool, Wailmer, Sharpedo, Horsea, Kingdra, Clamperl                                                  |
| Route134                                 | water    | Tentacool, Wingull, Skiploom, Pelipper, Yanma                                                                      |
| Route134                                 | fishing  | Qwilfish, Tentacool, Magikarp, Quagsire, Sharpedo, Wailmer, Horsea, Lapras, Starmie                                |
| Route135                                 | land     | Scyther, Ledian, Arbok, Clefairy, Tauros, Gloom, Meowth, Porygon, Ariados, Gligar, Heracross, Pinsir               |
| Route135                                 | water    | Horsea, Barboach, Lanturn, Wartortle, Croconaw                                                                     |
| Route135                                 | fishing  | Magikarp, Horsea, Wailmer, Clamperl, Seadra, Lapras, Sealeo, Feebas                                                |
| Route136                                 | water    | Wooper, Wingull, Omanyte, Kabuto, Dratini                                                                          |
| Route136                                 | fishing  | Magikarp, Slowbro, Wooper, Horsea, Wailmer, Lanturn, Feebas                                                        |
| Rusturf Tunnel                           | land     | Whismur, Elekid, Smoochum, Magby, Aron, Teddiursa, Tyrogue, Togepi, Larvitar                                       |
| Safari Zone North                        | land     | Phanpy, Oddish, Natu, Gloom, Xatu, Heracross                                                                       |
| Safari Zone Northeast                    | land     | Aipom, Teddiursa, Sunkern, Ledyba, Hoothoot, Pineco, Houndour, Miltank                                             |
| Safari Zone Northwest                    | land     | Rhyhorn, Oddish, Doduo, Gloom, Dodrio, Pinsir                                                                      |
| Safari Zone Northwest                    | water    | Psyduck, Golduck                                                                                                   |
| Safari Zone Northwest                    | fishing  | Magikarp, Goldeen, Seaking                                                                                         |
| Safari Zone South                        | land     | Oddish, Girafarig, Natu, Doduo, Gloom, Wobbuffet, Pikachu                                                          |
| Safari Zone Southeast                    | land     | Sunkern, Mareep, Aipom, Spinarak, Hoothoot, Snubbull, Stantler, Gligar                                             |
| Safari Zone Southeast                    | water    | Wooper, Marill, Quagsire                                                                                           |
| Safari Zone Southeast                    | fishing  | Magikarp, Goldeen, Remoraid, Octillery                                                                             |
| Safari Zone Southwest                    | land     | Oddish, Girafarig, Natu, Doduo, Gloom, Wobbuffet, Pikachu                                                          |
| Safari Zone Southwest                    | water    | Psyduck                                                                                                            |
| Safari Zone Southwest                    | fishing  | Magikarp, Goldeen, Seaking                                                                                         |
| Scorched Slab                            | land     | Charmander, Growlithe, Cyndaquil, Torchic, Ninetales                                                               |
| Scorched Slab                            | fishing  | Feebas                                                                                                             |
| Seafloor Cavern Entrance                 | water    | Tentacool, Zubat, Golbat, Milotic                                                                                  |
| Seafloor Cavern Entrance                 | fishing  | Magikarp, Tentacool, Wailmer                                                                                       |
| Seafloor Cavern Room1                    | land     | Zubat, Golbat, Aerodactyl                                                                                          |
| Seafloor Cavern Room2                    | land     | Zubat, Aerodactyl, Kabutops                                                                                        |
| Seafloor Cavern Room3                    | land     | Zubat, Golbat, Piloswine                                                                                           |
| Seafloor Cavern Room4                    | land     | Zubat, Piloswine, Golbat                                                                                           |
| Seafloor Cavern Room5                    | land     | Zubat, Lairon, Golbat                                                                                              |
| Seafloor Cavern Room6                    | land     | Zubat, Golbat                                                                                                      |
| Seafloor Cavern Room6                    | water    | Tentacool, Zubat, Golbat                                                                                           |
| Seafloor Cavern Room6                    | fishing  | Magikarp, Tentacool, Wailmer                                                                                       |
| Seafloor Cavern Room7                    | land     | Zubat, Golbat                                                                                                      |
| Seafloor Cavern Room7                    | water    | Tentacool, Zubat, Golbat                                                                                           |
| Seafloor Cavern Room7                    | fishing  | Magikarp, Tentacool, Wailmer                                                                                       |
| Seafloor Cavern Room8                    | land     | Zubat, Golbat                                                                                                      |
| Shoal Cave Low Tide Entrance Room        | land     | Zubat, Spheal, Lapras, Golbat                                                                                      |
| Shoal Cave Low Tide Entrance Room        | water    | Tentacool, Zubat, Lapras, Spheal                                                                                   |
| Shoal Cave Low Tide Entrance Room        | fishing  | Magikarp, Tentacool, Wailmer, Feebas                                                                               |
| Shoal Cave Low Tide Ice Room             | land     | Zubat, Spheal, Snorunt, Golbat, Froslass                                                                           |
| Shoal Cave Low Tide Inner Room           | land     | Zubat, Spheal, Lapras, Golbat                                                                                      |
| Shoal Cave Low Tide Inner Room           | water    | Tentacool, Zubat, Spheal                                                                                           |
| Shoal Cave Low Tide Inner Room           | fishing  | Magikarp, Tentacool, Wailmer                                                                                       |
| Shoal Cave Low Tide Lower Room           | land     | Zubat, Spheal, Lapras, Golbat                                                                                      |
| Shoal Cave Low Tide Stairs Room          | land     | Zubat, Spheal, Lapras, Golbat                                                                                      |
| Sky Pillar 1F                            | land     | Sableye, Golbat, Claydol, Banette, Sneasel                                                                         |
| Sky Pillar 3F                            | land     | Sableye, Golbat, Claydol, Banette, Snorlax                                                                         |
| Sky Pillar 5F                            | land     | Sableye, Golbat, Claydol, Banette, Altaria                                                                         |
| Slateport City                           | water    | Tentacool, Wingull, Pelipper                                                                                       |
| Slateport City                           | fishing  | Magikarp, Tentacool, Wailmer                                                                                       |
| Sootopolis City                          | water    | Magikarp                                                                                                           |
| Sootopolis City                          | fishing  | Magikarp, Tentacool, Gyarados                                                                                      |
| Underwater Route124                      | water    | Clamperl, Chinchou, Relicanth                                                                                      |
| Underwater Route126                      | water    | Clamperl, Chinchou, Relicanth                                                                                      |
| Victory Road 1F                          | land     | Golbat, Hariyama, Lairon, Loudred, Zubat, Makuhita, Aron, Whismur                                                  |
| Victory Road B1F                         | land     | Golbat, Hariyama, Lairon, Mawile                                                                                   |
| Victory Road B2F                         | land     | Golbat, Sableye, Lairon, Mawile                                                                                    |
| Victory Road B2F                         | water    | Golbat, Dratini, Dragonair                                                                                         |
| Victory Road B2F                         | fishing  | Magikarp, Goldeen, Barboach, Whiscash, Feebas                                                                      |
