| Pokemon | Changes |
|---|---|
| Abra | — |
| Absol | .baseHP +20 (now 85)<br>.baseDefense +20 (now 80)<br>.baseSpDefense +20 (now 80) |
| Aerodactyl | — |
| Aggron | .baseHP +20 (now 90)<br>.baseDefense -40 (now 140)<br>.baseSpAttack -10 (now 50)<br>.baseSpDefense +40 (now 100) |
| Aipom | — |
| Alakazam | — |
| Altaria | .baseHP +5 (now 80)<br>.baseDefense +10 (now 100) |
| Ampharos | .baseDefense +10 (now 85)<br>.baseSpAttack +10 (now 125)<br>.baseSpDefense +10 (now 100) |
| Anorith | — |
| Arbok | .baseHP +5 (now 65)<br>.baseDefense +1 (now 70)<br>.baseSpAttack -5 (now 60)<br>.baseSpDefense +1 (now 80) |
| Arcanine | — |
| Ariados | .baseHP +20 (now 90)<br>.baseAttack +10 (now 100)<br>.baseDefense +15 (now 85)<br>.baseSpAttack -20 (now 40)<br>.baseSpDefense +25 (now 85) |
| Armaldo | .baseHP +5 (now 80)<br>.baseSpeed +20 (now 65)<br>.baseSpAttack -30 (now 40)<br>.baseSpDefense +10 (now 90) |
| Aron | — |
| Articuno | — |
| Azumarill | — |
| Azurill | — |
| Bagon | — |
| Baltoy | — |
| Banette | .baseHP +1 (now 65)<br>.baseSpAttack -3 (now 80)<br>.baseSpDefense +17 (now 80) |
| Barboach | — |
| Bayleef | — |
| Beautifly | .baseAttack -30 (now 40)<br>.baseSpeed +15 (now 80)<br>.baseSpAttack +10 (now 100) |
| Beedrill | .baseAttack +20 (now 100)<br>.baseDefense +15 (now 55)<br>.baseSpeed +15 (now 90) |
| Beldum | — |
| Bellossom | .baseHP +5 (now 80)<br>.baseAttack -30 (now 50)<br>.baseDefense +15 (now 100)<br>.baseSpAttack +10 (now 100) |
| Bellsprout | — |
| Blastoise | .baseHP +1 (now 80)<br>.baseAttack +2 (now 85)<br>.baseSpeed -3 (now 75) |
| Blaziken | .baseDefense +10 (now 80)<br>.baseSpeed +15 (now 95)<br>.baseSpAttack -30 (now 80)<br>.baseSpDefense +10 (now 80) |
| Blissey | — |
| Breloom | .baseSpAttack -20 (now 40)<br>.baseSpDefense +10 (now 70) |
| Bulbasaur | — |
| Butterfree | — |
| Cacnea | — |
| Cacturne | .baseDefense +20 (now 80)<br>.baseSpDefense +20 (now 80) |
| Camerupt | .baseHP +20 (now 90) |
| Carvanha | — |
| Cascoon | — |
| Castform | — |
| Caterpie | — |
| Celebi | — |
| Chansey | — |
| Charizard | — |
| Charmander | — |
| Charmeleon | — |
| Chikorita | — |
| Chimecho | — |
| Chinchou | — |
| Clamperl | — |
| Claydol | — |
| Clefable | — |
| Clefairy | — |
| Cleffa | — |
| Cloyster | .baseHP +15 (now 65)<br>.baseDefense -40 (now 140)<br>.baseSpAttack -15 (now 70)<br>.baseSpDefense +40 (now 85) |
| Combusken | — |
| Corphish | — |
| Corsola | — |
| Cradily | .baseHP +4 (now 90)<br>.baseAttack -1 (now 80)<br>.baseDefense +8 (now 105)<br>.baseSpeed -8 (now 35)<br>.baseSpAttack +4 (now 85)<br>.baseSpDefense -2 (now 105) |
| Crawdaunt | .baseHP +7 (now 70)<br>.baseSpAttack -20 (now 70)<br>.baseSpDefense +5 (now 60) |
| Crobat | .baseHP +5 (now 90)<br>.baseSpAttack -10 (now 60) |
| Croconaw | — |
| Cubone | — |
| Cyndaquil | — |
| Delcatty | .baseHP +10 (now 80)<br>.baseDefense +10 (now 75)<br>.baseSpDefense +20 (now 75) |
| Delibird | — |
| Deoxys | — |
| Dewgong | — |
| Diglett | — |
| Ditto | — |
| Dodrio | .baseSpAttack -10 (now 50)<br>.baseSpDefense +10 (now 70) |
| Doduo | — |
| Donphan | — |
| Dragonair | — |
| Dragonite | — |
| Dratini | — |
| Drowzee | — |
| Dugtrio | — |
| Dunsparce | — |
| Dusclops | .baseHP +30 (now 70) |
| Duskull | — |
| Dustox | .baseAttack -10 (now 40)<br>.baseDefense +10 (now 80) |
| Eevee | — |
| Ekans | — |
| Electabuzz | — |
| Electivire | .baseHP 75<br>.baseAttack 123<br>.baseDefense 67<br>.baseSpeed 95<br>.baseSpAttack 95<br>.baseSpDefense 85<br>.type1 None<br>.type2 None |
| Electrike | — |
| Electrode | — |
| Elekid | — |
| Entei | — |
| Espeon | — |
| Exeggcute | — |
| Exeggutor | .baseAttack -5 (now 90)<br>.baseDefense +5 (now 90) |
| Exploud | .baseHP +1 (now 105)<br>.baseAttack +4 (now 95)<br>.baseDefense +7 (now 70)<br>.baseSpeed +2 (now 70)<br>.baseSpAttack -1 (now 90)<br>.baseSpDefense +7 (now 70) |
| Farfetchd | — |
| Fearow | .baseSpAttack -1 (now 60)<br>.baseSpDefense +4 (now 65) |
| Feebas | — |
| Feraligatr | .baseSpeed +2 (now 80)<br>.baseSpAttack -4 (now 75)<br>.baseSpDefense +7 (now 90) |
| Flaaffy | — |
| Flareon | — |
| Flygon | .baseHP +10 (now 90)<br>.baseAttack -30 (now 70)<br>.baseDefense +10 (now 90)<br>.baseSpAttack +40 (now 120)<br>.baseSpDefense +10 (now 90) |
| Forretress | .baseDefense -20 (now 120)<br>.baseSpDefense +20 (now 80) |
| Froslass | .baseHP 80<br>.baseAttack 80<br>.baseDefense 80<br>.baseSpeed 110<br>.baseSpAttack 80<br>.baseSpDefense 80<br>.type1 None<br>.type2 None |
| Furret | — |
| Gallade | .baseHP 80<br>.baseAttack 125<br>.baseDefense 70<br>.baseSpeed 80<br>.baseSpAttack 60<br>.baseSpDefense 115<br>.type1 None<br>.type2 None |
| Gardevoir | .baseHP +12 (now 80)<br>.baseAttack -5 (now 60)<br>.baseDefense +5 (now 70) |
| Gastly | — |
| Gengar | — |
| Geodude | — |
| Girafarig | — |
| Glalie | .baseHP +10 (now 90)<br>.baseDefense +10 (now 90)<br>.baseSpDefense +10 (now 90) |
| Gligar | — |
| Gliscor | .baseHP 75<br>.baseAttack 95<br>.baseDefense 125<br>.baseSpeed 95<br>.baseSpAttack 45<br>.baseSpDefense 75<br>.type1 None<br>.type2 None |
| Gloom | — |
| Golbat | — |
| Goldeen | — |
| Golduck | .baseAttack -12 (now 70)<br>.baseSpAttack +10 (now 105) |
| Golem | — |
| Gorebyss | .baseHP +20 (now 75)<br>.baseAttack -4 (now 80)<br>.baseSpeed -2 (now 50)<br>.baseSpAttack +1 (now 115)<br>.baseSpDefense +20 (now 95) |
| Granbull | — |
| Graveler | — |
| Grimer | — |
| Groudon | — |
| Grovyle | — |
| Growlithe | — |
| Grumpig | .baseDefense +20 (now 85) |
| Gulpin | — |
| Gyarados | — |
| Hariyama | .baseDefense +10 (now 70)<br>.baseSpDefense +10 (now 70) |
| Haunter | — |
| Heracross | — |
| Hitmonchan | .baseDefense +1 (now 80)<br>.baseSpeed -1 (now 75) |
| Hitmonlee | .baseDefense +17 (now 70)<br>.baseSpeed +3 (now 90)<br>.baseSpDefense -10 (now 100) |
| Hitmontop | .baseHP +5 (now 55) |
| Honchkrow | .baseHP 100<br>.baseAttack 125<br>.baseDefense 52<br>.baseSpeed 105<br>.baseSpAttack 85<br>.baseSpDefense 52<br>.type1 None<br>.type2 None |
| Hoothoot | — |
| Hoppip | — |
| Horsea | — |
| Houndoom | .baseAttack -20 (now 70)<br>.baseDefense +20 (now 70) |
| Houndour | — |
| Ho Oh | — |
| Huntail | .baseHP +20 (now 75)<br>.baseSpDefense +20 (now 95) |
| Hypno | .baseAttack +2 (now 75)<br>.baseDefense +10 (now 80)<br>.baseSpeed -2 (now 65)<br>.baseSpAttack +2 (now 75)<br>.baseSpDefense -5 (now 110) |
| Igglybuff | — |
| Illumise | — |
| Ivysaur | — |
| Jigglypuff | — |
| Jirachi | — |
| Jolteon | — |
| Jumpluff | — |
| Jynx | — |
| Kabuto | — |
| Kabutops | — |
| Kadabra | — |
| Kakuna | — |
| Kangaskhan | — |
| Kecleon | — |
| Kingdra | .baseSpeed +10 (now 95) |
| Kingler | .baseDefense -15 (now 100)<br>.baseSpDefense +15 (now 65) |
| Kirlia | .baseHP +2 (now 40)<br>.baseSpAttack +5 (now 70) |
| Koffing | — |
| Krabby | — |
| Kyogre | — |
| Lairon | .baseDefense -30 (now 110)<br>.baseSpDefense +30 (now 80) |
| Lanturn | — |
| Lapras | — |
| Larvitar | — |
| Latias | — |
| Latios | — |
| Ledian | — |
| Ledyba | — |
| Lickitung | — |
| Lileep | — |
| Linoone | — |
| Lombre | — |
| Lotad | — |
| Loudred | — |
| Ludicolo | .baseAttack -10 (now 60)<br>.baseDefense +10 (now 80) |
| Lugia | .baseAttack -10 (now 80)<br>.baseSpAttack +10 (now 100) |
| Lunatone | — |
| Luvdisc | — |
| Machamp | — |
| Machoke | — |
| Machop | — |
| Magby | — |
| Magcargo | — |
| Magikarp | — |
| Magmar | — |
| Magmortar | .baseHP 75<br>.baseAttack 95<br>.baseDefense 67<br>.baseSpeed 83<br>.baseSpAttack 126<br>.baseSpDefense 95<br>.type1 None<br>.type2 None |
| Magnemite | — |
| Magneton | .baseHP +10 (now 60)<br>.baseAttack -10 (now 50)<br>.baseSpDefense +10 (now 80) |
| Magnezone | .baseHP 70<br>.baseAttack 70<br>.baseDefense 115<br>.baseSpeed 60<br>.baseSpAttack 130<br>.baseSpDefense 90<br>.type1 None<br>.type2 None |
| Makuhita | — |
| Mamoswine | .baseHP 110<br>.baseAttack 130<br>.baseDefense 80<br>.baseSpeed 80<br>.baseSpAttack 70<br>.baseSpDefense 60<br>.type1 None<br>.type2 None |
| Manectric | — |
| Mankey | — |
| Mantine | — |
| Mareep | — |
| Marill | — |
| Marowak | .baseSpAttack -10 (now 40)<br>.baseSpDefense +10 (now 90) |
| Marshtomp | — |
| Masquerain | .baseDefense +10 (now 72) |
| Mawile | .baseHP +30 (now 80)<br>.baseSpDefense +30 (now 85) |
| Medicham | .baseHP +20 (now 80)<br>.baseDefense +5 (now 80)<br>.baseSpDefense +5 (now 80) |
| Meditite | — |
| Meganium | .baseHP +10 (now 90)<br>.baseAttack +3 (now 85)<br>.baseSpeed -5 (now 75)<br>.baseSpAttack +2 (now 85) |
| Meowth | — |
| Metagross | .baseHP +5 (now 85)<br>.baseSpAttack -25 (now 70)<br>.baseSpDefense +20 (now 110) |
| Metang | — |
| Metapod | — |
| Mew | — |
| Mewtwo | — |
| Mightyena | .baseSpAttack -10 (now 50)<br>.baseSpDefense +10 (now 70) |
| Milotic | — |
| Miltank | — |
| Minun | — |
| Misdreavus | — |
| Mismagius | .baseHP 60<br>.baseAttack 60<br>.baseDefense 60<br>.baseSpeed 105<br>.baseSpAttack 105<br>.baseSpDefense 105<br>.type1 None<br>.type2 None |
| Moltres | — |
| Mr Mime | — |
| Mudkip | — |
| Muk | — |
| Murkrow | — |
| Natu | — |
| Nidoking | .baseHP +9 (now 90)<br>.baseSpAttack -5 (now 80) |
| Nidoqueen | .baseAttack +3 (now 85)<br>.baseDefense +3 (now 90)<br>.baseSpeed +4 (now 80)<br>.baseSpAttack +5 (now 80) |
| Nidoran F | — |
| Nidoran M | — |
| Nidorina | — |
| Nidorino | — |
| Nincada | — |
| Ninetales | .baseSpAttack +4 (now 85) |
| Ninjask | .baseAttack +10 (now 100)<br>.baseSpeed -10 (now 150) |
| Noctowl | .baseDefense +30 (now 80) |
| None | — |
| Nosepass | — |
| Numel | — |
| Nuzleaf | — |
| Octillery | — |
| Oddish | — |
| Omanyte | — |
| Omastar | — |
| Onix | — |
| Paras | — |
| Parasect | .baseDefense +10 (now 90)<br>.baseSpAttack -30 (now 30)<br>.baseSpDefense +10 (now 90) |
| Pelipper | — |
| Persian | .baseAttack +10 (now 80)<br>.baseSpAttack -10 (now 55) |
| Phanpy | — |
| Pichu | — |
| Pidgeot | .baseHP +2 (now 85)<br>.baseSpAttack +10 (now 80) |
| Pidgeotto | — |
| Pidgey | — |
| Pikachu | — |
| Piloswine | — |
| Pineco | — |
| Pinsir | — |
| Plusle | — |
| Politoed | — |
| Poliwag | — |
| Poliwhirl | — |
| Poliwrath | .baseAttack +10 (now 95)<br>.baseSpAttack -10 (now 60) |
| Ponyta | — |
| Poochyena | — |
| Porygon | — |
| Porygon2 | — |
| Porygonz | .baseHP 85<br>.baseAttack 70<br>.baseDefense 70<br>.baseSpeed 90<br>.baseSpAttack 135<br>.baseSpDefense 75<br>.type1 None<br>.type2 None |
| Primeape | — |
| Probopass | .baseHP 60<br>.baseAttack 55<br>.baseDefense 145<br>.baseSpeed 40<br>.baseSpAttack 75<br>.baseSpDefense 150<br>.type1 None<br>.type2 None |
| Psyduck | — |
| Pupitar | — |
| Quagsire | — |
| Quilava | — |
| Qwilfish | — |
| Raichu | — |
| Raikou | — |
| Ralts | .baseHP +2 (now 30) |
| Rapidash | — |
| Raticate | .baseHP +5 (now 60)<br>.baseAttack +4 (now 85)<br>.baseSpeed +3 (now 100) |
| Rattata | — |
| Rayquaza | — |
| Regice | — |
| Regirock | — |
| Registeel | — |
| Relicanth | — |
| Remoraid | — |
| Rhydon | — |
| Rhyhorn | — |
| Roselia | .baseAttack +10 (now 70) |
| Roserade | .baseHP 75<br>.baseAttack 90<br>.baseDefense 70<br>.baseSpeed 95<br>.baseSpAttack 125<br>.baseSpDefense 90<br>.type1 None<br>.type2 None |
| Sableye | — |
| Salamence | — |
| Sandshrew | — |
| Sandslash | .baseSpDefense +15 (now 70) |
| Sceptile | .baseAttack +20 (now 105)<br>.baseDefense +5 (now 70)<br>.baseSpAttack -20 (now 85) |
| Scizor | — |
| Scyther | — |
| Seadra | — |
| Seaking | .baseSpeed +2 (now 70) |
| Sealeo | — |
| Seedot | — |
| Seel | — |
| Sentret | — |
| Seviper | .baseHP +10 (now 83)<br>.baseDefense +15 (now 75)<br>.baseSpAttack -50 (now 50)<br>.baseSpDefense +25 (now 85) |
| Sharpedo | .baseSpAttack -20 (now 75) |
| Shedinja | — |
| Shelgon | — |
| Shellder | — |
| Shiftry | .baseDefense +15 (now 75)<br>.baseSpAttack -30 (now 60)<br>.baseSpDefense +15 (now 75) |
| Shroomish | — |
| Shuckle | — |
| Shuppet | — |
| Silcoon | — |
| Skarmory | — |
| Skiploom | — |
| Skitty | — |
| Slaking | — |
| Slakoth | — |
| Slowbro | — |
| Slowking | — |
| Slowpoke | — |
| Slugma | — |
| Smeargle | — |
| Smoochum | — |
| Sneasel | — |
| Snorlax | — |
| Snorunt | — |
| Snubbull | — |
| Solrock | — |
| Spearow | — |
| Spheal | — |
| Spinarak | — |
| Spinda | — |
| Spoink | — |
| Squirtle | — |
| Stantler | — |
| Starmie | — |
| Staryu | — |
| Steelix | — |
| Sudowoodo | — |
| Suicune | — |
| Sunflora | — |
| Sunkern | — |
| Surskit | — |
| Swablu | .baseHP +5 (now 50)<br>.baseAttack +10 (now 50)<br>.baseSpAttack +10 (now 50) |
| Swalot | .baseAttack -20 (now 53)<br>.baseDefense +5 (now 88)<br>.baseSpAttack +10 (now 83)<br>.baseSpDefense +5 (now 88) |
| Swampert | .baseDefense +5 (now 95)<br>.baseSpAttack -10 (now 75)<br>.baseSpDefense +5 (now 95) |
| Swellow | — |
| Swinub | — |
| Taillow | — |
| Tangela | — |
| Tauros | — |
| Teddiursa | — |
| Tentacool | — |
| Tentacruel | — |
| Togekiss | .baseHP 85<br>.baseAttack 80<br>.baseDefense 85<br>.baseSpeed 90<br>.baseSpAttack 100<br>.baseSpDefense 105<br>.type1 None<br>.type2 None |
| Togepi | — |
| Togetic | — |
| Torchic | — |
| Torkoal | — |
| Totodile | — |
| Trapinch | — |
| Treecko | — |
| Tropius | .baseDefense +7 (now 90)<br>.baseSpDefense +3 (now 90) |
| Typhlosion | .baseHP +2 (now 80)<br>.baseAttack +6 (now 90)<br>.baseDefense +2 (now 80)<br>.baseSpAttack -9 (now 100) |
| Tyranitar | — |
| Tyrogue | — |
| Umbreon | — |
| Unown | — |
| Ursaring | — |
| Vaporeon | — |
| Venomoth | .baseAttack -10 (now 55)<br>.baseDefense +10 (now 70) |
| Venonat | — |
| Venusaur | — |
| Vibrava | — |
| Victreebel | — |
| Vigoroth | — |
| Vileplume | — |
| Volbeat | — |
| Voltorb | — |
| Vulpix | — |
| Wailmer | — |
| Wailord | — |
| Walrein | — |
| Wartortle | — |
| Weaville | .baseHP 70<br>.baseAttack 120<br>.baseDefense 65<br>.baseSpeed 125<br>.baseSpAttack 45<br>.baseSpDefense 85<br>.type1 None<br>.type2 None |
| Weedle | — |
| Weepinbell | — |
| Weezing | — |
| Whiscash | — |
| Whismur | — |
| Wigglytuff | — |
| Wingull | — |
| Wobbuffet | — |
| Wooper | — |
| Wurmple | — |
| Wynaut | — |
| Xatu | .baseAttack -10 (now 65)<br>.baseDefense +5 (now 75)<br>.baseSpDefense +5 (now 75) |
| Yanma | — |
| Zangoose | .baseHP +7 (now 80)<br>.baseDefense +10 (now 70)<br>.baseSpDefense +10 (now 70) |
| Zapdos | — |
| Zigzagoon | — |
| Zubat | — |