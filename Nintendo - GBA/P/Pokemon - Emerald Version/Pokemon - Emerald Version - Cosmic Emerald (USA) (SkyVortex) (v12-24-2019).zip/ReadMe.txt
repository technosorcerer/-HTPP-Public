This ROM hack of Pok�mon Emerald Version was created by SkyVortex, A.K.A. Sky0fBlades

==============
INSTRUCTIONS:
==============

1)
	Patch "[EM]-(US)-_PKMN_CosmicEmerald_v12-24-019" onto a unmodified USA Pok�mon Emerald ROM (for best results, just ensure that it has this MD-5 Checksum: 605B89B67018ABCEA91E693A4DD25BE3)
	(if you don't know how to check, find the Emerald ROM called "Pokemon Emerald (U)" through Google searching and chances are it should work)

	The patches in these folders are .IPS files, so you can use a program such as LunarIPS
		Link: https://fusoya.eludevisibility.org/lips/

2) Play, I hope you all enjoy! Also in this folder structure there is a Pok�mon Locations Guide I made, as well as Add-Ons and additional links to resources if you need them.

If you have some ideas of things I could improve in the hack, feel free to voice your opinion in the appropriate forum threads or by sending me a PM.



==================
SOURCE LOCATIONS:
==================

Silph Co. Forums [primary]

	https://forum.silphco.io/threads/pokemon-cosmicemerald-version.186/
--------------------------

Pok�Community Forums [secondary]

	https://www.pokecommunity.com/showthread.php?p=9730097
--------------------------