Please patch using Lunar IPS!
Rom used to test the patch was built using the pokeemerald decomp project.

Thank you for playing and hope you enjoy the new features! :)
-Astro

Starter and legendary encounter locations:
(Legendaries are 1% encounters on these locations)

Bulbasaur: Petalburg Woods
Squirtle: Route 103 (fishing)
Charmander: Fiery Path
Cyndaquil: Route 115
Chikorita: Route 115
Totodile: Route 102 (fishing)
Torchic: Jagged Pass
Mudkip: Route 102
Treecko: Route 116

Articuno: Meteor Falls B1F 2R
Moltres: Victory Road B2F
Zapdos: New Mauville interior
Mew: Altering cave/event
Mewtwo: Altering cave
Entei: Cave of Origin F1
Raikou: Cave of Origin F1
Suicune: Cave of Origin Entrance
Lugia/Ho-oh: Pick event item from player PC
Deoxys/Mew: Pick event item from player PC
Jirachi: Mt Pyre summit (outside)
Celebi: Shoal cave entrance on low tide
Latios/Latias (Apart from the roamer): Sky Pillar 5F