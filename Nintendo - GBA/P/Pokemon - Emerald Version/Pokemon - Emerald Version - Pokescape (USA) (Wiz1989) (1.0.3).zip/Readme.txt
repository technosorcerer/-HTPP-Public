How to patch this file:

1) Get an unmodified ROM of Pokemon - Emerald Version (USA, Europe)
2) Click on the UPS patcher, included in the zip-file (tsukuyomi.exe)
3) Select the UPS file and then the unmodified ROM
4) Wait for it to patch
5) Play the game!

Enjoy!