See the thread at https://www.pokecommunity.com/threads/pok%C3%A9mon-tourmaline.527425/ for more information.

Message me (tdilos) there or on the discord if you have any questions, comments, or feedback.


**********USEFUL NOTES (READ BEFORE PLAYING)**********

CURRENT VERSION (v1.0.3): Playable up to the Hall of Fame + some minor postgame content

FAQ: Located in the OP post in the pokecommunity thread. Check there for information about karma, difficulty modes, level caps, etc.

KNOWN ISSUES: See the OP post in the pokecommunity thread for a list of these.



