Current Ver.: 1.0
________________________________________________
 
           Moémon Star Emerald Ver.
               by Axcellerator
________________________________________________
 
SPRITERS WANTED:
The Moémon project will always appreciate having more talent on board!
Join our discord at https://discord.gg/fHPHSVNaqQ for more information.
 
Follow our Twitter/X to always be updated: https://x.com/MoemonOfficial
 
   +------------------------------------+
   |                                    |
   | Table of Contents:                 |
   |                                    |
   | 1. Getting Started                 |
   |    1.1) Emulator                   |
   |    1.2) ROM and Patching Info      |
   | 2. About the Patch                 |
   |    2.1) Features                   |
   |    2.2) Other Changes              |
   |    2.3) How to Mega Evolve         |
   | 3. Bugs                            |
   | 4. Other Information               |
   |                                    |
   +------------------------------------+
 
 
--< 1. Getting Started >--
 
1.1) Emulator:
   The game has been currently tested in VBA-M, mGBA and MyBoy. We recommend using the last version of these to avoid having issues.

   BEFORE PLAYING: Make sure to change your Emulator's settings so the Save Type is Automatic and Flash 128k, otherwise you may not be able to start the game.
 
1.2) ROM and Patching Info:
   The UPS file must be patched to this specific Pokémon Emerald GBA ROM:

   1986 - Pokemon Emerald (U)(TrashMan).gba
 
   If the ROM you have does not have the above filename, we strongly advise against patching to it.

   You can also verify if you have the correct ROM checking the following:
   The CRC32 hex code for the correct ROM is 1F1C08FB. 
   The MD5 is 605B89B67018ABCEA91E693A4DD25BE3.

   << WE ABSOLUTELY DO NOT PROVIDE ROMS >>
 
   Use a .ups patcher (such as NUPS or tsukuyomi) to apply the .ups patch to the .gba ROM.
   We recommend keeping a fresh copy of the original ROM for when a new update is released.
 
   DO NOT RANDOMIZE THIS GAME.
 
--< 2. About the Patch >--
 
2.1) Features:

   • All featured Pokémon have been replaced with their Moémon counterparts!
   • Over 800 Moémon species from all generations, including some from Generation 8 and 9.
   • Physical/Special/Status move split.
   • Many battle mechanics up to Generation 7, with some Generation 8 and 9 moves.
   • Mega Evolution available.
   • No need for trading to evolve your Moémon.
   • Added several newer cross evolutions, check our Changed Evolutions document for more information.
   • Every Trainer has been updated to use different teams and moves from the base game.
   • Increased difficulty.
   • Optional Level Caps added.
   • New rivals in your journey.
   • New locations to visit.
   • New Battle Backgrounds and Overworld Graphics.
   • Reusable TMs.
   • HM items (No more need for HM Slaves).
   • Use Apricorn to craft Poké Balls.
   • New Poké Balls.
   • Hidden Grottos.
   • New Move Tutors.
   • Egg Moves Tutor in Lilycove City.
   • Move Relearner now asks for $1,000.
   • EV Training QoL.
   • New Ticket Reward system.
   • Password System for Events and Special Gifts.
   • Most evolution items are sold in Lilycove City.
   • Vitamins are uncapped.
   • Movesets updated updated to more modern mixed movesets, some less used Moémon even got new moves to have a chance to shine!
   • A couple of Moémon have received new typings, check the Section 2.3.

2.2) Other Changes:

   The following Moémon have received changes in their typings:

   - Bayleef > Grass/Fairy.
   - Meganium > Grass/Fairy.
   - Feraligatr > Water/Dark
   - Goodra > Dragon/Poison.

2.3) How to Mega Evolve:
   _________________________________________________________________________________

      1: Have a Mega Bracelet in your inventory.
      2. Give the Moémon the correct Mega Stone to hold.
      3. In battle, select Attack, then press Start (Whatever your key is)
      4. Use a move.
 
      The Mega Stones are scattered all over the region (Looking like sparkling spots, some may be gifts), and can be used after obtaining the Mega Bracelet from Steven in Route 118.

   _________________________________________________________________________________
 
--< 3. Bugs >--
 
   1) The time-based events follow your device's (Your PC/Phone/etc) clock rather than your room's clock.
   2) Backup your save before using the Battle Frontier's facilities or the Battle Tents, some of them can randomly wipe out your PokéDex's data.
   3) Due to how EV gain works in gen 3, your mon will be unable to recieve EVs from EV training once it reaches level 100. The Vitamins still work for this, and they are uncapped.
   4) The Search function by Name in the Pokedex is currently broken.
   5) The Pokedex Order function has all of its listings incorrectly sorted.
   6) Sometimes rare candies will report +0 on stats. That's only a visual bug.
 
 
--< 4. Other Information >--
 
   We do not provide support for cheats or randomization. We heavily advise against using them as the results are unpredictable.
 
   Haven't seen your favorite mon? Chances are we do not have a sprite ready for it.
 
 
   Contact info:
   Interested in spriting for Moémon?
   Found a bug that isn't listed above?
   Please join our discord at: https://discord.gg/fHPHSVNaqQ
   Please read all the rules and resources.
 
   Support Us:
   Support the spriters!
   https://www.patreon.com/Moemon_Project
 
   The spriters are the backbone of the project. Without them, we wouldn't have a ROMhack to showcase the wonderful work they have contributed.
   If you appreciate the art in the game and would like to see more in the future, consider supporting their hard work!