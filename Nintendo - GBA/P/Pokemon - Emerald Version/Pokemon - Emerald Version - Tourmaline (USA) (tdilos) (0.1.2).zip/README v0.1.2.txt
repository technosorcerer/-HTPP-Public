See the thread at https://www.pokecommunity.com/threads/pok%C3%A9mon-tourmaline.527425/ for more information.

Message me (tdilos) there or on the pret discord if you have any questions, comments, or feedback.

**********USEFUL NOTES (READ BEFORE PLAYING)**********

CURRENT DEMO (v0.1.2): Playable up to the third gym. The player won't be able to progress any farther without an item that's currently unobtainable.

MECHANICS CHANGES: As mentioned in the pokecommunity thread, new moves/abilities have been added and a good number of old moves/abilities have been changed, too many to list here. Let me know if you have questions or if anything doesn't seem to be working properly.

LEVEL CAPS: In the current version, the starting level cap is 16, the first gym badge raises it to 32, and the third gym badge raises it to 48.

DIFFICULTY SETTINGS: These are experimental right now. HARDCORE and INSANE decrease the EXP/money earned from battles. Also Set mode and no bag usage in trainer battles are enforced. INSANE also charges the player a small fee for PokeCenter use.

OPTIONAL WIN FIGHTS: There are several places in the game where winning isn't necessary in order to progress. The story changes slightly based on the outcome of the battle.

UNFINISHED AREAS: The first big city has a few buildings that are blocked off for now. These will be added in a future release.

SWARMS: New swarms are randomly generated each day. Check any TV in the overworld to see what's currently swarming.


**********KNOWN ISSUES**********

EMULATOR SPEEDUP: This has a tendency to glitch the game in unpredictable ways. Use it sparingly and save often if you do.

DOUBLE BATTLE GLITCH: After fighting a double battle trainer (e.g. Twins), during wild battles, the player will send out two Pokemon as if it were a double battle. These battles otherwise seem to behave normally. The player can even catch the wild Pokemon without issue. Fighting a single battle trainer fixes this issue. This glitch does NOT happen after fighting a double battle against two separate trainers.

POKEDEX GLITCH: The pokedex pages for new regional forms don't show the correct sprites. The player will see the base form instead.

STATUS BAR GLITCH: Enemy status bars sometimes show the wrong color for status conditions. For example, the BRN symbol may be black instead of the correct red color. This is a minor graphics glitch that I haven't found a fix for yet. It doesn't affect anything else and it often fixes itself, so just ignore it.

CINEROUS TOWN GLITCH: The gate at the top of the map sometimes pulls from the wrong tileset. Entering and exiting a building fixes it for now.

DOORS: Some doors change color when you enter them. I'll add proper door animations for them at some point in the future.

WINDOWS AT NIGHT: Sometimes these will be strange colors instead of the correct yellow shade. Entering and exiting a building fixes this for now.

MUSIC: This is something I still have a lot to learn about. Some gen 4 songs are used but don't have enough sound channels, meaning only part of the song is heard. All of them should still be listenable.

