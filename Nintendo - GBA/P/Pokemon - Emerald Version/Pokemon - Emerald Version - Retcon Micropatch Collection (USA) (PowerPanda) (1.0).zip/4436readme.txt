Title: FireRed Retcon MicroPatches
Author: PowerPanda
Version: 1.0

Applies to: Pok�mon Emerald
No-Intro Name: Pokemon - Emerald Version (USA, Europe)
(No-Intro version  20130720-015858)
ROM/File SHA-1: F3AE088181BF583E55DAF962A92BB46F4F1D07B7

--------------------------------------------------------------------------------
-=Intro and Description=-

Retcon - Short for "retroactive continuity", a practice in media where previously-
established information is changed in order to fit with a new direction that the
series is going. 

The Pok�mon Series, for the most part, does not retcon. Instead, they create
elaborate reasons for why things didn't exist before. One example of this is in
Eevee's evolutions. Rather than simply adding new evolutions, GameFreak came up
with increasingly complex reasons why Eevee couldn't evolve to new forms in 
previous games. First it was because of happiness, then because it must evolve
in certain locations, then because it needs to know a specific move. In other
cases, they pass off bugs as intentional decisions. For example, Pinsir is a Bug
Type Pok�mon that learns only Fighting Type moves. However, since it wasn't a
Bug/Fighting Type from the beginning, that will never be corrected.

The refusal to retcon has added up over the years. Enter this Micropatch Collection.
It targets Gen III games and makes a series of retcons to provide a fuller, richer
experience for longtime players. 

It contains 2 main categories: evolution/breeding changes and type changes. Each
patch is fully compatible with all of the others, and SHOULD be compatible with 
most other hacks, as they only change one byte here and there. The reason this 
is released as a "micropatch collection" and not one big patch is to allow players
to choose which changes they want to make, and which they want to ignore.

--------------------------------------------------------------------------------
-=All-In Patch=-

*allin.ips - This patch contains all of the patches listed below.

--------------------------------------------------------------------------------
-=Evolution/Breeding Changes=-

*azurill.ips - This patch "corrects" Azurill's gender ratio from 75%/25% to the
50%/50% split seen in Marill and Azumarill, so your Azurill's gender will not
change upon evolution. This patch also changes Azurill's type to Water.

*eevee.ips - This patch changes how Eevee evolves into Espeon and Umbreon.
Use a sunstone to evolve to Espeon, and a moonstone to evolve to Umbreon. Note 
that this will not work in FireRed until you obtain the National Dex.

*nidorina.ips - Did you know that Nidorina and Nidoqueen cannot breed? And that
despite that, there is code for them to produce either Nidoran F or Nidoran M
when they breed? This is because Nidorina and Nidoqueen were never assigned to
an egg group. This patch gives them the correct Monster/Field egg groups.

*mrmime.ips - Mr. Mime is not a "Mr." in Japanese, so "he" has a 50%/50% gender
split. This patch changes the gender ratio to 100% Male.

*babyless.ips - Baby Pok�mon cannot breed. This patch removes the "baby" status,
allowing them all to breed. Affects Pichu, Cleffa, Igglybuff, Togepi, Azurill, 
Wynaut, Tyrogue, Smoochum, Elekid, and Magby.

*happiness.ips - This patch changes around which baby Pok�mon evolve by happiness.
Smoochum, Elekid, and Magby now evolve by happiness. Pichu, Cleffa, Igglybuff,
and Azurill all evolve at Level 13. Additionally, Marill has been changed to evolve
to Azumarill with a Water Stone. (Togepi, Wynaut, and Tyrogue are unchanged.)

--------------------------------------------------------------------------------
-=Type Changes=-

*badkitty.ips - Changes Meowth & Persian to Dark
When Dark and Steel type were added in Gen 2, Magnemite and Magneton were changed
to have a secondary steel type. However, no Dark types were added to the Gen 1
roster. Alolan Meowth is what the original Meowth should have been, a pure dark
type. This also changes Pay Day into a Dark-type move.

*clamperl.ips - Changes Huntail to Water/Dark and Gorebyss to Water/Psychic
Allows these 2 mirrored Pok�mon to be opposites of each other.

*dragons.ips - Changes Bulbasaur to Grass, Charizard to Fire/Dragon, Blastoise to Water/Steel,
Gyarados to Water/Dragon, and Sceptile to Grass/Dragon
This is one of the most-requested type changes. It adds 3 more dragons to the mix:
Charizard, Gyarados, and Sceptile. It also makes Bulbasaur a pure Grass type, gaining
a Poison-typing only upon evolution to Ivysaur, and gives Blastoise a secondary
Steel typing.

*lightningbug.ips - Changes Volbeat and Illumise to Bug/Electric
The Japanese word for firefly is "lighning bug". It is clear from their movesets
that these two have electric ability. This patch just gives them the secondary
typing.

*lugia.ips - Changes Lugia to Water/Flying
Lugia, the master of the seas, is... not a Water type. This patch corrects that.

*normalize.ips - Changes Unown, Wobuffet, and Wynaut to Normal
There is no reason for these 3 to be Psychic. It makes much more sense for all
of them to be Normal type.

*pinsir.ips - Changes Pinsir to Bug/Fighting
Pinsir is a Bug-type Pok�mon that learns only Fighting-type moves. By adding a
secondary Fighting type, Pinsir becomes as useful as Scyther and Heracross.

*porygon.ips - Changes Porygon & Porygon2 to Electric
They are virtual Pok�mon. It makes sense.

*psydark.ips - Changes Girafarig to Psychic/Dark and Absol to Dark/Psychic
Both Pok�mon fit a dual Psychic/Dark type, both in visual design and in moves.

*psyduck.ips - Changes Psyduck and Golduck to Water/Psychic
The type is in the name itself.

*purity.ips - Changes Geodude/Graveler to Rock and Gastly/Haunter to Ghost
Gen 1 did not have enough Rock or Ghost type moves to support a pure Rock or Ghost
type. As a result, the Geodude line gained a secondary Ground type, and the Ghastly
line gained a secondary Poison type. This patch changes it so that the secondary
typing does not come until the Pok�mon evolve to their final forms.

--------------------------------------------------------------------------------
Credits

Hacking - PowerPanda

Programs Used
PGE v3.8.1