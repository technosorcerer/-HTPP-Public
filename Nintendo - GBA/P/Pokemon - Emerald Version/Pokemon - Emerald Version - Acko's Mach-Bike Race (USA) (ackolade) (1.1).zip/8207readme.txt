Acko's Mach-Bike Race hack by Archie for ackolade



Release Video: https://youtu.be/UHkdCVDA-ZE
The original BPS file is available in the description with its license.



Acko's Mach-Bike Race is a romhack challenge centered on Mach-Bike.
It contains 3 bike-only levels focused on testing and improving your moving skills.
Any bumps into walls or people will lead to your death!
The Right Shoulder can slowdown the framerate for difficult sections.



ROM to patch: Pokemon - Emerald Version (USA, Europe)
per No-Intro: Game Boy Advance (v. 20210227-023848)
File SHA-1: B217952B980E6D1628D1E43E991753B59623076D
File CRC32: 53CEA92A
ROM SHA-1: F3AE088181BF583E55DAF962A92BB46F4F1D07B7
ROM CRC32: 1F1C08FB



MIT License