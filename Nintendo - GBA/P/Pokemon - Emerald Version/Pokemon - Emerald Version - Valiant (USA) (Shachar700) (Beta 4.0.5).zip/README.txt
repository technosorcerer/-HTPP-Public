Thank you for downloading Pokemon Valiant Beta 4!

Apply the patch onto a clean Pokemon Emerald (Trashman), 
using a rom patcher.

Online patching tool: https://www.marcrobledo.com/RomPatcher.js/

The beta is roughly 10-30 hours,
has 1 Pokémon League challenge
and ends at LILYCOVE CITY HARBOR.

If you want to leave feedback or report bugs,
the best place for that will be the discord server:
https://discord.gg/wcEwv9bytW

Best regards,
Shahar