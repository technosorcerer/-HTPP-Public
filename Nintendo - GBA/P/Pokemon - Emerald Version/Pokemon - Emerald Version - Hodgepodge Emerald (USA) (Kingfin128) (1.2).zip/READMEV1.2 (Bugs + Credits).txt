Known Bugs:
Magician works funky with Frost Orb (will be fixed in the future)
All Natures are set to Quirky but sometimes other Natures will pop up (all natures are just now neutral for this hack as a dodgy fix)
Shinies may appear but are a bit finicky
myboy can't run the game i think
squares in the back pocket may disappear just a visual thing

Project Credits:
Chairry, Livra & Sadfish - Project Leads

Livra, Ogwon, SharkGuy, Yondi/FBI, Bepis, Lichen, Dahlia, EeVeeEe, Ty_Sprites, Dillsacke, BigBoiPablo, Enwaitea, Val, PurrfectDoodle, Plasto, Memelord, DahViper, GaboSwampert, BonzosBunker, Celadonk, Clove, Cuprite, Savannah, TardySoap - Art and Sprite Design

Sadfish, Ghoulslash, Wiz1989, Shuckle Lord Mixone, SparkleButt/mcnomnom, BSBob, Mudskipper13 - Coding

Chairry - Map Design and Scripting

TrainerX493 - Extensive Tester, Hodgepodge's Strongest Soldier

Pret, RHH, and Pokemon Emerald Expansion - Decompilation & Code Base

GaboSwampert - for getting the highest win streak :^) (40)

Special Thanks to the rest of the Pebbler Platoon for playing and supporting the hack before release!