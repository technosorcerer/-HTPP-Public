Randolocke v1.0 Release Notes
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

(Please report any bugs by email to: randolocke.contact@gmail.com)

Randolocke is a Nuzlocke-oriented randomized Emerald ROM hack, inspired by the ROM hack used
in PChal and Pointcrow's Nuzlocke Invitational Tournament. Version 1.0 has the following features:

	General Randomization Features
	~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*	Every Pokemon up to and including gen 9.
*	Every wild Pokemon, Trainer's Pokemon and gift Pokemon is randomized to a Pokemon with similar BST. Starters and gift Pokemon are guaranteed to have 3 perfect IVs.
*	Every ability is randomized (except Shedinja's).
*	Every move (including TMs but excluding HMs) is randomized.
*	Every item found in the field or obtained as a gift has been randomized.
*	Every Tutor move has been randomized.


	Battle Features
	~~~~~~~~~~~~~~~

*	Every Pokemon learns 21 moves at the same levels: 7 STAB moves, 7 non-damaging moves and 7 damaging moves.
*	All Pokemon can learn every move.
*	There are hard level caps in place between every badge:
		0 badges earned: 	14
		1 badges earned: 	21
		2 badges earned: 	24
		3 badges earned: 	29
		4 badges earned: 	36
		5 badges earned: 	43
		6 badges earned: 	47
		7 badges earned: 	50
		8 badges earned: 	63
		Elite Four defeated:	100
*	All trainers' Pokemon have been scaled up and adjusted to the level caps.
*	The opponents' AI has been upgraded to make them more of a challenge.


	Quality of Life Features
	~~~~~~~~~~~~~~~~~~~~~~~~

*	To use HMs out of battle, you don't need to have a Pokemon that knows the move in the party.
*	HMs can now be forgotten, just like normal moves.
*	Each Pokemons' IVs can be seen in the summary screen.
*	The bag size has been slightly expanded.
*	Added some Quality of Life Key Items:
		- An (infinite) Repellant
		- A Porta Heal
		- An Endless Candy (levels a Pokemon by 1)
		- A Cap Candy (levels a Pokemon up to the next level cap, the next level the Pokemon learns a move, the next level the Pokemon evolves or by 1 of the Pokemon evolves via an item)


	Map Changes
	~~~~~~~~~~~

*	The Old Rod sailor has been moved to Route 103 to enable fishing earlier.
*	Scorched Slab has been populated with Pokemon.
*	Added Water to Littleroot Town and Grass to Oldale Town.
*	To make sure all Pokemon can evolve, several new areas and events have been added:
		- The Lilycove Dept. Store now has two new sellers. Between them, they sell all evolution items (except for Scroll of Darkness and Scroll of Waters -- see below).
		- The Scroll of Darkness and Scroll of Waters can be obtained from the white rock in Mossdeep City (finally it's useful).
		- A Tutor Mansion has been added to Lilycove City where you can teach your Pokemon any move that is needed for an evolution.
		- A new event has been added to Route 123, giving you the option to fight three Bisharps with Leader's Crest so that Bisharp can evolve.
		- In Fallarbor town, you are gifted a Remoraid so that Mantyke can evolve.
		- In Verdanturf Town, two new trades have been added so that Shelmet and Karrablast can evolve.
		- In Mauville Game Corner, an NPC gives you 999 Gimmighoul Coins so that Ghimmighoul can evolve.
		- In Route 111 in the desert, a statue has been added so that Galarian Yamask can evolve under the right circumstances (this feature is untested).


	Unavailable Features
	~~~~~~~~~~~~~~~~~~~~

	- Mega Evolutions
	- Primal Reversions
	- Dynamax Forms
	- Gigantamax Forms
	- Tera Forms
	- Fusion Forms
	- Z Moves

Credits & Special Thanks
~~~~~~~~~~~~~~~~~~~~~~~~

*	Based off RHH's pokeemerald-expansion 1.12.1 https://github.com/rh-hideout/pokeemerald-expansion/
*	pret for making the first decomp of Emerald. https://github.com/pret/pokeemerald
*	The RH Hideout Discord Community for being very helpful.
	Special shoutouts to SBird and MGriffin for their awesome ideas and help.
*	PChal and Pointcrow for creating an awesome event and inspiring this ROM hack.
*	Hope you enjoy the game! :) If you do, please spread the word and let others know about it! :)