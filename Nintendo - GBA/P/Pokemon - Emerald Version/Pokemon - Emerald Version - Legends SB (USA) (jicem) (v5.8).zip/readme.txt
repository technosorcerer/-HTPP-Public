Pokémon Legends: SB
A ROM hack by jicem

You play as Brendan or May, stuck on a mostly deserted island and tasked with finding the legendary Pokémon Kyogre.

Should be a 20-30 minute experience.

Features:

All the base features of pokeemerald-expansion 1.12.1 (except the Day/Night System, which wasn't a good fit for this hack)
Rare candies and repels available in your PC (which can be accessed from the Pokémon Center) if you would like to minimize grinding and unwanted encounters

Instructions for playing the game:

Get a ROM of Pokémon Emerald (should end in .gba) and patch the ROM using any of the multitude of tools you can find online
I have a mirror of the most common patching tool at https://jicem.neocities.org/patcher/ for your convenience
Use the Emerald ROM file as your ROM file and legends.bps in this folder as your patch file if using the above tool
After you apply the patch, you should generate a new .gba file with (patched) at the end of the name or something similar
Use the new file anywhere that can play Gameboy Advance games