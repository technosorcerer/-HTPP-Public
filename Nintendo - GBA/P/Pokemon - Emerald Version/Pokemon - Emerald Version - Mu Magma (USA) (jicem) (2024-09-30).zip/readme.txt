Pokémon Mu Magma (pronounced Mew Magma) is a rom hack of Pokémon Emerald that lets you play as a male or female Team Magma Grunt, with custom sprites, story changes, and many QOL changes to boot.

Features:

All of the base features of pokeemerald-expansion version 1.9 including PSS, fairy type, and modern learnsets
Reusable TMs
Gen 5-style popups when you enter new areas of the map
Gen 6-style Exp. Share as a key item given you in Petalburg Woods like in ORAS
Mega Evolution with several Mega Stones available as items you can collect
With this in mind, the Items pocket of the bag can now hold up to 42 items (similar to FRLG) instead of the default 30
Pressing B toggles run instead of needing to be held to run
Any Pokémon you're traveling with can use a field move as long as the HM for it is in your bag
The Cleanse Tag will let you avoid all wild encounters if it's held by any of your Pokémon, and you can find one from the start of the game on your PC
Switch between the mach bike and acro bike at any time by pressing R
Pokémon now have soft level caps to encourage you to use different ones, especially early in the game
You get the S.S. Ticket halfway through the game instead of in the postgame, letting you go directly from Slateport to Lilycove and travel to previously champion-exclusive and event-exclusive locations (including, of course, the one where you encounter Mew)

Dex Completion:

All Hoenn Pokémon from the Gen III games can be acquired either through wild encounters or evolution, and the nine forms introduced in the Gen IV games can be caught as well. All three starter Pokémon and any trade exclusive Pokémon can also be caught in the wild, so fully completing this game's regional dex by yourself should be possible. Gengar is also in Hoenn now because I like Gengar.

There are also several changes to dialogue and characterization tweaks to account for the fact that you're a Magma Grunt and to make the hack feel a bit more unique. This isn't a complete story overhaul like some of the other villain hacks, as I wanted to preserve as much of the original gameplay as possible, but there will be some surprises. If you decide to try this hack, please let me know what you think, and if anything breaks, definitely let me know then so I can try and fix it.

Enjoy!