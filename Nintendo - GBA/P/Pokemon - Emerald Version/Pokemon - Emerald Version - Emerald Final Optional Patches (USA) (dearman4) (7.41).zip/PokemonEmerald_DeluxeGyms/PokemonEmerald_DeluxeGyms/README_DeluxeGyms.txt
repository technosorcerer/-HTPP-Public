Apply Patch:	Apply to a ROM patched by Emerald Final (Deluxe version ONLY) after all other optional patches.  

Changelog: 	Changed all gym leader rebattles to Single (from Double)
		Changed many Pokemon used by gym leaders
		Updated Pokemon to use Gen 4 moves and abilities

Note: 		The following Pokemon have had their abilities switched. This will affect all Pokemon of this type:
		
		Shuckle, Sudowoodo, Machop, Machoke, Machamp, Hitmontop, Voltorb, Electrode, Numel, Camerupt, Ponyta, 
		Rapidash, Slugma, Magcargo, Chansey, Blissey, Meowth, Persian, Kangaskhan, Tropius, Remoraid, Octillery, 
		Spheal, Sealeo, Walrein, Shellder, Cloyster

		Use the Ability Switcher to change any captured Pokemon that have had their abilities switched. 

Gym Leaders:

+++++++++++++++++++++++++++++++++

ROXANNE

12 Geodude (IVs=12)@????????
- "Rock Polish"
- "Stealth Rock"
- "Defense Curl"
- "Rock Tomb"

12 Onix (IVs=12)@????????
- Harden
- Screech
- Headbutt
- "Rock Throw"

15 Nosepass (IVs=24)@"Oran Berry"
- "Thunder Wave"
- "Iron Defense"
- Mud-Slap
- "Rock Tomb"

---------------------------------

32 Shuckle (IVs=31)@"Sitrus Berry"
- "Bug Bite"
- Withdraw
- Bide
- "Rock Slide"

34 Graveler (IVs=31)@????????
- "Stealth Rock"
- Rollout
- Sandstorm
- "Defense Curl"

35 Onix (IVs=31)@????????
- "Iron Tail"
- Screech
- Headbutt
- "Rock Slide"

37 Nosepass (IVs=31)@"Sitrus Berry"
- "Thunder Wave"
- Magnitude
- Thunderbolt
- "Power Gem"

---------------------------------

38 Shuckle (IVs=31)@"Sitrus Berry"
- Toxic
- Withdraw
- "Bug Bite"
- "Rock Slide"

40 Golem (IVs=31)@????????
- "Stealth Rock"
- Rollout
- "Defense Curl"
- Sandstorm

40 Onix (IVs=31)@????????
- "Iron Tail"
- Dragonbreath
- "Headbutt"
- "Rock Slide"

40 Corsola (IVs=31)@"Sitrus Berry"
- "Aqua Ring"
- Waterfall
- "Icy Wind"
- "Rock Slide"

42 Nosepass (IVs=31)@"Sitrus Berry"
- "Thunder Wave"
- Magnitude
- Thunderbolt
- "Power Gem"

---------------------------------

47 Shuckle (IVs=31)@"Chesto Berry"
- Toxic
- Rest
- "Bug Bite"
- "Rock Slide"

47 Corsola (IVs=31)@"Sitrus Berry"
- "Ice Beam"
- Waterfall
- "Rain Dance"
- "Stone Edge"

47 Golem (IVs=31)@????????
- "Stealth Rock"
- Explosion
- Earthquake
- Sandstorm

48 Onix (IVs=31)@????????
- "Iron Tail"
- "Dragon Pulse"
- "Double Edge"
- "Rock Slide"

50 Nosepass (IVs=31)@"Sitrus Berry"
- Thunder
- "Earth Power"
- Gravity
- "Stone Edge"

---------------------------------

54 Shuckle (IVs=31)@"Sitrus Berry"
- "Double Team"
- "Gyro Ball"
- "Power Trick"
- "Rock Slide"

56 Corsola (IVs=31)@"Sitrus Berry"
- Blizzard
- Waterfall
- "Rain Dance"
- "Stone Edge"

56 Sudowoodo (IVs=31)@"Sitrus Berry"
- "Wood Hammer"
- "Hammer Arm"
- "Ice Punch"
- "Double Edge"

56 Golem (IVs=31)@????????
- "Stealth Rock"
- Explosion
- Earthquake
- Thunderpunch

56 Steelix (IVs=31)@????????
- "Iron Head"
- "Fire Fang"
- "Aqua Tail"
- "Double Edge"

58 Nosepass (IVs=31)@"Sitrus Berry"
- Thunder
- "Earth Power"
- Gravity
- "Stone Edge"

+++++++++++++++++++++++++++++++++

Brawly

16 Machop (IVs=12)@????????
- "Karate Chop"
- "Focus Energy"
- Headbutt
- "Bulk Up"

16 Meditite (IVs=12)@????????
- Confusion
- Reflect
- "Brick Break"
- "Bulk Up"

19 Makuhita (IVs=24)@"Sitrus Berry"
- "Force Palm"
- "Smelling Salt"
- "Rock Slide"
- "Knock Off"

---------------------------------

33 Tyrogue (IVs=31)@????????
- "Bullet Punch"
- Facade
- Thief
- "Hi Jump Kick"

33 Meditite (IVs=31)@????????
- Psychic
- "Brick Break"
- Reflect
- Thunderpunch

33 Machoke (IVs=31)@"Sitrus Berry"
- "Rolling Kick"
- "Rock Slide"
- "Cross Chop"
- Payback

37 Hariyama (IVs=31)@"Sitrus Berry"
- "Force Palm"
- "Smelling Salt"
- "Faint Attack"
- "Belly Drum"

---------------------------------

38 Machamp (IVs=31)@"Sitrus Berry"
- "Mega Kick"
- "Rock Slide"
- Dynamicpunch
- Payback

38 Medicham (IVs=31)@????????
- "Psycho Cut"
- Thunderpunch
- "Poison Jab"
- "Hi Jump Kick"

40 Hitmontop (IVs=31)@"Sitrus Berry"
- Pursuit
- "Rolling Kick"
- "Aerial Ace"
- "Rapid Spin"

42 Hariyama (IVs=31)@"Sitrus Berry"
- "Force Palm"
- "Smelling Salt"
- "Faint Attack"
- "Belly Drum"

---------------------------------

43 Machamp (IVs=31)@"Sitrus Berry"
- "Giga Impact"
- "Rock Slide"
- Dynamicpunch
- Payback

43 Medicham (IVs=31)@????????
- "Zen Headbutt"
- Thunderpunch
- "Poison Jab"
- "Hi Jump Kick"

45 Hitmontop (IVs=31)@"Sitrus Berry"
- Pursuit
- "Rolling Kick"
- "Aerial Ace"
- Earthquake

45 Heracross (IVs=31)@????????
- "Bug Bite"
- "Night Slash"
- "Aerial Ace"
- "Close Combat"

47 Hariyama (IVs=31)@"Black Belt"
- "Force Palm"
- "Smelling Salt"
- "Faint Attack"
- "Belly Drum"

---------------------------------

52 Machamp (IVs=31)@"Sitrus Berry"
- "Giga Impact"
- "Rock Slide"
- DynamicPunch
- Payback

54 Medicham (IVs=31)@????????
- "Zen Headbutt"
- Thunderpunch
- "Poison Jab"
- "Hi Jump Kick"

54 Hitmontop (IVs=31)@"Sitrus Berry"
- Pursuit
- "Rolling Kick"
- "Aerial Ace"
- Earthquake

56 Heracross (IVs=31)@????????
- Megahorn
- "Night Slash"
- "Aerial Ace"
- "Close Combat"

56 Poliwrath (IVs=31)@"Sitrus Berry"
- Waterfall
- Hypnosis
- "Belly Drum"
- "Wake-Up Slap"

58 Hariyama (IVs=31)@"Black Belt"
- "Force Palm"
- "Smelling Salt"
- "Faint Attack"
- "Stone Edge"

+++++++++++++++++++++++++++++++++

Wattson

20 Voltorb (IVs=24)@????????
- Rollout
- "Double Team"
- Sonicboom
- "Shock Wave"

20 Mareep (IVs=31)@????????
- Thundershock
- Reflect
- "Signal Beam"
- "Cotton Spore"

22 Magneton (IVs=27)@????????
- Supersonic
- "Magnet Rise"
- "Shock Wave"
- "Tri Attack"

24 Manectric (IVs=30)@"Sitrus Berry"
- "Quick Attack"
- "Charge Beam"
- "Ice Fang"
- Charge

---------------------------------

36 Flaafy (IVs=31)@????????
- Thunderbolt
- Reflect
- "Signal Beam"
- "Iron Tail"

36 Electrode (IVs=31)@????????
- Rollout
- Thunder
- Explosion
- "Rain Dance"

38 Magneton (IVs=31)@"Sitrus Berry"
- Supersonic
- "Magnet Rise"
- Thunderbolt
- "Mirror Shot"

40 Manectric (IVs=31)@"Sitrus Berry"
- "Ice Fang"
- Charge
- Discharge
- Flamethrower

---------------------------------

39 Chinchou (IVs=31)@????????
- "Charge Beam"
- "Confuse Ray"
- "Water Pulse"
- "Icy Wind"

41 Flaaffy (IVs=31)@????????
- Thunderbolt
- "Power Gem"
- "Signal Beam"
- "Iron Tail"

41 Electrode (IVs=31)@????????
- Rollout
- Thunder
- Explosion
- "Rain Dance"

43 Magneton (IVs=31)@"Sitrus Berry"
- Lock-On
- "Magnet Rise"
- "Zap Cannon"
- "Mirror Shot"

45 Manectric (IVs=31)@"Sitrus Berry"
- "Ice Fang"
- Charge
- Discharge
- Flamethrower

---------------------------------

44 Lanturn (IVs=31)@????????
- "Charge Beam"
- Psybeam
- Brine
- "Ice Beam"

46 Electrode (IVs=31)@????????
- Rollout
- Thunder
- Explosion
- "Rain Dance"

46 Ampharos (IVs=31)@????????
- Thunderbolt
- "Power Gem"
- "Signal Beam"
- "Iron Tail"

48 Magneton (IVs=31)@"Sitrus Berry"
- Lock-On
- "Magnet Rise"
- "Zap Cannon"
- "Mirror Shot"

50 Manectric (IVs=31)@"Sitrus Berry"
- "Ice Fang"
- Charge
- Discharge
- Overheat

---------------------------------

52 Electabuzz (IVs=31)@????????
- "Ice Punch"
- "Cross Chop"
- Thunderpunch
- "Giga Impact"

52 Lanturn (IVs=31)@????????
- "Charge Beam"
- Psybeam
- "Hydro Pump"
- "Ice Beam"

54 Ampharos (IVs=31)@????????
- Thunderbolt
- "Power Gem"
- "Signal Beam"
- "Iron Tail"

54 Electrode (IVs=31)@????????
- Rollout
- Thunder
- Explosion
- "Rain Dance"

56 Magneton (IVs=31)@"Sitrus Berry"
- Lock-On
- "Magnet Rise"
- "Zap Cannon"
- "Mirror Shot"

58 Manectric (IVs=31)@"Sitrus Berry"
- "Ice Fang"
- Charge
- Thunder
- Overheat

+++++++++++++++++++++++++++++++++

Flannery

24 Numel (IVs=24)@????????
- Ember
- "Stealth Rock"
- Magnitude
- Amnesia

24 Slugma (IVs=24)@????????
- Heat Wave
- Ancientpower
- "Light Screen"
- "Sunny Day"

26 Camerupt (IVs=30)@????????
- "Lava Plume"
- "Mud Bomb"
- "Sunny Day"
- Solarbeam

29 Torkoal (IVs=30)@"White Herb"
- Overheat
- "Iron Defense"
- "Body Slam"
- "Iron Tail"

---------------------------------

36 Ponyta (IVs=31)@????????
- "Flame Wheel"
- "Sunny Day"
- Solarbeam
- "Morning Sun"

38 Magcargo (IVs=31)@"Sitrus Berry"
- Flamethrower
- Ancientpower
- "Light Screen"
- "Acid Armor"

38 Camerupt (IVs=31)@"Sitrus Berry"
- "Lava Plume"
- "Mud Bomb"
- "Flash Cannon"
- Attract

40 Torkoal (IVs=31)@"White Herb"
- Overheat
- "Iron Defense"
- "Hyper Beam"
- "Iron Tail"

---------------------------------

41 Growlithe (IVs=31)@????????
- Bite
- "Fire Fang"
- Reversal
- "Aerial Ace"

41 Ponyta (IVs=31)@????????
- "Flame Wheel"
- "Sunny Day"
- Solarbeam
- "Morning Sun"

43 Magcargo (IVs=31)@"Sitrus Berry"
- Flamethrower
- "Rock Slide"
- "Light Screen"
- "Acid Armor"

43 Camerupt (IVs=31)@"Sitrus Berry"
- Eruption
- "Earth Power"
- "Flash Cannon"
- Attract

45 Torkoal (IVs=31)@"White Herb"
- Overheat
- "Iron Defense"
- "Hyper Beam"
- "Iron Tail"

---------------------------------

46 Houndour (IVs=31)@????????
- "Nasty Plot"
- "Heat Wave"
- "Dark Pulse"
- "Sludge Bomb"

46 Growlithe (IVs=31)@Sitrus Berry
- Crunch
- "Flare Blitz"
- Reversal
- "Aerial Ace"

48 Magcargo (IVs=31)@"Sitrus Berry"
- "Fire Blast"
- "Rock Slide"
- "Light Screen"
- "Acid Armor"

46 Rapidash (IVs=31)@????????
- "Flame Wheel"
- Megahorn
- Bounce
- "Poison Jab"

48 Camerupt (IVs=31)@"Sitrus Berry"
- Eruption
- "Sunny Day"
- Solarbeam
- Attract

50 Torkoal (IVs=31)@"White Herb"
- Overheat
- Amnesia
- Yawn
- Earthquake

---------------------------------

52 Houndoom (IVs=31)@????????
- "Nasty Plot"
- "Heat Wave"
- "Dark Pulse"
- "Sludge Bomb"

54 Arcanine (IVs=31)@Sitrus Berry
- Crunch
- "Flare Blitz"
- "Thunder Fang"
- "Aerial Ace"

54 Magcargo (IVs=31)@"Sitrus Berry"
- "Fire Blast"
- "Rock Slide"
- "Light Screen"
- "Acid Armor"

56 Rapidash (IVs=31)@????????
- "Flame Wheel"
- Megahorn
- Bounce
- "Poison Jab"

56 Camerupt (IVs=31)@"Sitrus Berry"
- Eruption
- "Sunny Day"
- Solarbeam
- Attract

58 Torkoal (IVs=31)@"White Herb"
- Overheat
- Amnesia
- Yawn
- Fissure

+++++++++++++++++++++++++++++++++

Norman

27 Spinda (IVs=24)@????????
- "Teeter Dance"
- Psybeam
- "Dizzy Punch"
- Thrash

27 Vigoroth (IVs=24)@"Scope Lens"
- "Focus Energy"
- Slash
- "Brick Break"
- "Faint Attack"

29 Linoone (IVs=24)@"Chesto Berry"
- Rest
- "Belly Drum"
- Thief
- Headbutt

31 Slaking (IVs=30)@"Sitrus Berry"
- "Faint Attack"
- Yawn
- "Slack Off"
- "Giga Impact"

---------------------------------

42 Spinda (IVs=31)@????????
- Swagger
- "Psycho Cut"
- Thrash
- "Psych Up"

42 Stantler(IVs=31)@"Sitrus Berry"
- Extrasensory
- "Signal Beam"
- "Energy Ball"
- "Calm Mind"

42 Chansey (IVs=31)@"King's Rock"
- Softboiled
- Sing
- "Zen Headbutt"
- "Focus Punch"

45 Slaking (IVs=31)@"Sitrus Berry"
- "Giga Impact"
- "Slack Off"
- "Hammer Arm"
- "Ice Punch"

---------------------------------

47 Spinda (IVs=31)@????????
- Swagger
- "Psycho Cut"
- Thrash
- "Psych Up"

47 Stantler(IVs=31)@"Sitrus Berry"
- Extrasensory
- "Signal Beam"
- "Energy Ball"
- "Calm Mind"

45 Persian (IVs=31)@????????
- Bite
- "Aerial Ace"
- Attract
- "Double Team"

48 Chansey (IVs=31)@"King's Rock"
- Softboiled
- "Iron Tail"
- "Zen Headbutt"
- "Fire Punch"

50 Slaking (IVs=31)@"Sitrus Berry"
- "Giga Impact"
- "Slack Off"
- "Hammer Arm"
- "Ice Punch"

---------------------------------

53 Spinda (IVs=31)@????????
- Swagger
- "Psycho Cut"
- Thrash
- "Psych Up"

54 Stantler(IVs=31)@"Sitrus Berry"
- Extrasensory
- "Signal Beam"
- "Energy Ball"
- "Calm Mind"

54 Persian (IVs=31)@????????
- Bite
- "Aerial Ace"
- Attract
- "Double Team"

56 Blissey (IVs=31)@"King's Rock"
- Softboiled
- "Ice Punch"
- "Zen Headbutt"
- "Rock Slide"

56 Slaking (IVs=31)@"Sitrus Berry"
- "Giga Impact"
- "Slack Off"
- "Hammer Arm"
- Substitute

---------------------------------

57 Spinda (IVs=31)@????????
- Swagger
- "Psycho Cut"
- Thrash
- "Psych Up"

57 Stantler(IVs=31)@"Sitrus Berry"
- Psychic
- "Signal Beam"
- "Energy Ball"
- "Calm Mind"

57 Persian (IVs=31)@????????
- Bite
- "Aerial Ace"
- Attract
- "Double Team"

58 Blissey (IVs=31)@"King's Rock"
- Softboiled
- "Ice Punch"
- "Zen Headbutt"
- "Rock Slide"

58 Kangaskhan (IVs=31)@"Figy Berry"
- Outrage
- "Rock Slide"
- "Double Edge"
- "Hammer Arm"

60 Slaking (IVs=31)@"Sitrus Berry"
- "Giga Impact"
- "Slack Off"
- Dynamicpunch
- Substitute

+++++++++++++++++++++++++++++++++

Winona

29 Swablu (IVs=26)@????????
- Featherdance
- Tailwind
- Safeguard
- "Aerial Ace"

31 Skarmory (IVs=27)@????????
- Spikes
- "Swords Dance"
- "Steel Wing"
- "Aerial Ace"

31 Tropius (IVs=26)@"Sitrus Berry"
- "Sunny Day"
- "Aerial Ace"
- Solarbeam
- Synthesis

31 Pelipper (IVs=26)@????????
- "Water Pulse"
- "Ice Beam"
- Roost
- "Aerial Ace"

33 Altaria (IVs=31)@"Sitrus Berry"
- Earthquake
- "Dragon Claw"
- "Dragon Dance"
- "Aerial Ace"

---------------------------------

38 Dratini (IVs=31)@"Sitrus Berry"
- "Dragon Tail"
- "Dragon Dance"
- "Aqua Tail"
- "Ice Beam"

38 Tropius (IVs=31)@"Sitrus Berry"
- "Sunny Day"
- "Air Slash"
- Solarbeam
- Synthesis

41 Pelipper (IVs=31)@????????
- Surf
- Blizzard
- Roost
- "Air Cutter"

43 Skarmory (IVs=31)@????????
- Whirlwind
- Spikes
- "Brave Bird"
- "Steel Wing"

45 Altaria (IVs=31)@"Sitrus Berry"
- "Sky Attack"
- "Dragon Rush"
- "Dragon Dance"
- Earthquake

---------------------------------

43 Hoothoot (IVs=31)@????????
- Hypnosis
- "Silver Wind"
- Reflect
- "Dream Eater"

43 Tropius (IVs=31)@"Sitrus Berry"
- "Sunny Day"
- "Air Slash"
- Solarbeam
- Synthesis

45 Dragonair (IVs=31)@"Sitrus Berry"
- "Dragon Rush"
- "Dragon Dance"
- "Aqua Tail"
- Blizzard

46 Pelipper (IVs=31)@????????
- Surf
- Tailwind
- Roost
- "Air Cutter"

48 Skarmory (IVs=31)@????????
- Whirlwind
- Spikes
- "Brave Bird"
- "Steel Wing"

50 Altaria (IVs=31)@"Sitrus Berry"
- "Sky Attack"
- "Dragon Rush"
- "Dragon Dance"
- Earthquake

---------------------------------

48 Noctowl (IVs=31)@????????
- Hypnosis
- "Silver Wind"
- Nightmare
- "Dream Eater"

50 Skarmory (IVs=31)@????????
- Whirlwind
- Spikes
- "Brave Bird"
- "Steel Wing"

50 Tropius (IVs=31)@"Sitrus Berry"
- "Sunny Day"
- "Air Slash"
- Solarbeam
- Synthesis

50 Dragonair (IVs=31)@"Sitrus Berry"
- "Dragon Rush"
- "Dragon Dance"
- "Aqua Tail"
- Blizzard

51 Pelipper (IVs=31)@????????
- Surf
- Tailwind
- Roost
- "Air Cutter"

55 Altaria (IVs=31)@"Sitrus Berry"
- "Sky Attack"
- "Dragon Rush"
- "Dragon Dance"
- Earthquake

---------------------------------

53 Noctowl (IVs=31)@????????
- Hypnosis
- "Silver Wind"
- Nightmare
- "Dream Eater"

54 Skarmory (IVs=31)@????????
- Whirlwind
- Spikes
- "Brave Bird"
- "Steel Wing"

55 Tropius (IVs=31)@"Sitrus Berry"
- "Sunny Day"
- "Air Slash"
- Solarbeam
- Synthesis

55 Pelipper (IVs=31)@????????
- Surf
- Tailwind
- Roost
- "Air Cutter"

58 Dragonite (IVs=31)@"Sitrus Berry"
- "Dragon Rush"
- "Dragon Dance"
- "Fire Punch"
- "Ice Punch"

60 Altaria (IVs=31)@"Sitrus Berry"
- "Sky Attack"
- "Dragon Rush"
- "Dragon Dance"
- Earthquake

+++++++++++++++++++++++++++++++++

Tate & Liza

41 Claydol (IVs=30)@????????
- Earthquake
- "Signal Beam"
- Psychic
- "Light Screen"

41 Xatu (IVs=30)@????????
- Psychic
- "Psycho Shift"
- "Confuse Ray"
- "Drill Peck"

42 Lunatone (IVs=30)@"Sitrus Berry"
- "Light Screen"
- Psychic
- Hypnosis
- "Shadow Ball"

42 Solrock (IVs=30)@"Sitrus Berry"
- "Sunny Day"
- Solarbeam
- Psychic
- Flamethrower

---------------------------------

48 Slowpoke (IVs=31)@????????
- "Aqua Tail"
- "Zen Headbutt"
- Earthquake
- "Trick Room"

49 Claydol (IVs=31)@????????
- "Gyro Ball"
- "Rock Slide"
- "Signal Beam"
- Psychic

49 Xatu (IVs=31)@"Sitrus Berry"
- Psychic
- "Psycho Shift"
- "Confuse Ray"
- "Drill Peck"

50 Lunatone (IVs=31)@"Sitrus Berry"
- "Light Screen"
- "Ice Beam"
- "Rock Slide"
- Hypnosis

50 Solrock (IVs=31)@"Sitrus Berry"
- "Sunny Day"
- Solarbeam
- Psychic
- Flamethrower

---------------------------------

53 Slowpoke (IVs=31)@????????
- "Aqua Tail"
- "Zen Headbutt"
- Earthquake
- "Trick Room"

54 Claydol (IVs=31)@????????
- "Gyro Ball"
- "Rock Slide"
- "Signal Beam"
- Psychic

54 Xatu (IVs=31)@"Sitrus Berry"
- Psychic
- "Psycho Shift"
- "Confuse Ray"
- "Drill Peck"

55 Lunatone (IVs=31)@"Sitrus Berry"
- "Light Screen"
- "Ice Beam"
- "Rock Slide"
- Hypnosis

55 Solrock (IVs=31)@"Sitrus Berry"
- "Sunny Day"
- Solarbeam
- Psychic
- Flamethrower

55 Exeggutor (IVs=31)@"Sitrus Berry"
- "Giga Drain"
- "Dream Eater"
- Nightmare
- "Sleep Powder"

---------------------------------

58 Slowbro (IVs=31)@"King's Rock"
- Surf
- "Zen Headbutt"
- Earthquake
- "Trick Room"

59 Claydol (IVs=31)@????????
- "Gyro Ball"
- "Rock Slide"
- "Signal Beam"
- Psychic

59 Xatu (IVs=31)@"Sitrus Berry"
- Psychic
- "Psycho Shift"
- "Confuse Ray"
- "Drill Peck"

60 Lunatone (IVs=31)@"Sitrus Berry"
- "Light Screen"
- "Ice Beam"
- "Rock Slide"
- Hypnosis

60 Solrock (IVs=31)@"Sitrus Berry"
- "Sunny Day"
- Solarbeam
- Psychic
- Flamethrower

60 Exeggutor (IVs=31)@"Sitrus Berry"
- "Leaf Storm"
- "Dream Eater"
- Nightmare
- "Sleep Powder"

---------------------------------

64 Slowbro (IVs=31)@"King's Rock"
- Surf
- "Zen Headbutt"
- Earthquake
- "Trick Room"

64 Claydol (IVs=31)@????????
- "Gyro Ball"
- "Rock Slide"
- "Signal Beam"
- Psychic

64 Xatu (IVs=31)@"Sitrus Berry"
- "Shadow Ball"
- Twister
- "Heat Wave"
- "Sky Attack"

65 Lunatone (IVs=31)@"Sitrus Berry"
- "Light Screen"
- Blizzard
- "Rock Slide"
- Earthquake

65 Solrock (IVs=31)@"Sitrus Berry"
- "Sunny Day"
- Solarbeam
- Psychic
- Flamethrower

Exeggutor (IVs=31)@"Sitrus Berry"
- "Leaf Storm"
- "Dream Eater"
- Nightmare
- "Sleep Powder"

+++++++++++++++++++++++++++++++++

Juan

41 Remoraid (IVs=24)@????????
- "Water Pulse"
- "Aurora Beam"
- Attract
- "Charge Beam"

41 Whiscash (IVs=24)@????????
- "Zen Headbutt"
- "Aqua Tail"
- Amnesia
- Earthquake

43 Sealeo (IVs=24)@????????
- Hail
- "Body Slam"
- Blizzard
- "Water Pulse"

43 Crawdaunt (IVs=24)@????????
- "Swords Dance"
- Crabhammer
- "Night Slash"
- X-Scissor

46 Kingdra (IVs=30)@"Sitrus Berry"
- "Rain Dance"
- "Hydro Pump"
- "Ice Beam"
- "Dragon Pulse"

---------------------------------

46 Octillery (IVs=24)@"Scope Lens"
- Octazooka
- "Focus Energy"
- "Ice Beam"
- Flamethrower

46 Whiscash (IVs=24)@????????
- "Zen Headbutt"
- "Aqua Tail"
- Spark 
- Earthquake

48 Walrein (IVs=24)@????????
- Hail
- "Super Fang"
- Blizzard
- Surf

48 Crawdaunt (IVs=24)@????????
- "Swords Dance"
- Crabhammer
- "Night Slash"
- X-Scissor

51 Kingdra (IVs=30)@"Sitrus Berry"
- "Rain Dance"
- "Hydro Pump"
- "Ice Beam"
- "Dragon Pulse"

---------------------------------

50 Octillery (IVs=31)@"Scope Lens"
- Octazooka
- "Focus Energy"
- "Ice Beam"
- Flamethrower

51 Whiscash (IVs=31)@????????
- "Zen Headbutt"
- "Aqua Tail"
- Spark 
- Earthquake

53 Walrein (IVs=31)@????????
- Hail
- "Super Fang"
- Blizzard
- Surf

53 Crawdaunt (IVs=31)@????????
- "Swords Dance"
- Crabhammer
- "Night Slash"
- X-Scissor

56 Kingdra (IVs=31)@"Sitrus Berry"
- "Rain Dance"
- "Hydro Pump"
- "Ice Beam"
- "Dragon Pulse"

---------------------------------

56 Cloyster (IVs=31)@"King's Rock"
- "Icicle Spear"
- "Rock Blast"
- "Toxic Spikes"
- "Spike Cannon"

56 Octillery (IVs=31)@"Scope Lens"
- "Water Spout"
- "Focus Energy"
- "Signal Beam"
- Flamethrower

58 Whiscash (IVs=31)@????????
- "Zen Headbutt"
- "Aqua Tail"
- Spark 
- Earthquake

58 Walrein (IVs=31)@"Sitrus Berry"
- Hail
- "Super Fang"
- Blizzard
- Surf

58 Crawdaunt (IVs=31)@"Scope Lens"
- "Swords Dance"
- Crabhammer
- "Night Slash"
- X-Scissor

61 Kingdra (IVs=31)@"Sitrus Berry"
- "Rain Dance"
- "Hydro Pump"
- "Ice Beam"
- "Dragon Pulse"

---------------------------------

61 Cloyster (IVs=31)@"King's Rock"
- "Icicle Spear"
- "Rock Blast"
- "Toxic Spikes"
- "Spike Cannon"

63 Octillery (IVs=31)@"Scope Lens"
- "Water Spout"
- "Focus Energy"
- "Signal Beam"
- Flamethrower

63 Whiscash (IVs=31)@????????
- "Zen Headbutt"
- "Aqua Tail"
- Spark 
- Earthquake

63 Walrein (IVs=31)@"Sitrus Berry"
- Hail
- "Super Fang"
- Blizzard
- Surf

63 Crawdaunt (IVs=31)@"Scope Lens"
- "Swords Dance"
- Crabhammer
- "Night Slash"
- X-Scissor

66 Kingdra (IVs=31)@"Sitrus Berry"
- "Rain Dance"
- "Hydro Pump"
- "Ice Beam"
- "Dragon Pulse"