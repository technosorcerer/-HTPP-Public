This patch replaces the name and descriptions of all pokémons, moves, types, natures, trainers, items and abilities
with their variant in the French version of Pokémon Emerald.

What is not translated : menus, dialogs, as well as most things related to the contests and battle zone.

If you see any trainer with their name ending with "MIA", please tell me where you found them.
Don't hesitate to report any mistake or problem to do with the translation to me ! (@philenarion on discord)

-------------------------------------------------------------------------------------------------

Ce patch remplace les noms et descriptions des pokémons, attaques, types, natures, dresseurs, talents, objets et capacités
avec leur équivalent dans la version française de Pokémon Emeraude.

Ne sont pas traduits les menus, dialogues, ainsi que tout ce qui est lié aux concours et à la zone de combat.

Si vous voyez le nom d'un dresseur qui se finit par "MIA", dites moi où vous l'avez croisé s'il vous plaît.
N'hésitez pas à me rapportez les erreurs ou problèmes en lien avec la traduction ! (@philenarion sur discord)