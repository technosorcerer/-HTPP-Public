Thank you for downloading Pokemon Valiant Beta 1.0!

The demo is roughly 1-3 hours and ends at Route C.

Donations are welcome but not necessary
https://ko-fi.com/shachar700

If you want to leave feedback or bug reports here's the discord server:
https://discord.gg/wcEwv9bytW

Best regards,
Shahar