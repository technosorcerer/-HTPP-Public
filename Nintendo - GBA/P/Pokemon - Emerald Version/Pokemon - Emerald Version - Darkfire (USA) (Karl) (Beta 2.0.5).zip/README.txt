Thank you for downloading Pok�mon Darkfire Beta 2!

This demo has around 10-12 hours of gameplay and ends in Pinleaf Town.

Although we have done everything to squash bugs, some may still remain.

Join our Discord Server!

www.discord.io/darkfire

======================================================================================

How to patch your ROM:

	1. Get a Pok�mon Emerald ROM (1986 TrashMan Version)
	2. Apply the 'Pok�mon Darkfire Beta 2.0.5.ups' patch to your Pok�mon Emerald ROM using NUPS or another similar patcher
	3. Sit back & enjoy the world of Tenjo!

======================================================================================

How to use NUPS:

	1. Open NUPS
	2. Click 'Apply an UPS patch to a file'
	3. For 'File to patch', click browse and double click your 1986 TRASHMAN Pok�mon Emerald GBA ROM file
	4. For 'UPS patch', click browse and double click the 'Pok�mon Darkfire Beta 2.ups'
	5. Click 'Patch'

======================================================================================

If you need help patching or have questions please join us at: www.discord.io/darkfire

Have fun!

-Karl & Ray