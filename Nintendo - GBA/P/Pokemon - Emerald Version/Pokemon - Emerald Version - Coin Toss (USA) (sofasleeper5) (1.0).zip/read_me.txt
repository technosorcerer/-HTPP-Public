The ups patch file can be used on 
Pokemon - Emerald Version (USA, Europe).gba

Any ups patcher will work (if you google "UPS Patcher" you'll find plenty)


Changes:
- All pokemon only learn coin flip by level up
	Coin flip is a 50% accurate 1 hit ko move
	It's ko can't be negated, and accuracy can't be changed
	Pokémon using the move always have a 50% chance to move first
- All other moves have no effect
- Struggle was replaced with coin flip