Pokémon Slowpink Version
A ROM hack by jicem

Instructions for playing game:

Get a ROM of Pokémon Emerald (should end in .gba) and patch the ROM using any of the multitude of tools you can find online
I have a mirror of the most common patching tool at https://jicem.neocities.org/patcher/ for your convenience
Use the Emerald ROM file as your ROM file and slowpink.bps in this folder as your patch file if using the above tool
After you apply the patch, you should generate a new .gba file with (patched) at the end of the name or something similar
Use the new file anywhere that can play Gameboy Advance games

A non-exhaustive list of what's changed:

All of the base features of pokeemerald-expansion version 1.9.2 including PSS, fairy type, and current movesets are included
Most Pokémon in wild encounters and in trainer battles are replaced with Gen 1 Pokémon as well as baby forms, evolutions, and regional variants of those Pokémon introduced in future generations through Gen 7
New dark UI for the start menu, party screen, and bag
Reusable TMs
Following Pokémon
FRLG-style location previews
Gen 6-style Exp. Share that can be toggled on and off as a key item
Any Pokémon you're traveling with can use a field move as long as the HM for it is in your bag
Your Pokémon can forget HM moves without needing a move deleter for it
Items used for trade evolutions like King's Rock and Metal Coat can now be used as evolution stones from the bag, and the Linking Cord item from Legends: Arceus can be purchased to trigger any other trade evolutions
All evolution items (except Upgrade, which will be held by the Porygon you're given at the Weather Institute) can be purchased on the fourth floor of the Lilycove Department Store
You can switch between the mach bike and acro bike at any time by pressing R

And more!