Pokemon Altair and Pokemon Sirius English Patch - beta 1.2

HISTORY
2/20/2015 - Beta 1.2 - changed more Pokemon names
10/24/2014 - Beta 1.1 - changed a lot of Pokemon names
9/19/2014 - Beta 1.05 - fixed man in Fallarbor Pokemart
9/06/2014 - Beta 1.042 - fixed Pokenav registration text
9/04/2014 - Beta 1.041 - fixed Firis's name in text file, fixed switch move text
9/03/2014 - Beta 1.04 - fixed Liepus appearing in Sirius, fixed rt 117 encounter rate in Sirius
9/01/2014 - Beta 1.03 - fixed "Billy used Pokeball!" text, changed Icebolt Wave and Plasmox/Blitzune to fit with Vega
7/19/2014 - Beta 1.02 - fixed library haunted book text, fixed Gordon's name
7/17/2014 - Beta 1.01 - fixed Yunesis's Sirius Pokedex entry, fixed maid dialogue in Mosmero's Cafe
7/16/2014 - Beta 1.001 - fixed Torment and Grudge text
7/12/2014 - Beta 1.0

Patch to a JAPANESE Pokemon Emerald ROM.

Credits:
Text Hacking: Dr. Akimbo
Graphics Hacking: N/A
Translation: Dr. Akimbo
Pokemon Names: Dr. Akimbo, Asfia, Doesnt, LightningLord2, Hawkfire, SilverStrangequark, Toyotasomi no Miko, Z-nogyroP