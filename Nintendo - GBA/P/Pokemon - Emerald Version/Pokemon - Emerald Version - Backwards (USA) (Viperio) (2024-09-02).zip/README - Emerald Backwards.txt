Emerald - Backwards

- The player can select a starter Pokemon in the intro with Professor Birch.
- The player then spawns in the hall of fame with:
	- all fully evolved Pokemon available in Hoenn at lvl 58.
	- access to a move relearner.
	- a bag full of all items obtainable.
	- all 8 badges.
- The events of Emerald are re-ordered to force a backwards progression through the entire story.
- Pokemon lose exp instead of gaining it, making it so:
	- Pokemon level down instead of up.
	- Pokemon forget moves when they level down below the level where they would learn that move, with the option to use the move relearner screen to replace it with a move that would be available.
	- Pokemon de-evolve when they level down below their evolution level.
- Picking up items makes you lose them.
- After beating a gym leader, you lose the respective badge and all Pokemon, items, and TM / tutor moves that are normally only available after beating that gym.
- Various infinitely usable candies are added as key items:
	- Rarer candy: levels down a Pokemon by 1 level.
	- Level cap candy: levels down a Pokemon to the level of the next gym leader.
	- Exp candies: make Pokemon lose a specific amount of exp.