Emerald - Snake

You spawn in the "Pokémon Arcade" (a copy of the Mauville Game Corner) where a clerk lets you play Snake:

Mechanics:
- You spawn with 2 clones of the player behind you.
- The player keeps walking even without inputs.
- Interacting with the randomly spawned pokeballs adds a follower, adds a point, and moves the pokeball to a new random position.
- Getting to 20 and 40 points speeds up the game (not mentioned in the video).