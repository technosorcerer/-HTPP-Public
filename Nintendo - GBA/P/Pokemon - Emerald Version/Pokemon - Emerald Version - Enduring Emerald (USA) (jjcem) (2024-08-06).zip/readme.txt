POKéMON ENDURING EMERALD

Changes:

Kanto/Johto Pokémon replace Hoenn Pokémon in the wild and in trainer battles
Dex has 175 Pokémon in total that should all be catchable
Your starter Pokémon will be a Gen 1 starter instead of a Gen 3 starter
The Zigzagoon you save Professor Birch from has been replaced with a Nidoran
Available Poke Mart items depend on your badge count (meaning you can buy Poke Balls without fulfilling any story requirements)
Since there are early Pokémon that can poison you, poison no longer affects you in the overworld
Weather institute event modified to give you a Porygon2 instead of a Castform
You can run indoors
Any Pokémon can use a field move as long as the HM for it is in your bag
Exp. Share is now a key item that awards XP to all Pokémon in your party and can be toggled on or off
Your Pokémon get XP per catch
And more!

Note: This isn't meant to be a difficulty hack, but the bosses will be a little tougher to account for how much easier XP is to get now, with the first four gyms having Pokémon that are one level higher than before and the last four gyms, the Elite Four, and the champion having Pokémon that are two levels higher than before. Even with the buffs, you shouldn't encounter any Pokémon above level 60 before the postgame.