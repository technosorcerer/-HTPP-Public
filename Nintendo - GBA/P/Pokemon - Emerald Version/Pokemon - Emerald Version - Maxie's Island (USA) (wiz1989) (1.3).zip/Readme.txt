How to patch this file:

1) Get an unmodified ROM of Pokemon - Emerald Version (USA, Europe).
2) Go to the web patcher at https://www.marcrobledo.com/RomPatcher.js
3) Select the ROM file (.gba) and then the Patch file (.ups).
4) Apply the patch.
5) Play the game!

Enjoy!