# Pokeemerald-Expansion Changelogs

## 1.8.x
- ### [Version 1.8.1](docs/changelogs/1.8.1.md) - HOTFIX Release 🔥
- ### [Version 1.8.0](docs/changelogs/1.8.0.md) - Feature Release ✨

## 1.7.x
- ### [Version 1.7.4](docs/changelogs/1.7.4.md) - Bugfix Release 🧹
- ### [Version 1.7.3](docs/changelogs/1.7.3.md) - Bugfix Release 🧹
- ### [Version 1.7.2](docs/changelogs/1.7.2.md) - Bugfix Release 🧹
- ### [Version 1.7.1](docs/changelogs/1.7.1.md) - Bugfix Release 🧹
- ### [Version 1.7.0](docs/changelogs/1.7.0.md) - Feature Release ✨

## 1.6.x
- ### [Version 1.6.2](docs/changelogs/1.6.2.md) - Bugfix Release 🧹
- ### [Version 1.6.1](docs/changelogs/1.6.1.md) - HOTFIX Release 🔥
- ### [Version 1.6.0](docs/changelogs/1.6.0.md) - Feature Release ✨

## 1.5.x
- ### [Version 1.5.3](docs/changelogs/1.5.3.md) - HOTFIX Release 🔥
- ### [Version 1.5.2](docs/changelogs/1.5.2.md) - Bugfix Release 🧹
- ### [Version 1.5.1](docs/changelogs/1.5.1.md) - Bugfix Release 🧹
- ### [Version 1.5.0](docs/changelogs/1.5.0.md) - Feature Release ✨

## 1.4.x
- ### [Version 1.4.3](docs/changelogs/1.4.3.md) - Bugfix Release 🧹
- ### [Version 1.4.2](docs/changelogs/1.4.2.md) - Bugfix Release 🧹
- ### [Version 1.4.1](docs/changelogs/1.4.1.md) - HOTFIX Release 🔥
- ### [Version 1.4.0](docs/changelogs/1.4.0.md) - Feature Release ✨

## 1.3.x
- ### [Version 1.3.0](docs/changelogs/1.3.0.md) - Feature Release ✨

## 1.2.x
- ### [Version 1.2.0](docs/changelogs/1.2.0.md) - Feature Release ✨

## 1.1.x
- ### [Version 1.1.1](docs/changelogs/1.1.1.md) - Bugfix Release 🧹
- ### [Version 1.1.0](docs/changelogs/1.1.0.md) - Feature Release ✨

## 1.0.x
- ### [Version 1.0.0](docs/changelogs/1.0.0.md) - Feature Release ✨

## Pre-1.0.x:
- ### [Version 0.9.0](docs/changelogs/0.9.0.md) - Retroactive Version 🦕
