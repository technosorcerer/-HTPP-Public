See the thread at https://www.pokecommunity.com/threads/pok%C3%A9mon-tourmaline.527425/ for more information.

Message me (tdilos) there or on the discord if you have any questions, comments, or feedback.


**********USEFUL NOTES (READ BEFORE PLAYING)**********

CURRENT DEMO (v0.2.1 beta): Playable up to the sixth gym. The player won't be able to progress any further without the Surf HM.

KNOWN ISSUES: See the OP post in the pokecommunity thread for a list of these.

FAQ: Located in the OP post in the pokecommunity thread. Check there for information about difficulty modes, level caps, etc.

MECHANICS CHANGES: As mentioned in the pokecommunity thread, new moves/abilities have been added and a good number of old moves/abilities have been changed, too many to list here. Let me know if you have questions or if something doesn't seem to be working properly.

