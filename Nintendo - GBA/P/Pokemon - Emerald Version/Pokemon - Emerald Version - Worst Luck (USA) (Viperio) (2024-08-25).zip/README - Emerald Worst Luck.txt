Emerald - Worst Luck

Battle:
- When battle animations are off, EXP and EV gain is multiplied by 5 (only in wild battles).
- The player's moves never crit, the opponents' moves always crit.
- The player's moves always get the lowest damage roll (x0.85), the opponents' moves get the highest roll (x1.0).
- The player's move only hit if the calculated accuracy is 100 or more, and the opponents' moves always hit.
- Chance based effects such as secondary effects from moves (e.g. flinching), items (e.g. quick claw) or chance based abilities (e.g. flame body) only trigger for the player if the chance is 100% or more, and they always trigger for the opponents.
- All status conditions always have their negative effects for the player (full paralysis, self-hit confusion) and never for the opponent.
- All conditions with a random amount of turns always have the worst outcome for the player, and the best for the opponent (usually this means longest for player and the shortest for the opponent, e.g. for confusion, but for example for thrash, it is always 2 turns, since for the player it is the worst outcome because you get confused and always hit yourself, and the opponent is freed from being locked into thrash without any actual drawbacks).
- Multi-hit moves always land 2 when used by the player and 5 times when used by the opponent.
- Magnitude is always magnitude 4 when used by the player and magnitude 10 when used by the opponent.
- Present always heals the opponent's HP when used by the player and always deals the most damage when used by the opponent.
- Psywave always has a 0.5x modifier when used by the player and 1.5x when used by the opponent.
- Metronome always results in splash when used by the player.
- Protect never works twice in a row for the player and always works when used by the opponent.
- Spite reduces the opponent's PP by 2 when used by the player and by 5 when used by the opponent.
- Disobedience always causes the player's pokemon to hit itself in confusion.
- If the speed of the player's pokemon and the opponent's pokemon is equal, the opponent always goes first.
- If the player's pokemon has a lower speed than a wild pokemon, the player can never run.
- Catching pokemon is only successfull when the odds of catching it is exactly 100%.
- Every wild pokemon will be shiny until the player has beaten the petalburg woods aqua grunt, since catching anything before then is impossible.

Overworld:
- Chance based overworld effects never activate (e.g. pickup).
- Eggs never get generated in the daycare.
- The player will never receive match call froms the pokenav.
- Pokemon caught by the player have all their IVs set to 0.
- Wild pokemon will never have held items if the chance for that is not 100%.
- When possible, a wild encounter is triggered every 4 steps.
- Wild encounters up until the player has access to great balls are always shiny, after that it is impossible to find shiny pokemon.
- Fishing always results in no bite.




