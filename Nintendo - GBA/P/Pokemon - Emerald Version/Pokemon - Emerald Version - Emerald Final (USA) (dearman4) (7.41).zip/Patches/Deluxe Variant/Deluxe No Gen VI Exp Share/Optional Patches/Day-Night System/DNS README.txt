The Day-Night System (DNS) goes by the *system* time to show a color filter outside to make it feel like it is actually nighttime in the game. This does not alter the encounters like in Gen 2.

By default, this only applies when outside and not in battle. But by adding the 'Add DNS In Battle' option, this will also apply in battles.

By adding the 'Remove DNS' option, the DNS will be removed... Pretty self-explanatory :)