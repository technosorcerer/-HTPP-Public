These patches change the species of the free egg obtained in Lavaridge.

By default, the egg contains a Togepi (Vanilla is Wynaut). If you wish for the egg to contain a Tyrogue or Wynaut, simple apply the appropriate patch before talking to the NPC who gives the egg.

Togepi because it is only obtainable post game otherwise, Tyrogue so you can get a good Fighting type before the Normal gym.