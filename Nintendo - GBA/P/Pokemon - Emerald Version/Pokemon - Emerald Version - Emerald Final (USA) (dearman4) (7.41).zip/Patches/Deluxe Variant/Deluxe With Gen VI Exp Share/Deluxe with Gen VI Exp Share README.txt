Pick one of these three patches depending on which wild encounter list you want. Vanilla wilds... Has the Vanilla Wilds, Vanilla Wilds Plus includes version exclusives from Ruby/Sapphire. New Wilds has all 386 pokemon available. Do NOT patch more than one of these main patches to the same ROM. Do optional patches after.

Deluxe contains the Generation 4 additions like new moves, abilities, and evolutions.

This one has the Gen VI Exp Share, so by activating the Exp Share in your bag you can have the entire party receive Exp from battles. 