These make the pokemon have different appearances. The Gen4 Style Sprite Replacement makes the pokemon look like they do in Gen 4. The Moemon Sprite Replacement makes the pokemon look like anime characters. Big thanks to the Moémon Project for making those sprites! Their Discord is: https://discord.gg/Ds7bjJMumn

Also thanks to Axcellerator#5035 on Discord for assembling these for me <3

Use the included NUPS Patcher to patch these, as they expand the ROM.