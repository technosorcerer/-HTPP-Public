Thank you for downloading my hack! 
I recommend patching your vanilla Emerald ROM with the .ups file found with the download via this website: https://www.marcrobledo.com/RomPatcher.js/

Otherwise, that's it for v1 of the demo! The next version, v2, will be released sometime by the end of the year and I plan to add the next 3 gyms alongside the continued 
storyline, so do look forward to it! Also, any feedback and/or constructive criticism is highly encouraged, so let me know any thoughts and/or concerns :D

Thanks again!

-NinJack