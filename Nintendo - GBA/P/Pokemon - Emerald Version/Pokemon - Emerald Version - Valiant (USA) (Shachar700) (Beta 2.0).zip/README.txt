Thank you for downloading Pokemon Valiant Beta 2.0!

Apply the patch onto a clean Pokemon Emerald (Trashman), 
using a rom patcher.

Online patching tool: https://www.marcrobledo.com/RomPatcher.js/

The demo is roughly 3-5 hours,
has 3 gyms,
and ends at the end of Route D.

If you want to leave feedback or report bugs,
the best place for that will be the discord server:
https://discord.gg/wcEwv9bytW

Best regards,
Shahar