*** Pokemon Victory demo v0.1 ***

To play the game, first find yourself a Pokémon Emerald ROM file (CRC32: 1f1c08fb).
Then use an online ROM patcher to patch the .bps file you downloaded onto the Pokémon Emerald ROM file. I like using https://www.marcrobledo.com/RomPatcher.js/ , but any patcher will work.
Once you have your patched ROM file, run it using a GBA emulator. I strongly recommend mGBA, as that's what the game has been tested and developed with.

If you find any bugs or just want to let me know what you thought, don't hesitate to send a Discord DM to kfmx or an email to kfmxdev@gmail.com.


I hope you enjoy:)