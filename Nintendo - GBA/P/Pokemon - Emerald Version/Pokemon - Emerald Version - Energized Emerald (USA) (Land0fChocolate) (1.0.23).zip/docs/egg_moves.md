# Egg Moves Learnsets

BULBASAUR
            | SKULL BASH
            | CHARM
            | PETAL DANCE
            | MAGICAL LEAF
            | GRASS WHISTLE
            | CURSE
            | INGRAIN
            | NATURE POWER
            | AMNESIA
            | LEAF STORM
            | POWER WHIP
            | SLUDGE
            | ENDURE
            | GIGA DRAIN
            | GRASSY TERRAIN

CHARMANDER
            | BELLY DRUM
            | ANCIENT POWER
            | BITE
            | OUTRAGE
            | BEAT UP
            | DRAGON DANCE
            | CRUNCH
            | DRAGON RUSH
            | METAL CLAW
            | FLARE BLITZ
            | COUNTER
            | DRAGON PULSE
            | FOCUS PUNCH
            | AIR CUTTER

SQUIRTLE
            | MIRROR COAT
            | HAZE
            | MIST
            | FORESIGHT
            | FLAIL
            | REFRESH
            | MUD SPORT
            | YAWN
            | MUDDY WATER
            | FAKE OUT
            | AQUA RING
            | AQUA JET
            | WATER SPOUT
            | BRINE
            | DRAGON PULSE
            | AURA SPHERE

PIDGEY
            | PURSUIT
            | FEINT ATTACK
            | FORESIGHT
            | STEEL WING
            | AIR CUTTER
            | AIR SLASH
            | BRAVE BIRD
            | UPROAR
            | DEFOG

RATTATA
            | SCREECH
            | FLAME WHEEL
            | FURY SWIPES
            | BITE
            | COUNTER
            | REVERSAL
            | UPROAR
            | LAST RESORT
            | ME FIRST
            | REVENGE
            | FINAL GAMBIT

SPEAROW
            | FEINT ATTACK
            | SCARY FACE
            | QUICK ATTACK
            | TRI ATTACK
            | ASTONISH
            | SKY ATTACK
            | WHIRLWIND
            | UPROAR
            | FEATHER DANCE
            | STEEL WING
            | RAZOR WIND

EKANS
            | PURSUIT
            | SLAM
            | SPITE
            | BEAT UP
            | POISON FANG
            | SCARY FACE
            | POISON TAIL
            | DISABLE
            | SWITCHEROO
            | IRON TAIL
            | SUCKER PUNCH
            | SNATCH

SANDSHREW
            | FLAIL
            | COUNTER
            | RAPID SPIN
            | METAL CLAW
            | CRUSH CLAW
            | NIGHT SLASH
            | MUD SHOT
            | ENDURE
            | CHIP AWAY
            | ROCK CLIMB
            | ROTOTILLER
            | HONE CLAWS

NIDORAN F
            | SUPERSONIC
            | DISABLE
            | TAKE DOWN
            | FOCUS ENERGY
            | CHARM
            | COUNTER
            | BEAT UP
            | PURSUIT
            | SKULL BASH
            | IRON TAIL
            | POISON TAIL
            | ENDURE
            | CHIP AWAY
            | VENOM DRENCH

NIDORAN M
            | COUNTER
            | DISABLE
            | SUPERSONIC
            | TAKE DOWN
            | AMNESIA
            | CONFUSION
            | BEAT UP
            | SUCKER PUNCH
            | HEAD SMASH
            | IRON TAIL
            | POISON TAIL
            | ENDURE
            | CHIP AWAY
            | VENOM DRENCH

VULPIX
            | FEINT ATTACK
            | HYPNOSIS
            | FLAIL
            | SPITE
            | DISABLE
            | HOWL
            | HEAT WAVE
            | FLARE BLITZ
            | EXTRASENSORY
            | POWER SWAP
            | SECRET POWER
            | HEX
            | TAIL SLAP
            | CAPTIVATE

ZUBAT
            | QUICK ATTACK
            | PURSUIT
            | FEINT ATTACK
            | GUST
            | WHIRLWIND
            | CURSE
            | NASTY PLOT
            | HYPNOSIS
            | ZEN HEADBUTT
            | BRAVE BIRD
            | GIGA DRAIN
            | STEEL WING
            | DEFOG
            | VENOM DRENCH

ODDISH
            | RAZOR LEAF
            | FLAIL
            | SYNTHESIS
            | CHARM
            | INGRAIN
            | TICKLE
            | TEETER DANCE
            | SECRET POWER
            | NATURE POWER
            | AFTER YOU
            | STRENGTH SAP

PARAS
            | SCREECH
            | COUNTER
            | PSYBEAM
            | FLAIL
            | SWEET SCENT
            | PURSUIT
            | METAL CLAW
            | BUG BITE
            | CROSS POISON
            | AGILITY
            | ENDURE
            | NATURAL GIFT
            | LEECH SEED
            | WIDE GUARD
            | ROTOTILLER
            | FELL STINGER
            | GRASSY TERRAIN

VENONAT
            | BATON PASS
            | SCREECH
            | GIGA DRAIN
            | SIGNAL BEAM
            | AGILITY
            | MORNING SUN
            | TOXIC SPIKES
            | BUG BITE
            | SECRET POWER
            | SKILL SWAP
            | RAGE POWDER

DIGLETT
            | FEINT ATTACK
            | SCREECH
            | ANCIENT POWER
            | PURSUIT
            | BEAT UP
            | UPROAR
            | MUD BOMB
            | ASTONISH
            | REVERSAL
            | HEADBUTT
            | ENDURE
            | FINAL GAMBIT
            | MEMENTO

MEOWTH
            | SPITE
            | CHARM
            | HYPNOSIS
            | AMNESIA
            | ASSIST
            | ODOR SLEUTH
            | FLAIL
            | LAST RESORT
            | PUNISHMENT
            | TAIL WHIP
            | SNATCH
            | IRON TAIL
            | FOUL PLAY

PSYDUCK
            | HYPNOSIS
            | PSYBEAM
            | FORESIGHT
            | FUTURE SIGHT
            | CROSS CHOP
            | REFRESH
            | CONFUSE RAY
            | YAWN
            | MUD BOMB
            | ENCORE
            | SECRET POWER
            | SLEEP TALK
            | SYNCHRONOISE
            | SIMPLE BEAM
            | CLEAR SMOG

MANKEY
            | FORESIGHT
            | MEDITATE
            | COUNTER
            | REVERSAL
            | BEAT UP
            | REVENGE
            | SMELLING SALTS
            | CLOSE COMBAT
            | ENCORE
            | FOCUS PUNCH
            | SLEEP TALK
            | NIGHT SLASH
            | POWER TRIP

GROWLITHE
            | BODY SLAM
            | CRUNCH
            | THRASH
            | FIRE SPIN
            | HOWL
            | HEAT WAVE
            | DOUBLE EDGE
            | FLARE BLITZ
            | MORNING SUN
            | COVET
            | IRON TAIL
            | DOUBLE KICK
            | CLOSE COMBAT
            | BURN UP

POLIWAG
            | MIST
            | SPLASH
            | BUBBLE BEAM
            | HAZE
            | MIND READER
            | WATER SPORT
            | ICE BALL
            | MUD SHOT
            | REFRESH
            | ENDEAVOR
            | ENCORE
            | ENDURE
            | WATER PULSE

ABRA
            | ENCORE
            | BARRIER
            | KNOCK OFF
            | FIRE PUNCH
            | THUNDER PUNCH
            | ICE PUNCH
            | POWER TRICK
            | GUARD SWAP
            | SKILL SWAP
            | GUARD SPLIT
            | PSYCHO SHIFT
            | ALLY SWITCH
            | PSYCHIC TERRAIN

MACHOP
            | MEDITATE
            | ROLLING KICK
            | ENCORE
            | SMELLING SALTS
            | COUNTER
            | CLOSE COMBAT
            | FIRE PUNCH
            | THUNDER PUNCH
            | ICE PUNCH
            | BULLET PUNCH
            | POWER TRICK
            | HEAVY SLAM
            | KNOCK OFF
            | TICKLE
            | QUICK GUARD

BELLSPROUT
            | ENCORE
            | SYNTHESIS
            | LEECH LIFE
            | INGRAIN
            | MAGICAL LEAF
            | WORRY SEED
            | TICKLE
            | WEATHER BALL
            | BULLET SEED
            | NATURAL GIFT
            | GIGA DRAIN
            | CLEAR SMOG
            | POWER WHIP
            | ACID SPRAY
            | BELCH
            | STRENGTH SAP

TENTACOOL
            | AURORA BEAM
            | MIRROR COAT
            | RAPID SPIN
            | HAZE
            | CONFUSE RAY
            | KNOCK OFF
            | ACUPRESSURE
            | MUDDY WATER
            | BUBBLE
            | AQUA RING
            | TICKLE

GEODUDE
            | MEGA PUNCH
            | BLOCK
            | HAMMER ARM
            | FLAIL
            | CURSE
            | FOCUS PUNCH
            | ROCK CLIMB
            | ENDURE
            | AUTOTOMIZE
            | WIDE GUARD

PONYTA
            | FLAME WHEEL
            | THRASH
            | DOUBLE KICK
            | HYPNOSIS
            | CHARM
            | DOUBLE EDGE
            | HORN DRILL
            | MORNING SUN
            | LOW KICK
            | CAPTIVATE
            | ALLY SWITCH
            | HIGH HORSEPOWER

SLOWPOKE
            | BELLY DRUM
            | FUTURE SIGHT
            | STOMP
            | MUD SPORT
            | SLEEP TALK
            | SNORE
            | ME FIRST
            | BLOCK
            | ZEN HEADBUTT
            | WONDER ROOM
            | BELCH

FARFETCHD
            | STEEL WING
            | FORESIGHT
            | MIRROR MOVE
            | GUST
            | QUICK ATTACK
            | FLAIL
            | FEATHER DANCE
            | CURSE
            | COVET
            | MUD SLAP
            | NIGHT SLASH
            | LEAF BLADE
            | REVENGE
            | ROOST
            | TRUMP CARD
            | SIMPLE BEAM
            | FIRST IMPRESSION
            | FINAL GAMBIT

DODUO
            | QUICK ATTACK
            | SUPERSONIC
            | HAZE
            | FEINT ATTACK
            | FLAIL
            | ENDEAVOR
            | MIRROR MOVE
            | BRAVE BIRD
            | NATURAL GIFT
            | ASSURANCE

SEEL
            | LICK
            | PERISH SONG
            | DISABLE
            | HORN DRILL
            | SLAM
            | ENCORE
            | FAKE OUT
            | ICICLE SPEAR
            | SIGNAL BEAM
            | STOCKPILE
            | SWALLOW
            | SPIT UP
            | WATER PULSE
            | IRON TAIL
            | SLEEP TALK
            | BELCH
            | ENTRAINMENT

GRIMER
            | HAZE
            | MEAN LOOK
            | LICK
            | IMPRISON
            | CURSE
            | SHADOW PUNCH
            | SHADOW SNEAK
            | STOCKPILE
            | SWALLOW
            | SPIT UP
            | SCARY FACE
            | ACID SPRAY
            | POWER UP PUNCH

SHELLDER
            | BUBBLE BEAM
            | TAKE DOWN
            | BARRIER
            | RAPID SPIN
            | SCREECH
            | ICICLE SPEAR
            | MUD SHOT
            | ROCK BLAST
            | WATER PULSE
            | AQUA RING
            | AVALANCHE
            | TWINEEDLE

GASTLY
            | PSYWAVE
            | PERISH SONG
            | HAZE
            | ASTONISH
            | GRUDGE
            | FIRE PUNCH
            | ICE PUNCH
            | THUNDER PUNCH
            | DISABLE
            | SCARY FACE
            | CLEAR SMOG
            | SMOG
            | REFLECT TYPE

ONIX
            | FLAIL
            | BLOCK
            | DEFENSE CURL
            | ROLLOUT
            | ROCK BLAST
            | ROCK CLIMB
            | HEAVY SLAM
            | STEALTH ROCK
            | ROTOTILLER
            | WIDE GUARD

DROWZEE
            | BARRIER
            | ASSIST
            | ROLE PLAY
            | FIRE PUNCH
            | THUNDER PUNCH
            | ICE PUNCH
            | NASTY PLOT
            | FLATTER
            | PSYCHO CUT
            | GUARD SWAP
            | SECRET POWER
            | SKILL SWAP
            | POWER SPLIT
            | PSYCHIC TERRAIN

KRABBY
            | HAZE
            | AMNESIA
            | FLAIL
            | SLAM
            | KNOCK OFF
            | TICKLE
            | ANCIENT POWER
            | AGILITY
            | ENDURE
            | CHIP AWAY
            | BIDE
            | ALLY SWITCH

EXEGGCUTE
            | SYNTHESIS
            | MOONLIGHT
            | ANCIENT POWER
            | INGRAIN
            | CURSE
            | NATURE POWER
            | LUCKY CHANT
            | LEAF STORM
            | POWER SWAP
            | GIGA DRAIN
            | SKILL SWAP
            | NATURAL GIFT
            | BLOCK
            | GRASSY TERRAIN

CUBONE
            | ANCIENT POWER
            | BELLY DRUM
            | SCREECH
            | SKULL BASH
            | PERISH SONG
            | DOUBLE KICK
            | IRON HEAD
            | DETECT
            | ENDURE
            | CHIP AWAY
            | CURSE

LICKITUNG
            | BELLY DRUM
            | MAGNITUDE
            | BODY SLAM
            | CURSE
            | SMELLING SALTS
            | SLEEP TALK
            | SNORE
            | AMNESIA
            | HAMMER ARM
            | MUDDY WATER
            | ZEN HEADBUTT
            | BELCH
            | THRASH

KOFFING
            | SCREECH
            | PSYWAVE
            | PSYBEAM
            | DESTINY BOND
            | PAIN SPLIT
            | GRUDGE
            | SPITE
            | CURSE
            | STOCKPILE
            | SWALLOW
            | SPIT UP
            | TOXIC SPIKES
            | VENOM DRENCH

RHYHORN
            | CRUNCH
            | REVERSAL
            | COUNTER
            | MAGNITUDE
            | CURSE
            | CRUSH CLAW
            | DRAGON RUSH
            | ICE FANG
            | FIRE FANG
            | THUNDER FANG
            | SKULL BASH
            | IRON TAIL
            | ROCK CLIMB
            | ROTOTILLER
            | METAL BURST
            | GUARD SPLIT

CHANSEY
            | PRESENT
            | METRONOME
            | HEAL BELL
            | AROMATHERAPY
            | COUNTER
            | HELPING HAND
            | GRAVITY
            | LAST RESORT
            | MUD BOMB
            | NATURAL GIFT
            | ENDURE
            | SEISMIC TOSS

TANGELA
            | FLAIL
            | CONFUSION
            | MEGA DRAIN
            | AMNESIA
            | LEECH SEED
            | NATURE POWER
            | ENDEAVOR
            | LEAF STORM
            | POWER SWAP
            | GIGA DRAIN
            | RAGE POWDER
            | NATURAL GIFT
            | WAKE UP SLAP

KANGASKHAN
            | STOMP
            | FORESIGHT
            | FOCUS ENERGY
            | DISABLE
            | COUNTER
            | CRUSH CLAW
            | DOUBLE EDGE
            | ENDEAVOR
            | HAMMER ARM
            | FOCUS PUNCH
            | TRUMP CARD
            | UPROAR
            | CIRCLE THROW

HORSEA
            | FLAIL
            | AURORA BEAM
            | OCTAZOOKA
            | DISABLE
            | SPLASH
            | DRAGON RAGE
            | DRAGON BREATH
            | SIGNAL BEAM
            | RAZOR WIND
            | MUDDY WATER
            | WATER PULSE
            | CLEAR SMOG
            | OUTRAGE

GOLDEEN
            | PSYBEAM
            | HAZE
            | HYDRO PUMP
            | SLEEP TALK
            | MUD SPORT
            | MUD SLAP
            | AQUA TAIL
            | BODY SLAM
            | MUD SHOT
            | SKULL BASH
            | SIGNAL BEAM

MR MIME
            | FUTURE SIGHT
            | HYPNOSIS
            | MIMIC
            | FAKE OUT
            | TRICK
            | CONFUSE RAY
            | WAKE UP SLAP
            | TEETER DANCE
            | HEALING WISH
            | CHARM
            | NASTY PLOT
            | POWER SPLIT
            | MAGIC ROOM
            | ICY WIND
            | PSYCHIC TERRAIN

SCYTHER
            | COUNTER
            | BATON PASS
            | RAZOR WIND
            | REVERSAL
            | ENDURE
            | SILVER WIND
            | BUG BUZZ
            | NIGHT SLASH
            | DEFOG
            | STEEL WING
            | QUICK GUARD

PINSIR
            | FURY ATTACK
            | FLAIL
            | FEINT ATTACK
            | QUICK ATTACK
            | CLOSE COMBAT
            | FEINT
            | ME FIRST
            | BUG BITE
            | SUPERPOWER

LAPRAS
            | FORESIGHT
            | TICKLE
            | REFRESH
            | DRAGON DANCE
            | CURSE
            | SLEEP TALK
            | HORN DRILL
            | ANCIENT POWER
            | WHIRLPOOL
            | FISSURE
            | DRAGON PULSE
            | AVALANCHE
            | FUTURE SIGHT
            | FREEZE DRY

EEVEE
            | CHARM
            | FLAIL
            | ENDURE
            | CURSE
            | TICKLE
            | WISH
            | YAWN
            | FAKE TEARS
            | COVET
            | DETECT
            | NATURAL GIFT
            | STORED POWER
            | SYNCHRONOISE
            | CAPTIVATE

OMANYTE
            | BUBBLE BEAM
            | AURORA BEAM
            | SLAM
            | SUPERSONIC
            | HAZE
            | SPIKES
            | KNOCK OFF
            | WRING OUT
            | TOXIC SPIKES
            | MUDDY WATER
            | BIDE
            | WATER PULSE
            | WHIRLPOOL
            | REFLECT TYPE

KABUTO
            | BUBBLE BEAM
            | AURORA BEAM
            | RAPID SPIN
            | FLAIL
            | KNOCK OFF
            | CONFUSE RAY
            | MUD SHOT
            | ICY WIND
            | SCREECH
            | GIGA DRAIN
            | FORESIGHT
            | TAKE DOWN

AERODACTYL
            | WHIRLWIND
            | PURSUIT
            | FORESIGHT
            | STEEL WING
            | DRAGON BREATH
            | CURSE
            | ASSURANCE
            | ROOST
            | TAILWIND
            | WIDE GUARD

SNORLAX
            | LICK
            | CHARM
            | DOUBLE EDGE
            | CURSE
            | FISSURE
            | WHIRLWIND
            | PURSUIT
            | ZEN HEADBUTT
            | COUNTER
            | NATURAL GIFT
            | AFTER YOU
            | SELF DESTRUCT
            | BELCH
            | POWER UP PUNCH

DRATINI
            | MIST
            | HAZE
            | SUPERSONIC
            | DRAGON BREATH
            | DRAGON DANCE
            | DRAGON RUSH
            | EXTREME SPEED
            | WATER PULSE
            | AQUA JET
            | DRAGON PULSE
            | IRON TAIL

CHIKORITA
            | VINE WHIP
            | LEECH SEED
            | COUNTER
            | ANCIENT POWER
            | FLAIL
            | NATURE POWER
            | INGRAIN
            | GRASS WHISTLE
            | LEAF STORM
            | AROMATHERAPY
            | WRING OUT
            | BODY SLAM
            | REFRESH
            | HEAL PULSE
            | GRASSY TERRAIN

CYNDAQUIL
            | FURY SWIPES
            | QUICK ATTACK
            | REVERSAL
            | THRASH
            | FORESIGHT
            | COVET
            | HOWL
            | CRUSH CLAW
            | DOUBLE EDGE
            | DOUBLE KICK
            | FLARE BLITZ
            | EXTRASENSORY
            | NATURE POWER
            | FLAME BURST
            | DISCHARGE

TOTODILE
            | CRUNCH
            | THRASH
            | HYDRO PUMP
            | ANCIENT POWER
            | MUD SPORT
            | WATER SPORT
            | ICE PUNCH
            | METAL CLAW
            | DRAGON DANCE
            | AQUA JET
            | FAKE TEARS
            | BLOCK
            | WATER PULSE
            | FLATTER

SENTRET
            | DOUBLE EDGE
            | PURSUIT
            | SLASH
            | FOCUS ENERGY
            | REVERSAL
            | TRICK
            | ASSIST
            | LAST RESORT
            | CHARM
            | COVET
            | NATURAL GIFT
            | IRON TAIL
            | CAPTIVATE
            | BABY DOLL EYES

HOOTHOOT
            | MIRROR MOVE
            | SUPERSONIC
            | FEINT ATTACK
            | WING ATTACK
            | WHIRLWIND
            | SKY ATTACK
            | FEATHER DANCE
            | AGILITY
            | NIGHT SHADE
            | DEFOG
            | MEAN LOOK
            | HURRICANE

LEDYBA
            | PSYBEAM
            | BIDE
            | SILVER WIND
            | BUG BUZZ
            | SCREECH
            | ENCORE
            | KNOCK OFF
            | BUG BITE
            | FOCUS PUNCH
            | DRAIN PUNCH
            | DIZZY PUNCH
            | TAILWIND
            | ENDURE
            | COUNTER

SPINARAK
            | PSYBEAM
            | DISABLE
            | SONIC BOOM
            | BATON PASS
            | PURSUIT
            | SIGNAL BEAM
            | TOXIC SPIKES
            | TWINEEDLE
            | ELECTROWEB
            | RAGE POWDER
            | NIGHT SLASH
            | MEGAHORN
            | LUNGE

CHINCHOU
            | FLAIL
            | SCREECH
            | AMNESIA
            | PSYBEAM
            | WHIRLPOOL
            | AGILITY
            | MIST
            | SHOCK WAVE
            | BRINE
            | WATER PULSE
            | SOAK

PICHU
            | REVERSAL
            | BIDE
            | PRESENT
            | ENCORE
            | DOUBLE SLAP
            | WISH
            | CHARGE
            | FAKE OUT
            | THUNDER PUNCH
            | TICKLE
            | FLAIL
            | ENDURE
            | LUCKY CHANT
            | BESTOW
            | DISARMING VOICE
            | ELECTRIC TERRAIN

CLEFFA
            | PRESENT
            | METRONOME
            | AMNESIA
            | BELLY DRUM
            | SPLASH
            | MIMIC
            | WISH
            | FAKE TEARS
            | COVET
            | AROMATHERAPY
            | STORED POWER
            | TICKLE
            | MISTY TERRAIN
            | HEAL PULSE

IGGLYBUFF
            | PERISH SONG
            | PRESENT
            | FEINT ATTACK
            | WISH
            | FAKE TEARS
            | LAST RESORT
            | COVET
            | GRAVITY
            | SLEEP TALK
            | CAPTIVATE
            | PUNISHMENT
            | MISTY TERRAIN
            | HEAL PULSE

TOGEPI
            | PRESENT
            | MIRROR MOVE
            | PECK
            | FORESIGHT
            | FUTURE SIGHT
            | NASTY PLOT
            | PSYCHO SHIFT
            | LUCKY CHANT
            | EXTRASENSORY
            | SECRET POWER
            | STORED POWER
            | MORNING SUN

NATU
            | HAZE
            | DRILL PECK
            | QUICK ATTACK
            | FEINT ATTACK
            | STEEL WING
            | FEATHER DANCE
            | REFRESH
            | ZEN HEADBUTT
            | SUCKER PUNCH
            | SYNCHRONOISE
            | ROOST
            | SKILL SWAP
            | SIMPLE BEAM
            | ALLY SWITCH

MAREEP
            | TAKE DOWN
            | BODY SLAM
            | SCREECH
            | ODOR SLEUTH
            | CHARGE
            | FLATTER
            | SAND ATTACK
            | IRON TAIL
            | AFTER YOU
            | AGILITY
            | EERIE IMPULSE
            | ELECTRIC TERRAIN

MARILL
            | PRESENT
            | AMNESIA
            | FUTURE SIGHT
            | BELLY DRUM
            | PERISH SONG
            | SUPERSONIC
            | AQUA JET
            | SUPERPOWER
            | REFRESH
            | BODY SLAM
            | WATER SPORT
            | MUDDY WATER
            | CAMOUFLAGE

SUDOWOODO
            | SELF DESTRUCT
            | HEADBUTT
            | HARDEN
            | DEFENSE CURL
            | ROLLOUT
            | SAND TOMB
            | STEALTH ROCK
            | CURSE
            | ENDURE

HOPPIP
            | CONFUSION
            | ENCORE
            | DOUBLE EDGE
            | AMNESIA
            | HELPING HAND
            | AROMATHERAPY
            | WORRY SEED
            | COTTON GUARD
            | SEED BOMB
            | ENDURE
            | GRASSY TERRAIN
            | STRENGTH SAP

AIPOM
            | COUNTER
            | SCREECH
            | PURSUIT
            | AGILITY
            | SPITE
            | SLAM
            | DOUBLE SLAP
            | BEAT UP
            | FAKE OUT
            | COVET
            | BOUNCE
            | REVENGE
            | SWITCHEROO
            | QUICK GUARD
            | TAIL SLAP

SUNKERN
            | GRASS WHISTLE
            | ENCORE
            | LEECH SEED
            | NATURE POWER
            | CURSE
            | HELPING HAND
            | INGRAIN
            | SWEET SCENT
            | ENDURE
            | BIDE
            | NATURAL GIFT
            | MORNING SUN
            | GRASSY TERRAIN

YANMA
            | WHIRLWIND
            | REVERSAL
            | LEECH LIFE
            | SIGNAL BEAM
            | SILVER WIND
            | FEINT
            | FEINT ATTACK
            | PURSUIT
            | DOUBLE EDGE
            | SECRET POWER

WOOPER
            | BODY SLAM
            | ANCIENT POWER
            | CURSE
            | MUD SPORT
            | STOCKPILE
            | SWALLOW
            | SPIT UP
            | COUNTER
            | ENCORE
            | DOUBLE KICK
            | RECOVER
            | AFTER YOU
            | SLEEP TALK
            | ACID SPRAY
            | GUARD SWAP
            | EERIE IMPULSE
            | POWER UP PUNCH

MURKROW
            | WHIRLWIND
            | DRILL PECK
            | MIRROR MOVE
            | WING ATTACK
            | SKY ATTACK
            | CONFUSE RAY
            | FEATHER DANCE
            | PERISH SONG
            | PSYCHO SHIFT
            | SCREECH
            | FEINT ATTACK
            | BRAVE BIRD
            | ROOST
            | ASSURANCE
            | FLATTER
            | PUNISHMENT

MISDREAVUS
            | SCREECH
            | DESTINY BOND
            | IMPRISON
            | MEMENTO
            | SUCKER PUNCH
            | SHADOW SNEAK
            | CURSE
            | SPITE
            | OMINOUS WIND
            | NASTY PLOT
            | SKILL SWAP
            | WONDER ROOM
            | ME FIRST

GIRAFARIG
            | TAKE DOWN
            | AMNESIA
            | FORESIGHT
            | FUTURE SIGHT
            | BEAT UP
            | WISH
            | MAGIC COAT
            | DOUBLE KICK
            | MIRROR COAT
            | RAZOR WIND
            | SKILL SWAP
            | SECRET POWER
            | MEAN LOOK
            | PSYCHIC TERRAIN
            | PSYCHIC FANGS

PINECO
            | PIN MISSILE
            | FLAIL
            | SWIFT
            | COUNTER
            | SAND TOMB
            | REVENGE
            | DOUBLE EDGE
            | TOXIC SPIKES
            | POWER TRICK
            | ENDURE
            | STEALTH ROCK

DUNSPARCE
            | BIDE
            | ANCIENT POWER
            | BITE
            | HEADBUTT
            | ASTONISH
            | CURSE
            | TRUMP CARD
            | MAGIC COAT
            | SNORE
            | AGILITY
            | SECRET POWER
            | SLEEP TALK
            | HEX

GLIGAR
            | METAL CLAW
            | WING ATTACK
            | RAZOR WIND
            | COUNTER
            | SAND TOMB
            | AGILITY
            | BATON PASS
            | DOUBLE EDGE
            | FEINT
            | NIGHT SLASH
            | CROSS POISON
            | POWER TRICK
            | ROCK CLIMB
            | POISON TAIL

SNUBBULL
            | METRONOME
            | FEINT ATTACK
            | PRESENT
            | CRUNCH
            | HEAL BELL
            | SNORE
            | SMELLING SALTS
            | CLOSE COMBAT
            | ICE FANG
            | FIRE FANG
            | THUNDER FANG
            | FOCUS PUNCH
            | DOUBLE EDGE
            | MIMIC
            | FAKE TEARS

QWILFISH
            | FLAIL
            | HAZE
            | BUBBLE BEAM
            | SUPERSONIC
            | ASTONISH
            | SIGNAL BEAM
            | AQUA JET
            | WATER PULSE
            | BRINE
            | ACID SPRAY

SHUCKLE
            | SWEET SCENT
            | KNOCK OFF
            | HELPING HAND
            | ACUPRESSURE
            | SAND TOMB
            | MUD SLAP
            | ACID
            | ROCK BLAST
            | FINAL GAMBIT

HERACROSS
            | HARDEN
            | BIDE
            | FLAIL
            | REVENGE
            | PURSUIT
            | DOUBLE EDGE
            | SEISMIC TOSS
            | FOCUS PUNCH
            | MEGAHORN
            | ROCK BLAST

SNEASEL
            | COUNTER
            | SPITE
            | FORESIGHT
            | BITE
            | CRUSH CLAW
            | FAKE OUT
            | DOUBLE HIT
            | PUNISHMENT
            | PURSUIT
            | ICE SHARD
            | ICE PUNCH
            | ASSIST
            | AVALANCHE
            | FEINT
            | ICICLE CRASH
            | THROAT CHOP

TEDDIURSA
            | CRUNCH
            | TAKE DOWN
            | SEISMIC TOSS
            | COUNTER
            | METAL CLAW
            | FAKE TEARS
            | YAWN
            | SLEEP TALK
            | CROSS CHOP
            | DOUBLE EDGE
            | CLOSE COMBAT
            | NIGHT SLASH
            | BELLY DRUM
            | CHIP AWAY
            | PLAY ROUGH

SLUGMA
            | ACID ARMOR
            | HEAT WAVE
            | CURSE
            | SMOKESCREEN
            | MEMENTO
            | STOCKPILE
            | SPIT UP
            | SWALLOW
            | ROLLOUT
            | INFERNO
            | EARTH POWER
            | GUARD SWAP

SWINUB
            | TAKE DOWN
            | BITE
            | BODY SLAM
            | ANCIENT POWER
            | MUD SHOT
            | ICICLE SPEAR
            | DOUBLE EDGE
            | FISSURE
            | CURSE
            | MUD SHOT
            | AVALANCHE
            | STEALTH ROCK
            | ICICLE CRASH
            | ICE TUSK
            | FREEZE DRY

CORSOLA
            | SCREECH
            | MIST
            | AMNESIA
            | BARRIER
            | INGRAIN
            | CONFUSE RAY
            | ICICLE SPEAR
            | NATURE POWER
            | AQUA RING
            | CURSE
            | BIDE
            | WATER PULSE
            | HEAD SMASH
            | CAMOUFLAGE
            | LIQUIDATION

REMORAID
            | AURORA BEAM
            | OCTAZOOKA
            | SUPERSONIC
            | HAZE
            | SCREECH
            | ROCK BLAST
            | SNORE
            | FLAIL
            | WATER SPOUT
            | MUD SHOT
            | SWIFT
            | ACID SPRAY
            | WATER PULSE
            | ENTRAINMENT

DELIBIRD
            | AURORA BEAM
            | QUICK ATTACK
            | FUTURE SIGHT
            | SPLASH
            | RAPID SPIN
            | ICE BALL
            | ICE SHARD
            | ICE PUNCH
            | FAKE OUT
            | BESTOW
            | ICY WIND
            | FREEZE DRY
            | DESTINY BOND
            | SPIKES
            | COUNTER

MANTINE
            | TWISTER
            | HYDRO PUMP
            | HAZE
            | SLAM
            | MUD SPORT
            | MIRROR COAT
            | WATER SPORT
            | SPLASH
            | WIDE GUARD
            | AMNESIA

SKARMORY
            | DRILL PECK
            | PURSUIT
            | WHIRLWIND
            | SKY ATTACK
            | CURSE
            | BRAVE BIRD
            | ASSURANCE
            | GUARD SWAP
            | STEALTH ROCK
            | ENDURE

HOUNDOUR
            | FIRE SPIN
            | RAGE
            | PURSUIT
            | COUNTER
            | SPITE
            | REVERSAL
            | BEAT UP
            | FIRE FANG
            | THUNDER FANG
            | NASTY PLOT
            | PUNISHMENT
            | FEINT
            | SUCKER PUNCH
            | DESTINY BOND

PHANPY
            | FOCUS ENERGY
            | BODY SLAM
            | ANCIENT POWER
            | SNORE
            | COUNTER
            | FISSURE
            | ENDEAVOR
            | ICE SHARD
            | HEAD SMASH
            | MUD SLAP
            | HEAVY SLAM
            | PLAY ROUGH
            | HIGH HORSEPOWER

STANTLER
            | SPITE
            | DISABLE
            | BITE
            | EXTRASENSORY
            | THRASH
            | DOUBLE KICK
            | ZEN HEADBUTT
            | MEGAHORN
            | MUD SPORT
            | RAGE
            | ME FIRST

TYROGUE
            | RAPID SPIN
            | HIGH JUMP KICK
            | MACH PUNCH
            | MIND READER
            | HELPING HAND
            | COUNTER
            | VACUUM WAVE
            | BULLET PUNCH
            | ENDURE
            | PURSUIT
            | FEINT

SMOOCHUM
            | MEDITATE
            | FAKE OUT
            | WISH
            | ICE PUNCH
            | MIRACLE EYE
            | NASTY PLOT
            | WAKE UP SLAP
            | CAPTIVATE

ELEKID
            | KARATE CHOP
            | BARRIER
            | ROLLING KICK
            | MEDITATE
            | CROSS CHOP
            | FIRE PUNCH
            | ICE PUNCH
            | DYNAMIC PUNCH
            | FEINT
            | HAMMER ARM
            | FOCUS PUNCH

MAGBY
            | KARATE CHOP
            | MEGA PUNCH
            | BARRIER
            | SCREECH
            | CROSS CHOP
            | THUNDER PUNCH
            | MACH PUNCH
            | DYNAMIC PUNCH
            | FLARE BLITZ
            | BELLY DRUM
            | IRON TAIL
            | FOCUS ENERGY
            | POWER SWAP
            | BELCH

MILTANK
            | PRESENT
            | REVERSAL
            | SEISMIC TOSS
            | ENDURE
            | CURSE
            | HELPING HAND
            | SLEEP TALK
            | DIZZY PUNCH
            | HAMMER ARM
            | DOUBLE EDGE
            | PUNISHMENT
            | NATURAL GIFT
            | HEART STAMP
            | BELCH

LARVITAR
            | PURSUIT
            | STOMP
            | OUTRAGE
            | FOCUS ENERGY
            | ANCIENT POWER
            | DRAGON DANCE
            | CURSE
            | IRON DEFENSE
            | ASSURANCE
            | IRON HEAD
            | STEALTH ROCK
            | IRON TAIL

TREECKO
            | CRUNCH
            | MUD SPORT
            | ENDEAVOR
            | LEECH SEED
            | DRAGON BREATH
            | CRUSH CLAW
            | WORRY SEED
            | DOUBLE KICK
            | GRASS WHISTLE
            | SYNTHESIS
            | MAGICAL LEAF
            | LEAF STORM
            | RAZOR WIND
            | BULLET SEED
            | NATURAL GIFT
            | GRASSY TERRAIN

TORCHIC
            | COUNTER
            | REVERSAL
            | ENDURE
            | SMELLING SALTS
            | CRUSH CLAW
            | BATON PASS
            | AGILITY
            | NIGHT SLASH
            | LAST RESORT
            | FEINT
            | FEATHER DANCE
            | CURSE
            | FLAME BURST
            | LOW KICK

MUDKIP
            | REFRESH
            | UPROAR
            | CURSE
            | STOMP
            | ICE BALL
            | MIRROR COAT
            | COUNTER
            | ANCIENT POWER
            | WHIRLPOOL
            | BITE
            | DOUBLE EDGE
            | MUD BOMB
            | YAWN
            | SLUDGE
            | AVALANCHE
            | WIDE GUARD
            | BARRIER

POOCHYENA
            | ASTONISH
            | POISON FANG
            | COVET
            | LEER
            | YAWN
            | SUCKER PUNCH
            | ICE FANG
            | FIRE FANG
            | THUNDER FANG
            | ME FIRST
            | SNATCH
            | SLEEP TALK
            | PLAY ROUGH

ZIGZAGOON
            | CHARM
            | PURSUIT
            | TICKLE
            | TRICK
            | HELPING HAND
            | MUD SLAP
            | SLEEP TALK
            | ROCK CLIMB
            | SIMPLE BEAM
            | EXTREME SPEED

LOTAD
            | SYNTHESIS
            | RAZOR LEAF
            | SWEET SCENT
            | LEECH SEED
            | FLAIL
            | WATER GUN
            | TICKLE
            | COUNTER
            | GIGA DRAIN
            | TEETER DANCE

SEEDOT
            | LEECH SEED
            | AMNESIA
            | QUICK ATTACK
            | RAZOR WIND
            | TAKE DOWN
            | WORRY SEED
            | NASTY PLOT
            | POWER SWAP
            | DEFOG
            | FOUL PLAY
            | BEAT UP
            | BULLET SEED
            | GRASSY TERRAIN

TAILLOW
            | PURSUIT
            | SUPERSONIC
            | REFRESH
            | MIRROR MOVE
            | RAGE
            | SKY ATTACK
            | WHIRLWIND
            | BRAVE BIRD
            | ROOST
            | STEEL WING
            | DEFOG
            | BOOMBURST
            | HURRICANE

WINGULL
            | MIST
            | TWISTER
            | AGILITY
            | GUST
            | WATER SPORT
            | AQUA RING
            | KNOCK OFF
            | BRINE
            | ROOST
            | SOAK
            | WIDE GUARD

RALTS
            | DISABLE
            | MEAN LOOK
            | MEMENTO
            | DESTINY BOND
            | GRUDGE
            | SHADOW SNEAK
            | CONFUSE RAY
            | ENCORE
            | SYNCHRONOISE
            | SKILL SWAP
            | MISTY TERRAIN
            | ALLY SWITCH

SURSKIT
            | FORESIGHT
            | MUD SHOT
            | PSYBEAM
            | HYDRO PUMP
            | MIND READER
            | SIGNAL BEAM
            | BUG BITE
            | AQUA JET
            | ENDURE
            | FELL STINGER
            | POWER SPLIT
            | LUNGE

SHROOMISH
            | FAKE TEARS
            | CHARM
            | HELPING HAND
            | WORRY SEED
            | WAKE UP SLAP
            | SEED BOMB
            | BULLET SEED
            | FOCUS PUNCH
            | NATURAL GIFT
            | DRAIN PUNCH

SLAKOTH
            | PURSUIT
            | SLASH
            | BODY SLAM
            | SNORE
            | CRUSH CLAW
            | CURSE
            | SLEEP TALK
            | HAMMER ARM
            | NIGHT SLASH
            | AFTER YOU
            | TICKLE

NINCADA
            | ENDURE
            | FEINT ATTACK
            | GUST
            | SILVER WIND
            | BUG BUZZ
            | NIGHT SLASH
            | BUG BITE
            | FINAL GAMBIT

WHISMUR
            | TAKE DOWN
            | SNORE
            | EXTRASENSORY
            | SMELLING SALTS
            | SMOKESCREEN
            | ENDEAVOR
            | HAMMER ARM
            | FAKE TEARS
            | CIRCLE THROW
            | DISARMING VOICE
            | WHIRLWIND

MAKUHITA
            | FEINT ATTACK
            | DETECT
            | FORESIGHT
            | HELPING HAND
            | CROSS CHOP
            | REVENGE
            | DYNAMIC PUNCH
            | COUNTER
            | WAKE UP SLAP
            | BULLET PUNCH
            | FEINT
            | WIDE GUARD
            | FOCUS PUNCH
            | CHIP AWAY

AZURILL
            | ENCORE
            | SING
            | REFRESH
            | SLAM
            | TICKLE
            | FAKE TEARS
            | BODY SLAM
            | WATER SPORT
            | BELLY DRUM
            | SOAK
            | MUDDY WATER
            | COPYCAT
            | CAMOUFLAGE

NOSEPASS
            | MAGNITUDE
            | ROLLOUT
            | DOUBLE EDGE
            | BLOCK
            | STEALTH ROCK
            | ENDURE
            | WIDE GUARD

SKITTY
            | HELPING HAND
            | UPROAR
            | FAKE TEARS
            | WISH
            | BATON PASS
            | TICKLE
            | LAST RESORT
            | FAKE OUT
            | ZEN HEADBUTT
            | SUCKER PUNCH
            | MUD BOMB
            | SIMPLE BEAM
            | CAPTIVATE
            | COSMIC POWER

SABLEYE
            | RECOVER
            | MOONLIGHT
            | NASTY PLOT
            | FLATTER
            | FEINT
            | SUCKER PUNCH
            | TRICK
            | CAPTIVATE
            | MEAN LOOK
            | METAL BURST
            | IMPRISON

MAWILE
            | POISON FANG
            | ANCIENT POWER
            | TICKLE
            | SUCKER PUNCH
            | ICE FANG
            | FIRE FANG
            | THUNDER FANG
            | PUNISHMENT
            | GUARD SWAP
            | CAPTIVATE
            | SLAM
            | METAL BURST
            | MISTY TERRAIN
            | SEISMIC TOSS
            | POWER UP PUNCH

ARON
            | ENDEAVOR
            | BODY SLAM
            | STOMP
            | SMELLING SALTS
            | CURSE
            | SCREECH
            | IRON HEAD
            | DRAGON RUSH
            | HEAD SMASH
            | SUPERPOWER
            | STEALTH ROCK
            | REVERSAL

MEDITITE
            | FIRE PUNCH
            | THUNDER PUNCH
            | ICE PUNCH
            | FORESIGHT
            | FAKE OUT
            | BATON PASS
            | DYNAMIC PUNCH
            | POWER SWAP
            | GUARD SWAP
            | PSYCHO CUT
            | BULLET PUNCH
            | DRAIN PUNCH
            | SECRET POWER
            | QUICK GUARD

ELECTRIKE
            | CRUNCH
            | HEADBUTT
            | UPROAR
            | CURSE
            | SWIFT
            | DISCHARGE
            | ICE FANG
            | FIRE FANG
            | THUNDER FANG
            | SWITCHEROO
            | ELECTRO BALL
            | SHOCK WAVE
            | FLAME BURST
            | EERIE IMPULSE

PLUSLE
            | WISH
            | SING
            | SWEET KISS
            | DISCHARGE
            | LUCKY CHANT
            | CHARM
            | FAKE TEARS
            | TEARFUL LOOK

MINUN
            | WISH
            | SING
            | SWEET KISS
            | DISCHARGE
            | LUCKY CHANT
            | CHARM
            | FAKE TEARS
            | TEARFUL LOOK

VOLBEAT
            | BATON PASS
            | SILVER WIND
            | TRICK
            | ENCORE
            | BUG BUZZ
            | DIZZY PUNCH
            | SEISMIC TOSS
            | LUNGE

ILLUMISE
            | BATON PASS
            | SILVER WIND
            | GROWTH
            | ENCORE
            | BUG BUZZ
            | CAPTIVATE
            | FAKE TEARS
            | CONFUSE RAY
            | AROMATHERAPY

ROSELIA
            | SPIKES
            | SYNTHESIS
            | PIN MISSILE
            | COTTON SPORE
            | SLEEP POWDER
            | RAZOR LEAF
            | MIND READER
            | LEAF STORM
            | EXTRASENSORY
            | SEED BOMB
            | GIGA DRAIN
            | NATURAL GIFT
            | GRASS WHISTLE
            | BULLET SEED
            | POWER WHIP

GULPIN
            | ACID ARMOR
            | SMOG
            | PAIN SPLIT
            | CURSE
            | DESTINY BOND
            | MUD SLAP
            | GUNK SHOT
            | VENOM DRENCH

CARVANHA
            | HYDRO PUMP
            | DOUBLE EDGE
            | THRASH
            | ANCIENT POWER
            | SWIFT
            | BRINE
            | DESTINY BOND
            | PSYCHIC FANGS

WAILMER
            | DOUBLE EDGE
            | THRASH
            | SNORE
            | SLEEP TALK
            | CURSE
            | FISSURE
            | TICKLE
            | DEFENSE CURL
            | BODY SLAM
            | AQUA RING
            | SOAK
            | ZEN HEADBUTT
            | CLEAR SMOG

NUMEL
            | HOWL
            | SCARY FACE
            | BODY SLAM
            | ROLLOUT
            | DEFENSE CURL
            | STOMP
            | YAWN
            | ANCIENT POWER
            | MUD BOMB
            | HEAT WAVE
            | STOCKPILE
            | SWALLOW
            | SPIT UP
            | ENDURE
            | IRON HEAD
            | GROWTH
            | HEAVY SLAM

TORKOAL
            | ERUPTION
            | ENDURE
            | SLEEP TALK
            | YAWN
            | FISSURE
            | SKULL BASH
            | FLAME BURST
            | CLEAR SMOG
            | SUPERPOWER

SPOINK
            | FUTURE SIGHT
            | EXTRASENSORY
            | TRICK
            | ZEN HEADBUTT
            | AMNESIA
            | MIRROR COAT
            | SKILL SWAP
            | WHIRLWIND
            | LUCKY CHANT
            | ENDURE
            | SIMPLE BEAM

SPINDA
            | ENCORE
            | ASSIST
            | DISABLE
            | BATON PASS
            | WISH
            | TRICK
            | SMELLING SALTS
            | FAKE OUT
            | ROLE PLAY
            | PSYCHO CUT
            | FAKE TEARS
            | RAPID SPIN
            | ICY WIND
            | WATER PULSE
            | PSYCHO SHIFT
            | GUARD SPLIT
            | SPOTLIGHT

TRAPINCH
            | FOCUS ENERGY
            | QUICK ATTACK
            | GUST
            | FLAIL
            | FURY CUTTER
            | MUD SHOT
            | ENDURE
            | EARTH POWER
            | BUG BITE
            | SIGNAL BEAM

CACNEA
            | GRASS WHISTLE
            | ACID
            | TEETER DANCE
            | DYNAMIC PUNCH
            | COUNTER
            | LOW KICK
            | SMELLING SALTS
            | MAGICAL LEAF
            | SEED BOMB
            | NASTY PLOT
            | DISABLE
            | BLOCK
            | WORRY SEED
            | SWITCHEROO
            | FELL STINGER
            | BELCH
            | ROTOTILLER
            | POWER UP PUNCH

SWABLU
            | AGILITY
            | HAZE
            | PURSUIT
            | RAGE
            | FEATHER DANCE
            | DRAGON RUSH
            | POWER SWAP
            | ROOST
            | HYPER VOICE
            | STEEL WING
            | PLAY ROUGH

ZANGOOSE
            | FLAIL
            | DOUBLE KICK
            | RAZOR WIND
            | COUNTER
            | CURSE
            | FURY SWIPES
            | NIGHT SLASH
            | METAL CLAW
            | DOUBLE HIT
            | DISABLE
            | IRON TAIL
            | FINAL GAMBIT
            | FEINT
            | QUICK GUARD
            | BELLY DRUM

SEVIPER
            | STOCKPILE
            | SWALLOW
            | SPIT UP
            | BODY SLAM
            | SCARY FACE
            | ASSURANCE
            | NIGHT SLASH
            | SWITCHEROO
            | IRON TAIL
            | WRING OUT
            | PUNISHMENT
            | FINAL GAMBIT

BARBOACH
            | THRASH
            | WHIRLPOOL
            | SPARK
            | HYDRO PUMP
            | FLAIL
            | TAKE DOWN
            | DRAGON DANCE
            | EARTH POWER
            | MUD SHOT
            | MUDDY WATER

CORPHISH
            | MUD SPORT
            | ENDEAVOR
            | BODY SLAM
            | ANCIENT POWER
            | KNOCK OFF
            | SUPERPOWER
            | METAL CLAW
            | DRAGON DANCE
            | TRUMP CARD
            | CHIP AWAY
            | DOUBLE EDGE
            | AQUA JET
            | SWITCHEROO

LILEEP
            | BARRIER
            | RECOVER
            | MIRROR COAT
            | WRING OUT
            | TICKLE
            | CURSE
            | MEGA DRAIN
            | ENDURE
            | STEALTH ROCK

ANORITH
            | RAPID SPIN
            | KNOCK OFF
            | SCREECH
            | SAND ATTACK
            | CROSS POISON
            | CURSE
            | IRON DEFENSE
            | WATER PULSE
            | AQUA JET

FEEBAS
            | MIRROR COAT
            | DRAGON BREATH
            | MUD SPORT
            | HYPNOSIS
            | CONFUSE RAY
            | MIST
            | HAZE
            | TICKLE
            | BRINE
            | IRON TAIL
            | DRAGON PULSE
            | CAPTIVATE

CASTFORM
            | FUTURE SIGHT
            | LUCKY CHANT
            | DISABLE
            | AMNESIA
            | OMINOUS WIND
            | HEX
            | CLEAR SMOG
            | REFLECT TYPE
            | GUARD SWAP
            | COSMIC POWER

KECLEON
            | DISABLE
            | MAGIC COAT
            | TRICK
            | FAKE OUT
            | NASTY PLOT
            | DIZZY PUNCH
            | RECOVER
            | SKILL SWAP
            | SNATCH
            | FOUL PLAY
            | CAMOUFLAGE
            | POWER UP PUNCH

SHUPPET
            | DISABLE
            | DESTINY BOND
            | FORESIGHT
            | ASTONISH
            | IMPRISON
            | PURSUIT
            | SHADOW SNEAK
            | CONFUSE RAY
            | OMINOUS WIND
            | GUNK SHOT
            | PHANTOM FORCE

DUSKULL
            | IMPRISON
            | DESTINY BOND
            | PAIN SPLIT
            | GRUDGE
            | MEMENTO
            | FEINT ATTACK
            | OMINOUS WIND
            | DARK PULSE
            | SKILL SWAP
            | HAZE

TROPIUS
            | HEADBUTT
            | SLAM
            | RAZOR WIND
            | LEECH SEED
            | NATURE POWER
            | LEAF STORM
            | SYNTHESIS
            | CURSE
            | LEAF BLADE
            | DRAGON DANCE
            | BULLET SEED
            | NATURAL GIFT
            | DRAGON HAMMER

CHIMECHO
            | DISABLE
            | CURSE
            | HYPNOSIS
            | WISH
            | FUTURE SIGHT
            | RECOVER
            | STORED POWER
            | SKILL SWAP
            | COSMIC POWER
            | CRAFTY SHIELD
            | PERISH SONG

ABSOL
            | BATON PASS
            | FEINT ATTACK
            | DOUBLE EDGE
            | MAGIC COAT
            | CURSE
            | MEAN LOOK
            | ZEN HEADBUTT
            | PUNISHMENT
            | SUCKER PUNCH
            | ASSURANCE
            | ME FIRST
            | MEGAHORN
            | HEX
            | PERISH SONG
            | PLAY ROUGH

SNORUNT
            | BLOCK
            | SPIKES
            | ROLLOUT
            | DISABLE
            | BIDE
            | WEATHER BALL
            | AVALANCHE
            | HEX
            | FAKE TEARS
            | SWITCHEROO

SPHEAL
            | WATER SPORT
            | STOCKPILE
            | SWALLOW
            | SPIT UP
            | YAWN
            | CURSE
            | FISSURE
            | SIGNAL BEAM
            | AQUA RING
            | ROLLOUT
            | SLEEP TALK
            | WATER PULSE
            | BELLY DRUM

CLAMPERL
            | REFRESH
            | MUD SPORT
            | BODY SLAM
            | SUPERSONIC
            | BARRIER
            | CONFUSE RAY
            | AQUA RING
            | MUDDY WATER
            | WATER PULSE
            | BRINE
            | ENDURE

RELICANTH
            | MAGNITUDE
            | SKULL BASH
            | WATER SPORT
            | AMNESIA
            | SLEEP TALK
            | AQUA TAIL
            | SNORE
            | MUD SLAP
            | MUDDY WATER
            | MUD SHOT
            | BRINE
            | ZEN HEADBUTT

LUVDISC
            | SPLASH
            | SUPERSONIC
            | WATER SPORT
            | MUD SPORT
            | CAPTIVATE
            | AQUA RING
            | AQUA JET
            | HEAL PULSE
            | BRINE
            | ENTRAINMENT

BAGON
            | HYDRO PUMP
            | THRASH
            | DRAGON RAGE
            | TWISTER
            | DRAGON DANCE
            | FIRE FANG
            | DRAGON RUSH
            | DRAGON PULSE
            | ENDURE
            | DEFENSE CURL

BUDEW
            | SPIKES
            | SYNTHESIS
            | PIN MISSILE
            | COTTON SPORE
            | SLEEP POWDER
            | RAZOR LEAF
            | MIND READER
            | LEAF STORM
            | EXTRASENSORY
            | SEED BOMB
            | GIGA DRAIN
            | NATURAL GIFT
            | GRASS WHISTLE
            | BULLET SEED
            | POWER WHIP

CHINGLING
            | DISABLE
            | CURSE
            | HYPNOSIS
            | WISH
            | FUTURE SIGHT
            | RECOVER
            | STORED POWER
            | SKILL SWAP
            | COSMIC POWER

RATTATA ALOLAN
        MOVE COUNTER
        MOVE FINAL GAMBIT
        MOVE FURY SWIPES
        MOVE ME FIRST
        MOVE REVENGE
        MOVE REVERSAL
        MOVE SNATCH
        MOVE STOCKPILE
        MOVE SWALLOW
        MOVE SWITCHEROO
        MOVE UPROAR

SANDSHREW ALOLAN
        MOVE AMNESIA
        MOVE CHIP AWAY
        MOVE COUNTER
        MOVE CRUSH CLAW
        MOVE CURSE
        MOVE ENDURE
        MOVE FLAIL
        MOVE HONE CLAWS
        MOVE ICICLE CRASH
        MOVE ICICLE SPEAR
        MOVE METAL CLAW
        MOVE NIGHT SLASH

VULPIX ALOLAN
        MOVE AGILITY
        MOVE CHARM
        MOVE DISABLE
        MOVE ENCORE
        MOVE EXTRASENSORY
        MOVE FLAIL
        MOVE FREEZE DRY
        MOVE HOWL
        MOVE HYPNOSIS
        MOVE MOONBLAST
        MOVE POWER SWAP
        MOVE SPITE
        MOVE SECRET POWER
        MOVE TAIL SLAP

DIGLETT ALOLAN
        MOVE ANCIENT POWER
        MOVE BEAT UP
        MOVE ENDURE
        MOVE FEINT ATTACK
        MOVE FINAL GAMBIT
        MOVE HEADBUTT
        MOVE MEMENTO
        MOVE METAL SOUND
        MOVE PURSUIT
        MOVE REVERSAL
        MOVE THRASH

MEOWTH ALOLAN
        MOVE AMNESIA
        MOVE ASSIST
        MOVE CHARM
        MOVE COVET
        MOVE FLAIL
        MOVE FLATTER
        MOVE FOUL PLAY
        MOVE HYPNOSIS
        MOVE PARTING SHOT
        MOVE PUNISHMENT
        MOVE SNATCH
        MOVE SPITE

GEODUDE ALOLAN
        MOVE AUTOTOMIZE
        MOVE BLOCK
        MOVE COUNTER
        MOVE CURSE
        MOVE ENDURE
        MOVE FLAIL
        MOVE MAGNET RISE
        MOVE ROCK CLIMB
        MOVE SCREECH
        MOVE WIDE GUARD

GRIMER ALOLAN
        MOVE ASSURANCE
        MOVE CLEAR SMOG
        MOVE CURSE
        MOVE IMPRISON
        MOVE MEAN LOOK
        MOVE POWER UP PUNCH
        MOVE PURSUIT
        MOVE SCARY FACE
        MOVE SHADOW SNEAK
        MOVE SPITE
        MOVE SPIT UP
        MOVE STOCKPILE
        MOVE SWALLOW

egg moves(PONYTA GALARIAN
        MOVE THRASH
        MOVE DOUBLE KICK
        MOVE HYPNOSIS
        MOVE DOUBLE EDGE
        MOVE HORN DRILL
        MOVE MORNING SUN

SLOWPOKE GALARIAN
        MOVE BELCH
        MOVE BELLY DRUM
        MOVE BLOCK
        MOVE STOMP

GROWLITHE HISUIAN
        MOVE BODY SLAM
        MOVE CRUNCH
        MOVE THRASH
        MOVE FIRE SPIN
        MOVE HOWL
        MOVE HEAT WAVE
        MOVE DOUBLE EDGE
        MOVE FLARE BLITZ
        MOVE MORNING SUN
        MOVE COVET
        MOVE IRON TAIL
        MOVE DOUBLE KICK
        MOVE CLOSE COMBAT
        MOVE BURN UP
