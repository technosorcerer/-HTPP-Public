# Tutor Move List and locations

-Swords Dance - Battle Frontier
-Body Slam - Battle Frontier
-Double Edge - Sootopolis City
-Counter - Battle Frontier
-Seismic Toss - Battle Frontier
-Mimic - Lavaridge Town
-Metronome - Fallarbor Town
-Soft Boiled - Battle Frontier
-Dream Eater - Battle Frontier
-Gastro Acid - Battle Frontier
-Explosion - Pacifidlog Town
-Psychic Fangs - Battle Frontier
-Substitute - Lilycove City
-Dynamic Punch - Mossdeep City
-Rollout - Mauville City
-Psych Up - Battle Frontier
-Snore - Battle Frontier
-Icy Wind - Battle Frontier
-Endure - Battle Frontier
-Earth Power - Battle Frontier
-Ice Punch - Battle Frontier
-Swagger - Slateport City
-Sleep Talk - Fortree City
-Swift - Battle Frontier
-Defense Curl - Battle Frontier
-Thunder Punch - Battle Frontier
-Fire Punch - Battle Frontier
-Fury Cutter - Verdanturf Town
-Serpent Dance - Battle Frontier
-Flint Blade - Battle Frontier
-Blaze Impact - Battle Frontier
-Work Up - Battle Frontier
-Low Sweep - Battle Frontier
-Avalanche - Battle Frontier
-Signal Beam - Battle Frontier
-Nasty Plot - Battle Frontier
-Superpower - Battle Frontier
-Play Rough - Battle Frontier
-Stored Power - Battle Frontier
-Role Play - Battle Frontier
-Defog - Battle Frontier
-Trick - Battle Frontier
-Knock Off - Battle Frontier
-Stealth Rock - Battle Frontier
-Tailwind - Battle Frontier
-Breaking Swipe - Battle Frontier
-Heat Wave - Battle Frontier
-Gunk Shot - Battle Frontier
-Zen Headbutt - Battle Frontier
-Body Press - Battle Frontier
-Worry Seed - Battle Frontier
-Recycle - Battle Frontier
-Low Kick - Battle Frontier
-Magic Coat - Battle Frontier
-Pain Split - Battle Frontier
-Seed Bomb - Battle Frontier
-Iron Head - Battle Frontier
-Aqua Tail - Battle Frontier
-Foul Play - Battle Frontier
-Megahorn - Battle Frontier
-Draco Meteor - Ever Grande City
-Hidden Thorns - Battle Frontier
-Bug Bite - Battle Frontier

# Tutor Move Learnsets

    BULBASAUR   	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | WORK UP
                    | KNOCK OFF
                    | WORRY SEED
                    | SEED BOMB
                    | HIDDEN THORNS

    IVYSAUR     	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | WORK UP
                    | KNOCK OFF
                    | WORRY SEED
                    | SEED BOMB
                    | HIDDEN THORNS

    VENUSAUR    	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | EARTH POWER
                    | WORK UP
                    | KNOCK OFF
                    | WORRY SEED
                    | SEED BOMB
                    | HIDDEN THORNS

    CHARMANDER  	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | FURY CUTTER
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | THUNDER PUNCH
                    | BLAZE IMPACT
                    | WORK UP
                    | HEAT WAVE

    CHARMELEON  	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | FURY CUTTER
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | THUNDER PUNCH
                    | BLAZE IMPACT
                    | WORK UP
                    | HEAT WAVE

    CHARIZARD   	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | FURY CUTTER
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | THUNDER PUNCH
                    | BLAZE IMPACT
                    | WORK UP
                    | BREAKING SWIPE
                    | DEFOG
                    | TAILWIND
                    | HEAT WAVE

    SQUIRTLE    	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | WORK UP
                    | ZEN HEADBUTT
                    | AQUA TAIL

    WARTORTLE   	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | WORK UP
                    | ZEN HEADBUTT
                    | AQUA TAIL

    BLASTOISE   	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | WORK UP
                    | AVALANCHE
                    | SIGNAL BEAM
                    | ZEN HEADBUTT
                    | BODY PRESS
                    | AQUA TAIL

    CATERPIE    	| SNORE
                    | BUG BITE

    METAPOD     	| BUG BITE

    BUTTERFREE  	| DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SIGNAL BEAM
                    | DEFOG
                    | TAILWIND
                    | BUG BITE

    WEEDLE      	| BUG BITE

    KAKUNA      	| BUG BITE

    BEEDRILL    	| DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | DEFOG
                    | KNOCK OFF
                    | TAILWIND
                    | BUG BITE

    PIDGEY      	| DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | WORK UP
                    | DEFOG
                    | TAILWIND
                    | HEAT WAVE

    PIDGEOTTO   	| DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | WORK UP
                    | DEFOG
                    | TAILWIND
                    | HEAT WAVE

    PIDGEOT     	| DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | WORK UP
                    | DEFOG
                    | TAILWIND
                    | HEAT WAVE

    RATTATA     	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | ZEN HEADBUTT
                    | SWIFT
                    | WORK UP

    RATICATE    	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | ZEN HEADBUTT
                    | SWIFT
                    | SWORDS DANCE
                    | WORK UP
                    | KNOCK OFF

    SPEAROW     	| DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | WORK UP
                    | DEFOG
                    | TAILWIND
                    | HEAT WAVE

    FEAROW      	| DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | WORK UP
                    | DEFOG
                    | TAILWIND
                    | HEAT WAVE

    EKANS       	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SERPENT DANCE
                    | GASTRO ACID
                    | BREAKING SWIPE
                    | AQUA TAIL

    ARBOK       	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SERPENT DANCE
                    | GASTRO ACID
                    | BREAKING SWIPE
                    | AQUA TAIL

    PIKACHU     	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | MIMIC
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | THUNDER PUNCH
                    | SIGNAL BEAM
                    | NASTY PLOT
                    | PLAY ROUGH
                    | KNOCK OFF

    RAICHU      	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | MIMIC
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | THUNDER PUNCH
                    | SIGNAL BEAM
                    | NASTY PLOT
                    | PLAY ROUGH
                    | KNOCK OFF

    SANDSHREW   	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FURY CUTTER
                    | MIMIC
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | EARTH POWER
                    | WORK UP
                    | KNOCK OFF
                    | STEALTH ROCK

    SANDSLASH   	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FURY CUTTER
                    | MIMIC
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | EARTH POWER
                    | WORK UP
                    | KNOCK OFF
                    | STEALTH ROCK

    NIDORAN F   	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | EARTH POWER

    NIDORINA    	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | EARTH POWER

    NIDOQUEEN   	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | FURY CUTTER
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | EARTH POWER
                    | AVALANCHE
                    | SUPERPOWER
                    | STEALTH ROCK
                    | BODY PRESS
                    | AQUA TAIL

    NIDORAN M   	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | EARTH POWER

    NIDORINO    	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | EARTH POWER

    NIDOKING    	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | FURY CUTTER
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | EARTH POWER
                    | AVALANCHE
                    | SUPERPOWER
                    | STEALTH ROCK
                    | BODY PRESS
                    | AQUA TAIL
                    | MEGAHORN

    CLEFAIRY    	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DREAM EATER
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | ICY WIND
                    | METRONOME
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SOFT BOILED
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | WORK UP
                    | SIGNAL BEAM
                    | PLAY ROUGH
                    | STORED POWER
                    | ROLE PLAY
                    | TRICK
                    | KNOCK OFF
                    | STEALTH ROCK
                    | ZEN HEADBUTT
                    | RECYCLE
                    | MAGIC COAT

    CLEFABLE    	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DREAM EATER
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | ICY WIND
                    | METRONOME
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SOFT BOILED
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | WORK UP
                    | SIGNAL BEAM
                    | PLAY ROUGH
                    | STORED POWER
                    | ROLE PLAY
                    | TRICK
                    | KNOCK OFF
                    | STEALTH ROCK
                    | ZEN HEADBUTT
                    | RECYCLE
                    | MAGIC COAT

    VULPIX      	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | BLAZE IMPACT
                    | ROLE PLAY
                    | HEAT WAVE
                    | ZEN HEADBUTT
                    | PAIN SPLIT
                    | FOUL PLAY

    NINETALES   	| BODY SLAM
                    | DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | BLAZE IMPACT
                    | NASTY PLOT
                    | STORED POWER
                    | ROLE PLAY
                    | HEAT WAVE
                    | ZEN HEADBUTT
                    | PAIN SPLIT
                    | FOUL PLAY

    JIGGLYPUFF  	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DREAM EATER
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | WORK UP
                    | NASTY PLOT
                    | PLAY ROUGH
                    | ZEN HEADBUTT
                    | ROLE PLAY
                    | KNOCK OFF
                    | STEALTH ROCK
                    | RECYCLE
                    | BODY PRESS
                    | MAGIC COAT
                    | PAIN SPLIT

    WIGGLYTUFF  	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DREAM EATER
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | WORK UP
                    | NASTY PLOT
                    | PLAY ROUGH
                    | ZEN HEADBUTT
                    | ROLE PLAY
                    | KNOCK OFF
                    | STEALTH ROCK
                    | RECYCLE
                    | BODY PRESS
                    | MAGIC COAT
                    | PAIN SPLIT

    ZUBAT       	| DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | GASTRO ACID
                    | NASTY PLOT
                    | DEFOG
                    | TAILWIND
                    | HEAT WAVE
                    | ZEN HEADBUTT

    GOLBAT      	| DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | GASTRO ACID
                    | NASTY PLOT
                    | DEFOG
                    | TAILWIND
                    | HEAT WAVE
                    | ZEN HEADBUTT

    ODDISH      	| DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | GASTRO ACID
                    | WORRY SEED
                    | SEED BOMB
                    | HIDDEN THORNS

    GLOOM       	| DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | GASTRO ACID
                    | WORRY SEED
                    | SEED BOMB
                    | HIDDEN THORNS

    VILEPLUME   	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | GASTRO ACID
                    | WORRY SEED
                    | SEED BOMB
                    | HIDDEN THORNS

    PARAS       	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | KNOCK OFF
                    | WORRY SEED
                    | BUG BITE

    PARASECT    	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | KNOCK OFF
                    | WORRY SEED
                    | BUG BITE

    VENONAT     	| DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SIGNAL BEAM
                    | ZEN HEADBUTT
                    | BUG BITE

    VENOMOTH    	| DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SIGNAL BEAM
                    | DEFOG
                    | TAILWIND
                    | ZEN HEADBUTT
                    | BUG BITE

    DIGLETT     	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | FOUL PLAY
                    | EARTH POWER
                    | WORK UP
                    | STEALTH ROCK

    DUGTRIO     	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | FOUL PLAY
                    | EARTH POWER
                    | WORK UP
                    | STEALTH ROCK

    MEOWTH      	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | WORK UP
                    | NASTY PLOT
                    | PLAY ROUGH
                    | KNOCK OFF
                    | GUNK SHOT
                    | SEED BOMB
                    | FOUL PLAY

    PERSIAN     	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | WORK UP
                    | NASTY PLOT
                    | PLAY ROUGH
                    | KNOCK OFF
                    | GUNK SHOT
                    | SEED BOMB
                    | FOUL PLAY

    PSYDUCK     	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SIGNAL BEAM
                    | ROLE PLAY
                    | NASTY PLOT
                    | ZEN HEADBUTT
                    | LOW KICK
                    | WORRY SEED
                    | AQUA TAIL

    GOLDUCK     	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FURY CUTTER
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | LOW SWEEP
                    | SIGNAL BEAM
                    | ROLE PLAY
                    | NASTY PLOT
                    | ZEN HEADBUTT
                    | LOW KICK
                    | WORRY SEED
                    | LOW KICK
                    | AQUA TAIL

    MANKEY      	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | METRONOME
                    | MIMIC
                    | PSYCH UP
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | THUNDER PUNCH
                    | SEED BOMB
                    | WORK UP
                    | LOW SWEEP
                    | ROLE PLAY
                    | GUNK SHOT

    PRIMEAPE    	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | METRONOME
                    | MIMIC
                    | PSYCH UP
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | THUNDER PUNCH
                    | SEED BOMB
                    | WORK UP
                    | LOW SWEEP
                    | ROLE PLAY
                    | GUNK SHOT

    GROWLITHE   	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | BLAZE IMPACT
                    | PSYCHIC FANGS
                    | PLAY ROUGH
                    | HEAT WAVE

    ARCANINE    	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | BLAZE IMPACT
                    | PSYCHIC FANGS
                    | SUPERPOWER
                    | PLAY ROUGH
                    | HEAT WAVE
                    | IRON HEAD

    POLIWAG     	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | EARTH POWER

    POLIWHIRL   	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | ICE PUNCH
                    | ICY WIND
                    | METRONOME
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | EARTH POWER

    POLIWRATH   	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | ICE PUNCH
                    | ICY WIND
                    | METRONOME
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | EARTH POWER
                    | WORK UP
                    | LOW SWEEP
                    | SUPERPOWER

    ABRA        	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DREAM EATER
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | METRONOME
                    | MIMIC
                    | PSYCH UP
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | SIGNAL BEAM
                    | ROLE PLAY
                    | TRICK
                    | KNOCK OFF
                    | ZEN HEADBUTT
                    | RECYCLE
                    | MAGIC COAT
                    | FOUL PLAY

    KADABRA     	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DREAM EATER
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | METRONOME
                    | MIMIC
                    | PSYCH UP
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | SIGNAL BEAM
                    | ROLE PLAY
                    | TRICK
                    | KNOCK OFF
                    | ZEN HEADBUTT
                    | RECYCLE
                    | MAGIC COAT
                    | FOUL PLAY

    ALAKAZAM    	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DREAM EATER
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | METRONOME
                    | MIMIC
                    | PSYCH UP
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | SIGNAL BEAM
                    | NASTY PLOT
                    | STORED POWER
                    | ROLE PLAY
                    | TRICK
                    | KNOCK OFF
                    | ZEN HEADBUTT
                    | RECYCLE
                    | MAGIC COAT
                    | FOUL PLAY

    MACHOP      	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | METRONOME
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | WORK UP
                    | LOW SWEEP
                    | SUPERPOWER
                    | ROLE PLAY
                    | KNOCK OFF
                    | LOW KICK

    MACHOKE     	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | METRONOME
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | WORK UP
                    | LOW SWEEP
                    | SUPERPOWER
                    | ROLE PLAY
                    | KNOCK OFF
                    | LOW KICK

    MACHAMP     	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | METRONOME
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | WORK UP
                    | LOW SWEEP
                    | SUPERPOWER
                    | ROLE PLAY
                    | KNOCK OFF
                    | LOW KICK

    BELLSPROUT  	| DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | GASTRO ACID
                    | KNOCK OFF
                    | WORRY SEED
                    | HIDDEN THORNS

    WEEPINBELL  	| DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | GASTRO ACID
                    | KNOCK OFF
                    | WORRY SEED
                    | HIDDEN THORNS
                    | BUG BITE

    VICTREEBEL  	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | GASTRO ACID
                    | KNOCK OFF
                    | WORRY SEED
                    | HIDDEN THORNS
                    | BUG BITE

    TENTACOOL   	| DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | GASTRO ACID
                    | KNOCK OFF
                    | MAGIC COAT

    TENTACRUEL  	| DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | GASTRO ACID
                    | KNOCK OFF
                    | MAGIC COAT

    GEODUDE     	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | EXPLOSION
                    | FIRE PUNCH
                    | METRONOME
                    | MIMIC
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | EARTH POWER
                    | SUPERPOWER
                    | STEALTH ROCK

    GRAVELER    	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | EXPLOSION
                    | FIRE PUNCH
                    | METRONOME
                    | MIMIC
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | EARTH POWER
                    | SUPERPOWER
                    | STEALTH ROCK

    GOLEM       	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | EXPLOSION
                    | FIRE PUNCH
                    | FURY CUTTER
                    | METRONOME
                    | MIMIC
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | EARTH POWER
                    | SUPERPOWER
                    | STEALTH ROCK

    PONYTA      	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | BLAZE IMPACT
                    | PLAY ROUGH
                    | HEAT WAVE
                    | LOW KICK

    RAPIDASH    	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | BLAZE IMPACT
                    | PLAY ROUGH
                    | HEAT WAVE
                    | LOW KICK
                    | MEGAHORN

    SLOWPOKE    	| BODY SLAM
                    | DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | FOUL PLAY
                    | SWIFT
                    | AVALANCHE
                    | SIGNAL BEAM
                    | STORED POWER
                    | TRICK
                    | ZEN HEADBUTT
                    | RECYCLE
                    | MAGIC COAT
                    | AQUA TAIL

    SLOWBRO     	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DREAM EATER
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FURY CUTTER
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | AVALANCHE
                    | SIGNAL BEAM
                    | NASTY PLOT
                    | STORED POWER
                    | TRICK
                    | ZEN HEADBUTT
                    | BODY PRESS
                    | RECYCLE
                    | MAGIC COAT
                    | AQUA TAIL
                    | FOUL PLAY

    MAGNEMITE   	| DOUBLE EDGE
                    | ENDURE
                    | EXPLOSION
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SIGNAL BEAM
                    | RECYCLE
                    | MAGIC COAT

    MAGNETON    	| DOUBLE EDGE
                    | ENDURE
                    | EXPLOSION
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SIGNAL BEAM
                    | RECYCLE
                    | MAGIC COAT

    FARFETCHD   	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | WORK UP
                    | DEFOG
                    | KNOCK OFF
                    | TAILWIND
                    | HEAT WAVE

    DODUO       	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | WORK UP
                    | KNOCK OFF

    DODRIO      	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | WORK UP
                    | KNOCK OFF

    SEEL        	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SIGNAL BEAM
                    | AQUA TAIL
                    | MEGAHORN

    DEWGONG     	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SERPENT DANCE
                    | AVALANCHE
                    | SIGNAL BEAM
                    | AQUA TAIL
                    | MEGAHORN

    GRIMER      	| BODY SLAM
                    | DYNAMIC PUNCH
                    | ENDURE
                    | EXPLOSION
                    | FIRE PUNCH
                    | ICE PUNCH
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | GASTRO ACID
                    | ZEN HEADBUTT
                    | GUNK SHOT
                    | PAIN SPLIT

    MUK         	| BODY SLAM
                    | DYNAMIC PUNCH
                    | ENDURE
                    | EXPLOSION
                    | FIRE PUNCH
                    | ICE PUNCH
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | GASTRO ACID
                    | ZEN HEADBUTT
                    | GUNK SHOT
                    | PAIN SPLIT

    SHELLDER    	| DOUBLE EDGE
                    | ENDURE
                    | EXPLOSION
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | AVALANCHE

    CLOYSTER    	| DOUBLE EDGE
                    | ENDURE
                    | EXPLOSION
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | AVALANCHE
                    | SIGNAL BEAM

    GASTLY      	| DREAM EATER
                    | ENDURE
                    | EXPLOSION
                    | FIRE PUNCH
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | TRICK
                    | KNOCK OFF
                    | PAIN SPLIT
                    | NASTY PLOT
                    | FOUL PLAY
                    | GUNK SHOT

    HAUNTER     	| DREAM EATER
                    | ENDURE
                    | EXPLOSION
                    | FIRE PUNCH
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | TRICK
                    | KNOCK OFF
                    | PAIN SPLIT
                    | NASTY PLOT
                    | FOUL PLAY
                    | GUNK SHOT

    GENGAR      	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DREAM EATER
                    | DYNAMIC PUNCH
                    | ENDURE
                    | EXPLOSION
                    | FIRE PUNCH
                    | ICE PUNCH
                    | ICY WIND
                    | METRONOME
                    | MIMIC
                    | PSYCH UP
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | NASTY PLOT
                    | ROLE PLAY
                    | TRICK
                    | KNOCK OFF
                    | PAIN SPLIT
                    | FOUL PLAY
                    | GUNK SHOT

    ONIX        	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | EXPLOSION
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SERPENT DANCE
                    | FLINT BLADE
                    | EARTH POWER
                    | BREAKING SWIPE
                    | STEALTH ROCK
                    | BODY PRESS
                    | IRON HEAD

    DROWZEE     	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DREAM EATER
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | METRONOME
                    | MIMIC
                    | PSYCH UP
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | LOW SWEEP
                    | SIGNAL BEAM
                    | ZEN HEADBUTT
                    | LOW KICK
                    | NASTY PLOT
                    | ROLE PLAY
                    | RECYCLE
                    | MAGIC COAT
                    | FOUL PLAY

    HYPNO       	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DREAM EATER
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | METRONOME
                    | MIMIC
                    | PSYCH UP
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | LOW SWEEP
                    | SIGNAL BEAM
                    | ZEN HEADBUTT
                    | LOW KICK
                    | NASTY PLOT
                    | ROLE PLAY
                    | BODY PRESS
                    | RECYCLE
                    | MAGIC COAT
                    | FOUL PLAY

    KRABBY      	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | SUPERPOWER
                    | KNOCK OFF

    KINGLER     	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | SUPERPOWER
                    | KNOCK OFF

    VOLTORB     	| ENDURE
                    | EXPLOSION
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SIGNAL BEAM
                    | MAGIC COAT
                    | FOUL PLAY

    ELECTRODE   	| ENDURE
                    | EXPLOSION
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SIGNAL BEAM
                    | MAGIC COAT
                    | FOUL PLAY

    EXEGGCUTE   	| DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | EXPLOSION
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | WORRY SEED
                    | SEED BOMB

    EXEGGUTOR   	| DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | EXPLOSION
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | ZEN HEADBUTT
                    | WORRY SEED
                    | LOW KICK
                    | SEED BOMB

    CUBONE      	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | FURY CUTTER
                    | ICY WIND
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | THUNDER PUNCH
                    | EARTH POWER
                    | KNOCK OFF
                    | STEALTH ROCK
                    | LOW KICK
                    | IRON HEAD

    MAROWAK     	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | FURY CUTTER
                    | ICY WIND
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | THUNDER PUNCH
                    | EARTH POWER
                    | KNOCK OFF
                    | STEALTH ROCK
                    | IRON HEAD

    HITMONLEE   	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | METRONOME
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | WORK UP
                    | LOW SWEEP
                    | SUPERPOWER
                    | ROLE PLAY
                    | KNOCK OFF
                    | LOW KICK

    HITMONCHAN  	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | METRONOME
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | THUNDER PUNCH
                    | WORK UP
                    | LOW SWEEP
                    | ROLE PLAY
                    | LOW KICK

    LICKITUNG   	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DREAM EATER
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | THUNDER PUNCH
                    | WORK UP
                    | KNOCK OFF
                    | ZEN HEADBUTT
                    | BODY PRESS
                    | AQUA TAIL

    KOFFING     	| ENDURE
                    | EXPLOSION
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | GUNK SHOT
                    | PAIN SPLIT

    WEEZING     	| ENDURE
                    | EXPLOSION
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | HEAT WAVE
                    | GUNK SHOT
                    | PAIN SPLIT
                    | GASTRO ACID

    RHYHORN     	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | EARTH POWER
                    | SUPERPOWER
                    | STEALTH ROCK
                    | AQUA TAIL
                    | MEGAHORN

    RHYDON      	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | FURY CUTTER
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | THUNDER PUNCH
                    | EARTH POWER
                    | BREAKING SWIPE
                    | AVALANCHE
                    | SUPERPOWER
                    | STEALTH ROCK
                    | BODY PRESS
                    | AQUA TAIL
                    | MEGAHORN

    CHANSEY     	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DREAM EATER
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | ICY WIND
                    | METRONOME
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SOFT BOILED
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | WORK UP
                    | STORED POWER
                    | STEALTH ROCK
                    | ZEN HEADBUTT
                    | RECYCLE

    TANGELA     	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | KNOCK OFF
                    | WORRY SEED
                    | PAIN SPLIT
                    | SEED BOMB
                    | HIDDEN THORNS

    KANGASKHAN  	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | FURY CUTTER
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | WORK UP
                    | AVALANCHE
                    | LOW KICK
                    | AQUA TAIL

    HORSEA      	| DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SERPENT DANCE
                    | SIGNAL BEAM

    SEADRA      	| DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SERPENT DANCE
                    | SIGNAL BEAM

    GOLDEEN     	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SIGNAL BEAM
                    | KNOCK OFF
                    | AQUA TAIL
                    | MEGAHORN

    SEAKING     	| DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SIGNAL BEAM
                    | KNOCK OFF
                    | AQUA TAIL
                    | MEGAHORN

    STARYU      	| DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SIGNAL BEAM
                    | RECYCLE
                    | MAGIC COAT
                    | PAIN SPLIT

    STARMIE     	| DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | AVALANCHE
                    | SIGNAL BEAM
                    | TRICK
                    | RECYCLE
                    | MAGIC COAT
                    | PAIN SPLIT

    MR MIME     	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DREAM EATER
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | ICY WIND
                    | METRONOME
                    | MIMIC
                    | PSYCH UP
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | SIGNAL BEAM
                    | NASTY PLOT
                    | STORED POWER
                    | ROLE PLAY
                    | TRICK
                    | ZEN HEADBUTT
                    | RECYCLE
                    | MAGIC COAT
                    | FOUL PLAY

    SCYTHER     	| COUNTER
                    | DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | DEFOG
                    | KNOCK OFF
                    | TAILWIND
                    | BUG BITE

    JYNX        	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DREAM EATER
                    | DYNAMIC PUNCH
                    | ENDURE
                    | ICE PUNCH
                    | ICY WIND
                    | METRONOME
                    | MIMIC
                    | PSYCH UP
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | AVALANCHE
                    | SIGNAL BEAM
                    | NASTY PLOT
                    | ROLE PLAY
                    | ZEN HEADBUTT
                    | RECYCLE
                    | MAGIC COAT

    ELECTABUZZ  	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | METRONOME
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | THUNDER PUNCH
                    | LOW SWEEP
                    | SIGNAL BEAM
                    | LOW KICK

    MAGMAR      	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | METRONOME
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | LOW SWEEP
                    | HEAT WAVE
                    | LOW KICK

    PINSIR      	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | SUPERPOWER
                    | KNOCK OFF
                    | STEALTH ROCK
                    | BUG BITE

    TAUROS      	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | WORK UP
                    | ROLE PLAY
                    | ZEN HEADBUTT
                    | IRON HEAD
                    | MEGAHORN

    MAGIKARP      =	| 

    GYARADOS    	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SERPENT DANCE
                    | BREAKING SWIPE
                    | AVALANCHE
                    | IRON HEAD
                    | AQUA TAIL

    LAPRAS      	| BODY SLAM
                    | DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | AVALANCHE
                    | SIGNAL BEAM
                    | ZEN HEADBUTT
                    | BODY PRESS
                    | IRON HEAD
                    | AQUA TAIL
                    | MEGAHORN

    DITTO         =	| 

    EEVEE       	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | WORK UP
                    | STORED POWER

    VAPOREON    	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | WORK UP
                    | SIGNAL BEAM
                    | STORED POWER
                    | AQUA TAIL

    JOLTEON     	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | WORK UP
                    | SIGNAL BEAM
                    | STORED POWER

    FLAREON     	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | BLAZE IMPACT
                    | WORK UP
                    | SUPERPOWER
                    | STORED POWER
                    | HEAT WAVE

    PORYGON     	| DEFENSE CURL
                    | DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SIGNAL BEAM
                    | TRICK
                    | ZEN HEADBUTT
                    | RECYCLE
                    | MAGIC COAT
                    | PAIN SPLIT
                    | FOUL PLAY

    OMANYTE     	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | EARTH POWER
                    | KNOCK OFF
                    | STEALTH ROCK

    OMASTAR     	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | EARTH POWER
                    | KNOCK OFF
                    | STEALTH ROCK

    KABUTO      	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | FLINT BLADE
                    | EARTH POWER
                    | KNOCK OFF
                    | STEALTH ROCK

    KABUTOPS    	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | ICY WIND
                    | MIMIC
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | FLINT BLADE
                    | EARTH POWER
                    | SUPERPOWER
                    | KNOCK OFF
                    | STEALTH ROCK
                    | LOW KICK
                    | AQUA TAIL

    AERODACTYL  	| DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | FLINT BLADE
                    | PSYCHIC FANGS
                    | EARTH POWER
                    | DEFOG
                    | STEALTH ROCK
                    | TAILWIND
                    | HEAT WAVE
                    | IRON HEAD
                    | AQUA TAIL

    SNORLAX     	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | ICY WIND
                    | METRONOME
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | GASTRO ACID
                    | WORK UP
                    | SUPERPOWER
                    | GUNK SHOT
                    | ZEN HEADBUTT
                    | BODY PRESS
                    | SEED BOMB
                    | IRON HEAD

    ARTICUNO    	| DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | AVALANCHE
                    | SIGNAL BEAM
                    | DEFOG
                    | TAILWIND

    ZAPDOS      	| DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SIGNAL BEAM
                    | DEFOG
                    | TAILWIND
                    | HEAT WAVE

    MOLTRES     	| DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | DEFOG
                    | TAILWIND
                    | HEAT WAVE
                    | BLAZE IMPACT

    DRATINI     	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SERPENT DANCE
                    | BREAKING SWIPE
                    | AQUA TAIL
                    | DRACO METEOR

    DRAGONAIR   	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SERPENT DANCE
                    | BREAKING SWIPE
                    | AQUA TAIL
                    | DRACO METEOR

    DRAGONITE   	| BODY SLAM
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | FURY CUTTER
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | THUNDER PUNCH
                    | SERPENT DANCE
                    | BREAKING SWIPE
                    | SUPERPOWER
                    | DEFOG
                    | TAILWIND
                    | HEAT WAVE
                    | BODY PRESS
                    | LOW KICK
                    | IRON HEAD
                    | AQUA TAIL
                    | DRACO METEOR

    MEWTWO      	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DREAM EATER
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | ICY WIND
                    | METRONOME
                    | MIMIC
                    | PSYCH UP
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | THUNDER PUNCH
                    | LOW SWEEP
                    | AVALANCHE
                    | SIGNAL BEAM
                    | NASTY PLOT
                    | STORED POWER
                    | ROLE PLAY
                    | TRICK
                    | ZEN HEADBUTT
                    | RECYCLE
                    | LOW KICK
                    | MAGIC COAT
                    | AQUA TAIL
                    | FOUL PLAY

    MEW         	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DREAM EATER
                    | DYNAMIC PUNCH
                    | ENDURE
                    | EXPLOSION
                    | FIRE PUNCH
                    | FURY CUTTER
                    | ICE PUNCH
                    | ICY WIND
                    | METRONOME
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SOFT BOILED
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | THUNDER PUNCH
                    | GASTRO ACID
                    | SERPENT DANCE
                    | FLINT BLADE
                    | BLAZE IMPACT
                    | PSYCHIC FANGS
                    | EARTH POWER
                    | WORK UP
                    | BREAKING SWIPE
                    | LOW SWEEP
                    | AVALANCHE
                    | SIGNAL BEAM
                    | NASTY PLOT
                    | SUPERPOWER
                    | PLAY ROUGH
                    | STORED POWER
                    | ROLE PLAY
                    | DEFOG
                    | TRICK
                    | KNOCK OFF
                    | STEALTH ROCK
                    | TAILWIND
                    | HEAT WAVE
                    | GUNK SHOT
                    | ZEN HEADBUTT
                    | BODY PRESS
                    | WORRY SEED
                    | RECYCLE
                    | LOW KICK
                    | MAGIC COAT
                    | PAIN SPLIT
                    | SEED BOMB
                    | IRON HEAD
                    | AQUA TAIL
                    | FOUL PLAY
                    | MEGAHORN
                    | DRACO METEOR
                    | HIDDEN THORNS
                    | BUG BITE

    CHIKORITA   	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | WORK UP
                    | WORRY SEED
                    | MAGIC COAT
                    | SEED BOMB
                    | HIDDEN THORNS

    BAYLEEF     	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | WORK UP
                    | WORRY SEED
                    | MAGIC COAT
                    | SEED BOMB
                    | HIDDEN THORNS

    MEGANIUM    	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | WORK UP
                    | WORRY SEED
                    | MAGIC COAT
                    | SEED BOMB
                    | HIDDEN THORNS
                    | BODY PRESS

    CYNDAQUIL   	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | IRON HEAD
                    | BLAZE IMPACT
                    | ZEN HEADBUTT
                    | WORK UP

    QUILAVA     	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | IRON HEAD
                    | BLAZE IMPACT
                    | ZEN HEADBUTT
                    | WORK UP

    TYPHLOSION  	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | FURY CUTTER
                    | MIMIC
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | THUNDER PUNCH
                    | LOW KICK
                    | IRON HEAD
                    | BLAZE IMPACT
                    | ZEN HEADBUTT
                    | WORK UP

    TOTODILE    	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | WORK UP
                    | AQUA TAIL

    CROCONAW    	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FURY CUTTER
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | PSYCHIC FANGS
                    | WORK UP
                    | AQUA TAIL

    FERALIGATR  	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FURY CUTTER
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | PSYCHIC FANGS
                    | WORK UP
                    | AVALANCHE
                    | AQUA TAIL

    SENTRET     	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | FURY CUTTER
                    | ICE PUNCH
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | THUNDER PUNCH
                    | WORK UP
                    | KNOCK OFF
                    | AQUA TAIL

    FURRET      	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | FURY CUTTER
                    | ICE PUNCH
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | THUNDER PUNCH
                    | SERPENT DANCE
                    | WORK UP
                    | KNOCK OFF
                    | AQUA TAIL

    HOOTHOOT    	| DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | WORK UP
                    | NASTY PLOT
                    | STORED POWER
                    | DEFOG
                    | TAILWIND
                    | HEAT WAVE
                    | ZEN HEADBUTT
                    | RECYCLE
                    | MAGIC COAT

    NOCTOWL     	| DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | WORK UP
                    | NASTY PLOT
                    | STORED POWER
                    | DEFOG
                    | TAILWIND
                    | HEAT WAVE
                    | ZEN HEADBUTT
                    | RECYCLE
                    | MAGIC COAT

    LEDYBA      	| COUNTER
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | ICE PUNCH
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | THUNDER PUNCH
                    | KNOCK OFF
                    | TAILWIND
                    | BUG BITE

    LEDIAN      	| DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | ICE PUNCH
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | THUNDER PUNCH
                    | KNOCK OFF
                    | TAILWIND
                    | BUG BITE

    SPINARAK    	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SIGNAL BEAM
                    | FOUL PLAY
                    | MEGAHORN
                    | BUG BITE

    ARIADOS     	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | SIGNAL BEAM
                    | FOUL PLAY
                    | MEGAHORN
                    | BUG BITE

    CROBAT      	| DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | GASTRO ACID
                    | NASTY PLOT
                    | DEFOG
                    | TAILWIND
                    | HEAT WAVE
                    | ZEN HEADBUTT

    CHINCHOU    	| DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SIGNAL BEAM

    LANTURN     	| DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SIGNAL BEAM
                    | AQUA TAIL

    PICHU       	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | THUNDER PUNCH
                    | SIGNAL BEAM
                    | NASTY PLOT
                    | PLAY ROUGH

    CLEFFA      	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | ICY WIND
                    | METRONOME
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SOFT BOILED
                    | SUBSTITUTE
                    | SWAGGER
                    | WORK UP
                    | SIGNAL BEAM
                    | PLAY ROUGH
                    | STORED POWER
                    | ROLE PLAY
                    | TRICK
                    | ZEN HEADBUTT
                    | RECYCLE
                    | MAGIC COAT

    IGGLYBUFF   	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | WORK UP
                    | PLAY ROUGH
                    | ROLE PLAY
                    | RECYCLE
                    | MAGIC COAT
                    | PAIN SPLIT

    TOGEPI      	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | METRONOME
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SOFT BOILED
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | WORK UP
                    | SIGNAL BEAM
                    | NASTY PLOT
                    | PLAY ROUGH
                    | STORED POWER
                    | TRICK
                    | ZEN HEADBUTT
                    | MAGIC COAT

    TOGETIC     	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | METRONOME
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SOFT BOILED
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | WORK UP
                    | SIGNAL BEAM
                    | NASTY PLOT
                    | PLAY ROUGH
                    | STORED POWER
                    | DEFOG
                    | TRICK
                    | TAILWIND
                    | HEAT WAVE
                    | ZEN HEADBUTT
                    | MAGIC COAT

    NATU        	| DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SIGNAL BEAM
                    | STORED POWER
                    | TRICK
                    | TAILWIND
                    | HEAT WAVE
                    | ZEN HEADBUTT
                    | MAGIC COAT
                    | PAIN SPLIT

    XATU        	| DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SIGNAL BEAM
                    | STORED POWER
                    | DEFOG
                    | TRICK
                    | TAILWIND
                    | HEAT WAVE
                    | ZEN HEADBUTT
                    | MAGIC COAT
                    | PAIN SPLIT
                    | FOUL PLAY

    MAREEP      	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SIGNAL BEAM

    FLAAFFY     	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | THUNDER PUNCH
                    | SIGNAL BEAM
                    | LOW KICK

    AMPHAROS    	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | THUNDER PUNCH
                    | SIGNAL BEAM
                    | LOW KICK

    BELLOSSOM   	| DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | GASTRO ACID
                    | PLAY ROUGH
                    | WORRY SEED
                    | SEED BOMB
                    | HIDDEN THORNS

    MARILL      	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | WORK UP
                    | SUPERPOWER
                    | PLAY ROUGH
                    | KNOCK OFF
                    | AQUA TAIL

    AZUMARILL   	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | WORK UP
                    | SUPERPOWER
                    | PLAY ROUGH
                    | KNOCK OFF
                    | AQUA TAIL

    SUDOWOODO   	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | EXPLOSION
                    | FIRE PUNCH
                    | ICE PUNCH
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | EARTH POWER
                    | ROLE PLAY
                    | STEALTH ROCK
                    | BODY PRESS
                    | LOW KICK
                    | FOUL PLAY

    POLITOED    	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | ICE PUNCH
                    | ICY WIND
                    | METRONOME
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | EARTH POWER

    HOPPIP      	| DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | SEED BOMB
                    | WORRY SEED

    SKIPLOOM    	| DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | SEED BOMB
                    | WORRY SEED

    JUMPLUFF    	| DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | SEED BOMB
                    | WORRY SEED

    AIPOM       	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DREAM EATER
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | FURY CUTTER
                    | ICE PUNCH
                    | METRONOME
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | THUNDER PUNCH
                    | WORK UP
                    | LOW SWEEP
                    | NASTY PLOT
                    | ROLE PLAY
                    | KNOCK OFF
                    | GUNK SHOT

    SUNKERN     	| DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | SEED BOMB
                    | EARTH POWER
                    | WORRY SEED

    SUNFLORA    	| DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | SEED BOMB
                    | EARTH POWER
                    | WORRY SEED

    YANMA       	| DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SIGNAL BEAM
                    | DEFOG
                    | TAILWIND
                    | BUG BITE

    WOOPER      	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | AVALANCHE
                    | EARTH POWER
                    | AQUA TAIL

    QUAGSIRE    	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | AVALANCHE
                    | BODY PRESS
                    | EARTH POWER
                    | AQUA TAIL

    ESPEON      	| BODY SLAM
                    | DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | PSYCHIC FANGS
                    | WORK UP
                    | SIGNAL BEAM
                    | STORED POWER
                    | TRICK
                    | ZEN HEADBUTT
                    | MAGIC COAT

    UMBREON     	| BODY SLAM
                    | DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | WORK UP
                    | STORED POWER
                    | FOUL PLAY

    MURKROW     	| DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | DEFOG
                    | TAILWIND
                    | NASTY PLOT
                    | HEAT WAVE
                    | FOUL PLAY

    SLOWKING    	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DREAM EATER
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FURY CUTTER
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | AVALANCHE
                    | SIGNAL BEAM
                    | NASTY PLOT
                    | STORED POWER
                    | TRICK
                    | ZEN HEADBUTT
                    | RECYCLE
                    | MAGIC COAT
                    | AQUA TAIL
                    | FOUL PLAY

    MISDREAVUS  	| DEFENSE CURL
                    | DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | FOUL PLAY
                    | SWIFT
                    | NASTY PLOT
                    | MAGIC COAT
                    | PAIN SPLIT

    UNOWN         =	| 

    WOBBUFFET   	| COUNTER

    GIRAFARIG   	| BODY SLAM
                    | DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | PSYCHIC FANGS
                    | WORK UP
                    | SIGNAL BEAM
                    | NASTY PLOT
                    | FOUL PLAY
                    | LOW KICK
                    | RECYCLE
                    | MAGIC COAT
                    | ZEN HEADBUTT

    PINECO      	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | EXPLOSION
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | STEALTH ROCK
                    | SEED BOMB
                    | PAIN SPLIT
                    | BUG BITE

    FORRETRESS  	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | EXPLOSION
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | EARTH POWER
                    | SIGNAL BEAM
                    | STEALTH ROCK
                    | BODY PRESS
                    | SEED BOMB
                    | PAIN SPLIT
                    | BUG BITE

    DUNSPARCE   	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | EARTH POWER
                    | SERPENT DANCE
                    | STORED POWER
                    | STEALTH ROCK
                    | ZEN HEADBUTT
                    | MAGIC COAT
                    | PAIN SPLIT
                    | AQUA TAIL

    GLIGAR      	| COUNTER
                    | DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | FURY CUTTER
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | DEFOG
                    | KNOCK OFF
                    | STEALTH ROCK
                    | TAILWIND
                    | AQUA TAIL
                    | BUG BITE

    STEELIX     	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | EXPLOSION
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SERPENT DANCE
                    | FLINT BLADE
                    | PSYCHIC FANGS
                    | EARTH POWER
                    | BREAKING SWIPE
                    | STEALTH ROCK
                    | BODY PRESS
                    | IRON HEAD
                    | AQUA TAIL

    SNUBBULL    	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | METRONOME
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | WORK UP

    GRANBULL    	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | METRONOME
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | WORK UP

    QWILFISH    	| DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | EXPLOSION
                    | ICY WIND
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | SIGNAL BEAM
                    | PAIN SPLIT
                    | GUNK SHOT
                    | AQUA TAIL

    SCIZOR      	| COUNTER
                    | DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | SUPERPOWER
                    | DEFOG
                    | KNOCK OFF
                    | TAILWIND
                    | IRON HEAD
                    | BUG BITE

    SHUCKLE     	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | GASTRO ACID
                    | EARTH POWER
                    | KNOCK OFF
                    | STEALTH ROCK
                    | BUG BITE

    HERACROSS   	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | WORK UP
                    | KNOCK OFF
                    | LOW KICK
                    | MEGAHORN
                    | BUG BITE

    SNEASEL     	| COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DREAM EATER
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FURY CUTTER
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | LOW SWEEP
                    | AVALANCHE
                    | KNOCK OFF
                    | LOW KICK
                    | NASTY PLOT
                    | FOUL PLAY

    TEDDIURSA   	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | FURY CUTTER
                    | ICE PUNCH
                    | METRONOME
                    | MIMIC
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | SUPERPOWER
                    | LOW KICK
                    | SEED BOMB
                    | THUNDER PUNCH
                    | WORK UP
                    | PLAY ROUGH
                    | AVALANCHE
                    | GUNK SHOT

    URSARING    	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | FURY CUTTER
                    | ICE PUNCH
                    | METRONOME
                    | MIMIC
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | SUPERPOWER
                    | LOW KICK
                    | SEED BOMB
                    | THUNDER PUNCH
                    | WORK UP
                    | PLAY ROUGH
                    | AVALANCHE
                    | GUNK SHOT

    SLUGMA      	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | EARTH POWER
                    | PAIN SPLIT

    MAGCARGO    	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | EXPLOSION
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | EARTH POWER
                    | STEALTH ROCK
                    | PAIN SPLIT

    SWINUB      	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | EARTH POWER
                    | AVALANCHE
                    | SUPERPOWER
                    | STEALTH ROCK

    PILOSWINE   	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | EARTH POWER
                    | AVALANCHE
                    | SUPERPOWER
                    | STEALTH ROCK

    CORSOLA     	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | EXPLOSION
                    | ICY WIND
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | EARTH POWER
                    | STEALTH ROCK
                    | MAGIC COAT

    REMORAID    	| DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SIGNAL BEAM
                    | GUNK SHOT
                    | SEED BOMB

    OCTILLERY   	| DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SIGNAL BEAM
                    | GUNK SHOT
                    | SEED BOMB

    DELIBIRD    	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | ENDURE
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | AVALANCHE
                    | SIGNAL BEAM
                    | DEFOG
                    | GUNK SHOT
                    | FOUL PLAY
                    | RECYCLE
                    | SEED BOMB

    MANTINE     	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SIGNAL BEAM
                    | DEFOG
                    | TAILWIND
                    | GUNK SHOT
                    | BODY PRESS
                    | SEED BOMB
                    | IRON HEAD
                    | AQUA TAIL

    SKARMORY    	| COUNTER
                    | DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | DEFOG
                    | TAILWIND
                    | BODY PRESS
                    | IRON HEAD

    HOUNDOUR    	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | PSYCHIC FANGS
                    | BLAZE IMPACT
                    | NASTY PLOT
                    | FOUL PLAY
                    | ROLE PLAY

    HOUNDOOM    	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | PSYCHIC FANGS
                    | BLAZE IMPACT
                    | NASTY PLOT
                    | FOUL PLAY
                    | ROLE PLAY

    KINGDRA     	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SERPENT DANCE
                    | BREAKING SWIPE
                    | SIGNAL BEAM
                    | IRON HEAD
                    | DRACO METEOR

    PHANPY      	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | EARTH POWER
                    | BLAZE IMPACT
                    | KNOCK OFF
                    | SUPERPOWER
                    | SEED BOMB
                    | IRON HEAD
                    | STEALTH ROCK
                    | GUNK SHOT

    DONPHAN     	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | EARTH POWER
                    | BLAZE IMPACT
                    | KNOCK OFF
                    | SUPERPOWER
                    | BODY PRESS
                    | SEED BOMB
                    | IRON HEAD
                    | STEALTH ROCK
                    | GUNK SHOT

    PORYGON2    	| DEFENSE CURL
                    | DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SIGNAL BEAM
                    | TRICK
                    | ZEN HEADBUTT
                    | RECYCLE
                    | MAGIC COAT
                    | PAIN SPLIT
                    | FOUL PLAY

    STANTLER    	| BODY SLAM
                    | DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | WORK UP
                    | SIGNAL BEAM
                    | ROLE PLAY
                    | ZEN HEADBUTT

    SMEARGLE    	| SEISMIC TOSS
                    | SLEEP TALK

    TYROGUE     	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | WORK UP
                    | LOW SWEEP
                    | ROLE PLAY
                    | LOW KICK

    HITMONTOP   	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | WORK UP
                    | LOW SWEEP
                    | ROLE PLAY
                    | LOW KICK

    SMOOCHUM    	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DREAM EATER
                    | DYNAMIC PUNCH
                    | ENDURE
                    | ICE PUNCH
                    | ICY WIND
                    | METRONOME
                    | MIMIC
                    | PSYCH UP
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | AVALANCHE
                    | SIGNAL BEAM
                    | NASTY PLOT
                    | ROLE PLAY
                    | TRICK
                    | ZEN HEADBUTT
                    | RECYCLE
                    | MAGIC COAT

    ELEKID      	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | THUNDER PUNCH
                    | SIGNAL BEAM
                    | LOW KICK

    MAGBY       	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | HEAT WAVE
                    | LOW KICK

    MILTANK     	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | ICY WIND
                    | METRONOME
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | WORK UP
                    | PLAY ROUGH
                    | STEALTH ROCK
                    | ZEN HEADBUTT
                    | BODY PRESS
                    | IRON HEAD

    BLISSEY     	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DREAM EATER
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | ICY WIND
                    | METRONOME
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SOFT BOILED
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | WORK UP
                    | AVALANCHE
                    | STORED POWER
                    | STEALTH ROCK
                    | ZEN HEADBUTT
                    | RECYCLE

    RAIKOU      	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SIGNAL BEAM
                    | IRON HEAD

    ENTEI       	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | BLAZE IMPACT
                    | HEAT WAVE
                    | IRON HEAD

    SUICUNE     	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | AVALANCHE
                    | SIGNAL BEAM
                    | TAILWIND
                    | IRON HEAD

    LARVITAR    	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | EARTH POWER
                    | SUPERPOWER
                    | STEALTH ROCK
                    | IRON HEAD

    PUPITAR     	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | EARTH POWER
                    | SUPERPOWER
                    | STEALTH ROCK
                    | IRON HEAD

    TYRANITAR   	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | FURY CUTTER
                    | ICE PUNCH
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | EARTH POWER
                    | BREAKING SWIPE
                    | AVALANCHE
                    | SUPERPOWER
                    | STEALTH ROCK
                    | BODY PRESS
                    | LOW KICK
                    | IRON HEAD
                    | AQUA TAIL
                    | FOUL PLAY

    LUGIA       	| BODY SLAM
                    | DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | EARTH POWER
                    | BREAKING SWIPE
                    | AVALANCHE
                    | SIGNAL BEAM
                    | DEFOG
                    | TRICK
                    | TAILWIND
                    | ZEN HEADBUTT
                    | IRON HEAD
                    | AQUA TAIL

    HO OH       	| DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | EARTH POWER
                    | SIGNAL BEAM
                    | DEFOG
                    | TAILWIND
                    | HEAT WAVE
                    | ZEN HEADBUTT
                    | IRON HEAD

    CELEBI      	| DEFENSE CURL
                    | DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | METRONOME
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | EARTH POWER
                    | SIGNAL BEAM
                    | NASTY PLOT
                    | TRICK
                    | STEALTH ROCK
                    | ZEN HEADBUTT
                    | WORRY SEED
                    | MAGIC COAT
                    | SEED BOMB
                    | HIDDEN THORNS

    TREECKO     	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FURY CUTTER
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | THUNDER PUNCH
                    | WORK UP
                    | WORRY SEED
                    | LOW KICK
                    | SEED BOMB
                    | HIDDEN THORNS

    GROVYLE     	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FURY CUTTER
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | THUNDER PUNCH
                    | WORK UP
                    | LOW SWEEP
                    | WORRY SEED
                    | LOW KICK
                    | SEED BOMB
                    | HIDDEN THORNS

    SCEPTILE    	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FURY CUTTER
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | THUNDER PUNCH
                    | WORK UP
                    | BREAKING SWIPE
                    | LOW SWEEP
                    | WORRY SEED
                    | LOW KICK
                    | SEED BOMB
                    | HIDDEN THORNS

    TORCHIC     	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | WORK UP
                    | HEAT WAVE
                    | LOW KICK

    COMBUSKEN   	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | FURY CUTTER
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | THUNDER PUNCH
                    | BLAZE IMPACT
                    | WORK UP
                    | LOW SWEEP
                    | HEAT WAVE
                    | LOW KICK

    BLAZIKEN    	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | FURY CUTTER
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | THUNDER PUNCH
                    | BLAZE IMPACT
                    | WORK UP
                    | LOW SWEEP
                    | SUPERPOWER
                    | ROLE PLAY
                    | KNOCK OFF
                    | HEAT WAVE
                    | LOW KICK

    MUDKIP      	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | EARTH POWER
                    | WORK UP
                    | AVALANCHE
                    | SUPERPOWER
                    | LOW KICK
                    | AQUA TAIL

    MARSHTOMP   	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | EARTH POWER
                    | WORK UP
                    | AVALANCHE
                    | SUPERPOWER
                    | STEALTH ROCK
                    | LOW KICK
                    | AQUA TAIL

    SWAMPERT    	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | EARTH POWER
                    | WORK UP
                    | AVALANCHE
                    | SUPERPOWER
                    | STEALTH ROCK
                    | BODY PRESS
                    | LOW KICK
                    | AQUA TAIL

    POOCHYENA   	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | NASTY PLOT

    MIGHTYENA   	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | NASTY PLOT

    ZIGZAGOON   	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | ICY WIND
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | WORK UP
                    | TRICK
                    | GUNK SHOT
                    | SEED BOMB

    LINOONE     	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | ICY WIND
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | WORK UP
                    | PLAY ROUGH
                    | TRICK
                    | GUNK SHOT
                    | SEED BOMB

    WURMPLE     	| SNORE
                    | BUG BITE

    SILCOON     	| BUG BITE

    BEAUTIFLY   	| DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SIGNAL BEAM
                    | DEFOG
                    | TAILWIND
                    | BUG BITE

    CASCOON     	| BUG BITE

    DUSTOX      	| DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SIGNAL BEAM
                    | DEFOG
                    | TAILWIND
                    | BUG BITE

    LOTAD       	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | ZEN HEADBUTT
                    | SEED BOMB

    LOMBRE      	| BODY SLAM
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | THUNDER PUNCH
                    | KNOCK OFF
                    | ZEN HEADBUTT
                    | SEED BOMB

    LUDICOLO    	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | ICY WIND
                    | METRONOME
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | THUNDER PUNCH
                    | KNOCK OFF
                    | ZEN HEADBUTT
                    | SEED BOMB

    SEEDOT      	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | EXPLOSION
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | NASTY PLOT
                    | WORRY SEED
                    | SEED BOMB
                    | FOUL PLAY
                    | HIDDEN THORNS

    NUZLEAF     	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | EXPLOSION
                    | FURY CUTTER
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | LOW SWEEP
                    | NASTY PLOT
                    | WORRY SEED
                    | LOW KICK
                    | SEED BOMB
                    | FOUL PLAY
                    | HIDDEN THORNS

    SHIFTRY     	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | EXPLOSION
                    | FURY CUTTER
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | LOW SWEEP
                    | NASTY PLOT
                    | DEFOG
                    | KNOCK OFF
                    | TAILWIND
                    | HEAT WAVE
                    | WORRY SEED
                    | LOW KICK
                    | SEED BOMB
                    | FOUL PLAY
                    | HIDDEN THORNS

    TAILLOW     	| COUNTER
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | WORK UP
                    | DEFOG
                    | TAILWIND
                    | HEAT WAVE

    SWELLOW     	| COUNTER
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | WORK UP
                    | DEFOG
                    | TAILWIND
                    | HEAT WAVE

    WINGULL     	| DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | DEFOG
                    | KNOCK OFF
                    | TAILWIND

    PELIPPER    	| DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | DEFOG
                    | KNOCK OFF
                    | TAILWIND
                    | GUNK SHOT
                    | SEED BOMB

    RALTS       	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | THUNDER PUNCH
                    | SIGNAL BEAM
                    | STORED POWER
                    | TRICK
                    | ZEN HEADBUTT
                    | RECYCLE
                    | MAGIC COAT
                    | PAIN SPLIT

    KIRLIA      	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | THUNDER PUNCH
                    | SIGNAL BEAM
                    | STORED POWER
                    | TRICK
                    | ZEN HEADBUTT
                    | RECYCLE
                    | MAGIC COAT
                    | PAIN SPLIT

    GARDEVOIR   	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | THUNDER PUNCH
                    | SIGNAL BEAM
                    | STORED POWER
                    | TRICK
                    | ZEN HEADBUTT
                    | RECYCLE
                    | MAGIC COAT
                    | PAIN SPLIT

    SURSKIT     	| DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SIGNAL BEAM
                    | BUG BITE

    MASQUERAIN  	| DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SIGNAL BEAM
                    | DEFOG
                    | TAILWIND
                    | FOUL PLAY
                    | BUG BITE

    SHROOMISH   	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | ZEN HEADBUTT
                    | GUNK SHOT
                    | SEED BOMB
                    | WORRY SEED

    BRELOOM     	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FURY CUTTER
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | THUNDER PUNCH
                    | LOW KICK
                    | SUPERPOWER
                    | ZEN HEADBUTT
                    | GUNK SHOT
                    | SEED BOMB
                    | WORK UP
                    | LOW SWEEP
                    | WORRY SEED

    SLAKOTH     	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | FURY CUTTER
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | ZEN HEADBUTT
                    | WORK UP
                    | GUNK SHOT

    VIGOROTH    	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | FURY CUTTER
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | LOW KICK
                    | ZEN HEADBUTT
                    | WORK UP
                    | LOW SWEEP
                    | GUNK SHOT

    SLAKING     	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | FURY CUTTER
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | BODY PRESS
                    | LOW KICK
                    | ZEN HEADBUTT
                    | WORK UP
                    | LOW SWEEP
                    | GUNK SHOT

    NINCADA     	| DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | BUG BITE

    NINJASK     	| DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | DEFOG
                    | BUG BITE

    SHEDINJA    	| DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | FURY CUTTER
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | TRICK
                    | PAIN SPLIT
                    | BUG BITE

    WHISMUR     	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | WORK UP
                    | ZEN HEADBUTT

    LOUDRED     	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | WORK UP
                    | ZEN HEADBUTT
                    | LOW KICK

    EXPLOUD     	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | WORK UP
                    | AVALANCHE
                    | ZEN HEADBUTT
                    | LOW KICK

    MAKUHITA    	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | METRONOME
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | BODY PRESS
                    | SUPERPOWER
                    | ZEN HEADBUTT
                    | LOW KICK
                    | WORK UP
                    | LOW SWEEP
                    | ROLE PLAY
                    | KNOCK OFF

    HARIYAMA    	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | METRONOME
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | BODY PRESS
                    | SUPERPOWER
                    | ZEN HEADBUTT
                    | LOW KICK
                    | WORK UP
                    | LOW SWEEP
                    | IRON HEAD
                    | ROLE PLAY
                    | KNOCK OFF

    AZURILL     	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | WORK UP
                    | KNOCK OFF

    NOSEPASS    	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | EXPLOSION
                    | FIRE PUNCH
                    | ICE PUNCH
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | EARTH POWER
                    | STEALTH ROCK
                    | BODY PRESS
                    | MAGIC COAT
                    | PAIN SPLIT

    SKITTY      	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | WORK UP
                    | NASTY PLOT

    DELCATTY    	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | WORK UP
                    | NASTY PLOT

    SABLEYE     	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DREAM EATER
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | FURY CUTTER
                    | ICE PUNCH
                    | ICY WIND
                    | METRONOME
                    | MIMIC
                    | PSYCH UP
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | LOW SWEEP
                    | SIGNAL BEAM
                    | NASTY PLOT
                    | ROLE PLAY
                    | TRICK
                    | KNOCK OFF
                    | ZEN HEADBUTT
                    | LOW KICK
                    | MAGIC COAT
                    | PAIN SPLIT
                    | FOUL PLAY

    MAWILE      	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | THUNDER PUNCH
                    | PSYCHIC FANGS
                    | PLAY ROUGH
                    | KNOCK OFF
                    | STEALTH ROCK
                    | PAIN SPLIT
                    | IRON HEAD
                    | FOUL PLAY

    ARON        	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | EARTH POWER
                    | SUPERPOWER
                    | STEALTH ROCK
                    | BODY PRESS
                    | IRON HEAD

    LAIRON      	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | EARTH POWER
                    | SUPERPOWER
                    | STEALTH ROCK
                    | BODY PRESS
                    | IRON HEAD

    AGGRON      	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | FURY CUTTER
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | FLINT BLADE
                    | EARTH POWER
                    | AVALANCHE
                    | SUPERPOWER
                    | STEALTH ROCK
                    | BODY PRESS
                    | LOW KICK
                    | IRON HEAD
                    | AQUA TAIL

    MEDITITE    	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DREAM EATER
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | METRONOME
                    | MIMIC
                    | PSYCH UP
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | THUNDER PUNCH
                    | LOW KICK
                    | ZEN HEADBUTT
                    | WORK UP
                    | LOW SWEEP
                    | SIGNAL BEAM
                    | ROLE PLAY
                    | RECYCLE
                    | MAGIC COAT
                    | PAIN SPLIT

    MEDICHAM    	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DREAM EATER
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | METRONOME
                    | MIMIC
                    | PSYCH UP
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | THUNDER PUNCH
                    | LOW KICK
                    | ZEN HEADBUTT
                    | WORK UP
                    | LOW SWEEP
                    | SIGNAL BEAM
                    | ROLE PLAY
                    | RECYCLE
                    | MAGIC COAT
                    | PAIN SPLIT

    ELECTRIKE   	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | PSYCHIC FANGS
                    | SIGNAL BEAM

    MANECTRIC   	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | BLAZE IMPACT
                    | PSYCHIC FANGS
                    | SIGNAL BEAM

    PLUSLE      	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | METRONOME
                    | MIMIC
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | THUNDER PUNCH
                    | SIGNAL BEAM
                    | NASTY PLOT

    MINUN       	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | METRONOME
                    | MIMIC
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | THUNDER PUNCH
                    | SIGNAL BEAM
                    | NASTY PLOT

    VOLBEAT     	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | ICE PUNCH
                    | METRONOME
                    | MIMIC
                    | PSYCH UP
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | THUNDER PUNCH
                    | SIGNAL BEAM
                    | TAILWIND
                    | BUG BITE

    ILLUMISE    	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | ICE PUNCH
                    | METRONOME
                    | MIMIC
                    | PSYCH UP
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | THUNDER PUNCH
                    | TAILWIND
                    | BUG BITE

    ROSELIA     	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | WORRY SEED
                    | SEED BOMB
                    | HIDDEN THORNS

    GULPIN      	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DREAM EATER
                    | DYNAMIC PUNCH
                    | ENDURE
                    | EXPLOSION
                    | FIRE PUNCH
                    | ICE PUNCH
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | GASTRO ACID
                    | SEED BOMB
                    | GUNK SHOT
                    | PAIN SPLIT

    SWALOT      	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DREAM EATER
                    | DYNAMIC PUNCH
                    | ENDURE
                    | EXPLOSION
                    | FIRE PUNCH
                    | ICE PUNCH
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | BODY PRESS
                    | ZEN HEADBUTT
                    | GASTRO ACID
                    | SEED BOMB
                    | GUNK SHOT
                    | PAIN SPLIT

    CARVANHA    	| DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | PSYCHIC FANGS
                    | ZEN HEADBUTT

    SHARPEDO    	| DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | PSYCHIC FANGS
                    | AVALANCHE
                    | ZEN HEADBUTT

    WAILMER     	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | AVALANCHE
                    | ZEN HEADBUTT
                    | BODY PRESS

    WAILORD     	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | AVALANCHE
                    | ZEN HEADBUTT
                    | BODY PRESS
                    | IRON HEAD

    NUMEL       	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | BODY PRESS
                    | ZEN HEADBUTT
                    | BLAZE IMPACT
                    | IRON HEAD
                    | EARTH POWER
                    | STEALTH ROCK

    CAMERUPT    	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | EXPLOSION
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | BODY PRESS
                    | ZEN HEADBUTT
                    | BLAZE IMPACT
                    | IRON HEAD
                    | EARTH POWER
                    | STEALTH ROCK

    TORKOAL     	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | EXPLOSION
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | ZEN HEADBUTT
                    | BLAZE IMPACT
                    | EARTH POWER
                    | SUPERPOWER
                    | STEALTH ROCK
                    | HEAT WAVE
                    | BODY PRESS

    SPOINK      	| BODY SLAM
                    | DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SIGNAL BEAM
                    | ZEN HEADBUTT
                    | ROLE PLAY
                    | RECYCLE
                    | MAGIC COAT

    GRUMPIG     	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DREAM EATER
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | EARTH POWER
                    | THUNDER PUNCH
                    | LOW KICK
                    | SIGNAL BEAM
                    | ZEN HEADBUTT
                    | NASTY PLOT
                    | SEED BOMB
                    | ROLE PLAY
                    | RECYCLE
                    | MAGIC COAT

    SPINDA      	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DREAM EATER
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | ICY WIND
                    | METRONOME
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | THUNDER PUNCH
                    | ZEN HEADBUTT
                    | WORK UP
                    | ROLE PLAY
                    | RECYCLE

    TRAPINCH    	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | EARTH POWER
                    | SIGNAL BEAM
                    | SUPERPOWER
                    | BUG BITE

    VIBRAVA     	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | EARTH POWER
                    | SIGNAL BEAM
                    | SUPERPOWER
                    | DEFOG
                    | TAILWIND
                    | HEAT WAVE
                    | DRACO METEOR
                    | BUG BITE

    FLYGON      	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | FIRE PUNCH
                    | FURY CUTTER
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | THUNDER PUNCH
                    | EARTH POWER
                    | BREAKING SWIPE
                    | SIGNAL BEAM
                    | SUPERPOWER
                    | DEFOG
                    | TAILWIND
                    | HEAT WAVE
                    | DRACO METEOR
                    | BUG BITE

    CACNEA      	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FURY CUTTER
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | THUNDER PUNCH
                    | LOW KICK
                    | NASTY PLOT
                    | FOUL PLAY
                    | SEED BOMB
                    | ROLE PLAY
                    | WORRY SEED
                    | HIDDEN THORNS

    CACTURNE    	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FURY CUTTER
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | THUNDER PUNCH
                    | LOW KICK
                    | NASTY PLOT
                    | SUPERPOWER
                    | ZEN HEADBUTT
                    | FOUL PLAY
                    | SEED BOMB
                    | ROLE PLAY
                    | WORRY SEED
                    | HIDDEN THORNS

    SWABLU      	| BODY SLAM
                    | DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | PLAY ROUGH
                    | TAILWIND
                    | HEAT WAVE

    ALTARIA     	| BODY SLAM
                    | DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | BREAKING SWIPE
                    | PLAY ROUGH
                    | TAILWIND
                    | HEAT WAVE
                    | DRACO METEOR

    ZANGOOSE    	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | FURY CUTTER
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | ZEN HEADBUTT
                    | GUNK SHOT
                    | SEED BOMB
                    | THUNDER PUNCH
                    | LOW KICK
                    | WORK UP
                    | KNOCK OFF

    SEVIPER     	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | SERPENT DANCE
                    | FLINT BLADE
                    | GASTRO ACID
                    | PSYCHIC FANGS
                    | BREAKING SWIPE
                    | ZEN HEADBUTT
                    | GUNK SHOT
                    | SEED BOMB
                    | KNOCK OFF
                    | AQUA TAIL

    LUNATONE    	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | EXPLOSION
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | EARTH POWER
                    | SIGNAL BEAM
                    | NASTY PLOT
                    | STORED POWER
                    | STEALTH ROCK
                    | ZEN HEADBUTT
                    | RECYCLE
                    | MAGIC COAT
                    | PAIN SPLIT
                    | IRON HEAD

    SOLROCK     	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | EXPLOSION
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | EARTH POWER
                    | SIGNAL BEAM
                    | STORED POWER
                    | STEALTH ROCK
                    | HEAT WAVE
                    | ZEN HEADBUTT
                    | RECYCLE
                    | MAGIC COAT
                    | PAIN SPLIT
                    | IRON HEAD

    BARBOACH    	| DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | EARTH POWER
                    | ZEN HEADBUTT
                    | AQUA TAIL

    WHISCASH    	| DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | EARTH POWER
                    | ZEN HEADBUTT
                    | AQUA TAIL

    CORPHISH    	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | SUPERPOWER
                    | KNOCK OFF

    CRAWDAUNT   	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | AVALANCHE
                    | NASTY PLOT
                    | SUPERPOWER
                    | KNOCK OFF

    BALTOY      	| DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | EXPLOSION
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | EARTH POWER
                    | SIGNAL BEAM
                    | TRICK
                    | STEALTH ROCK
                    | ZEN HEADBUTT
                    | RECYCLE
                    | MAGIC COAT

    CLAYDOL     	| DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | EXPLOSION
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | EARTH POWER
                    | SIGNAL BEAM
                    | NASTY PLOT
                    | STORED POWER
                    | TRICK
                    | STEALTH ROCK
                    | ZEN HEADBUTT
                    | BODY PRESS
                    | RECYCLE
                    | MAGIC COAT

    LILEEP      	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | GASTRO ACID
                    | EARTH POWER
                    | STEALTH ROCK
                    | WORRY SEED
                    | PAIN SPLIT
                    | SEED BOMB
                    | HIDDEN THORNS

    CRADILY     	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | GASTRO ACID
                    | EARTH POWER
                    | STEALTH ROCK
                    | WORRY SEED
                    | PAIN SPLIT
                    | SEED BOMB
                    | HIDDEN THORNS

    ANORITH     	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | FLINT BLADE
                    | EARTH POWER
                    | KNOCK OFF
                    | STEALTH ROCK
                    | BUG BITE

    ARMALDO     	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | MIMIC
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | FLINT BLADE
                    | EARTH POWER
                    | SUPERPOWER
                    | KNOCK OFF
                    | STEALTH ROCK
                    | LOW KICK
                    | AQUA TAIL
                    | BUG BITE

    FEEBAS      	| DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT

    MILOTIC     	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SERPENT DANCE
                    | BREAKING SWIPE
                    | AVALANCHE
                    | MAGIC COAT
                    | IRON HEAD
                    | AQUA TAIL

    CASTFORM    	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | WORK UP
                    | AVALANCHE
                    | TAILWIND

    KECLEON     	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | FURY CUTTER
                    | ICE PUNCH
                    | ICY WIND
                    | METRONOME
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | THUNDER PUNCH
                    | WORK UP
                    | NASTY PLOT
                    | ROLE PLAY
                    | KNOCK OFF
                    | STEALTH ROCK
                    | RECYCLE
                    | MAGIC COAT
                    | AQUA TAIL

    SHUPPET     	| BODY SLAM
                    | DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | ROLE PLAY
                    | KNOCK OFF
                    | FOUL PLAY
                    | GUNK SHOT
                    | MAGIC COAT
                    | NASTY PLOT
                    | PAIN SPLIT

    BANETTE     	| BODY SLAM
                    | DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | ICY WIND
                    | METRONOME
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | ROLE PLAY
                    | KNOCK OFF
                    | FOUL PLAY
                    | GUNK SHOT
                    | MAGIC COAT
                    | NASTY PLOT
                    | PAIN SPLIT

    DUSKULL     	| BODY SLAM
                    | DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | TRICK
                    | PAIN SPLIT

    DUSCLOPS    	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DREAM EATER
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | ICY WIND
                    | METRONOME
                    | MIMIC
                    | PSYCH UP
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | TRICK
                    | PAIN SPLIT

    TROPIUS     	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | DEFOG
                    | TAILWIND
                    | BODY PRESS
                    | ZEN HEADBUTT
                    | SEED BOMB
                    | WORRY SEED

    CHIMECHO    	| DEFENSE CURL
                    | DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SIGNAL BEAM
                    | KNOCK OFF
                    | RECYCLE
                    | MAGIC COAT

    ABSOL       	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | FURY CUTTER
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | BLAZE IMPACT
                    | FLINT BLADE
                    | PSYCHIC FANGS
                    | SUPERPOWER
                    | PLAY ROUGH
                    | ROLE PLAY
                    | KNOCK OFF
                    | ZEN HEADBUTT
                    | MAGIC COAT
                    | FOUL PLAY
                    | MEGAHORN

    WYNAUT      	| COUNTER

    SNORUNT     	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | AVALANCHE

    GLALIE      	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | EXPLOSION
                    | ICY WIND
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | AVALANCHE
                    | SIGNAL BEAM
                    | FOUL PLAY
                    | IRON HEAD

    SPHEAL      	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | AVALANCHE
                    | SIGNAL BEAM
                    | AQUA TAIL

    SEALEO      	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | AVALANCHE
                    | SIGNAL BEAM
                    | AQUA TAIL

    WALREIN     	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | ICY WIND
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | AVALANCHE
                    | SIGNAL BEAM
                    | BODY PRESS
                    | IRON HEAD
                    | AQUA TAIL

    CLAMPERL    	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER

    HUNTAIL     	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SERPENT DANCE
                    | AQUA TAIL

    GOREBYSS    	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SERPENT DANCE
                    | SIGNAL BEAM
                    | AQUA TAIL

    RELICANTH   	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | EARTH POWER
                    | STEALTH ROCK
                    | ZEN HEADBUTT
                    | BODY PRESS
                    | AQUA TAIL

    LUVDISC     	| DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT

    BAGON       	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | MIMIC
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | ZEN HEADBUTT
                    | IRON HEAD
                    | DRACO METEOR

    SHELGON     	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | ZEN HEADBUTT
                    | IRON HEAD
                    | DRACO METEOR

    SALAMENCE   	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | MIMIC
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | PSYCHIC FANGS
                    | BREAKING SWIPE
                    | DEFOG
                    | TAILWIND
                    | HEAT WAVE
                    | ZEN HEADBUTT
                    | IRON HEAD
                    | AQUA TAIL
                    | DRACO METEOR

    BELDUM        =	| 

    METANG      	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | EXPLOSION
                    | FURY CUTTER
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | THUNDER PUNCH
                    | SIGNAL BEAM
                    | TRICK
                    | STEALTH ROCK
                    | ZEN HEADBUTT
                    | IRON HEAD

    METAGROSS   	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | EXPLOSION
                    | FURY CUTTER
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | THUNDER PUNCH
                    | SIGNAL BEAM
                    | TRICK
                    | STEALTH ROCK
                    | ZEN HEADBUTT
                    | BODY PRESS
                    | IRON HEAD

    REGIROCK    	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | EXPLOSION
                    | FIRE PUNCH
                    | ICE PUNCH
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | EARTH POWER
                    | SUPERPOWER
                    | STEALTH ROCK
                    | BODY PRESS
                    | IRON HEAD

    REGICE      	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | EXPLOSION
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | AVALANCHE
                    | SIGNAL BEAM
                    | SUPERPOWER
                    | BODY PRESS
                    | IRON HEAD

    REGISTEEL   	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | EXPLOSION
                    | ICE PUNCH
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | SUPERPOWER
                    | STEALTH ROCK
                    | BODY PRESS
                    | IRON HEAD

    LATIAS      	| BODY SLAM
                    | DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | FURY CUTTER
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | BREAKING SWIPE
                    | STORED POWER
                    | ROLE PLAY
                    | DEFOG
                    | TRICK
                    | TAILWIND
                    | ZEN HEADBUTT
                    | MAGIC COAT
                    | DRACO METEOR

    LATIOS      	| BODY SLAM
                    | DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | FURY CUTTER
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | BREAKING SWIPE
                    | STORED POWER
                    | DEFOG
                    | TRICK
                    | TAILWIND
                    | ZEN HEADBUTT
                    | MAGIC COAT
                    | DRACO METEOR

    KYOGRE      	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | AVALANCHE
                    | SIGNAL BEAM
                    | IRON HEAD
                    | AQUA TAIL

    GROUDON     	| BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | FURY CUTTER
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | THUNDER PUNCH
                    | BODY PRESS
                    | ZEN HEADBUTT
                    | BLAZE IMPACT
                    | EARTH POWER
                    | STEALTH ROCK
                    | IRON HEAD

    RAYQUAZA    	| BODY SLAM
                    | DOUBLE EDGE
                    | ENDURE
                    | FURY CUTTER
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | SERPENT DANCE
                    | EARTH POWER
                    | BREAKING SWIPE
                    | AVALANCHE
                    | TAILWIND
                    | IRON HEAD
                    | AQUA TAIL
                    | DRACO METEOR

    JIRACHI     	| BODY SLAM
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DREAM EATER
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | ICY WIND
                    | METRONOME
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | THUNDER PUNCH
                    | SIGNAL BEAM
                    | PLAY ROUGH
                    | STORED POWER
                    | TRICK
                    | STEALTH ROCK
                    | ZEN HEADBUTT
                    | RECYCLE
                    | MAGIC COAT
                    | IRON HEAD

    DEOXYS      	| BODY SLAM
                    | COUNTER
                    | DOUBLE EDGE
                    | DREAM EATER
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | THUNDER PUNCH
                    | LOW SWEEP
                    | AVALANCHE
                    | SIGNAL BEAM
                    | NASTY PLOT
                    | ROLE PLAY
                    | SUPERPOWER
                    | KNOCK OFF
                    | STEALTH ROCK
                    | RECYCLE
                    | MAGIC COAT

    BUDEW           | ENDURE
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | WORRY SEED
                    | SEED BOMB
                    | HIDDEN THORNS

    ROSERADE        | ENDURE
                    | FURY CUTTER
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | WORRY SEED
                    | SEED BOMB
                    | HIDDEN THORNS

    AMBIPOM         | DREAM EATER
                    | ENDURE
                    | FIRE PUNCH
                    | FURY CUTTER
                    | ICE PUNCH
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | THUNDER PUNCH
                    | WORK UP
                    | LOW SWEEP
                    | NASTY PLOT
                    | ROLE PLAY
                    | KNOCK OFF

    MISMAGIUS       | DREAM EATER
                    | ENDURE
                    | ICY WIND
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | NASTY PLOT
                    | FOUL PLAY
                    | MAGIC COAT
                    | NASTY PLOT
                    | PAIN SPLIT

    HONCHKROW       | DREAM EATER
                    | ENDURE
                    | ICY WIND
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | NASTY PLOT
                    | FOUL PLAY
                    | DEFOG
                    | TAILWIND
                    | NASTY PLOT
                    | SUPERPOWER
                    | HEAT WAVE

    CHINGLING       | DREAM EATER
                    | ENDURE
                    | ICY WIND
                    | PSYCH UP
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SIGNAL BEAM
                    | KNOCK OFF
                    | RECYCLE
                    | MAGIC COAT

    BONSLY          | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | EXPLOSION
                    | MIMIC
                    | PSYCH UP
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | ROLE PLAY
                    | FOUL PLAY

    MIME JR         | DREAM EATER
                    | ENDURE
                    | ICY WIND
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SIGNAL BEAM
                    | NASTY PLOT
                    | STORED POWER
                    | ROLE PLAY
                    | TRICK
                    | RECYCLE
                    | MAGIC COAT

    HAPPINY         | COUNTER
                    | DREAM EATER
                    | ENDURE
                    | ICY WIND
                    | METRONOME
                    | PSYCH UP
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | WORK UP
                    | STORED POWER
                    | ZEN HEADBUTT
                    | RECYCLE

    MUNCHLAX        | BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | ICY WIND
                    | METRONOME
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | GASTRO ACID
                    | SUPERPOWER
                    | GUNK SHOT
                    | ZEN HEADBUTT
                    | RECYCLE
                    | SEED BOMB

    MANTYKE         | ENDURE
                    | ICY WIND
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SIGNAL BEAM
                    | TAILWIND

    WEAVILE         | DREAM EATER
                    | ENDURE
                    | FURY CUTTER
                    | ICE PUNCH
                    | ICY WIND
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | LOW SWEEP
                    | AVALANCHE
                    | NASTY PLOT
                    | KNOCK OFF
                    | LOW KICK
                    | FOUL PLAY

    MAGNEZONE       | ENDURE
                    | EXPLOSION
                    | PSYCH UP
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SIGNAL BEAM
                    | BODY PRESS
                    | RECYCLE
                    | MAGIC COAT
                    | IRON HEAD

    LICKILICKY      | DEFENSE CURL
                    | DREAM EATER
                    | ENDURE
                    | EXPLOSION
                    | FIRE PUNCH
                    | ICE PUNCH
                    | ICY WIND
                    | PSYCH UP
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | THUNDER PUNCH
                    | WORK UP
                    | KNOCK OFF
                    | ZEN HEADBUTT
                    | BODY PRESS
                    | AQUA TAIL

    RHYPERIOR       | ENDURE
                    | FIRE PUNCH
                    | FURY CUTTER
                    | ICE PUNCH
                    | ICY WIND
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | THUNDER PUNCH
                    | EARTH POWER
                    | BREAKING SWIPE
                    | AVALANCHE
                    | SUPERPOWER
                    | STEALTH ROCK
                    | BODY PRESS
                    | IRON HEAD
                    | AQUA TAIL
                    | MEGAHORN

    TANGROWTH       | ENDURE
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWORDS DANCE
                    | KNOCK OFF
                    | BODY PRESS
                    | WORRY SEED
                    | PAIN SPLIT
                    | SEED BOMB
                    | HIDDEN THORNS

    ELECTIVIRE      | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | THUNDER PUNCH
                    | LOW SWEEP
                    | SIGNAL BEAM
                    | LOW KICK

    MAGMORTAR       | ENDURE
                    | FIRE PUNCH
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | LOW SWEEP
                    | HEAT WAVE
                    | LOW KICK

    TOGEKISS        | DREAM EATER
                    | ENDURE
                    | PSYCH UP
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | WORK UP
                    | SIGNAL BEAM
                    | NASTY PLOT
                    | PLAY ROUGH
                    | STORED POWER
                    | DEFOG
                    | TRICK
                    | TAILWIND
                    | HEAT WAVE
                    | ZEN HEADBUTT
                    | MAGIC COAT

    YANMEGA         | DREAM EATER
                    | ENDURE
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SIGNAL BEAM
                    | DEFOG
                    | TAILWIND
                    | BUG BITE

    LEAFEON         | ENDURE
                    | FURY CUTTER
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | FLINT BLADE
                    | WORK UP
                    | STORED POWER
                    | KNOCK OFF
                    | WORRY SEED
                    | SEED BOMB
                    | HIDDEN THORNS

    GLACEON         | ENDURE
                    | ICY WIND
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | WORK UP
                    | AVALANCHE
                    | SIGNAL BEAM
                    | STORED POWER
                    | AQUA TAIL

    GLISCOR         | ENDURE
                    | FURY CUTTER
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | DEFOG
                    | KNOCK OFF
                    | STEALTH ROCK
                    | TAILWIND
                    | AQUA TAIL
                    | BUG BITE

    MAMOSWINE       | ENDURE
                    | ICY WIND
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | EARTH POWER
                    | AVALANCHE
                    | SUPERPOWER
                    | KNOCK OFF
                    | STEALTH ROCK
                    | SUPERPOWER
                    | BODY PRESS
                    | IRON HEAD

    PORYGON Z       | DREAM EATER
                    | ENDURE
                    | ICY WIND
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SIGNAL BEAM
                    | NASTY PLOT
                    | TRICK
                    | ZEN HEADBUTT
                    | RECYCLE
                    | MAGIC COAT
                    | PAIN SPLIT
                    | FOUL PLAY

    GALLADE         | DREAM EATER
                    | ENDURE
                    | FIRE PUNCH
                    | FURY CUTTER
                    | ICE PUNCH
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | THUNDER PUNCH
                    | WORK UP
                    | LOW SWEEP
                    | SIGNAL BEAM
                    | STORED POWER
                    | KNOCK OFF
                    | ZEN HEADBUTT
                    | RECYCLE
                    | LOW KICK
                    | MAGIC COAT
                    | PAIN SPLIT
                    | FLINT BLADE

    PROBOPASS       | ENDURE
                    | EXPLOSION
                    | FIRE PUNCH
                    | ICE PUNCH
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | EARTH POWER
                    | STEALTH ROCK
                    | BODY PRESS
                    | MAGIC COAT
                    | PAIN SPLIT

    DUSKNOIR        | DREAM EATER
                    | ENDURE
                    | FIRE PUNCH
                    | ICE PUNCH
                    | ICY WIND
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | THUNDER PUNCH
                    | TRICK
                    | PAIN SPLIT

    FROSLASS        | DREAM EATER
                    | ENDURE
                    | ICE PUNCH
                    | ICY WIND
                    | PSYCH UP
                    | ROLLOUT
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | AVALANCHE
                    | SIGNAL BEAM
                    | TRICK
                    | PAIN SPLIT

    SYLVEON         | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | WORK UP
                    | PLAY ROUGH
                    | STORED POWER

    RATTATA ALOLAN    | SWORDS DANCE
                      | BODY SLAM
                      | DOUBLE EDGE
                      | COUNTER
                      | MIMIC
                      | SUBSTITUTE
                      | SNORE
                      | ICY WIND
                      | SWAGGER
                      | SLEEP TALK
                      | ZEN HEADBUTT

    RATICATE ALOLAN   | SWORDS DANCE
                      | BODY SLAM
                      | DOUBLE EDGE
                      | COUNTER
                      | MIMIC
                      | SUBSTITUTE
                      | SNORE
                      | ICY WIND
                      | SWAGGER
                      | SLEEP TALK
                      | KNOCK OFF
                      | ZEN HEADBUTT

    RAICHU ALOLAN     | BODY SLAM
                      | SEISMIC TOSS
                      | MIMIC
                      | SUBSTITUTE
                      | DYNAMIC PUNCH
                      | SNORE
                      | SLEEP TALK
                      | SWIFT
                      | THUNDER PUNCH
                      | SIGNAL BEAM
                      | NASTY PLOT
                      | PLAY ROUGH
                      | STORED POWER
                      | KNOCK OFF
                      | RECYCLE
                      | MAGIC COAT

    SANDSHREW ALOLAN  | SWORDS DANCE
                      | BODY SLAM
                      | COUNTER
                      | SEISMIC TOSS
                      | MIMIC
                      | SUBSTITUTE
                      | DYNAMIC PUNCH
                      | ROLLOUT
                      | SNORE
                      | ICY WIND
                      | ENDURE
                      | ICE PUNCH
                      | SLEEP TALK
                      | SWIFT
                      | DEFENSE CURL
                      | FURY CUTTER
                      | WORK UP
                      | AVALANCHE
                      | KNOCK OFF
                      | STEALTH ROCK
                      | IRON HEAD
                      | AQUA TAIL

    SANDSLASH ALOLAN  | SWORDS DANCE
                      | BODY SLAM
                      | COUNTER
                      | SEISMIC TOSS
                      | MIMIC
                      | SUBSTITUTE
                      | DYNAMIC PUNCH
                      | ROLLOUT
                      | SNORE
                      | ICY WIND
                      | ENDURE
                      | ICE PUNCH
                      | SLEEP TALK
                      | SWIFT
                      | DEFENSE CURL
                      | FURY CUTTER
                      | WORK UP
                      | AVALANCHE
                      | KNOCK OFF
                      | STEALTH ROCK
                      | IRON HEAD
                      | AQUA TAIL

    VULPIX ALOLAN     | BODY SLAM
                      | DOUBLE EDGE
                      | ENDURE
                      | MIMIC
                      | PSYCH UP
                      | SLEEP TALK
                      | SNORE
                      | ICY WIND
                      | SUBSTITUTE
                      | SWAGGER
                      | SWIFT
                      | NASTY PLOT
                      | ROLE PLAY
                      | ZEN HEADBUTT
                      | PAIN SPLIT
                      | FOUL PLAY
                      | AVALANCHE
                      | AQUA TAIL

    NINETALES ALOLAN  | BODY SLAM
                      | DOUBLE EDGE
                      | ENDURE
                      | MIMIC
                      | DREAM EATER
                      | PSYCH UP
                      | SLEEP TALK
                      | SNORE
                      | ICY WIND
                      | SUBSTITUTE
                      | SWAGGER
                      | SWIFT
                      | NASTY PLOT
                      | STORED POWER
                      | ROLE PLAY
                      | ZEN HEADBUTT
                      | PAIN SPLIT
                      | FOUL PLAY
                      | AVALANCHE
                      | AQUA TAIL

    GEODUDE ALOLAN    | DOUBLE EDGE
                      | COUNTER
                      | SEISMIC TOSS
                      | MIMIC
                      | METRONOME
                      | EXPLOSION
                      | SUBSTITUTE
                      | DYNAMIC PUNCH
                      | ROLLOUT
                      | SNORE
                      | ENDURE
                      | EARTH POWER
                      | SLEEP TALK
                      | DEFENSE CURL
                      | THUNDER PUNCH
                      | FIRE PUNCH
                      | SUPERPOWER
                      | STEALTH ROCK
                      | IRON HEAD

    GRAVELER ALOLAN   | DOUBLE EDGE
                      | COUNTER
                      | SEISMIC TOSS
                      | MIMIC
                      | METRONOME
                      | EXPLOSION
                      | SUBSTITUTE
                      | DYNAMIC PUNCH
                      | ROLLOUT
                      | SNORE
                      | ENDURE
                      | EARTH POWER
                      | SLEEP TALK
                      | DEFENSE CURL
                      | THUNDER PUNCH
                      | FIRE PUNCH
                      | SUPERPOWER
                      | STEALTH ROCK
                      | IRON HEAD

    GOLEM ALOLAN      | DOUBLE EDGE
                      | COUNTER
                      | SEISMIC TOSS
                      | MIMIC
                      | METRONOME
                      | EXPLOSION
                      | SUBSTITUTE
                      | DYNAMIC PUNCH
                      | ROLLOUT
                      | SNORE
                      | ENDURE
                      | EARTH POWER
                      | SLEEP TALK
                      | DEFENSE CURL
                      | THUNDER PUNCH
                      | FIRE PUNCH
                      | SUPERPOWER
                      | STEALTH ROCK
                      | IRON HEAD

    GRIMER ALOLAN     | COUNTER
                      | MIMIC
                      | GASTRO ACID
                      | EXPLOSION
                      | SUBSTITUTE
                      | DYNAMIC PUNCH
                      | SNORE
                      | ICE PUNCH
                      | SLEEP TALK
                      | THUNDER PUNCH
                      | FIRE PUNCH
                      | KNOCK OFF
                      | GUNK SHOT
                      | RECYCLE
                      | PAIN SPLIT
                      | FOUL PLAY

    MUK ALOLAN        | COUNTER
                      | MIMIC
                      | GASTRO ACID
                      | EXPLOSION
                      | SUBSTITUTE
                      | DYNAMIC PUNCH
                      | SNORE
                      | ICE PUNCH
                      | SLEEP TALK
                      | THUNDER PUNCH
                      | FIRE PUNCH
                      | KNOCK OFF
                      | GUNK SHOT
                      | RECYCLE
                      | PAIN SPLIT
                      | FOUL PLAY

    DIGLETT ALOLAN    | BODY SLAM
                      | MIMIC
                      | SUBSTITUTE
                      | SNORE
                      | ENDURE
                      | EARTH POWER
                      | FOUL PLAY
                      | SLEEP TALK
                      | WORK UP
                      | STEALTH ROCK
                      | IRON HEAD

    DUGTRIO ALOLAN    | BODY SLAM
                      | MIMIC
                      | SUBSTITUTE
                      | SNORE
                      | ENDURE
                      | EARTH POWER
                      | FOUL PLAY
                      | SLEEP TALK
                      | WORK UP
                      | STEALTH ROCK
                      | IRON HEAD

    MEOWTH ALOLAN     | BODY SLAM
                      | MIMIC
                      | DREAM EATER
                      | SUBSTITUTE
                      | PSYCH UP
                      | ICY WIND
                      | SNORE
                      | SWAGGER
                      | SLEEP TALK
                      | SWIFT
                      | WORK UP
                      | NASTY PLOT
                      | PLAY ROUGH
                      | KNOCK OFF
                      | GUNK SHOT
                      | SEED BOMB
                      | FOUL PLAY

    PERSIAN ALOLAN    | BODY SLAM
                      | MIMIC
                      | DREAM EATER
                      | SUBSTITUTE
                      | PSYCH UP
                      | ICY WIND
                      | SNORE
                      | SWAGGER
                      | SLEEP TALK
                      | SWIFT
                      | WORK UP
                      | NASTY PLOT
                      | PLAY ROUGH
                      | KNOCK OFF
                      | GUNK SHOT
                      | SEED BOMB
                      | FOUL PLAY

    EXEGGUTOR ALOLAN  | SWORDS DANCE
                      | MIMIC
                      | DREAM EATER
                      | EXPLOSION
                      | SUBSTITUTE
                      | PSYCH UP
                      | SNORE
                      | SLEEP TALK
                      | SUPERPOWER
                      | KNOCK OFF
                      | HIDDEN THORNS
                      | BREAKING SWIPE
                      | ZEN HEADBUTT
                      | WORRY SEED
                      | LOW KICK
                      | SEED BOMB
                      | IRON HEAD
                      | DRACO METEOR

    MAROWAK ALOLAN    | SWORDS DANCE
                      | BODY SLAM
                      | DOUBLE EDGE
                      | SEISMIC TOSS
                      | MIMIC
                      | SUBSTITUTE
                      | DYNAMIC PUNCH
                      | ICY WIND
                      | AQUA TAIL
                      | SNORE
                      | EARTH POWER
                      | SLEEP TALK
                      | SWIFT
                      | THUNDER PUNCH
                      | FIRE PUNCH
                      | KNOCK OFF
                      | STEALTH ROCK
                      | HEAT WAVE
                      | LOW KICK
                      | PAIN SPLIT
                      | IRON HEAD

    PONYTA GALARIAN   | BODY SLAM
                      | DOUBLE EDGE
                      | ENDURE
                      | SLEEP TALK
                      | SNORE
                      | SUBSTITUTE
                      | SWIFT
                      | MIMIC
                      | SWAGGER
                      | PLAY ROUGH
                      | ZEN HEADBUTT
                      | LOW KICK

    RAPIDASH GALARIAN | BODY SLAM
                      | ENDURE
                      | SLEEP TALK
                      | SNORE
                      | SUBSTITUTE
                      | SWIFT
                      | MIMIC
                      | SWORDS DANCE
                      | SWAGGER
                      | PLAY ROUGH
                      | ZEN HEADBUTT
                      | LOW KICK
                      | MEGAHORN

    SLOWPOKE GALARIAN | BODY SLAM
                      | ENDURE
                      | ICY WIND
                      | PSYCH UP
                      | SLEEP TALK
                      | SNORE
                      | SUBSTITUTE
                      | SWIFT
                      | MIMIC
                      | MAGIC COAT
                      | AVALANCHE
                      | SIGNAL BEAM
                      | TRICK
                      | STORED POWER
                      | ZEN HEADBUTT
                      | FOUL PLAY
                      | RECYCLE

    SLOWBRO GALARIAN  | BODY SLAM
                      | ENDURE
                      | ICE PUNCH
                      | ICY WIND
                      | PSYCH UP
                      | SLEEP TALK
                      | SNORE
                      | SUBSTITUTE
                      | SWIFT
                      | MIMIC
                      | MAGIC COAT
                      | SIGNAL BEAM
                      | TRICK
                      | STORED POWER
                      | ZEN HEADBUTT
                      | FOUL PLAY
                      | BODY PRESS
                      | NASTY PLOT
                      | ICE PUNCH
                      | AVALANCHE
                      | COUNTER
                      | DYNAMIC PUNCH
                      | DREAM EATER
                      | RECYCLE
                      | BODY PRESS
                      | SEISMIC TOSS
                      | GASTRO ACID

    WEEZING GALARIAN  | ENDURE
                      | EXPLOSION
                      | SLEEP TALK
                      | SNORE
                      | SUBSTITUTE
                      | HEAT WAVE
                      | PLAY ROUGH
                      | SWAGGER
                      | PAIN SPLIT
                      | MIMIC
                      | DEFOG
                      | GASTRO ACID
                      | GUNK SHOT

    SLOWKING GALARIAN | BODY SLAM
                      | ENDURE
                      | ICE PUNCH
                      | ICY WIND
                      | PSYCH UP
                      | SLEEP TALK
                      | SNORE
                      | SUBSTITUTE
                      | SWAGGER
                      | SWIFT
                      | MIMIC
                      | MAGIC COAT
                      | SIGNAL BEAM
                      | TRICK
                      | STORED POWER
                      | ZEN HEADBUTT
                      | FOUL PLAY
                      | BODY PRESS
                      | NASTY PLOT
                      | ICE PUNCH
                      | AVALANCHE
                      | COUNTER
                      | DYNAMIC PUNCH
                      | DREAM EATER
                      | RECYCLE
                      | SEISMIC TOSS
                      | GASTRO ACID

    GROWLITHE HISUIAN | BODY SLAM
                      | DOUBLE EDGE
                      | ENDURE
                      | MIMIC
                      | SLEEP TALK
                      | SNORE
                      | SUBSTITUTE
                      | SWAGGER
                      | SWIFT
                      | BLAZE IMPACT
                      | PSYCHIC FANGS
                      | PLAY ROUGH
                      | STEALTH ROCK
                      | HEAT WAVE

    ARCANINE HISUIAN  | BODY SLAM
                      | DOUBLE EDGE
                      | ENDURE
                      | MIMIC
                      | SLEEP TALK
                      | SNORE
                      | SUBSTITUTE
                      | SWAGGER
                      | SWIFT
                      | BLAZE IMPACT
                      | PSYCHIC FANGS
                      | SUPERPOWER
                      | PLAY ROUGH
                      | STEALTH ROCK
                      | HEAT WAVE
                      | IRON HEAD

    VOLTORB HISUIAN   | ENDURE
                      | EXPLOSION
                      | MIMIC
                      | ROLLOUT
                      | SLEEP TALK
                      | SNORE
                      | SUBSTITUTE
                      | SWAGGER
                      | SWIFT
                      | SIGNAL BEAM
                      | MAGIC COAT
                      | HIDDEN THORNS
                      | SEED BOMB
                      | FOUL PLAY

    ELECTRODE HISUIAN | ENDURE
                      | EXPLOSION
                      | MIMIC
                      | ROLLOUT
                      | SLEEP TALK
                      | SNORE
                      | SUBSTITUTE
                      | SWAGGER
                      | SWIFT
                      | SIGNAL BEAM
                      | WORRY SEED
                      | MAGIC COAT
                      | HIDDEN THORNS
                      | SEED BOMB
                      | FOUL PLAY

    WYRDEER         | BODY SLAM
                    | DOUBLE EDGE
                    | DREAM EATER
                    | ENDURE
                    | MIMIC
                    | PSYCH UP
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | WORK UP
                    | SIGNAL BEAM
                    | ROLE PLAY
                    | ZEN HEADBUTT

    KLEAVOR         | COUNTER
                    | DOUBLE_EDGE
                    | ENDURE
                    | FURY_CUTTER
                    | MIMIC
                    | SLEEP_TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS_DANCE
                    | DEFOG
                    | KNOCK_OFF
                    | TAILWIND
                    | BUG_BITE
                    | FLINT_BLADE

    URSALUNA        | BODY SLAM
                    | COUNTER
                    | DEFENSE CURL
                    | DOUBLE EDGE
                    | DYNAMIC PUNCH
                    | ENDURE
                    | FIRE PUNCH
                    | FURY CUTTER
                    | ICE PUNCH
                    | METRONOME
                    | MIMIC
                    | ROLLOUT
                    | SEISMIC TOSS
                    | SLEEP TALK
                    | SNORE
                    | SUBSTITUTE
                    | SWAGGER
                    | SWIFT
                    | SWORDS DANCE
                    | SUPERPOWER
                    | LOW KICK
                    | SEED BOMB
                    | THUNDER PUNCH
                    | WORK UP
                    | PLAY ROUGH
                    | AVALANCHE
                    | GUNK SHOT

    TYPHLOSION HISUIAN  | BODY SLAM
                        | COUNTER
                        | DEFENSE CURL
                        | DOUBLE EDGE
                        | DYNAMIC PUNCH
                        | ENDURE
                        | FIRE PUNCH
                        | FURY CUTTER
                        | MIMIC
                        | ROLLOUT
                        | SEISMIC TOSS
                        | SLEEP TALK
                        | SNORE
                        | SUBSTITUTE
                        | SWAGGER
                        | SWIFT
                        | THUNDER PUNCH
                        | LOW KICK
                        | IRON HEAD
                        | BLAZE IMPACT
                        | ZEN HEADBUTT
                        | WORK UP
