Thank you for downloading Pokemon Valiant Beta 3!

Apply the patch onto a clean Pokemon Emerald (Trashman), 
using a rom patcher.

Online patching tool: https://www.marcrobledo.com/RomPatcher.js/

The demo is roughly 6-10 hours,
has 6 gyms,
and ends at HARUTEL CITY.

If you want to leave feedback or report bugs,
the best place for that will be the discord server:
https://discord.gg/wcEwv9bytW

Best regards,
Shahar