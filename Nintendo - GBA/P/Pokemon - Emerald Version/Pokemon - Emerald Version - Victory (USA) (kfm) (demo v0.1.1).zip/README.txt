*** Pokemon Victory demo v0.1.1 ***

To play the game, first find yourself a Pokémon Emerald ROM file (CRC32: 1f1c08fb).
Then use an online ROM patcher to patch the .bps file you downloaded onto the Pokémon Emerald ROM file. I like using https://www.marcrobledo.com/RomPatcher.js/ , but any patcher will work.
Once you have your patched ROM file, run it using a GBA emulator. I strongly recommend mGBA, as that's what the game has been tested and developed with.

If you find any bugs or just want to let me know what you thought, don't hesitate to send a Discord DM to kfmx or an email to kfmxdev@gmail.com.


I hope you enjoy:)


CHANGELOG FOR v0.1.1:

Bugfixes
	- caught wild Pokémon no longer turn into Bad Eggs after the player has participated in a double battle
	- Pokémon that require several trackable evolution requirements to evolve now work correctly
		- of note: Tyrogue's evolutions now check their requirements correctly
	- wild Pokémon now correctly have their highest available abilities
		- of note: the three overworld Venomoths now correctly have their Powder Scatter ability, instead of Fluffy
	- following Pokémon now properly go back inside their Pokéball after using Vine Whip
	- the first Pokémon sent out by opponents in battle is now always recorded as seen in the Pokédex
	- a Pokémon's name is now correctly displayed when asked to catch a Pokémon fainted via Leech Seed
	- traded Pokémon now always have a valid ability
	- unlocking new abilities during battle now correctly displays the ability name instead of a number
	- the ability Last Stand no longer activates from passive damage
	- the ability Last Stand no longer activates if the user has already used a move that turn
	- the ability description of Last Stand is no longer too long
	- the ability Triage now properly works with Grass Resonance
	- the ability message of Sanguivorous now correctly displays when triggered after the player has failed to run from a battle
	- the move Thunder Wave can no longer trigger the message "It's super effective!"
	- Water Resonance now correctly checks the user's type when trying to apply Wet
	- the Evolution menu now only shows sprites of evolutions when it's supposed to
	- reimplemented the move Aurora Beam as it had accidentally been removed
	- Low Sweep is now correctly treated as a kicking move
	- the third battle against Amy is now correctly hidden after beating the third Gym Leader
	- Ranger Jenna now uses correctly leveled Pokémon in her multi-battle
	- an NPC in Rotessy Town House 3 now correctly turns to face the player when talked to
	- Professor Bristle now correctly turns to face the player when giving them another Pokéball
	- it is now correctly possible to fish in the water at the elevated position in Mt. Lave
	- the item ball in the first floor of Ironspire Ridge now correctly contains its evolution item
	- removed the incorrect arrow tiles in Mt. Lave
	- corrected some incorrect grass tiles outside the Ranger Outpost
	- corrected an incorrect tile on Route 10
	- corrected some sand tiles in Desert Passage
	- corrected the z-index of the little bush sprites in Gladsome Glades
	- Lucy now correctly reveals the levels of her Pokémon as 26, not 32
	- fixed a spelling mistake in Amy's text in Riverhaven
	- fixed a spelling mistake in Ivysaur's text in the Flower Shop
	- fixed a spelling mistake in the fisherman's text in the Route 5 House
	- corrected the capitalization of the text "Someone'S PC" to "Someone's PC"
	- the HM for Vine Whip now correctly always displays as HM05, not HM09
	- added missing quotation marks around the quote on the sign in Rotessy Town


Pokémon Changes
	- Taillow now learns its first new abilities at level 15 and 20, down from 20 and 25 respectively
	- Trapinch now correctly evolves when following the player in a Sandstorm
	- Squirtle now correctly evolves at level 13, not 16
	- Sandshrew now correctly evolves at level 23, not 25
	- Geodude now correctly evolves at level 21, not 26
	- Snubbull now evolves at level 24, not 27
	- Ralts now correctly evolves at level 27, not 30
	- Sandile now correctly evolves at level 22, not 25
	- Teddiursa now correctly requires the Honey item to evolve
	- Ekans's stats have been improved:
			 HP  ATK DEF SPA SPD SPE
		OLD: 40  59  40  45  40  46
		NEW: 40  59  50  45  50  66
	- Chikorita, Bayleef, and Meganium now learn Sweet Scent instead of Magical Leaf at level 14
	- Chikorita now correctly learns Magical Leaf upon evolving
	- Charmander now correctly learns Dragon Breath upon evolving
	- Mudkip now correctly learns Mud Shot upon evolving
	- Ledyba now learns Reflect at level 13, Comet Punch at level 25, and Psybeam at level 26
	- Spinarak now learns Absorb instead of Bug Bite at level 1, and Bug Bite instead of Constrict at level 6
	- Poochyena now learns Taunt at level 22 instead of level 23
	- Lotad now learns Mega Drain at level 23 instead of level 29
	- Lombre now learns Mega Drain at level 23 and Wake-Up Slap at level 29
	- Seedot now correctly learns Grass Whistle at level 22
	- Nuzleaf now correctly learns Razor Leaf at level 20, and learns Knock Off at level 24 instead of level 23
	- Taillow now learns Natural Gife at level 14 instead of level 15
	- Goldeen now learns Flip Turn instead of Captivate at level 25
	

Other Changes
	- the Exp. Store now clearly states how much experience it stores
	- the Exp. Store now stores the leftover experience from when a mon reaches the level cap
	- the Exp. Store no longer grants 150% experience when a Pokémon is not level capped (100% to the Pokémon and 50% to the Exp. Store)
		- the Exp. Store now grants 100% experience when a Pokémon is not level capped (75% to the Pokémon and 25% to the Exp. Store)
	- increased experience gained by roughly 50% across the board (since the Exp. Store now technically gives less experience)
	- the Dex menu now shows both the current and maximum HP of Pokémon
	- when fishing, wild Pokémon now bite 100% of the time
	- when fishing, players no longer need to time a button press to hook a wild Pokémon
	- the item Poké Doll has been removed from the Pickup table and replaced with Oran Berry
	- flinching can no longer stop the Volatile ability from triggering
	- changed the ability description of Guts to "Ups Attack if statused.", not "Ups Attack if suffering."
	- changed the move Constrict to 40 base power and a secondary effect of lowering speed by 1 stage
	- evolutions can no longer be cancelled once started
	- traded Pokémon no longer gain boosted experience
	- replaced Flittle with Sandile as a wild encounter in the Kulho Desert
	- changed the ladder puzzle in Ironspire Ridge (it should now be a bit easier to stumble upon the solution)
	- removed cases where overworld Pokémon would continue their animations after being interacted with
	- the cuttable tree behind the lost Pokémon in Avana Woods is moved down 1 tile
	- the item ball containing Teal Fur on Route 10 is moved up 1 tile
	- removed the questionnaire from Pokémarts
	- reduced the level of the overworld Farfetch'd in Verdanoak City to 20, down from 25
	- removed the status-preferring AI from the battle against Gym Leader Tessa
	- removed the prediction AI from the battle against Developer kfm
	- the Scientist NPC that hands out the Exp. Store now explains that players can check how much experience it currently contains
	- changed the text of an NPC in Rotessy Town House 2 to explain that abilities can be changed in the party menu
	- changed the text of an NPC in Lamina Town to hint towards the fact that there are no hidden items in the game
