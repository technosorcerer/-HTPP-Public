The names of the patches are of the ROMs that I
have used. Also, to make it easier, just click
ignore when patching.