How to patch the ROM:

1) Get an unmodified ROM of: Pokemon - Emerald Version (USA, Europe).
2) Use a web patcher (https://www.marcrobledo.com/RomPatcher.js).
3) Select the ROM file (.gba) and the Patch file (.bps).
4) Apply the patch.


It's recommended to play on mGBA (PC) as other emulators may cause unexpected issues. mGBA can be downloaded for free at: https://mgba.io
