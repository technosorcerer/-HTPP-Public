Emerald - Lotad Stack

When the there are multiple Lotad in your party, and you send out a Lotad, it will stack with other Lotad in your party.

Stack setup:
- The maximum stack size is 3. More than 4 Lotad in your party results in multiple Lotad Stacks.
- The stacks are determined at the start of the battle.
- Single battle: The first 3 alive Lotad are stack 1, the remaining Lotad are stack 2.
- Double battle: Lotad get equally divided across 2 stacks by alternating between putting Lotad in stack 1 and in stack 2.

Stack mechanics:
- Lotad Stacks takes 50% as if it is getting hit by a spread move in a double battle.
- Lotad Stacks use the selected attack once for each Lotad in the stack (spread moves only hit one target on consequent hits).
- The HP and status conditions get synced between Lotad in a stack.
- You can't switch a Lotad out for another one of the same stack.
