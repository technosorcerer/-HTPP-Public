--------------------------------------------------------
Thank you for downloading Pokémon Darkfire Beta 0.2.1.2!
--------------------------------------------------------

IMPORTANT: Before you start, make sure you have a 1986 - Pokemon Emerald (U)(TrashMan) ROM.

This is not included for legal reasons.

To apply the patch, we recommend using RomPatcher.js.

HOW TO PATCH:
Step 1: Go to https://www.marcrobledo.com/RomPatcher.js/
Step 2: In the ROM file box, click & select your 1986 - Pokemon Emerald (U)(TrashMan) ROM
Step 3: In the patch file box, select your darkfire.ups patch that you just downloaded

Then click 'Apply patch' and it's done!

Now, simply open your ROM in an emulator (we highly recommend mGBA) and enjoy Pokémon Darkfire!

-------------------------------------------------------

If you'd like to support us, or stay up to date with the game's development, please visit:

KO-FI: ko-fi.com/karl_gba
DISCORD: discord.gg/3JSSNbw

Thank you <3
~Karl & Ray




