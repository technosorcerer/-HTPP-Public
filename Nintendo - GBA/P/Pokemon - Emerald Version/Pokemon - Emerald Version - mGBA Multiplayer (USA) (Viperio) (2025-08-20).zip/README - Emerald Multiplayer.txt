Emerald - Multiplayer

How to play Emerald Multiplayer:
1- Apply the .xdelta patch to a legally acquired ROM of Pokémon Emerald (for example, using https://www.marcrobledo.com/RomPatcher.js/).
2- Copy the patched ROM so you have a P1 game and a P2 game.
3- Launch mGBA, start P1 game.
4- Under mGBA Menu, File -> New Multiplayer Window, launch P2 game.
5- Under Tools -> Settings, set up the controls for both games. Use the keyboard for P1 and a controller for P2.
6- If you talk to the same trainer and say YES to battling with another trainer, you will connect and start a link multi battle!
7- OPTIONAL: You can use a remote control tool such as Chrome Remote Desktop to let someone from another device control P1 with their keyboard.

[Emerald - Multiplayer.xdelta] VS [Emerald Expansion - Multiplayer.xdelta]
The regular version uses vanilla Pokemon Emerald as a base, while the expansion version uses pokeemerald-expansion (credits to pret and RHH) as a base. This makes it so the expansion version has updated mechanics from later games such as new Pokemon, updated battle mechanics, and overworld following Pokemon.

Randomizer:
Open the start menu, select OPTION, and then select RANDOMIZER. This opens the randomizer settings.
For each setting you can select NO (no randomization) or YES (full randomization). Some settings also have a special third option:
- SMLR BST: Trainer or wild Pokémon will be randomized into a Pokémon with a similar BST to the BST of the original Pokémon.
- LEGENDARY: Legendary Pokémon will be randomized into another legendary Pokémon.
- 3 STAGE: Starter Pokémon will be randomized into other first stage Pokémon that can evolve twice.
The randomization uses your player trainer ID as a random seed. This for example means that if you lose to a trainer, they will still have the same Pokémon when battling them again. In a link multi battle, the trainer's team is determined by P1's randomizer settings.

Soullink mode:
The randomizer menu also lets you enable the soullink mode with the following features:
- Pokémon are linked to all other Pokémon with the same met location.
- If a Pokémon faints in a link multi battle and there is another Pokémon with the same met location in the battle, that Pokémon faints too.
- Fainted Pokémon cannot be healed anymore. Using items on a fainted Pokémon always fails. Depositing Pokémon in the PC does not heal it either.

Extra features:
- Rarer Cady: This is a key item that can infinitely raise your Pokémon's level. This is as compensation for the fact that Exp. is disabled in link multi battles.

Known bugs (regular version):
- There are occasionally graphical glitches when sending out Pokémon into battle. Simply open and close a menu to fix this for that battle.
- The game freezes for very specific pair of lead Pokémon. If this happens, reset and battle them individually or with a different randomizer setting.

Known bugs (expansion version):
-

You can report any other bugs in my discord server:
https://discord.gg/yQjhykr9yU