# Pokémon Summary Compendium

## Bulbasaur

**Availability**
- Battlepyramid 1
- Route 104
- Route 114
- Route 119
- Route 130

**Evolves to**
- Ivysaur (Level 16)

**Learnset**

| Move | Level |
|------|-------|
| Tackle | 1 |
| Growl | 4 |
| Leech Seed | 7 |
| Vine Whip | 10 |
| Poison Powder | 15 |
| Sleep Powder | 15 |
| Sludge | 17 |
| Razor Leaf | 20 |
| Sweet Scent | 25 |
| Growth | 32 |
| Solar Beam | 46 |

---

## Ivysaur

**Availability**
- Battlepyramid 1
- Battlepyramid 2
- Evolve Bulbasaur (Level 16)

**Evolves to**
- Venusaur (Level 32)

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Leech Seed | 1 |
| Tackle | 1 |
| Growl | 4 |
| Leech Seed | 7 |
| Vine Whip | 10 |
| Poison Powder | 15 |
| Sleep Powder | 15 |
| Razor Leaf | 22 |
| Sludge | 25 |
| Sweet Scent | 29 |
| Growth | 38 |
| Solar Beam | 56 |

---

## Venusaur

**Availability**
- Battlepyramid 1
- Battlepyramid 2
- Battlepyramid 3
- Evolve Ivysaur (Level 32)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Leech Seed | 1 |
| Tackle | 1 |
| Vine Whip | 1 |
| Growl | 4 |
| Leech Seed | 7 |
| Vine Whip | 10 |
| Poison Powder | 15 |
| Sleep Powder | 15 |
| Razor Leaf | 22 |
| Sweet Scent | 29 |
| Energy Ball | 36 |
| Growth | 41 |
| Synthesis | 53 |
| Solar Beam | 65 |

---

## Charmander

**Availability**
- Battlepyramid 1
- Battlepyramid 2
- Battlepyramid 3
- Battlepyramid 4
- Fiery Path
- Route 112
- Route 130
- Scorched Slab

**Evolves to**
- Charmeleon (Level 16)

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Scratch | 1 |
| Ember | 7 |
| Smokescreen | 13 |
| Rage | 19 |
| Scary Face | 25 |
| Flamethrower | 31 |
| Slash | 37 |
| Dragon Rage | 43 |
| Fire Spin | 49 |

---

## Charmeleon

**Availability**
- Battlepyramid 2
- Battlepyramid 3
- Battlepyramid 4
- Battlepyramid 5
- Battlepyramid 6
- Battlepyramid 7
- Route 115
- Evolve Charmander (Level 16)

**Evolves to**
- Charizard (Level 36)

**Learnset**

| Move | Level |
|------|-------|
| Ember | 1 |
| Growl | 1 |
| Scratch | 1 |
| Ember | 7 |
| Smokescreen | 13 |
| Rage | 20 |
| Flame Wheel | 22 |
| Flamethrower | 36 |
| Slash | 41 |
| Dragon Rage | 48 |
| Fire Spin | 55 |

---

## Charizard

**Availability**
- Battlepyramid 3
- Battlepyramid 4
- Battlepyramid 5
- Battlepyramid 6
- Battlepyramid 7
- Evolve Charmeleon (Level 36)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Ember | 1 |
| Growl | 1 |
| Scratch | 1 |
| Smokescreen | 1 |
| Ember | 7 |
| Smokescreen | 13 |
| Rage | 20 |
| Scary Face | 27 |
| Flamethrower | 34 |
| Wing Attack | 36 |
| Slash | 44 |
| Dragon Breath | 54 |
| Protect | 64 |

---

## Squirtle

**Availability**
- Battlepyramid 4
- Battlepyramid 5
- Battlepyramid 6
- Battlepyramid 7
- Route 104
- Route 127

**Evolves to**
- Wartortle (Level 16)

**Learnset**

| Move | Level |
|------|-------|
| Tackle | 1 |
| Tail Whip | 4 |
| Bubble | 7 |
| Withdraw | 10 |
| Water Gun | 13 |
| Bite | 18 |
| Rapid Spin | 23 |
| Protect | 28 |
| Rain Dance | 33 |
| Skull Bash | 40 |
| Hydro Pump | 47 |

---

## Wartortle

**Availability**
- Battlepyramid 5
- Battlepyramid 6
- Battlepyramid 7
- Route 114
- Route 115
- Route 135
- Evolve Squirtle (Level 16)

**Evolves to**
- Blastoise (Level 36)

**Learnset**

| Move | Level |
|------|-------|
| Bubble | 1 |
| Tackle | 1 |
| Tail Whip | 1 |
| Tail Whip | 4 |
| Bubble | 7 |
| Withdraw | 10 |
| Water Gun | 13 |
| Bite | 19 |
| Rapid Spin | 25 |
| Flash Cannon | 28 |
| Protect | 31 |
| Rain Dance | 37 |
| Skull Bash | 45 |
| Hydro Pump | 53 |

---

## Blastoise

**Availability**
- Route 131
- Evolve Wartortle (Level 36)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Bubble | 1 |
| Tackle | 1 |
| Tail Whip | 1 |
| Withdraw | 1 |
| Tail Whip | 4 |
| Bubble | 7 |
| Withdraw | 10 |
| Water Gun | 13 |
| Bite | 19 |
| Rapid Spin | 25 |
| Flash Cannon | 28 |
| Protect | 31 |
| Zen Headbutt | 37 |
| Rain Dance | 42 |
| Iron Head | 46 |
| Skull Bash | 55 |
| Hydro Pump | 68 |

---

## Caterpie

**Availability**
- Route 101

**Evolves to**
- Metapod (Level 7)

**Learnset**

| Move | Level |
|------|-------|
| String Shot | 1 |
| Tackle | 1 |

---

## Metapod

**Availability**
- Evolve Caterpie (Level 7)

**Evolves to**
- Butterfree (Level 10)

**Learnset**

| Move | Level |
|------|-------|
| Harden | 1 |
| Harden | 7 |

---

## Butterfree

**Availability**
- Evolve Metapod (Level 10)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Confusion | 1 |
| Confusion | 10 |
| Poison Powder | 13 |
| Stun Spore | 14 |
| Sleep Powder | 15 |
| Supersonic | 18 |
| Whirlwind | 23 |
| Gust | 28 |
| Psybeam | 34 |
| Safeguard | 40 |
| Silver Wind | 47 |
| Bug Buzz | 53 |

---

## Weedle

**Availability**
- Route 101

**Evolves to**
- Kakuna (Level 7)

**Learnset**

| Move | Level |
|------|-------|
| Poison Sting | 1 |
| String Shot | 1 |

---

## Kakuna

**Availability**
- Evolve Weedle (Level 7)

**Evolves to**
- Beedrill (Level 10)

**Learnset**

| Move | Level |
|------|-------|
| Harden | 1 |
| Harden | 7 |

---

## Beedrill

**Availability**
- Evolve Kakuna (Level 10)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Fury Attack | 1 |
| Fury Attack | 10 |
| Focus Energy | 15 |
| Twineedle | 20 |
| Rage | 25 |
| Pursuit | 30 |
| Poison Jab | 35 |
| Xscissor | 38 |
| Endeavor | 45 |

---

## Pidgey

**Availability**
- Route 132

**Evolves to**
- Pidgeotto (Level 18)

**Learnset**

| Move | Level |
|------|-------|
| Tackle | 1 |
| Sand Attack | 5 |
| Gust | 9 |
| Quick Attack | 13 |
| Whirlwind | 19 |
| Wing Attack | 25 |
| Feather Dance | 31 |
| Agility | 39 |
| Mirror Move | 47 |

---

## Pidgeotto

**Availability**
- Evolve Pidgey (Level 18)

**Evolves to**
- Pidgeot (Level 36)

**Learnset**

| Move | Level |
|------|-------|
| Gust | 1 |
| Sand Attack | 1 |
| Tackle | 1 |
| Sand Attack | 5 |
| Gust | 9 |
| Quick Attack | 13 |
| Whirlwind | 20 |
| Wing Attack | 27 |
| Feather Dance | 34 |
| Agility | 43 |
| Mirror Move | 52 |

---

## Pidgeot

**Availability**
- Evolve Pidgeotto (Level 36)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Gust | 1 |
| Quick Attack | 1 |
| Sand Attack | 1 |
| Tackle | 1 |
| Sand Attack | 5 |
| Gust | 9 |
| Quick Attack | 13 |
| Whirlwind | 20 |
| Wing Attack | 27 |
| Feather Dance | 34 |
| Agility | 48 |
| Brave Bird | 62 |

---

## Rattata

**Availability**
- Route 104

**Evolves to**
- Raticate (Level 20)

**Learnset**

| Move | Level |
|------|-------|
| Tackle | 1 |
| Tail Whip | 1 |
| Quick Attack | 7 |
| Hyper Fang | 13 |
| Focus Energy | 20 |
| Pursuit | 27 |
| Super Fang | 34 |
| Endeavor | 41 |

---

## Raticate

**Availability**
- Evolve Rattata (Level 20)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Quick Attack | 1 |
| Tackle | 1 |
| Tail Whip | 1 |
| Quick Attack | 7 |
| Hyper Fang | 13 |
| Scary Face | 20 |
| Pursuit | 30 |
| Fire Fang | 35 |
| Super Fang | 40 |
| Thunder Fang | 45 |
| Endeavor | 50 |

---

## Spearow

**Availability**
- Route 103

**Evolves to**
- Fearow (Level 20)

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Peck | 1 |
| Leer | 7 |
| Fury Attack | 13 |
| Pursuit | 19 |
| Aerial Ace | 25 |
| Mirror Move | 31 |
| Drill Peck | 37 |
| Agility | 43 |

---

## Fearow

**Availability**
- Evolve Spearow (Level 20)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Fury Attack | 1 |
| Growl | 1 |
| Leer | 1 |
| Peck | 1 |
| Leer | 7 |
| Fury Attack | 13 |
| Pursuit | 26 |
| Mirror Move | 32 |
| Drill Peck | 40 |
| Agility | 47 |
| Brave Bird | 58 |

---

## Ekans

**Availability**
- ???

**Evolves to**
- Arbok (Level 22)

**Learnset**

| Move | Level |
|------|-------|
| Leer | 1 |
| Wrap | 1 |
| Poison Sting | 8 |
| Bite | 13 |
| Glare | 20 |
| Screech | 25 |
| Acid | 32 |
| Spit Up | 37 |
| Stockpile | 37 |
| Swallow | 37 |
| Haze | 44 |

---

## Arbok

**Availability**
- Route 135
- Evolve Ekans (Level 22)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Bite | 1 |
| Leer | 1 |
| Poison Sting | 1 |
| Wrap | 1 |
| Poison Sting | 8 |
| Bite | 13 |
| Glare | 20 |
| Screech | 28 |
| Acid | 38 |
| Spit Up | 46 |
| Stockpile | 46 |
| Swallow | 46 |
| Haze | 56 |

---

## Pikachu

**Availability**
- Safari Zone South
- Safari Zone Southwest
- Evolve Pichu (High friendship)

**Evolves to**
- Raichu (Use Thunder Stone)

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Thunder Shock | 1 |
| Tail Whip | 6 |
| Thunder Wave | 8 |
| Quick Attack | 11 |
| Double Team | 15 |
| Slam | 20 |
| Thunderbolt | 26 |
| Agility | 33 |
| Thunder | 41 |
| Light Screen | 50 |

---

## Raichu

**Availability**
- Evolve Pikachu (Use Thunder Stone)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Quick Attack | 1 |
| Tail Whip | 1 |
| Thunder Shock | 1 |
| Thunderbolt | 1 |
| Thunder Wave | 8 |
| Quick Attack | 11 |
| Double Team | 15 |
| Slam | 20 |
| Thunderbolt | 26 |
| Agility | 33 |
| Thunder | 41 |
| Light Screen | 50 |
| Volt Tackle | 58 |

---

## Sandshrew

**Availability**
- Miragetower 1F
- Miragetower 2F
- Miragetower 3F
- Miragetower 4F
- Route 111

**Evolves to**
- Sandslash (Level 22)

**Learnset**

| Move | Level |
|------|-------|
| Scratch | 1 |
| Defense Curl | 6 |
| Sand Attack | 11 |
| Poison Sting | 17 |
| Slash | 23 |
| Swift | 30 |
| Fury Swipes | 37 |
| Sand Tomb | 45 |
| Sandstorm | 53 |

---

## Sandslash

**Availability**
- Evolve Sandshrew (Level 22)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Defense Curl | 1 |
| Sand Attack | 1 |
| Scratch | 1 |
| Defense Curl | 6 |
| Sand Attack | 11 |
| Poison Sting | 17 |
| Slash | 24 |
| Swift | 33 |
| Xscissor | 42 |
| Shadow Claw | 52 |
| Earthquake | 62 |

---

## Nidoran♀

**Availability**
- Route 102
- Route 103

**Evolves to**
- Nidorina (Level 16)

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Scratch | 1 |
| Mud Slap | 8 |
| Double Kick | 12 |
| Poison Sting | 17 |
| Bite | 20 |
| Helping Hand | 23 |
| Fury Swipes | 30 |
| Flatter | 38 |
| Crunch | 47 |

---

## Nidorina

**Availability**
- Evolve Nidoran♀ (Level 16)

**Evolves to**
- Nidoqueen (Use Moon Stone)

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Scratch | 1 |
| Tail Whip | 8 |
| Double Kick | 12 |
| Poison Sting | 18 |
| Bite | 22 |
| Slam | 26 |
| Poison Jab | 34 |
| Crunch | 43 |
| Substitute | 53 |

---

## Nidoqueen

**Availability**
- Evolve Nidorina (Use Moon Stone)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Double Kick | 1 |
| Poison Sting | 1 |
| Scratch | 1 |
| Tail Whip | 1 |
| Slam | 26 |
| Poison Jab | 34 |
| Avalanche | 40 |
| Crunch | 43 |
| Earthquake | 50 |
| Substitute | 53 |

---

## Nidoran♂

**Availability**
- Route 102
- Route 103
- Route 104

**Evolves to**
- Nidorino (Level 16)

**Learnset**

| Move | Level |
|------|-------|
| Leer | 1 |
| Peck | 1 |
| Mud Slap | 8 |
| Double Kick | 12 |
| Poison Sting | 17 |
| Horn Attack | 20 |
| Helping Hand | 23 |
| Fury Attack | 30 |
| Flatter | 38 |
| Horn Drill | 47 |

---

## Nidorino

**Availability**
- Evolve Nidoran♂ (Level 16)

**Evolves to**
- Nidoking (Use Moon Stone)

**Learnset**

| Move | Level |
|------|-------|
| Leer | 1 |
| Peck | 1 |
| Focus Energy | 8 |
| Double Kick | 12 |
| Poison Sting | 18 |
| Horn Attack | 22 |
| Slam | 26 |
| Poison Jab | 34 |
| Crunch | 43 |
| Horn Drill | 53 |
| Substitute | 53 |

---

## Nidoking

**Availability**
- Route 130
- Evolve Nidorino (Use Moon Stone)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Double Kick | 1 |
| Focus Energy | 1 |
| Peck | 1 |
| Poison Sting | 1 |
| Thrash | 23 |
| Slam | 26 |
| Poison Jab | 34 |
| Avalanche | 40 |
| Crunch | 43 |
| Earthquake | 50 |
| Substitute | 53 |

---

## Clefairy

**Availability**
- Route 135
- Evolve Cleffa (High friendship)

**Evolves to**
- Clefable (Use Moon Stone)

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Pound | 1 |
| Encore | 5 |
| Sing | 9 |
| Double Slap | 13 |
| Follow Me | 17 |
| Minimize | 21 |
| Defense Curl | 25 |
| Metronome | 29 |
| Cosmic Power | 33 |
| Moonlight | 37 |
| Light Screen | 41 |
| Meteor Mash | 45 |

---

## Clefable

**Availability**
- Evolve Clefairy (Use Moon Stone)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Double Slap | 1 |
| Metronome | 1 |
| Minimize | 1 |
| Sing | 1 |

---

## Vulpix

**Availability**
- Mtpyre Exterior
- Route 103

**Evolves to**
- Ninetales (Use Fire Stone)

**Learnset**

| Move | Level |
|------|-------|
| Ember | 1 |
| Tail Whip | 5 |
| Roar | 9 |
| Quick Attack | 13 |
| Confusion | 17 |
| Flame Wheel | 17 |
| Will O Wisp | 17 |
| Confuse Ray | 21 |
| Imprison | 25 |
| Flamethrower | 29 |
| Safeguard | 33 |
| Grudge | 37 |
| Fire Spin | 41 |

---

## Ninetales

**Availability**
- Scorched Slab
- Evolve Vulpix (Use Fire Stone)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Confuse Ray | 1 |
| Ember | 1 |
| Quick Attack | 1 |
| Safeguard | 1 |
| Tail Whip | 5 |
| Roar | 9 |
| Quick Attack | 13 |
| Confusion | 17 |
| Flame Wheel | 17 |
| Will O Wisp | 17 |
| Confuse Ray | 21 |
| Imprison | 25 |
| Flamethrower | 29 |
| Safeguard | 33 |
| Psychic | 37 |
| Energy Ball | 41 |
| Calm Mind | 47 |

---

## Jigglypuff

**Availability**
- Route 114
- Evolve Igglybuff (High friendship)

**Evolves to**
- Wigglytuff (Use Moon Stone)

**Learnset**

| Move | Level |
|------|-------|
| Sing | 1 |
| Defense Curl | 4 |
| Pound | 9 |
| Disable | 14 |
| Rollout | 19 |
| Double Slap | 24 |
| Rest | 29 |
| Body Slam | 34 |
| Mimic | 39 |
| Hyper Voice | 44 |
| Double Edge | 49 |

---

## Wigglytuff

**Availability**
- Evolve Jigglypuff (Use Moon Stone)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Defense Curl | 1 |
| Disable | 1 |
| Double Slap | 1 |
| Sing | 1 |

---

## Zubat

**Availability**
- Altering Cave 1
- Cave Of Origin 1F
- Cave Of Origin Entrance
- Granite Cave B 1F
- Granite Cave B 2F
- Meteor Falls 1F 1R
- Seafloor Cavern Entrance
- Seafloor Cavern Room 1
- Seafloor Cavern Room 2
- Seafloor Cavern Room 3
- Seafloor Cavern Room 4
- Seafloor Cavern Room 5
- Seafloor Cavern Room 6
- Seafloor Cavern Room 7
- Seafloor Cavern Room 8
- Shoal Cave Lowtideentranceroom
- Shoal Cave Lowtideiceroom
- Shoal Cave Lowtideinnerroom
- Shoal Cave Lowtidelowerroom
- Shoal Cave Lowtidestairsroom

**Evolves to**
- Golbat (Level 22)

**Learnset**

| Move | Level |
|------|-------|
| Leech Life | 1 |
| Supersonic | 6 |
| Astonish | 11 |
| Bite | 16 |
| Wing Attack | 21 |
| Confuse Ray | 26 |
| Air Cutter | 31 |
| Mean Look | 36 |
| Poison Fang | 41 |
| Haze | 46 |

---

## Golbat

**Availability**
- Cave Of Origin 1F
- Cave Of Origin Entrance
- Meteor Falls 1F 2R
- Meteor Falls B 1F 1R
- Meteor Falls B 1F 2R
- Meteor Falls Stevens Cave
- Seafloor Cavern Entrance
- Seafloor Cavern Room 1
- Seafloor Cavern Room 3
- Seafloor Cavern Room 4
- Seafloor Cavern Room 5
- Seafloor Cavern Room 6
- Seafloor Cavern Room 7
- Seafloor Cavern Room 8
- Shoal Cave Lowtideentranceroom
- Shoal Cave Lowtideiceroom
- Shoal Cave Lowtideinnerroom
- Shoal Cave Lowtidelowerroom
- Shoal Cave Lowtidestairsroom
- Skypillar 1F
- Skypillar 3F
- Skypillar 5F
- Victoryroad 1F
- Victoryroad B 1F
- Victoryroad B 2F
- Evolve Zubat (Level 22)

**Evolves to**
- Crobat (High friendship)

**Learnset**

| Move | Level |
|------|-------|
| Astonish | 1 |
| Leech Life | 1 |
| Screech | 1 |
| Supersonic | 1 |
| Supersonic | 6 |
| Astonish | 11 |
| Bite | 16 |
| Wing Attack | 21 |
| Confuse Ray | 22 |
| Thunder Fang | 28 |
| Air Cutter | 35 |
| Mean Look | 42 |
| Poison Fang | 49 |
| Haze | 56 |

---

## Oddish

**Availability**
- Route 110
- Route 117
- Route 119
- Route 120
- Route 121
- Route 123
- Safari Zone North
- Safari Zone Northwest
- Safari Zone South
- Safari Zone Southwest

**Evolves to**
- Gloom (Level 21)

**Learnset**

| Move | Level |
|------|-------|
| Absorb | 1 |
| Sweet Scent | 7 |
| Poison Powder | 14 |
| Stun Spore | 16 |
| Sleep Powder | 18 |
| Acid | 23 |
| Moonlight | 32 |
| Petal Dance | 39 |

---

## Gloom

**Availability**
- Route 121
- Route 123
- Route 135
- Safari Zone North
- Safari Zone Northwest
- Safari Zone South
- Safari Zone Southwest
- Evolve Oddish (Level 21)

**Evolves to**
- Vileplume (Use Leaf Stone)
- Bellossom (Use Sun Stone)

**Learnset**

| Move | Level |
|------|-------|
| Absorb | 1 |
| Poison Powder | 1 |
| Sweet Scent | 1 |
| Sweet Scent | 7 |
| Poison Powder | 14 |
| Stun Spore | 16 |
| Sleep Powder | 18 |
| Acid | 24 |
| Moonlight | 35 |
| Petal Dance | 44 |

---

## Vileplume

**Availability**
- Evolve Gloom (Use Leaf Stone)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Absorb | 1 |
| Aromatherapy | 1 |
| Mega Drain | 1 |
| Stun Spore | 1 |
| Petal Dance | 44 |

---

## Paras

**Availability**
- Advent Cave

**Evolves to**
- Parasect (Level 24)

**Learnset**

| Move | Level |
|------|-------|
| Scratch | 1 |
| Stun Spore | 7 |
| Poison Powder | 13 |
| Leech Life | 19 |
| Spore | 25 |
| Slash | 31 |
| Growth | 37 |
| Giga Drain | 43 |
| Aromatherapy | 49 |

---

## Parasect

**Availability**
- Evolve Paras (Level 24)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Poison Powder | 1 |
| Scratch | 1 |
| Stun Spore | 1 |
| Stun Spore | 7 |
| Poison Powder | 13 |
| Leech Life | 19 |
| Spore | 27 |
| Slash | 35 |
| Growth | 43 |
| Giga Drain | 51 |
| Aromatherapy | 59 |

---

## Venonat

**Availability**
- Advent Cave

**Evolves to**
- Venomoth (Level 31)

**Learnset**

| Move | Level |
|------|-------|
| Disable | 1 |
| Foresight | 1 |
| Tackle | 1 |
| Supersonic | 9 |
| Confusion | 17 |
| Poison Powder | 20 |
| Leech Life | 25 |
| Stun Spore | 28 |
| Psybeam | 33 |
| Sleep Powder | 36 |
| Psychic | 41 |

---

## Venomoth

**Availability**
- Evolve Venonat (Level 31)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Disable | 1 |
| Foresight | 1 |
| Silver Wind | 1 |
| Supersonic | 1 |
| Tackle | 1 |
| Supersonic | 9 |
| Confusion | 17 |
| Poison Powder | 20 |
| Leech Life | 25 |
| Stun Spore | 28 |
| Gust | 31 |
| Psybeam | 36 |
| Sleep Powder | 42 |
| Psychic | 52 |

---

## Diglett

**Availability**
- Route 136

**Evolves to**
- Dugtrio (Level 26)

**Learnset**

| Move | Level |
|------|-------|
| Sand Attack | 1 |
| Scratch | 1 |
| Growl | 5 |
| Magnitude | 9 |
| Dig | 17 |
| Mud Slap | 25 |
| Slash | 33 |
| Earthquake | 41 |
| Fissure | 49 |

---

## Dugtrio

**Availability**
- Route 123
- Evolve Diglett (Level 26)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Sand Attack | 1 |
| Scratch | 1 |
| Tri Attack | 1 |
| Growl | 5 |
| Magnitude | 9 |
| Dig | 17 |
| Mud Slap | 25 |
| Sand Tomb | 26 |
| Slash | 38 |
| Earthquake | 51 |
| Fissure | 64 |

---

## Meowth

**Availability**
- Route 135

**Evolves to**
- Persian (Level 28)

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Scratch | 1 |
| Bite | 11 |
| Pay Day | 20 |
| Faint Attack | 28 |
| Screech | 35 |
| Fury Swipes | 41 |
| Slash | 46 |
| Fake Out | 50 |

---

## Persian

**Availability**
- Evolve Meowth (Level 28)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Bite | 1 |
| Growl | 1 |
| Scratch | 1 |
| Bite | 11 |
| Pay Day | 20 |
| Faint Attack | 29 |
| Screech | 38 |
| Fury Swipes | 46 |
| Slash | 53 |
| Fake Out | 59 |

---

## Psyduck

**Availability**
- Advent Cave
- Resevoir Cave
- Safari Zone Northwest
- Safari Zone Southwest

**Evolves to**
- Golduck (Level 33)

**Learnset**

| Move | Level |
|------|-------|
| Scratch | 1 |
| Water Sport | 1 |
| Tail Whip | 5 |
| Disable | 10 |
| Confusion | 16 |
| Screech | 23 |
| Psych Up | 31 |
| Fury Swipes | 40 |
| Hydro Pump | 50 |

---

## Golduck

**Availability**
- Safari Zone Northwest
- Evolve Psyduck (Level 33)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Disable | 1 |
| Scratch | 1 |
| Tail Whip | 1 |
| Water Sport | 1 |
| Tail Whip | 5 |
| Disable | 10 |
| Confusion | 16 |
| Screech | 23 |
| Psych Up | 31 |
| Bug Buzz | 35 |
| Psychic | 44 |
| Hydro Pump | 58 |

---

## Mankey

**Availability**
- Granite Cave 1F

**Evolves to**
- Primeape (Level 28)

**Learnset**

| Move | Level |
|------|-------|
| Leer | 1 |
| Scratch | 1 |
| Low Kick | 9 |
| Karate Chop | 15 |
| Fury Swipes | 21 |
| Focus Energy | 27 |
| Seismic Toss | 33 |
| Cross Chop | 39 |
| Screech | 45 |
| Thrash | 51 |

---

## Primeape

**Availability**
- Route 130
- Evolve Mankey (Level 28)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Leer | 1 |
| Low Kick | 1 |
| Rage | 1 |
| Scratch | 1 |
| Low Kick | 9 |
| Karate Chop | 15 |
| Fury Swipes | 21 |
| Focus Energy | 27 |
| Rage | 28 |
| Seismic Toss | 36 |
| Cross Chop | 45 |
| Ice Shard | 50 |
| Bullet Punch | 54 |
| Thrash | 63 |

---

## Growlithe

**Availability**
- Fiery Path
- Mtpyre Exterior
- Route 112
- Scorched Slab

**Evolves to**
- Arcanine (Use Fire Stone)

**Learnset**

| Move | Level |
|------|-------|
| Bite | 1 |
| Roar | 1 |
| Ember | 7 |
| Leer | 13 |
| Odor Sleuth | 19 |
| Take Down | 25 |
| Flame Wheel | 31 |
| Helping Hand | 37 |
| Agility | 43 |
| Flamethrower | 49 |

---

## Arcanine

**Availability**
- Evolve Growlithe (Use Fire Stone)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Bite | 1 |
| Ember | 1 |
| Odor Sleuth | 1 |
| Roar | 1 |
| Leer | 13 |
| Odor Sleuth | 19 |
| Take Down | 25 |
| Flame Wheel | 26 |
| Crunch | 37 |
| Agility | 43 |
| Extreme Speed | 49 |
| Flamethrower | 49 |
| Thunder Fang | 57 |

---

## Poliwag

**Availability**
- Route 109

**Evolves to**
- Poliwhirl (Level 25)

**Learnset**

| Move | Level |
|------|-------|
| Bubble | 1 |
| Hypnosis | 7 |
| Water Gun | 13 |
| Double Slap | 19 |
| Rain Dance | 25 |
| Body Slam | 31 |
| Belly Drum | 37 |
| Hydro Pump | 43 |

---

## Poliwhirl

**Availability**
- Evolve Poliwag (Level 25)

**Evolves to**
- Poliwrath (Use Water Stone)
- Politoed (Use Sun Stone)

**Learnset**

| Move | Level |
|------|-------|
| Bubble | 1 |
| Hypnosis | 1 |
| Water Gun | 1 |
| Hypnosis | 7 |
| Water Gun | 13 |
| Double Slap | 19 |
| Rain Dance | 27 |
| Body Slam | 35 |
| Belly Drum | 43 |
| Hydro Pump | 51 |

---

## Poliwrath

**Availability**
- Evolve Poliwhirl (Use Water Stone)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Double Slap | 1 |
| Hypnosis | 1 |
| Submission | 1 |
| Water Gun | 1 |
| Hypnosis | 7 |
| Water Gun | 13 |
| Double Slap | 19 |
| Rain Dance | 27 |
| Aqua Jet | 31 |
| Body Slam | 35 |
| Submission | 35 |
| Belly Drum | 43 |
| Close Combat | 49 |

---

## Abra

**Availability**
- Granite Cave 1F
- Granite Cave B 2F
- Granite Cave Stevensroom
- Route 116

**Evolves to**
- Kadabra (Level 16)

**Learnset**

| Move | Level |
|------|-------|
| Teleport | 1 |

---

## Kadabra

**Availability**
- Evolve Abra (Level 16)

**Evolves to**
- Alakazam (Level 40)

**Learnset**

| Move | Level |
|------|-------|
| Confusion | 1 |
| Kinesis | 1 |
| Teleport | 1 |
| Confusion | 16 |
| Disable | 18 |
| Psybeam | 21 |
| Reflect | 23 |
| Recover | 25 |
| Future Sight | 30 |
| Energy Ball | 33 |
| Psychic | 36 |
| Trick | 43 |

---

## Alakazam

**Availability**
- Evolve Kadabra (Level 40)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Confusion | 1 |
| Kinesis | 1 |
| Teleport | 1 |
| Confusion | 16 |
| Disable | 18 |
| Psybeam | 21 |
| Reflect | 23 |
| Recover | 25 |
| Future Sight | 30 |
| Calm Mind | 33 |
| Psychic | 36 |
| Aura Sphere | 43 |

---

## Machop

**Availability**
- Fiery Path
- Jagged Pass

**Evolves to**
- Machoke (Level 28)

**Learnset**

| Move | Level |
|------|-------|
| Leer | 1 |
| Low Kick | 1 |
| Focus Energy | 7 |
| Karate Chop | 13 |
| Seismic Toss | 19 |
| Foresight | 22 |
| Revenge | 25 |
| Vital Throw | 31 |
| Submission | 37 |
| Cross Chop | 40 |
| Scary Face | 43 |
| Dynamic Punch | 49 |

---

## Machoke

**Availability**
- Route 123
- Evolve Machop (Level 28)

**Evolves to**
- Machamp (Level 40)

**Learnset**

| Move | Level |
|------|-------|
| Focus Energy | 1 |
| Leer | 1 |
| Low Kick | 1 |
| Focus Energy | 7 |
| Karate Chop | 13 |
| Seismic Toss | 19 |
| Foresight | 22 |
| Revenge | 25 |
| Vital Throw | 33 |
| Submission | 41 |
| Cross Chop | 46 |
| Scary Face | 51 |
| Dynamic Punch | 59 |

---

## Machamp

**Availability**
- Evolve Machoke (Level 40)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Focus Energy | 1 |
| Leer | 1 |
| Low Kick | 1 |
| Focus Energy | 7 |
| Karate Chop | 13 |
| Seismic Toss | 19 |
| Foresight | 22 |
| Revenge | 25 |
| Vital Throw | 33 |
| Submission | 41 |
| Cross Chop | 46 |
| Mach Punch | 51 |
| Close Combat | 59 |

---

## Bellsprout

**Availability**
- Route 130
- Route 136

**Evolves to**
- Weepinbell (Level 21)

**Learnset**

| Move | Level |
|------|-------|
| Vine Whip | 1 |
| Growth | 6 |
| Wrap | 11 |
| Sleep Powder | 15 |
| Poison Powder | 17 |
| Stun Spore | 19 |
| Acid | 23 |
| Sweet Scent | 30 |
| Razor Leaf | 37 |
| Slam | 45 |

---

## Weepinbell

**Availability**
- Evolve Bellsprout (Level 21)

**Evolves to**
- Victreebel (Use Leaf Stone)

**Learnset**

| Move | Level |
|------|-------|
| Growth | 1 |
| Vine Whip | 1 |
| Wrap | 1 |
| Growth | 6 |
| Wrap | 11 |
| Sleep Powder | 15 |
| Poison Powder | 17 |
| Stun Spore | 19 |
| Acid | 24 |
| Sweet Scent | 33 |
| Razor Leaf | 42 |
| Slam | 54 |

---

## Victreebel

**Availability**
- Evolve Weepinbell (Use Leaf Stone)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Razor Leaf | 1 |
| Sleep Powder | 1 |
| Sweet Scent | 1 |
| Vine Whip | 1 |
| Growth | 6 |
| Wrap | 11 |
| Sleep Powder | 15 |
| Poison Powder | 17 |
| Stun Spore | 19 |
| Acid | 24 |
| Sludge Bomb | 33 |
| Giga Drain | 42 |
| Flash Cannon | 54 |

---

## Tentacool

**Availability**
- Abandoned Ship Hiddenfloorcorridors
- Abandoned Ship Rooms B 1F
- Dewford Town
- Evergrande City
- Lilycove City
- Mossdeep City
- Pacifidlog Town
- Route 103
- Route 105
- Route 106
- Route 107
- Route 108
- Route 109
- Route 110
- Route 115
- Route 118
- Route 119
- Route 121
- Route 122
- Route 123
- Route 124
- Route 125
- Route 126
- Route 127
- Route 128
- Route 129
- Route 130
- Route 131
- Route 132
- Route 133
- Route 134
- Seafloor Cavern Entrance
- Seafloor Cavern Room 6
- Seafloor Cavern Room 7
- Shoal Cave Lowtideentranceroom
- Shoal Cave Lowtideinnerroom
- Slateport City
- Sootopolis City

**Evolves to**
- Tentacruel (Level 30)

**Learnset**

| Move | Level |
|------|-------|
| Poison Sting | 1 |
| Supersonic | 6 |
| Constrict | 12 |
| Acid | 19 |
| Bubble Beam | 25 |
| Wrap | 30 |
| Barrier | 36 |
| Screech | 43 |
| Hydro Pump | 49 |

---

## Tentacruel

**Availability**
- Abandoned Ship Hiddenfloorcorridors
- Abandoned Ship Rooms B 1F
- Evolve Tentacool (Level 30)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Constrict | 1 |
| Poison Sting | 1 |
| Supersonic | 1 |
| Supersonic | 6 |
| Constrict | 12 |
| Acid | 19 |
| Bubble Beam | 25 |
| Wrap | 30 |
| Barrier | 38 |
| Screech | 47 |
| Hydro Pump | 55 |

---

## Geodude

**Availability**
- Granite Cave 1F
- Granite Cave B 2F
- Magma Hideout 1F
- Magma Hideout 2F 1R
- Magma Hideout 2F 2R
- Magma Hideout 2F 3R
- Magma Hideout 3F 1R
- Magma Hideout 3F 2R
- Magma Hideout 3F 3R
- Magma Hideout 4F
- Route 111
- Route 114
- Safari Zone North
- Victoryroad B 1F

**Evolves to**
- Graveler (Level 25)

**Learnset**

| Move | Level |
|------|-------|
| Defense Curl | 1 |
| Tackle | 1 |
| Mud Sport | 6 |
| Rock Throw | 11 |
| Magnitude | 16 |
| Self Destruct | 21 |
| Rollout | 26 |
| Rock Blast | 31 |
| Earthquake | 36 |
| Explosion | 41 |
| Double Edge | 46 |

---

## Graveler

**Availability**
- Magma Hideout 1F
- Magma Hideout 2F 1R
- Magma Hideout 2F 2R
- Magma Hideout 2F 3R
- Magma Hideout 3F 1R
- Magma Hideout 3F 2R
- Magma Hideout 3F 3R
- Magma Hideout 4F
- Victoryroad B 1F
- Evolve Geodude (Level 25)

**Evolves to**
- Golem (Level 34)

**Learnset**

| Move | Level |
|------|-------|
| Defense Curl | 1 |
| Mud Sport | 1 |
| Rock Throw | 1 |
| Tackle | 1 |
| Mud Sport | 6 |
| Rock Throw | 11 |
| Magnitude | 16 |
| Self Destruct | 21 |
| Rollout | 29 |
| Rock Blast | 37 |
| Earthquake | 45 |
| Explosion | 53 |
| Double Edge | 62 |

---

## Golem

**Availability**
- Route 111
- Route 114
- Evolve Graveler (Level 34)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Defense Curl | 1 |
| Mud Sport | 1 |
| Rock Throw | 1 |
| Tackle | 1 |
| Mud Sport | 6 |
| Rock Throw | 11 |
| Magnitude | 16 |
| Self Destruct | 21 |
| Rollout | 29 |
| Rock Blast | 37 |
| Earthquake | 45 |
| Explosion | 53 |
| Double Edge | 62 |

---

## Ponyta

**Availability**
- Route 110
- Route 112

**Evolves to**
- Rapidash (Level 35)

**Learnset**

| Move | Level |
|------|-------|
| Tackle | 1 |
| Growl | 5 |
| Tail Whip | 9 |
| Ember | 14 |
| Stomp | 19 |
| Fire Spin | 25 |
| Take Down | 31 |
| Agility | 38 |
| Bounce | 45 |
| Fire Blast | 53 |

---

## Rapidash

**Availability**
- Evolve Ponyta (Level 35)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Ember | 1 |
| Growl | 1 |
| Tackle | 1 |
| Tail Whip | 1 |
| Growl | 5 |
| Tail Whip | 9 |
| Ember | 14 |
| Stomp | 19 |
| Fire Spin | 25 |
| Take Down | 31 |
| Agility | 38 |
| Fury Attack | 40 |
| Bounce | 50 |
| Fire Blast | 63 |

---

## Slowpoke

**Availability**
- ???

**Evolves to**
- Slowbro (Level 37)
- Slowking (Use Water Stone)

**Learnset**

| Move | Level |
|------|-------|
| Curse | 1 |
| Tackle | 1 |
| Yawn | 1 |
| Growl | 6 |
| Water Gun | 15 |
| Confusion | 20 |
| Disable | 29 |
| Headbutt | 34 |
| Amnesia | 43 |
| Psychic | 48 |

---

## Slowbro

**Availability**
- Route 115
- Route 124
- Route 136
- Evolve Slowpoke (Level 37)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Curse | 1 |
| Growl | 1 |
| Tackle | 1 |
| Yawn | 1 |
| Growl | 6 |
| Water Gun | 15 |
| Confusion | 20 |
| Disable | 29 |
| Headbutt | 34 |
| Withdraw | 37 |
| Amnesia | 46 |
| Psychic | 54 |

---

## Magnemite

**Availability**
- New Mauville Entrance
- New Mauville Inside
- Route 110

**Evolves to**
- Magneton (Level 25)

**Learnset**

| Move | Level |
|------|-------|
| Metal Sound | 1 |
| Tackle | 1 |
| Thunder Shock | 6 |
| Supersonic | 11 |
| Sonic Boom | 16 |
| Thunder Wave | 21 |
| Spark | 26 |
| Magnet Bomb | 32 |
| Swift | 38 |
| Screech | 44 |
| Zap Cannon | 50 |

---

## Magneton

**Availability**
- New Mauville Inside
- Evolve Magnemite (Level 25)

**Evolves to**
- Magnezone (Level 40)

**Learnset**

| Move | Level |
|------|-------|
| Metal Sound | 1 |
| Supersonic | 1 |
| Tackle | 1 |
| Thunder Shock | 1 |
| Thunder Shock | 6 |
| Supersonic | 11 |
| Sonic Boom | 16 |
| Thunder Wave | 21 |
| Spark | 26 |
| Magnet Bomb | 35 |
| Tri Attack | 44 |
| Flash Cannon | 53 |
| Zap Cannon | 62 |

---

## Magnezone

**Availability**
- Evolve Magneton (Level 40)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Metal Sound | 1 |
| Tackle | 1 |
| Thunder Shock | 6 |
| Supersonic | 11 |
| Sonic Boom | 16 |
| Thunder Wave | 21 |
| Spark | 26 |
| Magnet Bomb | 32 |
| Swift | 38 |
| Flash Cannon | 44 |
| Zap Cannon | 50 |

---

## Farfetchd

**Availability**
- Route 136

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Peck | 1 |
| Sand Attack | 6 |
| Leer | 11 |
| Fury Attack | 16 |
| Knock Off | 21 |
| Fury Cutter | 26 |
| Swords Dance | 31 |
| Agility | 36 |
| Slash | 41 |
| False Swipe | 46 |

---

## Doduo

**Availability**
- Safari Zone Northwest
- Safari Zone South
- Safari Zone Southwest

**Evolves to**
- Dodrio (Level 31)

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Peck | 1 |
| Pursuit | 9 |
| Fury Attack | 13 |
| Tri Attack | 21 |
| Rage | 25 |
| Uproar | 33 |
| Drill Peck | 37 |
| Agility | 45 |

---

## Dodrio

**Availability**
- Route 123
- Safari Zone Northwest
- Evolve Doduo (Level 31)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Fury Attack | 1 |
| Growl | 1 |
| Peck | 1 |
| Pursuit | 1 |
| Pursuit | 9 |
| Fury Attack | 13 |
| Tri Attack | 21 |
| Rage | 25 |
| Uproar | 38 |
| Drill Peck | 47 |
| Agility | 60 |

---

## Seel

**Availability**
- Route 108
- Route 132

**Evolves to**
- Dewgong (Level 34)

**Learnset**

| Move | Level |
|------|-------|
| Headbutt | 1 |
| Growl | 9 |
| Icy Wind | 17 |
| Aurora Beam | 21 |
| Rest | 29 |
| Take Down | 37 |
| Ice Beam | 41 |
| Safeguard | 49 |

---

## Dewgong

**Availability**
- Evolve Seel (Level 34)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Aurora Beam | 1 |
| Growl | 1 |
| Headbutt | 1 |
| Icy Wind | 1 |
| Growl | 9 |
| Icy Wind | 17 |
| Aurora Beam | 21 |
| Rest | 29 |
| Sheer Cold | 34 |
| Take Down | 42 |
| Ice Beam | 51 |
| Safeguard | 64 |

---

## Grimer

**Availability**
- Fiery Path
- Route 118

**Evolves to**
- Muk (Level 38)

**Learnset**

| Move | Level |
|------|-------|
| Poison Gas | 1 |
| Pound | 1 |
| Harden | 4 |
| Disable | 8 |
| Sludge | 13 |
| Minimize | 19 |
| Screech | 26 |
| Acid Armor | 34 |
| Sludge Bomb | 43 |
| Memento | 53 |

---

## Muk

**Availability**
- Evolve Grimer (Level 38)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Harden | 1 |
| Poison Gas | 1 |
| Pound | 1 |
| Harden | 4 |
| Disable | 8 |
| Sludge | 13 |
| Minimize | 19 |
| Screech | 26 |
| Acid Armor | 34 |
| Sludge Bomb | 47 |
| Memento | 61 |

---

## Shellder

**Availability**
- Route 109

**Evolves to**
- Cloyster (Use Water Stone)

**Learnset**

| Move | Level |
|------|-------|
| Tackle | 1 |
| Withdraw | 1 |
| Supersonic | 9 |
| Aurora Beam | 17 |
| Protect | 25 |
| Leer | 33 |
| Clamp | 41 |
| Ice Beam | 49 |

---

## Cloyster

**Availability**
- Route 131
- Evolve Shellder (Use Water Stone)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Aurora Beam | 1 |
| Protect | 1 |
| Supersonic | 1 |
| Withdraw | 1 |
| Spikes | 33 |
| Spike Cannon | 41 |

---

## Gastly

**Availability**
- Granite Cave B 1F
- Petalburg Woods
- Route 104
- Route 116

**Evolves to**
- Haunter (Level 25)

**Learnset**

| Move | Level |
|------|-------|
| Hypnosis | 1 |
| Lick | 1 |
| Acid | 8 |
| Mean Look | 13 |
| Curse | 16 |
| Night Shade | 21 |
| Confuse Ray | 28 |
| Dream Eater | 33 |
| Destiny Bond | 36 |

---

## Haunter

**Availability**
- Evolve Gastly (Level 25)

**Evolves to**
- Gengar (Level 36)

**Learnset**

| Move | Level |
|------|-------|
| Hypnosis | 1 |
| Lick | 1 |
| Spite | 1 |
| Spite | 8 |
| Mean Look | 13 |
| Curse | 16 |
| Night Shade | 21 |
| Shadow Punch | 25 |
| Confuse Ray | 31 |
| Dream Eater | 39 |
| Destiny Bond | 48 |

---

## Gengar

**Availability**
- Evolve Haunter (Level 36)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Hypnosis | 1 |
| Lick | 1 |
| Spite | 1 |
| Spite | 8 |
| Mean Look | 13 |
| Curse | 16 |
| Night Shade | 21 |
| Psybeam | 25 |
| Confuse Ray | 31 |
| Dream Eater | 39 |
| Shadow Ball | 44 |
| Energy Ball | 46 |
| Destiny Bond | 48 |
| Aura Sphere | 56 |

---

## Onix

**Availability**
- Route 136

**Evolves to**
- Steelix (Level 36)

**Learnset**

| Move | Level |
|------|-------|
| Screech | 1 |
| Tackle | 1 |
| Bind | 9 |
| Rock Throw | 13 |
| Harden | 21 |
| Rage | 25 |
| Sandstorm | 33 |
| Slam | 37 |
| Iron Tail | 45 |
| Sand Tomb | 49 |
| Double Edge | 57 |

---

## Drowzee

**Availability**
- Route 118

**Evolves to**
- Hypno (Level 26)

**Learnset**

| Move | Level |
|------|-------|
| Hypnosis | 1 |
| Pound | 1 |
| Disable | 10 |
| Confusion | 18 |
| Headbutt | 25 |
| Poison Gas | 31 |
| Meditate | 36 |
| Psychic | 40 |
| Psych Up | 43 |
| Future Sight | 45 |

---

## Hypno

**Availability**
- Evolve Drowzee (Level 26)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Confusion | 1 |
| Disable | 1 |
| Hypnosis | 1 |
| Pound | 1 |
| Disable | 10 |
| Confusion | 18 |
| Headbutt | 25 |
| Poison Gas | 33 |
| Meditate | 40 |
| Psychic | 49 |
| Psych Up | 55 |
| Future Sight | 60 |

---

## Krabby

**Availability**
- Route 118

**Evolves to**
- Kingler (Level 28)

**Learnset**

| Move | Level |
|------|-------|
| Bubble | 1 |
| Leer | 5 |
| Vice Grip | 12 |
| Harden | 16 |
| Mud Shot | 23 |
| Stomp | 27 |
| Guillotine | 34 |
| Protect | 41 |
| Crabhammer | 45 |

---

## Kingler

**Availability**
- Evolve Krabby (Level 28)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Bubble | 1 |
| Leer | 1 |
| Vice Grip | 1 |
| Leer | 5 |
| Vice Grip | 12 |
| Harden | 16 |
| Mud Shot | 23 |
| Stomp | 27 |
| Guillotine | 38 |
| Protect | 49 |
| Crabhammer | 57 |

---

## Voltorb

**Availability**
- New Mauville Entrance
- New Mauville Inside

**Evolves to**
- Electrode (Level 30)

**Learnset**

| Move | Level |
|------|-------|
| Charge | 1 |
| Tackle | 1 |
| Screech | 8 |
| Sonic Boom | 15 |
| Spark | 21 |
| Self Destruct | 27 |
| Rollout | 32 |
| Light Screen | 37 |
| Swift | 42 |
| Explosion | 46 |
| Mirror Coat | 49 |

---

## Electrode

**Availability**
- Battlepike 2
- New Mauville Inside
- Evolve Voltorb (Level 30)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Charge | 1 |
| Screech | 1 |
| Sonic Boom | 1 |
| Tackle | 1 |
| Screech | 8 |
| Sonic Boom | 15 |
| Spark | 21 |
| Self Destruct | 27 |
| Rollout | 34 |
| Light Screen | 41 |
| Swift | 48 |
| Explosion | 54 |
| Mirror Coat | 59 |

---

## Exeggcute

**Availability**
- Route 113
- Route 118

**Evolves to**
- Exeggutor (Use Leaf Stone)

**Learnset**

| Move | Level |
|------|-------|
| Barrage | 1 |
| Hypnosis | 1 |
| Uproar | 1 |
| Reflect | 7 |
| Leech Seed | 13 |
| Confusion | 19 |
| Stun Spore | 25 |
| Poison Powder | 31 |
| Sleep Powder | 37 |
| Solar Beam | 43 |

---

## Exeggutor

**Availability**
- Evolve Exeggcute (Use Leaf Stone)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Barrage | 1 |
| Confusion | 1 |
| Hypnosis | 1 |
| Reflect | 7 |
| Leech Seed | 13 |
| Confusion | 19 |
| Stomp | 19 |
| Stun Spore | 25 |
| Egg Bomb | 31 |
| Poison Powder | 31 |
| Sleep Powder | 37 |
| Psychic | 40 |
| Solar Beam | 43 |

---

## Cubone

**Availability**
- Route 113

**Evolves to**
- Marowak (Level 28)

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Tail Whip | 5 |
| Bone Club | 9 |
| Headbutt | 13 |
| Leer | 17 |
| Focus Energy | 21 |
| Bonemerang | 25 |
| Rage | 29 |
| False Swipe | 33 |
| Thrash | 37 |
| Bone Rush | 41 |
| Double Edge | 45 |

---

## Marowak

**Availability**
- Evolve Cubone (Level 28)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Bone Club | 1 |
| Growl | 1 |
| Headbutt | 1 |
| Tail Whip | 1 |
| Tail Whip | 5 |
| Bone Club | 9 |
| Headbutt | 13 |
| Leer | 17 |
| Focus Energy | 21 |
| Bonemerang | 25 |
| Rage | 32 |
| False Swipe | 39 |
| Thrash | 46 |
| Bone Rush | 53 |
| Double Edge | 61 |

---

## Hitmonlee

**Availability**
- Evolve Tyrogue (Level 20 (Atk > Def))

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Double Kick | 1 |
| Revenge | 1 |
| Meditate | 6 |
| Rolling Kick | 11 |
| Jump Kick | 16 |
| Brick Break | 20 |
| Focus Energy | 21 |
| Hi Jump Kick | 26 |
| Mind Reader | 31 |
| Foresight | 36 |
| Endure | 41 |
| Mega Kick | 46 |
| Reversal | 51 |

---

## Hitmonchan

**Availability**
- Evolve Tyrogue (Level 20 (Atk < Def))

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Comet Punch | 1 |
| Revenge | 1 |
| Agility | 7 |
| Pursuit | 13 |
| Mach Punch | 20 |
| Fire Punch | 26 |
| Ice Punch | 26 |
| Thunder Punch | 26 |
| Sky Uppercut | 32 |
| Mega Punch | 38 |
| Detect | 44 |
| Counter | 50 |

---

## Lickitung

**Availability**
- Route 118
- Route 136

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Lick | 1 |
| Supersonic | 7 |
| Defense Curl | 12 |
| Knock Off | 18 |
| Stomp | 23 |
| Wrap | 29 |
| Disable | 34 |
| Slam | 40 |
| Screech | 45 |
| Refresh | 51 |

---

## Koffing

**Availability**
- Fiery Path
- Route 118

**Evolves to**
- Weezing (Level 35)

**Learnset**

| Move | Level |
|------|-------|
| Poison Gas | 1 |
| Tackle | 1 |
| Smog | 9 |
| Self Destruct | 17 |
| Sludge | 21 |
| Smokescreen | 25 |
| Haze | 33 |
| Explosion | 41 |
| Destiny Bond | 45 |
| Memento | 49 |

---

## Weezing

**Availability**
- Evolve Koffing (Level 35)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Poison Gas | 1 |
| Self Destruct | 1 |
| Smog | 1 |
| Tackle | 1 |
| Smog | 9 |
| Self Destruct | 17 |
| Sludge | 21 |
| Smokescreen | 25 |
| Haze | 33 |
| Explosion | 44 |
| Destiny Bond | 51 |
| Memento | 58 |

---

## Rhyhorn

**Availability**
- Safari Zone Northwest

**Evolves to**
- Rhydon (Level 36)

**Learnset**

| Move | Level |
|------|-------|
| Horn Attack | 1 |
| Tail Whip | 1 |
| Stomp | 10 |
| Fury Attack | 15 |
| Scary Face | 24 |
| Rock Blast | 29 |
| Horn Drill | 38 |
| Take Down | 43 |
| Earthquake | 52 |
| Megahorn | 57 |

---

## Rhydon

**Availability**
- Evolve Rhyhorn (Level 36)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Fury Attack | 1 |
| Horn Attack | 1 |
| Stomp | 1 |
| Tail Whip | 1 |
| Stomp | 10 |
| Fury Attack | 15 |
| Scary Face | 24 |
| Rock Blast | 29 |
| Horn Drill | 38 |
| Take Down | 46 |
| Earthquake | 58 |
| Megahorn | 66 |

---

## Chansey

**Availability**
- Route 136

**Evolves to**
- Blissey (High friendship)

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Pound | 1 |
| Tail Whip | 5 |
| Refresh | 9 |
| Soft Boiled | 13 |
| Double Slap | 17 |
| Minimize | 23 |
| Sing | 29 |
| Egg Bomb | 35 |
| Defense Curl | 41 |
| Light Screen | 49 |
| Double Edge | 57 |

---

## Tangela

**Availability**
- Route 136

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Constrict | 1 |
| Ingrain | 1 |
| Sleep Powder | 4 |
| Absorb | 10 |
| Growth | 13 |
| Poison Powder | 19 |
| Vine Whip | 22 |
| Bind | 28 |
| Mega Drain | 31 |
| Stun Spore | 37 |
| Slam | 40 |
| Tickle | 46 |

---

## Kangaskhan

**Availability**
- Route 118
- Route 123
- Victoryroad 1F

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Comet Punch | 1 |
| Leer | 1 |
| Bite | 7 |
| Tail Whip | 13 |
| Fake Out | 19 |
| Mega Punch | 25 |
| Rage | 31 |
| Endure | 37 |
| Dizzy Punch | 43 |
| Reversal | 49 |

---

## Horsea

**Availability**
- Resevoir Cave
- Route 107
- Route 108
- Route 126
- Route 127
- Route 132
- Route 133
- Route 134
- Route 135
- Route 136

**Evolves to**
- Seadra (Level 32)

**Learnset**

| Move | Level |
|------|-------|
| Bubble | 1 |
| Smokescreen | 8 |
| Leer | 15 |
| Water Gun | 22 |
| Twister | 29 |
| Agility | 36 |
| Hydro Pump | 43 |
| Dragon Dance | 50 |

---

## Seadra

**Availability**
- Route 107
- Route 125
- Route 135
- Evolve Horsea (Level 32)

**Evolves to**
- Kingdra (Use Dragon Scale)

**Learnset**

| Move | Level |
|------|-------|
| Bubble | 1 |
| Leer | 1 |
| Smokescreen | 1 |
| Water Gun | 1 |
| Smokescreen | 8 |
| Leer | 15 |
| Water Gun | 22 |
| Twister | 29 |
| Dragon Pulse | 40 |
| Hydro Pump | 51 |
| Dragon Dance | 62 |

---

## Goldeen

**Availability**
- Meteor Falls 1F 1R
- Meteor Falls 1F 2R
- Meteor Falls B 1F 1R
- Meteor Falls B 1F 2R
- Petalburg City
- Route 102
- Route 111
- Route 114
- Route 117
- Route 120
- Safari Zone Northwest
- Safari Zone Southeast
- Safari Zone Southwest
- Victoryroad B 2F

**Evolves to**
- Seaking (Level 33)

**Learnset**

| Move | Level |
|------|-------|
| Peck | 1 |
| Tail Whip | 1 |
| Water Sport | 1 |
| Supersonic | 10 |
| Horn Attack | 15 |
| Flail | 24 |
| Fury Attack | 29 |
| Waterfall | 38 |
| Horn Drill | 43 |
| Agility | 52 |

---

## Seaking

**Availability**
- Safari Zone Northwest
- Safari Zone Southwest
- Evolve Goldeen (Level 33)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Peck | 1 |
| Supersonic | 1 |
| Tail Whip | 1 |
| Water Sport | 1 |
| Supersonic | 10 |
| Horn Attack | 15 |
| Flail | 24 |
| Fury Attack | 29 |
| Waterfall | 41 |
| Horn Drill | 49 |
| Agility | 61 |

---

## Staryu

**Availability**
- Lilycove City
- Meteor Falls 1F 1R
- Meteor Falls 1F 2R
- Petalburg City
- Resevoir Cave
- Route 114

**Evolves to**
- Starmie (Use Water Stone)

**Learnset**

| Move | Level |
|------|-------|
| Harden | 1 |
| Tackle | 1 |
| Water Gun | 6 |
| Rapid Spin | 10 |
| Recover | 15 |
| Camouflage | 19 |
| Swift | 24 |
| Bubble Beam | 28 |
| Minimize | 33 |
| Light Screen | 37 |
| Cosmic Power | 42 |
| Hydro Pump | 46 |

---

## Starmie

**Availability**
- Route 114
- Route 120
- Route 134
- Evolve Staryu (Use Water Stone)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Rapid Spin | 1 |
| Recover | 1 |
| Swift | 1 |
| Water Gun | 1 |
| Water Gun | 6 |
| Rapid Spin | 10 |
| Recover | 15 |
| Camouflage | 19 |
| Swift | 24 |
| Bubble Beam | 28 |
| Confuse Ray | 33 |
| Minimize | 33 |
| Psychic | 35 |
| Light Screen | 37 |
| Cosmic Power | 42 |
| Hydro Pump | 46 |

---

## Mr♂Ime

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| (none found) | - |

---

## Scyther

**Availability**
- Route 113
- Route 135

**Evolves to**
- Scizor (Level 36)

**Learnset**

| Move | Level |
|------|-------|
| Leer | 1 |
| Quick Attack | 1 |
| Focus Energy | 6 |
| Pursuit | 11 |
| False Swipe | 16 |
| Agility | 21 |
| Wing Attack | 26 |
| Slash | 31 |
| Swords Dance | 36 |
| Xscissor | 36 |
| Double Team | 41 |
| Fury Cutter | 46 |

---

## Jynx

**Availability**
- Evolve Smoochum (Level 30)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Lick | 1 |
| Lovely Kiss | 1 |
| Pound | 1 |
| Powder Snow | 1 |
| Lovely Kiss | 9 |
| Powder Snow | 13 |
| Double Slap | 21 |
| Ice Punch | 25 |
| Mean Look | 35 |
| Fake Tears | 41 |
| Body Slam | 51 |
| Perish Song | 57 |
| Blizzard | 67 |

---

## Electabuzz

**Availability**
- Evolve Elekid (Level 20)

**Evolves to**
- Electivire (Level 36)

**Learnset**

| Move | Level |
|------|-------|
| Leer | 1 |
| Quick Attack | 1 |
| Thunder Punch | 1 |
| Thunder Punch | 9 |
| Light Screen | 17 |
| Swift | 25 |
| Screech | 36 |
| Thunderbolt | 47 |
| Thunder | 58 |

---

## Magmar

**Availability**
- Evolve Magby (Level 20)

**Evolves to**
- Magmortar (Level 36)

**Learnset**

| Move | Level |
|------|-------|
| Ember | 1 |
| Fire Punch | 1 |
| Leer | 1 |
| Smog | 1 |
| Leer | 7 |
| Smog | 13 |
| Fire Punch | 19 |
| Smokescreen | 25 |
| Sunny Day | 33 |
| Flamethrower | 41 |
| Confuse Ray | 49 |
| Fire Blast | 57 |

---

## Magmortar

**Availability**
- Evolve Magmar (Level 36)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Ember | 1 |
| Fire Punch | 1 |
| Leer | 1 |
| Smog | 1 |
| Leer | 7 |
| Smog | 13 |
| Fire Punch | 19 |
| Smokescreen | 25 |
| Sunny Day | 33 |
| Flamethrower | 41 |
| Confuse Ray | 49 |
| Fire Blast | 57 |
| Hyper Beam | 61 |

---

## Pinsir

**Availability**
- Route 121
- Route 135
- Safari Zone Northwest

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Focus Energy | 1 |
| Vice Grip | 1 |
| Bind | 7 |
| Seismic Toss | 13 |
| Harden | 19 |
| Revenge | 25 |
| Brick Break | 31 |
| Guillotine | 37 |
| Submission | 43 |
| Swords Dance | 49 |

---

## Tauros

**Availability**
- Route 135

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Tackle | 1 |
| Tail Whip | 4 |
| Rage | 8 |
| Horn Attack | 13 |
| Scary Face | 19 |
| Pursuit | 26 |
| Rest | 34 |
| Thrash | 43 |
| Take Down | 53 |

---

## Magikarp

**Availability**
- Abandoned Ship Hiddenfloorcorridors
- Abandoned Ship Rooms B 1F
- Dewford Town
- Evergrande City
- Lilycove City
- Meteor Falls 1F 1R
- Meteor Falls 1F 2R
- Meteor Falls B 1F 1R
- Meteor Falls B 1F 2R
- Mossdeep City
- Pacifidlog Town
- Petalburg City
- Route 102
- Route 103
- Route 104
- Route 105
- Route 106
- Route 107
- Route 108
- Route 109
- Route 110
- Route 111
- Route 114
- Route 115
- Route 117
- Route 118
- Route 119
- Route 120
- Route 121
- Route 122
- Route 123
- Route 124
- Route 125
- Route 126
- Route 127
- Route 128
- Route 129
- Route 130
- Route 131
- Route 132
- Route 133
- Route 134
- Route 135
- Route 136
- Safari Zone Northwest
- Safari Zone Southeast
- Safari Zone Southwest
- Seafloor Cavern Entrance
- Seafloor Cavern Room 6
- Seafloor Cavern Room 7
- Shoal Cave Lowtideentranceroom
- Shoal Cave Lowtideinnerroom
- Slateport City
- Sootopolis City
- Victoryroad B 2F

**Evolves to**
- Gyarados (Level 20)

**Learnset**

| Move | Level |
|------|-------|
| Splash | 1 |
| Tackle | 15 |
| Flail | 30 |

---

## Gyarados

**Availability**
- Sootopolis City
- Evolve Magikarp (Level 20)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Thrash | 1 |
| Bite | 20 |
| Dragon Rage | 25 |
| Leer | 30 |
| Twister | 35 |
| Hydro Pump | 40 |
| Rain Dance | 45 |
| Dragon Dance | 50 |
| Hyper Beam | 55 |
| Brave Bird | 62 |

---

## Lapras

**Availability**
- Resevoir Cave
- Route 115
- Route 129
- Route 131
- Route 134
- Route 135
- Shoal Cave Lowtideentranceroom
- Shoal Cave Lowtideinnerroom
- Shoal Cave Lowtidelowerroom
- Shoal Cave Lowtidestairsroom

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Sing | 1 |
| Water Gun | 1 |
| Mist | 7 |
| Body Slam | 13 |
| Confuse Ray | 19 |
| Perish Song | 25 |
| Ice Beam | 31 |
| Rain Dance | 37 |
| Safeguard | 43 |
| Hydro Pump | 49 |
| Sheer Cold | 55 |

---

## Ditto

**Availability**
- Desertunder Pass
- Route 113

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Transform | 1 |

---

## Eevee

**Availability**
- Route 113
- Route 115

**Evolves to**
- Jolteon (Use Thunder Stone)
- Vaporeon (Use Water Stone)
- Flareon (Use Fire Stone)
- Espeon (High friendship (Day))
- Umbreon (High friendship (Night))

**Learnset**

| Move | Level |
|------|-------|
| Helping Hand | 1 |
| Tackle | 1 |
| Tail Whip | 1 |
| Sand Attack | 8 |
| Growl | 16 |
| Quick Attack | 23 |
| Bite | 30 |
| Baton Pass | 36 |
| Take Down | 42 |

---

## Vaporeon

**Availability**
- Route 129
- Evolve Eevee (Use Water Stone)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Helping Hand | 1 |
| Tackle | 1 |
| Tail Whip | 1 |
| Sand Attack | 8 |
| Water Gun | 16 |
| Quick Attack | 23 |
| Bite | 30 |
| Aurora Beam | 36 |
| Haze | 42 |
| Acid Armor | 47 |
| Hydro Pump | 52 |

---

## Jolteon

**Availability**
- Evolve Eevee (Use Thunder Stone)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Helping Hand | 1 |
| Tackle | 1 |
| Tail Whip | 1 |
| Sand Attack | 8 |
| Thunder Shock | 16 |
| Quick Attack | 23 |
| Double Kick | 30 |
| Pin Missile | 36 |
| Thunder Wave | 42 |
| Agility | 47 |
| Thunder | 52 |

---

## Flareon

**Availability**
- Evolve Eevee (Use Fire Stone)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Helping Hand | 1 |
| Tackle | 1 |
| Tail Whip | 1 |
| Sand Attack | 8 |
| Ember | 16 |
| Quick Attack | 23 |
| Bite | 30 |
| Fire Spin | 36 |
| Smog | 42 |
| Leer | 47 |
| Flamethrower | 52 |

---

## Porygon

**Availability**
- Route 115
- Route 135

**Evolves to**
- Porygon2 (Level 25)

**Learnset**

| Move | Level |
|------|-------|
| Conversion | 1 |
| Conversion 2 | 1 |
| Tackle | 1 |
| Agility | 9 |
| Psybeam | 12 |
| Recover | 20 |
| Sharpen | 24 |
| Lock On | 32 |
| Tri Attack | 36 |
| Recycle | 44 |
| Zap Cannon | 48 |

---

## Porygonz

**Availability**
- Evolve Porygon2 (Level 40)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| (none found) | - |

---

## Omanyte

**Availability**
- Route 106
- Route 128
- Route 136

**Evolves to**
- Omastar (Level 30)

**Learnset**

| Move | Level |
|------|-------|
| Constrict | 1 |
| Withdraw | 1 |
| Bite | 13 |
| Water Gun | 19 |
| Mud Shot | 25 |
| Leer | 31 |
| Protect | 37 |
| Tickle | 43 |
| Ancient Power | 49 |
| Hydro Pump | 55 |

---

## Omastar

**Availability**
- Evolve Omanyte (Level 30)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Bite | 1 |
| Constrict | 1 |
| Withdraw | 1 |
| Bite | 13 |
| Water Gun | 19 |
| Mud Shot | 25 |
| Flash Cannon | 31 |
| Protect | 37 |
| Spike Cannon | 40 |
| Tickle | 46 |
| Ancient Power | 55 |
| Hydro Pump | 65 |

---

## Kabuto

**Availability**
- Route 108
- Route 115
- Route 136

**Evolves to**
- Kabutops (Level 30)

**Learnset**

| Move | Level |
|------|-------|
| Harden | 1 |
| Scratch | 1 |
| Absorb | 13 |
| Leer | 19 |
| Mud Shot | 25 |
| Sand Attack | 31 |
| Endure | 37 |
| Night Slash | 43 |
| Mega Drain | 49 |
| Ancient Power | 55 |

---

## Kabutops

**Availability**
- Route 128
- Seafloor Cavern Room 2
- Victoryroad 1F
- Evolve Kabuto (Level 30)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Absorb | 1 |
| Harden | 1 |
| Scratch | 1 |
| Absorb | 13 |
| Leer | 19 |
| Mud Shot | 25 |
| Sand Attack | 31 |
| Cross Poison | 34 |
| Endure | 37 |
| Slash | 40 |
| Night Slash | 46 |
| Needle Arm | 55 |
| Ancient Power | 65 |

---

## Aerodactyl

**Availability**
- Route 115
- Seafloor Cavern Room 1
- Seafloor Cavern Room 2

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Wing Attack | 1 |
| Agility | 8 |
| Bite | 15 |
| Supersonic | 22 |
| Rock Slide | 29 |
| Iron Head | 36 |
| Take Down | 43 |
| Hyper Beam | 50 |
| Brave Bird | 56 |

---

## Snorlax

**Availability**
- Route 120
- Skypillar 3F

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Tackle | 1 |
| Amnesia | 6 |
| Defense Curl | 10 |
| Belly Drum | 15 |
| Headbutt | 19 |
| Yawn | 24 |
| Rest | 28 |
| Snore | 28 |
| Body Slam | 33 |
| Block | 37 |
| Iron Head | 42 |
| Rollout | 46 |
| Hyper Beam | 51 |

---

## Articuno

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Gust | 1 |
| Powder Snow | 1 |
| Mist | 13 |
| Agility | 25 |
| Mind Reader | 37 |
| Ice Beam | 49 |
| Reflect | 61 |
| Blizzard | 73 |
| Sheer Cold | 85 |

---

## Zapdos

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Peck | 1 |
| Thunder Shock | 1 |
| Thunder Wave | 13 |
| Agility | 25 |
| Detect | 37 |
| Drill Peck | 49 |
| Power Gem | 61 |
| Light Screen | 73 |
| Thunder | 85 |

---

## Moltres

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Ember | 1 |
| Wing Attack | 1 |
| Fire Spin | 13 |
| Agility | 25 |
| Endure | 37 |
| Flamethrower | 49 |
| Safeguard | 61 |
| Heat Wave | 73 |
| Sky Attack | 85 |

---

## Dratini

**Availability**
- Route 102
- Route 105
- Route 127
- Route 136
- Victoryroad B 2F

**Evolves to**
- Dragonair (Level 30)

**Learnset**

| Move | Level |
|------|-------|
| Leer | 1 |
| Wrap | 1 |
| Thunder Wave | 8 |
| Twister | 15 |
| Dragon Rage | 22 |
| Slam | 29 |
| Agility | 36 |
| Safeguard | 43 |
| Outrage | 50 |
| Hyper Beam | 57 |

---

## Dragonair

**Availability**
- Victoryroad B 2F
- Evolve Dratini (Level 30)

**Evolves to**
- Dragonite (Level 50)

**Learnset**

| Move | Level |
|------|-------|
| Leer | 1 |
| Thunder Wave | 1 |
| Twister | 1 |
| Wrap | 1 |
| Thunder Wave | 8 |
| Twister | 15 |
| Dragon Rage | 22 |
| Slam | 29 |
| Agility | 38 |
| Safeguard | 47 |
| Outrage | 56 |
| Hyper Beam | 65 |

---

## Dragonite

**Availability**
- Evolve Dragonair (Level 50)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Leer | 1 |
| Thunder Wave | 1 |
| Twister | 1 |
| Wrap | 1 |
| Thunder Wave | 8 |
| Twister | 15 |
| Dragon Rage | 22 |
| Slam | 29 |
| Agility | 38 |
| Safeguard | 47 |
| Wing Attack | 55 |
| Dragon Claw | 61 |
| Zen Headbutt | 68 |
| Hyper Beam | 75 |

---

## Mewtwo

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Confusion | 1 |
| Disable | 1 |
| Barrier | 11 |
| Swift | 22 |
| Psych Up | 33 |
| Future Sight | 44 |
| Mist | 55 |
| Psychic | 66 |
| Dark Pulse | 77 |
| Recover | 88 |
| Aura Sphere | 99 |

---

## Mew

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Pound | 1 |
| Transform | 10 |
| Mega Punch | 20 |
| Metronome | 30 |
| Psychic | 40 |
| Ancient Power | 50 |

---

## Chikorita

**Availability**
- Route 103

**Evolves to**
- Bayleef (Level 16)

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Tackle | 1 |
| Razor Leaf | 8 |
| Reflect | 12 |
| Poison Powder | 15 |
| Synthesis | 22 |
| Body Slam | 29 |
| Light Screen | 36 |
| Safeguard | 43 |
| Solar Beam | 50 |

---

## Bayleef

**Availability**
- Route 119
- Evolve Chikorita (Level 16)

**Evolves to**
- Meganium (Level 32)

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Razor Leaf | 1 |
| Reflect | 1 |
| Tackle | 1 |
| Razor Leaf | 8 |
| Reflect | 12 |
| Poison Powder | 15 |
| Psybeam | 19 |
| Synthesis | 23 |
| Body Slam | 31 |
| Psychic | 39 |
| Safeguard | 47 |
| Solar Beam | 55 |

---

## Meganium

**Availability**
- Evolve Bayleef (Level 32)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Razor Leaf | 1 |
| Reflect | 1 |
| Tackle | 1 |
| Razor Leaf | 8 |
| Reflect | 12 |
| Poison Powder | 15 |
| Psybeam | 23 |
| Synthesis | 23 |
| Body Slam | 31 |
| Energy Ball | 39 |
| Psychic | 39 |
| Safeguard | 47 |
| Solar Beam | 55 |

---

## Cyndaquil

**Availability**
- Fiery Path
- Route 112
- Scorched Slab

**Evolves to**
- Quilava (Level 14)

**Learnset**

| Move | Level |
|------|-------|
| Leer | 1 |
| Tackle | 1 |
| Smokescreen | 6 |
| Ember | 12 |
| Quick Attack | 19 |
| Flame Wheel | 27 |
| Swift | 36 |
| Flamethrower | 46 |

---

## Quilava

**Availability**
- Route 115
- Evolve Cyndaquil (Level 14)

**Evolves to**
- Typhlosion (Level 36)

**Learnset**

| Move | Level |
|------|-------|
| Leer | 1 |
| Smokescreen | 1 |
| Tackle | 1 |
| Smokescreen | 6 |
| Ember | 12 |
| Quick Attack | 21 |
| Astonish | 24 |
| Flame Wheel | 27 |
| Swift | 42 |
| Flamethrower | 54 |

---

## Typhlosion

**Availability**
- Evolve Quilava (Level 36)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Ember | 1 |
| Leer | 1 |
| Smokescreen | 1 |
| Tackle | 1 |
| Smokescreen | 6 |
| Ember | 12 |
| Quick Attack | 21 |
| Astonish | 24 |
| Flame Wheel | 31 |
| Shadow Claw | 36 |
| Flamethrower | 39 |
| Zen Headbutt | 47 |
| Belly Drum | 51 |

---

## Totodile

**Availability**
- Route 103

**Evolves to**
- Croconaw (Level 18)

**Learnset**

| Move | Level |
|------|-------|
| Leer | 1 |
| Scratch | 1 |
| Rage | 7 |
| Water Gun | 13 |
| Bite | 20 |
| Scary Face | 27 |
| Slash | 35 |
| Screech | 43 |
| Hydro Pump | 52 |

---

## Croconaw

**Availability**
- Route 129
- Route 135
- Evolve Totodile (Level 18)

**Evolves to**
- Feraligatr (Level 30)

**Learnset**

| Move | Level |
|------|-------|
| Leer | 1 |
| Rage | 1 |
| Scratch | 1 |
| Rage | 7 |
| Water Gun | 13 |
| Bite | 21 |
| Scary Face | 28 |
| Slash | 37 |
| Crunch | 39 |
| Aqua Jet | 44 |
| Hydro Pump | 55 |

---

## Feraligatr

**Availability**
- Evolve Croconaw (Level 30)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Leer | 1 |
| Rage | 1 |
| Scratch | 1 |
| Water Gun | 1 |
| Rage | 7 |
| Water Gun | 13 |
| Bite | 21 |
| Scary Face | 28 |
| Slash | 37 |
| Crunch | 39 |
| Aqua Jet | 44 |
| Avalanche | 46 |
| Close Combat | 58 |

---

## Sentret

**Availability**
- ???

**Evolves to**
- Furret (Level 15)

**Learnset**

| Move | Level |
|------|-------|
| Scratch | 1 |
| Defense Curl | 4 |
| Quick Attack | 7 |
| Fury Swipes | 12 |
| Helping Hand | 17 |
| Slam | 24 |
| Follow Me | 31 |
| Rest | 40 |
| Amnesia | 49 |

---

## Furret

**Availability**
- Route 136
- Evolve Sentret (Level 15)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Defense Curl | 1 |
| Quick Attack | 1 |
| Scratch | 1 |
| Defense Curl | 4 |
| Quick Attack | 7 |
| Fury Swipes | 12 |
| Helping Hand | 19 |
| Slam | 28 |
| Follow Me | 37 |
| Rest | 48 |
| Amnesia | 59 |

---

## Hoothoot

**Availability**
- Route 116
- Safari Zone Northeast
- Safari Zone Southeast

**Evolves to**
- Noctowl (Level 20)

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Tackle | 1 |
| Foresight | 6 |
| Peck | 11 |
| Hypnosis | 16 |
| Reflect | 22 |
| Take Down | 28 |
| Confusion | 34 |
| Dream Eater | 48 |

---

## Noctowl

**Availability**
- Evolve Hoothoot (Level 20)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Foresight | 1 |
| Growl | 1 |
| Peck | 1 |
| Tackle | 1 |
| Foresight | 6 |
| Peck | 11 |
| Hypnosis | 16 |
| Reflect | 25 |
| Take Down | 33 |
| Confusion | 41 |
| Dream Eater | 47 |
| Aeroblast | 58 |

---

## Ledyba

**Availability**
- Safari Zone Northeast

**Evolves to**
- Ledian (Level 18)

**Learnset**

| Move | Level |
|------|-------|
| Tackle | 1 |
| Supersonic | 8 |
| Comet Punch | 15 |
| Light Screen | 22 |
| Reflect | 22 |
| Safeguard | 22 |
| Baton Pass | 29 |
| Swift | 36 |
| Agility | 43 |
| Double Edge | 50 |

---

## Ledian

**Availability**
- Route 135
- Evolve Ledyba (Level 18)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Supersonic | 1 |
| Tackle | 1 |
| Supersonic | 8 |
| Comet Punch | 15 |
| Light Screen | 24 |
| Reflect | 24 |
| Safeguard | 24 |
| Baton Pass | 33 |
| Swift | 42 |
| Agility | 51 |
| Double Edge | 60 |

---

## Spinarak

**Availability**
- Safari Zone Southeast

**Evolves to**
- Ariados (Level 22)

**Learnset**

| Move | Level |
|------|-------|
| Poison Sting | 1 |
| String Shot | 1 |
| Scary Face | 6 |
| Constrict | 11 |
| Night Shade | 17 |
| Leech Life | 23 |
| Fury Swipes | 30 |
| Xscissor | 34 |
| Cross Poison | 38 |
| Spider Web | 43 |
| Zen Headbutt | 53 |

---

## Ariados

**Availability**
- Route 121
- Route 135
- Evolve Spinarak (Level 22)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Constrict | 1 |
| Light Screen | 1 |
| Poison Sting | 1 |
| Reflect | 1 |
| Scary Face | 1 |
| String Shot | 1 |
| Scary Face | 6 |
| Constrict | 11 |
| Night Shade | 17 |
| Leech Life | 25 |
| Xscissor | 34 |
| Cross Poison | 38 |
| Spider Web | 43 |
| Zen Headbutt | 53 |

---

## Crobat

**Availability**
- Advent Cave
- Evolve Golbat (High friendship)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Astonish | 1 |
| Leech Life | 1 |
| Screech | 1 |
| Supersonic | 1 |
| Supersonic | 6 |
| Astonish | 11 |
| Bite | 16 |
| Wing Attack | 21 |
| Confuse Ray | 28 |
| Air Cutter | 35 |
| Mean Look | 42 |
| Poison Fang | 49 |
| Cross Poison | 52 |
| Haze | 56 |
| Brave Bird | 58 |

---

## Chinchou

**Availability**
- Route 107
- Route 110
- Route 132
- Underwater Route 124
- Underwater Route 126

**Evolves to**
- Lanturn (Level 27)

**Learnset**

| Move | Level |
|------|-------|
| Bubble | 1 |
| Thunder Wave | 1 |
| Supersonic | 5 |
| Flail | 13 |
| Water Gun | 17 |
| Spark | 25 |
| Confuse Ray | 29 |
| Take Down | 37 |
| Hydro Pump | 41 |
| Charge | 49 |

---

## Lanturn

**Availability**
- Route 135
- Route 136
- Evolve Chinchou (Level 27)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Bubble | 1 |
| Supersonic | 1 |
| Thunder Wave | 1 |
| Supersonic | 5 |
| Flail | 13 |
| Water Gun | 17 |
| Spark | 25 |
| Confuse Ray | 32 |
| Thunderbolt | 37 |
| Take Down | 43 |
| Hydro Pump | 50 |
| Earth Power | 61 |

---

## Pichu

**Availability**
- ???

**Evolves to**
- Pikachu (High friendship)

**Learnset**

| Move | Level |
|------|-------|
| Charm | 1 |
| Thunder Shock | 1 |
| Tail Whip | 6 |
| Thunder Wave | 8 |
| Sweet Kiss | 11 |

---

## Cleffa

**Availability**
- Route 136

**Evolves to**
- Clefairy (High friendship)

**Learnset**

| Move | Level |
|------|-------|
| Charm | 1 |
| Pound | 1 |
| Encore | 4 |
| Sing | 8 |
| Sweet Kiss | 13 |

---

## Igglybuff

**Availability**
- ???

**Evolves to**
- Jigglypuff (High friendship)

**Learnset**

| Move | Level |
|------|-------|
| Charm | 1 |
| Sing | 1 |
| Defense Curl | 4 |
| Pound | 9 |
| Sweet Kiss | 14 |

---

## Togepi

**Availability**
- Route 101
- Rusturf Tunnel

**Evolves to**
- Togetic (Level 20)

**Learnset**

| Move | Level |
|------|-------|
| Charm | 1 |
| Growl | 1 |
| Metronome | 6 |
| Sweet Kiss | 11 |
| Yawn | 16 |
| Encore | 21 |
| Follow Me | 26 |
| Wish | 31 |
| Safeguard | 36 |
| Double Edge | 41 |

---

## Togetic

**Availability**
- Route 116
- Evolve Togepi (Level 20)

**Evolves to**
- Togekiss (Level 40)

**Learnset**

| Move | Level |
|------|-------|
| Charm | 1 |
| Growl | 1 |
| Metronome | 6 |
| Sweet Kiss | 11 |
| Yawn | 16 |
| Encore | 21 |
| Follow Me | 26 |
| Wish | 31 |
| Safeguard | 36 |
| Double Edge | 41 |

---

## Togekiss

**Availability**
- Evolve Togetic (Level 40)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Charm | 1 |
| Growl | 1 |
| Metronome | 6 |
| Sweet Kiss | 11 |
| Yawn | 16 |
| Encore | 21 |
| Follow Me | 26 |
| Wish | 31 |
| Aeroblast | 40 |
| Double Edge | 41 |
| Aurora Beam | 45 |
| Sacred Fire | 48 |
| Aeroblast | 54 |
| Energy Ball | 63 |
| Earth Power | 68 |

---

## Natu

**Availability**
- Route 116
- Safari Zone North
- Safari Zone South
- Safari Zone Southwest

**Evolves to**
- Xatu (Level 25)

**Learnset**

| Move | Level |
|------|-------|
| Leer | 1 |
| Peck | 1 |
| Night Shade | 10 |
| Teleport | 20 |
| Future Sight | 30 |
| Wish | 30 |
| Confuse Ray | 40 |
| Psychic | 50 |

---

## Xatu

**Availability**
- Safari Zone North
- Evolve Natu (Level 25)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Leer | 1 |
| Peck | 1 |
| Night Shade | 10 |
| Teleport | 20 |
| Future Sight | 35 |
| Wish | 35 |
| Psychic | 45 |
| Confuse Ray | 50 |
| Aeroblast | 60 |

---

## Mareep

**Availability**
- Altering Cave 2
- Route 110
- Safari Zone Southeast

**Evolves to**
- Flaaffy (Level 15)

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Tackle | 1 |
| Thunder Shock | 9 |
| Thunder Wave | 16 |
| Cotton Spore | 23 |
| Light Screen | 30 |
| Thunder | 37 |

---

## Flaaffy

**Availability**
- Evolve Mareep (Level 15)

**Evolves to**
- Ampharos (Level 30)

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Tackle | 1 |
| Thunder Shock | 1 |
| Thunder Shock | 9 |
| Thunder Wave | 18 |
| Cotton Spore | 27 |
| Light Screen | 36 |
| Thunder | 45 |

---

## Ampharos

**Availability**
- Evolve Flaaffy (Level 30)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Tackle | 1 |
| Thunder Shock | 1 |
| Thunder Wave | 1 |
| Thunder Shock | 9 |
| Thunder Wave | 18 |
| Nasty Plot | 27 |
| Thunderbolt | 30 |
| Light Screen | 42 |
| Dragon Pulse | 44 |
| Tail Glow | 50 |
| Thunder | 57 |

---

## Bellossom

**Availability**
- Evolve Gloom (Use Sun Stone)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Absorb | 1 |
| Magical Leaf | 1 |
| Stun Spore | 1 |
| Sweet Scent | 1 |
| Poison Powder | 14 |
| Stun Spore | 16 |
| Sleep Powder | 18 |
| Acid | 24 |
| Moonlight | 35 |
| Flamethrower | 44 |
| Leaf Storm | 44 |
| Solar Beam | 55 |

---

## Marill

**Availability**
- Petalburg City
- Route 102
- Route 104
- Route 111
- Route 112
- Route 114
- Route 117
- Route 120
- Safari Zone Southeast
- Evolve Azurill (High friendship)

**Evolves to**
- Azumarill (Level 18)

**Learnset**

| Move | Level |
|------|-------|
| Tackle | 1 |
| Defense Curl | 3 |
| Tail Whip | 6 |
| Water Gun | 10 |
| Rollout | 15 |
| Bubble Beam | 21 |
| Double Edge | 28 |
| Rain Dance | 36 |
| Hydro Pump | 45 |

---

## Azumarill

**Availability**
- Evolve Marill (Level 18)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Defense Curl | 1 |
| Tackle | 1 |
| Tail Whip | 1 |
| Water Gun | 1 |
| Defense Curl | 3 |
| Tail Whip | 6 |
| Water Gun | 10 |
| Rollout | 15 |
| Bubble Beam | 24 |
| Double Edge | 34 |
| Rain Dance | 45 |
| Hydro Pump | 57 |

---

## Sudowoodo

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Mimic | 1 |
| Rock Throw | 1 |
| Flail | 9 |
| Low Kick | 17 |
| Rock Slide | 25 |
| Block | 33 |
| Faint Attack | 41 |
| Slam | 49 |
| Double Edge | 57 |

---

## Politoed

**Availability**
- Evolve Poliwhirl (Use Sun Stone)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Double Slap | 1 |
| Hypnosis | 1 |
| Perish Song | 1 |
| Water Gun | 1 |
| Perish Song | 35 |
| Swagger | 51 |

---

## Hoppip

**Availability**
- Route 119

**Evolves to**
- Skiploom (Level 18)

**Learnset**

| Move | Level |
|------|-------|
| Splash | 1 |
| Synthesis | 5 |
| Tail Whip | 5 |
| Tackle | 10 |
| Poison Powder | 13 |
| Stun Spore | 15 |
| Sleep Powder | 17 |
| Leech Seed | 20 |
| Cotton Spore | 25 |
| Mega Drain | 30 |

---

## Skiploom

**Availability**
- Route 134
- Evolve Hoppip (Level 18)

**Evolves to**
- Jumpluff (Level 27)

**Learnset**

| Move | Level |
|------|-------|
| Splash | 1 |
| Synthesis | 1 |
| Tackle | 1 |
| Tail Whip | 1 |
| Synthesis | 5 |
| Tail Whip | 5 |
| Tackle | 10 |
| Poison Powder | 13 |
| Stun Spore | 15 |
| Sleep Powder | 17 |
| Leech Seed | 22 |
| Cotton Spore | 29 |
| Mega Drain | 36 |

---

## Jumpluff

**Availability**
- Evolve Skiploom (Level 27)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Splash | 1 |
| Synthesis | 1 |
| Tackle | 1 |
| Tail Whip | 1 |
| Synthesis | 5 |
| Tail Whip | 5 |
| Tackle | 10 |
| Poison Powder | 13 |
| Stun Spore | 15 |
| Sleep Powder | 17 |
| Leech Seed | 22 |
| Cotton Spore | 33 |
| Mega Drain | 44 |

---

## Aipom

**Availability**
- Altering Cave 6
- Route 119
- Safari Zone Northeast
- Safari Zone Southeast

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Scratch | 1 |
| Tail Whip | 1 |
| Sand Attack | 6 |
| Astonish | 13 |
| Baton Pass | 18 |
| Tickle | 25 |
| Fury Swipes | 31 |
| Swift | 38 |
| Screech | 43 |
| Agility | 50 |

---

## Sunkern

**Availability**
- Route 119
- Safari Zone Northeast
- Safari Zone Southeast

**Evolves to**
- Sunflora (Use Sun Stone)

**Learnset**

| Move | Level |
|------|-------|
| Absorb | 1 |
| Growth | 6 |
| Mega Drain | 13 |
| Ingrain | 18 |
| Endeavor | 25 |
| Sunny Day | 30 |
| Synthesis | 37 |
| Giga Drain | 42 |

---

## Sunflora

**Availability**
- Evolve Sunkern (Use Sun Stone)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Absorb | 1 |
| Pound | 1 |
| Growth | 6 |
| Razor Leaf | 13 |
| Ingrain | 18 |
| Bullet Seed | 25 |
| Sunny Day | 30 |
| Petal Dance | 37 |
| Solar Beam | 42 |

---

## Yanma

**Availability**
- Route 134

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Foresight | 1 |
| Tackle | 1 |
| Quick Attack | 7 |
| Double Team | 13 |
| Sonic Boom | 19 |
| Detect | 25 |
| Supersonic | 31 |
| Uproar | 37 |
| Wing Attack | 43 |
| Screech | 49 |

---

## Wooper

**Availability**
- Route 107
- Route 111
- Route 136
- Safari Zone Southeast

**Evolves to**
- Quagsire (Level 20)

**Learnset**

| Move | Level |
|------|-------|
| Tail Whip | 1 |
| Water Gun | 1 |
| Slam | 11 |
| Mud Shot | 16 |
| Amnesia | 21 |
| Yawn | 31 |
| Earthquake | 36 |
| Rain Dance | 41 |
| Haze | 51 |
| Mist | 51 |

---

## Quagsire

**Availability**
- Route 129
- Route 134
- Safari Zone Southeast
- Evolve Wooper (Level 20)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Tail Whip | 1 |
| Water Gun | 1 |
| Slam | 11 |
| Mud Shot | 16 |
| Amnesia | 23 |
| Yawn | 35 |
| Earthquake | 42 |
| Rain Dance | 49 |
| Haze | 61 |
| Mist | 61 |

---

## Espeon

**Availability**
- Evolve Eevee (High friendship (Day))

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Helping Hand | 1 |
| Tackle | 1 |
| Tail Whip | 1 |
| Sand Attack | 8 |
| Confusion | 16 |
| Quick Attack | 23 |
| Swift | 30 |
| Psybeam | 36 |
| Psych Up | 42 |
| Psychic | 47 |
| Morning Sun | 52 |
| Earth Power | 58 |
| Energy Ball | 58 |

---

## Umbreon

**Availability**
- Evolve Eevee (High friendship (Night))

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Helping Hand | 1 |
| Tackle | 1 |
| Tail Whip | 1 |
| Sand Attack | 8 |
| Pursuit | 16 |
| Quick Attack | 23 |
| Confuse Ray | 30 |
| Faint Attack | 36 |
| Mean Look | 42 |
| Dark Pulse | 47 |
| Moonlight | 52 |
| Power Gem | 58 |

---

## Murkrow

**Availability**
- Granite Cave B 1F
- Granite Cave B 2F
- Mtpyre 1F
- Mtpyre 2F
- Mtpyre 3F
- Mtpyre 4F
- Mtpyre 5F
- Mtpyre 6F
- Victoryroad 1F

**Evolves to**
- Honchkrow (Level 30)

**Learnset**

| Move | Level |
|------|-------|
| Peck | 1 |
| Astonish | 9 |
| Pursuit | 14 |
| Haze | 22 |
| Faint Attack | 23 |
| Night Shade | 27 |
| Dark Pulse | 35 |
| Taunt | 40 |
| Mean Look | 48 |
| Brave Bird | 52 |

---

## Honchkrow

**Availability**
- Evolve Murkrow (Level 30)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Peck | 1 |
| Astonish | 9 |
| Pursuit | 14 |
| Haze | 22 |
| Faint Attack | 23 |
| Night Shade | 27 |
| Dark Pulse | 35 |
| Taunt | 40 |
| Mean Look | 48 |
| Brave Bird | 52 |

---

## Slowking

**Availability**
- Evolve Slowpoke (Use Water Stone)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Curse | 1 |
| Tackle | 1 |
| Yawn | 1 |
| Growl | 6 |
| Water Gun | 15 |
| Confusion | 20 |
| Disable | 29 |
| Headbutt | 34 |
| Swagger | 43 |
| Psychic | 48 |
| Bug Buzz | 52 |
| Calm Mind | 60 |

---

## Misdreavus

**Availability**
- Granite Cave B 1F
- Granite Cave B 2F
- Mtpyre 1F
- Mtpyre 2F
- Mtpyre 3F
- Mtpyre 4F
- Mtpyre 5F
- Mtpyre 6F

**Evolves to**
- Mismagius (Level 30)

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Psywave | 1 |
| Spite | 6 |
| Astonish | 11 |
| Confuse Ray | 17 |
| Psybeam | 23 |
| Magical Leaf | 26 |
| Pain Split | 30 |
| Shadow Ball | 33 |
| Power Gem | 37 |
| Perish Song | 45 |
| Grudge | 53 |

---

## Mismagius

**Availability**
- Evolve Misdreavus (Level 30)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Psywave | 1 |
| Spite | 6 |
| Astonish | 11 |
| Confuse Ray | 17 |
| Psybeam | 23 |
| Magical Leaf | 26 |
| Pain Split | 30 |
| Shadow Ball | 33 |
| Power Gem | 37 |
| Perish Song | 45 |
| Grudge | 53 |

---

## Unown

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Hidden Power | 1 |

---

## Wobbuffet

**Availability**
- Battlepike 4
- Safari Zone South
- Safari Zone Southwest
- Evolve Wynaut (Level 15)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Counter | 1 |
| Destiny Bond | 1 |
| Mirror Coat | 1 |
| Safeguard | 1 |

---

## Girafarig

**Availability**
- Safari Zone South
- Safari Zone Southwest

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Tackle | 1 |
| Astonish | 7 |
| Confusion | 13 |
| Stomp | 19 |
| Odor Sleuth | 25 |
| Agility | 31 |
| Baton Pass | 37 |
| Psybeam | 43 |
| Crunch | 49 |

---

## Pineco

**Availability**
- Altering Cave 3
- Granite Cave B 2F
- Route 116
- Safari Zone Northeast

**Evolves to**
- Forretress (Level 31)

**Learnset**

| Move | Level |
|------|-------|
| Protect | 1 |
| Tackle | 1 |
| Self Destruct | 8 |
| Take Down | 15 |
| Rapid Spin | 22 |
| Bide | 29 |
| Explosion | 36 |
| Spikes | 43 |
| Double Edge | 50 |

---

## Forretress

**Availability**
- Evolve Pineco (Level 31)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Protect | 1 |
| Self Destruct | 1 |
| Tackle | 1 |
| Self Destruct | 8 |
| Take Down | 15 |
| Rapid Spin | 22 |
| Bide | 29 |
| Explosion | 39 |
| Spikes | 49 |
| Double Edge | 59 |

---

## Dunsparce

**Availability**
- Route 136

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Rage | 1 |
| Defense Curl | 4 |
| Yawn | 11 |
| Glare | 14 |
| Spite | 21 |
| Pursuit | 24 |
| Screech | 31 |
| Take Down | 34 |
| Endeavor | 41 |

---

## Gligar

**Availability**
- Route 121
- Route 135
- Safari Zone Southeast

**Evolves to**
- Gliscor (Level 34)

**Learnset**

| Move | Level |
|------|-------|
| Poison Sting | 1 |
| Sand Attack | 6 |
| Harden | 13 |
| Quick Attack | 20 |
| Thunder Fang | 24 |
| Faint Attack | 28 |
| Xscissor | 30 |
| Night Slash | 33 |
| Slash | 36 |
| Poison Jab | 40 |
| Fire Fang | 44 |
| Ice Fang | 48 |
| Swords Dance | 52 |

---

## Gliscor

**Availability**
- Evolve Gligar (Level 34)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Poison Sting | 1 |
| Sand Attack | 6 |
| Harden | 13 |
| Quick Attack | 20 |
| Thunder Fang | 24 |
| Faint Attack | 28 |
| Xscissor | 30 |
| Night Slash | 33 |
| Slash | 36 |
| Poison Jab | 40 |
| Fire Fang | 44 |
| Ice Fang | 48 |
| Swords Dance | 52 |

---

## Steelix

**Availability**
- Evolve Onix (Level 36)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Screech | 1 |
| Tackle | 1 |
| Bind | 9 |
| Rock Throw | 13 |
| Harden | 21 |
| Rage | 25 |
| Sandstorm | 33 |
| Slam | 37 |
| Iron Tail | 45 |
| Crunch | 49 |
| Double Edge | 57 |

---

## Snubbull

**Availability**
- Safari Zone Southeast

**Evolves to**
- Granbull (Level 23)

**Learnset**

| Move | Level |
|------|-------|
| Scary Face | 1 |
| Tackle | 1 |
| Tail Whip | 4 |
| Charm | 8 |
| Bite | 13 |
| Lick | 19 |
| Roar | 26 |
| Rage | 34 |
| Take Down | 43 |
| Crunch | 53 |

---

## Granbull

**Availability**
- Evolve Snubbull (Level 23)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Scary Face | 1 |
| Tackle | 1 |
| Tail Whip | 4 |
| Charm | 8 |
| Bite | 13 |
| Lick | 19 |
| Roar | 28 |
| Rage | 38 |
| Take Down | 49 |
| Crunch | 61 |

---

## Qwilfish

**Availability**
- Route 134
- Route 136

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Poison Sting | 1 |
| Spikes | 1 |
| Tackle | 1 |
| Harden | 10 |
| Minimize | 10 |
| Water Gun | 19 |
| Pin Missile | 28 |
| Take Down | 37 |
| Hydro Pump | 46 |

---

## Scizor

**Availability**
- Evolve Scyther (Level 36)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Leer | 1 |
| Quick Attack | 1 |
| Focus Energy | 6 |
| Pursuit | 11 |
| False Swipe | 16 |
| Agility | 21 |
| Bullet Punch | 26 |
| Slash | 31 |
| Swords Dance | 36 |
| Xscissor | 38 |
| Double Team | 41 |
| Fury Cutter | 46 |
| Mach Punch | 50 |

---

## Shuckle

**Availability**
- Altering Cave 7
- Safari Zone Northeast

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Constrict | 1 |
| Withdraw | 1 |
| Wrap | 9 |
| Encore | 14 |
| Safeguard | 23 |
| Bide | 28 |
| Rest | 37 |

---

## Heracross

**Availability**
- Route 121
- Route 135
- Safari Zone North

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Leer | 1 |
| Tackle | 1 |
| Horn Attack | 6 |
| Endure | 11 |
| Fury Attack | 17 |
| Brick Break | 23 |
| Counter | 30 |
| Take Down | 37 |
| Reversal | 45 |
| Megahorn | 53 |
| Close Combat | 58 |

---

## Sneasel

**Availability**
- Mtpyre Summit
- Skypillar 1F

**Evolves to**
- Weaville (Level 34)

**Learnset**

| Move | Level |
|------|-------|
| Leer | 1 |
| Scratch | 1 |
| Taunt | 1 |
| Quick Attack | 8 |
| Screech | 15 |
| Faint Attack | 22 |
| Night Slash | 36 |
| Fake Out | 43 |
| Ice Shard | 43 |
| Slash | 50 |
| Avalanche | 57 |
| Double Edge | 64 |

---

## Weaville

**Availability**
- Evolve Sneasel (Level 34)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Leer | 1 |
| Scratch | 1 |
| Taunt | 1 |
| Quick Attack | 8 |
| Screech | 15 |
| Night Slash | 22 |
| Ice Shard | 33 |
| Avalanche | 36 |
| Fake Out | 43 |
| Double Edge | 50 |

---

## Teddiursa

**Availability**
- Altering Cave 5
- Route 101
- Route 117
- Rusturf Tunnel
- Safari Zone Northeast

**Evolves to**
- Ursaring (Level 30)

**Learnset**

| Move | Level |
|------|-------|
| Leer | 1 |
| Scratch | 1 |
| Lick | 7 |
| Fury Swipes | 13 |
| Fake Tears | 19 |
| Faint Attack | 25 |
| Rest | 31 |
| Slash | 37 |
| Snore | 43 |
| Thrash | 49 |

---

## Ursaring

**Availability**
- Evolve Teddiursa (Level 30)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Fury Swipes | 1 |
| Leer | 1 |
| Lick | 1 |
| Scratch | 1 |
| Lick | 7 |
| Fury Swipes | 13 |
| Fake Tears | 19 |
| Night Slash | 25 |
| Rest | 31 |
| Slash | 37 |
| Snore | 43 |
| Thrash | 49 |

---

## Slugma

**Availability**
- Fiery Path
- Route 113

**Evolves to**
- Magcargo (Level 38)

**Learnset**

| Move | Level |
|------|-------|
| Smog | 1 |
| Yawn | 1 |
| Ember | 8 |
| Rock Throw | 15 |
| Harden | 22 |
| Amnesia | 29 |
| Flamethrower | 36 |
| Rock Slide | 43 |
| Body Slam | 50 |

---

## Magcargo

**Availability**
- Evolve Slugma (Level 38)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Ember | 1 |
| Rock Throw | 1 |
| Smog | 1 |
| Yawn | 1 |
| Ember | 8 |
| Rock Throw | 15 |
| Harden | 22 |
| Amnesia | 29 |
| Flamethrower | 36 |
| Rock Slide | 48 |
| Body Slam | 60 |

---

## Swinub

**Availability**
- Route 111

**Evolves to**
- Piloswine (Level 23)

**Learnset**

| Move | Level |
|------|-------|
| Odor Sleuth | 1 |
| Tackle | 1 |
| Powder Snow | 10 |
| Endure | 19 |
| Take Down | 28 |
| Mist | 37 |
| Blizzard | 46 |
| Amnesia | 55 |

---

## Piloswine

**Availability**
- Seafloor Cavern Room 3
- Seafloor Cavern Room 4
- Evolve Swinub (Level 23)

**Evolves to**
- Mamoswine (Level 40)

**Learnset**

| Move | Level |
|------|-------|
| Endure | 1 |
| Horn Attack | 1 |
| Odor Sleuth | 1 |
| Powder Snow | 1 |
| Powder Snow | 10 |
| Endure | 19 |
| Take Down | 28 |
| Avalanche | 33 |
| Mist | 42 |
| Blizzard | 56 |
| Amnesia | 70 |

---

## Mamoswine

**Availability**
- Evolve Piloswine (Level 40)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Endure | 1 |
| Horn Attack | 1 |
| Odor Sleuth | 1 |
| Powder Snow | 1 |
| Powder Snow | 10 |
| Endure | 19 |
| Take Down | 28 |
| Fury Attack | 33 |
| Ice Fang | 40 |
| Earthquake | 42 |
| Rock Slide | 56 |
| Amnesia | 70 |

---

## Corsola

**Availability**
- Evergrande City
- Route 122
- Route 128

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Tackle | 1 |
| Harden | 6 |
| Bubble | 12 |
| Recover | 17 |
| Refresh | 17 |
| Bubble Beam | 23 |
| Spike Cannon | 28 |
| Rock Blast | 34 |
| Mirror Coat | 39 |
| Ancient Power | 45 |

---

## Remoraid

**Availability**
- Route 125
- Safari Zone Southeast

**Evolves to**
- Octillery (Level 25)

**Learnset**

| Move | Level |
|------|-------|
| Water Gun | 1 |
| Lock On | 11 |
| Aurora Beam | 22 |
| Bubble Beam | 22 |
| Psybeam | 22 |
| Focus Energy | 33 |
| Ice Beam | 44 |
| Hyper Beam | 55 |

---

## Octillery

**Availability**
- Route 110
- Route 122
- Safari Zone Southeast
- Evolve Remoraid (Level 25)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Water Gun | 1 |
| Constrict | 11 |
| Aurora Beam | 22 |
| Bubble Beam | 22 |
| Psybeam | 22 |
| Octazooka | 25 |
| Focus Energy | 38 |
| Ice Beam | 54 |
| Hyper Beam | 70 |

---

## Delibird

**Availability**
- Route 136

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Present | 1 |

---

## Mantine

**Availability**
- Route 122
- Route 125

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Bubble | 1 |
| Tackle | 1 |
| Supersonic | 8 |
| Bubble Beam | 15 |
| Take Down | 22 |
| Agility | 29 |
| Wing Attack | 36 |
| Water Pulse | 43 |
| Confuse Ray | 50 |
| Aeroblast | 60 |

---

## Skarmory

**Availability**
- Route 113

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Leer | 1 |
| Peck | 1 |
| Sand Attack | 10 |
| Swift | 13 |
| Agility | 16 |
| Fury Attack | 26 |
| Air Cutter | 29 |
| Steel Wing | 32 |
| Spikes | 42 |
| Power Gem | 45 |

---

## Houndour

**Availability**
- Altering Cave 4
- Route 112
- Safari Zone Northeast

**Evolves to**
- Houndoom (Level 24)

**Learnset**

| Move | Level |
|------|-------|
| Ember | 1 |
| Leer | 1 |
| Howl | 7 |
| Smog | 13 |
| Roar | 19 |
| Bite | 25 |
| Odor Sleuth | 31 |
| Faint Attack | 37 |
| Flamethrower | 43 |
| Dark Pulse | 49 |

---

## Houndoom

**Availability**
- Evolve Houndour (Level 24)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Ember | 1 |
| Howl | 1 |
| Leer | 1 |
| Howl | 7 |
| Smog | 13 |
| Roar | 19 |
| Bite | 27 |
| Odor Sleuth | 35 |
| Faint Attack | 43 |
| Flamethrower | 51 |
| Dark Pulse | 59 |

---

## Kingdra

**Availability**
- Route 133
- Evolve Seadra (Use Dragon Scale)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Bubble | 1 |
| Leer | 1 |
| Smokescreen | 1 |
| Water Gun | 1 |
| Smokescreen | 8 |
| Leer | 15 |
| Water Gun | 22 |
| Dragon Claw | 29 |
| Aqua Jet | 40 |
| Hydro Pump | 51 |
| Dragon Dance | 62 |

---

## Phanpy

**Availability**
- Granite Cave 1F
- Route 111
- Safari Zone North

**Evolves to**
- Donphan (Level 25)

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Odor Sleuth | 1 |
| Tackle | 1 |
| Defense Curl | 9 |
| Flail | 17 |
| Take Down | 25 |
| Rollout | 33 |
| Endure | 41 |
| Double Edge | 49 |

---

## Donphan

**Availability**
- Evolve Phanpy (Level 25)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Horn Attack | 1 |
| Odor Sleuth | 1 |
| Defense Curl | 9 |
| Flail | 17 |
| Fury Attack | 25 |
| Rollout | 33 |
| Rapid Spin | 41 |
| Earthquake | 49 |

---

## Porygon2

**Availability**
- Evolve Porygon (Level 25)

**Evolves to**
- Porygonz (Level 40)

**Learnset**

| Move | Level |
|------|-------|
| Conversion | 1 |
| Conversion 2 | 1 |
| Tackle | 1 |
| Agility | 9 |
| Psybeam | 12 |
| Recover | 20 |
| Defense Curl | 24 |
| Lock On | 32 |
| Tri Attack | 36 |
| Recycle | 44 |
| Zap Cannon | 48 |

---

## Stantler

**Availability**
- Altering Cave 8
- Safari Zone Southeast

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Tackle | 1 |
| Leer | 7 |
| Astonish | 13 |
| Hypnosis | 19 |
| Stomp | 25 |
| Sand Attack | 31 |
| Take Down | 37 |
| Confuse Ray | 43 |
| Calm Mind | 49 |

---

## Smeargle

**Availability**
- Altering Cave 9
- Artisancave 1F
- Artisancave B 1F

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Sketch | 1 |
| Sketch | 11 |
| Sketch | 21 |
| Sketch | 31 |
| Sketch | 41 |
| Sketch | 51 |
| Sketch | 61 |
| Sketch | 71 |
| Sketch | 81 |
| Sketch | 91 |

---

## Tyrogue

**Availability**
- Granite Cave 1F
- Rusturf Tunnel

**Evolves to**
- Hitmonchan (Level 20 (Atk < Def))
- Hitmonlee (Level 20 (Atk > Def))
- Hitmontop (Level 20 (Atk = Def))

**Learnset**

| Move | Level |
|------|-------|
| Tackle | 1 |
| Karate Chop | 12 |

---

## Hitmontop

**Availability**
- Route 117
- Evolve Tyrogue (Level 20 (Atk = Def))

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Revenge | 1 |
| Rolling Kick | 1 |
| Focus Energy | 7 |
| Pursuit | 13 |
| Quick Attack | 19 |
| Triple Kick | 20 |
| Rapid Spin | 25 |
| Counter | 31 |
| Agility | 37 |
| Detect | 43 |
| Endeavor | 49 |

---

## Smoochum

**Availability**
- Rusturf Tunnel

**Evolves to**
- Jynx (Level 30)

**Learnset**

| Move | Level |
|------|-------|
| Lick | 1 |
| Pound | 1 |
| Sweet Kiss | 9 |
| Powder Snow | 13 |
| Confusion | 17 |
| Sing | 21 |
| Mean Look | 27 |
| Fake Tears | 33 |
| Psychic | 40 |
| Perish Song | 45 |
| Blizzard | 50 |

---

## Elekid

**Availability**
- Rusturf Tunnel

**Evolves to**
- Electabuzz (Level 20)

**Learnset**

| Move | Level |
|------|-------|
| Leer | 1 |
| Quick Attack | 1 |
| Thunder Punch | 9 |
| Light Screen | 17 |
| Swift | 25 |
| Screech | 33 |
| Thunderbolt | 41 |
| Thunder | 49 |

---

## Electivire

**Availability**
- Evolve Electabuzz (Level 36)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Leer | 1 |
| Quick Attack | 1 |
| Thunder Punch | 9 |
| Light Screen | 17 |
| Swift | 25 |
| Screech | 33 |
| Low Kick | 36 |
| Thunder Wave | 36 |
| Thunderbolt | 41 |
| Thunder | 49 |

---

## Magby

**Availability**
- Rusturf Tunnel

**Evolves to**
- Magmar (Level 20)

**Learnset**

| Move | Level |
|------|-------|
| Ember | 1 |
| Leer | 7 |
| Smog | 13 |
| Fire Punch | 16 |
| Smokescreen | 25 |
| Sunny Day | 31 |
| Flamethrower | 37 |
| Confuse Ray | 43 |
| Fire Blast | 49 |

---

## Miltank

**Availability**
- Safari Zone Northeast

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Tackle | 1 |
| Growl | 4 |
| Defense Curl | 8 |
| Stomp | 13 |
| Milk Drink | 19 |
| Bide | 26 |
| Rollout | 34 |
| Body Slam | 43 |
| Heal Bell | 53 |

---

## Blissey

**Availability**
- Evolve Chansey (High friendship)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Pound | 1 |
| Tail Whip | 4 |
| Refresh | 7 |
| Soft Boiled | 10 |
| Double Slap | 13 |
| Minimize | 18 |
| Sing | 23 |
| Egg Bomb | 28 |
| Defense Curl | 33 |
| Light Screen | 40 |
| Double Edge | 47 |

---

## Raikou

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Bite | 1 |
| Leer | 1 |
| Thunder Fang | 11 |
| Quick Attack | 21 |
| Fire Fang | 24 |
| Ice Fang | 28 |
| Roar | 31 |
| Spark | 41 |
| Reflect | 51 |
| Dark Pulse | 61 |
| Thunder | 71 |
| Calm Mind | 81 |

---

## Entei

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Bite | 1 |
| Leer | 1 |
| Ember | 11 |
| Thunder Fang | 11 |
| Fire Spin | 21 |
| Fire Fang | 24 |
| Ice Fang | 28 |
| Roar | 31 |
| Stomp | 41 |
| Flamethrower | 51 |
| Swagger | 61 |
| Fire Blast | 71 |
| Calm Mind | 81 |

---

## Suicune

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Bite | 1 |
| Leer | 1 |
| Water Pulse | 11 |
| Rain Dance | 21 |
| Icy Wind | 28 |
| Gust | 30 |
| Aurora Beam | 41 |
| Mist | 51 |
| Mirror Coat | 61 |
| Hydro Pump | 71 |
| Calm Mind | 81 |

---

## Larvitar

**Availability**
- Advent Cave
- Granite Cave 1F
- Meteor Falls 1F 1R
- Meteor Falls 1F 2R
- Route 111
- Rusturf Tunnel

**Evolves to**
- Pupitar (Level 30)

**Learnset**

| Move | Level |
|------|-------|
| Bite | 1 |
| Leer | 1 |
| Sandstorm | 8 |
| Screech | 15 |
| Rock Slide | 22 |
| Thrash | 29 |
| Scary Face | 36 |
| Crunch | 43 |
| Earthquake | 50 |
| Hyper Beam | 57 |

---

## Pupitar

**Availability**
- Meteor Falls B 1F 1R
- Evolve Larvitar (Level 30)

**Evolves to**
- Tyranitar (Level 50)

**Learnset**

| Move | Level |
|------|-------|
| Bite | 1 |
| Leer | 1 |
| Sandstorm | 1 |
| Screech | 1 |
| Sandstorm | 8 |
| Screech | 15 |
| Rock Slide | 22 |
| Thrash | 29 |
| Scary Face | 38 |
| Crunch | 47 |
| Earthquake | 56 |
| Hyper Beam | 65 |

---

## Tyranitar

**Availability**
- Evolve Pupitar (Level 50)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Bite | 1 |
| Leer | 1 |
| Sandstorm | 1 |
| Screech | 1 |
| Sandstorm | 8 |
| Screech | 15 |
| Rock Slide | 22 |
| Thrash | 29 |
| Iron Head | 38 |
| Crunch | 47 |
| Earthquake | 61 |
| Hyper Beam | 75 |

---

## Lugia

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Whirlwind | 1 |
| Safeguard | 11 |
| Gust | 22 |
| Recover | 33 |
| Hydro Pump | 44 |
| Earth Power | 55 |
| Rain Dance | 55 |
| Swift | 66 |
| Aeroblast | 77 |
| Ancient Power | 88 |
| Future Sight | 99 |

---

## Ho Oh

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Whirlwind | 1 |
| Safeguard | 11 |
| Gust | 22 |
| Recover | 33 |
| Fire Blast | 44 |
| Power Gem | 55 |
| Sunny Day | 55 |
| Swift | 66 |
| Sacred Fire | 77 |
| Ancient Power | 88 |
| Future Sight | 99 |

---

## Celebi

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Confusion | 1 |
| Heal Bell | 1 |
| Leech Seed | 1 |
| Recover | 1 |
| Safeguard | 10 |
| Ancient Power | 20 |
| Future Sight | 30 |
| Energy Ball | 35 |
| Baton Pass | 40 |
| Aura Sphere | 45 |
| Perish Song | 50 |

---

## Old Unown B

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| (none found) | - |

---

## Old Unown C

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| (none found) | - |

---

## Old Unown D

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| (none found) | - |

---

## Old Unown E

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| (none found) | - |

---

## Old Unown♀

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| (none found) | - |

---

## Old Unown G

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| (none found) | - |

---

## Old Unown H

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| (none found) | - |

---

## Old Unown I

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| (none found) | - |

---

## Old Unown J

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| (none found) | - |

---

## Old Unown K

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| (none found) | - |

---

## Old Unown L

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| (none found) | - |

---

## Old Unown♂

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| (none found) | - |

---

## Old Unown N

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| (none found) | - |

---

## Old Unown O

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| (none found) | - |

---

## Old Unown P

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| (none found) | - |

---

## Old Unown Q

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| (none found) | - |

---

## Old Unown R

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| (none found) | - |

---

## Old Unown S

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| (none found) | - |

---

## Old Unown T

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| (none found) | - |

---

## Old Unown U

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| (none found) | - |

---

## Old Unown V

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| (none found) | - |

---

## Old Unown W

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| (none found) | - |

---

## Old Unown X

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| (none found) | - |

---

## Old Unown Y

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| (none found) | - |

---

## Old Unown Z

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| (none found) | - |

---

## Treecko

**Availability**
- ???

**Evolves to**
- Grovyle (Level 16)

**Learnset**

| Move | Level |
|------|-------|
| Leer | 1 |
| Pound | 1 |
| Absorb | 6 |
| Quick Attack | 11 |
| Pursuit | 16 |
| Screech | 21 |
| Mega Drain | 26 |
| Agility | 31 |
| Slam | 36 |
| Detect | 41 |
| Giga Drain | 46 |

---

## Grovyle

**Availability**
- Route 119
- Route 130
- Evolve Treecko (Level 16)

**Evolves to**
- Sceptile (Level 36)

**Learnset**

| Move | Level |
|------|-------|
| Absorb | 1 |
| Leer | 1 |
| Pound | 1 |
| Quick Attack | 1 |
| Absorb | 6 |
| Quick Attack | 11 |
| Fury Cutter | 16 |
| Pursuit | 17 |
| Razor Leaf | 21 |
| Dragon Breath | 23 |
| Leaf Blade | 35 |
| Slam | 41 |
| Detect | 47 |
| False Swipe | 53 |

---

## Sceptile

**Availability**
- Evolve Grovyle (Level 36)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Absorb | 1 |
| Leer | 1 |
| Pound | 1 |
| Quick Attack | 1 |
| Absorb | 6 |
| Quick Attack | 11 |
| Fury Cutter | 16 |
| Pursuit | 17 |
| Dragon Breath | 23 |
| Leaf Blade | 29 |
| Dragon Dance | 36 |
| Dragon Claw | 43 |
| Shadow Claw | 47 |
| Detect | 51 |
| False Swipe | 59 |

---

## Torchic

**Availability**
- Fiery Path
- Route 112
- Route 130
- Scorched Slab

**Evolves to**
- Combusken (Level 16)

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Scratch | 1 |
| Ember | 7 |
| Sand Attack | 10 |
| Peck | 16 |
| Flame Wheel | 19 |
| Fire Spin | 25 |
| Quick Attack | 28 |
| Slash | 34 |
| Mirror Move | 37 |
| Flamethrower | 43 |

---

## Combusken

**Availability**
- Route 115
- Evolve Torchic (Level 16)

**Evolves to**
- Blaziken (Level 36)

**Learnset**

| Move | Level |
|------|-------|
| Ember | 1 |
| Focus Energy | 1 |
| Growl | 1 |
| Scratch | 1 |
| Focus Energy | 7 |
| Ember | 13 |
| Double Kick | 16 |
| Peck | 17 |
| Flame Wheel | 21 |
| Bulk Up | 28 |
| Quick Attack | 32 |
| Slash | 39 |
| Mirror Move | 43 |
| Sky Uppercut | 50 |

---

## Blaziken

**Availability**
- Evolve Combusken (Level 36)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Ember | 1 |
| Fire Punch | 1 |
| Focus Energy | 1 |
| Growl | 1 |
| Scratch | 1 |
| Focus Energy | 7 |
| Ember | 13 |
| Double Kick | 16 |
| Peck | 17 |
| Sand Attack | 21 |
| Bulk Up | 28 |
| Quick Attack | 32 |
| Blaze Kick | 36 |
| Slash | 42 |
| Protect | 45 |
| Sky Uppercut | 49 |
| Close Combat | 56 |

---

## Mudkip

**Availability**
- Route 102
- Route 126

**Evolves to**
- Marshtomp (Level 16)

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Tackle | 1 |
| Mud Slap | 6 |
| Water Gun | 10 |
| Bide | 15 |
| Foresight | 19 |
| Aqua Jet | 24 |
| Take Down | 28 |
| Whirlpool | 33 |
| Protect | 37 |
| Hydro Pump | 42 |
| Endeavor | 46 |

---

## Marshtomp

**Availability**
- Route 115
- Route 131
- Evolve Mudkip (Level 16)

**Evolves to**
- Swampert (Level 36)

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Mud Slap | 1 |
| Tackle | 1 |
| Water Gun | 1 |
| Mud Slap | 6 |
| Water Gun | 10 |
| Bide | 15 |
| Mud Shot | 16 |
| Foresight | 20 |
| Aqua Jet | 25 |
| Take Down | 31 |
| Muddy Water | 37 |
| Protect | 42 |
| Earthquake | 46 |
| Endeavor | 53 |

---

## Swampert

**Availability**
- Evolve Marshtomp (Level 36)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Mud Slap | 1 |
| Tackle | 1 |
| Water Gun | 1 |
| Mud Slap | 6 |
| Water Gun | 10 |
| Bide | 15 |
| Mud Shot | 16 |
| Foresight | 20 |
| Aqua Jet | 25 |
| Take Down | 31 |
| Muddy Water | 39 |
| Protect | 46 |
| Earthquake | 52 |
| Endeavor | 61 |

---

## Poochyena

**Availability**
- Petalburg Woods
- Route 101
- Route 102
- Route 103
- Route 104
- Route 116
- Route 117
- Route 120
- Route 121
- Route 123

**Evolves to**
- Mightyena (Level 18)

**Learnset**

| Move | Level |
|------|-------|
| Tackle | 1 |
| Howl | 5 |
| Sand Attack | 9 |
| Bite | 13 |
| Odor Sleuth | 17 |
| Roar | 21 |
| Swagger | 25 |
| Scary Face | 29 |
| Take Down | 33 |
| Taunt | 37 |
| Crunch | 41 |
| Thief | 45 |

---

## Mightyena

**Availability**
- Route 120
- Route 121
- Route 123
- Evolve Poochyena (Level 18)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Bite | 1 |
| Howl | 1 |
| Sand Attack | 1 |
| Tackle | 1 |
| Howl | 5 |
| Sand Attack | 9 |
| Bite | 13 |
| Protect | 17 |
| Thunder Fang | 20 |
| Roar | 22 |
| Ice Fang | 25 |
| Swagger | 27 |
| Crunch | 32 |
| Take Down | 37 |
| Taunt | 42 |
| Crunch | 47 |
| Thief | 52 |

---

## Zigzagoon

**Availability**
- Route 101
- Route 102
- Route 103
- Route 118
- Route 119

**Evolves to**
- Linoone (Level 20)

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Tackle | 1 |
| Tail Whip | 5 |
| Headbutt | 9 |
| Sand Attack | 13 |
| Odor Sleuth | 17 |
| Mud Sport | 21 |
| Pin Missile | 25 |
| Covet | 29 |
| Flail | 33 |
| Rest | 37 |
| Belly Drum | 41 |

---

## Linoone

**Availability**
- Route 118
- Route 119
- Evolve Zigzagoon (Level 20)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Headbutt | 1 |
| Tackle | 1 |
| Tail Whip | 1 |
| Tail Whip | 5 |
| Headbutt | 9 |
| Sand Attack | 13 |
| Fire Fang | 17 |
| Mud Sport | 23 |
| Fury Swipes | 29 |
| Covet | 35 |
| Slash | 41 |
| Rest | 47 |
| Belly Drum | 53 |

---

## Wurmple

**Availability**
- Petalburg Woods
- Route 101
- Route 102
- Route 104

**Evolves to**
- Silcoon (Level 7)
- Cascoon (Level 7)

**Learnset**

| Move | Level |
|------|-------|
| String Shot | 1 |
| Tackle | 1 |
| Poison Sting | 5 |

---

## Silcoon

**Availability**
- Petalburg Woods
- Evolve Wurmple (Level 7)

**Evolves to**
- Beautifly (Level 10)

**Learnset**

| Move | Level |
|------|-------|
| Harden | 1 |
| Harden | 7 |

---

## Beautifly

**Availability**
- Evolve Silcoon (Level 10)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Absorb | 1 |
| Absorb | 10 |
| Gust | 13 |
| Stun Spore | 17 |
| Morning Sun | 20 |
| Mega Drain | 24 |
| Whirlwind | 27 |
| Attract | 31 |
| Silver Wind | 34 |
| Giga Drain | 38 |
| Bug Buzz | 42 |

---

## Cascoon

**Availability**
- Petalburg Woods
- Evolve Wurmple (Level 7)

**Evolves to**
- Dustox (Level 10)

**Learnset**

| Move | Level |
|------|-------|
| Harden | 1 |
| Harden | 7 |

---

## Dustox

**Availability**
- Evolve Cascoon (Level 10)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Confusion | 1 |
| Confusion | 10 |
| Gust | 13 |
| Protect | 17 |
| Moonlight | 20 |
| Psybeam | 24 |
| Whirlwind | 27 |
| Light Screen | 31 |
| Silver Wind | 34 |
| Toxic | 38 |
| Bug Buzz | 42 |

---

## Lotad

**Availability**
- Petalburg City
- Route 102
- Route 114

**Evolves to**
- Lombre (Level 14)

**Learnset**

| Move | Level |
|------|-------|
| Astonish | 1 |
| Growl | 3 |
| Absorb | 7 |
| Nature Power | 13 |
| Mist | 21 |
| Rain Dance | 31 |
| Mega Drain | 43 |

---

## Lombre

**Availability**
- Route 114
- Route 132
- Evolve Lotad (Level 14)

**Evolves to**
- Ludicolo (Use Water Stone)

**Learnset**

| Move | Level |
|------|-------|
| Astonish | 1 |
| Growl | 3 |
| Absorb | 7 |
| Nature Power | 13 |
| Fake Out | 19 |
| Fury Swipes | 25 |
| Water Pulse | 31 |
| Psybeam | 34 |
| Thief | 37 |
| Energy Ball | 43 |
| Hydro Pump | 49 |

---

## Ludicolo

**Availability**
- Evolve Lombre (Use Water Stone)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Astonish | 1 |
| Growl | 3 |
| Absorb | 7 |
| Nature Power | 13 |
| Fake Out | 19 |
| Razor Leaf | 21 |
| Fury Swipes | 25 |
| Water Pulse | 31 |
| Psybeam | 34 |
| Thief | 37 |
| Energy Ball | 43 |
| Hydro Pump | 49 |

---

## Seedot

**Availability**
- Route 102
- Route 117

**Evolves to**
- Nuzleaf (Level 14)

**Learnset**

| Move | Level |
|------|-------|
| Bide | 1 |
| Harden | 3 |
| Growth | 7 |
| Nature Power | 13 |
| Synthesis | 21 |
| Sunny Day | 31 |
| Explosion | 43 |

---

## Nuzleaf

**Availability**
- Evolve Seedot (Level 14)

**Evolves to**
- Shiftry (Use Leaf Stone)

**Learnset**

| Move | Level |
|------|-------|
| Pound | 1 |
| Harden | 3 |
| Growth | 7 |
| Nature Power | 13 |
| Fake Out | 19 |
| Leaf Blade | 25 |
| Dark Pulse | 31 |
| Razor Wind | 37 |
| Swagger | 43 |
| Extrasensory | 49 |

---

## Shiftry

**Availability**
- Evolve Nuzleaf (Use Leaf Stone)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Growth | 1 |
| Harden | 1 |
| Nature Power | 1 |
| Pound | 1 |
| Fake Out | 19 |
| Leaf Blade | 25 |
| Dark Pulse | 31 |
| Razor Wind | 37 |
| Swagger | 43 |
| Psycho Cut | 49 |
| Earth Power | 57 |

---

## Nincada

**Availability**
- Route 116

**Evolves to**
- Ninjask (Level 20)
- Shedinja (Level 20)

**Learnset**

| Move | Level |
|------|-------|
| Harden | 1 |
| Scratch | 1 |
| Leech Life | 5 |
| Sand Attack | 9 |
| Fury Swipes | 14 |
| Mind Reader | 19 |
| False Swipe | 25 |
| Mud Slap | 31 |
| Metal Claw | 38 |
| Dig | 45 |

---

## Ninjask

**Availability**
- Evolve Nincada (Level 20)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Harden | 1 |
| Leech Life | 1 |
| Sand Attack | 1 |
| Scratch | 1 |
| Leech Life | 5 |
| Sand Attack | 9 |
| Fury Swipes | 14 |
| Mind Reader | 19 |
| Double Team | 20 |
| Fury Cutter | 20 |
| Xscissor | 20 |
| Swords Dance | 25 |
| Slash | 31 |
| Agility | 38 |
| Baton Pass | 45 |

---

## Shedinja

**Availability**
- Evolve Nincada (Level 20)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Harden | 1 |
| Scratch | 1 |
| Leech Life | 5 |
| Sand Attack | 9 |
| Swords Dance | 13 |
| Fury Swipes | 14 |
| Mind Reader | 19 |
| Spite | 25 |
| Confuse Ray | 31 |
| Shadow Claw | 38 |
| Xscissor | 45 |

---

## Taillow

**Availability**
- Petalburg Woods
- Route 104
- Route 116

**Evolves to**
- Swellow (Level 22)

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Peck | 1 |
| Focus Energy | 4 |
| Quick Attack | 8 |
| Wing Attack | 13 |
| Double Team | 19 |
| Endeavor | 26 |
| Aerial Ace | 34 |
| Agility | 43 |

---

## Swellow

**Availability**
- Route 115
- Evolve Taillow (Level 22)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Focus Energy | 1 |
| Growl | 1 |
| Peck | 1 |
| Quick Attack | 1 |
| Focus Energy | 4 |
| Quick Attack | 8 |
| Wing Attack | 13 |
| Double Team | 19 |
| Endeavor | 28 |
| Aerial Ace | 38 |
| Razor Wind | 44 |
| Brave Bird | 49 |

---

## Shroomish

**Availability**
- Petalburg Woods

**Evolves to**
- Breloom (Level 23)

**Learnset**

| Move | Level |
|------|-------|
| Absorb | 1 |
| Tackle | 4 |
| Stun Spore | 7 |
| Leech Seed | 10 |
| Mega Drain | 16 |
| Headbutt | 22 |
| Poison Powder | 28 |
| Growth | 36 |
| Giga Drain | 45 |
| Spore | 54 |

---

## Breloom

**Availability**
- Battlepike 3
- Evolve Shroomish (Level 23)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Absorb | 1 |
| Leech Seed | 1 |
| Spore | 1 |
| Tackle | 1 |
| Tackle | 4 |
| Stun Spore | 7 |
| Leech Seed | 10 |
| Mega Drain | 16 |
| Headbutt | 22 |
| Mach Punch | 23 |
| Counter | 28 |
| Needle Arm | 36 |
| Sky Uppercut | 45 |
| Dynamic Punch | 54 |

---

## Spinda

**Availability**
- Route 113

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Tackle | 1 |
| Uproar | 5 |
| Faint Attack | 12 |
| Psybeam | 16 |
| Hypnosis | 23 |
| Dizzy Punch | 27 |
| Teeter Dance | 34 |
| Psych Up | 38 |
| Double Edge | 45 |
| Flail | 49 |
| Thrash | 56 |

---

## Wingull

**Availability**
- Dewford Town
- Evergrande City
- Lilycove City
- Mossdeep City
- Mtpyre Exterior
- Pacifidlog Town
- Route 103
- Route 104
- Route 105
- Route 106
- Route 107
- Route 108
- Route 109
- Route 110
- Route 115
- Route 118
- Route 119
- Route 121
- Route 122
- Route 123
- Route 124
- Route 125
- Route 126
- Route 127
- Route 128
- Route 129
- Route 130
- Route 131
- Route 133
- Route 134
- Route 136
- Slateport City

**Evolves to**
- Pelipper (Level 25)

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Water Gun | 1 |
| Supersonic | 7 |
| Wing Attack | 13 |
| Mist | 21 |
| Quick Attack | 31 |
| Pursuit | 43 |
| Agility | 55 |

---

## Pelipper

**Availability**
- Dewford Town
- Evergrande City
- Lilycove City
- Mossdeep City
- Pacifidlog Town
- Route 103
- Route 104
- Route 105
- Route 106
- Route 107
- Route 108
- Route 109
- Route 110
- Route 115
- Route 118
- Route 119
- Route 121
- Route 123
- Route 124
- Route 125
- Route 126
- Route 127
- Route 128
- Route 129
- Route 130
- Route 131
- Route 132
- Route 133
- Route 134
- Slateport City
- Evolve Wingull (Level 25)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Water Gun | 1 |
| Water Sport | 1 |
| Wing Attack | 1 |
| Water Gun | 3 |
| Supersonic | 7 |
| Wing Attack | 13 |
| Mist | 21 |
| Protect | 25 |
| Water Pulse | 29 |
| Stockpile | 33 |
| Swallow | 33 |
| Spit Up | 47 |
| Aeroblast | 55 |
| Hydro Pump | 61 |

---

## Surskit

**Availability**
- Route 110

**Evolves to**
- Masquerain (Level 22)

**Learnset**

| Move | Level |
|------|-------|
| Bubble | 1 |
| Quick Attack | 7 |
| Sweet Scent | 13 |
| Water Sport | 19 |
| Bubble Beam | 25 |
| Agility | 31 |
| Haze | 37 |
| Mist | 37 |

---

## Masquerain

**Availability**
- Evolve Surskit (Level 22)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Bubble | 1 |
| Quick Attack | 1 |
| Sweet Scent | 1 |
| Water Sport | 1 |
| Quick Attack | 7 |
| Sweet Scent | 13 |
| Water Sport | 19 |
| Gust | 26 |
| Silver Wind | 33 |
| Spore | 40 |
| Bug Buzz | 47 |
| Whirlwind | 53 |

---

## Wailmer

**Availability**
- Dewford Town
- Evergrande City
- Lilycove City
- Mossdeep City
- Pacifidlog Town
- Route 103
- Route 105
- Route 106
- Route 107
- Route 108
- Route 109
- Route 110
- Route 115
- Route 121
- Route 122
- Route 123
- Route 124
- Route 125
- Route 126
- Route 127
- Route 128
- Route 129
- Route 130
- Route 131
- Route 132
- Route 133
- Route 134
- Route 135
- Route 136
- Seafloor Cavern Entrance
- Seafloor Cavern Room 6
- Seafloor Cavern Room 7
- Shoal Cave Lowtideentranceroom
- Shoal Cave Lowtideinnerroom
- Slateport City

**Evolves to**
- Wailord (Level 40)

**Learnset**

| Move | Level |
|------|-------|
| Splash | 1 |
| Growl | 5 |
| Water Gun | 10 |
| Rollout | 14 |
| Whirlpool | 19 |
| Astonish | 23 |
| Water Pulse | 28 |
| Mist | 32 |
| Rest | 37 |
| Water Spout | 41 |
| Amnesia | 46 |
| Hydro Pump | 50 |

---

## Wailord

**Availability**
- Route 129
- Evolve Wailmer (Level 40)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Rollout | 1 |
| Splash | 1 |
| Water Gun | 1 |
| Growl | 5 |
| Water Gun | 10 |
| Rollout | 14 |
| Whirlpool | 19 |
| Astonish | 23 |
| Water Pulse | 28 |
| Mist | 32 |
| Rest | 37 |
| Water Spout | 44 |
| Amnesia | 52 |
| Hydro Pump | 59 |

---

## Skitty

**Availability**
- Route 102

**Evolves to**
- Delcatty (High friendship)

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Tackle | 1 |
| Tail Whip | 3 |
| Attract | 7 |
| Sing | 13 |
| Double Slap | 15 |
| Assist | 19 |
| Charm | 25 |
| Faint Attack | 27 |
| Covet | 31 |
| Heal Bell | 37 |
| Double Edge | 39 |

---

## Delcatty

**Availability**
- Evolve Skitty (High friendship)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Attract | 1 |
| Double Slap | 1 |
| Follow Me | 1 |
| Growl | 1 |
| Sing | 1 |
| Attract | 7 |
| Sing | 13 |
| Double Slap | 15 |
| Assist | 19 |
| Ice Fang | 21 |
| Charm | 25 |
| Faint Attack | 27 |
| Thunder Fang | 29 |
| Covet | 31 |
| Fire Fang | 35 |
| Heal Bell | 37 |
| Double Edge | 39 |
| Night Slash | 42 |

---

## Kecleon

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Astonish | 1 |
| Lick | 1 |
| Scratch | 1 |
| Tail Whip | 1 |
| Thief | 1 |
| Bind | 4 |
| Faint Attack | 7 |
| Fury Swipes | 12 |
| Psybeam | 17 |
| Screech | 24 |
| Slash | 31 |
| Substitute | 40 |
| Ancient Power | 49 |

---

## Baltoy

**Availability**
- Route 111

**Evolves to**
- Claydol (Level 36)

**Learnset**

| Move | Level |
|------|-------|
| Confusion | 1 |
| Harden | 3 |
| Rapid Spin | 5 |
| Mud Slap | 7 |
| Psybeam | 11 |
| Rock Tomb | 15 |
| Self Destruct | 19 |
| Ancient Power | 25 |
| Sandstorm | 31 |
| Cosmic Power | 37 |
| Explosion | 45 |

---

## Claydol

**Availability**
- Skypillar 1F
- Skypillar 3F
- Skypillar 5F
- Evolve Baltoy (Level 36)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Confusion | 1 |
| Harden | 1 |
| Rapid Spin | 1 |
| Teleport | 1 |
| Harden | 3 |
| Rapid Spin | 5 |
| Mud Slap | 7 |
| Psybeam | 11 |
| Rock Tomb | 15 |
| Self Destruct | 19 |
| Ancient Power | 25 |
| Flash Cannon | 31 |
| Power Gem | 36 |
| Cosmic Power | 42 |
| Energy Ball | 55 |

---

## Nosepass

**Availability**
- Granite Cave B 2F

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Tackle | 1 |
| Harden | 7 |
| Rock Throw | 13 |
| Block | 16 |
| Thunder Wave | 22 |
| Rock Slide | 28 |
| Sandstorm | 31 |
| Rest | 37 |
| Zap Cannon | 43 |
| Lock On | 46 |

---

## Probopass

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Tackle | 1 |
| Harden | 7 |
| Rock Throw | 13 |
| Block | 16 |
| Thunder Wave | 22 |
| Power Gem | 25 |
| Rock Slide | 28 |
| Sandstorm | 31 |
| Tri Attack | 33 |
| Earth Power | 37 |
| Zap Cannon | 43 |
| Lock On | 46 |

---

## Torkoal

**Availability**
- Fiery Path
- Magma Hideout 1F
- Magma Hideout 2F 1R
- Magma Hideout 2F 2R
- Magma Hideout 2F 3R
- Magma Hideout 3F 1R
- Magma Hideout 3F 2R
- Magma Hideout 3F 3R
- Magma Hideout 4F

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Ember | 1 |
| Smog | 4 |
| Curse | 7 |
| Smokescreen | 14 |
| Fire Spin | 17 |
| Body Slam | 20 |
| Protect | 27 |
| Flamethrower | 30 |
| Iron Defense | 33 |
| Nasty Plot | 40 |
| Energy Ball | 43 |
| Heat Wave | 46 |

---

## Sableye

**Availability**
- Cave Of Origin 1F
- Granite Cave B 1F
- Granite Cave B 2F
- Skypillar 1F
- Skypillar 3F
- Skypillar 5F
- Victoryroad B 2F

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Leer | 1 |
| Scratch | 1 |
| Foresight | 5 |
| Night Shade | 9 |
| Astonish | 13 |
| Fury Swipes | 17 |
| Fake Out | 21 |
| Detect | 25 |
| Faint Attack | 29 |
| Knock Off | 33 |
| Confuse Ray | 37 |
| Shadow Claw | 41 |
| Poison Jab | 45 |

---

## Barboach

**Availability**
- Meteor Falls 1F 1R
- Meteor Falls 1F 2R
- Meteor Falls B 1F 1R
- Meteor Falls B 1F 2R
- Route 111
- Route 114
- Route 120
- Route 135
- Victoryroad B 2F

**Evolves to**
- Whiscash (Level 30)

**Learnset**

| Move | Level |
|------|-------|
| Mud Slap | 1 |
| Mud Sport | 6 |
| Water Sport | 6 |
| Water Gun | 11 |
| Magnitude | 16 |
| Amnesia | 21 |
| Rest | 26 |
| Snore | 26 |
| Earthquake | 31 |
| Future Sight | 36 |
| Fissure | 41 |

---

## Whiscash

**Availability**
- Meteor Falls 1F 2R
- Meteor Falls B 1F 1R
- Meteor Falls B 1F 2R
- Victoryroad B 2F
- Evolve Barboach (Level 30)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Mud Slap | 1 |
| Mud Sport | 1 |
| Tickle | 1 |
| Water Sport | 1 |
| Mud Sport | 6 |
| Water Sport | 6 |
| Water Gun | 11 |
| Magnitude | 16 |
| Amnesia | 21 |
| Rest | 26 |
| Snore | 26 |
| Earthquake | 36 |
| Zen Headbutt | 46 |
| Fissure | 56 |

---

## Luvdisc

**Availability**
- Evergrande City
- Route 128

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Tackle | 1 |
| Charm | 4 |
| Water Gun | 12 |
| Agility | 16 |
| Take Down | 24 |
| Attract | 28 |
| Water Pulse | 30 |
| Sweet Kiss | 36 |
| Dark Pulse | 40 |
| Safeguard | 48 |

---

## Corphish

**Availability**
- Petalburg City
- Route 102
- Route 117

**Evolves to**
- Crawdaunt (Level 30)

**Learnset**

| Move | Level |
|------|-------|
| Bubble | 1 |
| Harden | 7 |
| Vice Grip | 10 |
| Leer | 13 |
| Bubble Beam | 20 |
| Protect | 23 |
| Knock Off | 26 |
| Taunt | 32 |
| Crabhammer | 35 |
| Swords Dance | 38 |
| Guillotine | 44 |

---

## Crawdaunt

**Availability**
- Route 126
- Evolve Corphish (Level 30)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Bubble | 1 |
| Harden | 1 |
| Leer | 1 |
| Vice Grip | 1 |
| Harden | 7 |
| Vice Grip | 10 |
| Leer | 13 |
| Bubble Beam | 20 |
| Protect | 23 |
| Knock Off | 26 |
| Taunt | 34 |
| Crabhammer | 39 |
| Swords Dance | 44 |
| Guillotine | 52 |
| Night Slash | 55 |

---

## Feebas

**Availability**
- Meteor Falls 1F 1R
- Meteor Falls 1F 2R
- Petalburg City
- Resevoir Cave
- Route 103
- Route 104
- Route 105
- Route 106
- Route 107
- Route 108
- Route 109
- Route 110
- Route 111
- Route 114
- Route 115
- Route 120
- Route 124
- Route 125
- Route 126
- Route 127
- Route 132
- Route 135
- Route 136
- Scorched Slab
- Shoal Cave Lowtideentranceroom
- Victoryroad B 2F

**Evolves to**
- Milotic (High beauty)
- Milotic (Level 25)

**Learnset**

| Move | Level |
|------|-------|
| Splash | 1 |
| Tackle | 15 |
| Flail | 30 |

---

## Milotic

**Availability**
- Battlepike 1
- Battlepike 2
- Battlepike 3
- Battlepike 4
- Seafloor Cavern Entrance
- Evolve Feebas (High beauty)
- Evolve Feebas (Level 25)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Water Gun | 1 |
| Wrap | 5 |
| Water Sport | 10 |
| Refresh | 15 |
| Water Pulse | 20 |
| Dragon Pulse | 25 |
| Recover | 30 |
| Rain Dance | 35 |
| Hydro Pump | 40 |
| Attract | 45 |
| Safeguard | 50 |
| Nasty Plot | 55 |

---

## Carvanha

**Availability**
- Route 118
- Route 119

**Evolves to**
- Sharpedo (Level 30)

**Learnset**

| Move | Level |
|------|-------|
| Bite | 1 |
| Leer | 1 |
| Rage | 7 |
| Focus Energy | 13 |
| Scary Face | 16 |
| Crunch | 22 |
| Screech | 28 |
| Take Down | 31 |
| Swagger | 37 |
| Agility | 43 |

---

## Sharpedo

**Availability**
- Mossdeep City
- Pacifidlog Town
- Route 103
- Route 118
- Route 122
- Route 124
- Route 125
- Route 126
- Route 127
- Route 129
- Route 130
- Route 131
- Route 132
- Route 133
- Route 134
- Evolve Carvanha (Level 30)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Bite | 1 |
| Focus Energy | 1 |
| Leer | 1 |
| Rage | 1 |
| Rage | 7 |
| Focus Energy | 13 |
| Scary Face | 16 |
| Crunch | 22 |
| Screech | 28 |
| Slash | 33 |
| Taunt | 38 |
| Swagger | 43 |
| Skull Bash | 48 |
| Fire Fang | 53 |

---

## Trapinch

**Availability**
- Granite Cave Stevensroom
- Miragetower 1F
- Miragetower 2F
- Miragetower 3F
- Miragetower 4F
- Route 110
- Route 111

**Evolves to**
- Vibrava (Level 25)

**Learnset**

| Move | Level |
|------|-------|
| Bite | 1 |
| Sand Attack | 9 |
| Sand Tomb | 17 |
| Sunny Day | 22 |
| Dark Pulse | 25 |
| Dig | 33 |
| Sandstorm | 49 |
| Hyper Beam | 57 |

---

## Vibrava

**Availability**
- Evolve Trapinch (Level 25)

**Evolves to**
- Flygon (Level 40)

**Learnset**

| Move | Level |
|------|-------|
| Bite | 1 |
| Faint Attack | 1 |
| Sand Attack | 1 |
| Sand Tomb | 1 |
| Sand Attack | 9 |
| Faint Attack | 17 |
| Sand Tomb | 23 |
| Dark Pulse | 25 |
| Dragon Breath | 28 |
| Earth Power | 36 |
| Sandstorm | 49 |
| Hyper Beam | 57 |

---

## Flygon

**Availability**
- Evolve Vibrava (Level 40)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Bite | 1 |
| Faint Attack | 1 |
| Sand Attack | 1 |
| Sand Tomb | 1 |
| Sand Attack | 9 |
| Faint Attack | 17 |
| Sand Tomb | 25 |
| Dark Pulse | 33 |
| Dragon Breath | 35 |
| Earth Power | 36 |
| Bug Buzz | 42 |
| Dragon Pulse | 46 |
| Aeroblast | 65 |
| Hyper Beam | 75 |

---

## Makuhita

**Availability**
- Granite Cave 1F
- Granite Cave B 1F
- Granite Cave Stevensroom

**Evolves to**
- Hariyama (Level 24)

**Learnset**

| Move | Level |
|------|-------|
| Focus Energy | 1 |
| Tackle | 1 |
| Sand Attack | 4 |
| Arm Thrust | 10 |
| Vital Throw | 13 |
| Fake Out | 19 |
| Whirlwind | 22 |
| Knock Off | 28 |
| Smelling Salt | 31 |
| Belly Drum | 37 |
| Endure | 40 |
| Seismic Toss | 46 |
| Reversal | 49 |

---

## Hariyama

**Availability**
- Victoryroad 1F
- Victoryroad B 1F
- Evolve Makuhita (Level 24)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Focus Energy | 1 |
| Tackle | 1 |
| Sand Attack | 4 |
| Arm Thrust | 10 |
| Vital Throw | 13 |
| Fake Out | 19 |
| Whirlwind | 22 |
| Knock Off | 28 |
| Smelling Salt | 31 |
| Belly Drum | 37 |
| Endure | 40 |
| Iron Head | 42 |
| Seismic Toss | 46 |
| Reversal | 49 |

---

## Electrike

**Availability**
- Route 110
- Route 118

**Evolves to**
- Manectric (Level 26)

**Learnset**

| Move | Level |
|------|-------|
| Tackle | 1 |
| Thunder Wave | 4 |
| Leer | 9 |
| Howl | 12 |
| Quick Attack | 17 |
| Spark | 20 |
| Fire Fang | 25 |
| Roar | 28 |
| Bite | 33 |
| Thunder | 36 |
| Charge | 41 |

---

## Manectric

**Availability**
- Evolve Electrike (Level 26)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Howl | 1 |
| Leer | 1 |
| Tackle | 1 |
| Thunder Wave | 1 |
| Thunder Wave | 4 |
| Leer | 9 |
| Howl | 12 |
| Quick Attack | 17 |
| Spark | 20 |
| Fire Fang | 25 |
| Roar | 31 |
| Bite | 39 |
| Thunder | 45 |
| Ice Fang | 53 |

---

## Numel

**Availability**
- Fiery Path
- Jagged Pass
- Route 112

**Evolves to**
- Camerupt (Level 33)

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Tackle | 1 |
| Ember | 11 |
| Magnitude | 19 |
| Focus Energy | 25 |
| Take Down | 29 |
| Amnesia | 31 |
| Earthquake | 35 |
| Flamethrower | 41 |
| Double Edge | 49 |

---

## Camerupt

**Availability**
- Evolve Numel (Level 33)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Ember | 1 |
| Growl | 1 |
| Magnitude | 1 |
| Tackle | 1 |
| Ember | 11 |
| Magnitude | 19 |
| Focus Energy | 25 |
| Take Down | 29 |
| Amnesia | 31 |
| Rock Slide | 33 |
| Earthquake | 37 |
| Eruption | 45 |
| Fissure | 55 |

---

## Spheal

**Availability**
- Shoal Cave Lowtideentranceroom
- Shoal Cave Lowtideiceroom
- Shoal Cave Lowtideinnerroom
- Shoal Cave Lowtidelowerroom
- Shoal Cave Lowtidestairsroom

**Evolves to**
- Sealeo (Level 32)

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Powder Snow | 1 |
| Water Gun | 1 |
| Encore | 7 |
| Ice Ball | 13 |
| Body Slam | 19 |
| Aurora Beam | 25 |
| Hail | 31 |
| Rest | 37 |
| Snore | 37 |
| Blizzard | 43 |
| Sheer Cold | 49 |

---

## Sealeo

**Availability**
- Route 133
- Route 135
- Evolve Spheal (Level 32)

**Evolves to**
- Walrein (Level 40)

**Learnset**

| Move | Level |
|------|-------|
| Encore | 1 |
| Growl | 1 |
| Powder Snow | 1 |
| Water Gun | 1 |
| Encore | 7 |
| Ice Ball | 13 |
| Body Slam | 19 |
| Aurora Beam | 25 |
| Hail | 31 |
| Rest | 39 |
| Snore | 39 |
| Blizzard | 47 |
| Sheer Cold | 55 |

---

## Walrein

**Availability**
- Evolve Sealeo (Level 40)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Encore | 1 |
| Growl | 1 |
| Powder Snow | 1 |
| Water Gun | 1 |
| Ice Shard | 7 |
| Ice Ball | 13 |
| Body Slam | 19 |
| Aurora Beam | 25 |
| Hail | 31 |
| Rest | 39 |
| Snore | 39 |
| Avalanche | 44 |
| Blizzard | 50 |
| Sheer Cold | 61 |

---

## Cacnea

**Availability**
- Route 111

**Evolves to**
- Cacturne (Level 32)

**Learnset**

| Move | Level |
|------|-------|
| Leer | 1 |
| Poison Sting | 1 |
| Absorb | 5 |
| Growth | 9 |
| Leech Seed | 13 |
| Sand Attack | 17 |
| Pin Missile | 21 |
| Ingrain | 25 |
| Faint Attack | 29 |
| Spikes | 33 |
| Needle Arm | 37 |
| Cotton Spore | 41 |
| Sandstorm | 45 |

---

## Cacturne

**Availability**
- Evolve Cacnea (Level 32)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Absorb | 1 |
| Growth | 1 |
| Leer | 1 |
| Poison Sting | 1 |
| Absorb | 5 |
| Growth | 9 |
| Leech Seed | 13 |
| Sand Attack | 17 |
| Pin Missile | 21 |
| Ingrain | 25 |
| Faint Attack | 29 |
| Spikes | 35 |
| Needle Arm | 41 |
| Xscissor | 47 |
| Shadow Claw | 53 |

---

## Snorunt

**Availability**
- Shoal Cave Lowtideiceroom

**Evolves to**
- Glalie (Level 30 (Male only))
- Froslass (Level 30 (Female only))

**Learnset**

| Move | Level |
|------|-------|
| Leer | 1 |
| Powder Snow | 1 |
| Double Team | 7 |
| Bite | 10 |
| Icy Wind | 16 |
| Headbutt | 19 |
| Protect | 25 |
| Crunch | 28 |
| Ice Beam | 34 |
| Hail | 37 |
| Blizzard | 43 |

---

## Glalie

**Availability**
- Evolve Snorunt (Level 30 (Male only))

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Bite | 1 |
| Double Team | 1 |
| Leer | 1 |
| Powder Snow | 1 |
| Double Team | 7 |
| Bite | 10 |
| Icy Wind | 16 |
| Headbutt | 19 |
| Protect | 25 |
| Crunch | 28 |
| Ice Beam | 34 |
| Hail | 42 |
| Blizzard | 53 |
| Sheer Cold | 61 |

---

## Froslass

**Availability**
- Shoal Cave Lowtideiceroom
- Evolve Snorunt (Level 30 (Female only))

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Bite | 1 |
| Double Team | 1 |
| Leer | 1 |
| Powder Snow | 1 |
| Double Team | 7 |
| Bite | 10 |
| Icy Wind | 16 |
| Confuse Ray | 19 |
| Protect | 25 |
| Shadow Ball | 28 |
| Ice Beam | 34 |
| Will O Wisp | 42 |
| Blizzard | 53 |
| Destiny Bond | 61 |

---

## Lunatone

**Availability**
- Meteor Falls 1F 1R

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Harden | 1 |
| Tackle | 1 |
| Confusion | 7 |
| Rock Throw | 13 |
| Hypnosis | 19 |
| Psywave | 25 |
| Cosmic Power | 31 |
| Power Gem | 35 |
| Psychic | 37 |
| Nasty Plot | 40 |
| Future Sight | 43 |
| Explosion | 49 |

---

## Solrock

**Availability**
- Meteor Falls 1F 1R
- Meteor Falls 1F 2R
- Meteor Falls B 1F 1R
- Meteor Falls B 1F 2R
- Meteor Falls Stevens Cave

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Harden | 1 |
| Tackle | 1 |
| Confusion | 7 |
| Rock Throw | 13 |
| Fire Spin | 19 |
| Psywave | 25 |
| Cosmic Power | 31 |
| Power Gem | 35 |
| Rock Slide | 37 |
| Solar Beam | 43 |
| Explosion | 49 |

---

## Azurill

**Availability**
- ???

**Evolves to**
- Marill (High friendship)

**Learnset**

| Move | Level |
|------|-------|
| Splash | 1 |
| Charm | 3 |
| Tail Whip | 6 |
| Bubble | 10 |
| Slam | 15 |
| Water Gun | 21 |

---

## Spoink

**Availability**
- Jagged Pass

**Evolves to**
- Grumpig (Level 32)

**Learnset**

| Move | Level |
|------|-------|
| Splash | 1 |
| Psywave | 7 |
| Odor Sleuth | 10 |
| Psybeam | 16 |
| Psych Up | 19 |
| Confuse Ray | 25 |
| Magic Coat | 28 |
| Psychic | 34 |
| Rest | 37 |
| Snore | 37 |
| Bounce | 43 |

---

## Grumpig

**Availability**
- Evolve Spoink (Level 32)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Odor Sleuth | 1 |
| Psybeam | 1 |
| Psywave | 1 |
| Splash | 1 |
| Psywave | 7 |
| Odor Sleuth | 10 |
| Psybeam | 16 |
| Psych Up | 19 |
| Confuse Ray | 25 |
| Magic Coat | 28 |
| Psychic | 37 |
| Rest | 43 |
| Snore | 43 |
| Bounce | 55 |

---

## Plusle

**Availability**
- Route 110

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Thunder Wave | 4 |
| Quick Attack | 10 |
| Helping Hand | 13 |
| Spark | 19 |
| Encore | 22 |
| Fake Tears | 28 |
| Charge | 31 |
| Thunder | 37 |
| Baton Pass | 40 |
| Agility | 47 |

---

## Minun

**Availability**
- Route 110

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Thunder Wave | 4 |
| Quick Attack | 10 |
| Helping Hand | 13 |
| Spark | 19 |
| Encore | 22 |
| Charm | 28 |
| Charge | 31 |
| Thunder | 37 |
| Baton Pass | 40 |
| Agility | 47 |

---

## Mawile

**Availability**
- Victoryroad B 1F
- Victoryroad B 2F

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Astonish | 1 |
| Fake Tears | 6 |
| Bite | 11 |
| Sweet Scent | 16 |
| Vice Grip | 21 |
| Faint Attack | 26 |
| Baton Pass | 31 |
| Follow Me | 34 |
| Crunch | 36 |
| Iron Head | 41 |
| Spit Up | 46 |
| Stockpile | 46 |
| Swallow | 46 |
| Zen Headbutt | 50 |

---

## Meditite

**Availability**
- ???

**Evolves to**
- Medicham (Level 37)

**Learnset**

| Move | Level |
|------|-------|
| Bide | 1 |
| Meditate | 4 |
| Confusion | 9 |
| Detect | 12 |
| Hidden Power | 18 |
| Mind Reader | 22 |
| Calm Mind | 28 |
| Hi Jump Kick | 32 |
| Psych Up | 38 |
| Reversal | 42 |
| Zen Headbutt | 48 |
| Aura Sphere | 52 |

---

## Medicham

**Availability**
- Evolve Meditite (Level 37)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Bide | 1 |
| Confusion | 1 |
| Detect | 1 |
| Fire Punch | 1 |
| Ice Punch | 1 |
| Meditate | 1 |
| Thunder Punch | 1 |
| Meditate | 4 |
| Confusion | 9 |
| Detect | 12 |
| Hidden Power | 18 |
| Mind Reader | 22 |
| Calm Mind | 28 |
| Hi Jump Kick | 32 |
| Psych Up | 40 |
| Reversal | 46 |
| Zen Headbutt | 48 |
| Aura Sphere | 52 |
| Recover | 54 |

---

## Swablu

**Availability**
- Route 114
- Route 128

**Evolves to**
- Altaria (Level 35)

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Peck | 1 |
| Astonish | 8 |
| Sing | 11 |
| Fury Attack | 18 |
| Safeguard | 21 |
| Mist | 28 |
| Take Down | 31 |
| Mirror Move | 38 |
| Refresh | 41 |
| Perish Song | 48 |

---

## Altaria

**Availability**
- Skypillar 5F
- Evolve Swablu (Level 35)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Astonish | 1 |
| Growl | 1 |
| Peck | 1 |
| Sing | 1 |
| Astonish | 8 |
| Sing | 11 |
| Fury Attack | 18 |
| Safeguard | 21 |
| Mist | 28 |
| Take Down | 31 |
| Dragon Breath | 35 |
| Dragon Dance | 40 |
| Refresh | 45 |
| Dragon Claw | 50 |
| Perish Song | 54 |
| Sky Attack | 59 |

---

## Wynaut

**Availability**
- Route 130

**Evolves to**
- Wobbuffet (Level 15)

**Learnset**

| Move | Level |
|------|-------|
| Charm | 1 |
| Encore | 1 |
| Splash | 1 |
| Counter | 15 |
| Destiny Bond | 15 |
| Mirror Coat | 15 |
| Safeguard | 15 |

---

## Duskull

**Availability**
- Mtpyre 4F
- Mtpyre 5F
- Mtpyre 6F
- Mtpyre Summit

**Evolves to**
- Dusclops (Level 37)

**Learnset**

| Move | Level |
|------|-------|
| Leer | 1 |
| Night Shade | 1 |
| Disable | 5 |
| Foresight | 12 |
| Astonish | 16 |
| Confuse Ray | 23 |
| Pursuit | 27 |
| Curse | 34 |
| Will O Wisp | 38 |
| Mean Look | 45 |
| Future Sight | 49 |

---

## Dusclops

**Availability**
- Battlepike 1
- Evolve Duskull (Level 37)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Bind | 1 |
| Disable | 1 |
| Leer | 1 |
| Night Shade | 1 |
| Disable | 5 |
| Foresight | 12 |
| Astonish | 16 |
| Confuse Ray | 23 |
| Pursuit | 27 |
| Curse | 34 |
| Shadow Punch | 37 |
| Will O Wisp | 41 |
| Mean Look | 51 |
| Future Sight | 58 |

---

## Roselia

**Availability**
- Petalburg Woods
- Route 120

**Evolves to**
- Roserade (Level 36)

**Learnset**

| Move | Level |
|------|-------|
| Absorb | 1 |
| Growth | 5 |
| Poison Sting | 9 |
| Stun Spore | 13 |
| Mega Drain | 17 |
| Leech Seed | 21 |
| Magical Leaf | 25 |
| Grass Whistle | 29 |
| Giga Drain | 33 |
| Sweet Scent | 37 |
| Ingrain | 41 |
| Toxic | 45 |
| Petal Dance | 49 |
| Aromatherapy | 53 |
| Synthesis | 57 |

---

## Roserade

**Availability**
- Evolve Roselia (Level 36)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Absorb | 1 |
| Growth | 5 |
| Poison Sting | 9 |
| Stun Spore | 13 |
| Mega Drain | 17 |
| Leech Seed | 21 |
| Magical Leaf | 25 |
| Grass Whistle | 29 |
| Giga Drain | 33 |
| Sludge Bomb | 37 |
| Energy Ball | 41 |
| Ingrain | 41 |
| Toxic | 45 |
| Aromatherapy | 53 |
| Synthesis | 57 |
| Dark Pulse | 62 |

---

## Slakoth

**Availability**
- Petalburg Woods

**Evolves to**
- Vigoroth (Level 18)

**Learnset**

| Move | Level |
|------|-------|
| Scratch | 1 |
| Yawn | 1 |
| Encore | 7 |
| Slack Off | 13 |
| Faint Attack | 19 |
| Amnesia | 25 |
| Covet | 31 |
| Counter | 37 |
| Flail | 43 |

---

## Vigoroth

**Availability**
- Evolve Slakoth (Level 18)

**Evolves to**
- Slaking (Level 36)

**Learnset**

| Move | Level |
|------|-------|
| Encore | 1 |
| Focus Energy | 1 |
| Scratch | 1 |
| Uproar | 1 |
| Encore | 7 |
| Uproar | 13 |
| Fury Swipes | 19 |
| Endure | 25 |
| Slash | 31 |
| Counter | 37 |
| Focus Punch | 43 |
| Reversal | 49 |

---

## Slaking

**Availability**
- Evolve Vigoroth (Level 36)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Encore | 1 |
| Scratch | 1 |
| Slack Off | 1 |
| Yawn | 1 |
| Encore | 7 |
| Slack Off | 13 |
| Faint Attack | 19 |
| Amnesia | 25 |
| Avalanche | 31 |
| Swagger | 36 |
| Counter | 37 |
| Flail | 43 |
| Close Combat | 48 |

---

## Gulpin

**Availability**
- Route 110

**Evolves to**
- Swalot (Level 26)

**Learnset**

| Move | Level |
|------|-------|
| Pound | 1 |
| Yawn | 6 |
| Poison Gas | 9 |
| Sludge | 14 |
| Amnesia | 17 |
| Encore | 23 |
| Toxic | 28 |
| Spit Up | 34 |
| Stockpile | 34 |
| Swallow | 34 |
| Sludge Bomb | 39 |

---

## Swalot

**Availability**
- Evolve Gulpin (Level 26)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Poison Gas | 1 |
| Pound | 1 |
| Sludge | 1 |
| Yawn | 1 |
| Yawn | 6 |
| Poison Gas | 9 |
| Sludge | 14 |
| Amnesia | 17 |
| Encore | 23 |
| Body Slam | 26 |
| Toxic | 31 |
| Spit Up | 35 |
| Stockpile | 35 |
| Swallow | 35 |
| Sludge Bomb | 40 |

---

## Tropius

**Availability**
- Route 119

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Gust | 1 |
| Leer | 1 |
| Growth | 7 |
| Razor Leaf | 11 |
| Stomp | 17 |
| Sweet Scent | 21 |
| Whirlwind | 27 |
| Magical Leaf | 31 |
| Body Slam | 37 |
| Solar Beam | 41 |
| Synthesis | 47 |

---

## Whismur

**Availability**
- Desertunder Pass
- Route 116
- Rusturf Tunnel

**Evolves to**
- Loudred (Level 20)

**Learnset**

| Move | Level |
|------|-------|
| Pound | 1 |
| Uproar | 5 |
| Astonish | 11 |
| Howl | 15 |
| Supersonic | 21 |
| Stomp | 25 |
| Screech | 31 |
| Roar | 35 |
| Rest | 41 |
| Sleep Talk | 41 |
| Hyper Voice | 45 |

---

## Loudred

**Availability**
- Desertunder Pass
- Victoryroad 1F
- Evolve Whismur (Level 20)

**Evolves to**
- Exploud (Level 35)

**Learnset**

| Move | Level |
|------|-------|
| Astonish | 1 |
| Howl | 1 |
| Pound | 1 |
| Uproar | 1 |
| Uproar | 5 |
| Astonish | 11 |
| Howl | 15 |
| Supersonic | 23 |
| Stomp | 29 |
| Screech | 37 |
| Roar | 43 |
| Rest | 51 |
| Sleep Talk | 51 |
| Hyper Voice | 57 |

---

## Exploud

**Availability**
- Evolve Loudred (Level 35)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Astonish | 1 |
| Howl | 1 |
| Pound | 1 |
| Uproar | 1 |
| Uproar | 5 |
| Astonish | 11 |
| Howl | 15 |
| Supersonic | 23 |
| Stomp | 29 |
| Screech | 37 |
| Hyper Voice | 40 |
| Roar | 45 |
| Rest | 55 |
| Sleep Talk | 55 |
| Close Combat | 63 |

---

## Clamperl

**Availability**
- Resevoir Cave
- Route 104
- Route 124
- Route 132
- Route 133
- Route 135
- Underwater Route 124
- Underwater Route 126

**Evolves to**
- Huntail (Use Deep Sea Tooth)
- Gorebyss (Use Deep Sea Scale)

**Learnset**

| Move | Level |
|------|-------|
| Clamp | 1 |
| Iron Defense | 1 |
| Water Gun | 1 |
| Whirlpool | 1 |

---

## Huntail

**Availability**
- Evolve Clamperl (Use Deep Sea Tooth)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Whirlpool | 1 |
| Bite | 8 |
| Screech | 15 |
| Aqua Jet | 22 |
| Scary Face | 29 |
| Crunch | 36 |
| Zen Headbutt | 40 |
| Baton Pass | 43 |
| Iron Head | 47 |
| Hydro Pump | 50 |

---

## Gorebyss

**Availability**
- Evolve Clamperl (Use Deep Sea Scale)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Whirlpool | 1 |
| Confusion | 8 |
| Agility | 15 |
| Water Pulse | 22 |
| Calm Mind | 29 |
| Psychic | 36 |
| Baton Pass | 43 |
| Aura Sphere | 50 |
| Psycho Boost | 58 |

---

## Absol

**Availability**
- Route 120
- Route 121
- Victoryroad 1F

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Scratch | 1 |
| Leer | 5 |
| Taunt | 9 |
| Quick Attack | 13 |
| Razor Wind | 17 |
| Bite | 21 |
| Swords Dance | 26 |
| Double Team | 31 |
| Slash | 36 |
| Night Slash | 41 |
| Perish Song | 46 |
| Zen Headbutt | 50 |

---

## Shuppet

**Availability**
- Mtpyre 1F
- Mtpyre 2F
- Mtpyre 3F
- Mtpyre 4F
- Mtpyre 5F
- Mtpyre 6F
- Mtpyre Exterior
- Mtpyre Summit
- Route 121
- Route 123

**Evolves to**
- Banette (Level 37)

**Learnset**

| Move | Level |
|------|-------|
| Knock Off | 1 |
| Screech | 8 |
| Night Shade | 13 |
| Curse | 20 |
| Spite | 25 |
| Will O Wisp | 32 |
| Faint Attack | 37 |
| Shadow Ball | 44 |
| Snatch | 49 |
| Grudge | 56 |

---

## Banette

**Availability**
- Skypillar 1F
- Skypillar 3F
- Skypillar 5F
- Evolve Shuppet (Level 37)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Curse | 1 |
| Knock Off | 1 |
| Night Shade | 1 |
| Screech | 1 |
| Screech | 8 |
| Night Shade | 13 |
| Curse | 20 |
| Follow Me | 25 |
| Will O Wisp | 32 |
| Faint Attack | 39 |
| Shadow Claw | 48 |
| Snatch | 55 |
| Grudge | 64 |

---

## Seviper

**Availability**
- Battlepike 1
- Battlepike 2
- Battlepike 3
- Battlepike 4
- Route 114

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Wrap | 1 |
| Lick | 7 |
| Bite | 10 |
| Poison Tail | 16 |
| Screech | 19 |
| Glare | 25 |
| Crunch | 28 |
| Poison Fang | 34 |
| Swagger | 37 |
| Psycho Cut | 43 |

---

## Zangoose

**Availability**
- Route 118

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Scratch | 1 |
| Leer | 4 |
| Quick Attack | 7 |
| Swords Dance | 10 |
| Fury Cutter | 13 |
| Slash | 19 |
| Pursuit | 25 |
| Crush Claw | 31 |
| Night Slash | 34 |
| Taunt | 37 |
| Xscissor | 41 |
| Detect | 46 |
| False Swipe | 55 |

---

## Relicanth

**Availability**
- Underwater Route 124
- Underwater Route 126

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Harden | 1 |
| Tackle | 1 |
| Water Gun | 8 |
| Rock Tomb | 15 |
| Yawn | 22 |
| Take Down | 29 |
| Mud Sport | 36 |
| Ancient Power | 43 |
| Rest | 50 |
| Double Edge | 57 |
| Hydro Pump | 64 |

---

## Aron

**Availability**
- Granite Cave B 1F
- Granite Cave B 2F
- Granite Cave Stevensroom
- Rusturf Tunnel

**Evolves to**
- Lairon (Level 32)

**Learnset**

| Move | Level |
|------|-------|
| Tackle | 1 |
| Harden | 4 |
| Mud Slap | 7 |
| Headbutt | 10 |
| Metal Claw | 13 |
| Iron Defense | 17 |
| Roar | 21 |
| Take Down | 25 |
| Iron Tail | 29 |
| Protect | 34 |
| Metal Sound | 39 |
| Double Edge | 44 |

---

## Lairon

**Availability**
- Seafloor Cavern Room 5
- Victoryroad 1F
- Victoryroad B 1F
- Victoryroad B 2F
- Evolve Aron (Level 32)

**Evolves to**
- Aggron (Level 40)

**Learnset**

| Move | Level |
|------|-------|
| Harden | 1 |
| Headbutt | 1 |
| Mud Slap | 1 |
| Tackle | 1 |
| Harden | 4 |
| Mud Slap | 7 |
| Headbutt | 10 |
| Metal Claw | 13 |
| Iron Defense | 17 |
| Roar | 21 |
| Take Down | 25 |
| Iron Tail | 29 |
| Protect | 37 |
| Metal Sound | 45 |
| Double Edge | 53 |

---

## Aggron

**Availability**
- Evolve Lairon (Level 40)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Harden | 1 |
| Headbutt | 1 |
| Mud Slap | 1 |
| Tackle | 1 |
| Harden | 4 |
| Mud Slap | 7 |
| Headbutt | 10 |
| Metal Claw | 13 |
| Iron Defense | 17 |
| Roar | 21 |
| Take Down | 25 |
| Iron Tail | 29 |
| Protect | 37 |
| Rock Slide | 43 |
| Zen Headbutt | 47 |
| Iron Head | 50 |
| Double Edge | 63 |

---

## Castform

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Tackle | 1 |
| Ember | 10 |
| Powder Snow | 10 |
| Water Gun | 10 |
| Hail | 20 |
| Rain Dance | 20 |
| Sunny Day | 20 |
| Weather Ball | 30 |

---

## Volbeat

**Availability**
- Route 117

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Tackle | 1 |
| Confuse Ray | 5 |
| Double Team | 9 |
| Moonlight | 13 |
| Quick Attack | 17 |
| Tail Glow | 21 |
| Signal Beam | 25 |
| Protect | 29 |
| Helping Hand | 33 |
| Double Edge | 37 |

---

## Illumise

**Availability**
- Route 117

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Tackle | 1 |
| Sweet Scent | 5 |
| Charm | 9 |
| Moonlight | 13 |
| Quick Attack | 17 |
| Wish | 21 |
| Encore | 25 |
| Flatter | 29 |
| Helping Hand | 33 |
| Covet | 37 |

---

## Lileep

**Availability**
- Advent Cave

**Evolves to**
- Cradily (Level 30)

**Learnset**

| Move | Level |
|------|-------|
| Astonish | 1 |
| Constrict | 8 |
| Acid | 15 |
| Ingrain | 22 |
| Confuse Ray | 29 |
| Amnesia | 36 |
| Ancient Power | 43 |
| Spit Up | 50 |
| Stockpile | 50 |
| Swallow | 50 |

---

## Cradily

**Availability**
- Evolve Lileep (Level 30)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Acid | 1 |
| Astonish | 1 |
| Constrict | 1 |
| Ingrain | 1 |
| Constrict | 8 |
| Acid | 15 |
| Ingrain | 22 |
| Confuse Ray | 29 |
| Energy Ball | 32 |
| Amnesia | 36 |
| Ancient Power | 36 |
| Aura Sphere | 53 |
| Spit Up | 60 |
| Stockpile | 60 |
| Swallow | 60 |

---

## Anorith

**Availability**
- Advent Cave
- Route 120

**Evolves to**
- Armaldo (Level 30)

**Learnset**

| Move | Level |
|------|-------|
| Scratch | 1 |
| Twineedle | 7 |
| Mud Sport | 13 |
| Water Gun | 19 |
| Metal Claw | 25 |
| Protect | 31 |
| Ancient Power | 37 |
| Fury Cutter | 43 |
| Slash | 49 |
| Rock Blast | 55 |

---

## Armaldo

**Availability**
- Evolve Anorith (Level 30)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Harden | 1 |
| Mud Sport | 1 |
| Scratch | 1 |
| Water Gun | 1 |
| Harden | 7 |
| Mud Sport | 13 |
| Water Gun | 19 |
| Metal Claw | 25 |
| Protect | 31 |
| Rock Slide | 33 |
| Night Slash | 42 |
| Xscissor | 46 |
| Ancient Power | 50 |
| Slash | 55 |
| Shadow Claw | 64 |

---

## Ralts

**Availability**
- Route 102

**Evolves to**
- Kirlia (Level 20)

**Learnset**

| Move | Level |
|------|-------|
| Growl | 1 |
| Confusion | 6 |
| Double Team | 11 |
| Teleport | 16 |
| Calm Mind | 21 |
| Psychic | 26 |
| Imprison | 31 |
| Future Sight | 36 |
| Hypnosis | 41 |
| Dream Eater | 46 |

---

## Kirlia

**Availability**
- Evolve Ralts (Level 20)

**Evolves to**
- Gardevoir (Level 30 (Female only))
- Gallade (Level 30 (Male only))

**Learnset**

| Move | Level |
|------|-------|
| Confusion | 1 |
| Double Team | 1 |
| Growl | 1 |
| Teleport | 1 |
| Confusion | 6 |
| Double Team | 11 |
| Teleport | 16 |
| Calm Mind | 21 |
| Psychic | 26 |
| Magical Leaf | 30 |
| Imprison | 33 |
| Future Sight | 40 |
| Hypnosis | 47 |
| Dream Eater | 54 |

---

## Gardevoir

**Availability**
- Evolve Kirlia (Level 30 (Female only))

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Confusion | 1 |
| Double Team | 1 |
| Growl | 1 |
| Teleport | 1 |
| Confusion | 6 |
| Double Team | 11 |
| Teleport | 16 |
| Calm Mind | 21 |
| Psychic | 26 |
| Imprison | 33 |
| Energy Ball | 37 |
| Future Sight | 42 |
| Dream Eater | 51 |
| Hypnosis | 51 |
| Aura Sphere | 60 |

---

## Gallade

**Availability**
- Evolve Kirlia (Level 30 (Male only))

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Confusion | 1 |
| Double Team | 1 |
| Growl | 1 |
| Teleport | 1 |
| Confusion | 6 |
| Double Team | 11 |
| Teleport | 16 |
| Calm Mind | 21 |
| Psychic | 26 |
| Brick Break | 33 |
| Leaf Blade | 37 |
| Psycho Cut | 42 |
| Close Combat | 50 |

---

## Bagon

**Availability**
- Advent Cave
- Meteor Falls 1F 1R
- Meteor Falls 1F 2R
- Meteor Falls B 1F 2R

**Evolves to**
- Shelgon (Level 30)

**Learnset**

| Move | Level |
|------|-------|
| Rage | 1 |
| Bite | 5 |
| Leer | 9 |
| Headbutt | 17 |
| Focus Energy | 21 |
| Ember | 25 |
| Dragon Breath | 33 |
| Scary Face | 37 |
| Crunch | 41 |
| Dragon Claw | 49 |
| Double Edge | 53 |

---

## Shelgon

**Availability**
- Meteor Falls B 1F 1R
- Evolve Bagon (Level 30)

**Evolves to**
- Salamence (Level 50)

**Learnset**

| Move | Level |
|------|-------|
| Bite | 1 |
| Headbutt | 1 |
| Leer | 1 |
| Rage | 1 |
| Bite | 5 |
| Leer | 9 |
| Headbutt | 17 |
| Focus Energy | 21 |
| Ember | 25 |
| Protect | 30 |
| Dragon Breath | 38 |
| Scary Face | 47 |
| Dragon Claw | 50 |
| Crunch | 55 |
| Double Edge | 55 |
| Iron Head | 62 |

---

## Salamence

**Availability**
- Evolve Shelgon (Level 50)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Bite | 1 |
| Headbutt | 1 |
| Leer | 1 |
| Rage | 1 |
| Bite | 5 |
| Leer | 9 |
| Headbutt | 17 |
| Focus Energy | 21 |
| Ember | 25 |
| Protect | 30 |
| Dragon Breath | 38 |
| Scary Face | 47 |
| Dragon Claw | 50 |
| Fly | 50 |
| Crunch | 55 |
| Double Edge | 55 |
| Iron Head | 62 |

---

## Beldum

**Availability**
- Advent Cave
- Granite Cave B 2F
- Granite Cave Stevensroom
- Route 111

**Evolves to**
- Metang (Level 20)

**Learnset**

| Move | Level |
|------|-------|
| Take Down | 1 |
| Iron Head | 10 |

---

## Metang

**Availability**
- Evolve Beldum (Level 20)

**Evolves to**
- Metagross (Level 45)

**Learnset**

| Move | Level |
|------|-------|
| Take Down | 1 |
| Iron Head | 10 |
| Confusion | 20 |
| Metal Claw | 20 |
| Scary Face | 26 |
| Pursuit | 32 |
| Psychic | 38 |
| Bullet Punch | 40 |
| Meteor Mash | 50 |
| Agility | 56 |
| Hyper Beam | 62 |

---

## Metagross

**Availability**
- Evolve Metang (Level 45)

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Confusion | 1 |
| Metal Claw | 1 |
| Scary Face | 1 |
| Take Down | 1 |
| Iron Head | 10 |
| Confusion | 20 |
| Metal Claw | 20 |
| Bullet Punch | 26 |
| Pursuit | 32 |
| Psychic | 38 |
| Poison Jab | 45 |
| Zen Headbutt | 50 |
| Meteor Mash | 55 |
| Seed Bomb | 60 |
| Hyper Beam | 77 |

---

## Regirock

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Explosion | 1 |
| Rock Throw | 9 |
| Curse | 17 |
| Superpower | 25 |
| Ancient Power | 33 |
| Iron Defense | 41 |
| Zap Cannon | 49 |
| Lock On | 57 |
| Hyper Beam | 65 |

---

## Regice

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Explosion | 1 |
| Icy Wind | 9 |
| Curse | 17 |
| Superpower | 25 |
| Ancient Power | 33 |
| Amnesia | 41 |
| Zap Cannon | 49 |
| Lock On | 57 |
| Hyper Beam | 65 |

---

## Registeel

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Explosion | 1 |
| Metal Claw | 9 |
| Curse | 17 |
| Superpower | 25 |
| Ancient Power | 33 |
| Amnesia | 41 |
| Iron Defense | 41 |
| Zap Cannon | 49 |
| Lock On | 57 |
| Hyper Beam | 65 |

---

## Kyogre

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Water Pulse | 1 |
| Scary Face | 5 |
| Ancient Power | 15 |
| Body Slam | 20 |
| Calm Mind | 30 |
| Ice Beam | 35 |
| Hydro Pump | 45 |
| Rest | 50 |
| Sheer Cold | 60 |
| Double Edge | 65 |
| Water Spout | 75 |

---

## Groudon

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Mud Shot | 1 |
| Scary Face | 5 |
| Ancient Power | 15 |
| Slash | 20 |
| Bulk Up | 30 |
| Earthquake | 35 |
| Fire Blast | 45 |
| Rest | 50 |
| Fissure | 60 |
| Solar Beam | 65 |
| Eruption | 75 |

---

## Rayquaza

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Twister | 1 |
| Scary Face | 5 |
| Ancient Power | 15 |
| Dragon Claw | 20 |
| Dragon Dance | 30 |
| Crunch | 35 |
| Fly | 45 |
| Rest | 50 |
| Extreme Speed | 55 |
| Outrage | 60 |
| Hyper Beam | 70 |

---

## Latias

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Psywave | 1 |
| Wish | 5 |
| Helping Hand | 10 |
| Safeguard | 15 |
| Dragon Breath | 20 |
| Water Sport | 25 |
| Refresh | 30 |
| Mist Ball | 35 |
| Psychic | 40 |
| Recover | 45 |
| Calm Mind | 50 |
| Dragon Pulse | 55 |
| Dark Pulse | 60 |

---

## Latios

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Psywave | 1 |
| Memento | 5 |
| Helping Hand | 10 |
| Safeguard | 15 |
| Dragon Breath | 20 |
| Protect | 25 |
| Refresh | 30 |
| Luster Purge | 35 |
| Psychic | 40 |
| Recover | 45 |
| Dragon Dance | 50 |
| Dragon Claw | 55 |
| Night Slash | 60 |

---

## Jirachi

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Confusion | 1 |
| Follow Me | 1 |
| Wish | 1 |
| Rest | 5 |
| Swift | 10 |
| Magnet Bomb | 15 |
| Psychic | 20 |
| Refresh | 25 |
| Rest | 30 |
| Flash Cannon | 33 |
| Double Edge | 35 |
| Future Sight | 40 |
| Cosmic Power | 45 |
| Doom Desire | 50 |

---

## Deoxys

**Availability**
- ???

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Leer | 1 |
| Wrap | 1 |
| Night Shade | 5 |
| Double Team | 10 |
| Knock Off | 15 |
| Pursuit | 20 |
| Psychic | 25 |
| Swift | 30 |
| Agility | 35 |
| Recover | 40 |
| Psycho Boost | 45 |
| Extreme Speed | 50 |

---

## Chimecho

**Availability**
- Mtpyre Summit

**Evolves to**
- None

**Learnset**

| Move | Level |
|------|-------|
| Wrap | 1 |
| Growl | 6 |
| Astonish | 9 |
| Confusion | 14 |
| Take Down | 17 |
| Uproar | 22 |
| Yawn | 25 |
| Psywave | 30 |
| Double Edge | 33 |
| Heal Bell | 38 |
| Safeguard | 41 |
| Psychic | 46 |

---
