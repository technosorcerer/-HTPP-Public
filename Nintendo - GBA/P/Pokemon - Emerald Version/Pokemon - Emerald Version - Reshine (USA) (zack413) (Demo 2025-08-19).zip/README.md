# Pokemon-Emerald-Reshine

Features:

    -All Pokemon are shiny by default
    -All Pokemon have a new second shiny form that can be obtained
    -Some QOL or map changes may come down the line as I gain more experience
