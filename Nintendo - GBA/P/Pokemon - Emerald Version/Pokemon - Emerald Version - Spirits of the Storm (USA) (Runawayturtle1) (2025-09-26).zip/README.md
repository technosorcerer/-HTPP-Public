README - Pokemon: Spirits of the Storm

=== INSTRUCTIONS ===
1) Legally acquire a compatible ROM of Pokemon: Emerald Version that matches one of these descriptions:
- "Pokemon - Emerald Version (U)(Trashman)"
- "1986 - Pokemon Emerald (U)(Trashman)"
- "Pokemon - Emerald Version (USA, Europe)"

2) Apply the appropriate patch with its respective method:
- bps: (recommended) https://www.marcrobledo.com/RomPatcher.js
- xdelta: https://www.romhacking.net/utilities/598

3) Run the newly-created ROM on your system of choice!

=== DISCORD ===
Join the Prince Fluff doubles romhacking Discord:
https://discord.gg/PQjSgmk3k

=== CREDITS ===
- Kumatora: World Design, Programming
- Prince Fluff: Battle Design, Balance
- SocKuh and Stompbox: playtesting
- Pokeemerald Expansion: rh-hideout
- Pokeemerald Gen 4 Music: grunt-lucas, CyanSMP64 “Furret”, IPatix, Sierraffinity
- Vs B/W Legendary, Vs Champion Nemona, Waterfall Colosseum Music: NicoSwag (Cipher Admin and Gym Leader Remix in code but unused)
- Small town with lab Secondary tileset (TAAR): Rahtak, Ekat (https://www.deviantart.com/ekat99), Anonalpaca, Idilio, Heartlessdragoon, Vurtax, Skidmarc25, Thewilddeadhero, Zein
- Legend of Zelda Tileset, Lugia Shrine Tileset (TAAR): Ekat, Heartlessdragoon, Vurtax, Rahtak, Yumekua, Hek-el-grande (LoZ), jinxchan6306 (Lugia), Redblueyellow, Morlockhater, Nemu, Ross Hawkins, Pokemon Dawn Team, Slimshady, Thedeadheroalistar, The-Red-Ex, Zein, Fabnt, Idilio, Silverdeoxys563, Puggsoy, Aveontrainer, Shyinn, War8, SteamyJ, Anonaplacca, Dasani, Zeo, Pokemon Rejuvination Team, Random Talking Bush, Remy, robbydude, RocketSeviperShadow, Seiyouh, snuffles5, SphericalIce, taka Digi and Joe Schmoe, The Purple Stuff, TheWildDeadHero, Tonberry2k, XDinky, Skidmarc25
- Looker Overworld Sprite (TAAR): etique
- Shrine (TAAR): SphericalIce
- Extra Tiles (TAAR): Red-eX, Alistair, Hydragirium, Mew1993
- Brick City Tileset (Essentials): Ekat, HeartlessDragoon, VurTax, Alistar, SlimShady
- Brick Cafe Tileset (Essentials): Ekat, HeartlessDragoon, Vurtax
- Small Office Tileset (Essentials): Ekat
- Prevent Map Fade with a Flag: Anon822
- Teleport Camera: SphericalIce
- Unbound Quest Menu: psf, Skeli, ghoulslash, HN, Karathan, Mcboy, Greenphx, BSBob, MM, Tustin2121
- Unbound Quest Icons: belle
- Shake Movement Action: Jamie Foster
- PokeEmerald Rogue Battle Speedup: AlexOn1ine, PokeAbbie
- BW Summary Screen Expansion: RavePossum, Againsts (tiles), Sphericalice (grade sprites), Vexx (auto-format code), Buffelsaft (IV/EV code), Dizzyegg (nature color code), Zeturic (wrapping summary screen), Greenphx9 (referencing code in their pokefirered version), Skeli (graphic for heart indicator based on Unbound's), Zatsu (Tera type icons), Lhea (status icons)
- Gen 5-ish Party Menu: Archie, Team Aqua’s Hideout
- Speaker Nametags: tustin2121
- Blue Overworld: destvol (added walk cycle based on Huro’s sprite commissioned by Paccy) https://www.deviantart.com/destvol/art/RSE-OverWorld-sprites-712791931
- Misc Overworld Sprites (TAAR): Kasen (BW Ace Trainer, Breeders, Hex Maniac), Fan of 4869 (Lisia), PurrfectDoodle (Cynthia), mudskip (Lass, Youngster, Daisy), ryuujiryu (idol, nurse_m, officers), kyle dove and ulithium dragon (fairy tale girl on discord)
- Misc Trainer Sprites (TAAR): Kasen (BW Ace Trainers, Hex Maniac), Fan of 4869 (Lisia), Pawwkie (Breeder F), hyo-oppa (Anabel), mudskip (Lass, Youngster), Rubire4 (Cynthia, Idol, Officer M), Project Palladium (Leaf, Officer F), Bivurnum (Cook Walking)
- Farmgirl modified from Breeder_F sprite by Pawwkie
- Grass, Forest Battle Backgrounds: CFRU Team - Skeli, ShinyMiner, ghoulslash (I think there’s more but I don’t know who else that would be)
- Title Screen Resources: SotS Font: “XBox Logo”
- Genie art based on Ken Sugimori artwork

Special thanks to the MAP+ community <3
