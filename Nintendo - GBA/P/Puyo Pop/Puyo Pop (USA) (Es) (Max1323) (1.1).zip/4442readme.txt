"Puyo Pop"
Traducci�n al Espa�ol Ver. 1.1 (02/07/2019)
por Max1323 (maxmuruchi@gmail.com)
---------------------------------------------------
Descripci�n:
Arle y Carbuncle intentan buscar el camino de regreso a casa,
pero antes de que puedan llegar, deben enfrentar el desaf�o de jugar
Puyo Pop con todas las personas que conocen.

Desarrollado: Sonic Team
Publicado:    THQ y SEGA
Lanzamiento:  11/02/2002 (USA)
              02/04/2002 (EUR)
              18/10/2001 (JAP)
---------------------------------------------------
Acerca del proyecto:
Se tradujo los di�logos de la historia principal y se a�adio
la �.
Se corrigi� algunos textos.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS

Puyo Pop (USA) (En,Ja).gba
File MD5      3EE8E61DFE10BBFC15F51FD52EEF8E14        
File SHA-1    338702EA961B17C46A1DEB960F5D0DF19D7912F9
File CRC32    0901BE49                                
File Size     8.00 MB
                              
                           
                              
                              
                             
                       
