Hack created by BarniBarnstone

Eu rom needed for patching

Only supports english

-------------

If you want to play the vanilla game further with your new items and don't mind 
the characters staying as Strike and Bubbles, you can try this:
Step 1: Download Skytemple. 
Step 2: Open your rom of PMDTheExperiment.
Step 3: Find a scene called credits. You can just type it in the find bar at the top.
Step 4: Open the script by clicking on the name in the bottom right box, labelled scripts.
Step 5: Find the line: switch ( ProcessSpecial(PROCESS_SPECIAL_JUMP_TO_TITLE_SCREEN, 0, 0) ) { }
Step 6: Delete this line.
Step 7: Save your rom, check if it works in the debugger.(You can open it by clicking on the bug icon 
next to the refresh icon.) And if you did it right a vanilla cutscene should play after my credits scene.

------------

Have fun!