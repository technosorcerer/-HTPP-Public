	Pokémon Mystery Dungeon: Halloween Havoc
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Description
───────────────────────────
Visit the relaxing and joyous Harmony Town! Partake in their yearly event and see what awaits you!



Patch Install & How to Play
───────────────────────────
    ・Patch File: Halloween Havoc.xdelta
    ・Preferred Patch Tool: DeltaPatcher.exe (included in download)
    ・Game: Pokemon Mystery Dungeon - Explorers of Sky (USA)
    ・Tested Environment: Desmume

Information
──────────────────────
    ・ This project started around 09-28 2023 and ended 10-31 2023, and it having a general structure of gameplay we usually don't work with we hope everything works as best as it can
	・ Due to time constraints lots of ideas we had could not be made in time, potential updates in the future are a possibility
	
	


Credits below (spoilers)
──────────────────


























































baroness faron
Story
Scripting Scenes
Custom Dungeon Tilesets
Custom Item Sprites
Custom Backgrounds
Custom Objects
Costumed Portraits
Costumed Sprites
New Gen Pokemon Sprites
New Pokemon Portraits
Dungeon Design
Bug fixes
Playtesting


Tainted
Story
Scripting Scenes
Custom Dungeon Tilesets
Custom Background Help
Custom Objects
Costumed Portraits
Custom Item Sprite
Dungeon Design
Custom Shop Design
Bug fixes
Playtesting


Capybara
Skytemple


Adex
Team Assembly Manipulation
Textbox Manipulation
Setting Default Options
Setting Assembly Stats
Dropeye Status Bosses
Invisify Update
Save Bytes
Optimizing the Score System
Key Update
Spicy Lollipop

Irdkwia
Team Assembly Manipulation
Textbox Manipulation
Check input status


End
Edit Extra Pokemon
Disable Tips


Psy Commando
Actor and Level Loader


Michael12
Braixen sprite
Yamask sprite


Pink-No-Tori
Cofagrigus sprite


Pi 3.14
Greavard sprite


Emmuffin
Zorua sprite
Litwick sprite
Phantump sprite
Morpeko sprite
Fidough sprite
Gulpin portraits
Umbreon portraits
Mimikyu portraits
Greavard portrait
Braixen portraits


Nerointruder
Alolan rattata sprite
Woobat sprite


Jaifain
Gourgeist sprite


Ichor
Hisui zorua sprite


Opalite
Espeon portraits


Chime
Mega banette portrait


FunnyKecleonMeme
Cofagrigus portraits


Fortune's Fault Team
Pierce Bone Effect
TUnnel Orb


The Pokemon Company
&
Spike Chunsoft
For the original game

Pokemon Mystery Dungeon
Explorers of Sky

The Legend of Zelda
Minish Cap
Various Art Visuals
