Pokémon Pinball: Ruby & Sapphire (Cartridge Rumble Patch) openFPGA-GBA hackfix

WARNING
================================
Intended exclusively for those with an Analogue Pocket running the openFPGA-GBA core with a DS Rumble Pak inserted in the cartridge slot! This hackfix alters the ROM header data, which could have various unintended consequences, such as causing the game to be incorrectly identified in certain systems or interfering with the functionality of save states. It's a quick-and-dirty hack, not a permanent solution. Use at your own risk until a more robust fix is available from the openFPGA-GBA core developer.


USAGE
================================
To apply this hackfix:

- Download the latest version of the "Pokémon Pinball: Ruby & Sapphire (Cartridge Rumble Patch)" patch here:
  https://www.romhacking.net/hacks/6256/
- Apply the original patch to a clean Pokémon Pinball: Ruby & Sapphire ROM using Lunar IPS or similar patching tool
- Apply this hackfix to the modified ROM using Lunar IPS or similar patching tool


RECOMMENDED ACTION
================================
Consider opening or monitoring issues related to this matter at the openFPGA-GBA GitHub repository:
https://github.com/spiritualized1997/openFPGA-GBA/issues

