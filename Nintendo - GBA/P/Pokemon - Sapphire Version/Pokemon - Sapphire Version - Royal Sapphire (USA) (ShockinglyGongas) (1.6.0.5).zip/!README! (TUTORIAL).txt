!!!READ ME!!!!

How to PATCH:

Step 1: (VERY IMPORTANT)
Obtain a "Pokemon Sapphire Version ( U) ( V 1.1)", or
"Pokemon - Sapphire Version (USA, Europe) (Rev 1)" Rom through your own means
IT *REALLY* Needs to be one of these two. IF IT's NOT, IT *WILL NOT WORK*!
Even if it works, THERE WILL BE BUGS AND THE GAME WILL BE A MESS. THIS IS THE FINAL WARNING.

Step 2:
Download the Royal Sapphire Official Patch INSIDE THIS DRIVE

Step 3: Open https://www.marcrobledo.com/RomPatcher.js/ 
This is an Online Public patcher

Step 4: Insert your (Step 1) Rom file inside the first Slot

Step 5: Insert your (Step 2) Royal Sapphire Patch inside the second Slot

Step 6: Click "Apply Patch" and there you go!

PS: All Documentation and their links can be found in the Royal Sapphire Hub Sheet (Link in Drive)