---------------------------------------------------------------
Pok�puyo

By Yoni Arousement

A ROM Hack of Pok�mon Sapphire I started making in mid-late
2011, was later updated in early 2012, and was last updated in
October of 2014.

Some of the Pok�mon are changed to Puyo Puyo characters, among
other characters like Onnanoko from Wrecking Crew '98. Several
trainers are edited to use different Pok�mon species.
Nonsensical wild Pok�mon locations run rampant in some areas.

Patch over a US Pok�mon Sapphire ROM.
---------------------------------------------------------------