Patch onto Pokemon - Sapphire Version (USA, Europe) (Rev 2)

Docs - https://docs.google.com/spreadsheets/d/1og1AUfvymMvqFUxgUo35gPqBIsKGszFP-YiALSbLqyQ