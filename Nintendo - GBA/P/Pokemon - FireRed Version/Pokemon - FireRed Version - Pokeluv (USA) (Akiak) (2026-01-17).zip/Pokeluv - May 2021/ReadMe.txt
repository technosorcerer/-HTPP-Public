Pokéluv May 2021 Update by Akiak

https://www.pokecommunity.com/showthread.php?t=398903

HOW TO PLAY:
1) Obtain a ROM (.gba file) of Pokemon FireRed (BPRE 1.0) or Pokemon Emerald
2) Download Lunar IPS if you're on Windows, MultiPatch if you're on Mac (both from romhacking.net)
3) Apply PokeluvEmerald.ips or PokeluvFireRed.ips to the ROM using one of these tools

TO RANDOMIZE:
4) Double-click randomizer.jar or RunRandomizer.command
5) A window will open. Click on File in the top left, then Open, and find and open your patched ROM
6) The recommended settings are already set, so there's no need to change anything unless you want to.
7) Click on File again in the top left, then Save

You're done! You may not get any kind of confirmation message from the randomizer, but the ROM has been randomized, so now just open it in your preferred emulator and you're good to go :)

FEATURES:

- All 386 Pokemon have been 'rebalanced' (stats, movesets, abilities etc.) so that they're ALL somewhat viable, or at the very least not completely redundant, while also giving them a little extra flair (but without being unrealistic).

- All level-up and trade evolutions have been replaced by a special evolution by Rare Candy. Stone evolutions are unchanged. Eevee, Tyrogue and Wurmple evolve via Sun Stones (which can be found on wild Gloom and Vileplume) and Moon Stones.

- Some moves have been rebalanced (full list below).

- Legendary Pokemon have been considerably buffed (stats and movesets), and are now uncatchable (think of them as boss fights).

- More double battles
- Better AI
- Gym leaders have better teams
- Catch rates have been buffed, to make Nuzlocking less painful
- Physical/Special/Status split (with icons!)
- National Dex enabled from the start
- Critical hits nerfed to 1.5x (with Gen IV table)
- The 'Sturdy' ability has been updated
- Steel no longer resists Ghost
- Poison survival on 1 HP
- Berry Juice works like Rare Candy (but without evolving) and can be bought at the E4
- A Lucky Egg that doubles your EXP is available from Mr. Stone after delivering the letter (Emerald)
- The Master Ball is replaced by TM35, and an extra PP Max is available (hint: scanner) (Emerald)
- Revamped Battle Tent/Battle Frontier sets (Emerald)
- Many QoL features, courtesy of Pokémon Throwback and Pokémon Emerald Final.
- A specially tailored randomizer, with competitive movesets for all 386 Pokemon.

MODIFIED MOVES:

Acid (50% sp.def drop)
Beat Up (12BP)
Blizzard (110BP)
Bubble (30BP)
Bullet Seed (16BP 25PP)
Clamp (80acc)
Constrict (50% speed drop)
Covet (45BP)
Crunch (def drop)
Disable (60acc)
Fire Blast (110BP)
Fire Spin (20BP 80acc)
Flamethrower (90BP)
Flash (85acc)
Fury Attack (90acc)
Fury Cutter (20BP)
Fury Swipes (85acc)
Glare (95acc)
Headache (replaces Extrasensory)
Heat Wave (95BP)
Hi Jump Kick (90BP)
Hydro Pump (110BP)
Ice Beam (90BP)
Icicle Spear (16BP 25PP)
Jump Kick (75BP)
Knock Off (25BP)
Leech Life (35BP)
Lick (30BP 50% para)
Megahorn (79acc)
Mud Sport (+1 priority)
Mud-Slap (25BP 15PP)
Muddy Water (90BP)
Overheat (130BP)
Petal Dance (80BP)
Pin Missile (90acc)
Poison Gas (60acc)
Present (100acc)
Rock Blast (85acc)
Rock Smash (30BP)
Rock Tomb (55BP 85acc)
Sand Tomb (20BP 80acc)
Sing (100acc)
Snore (45BP)
Splash
Surf (90BP)
Tackle (45BP)
Thief (45BP)
Thunder (110BP)
Thunder Wave (95acc)
Thunderbolt (90BP)
Toxic (90acc)
Uproar (55BP)
Water Sport (+1 priority)
Whirlpool (20BP 80acc)
Will-O-Wisp (80acc)

CREDITS:
Pokemon Throwback by RichterSnipes (https://www.pokecommunity.com/showthread.php?t=285094)
Pokemon Emerald Final by dearman4 (https://www.pokecommunity.com/showthread.php?t=410480)
Reasonable Randomizer by LAT10S (https://www.reddit.com/r/PokemonROMhacks/comments/159cta/pokemon_3rd_gen_reasonable_randomizer)

THANKS:
karatekid552, Gamer2020, DoesntKnowHowToPlay, MrDollSteak, Jambo51, esperance, TL, haven1433, SevenChurches, ABZB, LocksmithArmy, Cha Cha Dinosaur, you

CONTACT:
Akiak#4655 on Discord
aakiiraa@email.com