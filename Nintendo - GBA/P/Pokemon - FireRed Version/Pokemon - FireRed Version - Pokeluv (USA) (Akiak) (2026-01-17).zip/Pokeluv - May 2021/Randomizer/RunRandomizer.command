cd "$(dirname "$0")"
java -jar randomizer.jar