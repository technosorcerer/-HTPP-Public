EnableItemsFR.ips - Gives opposing trainers their items back. Recommended (but not necessary) for casual playthroughs. Apply after PokeluvFireRed.ips

PokeluvFRbasic.ips - Only applies the core Pokemon and move changes (and Rare Candy/Berry Juice mechanics). Use this if you want to combine my hack with a different FireRed hack, or if you just want to play the vanilla game with Pokeluv features

PokeluvFRpss.ips - Same as above, but contains the Physical/Special split