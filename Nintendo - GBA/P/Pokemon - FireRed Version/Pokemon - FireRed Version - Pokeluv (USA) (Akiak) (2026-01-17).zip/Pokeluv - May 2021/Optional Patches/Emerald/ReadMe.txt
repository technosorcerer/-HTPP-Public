EnableItemsE.ips - Gives opposing trainers their items back. Recommended (but not necessary) for casual playthroughs. Apply after PokeluvEmerald.ips

PokeluvEmerald386.ips - Another version of the Emerald patch where all 386 Pokemon can be caught in the wild. Not recommended if you plan on randomizing wild Pokemon (too chaotic for my tastes). Apply to vanilla Emerald ROM.

PokeluvEbasic.ips - Only applies the core Pokemon and move changes (and Rare Candy/Berry Juice mechanics). Use this if you want to combine my hack with a different Emerald hack, or if you just want to play the vanilla game with Pokeluv features

PokeluvEpss.ips - Same as above, but contains the Physical/Special split

PokeluvEfinal.ips - If a new version of Emerald Final comes out and you want to use it, apply this patch after applying the latest version of Emerald Final. However please note that features such as 4th gen evolutions/moves/TMs will not be compatible, so you should stick to using the latest 'legacy' version.