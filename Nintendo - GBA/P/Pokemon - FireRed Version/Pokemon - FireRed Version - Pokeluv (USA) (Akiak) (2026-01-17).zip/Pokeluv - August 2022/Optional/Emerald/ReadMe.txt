The Day-Night cycle may not work correctly with certain emulators which is why there's the option of removing it.

Remove PSS is for those who want an experience closer to vanilla.

Full PSS fully applies PSS to all moves. Not recommended tbh.

Remove EVs removes all EV yields from Pokemon, however you can still use the EV training cave for post-game. This patch also makes all enemy trainers have 0 IVs. Honestly I don't recommend using this, if you dislike EV grinding you can very easily discourage it by just banning wild Pokemon grinding, and only using Moomoo Milk from Oldale (see Nuzlocke section of forum thread for more details).

386 allows you to capture all 386 Pokemon in the wild, as placed by Emerald Final 7.38. Only use this if you're planning to NOT randomize wild Pokemon. Pokeluv by default uses vanilla encounters + version exclusives added, in order to keep the randomization from being too chaotic. You should still be able to capture every Pokemon with the default randomizer settings.