import java.io.File;
import javax.swing.filechooser.FileFilter;

public class ROMFilter extends FileFilter {
	
	public static void main(String[] args) 
	{
		
	}

	public boolean accept(File f)
	{
		if (f.isDirectory()) return true;
		String extension = getExtension(f);
		if (extension != null)
		{
			if (extension.equals("gba")) return true;
		}
		return false;
	}
	
	public String getDescription()
	{
		return "GBA files";
	}
	
	private String getExtension(File f)
	{
		String ext = null;
		String s = f.getName();
		int i = s.lastIndexOf('.');
		if (i > 0 && i < s.length() - 1)
		{
			ext = s.substring(i+1).toLowerCase();
		}
		return ext;
	}
}
