cd "$(dirname "$0")"
cd RandomizerFiles
java -jar randomizer.jar