Nameless FireRed Project
Base: BPRE (English FireRed 1.0)
Updates: http://www.pokecommunity.com/showthread.php?t=366030

==================================================

PATCHING IF YOU ALREADY HAVE A SAVE FILE:

Various parts of the ROM have been shifted in this update. Patching (if you’re keeping your old save file) requires specific steps!

1) On your older file, save the game in a normal pokecenter (not Indigo Plateau/One Island)
2) Keep a backup of your old save file and the old .gba ROM in case something goes wrong
3) Open your new save file with the new ROM to make sure you can move between maps

==================================================

Emulator and Patching:

Your emulator must use real save files (not just save states) because a lot happens after the Elite Four.

Your emulator must use a real time clock to support evolutions, swarms, honey trees, and various other time based events.

Your emulator must support 32mb ROMs.

NUPS is included to do the patching for you. 
1) For “File to patch,” select a clean English FireRed 1.0 file
2) For “UPS patch,” select “Nameless FireRed Project.ups”
3) Check “Create backup of the file (.bak)” if you feel like it
4) Under “If file is invalid,” select “Ignore”
5) Click “Patch”

==================================================

Tips and Stuff:

You can use the Gen VI Experience Share, but I do not recommend using it as a default. The Experience Share can multiply the amount of total experience you gain by as much as 3.5, so just like X&Y, just like ORAS, don’t just leave it on continuously then act surprised when you end up ridiculously overleveled.

The Beginner difficulty should be similar to a vanilla game. As of now, there is no moveset differences between the difficulty levels, only EVs, so even the expert mode isn’t thaaat much harder. The jump to medium is the biggest jump because it includes a level match for gym leaders.

The start menu has other options such as level limits and some nuzlocke options. They can be changed anytime you can open the start menu, so feel free to play around with them.

Sevii Islands aren’t very interesting. More interesting than a vanilla game, but still.

The trainer tower has not been touched yet.

I wouldn’t be surprised if there are still buggy battlescripts.

No special rematches for regular trainers; only level/EV changes in this release.

Most of the old tutors (moves that could last be taught during gen I-IV as TMs/Tutors) have no distribution for gen V and VI Pokemon unless that Pokemon naturally learned the move, even if it make sense. For example, a Froakie wouldn’t be able to learn Water Gun.

All non-legendaries can be obtained. All legendaries can also be obtained, but it will take a reeeally long time. Think of it as a bonus.

Mega Stones can spawn in Hidden Grottos after receiving the Mega Bracelet.

I hate that 1% encounter rate that some hacks use to make Pokemon “rare.” If you’re having a hard time finding a species on a route even though the Pokedex swears it is there, it is most likely in a Hidden Grotto.

AFAIK, all Pokemon have their regular abilities and hidden ability except for some legendary specific abilities. Hidden abilities can be found in Hidden Grottos, in swarms, on honey trees, with Rock Smash, in the Safari Zone (except for rods), at the Sevii Islands, in Cerulean Cave, and with some events.

==================================================

Changed Evolutions:

Slowpoke + Level + Seafoam Islands Bottom Floor = Slowbro
Magneton + Level + Power Plant = Magnezone
Eevee + Level + Berry Forest = Leafeon
Eevee + Level + Icefall Cave Top Floor = Glaceon
Nosepass + Level + Power Plant = Probopass

Slowpoke + Level + King’s Rock = Slowking
Onix + Level + Metal Coat = Steelix
Rhydon + Level + Protector = Rhyperior
Seadra + Level + Dragon Scale = Kingdra
Scyther + Level + Metal Coat = Scizor
Electabuzz + Level + Electirizer = Electivire
Magmar + Level + Magmarizer = Magmortar
Porygon + Level + Upgrade = Porygon2
Porygon2 + Level + Dubious Disc = PorygonZ
Feebas + Level + Prism Scale = Milotic

Machoke + Level + Day + Black Belt = Machamp
Graveler + Level + Day + Hard Stone = Golem
Clamperl + Level + Day + Deep Sea Scale = Gorebyss
Spritzee + Level + Day + Sachet = Aromatisse
Swirlix + Level + Day + Whipped Dream = Slurpuff

Kadabra + Level + Night + Twisted Spoon = Alakazam
Haunter + Level + Night + Spell Tag = Gengar
Dusclops + Level + Night + Reaper Cloth = Dusknoir
Clamperl + Level + Night + Deep Sea Tooth = Huntail
Phantump + Level + Night + Miracle Seed = Trevenant
Pumpkaboo(size) + Level + Night + Miracle Seed = Gourgeist(size)

Karrablast + Level + Shelmet/Accelgor in party = Escavalier
Shelmet + Level + Karrablast/Escavalier in party = Accelgor

Poliwhirl + Level + Overworld Rain = Politoed

Eevee + Level + Fairy Move = Sylveon

Boldore + Level + Stone Edge = Gigalith
Gurdurr + Level + Superpower = Conkeldurr

As a treat, Inkay does not require turning your computer upside down.

Any evolution not listed functions the same as Gen VI

==================================================

Pokemon Locations:

Not included for now :)

==================================================

Alpha 1.01 Fixes:

-Aerial Ace and similar attacks actually hit again.
-Dragon Tail/Circle Throw switches don’t trigger on fainting, immunity, etc.
-Headbutt/Whirlpool no longer appear as field moves.
-Spiky Shield & King’s Shield cannot be spammed.
-Multiplayer rooms should be returned (but I don’t know how to test this).
-Illusion ignores Eggs at the back of the party.
-Rains more often.
-VS. Seeker actually does something.
-Power Anklet, Lens, and Band fixed to give the proper EVs.
-A few male swimmers with moves the froze the game have been fixed.
-Three Island story moved around.
-Ability Capsule changing nature, Everstone in breeding, and other PID related problems.
-Another Day-Care bug that’s embarrassing to the point that I won’t say what it is, and I’m shocked no one stumbled on.
-Magic Bounce doing nothing.
-Static/Magnet Pull occasionally freezing the game.
-Four Island IV Rater freezing for 0 IV Pokemon.
-Overcoat blocking what Bulletproof should be blocking.
-Justified & Rattled not triggering on Dark moves.
-Fixed a bug with nicknaming gift Pokemon.