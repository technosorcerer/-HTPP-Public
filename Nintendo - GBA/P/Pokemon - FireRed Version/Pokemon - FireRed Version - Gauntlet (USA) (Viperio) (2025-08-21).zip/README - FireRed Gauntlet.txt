FireRed - Gauntlet

- The player starts with all badges and HMs.
- All main game trainers have been removed from the overworld, except the champion.
- Talking to the champion starts a gauntlet where all main game trainers must be battled back to back without a chance to save or heal in between.