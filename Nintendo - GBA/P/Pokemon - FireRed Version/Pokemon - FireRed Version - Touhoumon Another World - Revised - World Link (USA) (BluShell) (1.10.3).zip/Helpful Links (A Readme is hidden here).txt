Readme:
https://docs.google.com/document/d/1w0O1fmUwIPzSY0_yI2wnXoyoUoK6K89x/edit?usp=sharing&ouid=105579225219363819221&rtpof=true&sd=true

General Boneka Overview:
https://docs.google.com/spreadsheets/d/1eRFOhlZ5l9XvE2YSbcTs7cres9W4OVQUM_VHB8plvwM/edit?usp=sharing

Wild Encounter List (both hacks):
https://docs.google.com/spreadsheets/d/1zYS27dVmOpO2QBBxfX_9XRqp4FybzeoDDLAJS4JVeIM/edit?usp=sharing

PokeCommunity thread:
https://www.pokecommunity.com/threads/497990/

Discord server:
https://discord.gg/2uDesdbatF