READ ME BEFORE YOU FIGHT ETHAN/GOLD!

This is intended to be the last thing you do in the game, the canon ending to the protagonist's journey. Thus, there is no "autosave"
and continue option after you win - I strongly recommend saving when prompted before so you don't lose any progress since your last
save when the credits roll.