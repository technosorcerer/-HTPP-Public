Pokémon Throwback by RichterSnipes

Unofficial Expansion by Tybobeebo

v1.1 (July 24, 2025)

----------------------------------------------------------------
Foreword

	RichterSnipes' Pokémon Throwback is, in my view, the definitive way to experience the Kanto games. It's a phenomenal blend of
	traditional gameplay with Quality-of-Life improvements and retro aesthetics. Playing it for the first time is one of the reasons
	I wanted to learn how to ROM hack. It's the inspiration for this hack - when I finished it, I didn't want to put it down. So,
	I decided to make it so I wouldn't have to (for a little while longer anyways).

	I have always felt that Gen I and its remakes have had the most barebones story, even among a franchise with largely barebones
	stories anyways. What I have aimed to capture with this hack is exactly the game I would have loved when I was 10 years old
	and first fell in love with Pokémon. I wanted to implement moments like what I have always loved the most in the games- stuff 
	like Red at Mt. Silver, the Fame Checker, Looker in XY, Team Rainbow Rocket in Alola, Steven in HGSS, Cynthia in Undella Town, 
	and a lot of the great easter eggs/nods from the Let’s Go games. You will find many moments like these in this game.

	I also wanted to make possible something that tortured me as a child who desperately wanted to catch 'em all in Pokémon Ruby, but
	was too broke to afford a Link Cable. In my hack, all 386 Generation III Pokémon can be registered legitimately and most importantly, 
	tastefully. I attempt to maintain a vanilla, Game Freak-y feel, especially in the pre-Elite Four base game.

	This is my first ROM hack and it is the culmination of six years of off-and-on ROM hacking, more game-breaking bugs than I can
	count, and multiple long-term (multiple year long) rage quits. If you are one of the people on Reddit that saw my post of my
	broken, four year old build and encouraged me to pick it back up again, thank you so much. It's by no means perfect, innovative,
	or world-shaking, but I am very proud of what I have accomplished as an amateur with nothing but a lifelong love for the Pokémon
	franchise. Thank you for playing - I really hope you love it as much as I do.

----------------------------------------------------------------
Notable Features in RichterSnipes' Pokémon Throwback (my base game):

	GB Sounds allow you to hear the classic chirptune Gen I soundtrack at the click of a button, found in your Bag from the 
	beginning of the game.

	Catch 'em All: All Gen I and II Pokémon present in the base game. (Gen III added in my expansion!)

	Wardrobe Changes: Male and Female player and rival models changed to better reflect concept art of Red, Blue and Green from Gen I.

	Many, many Quality-of-Life changes.

	Full list of RichterSnipes' changes can be found in the original Throwback documentation files which I have included in the Google Drive.

----------------------------------------------------------------
Notable Features Added by this Expansion:

	Route 28, Mt. Silver, Route 26-27, Tohjo Falls, New Bark Town, Route 29, Route 45, Cherrygrove City, Routes 30-31, Dark Cave, Violet
	City, Routes 36-37, and Ecruteak City have all been added to the postgame and are accessible once the Sevii Islands postgame challenge
	is complete and you’ve given the Sapphire to Celio. Complete with new trainers, encounters, Gyms and wild Pokémon. Battle the protagonist
	of GSC/HGSS at the top of Mt. Silver for a "canon" ending to Red's (or Green's) journey.

	Rocket Story Expanded: All references to “Admins” has been changed to Executives in line with the Johto games. The Warehouse Admins 
	have been given new sprites as a nod to their Gen IV appearances and explicitly named Ariana and Archer. Proton and Petrel have been
	subtly added to the game as nameless grunts working their way up- see if you can spot them! Looker, globetrotting elite of the 
	International Police, has been added to the main story on the trail of Team Rocket. He appears in a few missable cameos and a few
	essential story beats.

	Rocket Day-Care: sell any Pokémon to Team Rocket for five Rare Candies a pop in the Rocket Day-Care, replacing the Day-Care Center
	south of Cerulean. (The Four Island Daycare/Breeding Center still functions as normal). This is optional to provide a less grind-heavy
	experience for those who choose it and allow anyone to complete the full experience of the game regardless of age, skill/experience level
	or amount of free time.

	Full 386 National Dex Tastefully Implemented: All Johto and Hoenn Pokémon can be found in the postgame, including legendaries. The Sevii 
	Islands have been reworked- now, they are located between the three regions of Kanto, Johto and Hoenn, and Pokémon from all three regions
	can be found there. Sevii trainers have additionally been tastefully reworked to use a mixture of Pokémon from all three regions in their 
	teams.

	Story events and dungeons have been added to the postgame enabling capture of the Regis, the Weather Trio, Latios and Latias, Mew, Celebi, 
	and Jirachi. Most existing legendary events have had stories/questlines added or beefed up, including Mewtwo, Navel Rock (Ho-oh and Lugia), 
	Birth Island (Deoxys), and the roaming Legendary Beasts.

	The Elite Four have had their levels reduced to eliminate the need for main-story grinding. Several high level optional boss trainers have 
	been added to the postgame. All Gym Leaders have more interesting teams.

	A bunch of new NPCs have been added, with dialogue connecting to Gen 2 and other games, expanding on what Game Freak already did with the Fame
	Checker.

	All Kanto starters are obtainable through their Yellow events in Cerulean, Route 24, and Vermilion. You can use Red's canon team if you'd like!

	...AND MUCH MORE! See the "Rough Changelog" .txt file for a full list of changes in no particular order, and the "386 Pokédex Completion
	Documentation" .txt file for full list of Hoenn and Johto Pokémon I moved and added from RichterSnipes' Throwback base.

----------------------------------------------------------------
Optional "Oldhead Version"

	Functions identically to the default version, but refers to the protagonist of GSC/HGSS as "Gold" instead of "Ethan" in the postgame. Lyra's
	House in New Bark Town has been replaced with Elm's House as it is in the Gen II games. Gold has had his team adjusted to better reflect Gen II.
	
	This version does not include the modern Physical/Special split - instead, physical/special functions as it did in Gen 1-3 where it's determined
	by the move's type.

	Patch this version to a blank Firered instead of the default patch, NOT on top of an existing Throwback Unofficial Expansion .gba file.

----------------------------------------------------------------
Patches and Compatibility

	The IPS file needs to be patched onto a blank copy of Firered (U) (Squirrels). I've tested it with Lunar IPS- there are also some online links
	that work if you have an iPhone or something. Try this one: https://www.romhacking.net/patch/

	This game *should* be compatible with an existing save of Throwback.... maybe even vanilla? Try it out and let me know, but always back up your
	save first.

----------------------------------------------------------------
Known Bugs/Issues:

	Lots of locations display you being in the wrong place when you try to Fly or open the Town Map. Some of that's because I repurposed unused Sevii
	Island location headers and can't figure out how to change which map they display on, but some appear to be bugged (Mt. Ember for example).
	Shouldn't really affect gameplay, but let me know if you know how to fix it.

----------------------------------------------------------------
Join my Discord for developer updates and to give me feedback!
https://discord.gg/sdg36fEE

If anyone wants to use any part of this hack as a base for theirs- feel free, just give proper credits! Thanks for playing!



