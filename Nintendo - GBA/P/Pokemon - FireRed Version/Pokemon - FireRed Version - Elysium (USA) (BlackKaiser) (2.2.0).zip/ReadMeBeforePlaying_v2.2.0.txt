*****************
Read me before playing! 
*****************
*****************

Title: Pokemon Elysium (2017)
Current Version 2.2.0 (23-November-2024)

Information:
This is a story-focused RomHack of Fire Red US 1.0. It was created from scratch.
It consists of two Patch files Main Game(A) and Finale(B)
Main Game Takes place in a region called Rhea(which is the game's main one) and a smaller one called Savahnn. (Storywise: Part 1,2 and 3) The prologue takes place on the island of Crysta.
Finale: Takes place mostly on an island called Elysium, aboard a cruise ship and a chain of islands called Therian Isles. (Storywise: Part 4).
Recommending upset patcher v04 to patch the files.


*******
Story:
*******
Two millennia after the war that ended the Enlightened Men's civilization, a 16-year-old girl from the small island of Crysta begins her journey to become a Pokémon trainer and Champion.

*******
Features/Description:
*******
Physical-Special Split
A mix of Pokemon, moves and types up until Pokemon X and Y. Gen I, II and III mostly but there's a number of pokemon from the next generations like Hippopotas, Garchomp or Galvantula (Check the online excel file for the full list of obtainable pokemon)
*The actual starter is not the pokemon you are given at the beginning. (this will make sense once you play it).
Fairy Type-Pokemon & Moves (replacing old ones)
Certain evolutions (Gengar, Machamp, Kingdra etc) that needed trade to take place, now only need leveling up to level 45. Electivire, Magmortar to lvl 50, Dusknoir to lvl55. Others like Scizor or Snorlax are rewards of certain sidequests. (Check the online excel file for the full list of obtainable pokemon)
Story-related fakemon and fakemoves
Mega Evolutions of certain pokemon (up to X&Y)
Custom map & places to explore especially once you get a couple of HMs.
HMs: Surf, Fly, Strength and Waterfall (in that order)
Sidequests that reward you with rare pokemon, moves or special items.

---
What to do:
Use save states to save your progress rather than the game's built-in save feature. This way you can pass your progress to Part B. I.e in Visual Boy Advance, SHIFT+F1 saves an instance to a .sgm file.
Switch Battle Style to SET for more challenge.

What to not do:
Try to complete the Pokedex. You can't catch every pokemon, the focus of this Rom Hack is the story.
Do not release Pokémon that were given to you for obvious story reasons, as this could potentially lead to the game being softlocked. Release only the Pokémon you've personally caught using a Pokéball.
---

****Important****
Known Issues/Bugs: 
At a certain point in the game, you will softlock if you release an obtainable Lapras before obtaining HM Surf.
In very, very rare occasions, the player's sprite (may) suddenly messes up. This can be quickly fixed by entering or exiting a building or cave or using FLY. This has been fixed but there's still a very small chance you may encounter that bug.
Please be aware that there might be spelling or language errors in the game, as English is not the creator's native language!

**** Patching FILE B*****
When prompted by the game, you will need to patch Part B onto a clean ROM and use your most recent save file (saving state) to continue the story. Depending on your emulator, you may need to rename or relocate a file to a different folder.
In terms of the storyline, you must transition to the new ROM after boarding the ship known as S.S. CHALLENGER. This should occur after you have obtained all 8 badges and participated in the initial rounds of the championship at Battle Colosseum.


***Credits:***
Diegoisawesome for their XSE Scripting Tutorial
Alistair for various Tilesets
The Contributors of Gen VI and V: DS-Style 64x64 Pokemon Sprite Resource on Pokecommunity
Physical/Special Split (probably by Doesn'tKnowHowToPlay)
Unknown poster's guide for helping me create custom moves (didn't found the post/poster, will update)
u/Grazerous for playtesting and instructions about how to patch Part B on iOS.

***Version Changelog***
Version 2.2.0
* The ending has been changed, introducing a new unique battle section and altered story resolutions for some characters. This new scene is based on a piece of lore that I always wanted to make more prominent in the game's story.
* The EXP. Share has been tweaked. Now, the Pokemon holding it will gain full EXP even if it doesn't participate in battle. 
* A new feature has been added allowing repeatable trainer battles on specific routes by trading Heart Scales in the PokeCenter
* The game's balance has been adjusted, particularly to reduce the level gap after the 6th badge. Grinding should now be minimal or entirely unnecessary with this update. 
* Overworld sprites have been improved to make the game feel more unique, and some characters now have completely new sprites (like the 7th Gym Leader or the Pirate Arena Champion).
* Several minor bugs -mostly graphical- have been fixed (like one in several optional caves in Elysium island).
* Minor dialogue changes. (i.e Made the 3rd puzzle on Eerie's dark tower make more sense, etc)
* A guide for the game's major sidequests has been added.


Version 2.1.0
* Fixed the English of the game (most of it at least).
* Visual overworld improvements
* Changes in the game's level curve aim to reduce grinding and encourage exploration. Made the game easier since it's story focused.
* TMs are now reusable but limited, offering 7, 5, or 3 uses for each one you acquire.
* Adding Move Releaners/Deleters in several areas of the game in Part B.
* Rare Candies purchase is available right at the end of the game before the final battles.
* Changes in several Pokemon's movesets
* Players can travel back and forth to Amira Isles even after completing the main mission in that area.
* Fixed a bug where the players enter the casino screen near the end of the game.
* Fixed a bug here the game warps the player into a cave after the end of the game.
* Fixed a bug where the player can fly back to the Refugee Camp in the epilogue.
* Fixed the catch rates for some Pokemon that were uncatchable.


Version 2.0.0
* All Megaevolutions of the game's Pokemon are now available
* Added new Pokemon
* Added alternate forms Pokemon
* Several existing Pokemon were made available to the player (like Charmander, Squirtle, Abra, Tyranitar, etc)
* Balancing issues: Items like Exp.Share, Lucky Egg and Rare Candies are available way earlier in the game.
* A couple of sidequests and places to explore were added.
* Move Tutors and in-game trades were enhanced
* New overworld Sprites and tilesets improvement
* New intro
* Menu graphical glitch fixed.
* A couple of spelling and grammar errors were corrected. (I'm doing my best with that one, trust me)

Bugs
* Sometimes in the player's reflection palette on the water.

Version 1.2.0
* Added Froslass, Probopass (removed Delibird and Sableye)
* Added moves: Dragon Pulse, Bug Buzz, Zen Headbutt, Ice/Thunder/Fire Fang
* Updated Pokemon attacks with the above moves.
* Improved animations for several moves (Flash Cannon, Dazzling Gleam etc)
* Fixed a messing sprite glitch on several occasions
* Fixed messed dialogue on several occasions

Version 1.1.0
* Various Map/Dialogue/Scripting corrections and fixed bugs.
* Added intro to the game.
* Added Hall of Fame after the "THE END" screen.
* Fixed an issue with DELPHOX messing stats when evolving from Braixen.
* Added Pokemon: Glaceon, Yanmega, Rhyperion, Honchcrow, Weavile, Budew, Roserade, Magnezone, Mismagius
* Removed Pokemon: Sentret, Furret and Oddish, Gloom, Vileplume/Bellosom 
* Heatran, Gardevoir and Mega Gardevoir are now obtainable/catchable.
* Added right cries on some later generation pokemon like Sylveon and Xerneas.
* Added Cut Content in the last battle
* Fixed battle backgrounds according to the current location the player is.
* Fixed and issue where pressing CHECK on the item AGENT CARD crashes the game.


Version 1.0.3
File A
* Fixed an instance where for some players returning back from Savahnn doesn't allow them to proceed the story in the Rangers HQ (note: if your latest save is inside the Rangers HQ, get out, stroll around the building a bit and then get in again to continue).
* Map/dialogue fixes.

File B
* Map fix: the boundaries of the mind prison have been switched to black color, to not confuse the players.

Version 1.0.2
File A
* Strange Sprite switch in Wade's Booth during the Championship's 2nd Qualifying round when the trainer opens up the menu. It can softlock the game.
* Map fixes

Version 1.0.1
File A
* Removed the skeleton creatures who cause the game to freeze/crash in Ghost Island
* Removed Infinite Nugget pokeball in Porta Arkasia (in the house of the man who tells you about the map shards).
* Empty Pokemon slot in sunken Crysta that causes a ??????? Pokemon Encounter

File B
* Removed the skeleton creatures who cause the game to freeze/crash in Mt. Aterra

//Minor Spoilers - Guidelines
***Suggestions about sidequests***
****
****
****
-Some quicksands in Akra Desert are not traps and they can lead you down to secret underground chambers.
-Do not sell the card key if you want to follow a major sidequest to the end.
-The Black Cross Knights sidequest takes place during a specific time window only, right after the end of Chapter 1 but before you travel to the region of Savahnn.
-The Clown Prince sidequest is available only during Chapter 1. It fails if it isn't completed by the end of that chapter.
-The Slowpoke Tail Auction is only available during Chapter 1, and only before completing the main mission at the Free Wings Headquarters.

******
******
******

//----Main Story Spoilers about how to proceed in some points where it's not obvious:------
- Chapter 2: To get inside the OLD AMBER's cave, a quicksand nearby will lead you to an undeground chamber rather than rescued and brought back to Porta Arkasia.
- Chapter 2: After obtaining the 5th badge, you may want to explore behind Porta Arkasia's Lab.
- Chapter 2: Once you reach Alabasta City, a specific individual in the city's restaurant/saloon can grant you access to the port.
- Chapter 2: If you find yourself back in Alabasta City, you can return to Amira Islands by interacting with the ship that originally brought you there.
- Chapter 3: Master Hajan is hiding inside of a building in the western part of the Monastery.
- Chapter 3: After obtaining the 7th badge, you can access the second floor of Town CHIONA's PokeCenter.
- Chapter 3: In Castle Houndbourg's Library, interacting with a bookshelf can reveal a secret passage.
- Chapter 3: To enter Azurea's City Lighthouse, seek the assistance of a specific individual in village CRAB, north of Route 11.
- Chapter 4: On S.S CHALLENGER, going to your bed to sleep at the end of the day will advance the main story.
- Chapter 4: In the Shrine with the Chatot that can speak, there's a small puzzle that can get you out. Inspect the room's statue to discover a hidden coin within the shrine's walls. Examine the inner wall closely, and you'll notice a spot/crypt where the "::" pattern is damaged and not like the rest of the wall. 
	     Retrieve the coin from there and place it in the statue. Then, take 8 steps to the right (not 4, as the Enlightened Men's size was double that of a human), and simply pass through the wall.
- Chapter 4: CAMP-B Gates: Once you reach there you have to find your Championship opponent. Go back to the last checkpoint, you want to look for a hidden cave pathway near the small hill, between the high grass.
- Chapter 4: In President Maximus' private room, interact with various objects to solve a mini-puzzle and progress.
- Chapter 4: Within the Hidden Valley's secret lab, you'll encounter a puzzle on the first level. To solve it, follow these steps:
	1.Locate the Generator Card in the southeastern part of the level.
	2.Activate the Generator found in the western part of the level through the panel next to it.
	3.In the central room, switch the lights to open the door. Ensure that all 5 sets of lights turn red before use the panel. For a quick solution, toggle the 2nd from the left, the 4th from the left, and then the one in the middle.




