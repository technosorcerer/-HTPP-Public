I'm sorry if i missed some important documentation in here.
But I will improve on that once I have extra time.

AS this is still just a beta. Please make sure you save state often.
any bugs please report here https://www.pokecommunity.com/showthread.php?t=436368