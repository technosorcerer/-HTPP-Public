The Documentation

First I would like to say thanks for trying my RomHack.
And I hope you enjoy the idea behind it.

The documentation is not Perfect. So whatever questions you have please asked in the Pokecommunity if it's not in the files already.

or directly dm me at my reddit 'calistrotic22'

This hack was purely me having my own take on Pokemon Game.
Because it is not CFRU, be aware that it won't be as good as the great 'radical red' engine-wise lol.

This was made way before i found out about CFRU.
I barely have time to complete this, so I ain't going back to zero to learn the CFRU engine.

Hopefully the few bugs that is still in the game don't bother your enjoyment too much.

Thanks and up to you if you want to give me feedback or criticism in Pokecommunity https://www.pokecommunity.com/showthread.php?t=436368

After Gym 7 badge. There will not be Gym 8.
Immediately go to the Elite 4