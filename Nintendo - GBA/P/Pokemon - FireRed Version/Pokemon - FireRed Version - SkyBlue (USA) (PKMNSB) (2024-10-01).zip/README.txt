﻿[INFORMATION]
Pokémon SkyBlue is a fangame developed for GBA, based on Pokémon Fire Red (U).

[RECOMMENDATION]
Playing on the mGBA emulator is recommended!
Other emulators tend to give errors.

[WARNINGS]
If your screen freezes on a white screen, or if you can't save the game:
You should to CHANGE the emulator's options...

1) Go to "Save Type" a select the option "Flash128KB".

2) Close the emulator, delete the created ".sav" file, and then open the ROM.

[COMMUNITY]
Don't forget to join our community through our Discord!
Where we discuss topics related to SkyBlue and keep up with the project's development.

https://discord.com/invite/PY3ZfJPBdW

If you have any reports or complaints regarding the project, feel free to let us know! :)