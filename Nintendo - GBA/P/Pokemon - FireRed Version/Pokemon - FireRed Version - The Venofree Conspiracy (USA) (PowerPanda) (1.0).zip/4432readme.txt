Title: Pok�mon - The Venofree Conspiracy
Author: PowerPanda
Version: 1.0

Applies to: Pok�mon Fire Red
No-Intro Name: Pokemon - Fire Red Version (USA)
(No-Intro version  20130720-015858)
ROM/File SHA-1: 41CB23D8DCCC8EBD7C649CD8FBB58EEACE6E2FDC

--------------------------------------------------------------------------------
-=Intro and Description=-
There is a popular conspiracy theory for Pok�mon, and it goes like this:
Butterfree and Venomoth's sprites were swapped late into development. There is
a lot of evidence for this, the main evidence being that Venonat and Butterfree
have identical eyes and mouths. It is a theory that "can't be unseen".

This patch changes the sprites of Butterfree and Venonat so that people who
cannot unsee this theory can play their Gen III games with "corrected" sprites.
--------------------------------------------------------------------------------
Credits

Hacking - PowerPanda
Programs Used
PGE v3.8.1