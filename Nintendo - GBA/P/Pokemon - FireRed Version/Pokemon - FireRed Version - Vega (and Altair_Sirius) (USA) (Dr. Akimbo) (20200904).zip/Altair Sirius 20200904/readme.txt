﻿ZIP Contents:
- Pokémon Altair IPS patch
- Pokémon Sirius IPS patch
- This text file

Patch to a clean English Emerald ROM. The Altair and Sirius IPS patches are both included, but you should choose one to play. (The games are almost identical.)










---- INTRODUCTION ----

The Hoenn region, where humans and Pokémon live together with a smile...

One day, suddenly, huge meteors struck the Hoenn region -
a catastrophe that befell the entirety of Hoenn.
The meteors caused enormous damage to every city...

Despair had stolen the smiles from everyone's faces.
However, that's not what our hero saw on arrival.
Pokémon and people worked together to rebuild the cities,
and the Gym Leaders reopened the Gyms to prepare for new challengers...

Encounter new Pokémon created from the meteor strikes!
Fight against Team BH (Black Hole), a team with an evil plan centered around a mysterious and powerful Pokémon!

A story written with a new outlook...
New Pokémon appearing one after another...

Pokémon Altair and Sirius.










---- FAQ ----

Q:	I heard that some Pokémon have different evolution conditions than normal. How do they evolve now?
A:	Kadabra + Lv38 -> Alakazam
	Graveler + Lv38 -> Golem
	Machoke + Lv38 -> Machamp
	Haunter + Lv38 -> Gengar
	Onix + Lv30 -> Steelix
	Scyther + Lv30 -> Scizor
	Misdreavus + Lv37 -> Mismagius
	Absol + Lv30 -> Dizasol
	Girafarig + Lv30 -> Folifarig
	Tentacruel + Water Stone -> Tentyrant
	Electrode + Thunder Stone -> Sphericoil
	Roselia + Leaf Stone -> Roserade
	Budew + Happiness -> Roselia
	Poliwhirl + Happiness -> Politoed
	Pikachu + Happiness -> Machu
	Slowpoke + Happiness -> Slowking
	Feebas + Happiness -> Milotic
	Ralts + Happiness -> Kirgicia
	Kirlia + Lv30 when Attack and Defense are equal -> Gallade
	Breed Marill or Azumarill -> Azurill
	Breed Roselia or Roserade -> Budew
	Breed Wobbuffet -> Wynaut
	Breed Lapras -> Pressie
	Breed Clefairy or Clefable while it holds the Lax Incense -> Cleffa

Q:	Why isn't Dusknoir in that list?
A:	Sorry. Development was started back when Diamond and Pearl were new and the Reaper Cloth was postgame, so we chose to omit it.

Q:	How do I get past Mauville City?
A:	Think three-dimensionally. That is to say, go underneath.

Q:	Why aren't the Ditto hiding around Fortree City listed in the Pokédex?
A:	Ditto is just a bonus thrown in for breeding purposes.

Q:	How do I catch Lylapse, Ganimede, and Nemea?
A:	Lylapse is in the deepest part of the Abandoned Ship. (Required: Surf, Dive)
	Ganimede is in the deepest part of Meteor Falls. (Required: Surf, Waterfall)
	Nemea is in the deepest part of the Cave of Origin. (Required: Strength)

Q:	Where did Groudon and Kyogre go after the cutscene?
A:	Groudon is in Terra Cave (entered through Victory Road 1F).
	Kyogre is in Marine Cave (entered through Victory Road B2F).

Q:	Why didn't I get the National Pokédex after entering the Hall of Fame?
A:	The Hoenn Pokédex contains all the Pokémon available.

Q:	Why does the sign next to Billy's house in Petalburg City still say "Wally's House"?
A:	The two of them are brothers, so it's still Wally's house, after all.

Q:	Where's the Pokéblock Case?
A:	The Pokéblock Case is now a prize from the Pokémon Arena in Lilycove City.

Q:	Where do I find Munchlax?
A:	You receive it in the Pokémon Building.

Q:	Why can Norman's Snorlax use Self-Destruct?
A:	He visited the Orre region.

Q:	Ampharos moves when it shouldn't. This is a bug, right?
A:	It's a technical issue we couldn't solve. So, yes.

Q:	Where do I find all the Pretty Stones?
A:	Look absolutely everywhere. TVs can only be examined from the front.

Q:	Why aren't the Legendary Trainer's Pokémon shiny anymore?
A:	He's using different Pokémon than the ones from the Multi Battle.
	He has boxes full of Pokémon from breeding for perfect IVs.

Q:	Why won't the game of hide-and-seek end?
A:	The timing for when it ends is random. Keep at it.

Q:	Can Pokémon #202 change Forme?
A:	Only through trading; Altair and Sirius can trade with each other. Trading is the only way to complete the Pokédex, but there's no reason to do that.

Q:	How do I fight Sylvia at her full strength?
A:	Clear the Sphere Ruins and meet all of the Elite Four in Alto Mare. If you defeat her and talk to Bianca, then something might happen...










---- VERSION DIFFERENCES ----

The version exclusive Pokémon are as follows (Altair on left, Sirius on right):

Starly family			<---> 	Pidgey family
Liepus				<---> 	Lunabitt
Toxroach family			<---> 	Rollder family
Grimer family			<--->	Gulpin family
Hantama				<--->	Spelven
Absol family			<--->	Girafarig family
Grindon family			<--->	Tyranos
Asphere (Altair Forme)		<--->	Asphere (Sirius Forme)

In addition, some Pokemon are more common in one version:

Weedle family			<--->	Caterpie family
Glameow family			<--->	Meowth family
Duskull family			<--->	Misdreavus family

Some unimportant trainers switched which version-exclusive Pokémon they use.

The Pokédex entries are entirely different in each version.