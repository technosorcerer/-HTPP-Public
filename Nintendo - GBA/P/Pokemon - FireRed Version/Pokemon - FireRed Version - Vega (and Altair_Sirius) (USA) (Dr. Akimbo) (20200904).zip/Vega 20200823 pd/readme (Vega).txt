About this patch:
	Patch to a clean English Fire Red ROM. If you patch over a file already patched with Vega, Procyon, or Deneb, we can't guarantee it will work right.

About recommended software:
	The following software is recommended for this patch.
	Patch tool: LunarIPS
	Emulator: VBALink

About redistribution:
	Please link to the Pok�community thread, not the mediafire link. This ensures your link will always go to the latest version.

-------------------------------

There are parts of the story that won't make sense unless you've played Emerald and one of Altair or Sirius, so it's recommended to play them first.
It would also help to have played a game in the Pok�mon Ranger series, but that isn't required.

There is no trade compatibility with Altair and Sirius.

There are no issues with trading and battling with other copies of Vega, but the game was developed without considering the impact of trading in HM moves, so you may affect the intended story order this way.