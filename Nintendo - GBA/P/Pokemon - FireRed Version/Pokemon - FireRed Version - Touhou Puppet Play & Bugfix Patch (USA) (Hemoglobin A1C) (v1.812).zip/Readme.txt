Touhou Ningyougeki (Puppet Play) Files 
Translated and Compiled by Meido Matsuri

Contents:

- ZIP file available from the creator's website with the original JP text.
- Original Touhou Puppet Play v1.812 patch files (To apply to a FIRE RED JAPANESE ROM yourself.
- Original Touhou Puppet Play v1.812 bugfix patch (APPLY AFTER YOU ALREADY APPLIED ANY OF THE OTHER PATCHES) (Works with both Maribel and Renko Versions).
- Soft English Translation Patch. (Can be applied with or without the bugfix patch).


Notes
What the patch translates:
- Species names (Within 5 letters)
- Ability names (within 7 letters)
- Attack names (Within 7 letters)
- Item names (Within 8 letters)
- Type menu icons
- Natures

What the patch does not translate:
- Literally everything else. The bits translated above should be all is needed to play with much less guesswork, as the game follows the basic Fire Red plot progression.


ROMS:

- Touhou Puppet Play v1.812 - Maribel & Renko Versions
- Touhou Puppet Play v1.812 - Maribel & Renko Versions with only the Bugfixes applied.
- Touhou Puppet Play v1.812 - Maribel & Renko Versions with the Bugfixes and Soft EN-Translations applied (These are the ones you want to try).


CREDITS AND SPECIAL THANKS

Touhou Ningyougeki version 1.812 by Hemoglobin A1C (へもぐろびんA1C).
https://ux.getuploader.com/ningyougekikousiki/

Soft English Translation by Mille.
http://lkaexe.supersanctuary.net/thmn18jpsoft/

Nameless Rumia from EVERYTHING RUMIA KNOWS for the clean instructions on how to patch the roms, and some history about all 'Touhoumon' versions.
https://namelessrumia.heliohost.org/w/doku.php?id=touhou_ningyougeki


