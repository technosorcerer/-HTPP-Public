These are bonus patches that will change the gender ratios of the characters noted in the filename. They will work with any version of Sburbmon.

Note that in order to use them, you must hard patch your rom with Lunar IPS or another patcher! The automatic patching method will not work!

Instructions:

1. Download and apply the main Sburbmon patch to your ROM.
2. Select the gender patch you wish to apply, and then apply it over your already patched ROM.
3. Repeat with another patch if desired.