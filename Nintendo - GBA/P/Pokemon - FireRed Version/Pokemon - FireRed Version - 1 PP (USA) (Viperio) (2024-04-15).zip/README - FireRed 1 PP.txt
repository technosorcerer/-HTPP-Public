FireRed - 1 PP

- All moves for the player only have 1 PP (this can still be healed).
- The displayed PP is also changed in all relevant places, such as battles and the summary screen.