[b]Pokemon SGS (Shiny Gold Sigma)[/b]

A new revolutionary game. Improvements at Johto Region, adding Kanto, plus a special section with Orange Archipelago, Battle Frontier and now Hoenn finished. Complete and working 100% functional. Among major improvements, includes:

[list]
[li]More than 900 Pokémon, Gen I to IX, legends and Alola Forms, catch'em all without need trading.[/li]
[li]Mega Evolution & Treastallization available. Rightful evolution at every single Pokémon (no need to trade to catch'em all, Cable Link Item at PC Storage is available to that.[/li]
[li]New evolutionary stones includes: Cable Link, Metal Coat, King's Rock, Prism Scale, Oval Stone, Shiny Stone, Dawn Stone, Dusk Stone and a bunch more, including new eeveelutions.[/li]
[li]Battle Pyramid, Battle Tower, Battle Pyke, Battle Palace, Battle Arena, Battle Dome and Battle Factory available.[/li]
[li]New effects added, like entrance into a new place, ash grass, high grass, micro grass.[/li]
[li]Competitive stuff available, coloured stats, IV and EV suggestion.[/li]
[li]Be able to rightfully fly everywhere and using Clear Bell to UltraFly between regions.[/li]
[li]Leaders offers rematch in Johto, Kanto, Orange Islands and Hoenn.[/li]
[li]Badges as Crystal order and coloured.[/li]
[li]Improved graphics, colorful & elegant.[/li]
[li]New music set list.[/li]
[li]New pokémon, eggs and events.[/li]
[li]Pokémon Center Second Floor avaliable to trade, play and battle with your friends using Colisseum Battle Mode. Also a Wonder Trade feature is available.[/li]
[li]New moveset to use out of the battle.[/li]
[li]System clock automatically walk with 5 changes.[/li]
[li]System clock automatically walk with 7 weather times.[/li]
[li]New sprites include: new main character minisprite, new places, tiles, trainers sprites, Pokémon sprites, several graphs, etc.[/li]
[li]Pokemon are more likely to capture that were previously quite rare (Hoenn, Sinnoh, Unova, Kalos, Alola, Galar and Paldea species).[/li]
[li]Sounds remastered & enhanced, more aligned to Pokémon Crystal version.[/li]
[li]New rivals.[/li]
[li]Leaders reinforced, more difficult & new Ex-Elites.[/li]
[li]Several improvements through the years, including now more legendaries like Walking Wake, Gouging Fire and Raging Bolt.[/li]
[li]Full decapitalized.[/li]
[li]Get exclusive Pokémon like Pichu Spike Ear or Crystal Onix.[/li]
[li]Weather times works on battle.[/li]
[li]Be able to use Dive and Vine Whip.[/li]
[li]New items, new main characters, history, places, music, events.[/li]
[li]New Pokémon icons, new trades, Bicycle fixing, new improvements Black & White style, includes: Earn EXP while capture, TM unlimited use, 1 PS survival, repel's system, Kanto Alola Forms, among others.[/li]
[li]Complete Pokémon Location and available Pokédex to index them all. Gotta catch'em all![/li]
[/list]

Country: USA
Rominfo : Pokemon - Fire Red Version (USA).gba - NOINTRO (1656 Squirrels)
MD5: 727AD9FC225094B15928F7863CB99E8C
SHA-1: 695F2AF9EDBA1D7205E4057FD2182E8BD82AFE01
SHA-256: DB95C4EE7B1BF4364AD8DD33BA7EBDD0879CF2FE1E0D55DBE3976BD7E93A4391
File/ROM CRC32: 8F9CA336
Identifying name: Pokemon Shiny Gold Sigma (USA)
Compatibility: Visual Boy Advance (VBA, GBA, Computer), MyBoy, JohnGBA (Android, for Iphone see discord), Miyoo, Anbernic, PS Vita, DS, DS Lite, 2DS, 3DS, and others.

Discord: https://discord.gg/S5kGWmkaSm
Main Page: Facebook webpage, look for: PkmnShinyGoldSigma
Walktrough Guide: Discord/Facebook.


Discord: https://discord.gg/UW72ZkSS9n
Facebook Group: https://www.facebook.com/groups/pkmnshinygoldsigma
Facebook Page: https://www.facebook.com/PkmnShinyGoldSigma
Wix: https://asanchezc2.wixsite.com/pkmnshinygoldsigma
Instagram: https://www.instagram.com/pkmnsgs/
Twitter: https://twitter.com/pkmnsgs
Youtube: https://www.youtube.com/channel/UCEJN5Ol7WESOh-IgcW8SfDw
Reddit: https://www.reddit.com/r/PkmnSGS/
Email: pkmnsgs@gmail.com
Telegram: https://t.me/+0KZtyGr6Jhw4ZDFh
Whatsapp: https://chat.whatsapp.com/FiX5
Ko-Fi: https://www.paypal.me/AioliaLeo