All are to be used on v1.0 roms

Fire Red: Use the patch on a 1636 - Pokemon Fire Red (U)(Squirrels) rom (CRC32:dd88761c)
Leaf Green: (CRC32:d69c96cc)
Emerald: Use the patch on a 1986 - Pokemon Emerald (U)(TrashMan) rom (CRC32:1f1c08fb)
Ruby: (CRC32:f0815ee7)
Sapphire: (CRC32:554dedc4)