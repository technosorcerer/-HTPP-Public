Pokemon Kairos - Version Beta 1.0.2
By RuFF 

History:
Beta 1.0.2
- The Fraxinus City Gym will now force the player to challenge Battle Caf� first.
- Few bug fixes.
Beta 1.0.1 
- Tweaked trainer levels.
- All Bug types can now learn Leech Life.
- Edited Fraxinus City Gym.
- Few bug fixes.
Beta 1.0 
- Initial Release.

Known Bugs:
Description of some Pok�mon moves (Minor Bug)
Some Pok�dex datas are wrong (Minor Bug)
You can see trees on the sea at Almond Town (Minor Bug)

Please report any bugs on these sites:
https://ruffhacks.blogspot.com/p/pokemon-kairos.html
https://www.pokecommunity.com/showthread.php?t=372016

Patch it on to a clean 1636 - Pokemon Fire Red (U)(Squirrels) Rom using NUPS Patcher.

CREDITS
MrDollSteak - MrDollSteak's Decap. and Attack Rombase
pokefreak890 - Pokemon Fire Red Patch 1020 Rombase
Spherical Ice - Colored Stat's Based on Nature (ASM), Checkitem Hack (ASM)
DoesntKnowHowToPlay and lsmash - Catch Exp Gain
FBI - A lot of ASM stuff
Pokemon_XY - Fully Custom Given Pokemon
ChaoticCherryCake - Tiles
daniilS - Pok� Ball hacking guide
DoesntKnowHowToPlay - Displaying IVs on the stat screen
Contributors of DS Style 64x64 Pokemon Sprite Resource - Gen I to V DS Styled Pokemon Sprites
Contributors of Gen VI: DS Style 64x64 Pokemon Sprite Resource - Gen VI DS Styled Pokemon Sprites and Pokemon Icons
Contributors of Gen VII Pok�mon GBA Sprite Repository (64x64) - Gen VII Sprites
Bulbapedia - Pokemon Data
Tool Makers - Awesome tools that I am using