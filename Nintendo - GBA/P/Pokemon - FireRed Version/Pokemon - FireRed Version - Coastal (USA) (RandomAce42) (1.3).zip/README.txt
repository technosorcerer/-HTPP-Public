Thank you for downloading my ROM! It's my first ever ROM so please treat it with a grain of salt!
The following are the directions to play!

Directions:
You want to go on your preferred internet browser and find the same Base Rom that I used. Obviously I can't tell you where I got mine, but here is the info:

Base Rom:
Pokémon - Fire Red Version (USA, Europe)(Rev1).gba 
CRC32: 84ee4776
MD5: 51901a6e40661b3914aa333c802e24e8

Then you will take it to this website:
https://www.marcrobledo.com/RomPatcher.js/

Put the ROM where it says ROM File and the .bps file in this folder where it says Patch file. Once you hit Apply Download you'll want to take the downloaded file and rename it to something like "Pokémon - Coastal Version" and then the version number (V.1, V.1.1, V.2, etc).

After that you should be good to open in whatever emulator you use. The ones I used for testing and development are mGBA and Delta for ios and it worked fine in both of those, but technically untested elsewhere.

About Pokémon Coastal Version:

Pokémon Coastal Version is a Generation 3 ROM Hack that stays faithful to Gen 3. The only thing added is one Pokémon from future generations for one of the Gym Leaders. That Pokémon is possible for the player to get.

Pokémon Coastal will take you on a fairly linear Pokémon Adventure, going from one town to the next defeating the gyms with a slight interruption for story towards the final gyms.

There are three legendary Pokémon available to the players and many other secrets and rewards for exploring the region! Don't be afraid to look around each bend, delve each cave and corner, and to revisit places after gaining surf and waterfall!

Credit:
Developer: RandomAce42 ("George")
Play Testers: Xenolog ("Logan") and Lukism ("Izaiah")
 
Oh also, a Box Art is included in the Package, but if someone makes a better one I'll add it to the package and credit them. This is for software that allows you to add a box art for the ROM like Delta.

I've done a lot of balancing on the ROM to try to make it difficult and fair. In my opinion it's fair all the way through the seventh gym. The curve gets a little awkward after that. If a lot of people say it needs to be rebalanced then I'll go rebalance it and upload a new version.

1.3 Fixes
- Fixed Dialogue Errors, Typos, and Formatting
- Fixed Elite Four Elliot's Team
- Fixed Several Collision errors
- Fixed a potential softlock
- Adjustments to Route 5
- Adjusted Dripstone Cave encounter rate
- Reworked Mary's Marsh House

1.2 Fixes
- Ghost Town fixed on Town Map. Used to say Pattern Brush
- Potential Soft Lock in Route 1 fixed
- Fixed an issue where you couldn't enter Nanowatt City
- Fixed the Warp Points in Rocky Heights
- Fixed a Graphical Error in Ghost Town
- Fixed the Gym Advisor in Steel Dragon City

1.1 Fixes
- Fixed Pokémon from non Kanto regions not evolving before getting the Pokedex.
- Fixed a potential Softlock
- Corrected some Dialogue Errors and Typos
- Fixed Several areas in Dripstone Cave that were inaccessible due to turbulent waters.
- Fixed some Collision Errors
- Water Stone now works on Feebas

