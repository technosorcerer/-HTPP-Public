+-------------------------------------------+
|           Pokémon Cosmic Version          |
+-------------------------------------------+

===================== GAME INFORMATION =====================
Pokémon Cosmic Version is a Binary based hack of FireRed BPRE in English (but is now decomp based and being ported over to pokeemerald).

Developer(s):    Pyxal
Base ROM:        1636 - Pokemon Fire Red (U)(Squirrels)
Released:        26th May, 2024
Release:         Beta 0.0 HOTFIX

PokéCommunity thread: https://www.pokecommunity.com/threads/pok%C3%A9mon-cosmic-version-beta-0-0-25-05-2024.528757/
Discord server: https://discord.gg/5wUeGef6q3 (give suggestions, ask for help and report bugs)

===================== CHANGELOG (from Beta 0.0) ============
• You start the game with running shoes. Additionally, you can toggle auto-run on/off and press 
  the B button when auto-run is on to walk.
• Mom will now heal your party after you have received the parcel.
• The overworld Pokémon do not necessarily have to be caputurable in routes/towns.
• Custom encounter/battle music for some trainer classes.
• Some graphical updates, like shrinking through doors, better palettes, etc.

===================== KNOWN BUGS ===========================
• Looking at the location of Pokémon in the PokéDex shows the Kanto map.
• Looking at the PokéDex entry of any Gen I - III appears broken.
• Some move descriptions are thrown out of screen.
• The Rival naming screen shows a different Rival overworld sprite.
• Some move animations (rock related) have a messy palette.

===================== FAQ ==================================
• When is the next release?
There is no fixed release date as the game is being ported over to Pokémon Emerald Version.

• Why is the game being ported over (binary to decompilation and disassembly)?
It is a much better environment to make a hack in + development and releases will be faster.

• What's the release plan?
Check the Discord server!

• I've encountered a bug. What do I do?
If you are on Cosmic Version Beta 0.0 HOTFIX and the bug is GAME BREAKING, then report it in the Discord server.
Otherwise, as the game is being ported over, there is no need of knowing the bugs of the past engine.

• How do I play the game?
See HOW TO PLAY below.

• What emulators should I use?
For PC, use mGBA. For Android, use Pizzaboy or Lemuroid. For iOS, use Delta.

• Will my save data be transferred from one release to another?
Major Beta updates (Beta 1.0, Beta 2.0 etc.) will most likely not have compatibility. Between sub releases
(Beta 1.0, Beta 1.1 etc.), however, the plan is to have it.

• Why are Starbirth Town and Westray Pass so ugly?
They'll be remapped in Beta 1.0. 

• Can I use this game as a base? Subsequently, can I use assets from this game or from the CFRU copy of this game?
Of course! Although I would not recommend using Cosmic as a base, you can use the assets/cfru-for-cosmic. 
NOTE: A lot of things in Cosmic are out-sourced, so please credit the original owner! A credit back here is 
appreciated, but not necessary.

• What is the dev team/are you looking for help?
For now, it's just me, Pyxal! And yes, I am looking for help in the following areas:  (1) a person skilled 
enough to transform songs/other GBA games music to an Emerald sound font (no custom music) and (2) a talented 
spriter that will be tasked to make a few custom sprites, be it OW, Trainers, other etc. NO COMMISION IS INVOLVED.

• Can I donate?
Nope! Any donation you had wanted to do here, please make to a real charity, like for the people in Gaza!

• Beta 0.0 HOTFIX?
This is the second ever release, so a lot of features have not been added, the progression is quite small and the
quality is subpar. The Beta Phase for Cosmic was launched for this very reason: to streamline development and 
structure only the finest features for the full game. The HOTFIX was released soon after the intial release
to squash a bug that made the game unplayable. Additonally, the game is being ported and Beta 1.0 will not be
on this engine.

===================== HOW TO PLAY ==========================
-Basic steps
1. Download the ROM required to patch [1636 - Pokemon Fire Red (U)(Squirrels)]. The ROM is the other half of what you
   need to play. For legal reasons, game ROM's (and patched versions) can’t be distributed, so you’ll need to search
   the internet for it.
2. Patch the ROM using a patching tool. ROM Patcher JS is recommended (https://www.marcrobledo.com/RomPatcher.js/) — it 
   works entirely in-browser and puts the patched game straight in your downloads folder. But NUPS Patcher 
   (http://www.romhacking.net/utilities/606/) can also be used!
3. Open the patched ROM in the emulator of your choice. If you’re on a computer, mGBA is your best bet.

-Troubleshooting
1. Type mismatch error: Check if the ROM you’re trying to patch is correct and is the English 1.0 version. Any 1.1 version or 
   higher version or any version that has been modified in any way will not match.
2. White screens/“WRONG SAVE TYPE! Please change to Flash 128k.”/“WARNING! The correct system time could not be read. Enable the 
   Real Time Clock (RTC), and make sure the time is correct.” errors: Make sure the "Save type" is "Flash 128K" and also ensure
   that the "Real-Time Clock" is enabled in your emulator's settings.