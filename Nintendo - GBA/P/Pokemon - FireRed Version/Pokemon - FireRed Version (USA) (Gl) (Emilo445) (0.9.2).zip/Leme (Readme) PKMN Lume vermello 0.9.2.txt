COMO APLICAR O PARCHE

1- Executamos LIPS.exe

2- Seleccionamos a opción Apply IPS Patch.

3- Seleccionamos o arquivo parcheLumeVermello09.ips

4- Seleccionamos a ROM de Fire Red versión 1.0(USA).

5- Feito! Xa podes desfrutar de Pokémon en galego!

CRC32 orixinal: DD88761C