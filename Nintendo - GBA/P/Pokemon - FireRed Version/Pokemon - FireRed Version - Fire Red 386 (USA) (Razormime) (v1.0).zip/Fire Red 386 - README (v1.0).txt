=======================================================================================================
	Pokemon Fire Red: 386 Version (v1.0) - Razormime
=======================================================================================================

=======================================================================================================
	Table of Contents
=======================================================================================================
	0) Introduction - PLEASE READ
	1) Soft-Spoiler Guide (General information)
	2) Hard-Spoiler Guide (Detailed information) - Try to avoid reading this
	3) Things you *maybe* WISH I would change, but won't
	4) HOW TO USE THE PATCH
	5) Updates and Save Files - Returning players, please read!
	6) Special Thanks
	7) How to Contact Me

=======================================================================================================
	0)Introduction
=======================================================================================================

		Pokemon Fire Red 386's main goal is to give players the opportunity to encounter and to also
	obtain at least one of every Pokemon available in generation 3, thereby completing the Pokedex
	without the need to connect to or interact with other games or events. This project DOES NOT try to
	increase/decrease difficulty; add modern mechanics; change lore; "fix" balancing "issues" with the
	original Fire Red release; or include post-gen 3 pokemon, evolutions, mechanics, etc. - There are
	really amazing hacks that do all of this (and more), and I encourage you to try those as well!
	Please, before writing a review, consider what this hack intends to do, if it met its goal, and if
	this was outlined well-enough before investing your time into it.
	
		With that being said, understand that I needed to cram OVER 120 Pokemon into the game, AT LEAST
	(this doesn't include evolutions or fossils or special evolution items, etc.), while STILL trying to
	keep the feeling as vanilla as possible, and not stepping on the Generation-One-Remake "vibe" of
	the original release. This terrfied me well before I even started planning this hack, as I knew
	that a majority of the overwhelming amount of "missing" monsters would need to appear after becoming
	champion the first time. This game was not built to handle that type of expansion while allowing
	players post-gen-1 Pokemon teams in the early game. I've done my absolute best to stick to the feel
	of the original release, and to use the world and circumstance available to me, as well as my limited
	skills to spread out the monsters as much as possible, and in as many different ways as possible, to
	offer as much variety as I could manage. I have, however, decided to give players a few early-game
	opportunities to access some gen2/gen3 Pokemon by removing vanilla evolution restrictions, giving
	access to a few gen2/gen3 evolution items "early", and even a couple pokemon gift/trade events.
	I've done so to, hopefully, give players an option for a bit of a shake-up, should they choose.
	
		To keep true to the "Gen One Remake," I have NOT unlocked the National Pokedex from the start,
	as it is a major story point in Fire Red, but it DOES still record data on national monsters that
	might be collected "early", and can be accessed once the National Pokedex is obtained. Another goal
	was to give players infinite ACCESS to all TMs, tutor-moves, and evolution items so that they would
	have the freedom to develop more than one pokemon dream team; but I also wanted to avoid breaking
	the game by doing things like making TMs infinitely USABLE (for example). Instead, I tried to find
	a good balance and encourage you to review the rest of this readme for the various solutions that
	I've implemented.
	
		I have carefully designed all changes and additions to the game to not require this readme file!
	At the very least, the base-form of all Kanto "found in the wild" Pokemon evolution lines will be
	"seen" by your Pokedex by the time you become champion the first time through unavoidable battles, and
	the base-form of all "found in the wild" Pokemon evolutions lines from Johto and Hoenn will be "seen"
	by the time you get to the end of the Sevii-Island areas through unavoidable trainer battles... Any
	base-form Pokemon which do not appear this way (very few) are very special exceptions like fossil or
	legendary Pokemon, for example. Babies are also not part of this.

		All new events in the game, whether they are things like when shops will expand inventory, when
	the roamer starts roaming, who to see for help with something new, etc. are hinted at by brand new or
	existing NPCs, and are usually unavoidable. If you just talk to everyone, YOU WILL BE FINE! I've left
	none of my additions or changes obscure or difficult to figure out! There are a couple (really, like
	just a couple) Easter Eggs I've hidden and will not be revealing in this readme, but they are totally
	not needed for game completion.

		One last thing: I have worked very hard on this hack, and constantly personally checked and
	verified each addition or change while developing, as well as with regular "start to finish" 
	play-throughs by myself and a couple beta-testers. We've played through the game from a fresh save
	file all the way to beating the Elite 4 and the end of the Sevii Islands, interacting with any/all of
	the post-game changes to make sure they work. The beta tests were also performed across different
	hardware and different emulators. I really wanted v1.0 to be as solid as possible. However, I may
	have overlooked some interesting missing content and the project *might* need future updates... 
	I want you to know that I consider this release to be pretty solid, and you should feel confident that
	if you start a save file on v1.0, you will have a good time (and that, if needed, you should be able
	to update and keep your save file, no-problem).


=======================================================================================================
	1) Soft-Spoiler Guide
=======================================================================================================
A) Gameplay Mechanics, and Fixed Vanilla Bugs / Glitches.
    + Pokemon Fire Red 386 patch version number can be checked in-game (Help System: About Game).
    + Title Screen style can be swapped to "Leaf Green" in options menu (after starting a save file).
    + Roaming Pokemon IV Glitch has been fixed.
    + Snow effect fixed and updated.
    + Various minor graphical bugs fixed.
	+ Additional/alternate method added to earn the final star and color for the Trainer ID

B) Text + People Changes
    + Real World references changed to no longer mention the real world.
	+ Main Move Tutor can teach pre-evolution moves.
	+ One-Time Move Tutors will now reset after defeating the Elite 4 (will need to be reset each time).
	+ Some instances of NPC/sign/event dialogue has been rewritten to accomodate insertion of content. 
	+ Some NEW NPCs added to compliment changes or give hints.
	+ Some EXISTING NPCs altered: Positions, Battles, Gifts, Trades, Events, Hints, etc.
	+ Text formatting for when an NPC will send out a Pokemon has been slightly changed.

C) Shops and Items
	+ A few items have moved from their original locations to make room for new rewards.
	+ All TMs which were once finite (limited) will become available to purchase (unlimited) somewhere.
	+ Several shops expand inventory at various times throughout the story.
	+ Poke-Balls absent from Fire Red (Luxury, Net, etc.) unlocked as a store item at some point.
	+ All evolution-critical items can be found repeatedly.
    + One "new" Key Item added.
	+ Dive Ball buffed to improve capture chances on ICE-TYPE Pokemon as well as WATER-TYPE.

D) Areas
	+ A few areas have had small changes.
	+ A few areas have been expanded (extra rooms in a cave, for example).
	+ A few small areas have been added.

E) Pokemon
    + Trade-Based evolution Pokemon have the opportunity to trade-evolve and stay with you.
	+ Mystic Ticket and Aurora Ticket restored.
    + New static encounters and events added.
	+ De-Spawn Safety for all static encounters: Legendary and others (excludes Power Plant Electrodes).
	+ ALL Fossil-Pokemon are found as Fossils someplace. Fossil Regenerator updated accordingly.
	+ Leaf Green exclusive Pokemon added to their appropriate routes.
	+ Base forms (at least) of all Pokemon from Johto and Hoenn available in logical places.
	+ Deoxys learned move-set updated to include all version exclusive moves from R/S and FR/LG.
	+ Evolution methods to acquire Milotic, Umbreon and Espeon updated and strongly hinted at.

=======================================================================================================
	2) HARD-SPOILER GUIDE !!!
=======================================================================================================

I REALLY think that reading this might ruin much of the fun, but if you must...

.
.
.

A) Gameplay Mechanics, and Fixed Vanilla Bugs / Glitches.
    + Pokemon Fire Red 386 patch version number can be checked in-game.
      - With the "Help System" enabled (default setting), press "L" at the title screen or in any
	    Pokemon Center, and select "About Game" - The patch number is in the bottom right.
	  - Growlithe will appear in Prof.Oak's "This is the world of Pokemon" intro speech.	
	  
    + Title Screen can be swapped to "Leaf Green" in options menu.
	  - After starting a new game, access the options menu and change the option. Save game.
	  - This ONLY changes the title screen style. It will not change Pokedex information, etc.
	  
    + Roaming Pokemon IV Glitch has been fixed.
	  - The roaming Pokemon will no longer have busted IVs.
	  
    + Snow effect fixed and updated.
    + Various minor graphical bugs fixed.
    + Additional/alternate method added to earn the final star and color for the Trainer ID.
	  - Instead of playing the multiplayer mini-games, the player will also be able to gain this
	    star by unlocking all of Lorelei's Dolls (becoming champion the 200th time).
	  - Players WILL NOT gain an additional star for doing both methods.

B) Text + People Changes
    + Real World references changed to no longer mention the real world.
	  - I've opted to not include any references to gen 4 or later games while doing this.
	  - Any Pokedex entry that had an issue was simply swapped out for the Leaf Green entry.
	  - Most changes take cues from HG/SS or the Let's Go games.	 
	+ Main Move Tutor can teach pre-evolution moves.
	  - Evolved Pokemon will need to be 5 levels higher than when the pre-evolution learns the move.
	+ One-Time Move Tutors will now reset after defeating the Elite 4 (will need to be reset each time).
	+ Some instances of NPC/sign/event dialogue has been rewritten to accomodate insertion of content. 
	+ Some NEW NPCs added to compliment changes or give hints.
	+ Some EXISTING NPCs altered: Positions, Battles, Gifts, Trades, Events, Hints, etc.
	+ Text formatting for when an NPC will send out a Pokemon has been slightly changed.
	  - The line which says which Pokemon is about to come out can still be read while asking if the
	    player would like to switch Pokemon.

C) Shops and Items
    + Several shops expand inventory at various times throughout the story.
	  - Saffron Poke-Mart: After defeating Giovanni at Silph.Co.
	    - Upgrade added.
	  - Cinnabar Poke-Mart: After becoming champion the first time.
	    - Lava-Cookie added.
	  - Celadon Dept.Store: After becoming champion the first time.
	    - Evolution Stones, Gym-Leaders' TMs, Special Pokeballs added.
	  - Rocket Game Corner Prize Room: After becoming champion the first time.
	    - Evolution Items added: Metal Coat, Dragon Scale, Kings Rock, Deep Sea Tooth and Scales.
	  - Two-Island Shop has been repurposed to be a TM Shop, exclusively.
	    - Carries ALL remaining TMs which were once limited in vanilla Fire Red, and were not
		  part of the Celadon Dept.Store expansion. TALK TO BOTH NPCs.
		- Expands several times (vanilla triggers) after the player:
		  - Saves Lostelle.
		  - Saves Lostelle AND becomes champion.
		  - Finishes the Ruby and Sapphire side-quest.
		  
	+ A few items have moved from their original locations to make room for new rewards.
      - All the special items from the Two-Island shop-keeper have been moved to other shops.
	  
    + One "new" Key Item added.
	  - The Squirtle Pail is available in the Safari Zone after becoming champion.
	    - Sprite is of the "Squirt Bottle" found in HGSS.
		
	+ Dive Ball buffed to improve capture chances on ICE-TYPE Pokemon as well as WATER-TYPE.
	  - There would be no purpose for this ball, otherwise, as there are no dive spots in Fire Red.

D) Areas
	+ A few areas have had small changes to:
	  - Accomodate a new static encounter.
	  - Make "hiding" from a few battles impossible.
	  - Extra grass tiles for encounters.
	  - Prevent early access.
	  
	+ A few areas have been expanded (extra rooms in a cave, for example).
	  - Safari Zone expands with two new areas.
	  - Altering Cave expands with extra sub-caves.
	  - Trainer Tower area (Seven Island) expanded for two new island locations.
	  
	+ A few small areas have been added.
	  - Existing house structure in Cerulean City gets a door and interior.
	  - the two new Trainer Tower islands have "interiors".


E) Pokemon
----------------||| SEE THE INCLUDED POKEMON LOCATION GUIDE FOR FULLY DETAILED INFO |||----------------

    + Trade-Based evolution Pokemon have the opportunity to trade-evolve and stay with you.
	 - Celadon City: Meowth and Gambler Duo.
	    - Requires the player to have a COIN CASE and 200 COINS per trade.
	    - If the player has MORE than 200 Poke-dollars, Meowth will secretly steal 100 Poke-dollars.
	      (Meowth will NOT steal any Poke-Dollars if the player has 200 Poke-dollars or less)
		  (The "Payday" sound can be heard as a hint to this, as well as NPC dialogue in the hotel)
		- Evolutions through this method CANNOT be cancelled with "B".
		  (However, they CAN be prevented with an Everstone)
		- Players' "trade" count on their ID will increase for every trade done here.
		  (Twice, as the player trades a pokemon away, and then trades to get it back)
		  
	+ Mystic Ticket and Aurora Ticket restored.
	  - Mystic Ticket found in the Five-Island Rocket Hideout.
	    - Show to the Seagallop Captain in Vermillion to get to Naval Rock.
	  - Aurora Ticket is rewarded for completing the Sapphire side-quest from Celio on One-Island.
	    - Show to the Seagallop Captain in Vermillion to get to Birth Island.
		
    + New static encounters and events added.
	  - Sudowoodo, Kecleon, Mew, Celebi, Groudon, Kyogre, Rayquaza, Latias, Latios, Raikou, Entei, 
	    Suicune, Regice, Regirock, and Registeel all given new static encounters.
		
	+ De-Spawn Safety for all STATIC encounters.
	  - If the player CATCHES the Pokemon: It will not respawn.
	  - If the player RUNS from the Pokemon: It will respawn after the player leaves the area.
	  - If the player DEFEATS the Pokemon: It will respawn after becoming champion again.
	  (i) The respawn works as many times as needed until it is caught.
	  (i) If a player teleports or is roared away, it will count as "running away".
	  (i) Includes all Legendary, Snorlax, Sudowoodo, and Kecleon encounters.
	  (i) Does not include the Electrodes in the Power Plant.
	  (i) Re-spawning a Pokemon will reset all its stats each time (including IVs and shiny status).
	  
	+ De-Spawn Safety for the ROAMING Pokemon (JIRACHI).
	  - If the player RUNS, or Jirachi FLEES: It's still roaming with the same Stats, HP and Condition.
	  - If Jirachi DEFEATS the player: It's still roaming with the same Stats, HP and Condition.
	  - If the player DEFEATS Jirachi: It will RESET by becoming the champion again.
	  (!) Jirachi "resets" everytime you enter the Hall of Fame, even if it is CURRENTLY ROAMING!
	      - This will change its HP, Condition, and its Stats - including the SHINY STATUS!
		  - If you encounter a shiny Jirachi, and it escapes, avoid entering the Hall of Fame again
		    until you have either captured or defeated it.
	  (i) If you trade another Jirachi into Fire Red 386, or move one in with something like PKHex,
	      the event which sets Jirachi roaming will still happen... However, the "reset" WILL NOT.
		  - A roaming Jirachi will keep its stats, even if you enter the Hall of Fame.
		  - A defeated Jirachi will not come back.
		  
	+ ALL Fossil-Pokemon are found as Fossils someplace. Fossil Regenerator updated accordingly.
	  - Second Kanto Fossil can be found near Mewtwo in Cerulean Cave.
	  - Claw Fossil can be found in Mt.Ember (Ruby Path).
	  - Root Fossil can be found in the Dotted Hole.
	  (i) Cinnabar Island fossil menu updates after finding either/both Hoenn fossils.
	  
	+ Leaf Green exclusive Pokemon added to their appropriate routes.
	  - Usually splitting rarity with the Fire Red "counterpart".
	  
	+ Base forms (at least) of all Pokemon from Johto and Hoenn available in logical places.
	  - Except for the Safari Zone expansions, ALL new "wild" encounters will be in the Sevii Islands.
	  - A few opportunites for "early" gen2 or gen3 Pokemon available via evolution or gift/trade. 
	  
	+ Deoxys learned move-set updated to include all version exclusive moves from R/S and Emerald.
	  - Use the move reminder to gain access to some of these.
	  
	+ Evolution methods to acquire Milotic, Umbreon and Espeon updated and strongly hinted at.
	  - FEEBAS must be taken to the Fan Club Chairman in Vermillion City.
	  - EEVEE now reacts to MOON and SUN STONES.

=======================================================================================================
	3) Things you *might* WISH that I would change, but won't:
=======================================================================================================
	
	+ HM Items: a popular change to rom-hacks is making field-use items to replace HMs (like a SURFBOARD
		instead of SURF, for example). This hack is a pure nostalgia trip (which you can complete), 
		and does not aim to modernize stuff like this. I think they are great additions to "bigger" more
		robust rom-hacks, but not to my humble diet-vanilla hacks.
		
	+ Running in-doors, ultra-fast text, speed enhancments, etc: As before, just trying to make a super
		humble vanilla nostalgia trip. I wanna run in SilphCo. too, but thems the breaks.

	+ DECAPITALIZING: Somehow, innevitably something would get overlooked and I would need to go back
		in and decap something, update, repeat. But it's a VANILLA NOSTALGIA DREAM and not worth it.
		
	+ Anything Else and Everything Else: Consider that everyone gets something different out of playing
		through a Pokemon game, and no single hack can please everyone. This hack is for "semi-purist"
		players who wanna complete dexes but don't want to invest in old hardware and methods or feel
		like they cheated by using cheat-codes. This is for people who don't want a MODERN version
		of Fire Red, it's for those who want the OLD version of Fire Red... only completable.
		
	+ MEW not using the OLD SEA MAP: This item was never implemented in FR/LG, and while possible to
	    still add this item and the functionality, I had a completely different idea with what I wanted
		for MEW, thusly, the item was not added to Fire Red 386.
	
	+ EEVEE and the SUN/MOON STONES: There was an honest effort to implement a non-real-time clock
	   into the game JUST for EEVEE's evolutions, and It worked... mostly. It worked for EEVEE, but
       was causing issues, elsewhere, that when fixed, broke something else down the chain. Eventually,
	   I had gotten to a place where I thought I was good, but I questioned if there was just another
	   land mine I hadn't discovered, yet. I decided to scrap the plan in favor of something more
	   dependable and less risky.
	
	+ Pokemon "Legality": Initially, I had spent a considerable amount of time trying to make it so
        the new Pokemon would have appropriate data overwright things like location and OT IDs and
        such, to "look" like they were caught in Emerald or whatever... But, there was a sense of
        immersion that was breaking (Catching Sudowoodo in Viridain Forest and having it reflect that
		it was caught at the Battle Frontier) and a lot of code being written that started to feel
		like more of a risk than a reward, unfortunately. This is also one of those things that's in
		the spectrum of what is truly considered "legal" or not. To some, simply playing a rom hack
		(or even just using an emulator with a vanilla rom) is already not "legal" - Certainly the
		Pokemon Company would say so. I did want this, but I couldn't find a "clean" way to make it
		work, sadly. Dropping the idea allowed me to not only speed up my work, but it also allowed
		me more freedom in how I handled some of the events, as well as allowed me to give the roamer
		(and the three beasts) non-bugged IV imlpementation!

=======================================================================================================
	4) HOW TO USE THE PATCH... (aka "Why won't this game run?")
=======================================================================================================
	+ The rom hack you just downloaded cannot be played by itself! It must be applied to an original, 
	legit copy of this exact .gba rom: "Pokemon - FireRed Version (USA)" <- I cannot tell you
	where or how to find that exact titled rom, but if you have a rom like this, check it using this
	link https://www.romhacking.net/hash/ , and compare the information it gives you to this info, here:

			Database match: Pokemon - FireRed Version (USA)
			Database: No-Intro: Game Boy Advance (v. 20210227-023848)
			File/ROM SHA-1: 41CB23D8DCCC8EBD7C649CD8FBB58EEACE6E2FDC
			File/ROM CRC32: DD88761C

	If the information matches, then you can make the Fire Red 386 rom:

		1) Unzip the .zip file to get to the .ips file,
		2) Put the Pokemon Fire Red 386.ips file and your copy of the Pokemon Fire Red .gba in a folder,
		3) Apply the patch (.ips file) to the game (.gba file) using only ONE of these two options:
			+ Online Patcher: https://www.romhacking.net/patch/
			+ Offline Patcher: https://www.romhacking.net/utilities/240/
		4) The file created by the patcher is the full Pokemon Fire Red 386 patched game, and can now
		be played on your favorite GBA emulator or flashed to a cart! To be sure that the patch is
		applied correctly, press "L" on the title screen for the Help Menu, and select "About Game."
		The patch version number will be in the bottom right of the game description (v_._)

=======================================================================================================
	5) Patch Updates & Old Save Files
=======================================================================================================
    1.0   Fire Red 386 released.

	USING OLD SAVE FILES:
		+ YOU SHOULD NOT USE ANY ORIGINAL VANILLA SAVES WITH THIS PATCH!
		+ However, you CAN update from older Fire Red 386 versions and continue using that save file...

	To update Fire Red 386 from previous versions to new versions safely, follow these instructions:
		0: Check newest update: https://www.romhacking.net/community/6608/
		1: Save your current game UPSTAIRS in a Pokemon Center and exit the emulator,
		2: Make a backup of your current Pokemon Fire Red 386 ROM ".gba" and save file ".sav/.srm"
		   and put them in a second backup folder somewhere safe,
		3: Patch a CLEAN copy of "Pokemon - FireRed Version (USA)" with current patch version
		   (DO NOT PATCH A NEW FR386 VERSION TO AN OLD FR386 VERSION ROM!!! USE A CLEAN VANILLA ROM!!!),
		4: Replace the PREVIOUS Fire Red 386 ".gba" file with the NEW one in the folder your emulator
		   reads from (never replace the backups),
		5: Make sure your .gba and .sav/.srm names all match,
		6: Verify the update by checking the Help System at the title screen with the "R" button.

=======================================================================================================
	6) Extras
=======================================================================================================
	+ Included in the download is box art in either Fire Red or Leaf Green styles, to use with any
	emulation front-end software you use. Together, with the option to change the title, you can more
	closely capture nostalgia if you are a Leaf Green fan.


=======================================================================================================
	7) Special Thank You
=======================================================================================================
	+ First, I need to thank everyone involved in the Pokefirered Disassembly project. Obviously, none
	of what I've planned to do here would be possible. It is a lot of hard work to create and maintain
	the project, and I am very very grateful to them. By extension, I want to thank everyone involved
	with pret and its extensions like the discord group. They, alongside branched discord groups, like
	RH Hideout, have been invaluable resources to turn to when I had encountered road-blocks. Everyone
	who has contributed to the wiki via forum posts in the form of walkthroughs or tutorials for nifty
	features also deserve massive thanks. Team Aqua's Hideout video tutorials for features was also an
	amazing resource I couldn't have lived without, so "Thank You" to them, too! Specific users from
	these resources for specific changes are as follows:
	
		+ Mgriffin: Project setup and Porymap troubleshooting.
		+ GriffinR: Porymap troubleshooting.
		+ Jaizu: Porymap troubleshooting, tutorial on sound changing.
		+ Zatsu: Some NPC movement scripting.
		+ Lunos: Creating tutorials for, and helping with Script Specials, and Overworld expansions.
		+ Sbird: Project setup.
		+ TheXaman: Their tutorial on in-game self trading for Emerald.
		+ Alex D, daniilS and Samu for tutorials on changing + updating snow effects.
		+ devolov: pre-evolution move tutor tutorial.
		+ ShinyDragonHunter: Various scripting help.
		+ Kurausukun: Fixing script issues with the title-screen swap.
		+ Deokishisu: Sharing their work on how their title-screen swap, and premier-ball shop logic.
	
	+ HUGE THANKS to my direct help:
	    + Gas: Beta testing, consultation, and devloping tools to allow the creation of the detailed
				Pokemon Guide.
		+ Rennie: Intense beta testing, consultation, and helping with planning the spread of Pokemon
				across the Sevii Islands as naturally as possible.
	
	+ I want to thank everyone who has taken the time to write informative, but spoiler-free reviews
	for my previous rom-hacks on romhacking.net far:
		
		+ Emerald 386: 
			Miss Alexis

		+ Crystal 251: 
			Arindur
			SteRossetto
			Incantator (also for Yellow 151)
			ThegreatBen
			Aizumi
			KevCfcNo1
			
		+ Yellow 151
			Vomer (also for Blue 151)
			Greenknight9000
			Pudupuda
			NordicNugz
		
		+ Blue 151
			teddybear6655
			KennieJim
			ClaudeDixon
			headfallsoff
			Pokemonfan98
	
	+ The Pokemon documentation sites Bulbagarden/Bulbapedia and Serebii.net
		+ https://bulbapedia.bulbagarden.net/wiki/Main_Page
		+ https://www.serebii.net
	
	+ MANO for your save file, which I used for beta testing.
	
	+ GameFAQs at https://gamefaqs.gamespot.com/gba
	
	+ I also want to thank you, whoever you are, for downloading and taking a chance with my hack (and
	especially if you took the time to read this novel of a readme file). I worked really hard to teach
	myself new skills so that the project would feel as natural and original as possible. I wanted to
	avoid cringy dialogue and I also wanted to avoid adulterating the 'soul' of the original game.
	+ IF YOU STREAM IT, LET ME KNOW!

	+ "Thank you all" - Razormime

=======================================================================================================
	7) How to Contact Me
=======================================================================================================
	+ If, for whatever reason, this document does not answer your questions, has left something out, or
	you simply want to discuss the hack, feel free to message me on my PokeCommunity page or join my
	Discord server. Be aware that my Discord group has multiple channels which target my Twitch stream
	community as well, and as such, you will be expected to accept and follow the same rules (but can
	opt-out of the roles and even mute those channels), please treat the Discord kindly:
	
		+ Pokecommunity: https://www.pokecommunity.com/members/razormime.972604/
		+ Discord (be sure to select your roles and interests): https://discord.gg/Cb2H8FPmDG