========================== Celia's Stupid Romhack - Demo 2.9! ==========================
Base ROM: 	1635 - Pokemon Fire Red (U)(Squirrels)
Language: 	English
Released:	27th June, 2025
Discord:        https://discord.gg/Hm2p7BuHDB

To play, find a FireRed ROM and apply the .UPS patch to the .GBA file using
the included NUPS program.
Alternatively, you can go to https://www.marcrobledo.com/RomPatcher.js/ 

If you have a previous version of Celia's Stupid Romhack Demo 2.5, you can instead apply the [UPGRADE] Patch to your previously patched rom.

This demo ends ends after Celadon City - expected playtime is 6-9 hours. Additionally, there's a preview for the upcoming Demo 3!

This is a Puzzle Adventure game! Talk to everyone and read carefully; there's several in-game hint systems to keep you from getting stuck.

Be sure to savestate frequently!

Join our Discord! https://discord.gg/Hm2p7BuHDB

CREDITS:
PROGRAMMING: Wiz1986, RavePossum, Celia Dawn, Iriv24, 
ART: Lichen, Chairry, MasterFoF, Celia Dawn
MUSIC: CeliaDawn, Swiwious, IronInvoker47
WRITING: Celia Dawn
DESIGN: Celia Dawn, Plasto, MasterFoF

Special thanks to:
Reverend's Discord Server, for giving me the confidence to continue working!
Lucca, for initial concept brainstorming and working out the first draft of the hack with me!
The Phishing Guru, who will give you a shiny if you tell him "LEEKD"
HexManiacAdvance Discord Server for helping my through my first phases of development - Especially thanks to Haven, Shiny Till Dawn, yogia16, and phoenixbound!


TOOLS USED:
pokefirered decompilation
porymap
porytiles
poryscript
Aseprite
HexManiacAdvance
Musescore 4
Reaper