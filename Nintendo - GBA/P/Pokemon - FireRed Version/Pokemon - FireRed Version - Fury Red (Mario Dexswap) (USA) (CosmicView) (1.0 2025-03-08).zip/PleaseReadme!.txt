Hello thanks for checking out Pokémon Fury Red, this has been a small passion project of mine for about a month 
and a half so I'm excited to get this out there for people to enjoy a bit before Mar10 Day.

To patch the rom you'll need to have 1.0 (Squirrels) version of Fire Red.

If there are any bugs please report them to the Pokecommunity page


Side note, as it is 2025 and Dexswap hacks are on the rise I wanna quickly shout out some
upcoming or already released dex swap projects that I've seen that should be known about.


Pokémon Puffy Pink by TheUltraNerd: https://www.pokecommunity.com/threads/pok%C3%A9mon-puffy-pink.525104/
If you've seen a Dexswap hack before it is likely this one, replaces all 151 Pokemon with Kirby
enimies and characters, that's very fateful to being a gen 3 Rom hack and was one of the biggest
insperations behind this game.


Pokémon Mario Red & Luigi Green by DogPond4: https://x.com/DogPond4/status/1896606496642994423
At the time of writing this hack isn't released yet, and likely won't till next year they say
but what been shown of so far is extremely promising, you can find some of the sprites that 
has been done on DogPond4 twitter if you want to learn more.


Pokémon Flower White by JGPanther: https://www.youtube.com/watch?v=zA6hQwn8Xaw
A Dexswap using Pikmin shown off late 2024 that set to be releasing this year, being made by
a small team of people, so far it plans to have a new story,151 Pikmin enimies and an orginal
soundtrack. 

Pokémon Smash by RolfySoft: https://www.youtube.com/watch?v=XnJchbfs_WE
While only a demo so far it is extremely promising and the full version of the hack the hack
I'm most excited for here, featuring characters from smash, to digimon, to touhou. If you like
a wide variety of games this might be the hack for you.

Super Mario Monsters RPG by Marginal: https://www.pokecommunity.com/threads/super-mario-monsters-rpg.525440/
The other big insperation to me making my own hack, Being entirly made within Pokémon Essentials instead of
a rom hack, featuring 190 planned Mario characters, a new story, and clean sprite work. I have very high
hopes and wish Marginal a lot of luck pushing through and getting the game finished at some point in the future.


For the other Mario dex swap games just to note, even if you had played mine I'd say it is still 100% worth
checking any others I mentioned here or pop up in the future, everyone has different ideas so even something as
simple as a Goomba can be completely different with stats, typing abilities and especially movesets.

That's all for this read me now, thanks for reading and I hope you enjoy Pokémon Fury Red!