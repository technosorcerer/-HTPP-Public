========================== Celia's Stupid Romhack - Demo 2! (v2) ==========================
Base ROM: 	1635 - Pokemon Fire Red (U)(Squirrels)
Language: 	English
Released:	6th January, 2023
Discord:        https://discord.gg/Hm2p7BuHDB

To play, find a FireRed ROM and apply the .UPS patch to the .GBA file using
the included NUPS program. 

This demo ends ends after Celadon City. It's about 6-9 hours of content (nice).

After this demo, the project will be switching to Decomp and will be build from scratch. Unfortunately, it is very likely that saves will not carry over after this demo. However, a completed Demo 2 save will be provided in the next update.

This is a comedy/puzzle hack! If you see something that looks like a bug but it makes you laugh, it was probably intentional! 

Be sure to savestate frequently!

Join our Discord! https://discord.gg/Hm2p7BuHDB

CREDITS:

IronInvoker47 for helping with the Title Screen Music!

MisterFoF for helping with the Title Screen Art and for being a real cool guy!

Lucca, for initial concept brainstorming and working out the first draft of the hack with me!

HexManiacAdvance Discord Server for helping with answering all the questions I had - Especially thanks to Haven, Shiny Till Dawn, yogia16, and phoenixbound!

The DS-style 64x64 Pokémon Sprite Resource , for many of the new gen sprites!

skatefilter5, for the Erika overworld walking sprites

Lichen, for the Jessie and James sprites

Chairy, for the Growlithe Pokemon Sign

Special thanks to Reverend's Discord Server, for giving me the confidence to continue working!




TOOLS USED:
HexManiacAdvance
AdvanceMap
CryEditor
Sappy
YAPE
Trader Advanced
Shinyizer

Microsoft Paint
Musescore
Anvil Studio
Reaper