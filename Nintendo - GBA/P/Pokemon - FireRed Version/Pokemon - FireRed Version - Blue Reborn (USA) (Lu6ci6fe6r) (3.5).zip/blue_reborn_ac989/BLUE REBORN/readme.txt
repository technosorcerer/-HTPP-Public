use Luna IPS or any other IPS Patcher to apply this Hack
ROM BASE is FIRE RED (U)(Squirrels)





changelog

-Gen 1 Pokemon Yellow Frontsprites
-2 Frontsprites from RED/BLUE
-1 Frontsprite from Crystal(LUGIA)

-added XD001(Dark Lugia)

-added around 60 Sinnoh Pokemon

-all Pokemon From Gen1 - Gen3 can be captured/evolved without Trade.
 EEVEE'S evolutions use now all stones Umbreon moonstone and Espeon Sunstone.

-added some Hidden Pokemon(in a special Place)

-added a New Rocket System that starts from your decision at the nugget Bridge
 when you are Rocket:


-you cannot fight Gyms anymore as Rocket until you get a Special Item
 that enables Battles with Gyms again

-You need to gain Rocket Coins wchich allow the use Of Team Rocket Services
 like buy Pokemon and sell Pokemon, buying R.Balls, buying a specific Item.

- Rocket coins are also like Ranking Points when you got 60 you can go to Giovanni
  in the "SILPH CO BUILDING" to get High Rank means you can access two more areas
  1 is the Celadon Hotel.

-The Gyms and League have now Higher Levels.

-The Island from 1-7 are now expanded especially Island 2 which has access to the new called Sinhoe Isle.
  
-Mt.Ember: Groudon is now where Moltres were and Moltres is back at Victory Road

Faraway Island, Southern Islands, Birth Island, Navel Rock and Fullmoon Island can now be accessed by traveling through 
The Islands 1-7.

-added moves: ROAR OF TIME, SPACIAL RENT, SHADOW FORCE(is now a not vanishing 2 turns move),Shadow Blast(Crypto Lugia only)
              and some other for the Hidden Pokemon.



FORM CHANGES: -DEOXYS can change Forms in Pewter City Museum
              -Giratina and Shaymin can change their Forms at the Place where you captured them.  


Known Bugs:

In battle if the Pokemon has not 4 moves instead of the empty moves usual display by a "-" will now be displayed as "Pure Light"
since I added some new Moves. 


changelog V.3.1 update
----------------------------
-little change to a certain Hidden Pokemon added Evolution for Lv.100
-changed The Events of Team Rocket on the Islands so they do not Battle you if you are Rocket
-added Squirtle and Bellsprout to Route 24
-Vulpix and jigglypuff are added to the Route under Cerulean City.
-Charmander can be caught on Route 8 now
So every Pokemon fom 1-386, around 60 Sinnoh Pokemon and around 20 of the Secret Pokemon is obtainable without trade 

-Moon and Sun Stone has been added to the Celadon market.

-Fixed a Elite 4 Freezing problem when battle the champion

-corrected Blain to battle you as Rocket when you have the "Fake ID" in Items




Version 3.2 Final
--------------------------------
Major fixes for the Islands

-Fixed a Problem where the sailor at vermillion doesn't check for the Islands Ticket when Player = Rocket
-Fixed Groudon at Mt.Ember that was seemingly for no reason not appearing on the Map as Overworld.
-Fixed reappearing of Mesprit when it was already caught.

-other Fix 
 The Bycicle shall now be recognized by the Celadon Road "Guard" when you stole the bycicle.

  
-Gender and ability Fix for Giratina Origin Form

3.2 little fix  Giovanni should reappear in virirdian Gym if a certain condition is met.
    Legendary reset  now includes Lugia, Ho-oh and The Birds Trio to be recatchable if a special condition is met. 

Version 3.3 Final
-fixed Rocket coin system for gyms to obtain Rocket coins only once per gym Leader
-fixed XD001 from male to genderless  





Credits For the Pokemon Blue Reborn Hack goto Lu6c6fe6r:https://gamebanana.com or MewBlack: https://www.pokecommunity.com/member.php?u=682124






