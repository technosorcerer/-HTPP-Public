Pokemon - Ultra Violet Version: By LocksmithArmy

I never was a big fan of games you could not get everything by yourself. I am a 100%er so I always want to get EVERYTHING. Pokemon games by design make you either trade or buy and play more than one game to get everything. I did not like this...

So I mixed Pokemon Fire Red and Leaf Green, that gave me ALL the pokemon from the first 2 generations (I only neede to add a few gen 2 pokemon that were not in fire red or leaf green) ;)

well that was not good enough becauseyou still could not complete the pokedex...

so I made a new Island... To get to the island you must talk to the girl in the southern most house in Virmillion city. This new island, 4-Points Isle, houses ALL gen 3 pokemon... there are several new events and areas to explore.


there are other changes other than pokemon changes... you may find them ;) they are to help you through the game, getting all the pokemon can be hard, even impossible if you dont have the right items... for example, how can you evolve your Sunkurn if you dont have any sunstones.

Included in the .rar file you downloaded is an Official Players Guide, it contains all the secrets of the game... including all the locations for all 386 Pokemon and every TM and Item location aswell.

UPDATE 1.22:
players that cannot utilize in game saving can skip the game reset that is after the E4

INSTRUCTIONS:

For to patch this IPS file you only need the contents of this .rar file and your origional copy of Pokemon - Fire Red Version (USA).

Unzip this .rar archive (I use WinRAR) to any location on your computer.
Add your Pokemon Fire Red Version rom to that folder.
Double click the "Lunar IPS.exe" application
Once it is opened click "Apply IPS Patch"
Then select the "Pokemon - Ultra Violet Version(1.21) LSA.ips" file
Next you will be prompted to select your clean copy of Pokemon Fire Red Version... 
After you select your rom the patch will be applied... you may want to rename your patched rom.

If your emulator uses a "game_config.txt" file just add the text from the included "game_config.txt" to your existing file.

Enjoy it!

Special thanks to:
TheZunar123 for ideas and support	
karatekid552 for help with unsolvable problems ;)
FBI agent for jogging my noggin when I wasnt seeing the big picture
Lizzzz for being the best beta tester ever
And one great big THANK YOU!!! to all the players who enjoy catching all the pokemon in this hack <3.

