This patch adds an EV/IV viewing screen to the game, in the same style as the BW Summary Screen patch. To view the screen, go to your Pokemon's summary, to the stats screen and then press the A button.

The screen displays your Pokemon's Base Stats, EVs and IVs, as well as Friendliness and Hidden Power info.

Offsets used: C2CF10 - C2F49F

If used, please credit LibertyTwins, CtrlFootPrint & mZake