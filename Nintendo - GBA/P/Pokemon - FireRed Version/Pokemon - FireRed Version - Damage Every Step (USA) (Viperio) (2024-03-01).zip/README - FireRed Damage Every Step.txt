FireRed - Damage Every Step

Damage:
- All party Pokemon take 1 HP damage for each step taken.
- Poison damage stacks with this damage (2 HP damage every 4 steps if poisoned).
- This damage can make Pokemon faint in the overworld, but no message is showed.
- This damage can cause a white out.

Healing items:
- All HP healing items have been removed from shops.
- Vending machines have been disabled.
- All respawnable healing items have been removed (e.g., potions in underground paths and berries in the sevii islands).
- All HP healing items have been removed from wild Pokemon held item pools.
- I've probably forgotten some other form of renewable healing items that I have removed, but yes I did remove all of them.