BW Menu Patches

This resource contains 3 patches to be used with Fire Red:

BW Main Menu
	Offsets used: C05D78 - C07695

BW Options Menu
	Offsets used: C07698 - CO8DB8

BW Naming Screen
	Offsets used: C08DBC - COC7DB

If used, please credit LibertyTwins, Shiny Miner, Compumaxx and ansh860.
If the BW Naming Screen is used, please credit TerraNovaFR and Acimut as well.

---

If you'd prefer to use the C: injections, to locate the data at whatever offset you wish, please see the links below: (Note: this is very compilcated unless you're familiar with Environment Variables, Path and Command Prompt)

"Tha Code Mining Hub" Discord: https://discord.gg/2vRGgnqw7T

Main Menu repo: https://github.com/Shiny-Miner/C-injections-FR/tree/Main-Menu-BW

Options Menu repo: https://github.com/Shiny-Miner/FR-OptionMenu

Naming Screen repo: https://github.com/Shiny-Miner/Naming-screen-BW

Pre-requirements: https://www.mediafire.com/file/bdq6eept3e00bb8/pret-tools.rar/file

ARMIPS: https://github.com/Kingcom/armips/releases

devkitPro: https://github.com/devkitPro/installer/releases

Python: https://www.python.org/downloads/