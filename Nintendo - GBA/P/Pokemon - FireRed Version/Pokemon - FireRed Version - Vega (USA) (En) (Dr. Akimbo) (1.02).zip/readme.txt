Pokemon Vega English Translation - Version 1.02

HISTORY
05/27/2017 - Version 1.02 - Fixed compatibility with non-VBA emulators
04/09/2016 - Version 1.01 - Fixed Cosmic Power tutor
02/20/2016 - Version 1.0 - Various minor mapping, scripting, spelling fixes
12/19/2015 - Beta 1.03 - Fixed Vs. Seeker
12/17/2015 - Beta 1.02 - Fixed grunt in D.H. Building
12/16/2015 - Beta 1.01 - Fixed water route music
12/15/2015 - Beta 1.0

Patch to an English Fire Red v1.0 ROM.

This is a sequel to Pokemon Altair and Pokemon Sirius. A plot summary is included with this patch, in altairsirius.txt, in order to remove the requirement of playing one of them first.

CREDITS
Translation: Dr. Akimbo
Pokemon Names: Dr. Akimbo, Asfia, Bevan7, Doesnt, Ganon's Error, Hawkfire, K1seki, LightningLord2, Lucis, Mighty Revenant, quiggles, Silphver, SilverStrangequark, Toyotasomi no Miko, Z-nogyroP
Move Names: Dr. Akimbo, Wizards of the Coast, Doesnt, Ketsuban, Mighty Revenant
Title Screen Logo: K1seki
Text Hacking: Dr. Akimbo
Graphics Porting: Dr. Akimbo, Doesnt, Chrunch, El Diabeetus, Tailes
Music Porting: Dr. Akimbo
Map Porting: Dr. Akimbo, Doesnt
Mechanics Porting: Doesnt, Tailes
Non-VBA Compatibility: Diegoisawesome