NOTE: YOU CAN NOW USE THE AUTOMATIC ONLINE PATCHER AT https://as1th.github.io/SpectrobesGBA-RomPatcher/ INSTEAD

Manual instructions:
1) Extract all the contents included in the download.
2) Obtain a V1.0 FireRed ROM. (How you obtain this is your own business). V1.1 will NOT work; it has to be V1.0 FireRed. 1636.
3) Run the extracted NUPS.exe that was included in the download.
4) Select "Apply a UPS patch to a file"
5) File to patch: Your clean FireRed V1.0 ROM (will be overwritten with Spectrobes GBA).
     UPS patch: The extracted SpectrobesV0.4.ups that was included in the download.
     Click patch.
6) Upon successful patching, your original FireRed ROM file will have now become the Spectrobes GBA game that can be played on a GBA emulator. 
   Feel free to rename this file to "Spectrobes.gba" or whatever you want and move it wherever you like.
7) If it runs, great, have fun! If the game does not run, you probably used Firered V1.1 instead of V1.0 as your clean ROM. 