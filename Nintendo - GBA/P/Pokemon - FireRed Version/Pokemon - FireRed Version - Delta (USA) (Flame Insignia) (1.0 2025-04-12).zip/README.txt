
------Pok�mon FireRed Delta------
------------READ ME--------------

Thank you for taking the time to download the illegal .gba file
containing my ROM hack, Pok�mon FireRed Delta.

In downloading this illegal file, you are now my accomplice in
copyright violation, and in reading this document, you agree to
remain silent about our communal criminal activity.

Remember, if Nintendo doesn't know, it's not illegal *wink ;)*

**********************************

Pok�mon FireRed Delta is a difficulty/fakemon ROM hack with the
goal of replacing 149 of the 151 gen 1 Pok�mon with freshly
designed Delta variants. Mew and Mewtwo are excluded from the
redesign due to their postgame nature.

All 149 of the Delta variants are accessible before defeating
the Elite Four, and all trade evolutions have been replaced.
"Pick one" type Pok�mon, (e.g. starters, fossils) have been
added to Altering Cave in the Sevii Islands postgame.

This ROM hack does not contain the quality of life features
that modern ROM hacking has made possible to preserve the
authentic gen 3 experience. Examples of features that this
ROM hack **DOES NOT** have include:

-Fairy types
-reusable TMs
-Physical/Special split
-Visible EV/IV stats
-IV changing
-Nature changing
-Chegg unlocking

The only changes made to the ROM hack are those made to the 149
Delta Pok�mon (abilities, base stats, typing, movesets, etc.),
dialog adjustments for many NPC's, rebalancing to various moves
(e.g. buffs for HM moves, base power/PP changes to make gen 3
moves reflect changes made in later generations), and teams for
most of the trainer teams in the game, including gym leaders
and elite four.

Although I have tried to make each Delta Pok�mon's typing and
moves reflect their new designs, should you feel the need to
obtain more detailed documentation regarding the content of
this ROM hack, you may visit the spreadsheet below:

https://docs.google.com/spreadsheets/d/1Ot31SiXSOrSaqsOzYH5oo2Dc0i551g0ZmvgWmN288Hc/edit?usp=sharing

I have attempted to make each and every Pok�mon viable for a
full game playthrough and obtainable in a sensible location.
My advice is to load your team with whichever Delta Pok�mon
seem most appealing and just have fun! I hope you enjoy!

All Delta Pok�mon sprites featured in this ROM hack were drawn
by me personally, with a few caveats:

Kabuto and Kabutops were recolored and redrawn based on
their designs in Pok�mon Insurgence.

Tangela was resized and adjusted from its sprite in
Pok�mon Opalo.

Porygon's front sprite was originally made by EchoTheThird
on DeviantArt.

Major thanks to MrDollSteak on pokecommunity for providing
64x64 sprites of all the gen 1 Pok�mon in his thread.