--- Pok�mon Dreary Version | Anthroyd ---

This hack is only available through Anthroyd's Google Drive download link.

--- THINGS TO KNOW ---

1. All version patches should be applied to a Pok�mon FireRed v1.0 ROM, rather than v1.1
2. Ability to use Sacred Ash during battle (acts like a Max Revive)
3. Note that you're able to heal by sleeping in any bed, and there are a few "stray" Nurse Joys available who will heal your party.
4. Dreary is meant to pose a serious challenge... good luck!

--- Introduction ---

Pok�mon Dreary tells a short story about a troubled Kanto region.
Journey through Kanto and uncover mysterious phenomena...
But most importantly, get to the Indigo Plateau while you still have the chance.

--- Features ---

Short Story Focus
Ability to Sleep in Beds
Start from Last Save on Death
Intelligent Enemy AI
Modern Pok�mon Specs
Physical / Special Split
Convenient Repel System
Custom Soundtrack

--- Author's Notes ---

Pok�mon Dreary is a project developed at a relatively speedy rate.
Dreary was started on August 24, 2018, and was completed on January 28th, 2019.
My goal is to tell a short story that I whipped up in my head during my regularly scheduled dozing off.
By no means is this a hack that is meant to bedazzle you with its technical prowess!
By all means, this is a hack that is meant to make you think, challenge you, and be an all around memorable experience.

Let me know what you think!
Stumble upon a glitch? Have a suggestion? I appreciate any and all feedback!
I hope you enjoy playing Pok�mon Dreary as much as I enjoyed making it.

--- Sources --- 

ASM Creators:
MrDollSteak - Decap. and Attack Rombase
HackMew - Running Indoors ASM
Team Fail - Start from Last Save on Death ASM
diegoisawesome - Introduction ASM

Tool Creators:
Advanced Map
Advanced Palette Editor
Advanced Series
Advanced Text
Complete Item Editor
Cry Editor
Gen III Hacking Suite
GBA Intro Editor
Hopeless Trainer Editor
Nameless Sprite Editor Classic
Nameless Tile Map Editor
Sappy
unLZ
eXtreme Script Editor

Obligatory:
Game Freak
Nintendo