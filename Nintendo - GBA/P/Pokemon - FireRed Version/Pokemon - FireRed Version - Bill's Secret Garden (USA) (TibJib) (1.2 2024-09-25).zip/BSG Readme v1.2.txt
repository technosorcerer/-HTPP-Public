===========================================
POKEMON FIRERED: BILL'S SECRET GARDEN v1.2
Rom hack by TibJib
===========================================

Online version of this readme with active links can be found here:
https://docs.google.com/document/d/1Au7F-dqAkDQf7MhSL9GHLvjDil4SMfSNDWOmZBGacvc/edit?usp=sharing

Documentation for this rom hack can be found here:
https://docs.google.com/spreadsheets/d/1bywsxxD06xGuGpHlBZTbCKAszi3jr6k7XOuu5g-vTH4/edit?usp=sharing

A sprite pack that includes all the Beta sprites I created or edited can be found here:
https://www.mediafire.com/file/w8g7co0xmworp24/GSBeta_Sprite_Pack.zip/file


===========
OVERVIEW
===========

Bill's Secret Garden (BSG) is a Vanilla+ rom hack for FireRed. This includes the following changes to the base game:

• The namesake feature of this hack is a new garden area accessed from a teleporter in Bill's house. Here, you will find Pokemon from the GS Spaceworld Beta! Between the Pokemon you can find in the garden and new evolutions, there are a total of 40 new Pokemon to find.

• This hack uses CFRU as a base along with the Dynamic Pokemon Expansion. All the changes associated with this new engine are included, such as the Fairy-type, modern moves and battle mechanics, and the DexNav.

• Encounter tables have been updated so all 386 Pokemon in Gen 3 are catchable, with nearly all of them able to be found before the Elite Four.

• Any pre-evolutions, evolutions, forms, or variants of the original 386 Gen 3 Pokemon that were introduced in later generations have been made available. This includes Paradox forms, which are accessible as split evolutions from the original line they are based on.

• Trainer teams have been updated to take advantage of the newly available Pokemon. While this isn't intended as a difficulty hack, this does mean some trainers will naturally be harder than the base game.

• Various other changes such as new move tutors and shops, to help support the previously mentioned changes.


Despite using CFRU as a base, Mega Evolution and Gen 4-9 Pokemon unrelated to existing lines have been excluded from BSG.
Possible future features:
-Update animations for new attacks, which are currently recycling existing animations.
-Create an optional "Hard Mode" patch.
-Update certain Pokemon icons (some of them are pretty terrible…)
-Change in-game trades.
-Balance changes based on any feedback received.
-Multi-move tutors.


KNOWN BUGS:
-The map sprite for the roaming legendary that appears after beating the League is broken and shows the wrong Pokemon.
-Nincada’s normal evolution method isn’t working, making Shedinja impossible to get. Added a new evolution method to get Shedinja using a Dusk Stone.
-Registering more than one Key Item to the Select button causes a glitch in the item list. The items will function normally when selected, but the names will be wrong (For example, the Bike might be listed as Fresh Water).
-Some Pokemon, primarily regional forms, only give 1xp.


============
ROM Patching
============

The UPS file must be patched to a specific FireRed GBA ROM:
   1636 - Pokemon Fire Red (U)(Squirrels).gba

Use a .ups patcher (such as NUPS or tsukuyomi) or an online patcher such as this one:
https://www.marcrobledo.com/RomPatcher.js/


=========
Changelog
=========

1.2 - 9/22/24
------------------
One more small update, mostly to address a few bugs that have been reported to me. There is one big addition however…

* Farfetch’d now learns Cut at Level 15. This means you could trade for one in Vermilion City and skip getting the Cut HM, but why would you do that?
* Changed the Hidden Abilities of the Paradox Pokemon to be more beneficial to them specifically.
* Fixed an error where Mega Slowbro would show up in the lowest level of Seafoam Islands. This should have been Galarian Slowbro and has been corrected.
* Fixed a bug where Lucy in the Tanoby Ruins couldn’t be interacted with properly.
* Removed a broken NPC from Oak’s Lab.



1.1 - 8/17/24
------------------
The first and likely last update, unless I can figure out how to implement some of the desired features that didn't end up working out. That said, there are quite a few changes made. Old save files should work, but might cause new items to pop up on the overworld or some beaten trainers to reactivate.


* The PokeDex has been updated with entries for all the new Pokemon.
	** Was unable to implement separate entries for Hisuian, Paldean, and Beta regional forms, so they share entries with their base forms.
* The descriptions for TMs past TM50 have been fixed.
* The Exp Share has been moved to the Guard House on Route 11, outside Vermilion City. The ItemFinder is now in the Fuchsia City Guard House.
* The back half of Bill's Garden has been slightly altered, to make DexNav chaining easier.
* Some TM moves have been changed to be more useful. Locations of these TMs have been moved to be appropriate to power level.
	**TM41 Torment 	> 	Moonblast
	**TM48 Skill Swap 	> 	Zing Zap
	**TM67 Recycle 	> 	Raging Fury
	**TM110 Captivate 	> 	Wood Hammer
	**TM112 Round 	>	Draco Meteor
	**TM113 Echoed Voice > 	Dual Wingbeat
	**TM114 Natural Gift 	> 	Icicle Crash
	**TM115 Quash 	> 	Meteor Mash
	**TM119 Sky Drop 	> 	Expanding Force
	**TM120 Nature Power > 	Fiery Dance
* Sludge Bomb TM has been moved to be available before E4.
* 20 additional Move Tutors have been added. See documentation for full list.
* Location of the Body Slam tutor has been changed to Vermilion City.
* Many late-game item pickups have been changed to remove filler and make them more valuable.
* Masquerain has been buffed, with similar stats to other rom hacks. Done to make it more viable when used by enemy trainers.
* Mawile now learns Metal Claw earlier.
* Tangtrip has been moved to Route 22, west of Viridian City.
* Bomsheal now learns Seed Bomb via Move Tutor
* Super Boss trainers have been added to Seven Island. There is one for each type, excluding the types already used by the Elite Four. These trainers have full IVs, with customized EVs, natures, movesets, and items. Their teams are in the mid-80s. They will initiate a battle as soon as you speak with them, so be ready before you approach. You'll likely know them when you see them.
* The Rival in the Elite Four rematches has been buffed, giving his Pokemon EVs, IVs, and held items.
* A secret cheat block has been added for anti-grinding support.



1.0 - 7/22/24
------------------
The first release! As there are no version changes, I’ll provide the full list of changes from base FireRed.

* CFRU and DPE have been applied via Leon’s Base Rom in HexManiacAdvance. All basic features included in this engine upgrade are applied.
* 40 new Pokemon added, with some being new lines and others being new evolutions.
* New moves have been added, primarily as signature moves for the new Pokemon.
* New evolution items have been added.
* A new area was added to Bill’s House via a teleporter in the back. This garden area houses most of the new Pokemon.
* Later generation evolutions and forms for the original 386 Pokemon have been made available.
* Mega Mawile and Mega Sableye have been made into their own Pokemon, Feauxile and Gemineye. They will evolve from their original forms by level.
* G-Ponyta/G-Rapidash and Masquerain have had their types changed.
* Covet has been changed into a Fairy-type move.
* Encounter tables have been altered to allow most Pokemon to be found before the Elite Four.
* Small new areas have been added all over the region to provide catching locations for some Pokemon.
* The female trainer sprite has been changed to Blue (JP). Sprite courtesy of LouLilie.
* Player starts with Running Shoes.
* Trainer teams have been updated to take advantage of the newly available Pokemon.
* In addition, many mid-to-late game trainers who were still using unevolved Pokemon have been given final evolutions. This is most noticeable on the routes leading to Fuchsia and beyond.
* TM locations have been moved to increase availability.
* Move Tutors are now repeatable. Most Tutors have been given different moves and new Move Tutors have been added all over the region.
* PokeMarts have been updated with a second vendor for additional items, such as special Pokeballs and type-boosters.
* The DexNav has been made available in Veridian.
* The Good Rod has been moved to Lavender Town.
* Item selection in the Department Store has been expanded, including more evolution items and more Pokeballs.
* New vendors have been added to Celadon Mansion, Pokemon Trainer Fan Club, Fuchsia City, Two Island, and Five Island, providing various rare items.
* The Mystic Ticket is available on the Sevii Islands before the Elite Four.
* The National Dex catching requirement has been reduced to 30. Note, only the original 150 Kanto Pokemon will count towards this number.
* The Aurora Ticket is available in the post-game Sevii Islands.
* The Elite Four rematches have been updated with new Pokemon and are designed to be a bit harder than the vanilla game.
* A special trainer has been added to Birth Island, with a team in the mid-80s. Proceed with caution.



========
CREDITS
========

Tools:

CFRU by Skeli789, ghoulslash and more
https://github.com/Skeli789/Complete-Fire-Red-Upgrade
	
Dynamic Pokemon Expansion
https://github.com/Skeli789/Dynamic-Pokemon-Expansion?tab=readme-ov-file

HexManiacAdvance by haven1433
https://github.com/haven1433/HexManiacAdvance


Sprites:

I edited most of the new sprites for the beta Pokemon myself, creating GBA-styled sprites using existing GB-style sprites as a base. However, I did not create the original GB sprites, so I'd like to highlight the many talented sprite artists behind these original images.

Most of the Beta Pokemon sprites were edited from those found in the Pokemon GS '97: Reforged rom hack. Credit to Rool, Smalls, Pik, Bencc, Nuuk, Scarlax, Sam the Salmon, and SoupPotato for the original GS versions of these Pokemon:

https://www.pokecommunity.com/threads/pok%C3%A9mon-gold-and-silver-97-reforged-complete.437360/

-Flambear	-Sunmola
-Volbear	-Anchorage
-Dynabear	-Grotess (Back)
-Cruize		-Wolfur
-Aquallo	-Alphur
-Aquarius	-Meowsy (Back)
-Kotora	-Raika
-Raitora	-Enta
-Rinring	-Suica
-Bellarin	-Bellmit
-Ghual		-Cottomew
-Kurstraw	-Praxe
-Pangshi	-Numpuff
-Rayleep	-Mafetch'd

Credit for the following sprites goes to MultiDiegoDani:
https://www.deviantart.com/multidiegodani/art/Some-Beta-Pokemon-Gold-Silver-Sprites-843651024

-Dewpodd
-Grotess (Front)
-Meowsy (Front)
-Anchorage (Tail)

	
Credit for the following sprites goes to Aethestode:
https://www.deviantart.com/aethestode/art/Spaceworld-Demo-Beta-Pokemon-Sprites-Revamped-856667682

-Bomsheal
-Lickilord
-Gelania
-Noctowl Beta
-Remoraid Beta


Beta Octillery sprite created by peeboy:
https://www.spriters-resource.com/custom_edited/pokemongeneration2customs/sheet/134704/


The front sprite for Gorochu was edited from the sprite found in the Kanto Expansion Pak rom hack. Credit to artists RacieBeep, Martha’s Against Humanity and Albatross:
https://www.pokecommunity.com/threads/kanto-expansion-pak.525646/


The back sprite for Goruchu was edited from sprites made by Keiitan and JabariWilliams:
https://www.deviantart.com/keiitan/art/Gorochu-revamped-795662678
https://www.deviantart.com/jabariwilliams/art/Gorochu-GBA-Style-957712705


The sprite for Keelisk was edited from sprites made by Abeshoken on DeviantArt and the Earthretha Fakemon Pack by NanaelJustice:
https://www.deviantart.com/abeshoken/art/Drakkarow-Betamon-840880948
https://www.pokecommunity.com/threads/earthretha-fakemon-pack.527306/


The back sprite for Meowsy was edited from sprite made by Drafex14 on DeviantArt:
https://www.deviantart.com/drafex14/art/Beta-Sprites-All-Copia-895048858


The "puffball" part of the Cottomew sprite was edited from a sprite made by Pokemon-Future:
https://pokemon-future.tumblr.com/about


Sprites for Gen 6-9 Pokemon taken from the PokeCommunity Sprite Repository:
https://www.pokecommunity.com/threads/ds-style-gen-vii-and-beyond-pok%C3%A9mon-sprite-repository-in-64x64.368703/


The sprites for the SECRET Pokemon were taken from the rom hack TPP Burning Red. Credit for original design goes to Warupua on DeviantArt:
https://github.com/TwitchPlaysPokemon/tpp_burning_red
https://www.deviantart.com/warupua


The sprites used for Beta Girafarig and Tangel came from unknown/lost sources. If anyone knows the origin of these particular sprites, please let me know and I will be happy to credit the original artists.


The female trainer sprite of LGPE Blue (JP) was created by LouLilie.
https://x.com/Lou_Lilie


Gen 9 sprites from the PokeCommunity Sprite Repository.
https://www.pokecommunity.com/threads/ds-style-gen-vii-and-beyond-pok%C3%A9mon-sprite-repository-in-64x64.368703/


Special thanks to the HexManiac Discord server, for helping me throughout this entire process.



================
Development Trivia
================

-This hack was first conceived with the thought "Wouldn't it be cool to play through FireRed with the GS beta Pokemon? Maybe have a garden behind Bill's house where you can catch them!". That was originally all this hack was going to be.

-Then I got thinking, "The Gen 3 mechanics are a bit limiting when designing how these Pokemon will work. I'd at least like to have the Physical/Special split to give them more design variety. I guess I'll use CFRU as the base for the hack".

-This led to the thought, "Well if CFRU includes them anyway, I might as well make the later generation evolutions available in the game. And if I'm going that far, I should make the regional forms available too."

-Then Scarlet/Violet came out. I saw all the new Paradox forms and thought "It would be great to include those as split evolutions for the Pokemon they're based on!"

-This all led to the reasoning that "If I'm adding all these new Pokemon, I should make this a 386 hack as well so all of them will be available to the player before the Elite Four. Should probably make sure the trainers they encounter also use all available Pokemon."

-And that ladies and gentlemen, is the dangers of Feature Creep.

-One last thing. Before commiting to creating new sprites for all the beta Pokemon, I had briefly considered just changing all the Pokemon sprites in the game into Gen 1-2 style sprites. Glad I took the extra effort instead.


