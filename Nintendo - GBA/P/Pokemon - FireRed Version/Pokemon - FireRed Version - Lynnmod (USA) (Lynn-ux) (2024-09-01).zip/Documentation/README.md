Here you'll find various excel files that I use to keep track of (most) of the changes in the game. 
