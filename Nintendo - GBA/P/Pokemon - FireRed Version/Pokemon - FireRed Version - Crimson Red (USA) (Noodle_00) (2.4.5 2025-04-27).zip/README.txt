﻿The Reccomended playstyle
Crimson Red was built to play with Hardcore nuzlocke rules and with the cheat file inserted that is optional (No exp gain which is a self imposed level cap + 100% catch rate)


If you want to have a harder experience then you can play with custom nuzlocke variants:


HC+
* HC nuzlocke 
* No gift Pokemon
* No legends / mythicals


HC++ 
* HC+ nuzlocke
* No hidden items besides heart scales
* Must bring the same amount of Pokemon as the next trainer


These are just some ideas I had but the game wasn’t built around these variants.




Move Changes:


Disable
* Always lasts 4 turns


Encore
* Always lasts 3 turns


Taunt
*  Always lasts 3 turns


Scald
* Always Burns


Stockpile
* Always Raises Def and SpDef by 1 each time this move is used
.
Rapid Spin
* Raises Speed by 1


Detect
* PP reduced to 3


Protect
* PP reduced to 5


Fake Out
* PP reduced to 3


Explosion / Self Destruct
* PP reduced to 1


Features
2.3
* 30+ Battles Changed
* Elite 4 remade
* New Bag assets
* New Berry Pouch assets
* New TM Case assets
* New Battle Backgrounds
* New Battle UI
* Move Balancing
* Pokemon Balancing
* 4 New Megas
* Bug Fixes
* New item distribution 
* Gym Leader Relocations


Bugs
2.2
* Route 26 game crash when entering back to Route 3
* Town Map crashing when in new location
* Player being able to walk through walls
* Crash when entering Lavender town from Route 8 with the mountain Route
* Pokemon Mansion walls being in the wrong location
* Giovani (Leader Team) being the wrong level


2.3
* Berry Bag being weirdly coloured when choosing Dawn as a playable character (Female player)
*