# Pokémon Pinball: Ruby & Sapphire Speedchoice

As with other "speedchoice" ROM hacks, Pokémon Pinball: Ruby & Sapphire Speedchoice is a hack designed to make the game more speedrun-friendly. Specifically, this hack is designed to drastically reduce the amount of time necessary for the "Complete Pokédex" category.

Please see CHANGELOG.md for more information on specific changes.

To download the hack, click on the bps file above, and then click the "Download raw file" button. It looks like this: ![image](https://github.com/user-attachments/assets/96a892a8-794f-490c-8a4b-447175de8e53)
