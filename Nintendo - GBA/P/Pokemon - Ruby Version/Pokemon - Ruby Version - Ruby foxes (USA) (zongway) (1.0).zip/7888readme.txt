ver 1.0


* changed starters to vaporeon and jolteon and Flareon


* change wild encounters to more gen 1 and 2


* changed gym leaders


* replaced parasect and RELICANTH and Mawile 


* gives hidden power TM10


