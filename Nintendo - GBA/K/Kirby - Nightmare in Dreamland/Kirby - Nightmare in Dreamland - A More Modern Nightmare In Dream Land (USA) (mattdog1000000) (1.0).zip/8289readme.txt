Despite coming out after Kirby Super Star, the mechanics and controls of Kirby: Nightmare in Dream Land were entirely based on its predecessor: Kirby's Adventure.

This hack does not aim to bring absolutely all of the modern sensibilities that KSS introduced, but rather:
1) Not dropping the copy ability every single time Kirby takes damage
2) Hovering only with the jump button -- leaving Up on the +Control Pad to be used by other mechanics with fewer frustrations

General Notes:
- The A_More_Modern_Amazing_Mirror patches contain both the Damage_Retains_Basic_Ability and No_Up_Hover patches
- When playing multiplayer, ensure that all games have the same patch(es) applied, otherwise desyncs and errors can occur

Notes on Damage_Retains_Basic_Ability patch:
- UFO ability is still dropped when damaged to avoid some buggy behavior

Notes on No_Up_Hover patch:
- UFO still controls like it previously did (with Up on the +Control Pad causing it to rise)

Database match: Kirby - Nightmare in Dream Land (USA)
Database: No-Intro: Game Boy Advance (v. 20210227-023848)
File/ROM SHA-1: 37A476567D133C146FEE6B5E2EB0B07A215DA6B0
File/ROM CRC32: 20EF3F64

Database match: Kirby - Nightmare in Dream Land (Europe) (En,Fr,De,Es,It)
Database: No-Intro: Game Boy Advance (v. 20210227-023848)
File/ROM SHA-1: 39B00BEEE4558E6738859CFA250E4E0FCAAE626E
File/ROM CRC32: 3B7A7477

Database match: Hoshi no Kirby - Yume no Izumi Deluxe (Japan)
Database: No-Intro: Game Boy Advance (v. 20210227-023848)
File/ROM SHA-1: D0E1D2578344E881780A71B9910562DA4B123964
File/ROM CRC32: C55A3C2C
