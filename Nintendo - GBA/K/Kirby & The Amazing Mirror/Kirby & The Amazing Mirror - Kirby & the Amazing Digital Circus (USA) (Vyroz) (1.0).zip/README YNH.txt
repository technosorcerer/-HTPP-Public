Been a while since I last uploaded something huh? Well, while I'm working on Amazing Mirror ENCORE, here's something I've been working on since December of 2023. "Your New Home" from The Amazing Digital Circus is intended to replace the ending theme (the one that plays after defeating Dark Mind). The patches included here are for the EU and US versions of the game.

If you want to test it without having to beat Dark Mind's ass, just go to track 17 in the sound test.

Credits & Tools:
Vyroz - Composition, arrangement, developer
Anvil Studio - Composer tool
Mid2AGB - .MID to AGB sound file
SAPPY - Importing
HxD - Miscellaneous stuff
