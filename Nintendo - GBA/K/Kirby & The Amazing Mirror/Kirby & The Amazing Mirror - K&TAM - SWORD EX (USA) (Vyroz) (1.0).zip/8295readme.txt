Thank you for downloading SWORD EX! This mod aims to make Sword's aerial moveset more similar to its grounded moveset. It also applies to Sword underwater. This ZIP file includes pathes for the European and American versions of the game. Please continue reading for a list of changes and disclaimers.

Changelist:
*Overhead Slash, Multisword Attack, and Final Stroke can all be used in the air and underwater with the same inputs as the grounded version.
*Final Sword can also be used in the air and underwater with the same input.
*Sword Spin can be used in the air if done after a float cancel (press A to float and immediately use B). It cannot be used underwater, however.
*Sword's hat and icon were slightly modified.

Disclaimers:
There were some bugs I found that didn't harm the experience. However, I should still document them.
*Using Final Sword at the peak of a jump skips the starting lag of the move and starts right at the ascending portion.
*Master's Drill Rush might sometimes stop abruptly in mid-air as if it had hit a wall. Aditionally, Down Thrust can only be used after a float cancel.

Credits & Programs:
*Vyroz: Hacking
*HxD: Code editing, porting from EU to USA
*Tile Molester: Graphical edits

