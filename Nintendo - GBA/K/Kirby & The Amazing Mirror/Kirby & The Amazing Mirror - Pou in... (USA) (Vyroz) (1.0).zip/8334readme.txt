Thanks for downloading this mod, I think! This just changes Waddle Dee, Boss Endurance Waddle Dee, and Parasol Waddle Dees into Pou, from the hit mobile game Pou. This file contains two patches, one for the EU version, and another one for the US version.

CREDITS
Vyroz: Developer and spritework
Tile Molester: Graphics tool
HxD: Porting from EU to US