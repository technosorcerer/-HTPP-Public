Hi! Thank you for downloading this music hack! This works for both the European and American versions of the game. This hack makes Sky Tower from Kirby's Return to Dream Land to play in Carrot Castle! Moonlight Mansion keeps its old music. The theme is listed as music 39 in the Sound Test, replacing an unused duplicate of the Crackity Hack theme.

This track took a lot of time to compose and mix. If you find any problems, please notify me. I've made sure to polish and adjust some parameters so the track is stable in-game.

CREDITS & TOOLS I USED
Vyroz: Composition, developer
Anvil Studio: Composer program
Mid2AGB: Converting my MIDI to an AGB Sound File
SAPPY: Insterting the track into the game
HxD: Room modification