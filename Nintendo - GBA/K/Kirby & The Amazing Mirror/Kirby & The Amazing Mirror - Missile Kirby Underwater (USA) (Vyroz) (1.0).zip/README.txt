This is a change to the ability pointers of the game that allows Missile to work underwater. Just go to any body of water and press B inside it to transform. Includes patches for the Japanese, European, and American versions of the game.

Tools used:
HxD: Pointer modifications

Thank you to Mr.PersonMan on Discord for initially telling me about Missile working underwater :)