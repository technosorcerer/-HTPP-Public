Thank you for downloading my very first finished mod for Amazing Mirror! This is mostly a palette swap mod, but it also includes many modifications to graphics themselves. This mod had been in the works since October 10th, but I still put love and care and I even modified a little bit of code.

There were some things I planned to change but I unfortunately couldn't. The Collection Room still says "SPRAY PAINT: PINK" due to the graphic for it being a pain in the ass to modify, so you'll have to live with that for a sec. The intro text is also unchanged due to also being a compressed graphic and because I don't really mind it staying the same :P

THIS IS ONLY FOR THE EUROPEAN VERSION OF THE GAME. I have plans of making a Japanese version of the mod. A mod for the US version of the game is still being considered.

TOOLS I USED:
*Tile Molester: Graphic modifications and palette changes.
*GBA Graphics Editor: Palette finder and minor palette changes.
*HxD: Code modification and palette changes.
*mGBA: Emulation and memory tools.

CREDITS:
Vyroz: Creator and sole developer of the mod.
heynow: Suggested the change to the ability hats, and provided technical information.
Mr. Person Man: Original discoverer of underwater Missile.

Changes:

This is a list containing the changes contained in this mod. If you'd like to find out everything by yourself, please skip this list.

*Turned Pink Kirby into Shadow Kirby.
*Turned Shadow Kirby's encounters into "Kirby of the ⭐" encounters (applies to all languages).
*Changed the Cherry Spray Paint to be red, similar to the Strawberry Color from Dream Buffet.
*Pink Spray Paints, Maps, and Notes have been changed to resemble Shadow Kirby's color scheme.
*Changed many ability hats to be in grayscale to match Shadow Kirby.
(Hats not changed are Fire, Ice, Burning, Tornado, Spark, Cupid, Cook, Magic, Laser, Parasol, and Sleep)
*Made 2 custom palettes for Shadow Kirby and Cherry Kirby in their UFO form.
*All ability icons have been modified to be Shadow Kirby.
*The Master ability now makes the sword resemble Dark Meta Knight's sword.
*Fixed "Mr. Flosty's" name to be "Mr. Frosty".
*Fixed one of Sword's attacking sprites. The old version lacked 4 pixels in the ball on the tip of the hat.
*Missile can now be used underwater.
*Shooty and Soarar now give Laser when inhaled.

Might release some of these changes as separate mods in the future.

If you wish to support me, follow me on Tumblr (vyroz-sun.tumblr.com) or alternatively, on Tw*tter (@_Vyroz_). You can also use Discord to contact me if you have any suggestions or complaints about the mod (@vyroz).