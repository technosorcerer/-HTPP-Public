Thank you for downloading the EX Aility Trio hack! This aims to make the aerial moveset of Sword, Fighter, and Hammer more similar to their grounded moveset. It also applies to Sword underwater. This ZIP file includes pathes for the European and American versions of the game. Please continue reading for a list of changes and disclaimers.

Changelist:

SWORD:
*Overhead Slash, Multisword Attack, and Final Stroke can all be used in the air and underwater with the same inputs as the grounded version. Final Sword can also be used in the air and underwater with the same input.
*Sword Spin can be used in the air if done after a float cancel (press A to float and immediately use B). It cannot be used underwater, however.
*Sword's hat, sword, and icon were modified.

HAMMER:
*Hammer, Hammer Swing, and Hammer Flip can all be used in the air with the same inputs as the grounded version.
*Hammer's hammer and icon were modified.

FIGHTER:
*Vulcan Jab, Kick, and Spike punch can all be used mid air. Spin Kick is now reverted to how it was in Amazing Mirror's demo version, propelling Kirby sideways when using it in the air. Force Blast and its charged variants can also work in the air, as so does Moon Somersault Kick, and can even be done multiple times in a row.
*Fighters bandana and icon were modified.


Disclaimers:
There were some bugs and issues I found that didn't harm the experience. However, I should still document them.
*Using Final Sword at the peak of a jump skips the starting lag of the move and starts right at the ascending portion.
*Fighter can't use Sky Kick. Similarly, Hammer can't use Giant Swing. I tried to find solutions to these issues but I couldn't make them work. My apologies.
*Master's Drill Rush might sometimes stop abruptly in mid-air as if it had hit a wall. Aditionally, Down Thrust can only be used after a float cancel. I don't know why this happens.

Credits & Tools:
*Vyroz: Developer
*HxD: Code editing, porting from EU to USA
*Tile Molester: Graphical edits
