Despite coming out after Kirby Super Star, the mechanics and controls of Kirby & The Amazing Mirror were largely based on its predecessor: Kirby's Adventure.

This hack does not aim to bring absolutely all of the modern sensibilities that KSS introduced, but rather:
1) Not dropping the copy ability every single time Kirby takes damage
2) Hovering only with the jump button -- leaving Up on the +Control Pad to be used by other mechanics with fewer frustrations

General Notes:
- The A_More_Modern_Amazing_Mirror patches contain both the Basic_Damage_Retains_Ability and No_Up_Hover patches
- When playing multiplayer, ensure that all games have the same patch(es) applied, otherwise desyncs and errors can occur

Notes on Basic_Damage_Retains_Ability patch:
- When Kirby is kissed or takes electric/fire damage, kirby still drops his ability -- this avoids large graphical corruptions
- Environmental spikes and damage from being flung also had the ability dropping removed, despite these being a bit more than "basic"

Notes on No_Up_Hover patch:
- UFO still controls like it previously did (with Up on the +Control Pad causing it to rise)
- Cupid will only enter its flying state after the jump button is pressed while in the air (then Up on the +Control Pad causes it to rise like it previously did)
- AI logic was updated to use the jump button instead of Up on the +Control Pad to hover, but it may behave a bit differently as a result of these no longer being two separate bits

Database match: Kirby & The Amazing Mirror (USA)
Database: No-Intro: Game Boy Advance (v. 20210227-023848)
File/ROM SHA-1: 274B102B6D940F46861A92B4E65F89A51815C12C
File/ROM CRC32: 9F2A3048

Database match: Kirby & The Amazing Mirror (Europe) (En,Fr,De,Es,It)
Database: No-Intro: Game Boy Advance (v. 20210227-023848)
File/ROM SHA-1: 6F478A455383A2A12378F292581DFD7300300700
File/ROM CRC32: 4F07C618

Database match: Hoshi no Kirby - Kagami no Daimeikyuu (Japan) (Rev 1)
Database: No-Intro: Game Boy Advance (v. 20210227-023848)
File/ROM SHA-1: 75C95413EB5BB98E8E2549BCEBCF590A0CE75C8B
File/ROM CRC32: 683D772C
