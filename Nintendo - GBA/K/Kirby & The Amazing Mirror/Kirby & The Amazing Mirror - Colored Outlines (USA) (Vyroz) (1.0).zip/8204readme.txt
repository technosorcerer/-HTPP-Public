Thank you for downloading this cosmetic change. It's sorta minor, but I think it's nice. :)
This file contains 2 patches, each corresponding to the European and American versions of the game.

Tools:
*Tile Molester: Palette edits
*GBA Graphics Editor: Finding palettes
*HxD: Porting from EUR to USA