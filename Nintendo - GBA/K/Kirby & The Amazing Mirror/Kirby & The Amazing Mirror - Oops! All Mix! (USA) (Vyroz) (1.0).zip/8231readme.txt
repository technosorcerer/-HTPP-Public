Hello! Thank you for downloading my hack! This works for the European version of the game, as well as well as the American version. That's right! I've decided to finally port one of my mods to the American version of the game. It was simple enough, so I thought maybe I could do it for convenience. There are 2 ips patches in this file. Just be careful and make sure you apply the correct patch to the correct version.
This mod changes EVERY enemy to give a mix upon inhaling. It doesn't matter if the enemy didn't have an ability to begin with. You just inhale that baddie, and BAM, random ability roulette. For some reason, the first Waddle Doo of Rainbow Route doesn't change, but it's only that Waddle Doo, so it's fine.

Credits:
Vyroz: Developer, param editor
RHVGamer: Came up with the idea

Tools I used:
KatAM Object Editor by Fyik