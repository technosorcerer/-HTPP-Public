Filename:  vforcdbg.ips
Console:   Virtual Boy
Game:      Virtical Force (U)
Comments:  Unlocks A Debug Menu With Stage Select and Sound Test


This is an IPS patch file, you will need an IPS patcher program to apply the
patch to your Virtical Force (U) ROM. This has been made and tested on the USA
ROM with CRC32 4C32BA5E.


When the patched ROM loads, you will see a debug menu containing a Stage Select
and Sound Test option. The Sound Test is very polished, leading me to believe
it's accessable without a patch. In fact, the debug menu may be accessable as
well. Most likely with a button combonation on the title screen.


On a final note, this patch consists of only one byte changed! Address 0xB330
contains assembly which selects the first portion of the game to load. Changing
the selection to the value of the debug menu is what the patch does. Simple!
