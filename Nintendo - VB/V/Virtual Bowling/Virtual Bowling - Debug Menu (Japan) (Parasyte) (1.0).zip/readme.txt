Filename:  vbowldbg.ips
Console:   Virtual Boy
Game:      Virtual Bowling (J)
Comments:  Unlocks A Debug Menu Which is Accessable in the Prototype


This is an IPS patch file, you will need an IPS patcher program to apply the
patch to your Virtual Bowling (J) ROM. This has been made and tested on the
Japanese ROM with CRC32 20688279.


When the patched ROM loads, you will see a debug menu with 3 items. The
values used are hex, with the "F" character replaced by "?."

MUSIC 0-1C (including all the hex in between - 29 total)
SE 0-26 (including all the hex in between - 39 total)
MAINFG 0-18 (including all the hex in between - 25 total)

"MAINFG" is a 'level select' of sorts. Use it to get to other parts of the
game.


On a final note, this patch consists of only one byte changed! Address 0x3EFA
contains assembly which loads the first portion of the game. The assembly
accesses a pointer table, which means all we have to do is change which
pointer is loaded to open the debug menu. Changing the index from 1 to 3 is
all there is!


For more info on the Virtual Bowling prototype, visit DogP's website,
Project: VB - http://projectvb.vze.com/
