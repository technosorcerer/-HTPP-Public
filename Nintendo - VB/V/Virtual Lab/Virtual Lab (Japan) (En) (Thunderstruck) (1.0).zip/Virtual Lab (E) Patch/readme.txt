Hey everyone,

VirtuousRage posted some screenshots for translating Virtual Lab some time ago. After that I was asked by several members of the community to do a translation patch. I didn't really see the point as all the Japanese text is already translated on screen. When I checked for the first time I saw that the hack wouldn't be as easy so I moved on.

However, I had a look again today and decided to do the absolute minimum. I didn't do most of the proposed rearrangements and didn't alter the English text. I just removed the Japanese text and moved the English text on the "Read Instructions" screen a bit.

-ThunderStruck