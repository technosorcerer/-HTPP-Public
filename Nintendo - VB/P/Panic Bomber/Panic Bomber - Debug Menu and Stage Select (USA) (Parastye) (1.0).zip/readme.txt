Filename:  pbombdbg.ips, pbombrss.ips
Console:   Virtual Boy
Game:      Panic Bomber (U)
Comments:  Unlocks Debug\Stage Select Menus (See Notes Below)


This is an IPS patch file, you will need an IPS patcher program to apply the
patch to your Panic Bomber (U) ROM. This has been made and tested on the USA
ROM with CRC32 19BB2DFB.


When the patched ROM loads, you will see a debug menu with 5 items. (Also
notice "VERTIAL BOY" at the top!) The first menu item takes you to the normal
game. The second and third items are similar. Both load the same sub-menu,
but only the former allows you to actually play the game. With the latter,
you will be watching the CPU play against itself. The forth menu item is a
happy sound test. And the the last takes you directly to the end sequence.

The debug sub-menus are filled with several items for you to play with. Each
affects the way the game plays. I have not tested every one, but there are
things such as background and enemy selection.


On a final note, there is still one other debug menu which this main menu
does not access. It's a Stage Select menu. I've included a second IPS patch
(pbombrss.ips) To unlock the Stage Select menu. You must use each IPS on
seperate ROMs! THEY ARE NOT COMPATABLE.

With the Stage Select patch, the Stage Select menu will appear in place of
the debug menu. To get to the intro\title screen, lose to the CPU, then
choose not to continue.

