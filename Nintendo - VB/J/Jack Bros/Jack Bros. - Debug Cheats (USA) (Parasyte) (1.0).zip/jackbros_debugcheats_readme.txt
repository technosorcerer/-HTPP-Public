Filename:  jbrosdbg.ips
Console:   Virtual Boy
Game:      Jack Bros. (U)
Comments:  Unlocks Debug Cheats Which are Normally Inaccessable


This is an IPS patch file, you will need an IPS patcher program to apply the
patch to your Jack Bros. (U) ROM. This has been made and tested on the USA
ROM with CRC32 801F5A10.


When the patched ROM loads, you will notice nothing unusual. However, there
are certain cheats which have been disabled by the programmers. This patch
re-enables them for you to explore!

=====The following cheats work on an unpatched (and patched) ROM:

Hard mode:

To access a harder difficulty level, press the following combination on the titlescreen using the left DPad: 6 x Right, 3 x Left, 6 x Right. 
If you did it right, "For Super Players" appears under the "Jack Bros." logo. The differences to normal mode are more and differently placed enemies, different textures in the levels, differently looking boulders and warp tiles, more jack traps, pradices are closer together and, of course, different passwords. You get this cheat after completing the game.

Play as Pixie:

To access Pixie as another playable character, type in '4649' on the password screen but confirm the '9' by pressing and keeping pressed L and R Triggers, Select and A simultaneously instead of using the A Button.

Show map:

To see the whole level on your map, instead of just the keys, type in the following while the game is paused on the left DPad: Up, Left, Down, Right. This cheat can be disabled by the following combo: Up, Right, Down, Left.

Sound Test:

To access a hidden Sound Test Menu, type in the following at the title screen using the left DPad: 3 x Up, 4 x Down. This cheat only works in the japanese version.

*Note that on the patched USA game, the music\sfx names are scrambled)

=====The following cheats work only on a patched ROM:

Level select:

To access a level select menu, type in the following at the title screen using the left DPad: 7 x Right, 1 x Left, 7 x Rights. This Cheat was disabled in the final version of the game by the programmers and only works with a patched Rom.

Invulnerability:

To access the "Muteki Select", type in the following at the title screen using the left DPad: Up, Right, Down, Left, Up, Right, Down, Left, Up, Right, Down, Left. Muteki is japanese for invincible, while the second option, "ataru", means vulnerable. Note that you can't use warps when invincibly, but you can use the "Go through walls" trick instead. This Cheat was disabled in the final version of the game by the programmers and only works with a patched ROM.

More time:

On a patched ROM, you can manipulate the remaining time by pressing the L Trigger and up or down on the right DPad.

More special attacks:

Using a patched ROM, you can manipulate the number of remaining special attacks by pressing the L Trigger and left or right on the right DPad.

Go through walls:

Using a patched ROM, it is possible to move freely on the playfield by holding down the L trigger. This way you can go through walls and reach other areas of a level, only boulders still are an obstacle.

Show position:

Using a patched ROM, you can display your current position in form of X and Y coordinates by pressing the L Trigger and Select simultaneously.

On a final note, this patch consists of only two bytes changed! Address 0x0000
is a variable which the game checks to ensure it's allowed to allow the cheats.
If the byte at this address is 0x00, the game will not allow the debug cheats,
otherwise, it will! Address 0x1218 is a function which watches the user enter
the Sound Test cheat. If the game is not in Japanese mode, it disallows the
use of the Sound Test cheat! So the second byte changed ensures the language
is set to English.

To change your ROM to Japanese mode, change the byte at 0x0004 to 0x00!
