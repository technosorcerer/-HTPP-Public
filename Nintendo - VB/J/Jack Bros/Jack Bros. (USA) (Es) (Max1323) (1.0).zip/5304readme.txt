"Jack Bros."
Traducci�n al Espa�ol Ver. 1.0 (14/12/2019)
por Max1323 (maxmuruchi@gmail.com)
---------------------------------------------------
Descripci�n:
El jugador toma el papel de uno de los tres hermanos Jack, Jack Frost, Jack Lantern o Jack Skelton, que han visitado el mundo humano para Halloween y necesitan regresar al mundo de las hadas antes de que se cierre el portal que conecta los dos mundos. El jugador debe atravesar seis �reas, que consisten en una serie de pisos, derrotando a los enemigos mediante el uso de ataques espec�ficos del personaje y recogiendo llaves para poder avanzar al siguiente piso.

Desarrollado: Atlus 
Publicado:    Atlus
Lanzamiento:  29/09/1995   (JAP)
              Octubre 1995 (USA)
---------------------------------------------------
Acerca del proyecto:
Se tradujo los di�logos.
Contiene el modo debug creado por Parasyte.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS

Jack Bros (U) [!].vb
File Size     1.00 MB
File MD5      EE873C9969C15E92CA9A0F689C4CE5EA        
File SHA-1    0E086D7EF2BD8B97315196943FD0B71DA07AA8F1
File CRC32    A44DE03C                                
