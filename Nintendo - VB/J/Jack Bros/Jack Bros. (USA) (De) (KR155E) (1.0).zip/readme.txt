                                     __          __ ______
   ____  _    ___  _    _ ____ _____\  \        /  /  __  \
  |  _ \| |  / _ \| \  | |  __|_   _|\  \      /  /  |  |  |
  | |_| | | | |_| |  \ | | |_   | |   \  \    /  /|  |__| /
  |  __/| | |  _  | |\\| |  _|  | |    \  \  /  / |   __ |
  | |   | |_| | | | | \  | |__  | |     \  \/  /  |  |  | \
  |_|   |___|_| |_|_|  \_|____| |_|      \    /   |  |__|  |
  [   w  w  w  .  v  r  3  2  .  d  e   ] \__/    |_______/

  PRESENTS...

    Jack Bros. German Translation Hack v1.00 by KR155E

  INFO:
  
    This patch translates all editable text and some graphics
    in Jack Bros. to german. It also includes Parasyte's Debug
    Patch. To be used with the US version ROM.