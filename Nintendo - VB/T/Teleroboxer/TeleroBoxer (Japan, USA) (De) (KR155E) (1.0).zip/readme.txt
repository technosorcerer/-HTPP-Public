                                     __          __ ______
   ____  _    ___  _    _ ____ _____\  \        /  /  __  \
  |  _ \| |  / _ \| \  | |  __|_   _|\  \      /  /  |  |  |
  | |_| | | | |_| |  \ | | |_   | |   \  \    /  /|  |__| /
  |  __/| | |  _  | |\\| |  _|  | |    \  \  /  / |   __ |
  | |   | |_| | | | | \  | |__  | |     \  \/  /  |  |  | \
  |_|   |___|_| |_|_|  \_|____| |_|      \    /   |  |__|  |
  [   w  w  w  .  v  r  3  2  .  d  e   ] \__/    |_______/

  PRESENTS...

    Teleroboxer German Translation Hack v1.00 by KR155E

  INFO:
  
    This patch translates all editable text in Teleroboxer to
    german.