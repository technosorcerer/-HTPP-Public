YU-NO: A Girl who Chants Love at the Edge of the World
PC-98 translation patch by BabaJeanmel

Version 1.5 - 12/05/25

First things first : I'm not the author of the english script. All the credit goes to TLWiki and their incredible work. Apart some changes in line breaks (the space for text is not exactly the same), it's basically the same script for the PC-98 version and the Windows version. Well, except a few chunks of the epilogue ; TLWiki chose to use the script from the Saturn version, that has a few extra stuff and some revisions, for the text to match with the Saturn voices. They still ended up translating and documenting the original PC-98 lines (well, most of them anyway). I personally chose to stick to the PC-98 lines when they were available for more authenticity.

My only slight modifications to the script are something like 4/5 lines translated from scratch (the original translators had not covered the original PC-98 lines in these very few cases), a bit of broken French that has been corrected (I'm a French guy myself) and an infamous Pokemon reference that was removed and replaced by the line used in the english version of the remake. However, nothing was censored or atoned, including the cringiest scenes of the game. Rest assured.

* WHAT'S NEW IN 1.5
- Fixed even more derps. Thanks to the numerous players who sent me screencaps so I could correct them.
- Fixed bad hyphenation and reworked the previously split lines to a cleaner format.
- Optimized and revamped the script format to be cleaner (i.e on par with all my other projects) and facilitate further edits. As a side bonus, the script files are now about 1% smaller.

* WHAT'S DONE

- All text, including the SP disc and the New Game + content, is now in English.
- CGs that were in English in the TLWiki version have been backported.
- The entire game, including the SP Disc/New Game + content have been proofred.

* WHAT NEEDS TO BE DONE

- A few untranslated hardcoded text strings in the SP scenario. We're talking about 5-6 lines that are a serious pain in the ass to process because they basically require to massively hack the main executable just for them. A workaround has been devised by tomyun to display them anyway, but there is a side effect : a missing animation, the one that's akin to what you see in Chrono Trigger when time travelling. Until we've found out another way, that's as good as it gets, sorry.

* WHAT WON'T BE DONE

- All extra stuff from the Windows version : Saturn CGs, voices, SP Disc scenario integrated in the main game. This project will remain as "vanilla" as possible.

*INSTRUCTIONS

First you must extend a clean HDI of the game from Neo Kobe. The file is named "Kono Yo no Hate de Koi o Utau Shoujo YU-NO (with Special Disk) [HD].hdi" and its CRC-32 checksum is 2820FD3C.

Using delta patcher, apply the "yu_no_1_5.xdelta" patch directly on this hdi.

To keep your saves from a previous version, extract the FLAG* files from your existing 1.x patched HDI using Disk Explorer. Reinject them into the newly patched image.

Don't hesitate to report bugs, errors and such on GBATemp or the PC-98/Yu-No discords.

That's it; enjoy !

*CREDITS

Original TLWiki translation
Translation: Phar
Translation Check: Phar
Editing: Spin
Image editing: EchoMateria
Hacking: Kingshriek
Proofreading / QC: Izmosmolnar, KViN, Tsumori, Balcerzak

PC-98 port
Hacking and tools: tomyun
Editing: BabaJeanmel
Image editing: Kaminari
Proofreading and real hardware testing : ShintoCetra