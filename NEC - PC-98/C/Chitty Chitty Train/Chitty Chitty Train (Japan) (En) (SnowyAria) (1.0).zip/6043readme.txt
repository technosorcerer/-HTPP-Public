Chitty Chitty Train v1.0 (April 2021)

Help! The control systems at Chitty Chitty Train Corp have been sabotaged
and the trains are out of control! Only you, the best train operator in
the business, can help us!

# Installation #
## If you have "Chitty Chitty Train [installed].hdm" ##
- You can use the patcher. Just drag and drop 
"Chitty Chitty Train [installed].hdm" onto the file called
"Drag and drop hdm file on me.bat," then the patched game will be created as
"Chitty Chitty Train [installed] - ENG v1.0.hdm"

## Otherwise ##
- You simply need to insert the included "raw_files\TRAIN.EXE" into your game's
files. You may need a tool like "editdisk" to access the files.

# Controls #
- Your goal is to guide your train to each station, which are the buildings labeled
"EKI" with people standing out front, then reach the exit. You must rescue all
passengers for the exit to open!

- If you hit another train or a closed railroad junction, then you lose!

- You can click on railroad junctions to change the track direction. You will need
to use this to guide your train as well as to divert other trains away from you.
Each click uses up one "POINT CHANGE" on the right side of the screen.

- You have a limited amount of "RED SIGNALS" that can be used to temporarily stop
any train for a few seconds, including yours! Use right-click at any time to place
one anywhere on the tracks. The remaining signals are on the right side of the screen.

- By default, your train is on LCL, or Local Train, which means it stops at all
stations. If you click the LCL label, it'll change to EXP, or Express Train. This
will prevent your train from stopping at a station if you don't want to grab
passengers just yet.

# Translation Issues #
All the text in the game is translated, but the game's final text has not been tested
due to the sheer difficulty of the game. If you managed to see the later game dialogue
(there should be two sets) and there's a problem, send SnowyAria a message, preferably
with a screenshot!

# Credits #
SnowyAria(Twitter - @SnowyAria) - Game translation, text insertion
JohnnyFive - Pointer hacking
DragEnRegalia - Playtesting

# Contact #
Have any issues or run into any problems? Feel free to drop by our discord here:
- https://discord.gg/bewGNtm

Alternatively, you can message ArcaneAria on ROMhacking.net or on Twitter at @SnowyAria.