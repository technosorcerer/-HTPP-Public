Cyber Arms Val-Kaizer - English Translation Patch by Alpharobo/Kirinn B/BabaJeanmel
Version 1.0 - 03/14/25

Another short ADV released by Silence, Val-Kaizer is another ADV with high production values. This was supposed to be the first episode of a larger series, but it was scrapped pretty quickly in favor of Guynarock 2 and "Lime". The story itself is nothing stellar, but you'll probably enjoy the animation quality and the banger OST.

The team here is the same as for the other Silence/SGS Projects. The engine isn't actually SGS so Alpharobo had to dig further to allow half-width characters display. The graphics format, on the other way, was the same, so it saved us a bit of time.

Like we did for the SGS games, the translation includes a full recompression of all graphics and animations to squeeze out a few KB, along with a HDD conversion to avoid disk swapping. Timings for CG display have been fine-tuned to compensate for the absence of disk access times.

CONTENT WARNING

Some partial nudity and a couple rape threats. Nothing too saucy here, but it's still better to keep it away from your kids. I'd say it's a 16+ one.

HOWTO
Put the unzipped disk images from the Neo Kobe release in the folder you extracted the patch to, and launch "PATCH.BAT". You'll get an autobootable HDI to boot inside your emulator of choice. If you prefer real hardware, just extract the contents of the HDI and copy the "VKAIZER" folder to your PC-98. Launch the game with VKAIZER.BAT.

Credits
Alpharobo: Hacking, proofreading
Kirinn B: Graphics hacking
BabaJeanmel: Translation, graphics edits
shru: Proofreading