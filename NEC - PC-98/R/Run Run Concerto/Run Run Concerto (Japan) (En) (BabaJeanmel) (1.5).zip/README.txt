RUN RUN CONCERTO English Patch
by BabaJeanmel
Version 1.5 - 06/30/23

Run Run Concerto is an early Elf game, first released for the PC-88, then ported on the PC-98. It's an action game, reminiscent of some very primitive version of Deshing Desperadoes. Except you lead a female runner team and there is a bit of strategy and resource-management involved (not to mention pathfinding for the later levels). Notable for being one of the few eroge that can actually be played in competitive 2 player mode.

This project is a very fast one. The main issue was the lack of space and some nasty hardcoded routines preventing to expand them. You'll have to go with abbrievated names for the runners, sorry. Apart of this, the script was both short and simplistic so it was basically a no-brainer.

As it's an early Elf game, it's completly uncensored. It's also very dumb and light-hearted, so don't expect serious or unsettling stuff like in later games such as Isaku, Yu-No or Words Worth.

CHANGELOG
1.5
- The whole text display system has been revamped. No more ugly fonts and short line breaks in the h-scenes. Now the text displays as every other translated AI1 game does.
1.1
- Added a translated title screen, thanks to Kirinn B.'s graphic reverse engineering! The game title has been changed to reflect that.

HOW TO PATCH

Copy the two disks from the Neo Kobe release (entitled "Run Run Kyousoukyoku") into the patch directory and launch the patch.bat file. You'll get a fully functional HDI file that boots directly on the menu. For real hardware, open the hdi with Disk Explorer or ND, then copy the RUNRUN subdirectory on your hard drive and launch MENU.BAT.

HOW TO RUN

If you play on an emulator, you should use Neko Project FMGEN (np2 variant, not np21 - otherwise the image will be filled with ugly black lines to compensate for the different resolution). Keep the CPU at 1x for accurate timing, or raise it to 2 or even 4x if you find the game to be too janky. The gameplay will grealy benefit from it, but you should then turn the music off to avoid losing your sanity. If you use save states, don't reload a save after finishing a race and viewing the event CG or you might hang the game and corrupt your savegame, which WILL break the game. 

Other emulators (Dosbox-x anyone?) should work too, as long as you emulate an old model or you keep the CPU speed between 8-10 Mhz (or something between 16 and 40 if you want a faster gameplay).

If you play on real hardware, early models (up to the UX I guess) will run the game just fine, but later ones may need to enable slow cpu mode to run the game without issues.

GAME HINTS

- Each girl depletes her "VITAL" meter when she runs. You must not rely to the same ones for each race, or she may run out of "VITAL" and be disqualified.

- Red powerups raise your stats (running speed, jump height or stamina aka recovery time). Blue powerups lower your stats so avoid them. The black ones make your opponent fall.

- You must win two races to be qualified for the next round. If you beat the opponent 2 to 0, you get an explicit h-scene. If you win 2 but lose one, you'll have to content yourself with an ecchi picture. If you lose both races, it's game over.

- Winning every 7 rounds without losing a single race takes you to a special round which unlocks a final h-scene. If you lose this round, you can replay it without having to start the game from the beginning.

That's it. Hope you'll enjoy this great piece of 80's ero-jpc-jank as much as I did !