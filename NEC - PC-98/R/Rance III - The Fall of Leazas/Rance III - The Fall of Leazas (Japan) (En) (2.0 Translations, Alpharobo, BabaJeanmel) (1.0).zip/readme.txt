Rance III - The Fall of Leazas - English Translation port by Alpharobo & BabaJeanmel
V 1.0 - 04/04/24

The third game in the infamous Rance series is probably the best regarded one in the "classic" Rance era. High production values (the CG quality bump is pretty impressive), very good writing and pacing, twice as large as the previous game, with proper top-down RPG style mazes and a nice T-RPG like battle system. My only complaint would be the very low difficulty, but some might enjoy this "casual" feel.

It also was one of the first System 2 games. The thing about System 2 is that it's a real fucking mess, with a lot of variations from one game to the other. It doesn't have as much documentation or mature tools available like System 1 or System 3, because each single game would basically need its own implementation, while the System 3.5 Windows ports are standardized and much easier to deal with. Consequently, we hit a lot, and I mean a LOT of game-breaking bugs while we were working on this game. Kudos again to Alpharobo for the tremendous amount of work he put into fixing everything. And also, thanks a lot to RottenBlock for taking the time to update Sys0Decompiler to simplify our workflow a bit.

Unfortunately, Rance III will be the last game covered by the AliceSoft porting project. Actually we haven't got any means to accurately decipher the script files of the last two significant games that happen to have English scripts publicly available: Rance IV and Toushin Toshi II. So unless there are some further developments in this domain, that's as good as it gets, sorry. Nevertheless, I'd say getting these 6 ports done in little more than a year is still a pretty good achievement for our little project :)

Anyway, back to the translation in itself. The script is the one done by 2.0 Translations, and it's pretty nice, as long as you don't mind Japanese honorifics. It's been left largely unedited, I just added a few exclusive lines present in Alice's Mansion and changed a few menu items that didn't fit into the tiny space available. As for the CG, the translated ones are also backported, along with the uncensored H-scenes from the Neo Kobe release. The main interface and title screen have been remade to better fit with this particular version.

USUAL CONTENT WARNING
Rance is not a nice person. To say he doesn't care a lot with sexual consent would be a big understatement. Even if the game is supposed to be written as comedy, I can't blame you if you find it offensive. So don't play it if you're likely to be offended.

VERSION DIFFERENCE WARNING
You don't actually fight the last boss in the PC-98 version like you do in the Windows one. This last fight, which doesn't even rely on the regular combat system, was probably added as a late bonus in the System 3.5 port. You will not miss much, as it's actually a really annoying section, and the fight with the penultimate boss was a much more satisfying last challenge anyway.

HOW TO
The game is freeware. Download the official digital release from the AliceSoft website: http://retropc.net/alice/menu.html
Copy the patch to the folder you extracted the disk images to and launch "PATCH.BAT". You'll get an autobootable HDI to boot inside your emulator of choice. If you prefer real hardware, just extract the contents of the HDI and copy the "RANCE3" folder to your PC-98. Launch the game with RANCE3.BAT.

CREDITS

*Original translation*
Hacking: Toolbox
Translation and Editing: Tulip Goddess Maria
Graphics Editing: Vodka
Playtesting and Editing: Ludo-Rathowm and Roven-Pan
Technical Help: Sandrio, SomeLoliCatgirl

*PC-98 backport*
RottenBlock: engine hacking
Alpharobo: executable hacking
BabaJeanmel: script insertion, additional translation and editing, additional graphics hacking