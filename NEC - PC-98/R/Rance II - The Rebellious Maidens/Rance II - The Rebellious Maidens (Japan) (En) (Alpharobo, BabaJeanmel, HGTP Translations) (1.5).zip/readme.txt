Rance II - The Rebellious Maidens - English Translation port by Alpharobo & BabaJeanmel
V 1.5 - 12/30/24

Guess who's back to your beloved kyuu-hachi (real one or emulator) just in time for the new year's day? Everyone and their grandmother's favorite rapist scumbag Rance, in another (really) old RPG from 1990!

This game has a pretty circonvulted history as long as fan translation is involved. Its modern remake version, title Rance 02, was translated back in 2011 by HGTP Translations. The script was then backported to the original version's Windows port (using System 3.5) by velt211 and RottenBlock in 2020. Alpharobo and I tackled the original PC-98 version during the end of 2023, and now you can finally play it the way it was intented (or almost, as it was converted from N-BASIC to DOS format by Ryu1 in the 90's, greatly helping the process) 33 years after its release!

Being another System 1 game and part of the AliceSoft Porting Project, this project was made possible by everything we learnt on the game engine while working on the Rance 1 script port. The game is way more ambitious than the first one, even if it remains in the "primitive" category. It's still a quite enjoyable classic in the closed world of oldschool ero-RPGs ^^

The HGTH script is mostly untouched (as it's a decent script to begin with), except for the last chapter that had quite a lot of bizarre grammar and phrasing. I guess these parts were not translated by the same team. I corrected and rephrased a lot of things, but there might still be some badly phrased stuff remaining here and there. As with the rest of the AliceSoft porting project, take it or leave it.

USUAL CONTENT WARNING
Rance is not a nice person. To say he doesn't care a lot with sexual consent would be a big understatement. Even if the game is supposed to be written as comedy, I can't blame you if you find it offensive. So don't play it if you're likely to be offended.

CHANGELOG

1.5 - 12/30/24

Amost exactly one year after the intial patch release, we bring you the most definitive Rance II version ever, thanks to the dumping and archival of the long-lost associated hint disk by arcwil! It includes a few very nice goodies: character and monster encyclopedia, developer talk, and also a strip quiz game and a short, goofy ADV named SD Rance. 

Part of this content had already been retrieved and translated by RottenBlock back in the days by combining data from the MSX and PC-88 releases. The translated script has been reinserted there, and all the missing parts translated from scratch by yours truly. A couple adaptations had to be done (consistency edits, a few differences in the hint section) but it was a pretty fast job to do.

You're now greeted at boot by a menu to choose between the game and the hint disk. By the way, the code you need to enter some sections is given when you finish the game, but if you don't care for spoilers or don't want to go through the whole thing again, here it is: 6782

1.1 - 04/01/24
- Corrected a display bug when you go back from 3 to 2 party members.
- Reduced the filesize of the main script file by 30% and resized the HDI to 7 mb to take profit of this. The script itself is unchanged compared to the 1.0 version.
- Previous saves are not compatible with this version, sorry.

HOW TO
The game is freeware. Download the official digital release from the AliceSoft website: http://retropc.net/alice/menu.html

You'll also need the Rance II hint disk. You can probably retrieve it from a place on the Internet where there's some stuff archived. Pick up the d88 version, and rename it to GDISK.D88.

Put the unzipped disk images from the freeware release along with the hint disk in the folder you extracted the patch to, and launch "PATCH.BAT". You'll get an autobootable HDI to boot inside your emulator of choice. If you prefer real hardware, just extract the contents of the HDI and copy the "RANCE2" folder to your PC-98. Launch the game with RANCE2.BAT or the hint disk with RANCE2H.BAT.

CREDITS

*Original translation (Rance 02 remake)*
Thanatos, w8m: hacking
Zweiterversuch, Soletta: translation
Azathoth: editing
Evilmaycry238, Futurelight, Sysreq623: graphics edits
Gosuoune, Kyou_Kun: proofreading

*Windows version backport*
RottenBlock: engine hacking, translation (hint disk)
velt211: script insertion, editing

*PC-98 version backport*
ryu1: N-BASIC to MS-DOS conversion
RottenBlock: engine hacking
Alpharobo: executable hacking
BabaJeanmel: script insertion, additional translation (alice's mansion, a few hint disk sections) and editing

Special thanks to arcwil for securing, dumping and sharing the long-lost hint disk. You're awesome!