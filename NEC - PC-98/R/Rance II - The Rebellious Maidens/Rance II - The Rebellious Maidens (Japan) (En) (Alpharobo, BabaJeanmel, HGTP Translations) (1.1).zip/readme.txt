Rance II - The Rebellious Maidens - English Translation port by Alpharobo & BabaJeanmel
V 1.1 - 01/01/24

Guess who's back to your beloved kyuu-hachi (real one or emulator) just in time for the new year's day? Everyone and their grandmother's favorite rapist scumbag Rance, in another (really) old RPG from 1990!

This game has a pretty circonvulted history as long as fan translation is involved. Its modern remake version, title Rance 02, was translated back in 2011 by HGTP Translations. The script was then backported to the original version's Windows port (using System 3.5) by velt211 and RottenBlock in 2020. Alpharobo and I tackled the original PC-98 version during the end of 2023, and now you can finally play it the way it was intented (or almost, as it was converted from N-BASIC to DOS format by Ryu1 in the 90's, greatly helping the process) 33 years after its release!

Being another System 1 game and part of the AliceSoft Porting Project, this project was made possible by everything we learnt on the game engine while working on the Rance 1 script port. The game is way more ambitious than the first one, even if it remains in the "primitive" category. It's still a quite enjoyable classic in the closed world of oldschool ero-RPGs ^^

The HGTH script is mostly untouched (as it's a decent script to begin with), except for the last chapter that had quite a lot of bizarre grammar and phrasing. I guess these parts were not translated by the same team. I corrected and rephrased a lot of things, but there might still be some badly phrased stuff remaining here and there. As with the rest of the AliceSoft porting project, take it or leave it.

So, that's one more done. Toushin Toshi and (hopefully) Rance III should follow this year!

USUAL CONTENT WARNING
Rance is not a nice person. To say he doesn't care a lot with sexual consent would be a big understatement. Even if the game is supposed to be written as comedy, I can't blame you if you find it offensive. So don't play it if you're likely to be offended.

CHANGELOG
1.1 - 04/01/24
- Corrected a display bug when you go back from 3 to 2 party members.
- Reduced the filesize of the main script file by 30% and resized the HDI to 7 mb to take profit of this. The script itself is unchanged compared to the 1.0 version.
- Previous saves are not compatible with this version, sorry.

HOW TO
The game is freeware. Download the official digital release from the AliceSoft website: http://retropc.net/alice/menu.html
Copy the patch to the folder you extracted the disk images to and launch "PATCH.BAT". You'll get an autobootable HDI to boot inside your emulator of choice. If you prefer real hardware, just extract the contents of the HDI and copy the "RANCE2" folder to your PC-98. Launch the game with RANCE2.BAT.

CREDITS

*Original translation (Rance 02 remake)*
Thanatos, w8m: hacking
Zweiterversuch, Soletta: translation
Azathoth: editing
Evilmaycry238, Futurelight, Sysreq623: graphics edits
Gosuoune, Kyou_Kun: proofreading

*Windows version backport*
RottenBlock: engine hacking
velt211: script insertion, editing

*PC-98 version backport*
ryu1: N-BASIC to MS-DOS conversion
RottenBlock: engine hacking
Alpharobo: executable hacking
BabaJeanmel: script insertion, additional translation and editing