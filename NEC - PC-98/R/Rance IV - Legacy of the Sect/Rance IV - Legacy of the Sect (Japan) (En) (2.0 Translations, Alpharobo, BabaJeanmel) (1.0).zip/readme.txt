Rance IV - Legacy of the Sect - English Translation port by Alpharobo & BabaJeanmel
V 1.0 - 10/04/24

With the latest Sys0Decompiler release (courtesy of Rottenblock), the AliceSoft porting project has been resumed! The latest release is obviously the 4th main Rance game, which is also the only one that hasn't been remaked yet.

Rance IV is a bit of a mixed bag. On the good side, the game has awesome production values (256-color graphics were real cutting edge technology at the time) and great additions to the lore. On the bad side, the game is badly balanced, the sprites blink like crazy, and the dungeon navigation is pretty clunky. IMO Rance III is still the superior game, but IV deserves all your attention if you're a fan of the series.

Also, it's pretty obvious Merim is best girl, but it must be mentioned anyway.

The script, along with the localized CG, was made by 2.0 translations back in 2013. A few lines exclusive to the PC-98 version (specific menus or technical info in Alice's Mansion) have been done from scratch for this specific release. A bit of editing has also been done to fit some location or spell names into the menus and/or avoid display issues (so "Hellfire Conflagration" is "Inferno" and "Youth League Office" is just "Youth League" now, among a few other minor changes)

The two short companion games, Rance 4.1 and 4.2, will be the next (and last, until Toushin Toshi 2 data format has been figured out) games covered by the AliceSoft porting project. They're planned to be released simultaneously. I'd love to bring the option/hint disks for Rance III and IV as well, as they include a few nice bonus games, but there are a couple bigger projects to take care of before.

USUAL CONTENT WARNING
Rance is not a nice person. To say he doesn't care a lot with sexual consent would be a big understatement. Even if the game is supposed to be written as comedy, I can't blame you if you find it offensive. So don't play it if you're likely to be offended.

HOW TO
The game is freeware. However, as applying the patch needs a preinstalled game installation and doing it manually can be pretty tedious (especially if you don't understand Japanese at all), it doesn't use the original floppy disk images but targets the Neo Kobe hdi image (CRC32: 966558B7) instead. Just apply the xdelta patch to it using deltapatcher. If you're using real hardware, extract the contents of the patched HDI with DiskExplorer and copy the "RANCE4" folder to your PC-98. Then launch the game with RANCE4.BAT.

CREDITS

*Original translation*
Hacking: Toolbox
Translation and Editing: Tulip Goddess Maria
Graphics Editing: Vodka
Playtesting and Editing: Roven-Pan
Super Hacker: SomeLoliCatgirl

*PC-98 backport*
RottenBlock: engine hacking
Alpharobo: executable hacking
BabaJeanmel: script insertion, additional translation and editing