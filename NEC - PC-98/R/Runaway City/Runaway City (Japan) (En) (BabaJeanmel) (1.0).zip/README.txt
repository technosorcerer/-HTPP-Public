JAST Memorial Collection PC-98 backport project
By BabaJeanmel/Kirinn B/Alpharobo
Version 1.0 (2022/12/02)

These patchs will insert the script and the translated graphics from the english JAST version of these three games into the japanese PC-98 versions. Menus will also be translated, as well as your MC's name.

There's also a brand new translated title screen for Season of the Sakura and uncensored CG for Runaway City (the other two games already were uncensored).

HOWTO

All patches are in xdelta format. Just use deltapatcher to apply them.

Use the "Runaway City" patch on the "Meisou Toshi (HD)" hdi from the "Tiare" subdirectory of the Neo Kobe PC-98 collection. (CRC32: F46E94FB)

Use the "Season of the Sakura" patch on the "Sakura no Kisetsu (HD) (Uncensored)" hdi from the "Tiare" subdirectory of the Neo Kobe PC-98 collection. (CRC32: 3E4F80FC)

Use the "Three Sisters Story" patch on the "Sanshimai (HD) (Uncensored)" hdi from the "Jast" subdirectory of the Neo Kobe PC-98 collection. (CRC32: 5B84EB0D)

Here is a listing of known bugs and limitations of these english versions:

ALL GAMES
- Because of space limitations, the menus have been cut off a bit. So they're not completely accurate to the original JAST versions.
- I don't know how to access the Omake content (is it even possible, or just a leftover?), and I don't want to mess with it blindly, so it's left untranslated.
- Previous savegames left in the Neo Kobe dumps have been removed so you can get a fresh start.

SEASON OF THE SAKURA
- The game crashes after the end credits (already did in the original Neo Kobe HDI)

THREE SISTERS STORY
- The intro text had to be severely cut off because of space limitations. Fortunately, the cut parts, such as the MC pretending to have his parents living abroad, or the way the MC's father commited suicide are all mentioned one way or the other at the beginning of the game.

That's all. Enjoy !

CREDITS
Original english script by JAST USA
Alpharobo : Hacking
Kirinn B. : Graphics Hacking
BabaJeanmel : Text & graphics editing