------------------
RUSTY BUTT FIX 1.0
------------------

Patch Instructions
------------------
This patch currently only works on the floppy disk version of the game. 

You will need to use an xdelta patcher. Here are some examples if you don't know which to use:

Delta Patcher for Windows  https://www.romhacking.net/utilities/704/
Multipatch for Mac  https://www.romhacking.net/utilities/746/
YADP for Linux  https://www.romhacking.net/utilities/1159/

Apply the patch to the third game disk labeled "Rusty (Game disk C).hdm". It should work even if the game already is patched with 46 OkuMen's English translation (https://www.romhacking.net/translations/2997/) since the English patch doesn't change that particular disk. Be sure to backup the original disk though before applying the patch just to be safe.

And that's it, enjoy! 


About the Fix
------------------
The patch fixes one of the last images from the ending of the game to give you a better view of Rusty's butt. It replaces the original image with an expanded image I made that shows the rest of her butt below the point where the original image cut off.

It was made possible thanks to an idea suggested in a /pc-98/ thread on 4chan's /vr/-board. A big thanks to the awesome anonymous user there who beat the whole game, giving me a save state file so I could test the new image.
