Rance - Quest for Hikari - English Translation port by Alpharobo & BabaJeanmel
V 1.0 - 10/28/23

Now we're talking. Here's what everybody and their grandmother have been waiting for: the return of the most infamous eroge series ever, in English, back to its original iteration!

For the third step of the AliceSoft porting project, we bring you Rance - Quest for Hikari. The script used is the one from HGTP Translations, save for a few menu-related lines and the "Alice's Mansion" part (the PC-98 text is exclusive to this version, and has been translated from scratch). I have made no edits in the original 2010 HGTP script; that means the references to Street Fighter and the un-accurate quizz section are still there, and that all the translation and/or grammar errors have been left untouched. As with all our script port projects, take it or leave it. As far as I'm concerned, I still find it pretty decent.

Needless to say, if you want a better experience, you can play the remake; the new script and the new english translation coming with it are both top-notch and the mechanics have been upgraded quite a bit. But if you like your localized eroge in full 16-color dithered glory and all the jank coming with it, the HGTP version is pretty much your only option, sorry.

The script has been backported from AliceSoft's System 3.5 back to System 1.0 ; that meant a tedious work of relocating data, especially for the menu part. The dialogues were a lot easier to reinsert, fortunately, so after passing the 10% landmark, things went pretty smoothly, until we reached the first playthrough and its debugging. There were quite a lot of bugs to iron out, both because of the data format conversion issues and my own idiot mistakes, but Alpharobo made wonders as always, so it turned out pretty good in the end.


USUAL CONTENT WARNING
Rance is not a nice person. To say he doesn't care a lot with sexual consent would be a big understatement. Even if the game is supposed to be written as comedy, I can't blame you if you find it offensive. So don't play it if you're likely to be offended.

CHANGELOG
1.1 - 01/05/23
- Reduced the filesize of the main script file by 30%. The script itself is unchanged compared to the 1.0 version.
- Previous saves are not compatible with this version, sorry.

HOW TO
The game is freeware. Download the official digital release from the AliceSoft website: http://retropc.net/alice/menu.html
Copy the patch to the folder you extracted the disk images to and launch "PATCH.BAT". You'll get an autobootable HDI to boot inside your emulator of choice. If you prefer real hardware, just extract the contents of the HDI and copy the "RANCE1" folder to your PC-98. Launch the game with RANCE1.BAT.

That's all for now; stay tuned for Rance 2's PC-98 release in early 2024!

CREDITS

*Original Version*
Toolbox: hacking
Zweiterversuch, Solletta: translation
Futurelight, Azathoth, The Rogue trader, Phillullis, Nick Sawatsky: editing

*PC-98 port*
ryu1: N-BASIC to MS-DOS conversion
RottenBlock: engine hacking
Alpharobo: executable hacking
BabaJeanmel: script insertion, additional translation