Holy Girl Force Lakers
Translation patch 1.1 by BabaJeanmel - 09/21/22

Lakers is a cool T-RPG series, which has some sort of cult following. Imagine a mix between Sailor Moon-type magical girl anime and super sentai flicks, with the addition of a strong amount of booba. Sounds awesome, right? Anyway, working on this trilogy was my first PC-98 project; it spawned three menu patches and a meme, so I could see it an as an achievement in itself. But a year's worth of tireless Anki drilling and the welcome support from competents text and graphic hackers motivated me to do what everybody wanted: fully translate these games, starting with the first one. So, rejoice, here it is !

Oh, yeah. The second (and best) game will be worked on after I'm done with my backlog. (two more projects ongoing, whoo-hoo!)

Also, sorry for all you Natsune fans out there, but Yayoi's best girl. Don't underestimate her.

ABOUT THE PATCH
There are a lot of corrections over the previously released menu patch : a few missing strings, replacement for some poorly chosen terms ("Spread" replaced by "Span" or "Sawcutter" by "Slicer" for instance), some typos fixed, some technique names changed for consistency with the other two games, more precise and less crude options for sex scenes (no "DON'T" here, sorry), and finally the removal of all traces of the OAV ("Battle Team Lakers") existing localization, hence the change of title.
Feel free to report any bugs or errors you might encounter to me. I'm hanging around on PC-98 discord, but you can also find me on the GBATemp forums.

As for the story (event and h-scenes), you'll be soon to notice it's not a state-of-the-art writing achievement, but what the hell. The script is fun, makes use of almost all the tropes you can think of, and doesn't takes itself seriously the slightest. Anything you would expect from a porn 90's T-RPG!

CONTENT WARNING
There are two rape scenes in this game, one of them being perpertrated by your MC, under mind control. The other one involves some tentacles, as this should be expected for this kind of game in this era. Those were the times.
So let's get things straight right away: I'm not responsable for the writing of these scenes, they happened to be in the game, and I didn't want to censor anything. If this kind of stuff makes you uncomfortable, do yourself a favor and don't play the game. And as a matter of fact, you should stay away from most of the 90's eroge, there is some way worse stuff than that, I can guarantee it...

CHANGELOG FROM 1.01
Apostrophes now display properly, thanks to some reverse engineering by Alpharobo. It looks way more polished now! And BTW, the upcoming Lakers 2 patch will have the same fix :)

HOWTO
Apply the xdelta patch to a clean Neo Kobe "Sei Shoujou Sentai Lakers" hard disk image in the hdi format (CRC32: B9E4FA54).

The full game has been confirmed to run on orginal hardware (just copy the "LAKERS" folder from the translated image on your hard drive). There's a freeze that may occur during the second battle of the last chapter after a certain event, but the game recovers from it alone. It was also present in the original version. Make sure you save often just in case!

CREDITS
Hacking and tools: Alpharobo
Gaphic hacking/tools/conversion: Kirinn B.
Translation: BabaJeanmel
Title screen: Anata
Proofreading/Real hardware testing: LowDefAl, Speedynoelle, ShintoCetra

Special thanks to tomyun, Kaminari, Pasokon Deacon, GangFight, Ryo-Cokey, Thanys and all the fine PC-98 Discord community, along with the Tokugawa Corp. forum members.