Holy Girl Force Lakers II
Translation 1.1 by BabaJeanmel - 10/13/22

NOT TO BE REDISTRIBUTED ON RHDN. Thanks.

Okay, here it is. Second game of the trilogy, and by far the best one. Lakers 2 improves almost everything over the first episode, including the girls' breast size. More seriously, it's a nice game with a pretty elaborate equipement/technique system. It's also way longer and more challenging, and the production values are better.

Anyway, it was a longer and more challenging project than my previous one. As a matter of fact, it's my most ambitious one so far! Fortunately, the same talented people who worked with me on the first game (Alpharobo, Kirinn B, Anata and LowDefAI) were back there, and they did a damn fine job. I hope you'll enjoy the result of our efforts!

Oh, and by the way. Yayoi is still best girl. No discussion there.

DISCLAIMER
People maintening fullsets here and there, please remove all prepatched HDIs that include the previous menu-only patches (labelled "Battle Team Lakers II" or "Holy Girl Force Lakers II" v.0.x). I don't want them to collide with the new one.

ABOUT THE PATCH
The translation is built on top of the previous 0.4 menu patch (the latest revision, previously available on GBATemp only). At this point, it had already been harmonized with the Lakers 1 translation for consistency, and all the graphical edits had been done.
Feel free to report any bugs or errors you might encounter to me. I'm hanging around on PC-98 discord, but you can also find me on twitter and GBATemp forums.

You'll be soon to notice the script is even dumber than in the first game, even if it can get a bit darker at times. Cringey catchphrases, bizarre sex metaphors, Jojo-esque over the top dialogue, cliche as hell plot devices, you got it all. And damn, this is SO good. Some people may call it bad taste, but I call it great fun.

RESTORED CONTENT
Half of chapter 7 was present in the game files but did not play when it should. In fact it didn't play at all, leaving a big plot hole where two event scenes and a full battle should have taken place. It might be a problem with the dump of the game circulating, or just a derp in the retail release that somehow survived the testing phase. Anyway, thanks to Alpharobo, the missing part of chapter 7 is now restored!

SPECIAL GAMEPLAY NOTE
Clicking on "Weapon name" in the tech menu lets you choose the special techniques (secondary weapons on your equipment, which use these SP points you get each time the enemy attacks you). It's not specified either in the original menu, it's the kind of info you'll just need to read the manual to know. And trust me, some of these techniques are almost mandatory in specific parts of the game (like Akira's Bladdard Spark for chapter 7).

CONTENT WARNING
Like in the first game, there are two rape scenes (looks like we got a pattern there). Well, to be correct, a "full" rape scene and an "attempted" rape scene where your MC is the perpetrator. Yep, classier as ever. So don't play the game if this kind of stuff grosses you out.
The rest of the sex scenes is pretty vanilla, if we expect the writing that is pretty out-of-this world (pang pang, anyone?)

HOWTO
Apply the xdelta patch to a clean Neo Kobe "Sei Shoujou Sentai Lakers II" hard disk image in the hdi format.
You can also edit your disk image with DiskEdit and insert the files from the "FILES" subdirectory into your "LAKERS2" folder, overwriting files in the process.
Warning: previous savegames WILL be corrupted if you update the files manually. If you already have saves, just start a new game and overwrite them.

If you want to play the japanese version with the extra content, just use the  lakers2-restored-jp.xdelta patch from the EXTRAS folder instead. It includes a couple of minor bug fixes, too.

The full game has been confirmed to run on orginal hardware. Just copy the "LAKERS2" folder from the translated image on your hard drive.

CHANGELOG
The 1.1 version fixes a crash after the second chapter 7 battle, before the H-scene. Everything should be working properly now. Sorry for the inconvenience.
you can manually update your game by injecting the S07_006.BIN file from the "FILES" folder into a patched 1.0 image's "LAKERS2" folder. It won't affect your savegame.

CREDITS
Hacking and tools: Alpharobo
Gaphic hacking/tools/conversion: Kirinn B.
Translation: BabaJeanmel
Title screen: Anata
Proofreading/Real hardware testing: LowDefAI

Thanks again to all the people involved in this project for their incredible work. You're all awesome!