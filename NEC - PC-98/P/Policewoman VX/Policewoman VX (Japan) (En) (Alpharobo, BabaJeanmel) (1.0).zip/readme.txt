Policewoman VX - English Translation by Alpharobo & BabaJeanmel
V 1.0 - 04/10/24

After completing (sort of) the AliceSoft porting project, there still was a pretty mature toolset at our disposal, and countless AliceSoft games that were left untranslated. So naturally, we moved on to make new ones! Here is the first, albeit modest, original (ie not backported) AliceSoft PC-98 translation ever: Policewoman VX.

This game was originally a bonus game embedded with the original Rance release. At the time it was text-only, but a couple years later a CG version was offered to the ALICE-NET BBS members. That's the version that Neo Kobe preserved, and that we choose to bring you. It's ridiculously short (about 10 minutes of gameplay), but for those who like diving into Bishoujo history, or just AliceSoft fans, you might find some enjoyment in it. Expect other small treats like this one in the near future :)

CONTENT WARNING
An attempted rape scene, and a couple naked girls partly covered by the image borders. Nothing really explicit in this one, but still would qualify as PG-16.

CULTURAL NOTE
There are a couple jokes (one explicit, the other implied) about the "Recruit scandal". It's actually a politico-financial corruption scandal that occured in 1988. Check Wikipedia if you want some details.

HOW TO

This game, unlike most of AliceSoft's early input, is not available for download on their site. You must use deltapatcher to apply the patch on the Neo Kobe dump (Fukei-san VX (CG Version).hdm - CRC: 76F3CDA8).
If you want to play it on real hardware, you can either copy the contents of the hdm to a blank floppy, or just the "FUKEI" directory to your harddrive, and launch it with "FUKEI.BAT".

CREDITS

RottenBlock: engine hacking
Alpharobo: executable hacking
BabaJeanmel: translation, script insertion