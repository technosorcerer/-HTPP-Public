Alpharobo presents:

Slayers (PC-98)
English translation patch ver. 1.0

Thank you for trying this english translation patch for Slayers on the PC-98. The project was based on the work originally started by Filler and EsperKnight in 2006, with translation work by Eien ni Hen in 2012. After a long period of silence, I reached out in 2024 and offered my assistance in completing the work on the hacking side and pretty much ran from there. I had a lot of fun working on this and am very excited to get it in the hands of players! Enjoy!

Instructions:
This translation patch can be applied directly to the hard drive image available in the Neo Kobe pack on archive.org. Apply it with a standalone application like xdelta or xdeltaUI, or search online for an online ROM patcher.
original file: Slayers.hdi
SHA-1: FD77AE14C12E3E2A4E6D26BE487C3F0B4A65AE46
CRC32: 1AA9E5BA
patched file
SHA-1: D5BAFA003B409D8AD352432FB9F164FF2665FB95
CRC32: C0A35346

If you are using a different hdi image or floppy images, you can copy the individual patched files from the patched files folder over their original counterparts. There are extra cutscene scripts and texts over the original due to having to split some of the cutscenes. Be sure to include those in the appropriate folder/disk with their like counterparts, i.e.X111 in the same place as X110.

Credits:
Original project: EsperKnight, Filler
Initial tools and Script Dumping: Guest
Cutscene Translation: Eien ni Hen
Game Text Translation Filler
Additional Script Extraction: Alpharobo
ASM Hacking: Alpharobo
Graphics tools: KirinnB
Script Editing: Alpharobo
Playtesting: duglis, BabaJeanmel, JackDBS, Kanji, shintocetra, shru, AnnK
Special thanks: Shansito, whose website guide made playtesting the game a whole lot easier. If you get lost in the game, check out: www.lost-slayers.net/juegos/pc98.php

Bonus notes:
The game contains restored cut content in the form of the "Adult Shop" in town (don't worry, it's not exactly what it sounds like). The graphics intended for this scene are missing from the disk, so the black screen and glitched dialog portraits are unfortunately expected, but it is fully functional for what it does. Maybe save your game before trying it out, though...
