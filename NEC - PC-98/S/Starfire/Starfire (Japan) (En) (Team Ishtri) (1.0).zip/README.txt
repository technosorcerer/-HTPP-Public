Starfire
English Translation v1.0
by Team Ishtri

***********************
  GENERAL INFORMATION
***********************

Starfire is an action RPG for PC-9800, initially designed by Winston Douglas Wood (of Phantasie fame) and developed by StarCraft Inc. as a successor to Star Command. The game underwent major changes during the development and eventually became a more straightforward dungeon/space shooter RPG running on the Might & Magic 3 engine.

In this game, you are a member of a mercenary squad of infantry mechs contracted by the government to do dirty jobs. Eventually you gain access to a space ship and travel the galaxy to deal with an alien invasion.

The project started in 2020 when the original designer (Winston Douglas Wood of Phantasie fame) admitted during the Matt Chat interview that he never played Phantasie IV and Starfire when they came out in Japan.


This English translation is for Starfire on NEC PC-9800.
Support for both 16 & 256 color versions of the game are available.
Neko Project 21/W version was used in running and testing of this game and is recommended for play.


*****************************
  INSTALLATION INSTRUCTIONS
*****************************

1. Patch original Starfire HDI file matching the hash values below with only 1 of the patches (16 or 256 color). You can't apply both patches to the original file due to space issues so either only select one or make 2 seperate versions from the original file.

Starfire (Original).hdi
CRC32: 868F0FBD
MD5: DE727F5591A2B4DD170F99B4179A7338
SHA-1: E75322C5A67E64BEF27E1DB673D996799B7E545E

2. Enjoy the game!

*****************************************
  IMPORTANT INFORMATION & GAMEPLAY TIPS
*****************************************

1. Save often. Make sure create a separate save upon the first arrival on Bunjiki IV.

2. Difficulty spike near Bunjiki IV.

The game has a nasty difficulty spike here due to inability to repair your ship, except for special events, like upgrades or boarding enemy ship.

Until you beat the Camelot battle, you'll only be able to upgrade it ONCE. Avoid using any other terminals until you're low on shield points.

Save often, reload the save if you're too damaged after the battle and try to beat it again. Reduce the CPU clock speed to make the enemies bearable.

If you have less than about 15 shield points, DO NOT go to the Camelot system if you don't want to get crushed by enemies.

Don't worry, the game is a smooth ride after this moment. Our theory is that the developers cut an important event from the Viland system, which would fix the player ship afterwards.

3. Before delving into the Sol system, make sure you've upgraded your ship and tuned up your Motor Shell / strengthened your cells / stocked up on Repair Units, Repair Kits, and medical supplies. You'll need them.

*******************
  TROUBLESHOOTING
*******************

Q: I've installed the translation, but the game shows the big red window with Japanese text upon launch, and then crashes...
A: This happens when there's not enough free space on your HDD. Please remove any unnecessary files and try again.

Q: The enemy ships fly too fast and enemies attack too frequently...
A: Lower the clock speed of the emulated CPU. Also, try attacking enemies from the distance, since their speed seems to be linked to the distance from the player character.

***********
  CREDITS 
***********

Team Ishtri

Hacking:

	kinezumi
	MrRichard999

Translation:

	TheMajinZenki
	AgentOrange
	Shinto-Cetra

Consulting:

	Xeen Music

Tool Authors:

        Cedric Busch - Creator of Xeen CC Packer http://games.playazlounge.net/   

***************************************
  TRANSLATION TEAM NOTES AND COMMENTS
***************************************

kinezumi:

	I was intrigued by Phantasie IV and Starfire for quite some time, but after hearing the story behind their development from Winston Douglas Wood and that he never got the chance to play them, I've decided to take the matter into my own hands and convinced Richard to help me with this.
	
	Now you can play this game for the first time and see the final project released by StarCraft Inc.
	
	The translation was initially implemented by decrypting and modifying the CC file directly, but after an unfortunate incident with file corruption, we've learned about the alternative way to override the files from Xeen Music.
	
	I would like to thank everyone who contributed to this project, and I hope we can translate Phantasie IV next.

MrRichard999:

	Kinezumi asked about working on the game in the past and I was always a fan of the Might and Magic Xeen games and part 3 so it really hit a nostalgic spot. We tinkered around with tools used to edit Worlds of Xeen which gave us some insight into modifying the game.

	Unfortunately it wasn't perfect with reinsertion due to it being a completely different game but kinezumi was able to work it out and we used Xeen CC Packer to extract a majority of the text thankfully!

	Things progressed greatly afterwards and it came together very nice! I am thankful to the translation team as if it weren't for them, this would have never been done! 