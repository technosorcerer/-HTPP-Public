V.G. - Variable Geo- English translation by Harry Johnson and Valley Bell

V1.0- Initial release 2/8/2025

The (in) famous fighting waitresses are finally making a comeback onto everyone's favorite retro computer but this time, in English for the first time ever.

Get ready to serve up some cans of whoopass as attractive 90s anime waitresses that are representing parodies of real life Japanese restaurants along with excellent music and some S tier art by the great Takahiro Kimura (R.I.P)   

This particular translation is machine translated but some of the text was cleaned up and modified to read more naturally and to add back in some of the termonology that's used in the world of Variable Geo and to correct some of the character names and some other oddities in the text that we could catch.

USUAL PC-98 CONTENT WARNING
As par for the course with the PC-98 and other Japanese PC's of the 80s and 90s, this game has very explicit adult content of an extreme nature such as:
Noncon 
Watersports (Squirting or urnination? The liquid is clear, so it's pretty hard to tell)
Mild blood during both of Reimi's H scenes from her being wrapped by thorned rose vines
Bondage/BDSM  
Sexual Humiliation
Tears and other generally unplesant H imagery.

PLAYER DISCRETION IS HIGHLY ADVISED! THIS GAME HAS CONTENT THAT CAN BE VERY TRIGGERING TO SOME PLAYERS! There's an optional SFW patch that removes all of the H content, but keeps the character intros. We're aware that the original game had the option to remove the H content by turning the "GRAPHIC" setting off in the Options menu, but it removes the character intros before each match.

WHAT'S TRANSLATED:
The win and lose text after each match for every character
All of the H scenes
Endings for each character
Messages when exiting the game and when your PC-98 isn't set to the proper GDC Clock

WHAT'S NOT TRANSLATED:
Title screen
Some Japanese text that's in the options menu because neither of us couldn't figure out the graphics format that V.G. uses as TGL/ GIGA's games are notorius for the graphics being in weird formats.
Miscellaneous graphics that contain Japanese text in the stages and on the character select screen.

HOW TO APPLY PATCH
A copy of Xdeltaui is included with the patch
Make sure you have an HDI file for V.G. - Variable Geo (It has to be the one from the Neo Kobe set)
Only one patch can be used at a time per HDI so please only choose one (Either VG-ENG-MTL or VG-ENG-MTL (SFW)) 
Use Xdelta to apply the patch of your choice that's included with the ZIP to the HDI
Load it into your favorite PC-98 emulator and start serving up some whoopass

CREDITS: 
Harry Johnson: Translation, Proofreading, Playtesting
Valley Bell: Hacking, Proofreading, Playtesting

Please report any bugs/glitches/errors to Harry Johnson or Valley Bell

TOOLS AND REFERENCES USED:
Google Translate
OpenAI ChatGPT 4.0- https://openai.com/chatgpt/overview/
Variable Geo Wiki- https://variablegeo.fandom.com/wiki/Variable_Geo_Wiki
Wikipedia page on Variable Geo- https://en.wikipedia.org/wiki/Variable_Geo
Variable Geo OVA ADV Films english dub (For some of the termonology)
Valley Bell's hacking tools for the game- https://github.com/ValleyBell/PC98VNResearch/blob/master/z_misc/README.md

SPECIAL THANKS AND GRUDGES

Special thanks to: 
Takahiro Kimura- for designing all of these characters and having massive roles in a bunch of other excellent Video games and Anime 
Rest in Power, Kimura. May 19, 1964 - March 5, 2023 (aged 58)

Takahiro Yonemura (CHEMOOL)- for composing the amazing OSTs that are in Variable Geo and a bunch of other video games.

The rest of the team that work or have worked at TGL/ GIGA

The PC-98 Community Discord server- for the words of encouragement and helping with some of the translation

Valley Bell- for helping this fan translation become a reality with their amazing hacking skills

GRUDGES

Danielle (Harry's sister)- FUCK YOU, DANIELLE! YOU STILL OWE ME $50,000 FOR SELLING MY ENTIRE VIDEO GAME AND POKEMON CARD COLLECTION NEARLY 8 YEARS AGO. AND YOU HAVE THE AUDACITY TO TELL ME THAT YOU LOST THE STORAGE UNIT, KNOWING FULL FUCKING WELL TOU TOOK EVERYTHING AND SOLD ALL OF IT TO SUPPORT YOUR HABIT! WELL GUESS FUCKING WHAT! YOUR BS IS BEING CALLED OUT IN A README FILE OF A TRANSLATION OF AN OBSCURE EROGE ON AN OBSCURE PC FROM JAPAN!
