Holy Girl Force Lakers 2
Translation 0.3 by BabaJeanmel - 05/05/21

This little menu patch should be enough to help you play this great PC-98 ero-t-rpg that has some sort of a cult following. Of course, if you're over 18.

A full translation is planned, but in the meantime, I thought this patch could use a small maintenance update! Most changes won't appear on previous savegames, sorry. You must start a new game to see them.

WHAT'S DONE
- Main menu
- Character profiles
- Save/Load dialogue, including inbetween levels
- Ingame system menu and all relevant options, such as mission objectives.
- Character names (both allies and ennemies) and techniques
- Upper right status dialog (with terrain effect, remaining actions etc.)
- Confirm dialogs (for movement, direction, equipment...)
- Sex scene choices
- Extras menu is fully unlocked from the start

WHAT'S REMAINING TO DO
- Event/H scene dialogue
- Battle dialogue

CHANGES IN 0.3
- Version renumbering.
- Changed title from "Battle Team Lakers" (from the shitty OVA) to the more faithful "Holy Girl Force Lakers".
- Lots of corrections and consistency changes in enemy/techniques names. Should be harmonized with the forthcoming Lakers 1 translation.
- Some menu text that was in graphical form (equipment menu, down-right corner of battle screen) has been edited thanks to Kirinn B.'s reverse engineering of the image format. That's right, all menus are now completely in english!
- I'm no longer doing a "don't" edition. Feel free to edit it back (in sex*.bin files) if you want it so badly.

NOTES
- Reiko's last name is "Kagurazaka" according to the game, and "Kagurasaka" according to the artbook. I chose to keep "Kagurazaka".
- Sex choices are written in cruder language than the original... because there's not enough room to use less offensive terms. But, hey, this is an eroge after all, so if you play this, I guess you need more than crude language to be offended.
- Clicking on "Weapon name" in the tech menu lets you choose the special techniques (secondary weapons on your equipment, which use SP points). It's not specified either in the original menu, it's the kind of info you'll just need to read the manual to know.

HOWTO
Apply the xdelta patch to a clean Neo Kobe "Sei Shoujou Sentai Lakers II" hard disk image in the hdi format.
Or you can also edit your disk image with DiskEdit and insert the files from the "FILES" subdirectory into your "LAKERS2" folder, overwriting files in the process.

SPECIAL THANKS

Anyone who helped with the broken german text (Natsune's techniques). Danke schön, guys.
Kirinn B. for his awesome graphical extract/insert tools.
The fine people of the PC-98 Discord, Tokugawa Corp. and the /vr/ PC-98 anons.