Shangrlia 2 - English Translation Patch by BabaJeanmel
Version 1.1 - 10/30/23

Shangrlia 2 is a very nice T-RPG by Elf, with a pretty unusual unit managment system and a fair challenge, not to mention a great art direction. It's a big improvement over the first game in the series, that is both really barebones and of brutal difficulty. The story, however, is still pretty much shit, but who cares. The game is still cool as fuck, and even if it doesn't offer as much as Metajo, Dead Force or Last Guardian, it's a solid addition to the PC-98 T-RPG library.

A menu patch was released some time ago, while I was working on the first half of "Lime". I was not planning to do much else, but the short size of the script made me reconsider. However, don't expect good writing there, or even actual writing at all. Save for half of the introduction, 4 lines before fighting the last mission, and a very short ending, there's nothing but (very cringey) h-scenes. Translating them was honestly the most boring thing I've ever done in three years of PC-98 hacking/translation, but oh well. Maybe you'll find some kind of enjoyment reading them if you're not too picky about your digitalized porn. Thanks again to Kirinn B for proofreading the whole thing and motivating me to actually finish it!

Usual content warning: there are two S&M rape scenes in this game. One is just fantasized by your MC, while he actually performs the second one as punishment on one of the female generals. So yeah, that's pretty fucked up, and pretty much contrary to all rules of both decency and good taste. As always, I haven't censored anything; so just don't play the game if you find this kind of stuff offensive.

This patch has been made possible by tomyun's inestimable work on the Elf AI1-5 engine. Not to mention Alpharobo's superhuman hacking skills that allowed him to fix the last and most annoying bugs.

CHANGELOG
- The text width has been fixed for the first three generals. The font width command was ignored for them, except the one you rescue first.

HOWTO
Apply the patch to the Neo Kobe HDI version. For real hardware users, just copy the contents of the "SYAN2" folder to your hard drive after patching.

Just to make things clear, I don't have any plans to translate the SP disk. I have other more motivating to stuff to work on :)

Credits:
tomyun: hacking and tools
Alpharobo: additionnal hacking
BabaJeanmel: translation, graphical edits
Kirinn B: proofreading