Dead of the Brain ~Cry of the Dead~
By WINE
Version 1.0

This patch translates the PC-9801 version of Dead of the Brain ~Shiryou no Sakebi~.

FAQ
1. Why does this patch exist? Doesn't a patch for the PC-98 version already exist?
	Yes, there is a patch for the same version of the game, which was released in 2019 by Retronomicon.
		However, it's known to be buggy in its original state, and uses machine translation.
		Not only that, but it makes a lot of weird changes to the script, which even the creator stated to be true.
		This version was made to have a new version for people to play, in a better, more accessible state.
2. How closely related to the Retronomicon patch is this?
	Now, this patch is based off that, but as I said, it's a full overhaul.
		The Retronomicon patch was revised twice by cuba200611 and BabaJeanmel a while ago.
		These two patches were made to fix bugs and compile the game into 1 hard drive file, instead of 4 floppies.
		The dirty work here was already done, so I decided to go with that version instead of the original floppies, which would've taken longer to complete.
3. Will the other versions be patched like the X68000 and MSX versions?
	The X68000 version is being worked on by trentsignia and me, and will be completed shortly after Halloween, hopefully.
		For now, there's going to be a trailer patch, which translates about a 1/3 of the game.
		For the FM Towns version, it's in the works. It'll take a bit longer due to compression that needs to be worked with.
		For the MSX version, absolutely not. Worst version of the game. Doesn't deserve a patch.
4. Will you be doing "Nightmare Collection II: Marine Philt" or "Dead of the Brain 2" after this?
	No. There are no plans to translate either game.
		In Marine Philt's case, there seems to be some weird text scroll thing that has to be figured out.
		In DOTB2's case, CrookerWine hates the game, so she doesn't want to translate it.
		The guy doing the PC Engine translation of DOTB1&2 may do it though.
		If you want to translate it, either do it yourself (as the tools are around on the internet), or just contact either me or David Shadoff.
5. Is this the same script as the PC Engine translation that just came out the same day as your patch?
	No. Me and David Shadoff spoke in Twitter DMs mainly about character names, but that was about it.
6. Why is there some spacing at points later in the game?
	Workaround so the game doesn't crash.
7. The text speed is so slow. What do?
	Go into the options, click MESSAGE SPEED, and you'll be on HI-SPEED.
8. The font looks weird and nigh unreadable. What do?
	Yeah. That's the default PC-98 font for ASCII.
		Go on the internet, look up "PC-98 Font", and go looking. Neko Project 21 should have a "Font" option in the "File" section.
9. Does the game work on real PC-98 hardware?
	I hope so! We didn't do any real hardware testing on this game, but if you have trouble on real hardware, contact me.
10. I'M STUCK AHHHHHHHHHHHHHHHH
	Yeah, the game wants you to check and look at everything on screen, welcome to 1992.

HOW TO APPLY THE PATCH:

1. Download "Dead of the Brain [FD].zip" from Neo Kobe in the "Fairytale" section.
2. Use an XDelta patcher to apply the patch on the "Dead of the Brain (Disk A)".
3. Name it whatever you want, BUT MAKE SURE YOU MAKE IT A "HDI" FILE, NOT "HDM".
4. Enjoy!

Recommended Emulators
	Neko Project 21 (and nothing else)

Credits:
CrookerWine: Translation
JackDBS: Editing, Hacking, Playtesting
trentsignia: Editing, Hacking
NightWolve: Playtesting
KekleAlex: Playtesting
Geometrizer: Playtesting
Hee-Ho: Playtesting
David Shadoff: Editing Help
tomyun: Script decompression tools
Retronomicon: Original Hacking
cuba200611: Hard Drive Port Hacking
BabaJeanmel: Original Addendum Hacking
Ashley Riot: Special Thanks

Discord Servers
	PC-98 Centric Server with many PC-98 translators/hackers: http://discord.gg/j2ns7UQ
	My own personal Discord server: http://discord.gg/U5mRcWeEV5

Contact Info
	JackDBS
		Discord: jackdbs
		Email: smtifwasbad@gmail.com
	CrookerWine
		Discord: crookerwine
		
Special Thanks
	To Retronomicon Games, thank you for doing the patch back in 2019.
		It may be shit, and it may be buggy, but it was the first PC-98 game I ever played.
	To cuba200611 and BabaJeanmel, thank you for doing the addendums for the original Retronomicon translation.
	To Ashley Riot, thank you for making a full YouTube video on Retronomicon back in May.
		You working with me for research on the topic made me want to attempt to get this game the translation it deserves.
		
Change Log:
10/31/23 - Version 1.0: Initial Release