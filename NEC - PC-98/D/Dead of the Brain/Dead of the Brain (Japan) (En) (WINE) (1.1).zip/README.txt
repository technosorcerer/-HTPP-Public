Dead of the Brain 2 (PC-98) - English Translation
By WINE

Version 1.1, for hosting on the following websites:
- Archive.org
- GBATemp.net
- Github.com
- jackdbs.neocities.org
- Romhack.ing
- Romhackplaza.org

The patch and patched version of this translation project may not be rehosted elsewhere.

Table of Contents:
	I: HOW TO APPLY THE PATCH
	II: RECOMMENDED SETUP
	III: FAQ
	IV: CREDITS
	V: DISCORD SERVERS
	VII: CONTACT INFO
	VIII: CHANGELOG

I: HOW TO APPLY THE PATCH:
	1. Download "Dead of the Brain 2 [HD].zip" from Neo Kobe in the "Fairytale" section.
	2. Use an XDelta patcher to apply the patch on the HDI file.
	3. Enjoy!

II: RECOMMENDED SETUP
	You should check out GANG FIGHT's "PC-98 Emulation For Beginners" guide, even if you have been emulating PC-98 for a while. It contains a lot of useful information and tips that will greatly improve your gaming experience.
		https://gang-fight.com/projects/98faq/

III: FAQ
	1. What kind of objectionable content can I expect to see in this game?
		As a riff on zombie and punk flicks, you can expect a lot of graphic violence and gore throughout the game.
			There are also some instances of sexual content, consensual and otherwise, but visually they are not depicted beyond the display of frontal nudity.
	2. The game is asking me to pick a music board. Which one should I pick?
		The short answer is that if you don't know what this means, pick internal.
			The longer answer is that some early models of PC-98 computers did not include any sound, which had to come from an external sound card called the PC-9801-26K. Later models came with this sound hardware built in, but the volume levels were mixed differently from the 26 sound card. (The PC-9801-86K sound card, which was released after this game came out, has the same volume mixing as internal music boards.)
			The game contains two copies of the soundtrack with different volume mixes depending on the computer you own (or the model you have chosen to emulate). The music option screen provides examples of which models use which setting.
			If you are playing on Neko Project 21/W and the mixing sounds off no matter which option you pick, navigate to the Sound Option section under Device and set the PSG level to 32.
	3. I selected "END GAME" when I got a Game Over, and now I cannot do anything. What do I do?
		You must restart the game in order to continue playing from a "GAME END". This can be done by simply resetting the emulator, but here is an in-system alternative:
			1. Press the [Break] key on your keyboard. (If you are using a laptop, this key might only be accessible via a shortcut or on-screen keyboard.)
			2. The system will ask if you want to exit to the command prompt. Press [Y] to confirm.
			3. Type "BRAIN2.BAT" into the command prompt to restart the game.
	4. The game is asking me to enter a four-digit code. What do I put?
		Glad you asked! This information was originally printed in the game's manual. Here is a reproduction:
			R-T50 -> 1129	V-L25 -> 2509
			R-S73 -> 2854	V-Y59 -> 4481
			S-N35 -> 6626	B-W33 -> 2680
			S-R52 -> 3459	B-A41 -> 4304
			P-B30 -> 5055	W-C13 -> 6437
			P-A50 -> 9396	W-S99 -> 7144
			X-F01 -> 4344	G-R64 -> 8327
			X-M00 -> 7687	G-E97 -> 8233
			D-O23 -> 1630	K-L43 -> 0071
			D-H33 -> 9642	K-Y86 -> 0915
			T-D79 -> 9461	I-U68 -> 7678
			T-J86 -> 5971	I-E21 -> 1841
			N-U12 -> 1692	Z-P08 -> 3121
			N-Z04 -> 8276	Z-V77 -> 5765

IV: CREDITS
	Geometrizer: Translation
		FCandChill: Management, Hacking, Support
		JackDBS, trentsignia: Editing, Hacking, Playtesting
	
	Thanks to:
		Cavey, flavx, Hee-Ho, KDan, meunired, and Shylrai for playtesting this translation.
		tomyun, for developing the script decompression tool Juice.

V: DISCORD SERVERS
	PC-98 Centric Server with many PC-98 translators/hackers: http://discord.gg/j2ns7UQ
	My own personal Discord server: http://discord.gg/U5mRcWeEV5

VI: CONTACT INFO
	JackDBS
		Discord: jackdbs
		Email: smtifwasbad@gmail.com
		Website: https://jackdbs.neocities.org/

VII: CHANGELOG
	14/10/2025 - Version 1.1: Disclaimer correction, save data fix, name entry reenabled
	01/10/2025 - Version 1.0: Initial Release