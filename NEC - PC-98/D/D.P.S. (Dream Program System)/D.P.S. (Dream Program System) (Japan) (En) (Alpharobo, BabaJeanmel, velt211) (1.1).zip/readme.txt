D.P.S - Dream Program System - English Translation port and enhancement by Alpharobo & BabaJeanmel
V 1.0 - 10/04/22

D.P.S. is an early AliceSoft game that lets you play a "virtual console" with three games, each corresponding to a different erotic scenario. It also lets you choose between two different flavors for each one. This shiny concept just encompasses three mediocre ADV games with erotic content ranking from vaguely creepy (at best) to completely fucked up (at worst). The only redeeming part is the great artstyle. The sequels were thankfully better, both in writing and art department.

This game (well, the FM TOWNS version of it, running on the SysEng Windows port of the AliceSoft engine) was translated by velt211 back in 2020. Well, "translated" is an overstatement; actually, it was just processed in Google Translate. It was out of question for me to retranslate the whole thing from scratch, but I ended up editing the script a lot to fix spacings, translate the onomatopeia, remove redundancies and third person speech, and correct the most blatant mistranslations, "according to keikaku" parts and bizarre phrasing. The result is still far from being accurate, but at least it reads a lot better.

If you still want to play D.P.S at this point, just be aware it's more an "educational" project than a polished release like what we usually deliver. The real reason for this project was to build the foundation for a larger AliceSoft porting project. Allow me to explain...

All AliceSoft games on PC-98 rely on a single engine, "System" and its three revisions. RottenBlock from the AliceSoft wiki had already made an incredible work on deciphering almost every aspect of it, and wrote some very nice tools at the disposal of localizers, but to use with modern system ports. So I requested them to add support for compiling PC-98 compatible scripts with these tools, and they kindly agreed to do so.

After messing a bit with ryu1's porting kit (http://www.ryu1.jp/alice/index.html), I managed to convert all early PC-98 AliceSoft titles from N-BASIC floppy disk images to MS-DOS-compliant HDIs, giving us a lot of extra space to work with along with direct access to the executables. Then, Alpharobo found a clever way to allow these titles to display latin characters, something the original engine was totally incapable of. So I started converting DPS' English script, because it was the shortest and, technically, the easiest one to do. Turns up the editing, along with the restoration of the animations (cut out in the Windows port) took me waaay longer than expected... Then a lot of manual fixes were made by Alpharobo to correct the bugs (missing opening, bad dialogue box sizes, garbled characters... you name it). The good news is that now, we have enough knowledge in our hands to tackle some more ambitious projects!

So for 2024, you should be able to play Little Vampire, Rance 1 and 2, and finally Toushin Toshi, in their original versions, in English, using the existing scripts you've all come to know and love among the years! How cool is that? And who knows, I might pick up one of the untranslated ones at a point, too... :)

CHANGELOG
1.1 - 01/05/23
- Reduced the filesize of the main script file by 30%. The script itself is unchanged compared to the 1.0 version.
- Previous saves are not compatible with this version, sorry.

HOW TO
The game is freeware. Download the official digital release from the AliceSoft website: http://retropc.net/alice/menu.html
Copy the patch to the folder you extracted the disk images to and launch "PATCH.BAT". You'll get an autobootable HDI to boot inside your emulator of choice. If you prefer real hardware, just extract the contents of the HDI and copy the "DPS" folder to your PC-98. Launch the game with DPS.BAT

CREDITS

*Original Version*
RottenBlock: hacking
velt211: translation

*PC-98 port*
ryu1: N-BASIC to MS-DOS conversion
Alpharobo: hacking
BabaJeanmel: script insertion, editing