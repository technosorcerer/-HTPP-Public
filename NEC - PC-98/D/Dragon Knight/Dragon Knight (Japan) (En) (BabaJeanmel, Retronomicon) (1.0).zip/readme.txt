Dragon Knight - English translation v1.0 by Retronomicon
Addendum patch by BabaJeanmel - FINAL version

THE STORY SO FAR

Back in 2019, a romhacker called Retronomicon opened a patreon and offered some PC-98 game translations to download for free on it. They worked at a very fast pace, releasing one pre-patched english game per month. However, after a handful of them were released, it turned out these translations were basically edited MTL, with a lot of liberties taken here and there, not to mention a fair share of gross mistranlations. As for the hacking, it's safe to assume it was really quick and mostly untested, as some games were unplayable on real hardware while others had derps of various seriousness (some were unfortunately game-breaking).

Even if the patches were free, the fact that Retronomicon made donations possible raised some controversy and most of all, scam accusations. So Retronomicon first tried defend themselves arguing that the games were shit and didn't deserved an accurate translation in the first place, before closing their patreon page and vanishing from the surface of the web.

The localisation of "Dragon Knight" is pretty bad. Sure, the script is fun and lively, but there are some gross mistranslations (the most infamous being Obaba calling herself "the eagle"), a lot of cut text (to fit into size limits - Retronomicon could have expanded them with a couple hacks, but chose the quick and dirty way instead) and a fair share of bugs, the most annoying one being the total absence of all animations from the game.

PATCH GOALS AND CONTENTS

I've bothered with this mostly to take a peek at the edited files's structure, for educational purposes (it actually allowed me to understand some errors made in my own AI1 engine games translations - Run Run Concerto and Foxy, that I plan to revisit at a point). So I don't take any responsability for the un-acurateness of the script. If you don't like the script (and you have all the right in the world to do so) just play the game in Japanese if you can or wait for Butch's re-translation of the game for a better English experience. Otherwise, it's your only option, so sorry if you're really desperate about playing it. Just to make things clear, I don't plan * at all * to retranslate it. I've already spent way more time on this thing than I should have ^^

List of changes :
- HDI conversion, with omake content accesible at boot.
- All animations restored.
- Ugly text brackets (<>) removed and replaced with the real stuff ([]).
- A lot of random font changes, line break errors, alignment issues, and some garbled characters have been fixed all over the game. There even were a couple of untranslated strings I had to do from scratch. Now everything is legible and displays properly. That doesn't mean the script is better, though.
- Hackers can now decompile all .MES files with tomyun's "juice" tool, while the original Retronomicon version had a couple corrupted files. 

HOW TO

Just put the two disk images from the Neo Kobe version ("Dragon Knight [FD].zip", in the "elf" directory) in the same directory as the patch, then run "patch.bat". You'll end up with a fully bootable HDI file that lets you choose between booting the game or accessing omake content.

To skip the very, very long opening and access the main menu, press "F1" (Thanks to Butch for pointing it out!)