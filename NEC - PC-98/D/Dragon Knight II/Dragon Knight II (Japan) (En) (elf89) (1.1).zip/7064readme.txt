Dragon Knight 2 - English translation 1.1 by elf89

This patches all mes and dat files with text in them. There are 2 ways to apply the patch.

The first and easier way is to use a hdi image compatible with the one in the Neko Kobe collection (Dragon Knight II [HD]) Then, apply the hdi delta from this patch by running patch_hdi.bat.

The second way is to take all *.mes and mon*.dat files from your Dragon Knight 2 disk image with your favorite disk image editing tool. Then apply the individual file deltas from this patch on every file by running patch_allfiles.bat. Then copy the modified *.mes and mon*.dat files back into your disk image.

Back up your disk images first!!

This is a machine translation but I've looked over every text and cleaned them up. But it's not perfect so if you can do better just use the included converter script or whatever other mes editing tool and make it better and publish a new version. Beware, there's a lot of pointlessly repeated text in the files that you should translate consistently.

Bonus: You can use the included mester python script to convert mes and monster dat files to an editable text format, and back. Run "python mester.py open.mes" to create open.mes.txt, and "python mester.py open.mes.txt" to turn it back to open.mes with your changes.

You can change most line lengths freely and add hard linebreaks if needed, except in monster dats, where line start offsets are given in the file so if you want longer lines you have to update the offsets too. For shorter lines just pad with nulls or whatever. In mes scripts 2-byte shiftjis can appear wherever and it just gets printed, but ascii has to be put in "quotes".

Known problems:
  - Name entry is disabled on purpose
  - Monster texts are forced to fit in the original text length and linewrap acceptably for hit reactions on both Takeru and Baan so the translation is simplified
  - Punctuation sometimes linewraps badly (but there shouln't be any english words broken by linewrapping)
  - Healing magic sometimes shows incomplete messages but otherwise functions as expected
  - Animated scene may hang for a minute on exit, should be all fixed but if it happens, wait patiently
Fixed in 1.1:
  - Takeru was written in double-width characters
  - Character eye/mouth animations didn't work most of the time
  - Changed hdi image layout to maybe work better on real hardware
  - Opening now waits for keypresses instead of autotimed
  - Small text corrections

If you want to upgrade an ongoing game, copy the flag* files from your 1.0 image to 1.1 image, those are the save files.

Special thanks go to Kirinn for tools and testing!! Extra thanks to BabaJeanmel for 1.1 fixes!! Look out for Dragon Knight 3 next!!

How to play: Turn on numlock and play with numpad, hold F1 to skip intro or camp in dungeon, hold F3 to speed transitions, draw a map of every level or you will get stuck, save often because some monsters will one hit kill you, stand next to stairs and run into a wall endlessly to grind xp easily, hug Sophia once every day

Modification and redistributing is encouraged. I disclaim all rights and responsibilities. Do whatever you want.
