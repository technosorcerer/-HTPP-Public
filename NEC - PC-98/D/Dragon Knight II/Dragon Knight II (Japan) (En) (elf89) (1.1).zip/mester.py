#!/usr/bin/env python3
import argparse
import os
import glob

parser = argparse.ArgumentParser(description="Converts Elf AI1/AI2 .MES scripts to editable *.MES.TXT and back to .MES")
parser.add_argument("file", action="store", type=str, nargs="+", help="Input files")
parser.add_argument("-l", action="store", type=int, default=77, help="Soft linebreak limit, default 77; override with L in txt files")
parser.add_argument("-n", action="store", type=int, default=12, help="Player name length for soft linebreaks, default 12 bytes")
parser.add_argument("-m", action="store", type=str, default="Takeru", help="Player name, default Takeru")
parser.add_argument("-r", action="store", type=int, default=3, help="Max rows for soft linebreaking, default 3")
args = parser.parse_args()

def from_mon(fil):
	txtfile = os.path.basename(fil) + ".txt"
	print(fil, "->", txtfile)
	with open(txtfile, "w") as fw:
		with open(fil, "rb") as fr: data = fr.read()
		offset = 0
		in_jis = False
		first_char = False
		while offset < len(data):
			b = data[offset]
			offset += 1
			maybejis = ((b >= 0x81) and (b <= 0x98)) or ((b >= 0xE0) and (b <= 0xEA))
			if (maybejis) and (not in_jis):
				maybejis = False
				if offset + 2 < len(data):
					b2 = data[offset + 1]
					if ((b2 >= 0x81) and (b2 <= 0x98)) or ((b2 >= 0xE0) and (b2 <= 0xEA)):
						maybejis = True

			if maybejis:
				jis = bytes([b, data[offset]])
				try:
					conv = jis.decode("shift_jis")
					if not in_jis:
						in_jis = True
						fw.write("\n")
					elif (not first_char) and (b == 0x81) and (jis[1] == 0x93):
						fw.write("\n")
					fw.write(conv)
					first_char = False
					if (b == 0x81) and (jis[1] == 0x93):
						fw.write("\n")
						first_char = True
					offset += 1
				except:
					maybejis = False

			if not maybejis:
				if in_jis:
					in_jis = False
					if not first_char:
						fw.write("\n")
				fw.write("#" + format(b, "02x"))

def from_mes(fil):
	txtfile = os.path.basename(fil) + ".txt"
	print(fil, "->", txtfile)
	with open(txtfile, "w") as fw:
		with open(fil, "rb") as fr: data = fr.read()
		offset = 0
		in_quotes = False
		in_jis = False
		first_char = False
		while offset < len(data):
			b = data[offset]
			offset += 1
			if ((b >= 0x81) and (b <= 0x98)) or ((b >= 0xE0) and (b <= 0xEA)):
				jis = bytes([b, data[offset]])
				offset += 1
				if not in_jis:
					in_jis = True
					fw.write("\n")
				elif (not first_char) and (b == 0x81) and (jis[1] == 0x93):
					fw.write("\n")
				fw.write(jis.decode("shift_jis"))
				first_char = False
				if (b == 0x81) and (jis[1] == 0x93):
					fw.write("\n")
					first_char = True
			else:
				if in_jis:
					in_jis = False
					if not first_char:
						fw.write("\n")
				if (b == 0x22):
					in_quotes = not in_quotes
					if in_quotes: fw.write("\n")
					fw.write("\"")
					if not in_quotes: fw.write("\n")
				elif (b == 0) or (b == 0x10):
					fw.write("#" + format(b, "02x"))
					fw.write("#" + format(data[offset], "02x"))
					offset += 1
				elif (b == 8) or (b == 0x18):
					fw.write("#" + format(b, "02x"))
					fw.write("#" + format(data[offset], "02x"))
					offset += 1
					fw.write("#" + format(data[offset], "02x"))
					offset += 1
				else:
					if in_quotes:
						fw.write(chr(b))
					else:
						fw.write("#" + format(b, "02x"))

def to_mes(fil):
	global maxlen
	global maxanim
	global args
	mesfile = os.path.splitext(fil)[0]
	print(fil, "->", mesfile)

	with open(mesfile, "wb") as fw:
		with open(fil, "r") as fr: data = fr.readlines()
		maxlen = args.l
		maxanim = 99
		linelen = 0
		softrows = 0
		maybeanim = False
		for line in data:
			try:
				l = line.strip("\n")
				if l:
					# Script bytes, don't touch.
					if l.startswith("#"):
						# Printing player name in DK2.
						if l == "#ac#47":
							linelen += args.n
							if linelen >= maxlen:
								fw.write(bytearray([0x81, 0x93]))
								linelen = args.n
						# Don't reset line length if it's just a color change command.
						elif (len(l) == 6) and (l.startswith("#a9")):
							pass
						else:
							if maybeanim:
								# Print some double-width spaces to trigger animations. Still have to softwrap these to avoid glitches...
								animlen = softrows * 3 + linelen // 20 + 1
								if animlen > maxanim: animlen = maxanim
								i = (maxlen - linelen) // 2
								if animlen > i:
									if softrows + 1 < args.r:
										fw.write(bytearray([0x81, 0x93]))
									else:
										animlen = i
								fw.write(bytearray([0x81, 0x40] * animlen))
								maybeanim = False
							linelen = 0
							softrows = 0

						for part in l.split("#"):
							if part:
								fw.write(int(part, 16).to_bytes(1))

					# Ascii strings.
					elif l.startswith("\""):
						# Strip start and end quote, replace remaining quotes with apostrophes to avoid breaking the string.
						if l.endswith("\""):
							l = l[1:-1]
						else:
							l = l[1:]
						l = l.replace("\"","'")

						if not maybeanim:
							maybeanim = (l.startswith("[")) and (not l.startswith("[" + args.m))
							if maybeanim:
								# Don't trigger talking animation if the line is merely ...
								i = l.find("]")
								if (i < 0) or (l.count(".") + i + 2 >= len(l)): maybeanim = False

						if not l.startswith(" "):
							# Do soft linebreaking unless the string begins with a space.
							while linelen + len(l) > maxlen:
								frm = maxlen - linelen
								i = l.rfind(" ", 0, frm)
								j = l.rfind("-", 0, frm)
								if j >= 0: j += 1
								if j > i: i = j
								if i < 0: i = frm
								if (linelen == 0) or (linelen + i <= maxlen):
									fw.write(bytes("\"" + l[:i] + "\"", "ascii"))
									if l[i] == " ": i += 1
									l = l[i:]
								fw.write(bytearray([0x81, 0x93]))
								linelen = 0
								softrows += 1
								if softrows >= args.r: print("[!] Line takes more than", str(args.r), "rows:", line)
						fw.write(bytes("\"" + l + "\"", "ascii"))
						linelen += len(l)

					# Use : for infile comments.
					elif l.startswith(":"):
						pass

					# Use N to disable animation for the current line.
					elif l.startswith("N"):
						maybeanim = False

					# Use Axx to cap anim counter going forward in this file.
					elif l.startswith("A"):
						maxanim = int(l[1:])

					# Use Lxx to force automatic linebreak lengths to xx going forward in this file.
					elif l.startswith("L"):
						maxlen = int(l[1:])
						if maxlen == 0: maxlen = 1

					else:
						linelen = 0
						fw.write(bytes(l.encode("shift_jis")))
			except Exception as e:
				print(e)
				print("line:", line)

for in_file in args.file:
	files = glob.glob(in_file)
	if len(files) == 0:
		print("No files match", in_file)
		continue
	for f in files:
		if f.lower().endswith("txt"): to_mes(f)
		elif f.lower().endswith("dat"): from_mon(f)
		else: from_mes(f)
exit(0)
