Little Vampire - English Translation port by Alpharobo & BabaJeanmel
V 1.2 - 09/16/24

Little Vampire is an early ADV game from the time AliceSoft was still called Champion Soft. Despite its connections with the Rance series (partially retconned since) it's a SFW game, which is kind of unusual for this publisher. First game using the "System" engine, it's brutally hard and unforgiving, but also has a lot of charm.

This patch is the second step of the AliceSoft porting project, aiming at bringing back all the early AliceSoft fan-translated games back to their platform of origin. The script is an edited MTL by RottenBlock, who also wrote the tools to decompile the game scripts and kindly agreeded to add PC-98 data export possible on them. Unlike the DPS script, this one was decent and didn't need additional edits, so porting it was kinda easy. Additional hacking was needed, but nothing Alpharobo couldn't handle.

As for the next step of the project... it's no less than the first game of the infamous Rance series! I'm sure this one will be relevant to some people's interests...

CHANGELOG
Version 1.2:
- Restored the original title screen and music, previously exclusive to the N-BASIC version (despite being present in the game files)
- Removed the numbers that were sitting on top of the game window, covering part of the artwork.
Version 1.1:
- Reduced the filesize of the main script file by 30%. Mostly useful for real hardware users.

HOW TO
The game is freeware. Download the official digital release from the AliceSoft website: http://retropc.net/alice/menu.html
Copy the patch to the folder you extracted the disk images to and launch "PATCH.BAT". You'll get an autobootable HDI to boot inside your emulator of choice. If you prefer real hardware, just extract the contents of the HDI and copy the "VAMP" folder to your PC-98. Launch the game with VAMP.BAT.

CREDITS

*Original Version*
RottenBlock: hacking and translation

*PC-98 port*
Alpharobo: hacking, playtesting
BabaJeanmel: script insertion