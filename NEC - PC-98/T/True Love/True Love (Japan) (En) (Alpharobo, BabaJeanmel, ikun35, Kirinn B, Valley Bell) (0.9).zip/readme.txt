True Love - English Translation port by ikun35, Kirinn B, Alpharobo, Valley Bell & BabaJeanmel
V 0.9 - 11/09/2025

One of the first eroge experienced in English by western gamers, True Love is basically a Tokimeki Memorial spoof. It's neither beautiful nor very well written, but it has a wholesome atmosphere and a lot of funny moments (and also some very cringey ones, as you should expect). It's also pretty short so you might as well give it a go. I have not much else to say about it, except it has a great nostalgia value for me, so I enjoyed revisting it so many years later.

When ikun35 decoded both the compression and script system, he also added a powerful tool which automatically reinserted about 85% of the original windows script straight back to the PC-98 files. It left me with an almost complete script, but the devil is often in the details, so a lot of additional work was needed to insert the 15% missing lines, translate the text exclusive to the PC-98 version (mainly a developers talk section), correct the punctuation, spacing, and most blatant grammar errors, re-insert the "emoji" which the Windows version eluded, and take care of the hardcoded parts. Still, it was pretty motivating to have an almost complete script to start a project. Wish I had the same thing for Yu-No back in the days...

Valley Bell provided us a great tool which auto-insterted line breaks in the final script file. It helped tremendously. Basically, I just had to manually fix the h-scenes (which use a different spacing) afterwards.

Alpharobo handled the much needed ASM hack. Thanks to him, we had the name selection screen fixed for half-width characters really fast.

As for Kirinn, he once again took care of the graphical hacking, allowing us to both reinsert the localized menu graphics and take care of the mosaic censorship.

This patch integrates the 1.2 update which makes resting less punitive and changes a bit the random events frequency. Most of all, it adds MIDI support for the soundtrack, in case you have a good setup you'd like to take advantage of.

NOTE
This is still not a proper 1.0 release, as there is some hardcoded text I couldn't expand: the "choice" word before each multiple dialogue choice, the presents you can give the girls at the end of the game, the full names of the characters in the CG/music rooms and some of the staff names. If somebody wants to take a look at the executable to fix this, please let me know.

CONTENT WARNING
There are (of course) H-scenes in this game. They're all pretty vanilla by PC-98 standards, but still forbidden to players under 18.

HOWTO
Apply the xdelta patch to a clean Neo Kobe "True Love" hard disk image in the hdi format (from the "Software House Parsley" directory, CRC32: 8A7C9B78).
To play on real hardware, just extract the hdi contents using Disk Explorer and copy the "TLOVE" directory on your hard drive. Launch with "START.BAT".

CREDITS
Original translation: Otaku
Hacking and tools: ikun35
Additional text hacking: Valley Bell
Additional ASM hacking: Alpharobo
Graphic hacking and tools: Kirinn B.
Script insertion and editing, additional translation, graphic edits: BabaJeanmel
Proofreading: duglis