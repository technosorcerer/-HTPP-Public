Tuned Heart PC-98 Translation

Contents:

1. Foreword

2. Game description

3. Translation notes

4. Hacking notes

5. Disclaimer

6. Staff and special thanks

7. Contact
----------------------------------------------------------------

1. Foreword

Hello again!

Tuned Heart is a strategy RPG game for PC-98, featuring an all-female crime fighting squad. This game was in the oven for a while for various reasons, but we managed to finish fixing it up for the final release. So, this should be an enjoyable romp for all you players out there!

2. Game description 

In Tuned Heart, you control a squad of girls who fight crime in Japan. They're of various backgrounds and they have different stories behind them. The game plays like most SRPGs, with some twists. 
Firstly, there are VN sections which flesh out the characters and add more depth to them (the game is played from the players' perspective). 
Secondly, there are special abilities each of the girls has that can be used to make the battles easier.
Thirdly, there is some tuning/weapon modification, both of which help to add replayability to the game and give it more depth.
When it comes to the plot, there are some twists and turns along the way, it is not entirely predictable. It also seems that the developers wanted to make an equivalent of a cop flick in a video game form, judging by the dialogues and various scenes present in the game.

3. Translation notes

The game had some tricky lines to translate, mostly related to the techniques the girls use to combat crime, but also lots of motorcycle/car/weapon names, all based on their real-world equivalents. 
It also had some fuzzy story bits, but we hope they were conveyed without needless shortcuts. Almost the entire game consists of dialogues, with very few (if any) descriptions, which made the setting feel more vived and lived-in.

4. Hacking notes 

One notable thing about this game is that it used an updated web-based translation tool we made for Macross, which was created by Miralita. It became a very convenient and powerful tool that we planned to use for other translations, but... Actually, we never used it again. Also, this particular translation had a very unfortunate story - it was planned as one of the early releases back in 2017. 
It was translated rather quickly up to about 90% and was fully playable, but this remaining part, as usual required the most hacking effort - compressed graphics and the requirement of custom patching because of packed files on game floppy disks (the game requires installation on hard disk). 
Because of these and some other problems this translation was postponed multiple times. At the end of 2018 the graphics were finally cracked (it was a simple RLE, but used a ton of crap in a header that was very misleading), so we started to plan the final release... And discovered that tools that were made for this game are too old and it's easier to rewrite them than add new features. 
So, in order to put everything together quickly, Miralita set to rewrite it and finally piece everything together. Aaaaand... It took another few months to test the game, including some more nitty-gritty.

As per the hacking details (last thing in the hacking section are the actual hacking notes, yeah), it's not really something special at all. 
Essentially, it's a very simple VN engine in the story scenes that required really small amount of debugging fun to uncover mostly all of scene codes. 
Also, there's a built-in support for half-width English letters. Nothing to see here, really.

5. Disclaimer

This translation is a non-commercial and unofficial project which is in no way affiliated with the game creators or distributors. We don't own anything here and have no copyrights.

We release this translation in the form of a patch. Please, don't ask us to send you the disks, or where you can find them - we can't help you with that.

You can redistribute this translation freely as long as you don't ask money for it and include this readme.txt file with it. We don't condone any form of commercial redistribution. Please, keep that in mind.

6. Staff:

Celcion       - hacking

Miralita      - hacking/graphics

cccmar        - lead translator/editor 

TheMajinZenki - manual translation, additional help

Special thanks go to:

- guys from the ROMhacking.net forum 
- betatesters - hollowaytape, Blomman and Spolan

7. Contact:

celcion - celcion@gmail.com

cccmar  - cccmar111@gmail.com

