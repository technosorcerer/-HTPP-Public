Toushin Toshi - English Translation port by Alpharobo & BabaJeanmel
V 1.0 - 02/18/24

It's already the fifth game released within the AliceSoft porting project, and the last working on the venerable System 1 engine.

Work on Toushin Toshi required a bit of additional hacking, especially to get the scrolling text from the intro working. The previous work we did to optimize the script size was a lifesaver on this game, as it has some really tight memory limits. The unoptimized script made the game crash on multiple horizons. Now it's mostly stable, except on a few occasions (see below).

Like most of the AliceSoft translations we port, this one hasn't been touched really much. Only the spacing and a couple occasional typos have been edited. That made the whole process go really smoothly as soon as the hacking was taken care of.

Future AliceSoft ports will take a lot more time, sorry. The System 2/3 games are HUGE for the most part, and present some technical issues difficult to figure out. But we hope to be able to bring you the 5 last games (Rance III, Rance IV, Rance 4.1 and 4.2 and finally Toushin Toshi II) eventually.

BUGS WARNING

Toushin Toshi is a very ambitious game considering the primitive engine it was built on. Consequently, it has some very tight memory limits, and a poor way of handling them. Here are the main issues you must be warned of before playing:

- You WILL make the game crash if you try to initiate conversation in the bar with a NPC after returning from the dungeon. It'll start around when you reach floor 3 if I remember well. To avoid this, always stop by the inn and save before going to the tavern. It'll clear the memory and you'll prevent the game from crashing.
- If you run away from too many battles, random encounters will completely stop, until you exit the dungeon floor you're in and return. 

USUAL CONTENT WARNING

This game has a lot of rape scenes, most of them being performed by ugly monsters. Worse, you can even rape two of the female characters without any real consequence on your progress, not to mention selling monster girls into sex slavery. Custom might not be an asshole like Rance is, but you still have the option of doing some pretty fucked up stuff. So... don't play it if you're likely to be offended. And maybe you should give up with AliceSoft games entirely.

HOW TO
The game is freeware. Download the official digital release from the AliceSoft website: http://retropc.net/alice/menu.html
Copy the patch to the folder you extracted the disk images to and launch "PATCH.BAT". You'll get an autobootable HDI to boot inside your emulator of choice. If you prefer real hardware, just extract the contents of the HDI and copy the "TOUSHIN" folder to your PC-98. Launch the game with TOUSHIN.BAT.

CREDITS
*Original translation*
Toolbox: hacking
Arunaru: translation, editing

*PC-98 port*
Alpharobo: executable hacking
BabaJeanmel: script insertion, editing