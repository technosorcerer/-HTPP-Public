FOXY English Patch
by BabaJeanmel
Version 1.0

Foxy is an early Elf title. It's a strategy game looking like a very primitive version of Advance Wars. Basically, you're a commander from the "Blue" army and are fighting against the "Red" army, led by Crystal Eyes, over some kind of supercomputer called FOXY. 

Elf built on the mechanics of Foxy to make some more complex games later: Shangrlia, Dragon Knight 4, and of course Foxy 2. It's also notable, due to its venerable age, to be one of the few completly uncensored eroge. So no invisible/pixelated vaginas there.

This is actually the first time I fully translate a game myself, hence the choice of a short game with a script that's not too big. I hope there are not too many errors nor misses. If you played the original and you encounter some gross mistranslations, or if there are some english grammatical errors (I'm not a native speaker, even if I've been speaking english on a daily basis for 30+ years now) don't hesitate to (politely) tell me about it so I can make corrections.

CONTENT WARNING: there are quite a few rape scenes in the game. And your MC is the perpetrator in not less but four of them (even if two of the girls magically become consentant during the act). This can probably make some people uncomfortable. At the time the game was released, these scenes were considered to be funny for the young male audience this game was aiming at; they even include their fair share of puns (think Rance, but with worse writing). Don't play the game if you find this kind of stuff offensive. You've been warned.

HOW TO PATCH

Copy the two disks from the Neo Kobe release into the patch directory and launch the patch.bat file. You'll get a fully functional HDI file that boots directly on the menu. For real hardware, open the hdi with Disk Explorer or ND, then copy the FOXY subdirectory on your hard drive and launch MENU.BAT.

When launching the game, you'll be sent to a little text menu that allows you to select the game, SP content or character editor. The original floppy version used some key combinations that couldn't be carried over to the HDD version. Be warned: the character editor makes PERMANENT changes to the sprites, so you might want to keep a clean copy of the game somewhere in case you screw up.

HOW TO RUN

If you play on an emulator, you should use Neko Project FMGEN (np2 variant, not np21). Keep the CPU at 1x or you'll run into timing issues. If you use save states, don't reload a save after finishing a mission and viewing the event CG or you might hang the game and lose your progress. Save between each mission to avoid problems.
Other emulators (Dosbox-x anyone?) should work too, as long as you emulate an old model or you keep the CPU speed between 8-10 Mhz.
If you play on real hardware, early models (up to the UX I guess) will run the game just fine, but later ones may need to enable slow cpu mode to run the game without issues.

WHAT'S DONE
- Basically everything in the main game AND the SP disk: menus, battle messages, event CGs, ending, credits.

WHAT'S MISSING
- The character editor. I haven't messed with it at all and don't plan to do so.

BUGS
- Animations won't loop in the CG events. But at least, they play!
- Blinking cursor in the character editor.

SPECIAL THANKS
- tomyun for his awesome reverse-engineering work that allowed me to start this project in the first place;
- Kanji and sampson for fixing my english grammar mistakes