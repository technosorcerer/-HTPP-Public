Versi�n de la traducci�n 1.0 por ZetaM traducciones de AbandoJuegos.

Necesitaran del programa anxdiet que trae el emulador Anex86 para colocar los archivos de la traducci�n.

Es recomendable Traducir la versi�n instalada en HDI del juego, pero si desean utilizar la de disquetes deber�n colocar los archivos de la siguiente manera. 

en el disquete 1 colocar los siguientes archivos

FSMAIN.EXE
STAGE51.MSG
STAGE52.MSG
STAGE53.MSG
STAGE99.MSG

en el disquete 2 colocar los siguientes.

HELP.MSG
stage01.msg
STAGE02.MSG
STAGE03.MSG
STAGE04.MSG
STAGE05.MSG
STAGE06.MSG
STAGE07.MSG
STAGE08.MSG

en el disquete 3 colocar los siguientes.

STAGE09.MSG
STAGE10.MSG
STAGE11.MSG
STAGE12.MSG
STAGE13.MSG
STAGE14.MSG

y por ultimo en el disquete 4 el siguiente.

ENDING.MSG

Esta es la traducci�n 1.0 si se crashea el juego al leer alguna descripci�n de objeto o arma. notif�calo en donde esta la traducci�n.
