Night Slave - English Translation Patch by Valley Bell, Kirinn B & BabaJeanmel
Version 1.0 - 02/12/24

Night Slave is an action game reminiscent of Assault Suit Valken, with a strong VN part that happens to have both an interesting plot and a lot of lesbian hentai action. It's one of the very best action games available on the platform, alongside Rusty and Burning Dragon Plus. It controls well, offers a nice Gradius-like powerup system, a great variety of ennemies and environments, and a kickass soundtrack.

I know, this project isn't exactly a novelty. Night Slave already had a translation patch back in 2019, courtesy of Retronomicon. However, it was a straight up disaster. It had it all: badly hacked, and totally incompatible with real hardware ; not a single graphic done ; some missing text here and there, that showed up garbled because of the bad hack mentionned earlier ; brand new bugs, some of which were game-breaking ; and of course, a script of dubvious quality, with a lot of approximations, plainly made-up stuff, and cut lines.

This project aims to offer a better English version of this cult classic. Thanks to Valley Bell's research, the executable has been properly hacked to support actual ASCII characters, so it is totally compatible with real hardware and don't need any font workaround. The unpacking of the game files allowed more flexibility to work on the script: the text could finally be expanded, allowing it to be accurately translated. Finally, the graphics have been edited and reinserted, thanks to Kirinn B cracking once again the two different formats this game uses.

All of this... without asking for a single dime on Patreon! How is that?

It goes without saying, but in case you wonder: there's not a single element from the Retronomicon version in here. Everything's been redone from scratch. Rest assured.

*CONTENT WARNING*

There are some lesbian sex scenes in here, plus some good old fashioned heterosexual rape, and finally some lesbian dickgirl rape for a bit more variety. But sadly, no defenestration rape like in D.P.S. As always, don't play this game if you're likely to be offended by these scenes. Or you can set "VISUAL" to "off" in the options menu to play a SFW version, but devoid of any story event (even the non-sexual ones). Your call.

*HOWTO*

Use deltapatcher to apply the patch to an untouched hdi of the game from Neo Kobe (CRC:FF5F359A). Remember to set GDC to 2,5 Mhz, otherwise the game won't run. If you don't know how to do so, check this guide: https://gang-fight.com/projects/98faq/

*EMULATOR USERS WARNING*

If you don't play on real hardware, don't use an old, outdated emulator such as Anex86, T-98 next, or the old NP21 build that is part of the Neo Kobe Emulator Pack. There's a bug that can occur on these that makes mission 8 crash if you pick some specific equipment. We haven't been able to reproduce it on modern emulators nor real hardware. Just in case, you should update to the latest NP21, be it FMGEN, Win or Kai variants.

Save states should be avoided too. They can mess with level transitions, and make the game prone to crashing.

*BUG WARNING*

Don't kill the bosses for missions 7 and 9 off-screen, or the game will enter an endless loop, forcing you to reset and restart the level. This annoying bug was present in the original version ; maybe we'll be able to fix it one day, but for now just be careful.

*NOTE FOR PEOPLE DISTRIBUTING PRE-PATCHED GAMES*
We can't stop you to distribute pre-patched builds, as we have no actual rights on the games themselves, having just created some derivative work. But at least, if you do that, make sure you use the latest version available. 

So, ChadMaster guy, if you read this. You should know as of today, your current set has outdated versions of Yu-No (1.03) with a game breaking bug, Shangrlia 2 (1.0) with a text width bug, and the Alicesoft script ports (1.0) with the old text encoding system and a couple display bugs. All of these have been fixed since last revision, but you haven't noticed... Of course there is no way to reach you to tell you that, so I just hope you'll read this and take appropriate measures to prevent people for running into bugs we went through the trouble of fixing. Thanks.

And to the other countless ones: please include our READMEs with your prepatched files, so at least people know where these English versions come from and what to expect. The ChadMaster guy does this, and it's nice. So you should do the same. For every fan translation you curate, not only ours. Thanks.

CREDITS
Valley Bell: Hacking
Kirinn B: Graphics hacking, proofreading
BabaJeanmel: Translation, graphic edits
Special thanks to sfpt and amazin for real hardware testing.