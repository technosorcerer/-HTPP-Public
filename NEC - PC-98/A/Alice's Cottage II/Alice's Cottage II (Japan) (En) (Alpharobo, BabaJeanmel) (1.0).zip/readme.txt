Alice's Cottage II - English Translation by Alpharobo & BabaJeanmel
V 1.0 - 10/30/24

This second Alice's Cottage compilation is heavily tied to Rance III. It uses the same artstyle and offers three mini-games related to it. "Naguri Makuri Tower" lets you play Patton in some kind of Bomber Quest-like dungeon crawler, "Return of Okayu Fever" lets you play a monster against the main cast of Rance III, and the Alice Quiz makes you play as Rance himself, against five Alicesoft girls.

The rest of the content is pretty nice, too: the sequel for "Policewoman VX" entitled "Policewoman DA" which is at least as dumb as the first game, lots of fan content (including a totally insane short ADV called "Kumi-chan fight", but also a bunch of nice CG and some fanfics), a big Alice Soft back catalogue slideshow, and lots of random CG and developer messages.

The bump in quality from the first "Alice's Cottage" is impressive, and the amount of content is more than double. If you're an Alicesoft fan, you'll defintitely love this one.

CONTENT WARNING
As always with Rance-related stuff, there is quite a lot of rape in this collection, including a whole "Rape Club" in Policewoman DA. There also are some insensitive remarks about white guys' penis rigidity. Of course, nothing here is supposed to be taken seriously, but if this kind of stuff grosses you out, stay the hell out of it (and avoid other AliceSoft games like the plague)

CULTURAL NOTES
I hope you know stuff about Japanese trains, AV idols and Tokusatsu if you want to play "Alice Quiz".  Along with solid otaku references, a bit of scientific background, and of course knowledge of AliceSoft games. Or you can use save states, too.

HOW TO

This game, unlike most of AliceSoft's early input, is not available for download on their site. You must use deltapatcher to apply the patch on the Neo Kobe dump (Alice no Yakata II.hdi - CRC: ECD1FDBD).
If you want to play it on real hardware, you can copy the "YAKATA2" directory to your harddrive, and launch it with "YAKATA2.BAT".

CREDITS

RottenBlock: engine hacking
Alpharobo: executable hacking
BabaJeanmel: translation, script insertion