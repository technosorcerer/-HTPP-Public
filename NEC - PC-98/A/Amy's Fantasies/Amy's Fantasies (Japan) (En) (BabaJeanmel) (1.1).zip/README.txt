Amy's Fantasies PC-98 english script backport
by BabaJeanmel
Version 1.1 - 08/22/2022

No one asked for it, but I did it anyway: this infamous ero-vn can finally be played on its original iteration, in all its uncensored glory!

Well, let's be honest there: the script is not really good. It's somehow accurate to the original Japanese version, but has been stripped of a lot of stuff such as basic character characterization (especially for Sumire who now speaks in a kinda normal way) with the added bonus of typos and grammar mistakes. Sorry but being the lazy bastard I am, I did not try to retranslate anything... well, except a few lines mostly related to saving and loading, and a good chunk of the omake content Himeya either didn't bother with and/or mangled beyond recognition. My actual input is around 6-7% of the total english text.

But the game's primary interest is not its writing. Just its sheer insanity. It kinda set a landmark at the time... so here is the obligatory content warning. Check the VNDB page before playing to make sure you're ok with all the stuff that's going on there (and boy, there is). It's honestly so absurd that it ends up being more funny than actually shocking, but it depends on how much fucked up Japanese erotica you can actually stomach.

Kudos once again to Kirinn B, who wrote a great graphical recompression tool in a breeze, and Alpharobo, who managed to fix a pretty nasty pointer bug near the beginning of the game at lightning speed.

WHAT'S DONE

Basically everything, including the menu and ingame graphics. The patch also gets rid of the mosaic censorship that occurs in a few scenes.

CHANGELOG

-Version 1.1 : A short untranslated section in chapter 2 that I though was unused content is now in English. Thanks to dandalyn for reporting the issue.

HOWTO

Use Xdelta patcher to apply the patch on the Neo Kobe "Eimmy to Yobanaide (FD version) [HD].hdi" image (in the "C's Ware" subdirectory, CRC32: 7408306A)

CREDITS
Himeya Soft: original script
Tamamoball: hacking
Alpharobo: additional hacking
Kirinn B: graphics hacking
BabaJeanmel: script insertion, graphics edits, additional translation