Alice's Cottage - English Translation by Alpharobo & BabaJeanmel
V 1.0 - 05/22/24

Alice's Cottage is basically the grandaddy of fan discs. It's not an outstanding work on a gaming standpoint, but it includes a lot of goodies from the early days of anyone's favorite eroge publisher. It includes a quiz game, a short kinetic novel (probably the remains of a bigger project that was never achieved), some funny and non-sensical comments about the first "Rance"'s CG, a bit of shared user feedback, and last but not least a small ADV starring Alice herself.

Translating this disc was actually quite challenging, and a lot of modifications had to be made to the original script - especially the quiz section, that included some Kanji reading questions, puns that didn't convey at all in English, or references to Japanese expressions or proverbs. I did my best to preserve the original intents of the writers as much as possible, so I hope you'll have fun playing it.

Like in our previous projects done during the AliceSoft porting project, this translation work is heavily based on ryu1's N-BASIC to MS-DOS porting kit and RottenBlock's Sys0Decompiler tool. The PC-98 specific hacking was once again masterfully handled by Alpharobo.

CONTENT WARNING
The adult content here is pretty tame. "Alice in Digi-Land" is SFW. "Sentimental Seasons" has a couple sexually explicit CGs. The other sections have a few images with nudity scattered here and there. There also are a few sex jokes in the quiz section. Nevertheless, it's still restricted to players above 18 of age.

HOW TO
This game, unlike most of AliceSoft's early input, is not available for download on their site. You must use the Neo Kobe disk dumps (named "Alice no Yakata [FD h01]"). Extract the D88 disk images somewhere, then extract the contents of this zip file in the same directory. Launch "PATCH.BAT". You'll get an autobootable HDI to boot inside your emulator of choice. If you prefer real hardware, just extract the contents of the HDI with ND or Disk Explorer, and copy the "AL1" folder to your PC-98. Launch the game with AL1.BAT

CREDITS

ryu1: N-BASIC to MS-DOS conversion
RottenBlock: engine hacking
Alpharobo: executable hacking
BabaJeanmel: translation, script insertion