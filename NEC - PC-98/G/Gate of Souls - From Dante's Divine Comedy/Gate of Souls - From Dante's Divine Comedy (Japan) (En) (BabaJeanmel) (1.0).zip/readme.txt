Gate of Souls ~ From Dante's Divine Comedy
English partial translation by BabaJeanmel
Version 1.0 - 06/29/2021

"Tamashii no Mon ~ Dante no Shinkyoku yori" is quite an oddball. It's basically a metroidvania for PC-98, more focused on exploration and puzzles than on platforming or combat. What makes it quite unique is its setting : Dante's Divine Comedy, specifically the "Inferno" part. Although the plot has been heavily modified, both to make it work as a game and to remove most of the references to the Florentine XIVth century history, Christianity and Islam, it still is a very unsettling yet fascinating game. If you can get past the stiff controls, prepare yourself for a fascinating piece of obscure gaming history.

This patch will translate the UI and enough stuff to help you navigate more easily through the game.

A walkthrough is included to compensate for the dialog not being translated. Some puzzles are a bit difficult to figure out blindly.

Everything's been playtested to the end. If you played the beta, there are a couple item-related messages that were fixed or added, plus the location name "Purgatory" when you complete the game.

HOW TO PATCH
Apply the xdelta patch on a clean Neo Kobe HDI image of the game. Alternatively, you can open your HDI with Disk Explorer and copy the contents of the "FILES" folder intro it, preserving directory structure and overwriting everything in the process. In that case, be aware that in your previously existing save files, item names will stay in Japanese. Oh, and by the way, the game no longers needs a boot disk to run after patching. Enjoy a disk-swapping-free experience.

WHAT IS DONE
- All menus (save/load, status, options)
- Souls' names
- Main map
- Location names
- Item names
- Dialogs for using healing and stats enhancing items + the Icarus Wings

WHAT NEEDS DOING
- The "1" taking place of the "E" in the floppy related messages. Pointer issue. I haven't figured out how the game stores it yet.
- Item descriptions. It's quite a bitch to do because you actually get them from a character, and that the info he can provide you is very slowly updated through the game (think the Chocobo Sage in Final Fantasy VII), making tests quite difficult to do.
- Character names in dialogue. Serious lack of space here.

WHAT WON'T BE DONE
- Full dialog.
- Some error messages about boot disks. You don't need them anymore, so why bother ?

TRANSLATOR NOTES
I've altered a bit some stuff to make it closer to the mythological elements they take source in. For example, the ointment you get from Medea is called "magic ointment" in the game, but according to the Golden Fleece legend, it's "impervious ointment", so I kept the real thing. Same goes for some location names such as "Acheron River" instead of "River of Hell". 