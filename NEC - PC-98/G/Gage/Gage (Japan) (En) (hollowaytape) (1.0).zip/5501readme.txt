Gage ENGLISH TRANSLATION PROJECT

VERSION 1.0

4/13/2020

This is a full English translation release for the PC-98 game, Gage which was developed by Mick Albert of Mindware. All the wall/sign text, action lines, and remaining text have been translated and reworked. The only text which has been unchanged is from the User Disk Creation setup but screenshots and a text document are included to help guide you if needed.


If any issues arrise, please inform @MrRichard999 on twitter of anything.


To play this game you will need to create a personal USERDISK. This can be made by inserting the UM disk into FDD1. Follow the prompts and you will be fine.

If you already have the USERDISK created, just place the GAME disc in FDD1 and the USERDISK in FDD2.


CREDITS

Major Text Modifications by MrRichard999

Encrypted Text Modifications & Extraction/Reinsertion Tool by hollowaytape

Translation work done by AgentOrange

SPECIAL THANKS

To Mick Albert for making Gage and giving the thumbs up for us changing the game to English! Thank you!

Also to Pasokon Deacon for showing this game on Twitter!	
