  ___ _ _ _     ___              _   ___
 / __(_) | |__ | _ \___  __ _ __| | |_  )
 \__ \ | | / / |   / _ \/ _` / _` |  / /
 |___/_|_|_\_\ |_|_\___/\__,_\__,_| /___|
  Silk Road 2 for the Sharp X68000

Silk Road 2 English Patchdisk Readme

The patchdisk will copy game files to itself as part of the process. For this reason, it should not be redistributed after being used.

The patchdisk allows patching only the files that need to be patched instead of needing the whole game disk to be what it expects. If your save file or others that do not need to be patched are different, it won't care. It also supports multiple options and versions of the game.

It should be used on an emulator. You will need to patch the disk image after running it once with patchdisk-dat.bps or patchdisk-txt.bps anyway, and it is safer than using it on a real machine if something unexpected happens. Use as your own risk.

• • • • • • • • • • • • • • • • • • •

You will need:

1. A copy of Silk Road 2.

2. A copy of the Human 68k v3.02 operating system that you can boot off of. Only the basic operating system with the COMMAND.X commands is needed.

3. Some way of running them. XM6 Pro-68k works.

4. A bps patcher. Floating IPS works.

• • • • • • • • • • • • • • • • • • •

Short Instructions (for people who know how to use an X68000)

1. Boot the Human 68k v3.02 OS. If booting from a disk, it does not need to remain in the drive.

2. Put the Silk Road 2 disk in drive B or D. Put the patchdisk in the other drive.

3. Navigate to the top directory of the patchdisk, where FILE and RUN.BAT are. The bat files must be run with the command prompt at this location.

4. Run RUN.BAT. Note which bps it says to use and remove the patchdisk when it is fully finished.

5. Patch the patchdisk image with the correct bps, and re-insert it into the drive. Silk Road 2 must be in drive B or D as before.

6. Navigate to the correct place as before, and run PATCH.BAT to patch the game. Alternatively you can run file\fix to fix the game without translating it, or file\nofix to translate the game without fixing it.

• • • • • • • • • • • • • • • • • • •

Full Instructions

You may boot the Human OS from a disk or the hard drive. These instructions will assume you are using a disk with only two floppy disk drives available, on an emulator using disk images.

1. Boot the system with the Human 68k v3.02 disk in any drive. Once the system is fully booted and the command prompt is available, remove the disk. Enough parts of the OS should remain in memory to use.

2. Insert the game disk into drive B or D, and insert the patchdisk.xdf disk into any other drive.

3. Navigate to your patchdisk where RUN.BAT and FILE are located, if it is not there already. It is not enough to run the bat file, the command prompt must be in the correct place.

To check if you are in the right place, input "dir" without quotes and press enter. This should list FILE and RUN.BAT. If it doesn't, navigate to the drive the patchdisk is in. If the disk is in drive C, to go to it you would type "c:" without quotes and press enter.

4. Type "run" without the quotes and press enter, then press a key when it pauses and says to press any key. This will run a script that will look for Silk Road 2 in drives B and D, and copy the needed files from it to the patchdisk. If successful, it will tell you which patchdisk bps you need to use with it.

5. Wait for the disks to fully finish any reading and writing, then remove the patchdisk from the drive.

The contents of the patchdisk need to be exact. Do not mess with it in ways not instructed until patchdisk-dat.bps or patchdisk-txt.bps has been applied to it.

6. Patch the patchdisk.xdf image with patchdisk-dat.bps or patchdisk-txt.bps, depending on which it told you to use. This will translate the game's files that got copied to the patchdisk and prepare it for the next step.

If the bps patch does not work then
• You might not have removed the patchdisk from the drive first. An emulator might not write changes to the disk image file until the disk is ejected.
• It might not have finished writing before you removed it from the drive.
• You might be using the incorrect patch.
• You might be patching the incorrect disk. The patchdisk bps files are for the patchdisk once it has copied all the files to patch, not the game disk.
• Your game might not be compatible. This will happen if a file it needs to patch is different than expected.
• The copying might not have happened in an expected way.
• An emulator might not be writing to the disk file, but instead saving changes to another file.

7. Re-insert the now patched patchdisk. Silk Road 2 should be in drive B or D.

8. Navigate to the disk as before. This time "dir" should display FILE and PATCH.BAT.

9. Type "patch" without the quotes and press enter. This will attempt to patch the game in drive B or D.

There are two other options. Instead of "patch" you can use "file\fix" or "file\nofix". These need to be run from the same location "patch" does. Do not navigate to the FILE directory to run them.

file\fix
This will try to fix configuration problems without translating the game. This allows you to fix it while leaving it in Japanese.

file\nofix
This will copy the translated files to the game without trying to fix configuration problems.