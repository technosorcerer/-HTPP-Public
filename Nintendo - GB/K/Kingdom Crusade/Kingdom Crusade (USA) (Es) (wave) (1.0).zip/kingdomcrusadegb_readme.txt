Kingdom Crusade (Game Boy)
Traducción al Español v1.0 (28/05/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Kingdom Crusade (USA).gb
MD5: 79603fd837abd36b72d73f959e0ae749
SHA1: ceca61f9ee1e549ca5b70bf620159cf2c2290423
CRC32: 920202dc
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --