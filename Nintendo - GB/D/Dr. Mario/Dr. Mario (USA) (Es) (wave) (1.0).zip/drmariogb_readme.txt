Dr. Mario (Game Boy)
Traducción al Español v1.0 (27/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dr. Mario (W) (V1.1).gb
MD5: 921bdff008475aa2c5344e1a0d110910
SHA1: d31d67d0682515c7c85deaa1752b02231150e5bf
CRC32: f0225dd0
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --