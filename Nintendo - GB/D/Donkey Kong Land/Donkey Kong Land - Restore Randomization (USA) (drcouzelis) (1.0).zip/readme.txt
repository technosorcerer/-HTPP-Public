A patch for Donkey Kong Land (NA) for Game Boy.

There's a bug preventing the animation from playing while ducking. This patch restores that functionality.

David Couzelis
drcouzelis@protonmail.com
2024-10-27
