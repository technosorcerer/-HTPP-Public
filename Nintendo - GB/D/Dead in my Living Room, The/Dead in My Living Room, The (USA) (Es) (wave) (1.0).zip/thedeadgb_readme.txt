The Dead in my Living Room (Game Boy)
Traducción al Español v1.0 (30/01/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
thedead.gb
MD5: 020397a93cb6b897716c4f261e9a339e
SHA1: 9ac54df0bdcdf49895f13ff2eeb65e5231628e0e
CRC32: 2a4ea175
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --