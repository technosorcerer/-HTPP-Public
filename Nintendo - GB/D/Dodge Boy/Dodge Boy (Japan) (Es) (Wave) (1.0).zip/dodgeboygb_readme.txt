Dodge Boy (Game Boy)
Traducción al Español v1.0 (08/06/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dodge Boy (Japan).gb
MD5: d9c82bf67ad459f08676a1c7cb9037f3
SHA1: b48eb2bdc34588847728936491dadda67394f9b7
CRC32: f58dc358
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --