 .=============.
( ULTRAMAN BALL )
 '============='

Full english translation.

This is an addendum for the patch done by Suicidal Translation.
A few things were corrected in order to finalize their patch:
-A better title screen
-Super Gameboy Border translated
-Area Select screen translated
-Endings credits translated
-Checksum fixed

2 patchs are provided:
-UltramanBall_SuicidalAddendum.ips to apply on the english patched ROM
-UltramanBallEnglish100.ips to apply on a clean No-Intro ROM

This patch must be applied on the NO-INTRO ROM:

Ultraman Ball (Japan) (SGB Enhanced).gb
CRC32: 468D1A2E
MD5: 90A0BC783FBE56748989D8FAD9AE48ED
SHA-1: 3CDFCFB1A88D0CBFEB1C7B12751409FAF69BBA02
SHA-256: 5D8520EE6DEA9A6A07C4329B39E3E51CE4B479AEFF357270505222655B405A09

Staff:
FlashPV: Hacking, graphic work
Just J: Ending credits translation
Inverse: Initial haking
Takamichi Suzukawa: Initial translation

Version history:

V 1.0: Final Release