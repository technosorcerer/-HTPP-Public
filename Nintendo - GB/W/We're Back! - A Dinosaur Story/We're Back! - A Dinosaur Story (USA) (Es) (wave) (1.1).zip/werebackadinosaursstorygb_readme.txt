We're Back! - A Dinosaur's Story (Game Boy)
Traducción al Español v1.1 (19/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Arreglada intro

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
We're Back! - A Dinosaur's Story (U) [!].gb
MD5: c0d8ed063b30614c71d15d4d0ff08ffe
SHA1: ef58224f406cdf66bbe3797e2ef82a453fb1c18c
CRC32: c811560b
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --