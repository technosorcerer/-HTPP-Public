Wario Land - Super Mario Land 3 (Game Boy)
Traducción al Español v1.0 (21/01/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Wario Land - Super Mario Land 3 (World).gb
MD5: d9d957771484ef846d4e8d241f6f2815
SHA1: ae65800302438e37a99e623a71d1c954d73c843e
CRC32: 40be3889
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --