Agro Soar (Game Boy)
Traducción al Español v1.0 (19/09/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Agro Soar (Australia).gb
MD5: c8bab3886324f6aec60b65d8584453a1
SHA1: d635761f247301fe6bae4d71ee67ceef384ca53a
CRC32: 9b7945ea
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --