Arcade Classic No. 3 - Galaga & Galaxian (Game Boy)
Traducción al Español v1.0 (10/05/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Arcade Classic No. 3 - Galaga & Galaxian (USA) (SGB Enhanced).gb
MD5: 19fd29efaf7ea9e314bd613954a92169
SHA1: 739671d6cf151fa5527d68f78345197d278cdf19
CRC32: 6a6ecfec
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --