Esta � uma boa tradu��o feita pelo tradutor Guto. Os textos est�o traduzidos e parcialmente acentuados, mas os gr�ficos infelizmente n�o foram editados.

Author: Guto

Author's website: http://www.gutotraducoes.cjb.net

Completion: 100%

Genre: A��o/Plataforma 