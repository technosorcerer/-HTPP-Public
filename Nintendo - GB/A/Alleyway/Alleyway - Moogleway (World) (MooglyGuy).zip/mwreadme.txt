Title: Mooglyway

Game: Alleyway

System: Gameboy / Gameboy Color / Super Gameboy / Gameboy Pocket

Author: MooglyGuy - mega64man1@mailpanda.com

Description: This is a difficulty hack for Alleyway, and I do believe it's the
	     first hack that's ever been done of Alleyway. It changes every
	     level, ramping up the difficulty to insane amounts. If you can
	     beat all of the levels without cheating and without using
	     savestates on an emulator, you're officially an Alleyway master.
	     This also changes the title screen to the appropriate title,
	     lets you start the game with 15 lives and have a maximum of 15,
	     and you receive an extra life every 500 points instead of 1000.

Bugs: Currently if you play the game on an emulator the emulator will complain
      about having an incorrect checksum. This shouldn't be a problem if you're
      playing it on an actual Gameboy, but it might get annoying on an emulator.
      Eventually I'll figure out how to redo the checksum and there will be no
      bugs.