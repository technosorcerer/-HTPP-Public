Alleyway (Game Boy)
Traducción al Español v1.0 (15/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Alleyway (W) [!].gb
MD5: 91128778a332495f77699eaf3a37fe30
SHA1: 0cf2b8d0428f389f5361f67a0cd1ace05a1c75cc
CRC32: 5cc01586
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --