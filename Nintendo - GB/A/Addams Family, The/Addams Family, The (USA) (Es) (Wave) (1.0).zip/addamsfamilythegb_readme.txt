The Addams Family (Game Boy)
Traducción al Español v1.0 (05/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Addams Family, The (U) [!].gb
MD5: f629f0b6d156bec6acb9e6b9da4ad4e3
SHA1: 8710ceecbe3e7ade67c0362cc3b455aceb67a90d
CRC32: c170a732
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --