Adventures of Lolo (Game Boy)
Traducción al Español v1.0 (10/07/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Adventures of Lolo (Europe) (SGB Enhanced).gb
MD5: 8f6b6ef366a787852f664d945c86eb72
SHA1: e09277358a7fd4f3a6206464dd9d39f3abe66a53
CRC32: 176d2eeb
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --