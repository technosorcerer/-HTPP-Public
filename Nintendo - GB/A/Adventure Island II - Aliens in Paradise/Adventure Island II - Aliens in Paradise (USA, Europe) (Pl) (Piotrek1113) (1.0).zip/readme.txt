***PL***
Dzi�kuj� za pobranie tego t�umaczenia gry Hudson's Adventure Island 2 na Gameboya!

�eby zainstalowa� t�umaczenie nale�y posiada� tylko program Lunar IPS oraz oryginalny ROM gry (w wersji USA, Europe).

Mi�ej zabawy!
~Piotrek1113

***ENG***

Thank you for downloading this translation of Hudson's Adventure Island 2 for the Gameboy!

To install this translation you need only Lunar IPS and original ROM of the game (USA, Europe version).

Have fun!
~Piotrek1113