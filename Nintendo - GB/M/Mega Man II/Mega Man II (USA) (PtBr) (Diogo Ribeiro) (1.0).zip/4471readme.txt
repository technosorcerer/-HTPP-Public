

                              MEGA MAN 2
                         Game Boy, 1991/1992

                       Tradu��o Portuguesa (PT)

------------------------------------------------------------------
1. Sobre
2. Conte�dos & Uso
3. Hist�rico & Notas sobre o Patch
4. Contacto
------------------------------------------------------------------

------------------------------------------------------------------
1. Sobre
------------------------------------------------------------------

 Apenas escolhi o Mega Man II porque queria tentar algo r�pido
 no campo de tradu��o/edi��o de ROMS. � basicamente isso! Demorei
 cerca de duas semanas a traduzir, editar gr�ficos e a testar
 a tradu��o.


------------------------------------------------------------------
2. Conte�dos & Uso
------------------------------------------------------------------

 Este ficheiro ZIP deve conter:

 - M2GBPT.ips        - O ficheiro IPS para o Mega Man II
 - M2GBPT_Readme.txt - Este ficheiro de texto, em Portugu�s

 Para jogar o Mega Man II em Portugu�s, apenas � necess�rio
 aplicar o patch com o patcher preferido (Lunar IPS recomendado)
 na vers�o Norte Americana do ROM de "Mega Man II" para Game Boy.

 Os dados do ROM original devem ser:

 CRC32:              E496F686
 MD5:                7FE07271D04ED9E0BC0663DDE55A2AE4
 SHA1:               334F1A93346D55E1BE2967F0AF952E37AA52FCA7
 Header Checksum:    0x72 (Ok)
 Global Checksum:    0xE6C4 (Ok)

 Uma vez aplicado, o ROM com o patch deve ter:

 CRC32:              B3382A05
 MD5:                F8B790D0EB232876DE844AD1278DCD6F
 SHA1:               9ECC00CEC3476D937EABA9BF28EA7460419F65B8
 Header Checksum:    0x72 (Ok)
 Global Checksum:    0xFEA4 (Ok)

 Pode ver estes valores com o programa Game Header, dispon�vel em:
 http://www.no-intro.org/tools.htm


------------------------------------------------------------------
3. Hist�rico & Notas sobre o Patch
------------------------------------------------------------------

 In�cio do projeto: 12 de abril, 2019;
 Fim do projeto: 25 de abril, 2019

 Texto: 100%
 (Isto inclui: Nomes de armas, iniciais das armas, Ecr� de T�tulo,
  Game Over e o menu de Passwords)
 Gr�ficos: 100%

 Nota: As letras inclu�das no jogo s�o "�", "�", "�" e "�".

 Note: Tamb�m inclui aspas extra para o inimigo Have "SU" Bee;
       em vez de HAVE�SU�BEE, o jogo agora indica HAVE�SU�BEE.

 O jogo usa v�rias fontes, e at� tem uma n�o usada no c�digo,
 o que me levou fora de rota algumas vezes, mas est� tudo feito.
 Tamb�m pensei em corrigir as anima��es do Mega Man (algumas
 est�o incompletas, na verdade), mas fica para outra altura.
 Talvez.

 Cada letra ocupa um "tile" inteiro, pelo que decidi encolher as
 letras novas. Ficam meio estranhas, mas at� me ocorrer ou criar
 uma fonte melhor para o jogo, ficam como est�o.

 Apesar de ser bastante f�cil de o fazer, "Password" permance por
 traduzir dado que � generalizado o suficiente, at� em Portugu�s,
 para que n�o seja necess�ria a altera��o.

 Por outro lado, os nomes de inimigos e dos Robot Masters est�o
 nas suas vers�es originais porque soariam r�diculos ou a coisas
 sem significado em Portugu�s (alguns nem significado t�m em
 Ingl�s); a transfer�ncia de substantivos e nomes pr�prios
 nem sempre funciona. N�o estamos a falar de um Dragon Quest IX,
 onde os nomes dos inimigos s�o deliciosos e repletos de
 trocadilhos.

------------------------------------------------------------------
4. Contacto
------------------------------------------------------------------

 Para qualquer coment�rio, cr�tica, sugest�es ou erros relativos
 a este patch de tradu��o para Mega Man II, enviem e-mail para:

 diogo.fa.ribeiro @ gmail

 Tamb�m me podem encontrar no Romhacking.bet com o nome "4lorn".

 Tudo de bom.




