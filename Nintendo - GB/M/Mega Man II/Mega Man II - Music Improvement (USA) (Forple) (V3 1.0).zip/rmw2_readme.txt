This is the release of Rockman World 2 Music Improvement V3. 
This would normally have gone on RHDN, but its closure threw a
wrench into those plans, plus I needed to incorporate some 
feedback from the prior release of this soundtrack into the 
game as well.

If you want to use this in a Romhack for whatever reason, 
please feel free to do so, but I would appreciate credit.

Credits:
forple: Main hacking/Music rearranging/Driver reverse engineering
Accuracy/Sun Rays: Sound driver reverse engineering and assistance
Superdisk: Sound converter for sound driver
Kak2x: Sound driver bankswitching code
Hiroto Nakamura: Programmed the original game and sound driver, plus original song arranger
Kenji Yamazaki: Composed the soundtrack.

Changelog:
1.0: Initial release.