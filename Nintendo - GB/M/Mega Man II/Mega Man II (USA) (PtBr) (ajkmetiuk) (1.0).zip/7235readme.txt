Tradu��o de Mega Man II para GB v.1.0

Progresso: 100%

V1.0 - primeira vers�o.

Como aplicar a tradu��o:

Eu criei o patch usando o aplicativo Lunar IPS, que pode ser baixado no site da PO.B.R.E.
Link direto: https://romhackers.org/utilitarios/patching/lunar-ips/

Depois de baixar, abra o programa, clique em "Apply IPS Patch", selecione o "MM2_GB_BR_v1_0_ajkmetiuk.ips" e clique em "Abrir"
Na tela seguinte, selecione a rom, clique em abrir e pronto! Seu jogo estar� traduzido.
Creio que seja compat�vel com qualquer emulador que emule GB, eu utilizei o VisualBoyAdvance.

ROM CRC32: E496F686

Tradu��o: ajkmetiuk

Contato:

Caso encontre algum bug, n�o deixe de enviar seu feedback no f�rum que quando poss�vel irei verificar e corrigir os erros e assim lan�o futuras vers�es...
