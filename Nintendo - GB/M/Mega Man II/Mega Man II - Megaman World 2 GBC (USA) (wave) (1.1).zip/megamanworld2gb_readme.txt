Mega Man World II GBC (Game Boy Color)
Traducción al Español v1.1 (20/04/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en el de Specialagentape.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V1.1: Arreglado error en clave y game over.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mega Man II (USA).gb
MD5: 7fe07271d04ed9e0bc0663dde55a2ae4
SHA1: 334f1a93346d55e1be2967f0af952e37aa52fca7
CRC32: e496f686
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --