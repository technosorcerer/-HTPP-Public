Known Issues:
- Napalm man is "red" in re-fight due to limitation of background color
- Boss re-fight capsule stage, BG priority issue? Mega Man will disappear briefly going into capsule, going "behind" background
- Mega Man pal. color wrong after "Satellite Cannon"  Fight, if using a special weapon
- Mega Man pal. color wrong after unnamed boss, most known by "Bridge" or "Defense System",  if using a special weapon.
