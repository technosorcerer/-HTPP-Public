Mickey Mouse (Game Boy)
Traducción al Español v1.0 (16/12/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mickey Mouse (UE) [!].gb
MD5: fecc3f5a95ccaec78f83892933d8159f
SHA1: b8e708dfe7496c712bd3ef171429d81cb6619252
CRC32: fc50dee7
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --