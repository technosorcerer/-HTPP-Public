Mega Man World 5 DX (Game Boy Color)
Traducción al Español v1.0 (12/04/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en el de marc_max.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mega Man V (USA) (SGB Enhanced).gb
MD5: ceb17d831b410d91aa41bf2819cbed82
SHA1: 9a7da0e4d3f49e4a0b94e85cd64e28a687d81260
CRC32: 72e6d21d
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --