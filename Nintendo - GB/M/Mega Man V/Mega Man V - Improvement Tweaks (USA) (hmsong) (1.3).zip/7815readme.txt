
================================================================================
Mega Man V (Gameboy) -- Improvement Tweaks
v1.3

by hmsong
================================================================================

Mega Man V (aka Mega Man World 5) was the last Mega Man game for the original
Gameboy.  Mega Man I ~ IV were all ports of the NES Mega Man games with slight
changes, but Mega Man V was entirely original, with a new Mega Buster (called
Mega Arm), bosses, and story.  And it was great.

Sadly, the game had some flaws:

1. Mega Man's defining mechanic was that you would get a particular weapon from
   a specific Robot Master (known in this game as Stardroids), which would be
   effective against another specific Robot Master, and so on.  However, for the
   first 5 bosses (4 Robot Masters and the mid-way boss), the same 2 weapons
   were effective against 4 bosses (one of which is semi-effective), and the
   other 2 weapons were entirely useless against them.  And none of the weapons
   from the 8 Robot Masters were effective against Neptune (one of the first 4
   Robot Masters).  And in some cases, even the effective weapons were rather
   impractical in how they were used.  For example, Black Hole did a big damage
   against Mercury, but it was one of the weapons that required you to get close
   to Mercury (bad idea, because Mercury's attacks made you lose random items).
   It would have been MUCH better to make Venus weak to Saturn's Black Hole or
   even Tango, as they can destroy Venus's bubbles and attack it at the same
   time.

2. In the Wily Star, you fight the Gameboy-unique-bosses from the past games --
   Enker, Quint, Punk, and Ballade.  While it is certainly great to pay homage
   to the past games, most of them posed no challenge at this point, making the
   fights pathetically easy (esp Enker and Quint).

3. Mega Arm's regular bullets (uncharged Mega Arm) were supposed to be
   ineffective against some bosses (namely Uranus, Terra, and Sunstar), but they
   were still able to do damage against them.  Uranus and Sunstar in particular,
   the bullets did the same damage as the fully-charged Mega Arm.  That didn't
   make any sense.

4. Tango (the new animal weapon you start with) was ineffective against all
   bosses, making it almost useless.  At least Beat (from the previous game) was
   good against the normal enemies, but Tango was simply useless due to it being
   so random and hindered by obstacles and pits.  Tango was semi-effective
   against the first phase of the final battle, but the other effective weapons
   were MUCH better choices, due to Tango generally sucking.

5. Spark Chaser (Terra's weapon) was quite overpowered in this game, so much so
   that it made most of the enemies and bosses laughably easy (all the more so,
   because of how energy efficient it was).  That included most of the final
   bosses, and even Sunstar.

6. The boss rooms were quite boring, as they all had the exact same flat ground
   stages.

7. Some of the stage rooms were very boring, especially the Wily Star shortcuts.

8. There were too many free Large E Tanks in the stages, which made this game
   far too easy.

9. The secret crystals were all obtainable with Break Dash and Deep Digger,
   which made hunting for them kind of boring, not to mention that you were
   forced to replay the level, regardless of what boss order you chose.


So, this patch does the following:

1. Distributes the boss vulnerabilities more evenly (including Tango), in order
   to increase the usefulness and availability of the weapons against their
   specific bosses -- not just in damage, but in practical usage sense.  Some
   are very effective, and some are semi-effective.  Generally, any given boss
   is weak to one weapon from the first 4 bosses, and another from the later 4
   bosses -- see the attached chart for more detail.

2. Makes the GB-unique-bosses from the past Mega Man games match their previous
   weapon defense, to certain level (the weapons aren't the same, after all).
   That includes Enker and Quint taking only 1 damage from all Mega Buster (err,
   Mega Arm), as their games didn't have the charged shot.

3. Changes up the Mega Arm's effectiveness for bosses that were supposed to be
   immune to Mega Arm's bullets.  Specifically, Uranus can be damaged by semi-
   charged+ shot (1 damage, CL works), Terra can be damaged by fully-charged
   shot (3 damage, CL fails), and Sunstar can only be damaged by fully-charged
   shot (1 damage, CL fails).

4. Makes Spark Chaser less overpowered against Wily 3 (Brain Crusher's capsule)
   by making it do 1 damage per hit.  It's still the safest, and probably the
   best weapon against Wily 3.  However, as per Mega Man World tradition (the
   final weapon must be effective against at least one phase of the final
   bosses), it is now effective against Wily 1 (Knuckles).

5. Changes some of the boss rooms to make the fights more interesting (and
   difficult).  Specifically, Neptune and Quint's rooms have obstacles (you can
   use Uranus's Deep Digger to remove them), and Jupiter and Punk's rooms have
   insta-death traps.

6. Minor changes to the items, stages, and enemies (includes unused enemies).

7. Some of the crystals require methods other than Break Dash or Deep Digger to
   obtain -- namely, MH upgrade and Rush Jet.  You can get them all in one-go
   without having to replay the level.

Known issues:
- Neptune can sometimes get "stuck" on a wall and not be able to move forward
  (unless you get behind him).  However, he'll still be able to attack.
- For the first Jupiter fight, if you enter the boss room very slowly, then you
  will immediately fall in the pit and die.  So enter normally.  Also, if you
  fall in the pit after beating him, then you won't die and still get the power
  up (although you won't be able to see most of the normal victory animations
  until the screen changes).
- If you fall on the spikes after beating Punk or Jupiter in Wily Star, then you
  won't die.
- Normal Mega Arm bullets do not bounce off Uranus (although they don't do any
  damage).


If anyone has any specific requests regarding the boss fights, then let me know.
I'm open to suggestions, and I may be able to work out a solution.



Applying Notes:

- This is for Mega Man V US rom, but it's also compatible with marc_max's Mega
  Man World 5 DX.  While the order shouldn't matter, but to be safe, apply
  MMW5DX patch first, then apply this patch.


If you have any questions, requests, or error reports, then please DM me on
Romhacking.net (click my name, then click my name next to "Forum Account", then
click "Send PM").



Change Logs:

1.3
 - Minor changes to the items, stages, and enemies (includes unused enemies).
 - Other minor changes.

1.2
 - Minor fix.

1.1
 - Changed around the weaknesses.
 - Neptune and Quint's stages have obstacles (you can use Deep Digger to remove
   them).
 - Jupiter and Punk's stages have insta-death traps.

1.0
 - Initial release.
