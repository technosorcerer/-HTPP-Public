
================================================================================
Mega Man V (Gameboy) -- Boss Fight Changes
v1.1

by hmsong
================================================================================

Mega Man V (aka Mega Man World 5) was the last Mega Man game for the original
Gameboy.  Mega Man I ~ IV were all ports of the NES Mega Man games with slight
changes, but Mega Man V was entirely original, with a new Mega Buster (called
Mega Arm), bosses, and story.  And it was great.

Sadly, the game had some flaws:

1. Mega Man's defining mechanic was that you would get a particular weapon from
   a specific Robot Master (known in this game as Stardroids), which would be
   effective against another specific Robot Master, and so on.  However, for the
   first 5 bosses (4 Robot Masters and the mid-way boss), the same 2 weapons
   were effective against 4 bosses (one of which is semi-effective), and the
   other 2 weapons were entirely useless against them.  And none of the weapons
   from the 8 Robot Masters were effective against Neptune (one of the first 4
   Robot Masters).

2. It seemed like the devs didn't think things through when making certain
   bosses weak against particular weapons, as those "effective" weapons were
   very impractical against those specific bosses, despite them doing big
   damages.  For example, Black Hole did a big damage against Mercury, but it
   was one of the weapons that required you to get close to Mercury (bad idea,
   because Mercury's attacks make you lose random items).  It would have been
   MUCH better to make Venus weak to Black Hole, as Black Hole can absorb
   Venus's bubbles.

3. Grab Buster, Black Hole, and Deep Digger were effective against their
   specific Robot Masters, but were completely ineffective against most, if not
   all other bosses in the game.  Black Hole in particular was especially
   useless, because by the time you got this weapon, you had already beaten the
   Robot Master that it was effective against (i.e. Mercury).  Of course, it can
   still be used against Mercury in the rematch in the Wily Star, but that was
   still a wasted potential.

4. In the Wily stage, you fight the Gameboy-unique-bosses from the past games --
   Enker, Quint, Punk, and Ballade.  While it is certainly great to pay homage
   to the past games, most of them posed no challenge at this point, making the
   fights pathetic (esp Enker and Quint).

5. Mega Arm's regular bullets (uncharged Mega Arm) were supposed to be
   ineffective against some bosses (namely Uranus, Terra, and Sunstar), but they
   were still able to do damage against them.  Uranus and Sunstar in particular,
   the bullets did the same damage as the fully-charged Mega Arm.  That didn't
   make any sense.

6. Tango (the new animal weapon you start with) was ineffective against all
   bosses, making it almost useless.  At least Beat (from the previous game) was
   good against the normal enemies, but Tango was simply useless.  Tango was
   technically semi-effective against the first phase of the final battle, but
   the other effective weapons were MUCH better choices, due to Tango generally
   sucking.

7. Spark Chaser (Terra's weapon) was quite overpowered in this game, so much so
   that it made most of the enemies and bosses laughably easy (all the more so,
   because of how energy efficient it was).  That included most of the final
   bosses, even Sunstar.

8. The boss rooms were quite boring, as they all had the exact same flat ground
   stages.

9. The secret jewels were all obtainable with Break Dash and Deep Digger, which
   made hunting for them kind of boring.


So, this patch does the following:

1. Distributes the boss vulnerabilities more evenly (including Tango), in order
   to increase the usefulness and availability of the weapons against their
   specific bosses -- not just in damage, but in practical usage sense.  Some
   are very effective, and some are semi-effective.  Generally, any given boss
   is weak to one weapon from the first 4 bosses, and another from the later 4
   bosses -- see the attached chart for more detail.

2. Makes the GB-unique-bosses from the past Mega Man games match their previous
   weapon defense, to certain level (the weapons aren't the same, after all).
   That includes Enker and Quint taking only 1 damage from all Mega Busters (err,
   Mega Arm), as their games didn't have the charge shot.

3. Changes up the Mega Arm's effectiveness for bosses that were supposed to be
   immune to Mega Arm's bullets.  Specifically, the bullets won't do any damage
   (no reflect animation though), but the charged fist will do 1 damage (and CL
   upgrade can do additional damages, as usual).

4. Makes Spark Chaser less overpowered against the bosses by making all of them
   not weak to Spark Chaser, except one of the Robot Masters.  It is still the
   safest (and probably the best) weapon against Wily 3.

5. Changes some of the boss rooms to make the fights more interesting (and
   difficult).  Specifically, Neptune and Quint's rooms have obstacles (you can
   use Uranus's Deep Digger to remove them), and Jupiter and Punk's rooms have
   insta-death traps.  Note that I had to change one of the rooms after Punk to
   enable this.

6. Sunstar is now immune to everything, except the charged Mega Arm.  It makes
   the fight more difficult, but also more interesting.

7. Some of the jewels require methods other than Break Dash or Deep Digger to
   obtain -- namely, MH upgrade and Rush Jet.

Known issues:
- Neptune can sometimes get "stuck" on a wall and not be able to move forward
  (unless you get behind him).  However, he'll still be able to attack.
- For the first Jupiter fight, if you enter the boss room very slowly, then you
  will immediately fall in the pit and die.  So enter normally.  Also, if you
  fall in the pit after beating him, then you won't die and still get the power
  up.  However, you can't see most of the normal victory animation until the
  screen changes.
- If you fall on the spikes after beating Punk or Jupiter in Wily Star, then you
  won't die.


If anyone has any specific requests regarding the boss fights, then let me know.
I'm open to suggestions, and I may be able to work out a solution.



Applying Notes:

- This is for Mega Man V US rom, but it's also compatible with marc_max's Mega
  Man World 5 DX.  While the order shouldn't matter, but to be safe, apply
  MMW5DX patch first, then apply this patch.


If you have any questions, requests, or error reports, then please DM me on
Romhacking.net (click my name, then click my name next to "Forum Account", then
click "Send PM").



Change Logs:

1.1
 - Changed around the weaknesses.
 - Neptune and Quint's stages have obstacles (you can use Deep Digger to remove
   them).
 - Jupiter and Punk's stages have insta-death traps.

1.0
 - Initial release.
