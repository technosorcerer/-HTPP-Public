"Magic Knight Rayearth"
Traducción al Español Ver. 1.0 (19/01/2023)
por Max1323 (Traducciones Max1323).
Basada en la gran traducción de LIMPEMCO! Translations.
---------------------------------------------------
Descripción:
Un día, Hikaru, Umi y Fuu fueron invocadas a otro mundo, Cephiro,
por la Princesa Emeraude. Luego Guru Clef les contó la leyenda de las
Guerreras Mágicas y liberaron su magia, a partir de ese momento, las
chicas viajaron para salvar a la Princesa Emeraude y a la tierra
de Cephiro de Zagato.

Desarrollado: Pandora Box
Publicado:    Tomy
Lanzamiento:  02/06/1995 (JAP)
---------------------------------------------------
Acerca del proyecto:
-La traducción fue hecha gracias a las herramientas 
creadas por Supper, ccmar (Edición y testeo) y TheMajinZenki (Script).

-La mayoría de los textos están traducidos. Se agregaron
los caracteres españoles. Solo los necesarios ya que no había
mucho espacio para agregar.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS (PC)
Utilizar UniPatcher (Android)
Utilizar Rom Patcher JS (Parcheador Online):
https://www.romhacking.net/patch/

Archivo IPS
Magic Knight Rayearth (Japan) (SGB Enhanced).gb
File Size     256 KB
File MD5      06B75E657DEBD1568F18D369CC2422DD        
File SHA-1    4F77031946E62772A241A9B5B046D7FCF6A28EA8
File CRC32    94838A81