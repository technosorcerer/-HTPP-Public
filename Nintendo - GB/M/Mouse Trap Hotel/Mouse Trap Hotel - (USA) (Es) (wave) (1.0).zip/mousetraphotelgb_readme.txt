Mouse Trap Hotel (Game Boy)
Traducción al Español v1.0 (24/02/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mouse Trap Hotel (USA).gb
MD5: cd8eb18dec915d8e2ea73f097d33ba04
SHA1: 301658fd29b1a9277690a3c6e43dc68c8a277c1d
CRC32: 6edf07e5
65536 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --