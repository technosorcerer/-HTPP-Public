ABOUT THIS MOD/HACK

------ Metroid II: SGB Enhanced ------

Wait... Metroid II with a Super GameBoy border and custom palette?!

Yup, sure is!!

Thanks to "Marc Max" for their AWESOME Super GameBoy injector program, you can now enjoy Samus's second adventure in SGB glory!

The Samus, Chozo and Metroid sprites were edited from the game, the gunship is entirely custom. The background mimics the promo poster/boxart.

I really hope y'all enjoy my first venture into ROM modding. Here's to hoping for more to come in the future!

Ryallasha N'vetay
-------

KEY FEATURES:

• Custom Palette
• Custom Full Color Border
• Looks AMAZING with a CRT filter!

-------

ROM INFO:

Database match: Metroid II - Return of Samus (World)
Database: No-Intro: Game Boy/Color (v. 20210227-015730)
File/ROM SHA-1: 74A2FAD86B9A4C013149B1E214BC4600EFB1066D
File/ROM CRC32: DEE05370

