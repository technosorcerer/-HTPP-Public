Mario's Picross X
------------------
Version 1.0 - 09/08/2018
Ross Adkin


Overview
--------
Mario's Picross X is a full hack of Mario's Picross, with 256 new puzzles to solve.

All of the puzzle solutions in Mario's Picross X are based on retro gaming sprites and images, containing characters such as Mario, Sonic, Kirby, Link and Jet Set Willy.

The package for this hack contains solutions for each of the puzzles, including references to the games/systems on which they are based.

Good luck!


ROM Details
-----------
The rom to patch is Mario's Picross (UE) [S][!].gb

No-Intro Name: Mario's Picross (USA, Europe) (SGB Enhanced)
(No-Intro version  20130802-061634)
ROM/File SHA-1: 9712F37171B8A0CDC99A60170EA7B2AED161195E
ROM Size: 262144 (40000)
ROM CRC32: F2D652AD


Contact
-------
If you find any bugs please let me know	either by email or on the Romhacking forums
TidusRenegade
theadkin@hotmail.com