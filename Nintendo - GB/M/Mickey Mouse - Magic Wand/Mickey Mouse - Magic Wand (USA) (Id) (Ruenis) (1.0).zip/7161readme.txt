Mickey Mouse - Magic Wands!
Di terjemahkan oleh Ruenis

Semua teks dialog dalam permainan sudah di terjemahkan semua ke dalam Bahasa Indonesia


Cara Patch:
Pilih salah satu format patch antara BPS atau IPS ke dalam ROM image untuk menerapkan filenya

Mickey Mouse - Magic Wands! (USA, Europe) (SGB Enhanced)
File/ROM SHA-1: 90A181EE7D42941BCE3B425077D6570DA0E2FB2C
File
ROM CRC32: F0482567
