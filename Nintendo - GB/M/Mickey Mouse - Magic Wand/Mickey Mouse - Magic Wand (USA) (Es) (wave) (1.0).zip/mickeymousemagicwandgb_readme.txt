Mickey Mouse - Magic Wand (Game Boy)
Traducción al Español v1.0 (22/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mickey Mouse - Magic Wand (U) [S][!].gb
MD5: 38b65d28ac0bd619f5dee5a45d5fc542
SHA1: 90a181ee7d42941bce3b425077d6570da0e2fb2c
CRC32: f0482567
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --