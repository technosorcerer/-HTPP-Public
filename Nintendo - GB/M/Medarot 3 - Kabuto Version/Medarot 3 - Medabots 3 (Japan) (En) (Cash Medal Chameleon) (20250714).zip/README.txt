There are two sets of patches provided, along with a sha1sum file that shows the resulting sha1sum of the patched ROMs for verification (the BPS format should handle this automatically anyway though).

EN - A more literal patch which retains the Japanese phrasing and terminology (e.g., 'Medarot' instead of 'Medabot', 'Kikuhime' instead of 'Samanatha', etc...)

EN-US - A more Americanized translation, aiming to match as much of the Nelvana dub terminology as possible (probably more familiar to those who have played the Medabots RPG on the GBA, but note that we didn't change the setting to America like that game did)

We've gone to great lengths to make sure just about everything is translated (except the debug menu). 

If you notice any spelling mistakes or other bugs, please feel free to report them in https://github.com/Medabots/medarot3/issues or add a message in the #medarot-3-translation channel in the Medabots discord (the invite link is in the sidebar of the Medabot subreddit https://www.reddit.com/r/Medabot/). Please make sure that the issue reproduces on real hardware or an accurate enough emulator (such as BGB or SameBoy).