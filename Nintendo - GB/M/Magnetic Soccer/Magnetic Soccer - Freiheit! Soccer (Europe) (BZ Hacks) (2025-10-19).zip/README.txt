Free yourself and your friends by beating the nazis in soccer!

Patch to Magnetic Soccer (Europe).gb