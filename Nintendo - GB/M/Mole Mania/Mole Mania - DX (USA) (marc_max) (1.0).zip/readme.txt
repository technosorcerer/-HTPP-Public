================================================

               MOLE MANIA DX v1.0
           by kensuyjin33 & marc_max

================================================


Mole Mania is a cult classic puzzle game for the original Game Boy.
Guide Muddy Mole through more than 200 screens full of puzzles to rescue his family from Jinbe the farmer.

This remastered version, allows you to enjoy the game in full color for the first time ever in 30 years! 

FEATURES
- full color conversion
- slowdowns removed
- some graphical fixes and tweaks
- works in real hardware and emulators

It also comes with a little addition: press SELECT during gameplay to choose shadow color for
Muddy, the main character.


PATCHING INFORMATION
--------------------
You must provide the original Mole Mania (USA/Europe) ROM:

Mole Mania (USA, Europe) (SGB Enhanced).gb
CRC32: 2c36c74c
MD5:   f28ade3926852a8ad2e449c274683956
SHA-1: 37085973519d61e17797693b23016493da56a462
 
Apply the patch here: https://www.romhacking.net/patch/
(some emulators may require a .gbc extension, so make sure you rename it after
patching)



CHANGELOG
---------
v1.0 (2025-09-30)
- first version



CREDITS
-------
kensuyjin33 - graphics
marc_max - reverse engineering & hacking

thanks to all betatesters for their deep testing!
thanks to the GB Colorization team for their help and advice!
thanks to you for your patience!


DISCLAIMER
----------
This is a fan created hack, no copyright or trademark infringement is intended.
Mole Mania is a trademark © of Nintendo. We are not affiliated nor endorsed by Nintendo.
