# PLAGUEMON: LOST DIARIES

This is an art project, based on pokered disassembly, where the region we all know got nuked
and monsters started mutating.


* Discord: [**PLAGUEMON**]
https://discord.gg/ChexDXF
