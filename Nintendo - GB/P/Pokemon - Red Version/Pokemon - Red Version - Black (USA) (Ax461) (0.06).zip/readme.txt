Intro:

This hack recreates the game based on the famous pokemon black creepypasta as close as possible to the original story.

Read the story here:
http://tinycartridge.com/post/866743831/super-creepy-pok�mon-hack

Features:

This game is complete, and every feature from the creepypasta is implemented.

Thanks to
*. triumph (from Skeetendo), who pointed out many things that I haven't noticed, and for testing.
*. Reidd, for the sprites and for his work on his recreation of pokemon black.
*. Pokemon Red disassembly, without it this project woudn't have been possible.