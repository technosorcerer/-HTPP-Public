import pokemontools.vba.vba as vba
import pokemontools.vba.keyboard as keyboard
import pokemontools.vba.autoplayer as autoplayer
autoplayer.vba = vba
