"""
pokecrystal/pokered VBA automation module

dependencies:
    python-vba-wrapper (vba_wrapper)
    vba-linux
"""
