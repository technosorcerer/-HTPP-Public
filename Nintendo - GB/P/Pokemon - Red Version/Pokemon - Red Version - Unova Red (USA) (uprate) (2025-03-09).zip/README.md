# Pokemon Unova Red by Azure_Keys
# Forked by devolov

https://www.pokecommunity.com/showthread.php?t=413878

# Includes the following additions not in Unovared:
  * Faster Nurse Joy
  * Can't run from ghost with PokeDoll
  * EXP All more like Gen 5 and togglable
  * Press B to go to Run option in battle
  * Bag Sorting
  * Trees get Cut Forever
  * Added running
  * TMs are reusable
  * HMs can be forgotten
  * Added Field Moves and can be used if a Pokemon can know the move
  * Flash and Fly are in the menu for any Pokemon who can learn it
  * TM name gets displayed
  * Added a perfect Cleanse Tag and PokeDoll can be used to make trainers not see you
  * Expanded Bag
  * Razor Wind and Skull Bash boost stats
  * Poison moves buffed
  * Added PokeVial and portable Teleporter
  * Added Thief Balls which allow stealing non-Indigo Plateau/Gym enemy Pokemon. If used on Rival, then Rival's future battles will not include the stolen mon.
  * Press Select opens bicycle
  * Faster text scrolling
  * Safari Zone has 750 steps
  * Abandon learning is now continue learning
  * Selecting already out Pokemon when in shift mode will continue the fight
  * Removed Low-Health Beep
  * Attack after waking from sleep
  * Poison, burn and leech seed do an 8th of max HP
  * Celadon Hotel PC restored
  * Removed missingno glitch
  * Lt. Surge's gym trash cans do not use the proper trash cans for the locks
  * Fixed healing moves will fail if max HP is 255 or 511 points higher than current HP
  * Fixed Focus Energy
  * Fixed moves that have 100% accuracy will miss in 1/256 uses
  * Fixed CoolTrainerFAI switches all the time at 10-20% health instead of 25%
  * Fixed PP restoring items do not account for PP Ups when used
  * Fixed Moves that have a 100% chance to critical hit will not crit in 1/256 uses
  * Removed Missingno glitch

Built from pokered

# Pokémon Red and Blue

This is a disassembly of Pokémon Red and Blue.

It builds the following roms:

* Pokemon Red (UE) [S][!].gb  `md5: 3d45c1ee9abd5738df46d2bdda8b57dc`
* Pokemon Blue (UE) [S][!].gb `md5: 50927e843568814f7ed45ec4f944bd8b`

To set up the repository, see [**INSTALL.md**](INSTALL.md).


## See also

* Disassembly of [**Pokémon Crystal**][pokecrystal]
* irc: **irc.freenode.net** [**#pret**][irc]

[pokecrystal]: https://github.com/kanzure/pokecrystal
[irc]: https://kiwiirc.com/client/irc.freenode.net/?#pret
