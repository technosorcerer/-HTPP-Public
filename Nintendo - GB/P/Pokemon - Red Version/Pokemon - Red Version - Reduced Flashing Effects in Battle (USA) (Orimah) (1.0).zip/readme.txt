In the future I would like to make a patch which cuts out the slow flash part of the wild encounter animation. As a compromise I included an optional patch which removes those by always using the dungeon encounter animations. (Do not use both patches at the same time, dungeon patch includes move animation changes)

If you see any bugs, unusual move animations or have any other minor problems with the patch, please contact OrimahROSAT@gmail.com .

All instanced of move flashing effects have been removed. Some moves below have been tweaked if they looked awkward or identical to other moves with no screen flash.

Tweaked animations with flashing:
	-Darkens screen instead of flashing
		Blizzard
		Bubblebeam
		Fissure
		Guillotine
		Mega kick
		Mega punch
		Spore
		Thunderbolt
	-Lightens screen instead of flashing
		Explosion
		Self-destruct


Tweaked animations with slow screen flashing:
	-Replaced with lighten screen
		Confusion
		Hypnosis
	-Replaced with darken screen
		Night shade
	-Replaced with wavy screen
		Dream eater
		Psybeam

New animations:
	Disable
		-Similar to thunder wave, based on gen 2 animation
	Flash
		-Lightens and smoke poof
	Glare
		-Darkens and beam, based on gen 2 animation
	Leer
		-Beam, based on gen 2 animation