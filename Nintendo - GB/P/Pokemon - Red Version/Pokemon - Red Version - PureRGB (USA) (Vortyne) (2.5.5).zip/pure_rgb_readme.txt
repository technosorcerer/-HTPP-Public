Use lunar IPS to patch Pokemon Blue's english rom for PureBlue or PureGreen. For PureRed, use Pokemon Red's english rom.

Download the latest version of PureRed, PureGreen, or PureBlue here (patch files at bottom of page):
https://github.com/Vortyne/pureRGB/releases/latest

Report any bugs or issues here: 
https://github.com/Vortyne/pureRGB/issues/new?assignees=&labels=&template=blank_issue.md

Pokemon PureRGB on github: 
https://github.com/Vortyne/pureRGB/blob/master/README.md

Full features documentation: 
https://github.com/Vortyne/pureRGB/blob/master/FEATURES.md

Info like learnsets or tm locations can be found here: 
https://github.com/Vortyne/pureRGB/wiki

