This hack adds player selection to the beginning of the game during Oak's speech. There are three characters to choose from: Red, Green and Blue. If you chose the female character, the player character sprite is green (in the overworld, battle screen, town map screen, trainer card, etc). All references to the player character's gender in the games script have been gender neutralized (ie, Mom says "all boys leave home" to "all kids leave home"). If you chose to play as Oak's grandson, the regular player character and rival switch places, along with their mom/sister and all references to their family are swapped. Playing as the rival makes your character blue. The standard character is red. The sprites for the girl character were made by BurstXShadowzX on DeviantArt and adapted into the rom. The sprites for the rival character were custom made.

This is built on the latest version of the Pokered-GBC rom. In addition to colorizing the rom, the Pokemon sprites have been replaced with their Gen 2 equivalents, back sprites expanded to 48x48 and the audio engine updated to Crystal's. A few other changes were made, listed below. The hack is not a "catch them all" hack, in that you cant get all Pokemon in a single play through, but all version exclusives and trade-evolve Pokemon are available.

The game has been play tested through to the end twice. If you find any errors, especially with the coloration or Red, Blue or Green's sprites in-game, please leave a review stating where the issue is.

Special thanks to Danny-E33. He provided much insight into the function of his colorization code and without him the hack would not have been possible. 
---

Gameplay changes:

The chance to encounter Ekans on routes 4, 9 and 10 have been replaced with Sandshrew. Ekans can still be found on other routes.
The chance to encounter Oddish on routes 12, 13, 14 and 15 have been replaced with Bellsprout. Oddish can still be found on other routes.
The chance to encounter Growlithe on routes 5 and 6 have been replaced with Vulpix. Growlithe can still be found in the Pokemansion.
Magmar has been added to the Pokemansion in the same way as he appears in Blue.
Pinsir has taken the place of Syther as a prize at the casino. Syther is still available in the Safari Zone.
Casino Pokemon prices have been adjusted. (Pinsir, 2800; Dratini, 4600; Porygon, 6500 -- mixture of Red and Blue's prices)

Pokemon trades have been adjusted:
    Route 11 Nidorana for Nidorano trade has been replaced by Graveler for Haunter (Named Josef, Graveler evolves upon receipt.)
    Cinnabar Island Seel for Ponyta trade has been replaced by Haunter for Electabuzz (Named Casper, Haunter evolves upon receipt.)
    Cinnabar Island Raichu for Electrode trade has been replaced by Machoke for Magmar (Named Apollo, Machoke evolves upon receipt.)
    Cinnabar Island Venemoth for Tangela trade has been replaced by Kadabra for Kangaskhan (Named Houdini, Kadabra evolves upon receipt.)

Fixed a text error with the base game when Oak gives you Pokeballs.
The sprite when the player character is surfing had its palette changed to match Seel.