Another batch of annoying bug fixes have been ironed out, and the game should be a lot more playable now. Unless some more huge bugs are discovered, I expect the number of releases to really slow down now. As always, make sure to save the game in an indoor map (I would recommend your house or a Pokemon Center) to ensure your save loads smoothly. 1.1 to 1.2 seems to work, though I have yet to test 1.0 saves.

To use, simply apply the given patch to a clean copy of Pokemon Red. The SHA1 should be ea9bcae617fdf159b045185467ae58b2e4a48b9a, which matches a retail copy or one built from pret/pokered. Alternatively, you can straight-up build KEP from source.

The given patch works with apps like LunarIPS and (I think) xdelta.

Version: 1.2
Find releases at https://github.com/PlagueVonKarma/kep-hack/releases

The fixed bugs (for this patch) are as follows:

When reloading a save inside certain indoor areas, the border tile would not load correctly, allowing you to walk out of bounds and crash the game.

Some static encounter field sprites wouldn't disappear after battle. While this wouldn't be an issue for most, the Cactormus on Brunswick Trail would impede progress if this glitch occurred, so a special case was added to ensure this won't happen again.

Getting the Vermilion Beauty gift would lock you out from getting the Silph Co Lapras gift later.

Okay, NOW it's impossible to trap yourself in Cinnabar Volcano.

Viewing the Town Map in Viridian Pre-Gym would show the player as being in Cerulean.

Psychic, Psywave, Night Shade and Dazzling Gleam wouldn't shake the full screen when used.

A lot of small text fixes