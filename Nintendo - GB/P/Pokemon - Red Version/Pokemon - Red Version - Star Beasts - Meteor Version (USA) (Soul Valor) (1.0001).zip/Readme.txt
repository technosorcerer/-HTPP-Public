This is Gen 1 Dex replacement and other things that is best experienced blind.
If you need to know about what or where beast or moves is, consult the other documents in the zip.
Documentation is WIP and will be finalized in time.

Have fun!

Credits:
Vast Fame for majority of original sprites
Mufeet for new sprites, improved sprites, border, trainer sprites, etc
Trézzy for the Star Beasts logo
LucasPucas for the "Meteor Version" text
Game Freak for Pokemon Red
Pret for the Pokered disassembly on GitHub, without which this wouldn't have been possible