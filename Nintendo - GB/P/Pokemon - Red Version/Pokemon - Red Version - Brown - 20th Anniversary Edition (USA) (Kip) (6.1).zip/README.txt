Pokémon Brown 20th Anniversary Edition - version 6.1
****************************************************

This is Pokémon Brown! Thanks for downloading this game; we hope you enjoy it.
Visit https://rainbowdevs.com/setup for an illustrated guide for setting up
your game, or read below.

If you want to find what's new in this version, check the changelog.txt file.

To set up the game, you will need:
* An English ROM of Pokémon Red (do not use a previous Pokémon Brown ROM).
* Game Boy emulator. We recommend one of the following:
  * BGB (https://bgb.bircd.org/): this will run on Windows, or under Wine on
    Linux and Mac.
  * SameBoy (https://sameboy.github.io/): runs on macOS (with additional
    features), iOS, Windows and Linux.
  * Retroarch (https://www.retroarch.com/) with mGBA core: runs on Steam Deck.
  * Emulicious (https://emulicious.net/): multi-system emulator that runs on
    any platform with a Java runtime available.

  Other emulators may also work; try them if you want. DO NOT USE ANY VARIANT
  OF VISUAL BOY ADVANCE (including VBA-M): we know those emulators aren't
  accurate enough for the game to run properly.

1. Access the patcher here: https://www.marcrobledo.com/RomPatcher.js/
   Or go to the RomPatcher.js-2.9.1 folder and double-click "index.html"
2. Place the ROM file and patch file in their respective fields.
3. Click "Apply patch" and download your game.

Updating your game
******************

If you have played a previous version of Pokémon Brown 20th Anniversary 
Edition, you can use the same save file in the new version. You can also 
update from Pokémon Brown 2016 (TPP) and 2014, however in this case we do 
recommend starting a new game.

To update any save file, you must follow the instructions below.

|| Please ensure to always BACK UP your save file before attempting! ||

To safely update, you need to either have Fly, Teleport, Dig or an Escape
Rope, then:

1. Save at any location where you can use Fly/Teleport/Dig/Escape Rope.
2. Load your save in Brown 20th Anniversary.
3. Graphics will be glitched, don’t worry. Use Fly/Teleport/Dig/Escape Rope
and after warping, you can continue as normal.

FAQ
***

- How do I play the game in color?
Pokémon Brown will play in Game Boy mode (black & white), Game Boy Color mode 
(brown palette by default) and Super Game Boy mode (limited colors). You will 
need an emulator that supports Super Game Boy (SGB) mode. Notably, Delta for 
iOS does not currently support SGB mode - consider switching to SameBoy if you 
would like to play in color.

- How do I get rid of the border?
This is a setting in your emulator. Be sure to disable the SGB border.

- The Eevee I got from the Casino won't evolve.
This was a glitch from 6.0 that has been patched. To fix this, have the Eevee 
in your party and speak to Cable Club lady in any Pokémon Center.

- I'm stuck in the Elite Four room and the door is locked!
This was a glitch from 6.0 that has been patched. Simply save in the room and
reset the game. Speak to the NPC again and the door will open.

- How do I make my old Pokémon update to their new stats?
Talk to the trading NPC at any Pokémon Center and the party’s stats will be
updated (no specific message will appear, don’t worry).

- My Tyrogue is now a Noibat, what happened?
Brown 2014/TPP had internally three different Tyrogues. In order to allow
Noibat to have wild spawns we had to overwrite one of the old Tyrogue entries
(specifically the one that evolved into Hitmontop). There is nothing we can do
about this and you’ll need to capture another tyrogue. Alternatively, evolve
any Tyrogue you have in your old savegame before using it in the 2024 version.

- What happened to the old Eevee/Tyrogue species?
On Pokémon Brown 2014/TPP Tyrogue and Eevee had multiple internal species,
which determined what they would evolve into. This was a way to add new
evolutions, but in the 2024 new evolution methods for Eevee and Tyrogue have
been added, making this unnecessary.

You can still use them and they will function normally but they won’t evolve
nor learn any new moves. Talk to any trading NPC at any Pokémon Center to
update any old Eevee/Tyrogue you may have.

- My old Eevee/Tyrogue won’t evolve nor learn any new moves:
        Please refer to “What happened to the old Eevee/Tyrogue species?”.

- What's .ups? What happened to .ips?
We switched patch formats to help prevent people patching the incorrect
ROM. Don't worry, it works exactly the same way!

Editing tools
*************

Special versions of editing tools have been created for Brown.

These are available from our website or Discord (browntools.zip). You can also
download them separately below:

* Brown Dumper: https://github.com/suloku/BrownDumper
* Brown Editor: https://github.com/suloku/BrownEditor
* ClassicMap: https://github.com/suloku/ClassicMap


Additional information
**********************

Some of the new features take inspiration or are directly adapted from the
source code of other amazing projects like: 

* Shin Pokered (https://github.com/jojobear13/shinpokered)
* PureRGB (https://www.pokecommunity.com/threads/494837)
* Red++ (https://github.com/JustRegularLuna/rpp-backup)
* Yellow Legacy (https://github.com/cRz-Shadows/Pokemon_Yellow_Legacy)


You can find future updates and contact us at the following:

Website: https://rainbowdevs.com
Twitter: https://twitter.com/rainbowdevs
Bluesky: https://bsky.app/profile/rainbowdevs.com
Mastodon: https://donphan.social/@rainbowdevs
Reddit: https://reddit.com/r/pokemonbrown
Discord: https://discord.gg/pmysaXn

Have fun!

About us
********

    ____        _       __                  ____
   / __ \____ _(_)___  / /_  ____ _      __/ __ \___ _   _______
  / /_/ / __ `/ / __ \/ __ \/ __ \ | /| / / / / / _ \ | / / ___/
 / _, _/ /_/ / / / / / /_/ / /_/ / |/ |/ / /_/ /  __/ |/ (__  )
/_/ |_|\__,_/_/_/ /_/_.___/\____/|__/|__/_____/\___/|___/____/

RainbowDevs are collective of passionate Gameboy developers with decades of
experience.

We are coders, artists, musicians, designers, and every position in-between —
crafting new stories and worlds for everyone explore while pushing the 
boundaries of classic, retro hardware. Everything we do runs on original, 
classic hardware, as our passion for the original games and worlds runs deep.

Ex cineribus resurgam, ferox et potens.