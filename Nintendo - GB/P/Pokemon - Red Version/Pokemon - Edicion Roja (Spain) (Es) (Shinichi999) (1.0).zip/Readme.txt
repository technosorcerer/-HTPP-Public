July 16th, 2024


SPANISH:
---------------------------------------
Pok�mon Verde (Versi�n Latinoamericana)
---------------------------------------

Versi�n 1.0


Descripci�n:

Pok�mon Verde fue el primer videojuego de la famosa franquicia en salir a la venta en Jap�n, contando la historia de un ni�o 
que parte de Pueblo Paleta con la misi�n de convertirse en el mejor entrenador Pok�mon del mundo.

Este juego nunca sali� de Jap�n. Adem�s, en Latinoam�rica no cont�bamos con una traducci�n propia para los juegos de Pok�mon, recibiendo primeramente  
los videojuegos en ingl�s y posteriormente heredando la traducci�n de Espa�a, la cual conten�a t�rminos muy distintos a los utilizados 
dentro de la franquicia en Am�rica Latina. 

Por esta raz�n decidimos crear nuestra propia versi�n de Pok�mon Verde en Espa�ol Latino.

Caracter�sticas:

-Traducci�n 100% en Espa�ol Latino (Neutro)
-Se respetan los ataques y t�rminos del anime doblado en M�xico
-Se corrigieron errores de traducci�n de la versi�n original
-Se elimin� la censura de algunos di�logos aplicada en occidente
-Se puede combatir e intercambiar Pok�mon sin ning�n problema con versiones oficiales

Cr�ditos y agradecimientos a Montblanc por crear esta versi�n de Pok�mon Verde que fue usada como base para el Espa�ol Latino.

Cualquier bug o error que encuentres, favor de reportarlo al e-mail: contactoanmtvla@gmail.com

�Esperamos que disfrutes esta nueva versi�n!





ENGLISH:
---------------------------------------
Pok�mon Green (Latin American Version)
---------------------------------------

Version 1.0


Description:

Pok�mon Green was the first video game of the famous franchise to go on sale in the West, telling the story of a boy who departs 
from Pallet Town with the mission of becoming the best Pok�mon trainer in the world.

This video game was never released outside of Japan. Plus, in Latin America we didn't have our own translation for Pok�mon games, 
first receiving the video games in English and then inheriting the translation from Spain, which contained very different terms
from those used within the franchise in Latin America. 

This is why we decided to create our own version of Pok�mon Green in Latin American Spanish.

Characteristics:

-100% Latam Spanish Translation (Neutral)
-The attacks and terms of the dubbed anime in Mexico are respected
-Translation errors of the original version were corrected
-Censorship of some dialogues applied in the West was eliminated
-It is possible to battle and trade Pok�mon with official versions without any problem

Credits and thanks to Montblanc for creating this version of Pok�mon Green, which was used as the basis for the Latin American Spanish translation.

Any bug or error you find, please report it to the e-mail: contactoanmtvla@gmail.com

We hope you enjoy this new version!