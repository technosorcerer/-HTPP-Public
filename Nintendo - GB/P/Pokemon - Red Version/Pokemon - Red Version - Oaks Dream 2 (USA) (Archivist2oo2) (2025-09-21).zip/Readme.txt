Oaks Dream 2 V1.3
This Hack should be applied to pok�mon red.
In this hack you play as professor Oak, and your rival is Giovanni and instead of professor Oak there is prfoessor Fuji.
This hack MUST have been downloaded from Andy's Translations http://andytrans.cjb.net
Thank you and Enjoy the Game!!!