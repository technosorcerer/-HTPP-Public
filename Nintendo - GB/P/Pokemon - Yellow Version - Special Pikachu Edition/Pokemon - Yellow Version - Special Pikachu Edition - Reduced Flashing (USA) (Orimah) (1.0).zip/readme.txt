Pokémon Yellow Reduced Flashing v1.0 (Parity with Red/Blue Reduced Flashing v1.1)

If you see any bugs, unusual move animations or have any other minor problems with the patch, please contact OrimahROSAT@gmail.com .

All instances of flashing that I could find were either removed or reduced. Please contact me if you find any instances of flashing that I had missed or otherwise notice an issue with the patch.

Please not this is NOT an "epilepsy safe" patch. This game still contains patterns which may be harmful for those with photosensitive epilepsy.

Changes:

	Pikachu's interact animation after learning thunderbolt or thunder now brightens the screen instead of flashing. This can still be used to peek in dark areas like rock tunnel.

	Wild non-dungeon battle transitions now darken the screen instead of doing a slow flash.

	Quick flash moves (e.g. Thunderbolt, Mega Punch) have been toned down to only lighten the Pokémon's sprites instead of a full-screen black/white flash.

	All long screen flash moves (e.g. Confusion, Hypnosis) now only flash the Pokémon's sprite.

	Some moves have been further tweaked:
		Disable
			No dark screen effect as the lightened flash does not help when the dark screen effect is active.
		Glare
			No dark screen effect as the lightened flash does not help when the dark screen effect is active.
		Hyper Beam
			Removed screen flashing as the lightened flash does not help when the dark screen effect is active.
		Leer
			No dark screen effect as the lightened flash does not help when the dark screen effect is active.
		Reflect
			Removed screen flashing as the lightened flash does not help when the dark screen effect is active.
		Thunder
			Removed screen flashing as the lightened flash does not help when the dark screen effect is active.
		Thunderbolt
			The black ball effect on the enemy Pokémon is slowed to match that of Thunder shock and other moves.