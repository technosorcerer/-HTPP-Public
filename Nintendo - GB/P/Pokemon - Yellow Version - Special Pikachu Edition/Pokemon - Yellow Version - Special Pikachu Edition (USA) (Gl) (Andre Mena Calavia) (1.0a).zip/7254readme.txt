Ola,

son André Mena Calavia, coñecido in Romhacking.net coma RetGal, acrónimo de "Retro Galicia".

Este é un parche de tradución ó galego completamente funcional do xogo "Pokémon Amarillo", de agora en adiante referido "Pokémon Amarelo".

Comecei a traballar neste proxecto en 2021, antes de tomar un descanso das tradución que retomei a finais de 2023 con Super Mario World, Super Mario Bros, Metroid e Godzilla. Ó rematar este último retomei "Pokémon Amarelo", do que so fixera a tradución ata o primeiro ximnasio (e daquela maneira) e a Pokédex completa (somentes isto último levaríame case dúas semanas).

Sen dúbida atopábame ante o traballo máis largo dos que levo feitos (máis que Arcana para SNES ó castelán, outro xogo longo pero lineal, e co que ademáis contara coa axuda do traballo previo de Lukas); nembargantes, a idea de acadar esta tradución ó galego dun xogo no que deixei tantas e tantas horas de cativo (que me axudaron a coñecer case tódolos recunchos do xogo) era afouteza dabondo para acada-lo meu obxectivo.

Teño que deixar claro: este traballo usa a ROM da versión orixinal en castelán, polo que foi un traballo polo miúdo e a mán; existe unha deconstrucción da versión en inglés ("Pokémon Yellow") na que é moitísimo máis doado traballar e recompilar, aparte que tódalas ferramentas de modificación do xogo que atopei na internet están pensadas para esa versión en inglés (por exemplo, os textos en castelán localizan en zonas da ROM diferentes, a pouca distancia pero dabondo para que os punteiros non funcionen e dean erros ou as ferramentas de texto de terceiras persoas non teñan en conta vogais con til, por citar); isto é importante porque foi en 2021 cando xa comezara a tradución, ainda que pouco avanzada, e non tiña intención de ciscar ese traballo feito (carneirada miña, recoñezo).

Non vou entrar en moitos detalles, como teño feito noutros arquivos de texto de tradución previas, sobre as loitas que tiven coa ROM; só direi, de maneira xeral, que neste proxecto (alomenos nos meses de 2023-2024 nos que traballei nel) descubrinme canto mellorei na lectura de código hex e a traballar con punteiros de maneira manual, cousas que me fixeron sentir moi moi satisfeito cada vez que acadaba un novo logro (por exemplo, expandi-lo texto dispoñible na Pokédex para as definición de cada especie, en concreto Magikarp para poder amplia-lo espazo de 3 hex de lonxitude "PEZ" por un de 5 para "PEIXE" en troques do traballo de 2021 no que deixara "PX.", así sen máis) (ou acada-la tradución de "GHOST" por "ÁNIMA" que nin na versión en castelán acadaron, certamente estaba moi agochada e mesmo na deconstrucción do xogo inglés non está contemplada esta parte).

Unha vez lín que unha boa tradución non é a que se limita a trocar palabra por palabra, senon aquela na que o tradutor faina súa (aportando humor, comprendendo a historia que está a contar para reaxustar frases que non encaixen se se fai literal, metendo referencias ó público destinatario, etc); neste parche teño engadido moitas, MOITAS referencias e aportado matices a personalidade de personaxes (en concreto estou moi ledo co traballo feito con GARY, aínda me fai moita gracia le-la virulencia coa que di as cousas, quizáis vólvese máis serio cara o final do xogo pero aínda escacho cando asoballa ó protagonista con referencias galegas, é xenial).

A modo de trivia, procurei introducir as diferentes variantes dialecticas do galego nas personaxes; para tal fin relacionei cada vila e cidade de Kanto cunha cidade de Galicia e o Bierzo, e procurei que alomenos un habitante de cada lugar tivera un rasgo característico da fala; por exemplo, Cidade Azulona correspondería a Compostela, con algúns habitantes falando con gheada, seseo implosivo e engadindo o artigo "esto" ou dicindo "irmao" e "vacaciós". En troques, Vila Lavanda correspondería a Ponferrada, con habitantes empregando "mao", "tu", sen seseo nin gheada e algún teismo. Isto, por suposto, só foi unha ferramenta que usei para dar algo de variedade a como falan diversos NPC, pois non é a miña intención que houbera unha relación 100% exacta entre as cidades de Kanto e as de Galicia e Bierzo, nin que tódalas personaxes de cada vila presentaran os correspondentes dialectos. Polo xeral está extendido o uso do galego normativo, procurando que as personaxes falen o máis "natural" posible mentres que os textos xerais, menús e Pokédex empregan un galego máis "enxebre".

Teño que entoar, con todo, o "mea culpa" de ter usado lusismos; exemplo máis cantoso é o "evoluír" e as súas conxugación ("evoluíu", "evolúe"...) en troques do galego correcto "evolucionar". Existen outros, pero son máis sutís. Tamén teño que dicir que usei "koruño" para as personaxes CHUNGO ("MOTORISTA" na versión orixinal) sen eu ser falante de koruño... lamento se metín a pata con certas frases polo seu incorrecto uso, se alguén quere que engada correccións engado o meu contacto ó final deste arquivo.

Acho preciso avisar: aínda que moi esporádicamente, este xogo contén partes con linguaxe soez e palabras malsoantes. Quero deixalo claro xa que este parche foi pensado para persoas de +30 anos, que xa somos medrados, pero quizáis alguén quere introducir ós seus fillos no mundo pokémon a través dos xogos da primeira xeración e na nosa lingua; nese caso, queda o aviso. 




-- FERRAMENTAS USADAS --

Habituais:

♦ Tiny Hexer, a millor que coñezo para ler hex e aplicar táboas.
♦ CrystalTile2, sinxela para ler e modificar tiles.
♦ Paint.net, esencial para trocar gráficos.
♦ Papel e lápis.

Específicas deste proxecto:

♦ TGB_Dual, emulador especializado nos intercambios entre xogos Pokémon, co que comprobei non só se a tradución desta parte estaba ben aplicada senon a súa compatibilidade, alomenos, coas versión española, alemá e francesa, en calquera das versión dos xogos (Amarelo, Azul e Vermello).
♦ Wikidex, enciclopedia Pokémn na que informei de moitísimos detalles miúdos (maiormente relativos a información de Pokédex) e lendas Pokémon que engadín coma "ovos de Pascua" no xogo.




-- TROCOS QUE REALIZA ESTE PARCHE --

Atinentes a tradución:

♥ Pantalla de título.
♥ Nomes de personaxes.
♥ Textos de personaxes.
♥ Pokédex completa.
♥ Menús.
♥ Tiles de xogo (GIM --> XIM, SHOP --> SÚPER, etc)
♥ Engadidas grafías ("NON", ï, notas musicais, etc)
♥ Disposición do alfabeto na pantalla de nomes e alcumes.
♥ Diploma ó completa-la Pokédex.
♥ Pantalla cando se xoga na SNES coa SGB.
♥ Minixogo de Pikachu surfista.
♥ Créditos (todo o equipo orixinal respectado)
♥ Recoñecemento polo parche ó galego (cara o final dos créditos)
♥ Todo o traducible que atopei, a fin de contas.

Non atinentes a tradución:

♥ As ataques PANTASMA son agora súperefectivas contra o tipo PSIQUE, como é canon no anime dende o principio e nos xogos dende a segunda xeración.
♥ Paleta "black", que controla as cores de por exemplo cando es derrotado (en troques de ser todas do mesmo tono escuro, agora ten matices similares ás versións Azul e Vermella).

♥ De maneira adicional e optativa engado outro parche que agocha o nome do pokémon que vai usa-lo adestrador inimigo. Así, por exemplo, en troques de sai-lo texto "LORELEI vai empregar a CLOYSTER" sae a mensaxe "LORELEI vai empregar outro POKéMON". Isto é útil cando queres xogar en modo "trocar de pokémon" sen ter información previa de cal será o contrincante, facéndoo unha pinga máis difícil ó non dirpor desa vantaxe para preparar tipos de antemán; tamén serve por se queres pór a proba a túa memoria e lémbra-la orde dos pokémon inimigos.

Para empregar este "parche de inimigo agochado" primeiro hai que aplica-lo parche de tradución e despois este segundo parche. Como digo, é un parche optativo e non é preciso o seu uso para disfrutar da tradución orixinal. Se o aplicas e despois non queres seguir usándoo somentes tes que aplica-lo parche de tradución orixinal e voltará aparece-lo nome de maneira normal.

OLLO! Este parche optativo só é válido para a versión en galego! É dicir, pódese aplicar na versión en castelán e funcionará normal, pero ese texto aparecerá en galego, o que é algo raro para a xogabilidade cando o resto do xogo aparece en castelán.




-- QUE QUEDA POR FACER --

♣ Comprobar que todos estes trocos funcionen en consola real (GB e SGB)
♣ Saca-las versións "Azul" e "Vermello" (xa moi avanzadas, pero antes quero ver se se atopan erros na versión "Amarelo" e corrixilos nestas antes de sacalas ó público).




-- CONTACTO --

Se alguén quere contactar por algunha razón sempre estou dispoñible en Romhacking.net --> https://www.romhacking.net/forum/index.php?action=profile;u=91332

Tamén podedes contactar en retrogaliza@gmail.com para quen non sexades membros do foro de Romhacking e aínda así queirades manter contacto. Esta conta de correo non a emprego moito, polo que pode pasar un tempo "t" entre recibi-la túa mensaxe e lela. Procurarei estar máis atento nos días posteriores ó lanzamento do parche e as súas actualizacións (de habelas, que seguramente haxa).

Aburiño.

------------------------------------------

VERSIÓN 1.0a

♣ CheckSum é agora OK.