Thank you very much for playing Pok�mon Yellow: Cramorant Edition. Creating it was a labor of love and I hope you enjoy!
This hack replaces the following Pikachu with a Cramorant, among other changes.
This hack was made using the Pok�mon Yellow disassembly created by the Pok�mon Reverse Engineering Team as a base.
Some game features were borrowed with permission from "Pok�mon PureRGB" by Vortyne.

To play, please download the .bps patch and apply it to a clean English ROM of Pok�mon Yellow.
Download or use an online patcher of your choice to apply the patch to the ROM.
Load the ROM into your Gameboy emulator or flashcart and enjoy!

All the best.
-Cram-o-dev