# A subset of https://github.com/pret/pokemon-reverse-engineering-tools
