Thank you very much for playing Pok�mon Yellow: Cramorant Edition. Creating it was a labor of love and I hope you enjoy!
This hack replaces the following Pikachu with a Cramorant, among other changes.
This hack was made using the Pok�mon Yellow disassembly created by the Pok�mon Reverse Engineering Team as a base.
Some game features were borrowed with permission from "Pok�mon PureRGB" by Vortyne.

To play, please download the .bps patch and apply it to a clean English ROM of Pok�mon Yellow.
Download or use an online patcher of your choice to apply the patch to the ROM.
Load the ROM into your Gameboy emulator or flashcart and enjoy!

All the best!
-Cram-o-dev

NOTE: Some emulators have difficulty playing Cramorant's voice clips. If they sound too quiet, try using a different
emulator. For desktops I recommend mGBA or BGB.

Version 1.1 Changes:
Bugs Fixed:
- Pokemon will now always be afflicted with SLP when sleep status moves are successfully used.
- Game Corner coins can now be redeemed for $1500 if your total money is under $8000 and above $1499 like they should have been.
- The Super Rod will now fish up the correct Pokemon or tell the player if no Pokemon can be found. No more battles with glitchy Cue Balls or level 250 Arcanine.
- Rival 1's victory text on Route 22 has been formatted correctly and the Softboiled TM guy in Celadon has a minor text grammar fix.
- If a Ditto transforms into Cramorant and uses Gulp Missile, the fish animation graphics will also now appear by the player's Pokemon.
- A few more minor glitches have been (hopefully) fixed to provide a smoother experience.

Additions:
- Ekans has a 1% chance of appearing in the grass on Route 22.
- Cramorant can now learn Water Gun and Metronome by TM.
- The TM for Metronome can be bought from the Celadon Dept. Store.
- Repels can now be bought from the Pewter Pokemart.
- The salesman in the Mt. Moon Pokecenter now sells the player an Abra for $3000.
- Abra now learns Tackle at level 11.
- Many Pokemon found by Super Rod have had their levels buffed slightly. Starmie can also be fished up with a Super Rod in the bottom two floors of Seafoam Island.
- Added flavor text for the window in the player's bedroom.