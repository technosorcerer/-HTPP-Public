Pokémon Yellow Rom Hack

Hack Name: Pokémon Yellow 98 v1.5

Hack of: Pokémon Yellow

(DOWNLOAD AT BOTTOM OF PAGE)



Details:



This took me quite a while to figure out and I'm sure it would have been easy for people that understand coding, but I had to learn how just by constant failures assembling the game. I will happily provide credits where credits are due so if I have not properly credited someone, please inform me and I will do my best to make sure their work is appreciated.



Hello and thank you for taking a look at this hack.

This hack consists of several manga-inspired graphic changes as well as Spaceworld '97 backsprites.

Palettes for a few Pokémon were corrected to more appropriate colors; for instance, Eevee is now brown instead of green.

Speaking of green, this hack allows you to choose a girl option based on the Green character from the manga.



- Blue's frontsprite has been updated.

- Red's frontsprite has been slightly modified, and Red's backsprite is redone.

- New modified Oak frontsprite is also featured as a post HoF battle with a team inspired by the manga.

- Mew has been added to the Pokémon Mansion.

- Almost all of the gym leaders have had slight changes to their teams (inspired by the manga).

 (with a surprise addition to Giovanni's team that won't be spoiled here)

- Team Rocket had some changes to repetitive pokemon; just replaced a few dupes with Tauros & a few Pinsir.

- Jessie & James get a Lickitung later game.

- Pikachu can learn Surf.

- New blue sprite and slightly changed dialogue for pokemon tower battle.

- Crystal Onix



Differences from Legacy98:

Legacy98 was more of a project to appeal to fans of the legacy hack by Smithplays while bringing some updated graphics. All the sprites added to that hack were originally intended for my own hack here with Pokemon Yellow 98, my own idea of a definitve pokemon yellow. it's got closer to vanilla feels with smaller changes. it adds some cut content like mew or the professor oak battle at the end (different team inspired by manga). and small changes to gym teams that make sense with the manga. hard to say but in my mind this hack is very different to legacy98 as it is a completely different experience just with updated graphics.



This hack is generally considered complete, but there are plans to continue adding more to make it the definitive way to play Pokémon Yellow.



Videos:

(coming soon)



Screenshots:



NEW 98 Title:

title98.png



Spaceworld 97 -

 Backsprites:------------------------ NEW Green Frontsprite & Overworld:

20240608_011822.png ____ 20240608_012036.png 20240608_012308.png







   

NEW Red, Green Backsprites & Blue Front Sprite:-------Professor Oak (Mateo) Back & NEW Front:

20240608_011403.png 20240608_011937.png____ Screenshot1.png new98oak.png





Some NEWER features:

 

Raticate/PokemonTower Blue:--------------------------------- Crystal Onix:

grave.png ghostblue.png____ crysonix.png crysonix2.png



Credits:

Old Man Back Sprite (by SteppoBlazer) 

1717127697223.png

Oak Back Sprite (by Mateo)

1717127795615.png

(Spoiler) from Vortyne's Pure RGB hack.

[ISPOILER]Armored Mewtwo Sprite

mewtwo_a.png[/ISPOILER]

- All spaceworld 97 Back Sprites were ripped from the redstarbluestar hack by Rangi42

- Some of the sprites were borrowed originally but were remade into something of my own. if needed to give credit of where it came from originally,

it would be Ghost-missingno. on DeviantArt.



PLANNED CHANGES:

ghostblue22.png





Warning! This hack has been through VERY limited testing. let me know if anything comes up graphically that is corrupted in any way.

- Backup Saves! with each version update there is a possibility of corrupted saves. I wish it wasn't an issue but it's the only way I can continue to add cool things and fix issues. if you need anything from me, I will do my best to help.

(PKHEX Seems currently only able to change Pokémon stats/moves nothing else at the moment. and there is always risk in corruption.)



Changelog:
v1.2
-Touched up Prof. Oak Front Sprite
v1.3
-New blue sprite and dialogue for pokemon tower battle.
-Fixed moves for blue champion battle.
-Fixed moves for some gym leaders
-Added golbat to Koga
-Changed brock's omastar to omanyte.
v1.4
-fixed Blue's pokemon tower dialogue.
-fixed jessiejames corrupted sprite.
-fixed Blue's pathing in pokemon tower.
-fixed Silph Cos Rival Battle being overpowered.
(if any of the rival battles seem off let me know.)
-added Blue's raticate sign in Pokemon Tower.
-Touched up Prof. Oak Front Sprite again
v1.5
-fixed channler corrupted sprites
-added crystal onix
-added crystal cavern to rock tunnel b1f via ladder
v1.6
-removed extra ladder from crystalcavern
-Blue stays facing grave for first dialogue.
-added Broc overworld Sprite to PewterGym (from gen-II)
-changed up Blue's Ghost Sprite slightly and added ghost.

My Other Hacks:
PokemonYellow97

Related Hacks:
Legacy98
