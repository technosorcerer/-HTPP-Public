# Pokémon Static Yellow- A Gen 1 Hack with QOL improvements, but also trying to keep the same vibe as Gen 1!

My love of hacks and hacking came from Playing Red++ and Blue Kaizo. 
Small binary edits to disassembly have come a long way and I am greatful I found those 2 hacks many moons ago!

Features:  
- Second Branch: Gen 1 Graphics/Sprites
- Now you can Play Gen1 as either Red, Green, or Yellow.  
- All 151 Pokémons can be caught or evolved without trading. MEW IS OBTAINABLE  
- GEN 2 Sprites and Battle Graphics  
- Can Surrender in Battle by clicking RUN  
- NPC Tradeback Guy in FUCHSIA CITY- BILLS GRANDPAS HOUSE (evolve trade evolutions)  
- Trade evolution pokemon also evolve level up  
- Now you can take both fossils in MT. MOON!  
- Teams have mixed Pokémon (no more 5 pidgey teams)  
- IN-GAME MOVES/ EVOLUTIONS/ LEARNSET in POKEDEX  
- MOVEDEX BUILT INTO POKEDEX
- Infinite TM's (they are reusable like newer gens)  
- Gym Leaders, Rival, Rockets and other trainers had a buff in level, moves and parties (some parties to match Anime/Lets go Pikachu/References)  
- Move Relearner added in Cinnabar- Kris  
- Move Deleter added in Vermillion (undeletable HMs) – Kris
- Updated Pokeball/Pokedex sprites
- Fishing Rod Encounters Displayed in Pokedex
- EXP Bar on Status Screen- Blue
- Can’t deposit HMs- prevent softlock
- Traded Pokemon in Game can now be renamed with Name Rater in Lavendar
- UP/DOWN ON POKEMON PAGE/ IN BATTLE TO SEE POKEMON STATS
- Gym Leader Names on Trainer Card
- Restored “Presents” on Intro
- Trainers have perfect DVs and Better AI
- All overworld Pokémon icons have been updated (no more generic ones)
- Party Mini sprites have been updated
- Caught Pokémon icon added in HUD Battle
- Several POKÉMON had learnsets buffs (eg: Charizard Fly)
- Pikachu and Raichu can learn SURF through HM: Can do Surfing MiniGame now
- Pikachu can learn FLY (New Pikachu Flying Sprite) and now CUT
- PROF. OAK gives you 5 POKÉBALLS when you receive the POKÉDEX.
- TM names in BAG and MART (TM24 it says TM24 THNDRBLT)
- 50 item bag space
- Auto HM use (eg: surf, just touch the water and say YES)
- Deletable HM's
- Sort Items in BAG- Press Start while in bag
- PRESS SELECT IF HAVE BICYCLE to use it
- OAK Battle post game (ONCE POKEDEX IS COMPLETED)
- Message when PC is full
- Check IV/DV - hold start for DVs and select for IVs when click A on Pokemon STATS
- Blue EXP BAR
- Caught Icon in battle
- Catching a Pokemon that is sent to PC boxes will tell you when box is full and how many slots are left
- Moon Stone can be bought in Celadon Mart-
- Team Rocket Received a buff in levels and parties
- Reusable Repel B/W
- Engine Bugfixes
- Attack after waking up from Sleep
- Sleep engine fixed (it works now like gen 2 - max 6 turns)
- Removed 25% chance for enemy stat down moves to miss
- Swift will not hit throught Fly or Dig
- SS Anne Captain Takes SS Ticket
- Nurse Joy room on SS Anne
- Secret Key, Lift Key, Card Key Consumed when used
- Town Map in Start Menu
- Running and Surfing Sprites
- Lapras Swims in Fuchsia City
- Elevator time shorter and tells you what floor you are on
- Bill PC now says how many pokemon are in a box
- Bill PC has a Pokemon View Mode. Press select on Withdraw to see the Pokemon currently in the box
- Safari Zone has 2 modes: Classic (Vanilla Safari Game), and Free Roam (Roam with all Pokemon and catch Safari pokemon like all other routes)
- Can fly in Safari Zone, Viridan Forest, Celadon Roofs now
- Elite 4 door sound effect
- POKEDEX OVERHAUL: CHECK IT OUT FOR YOURSELF
- PC in Daycare
- CHEAT CANDY GIVEN AT START OF GAME TO HELP LEVEL UP/GRIND
- Eveevolution Pokemon sit next to Rival now
- ADDED TM51: FLAMETHROWER: IN CINNABAR MART
- Mr Mime in Red’s house after Erika
- Victory Road now needs FLASH to get through it
- Seafoam Islands now Blue
- Elite 4 members play Gym Leader Music
- EXP ALL IS NOW A KEY ITEM: TURN IT ON OR OFF FOR USAGE
- SS Anne returns after 6th Badge
- Janine is in Kogas gym training
- Overworld sprites for gym leaders
- GYM LEADER REMATCHES
- ELITE 4 REMATCHES
- Jenny and Joy Post Game Battle
- Coin Clerk in Celadon will sell coins in bulk after 4th Badge
- 2nd Plateau Mart after E4 beaten says ALL TMs
- SLOT FIXES
- BUG FIXES
- Ghost now deals SUPER EFFECTIVE on Psychic Pokémon

CREDITS: THE MOST IMPORTANT PART OF THIS
- PRET for disassembly of Pokeyellow
- Dannye- Created Pokeyellow Gen 2 repo, Pokered-gbc repos and much much more. This game is based on his Pokeyellow Gen2. Dannye did all the sprites, EXP Bar work, answered a lot of questions and is someone I can consider a friend
- Vortiene/PureRGB-  Another great person who has helped so many people in discord. His credit goes from Safari Zone options, Elevator times shorter, Overworld Sprites, SS Ticket and other key items being removed when used, Box Slot Space on Catching Pokemon, Lapras swimming in Fuchsia City, PC Box View Mode, SELECT for Bicycle, MOVEDEX and tons of Bugs fixes. Taught me about Unions, calling codes from other banks and RST VECTORS FOR SPACE…. PURERGB IS IN THE TOP 3 OF GEN 1 HACKS IN MY OPINON ALONG WITH RED++ AND SHIN POKERED FOR ALL THERE UPDATES AND FEATURES
- CRz Shadows/The Smith Plays/Yellow Legacy- The reason I started disassembly. A lot of initial changes features came from there game. Moves in Pokedex, Running Shoes, Pikachu fixes, Gym Leader rematches, Mr Mime in house, eeveeolution next to trainer and post game mart clerk. Alot of Pokemon learnsets, level up moves were borrowed and used from Yellow Legacy, as well as some trainer ideas like Janine in Kogas Gym IN MY OPINON THE TWO BEST YELLOW HACKS ARE YELLOW LEGACY AND EXTREME YELLOW. THIS GAME WOULD NOT BE MADE WITHOUT THERES SO PLEASE TRY IT. Thanks for Crystal and Emerald Legacy too!!
-JojoBear13/ShinPokeRed- Trainer AI code taken from game, as well as many many bug fixes. TRY SHINPOKERED. AS I STATED BEFORE ITS IN TOP 3 OF GEN 1 HACKS.
-JustRegularLuna/Red++- My favorite Gen 1 hack. First one I ever played too. The main reason celebrations was made was to try to create magic like you did. Features from Red++ include Gender code, Sprite Palette help, Intro being changed, Oak Giving 5 pokeballs, updated pokeball and pokedex sprites.
- Engezertorung- A lot of help with color, sprite and graphics. Very helpful and patient. Please try his Pokered-gbc French and English updated game.
-Melody- For the rest of Pokedex code that makes it run and look clean. You also assisted with the LearnSet moves and Bugs. Thanks for the help with Celebrations too.
-Devianart- For all the female sprites for the game
-FrenchOrange- for all the running and surfing sprites added to the game/ yellow sprites
-Rosie- for the Nurse Joy, Jenny, Yellow back picture.
-PokeFanMarcel- For the Nurse Joy SS Anne room, the code for the running sprites to work and the code to make the EXP ALL a key item that can turn on or off
-RainbowMetalPigeon/ExtremeYellow- Space code for Bank 1E, Surrender in battle option, and Pikachu Flying Animation. Also for 3rd character/gender tutorial AND FOR CREATING THE HARDEST GEN 1 YELLOW HACK EVER. BUT I LOVE PLAYING IT
-RainbowDevs/Pokemon Brown- Another awesome Gen 1 hack. Some Pokemon Sprites were taken from Brown and added into this game.
- BYRAX- FOR THE BOXART FOR ALL THE GBC/GBA GAMES. ALSO TESTING THE GAME MULTIPLE TIMES AS WELL.
- JA2398- Tester
-DarthBR- Tester
- Bri- Tester
-Dreams897
- Mauvesea
-Alio
-SCORP MILLER
-ELRT
-TUXMAN
-BEEFMAN
-BlueZangoose- Answered questions
-Rangi42- Pret and Disassembly Team
MegaMan-Omega- Sprites
-ZetaPhoenix- Explaining how to call from other banks
- DISCORD AND EVERYONE FOR PLAYING OR THINKING ABOUT PLAY

** IF I FORGOT SOMEONE OR SOME DETAIL LET ME KNOW AND I WILL ADD IT. I PUT CREDIT TO EVERYONE IN THE COMMITS THEY HELPED WITH AS WELL, AS WELL AS LINKS TO THEIR CODES IF I HAD IT HANDY***

AS I SAID ABOVE THERE ARE MANY HACKS AND CREATORS OUT THERE: FOR GENERATION 1 PLAY THESE AMAZING GAMES: PURERGB, SHIN POKERED, YELLOW LEGACY, POKEMON BROWN, RED++, EXTREME YELLOW, BLUE KAIZO, AND MY OTHER HACK POKEMON CELEBRATIONS!



To set up the repository, see [**INSTALL.md**](INSTALL.md).
USE RGBDS 7.0 or 8.0


## See also

- [**Wiki**][wiki] (includes [tutorials][tutorials])
- [**Symbols**][symbols]

You can find Pret [Discord (pret, #pokered)](https://discord.gg/d5dubZ3).

CREAMELDUDJAFAR'S DISCORD: https://discord.gg/3YQrCFzCNv

For other pret projects, see [pret.github.io](https://pret.github.io/).

[wiki]: https://github.com/pret/pokeyellow/wiki
[tutorials]: https://github.com/pret/pokeyellow/wiki/Tutorials
[symbols]: https://github.com/pret/pokeyellow/tree/symbols
[ci]: https://github.com/pret/pokeyellow/actions
[ci-badge]: https://github.com/pret/pokeyellow/actions/workflows/main.yml/badge.svg
