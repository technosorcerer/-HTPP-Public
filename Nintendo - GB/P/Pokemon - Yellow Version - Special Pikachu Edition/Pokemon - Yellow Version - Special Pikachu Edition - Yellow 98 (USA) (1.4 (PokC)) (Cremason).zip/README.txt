
This took me quite a while to figure out and I'm sure it would have been easy for people that understand coding, but I had to learn how just by constant failures assembling the game. I will happily provide credits where credits are due so if I have not properly credited someone, please inform me and I will do my best to make sure the work is appreciated.

Hello and thank you for taking a look at this hack. 
This hack consists of several manga-inspired graphic changes as well as Spaceworld '97 backsprites.
Palettes for a few Pokémon were corrected to more appropriate colors; for instance, Eevee is now brown instead of green. 
Speaking of green, this hack allows you to choose a girl option based on the Green character from the manga. 

- Blue's frontsprite has been updated.
- Red's frontsprite has been slightly modified, and Red's backsprite is redone.
- New modified Oak frontsprite is also featured as a post HoF battle with a team inspired by the manga. 
- Mew has been added to the Pokémon Mansion. 
- Almost all of the gym leaders have had slight changes to their teams. (with a surprise addition to Giovanni's team that won't be spoiled here)

This hack is generally considered complete, but there are plans to continue adding more to make it the definitive way to play Pokémon Yellow.

Videos:
(coming soon)

Screenshots:

New Pokémon Back Sprites from space world 97 with original Yellow Palette design:






Screenshot1.png

Credits:
Old Man Back Sprite (by SteppoBlazer) -
1717127697223.png
Oak Back Sprite (by Mateo)
1717127795615.png
- All spaceworld 97 Back Sprites were ripped from the redstarbluestar hack by Rangi42
- Some of the sprites were borrowed originally but were remade into something of my own.

 if needed to give credit of where it came from originally, 

it would be Ghost-missingno. on DeviantArt.



Warning! This hack has been through VERY limited testing. let me know if anything comes up graphically that is corrupted in any way.

Download:
PY98v1.0

My Other Hacks:
PokemonYellow97


Teaser for Pokemon Blue 98:


Red Sprite Back Sprite (by Poketto)



---
