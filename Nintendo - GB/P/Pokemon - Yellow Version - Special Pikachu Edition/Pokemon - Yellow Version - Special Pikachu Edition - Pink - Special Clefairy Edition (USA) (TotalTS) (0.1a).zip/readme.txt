Pokémon Pink: Special Clefairy Edition v0.1a

A rom hack that imagines what Pokemon Pink could have been.
Even if progress was made from the original project, this is also not 100% completed, but with enough steps done to make it playable from start to end.
This hack so far changes graphics and sounds, expands the map and adds gender selection, no further improvements were done to keep a "vanilla experience".

Features:

-Clefairy fully replaces Pikachu.
-Gender selection added.
-Mt. Moon Square from Gen 2 is now added as a counterpart of Surf House. Clefairy shows up at Mt. Moon Square at random.

To do:

*Small changes on intro graphics. (Animated stars, corrections on Clefairy's ears palettes, animate closer Clefairy, SGB palette fixes)
*Add Clefairy jumping animation and cries in Mt. Moon Square.
*Add 41 different sounds for Clefairy.
*Change diploma's art.
*New Clefairy Minigame?

Credits:

Original project (2020):
**Mathias** - title screen graphics / Clefairy overworld sprite
**DarkSideHunterX** - code modifications
**DarkShade** - Clefairy's emotes

https://github.com/DarkSideHunterX/pokepink

New project (2024):
**TotalTS** - code modifications / some intro and female protagonist graphics
**Picto** - Clefairy's intro graphics / SGB Border
**FrenchOrange** - Clefairy's kick intro graphics
**Cram-o-dev** - help with inserting Clefairy's sounds
**PokefanMarcel** - original code of Mt. Moon Square
**Engezerstorung** - helping me understanding oam_intro.asm
**Vortiene** - help with optimization on home bank
**ElectricLeafy** - help with new PalPackets