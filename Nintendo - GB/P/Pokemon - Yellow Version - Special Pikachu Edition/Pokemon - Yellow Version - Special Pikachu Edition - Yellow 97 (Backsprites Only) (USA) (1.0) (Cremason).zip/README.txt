Pokémon Yellow Rom Hack

Hack Name: Pokémon Yellow 97 (Back Sprites Only) V1

Hack of: Pokémon Yellow

Details:

This took me quite a while to figure out and I'm sure it would have been easy for people that understand coding, but I had to learn how just by constant failures assembling the game. I will happily provide credits where credits are due so if I have not properly credited someone, please inform me and I will do my best to make sure the work is appreciated.

The wait is finally over!

I'm thrilled to introduce a Space World 97 (Back Sprites) Hack for Pokémon Yellow!

Key Features:
- Original Space World 97 back sprites
- Various graphical updates inspired by Space World 97


Red Sprite Back Sprite (by Poketto)



Old Man Back Sprite (by SteppoBlazer) -


Oak Back Sprite (by Mateo)


All spaceworld 97 Back Sprites were ripped from the redstarbluestar hack by Rangi42