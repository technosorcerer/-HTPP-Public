Pokemon Carcinization 1.1 by tm20

Patch for Pokemon Blue. Makes everything evolve into Krabby, along with a few other surprises.
	•	Hold down B to run. Hold B on the bike to go even faster.
	•	Slow text is vanilla Medium, Medium text is vanilla Fast and Fast text is instant.

How to apply
Have a legitimate backup of USA Pokemon Blue Version and patch it with CarcPatch1.1.bps.

https://www.marcrobledo.com/RomPatcher.js/ is a simple web-based patcher.

Made with https://github.com/pret/pokered

Also available at https://github.com/stivvin/carcinizationpatch