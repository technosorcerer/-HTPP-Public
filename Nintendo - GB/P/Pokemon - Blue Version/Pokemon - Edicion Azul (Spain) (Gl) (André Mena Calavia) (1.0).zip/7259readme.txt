Ola,

son André Mena Calavia, coñecido in Romhacking.net coma RetGal, acrónimo de "Retro Galicia".

Este é un parche de tradución ó galego completamente funcional do xogo "Pokémon Azul".

Comecei a traballar nos parches de Azul e Vermello inmediatamente despois de completa-la tradución de Amarelo; o traballo era case o mesmo e xa o tiña feito.

Porén, hai cousas que había que trocar: os textos non ían nos mesmos bancos que Amarelo (había que movelos en pequenos bloques), algúns textos non existían en Amarelo e había que traducilos, así como textos de Amarelo que non tiñan contraparte en Azul/Vermello, textos que tiñan diferentes lonxitudes en Amarelo había que reformulalos para non dar erros cos punteiros, etc.

Este "copia-pega" conleva que as mesmas licenzas que tomei en Amarelo (lusismos, koruño, etc) están presentes nestes parches; triple traballo no caso de que teña que corrixir algo, pero paga a pena.

As Pokédex de Azul e Vermello son distintas entre elas; foi un traballo longo comparado co resto que me levou pero alomenos isto dá maior diferencia entre ámbolos dous xogos.

Dúas cousas a ter en conta, que saco directamente do "Leme" de Amarelo:

1) A modo de trivia, procurei introducir as diferentes variantes dialecticas do galego nas personaxes; para tal fin relacionei cada vila e cidade de Kanto cunha cidade de Galicia e o Bierzo, e procurei que alomenos un habitante de cada lugar tivera un rasgo característico da fala; por exemplo, Cidade Azulona correspondería a Compostela, con algúns habitantes falando con gheada, seseo implosivo e engadindo o artigo "esto" ou dicindo "irmao" e "vacaciós". En troques, Vila Lavanda correspondería a Ponferrada, con habitantes empregando "mao", "tu", sen seseo nin gheada e algún teismo. Isto, por suposto, só foi unha ferramenta que usei para dar algo de variedade a como falan diversos NPC, pois non é a miña intención que houbera unha relación 100% exacta entre as cidades de Kanto e as de Galicia e Bierzo, nin que tódalas personaxes de cada vila presentaran os correspondentes dialectos. Polo xeral está extendido o uso do galego normativo, procurando que as personaxes falen o máis "natural" posible mentres que os textos xerais, menús e Pokédex empregan un galego máis "enxebre".

2) Acho preciso avisar: aínda que moi esporádicamente, este xogo contén partes con linguaxe soez e palabras malsoantes. Quero deixalo claro xa que este parche foi pensado para persoas de +30 anos, que xa somos medrados, pero quizáis alguén quere introducir ós seus fillos no mundo pokémon a través dos xogos da primeira xeración e na nosa lingua; nese caso, queda o aviso. 




-- FERRAMENTAS USADAS --

Habituais:

♦ Tiny Hexer, a millor que coñezo para ler hex e aplicar táboas.
♦ CrystalTile2, sinxela para ler e modificar tiles.
♦ Paint.net, esencial para trocar gráficos.
♦ Papel e lápis.

Específicas deste proxecto:

♦ TGB_Dual, emulador especializado nos intercambios entre xogos Pokémon, co que comprobei non só se a tradución desta parte estaba ben aplicada senon a súa compatibilidade, alomenos, coas versión española, alemá e francesa, en calquera das versión dos xogos (Amarelo, Azul e Vermello).
♦ Wikidex, enciclopedia Pokémn na que informei de moitísimos detalles miúdos (maiormente relativos a información de Pokédex) e lendas Pokémon que engadín coma "ovos de Pascua" no xogo.




-- TROCOS QUE REALIZA ESTE PARCHE --

Atinentes a tradución:

♥ Pantalla de título.
♥ Nomes de personaxes.
♥ Textos de personaxes.
♥ Pokédex completa.
♥ Menús.
♥ Tiles de xogo (GIM --> XIM, SHOP --> SÚPER, etc)
♥ Engadidas grafías ("NON", ï, notas musicais, etc)
♥ Disposición do alfabeto na pantalla de nomes e alcumes.
♥ Diploma ó completa-la Pokédex.
♥ Pantalla cando se xoga na SNES coa SGB.
♥ Créditos (todo o equipo orixinal respectado)
♥ Recoñecemento polo parche ó galego (cara o final dos créditos)
♥ Todo o traducible que atopei, a fin de contas.

Non atinentes a tradución:

♥ As ataques PANTASMA son agora súperefectivas contra o tipo PSIQUE, como é canon no anime dende o principio e nos xogos dende a segunda xeración.



-- QUE QUEDA POR FACER --

♣ Comprobar que todos estes trocos funcionen en consola real (GB e SGB)



-- CONTACTO --

Se alguén quere contactar por algunha razón sempre estou dispoñible en Romhacking.net --> https://www.romhacking.net/forum/index.php?action=profile;u=91332

Teño un blog tamén onde centralizo tódalas miñas traducións ó galego, e onde podedes contactar tamén comigo --> https://retrogaliciatraducions.blogspot.com/

Aburiño.