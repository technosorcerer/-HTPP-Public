My very first hack, Garbage Blue is finally out! It's meant to be similar to Garbage Green with even less mons (no generation 2 or 3 mons), which effectively means more challenge. 
So for anyone unfamiliar w / Garbage green:
- The idea is to use awful pokemon
- This is done by limiting encounters, and making evolutions either come later or be removed
- Healing items have been removed from the game(Garbage green has them extremely limited, but here it's none)
- Powerful TMs are removed or changed into weaker moves
- Move PP has been nerfed, especially on moves that are consistent
- All trainer parties have been left unchanged however
- Many maps are locked out by a dungeon factor, not allowing you to leave until you defeat every trainer in your way.
- Surf and strength become 20 and 30 base power respectively.
Now, the main differences between garbage green and garbage blue are:
- There's even worse AI in gen 1.
- Battle mechanics have been left mostly unchanged
-  Poison walk damage exists
- HM Fly's out of battle effect has been removed (it still is in battle the same)
The game has a built in hard mode, which makes it so that the game deletes access to item usage for you, forces you to play on set mode and forces a hard level cap (that is 1 above the next gym leaders level to encourage nuzlockers not going to the cap instantly). And yes, this hack is intended to be nuzlocked.
The game gives you almost-infinite access to Rare candies to stop annoying grinds.