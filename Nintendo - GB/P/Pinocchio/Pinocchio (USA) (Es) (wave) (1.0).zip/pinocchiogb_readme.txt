Pinocchio (Game Boy)
Traducción al Español v1.0 (24/06/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pinocchio (USA).gb
MD5: 97fecf5ab824825b781771a40e1c60bf
SHA1: e17c15325a1eaf5bb365ae4923c660e8c98a1d6b
CRC32: 2d924e46
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --