Palamedes (Game Boy)
Traducción al Español v1.0 (19/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Palamedes (UE) [!].gb
MD5: f4e5b89f72cf88c203d8f66c627acd91
SHA1: f93f5b939985935b9cce1364119344b9dc236f57
CRC32: 526942e1
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --