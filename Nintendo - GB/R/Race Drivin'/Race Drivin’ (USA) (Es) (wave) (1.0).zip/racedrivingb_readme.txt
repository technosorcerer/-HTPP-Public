Race Drivin' (Game Boy)
Traducción al Español v1.0 (10/04/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Race Drivin' (USA, Europe).gb
MD5: 74d409740ce00448d42b25ebb31e7bcd
SHA1: 67111295fe2095861256b46e7417e4c1d115a6fe
CRC32: 6775ccd6
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --