Rubble Saver II (Game Boy)
Traducción al Español v1.0 (23/07/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rubble Saver II (Japan).gb
MD5: 019db3e93fa9583a04366a4e4597c618
SHA1: 49a07665695018b29def2cf3f843e10b88889775
CRC32: 92c95f2d
65536 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --