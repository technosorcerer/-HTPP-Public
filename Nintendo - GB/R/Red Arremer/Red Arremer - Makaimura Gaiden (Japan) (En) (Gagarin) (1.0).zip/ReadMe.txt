A complete graphical upgrade for Gargoyle's Quest, intended specially for the retranslation by Stardust Crusaders for the JP ROM. 

* Graphical changes: removes white borders from all sprites. Inserts outlines for most map sprites. Imports the superior graphics from the second game, including in-stage Firebrand. All graphics are overall more polished and detailed, allowing for better color customizations. Fix a tile from the titlescreen.

* Textual changes: fix all innacuracies, such as some treasures saying you won "dark power" (1-UP), while you just won some "souls" (in-game currency).

=======

Must be applied on a ROM patched with Stardust Crusaders retranslation (done for a JP ROM). Link for his project is: https://www.romhacking.net/translations/4146/.

=======

The hack was all done and tested on BGB emulator. Custom colors used are as follow (must set the system to Gameboy mode):

1 - BG: 255/239/206.
         198/131/86.
         144/120/24.
           49/24/82.

2 - WIN: 232/222/222.
         188/178/178.
         125/115/115.
            16/16/16.

3 - 0BP0: 232/222/222.
            255/80/80.
            127/40/40.
             16/16/16.

4 - 0BP1: Same as 0BP0 (above).







