Rhino Rumble (Game Boy Color)
Traducción al Español v1.1 (18/02/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V1.1:
-Cambiado CHILLIES por CHILES
-Cambiado WOW por VAYA
-Traducido PRESS START en el título
-Traducido PASSWORD por CLAVE
-Arreglado GAME OVER cambiando PAUSADO por PAUSA

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rhino Rumble (USA, Europe).gbc
MD5: ced299d2952ae83c7bbfbb64767e4634
SHA1: 2caf47c20d8632e47c4426dd3564e76415139973
CRC32: 73160e05
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --