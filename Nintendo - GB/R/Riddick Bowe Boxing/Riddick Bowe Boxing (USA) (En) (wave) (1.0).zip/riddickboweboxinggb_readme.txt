Riddick Bowe Boxing (Game Boy)
Traducción al Español v1.0 (23/12/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Riddick Bowe Boxing (USA).gb
MD5: f72ba137f679bde064e2e4e644c69b22
SHA1: 93a8a28244461b564e828cca876821fb7a60fc89
CRC32: fb5d24e0
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --