A small patch for the unreleased Resident Evil port for Game Boy Color, that disables the debug overlay/output for the opening text and during gameplay. The patch changes a single byte, and should not affect anything else. Feel free to let me know if it does, so I can explore other methods to remove the overlay.

This patch can be combined with with PacoChan's bugfix patch: https://www.romhacking.net/hacks/891/

Patch made by Carnivol. 

Special thanks to:
- Mechanical Paladin for requesting this fix
- FuSoYa for the eternally handy tool that is Lunar IPS
- Bas Steendijk for developing the Game Boy Debugger bgb