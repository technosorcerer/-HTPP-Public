The Flintstones (Game Boy)
Traducción al Español v1.0 (14/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Flintstones, The (U) [!].gb
MD5: f07ed24e96f84ce78787709f248263c8
SHA1: 506a647137bcaad81589f1b3592884b3bbed8aa3
CRC32: 503d3613
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --