

Intro
=====
Using the "Final Fantasy Adventure Color" patch by theadamrippon on top
of the "Seiken Densetsu Restoration" patch by CasualCollision causes gfx
tiles in the title screen's logo to become corrupted.


What does this patch do?
========================
This patch changes a few palettes and gfx tiles on the title screen. That
is all. It restores the "Seiken" logo from CasualCollision's restoration
patch. The pixel data from theadamrippon's color patch gets mixed together
with the tiles from CasualCollision's restoration patch.  This hack fixes
that conflict.

Option 1.ips = uses black as the outline color.
Option 2.ips = uses dark orange 0x155A (as used in the color patch) as the
		outline color.

Installation:
=============
1. Apply "Seiken Densetsu Restoration" by CasualCollision to a clean rom.
	CRC32: 18C78B3A
2. Apply "Experience Fix for Seiken Densetsu Restoration" by xenophile.
	(this patch is optional)
3. Apply "Final Fantasy Adventure Color" by theadamrippon.
4. Apply this patch last.

You must download and apply the original patches made by those authors.
This patch will not work without them.


Are There Conflicts?
====================
No.  There are no major conflicts between the color patch and restoration
patch.

Testing was done between the all the patches and there weren't
any conflicts beyond the title screen.  Everything will work as intended
by each author.

Using "Advanced Patch Conflict Finder" by Leet Sketcher, there were 17
conflicts found between "Seiken Densetsu Restoration" patch and
"Final Fantasy Adventure Color" patch:

17 conflicts within this range:
0x02C6AB - 0x02CAF3

All of the data within this range is gfx tiles for the title screen.  So
to put your mind at ease, the restoration patch and the color patch are
compatible. No code is affected.


Conflict Report
===============
This report simply shows which data conflicted between the two patches
using Leet Sketcher's utility.

Advanced Patch Conflict Finder v1.0 by 1337|<37C|-|3|2
2 patches scanned, 17 conflicts found
2 patches in conflict - marked with (*)

List of patches:
FFA Seiken Densetsu Restoration.ips (*)
FFA.ips (*)


0x02C6AB - 0x02C6AD (2)
	FFA Seiken Densetsu Restoration.ips
	FFA.ips

0x02C80D - 0x02C80F (2)
	FFA Seiken Densetsu Restoration.ips
	FFA.ips

0x02C83D - 0x02C83F (2)
	FFA Seiken Densetsu Restoration.ips
	FFA.ips

0x02C86D - 0x02C86F (2)
	FFA Seiken Densetsu Restoration.ips
	FFA.ips

0x02C8AD - 0x02C8AF (2)
	FFA Seiken Densetsu Restoration.ips
	FFA.ips

0x02C901 - 0x02C91B (2)
	FFA Seiken Densetsu Restoration.ips
	FFA.ips

0x02C923 - 0x02C92B (2)
	FFA Seiken Densetsu Restoration.ips
	FFA.ips

0x02C933 (2)
	FFA Seiken Densetsu Restoration.ips
	FFA.ips

0x02C941 - 0x02C96F (2)
	FFA Seiken Densetsu Restoration.ips
	FFA.ips

0x02C981 - 0x02C98B (2)
	FFA Seiken Densetsu Restoration.ips
	FFA.ips

0x02C993 - 0x02C99B (2)
	FFA Seiken Densetsu Restoration.ips
	FFA.ips

0x02C9A3 (2)
	FFA Seiken Densetsu Restoration.ips
	FFA.ips

0x02C9C1 - 0x02C9CB (2)
	FFA Seiken Densetsu Restoration.ips
	FFA.ips

0x02C9D7 - 0x02C9EB (2)
	FFA Seiken Densetsu Restoration.ips
	FFA.ips

0x02C9F7 - 0x02CA03 (2)
	FFA Seiken Densetsu Restoration.ips
	FFA.ips

0x02CA61 - 0x02CA63 (2)
	FFA Seiken Densetsu Restoration.ips
	FFA.ips

0x02CAF1 - 0x02CAF3 (2)
	FFA Seiken Densetsu Restoration.ips
	FFA.ips

