The Flintstones - King Rock Treasure Island (Game Boy)
Traducción al Español v1.0 (14/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Flintstones, The - King Rock Treasure Island (U).gb
MD5: 25dfaca5120462af05532aaf4756776a
SHA1: 4ea1609dc273623c677aaa0accd0cd8d4a03efca
CRC32: 508282d0
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --