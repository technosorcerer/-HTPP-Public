Flipull (Game Boy)
Traducción al Español v1.0 (26/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Flipull (U) [!].gb
MD5: 4fcc13db8144687e6b28200387aed25c
SHA1: 54cf45a997d390729dd23b9ed46a967b77cb7664
CRC32: a2f30b4b
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --