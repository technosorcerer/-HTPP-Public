This is a complete reworking of Game Boy Lock 'N Chase into a very fun Pac-Man game called "Pac-Man Escape".  Can Pac-Man rescue Ms. Pac-Man from the evil ghosts??

All of the graphics have received a nice Pac-Man style facelift.  Including the 4 different types of ghost.

The 2 doors at your disposal on each maze now stay permanently shut.  (They only lasted a few seconds in the original Lock 'N Chase.)  This adds more strategy to the gameplay.  If you trap a ghost inside of these 2 doors you will recieve bonus points.  Which also makes the rest of that maze easier.  But be sure to not trap yourself... you will have to restart if you do!

----

Things that need to be finished in a future version:

The animation of the main character will need to be reworked so that Pac-Man can "chomp" correctly in all four directions.  The way it looks now is fine, and it would be quite complicated to implement, so this is not a priority.

The select button needs to kill the player, and restart the current maze, like in most other puzzle games.  (Just in case the player traps themselves with the 2 doors.)  Easily avoided; therefore also not a priority.

----

thirtythree