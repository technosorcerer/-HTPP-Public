`Super Awakening` is a `Legend of Zelda: Link's Awakening` romhack that uses the `Super Game Boy` to enable new gameplay features.  The romhack is designed to be played with a `Super Nintendo` controller on a `Super Game Boy` compatible system.

* Features: *

* Sword and Shield equipped to `A` / `B` buttons
* Change items with `R` / `L` buttons
* Customizable item inventory
* Quick dash
* Quick lift
* Quick restock

* Expanded controls *

Your sword and shield are equipped to `A` and `B`.  There are 2 different items equipped to `X` and `Y`.  The items currently equipped to `X` and `Y` are displayed on screen during gameplay.  

* Change Items *

Use the shoulder buttons to change either equipped item.
* Press `L` to change the item in `Y`
* Press `R` to change the item in `X`
* Use `L+Y` or `R+X` to change to previous item

* Customizable item inventory *

The pause menu allows you to customize your inventory.  Your inventory is used during gameplay to change between items.

You have 10 inventory slots.  Each inventory slot can have a different item.  An inventory slot can also be set to empty.  

* Press `Start` to open inventory menu
* Use `Arrow Keys` to select an inventory slot
* Press `A` or `B` to change item in the selected inventory slot

* Quick Dash *

Double tap any direction to automatically start a dash.

* Quick Lift *

Push against a heavy object and press `X` or `Y` to automatically lift the object.  Equip the `Power Bracelet` to lift other objects.

* Quick Restock *

Spend rupees to automatically restock empty consumable items.

* Compatibility Notes *

The romhack is fully supported on an original `Super Nintendo` system using a `Super Game Boy`.  `Game Boy Color` is supported in emulators where available.  Some emulators require additional configurations to set the `X/Y/R/L` buttons to controller 2.

* ✅ Super Nintendo
* ✅ Analogue Pocket
* ✅ [url=https://cphartman.github.io/projects/super-links-awakening/]Web Browser[/url]
* ✅ Mesen -  Set `Game Boy model` to `Super Game Boy`. Set buttons for `SNES Port 1 Controller`
* 🌈 BGB -  Set `Emulated System` to `SGB + GBC`. Set `X/Y/L/R` button inputs to `A/B/Left/Right` on joypad1
* ❌ mGBA, Retroarch - Does not support Controller 2 inputs 