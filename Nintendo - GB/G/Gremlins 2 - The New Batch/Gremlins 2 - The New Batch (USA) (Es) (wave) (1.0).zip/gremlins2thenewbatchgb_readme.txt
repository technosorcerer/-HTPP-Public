Gremlins 2 - The New Batch (Game Boy)
Traducci�n al Espa�ol v1.0 (21/09/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Gremlins 2 - The New Batch (W) [!].gb
MD5: f59dbce4cf5b51a5241806e1b35301fb
SHA1: 0cb722d9d4e349bea1b1afa85d8d3b93f2dc2aad
CRC32: 3579e297
131.072 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --