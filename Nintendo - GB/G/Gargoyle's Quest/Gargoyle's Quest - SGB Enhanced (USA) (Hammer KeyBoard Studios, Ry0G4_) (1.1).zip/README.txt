«Gargoyle's Quest (USA, Europe) (SGB Enhanced)»


A Gargoyle's Quest (USA, Europe) HACK created by:

Hammer Keyboard Studios / Ry0G4_
https://darkryoga.wordpress.com/

Description: «Gargoyle's Quest (USA, Europe) (SGB Enhanced)» is a hack of Gargoyle's Quest (USA, Europe) (Game Boy). 
This hack adds a custom border and custom palette set to make this game FULL compatible with the Super Game Boy 
peripheral.

[1.1]

First revision of the patch. This revision includes minor changes in border tiles.

[1.0]

First version of the patch. This includes the new custom border that con be applied to the ROM.

>>> INSTRUCTIONS <<<

  ************************************************************************************************************
  * To play - This rom hack is distributed as an IPS (International Patching System) patch. 
  * You'll need to find the Gargoyle's Quest (USA, Europe) rom on your own. 
  * Once you have it, you can use a website or program like "Lunar IPS" to apply the patch to the rom. You'll 
  * also need a Game Boy emulator, like BGB or mGBA, to run the patched rom. The patched ROM also works on a 
  * real Super Game Boy.
  ************************************************************************************************************


