Ghostbusters II (Game Boy)
Traducci�n al Espa�ol v1.0 (24/02/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ghostbusters II (USA, Europe).gb
MD5: 0841a527b116a52ad26de023b20b1a42
SHA1: 1e2aa42b7e0f974f45fbca35160cda6d5964f0ad
CRC32: 5821ecd4
131.072 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --