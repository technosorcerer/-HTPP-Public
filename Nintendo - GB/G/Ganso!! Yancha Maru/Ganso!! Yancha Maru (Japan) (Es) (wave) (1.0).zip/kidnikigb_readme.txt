Kid Niki (Game Boy)
Traducción al Español v1.0 (20/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Kid Niki (J).gb
MD5: a60df6aeb6820683805be1717097fca8
SHA1: 76be351eac00749553c942b6f8002e65d8a35986
CRC32: 004443e6
65536 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --