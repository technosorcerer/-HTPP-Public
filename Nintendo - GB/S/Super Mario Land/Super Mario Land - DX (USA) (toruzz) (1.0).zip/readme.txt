**************************************
****      SUPER MARIO LAND DX     ****
****  v1.0   22/04/2019 - toruzz  ****
**************************************

WHAT IS THIS?
-------------
Super Mario Land DX is a romhack of the original Super
Mario Land for the GameBoy that turns the game into a
GameBoy Color game. It adds color and changes the
graphics to give the game a modern look.


HOW DO I APPLY THIS PATCH?
--------------------------
You have to use an IPS patching program (e.g. Lunar IPS)
on a Super Mario Land (W) (V1.0) ROM. Please make sure it's
the one with CRC32 90776841.


WHAT IF MY ROM IS V1.1?
-----------------------
It won't work.


DOES THIS WORK ON REAL HARDWARE?
--------------------------------
Yes!


I FOUND A BUG!
--------------
Please make sure this isn't present in the original game!
If you actually found one, please let me know.


SPECIAL THANKS
--------------
Martin Allen for making Land Forger. You saved me hours!
JuananBow, Dragoonglue and Marc Max for betatesting and
their valuable feedback.


DISCLAIMER
----------
I'm NOT responsible for the use of the program and/or
the information distributed. Use it at your own risk.
I'm NOT affiliated nor endorsed by Nintendo.
Registered trademarks are of their respective owners.