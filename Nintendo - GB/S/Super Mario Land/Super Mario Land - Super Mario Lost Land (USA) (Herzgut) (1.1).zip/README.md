# Super-Mario-Lost-Land-ROM-Hack
A simple ROM-Hack/IPS-Patch for Super Mario Land (JUE) (VER1.1) that makes the game significantly more challenging. It includes remixed and completly original levels, with reworked boss rooms and even alternative (some of which are Hardmode-only) exits!
![Screenshot (4)](https://github.com/user-attachments/assets/94848e48-277e-4f85-8a8a-548de6124f4c)
![Screenshot (11)](https://github.com/user-attachments/assets/d671f72f-e2b8-41b9-bbb4-63ba51a635d6)
![Screenshot (12)](https://github.com/user-attachments/assets/da276587-5be2-4fa1-b9cb-700ede076af9)
![Screenshot (15)](https://github.com/user-attachments/assets/a156994f-f6eb-4902-b32b-355aa0683eb7)
