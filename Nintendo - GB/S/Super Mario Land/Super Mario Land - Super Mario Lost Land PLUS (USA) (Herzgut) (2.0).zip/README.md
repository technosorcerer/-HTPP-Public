# Super-Mario-Land-ROM-Hack
A simple ROM-Hack/IPS-Patch for Super Mario Land (JUE) (VER1.1) that makes the game a bit more challenging. It includes remixed and completly original levels, with reworked boss rooms and even alternative (some of which are Hardmode-only) exits!

NEW: Super Mario Lost Land PLUS available now!!!
+ complete graphics overhaul
+ slightly altered level design
+ more and better item placements
+ redesigned bonus rooms
+ altered enemy designs
+ new added story

Note: If you found the original Lost Land too difficult in the past, were not satisfied with the similar looking graphics, or simply want to own/play a new, better version without the known bugs or softlocks — here is your chance to do so!
Have fun with this final version called Super Mario Lost Land PLUS!
