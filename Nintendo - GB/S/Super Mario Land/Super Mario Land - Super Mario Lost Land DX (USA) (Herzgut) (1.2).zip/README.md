# Super-Mario-Lost-Land-ROM-Hack
A simple ROM-Hack/IPS-Patch for Super Mario Land (JUE) (VER1.1) that makes the game significantly more challenging. It includes remixed and completly original levels, with reworked boss rooms and even alternative (some of which are Hardmode-only) exits!

NEW: Super Mario Lost Land DX included!
