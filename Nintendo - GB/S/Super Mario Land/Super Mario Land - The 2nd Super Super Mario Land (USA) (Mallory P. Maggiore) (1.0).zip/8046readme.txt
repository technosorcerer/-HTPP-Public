The 2nd Super Super Mario Land, v. 1.0

Created August 28, 2023, by Mallory P. Maggiore
Contact: golden_road15@hotmail.com

* A fully complete normal mode and hard mode.
* Time limit increased to 500 seconds per level.
* Minor graphics changes.
* Most levels have more enemies and are longer.
* 3-1 is a short level with only a few unique screens. This is for space purposes, but I still made it (hopefully) rather enjoyable, and 3-2 and 3-3 should make up for it.