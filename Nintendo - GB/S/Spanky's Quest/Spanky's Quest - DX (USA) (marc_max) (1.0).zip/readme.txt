================================================

            SPANKY'S QUEST DX v1.0
           by kensuyjin33 & marc_max

================================================


The Natsume's Game Boy classic, now in full color!

Spanky's Quest is a little hidden gem that, against all odds, is very well
remembered by a lot of people who played it as a child.

Enjoy this cute single screen arcade with a new beautiful paint coat!


PATCHING INFORMATION
--------------------
You must provide the original Spanky's Quest USA ROM:

Spanky's Quest (USA).gb
CRC32: 6ee7ca79
MD5:   3c268409bf6869a8707839a7dd1ee1c7
SHA-1: 8f448eab7e6a05266d62f3564a00813f79314736

Apply the patch here: https://www.romhacking.net/patch/
(some emulators may require a .gbc extension, so make sure you rename it after
patching)



CHANGELOG
---------
v1.0 (2023-12-20)
- first version



CREDITS
-------
kensuyjin33 - graphics
marc_max - reverse engineering & hacking



DISCLAIMER
----------
This is a fan created hack, no copyright or trademark infringement is intended.
Spanky's Quest (known as Lucky Monkey in Japan) is a game originally made by
Natsume.
We are not affiliated nor endorsed by Natsume.
