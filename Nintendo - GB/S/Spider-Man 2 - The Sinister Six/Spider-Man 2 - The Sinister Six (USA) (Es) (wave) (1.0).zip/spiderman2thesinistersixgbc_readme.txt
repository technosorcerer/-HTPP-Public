Spider-Man 2 - The Sinister Six (Game Boy Color)
Traducción al Español v1.0 (07/11/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Spider-Man 2 - The Sinister Six (USA, Europe).gbc
MD5: 85bbad46380dffa631f8ce732e9c5d89
SHA1: 22c63fa198df68edb9cbe22e35cbd307174c9eb9
CRC32: a7faaccf
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --