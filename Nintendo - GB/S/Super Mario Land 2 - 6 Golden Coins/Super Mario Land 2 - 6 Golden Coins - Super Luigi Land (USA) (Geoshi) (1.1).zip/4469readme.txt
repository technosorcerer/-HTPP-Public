~Changes in Super Luigi Land~ 

-The title screen has been updated for both the Logo and Luigi appearing on the top.

-Luigi is now playable completely replacing Mario, which makes it fitting and done right for Luigi to save Daisy instead of Mario saving her oddly.

-World 2-3 the Muda Kingdom has some coin positions changed and now the coins spell "LUIGI" instead of "MARIO"

-All text with "MARIO" is replaced with "LUIGI"
 
I originally wanted to include jumping high and having slippery controls but Super Mario Land already has bad physics so I left them unchanged and neither do I know how to modify it anyways let alone modifying the levels to be designed for those movesets.
