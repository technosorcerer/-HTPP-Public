Skate or Die - Badder than Rad
Jan. 8th 2026
BillyTime! Games

This patch is designed to reduce difficulty in Skate or Die - Bad n' Rad.

Changes:
--------------------
*Increased Invulnerability Time in side scrolling sections
*Non-Insta kill hits reduce only one bar of energy (Side Scrolling and Vertical Scrolling stages)
*Lives increased from 3 to 5
*All 7 stages are now selectable


How to Patch:
--------------------
1.Grab a copy of Skate or Die - Bad 'N Rad (USA).gb
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file