Shaq Fu (Game Boy)
Traducción al Español v1.0 (01/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Shaq Fu (U) [S][!].gb
MD5: 9d4d9a346158fcda7221c853b13bd19d
SHA1: 5e9e68d9235cf8149232b85fd6080ba8796cb85e
CRC32: 7ed43fe6
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --