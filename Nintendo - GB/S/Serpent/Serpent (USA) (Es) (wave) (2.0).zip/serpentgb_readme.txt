Serpent (Game Boy)
Traducción al Español v2.0 (18/01/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Cambiado ALPHA FORCE por FUERZA ALFA.
-Mejorada pantalla de título
-Traducido PAUSE por PAUSA
-Añadidos É e Í

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Serpent (USA).gb
MD5: ed999967209a4cbcaa844b8a84e09ea9
SHA1: 3122b3c12c2580c3a81d70c5648f767bf3590aaf
CRC32: 74d466d7
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --