Stop That Roach! (Game Boy)
Traducción al Español v1.0 (06/04/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Stop That Roach! (USA).gb
MD5: 1a316519500424ae9a2649746c4c83ab
SHA1: b7265343bd77f966b31f871fd471559266e5fc82
CRC32: 86107477
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --