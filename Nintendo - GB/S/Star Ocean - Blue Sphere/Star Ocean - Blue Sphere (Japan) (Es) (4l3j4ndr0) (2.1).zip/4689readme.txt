Star Ocean: Blue Shere
Spanish Translation V2.1
Copyright 2024 by 4l3j4ndr0 [343]

1.About SOBS
2.Patch Credits
3.Known Issues
4.Application Instructions
5.Contact
6.Glossary

---------------------
1.About Star Ocean Blue Sphere
---------------------
Star Ocean: Blue Sphere takes place two years after the events of Star Ocean:The Second Story. 
Some characters moved to Earth, some stayed on Expel, and others are elsewhere doing their own thing.
Ernest and Opera are still exploring uncharted, primitive planets, and on one ocean-covered planet known
as Edifice.

---------------
2.Patch Credits
---------------
STAR OCEAN BLUE SPHERE

4l3j4ndr0 [343] - Translator, Graphics.
AnimaC13 - ASM hacking and Bux Fix.
MZ - Romhacking, Tools, Script Extraction.
Geno CL - Pixel Art. (@geno_cl)

Thanks to :

	Psyklax and for Denim Romhacking help.
	Gadesx for his support.

--------------
3.Known Issues
--------------
None, but please report any bugs, spelling errors, and such on the dedicated
Discord server (https://discord.gg/RSc5Tha)

--------------------------
4.Application Instructions
--------------------------
Open the .ips patch whit Lunar IPS or similar, and "Apply
Patch" to a clean Star Ocean - Blue Sphere (J) [C][!].gbc rom.

--------------------------
5.Contact
--------------------------
For comments and bug report

https://discord.gg/RSc5Tha

--------------------------
5.Glossary
--------------------------

Str	Strength
Con	Constitution
Dex	Dexterity
Agl	Agility
Int	Inteligence
Res	Resistance
Gut	Recovery
HP	Health Points
MP	Magic Points
Att   	Attack
Def   	Defense
Hit   	Hit
Eva   	Evasion
Mag	Magic
