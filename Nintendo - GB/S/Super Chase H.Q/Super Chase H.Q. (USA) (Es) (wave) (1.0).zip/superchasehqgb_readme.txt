Super Chase H.Q. (Game Boy)
Traducción al Español v1.0 (14/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Chase H.Q. (UE) [!].gb
MD5: ebdb99bf19c9066be71485c3c9187b82
SHA1: d5184c1849d8e0addd4e1d31812068931bf98adc
CRC32: 630e0e00
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --