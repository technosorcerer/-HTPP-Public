Battle Unit Zeoth (Game Boy)
Traducción al Español v1.0 (26/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Battle Unit Zeoth (U) [!].gb
MD5: 023a8fd8eacad0656b5110da26dcdd44
SHA1: eba09c60cd60feba0a7a9e82597dad080ce78d22
CRC32: e67a92b3
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --