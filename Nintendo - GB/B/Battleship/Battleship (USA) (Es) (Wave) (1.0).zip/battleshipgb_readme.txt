Battleship (Game Boy)
Traducci�n al Espa�ol v1.0 (27/01/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Battleship (U) [M][!].gb
MD5: d4f7ade01af0818a79bc809cf96118bb
SHA1: d3efb4afebcf94b191a66797a6bae2c90ba92c6a
CRC32: fef62da5
65.536 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --