Burai Fighter Deluxe (Game Boy)
Traducci�n al Espa�ol v1.0 (22/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Burai Fighter Deluxe (UE) [!].gb
MD5: dd5aa6e85827a3ce6e4b7500e75a3262
SHA1: 178e18b7e6e65e726b4e06f80d89c55332ea868b
CRC32: 3c86f5db
65.536 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --