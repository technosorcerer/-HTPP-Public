Bart Simpson's Escape from Camp Deadly (Game Boy)
Traducción al Español v2.0 (12/10/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Añadidos ÍÑÓ¡
-Guion reescrito
-Traducido PAUSE, GAME OVER y MUSIC ON/OFF
-Traducido LIVES incluido el cambio de vidas

Faltan las traducciones de los letreros.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bart Simpson's Escape from Camp Deadly (USA, Europe).gb
MD5: e731fa23d9cd0c3d4dec7d5565beef61
SHA1: 89b7b2d4684d703ea5d323e3aaf4910dcdbc47d3
CRC32: 5546a382
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --