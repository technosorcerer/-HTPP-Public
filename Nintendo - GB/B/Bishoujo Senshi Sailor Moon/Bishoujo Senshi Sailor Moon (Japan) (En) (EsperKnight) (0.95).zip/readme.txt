SSSSSSSSSSSS GGGGGGGGGGGG SSSSSSSSSSSS TTTTTTTTTTTTT
SSSSSSSSSSSS GGGGGGGGGGGG SSSSSSSSSSSS TTTTTTTTTTTTT
SSS      SSS GGG      GGG SSS      SSS      TTT
SSS      SSS GGG      GGG SSS      SSS      TTT
SSS          GGG          SSS               TTT
SSSSSSSSSSSS GGG   GGGGGG SSSSSSSSSSSS      TTT
SSSSSSSSSSSS GGG   GGGGGG SSSSSSSSSSSS      TTT
         SSS GGG      GGG          SSS      TTT
SSS      SSS GGG      GGG SSS      SSS      TTT
SSS      SSS GGG      GGG SSS      SSS      TTT
SSSSSSSSSSSS GGGGGGGGGGGG SSSSSSSSSSSS      TTT
SSSSSSSSSSSS GGGGGGGGGGGG SSSSSSSSSSSS      TTT

Some Good Shit Translations
Present

SAILOR MOON (GB)

Ver .95
Nove, 2001


Whoopie.  Salor Moon!  Now you can shamelessly oggle 14-year-old 
schoolgirls....in ENGLISH!

ROMhacking shiznit
------------------
Project Leader:  EsperKnight
ASM shtuff: FuSoYa

Translation Bum
---------------
DDS

TXT Guy
-------
TheFreak

This patch is obviously not complete, but complete enough to warrant
a release.  Look for the complete version soon.




Sailor Moon is copyrighted to Toei animation and a bunch others.
Unnoficial English Translation 2001 SGST Translations.
SGST, King Archibald of Turkey 2001 Giraffe's Broken Ankle, inc
All Rights Preserved



Keep circulating the ROMs




*twang*



