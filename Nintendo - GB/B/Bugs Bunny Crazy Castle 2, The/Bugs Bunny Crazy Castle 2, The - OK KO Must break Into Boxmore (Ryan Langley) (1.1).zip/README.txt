OK KO Must Break Into Boxmore
Version 1.1
By Ryan Langley (@Rlan2)

KO's Mom has been kidnapped by Lord Boxman. You must Break into Boxmore and rescue her. His even Robots Darrel, Shannon, Raymond and Jethro are out to get you, so be careful! Save your Mom!

===========================================

This is a hack of 'Bugs Bunny Crazy Castle II' for the Game Boy, to turn it into a game about OK KO, the Cartoon Network show.

I was listening to the podcast 'Retronauts', in which the OK KO creator Ian Jones-Quartey was on talking about Looney Tunes games. They pondered what would OK KO's games been like if it was released in the 90's?

So, I took some time to make that happen! 

Use Lunar IPS to Patch the ROM.

https://www.romhacking.net/utilities/240/

============

Update 1.1
Was able to fix the one reference to 'BUGS' in a screen. Thanks to @MattheRabbit for the help.