Bugs Bunny - Crazy Castle II (Game Boy)
Traducción al Español v1.0 (16/12/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bugs Bunny - Crazy Castle II (U) [!].gb
MD5: 8963803e642dbfbe4f5f3bc5a567785d
SHA1: 1e4c8c8fe8b6c34f76cd0da876442f14299da725
CRC32: a973e604
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --