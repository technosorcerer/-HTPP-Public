The Ultimate Bugs Bunny Crazy Castle II, �  Frank Maggiore, 2002

Version 3.1

The Bugs Bunny Crazy Castle II hack, Game Boy

Updated July 3, 2009

Contact:  golden_road15@hotmail.com
Site:  http://www.angelfire.com/la3/goldenroad15/hacks.html