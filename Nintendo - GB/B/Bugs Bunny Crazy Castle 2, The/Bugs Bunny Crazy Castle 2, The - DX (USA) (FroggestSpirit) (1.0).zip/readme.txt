Bugs Bunny Crazy Castle 2 DX

This is a hack that attempts to put color into an old monochrome game.
In here are 2 patches: BBCC2DX.ips will patch the game to color,
and BBCC2DXFaster.ips will do the same, in adition to activating the
GBC's Double Speed mode (which plays nicely).
If you find any glitches, please contact me at FroggestSpirit@gmail.com

Version 1.0 (11,Jul,2012):
-Only levels, enemies, and items are colored

