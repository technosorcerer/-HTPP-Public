The Ultimate Bugs Bunny Crazy Castle 2, �  Frank Maggiore, 2002

The Bugs Bunny Crazy Castle 2 hack, Game Boy

Contact:  goldenroad155@cs.com
Site:  http://www.geocities.com/plinko50000/hacks.html