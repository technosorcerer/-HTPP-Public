The Bugs Bunny Crazy Castle II Mayhem Edition
Version 1.1

By willj168 and Frank Maggiore

All 28 levels plus the boss level were designed by willj168 and translated into the game by Frank Maggiore

The hack also has brand new passwords

2 - HACK
3 - SLIP
4 - BAIT
5 - DUCK
6 - ROLL
7 - WARP
8 - FEND
9 - CASH
10 - RUBY
11 - FARM
12 - VOID
13 - HIKE
14 - BLUR
15 - SKIM
16 - DUMP
17 - JUNK
18 - TAIL
19 - VOTE
20 - PAIN
21 - FIRM
22 - SEAL
23 - WILD
24 - MEGA
25 - TOUR
26 - OCHO
27 - APEX
28 - BETA