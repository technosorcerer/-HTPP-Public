Bomberman GB (Game Boy)
Traducción al Español v1.0 (19/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bomberman GB (U) [S][!].gb
MD5: 7e4c9c3620bea7b633394beb67e9680b
SHA1: f7058f31ddaec63f3b9c45ee9caf3c8e2cae1ca8
CRC32: f372d175
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --