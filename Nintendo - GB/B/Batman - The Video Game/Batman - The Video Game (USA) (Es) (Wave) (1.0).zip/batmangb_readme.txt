Batman
Traducci�n al Espa�ol v1.0 (18/05/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Batman
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Batman
-----------------
Plataformas para Game Boy, adaptaci�n libre de la pel�cula.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Batman (JU) [!].gb
131.072	bytes
CRC32: 6c41d3cd
MD5: 03c6d84a951be6703b7458478f4277b9
SHA1: ef7d6684a0f737c01a1f2cc2c6609e0f3ac1310e

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --