================================================

         BURGER TIME DELUXE COLOR v1.0
                  by marc_max                  

================================================


This is a colorization hack for the original Burger Time Deluxe game for
Game Boy, turning it into a Game Boy Color game.

It is a very small and simple game, and works great as an example on how to
start a colorization hack. Sourcecode is available here:
https://github.com/marcrobledo/burger-time-deluxe-colorization



PATCHING INFORMATION
--------------------
You must provide the original BurgerTime Deluxe (World) ROM:

BurgerTime Deluxe (World).gb
CRC32: 88219a49
MD5:   9627134ca3ea6e885275d30460ce3563
SHA-1: 1aafcef0dd5fbb8e95188631e0b2decdf84e9aed
 
Apply the patch here: https://www.romhacking.net/patch/
(some emulators may require a .gbc extension, so make sure you rename it after
patching)



CHANGELOG
---------
v1.0 (2025-11-09)
- first version



DISCLAIMER
----------
This is a fan created hack, no copyright or trademark infringement is intended.

