Bonk's Adventure (Game Boy)
Traducci�n al Espa�ol v1.0 (13/06/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bonk's Adventure (U) [!].gb
MD5: 79d6e6515905ec3fbcbd9e50ff469000
SHA1: e27d941af0a006c4f5ffd03914265146aa140e2c
CRC32: a7cdbb96
262144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --