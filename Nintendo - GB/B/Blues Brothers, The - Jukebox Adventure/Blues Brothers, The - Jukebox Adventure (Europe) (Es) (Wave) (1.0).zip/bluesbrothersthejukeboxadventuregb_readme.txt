The Blues Brothers - Jukebox Adventure (Game Boy)
Traducci�n al Espa�ol v1.0 (23/12/2018)
(C) 2018 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Blues Brothers, The - Jukebox Adventure (U).gb
MD5: 3132b823343c82dacece721452612812
SHA1: 2005e94222a1f0edd30903411343f9570a91d4f3
CRC32: f1c0fb1d
131.072 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --