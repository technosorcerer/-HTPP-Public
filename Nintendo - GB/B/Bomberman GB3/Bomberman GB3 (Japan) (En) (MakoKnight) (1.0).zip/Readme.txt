BomberMan GB 3 English Translation Patch
Version 1.00

-----------------------------------------------------------------------
Created by:
----------------------------------------------------------------------- 

 David Mullen ("MakoKnight") http://www.geocities.com/makoknight.geo/
 Duke Serkol

 Thanks to Zackman for those spot translations.

-----------------------------------------------------------------------
Instructions
-----------------------------------------------------------------------

The file "bomber3e.ips" must be patched to the original ROM image to 
play this translation. Any IPS patching utility should work. Two 
commonly used utilities are IPS.exe and Snestool. You can find these 
two programs at most emulation websites.

It's a good idea to:
*** Always keep a backup of the original ROM image. ***

To use IPS.exe, run this at a command prompt:

IPS <ROM NAME> <IPS NAME>

Snestool has a graphic interface that makes it easier. After starting
it, select "Use IPS", then select the IPS file, then the ROM image
that it should be used on.

The game has been thoroughly tested using the No$Gmb emulator, but it
should work properly with most emulators especially those with Super Gb 
support.

-----------------------------------------------------------------------
ABOUT THE GAME
-----------------------------------------------------------------------

Duke Serkol:
Although its title says 3, this is truly the fourth BomberMan game on
Game Boy and up to now the only one that was not imported to the
English world by Hudson. We decided to work at this translation since
the game is actually a prequel to BomberMan Hero on the Nintendo64 and
since... it's a really cool game (in our humble opinion).

-----------------------------------------------------------------------
NOTES
-----------------------------------------------------------------------

David:
This one was a tough egg to crack. I took Duke Serkol's suggestion and
tried to see what I could do with this. At first glance, the game had
some weird compression for its graphics. It took me a while to figure
it out, but once I did, I felt so foolish for missing something so
obvious. But hey, it's the first type of compression I've ever solved,
so I'm happy. =P

Anyways, the game was edited and translated by myself, and Zackman
helped out on the toughest parts. Duke Serkol did the testing and
script editing, and also provided much-needed support.

There are a few things left undone in this translation. I wasn't able
to change the Area names on the explanation screens, since some didn't
give enough space to even write a legible name. The SGB border in
Challenge mode is also left, since I didn't know how to change it. And
the credits at the end are gibberish, because I didn't have enough
space to put everyone's names in. The full list is in the accompanying
file named "credits.txt". Perhaps someone with more skill than I will
take this game and complete it.

-----------------------------------------------------------------------
DISCLAIMER
-----------------------------------------------------------------------

BomberMan Gb 3 is a copyright of Hudson Soft. This work is unofficial 
and is not supported by them.

This patch may be freely distributed, as long as:
 - The patch remains unmodified
 - This readme file accompanies the patch
 - The ROM image is not distributed with this patch

This patch is not for sale, and is not to be exchanged for money,
goods, or services of any kind.

We won't be held accountable for any damage or undesirable side-effects
this patch may create. Use it at your own risk.