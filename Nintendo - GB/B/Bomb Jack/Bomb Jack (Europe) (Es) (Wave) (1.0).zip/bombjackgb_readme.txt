Bomb Jack (Game Boy)
Traducción al Español v1.0 (01/12/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bomb Jack (U).gb
MD5: 7615154dc9afb1a7d7d2fe63b76c68e4
SHA1: a2b2799e867777a5a19155ed1f2245630fc03560
CRC32: 9bd8815e
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --