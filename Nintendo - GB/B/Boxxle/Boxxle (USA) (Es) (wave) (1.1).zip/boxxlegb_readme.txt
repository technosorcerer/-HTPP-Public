Boxxle (Game Boy)
Traducción al Español v1.1 (11/12/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Arreglado título y créditos.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Boxxle (U) (V1.1) [!].gb
MD5: 239fd20f424ee53d2f11018dbd942df4
SHA1: f9d5287bc9d6eda9ec36e9b5a8dbc38cf2cffecf
CRC32: c09cee99
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --