Who: Ushanka
What: A Spanish translation of Boxxle, version 1.0
When: Completed 30 August 2006
Where: Mostly in between lab work
Why: Just because
How: Windhex (Stealth Translations), Translhextion (Januschan), IPS (WaveMaster and SCePTiC), and Gameboy Tile Editor (Mr. Click)

Stuff:
Boxxle is a Game Boy game more commonly known as Soko-Ban or Soukoban.  Call it what you will, it's a great puzzle in that really-frustrating way.  Boxxle takes a step up from the original computer game and adds an attempt at a story.  It comes out to be about seven lines long or something.  But now it's in Spanish! Woo!

Other stuff:
I call this a lunch break translation, because that's how long it took to make it.  Okay, that's a lie.  I ended up shrinking all of the letters so that accented ones, which were two pixels shorter than the originals, wouldn't look so out-of-place.  Some of the translations aren't the most accurate due to space restrictions (Not that the story made much sense in English anyway).  Maybe I'll do some more stuff like this later; I rather enjoyed this.

Other other stuff:
I may use the Japanese version, "Soukoban (J).gb" for a later patch, because there is more room in the ROM for expanding text.  For this one, I used the English version, called "Boxxle (V1.1) (U) [!].gb" because I like the title screen more.  Speaking of the title, I opted not to translate "Licensed by Nintendo" to Spanish because I didn't know the best way to do so.  Secondly, all of the credits are translated except for the word "Music" because I didn't have any space to re-point it and let me add one more letter.  Bleh.

Windhex was used to make the patch, and IPS was used to apply/test the patch.

I need to thank Lakmir, KaioShin, Kitsune, MKendora, and everyone else who explained things to me.  I'm pretty slow with new things, but hey, I'm trying to put it all to use.  Thanks for not going stabbing me.  I'm a little tired of people stabbing me.

         *************
         *           *
         *  THE END  *
         *           *
         *************
