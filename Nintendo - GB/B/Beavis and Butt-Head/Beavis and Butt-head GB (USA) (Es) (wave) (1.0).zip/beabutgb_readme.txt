Beavis and Butt-head
Traducci�n al Espa�ol v1.0 (02/03/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Beavis and Butt-head
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Beavis and Butt-head
-----------------
Aventura basada en los famosos personajes de la MTV.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Beavis and Butt-head (U) [!].gb
524.288	bytes
CRC32: af1ae123
MD5: 8f160aa0b2f69a019911fd57ac8c5b31
SHA1: 918e9cc878a61d8174918c897182604f0c27b1d9

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --