«Ninja Gaiden Shadow (忍者龍剣伝) SGB Enhanced»


A Ninja Gaiden Shadow (忍者龍剣伝) HACK created by:

Hammer Keyboard Studios / Ry0G4_
https://darkryoga.wordpress.com/

Description: «Ninja Gaiden Shadow (忍者龍剣伝) SGB Enhanced» is a hack of Ninja Gaiden Shadow (Game Boy). 
This hack adds a custom border and custom colour set to make this game compatible with the 
Super Game Boy peripheral.

>>> INSTRUCTIONS <<<

  ******************************************************************************************************
  * To play - This rom hack is distributed as an IPS (International Patching System) patch. 
  * You'll need to find the Ninja Gaiden Shadow  (USA) rom on your own. Once you have it, you can use 
  * a website or program like "Lunar IPS" to apply the patch to the rom. You'll also need a Game Boy 
  * emulator, like BGB or Mesen, to run the patched rom. The patched ROM also works on a real Super Game Boy.
  ************************************************************************************************************


