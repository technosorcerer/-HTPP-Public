~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  Nettou The King Of Fighters '96 
  English Translation Patch
  Version .30

  Created by SniperSide Translations
             http://SniperSide.Romhacking.com
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


CREDITS
-----------------
 Kitsune Sniper=
  Game hacking, font insertion and preliminary translation.
  Email: kitsune@terra.com or kitsune_sniper@yahoo.com


Project History:
-----------------


July 1, 2000.
 Unfortunately for most people, I am forced to release this 'going away' 
 patch. I'll be leaving on July 4 on a work trip, and won't be back until
 august. I've decided to release this patch as a present, to everyone who
 has used my patches. 

 Muchisimas gracias a todos mis usuarios. �Nos vemos en agosto!
 [Thanks a lot to everyone that uses my patches. See ya in august!]

June 14, 2000.
 After reading The Whrilpool's interview with satsu, I felt in a 
 good enough mood to tinker with this project of mine [or maybe it
 was the 4.3 earthquake that hit us before 3 o'clock]

April 26, 2000.
  I had just finished [So I assumed =P] the hacking and
 script insertion for Dragon Ball Z 3: Ultime Menace, and I decided to 
 take a break for a while.

  After a short rest [3 days], I decided to start another project, this time on the 
 Game Boy. I chose this game because I've been a fan of SNK since I first
 played Art Of Fighting 2, back in 1993. And I thought 'This game is easy
 as heck'. Boy, was I wrong. The game uses some sort of compression for the
 background, the title screen and the Super Game Boy border, and I haven't
 been able to crack it. But, I added an English font, and have figured out
 the Font table.


Version History:
-----------------

 Version .30, July 1, 2000 [2826 bytes], *released July 4, 2000*
  I messed around with the title screen a bit. Nothing too fancy. I also edited the
  credits, and please wait a bit after the 'The End' message in 
  Normal difficulty... ;)

 Version .25, June 14, 2000 [1860 bytes]
  I messed around with the font, and now all of the messages
  use the standard Pok�mon font, including the numbers. The menus
  were changed a bit [lower cased where needed].

 Version .20, May 23, 2000 [1223 bytes]
  The victory phrases of everyone but Mr. Karate and Kagura
  are translated. And I fixed the checksum using HebeGB9x!

 Version .05, May 14, 2000 [534 bytes]
  I've added an english font, the victory phrases of Kyo, Iori' and Leona'.
  And that's it. Everything else is in cavespeak!
  I haven't added more dialogue because I need a japanese translator. Anyone
  wanna help? 


Project Notes:
-----------------

  Due to space limitations, some dialogue will most likely be cut off. 
  I'll try to stick to the story as closely as I can. I'll be using the 
  victory phrases from the arcade game, but the cinema scene dialogue will
  have to be translated fully by someone. 

  


What's left
-----------------
  All the dialogue!



How to patch [by Vincent]
-----------------
  First, get SNESTool12. Then put that in the same
  folder with the rom and the patch. Double click on
  SNESTool12. Press "u" to use the patch. Use the arrow
  keys to move to the patch. Press "Enter" to select it.
  Then use the arrow keys to move to the rom. Press
  "Enter" to select. It should say "IPS patched ok."
  near the bottom in the Info space. Then press "q" to
  quit, and you have just patched a rom.


  Please do not bother me on how to patch roms. Any questions regarding 
  how to patch roms, or where to obtain the rom
  will be IGNORED [everything else is OK].



Other Stuff
-----------------

  If you like my patch, feel free to send praises, rolls of quarters, old
  Depeche Mode singles, cassetes and CDs [bootlegs or original], etc. to kitsune@terra.com. 
  If you'd like to volunteer for translating, feel free to drop me a line.  

Mi respeto va hacia:
[Respect goes to:]
--------------------
 Lina`chan[^^;], icemanX, satsu, Drakkhen, Spinner 8, (wraith), Megaman`X, serisu [Celes],
 m`agi, _Bnu, DocEvil, PKT_Paladin, TNSe, ballz, SkrErnJav, and everyone at #romhack. 
 Thanks for the great chats, people! 
 And pardon me for using spanish there and talking about soccer with the european people!


Disclaimer
-----------------
 There is no videogame company or any other company associated with
 SniperSide Translations [be it current or former members]. In no event shall
 SniperSide Translations be liable or responsible for any damages that may
 occur from direct, indirect or consequential results of the ability or 
 disability to use or misuse any material it provides.


Copyrights
-----------------
 King Of Fighters, Kyo Kusanagi, Ryo Sakazaki, Iori Yagami, and all related names
 and characters are trademarks of SNK Entertainment Corporation. 

 Takara is a registered trademark of Takara Amusement Company, Ltd.

 Game Boy, Super Game Boy, the Pok�mon font and all other related names
 and and indicia are Copyrighted to Nintendo.





 Later!!! See ya in August! 