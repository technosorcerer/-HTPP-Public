********************************************************************************
*                             Nekojara Monogatari                              *
*                             English Translation                              *
********************************************************************************

This is an English translation for Nekojara Monogatari for the Game Boy.

****************************************
*               Credits                *
****************************************

Asbestoast - Reverse Engineering, Tooling, English Translation, Graphics