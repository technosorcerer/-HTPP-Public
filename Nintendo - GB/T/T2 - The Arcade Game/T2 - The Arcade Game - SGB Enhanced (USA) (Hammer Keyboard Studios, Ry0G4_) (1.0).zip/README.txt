«T2 - The Arcade Game (USA, Europe) SGB Enhanced»


A T2 - The Arcade Game (USA, Europe) HACK created by:

Hammer Keyboard Studios / Ry0G4_
https://darkryoga.wordpress.com/

Description: «T2 - The Arcade Game SGB Enhanced» is a hack of T2 - The Arcade Game (Game Boy). This hack adds a custom border 
and custom palette set to make this game FULL compatible with the Super Game Boy peripheral.

>>> INSTRUCTIONS <<<

  ***************************************************************************************************************
  * To play - This rom hack is distributed as an IPS (International Patching System) patch. 
  * You'll need to find the «T2 - The Arcade Game (USA, Europe) rom on your own. Once you have it, 
  * you can use a website or program like "Lunar IPS" to apply the patch to the rom. You'll also need a Game Boy 
  * emulator, like BGB or mGBA, to run the patched rom. The patched ROM also works on a real Super Game Boy.
  ***************************************************************************************************************