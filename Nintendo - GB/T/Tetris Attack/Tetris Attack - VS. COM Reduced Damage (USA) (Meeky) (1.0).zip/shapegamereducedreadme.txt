========================================================================
More patches for the sadly watered down port of Game Boy's Tetris Attack
Created and checked for by Meeky (since I'm the only one who does this!)
========================================================================

Long story short, was going to do this the hard way, but soon realized
that I could change multiple values in ROM to get the effect I wanted.

So here they are! Patches that...reduce attack power?

Allow me to explain. VS. COM with vanilla settings isn't very difficult,
and I wanted to at least make it more difficult for challenge seekers.

This is where Reduced Damage comes into play. It simply reduces attacks
from chains all the way up to ×9, so remember to CUT YOUR CHAINS since
anything beyond ×9 simply gives you the damage value correlating to ×9.

Albeit, in its now reduced form. Before, you could simply OHKO Kamek
with an ×9 attack on Hard and be done with his healing shenanigans.

So in a nutshell, damage that you do has been nerfed in these patches.

They also break traditional speedruns of a mode that has already been
optimized by players who like to chain very fast and very efficiently.

However, there IS a silver lining! Combo Damage has NOT been reduced
in the ×2 variant, though it /does/ get halved in the ×4 variant. This
makes beating VS. COM on the not-so-secret hardest difficulty possible.

These patches are also compatible with my other patches for this game.

I also rarely use Discord. I'm a dork (@avgstr) who looks like a star.

Yup, I'm definitely a dork that doesn't rely on STG's to get his fame.

----

要するに、最初は面倒な方法でやろうとしたんだけど、すぐに気づいたんだ。
ROM内の複数の値を変更すれば、望んだ効果が得られるってことに。

というわけで、これがそれだ！ パッチで…攻撃力を減らす？

説明させてくれ。デフォルト設定のVS.COMはそれほど難しくないから、
挑戦好きなプレイヤー向けに、せめて難易度を上げたくてね。

ここで「ダメージ減少」が活躍します。チェーン攻撃のダメージを
最大×9まで単純に減らすので、チェーンは×9で切り上げることを忘れずに。
×9を超えると、×9に相当するダメージ値しか与えられなくなるからです。

とはいえ、減った形ではありますが。以前はハードモードでカメックを
×9攻撃でワンパンKOでき、回復の面倒も省けました。

つまり要約すると、これらのパッチでは与ダメージが弱体化されている。

また、高速かつ効率的な連鎖を好むプレイヤーによって最適化されていたモードの
従来型スピードランも崩壊した。

しかし、救いがある！コンボダメージは×2バリエーションでは削減されておらず、
×4バリエーションでは半減するものの、完全には削減されていない。これにより、
「あまりにも秘密ではない」最高難易度でのVS. COMを攻略可能にしています。

これらのパッチは、私が作成した他のパッチとも互換性があります。

ちなみにDiscordはほとんど使いません。スターみたいな見た目のオタクです（@avgstr）。

ええ、STGに頼らずとも名声を得られるオタクです。
