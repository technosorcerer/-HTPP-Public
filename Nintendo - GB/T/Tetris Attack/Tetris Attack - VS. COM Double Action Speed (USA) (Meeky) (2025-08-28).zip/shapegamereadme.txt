===================================================================
A patch for the sadly watered down port of Game Boy's Tetris Attack
Created by Meeky (it was about time since this game is pretty old!)
===================================================================

This is a quick and dirty patch that doubles the speed of CPU [PW]
gauges for a greater challenge. CPU attacks are unchanged for now.

Original:

   Easy - 40 steps per bar increase
 Normal - 36 steps per bar increase
   Hard - 34 steps per bar increase
SP Hard - 32 steps per bar increase

Modified:

   Easy - 20 steps per bar increase
 Normal - 18 steps per bar increase
   Hard - 17 steps per bar increase
SP Hard - 16 steps per bar increase (!!)

VS. COM is normally too easy. Hopefully it's not so easy this time!

I rarely use Discord. I'm a dork (@avgstr) who looks like a star...

----

これは手っ取り早いパッチで、CPUの[PW]ゲージの速度を倍増させ、
より高い難易度を実現します。CPUの攻撃は現時点では変更されていません。

原文:

 イージー - 1小節あたり40ステップ増加
 ノーマル - 1小節あたり36ステップ増加
     ハード - 1小節あたり34ステップ増加
SPハード - 1小節あたり32ステップ増加

修正済み：

 イージー - 1小節あたり20ステップ増加
 ノーマル - 1小節あたり18ステップ増加
     ハード - 1小節あたり17ステップ増加
SPハード - 1小節あたり16ステップ増加 （！！）

VS. COMは普通は簡単すぎる。今回はそうじゃないといいんだけど！

Discordはほとんど使わない。俺はオタク（@avgstr）
で、見た目はスターみたいなやつ…

（また、私は日本語が全く話せないので、この情報を翻訳しています...）
