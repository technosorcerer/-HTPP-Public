=========================================================================
Another patch for the sadly watered down port of Game Boy's Tetris Attack
Created and checked for by Meeky (since I'm the only one who does this!)
=========================================================================

Put off making this for a while...it may have taken almost three decades,
but finally, here it is! A patch that makes VS. COM opponents tougher on
ALL difficulties while also properly aligning with their characteristics.

You may also combine this with the Double Action Speed patch if you wish.
Remember to patch this hack FIRST, before you patch in the other hack!
So, like this: Unmodified ROM -> Round 2 Patch -> Double Action Speed.

Here are some changes from the screenshots: (the rest of 'em are secret!)

• On EASY, Gargantua Blargg and up have a low chance of sending an ×3
  Garbage Block on your playfield, with the final two opponents also
  having a low chance of sending an ×4 Garbage Block.
• Starting with Lunge Fish on EASY, Shock Garbage Blocks are sent over
  rarely. The final two opponents don't send any at all since they still
  have no idea how to make Shock Garbage Blocks at this point.
• EASY also serves as an introduction for how PW retention rate can be
  used to show off how tough opponents can actually get in battle. It
  may still be easy for the player, but it definitely gets harder!
• Naval Piranha gets its healing ability one difficulty early as an
  introduction to the mechanic. Since this is the last stage, it fits.
• Moving on to the NORMAL difficulty, Flying Wiggler has a low chance of
  launching a surprise ×4 Garbage Block attack, and these power attacks
  don't give any retention, since these are meant to be the strongest.
• Starting on NORMAL, Froggy can actually heal himself, which also
  serves as a reminder that this is ramping up in difficulty level.
• Once again, Gargantua Blargg favors power over strategy on the NORMAL
  difficulty. Unlike in Stage 3, the chances of sending ×4 are higher.
• Surprise! Raphael the Raven can also heal himself if his health is low
  enough. It's not much, but for NORMAL difficulty, a welcome challenge.
• Hookbill hits hard...sometimes. On NORMAL difficulty, this is typically
  ×3 and ×4 Garbage Blocks, but in R2, there is a single ×5 he can send.
• Finally, on the NORMAL difficulty, Kamek's HP was normally lower than
  the unused EASY counterpart. His HP properly matches this as intended.

In the end, I had fun making little balance changes, as well as also
getting certain attacks to proc since I wanted to show those off fairly
early. Also didn't want any spoiling of the higher difficulties because
it'd be entertaining for players to find out how I made things harder!

I also rarely use Discord. I'm a dork (@avgstr) who looks like a star.

Yup, I'm definitely a dork that doesn't rely on STG's to get his fame.

----

しばらく制作を先延ばしにしていましたが…ほぼ30年近くかかってしまいましたが、
ついに完成しました！ VS.COM対戦相手の難易度を全レベルで強化しつつ、
それぞれの特性に適切に調整するパッチです。

ご希望であれば、ダブルアクションスピードパッチと併用することも可能です。
他のハックを適用する前に、必ずこのハックを最初に適用してください！
つまり、この順序です：未改造ROM → ラウンド2パッチ → ダブルアクションスピード。

スクリーンショットからの変更点の一部をご紹介します（残りは秘密です！）：

• イージーモードでは、ガルガンチュア・ブラッグ以上の敵が低確率で×3
  ガベージブロックをプレイフィールドに送る低確率が発生。最終2体の敵はさらに低確率で×4ガベージブロックを送る。
• イージーモードではランジフィッシュ以降、まれにショックガベージブロックが送られる。最終2体の敵は現時点でショックガベージブロックの生成方法を知らないため、一切送らない。
• イージーモードは、PW保持率を活用して敵の戦闘強度を表現する手法の導入例でもある。プレイヤーにとっては依然として簡単かもしれないが、確実に難易度が上がる！
• ナバルピラニアは回復能力を1段階早い難易度で習得する。これはメカニクスの導入として意図されたもので、最終ステージであるため適切である。
• NORMAL難易度では、フライングウィグラーが低確率で
  サプライズ×4ガベージブロック攻撃を仕掛けます。これらのパワー攻撃は
  保持効果を持たないため、最強攻撃として設計されています。
• NORMALから、フロギーは自己回復が可能になります。これは難易度が
  上昇していることを示す指標でもあります。
• ガガンチュア・ブラッグはノーマル難易度でも戦略よりパワーを重視。ステージ3と異なり、×4攻撃の発生確率が上昇。
• 驚いたことに、レイヴン・ラファエルも体力が十分低下すれば自己回復可能。回復量は少ないが、ノーマル難易度では歓迎すべき挑戦要素。
• フックビルの攻撃は…時折強烈だ。NORMAL難易度では通常×3と×4のゴミブロックだが、R2では単発の×5を放つことがある。
• 最後に、NORMAL難易度ではカメクのHPは未使用のEASY版より通常低かった。意図通り、そのHPが適切に調整されている。

結局、細かいバランス調整を楽しむと同時に、特定の攻撃を早期に発動させるのも楽しかった。
だって早い段階で披露したかったからね。
高難易度のネタバレも避けたかった。
プレイヤーに「どうやって難易度を上げたのか」を発見してもらうのが面白いからさ！

Discordもほとんど使わない。俺はオタク（@avgstr）だけど、見た目はスターみたいなんだ。

そう、俺は間違いなくオタクだ。STGに頼らずとも名声を得られるタイプだからな。
