Someone pointed out to me that Alberto Gonzalez, the composer of this game, had noted on his soundcloud page that this games' soundtrack was programmed with stereo panning, but due to a programming bug the released game was in mono.

This patch corrects the bug by making the routine which checks for the mono/stereo flag always return 1. 

Enjoy this game with stereo audio! 