Tetris DX Easy Access version 1.1 by bankbank

Tetris DX has two delays when getting into the game:

1) at bootup, there is a 2 second unskippable license screen
2) if there is no save file present, the user must enter their name before they can play

This hack removes both of these delays.

Upon bootup, the player is able to press a key to skip the license screen.

The title screen allows free selection of play rather than forcing name entry. This is very handy when playing the game on devices that don't support SRAM save - such as a Tetris DX cart with a dead battery.

Simply patch your original 'Tetris DX (World) (SGB Enhanced).gbc' ROM with this patch and you're ready to go.

changelog:

* version 1.1 - no music change

* version 1.0 - patch was applied to a ROM which had music A changed

Any issues? email bank [at] bankbank [dot] net