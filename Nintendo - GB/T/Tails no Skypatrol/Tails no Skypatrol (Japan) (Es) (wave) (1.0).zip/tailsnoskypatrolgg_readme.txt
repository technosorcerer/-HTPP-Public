Tails no Skypatrol (Game Gear)
Traducción al Español v1.0 (15/02/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tails no Skypatrol (Japan).gg
MD5: ffb364bbaf72881cf7571e7ec388490d
SHA1: 9cb440611e9e3a7957438698fede0978d568a807
CRC32: 88618afa
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --