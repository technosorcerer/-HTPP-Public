This game, along with several other Bit Managers titles with soundtracks by Alberto Jose Gonzalez, due to a programming oversight only play with mono audio. This patch alters the routine which checks for the mono/stereo playback flag to always retun true. 

-jmr, 2023