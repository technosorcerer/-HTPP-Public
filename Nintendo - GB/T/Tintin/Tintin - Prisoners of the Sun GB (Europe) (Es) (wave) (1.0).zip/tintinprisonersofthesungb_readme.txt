Tintin - Prisoners of the Sun (Game Boy)
Traducción al Español v1.0 (22/03/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tintin - Prisoners of the Sun (Europe) (En,Fr,De).gb
MD5: 8fdffde2db7f8da5cdb60a49d77a6b32
SHA1: a26a769aac6060705f24c3e0dde367b62962e921
CRC32: 55fc585f
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --