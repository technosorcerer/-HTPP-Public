Gameboy Tetris Colorization Hack

Includes:
1) Color! (Of Course)
2) Some Easter Eggs (try to find all of them!)
3) A Secret Mode :eyes:



I wanted to make this hack since quite some time ago, i started on july 2023 and as of November 19th, 2023, it's finally finished!!


For the TGM Lovers, i included a version of the hack that has the ARS colors instead of the SRS colors.

Enjoy!

Credits to (i'm probably missing some people):

=========gbdev Discord Server==========
               ISSOtm
                zlago
                evie
              PinoBatch
=====Gameboy Tetris Discord Server=====
               Tolstoj
                OSpin
====GB Colorizations Discord Server====
               tobiasvl
             ProstatePunch
              xenophile
                 256
               Andrew
                leina
               marc_max
              nitro2k01
                wyatt  

Thanks to all those people for helping me and teaching me how does assembly work!


































Rosy Retrospection hack, i'm coming for you >:)