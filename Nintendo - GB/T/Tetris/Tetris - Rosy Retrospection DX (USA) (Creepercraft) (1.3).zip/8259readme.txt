Tetris Rosy Retrospection DX



It's Finally Here!!!!!!

The wait is over, Creeper presents: The Tetris Rosy Retrospection Colorization Hack!!!

Includes:
-1) Randomized colors for the Title Screen, Level Selection menu and Rocket screen!
-2) a slightly improved "Danger-meter" adding blue at the bottom (Inspired on Tetris Axis)
-3) Guideline Features!!!!!!

Also includes Bug fixes of the original hack:
-1) the 7-Bag always starts full now!
-2) Pieces now spawn in the 21st row instead of the 20th row



Note: The game will NOT run on a DMG console.
Yet...

WARNING: THE PATCH DOES NOT INCLUDE THE ROSY RETROSPECTION HACK!!
So you must patch your rom with Ospin's hack first and then this one, otherwise it won't work



Enjoy!!






and someday, the "DX" and the "Rosy Retrospection" words will change places... wink wink

Changelog:

v1.3
This was first gonna be 1.2, then 2.0, then 1.1.1, then 1.2 again and now 1.3

- An Extra Legal screen, you can skip it by pressing A or you can also disable it forever by pressing B
- Now you can pick whether to use the Danger-Meter or not :D

- Fixed the bug where the screen filled with garbage when pressing B on the high score screen

- Now the board background isn't white!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

v1.1
-Oops, turns out that the pieces actually spawn in the 22nd row(according to the guideline) and not in the 21st as i thought, fixed!
-Ghost Piece and Hold piece palettes are lighter now to avoid confusion

v1.0
first release