================================================

       TINY TOON 2 MONTANA'S MOVIE MADNESS
           restoration hack by marc_max

================================================


This hack restores some features the Japanese version had:

- password function
- unlimited continues
- earn an extra life after winning a minigame
- earn an extra life after reaching 2000 points (instead of 3000)

Making the game more enjoyable and less frustrating.

Read more about the regional differences at The Cutting Room Floor:
https://tcrf.net/Tiny_Toon_Adventures_2:_Montana%27s_Movie_Madness#Regional_Differences

Source code among author's development notes are available in GitHub:
https://github.com/marcrobledo/tiny-toon-2-gb-restoration



PATCHING INFORMATION
--------------------
You must provide the original Tiny Toon 2 (USA/Europe) ROM:

Tiny Toon Adventures 2 - Montana's Movie Madness (USA, Europe).gb
CRC32: c5c7868d
MD5:   7aa389f71808dc989a38b41009a32851
SHA1:  b76aa64cc4123b7900569ff9db680935198db73f
 
Apply the patch here: https://www.romhacking.net/patch/



CHANGELOG
---------
v1.0b (2025-05-18)
- fixed: small graphic glitch during Montana's cutscene after completing a stage
- fixed: removed CONTINUE word from game over screen after completing game
- added: boss health reduced by one

v1.0 (2025-05-17)
- first version


DISCLAIMER
----------
This is a fan created game restoration, no copyright or trademark infringement is intended.
I am not affiliated nor endorsed by Konami.
