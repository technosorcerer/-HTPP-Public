Elevator Action (Game Boy)
Traducci�n al Espa�ol v1.0 (02/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Elevator Action (U) [!].gb
MD5: 7876945a990ea94ac6b1fe5cf01bc00f
SHA1: c0c9de672a31f314e98392160fc343cf46ee98b9
CRC32: b749a927
65.536 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --