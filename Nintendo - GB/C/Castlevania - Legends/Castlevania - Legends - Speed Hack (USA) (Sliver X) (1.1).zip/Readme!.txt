Castlevania - Legends: Speed Hack v1.1

2007 Sliver X (panicus@gmail.com)

http://panicus.googlepages.com

What it is
~~~~~~~~~~

Makes Sonia move faster. Probably blurs on the old brick Gameboys (There's
a reason why the GB CV games are so slow!), but for emulators it's sweet.

Important
~~~~~~~~~

The patches are meant for the following ROMs:

Akumajou Dracula - Shikkokutaru Zensoukyoku (J) [S][!].gb
Castlevania - Legends (U) [S].gb

Usage of any other ROM version may cause issues and incompatabilities.

How?
~~~~

The previous iteration of this hack made Sonia move as fast as when "Burning Mode"
is enabled. However, some people have told me that it's too fast, and cheapens one
of the aspects of Burning Mode.

Since I had recently hacked Belmont's Revenge to have faster character speed, I
thought of checking Legends to see if it shared common routines for determining
this with that game; turns out it does, which lends creedence to the idea that
Belmont's Revenge and Legends are based on the same engine.

So now Sonia moves faster, but not as fast at in v1.0. Burning mode will still give
her a speed boost on top of the upped attack power and invunerablitity.

Changes
~~~~~~~

v1.1: Toned down Sonia's speed slightly. Added a patch for the japanese version of the game.

v1.0: Initial release.