Catrap for Super Game Boy 1.0
by Plunskas
_____________________________

This is a romhack of the game "Catrap" for Game Boy that adds a border and a
custom palette for use in Super Game Boy.

Works in real hardware (tested in FXPak Pro by thirsty-pocket).

It is provided as a .bps patch file, it needs to be applied to a Catrap rom.
Filename: Catrap (USA).gb
CRC32: ADB96150
SHA1: 171e4d54f22f8dc137d12828fcc2da9874c56970

This has been possible thanks to the wonderful Super Game Boy Border
Converter and Injector tools made by marc_max, which you can find here:
https://www.marcrobledo.com/super-game-boy-border-converter/
https://www.marcrobledo.com/super-game-boy-border-injector/

I hope you enjoy it as much as I did making it.
Thanks for downloading!
