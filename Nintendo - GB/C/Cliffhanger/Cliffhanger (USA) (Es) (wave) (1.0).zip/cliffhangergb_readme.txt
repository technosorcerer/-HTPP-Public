Cliffhanger (Game Boy)
Traducción al Español v1.0 (07/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Cliffhanger (UE) [!].gb
MD5: b33d6f65f4a566d715ce480bffd004ad
SHA1: c74f85035842f8a2d9560066d7065ff86d9107e2
CRC32: aa133439
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --