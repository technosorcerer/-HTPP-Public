Castlevania 2 - Belmont's Revenge: Speed Hack v1.1

2007 Sliver X

What it is
~~~~~~~~~~

Hate how slow Christopher moves in Belmont's Revenge? Well hate no more.
This hack will add a burst of adreneline to the Vampire hunter and
make him move his ass like someone in the midsts of hell spawn should.


Variants
~~~~~~~~

This archive includes three patches:

Castlevania II - Belmont's Revenge (Speed Hack).ips: For the original USA GB Mono game.
*Monochrome, but a classic.

Dracula Densetsu II (Speed Hack).ips: For the Japanese version of the GB Mono game.
*Contains the Banshee Boomerang, which was censored from the US mono release.

Konami Collection 3 (CV2 Speed Hack).ips: For the Super Gameboy collection (Entry 2 on Menu). 
*Prettier, with semi-coloring and a nice border around the screen. Japanese.

Konami GB Collection Vol.4 (CV2 Speed Hack).ips: For the GB Color collection.
*Prettiest, with full coloring (But no border...).

Important
~~~~~~~~~

The patches are meant for the following ROMs:

Castlevania II - Belmont's Revenge (U) [!].gb
Dracula Densetsu II (J).gb
Konami Collection 3 (J) [S].gb
Konami GB Collection Vol.4 (E) [C][!].gbc

Usage of any other ROM version may cause issues and incompatabilities.

How?
~~~~

Via a lot of code tracing and flipping back and forth to z80 manuals. This was much more
difficult than hacking Legends was, but the result is well worth it.

Thanks
~~~~~~

A big thanks to Serio. Provided invaluable feedback and beta testing.

Changes
~~~~~~~

v1.1: Speed boost toned down to prevent unavoidable spike collision before Plant Castle boss. 
      Added hack for Dracula Densetsu II. 	

v1.0: Initial Release