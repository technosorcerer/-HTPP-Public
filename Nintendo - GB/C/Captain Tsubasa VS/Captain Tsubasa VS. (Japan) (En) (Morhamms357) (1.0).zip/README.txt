==============================================
CAPTAIN TSUBASA VS. (ENGLISH TRANSLATION) V1.0
               By: Morhamms357
==============================================

What's the difference between the normal version and the All-Star Version?

The All-Star version translates the names of every single character, even minor characters on the opponent teams with no graphics or moves. In the normal version, they're numbered as "No. #" based on their position.

This makes it so you can play in the VS. mode, which lets you play as opponent teams, and customize your player lineup. Else it would be confusing because "No. 3" could be at any position.

Still, unless you're dying to play as other teams at all times and completely customize your lineup, I wouldn't recommend it. There isn't enough space to fit every name, so lots are truncated. Plus, it makes playing the story mode harder, since it can sometimes be hard to keep track of the good players.

Have fun!