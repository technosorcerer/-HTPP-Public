Ikari no Yousai 2 (Game Boy)
Traducción al Español v1.0 (21/01/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en el de Stardust Crusaders.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ikari no Yousai 2 (Japan).gb
MD5: 1efea4210026a8d733a5b2ade2b005f1
SHA1: ae437d4fb39d7438fc9eb98c91820aa2b5161b4f
CRC32: 6d4fd9aa
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --