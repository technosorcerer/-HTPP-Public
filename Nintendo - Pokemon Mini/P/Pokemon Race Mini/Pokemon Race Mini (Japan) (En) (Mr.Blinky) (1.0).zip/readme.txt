Pokemon Race mini English translation
-------------------------------------

One of the best Japanese Pok�mon mini games is now translated into English.

Race mini is a very nice action paced game for the pokemon mini with many 
great features. One of the best features is the ability to compete against
a recording of one of your earlier races or one that was transferred from
another pokemon mini.
With all the graphics being translated into English, the game can really
be enjoyed to its full extent now.

Have fun playing Pokemon Race mini English translation

Mr.Blinky, October 2012

Credits
-------

Translations........................................ snesy, Wa
Graphics, Resource locating and code patching ....... Mr.Blinky
additional resource locating.........................Wa, JustBurn

Special Thanks
--------------

JustBurn, for his awesome PokeMini debugger which made resource
locating, patch and play testing a real pleasure.
Wa, for her great gfxchanger python patching tool
Everyone on #pmdev for their support.
