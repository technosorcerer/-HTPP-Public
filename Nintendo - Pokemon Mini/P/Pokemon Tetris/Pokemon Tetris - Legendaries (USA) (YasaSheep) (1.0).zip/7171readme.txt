# Shock Tetris Legendaries patch

Between May 18th, 2002 and June 30th, 2002 if you went to Pokémon Center Tokyo or Osaka, or one of a number official Pokémon gyms in Japan, then you could battle a staff member and receive a secret code from them, which when entered on the Options screen (while on-location) would enable you to access the ability to catch Mew and Celebi from infrared signals being broadcast there.

This event was called ポケモンショックテトリス赤外線でゲットだぜ！キャンペーン meaning the "You can get things in Pokémon Shock Tetris from infrared rays!" campaign. The participating gym locations were in Sapporo, Nagoya, and Fukuoka. If you beat the staff member, you could receive a T-shirt. If anyone has one, please send me a photo!!

For those of us outside of Japan (or those of us in the future) who missed this opportunity, we have to recreate this event ourselves. Although I've been working on replicating the IR communication, that alone would be difficult for people who only have one console or are playing on emulator.

As such, I'm releasing this patch which disables the checks for whether or not you participated in the event. This allows you to catch Mew and Celebi in Standard or 20 Lines on Master difficulty. They only appear for 2 turns, similar to the other legendaries, so good luck!

## Files

You may have a .min file with different junk data, so you can check the partial checksum below to see if it's okay, if the full one fails. Since these only modify a few bytes, it's probably okay anyway.

* tetris_e-legendaries.ips - IPS patch for Pokémon Tetris (EU)
  * CRC-32: 2FB23527
  * CRC-32 ignoring the bottom $2100 bytes: 9349C0A4
  * MD5: F100CAF74574AEABE5084F3B5C9E03D2
* tetris_j-legendaries.ips - IPS patch for Pokémon Shock Tetris (JP)
  * CRC-32: B4B5CC20
  * CRC-32 ignoring the bottom $2100 bytes: 084E39A3
  * MD5: 8243AD09F4E470E239056B096083B6BD

## Credits

* YasaSheep - me, doing all the research and the hack.
* Special thanks to Danius/Dani88alv and LarviStar for bringing it to my attention that these legendaries couldn't be caught normally.
* Special thanks to @purin_nau and 5ch.net for info on the event itself.

### Links

* [purin_nau's blog](https://purin-nau.hatenablog.com/entry/2020/06/14/013705)
* [5ch.net post](https://game4.5ch.net/test/read.cgi/poke/1009623176/) post #254
