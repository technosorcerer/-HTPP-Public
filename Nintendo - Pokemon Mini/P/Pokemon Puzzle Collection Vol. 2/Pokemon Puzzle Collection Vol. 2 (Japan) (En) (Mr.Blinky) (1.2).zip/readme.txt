Pokemon mini Puzzle Collection Vol.2  Unofficial English version 1.2
--------------------------------------------------------------------

                        by Mr.Blinky and Wa


After just over a week of intense reverse engeneering, hacking,
editing and translating, a 100% Translation completed on 2011/02/25.

All Game screens, help screens, bonus screens, options, pokemon names,
pokedex and save game system messages were translated. 

All the patching is done using Wa's excellent Graphic changer tool gfxchgr.
Without it, the project would probably have taken ages to finish or not at all.


Mr. Blinky

Note this is the 2nd release with typos in some pokemon names fixed.

Special thanks to:

Wa        For being the major contributor to this project on
          translating, artwork and writing her exellent gfxchgr tool.

Other thanks go to:

Asterick for his Minimon debugger which was a great help to the project.

Justburn for his great PokeMini emulator giving the best realistic
         picture of the new artwork.

ContraPie, lessly for translations.

Those on #pmdev
