Pokemon Breeder mini English Translation
----------------------------------------

Finally ! Finished !

I was worried for a while on successfully completing
the translation due to difficulties in translating
the large quantity of japanese dialogs.

After doing all the graphic translations and code
patches I was simply stuck, Unable to translate those
dialogs.

Months passed by without any progress. But then, Lupin
found someone who is very good at japanese.
This person is no one else then snesy. He's great at
japanese. As soon as he joined, it took him just a
couple of days to translate all those japanese dialogs.
With the translations now done I could pick up the
thread and continue. Less then two weeks later I
finished the translation.


Credits
-------

Code patches and Graphics translations.......Mr.Blinky 
Japanese text dialogs translations...........snesy
Graphics transations.........................Wa 

Special Thanks
--------------

To JustBurn, for his exelent PokeMini debugger.
To Lupin, for his flash cart, tools and introducing snesy.
Every one on pmdev for cheering.


Note for playing the game on real hardware. Like the original
when you "power off" while you are in the house or outside, 
the Pok�mon mini doesn't realy power off. It switches off the
display and cart slot and enters a sleeplike mode. But every
4~5 minutes it powers up shortly. This will drain the battery
faster.
To save the battery, choose QUICK BREAK in the ingame menu and
then power off your pokemon mini.


Have fun playing Pok�mon Breeder mini English translation

Mr.Blinky, July 2011
