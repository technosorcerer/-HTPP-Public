Pichu Bros. Mini: English Translation
V1
21 May 2019
-Nikc


The Pichu Brothers have picked out six monochromatic mini-games for you to play, in this entry for the Pokemon Mini console!

*Find out if you can accurately count to 10 seconds and stick the landing in Magby's Hot Air Balloon
*Help Smoochum harrass some Digletts in her kiss-crazed version of Whack-a-Mole
*Play a rousing game of catch with Cubone and a friend, or practice by yourself in Training Mode
*And more! (Three more, to be precise)

Compare your scores with your friends, or battle against each other in a timed Challenge Mode!

(Incidentally, this was the last untranslated game for the Pokemon Mini. Now the entire console's library is playable in English!)

v1
------------
*English translation added

**************
Future Updates
*Translating the remaining multiplayer graphics in ROM
*Touch-ups to backgrounds, sprites, and sprite maps
**************

How to patch:
Get a copy of the Pichu Bros. Mini ROM, and an IPS patching program (Lunar IPS seems to be the standard).
Run the program, click 'Apply patch', and viola! Enjoy.

Tools Used:
----------------
PokeMini Emulator
img2png Image Convert
YYChar.net Tile Editor
XVI Hex Editor
-----------------

Special Thanks
----------------
Wa/Kadalyn
Mr. Blinky
Members of the Pokemon-Mini.net Forums and Discord
----------------

Questions? Glitches? Comments?
nikcdc@gmail.com