Rock Band 2 - DualShock Patch
Patch made by Gledson999

This patch allows Rock Band 2 to be compatible with
the DualShock controller, just like it was in the
first games in the Guitar Hero series, no longer
needing a guitar controller to play.

SITE: 
https://www.retro-jogos.com