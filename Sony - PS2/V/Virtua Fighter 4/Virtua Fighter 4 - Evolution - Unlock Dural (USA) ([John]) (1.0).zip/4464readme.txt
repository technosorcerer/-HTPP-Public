Virtua Fighter 4:Evolution [SLUS_206.16] -Unlock Dural-

Update: 
Enable Dural as a selectable character on both Virtua Fighter 4 Evolution and Virtua Fighter 10th Anniversary.

The patch can be applied to the iso file through the program Delta Patcher which can be found in this site.

==============
Special thanks
==============
Special thanks to the original creators of these hacks.
Unfortunately I do not know their names, but the credit is for all of them.
The hacks presented in this patch are partially based on their work.

=============================================================
Virtua Fighter 10th Anniversary - Original Hacking by [Jhon]
=============================================================
www.Emudesc.com|User:John-Paul
==============================
   Twitter: @Juan_Pablo_81
==============================