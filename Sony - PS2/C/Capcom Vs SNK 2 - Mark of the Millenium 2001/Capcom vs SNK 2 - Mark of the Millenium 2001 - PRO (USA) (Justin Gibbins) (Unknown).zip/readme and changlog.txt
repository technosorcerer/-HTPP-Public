---Capcom vs. SNK 2 PRO------------
This is a version of CvS2 that basically intends to back port most of the key fixes from CvS2 EO into the original home version of CvS2 (which already had its own fixes), while also fixing a few outstanding bugs the EO version didn't fix, adding in a progressive mode (which the PS2 version never had), and updating some of the text to address various spelling errors, inconsistencies, etc. 

In general it doesn't try to overstep its bounds in terms of balance, sticking mostly to official EO changes, but there is one thing it does very differently from EO:

Roll Canceling is incorporated into the system, rather than simply removing the invincibility.


---Why?----------------------------
Fighting games rarely get this kind of treatment, so I can understand the question.

This isn't meant to replace any version, new or old, but is simply a love letter or even a sendoff to an era of the game, primarily played on CRTs (but 480p panels are also welcome).

You can also think of it as a "What-if", as in, "What if Capcom had done this instead?" Would people have largely accepted EO?

You tell me.


---How to Apply this Patch-----------
Digitally backup your copy of the US PS2 game, such that it matches the Redump ISO image with a CRC of 79595100, then apply the patch using xdelta.



---Game Changes----------------------
Here's everything that was changed for this version, as well as documenting where changes came from in regards to the various releases of this game, such as if they were in the original home port, the EO version, or if fixes are unique to this. 

If something is noted as a "Home version" fix, then that means it was already here in the PS2/DC version. I'm including those notes for specifically notorious bugs that are often shown in videos.


--Main Gameplay--
● Player 2 can no longer take the corner from Player 1 when they are downed in such a way that their sprite faces the corner: PRO
● The left corner will no longer send opponents in a juggle state out of the corner, if the player lands an moving attack on them while they both occupy the same space / corner: PRO
● Roll Canceling is incorporated in the main system: PRO 
   ○ It now costs about a third of Guard meter to perform.
   ○ It has an extended window of around 3 frames in which to execute it, making it easier, and also allowing you to extend the reach of some moves further to get in on your opponents.
   ○ Invincibility will not be applied while the guard meter is flashing, but you can still get an extension.
● Throw Tech Reversal glitch mitigated: PS2
   ○ The PS2 version generally will elect for positive interactions in the event of certain overlapping reversals, depending on the timing and character state, though there are still a few specific cases, especially related to grappling/catching colliding, where the game doesn't have an answer for the overlap, and instead of blowing up, elects to just stop both moves from happening and have both characters go to neutral, preventing soft locks or graphical issues.
   ○ The EO version cleans this up more consistently, but the PS2's solution is good enough for the time being.
● Meter gain after KO removed: Home versions


--Grooves--
C Groove:
● No change

A Groove:
● Custom Combo can be activated after a air attack connects and in a cancel-able state: EO
   ○ This applies to most moves, but certain moves with chaining effects, like Bison's Hell Attack (j.MP~j.MP) do not count.
● Chip damage is significantly reduced: Home versions

P Groove:
● Can cancel a special into a Super, like in 3rd Strike: EO
● Guard Crush meter increased to 90% of normal, from 80%: EO
● 2 additional active frames on the tap parry (standing, crouched, and air): PRO
   ○ Pressing forward and any other direction still only applies 4 frames of detection at minimum before canceling if not returned to neutral.
   ○ This value was not changed for EO, but certain aspects of how the game ran and calculated frames made it such that it was more lenient on this input, and as such, this is compensated for here.

S Groove:
● The charge rate value for each tick of charging the S Groove meter has been increased by one up to the maximum charge rate, which greatly increases the initial charging of the meter: EO

N Groove:
● No change

K Groove:
● Guard Crush meter decreased to 80% of normal, from 90%, swapping it's value with P Groove: Pro
   ○ Just Defense is no risk all reward, and with the tremendous defense buff of Rage, this seemed to make sense.


--Characters--
Several characters had 5% up or down adjustment made to every attack they do in the core attack damage calculator, and there's a common them to who gets it. In addition to the move set changes these are all take exactly as they were from the Gamecube EO version of the game.

The Xbox version, while supporting key gameplay fixes and the damage adjustments for characters, DID NOT make move set adjustments for most of the cast, which means in the Xbox version, Dan can still be thrown off the ground, and Sagat can super cancel from his far heavy punch. My guess is they did not have the right people to convert the tables in time for release.


Guile:
● Increased recovery after all Sonic Booms by 2 frames to 23 (same for all levels)
● Decreased Damage of light Boom by 100 and medium and heavy by 200, so all Booms are down to 500 base damage

Zangief:
● 5% Overall Attack INCREASE
● Adjusts a character immunity setting when landing after the Aerial Russian Slam if it whiffs, where it was briefly immune to most things for a very, very brief window, where now it should just be grab immune for that short period.

Dhalsim:
● All Long Range Normals (Standing, Ducking, Jumping) - Removed 2 starting animation frames, decreasing start-up by that much (and making the moves shorter as a whole). 
● Heavy punch & kick, and all crouching punches had their hit box slightly pulled back on the initial attack frame, but remains the same for the duration after.
● Jumping attacks have had a few parameters adjusted. Hit box adjustment on first active frame, and another value increased, possibly hurt box as the moves seem to lose to more things.

Blanka:
● 5% Overall Attack REDUCTION

Vega (Claw):
● 5% Overall Attack REDUCTION (present since PS2/DC version)
● A few of his clawless attacks also receive a base damage reduction, as below.
   ○ All Izuna drops are reduced 200 damage to 1800
   ○ Standing Heaving Kick Throw is reduced by 100 to 1600, making it more in line with the Heavy Punch throw
   ○ Close crouching medium, as been reduced by 100 damage to 600
These reductions continue to stack with his clawless debuff as well.

Sagat:
● 5% Overall Attack REDUCTION
● Standing Far Fierce has an added frame in the very first portion of start-up (before Sagat readies his hand) and in the portion where he first brings up his fist, making for a total of 2 additional frames prior to the active portion of the attack.
● His Crouching Fierce has one added frame to the wind-up, making it not possible to cancel into a super after the attack connects (it was a single frame margin before where it was possible)

Cammy:
● 5% Overall Attack REDUCTION
● They tried to increase the recovery time on her Canon Spike, but the trajectory to the ground always sets a fixed recovery value for this move. Basically, originally they set it for 4, then tried to increase it to 6, but really, it's always 5.
● They increased the recovery frames by 2 of a certain sit animation that has 3 weight levels, but the game never calls this particular animation series (even in other versions). This is the same style of recovery of Spiral Arrow (and the associated supers), the no input Hooligan Combination, and her dive kicks, and a few other grounded recovery style animations. Spiral arrow has its own call for this style of recovery, and the dive kicks also all call the same individual one for themselves. None of them seem to vary this by weight either. Possibly could have been intended for a variable Spiral Arrow recovery (since it immediately follow that and the simple recovery), but was just never hooked up.

Morrigan:
● Fixed an issue where her rise after getting crumpled wasn't properly marked as rising frames, which likely may have caused some crossover / OTG situations.

Kim:
● Fixed the duplicating sound issue for Kim when he stomps.
● His stomp across all levels now sends the opponent to the ground when they are in a juggle state.
● Fixed Kim's Aerial Super such that specific opponents very low to the ground can still be caught and attacked before Kim has to touch the ground (Cammy Spiral Arrow glitch)

Rugal
● His Far Fierce had a massive buff of 300 damage, now up to 1400.

Vice:
● 5% Overall Attack INCREASE
● Medium punch base damage reduced by 200 to 1000 (it was more powerful than her Fierce close)
● Fierce punch base damage increased by 100 to 1300

Dan:
● Dan can't be OTG'd while getting up from a knockdown
● Decreased the hurtbox on his standing custom combo activation animation, allowing him to pass through more attacks when they overlap with the activation and freeze.

Eagle:
● 5% Overall Attack INCREASE
● Changed all versions of Liverpool White such that it no longer knocks back and downs the opponent, and added a minimal amount of pushback on hit. Opponent will still be in striking distance, and this move is negative on hit, so it can no longer be used as a tool to get in over fireballs, UNLESS you use it with P or A groove, which both allow you to cancel out of it with meter, in which case it can be very powerful, since you can now combo from it.
● Reduced start-up on all Saint Andrews Green by 5 frames, down to 4 frames of start-up, and reduced recovery frames across multiple animation frames for a total of 10 fewer frames of recovery. It's much easier to hit fireballs with this move and not be punished, follow-up on juggles, and custom combos as well.
● Massively increased the reflected projectile power of light Saint Andrews Green by 600 damage, up to 2000.

Maki:
● 5% Overall Attack INCREASE
● She can't activate CC and combo off Fierce Punch throw
	○ This was still possible in the EO version.
	○ For this PRO version, the recovery was increased by 3 frames total across the final section of her animation.

Kyosuke:
● 5% Overall Attack INCREASE
● Medium air punch causes the opponent to float up a bit less, to make it easier to complete aerial raves.
● Kyosuke's grounded normal game was generally improved across the board.
● Shortened the recovery by 1 frame for close light kick, low medium, and low forward.
● Shortened the recovery by 2 frames for far light punch, close medium punch, far medium punch, far light kick, close forward kick, and far forward kick.
● Shortened the recovery by 10 frames for close Fierce

Hibiki:
● She can't activate CC and combo off Heavy Kick throw
	○ This was still possible in the EO version.
	○ For this PRO version, the recovery was increased by 3 frames total across the final section of her animation.
● Her special winpose now takes into account the possibility that an opponent with K groove may get a the defense buff after the attack deals its initial meter damage, so she doesn't leave herself minus infinity in a game winning position.

God Rugal:
● His Far Fierce had a massive buff of 300 damage, now up to 1400, like regular Rugal.

Rolento
● He cannot be OTG'd with special grabs anymore.


--Text & Voice--
In general, text was touched to better serve certain characters, especially on SNK side. Shortly after this game's release, we'd see better attention to characterization and moves for these characters in English, and this tries to bring some of that in, while remaining period appropriate. There is some shared DNA with the work I did on CvS Pro, as much of that carried over from the first, but I touched up what came over since I had the benefit of time and a smaller footprint to work with.

I wouldn't have touched the ending dialog or some other items, but there was enough issues with incredibly short lines on much of the new stuff, or typos, that it seemed at least worth a shot. I am certain the English team did not have a lot of time to get their work in, but I can tell that they reasonably were going in the right direction, just obviously constrained. So really I just wanted to expand on that work, since the space and time is here now.

Specific updates are as follows:

● Most win quotes are updated
● Many SNK characters had their moves made consistent with typical conventions
● Censored religious themes have been restored. God Rugal and all lines relating to that, and of course Akuma and others who reference lore outside typical Western concepts. Honestly, none of it is egregious or offensive, as I see it, but I can understand the sensitivity at the time.
● Rugal and Sagat's moves have hadtheir names restored, and they appropriately call out the names.
● When you get a Dramatic KO, the Announcer now shouts FINEST KO, as in the JP version
● All endings and rival lines updated for readability, and accuracy in some cases.


--Platform Changes--
A progressive mode has been added, new to the PS2 version. This was a bit tricky to some extent to get running, as the game uses the PS2's field rendering method with a half sized buffer, so I had to implement a means to activate a full frame mode, without replacing the original display method. Progressive changes the color display mode so as to be able to fit everything in VRAM, which is typical on the PS2, and is consistent with the Dreamcast version.

I went through and cleaned up most things to ensure everything displayed correctly, without harming the quality of the original assets in the game. There's two instances of rogue triangles displaying in non-core gameplay segments (which hopefully you never notice haha), but otherwise everything is in-line with the Dreamcast version.

To activate Progressive, just hold Triangle and Cross while the game is booting up, as is typical with the PS2 games that support progressive modes. You can stop holding once the Memory Card screen shows up, or you see your display update the output.

There is an additional option to disable dithering, if you so desire, but this leaves in color banding and could be less-pleasing in certain circumstances. Keep in mind, the Dreamcast version also has dithering when outputting via VGA. Even so, if you want to try this mode, just hold R1 while holding the standard Progressive mode command above, and the game will boot without dithering, and instead with color banding.


---Special Thanks--------------------------
Thanks to Capcom and SNK for making a great game. I grew up playing it on Dreamcast and PS2, and I still love it. Never got tired of it, even while testing. Always wanted a version like this for PS2 or Dreamcast, and here we are today. If you're like me, then please BUY THE NEW CAPCOM VS SNK GAMES WHEN THEY RELEASE. I know I will!

I should thank NeoCVera as well, because I probably wouldn't have put in the progressive mode if it hadn't been the first thing he said when I mentioned this project to him. It immediately made me realize that not everybody prefers playing on a CRT, like me haha.

