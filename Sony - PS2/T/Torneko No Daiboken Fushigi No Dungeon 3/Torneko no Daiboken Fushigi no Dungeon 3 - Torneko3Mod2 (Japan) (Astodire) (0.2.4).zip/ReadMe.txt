Torneko3Mod2 v0.2.4 / Windows x64

TORNEKO NO DAIBOKEN FUSHIGI NO DUNGEON 3/ トルネコの大冒険不思議のダンジョン3 Unofficial Patch

This unofficial patch for TORNEKO NO DAIBOKEN FUSHIGI NO DUNGEON 3 includes new monsters, items, and dungeons accessible from Puchi Village.

Additionally, several existing bugs have been fixed:
 - In monser houses, items and traps are no longer placed in the air.
 - When an Eradication Scroll hits a monster, breads, gold, keys, and medals in Curse Pots no longer become cursed.
 - When a Rula Grass on the ground is placed in a Grass Pot, now it disappears.
 - Preservation Pots are no longer duplicated when a Baby Satan steal it while on a tripping trap. (Ver0.1.2)
 - Several minor bugs have also been fixed.

How to use:
1. Rip the ISO image file from the game CD.
2. Open exe file and select the ISO file as the input.
3. Choose the output DVD format from the following options:
   (1) FDVDB-ESR patched DVD ISO, playable on an unmodified PS2 slim console.
   (2) Standard DVD ISO.
4. Press the patch button and select the output file.

To play (1) on an actual PS2 (SCPH-70000~90000), set the console language to English,
burn the ISO file onto a high-quality DVD-R, and boot it on the PS2.
See more information on the FreeDVDBoot GitHub page:
https://github.com/CTurt/FreeDVDBoot

--
Version 0.2.4
 -  Fixed a bug where the game could freeze when receiving a Majin Slash while wearing the Kamihitoe Ring or the Mikiri Ring.
 -  Fixed a bug where the game could sometimes freeze when hitting an enemy monster with a heart.
 -  Adjusted monster pots so that items are not consumed when no monster appears.
 -  Fixed several minor bugs.

Version 0.2.3m
 -  Fixed an issue where allied monsters could inherit previous monsters's heart capacity.

Version 0.2.3
 -  Fixed a bug where the game could freeze when having a monster from the Dragoslime family as an ally.
 -  Dungeon 2: Fixed an issue (from 0.2.1) where the game could freeze due to a rare map generation failure on 46F and below.
 -  Dungeon 2: Re-fixed an issue where enemies would stop spawning in Large Monster Houses.
 -  Fixed an issue where the pillar of fire tile effect had no effect on Slime Tar.
 -  Fixed several minor bugs.

Version 0.2.2m
 -  Dungeon 2: Re-adjusted the visibility settings on 29F and 35F.

Version 0.2.2
 -  Dungeon 2: Increased the number of items inside walls.
 -  Dungeon 2: Adjusted corridor connectivity from 46F and below.
 -  Fixed an issue where Max HP could sometimes increase when leveling down.
 -  Fixed an issue where the maximum and minimum possible Max HP values were not being calculated correctly.
 -  Fixed an issue where the Berserk infliction rate of Despecter's special ability was lower than intended.
 -  Fixed an issue where the level-up bonus was fixed when leveling up by more than 2 levels at once.
 -  Fixed several minor bugs.
 -  Corrected several in-game text.

Version 0.2.1m
 -  Fixed an issue where sealed monsters would incorrectly flash red.

Version 0.2.1
 -  Balance adjustments (considering the order of item drop checks and recruitment checks):
      - Adjusted the recruitment bonus effect of Magic Claw to 2%.
      - Increased the Heart drop rate of boss monsters.
 -  Dungeon 2: Added Star Kimera to monster placement.
 -  Corrected data entry errors:
      - Dungeon 2: Adjusted the visibility settings on 29F and 35F.
      - Fixed the slowed movement attribute of Metal Biter.
      - Adjusted the Heart drop rate of Slime Knight.
      - Corrected monster type flags for Steel Colossus.
 -  Dungeon 2: Fixed an issue where enemies would stop spawning in Large Monster Houses.
 -  Dungeon 2: Fixed an issue where some monster models were not loading properly.
 -  Fixed an issue where the game could freeze during the resurrection animation from Zombie Graves.
 -  Fixed an issue where Dokudoku Zombie could remove multiple Insignias at once.
 -  Fixed an issue where Killer Machine's parameters increased on level-up even without possessing a Machine Heart G.
 -  Fixed a bug that allowed holding multiple Hearts of certain growth types.
 -  Corrected several in-game text.

Version 0.2.0
  *** WARNING ***
  SAVE DATA FROM THE PREVIOUS VERSION IS NOT COMPATIBLE.
  ITEM DATA OF NEW RINGS AND CLAWS MAY BECOME CORRUPTED.
  ***************
 -  Added a new dungeon for Popolo.
 -  Fixed numerous bugs and corrected typos.
 -  Adjusted the prices of several items.
 -  Modified the success rate of Zauriku.
 -  Changed the behavior logic of some monsters' special abilities. Killer Crab and Metal Dragon.

Version 0.1.4
 -  Fixed bug: When a Cannibox on the ground is placed in a Synthesis Pot, it does not disappeared.
 -  Dungeon1: Slightly increased the spawn rate of Monster Food, as it was not appearing as intended.

Version 0.1.3
 -  Fixed bug: blessed Defence Seed, or when drinking it in mystical state, had no additional effects.
 -  Dungeon1: Adjusted the level of Doroningyo to the intended value, as it was not properly reflected in previous versions.
 -  Updated character visuals.

Version 0.1.2
 -  Several bugs have been fixed.

Version 0.1.1
 - The application has been converted to a self-contained deployment.

