Torneko3Mod2 v0.1.0

TORNEKO NO DAIBOKEN FUSHIGI NO DUNGEON 3/ トルネコの大冒険不思議のダンジョン3 Unofficial Patch

This unofficial patch for TORNEKO NO DAIBOKEN FUSHIGI NO DUNGEON 3 includes new monsters, items, and dungeons accessible from Puchi Village.

Additionally, several existing bugs have been fixed:
 - In monser houses, items and traps are no longer placed inside walls.
 - When an Eradication Scroll hits a monster, breads, gold, keys, and medals in Curse Pots no longer become cursed.
 - When a Rula Grass on the ground is placed in a Grass Pot, now it disappears.
 - Several minor bugs have also been fixed.

How to use:
1. Rip the ISO image file from the game CD.
2. Open Torneko3Mod.exe and select the ISO file as the input.
3. Choose the output DVD format from the following options:
   (1) FDVDB-ESR patched DVD ISO, playable on an unmodified PS2 slim console.
   (2) Standard DVD ISO.
4. Press the patch button and select the output file.

To play (1) on an actual PS2 (SCPH-70000~90000), set the console language to English,
burn the ISO file onto a high-quality DVD-R, and boot it on the PS2.
See more information on the FreeDVDBoot GitHub page:
https://github.com/CTurt/FreeDVDBoot