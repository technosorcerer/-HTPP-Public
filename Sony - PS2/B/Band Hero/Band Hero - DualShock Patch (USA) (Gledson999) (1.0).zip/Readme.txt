Band Hero - DualShock Patch
Patch made by Gledson999

This patch allows Band Hero to be compatible
with the DualShock controller just like it was in
the first games in the series, no longer needing
to have a Guitar Controller to play.

SITE: 
https://www.retro-jogos.com