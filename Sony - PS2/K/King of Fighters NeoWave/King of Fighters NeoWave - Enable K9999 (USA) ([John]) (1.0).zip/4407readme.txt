The King of Fighters NeoWave - Hack

Enable K9999 as a selectable character.
-To select K9999 put the cursor on Maxima and press Up. 

His colour palette is 'wrong', however apart from that, he seems to be fully intact and usable, with the correct sound effects and a proper Skill list in the pause menu.
Also notice how he uses Kyo's icon area and portraits on the character select and Order screen, and Kula's icon on his lifebar. 

==============
Special thanks
==============
To the original creator of this hack.
To the user Saintjavi from Emudesc for sending me the PAR codes.
==============================
John-Paul from www.Emudesc.com
==============================
   Twitter: @Juan_Pablo_81
==============================