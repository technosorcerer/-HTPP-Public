The king of Fighters -Nest- SLPS_256.61

-Enable Krizalid (1st form) as a selectable character in The King of Fighters 99'Evolution.

-Enable Krizalid (1st form) at Color Edit Mode.

The patch can be applied to the iso file through the program Delta Patcher which can be found in this site.

==============
Special thanks
==============
To the original creator of this hack.
To the user Saintjavi from Emudesc for sending me the PAR codes.
==============================
John-Paul from www.Emudesc.com
==============================
   Twitter: @Juan_Pablo_81
==============================
