============================================================================
From this great site:
http://www.arcadequartermaster.com/

The King of Fighters 99 - Krizalid
Moves set: http://www.arcadequartermaster.com/kof99_krizalid.html#krizalid

The King of Fighters 2000 - Zero 
Moves set:
http://www.arcadequartermaster.com/kof00_nests.html#zero

The King of Fighters 2001 - Zero & Igniz
Moves set:
http://www.arcadequartermaster.com/kof01_ceo.html#zero

============================================================================
Special thanks to the original creators of these hacks.
Unfortunately we do not know their names, but the credit is for all of them.
The hacks presented in this patch are partially based on their work.
============================================================================
John-Paul and Pitufodark from www.Emudesc.com
============================================================================