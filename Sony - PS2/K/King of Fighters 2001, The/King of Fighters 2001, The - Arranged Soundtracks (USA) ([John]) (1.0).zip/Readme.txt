The King of Fighters:2001 [SLPS_252.66] -Arranged Soundtrack-

This patch will replace the Arcade Soundtracks 
with the Arranged Soundtracks from the Dreamcast version.

The patch can be applied to the iso file through the program Delta Patcher which can be found in this site.

==============================
www.Emudesc.com|User:John-Paul
==============================
   Twitter: @Juan_Pablo_81
==============================

