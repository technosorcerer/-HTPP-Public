The King of Fighters:2001 [SLPS_252.66] -Unlockables-

This patch enables the boss characters at Party Mode + unlockables.

-All secret characters unlocked.
-All arcade stages unlocked.
-All secret characters unlocked at Party Mode.

The patch can be applied to the iso file through the program Delta Patcher which can be found in this site.

==============
Special thanks
==============
Special thanks to the original creators of these hacks.
Unfortunately I do not know their names, but the credit is for all of them.
The hacks presented in this patch are partially based on their work.
==============================
www.Emudesc.com|User:John-Paul
==============================
   Twitter: @Juan_Pablo_81
==============================

