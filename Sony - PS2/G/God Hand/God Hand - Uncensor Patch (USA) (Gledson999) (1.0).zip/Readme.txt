God Hand - Uncensorship Patch
Patch made by Gledson999

This patch allows you to enable the unused
DEAD PAN roulette technique from the final
version and removes the censorship used on
some textures and enables the Japanese food
Chiguahua Curry in the shop.

SITE: 
https://www.retro-jogos.com