Extra Options Hack made by Gledson999

This hack adds two new options to the controller
menu in Guitar Hero Aerosmith, these new options
activate the bot on controller 1 and 2,
essential for playing in co-op mode alone.

SITE: 
https://www.retro-jogos.com