Improvement on Fatal Fury Special:
Enable Ryo Sakazaki as a selectable character.

Improvement on Fatal Fury 3:
Enables Ryuji Yamazaki, Jin Chonshu, & Jin Chonrei as a selectable characters.

=========
Move List
=========
From: http://www.arcadequartermaster.com/

============
Ryo Sakazaki
============
http://www.arcadequartermaster.com/ffs_7.html#ryo

==========================================
Ryuji Yamazaki, Jin Chonshu, & Jin Chonrei
==========================================
http://www.arcadequartermaster.com/ff3_6.html#yamazaki

==============
Special thanks
==============
Special thanks to the original creators of these hacks.
Unfortunately I do not know their names, but the credit is for all of them.
The hacks presented in this patch are partially based on their work.
==============================
John-Paul from www.Emudesc.com
==============================




