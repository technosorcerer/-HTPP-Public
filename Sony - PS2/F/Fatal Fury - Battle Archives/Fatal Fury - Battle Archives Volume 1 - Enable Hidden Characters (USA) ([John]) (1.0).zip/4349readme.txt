Improvement in Fatal Fury Special:
Enable Ryo Sakazaki as a selectable character.

Improvement in Fatal Fury 3:
Enable Ryuji Yamazaki, Jin Chonshu and Jin Chonrei as selectable characters.

The patch can be applied to the iso file through the program Delta Patcher which can be found in this website.
=========
Move List
=========
From: http://www.arcadequartermaster.com/

============
Ryo Sakazaki
============
http://www.arcadequartermaster.com/ffs_7.html#ryo

==========================================
Ryuji Yamazaki, Jin Chonshu, & Jin Chonrei
==========================================
http://www.arcadequartermaster.com/ff3_6.html#yamazaki

==============
Special thanks
==============
Special thanks to the original creators of these hacks.
Unfortunately I do not know their names, but the credit is for all of them.
The hacks presented in this patch are partially based on their work.
==============================
John-Paul from www.Emudesc.com
==============================




