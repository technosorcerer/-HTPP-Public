Improvement on Real Bout:
-Easy Super Moves. (Optional Patch)
Using any character input the command:

-Down, Down + A to perform a S.POWER move.
-Down, Down + C to perform a P.POWER move.

Note: 
You can perform these movements infinitely;
regardless of the status of your POWER GAUGE.

Improvements on Real Bout Special:

-Enable [Nightmare] Geese Howard as a selectable character.

-Easy Super Moves. (Optional Patch)
Using any Character input the Command:

-Down, Down + A to perform a S.POWER move.
-Down, Down + C to perform a P.POWER move.
-Down, Down + D to perform the "DEADLY RAVE" move.
 (Wolfwang Krauser & Geese Howard only)

Note: 
You can perform these movements infinitely;
regardless of the status of your POWER GAUGE.

==============
Special thanks
==============
Special thanks to the original creators of these hacks.
Unfortunately I do not know their names, but the credit is for all of them.
The hacks presented in this patch are partially based on their work.
==============================
John-Paul from www.Emudesc.com
==============================


