---------------------------------------------
DBZ BT3 DLC MOD Classic to GT (v1.03)
---------------------------------------------


This is an addendum to 'DBZ BT3 DLC Classic to GT'.
https://www.romhacking.net/hacks/6337/


The changes are:
-The Team Battle in the Duel is able to use any repeatable character.
-Edited yellow text for extra characters' name in Ultimate Battle, Dragon World Tour, Duel, Ultimate Training, and Character Reference.
-Edited some of the characters' camera angle in the Character Reference to compensate the extra characters.
-Fixed Majin Buu's Character Introduction in the Character Reference (https://dragonball.fandom.com/wiki/Dragon_Ball_Z:_Budokai_Tenkaichi_3)
-Translate the Japanese BGM sprite text to English in Duel, Ultimate Training, and Options.
-Added different animation (FA) and effect (Kze) for most of the extra characters without affecting the original characters.
-Updates/Changes on certain character's 3D models.


A) Different patches of xdelta:
Unfortunately, unlike the older patches, only one patch is given in version 1.03 due to the 30mb limitation from RHDN.


B) Software needed:
1) Software that can extract '7z' extension file (e.g. Peazip, WinRAR, etc)
2) xdelta


C) Patching instructions:
1) First, apply the 'DBZ BT3 DLC Classic to GT.xdelta' patch over an unmodified 'SLUS_216.78.DragonBall Z - Budokai Tenkaichi 3 (USA) (En,Ja)' ISO file using 'xdelta UI' to create a new ISO.
2) Then, apply SLUS_216.78.DBZ_BT3_DLC_MOD_v103.xdelta patch over the newly created ISO file using 'xdelta UI' to create another new ISO.


D) Reversal xdelta:
There is no undo button for xdelta patch, unlike the ppf patches given if the file size is similar. Therefore, I created a reversal xdelta patch.
How to use it.
1) Use 'SLUS_216.78.DBZ_BT3_DLC_MOD_v103.xdelta' patch to create the addendum ISO.
2) Then, choose 'SLUS_216.78.DBZ_BT3_DLC_MOD_v103_Reversal.xdelta' patch over the addendum ISO to create another new ISO that is identical to the 'DBZ BT3 DLC Classic to GT'.
(Note: Keep the reverse xdelta patch as any future updates will be base on 'DBZ BT3 DLC Classic to GT'.)


E) DLC MOD.BIN configuration:
This is a feature created by KKTEAMTENKAICHI. Look for their website mentioned in the credits for further understanding. All I did was import this feature and other neccesary files into the current xdelta patch.
Currently, v3.8 can have dynamic outfit for fusions, repeatable character, extended roster and a secret function (not sure what it is as the author never mentioned it).
However, dynamic outfit for fusions seems to be imperfect as the selected character may not get the correct outfit (e.g. choosing Goku with color 3 will end up playing with color 1).
The patch only enable the repeatable character. The rest are disabled. Thus, avoiding the bug.
This feature also cause ghosting effect on certain characters when upscale it with PCSX2 emulator. For quick solution, change the Texture Offsets for X and Y to 300 for 2x Native, 350 for 3x Native, and so on.


F) DLC.AFS
Another feature created by KKTEAMTENKAICHI. Now you can create your own character starting from slot 165 to 252. This is located in a folder called EXTRA. I leave it blank for the time being. It's kind of buggy.


G) MOD.AFS:
Also one of the feature created by KKTEAMTENKAICHI which is also located in a folder called EXTRA. Now each character can have different FA (Animation), KZE (Effect), and Big Image.
However, only original Big Image is displayed during tournament.
Below is the link to their tutorial.
https://www.youtube.com/watch?v=TmtFeX42B_0 
example:
AXXX-Y.unk = Animation for that specific ID and slot
EXXX-Y.unk = Effect for that specific ID and slot
RXXX-Y.unk = Big Image for that specific ID and slot
Another important tutorial by Genius Corp needs to be mentioned in order to import the Animation, Super and Ultimate moves correctly from other character.
https://www.youtube.com/watch?v=ejZpvh25Vz8
What have been added in this MOD.AFS on 26/06/2024 (Note: Big Images not included due to 30mb limitation from RHDN):
-----    		--------
Slot     		Detail
-----    		--------

Angila
A024-4.unk	FA = Base animation from original Nail and Matheus Nerd's Angila+Zarbon and Piccolo Early entry animation+Matheus Nerd's Angila Super1+Gohan SSJ's Super2
E024-4.unk	KZE = Base effect from original Nail+Appule's charging Aura+Matheus Nerd's Angila Super1+Gohan SSJ's Super2

Yamcha DB
A026-4.unk	FA = Base animation from original Yamcha+General Blue's Floating Animation
E026-4.unk	KZE = Base effect from original Yamcha

Spice
A058-4.unk	FA = Base animation from original Zarbon+Supreme Kai's Support1, Support2 and Super2+Matheus Nerd's Spice Super1 and Ultimate
E058-4.unk	KZE = Base effect from original original Supreme Kai+Matheus Nerd's Spice Support1 to Support2, Super1 and Ultimate

King Kai
A059-4.unk	FA = Base animation from original Kibitokai+Falling animation from Great Ape Goku and Broly LSSJ+General Blue's Support1+Future Gohan SSJ's Support2+Vive's Goku Early Kaio-ken Super1 as Super2+Goku Early's Ultimate.
E059-4.unk	KZE = Base effect from original Kibitokai++General Blue's Support1+Goku Early's Support2 and Ultimate+Vive's Goku Early Kaio-ken Super1 as Super2

Ninja Murasaki DB
A060-3.unk	FA = Base animation from original Yajirobe+Tapion's throw+Pilaf Machine's Support2 to teasing
E060-3.unk	KZE = Base effect from original Yajirobe with edited Cman for Super2 and Ultimate

Korin DB
A060-4.unk	FA = Base animation from original Yajirobe+Babidi's exit animation+Trunks (Sword) throw+Tail animation
E060-4.unk	KZE = Base effect from original Yajirobe with edited Cman for Super2

Princess Oto/ Oceanus Shenron GT
A061-4.unk	FA = Base animation from Matheus Nerd's Princess Oto, change Support2 to Support1 and change Super2 to Super1+Pikkon's Entry+Tambourine's charging pose and air pose+Android 18's Support1 and change Super1 to Super2+Fasha's Support2
E061-4.unk	KZE = Base effect from Matheus Nerd's Princess Oto and change Support2 to Support1+Pikkon's Support2+Trunks (Sword) Super2

Minotia
E062-4.unk	KZE = Base effect from original Tapion with edited Cman for Ultimate

Bulla GT
A063-4.unk	FA = Base animation from original Pan+JSN's Bulla entry & exit animation and teasing
E063-4.unk	KZE = Base effect from original Pan with edited Cman Super2

South Supreme Kai
A065-4.unk	FA = Base animation from original Goku End SSJ3'+Majuub's entry & exit animation, Combo1 until End of Variety (224-604), Support1, Support2, Super1 and Ultimate+JSN's South Supreme Kai throw+Kibitokai's Super2
E065-4.unk	KZE = Base effect from original Majuub+Kibitokai's Super2

Goku's Doll DB
A068-4.unk	FA = Base animation from original Grandpa Gohan+Tail animation

Kid Krillin DB
A069-3.unk	FA = Combination of base animation from original Nam, Krillin and Broly LSSJ+Videl's Ultimate
E069-3.unk	KZE = Base effect from original Nam+Videl's Ultimate

Kid Vegeta
A071-3.unk	FA = Base animation from original Vegeta (second form) SSJ4's and Ultimate to Super1+Vegeta (second form) SSJ2's entry & exit animation+King Vegeta's Super2 and Ultimate+Tail animation
E071-3.unk	KZE = Base effect from original King Vegeta with edited Cman for Ultimate

Bardock SSJ
E073-4.unk	KZE = Base effect from original Bardock+GokuMidSSJ's charging aura

Golden Great Ape
E074-4.unk	KZE = Base effect from original Great Ape Bardock+Great Ape Baby's charging aura+Slug (Giant) Support1

Rage Shenron GT
A081-4.unk	FA = Base animation from original Great Ape Vegeta+Slug (Giant) charging pose+Great Ape Kid Goku's shoot Ki and charge shoot Ki+Great Ape Nappa's Entry & Exit Animation, Support1, Support2, Super1, Super2 and Ultimate
E081-4.unk	KZE = Base effect from original Great Ape Nappa+Great Ape Vegeta's charging Aura+Hirudegarn's Support1 and Support2 (Not enough space for Howl)+Matheus Nerd's Rage Shenron Super2+Goku GT SSJ4's Super1 change to Ultimate

Amond
E082-4.unk	KZE = Base effect from original Zarbon with edited Cman for Super2

Cacao
E083-4.unk	KZE = Base effect from original Zarbon Post-Tranformation with edited Cman for Super2

Wings
A084-4.unk	FA = Base animation from original Dodoria+Matheus Nerd's Wings air pose

Dore
A087-4.unk	FA = Base animation from Vive's Dore
E087-4.unk	KZE = Base effect from Vive's Dore

Neiz
A088-4.unk	FA = Base animation from Vive's Neiz
E088-4.unk	KZE = Base effect from Vive's Neiz

Medamatcha
A090-3.unk	FA = Base animation from original Guldo+Saibamen's Super1 and Ultimate
E090-3.unk	KZE = Base effect from original Guldo+Nail's Super1+Spopovich's Ultimate

Rasin/Lakasei
A090-4.unk	FA = Base animation from original Guldo+Saibamen's Super1 and Super1 to Ultimate
E090-4.unk	KZE = Base effect from original Guldo+Saibamen's Super1+Captain Ginyu's Super2+Jeice's Super1 to Ultimate

Kogu
A097-3.unk	FA = Base animation from original King Cold+Broly's charge pose+Dabura's shoot charge Ki

Kogu (Full Power)
A097-4.unk	FA = Base animation from original King Cold+Broly's charge pose+Dabura's shoot charge Ki

Mustard
A098-4.unk	FA = Base animation from Matheus Nerd's Mustard
E098-4.unk	KZE = Base effect from Matheus Nerd's Mustard+Appule's charging Aura and Support2+Jeice's Super2 to Super1

General Rilldo GT
A100-4.unk	FA = Base animation from original Android #16
E100-4.unk	KZE = Base effect from original Android #16

Android #17 (Hell) GT
E101-3.unk	KZE = Base effect from original Android #17 with edited Cman for Ultimate

Android #17 (Earth) GT
E101-4.unk	KZE = Base effect from original Android #17 with edited Cman for Ultimate

Ebifurya
A103-4.unk	FA = Base animation from Matheus Nerd's Ebifurya and Super1 to Ultimate+Frieza 2nd Form's Super1+Android #19's Super2
E103-4.unk	KZE = Base effect from original Android #19+Matheus Nerd's Ebifurya Super1 to Ultimate

Hoi
A109-3.unk	FA = Base animation from original Cell Jr.+Appule's Taunt and Super2+Frieza's soldier super2 to Ultimate
E109-3.unk	KZE = Base effect from original Cell Jr.+Frieza's soldier Super1+Baby Vegeta's Ultimate

Moah
A109-4.unk	FA = Base animation from original Cell Jr.+Saibamen's Taunt and Super2+Appule's Ultimate
E109-4.unk	KZE = Base effect from original Cell Jr.+Frieza's soldier Super1+Appule's Ultimate

Dr. Lychee
A110-4.unk	FA = Base animation from original Babidi+Goten SSJ's Support2 to taunt+Guldo's Super2 to Ultimate
E110-4.unk	KZE = Base effect from original Babidi with edited Cman for Super1 and Super2

Nicky
A111-3.unk	FA = Base animation from original Demon King Dabura+Bojack Full Power's Support2 to Support1+Matheus Nerd's Nicky Super1+Vive's Dore Super1 to Super2+BT2 Dabura's Ultimate
E111-3.unk	KZE = Base effect from original Demon King Dabura+Appule's Support1+Supreme Kai's charging Aura, shooting Ki and Super1+Majuub's Super1 to Super2+BT2 Dabura's Ultimate and Cman

Ledgic GT
A111-4.unk	FA = Base animation from original Demon King Dabura+Slug's Support1+Vive's Dore Super1 to Super2
E111-4.unk	KZE = Base effect from original Demon King Dabura+Jeice's Support1+Turles's Super2

Grand Supreme Kai
A112-4.unk	FA = Base animation from original Majin Buu+JSN's Grand Supreme Kai Ultimate to Super2
E112-4.unk	KZE = Base effect from original Majin Buu+JSN's Grand Supreme Kai charging Aura, shooting Ki, charge shooting Ki and Ultimate to Super2+Piccolo Early's Support1

Salt
A118-3.unk	FA = Base animation from original Garlic Jr.+Chiaotzu's shooting Ki+Saibamen's Super1
E118-3.unk	KZE = Base effect from original Garlic Jr.+Zangya's Support1+Saibamen's Super1

Bujin
A118-4.unk	FA = Base animation from Matheus Nerd's Bujin and Super1 to Ultimate+Garlic Jr.'s Support2+Jeice's Super1
E118-4.unk	KZE = Base effect from original Supreme Kai+Matheus Nerd's Bujin Support1, Super1 to Ultimate+Garlic Jr.'s Support2+Broly's Super1+Guldo's Ultimate to Super2

Sansho
A119-3.unk	FA = Base animation from original Super Garlic Jr+Bojack Full Power's Support2 to Support1+Matheus Nerd's Sansho Ultimate
E119-3.unk	KZE = Base effect from original Super Garlic Jr.+Dodoria's Support1 and Support2+Jeice's Super1+Matheus Nerd's Sansho Ultimate

Vinegar
A119-4.unk	FA = Base animation from original Super Garlic Jr.+Matheus Nerd's Vinegar Super1 to Ultimate
E119-4.unk	KZE = Base effect from original Super Garlic Jr.+Jeice's Super1+Matheus Nerd's Vinegar Support1 and Super1 to Ultimate

Yakon
A120-3.unk	FA = Base animation from original Dr. Wheelo
E120-3.unk	KZE = Base effect from original Dr. Wheelo

Giant Cooler Core
A120-4.unk	FA = Base animation from original Dr. Wheelo
E120-4.unk	KZE = Base effect from original Dr. Wheelo

Kishime
A125-4.unk	FA = Base animation from original Salza+Matheus Nerd's Kishime Entry&Exit animation and Ultimate to Super2
E125-4.unk	KZE = Base effect from original Salza+Matheus Nerd's Kishime Super1 to Super2+Vegito SSJ's Ultimate

Android 15
A129-4.unk	FA = Base animation from original Android 13+Broly's charging+Broly LSSJ fall to ground+Great Ape Kid Goku supine and prone position
E129-4.unk	KZE = Base effect from original Android 13+Lukesca's Android 14 Shooting Ki and Charge Shooting Ki+Bardock's Super1+Android 17's Super1 to Ultimate

Android 14
A130-4.unk	FA = Base animation from original Android 13 Fusion+Lukesca's Android 14 ground stance and air stance
E130-4.unk	KZE = Base effect from original Android 13 Fusion+Android 13's charging Aura+Lukesca's Android 14 Shooting Ki and Charge Shooting Ki+Pilaf Machine Fusion support1+Android 17's Super1+Bardock's Ultimate

Bido
A135-4.unk	FA = Base animation from original Bojack+Super Garlic Jr.'s Support1
E135-4.unk	KZE = Base effect from original Bojack+Zangya's Support1

Hatchiyack
A136-4.unk	FA = Base animation from Apioman's Hatchiyack
E136-4.unk	KZE = Base effect from Apioman's Hatchiyack+Broly LSSJ's Support

Luud GT
A137-3.unk	FA = Base animation from Matheus Nerd's Luud and change Super1 to Ultimate+Slug (Giant) Shoot Ki, Shoot Ki Charge, Support1, Support2 and Super1
E137-3.unk	KZE = Base effect from original Janemba+Great Ape Bardock's Support1 and Support2+Slug (Giant) Super1+Matheus Nerd's Luud Super2 and change Super1 to Ultimate

Luud (Full Power) GT
A137-4.unk	FA = Base animation from Matheus Nerd's Luud and change Super1 to Ultimate+Slug (Giant) Shoot Ki, Shoot Ki Charge, Support1, Support2 and Super1
E137-4.unk	KZE = Base effect from original Janemba+Great Ape Bardock's Support1 and Support2+Slug (Giant) Super1+Matheus Nerd's Luud Super2 and change Super1 to Ultimate

North Supreme Kai 
A138-3.unk	FA = Base animation from original Tapion+Uub's Support1+Trunks (Sword) Support2
E138-3.unk	KZE = Base effect from original Tapion with edited Cman for Ultimate+Uub's Support1+Trunks (Sword) Support2

Haze Shenron GT
A138-4.unk	FA = Base animation from original Cooler+Matheus Nerd's Haze Shenron entry animation+Great Ape Kid Goku's suppine+Super Janemba's Support1, Super1, Super2 and Ultimate
E138-4.unk	KZE = Base effect from original Super Janemba+Cooler's Support2

Naturon Shenron GT
A139-4.unk	FA = Base animation from Matheus Nerd's Naturon Shenron+Hirudegarn's Super1+Dr. Wheelo's Super2
E139-4.unk	KZE = Base effect from Matheus Nerd's Naturon Shenron+Great Ape Nappa's Shoot Ki and shoot Ki charge+Janemba's Support1 and Support2+Hirudegarn's Super1+Dr. Wheelo's Super2+Gohan's Ultimate

Eis Shenron GT
A145-4.unk	FA = Base animation from Vive's Eis Shenron
E145-4.unk	KZE = Base effect from Vive's Eis Shenron

Dr. Kochin
A148-4.unk	FA = Base animation from original General Tao+Master Roshi's Entry Animation+Devilman's Super1+Matheus Nerd's Bulma Classic Ultimate
E148-4.unk	KZE = Base effect from original General Tao

Bulma DB
A150-3.unk	FA = Base animation from original Android 18's and change Ultimate pose to teasing+Videl's full charging+Chi-Chi's throw+General Blue's float, Support1, Super1 and Ultimate with Android 18's teasing pose+Hercule's Support2 and Super2.
E150-3.unk	KZE = Base effect from original General Blue with edited Cman for Ultimate+Hercule's Super2.

Launch DB
A150-4.unk	FA = Base animation from original Android 18+Zangya's entry animation, full charging and Ultimate 1st pose+Videl's charging, throw and Support2+General Blue's float, Support1, Super1 and Ultimate+Trunks's Super2.
E150-4.unk	KZE = Base effect from original General Blue with edited Cman for Ultimate+Trunks's Super2.

Lucifer DB
A151-3.unk	FA = Base animation from original Devilman+General Blue's Floating Animation

Kami DB
A151-4.unk	FA = Base animation from original Devilman+Dragon Wolf BT3's Kami Super1 to Ultimate
E151-4.unk	KZE = Base effect from original Devilman+Dragon Wolf BT3's Kami Super1 to Ultimate

Pirate Robot DB
A152-3.unk	FA = Base animation from original Super Janemba+Cooler Final Form's charging Ki and throw+Frieza 2nd Form's Super1 and Super1 to Ultimate with Ultimate 1st Pose+Meta-Cooler Super2.
E152-3.unk	KZE = Base effect from original Super Janemba+Pilaf Machine's charging Ki, Support1, Support2 and Super2+General Blue's Super1+Dabura's Super2 to Ultimate.

Gill GT
A152-4.unk	FA = Base animation from original Cell Jr.+Matheus Nerd's Gill throw, Support1, Support2, Super1+Kid Trunks's Ultimate.
E152-4.unk	KZE = Base effect from original Cell Jr.+Support1 and Support2+Matheus Nerd's Gill Super1+Pilaf Machine Fusion's Ultimate with edited texture.

Cyclopian
A153-3.unk	FA = Base animation from original Super Garlic Jr.+Broly LSSJ's throw+Matheus Nerd's Sansho Ultimate to Super1+Super 17's Super2 and Super1 to Ultimate.
E153-3.unk	KZE = Base effect from original Super Garlic Jr.+Pilaf Machine Fusion's charging Ki, Support1, Support2, Super1, Super2 and Ultimate with edited texture.

Sigma GT
A153-4.unk	FA = Base animation from original Android 13 Fusion+Matheus Nerd's Sansho Ultimate to Super1+Pilaf Machine Fusion's Super2+JSN's Black Machine Ultimate.
E153-4.unk	KZE = Base effect from original Android 13 Fusion+Pilaf Machine Fusion's Support1, Support2, Super1 and Super2 and Ultimate with edited texture.

Spopovich (Younger)
A158-3.unk	FA = Base animation from original Spopovich+General Blue's Floating Animation

Commander Zeeun
E158-4.unk	KZE = Base effect from original Spopovich with edited Cman for Ultimate+Dodoria's charging Aura

Goten GT
A159-4.unk	FA = Base animation from original Future Gohan+Gohan's Super1 and Ultimate

Goten SSJ GT
A160-4.unk	FA = Base animation from original Future Gohan Super Saiyan+Gohan SSJ's Support1 and Super2+Ultimate Gohan's Super1 and Ultimate.
E160-4.unk	KZE = Base effect from original Future Gohan Super Saiyan+Gohan SSJ's Support1 and Super2+Ultimate Gohan's Super1 and Ultimate.


H) The English Translated Japanese BGM Text:
Finally, thanks to 'TeamBT4', I was able to extract the translated English BGM texture text from their 'DBZ Tenkaichi Collection' which was published on 07/01/2023.
The BGM texture text can be found in the PZS3US1.AFS's unk files.
Duel 		= file no. 448 = p.unk
Options 		= file no. 453 = p(453).unk
Ultimate Training 	= file no. 461 = Ultimate(461).unk
If you want to look into it, you'll need three sofware.
1) AFSExplorer v3.7 to export those three unk files.
2) KkTeamUnkArchivesExplorer v4.0 to export and decompress the [Block 2] inside the unk file. [Block 1] for 'p(453).unk'.
3) KkTeamQrsExplorer v1.0 to view the texture [Block 2] that has been decrompressed. [Block 1] for 'p(453).unk'.
The link below will explain how to replace or customize soundtracks which are located inside PZS3US2.AFS.
https://andysitblog.blogspot.com/2013/12/ps2-replacing-background-music-of.html


I) Restore/Edit Character's Name:
These can also be found in the PZS3US1.AFS's unk files.
Duel 			= file no. 448 = p.unk
Dragon World Tour		= file no. 450 = WorldTou.unk	
Ultimate Battle 		= file no. 451 = Ultimate.unk
Ultimate Training 		= file no. 461 = Ultimate(461).unk
Character Reference	= file no. 463 = Collecti.unk
They can be edited using 'KkTeamPEditor'. First, you must open it with the 'p.unk'. Then, change the character's name to your liking under the 'Names and small images'.
These changes can be carried over to 'WorldTou.unk', 'Ultimate.unk', and 'Ultimate(461).unk' under the 'Custom ISO Maker'.
On the other hand, 'Collecti.unk' cannot be carried over but can be opened straight away using 'KkTeamPEditor'.


J) Character Reference Camera:
'res(3).unk' which is inside 'PZS3US1.AFS' has a feature to adjust the Character Reference Camera (Height and Distance).
Again, this can only be done using 'KkTeamPEditor'. You must first open it with the 'p.unk'. Next, click on 'File' and choose 'Open res(3)' to load the 'res(3).unk'. Only then, you can edit it on the 'Other stuff'.
The Character Reference Camera (Height and Distance) of one of the two xdelta patches has been adjusted to compensate for the differences between the characters in Color 3 and 4. They are:
Character:			Original Camera:			Edited Camera:
Kibitokai				Height: -9.500, Distance 24.750	Height: -10.500, Distance 25.750
Uub				Height: -8.510, Distance 23.288	Height: -9.510, Distance 29.288
Majuub				Height: -8.510, Distance 23.288	Height: -9.510, Distance 29.288
Zarbon				Height: -10.100, Distance 25.800	Height: -11.100, Distance 30.800
Zarbon Post-Transformation		Height: -10.100, Distance 25.800	Height: -11.100, Distance 30.800
Appule				Height: -8.473, Distance 22.156	Height: -10.473, Distance 27.156
Frieza Soldier			Height: -8.117, Distance 22.500	Height: -8.117, Distance 24.500
Android #19			Height: -8.550, Distance 24.350	Height: -10.550, Distance 28.350
Cell Perfect Form			Height: -10.800, Distance 27.150	Height: -11.800, Distance 33.150
Babidi				Height: -6.600, Distance 18.600	Height: -9.600, Distance 21.600
Pilaf Machine			Height: -8.185, Distance 24.000	Height: -13.185, Distance 33.000


K) Changes/Updates on Character 3D Models:
26/06/2024 (v1.03) [Note: Most of the Entry&Exit Special Quotes which is under "021_voice_speaker" for Extra Characters were totally removed.]
DD/MM/YYYY
Goku (GT) SSJ Costume 4 (Empty) - ƒ‚E1506).unk				Slot_1+SSJ_gold_tail+Can_Transform				(Added Golden Great Ape transformation from Vive) Note: Incomplete transformation scene and share the same Golden Great Ape with Bardock SSJ
Goku (GT) SSJ Costume 4 damaged (Empty) - ƒ‚E1510).unk			Slot_1+SSJ_gold_tail+Can_Transform+Damage			(Added Golden Great Ape transformation from Vive) Note: Incomplete transformation scene and share the same Golden Great Ape with Bardock SSJ
Goku (GT) SSJ3 Costume 4 (Empty) - ƒ‚E1516).unk				Slot_1+SSJ3_gold_tail+Can_Transform			(Added Golden Great Ape transformation from Vive) Note: Incomplete transformation scene and share the same Golden Great Ape with Bardock SSJ
Goku (GT) SSJ3 Costume 4 damaged (Empty) - ƒ‚E1520).unk			Slot_1+SSJ3_gold_tail+Can_Transform+Damage		(Added Golden Great Ape transformation from Vive) Note: Incomplete transformation scene and share the same Golden Great Ape with Bardock SSJ
Teen Gohan SSJ Costume 4 (Empty) - ƒ‚ƒfE1576).unk				Movie_Broly+SSJ+Can_Transform				(Redo the texture coloring from Vive)
Teen Gohan SSJ Costume 4 (Empty) - ƒ‚ƒfE1580).unk				Movie_Broly+SSJ+Can_Transform+Damage			(Redo the texture coloring from Vive)
Teen Gohan SSJ2 Costume 4 (Empty) - ƒ‚ƒfE1586).unk				Movie_Broly+SSJ2+Can_normal				(Redo the texture coloring from Vive)
Teen Gohan SSJ2 Costume 4 (Empty) - ƒ‚ƒfE1590).unk				Movie_Broly+SSJ2+Can_normal+Damage			(Redo the texture coloring from Vive)
Nail Costume 4 (Empty) - unknow_01666.unk					Angila_no_damage_no_LIPS					(Edited moveset and Etc+Adjust Devilmite Beam Damage Multiplier)
Nail Costume 4 damaged (Empty) - unknow_01670.unk				Angila_no_damage_no_LIPS					(Edited moveset and Etc+Adjust Devilmite Beam Damage Multiplier)
Yamcha Costume 4 (Empty) - ƒ‚ƒfE1686).unk					Yamcha_21st_Tenkachi_Budokai_no_damage_no_LIPS		(No Aura, Cannot Fly and Cannot Shoot Ki)
Yamcha Costume 4 damaged (Empty) - ƒ‚ƒfE1690).unk				Yamcha_21st_Tenkachi_Budokai_no_damage_no_LIPS		(No Aura, Cannot Fly and Cannot Shoot Ki)
Tien Costume 4 (Empty) - unknow_01696.unk					Tien_DragonBall						(No Aura)
Tien Costume 4 damaged (Empty) - unknow_01700.unk				Tien_DragonBall+Damage					(No Aura)
Chiaotzu Costume 3 (Empty) - pa(1705).unk					Chiaotzu_DragonBall+Hat					(No Aura)
Chiaotzu Costume 4 (Empty) - pa(1706).unk					Dende_no_damage					(Adjust Devilmite Beam Damage Multiplier)
Chiaotzu Costume 3 damaged (Empty) - pa(1709).unk				Chiaotzu_DragonBall					(No Aura)
Chiaotzu Costume 4 damaged (Empty) - pa(1710).unk				Dende_no_damage					(Adjust Devilmite Beam Damage Multiplier)
Vegeta (End) Majin Costume 4 (Empty) - E1796).unk				GT+SSJ2_Majin_no_M_no_jacket+Can_normal			(Adjust Devilmite Beam Damage Multiplier)
Vegeta (End) Majin Costume 4 damaged (Empty) - E1800).unk			GT+SSJ2_Majin_no_M_no_jacket+Can_normal+Damage		(Adjust Devilmite Beam Damage Multiplier)
Trunks (Sword) Costume 3 (Empty) - E1815).unk					Long_hair+Sleeveless_jacket+Sword+Can_SSJ+Can_no_sword	(Now transform to No_Sword cost 1 Ki bar)
Trunks (Sword) Costume 3 damaged (Empty) - E1819).unk			Long_hair+No_jacket+Sword+Can_SSJ+Can_no_sword+Damage	(Now transform to No_Sword cost 1 Ki bar)
Trunks (Sword) SSJ Costume 3 (Empty) - E1825).unk				Long_hair+Sleeveless_jacket+Sword+SSJ+Can_normal		(Slightly reduce the size of the hair)
Trunks (Sword) SSJ Costume 4 (Empty) - E1826).unk				GT+Sword+SSJ+Can_normal				(Slightly change the hair)
Trunks (Sword) SSJ Costume 3 damaged (Empty) - E1829).unk			Long_hair+No_jacket+Sword+SSJ+Can_normal+Damage		(Slightly reduce the size of the hair)
Trunks (Sword) SSJ Costume 4 damaged (Empty) - E1830).unk			GT+Sword+SSJ+Can_normal+Damage			(Slightly change the hair)
Trunks Costume 3 (Empty) - E1835).unk					Long_hair+No_jacket+Can_Transform+Can_Sword		(Now transform to Sword cost 1 Ki bar)
Trunks Costume 3 damaged (Empty) - E1839).unk				Long_hair+No_jacket+Can_Transform+Can_Sword+Damage	(Now transform to Sword cost 1 Ki bar)
Goten Costume 4 (Empty) - ƒ‚ƒfE1886).unk					Kimono_smaller+Can_SSJ+Can_Fusion			(Rescale Maredzer's model Y vertices on waist, hands and legs by 1.4)
Goten Costume 4 damaged (Empty) - ƒ‚ƒfE1890).unk				Kimono_smaller+Can_SSJ+Can_Fusion+Damage		(Rescale Maredzer's model Y vertices on waist, hands and legs by 1.4)
Goten SSJ Costume 4 (Empty) - ƒ‚ƒfE1896).unk					Kimono_smaller+SSJ+Can_normal+Can_Fusion			(Rescale Maredzer's model Y vertices on waist, hands and legs by 1.4)
Goten SSJ Costume 4 damaged (Empty) - ƒ‚ƒfE1900).unk				Kimono_smaller+SSJ+Can_normal+Can_Fusion+Damage	(Rescale Maredzer's model Y vertices on waist, hands and legs by 1.4)
Vegito Costume 3 (Empty) - ƒ‚E1935).unk					Armor+Can_SSJ (Bug: Incorrect LIPS animation)			(Fix the LIPS animation)
Vegito Costume 3 damaged (Empty) - ƒ‚E1939).unk				Armor+Can_SSJ+Damage (Bug: Incorrect LIPS animation)		(Fix the LIPS animation)
Super Vegito Costume 3 (Empty) - ƒ‚E1945).unk					Armor+SSJ+Can_normal (Bug: Incorrect LIPS animation)		(Fix the LIPS animation)
Super Vegito Costume 3 damaged (Empty) - ƒ‚E1949).unk				Armor+SSJ+Can_normal+Damage (Bug: Incorrect LIPS animation)	(Fix the LIPS animation)
Great Saiyaman 2 Costume 3 - ƒOƒŒ[ƒgƒTƒCƒ„(1995).unk			Slot_1_no_helmet						(No Solar Flare immunity)
Great Saiyaman 2 Costume 3 damaged - ƒOƒŒ[ƒgƒTƒCƒ„(1999).unk		Slot_1_no_helmet+Damage					(No Solar Flare immunity)
Supreme Kai Costume 3 (Empty) - unknow_02005.unk				Old_Kai_no_damage_cannot_transform			(Adjust Devilmite Beam Damage Multiplier)
Supreme Kai Costume 4 (Empty) - unknow_02006.unk				Spice_no_damage_cannot_transform				(Edited character reference pose and moveset+Adjust Devilmite Beam Damage Multiplier)
Supreme Kai Costume 3 damaged (Empty) - unknow_02009.unk			Old_Kai_no_damage_cannot_transform			(Adjust Devilmite Beam Damage Multiplier)
Supreme Kai Costume 4 damaged (Empty) - unknow_02010.unk			Spice_no_damage_cannot_transform				(Edited character reference pose and moveset+Adjust Devilmite Beam Damage Multiplier)
Kibitokai Costume 3 (Empty) - ƒ‚ƒfE2015).unk					Kibito							Note: Remove all Special Quotes
Kibitokai Costume 4 (Empty) - ƒ‚ƒfE2016).unk					King_Kai_no_damage					(Have Solar Flare immunity+Edited character moveset) Note: No longer has "Present Bomb" height issue
Kibitokai Costume 3 damaged (Empty) - ƒ‚ƒfE2019).unk				Kibito+Damage						Note: Remove all Special Quotes
Kibitokai Costume 4 damaged (Empty) - ƒ‚ƒfE2020).unk				King_Kai_no_damage					(Have Solar Flare immunity+Edited character moveset) Note: No longer has "Present Bomb" height issue
Yajirobe Costume 3 (Empty) - ƒ‚E2025).unk					Ninja_Murasaki_no_damage					(Adjust Devilmite Beam Damage Multiplier)
Yajirobe Costume 4 (Empty) - ƒ‚E2026).unk					Korin_no_damage						(Change to another version from Matheus Nerd+Adjust Devilmite Beam Damage Multiplier+Tail animation+Zsearch01010101)
Yajirobe Costume 3 damaged (Empty) - ƒ‚E2029).unk				Ninja_Murasaki_no_damage					(Adjust Devilmite Beam Damage Multiplier)
Yajirobe Costume 4 damaged (Empty) - ƒ‚E2030).unk				Korin_no_damage						(Change to another version from Matheus Nerd+Adjust Devilmite Beam Damage Multiplier+Tail animation+Zsearch01010101)
Pikkon Costume 4 (Empty) - E2036).unk					Princess_Otto_no_LIPS					(Edited character reference pose, moveset and common param+Adjust Devilmite Beam Damage Multiplier) Note: No longer has "Present Bomb" height issue
Pikkon Costume 4 damaged (Empty) - E2040).unk				Oceanus_Shenron_no_LIPS					(Edited character reference pose, moveset and common param+Adjust Devilmite Beam Damage Multiplier)
Tapion Costume 3 (Empty) - ƒ‚ƒfE2045).unk					Konatsian_Wizard_no_damage				Note: Remove all Special Quotes
Tapion Costume 4 (Empty) - ƒ‚ƒfE2046).unk					Minotia_no_damage					Note: Remove all Special Quotes
Tapion Costume 3 damaged (Empty) - ƒ‚ƒfE2049).unk				Konatsian_Wizard_no_damage				Note: Remove all Special Quotes
Tapion Costume 4 damaged (Empty) - ƒ‚ƒfE2050).unk				Minotia_no_damage					Note: Remove all Special Quotes
Pan Costume 3 (Empty) - pa(2055).unk					End_of_Z	_no_damage					(Fix body texture) Note: No longer has "Present Bomb" height issue
Pan Costume 4 (Empty) - pa(2056).unk					Bulla_no_damage_no_LIPS					(Change to another version from JSN Mods=Updated and with LIPS)
Pan Costume 3 damaged (Empty) - pa(2059).unk				End_of_Z_no_damage					(Fix body texture) Note: No longer has "Present Bomb" height issue
Pan Costume 4 damaged (Empty) - pa(2060).unk				Bulla_no_damage_no_LIPS					(Change to another version from JSN Mods=Updated and with LIPS but still no damage outfit)
Uub Costume 3 (Empty) - ƒ‚ƒfE2065).unk					Uub_costume_1						(Replace Kid_Uub with Uub with edited transformation text) 
Uub Costume 4 (Empty) - ƒ‚ƒfE2066).unk					End_of_Z_no_damage_no_LIPS_cannot_transform		(Replace Olibu with Kid_Uub can't remember the source) Note: No longer has "Present Bomb" height issue
Uub Costume 3 damaged (Empty) - ƒ‚ƒfE2069).unk				Uub_costume_1_damaged					(Replace Kid_Uub with Uub with edited transformation text) 
Uub Costume 4 damaged (Empty) - ƒ‚ƒfE2070).unk				End_of_Z_no_damage_no_LIPS_cannot_transform		(Replace Olibu with Kid_Uub can't remember the source) Note: No longer has "Present Bomb" height issue
Majuub Costume 4 (Empty) - ƒ‚ƒfE2076).unk					South_Supreme_Kai_no_damage				(Edited character reference pose and moveset+Adjust Devilmite Beam Damage Multiplier)
Majuub Costume 4 damaged (Empty) - ƒ‚ƒfE2080).unk				South_Supreme_Kai_no_damage				(Edited character reference pose and moveset+Adjust Devilmite Beam Damage Multiplier)
Master Roshi Costume 4 (Empty) - ƒ‚ƒfE2086).unk				Slot_1+Can_Full_Power+Shell				(Have Solar Flare immunity)
Grandpa Gohan Costume 4 (Empty) - unknow_02106.unk				Goku's_doll						(Adjust Devilmite Beam Damage Multiplier+Tail animation)
Grandpa Gohan Costume 4 damaged (Empty) - unknow_02110.unk			Goku's_doll+Damage					(Adjust Devilmite Beam Damage Multiplier+Tail animation)
Nam Costume 3 (Empty) - pa(2115).unk					Kid_Krillin_no_damage					(Edited character reference pose, moveset and mini camera+Adjust Devilmite Beam Damage Multiplier) Note: No longer has "Present Bomb" height issue
Nam Costume 4 (Empty) - pa(2116).unk					Mr_Popo							Note: Remove all Special Quotes
Nam Costume 3 damaged (Empty) - pa(2119).unk				Kid_Krillin_no_damage					(Edited character reference pose, moveset and mini camera+Adjust Devilmite Beam Damage Multiplier) Note: No longer has "Present Bomb" height issue
Nam Costume 4 damaged (Empty) - pa(2120).unk				Mr_Popo+Damage						Note: Remove all Special Quotes
Android #8 Costume 3 (Empty) - ƒ‚E2125).unk					OxKing_no_LIPS_no_damage				(Not Android and Shorten Super1+Adjust damage taken and etc+Adjust Devilmite Beam Damage Multiplier+Zsearch07070707)
Android #8 Costume 4 (Empty) - ƒ‚E2126).unk					Bora_no_damage_no_LIPS					(Not Android and Shorten Super1+Adjust damage taken and etc+Adjust Devilmite Beam Damage Multiplier+Zsearch07070707)
Android #8 Costume 3 damaged (Empty) - ƒ‚E2129).unk				OxKing_no_LIPS_no_damage				(Not Android and Shorten Super1+Adjust damage taken and etc+Adjust Devilmite Beam Damage Multiplier+Zsearch07070707)
Android #8 Costume 4 damaged (Empty) - ƒ‚E2130).unk				Bora_no_damage_no_LIPS					(Not Android and Shorten Super1+Adjust damage taken and etc+Adjust Devilmite Beam Damage Multiplier+Zsearch07070707)
King Vegeta Costume 3 (Empty) - E2135).unk					Kid_Vegeta_straight_tail+Can_Ape				(Refine the model+Edited throw damaged and camera for Entry&Exit and Super1+character reference and tail animation) Note: Still have unresolved face animation
King Vegeta Costume 4 (Empty) - E2136).unk					Paragus+Can_Ape						(Copy King Vegeta's moveset and Etc)
King Vegeta Costume 3 damaged (Empty) - E2139).unk				Kid_Vegeta_straight_tail+Can_Ape+Damage			(Refine the model+Edited throw damaged and camera for Entry&Exit and Super1+character reference and tail animation) Note: Still have unresolved face animation
King Vegeta Costume 4 damaged (Empty) - E2140).unk				Paragus+Can_Ape+Damage					(Copy King Vegeta's moveset and Etc)
Great Ape King Vegeta Costume 3 (Empty) - E2145).unk				Slot_2_edited						(Edited character model by replacing the head to Great Ape Vegeta costume 01 and Great Ape Fasha's arms)
Great Ape King Vegeta Costume 4 (Empty) - E2146).unk				Slot_2_Great_Ape_Nappa_edited				(Edited textures and model by replacing hands with the combination of Great Ape Fasha and Great Ape King Vegeta)
Great Ape King Vegeta Costume 3 damaged (Empty) - E2149).unk			Slot_2_edited+Damage					(Edited character model by replacing the head to Great Ape Vegeta costume 01 and Great Ape Fasha's arms)
Great Ape King Vegeta Costume 4 damaged (Empty) - E2150).unk			Slot_2_Great_Ape_Nappa_edited+Damage			(Edited textures and model by replacing hands with the combination of Great Ape Fasha and Great Ape King Vegeta)
Bardock Costume 4 (Empty) - E2156).unk					Scoutless_SSJ+Can_Ape					(Edited eyes texture+Zsearch00000000+Edited transformation text)
Bardock Costume 4 damaged (Empty) - E2160).unk				Scoutless_SSJ+Can_Ape+Damage				(Edited eyes texture+Zsearch00000000+Edited transformation text)
Great Ape Bardock Costume 4 (Empty) - E2166).unk				Slot_1							(Change to GoldenGreatApe from Vive's Revolution Sparking)
Great Ape Bardock Costume 4 damaged (Empty) - E2170).unk			Slot_1+Damage						(Change to GoldenGreatApeDamage from Vive's Revolution Sparking)
Fasha Costume 4 (Empty) - ƒ‚ƒfE2176).unk					Gine+Can_transform_to_Great_Ape_Goku			(Zsearch00000000)
Fasha Costume 4 damaged (Empty) - ƒ‚ƒfE2180).unk				Gine+Can_transform_to_Great_Ape_Goku+Damage		(Zsearch00000000)
Great Ape Fasha Costume 4 (Empty) - ƒ‚ƒfE2186).unk				Misokatsun_no_damage					(Adjust damage taken+Adjust Devilmite Beam Damage Multiplier)
Great Ape Fasha Costume 4 damaged (Empty) - ƒ‚ƒfE2190).unk			Misokatsun_no_damage					(Adjust damage taken+Adjust Devilmite Beam Damage Multiplier)
Raditz Costume 4 (Empty) - E2196).unk					Tora_no_LIPS+Can_Ape					(Edited textures and fix the blinking face+Add Trunks's ponytail)
Raditz Costume 4 damaged (Empty) - E2200).unk				Tora_no_LIPS+Can_Ape+Damage				(Edited textures and fix the blinking face+Add Trunks's ponytail)
Great Ape Raditz Costume 4 (Empty) - E2206).unk				Great_Ape_Turles_Slot_2					(Edited textures and model by replacing hands with Great Ape Raditz+Add resize hair from Great Ape Raditz)
Great Ape Raditz Costume 4 damaged (Empty) - E2210).unk			Great_Ape_Turles_Slot_2+Damage				(Edited textures and model by replacing hands with Great Ape Raditz+Add resize hair from Great Ape Raditz)
Saibamen Costume 4 (Empty) - ƒ‚ƒfE2216).unk					Bio-Men							Note: Remove all Special Quotes
Saibamen Costume 4 damaged (Empty) - ƒ‚ƒfE2220).unk				Bio-Men+Damage						Note: Remove all Special Quotes
Nappa Costume 4 (Empty) - ƒ‚ƒfE2226).unk					Borgos+Can_transform_to_Great_Ape_Goku			(Zsearch02020202) Note: No longer has "Present Bomb" height issue
Nappa Costume 4 damaged (Empty) - ƒ‚ƒfE2230).unk				Borgos+Can_transform_to_Great_Ape_Goku+Damage		Note: No longer has "Present Bomb" height issue
Great Ape Nappa Costume 4 (Empty) - ƒ‚ƒfE2236).unk				Rage_Shenron_60%_no_damage_no_LIPS			(Further shorten the tail by 30%+Edited character reference pose+Adjust Devilmite Beam Damage Multiplier)
Great Ape Nappa Costume 4 damaged (Empty) - ƒ‚ƒfE2240).unk			Rage_Shenron_60%_no_damage_no_LIPS			(Further shorten the tail by 30%+Edited character reference pose+Adjust Devilmite Beam Damage Multiplier)
Zarbon Costume 4 (Empty) - ƒ‚E2246).unk					Amond_no_damage_only_Special_Attack_cannot_transform	(Restored moves list) Note: No longer has "Present Bomb" height issue
Zarbon Costume 4 damaged (Empty) - ƒ‚E2250).unk				Amond_no_damage_only_Special_Attack_cannot_transform	(Restored moves list) Note: No longer has "Present Bomb" height issue
Zarbon Post-Transformation Costume 4 (Empty) - ƒ‚E2256).unk			Cacao_no_damage_no_LIPS					(Edited moveset, Aura, damaged taken and Entry Cman+Zsearch02020202+Metallic SFX)
Zarbon Post-Transformation Costume 4 damaged (Empty) - ƒ‚E2260).unk		Cacao_no_damage_no_LIPS					(Edited moveset, Aura, damaged taken and Entry Cman+Zsearch02020202+Metallic SFX and SSJ2)
Cui Costume 4 (Empty) - unknow_02276.unk					PuiPui_no_damage_new_version				(Zsearch00000000)
Cui Costume 4 damaged (Empty) - unknow_02280.unk				PuiPui_no_damage_new_version				(Zsearch00000000)
Dodoria Costume 4 (Empty) - ƒ‚ƒfE2266).unk					Wings_aka_Dorodabo_no_damage_no_LIPS_no_wings_movement	(Edited moveset, Aura and damaged taken+Zsearch00000000+Adjust Devilmite Beam Damage Multiplier)
Dodoria Costume 4 damaged (Empty) - ƒ‚ƒfE2270).unk				Wings_aka_Dorodabo_no_damage_no_LIPS_no_wings_movement	(Edited moveset, Aura and damaged taken+Zsearch00000000+Adjust Devilmite Beam Damage Multiplier)
Captain Ginyu Costume 4 (Empty) - ƒ‚ƒfE2286).unk				Goku+Scouter						(Change to GinyuGokuScouter from Vive's Revolution Sparking)
Captain Ginyu Costume 4 damaged (Empty) - ƒ‚ƒfE2290).unk			Goku_early+Damage					(Change to GinyuGokuScouterDamage from Vive's Revolution Sparking)
Recoome Costume 4 (Empty) - ƒ‚ƒfE2296).unk					Dore_no_damage						(Change to another version from Vive+Adjust etc and damage taken+Adjust Devilmite Beam Damage Multiplier)
Recoome Costume 4 damaged (Empty) - ƒ‚ƒfE2300).unk				Dore_no_damage						(Change to another version from Vive with damage outfit+Adjust etc and damage taken+Adjust Devilmite Beam Damage Multiplier)
Burter Costume 4 (Empty) - unknow_02306.unk					Neiz_no_damage+Support_from_Salza			(Change to Vive's model with JSN's LIPS)
Burter Costume 4 damaged (Empty) - unknow_02310.unk				Neiz_no_damage+Support_from_Salza			(Change to Vive's damage model with JSN's LIPS)
Jeice Costume 4 (Empty) - unknow_02316.unk					Daiz_no_damage_no_LIPS_only_Special_Attack+Turles_Support	(Restored and renamed moveset & Etc)
Jeice Costume 4 damaged (Empty) - unknow_02320.unk				Daiz_no_damage_no_LIPS_only_Special_Attack+Turles_Support	(Restored and renamed moveset & Etc)
Guldo Costume 3 (Empty) - unknow_02325.unk					Medamatcha_no_damage_no_LIPS				(Edited moveset, Aura, weight, damaged taken and Cman+Zsearch00000000+Adjust Devilmite Beam Damage Multiplier)
Guldo Costume 4 (Empty) - unknow_02326.unk					Rasin/Lakasei_no_damage_no_LIPS				(Edited moveset and Cman+Zsearch02020202+Adjust Devilmite Beam Damage Multiplier)
Guldo Costume 3 damaged (Empty) - unknow_02329.unk				Medamatcha_no_damage_no_LIPS				(Edited moveset, Aura, weight, damaged taken and Cman+Zsearch00000000+Adjust Devilmite Beam Damage Multiplier)
Guldo Costume 4 damaged (Empty) - unknow_02330.unk				Rasin/Lakasei_no_damage_no_LIPS				(Edited moveset and Cman+Zsearch02020202+Adjust Devilmite Beam Damage Multiplier)
Frieza 1st Form Costume 4 (Empty) - ƒ‚E2336).unk				Scoutless+Can_transform_until_Final_Form+No_armor		(Zsearch08080808)
Frieza 1st Form Costume 4 damaged (Empty) - ƒ‚E2340).unk			Scoutless+Can_transform_until_Final_Form+No_armor+Damage	(Zsearch08080808)
Mecha Frieza Costume 4 (Empty) - ƒ‚E2386).unk					Chilled							(No metallic SFX)
Mecha Frieza Costume 4 damaged (Empty) - ƒ‚E2390).unk				Chilled+Damage						(No metallic SFX)
King Cold Costume 3 (Empty) - ƒ‚E2395).unk					Kogu_no_damage+Zangya's_support				(Replace white armor King Cold with Kogu created by Matheus Nerd+Edited character moveset and etc+Adjust Devilmite Beam Damage Multiplier)
King Cold Costume 4 (Empty) - ƒ‚E2396).unk					Kogu_Transform_no_damage+Zangya's_support			(Replace Kogu with Kogu_Full_Power created by Matheus Nerd+Edited character moveset and etc+Adjust Devilmite Beam Damage Multiplier)
King Cold Costume 3 damaged (Empty) - ƒ‚E2399).unk				Kogu_no_damage+Zangya's_support				(Replace damaged white armor King Cold with Kogu created by Matheus Nerd+Edited character moveset and etc+Adjust Devilmite Beam Damage Multiplier)
King Cold Costume 4 damaged (Empty) - ƒ‚E2400).unk				Kogu_Transform_no_damage+Zangya's_support			(Maintain Kogu_Full_Power created by Matheus Nerd+Edited character moveset and etc+Adjust Devilmite Beam Damage Multiplier)
Appule Costume 3 (Empty) - ƒ‚ƒfE2405).unk					Ginger_no_damage					(Zsearch00000000+Adjust Devilmite Beam Damage Multiplier)
Appule Costume 4 (Empty) - ƒ‚ƒfE2406).unk					Mustard_no_damage					(Edited character reference pose and moveset+Edited Cman for Entrance, Win and Lose+Zsearch00000000+Adjust Devilmite Beam Damage Multiplier)
Appule Costume 3 damaged (Empty) - ƒ‚ƒfE2409).unk				Ginger_no_damage					(Zsearch00000000+Adjust Devilmite Beam Damage Multiplier)
Appule Costume 4 damaged (Empty) - ƒ‚ƒfE2410).unk				Mustard_no_damage					(Edited character reference pose and moveset+Edited Cman for Entrance, Win and Lose+Zsearch00000000+Adjust Devilmite Beam Damage Multiplier)
Frieza Soldier Costume 3 (Empty) - ƒtƒŠ[ƒUŒR•ºŽm(2415).unk			Slug_Soldier_no_damage_incorrect_Hub			(Change to blue color remake by Dragon V modding+Corrected Hub+Zsearch00000000+Have Solar Flare immunity+Adjust Devilmite Beam Damage Multiplier)
Frieza Soldier Costume 4 (Empty) - ƒtƒŠ[ƒUŒR•ºŽm(2416).unk			Angol_Paragus_Soldier_no_damage_no_LIPS			(Zsearch00000000)
Frieza Soldier Costume 3 damaged (Empty) - ƒtƒŠ[ƒUŒR•ºŽm(2419).unk		Slug_Soldier_no_damage_incorrect_Hub			(Change to black color remake by Dragon V modding+Corrected Hub+Zsearch00000000+Have Solar Flare immunity+Adjust Devilmite Beam Damage Multiplier)
Frieza Soldier Costume 4 damaged (Empty) - ƒtƒŠ[ƒUŒR•ºŽm(2420).unk		Angol_Paragus_Soldier_no_damage_no_LIPS			(Zsearch00000000)
Android #16 Costume 3 (Empty) - �E2425).unk					Capsule_Corporation					(Restored Super1)
Android #16 Costume 4 (Empty) - �E2426).unk					General_Rilldo_no_LIPS					(Restored Super1+Edited moveset and Etc+Zsearch00000000+Adjust Devilmite Beam Damage Multiplier)
Android #16 Costume 3 damaged (Empty) - �E2429).unk				Capsule_Corporation+Damage				(Restored Super1)
Android #16 Costume 4 damaged (Empty) - �E2430).unk				General_Rilldo_no_LIPS+Damage				(Restored Super1+Edited moveset and Etc+Zsearch00000000+Adjust Devilmite Beam Damage Multiplier)
Android #17 Costume 3 (Empty) - �E2435).unk					Slot_1+Can_Super_17+No_support_from_Android_18		(Red Aura Transformation and repair costume+Adjust Devilmite Beam Damage Multiplier)
Android #17 Costume 4 (Empty) - �E2436).unk					Slot_2+Can_Super_17+No_support_from_Android_18		(Red Aura Transformation and repair costume+Adjust Devilmite Beam Damage Multiplier)
Android #17 Costume 3 damaged (Empty) - �E2439).unk				Slot_1+Can_Super_17+No_support_from_Android_18+Damage	(Red Aura Transformation and repair costume+Adjust Devilmite Beam Damage Multiplier)
Android #17 Costume 4 damaged (Empty) - �E2440).unk				Slot_2+Can_Super_17+No_support_from_Android_18+Damage	(Red Aura Transformation and repair costume+Adjust Devilmite Beam Damage Multiplier)
Android #19 Costume 3 (Empty) - �E2455).unk					Android_#19_costume _1_damaged				(Replace Android_#19 to damage costume)
Android #19 Costume 4 (Empty) - �E2456).unk					Ebifurya_no_damage					(Edited character reference pose, moveset and Etc+Zsearch00000000+Adjust Devilmite Beam Damage Multiplier)
Android #19 Costume 3 damaged (Empty) - �E2459).unk				No_Hat+Damage						(Maintain Android_#19_No_Hat+Damage costume)
Android #19 Costume 4 damaged (Empty) - �E2460).unk				Ebifurya_no_damage					(Edited character reference pose, moveset and Etc+Zsearch00000000+Adjust Devilmite Beam Damage Multiplier)
Dr. Gero Costume 4 (Empty) - �E2466).unk					Dr_Myuu_no_damage_no_LIPS				(Zsearch00000000+Have Solar Flare immunity)
Dr. Gero Costume 4 damaged (Empty) - �E2470).unk				Dr_Myuu_no_damage_no_LIPS				(Zsearch00000000+Have Solar Flare immunity)
Cell Perfect Form Costume 3 (Empty) - unknow_02495.unk			Ultra+Can_Transform					(Adjust entry camera angle)
Cell Perfect Form Costume 4 (Empty) - unknow_02496.unk			Super_Ultra_no_LIPS+Can_Transform				(Adjust entry and exit camera angle)
Cell Perfect Form Costume 3 damaged (Empty) - unknow_02499.unk		Ultra+Can_Transform+Damage				(Adjust entry camera angle)
Cell Perfect Form Costume 4 damaged (Empty) - unknow_02500.unk		Ultra+Can_Transform+Damage				(Change to Super Ultra with damaged outfit+Adjust entry and exit camera angle)
Cell Jr. Costume 3 (Empty) - �E2515).unk					Hoi_Evil_Wizard_no_damage				(Edited moveset+No metallic SFX)
Cell Jr. Costume 4 (Empty) - �E2516).unk					Moah_Paragus_Soldier_no_damage				(Edited moveset+No metallic SFX+Adjust Devilmite Beam Damage Multiplier)
Cell Jr. Costume 3 damaged (Empty) - �E2519).unk				Hoi_Evil_Wizard_no_damage				(Edited moveset+No metallic SFX)
Cell Jr. Costume 4 damaged (Empty) - �E2520).unk				Moah_Paragus_Soldier_no_damage				(Edited moveset+No metallic SFX+Adjust Devilmite Beam Damage Multiplier)
Babidi Costume 3 (Empty) - ƒ‚ƒfE2525).unk					Bibidi							Note: Remove all Special Quotes
Babidi Costume 4 (Empty) - ƒ‚ƒfE2526).unk					Dr_Lychee_no_damage_no_LIPS				(Edited moveset and Cman for Entrance: Win and Lose)
Babidi Costume 3 damaged (Empty) - ƒ‚ƒfE2529).unk				Bibidi+Damage						Note: Remove all Special Quotes
Babidi Costume 4 damaged (Empty) - ƒ‚ƒfE2530).unk				Dr_Lychee_no_damage_no_LIPS				(Edited moveset and Cman for Entrance: Win and Lose)
Demon King Dabura Costume 3 (Empty) - �E2535).unk				Nicky_no_damage_only_Special_Attack			(Edited moveset, Cman and Etc+Added Super Janemba Sword+Adjust Devilmite Beam Damage Multiplier) Note: No longer has "Present Bomb" height issue
Demon King Dabura Costume 4 (Empty) - �E2536).unk				Ledgic							(Increase body size+Edited moveset, Cman and Etc+Added Super Janemba Sword+Adjust Devilmite Beam Damage Multiplier) Note: No longer has "Present Bomb" height issue
Demon King Dabura Costume 3 damaged (Empty) - �E2539).unk			Nicky_no_damage_only_Special_Attack			(Edited moveset, Cman and Etc+Added Super Janemba Sword+Adjust Devilmite Beam Damage Multiplier) Note: No longer has "Present Bomb" height issue
Demon King Dabura Costume 4 damaged (Empty) - �E2540).unk			Ledgic+Damage						(Increase body size+Edited moveset, Cman and Etc+Added Super Janemba Sword+Adjust Devilmite Beam Damage Multiplier) Note: No longer has "Present Bomb" height issue
Majin Buu Costume 4 (Empty) - ƒ‚�E2546).unk					Grand_Supreme_Kai_no_damage				(Edited moveset and Aura+Adjust Devilmite Beam Damage Multiplier)
Majin Buu Costume 4 damaged (Empty) - ƒ‚�E2550).unk				Grand_Supreme_Kai_no_damage				(Edited moveset and Aura+Adjust Devilmite Beam Damage Multiplier)
Garlic Jr. Costume 3 (Empty) - �E2605).unk					Salt_no_damage_cannot_transform				(Edited moveset and Cman)
Garlic Jr. Costume 4 (Empty) - �E2606).unk					Bujin_no_damage_cannot_transform				(Edited character reference pose, moveset and Etc) Note: Combination of Supreme Kai+Garlic Jr.+Matheus Nerd's Bujin
Garlic Jr. Costume 3 damaged (Empty) - �E2609).unk				Salt_no_damage_cannot_transform				(Edited moveset and Cman)
Garlic Jr. Costume 4 damaged (Empty) - �E2610).unk				Bujin_no_damage_cannot_transform				(Edited character reference pose, moveset and Etc) Note: Combination of Supreme Kai+Garlic Jr.+Matheus Nerd's Bujin
Super Garlic Jr. Costume 3 (Empty) - �E2615).unk				Sansho_no_damage					(Edited moveset, damaged taken and Cman) Note: No longer has "Present Bomb" height issue
Super Garlic Jr. Costume 4 (Empty) - �E2616).unk				Vinegar_no_damage					(Edited moveset, damaged taken and Cman)
Super Garlic Jr. Costume 3 damaged (Empty) - �E2619).unk			Sansho_no_damage					(Edited moveset, damaged taken and Cman) Note: No longer has "Present Bomb" height issue
Super Garlic Jr. Costume 4 damaged (Empty) - �E2620).unk			Vinegar_no_damage					(Edited moveset, damaged taken and Cman)
Dr. Wheelo Costume 3 (Empty) - ƒ‚ƒfE2625).unk					Yakon_no_damage_no_LIPS					(Change common parameter: Adjust damage taken, Green Aura, no longer robot and adjust balance settings)
Dr. Wheelo Costume 4 (Empty) - ƒ‚ƒfE2626).unk					Cooler_Core						(Transformation with 0.5 Health and full Ki Bars+No tail+No Solar Flare Immunity+Adjust Devilmite Beam Damage Multiplier)
Dr. Wheelo Costume 3 damaged (Empty) - ƒ‚ƒfE2629).unk				Yakon_no_damage_no_LIPS					(Change common parameter: Adjust damage taken, Green Aura, no longer robot and adjust balance settings)
Dr. Wheelo Costume 4 damaged (Empty) - ƒ‚ƒfE2630).unk				Cooler_Core+Damage					(Transformation with 0.5 Health and full Ki Bars+No tail+No Solar Flare Immunity+Adjust Devilmite Beam Damage Multiplier)
Salza Costume 4 (Empty) - ƒ‚ƒfE2676).unk					Kishime_no_damage					(Edited character moveset and Entry&Exit Camera+Zsearch00000000)
Salza Costume 4 damaged (Empty) - ƒ‚ƒfE2680).unk				Kishime_no_damage					(Edited character moveset and Entry&Exit Camera+Zsearch00000000)
Cooler Costume 3 damaged (Empty) - ƒ‚ƒfE2689).unk				Meta_no_damage+Can_Transform				(Change to damage model)
Cooler Final Form Costume 4 (Empty) - ƒ‚ƒfE2696).unk				Silver_no_damage+Transform				(No more green face blinking)
Cooler Final Form Costume 3 damaged (Empty) - ƒ‚ƒfE2699).unk			Meta_no_damage+Final_Form				(Change to darker color model)
Cooler Final Form Costume 4 damaged (Empty) - ƒ‚ƒfE2700).unk			Silver_no_damage+Final_Form				(No more green face blinking)
Meta-Cooler Costume 4 (Empty) - �E2706).unk					Core_with_tail_no_damage+Can_transform			(Change Transformation to red Aura and repair costume)
Meta-Cooler Costume 4 damaged (Empty) - �E2710).unk				Core_with_tail_no_damage+Can_transform			(Change Transformation to red Aura and repair costume)
Android 13 Costume 4 (Empty) - l‘¢lŠÔ13†_0(2716).unk				Android_15_cannot_transform				(Change moveset name+Have Solar Flare immunity) Note: No longer has "Present Bomb" height issue
Android 13 Costume 4 damaged (Empty) - l‘¢lŠÔ13†_0(2720).unk			Android_15_cannot_transform+Damage			(Change moveset name+Have Solar Flare immunity) Note: No longer has "Present Bomb" height issue
Android 13 Fusion Costume 4 (Empty) - l‘¢lŠÔ13†_1(2726).unk			Android_14_no_damage					(Change to Lukesca's model+Change moveset name and adjust damage taken) Note: No longer has "Present Bomb" height issue
Android 13 Fusion Costume 4 damaged (Empty) - l‘¢lŠÔ13†_1(2730).unk		Android_14_no_damage					(Change to Lukesca's damage model+Change moveset name and adjust damage taken) Note: No longer has "Present Bomb" height issue
Broly Legendary SSJ Costume 3 (Empty) - ƒ‚E2755).unk				Bio_Broly_no_damage_no_LIPS				(Change to another version from BENZ=with LIPS)
Broly Legendary SSJ Costume 3 damaged (Empty) - ƒ‚E2759).unk			Bio_Broly_no_damage_no_LIPS				(Change to another version from BENZ=with LIPS and purple color)
Zangya Costume 4 (Empty) - ƒ‚ƒfE2766).unk					West_Supreme_Kai_no_damage				(Adjust Devilmite Beam Damage Multiplier)
Zangya Costume 4 damaged (Empty) - ƒ‚ƒfE2770).unk				West_Supreme_Kai_no_damage				(Adjust Devilmite Beam Damage Multiplier)
Bojack Costume 4 (Empty) - ƒ{[ƒWƒƒƒbƒN_0(2776).unk				Bido_no_damage_no_LIPS					(Edited moveset+Adjust Devilmite Beam Damage Multiplier)
Bojack Costume 4 damaged (Empty) - ƒ{[ƒWƒƒƒbƒN_0(2780).unk			Bido_no_damage_no_LIPS					(Edited moveset+Adjust Devilmite Beam Damage Multiplier)
Bojack Full Power Costume 4 (Empty) - ƒ{[ƒWƒƒƒbƒN_1(2786).unk			Hatchiyack_no_damage_no_LIPS				(Change to Apioman's mode+Edited moveset and Etc+Adjust Devilmite Beam Damage Multiplier)
Bojack Full Power Costume 4 damaged (Empty) - ƒ{[ƒWƒƒƒbƒN_1(2790).unk		Hatchiyack_no_damage_no_LIPS				(Change to Apioman's mode+Edited moveset and Etc+Adjust Devilmite Beam Damage Multiplier)
Janemba Costume 3 (Empty) - �E2795).unk					Luud_no_damage						(Edited character reference pose, character moveset and damaged taken)
Janemba Costume 4 (Empty) - �E2796).unk					Luud_Pan_Absorbed_no_damage				(Edited character reference pose and character moveset)
Janemba Costume 3 damaged (Empty) - �E2799).unk				Luud_no_damage						(Edited character reference pose, character moveset and damaged taken)
Janemba Costume 4 damaged (Empty) - �E2800).unk				Luud_Pan_Absorbed_no_damage				(Edited character reference pose and character moveset)
Super Janemba Costume 3 (Empty) - �E2805).unk				North_Supreme_Kai_no_damage_no_LIPS			(Edited character reference pose and character moveset+Adjust Devilmite Beam Damage Multiplier)
Super Janemba Costume 4 (Empty) - �E2806).unk				Haze_Shenron_no_damage_no_LIPS				(Edited character reference pose, moveset and Ultimate mini camera+Adjust Devilmite Beam Damage Multiplier) Note: No longer has "Present Bomb" height issue
Super Janemba Costume 3 damaged (Empty) - �E2809).unk			North_Supreme_Kai_no_damage_no_LIPS			(Edited character reference pose and character moveset+Adjust Devilmite Beam Damage Multiplier)
Super Janemba Costume 4 damaged (Empty) - �E2810).unk			Haze_Shenron_no_damage_no_LIPS				(Edited character reference pose, moveset and Ultimate Cman+Adjust Devilmite Beam Damage Multiplier) Note: No longer has "Present Bomb" height issue
Hirudegarn Costume 4 (Empty) - �E2816).unk					Naturon_Shenron_80%_no_damage_no_LIPS_only_Special_Attack	(Change back to remake version from Matheus Nerd+Edited character reference pose, character moveset and common param+Adjust Devilmite Beam Damage Multiplier)
Hirudegarn Costume 4 damaged (Empty) - �E2820).unk				Naturon_Shenron_80%_no_damage_no_LIPS_only_Special_Attack	(Change back to remake version from Matheus Nerd+Edited character reference pose, character moveset and common param+Adjust Devilmite Beam Damage Multiplier)
Baby Vegeta Costume 3 (Empty) - ƒxƒr[ƒxƒW[ƒ^(2825).unk				Baby_no_damage_no_LIPS+Can_Transform			(Transformation will not repair costume)
Baby Vegeta Costume 4 (Empty) - ƒxƒr[ƒxƒW[ƒ^(2826).unk				Slot_1+Complete_Transformation+Can_SSJ2_Majin		(Transformation will not repair costume)
Baby Vegeta Costume 3 damaged (Empty) - ƒxƒr[ƒxƒW[ƒ^(2829).unk			Baby_no_damage_no_LIPS+Can_Transform			(Transformation will not repair costume)
Baby Vegeta Costume 4 damaged (Empty) - ƒxƒr[ƒxƒW[ƒ^(2830).unk			Slot_1+Complete_Transformation+Can_SSJ2_Majin		(Transformation will not repair costume)
Super Baby 1 Costume 3 (Empty) - ƒxƒr[ƒxƒW[ƒ^(2835).unk			Teen_no_damage_no_LIPS+Can_Transform+Can_normal		(Transformation will not repair costume)
Super Baby 1 Costume 4 (Empty) - ƒxƒr[ƒxƒW[ƒ^(2836).unk			Slot_1+Complete_Transformation				(Transformation will not repair costume)
Super Baby 1 Costume 3 damaged (Empty) - ƒxƒr[ƒxƒW[ƒ^(2839).unk		Teen_no_damage_no_LIPS+Can_Transform+Can_normal		(Transformation will not repair costume)
Super Baby 1 Costume 4 damaged (Empty) - ƒxƒr[ƒxƒW[ƒ^(2840).unk		Slot_1+Complete_Transformation+Damage			(Transformation will not repair costume)
Super Baby 2 Costume 3 (Empty) - ƒxƒr[ƒxƒW[ƒ^(2845).unk			Adult+Can_Ape+Can_normal					(Transformation will not repair costume)
Super Baby 2 Costume 4 (Empty) - ƒxƒr[ƒxƒW[ƒ^(2846).unk			Slot_1+Can_Great_Ape_Baby+Can_Super_Baby_1		(Transformation will not repair costume)
Super Baby 2 Costume 3 damaged (Empty) - ƒxƒr[ƒxƒW[ƒ^(2849).unk		Adult+Can_Ape+Can_normal+Damage				(Transformation will not repair costume)
Super Baby 2 Costume 4 damaged (Empty) - ƒxƒr[ƒxƒW[ƒ^(2850).unk		Slot_1+Can_Great_Ape_Baby+Can_Super_Baby_1+Damage	(Transformation will not repair costume)
Super 17 Costume 3 (Empty) - �E2865).unk					Slot_1							(Transformation with 0.5 Health and full Ki Bars)
Super 17 Costume 4 (Empty) - �E2866).unk					Slot_1							(Transformation with 0.5 Health and full Ki Bars)
Super 17 Costume 3 damaged (Empty) - �E2869).unk				Slot_1+Damage						(Transformation with 0.5 Health and full Ki Bars)
Super 17 Costume 4 damaged (Empty) - �E2870).unk				Slot_1+Damage						(Transformation with 0.5 Health and full Ki Bars)
Nuova Shenron Costume 4 (Empty) - �E2876).unk				Eis_Shenron						(Reuse back the whole model from Vive+Adjust height+Adjust Devilmite Beam Damage Multiplier)
Nuova Shenron Costume 4 damaged (Empty) - �E2880).unk			Eis_Shenron+Damage					(Reuse back the whole model from Vive+Adjust height+Adjust Devilmite Beam Damage Multiplier)
General Tao Costume 3 (Empty) - ƒ‚ƒfE2905).unk				Shirtless							(No Aura and Cannot Fly)
General Tao Costume 4 (Empty) - ƒ‚ƒfE2906).unk				Dr_Kochin_no_damage_no_LIPS				(Adjust common param=Android, Robot, no Aura, cannot fly, cannot shoot Ki  and Ki setting changed+Camera Entry Angle)
General Tao Costume 3 damaged (Empty) - ƒ‚ƒfE2909).unk			Shirtless+Damage						(No Aura and Cannot Fly)
General Tao Costume 4 damaged (Empty) - ƒ‚ƒfE2910).unk			Dr_Kochin_no_damage_no_LIPS				(Adjust common param=Android, Robot, no Aura, cannot fly, cannot shoot Ki  and Ki setting changed+Camera Entry Angle)
Cyborg Tao Costume 3 (Empty) - ƒ‚ƒfE2915).unk					Master_Shen_no_damage_no_LIPS				(No Aura+No Blade SFX+Edited character moveset+Zsearch00000000) Note: No longer has "Present Bomb" height issue
Cyborg Tao Costume 4 (Empty) - ƒ‚ƒfE2916).unk					Shugesh+Can_transform_to_Giant_Ape_Goku			(No Solar Flare immunity+Edited character moveset+Zsearch02020202) Note: Complete Great Ape transformation scene
Cyborg Tao Costume 3 damaged (Empty) - ƒ‚ƒf E2919).unk			Master_Shen_no_damage_no_LIPS				(No Aura+No Blade SFX+Edited character moveset+Zsearch00000000) Note: No longer has "Present Bomb" height issue
Cyborg Tao Costume 4 damaged (Empty) - ƒ‚ƒf E2920).unk			Shugesh_no_Scouter+Can_transform_to_Giant_Ape_Goku	(No Solar Flare immunity+Edited character moveset+Zsearch07070707) Note: Complete Great Ape transformation scene
General Blue Costume 3 (Empty) - unknow_02925.unk				Bulma_Bunny_no_damage_sealed_LIPS			(Change to Teen Bulma from Matheus Nerd and increase body size+Edited character reference pose, moveset and Camera Entry&Exit Angle+Adjust Devilmite Beam Damage Multiplier)
General Blue Costume 4 (Empty) - unknow_02926.unk				Launch_Bad_no_LIPS_only_Special_Attack			(Edited character reference pose, moveset and Camera Entry&Exit Angle+Adjust Devilmite Beam Damage Multiplier) Note: No longer has "Present Bomb" height issue
General Blue Costume 3 damaged (Empty) - unknow_02929.unk			Bulma_Bunny_no_damage_sealed_LIPS			(Edited character reference pose, moveset and Camera Entry&Exit Angle+Adjust Devilmite Beam Damage Multiplier)
General Blue Costume 4 damaged (Empty) - unknow_02930.unk			Launch_Good_no_LIPS_only_Special_Attack			(Edited character reference pose, moveset and Camera Entry&Exit Angle+Adjust Devilmite Beam Damage Multiplier) Note: No longer has "Present Bomb" height issue
Devilman Costume 3 (Empty) - ƒ‚E2935).unk					Lucifer_no_damage_no_LIPS_incorrect_Hub			(No Aura and Cannot Fly)
Devilman Costume 4 (Empty) - ƒ‚E2936).unk					Kami_no_damage						(Edited Ultimate+Adjust Devilmite Beam Damage Multiplier and change Aura to blue)
Devilman Costume 3 damaged (Empty) - ƒ‚E2939).unk				Lucifer_no_damage_no_LIPS_incorrect_Hub			(No Aura and Cannot Fly)
Devilman Costume 4 damaged (Empty) - ƒ‚E2940).unk				Kami_no_damage						(Edited Ultimate+Adjust Devilmite Beam Damage Multiplier and change Aura to blue)
Pilaf Machine Costume 3 (Empty) - ƒsƒ‰ƒtƒ}ƒVƒ“_0(2945).unk			Robot_Pirate_no_damage_cannot_transform			(Edited character reference pose, moveset and mini camera+Cannot Fly+Adjust Devilmite Beam Damage Multiplier)
Pilaf Machine Costume 4 (Empty) - ƒsƒ‰ƒtƒ}ƒVƒ“_0(2946).unk			Gill_no_damage_cannot_transform				(Change to another version from Matheus Nerd+Edited character reference pose, moveset and mini camera+Adjust Devilmite Beam Damage Multiplier)
Pilaf Machine Costume 3 damaged (Empty) - ƒsƒ‰ƒtƒ}ƒVƒ“_0(2949).unk		Robot_Pirate_no_damage_cannot_transform			(Edited character reference pose, moveset and mini camera+Cannot Fly+Adjust Devilmite Beam Damage Multiplier)
Pilaf Machine Costume 4 damaged (Empty) - ƒsƒ‰ƒtƒ}ƒVƒ“_0(2950).unk		Gill_no_damage_cannot_transform				(Change to another version from Matheus Nerd+Edited character reference pose, moveset and mini camerat+Adjust Devilmite Beam Damage Multiplier)
Pilaf Machine Fusion Costume 3 (Empty) - ƒsƒ‰ƒtƒ}ƒVƒ“_1(2955).unk		Cyclopian_Guard_no_damage				(Edited character reference pose+Adjust Devilmite Beam Damage Multiplier)
Pilaf Machine Fusion Costume 4 (Empty) - ƒsƒ‰ƒtƒ}ƒVƒ“_1(2956).unk		Sigma_GT_no_damage					(Edited character reference pose)
Pilaf Machine Fusion Costume 3 damaged (Empty) - ƒsƒ‰ƒtƒ}ƒVƒ“_1(2959).unk	Cyclopian_Guard_no_damage				(Change to another color model from Matheus Nerd+Edited character reference pose+Adjust Devilmite Beam Damage Multiplier)
Pilaf Machine Fusion Costume 4 damaged (Empty) - ƒsƒ‰ƒtƒ}ƒVƒ“_1(2960).unk	Sigma_GT_no_damage					(Edited character reference pose)
Tambourine Costume 3 (Empty) - ƒ‚E2965).unk					Cymbal_no_damage_no_LIPS				Note: Remove all Special Quotes
Tambourine Costume 4 (Empty) - ƒ‚E2966).unk					Drum_no_damage_no_LIPS					Note: Remove all Special Quotes
Tambourine Costume 3 damaged (Empty) - ƒ‚E2969).unk				Cymbal_no_damage_no_LIPS				Note: Remove all Special Quotes
Tambourine Costume 4 damaged (Empty) - ƒ‚E2970).unk				Drum_no_damage_no_LIPS					Note: Remove all Special Quotes
Spopovich Costume 3 (Empty) - �E3005).unk					Long_hair						(No Aura, cannot shoot Ki and Cannot Fly+Adjust Devilmite Beam Damage Multiplier)
Spopovich Costume 4 (Empty) - �E3006).unk					Commander_Zeeun_no_damage+No_support			(Purple Aura, Shooting Ki x4+Adjust Devilmite Beam Damage Multiplier)
Spopovich Costume 3 damaged (Empty) - �E3009).unk				Long_hair+Damage					(No Aura, cannot shoot Ki and Cannot Fly+Adjust Devilmite Beam Damage Multiplier)
Spopovich Costume 4 damaged (Empty) - �E3010).unk				Commander_Zeeun_no_damage+No_support			(Purple Aura, Shooting Ki x4+Adjust Devilmite Beam Damage Multiplier)
Future Gohan Costume 4 (Empty) - �E3016).unk					Goten_GT+Can_SSJ					(Change to another version from KMS Mods)
Future Gohan Costume 4 damaged (Empty) - �E3020).unk				Goten_GT+Can_SSJ+Damage				(Change to another version from KMS Mods=has a different damaged outfit)
Future Gohan SSJ Costume 4 (Empty) - �E3026).unk				Goten_GT+SSJ+Can_normal				(Change to another version from KMS Mods+Edited character moveset)
Future Gohan SSJ Costume 4 damaged (Empty) - �E3030).unk			Goten_GT+SSJ+Can_normal+Damage			(Change to another version from KMS Mods=has a different damaged outfit+Edited character moveset)
18/01/2023
DD/MM/YYYY
Vegeta (End) Majin Costume 3 (Empty) - E1795).unk			Cell_saga+SSJ2_Majin+Can_normal				(Change to another version with no more blinking M)
Dr. Wheelo Costume 3 (Empty) - ƒ‚ƒfE2625).unk				Yakon_no_damage_no_LIPS_incomplete_Hub			(Change to another version with updated Hub)
Dr. Wheelo Costume 3 damaged (Empty) - ƒ‚ƒfE2629).unk			Yakon_no_damage_no_LIPS_incomplete_Hub			(Change to another version with updated Hub)
Super Janemba Costume 4 (Empty) - �E2806).unk			Haze_Shenron_no_damage_no_LIPS				(Change to smaller version from Matheus Nerd)
Super Janemba Costume 4 damaged (Empty) - �E2810).unk		Haze_Shenron_no_damage_no_LIPS				(Change to smaller version from Matheus Nerd)
23/08/2022
DD/MM/YYYY
Goten Costume 3 (Empty) - ƒ‚ƒfE1885).unk				Kimono_no_damage+Can_SSJ+Can_Fusion 			(Change to another version)
Goten Costume 3 damaged (Empty) - ƒ‚ƒfE1889).unk			Kimono_no_damage+Can_SSJ+Can_Fusion 			(Change to another version)
Goten SSJ Costume 3 (Empty) - ƒ‚ƒfE1895).unk				Kimono_no_damage+SSJ+Can_normal+Can_Fusion 		(Change to another version)
Goten SSJ Costume 3 damaged (Empty) - ƒ‚ƒfE1899).unk			Kimono_no_damage+SSJ+Can_normal+Can_Fusion 		(Change to another version)
Android #8 Costume 3 (Empty) - ƒ‚E2125).unk				Green_color						(Change to OxKing_no_LIPS_no_damage)
Android #8 Costume 3 damaged (Empty) - ƒ‚E2129).unk			Green_color+Damage 					(Change to OxKing_no_LIPS_no_damage)
Cui Costume 4 (Empty) - unknow_02276.unk				PuiPui_no_damage_no_LIPS					(Change to another version with LIPS)
Cui Costume 4 damaged (Empty) - unknow_02280.unk			PuiPui_no_damage_no_LIPS					(Change to another version with LIPS)
Devilman Costume 3 (Empty) - ƒ‚E2935).unk				Lucifer_no_damage_no_LIPS_incorrect_Hub			(Update the Hub)
Devilman Costume 3 damaged (Empty) - ƒ‚E2939).unk			Lucifer_no_damage_no_LIPS_incorrect_Hub			(Update the Hub)
(Note: If you want to keep any of the old character 3D model, use AFSExplorer to export it first before placing the latest patch. Then, import it back after patching.)


L) Software involved:
Advanced Renamer
AFSExplorer v3.7
Blender
Conversion Model 3D v1.2
DBZT3 Model Builder v2.5
DkZ Studio
Genius Editor Corp Bt3 v5.1
https://cloudconvert.com/
https://ezgif.com/webp-to-png
https://jpg2png.com/
https://www.iloveimg.com/compress-image/compress-png
https://www.photoroom.com/background-remover
https://www.upscale.media/product/png-image-enlarger-and-enhancer
HxD
ImgBurn
KkTeamBigImagesCreator v3.1
KkTeamModelEditor v0.5.1
KkTeamPEditor v5.4
KkTeamUnkArchivesExplorer v4.0
KkTeamQrsExplorer v1.0
KZE Editor
Optpix ImageStudio v3.12a
Peazip
PES Sound File Converter v1.8
Photoshop CS6
PNGoo.0.1.1
Sparking Studio
xdelta


Credits:
Benji for the character 3D models.
https://benjagalarcecastro.wixsite.com/benjimods

DragonBall Z League for sharing Sparking Studio v6 created by Hirotex.
https://www.youtube.com/watch?v=6pSf0UZ_X9Y

Dragon V modding for the character 3D models.
https://www.youtube.com/channel/UCHK8fr8Fem5O-NUaz8Q3p5Q

GENIUS CORP for providing the handy GENIUS PLUS EDITION X.18.
https://www.youtube.com/user/realmaximun/featured

Hunter for sharing BT2 Techniques to BT3
https://www.youtube.com/watch?v=MhuWu5ssdHg

JSN Mods for character 3D Models.
https://www.youtube.com/@JSNMods
https://www.youtube.com/watch?v=_4BS9lH_Cj8

Kitty K Mods for sharing PNGoo.0.1.1 and Sparking Studio v5.2 created by Hirotex.
https://www.youtube.com/watch?v=qmST4jiGvro

KKTEAMTENKAICHI for all their wonderful software and mods.
https://kkteamtenkaichi.blogspot.com/

KMS Mods for character 3D Models, FAs and KZEs.
https://kmsmods.blogspot.com/

Mattheus Nerd for the character 3D Models, FAs and KZEs.
https://matheusmodsdbzbudokaitenkaichi3ps2.blogspot.com/

PIPE GAME for character 3D Models.
https://www.youtube.com/@PIPEGAME
https://pipe-gba.wixsite.com/pipe-game56

TeamBT4 for their English translated Japanese BGM texture text from DBZ Tenkaichi Collection.
https://teambt4.wixsite.com/dbzbt4ps2oficial/tenkaichi-collection

Various authors on the below website for their character 3D models.
https://lukemods.wixsite.com/luktsu/dragon-ball

VINCENT BELMONT-BT3 for character 3D models.
https://www.youtube.com/@vincentbelmont-bt3715/videos

Vive for character 3D models, the edited English BGM textures and 'res(3).unk' which makes all the characters have four slot colors in the base patch.
https://www.youtube.com/c/ViveTheModder

Xavier DBZ for character 3D Models.
https://www.youtube.com/@xavierdbz3744
https://www.youtube.com/watch?v=29SbBYyRnX4&t=0s

And the rest of the authors for their character 3D models that have been mentioned in the main readme patch.
https://www.romhacking.net/hacks/ps2/patches/6337readme.txt


Written by injoon84:
16/08/2022
DD/MM/YYYY


Latest update on:
26/06/2024
DD/MM/YYYY
