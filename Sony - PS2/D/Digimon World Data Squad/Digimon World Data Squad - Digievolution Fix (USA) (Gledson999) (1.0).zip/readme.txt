This hack adds Demon Lord Digievolution to Lalamon Galaxy.

When the game was released, the Digimon called Dark Lord was
missing from being registered in the encyclopedia list, he is
the only Digimon that cannot be obtained through Digievolution,
with this hack it is now possible to Digivolve to Demon Lord
through the Lalamon galaxy and be registered in the encyclopedia list.

Changelog v1:
* New Digievolution (Demon Lord) has been added
* New texture was created for the new Digievolution
* New constellation (Pentagram) was created for the new Digievolution
* Fixes the registration of Demon Lord in the encyclopedia list.

WEBSITES:
* https://retro-jogos.com
* https://www.youtube.com/RetroJogos