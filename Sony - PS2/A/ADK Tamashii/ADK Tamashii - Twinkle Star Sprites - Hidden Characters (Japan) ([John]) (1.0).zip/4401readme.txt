ADK Tamashii -Twinkle Star Sprites- hidden characters.

Improvement on Twinkle Star Sprites:

Enable Memory, Mevious, Dark.Ran, and Sprites as selectable characters.

The patch can be applied to the iso file through the program Delta Patcher which can be found in this site.

==============
Special thanks
==============
Special thanks to the original creators of these hacks.
Unfortunately I do not know their names, but the credit is for all of them.
The hacks presented in this patch are partially based on their work.
==============================
John-Paul from www.Emudesc.com
==============================
   Twitter: @Juan_Pablo_81
==============================