
Improvement in Art of Fighting:
-All characters are selectable in single player mode.

Improvement in Art of Fighting 2:
-Replaces the character Mr.Big with Geese Howard in the character selection screen.

=========
Move List
=========
From:
http://www.arcadequartermaster.com/

==== ==== === ==== ====== ====
TODO JACK LEE KING MICKEY JOHN
==== ==== === ==== ====== ====
http://www.arcadequartermaster.com/aof1_1.html#todo

====== =========
Mr.BIG Mr.Karate
====== =========
http://www.arcadequartermaster.com/aof1_2.html#big

==========
Known bugs
==========

Art of Fighting
- After completing any BONUS GAME level using a Extra Character, the game may (or not) end suddenly. (It will show the game's ending)

Art of Fighting 2
- Once you finish a single fight against the CPU using Geese Howard, 
the game will think that you lost and send you to the continue screen.
=================================================================================================
These Bugs do not appear in the Final Version of the patch on which these Hacks were based.
But at the moment I do not know how to fix them, so any help to solve this will be well received.
=================================================================================================

==============
Special thanks
==============
Special thanks to the original creators of these hacks.
Unfortunately I do not know their names, but the credit is for all of them.
The hacks presented in this patch are partially based on their work.
========================
Twitter: @Juan_Pablo_81
========================