**********************************************************
*** English translation of Atelier Marie + Elie on PS2 ***
**********************************************************

The game has been translated to English by the Atelier Traduction team:
http://ateliertraduction.forumactif.org

*************************
** Playing on emulator **
*************************

!!! PLEASE READ !!!

If you want to play on the emulator (pcsx2), please read the "Tutorial_patch_EN_AME.pdf" file to get the best performances without bugs.

********************************
** Playing on Open PS2 Loader **
********************************

You must enable Mode 1 in Open PS2 Loader to make the game work.
Some people got a white screen by transfering the game via Winhiip. If you have that problem, please use HDL Dump instead.
The 480p mode is not supported because it causes troubles with the videos of the game.

***************************
** Patching instructions **
***************************

- Take your ISO file (with any name *.iso) and put it in the "Patch" folder.

- Run "English_AME_patch_v1.01.exe".

The patch must be applied on the ISO file of the japanese version of Atelier Marie + Elie on PS2.

If the program doesn�t run, disable your antivirus software.

More detailed instructions are available in the "Tutorial_patch_EN_AME.pdf" file.
If you can't read that file, please install "Adobe Reader" on your system, which is available here:
https://get.adobe.com/reader/

If you don't know how to get an ISO file from your disc, please read the "Tutorial_patch_EN_AME.pdf" file.

***************
** Checksums **
***************

ISO file CRC32:

JAP retail version: 879471A8
ENG patched version: DED23029

***************
** Additions **
***************

The remake didn't contain the extra menus from the original games on PS1. We added the extra menus ourselves from scratch with the data from the original games. These extra menus are unlocked after finishing a game with a good ending. We hope you will enjoy them.

We added the original openings from the original games. You can see each of them if you leave the game idle in the Main Title menu of its respective game.

**********
** Bugs **
**********

The official japanese version of the remake had numerous bugs like freezes or bad conditions to get some events or endings. We have fixed all these ones.

*************
** Credits **
*************

- Hacker:

RyleFury

- Translator:

Aquagon (from A Reyvateil's Melody)

- Texts Editor:

Replicant

- Graphics Editor:

RyleFury

- Video Editor:

RyleFury

- German Language Specialist:

Omegasword

- Testers:

Aquagon
RyleFury
Elfeni
Izcee
BadTetsuo

**************
** Versions **
**************

- v1.0 (03/18/2018) :

Complete translation in English of texts, images and videos.
Addition of the PS1 Openings and Extra menus.

- v1.01 (04/27/2018) :

Fix the audio tracks during the PS1 Opening videos which didn't play if the game was played on a burned disc.