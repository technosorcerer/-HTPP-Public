"JoJo's Bizarre Adventure: Golden Wind"
Traducción al Español Ver. 1.0 (04/01/2025)
por Max1323 (Traducciones Max1323).
Basada en la gran traducción de Hudgyn Sasdarl, penguino, infval.
---------------------------------------------------
Descripción:
La quinta parte de JoJo's Bizarre Adventure. Es el año 2001,
en Italia, la historia gira en torno a Giorno Giovanna, 
el hijo ilegítimo de DIO y el sueña con convertirse en
un gang-star.

Desarrollado: Capcom
Publicado:    Capcom
Lanzamiento:  25/07/2002 (JAP)
---------------------------------------------------
Acerca del proyecto:
-La mayoría de los textos están traducidos. Se agregaron los caracteres españoles.

-La mayoría de los gráficos fueron traducidos con ciertas limitaciones. El gráficos al ser derrotado es dejado en japónes
y el de Retired queda en inglés.

-Los nombres de los personajes y Stands no están censurados y el nombre de Buccellati es corregido a Bucciarati.

-Algunos diálogos fueron sacados del anime y de JJBA: All Star Battle R para corregir o mantener ciertas frases de los personajes.

-Algunos textos tienen limitaciones como el menú, galería, bios de personajes, etc.. Esto es porque estaban en el archivo del SLPM y no como los textos de la historia que son archivos apartes.

-Gracias a las instrucciones, herramientas y toda la información de penguino e infval fue posible está traducción.
---------------------------------------------------
Instrucciones del parche:
Utilizar Rom Patcher (Parcheador Online):
https://romhackplaza.org/patch/
Recomendación:
Utilizar xdelta UI
https://www.romhacking.net/utilities/598/

1° Agregar el parche en Patch
2° Agregar el juego sin modificar en Source File
3° Al guardar el juego en Output File, es necesario agregar el nombre con la extensión Ejemplo.iso

Archivo xdelta
Jojo no Kimyou na Bouken - Ougon no Kaze (Japan).iso
File Size:        3.55 GB
Número de Serie:  SLPM-65140
File/ROM SHA-1:   DCB15D9DD95F6A54B0EF0BC42E5FE2EC47087B9F
File/ROM CRC32:   79A4677D