This English translation patch for
JoJo's Bizarre Adventure: Phantom Blood
(JoJo no Kimyou na Bouken: Fantomu Buraddo)
was created by penguino and Hudgyn Sasdarl.

Installation:
After extracting the files, open xdeltaUI.exe and make sure the "Apply Patch" tab is selected. Click the "Open..." button under the "Patch:" header and select the .xdelta file included in this zipped file, then do the same with "Source File:" and select your unmodified ISO of the game. Under the "Output File:" header, click the "..." button and select a name and location for the patched ISO. Finally, click the "Patch" button at the bottom of the window, and wait until the program is finished patching the file before use.

Warning:
As of the writing of this document, no available PS2 emulator can run this game without graphical issues. As a result, some graphics may be displayed incorrectly. A bonus cheat file for PCSX2 is included which contains codes to work around some of the graphical issues.
Due to the translated save data name, save files for the Japanese version of the game will not work with the translated ISO. To partially remedy this, a memory card file with a 100% save file is included with the patch.

Additional credits:
Luigi Auriemma - QuickBMS program and FILELINK script
Marco Calautti - Rainbow (TIM2 export/import) program
"f2065.ru" - ZLib GUI (file compression) program
WE-NG Team - AFSExplorer (SOUND.AFS explorer) program
Viz Media - Fairly decent official translation of Phantom Blood
DeepL - Very decent machine translation engine
pips - Crucial stalemate resolution associate