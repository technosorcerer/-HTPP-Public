A quality-of-life mod that aims to reduce the amount of grinding needed to acquire late-game mantras by reducing their prices. Mantras of difficulty 5 and up have their prices reduced by half or more.

General adjustments:
All mantras of price $100000 -> $50000
All mantras of price $250000 -> $100000
All mantras of price $600000 -> $300000
All mantras of price $800000 -> $400000
All mantras of price $1500000 -> $1000000

Specific adjustments:
Dark Leader:			$150000 -> $75000
Dark Lord:				$300000 -> $150000
Dark King:				$800000 -> $500000
Cherubim & Death:		$120000 -> $80000
Curse:					$40000	-> $30000
Arcane:					$120000 -> $50000
Calm Spirit:			$40000	-> $30000
Progenitor:				$120000	-> $60000
Death Spirit:			$300000 -> $100000
Overlord:				$400000 -> $200000
World:					$300000 -> $100000
Root of Evil:			$2500000 -> $1000000
Dragonslayer:			$1500000 -> $800000
Aksara & God of Light:	$2000000 -> $1000000

Esoteric mantras remain unchanged.

(If you still find yourself with money problems, money is stored at memory address 0x21175641 and can be modified with a debugger.)