This is a cosmetic mod that changes some skill and mantra names to be more accurate to the original Japanese, clearer at conveying their mechanical effect, or just to sound nicer. A list of changes and reasoning are provided in this file.

--------------------------------------
Typo/mistranslation corrections:
	-Varna -> Varuna
	-Vayaviya -> Vayavya
	-Brahma Sutra -> Brahmastra
	-Divine Light -> Omnipotence

Also fixed the broken Brahma Sutra 3 message. (It's supposed to be "Pure, intense light engulfs the area!" but it looks like the coders accidentally put the message ID in the message text field.)

--------------------------------------
Elemental mantras now have more consistent naming schemes. Except for Earth, they are now all:
	[Element] Spirit -> [Element] Demon -> Elemental -> (Unique) -> [Element] Master
	
Fire Spirit -> Fire Demon -> Salamander -> Fire Lord -> Fire Master
Ice Spirit -> Ice Demon -> Jack Frost -> Ice Wolf -> Ice Master
Wind Spirit -> Wind Demon -> Sylph -> Wind Waker -> Wind Master
	(yes it's a Zelda reference, sue me)
Bolt Spirit -> Bolt Demon -> Raiju -> Bolt Wizard -> Bolt Master
Earth Spirit -> Earth Shrine -> Gnome -> Earth Temple -> Earth Empire
	(it annoyed me that the upper Earth mantras broke the pattern of being places rather than titles)

--------------------------------------
Other mantras:

Dark Leader -> Dark Wizard
	("Leader" is just really awkward in this context, sorry localizers)
Priestess -> Miko
	(a bhikkuni is a Buddhist priestess, so another specific priestess seems more fitting for the next mantra than the generic "priestess")
Thrones -> Throne
	(no idea why this was plural)
Evil Spirit -> Ghost
Dark Spirit -> Wraith
	(increasingly edgy adjectives prepended to "Spirit" just sounds dumb in English, sorry)
Arcane -> Arcana
	(for consistency with other boost mantras being nouns)
Fierce Spirit -> Kishin
Death Spirit -> Psychopomp
	(I have no idea what this was supposed to mean, but it's confusing to have it on the healing branch, especially when there's already a "Death" mantra. I presume it's meant to mean "spirit with power over life and death", and this is the closest English has to that.)
Vicious God -> Messiah
	(I have no idea what "Vicious God" is supposed to mean or why it's on the healing branch of all things. Since this mantra gives Salvation, I decided to just double down on the Christianity theme.)
Adamant -> Atman
	(I assume this was a mistranslation, this fits with the ailment line's Buddhist theme)
Holy Leader -> Buddha
	(same)
Formless -> Nirvana
	(this appears to be a reference to "formless meditation" in Buddhism, but that's not clear to Westerners; this is a clearer reference and is close in meaning)
Evil God -> Devil
	("Evil God" just sounds silly, sorry localizers)

--------------------------------------
Demon races:

Nether -> Mystic
Light -> Angel
Death -> Reaper
Tyrant -> God
Fury -> God
	(Shiva and Vishnu are of equal rank with Brahma in Hinduism so they ought to have the same title. Also neither of the given titles make sense for them.)
Fiend -> Judge
	(In Japanese Satan's title is the same word used for "the Devil", which makes no sense when he is not only a different being from Lucifer but of opposite alignment in SMT. I'm making an executive decision and giving him a completely different title that fits his actual identity.)

--------------------------------------
Skills:

Explode -> Explosion
Cold Wave -> Cold Snap
	(more accurate to Japanese and is an actual term)
Avalanche -> Landslide
	(I associate "avalanche" soley with snowfall)
Vanity -> Madness
	(Japanese name is a reference to a nihilistic Buddhist saying meaning "all is vanity, form is emptiness", essentially saying existence is contradictory. Given two of the ailments inflicted are mental, I assume the idea is the spell drives you mad by revealing the meaninglessness of existence?)
Petrifier -> Entomb
	(to reduce confusion with Petrify)
Calm Death -> Eternal Rest
	(for consistency with SMT3)
Fatal Charm -> Fatal Attraction
Seraph Lore -> Seraphic Lore
Genocide -> Massacre
	(more accurate to the Japanese and less edgelordy)
Ragnarok -> Apocalypse
	(reduces confusion with Ragnarok being fire-element in other games, closer to original Japanese meaning "end of the world")
Feed Frenzy -> Feeding Frenzy
Ingest -> Swallow Whole
	(better conveys effect, also more accurate to Japanese)
Last Feast -> Last Supper
	(the Japanese is literally the same as the Biblical term, not sure why the localizers changed it)
Resolution -> Desperation
	(Japanese was "Desperate Resolution", better conveys effect)
Null Sleep -> Sleepwalker
	(to avoid confusion with other Null skills)
Retaliate -> Bite Back
Vengeance -> Swallow
	(closer to the Japanese and better conveys effect)
Horror -> Confuse
	(initially I thought this inflicted fear, this change ironically reduces confusion)

--------------------------------------
Combo skills:

Gang Blast -> Rumble Rush
	(more accurate to Japanese, also more accurate to component skills)
Cocytus (combo) -> Absolute Zero
	(to avoid confusion with the regular spell. Japanese for this is actually "Cocytus" while the Japanese for the Cocytus spell is "Frozen World", but I didn't want to change the spell name for consistency with DDS1.)
Landslide -> Rock Tomb
	(to avoid confusion with my renamed Avalanche, also Pokemon reference that conveys its debuff effect)
Millennia Curse -> Millennium Curse
Shot II -> Shot B
	(other RPGs conditioned me to think a number means an improved version)
Bolt Rain -> Infinite Thunder
	(accurate to Japanese, also sounds cooler)