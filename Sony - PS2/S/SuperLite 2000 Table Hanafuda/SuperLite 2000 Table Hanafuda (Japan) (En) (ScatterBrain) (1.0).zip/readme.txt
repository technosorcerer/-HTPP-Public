An English translation patch for "SuperLite 2000 Table Hanafuda" [SLPM-62487] PS2 game published by SUCCESS.

Patch file was created with Delta Patcher 3.1.5 and was tested with MD5: 4c0c84f0314c37af9d272f23c355d064 copy of the game.

Don't forget to make a backup of your game before patching!

If you experience any issues with the patch or notice any mistakes you can create an issue on GitHub https://github.com/ScatterdBrain/SuperLite-2000-Table-Hanafuda-PS2-English-Translation-Patch
or contact me on discord username: scatterdbrain

Check https://github.com/ScatterdBrain?tab=repositories for other stuff.