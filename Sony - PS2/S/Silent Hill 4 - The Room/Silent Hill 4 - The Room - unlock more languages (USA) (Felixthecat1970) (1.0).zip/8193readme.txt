PS2 Silent Hill 4: The Room SLPM-65574 (game version 1.3)
サイレントヒル４　ザ・ルーム 
Edition Original, Konami the Best, Konami Dendou Selection 

+Unlock multilang Spanish, Italian, Deutch, French, Korean, 
+enable sharp backbuffer less blurry and no dithering patch v1 for PCSX2 emu on PC (console untested)
By felixthecat1970

Seems developers lock langs maybe no time for debug, sales region, time release who knows?
the patch unlock the option for lang selection; unknow if looks ok in consoles so i did another patch for langs only (look github folder for CONSOLE patch)

sh4multilangCONSOLE.7z 
sh4multilangPCSX2-PC.7z (have sharp backbuffer enabled but unknow if work in consoles use above insted if error or bugs)

+Go to game options change the desired language in options
-some menus misaligned (lang option, save memory card)
-if using sh4PCSX2 patch some cutscenes subtitles will not show
-warning not fully tested.

verify your original dump filehash (Redump verified)
sha1:bbd59368c6c2d2c86267a1d7bf24e14cf339143a

rename your silent hill 4 ps2 .ISO dump with name: 
Silent Hill 4 - The Room (Japan) (En,Ja)

Go to:
https://github.com/felixthecat1970/gamepatches/tree/main/Playstation_2/Silent%20hill%204
