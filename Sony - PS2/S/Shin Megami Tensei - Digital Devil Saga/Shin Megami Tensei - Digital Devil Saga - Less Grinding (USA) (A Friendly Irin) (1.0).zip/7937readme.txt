--------------------------------------
Skill changes:

Null Ailment moved from Godly Spirit to Holy Leader
	-Lesser Null skills removed from Holy Leader, since they're no longer useful
Null Death moved from Evil God to Death
Null Expel moved from Evil God to Seraphim
Dekaja moved from Insane God to Evil God

--------------------------------------
Price changes:

General adjustments:
All mantras of price $50000   -> $35000 (except Outer God)
All mantras of price $100000  -> $50000
All mantras of price $150000  -> $75000
All mantras of price $250000  -> $100000
All mantras of price $300000  -> $150000
All mantras of price $350000  -> $150000
All mantras of price $500000  -> $250000
All mantras of price $600000  -> $300000
All mantras of price $1200000 -> $600000
All mantras of price $2000000 -> $1000000

Specific adjustments:
Holy Beast:				$50000   -> $40000
Godly Beast:			$300000  -> $250000
Wikipedia:				$600000  -> $400000
Dark Leader:			$700000  -> $400000
Dark Lord:				$1400000 -> $800000
Death Spirit:			$250000  -> $100000
Mitama:					$75000   -> $50000
Gyokuza:				$1500000 -> $600000