This is a cosmetic mod that changes some skill and mantra names to be more accurate to the original Japanese, clearer at conveying their mechanical effect, or just to sound nicer. A list of changes and reasoning are provided in this file.

--------------------------------------
Typo/mistranslation corrections:
	-Varna -> Varuna
	-Vayaviya -> Vayavya
	-Fierce Spirit -> Kishin
	-Raksas -> Rakshasa

--------------------------------------
Elemental mantras now have more consistent naming schemes. Except for Earth, they are now all:
	[Element] Spirit -> [Element] Demon -> Elemental -> (Unique) -> [Element] Master
	
Fire Spirit -> Fire Demon -> Salamander -> Fire Lord -> Fire Master
Ice Spirit -> Ice Demon -> Jack Frost -> Ice Wolf -> Ice Master
Wind Spirit -> Wind Demon -> Sylph -> Wind Waker -> Wind Master
	(yes it's a Zelda reference, sue me)
Bolt Spirit -> Bolt Demon -> Raiju -> Bolt Wizard -> Bolt Master
Earth Spirit -> Earth Shrine -> Gnome -> Earth Temple -> Earth Empire
	(it annoyed me that the upper Earth mantras broke the pattern of being places rather than titles)

--------------------------------------
Other mantras:

Wikipedia -> Abaddon
	(This one had to be a joke placeholder, right? I can't find the original Japanese so I'm just making something up for this one.)
Dark Leader -> Dark Wizard
	("Leader" is just really awkward in this context, sorry localizers)
Priestess -> Miko
	(for consistency with my DDS2 mod)
Thrones -> Throne
	(no idea why this was plural)
Evil Spirit -> Ghost
Dark Spirit -> Wraith
	(increasingly edgy adjectives prepended to "Spirit" just sounds dumb in English, sorry)
Death Spirit -> Psychopomp
	(I have no idea what this was supposed to mean, but it's confusing to have it on the healing branch, especially when there's already a "Death" mantra. I presume it's meant to mean "spirit with power over life and death", and this is the closest English has to that.)
Vicious God -> Messiah
	(I have no idea what "Vicious God" is supposed to mean or why it's on the healing branch of all things. Since this mantra gives Salvation, I decided to just double down on the Christianity theme.)
Adamant -> Atman
	(I assume this was a mistranslation, this fits with the ailment line's Buddhist theme)
Holy Leader -> Buddha
	(same)
Evil God -> Devil
	("Evil God" just sounds silly, sorry localizers)
Insane God -> Zealot
	(consistency with other SMT localizations)
Monotheist -> Polytheist
	(because it makes negative sense that mastering multiple elements makes you a "monotheist")
Godly Spirit -> Onmyo
	(I don't like the YHVH reference when this is one of the very few SMT games where he's not present, so I've changed it to reference *this* game's final boss instead. Bonus, it's a Hindu term, which is the cosmology used by DDS.)

--------------------------------------
Demon races:

Fiend -> Mystic
	(for consistency with my DDS2 mod; yes, this is the same as the Nether race in DDS2)
Demon -> Brute
Evil -> Icon
	(for consistency with DDS2)

--------------------------------------
Skills:

Closdi -> Mutudi
Avalanche -> Landslide
	(I associate "avalanche" soley with snowfall)
Vanity -> Madness
	(Japanese name is a reference to a nihilistic Buddhist saying meaning "all is vanity, form is emptiness", essentially saying existence is contradictory. Given two of the ailments inflicted are mental, I assume the idea is the spell drives you mad by revealing the meaninglessness of existence?)
Calm Death -> Eternal Rest
	(for consistency with SMT3)
Seraph Lore -> Seraphic Lore
Genocide -> Massacre
	(more accurate to the Japanese and less edgelordy)
Ragnarok -> Apocalypse
	(reduces confusion with Ragnarok being fire-element in other games, closer to original Japanese meaning "end of the world")
Feed Frenzy -> Feeding Frenzy
Ingest -> Swallow Whole
	(better conveys effect, also more accurate to Japanese)
Last Meal -> Last Supper
	(the Japanese is literally the same as the Biblical term, not sure why the localizers changed it)
Null Sleep -> Sleepwalker
	(to avoid confusion with other Null skills)

--------------------------------------
Combo skills:

Fimbulvet -> Niflheim
Titan -> Titanomachia
	(for consistency with DDS2)
Gang Blast -> Rumble Rush
	(more accurate to Japanese, also more accurate to component skills)
Millennia Curse -> Millennium Curse