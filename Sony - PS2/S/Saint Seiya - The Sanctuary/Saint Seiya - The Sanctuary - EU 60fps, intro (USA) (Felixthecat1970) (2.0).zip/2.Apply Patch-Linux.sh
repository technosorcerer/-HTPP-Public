#!/bin/sh
cd "$(cd "$(dirname "$0")" && pwd)"
mkdir ./output
chmod +x ./exec/xdelta3_x64_linux
echo Place the files to be patched in the \"original\" directory with the following names:
echo --------------------
echo "Saint Seiya - The Sanctuary (Europe) (En,Ja,Fr,De,Es,It).iso"
echo --------------------
echo Patched files will be in the \"output\" directory
read -p "Press enter to continue..." inp
./exec/xdelta3_x64_linux -v -d -s "./original/Saint Seiya - The Sanctuary (Europe) (En,Ja,Fr,De,Es,It).iso" "vcdiff/Saint Seiya - The Sanctuary (Europe) (En,Ja,Fr,De,Es,It).iso.vcdiff" "./output/Saint Seiya - The Sanctuary (Europe) (En,Ja,Fr,De,Es,It)-patched.iso"
