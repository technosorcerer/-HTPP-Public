PS2 Saint Seiya - The Sanctuary (Europe) (En,Ja,Fr,De,Es,It) SLES-53201 v2.0 (patch)

If you used:
-PS2 Saint Seiya - The Sanctuary (Europe) (En,Ja,Fr,De,Es,It) SLES-53201 v2 (patch)
patch has a bug (gameplay combos not connect)

Updated patch with next changes:
+unlock max 50fps for (story - battle intros)
+unlock all chara for versus gameplays
-remove old patch NTSC, video intro and 60fps due a bug (in gameplay you can’t make combos hits)


!!Warning!! patch modifies parameters shared by memory card saves if you using a save prgress, in test if you have already save , game take memory card save data by default (all character patch unlock will not work) before test or use make a bakup\copy of your save game for prevent undesired data loss like always patch have not guarantee use under you decision.

Saint Seiya - The Sanctuary (Europe)-patch(4.3).7z
(https://www.mediafire.com/file/bmwx101813v1h3j/Saint_Seiya_-_The_Sanctuary_%2528Europe%2529-patch%25284.3%2529.7z/file)

-patch not include intro, NTSC, 60fps -japanese version works ok,.. but japnaese only— because bug in gameplay (you can’t make combo hits), NTSC and 60fps codes for PCSX2 test are available in my github repo.

More info for saint seiya series improvements:
https://felixthecat1970.github.io/gamepatches-blog/blog/ps2/ps2-saint-seiya-series/