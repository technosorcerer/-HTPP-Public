Samurai Shodown Anthology - Hidden Characters Hack

Improvement in Samurai Shodown:
-Enable Amakusa as a selectable character.

Improvement in Samurai Shodown II:
-Enable Kuroko & Mizuki as selectable characters.

Improvement in Samurai Shodown III:
-Enable Zankuro & Kuroko as selectable characters.

Improvement in Samurai Shodown IV:
-Enable Zankuro as a selectable character.

Improvement in Samurai Shodown V:
-Enable Yumeji, Sankuro, Poppy & Gaoh as selectable characters.

The patch can be applied to the iso file through the program Delta Patcher which can be found in this site.

==============
Special thanks
==============
Special thanks to the original creators of these hacks.
Unfortunately I do not know their names, but the credit is for all of them.
The hacks presented in this patch are partially based on their work.
==============================
John-Paul from www.Emudesc.com
==============================
   Twitter: @Juan_Pablo_81
==============================