ABOUT
-----------------------------------------------------------------------
This is a translation patch for the Sega Saturn Version of Cotton 2
by Success. The patch will translate the entire text of the game to
English. This patch is distributed under CC BY-NC, please read the
included license.txt if you plan to distribute this patch. Please
note that this license explicitly forbids commercial use.

This patch is published as delta patch. Distributing pre-patched ISOs 
may be illegal and is not endorsed by the original creator.

This patch was originally distributed on segaxtreme.net. Visit the
site to find new versions or read about the hacking process if you're 
interested.

Instructions
-----------------------------------------------------------------------
To use this patch you need a rip of the game. Once you obtained a
valid rip. Use KnightOfDragons Sega Saturn Patcher V1.2 (or later) to
apply the patch. It can be found here:

https://segaxtreme.net/resources/sega-saturn-patcher.73/

Follow the instructions that come with the patcher.


CREDITS
-----------------------------------------------------------------------

Translation & Hacking
nanashi

Proofreading / Editing
Katrin
Danthrax

Special thanks to KnightOfDragon for programming the patcher