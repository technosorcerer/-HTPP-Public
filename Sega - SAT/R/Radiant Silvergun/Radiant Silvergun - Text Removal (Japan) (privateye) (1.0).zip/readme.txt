***************************
*    Radiant Silvergun    *
*  Text Removal Hack v1.0 *
***************************

=======================
 1. Introduction
=======================
This is a hack for Radiant Silvergun on Sega Saturn which stops "PRESS START BUTTON" and "PLEASE WAIT" from appearing during gameplay, thus making it behave like the PC / Switch / Xbox 360 ports. 

Due to the basic nature of this hack, it also removes "PRESS START BUTTON" from the title screen and attract demo.

=======================
 2. Patch Instructions
=======================
The patches are in xdelta format and have been tested with the following utilities:
 * Delta Patcher - https://www.romhacking.net/utilities/704/
 * Web Patcher   - https://hack64.net/tools/patcher.php
 
This disc image from the Redump set is required: 
 http://redump.org/disc/5158/

Before proceeding, it is highly recommended to apply Radiant Silvergun EXTRA to the aforementioned disc image. The patch can be obtained here:
 http://daifukkat.su/hacks/rsg_ex/

The following instructions are for Delta Patcher but the same general process applies to all patch utilities:
 1. Open Delta Patcher and click the folder icon next to the "Original file" box.
 2. Browse to the disc image folder and select: 
     * Radiant Silvergun       -> Radiant Silvergun (Japan) (Track 01).bin
     * Radiant Silvergun EXTRA -> RSG_EX_SAT.bin
 3. Click the folder icon next to the "XDelta patch" box.
 4. Browse to the patch folder and select:
     * Radiant Silvergun       -> Patch (Vanilla).xdelta
     * Radiant Silvergun EXTRA -> Patch (EX v1.0).xdelta
 5. Click the "Apply patch" button.
 6. "Patch successfully applied!" prompt should appear. If not, repeat the process and make sure that you are patching the correct disc image.
 7. The patch has now been applied and is ready to play!
 
=======================
 3. Cheat Codes
=======================
To remove text without applying the patch, use the following cheat codes:

+---------------------------------------------------------+
|                       Master Code                       |
|                      F6000914 C305                      |
|                      B6002800 0000                      |
+---------------------------------------------------------+
|                       Enable Code                       |
|                      D6076DFA 0000                      |
+--------------------+---------------+--------------------+
| INSERT COIN(S) [*] |  PLEASE WAIT  | PRESS START BUTTON |
+--------------------+---------------+--------------------+
|   160648E4 2020    | 160648BC 2020 |   160648F6 2020    |
|   160648E6 2020    | 160648BE 2020 |   160648F8 2020    |
|   160648EA 2020    | 160648C0 2020 |   160648FC 2020    |
|   160648EC 2020    | 160648C4 2020 |   160648FE 2020    |
|   160648EE 2020    | 360648C3 0020 |   16064902 2020    |
|   360648E3 0020    | 360648C6 0020 |   16064904 2020    |
|   360648E8 0020    |               |   360648F5 0020    |
|   360648F0 0020    |               |   360648FB 0020    |
|                    |               |   36064901 0020    |
|                    |               |   36064906 0020    |
+--------------------+---------------+--------------------+
| [*] Arcade mode only                                    |           
+---------------------------------------------------------+                                    

It is recommended to only use the cheat codes that remove "PRESS START BUTTON", for a few reasons:
 * INSERT COIN(S) only appears in Arcade mode when zero credits are remaining; once a credit is added by pressing the left shoulder button, it disappears.
 * PLEASE WAIT only appears during very brief periods when you're not in control (e.g. while loading the next stage)
 
Enable Code is not mandatory but the text only needs to be removed once, so it improves efficiency by controlling the main codes like so:
 * While player one's score is zero at game startup, erase the text from High Work RAM.
 * Once player one's score is greater than zero, stop erasing the text.

For cheat codes and a save file that replicates Training Mode from the PC / Switch / Xbox 360 ports, visit this link:
 https://segaxtreme.net/threads/radiant-silvergun-training-mode-in-saturn-version.25462

=======================
 4. Technical Details
=======================
The aforementioned text strings are stored as ASCII in SS\GAME.BIN so this hack simply blanks them out. A more sophisticated hack would possibly modify or disable the function(s) that display these strings during gameplay and hence would keep "PRESS START BUTTON" in the title screen and attract demo... but that's more work for very little gain so I didn't contemplate that.

INSERT COIN(S) appears in Arcade mode but removing this string results in a blank space where it sits in the main menu, and it's not worth the ugliness because it only appears when zero credits are remaining; once a credit is added by pressing the left shoulder button, it disappears.

An identical copy of GAME.BIN can be found in the STV (i.e. Sega Titan Video) folder. Based on some very quick testing, it seems like this file is unused and SS\GAME.BIN is loaded for both Arcade and Saturn modes but, for the sake of completeness, STV\GAME.BIN is also patched.
  
Since these strings are loaded into High Work RAM at game startup and subsequently referenced from there, they can also be removed with the cheat codes listed in section 3.

=======================
 5. Credits
=======================
privateye - Created the hack and cheat codes.
 * SegaXtreme - https://segaxtreme.net/members/privateye.20804
 * YouTube    - https://www.youtube.com/privateye
