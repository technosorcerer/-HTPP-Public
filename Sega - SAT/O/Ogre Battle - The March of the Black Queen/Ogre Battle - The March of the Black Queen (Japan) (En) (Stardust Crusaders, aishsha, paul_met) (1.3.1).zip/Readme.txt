﻿====================Ogre Battle=====================
================The March of the Black Queen========
=======================v1.3.1=========================
Genre: RPG

Source language: Japanese

Platform: Sega Saturn

Patch language: English

Author: paul_met/Pennywise/aishsha

E-mail:	paul294met@gmail.com
	http://meduza-team.ucoz.net
        aishsha@gmail.com
        aishsha@blogspot.com
	http://yojimbo.eludevisibility.org/
 
======================================================
Background
======================================================
This is a complete English patch for the Sega Saturn port
of Ogre Battle. The technical details are as follows:

- Support for VWF.
- Support for 1-byte character encoding.
- Support for DTE.
- Colors support for the main font.
- Background translucency support for most windows.
- If the character has equipped an artifact, then the changed stats are highlighted in color.
- Replacing standard shouts with better ones from the PS1 version of the game ("Fight It Out", "Lucky" etc.).
- Changed the voice of the narrator in the opening story scene to female (from the PS1 version of the game).
- Support for difficulty levels (selected before starting the game).
- Flat level map by default.


The project was supposed to be a fast and easy retranslation at its
onset, but it eventually transformed into something more.
The PS1 script has been ported over to this translation, but later
it was heavily redone, with most of it taken from the scratch due
to inconsistency, lack of details and sometimes apparent laziness
of the official translation. We tried making it as close to the official
canon as possible (by taking the PSP lore version as the basis).
The script has been reviewed for accuracy and edited accordingly.
Another small note is that this is one of those games that fell
victim to extreme religious purge to fit it with a younger audience
or whatever. The final translation uses the exact lore that was
originally meant by the developers since we tried and did
bring it back to the roots, so to say. Also, the text of additional
scenarios was completely translated.

The Saturn version of the game has mini map, additional scenarios, musical
compositions, characters, endings etc.

More information on that can be found here:
https://kahran042.livejournal.com/57736.html

*Addition to the article at the link above:
To get to the secret location, you must enter the name of the hero as "TSARGEM".


Please note that the game currently has emulation issues
on Mednafen that results some backgrounds are shifted to the left.
These issues are not present on the original hardware.

=====================================================
Patching Instructions
=====================================================
1. Copy all the patch files into a folder containing the
   original multi-track game image in the "Bin/Cue" format!
2. Launch the "START.BAT" file.
3. To make things safer, the original data track is saved
   in the same folder (with the "old" extension). You may
   further delete after successful patching.
4. All the patch files are automatically deleted at the
   end of the patching process!
---------------------------------------------------
The original image should be equivalent to the one found here:
http://redump.org/disc/8687

======================================================
Credits
======================================================
paul_met - initiator, coordinator, hacker and designer

Pennywise - testing, editing, coordinating

aishsha - translation review and retranslation, hardware testing

Ryusui - spot translations

=======================================================
Changes in version 1.1
----------------------
- Added the ability to skip the difficulty selection menu (hold the "A" or "B" buttons respectively on the Sega Saturn logo screen);
- Fixed "black screen" after saving in battle;
- Default flat map mode when loading a save in battle;
- Formatted text in the shop dialog;
- Fixed line wrapping in the current squad window (movement type);
- Expanded the window with the list of recruits in cities;
- Fixed incorrectly displayed character names;

=======================================================

Changes in version 1.2
----------------------
- Fixed a bug with displaying text in the info window when creating a new squad;
- Changed the name of the sword "Karanborg" to "Caladbolg";
- Formatted text in some dialogue;

=======================================================

Changes in version 1.3
----------------------
- Support for non-classic controllers (3D Control Pad or Retro-bit Pad) in the game difficulty selection menu.

=======================================================
Compiled by paul_met. June 2022.
