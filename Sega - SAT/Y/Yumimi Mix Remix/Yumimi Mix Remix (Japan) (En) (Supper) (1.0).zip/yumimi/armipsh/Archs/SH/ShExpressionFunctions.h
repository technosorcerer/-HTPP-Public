#pragma once

extern const ExpressionFunctionMap shExpressionFunctions;
