#ifndef ENDIANNESSTYPE_H
#define ENDIANNESSTYPE_H


namespace BlackT {


namespace EndiannessTypes {
  enum EndiannessType {
    little = 0,
    big
  };
};


};


#endif 
