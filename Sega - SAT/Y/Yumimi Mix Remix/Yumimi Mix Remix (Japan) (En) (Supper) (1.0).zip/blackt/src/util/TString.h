#ifndef TSTRING_H
#define TSTRING_H


#include <string>

namespace BlackT {


typedef std::string TString;


};


#endif
