#ifndef SIGNEDNESSTYPE_H
#define SIGNEDNESSTYPE_H


namespace BlackT {


namespace SignednessTypes {
  enum SignednessType {
    nosign = 0,
    sign = 1
  };
};


};


#endif 
