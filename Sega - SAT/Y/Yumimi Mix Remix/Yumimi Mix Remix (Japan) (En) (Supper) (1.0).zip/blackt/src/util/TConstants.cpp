#include "util/TConstants.h"

namespace BlackT {


const double TConstants::pi = 3.14159265358979323846264338328;


}
