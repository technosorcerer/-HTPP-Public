#ifndef TCONSTANTS_H
#define TCONSTANTS_H


namespace BlackT {


class TConstants {
public:
  const static double pi;
protected:
  
};


}


#endif
