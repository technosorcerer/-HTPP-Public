#ifndef TSORT_H
#define TSORT_H


#include <string>
//#include "util/TFileInfo.h"

namespace BlackT {


  class TSort {
  public:
//    static bool sortFileInfoByIso9660Name(
//                                  const std::string& first,
//                                  const std::string& second);
  protected:
    
  };


}


#endif
