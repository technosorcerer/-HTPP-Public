#include "ymm/YmmTranslationData.h"

using namespace BlackT;

namespace Md {


YmmTranslationData::YmmTranslationData()
  : doTranslationModifications(false) { }


}
