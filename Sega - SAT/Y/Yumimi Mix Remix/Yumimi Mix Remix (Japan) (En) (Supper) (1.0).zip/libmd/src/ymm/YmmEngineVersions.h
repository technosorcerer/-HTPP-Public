#ifndef YMM_ENGINE_VERSIONS_H
#define YMM_ENGINE_VERSIONS_H


namespace Md {


namespace YmmEngineVersions {
  enum YmmEngineVersion {
    mcd,
    sat
  };
}


}


#endif
