#ifndef YMMSUBTITLERESOURCES_H
#define YMMSUBTITLERESOURCES_H


#include "util/TStream.h"
#include "util/TBitmapFont.h"
#include <vector>
#include <string>

namespace Md {


class YmmSubtitleResources {
public:
  YmmSubtitleResources();
  
  BlackT::TBitmapFont font;
protected:
  
};


}


#endif
