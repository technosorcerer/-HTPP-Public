#ifndef DISCASTERCDIMAGE_H
#define DISCASTERCDIMAGE_H


#include "discaster/Object.h"

namespace Discaster {


  class CdImage : public BlobObject {
  public:
    CdImage();
  };


}


#endif
