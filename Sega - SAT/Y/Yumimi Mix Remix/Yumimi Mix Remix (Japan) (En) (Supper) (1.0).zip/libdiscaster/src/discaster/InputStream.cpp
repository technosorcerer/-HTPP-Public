#include "discaster/InputStream.h"

namespace Discaster {


  InputStream::InputStream() { }
  InputStream::~InputStream() { }


} 
