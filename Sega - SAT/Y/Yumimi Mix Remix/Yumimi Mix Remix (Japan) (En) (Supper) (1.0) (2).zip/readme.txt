﻿********************************************************************************
*                               Yumimi Mix Remix                               *
*                          English Translation Patch                           *
*                              v1.0 (06 Apr 2022)                              *
*                                                                              *
*                               Supper -- Hacking and Translation              *
*                               cccmar -- Testing                              *
********************************************************************************

In a town somewhere in Japan, there once lived a very average high school girl 
named Yumimi. Together with her best friend Sakurako and friend-cum-crush 
Shinichi, she enjoyed happy if very average days…until one fateful morning when, 
on the way to school, she witnesses a procession of ghosts(?) crossing the 
street before her very eyes! And then in the hallway, a girl suddenly latches on 
to her, tells her she has to "go stitch the holes", and – declares her love for 
her!? Suddenly, Yumimi's life isn't so average anymore, though she may soon be 
wishing it was…

Yumimi Mix Remix is a 1995 adventure game for the Sega Saturn. A direct port of 
the 1993 Mega-CD game Yumimi Mix, it was created in a collaboration between 
developer Game Arts (of Lunar and Grandia fame) and well-known shoujo manga 
artist Izumi Takemoto, who wrote and storyboarded the entire game. A happy 
marriage of Game Arts' technical skill with Takemoto's cute, whimsical artistry 
and inimitably eccentric sensibilities, the game is comprised entirely of 
fully-animated, fully-voiced, full-screen cutscenes coupled with periodic 
multiple-choice prompts, creating an experience almost exactly like watching an 
anime while still making full use of the interactivity afforded by the game 
medium.

This patch fully translates the game into English, subtitling all dialogue, 
songs, and important background text in the manner of a typical subtitled anime. 
It also adds new in-game options to show or hide Japanese honorifics, to 
partially or completely disable the subtitles, and to allow unimportant scenes 
to be skipped during gameplay.

                    ****************************************
                    *          Table of Contents           *
                    ****************************************

  I.    Patching Instructions
  II.   How to Play
  III.  Translation Options
  IV.   Translation Notes
  V.    Additional Notes
  VI.   Author's Comments
  VII.  Special Thanks
  VIII. Version History

                    ****************************************
                    *       I. Patching Instructions       *
                    ****************************************

To use this translation, you'll need to apply a patch to a disc image of the 
game. Unfortunately, patching disc images is inherently complicated because 
there are numerous CD image formats in use, as well as many ways that 
poorly-written disc ripping programs can mess things up and make a patch not 
work properly. As a result, this is a rather long section – sorry! But please 
read it over carefully before complaining that the patch doesn't work.

Just to be clear: this patching process is designed to support every disc image 
format it reasonably can. Though a Redump-verified disc image is a definite 
plus, options are provided to patch pretty much any image so long as it has the 
correct data track. If you don't have a Redump image, just go ahead and try to 
patch whatever you have using whichever of the options below applies to it.

Now then, here are your options for patching, approximately ordered from best to 
worst:

  A. Directly patch a single-file Redump-verified BIN or IMG image
  B. Directly patch a multi-track Redump-verified BIN image
  C. Automatically patch a BIN or IMG image via binpatch.bat
  D. Automatically patch an ISO+WAV+CUE image via isopatch.bat
  E. Manually patch

These options are explained in the subsections that follow.

IMPORTANT: If you downloaded this patch from Romhacking.net, only options C, D, 
and E are available. Due to restrictions on upload size, it's not possible to 
host the full-disc xdelta patch on that site, so only the ISO-based patching 
options are included. If at all possible, please download this patch from the 
web page specifically set up for it instead in order to have access to all 
patching options: http://stargood.org/trans/yumimi.php

POSSIBLY IMPORTANT: This translation does not patch the game's region coding 
data. This is only relevant if you're going to play the game on real, 
non-Japanese Saturn hardware using a setup that doesn't include some sort of 
region bypass, as the Saturn BIOS will reject discs that don't match the 
console's region. If this is an issue, then after applying the translation 
patch, you can use external tools to modify the region data so the BIOS will 
accept it. Though I haven't tried it personally, Saturn Region Patcher will 
supposedly do the job: 
https://segaxtreme.net/resources/saturn-region-patcher.81/

  -------------------
  - BEFORE STARTING -
  -------------------

It should go without saying, but first, extract all the contents of the 
translation patch's ZIP to your hard drive if you haven't already.

Before you start, you'll need to determine what format your disc image is in. At 
the very least, you must have an image in BIN+CUE, IMG+CUE, or ISO+WAV+CUE 
format; more exotic formats are not supported. It's unfortunately not uncommon 
to come across disc images that don't use the standard file extensions used in 
this section, or use them differently from normal, which makes things very 
confusing. Some tips:

  - One common way of distributing disc images is the "dual CCD/CUE" format. 
This consists of four files: a CCD, a CUE, an IMG (or possibly BIN), and a SUB. 
If your image is like this, you can throw away the CCD and SUB files, as they 
aren't needed for the patch. For our purposes, an IMG is the same as a BIN, so 
any references to a "BIN" below can also refer to an "IMG" or vice versa.
  
  - If your disc image has a CCD but no CUE, you may be able to patch it with 
method A. If that fails, you'll need to look into creating or obtaining a CUE 
file for the disc.
  
  - If your disc image consists of a CUE and a large number of BIN files, it's 
in the "split BIN" format. This format is particularly used by the distributions 
available on certain archival web sites. It's possible to patch this format as 
long as the BIN files represent one of the Redump disc images, just split up 
into its component tracks.
  
  - You're not likely to see them much these days, but old, lossy formats like 
ISO+MP3 are not supported.

  --------------------------------------------------------------------
  - A. Directly patch a single-file Redump-verified BIN or IMG image -
  --------------------------------------------------------------------
  
Use this method if at all possible. While not as simple as the auto-patching 
method described later, it gives the most reliable results.

You can patch using this method if your disc image *exactly* matches the 
verified "good" image as listed on Redump.org, and if all the tracks on the disc 
are combined into one single BIN or IMG file.

First, check that your disc image contains a single file with the extension 
".bin" or ".img". If it does, verify that that file matches one of the following 
specifications. (If you don't know how to do that, just go ahead and follow the 
steps listed below; if you get an error, your disc image is wrong.)

  Redump name: Yumimi Mix Remix
  CRC32:       8c291ee5
  MD5:         d8661e29c0b882afc09f8c9fb42b06ab
  SHA-1:       77793fe43f10ccb19a724e78d16ac4fdb7c711b3

Consult redump.org for full details: http://redump.org/disc/43000/

If your disc image is a match, all you need to do is apply an xdelta patch to 
the BIN or IMG file, then rename it and pair it with the CUE file provided in 
the download.

  1. Extract the "redump_patch" folder from the translation ZIP and open it.
  
  2. Run "DeltaPatcher.exe", which should be present in that folder. This is the 
popular Delta Patcher program for applying xdelta patches. If you're not using 
Windows, you'll need to obtain an alternate patching program for your system, 
such as the command-line "xdelta3" program.
  
  3. Locate the .xdelta patch file in the "redump_patch" folder.
  
  4. Use Delta Patcher (or another xdelta patching tool) to apply the patch to 
the BIN or IMG file. If you get an error, you'll need to try one of the other 
patching methods below.
  
  5. If your disc image came with a CCD or CUE file, delete it now.
     DO NOT USE THE OLD CCD OR CUE FILE WITH THE PATCHED IMAGE!
     Also get rid of any SUB file if it exists. It's not needed.
     
  6. The "redump_patch" directory should contain a CUE file with a name like 
"Yumimi Mix Remix EN [v1.0] Redump.cue". Rename your patched disc image so it 
has *exactly* the same name as the CUE, except with a .bin extension instead of 
.cue.
     IMPORTANT: If the file you patched was originally an IMG file, make sure 
that you change the extension to .bin. The CUE will not work if the extension is 
.img.
     
  7. You're done! Make sure you have the CUE and BIN in the same directory, then 
open the CUE in an emulator. Or burn it to a CD and play on your appropriately 
modified Saturn (though see the earlier note about patching the region coding), 
or use whatever other wacky solution you've got for playing custom Saturn games 
on real hardware.

  -------------------------------------------------------------
  - B. Directly patch a multi-track Redump-verified BIN image -
  -------------------------------------------------------------
  
  One common distribution of the game found on certain archival sites uses the 
Redump-verified disc image, but splits it up into separate tracks instead of 
combining them into a single file. This is easily recognized by the presence of 
4 separate BIN files and a single CUE.
  
  Before patching:
  
  - Make sure that your disc's CUE file has a name like "Yumimi Mix Remix 
(Japan).cue".
  
  - Make sure that the BIN files are named like this:
      Yumimi Mix Remix (Japan) (Track 1).bin
      Yumimi Mix Remix (Japan) (Track 2).bin
      …
      Yumimi Mix Remix (Japan) (Track 4).bin
  
  To patch:
  
  1. Copy the CUE file and all BIN files into the "splitbin_patch" directory.
  
  2. Drag-and-drop the CUE file onto "binpatch.bat".
  
  3. If all goes well, this should produce a new, single-track format disc image 
in the same directory. (This works by simply combining all the tracks together 
and then applying the same patch as in method A.)
     
  4. Use the CUE file in the "splitbin_patch" directory to play the game.

  --------------------------------------------------------------
  - C. Automatically patch a BIN or IMG image via binpatch.bat -
  --------------------------------------------------------------

If your disc doesn't match the Redump image, or you otherwise couldn't get 
method A to work, it may still be possible to patch it. If your disc is in 
BIN+CUE format or IMG+CUE format, and you're using Windows:

  1. Make sure that your BIN/IMG and CUE have the same base name (e.g. 
"yumimi.bin" and "yumimi.cue", or "yumimi.img" and "yumimi.cue"). Note that if 
you rename the BIN file, you will need to open your CUE in a text editor and 
make the same change to any occurrences of the name inside the file.
  
  2. Copy both the BIN/IMG and CUE into the "auto_patch" directory.
  
  3. Drag-and-drop the BIN/IMG file onto "binpatch.bat".
  
  4. If all goes well, this should produce an ISO+WAV+CUE format disc image in 
the same directory.

  ----------------------------------------------------------------
  - D. Automatically patch an ISO+WAV+CUE image via isopatch.bat -
  ----------------------------------------------------------------

If your disc image is already in ISO+WAV+CUE format, you can perform a procedure 
similar to patching via binpatch.bat:
  
  1. Copy all the disc image files to the "auto_patch" directory.
  
  2. Drag-and-drop track 2 of your image onto "isopatch.bat".
  
  3. If all goes well, this should produce an ISO+WAV+CUE format disc image in 
the same directory.

  ---------------------
  - E. Manually patch -
  ---------------------

You can also attempt to apply the xdelta patches in the "auto_patch" directory 
to the ISO of an ISO+WAV+CUE image manually. Pretty much the only reason to do 
this is if you're on Linux and can't or won't use Wine. If that's the case, then 
presumably you're smart enough to handle it yourself, so you're on your own 
here.

                    ****************************************
                    *            II. How to Play           *
                    ****************************************

While I wish I'd been able to translate the game manual's own explanation of how 
to play, as it consists of a combination of gorgeous full-color comics by Izumi 
Takemoto and amusing dialogue from the game characters, I unfortunately only 
have access to the manuals for the Mega-CD and PC versions, and it'd be pretty 
silly to include either of those with a translation for a completely different 
platform. I'm afraid you'll instead have to make do with this much shorter and 
less personality-filled overview I wrote loosely based on the other manuals.

Honestly, though, the only things you really need to know are that you can save 
by pressing B at dialogue prompts and access the translation options menu by 
pressing Start pretty much any other time. It's a very simple game to play, and 
everything else should be obvious.

  @~~~~~~~~~~@
  | Overview |
  @~~~~~~~~~~@
  
  Yumimi Mix is a "command selection" (multiple-choice) adventure game. As the 
story progresses, you'll periodically be prompted to make choices that will 
affect how it develops.

  @~~~~~~~~~~@
  | Controls |
  @~~~~~~~~~~@
  
  START BUTTON    Used to skip the opening scene and to pause.
                  In this translation, pausing brings up a menu with
                  additional options – see the "Translation Options" section.

  D-PAD           Used when selecting commands.
  
  A/C BUTTONS     Used to confirm commands, and can be used to skip scenes in
                  Replay Mode (or in normal gameplay if scene skip has been
                  enabled – see the "Translation Options" section).
                  
  B BUTTON        Cancels commands, and accesses the Save/Load menu when
                  making choices during gameplay.
  
  Other buttons are not used.
  
  This game also supports the Shuttle Mouse peripheral; it can be used in place 
of a standard Control Pad for both regular gameplay and the Yumimi Puzzle bonus 
game.
  
  Also note that in most situations, pressing and holding the A, B, C, and Start 
Buttons simultaneously will perform a soft reset. During normal gameplay, this 
will reset the game to the introductory scene; otherwise, it will return to the 
console's Multiplayer.

  @~~~~~~~~~~~~~~~~~~~~@
  | Saving and Loading |
  @~~~~~~~~~~~~~~~~~~~~@
  
  The game can be saved by pressing the B Button at choice prompts during 
regular gameplay. Up to five save files can be saved to the Saturn's internal 
backup memory; if a RAM cartridge is inserted, an additional five files can also 
be saved to it (select between the internal memory and the cartridge using the 
"Internal"/"Cartridge" option at the lower-right of the file selection menu).
  
  Saved games can be loaded from the main menu, or during gameplay using the B 
Button menu described above. Saved games can also be used in the Replay mode 
(see below).
  
  If there isn't enough free space available to save the game, a warning screen 
will appear on startup. It's still possible to play in this situation, but 
saving and loading will be disabled.

  @~~~~~~~~~~~~~@
  | Replay Mode |
  @~~~~~~~~~~~~~@
  
  Replay Mode, accessible from the main menu when save game data exists, allows 
previously saved files to be rewatched exactly as they occurred, with events 
playing out automatically based on the player's previous choices during the 
game. In this mode, most scenes can be skipped by pressing the A or C Button 
(exactly like when the "Allow Scene Skip" option is enabled in the Translation 
Options menu). However, scenes in which the player would normally have to make a 
choice cannot be skipped and must be watched in full (even though the choice 
will be made automatically in this mode).
  
  Once the entire file has been replayed up to the point where it was saved, 
standard gameplay resumes, with the player once again prompted to make choices 
as they come up.

  @~~~~~~~~~~~~~~~@
  | Yumimi Puzzle |
  @~~~~~~~~~~~~~~~@
  
  As a bonus, Yumimi Mix Remix contains a new minigame not in previous versions 
of the game, "Yumimi Puzzle". It can be accessed by selecting "Bonus" at the 
main menu.
  
  As this isn't an official manual, I can readily inform you that this game is a 
clone of the popular tile-matching/"mahjong" (but not really) game "Shanghai", 
with Yumimi-themed bonus pictures. Pair up the tiles at the top of the stack one 
by one until they're all eliminated. Question mark tiles are wildcards that can 
be paired with any other tile, but make sure you don't accidentally get rid of a 
tile you need to finish the puzzle! If you do, select "Retry" to start over.
  
  In total, there are 40 stages of increasing difficulty. There's a special 
bonus for clearing them all, so try to make it to the end!
  
  As an aside, a few of the bonus pictures in this mode have Japanese text in 
the background. This has been deliberately left untranslated for aesthetic 
consistency with the main game.

                    ****************************************
                    *       III. Translation Options       *
                    ****************************************

In an attempt to please everyone, or at least displease somewhat fewer people, 
this translation adds a new options menu to the pause screen that provides the 
ability to toggle several features, mostly translation-related. Access it by 
pressing the Start Button at any time during gameplay *except* when a choice 
prompt is being displayed. (You might have to hold the button down a second for 
it to take; the game's input handling can be a bit dodgy.)

Here is an explanation of each option:

  -- HONORIFICS --
  
  By default, the subtitles will include Japanese honorifics: -san, -chan, you 
probably know the deal. Since I'm aware not everyone is fond of this, I've 
provided the option to disable it.
  
  This setting affects only two things:
  
  1. When ON, honorific suffixes are present; when OFF, they're omitted 
("Yumimi-chan" -> "Yumimi") or replaced ("Kojima-sensei" -> "Mr. Kojima"). It 
would probably also affect familial terms of address like "nee-san", except it 
so happens that this game doesn't actually have any.
  
  2. When ON, Japanese names are presented using Japanese name order (last name 
before first name, e.g. "Yoshizawa Yumimi" instead of "Yumimi Yoshizawa"). This 
is because the name order is intrinsically tied to honorifics: "Morishita 
Rie-chan" is not the same as "Rie Morishita-chan". When set to OFF, the standard 
Western order is used.
  
  Nothing else is changed by this option. Particularly, I would like to note 
that disabling honorifics does not "Westernize" the names by which characters 
call each other. Yumimi refers to Shinichi as "Matsuzaki-kun" when honorifics 
are on and just "Matsuzaki" when they're off – never "Shinichi", even though 
we'd expect two students in a typical Western country to call each other by 
their first names. Some professional translations attempt to adapt the material 
in this way; personally, I find the effect incredibly jarring.

  -- SUBTITLES --
  
  Sets whether dialogue subtitles (anything that appears at the bottom of the 
screen) are displayed.

  -- SIGNS/KARAOKE --
  
  Sets whether subtitles for on-screen text are displayed, as well as whether 
lyrics for musical sequences are shown – in other words, anything that appears 
at the top of the screen.
  
  Note that not all visible text is subtitled, only that which is prominent or 
relevant to the plot.
  
  -- ALLOW SCENE SKIP --
  
  As explained in the menu itself, setting this to ON makes it possible to skip 
scenes during regular gameplay by pressing the A or C Button during scenes that 
don't contain a choice prompt. In the original game, this was only possible in 
Replay mode (and is always possible in that mode regardless of this setting). 
This defaults to OFF so people who didn't read this readme – surely that's no 
one!? – won't accidentally miss scenes by hitting the button at the wrong time.
  
  As an aside, this was added to the game in part because the original Mega-CD 
version had a cheat code to skip scenes which was unfortunately not carried over 
to the Saturn version. That cheat had some strange issues with certain scenes 
disabling it permanently until the save file was reloaded, though, so this is a 
much cleaner alternative.

                    ****************************************
                    *        IV. Translation Notes         *
                    ****************************************
  
As you'll quickly notice, this translation does not attempt to localize the 
game's many references to Japanese culture, pop culture, Japanese pop culture, 
obscure Nordic cities, etc. etc. etc. Why not? Well, I think it's a distinct 
part of the game's identity, and I have no interest in trying to paint over it.

Giving full explanations of every reference the game makes would fill a book, 
but in the interest of time (mostly my own), I've settled for doing a quick 
rundown of the most esoteric or Japan-specific ones here.

I'd like to note my boundless gratitude to 司書 for creating a page specifically 
detailing most of these references as well as many more, saving me hours of 
trying to track down obscure references to 50-year-old Japanese TV shows and 
jazz bands. If you want more detailed information and can handle Japanese one 
way or another, check it out!: http://zattalib.yu-nagi.com/game/Takemoto.html
  
  *** Aoi-chan Panic!
  
    A 1983 manga by Izumi Takemoto. One of his best-known works, and one of 
those considered most representative of his overall style, this is the origin of 
"Tooktoop", the "Tombinai Fish", the term "Punyoomkin", etc.
  
  *** Keseran-Pasaran
  
    Also known as "Kesaran-Pasaran". A Japanese cryptid described as a small 
white fluff ball that is "said to float down from the sky and bring good luck to 
whoever finds it".
  
  *** Saburou Kitajima
  
    A famous Japanese enka singer. Quoth Wikipedia: "He is very popular in Japan 
partly due to his looks of a physical laborer, and he mostly sings in the spirit 
of Japan's working class and rural laborers."
  
  *** The Crazy Cats
  
    A Japanese jazz band and comedy group formed in 1955. Broke up in 1993, 
which was coincidentally the year of this game's release.
  
  *** The Drifters
  
    A Japanese rock band and comedy group formed around 1956, famed for their 
variety show appearances.
  
  *** That song about the moon
  
    The traditional Japanese song "Tsuki" (Moon). If you go looking, you'll find 
some considerably higher-effort translations of this song that attempt to 
produce singable lyrics, but as I have no interest in that, I opted for 
something more to-the-point.
  
  *** UNICORN/Dancing Turtle Yapushi
  
    UNICORN (flip a coin to decide whether their name should be all-caps or not) 
is a Japanese rock band formed in 1986. They released an album in 1990 entitled 
"Odoru Kame Yapushi" (Dancing Turtle Yapushi). Coincidentally, like the Crazy 
Cats, they broke up the year this game was released.
    
  *** "The Super Girl"
  
    "Choushoujo Asuka", a 1975 manga.
  
  *** "the wolf girls"
  
    The almost-certainly-fabricated "real-life" story of Amala and Kamala, two 
Indian girls supposedly raised by wolves who were claimed to have developed 
various wolf-like physical traits.
  
  *** "the Masked Beauty"
  
    "Bishoujo Kamen Poitrine", a 1990 tokusatsu series. It's said to have been 
an influence on Sailor Moon, and on the off chance you're familiar with the 
Galaxy Fraulein Yuna series, the "Ojousama Kamen Polylina" is a very obvious 
parody of this.
  
  *** "Pokopokopokodama"
  
    "Henshin! Ponpokodama", a 1973 TV drama.
  
  *** Piggyback Ghost
  
    "Onbu Obake", a 1955 movie and 1972-1973 anime series.
  
  *** Tyltyl and Mytyl
  
    The main characters of the 1908 play "The Blue Bird" by Maurice Maeterlinck. 
The play was adapted into an anime series with character designs by Leiji 
Matsumoto in 1980, which is probably how the reference to it in this game came 
about.
  
  *** Borlänge
  
    A city in Sweden. It's not a transcription error, I swear.
  
  *** "Itagaki may die, but liberty never"
  
    A famed quote from Japanese politician Itagaki Taisuke following an 1882 
assassination attempt. In the way of famed quotes, he may not have actually said 
it.
  
  *** That song about miso sesame and tea jars and stuff
  
    The traditional Japanese song "Zui Zui Zukkorobashi". Here is a translation 
of an explanation of the lyrics, as given on the following page: 
http://www.worldfolksong.com/songbook/japan/warabeuta/zuizui.htm
    
    "In the Edo Period, in order to present the Uji tea that is the famous 
specialty of Uji City in Kyoto Prefecture to the Tokugawa shogun, a procession 
was held in which the tea was carried in a sealed jar.

    "Because, just as with the daimyo processions, residents along the highway 
routes (Tokkaido, Nakasendo) were compelled to prostrate themselves, it was 
called the 'tea jar journey' (お茶壺道中, ochatsubo douchuu), and it continued from 
1633 until the collapse of the Tokugawa Shogunate.

    "This was a harsh era with a class system in which, if the common people 
crossed in front of the procession, women and children would be killed 
barehanded without a concern. It's said to contain the meaning of a warning that 
'If the tea jar comes, slam your doors shut; no matter who calls, going outside 
is forbidden.'"
    
    The lyrics are vague and this interpretation has been disputed, but since 
it's effectively impossible to translate it without assuming some sort of 
meaning, my translation largely follows from this interpretation.
  
  *** Mount Hakkoda
  
    A mountain (range) in Aomori Prefecture. In the most lethal disaster of 
modern mountain climbing, nearly 200 soldiers died there in 1902 after becoming 
lost in a blizzard, a fact which may or may not be relevant to its appearance in 
this game.

                    ****************************************
                    *         V. Additional Notes          *
                    ****************************************

  +---------------------+
  | Version Differences |
  +---------------------+
  
  What's the difference between the original game and this "Remix" version? 
Well, practically nothing. The graphics were not redrawn, so despite being on 
the Saturn, it looks no different from the original Mega-CD game. What few 
changes do exist are very minor and probably unnoticeable if you haven't played 
the original – think "an occasional extra fade-out here and there". A few small 
cosmetic improvements were made to the opening sequence, and a single scene in 
the middle of the game was slightly extended to match how it appeared in the 
FM-Towns port. Unfortunately, some small graphic bugs were also introduced, as 
detailed below.
  
  The game does benefit slightly from the more powerful hardware; there is no 
longer a screen blackout when changing scenes, and scaling and rotation effects 
run more smoothly and at a higher resolution. And naturally, the music no longer 
uses the YM2612 chip; the actual compositions are virtually the same, just with 
a much more MIDI-like sound. (Though whether that's an improvement or not may be 
a matter of taste.) Yumimi Puzzle is also new for this version.
  
  In short, this is a Mega-CD game running on the Saturn – nothing less and very 
little more. Try not to judge it by 32-bit standards, because obviously it's not 
going to measure up to games that were originally designed for the more powerful 
hardware. I didn't translate it because it was an amazing Saturn game, I 
translated it because it was an amazing game period.

  +----------+
  | Bugfixes |
  +----------+

  In a rather large oversight, when the game was ported to the Saturn, the 
developers appear to have forgotten to take into account that the Mega Drive's 
VDP renders sprites front-to-back whereas the Saturn's renders them 
back-to-front. As a result, most if not all sprite-based objects are actually 
layered in the opposite order, relative to each other, from what was intended.
  
  Due to the way the game typically composes its graphics, this actually causes 
surprisingly few issues. However, there are a handful of scenes where this 
results in sprite elements that were meant to be overlaid onto other sprites 
instead being hidden behind them; all known instances manifest as characters 
missing mouths and lip flaps that were present in the original game. This 
probably went unnoticed because the game's art style often intentionally omits 
mouths anyway.
  
  This translation fixes several specific scenes that suffer from this problem 
by changing the drawing order to place the overlay elements back on top. The 
underlying issue is not fixed, as that would require a major rewrite of the 
game's sprite generator functions, and I only discovered the problem at the very 
end of development, when I had no desire to hold up the release indefinitely to 
resolve it and retest the entire game for possible knock-on issues.
  
  Fixes made:
    - Yumimi's mouth in the early-game scene where Sakurako and Shinichi run by 
her in a cloud of dust
    - Yumimi's mouth as she and Sakurako walk down a hallway in one of the 
endings
    - Mouths of two students who walk by Yumimi and Shinichi in one of the 
endings
  
  I didn't do an exhaustive check, so it's certainly possible there are other 
instances of the issue that aren't fixed, but problems are rare and generally 
not noticeable anyway.

                    ****************************************
                    *        VI. Author's Comments         *
                    ****************************************
  
  Vision, determination, patience, ambition, drive. You meet a lot of people 
with those qualities in the fan translation scene, because that's what it takes 
to be successful and do good work even when it's not putting food on the table 
and keeping the lights on. Those people are your Tomatos, your Gideon Zhis, your 
TheMajinZenkis – the ones with the grit and skill to push through to the end, 
whatever it takes. Then, on the other hand, you have some people that only get 
anywhere because they're too dumb to realize they should quit. Those, I can 
safely tell you, are your Suppers.
  
  I'd love to be able to relate here the memorable and compelling story of how I 
came to be involved with Yumimi Mix here. It would probably involve a lifelong 
passion for Izumi Takemoto's eye-catching artwork and one-of-a-kind worldview, 
blending naturally with my interest in Game Arts' technically accomplished and 
highly compelling games, and the discovery that both had been brought together 
in one astoundingly well-realized package. But of course that would all be a 
lie, because what really happened was that I was browsing a list of Mega-CD 
games for something to play, picked this one out because of the weird title, and 
played it for a few minutes before giving up because I had no idea what was 
going on.
  
  That was October 29th, 2016, at least if my computer's datestamps can be 
believed. By Halloween, I'd apparently moved on to Cosmic Fantasy Stories 
(though I'm pretty sure I played that for maybe a couple of minutes tops), and 
for a while, that was that. But in late 2017, when I was trying to break into 
the translation scene, something apparently sparked me to work on the game again 
– honestly, I think my main motivation was just the fact that no one else was 
doing Mega-CD translations and it was an opportunity to stand out, which I guess 
mattered to me back then. I took apart almost the entire scripting system 
(mostly just by commenting a disassembly, as MCD debugging tools were and 
probably still are crap) and wrote tools to de- and re-construct all the 
resource files.
  
  I knew almost no Japanese at the time and had a great deal of naivete about 
how much effort was involved in translating such a game, so I hoped that if I 
did the basic hacking and posted some screenshots of my work, someone might take 
pity and offer to help out. I did so on January 18th, 2018. And while that 
strategy did work out for another project and led to many further translations 
(thank you, Sailor Moon and filler, I owe you a lot), Yumimi Mix had no such 
luck and lay around abandoned as the years slowly passed, eventually becoming 
the sole inhabitant of the "Limbo" section of my web site.
  
  Over the years, a couple of different people approached me about the 
possibility of translating the game, but things just never worked out. Honestly, 
it's probably for the best; early on, I had no understanding of how to carry out 
a project of this type and scale, so I doubt things would have turned out well 
anyway. But I'm grateful for the offers, and trust me, I now have a very 
thorough appreciation of the fact that if you're not getting paid, you pretty 
much have to love the game (and be too dumb to quit) to successfully make it 
through transcribing and translating two hours of low-quality audio clips. So if 
you're one of those people who offered, don't feel bad, because I get it.
  
  But those occasional offers did push me to keep working on the project, 
including a major rewrite a couple of years ago that updated the codebase from 
my original messy ad-hoc solutions to the (infinitesimally) higher standards of 
my modern projects. That gave me a much cleaner basis for subsequent work.
  
  So, we reach this year. Having discovered that, contrary to my expectations 
based on its title and platform, Hataraku Shoujo: Tekipaki Working Love for the 
PC-Engine was *not* an office romance game, but in fact another wonderful Izumi 
Takemoto project with more great artwork and a funny opening song, I found 
myself thinking of Yumimi Mix again. Having now studied Japanese for years, and 
having just come off of a mostly-solo translation of Galaxy Fraulein Yuna 2 that 
involved a considerable amount of audio transcription, I replayed the game and 
started to think, "You know, maybe…"
  
  And a few months, a change of target platform, insufferable amounts of coding, 
and a whole lot of "what the hell is this voice actress screaming" later, here 
we are, with what is basically a fansub for a two-hour anime movie except it 
runs on the Sega Saturn. Was it worth it? …Well, I'd say yes. Though I suppose I 
might be a little biased.
  
  Switching from the Mega-CD to the Saturn was an early decision and a 
no-brainer. The Mega-CD struggles to keep up with the game's demanding graphical 
throughput as it is, and trying to put subtitles on top of that would only 
exacerbate the issue. The Saturn version not only runs smoother but adds minor 
improvements here and there. Targeting the MCD version would have taken ten 
times as much work just to create a worse translation for an almost strictly 
inferior version of the game, and I really should never have bothered with it in 
the first place.
  
  Once the decision to switch platforms was made, I had to rework the project a 
bit, though not as much as you might expect. The game runs on a virtual machine, 
and all ports of the game basically just reimplement the machine with minimal 
further changes: all game data like scripts and graphics are 95% identical 
between versions, with the only real change being the audio format (matching the 
hardware specs, the Saturn version uses 16-bit rather than 8-bit PCM, and also 
encrypts it for whatever reason). As a result, I was able to reuse the script 
assembly tools I'd previously developed with almost no changes.
  
  On the other hand, the subtitling system was redone entirely from scratch. The 
original concept was to operate through extensions to the existing script 
system, but that proved to be far too limiting and an incredible pain to try to 
time subtitles against. So instead, subtitles are now externally overlaid 
through direct hacks to the game engine and timed via VSync, allowing for far 
more powerful and precise display. As an aside, the subtitle code for this game 
is largely a SuperH port of what I previously wrote for the Community Pom ending 
– did anyone actually play it that far? I'm doubtful – with many extensions and 
improvements to allow for multiple simultaneous subtitle streams, more than one 
line of text per display slot, etc.
  
  As a very straightforward port of a Mega-CD game, this was obviously a 
relative softball as far as Saturn hacking goes, so I suppose it won't earn me 
much credit with that scene. A giant portion of the main RAM was just sitting 
around completely unused, and all the extra resources needed for the translation 
easily fit in uncompressed. There was ample free VRAM to just shove in a whole 
font and a dozen kilobytes' worth of display commands for it, and even to 
"double-buffer" everything to avoid rendering complications.
  
  But hey, don't think it didn't take any work: while it obviously can't compare 
to any of the big Saturn projects, 6000 lines of assembly don't write 
themselves. And after determining that none of the existing assemblers had the 
featureset I wanted, I even had to spend a weekend hastily hacking SH-2 support 
into armips (the result naturally being "armipsh", though somehow I don't think 
Kingcom will be adopting it anytime soon). Who knows, maybe all that will even 
work on real hardware! Ah ha ha...
  
  And then, of course, there was the translation. While this is a game that's 
relatively well suited to my skill level – typical school setting, lots of 
straightforward "anime conversations", not in any way serious, really not even 
all that long – everything was complicated horribly by the complete lack of a 
written script. Before I studied the language, I had the strange misapprehension 
that at some point you just "learned Japanese" and could translate whatever, 
including spoken dialogue, with no problem. Shockingly, it turns out it's a bit 
more complicated than that, and that even professional translators would rarely 
if ever work without a text script. But you know, too dumb to know when to quit 
and all.
  
  I could carry on, but I think this is too many words already. If you really 
want more of the story, go find this project's Git repo and read the source 
code. It's probably more exciting anyway – I'm sure you can find a bout of 
profanity or three in comments written on a particularly frustrating night.
  
  So, five-odd years on, here's a translation of Yumimi Mix, done, for lack of 
any better options, by myself (with testing assistance from the ever-faithful 
cccmar). I could try to sell it to you as the logical outcome of drive, 
ambition, patience, determination, and vision – but I think I've well 
established that really, it was just about being too dumb to quit. But now I 
finally will quit – talking, that is, and let the game speak for itself, because 
it has far more interesting things to say anyway. I hope you enjoy it, because 
there's really nothing else like it. Except the quasi-sequel, and boy, don't ask 
me about that just yet.
  
  But you know, seriously, how much of Perry Rhodan COULD anyone read in a 
lifetime? I just don't get it at all.

                    ****************************************
                    *         VII. Special Thanks          *
                    ****************************************

Thanks goes first and foremost to 司書, who created a Japanese fanpage for Yumimi 
Mix with incredibly detailed information about the game and explanations of 
almost all of its bizarre pop culture references. It even includes the full 
contents of the Yumimi Quiz minigame from the FM-Towns version of the game, 
which was an excellent source of unintended aid for transcribing some of the 
crazier lines (never in a million years would I have figured out Sakurako 
screaming 板垣死すとも自由は死なず at the top of her lungs, with no further context, on my 
own). It was an absolute godsend, and this translation would have taken longer 
and been much worse without it. You have my eternal gratitude! Check the site 
out: http://zattalib.yu-nagi.com/game/YumimiMix/YMMain.html

Thanks to contributors at MobyGames for translating the game's credits, saving 
me most of the tedious legwork of trying to cross-reference the raw names 
against known Game Arts employees in order to figure out the name 
readings…though unfortunately, they only translated the Mega-CD version, which 
has slightly different credits from the Saturn version, so I had to do some of 
the research myself anyway. It's still hours of my time saved, though, so I'm 
not complaining.

I have to thank all the other members of LIPEMCO! Translations for putting up 
with me and offering support, even when I keep putting my solo career ahead of 
the band, so to speak. I don't think they're at the point of kicking me out…yet…

Additional thanks goes to SadNES cITy Translations for the Delta Patcher 
program, which is bundled with this patch as a convenience.

Finally, thank you to the various people who've offered to translate the game 
over the years. Even though things didn't work out, it pushed me to keep working 
on the project, and I doubt this would have happened without you.

                    ****************************************
                    *        VIII. Version History         *
                    ****************************************

v1.0 (06 Apr 2022): Initial release.
