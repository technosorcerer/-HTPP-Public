This patch patches PAL Keio Flying Squadron 2 to replace the sounds
(like the ones from the main character) and the videos by the
Japanese ones.

v1.0 by s10k 2021-11-29

Use xdelta 3.0u (you can use the GUI xdeltaUI) to patch
"Keio Flying Squadron 2 (Europe) (Track 01).bin" file. I used the
image from redump.ss.revival. CRC32: C5EEDCCF
