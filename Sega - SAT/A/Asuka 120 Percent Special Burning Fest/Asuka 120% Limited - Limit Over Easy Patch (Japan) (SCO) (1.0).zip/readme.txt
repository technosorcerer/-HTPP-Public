Asuka 120% Limit Over, English translation 1.0

Introduction
============

This patch applies to redump Asuka 120% Limited: Burning Fest. for Saturn and
combines both Asuka 120% Over Limit and Ms Tea Menu patch. Since the original
patch didn't include the Asuka 120% Over Limit modifications or target a 
'good dump', applying the patch was harder than expected to the point I created
this.

Since the original Asuka 120% Over Limit already was a non-commercial hack,
I see no reason not to combine both, extract the first track in raw mode and
create a patch that creates a complete translation that turns redump 
Asuka 120% Limited: Burning Fest. into Asuka 120% Over Limit.

How to use
==========

Apply the patch.xdelta file to Asuka 120% Limited - Burning Fest. Limited (Japan) (Track 01).bin
and replace this file by the new one.


Sources
=======

http://www.geocities.jp/shicky256/limitover/index.html
http://www.romhacking.net/translations/2381/


