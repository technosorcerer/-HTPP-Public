How to apply romhack:
Using Delta patcher to apply your patches 
Download : https://1drv.ms/f/s!ArhmD3lN6G3Nf1f_IejOj47AQqY?e=kZkJJu
Author: PFTM
Youtube: http://youtube.com/@pftmclub
Discord: pftmclub




ROM / ISO Information:
Asuka 120% Limited BURNING Fest.
MD5 (Track 01.bin): 9f943972333e83a4d2c15cf0bb9f3434
SHA-1 (Track 01.bin) : 1c21759864381dbc946a143e3527848fb35976d8
SHA-1 (Cue_Sheet) : 166D6AE6563AAF7091F6B13590A95B01A724488F
http://redump.org/disc/28740

Bonus: 
You can using Limit Over English patch provided inside LimitOver Folder after patching 
Burning Remixes successfully 
