~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
~--------- Astal - Vocal Sega Jingle Restoration + Easter Egg ----------~
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Patch version: v1.0

Author: Riggles

Platform: Sega Saturn

Date: 2024-03-17

--- About ---------------------------------------------------------------

In the Japanese release of Astal, if you idle on the Title Screen a Sega Logo 
animation and jingle eventually starts playing. In the Japanese version 
this jingle plays alongside a female vocal "Seeegaaaa". 
This patch restores the vocal version of that jingle.

This patch also restores the "Alternate Sega Calls" Easter Egg that also was 
cut from the US version. With the Easter Egg enabled you can make other
characters from the game say "Sega" during the Sega logo animation.

The various Sega jingles in the Japanese version can be heard here:
https://tcrf.net/Astal#:~:text=In%20the%20Japanese%20version%2C%20Astal,The%20US%20version%20is%20instrumental.

--- How to enable the Easter Egg -----------------------------------------

Go into the options menu, then press Left Right Left Right Up Down L R START on the 
second player controller. This unlocks the "Secret Mode".
With Secret Mode enabled you can return to the Title Screen.

While waiting for the Sega Logo to appear:

Hold L+X for Leda
Hold L+Y for Astal
Hold L+Z for Geist
Hold R+X for Antowas
Hold R+Y for an alternate Antowas
Hold R+Z for Gerardo

More cheats are described here: https://segaretro.org/Astal/Hidden_content

--- Patching Instructions ----------------------------------------------

- Download the Sega Saturn Patcher by KnightOfDragon:
https://segaxtreme.net/resources/sega-saturn-patcher.73/
(v1.91 Beta download, actual version 1.9.7872.1316)

- Select Saturn Game then CD Image

- Select your .cue + .bin copy of Astal (redump verified (USA) (3S), two .bin tracks)

- Click the "+Game Patch" button and select the .ssp patch provided.

- Click the "Build Image" button, optinally with "Separate Track Files" checked in.

- Select .bin from the Windows Explorer window "Save as type:" dropdown.


 






