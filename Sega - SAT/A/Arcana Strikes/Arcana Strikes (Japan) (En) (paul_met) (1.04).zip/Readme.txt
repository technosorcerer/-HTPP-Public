========================================
=============Arcana Strikes=============
================V 1.04==================
========================================
Genre: TRPG

Source language: Japanese

Platform: Sega Saturn

Patch language: English

Author: paul_met/aishsha/Pennywise

E-mail:	paul294met@gmail.com
	http://meduza-team.ucoz.net
        aishsha@gmail.com
        aishsha@blogspot.com
 
======================================================
Background
======================================================
This is a complete English patch for "Arcana Strikes" translating the game from Japanese into English.

======================================================
Patching Instructions
======================================================
 - In order to apply a "ppf" format patch, you will need a utility known as "ppf-o-matic" which can be found at "https://www.sadnescity.it/tools/patch/ppfomatic3.zip";
 - It is recommended to patch a disc image (data track #1) compatible with the one from "redump.org" (http://redump.org/disc/42764/) or use your own dumo in the bin/cue format with Mode1/2352 parameters.

======================================================
Manual
======================================================
Will be available later...

======================================================
Emulators to use
======================================================
The game was fully passed on Mednafen.

======================================================
Comments
======================================================
paul_met:
---------
I've been eyeing this game for a long time, but at that time I didn't have enough skill and experience to hack it properly.
First of all, I was interested in the plot, since all the text is in Japanese. In addition, the game looks very interesting (unusually implemented animation, allies and enemies in the form of a deck of cards, mysterious locations, etc.). The combat system is not as simple as it seemed at first glance (it reveals itself gradually).

Technical Details:
******************
- The game now supports 1-byte encoding, DTE and color highlights for the dialogues;
- The cinematics use software subtitles.
- The game uses its own data caching system and does not require an expansion card.


======================================================
Disclaimers
======================================================
All the materials in the game are purely copyrights of  Takara CO., LTD. and RED. The game developers did their best and put a lot of hard work into this project, so BUY THE ORIGINAL GAME IF YOU LIKE IT!!!

======================================================
Credits
======================================================
paul_met - major hacker, programmer and designer

aishsha - translation

Ryusui, TheMajinZenki - spot translations

Pennywise - testing, editing, coordinating

FCandChill - testing 

======================================================
Compiled by paul_met.
March 2025.