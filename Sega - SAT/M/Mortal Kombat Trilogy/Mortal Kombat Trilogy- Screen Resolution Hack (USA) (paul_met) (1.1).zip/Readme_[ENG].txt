Mortal Kombat Trilogy [Saturn] - hack to increase the screen resolution up to 352x240 (v1.1)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Patch installation:
===================
- Attention! This hack is designed only for USA (NTSC) version of the game.
- Open the original image of USA (NTSC) region of the game in the program "CDMage" (attached).
- Insert all the file are in a directory "Patch..." to the image through "CDMage" (select the file in the list and by the right-clicking select item "Import file").


===============
= Changes log =
===============

Version 1.1:
************
- Changed the distance of lifebars from the edges of the screen (+8 pixels)
- Corrected the coordinates of the inscription "Random select" for the 2nd player
- Corrected Y coordinates of the characters sprites in some arenas
- Corrected X coordinates of the background in the arena "The Portal"

Version 1.0:
************
- Increase the screen resolution.
- Removed horizontal black bars to the bottom of some arenas
- Tiles maps have been improved
- Changed controls by default ("B" - block, "Y" - run)
- Unlocked menu as question mark ("?")


===================================
�2017 paul_met (paul-met@yandex.ru)