"Metal Slug - Super Devil Rank Fix" by Miagui

1. Introduction
===============
This patch is meant to fix a bug in the rank system on Combat School, where finishing Survival Attack wasn't awarding the 10 points needed to reach the Super Devil rank (1000 points).
Tested on Beetle Saturn.

2. ISO Information
==================
Metal Slug - Super Vehicle-001 (Japan) (Rev A) (Track 01).bin
Serial "T-3111G"
MD5: 35aae15f0a552b751d68753e3ab2e2db
http://redump.org/disc/1643/

3. Instructions
===============
Use XDeltaUI to apply the patch (https://www.romhacking.net/utilities/598/) on the first track "Metal Slug - Super Vehicle-001 (Japan) (Rev A) (Track 01).bin".

MD5 before: 35aae15f0a552b751d68753e3ab2e2db
MD5 after: d3de746103dafe521ef80b2116d15fef