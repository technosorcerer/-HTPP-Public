﻿=======================================================
=====================Valhollian========================
=======================V 1.3===========================
Genre: RPG

Source language: Japanese

Platform: Sega Saturn

Patch language: English

Author: paul_met/aishsha/Pennywise

E-mail:	paul294met@gmail.com
	http://meduza-team.ucoz.net
                     aishsha.blogspot.com
	http://yojimbo.eludevisibility.org/
 
======================================================
Background
======================================================
This is a complete English patch for Valhollian translating
the game from Japanese into English. The game itself is a
pure representative of the tactical role-playing genre, with
all its ups and downs. This is one of the very few titles
released by Datt Japan.

=====================================================
Patching Instructions
=====================================================
1. Copy all the patch files into a folder containing the
   original multi-track game image in the "Bin/Cue" format!
2. Launch the "START.BAT" file.
3. To make things safer, the original data track is saved
   in the same folder (with the "old" extension). You may
   further delete after successful patching.
4. All the patch files are automatically deleted at the
   end of the patching process!
---------------------------------------------------
The original image should be equivalent to the one found here:
Redump.org/disc/68329
======================================================
Manual
======================================================
We have also fully translated and edited the game's
manual which you can find in the CBR format. Please,
use the http://www.cdisplay.me/ software to view it
properly.
======================================================
Emulators to use
======================================================
This is another emulator-nightmare title which might
turn down to various sound or graphical issues found
even on SSF or yabause. MedNafen was considered the
most stable one in emulating this game properly,
but real hardware is always the best choice (the game
has been fully tested and passed on the real Sega Saturn).
======================================================
paul_met's comments
======================================================
The "Valhollian" might look like an average tactical
game from the first glance - typical for its times.
But when you start digging deeper - this is one of
those die-hard nuts to crack. The battles are hard
above average while keeping you under constant pressure.

It's quite unique combo system also makes things
a bit funnier when two allies can hit the same foe
as a duo team. It's worth mentioning that the 3D
animation found in the game is also of high quality
(while exceeding 3D models found even in such titles
as the acclaimed "Shining Force III"). Music also
has nothing to complain about while plot is another
"gem" part of the game. All in all, the game's techs
are rather well-done (since the title was released
on the dusk of the Sega Saturn era - back in 1998).

The new features introduced by the patch also provide
the 4MB external RAM support (activated automatically
with the RAM cart inserted) to speed up the loading
for optional 3D screens found in battles (the loading
time is cut by about a half).
======================================================
aishsha's comments
======================================================
Well, another obscure game on my memory which started
like "let's do something real quick for a change" and
turned out into a full-fledged project eventually.

The only thing I can say about the Valhollian is that
it absolutely NOT what it might seem. The seemingly
average plot turns into a really neat and consistent
story those 90s times, and probably only the lack of
financing stood in the way of making it even better.
The music gets captivating with every new step and
cartoonish visuals fit the game quite well.

One last thing - despite its childish look, the game
is hard. And I mean ABSOLUTELY BRUTAL. So, SAVE the
game. Then, save it again. And save it another time,
just to be sure, as every next turn might be your
last one, and reloads will be your constant assistants
in this tactical hell. So, yes, you will have to think
in this one. Sometimes, 2-3 turns ahead. There will
be occasions when there's much safer to lure your
foes and rushing on them. But I'm spoiling too much -
see it for yourselves.

So, yes, enjoy the game and BUY the bloody original
since the developers certainly deserved that even
if they're inactive :)
======================================================
Pennywise's comments
======================================================
Valhollian is a super obscure Saturn game that I'd never
heard of before aishsha told me about it. Naturally,
I wasn't expecting much, but the game surprised me in
the end. I especially grew to like the beautiful 2D
graphics of the various maps and while the scope of the
game was limited, there was some depth to it.

The difficultly on the other hand was so shockingly hard,
I suspect a lot of people will just give up on it, but the
game does get easier as you progress.

All in all, we've provided another quality translation
for the oft-neglected Sega Saturn.
======================================================
cccmar's comments
======================================================
Valhollian is a pretty late Saturn game, and I thought
it was pretty good. Apparently, it's not very well-known
in Japan either (not many articles etc. on it).

The characters on the battle map looks sorta like SFC
characters, for the most part. The number of songs in
music is small, and you can hardly expect anything too
bombastic. The battle map/battle music tracks were the
best in my opinion. This game has a huge number of foes.
The enemy's attack power is quite significant all things
considered. You can't win just with a single character.
So what is an effective strategy to win? Use decoys to
lure enemies and disperse their forces. Create a wall
with characters with high defense power/HP to protect
the characters in the back. Make sure to stop the enemy's
counterattack during your turn. Do not use just one
character at any time. Also, remember about the combined
attacks, they're the most powerful by a long shot, and
will make the game considerably easier (the first few maps
will still be quite difficult).

Overall, it's a fairly simple game, with a story that has
a few surprises in store and some fun moments, but if you're
not into SRPGs, this one is pretty standard fare and likely
won't convince you to get into the genre. I enjoyed it though,
in the end, and I hope you will too.
======================================================
Disclaimers
======================================================
All the materials in the game are purely copyrights
of Sega and DATT JAPAN INC. The game developers did their
best and put a lot of hard work into this project,
so BUY THE ORIGINAL GAME IF YOU LIKE IT!!!
======================================================
Credits
======================================================
paul_met - initiator, coordinator, hacker and designer

aishsha - translation, testing, manual works

Pennywise - testing, editing, coordinating

TheMajinZenki - misc spot translations

MatatabiMitsu - misc spot translations

cccmar - major testing

Xanathis - testing

Rim Saruyama - an absolutely gorgeous video walkthrough
for this game with personal comments. Do check out or
even subscribe to the guy's channel if you like retro
gaming or just cool little stories about Japan:
https://www.youtube.com/channel/UCA_woHeX-K3qs8B4pJJyTTg

All those who contributed into this process.

======================================================
Fixes
======================================================
Ver. 1.2 contains a fix for a specific Levelup glitch.
======================================================
Ver. 1.3 contains corrections of a number of minor grammar
errors and misspellings, a fix for Gerard's levelup code and
the requested MP memory card routine.
To disable auto-detection of the 4 MB expansion card,  you
need  hold down the "L+R" button during the animated
"Sega Saturn" logo.
======================================================

Compiled by aishsha. May 2021.