=======================================================
==================Linkle Liver Story===================
========================V 1.0==========================
Genre: Action-RPG

Source language: Japanese

Platform: Sega Saturn

Patch language: English

Author: paul_met/aishsha/Pennywise

E-mail:	paul294met@gmail.com
	http://meduza-team.ucoz.net
        aishsha@gmail.com
        aishsha@blogspot.com
	http://yojimbo.eludevisibility.org/
 
======================================================
Background
======================================================
This is a complete English patch for Linkle Liver Story
translating the game from Japanese into English. The game
itself is a light-hearted and fast-pacing kind of a hybrid
between a platformer, adventure and RPG with a colorful
cartoonish visuals, great music, funny story and a
unique weapon-cultivation system. The debates about
the game title has been ongoing since way back of its
release in 1996, and it still remains a mystery to
all. This is one of those hidden Saturn gems definitely
worthy to play - especially when it's quite easy and
fast to complete.
======================================================
Differences from the original game
======================================================
 - 1-byte encoding support;
 - VWF support;
 - 4 lines support in the dialogue screen.
======================================================
Patching Instructions
======================================================
 - In order to apply a "ppf" format patch, you will
   need a untility known as "ppf-o-matic" which can
   be found at http://www.romhacking.net/utilities/356/;
 - It is recommended to patch a disc image compatible
   with the one from "redump.org" (http://redump.org/disc/3238/)
   or use your own dumo in the bin/cue format with
   Mode1/2352 parameters.
======================================================
Manual
======================================================
We have also fully translated and edited the game's
manual which you can find in the CBR format. Please,
use the "CDisplay" software (http://www.cdisplay.me/) 
to view it properly.
======================================================
Emulators to use
======================================================
The game is VERY picky with the emulation software.
Hence, it simply freezes eventually on mednafen and
has some issues on the most popular emulators available
today.
 - SSF (number 1 recommended, though it has some
   reported lag and framerate drop issues);
 - Yabause/YabaSanshiro (play the game fine mostly,
   but experience troubles when playing separate
   musical pieces in the beginning and the end:
   yabause-0.9.14 version was used for testing);
 - Mednafen (v1.22.0 or earlier) is not recommended - 
   game freezes on global map;
 - Real hardware. THE GAME HAS BEEN FULLY TESTED
   ON AN ACTUAL SEGA SATURN SYSTEM WITHOUT ANY
   ISSUES DETECTED. It goes without saying that
   it is the best option to play the game.
======================================================
paul_met's comments
======================================================
Linkle Liver Story is a pretty and coloful title with
funny characters and foes, pleasant musical background
and easy-going gameplay. The game was mostly developed
by Nextech - the one responsible for one of the best
Megadrive jewels in the Action-RPG field known as
Crusader of Centy or Soleil. Generally, Linkle Liver
Story is quite "hi-tech" for its age. Except for
scaled 2D elements, animated backgrounds, reflections
and shaders, it also actively uses 3D models (rocks,
trees or a globe-like world map). The game actively
utilizes both Saturn processors, which is a rarer
thing even for most successful titles issued in the
same year (e.g., The Story of Thor 2 / Legend of Oasis
uses only one CPU).
======================================================
aishsha's comments
======================================================
This whole thing started as a quite unexpected project
about a year ago when paul_met approached me with this
proposal while I was coming and going to various other
project. The collaboration was very fast-pacing and
pleasant, which resulted in quite a rapid release with
the help of Pennywise who basically did hell of a job
editing it to the polished beauty we have at the moment
while the hacking works was top-notched from the very
start. The game is a rather unique platformerish runner
with RPG elements, which I personally enjoyed a lot and
even passed it for the THIRD time on my Sega Saturn.
Besides, we do love this platform which certainly
deserves more of our attention :)
======================================================
Pennywise's comments
======================================================
aishsha asked to edit this game. Seemed like a change
of pace being a Saturn game and all. Overall, it was a
charming game and fun to work on.
======================================================
Disclaimers
======================================================
All the materials in the game are purely copyrights
of Sega and Nextech. The game developers did their
best and put a lot of hard work into this project,
so BUY THE ORIGINAL GAME IF YOU LIKE IT!!!
======================================================
Credits
======================================================
paul_met - initiator, coordinator, hacker and designer

aishsha - translation, testing, manual works

Pennywise - testing, editing

FlashPV and Lestat - main game logo and misc designs

Ryusui - misc spot translations

harmony7 - misc spot translations

TheMajinZenki - misc spot translations

Xanathis - testing

cccmar - testing

Jazz - the Game Over screen design

Midna/weissvulf - weapon icons designs

All those who contributed into this process.

======================================================


Compiled by aishsha. January 2019.