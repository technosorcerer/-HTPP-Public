***********************************************
* Sonic 3D Blast / Sonic 3D: Flickies' Island *
*         Special Stage Edition v1.0          *
***********************************************

=================================
 1. Introduction
=================================
This is a hack for the Sega Saturn port of Sonic 3D Blast which cuts out the main game and allows all seven Special Stages to be played consecutively.
 
In the main menu, select "Start" and the map of Flickies' Island will appear, followed by a brief flash of the title card for Green Groves Act 1. After a bit more loading, the first Special Stage will begin.

Gameplay loop :
 * Pass the Special Stage           -> Collect a Chaos Emerald and proceed to the next Special Stage
 * Fail the Special Stage           -> Retry the same Special Stage
 * Collect all seven Chaos Emeralds -> Play the sixth Special Stage endlessly

=================================
 2. Game Version Recommendations
=================================
If you have an NTSC Saturn, a PAL Saturn modified for 60Hz output, or plan on using an emulator, patch the Japanese version as it has the shortest loading times and gives the smoothest experience at 60 frames per second.

If you have an unmodified PAL Saturn that is only capable of 50Hz output, patch the European version. To compensate for the lower refresh rate, the speed of its Special Stages were adjusted and so they perform comparably to the NTSC versions (in fact, they run slightly faster at 50Hz than the NTSC versions running at 60Hz). Note that the European version can't be forced to 60Hz as this completely breaks the Special Stages.

Patch for the USA version is only included for the sake of completeness and is not recommended, as it has the longest loading times and is incompatible with Satiator ODE as of firmware v160 and menu v67; like the vanilla USA version, it crashes after the Special Stage results screen.

=================================
 3. Patch Instructions
=================================
The patches in this archive are in IPS format:
 * Compatible with disc images in MODE1/2352 format (e.g. BIN/CUE, CCD/IMG/SUB)
 * Incompatible with disc images in MODE1/2048 format (e.g. ISO/WAV/CUE)
 
Additional patching options can be found in the archive at SegaXtreme:
https://segaxtreme.net/resources/sonic-3d-blast-sonic-3d-flickies-island-special-stage-edition.239/

The following instructions are for Lunar IPS but the same general process applies to all patch utilities:
 1. Open Lunar IPS and click "Apply IPS Patch".
 2. Browse to the main patch folder.
 3. Select the subfolder that corresponds with the game version you want to patch.
 4. Select the IPS file that corresponds with the character you want Sonic to be taken to the Special Stage by.
 5. In the bottom-right corner of the window, select "All Files (*.*)" from the drop-down menu.
 6. Browse to the disc image folder.
 7. Select the disc image; if you are patching one of the images listed below, select Track 01.
 8. "The file was successfully patched!" prompt will appear.
 9. The patch has now been applied and is ready to play!
 
+=============+======================================+===============================+
| Game Region |           Disc Image Name            |    Disc Image Information     |
+=============+======================================+===============================+
| Europe      | Sonic 3D - Flickies' Island (Europe) | http://redump.org/disc/8309/  |
+-------------+--------------------------------------+-------------------------------+
| Japan       | Sonic 3D - Flickies' Island (Japan)  | http://redump.org/disc/28742/ |
+-------------+--------------------------------------+-------------------------------+
| USA         | Sonic 3D Blast (USA)                 | http://redump.org/disc/7008/  |
+-------------+--------------------------------------+-------------------------------+
 
=================================
 4. Cheat Codes
=================================
To play any Special Stage straight away, use the appropriate cheat code and replace X with the stage number minus one. For example, if you want to play Special Stage 7 in the Japanese version, use code 360961C5 0006.

Cheat code for the European version is only included for the sake of completeness and should not be used; on real hardware and the emulator Mednafen, it causes graphical glitches in the fifth Special Stage and crashes every other Special Stage at various points.

+=============+===============+
| Game Region |  Cheat Code   |
+=============+===============+
| Europe      | 36096F45 000X |
+-------------+---------------+
| Japan       | 360961C5 000X |
+-------------+---------------+
| USA         | 36097C55 000X |
+-------------+---------------+

Here is a brief comparison of cheat code usage on real hardware and emulators:

+===============+=======================+=========================+
|     Setup     | Master Code Required? |  Play Stage Endlessly?  |
+===============+=======================+=========================+
| Real Hardware |  Yes: F6000914 C305   |           Yes           |
|               |       B6002800 0000   |                         |
+---------------+-----------------------+-------------------------+
|   Emulator    |          No           | No, if code is disabled |
|               |                       |  once stage has loaded  |
+---------------+-----------------------+-------------------------+

=================================
 5. Technical Details
=================================
All patches simply change two bytes in SONIC.BIN:
 * first byte is changed from 01 to 00 which allows you to collect more than one Chaos Emerald in a single act. 
 * second byte is changed from 00 (normal play) to 01 or 02 which activates the Special Stage with Sonic taken to it by Tails or Knuckles, respectively. In both cases, the Special Stages are identical so this amounts to a minor cosmetic difference.

+=============+=============================+=============================+
| Game Region |  Collect all Chaos Emeralds |   Activate Special Stage    |
+=============+=============================+=============================+
| Europe      | 0x000426BF | 01 -> 00       | 0x00042843 | 00 -> 01 or 02 |
+-------------+-----------------------------+-----------------------------+
| Japan       | 0x00041FED | 01 -> 00       | 0x00042175 | 00 -> 01 or 02 |
+-------------+-----------------------------+-----------------------------+
| USA         | 0x00043449 | 01 -> 00       | 0x000435AF | 00 -> 01 or 02 |
+-------------+-----------------------------+-----------------------------+

=================================
 6. Credits
=================================
Bo Bayles - Hack author.
 * Twitter / X - https://twitter.com/memory_fallen
 * Website     - https://www.bbayles.com

privateye - Testing, and created the patches, cheat codes for the European and Japanese versions, and readme.
 * SegaXtreme - https://segaxtreme.net/members/privateye.20804
 * YouTube    - https://www.youtube.com/privateye
 
Ramdemann - Created cheat code for the USA version.
 * GameHacking - https://gamehacking.org/hackers/Ramdemann
 
Double Dime - Additional testing.

manofstone17 - Additional testing.
