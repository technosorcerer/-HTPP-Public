A translation of Treasure's 1997 masterpiece, Silhouette Mirage, into english using the PS1 Working Designs script.

Current version: 0.63 

The current version has the Tutorial through the start of Area 5 playable fully in english.

Patch using KnightOfDragon's Sega Saturn Patcher (SSP). The patch has been confirmed to work on real hardware using Fenrir/Fenrir Duo, Phoebe, and Satiator, as well as via emulation using Bizhawk, Mednafen, and Yabasanshiro.

NOTE: "+ Region Free Patch" must be UNSELECTED when patching in SSP otherwise the game will crash on boot.

Current Goals:
 -Continue screen sprites
 -Shop keeper sprites
 -Text centering (all areas)
 -Area 5 story text
 -Area 5 shop text

Additional Goals:
 -Insert PS1 load screen splash art in place of Saturn black loading screen (might not be possible with our skill set)

Known Issues:
 -Text spacing in 4-2
 -Text spacing in 4-3
 -Weapon level reset between Area 4 stages (likely a shop-related bug)

Please let us know if you encounter any issues!​

Credits: soniccd123, Rasputin3000, Malenko