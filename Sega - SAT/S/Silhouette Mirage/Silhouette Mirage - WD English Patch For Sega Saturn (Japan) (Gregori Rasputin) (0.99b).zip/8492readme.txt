---------------------------------------------------
* Silhouette Mirage English Patch for Sega Saturn * 
* Release Edition v0.99.b *
* 13-Nov-2023 *
---------------------------------------------------

-----------------
* Patch Details *
-----------------

A translation of Treasure's 1997 masterpiece, Silhouette Mirage, into english using the PS1 Working Designs script. 

The entire game is now playable in english.

The patch has been confirmed to work on real hardware using Fenrir/Fenrir Duo, Phoebe, and Satiator, as well as via emulation using Bizhawk, Mednafen, and Yaba Sanshiro.

--------------------
* Game Description *
--------------------

"In an apocalyptic future, the Edo computer has gone beserk, dividing the world's inhabitants into two mutant classes, Silhouette and Mirage. Now, the watchguard computer safety system has sent forth the Messenger of Justice to travel to Edo and repair the damage before the world is lost forever. As the Messenger, Shyna Nera Shyna, blast, beat, and bash your way through seven wild and bizarre stages using friendly parasite weapons to aid your advance against wacky enemies, huge fully-animated bosses, and devilishly difficult obstacles." 
- Excerpt from Playstation Case

-------------------------
* Patching Instructions *
-------------------------

Patch using KnightOfDragon's Sega Saturn Patcher (SSP) 2.0 (included with this patch). 

NOTE1: Patch will work with all Saturn versions of the game. This includes: v1.001 (Demo), v1.003 (Release), and v1.100 (Rev. A)

NOTE2: "+ Region Free Patch" must be UNSELECTED when patching in SSP otherwise the game will crash on boot.

NOTE3: If the game is having difficulty loading on Fenrir ODE, then try patching with "Separate Track Files(if applicable)" SELECTED in SSP.

---------------
* Known Issues*
---------------

- Centering of "Insufficient RAM" text
- "Continue" screen sprites are untranslated 

Please let us know if you encounter any issues! You can find us at segaxtreme.net

------------------------
* Community Tools Used *
------------------------

-ByteSearch 
-CRAM2PAL
-Crystal Tile 2
-ImHex
-mednafen
-Sega Saturn Patcher
-tim2view
-WinMerge
-wxMEdit
-Yaba Sanshiro

-----------
* Credits * 
-----------

Hacking: soniccd123 
Hex editing: Rasputin3000
Sprite Work/Advising: Malenko