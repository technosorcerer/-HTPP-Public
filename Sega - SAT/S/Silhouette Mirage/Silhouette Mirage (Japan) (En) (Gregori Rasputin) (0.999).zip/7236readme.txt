---------------------------------------------------
* Silhouette Mirage New English Translation Patch for Sega Saturn * 
* RELEASE EDITION v0.999 *
* 28 FEBRUARY 2024 *
---------------------------------------------------

-----------------
* Patch Details *
-----------------

Every line of dialogue has been newly translated from the original Japanese script, obsessively checked and double-checked, to bring the plot and characters of Silhouette Mirage as originally intended into English for the first time. 

The patch has been confirmed to work on real hardware using Fenrir/Fenrir Duo, Phoebe, and Satiator, as well as via emulation using Bizhawk, Mednafen, and Yabasanshiro.

--------------------
* Translator's Synopsis *
--------------------

Following the apocalyptic "Day of Parting", the world and all who inhabit it were split into two halves; Silhouette and Mirage. 

Amidst this wasteland, Shyna Nera Shyna, the "legacy of the past", awakens in an abandoned tower. She knows little aside from her mission; to find "Edo", wherever and whatever that may be, and restore the world to its former state. 

Yet Shyna's own state is bizarre and incomplete, split down the middle. One side possesses the element of Silhouette, the other, Mirage. 

The whole world is against her on her quest to reach Edo. Shyna will face legions of Silhouettes as well as the Lord of the Mirages and his army of "Guardian Angels". Also standing in her way is the mysterious Zohar, a strange being who previously thought they were the only "Half" in the world. 

In the end, will Shyna truly be the "Messenger of Justice"? 

-------------------------
* Patching Instructions *
-------------------------

Patch using KnightOfDragon's Sega Saturn Patcher (SSP) 2.0 (included with the J.B. Harold English Patch: https://segaxtreme.net/resources/j-b-harold-blue-chicago-blues-english-patch.135/). 

NOTE1: Patch will work with both Saturn release versions of the game. This includes: v1.003 (Release) and V1.100 (Rev. A)

NOTE2: "+ Region Free Patch" must be UNSELECTED when patching in SSP otherwise the game will crash on boot.

NOTE3: If the game is having difficulty loading on Fenrir ODE, then try patching with "Separate Track Files(if applicable)" SELECTED in SSP.

---------------
* Known Issues*
---------------

- Centering of "Insufficient RAM" text
- "Continue" screen sprites are untranslated 

Please let us know if you encounter any issues! You can find us at segaxtreme.net

------------------------
* Community Tools Used *
------------------------

-ByteSearch 
-CRAM2PAL
-cysta Tile 2
-ImHex
-mednafen
-Sega Saturn Patcher
-tim2view
-WinMerge
-wxMEdit
-Yaba Sanshiro

-----------
* Credits * 
-----------
Translator: wiredcrackpot
Dialogue Script Editor: CSketch
Hex editing: Rasputin3000

------------------
* Special Thanks * 
------------------
soniccd123 
Malenko