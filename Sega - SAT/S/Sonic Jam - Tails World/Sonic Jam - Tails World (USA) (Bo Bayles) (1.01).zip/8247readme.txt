*********************************
* Sonic Jam: Tails World v1.0.1 *
*********************************

=========================
 1. Introduction
=========================
This is a hack for Sonic Jam on Sega Saturn which makes Tails the playable character in the 3D "Sonic World" mode.

This hack is only compatible with the North American version of the game.
 
=========================
 2. Patch Instructions
=========================
The patch can be applied via Sega Saturn Patcher or an xdelta utility.

Sega Saturn Patcher :
 * Windows only.
 * Compatible with all valid disc images.
 * Patched disc image can be output to BIN/CUE and CCD/IMG/SUB formats.

xdelta :
 * Patch utilities available for all platforms.
 * Only compatible with a specific disc image from the Redump set.
 * Patched disc image is in BIN/CUE format.

-------------------------
 2a. Sega Saturn Patcher
-------------------------
Sega Saturn Patcher can be obtained here: 
 https://segaxtreme.net/resources/sega-saturn-patcher.73/

This program requires .NET Desktop Runtime 5.0 which can be obtained here: 
 https://dotnet.microsoft.com/en-us/download/dotnet/5.0

Once everything is installed, follow these instructions:
 1. Open Sega Saturn Patcher and click the "Select Saturn Game" button.
 2. Click the "CD Image" button.
 3. Browse to the disc image folder and select the Sonic Jam disc image.
 4. Click the "+ Game Patch (SSP)" button.
 5. Browse to the patch folder and select "Patch.ssp"
 6. If you want to save the patched disc image as:
     * BIN/CUE     - Tick the "Separate Tracks Files" box in the bottom-right corner of the window. 
     * CCD/IMG/SUB - Untick the "Separate Tracks Files" box in the bottom-right corner of the window.
 7. In the bottom-right corner of the window, click the "Build Image" or "Patch Image" button.
 8. Enter the desired file name for the patched disc image.
 9. In the drop-down menu labeled "Save as type", select the desired format for the patched disc image.
 10. Click the "Save" button.
 11. "CD image successfully created" prompt should eventually appear. If the program crashes, repeat the process and make sure that you are patching the North American version of Sonic Jam.
 12. The patched disc image has now been created and is ready to play! 
 
-------------------------
 2b. xdelta
-------------------------
Patch utilities :
 * Delta Patcher - https://www.romhacking.net/utilities/704/
 * Web Patcher   - https://hack64.net/tools/patcher.php
 
This disc image from the Redump set is required: 
 http://redump.org/disc/20330/

The following instructions are for Delta Patcher but the same general process applies to all patch utilities:
 1. Open Delta Patcher and click the folder icon next to the "Original file" box.
 2. Browse to the disc image folder and select "Sonic Jam (USA) (Track 1).bin"
 3. Click the folder icon next to the "XDelta patch" box.
 4. Browse to the patch folder and select "Patch.xdelta"
 5. Click the "Apply patch" button.
 6. "Patch successfully applied!" prompt should appear. If not, repeat the process and make sure that you are patching the North American version of Sonic Jam from the Redump set.
 7. The patch has now been applied and is ready to play!

=========================
 3. Cheat Codes
=========================
To play as Tails without applying the patch, use the following cheat codes with the North American version of Sonic Jam:
 * 1604CA92 E001
 * 1604E1E2 E009
 * 1604E306 E009
 * 1604E410 E01D
 * 1604E44C FFE0
 * 1604E68C E01D
 * 1604E6FA E009
 * 1604F0F8 E003
 * 1605BE28 0009
 
When using these cheat codes on real hardware, the following master code is recommended for the best performance. Other master codes may result in sprite flicker.
 * F600093C C305
 * B6002800 0000
 
Please note that the Mega Drive / Genesis games either crash or have graphical corruption with these codes enabled, so the patch is preferred for a trouble-free experience.

=========================
 4. Technical Details
=========================
A handful of memory locations are patched in MUSEUM.MUS:

 * $0000CA92 normally reads the character selector ($00 for Sonic, $01 for Tails).
   We hard-code it to $01 for Tails.
   
 * $0000F0F8 also alters an animation. The game uses Sonic's $02 animation (running) to trigger his running model.
   That doesn't work for Tails, so we set it to $03 (jogging) to allow Tails to run.

 * $0000E1E2, $0000E306, $0000E410, $0000E68C, and $0000E6FA normally set Sonic's animation number to $06 (jumping).
   The game uses that animation to trigger the "spin ball" model, which doesn't work for Tails.
   We set it instead to $09 (flipping over) and $1D (flying) to allow Tails to jump.

 * $0000E44C has the "running jump" height. We set it to make Tails jump higher when running.
   This, coupled with the $1D animation, simulates flying.
 
 * $0001BE26 checks for the $06 jumping animation to determine whether a balloon should be popped. 
   We replace the next instruction with a null operation to allow any animation to break the balloon.

The file is loaded into memory at 0604000. These patches can thus be translated into cheat codes listed in section 3.

=========================
 5. Credits
=========================
Bo Bayles - Created the hack and cheat codes.
 * Twitter / X - https://twitter.com/memory_fallen
 * Website     - https://www.bbayles.com
 
Starman - Research and proof of concept.
 * Sonic Retro - https://forums.sonicretro.org/index.php?threads/sonic-jam-hacking.40001/
 * YouTube     - https://www.youtube.com/164starman
 
privateye - Created the patches and readme, and additional testing.
 * SegaXtreme - https://segaxtreme.net/members/privateye.20804
 * YouTube    - https://www.youtube.com/privateye
 
fafling - Discovered optimal master code, and additional testing.
 * SegaXtreme - https://segaxtreme.net/members/fafling.21188/

=========================
 6. Changelog
=========================
v1.0 (2023/11/22)
 * Initial release.
 
v1.0.1 (2023/12/15)
 * Fixed a bug where balloons could not be popped in mission seven.
