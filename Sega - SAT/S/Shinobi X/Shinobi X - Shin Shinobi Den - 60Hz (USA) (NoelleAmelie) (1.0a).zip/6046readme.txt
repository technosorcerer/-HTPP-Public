--- SHINOBI X: SHIN SHINOBI DEN, 60hz HACK ---
    H          H    H       D    0    A
    I          I    I       E         C
    N          N    N       N         K
    O               O  
    B               B
    I               I


--- CHANGELOG ---

1.1 - fixed an error in the disc region
    - changed to SSP (thanks Knight!)

1.0 - original release

--- WHAT IS THIS? ---

This hack converts the EU/PAL release of Shin Shinobi Den to run at 60hz NTSC, normal speed, by modfying three game files to be equivalent to their NTSC counterpart, as well as changing the header to US.

--- HOW DO I USE IT? ---

You'll need a Redump compliant copy of the game and something that can load the modified game. It is verified to work on a JP VA0 Model 1 with Fenrir 20-pin, JP Model 2 Saturn with Satiator, and SSF R26.
Use Sega Saturn Patcher 1.91 or greater to patch the game.

--- WAIT... WHY? ---

To quote SegaRetro: 

"Sega of Europe's producer David Nulty was reportedly unimpressed with Shinobi Legions's quality, and decided to delay the game from seeing a European release so that the entire soundtrack could be replaced. The new soundtrack was produced by Richard Jacques, who aimed for a style closer to that of Yuzo Koshiro, the man behind The Revenge of Shinobi's musical score"

--- BUT ISN'T THIS VERSION UNOPTIMIZED ANYWAYS? ---

Some lists online would have you believe so, but it's false. Pure fiction. Shinobi X runs faster on NTSC systems as I unfortunately found out attempting to play the base game. I wasn't going to be satisified with playing the arguably (definitely) inferior US release, or playing a too fast version of the game, so I spent a few hours trying to find how to make the game run properly.

--- IS ANYTHING WRONG? ---

- Intro FMV no longer plays. This seems unfixable without in depth hacking
- Game has not been fully playtested, only up through part of Stage 4 and level skipping with cheats

--- CREDITS ---

NoelleAmelie (that's me!) for making the original patch
Knight0fDragon for creating Sega Saturn Patcher, and converting the IPS patch to SSP, and fixing an error I made in the disc region
Richard Jacques for doing the rad new score
Ced2911 for making the Fenrir that made testing this easy 
The people I got to playtest it