xISO 1.1.0
por Yursoft

www.yursoft.com
xiso@yursoft.com

INFO
----

-Notes:
If you have problem with the program like Blue Screen or it dont recognise your drives, please download the ASPI drivers v4.60 from:
www.yursoft.com/xbox/aspi.zip

-Command line switchs:
 Note: The quotes must be in the params, and the words between % (included this) are the params:
 
Open Image....: -o "%IMAGE%"
Extract Image.: -e "%SOURCE_IMAGE%" -f "%TARGET_FOLDER%"
Make Image....: -m "%TARGET_IMAGE%" -f "%SOURCE_FOLDER%
No messages...: -n