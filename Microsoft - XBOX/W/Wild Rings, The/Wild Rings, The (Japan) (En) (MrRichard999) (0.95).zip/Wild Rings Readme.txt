The Wild Rings ENGLISH Translation Version 0.95
10/1/2016

Here is a patch which translates the majority of the game including the player rosters.

There are still a few things left untranslated unfortunately due to compression
and also the fact words are saved as graphics unaccessible but you should be able to navigate through the game for the most part a lot better than before. We hope you enjoy this release!

To setup just replace your original default.xbe and aikoh.arc files with the ones included with
this compressed RAR.

Also included is a file which adds some known wrestlers and has most of the rest translated. If you wish to use it, it will need to be copied in the game�s specific UDATA directory where it�s saves are located.

Don�t forget to backup your original files just in case!

Hacking done by MrRichard999
Majority Translation done by Helly
Translation done by Jink640
 