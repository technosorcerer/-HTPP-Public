THOUSAND LAND ENGLISH TRANSLATION PROJECT
VERSION 0.992b
7/3/2019

MODIFICATIONS AND MENU DESIGNS BY MRRICHARD999

EXTRACTION AND INSERTION OF COMPRESSED 
GRAPHICS FOR MENUS AND ENTRY KEYBOARD BY IRVGOTTI452

TRANSLATION OF OPPONENT DIALOGUES BY AGENTORANGE

TRANSLATION OF TUTORIAL TEXT, DESCRIPTIONS, AND OPPONENT DIALOGUES BY HELLY

TRANSLATION OF ITEMS, TELA NAMES, AND DESCRIPTIONS BY JINK640 

Here is full English translation for Thousand Land on the Xbox Original. All of the menus, graphics, name entry screen, and dialogue have been fully translated! Some testing has been done but not everything may have been fully seen yet. If any corrections are needed or issues are present please feel free to contact MrRichard999 on Twitter or RPG Codex. 

Update Notes for 0.99b

-Patch of completion.

Update Notes for 0.991b

-Spelling corrections made.

Update Notes for 0.992b

-Fixed debug dialogue and text.


DIRECTIONS FOR SETTING UP - EXTRACT THESE FILES AT THE ROOT OF THE FOLDER SO THAT FOLDERS ARE EXTRACTED AT THE CORRECT LOCATIONS.