TOUGE R ENGLISH TRANSLATION PROJECT

VERSION 0.98

12/4/2019

MODIFIED BY MRRICHARD999

This is an English translation release for Touge R for the Xbox. Everything has been translated into English except for 3 small screens which confirm a purchase, tire type (GRIP or DRIFT), and the transmission selection between AUTO and MANUAL. These issues should not be critical in playing the game. 

If someone is able to extract these graphic areas to be modified please let me know.

If any issues are present please feel free to contact me on Twitter @MrRichard999

INSTALLATION

A modified XBOX is required to play this or one that can read burnt discs. Use files included in this package and overwrite the existing original ones on a disc or stored on the hard drive of the XBOX however they are currently stored. 


