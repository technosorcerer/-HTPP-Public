---[ Translated Character Dialog Files for Drihoo ]---

For much more about this game and my translation project visit: bit.ly/drihoobook


[ RELEASE HISTORY ]

1.0 - September 2022 - Initial Release
1.1 - October 02, 2022 - Updated README.txt



[ WHAT IS THIS ]

Included in this zip file are 16 .tsc files which have been edited from their original Japanese format to include English text. This will replace most of the dialog seen in the game but not the in-game menus or certain pop-up text prompts.

I do not read or speak Japanese. This translation was made with the help of Google Translate and, later, DeepL Translator. Efforts were made to keep the dialog as close to the original intention as possible while localizing some elements to read more naturally to native English speakers.



[ HOW TO USE THIS WITH ORIGINAL XBOX HARDWARE ]

Once you have the game copied to your internal Xbox hard drive, connect to it (FTP, etc.) and browse to the directory where Drihoo is installed. In most cases that should be 'F:\Games\Drihoo'

Navigate the folders to 'Drihoo\Media\talk' and replace all the files there with the 16 files included in this zip folder.

Launch the game and enjoy!



[ HOW TO USE THIS WITH AN XBOX EMULATOR ]

You would need to acquire a copy of the game in a digital format (ISO, etc.), extract its contents on a PC to browse its file structure, copy the files from the included zip, and then create a new disc image that the desired emulator can launch. I can't help much more there as I have not used an Xbox emulator myself.

