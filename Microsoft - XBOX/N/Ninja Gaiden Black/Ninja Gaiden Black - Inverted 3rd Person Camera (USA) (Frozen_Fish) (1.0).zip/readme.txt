NINJA GAIDEN Black Camera Invert Patch

This patch inverts the 3rd person camera controls to align with modern TPP game defaults (i.e. up orbits the camera down, left orbits the camera right).
First person controls are untouched and remain configurable from the game's settings menu.

Your input "default.xbe" should match the following:

Title: NINJA GAIDEN Black
Title Id: TC-013
Region: NTSC

Size in bytes: 4571136
SHA-256: 5FA3997B0D518A9DB3867CA6AE2942C99E5349FD138F536FF56772E1A0202200
