For README, visit:
https://github.com/DerekPascarella/CoolCoolToon-EnglishPatchDreamcast