Capcom vs SNK Pro - Millennium Fighter 2000 (English)--------------

This is patch that converts the Dreamcast version of CvS Pro to English. 
It converts the following for English:
-System menus
-Move names
-Win Quotes
-Boss quotes
-Endings
-Online Mode

Which is everything, basically.


What's New in This?-------------------------------------------------

There's a lot that's new in this over the original English:

-Almost all win quotes, endings, and boss dialogues are re-translated, mostly just to keep character consistency
-The VS and Partner win quotes are all newly translated. All roughly 4500 of them. You are unlikely to ever see even a quarter of them, but hey, they're all in there.
-The move names are cleaned up and appropriately translated for several characters who had some odd translation choices. Generally the theme of translating certain moves that don't typically get translated has been kept, as in the original, but it's hopefully more appropriate / encapsulates the identity of the moves.
-For all of the above, you could say that concepts like swearing, religion, or saying "Genocide" in the case of Sagat and Rugal has been retained. There's not a ton of that in the original, but where it popped up originally, it's there.
-The command list attack indicators have been changed from generic Dreamcast controller buttons that didn't change even if you swapped inputs, to the more traditional Capcom attack indicators for punches and kicks.
-The Online mode is translated as far as I could get. At some point you can't go any further, and while all the strings are there in the event that someone gets Online to work somehow (the service is no longer up), they may be misaligned, and likely there is image-based text that is untranslated, such as for tournaments, etc.
-The Dream Passport 3 lite web browser is translated. You should be able to browse the web using this. You can even set up a serial port modem using it.
-There is a toggle in the options called "Game Theme". Normal sets the color of the life bar to green, and Original sets it to yellow. The level theme music also toggles between CvS version and original renditions.
-The Link mode lets you import your colors from the original CvS, or unlock everything for that game, and this patch will ensure it works with the English version of that game. Tested with the US version on real hardware, at least.


How to Patch--------------------------------------------------------

Get your favorite XDelta patcher and dump your copy of CvS Pro for the Dreamcast to GDI.
Track03.bin should have a CRC of A01D121F

Once patched, your track03 should have a CRC of 18E4CD7E

The just load it up in an emulator or on real hardware. Easy.


Thanks--------------------------------------------------------------

I want to thank Rob2D for paving the way on the decryption and encryption of the Capcom Naomi LZSS format.
I was able to build scripts based on his great work there. Check out https://modnao.vercel.app/ if you want to do some stuff yourself, as his website handles so much stuff for Naomi all within a web browser.

I also want to thank Derek Pascarella (ateam) for his pro tips. He's a good dude, and you, like me, have already played and enjoyed a number of his hacks.

Lastly, I gotta' thank Deuce (Moriyamug, Price of Reason, PricePartDeux) for anything SNK related, as he's a great source of inspiration and encouragement for this stuff as well. I tried not to bug him too much regarding this project, but he was always a helpful ear when I needed it.


Notes----------------------------------------------------------------

There are about 5 lines between CvS and CvS2 that are different, but all the rest of the win quotes, are identical. Due to the nature of translation differences between people / groups, what you see here will still likely be different than what you may read online or be in other translation hacks for CvS2, though undoubtedly there will still be a lot of crossover.

For the actual 5 unique lines, it's some slight changes in characters. For example:
Chun-Li original admonishes Ken for not considering his wife
Zangief is a bit more friendly to M. Bison
Kim mistakes Zangief for Chang, but he can't do that in CvS2, sine Chang is actually in the roster.
etc.

Also, for the added feature of altering the life bar color, there's a hidden override for that as well.
Set player 2's rumble to On, and the bar will always be green, regardless of Theme setting.
Set player 2 and player 1's Vibration to On, and it will always be Yellow.
Rumble packs don't need to be inserted in either case, and setting Player 1 to On or off has no effect if Player 2 is unchanged.

In regards to the translated Web Browser, people can feel free to use that in their projects if they wish.