"Cannon Spike"
Traducci�n al Espa�ol Ver. 1.0 (29/02/2019)
por Max1323 (maxmuruchi@gmail.com)
---------------------------------------------------
Descripci�n:
En el a�o 20XX DC, un grupo de robots terroristas causa estragos en el mundo y sus ciudadanos. El Anti Robot Squad Special Forces ha sido creado para derrocar a estos robots radicales. Con un arsenal de armas y botas de motor de alta potencia, debes liderar una valiente legi�n de siete miembros a trav�s de m�ltiples niveles de terror rob�tico, grandes jefes y otros males. Prep�rese para lo �ltimo en velocidad, estrategia y potencia de fuego.

Desarrollado: Psikyo
Publicado:    Capcom
Lanzamiento:  21/12/2000 (JAP)
              14/11/2000 (USA)
              03/05/2002 (EUR)                           
---------------------------------------------------
Acerca del proyecto:
Se tradujo los di�logos de los personajes y algunos textos
del men�.
---------------------------------------------------
Instrucciones del parche:
Utilizar Xdelta

Cannon Spike.CDI
File Size  701 MB
File MD5   e9f62ccdaf1304a40e64d591c5601f72
File SHA1  43f8ce0d82fe80734b7b2ac34e02a27982c9df16
File CRC32 04db3c7c