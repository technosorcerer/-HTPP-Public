~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
~--------------- Radirgy Audio + GFX Repairs + Analog ------------------~
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Patch version: v4
Authors: 
Riggles (Audio+GFX)
Dakrk (Stereo+Analog+tools)
Wiredcrackpot (Translation Port)

Platform: Dreamcast

Date: 2025-03-28

--- Info ---------------------------------------------------------------

- Re-encoded BGM, clean music tracks sourced from the OST CD.
(Higher quality, no more distorted bass that plagues stage 5)
- Rebalanced SFX, no longer distorts or peaks, each sound has been individually tweaked.
- Stereo BGM playback enabled. (Thanks to Dakrk for finding the function)
(originally the game music would only play in mono)
- Optional orange border removal.
- Alpha cleanup. (Edge garbage pixels in the HUD and a few other elements)
- Wiredcrackpot's Wii Script English Patch baked in. (Optional Japanese patch)
- Analog stick support with full analog movement, 
digital/dpad still works like normal. (Thanks to Dakrk's script)

Video comparing the improved audio with the original audio at the end.
https://www.youtube.com/watch?v=Egke85bK2F8

Version differences: The GC and PS2 versions have very poor texture quality but
include a 1 credit remix OST mode, and the Wii version also has audio 
issues. 

Left to do: I'd like to make these same changes to the Naomi arcade release 
which also suffers from the exact same low quality distorted 
audio as the Dreamcast version.

Changelog:
V3 - (Further alpha cleanups)
V3+1 - (adds a new optional patch that you apply last, it increases the volume of the
ABS alarm system as well as lowers the explosions making it easier to hear this if 
you're playing with low volume or in a loud environment)

V4 - Full 3D analog support!
(Further alpha cleanups), better audio mixing as the main patch 
(alt mixing with lower ABS is provided in the Old Patches folder)



--- Patching Instructions ----------------------------------------------

- Download the Universal Dreamcast Patcher by Derek (ateam):
https://github.com/DerekPascarella/UniversalDreamcastPatcher (v1.8 as of this release)

- Get a TOSEC GDI verified version of the Japanese release of the game.
"Radirgy v1.002 (2005)(Milestone)(JP)[!].zip"->".bin+.raw+.gdi"

- Start the patcher and select the .gdi 

- Select "1. Radirgy English+AudioFix+GFXFix+Analog v4.dcp" and patch your gdi.

- After it finishes patching, optionally apply "2. Border Removal ENG (Apply After, Optional) v4.dcp"
to remove the border.

- The finished patched game will be in the "2. Border Removal ENG (Optional) v4 [GDI]" folder
if you applied both 1. and then 2. 

- If you want the game in Japanese instead, then apply patch .1, then use the .2 and .3 patches 
from the "Alt Japanese Language" folder instead. 

- Lastly there's an optional lower ABS alarm you can apply to any version. 
(Not recommended as it's often too low in most setups, the alarm 
is essential for combos)

--- Thanks and Tools ---------------------------------------------------

Wiredcrackpot/ wii script english patch author
Derek (ateam)/ universal dreamcast patcher + asf-builder author
Isaac-Lozano/ radx author
Dakrk/ manatools author (would be impossible to adjust the levels efficiently without
his toolset, huge game changer)
Open Source Misc/ gditools


 




