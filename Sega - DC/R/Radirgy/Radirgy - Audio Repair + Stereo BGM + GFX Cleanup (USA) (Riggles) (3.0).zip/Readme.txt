~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
~-------------------- Radirgy Audio + GFX Repairs ----------------------~
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Patch version: v3

Author: Riggles

Platform: Dreamcast

Date: 2025-01-04

--- Info ---------------------------------------------------------------

- Re-encoded BGM, clean music tracks sourced from the OST CD.
(Higher quality, no more distorted bass that plagues stage 5)
- Rebalanced SFX, no longer distorts or peaks, each sound has been individually tweaked.
- Stereo BGM playback enabled. (Thanks to Dakrk for finding the function)
(originally the game music would only play in mono)
- Optional orange border removal.
- Alpha cleanup. (Edge garbage pixels in the HUD and a few other elements)
- Wiredcrackpot's Wii Script English Patch baked in. (Optional Japanese patch)

Video comparing the improved audio with the original audio at the end.
https://www.youtube.com/watch?v=Egke85bK2F8

Version differences: The GC and PS2 versions have very poor texture quality but
include a 1 credit remix OST mode, and the Wii version also has audio 
issues. 

Left to do: I'd like to make these same changes to the Naomi arcade release 
which also suffers from the exact same low quality distorted 
audio as the Dreamcast version.

V3 (Further alpha cleanups)

--- Patching Instructions ----------------------------------------------

- Download the Universal Dreamcast Patcher by Derek (ateam):
https://github.com/DerekPascarella/UniversalDreamcastPatcher (v1.8 as of this release)

- Get a TOSEC GDI verified version of the Japanese release of the game.
"Radirgy v1.002 (2005)(Milestone)(JP)[!].zip"->".bin+.raw+.gdi"

- Start the patcher and select the .gdi 

- Select "1. Radirgy English+AudioFix+GFXFix v3.dcp" and patch your gdi.

- After it finishes patching, optionally apply "2. Border Removal ENG (Apply After, Optional) v3.dcp"
to remove the border.

- The finished patched game will be in the "2. Border Removal ENG (Optional) v3 [GDI]" folder
if you applied both 1. and then 2.

- If you want the game in Japanese instead, then apply patch .1, then use the .2 and .3 patches
instead from the "Alt Japanese Language" folder.

--- Thanks and Tools ---------------------------------------------------

Wiredcrackpot/ wii script english patch author
Derek (ateam)/ universal dreamcast patcher + asf-builder author
Isaac-Lozano/ radx author
Dakrk/ manatools author (would be impossible to adjust the levels efficiently without
his toolset, huge game changer)
Open Source Misc/ gditools


 




