.------------------.
| Rent-A-Hero No.1 |
'------------------'
Unofficial English Translation v1.0
Sega Dreamcast


.------------------::[ Credits ]::------------------
| 
|               RENT-A-MODDERS TEAM
| 
'---------------------------------------------------
| 
| LEAD DEVELOPER/PROJECT LEAD:
| VincentNL
| 
| PROGRAMMERS:
| 
| VincentNL ( SH4 Asm )
| Nanashi   ( SH4 Asm / Compression algo )
| USC       ( Text Editing Tools )
| 
| GRAPHICS:
| Egregiousguy ( 3D models / 3D animations )
| Danthrax     ( VMU animations )
| Richterw     ( VMU animations )
| Togepichu    ( VMU animations )
| VincentNL    ( textures / VMU animations )
|
| TRANSLATORS:
| CurtainFire
| Korp13
| Shark
| Togepichu
| Ensoku
| Frogacuda
| PSXCraver
| Chmcl
| Ghaleon
| Rob2d
|
| TECHNICAL SUPPORT:
|
| Zychion  ( New data and scripts testing )
| Deluxx   ( Server for QBMS text data analysis)
| Esppiral ( Wide screen patch )
|
'---------------------------------------------------
|
| BETA TESTERS:
| 
| ToddlerPichu ( Togepichu )
| Cicadas-dc
| Guimli355
| Charisma103 ( Mkol103 )
| Sdesiena    ( Steve DeSiena )
| IncredibleMeltingMatt
| MadMatMax
|
| SPECIAL THANKS:
| 
| RAH Xbox localization prototype
| Derek Pascarella ( ateam )
| Zocker_160
| Exant
| Dreamcast-Talk Community
| Romhacking.net Community
| The Dreamcast Junkyard
| The Hidden Palace
| Rolly
| Dubcity
| Guimli
| Treamcaster
| ProstatePunch
| Stephon Kirkpatrick
| Nightsb
| VincentNL Patreons
|
`---------------------------------------------------


.-----------::[ Patching Instructions .GDI ]::-----------
|
| The .DCP patch file shipped with this release is designed for use with
| Universal Dreamcast Patcher:
|
| https://github.com/DerekPascarella/UniversalDreamcastPatcher/releases
|
| Note that Universal Dreamcast Patcher supports both TOSEC-style GDI and
| Redump-style CUE disc images as source input.
|
| 1) Click "Select GDI or CUE" to open the source disc image.
|
| 2) Click "Select Patch" to open the .DCP patch file.
|
| 3) Click "Apply Patch" to generate the patched GDI.
|    - The patched GDI will be generated in the folder from which the
|      application is launched.
|
| 4) Click "Quit" to exit the application.
|
`---------------------------------------------------


.-----------::[ Patching Instructions .CDI ]::-----------
|
| The .xdelta patch file shipped with this release is designed for use with
| Delta Patcher:
|
| https://www.romhacking.net/utilities/704
|
| 1) Click the first folder and select the original JP release .cdi
|
| 2) Click the second folder and select .xdelta patch file.
|
| 3) Click "Apply Patch".
|    - The original .cdi will be the patched
|
| 4) Exit the application.
|
`---------------------------------------------------



.-------------::[ Redream / Retroarch / Flycast *WARNING* ]::------------
|
| You NEED to use a Dreamcast bios file in order to play it without issues or freezes!
|
| Redream:              boot.bin
| RetroArch/ Flycast:   dc_boot.bin
|
|---------------------------------------------------
| Please note: *HLE BIOS* needs to be disabled!
|
| HLE BIOS issues reported: "Dark menus", "NOW LOADING" freeze after using subway
|
`---------------------------------------------------



.------------::[ v1.0 Release Notes ]::-------------
| 
| In 2000, I eagerly awaited the English Dreamcast release of Rent-A-Hero No.1, 
| but it never materialized until 2017, when an unfinished Xbox localized prototype
| version appeared on hiddenpalace.org.
|
| During the pandemic, I dedicated my free time to reverse engineering Naomi games
| for modding Naomi Library 3D format. To venture out from the arcade zone, 
| I decided to take on the challenge of an unknown DC file format. 
| Dreamcast-talk forums (thanks Derek!) were discussing Rent-A-Hero No.1 text data
| format which prevented any translation from happening, making it the perfect target.
|
| The Xbox prototype text data couldn't be used on DC due to the file archives 
| being totally different. To port text, had to reverse both formats, 
| write scripts to extract and convert, and ultimately reassemble data into
| .SNR archives + chunks.
|
| On February 9th, 2021, the first proof-of-concept video was released, 
| and positive feedback encouraged me to begin disassembly and setting
| up a translation process.
| Rent-A-Modders team grew in numbers and quality, with outstanding translators
| such as Korp13 and CurtainFire, who have diligently tackled thousands of 
| untranslated lines.
|
| The project stepped up with the contributions of fellow reverse engineers
| like Egregiousguy and Nanashi. Egregiousguy made brand new 3D content and animations
| for the game and Nanashi's SH4 work on font and decompression algorithms
| prompted me to create brand new features for the game.
| I loved coding over 60+ functions,in particular Name entry, Debug menu,
| VMU animation system, subtitles, and new SECAMAIL interface controls
| with the analog stick.
|
| A special mention goes to Togepichu, who tirelessly worked on multiple
| playthroughs to find over 200+ bugs that needed fixing.
|
| Although the journey was challenging, it was always fascinating and rewarding
| to overcome seemingly insurmountable challenges together.
| 
| 
| Today, on May 1st, 2023, I am proud to announce the first unofficial 
| English version of Rent-A-Hero No.1 for Sega Dreamcast, which includes:
| 
| - Complete English translation
| - Over 60 new exclusive functions
| - Opening / Ending subtitles
| - New 2D/3D content
| - New VMU animations
| - New Debug modes
| - Bug fixes of original code
| - Bonus content
| 
| I'd like to give special thanks to all the active fans and developers in 
| the Dreamcast community who've kept the spirit of our beloved console alive and well! :)
|
`---------------------------------------------------


.-----------------::[ Legal Discalimer ]::-----------
|
| Unofficial Rent-A-Hero No.1 English Patch is a recreational project and has
| no relation with SEGA, the original Rent-A-Hero No.1 team, or Xbox localization team.
| This free patch is meant to be used on a legally obtained disc backup and it is strictly
| forbidden to distribute it as patched .GDI /.CDI. 
| Those who distribute it illegally or ask for money for a patched disc have no affiliation
| with VincentNL, Rent-A-Modders team, and are solely responsible for their actions.
|
| By using hereby unofficial Rent-A-Hero No.1 English Patch, you agree that you do so
| at your own risk. The creators of this patch will not be held responsible for any damages
| that may arise from its use or illegal distribution.
|
| Additionally, unofficial Rent-A-Hero No.1 English patch is not endorsed, licensed, 
| or sponsored by SEGA, the original Rent-A-Hero No.1 team, or Xbox localization team.
|
| Rent-A-Hero No.1 is a registered trademark of SEGA.
| By using this patch, you acknowledge that you have read, understood, and agreed to the terms
| and conditions stated in this legal disclaimer.
|
`---------------------------------------------------


.-----------------::[ Changelog ]::-----------------
|
| -> 2023-05-01 (v1.0)
|      -Initial release.
|
`---------------------------------------------------


For bug reporting or any other info, you can find me on...

 -> Twitter: https://twitter.com/VincentNL_
 -> YouTube: https://www.youtube.com/@wrarwa
 -> Patreon: https://www.patreon.com/VincentNL
 -> Ko-fi: https://ko-fi.com/vincentnl
 -> Dreamcast-Talk: https://www.dreamcast-talk.com/forum/memberlist.php?mode=viewprofile&u=12555
 -> Romhacking.net: https://www.romhacking.net/forum/index.php?action=profile;u=104296