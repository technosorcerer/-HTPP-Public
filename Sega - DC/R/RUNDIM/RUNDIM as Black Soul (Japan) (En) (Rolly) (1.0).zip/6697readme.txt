﻿
             _        .a'---'a.
              \-_     / -. .- \    
               /_"-__| (@)^(@) |__---__-'
              __--___""-_\ /_-""____/_  
             /       "":YHiHY;""     \    
           .'  .        '''''         '.  
         ROLLY FROM SEGA-SKY PORTAL PRESENTS:

RUN=DIM as Black Soul for SEGA Dreamcast - japanese to english translation. Ver.1.0 (10.2022)
(c) IDEA FACTORY
Serial Number: 	T-46201M / NTSC-J

If you like the project - please support us via PayPal / CreditCard at link : https://www.paypal.me/segasky

*** ABOUT GAME ***

RUN=DIM as Black Soul (ランディム アズ ブラックソウル) is a turn-based strategy RPG for SEGA Dreamcast, made by Idea Factory & Yuki & Digital Dream Studios. Must-play for fans of series such as Front Rayblade, Sunrise Eyiuutan, Super Robot Wars or Front Mission.
Game is fully translated to english, thanks to a great job by RafaMGam - our brilliant translator. 
From now on, you can play and experience this hard&challenging tactical title!
It has been tested to work on emulators and real Dreamcast hardware.

***  LINKS  ***

* All Download links is avalaible on : http://sega.c0.pl/romhacking_mods_translation.html
* Useful SEGA Dreamcast Translation Tools Pack is avalaible on : www.mediafire.com/file/9ymrs1lvjxnxsn2/SEGA_Dreamcast_Translation_%2526_Hack_Tools.zip
* Old webpage : http://www.tv-tokyo.co.jp/run/game.html
* Promotion Music Clip 「Heaven Knows」 by Nana Mizuki : https://www.youtube.com/watch?v=2uPBmaO2FI4

*** LOCALIZATION TEAM ***

Rolly - project head, translation, implementation, hack, GFX, video, web, playtest
RafaMGam - lead translator
esperknight - romhacker & Atlas/text implementation specialist

*** CHANGES ***

- Translated all dialgos, mission, items, menus and graphics
- Subtitles on videos (wait in main menu, it's a pity that only used 320x240 resolution)
- Removed loading screens
- Bigger font in menus
- Nothing downsampled in GDI version
- Support for real hardware, GDEMU, emulation
- Region FREE & VGA support
- The game has a weird security feature, if you want to add a cover 0GDTEX.PVR, you have to delete some file ex. DIGI.BIN, otherwise the game will freeze in game main menu. 

*** How to Patch a GDI Version of the Game ***
Use Universal Dreamcast Patcher, on your org. GDI image (T-46201M), and the .dcp file included with this patch.
Run UDP choose GDI & .DCP file and the rest should be self-explanatory.
Download Universal Dreamcast Patcher here:
https://github.com/DerekPascarella/UniversalDreamcastPatcher/releases/
Get the regular ZIP, not the source code.
Remember about credits and feel free if you want make a CDI image.

*** TIPS (spoilers!) ***
- just in case, use as many slots for saved games as possible (only 38 blocks), sometimes he will have to approach the mission in several ways.
- game level jump a lot after about 40% of the game, don't waste your funds & support items!
- zero funds after non-scenario missions = game over
- scenario missions can be repeated, thus increasing the character's (not RB) EXP & parameters.
- in very heavy missions better choice si surrender / avoid combat, e.g. when the enemy destroys the transporter - financial losses in the mission summary are then very small.
- in one of the missions, Hiroko will take heavy damage, you will have to choose who to assign the new mech to. My suggestion? Give it to the character sitting in the Long Range Models.
- rifles and launchers are quite costly, limit them to a mininium in the first missions.
- the best characters to develop are Yutaka and Laon, but remember that at the end of the game he will have to field all characters divided into two teams.
- etc. rare found - game use unknown "Nindows 2" variation

*** Thanks to ***

- VincentNL (hacking help and Nindows2 info)
- Cargodin, megavolt85 & DC-Swat, japanese-cake, Deunan
- Derek Passcarella, Speud, SiZious, BlueCrab, Kazade, Shuouma
- Dreamcast-Talk, Sega Xtreme, SEGA-SKY web portals
- All Dreamcast scene & SEGA Fans around the world

*** Contact, info, links ***
Paypal Support : https://www.paypal.me/segasky
SEGA-SKY Portal (PL) : http://sega.c0.pl/
Youtube : https://www.youtube.com/c/SEGASKYPortal
Twitter/Rolly : https://twitter.com/SEGA_SKY 
Twitter/Esper : https://twitter.com/EsperKnight
Rafa RHDN : https://www.romhacking.net/forum/index.php?action=profile;u=78632
Discord : https://discord.gg/FyRJpQj
