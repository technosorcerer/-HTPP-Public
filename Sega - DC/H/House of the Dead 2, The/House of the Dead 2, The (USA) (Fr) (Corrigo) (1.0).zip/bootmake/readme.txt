   [big_fury]
  888888888    8888  888888888888  8888     888888888     8888      8888   888888888
8888888888888  8888  888888888888  8888   8888888888888   8888      8888 8888888888888
8888     8888              88888         8888       8888  8888      8888 8888     8888
888888888      8888      888888    8888 8888         8888 8888      8888 888888888
  8888888888   8888     88888      8888 8888         8888 8888      8888   88888888888
       888888  8888   88888        8888 8888         8888 8888      8888         888888
8888      8888 8888  88888         8888  8888       8888  8888      8888 8888      8888
8888888888888  8888 88888888888888 8888   8888888888888    888888888888  8888888888888
  8888888888   8888 88888888888888 8888     888888888       8888888888     8888888888

BootMake
========

Version : v1.1
(C)reated by [big_fury]SiZiOUS
http://sbibuilder.shorturl.com/

I) What's that
--------------

This program is a very simple GUI for CDI4DC. It uses mkisofs (for creating the ISO), ipinj 
(for inserting the IP.BIN in the generated ISO) and cdi4dc (ISO to CDI).

II) How to use it
-----------------

Extract the latest release of cdi4dc in the Tools directory. Run the proggy. In the first field,
select your source directory (where Dreamcast files are located). You can add a custom IP.BIN if you
want and change the temp ISO image location. And in the last field, enter your disired CDI.

You can change the CD label if you want.

After doing this, just click Make.

III) Credits
-------------

This proggy's dedicaced to Ron - Today it's the 6 july, happy bday amigo
Greetings to Xeal, DeXT, Heiko Eissfeldt and Joerg Schilling for libedc

SiZ! for Dreamcast-Scene 2006... The legend will never die