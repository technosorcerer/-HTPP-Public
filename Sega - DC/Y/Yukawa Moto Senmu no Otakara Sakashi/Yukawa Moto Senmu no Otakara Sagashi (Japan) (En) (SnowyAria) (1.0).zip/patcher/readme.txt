Universal Dreamcast Patcher v1.2
Written by Derek Pascarella (ateam)

For full usage instructions and details, visit:
https://github.com/DerekPascarella/UniversalDreamcastPatcher/blob/main/README.md