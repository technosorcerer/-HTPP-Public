~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
~------------------- Skies of Arcadia - Perfect 60Hz RGB+VGA (Desync Fix) --------------------~
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Patch version: v2.0

Author: Riggles

Platform: Dreamcast

Date: 2025-02-10

--- What it does ------------------------------------------------------------------------------

This patch fixes all of the issues with the 60Hz patched PAL version by Japanese_cake.
Undoing the various PAL optimizations to make this the perfect release for all region Dreamcast 
users with CRT TV's (15kHz RGB) as well as those wanting to play the game in either English, 
Spanish, German or French with intended animation timings at 60Hz RGB, VGA and Composite.

- Audio in cutscenes are all in sync 1:1 with the JP/US release, no more drifting delayed audio. 
- SFX's are also reverted to the JP/US release ones as these also were 50Hz optimized.
- Walking speed is now the exact value as the JP/US release.
- Region-Free

Skye from the Skies of Arcadia discord is working on a big QoL improvement hack based on this 
release, if you're on the fence on playing the game, consider waiting for it.
It'll both restore censorship and re-balance things like the notoriously high encounter rate, 
restoring the website function and touching up various other aspects of game.


V1.1
- Fixes intro cinematic, one of the few streamed music tracks. 
Turns out they sped up the animation to match the PAL speed, unlike other music that's tied to midi tables.
This is now reverted to the US files and doesn't desync anymore.

V2.0
- Fixes Spanish/French/German mode texture loading for streamed audio cutscenes (black text on white intro screen)
Additionally did a full search through all of the ~400 script files to confirm if there are any PAL optimizations left.
Fixed ending cinematic timings (probably still worked in v1.1, but now has the intended file with PAL optimizations undone instead)
I undid optimizations in the 250A scripts (identical on both discs), unused duplicate ending data, real ending is in 298A, 
removed the optimizations anyway. Upgrade to 2.0 to be sure you won't encounter any desyncs with the ending.
This should be the Final version release as all script files have been analyzed. 

GDEmu info, unrelated to this mod and happens to all retail releases of Skies of Arcadia:
pre-v5.20 firmware will get an intro animation freeze at the final 20 seconds (pressing start works like normal here),
upgrade to v5.20 which updates disc access speeds, hopefully there's a fix for this minor issue for those stuck with v5.15.

---Patching Instructions ----------------------------------------------------------------------

- Download the Universal Dreamcast Patcher by Derek (ateam):
https://github.com/DerekPascarella/UniversalDreamcastPatcher (v1.8 as of this release)

This patch should be applied to the TOSEC .gdi PAL release 
"Skies of Arcadia v1.000 (2001)(Sega)(PAL)(M4)(Disc 1 of 2)[!]"
"Skies of Arcadia v1.000 (2001)(Sega)(PAL)(M4)(Disc 2 of 2)[!]"

- Start the Universal Dreamcast Patcher

- Select "Disc 1 Skies of Arcadia - Perfect 60Hz RGB+VGA (Desync Fix).dcp" and select the gdi.

- Select "Disc 2 Skies of Arcadia - Perfect 60Hz RGB+VGA (Desync Fix).dcp" and select the gdi.

If you still want the incorrect faster walking speed from the Japanese_cake release you can 
follow the instructions further down. Admittedly movement being slightly faster does
feel pretty nice. It only affects movement (ie walking-running) as climbing, attacks etc were
all unoptimized for the PAL release, so those all play at the correct speed here.

--- More Info ---------------------------------------------------------------------------------

The cutscene audio desync is due to midi tables (.msb located in the .mlt containers) 
being timed differently in the PAL release. Sound effects were also altered. 
This patch replaces these with the ones from the US release to make it all play like it should.
The only other difference is the walking speed, which this patch restores to the US/JP value.

Here's a clip of what the previous 60Hz patch did to cutscenes:
https://imgur.com/d8DSEdh
Note how delayed the gate breaking sound is. Cutscenes in this restored version have been
timed with the US release to ensure everything plays as intended.

This release isn't 50Hz compatible, everything will just be slower and desync the opposite way. 

--- Optional Faster Walking patching-----------------------------------------------------------

Default US/JP walking speed is 1.7 (9A 99 D9 3F) which is already restored here, 
but if you want the incorrect 2.04 speed some people prefer, do the following steps:

- Open track03.bin in a Hex Editor, HxD for example. You'll need to do this same change to 
both disc 1 and disc 2 track03.bin's.

- Find the following line (Ctrl-F)
00 00 00 00 9A 99 D9 3F EC 51 B8 3F EC 51 38 3F 00 00 80 3F 00 00 80 40 00 00 00 00 9A 99 D9 40

- Replace that line with the the following (Right-Click Selection -> Paste-Write)
00 00 00 00 5D 8F 02 40 EC 51 B8 3F EC 51 38 3F 00 00 80 3F 00 00 80 40 00 00 00 00 9A 99 D9 40

(Be sure you use Paste-Write "ctrl-b" and not Paste-Insert "ctrl-v")

(This is actually located in the 1ST_READ.BIN at address 0x3631E4)

-----------------------------------------------------------------------------------------------

Thanks to:

Japanese_cake - For the original 60Hz VGA patch.
Pomegd and Noseguy - For investigating the original float values for the walking speed.
Derek (ateam) - For tips with setting up the ROM disassembly and memory searching.
Angelrenard and Wonder-inc - For confirming no desync with VGA+RGB 60Hz on PAL+NTSC-U Dreamcasts.
Skye - For working on a Quality of Life project that builds on this release as a base.