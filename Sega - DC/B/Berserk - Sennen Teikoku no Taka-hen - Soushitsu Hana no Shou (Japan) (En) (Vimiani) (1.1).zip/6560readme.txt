
     Berserk: Millennium Falcon Arc - Flowers of Oblivion English Patch
                                Version 1.1

Sections:
1: Overview
2: Installation
 a: GDI Patch
 c: CDI Patch
3: Credits
4: Other stuff
5: Changelog

  =========================================================================
                             ---1: Overview---                             

English translation for Berserk: Millennium Falcon-hen - Wasurebana no Shou
for the Sega Dreamcast. All story dialogue, menus, and extra content is
translated. Patch has been tested on Flycast, a real Dreamcast using a GDEMU,
and a real Dreamcast using a burned CDI file.

This game is a side-story of the Berserk manga series, which was written by
Kentaro Miura. The game was localized under a different title, "Sword of the
Berserk - Guts' Rage" in 2000, and was the first piece of Berserk media to
ever receive an official translation, two years before the 1997 anime's dub
was released, and three years before Dark Horse Comics started publishing the
manga in the United States. As such it was greatly lacking in established lore
context that the Japanese release of the game had, and many lines were
destroyed during localization due to that lack of context.

This patch is a complete re-translation of the game from scratch, and aims to
be understandable mainly to any previous fans of the Berserk manga series,
I personally do not recommend playing this game at all if you have not read
Berserk, as honestly the game isn't very good outside of its Berserk-ness.
I also would not advise any fans of the Berserk manga to play this before at
the very least completing the Conviction Arc of the series. The game came out
during the middle of the Conviction Arcs release in Japan, but canonically
takes place somewhere between the events depicted in volume 22 and volume 23
of the series, so playing it between then during a read would be ideal.

This patch follows the Dark Horse Comics English release of the manga when it
comes to things such as characterization and terminology. Including the use of
"Behelit" and the jumping between "Hawk" and "Falcon" as translations for 鷹.
The only Exception to this is the game's title, Dark Horse translated the arcs
title in the manga as "Hawk of the Millennium Empire Arc", completely ignoring
the "ミレニアム・ファルコン" furigana and translating the kanji straight. I think this
is really stupid and so I will call this name by its original title.

It has been several years since either person on the team has actually read
through the manga, so there is likely to be errors, if anyone spots any, feel
free to contact me on Discord (vimiani#7210) or email me (vimiani@protonmail.com)

  =========================================================================
                           ---2: Installation---                           

  a. GDI Patch
Tested on "Berserk - Sennen Teikoku no Taka-hen - Soushitsu Hana no Shou
v1.001 (1999)(ASCII)(JP)[!]", with a track03.bin CRC32 of A9A304FD

1. In the GDI folder, open "Universal Dreamcast Patcher.exe"
2. Click "Select GDI or CUE" and then navigate to your Berserk GDI.
3. Click "Select Patch" and then navigate to the "Berserk DC (English v1.1).dcp"
   in the patch folder.
4. Click "Apply Patch" and then press "Yes" when asked if you are ready to proceed.
5. Wait for the patching process to complete, and then your patched GDI should work.

 --------------------------------------------------------------------------

  b. CDI Patch
Requires "berserk (Japan).cdi", with a CRC32 of 9E3FA05F

1. In the CDI folder, open "xdeltaUI.exe"
2. In the "Patch" field, click "Open..." and then navigate to the "Berserk DC
   (English v1.1).xdelta" file in the patch folder
3. In the "Source File" field, click "Open..." and then navigate to your game CDI
4. In the "Output File" field, click "..." and then navigate to wherever you
   wish to put your patched CDI file
5. Click "Patch" and then wait for the patching process to finish, if you
   get a checksum mismatch, your game CDI likely isn't compatible.

  =========================================================================
                              ---3: Credits---

Translation: Catasplurge
Hacking, Images, Patch: vimiani
Editing: vimiani, Gem

---Special Thanks---
jackic for helping me figure out how to patch a CDI, and also how to get to
the text used for one specific scene in the game that's stored differently
for some reason. Probably couldn't have done it without you, thank you.

Nuttrageous - for helping me test this game on the GDEMU, as I do not own one.

derplayer - for developing the paint.net plugin I use to convert to the .PVR
image format used by the Dreamcast, and also the extractor and repacker used
for this games .TEX texture bundle format.
(https://github.com/derplayer/PDN-FileTypePVR)
(https://github.com/derplayer/DCBerserkTextureTool)

fafadou - for helping figure out how to edit the games executable and one
other file to allow for translated credits to be inserted.

  =========================================================================
                             ---4: Other Stuff---

This is all more so my personal rambling, because I need a place to say things.

I couldn't translate the opening credits because I have absolutely no clue 
which PAC file they're in or how to get them out and nobody else I know does
either, if anyone more experienced wants to help with that I WILL update the
patch with translated credits, but if not, they will stay like that.
##(Update: Patch v1.1, translated opening credits have been added.)##

Every single bit of text in this game is in the form of bitmaps, it makes it
overall easier to edit things to your liking this way, but God was it slow and
painful. If anyone is interested, message me and I can send all the source
files for this patch to you, and you will witness firsthand how disorganized
this was because I just didn't have the energy.

This game for some reason downscales all the UI textures in-game to match the
resolution of the screen, and this game (by default) uses nearest-neighbor
texture filtering for all of the UI textures, and this includes the cutscene
subtitles. This results in a terrible and uneven look on real hardware and
Emulators when running at native resolution, there is absolutely nothing I
can do about this. The silver lining here is that in emulators, when playing
at above the native resolution of 640x480, these UI textures will start to
look more and more normal the higher res it is, because it doesn't downscale
them in VRAM at all, only on screen.

This patch is my tribute to Kentaro Miura, the author of Berserk, who died
last year. His work has changed me as a person and it remains one of my
favorite works of fiction. You will be missed for a very long time.

  =========================================================================
                             ---5: Changelog---

Version 1.0 (May 24th 2022)
-Initial release

Version 1.1 (September 6th 2022)
-Opening credits have been translated
-World guide and character bios have been rid of typos
-Fixed typos and weird English in the readme (Haha...)

v1.1 is likely the final release unless issues are reported to me, as I do
not plan to change anything else otherwise.

