README (Macross M3 Colour Accuracy Patch, ver1.0)

This patch is distributed in DCP (Universal Dreamcast Patcher) patch format. Universal Dreamcast Patcher can be downloaded from the project's GitHub page.

The patch is intended for roms in GDI format, which will have a .GDI file and three .BIN files. It should work with any proper rom dump of the game, but just in case, here is the MD5 Checksum of Track 03 the files I started with:

MD5: b61f4441db8640f1dddb2efc3a2f4bda

For some reason, in this game they chose to make Max's Valkyries baby blue and Milia's pink, instead of their proper blue and red as they are in every other Macross media. This patch fixes that!
Changed Valkyries:
	VF-1J
	VF-4G
	VF-5000
	VF-9A
	VF-14
Unchanged:
	VF-3000 (their lineart is baby blue and pink, and it makes them more unique compared to the similar VF-1J)
	VF-X-11 (unfortunately due to the way the game has the textures, I am unable at present to make this one have it's pilot's custom colours, so it will stay an unpainted prototype grey for now. Possibly coming in a future update if I figure out how to do it!!

If you speak English, I have made a translation patch for this game! It should be available to download from wherever you downloaded this from.


I hope you enjoy!!

				-Netsui Ayahoshi, head of Comet Softworks




CREDITS:

Texture Editing:                           Netsui Ayahoshi
Playtesting:                               PixelatedShinobi
Direction/Lead:                            Netsui Ayahoshi