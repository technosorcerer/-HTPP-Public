README (Macross M3 English Translation Patch, ver1.0.1) (Game-breaking bug hotfix)

This patch is distributed in DCP (Universal Dreamcast Patcher) patch format. Universal Dreamcast Patcher can be downloaded from the project's GitHub page.

The patch is intended for roms in GDI format, which will have a .GDI file and three .BIN files. It should work with any proper rom dump of the game, but just in case, here is the MD5 Checksum of Track 03 the files I started with:

MD5: b61f4441db8640f1dddb2efc3a2f4bda

The story segments and comms are both 100% translated. All image-based text (as far as I know?) in the game is translated. (Probably) all system text (VMU operation such as saving/loading, plugin descriptions, ect) is translated. What is not translating is briefing text, which for the most part never will be due to lack of native subtitles.
It is recommended to use this with my colour accuracy patch, which should be available to download from wherever you downloaded this from.


I hope you enjoy!!

				-Netsui Ayahoshi, head of Comet Softworks




CREDITS:

Translation:                               Netsui Ayahoshi
Programming Assistance:                    Senryoku
Playtesting:                               PixelatedShinobi
Direction/Lead:                            Netsui Ayahoshi