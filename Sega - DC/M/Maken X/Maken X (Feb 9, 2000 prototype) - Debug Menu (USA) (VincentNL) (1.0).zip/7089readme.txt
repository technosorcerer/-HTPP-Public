---------------------------------------------
  Maken X (Feb 9, 2000 prototype) Debug Patch

  By VincentNL 24/08/2022
---------------------------------------------



-----------------
1) How to Install
-----------------

- Download "Universal Dreamcast Patcher"
https://github.com/DerekPascarella/UniversalDreamcastPatcher/releases/download/1.3/Universal.Dreamcast.Patcher.v1.3.zip

- Extract "Maken_X_(Feb_9,_2000_prototype).7z" to create "Maken_X_(Feb_9,_2000_prototype)" folder.

- Open "Universal Dreamcast Patcher.exe", click on "Select GDI or CUE" and choose disc.GDI inside located in game folder.

- Click on "Select Patch" and choose "Maken X (Feb 9, 2000 prototype)_Debug.dcp" file, then Click on "Apply Patch".

- Once done a new folder will be created automatically: "Maken X (Feb 9, 2000 prototype)_Debug [GDI]".



-----------------
2) How to use
-----------------

- Enter in game ("New Game or Load Game")

- Press L+R+Y+UP to enable/disable Debug mode, you'll see Nindows cursor with debug numbers appearing on top-left corner.

- Once debug is active, press A+B+X+Y+START to reach stage select debug screen



------------------------
3) Nindows / Debug info
------------------------

- Nindows cursor use P1 controller directions and buttons to operate menus.



---------
 Credits
---------

* Laurent Espirral for testing new Debug activation function!
* Derek for "Universal Dreamcast Patcher" and great support


-------------------
 Legal Disclaimer
-------------------

This patch is intended for private use on legally own backup copy.
Any copyright infringment / illegal distrubution packed with rom/isos are exclusive responsability of who distributes them,
lifting VincentNL from any legal responsability.