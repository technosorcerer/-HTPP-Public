             _        .a'---'a.
              \-_     / -. .- \    
               /_"-__| (@)^(@) |__---__-' 
              __--___""-_\ /_-""____/_  
             /       "":YHiHY;""     \     
           .'  .        '''''         '.  
             SEGA-SKY PORTAL PRESENTS:

The Last Golem (Golem no maigo) for SEGA Dreamcast - japanese to english translation. Ver.1.0 (12.2019) 
Serial Number: T-41501M / NTSC-J

About game:
You play as a golem and must guide a king in a castle to safety. The king walks by himself and turns when he bumps into a wall, so you must move walls around to guide him to exit.
The Lost Golem sold under 500 copies, making it obscure and relatively rare&hard to find.
Dricas Homepage Archive (currently not on SEGASKY server) : http://web.archive.org/web/20021021225712fw_/http://golem.dricas.ne.jp/top.html 

Game is fully translated to english. Menus, descriptions, gameplay graphics, dialogs, ending movies and icons. We added also all DLC archive saves available directly from Golem Net option. 
Patched files work on real SEGA hardware and emulators like Redream, NullDC, Demul, Makaron or etc. 
For free, without external patcher - just use a simple LazyBoot tool or GDIBuild and overwrite your files.



*** Localization team ***

Rolly - Project head, translation, implementation, hack, GFX, playtester
RafaGam - Advanced translation, proofreader, playtester
Cargodin - translation

*** Changes ***

- translated all dialgos and graphics
- translated videos
- added 96 bonus saves with custom stages (DPWWW folder) and wallpapers 
- added 96 DLC & Wayback Machine & link them in Golem Net (works only on real console with modem)
- nothing downsampled
- VMU LCD hack
- VGA, 60HZ support
- support PAL, NTSC-U, NTSC-J region
- Support for .CDI (real hardware) and .GDI images (GDEMU, USB-GDROM)

*** Patching Instructions for Discjuggler .CDI ***

1. Download a LazyBoot (selfboot tool - avalible on  http://www.mediafire.com/file/qczota5hjbmkn8a/Dreamcast_Lazyboot_3.3_oketado.zip/file). Extract this one on your hard drive.
2. Put your all "The Last Golem" files from .GDI rip or .CDI image (you can extract files with GDRom Explorer by japanese cake, or any virtual drive which support DiscJuggler images) in LazyBoot "DATA" folder.
3. Copy all files from this translation .ZIP folder and overwrite all old files in DATA folder.
4. Run Lazyboot.bat from selfboot folder.
5. Click "1" or "4" for CDI image and hit Enter, next insert a NAME for your image and hit Enter. Click "Y" for hack binaries and click Enter. Wait for a few minutes - .CDI image is ready for use on Dreamcast emulators (Redream, NullDC, Demul, Flycast, Makaron etc) or burn this on blank CD, and play on real hardware or emulator. 

*** Patching Instructions for .GDI ***

1. Extract all files from your The Lost Golem GDI image with GD-ROM Explorer to GDI_PATCH/DATA folder.
2. Copy all files from this translation .ZIP to DATA folder. Overwrite all old files in DATA folder and drop 1ST_READ.BIN & IP.BIN from GDI_PATCH folder to your extracted and patched folder. This 2 files is nessesary to proper work with repacked GDI image. 
3. Open GDIBuilder & select extracted and patched DATA folder and IP.BIN.
4. Select your output folder (ex. desktop) & tick the Output raw sectors (2352 mode). Now click Create GD-ROM track.
5. Put your new Track03.bin to GDI_PATCH folder (disc.gdi, track01.bin, track02.raw is ready to use on emulators - don't modify or delete this files!). Play on real hardware (GDEMU) or emulators like Redream (perfect emulation), Flycast, NullDC, Demul, Makaron etc. 


*** Thanks to ***

- videojet (playtest)
- Sylwia (playtest)
- oketado (great selfboot tool)
- Iwakura Productions, Dreamcast-Talk, Seganet Discord, Sega Xtreme, Caramelpot staff, Eric Walker, timbearup, ckhraish, eyl2004, smellypiratemonke, rscapewell, Gumlen&Operacja Panda, Tomcio, Esperknight, megavolt85, DC-Swat and all SEGA & Dreamcast fans.

*** Contact, info, links ***

Paypal Support : https://www.paypal.me/segasky
RHDN : https://www.romhacking.net/forum/index.php?action=profile;u=1522 & https://www.romhacking.net/forum/index.php?action=profile;u=78632
SEGA-SKY Portal : http://sega.c0.pl/romhacking_mods_translation.html
Youtube : https://www.youtube.com/c/SEGASKYPortal
Twitter : https://twitter.com/SEGA_SKY
Discord : https://discord.gg/FyRJpQj
Dricas Homepage Archive : http://web.archive.org/web/20021021225712fw_/http://golem.dricas.ne.jp/top.html 

Merry Christmas for All *<|:-) 
Weso�ych �wi�t ^^