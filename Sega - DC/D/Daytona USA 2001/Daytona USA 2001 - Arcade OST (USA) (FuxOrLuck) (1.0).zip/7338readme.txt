The Remake of Daytona USA for the Sega Dreamcast came with remixed version of the original soundtracks which considered to be inferior to the original Arcade version by many.
The Arcade Soundtracks is still located on the disc but it isn't been used when racing.
 
This Hacks replace the remixed OST with the Arcade Original that are located on the Disc.
Just Patch "track03.bin" file with Xdelta and you are done.

This hack Restore:
Daytona USA - Let's Go Away (Attract Mode)
Daytona USA - Start Your Engines (Car Selection)
Daytona USA - The King of Speed (Short Track)
Daytona USA - Let's Go Away (Medium Track)
Daytona USA - Sky High (Long Track)
Daytona USA - G.A.M.E.O.V.E.R (Game Over)

The remixed versions, now only appears at the mirror tracks.