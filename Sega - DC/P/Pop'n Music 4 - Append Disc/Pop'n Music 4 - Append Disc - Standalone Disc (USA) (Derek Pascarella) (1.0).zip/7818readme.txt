For README, visit:
https://github.com/DerekPascarella/PopnMusicAppendDiscs-StandalonePatchDreamcast