<h1>Quiz #1</h1>
<table border="1">
<tr>
<td width="60%">
<b>[MIBABA]</b> "Five grains" refers to the five main types of grains. Which of the following is not one of the five grains?</td>
<td width="40%">
Chestnuts</td>
</tr>
<tr>
<td width="60%">
<b>[MIBABA]</b> "Three major grains" refer to the grains most commonly used across the world. Which of the following is included in that list?</td>
<td width="40%">
Corn</td>
</tr>
<tr>
<td width="60%">
<b>[MIBABA]</b> A question about food pairing. Which of the following do they say shouldn't be eaten with "unagi" (eel)?</td>
<td width="40%">
Pickled dried plum</td>
</tr>
<tr>
<td width="60%">
<b>[MIBABA]</b> A question about food pairing. Which of the following do they say shouldn't be eaten with pond snail, also known as "tanishi"?</td>
<td width="40%">
Soba</td>
</tr>
<tr>
<td width="60%">
<b>[MIBABA]</b> Among the following, who is said to have been the first to eat "fugu" (pufferfish)?</td>
<td width="40%">
The Jomon people</td>
</tr>
<tr>
<td width="60%">
<b>[MIBABA]</b> Which of the following ingredients is found in all cuisines around the world?</td>
<td width="40%">
Salt</td>
</tr>
<tr>
<td width="60%">
<b>[MIBABA]</b> What kind of seasoning is "shottsuru" and "nyokumam"?</td>
<td width="40%">
Fish sauce</td>
</tr>
<tr>
<td width="60%">
<b>[MIBABA]</b> Which of the following is not one of the "seven herbs of spring"?</td>
<td width="40%">
Dandelions</td>
</tr>
<tr>
<td width="60%">
<b>[MIBABA]</b> The scholar Aoki Konyou introduced the "satsuma potato" to Japan. What kind of potato is it?</td>
<td width="40%">
Sweet potato</td>
</tr>
<tr>
<td width="60%">
<b>[MIBABA]</b> Which of the following is called "yuk" in the Ainu language? </td>
<td width="40%">
Deer</td>
</tr>
<tr>
<td width="60%">
<b>[MIBABA]</b> Which of the following do we, the Ainu, eat?</td>
<td width="40%">
Deer</td>
</tr>
<tr>
<td width="60%">
<b>[MIBABA]</b> In which country did "konpeito" candy originate?</td>
<td width="40%">
Portugal</td>
</tr>
<tr>
<td width="60%">
<b>[MIBABA]</b> Which of the following is found in "kitsune udon"?</td>
<td width="40%">
Fried tofu</td>
</tr>
<tr>
<td width="60%">
<b>[MIBABA]</b> What animal does "sakura meat" come from?</td>
<td width="40%">
Horse</td>
</tr>
<tr>
<td width="60%">
<b>[MIBABA]</b> Which one of the following is Nakoruru's specialty dish?</td>
<td width="40%">
Rataskep</td>
</tr>
<tr>
<td width="60%">
<b>[MIBABA]</b> Which of these is not a real type of melon?</td>
<td width="40%">
North melon</td>
</tr>
<tr>
<td width="60%">
<b>[MIBABA]</b> What is Jubei Yagyu's favorite food?</td>
<td width="40%">
Dango</td>
</tr>
<tr>
<td width="60%">
<b>[MIBABA]</b> What is Nicotine Caffeine's favorite food?</td>
<td width="40%">
Castella</td>
</tr>
<tr>
<td width="60%">
<b>[MIBABA]</b> From what region did corn originate?</td>
<td width="40%">
South America</td>
</tr>
<tr>
<td width="60%">
<b>[MIBABA]</b> What species does the onion belong to?</td>
<td width="40%">
Lilies</td>
</tr>
<tr>
<td width="60%">
<b>[MIBABA]</b> What is the Ainu word for a dish of half-frozen salmon?</td>
<td width="40%">
Ruibe</td>
</tr>
<tr>
<td width="60%">
<b>[MIBABA]</b> What is the fish caught in the summer that we call "sakipe"?</td>
<td width="40%">
Salmon</td>
</tr>
<tr>
<td width="60%">
<b>[MIBABA]</b> What family of plants does the coffee bean belong to?</td>
<td width="40%">
Rubiaceae </td>
</tr>
<tr>
<td width="60%">
<b>[MIBABA]</b> What is a dish made by seasoning raw fish or vegetables in vinegar?</td>
<td width="40%">
Namasu</td>
</tr>
<tr>
<td width="60%">
<b>[MIBABA]</b> Carrots belong to the Apiaceae family. What plant family does ginseng belong to?</td>
<td width="40%">
Araliaceae</td>
</tr>
<tr>
<td width="60%">
<b>[MIBABA]</b> What's the name for an inn that serves meals and caters especially to samurai?</td>
<td width="40%">
Hatago</td>
</tr>
<tr>
<td width="60%">
<b>[MIBABA]</b> What's the name of the special knife used for filleting fish?</td>
<td width="40%">
Deba bocho</td>
</tr>
<tr>
<td width="60%">
<b>[MIBABA]</b> What kind of fish do our people prepare using the hang-and-cut method?</td>
<td width="40%">
Monkfish</td>
</tr>
<tr>
<td width="60%">
<b>[MIBABA]</b> People from Kyoto love clothes. People from Kobe love shoes. What do people from Osaka love?</td>
<td width="40%">
Eating</td>
</tr>
<tr>
<td width="60%">
<b>[MIBABA]</b> What is the name given to the samurai's unwritten code of conduct?</td>
<td width="40%">
Bushido</td>
</tr>
<tr>
<td width="60%">
<b>[MIBABA]</b> On the Zodiac calendar's "Day of the Ox", what food do we commonly eat countrywide?</td>
<td width="40%">
Eel</td>
</tr>
</table>

<h1>Quiz #2</h1>
<table border="1">
<tr>
<td width="60%">
<b>[HIBABA]</b> A "hayashikata" (group of Noh musicians) is divided into "kozutsumikata" (drums), "taikokata" (percussion), and "huekata". What instruments do the huekata play?</td>
<td width="40%">
Flutes and woodwinds</td>
</tr>
<tr>
<td width="60%">
<b>[HIBABA]</b> The "koto" is a large, traditional Japanese instrument. In what family does it belong?</td>
<td width="40%">
Stringed</td>
</tr>
<tr>
<td width="60%">
<b>[HIBABA]</b> From what material is a "taiko" drum head made?</td>
<td width="40%">
Animal skins</td>
</tr>
<tr>
<td width="60%">
<b>[HIBABA]</b> Which expression describes a big belly by comparing it to a musical instrument?</td>
<td width="40%">
Taiko belly</td>
</tr>
<tr>
<td width="60%">
<b>[HIBABA]</b> In what time period did the "biwa" (lute) instrument come to Japan?</td>
<td width="40%">
Nara period</td>
</tr>
<tr>
<td width="60%">
<b>[HIBABA]</b> Who is the founder of "kabuki" (Japanese dance-drama)?</td>
<td width="40%">
Okuni</td>
</tr>
<tr>
<td width="60%">
<b>[HIBABA]</b> From which dance did "kabuki" (Japanese dance-drama) originate?</td>
<td width="40%">
Yayako</td>
</tr>
<tr>
<td width="60%">
<b>[HIBABA]</b> In what year were women banned from "kabuki" (Japanese dance-drama)?</td>
<td width="40%">
1629</td>
</tr>
<tr>
<td width="60%">
<b>[HIBABA]</b> What is the closest Western equivalent to "kabuki" (Japanese dance-drama)?</td>
<td width="40%">
Opera</td>
</tr>
<tr>
<td width="60%">
<b>[HIBABA]</b> In what century did the "do-re-mi" scale originate?</td>
<td width="40%">
11th century</td>
</tr>
<tr>
<td width="60%">
<b>[HIBABA]</b> In Chinese music theory, which of the following is not part of the pentatonic scale, also known as the "five tones"?</td>
<td width="40%">
Lan</td>
</tr>
<tr>
<td width="60%">
<b>[HIBABA]</b> A "taiko" is a percussion instrument, a "shakuhachi" is a woodwind, but what type of instrument is a "shamisen"?</td>
<td width="40%">
Stringed</td>
</tr>
<tr>
<td width="60%">
<b>[HIBABA]</b> Just like the "sho" (mouth organ), which of the following is a free-reed instrument?</td>
<td width="40%">
Accordion</td>
</tr>
<tr>
<td width="60%">
<b>[HIBABA]</b> Who is credited as the creator of the "kagura" dance, performed to worship the gods?</td>
<td width="40%">
Ame-no-Uzume</td>
</tr>
<tr>
<td width="60%">
<b>[HIBABA]</b> For what purpose do our people use a deer whistle?</td>
<td width="40%">
To attract deer</td>
</tr>
<tr>
<td width="60%">
<b>[HIBABA]</b> The "Yukar" are Ainu folktales and songs handed down through oral tradition. Which of these is not a setting for a yukar?</td>
<td width="40%">
Animal world</td>
</tr>
<tr>
<td width="60%">
<b>[HIBABA]</b> Which of the following is a traditional Ainu love song?</td>
<td width="40%">
Yaikatekara</td>
</tr>
<tr>
<td width="60%">
<b>[HIBABA]</b> What's the name of the music that once played at the imperial court?</td>
<td width="40%">
Gagaku</td>
</tr>
<tr>
<td width="60%">
<b>[HIBABA]</b> How many singers participate in Ainu "ukouku" music?</td>
<td width="40%">
Multiple singers</td>
</tr>
<tr>
<td width="60%">
<b>[HIBABA]</b> Who traditionally played the role of women in "kabuki" (Japanese dance-drama)?</td>
<td width="40%">
Male actors</td>
</tr>
<tr>
<td width="60%">
<b>[HIBABA]</b> True or false? "Sho" (mouth organ) pipes are made from bamboo.</td>
<td width="40%">
True</td>
</tr>
<tr>
<td width="60%">
<b>[HIBABA]</b> What name is given to the black bamboo curtain used in performances of "geza" music?</td>
<td width="40%">
Kuromisu</td>
</tr>
<tr>
<td width="60%">
<b>[HIBABA]</b> In what sect of Buddhism do monks play the "shakuhachi" flute?</td>
<td width="40%">
Fuke</td>
</tr>
<tr>
<td width="60%">
<b>[HIBABA]</b> What name describes all traditional Japanese musical instruments?</td>
<td width="40%">
Wagakki</td>
</tr>
<tr>
<td width="60%">
<b>[HIBABA]</b> What metal is used in the casting of gong drums?</td>
<td width="40%">
Bronze</td>
</tr>
<tr>
<td width="60%">
<b>[HIBABA]</b> How many tone holes does a typical "shinobue" flute have?</td>
<td width="40%">
Six to seven</td>
</tr>
<tr>
<td width="60%">
<b>[HIBABA]</b> What is the name of a stick used to beat "taiko" drums?</td>
<td width="40%">
Bachi</td>
</tr>
<tr>
<td width="60%">
<b>[HIBABA]</b> What musical instrument is called the "baiorin" in Japanese?</td>
<td width="40%">
Violin</td>
</tr>
<tr>
<td width="60%">
<b>[HIBABA]</b> In Japanese music, what describes the distinctive sound made by striking two square oak boards?</td>
<td width="40%">
Ki and tsuke</td>
</tr>
<tr>
<td width="60%">
<b>[HIBABA]</b> What Ainu instrument is sometimes compared to the didgeridoo used by the indigenous Australians?</td>
<td width="40%">
Cirektekuttar</td>
</tr>
</table>

<h1>Quiz #3</h1>
<table border="1">
<tr>
<td width="60%">
<b>[UBABA]</b> Which "Book of the Samurai" written by Yamamoto Tsunetomo says, "Bushido is realized in the presence of death"?</td>
<td width="40%">
Hagakure</td>
</tr>
<tr>
<td width="60%">
<b>[UBABA]</b> How many cards come in a typical "hanafuda" game deck?</td>
<td width="40%">
48 cards</td>
</tr>
<tr>
<td width="60%">
<b>[UBABA]</b> Which of the following is Amakusa Shiro's real name?</td>
<td width="40%">
Tokisada</td>
</tr>
<tr>
<td width="60%">
<b>[UBABA]</b> How old was Amakusa Shiro when he led the Amakusa Rebellion?</td>
<td width="40%">
16 years old</td>
</tr>
<tr>
<td width="60%">
<b>[UBABA]</b> The "kata", which originated in ancient Chinese martial arts, pairs attack and defense drills known as "the five patterns". After what were these five patterns named?</td>
<td width="40%">
Animals</td>
</tr>
<tr>
<td width="60%">
<b>[UBABA]</b> Which of these names for plants and trees literally translates to "planted in container"?</td>
<td width="40%">
Bonsai</td>
</tr>
<tr>
<td width="60%">
<b>[UBABA]</b> After what, or whom, was nicotine, the chief active ingredient in cigarettes, named?</td>
<td width="40%">
Jean Nicot DeVillemain</td>
</tr>
<tr>
<td width="60%">
<b>[UBABA]</b> What's the name of the poison found in "fugu" (pufferfish)?</td>
<td width="40%">
Tetrodotoxin</td>
</tr>
<tr>
<td width="60%">
<b>[UBABA]</b> Which historical event is said to have included the first known use of "ninjutsu" martial arts?</td>
<td width="40%">
Genpei War</td>
</tr>
<tr>
<td width="60%">
<b>[UBABA]</b> For which style of "ninjutsu" martial arts is the Hattori clan famous?</td>
<td width="40%">
Iga-ryu</td>
</tr>
<tr>
<td width="60%">
<b>[UBABA]</b> Which of the following places in the United States is a "sister city" of Tokyo?</td>
<td width="40%">
New York City</td>
</tr>
<tr>
<td width="60%">
<b>[UBABA]</b> Who's the swordsmith made famous for his sharp "stone lantern cutter"?</td>
<td width="40%">
Kotetsu</td>
</tr>
<tr>
<td width="60%">
<b>[UBABA]</b> Which famous "yin and yang" master who lived during the Heian period?</td>
<td width="40%">
Abe no Seimei</td>
</tr>
<tr>
<td width="60%">
<b>[UBABA]</b> The "denki" eel inflicts damage to both predator and prey by producing an electric shock. True or false?</td>
<td width="40%">
True</td>
</tr>
<tr>
<td width="60%">
<b>[UBABA]</b> Who is the founder of the Yagyu Shinkage-ryu school of swordsmanship?</td>
<td width="40%">
Kamiizumi Nobutsuna</td>
</tr>
<tr>
<td width="60%">
<b>[UBABA]</b> What was the Chinese Qing dynasty originally called before being renamed?</td>
<td width="40%">
Later Jin dynasty</td>
</tr>
<tr>
<td width="60%">
<b>[UBABA]</b> "Ukiyo-e" is a type of woodblock painting that depicts "kabuki" (japanese dance-drama) actors. Who pioneered this art?</td>
<td width="40%">
Hishikawa Moronobu</td>
</tr>
<tr>
<td width="60%">
<b>[UBABA]</b> Which dinosaur is said to be the last one to go extinct?</td>
<td width="40%">
Chenanisaurus</td>
</tr>
<tr>
<td width="60%">
<b>[UBABA]</b> Which ocean is famous for the optical phenomenon "shiranui"?</td>
<td width="40%">
Yatsushiro Sea</td>
</tr>
<tr>
<td width="60%">
<b>[UBABA]</b> Which of the following is said to be the "fruit of the underworld"?</td>
<td width="40%">
Pomegranate</td>
</tr>
<tr>
<td width="60%">
<b>[UBABA]</b> Which flower is said to bring good luck and is often called the "king of flowers"?</td>
<td width="40%">
Peony</td>
</tr>
<tr>
<td width="60%">
<b>[UBABA]</b> Where on the body is the Ainu "ninkari" worn?</td>
<td width="40%">
The ear</td>
</tr>
<tr>
<td width="60%">
<b>[UBABA]</b> Shinto priests use "tamagushi" branches in certain rituals. What tree are they from?</td>
<td width="40%">
Sakaki</td>
</tr>
<tr>
<td width="60%">
<b>[UBABA]</b> Which of the following is an ancient Japanese bronze mirror decorated with gods and animals from Chinese mythology?</td>
<td width="40%">
Shinju-kyo</td>
</tr>
<tr>
<td width="60%">
<b>[UBABA]</b> A red rose symbolizes romance, but what does a yellow rose symbolize?</td>
<td width="40%">
Friendship</td>
</tr>
<tr>
<td width="60%">
<b>[UBABA]</b> Finish this Japanese proverb: "Giving birth to a baby is easier than..."</td>
<td width="40%">
Worrying about it</td>
</tr>
<tr>
<td width="60%">
<b>[UBABA]</b> Where can one find Kuro Kojima island?</td>
<td width="40%">
Nagasaki</td>
</tr>
<tr>
<td width="60%">
<b>[UBABA]</b> Which of the following are known as flesh-eating demons?</td>
<td width="40%">
Jikininki</td>
</tr>
<tr>
<td width="60%">
<b>[UBABA]</b> Who's the demon said to have challenged the god Taishakuten to a fight?</td>
<td width="40%">
Ashura</td>
</tr>
<tr>
<td width="60%">
<b>[UBABA]</b> Which period in Japan is marked by a hunter-gatherer lifestyle?</td>
<td width="40%">
Jomon Period</td>
</tr>
</table>
