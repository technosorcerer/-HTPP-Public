For README, visit:
https://github.com/DerekPascarella/NakoruruTheGiftSheGaveMe-EnglishPatchDreamcast