This is a re-implementation of the David Michel and filler patch for the dating sim "Pia Carrot e Yookoso !!" for the PC-FX. It's a nice heart-warming game, surprisingly low-kew on the erotic content. The previous patch was messing with file checksums ; it basically made it unable to run on modern emulators and (probably) real hardware. This patch fixes the issue so you're no longer forced to use Magic Engine !

This version of the patch targets the PC-FX redump version (it's the most commun dump nowadays) composed of 5 bin files and a cue file. Just use xdelta to patch track 2, and replace the cue file with the one embedded. Voilà, you're set !

All credit goes to the original patch authors.