Farland Story FX English Translation V3 by hasnopants 2025

**This is a translation update to the existing partial translation of Farland Story FX Eng V2 done by Djlpap.**
**If you are interested, I have included Djlpap's original notes in this package as well, named "Translation Notes v2"**

Installation:

1. Apply this xdelta patch to an unmodified Turborip dump of Farland Story FX's iso file only.

	ISO Unmodified MD5: 841634169EC9637FF2A7AAAE1733DE18
	ISO patched MD5: F36EFF66015EF3A2863AE88A94866BCD
	
2. Play! I have tested this on Mednafen extensively.  Only minor testing on real hardware. You may encounter crashes, if you do, I apologize, but there is still testing and bug squashing to be done with my edits most likely.  Save often!

What's changed?

	1. Formatting.  If you played V2 of the patch you'll notice now that the battle messages are much more readable and most line breaks mid sentence/word should be eliminated. You will also notice item descriptions are cleaned up of line breaks and just overall formatted better in my opinion.
	
	2. Characters, weapons, item names have been tweaked to either be a closer translation to the other games in the series or for clarity for english speaking audiences. Mission stages have also been tweaked, however there is a limitation due to the nature of this patch that only allows for certain number of characters for names and in alot of the mission names at the game's load screen you will notice the name is quite weird, this is due to this. These could be reworked at a later date.
	
    3. Quick battle messages are now translated.  Previously if you chose to do quick battle and stay outside of the cinematic battle screen when doing combat all those messages remained in japanese.  These are all now in English.

I hope to get back to this patch at a later date but for now consider this as-is indefinitely. Feel free to build off this work as I did and release an batter update!  Thanks for playing!

Josh (hasnopants) 2025