Farland Story FX English Translation by Djlpap 2021
----------------------------------------------------

Release 2: 03/03/2021
Fixed a few strings that incorrectly displayed
Added missing magic strings

Release 1: 30/08/2020

This is my first release of an English translation to Farland Story FX for the PC-FX. 
My Japanese is very limited, I've studied it only for the past two months so I've tried
to translate as best as I could. I've translated all the text that I could find in the
binary. There may be text that may be left untranslated and If time allows for another 
release, I will address them. I have also replaced the graphics text tiles for the menu
screens. Unfortunatly I was unable to replace the Video files, so the FMV are left 
untranslated.

To apply patch, please use TurboRip on your copy to generate cue/iso/wav files and then
use deltapatcher to patch the main ISO file (Track 02).

MD5 checksum values:
--------------------------------------
FSFX_Eng_R2.xdelta f89b9cf155be854ec5329def44ac3b95 (Release 2)
02 Farland Story FX [FXNHE628] (J).iso abb9fa416be4d8c0e1414601fcf19b64 (Translated Release 2)

FSFX_Eng_R1.xdelta 4cd5d641419fb70a59f14c752447d8dc (Release 1)
02 Farland Story FX [FXNHE628] (J).iso 841634169ec9637ff2a7aaae1733de18 (TurboRip)
02 Farland Story FX [FXNHE628] (J).iso ce52b9398fdcbce4d30faa4c37216514 (Translated)

Please find below my translation notes. The english text was restricted to the length of
the Japanese characters, so some sentences have been shorten and abbreviated. 

Character Status 00089E9-0008A9F:
--------------------------------------
終了		End.
可能		Free (Possible)
不能		N/A. (impossible)
気合		PoW (Ki Energy, Short Shout)
気絶		Weak (Faint)		
待機		Idle (Waiting)
名前		Name
ﾚﾍﾞﾙ		Level.
体力		STR. (Physical Strength) 
行動		Actn (Action)	
クラス		Class.
レベル		Level.
経験値		EXP...
体力		H.P.
行動		Actn (Action)
攻撃力		A.P...
防御力		DEF...
知力		INT.
魔法防御		MAG.DEF.
敏捷さ		AGL...

Characters 000BEA69-000BEB7C & 000BBF9A-000BC0A7:
--------------------------------------
アーク 		Arc...
ランティア		Randia....
アリシア 		Alicia..
ゴダール		Godard..
ドカティ		Docati..
ディーノ		Dino....
パミラ		Pam... (Pamira)
ルシーダ		Lucida..
イワン		Ivan..
ミリア		Milia.
アリーナ		Arena...
リーサ		Risa..
ウィル		Will..
カイ		Kai.
メル		Mel.
フェリオ		Felio...
ライア		Lyer..
お雪ちゃん		Yuki-chan.
エレノア		Eleanor.
イマイラ		Imeira..
ウォルター		Walter....
カイゼル		Kaiser..
ギル		Gil.
ザヴェル		Zavel...
ディヴァ		Diva....
デミトス		Demitos.
ハイゼン		Heisen..
メガデス		Megades. (Megadeth)
モハド		Mohad.
魔軍兵		Enemy. (Devil Soldier)  
魔軍隊		Officer. (Devil Army)   
ドッペルゲンガー	Doppelganger.... 
村人		VLG.
兵士		Army (Soldier)
魔軍隊長		Captain. (Demon Captain)

Character Class 000BEB80-000BED98:
--------------------------------------
ロード		Lode..
クレリック		Cleric....
マジシャン		Magician..
ソーサラー		Sorcerer..
ウィザード		Wizard....
ファイター		Fighter...
ナイト		Knight
プリースト		Priest....
ビショップ		Bishop....
メイジ		Mage..
レディナイト		Lady Night..
ドワーフ		Dwarf...
スパルタン		Spartan...
バーサーカー	Berserker...
セイレーン		Siren.....
ハイエルフ		High Elf..
バード		Bird..
ワルキューレ	Valkyrie....
エルフ		Elf...
シャーマン		Shaman....
雪女		Snow (Woman)
ダークエルフ	Dark Elf....
忍者		Nija (Ninja)
ゴースト		Ghost...
バンパイア		Vampire...
フェアリー		Fairy.....
デーモン		Daemon..
サッキュバス	Succubus....
ゴーレム		Golem...
ハーピー		Harpy...
ｼﾞｬｯｸ･ｵｰ･ﾗﾝﾀﾝ	JackOLantern.
スケルトン		Skeleton..
ｳｨﾙ･ｵｰ･ｳｨｽﾌﾟ	Will-O-Wisp.
ドラゴン		Dragon..
メデューサ		Medusa....
サイクロプス	Cyclops.....
スペクター		Specter...
リザードマン	Lizard Man..
アサシン		Assassin
黒騎士		Blk Kn (Black Night)
ダークプリンセス	Dark Princess...
女王		Quen (Queen)
妖魔将軍		DGeneral (Demon General)
魔王		Maou (Devil)
大魔王		GTMaou (Great Satan)
少女		Girl (Little Girl)
	
Weapons/Items 000BBB0D-000BBF978:
--------------------------------------
ロングソード	Long Sword..
ブロードソード	Broad Sword...
バスタードソード	Bustered Sword..
ランス　		Lance.
ショートソード	Short Sword...
シルヴァンボウ	Sylvan Bow....
ショートボウ	Short Bow...
ロングボウ		Long Bow..
リピーター		Repeater..
シルバーボウ	Silver Bow..
ハープ		Harp..
トライデント	Trident.....
サンダースピア	Thunder Spear.
スピア		Spear.
ダガー		Dagger
ハンドアックス	Hand Axe......
バトルアック	Battle Axe....
ハルバード		Halberd...
メイス 		Mace..
ウォーハンマー	Warhammer.....
レイピア		Rapier..
薬草 		Herb (Medical)
エリクサー 		Elixir....
ファイヤーロッド	Fire Rod........
聖剣		Swrd (Holy Sword)
シルフィード	Sylpheed....		
タイタニアソード	Titania Sword...
グングニル		Gungnir...
ラ・フレア		Flair.....
カボチャの種	PumpkinSeed.
妖精の涙		FaryTear (Fairy Tears)
ブロードアックス	Broad Axe.......
アイスロッド		Ice Rod.....
ライトニング	Lightning...
バーニンロッド	Burning Rod...
フレイムバード	Flame Bird....
ドカティの鍵	Docati Key..
愛の夢		Dream. (Love dream)
赤い羽		RedFin (Red Feather)
リラ		Lira
エストック		Estoc.....
ドラゴンランス	Dragon Lance..
魔術師の杖	MagicStaff (Magician's Staff)
騎士のランス	Knight Lance
アルテミスの弓	Artemis Bow...
精霊の弓		SpirtBow (Spirit Bow)
剛力の斧		Rigid Ax
吟遊詩人の竪琴	Bard's Harp...
魔除けのお札	Amulet Bill.
幸運の靴		LCKShoes (Lucky Shoes)
知識の書		WiseBook (Book of Knowledge)
モーニングスター	Morning Star....
ポールアックス	Paul Axe......
トマホーク		Tomahawk..
リュート		Lute....
力の実		Fruit. (Fruit of Power)
守護石		Stone. (Guardian Stone)
シルバーランス	Silver Lance..
ジャベリン		Javelin...
グレートソード	Great Sword...
フレイル		Flail...
ウイスキー		Whisky....
ヘビーメイス	Heavy Mace..
ホーリーランス	Holy Lance....
丸薬		Pill		
メデューサキラー	Medusa Killer...
オーディンの槍	Odin's Spear..
マッシュルーム	Mushroom......
直接		DRCT (Direct)
間接		INDR (Indirect)
直接／間接	DRCT/INDR. (Direct/Indirect)
忍び装束		Shinobi. (Shinobi Costume)
ドラゴンブレス	Dragon Breath.
吸血牙		Vmpire (Vampire)
怨念の魂		Soul.... (Soul of Remorse/Grudge)
イービルソード	Evil Sword....
黒水晶の杖	XTAL Staff (Black Crystal Staff)
デモンアックス	Demon Axe.....
忌まわしき物	Abomination.
雪の結晶		SnowXTAL (Crystal of Snow)
神秘の錫杖	Myst.Staff (Mysterious Bishop's Staff)
雷神の杖		GodStaff (Thunder God's Staff)
フレイムスター	Flame Star....
星屑の杖		StarStaf (Stardust Staff)
戦神の槍		WarStaff (War God's Staff)
スターロッド		Star Rod....
死者の剣		DeadSwd. (Dead Sword)
ヘビーランス	Heavy Lance.
暗黒の呪符	Dark Spell
紅蓮の斧		GurenAxe
ドラゴンソード	Dragon Sword..
ミラージュソード	Mirage Sword....
聖なる錫杖	Holy Staff
ゴッドランス		God Lance...
狂戦士の斧	BeserkerAx (Berserker Axe)
エレキギター	ElecGuitar.. (Electric Guitar)
ライトセプター	Light Scepter.
死の王錫		DthStaff (Death Staff)	
アイテム最大値	Items Maximum. 

Location & Misc 00005E39-0000622C & 0000FB65-000FD6C: 
--------------------------------------
未使用 		Unused
魔導の目覚め	Awaken Magic & Awakening of Magic..
ドワーフの村	DwarfVillage & Dwarf Village
裏切りの果て	End of Betrayal
精霊の森		Forest.. & Spirit Forest 
ラメ・ニクト城の攻防 	Battle Nikuto Castle (Lame・ The Battle of Nikuto Castle)
封印の島		Island.. & Sealed Island
眠りの街		Zzz City & The City of Sleep
古より目覚めしもの  	Awakening Ancient. (Awakening from ancient times)
迷いの城		Castle.. & Lost Castle
黒き闇の牙	Dark Fang. & Black Dark Fang
聖なるものたち	Holy Things...
力求めし者	Pwr Seeker & Power Seeker (Chikara motomeshi mono)
魔城		MaJo & Devil Castle
魔界		Hell & Demon World
新たなる旅立      A New Journey. (A New Departure)
よみがえる魔たち   	Reborn Demons and Resurrected Demons)
前線基地		Fnt Base and Front Base)
嘆きの村		Village and Lament Village)
幻影の城		GhtCasle and Ghost Castle
騒乱の雪原       Snow Field and Chaotic Snowy Field
ドラゴン・ロード	Dragon Road.....
最後の砦		LastFort
悲しみの迷城	SadLabyrinth and Labyrinth of Sadness
うたかたの魔界	UtakataDemonWd & Utakata Demon World (Utakata/Bubble of Demon World)
魔王の魔界	DemonKngdm and Demon Kingdom
セーブファイルが破壊されているので、削除します Save file is currupted, please delete.........
最初から   	.Begin..
続きから 		Continue
はい		Yes. 
いいえ		..No..
セーブするファイルを選んで ください	Please select a file to save.......
このファイルにセーブして よろしいですか？	Are you sure you want to save to this file
ロードするファイルを選んで 		Please select a file to     load....
このファイルをロードしてよろしいですか？	Is it OK to Load this file?............... 
ロードできるファイルが 見つかりません	No save game files are avaliable......
バックアップＲＡＭに  異常が見つかりました	The backup RAM has encounted an error.....
バックアップＲＡＭが  初期化されていません The backup RAM is not initialised.........
バックアップＲＡＭの 容量が00000 足りません Insufficient Space avaliable 00000 on RAM....
セーブできませんが よろしいですか？   は い  いいえ  Unable to save. Are you sure?......  Yes.... No......
ファイルメンテナンスで バックアップＲＡＭを   初期化してください Push [] to RESET!
ファイルメンテナンスで   不要なファイルを   削除してください Push [] to RESET!
(000BA0A9) ファイル１ ステージ 00 ターン 000 アークのレベル 00 ...File 1 .....Stage 1 ...Turn 1 .....Arc Level

Battle 00019BE2-00019C7C & 00028AF0-00028D1F & 0002E8D0-0002E8FF:
--------------------------------------
ターン		Turn 
魔軍の行動	Enemy Turn (Demon Army Action)  
アーク達の行動	Players Turn.. (Actions of Arcs)
ステーヅ		Stage
宝箱をみつけた！	Treasure Chest!. (I found a treasure chest!)
を手に入れた	Acquired.... (Acquired/Got)
しかし、これ以上持てない I can't acquire anymore! (But I can't take anymore)
GOLD		GOLD
手に入れた	I Acquired
宝箱はからっぽだった	Chest is empty!..... (The treasure chest is empty!)
__ は __ の経験値を得た! 		gain.__EXP!..... (__ has __ gained experience points)
__ は __ レベルが __ になった 	...Level __ reached!. (__ has reached level __)
__ を得た! __			recieved __
__ ＧＯＬＤを得た！ 			GOLD recieved
__ は連れ去られた！！		has been stolen!!. (was taken away!)
__ のｸﾘﾃｨｶﾙﾋｯﾄ			critical hit.....
__ は __ のダメージを与えた！		hits __ damage!!............. (inflicted damage!)
__ は力尽きた！！			is exhausted!!
__ は攻撃をかわした！		held off attacker!!. (Fought off the attack!)
__ は行動力を回復した！		has recovered energy 
__ は気がついた！！			has revived!!... (has become conscious!!)
__ は体力が 回復した！		...H.P  recovered!.. (Physical streght has recovered!!)
__ は全快した！！         		fully healed!! (was completely recovered)
__ 体力の上限が			health up by __ points. (The upper limit of physical strength)
__ 上がった！			increased
__ 攻撃力が			ATK Pwr
__ 防御力が			DEF Pwr
__ 知力が			INT..
__ 魔法防御が			Magic DEF
__ 敏捷さが			Agility
の攻撃！				Attack!.
の魔法！				Magic!..
の必殺攻撃！			Deadly Attack!
の必殺魔法！！			Deadly Magic!.

Battle Magic 1AC58080 & 1AC5FAA8 & 1AC630AA & 1AC90B40 & 1AC922B0 & 1AC9CA0A & 1ACAC2A8 & 1ACAF8AA & 1ACDD342 & 1ACDEAB2 & 1ACE9209 & 1AC6F1C0 
& 1AC82351 & 1AC92D1B & 1AC95C4B & 1AC9785E & 1AC997D0 & 1AC9EC23 & 1ACA4882 & 1ACBB9CC & 1ACCEB50 & 1ACE051D & 1ACE244C & 1ACE4060 & 1ACE5FD6 
& 1ACEB425 & 1AC64FAC & 1AC8CDD0 & 1ACB17B4 & 1ACD95D0 & 1AC71C1C & 1ACBE41C & 1AC7337E & 1ACBFB7E & 1AC74A9B & 1ACC12A1 & 1AC7AB5D & 1ACC735D
& 1AC7D54F & 1ACA1869 & 1ACC9D4F & 1ACEE06B & 1AC87613 & 1ACD3E10 & 1AC89106 & 1ACD5906
--------------------------------------
ヒールを唱えた！			Recovery magic!. 
ファイアーボール			Fire ball!......
フリーズエッジ			Freeze edge!..
フレイムバード			Flame bird....
サンダージャベリン			Thunder javelin...
フレアストームを唱えた！		Flare storm!............ (cast magic)
フレアソウルを唱えた			Flared soul!.......... (cast magic)
プラネットレイを唱えた！		Planet ray!............. (cast magic)
スターゲートを唱えた！		Stargate!............. (cast magic)
ライトニングボルト			Lightning bolt....
エレックバーンを唱えた！		Electric burn!.......... (cast magic)
キュアを唱えた！			Cure spell!..... (cast cure)	
カースドバレットを唱えた		Cursed bullet........... (cast magic)
ダークダンサーを唱えた！		Dark dancer!............ (cast magic)
連れさる手				Take hand.
カースを唱えた			Curse......... (cast magic)
ブラックフォグを唱えた！		Black fog!.............. (cast magic)			
ヘルファイアーを唱えた！		Hell fire!.............. (cast magic)
ドラゴンダンスを唱えた！		Dragon dance!........... (cast magic)
レーザーメスを唱えた！		Laser knife!.......... (cast magic)
神への祈り！			Pray to God!
リカヴァーを唱えた！			Recovery spell!..... (sang a recovery)
神の加護を唱えた！			God's protection!. (advocated)
リザレクトを唱えた！			Resurrection spell!. (chanted)
ヒートブリザードを唱えた！		Heat blizzard!............ (cast magic)
地を打つ鉄拳！			Iron fist!.... (Tekken hitting ground)
デスブレイドを唱えた！		Death blade!.......... (cast magic)
ヒールを唱えた！			Heel chanted!...
クラッシュビート 			Crash beat......
励ましの歌 			Spur song. (Encouragent Song)
ビブラート 				Vibrato...
赤い羽根				Feather. (Red Feather)
魅惑のキッス			Enchant kiss (Enchanted)
ブラックウェイブ			Black wave......
カオスアタック			Chaos attack..
イフリートの召喚			Summon Ifrit....
フリッガの召喚			Summon Frigga.
ジンの召喚			Summon Jin 
タイタンの召喚			Summon Titan.. 
雪の精霊を呼んだ			Call Snow Spirit 
「雪だるまさーん！」			「Snowman!」........
雷竜の召喚			V Dragon.. (Summon thunder dragon)
戦乙女の召喚			Call Valyrie (Summon a valkyrie)


Weapon/Item Details 0000FD71-00010AEE:
--------------------------------------
ごく一般的な剣。アークが最初から持っている。 		Very common sword. Ark's firstweapon
幅広の剣。威力もそこそこ高い。 				A wide sword with high power.				
大きめの剣。片手でも使えるが、主に両手で持って使う 		A large two handed sword. Can be used with one hand.
騎士が使う槍。本当は馬に騎乗して使う。 			A spear used by a horse ridingknight..
小剣。価格は安いが、威力もそれなり。 			A reasonable power low cost ..sword.
風の精霊、シルフの加護がある弓。 			Bow with the Sylph protection....... (the spirit of the wind)				
小さくコンパクトな弓。 				A small compact bow...
大きめの弓で、威力もかなりある。 			A large powerful bow............
機械仕掛けで連続して矢を発射できる弓。 			A mechanical bow that shoots .rapidly.
銀でできた魔法の弓。魔法効果がある。 			A magical bow made of silver......... (There is a magic effect)
吟遊詩人が持つ竪琴。味方を励まし、敵の心に攻撃できる。 	Bard's lyre. Encourage allies and attack the enemies.. (heart)
三つ叉の矛。突き刺す威力はかなりのもの。 		Three-pronged spear. Piercing PWR....... (Huge piercing power)
雷神の宿った槍。離れた敵に電撃で攻撃することができる。 	An electric long ranged spear blessed by Raijin...... 
普通の槍。特別なことは何もない。 			An ordinary spear.............. (nothing special)
その名の通り、ごく小さな剣。ないよりマシという程度。 		A tiny sword. It is better ...than nothing..........
片手で使う手斧。投げることもできる。 			A one handed hatchet. Can be .thrown
両手で使う戦闘用の斧。 				A two handed battle ax.
長い柄の先に斧や槍のついたもの。豪快に振り回して使う。 	A long pole that can be swang around vigorously....... (ax or spear handle)
鎚矛。僧侶が使う。 					Monk's mace....... 
大きな金槌のようなもの。 				A big hammer............ 
突き専用の細身の剣。エルフが好んで使う。 			An Elves slender sword for ...thrusting.
森で採れる、薬用効果の高い植物。 			Medicinal plant found in forest...
力尽きた者を甦らせ、さらに体力も完全に回復させる。 		Resurrects exhausted people & restores their HP...
火の魔法が封じられた杖。 				A magic fire wand.......
魔王に対抗する力を持った剣。隠された力があるらしい。 	A devil resisting sword with .hidden power..........
風の精霊ジンが宿る細身の剣。敵の魔法防御力を減らす。 	A spirit of the wind sword....which reduces MAG DEF. (Wind Jin)
地の精霊タイタンが宿る剣。敵の攻撃力を減らす。 		A spirit of earth (Titan) sword which reduces ATK.....
大地母神フリッガの祝福を授かった槍。敵の知力を減らす。 	A spear blessed by mother of .earth Frigga. Reduce INT
火の精霊イフリートが宿る剣。敵の防御力を減らす。 		A spirit of fire (Ifrit) swordReduces DEF.......
その名の通り、ポリポリと歯応えがあって、栄養価も高い。 	It has a crunchy texture and ahigh nutritional value.
妖精が持つ小さな透き通った丸薬。 			A small transparent fairy pill..
幅広の斧。非常に重いが、投げることも可能。 		A very heavy wide ax that can be thrown...
氷の魔法が封じられた杖。 				A ice magic staff.......
強力な電撃弾を発する杖。近距離でも遠距離でも使える。 	A wand that emits a powerful..blitz. Shrt/Lng range
激しい爆発の魔法を秘めた杖。強力なため遠距離で使う。 	Magical wand of a explosion...Only long range......
強力な魔力を持った杖。炎の精霊が封じられているらしい。 	A spirt of fire wand. Powerfulmagical power.....
ドカティが隠していた小さな鍵。 				A small key hidden by Docati..
夢魔サッキュバスの魔力がこもった丸薬。使うと・・・？ 		A magical pill with power of..Succubus. When to use?
善意の赤い羽。使うと何が起こるのだろう？ 			Red feathers. What does it do?......... (Well-meaning red feathers)
古い時代に作られた魔力を持った竪琴。 			A magical lyre made in the olddays..
刃のない、突き専用の細剣。貫通力が高い。 		A blade-less sword only for...thrusting. (High penetration)
悪しきドラゴンを倒すために作られたという伝説の槍。 		A legendary spear to defeat anevil dragon........
上位魔術師の証。 					ProofOfMagician. (upper magician.)
騎士であることの象徴。 				Symbol of being knight
月の女神アルテミスが持っていた弓。秘めた力を持っている。 	A bow from the moon goddess...Artemis. Has hidden power.
精霊の力を宿した弓。 				A spirit bow........
持つ者に力強さを与える斧。 				Axe grants user strength.. 
吟遊詩人の象徴。 					Symbol of a bard
魔を祓うお札。 					Bill of demons. (enshrines deamons)
幸運を呼び込むといわれる靴。 				Shoes that bring good luck..
様々な学問について書かれた本。 			Various disciplines book.....
長い棒と、スパイク付きの鉄球を鎖でつないだ物。 		Long rod with chain of spiked iron balls......
長い竿状の柄の先に斧の刃が付いた物。攻撃力高し。 	Long rod with with axe blade..High ATK PWR...........				
異国の戦士が使っていたという強力な投げ斧。 		A powerful throwing ax used bywarriors... (foreign warriors)
ギターに似た弦楽器。その音色は遠くまでも届くという。 		A stringed instrument. Timbre can reach far away....
食べると、体中に力がわき上がってくる不思議な木の実。 	The mysterious fruit powers upall over your body...
守りの力がこもった石。 				A protective stone....
銀でできた槍。 					A silver spear
セイレーン族が使う槍の中でも、特に強力な物。 		The most powerful spear used..by the Sirens.
両手で使う、身長くらいもある巨大な剣。 			A huge double handed tall.....sword...  (as tall as you can use it with both hands)
棒と分銅を鎖でつないだ武器。 				A rod with a chained weight.
麦から作ったお酒。力尽きた者を気がつかせる。 		Sake made from wheat. Revives the exhausted.
メイスの大きなもの。 					A big mace..........
聖なる力を持った槍。ランス系の武器では、かなり強力。 	Spear with sacred power. Very powerful with lance...
薬草の成分を濃縮して丸く固めた物。体力を完全に回復。 	Concentrated medicinal herbs. Full recovery of health.
メデューサを倒すために作られた槍。 			A spear made to defeat Medusa.....
大神オーディンが使っていたとされる槍。 			A spear used by Ogami Odin............
山奥でしか取れない不思議なキノコ。体力がつく！！ 		Mysterious mountain mushroom. H.P gained!....... (Be taken only in mountain)
魔界の力が込められた斧。恐るべき衝撃波を放つ。 		Demon world Ax. Emits terror..shock wave.....
雪女の力の源。他の者には使えない。 			Source Yuki-Onna PWR not......use (not usuable for others)
古い神々を祭るための錫杖。秘めた力を持っている。 		A tin staff made for old gods.Has hidden power..
雷神が作ったという杖。秘めた力を持っている。 		A staff made by Raijin. Has...hidden power...
炎を自在に操ることができる杖。秘めた力を持っている。 		A fire wand. Has hidden power.........................
空に浮かぶ星から作られたという杖。 			A celestrial wand................ (made of stars floating in the sky)
戦いの女神が宿る槍。秘めた力を持っている。 		A spear that the goddess of...battle dwells (Has hidden power)
星の光を封じ込めた不思議な杖。秘めた力を持っている。 	A celestrial staff. Has hiddenpower................ (contains the light of the stars)
騎士団が訓練用に使っている重い槍。 			Heavy spear, Knights training.....
火の魔人が手にしていたという斧。秘めた力を持っている。 	Fire demon's axe. Has a hiddenpower.....................
ドラゴンの鱗から鍛え上げられた剣。秘めた力を持っている。 	Dragon's scale sword. Has a...hidden power...............
別名、幻影の剣。秘めた力を持っている。 			Phantom sword. Has a hidden...power...
上位の聖職者が持つ錫杖。 				High priest staff.......
名も知れぬ神が鍛えた槍。秘めた力を持っている。 		An unknown god's spear. Has a hidden power....
真の戦士だけに受け継がれた斧。秘めた力を持っている。 	A true warriors axe. Has a....hidden power..........
不思議な異世界の楽器。秘めた力を持っている。 		A mysterious instrument. Has ahidden power.. (From a differnet world)
使う者の神聖な力を増幅させる杖。秘めた力を持っている。 	A wand that amplifies PWR of..user. Has a hidden power

Weapon/Exchange Menu 000BA302-000BA3AB & 0000AC99-000ACBC & 000010AF4-00011222:
--------------------------------------
の武器を選んで下さい			Please choose weapon (Please select a weapon)
武器を持っていません			Don't have a weapon.
交換する武器を選んでください		Choose a weapon to exchange.
聖剣は渡せません！！		Can't swap Holy Swd! (Can't exchange Holy Sword!)
ｺﾞｰﾙﾄﾞです			Gold.....
売りますか?			Sell Weapon?
は い  いいえ			Yes.. No....
その武器は売れません			Can't sell weapon!..
売る 装備				Sell equip. (Sell Equipment)
売る はずす			Sell Remove
は　になった			promoted (became)
直接打撃力			.....DRCT. (direct impact force)
間接打撃力			.INDRCT. (indirect impact force)
間接効果				IND.Eff (indirect effect)
直接効果				DRT.Eff (direct effect)
回復する。				.recovered.
以上のマジシャンをソーサラーにクラスチェンジ。 .Class change from magician to sorcerer.......	
以上のファイターをナイトにクラスチェンジ。	.Class change from fighter to knight......
以上のエルフをシャーマンにクラスチェンジ。	.Class change from elves to shamans.....
以上のドワーフをスパルタンにクラスチェンジ。 .Class change from dwarves to spartans.....
以上のセイレーンをバードにクラスチェンジ。	.Class change from siren to bird.........
使うと魔法防御力が 5増加する。	Magic resistance increased 5. (when used)
使うと敏捷さが 5増加する。		AGL resistance increased 5 (when used)
使うと知力が 5増加する。		INT resistance up by 5.. (when used)
使うと攻撃力が 5増加する。		ATK PWR increased by 5... (when used)
使うと防御力が 5増加する。		Defence increased by 5... (when used) 
効果				Eff. (Effect)
以上のクレリックをプリーストにクラスチェンジ。 .Class change from cleric to a priest...........
ﾛｰﾄﾞ				lode
ｸﾚﾘｯｸ				clerk
ﾏｼﾞｼｬﾝ				magic. magician
ｿｰｻﾗｰ				srcer (sourcer)
ｳｨｻﾞｰﾄﾞ				wizard.
ﾌｧｲﾀｰ				fight (fighter)
ﾅｲﾄ				kng (knight)
ﾌﾟﾘｰｽﾄ				priest
ﾋﾞｼｮｯﾌﾟ				shop...
ﾒｲｼﾞ				mesg (message)
ﾚﾃﾞｨﾅｲﾄ				ladyN..  lady night
ﾄﾞﾜｰﾌ				dwarf	
ｽﾊﾟﾙﾀﾝ				spartn (sparten)
ﾊﾞｰｻｰｶｰ				berserk (berserker)
ｾｲﾚｰﾝ				siren
ﾊｲｴﾙﾌ				hiElf
ﾊﾞｰﾄﾞ				bird.
ﾜﾙｷｭｰﾚ				valkyr (valkyrie)
ｴﾙﾌ				elf
ｼｬｰﾏﾝ				shman (shaman)
雪女				snow (snow woman)
が使えます				.can use..
誰も使えません			noone can use.			
全員が使えます			all can use...

Item Menu 000BA46D-0x00BA523 & 000CFB0-000D105 & 000BA1FC-000BA213 & 000BF68F-000BF7CF & 00032AFB-00032B35:
--------------------------------------
道具を選んでください			Please choose a item
所持金				Inventory (Possession)
ゴールド				.Gold...
道具はありません			No items........
使う見る売る			Use. See. Sell
です 売りますか？ 			Sell item?.......
は い  いい			Yes.. No....
その道具は売れません			Can't sell item!....
回復				Heal (Recovery)
復活				CPR. (Revival)
特殊				SPL. (Speical)
の体力が __ 回復した		recover. __ H.P..... (Has recovered physical strength)
は体力が満タンなので使えない		H.P is full. Can't use!..... (physical strength is full and can't be used)
の体力最大値が __ 増えた		H.P increased. __ point (of maximum physical strenght __ increased)
の敏捷さが __ 増えた		AGL UP.... __ point (of agelity __ increased)  
の攻撃力が __ 増えた		ATK UP.... __ point (of Attack power __ increased)
の防御力が __ 増えた		DEF UP.... __ point (of defence __ increased)
の知力が __ 増えた			INT UP.. __ point (of intelligence __ increased)
の魔法防御力が __ 増えた		MAG DEF UP.... __ point (of Magic Defence __ increased) 
はちょっといい気分になった！		feeling a little bit better!
は眠ってしまった・・・			has fallen asleep.....
を使う相手がいません			No one can use!.....
は気がついた			noticed.....
持ち物はありません			I have no items!..
名前 				Name
個数				No.. (Number)
種類				Type 
ユニットを選んでください		Please select a unit....
帰って寝るっス			Go home sleep. 
所持金				.Money. (Possession)
ゴールド				.Gold...
個 				#.
買いますか				Purchase?.
はい いいえ			Yes. No....
お金が足りません			Not enough money
これ以上持てません			Can't hold anymore
				
Settings Menu 000BF102-000BF12D & 0003190F - 0003191F:
--------------------------------------
高速モード 			High speed (High speed mode)
バトルアニメ			Battle Ani.. (Battle animation)
メッセージ速度			Message speed.
速い				Fast
普通				Norm
遅い				Slow

Graphics Tiles for text 0x0009CBF8-0x0009E7A8:
--------------------------------------
[0x0009CDC8,0x0009CDB8] 移動 Move 
[0x0009CF28,0x0009CF18] 直捜 DRCT (Direct)
[0x0009CF28,0x0009CF18] 間/ IN/ (Indirect)
[0x0009CFC8,0x0009CFB8] 攻/回(復) Atk/❤ (Attack/Recovery)
[0x0009D1C8,0x0009D1B8] ためる Collect
[0x0009D3C8,0x0009D3B8] 買物 Shop (Shopping)
[0x0009D5C8,0x0009D5B8] 武器 Weapon
[0x0009D7C8,0x0009D7B8] 道具 Item
[0x0009D9C8,0x0009D9B8]	交換 Swap⚔ (Exchange)
[0x0009DBE8,0x0009DBC8] 待機 Standby
[0x0009DDC8,0x0009DDB8] ターン終了 End Turn (End of Turn) 
[0x0009DFA8,0x0009DF98] ユニツトー覧 Party (Units List)　
[0x0009E1A8,0x0009E128] セーブ Save
[0x0009E3A8,0x0009E398] ロード Load 
[0x0009E5A8,0x0009E598] 環境設定 Settings (Enviromental Settings)


Cheats: 
Edit save game (Set to FF which gives a value of 255 or 55)
Arc
0x00003592 Level
0x00003594 & 0x00003597 HP
0x0000359A AP
0x0000359B DEF
0x0000359C INT
0x0000359D MAG DEF
0x0000359E AGL
Randia 
0x000035AE Level
0x000035B0 & 0x000035B2 HP
0x000035B6 AP
0x000035B7 DEF
0x000035B8 INT
0x000035B9 MAG DEF
0x000035BA AGL
Alicia
0x000035CA Level
0x000035CC & 0x000035CE HP
0x000035D2 AP
0x000035D3 DEF
0x000035D4 INT
0x000035D5 MAG DEF
0x000035D6 AGL


