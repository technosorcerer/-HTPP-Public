Eternal Champions - Challenge From The Dark Side (AI Nerf)
June 28th, 2020
Billy Time! Games

This is a simple patch which tones down computer AI for all three difficulty levels in single player contest mode.
Compatible only with REDUMP set!

How to Patch:
1.Grab a copy of Eternal Champions - Challenge from the Dark Side (USA) (RE)
2.Grab Xdelta UI(https://www.romhacking.net/utilities/598/)
3.Patch your Track 01 Bin with the included Xdelta file