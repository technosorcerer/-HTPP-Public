Este parche debe ser aplicado si o si a la version "USA-Redump" del juego:

Que tiene este nombre:



"Eternal Champions - Challenge from the Dark Side (USA) (RE)"



Para aplicar el parche, deben utilizar e� programa "Lunar Ips" y debe aplicarse sobre este archivo:


"Eternal Champions - Challenge from the Dark Side (USA) (RE) (Track 01).bin"


Posiblemente encuentren errores ortograficos. Los cuales pienso corregir en una actualizacion de este parche.






