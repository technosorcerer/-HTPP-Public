[SEGA-CD] Road Rash Improvement.

Use this patch if you have CUE+BIN image:
Road Rash (USA) (Track 1) (Improvement v1.0).xdelta

Or this patch if you have CUE+ISO image:
Road Rash (1995)(Electronic Arts)(NTSC)(US)(Track 1 of 2) (Improvement v1.0).xdelta

Changes:
+ code optimization - much better FPS, even without overclocking.
+ fixed low fps rate when used with overclocked emulators.
+ with higher fps rates , player's bike turns speed no longer reduces.
+ 6-buttons control - nitro by X or Y.
+ fixed usage of nitro for nothing (can't use if already being used).
+ every nitrobike now with 8 nitro charges.
