## Introduction

A message from the Blue Star... catastrophe is coming.

This enhancement patch improves the English version of Lunar: Eternal Blue for Sega CD that was originally released in 1995 by Working Designs.

## What's in the patch?

This patch focuses on undoing the changes Working Designs made to the original Japanese game while keeping their English translation. Like with their other games, Working Designs made significant changes to the game balance. They also made some small edits to the graphics at Sega's request. All of those changes are reverted here so that it plays and looks just like the Japanese version. The original version of the translation also featured an all-uppercase font due to technical limitations; this has been replaced with an easier-to-read mixed-case font.

The 1.0 patch contained these changes:

* Magic Experience is no longer needed to save the game. This was one of Working Designs's most controversial changes and required players to choose between saving their game or improving their spells.
* Text features a new mixed-case font and the script has been updated to use it.
* All character and enemy stats are like they were in the Japanese version.
* All pentagrams have been restored.
* Plantella wears her original outfit.
* A few shots of Lucia in the opening cutscene have been restored to the Japanese versions.
* The shot of Luna in a flashback cutscene features the original brightness.

This 2.0 version of the patch keeps all of those changes while also making many improvements and bugfixes:

* The intro cutscene no longer desyncs on original hardware or certain emulators.
* Load times have been slightly improved.
* Many improvements to the script, fixing miscapitalizations and places where text would run off the edge of a line. This includes both fixes to the original Working Designs script and bugs introduced in the 1.0 version of the patch.
* The patch can now be applied straight to a BIN/CUE copy, making it easy to use and burn.

## How to use

This patch works with a BIN/CUE or IMG/CCD version of the game. There are two patches, compatible with two different rips of the game which are commonly circulating. If your BIN (or IMG) is 584135664 bytes in size, use the patch with "248357" in the filename. If your BIN is 584488464 bytes in size, use the patch with "248507" in the filename. (If you're familiar with how to calculate SHA1 hashes: patch "248357" is for a BIN with the SHA1 "6c5d0ef7ba22f4698cdff5605f2fe7fe13c3d637", and patch "248507" is for a BIN with the SHA1 "642e41670393dffd67a4cfbeccae17e5f5386f4b".)

This patch applies directly to the BIN or IMG file from your game. Replacement CUE, CCD and SUB files are included which should be used instead of the ones from your unpatched game.

This patch is in the "Xdelta" file format and is compatible with any tool that supports Xdelta 3.0 or later. If you use Windows, Delta Patcher, available from romhacking.net, is recommended.

After you apply the patch, you should rename your BIN or IMG to "lunar2.img". Make sure it uses ".img" even if your original file was named ".bin"!

If you use Mac or Linux, you can install the "xdelta" commandline tool via your package manager. On macOS, you can install it using Homebrew by running: brew install xdelta

To apply this patch using the commandline tool, run the following command:

xdelta3 -d -s NAME_OF_YOUR_BIN.bin lunar2.xdelta lunar2.img

## Known bugs

This fixes most, but not all, bugs from the original game and the 1.0 patch. There are a few bugs that couldn't be fixed without much more intensive changes.

* The Magic Experience meter will occasionally display a corrupt number. Your Magic Experience is safe; only the graphics are affected.
* A few typos and inconsistencies in the original Working Designs script had to be kept because there wasn't enough space in the script data to fix them.

## Credits

* Original patch and tool support: Suppertails66
* Updated patch and additional development: Ms. Tea
* Playtesting: Shinto-Cetra, kimmipen, MasterBismuth
