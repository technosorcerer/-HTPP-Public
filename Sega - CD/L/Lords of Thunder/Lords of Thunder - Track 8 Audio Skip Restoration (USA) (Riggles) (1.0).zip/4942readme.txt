-----------------------------------------------------------------------------
Lords of Thunder (U) Sega CD Audiofix by Riggles (R1ggles/Riggles1)				
Release: 02/17/2020     						
-----------------------------------------------------------------------------

1. Purpose
2. Tools needed
3. How to patch
4. Contact

*****************************************************************************
1. Purpose						    
*****************************************************************************
This mod restores the skipping in track 8 (NTSC, stage title Azual. Track 16 in the PAL release). 
A production oversight of the game causes track 8 to be filled with small gaps in the song 
making it skip and glitch on playback in both the NTSC and PAL releases of the game.
There has never been an official soundtrack released, so an intact version of the song isn't available.

Because each skip is only a few milliseconds in length I was able to take the time 
and manually interpolate each skip using stretching, reversing and other techniques 
to fill the gaps and restoring the track completely back into what sounds like its original 
form without any audible traces of restoration work being done.

The Sega CD version of the game uses all the exact same compositions as the TurboGrafx CD/PC-Engine CD releases,
however the Sega CD recordings use much higher quality equipment and better audio mastering, 
resulting in a richer sound. In comparison, the TurboGrafx CD/PC-Engine CD version 
sounds tinny with a lot of unwanted buzz, comparable to a raw beta tape sound.

*****************************************************************************
2. Tools needed								
*****************************************************************************

1. LazyAss CD Image Ripper (v10)
2. Daemon Tools Lite
3. ImgBurn

*****************************************************************************
3. How to patch	
*****************************************************************************

1. Mount the .cue file for Lords of Thunder with Daemon Tools Lite 
or insert your original copy into the disc drive.

2. Start LazyAss.exe and select the drive letter with the game. 
Leave everything untouched (I had MODE1/2352 [SATURN] selected), set your output folder and rip the game.
You'll end up with a LORDS_OF_THUNDER.cue .toc and .iso as well as .wav files for each track.

3. Overwrite LORDS_OF_THUNDER-08.wav with the one included in this release.

(These next steps are necessary in order for every song to work in RetroArch Genesis Plus GX, 
otherwise only the title music will play)

4. Unmount your virtual drives in Daemon Tools and mount the new LORDS_OF_THUNDER.cue from the
LazyAss output folder you picked.

5. Open ImgBurn and choose "Create image file from disc", select the virtual drive (DiscSoft Virtual), 
set an output folder and rip the fixed version of the game.
You'll end up with playable LORDS_OF_THUNDER.BIN and LORDS_OF_THUNDER.CUE 
which you then can play in an emulator or burn to a CD.

*****************************************************************************
4. Contact					
*****************************************************************************

For any questions, you can find me in the SegaNet discord https://discord.gg/9SQqMc



















