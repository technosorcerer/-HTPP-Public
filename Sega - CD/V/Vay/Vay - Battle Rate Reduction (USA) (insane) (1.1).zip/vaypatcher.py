#!/usr/bin/env python3

"""
quick'n'dirty vay patcher b20220622
- by insane/Rabenauge^.tSCc. - insane.atari@gmail.com

supports 2048+2352bytes images of Vay and Vay Unworked
"""

import os
import tkinter as tk
from tkinter import ttk
from tkinter import filedialog
from tkinter import messagebox

WMTITLE="Vay Battle Rate Patcher"

patches={
    "Normal Battle Rate":   b'\x3e\x2e\xd0\x41\x33\xc0\x00\xff\x93\xf8\x50\xf8',
    "Battle Rate / 2":      b'\x3e\x2e\xd0\x41\xe3\x48\x31\xc0\x93\xf8\x50\xf8',
    "Battle Rate / 4":      b'\x3e\x2e\xd0\x41\xe5\x48\x31\xc0\x93\xf8\x50\xf8',
    "Battle Rate / 8":      b'\x3e\x2e\xd0\x41\xe7\x48\x31\xc0\x93\xf8\x50\xf8',
    "Battle Rate / 16":     b'\x3e\x2e\xd0\x41\xe9\x48\x31\xc0\x93\xf8\x50\xf8',
    "Battle Rate / 32":     b'\x3e\x2e\xd0\x41\xeb\x48\x31\xc0\x93\xf8\x50\xf8',
}

patchtxt=list(patches.keys())
patchbin=list(patches.values())

curdir=os.getcwd() # windows seems to globally save the last used askopenfilename directory, this forces the current program directory

def romfind(rom,datarr):
    for dat in datarr:
        first=rom.find(dat)
        if(first!=-1):
            second=rom.find(dat,first+1)
            if(second!=-1):
                return -1   # further matches found - abort
            return first    # patch position found
        continue
    return -1               # patch position not found

def romload(filename):
    global rom
    try:
        with open(filename,"rb") as f:
            rom=bytearray(f.read())
            return True
    except IOError as error:
        pass
    return False

def romsave(filename):
    global rom
    try:
        with open(filename,"wb") as f:
            f.write(rom)
            return True
    except IOError as error:
        pass
    return False

def rompatch(patch):
    global rom,rompos
    rompos=romfind(rom,patchbin)
    if rompos!=-1:
        rom[rompos:rompos+len(patchbin[0])]=patch
        return True
    return False

def gui():

    def guibrowse():
        global curdir
        filename=(tk.filedialog.askopenfilename(title="Open CD Image",filetypes=[("BIN File", ".bin"),("ISO File", ".iso"),("All Files","*.*")],parent=tkroot,initialdir=curdir))
        curdir=""
        varfile.set(filename)

    def guipatch():
        if not romload(varfile.get()):
            tk.messagebox.showerror(WMTITLE,"File not found",parent=tkroot)
            return

        if not rompatch(patchbin[cbox.current()]):
            tk.messagebox.showerror(WMTITLE,"File not supported",parent=tkroot)
            return

        if not romsave(varfile.get()):
            tk.messagebox.showerror(WMTITLE,"Error while saving",parent=tkroot)
            return

        tk.messagebox.showinfo(WMTITLE,patchtxt[cbox.current()]+" activated",parent=tkroot)
        pass

    def guiboxselected(event):
        cbox.selection_clear()

    tkroot = tk.Tk()
    tkroot.resizable(False, False)

    varfile=tk.StringVar()
    varpatch=tk.StringVar()

    varpatch.set(patchtxt[2])

    label1 = tk.Label(tkroot, text="CD Image")
    label2 = tk.Label(tkroot, text="Patch")
    label3 = tk.Label(tkroot, text="Quick'n'Dirty code by insane/Rabenauge^.tSCc.")

    efile = tk.Entry(tkroot, textvariable=varfile)
    cbox = ttk.Combobox(tkroot, textvariable=varpatch, values=patchtxt, state="readonly")
    cbox.bind('<<ComboboxSelected>>', guiboxselected)

    bbrowse = tk.Button(tkroot, text="Browse", command=guibrowse)
    bpatch = tk.Button(tkroot, text="Patch", command=guipatch)
    bquit = tk.Button(tkroot, text="Quit", command=tkroot.destroy)

    padding1={'padx':8,'pady':8}
    padding2={'ipadx':128,'pady':8}

    label1.grid( column=0,row=0,**padding1,sticky="w")
    label2.grid( column=0,row=1,**padding1,sticky="w")
    label3.grid( column=1,row=2,**padding1,sticky="ew")
    efile.grid(  column=1,row=0,**padding2,sticky="ew")
    cbox.grid(   column=1,row=1,**padding2,sticky="ew")
    bbrowse.grid(column=2,row=0,**padding1,sticky="ew")
    bpatch.grid( column=2,row=1,**padding1,sticky="ew")
    bquit.grid(  column=2,row=2,**padding1,sticky="ew")

    tkroot.title(WMTITLE)
    tkroot.mainloop()

if __name__ == "__main__":
    gui()

# vim:list:listchars=tab\:>-:set ts=4 sw=4 sws=4 et:
