Vay Battle Rate Reduction Hack by insane/Rabenauge^.tSCc. - insane.atari@gmail.com

This hack reduces the random battle encounter rate in Vay and Vay Unworked (http://stargood.org/unworked/vay.php)

There are multiple patch files included as well as a Python patch program which can patch a cd image by itself.

Each patch file divides the battle rate with a certain amount. 
Apply the desired rate file - the bigger the number - the smaller the encounter rate - or use the python patcher.

Vay patches are in .ips format for 2048 byte/sector and 2352 byte/sector image files.

Vay Unworked patches are in .xdelta3 and .ups format due to the changes being moved into an offset >16MB in the image files.

To figure out if you need the 2048 or 2352 byte patch:
- Open your .cue file
- if there is a line "TRACK 01 MODE1/2048" you'll need to use the 2048 byte patch
- if there is a line "TRACK 01 MODE1/2352" you'll need to use the 2352 byte patch
- or use the python patcher

History:
v1.0: 20220516
 - initial release
v1.1: 20220622
 - added support for 2048 byte/sector images
 - added support for Vay Unworked (requested by Escaeva)
 - added python patcher

