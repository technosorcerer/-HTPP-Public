Cliffhanger - No Enemy Invincibility Frames Sega CD
May. 10th 2025
BillyTime! Games
--------------------
This simple patch is designed to remove invincibility frames from enemies in Cliffhanger for Sega Genesis.

How to Patch:
--------------------
1.Grab a copy of Cliffhanger (USA) (Track 1).bin (REDUMP)
2.Grab Xdelta UI(https://www.romhacking.net/utilities/598/)
3.Patch your Track 01 Bin with the included Xdelta file