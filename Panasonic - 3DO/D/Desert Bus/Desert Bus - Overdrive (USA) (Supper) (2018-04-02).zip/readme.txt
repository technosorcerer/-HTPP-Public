         **************************************************************
         *                   Desert Bus Overdrive                     *
         *                  Version 0 (1 Apr. 2018)                   *
         *            by Supper (suppertails66@gmail.com)             *
         **************************************************************

You've driven the desert route so many times you've lost count. Tucson to Vegas 
-- eight hours there, eight hours back -- at the wheel of that silent, empty 
bus, year after year after year. It's a pitiful, meaningless, hellish existence.

But no more! Scraping together every last scrap of your savings, you've made a 
few little modifications to your bus. You've rebuilt it. Faster. Faster. And... 
uh, faster. Quite possibly a little too fast, if those flashing lights behind 
you are anything to go by. And you still couldn't find some tires with enough 
traction to get you out of a ditch, or figure out how to fix that damn right 
pull.

But who cares? You've on duty today, and this time it's going to be a whole new 
kind of "hell on wheels"...

              ****************************************************
              *                    Uh, what?                     *
              ****************************************************

It's Desert Bus, except the bus goes 1,000 miles an hour. Honestly, what more 
could you want? (aside from an enjoyable game)

For people who like numbers:

Internally, Desert Bus actually does all its calculations in terms of meters. In 
the original game, the bus has a top speed of 0.375 meters per frame, which 
works out to 81.000 km/h or 50.33 mph (this despite the game's claim of a top 
speed of 45 mph; the conversion from metric is fudged to make this work). The 
game assumes a distance of exactly 648,000 meters from Tucson to Las Vegas, 
meaning a full-speed drive will take precisely 8 hours.

So what does the hack do? First, it raises the bus's top speed to 0.499 
meters/frame (108 km/h or 67.1 mph), which is the highest value possible without 
causing complications. That's a pretty paltry difference, though. The bulk of 
the speedup is achieved by running the most important logic calculations an 
extra 15 times per frame, which essentially causes the game to run 16 times 
faster on top of the base speed change.

Thus, the new top speed of the bus is approximately (0.499 * 16) = 7.984 
meters/frame, which comes out to 1,724.544 km/h or 1071.582 mph -- in other 
words, more than 21 times the original speed. That means a one-way trip from 
Tucson to Las Vegas will take about 22 minutes (though due to rounding and the 
lag caused by the extra processing, the game reports the time as 21 minutes 
while it probably takes closer to 25 minutes in real time).

The speedup also affects the handling of the bus, making for much 
faster-paced gameplay. Unforunately, it turns out that even at 1071 miles an 
hour, Desert Bus is still Desert Bus. But hey, it _sounds_ cool, right? No?

              ****************************************************
              *               Patching Instructions              *
              ****************************************************

--- WHAT YOU'LL NEED ---
* A BIN/CUE or ISO/WAV format disc image of Disc 1 of Penn & Teller's Smoke and 
Mirrors, which contains the minigame Desert Bus. As this game was never 
officially released, hitting up eBay is highly unrecommended.
* If you're on Windows, the xdelta patching utility (http://xdelta.org/) is 
provided in this distribution. On other platforms, you'll need to acquire 
version 3.0.8 or later on your own.

--- AUTOMATIC PATCHING METHOD (WINDOWS) ---

If you're using Windows, move your disc image files into the same directory as 
the program and do one of these as appropriate:
  * If you have a BIN/CUE disc image -- which you should, since it's how the 
game was distributed in the first place -- drag and drop the BIN file onto 
binpatch.bat.
  * If you have an ISO/WAV disc image for some reason, drag and drop the ISO 
file onto isopatch.bat. Note that your ISO/WAV files must use standard naming 
and numbering, e.g. "File 01.iso", "File 02.wav", etc.

If everything works, this should produce the patched game under the name 
"Desert_Bus_Overdrive_##". To play it, make sure the file 
"Desert_Bus_Overdrive.cue" (included with the patch) is in the same directory as 
everything else and then load it in an emulator, or burn it to a CD for use on 
real hardware.

If this doesn't work, try using the manual patching method below to diagnose the 
problem.

--- MANUAL PATCHING METHOD---

--- CONVERTING FROM BIN/CUE TO ISO ---
If you have a BIN/CUE image (or the equivalent IMG/CUE), you'll need to convert 
it to ISO/WAV before you can patch it. I'd recommend using BinChunker (a.k.a. 
bchunk -- homepage http://he.fi/bchunk/) to do this.

* On Windows, you can use the included bchunk.exe (courtesy of elmer). If you 
don't want to use bchunk, there are also many "shareware"/commercial utilities 
that can do this task, though they may or may not output the same ISO as bchunk.
* On Linux, it should be available from your distro's repos, or of course you 
can build from source.
* On Mac, you can build from source, or perhaps get binaries wherever Mac people 
get their binaries from.

To convert, open a command prompt and navigate to the folder containing the 
BIN/CUE, then run the following command:

bchunk -w PTSM1.bin PTSM1.cue PTSM1_

(substituting the names of your BIN/CUE files, obviously -- remember to put 
quotes around them if they have spaces in them. **Don't rename them** -- this 
will cause the conversion to fail unless you also modify the CUE file itself.)

--- PATCHING STEPS---
1. First, !!!***verify that your ISO has the correct MD5 hash***!!! It should be 
b349ab167f3ef914fbab3ec8d6326437. If it isn't, the patch almost certainly won't 
work. You can obtain the hash by using the md5sum utility on *nix, or the FCIV 
utility (https://support.microsoft.com/en-us/kb/889768) on Windows.

2. Use xdelta to apply Desert_Bus_Overdrive.xdelta to your ISO. If you're using 
the command line, this would look something like:

xdelta3 -d -s Desert_Bus_Overdrive.xdelta PTSM1_01.iso 
Desert_Bus_Overdrive_01.iso

If you use a GUI wrapper, it should be self-explanatory, but make sure the 
output file is named Desert_Bus_Overdrive_01.iso.

3. That's technically all the patching required, but assuming you want to play 
on an emulator, we now need to make sure the CD audio files are properly 
associated with the ISO. First, make sure your patched ISO is named 
Desert_Bus_Overdrive_01.iso, then rename the audio files produced from the 
BIN/CUE conversion process to Desert_Bus_Overdrive_02.wav, 
Desert_Bus_Overdrive_03.wav, etc.

4. A CUE file named Desert_Bus_Overdrive.cue is included with this patch. Move 
it to the same directory as your ISO and WAV files.

--- TROUBLESHOOTING ---
* If the automatic patching method fails to produce any audio files, make sure 
all your files are named in the format "Filename ##.wav". The patcher expects to 
see a two-digit number directly before the file extension; without that, it 
can't find the tracks.
* If the patched ISO won't run, check the MD5 hashes of your original ISO and 
the patched ISO. The correct hashes are given in the steps above. If either of 
them doesn't match, try a different method for converting the BIN/CUE to ISO, or 
using a BIN/CUE generated by a different program.
* If loading Desert_Bus_Overdrive.cue doesn't work, try loading 
Desert_Bus_Overdrive_01.iso by itself. If that works, make sure all your files 
are named exactly as described above, and that the names in the CUE file match 
your audio files. CUE files are plaintext; just open it in Notepad or whatever.
* If your ISO has associated sound files in some format other than WAV (or your 
emulator doesn't support WAV files), you'll need to either convert them to WAV 
or modify the CUE file to use a different format. In the latter case, change 
(for example) all occurences of WAVE to MP3, and make sure the filenames are 
correct.

              ****************************************************
              *                  Known Issues                    *
              ****************************************************

None, yet...

              ****************************************************
              *                 Version History                  *
              ****************************************************

Version 0 (4/1/18) (actually 4/2/18, I got the idea too late to finish on April 
1st)
  * Initial release.

              ****************************************************
              *                  Special Thanks                  *
              ****************************************************

* elmer, for providing the fixed bchunk executable included with this patch
