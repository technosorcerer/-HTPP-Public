-------------------------------------------------------------------
Spanish Translation of Doctor Hauzer by Mr.Nobody
-------------------------------------------------------------------

Full Translation for Doctor Hauzer (3DO)

This is a Spanish translation for the 3DO game Doctor Hauzer. The patch can be applied to the original iso file using programs such as xdeltaui which can be found in this website.

The translation covers in-game & cutscenes text, there are a few things that are not translated like the main menu choices & introduction videos for the 1st version of the patch.

The file includes the xdelta file & a txt file with the translation of the untranslated elements of the game.

Thanks to Arcanearia who translated to english the original game, created the spanish font, and guided me through the process.

Enjoy the game!


------------------------------------------------------------------------
Traducci�n de Doctor Hauzer al espa�ol por Mr.Nobody
------------------------------------------------------------------------

Full Translation for Doctor Hauzer (3DO)

Este parche traduce el videojuego Doctor Hauzer de 3DO al espa�ol. Aplica el archivo xdelta a Doctor Hauzer (Japan).bin utilizando xdeltaui o cualquier otro programa compatible.

El menu principal y los videos no est�n traducidos as� como peque�os assets que intentar� traducir en las pr�ximas versiones.
Los v�deos est�n traducidos en la parte inferior de este readme.

Traducci�n, fuente en espa�ol y hacking original al ingl�s por ArcaneAria.

�Disfruta del juego!



PD: No olvides seguirme en los siguientes enlaces para 
apoyar pr�ximas traduciones y proyectos:

---------------------------------------------------------------------

- Youtube:
https://goo.gl/sE58x7

- Blogger:
https://mrnobodystudios.blogspot.com/

- Twitter:
https://twitter.com/mrnobodystudios

- Traducciones:
http://www.romhacking.net/community/4650/


---------------------------------------------------------------------------
Doctor Hauzer traducci�n de cutscenes y men� principal:
---------------------------------------------------------------------------

Men� principal:
############

OPENING	-	Introducci�n 
START		- 	Nuevo juego
CONTINUE	-	Cargar partida
OPERATION	-	Controles



(FMV) Introducci�n:
################

1952
�El famoso arque�logo Profesor Hauzer
ganador de multiples premios
y descubridor de artefactos historicos!

Ahora...
El Profesor Hauzer
�Ha desaparecido!

Comenc� a recopilar informaci�n sobre
Hauzer hace 10 a�os...
Nunca pens� que el brillante hombre que
segu� durante tanto tiempo desapareciese as�...

Finalmente he averiguado donde se encuentra...

En una vieja mansi�n en las afueras...



(FMV) Nuevo Juego:
################

Cuando comenc� como reportero.
Me asignaron entrevistar al Dr. Hauzer.

Alguien que le entrevist� previamente
dijo que a pesar de ser un genio,
ten�a una personalidad neur�tica

Un reportero antiguo de la compa�ia
dijo que todos odiaban liadiar con �l.

Siendo nuevo, probablemente me lo 
asignaron para ponerme a prueba.

Pero, como no sab�a nada por entonces,
le entrevist� con mucho entusiasmo.

Por suerte, consegu� que me hablase
hasta de sus estudios no publicados.

Gracias a este �xito, intent� estar al tanto
de los trabajos que se relacionaban con �l.
Estuve siguiendole la pista durante a�os
antes de que desapareciese.

No es solamente que acabase
llevandome bien con �l.

Es el hecho de que su investigaci�n
siempre generaba buenos art�culos...

Cuando desapareci�, segu� su rastro.
Finalmente encontr� su paradero.

Para poder hablar con �l de nuevo,
he viajado hasta su mansi�n...



(FMV) Entrada a la mansi�n:
#######################

�Eh? Vaya...
Esta casa es muy antigua...
y parece estar en muy mal estado...

��Pero qu�...?! �Est� abierta?