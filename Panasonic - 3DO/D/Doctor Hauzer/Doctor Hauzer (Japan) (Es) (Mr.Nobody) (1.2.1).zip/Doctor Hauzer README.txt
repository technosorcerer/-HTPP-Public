###################################################################
Doctor Hauzer English v1.2.1 (March 2022)
###################################################################

## Intro ##
World-famous archaeologist and famed scholar Doctor Hauzer has mysteriously vanished,
and Adam, a reporter who frequently covers his work, decides to track him down.
His search leads him to a decrepit mansion on the outskirts of town. What awaits him
in the sinister darkness where the mysterious doctor lurks?

Doctor Hauzer is a puzzle game with horror themes where the player navigates a
trap-filled mansion and finds the secrets within. Players can save in any room as
long as there's no danger present. The controls closely resemble Alone in the Dark,
although the player can also play in over-the-top camera and first person modes.


## Installation ##
* The patcher expects the ISO version of the game *
 
### Windows ###
- Drag and drop the ISO file onto "Drag and drop ISO on me.bat".
- An ISO file named "Doctor Hauzer (English v1.2).iso" will be generated next to the patcher.
- Enjoy!

### Web Patch ###
Kotcrab recently wrote a web-based patcher that supports xdelta3, whereas most other web
patchers only support xdelta. Everything is client-side, so you're not uploading your
files anywhere.
1. Head to https://kotcrab.github.io/xdelta-wasm/
2. Under "Source file," select your original copy of the game.
3. Under "Patch file," upload the file "patch_data/doctor-hauzer-1.2-patch.xdelta3"
   that came with the patcher.
4. Select "Apply Patch" then download the resulting file.


## Tips ##
- Save frequently! The mansion can and will kill you constantly!


## Credits ##
SnowyAria - Translation, game hacking
Mr. Nobody - Spanish translation
Arjak, TurnipTheBeet, blueskyrunner - Playtesting


## Special Thanks ##
Folks at 3dodev.com for writing a guide to creating 3DO compatible FMVs and setting up
the MacOS 3DO development environment VM for running the old software!


## Contact ##
Have any issues or run into any problems? Feel free to drop by the Eight Mansions discord here:
*  https://discord.gg/bewGNtm

Alternatively, you can message ArcaneAria/SnowyAria on ROMhacking.net or on Twitter at @SnowyAria.