				Supreme Warrior Easy v.1.0b
			        Public release (February 12th 2014)

Description:
Supreme Warrior was a very difficult game that was quite frustrating...especially on the harder difficulties. I personally just cannot beat it and get frustrated half way through...haha. So, I've decided this game needed to be done. This is an easy mod of Supreme Warrior (U) that makes the game a whole bunch less difficult by making all opponents have 1 for health and attack chis for Apprentice Mode. Add +100 for Master difficulty and +200 for Supreme difficulty.

Features:
-Apprentice difficulty opponents start with 1 for attach and health Chi.
-Master difficulty opponents start with 101 for attach and health Chi.
-Supreme difficulty opponents start with 201 for attach and health Chi.


NOTE: The IPS patches only work on the North American (U) disc images, it is untested on any other region or disc images downloaded from the various ROM sites. There are two patches, one for each disc.


Patching:
-You need a BIN/ISO of the North American release (U) for both discs. The size of the BIN/ISO for both discs must be exactly: 672,010,240 bytes or 640 megabytes!
-Use the included screenshots of the Properties pages from both of the BIN/ISO CD image for reference. 
-You'll need to rip the discs using ImgBurn, this will rip the correct size and or format which is what I used on my original discs.
-It is also strongly recommended to use Lunar IPS.  I've included this IPS program as well.  You can get this program from this website: http://fusoya.eludevisibility.org/lips


Note: This is a beta patch and is not complete.  If you find any issues and or bugs please email me.  Suggestions are also welcomed.




http://www.jce3000gt.com/
jce3000gt@yahoo.com