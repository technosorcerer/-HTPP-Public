"Honey in the Sky"
Traducción al Español Ver. 1.0 (09/02/2024)
por Max1323 (Traducciones Max1323).
Basada en la gran traducción de filler, cabbage y Diogo Ribeiro.
---------------------------------------------------
Descripción:
Un día, el dios de la mitología japonesa, Izanaki llama a Honey
para contarle que un ser malvado se infiltró en el corazón de
su esposa Izanami, por esta razón ella está matando a los humanos.
Izanaki le pide ayuda a Honey para que busque y elimine a este 
ser malvado para que todo vuelva a estar en paz.

Desarrollado: Sankindo
Publicado:    Face
Lanzamiento:  01/03/1989 (JAP)
---------------------------------------------------
Acerca del proyecto:
-La mayoría de los textos están traducidos, se añadieron los
caracteres españoles.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS (PC)
Utilizar UniPatcher (Android)
Utilizar Rom Patcher JS (Parcheador Online):
https://www.romhacking.net/patch/

Archivo IPS
Hanii in the Sky (Japan).pce
File Size     256 KB
File MD5      523F9D5BFB35037EEEF71A34DE4270A1        
File SHA-1    49B1C5D889002BF52BE65114D7F0646493500170
File CRC32    BF3E2CC7