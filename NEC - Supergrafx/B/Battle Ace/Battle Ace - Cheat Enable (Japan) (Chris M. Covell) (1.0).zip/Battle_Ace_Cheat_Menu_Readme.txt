Cheat Menu Hack for Battle Ace (SGX)
------------------------------------

By Chris Covell

A quick explanation:

Battle Ace has a SITUATION (cheat) menu built-in, but all the options,
except for lives, have been removed.  This hack adds those options back in.
There's no way to put these options back in the original Hu-Card of Battle Ace.

1) Patch your SGX ROM of Battle Ace.pce using a good IPS tool.  ***NOTE*** that
your original ROM mustn't have any header (ie: its file size is exactly 524288 bytes.)

2) Play the game in a good emulator (with SGX mode enabled) or on a flash card.
At the title screen of Battle Ace, press SELECT then RUN.  You may now cheat!




If you would rather just do a RAM hack, then RAM location $4E1E set to 1 enables
Non-Death mode.