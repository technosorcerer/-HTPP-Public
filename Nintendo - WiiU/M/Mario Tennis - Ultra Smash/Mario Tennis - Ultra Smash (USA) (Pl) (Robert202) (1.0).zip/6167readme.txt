The patch is based on Loadiine version of "Mario Tennis: Ultra Smash (USA) v.32"

Patch the following files:
- "msg_kernel.ips" -> "content\msg\i18n_us_en\msg_kernel.dat"
- "NintendoP_NewRodin-DB.ips" -> "content\font\NintendoP_NewRodin-DB.ttf"

This files replace the messages and expand font for US English version, if you're using other languge version, after patching replace the file to corresponding language version in "content\msg\"

The game also uses built in WiiU Cafe Font, if you don't see Diacritic signs, update your font with a unicode CafeStd font (CafeStd.ttf) -> http://emulation.gametechwiki.com/index.php/Emulator_Files#Wii_U

If your using cemu replace the "sharedFonts\CafeStd.ttf", you can also use CafeStd.ips file to patch it.

Remember to make a backup of files before patching if something goes wrong.