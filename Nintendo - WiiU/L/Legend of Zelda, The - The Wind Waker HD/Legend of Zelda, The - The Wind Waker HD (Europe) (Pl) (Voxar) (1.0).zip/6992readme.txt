The Legend of Zelda: The Wind Waker HD PL
Wersja 1.0

Spolszczenie działa na wersji Loadiine:
Nazwa: THE LEGEND OF ZELDA The Wind Waker HD
ID: 00050000-10143600 WUP-P-BCZP
Wersja: v0
Region: EUR

1. Wejdź na stronę https://www.romhacking.net/patch/
2. Kliknij pierwszy przycisk (obok "ROM file:") i wybierz plik "permanent_2d_EuEnglish.pack". Ścieżka do pliku powinna wyglądać tak: THE LEGEND OF ZELDA The Wind Waker HD [BCZP0101]\content\Common\Pack\permanent_2d_EuEnglish.pack
3. Kliknij drugi przycisk (obok "Patch file:") i wybierz łatkę spolszczającą (zeldatwwhdpl.xdelta).
4. Kliknij "Apply patch".
5. Zostanie utworzony i pobrany nowy plik "permanent_2d_EuEnglish (patched).pack".
6. Zmień nazwę dla wyżej wymienionego pliku usuwając dopisek "(patched)" i przenieś go do folderu "Pack" zamieniając oryginalny plik.