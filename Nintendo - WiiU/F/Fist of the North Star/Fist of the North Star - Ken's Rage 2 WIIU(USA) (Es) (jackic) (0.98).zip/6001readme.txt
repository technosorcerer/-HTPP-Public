Parche de traducci�n al castellano para el juego "Fist of the North Star - Ken's Rage 2" de WiiU y PS3

�Esto qu� es?

Esto es un parche para modificar el mencionado juego de PS3 y WIIU y traducir en la medida de los posible los textos al castellano.

�Qu� est� traducido?

Est� traducido todo el gui�n del juego dejando solamente los elementos que son gr�ficos pues si bien puedo extraerlos y modificarlos, no existe una herramienta particular para volverlos a insertar.

La fuente del juego ya contaba con todas las vocales acentuadas y s�mbolos y se ha podido usar para una correcta puntuaci�n en castellano.

�Qu� me hace falta para instalarlo en PS3?

El juego en cuesti�n, este parche y LEER CON ATENCI�N LAS INSTRUCCIONES. Es muy sencillo y no dar� soporte alguno m�s all� de este archivo de texto.

Ni que decir que SOLO PUEDE USARSE EN UNA CONSOLA MODIFICADA o en un EMULADOR (CEMU).

�C�mo aplico la traducci�n en WIIU?

En el caso de la versi�n de WIIU, necesitamos el juego en una versi�n "DESEMPACADA"(la versi�n para LOADIINE vamos) es decir, no vale la versi�n instalable descargada tal cual de WiiU USB HELPER, pero ese mismo programa puede usarse para DESEMPACAR EL JUEGO, una vez tenemos el juego, como digo, desempacada, quedar�n 3 carpetas, CODE, CONTENT y META. El archivo que nos interesa est� en esta ruta:

content\LINKDATA.A

Lo copiamos en la carpeta WIIU del parche y ejecutamos el archivo "FISTWIIU.exe" sigues las instrucciones de pantalla y listo, el archivo ser� reemplazado por uno ya parcheado en castellano, una vez hecho esto, vuelves a colocar LINKDATA.A en su carpeta, a partir de aqu�, puede usarse de diferentes modos, en el emulador CEMU que funciona perfectamente con este juego (permitiendo jugar, adem�s, a 60HZ) en WIIU mediante LOADIINE (no recomendado por la lentitud) o bien convirti�ndolo a un formato INSTALABLE, esta conversi�n est� ampliamente explicada documentada en internet y es el m�tido recomendado para usar el juego en wiiu, una gu�a por ejemplo se encuentra aqu� (donde pone "M�TODO"): 

shorturl.at/lIKX8

Una vez convertido, puede instalarse mediante "Wii U WUP Installer", esta conversi�n tambi�n puede usarse para convertir el DLC e instalarlo.

DLC (SOLO EN WIIU) 

El parche de traducci�n para el DLC, SOLO puede descargarse desde "El blog de Jackic", no es dif�cil de encontrar.

Para parchear el DLC, necesitamos DESEMPACARLO y copiar los archivos de DLC.zip, sobreescribiendo los antiguos, esto luego se puede convertir como mencion� antes e instalarlo.

En el caso de querer usar el DLC traducido en CEMU, hay que INSTALAR el dlc y despu�s buscar la carpeta de instalaci�n en tu directorio que deber�a ser este "Cemu\BIN\mlc01\usr\title\0005000c\1012b800\content" o el que hay�is elegido vosotros en la configuraci�n del emulador. 

�Qu� me hace falta para instalarlo en PS3?

El juego en cuesti�n, este parche y LEER CON ATENCI�N LAS INSTRUCCIONES. Es muy sencillo y no dar� soporte alguno m�s all� de este archivo de texto.

Ni que decir que SOLO PUEDE USARSE EN UNA CONSOLA MODIFICADA.

�C�mo aplico la traducci�n en ps3?

En el caso de la versi�n de ps3, necesitamos el juego en una versi�n "descompactada" es decir, no vale para una versi�n en pkg, el archivo que necesitamos del juego es el siguiente:

BLES01801\PS3_GAME\USRDIR\LINKDATA\PS3\LINKDATA.A

Lo copiamos en la carpeta PS3 del parche y ejecutamos el archivo "FISTPS3.exe" sigues las instrucciones de pantalla y listo, el archivo ser� reemplazado por uno ya parcheado en castellano, una vez hecho esto, vuelves a colocar LINKDATA.A en su carpeta, lo copias a tu PS3 con el m�todo que te vaya mejor (pendrive mismo), lo ejecutas con tu gestor de juegos favorito, en mi caso MULTIMAN y ejecutas el juego normalmente, tras instalarse, tendr�s el juego en tu ps3 en castellano.

Bugs y estad�sticas

Esta traducci�n me ha llevado, inclu�do el testeo, un buen rato.

�Para qu� versiones vale este parche y qui�n lo puede usar?

Este parche solo se puede aplicar con �xito al juego de ps3 cuyo c�digo es "BLES01801" y el de WIIU cuya nomenclatura es Fist of the North Star  Ken's Rage 2 [AH9P] (versi�n PAL pero creo que deber�a valer tambi�n para la USA)

Notas: 

Se ha testeado el juego a FUEGO en el emulador CEMU, se ha comprobado su funcionamiento en WIIU mediante LOADIINE e INSTAL�NDOLO y en una PS3 Slim con HEN 3.02

El juego contiene una gran cantidad de texto y varios idiomas mezclados, esto ha hecho que la correcci�n autom�tica solo pueda haberse aplicado a PARTE del texto ya que, al estar mezclado Castellano, Franc�s e Italiano, el programa reporta errores constantes y es un trabajo de chinos, as� que, parte del texto se ha corregido visualmente, por ello, que nadie se maraville que queden errores, si alguien quiere reportarlos, el gadget de contacto del blog es el lugar apropiado para hacerlo.

Debido a la extensi�n del texto (que lo he ampliado en partes) el idioma Franc�s e Italiano ROMPEN EL JUEGO, en caso de querer jugar en esos idiomas, no uses este parche.

Gracias por usar esta traducci�n para su uso particular, en concreto se "prohibe" usar el parche en ning�n tipo de reproducci�n para su venta al por mayor.

Jackic 2021.