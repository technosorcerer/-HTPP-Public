Rhyme Rider Kerorican - The Digimon Rhythm Collection Part 1
December 24, 2021
DanielKan

--------------------------
MENU TRANSLATION
--------------------------
taken from https://gamefaqs.gamespot.com/wsc/579969-rhyme-rider-kerorican/faqs/17465

Menu #1 (title screen)

"start" - start game
"how to play" - shows you how to play

Menu #2 (after "start")

"Stage Select" ----> Stage 1
		     Stage 2
		     Stage 3
		     Stage 4

"High Score"   ----> Stage 1(1-4)      Rank 

"Option"       ----> Erase Data      ----> yes
				           no
		     
		     Key Configure   ----> default (normal commands)
				           one button (easy mode)

Menu #3 (after you play through a stage)

"Score"				
"Time Bonus"
"Total"

------------------------------
BUTTON COMBINATIONS
------------------------------
By order of appearance:

A (or B) = robot armadillo
X = daifuku burger
Y = triangular gymnasts
Y + A (or B) = kamameshi
X + A (or B) = orca
Y + X = shampoo bomb

And of course, if you choose to set the "one button" option, you can press whatever you want as long as the timing is correct.