*******************************************************
Digimon D-1 Tamers English Translation v.05

�2003-2004 by PmHacks
http://pmhacks.emuxhaven.net
*******************************************************

-------------------------
Table of Contents
------------------------

1. About Digimon D-1 Tamers
2. Patch History 
3. Partch Credits
4. Known Bugs
5. Applying the Patch
6. Extra Stuff
7. Contact


------------------------------------------
1. About Digimon D-1 Tamers
------------------------------------------

It all started in Digimon Adventure 01 : Anode and Cathode Timers,
where Ryo, began his journey in the Digital World. Ryo was playing on
his laptop, all of a sudden, Agumon appeared on the screen and he was
transported to the Digital World. Then Gennai told him that Milleniummon
had captured all the DigiDestinied and told Ryo that he'll have to save
them and defeat Milleniummon... continue on to Tag Tamer

In Digimon Adventure 02: Tag Tamer, Ryo and Ken were transported to the
Digital World where they meet up with their Digimon. Gennai told them
Millenniummon had appeared again with Diablomon. Ryo and Ken then walks
up the mountain and defeat them. But its not over yet, as Milleniummon
returns again as Moon=Milleniummon. Now Ryo and Ken have to find some
way to defeat Moon Milleniummon...continue on to D1 Tamer

In Digimon Adventure 02: D1 Tamer. It all started in Ken's house,
Ryo was transported to the Digital World to participate in D-1
Tournament. Moon=Milleniummon has reappeared and now Ryo has to
both win in D-1 Tournament and defeat Moon=Milleniummon...


----------------------
2. Patch History
----------------------

 Digimon D-1 Tamers translation patches:


   - v.05
   
   - The main menu is done.
   - Shop menu's are done.
   - the fusion shop has been done but not one button 
     becoz i dont know what it is or what it does.
   - All items thats i have on my saved game which is 4 pages 
   - Some item Decriptions
   - Some Digimon Mentals have benn translated
   - Most of the Digimon names have bee translated 
   - Done some text in the upgrade shop
----------------------
3.Patch Credits
---------------------

 PmHacks - Done 95 % of whats done
 Jazz    - Translated the shop text and the Digimentals


---------------------
4. Known Bugs
---------------------

  none as of yet.
 
-----------------------------
5. Applying the Patch
-----------------------------

 Use SNESTool which u can get at www.romhacking.com

 Directions for using it:
 --------------------------------------------------

 1. Unzip the patch, rom, and SNESTool all into the same folder.
 2. Run SNESTool which should come with this patch.
 3. Press U for Use Patch.
 4. Find the patch on the list of patches.  Press Enter.
 5. Find the rom on the list of files.  Press Enter.
 6. SNESTool should say something like, "Patching OK!"
 7. Press Q for Quit.
 8. Load up your favorite emulator and have fun!

 If these instructions do not work for you...then you are a moron.
 This is like...the easiest set of instructions for the program ever.
 You shouldn't have any problem.  None.  Go away.
  

------------------
6. Extra Stuff
-----------------

I also need some one that is good with graphics thats can 
uncompress them and then recompress them when i am fnsihed 
with them.

 
-------------------
7. Contacting
-------------------

  Before you fire up your mail program and send me mail, keep this
  in mind:

  - Don't email when the next release will be out.
  - The rom.  i am not sending anyone the rom.

  If you proceed to email me for this reason you probably won't get
  a reply.  If you do, it'll probably be nasty.

  If you still want to email me to say thanks or whatever, mail to:
  normmatt234@hotmail.com
===================================================================