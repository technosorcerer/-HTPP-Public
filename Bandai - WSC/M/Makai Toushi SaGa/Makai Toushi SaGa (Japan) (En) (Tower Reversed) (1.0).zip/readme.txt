Use with:

(No Intro)
Makai Toushi Sa-Ga (Japan).wsc
957137e7d5249c02fecff063e0c86e87
1b6f5f30