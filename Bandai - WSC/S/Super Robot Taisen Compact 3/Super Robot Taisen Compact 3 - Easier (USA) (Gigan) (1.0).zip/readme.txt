Super Robot Wars Compact 3 Easier Hack

This is a Super Robot work in which characters similar to "Fist of the North Star" play an active role.
For light users who want to play comfortably, the economic cost has been greatly reduced.
Effective use of pilot points, which are often in short supply, is now possible.
Please try it.

"SRW-Compact 3 Easier.ips"

This is "Super Robot Wars Compact 3" IPS patch.

[Changes]
- SP initial value increase, consumption 1/5
- Swap repair costs and earned funds
- Unit modification cost 1/10, Weapon modification cost reduced to 1/3
- Reduced PP required for skill acquisition

P.S.
I used MasMin to analyze this hack.
https://www.romhacking.net/utilities/1668/

EOF