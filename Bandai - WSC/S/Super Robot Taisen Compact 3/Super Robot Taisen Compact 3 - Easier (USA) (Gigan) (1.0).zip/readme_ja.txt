Super Robot Wars Compact 3 Easier Hack

"SRW-Compact 3 Easier.ips"

「スーパーロボット大戦COMPACT3」のIPSパッチです。

【変更点】
・SP初期値増、消費量1/5
・修理費と獲得資金を入れ替え
・ユニット改造費1/10、武器の改造費を1/3に低減
・技能修得の必要PPを低減

【解説】
「北斗の拳」のようなノリで展開するWonderSwan最後のスパロボ、ハックも見当たらないようなので解析してみました。
元々難易度も高くない本作ですが、少ない獲得資金と高い修理費を入れ替え、SP消費値や改造費等を軽減しました。
技能修得の必要PPは見つけるのに苦労したよー。

【解析メモ】
このハックはMasMinで検索して解析しました。
https://www.romhacking.net/utilities/1668/

EOF