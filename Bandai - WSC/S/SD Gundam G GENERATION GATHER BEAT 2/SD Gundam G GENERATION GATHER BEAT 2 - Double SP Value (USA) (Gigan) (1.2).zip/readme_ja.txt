SD Gundam G Generation - Gather Beat 2 Hack

「SDガンダム GGENERATION GATHER BEAT2」のIPSパッチです。

"SDGGG_GatherBeat2Hack_MainChars.ips"
【味方の主役系パイロットを強化】
・格闘パラメータと射撃パラメータの初期値を1.3倍にする。
・SP値を2倍にする。

"SDGGG_GatherBeat2Hack_SuppChars.ips"
【味方の脇役系パイロットを強化】
・格闘パラメータの初期値を2倍にする。
・射撃パラメータと素早さの初期値を1.5倍にする。
・クリティカルヒット率とSPの初期値を2.5倍にする。

"SDGGG_GatherBeat2Hack_MS.ips"
【味方のMSを強化】
・かなり強化
Ez8改、NT-1 アレックス、カプル、ガンダム、ガンダムG3、ジムジャグラー、ディジェ、百式、ボール先行試作型、メタス、リ・ガズィ、ジェガン、Gキャノン、リック・ディアスS
・やや強化
∀ガンダム(発掘時)、F91、GP03、ガンダムサンドロック、ガンダムデスサイズ、ガンダムヘビーアームズ、スペリオルガンダム、ウィングガンダム、ZZガンダム、Zガンダム、νガンダム、ガンダムmkII 0号機、シャイニングガンダム、ガンダムシュピーゲル、スモー(ゴールドタイプ)、トーラス(白)、ライジングガンダム、Ξガンダム、ノーベルガンダム(スーパーモード)

"SDGGG_GatherBeat2Hack_All.ips"
・上記全部入り。

<EOF>
