SD Gundam G Generation - Gather Beat 2 Hack

IPS patch for "SD Gundam G GENERATION GATHER BEAT 2". 


"SDGGG_GatherBeat2Hack_MainChars.ips"

[Strengthen allied main pilots]
- Increases the initial value of close combat and shooting parameters by 1.3x.
- Doubles initial SP value.


"SDGGG_GatherBeat2Hack_SuppChars.ips"

[Strengthen allied supporting pilots]
- Doubles the initial value of close combat parameters.
- Increases the initial value of shooting parameters and agility by 1.5x.
- Increases critical hit rate and SP by 2.5x.


"SDGGG_GatherBeat2Hack_MS.ips"
[Strengthen allied MS]
- Significantly enhanced
Ez8, NT-1 Alex, Capule, Gundam, G3, GM Juggler, Dijeh, Hyaku-shiki, Ball, Methuss, Re-Gz, Jegan, G Cannon, Rick Dias S
- Slightly enhanced
Turn A Gundam (When excavated), F91, GP03, Gundam Sandrock, Gundam Deathscythe, Gundam Heavy Arms, Superior Gundam, Wing Gundam, ZZ Gundam, Z Gundam, Nu Gundam, Gundam mkII No.0, Shining Gundam, Gundam Spiegel, Sumo (Gold), Taurus (White), Rising Gundam, Xi Gundam, Nobel Gundam (Super Mode)


"SDGGG_GatherBeat2Hack_All.ips"

Includes all of the above.

<EOF>
