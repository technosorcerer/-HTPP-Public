SD Gundam G Generation - Gather Beat 2 Hack

「SDガンダム GGENERATION GATHER BEAT2」のIPSパッチです。

"SDGGG_GatherBeat2Hack_MainChars.ips"
【味方の主役系パイロットを強化】
・格闘パラメータと射撃パラメータの初期値を1.3倍にする。
・SP値を2倍にする。

"SDGGG_GatherBeat2Hack_SuppChars.ips"
【味方の脇役系パイロットを強化】
・格闘パラメータの初期値を2倍にする。
・射撃パラメータと素早さの初期値を1.5倍にする。
・クリティカルヒット率とSPの初期値を2.5倍にする。

"SDGGG_GatherBeat2Hack.ips"
・上記全部入り。

<EOF>
