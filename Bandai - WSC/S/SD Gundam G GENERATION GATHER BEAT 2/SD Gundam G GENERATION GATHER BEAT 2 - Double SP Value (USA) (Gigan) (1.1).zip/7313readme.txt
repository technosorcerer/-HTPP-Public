SD Gundam G Generation - Gather Beat 2 Hack

IPS patch for "SD Gundam G GENERATION GATHER BEAT 2". 


"SDGGG_GatherBeat2Hack_MainChars.ips"

[Strengthen allied main pilots]
- Increases the initial value of close combat and shooting parameters by 1.3x.
- Doubles initial SP value.


"SDGGG_GatherBeat2Hack_SuppChars.ips"

[Strengthen allied supporting pilots]
- Doubles the initial value of close combat parameters.
- Increases the initial value of shooting parameters and agility by 1.5x.
- Increases critical hit rate and SP by 2.5x.


"SDGGG_GatherBeat2Hack.ips"

Includes all of the above.

<EOF>
