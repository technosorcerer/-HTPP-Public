Usage:

1. Press the [Refer] button to load the ROM file (.wsc)
2. Specify the pilot number in No. and press the [Read] button.
3. Change the SP value as you like and press the [Write] button
(*If you know the name of the pilot with this No., enter the name as well!)
4. Repeat steps 2 to 3 as many times as necessary
5. Press the [Save ROM files] button to update the ROM file

Request
If you find out the correspondence between the number and the pilot name, please let me know.
Share your "pilst.ini"!
