Star Hearts - Hoshi to Daichi no Shisha (Japan) (WonderGate Bypass)
-------------------------------------------------------------------

This is a nifty little WonderSwan exclusive, which also attempts to take advantage of the WonderGate. It had a little side area, accessible from the menu, which allowed you to sort of check in, see how many people were on that day or how many had signed in ever, and also shop with a vendor who would show off random wares in relation to your current progress in the game.
For the most part, this is all content that's still in the game, but would partially be shaped by community, or just provide you an advantage for having paid for an add-on spent some 2001 dollars on dialing up the Internet from a mobile phone.
It's not accessible today, though, so what to do?

The purpose of this hack is allow you to somewhat get the original experience, and gain access to these bonus shops and features
As such it does these two things specifically:
-Bypass the connection and communication process of earning the membership card, and just assigning it to you (it will always be 0, as opposed to what would have been assigned based on your position in accessing the shop)
-Bypass the connection and communication process of the daily check-in and assign a random appropriate value (as opposed to a community value), giving you a slim chance of earning some bonus items
-Bypass the connection and communication process of the all-time check-in and assign a random appropriate value (as opposed to a community value), giving you a slim chance of earning some bonus items
-Bypass the connection and communication process of the specialty shop, and allow you to browse a random selection, every time you open it up.

Essentially it approximates the original experience, although you now have the benefit of spamming these options to cycle through, and potentially have a better chance at earning something neat.

Install:
--------
This hack is compatible with the original Japanese version (No-Intro) (probably won't work with trimmed roms).
It's IPS so use your preferred patching tool, like Lunar.

The regular patch does what is suggested above and immediately below, and the CHEAT patch is explained in the second "How to" section of this readme. Only use one or the other.

There is a third patch that fixes the game for Emulators. You can use this with the bare ROM or any patched ROM.
The original game appears to have what I believe is a simple copy protection, which explicitly writes data to SRAM outside the assigned RAM space, which is likely possible on the original cart because they used a slightly large RAM than they specified, and it also works on the FLashMasta, because that has a giant SRAM, large enough to fit an almost endless number of save files.
In short, just use this for use with emulators which obey the RAM assignment so that you'll be able to save progress and not have it wiped every time you boot.

How to use:
----------------
You have to make certain progress in the game to access some of these features, but not too much.

1. Get far enough to save:
Once you load up he game, go far enough to the bottom left to go to the chiefs tent, and you'll get an ax and a save drum. Then step out of the tent, tap Y1, and save and exit.
Now on the main menu select the upper right option, and speak to the lady on the right to get your member card.
Exit.
Then select that option again, and the greeters will be there, and you can talk to them to get random values. 4 different values each will net you a set of special items.
That's all you can do for now.

2. Beat the first dungeon boss
After you beat the first dungeon boss, and hand off the item to a certain character, you'll be able to access the shop in the WonderGate menu
Go back into the WonderGate Menu, and you'll notice a door in the upper left is open.
Head up there, and the first guy will buy back items from you at decent prices
Keep going and the second guy will sell you some neat weapons, and his stock will change as you check with him, and as you progress in the game.
Speaking of which, that's all for now

3. Keep progressing in the game
As you progress more, the left door will open, and more things will happen on the right as well. Just keep playing and see!

How to get items using the CHEAT patch:
--------------------------------------
This patch is essentially identical to the normal one, except that it will always give you the good items from the greeters. And you can keep getting them over and over, and you can sell extras, and break the economy as well.
So just do as above, but enjoy really going through the game
It should be noted that one of the items is actually CURSED, and will partially present a more challenging play-through (save for bosses), which you can't get out of.
So be careful when trying out weapons!

Notes:
------

Most of the values that the greeters check are somewhat reasonable. The daily guy will check against 10, 100, and 1000, which may be a bit of a reach, but maybe the game could have been popular enough to have that happen.
But the lifetime greeters highest number is actually 1,000,000. I don't want to slight the devs of this game, because I actually really enjoy it, but considering the platform, the exclusionary accessory, and also that this game was Japan only, it seems unlikely that anyone has seen the very heartfelt message that displays when this event happens, outside of this cheat patch.
The devs most likely have records of how many people ever signed in, so I wouldn't mind seeing that info one day.
At the very least, I'm glad people can see it today.
Especially for such a neat little game like this.

