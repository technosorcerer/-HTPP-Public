Usage:

1. Press the [Refer] button to load the ROM file (.wsc)
2. Specify the MS number in No. and press the [Read] button.
3. Change various values arbitrarily and press the [Write] button.
(*If you know the name of the MS with this No., enter the name as well!)
4. Repeat steps 2 to 3 as many times as necessary
5. Press the [Save ROM files] button to update the ROM file

Request
If you find out the correspondence between the number and the MS name, please let me know.
Share your "mslst.ini"!

Supplement
Press the [Copy] button to load the weapon data into memory.
Press the [Paste] button to write the memory data to the weapon.
(*Attack animation does not change.)
