SD Gundam G Generation - Mono-Eye Gundams Hack

IPS patch for "SD Gundam: G Generation - Monoeye Gundams". 

"SDGGG_Mono-Eye_G_Hack.ips"

Power up the following MS that are easy to obtain in the early and middle stages.
(They probably won't show up as enemies.)

- Zaku II High Mobility (enhanced)
- Rick Dom (enhanced)
- Gelgoog Marine (enhanced)
- Rick Diaz (enhanced)
- Rick Diaz Q.V (enhanced)
- Rick Diaz S (enhanced)
- Super Diaz (enhanced)
- Re-GZ BWS (enhanced)
- Re-GZ (enhanced)
- Sisquiede Hyper

In addition, the following MS are enhanced slightly more modestly than the above

- Hermes (enhanced)
- Gelgoog for Char (enhanced)
- Gelgoog for J. Raiden (enhanced)
- Gelgoog for Gato (enhanced)
- Gelgoog for Matsunaga (enhanced)
- Z Gundam for Amuro (enhanced)
- Val Walo
- Gwadine

Not only the aircraft performance but also the power of the weapon, the number of bullets, and the hit correction have been enhanced.
Let's advance the game advantageously by incorporating it into the troop stack!

<EOF>
