Final Fantasy I Wonderswan
English Hack v0.91 by Kalas
(DrCaslas@yahoo.com)

Revisions:
v0.91:
 Fixed small error with 'MISS' graphic.
 Translated a graphical occurrance of 'Gil'-
 not really sure where it appears.
 Translated/fixed the 'stats up' messages
 at level up time. Totally slipped my mind
 in .90
v0.90:
 Initial Release

What is it?
* An english hack of FF1 Wonderswan.
  Note: This isn't really a true translation.
  Most of it was based off the existing NES
  version. Sorry, I don't know japanese or
  have access to someone who does, also that
  wasn't quite the goal of this project anyway.

Why then?
* Because I wanted to play the game. It'd been
  forever since I played the NES version so I
  wanted to be able to go through the WSC version
  without having to reference a FAQ every few
  minutes. So what'd I end up doing? Referencing
  a FAQ for a week. Good logic, huh? Also my
  roommate wanted to play it.

What'd you use to do it?
* Hex workshop, Thingy, SearchR2, Cygne, VirtuaNES,
  GameFAQs, http://www.classicgaming.com/ff1, WSCamp,
  and the header docs on the Cygne site.

Is this your first hack?
* Second, actually. I did a Kid Dracula patch
  a few years ago. Haven't touched any of this
  stuff in the time since. I may go back and
  finish that Kid Dracula patch now that
  the emulators are better, had to use BioNES
  back in the day on that one and it bugged
  the game considerably.

How long did making this patch take?
* About a week. Started Saturday, March 23rd, 2002.
  First release (v0.9) was on March 31st, 2002.

Why release this 0.9 version?
* Because I've finished enough that someone can
  play through the game quite comfortably without
  any japanese knowledge. That was all I wanted
  out of the project. I'm taking a break from it,
  burnt out on this game.

Will you ever finish 100%?
* Unlikely. There's other people doing actual
  translations of the game which is great. In
  the meantime people who want to play through
  can use this patch and have basically get a
  script on the level of the NES version or so.

Will you do FF2/3/4 Wonderswan?
* 2? Really doubt it.. not a fan of FF2. Maybe
  if I get bugged enough and it's laid out as
  easy or easier than FF1 is... If FF3
  ever actually gets freaking released I'd be
  on that shit in a heartbeat, it's my favorite
  FF game. 4? No. Played it a bit, wasn't
  impressed. I'll use the SNES version, thanks.

What's done:
* Most of the dialogue (about 95%+ I'd say)
* Monster names
  (some of them are painfully shortened,
   but eh, you can tell what they are. I
   didn't have time to expand them.)
* Weapon names
* Armor names
* Item names
* Most all shop text
* Inn text
* Church text
* Key Item names
  (might be missing one? there's a slot for one
   that I never actually found in the game. Maybe
   a WSC addition? There's a soundtest somewhere,
   might be linked to that? Dunno.)
* Key Item descriptions
* Battle Menus
* Spell Names
  (Removed the White/Black magic icon on the spells
   as it was fairly redundant (unless you're a red
   mage, but eh.) and there's physically only room
   for 5 letters on the spell name field, and some
   of these spells needed 5 letters.)
* Spell Descriptions
* the evil bastard of a config menu
* Most of the submenus
* Character classes and descriptions
* Character select and naming screens

What's not done:
(This is a fairly long list - but believe me,
 there's most all of this stuff isn't going to
 impact your enjoyment of the game, with the
 exception of the ending anyway. To somewhat
 resolve this I included a virtualNES savestate
 for the FF1 Ending. Have fun.)

* Title Screen. No biggie - it's New/Load/QuickLoad.
* The big one: The main menu. Most important thing
  in the damn game and I can't find the hex for it,
  lame huh. Uses a different table than the rest of
  the game, for some reason. Anyway the rest of
  the menus are done so memorizing one of them isn't
  hard. It's Item/Magic/Equip/Stats/Order/Q-Save/Config.
* A few status ailments in battle - it changes your
  name to the ailment. big whoop, look at the icon
  on your character instead - far more descriptive.
  I think I actually did two of these, but they only
  gave me two characters and I didn't feel like
  bothering to expand it.
* Description text on the config menu - not too
  important, the names are pretty descriptive,
  and frankly you're not going to want to turn
  off the enhanced mode anyway. who wants to
  miss if they target a dead monster?
* The introduction
* The bridge cutscene
* The ending
  (these 3 all use a [compressed?]
   font I haven't found yet. Might
   try to do it later, might not.)
* Subscreen 'location' window.
  (This is just a WHERE AM I type thing
   it shows by your Gil and Time.
   Nothing real essential.)
* 'Tutorial Sage' guys in Coneria.
  (Didn't feel like it.)
* Weapon/Armor Descriptions.
  (Uh. You know what a Short Sword does.)
* The Ship Mini-Game Puzzle.
* Assorted dialogue. I did everything I found,
  but I'm sure there's some punk in some town
  that you shouldn't even be going to during
  one of the events who comments on something.
  Most of it is done. Places I know I missed
  something: Arylon in Coneria says a few things
  differently from time to time. Caught most of
  them. Pretty sure I missed one or two. The
  old man in the corner of Coneria does the
  same thing.
* Non-Spell monster special attacks (Er, except
  for WarMech's "Nuclear", did that one@!#$)
* The word "Gil" when you find money in chests
  or in the store windows and crap. Not too
  important.

What Emu should I use?
* WSCamp for sure, as of this writing. Runs the
  game pretty much flawlessly with sound. Cygne has
  a lot of graphic bugs with the menus and no sound,
  but does run the game (I won it with Cygne while
  doing the hack).

Can I use your patch as the base of a translation?
* Knock yourself out, just give credit. If you seriously
  want to base something off it send me an email and I'll
  supply the table files and some tips on where stuff is
  in the rom.

And in closing?
* Have fun. Enjoy the game. Don't send me lots of
  stupid questions, please! I'm not going to reply
  to any questions about gameplay or reports of bugs
  with the patch. The maps and shit are all identical
  to the NES version, just pull out your old player's
  guide or something.

BYE!@($*@!$