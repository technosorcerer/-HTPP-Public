Final Fantasy IV - WonderSwan Color
Translation By: MottZilla

Please do not use anything from this translation without asking or giving me
credit first.

Why:

This hack actually just started out as me wanting to be able to go in the submenu 
and not have to count spaces and pick the right options. Now I hope to translate as
many gameplay related things as I can, however I'll probably leave the script untouched.

v0.5 (June 11th 2004):
* Several location names. Not All.
* Every Item Name.
* Every Item Description. Note not all items had one, thus only those that did have them.
* All Magic Spell Names which you an aqquire. Some You Cannot Aqquire May Be missing.
* Most of the Battle Commands. 
* Some Battle Messages (Gained Gold, Exp, Level)
* Some Monster Names, Most are still japanese.
* The Main Game Menu (item, equip, magic, status, etc)
* More stuff I forgot to mention.


- MottZilla
