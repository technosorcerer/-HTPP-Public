One day I'll make a nice readme file
but until then, please go to the official website
if you have any questions...

http://members.cox.net/ff2trans