================================================================================
  
 ###########    #########     ########       #######    ###     ###  ###########
######   ####  #####    ##  ####     #    #####   ###   ####     ##    ###      
######  ####  ## ###   ### ###           ## ##     ###  #####    ###  ####  
   ########   # ###   ### ###   ######  ##  ##     ###  #####    ##  #########  
  #######      ########   ###  ####### ###        ###  ### ###  ###   ###       
  ###  ###      ###       ###     ###  ###       ###   ##   ######    ##        
  ###   #####  ###        ##########   ####    ####    ##    #####   ########## 
 ###     ####  ###           #######     ########     ###     ###     ########  
 ##            ###               ###        
                                                                  Translations(c)
=================================================================================

                                  Presents

                 =============================================
                 |                                           |
                 | Final Fantasy II Wonderswan Color Edition |
                 |     English Translation Stage 1 v0.97     |   
                 |       http://rpgone.emuxhaven.net         |
                 |                                           |
                 =============================================


=================================================================================
Table of Contents
=================================================================================

I.   What's New?
II.  Introduction
III. How to Start Playing
IV.  Playing the Game
V.   Credits and Special Thanks
VI.  Help Us
VII. Disclaimer


=================================================================================
I. What's New?
=================================================================================

v0.97 (05/31/02):
Fixes many dialogue related problems.

v0.95 (05/20/02):
First Stage 1 public release, still contains some bugs. See Section VI for bug
reporting information. 
Issues we know already: 
1) The intro is untranslated due to graphic compression that we will be working 
on. 
2) The battle menu text for Attack, Items, etc, is not displaying correctly. 
3) Yes and No in shops is not displaying correctly as well.
4) Continue at game start up is not displaying correctly all the time.
Please do not tell us about the above issues since we know them already.


=================================================================================
II. Introduction
=================================================================================

Square's Final Fantasy II (J) for the NES was a revolution in the RPG genre. For 
the first time a game features a storyline that's just as focused on as the 
gameplay itself. For the first time, characters have their own personalities, 
interact with other characters and each play a critical role in the story itself. 
Unfortunately this game was never brought outside of Japan due to the fact that
Square was having problems with Nintendo at the time (1990) and FFII never saw 
release in North America, a place where the original Final Fantasy outsold its 
counterparts in Japan.

Enough with the history lesson. Final Fantasy II was re-released in 2001 on the 
Japanese handheld Wonderswan Color, which was also never released outside of 
Japan because its maker, Bandai, was afraid it wouldn't sell with the Gameboy 
Advance about to be released. So here, RPGOne brings you Final Fantasy II in 
English, so people all over the world can finally enjoy this great game in a 
language that is more widely understood.

The translation is being done in two stages. The first stage is an adaptation of 
Neo Demiforce's original translation of the NES FFII by RPGTess. This release is
done so that people can play this game in English as early as possible without
having to wait too long to play. 

The second stage will be a full translation, and will contain as many enhance-
ments to the game as we can possibly fit in. The translation will be done by 
SpSpiff, the translator of RPGOne's Dragon Quest I&II Remix and Byuu's Dragon 
Quest V. Whichever one you play however, you will enjoy! 


=================================================================================
III. How to Start Playing
=================================================================================

The zip includes this readme and the FFII IPS file. You will need to apply this
patch onto a ROM image of FFII. Please do not ask us where to obtain this image, 
it can be done with a careful search of the Internet. However, it is required 
that this patch be applied to the ORIGINAL, unmodified ROM.

To apply the image, to will need an IPS patching program. The easiest one to use 
would be IPSWin. You can get this and other programs from www.emuxhaven.net.

After you patch the ROM, you will need to get a Wonderswan Color emulator, 
preferably WSCamp, as it runs the game with the best sound and speed, but you can
also use Cygne or Oswan if you want, since they offer more features.

After you're done getting all that, just start up the emulator, load up the rom, 
and start playing!


=================================================================================
IV. Playing the Game
=================================================================================

The gameplay of Final Fantasy II is very different from other Final Fantasy 
games. For one thing, characters do not get experience points to level up. In 
order to gain stats in this game, you must use that stat. For example, to raise
your HP, you must lose HP in battle. To raise your weapon strength, you must
use the weapon. For more information on how to play the game, visit Gamefaqs at
www.gamefaqs.com or visit our website at rpgone.emuxhaven.net.

The default controls for the game are as follows:

D-Pad        : Move characters
A Button     : Confirm 
               Interact with entity in front of character
               Open a treasure chest
               Activate a switch
B Button     : Cancel
               Hold to run in towns and dungeons
Y1 Button    : Equipment Screen
Y2 Button    : Item Screen
Y3 Button    : Menu Screen
Y4 Button    : Magic Screen
Start Button : Menu Screen


=================================================================================
V. Credits - Stage 1
=================================================================================

Programming and Hacking 
  ChrisRPG
  Squall Alpha

Script Insertion
  RPGTess
  Squall Alpha

Fonts and Graphics  
  Squall Alpha

Project Leader
  RPGTess

Readme Writer
  Brightman

  
Special Thanks to

Devoid - Major help early on in the project
Neo Demiforce - Translator of the original NES FF2
Emuxhaven - Host of RPGOne website
Kalas - Involved in the birth of this project and helping RPGTess 
Anoda - For paying for the computer that ChrisRPG uses.
Brightman - All the non-hacking work

=================================================================================
VI. Help Us
=================================================================================

Please report all bugs to ChrisRPG at crisrpg@bellsouth.net.


=================================================================================
VII. Disclaimer
=================================================================================

Final Fantasy II and all related images, names, and themes are trademarks of 
Square Co., Ltd. 

RPGOne is in no way or form affiliated with Square and any other video game 
companies. It shall not be held liable for any damages of any type arising out of 
or in any way connected with your use of the products it provides.

Visit RPGOne's webpage at http://rpgone.emuxhaven.net
