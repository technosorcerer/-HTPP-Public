Over Obj contains a hidden Debug Options menu containing Muteki (invulnerability), Heranai (infinite lives), Stage Select (allows selection via "Left" and "Right" when hovering on "Continue" on the main menu), Rest (0-9 number of lives), BGM (0-17 music tracks), and SE (0-15 sound effects).  It is normally accessible at the title screen by holding down "B" and pressing "Right" 9 times, "Up" 2 times, "Left" 2 times, "Down" 9 times.  This patch bypasses the need for inputting that button code.

Use either the bps, ips, or xdelta patch depending on your needs.

Pre-patch rom file
***
Name: Over Obj (World) (Aftermarket) (Unl).nes
Size: 262160 bytes (256 KiB)
CRC32: F8D5AD55
CRC64: E63FE1111DCB210F
SHA256: 9C711F3F5ECF64FAAE77B7B871F7F585DE5C4B95E6E295B82AAF31DA832236BF
SHA1: 7748941751E4405DDE696A24ECDB71150CA5EB55
BLAKE2sp: 98BE23FE654A1C7591681E6BD31C0881BADC556B12A1912CD0E1304A9E76EEEB

Post-patch rom file
***
Name: Over Obj (World) (Aftermarket) (Unl) - Debug Options.nes
Size: 262160 bytes (256 KiB)
CRC32: 0DF40C39
CRC64: AFDDE166056CCC76
SHA256: AF55573B3421E4AFDFB608A0F2B84D916A138FCF4B691379A59A050CA8BEE443
SHA1: 8FB0DA1D272802A30AAA323EF73886362D69DFBF
BLAKE2sp: BAECB3384040065A4EAB078CD10D00094C408B9DAE7BD838A898BB7E4A1B12CF
