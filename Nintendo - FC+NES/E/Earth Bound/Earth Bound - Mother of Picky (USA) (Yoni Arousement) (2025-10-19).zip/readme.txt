---------------------------------------------------------------
Mother of Picky

By Yoni Arousement

My oldest ROM Hack that I saved, which dates back to September
18, 2010.

A silly and juvenile ROM Hack where Ness is changed to Picky,
Paula is changed to Tracy, Jeff is changed to Porky/Pokey, and
Poo is changed to a Mr. Saturn named Satsy (likely named after
a Starmen.net user). Picky (Ness) can't learn offensive PSI.
But the actual Picky, Tracy and Pokey are unchanged.

Some of the dialogue is edited to include cussing or sexual
references, and many of the enemies are changed, featuring
girls who show their valuable panties. Attack Slugs can now
poison you. Thirsty Coil Snake and Balloon Girls are too
powerful, and the latter resists PK Fire but is weak to PK
Freeze, and can call even more Balloon Girls for help. It
makes going through Peacful Reset Valley miserable until you
get Tracy. Annoyingly, a lot of the enemies are immune to
Bottle Rockets.

A few music tracks are edited, with Onett's music getting
messed up, the Sanctuary Boss Theme and Fourside's tempo is
sped up to sound closer to its rendition in Super Smash Bros.
Melee. This ROM Hack introduced a bug where Picky can eat
health items during battles without consuming them from his
inventory, similar to the good 'ole Rock Candy trick. I didn't
know girls' panties can be so lethal.

The photographer is now a Ranboob who creates nightmares out of
the pictures he takes. During his photo shoots, Tracy 
disappears, and Picky turns into Tracy flashing her skirt while
opening her mouth. Certain blonde guys now tell you what to do
next in the early game.

Before the Department Store Mook appears, give the Franklin
Badge and the ATM card to either Tracy or Pokey.

Patch over a US EarthBound ROM.
---------------------------------------------------------------