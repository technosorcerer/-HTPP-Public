While DragonDePlatino's MOTHER - 25th Anniversary Edition is a wonderful work of art with excellent graphical and script overhauls, the core mechanics of the game itself were not inherently flawed, even if they were a product of RPGs of the time. The difficulty could be satisfying to a great many players, and the internet is rife with analytical resources picking apart the mechanics of the game. Dragon's changes sadly render many of these resources irrelevant.

This patch reverts all changes to character stats and enemy stats, allowing players to experience the challenge of the original game, while still enjoying the beautiful art, map, and script changes. Enemies are just as tough and unforgiving as in vanilla, but appear slightly less frequently and reward 25% more exp. The idea to this patch is to make the game less tedious while still keeping combat faithful to its challenging origins. Re-Faithful pairs well with MOTHER - Vanilla Sprites and MOTHER 25th Faithful Edition.

This patch DOES:

-Revert initial character stats to original MOTHER state
-Revert character stat growth values to original MOTHER state
-Revert enemy stats to their vanilla state for resource consistency and challenge's sake
-Revert grossly nerfed enemy encounter rates back to a difficult but not unreasonable frequency
-Slightly revert Dragon's streamlining of level-up text; pauses are added at RNG breakpoints (after "level up!", after 5 primary stats gain, after HP gain, and after PP gain)
-Revert a few of Dragon's battle theme changes to be more contextually appropriate; made one or two changes myself

This patch does NOT:

-Revert any graphics (for overworld sprites only, see other patch linked in description)
-Revert level-up text to its slow, tedious, pause-between-every-single-stat behavior as in vanilla
-Revert ALL of Dragon's battle theme changes (there were some very nice choices that fit more than the original; again, context is important)

~~~~~~~~~~~~~~~~~~~~~~~~~~~
    Patch Compatibility
~~~~~~~~~~~~~~~~~~~~~~~~~~~

As this is an addendum, it is required that you apply Re-Faithful AFTER 25th Anniversary or 25th Faithful Edition. If you are planning to use my Vanilla Sprites patch, recommended patch order is as follows:

- MOTHER - 25th Anniversary Edition OR MOTHER - 25th Faithful Edition (do not apply both of these to the same ROM!)
- MOTHER - Re-Faithful
- MOTHER - Vanilla Sprites (apply this at the end of any load order)

I cannot say how compatible Re-Faithful is with other patches not listed here, so please experiment at your own risk.


~~~~~~~~~~~~~~~~~~~~~~~~~~~
        Changelog
~~~~~~~~~~~~~~~~~~~~~~~~~~~

v1.0
* Music Changes: Most intense theme takes precedence in enemy groups of order Dangerous, Hippie, Flippant
- Reverted Snake from Dangerous to Flippant
- Reverted Willy from Hippie to Flippant
- Reverted Mr. Batty from Hippie to Flippant
- Reverted Gorilla from Flippant to Dangerous
- Reverted Groucho, Mom Eyes, Dad Eyes, Four Eyes, and Eyes from Hippie to Flippant
- Reverted Barbot from from Flippant to Dangerous
- Reverted Bag Lady from Hippie to Flippant
- Reverted Eagle from Hippie to Dangerous
- Reverted UFO from Hippie to Dangerous
- Reverted Cougar from Flippant to Dangerous
- Reverted Bear from Flippant to Dangerous
- Reverted PolarBear from Flippant to Dangerous
- Reverted BioBat from Hippie to Flippant
- Reverted DeathBarbot from Flippant to Dangerous
- Reverted OmegaSaucer from Hippie to Dangerous
- Reverted Tough Crocodile from Flippant to Dangerous
- Reverted Cerebrum from Hippie to Dangerous
- Reverted Grizzly Bear from Flippant to Dangerous
- Reverted Star Miner from Flippant to Dangerous

* Combat Changes
- Reverted character initial stats and character stat growth values, as well as character EXP to level up values
- Reverted Mt. Itoi's 2x and 3x Rockoyle/Satania battles that Dragon reduced to 1x and 2x
- Reverted enemy stats that were significantly nerfed
- Encounter rate increased from Dragon's patch, which made battles almost nonexistent; the numbers in the encounter "steps" were slightly adjusted so that the highest frequency is ~1/10 rather than ~1/8
- Increased experience of enemies across the board by 25%, rounded down (any enemies that give less than 4 EXP in vanilla are unaffected by this buff)
- Streamlined level-up text without bypassing RNG breakpoints, allowing for min-max/save-scum play for those players who want it

* Miscellaneous Changes
- Fixed a few minor typos in DragonDePlatino's retranslated script