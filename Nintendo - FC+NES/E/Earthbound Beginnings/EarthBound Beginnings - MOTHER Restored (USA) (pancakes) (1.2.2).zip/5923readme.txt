
~MOTHER Restored v1.2.2~


MOTHER Restored is a patch for EarthBound Beginnings that aims
to make it as faithful as possible to the Japanese version of
MOTHER while keeping its gameplay improvements.

In this patch:

The game's script has been completely replaced with the more accurate
translation done by Tomato for MOTHER1+2, including dialogue, battle
text, item and enemy descriptions, and other miscellaneous text.
Unlike previous attempts to replace EarthBound Beginnings' dialogue,
this patch repoints virtually all of the text in the game. This allowed
the fan translation to be included in its entirety. The main version
also makes names of characters, locations, and items more accurate to
what they were originally.

Graphics that were altered in localization have also been restored,
including: 
- The title screen
- Character sprites
- Enemy sprites
- Various crosses throughout the game
- The text on the world map
- The "YOU WIN!" font

You can read more about these changes here:
https://tcrf.net/EarthBound_Beginnings/Regional_Differences


Included are two versions -

MOTHER Restored: This version makes the names of characters, items,
and locations closely match the Japanese game.

MOTHER Restored (1+2 Edition): This version has the same
character, item, and location names as the MOTHER1+2 fan translation.
Pick this if you want to keep continuity with the official release of
EarthBound. 


 
To use the patch:
 
  1. Extract the contents of the zip file.

  2. Apply one version of the patch to an unmodified copy of the
     prototype ROM - it should be called "Earth Bound (USA) (Proto)"
     - using a BPS patcher such as Floating IPS, or an online BPS
     patcher.

     Modern emulators such as Mesen (which I highly recommend
     using) also support the ability to automatically load 
     patches without modifying the original ROM. Simply name
     both the ROM and the patch the same thing, and keep them in
     the same folder when you run the game.

  3. Enjoy the game! 

  



Credits

Hacking - pancakes
Translation - Tomato


Changelog:

v1.1
-Polished up some text
-Fixed a typo

v1.2
-Fixed an uncommon battle text overflow
-Added an alternate version of the patch with names that match
 the 1+2 fan translation and altered ATM graphics

v1.2.1
-Corrected the Mouse's description to read mouse instead of rat
-Corrected the 1+2 version's disallowed names to use Giygas instead
 of Gyiyg

v1.2.2
-Minor optimizations to item names