This is another addendum to pancakes’ MOTHER Restored hack that offers two small 
patches to tweak the game’s difficulty:

 *  Easy Mode by Default gives you the benefits of the Easy Ring without having 
    to tie up one of your ring slots. The original difficulty is still available 
    by equipping the new Hard Ring item.
 *  No Starting Ring removes the present in Ninten’s room that would normally 
    give you the Easy Ring (or the Hard Ring if the above patch is applied).

The Easy Ring is an item from Tomato’s MOTHER 1+2 Fan Translation that reduces 
random encounters and increases experience and money from battles. The values 
that Tomato landed on are very well-tuned and this mode comes highly recommended, 
especially for first-time players.

Both of these patches are compatible with one another and with Earth Bound Restored. 
For the encounter rate changes to work correctly, you must apply the Earth Bound 
Restored patch before your chosen patches from this pack.
All patches should be applied to a rom already patched with MOTHER Restored.

Proto Header:  
File SHA-1: 320E027A6A138D73729161A54E182A2DDEDE75F6  
File CRC32: D68579A7

VC Header:  
File SHA-1: 915A9937B542DA7087CF837541E1C0220E0837BA  
File CRC32: B1075ED4

ROM SHA-1: 0A3EA1BBBC3271502BE943098D994D9250B1AE9B
ROM CRC32: 70C3CB1F