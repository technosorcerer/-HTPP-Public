This patch changes the title screen of pancakes' MOTHER Restored patch from the 
Japanese MOTHER design back to the Earth Bound title screen from the US prototype.

Optional patches are included to add 989fox989's "Beginnings" subtitle or the 
"ZERO" subtitle from the old Demiforce rom. These should be applied after the 
main "Earth Bound Restored" patch.

This patch should be applied to a rom already patched with MOTHER Restored. 
This patch is compatible with both of the patches included in MOTHER Restored 
Difficulty Tweaks, as long as you apply this one first.

Proto Header:  
File SHA-1: 320E027A6A138D73729161A54E182A2DDEDE75F6  
File CRC32: D68579A7

VC Header:  
File SHA-1: 915A9937B542DA7087CF837541E1C0220E0837BA  
File CRC32: B1075ED4

ROM SHA-1: 0A3EA1BBBC3271502BE943098D994D9250B1AE9B
ROM CRC32: 70C3CB1F