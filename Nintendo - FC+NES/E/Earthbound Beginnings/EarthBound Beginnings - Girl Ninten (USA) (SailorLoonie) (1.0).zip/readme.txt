XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
X Earthbound Beginnings - Girl Ninten X
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX                                                             
                                                                                      
___________________________________________________________________________     
                                                                                
                                                                                   
This is a hack that makes the main character of the game into a girl.               
                                                                                      
This was done so that certain players may feel a closer connection to                             
their main character.

This hack changes dialogue in the game to use feminine terms to refer to
the main character. Additionally, it allows the main character to receive
and use the MagicRibbon. Finally, it changes a single NPC who gets named
after the main character during the course of the game to be femme as well.

I hope that you enjoy the hack!                              
___________________________________________________________________________
Target ROM checksum info:

Rom name: EarthBound Beginnings (USA, Europe) (Virtual Console).nes

SHA-1: f338af0af0058dc692d6003e04b4094bb324d2c5 
CRC: abbe02fa              

___________________________________________________________________________
This is a BPS patch, and can be applied to a ROM using Floating IPS "FLIPS"
found here: 

https://www.romhacking.net/utilities/1040/

___________________________________________________________________________

Updates

9/8/2024 - Initial release!

10/14/2024 - Disabled anti-piracy screen.

___________________________________________________________________________           
                                                                                  
Hack created by SailorLoonie!
Additional testing done by Limni and Jelly!
Special Thanks to Blue Ribbs, the creator of the Earthbound - Girl Ness
rom hack! Without that hack, and the wonderful time I had playing it,
I never would have started work on this hack.

If you find any issues with this hack, please send me an email at 
dj.capn.b@gmail.com!