                            MOTHER Restored v2.0
                           Released July 27, 2024
					
This is a patch for EarthBound Beginnings that replaces the game's script
with the MOTHER 1+2 Fan Translation and restores the graphics that were
changed or censored during localization. Also included are improvements from
the fan translation, like:

- Expanded text boxes, menus, and names, allowing for more natural and
  presentable text

- The fan translation's improved font

- The "Easy Ring" added to a present in Ninten's room. This item, when
  equipped, greatly increases the experience and money you win from enemies
  while also reducing the amount of random battles.

And improvements specific to the NES version:

- The overall text speed has been increased

- Some bugs in the original game have been fixed

============================================================================

How to use:

    1. Extract the contents of the zip file.

    2. Apply the patch to an EarthBound Beginnings ROM with Romhacking.net's
       online ROM patcher found here: https://www.romhacking.net/patch/ or
       by using a standalone patching program.

       Alternatively, most modern emulators are able to automatically load
       patches without modifying the original ROM. To do so, simply name
       both the patch and the ROM the same thing, e.g., "mother.bps" and
       "mother.nes", and keep them in the same folder when you load the ROM.

    3. Load the ROM in your emulator of choice; I recommend Mesen.

============================================================================

Changes made by this patch:

    - Replaced the script with Tomato's translation.
    - Restored MOTHER's original sprites, graphics, and palettes.
    - Restored MOTHER's title screen and intro.
    - Made the UI more consistent with the Famicom and GBA versions.
    - Expanded the dialog and battle text boxes.
    - Expanded the enemy name box, allowing for longer enemy names.
    - Modified text routines to allow for more text at a time.
    - Made it so that text is cleared only when necessary, increasing the
      text speed.
    - Added automatic word wrapping for battle text.
    - Added item articles for when an item is used or won in battle.
    - Added a space before enemy suffix letters.
    - Enabled the "'s party" control code.
    - Added the fan translation's line for capsules.
    - Added the Easy Ring.
    - Replaced the ATM graphics with the ones used by the fan translation.
    - Replaced the font with the one used by the fan translation.
    - Made it so that Ninten's friends have default names, like MOTHER 1+2.
    - Made it so that Flying Man's name is no longer abbreviated in battle
      (requires a new save file to work).
    - Fixed Minnie's color palette during the ending.
    - Fixed an issue where, when Lloyd was knocked unconscious by a Super
      Bomb, Ninten's name would be displayed instead.
    - Fixed an issue where the guitar player in Magicant could sing his song
      before the requirement was met, or vice versa.

============================================================================

Troubleshooting:

    Q: I can't get the patch to work!
    A: Make sure you're using an original, unmodified ROM, and follow the
       directions above.

    Q: How do I unequip the Easy Ring?
    A: The only way to unequip an item is to equip something in its place.

    Q: I found a bug/typo!
    A: Please contact me on Romhacking.net.

============================================================================

Credits:

    HACKING
    pancakes

    ORIGINAL TRANSLATION, ORIGINAL DESIGN FOR THE EASY RING
    Tomato

