This is a small addendum to pancakes' MOTHER Restored patch to revert the 
Mother title screen and intro back to the US prototype rom's Earth Bound 
title screen.

You should apply this to a rom already patched with MOTHER Restored.

Proto Header:  
File SHA-1: 0A3EA1BBBC3271502BE943098D994D9250B1AE9B  
File CRC32: 70C3CB1F

VC Header:  
File SHA-1: 915A9937B542DA7087CF837541E1C0220E0837BA  
File CRC32: B1075ED4