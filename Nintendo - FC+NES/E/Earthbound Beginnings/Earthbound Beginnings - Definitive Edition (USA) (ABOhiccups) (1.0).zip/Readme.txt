Thank you for downloading EarthBound Beginnings: Definitive Edition.

EarthBound Beginnings: Definitive Edition is a fork of Earth Bound Beginnings 25th Faithful Edition by Rodimus Primal, Mother 25th Faithful Edition by ShadowOne333, and Mother 25th Anniversary Edition by DragonDePlatino with EarthBound Beginnings Title Screen by 989fox989 added.

All you need is a clean ROM of EarthBound Beginnings or Earth Bound (Proto).

==================================================
Changes
==================================================

Changes in Mother: 25th Anniversary Edition
- All enemy graphics, NPC sprites and tiles are be redrawn from scratch to be more faithful to the clay models. The goofy enemies are goofier and the creepy enemies are creepier. A shiny new font and title screen was added, too!
- The overworld has been tweaked to be much less bleak and repetitive, so it’s harder to get lost. There is more scenery, areas are more colorful and confusing areas like Duncan’s factory have been simplified. On the other hand, tiny areas like the Cemetery or Snowman have been expanded.
- There are also a lot of changes under the hood. Enemies will yield slightly more exp and the encounter rate has been readjusted. The “Dangerous Foe” battle theme is used less often and party members will be met at a higher level. DragonDePlatino’s goal in creating this hack was to make Mother less challenging, but still quite difficult.
- And last but not least, this hack uses Tomato’s official Mother 1 + 2 translation, adapted for the NES. Over 1400 lines of text have been altered to create connections with the rest of the series, improve clarity and shorten reading time. This hack will also feature much quicker battle text courtesy of vince94. Battles progress almost twice as quickly!

Changes in Mother 25th Faithful Edition
- Intro sequence colors changed to match the original Mother (Red / Blue / White).
- Main Title Screen modified to match the original Mother Title Screen screen (without subtitles but retaining the modified credits at the bottom).
- Giegue name changed to Giygas.
- “Status” stat changed to “Wisdom”.

Changes in Earth Bound 25th Faithful Edition
- Change the text from "Mother" to "Earth Bound" on Map Screen.

Changes in EarthBound Beginnings: Definitive Edition
- A Title Screen by 989fox989 was added
- Intro Credits font was restored back to original font

==================================================
All credits goes to all ROM Hacks Creators
==================================================

Mother: 25th Anniversary Edition by DragonDePlatino
https://www.romhacking.net/hacks/2211/

Mother 25th Faithful Edition by ShadowOne333
https://romhackplaza.org/romhacks/mother-25th-faithful-edition-nes/

Earth Bound Beginnings 25th Faithful Edition by Rodimus Primal
https://www.romhacking.net/hacks/2533/

EarthBound Beginnings Title Screen by 989fox989
https://www.romhacking.net/hacks/5669/