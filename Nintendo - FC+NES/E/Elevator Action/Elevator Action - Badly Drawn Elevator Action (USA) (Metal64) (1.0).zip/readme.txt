Hack Name: Badly Drawn Elevator Action

A Hack Of: Elevator Action (USA)

Hacked By: Metal64

Youtube channel: https://www.youtube.com/user/MetalOverlord64

2 Youtube channel: https://www.youtube.com/channel/UCPVhjP2tmdRVpqfD5TOymKA


About the hack

I just redraw all the sprites as badly as I could