When setting up to start a random graphics hack of Excitebike, I noticed an unused green racer palette in the ppu viewer. Through a decent bit of experimentation and help from a good friend, this green racer now joins the race!

Features:

All 4 racers now have thier own colors!
oRBIT's savegame patch, so you can save and load user-made tracks!

Patch to Excitebike (Japan, USA).nes rom

Credits/Special Thanks

oRBIT, for creating the savegame patch
Dr. Floppy, for helping track down the racer palettes