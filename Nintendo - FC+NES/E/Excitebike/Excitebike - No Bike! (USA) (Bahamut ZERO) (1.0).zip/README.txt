A graphics and text hack that jacks up the excitement of Excitebike - by removing the bikes entirely!

Features:

A unique player color for each track
Palette swaps for every track
oRBIT's savegame patch, so you can save and load user-made tracks
No bikes!


Patch to Excitebike (Japan, USA).nes rom