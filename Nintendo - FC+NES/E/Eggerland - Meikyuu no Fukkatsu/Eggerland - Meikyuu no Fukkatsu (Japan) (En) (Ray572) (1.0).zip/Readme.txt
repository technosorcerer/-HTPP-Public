Name: Adventures of Lolo: Revival of the Labyrinth (USA)
Name Original Japan: Eggerland - Meikyuu no Fukkatsu (Japan)
Patch Add Versión 1.0.

This is my first project, please don't ask too much of me. I used the Mesen emulator to modify the main title and give the game a more "western" feel. The patch is an addendum that should be applied to Kapow's translation. It can eventually be applied to a clean rom but it wouldn't make sense. I hope you like it.

Database match: Eggerland - Meikyuu no Fukkatsu (Japan) [T-En by Kapow v1.0] [Add by Kapow v1.0] 
(The Add (addendum), is the additional patch to translate the password menu, made by Kapow himself. It is not required for my patch but it is recommended for a better experience.)
File CRC32: 9A0D9301
File SHA-1: afbed93544e7642717d18480dea88b5aba9b4f61

Translation by Kapow (https://www.romhacking.net/translations/941/)
Title screen Modified by Ray572

The file comes with a bonus media made by me from the Japanese version covers but modified to the "USA" version. :)