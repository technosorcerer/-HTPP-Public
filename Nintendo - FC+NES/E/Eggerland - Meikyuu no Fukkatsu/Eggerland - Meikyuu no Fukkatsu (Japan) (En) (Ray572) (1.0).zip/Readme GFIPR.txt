Name: Go for It! Pennant Race! (USA)
Name Original Japan: Ganbare Pennant Race! (Japan)
Patch Add Versión 1.0.

Continuing in the line of modifying main title screens I bring you this patch to continue the Ganbare Goemon series, which as in the previous games the word Ganbare was translated to "Go for It! And this game will not be the exception, since the same character from the adventure game appears but now we have him playing baseball.
The patch must be applied to the rom already translated by FlashPV.
Also as in my previous patch, the file comes with Bonus Media made by me.

Nombre: Ganbare Pennant Race! (Japan) [T-En by FlashPV V.98]
CRC-32: 6871CC56
MD4: 7ddba16bcf9bc5c27aafb1fd4dde45a2
MD5: 421fe597a9add020f8aa07042890b2e7
SHA-1: bb75d7a5aadfac4b38b88c08fea3fc8c6f56acdc

Translation by FlashPV (https://www.romhacking.net/translations/5442/)
Title screen Modified by Ray572
