FF3 Touch-ups & Fixes

This relatively small-scale project, FF3 - Touch-ups & Fixes.ips, includes the four following components:

1. 10 corrections to sprite drawing errors across various jobs in battle, similar in nature to my prior touch-up patches for FF1 & FF5

2. A bugfix for the elemental magic damage boost affording by certain rods & staves not working. Resulting damage with those spells seems to be appx 20% higher.

3. A fix to a problem with rows in the native game, where any row adjustments made in battle would be saved after battle, and thus have to be manually adjusted. With this fix, any row changes during battle will be reverted back to the pre-battle arrangement afterwards.

4. A fix to the flee bug, where the game was supposed to set evade to zero while fleeing but mistakenly set defense to 0, making any attempts to flee exceedingly deadly. 

All four of these components are included in the main patch, but all four of them are included in separate patches in the individual components folder.

These patches were tested with the Alex W. Jackson, Neill Corlett, SoM2Freak translation, but should work with most other versions of the game. 



V. 1.0 released 9/12/2024



Additional detail on the sprite fixes:

Warrior: Fixed ear not moving up with the head while celebrating

Monk: Wrong color chest apron in right hand animation 

Red Mage: Fixed disappearing white trim on robe during right hand animation

Knight: Fixed red tone pixel on head that appears in victory frame

Mystic Knight: Fixed eyes in victory frame from blue to yellow

Mystic Knight: Fixed eyes in knocked out frame from blue to yellow

Warlock: Fixed crescent on head changing color in victory frame

Devout: Fixed inconsistent bottom of cape line when attacking with left arm.

Summoner: Fixed inconsistent right foot length during right hand attack

Ninja: Fixed right foot inconsistent movement when attacking with left hand

The best place to view the above noted issues is:

https://www.videogamesprites.net/FinalFantasy3/

Note: the linked website does not show the discoloration with the Warlock's crescent for some reason, but it very much appears within the game.



Credits / Thanks 

The elemental boost fix wouldn't have been possible without everything8215's FF3 disassembly. 

The row fix component involves ASM work by everything8215 which he generously contributed after I had reached out to him for guidance on the issue.

Credit to Maeson for the flee defense bugfix.