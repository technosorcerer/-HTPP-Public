Felix the Cat (NES)
Traducción al Español v2.0 (11/10/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Felix => Félix
-1UP => 1VD
-Pantalla de título
-Añadidos caracteres españoles
-Nueva traducción
-Traducido FELIX WORLD
-Traducido GAME OVER
-Traducido cartel GOAL
-Traducido TIME UP
-Traducido THE END
-Parche de smoke_th para devolver el brillo

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Felix the Cat (USA) (Hudson).nes
MD5: 9ac05a0ec9d615e18c74b4c0b16844e6
SHA1: b57b1c6e6933432694e920694cfa10dae5c5961b
CRC32: 3856f581
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --