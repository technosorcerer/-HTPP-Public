Before getting into the minutia of this cruel world, I should clear up some questions.

Famicom Merciless is based on the vanilla FE1, NOT THE REBALANCE HACK. This hack is supposed to feel as close to the original game as possible,
and was designed as if FE1 had difficulty options baked into it's design. Archers only have 5 MOV, and Ballisticians are completely worthless. I'm sorry.
I took a few liberties here and there, and those will be mentioned when they're relevant, but don't expect awful units like Wrys and Vyland to suddenly 
have merit. Then again, you might find use for them if lines are stretched thin enough. Everbody counts, right? 

So what does this "Merciless Mode" entail? Generally, enemies have inflated HP, STR, SPD, have higher levels, and get more dangerous equipment sooner.
By Chapter 6, all enemies are using Steel weapons. Chapter 12 onward, all enemies use silver weapons. You get the picture.

It may seem hopeless, but fear not, because due to how enemy stats are generated, recruitable characters like Darros and Castor are subject to the same
crazy stat boosts that enemies are! These rudimentary hard mode "bonuses" should help even the playing field. I've also increased the exp gained by
killing a foe by 8-12 points for every enemy.
Here's how EXP works:
;If the foe was hit, but not killed in combat, gain EXP = to the damage dealt. This caps at 20, so that's the most you can get without killing a foe.
;If the foe was killed, you gain the EXP displayed on their stat screen. This number is determined based on class and increased by 1 for each level
the enemy has gained. For example, if a Thief gives 40 EXP, and it's level is 10, it should give out around 50 EXP. Be warned, you do not get any extra
EXP from killing a foe in a single round of combat. You only get so-called "Hit EXP" if the foe survived combat with your unit.
;If the foe was missed, you get NOTHING!
That's basically it. Dodging hits during enemy phase yields no reward unless you're a Priest (in which case you gain kill EXP).

Weapon Durability is virtually identical to the base game, but all weapons have been buffed to the nearest 5 or 10 so that my OCD stops going off 
like a goddamn smoke alarm. Don't expect much, just be glad silver swords have 20 uses instead of a mere 17.
As for larger scale weapon changes, most axes are lighter, more accurate. Devil Weapons have 100 hit. Better watch out for them. 
The Gradivus, Mercurius, Devil Sword, and Devil Axe deal effective damage to Medeus, because the Falchion is missable, and I don't want the player to 
get completely stuck on him. What's the point of the Falchion then, you say? I don't know. It's like a slightly stronger Mercurius in this hack.

This should cover everything you need to know about the garish, ugly world that awaits you in Fire Emblem: Famicom Merciless!
Special Thanks to Vince Vodka for providing feedback on most of this hack's new ideas, and for playtesting most of the game. Without his involvement, 
I imagine the placements of those Dracoknights would be far more unfair.
























































































































































































































Do you think my color choices for the maps are nice?