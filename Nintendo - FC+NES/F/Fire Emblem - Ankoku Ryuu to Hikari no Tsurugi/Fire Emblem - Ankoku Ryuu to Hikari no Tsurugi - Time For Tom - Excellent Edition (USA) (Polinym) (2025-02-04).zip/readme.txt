	Time For Tom is the world's first complete
FE1 hack created by Polinym! This hack features a number
of brand new features, as well as an original story with 18
chapters. This project is the result of 4 months of research
and experimentation with Fire Emblem: Shadow Dragons and the
Blade of Light.

	Two friends, Thomas and Jake, set off an quest to
find a lost item called the Time Orb. Supposedly, it allows the
user to travel through time. Unfortunately, the two have no idea
how to use it! The Time Orb takes the friends on an excellent
adventure through a few games in the Fire Emblem series to right
the wrongs of history.

	If you want to know who recruits who, then be sure to
pay attention to ALL the dialogue! If it helps any, Thomas recruits
the first enemy unit. There's also SECRET recruits! :)


Differences in gameplay from the original game include:
 - New items
 - New maps/portraits/graphics/units
 - Magical attacks use Strength/Magic stat
 - Thunder swords use the Strength stat
 - Stat caps are raised to 50
 - Hunters/Generals can promote
 - All classes promote using Master Proofs
 - Generals can weild bows, lances, and swords
 - Player and Enemy Units have Resistance
 - Units have Resistance growths
   *Res. growth is not displayed in battle messages, but works
 - Weapon Triangle
 - Protagonist always has access to the Convoy
 - Storing items in the convoy is free
 - Items from the base game use their Monshou stats instead
 - Items from other games use stats from their respectives games
 - Crossbows are now 1-2 range, have lower accuracy and higher crit rate
 - Fewer than the required units can be deployed in chapters

	This patch should be applied to an original Japanese
Ankoku Ryu to Hikari no Tsurugi ROM. 

	And remember, HAAAVE fun with it! :)


