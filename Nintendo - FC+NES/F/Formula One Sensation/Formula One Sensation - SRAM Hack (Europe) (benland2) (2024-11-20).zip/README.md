# F1-Sensation-Rom-Hack

In fact, this game already contains the code for the saves: the save menu and the load menu. However, on the original cartridge, all files are erased when the power is turned off (even if you install a battery in the cartridge). Apparently, at the final stage of the development of the game, it was decided to reduce the cost of production, so a system of criminally long passwords was introduced. This simple patch fixes the signature verification code so that save files are no longer erased when the power is turned off if there is a battery in the cartridge.

Thanks to Alexey 'Cluster' Avdykhin who is the author of the original hack for the Japanese version.


ROM information:
Database match: Formula 1 Sensation (Europe)
Database: No-Intro: Nintendo Entertainment System

Credits:
Benland Goutz
bgozzo@hotmail.com
