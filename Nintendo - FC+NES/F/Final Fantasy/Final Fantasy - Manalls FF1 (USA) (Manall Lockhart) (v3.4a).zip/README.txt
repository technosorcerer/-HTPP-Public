░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒

          --- Manall's FF1 ---

         http://manallsmods.net

   ... for patch notes, updates, and
       news about my other projects.

▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░

Hello! Thank you for trying my mod.

I love everything about this game. Years of effort went into making this fresh, tougher, modern experience with some new flair. 

I've made some charts to help you on your journey - click the documentation link that came with the mod to view them.

GOOD LUCK!

contact: manalockhart@gmail.com
discord: cyandral

(psst. If you wanna try Magecore/Lunarscape, you'll have to defeat CHAOS first.)

░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
                                
          Getting Started (2025)
          ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯
▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░

Apply my .ips patch to a headered*, unmodified "Final Fantasy (USA).nes" rom file.

For emulators I recommend Mesen, FCEUX, Nestopia or Delta. Please avoid OpenEmu.
Note: I cannot speak for reliability on real hardware setups.

*Refer to the documentation if you do not know whether your rom is headered.

To ensure you have the correct rom base for patching, quickly test it with romhacking.net's Rom Hasher.
If your rom data matches the below (except only maybe a different year than 2021) you should be all set.

Database match: Final Fantasy (USA)
Database: No-Intro: Nintendo Entertainment System (v. 20210216-231042)
File SHA-1: 80CE108FBC066C985D4FB541BD68E9A7C8994FEB
File CRC32: AB12ECE6
ROM SHA-1: C9CFBF5455085E198DCE039298B083CD6FC88BCE
ROM CRC32: CEBD2A31

░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
                                
          Customization Options
          ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯
▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░

The patches below are unlocked from the start.
All patches can easily be reversed.

### Static EXP (Default: ON)
¯¯¯
	All four characters gain experience regardless of status ailments in this mod. Turn
	this off if you prefer the classic setting or if you're doing party challenges.

### Less Spell Text (Default: OFF) ***NOT recommended for new players***
¯¯¯
	Turn this on if you'd like to speed up combat even more by disabling non-essential spell
	messages in battle. Damage and certain status updates still appear.

### Monster Density (Default: OFF)
¯¯¯
	Still not hard enough? This patch increases the size of formations by +3 for small,
	+2 for small-large mixes, and +1 for large. More foes, but greater rewards.

### Spell Flashing (Default: OFF)
¯¯¯
	Toggles the flashing animation that plays while casting spells.
	Makes combat easier on the eyes for those with health concerns or when playing in the dark.


(and if you're looking for the menu colors...
try pressing SELECT on the main menu. ♥)

░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
                                
                 Credits
                 ¯¯¯¯¯¯¯
▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░

Jiggers..........direct system contributions, assembly, insight & development...zheep!

M Bibaud.........creator of SourMesen!

Xyfor............help with cosmetics, motivation and sprites/monsters!

Pommelo..........inspiration, testing, feedback, motivation and apples!

Marf Norrelia....inspiration and help with sprites!

Disch............creating hackster and the disassembly!

Marsh............feedback and inspiration!

AstralEsper......whose expertise got me excited about the idea of modding FF1!

Joe73ffdq........compiling the disassembly companion!

CaptainMuscles...creator of the original dynamic action patch!

Anomie...........all your patches and crazy edits!

Paulygon.........creating hackster plus, and edits to said crazy edits!

Grond............inspiration, especially in interface design & formatting!

Mentil...........inspiration from and development of FF Hasted!

░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
                                
               Mystery Box
               ¯¯¯¯¯¯¯¯¯¯¯
▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░

Since you're still reading I'll assume - it's because you have your eye on that. 

Pay close attention when speaking with others...you should be able to find the key!
