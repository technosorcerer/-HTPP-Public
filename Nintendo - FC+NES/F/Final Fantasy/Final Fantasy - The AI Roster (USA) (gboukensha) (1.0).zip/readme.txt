NES ROM Hack by Emanuele Rodolà
https://github.com/erodola/bigram-nes
2025/08/07

This patch replaces the original Final Fantasy (NES) character naming screen with an AI-powered generator. It automatically creates fantasy-style names and assigns random classes for your party.

Just press B to shuffle, and A to confirm.

Apply the included IPS patch to a clean FF1 ROM (US version) with matching checksums:

ROM CRC32: cebd2a31
ROM SHA1: c9cfbf5455085e198dce039298b083cd6fc88bce
ROM MD5: 24ae5edf8375162f91a6846d3202e3d6

Final Fantasy.nes (GoodNES)
File MD5: d111fc7770e12f67474897aaad834c0c

Final Fantasy (U) [!].nes
File MD5: cd4e3c7b65f3cc45594c5122f2e17fdb

For source code, details, and training scripts:
https://github.com/erodola/bigram-nes