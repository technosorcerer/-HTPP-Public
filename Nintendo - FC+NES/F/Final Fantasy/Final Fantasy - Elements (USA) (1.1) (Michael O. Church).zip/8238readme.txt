﻿Final Fantasy Elements -- version 1.1 (21 Jan 2024)

=== Acknowledgements & History ===

Final Fantasy Elements ("FFE") is a mod (or "hack") of Final Fantasy (NES, 1987). It could not have been built without excellent prior art, so acknowledgements are in order. The original game ("vanilla") was built by Nasir Gebelli under extreme time and resource constraints--in assembly code, within 256KB--and stands as a major accomplishment.

In 2015, Pinkpuff released Final Fantasy Negative One. She fixed a number of  the original version's bugs--all the spells actually work, thanks to her, and so do all the character stats--while removing a number of low-tension encounters and objectives ("fetch quests") and adding four challenging optional dungeons to the late game--they remain in this version, too. She expanded the class system to include 12 options, as opposed to the original six, and improved their balance considerably, thus increasing the game's replay value. 

Four years later, Robert August de Meijer released Final Fantasy Ultra Champion Edition. He increased the difficulty of many fights: enemies have more hit points and are less predictable. To give party creation a feel similar to that of a modern tabletop RPG, he revamped the class system into the form that is preserved here.

Final Fantasy Elements builds on their work, with the following changes:

* Some of the classes have been adjusted. The Ranger's arc has been entirely redesigned, making him more interesting. The Priest's magic defense and ability to run from battles have been increased in order to make him more compelling. None of the 11 main classes--the 12th, the Fool, is deliberately underpowered--is notably stronger or weaker than any other. Instead, they all have advantages and drawbacks.

* Character levels, HP, experience points, gold have all been rescaled, both to increase the game's difficulty, and to give the game a more "tabletop" feel by using lower numbers in general. This game is substantially harder than vanilla.

* The magic system has been adjusted to use the 8-element system (fire, ice, lightning, wind, holy, dark, earth, water) of modern Final Fantasy games.

* New spells have been added such as: SURG (water-elemental attack), RUIN (multi-elemental attack), HEX (multi-status attack), and GLRY (whole-party offensive buff).

* Extant animals have been removed from the enemies list--SHARK has been renamed ISONADE, WOLF has been renamed WARG, etc.

* Dialogue and story have been rewritten entirely. I shan't steal my own thunder, but you should TALK TO EVERYONE. The NPCs will surprise, humor, annoy and insult you. They'll also teach you about the game and tell you where to go.

=== The Classes ===

You should READ THIS SECTION BEFORE YOU START, because (as in vanilla) you are forever stuck with the party you choose at the beginning of the game. The class change quest has been removed; no character's class ever changes.

The game does not prevent you from having two or more party members of the same class, but I advise against it. The classes have been painstakingly balanced; none is so superior that its merits would outweigh the significant costs (reduced strategic diversity, competition for equipment) of doubling up. If you want two Vikings (fighters) consider making one of them a Ranger or Ninja or Monk. If you want two black mages, choose a Warlock and a Wizard, or consider making one a Sage. If you want two bards, please play some other game because this one does not have them.

The 11 main classes are approximately equal in overall value--the Fool is a challenge class that is bad at everything. However, extensive testing has proven that any combination--even four Fools--is capable of beating the game at max level (32).

With that, let's begin.

Viking ("The Destroyer")
HP Growth: B; MP Growth: None
Equips: Axes (A), Plate Armor (A)
Magic: none

The Viking is the most powerful fighter. His HP growth is above average, and he can use the best weapons and armor, but he cannot use shields and his magic defense is terrible. Also, he will never learn any spells. He kills things, and he's good at it. Sometimes, things really are that simple.

Rogue ("The Survivor")
HP Growth: B+; MP Growth: None
Equips: Swords (B), Scale Armor (B)
Magic: none

The Rogue is a decent physical fighter, but she's best known for her ability to escape unwanted battles--some of the random encounters in this game are very hard, so being able to run on the first attempt is an asset. If she leads your party, you will almost never be ambushed. She, like the Viking, never learns magic, but her Magic Defense is excellent, and her HP growth is quite strong. She is invaluable for speedruns, low-level playthroughs, and just plain surviving in this difficult game.

Monk ("The Disciplined Fighter")
HP Growth: A-; MP Growth: C
Equips: None
Magic: all indirect (31 spells)

The Monk is a bare-fisted fighter with excellent HP growth. His hits don't do a lot of damage, but he'll do twice as many of them as anyone else, which can make him quite powerful. He struggles against armored foes, but his magic--buffs, debuffs, effect spells--can turn some of the game's hardest fights to his advantage.

Ninja ("Versatile Offense")
HP Growth: B-; MP Growth: C
Equips: Swords (B), Cloth Armor (C)
Magic: all direct Black (16 spells)

The Ninja is a strong physical fighter, and she has the best Agility (and Evasion) in the game. She can stab and slash her way to victory with her sword... or she can use offensive (Black) magic to freeze, electrocute, or incinerate her adversaries. Her HP growth is mediocre for a fighter, so if she does get hit, she'll bruise... but she's great at dodging physical hits and, if she leads the party, ambushes are unlikely due to her Agility.

Cleric ("The Protector")
HP Growth: C+; MP Growth: B
Equips: Hammers (C), Scale Armor and Shields (B+)
Magic: all indirect and some direct White (24 spells)

The Cleric wields hammers, so she's effective against the undead, and she has decent physical defense. Her healing magic is sufficient to carry a party through the game, but her real strength is in her defensive and support spells. Keep her alive, and she'll render the party nearly invincible--for this reason, she's indispensable in the long, nasty boss fights. She's also charismatic, by which I mean she is almost as good at escaping ("talking down") enemies as the Rogue.

Warlock ("The Cannon")
HP Growth: C; MP Growth: B
Equips: Staves (D), Scale Armor (B)
Magic: all direct and some indirect Black (23 spells)

Back when we were in grade school, the Warlock was out blasting kyzokus and werewolves to hell. So long as he never runs out of magic, he's a one-man demolition crew--his multitarget damage spells can win fights instantly--but once he's used his magic up, he's an old man with a stick. Conserve his power, avoiding the temptation to blow everything to bits, and he's a powerful ally.

Sage ("The Consummate Mage")
HP Growth: D; MP Growth: A
Equips: Staves (D), Cloth Armor (C)
Magic: all (64 spells)

The Sage is, by far, the best magic user. She learns the most powerful spells faster than anyone else, and her superior Intelligence stat (which, in this version of the game, actually works) means her spells land hard. She's the weakest physical fighter of the 11 main classes, and her HP growth is terrible, but if you can keep her alive, she will use her magic to heal, buff, destroy, debuff, revive, and escape. (Unfortunately, game limitations still limit her, as they do for all PCs, to three spells per level per playthrough, so choose wisely.) Finally, the most powerful offensive spell in the game, SAGE, is available only to her. 

Fool ("Just Say No")
HP Growth: F; MP Growth: None
Equips: Staves (D), Cloth Armor (C)
Magic: none

The Fool doesn't belong on adventures. He exists mainly for challenge runs, and to make the other characters look good. The less said about him, the better.

Paladin ("The Tank")
HP Growth: A, MP Growth: C
Equips: Hammers (C), Plate Mail and Shields (A+)
Magic: all direct White (16 spells)

The Paladin is the ultimate defender. He has more HP than anyone else, and he can equip plate mail and shields, so enemy attacks will often hardly faze him. His Strength is high, but he refuses to use bladed weapons, making do with a hammer, so his offense is mediocre. However, he's the easiest character to keep alive, which is good for him, and he has healing magic, which is good for everyone else.

Ranger ("The Generalist")
HP Growth: C-, MP Growth: C
Equips: Any Weapon (A), Scale Mail and Shields (B+)
Magic: Some (Lv 1-6) specialized and all non-specialized (47 spells)

The Ranger is the most versatile character. She can equip almost every weapon in the game, and she has offensive magic as well as healing. Her stats--including HP and MP growth--are below average, but her versatility makes up for it, if you know how to use her. When it comes to weapons, she can equip hammers to trounce undead, swords for added accuracy (and hit count), or axes for raw power.

Wizard ("The Grandmaster")
HP Growth: C, MP Growth: B
Equips: Swords (B), Cloth Armor (C)
Magic: all direct and some indirect Black (23 spells)

The Wizard is an offensive mage who thinks ahead: his buffs and debuffs can turn battles to your favor. Although he lacks the multitarget damage spells of the Warlock, he can poison and stun enemies into submission. The Wizard excels in the long, difficult fights... but he's not bad in the short ones either because, unlike the other magic users, he's quite capable with a sword.

Priest ("The Blessed")
HP Growth: B, MP Growth: B
Equips: Staves (D), Cloth Armor (C)
Magic: all direct and some indirect White (24 spells)

The Priest is the most effective healer, second only to the Sage in terms of spell selection and MP; but unlike the Sage, he has reasonable HP as well as the best Magic Defense in the game, so he'll survive enemy attacks and status debuffs that cripple everyone else. He's also good at escaping encounters.

=== Party Recommendations ===

Any party can complete the game. Below are just a few possibilities that might appear to various types of players:

The Classic: Viking, Ranger, Priest, Warlock

This party has the feel of a traditional RPG group: the pure fighter, the jack-of-all-trades, the healer, and the offensive mage. This party is straightforward to use and, especially for a first playthrough, not a bad choice at all. Game breaking? Probably not. Straightforward? Yes.

The Wrecking Crew: Rogue, Viking, Ninja, Wizard

This party delivers beatdowns with admirable efficiency. The Viking's axe tears through armored enemies, the Ninja blasts mobs, and the Wizard fights hard in short battles and buffs fighters for long ones. You'll want to invest in healing potions, but for raw offensive power ("DPS") this group is hard to beat. 

The Roundhouse: Paladin, Monk, Ranger, Ninja

All four of these characters have access to magic, and all four are decent fighters. This party doesn't specialize, but it can do almost anything. The Paladin heals and takes hits, the Ninja adds versatile offense, the Monk's buffs and debuffs find use in boss battles, and the Ranger does a bit of everything . This party is expensive to equip, and its magic defense is less than stellar, but it is effective.

Four Mages: Cleric, Wizard, Priest, Warlock

This one's challenging, but fun as hell, with access to every kind of magic. It's quite squishy, but it has two healers and lots of tricks. When this party's good, it's really good. If you play this party, you'll learn a lot about the game.

Expert Mode: Rogue, Monk, Sage, Warlock

This multistrategy party is designed for the second and subsequent playthroughs. If you know when to run, when to fight, and _how_ to fight through various challenges, this party can be obscenely powerful--broken, in fact--but it is not as straightforward to use as the others.

Run & Heal: Paladin, Rogue, Cleric, Sage

This is an excellent defensive party. The Rogue is the best runner, the Paladin is an absolute tank, and you have 2 or 3 healers, depending on how you spec the Sage. If you can keep the Cleric alive, you can make yourself nearly invincible in long battles. This party's designed for completing the game at low levels--I've beaten the game at 15 using it. 

Take a Spin: ???, ???, ???, ???

Back in my day, we used raw-dog 3d6 to roll our attribute scores, and we liked it that way! If you'd like to experience the thrill of rolling dice and playing what fate gives you, then roll a 12-sided die four times, rerolling duplicates and 12s. 1 = Viking. 2 = Rogue. 3 = Monk. 4 = Paladin. 5 = Ninja. 6 = Ranger. 7 = Priest. 8 = Cleric. 9 = Warlock. 10 = Wizard. 11 = Sage. There are 330 possibilities, and any of them will be able to complete the game at level 20 (low/minimal grinding).

=== Equipment ===

Most classes only have one type of weapon available--the Ranger is an exception--and no class has more than one armor type available, though some can also carry shields for additional defense. Thus, you'll know in advance what your party can equip. Hammers have enhanced effectiveness against most undead, swords provide a bonus to accuracy, and axes are most powerful overall.

The rings and the Heal Staff cannot be equipped, but cast spells when USEd in battle--for example, the GarntRng casts BIND and the RubyRing casts TMPR and the Heal Staff, well, heals. 

=== Magic ===

As in vanilla, there are 8 levels of spell, and eight spells at each level. In FFE, unlike in vanilla, all 8 levels are available to all magic users. The spells are categorized as:

* either (W)hite or (B)lack; white magic is defensive or curative, while black magic is offensive.
* either (D)irect (e.g., healing, damage) or (I)ndirect (e.g., buffs, debuffs, escape).
* specialized (+) and, thus, available to fewer classes, or not.

The Ranger can cast all spells in the first 6 levels and all non-specialized spells in Lv 7-8.

Thus, the "tag" following each spell indicates which classes can learn it:
WD = Priest, Cleric, Paladin, Ranger, Sage
WD+ = Priest, Paladin, Sage, Ranger (Lv 1-6)
WI = Priest, Cleric, Monk, Ranger, Sage
WI+ = Cleric, Monk, Sage, Ranger (Lv 1-6)
BD = Warlock, Wizard, Ninja, Ranger, Sage
BD+ = Warlock, Ninja, Sage, Ranger (Lv 1-6)
BI = Warlock, Wizard, Monk, Ranger, Sage
BI+ = Wizard, Monk, Sage, Ranger (Lv 1-6)

Damage levels will vary; characters with high Intelligence stats (such as the Sage) will tend to exceed the numbers listed here.

Level 1:

CURE (WD, single ally): a simple healing spell that improves the health of the target (~50 HP); as are all healing spells, it is about 20% more effective when used in battle. 
HOLY (WD+, all enemies): directs a blast of holy energy at all undead, doing about 80 damage to each. Has no effect on non-undead enemies.
WAKE (WI, all allies): all allies are roused from sleep. Also cures paralysis ("Stun" status).
INVS (WI+, all allies): the party becomes difficult to see; enemies' physical attacks will miss more often.

FIRE (BD, single enemy): launches a small fireball at a single enemy, doing about 80 damage. More effective against undead and ice monsters.
BOLT (BD+, all enemies): small bolts of lightning strike all enemies, doing about 40 damage to each, but more to aquatic adversaries. Quite useful on the open sea.
SLEP (BI, all enemies): affected enemies fall asleep for at least one turn.
BIND (BI+, all enemies): evasive enemies become much easier to hit.

Level 2:

PURG (WD, one/all allies): cures the "Poison" status. In battle, it affects all allies instead of one.
HEAL (WD+, all allies): Like CURE, but heals all party members (about 50 HP).
SLOW (WI, all enemies): an enemy's offensive movements are slowed; counteracts Haste status, or reduce hit count to one.
SHLD (WI+, all allies): surround each army with a protective shield, reducing the damage done by physical attacks.

AERO (BD, single enemy): directs a shock wave at one enemy, causing about 120 points of wind damage.
ICE (BD+, all enemies): blasts one's enemies with frigid air. Does about 60 damage to each, but more to fire-elemental or desert monsters.
POIS (BI, all enemies): when it hits, inflicts the "Poison" status, which causes an enemy to lose 10% of its HP after each round of combat. 
BLND (BI+, all enemies): inflicts the "Darkness" status on enemies, making them easier to hit as well as less effective at hitting you.

Level 3:

CUR2 (WD, single ally): a healing spell of moderate strength. Restores about 100 HP (~120 in battle).
HLY2 (WD+, all enemies): undead adversaries suffer about 180 HP of damage each. Has no effect on non-undead.
MUTE (WI, all enemies): may inflict the "Silence" status, which makes spell-casting enemies unable to use magic.
WILL (WI+, all allies): fortifies allies against status-altering magic, as well as holy-, wind-, and dark-elemental attacks.

FIR2 (BD, single enemy): a single monster erupts in flames, suffering about 180 HP of damage.
BLT2 (BD+, all enemies): directs lightning at all enemies, causing each to suffer about 90 damage (in water, about 140).
CHRM (BI, all enemies): enemies may become confused and attack each other. 
TMPR (BI+, one ally): increases the offensive output of one ally. Despite the name and icon, works on bare-fisted fighters too.

Level 4:

CLNS (WD, one/all allies): cures all status effects except petrification. In battle, it affects all allies instead of one.
HEL2 (WD+, all allies): Like CUR2 (~100 HP) but heals all party members.
LIFE (WI, one ally/one enemy): outside of battle, revives a KO'd ally (but with only 1 HP). In battle, inflicts massive damage on a single undead.
SLD2 (WI+, all allies): surrounds your party by a force field that significantly reduces the potency of physical attacks.

COMT (BD, single enemy): a comet strikes the enemy, doing about 240 HP of dark-elemental damage.
ICE2 (BD+, all enemies): a deep frost surrounds the enemies, doing about 120 points of damage to each (but more against fire or desert monsters).
BIO (BI, all enemies): emits a poisonous gas that inflicts Poison and Sleep status.
HSTE (BI+, one ally): target ally gains the "Haste" status, making twice as many hits with physical attacks. (Note: HSTE and SLOW cancel each other out.)

Level 5:

CUR3 (WD, single ally): arcane magic that causes rapid bodily regeneration; an ally recovers about 200 HP.
HLY3 (WD+, all enemies): pale molten fire falls from the sky on all undead; they suffer about 300 damage.
SOFT (WI, one ally/enemy): outside of battle, reverses petrification status. In battle, may inflict it (causing instant death).
SHEL (WI+, all allies): entire party surrounded by a reddish light; damage from fire, ice, and lightning attacks is reduced substantially.

FIR3 (BD, single enemy): a rain of magma falls upon a single enemy, causing about 300 damage.
BLT3 (BD+, all enemies): electrocute all enemies at once, inflicting about 180 HP of damage.
WARP (BI, party/single enemy): outside of battle, use it to "warp" (hence, the name) back one level in a dungeon. In battle, causes one enemy to teleport (no XP or GP are gained).
STOP (BI+, all enemies): affected enemies freeze in place ("Stun" status). 

Level 6:

CHKR (WD, caster only): in battle, causes spellcaster to fight more vigorously. Out of battle, revives a KO'd ally (like LIFE) with full HP.
HEL3 (WD+, all allies): like CUR3 (~200 HP) but heals all party members.
EXIT (WI, party/all enemies): outside of battle, use this spell to return to the overworld. In battle, causes all enemies to teleport (no XP/GP gained).
IVS2 (WI+, all allies): party members become fully invisible, thus much harder to hit. Stronger than INVS.

SURG (BD, single enemy): torrential jets of water blast a single enemy, doing about 400 damage.
ICE3 (BD+, all enemies): the temperature drops to absolute zero. Enemies take about 230 HP of damage, and cold-intolerant monsters suffer more.
DETH (BI, single enemy): target enemy may instantly die. Will not always hit.
GLXY (BI+, all enemies): blast all enemies with radiation from deep space, causing them to suffer silence, sleep, or paralysis.

Level 7:

CUR4 (WD, single ally): a miraculous healing spell that recovers target to full health and cures all status effects (except petrification and death).
HLY4 (WD+, all enemies): the undead boil and dissolve; each suffers about 500 points of damage.
HEX (WI, all enemies): nature itself rebels against the adversary; this spell can cause paralysis, silence, blindness, and poison status. 
WALL (WI+, all allies): each party member acquires a protective aura that blocks enemy magic of all elements.

DARK (BD, single enemy): a bolt of pure corruption strikes a single enemy, causing massive (about 500 HP) damage.
QAKE (BD+, all enemies): an earthquake does about 300 damage to all enemies, but substantially more to large monsters. Ineffective vs. flying enemies.
XZON (BI, all enemies): multitarget instant death spell.
TPR2 (BI+, one ally): massively increases the offensive capability of one ally. Indispensable against armored enemies.

Level 8:

PERL (WD, all enemies): a blast of pure light destroys all evil. Does about 350 holy damage to all enemies, but substantially more (550-600+) to undead.
HEL4 (WD+, all allies): every living ally is fully healed and cured of all status ailments.
GLRY (WI, all allies): increases the fighting ability of all party members.
SLD3 (WI+, all allies): each party member gains a level of physical protection comparable to the finest armor.

FLAR (WD, one enemy): direct a raging solar flare at the enemy, doing about 600 non-elemental damage to a single target.
RUIN (WD+, all enemies): a multi-elemental attack--meteors fall from the sky, tornados break out, lightning strikes everywhere--that does over 400 HP of damage to all enemies, but 600+ to those weak to water, darkness, or lightning.
HST2 (WI+, all allies): gives ALL allies the "Haste" status, doubling their damage output.
SAGE (Sage only, all enemies): the most powerful battle spell, by far--it does about 700 damage to each enemy.

Note: Sages should never waste a slot on FLAR, RUIN, or PERL; the SAGE spell is strictly more powerful, even against enemies weak to those elements. 

=== Some Spoiler-Free Advice ===

* The Walkthrough (next section) is not necessary to complete the game, and that's where the spoilers begin, so don't read beyond it if you want to avoid them.

* Magic is more powerful than in vanilla. All the spells actually work. You can beat the game without using magic, but it's tough. Don't discount buffs, debuffs, and status effects.

* Talk to people in towns. They will give you tips about how to play the game. They want you to win; the monsters in this game don't. On the off chance that I've lied to you, they might tell you things you wouldn't otherwise know.

* Your leader will take 50% of the physical hits, so make sure it's someone strong. A leader with high Luck and Agility will often get first attack against enemies, and almost never be ambushed.

* You make money quicker by exploring dungeons--and selling unneeded equipment--than you do by fighting enemies. Don't feel like you need to be able to complete a dungeon in one trip--they're designed to take two or three. 

* Most dungeons have exit portals. However, they are sometimes guarded by forced encounters ("spike tiles"), so be prepared for a fight.

* Although running is harder than in vanilla, you can escape most enemies. Some random encounters are so difficult, running may be the only option. However, you can never run from bosses or dragons.

* For example, you can--and should, unless you know what you're doing--run from WarMECH in the Floating Fortress; he is almost unbeatable when you first encounter him. Same for PINKPUFF in the Time Cleft. These enemies are extremely tough, but they're not hard to run from.

* There are eight elements (fire, ice, lightning, water, darkness, holy, wind, earth). A damage spell is 50% more effective against an enemy that is weak to that element, but is 75% less effective if the enemy is immune. 

* There are nine enemy classes; some belong to more than one. They are: Ordinary (no class), Ancient, Dragon, Aquatic, Human, Undead, Giant, Magic-User, and Regenerative. Certain weapons and spells do excess damage to specific enemy types.

* There are also specific places where you can find specific enemy types. There is an island in the northeast where Giants are easily found; to the far northwest of Onrac, Dragons are often encountered. There is an island where pirates (Humans) tend to go. 

* For enemies to score critical hits is a lot more common in this version than it is in vanilla. For example, enemies of the Human type score critical hits at least 5 times as often as ordinary ones, so killing Humans first is, as always, a good idea.

* You won't have to grind much in this game if you know what you're doing, but the harder dungeons are likely to take multiple trips if you explore fully.

* If you're trying to beat the game at as low a level as you have patience for, then sand hags (SandHAG) and gold golems (Gold G) are your friend, because they give 0 XP. (You'll still get 1 XP per battle, because of the way the game engine works.) Use WARP to make vanish enemies that do give XP--the game will treat them as having run away, so you will not gain any.

* Alas, each magic user can only learn 3 spells in each of the eight levels. (This is a hard-coded limitation of the game.) If you have a Ranger, Monk, or Sage, consider leaving a slot open until you figure out what you want to buy.

* Gil (gold) and XP are scaled much lower in this game, so don't be discouraged by the smaller numbers. You'll get a lot less gold at every point in the game, but things also cost about 5x less, so it works out. All the big dungeons have at least one chest with a substantial payload.

* The XP curve is designed to be flatter than in the original game--equipment matters more, and your level matters less. This means the endgame is still reasonably challenging if you're over the design level of 20, and remains beatable if you're a few levels below.

* There's some extremely expensive equipment available at the very end of the game that you don't need to buy. There are certain routes and strategies that use it, but is it worth grinding for? In general, probably not.

* Inns and clinics are very cheap, but you start with... 0 Gold. Nothing. No weapons, no armor. This is to give you a sense of what this game is like. You can fight enemies barefisted, or you can go into town and talk to people...

=== Walkthrough ===

(Spoilers begin here.)

... such as the NPC in Coneria who makes fun of you for "looking poor" and tells you to go to the castle for a "handout." She's not just there to annoy or insult you (that's an added bonus) or gloat about the game's difficulty. She's actually helping you out--she's telling you where to go. In the original game, the castle had two rooms with locked doors. One of those still is locked, but the other one can be opened now. You'll get a Cure potion, 25 gil, and a Wooden Sword.

Buy weapons first. You don't need armor to fight IMPs. Buy CURE and FIRE (for CREEPs) if you have magic users. Tents are cheap in this game, but potions are expensive, so use them sparingly. Once you're at level 2, you can explore the Temple of Fiends, where you'll find another 50 G, a Bronze Shield (if you can't equip it, sell it) and some potions.

The people of the castle want you to save Garland, who has ill-advisedly kidnapped a princess much stronger than him in preparation for a boxing match she will surely win. Unfortunately, you arrive to find that Garland has gone a bit... batty. The knight arrogant is beatable at level 2, but 3's more typical, and you'll get there pretty quickly. His GALE attack hurts. He's of the Human type, so he crits a lot. Don't be surprised if he kills one of your party members before you bump him off. 

Once you've beaten him, talk to the princess. She'll teleport you back to Castle Coneria. Talk to the queen; she will build you a bridge. She had a bunch of money lying around, but never bothered to tell you. It would have been useful! Cross it and go to Pravoka. Unlike in the original game, you don't find Bikke (or his ship) in the port town. To get to him, you'll have to go into the Seaside Cave, a dungeon to the south that doesn't exist in vanilla.

Another difference from the original game is that the pirate encounter is a real fight (design level 5) because KYZOKUs have 100 HP and are immune to fire and ice; it'll take three turns to clear them away with AOE magic. Bikke is a RAIDER with 550 HP and his blows really hurt at this stage of the game. POIS is a great spell for this fight; it whittles down the enemies' HP over time, 10% each turn. You shouldn't start this fight until you have a party where any three can finish the job, because a Bikke/RAIDER crit will do over 100 damage, which is almost certainly lethal at this point in the game.

Once you have the ship, you can go to Elfheim. You can buy powerful magic here, but you probably won't be able to afford much. Your top priority should probably be BLT2, as it's very useful on the ocean. An astute player will realize that you could have _walked_ to Elfheim and bought BLT2, which would have been useful in the pirate fight. Whoops.

The Marsh Cave is, like its counterpart in the original game, difficult, but it's less annoying in this version. You'll drop through a hole into the center of the upper floor (there are only two.) If you want to get out, you'll have to make your way back up to the northern stairs. Unlike in the original game, there are no locked doors here, so you won't have to revisit this place ever once you're done with it. 

From the entrance, go south to get the chest, then head back and go east for the staircase to the lower level, which is exactly the same layout as in the original game, but with all the rooms open. The boss fight is the familiar gaggle of piscodemons (PISCO/"WIZARD"). They're immune to most elements, although they can be poisoned--not that you'll want to wait 10 turns while getting hit by them, but it may help. If you have HSTE and TMPR, they can be used to boost your fighters. If your strategy for beating the piscodemons requires magic, make sure you have Clns potions, because their physical hits inflict the Silence status. Defeat them and get the TNT, which you'll need if you want to see the rest of the world (so you can save it, if that's a thing you care about.)

At this point, you can open up the mediterranean sea you're in--if you take the TNT into the Dwarf Cave, there's a nice old man who'll blow a chunk of land into space, ecological consequences be damned. Or, you can do an optional quest, which is to go to the Northwest Castle and take out Astos, a stoner dark elf who stole weed from the Prince's stash.

He's not actually that hard. He has 1650 HP and strong spells for this phase of the game, but he can be MUTEd. It may take a few attempts for the spell to land, but it's worth doing, because if he's mute he'll end up wasting 62.5% of his turns, giving you time to whittle him down rather than eating a bunch of spells, some of which can easily kill you. In the chest behind him is the HERB: you can give that to the prince of Elfheim, and get the Mystic KEY, which you can use... to raid some locked rooms and make money.

There are not as many locked treasure rooms as in vanilla--only three. One is in Elfheim Castle, one is in the Dwarf Cave, and one is in Castle Coneria. You can get some decent loot before you go on to Earth Cave, and you probably want to do so, because the stuff in Melmond is expensive.

One not-so-secret of the Rogue, preserved from earlier versions of this game, is that he can "steal" late-game items and pull off some powerful sequence breaks. This is the point at which those items are available.  

Earth Cave is, as in the original game, long and painful. It'll probably take you two or three visits to clear it out. You can find the first of the eight magical rings--the Garnet Ring, which casts BIND when used in battle--on the 4th floor. At the bottom, you'll find the first of the four fields: Lich.

For an aside, though, the most dangerous enemy here is probably not the Lich but the cockatrices (COCTRICEs). They're hard to hit and they can petrify you. At this stage of the game, there is a good chance of that status landing, and a stoned party member is as good as dead for the rest of the battle--you lose the game if your only living party members are statues. Either run, or blast those awful birds with BLT3.

The Lich has 3500 HP, but he is undead, so HOLY spells work and LIFE can hit him for about 400 HP. His physical hits are rough, and his magic is absolutely vicious for this stage of the game. SLOW might land on him, because it's holy-elemental and he's weak to it; MUTE almost certainly won't. Use SHEL if you've got it, and don't let him live long enough to use QAKE, which at this stage of the game is likely to be a T.P.K.

One fiend down? Good. Now you can fight the other three. The canonical sequence, and the order of increasing difficulty, is: Kary (fire), Kraken (water), Tiamat (air). Some strategies use different permutations, but I'll cover the most common sequence.

Kary, as in vanilla, lives in Gurgu Volcano. To reach her, you'll either need the canoe or the airship. (You'll probably want to get both eventually.) The former is available in Crescent Lake from an NPC who bought it in a midlife crisis but realized the local rivers were full of poisonous monsters and is now selling it for zero, which is embarrassing for him, but good for you, because this game is hard and you need to be cheap to survive.

BLT3 is invaluable on the river. Take two HOUSEs for each trip to Gurgu: one to use before entering the dungeon, and one to replenish your magic after leaving it. Trust me on this.

The volcano's full of CURE potions. You'll need them. The lava floors were a minor annoyance in vanilla, but with this game's reduced HP, they're brutal. The monsters aren't very nice either. Heal up early and often. If you have ICE3, save your charges of that spell for the Red D's, which you can't run from. You'll meet at least three of them if you go for all the chests, and they're quite nasty at this stage of the game; worse is that they often come with two FIRE elementals, who are bad enough on their own.

It's common for this dungeon to require multiple trips. If you don't have a TMPR-caster, be sure to get the RubyRing on the lowest floor. In a low- or no-spell run, it's one of the most useful rings.

Kary, unlike most bosses, is weak to wind damage, and since status effects are wind-elemental, you have a nonzero chance of hitting her with one. However, her Magic Defense is very high, so this will take a long time. BIND will reduce her evasion, if you’re having a hard time hitting her. You should also use SLOW if you've got it: her physical attacks hit 4 times, so she can one-shot you. SHEL will blunt the damage from her FIR2 and FIR3 attacks, but if she gets around to FLAR, there's nothing you can do: you'll have to finish the fight down a player.

It's canonical to go for the airship after defeating the first two fiends. In this version of the game, the airship is technically optional, because there are ports in the north, but you'll probably want the speed of air travel--the game was, thankfully, made before 2001. As in vanilla, you need to get the (hilariously ill-named) FLOATER, then use it in the desert (Ryukahn Desert) south of Crescent Lake. What's different is the location of the helium rock: you won't find it in the Ice Cave and, indeed, you can't get to the Ice Cave until you've found the airship. Instead, you'll find the FLOATER in the Ryukahn Ruins--a dungeon that doesn't exist in vanilla--just north of that desert. If you don't have the spell SOFT, bring a SOFT potion or few in case you get stoned.

Red Dragons can spawn in the desert ruins, so save ICE3 for them. If you're trying to keep your levels low, you can kill SandHAGs for XP-free Gil (if you WARP/EXIT the rogues away). There are also two chests in this dungeon with decent money for this stage of the game. The FLOATER, up north, is gated by not one but two difficult fights. The first one, with the EYE, is not runnable. He has stonetouch and casts DETH and STOP; casting WILL shores you up against the spells, but your best strategy for stonetouch is... hope not to get hit. (You will.) SHEL, at least, neuters his FIR2. The second fight, with Green H(ydras) and NAOCHOs, actually is runnable--it feels like it shouldn't be, which is why it is--although you may want to take this fight because it gives fantastic XP for this stage of the game. Once you've got the FLOATER, exit the dungeon and use it in the desert to get the airship and now, as Tony Montana once said, the world is yours.

Onrac's water dungeon is still gated by OXYALE, but the desert caravan of vanilla doesn't exist. FFE makes you fight for it, but  it's in the same place: the oasis west of Onrac. Bring SOFT (the spell, or a couple potions) and consider having any black magic users learn ICE3 and QAKE for any black users. 

The Mithril Sword is gated by an unrunnable fight with a BASILISK. He has stonetouch and he hits hard. So, you'll be tempted to kill him off first and ignore those IMPs. That would be a mistake. You may have noticed that those "imps" are slightly harder to kill than the ones at the beginning of the game--they are, in fact, a different monster from the early-game mooks. They pack a hilarious brick joke that I'd rather not spoil except to say that it can Teabag-P.K. you if you get unlucky. Once the perineal sorcery stops being hilarious, make BLT3-ing them the first thing you do. 

The oasis dungeon is short and, when you get to the end of it, you'll find the treasure chest that ought to have OXYALE... empty. Search the lake nearby. You'll find it. Then get out of there. 

The water dungeon, with only three floors instead of five, isn't as massive or confusing as the one in the original game. Still, it can be annoying and difficult. The first (top) floor is exactly like the original in layout; the second requires you to wander about (you can walk on the water) quite a bit; the third is where you get the SaphRing (CLNS) and can talk to a mermaid, and fight your way through GHOST mobs and their ridiculous crit rates. At the northern end of the bottom floor's massive chamber is the third fiend, KRAKEN, Ultros's uncle, who is even more of pain in the ass. Even if SLOW sticks to him, a single critical hit can kill you, so use defensive spells like SHLD and INV2 if you have them. SHEL will help you survive EXAVOLT, which can blast you for 700 if you raw-dog it. If you don't have magic? Then just kill him as fast as possible. He has 6500 HP.

Once you've nailed KRAKEN to Davy Jones's skybox, there's only one fiend left: TIAMAT. She lives in the Mirage Tower; you won't be able to get into it without the CHIME, which you get from the people of Lefein... but only if you know their language, and since you don't have time (the fate of the world being at stake and all) to learn it by immersion, you've got to get the PAPYRUS for Dr. Unne in Melmond. Where's the PAPYRUS? The Library of Ancients, a mini-dungeon sitting on an island between the two main continents of the north. Be prepared, with magic or potions, to CLNS yourself often... the place is full of undeads who inflict status effects. Garland also hangs out here because even in the afterlife he gets off on getting smacked around and humiliated, but he's not a real threat at this point. From the entry point, go north, west, or east for treasure; go directly south if you just want the boss fight: 3 VAMPIRES.

This can be a tough fight. One of these would be bad enough, but you have to face three. They have 3375 HP each, and their physical attacks can inflict sleep, darkness, and silence. Also, they have very high critical hit rates and they heal themselves. Their Magic Defense is quite high and their special attacks include TAINT and CRACK (thank you, thank you, I'm here all night). If they HST2 themselves, SLOW them back down immediately or they will kill you quick. Luckily, they are undead, and SLOW being holy-elemental, there is a good chance that it sticks to them while you HLY4 and PERL them to shreds.

The Mirage Tower is the first dungeon where you'll find equipment better than anything you can buy in towns. The Rune Tunic guards its wearer against lightning and instant death spells. The Bah(a)mut Sword is strong against dragons, such as the one at the top of this tower. This dungeon has loot worth almost 40,000 Gil, although most of it you won't want to sell, so don't feel bad about taking your time.

You can't run from Blue D--and you'll have to fight at least one, on the third floor before you can enter the Floating Fortress. He uses lightning attacks, so SHEL will guard you against his worst. His physical attacks are brutal and he can be SLOW'd, but if you have a strong party, you might do better to focus on offense.

MagiTEKs are formidable at this stage of the game, but they can be SLOW'd. SHEL or WALL will protect you from their various beam attacks. There's nothing you can do, however, about non-elemental GAMMARAY. The counterstrategy is: kill them before they get around to it. The TopazRng on the 5th floor casts BLT2, so it's not a bad idea to pick it up.

You *can* run from WarMECH, who you might never meet because he's only found on the 8th floor, the long corridor before the end. At this dungeon's typical level (15-16) you should. He regenerates 997 HP every round of combat and he's immune to Holy (including SLOW). If you want to fight these, you'll find them again in the Temple of Fiends (Air floor) and be better equipped to handle them. If you're up for a challenge, though, give it a go.

At the top of the tower, you'll meet TIAMAT. She has 8000 HP and high defense, so expect a long fight. She also has high Magic Defense, but you might want to try SLOWing her anyway--it might take three or four tries--because of her brutal physical attacks. She's immune to lightning (BLT3, RUIN), water (SURG), and earth (QAKE) damage, so don't bother with those. FLAR works, if you've got it. So will DARK, ICE3, and FIR3.

And... once you've defeated her... you have restored the power of the Orbs! You can enter the Temple of Fiends, predux. Yes, even though the place is literally called "The Temple of Fiends" and has been the center of evil for millennia, it has been allowed to stand there, perilously close to human civilization, for two thousand years. Why? Don't ask me.

You might want to take a few detours, though. The design level of the final dungeon is 19-22, and you're probably below that. There are five dungeons you can explore before you go in.

The easiest of the bonus dungeons is the Abyss, accessible only by ship. Sail to the horn-shaped peninsula in the northwest and enter the whirlpool. To the northwest of the entrance, you can find Sting, the Rogue's best sword, as well as a DiamdRng, which casts INVS when used in battle. (You could have come here, to "steal" a weapon for the Rogue, much earlier.) Head southeast and you'll find the Aegis Shield, the best shield in the game. Grope about a bit more--pay attention to the wells, so you don't get lost in the blackness--and you'll find your way to DEATH's room. He's a souped-up lich; kill him before he can cast FLAR or XZON. Once you defeat him, you'll get the best weapons in the game for the Ninja and the Warlock. 

The Ice Cave is in a similar place to its vanilla counterpart, but in this version it's only accessible by airship, because it's an endgame dungeon. Remember the sage in Coneria who said that wood, when fossilized in ice for millions of years, gains certain powers? Keep that in mind. You might not want to sell or discard the "Wooden Staff" you find there. There's also lots of gold to be found, as well as best-in-game scale armor (Dragon Mail) with some useful elemental resistances and the Am(e)thyst R(ing) that casts SLOW. The boss here is HYUDRA, an ice dragon. After you beat her, you'll get the Wizard's and Paladin's best weapons.

Next is the Time Cleft. There's a tower visible on the overworld map, northeast of the Ryukahn Desert. You'll find strong enemies on the way to it, and then find yourself in a desert ruin full of portals, most of which return you to the overworld. You'll also meet some T REXes. They're good people, tyrannosaurs. They don't like intruders, though, so they might inflict a few hundred HP of misunderstanding on you, which you probably don't want. If you'd prefer to skip the trial-and-error of testing each portal in the desert, just go southwest from your spawn point and use the one near the ?-shaped cluster of blocks.

It's not actually a tower. In fact, it only has one floor. Kill or run from the SAGEs before they kill you. Don't waste your time trying to MUTE them; it won't work. The SENTRY robots have GAMMARAY, which hurts a lot. You can find the Ranger's best weapon, the Tonberry Knife, and the EmrldRing, which casts WILL in battle, in case you don't have the spell. That's somewhat of a hint: OGOPOGO has instant death attacks, so use it (or the WILL spell) before XZON can land. After taking him out, you'll get the best weapons for the Sage and Viking.

The last of the major bonus dungeons is the Seraph's Castle, standing where the Castle of Ordeals was in the original game. The enemies here are tough, but susceptible to dark-elemental damage (DARK, RUIN) and, more often than you'd expect, instant-death attacks (DETH, XZON) work. However, they won't work on SERAPH, the boss of this dungeon. The OpalRing casts HLY3 when used in battle. 

SERAPH is one of the hardest bosses in the game. She has 8888 HP and she's immune to status effects. Her physical attacks hurt, but most of her first magical attacks will be buffs, giving you a couple of easy turns before the nightmare begins. Use all the buffs you can, but try to kill her before she makes you code in PERL. After you beat her, you'll find the Cleric's and Priest's best weapons.

Finally, there's a "bonus bonus" dungeon, the Forbidden Castle, which sits on an island south of Melmond. The Lunar equipment can be useful, but you probably don't need it. The weapons are slightly weaker than the character-specific ones you've already gathered, but can be useful if you have class duplication. This is mostly a money pot; you can find lots of Gil, and you can fight some very tough monsters here. But you don't have to go here, and you don't miss out on much if you skip this one.

After clearing out the optional dungeons, you should be around level 20. You're now ready to enter the Temple of Fiends, Revisited.

You start on the ground floor and must find your way to the upper floor, which is full of dangerous enemies (IFNYR, Gold G, Green D). You'll probably be running from a good fraction of these fights, but you can't run from dragons. There are also five treasure chests, but they play a bit of a prank on you--the first one (it doesn't matter which order you use) gives you 10000 Gil, but the other four are empty. When you return to the ground floor, you will go west to find a staircase. Before you go down, you'll fight a Green D(ragon). His weapons of choice are non-elemental poisons, to which you have no resistance. He can also MUTE you, so bring CLNS potions. He has 5000 hit points. He's a pain, but beating him is worth a lot of XP, so if you need to grind, there are worse places to do it than the "spike" tile where you are guaranteed to meet him.

After the forced green dragon fight, you'll descend through floors themed in the four elements and, as in the original game, you'll have to fight each of the four fiends along the way, each with more HP, fewer elemental weaknesses, and stronger attacks than they had in the first fight. In version 1.1, I removed their HP regeneration (but increased their defense, to compensate) so you don't have to worry about that; all damage makes progress.

Each of the elemental floors has a portal to a secret village. You can buy potions and magic (level 8, if you didn't get it from Gaia and Lefein) there, at their normal prices, and find (very expensive) inns at the midpoint and near the end of the dungeon. One warning: although staying at these inns will save your XP gains, you will spawn (less the room rate) outside the temple if you die or reset.

The Lunar weapons are available on the fire floor; the Lunar armor, on the water one. This stuff is all expensive and, stats-wise, it's slightly inferior to the class-specific equipment you've already found if you've completed the bonus dungeons, but valuable if you ignored my advice and doubled up a class or made the mistake of selling a rare weapon.

On the air-themed floor, there is a prank staircase that leads you to think you can get away with skipping Tiamat, but it just sends you back to where you entered the floor. There are also some great encounters here if you need to grind: you can 2048 XP for the 4-MagiTEK fight, 1750 XP for each Iron G(olem), and 4096 XP for scrapping a WarMECH. Gold G(olem) can also be found here, but you'll probably want to run from those unless you're level 24+, since you probably don't need money now. 

On the bottom floor, you'll find Garland, who turns himself into the more powerful CHAOS, the game's final boss. It's good that he didn't have that ability in the recent-past/distant-future because he would have beaten you up back then (front then?) Anyway, the final boss is A LOT harder than in vanilla. Any party (sans Fools) can defeat him at level 20, but you'll have to have learned how to actually play this game in order to have a good chance against him, even at 22-24, which is where you'll probably be on a first playthrough.

=== Final Boss Strats (EXTREME SPOILER TERRITORY) ===

CHAOS is hard. His buffs and debuffs are nasty, he's got strong magic defense and no elemental weaknesses, and he has a ridiculous 32,767 HP. He's Human, so his crit rate is also high. He's about as hard as I was able to make him, within the confines of the game engine, without making the fight unfair, gimmicky, or unreasonably stochastic. At level 20, you have a decent chance of beating him if you know what you're doing, though you may have to fight him a few times to learn his patterns.

The NPC who makes the "Pennsylvania" comment about the Lunar Shield is giving a hint (Franklin Badge): although it only grants 1 point of absorb, it grants lightning resistance AND can be used by any character except the Monk, regardless of whether they can use other shields. The Dragon Mail also provides elemental resistances (fire, ice, lightning). These can help you survive a turn-one EXAVOLT, should CHAOS decide to go that way.

He has the spell HEX, so make sure you go into the fight with a few CLNS potions on hand. Although the SaphRing (CLNS) is very useful, it clouds as a spell, so you'll need to potion its user before it can be used to un-HEX you. CUR4 and HEL4 also remove statuses, so if you need to recover HP and fix status, you can use those.

Chaos's physical attacks are nasty. SLOW has a chance of landing on him if cast by a high-level Sage, and might be worth doing, especially to cancel out HSTE, but it's also a good idea to use spells like IVS2 and SLD3 that you know will work. These are not perfect protection--he might still score a critical hit--so keep your HP above 200, and ideally above 300, no matter what. Also, BIND is in his spell table (though late enough that, if you see it, you have other problems) so you can't count on your invisibility to last forever.

In addition to EXAVOLT and AIRBURST, he has the non-elemental GAMMARAY, which you've probably already seen and can hit for over 400, but his worst attack is GONER, an all-party non-elemental attack that can do more than 500 damage. The best defense against GONER is... don't get GONER'd. Try to kill him first. You have, on average, thirteen turns before he gets around to it.

CHAOS has no elemental weaknesses, but is of enemy types Ancient, Human, and Magic-User, so the Viking, Ranger, Ninja, and Warlock all have class-specific weapons that do extra damage to him, so there is no point in using the Lunar weapons, but those target the Ancient type (remember the NPC who said that dinosaurs hate the Moon?) and so does the "Wooden" staff you found in the Ice Cave. You don't need any Lunar equipment to beat Chaos, as the class-specific weapons and your magic are good enough, but it may help.

More specific strategies for each party member are below:

Viking: do what Vikings do best. Start wailing on CHAOS immediately while support characters increase his damage output using buffs like HSTE, TMPR, and GLRY. 

Rogue: they're great at escaping, but they won't be doing that here, so physical offense is the way to go. If you have 40000 Gil, you might want to buy a Lunar Sword for this guy, but it's not necessary. Sting can do the job, especially if he's supported with buffs. After a devastating magic attack like GONER, the Rogue might be the only one standing.

Monk: the Monk shines in long battles like this. He has HSTE/HST2, TMPR/TPR2, and GLRY. It's not a bad idea to keep a charge of HST2 on hand, because CHAOS can SLOW the entire party. Although Monks (unless buffed) tend to be mediocre damage dealers in late-game fights, a HSTE'd one at level 20 will land 20 (!) hits per turn, which means each TPR2 increases his damage output by about 900 points. Offensively, he's got everything it takes to take down CHAOS--he just needs time to get set up (and, you know, to survive).

Ninja: the Ninja might want to use up his FLAR spells (600+ damage) while waiting for the other characters' buff spells to land, but he should switch to physical attacks after a couple turns. There's no value in buying a Lunar Sword for him--the Masamune targets Humans and is therefore more effective already.

Paladin: the Paladin, if she leads the party, can tank physical blows in the front, but you’ll still want to keep her HP up, because of magic attacks and critical hits. The upshot of Paladins here is that, in addition to being tanks, they can also heal the other characters--but if a Paladin is your only healer, you probably want to equip the other party members with Heal Staffs too, because her magic alone won't always be enough to keep up with his damage.

Wizard: in this fight, Wizards should TMPR/TPR2 and HSTE/HST2 the fighters. They're very effective in a support role, but they usually won't be on primary physical offense, unless carrying a Lunar Sword; usually, they'll be casting buff spells in at least the first four turns. Keeping a charge of HST2 is a good idea.

Priest: as a HEL4 caster with strong magic defense, the Priest has a good chance of surviving GONER and being able to pick up some of the pieces. Unfortunately, revival in battle is impossible--the game engine doesn't allow it--so the odds are long if he's the only one left. He does have access to GLRY, so he can buff the whole party when he's not needed for healing.

Cleric: the Cleric is very powerful in this fight because she has access to lots of whole-party buffs: SLD3 and INVS to limit CHAOS's damage output (although critical hits still hurt), GLRY to boost the fighters. She can slow CHAOS down while the fighters get better and better.

Warlock: although the Warlock excels against mobs with his multitarget magic, this won't do much for him against one adversary, though spells like FLAR still work. If you can land haste or a couple attack buffs on him, though, he can do considerable damage, especially because his ultimate weapon targets Magic-User, which Chaos is.

Sage: because she's the only one who has it, you might think you'd want to have her use SAGE in this fight, but it can't do more than 1000 damage. Instead, spend her spell charges on HST2, TPR2, GLRY, or SLD3. The good news is that she's the least likely of all the classes to run out of magic--if she lives long enough to do so, she will have made the rest of your party *extremely* powerful.

Ranger: as the generalist and most versatile class, the Ranger can be used for a number of purposes. As with the Ninja, I would use him for his spells early on and switch to physical attacks later on. There is no reason to buy him a Lunar weapon--his endgame choice is quite effective and targets the Human enemy type.

Fool: you've come all this way, with a Fool? He does, like everyone else, get one turn. That's better than zero. Perhaps he can hand out potions or use the heal staff or something. I don't know.

You can do everything right in this battle and end up one party member, possibly two, down. For this reason, HST2 and GLRY are invaluable; you can't rely on a single "wrecking ball" fighter because any character can be GAMMARAYed or GONERed into oblivion. Your strategy, in other words, must be resilient against losing a party member. If you lose two? Then you're in desperation mode; go for all-out DPS. At this point, your Sage can cast SAGE (if she has any 8th-level charges left, and hasn't been buffed enough to do 750+ damage per turn) and your FLAR-casters can start firing that off (again, if they're not buffed enough to be offensively capable) but everyone else should fight, healing when they can. At that point, you're just spamming damage and hoping for the best.

Follow the strategy above, at level 20 with a typical party, you have about an 80% chance of beating CHAOS. Good job. World saved. I give you your life back. Go play something else. Or create another party and do this whole thing again. Or buy my novel, Farisa's Crossing, if it's out yet... and make fun of me for taking too long, if it isn't.

=== Appendix: Achievements (Spoiler Free) ===

Mandatory (100 pts)
1.  ( 5) Defeat Garland.
2.  ( 5) Defeat Bikke and steal his ship.
3.  (15) Defeat the Earth Fiend, Lich.
4.  (15) Defeat the Fire Fiend, Kary.
5.  (15) Defeat the Water Fiend, Kraken.
6.  (15) Defeat the Air Fiend, Tiamat.
7.  (30) Defeat Chaos.

The Expansions (200 pts)
8.  (10) Defeat Astos.
9.  (10) Get the airship.
10. (30) Get 8/8 rings in one playthrough.
11. (20) Defeat the Dark Fiend.
12. (20) Defeat the Ice Fiend.
13. (20) Defeat the Time Fiend.
14. (20) Defeat the Holy Fiend.
15. (20) Get all 4 treasures from Forbidden Castle.
16. (50) Defeat Chaos with all 4 party members alive.

Superbosses (200 pts)
17. (25) Defeat WarMECH.
18. (25) Defeat Gold G.
19. (25) Defeat GrMORBOL.
20. (50) Defeat PINKPUFF.
21. (75) Defeat PINKPUFF with all 4 party members alive.

Numberwang (200 pts)
22. (25) Do at least 4000 damage to one target w/ melee attack.
23. (50) Do at least 1000 damage to one target w/ magic attack.
24. (50) Do at least 10000 damage (to any number of targets) in one round.
25. (25) TAKE at least 1000 damage in one attack.
26. (50) SURVIVE a 500+ damage attack.

Classiness and Foolishness (100 pts)
27. (20) Beat the game using each of the 11 main classes at least once.
28. (30) Beat the game with one Fool in your party.
29. (50) Beat the game with two Fools in your party.

How Low Can You Go? (175 pts)
30. (15) Beat the game at final level <= 22.
31. (35) Beat the game at final level <= 20.
32. (50) Beat the game at final level <= 18.
33. (75) Beat the game at final level <= 16.

White Knuckle (200 pts)
34. (50) Survive physical attack from PINKPUFF and win fight. (The attacked character must survive the whole battle.)
35. (50) Survive GONER and win fight.
36. (100) Defeat Chaos with one character alive and HP <= 32.

It's About Time (175 pts)
37. (15) Beat game in 18 hours or less.
38. (35) Beat game in 14 hours or less.
39. (50) Beat game in 12 hours or less.
40. (75) Beat game in 10 hours or less.

Back In My Day... (50 pts)
41. (50) Beat final dungeon without running or using "hidden" inns/clinics.

Lore, Cheats, Etc. (200 pts)
42. (10) Which NPC discovers a love of learning in the afterlife?
43. (10) Why did Lefein fall? Not Tiamat. Hint: mathematical misdemeanor.
44. (10) Cast a spell to find a programming joke in the script.
45. (10) Win a Peninsula of Power fight at level 7 or less.
46. (10) "Steal" any character's endgame weapon at level 9 or less.
47. (10) Get airship at level 9 or less.
48. (20) Take 100+ damage from an IMP.
49. (20) Win a 1000+ XP fight using only one action (not one round, one action; however, no-effect item actions don't count against you.)
50. (20) "Cheat" in the Ice Cave.
51. (30) The hidden thing that isn't listed here. If you think you deserve these points, you probably do.
52. (50) Who can we be certain was killed by Chaos, using what weapon, and where? (May require external research.)

Unsolved by Developer (1000 pts)

53. (100) Beat game in 8 hours or less.
54. (200) Beat game in 6 hours or less.
55. (300) Beat game in 4 hours or less.
56. (100) Beat game at final level <= 14.
57. (300) Low Level Game! (Final level = 12, the lowest possible.)
