Title: Battle DTE fixer upper
Author: Lenophis
Version: v1.0
Applies to: Final Fantasy, US version
Tested on: Final Fantasy, US version

Contents: DTE.ips
          Anti DTE.ips
          readme.txt
          DTE original.txt
          DTE new.txt

ROM addresses: 0F/FAB1 - 0F/FAF0

Ok, maybe those aren't the true addresses, but this is for the hard-wired bank,
which translates to the addresses above. File offsets are 0x3FAB1 through
0x3FAF0. Add the 0x10 byte iNES header for both afterwards.

Urgency: Medium
Depends on if you like DTE or not. If not, then get the hell out! =p

--------------------------------------------------------------------------------
Description:

Anybody that has ever hacked monster names will quickly realize that the DTE
does not work.

--------------------------------------------------------------------------------
What this patch does:

Adds DTE ability for monster names in battle, as well as a minor optimization
which frees 0x23 bytes in the process. This is something patch authors are sure
to love.

Note: The anti patch will remove the patch.

--------------------------------------------------------------------------------
Version history:

v1.0 - October 04, 2009
       Initial release

--------------------------------------------------------------------------------
Credits:

bbitmaster & Parasyte - Creators of FCEUXD, which greatly aided in finding the
 mess that Nasir created here.

Disch - Creator of FFHackster, who for some reason let the user use DTE for
 monster names. Additional mention for having a (mostly) commented diassembly
 which made some addresses easy to find.
