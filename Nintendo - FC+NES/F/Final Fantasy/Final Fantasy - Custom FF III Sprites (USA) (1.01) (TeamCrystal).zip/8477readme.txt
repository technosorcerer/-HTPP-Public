This patch comes in two versions: One specifically for Grond's Final Fantasy, and one for Vanilla (Base) Final Fantasy.

To install, apply the Sprite Blackout Patch followed by the Custom FF III Sprites patch matching your version. Use the
GFF version for Grond's Final Fantasy, and the Base version for Vanilla Final Fantasy. The blackout patch is used to
prevent interference between the original character sprites and the new ones, increasing compatiblity dramatically.
For best results, apply this mod after all other graphics altering mods.

Compatiblity can only be guaranteed with GFF and Base FF, but the patch for Base FF should also be compatible with
most other mods as well, specifically Final Fantasy Restored. Any mod other than GFF that changes the locations of
character palettes or sprites is incompatible with this mod.

If playing the game with an emulator that supports custom palettes, such as Nestopia, True NES Palette.pal can be
optinally used to display the game using the raw color data rather than the colors the NES originally produced when
sending the image to the TV. All screenshots were taken using this palette, so the new sprites will look a little
different compared to the default NES palette.
