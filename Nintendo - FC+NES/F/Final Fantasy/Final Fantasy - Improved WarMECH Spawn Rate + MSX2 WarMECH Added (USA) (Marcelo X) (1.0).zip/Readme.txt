Feel like fighting WarMECH yet don't want to spend all day on the bridge?
Here are two patches I made for the USA release of Final Fantasy on the Nintendo Entertainment System to save some time.


(Use your favorite IPS Patcher software [I used Lunar IPS.exe] and apply the patch to the game. That's it!)


Final Fantasy (Marcelo X's: WarMECH's Domain Mod)
-------------------------------------------------
Only 2 Battles Occur in WarMECH's Domain (Sky Castle - 5F [Fifth Floor.])
-WarMECH.
-MSX2 WarMECH (Battle with two Death Machines from the Machines with Software eXchangeability 2 release of Final Fantasy.)
This mod causes a palette adjustment to random miscellaneous things and Kary (her hair/eyes are white instead of yellow.)


Final Fantasy (Marcelo X's: Notorious Monster Invasion Mod)
-----------------------------------------------------------
WarMECH and T REX now have the same odds of appearing as normal enemies, their locations have not changed.
This mod does NOT include the MSX2 WarMECH, nor are there any palette adjustments, so Kary looks normal.


Note: Keep in mind that WarMECH is the hardest enemy, the fifth floor of the Sky Castle will become extremely dangerous.


Made By Marcelo X on 10/24/2022 (These patches were created after trying to get into battle with WarMECH for a couple of hours with no success, worst streak of bad luck with getting into a battle with WarMECH in 33 years of playing the first Final Fantasy. lol Was just in the mood for that bad ass battle without the hassle, so I made these two patches..)