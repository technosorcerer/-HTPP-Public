░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒

          --- Manall's FF1 ---

         http://manallsmods.net

   ... for patch notes, updates, and
       news about my other projects.

▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░

Hello! Thank you for trying my mod.

I love everything about this game. Years of effort went into making this fresh, tougher, modern experience with some new flair. 

I've made some charts to help you on your journey - click the documentation link that came with the mod to view them.

GOOD LUCK!

contact: manalockhart@gmail.com

(psst. If you wanna try Magecore/Lunarscape, you'll have to defeat CHAOS first.)

░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
                                
             Getting Started
             ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯
▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░

Apply my .ips patch to a headered*, unmodified FF1 USA.nes rom file, grab an NES emulator and you're set to play! 

*Refer to the download page on the website if you do not know whether your rom is headered.

░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
                                
                 Options
                 ¯¯¯¯¯¯¯
▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░

All patches can easily be reversed.

Patch 1 - Default: ON
¯¯¯¯¯¯¯
This mod uses static experience gain - EXP is always divided by 4 regardless of character status. Turn this off if you prefer the classic setting, or if you're doing party challenges.

Patch 2 - Default: OFF
¯¯¯¯¯¯¯
Turn this on if you'd like to disable all non-essential spell messages in battle. Combat will go much faster! (Note - damage and certain status updates still appear)

Not recommended for players who haven't memorized spell effects.

Patch 3 - Default: BLUE
¯¯¯¯¯¯¯
I have provided many battle skins for you to choose from which customize your battle screen border color. If you'd like something different, email me with your desired color.

Patch 4 - Default: OFF
¯¯¯¯¯¯¯
Still not hard enough? Try Patch 4. This patch increases the size of monster formations by +3 for small, +2 for small-large mixes, and +1 for large. The difficulty (and rewards!) will rise accordingly to meet you...with a blade at your throat.

Patch 5 - Default: OFF
¯¯¯¯¯¯¯
This patch removes the flashing effect from spells. Use this if you have health-related concerns or if it's just a bother on your eyes.

Patch 6 - Default: ON
¯¯¯¯¯¯¯
By default, FIRE, LIT and ICE are area effect attacks in this mod, and deal half damage. Disable this patch to restore them to their original functionality.

░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
                                
                 Credits
                 ¯¯¯¯¯¯¯
▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░

Jiggers..........direct system contributions, assembly, insight & development...zheep!

Xyfor............help with cosmetics, motivation and sprites/monsters!

Marf Norrelia....inspiration and help with sprites!

Pommelo..........Inspiration, feedback and apples!

Disch............creating hackster and the disassembly!

Marsh............feedback and inspiration!

AstralEsper......whose expertise got me excited about the idea of modding FF1!

Joe73ffdq........compiling the disassembly companion!

CaptainMuscles...creator of the original dynamic action patch!

Anomie...........all your patches and crazy edits!

Paulygon.........creating hackster plus, and edits to said crazy edits!

Grond............inspiration, especially in interface design & formatting!

Mentil...........inspiration from and development of FF Hasted!

░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
                                
               Mystery Box
               ¯¯¯¯¯¯¯¯¯¯¯
▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░

Since you're still reading I'll assume - it's because you have your eye on that. 

Pay close attention when speaking with others...you should be able to find the key!