Remarco un par de cosas:

Algunas cosas no quedaron perfectas porque no hay manera de hacerlo mejor (al menos con lo que se) por ejemplo la pantalla de titulo.
Donde decia "normal mode" y "free mode" no es texto, sino que son graficos, que a la vez repiten algunas letras, por lo que eso limito un monton lo que podia hacer.
"Normal mode" quedo como "normal" , y "free mode" quedo como "practica" pero al practica tuve que bajar renglon porque sino pasando esa parte repetia lo que sea que pusiera.

Para completar algunas palabras borre signos que no se usaban y en esos puse 2 o 3 letras, por eso es que algunas letras se ven mas chicas.

Hay algunos cuadrados negros en algunas partes. Eso paso por tener que forzar los espacios en algunas partes, no quedo otra opcion XD.

Hay un solo bug y por suerte no rompe las bolas. Viste que si vos no elegis normal o practica muestran la descripcion de uno de los 4 autos mas un gameplay corto? bueno.
El bug es un chasheo, pero por suerte solo pasa cuando pasaste el juego, y despues de que pasaron los creditos dejas que arranque esa descripcion del auto y gameplay del juego de nuevo. 
Osea, si arrancas el juego normal y dejas que arranque la descripcion y el gameplay no se tilda, solo pasa despues de ver los creditos de fin del juego y dejas que arranque la descripcion del coche y el gameplay.

Para mi quedo bastante decente, pero bue, acepto cualquier tipo de critica XD
