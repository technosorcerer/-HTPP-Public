Fire Emblem Gaiden: Route Swap
Made by Merpin


Thank you Hextator for creating the Nightmare program and its modules.


Apply this to a clean Japanese ROM of Gaiden. Afterwards, you can put any translation over it. Only the Artemis translation has been tested, but anything else should work.