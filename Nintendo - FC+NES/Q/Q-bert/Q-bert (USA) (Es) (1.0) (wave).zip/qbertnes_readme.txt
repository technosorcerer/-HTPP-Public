Q-bert (NES)
Traducción al Español v1.0 (30/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Q-bert (USA).nes
MD5: 6c660602b017ea33498f5dd43d364793
SHA1: e1587a29d66d5fe11a0b8855f17399602936115e
CRC32: 8f992f3c
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --