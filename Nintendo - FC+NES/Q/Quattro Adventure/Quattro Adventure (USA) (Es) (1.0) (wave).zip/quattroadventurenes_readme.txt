Quattro Adventure (NES)
Traducción al Español v1.0 (08/05/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Quattro Adventure (USA) (Unl).nes
MD5: d8660c72782af6bbf8881288ccc874d7
SHA1: b402372554167343ed5cc6ae46c02351766ca208
CRC32: ee8e3a91
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --