﻿-----------------------------------
Yie Ar Kung-Fu (J) (V1.4) [!].nes (16/08/2020)
-----------------------------------
File MD5      B48DB05C48AF5A75220A4043A17DDE90
File SHA-1    AFD2B46265E14AB87FBDDF054252FB2D4B5AD257
File CRC32    0D526208

ROM MD5       3C811B8B45949925CB02CC90BEFBFA35
ROM SHA-1     55D6146D7CDDB4CA9BD368DCACD5A855999C1017
ROM CRC32     86CEFC12

----------------------------------
Registro de cambios
----------------------------------
1.1
Edición de posición de textos.
Edición de punteros.

----------------------------------
Contacto |Errores |Bugs |Recursos!
----------------------------------
https://linktr.ee/Terwilf
