Final part of the Ys series for the NES, this was by far the easiest and quickest work that was done to improve the game in general, as very little was changed in it, based on the following work:

Ver. Final Fix: A small correction in HUD.

Vice Translations (original translation)

https://www.romhacking.net/translations/240/

Pacnsac Dave (a small graphic edit on one of the intro screens).

Minucce (original improvement hack).

Minucci only made two changes, one to fix the hud and one to fix a bug in the final boss’s movements caused by his own hack, the rest didn’t need to be changed. As for the Vice group’s translation, an italic font was adopted which in this hack was reverted to David Mullen’s original in his translations of Ys 1 and 2, some characters had to be edited because they were not the standard. Tested in Mesen and FCEUX without any problems detected