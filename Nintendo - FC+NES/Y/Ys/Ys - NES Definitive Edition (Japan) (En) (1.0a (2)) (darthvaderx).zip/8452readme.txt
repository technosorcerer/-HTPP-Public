Ys NES Definitive Edition by darthvaderx.

Hack based on works by Datchy, SomeOldGuy/PacnsacDave (title screen), Dave Mullen (translation) and Minucce (original hack). Several edits were made to eliminate at least the majority of the bugs presented by the latter, there are still some, but nothing that affects the gameplay in general. Please leave a description of any more serious problems encountered in the game in the comments.

More information about what was done here:

https://www.romhacking.net/forum/index.php?msg=454710

Note: Does not work in FCEUX!!! Tested only on Mesen, not tested on other emulators besides these two.
