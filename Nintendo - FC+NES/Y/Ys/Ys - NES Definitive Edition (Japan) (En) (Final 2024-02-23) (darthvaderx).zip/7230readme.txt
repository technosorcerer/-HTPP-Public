Ys NES Definitive Edition by darthvaderx.

Hack that aims to fix some graphical and gameplay errors of the original game as well as other improvements, based on these works:

-SomeOldGuy (which is based on the PacnsacDave's work) and Datchy (title screen hacks):

https://www.romhacking.net/hacks/6306/

-Dave Mullen/Makoknight (translation):

https://www.romhacking.net/translations/238/

-Minucce (original improvement hack):

https://www.romhacking.net/hacks/6247/

Various edits have been made to eliminate most of the bugs introduced by this latest hack, there are still some, mainly in the Darm Tower part, but nothing that affects the gameplay in general. Please leave a description of any more serious problems encountered in the game in the comments.

More information about what was done here:

https://www.romhacking.net/forum/index.php?msg=454710

Note: Does not work in FCEUX! Tested only on Mesen, not tested on other emulators besides these two.
