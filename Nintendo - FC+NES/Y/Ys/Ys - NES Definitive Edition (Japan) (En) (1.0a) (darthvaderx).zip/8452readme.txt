Ys NES Definitive Edition by darthvaderx.

Hack based on works by Datchy,SomeOldGuy, PacnsacDave (Title screen). Dave Mullen (Translation) and Minucce (Original hack). For my part, several edits were made to eliminate at least the majority of the bugs presented by the latter, there are still some, but nothing that affects the gameplay in general.