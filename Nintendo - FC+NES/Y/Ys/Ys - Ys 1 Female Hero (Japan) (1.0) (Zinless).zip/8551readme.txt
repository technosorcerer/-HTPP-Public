Ys 1 Female Hero (Project Adele) by Zinless

This is a simple sprite edit that turns the male protagonist (Adol) into a female one (Adele...?)

To install, just apply the ips patch (ys1adele.ips) into your ROM.

Sprite edit by Zinless
Special thanks to Lorenz for teaching me how to make this into a patch.

Contact me on Discord: zinless