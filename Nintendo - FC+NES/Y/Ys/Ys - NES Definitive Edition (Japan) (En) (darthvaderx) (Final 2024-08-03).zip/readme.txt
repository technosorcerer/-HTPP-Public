Ys NES Definitive Edition by darthvaderx.

Hack that aims to fix some graphical and gameplay errors of the original game as well as other improvements, based on these works:

-SomeOldGuy (which is based on the PacnsacDave's work) and Datchy (title screen hacks):

https://www.romhacking.net/hacks/6306/

-Dave Mullen/Makoknight (translation):

https://www.romhacking.net/translations/238/

-Minucce (original improvement hack):

https://www.romhacking.net/hacks/6247/

Various edits have been made to eliminate most of the bugs introduced by this latest hack, there are still some, mainly in the Darm Tower part, but nothing that affects the gameplay in general. Please leave a description of any more serious problems encountered in the game in the comments.

More information about what was done here:

https://www.romhacking.net/forum/index.php?msg=454710

Note: Note: To work in FCEUX, go to CONFIG > PPU > NEW PPU.

Rom info:

Database match: Ys (Japan)
Database: No-Intro: Nintendo Entertainment System (v. 20210216-231042)
File SHA-1: 0F940EF923B43C1821F9ABB4DCA642527FA04A8F
File CRC32: F7FBB9CB
ROM SHA-1: 5064C11751EA56ACF28FDC63A866657E0035C42E
ROM CRC32: 92547F1C