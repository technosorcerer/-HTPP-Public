
Yuu Yuu Hakusho - Bakutou Ankoku Bujutsu Kai

Hack: Do Not Need DATACH Barcode


# About Mapper

Two versions are provided, mappers are 16 and 157 respectively. Different simulators have different support for mappers. For example, FCEUX can run mapper 157, and VirtuaNES can run mapper 16. If one doesn't work, please try the other one.



# Description

- Press buttons to select character. Use the arrow keys to adjust the ID, the START key to confirm, and the SELECT key to select randomly (random is not available in the judgment room). The START and SELECT keys do not distinguish between 1P/2P (that is, the START/SELECT of 1P is also valid for 2P. This is considering that 2P in some environments may not have START/SELECT).

- All characters can be selected in both story mode and battle mode, including the hidden character younger Toguro 120% (did not appear in the original story mode).

- Fighters are all full-skilled (the character skills obtained through barcode selection in the original version may be incomplete), and the assistants are all with the highest values.

- In story mode, you can choose a character before the battle against younger Toguro 80% (Yusuke Urameshi was always used in the original version).

- After defeating younger Toguro 80% in the story mode, if the remaining HP >= 2000, the final boss will be changed from younger Toguro 100% to younger Toguro 120% (did not appear in the original story mode).



# Input

- UP:       ID +10
- DOWN:     ID -10
- LEFT:     ID -1
- RIGHT:    ID +1
- START:    Confirm
- SELECT:   Random



# Character ID Range

- 00-22     Fighters
- 23-28     Assistants
- 29-32     Special Characters



# Known Issues

- Some tiles on screen will be changed when ID is displayed. Because the tiles for sprites are replaced at that time. It will be recovered after the selection.



# Contact Information

- Email: wangsitan@aliyun.com
- WeChat: wangsitan7



# Donate

If you would like to donate, you can do so in the following ways:
- PayPal: wangsitan7@gmail.com
- Alipay: wangsitan@aliyun.com

Thank you very much for your support!


2024-01-14

