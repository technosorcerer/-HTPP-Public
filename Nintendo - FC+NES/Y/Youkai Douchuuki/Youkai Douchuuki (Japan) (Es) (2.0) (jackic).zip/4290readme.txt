Parche de traducci�n al castellano para el juego "Youkai Douchuuki" de Nes

�Esto qu� es?

Esto es un parche para modificar el mencionado juego de Nes y traducir en la medida de los posible los textos del japon�s al castellano.

�Qu� est� traducido?

Est� traducido mayormente todo el texto del juego as� como casi todos los gr�ficos. 

Bugs y estad�sticas

En la consecuci�n de este proyecto se han invertido bastante horas y cari�o, antes de este parche, no exist�a ninguna modificaci�n del texto para este juego debido, se ha localizado directamente del japon�s. 

�Para qu� versiones vale este parche y qui�n lo puede usar?

Este parche solo se puede aplicar con �xito a la rom "Youkai Douchuuki (J) [!]" ROM CRC32    C811DC7A

�Qu� me hace falta para instalarlo?

La rom en cuesti�n, este parche y un parcheador ips.

�C�mo aplico la traducci�n?

Usa un parcheador IPS, por ejemplo Lunar Ips para aplicar el parche a la rom y listo.

Notas: 

Se ha testeado el juego a FUEGO en el emulador fceux pero esta vez NO se ha probado en hardware real(everdrive), si alguien lo prueba, por favor que se ponga en contacto conmigo para actualizar este archivo de informaci�n.

Gracias por usar esta traducci�n.

Jackic 2019.