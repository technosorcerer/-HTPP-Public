Ys II NES Definitive Edition by darthvaderx.

Here the second part of the Ys trilogy on the NES, a hack made with the aim of fixing graphical and gameplay bugs as well as bringing other improvements, was based on the work of these people:

-David Mullen/Mako Knight (translation):

[url]https://www.romhacking.net/translations/239/[/url]

-Pacnsac Dave (title screen hack).

-Minucce (original improvement hack):

Hack not released, the hud was fixed and deadzone scrolling improved, there may have been other improvements, but they were not documented. Originally this game has several improvements compared to the first part and apparently very little needed to be fixed, there may still be bugs, but they are almost imperceptible, tested on Mesen and FCEUX and works completely on both.