Day Dreamin' Davey (NES)
Traducción al Español v1.0 (08/10/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Day Dreamin' Davey (USA).nes
MD5: 6951af5e75398437a8a6e255268e8952
SHA1: 4c88391318e3bd79c14bff6724a377688e47261b
CRC32: ced13971
393232 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --