Defenders of Dynatron City (NES)
Traducción al Español v1.0 (21/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Defenders of Dynatron City (U) [!].nes
MD5: adde664c787b9778f64085d75299758e
SHA1: 5a979137158b458ce08a08e0996dea518ea18028
CRC32: 8db6ba41
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --