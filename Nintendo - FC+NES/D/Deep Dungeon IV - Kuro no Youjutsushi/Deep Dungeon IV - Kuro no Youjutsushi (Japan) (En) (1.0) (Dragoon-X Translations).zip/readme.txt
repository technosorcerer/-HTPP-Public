

				Dragoon-X Translations Presents...


	DDDDDDD   EEEEEEEE EEEEEEEE PPPPPPPP
        DDDD  DDD EEEE     EEEE     PPPP   PPP
        DDDD  DDD EEEE     EEEE     PPPP   PPP
        DDDD  DDD EEEEEEE  EEEEEEE  PPPPPPPP
        DDDD  DDD EEEE     EEEE     PPPP 
        DDDD  DDD EEEE     EEEE     PPPP
        DDDDDDD   EEEEEEEE EEEEEEEE PPPP

	DDDDDDD   UUU  UUU NNN  NNN  GGGGGGGG  EEEEEEEE  OOOOOO   NNN  NNN
	DDDD  DDD UUU  UUU NNNN NNN GGG    GGG EEEE     OOO   OOO NNNN NNN
	DDDD  DDD UUU  UUU NNNNNNNN GGG        EEEE     OOO   OOO NNNNNNNN
	DDDD  DDD UUU  UUU NNN NNNN GGG   GGGG EEEEEEE  OOO   OOO NNN NNNN
	DDDD  DDD UUU  UUU NNN  NNN GGG     GG EEEE     OOO   OOO NNN  NNN
	DDDD  DDD UUU  UUU NNN  NNN GGG    GGG EEEE     OOO   OOO NNN  NNN
	DDDDDDD	   UUUUU   NNN  NNN  GGGGGGGG  EEEEEEEE  OOOOOO   NNN  NNN


				IIIIIIIIIIIIIIIIII
				IIIIIIIIIIIIIIIIII         "The Black Sorcerer"
				  IIII III   III
 				  IIII	III III
				  IIII	 IIIII
				  IIII	  III
				  IIII 	   I
                                IIIIIIIIIIIIIIIIII
                                IIIIIIIIIIIIIIIIII

				Translation  V 1.0 	
		
           Updates of this patch can be found on http://www.emucamp.com/dxtrans

        -------------------------------    -----------------------------
	|Rom Hackers - kueller & WeirdMan|====|Translator -  Hunny | 
	-------------------------------    -----------------------------
         \_____________________________\==/___________________________/

----------------------------------------------------------------------------------------------------------

The Long and Boring Story of This Translation - 	

I'm sure you're wondering, what the heck is Deep Dungeon IV? Well to tell the truth
i'm not too sure myself. I believe there were 4 in the Deep Dungeon Series each developed by 
Square,Asmik and Hummingbird Soft I think. It is a 3D RPG like Wizardy and Arcana for the SNES.
Why did I choose to translate this in the first place?... To be honest I don't know. It really
wasn't my decision. I had gotten Dragon Quest VI for Christmas in 97' and it inspired me to learn
about romhacking. So I talked to my buddy BigWierd and got some docs and some info and read up on
it. A day or so later I popped into a channel on Austnet to chat with some buddies, Aerisu and
Butz had started learning about romhacking too and had started working on some game I had never
heard of. Deep Dungeon IV, so we founded Off Course Translations, which was doomed from the start.
Pretty soon, we figured out that Butz was butchering the script, making up quite a bit of it.
And soon Aerisu quit romhacking altogether so I was the lone romhacker on this project, and I left.
I started chattinig on #romhack when it was fruity fresh and Ghaleon-X,survive,and Animefx helped me start
reviving the project. We got a little bit farther and I released a small patch as a #Romhack translation.
But soon we lost contact with each other and again the Deep Dungeon IV project was forgotten. Finally
in December of 98', Kueller decided to help me revive Deep Dungeon IV one last time. So we got to work on it
(Though I must admit he did a lot of it) and we got a translator named Hunny and later Demi finished
the rest of the scripts up. So here it is, finally completed... Deep Dungeon IV. Maybe someday we can
tackle the other 3 but I doubt it =) The translation was an easy one from the beginning, it just lacked
dedicated team members. So I'm very thankful for kueller for keeping up his hard work on this project.
I'm glad I could finally see it be completed... Now quit reading this and go play it =)

WeirdMan 
Leader of Off Course Translations

Well, here we are, at the beginning of the long and hopefully prosperous road of Dragoon-X Translations.
I have a lot planned for the group, once Dragon Quest 5 is complete (remaining optimistic), and I hope to continue
bringing smaller games such as Deep Dungeon IV to the translation scene. As far as DD4 was concerned, it was a relatively
easy hack. A lot of control codes made it bitchy at first, but once we got through that, it was a piece of cake.
I do plan on doing the other Deep Dungeon games. I have been unable to locate the Deep Dungeon II ROM, so
that's out of the question for now. Deep Dungeon I is for Famicom Disk System, which from what I've been told,
is just as easy as NES. Enjoy this translation of Deep Dungeon IV by Dragoon-X, and I hope to be writing another
one of these soon.

Kueller
Founder of Dragoon-X Translations

----------------------------------------------------------------------------------------------------------

Version Information
V1.0    - Battle system display bug fixed, for the most part.
        - Complete monster name translation.
        - Untranslated bits and pieces of text blocks translated.
        - Enjoy the complete translation!

V0.90b  - For the most part, everything is translated. Dialogue is complete, as is items.
	- Display problem with battle system. Names of monsters & spells will not show up in battle box.
	- Untranslated bits and pieces of different text blocks. I think a bit of shop dialogue is left, monsters untranslated, as is special intro.
	- Names may not be correct in all places. We've had about 7 or 8 translators do bits and pieces of script for us, and they may have translated names differently than others.


What's Planned? (Assuming I ever want to continue work on future versions)
        - Insertation of DTE.
   
----------------------------------------------------------------------------------------------------------

Special Thanks & Greetings to -

Ghaleon-X - For the Title Screen Work
BigWierd - Hey bud! Thanks for the inspiration
Zantagor & skippy911 - All the monster name translations.
Animefx
Aerisu
FredTC
Roto
Dark Force
SrDragoon
Spinner_8 - My translation section kicks your translation section's ass. 
Spirit in the Contraption 
Neil_ - I told you i'd get it done. :)
ZHeights
Wildbill
DarkMazda, YnT, and the DMD crew
Brad Nowell - For the sweet sounds of Sublime. 
Everyone on the CTC board, especially those who helped with the spot trans request.

I know there are many I'm forgetting and I'm really sorry =) Hopefully you know who you are.

----------------------------------------------------------------------------------------------------------

Still here huh? Wow, you must be bored or be waiting for your name to be listed on this doc =)
Well that's all we have to say...

kthxbye!

WeirdMan & Kueller

Deep Dungeon IV Translation (C)1999 via Dragoon-X Translations No rights reserved.

We are not affiliated with Square, Hummingbird Software or Asmik in any way that we know of =P
We're just 2 guys that were bored one day and felt like hacking.