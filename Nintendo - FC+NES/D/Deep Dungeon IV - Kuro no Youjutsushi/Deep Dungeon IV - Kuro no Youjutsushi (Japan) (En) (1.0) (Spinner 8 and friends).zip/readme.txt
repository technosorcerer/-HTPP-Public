Deep Dungeon IV Header Correction Patch
by Spinner 8
spinnereight@gmail.com
1 June 2013

----

Deep Dungeon IV was translated by Off Course Translations and Dragoon-X
Translations 1998-1999.
Deep Dungeon IV was published by Asmik 1990.
This patch does not intend to take any credit for any of these works.

----

Way back before Dragoon-X was involved in translating Deep Dungeon IV, the
translation project was originally started by Off Course Translations,
consisting of Dustin Hubbard (now going by Hubz). The ROM he used to hack
the game had one of those "dirty" headers that you used to see all the
time back in the day, and the same ROM was used throughout the project.
This means that any ROM patched with any of Off Course's or Dragoon-X's
patches will have a "dirty" header and will not run in most modern
emulators.

----

Long, long ago, when NES emulation was just starting, the creator of the
.NES file format (in all of his adorable naivete) decided that 16 memory
mappers were more than enough for all the NES games in all the world to
swap data in and out of the console's memory. And that's what he based his
original 16-byte header on: the same header that's used on every .NES file
to this day. A lot of the bytes in the header were unused, and a lot of
elite dudes took it upon themselves to create NES ROM utilities that, when
you ran them, inserted the dudes' own names into the unused header bytes.
"Mwahaha, now every single ROM that my program touches will have my name
in it," thought the dudes, "and who's it going to hurt, anyways? This is
just a bunch of bytes that nobody uses! Who cares!"

Just a couple years later, everybody realizes that NES memory mappers are
WAY more diverse and confusing than they first thought, not to mention all
those weird-ass Vs. and PC10 arcade games that were being released around
that time. So they decided to take one of those unused bytes in the header
and put some additional data in there, and now we have room for 256
mappers altogether (and even THOSE likely aren't enough). But now, all
those old ROMs that have crap in the formerly-unused bytes are trying to
be read by all the new emulators, and because there's data in that byte
that shouldn't BE there, emulators are mistaking it for actual information
and are using it to run the game in completely the wrong way.

For instance, when using the Dragoon-X translation patch on an original
ROM of Deep Dungeon IV, the ROM changes from a normal game that uses
Mapper 1, to a Vs. Unisystem game that uses Mapper 193! If the emulator
supports the recent extended .NES format, it will try to run the game in
the special arcade mode that was used by Super Xevious. So you can see why
most emulators will run the game wrong and end up showing only a gray
screen.

Another thing to realize is that all an IPS patch does is record the
differences between two files, so if there's some data that's the same on
both ROMs, the patch won't record it. That means that Dustin Hubbard must
have used a ROM with a bad header when hacking the game, and then used a
ROM with a CLEAN header when it was time to make the patch! Who even does
that? If he just used the same bad-headered ROM to make the patch, there
would have been no need for all this. Thanks a fucking lot, Ni0330.

----

This is an addendum patch, and is intended to be patched on top of a Deep
Dungeon IV ROM with a bad header. In the case of Off Course's and
Dragoon-X's translations, use this patch AFTER using the translation
patch.

This new patch will now restore the entire header, rather than just a
section, so it can be used on top of any Deep Dungeon IV ROM to restore
the header completely to its intended state. This includes the original
Japanese ROM, as well as KingMike's translation from 2011. It shouldn't be
necessary in those cases, but here it is if you want.

There shouldn't be any issues that arise from using this patch, but feel
free to contact me at the above email address if you have any problems or
questions.