Dream World Pogie Revival patch.
03.VI.2012
v.05

--------------------------
Authors
--------------------------
Dizzy9 - Hacking, coding.
Armacoder - GFX decompression tool.
nowa_era - Initial idea for project.

--------------------------
Info
--------------------------
This patch serves as an improvement for original game.
There's various changes done to make the game much more enjoyable and, more importantly, possible to finish.

--------------------------
Using the patch
--------------------------
Simply use Lunar IPS to patch original ROM.
Original ROM checksum should be: 1ff02326c28e1d6efdc23846d6d0d749
Patched ROM Checksum should be: 0ce8e2d20103d6f192b06b01afcf4807

--------------------------
Warning
--------------------------
This patch is non-commercial project, created for free.
Any attemps in selling or commercial use are severly forbidden.
Authors takes no responsibility for any of these.

--------------------------
Contact
--------------------------
Any questions can be answered by emailing this address:
Dizzy9@interia.eu

--------------------------
Changelog
--------------------------
0.1:
-Usage table fix.
-Werefuffle power up fix:
	Friction fix.

0.2:
-Map fixes:
	Door placed in more logical positions.
	Overall map fixes(some had used broken Meta tiles)
-Meta tiles fixes.

0.3:
-Multiplayer fixes:
	Repointered Rosie's Graphics, dancing animation, and a lot of other fixes to get this working.
	"Map holder byte" is fixed.
	Player is not fixed to Pogie after finishing level anymore.
	Pogie is not dragged back when Rosie finishes level.
0.4:
-Music Fixes:
	Found and repointered to the music table for every level.

v.05:
-Main menu arrow fixes
	Drawn, compressed, and placed GFX of arrow into ROM.
	Rewritten the code to unpack arrow in VRAM.
-various fixes in "Enter your name" screen.

