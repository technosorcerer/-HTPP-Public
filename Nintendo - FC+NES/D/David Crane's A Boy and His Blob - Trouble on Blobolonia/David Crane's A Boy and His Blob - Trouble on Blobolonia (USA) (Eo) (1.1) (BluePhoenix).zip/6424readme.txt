A Boy and His Blob: Trouble on Blobolonia (NES)
Traduko al Esperanto v1.1 (12/03/2022)

ENKONDUKO
---------
Ĉi tiu projekto estas Esperanta traduko de A Boy and His
Blob: Trouble on Blobolonia, videoludo por la Nintendo
Entertainment System. La retpaĝo por la projekto estas

    http://github.com/tboronczyk/aboyandhisblob

PRISKRIBO DE LUDO
-----------------
Samekiel multaj aliaj knaboj en la dudek-unua jarcento, la
knabo havas amikon de kosma spaco. Ĝi devenas de Blobolonio --
planedo, kie malbona reĝo devigas ĉiujn manĝi marŝmalojn kaj
ĉokoladon. Fakte, al la reĝo, sanigaj manĝaĵoj, kiel
vitaminaĵoj, estas venenaj.

Blob (kies vera nomo estas Bloberto) venis al la Tero serĉante
helpon por veniki la reĝon. Tiel li renkontis la knabon.

Por venki la malbonan reĝon, la knabo kaj Blob bezonas
provizon da vitaminaĵoj. Kaj por akiri la vitaminaĵojn, ili
bezonas monon. Kaj por akiri monon, ili serĉos kaŝitajn
trezorojn kaj diamantojn en la subteraj kavernoj.

Nu, kion faru la knabo? Li fajfu (tio vokas al Blob) kaj donu
ĵeleerojn al ĝi!

La knabo mirinde malkovris, ke Blob ne nur ŝatas ĵeleerojn --
sed diversaj gustoj ŝanĝas ĝin en diversajn formojn. Kaj tiuj
formoj helpos trapasi la alie netrapaseblajn situaciojn.

Kun sufiĉaj ĵeleeroj en sufiĉaj gustoj, io ajn eblas!

INFORMOJ PRI ROM
----------------
Vi devas posedi fizikan kopion de la kartoĉo de A Boy and
His Blob. Alŝulti ROM-on de videoludo, kiun vi ne posedas,
povas esti pirateco.

    A Boy and His Blob - Trouble on Blobolonia (USA).nes
    MD5: 61D431D155B503C378778062BDA9CF5D
    CRC32: 20A9E4A2

HISTORIO
--------
v1.1  12/03/2022
 - Tradukis subtitolon
 - Korektis "NUL ĴELEEROJ"
 - Aldoni grafikaĵojn

v1.0  19/01/2022
 - Unua eldono

KONTRIBUANTOJ
-------------
Timoteo BORONCZYK/bluephoenix
 - Tradukado, grafikaĵoj, programado

Zerbie HYNSON/Terpomo11
 - Traduka konsultisto

