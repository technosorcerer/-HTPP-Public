David Crane's A Boy and His Blob - Trouble on Blobolonia (NES)
Traducción al Español v2.0 (21/01/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Traducido subtítulo del título.
-Invertido sabor y golosina.
-Añadido espacio detras del texto de vitaminas al usar la vitapistola.
-Traducido "Treasures" "TR" por "Tesoros" "TE".
-Textos mejorados.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
David Crane's A Boy and His Blob - Trouble on Blobolonia (USA).nes
MD5: 61d431d155b503c378778062bda9cf5d
SHA1: 74e43903d7b7a8d6b17e53f2774a4b2d26a2ea9a
CRC32: 20a9e4a2
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.
bluephoenix - Hacking de inversión de "Jellybeans" y punteros de vitaminas.

-- FIN --