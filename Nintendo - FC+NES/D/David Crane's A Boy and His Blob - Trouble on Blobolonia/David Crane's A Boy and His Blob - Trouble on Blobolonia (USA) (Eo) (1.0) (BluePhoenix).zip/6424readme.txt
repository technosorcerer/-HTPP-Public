A Boy and His Blob: Trouble on Blobolonia (NES)
Traduko al Esperanto v1.0 (19/01/2022)
BluePhoenix

INFORMOJ PRI ROM
----------------
A Boy and His Blob - Trouble on Blobolonia (USA).nes
MD5: 61D431D155B503C378778062BDA9CF5D
SHA-1: 74E43903D7B7A8D6B17E53F2774A4B2D26A2EA9A
CRC32: 20A9E4A2

Github: http://github.com/tboronczyk/aboyandhisblob
