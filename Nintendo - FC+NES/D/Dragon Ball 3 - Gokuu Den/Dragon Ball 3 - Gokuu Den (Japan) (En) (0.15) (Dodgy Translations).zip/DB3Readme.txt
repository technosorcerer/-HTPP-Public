  Dodgy Translations
	Proudly Presents

Dragonball 3, Gokuu Den
	v0.15
------------------------

Introduction:
-------------
Another release is apon us, this one is 100% bug free as far as i know about.  i have retranslated everything from scratch.  I have also replaced the crappy font which i stole from FF1 with a better one.  This patch is also made 100% by Dodgy Translations and not corrupted my ExtremeFun Translations (Sorry Mitchy)

Whats Done:
-----------
v0.15 9/12/2k
- The intro text is now inserted.
- About 1/2 of the item named are done.
- Some other stuff...
v0.13 5/11/2k
- New and better font.
- Most of the main menus done.
- Some of the battle dialogue.
- Some other stuff.

Who Did What:
-------------
Aussie, Hacking, Minor Translation
Stix, Minor Translation
Scottie, Minor Translation
SSJ-Mitchy, Made the Tables and Some other Stuff
Pinky, ??? but I know he did something

Who Didn't Do Anything:
-----------------------
Flemo
Dizzy
Struggy
Jules
Renae
Fluffy_Chick

Contacting Info:
----------------
E-Mail: CKSoftware@Hotmail.com
ICQ: 50530395
WWW: http://dodgytrans.darkmazda.com
