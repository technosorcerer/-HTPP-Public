Restores the japanese title screen to the english patch made by Esperknight, Tom and Stardust Crusaders.

2 Files are included in the patch

Megami Tensei Title Screen (Japan).bps -> Meant to be patched with the japanese rom

Megami Tensei Title Screen (Esperknight).bps -> Meant to be patched with the Pre-patched EsperKnight translation rom

Roms to use:
Digital Devil Story - Megami Tensei (Japan)
Database: No-Intro: Nintendo Entertainment System (v. 20210216-231042)
File SHA-1: 67E1E87844AC4E32734937E4EC967DA259C35F4B
File CRC32: F906ACAB
ROM SHA-1: F60102AB3B1470ECFBB7FE31FD9392E6B4BFBFBA
ROM CRC32: 5393D949

Digital Devil Story - Megami Tensei (Japan) + Esperknight English Patch
Database: No-Intro: Nintendo Entertainment System (v. 20210216-231042)
File SHA-1: 0C4FF5EB16A0826A92B6196EE67D8AEA2CB7572B
File CRC32: AC5ACC89
ROM SHA-1: 819CD03A28B422375829B71AE24FF655F22D4420
ROM CRC32: A7B0717E