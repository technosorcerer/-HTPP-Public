

● You can find many more hacks from the same author at this link:
https://www.romhacking.net/?page=hacks&genre=&platform=&game=&category=&perpage=20&order=&dir=&title=&author=crying+onion&hacksearch=Go

● You can also find him on Youtube, showing his work (and that of others) here:
https://www.youtube.com/channel/UCKgNcvTtNkbT2hzIUZPHeuw

● And of course, if you want to follow closely his current projects, you can do it through their twitter account, where he usually share
screenshots, videos, thougts, etc:
@CryingOnion3
                    
                    
                      
                     ████▓██
                  ███▒░░░░░░█
                 ██▒░░░▒▓▓▓▒░█
                ██░░░▒▓█▒▒▒▓▒▓█
               █▓─░▒▒▓█─────▓▓█
               █▒░▒▒▒▒█──▓▓▒▒─▓█
              █▒░▒▒▒▒▓▒─▒▓▒▓▓─▒█
             █▓░▒▒▒▒▒▓░─▓▒──░░▒█
            █░▒▒▒▒▒▒█──▓──░▓███████
           █▒▒▒▒▒▒▒▒▓░─█▓███▓▓▓▓██─█                     ##############################################
          █▓▒▒▒▒▒▒▒▒▓███▓▓████▓▓██──█                    #                                            #
       ███▓▒▒▒▒▓▒▒▒████▒▒░░──████░──██                   #                                            #
      ██▒▒▒▒▒▒▒▒▒▓██▒────────▒██▓────▓█                  #    ::::     SUPER MARIO BROS. 8     ::::   #
      █▒▒▒▒▒▒▒▒▓█▓─────▓───▒░░▓──▓────▓█                 #                                            #
     ██▒▓▒▒▒▒▒█▓──────▒█▓──▓█░▒──▒░────█                 #    ::::           ver.1.0           ::::   #
     ██▒▒▓▓▓▒█▓▓───░──▓██──▓█▓▓▓█▓─────█                 #                                            #
      █▒██▓▓█▒▒▓█─────░█▓──▒░───░█▓────█                 #                                            #
      ██▓───▓▓▒▒▓▓─────░─────────▒▒─░─░█                 ##############################################
       █──▒░─█▒▓█▓──▒───────░─░───█▒──█
       █──░█░░█▓▒──▓██▒░─░─░─░─░░░█▒██
       █▒──▒▒──────▓██████▓─░░░░─▒██
        █──────────░██▓▓▓██▒─░──░█                             	1) Introduction
        ██▒─────░───░██▓▓▓██▓▒▒▓█
         ████▒──░───▒█▓▓▓▓▓████▓                                2) Features list
         ▓██▓██▒──░───▓█████▓███
       ██▓░░░░▓█▓░────░█▒█▒─▒▓█                                 3) Patches and their features
      █▒░░▒▒▒▒▒▓███▓░──▓█▒─▒▓▓█
     █▒░▒████▓██▓▓▓██▒───░▓█▓█                                  4) Acknowledgements
     █▒▒█░─▒───▓█▓▓▓▓▓▓▒▒▓█▓█
     █▒█░───────██▓▓▓▓▓█▓▓█▓██
     █▓▓────────░██▓██▓▓▓▓▓▓▓▓█
     ██░────▓▓────█░─█▓▓▓▓▓▓▓─▒████
     ██░───░──────▓░─▓▓▓▓▓▓▓█─▒█▒░▒█
     █░▓░──▓▓────▒█░─█▓▓▓▓▓▓▓█▒─░░░▒█
    █─▒██─░──────████▓▓▓▓▓▓▓█▓─░▒▒█▓▓█
    █─▓▒▓▒░░────▓█▓▓▓▓▓▓▓▓▓▓█░░▒▓█░──▒█
    █░█▒▒█▒───░▓█▓▓▓▓▓▓▓▓▓▓█▓░▒▓▓──▓█▓█
   █▓▒▓▒▒▓██████▓▓▓▓▓▓▓▓▓▓▓█▒▒▓▓─░█▓▒▒█
   █░▓▓▒▒▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓█▒▒▓─▒█▒▒▒▒█
   █─█▒▒▒▓█▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▒▓─▒█▒▒▒▒█
   █─█▒▒▒▒█▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓█▒▓▒░█▒▒▒░▓█
   █─█▒▓▒▒▓█▓▓▓▓▓▓▓▓▓▓▓▓▓█▓▒▓░▓░░░░▒█
   █─▓▓▓▓▒▓█▓▓▓▓▓▓▓▓█████▓▓▓▓▒▓░░─▒█
   █▒▓▓▓▓▓▒▓████████    ██▓█─▒█▓▒▓█
   █▒█▓▓▓▓▒▓██          ██▒░▓▓▓▒██
    ███▓▓▓██             █░▓▒░░▓█
       ███                ██▓─▒█
                            ███


______________________________________________________________________________________________________________________________________________


1) Introduction


	First of all, thanks for downloading this Hack, which was a suggestion from a subscriber (I hope you enjoy it, Super Buni). In essence
	is a Remake of the pirate cartridge Super Bros. 8 that left so good memories to many in the 90's, when the 'Famiclones' ruled in the
	bazaars.

	The original game, "Don Doko Don 2" was developed by Natsume and published by Taito exclusively in Japan in 1992, in which we play as
	Bob, one of the bearded twins who starred in the 1st part (a Co-op Arcade game very similar to Bubble Bobble that also appeared on the
	Famicom) and who must go through the Kingdom of Marryland to find the ingredients of the potion that will return the Prince (transformed
	into a toad on his wedding day) to his normal state.

	Don Doko Don 2 is a great title, and since the pirates left 99.99% of the game intact, it's no wonder it stood out from other pseudo
	sequels of the plumber. If we add to that the fact that its creators never hid the fact that they were inspired by the adventures of the
	hero of the Mushroom Kingdom (they even added a small Easter Egg in World 2), we have the basis to create a Hack that feels as official
	as possible, or at least, as a Third Party development made with Nintendo's permission.

2) Features list


	Super Mario Bros. 8 Ver. 1.0

		● New ntro and title screen

		● New text font ripped from Super Mario Bros. 3.

		● Using as a base the excellent English translation of Don Doko Don 2 by MrRichard999 and Guyver,
		  I partially redrawn the cinematics and adapted the texts to go along with the Hack theme.

		● Main sprite and 90% of the enemies have been replaced or modified to make the game 'more Mario'.

		● Minor changes to the backgrounds
		
		● By popular demand and thinking that most nostalgics of this cartridge are Spanish-speaking, it also includes
		  a Spanish translation (details in point 3).

		● Some funny cameos and Easter Eggs have been added.


3) Patches and their features


	● SMB8 ENG.ips -------------> Regular version of Super Mario Bros. 8 with English dialogs

	● SMB8 ENG ALT.ips ---------> Alternative titlescreen version of Super Mario Bros. 8 with English dialogs

	● SMB8 ESP.ips -------------> Regular version of Super Mario Bros. 8 with Spanish dialogs

	● SMB8 ESP ALT.ips ---------> Alternative titlescreen version of Super Mario Bros. 8 with Spanish dialogs

	● SMB8 S.B. Edition.ips ----> Special version including a twist as a small tribute to the subscriber who suggested the project


4) Acknowledgements

	● To Super Buni, for proposing this project to me and actively participating with suggestions and a beautiful cover.

	● To Supergamerguy, for his tons of suggestions (many of which have been implemented in the final version).

	● To MrRichard999 and Guyver, for their excellent translation from Japanese.

	● To Sics aka "Ssicosomatic", aka "Terwilf", for their valuable knowledge of romhacking which has allowed to take this project
	  a step further than others I have worked on.

	● And of course, to everyone who has supported me from the Youtube channel, Twitter and the Romhacking community forums.