

● Puedes encontrar más hacks del mismo autor en este link:
https://www.romhacking.net/?page=hacks&genre=&platform=&game=&category=&perpage=20&order=&dir=&title=&author=crying+onion&hacksearch=Go

● También puedes encontrarle en Youtube, mostrando sus trabajos (y los de otros) aquí:
https://www.youtube.com/channel/UCKgNcvTtNkbT2hzIUZPHeuw

● Y por supuesto, si quieres seguir de cerca proyectos en curso puedes hacerlo a través de su cuenta de Twitter, donde suele compartir
capturas de pantalla, videos, pensamientos, etc:
@CryingOnion3
                    
                    
                      
                     ████▓██
                  ███▒░░░░░░█
                 ██▒░░░▒▓▓▓▒░█
                ██░░░▒▓█▒▒▒▓▒▓█
               █▓─░▒▒▓█─────▓▓█
               █▒░▒▒▒▒█──▓▓▒▒─▓█
              █▒░▒▒▒▒▓▒─▒▓▒▓▓─▒█
             █▓░▒▒▒▒▒▓░─▓▒──░░▒█
            █░▒▒▒▒▒▒█──▓──░▓███████
           █▒▒▒▒▒▒▒▒▓░─█▓███▓▓▓▓██─█                     ##############################################
          █▓▒▒▒▒▒▒▒▒▓███▓▓████▓▓██──█                    #                                            #
       ███▓▒▒▒▒▓▒▒▒████▒▒░░──████░──██                   #                                            #
      ██▒▒▒▒▒▒▒▒▒▓██▒────────▒██▓────▓█                  #    ::::     SUPER MARIO BROS. 8     ::::   #
      █▒▒▒▒▒▒▒▒▓█▓─────▓───▒░░▓──▓────▓█                 #                                            #
     ██▒▓▒▒▒▒▒█▓──────▒█▓──▓█░▒──▒░────█                 #    ::::           ver.1.0           ::::   #
     ██▒▒▓▓▓▒█▓▓───░──▓██──▓█▓▓▓█▓─────█                 #                                            #
      █▒██▓▓█▒▒▓█─────░█▓──▒░───░█▓────█                 #                                            #
      ██▓───▓▓▒▒▓▓─────░─────────▒▒─░─░█                 ##############################################
       █──▒░─█▒▓█▓──▒───────░─░───█▒──█
       █──░█░░█▓▒──▓██▒░─░─░─░─░░░█▒██
       █▒──▒▒──────▓██████▓─░░░░─▒██
        █──────────░██▓▓▓██▒─░──░█                             	1) Introducción
        ██▒─────░───░██▓▓▓██▓▒▒▓█
         ████▒──░───▒█▓▓▓▓▓████▓                                2) Lista de cambios
         ▓██▓██▒──░───▓█████▓███
       ██▓░░░░▓█▓░────░█▒█▒─▒▓█                                 3) Parches y sus características
      █▒░░▒▒▒▒▒▓███▓░──▓█▒─▒▓▓█
     █▒░▒████▓██▓▓▓██▒───░▓█▓█                                  4) Agradecimientos
     █▒▒█░─▒───▓█▓▓▓▓▓▓▒▒▓█▓█
     █▒█░───────██▓▓▓▓▓█▓▓█▓██
     █▓▓────────░██▓██▓▓▓▓▓▓▓▓█
     ██░────▓▓────█░─█▓▓▓▓▓▓▓─▒████
     ██░───░──────▓░─▓▓▓▓▓▓▓█─▒█▒░▒█
     █░▓░──▓▓────▒█░─█▓▓▓▓▓▓▓█▒─░░░▒█
    █─▒██─░──────████▓▓▓▓▓▓▓█▓─░▒▒█▓▓█
    █─▓▒▓▒░░────▓█▓▓▓▓▓▓▓▓▓▓█░░▒▓█░──▒█
    █░█▒▒█▒───░▓█▓▓▓▓▓▓▓▓▓▓█▓░▒▓▓──▓█▓█
   █▓▒▓▒▒▓██████▓▓▓▓▓▓▓▓▓▓▓█▒▒▓▓─░█▓▒▒█
   █░▓▓▒▒▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓█▒▒▓─▒█▒▒▒▒█
   █─█▒▒▒▓█▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▒▓─▒█▒▒▒▒█
   █─█▒▒▒▒█▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓█▒▓▒░█▒▒▒░▓█
   █─█▒▓▒▒▓█▓▓▓▓▓▓▓▓▓▓▓▓▓█▓▒▓░▓░░░░▒█
   █─▓▓▓▓▒▓█▓▓▓▓▓▓▓▓█████▓▓▓▓▒▓░░─▒█
   █▒▓▓▓▓▓▒▓████████    ██▓█─▒█▓▒▓█
   █▒█▓▓▓▓▒▓██          ██▒░▓▓▓▒██
    ███▓▓▓██             █░▓▒░░▓█
       ███                ██▓─▒█
                            ███


______________________________________________________________________________________________________________________________________________


1) Introducción


	Antes que nada, gracias por descargar este Hack, que fue una sugerencia de un suscriptor (espero que lo disfrutes, Super Buni) y que
        en esencia es un Remake del cartucho pirata Super Bros. 8 que tan buenos recuerdos dejó a muchos en los 90, cuando las 'Famiclones'
	reinaban en los bazares.

	El juego original, "Don Doko Don 2" fue desarrollado por Natsume y publicado por Taito exclusivamente en Japón en 1992. En él
	encarnamos a Bob, uno de los gemelos barbudos que protagonizaron la 1ª parte (un Arcade cooperativo muy similar a Bubble Bobble que
	también apareció en la consola de Nintendo) y que debe recorrer el Reino de Marryland para encontrar los ingredientes de la poción
	que devolverá al Príncipe (transformado en sapo el día de su boda) a su estado normal.

	Don Doko Don 2 es un título de gran calidad, y como los piratas dejaron intacto el 99,99% del juego, no es de extrañar que sobresaliera
	sobre otras pseudo-secuelas del fontanero. Si a eso añadimos que sus creadores nunca ocultaro inspirarse en las aventuras del héroe del
	Reino Champiñón (incluso añadieron un pequeño Easter Egg en el Mundo 2), tenemos la base para crear un Hack que se sienta lo más oficial
	posible, o por lo menos, como un desarrollo Third Party hecho con permiso de Nintendo.


2) Lista de cambios


	Super Mario Bros. 8 Ver. 1.0

		● Nueva Intro y pantalla de título

		● Nueva fuente de texto extraída directamente de Super Mario Bros. 3

		● Usando como base la excelente traducción al inglés de Don Doko Don 2 de MrRichard999 y Guyver, se han redibujado parcialmente
		  las cinemáticas y adaptado los textos para que vayan acordes con la temática del Hack.

		● El sprite principal y el 90% de los enemigos han sido reemplazados o modificados para hacer el juego 'más Mario'

		● Cambios menores en los fondos
		
		● Por petición popular y pensando que la mayoría de nostálgicos de este cartucho son de habla hispana, se incluye también
		  traducción al español (detalles en el punto 3).

		● Se han añadido algunos cameos divertidos y Huevos de Pascua


3) Parches y sus características


	● SMB8 ENG.ips -------------> Versión regular de Super Mario Bros. 8 con textos en inglés

	● SMB8 ENG ALT.ips ---------> Versión con pantalla de título alternativa de Super Mario Bros. 8 con textos en inglés

	● SMB8 ESP.ips -------------> Versión regular de Super Mario Bros. 8 con textos en español

	● SMB8 ESP ALT.ips ---------> Versión con pantalla de título alternativa de Super Mario Bros. 8 con textos en español

	● SMB8 S.B. Edition.ips ----> Versión especial que incluye un giro como pequeño homenaje al suscriptor que sugirió el proyecto


4) Agradecimientos

	● A Super Buni, por proponerme este proyecto y haber participado activamente con sugerencias y una preciosa portada

	● A Supergamerguy, por sus toneladas de sugerencias (muchas de las cuales se han implementado en la versión final)

	● A MrRichard999 y Guyver, por su excelente traducción del japonés

	● A Sics alias "Ssicosomatic", alias "Terwilf", por sus valiosos conocimientos de hackeo de roms que han permitido llevar este proyecto
	  un paso más allá de otros en los que he trabajado

	● Y por supuesto, a todos los que me han apoyado desde el canal de Youtube, Twitter y los foros de la comunidad Romhacking