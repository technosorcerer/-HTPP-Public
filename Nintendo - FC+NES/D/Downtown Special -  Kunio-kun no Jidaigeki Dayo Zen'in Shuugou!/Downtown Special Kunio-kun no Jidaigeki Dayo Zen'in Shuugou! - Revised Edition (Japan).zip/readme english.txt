Kunio-kun's historical drama (revised edition)
A version that adds special moves to the enemy boss.

★List of additional special moves

Ginpachi: Makahikku/Jibungyorai
Gonsaku: My own dream
Tamekichi: Makha Punchi
Kinsuke: Makhakikku
Heishichi: Makhataki
Jinroku: Makha Punch II/Maha Kiku
Hiroshiro: My Own Gyorai/Mahafumi Fumi
Nizaemon: Mahaswing
Tsurumatsu: Makhakku II/Zutsuki Special
Jukichi: Makhakki, Makhatataki, High Guard, Senpuukyaku, Sukuryu II, Dosu Special
Asajiro: Makha Punch, Makha Kikku, Makha Tataki, Makhaswing, Makha Fumifumi
・Sukuryu・Nitoro Attack・High Guard・Maha Punch II・Maha Kick II
・Zutsuki Special ・Harute Special ・Mahakiukiu ・Warp Shoot