"Dragon Buster"
Traducci�n al Espa�ol Ver. 1.0 (13/12/2019)
por Max1323 (maxmuruchi@gmail.com)
---------------------------------------------------
Descripci�n:
Dragon Buster es un juego de rol de acci�n de plataformas y mazmorras que fue desarrollado por Namco y lanzado en 1985.
El juego presentaba un juego de plataformas de desplazamiento lateral y un mapa del mundo similar a los juegos de plataformas posteriores para consolas dom�sticas y computadoras personales. Dragon Buster tambi�n fue el primer juego en presentar una mec�nica de doble salto, y uno de los primeros en usar un medidor de salud visual.

Desarrollado: Namco/TOSE
Publicado:    Namco
Lanzamiento:  07/01/1987 (JAP)
---------------------------------------------------
Acerca del proyecto:
Se tradujo los textos.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS

Dragon Buster (J).nes
File Size     160 KB
File MD5      8C7B69FC538532D70148C100EB24E45D        
File SHA-1    58C1248788E202D576C1DCA5F15E5B5C756E9B04
File CRC32    ABB83B0F                                

