One day I saw a random comment by someone on the internet, saying how every bad hack is just a dick ejaculating swastikas at minorities.

I thought the comment was so funny, I decided to make it a reality!


Patch to a Defender II (USA).nes rom and protect your bananas!