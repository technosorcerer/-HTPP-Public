Darkman
Traducci�n al Espa�ol v1.0 (10/01/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Darkman
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Darkman
-----------------
Plataformas basado en la pelicula, con unas fisicas estilo robocop 2, probablemente usa el mismo motor.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Darkman (U) [!].nes
262.160	bytes
CRC32: 5438a0ac
MD5: fc51c0aa5e3283bed572de31ac5985b5
SHA1: 21b4a65356b54815153303f14832bf5b1b8d3b83

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --