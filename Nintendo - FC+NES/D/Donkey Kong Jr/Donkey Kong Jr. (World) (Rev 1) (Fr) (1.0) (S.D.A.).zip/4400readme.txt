DONKEY KONG JR. (FR)

Une traduction compl�te de "Donkey Kong Jr." pour la NES en langue fran�aise, au format ips.
Cliquez sur le fichier ips, puis s�lectionnez la ROM du jeu et vous y ajouterez des correctifs.
Prendre plaisir!

-S.D.A.