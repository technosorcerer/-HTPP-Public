Destiny of an Emperor- Yuan Shao's Revenge v2.0
	http://www.lordyuanshu.com/forums/profile/midknight
*********************************************************

This patch kit will convert a stock version of Destiny of an Emperor to 
Destiny of an Emperor-Yuan Shao's Revenge v2.0  Here's exactly what it
intends to accomplish.

- The setting takes place between the Yellow Turban rebellion and the timeframe of the Cao Cao vs Yuan Shao war (200 AD).

Enhancements included are:

- Iron Ore / Treasure Chest Bug Fix
- Portrait Expansion Code
- Sprite Expansion Code
- Pre-loaded sprite bank(s)
- 8 tactics
- Agility on status page
- Critical hit formula changes (subtle increase in number of critical hits)
- Agility Based Multi-attacks
- Modified soldier bars to support more troops
- 25 soldier gain level up patterns
- Modified TP gains at level-up
- Change food usage (subtle decrease in amount of food used)
- DoaE2 like damage
- New Chapters
- "Life" and "Raise" tactics
- Tactic slots and order changed to support 8 tactics, life, and raise.
- Smoke pot lasts twice as long
- DOAE Artificial Intelligence Enhancements
- "Duel" Tactic (replaces Shui Jian)
- "Charge" Tactic (replaces Cheng Nei)
- "Protect" Tactic (combines Wuo Jian, Shui Jian, and Cheng Nei)
- Enhanced "An Sha" tactic
- Level/soldier based damage for tactics
- Guard tactic only defends against physical attacks
- "Defend" halves physical and tactic damage and gains TP
- There is no tactician. Each officer uses their own tactics.

- Some weapon and armor name changes. The final swords have some "ROTK" type names.

- Some cities changed to better represent Yuan Shao's story. Example: Xu Zhou is now "Ye". Zhang Jue, Dong Zhuo, and Yuan Shu are the *only* final bosses that are the same as the original DoaE. After that it's all different.

- Almost every general has a unique portrait. Many new sprites include as well.

- When invading Cao Cao's land, there is a re-creation of the battle of Guandu. Same enemy generals, etc... That is the turning point in the war...if you lose you re-create history, if you win...

- Battles somewhat re-created:

http://en.wikipedia.org/wiki/Yellow_Turban_Rebellion
http://en.wikipedia.org/wiki/Campaign_against_Dong_Zhuo
http://en.wikipedia.org/wiki/Battle_of_Yangcheng
http://en.wikipedia.org/wiki/Battle_of_Jieqiao
http://en.wikipedia.org/wiki/Battle_of_Yijing
http://en.wikipedia.org/wiki/Battle_of_Xiangyang_%28191%29
http://en.wikipedia.org/wiki/Battle_of_Guandu

Mixed with some historical and fictional stuff to keep the story going.

- Difficulty is higher than the original DoaE but not impossible.

- Yuan Shao sits on the fancy chair with his sprite instead of Liu Bei's.

- Yan Liang and Wen Chou no longer leave your party and are billetable (they are in the Guan Yu and Zhang Fei roles)

- Most generals have soldier growths. You may have some tough party decisions.

- Some game events have been changed so if you're a DoaE vet there may be some minor surprises.

Tactic Names for the Yuan Shao mod:

Fire Tactics:

Flame (targets one enemy)
Blaze (targets all enemies)
Powder (targets one enemy)

Water Tactics:

Flood (targets all enemies)
Torrent (targets one enemy)
Tsunami (targets all enemies)

Arrow (Agility Based) Tactics:

Arrows (targets all enemies)
X-Bows (targets all enemies)

Strength Based Tactics:

Boulder (targets one enemy)
Catapult (targets one enemy)
Ambush (targets one enemy)
Charge (critical hit)

Heal Tactics:

Heal (targets one ally)
Salve (stronger heal that targets one ally)
Recover (targets all allies)
Revive (targets one ally)
Miracle (targets all allies)

Life (revives one ally with "Salve")
Raise (revives one ally with "Revive")

Defensive Tactics:

Protect - Cut damage for fire and water tactics, also adds Cheng Nei status
Guard - Cuts physical damage in half
Evade - Avoids physical damage
Thwart - Avoids tactic damage
Negate - Counter enemy strategies

* Protect and Guard are mutually exclusive. Only one is active at a time. Protect or Guard will fail if Evade or Thwart is active.
** Evade and Thwart are mutually exclusive. Only one is active at a time.

Support Tactics:

Haste - Increase agility for one ally
Rally - Boost attack power for all allies

Offensive Non-Damage Tactics:

Duel - Challenge opposing officer to a duel (STR based)
Remove - Remove an enemy from battle (INT based)
Doubt - Stop one enemy from moving
Mislead - Make an enemy attack their allies

Special thanks to...
*********************************************************
- Meteorstrike and ludmeister for new DOAE ROM hacking discoveries. 
Without which a lot of the changes in this mod would not have
been possible.  
- Niahak for making "Destiny of an Editor" without which this mod
and other DOAE mods would not be possible.
- Members of the lordyuanshu.com and kongming.net message boards
for testing and advice.  

To convert your Destiny of an Emperor ROM:
*********************************************************

The following applies this and all future releases of Yuan Shao's Revenge:

0. First of all, you will need to obtain a clean NES ROM of Destiny of an Emperor 
   (Destiny of an Emperor (U).nes). You are on your own for this step, as it is 
   illegal to provide ROMs of copyrighted material. There are sites that do provide 
   this ROM though, and you should be able to obtain it.

1. When you get it, make a backup of it if you would want to play the stock version, 
   play another mod, or, in case I post an updated version of the mod here... I am not 
   going to make version 1.0 to "version whatever" patches for my mods, for instance.
   
2. Download the Yuan Shao's Revenge mod.
  
3. Use the IPS patching program of your choice to apply the .ips patch to the 
   correct ROM.  As I use Lunar IPS to create my patches, I recommend using 
   this program to patch your ROM. --> http://www.romhacking.net/utilities/240/
	    
4. This mod is expanded and the graphics only seem to work with FCE Ultra.  To
   download FCE Ultra go to: http://fceultra.sourceforge.net/download.php

