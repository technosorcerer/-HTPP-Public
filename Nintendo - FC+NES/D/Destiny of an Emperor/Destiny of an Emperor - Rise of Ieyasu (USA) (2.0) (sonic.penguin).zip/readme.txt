
Hi, and thanks for downloading...
DESTINY OF AN EMPEROR RISE OF IEYASU 2.0 by sonic.penguin

Use FCE Ultra Emulator 2.1.5 or above for best mod compatibility

The original DOAE and other associated DOAE mods can be found at the Lord Yuan Shu forums and at Kongming.net

Contact: You can possibly get in touch with me at lordyuanshu.com/forums or the-scholars.com/forums
---------------------------------------

Synopsis: Follow the story of the Japanese hero Tokugawa Ieyasu in his journery to establish a peaceful rule and end the senseless wars that have constantly plagued the land.  Experience an entirely new game! It has taken thousands of hours of learning, creativity, and modding to create this game, so enjoy!
---------------------------------------


Game changes in Rise of Ieyasu 2.0

New Portraits
New Sprites
New Unique Officer classes
New Tactics and Tactic Types
Typo Fixes
Game Balancing Updates
Money System Overhaul
Additional Map Edits/Fixes


Game changes in Rise of Ieyasu

1. Entirely new story that takes place during the Sengoku period of Japan.  An entirely new officer roster!

2. Increased difficulty for all battles and major boss battles. Keep in mind that having multiple types of strategists will ensure that you gain the most TP by the end of the game.

3. Entirely new portraits for about 98.27% of the game. I hope you particularly enjoy this as it took a lot of time... now in MULTI COLOR!

4. New sprites courtesy of MidKnight and labeling of the sprites via Destiny of an Editor courtesy of Lord Yuan Shu.

5. New "resurrect" type tactics + enhanced 8 tactic system code courtesy of MidKnighT and Ludmeister.

6. Agility based attacks and multi-attack item programming courtesy of Ludmeister.

7. Faster/cleaner dialogue after battles, in menus, and when dealing with merchants to eliminate extra keystrokes.

8. Brand new tactic effects, names, and super-tactics.

9.  New intro screens, biographies, and more.

10. Changed menus to accommodate new tactics.

11. Bonus section of the game.... the Path of Heaven summons you...

---------------------------------------

Please let me know if you encounter wrong names or misspellings (ie: Charlie Sheen instead of Ieyasu) or if there are any impassible areas/strange warps due to map changes.

***Special Thanks to Niahak's Tools which make mods like this possible with A LOT more ease and all the helpful people from the LordYuanshu.com forums! (shameless plug)***

Thanks for reading, and enjoy Rise of Ieyasu!
Regards, sonic.penguin
