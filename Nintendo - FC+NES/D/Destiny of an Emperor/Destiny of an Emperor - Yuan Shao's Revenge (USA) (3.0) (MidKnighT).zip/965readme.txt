Destiny of an Emperor: Yuan Shao's Revenge Version 3.0 | RELEASE NOTES

Filename: YuanShao_DoaE.ips
Version: 3.04
Date: August 29th 2022

Gameplay information and hints can be found at:
http://doaerhguide.wikidot.com/yuan-shao-s-revenge

To convert your Destiny of an Emperor ROM:

The following applies this and all future releases of the Ludmeister's Remix Destiny 
of an Emperor mod.

0. First of all, you will need to obtain a clean NES ROM of Destiny of an Emperor. 
   You are on your own for this step. There are sites that do provide this ROM 
   though, and you should be able to obtain it.

1. When you get it, make a backup of it if you would want to play the stock version, 
   play another mod, or, in case I post an updated version of the mod here... 
   
2. Download the Yuan Shao's Revenge 3.0 mod IPS patch.
  
3. Use the IPS patching program of your choice to apply the .ips patch to the 
   correct ROM.  I use Lunar IPS (https://www.romhacking.net/utilities/240/) to
   create my patches, I recommend using this program to patch your ROM.	   

------------------------------------------------------------

Changelog for Version 3.04:

- TP resets of PLAN with TP near TP max
- Text about Cui Zhou Ping's house (west of Nan Yang)

------------------------------------------------------------

Changelog for Version 3.03:

- Fix Bao Zhou warp (Cao Cao 1st battle town)
- Fixed cast Ambush then Haste and your own party gets attacked
- Fixed plan with low TP resets TP to 254
- Add Food Store in Bao Zhou and remove chariots from Chapter 8 drops
- Minor updates
------------------------------------------------------------

Changelog for Version 3.02:

- Fixed Sun Ce Battle (belogns in chapter 6)
- Yuan Shu invite bug
- Party death / wrong location issues
- Minor updates

------------------------------------------------------------

Changelog for Version 3.01:

- Removed extra chapter 8 battle after Ma Teng battle.
- Fixed Luo Yang warp if you haven't won the battle yet.
- Fixed room in Fu Shui castle.
- Gave Eunuchs Doubt back (they were supposed to have it) 

------------------------------------------------------------

NOTES:

This ROM uses a rare mapper to make it 1MB in size. For that reason only certain emulators will work.

Tested and Working Emulators:

* FCEUX �> http://fceux.com/web/download.html - must be at least version 2.2.3 but 2.4.0 is recommended.
* Nostalgia NES (Android)
* NES.emu (Android)

Also have mainly tested with save slot 1. Do not recommend using save slot 2. If you need more save slots use save states in your emulator.

------------------------------------------------------------

ROM TEAM: 

MiDKnighT - Original ROM Design, Characters, Battles, Tactics, etc...
Boneduke - Map design including world map, caves, and towns.
Cao Zhang - Lead tester
Ludmeister for additional ROM enhancements like agility based attacks, item drops, etc�
Sonic Penguin for portraits and sprites
Phaxuji, Boneduke, Ludmeister, and Lordyuanshu for play testing.

------------------------------------------------------------

CONTACT

Please share your feedback, it is much appreciated! Also please report any bugs or other issues and I will do my best to fix them. I can be reached on the following sites:

Destiny of an Emperor Mods Facebook page: https://www.facebook.com/Destiny-of-an-Emperor-Mods-317883821595523/
Lordyuanshu.com: http://www.lordyuanshu.com/forums/topic/yuan-shaos-revenge-mod

Thanks,
MiDKnighT and Team
