Destiny of an Emperor- Ludmeister's Remix v1.1
	http://jeffludwig.com/
*********************************************************

This patch kit will convert a stock version of Destiny of an Emperor to 
Destiny of an Emperor-Ludmeister's Remix v1.1.  Here's exactly what this 
will accomplish:


This mod aims to improve the gameplay of Destiny of an Emperor. Battles are 
designed to be more decisive, tipping in favor of the more powerful/smarter 
army much faster. Tactician heavy armies are designed to be more viable over 
a long march. Difficulty is increased slightly to moderately.



Notice, effective March 1st, 2012 
******************************************************************************

	For this release and all new releases, I am discontinuing the use of 
	IPS2EXE to create patches that can be applied without an IPS patching 
	program.  These executable patches set off certain virus and malware 
	scanners.  


	
Version 1.1 Changelog
*********************************************************

  * Edited the tactic's learning order and priorities.  This makes endgame
    battles much more interesting as any tactician having 210+ Intelligence 
	features useful tactics that provide viable attack strategies (though
	higher Intelligence generally yields more surefire strategies).
	
	

Version 1.0 Changelog
*********************************************************

  * A general's status screen shows their AGI, and not T.P. If you want to 
    know if they can be a tactician, they will have Tactics listed (after 
	Level 1, of course).
    
  * Soldier graphs in battle are improved (Full length of green bar depicts 
    about 64000 soldiers).
    
  * The palette for Character sprites have been tweaked slightly. I'm not a
    fan of pink.
	
  * All tactics have been given an English name. I wouldn't call them 
    "translations" because I don't know Chinese... I merely described the 
	tactic in English. In addition, the names of several weapons and armors
	have been edited.
    
  * Item disappearing bug is fixed.
    
  * Many more generals gain soldiers at army level up. Many Generals have 
    different stats.
    
  * Liu Bei can recruit Yuan Shao during chapter 4 (where Zhou Cang was 
    recruited). Zhou Cang is recruited at Luo Yang, in place of Wang Gui. 
	Yuan Shang is the nemesis for Chapter 4. Doesn't make sense... I know.
	
  * Can recruit Lu Meng after fighting Sun Quan, and Zhang He after defeating
    Cao Pei at Ru Nan.
	
  * Unbilletable generals Zhuge Liang, Lu Bu, Zhang Bao, and Guan Xing are now 
    billetable.
    
  * Food is consumed a bit slower now (x/1600, min. 1)
    
  * All Items (excepting elixirs) cost more.
    
  * Attack damage is much more randomized. Critical hits are more devastating.
  
  * Power of Weapons/Armor/Tactics are heavily modified. Water tactic #2 attacks
    whole party.
    
  * Gain 5-8 TP per level. TP cost for most tactics reduced. Regularly using 
    Tactics is a viable strategy now, and sometimes essential!
    
  * Attack damage calculation is heavily modified. Specifically, the size of an 
    officer's army is much more important in determining casualties inflicted. 
	Before, a general's effective Strength was determined by calculating: 
	
		Strength * (digits(army size) ^ 2). 
	  
	In other words, if a 250 STR general with 500 soldiers attacked, his effective
	Strength would have been 2250 (250 * 9). Ludmeister's Remix calculates the
	Strength multiplier differently, based on a stair-step approach, as shown below.


		Army size (soldiers)	Strength multiplier (x = army size)
		1 to 255					(x / 32) + 1
		256 to 2047					(x / 128) + 7
		2048 to	8191				(x / 256) + 15
		8192 to	max					(x / 1024) + 37
		
	Hence, when outnumbered, using brute force will likely result in the good guys
	getting routed. At times like that, Intellect and the correct tactics will be
	very important to victory.


To convert your Destiny of an Emperor ROM:
*********************************************************

The following applies this and all future releases of the Ludmeister's Remix Destiny of an Emperor mod.

0. First of all, you will need to obtain a clean NES ROM of Destiny of an Emperor. 
   You are on your own for this step, as it is illegal to provide ROMs of copyrighted
   material. There are sites that do provide this ROM though, and you should be able
   to obtain it.

1. When you get it, make a backup of it if you would want to play the stock version, 
   play another mod, or, in case I post an updated version of the mod here... I am not 
   going to make version 1.0 to "version whatever" patches for my mods, for instance.
   
2. Download the Ludmeister's Remix mod.
  
3. Use the IPS patching program of your choice to apply the .ips patch to the 
   correct ROM.  As I use IPS XP (http://home.arcor.de/minako.aino/ipsXP/) to
   create my patches, I recommend using this program to patch your ROM.
	    
4. I hope you enjoy it!

