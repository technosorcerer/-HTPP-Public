Double Dragon III - Difficulty Fix
Platform: NES
2007.5.18 Quest Games
V1.0 / 1.1

Table of Contents
-----------------
1. About Double Dragon III
2. Hack Details
3. Patch History
4. Known Issues
5. IPS File
-----------------

1. ABOUT

Double Dragon III is notorious for giving the player only 1 life & not being easy. The player can earn more fighters & 1 continue after Mission 3. The Japanese version is somewhat less demanding by allotting the player more health. This hack aims to make the game more forgiving, yet at the same time more challenging.

2. HACK DETAILS

-player is given 5 continues on start (no continues are deducted on Mission 1)
-players are allotted more health & weapons
-enemies' health have been increased (for the most part)
-typos are fixed
-Jimmy is available during a 1 player game
-weapons stay around after enemies die
-final boss' health was reduced marginally (255? Yeesh!)

3. PATCH HISTORY

1.1: reverts the music back to its original state (the sound channels were modified in the first patch)

4. KNOWN ISSUES

Trying this out on a physical NES (via PowerPak) I noticed that wall-jumpkicking doesn't work. I haven't had this issue with any emulator yet.

5. IPS FILE

Apply the IPS file to 'Double Dragon III: The Sacred Stones (U)'