This is a hack of Double Dragon III.  If you got the patch version of this, apply the patch to the US version of Double Dragon III.

  It's the glorious return of Le Poulet!  This game shall now also be known as Pussy City Gaiden, both names are acceptable, but I will be calling it Tranny Tramps.  The theme is transformation.  Go figure.  Its the daring quest of 2 transvestites, 1 she-male, and 1 previously-female male, as they travel the world in hopes of being made biologically women.  In what I think is a ROM-hack first (anyone know different?), this hack has its own instruction manual.  I actually took scans of the Double Dragon III manual and transformed them to my own twisted ends.  If you dont have the manual you ought to go look for it, it really adds to the experience.  

  A word of caution while playing Tranny Tramps - some areas have new time limits.  If you stand around in the massage parlor for about 7-8 minutes the game will end in a most un-kind way.  Same thing for all areas in China.  In Italy (excluding the boss fight with Cockules), you only have about 3.5 minutes.

 As you'll quickly realize, the game has a new brain-damaged soundtrack.  If you like that sort of thing, I am also selling the soundtrack for $7 + postage.  Write Jomb at nnnmmm1134@yahoo.com if interested.  The CD contains bonus material.  See the ad in back of the instruction manual for a better description (with photos).




Timeline of Jomb & The Electric Womb:

Pre-1999
________
   Various game fragments, none of them playable.  A bunch of half-baked ideas.

1999
____
   Pussy City Pimps (the popular hack)
   Work begins on Worlds Of War

2000-2004
_________
   Sent to the gulag.  Pen and paper version of Night Walkers is made, is popular with the POWs.  3000+ pages of game designs written, covering 8 unique games.

2005
____
   Little Remo - The Child Abuser (the psychologist pay-back hack)
   work resumes on Worlds Of War

2006
____
   The Lone Rapist (the pubic hack)
   Tranny Tramps - The Family Jewels (the testicular hack)