Double Dragon III - The Sacred Stones (NES)
Traducci�n al Espa�ol v1.0 (17/08/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Double Dragon III - The Sacred Stones (U) [!].nes
262.160 bytes
MD5: a5484da6feadc9c8fdb2b1a8edf97ee2
SHA1: 18ecc9cad3b1c36653867ea02a8465f2046aa459
CRC32: 7a6e0454

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --