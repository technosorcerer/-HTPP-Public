--------------------------Info---------------------------
Game name: Double Dragon III - The Sacred Stones
Console: Nintendo entertainment system
Game region USA: (U)
Patcher: Cheat Patcher v1.2 or higher.
----------------------------------------------------------
--------------------------patch------------------------
The patch allows to set following parametres:
 
 Unlock Jimmy (single mode).
 Unlock Chin.
 Unlock Yagyu.
 Billy & Jimmy lives.
 Billy, Jimmy & Chin weapon.
 Chin lives.
 Yagyu lives.
 Yagyu weapon.
 Continues.
 Decrease enemies lives.
 Jump on the start button.
 Game intro disabled.
 Game story disabled.

--------------------Cheat Patcher------------------
Download link:
http://www.romhacking.net/utilities/1112/
----------------------------------------------------------
Authors by: tog, infval, Jedi QuestMaster, Mr2.
e-mail: fsocp@land.ru
http://rgcorp.ucoz.net/