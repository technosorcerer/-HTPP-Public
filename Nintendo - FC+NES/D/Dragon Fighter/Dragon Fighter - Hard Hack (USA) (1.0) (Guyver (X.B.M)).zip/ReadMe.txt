The hard mode hack of the game Dragon Fighter. The Enemies grow stronger. At the beginning of the game the hero is filled with scale transformation into a dragon. Scale of the dragon does not decrease. The player has 24 lifebars in the first level.

ROM / ISO Information:
Original ROM: Dragon Fighter (U) [!].nes
MD5: 5f2ac5597c45d368079d80caf863e742

My NES hacks: http://famicom.byethost7.com