      
            Donkey Kong Contry NES EDITION V 1.0 / hack by The Jabu  2025
        ---------------------------------------------------------------------
   
         To celebrate DKC's 30th anniversary (a little late, I know), here's a hack
    for the bootleg version (DKC4) of the NES. This hack improves the gameplay so it
    feels more like the original. It also includes new sprites, better music, changes
    to the levels and color palettes, and more. 
                 
        


    Changes:

        - Improved controls for Dk and Diddy.

   	- New sprites for Dk ,Diddy and enemies.

        - Improved music.

        - Changes to levels and palettes.

        - Ending screen added.

        



    

  


  Apply the IPS file to "Donkey Kong Country 4 (Unl) [!].nes" and have fun!!!
