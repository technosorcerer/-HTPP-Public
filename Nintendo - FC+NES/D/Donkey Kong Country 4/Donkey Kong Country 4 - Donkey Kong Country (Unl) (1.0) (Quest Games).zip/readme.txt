Donkey Kong Country 4 -> Donkey Kong Country
Platform: Famicom/NES
2011.5.23 Quest Games
V1.0

Table of Contents
-----------------
1. About Donkey Kong 4
2. Hack Details
3. Patch History
4. Known Issues
5. IPS File
-----------------

1. ABOUT

That is not a typo; Donkey Kong Country has been "ported" to the Famicom in 1997 by a pirate company known as "Hummer Team."  It was erroneously renamed to 'Donkey Kong Country 4' or sometimes titled 'Donkey Kong 4.'  The game also includes 'Jungle Book 2' which is just Donkey Kong Country with Mowgli in place of Donkey Kong & Diddy.

2. HACK DETAILS

DKC:
 -all known instances of the number '4' have been removed from the title
 -number of lives have been reduced from 30 to 7.
Jungle Book 2:
 -barrels have been changed to read 'M' instead of 'DK'
 -letters to collect in Jungle Book 2 spell out 'BEAR' instead of 'KONG'
Both:
 -a 'bug' on the map screen is fixed to display the last few stages correctly

3. PATCH HISTORY

Complete! Hopefully.

4. KNOWN ISSUES

None

5. IPS FILE

Apply the IPS file to 'Donkey Kong Country 4 (Unl) [!]'