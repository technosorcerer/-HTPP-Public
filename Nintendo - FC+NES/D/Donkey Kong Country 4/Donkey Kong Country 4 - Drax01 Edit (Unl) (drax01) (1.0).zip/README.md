# Donkey-Kong-Country-Drax01-Edit
Mejoras implementadas de Donkey Kong Country 4 del bootleg de Hummer Team 

Se toma de base el hack del usuario "Ti_" y los sprites de Donkey y Diddy Kong del hack del usuario "The Jabu" para hacer un nuevo hack donde realizo un toque personal de las pantallas de "Titulo" y la pantalla "Game Over".

"Ti_"
Donkey Kong Country 4 Improvement VRC7 music
https://www.romhacking.net/hacks/8924/

"The Jabu"
https://www.romhacking.net/hacks/8914/
