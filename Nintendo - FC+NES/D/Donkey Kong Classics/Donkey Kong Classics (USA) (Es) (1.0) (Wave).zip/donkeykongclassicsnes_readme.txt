Donkey Kong Classics (NES)
Traducci�n al Espa�ol v1.0 (12/03/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Donkey Kong Classics (U) [!].nes
MD5: 074fea160b7ec513bdaf2c0bb042c262
SHA1: 8ad359b48f1a9cde36bd682d0776dedae1bbbc89
CRC32: 17ec0cc7
49.168 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --