DONKEY KONG CLASSICS (FR)

"Donkey Kong Classics" pour la NES traduit en fran�ais au format ips.
Pour patcher, cliquez sur le fichier ips (il vous dira quel fichier vous voulez utiliser) et cliquez sur la ROM susmentionn�e. Apr�s cela, ex�cutez la ROM corrig�e dans un �mulateur Famicom.

-S.D.A.