Dragon Ball Z III: Ressen Jinzou Ningen [HP+]
-------------------------------------------


A) Info:
1) By using this ROM Hack, bosses have more HP than before for Freeza, Cooler (Transform), Androids 19, 18, 17, and 16.
2) And thanks to YouTuber, 'zack86735', both Vegeta and Trunks are now fully playable.


B) Emulator compatibility:
You have to test it yourself. VirtualNES will not work. To be safe, use FCEUX.


C) 2 patches were provided:
1) Dragon Ball Z III - Ressen Jinzou Ningen (J) [HP+].ips
2) Dragon Ball Z III - Killer Androids [HP+] [En by Twilight v1.0].ips


D) How to patch:
Use Lunar IPS and choose one of the ips file to patch it with the original ROM.
Database match: Dragon Ball Z III - Ressen Jinzou Ningen (Japan)
Database: No-Intro: Nintendo Entertainment System (v. 20210216-231042)
File SHA-1: 10918010E3C886E56398E93BD19E1E619A51F8AA
File CRC32: A69079D4
ROM SHA-1: B4AADED46AE0C09DA687BA9D22A137E7B3BC1682
ROM CRC32: DC52BF0C


E) Software needed:
1) Lunar IPS
2) Compatible NES Emulator
3) Software that can extract 'zip' extension file (e.g. Peazip, WinRAR, WinZip, etc)


F) Software involved:
1) https://www.rapidtables.com/calc/math/hex-calculator.html
2) FCEUX Emulator
3) HxD
4) Lunar IPS
5) Peazip


G) ROM hack findings:
a) Playable Vegeta & Trunks
Offset (Hex)		: C3DC
Original 		: F00A C903 F008 C90A F004 9016
Edited	 		: F00A C90C F008 C92C F004 9016

b) Z warriors HP	: Goku, Piccolo, Vegeta, Gohan, Krillin, Yamcha, Tien, Chaozu, Trunks
Offset (Hex) Start	: E718
Little endian
22 01 40 01 54 01 68 01 86 01 A4 01 C2 01 E0 01 08 02 30 02 58 02 7B 02 A8 02 DA 02 02 03 34 03 66 03 9D 03 D1 03 E7 03 F6 00 0B 01 20 01 35 01 4A 01 65 01 7F 01 9A 01 B4 01 CF 01 EA 01 03 02 1C 02 3D 02 58 02 7A 02 8A 02 B6 02 C6 02 DA 02 C2 01 D6 01 E0 01 EA 01 F4 01 08 02 1C 02 30 02 44 02 58 02 6C 02 80 02 94 02 A8 02 BC 02 DA 02 EE 02 0C 03 2A 03 52 03 F5 00 0B 01 21 01 37 01 4D 01 69 01 84 01 A0 01 BB 01 DB 01 FE 01 21 02 46 02 6A 02 91 02 BB 02 E1 02 0A 03 32 03 52 03 EE 00 02 01 16 01 28 01 3E 01 57 01 70 01 89 01 A2 01 BD 01 D6 01 F0 01 0E 02 25 02 44 02 56 02 63 02 80 02 9C 02 B8 02 EA 00 FE 00 13 01 27 01 3C 01 56 01 71 01 8B 01 A6 01 C2 01 DB 01 F5 01 14 02 29 02 47 02 5A 02 6A 02 88 02 9E 02 BC 02 F6 00 09 01 1B 01 2E 01 40 01 63 01 72 01 8B 01 A4 01 C2 01 DB 01 F5 01 15 02 2A 02 49 02 5D 02 6F 02 8C 02 AF 02 C5 02 DA 00 EE 00 01 01 15 01 28 01 3F 01 55 01 6C 01 82 01 9A 01 B8 01 CC 01 ED 01 0B 02 22 02 3D 02 4F 02 65 02 7F 02 B7 02 02 01 14 01 2C 01 41 01 5B 01 6F 01 8B 01 B1 01 C8 01 E6 01 01 02 22 02 3D 02 57 02 8A 02 B2 02 EE 02 FD 02 16 03 4D 03
Offset (Hex) End	: E87F

c) Z warriors KI	: Goku, Piccolo, Vegeta, Gohan, Krillin, Yamcha, Tien, Chaozu, Trunks
Offset (Hex) Start	: E89A
Little endian
68 01 7C 01 90 01 A4 01 B8 01 CC 01 E0 01 EF 01 08 02 1C 02 30 02 44 02 58 02 6C 02 80 02 94 02 A8 02 BC 02 D5 02 EE 02 18 01 2C 01 40 01 86 01 9A 01 AE 01 C2 01 D6 01 EA 01 F9 01 1C 02 3F 02 53 02 67 02 7B 02 8F 02 A3 02 B7 02 CB 02 DF 02 13 01 27 01 40 01 81 01 9A 01 A9 01 BD 01 D1 01 EF 01 FE 01 12 02 21 02 35 02 58 02 71 02 85 02 A8 02 BC 02 CB 02 0C 03 0E 01 22 01 36 01 7C 01 90 01 A4 01 B8 01 CC 01 E0 01 F4 01 08 02 1C 02 30 02 44 02 5D 02 76 02 8F 02 A8 02 C1 02 DF 02 18 01 2C 01 40 01 86 01 9A 01 AE 01 C2 01 D6 01 EA 01 F4 01 03 02 1C 02 30 02 49 02 5D 02 76 02 8A 02 A8 02 B7 02 CB 02 0E 01 22 01 36 01 7C 01 90 01 A4 01 B8 01 CC 01 E0 01 F4 01 F9 01 17 02 2B 02 3F 02 53 02 6C 02 7B 02 9E 02 A8 02 BC 02 13 01 27 01 3B 01 81 01 90 01 A9 01 BD 01 D1 01 E5 01 F4 01 FE 01 17 02 2B 02 44 02 58 02 71 02 85 02 A3 02 B2 02 C6 02 FA 00 0E 01 27 01 3B 01 77 01 90 01 A4 01 BD 01 CC 01 E0 01 F4 01 F9 01 17 02 26 02 3A 02 4E 02 67 02 76 02 99 02 B7 02 0E 01 22 01 3B 01 7C 01 95 01 A9 01 B8 01 CC 01 E5 01 F9 01 12 02 26 02 30 02 58 02 6C 02 85 02 A8 02 BC 02 CB 02 E9 02
Offset (Hex) End	: EA01

d) Boss enemies HP	: Mecha Frieza, Frieza, Cooler, Cooler (Transform), Salza, Dore, Neiz, Cell, Android 16, 17, 18, 19
01) Mecha Frieza
Offset (Hex)		: F923
Original 	HP999	: E7 03
Edited	 	HP999	: E7 03
02) Frieza
Offset (Hex)		: F92B
Original	HP500	: F4 01
Edited		HP900	: 84 03
03) Cooler
Offset (Hex)		: F933
Original	HP999	: E7 03
Edited		HP999	: E7 03
04) Cooler (Transform)
Offset (Hex)		: F93B
Original	HP999	: E7 03
Edited		HP1500	: DC 05
05) Salza
Offset (Hex)		: F943
Original	HP950	: B6 03
Edited		HP950	: B6 03
06) Dore
Offset (Hex)		: F95B
Original	HP980	: D4 03
Edited		HP980	: D4 03
07) Neiz
Offset (Hex)		: F973
Original	HP800	: 20 03
Edited		HP800	: 20 03
08) Cell
Offset (Hex)		: F9E3
Original	HP999	: E7 03
Edited		HP999	: E7 03
09) Android 16
Offset (Hex)		: F9EB
Original	HP999	: E7 03
Edited		HP5000	: 88 13
10) Android 17
Offset (Hex)		: F9F3
Original	HP999	: E7 03
Edited		HP3000	: B8 0B
11) Android 18
Offset (Hex)		: F9FB
Original	HP999	: E7 03
Edited		HP2500	: C4 09
12) Android 19
Offset (Hex)		: FA03
Original	HP999	: E7 03
Edited		HP2000	: D0 07


H) Credits:
1) https://gesato.com/fc/dbz3/data.html
A very detailed information is provided which leads to the finding of hex addresses for the Z Warriors' HP and KI as well as enemies' HP.
2) https://www.youtube.com/watch?v=vY7kTv4ZuYY
Full credits to 'zack86735' for finding a way to make Vegeta and Trunks fully playable.
3) Twilight Translations from ROMhacking.net
English translation for their Dragon Ball Z III - Killer Androids.


Written by injoon84:
06/08/2025
DD/MM/YYYY
