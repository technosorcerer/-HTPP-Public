
     Dragon's Lair (improvement) V 1.0 / hack by The Jabu    
    -----------------------------------------------------

        This is a hack for the game "Dragon's Lair" for the NES, that make a 
  few improvement to the game, so now you have more chances to beat the game.
  

  Changes:


  V 1.0

  
  - Now with the "B" button you use your weapon, and with the "A" button you jump. 

  - Now you have unlimited lives.

  - You don't lose energy by using your weapon anymore. 

   



  Apply the IPS file to  "Dragon's Lair (U) [!].nes" or " Dragon's Lair (E) [!].nes " , 
  and have fun!!!



  note 1: sorry for my english , but english is not my native language. 
