Dragon's Lair (NES)
Traducción al Español v1.0 (05/12/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dragon's Lair (U) [!].nes
MD5: 71e678115866ff40ed98f1beeaf06db4
SHA1: b264269fd22f9ce245bc8b84771a0022ebb75278
CRC32: f90ae80e
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --