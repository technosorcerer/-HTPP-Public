 - - T H E   T R A N S L A T O R S - - 

**************************************
* Spel:         DuckTales            *
* Konsol:       NES                  *
* Spr�k:        Engelska-Svenska     *
* Uppdaterad:   2001-12-15           *
* �vers�ttare:  Bj�rn Norrliden      *
* F�rdigt:      99%                  *
**************************************

 - VAD �R INTE GJORT?

    * Game Over-sk�rmen
    * Det saknas ett N p�
      TRANSYLVANIEN p� landvalsmenyn.


 - VAD �R NYTT I VERSION 2?

    * Jag lyckades �ndra TIME till
      TID.
    * Dialogerna och grammatiken �r
      mycket b�ttre. Ingen
      s�rskrivning h�r, inte.

  - FELRAPPORT

     Om du skulle hitta n�gon bugg,
     n�got stav/grammatikfel, skicka
     ett mail till mig p�:

     bjorn.n@ebox.tninet.se

**************************************
      HUR MAN ANV�NDER IPS-FILEN      

V�ldigt m�nga vet inte hur en IPS-fil
fungerar. H�r finns en f�rklaring:

Du beh�ver f�ljande:

 - SNESTOOL (finns p� v�r hemsida)
 - DuckTales-rom (amerikansk version)
 - DuckTales-patch (ips-filen)

1. L�gg alla de h�r filerna i samma mapp
   och starta SNESTOOL.

2. V�lj med hj�lp av piltangenterna
   USE IPS och tryck enter.

3. V�lj DUCK.IPS i listan till v�nster
   och tryck enter.

4. V�lj sedan DuckTales-rommen och tryck
   enter.

5. V�lj QUIT PROGRAM.

6. Starta DuckTales-rommen i en
   NES-emulator som bl a finns p�

   http://sen.zophar.net/

S� h�r g�r man n�r man patchar alla
�vers�ttningarna fr�n The Translators.
Du ska sj�lvklart ha respektive ips-fil,
spelrom och emulator till dem.

**************************************

Copyright � The Translators 2001.

http://sen.zophar.net/tt/

bjorn.n@ebox.tninet.se
