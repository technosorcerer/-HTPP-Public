"Raping your childhood games since 2008."

This is a ROM-hack of DuckTales for the NES. This readme should be included with the ROM of DickTales. If you got the patch version, then apply the patch to the DuckTales ROM.

Hello. 

I am B. Dicke, and I am, quite simply, a ROM-hacker. A Bad Hacker, at that.

I hack games that should piss you off, or make you giggle, depending on your personality and sense of humor.

This is the first game I hacked. It is a hack of Capcom's "DuckTales", appropriately called "DickTales". It is basically DuckTales but with crude humor and crude graphics that may be offensive to some. If you were offended by this hack, then please get the hell out of the Internet. There are much worse things to worry about.

Story:

You are Spoodge McDick, the most perverted duck on Dickburg and possibly the world. You are on a quest to collect the five legendary fuck-toys in order to fulfill their prophecy: "Whosoever collects the five toys will be granted the biggest dick in the world." Determined to enlarge his already large and formidable member, Spoodge goes on a globetrotting quest to collect the five toys and possibly kick some ass.

About the hack:

Title Screen: It looks somewhat fucked up due to the fact that the tiles for it were laid out like shit and there were a few repeating tiles. Had to work with what I have.

Sprites: A good number of sprites were changed.Not much of an artist, but I think I did a decent job. 
Notable changes:
- Spoodge no longer uses a cane, but uses his dick to hit things and bounce around. 
- Changed the font. Loosely based from Ray N's handwriting from his comics. Plus it looked cool. ;)
- Some people have penises or swatsikas or cigarets added.
- Magica DeSpell is now nude.
- The treasures are now fucktoys. A gold penis, Tranny DNA, a diamond cunt, Homo Shit, and an Astral Assplug, in that order.
- Money is now pussy. Makes the world go round and it helps your dick grow. ;)
- Rat has weirder eyes.
- Other item and character changes too lazy to list.

Levels: Changed the names of them. Not the look of them. Didn't feel it was really necessary. We now have Jonesboro (in place of the amazon, and as a tribute to Ray N's involvement to the hack), Trannie-Land (transylvania pun, now a Motel), African Cunts (another lazy pun), San Francisco (in place of himalayas, but instead of snow, its semen, like the actual SanFran, complete with the abominal snow (cum) faggot), and finally UFO Land (same shit, fuck you).

Story: The story of this hack was written by Ray N. of The Jonesboro Experience of America. DickTales was also based on a flash parody of the same name by Emanhattan. Look up "Skittles N Dickz" on Newgrounds to find the skit among the flash. Both of them are credited for the concept. Fellow BadHacker Jomb (Of "Pussy City Pimps" fame) helped me out by providing me the table file for this game, and for playtesting this game, so I was able to hex away without a hitch. He is credited as well. I did the rest of the shit (graphics hacking, hex editing, testing, etc.)

This hack was completed in a course of a week (and it shows :P), but planning had happened for months. I plan to do more hacks in the future, possibly one entirely done by me. This one is more of a joint work (and its my debut) I am open to suggestions, but please, make em simple, ok?

Email me at b_dicke66@yahoo.com for any questions about the hack or anything. (no spam, please.)

-End Transmission-

B. Dicke, 2008 

Please visit http://www.badhacks.net for more Rule 34-type mutilations of your favorite games from the past. Tell em B. sent ya! ;)