﻿Ankronikka (NES) V1.0
---------------------
Arto4000 / arto4000@gmail.com
NES-Retromaailma nesretro.com

Muutama huomio:
---------------
- Ajan loppuessa tulee teksti "AIKA UUU", koska kuolema triggeröityy tuosta
  ekasta U-kirjaimesta, enkä saanut sitä muutettua. "AIKA U" olisi näyttänyt
  vähän typerälle, niin laitoin sitten kunnolla U-kirjaimia. Alkuperäinen
  muoto "TIME UP".
- Käännös voi olla aavistuksen tönkköä teknisistä rajoitteista johtuen.

Toimintaohjeet:
---------------
1. Pätsää IPS-tiedosto eurooppalaiseen PAL-versioon pelistä. NTSC-versioon
   pätsättäessä ei toimi kunnolla.
2. Varmista emulaattorista, että PAL-tila on päällä.
3. Nauti!

Kiitokset avustajille:
----------------------
Radikus
Kipsi
Zilverfang
Calondra
RetroUkko
simoxyz

Greetz:
-------
Lurg, senkin apina
Nesretro.com
Pave Maijanen