Donkey Kong 3 (NES)
Traducci�n al Espa�ol v1.1 (15/03/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
V1.1: Arreglado V por R, porque hace referencia a la RONDA. Cambiados tiles para poner TIEMPO donde pone TIEM.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com


------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Donkey Kong 3 (U) [!].nes
MD5: a267179a14c89ee73b0031de07c9e5c7
SHA1: ec6fa944c672a2522c8bc270a25842281c65ff5d
CRC32: d1cac3c2
24.592 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --