--------------------------Info---------------------------
Game name: Double Dragon II - The Revenge
Console: Nintendo entertainment system
Game region USA: (U)
Patcher: Cheat Patcher v1.2 or higher.
----------------------------------------------------------
--------------------------patch------------------------
The patch allows to set following parametres:
 
 Billy lives.
 Jimmy lives.
 Billy & Jimmy energy.
 Safe water (mission 4, 5).
 Switching the attack buttons disabled.
 Forward kick enabled, switching the attack buttons disabled.
 Jump on the start button.
 Jump on the select button.

--------------------Cheat Patcher------------------
Download link:
http://www.romhacking.net/utilities/1112/
----------------------------------------------------------
Authors by: Evgeny, Kaiser_Gun, infval, Mr2.
e-mail: fsocp@land.ru
http://rgcorp.ucoz.net/