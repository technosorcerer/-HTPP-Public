Double Dragon II - The Revenge (NES)
Traducción al Español v1.0 (04/05/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Reescrito todo el guion
-Añadidos caracteres españoles
-Traducida barra de estado
-Traducido gráfico DANGER!

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Double Dragon II - The Revenge (USA) (Rev A).nes
MD5: b94be0bf2e861bca19339920cd786f53
SHA1: e4fbbe69b3b539b198ae0e037fdc2558074a283f
CRC32: a0f7027d
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --