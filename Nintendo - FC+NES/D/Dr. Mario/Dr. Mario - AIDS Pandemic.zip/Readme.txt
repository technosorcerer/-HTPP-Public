
=====How to play The 1957-1959 AIDS Pandemic======
1) Download this hack (already done, good fucking job)
2) Download Dr. Mario ROM (use Google)
3) Download Lunar IPS (use Google)
4) Use Lunar IPS to Patch The 1957-1959 AIDS Pandemic.ips to the Dr. Mario ROM (It's a shitload easier than it sounds)
5) launch the hack in any NES emulator ( I recommend FCEUX)





================plot==============================
My Name is Doleskonov chechloromanov. I am a Doctor in Russia.

1957.... the year that mankind fell apart. From August to November that year, the
entire jew population was decimated. There was not be a single one left on
Earth. On 
Christmas Day, that same year, a new, and horrific disease appeared. Patient
Zero died within hours. We soon discovered that the disease completely 
destroyed the patients immune system. The most terrifying thing though, was that
it was airbourne. We called the disease....AIDS.... Over the course
of 1958, the disease spread across the planet. It succeeded in wiping out
nearly 4 Billion people in that time. By 1959, this year... an estimated
88% of mankind has
died of AIDS. Here in Russia, we've managed to stave off the
AIDS by dosing ourselves with an experimental drug we call Mifepriston. The unfortunate
side effect is that it renders anyone who takes it... infertile.

There is no saving us. Mankind has absolutely zero chance of bouncing back
from this travesty. the infertility caused by the AIDS meds all but seals our
fate. when faced with the fate of dying a slow, excruciating death, its a no
brainer. Even so, the RU-486 seems to be losing it's effect. even after treatment, 
many patients simply die anyway. 


 During the initial pandemic, there were wars, riots,
entire cities burned to the ground, and several nuclear exchanges had occured. It 
doesn't even seem to matter if the drugs make us infertile. I'd never
even entertain the idea of bringing a child into this ruined world. There is 
word that there is massive activity in Germany since the pandemic started winding
down, but nobody who has made the trek to that country has returned to tell
us about it. Perhaps they are immune? Who knows? I must stay here and 
fufill my duty to help stave off the AIDS in the remaining local population. 

Every single one of us is infected. There's no way out of this. Mankind will
be coming to an end very soon. I suspect there won't be any people around
to see the year 1960.




====Credits=====
Hax0rKyo - Creator
Dr. Floppy - Musical/pause screen Consultant






























https://www.youtube.com/watch?v=5yC7HwPh6Es
