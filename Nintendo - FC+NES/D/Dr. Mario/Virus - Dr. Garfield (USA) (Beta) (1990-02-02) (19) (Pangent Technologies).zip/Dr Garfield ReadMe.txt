
Find out why everybody’s calling on Dr. Garfield.

(This may sting a little.)

Looking for an intense new challenge?
Dr. Garfield is here and he's got the cure! 

Three kinds of ugly, nasty viruses are on the loose. But these germs are fun to catch. Garfield throws multi-colored vitamin capsules into the bottle. You can move, shift or spin the capsules as they fall. Arrange them to align with other capsules on top of the virus. If you can get 4 or more of the same color in a row, POOF! The viruses disappear! Destroy all the viruses in the bottle and you progress to the next round, where things get even more difficult. Play alone or enjoy simultaneous 2-player action, only from Nintendo on your Nintendo Entertainment System or Nintendo Game Boy.

Dr. Garfield—the fun is contagious!

Garfield and Garfield characters © 1978, 1990 King Feature Syndicate, Paws Incorporated.
Dr. Garfield © 1990 Nintendo
Nintendo of America Inc., P.O. Box 957, Redmond, WA 98073-0957, 1-800-633-3236, Fax: 206/882-3585

___________________

IPS Patch for this ROM:

"Virus_(USA)_(1990_Proto)"

The ROM used is a proto version of Dr. Mario.
https://tcrf.net/Proto:Dr._Mario_(NES)/Virus_1989_%26_1990

___________________

From Pangent Technologies.

Video:
https://www.youtube.com/watch?v=AkqfMeMGDww

Thanks to BogaaBogaa for ASM coding, including win and loss animations, the Odie pause screen, Odie logic, Jon menu logic, music logic and HDPack Music Logic.

Thanks to KasumiDirect for I-CHR and solving many issues, particularly with the title and menu screens, and palettes.

Acknowledgements to Lumpytouch for the in-game viruses.

Some graphical acknowledgements to Garfield: Big Fat Hairy Deal by Stephen Cargill and Neil Strudwick.

___________________

Notes:

VERSION 19

An HDpack for the Mesen emulator is available which makes the game more colorful using PNG images, including some custom backgrounds.

Copy this HDPack directory into the Mesen/HDPacks directory. This directory must have the same name as the ROM (such as DrGarfield).

The separate DrGarfieldHD patch is intended to make use of custom music in Mesen's HD packs. You can add custom music to the game (using filenames like Track01.ogg).

Music tracks from Tetris can be played by writing a track number to RAM address $6F5. They seem to play at double speed. This is added to this version.

Level can only be set to EASY (NERM) or NORM (GARF), though a HARD setting exists and can be accessed by setting RAM address $726 to 01. This is added to this version.

An option to disable periodic speedups exists, which is activated by changing RAM address $723 to a non-zero value.

___________________

Audio replacement in HD packs in the Mesen emulator adds a number of read/write registers in memory and they can be used to play OGG files specified via <bgm> and <sfx> tags. This can be spotted in the code.

$4100: Playback Options (BGM looping on or off)
$4101: Playback Control (Pause/Resume/Stop)
$4102: BGM Volume 0-255
$4103: SFX Volume
$4104: Album Number
$4105: Play BGM Track
$4106: Play SFX Track

___________________

Thoughts about this build:

Music stops after every round in 2P mode. (Not in HDPacks mode).

Odie loss frame is not implemented, or left-facing Odie for the pause screen. It's been discussed that the pause screen could have been programmed into more of a minigame.

HDPack includes Odie and Jon characters in background in 2P mode. ROM could possibly include this as well, if four more CHR banks were added and background CHR bankswitching was redirected to them in this mode, which would free up many background tiles used in 1P mode only. There is some info about Register switching in the ASM files.

HDPack has some animated backgrounds, which use condition tags mapped to tiles in the original animated backgrounds. These can be swapped out, or more animation could be added as desired. The title screen could be animated with conditions based on the animating virus sprites.

___________________

A Dr. Mario AI which would almost certainly have to be rewritten to work with this ROM.
https://meatfighter.com/drmarioai/

Dr. Mario virus placement discussion here:
https://tetrisconcept.net/threads/dr-mario-virus-placement.2037/page-1