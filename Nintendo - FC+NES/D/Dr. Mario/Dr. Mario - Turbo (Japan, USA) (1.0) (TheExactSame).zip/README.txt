Dr. Mario Turbo

Designed by Leviticus
Romhacking by TheExactSame

Dr. Mario Turbo primarily aims to make vs. play faster paced and less affected by stun locking garbage. The main feature is that all clear and drop time is cut in half, allowing both players to return to control much sooner after receiving garbage.

All features are implemented for the single player game as well.

--------------
Full Feature List:
- Double drop time speed for both settling pills after clear and 2p garbage. Clear animation time is also twice as fast.
- Hard Drops. Hit up to immediately place a pill where it lands directly below it's current position.
- Close approximation of full SNES capsule sequence RNG.  No more long droughts or runs, and more doubles
- In 2p, chained 2-combos will no longer always drop garbage in the same place.

Join the Dr. Mario Championship Discord Server!
https://discord.gg/3XKnESEcXx
 