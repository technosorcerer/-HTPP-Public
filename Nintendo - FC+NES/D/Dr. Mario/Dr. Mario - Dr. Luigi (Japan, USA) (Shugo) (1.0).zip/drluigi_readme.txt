﻿
			-The Year of Luigi Collection-
 		 _____         _     _    _ _____ _____ _____ 
 		|  __ \       | |   | |  | |_   _/ ____|_   _|
 		| |  | |_ __  | |   | |  | | | || |  __  | |  
 		| |  | | '__| | |   | |  | | | || | |_ | | |  
 		| |__| | |_   | |___| |__| |_| || |__| |_| |_ 
 		|_____/|_(_)  |______\____/|_____\_____|_____|

______________________________________________________________________________


In the spirit of The Year of Luigi, which in fact did NOT end in 2013, I'm
inserting Luigi into classic Mario games in place of the red plumber! I was
originally inspired by an April Fools' joke on NintendoLife.com teasing Luigi
versions of classic NES games, specifically Dr. Luigi, which I wished was a
thing so much that I decided to make it one!


------------------------------------------------------------------------------


Features:
-Dr. Mario is now Dr. Luigi! All of his sprites are redrawn to feature the
 taller, thinner brother in medical attire. His appearance is based on other
 80's/90's games that featured him rather than his modern appearance.
-New title logo based on the logo from the Wii U Dr. Luigi.
-New, completely redrawn virus designs based on the ones from the Wii U title.
-New color palettes - pills, viruses, backgrounds, etc. Most of the changes
 are based on the Wii U Dr. Luigi.


------------------------------------------------------------------------------


Patching Instructions:

You should probably know this by now if you're on romhacking.net, but use an
IPS patcher such as LunarIPS to apply one of the included patches to a clean
Dr. Mario ROM. The one I used was named "Dr. Mario (JU).nes".

In the archive I've included three different patches to suit different users'
tastes. Here are the differences between them:


DrLuigi_lite.ips
---------
The standard Dr. Mario with minor changes. Only the logos and Mario himself
are edited in this one. This is for the purists out there who just want a
straight brother swap. I like to say this is "how Nintendo would do it".


DrLuigi.ips
---------
All of the features listed above are included in this patch. I like to say
this is "how Nintendo would do it if they decided to put some effort into it".


DrLuigi_yole.ips (Dr. Luigi: Year of Luigi Edition)
---------
All of the features listed above plus an extra bar on the title screen
displaying "The Year of Luigi". I almost didn't include this idea but a good
amount of people thought it was cool...while another good amount thought it
wasn't. So I've included both versions.


______________________________________________________________________________

I hope you enjoy it! Wahoo! Let me know on the forums if there's a problem I
should patch up.

Created by: Shugo
shugotakahashi at gmail dot com