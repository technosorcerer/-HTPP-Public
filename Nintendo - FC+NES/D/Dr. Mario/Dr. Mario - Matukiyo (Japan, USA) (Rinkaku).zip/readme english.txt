＊＊＊＊＊＊＊＊＊＊＊＊＊＊
＊　Rinkaku's Hackrom　＊
＊＊＊＊＊＊＊＊＊＊＊＊＊＊

"Matsukiyo Mario"

Please use it by overwriting "Dr. Mario (Dr Mario (JU).nes)".

If you are unable to make changes or the screen becomes strange, please contact us.

A one-shot hack with just the title.
It was a good effort at the time.

I'm not sure if I remember posting this publicly, but it was picked up by GoodNes.
Because of this, it is a hack chrome that has been renamed in Japanese on JPnes.
I apologize to the creator of JPnes. For something like this.

Please feel free to reprint and redistribute this if you like.

history
Created sometime in 2000

Rinkaku rinkaku@geocities.co.jp
Rinkaku page http://www.rinkaku.com/ (forward)
         http://www.geocities.co.jp/SiliconValley/8474