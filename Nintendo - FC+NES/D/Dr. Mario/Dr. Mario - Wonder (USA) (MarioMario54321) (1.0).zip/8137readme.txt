This is MarioMario54321. I don't usually do this, but although I am normally on Youtube making videos, but I made this ROM hack of Dr. Mario for the NES that is tailored towards one of the videos I made on Youtube. This was actually my first experience in NES ROM hacking.

A mysterious new virus called the Wonderflu has spread across the Mushroom Kingdom! Although this virus is suspected to come from the Flower Kingdom (the setting for Super Mario Bros. Wonder), this is highly speculated otherwise. Same rules as the original game, just match 4 vertically or horizontally to get rid of the viruses. If you trigger a cutscene, you'll find out who or was responsible! But if you beat the game at its hardest, you'll go even deeper than that!

This ROM hack is based on this video that I made: https://www.youtube.com/watch?v=LLg1B0VXdCI

New Viruses: Tripurple (purple), which causes victims to hallucinate. Elephever (gray) which adds elephants to their hallucinations, and Suipipe (teal), the worst one, which slowly drives its victims to suicide! This last virus also loves it when you match it in a vertical or combination of 4, and instead of laughing at you, this virus will get angry and roar at you if you get a Game Over.
==================
V1.0 - Dr. Mario Wonder
- Replaced viruses with three new viruses: Tripurple (purple), Elephever (gray) and Suipipe (teal)
- Changed the colors of the viruses
- Replaced the tree in the cutscenes
- Changed title screen and menu screens
- Changed assets in each of the end cutscenes
==================
ROM Info:
    Dr. Mario (JU).nes
    No-Intro Name: Dr. Mario (Japan, USA)
    File MD5: D3EC44424B5AC1A4DC77709829F721C9
    File SHA-1: 01DE1E04C396298358E86468BA96148066688194
    File CRC32: B1F7E3E9
    ROM MD5: 5B401F4CA7E1B12AF3F29D8FC758DD2F
    ROM SHA-1: FF6459BC3AF5743E3D303823999F33D74ABDF1AA
    ROM CRC32: 198C2F41
==================
Contact:
Youtube: https://www.youtube.com/mm54321
Twitter: https://twitter.com/mm_54321
Discord: mariomario54321
==================
Special Thanks:
To John Riggs, whose Youtube videos helped me learn to hack this game and bring you this mod. Go check out his Youtube channel here: https://www.youtube.com/@JohnRiggs
==================
Go check out my Youtube channel if you want to see some SM64 and other game content!