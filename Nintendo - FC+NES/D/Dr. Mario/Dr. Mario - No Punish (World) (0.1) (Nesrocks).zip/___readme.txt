Dr. Mario (NES)


Removes the punishment blocks when a 2+ virus combo
is achieved.


Credit to nesrocks for original hacking work.
