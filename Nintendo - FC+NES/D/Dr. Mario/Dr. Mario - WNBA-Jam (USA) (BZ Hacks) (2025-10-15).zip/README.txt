Play as the president of the United States as you toss dildos into unsuspecting basketball games! 

Patch to Dr. Mario (Japan, USA).nes