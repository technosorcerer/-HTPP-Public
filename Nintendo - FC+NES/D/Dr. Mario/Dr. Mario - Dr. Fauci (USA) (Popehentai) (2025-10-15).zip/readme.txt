dr fauci
hack of dr mario (UJ)
Description:

trust the science. the science of not having a clue what youre doing, and not having to care because of a pre-emptive pardon. Whoops.