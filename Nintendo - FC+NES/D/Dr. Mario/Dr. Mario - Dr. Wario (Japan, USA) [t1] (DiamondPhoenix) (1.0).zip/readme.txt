Hello!

Thanks for downloading my Dr. Mario hack.

To play this game, you need LunarIPS, and patch the .ips file into a clean rom of dr. mario (I hacked Dr. Mario (JU) [t1])
OR, you can jusr rename the ROM the same as the .ips

(Filename.nes for the rom and Filename.ips for the patch)

The hack was made by DiamondPhoenix, in 2010.


--- Note for hackers---
I have found some stuff for the demo screen like the level map, and demo computer's movements.
ROM: Dr. Mario (JU) [t1]

0x5215 - 0x540F
Demo movements

1st bytes = frames to wait before next button activates, the previous button is still being pressed while the next one waits, 
2nd bytes = button pressed 
(goes like that: 1,2,1,2,1,2,1,2,1,2,1,2,1,2...)
(HEX)
-----
0x5110 - 0x518F
Demo virus map (HEX).
FF = empty
D0 = Yellow virus
D1 = Red virus
D2 = Blue virus

(12 yellow, 15 red, 17 Blue)


Controls (HEX):
00 = None
01 = Right
02 = Left
04 = Down
08 = Up
10 = Start
20 = Select
40 = B
80 = A