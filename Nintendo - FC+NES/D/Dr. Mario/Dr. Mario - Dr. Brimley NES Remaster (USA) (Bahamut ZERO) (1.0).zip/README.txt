That's right, Dr. Brimley got a remaster on the NES! And boy is it a doozy!

Inspired by a request from Googie, this was originally gonna be a quick redo of my old Dr. Brimley hack for the Game Boy, but on NES with full color. After realizing I wouldn't be able to remake the old food animations due to how the NES version handles animating the viruses (sorry folks, no twerking ice cream cones this time!) I tossed that idea aside and made it it's own thing.

Features:

Visible pause and demo remover thanks to DMHero's Combo tool
TheExactSame's SNES RNG mod
TakuikaNinja's Input Fixes mod

An insane amount of graphical changes: including characters, viruses, cutscene graphics, hell even the old bottle-shaped playing field has been changed!

Palette changes, including darker backgrounds during gameplay so it's easier to focus on the action.


Patch to Dr. Mario (Japan, USA).nes