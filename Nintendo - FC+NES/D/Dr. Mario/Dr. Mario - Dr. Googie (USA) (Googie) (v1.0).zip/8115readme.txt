Dr. Googie - Dr. Mario hack
---------------------------

Big thanks to Zynk Oxhyde for all his help with the graphics putting my cartoons in the game
--------------------------------------------------------------------------------------------

Story...

There's an alien virus that's going around and it up to Googie to cure the world before earth goes into anyother pandemic, whee!
--------------------------------------------------------------------------------------------------------------------------------

Googie Toons and all original characters are owned by Victor Alonzo, make sure to connect with me on social media https://beacons.ai/googietoons

---------------------------------------------------------------------------------------------------------------------------------------

Q: How come you don't release hacks like you used to?

A: I'm still hacking but at a slower pace, I'm also getting into game development to make an 8-bit game with my cartoons, I'll keep you guys in the loop

Q: How many more hacks do you have on your plate?

A: I have a lot of hacks to do so I'm not retiring anytime soon, so don't worry ;)
----------------------------------------------------------------------------------

Any feedback reach out to me at googietoons(REMOVE THIS)@gmail.com

Take care and happy hacking! :D

- Googie 