"Dream Master" traducido al espa�ol por el usuario
"Takkun57" de "romhacking.net". Puedes seguirme en mi
cuenta de twitter @Javi_trad para conocer y seguir el
resto de mis proyectos.

Si quieres ayudar a mejorar esta traducci�n, env�ame
un correo a fjcn1994@yahoo.es, indicando tu experiencia
general y cualquier error ling��stico o bug que pudieras
encontrar. �Gracias!

Versi�n: 1.0


INSTRUCCIONES PARA APLICAR EL PARCHE:

1) Descarga LunarIPS, disponible desde este sitio web:
https://www.romhacking.net/utilities/240/

2) Extrae el programa, �brelo y selecciona
"Apply IPS Patch".

3) Selecciona el archivo "[ES] Dream Master.ips", y
a continuaci�n el archivo ROM que contiene el juego.

4) �Disfruta!

CONSEJOS PARA LA EMULACI�N

- Este juego presenta ciertos glitches visuales con
algunos emuladores. Para una experiencia de juego
�ptima, recomiendo el emulador "nestopia".

GU�A:

- Si te quedas atascado, puedes consultar la gu�a del
usuario "threetimes" en la siguiente direcci�n (en
ingl�s):

https://gamefaqs.gamespot.com/nes/580594-dream-master/faqs/60830

Este juego utiliza un sistema de contrase�as para guardar
y cargar partidas. Si quieres jugar con el sistema original,
aseg�rate de apuntar las contrase�as o "Dreamwords" que
se proporcionan a lo largo del juego para no perder tu
progreso.

En caso de que pierdas tu contrase�a o savestate, puedes
utilizar las Dreamwords que aparecen m�s abajo (cortes�a
de threetimes) para empezar a jugar desde ciertos puntos
clave de la historia.

Tambi�n puedes reemplazar la parte "GAMEFAQS" por los
nombres que quieras darles a tu h�roe y hero�na, teniendo
en cuenta que el l�mite de caract�res para cada nombre
es de 4. En los ejemplos que aparecen a continuaci�n,
el nombre del h�roe aparecer� como "GAME" y el de la
hero�na como "FAQS".

Dreamword 1:
GAMEFAQS ..v2? 

(v = flecha hacia abajo)

Dreamword 2:
GAMEFAQS vjJj  

Dreamword 3:
GAMEFAQS 1%Ej  

Dreamword 4:

GAMEFAQS Ejv.. 

Dreamword 5:
GAMEFAQS  lB>C
 
(> = flecha en direcci�n derecha)

Dreamword 6:
GAMEFAQS  F%Hj