David Crane's The Rescue of Princess Blobette Starring A Boy and His Blob (Game Boy)
Traducción al Español v2.0 (07/12/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Traducida pantalla de título
-Traducidos créditos
-Mejoradas traducciones de sabores y objetos
-Traducido TR por TE en barra de estado

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
David Crane's The Rescue of Princess Blobette Starring A Boy and His Blob (USA).gb
MD5: 81f7dee7546e630de075a3397349efb8
SHA1: 0a45d1b98646fd7832b5119b04bc8d6d6d0f657a
CRC32: 8210a03f
65536 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --