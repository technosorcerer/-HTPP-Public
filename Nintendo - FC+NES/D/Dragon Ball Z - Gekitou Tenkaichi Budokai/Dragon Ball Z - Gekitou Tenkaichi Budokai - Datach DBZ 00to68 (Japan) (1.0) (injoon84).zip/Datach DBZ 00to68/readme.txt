

   --------------------------------------------------------------------
---Datach Dragon Ball Z - Gekitou Tenkaichi Budou Kai---
   --------------------------------------------------------------------


Notes:
--------

- This game was hacked by 'wangsitan@aliyun.com' or 'wangsitan@yahoo.com.cn' on
  23/10/2012. All I did was change the characters' stat into a much balance
  fighter.

- For more info about this game, you can always check the gamefaqs website at
  (http://www.gamefaqs.com/nes/577360-dragon-ball-z-gekitou-tenkaichi-budokai/faqs/65524)
  written by me though that is for unhacked version. One mistake in my faqs is
  Super Trunks minimum transformation BP suppose to be 29k instead of 30k.

- Some tiles on screen will be affected when ID is displayed because ID is made
  up by sprites. It will recover after selecting.

- 2 patches were made for this hacked version. Either use mapper 16 patch for
  the likes of 'Virtualnes' emulator or use mapper 157 patch for the likes of
  'fceux' emulator.

- Include 'edit character.xls' documentation. A complete table to edit the
  characters' stat range from HP(0 to 99500), BP(0 to 49750), DP(0 to 49750),
  and skills description (N/A to L4).

- If you like this hacked game, be sure to check out the hacked version of
  'Datach: Yuu Yuu Hakusho - Bakutou Ankoku Bujutsu Kai (J)' also released
  by 'wangsitan@aliyun.com'. The title is 'Yuu Yuu Hakusho - Need not DATACH'
  and you can get it at (http://www.romhacking.net/hacks/1979/).
  English translation patch was released by 'Stardust Crusaders'.
  Look at (https://www.romhacking.net/translations/5386/).
  Awesome game and the best fighting games for NES in my opinion!


Guides:
----------

- There are a total of 69 ID numbers (00 to 68) added to this game. 00 to 28
  for characters and 29 to 68 for items.

- ID 00 to 28
---- ---------------
  ID Characters
---- ---------------
  00 Son Goku
  01 Super Son Goku
  02 Trunks
  03 Super Trunks
  04 Son Gohan
  05 Super Son Gohan
  06 Tien Shin Han
  07 Chaotzu
  08 Piccolo
  09 Super Piccolo
  10 Yamcha
  11 Vegeta
  12 Super Vegeta
  13 Krillin
  14 Android No16
  15 Android No17
  16 Android No18
  17 Android No19
  18 Raditz
  19 Ginyu
  20 Zarbon
  21 Saibaman
  22 Frieza
  23 Frieza (1st Form)
  24 Frieza (2nd Form)
  25 Frieza (Final Form)
  26 Cell
  27 Cell (Semi-perfect)
  28 Cell (Perfect)

- ID 29 to 68
---- --------
  ID Items
---- --------
  29 Recovery Capsule
  30 Senzu Bean
  31 Karin
  32 Shenron
  33 Bulma
  34 Dende
  35 Muten Roshi
  36 Kami
  37 Mr Popo
  38 Kaio
  39 King Enma
  40 Muri (Namekian Elder)
  41 Saiyajin Armor
  42 Chou Shen Shui (Super God Water)
  43 Chi Chi
  44 Yajirobe
  45 Puar
  46 Umi Kame (Sea Turtle)
  47 Gregory
  48 Oolong
  49 Bubbles
  50 Granpa Gohan
  51 Uranai Baba
  52 Dr Brief
  53 Bulma's mother
  54 Gyumao
  55 Lunch
  56 Capsule
  57 Unknown ???
  58 Dragonball 1 star
  59 Dragonball 2 stars
  60 Dragonball 3 stars
  61 Dragonball 4 stars
  62 Dragonball 5 stars
  63 Dragonball 6 stars
  64 Dragonball 7 stars
  65 Porunga L1
  66 Porunga L2
  67 Porunga L3
  68 Porunga L4

- During the ID number selection:
  Up	: +10
  Down	: -10
  Left	: -1
  Right	: +1
  Start 	: Confirm the selection number
  Select	: Random barcode

- 1P ID number is controlled by 1P's joypad. 2P ID number is controlled by
  2p's joypad.

- Barcode still applicable for barcode data testing but only characters'
  barcode are actually working in the game. Items barcode have become useless
  but no worries as all items are presented within the ID numbers including
  unknown ID 57 which I think is a bug.

- During item selection, the same ID number can be repeatedly used. As for the
  original game, after selecting item barcode, the same item barcode can only
  be reselected again on the 6th round.

- All the modified characters within the ID numbers are given 3 skills.
  L1, L2, and L3.
  To perform the skill:
  B+A		: L1 skill
  Back B+A	: L2 skill
  Front B+A	: L3 skill
  Down B+A 	: L4 skill (Can use this after select ID 47 or ID 68)

- If you used barcode to create your own character, the number of skill can be
  perform depends on the skill level.
  N/A	: No skill
  L1	: 1 skill
  L2	: 2 skills
  L3	: 3 skills
  L4	: 4 skills


By:
----
- 'injoon84' on 04/ 02/ 2015 (dd/ mm/ yyyy)
- Updated on 14/ 07/ 2020 (dd/ mm/ yyyy)

