Datach Dragon Ball Z - Gekitou Tenkaichi Budou Kai (J)
  - Press Key to Select Fighter Hack (Need not DATACH Barcode)


Instruction
===========

Player can press key to select fighter and assistant. There are 29 fighters (ID range: 00-28) and 40 assistants (ID range: 29-68) in total.

When ID appears on screen, player can press direction key to change ID and press START key to confirm.

  Key       Effect
  ------------------
  UP        +10
  DOWN      -10
  LEFT      -1
  RIGHT     +1

When selecting fighter, player can press SELECT key to input random barcode.

When selecting assistant, player can press SELECT key to choose one assistant randomly. There is small probability for picking nothing. The mechanism is different from 'input random barcode'.

In battle mode of 2 players, selecting fighter for player-2 is controlled by the joypad of player-2. In battle, if the right side fighter is controlled by player-2, then its assistant selecting is controlled by the joypad of player-2.

Fighters can use skills those level are equal to or lower than the fighter's current level. For example, a fighter in Lv3 has 3 skills (Lv1, Lv2, Lv3), and cannot use the skill of Lv4.

  Key           Skill
  ---------------------
  AB            Lv1
  Back + AB     Lv2
  Front + AB    Lv3
  DOWN + AB     Lv4
  
If player selects a fighter with START key (not randomly), then the initial level of the fighter is Lv3, and the initial data (HP, BP, DP) is constant for each fighter. If player selects a fighter with SELECT key, then the initial level and data of the fighter are random. Note that the initial level of the fighter may be 0, which means that the fighter cannot use any skills.

In test room, player can choose an ID or press SELECT key to input random barcode.

The constant initial data of fighters are kind of high. Player can set difficulty of the game according to that in the option screen. In option screen, these options can be configured: 

  Round Number
  Time of Each Round
  Difficulty (1 is simplest, 3 is hardest)
  
Player can also input barcode, just like in the original game.

Some tiles on screen will be wrong when ID is displayed. Because ID is made up by sprites. It will be recovered after the selection.


About Assistants
================

In original game, effect of 4 dragons is changing skill. In this hack, their effect is level up. 4 dragons represent Lv1-Lv4. If the current level of the fighter is higher, the level will not be changed.
 
There is an assistant for level up by 1 level in the original game. Its effect in this hack keeps same with that in the original game.
 
The effect of Ranchi (ID 55) is changing the fighter, player can select fighter with joypad or barcode.


Thanks
======

Providing barcode for testing: ֯�����ܽ�

Plan optimization: ֯�����ܽ�

Testing: ֯�����ܽ�

Correcting my wrong knowledge about Ranchi: xsin


wangsitan@aliyun.com
2014-03-15
(This English document is written on 2017-08-13.)