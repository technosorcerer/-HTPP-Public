For a comprehensive guide on how to use Dezaemon, check out:

http://www.nesartifacts.blogspot.com/p/dezaemon-fc-game-guide.html


All credit due to the Dezaemon creators.  This patch was created to help preserve this game and its vital aspect - the ability to save your creation, and ultimately share it.

Have fun!

 - NES Artifacts, 2015