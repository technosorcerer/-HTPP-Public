

FC/NES Hack

_Datach Dragon Ball Z - Gekitou Tenkaichi Budou Kai_: **Don't Need Barcode, Multiple Skills**



# About Mapper

Two patches are provided: mapper 16 and mapper 157. Different emulators have different support for mappers. For example, FCEUX can run mapper 157, and VirtuaNES can run mapper 16. If one doesn't work, you can try the other one.



# Description

- When you need to select a character, the character ID will be displayed. Press arrow keys to adjust the ID. You can press START to select the character corresponding to the ID, or press SELECT to select randomly. The level of the fighter selected by ID is always Lv3. The level of a randomly selected fighter is random, and Lv0 may appear.

- Barcode input is allowed, too.

- Player can use all skills not higher than their current level. The usage is:
     - AB: Lv1
     - Back + AB: Lv2
     - Front + AB: Lv3
     - Down + AB: Lv4

     _For example, a fighter at Lv3 has the skills of Lv1, Lv2, and Lv3 at the same time, but does not have the skill of Lv4. Pressing "Down + AB" will trigger the skill of Lv1._



# Helpers

- Dragons (ID 65-68): The effect of the four dragons in the original version is to change the level to Lv1-Lv4 respectively. In this hack, a fighter's level will not be changed after using the dragon, if the current level is higher.

- Ranchi (ID 55): The effect is to change the fighter. Player can press key or input barcode to select a fighter.



# Input

- UP:       ID +10
- DOWN:     ID -10
- LEFT:     ID -1
- RIGHT:    ID +1
- START:    Confirm
- SELECT:   Select a character randomly



# Character ID Range

- 00-28:    Fighters
- 29-68:    Helpers



# Known Issues

- Some tiles on screen will be changed when the character ID is displayed. Because the tiles for sprites are replaced at that time. It will be recovered after the selection.



# Contact Information

- Email: wangsitan@aliyun.com



# Personal Page

- RomHacking: https://www.romhacking.net/community/2188
- YouTube: https://www.youtube.com/@wangsitan7
- Patreon: https://www.patreon.com/wangsitan



# Donate

If you would like to donate:
- PayPal: https://paypal.me/wangsitan
- Alipay: wangsitan@aliyun.com

Thank you for your support =)

