Die Hard (NES)
Traducción al Español v1.1 (10/09/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V1.1: Añadidos acentos y ñ¡¿

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Die Hard (U) [!].nes
MD5: c6f5c88bcb6f974828c3af013fe57bdc
SHA1: 47d52828efaf573f4f4675f0571a603ba8fcf7e3
CRC32: 65eec6e7
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --