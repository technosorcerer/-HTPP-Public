Die Hard Special Edition v1.0
(Die hard hack)
by Magnus Nilsson

How to use
----------
Apply the ips to Die Hard (USA).nes

CRC-32: 65EEC6E7
SHA-1: 47D52828EFAF573F4F4675F0571A603BA8FCF7E3
MD-5: C6F5C88BCB6F974828C3AF013FE57BDC


Changes
-------
Cosmetic:

 -Almost all graphics including sprites, UI and hundreds
 of background tiles have been redesigned to make the game
 look better and for the levels to be less confusing

 -Text now have a new font and a couple of script edits

Gameplay:

 -Time limit per lock is now 5 minutes instead of 4

 -Health powerups now gives 5 points instead of 1

 -Line of sight tweaked in a few areas

About
------
Despite what some angry internet nerds may think,
Die hard for NES is a great game. Argueably one of the
most faithful game adaptations of a film ever made and
boasting some (for NES atleast) unique features such as
line of sight, realtime tracked AI, persistant destructable
terrain and enemy corpses, good script with lines lifted
straight from the movie, randomly generated item
locations and multiple endings for replay value and yes,
foot meter, this game is awesome.

It's far from perfect though and most of the criticism
can be aimed at the games bad graphics.
Despite having some of the best looking digitilized
cut-scenes the NES ever seen, most of the game looks awful.
This hack aims to rectify that by redesigning most of the
games graphics and also the difficulty has been lowered
abit by adjusting some key values for better balance.
 

(C) Magnus Nilsson 2014
