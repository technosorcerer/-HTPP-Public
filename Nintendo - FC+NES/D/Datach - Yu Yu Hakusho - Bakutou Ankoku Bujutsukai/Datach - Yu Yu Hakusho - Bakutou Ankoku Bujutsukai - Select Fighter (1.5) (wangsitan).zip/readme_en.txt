
Yuu Yuu Hakusho - Bakutou Ankoku Bujutsu Kai
  - Press Key to Select Fighter Hack (Need not DATACH Barcode)



========== Short Description ==========

- Player can press key to select role. All roles are accepted in all mode.

- Player can select ��������-120% as fighter. He's hiden in original game.

- All fighters have complete skills of themselves. All assistants provide the highest HP/SP.

- 1P, COM and Determine Room is controlled by 1P's joypad. 2P is controlled by 2p's joypad.

- Press direction key to change ID. Press Select key to select current role.


  Key    ID Changed
  --------------------
  Up        +10
  Down      -10
  Left       -1
  Right      +1


  ID       Role Type
  ---------------------
  00-22    Fighter
  23-28    Assistant  
  29-32    Special




========== Some Issues ==========

- Player cannot select fighter in the final battle. It's a setting of the original game.

- Some tiles on screen will be changed when ID is displayed. Because ID is made up by sprites. It will be recovered after selecting.




wangsitan@aliyun.com
2014-03-16

