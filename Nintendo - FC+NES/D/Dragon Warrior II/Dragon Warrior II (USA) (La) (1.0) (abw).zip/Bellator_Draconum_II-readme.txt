Dragon Warrior II Latin Translation
by abw
Version 1.0
Release Date: March 13, 2019

Checksums (unpatched):
GoodNES File Name: Dragon Warrior II (U) [LA].nes
File MD5      3AEF63A01D6F57E3BF2C865A1D919D13        
File SHA-1    F464C7045A489A248686E92164FDE2903CFD013E
File CRC32    E9F5BE99                                
ROM MD5       CCDB4563C9004D862DCF3A98C7937C22        
ROM SHA-1     191A131E7E27E121D094CC412FED87C708147B2C
ROM CRC32     8C5A784E                                

Checksums (patched):
File MD5      77FDE05D7C5D304DF794466C82AC8E94        
File SHA-1    96440BB201714B54DCDA8056ADAB6B954DEC2464
File CRC32    7DF3D301                                
ROM MD5       4373D55E7D2FDD13B6071D4178AC76FB        
ROM SHA-1     3F14277DBE356E27126B3F707D899F75E6C95979
ROM CRC32     185C15D6                                


To apply the patch:
	You will need: a copy of the Dragon Warrior II ROM and an IPS patching utility. If you don't have the ROM, go ask Google how to get it. If you don't have a patcher, I can recommend Lunar IPS (http://www.romhacking.net/utilities/240/), so snag that too. Then simply follow your chosen patcher's instructions to apply the patch to the ROM. Now that that's done, fire up your favourite NES emulator and prepare yourself for some Latin-ey goodness!

About the patch:
	In the latter half of 2018 both Chicken Knife and Choppasmith started working on script updates for Dragon Warrior II, but encountered difficulties extracting the game's main script due, as it turned out, to Dragon Warrior II not using a byte-based text encoding. Since I had recently completed my own translation of the first Dragon Warrior game and the three of us had enjoyed great success working together on their respective projects for Dragon Warrior, I decided the best way to provide knowledgeable support for their Dragon Warrior II projects was to translate the game into Latin myself. It also gave me another chance to show off abcde's capabilities and another test case to use while making improvements to abcde.

For those interested, this patch's technical highlights include:
	- updated code for converting monster names from singular to plural
	- new code for converting item names from nominative to accusative; this seemed like a better option than attempting to rewrite strings containing multiple variables of indeterminate number/gender to keep all the variables in the nominative
	- expanded length of monster and item names
	- hero name display code (including the hero name for saved games) rewritten to display full 8-character names instead of just 4-character names; you'd think this would be a 1-byte hack, but... no
	- menus expanded to display those full-length hero names (without running afoul of the very touchy code for redrawing parts of the screen when a menu closes!)
	- added hero names to per-hero sub-menus (i.e. SPELL, ITEM, EQUIP) so that you can easily tell which hero's sub-menu you're currently in; it's not like it's hard to tell where you are anyway, but given that I went to the trouble of expanding hero name display in the first place, I figured I might as well make the most of it
	- new code for printing border tiles instead of spaces when hero names are printed in borders; this originally only happened in battle when you gave the Prince of Midenhall a 1-to-3 character name but happens more often in this patch
	- new code for deactivating speech sound effect when switching between dialogue and narrative text; see especially the opening Moonbrooke sequence

Progress:
	Aside from the fancy "The End" text after the end credits, which was in English even in the original Japanese release, the remainder of the game is entirely in Latin.

Contact:
	Fan mail, insults, comments, suggestions and the like can all be sent to tempestas.caput@gmail.com where they will almost certainly all be read (unless they get filtered as spam). That said, I have been known to go for extremely long periods of time without checking my mail, so don't be upset if you don't receive a response in a timely manner!

Thanks to:
* All the helpful people who wrote the utilities and documentation I've used, particularly:
** The FCEUX development team - this patch would have been much more annoying to create without a quality debugging emulator.
** William A. Whitaker and his WORDS program for providing the world with a Latin spell-checker.