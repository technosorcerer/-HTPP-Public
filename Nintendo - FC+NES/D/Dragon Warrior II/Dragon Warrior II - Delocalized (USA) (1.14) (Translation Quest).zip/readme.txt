DRAGON QUEST II: DELOCALIZED - GODS OF EVIL

Thank you for checking out this Japanese style overhaul of Dragon Warrior 2 for the NES. The author has long felt that an uncensored and more direct contemporary English translation of the US Dragon Warrior games would be an ideal wasy to experience them. While many have a love for the medieval style of the original North American localizations or enjoy the verbose, rather silly style of the contemporary English versions, the author hopes that players will find value in experiencing a version of the game that closely represents the conventions and tone of Horii's original work.

In addition to restoring censored graphics, the entire script of Dragon Warrior II has been retranslated from scratch by a team of nejimakipiyo, primary translator, Dattebayo, our native Japanese speaking consultant and Chicken Knife, primarily responsible for polishing the script in English.

Because this patch is intended for the US Dragon Warrior II rom, all of the benefits that were added for western release have been preserved, such as battery saving and the fall of Castle Moonbrooke.

This patch is credited to the Translation Quest group, and was originally released by Chicken Knife on 12/16/2018. The authors give permission for any contents of this patch to be incorporated into other projects as long as credit is provided appropriately.

VERSION INFO

1.14 released 03/17/21
-updated the text formatting to match that of DQ3 Delocalized & more modern general standards. Made it so that clusters of short sentences are not segregated to separate lines. No changes to battle text.
-a handful of other minor text revisions.

1.13 released 11/8/20
-updated prologue to use Princess Moonbrooke's assigned name as speaker.
-updated battle text in a couple ways in order to match conventions with DQ3 while maintaining accuracy.
-used a new and unique string for end of battle victory message to eliminate repetition of "You have defeated X" - Thanks to Choppasmith for pointing me in the right direction with this!

1.12 released 8/1/20
-made numerous text improvements, including changing Jailor's Key to Jailer's Key. 
-incorporated abw's Text Sound Off patch which allowed for improved formatting of speaker notation, primarily in prologue.

1.11 released 7/8/20
-major script overhaul, with at least 80 percent of the lines of text being subject to revision. Errors from the original game were discovered and corrected (Such as text that you damaged the enemy when you actually missed them), text embellishments originally added to NA version were removed, missing Japanese text was restored, grammar/punctuation was improved, conservative updates to item and spell names and everything was subject to an intensive multi-person refinement process. 

1.10 released 7/12/19
-restoration of white cross room in Hargon's Castle--huge thanks to abw for contributing this!!!
-A few minor text corrections including wrong item name when trying to use Emblem of Roto.

1.09 released 4/7/19
-fixed a menu bug where UNCURSE appeared incorrectly--which sprang up as a result of previous fix to menu text
-introduced improved randomization method for ally name selection (thanks abw)
-minor additional improvements to intro dialogue

1.08 released 4/2/19
-tweaked intro dialogue to use princess's name, along with other changes. (thanks abw)

1.07 released 3/30/19
-completely rewritten prologue/intro text modeled after Japanese SFC version.
-fixed equip menu text bugs, SHILD is now SHIELD and DEFENC POWER is now DEFEND POWER (thanks abw for helping)
-Changed town name of Lirizia to Liriza for improved translation accuracy
-Improved appx 20 other miscellaneous pieces of text throughout the game including unclear hint information

1.06 released 3/2/19
-completely changed spell names to offer english meaning while maintaining style of Japanese words

1.05 released 2/4/19
-Significant expansions to item and monsters names (thanks abw for helping with the code to allow that)
-Thoroughly translated and revised battle text and miscellaneous text to be more faithful to the Japanese
-Went over the script for continuity revisions based on the recent updates to DQ1 Delocalized

1.04 released 12/22/18
-Several improvements to text having to do with end game sequence

1.03 released 12/20/18
-Improvements to animation frames in the title sequence.
-Minor textual improvements.

1.02 released 12/17/18
-Fixed a bug brought to my attention where the coffins appeared all blue in Rondarkia (Rhone). -Corrected a minor text issue.

1.01 released 12/16/18
-Minor improvements to the script, primarily text in Moonbrooke prior to recruiting the princess

1.00 released 12/16/18


CREDITS AND THANKS


nejimakipiyo: You have become lead translator to the project for a reason! Thank you for all your enthusiasm, dedication, resourcefulness, great ideas, unflinching criticism and most of all your friendship 

abw: this wouldn't have been possible without the help of this abw supporting every step of using his custom software abcde for the extraction, decompression, and insertion of the game's script. abw's help and support gone far beyond anything I hoped or expected. 

Dattebayo: for always being there to help us explore the finest nuances of the Japanese language.

Lady Cannock & "Some girl named Erinn": Big thanks to both of you for all the excellent contributions to our new spell naming system

Choppasmith: for being a great collaborator as we've worked together on our sister Dragon Quest projects.

x_loto: for providing a translation document for the Japanese script into English. We've gone in different directions on numerous occaisions but this served as a great base to work from.

Chris Wilder: for your support, enthusiasm and dedication testing my DQ hacks.

Paul Acevedo: It's always great to have a friend who is a seasoned writer and English teacher when taking on the monstrous threat of grammar issues

Chris Markham: for convincing me that Roto, not Loto is the official Japanese name of the legendary hero.

Shane Spafford: for the excellent suggestion of "Embalmed" for the name of the stronger Mummy type enemy

Shawn Pendergast: for keeping me in line with representing the Japanese text accurately, warts and all as you say.


BUG FIXES & IMPROVEMENTS


The following bug fixes / improvments are all by abw:
Random Name Selection
Main Script F2 Fixed
Japanese Maps Restored


GRAPHICAL CHANGES


Edits to various animation frames of Prince of Laurasia and Samaltria for title screen which both fix animation errors and make them closer resemble the Toriyama art

New Dragon Quest logo by Chicken Knife

Crosses have been restored to churches

DQ2 priest sprite has been fully restored

Coffins have been restored for dead party members


ITEMS


(original names in parenthesis)


Cypress Stick (Bamboo Stick)
Sacred Knife (Magic Knife)
Sorcerer's Staff (Wizard's Wand)
Staff of Thunder
Club
Copper Sword
Chain Sickle
Iron Spear
Falcon Blade (Falcon Sword)
Steel Sword (Broad Sword)
Giant Hammer
Sword of Destruction
Dragon Killer
Sword of Light (Light Sword)
Sword of Roto (Sword of Erdrick)
Lightning Blade (Thunder Sword)
Linen Clothes (Clothes)
Clothes of Evasion (Clothes Hiding)
Heavenly Gown of Water (Water Flying Cloth)*
Mink Coat
Leather Armor
Chain Mail
Devil's Armor (Gremlin's Armor)
Magic Armor
Steel Armor (Full Plate Armor)
Armor of Gaia
Armor of Roto (Armor of Erdrick)
Leather Shield
Shield of Strength
Steel Shield
Reaper Shield (Evil Shield)
Shield of Roto (Shield of Erdrick)
Mysterious Hat
Iron Helmet
Helmet of Roto (Helmet of Erdrick)
Emblem of Roto (Token of Erdrick)
Sunken Treasure (Tresures)
Moon Fragment
Amulet of Rubiss (Charm of Rubiss)
Evil Idol (Eye of Malroth)
Leaf of the World Tree
Echoing Flute
Mirror of Ra
Thread of Dew and Rain (Dew's Yarn)
Sacred Loom
Wind Mantle (Cloak of Wind)
Devil's Tail (Gremlin's Tail)
Warding Bell (Dragon's Bane)
Orb of Restoration (Dragon's Potion)
Gold Card (Golden Card)
Lottery Ticket
Holy Water (Fairy Water)
Chimera Wing (Wing of the Wyvern)
Golden Key
Silver Key
Jailor's Key
Watergate Key
Antidote Herb
Medical Herb
Prayer Ring (Wizard's Ring)


*The item is 'mizu no hagoromo' in Japanese. This means 'hagoromo of water'. There's no English equivalent to the word hagoromo, a celestial, magical garment that is said to make one able to fly. We had to catch that nuance in a different way.


MONSTERS


Slime
Giant Slug (Big Slug)
Iron Ant
Dracky (Drakee)
Giant Rat (Wild Mouse)
Heali Slime (Healer)
Spirit (Ghost Mouse)
Bubble Slime (Babble)
Army Ant
Magus (Magician)
Mountain Rat (Big Rat)
King Cobra (Big Cobra)
Slumbari Ant (Magic Ant)
Tuff Dracky (Magidrakee)
Armor Centipede (Centipede)
Numbing Jellyfish (Man O' War) 
Lizard Fly
Living Dead (Zombie)
Smoke
Monstrous Rat (Ghost Rat)
Mandrill (Baboon)
Man Eater (Carnivog)
Helmet Centipede (Megapede)
Sea Slug
Medusa Ball (Medusa)
Shaman (Enchanter)
Mud Doll (Mud Man)
Baboon (Magic Baboon)
Reaper (Demighost)
Gremlin
Poison Kiss (Poison Lily)
Mummy (Mummy Man)*
Gorgon Head (Gorgon)
Saber Wolf (Saber Lion)
Dragon Fly
Face Tree (Titan Tree)
Undead Man (Undead)*
Basilisk
Muddy Hand (Goopi)
Orc
Puppet Man
Embalmed (Mummy)*
Woodler (Evil Tree)
Ghast (Gas)
Rotting Corpse (Hork)
Hawk Man
Warlock (Sorcerer)
Metal Slime
Headhunter (Hunter)
Devil's Eyeball (Evil Eye)
Hibabango**
Bloody Hand (Graboopi)
Gold Orc
Messenger of Hell (Evil Clown)
Ghoul
Vapirus*** (Vampirus)
Skull Knight (Mega Knight)
Killer Tiger (Saber Tiger)
Metal Hunter
Baby Devil (Ozwarg)
Dark Eye
Gargoyle 
Orc King
Vapirus Mage (Magic Vampirus)
Berserker
Stray Metal (Metal Babble)
Hargon's Knight
Cyclops 
Killing Machine (Attack Bot)
Dragon (Green Dragon)
Devil Priest (Mace Master)
Flame
Silver Devil (Silver Batboon)
Blizzard
Gigantes (Giant)
Devil Lord (Gold Batboon)
Archdemon (Bullwong)
Atlas
Bazuzu****
Belial (Zarlox)
Hargon
Shido (Malroth)

*The weaker Mummy was originally named Mi-ra, the Japanese common word for Mummy based on the Portuguese word Mirra which translates as Myrrh. The stronger Mummy was named "Mummy" in English as a more exotic word to the Japanese audience. We followed that methodology by using the standard "Mummy" name to the weaker monster and using "Embalmed," a more exotic name for the stronger.
**Hibabango is a monster inspired by the Hibagon, a Bigfoot-like cryptid in the Hibaba mountain range.
There was no way to translate this monster name and keep the reference, so we left the name as-is.
***Vapirus is said to be inspired by the demon Vapula, despite looking nothing like a griffin or lion.
****Bazuzu is of course inspired by the demon Pazuzu.


SPELLS


Heali (Heal)
Helimi (Healmore)
Heloma (Healall)
Curii (Antidote)
Vivariku (Revive)
Flara (Firebal)
Flarama (Firebane)
Aeri (Infernos)
Ionazun (Explodet)
Exaraki (Defeat)
Sacrizaku (Sacrifice)
Slumbari (Sleep)
Stopmaju (Stopspell)
Phantasma (Surround)
Softinara (Defense)
Cosmicaos (Chance)
Fortiruto (Increase)
Flyra (Return)
Vacatara (Outside)
Trapelude (Stepguard)
Abatetoil (Repel)
Bustiero (Open)

*The translation team understands that the renaming of spells can be controversial, but they feel that neither the original English localization namings nor the contemporary version namings come anywhere near providing any kind of equivalency with the Japanese names. Therefore, the formation of a new English system was deemed a necessary part of the retranslation. The vast majority of Japanese spell names throughout the series are formed by fragments of meaningful words or contorted versions of those words, followed by exotic suffixes (and occaisionally prefixes) that expand in a way that signifies increasing power within a family of spells. In nearly all cases, the authors looked for a word in English that best represented the meaning of the Japanese base word, altered that word in an equivalent manner, and utilized the same style of suffixes that were used for the Japanese spell names. Adjustments were made for the purpose of creating words that sound good in English. The translation team hopes that the net result is a highly accurate set of names that are also memorable and fun.


LOCATIONS


Laurasia (Midenhall)
Liriza (Leftwynn)
Samaltria (Cannock)
Moonpeta (Hamlin)
Moonbrooke
Rupugana (Lianport)
Ladatorm (Tantagel)
Zahan
Beranoor (Beran)
Delkondar (Osterfair)
Pelpoi (Wellgarth)
Tepa (Tunh)
Rondarkia (Rhone)


ALLY NAMES


PRINCE--
Tonnura (Bran)
Arthur (Glynn)
Cain (Talint)
Cookie (Numor)
Conan (Lars)
Sukesan (Orfeo)
Paulos (Artho)
Rand (Esgar)

PRINCESS--
Eileen (Varia)
Akina (Elani)
Samantha (Ollisa)
Nana (Roz)
Pudding (Kailin)
Maiko (Peta)
Maria (Illyth)
Linda (Gwen)

