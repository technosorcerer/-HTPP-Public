
  Dragon Quest II Redux/Definitive Edition (Dragon Warrior II).

  The objective of 'Dragon Quest Redux/DE' is simply to restore all the elements changed from the Japanese version to the American version and also add the following improvements:

-DW II Delocalized hack v1.19 by Translation Quest (with some small touches on the title screen).

https://www.romhacking.net/hacks/4273/

-DW II DX hack v1.0 by LastDual (sprites from GBC version).

https://www.romhacking.net/hacks/3964/

-DW II Doubled XP & Gold hack v1.0 by Psyklax.

https://www.romhacking.net/hacks/3833/

I would also like to incorporate the 'Menu Upgrade' hack by abw, but unfortunately it is incompatible.

https://www.romhacking.net/hacks/4753/