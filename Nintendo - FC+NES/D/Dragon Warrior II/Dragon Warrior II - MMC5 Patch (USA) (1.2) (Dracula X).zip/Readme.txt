Dragon Warrior II
Mapper Conversion Patch
FROM Mapper 1 (MMC1) TO Mapper 5 (MMC5)
Converted by Dracula X
RELEASE DATE: 10/7/19




PRG Bankswitch Routine is at $FFC1

To switch banks from $C000 - $FFFF, use like so:

LDA bank_number
JSR $FFC1




CHR Sprite Bankswitch Routine (Left side of PPU) is at $C636

To switch sprite pages, use like so:

LDA page_number
JSR $C636




CHR Background Bankswitch Routine (Right side of PPU) is at $C64D

To switch background pages, use like so:

LDA page_number
JSR $C64D




Nametable Mapping Routine (one of its uses is mirroring) is at $C61F or $FE0C

To change mirroring for instance, use like so:

LDA mirroring_number (#$50 for Horizontal, #$44 for Vertical)
JSR $C61F

This patch does not work for:
Dragon Quest II - Akuryou no Kamigami (Japan)

Hacks supported:
Dragon Warrior II General Improvement
DW2 - Remix and rebalance
Dragon Warrior 2 - Doubled

Credits:
Rockman or RetroRain: for info on how to convert the mapper!
Disch: for his mapper docs and a better MMC5 startup!
Bregalad: for info about the game keeps on crashing!

Changes for this version 1.2:
Fixed the mirroring for ending credies screen.

Changes for this version 1.1:
Fixed the bankswitch code at location $FFC1 instead of $FF97

Non Supported Emulators:
Nintendulator
RockNES
VirtuaNES