============
Introduction
============

This is an Esperanto translation of Duck Hunt for the NES by ProManglementer. 
It is not currently complete, but the main menu and some of the in-game text is
 translated.

===============
Version History
===============

1.0 - 27 Jan 2019

* Initial Release

============
Instructions
============

The patch is provided in .bps and .ips formats. Apply it to the No-Intro 
version of Duck Hunt using your preferred patching utility.