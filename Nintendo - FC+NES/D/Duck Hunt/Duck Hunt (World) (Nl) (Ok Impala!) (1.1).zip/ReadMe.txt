﻿*****************************************************************
*Duck Hunt - Dutch Translation					*
*****************************************************************
*Game: Duck Hunt						*
*System: NES							*
*Producer: Nintendo						*
*Patch: DuckHunt(NE)v11.ips					*
*Works with GOODNES: Duck Hunt (JUE)				*
*Language: Dutch						*
*Translation: Ok Impala!					*
*Release: 	v1.0: 2002					*
*		v1.1: 2005					*
*© 2002	Ok Impala!						*
*http://www.okimpala.com					*
*****************************************************************

*****
*FAQ*
*****

What is Duck Hunt?
A great hunting game.  

What is Duck Hunt (NE)?
A dutch version of this game.

How can I play it?
Download an emulator. www.okimpala.com
Download Lunar IPS. www.okimpala.com
Download the ROM (search google)
Open Lunar IPS
Choose "Apply IPS Patch"
Choose this .ips file
Choose the rom
Lunar IPS says "The file was successfully patched!"
Open the rom with the emulator.

What should I do when I still don't understand?
Mail: info@okimpala.com

*****************
*Version History*
*****************

v1.0:	100% translation
v1.1:	Small Bugfixes

*********************************
*http://www.okimpala.com	*
*© 2002 OK IMPALA!		*
*********************************