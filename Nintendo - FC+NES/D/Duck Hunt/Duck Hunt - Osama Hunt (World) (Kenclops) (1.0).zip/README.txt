OSAMA HUNT -- 1.0 -- JUNE 06, 2002
by Kenclops
------------------------------------------------------------------------------

REQUIREMENTS TO PLAY IT:

DUCK HUNT game
FCE ULTRA OR ANY OTHER EMULATOR WITH EMULATED ZAPPER SUPPORT

------------------------------------------------------------------------------

DISCLAIMER:  This game or the author of this game is not endorsed by Nintendo, by 
the creators of Duck Hunt, or anyone that is affiliated by Nintendo.  This game 
is also not endorsed by Osama Bin Laden for obvious reasons.

------------------------------------------------------------------------------

WHAT'S NEW

Osama (or Usama, depending where you live) has replaced the ducks.
Duck icons that measure duck deaths are now Osama deaths.
Minor title screen changes

------------------------------------------------------------------------------

OBJECTIVE

Your mission is to shoot Osama Bin Laden.  Be careful, however, because the son
of a bitch can reincarnate himself.  Shoot as many Osamas as you can and meet 
the minimum required amounts of Osamas you must shoot down in order to advance
to the next round.  For real excitement, play the 2 Osamas game.

-------------------------------------------------------------------------------

Feedback:  kenclops@hotmail.com

------------------------------------------------------------------------------

WHAT's IN STORE FOR THE FUTURE:

-- CHANGE IN TITLE FROM THE "DUCK" TO SPELL "OSAMA"
-- ALTER THE GAME LAYOUT
-- NO IDEA WHAT TO DO WITH THE CLAY SHOOTINGS?  HAVE AN IDEA-- SEND ME AN E-MAIL.

------------------------------------------------------------------------------

WHAT ELSE IS IN STORE FOR THE FUTURE:

-- OSAMA HUNT 2 (HOGAN'S ALLEY HACK):  WHEN:  WHO KNOWS?

-------------------------------------------------------------------------------