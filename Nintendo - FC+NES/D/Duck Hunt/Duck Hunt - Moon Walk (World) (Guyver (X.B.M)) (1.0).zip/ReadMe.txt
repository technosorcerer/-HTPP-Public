Description:
This hack is a joke, nothing more.

Modifications:

Palette (autumn)
Music (Michael Jackson)
Text (title screen)
The dog goes moon walk ;o)

ROM / ISO Information:
Duck Hunt (World).nes - NOINTRO
CRC32: 4644085E
MD5: D802E9D7B8BFD586F878E0922F62BF46
SHA-1: 8E18068823635A115E2FC0925FF3BDA209EC6A42
SHA-256: CA0D31E6F3AA70204FA5AF67803C6533851A28FA48A133E15D772D3667FA675

My NES hacks: http://famicom.byethost7.com