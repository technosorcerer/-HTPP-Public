This is my hack and NOBODY can't copy it without my permission!!

Duck Hunt NoHead Edit
Version 1.00

Changelog (27.06.2013 for 1.00 (Poland time)):
- removed head ducks
- changed graphic shots (normally bullet to (!))
- inverted colour advance bar.