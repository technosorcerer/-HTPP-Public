Hook the hungry Haitian man with some ducks before he eats your dog! Or relieve some stress with a round of Baby Baster!

Patch to Duck Hunt (World).nes