Googie's Island - Dig Dug 2 hack
--------------------------------

This is a minor hack that puts my cartoon characters in the game to give this hack a comedy feel to it, and minor text changes in the title screen. 

Special thanks goes to...

Zynk Oxhyde: For putting my cartoons in  this hack

pacnsacdave: For making a title screen

Dr. Floppy: For making the alternate title screen

You guys kick ass!
------------------

My e-mail is googietoons(REMOVE)@gmail.com

and my Discord invite is at the following link, in case you wanna check it out ;)

https://discord.gg/pdCuD5x
--------------------------

Googie Toons is owned by me, Victor Alonzo

My Linktree if you wanna support me on my social media pages :)

https://linktr.ee/googietoons
-----------------------------   