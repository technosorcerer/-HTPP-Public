Dig Dug II - Trouble in Paradise (NES)
Traducci�n al Espa�ol v1.0 (28/03/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dig Dug II - Trouble in Paradise (U) [!].nes
MD5: 7f4d3cea6c410538995e462e11b68871
SHA1: e21a7594cd07b478c4d823eabc367a833f9adb9e
CRC32: 3cc270fb
40.976 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --