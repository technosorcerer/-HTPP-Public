With a cock strong enough to shatter the earth, spread your seed across the Orgy islands!


Patch to Dig Dug II - Trouble in Paradise (USA).nes