Notas de Traduccion "Daiku no gen-san" para "famicom" por Rockymitsu 2024

Saludos, quisiera aclarar unas cosas acerca de este trabajo que hice y por favor
lean bien para entender detalles acerca del trabajo que hice, es simple y facil de saber
lo que digo.

Notas:

Todo lo que esta en ingles dentro del juego se mantuvo por esencia de "Video Juego Retro"

Todos los dialogos de historia, o mensajes finales (que son 2) se han traducido al espa�ol

No he podido traducir el logo dentro de la rom porque me dio flojera XDD (Obviamente muchos pueden saber que "Daiku no gen-san" significa "El carpintero gen-san")

El dialogo del final se ve raro pero es porque la modifique directamente como es y no me enfoque tanto por poco tiempo que tuve de hacer muchas cosas en el dia.



Gracias por tomar tu tiempo.