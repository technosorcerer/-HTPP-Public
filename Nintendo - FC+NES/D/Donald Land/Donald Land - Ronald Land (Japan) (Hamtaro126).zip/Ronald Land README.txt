Ronald Land (Improvement of Donald Land)
By Hamtaro126
Applies to: Donald Land (J).nes, Also needs the header cleaned!

Improvements:

- Arches (the currency used in-game) are now actual arches
- Fonts are now looking better
- Changed Title to expand, The name Ronald uses extra characters due to NES graphical limits,
- And some minor textual changes as well!

Ronald, and many related characters, are Copyrighted by Mcdonald's, All of this patch is a fan tribute
to Mcdonalds!

To NESReproductions.com or RetroUSB: Thanks for thinking about downloading it, But since there can be
legal troubles with repros, Please respect the copyrights and DO NOT repro it.

Thanks to: NESDEV, SMWCENTRAL.NET, RHDN (the non-forums side), YY (YY-CHR), Djinn(Djinn tile mapper)