Dragon Warrior III
Traducci�n al Espa�ol v0.9 (02/08/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Dragon Warrior III
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Dragon Warrior III
-----------------
Dragon Warrior III es un jrpg clasico de enix, de batallas por turnos.
Este parche lo traduce completamente al espa�ol.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
Los nombres de algunos enemigos y de casi todas las magias han sido
traducidos, espero que para que se entiendan algo mas.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Dragon Warrior III (U).nes
524.304 bytes
CRC32: 0eb63e83
MD5: 3ef863d2df43e805bad70f74f0ccd909
SHA1: a867549bad1cba4cd6f6dd51743e78596b982bd8

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --