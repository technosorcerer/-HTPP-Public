 
   Dragon Quest III Redux/Definitive Edition (Dragon Warrior III).

  The objective of 'Dragon Quest III Redux/DE' is simply to restore all the elements changed from the Japanese version to the American version (with the option of keeping some of the latter) numerou bugfixes and also add the following improvements:

-DW III Delocalized hack v1.07 by Translation Quest.

https://www.romhacking.net/hacks/5466/

-DW III DX hack v1.0 by LastDual (sprites from GBC version).

https://www.romhacking.net/hacks/3965/

-DW III Doubled XP & Gold hack v1.0 by Psyklax.

In the case of the DX Hack, I had to edit some graphics such as the priests and the coffins sprites  (dead characters from battles), as they conflict with 'Delocalized' and I also made slight adjustments to the title.