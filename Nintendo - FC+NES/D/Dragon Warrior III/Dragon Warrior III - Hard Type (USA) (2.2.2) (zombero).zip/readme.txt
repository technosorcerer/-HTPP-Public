Version 2.1.4

*Changed Pilgrim and Merchant's starting armor for Cloth Armor to Clothes (this was a bug) (5/1/2016)
*Re-worked Kandar's second form (5/1/2016)
*Increased the item drop rate from the final boss gauntlet to 100% (12/24/2015)
*Fixed a Bug with Shield of Sorrow, tweaked Wizard's Ring, and reduced Staff of Change drop rate. (5/30/2015)
*Bug fixes related to female Goof-Off class change and Angel's Robe price. (5/7/2015)
*New set of balance updates and mechanics tweaks. (4/28/2015)
*The Parry Fight bug from the original game has now been fixed. (9/20/2014)
*Big updates to game file! See description for details. (2/9/2014)
