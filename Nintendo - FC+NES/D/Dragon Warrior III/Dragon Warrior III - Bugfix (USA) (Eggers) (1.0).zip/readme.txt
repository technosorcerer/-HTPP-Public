﻿Bugfix #1:

The "character creation overflow" bug.

When creating a new character, this bug would result in glitches to other
characters' spells and items, if you had reached the maximum number of
characters (eleven).

It could result in the Hero learning a lot of spells early, but not being able
to cast them outside of battle. It could also result in other characters gaining
or losing spells, or items.

This will no longer happen.

Bugfix #2:

The "baseline overflow" bug.

After a certain level, characters would stop making significant gains in stats
that they previously had high gains in. This was an error and was not intended
by the developers.

It was most obvious with the goof-off, who would stop gaining more than one
point of luck at level 25. Other characters would also experience this bug at
higher levels -- for instance, the fighter would stop gaining strength or
agility at level 55.

This has been fixed, and stat gains will now work as intended at high levels.

Credit:

A large amount of credit goes to 1whoistornapart, who shared his detailed
analysis of this game's algorithms and mechanics on the gamefaqs message board,
years ago, in threads that are now archived. He provided direct instructions on
how to fix the first bug: he identified a single byte to edit in the ROM. I
simply implemented his fix. For the second bug, I did have to track it down and
fix it myself. But it was only from 1who's analysis that I knew the bug existed,
and why it existed, in terms of the game's internal mechanics. If I had not
consulted his research, it's unlikely that I could have made this patch.
