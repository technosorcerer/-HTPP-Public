Dragon Warrior III
Mapper Conversion Patch
FROM Mapper 1 (MMC1) TO Mapper 5 (MMC5)
Converted by Dracula X
RELEASE DATE: 10/21/19




This game have two bank swapping routines at $3Cxxx and $7Cxxx
PRG Bankswitch Routine is at $FF91

To switch banks from $C000 - $FFFF, use like so:

LDA bank_number
JSR $FF91



This game have two CHR Sprite Bankswitch Routine at $3Cxxx and $7Cxxx
CHR Sprite Bankswitch Routine (Left side of PPU) is at $C668

To switch sprite pages, use like so:

LDA page_number
JSR $C668

RAM is at $06C8

This game have two CHR Background Bankswitch Routine at $3Cxxx and $7Cxxx
CHR Background Bankswitch Routine (Right side of PPU) is at $C67C

To switch background pages, use like so:

LDA page_number
JSR $C67C



This game have two Nametable Mapping Routine Bankswitch Routine at $3Cxxx and $7Cxxx
Nametable Mapping Routine (one of its uses is mirroring) is at $C64E or RAM $06C7

To change mirroring for instance, use like so:

LDA mirroring_number (#$50 for Horizontal, #$44 for Vertical)
JSR $C64E or RAM $06C7

This patch does not work for:
Dragon Quest III - Soshite Densetsu e... (Japan)

Hacks supported:
All!

Credits:
Rockman or RetroRain: for info on how to convert the mapper!
Disch: for his mapper docs and a better MMC5 startup and a new bankswitch code!
abw: for a lot of info!

Changes for this version 1.1a:
I had no idea that the game will not start because I think I messed up the bankswitch
code.

Changes for this version 1.1:
Fixed a bug that causes the script in battle while the monster drop a treasure chest.
Example: The monster name will show a Slime have drop a chest, but it's actually
a Army Crab that actually droped the chest. This bug have been fixed. It might be the
old bankswitch code that was causing it. His new bankswitch code fixed this bug.

Non Supported Emulators:
Nintendulator
RockNES
VirtuaNES