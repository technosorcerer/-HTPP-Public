c:\Rom_Editing\abcde\abcde.pl -m text2bin -cm abcde::Atlas "Dragon Quest III - Delocalized - Quest.nes" dw3_Atlas_Quest.txt

pause