DRAGON QUEST III: THUS INTO LEGEND - DELOCALIZED



FORWARD

Thank you for taking a moment to look into Dragon Quest III: Delocalized. This project has been steadily worked on for nearly 2 years, including a complete retranslation from the original Japanese text, along with numerous bug fixes, restorations and highly conservative improvements. The main idea for this project was to allow English speakers to play a version of the game that mirrors the original Dragon Quest III by being both uncensored and rigorously accurate, yet also delivered with refinement and none of the awkward language that often plagues literal translations.  

The authorship of this project is credited to the Translation Quest team, consisting of:

nejimakipiyo: lead translator, script editing

dattebayo: native speaking translation consultant

Chicken Knife: hacking, script editing, graphics



VERSION INFO

1.00 originally released 10/12/2020



CREDITS AND THANKS

abw: essential hacking support and guidance through the course of the project

Lady Cannock & erinnk: significant involvement in the creation of the new spell naming system, along with holding my hand through the process of learning how to read and write 6502 assembly language.

Chris Wilder: for steadfast support and playtesting

Shawn Pendergast: for a conversation about the Dharma shrine that shaped the direction of this project

Jen Munro: for the fabulous name "Deadly Dead" that recreates the pun of the Japanese creature name

Huma Squids: for the excellent spell name suggestion: Bustiero. Few will grasp how perfectly this mirrors the Japanese name.

Cyneprepou4uk: help with reverting the localization changes to experience accrual 



BUG FIXES / IMPROVEMENTS

Expanded character allowance for item names in vault

Changed namecheck to object to Roto instead of Erdrick

Removed extra gold / xp introduced by localized version *see below

Fixed parry bug (thanks to Zombero for info derived from his Hardtype patch)

Fixed bug with reversed ice magic spell learning 

Fixed glitched old man sprite animation

Fixed glitched female martial artist animation

Character creation overflow & baseline overflow fixes by Eggers

* Regarding the extra gold / xp:
The 1992 North American localization made the following changes to the original Japanese version: routines were introduced that boosted earned experience points by 40% and earned gold by 20%. This patch has those reward boosting routines disabled by default, so that the player can experience the game as it was originally developed. In the opinion of the authors, the restored pacing & difficulty feels much more in line with that of Dragon Quest I and II, & therefore provides the feeling of a more cohesive trilogy. However, the authors understand the diversity of opinion on issues like grinding & overall difficulty. Therefore, an optional patch was included called dw3_revert_localized_rewards.ips. This patch should be applied *AFTER* the main patch, *ONLY* if the player does not want to experience the original, more challenging difficulty curve.



GRAPHIC CHANGES

All new title screen displaying the name DRAGON QUEST III: THUS INTO LEGEND

Restored uncensored Dharma Temple map *see note below

Restored uncensored Lanceal Temple map

Restored uncensored Necrogond Shrine map

Restored crosses on churches

Restored Japanese grave markers

Restored original shrines

Restored coffins for dead characters and in Pyramid

Restored original king, priest, old man, & pilgrim sprite

* About the Dharma tile map:
Decensoring the background in the Dharma temple has led us to restoring a left-facing swastika symbol. We understand the unfortunate sensitivities that use of this symbol might provoke. It should be known that, while similar in appearance, this symbol is not be confused with the Nazi usage of the right-facing swastika, as the the usage in this game derives from Asian religious tradition, predating that of Nazi Germany's use. In Hinduism and Buddhism, this symbol represents well-being, prosperity and good luck. The name, Dharma, is another link to Asian religious tradition. Based on this name, along with this region's general theme of 'enlightenment', we can better understand the cultural relevance of this symbol's use as something wholly distinct from the way it has been warped. The authors' intentions are strictly to restore that aspect of Asian culture and religion, as per the original design by Horii.



CLASS NAMES

Hero
Wizard
Priest (Pilgrim)
Sage
Warrior (Soldier)
Merchant
M. Artist (Fighter)
Goof-Off



LOCATIONS

Aliahan
Reive (Reeve)
Romalia (Romaly)
Kazav (Kanave)
Champagne (Shanpane)
Noaniel (Noaniels)
Assalam (Assaram)
Isis
Portoga
Baharata
Dharma (Dhama)
Muor
Jipang
Tedan (Tedanki)
Sioux (Soo)
Edinbear (Eginbear)
Lanceal (Lancel)
Luzami
Samanosa (Samanao)
Ladatorm (Tantagel)	
House of Garai (House of Garin)
Domdora (Hauksness)
Maira (Kol)
Melkido (Cantlin)



SPELLS

Seara (Blaze)
Searami (Blazemore)
Searazoma (Blazemost)
Flara (Firebal)
Flarama (Firebane)
Flaragon (Firevolt)
Io (Bang)
Iora (Boom)
Ionazun (Explodet)
Frosto (Icebolt)
Frostaru (Snowblast)
Frostdain (Icespears)
Mafrosto (Snowstorm)
Aeri (Infernos)
Aerima (Infermore)
Aericross (Infermost)
Shockzolt (Zap)
Gigazolt (Lightning)
Exaki (Beat)
Exaraki (Defeat)
Sacrizaku (Sacrifice)
Banishasu (Expel)
Flyrago (Limbo)
Sapmaju (RobMagic)
Decelera (Slow)
Accelera (Speedup)
Heali (Heal)
Helimi (Healmore)
Heloma (Healall)
Helomara (Healus)
Helomazun (Healusall)
Vivaru (Vivify)
Vivariku (Revive)
Slumbari (Sleep)
Rousima (Awaken)
Stopmaju (StopSpell)
Phantasma (Surround)
Flyra (Return)
Optipani (Chaos)
Replicato (Transform)
Dragorum (Bedragon)
Ferreron (Ironize)
Softani (Sap)
Softinara (Defense)
Fortara (Upper)
Fortiruto (Increase)
Mirromaju (Bounce)
Insularo (Barrier)
Ampiruto (Bikill)
Cosmicaos (Chance)
Curii (Antidote)
Curiku (Numboff)
Hexagone (Curseoff)
Abatetoil (Repel)
Timefutra (Day-Night)
Bustiero (Open)
Probasu (X-Ray)
Vacatara (Outside)
Invisara (Invisible)
Trapelude (StepGuard)

*The translation team understands that the renaming of spells can be controversial, but they feel that neither the original English localization namings nor the contemporary version namings come close to providing equivalency with the Japanese naming system. Therefore, the formation of a new English system was deemed a necessary part of the retranslation. The vast majority of Japanese spell names throughout the series are formed by fragments of meaningful words or contorted version of those words, followed by exotic & epic sounding suffixes (and occaisionally prefixes) that expand in a way that signifies increasing power within a family of spells. In nearly all cases, the authors looked for a word in English that best represented the meaning of the Japanese base word, altered that word in an equivalent manner, and utilized the same style of suffixes that were used for the Japanese spell names. Adjustments were made for the purpose of creating words that sound good in English or for fitting the names within the 9 character limit. The translation team hopes that the net result is a highly accurate set of spell names that are also memorable and fun.



ITEMS

Cypress Stick
Club
Copper Sword
Sacred Knife (Magic Knife)
Iron Spear
Iron Axe (Battle Axe)
Steel Sword (Broad Sword)
Sorcerer's Staff (Wizard's Wand)
Poison Needle
Iron Claw
Thorn Whip
Giant Shears
Chain Sickle
Raijin Blade (Thor's Sword)
Blizzard Sword (Snowblast Sword)
Titan Axe (Demon Axe)
Raincloud Staff (Staff of Rain)
Sword of Gaia
Staff of Reflection
Sword of Destruction
Double-Edged Sword (Multi-edge Sword)
Staff of Force
Blade of Temptation (Sword of Illusion)
Zombie Killer (Zombie Slasher)
Falcon Blade (Falcon Sword)
Giant Hammer (Sledge Hammer)
Lightning Blade (Thunder Sword)
Staff of Thunder
Blade of Kings (Sword of Kings)
Kusanagi Blade (Orochi Sword)
Dragon Killer
Staff of Judgment
Linen Clothes (Clothes)
Training Uniform (Training Suit)
Leather Armor
Flashy Clothes
Iron Armor (Half Plate Armor)
Steel Armor (Full Plate Armor)
Magic Armor
Clothes of Evasion (Cloak of Evasion)
Armor of Light (Armor of Radiance)
Iron Apron
Cat Suit (Animal Suit)
Fighting Uniform (Fighting Suit)
Magical Vestment (Sacred Robe)
Hell Armor (Armor of Hades)
Heavenly Gown of Water (Water Flying Cloth)
Chain Mail
Traveler's Clothes (Wayfarer's Clothes)
Dangerous Swimsuit (Revealing Swimsuit)
Magic Bikini
Shell Armor
Earth Armor (Armor of Terrafirma)
Dragon Mail
Razor-Edged Armor (Swordedge Armor)
Angel Robe (Angel's Robe)
Leather Shield
Iron Shield
Shield of Strength
Shield of Heroes
Shield of Grief (Shield of Sorrow)
Bronze Shield
Mirror Shield (Silver Shield)
Golden Crown
Iron Helmet
Mysterious Hat
Helmet of Sorrow (Unlucky Helmet)
Turban
Hannya Mask (Noh Mask)
Leather Hat (Leather Helmet)
Iron Mask
Sacred Amulet
Ring of Life
Shoes of Happiness
Golden Claw
Falling Star Bracelet (Meteorite Armband)
Enlightenment Tome (Book of Satori)
Prayer Ring (Wizard's Ring)
Black Pepper
Sage's Stone
Mirror of Ra
Vase of Thirst (Vase of Drought)
Lamp of Darkness
Staff of Morphing (Staff of Change)
Stone of Life
Vanishing Herb (Invisibility Herb)
Magic Ball
Thief's Key
Magic Key
Final Key
Dream Ruby
Powder of Waking (Wake Up Powder)
King's Letter (Royal Scroll)
Orichalcum (Oricon)
Strength Seed
Agility Seed
Vitality Seed
Luck Seed
Intelligence Seed
Life Nut (Acorns of Life)
Medical Herb
Antidote Herb
Holy Water (Fairy Water)
Chimera Wing (Wing of Wyvern)
Leaf of the World Tree (Leaf of World Tree)
Memory of Love (Locket of Love)
Full Moon Herb
Water Gun (Water Blaster)
Sailor's Bone (Sailor's Thigh Bone)
Echoing Flute
Elven Flute (Fairy Flute)*
Silver Harp
Orb of Light (Sphere of Light)
Poison Moth Powder
Spider Web (Spider's Web)
Stone of Sunlight (Stones of Sunlight)
Rainbow Drop
Silver Orb
Red Orb
Yellow Orb
Purple Orb
Blue Orb
Green Orb

*Whenever a Japanese weapon name used the word "tsurugi", we translated as "sword". Whenever a Japanese name used "ken", we translated as "blade". There is little distinction between the two words in Japanese.

*The Japanese word "yosei" used in this name could refer to either elves or fairies, broadly referring to a variety of western sylvan creatures. The authors settled on elven being the better translation for two reasons. First, the same word is used to refer to the humanoids living west of Noaniel, who are clearly elves and not fairies. Since there is a direct presence of elves in the Roto trilogy, it would make more sense that the flute would have been crafted by them. Second, in discussion with native Japanese speakers, it was determined that our understanding of an elf is the first thing that comes to their mind when they hear "yosei".


MONSTERS

Slime
Giant Crow (Black Raven)
Horned Rabbit
Giant Anteater
Man-Faced Butterfly (Masked Moth)
Frogger (Froggore)
Bubble Slime (Babble)
Magician
Scorpion Wasp
Heali Slime (Healer)
Monstrous Anteater (Demon Anteater)
Al-Mi'raj (Spiked Hare)*
Poison Toad
Caterpillar
Bat Man (Humanabat)
Zombie Mutt (Putrepup)
Killer Bee
Army Crab
Gizmo (Gas Cloud)*
Matango (Demon Toadstool)*
Poison Hornworm (Poison Silkworm)
Death Flutter (Avenger Raven)
Buried Dog (Madhound)
Monstrous Mushroom (Deadly Toadstool)
Suspicious Shadow (Shadow)
Vampire
Man-Eating Moth (Man-Eater Moth)
Wandering Armor (Rogue Knight)
Flying Cat (Vampire Cat)
King Toad (King Froggore)
Raging Gorilla (Wild Ape)
Laughing Bag (Trick Bag)
Mummy (Mummy Man)
Hell Claw (Infernus Crab)
Druid (Lumpus)
Flame Centipede (Flamapede)
Embalmed (Mummy)
Matango Mage (Mage Toadstool)
Hunter Fly
Death Jackal (Avenger Jackal)
Illusionist (Nev)
Heat Gizmo (Heat Cloud)
Antbear (Tongue Bear)
Heloma Slime (Curer)
Mad Goat (Rammore)
Cat Bat (Catcula)
Evil Mage
Killer Ape (Simiac)
Garuda
Metal Slime
Ramming Goat (Goategon)
Cutthroat (Executioner)
Baby Satan (Demonite)
Menacing Hermit (Deranger)
Man-Eating Chest (Man-Eater Chest)
Eliminator
Great Beak
Snail Slime (Slime Snail)
Sky Dragon
Barnabas
Witch	
Dead Pecker (Avenger Beak)
Hell Armor (Infernus Knight)
Marine Slime
Numbing Jellyfish (Man O'War)
Merman (Merzon)
Giant Squid (King Squid)
Crabzilla (Crabus)*
Mermandine (Merzoncian)
Hell Condor (Hades' Condor)
Brave Bear (Fierce Bear)
Rotting Corpse (Hork)
Bighorn
Numbing Swallowtail (Stingwing)
Deadly Dead (Venom Zombie)
Achaierai (Blue Beak)*
Killer Armor (Lethal Armor)
Death Stalker (Avenger)
Lava Titan (Lava Basher)
Witch Doctor
Magic Hag (Old Hag)
Shade (Terror Shadow)
Glacier Titan (Glacier Basher)
Chimera (Wyvern)
Kong
Tortragon
Bird of Paradise (Elysium Bird)
Bomb Boulder (Bomb-Crag)
Grizzly
Zombie Master (Voodoo Shaman)
Tortragon Lord (King Tortragon)
Snow Dragon
Troll
Frost Gizmo (Frost Cloud)
Dancing Jewels (Dancing Jewel)
Mini Demon (Minidemon)
Tentacles
Skeleton Swordsman (Skeleton)
Mimic
Hell Knight (Marauder)
Hologhost
Orochi*
Animated Statue (Stone Hulk)
Salamander
Slime Bess (Red Slime)
Muddy Hand (Goopi)
Archfiend's Shadow (Vile Shadow)
Macumbeiro (Voodoo Warlock)*
Stray Metal (Metal Babble)
Ghoul
Lionhead
Boss Troll
Goldman (Gold Basher)
Skullgon (Scalgon)
King Merman (King Merzon)
Kraken (Kragacles)
Darth Werebear (Darthbear)
Grand Titan (Granite Titan)
Ragonne (Leona)*
Archmage
Chimera Mage (Magiwyvern)
Satan's Puppy (Winged Demon)
Hydra
Troll King
Dragon (Green Dragon)
Balrog (Barog)
Zombie Dragon (Putregon)
Mantigore (Lionroar)
Swordoid
King Hydra
Baramos
Baramos Brother (Baramos Bomus)
Zombie Baramos (Baramos Gonus)
Zoma
Ortega
Kandata (Kandar)*
Kandata's Henchman (Kandar Henchman)

*Almiraj, or Al-Mi'raj is a creature in Islamic mythology. The Japanese name arumiraaji references this monster.

*Gizmo derives from a book called War with the Gizmos by Murray Leinster.

*Matango derives from a 1963 Japanese horror film of the same name that involves a species of mutagenic mushrooms.

*The Japanese name of the monster is Ganirasu. Gani means crab and the ~rasu is a suffix used commonly in kaiju names to sound stronger. Crabzilla was the obvious solution.

*Achaierai is a D&D monster.

*Orochi is Yamata no Orochi, a giant 8-headed and 8-tailed serpent from Japanese Mythology.

*Macumbeiro is a practitioner of Macumba witchcraft, originating in Brazil. That seems to be the intention of the Japanese name "makurobeta".

*The Japanese name of Ragonne is Ragonnu, which seems to reference the D&D creature Dragonne--a hybrid of lion and dragon. 

*Kandata is the name of a criminal protagonist in a short story by Ryunosuke Akutagawa, entitled "The Spider's Thread".



COMPANION DEFAULT NAMES

Han Solo	(Brindar)		
Stallone 	(Ragnar)
Ben Hur 	(Adan)
Elias 		(Glennard)
Kid 		(Theron)
Romeo 		(Elucidus)
Ilya 		(Harley)
Marlene 	(Matthias)
Alan 		(Sartris)
Smith 		(Petrus)
El Cid 		(Hiram)
Nikolai 	(Viron)



MISCELLANEOUS SCRIPT NOTES

"Now, let's get you dressed up appropriately" - This was added to the king of Romalia's speech after returning the Golden Crown to smooth out the awkwardness of a female character transitioning into the new "king". 

Nord, the dwarf - The Japanese game has him being referred to as a hobbit, but the project authors were supsicious of this since he lives under a mountain, wields a shield and axe, wears heavy armor, has a beard and has a very  gruff and inhospitable attitude. Research was done, and it was determined that Horri originally intended that he be a dwarf, but this was not possible because the katakana character of "Wa" did not fit in the game's memory. Therefore, Nord nominally became a hobbit in spite of all his characteristics being dwarven. While it was a difficult translation choice, the authors of this project have chosen to fulfill Horii's original intention and present him as a dwarf.