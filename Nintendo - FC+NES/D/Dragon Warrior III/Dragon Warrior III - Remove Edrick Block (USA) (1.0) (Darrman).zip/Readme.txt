REMOVE ERDRICK BLOCK
22/05/20

Dragon Warrior 3 doesn't let you name the protagonist "Erdrick".
When you try to do that, it tells you to "INPUT YOUR NAME!".
This patch removes the restriction on naming Erdrick "Erdrick".

Included is a file of notes that I took while making this hack. They describe what must be modified to change the blocked name.

- Darrman