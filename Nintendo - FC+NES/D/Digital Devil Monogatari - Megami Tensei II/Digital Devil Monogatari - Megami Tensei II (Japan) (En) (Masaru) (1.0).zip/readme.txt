デジタル・デビル物語 女神転生II (Digital Devil Story: Megami Tensei II) - Japanese Logo Patch
by Masaru

Description:
The purpose of this patch is simply restoring the japanese logo back to the
Fan-translation made by Stardust Crusaders. Nothing else was changed.

Patching:
Use a patching tool (Like Floating ips, Unipatcher or an online patcher)
and patch it to either one of the two roms, depending of which rom you have

(JP Rom) is for the japanese rom:
Database match: Digital Devil Story - Megami Tensei II (Japan) (Rev A)
File SHA-1: EE3BF7B6EFF07316DF1B4C7EE0FCB2C4989961C1
File CRC32: 59489AA8
ROM SHA-1: 4FE1D7FEDB5416CD8E4E2488B9056073AD401B3C
ROM CRC32: 10C9A789

(FTL Rom) is for an already pre-patched rom with the fan-translation:
Digital Devil Story - Megami Tensei II (T+Eng)(Stardust Crusaders v1.04)
File SHA-1: 1DBB69BC67EAF369B20ED9C024E728795E0D5871
File CRC32: E74E6DD4
ROM SHA-1: 2845300DEC42F052BDA7AD3D6ABE5A58815F0F3B
ROM CRC32: 1E9FC80B

Patching issues:
It is very recommended to patch with the japanese rom patch.
This is because the rom that the fan-translation needs from
patching is a bad dump rom of the game, having different
hashes and CRCs to a clean rom

CRC from a Clean rom:
File CRC32: 59489AA8
The CRC from the rom the fan-translation wants:
File CRC32: CBB8C4CC

Original Credits:
Pennywise/abw - Hacking
Tom - Translation
FlashPV - Graphics
Almendrita/FCandChill - Manual Translation
