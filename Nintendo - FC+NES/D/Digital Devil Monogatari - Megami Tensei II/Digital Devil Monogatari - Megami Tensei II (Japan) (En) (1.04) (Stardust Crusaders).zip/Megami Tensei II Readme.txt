======================Digital Devil Story================
=======================Megami Tensei II==================
===========================V 1.04========================
Genre: Role-playing

Source language: Japanese

Platform: Famicom

Patch language: American English

Author: Pennywise/Tom

E-mail: antoniusblocko@protonmail.com
		
http://yojimbo.eludevisibility.org/
 
======================================================
Project history and hacking notes
======================================================

This project was originally discussed way back when
we released our 1.0 translation for the first game.
For various reasons, work never began on it until
years later.

This project owes a great debt to abw, the person who
maintains the script extraction/insertion program abcde.
This game uses a complicated scripting system with
non-script data embedded into the script.
It made getting a clean rip of the script a problem,
but abw took care of that and paved the way for the
translation to truly start.

Anyhow, the project began a little over a year ago and
a lot of time and effort has gone into it.

-The ROM has been expanded and various blocks of text
have been relocated to take advantage of that space.

-There were various blocks of data stored in the CHR-ROM
that have been moved and converted to load from the PRG-ROM
as well. The intro screen with text is one such example.
The programmer likely did this because they ran out of the
space for the data in the PRG-ROM. This is no longer an issue
with the expanded ROM.

-Demon names have been expanded to 12 letters and corresponding
menus have been hacked to seamlessly accommodate the expansion.
A side effect of this expansion is that max HP will no longer
display on the bottom menu; a worthy sacrifice in my opinion.

-Demon class names have also been expanded so that text like
"One True God" is loaded and displayed properly.

-Item names have been expanded to 12 characters and item displays
have been hacked to 1 column per row instead of 2 per row.
A side effect of this change was that there wasn't enough screen
space to display items on 1 screen.

-You can now switch between item pages by pressing left/right.
The hack is not 100% perfect, but it's functional and was a lot
of work to get working. The hack was further complicated by
sharing code with the spells.

-Spell names have been expanded as well and the above hack is also
applied to spells. Your female partner can learn more than 12 spells
if you level her up enough.

-Player names can now be up 10 to letters from the original 8.
A side effect of this change is that the easter egg in RAM,
"PROGRAMMED BY COZY" has been removed to take advantage of
the unused RAM.

-The sprite error with YHVH has been fixed.

-Various other menus and interfaces have been extensively
hacked for this translation.
======================================================
Version History
======================================================
V 1.0 - initial release
V 1.01 - minor text fix
V 1.02 - various bug fixes, minor text updates
V 1.03 - minor player name bug fix
V 1.04 - minor text updates and bugfixes

======================================================
Notes from the translator
======================================================

A few points that should be clarified about this translation:

- This is an original fan translation, unrelated to the
  Super Famicom remake's translation.

- The script and graphics were translated directly from
  Japanese to American English.

- The terminology and spellings used in the patch do not
  necessarily match up with other translations (but are no less valid).

- The translated manual and packaging is also available with
  this patch, so please give them a look, and feel free to
  create your own "real" package (if you'd like).

======================================================
Patching Instructions
======================================================
Due to limitations in the IPS format and the changes I
made to the ROM, I'm only supporting BPS and xdelta formats
for this game. You can download a program to patch from here:

https://www.romhacking.net/patch/

Apply the patch to the Japanese ROM:

Digital Devil Monogatari - Megami Tensei II (Japan)(Rev A).nes

We would be highly grateful, if you find some time to 
contact us with proposals or corrections. Information
on found bugs or corrections would be highly 
appreciated.

P.S.

Support the game industry by buying used games!

Even if the money doesn't go to the developers
directly, as the games become rare and harder
to find, the price goes up, and people become
more inclined to buy new releases "while they can!"

======================================================

Credits go to:

Pennywise - hacking

Tom - translation

abw - script extraction

FlashPV - title screen design

cccmar - testing

Xanathis - testing

All those who contributed into this process.

======================================================


Compiled by Pennywise. April 2022