Donkey Kong Jr. Math (NES)
Traducci�n al Espa�ol v1.0 (12/03/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Donkey Kong Jr. Math (U) [!].nes
MD5: ed081b5c6dbddd623a845f0d27b4a288
SHA1: f05e358803ee665aca2f84a34d9010d01e604b2b
CRC32: 67193fc8
24.592 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --