   >xy**34(ab)+=->= .. x#%=6x#%=(8)*x-  =++45#77/~*77-+=>4(ab)  ^(bh +/- dn)f(x 
 ->=++45#77/~*77-+=>#34456x#%^>xy**34(ab)804>=++46x#%=6x#%=(8)*x-.x*^675(c&#fuckk
 %#1           `        6+-         `    +=^      *xf        - ~(x)       77*ekd
  =  /��\/�����Y������\  1 /��������Y��\  ____\��\_____ \��\         \��\  *8563
 ^7  �\   /���\ /���\  \   ;  :����\    \ \_____   ____\ \  \_________\  \__  ^
  +%>  \  \    y     \  \  \  \     :    \      \  \     \_   __________   _\ 154
  (77)  \  \          \  \_ \  `-___1     \_     \  \      \  \         \  \  +/-
 1337=  /___\         /____\ `-________^____\     \  \      \__\         \__\  .
 xy**3                                             \ /             46*re      /
  6^4%(456447%              /��`                    V                   77234%
   %^>xy**34(   _____    ___\___    /����\    Y�����`    _____    >=++46x#%=6
  59(456-+=44    _____       \      \     \    \          _____    4646*84
  8                          /       \____/     \                   33590-+x(q)
 . /�����Y������\                                                             '16
 1 �\        o  /       /�����\\�������\\������\ /������\\�������\ /��������\  bhdn
  /  \     _    ����\   \ \��\_\���\ \�/������  \\ \���\_\�\      \     ____/  bitch
  77  \    \����\    \   \ \        \ \\   o     \\ \       \      \ _____ \  niggas
 272   \    \    \    \   \ >  __    \ \\         \\ \       \   o  \       \ 4^56%21
  ^54   \    \    \    \_ / \__\ \    \ \\        / \ \      _\     /       / 34
 54356  /_____\   /______\\_______\    \_\\______/   \_\     \_____/ \_____/ `126%=
   6(                                                                           09-65
  .4^780x#342%568  21321487$%67687.  45454354  6789985%342=()e45+=4532-*xf(f)34234  .
 x- =++45#7%^>x%^>x%^>x=++46x#%=6x#%=(8.lordprettyflackojodye7733590-+x(q)536890*
  \/67  5t5758   (456   456456    7  6757  2234(457   8%%%% 45323   %^  ()6 576
    .    .         .       .          .     .               .            .          
    (also known as "MATH FOR RETARD5")              starring MONKEY DONKEY

"all semblance of 'will this look any good' are going out the window" (sic)
    - el kadong

"math is for faggots"
    - anal cunt

"don't do <del>meth</del> math"
    - raul julia

"you can try as high as you goddamn please and it doesn't make a bit of
difference to [Monkey Donkey], so stop bothering him already or you'll be
taking your meals through a straw for the next two weeks."
    - Zartan, Zeroes Unlimited
    http://sliverx.arc-nova.org/zeroes/arcade.html

"anyways I think I'm going to give up and only release one version of
 math for retards because I'm lazy and expending effort is for suckers"
    - el kadong

+==================================================+===========+
| el kadong black box series #10: Math for Retards | Education |
| video game hack by el kadong, 2016               |  Mockery  |
| licensed to baddesthacks.net                     |   Series  |
+==================================================+===========+

this is probably the best AND worst romhack ever created
so please send all award money and/or prizes to

el kadong
p.o. box 737750177
mars, the milky way galaxy

peace and thank you

p.s. if this hack offends you

good

i still don't give a fuck

- <del>eminem</del> el kadong

================================================================================
THE PATCHING INFORMATION

Should you be bored enough to actually want to play this hack...

The original rom is "Donkey Kong Jr. Math (USA, Europe).nes"
and the hashes are...

  MD5: ED081B5C6DBDDD623A845F0D27B4A288
SHA-1: F05E358803EE665ACA2F84A34D9010D01E604B2B

One versions of the hack are included:
2) tardmath2.ips - The "New Expanded Edition"

***DO*** play the New Expanded Edition.
You will be even MORE confused than you already are.

================================================================================
A LOT OF WANKY WORDS TO EXPLAIN WHAT'S HAPPENING, SOMEWHAT

This hack doesn't really merit commentary, but in case you want to have some
sort of idea of what was hacked...

IMPORTANT NOTE
--------------
Figuring out the new mathematical operators is an exercise left to the player.

EASY MATH, HARD MATH
-----------------------
I changed some palettes. Player 2 is now "Blue Berry Kong", for lack of a better
name. Instead of "WIN." there's "METH", and you win piles of meth instead of apples.

meth for retards

now, first to 3 meth piles wins, because who the fuck is going to try to play
to five victories in this shitpile of a game???

+-x% EXERCISE
-------------
no i don't want to grab the proper characters for this text file, suck it

if you suck at math, there's a thing on the left that will tell you the answer.
you won't get shit though.

the bird on the left is a dong. getting the answer right now gives you a turd.

the bird on the right got replaced with a mongoloid or some shit, I don't care.

================================================================================
THE CREDITS
* all hacking (graphics, code) by el kadong
* the cool ascii art by tettsui77, thanks bro
* marijuana, for inspiring the hack and being a large driver of its content
* baddesthacks.net, the only place i could possibly release something like this

SPECIAL THANKS
* meth user 2929, for using meth 2929 times
* meth on napkins, which is where meth user 2929 got part of his stash from
* anal cunt, because they're great. RIP seth putnam

NO THANKS
* everyone who thinks romhacking needs to be serious
* everyone who gets offended over this hack
* bitch niggas

SORRY TO
* actual retarded people
  you won't actually learn math from playing this game

================================================================================
OTHER INFORMATION

I showed this hack to an extraterrestrial being who claimed to have math
knowledge and here's what they had to say:

dalkhfaqnt098vq t7qp9cyt9 qaoirhbhtp9iawo4jt1q$%!$%~R#JFIYVX87R`P4R`~#$R%!$TqfgRE
poreu`9y51vc45!^$!@^$YTquojfradFAFGa43t5uq'45Q#$%!@$5pn9akpgrftgAW%Y^E&^IT*GOLY)P
E%!Q#$%QJ06wb0o3p6taWERTQPOJB6ewrfg.hytju^&(I&*)(sFGSRtw456d?l,l[,;l,'

unfortunately i have no idea how to translate this to english, so if you do,
please let me know; up until this point, all communication was telepathic,
but seeing the hack broke the dude

i'm sorry if this causes some intergalactic war

================================================================================
POSTSCRIPT

i, the undersigned, do believe this hack exudes the qualities of everything a
"badhack" should have, and am proud of this fact.

signed,
el kadong
2016/09/27 (that iso date format thing, you pisspot wankfisters)

================================================================================
POSTSCRIPT 2

what should have been a relatively short hack to make has turned out to be a bit
more involved than originally necessary. at the start, there were no plans to make
an "expanded edition". however, it became necessary once I realized how hilarious
it would be to have things not even perform the correct looking operation.
everything else just snowballed from there, to the point where I decided "fuck it,
I'm going to swap out some code for more efficient code", which has resulted in
the music being hilariously off.
