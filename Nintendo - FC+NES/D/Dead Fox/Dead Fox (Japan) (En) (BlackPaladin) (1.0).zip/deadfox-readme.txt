-------------------------------------------------------------
-BlackPaladin's The Human Weapon: Dead Fox Translation Patch-
-------------------------------------------------------------

************************
*Ningen Heiki: Dead Fox*
************************


Ningen Heiki: Dead Fox is a run 'n gun game with platforming, released by Capcom.  This game is a blatant knockoff of the classic arcade game "Rolling Thunder".

This game was released in the United States under the name "Code Name: Viper". This patch changed the game how it originally was.

This game comes in four flavors...

The Human Weapon - Dead Fox (English).ips
--Translation patch for JPN ROM (IPS Format)
The Human Weapon - Dead Fox (English).bps
--Translation patch for JPN ROM (BPS Format)
The Human Weapon - Dead Fox B (English).ips
--Translation patch for USA ROM (IPS Format)
The Human Weapon - Dead Fox B (English).bps
--Translation patch for USA ROM (BPS Format)

If you're using the Japanese ROM for patching, use either the IPS or BPS patch that contains the file name "The Human Weapon - Dead Fox".  (Don't use both patches.)  Make sure the ROM has the following hashes.

File SHA-1: 4469CB270017D6F6319385E0A1FC5ABCAD2C69D1
File CRC32: 95A79DE2
ROM SHA-1: 572F719D09C6538477AF240C81950D43B133C480
ROM CRC32: 2E1E7FD8

If you're using the "Code Name: Viper" USA ROM for patching, use either the IPS or BPS patch that contains the file name "he Human Weapon - Dead Fox B".  (Don't use both patches.)  Make sure the ROM has the following hashes.

File SHA-1: 4C86AE577454B6DE9A3FE48ACBB7F095C8B82D3B
File CRC32: 5988DA29
ROM SHA-1: 220939191A48FB2CF3A73C8FD713A60AD2EE34DF
ROM CRC32: E2313813

The end result will be the patch with the following hashes.

File SHA-1: C71699B048598A151ABB93A7BE20C236208BA327
File CRC32: DCC8C8E3
ROM SHA-1: 69AD9968DFFAC202AADCEF2DBDE51AF019E8DC7A
ROM CRC32: 1C003AC

What's done?

Translated Title Screen
English font applied
All Japanese text translated to English

Special Thanks
FCE Ultra Team (Emulator was used to test the translation patch)
Mesen Team (Emulator was used to test the translation patch)
YY-Char Team (This program was used to edit the graphics in the game)
giblet92 (Japanese to English Translation)
FCAndChill (Title Screen Design & ROM Hacking)

All credits to "The Human Weapon: Dead Fox" belong to their respective creators and programmers.  This patch is mainly for pure entertainment for those who cannot enjoy the game.  All right reserved.  (Capcom, please don't come after me!)