+---------------------------------------+
| Donkey Kong: Kill-Screen Variety Pack |
+---------------------------------------+

  | Overview
  +--------------------------------------
    A variety pack of kill-screen hacks for use with Donkey Kong: Original Edition, which has the cement-factory stage.


  | Features
  +--------------------------------------
    - Fixes NES kill-screen that occurs on Loop 133.
	- Fixes bug that caps bonus points to 8,000 instead of 9,000.
	- Bonus hack: reinserts a kill-screen inspired by the American-Arcade kill-screen on board 117.
	- Bonus hack: reinserts a kill-screen inspired by the Japanese-Arcade kill-screen on board 85.

    For a demonstration of these features, see the video section below.


  | Video
  +--------------------------------------
    https://www.youtube.com/watch?v=jeICEDkBhSA


  | Resources Used
  +--------------------------------------
 	Nathan Altice, Porting the Kill Screen
	http://metopal.com/2012/03/24/porting-the-kill-screen/
	
	Jeff Kulczycki, What's with the Kill Screen?
	http://www.jeffsromhack.com/products/donkeykong_tech.htm
	
	Don Hodges, How High Can You Get?
	http://donhodges.com/how_high_can_you_get.htm
    

  | Tools Used
  +--------------------------------------
    - FCEUX
    - Lunar IPS


  | Platform
  +--------------------------------------
    Nintendo Entertainment System (NES)


  | Game Credits
  +--------------------------------------
    - Nintendo, developer of the original game.


  | Version History
  +--------------------------------------
    Version 1.0 created March 31 - April 1, 2023 and submitted on June 11, 2023.


  | License
  +--------------------------------------
    MIT License


  | Creator
  +--------------------------------------
    clymax
    https://twitter.com/clymax