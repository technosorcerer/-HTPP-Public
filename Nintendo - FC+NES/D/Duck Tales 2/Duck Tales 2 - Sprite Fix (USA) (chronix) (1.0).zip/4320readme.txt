Duck Tales 2 Sprite Fix

Hacked by Andrei Vdovin a.k.a. Chronix
Email me if you find any glitches in my hack.
Thanks in advance!
chronix@bk.ru

This game is an 8-bit masterpiece, but it has few insignificant flaws.

* Dialog portraits of Scrooge, Launchpad, Gyro and Glomgold are shifted down by one pixel
* Niagara Falls sprites (on the map) are shifted right by one pixel
* When you fly back home with Launchpad, tail fin of the plane shivers

My patch will help you fix these flaws and enjoy the game.



Original ROM:
-----------------------
Duck Tales 2 (U) [!].nes
File size: 131 088

 PRG ROM:    8 x 16KiB
 CHR ROM:    0 x  8KiB
 ROM CRC32:  0x73c7fcf4
 ROM MD5:  0xb8592879590cddec02fe077217562d00
 Mapper #:  2
 Mapper name: UNROM
 Mirroring: Vertical
 Battery-backed: No
 Trained: No
