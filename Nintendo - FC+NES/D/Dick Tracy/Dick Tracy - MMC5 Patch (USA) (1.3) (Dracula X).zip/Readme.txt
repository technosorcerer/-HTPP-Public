Dick Tracy Mapper Conversion
From UNROM to MMC5 (from UNROM to Mapper 5)
by Dracula X

RELEASE DATE: August 14, 2019
Last Modified: August 18, 2019
TIME SPAN FROM START TO FINISH: 1 Day

Bankswitch:
To use it, all you have to do is select a bank and jump to it.

LDA bank_number
JSR $FFB0

I had to expand the ROM because Dick Tracy had a little of free space in hardwired bank.

You can also use Nflate from http://www.romhacking.net/ Utilities to expand the ROM up to 512kb.

You can now use free RAM space at $5c00 to 5fff and $6000 to $7fff for cool or new stuff.

Bankswitching:
to bankswitch from $8000 - $Bfff and from $C000 - $ffff, here's how to do it:

LDA bank_number
JSR $FFB0
JMP New Location

or

LDA bank_number
JSR $FFB0
RTS

New location would be $8000 or $A000 etc... Bank 08 would be at $20010.

Credits:
Rockman: for info on how to convert the mapper!
Disch: for his mapper docs!

Have fun!


Changes for this version 1.3:
Change all $FF's to $00's in the expanded ROM area from location $20000

Changes for this version 1.2:
Change MMC5 setup code at $3ff00 in the Expanded ROM area.
Fixed: I changed $4c JMP to $20 JSR because it was wrong at location $1ffe6.

Changes for this version 1.1:
Fixed the Nametable mapping ($5105)



Non Supported Emulators:
Nintendulator
RockNES
VirtuaNES