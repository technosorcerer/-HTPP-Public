Dragon Quest I, translation by Polinym, password fix

May 16th, 2020.

!!! VERY IMPORTANT !!!
This is an addendum hack !
Please apply this patch AFTER applying the translation by Polinym (any version).

I made this patch so that the password system is actually usable by writing down password by hand on a sheet.
The original password system used a password of 20 kana, the unaltered translation also uses 20 symbols but use strange symbols which are not easy to write down.

This hack changes the password to be encoded in 24 alfanumeric characters. It is how the password system could look like if Dragon Warrior didn't use battery saves instead.

This hack DOES NOT change the password system itself in any way, it only changes how the password is encoded/decoded in actual characters.