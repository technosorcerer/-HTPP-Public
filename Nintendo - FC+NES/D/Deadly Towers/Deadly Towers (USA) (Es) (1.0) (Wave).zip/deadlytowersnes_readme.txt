Deadly Towers (NES)
Traducción al Español v1.0 (01/02/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Deadly Towers (USA).nes
MD5: f90d8365cd2a8e733e2280444b139d45
SHA1: d59da5bf52d5ecf5f407b70ff1c32b99235676d9
CRC32: 25225c70
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --