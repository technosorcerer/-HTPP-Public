"Devil Man"
Traducción al Español Ver. 1.1 (28/01/2022)
por Max1323 (maxmuruchi@gmail.com)
Basado en la gran traducción de snark.
---------------------------------------------------
Descripción:
Devilman es un juego basado en el manga del mismo
nombre creado por Go Nagai.
La historia se centra en Akira Fudo que se
convierte en Devil Man gracias a su amigo Ryo Asuka
que necesita tu ayuda para vencer a los demonios.

Desarrollado: ISCO
Publicado:    Namco
Lanzamiento:  25/04/1989 (JAP)
---------------------------------------------------
Acerca del proyecto:
-Se agregaron los acentos (no se agrego la í).
-Se tradujeron la mayoria de los gráficos,
también se cambio el logo de la pantalla de inicio.
-Los nombres de algunos personajes fueron cambiados a
su nombre original. Por ejemplo: Riyo es estaba mal escrito, su nombre original es Ryo.
-Hay dos parches, uno con el logo original y otro
traducido.
1.1 -Se corrigió el año a principio y el nombre de
Geruma a Gelmer.
-El parche del titulo original se aplica sobre el
parche traducido.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS (PC)
Utilizar UniPatcher (Android)

Devil Man (Japan).nes
File Size     256 KB
File MD5      4C0253FA8363340B11B5DB88CFF69459        
File SHA-1    124E79FABB941F98DC439085BD8EAA1A1183921B
File CRC32    0D327F0A