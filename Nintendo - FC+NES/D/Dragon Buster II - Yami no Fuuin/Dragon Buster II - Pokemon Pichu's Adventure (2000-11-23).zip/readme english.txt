POKEMON Pichu's Adventure 2000/11/23Version

Please drag and drop the Rom image to the exe file.
Please pick up the ROM image as you like (^^;