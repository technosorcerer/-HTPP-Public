"Dragon Scroll: Resurrección del Demonio Dragón"
Traducción al Español Ver. 1.1 (29/03/2025)
por Max1323 (Traducciones Max1323).
Basada en la gran traducción de KingMike's Translations, Eien Ni Hen y FlashPV.
---------------------------------------------------
Descripción:
Cientos de años han pasado desde que Narume eliminara la magia del mundo. La gente vivió en paz y los pueblos prosperaron.
Sin embargo, también había quienes hacían el mal para conseguir la fortuna. Entre ellos, estaban los tres ladrones codiciosos: Safra, Kakai y Unasu. Un día mientras estaban siendo perseguidos, se perdieron en el desierto. Luego caminar y caminar, se toparon con una torre sagrada y descubrieron los Libros Mágicos ocultos. Pensando que podrían venderlos por una gran cantidad de dinero, los tres se repartieron los libros y cada uno se fue por su cuenta. Con los Libros Mágicos desaparecidos, el Dragón Croma despertó de su sueño eterno, determinado a sumergir el mundo en una segunda era de hechicería oscura.
Entonces Narume infundió al Dragón de Oro con el espíritu de la justicia, invocándolo en la forma de un héroe llamado Feram.
Ahora todo depende de Feram en reunir los Libros Mágicos y regresar al Dragón Croma a su sueño eterno.

Desarrollado: Konami
Publicado:    Konami
Lanzamiento:  04/12/1987 (JAP)
---------------------------------------------------
Acerca del proyecto:
-La mayoría de los textos están traducidos. Se agregaron los caracteres españoles.

-La mayoría de los gráficos fueron traducidos.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS (PC)
Utilizar UniPatcher (Android)
Utilizar Rom Patcher (Parcheador Online):
https://romhackplaza.org/patch/

Archivo IPS
Dragon Scroll - Yomigaerishi Maryuu (Japan).nes
File Size:    257 KB
File MD5      4FA18D83EDF7A58DF530338A8BBAD149        
File SHA-1    B8A925BC1208134672CD90AF738E9BD0A2BDA610
File CRC32    9475BAFC