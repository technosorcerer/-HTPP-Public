Dungeon Magic - Sword of the Elements (NES)
Traducción al Español v1.0 (18/01/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dungeon Magic - Sword of the Elements (USA).nes
MD5: bf06f7f28ddc4e07fe994fa214ede357
SHA1: ab916a9fa0e389502e6f5849e9f6d45de2b98959
CRC32: 7a365bf8
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --