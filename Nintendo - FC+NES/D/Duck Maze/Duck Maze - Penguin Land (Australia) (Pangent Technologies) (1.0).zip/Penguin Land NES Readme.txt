Penguin Land NES / Famicom

From Pangent Technologies

Sega's Penguin Land is ported to the Nintendo Entertainment System. Well, sort of. This is based on the unlicensed clone "Duck Maze."

Apply this IPS patch to this ROM:

Database match: Duck Maze (Australia) (Unl)
Database: No-Intro: Nintendo Entertainment System (v. 20180803-121122)
File SHA-1: 7A4E1430C74B226FF9CF59F63C185E34CA09D568
File CRC32: 1C1CA36
ROM SHA-1: 261CD2397B65C43F50F56C367AF5CC5E99BE6116
ROM CRC32: FF1CEFAA

Doki Doki Penguin Land is a series of puzzle platform games developed and published by Sega, and which began in 1985. All games in the series feature a very similar formula whereby players guide an egg to the bottom of a level by moving or destroying blocks. The egg cannot fall more than a certain distance, nor can it come into contact with an enemy or it will break and the player will lose a life.

Doki Doki Penguin Land (どきどきペンギンランド, Doki Doki Penguin Rando, lit. "Heart Pounding Penguin Land") is the first title in the series. Originally released in 1985 for the SG-1000 and MSX, it was also among the few games to receive an arcade port running on hardware closely based on the SG-1000.

The first game remains the most widely ported, and has been compiled on the Sega Saturn, various cell phones, and a loose adaptation on the Game Boy by Pony Canyon, which inspired this clone.

Duck Maze is a platform puzzle game developed and published by Bit Corporation in 1987, making it the very first Nintendo unlicensed video game released for Famicom (internationally known as NES). The title has been later published in 1990 by HES and Dismac, respectively in Australia and Brazil.

Duck Maze is a clone of Doki Doki Penguin Land by Sega, in which the player control a duck to guide an egg downwards of its 20 levels by moving or destroying blocks. Furthermore, one of the three lives available can be lost when this egg touch an enemy or when it breaks down falling too high.

CHEATS
0x2fd = printed out location for # of lives.
0xc3 = 0 lives = game over. I have been unable to find the # of lives.
0x327/36c = level #--I think you need to change both of these.

FAQ/Walkthrough
version 1.0.0 by schultw.andrez@sbcglobal.net (anti spam spoonerism)

Level 1:

X              X
X              X
XXXXXXXXXXXXXXXX
X              X
X              X
XXXXv====*XXXXXX
X              X
X    XX*XX     X
X   XXXXXXXXXX*X
XXXXXX         X
X              X
X      XXXXXX  X
X              X
X       XXXXXXXX
X        XXXXXXX
XX*       XXXXXX
XXX===v===XX XXX
X              X
X   *          X
XXXXXX XX*X XXXX
X   XXXXXXXXXX*X
XXX    XX      X
X          *XXXX
XXXXXX         X
X     XXXXX==v=X
X              X
Xv====   X   X X
X     XXXX  XXXX
X              X
XXXXXXX  XXX*XvX
XXXX  XXXXXXXX X
X              X
XX     *XX X   X
XXXXX XXXX XXXXX
X    XX*XX     X
X              X
XXXXX     *XXXXX
X      XXXXXX  X
X     X     XXXX
X     *      XXX
XXXX XXX X    XX
X====XXXXXXXXXXX
X        XXXXXXX
X XXXXX   XXXX X
X    XXXXXXXXXXX
XXXXXXXXXXXXXXXX

I like to dig the egg down the right side here. Make sure it doesn't fall off 
the very edge, but onto the 6-wide platform, then tip it right and back left. 
Dig the leftmost square, drop and push the egg over the egg-only hole.

Stand on the block and dig left. Push the block 2R and dig left 2x so you can 
push the block down to the left. Then push the block right of it to the right, 
in one hole, and push the other block right so it lands on the bear in the 
hole. Drop the egg through.

2-1 dig right of where you crushed the bear so you can push the egg down and 
right and back left. You may want to jump over the egg and fall left so it 
does not get stuck in a corner below the block. Then dig right and fall over 
the egg-tube and push left.

Dig over the egg so that it falls on the outcropping L, so the bear cannot 
run down and get it. Jump over and knock the egg from the left.

Push the egg into the 2-wide and back right. Dig under it, drop on it and dig 
under it. 2-1 dig right of the block so the egg falls in there. Push the 
block left to crush the enemy. Dig 1L of the egg, jump over and dig right so 
you can loop around the egg and push it left.

Dig left after pushing the egg to the 4-wide hole and now 3-2-1 dig on the 
left so the egg falls down. Run into the egg so you don't 3-1 dig by 
mistake(a trap) then 2-1 dig to get the egg out. You have the time to jump 
over it and get the heart if you want.

Level 2:

X              X
X              X
XXXXXXXXX    XXX
X        XXXXXXX
X   *          X
XXXXXX         X
XXXX  XXXXXXXX X
X       XXX    X
X         XX   X
X XXXXX X XX XXX
X     XXX  X XXX
X * *      XXXXX
X XXXXX X XX XXX
X              X
X     *      XXX
XXX===v===XX XXX
XX*       XXXXXX
XXX    XX      X
XXXXX XXXX XXXXX
X              X
X       XXXXXXXX
X              X
XXXXXXX==v=XXXXX
X              X
X              X
X*X*  XX XXXXXXX
XXXXXXXXX X*X*XX
XXXX     XXXXXXX
X         *X*X*X
X XX*X   XX    X
XXXXXXXXX    XXX
XXXX  XXX  XXXXX
X     XXX  X XXX
X      XXXXXX  X
XXX XX X X     X
X  XXXXX====XXXX
X   X    XXX   X
XXXXXXXXXXXXXXXX

Push the egg to the right edge and dig it down. Then push it left and dig it 
down, jump over it and crush the enemy to the right. Dig leftmost and drop 
the egg there. Fall left on the egg, dig the egg left and now jump to the 
left and push the block back to the right, crushing the cat.

Dig to get to the heart and fall off the bottom, making a detour to push the 
green block into the cat. Jump over to the left so you can push the egg right, 
then dig it into the cavern below. Dig 2U1L and 1U of the cat in the DR. Let 
him push you left and then follow you off the edge. That gets rid of him.

Dig the egg into the cave below and roll it right, then back left. When on 
top of the undiggables, push the egg left of them and dig 1L of the greens. 
Get the spare heart in midair by digging over it if you want. Fall on the egg 
and drop it left, then dig it when it is on the right square. Push it right.

At this point you can dig the egg right til you can't any more. Taking time 
to get the heart is tricky as an enemy may appear inside the egg, but you can 
do it without pushing the egg. The digs shouldn't be too hard.

Level 3

X              X 
X              X
XXXX  ======v==X
X   *          X
X   X*     XXX X
X  XXX X       X
X XXXX X  X    X
X       XXXXXXXX
X XXX*XXXXXX==vX
X    XX*XX     X
Xv====   X   X X
X      XXXXXX  X
X      XXXXXX  X
X XXXXX X XX XXX
X       XXX    X
X   *          X
XXXXXXXX XXXXXXX
X              X
X  X=v== XXXXXXX
XXX    XX      X
X              X
X XX*X   XX    X
X====XXXXXXXXXXX
X       XXXXXXXX
XXX    XX      X
XX*       XXXXXX
XXX    XX      X
X XXX*XXXXXX==vX
X              X
XXX    XX      X
XX*       XXXXXX
XXX   *XX      X
X XXX*XXXXXX==vX
X              X
XXX    XX      X
XX*X* *XX   XX X
X XXXXXXX  XXXXX
X      XXXXXX  X
X              X
X X * X XXXX*XXX
XXX===v===XX XXX
X   *          X
X     =======  X
X      XXXXXX  X
XXXXXXXX   X   X
X   *          X
X              X
XXXXXXXXXXXXXXXX

Drop the egg over the egg chute then send it down. Fall left and run back 
right so you can jump and push the egg left (twice) and then dig left so the 
egg drops. Now 2-1 dig the right edge so the egg will fall down and you can 
roll it left.

Push the egg left and jump over it to push the block right. Dig over the 
heart and fall to lure the cat left, then drop the block on the cat. Drop the 
egg right then left and now be careful to jump over the egg, dig 1U1L of it, 
and push it right into the 3-wide gap. Drop the egg down the center of it, 
then dig each side of the block to your right and dig 1R1D of it and drop it 
down the chute. Follow it and fall left. Now you can crish the cat as it 
comes by.

You need to dig down the left to fall into the UL and be able to push the egg 
left, then jump left to push it 2 squares right. Don't let it fall off, but 
2-1 dig so that it lands on the 2-platform below. Then push it right.

Dig 2-1(jump on the egg so it falls to the left) so the egg falls onto the 
undiggables, then jump on it and push it left. Dig left when 1R of the left, 
then fall on the egg and dig left. That should give plenty of time to 
outmaneuver the cat.

Level 4

X              X
X              X
XXXXXXXXXXXXXXXX
X   *          X
XXXXXX XX*X XXXX
XXXXX     *XXXXX
X        XXXXXXX
X     XXX  X XXX
X X=v===   *   X
X         XXvXXX
X XX*X   XX    X
XXXXXXXX   X   X
XX*     * XXXXXX
X       XXX* X X
Xv====   X   X X
X  XXXXX  XXXXXX
X      XXXXXX  X
XX     *XX X   X
XX XXXXXXXXX   X
XX X      XXXXXX
XXXX           X
X       XXX* X X
XXXXv====*XXXXXX
XX     *XX X   X
XXXX  XXX  XXXXX
XX*X*X*X  XXXvXX
XXX*X*XX XX    X
XX*X*X*X  XXXvXX
X    X         X
X              X
XX*       XXXXXX
XXXX  ======v==X
X   *          X
XX X      XXXXXX
Xv====   X   X X
X    XX*XX     X
XXXX XXX X    XX
X XXX*XXXXXX==vX
XXXX           X
X   *          X
XXXX  XXXXXXXX X
X  XXXXX  XXXXXX
XXXXXX*X*X*X   X
X XXXXX   XXXX X
X     XXXX  XXXX
XXXXXXXXXXXXXXXX

Dig left of the gold block and push it right then left. Bring the egg along 
and push it left then right. Dig 1R2U of the egg so you can push it right, 
then dig so you can push the gold block into the corner. Push the egg left 
into the corner. Dig around the block to the right and push it right so it 
falls on the cat.

Push the block left and right and now push the egg down. Place it 2 squares 
right of the chute and then jump up/right and dig right of the gold block so 
you can push it left, when the enemy is 2L of the chute. That will crush him. 
Push the gold blick 1R, dig and push the block 1L. Jump over the egg and drop 
it on the gold block.

Now use the gold block on the right to dig all obstacles, then push the gold 
block to the right edge. Dig over the 3x1 and drop the egg into it. Dig 2 
holes in the 3-cavern and drop the egg into the chute, then dig next to the 
chute and dig the egg again. Long jump left then go back right and push the 
egg to the right edge, dig and jump over it so you can dig and bait the cat 
left. Dig the cat into a hole by jumping over it and standing at the left 
edge and digging right.

Now dig 1L 2L 3L of the right edge on the platform below, then let the egg 
drop, then dig 4L. Dig below the 3L square and now you can 2-1-1 dig to the 
bottom. You can also dig, push the right of the gold blocks left and make two 
digs.

*X
XX21
  3X
XX4X

Level 5:

X              X
X              X
XXXXXXXXXXXXXXXX
X              X
XX     *XX X   X
XXXX  XXXXXXXX X
X   *          X
Xv====   X   X X
X         XXXXXX
X   *          X
X     XXX  X XXX
XXXXXXXX   X   X
X   X    XXX   X
XXX XXXXX      X
X      X  X* *XX
X X     XXXXXX X
X XXXXX X XX XXX
X              X
XX       XXX XXX
XXX   XXX  XX  X
XXXXXX         X
X      * X  XX X
X     X* X     X
XXXXXXXX XXXXXXX
XX===          X
X              X
XX     *XX X   X
XX*       XXXXXX
XX*X*X*X  XXXvXX
XXXX           X
XXXX X XX XXXX X
XX     *XX X   X
X              X
X  XXXXX  XXXXXX
X         X    X
X         X    X
XX XXX   *XXX*XX
X              X
X     XXX      X
XXXXXXXX   X   X
XXXX     XXXXXXX
X  XXXXX  XXXXXX
X XX *X*X X    X
X     XX XX    X
XXXXXX*X*X*X   X
XXXXXXXXXXXXXXXX

Dig the egg 2L of the R, jump over and dig 1L of the R, then dig the egg down. 
Dig it on top of the L and jump on it, then jump left to dig it from the left. 
Jump to kick it back left and then dig left so you can dig under the egg. 
Drop on it again.

Drop the egg to the left by the heart, then push both the blocks right of it 
to the right. Dig below where they were and push the egg right and left. When 
it is over the single block, dig it and fall to push it left. Now bait the 
enemy on the right to come down and follow you down the chute to the bottom. 
Remain just below him. Then dig over the egg so it falls right and avoids the 
enemy in the DL.

Go to the right side and dig on the red block so it falls, then use it to dig 
the square to the left. Now bring the egg back right and 2-1 dig so it lands 
in the left of the DR room. Push it right and dig.

Level 6:

X              X
X              X
XXXXXXXXXXXXXXXX
X              X
X              X
XXXXv====*XXXXXX
X              X
X         XX   X
X X XXX XX ====X
XXX   XXX  XX  X
X              X
X   X    XXX   X
X XXXXXXX  XXXXX
XXXXXX     X*X*X
X          XX*XX
XXX  X         X
X     XX XXX   X
X    X X   X X*X
XXXXXX XX*X XXXX
X         X    X
X              X
XXXX  *      *XX
X    XXXXXXXXXXX
X   *          X
XXX    *       X
XXXXXXXX   X   X
X      X    ==vX
X         X    X
XX XXXXXXXXX   X
X    X X   X X*X
X *X*          X
X XXXX X  X    X
X      XXXXXX  X
X     XXX      X
X    X      X  X
XXXXX     *XXXXX
X    XX*XX     X
X  XXX X       X
Xv====   X   X X
X       XXXXXXXX
X XXXXX X XX XXX
XXXXXXX==v=XXXXX
X         X    X
X              X
X X==X==X   XXXX
XXXXXXXXXXXXXXXX

The big starter combo is the only real area of contention here. Get through 
that, and the rest is easy.

Dig left, dig the boulder, and then push the egg left right and then dig so 
you fall 1L of the egg. Push the boulder to the right. On the boulder, dig 
left, 1L, dig left and drop the boulder in. Dig 1U1L, 1U and 1U1R of the 
buried boulder, then L and R of it, and push it on the other. Go to the left 
side and dig to fall off the edge and go back right to kick the egg R L L R. 
When it is on the boulder, kick the boulder.

Drop to push the egg right, then dig so it drops on the single square. Push 
it onto the egg chute. Drop it in. Then push the egg L R. In the 2-pit below, 
jump over the egg so it is at the left. Dig over it then fall on it. Final 
bit:

   X
12XX
X3 X
XX4X

Dig as above and jump over the egg and push it left so it falls a square, 
then dig on it.

Level 7:

X              X
X              X
XXXXXXXXXXXXXXXX
X   *          X
X   *          X
X*===v=*XXXX*X X
X   X    XXX   X
X      XXXXXX  X
X          *XXXX
X     XXX  X XXX
X   *          X
X XXXX X  X    X
X  XXXXX====XXXX
X X*X*XXX  Xv==X
X   *          X
X      X    ==vX
X XX*XXXX      X
X X=v===   *   X
XXXX  XXX  XXXXX
X    XX*XX     X
X   X    XXX   X
X      X   X   X
X * *      XXXXX
X    XXX=v==  XX
XXXX  XXX  XXXXX
XX X *X*       X
X    XXXXXX    X
X XXXXXXX  XXXXX
X   XXXXXX  XXXX
XXXXXXX==v=XXXXX
X              X
X         XX   X
X     XXXX  XXXX
XX       XXX XXX
XXX===v===XX XXX
XX     *XX X   X
X====XXX  XXXXXX
XX XXX   *XXX*XX
XX X *X*       X
X      XXXXXX  X
X         XX   X
X     XXXXX==v=X
X     XXX      X
XXX XXXXXX**   X
X   XXXXXXXXXX*X
XXXXXXXXXXXXXXXX

Dig the egg and make it fall right, then push it right. Dig as follows to 
kick it down some more.

21
X3
XX4
 *X65
 X X7

 X89X

Now jump over to the left and push the boulder right in the pit, dig to each 
side and crush the enemy to the right. Dig through so the enemy walks after 
you, then jump back up and push the egg through the chute. Jump over the 
block and fall right and dig right with the enemy on the right edge. Let him 
fall, then drop the egg down the chute and jump/push the block 1 right. When 
both enemies are in the center or heading there, drop the block down. Drop 
the egg on the block.

Push the block right(jump back left) and the egg left, then dig it down twice. 
Then dig the egg into the Z, then dig/push the block above down.

*1*
XXXX2X
XXXX
XXXXX

Dig the egg down after 2, then dig:

123*
45XX
6==v=

Again jump and push, then dig R of 5 and push the block left. Push the egg 
left. Push the block left, dig where it fell, and push the block left into 
the cat. Drop the egg down the chute. Go to the left edge and dig when over 
the block, push the block right and dig again.

Now you can dig under the egg so it is not on the immovable bit. Then push it 
right and down, then cycle back left for the heart. Dig to get to the egg(4L 
of the chute) and 2-1 dig to win.

Level 8:

X              X
X              X
XXXXXXXXXXXXXXXX
XXX XX X X     X
XXXX  *      *XX
X    XXXX XXXX X
XXXXXX         X
X    XXXXXX    X
X      X   X   X
X  XXX X       X
X*===v=*XXXX*X X
X   *          X
X XXXX X  X    X
X  XXXXX====XXXX
X X*X*XXX  Xv==X
X   *          X
X     XXX      X
X XX*XXXX      X

XXXX  XXX  XXXXX
X    XX*XX     X
X   X    XXX   X
X              X
X *X*          X
X XXX*XXXXXX==vX
X    XXX       X
XX X *X*       X
XXXXXX    XXXXXX
X       X      X
X     XXXX  XXXX
XX      XX v   X
XX             X
XXXXXX XX*X XXXX
X   X*     XXX X
X       XXX    X
X   *          X
X    XXXX XXXX X
XX===          X
X         X    X
X     X* X     X
X   XXXXXXXXXX*X
X     *      XXX
X X XXX XX ====X
XX*X*X*X  XXXvXX
X         X    X
X         X    X
XXXXXXXXXXXXXXXX

2-1 dig left of the mobile block and push it right. When the enemy falls, 
push the block onto him. Then roll the egg left and drop and right. You can 
dig left of the hole and push the block right. You can go 1/2 square right so 
the block falls and the egg does not, or you can just push the egg left, jump 
and dig left of the egg.

Drop the egg on the block below to the right, and dig the block so it falls 
on the enemy. Push the block left and jump on t he block and dig left. Repeat 
until you can't any more. 2-1 dig and drop the egg. You need to jump left to 
drop on it to push it right. Keep pushing it right and dropping it, and you 
can dump it down the chute easily enough.

Jump over the enemy and dig right, then jump on the block and dig left so you 
can push right. Roll the egg left so it falls. Wait for the enemy to fall 
down the chute to the left. Wait for both enemies to fall in a 1-hole below. 
Push the egg right so it falls twice. Dig left of the egg so you can roll it 
left all the way.

Dig right over the block and left on the block. Drop the egg on the block. 
Then dig left after dropping the egg, and push the block right to crush the 
enemy.

Drop the egg left and then dig right and fall. Dig left to make a 2-pit and 
then dig under the egg, push/drop left, and push/drop left.

Level 9:

X              X
X              X
XXXXXXXXXXXXXXXX
X              X
X              X
XXXX XX XX  XXXX
X              X
XXX===v===XX XXX
X   *          X
XXXX XX XX  XXXX
XXXX XX XX  XXXX
X    XXXX XXXX X
XXXXXX         X
XX*X* *XX   XX X
XXXX     XXXXXXX
X   *          X
X   *          X
XXX===v===XX XXX
X              X
X   *          X
X     =======  X
XX*       XXXXXX
X     X* X     X
X       XXXXXXXX
XX      XX v   X
X             XX
X     XXX      X
X      * X  XX X
XX XXXXX  X    X
X    X   XXX   X
X       XXXXXXXX
X XXX  XX*X*X*XX
X X   XX*X*X*XXX
XXXX           X
X              X
XXXX  ======v==X
X              X
XX*X*X*X*  XX*XX
X         X=== X
XXXXXX    XXXXXX
X   *          X
X      XXXXXX  X
X  XXXXX  XXXXXX
X    XXX       X
XX*X*X*X*  XX*XX
XXXXXXXXXXXXXXXX

Push the egg and dig it down the right edge. Then, by the 2x2-pit,

  12X
  3XX
XX4X

  X5
XXXX6

Push the egg onto the immovable, fall right and dig left and drop and dig 
left. Wait for the enemy to drop off the screen. Push the egg right. Go to 
the  left and get the heart and jump and hit under the block twice so it 
falls.

Push the block right, dig left of it, jump and push it right. Then jump and 
push it left after digging. You want things to look like:

 *X
 XXXh
XXXXXXX

Fall through to the left and the enemy will jump after you. Now jump on the 
egg from the left, dig right, then jump on it and have it tumble right and 
left. Get the heart and dig 1R of the block, which you can push right off the 
edge. Dig left, fall, dig left, fall, and get the egg and push it left. Dig 
right so it falls in, then fall left, dig under the egg chute and 1L, then 
dig right of the boulder and push it left, and go back and only now drop the 
egg in the chute. Otherwise the egg would be trapped--and now you can push 
the block on the cat to the right.

Push/drop the egg left, dig left after falling on it, then dig right after 
falling on it.

Level 10:

X              X
X              X
XXXXXXXXXXXXXXXX
XX X *X*       X
XXX*X X  ====XXX
X XXX  XX*X*X*XX
X              X
X     XXXX  XXXX
XXXXXXXX XXXXXXX
X            X X
X     X* X     X
Xv====   X   X X
X   *          X
X   XXXXXXXXXX*X
XX  X X*X*X XXXX
X              X
XXXXXX*X*X*X   X
X     XXX      X
XXX XXXXX      X
X X     XXXXXX X
X     X     XXXX
XXXX     XXXXXXX
X     XXXX  XXXX
XXXXXX XX*X XXXX
XXXX XXX X    XX
X     X     XXXX
X     XXX  X XXX
X      XXXXXX  X
X*X*  XX XXXXXXX
X       XXXXXXXX
XXXXXXXXXXXXX  X
X   *          X
X       XXX* X X
XX     *XX X   X
X XX*X   XX    X
X     *      XXX
XXX===v===XX XXX
X         X=== X
X     X X X  X X
X   *          X
XXXXXX         X
X  XXXXX  XXXXXX
XXXXXXX  XXX*XvX
X      XXXXXX  X
XXXXXXXXXXXXXXXX

123
*4*
 X

Dig 1-3, kick the block on the left, dig 4 and roll the egg left ontoo the 
block to the left. Push the egg 2R and then dig below it and 1L, then below 
the egg. Dig and push right.

Push the free block L R so you crush the cat. Then come back for the egg. 
Push it left, jump when it falls, push it right and dig at the last edge 
square. Now when you fall on it, it goes left.

Dig left and drop it twice so it is on top of the block. Jump over it and 
push it right. Dig and drop on the valentine. Dig on the block to crush the 
enemy, then dig on the square you were on. Dig and fall left. Fall through. 
Dig under the egg and push it R L. It's in a 2 pit so dig:

X1  X
XX32X
X 4XX
 5XXX

You can keep digging the egg left til it falls on the block suspended 2U of 
the unbreakables below. Push the block 2D1L of it into the left wall. Then 
dig the other block down and kick it right into the hole. Drop the egg so the 
rat doesn't get it, then drop the block 1U1R of the single hole off to the 
right so you can 2-1 dig in the corner.

Chuck that block into the corner and push the egg right. Dig at the final 
right square so you can drop it right twice safely. Roll the egg left now, 
with two digs to the left so it falls in.

Level 11:

X              X
X              X
XXXXXXXXXXXXXXXX
XXXXX     *XXXXX
X   *          X
XXXXXXX==v=XXXXX
X X            X
XXXXXXX  XXX*XvX
X      XXXXXX  X
X     XXX      X
XXX XXXXXX**   X
X           X  X
X   X*     XXX X
X X            X
X  XXXX==XXXXX X
X XX *X*X X    X
XXXX XX XX  XXXX
X       X      X
XXXX  XXXXXXXX X
X      * X  XX X
XXXX  XXXXXXXX X
X   *          X
X  XXXX     XXXX
X       X=v====X
X  XX X      X X
X   XXXXXX  XXXX
X    X*X*X*X   X
X X   XX*X*X*XXX
X X    X*X  XX X
XX*X*X*X*  XX*XX
X             XX
X         X=== X
XXX*X X  ====XXX
XXXXXX    XXXXXX
X            X X
X   *          X
X      XXXXXX  X
XX  X X*X*X XXXX
XXXXXX*X*X*X   X
X  XXX XX XXX  X
X     XXXXX==v=X
X      XXXXXX  X
X     XX XX    X
XXX    XX      X
X   XXXXXXXXXX*X
XXXXXXXXXXXXXXXX

Dig so the egg falls on the chute. Jump to the other side and dig so you can 
drop the egg through the chute. Go right and dig, then dig 1R of the egg and 
blow there so you can drop the egg to the right. Drop onto the egg and dig 
the block below it. Push that block right to crush an enemy. Push the egg to 
the left edge, dig under it, fall, etc. to the right edge.

Go back up and dig at the top so you fall down a long way. Let the enemy 
follow you, then jump to the left and fall down the left. Push the egg right 
so it falls twice once he is in the 2-pit. Dig 1R of the block the egg laded 
on, then fall through and dig to push the block right. Dig 2L 1L 1R of the 
block and push it over, then roll the egg left.

3-1 dig so you can drop the egg 1R, then jump over it and dig it from the 
right. Drop on it and push the block right. There's another block on top you 
can dig and push right. Do so.

Now you need to push the egg to the left, eventually, but you must put 
everything in place.

     a0
3  2 1c8
XX754bX
  XX6

Dig 0, a 1L, then dig 1-2 and push a 4L and dig 3.

Dig 4-5-6, drop a right, dig 7 and drop a right.

Dig 8, drop c left. Dig b, then drop the egg on b and off to the left. Roll 
it into the DL corner and dig.

If you have trouble getting the egg in a safe position, dig the DL and then 
jump from the left to the right at the top and dig there.

Level 12:

X              X
X              X
XXXXXXXXXXXXXXXX
XXXXv====*XXXXXX
X      XXXXXX  X
XXXXXX*X*X*X   X
X              X
X              X
X X    X*X  XX X
X    X         X
X    X         X
X X==X==X   XXXX
XXXXXXXXXXXXX  X
X              X
X          *XXXX
XXX===v===XX XXX
X              X
X    X      X  X
XX*X*X*X  XXXvXX
XX XXXXX  X    X
X XX*X   XX    X
X XXXXXXX  XXXXX
X X XXX XX ====X
X     XXX      X
XXXXv====*XXXXXX
X      XXXXXX  X
X *X*          X
X              X
XXXXXXX  XXX*XvX
XXXX           X
X  XX       *  X
X  XXX XX XXX  X
XXXXXX    XXXXXX
X    X   XXX XXX
Xv====   X   X X
X    X  XXXXXX X
XXX XXXXXX**   X
XXXXXX*X*X*X   X
XXX*XX *X*     X
X      X    ==vX
X X    X*X  XX X
X XX *X*X X    X
X XXXXX   XXXX X
XXX*X X  ====XXX
X      X  X* *XX
XXXXXXXXXXXXXXXX

Dig as follows so the egg falls below the 5, then dig it:

1234
X56

Drop the block to the right on the advancing enemy, then knock the left top 
block down and push it so you can dig left. Then push the block left onto the 
enemy. Dig and push the block left to the edge, and the other one right, so 
the egg can roll right. Dig the egg from the right in the 2-pit.

Drop the egg through the chute and dig 1L of the top block, then 1R of it and 
push it left after digging the square where it would've fallen.

 *X
 X
XX

Dig right on the block and push it left. Repeat to kill the enemy. Roll the 
egg right, jump over it after it and push to the left of the 4-pit, dig it 
and let it fall twice. Jump and dig left so you fall L R and thus kick the 
egg right. 2-1 dig so it falls harmlessly.

Push the egg 1L of the chute, then dig left and push the block below 1R. Now 
dig the 3 squares to the left. Dig down to the 3-cavern(1U and 2U of the left 
edge) and dig the right two squares inside. Fall through and push the egg 
onto the block, and dig the block. Roll the egg down to the safe bit and 
stick it over the chute.

X21
==43
* *5
XXX6

Dig 1-5, then dig 6, fall through and push the egg back left then right to 
complete the level.

Level 13:

X              X
X              X
XXXXXXXXXXXXXXXX
XX*         X*XX
XXXXX     *XXXXX
X      XXXXXX  X
XXXXXXXXXXXXX  X
X            X X
X*===v=*XXXX*X X
X       XXX    X
X       XXX    X
X  XXXXX====XXXX
X         XX   X
XXXXXXXXXXXXX  X
X              X
X   X X        X
XXX*XX *X*     X
X   X    X     X
X XXXXXXX  XXXXX
XXXXXXXX   X   X
X       X      X
X    X*X*X*X   X
X           X  X
X     X X X  X X
XXXXXXXXXXXXX  X
X*===v=*XXXX*X X
X              X
X XX*XXXX      X
XXXXXX    XXXXXX
X    XX*XX     X
X              X
X    X XXX X   X
X  XXX XX XXX  X
XXXXX XXXX XXXXX
X XXXXXXXXXXXX X
X XX   XX   XX X
XXXXXX         X
X              X
X              X
X*==v===X==v==*X
X              X
XXXX X XX XXXX X
X  XXXX     XXXX
X       X=v====X
XXX    XX      X
XXXXXXXXXXXXXXXX

Dig the 3 squares on the right and push the egg right. Drop, dig left and 
then dig 1R of the lower block to push it and crush the enemies. Dig 2U and 
1R2U of the chute to drop the egg down after you roll it. Kick the boulder to 
the right and drop the UL block down after digging the left part of the floor 
below. Do it when the enemy is in the center going left, to be sure. Drop the 
egg left once.

   43
   5
  *6

1XXX

2XXX

Fall to the DR after digging 1/2, then dig under the egg. Jump over it and 
dig each side of the block to crush the enemy below. Then dig each side of 
the next block over. Push the block in the 4-pit 1R(dig from the right) and 
dig left when on it. Push the block into the corner. Now you can push the egg 
L R. Dig under it at the right edge so it falls on the floor above the brick. 
Push it right 2 squares so you are over a brick and it is at the top of the 
stairs.

Dig the egg down. Fall on it and dig right. Jump to the right edge, then jump 
up and go left so you can dig left. Watch the cat go splat.

Push the egg to the left corner, then dig 1U and 1U1R of it. Kick the egg 
back right and dig 1L of the block and dig the block. Fall in the left pit 
and jump and push the block back right to a hole. Now you need to dig the 
block to the bottom so it interferes with the cat.

X    X 123 4   X
X  XXX 56 987  X
XXXXX aXcb dXXXX
X XXXeXXXXXXXX X
X XX   XX   XX X

Dig as above, pushing the block into the next available hole. Finish things 
by dropping the block on the cat. You may have to shuffle it. Only then push 
the egg to the left, then jump over the top so you can push the egg back 
right after it falls.

The rest is a gimme. Roll the egg to the center and dig below it continually. 
Then drop it down the chute and dig 1L and 1L1D of the chute.

Level 14:

X              X
X              X
XXXXXXXXXXXXXXXX
X   X    * X   X
X   * XXXX     X
XXXXX XXXX XXXXX
X   X    * X   X
X   XXXXXXXX   X
X   *          X
X   XXXXXXXXXX*X
XXX===v===XX XXX
X    X      X  X
X          *XXXX
X X==X==X   XXXX
X    X XXX X   X
X  XXXX     XXXX
X   X XX       X
XX*         X*XX
X   XXXXXXXX   X
XXXXXXXXXXXXXXXX
X   X    X     X
X       X=v====X
XXX*       XX  X
X       X      X
X     XXX      X
X    XXXXXX    X
X    XXXX XXXX X
XXXX XXXXXXXXX X
XXX    *       X
XX             X
X    X   XXX   X
X   X X        X
XXXXXXX  XXX*XvX
X       X      X
X       XXX    X
X XXX  XX*X*X*XX
XXXXv====*XXXXXX
X X   XX*X*X*XXX
XX       XXX XXX
XX     *XX X   X
X XXXXXXXXXXXX X
X     =======  X
X   *          X
X=v===X*X=====vX
X           X  X
XXXXXXXXXXXXXXXX

Dig the egg into the center square and push it left. Push it right after it 
falls, then dig it by the block. Jump on it and crush the enemy to the right, 
then push the left block left to crush the other enemy. Now go right to the 
edge and dig right as you go back left. Push the green block all the way 
right into the hole. Land on it and dig each way.

Drop right, jump and kick the green block left. Dig right on it so you can 2-
1 dig below. Though after the egg falls(first dig,) go right and be prepared 
to drop the block on the advancing enemy. Dig the egg to below the next cat.

Dig 4L 3L 2L 1L of the egg and push it left. Then jump to the left side and 
2-1 dig to get the cat to follow you. Drop down to oblivion. He'll follow, 
and you'll reappear at the top. Dig under the egg, so it drops. Then go dig 
the UL square so you can push a green block right.

*21
34X
5XX
XXX

Dig 1-2, push the egg down, push the block left, and dig 3-4-5. That leaves 
the egg safe. Push the egg left to the edge. Push the block right after 
digging 1. Then dig 2/3 and push the block right. Go 1U1R and stand on the 
left edge and jump twice to bring the above block down. Right edge of the 
left platform won't work.

   *1
   2 3
XXXXXX

Dig 1R of the fallen block. Cut the egg over to the right and let it fall 
into the corner. Push the top block left, then dig the 3 squares right of the 
other block, so you can push it into a corner. Put the egg on the left of the 
2 boulders and dig up everything you can to the right. Push the blocks left, 
in order left to right. Drop the egg down 1 and now dig the right side:

321
*45
 6X

Now snake the egg down and don't put it in the chute--dig either floor space, 
drop and dig again. Detour for the heart if you want.

Level 15:

X              X
X              X
XXXXXXXXXXXXXXXX
X              X
X    X  XXXXXX X
XXXXXX         X
X X    X*X  XX X
X    X  XXXXXX X
X   X X        X
X XX  X *==v===X
XXX  XX        X
XX             X
X      XX* XX*XX
XXXXXXX  XXX*XvX
X    X   XXX   X
XXX*XX *X*     X
XXXX  *      *XX
XXXXXXXXXXXXX  X
Xv====   X   X X
X         X    X
X XXXXX        X
X      X   X   X
X      X  X* *XX
XXX*XX *X*     X
X  XX  XX*X*X  X
X       XXXXXXXX
XXX XX X X     X
X            X X
X    X  XXXXXX X
Xv===  XXX XXX X
X * *      XXXXX
XX X X X X X X X
XX XXXXX  X    X
X              X
X XXXXX        X
X      XX* XX*XX
X              X
XXX    *       X
X   X    * X   X
X     XX XXX   X
X   *          X
X       XXXXXXXX
X       XXX* X X
XXXX           X
XXXXXXXXXXXXXXXX

Dig under the egg and keep kicking it right. Then at the edge pull it back 
left. Drop it then land on it. Let the enemy trap himself. Dig around the 
right block to release it and crush the enemy.

Dig 1R of the egg, drop in and roll the egg left then right--jump over it so 
it is not stuck in the corner. Drop it right, fall on it, dig and roll the 
egg right. Push one boulder left, then dig over the cat, and jump under one 
boulder an push it over the cat. Fall down to the 2-pit and dig and push the 
block right. Jump on back up and shift the egg L R R and, when you can push a 
block left, do so. Then fall after it. A cat will give chase into oblivion.

Stand on the middle block, dig each side and push it right.  Then push the 
egg into the 2-gap and then dig under it. Push it L L R R. Now back up and 
dig so you fall left of the egg and dig left. Fall L R L and dig your way out 
so you land on the top--put a hole on the left so that the enemy goes right 
there.

Fall on the egg from the right. Push it L L. Jump to the right sole tile and 
then wait for the enemy to turn around. Jump so you push the egg right and 
then you can push it back left and to the hole you created. It's ok to place 
the hole directly where it falls off the last long ledge.

Level 16:

X              X
X              X
XXXXXXXXXXXXXXXX
X              X
X XXXXX   XXXX X
X         X    X
X   *          X
X XXXXX   XXXX X
X     XX XX    X
X     XXXX  XXXX
X*X X X X  XXXXX
XXXXXXX  XXX*XvX
XXXXXXXX   X   X
XX*X*X*X*  XX*XX
X         X=== X
XX X *X*       X
XXX*XX *X*     X
X    X*X*X*X   X
X        XXX X X
XXX*X X  ====XXX
X X            X
X   *          X
X  X=v== XXXXXXX
X     XXX      X
X            X X
X    XXXXXX    X
X XXXXX        X
XXX    XX      X
X   X    * X   X
XX  X X*X*X XXXX
XXXXXX*X*X*X   X
X              X
X X    X*X  XX X
X      X    ==vX
X              X
XXXXXXX  XXX*XvX
X     XXX  X XXX
X X==X==X   XXXX
X XXXXXXX  XXXXX
X X*X*XXX  Xv==X
X            X X
XXXXXX         X
XXXXXXX*X*X*X  X
X  XX X      X X
XXX XXXXXX**   X
XXXXXXXXXXXXXXXX

Dig left, drop the egg, and dig left so the egg is in the niche at the corner 
of the L. Go right off the edge and back left and dig at the bottom. Go to 
the left side and dig so you can push the stone right, dig left on the stone, 
and push it in the big hole. You can jump up and knock the egg down now. Dig 
1R of where it falls and push the egg there, then dig 2L 1L 1R of the stone. 
Push the stone left.

Dig 1U1R, 1R, 1L of the stone and push it into the enemy. Run to the DR to 
activate the enemy. Drop the egg to the left edge. Dig right, fall right and 
dig right. Now in the DR,

1*
*2*3
 XXX X

Dig 1, push the block left, dig 2/3 and push the block right into the pit. To 
get out, dig the DR--1U1L of the corner, then the corner. 

Now push the egg to the DR and when it is there, push it right, then dig left 
and fall in the hole and jump out. That traps the enemy. Push the egg off the 
right edge. Dig the rest of the bricks needed to push the block left on the 
enemy. Push the next block over left onto another enemy. Dig right of the 
center so you can drop the egg and roll it left into the 2-wide pit, then 
drop the other block in the corner. Dig 1R, then 1D of the egg so it lands on 
the 2-spire, then push it left. Dig left to drop it again.

Jump back right and dig R L on top of the block to crush the enemy. You can 
drop a block down now and awaken the enemy and crush him into the side. Then 
push the egg on the grey block, left then right. Drop it between the two hard 
floors, then jump on it and dig left before the edge to drop it again. Then 
you just need to roll the egg all the way right and jump on it and dig left.

Level 17:

X              X
X              X
XXXXXXXXXXXXXXXX
X              X
X       XXX    X
XXXXXXXXXXXXX  X
XXXXXXX*X*X*X  X
X     XXX      X
XXXXXXXXXXXXX  X
X              X
X   *          X
X=v===X*X=====vX
X              X
X              X
XX*X* *XX   XX X
X   XXXXXXXX   X
X  XXXX==XXXXX X
X         X=== X
X X            X
X XXX  XX*X*X*XX
X     XXX      X
X X*X*XXX  Xv==X
X              X
XXXXXXXX   X   X
XX X      XXXXXX
X   *          X
X X=v===   *   X
X XX   XX   XX X
XXX   XXX  XX  X
XXXXXXXXX X*X*XX
X X            X
X    X   XXX XXX
XXX XXXXXX**   X
X           X  X
X     X     XXXX
Xv====   X   X X
X     X X X  X X
X    XXXXXXXXXXX
XX     *XX X   X
XXX    *       X
X====XXXXXXXXXXX
X XX  X *==v===X
XXXXXX         X
X*==v===X==v==*X
X   *          X
XXXXXXXXXXXXXXXX

Dig the egg to the left side and drop it, then over the block,

X123X
XX4XX

Dig 1-2-3 and then dig 4 from the left, and drop on the egg and dig it and 
drop on it. Crush the enemy to the left. Push the egg right til you are on 
the block and dig right. Drop on the egg and dig 2R 1R of the block to crush 
the enemy. Dig and drop the egg to the right edge.

Push the egg back left and dig the 2 leftmost squares in the next platform. 
Fall, dig right and drop down the big chute. Everyone follows. Roll the egg 
left then a bit right, digging it to drop it 4R of the chute.

You need to bring that suspended green block over, so jump under it and run 
away to avoid getting stunned. Stay on the left half and watch for the 
movement--better to jump too early than too late.

Dig 1R of the block and push it left and continue. Keep doing so til the 
block can't be moved. Dig 1U1R of the block and dig down through the DR. Push 
the egg right then jump over it so you can push the block left.

Dig 1L of the block you pushed then 1R of it, so you can push the block left. 
Push the egg so you can dig it onto the single floor and jump over the egg to 
push it left. Then dig when on the bpilder to push the egg left off the edge.

This last bit looks like it should be easy, but watch out. Straight digging 
loses, but running the block into the enemy and digging right under the egg 
where the block was, then re-digging and dropping, wins.

Level 18:

X              X
X              X
XXXXXXXXXXXXXXXX
Xv====   X   X X
X              X
X====XXX  XXXXXX
X XXXXX   XXXX X
X       XXXXXXXX
XXXXXXX  XXX*XvX
X              X
Xv====   X   X X
X          *XXXX
X         X=== X
X              X
XX XXXXX  X    X
XX X      XXXXXX
X=v===X*X=====vX
X              X
XXXX           X
XX*X*X*X*  XX*XX
X           X  X
XXXX  XXX  XXXXX
X              X
X    XXXX XXXX X
X    X         X
XX      XX v   X
XXXX XXX X    XX
X         XXvXXX
XXXXXX         X
X              X
X      X  X* *XX
X XXXXX   XXXX X
X    XX*XX     X
X              X
XX*X*X*X*  XX*XX
X              X
X      XX* XX*XX
X   *          X
XXX XX X X     X
X   X*     XXX X
X         XXXXXX
X              X
X    XXXX XXXX X
X X X        XXX
X    X   XXX XXX
XXXXXXXXXXXXXXXX

X4321
XX65
XX78X
XX*Xv

Dig the egg right. Drop it when over the block. Jump left then push the egg 
to the right corner. Dig right, push the block 1L, then bring the egg to the 
left and dig the two right squares. Push the egg off the right edge. The top 
block vanishes. Dig 1R of the other one and push it 1R, dig left and push it 
left. Jump and push it right and dig on it. Push it left, dig right and push 
left.

Dig left when on the block in the center, then fall left and right to make 
the enemies follow you. Wait for them to die, then push the egg left. Push it 
back right and dig right:

X*X*X*!*

Drop on it, dig right and drop on it. Get the heart and then drop on the egg 
and place it over the chute. Dig left. Drop, 1R, dig left, then jump to dig 
the right edge and push the block right. Push the other block 1R. Fall 
through the bottom and wait to drop the egg through the chute. If the rat 
appears, drop the egg--the enemies on the left will eventually die anyway.

Jump to push the egg R R L and 1L so it is 2 from the right. Dig under it. 
Drop on it from the left and dig the block inder it, then push the block 
right so the egg falls. Dig eft of the block to get more space, then dig left 
so the egg falls. That wakes up the final cat. Let him go to the pit and just 
roll/dig the egg left to complete this.

Level 19:

X              X
X              X
XXXXXXXXXXXXXXXX
X       X=v====X
X       X      X
X X   XX*X*X*XXX
X              X
XXX===v===XX XXX
X    X   XXX   X
XXXXXX*X*X*X   X
X  XX X      X X
XXXX  XXXXXXXX X
XX  X X*X*X XXXX
X   *          X
X     XXXX  XXXX
X        XXXXXXX
XXXX XX XX  XXXX
X*==v===X==v==*X
XXX    *       X
X      XXXXXX  X
X     XX XXX   X
X     XXX      X
XX*X*X*X*  XX*XX
XXX XXXXXX**   X
X       X      X
X       X=v====X
XXXXXXXX   X   X
XXXXXXXX   X   X
XXX XXXXX      X
X   XXXXXX  XXXX
X     XXX      X
X        XXXXXXX
XXXXXX         X
X           X  X
X         XX   X
X    X*X*X*X   X
XXXXXX*X*X*X   X
X=v===X*X=====vX
X              X
X  XXXX     XXXX
X XXXXXXX  XXXXX
XXXXXXX*X*X*X  X
XXXXXX         X
X  XXXX     XXXX
X X            X
XXXXXXXXXXXXXXXX

Below the chutes is a trap, so push the egg left and dig it. The second chute 
is a trap , too, so just 2-1 dig right of it. Push the egg to 2U of the right 
enemy and dig the top right purple boulder. Dig right on it and push it into 
the enemy. Push the egg into the corner. Dig 1L and 1D of it.

Dig the egg into the 2-pit above the cavern above the chute. Dig 2L 3U, 2L 2U, 
3L 1U, and 3L of the chute. Then dig the egg through. Drop the egg off the 
right. Then push the purple rock at the top left, then dig 1R and 1R of it 
and drop the block on the enemy. Dig over the egg.

Now dig 3R 2R 1R of the purple block. 2R 1D, then 4R 2D. You can push a block 
to the right now, then dig 1U1L and 1L of it. Push it 1R, then dig the floor 
to the left, then jump and dig 2L of the egg so you can push the block left 
run to the DR and dig, to make a cat follow you and die.

Drop the egg on the block. Drop it right til you are on the wide platform, 
then dig right under it. Go 1L and dig right again, then dig right under the 
egg. You should be able to push it over the chute now. Leave it there and 
find a way down.

  1*2
XX3*4

1, 2, push * left, 3, 4, push * left and dig. Then jump back up.


You can dig left of the enemy's pit to jump over him more easily, then 2-1 
dig the egg so it drops safely. Roll it to the bottom and dig.

Level 20:

X              X
X              X
XXXXXXXXXXXXXXXX
X   *          X
XXXXX     *XXXXX
XXXXXXX*X*X*X  X
XX       XXX XXX
X          *XXXX
X X    X*X  XX X
X=v===X*X=====vX
X              X
XXXXXX*X*X*X   X
X   X*     XXX X
X       XXX    X
X XXXXX        X
XXXXXX*X*X*X   X
XXXX XX XX  XXXX
X      * X  XX X
X       X      X
X====XXX  XXXXXX
X    X XXX X   X
X    XXXXXX    X
X XX*X   XX    X
XX*X*X*X*  XX*XX
XX     *XX X   X
XX X *X*       X
XX X      XXXXXX
XXX   XXX  XX  X
X      X    ==vX
X   X    XXX   X
X  XXXX     XXXX
X XX *X*X X    X
X     XXXXX==v=X
X     XXX      X
X*X*  XX XXXXXXX
X XX  X *==v===X
X              X
X      XXXXXX  X
XX  X X*X*X XXXX
X              X
X         X=== X
X           X  X
X        XXXXXXX
X       XXXXXXXX
X     XXX  X XXX
XXXXXXXXXXXXXXXX

Dig the egg to the right, then dig left and dig 1R of the block you can push 
into the enemy. Dig 2U and 1U and 1U2L of the hole to drop a block in. Dig 1L, 
2R, 1R of the block below, then dig below the egg on the edge.

Push the block left and dig left of it and drop it. Bring the egg back left 
as far left as you can, dropping 2 rows. Dig 1U of the embedded block, kick 
it and dig the remaining square. Push the block into the enemy. Dig 1L of it 
and drop it right, then bring the egg back to the right. After the first drop, 
dig behind you so the boulder blocks the cat. Then push the boulder into the 
cat. Drop the egg on the right edge and back left 1. Now dig the square 1L3U 
of the cat and drop the top boulder down that chute. (dig behind it when it 
falls.)

Crush the cat and dig above the hole below, so you can drop the block 5 
squares above into it. Push the egg left then dig 1U1R and 1R of the block, 
then 1L of it to crush the cat below. Go to the DR to recycle and dig 1L of 
the egg to roll it down. Wait for the DL cat to fall off the edge first, and 
don't make the big drop--there's a block 2R2D of the egg. Loosen it and push 
it 1L. Then jump to push the egg right to the edge.

Push the block L L R. The egg can follow L L R R. Dig 1R, 1R1D, 1L of the 
block and drop it right, then dig 1U1L of where it lands so you can push it 
right. Dig 2D, 2D1L, 2D2L of the chute. Drop the egg down the two chutes. 
Jump onto the lone floor piece in the air on the left. If you miss, just dig 
under it. Then jump left and hold left and you will go right. (you can also 
2-1 dig.)

Push the egg so it falls once, then dig 1L of it, drop and dig under it. It 
lands on the yellow bit. Jump over it and roll it all the way left and down.

The game repeats after level 20.
