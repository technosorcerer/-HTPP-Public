Help a dick guide a petrified testicle through a maze!

Patch to Duck Maze (Australia) (Unl).nes