Dragon Warrior
Mapper Conversion Patch
FROM Mapper 1 (MMC1) TO Mapper 5 (MMC5)
Converted by Dracula X
RELEASE DATE: 10/2/19
Last Modified 07/12/2020




PRG Bankswitch Routine is at $FF96

To switch banks from $C000 - $FFFF, use like so:

LDA bank_number
JSR $FF96
JSR to any location in $8000-$BFFF

or

LDA bank_number #$80
PHA
LDA bank_number #$00
PHA
LDA bank_number #$04
JSR $FF96
RTS




CHR Sprite Bankswitch Routine (Left side of PPU) is at $FFAC

To switch sprite pages, use like so:

LDA page_number
JSR $FFAC




CHR Background Bankswitch Routine (Right side of PPU) is at $FFC2

To switch background pages, use like so:

LDA page_number
JSR $FFC2




Nametable Mapping Routine (one of its uses is mirroring) is at $FE09

To change mirroring for instance, use like so:

LDA mirroring_number (#$50 for Horizontal, #$44 for Vertical)
JSR $FE09

This patch does not work for:
Dragon Quest (Japan)

Hacks supported:
All!

Credits:
Rockman or RetroRain: for info on how to convert the mapper!
Disch: for his mapper docs and a better MMC5 startup!
Bregalad: for info about the game keeps on crashing!

Changes for this version 1.1a:
Changed the IPS format to xdelta format and all hacks are now supported.

Changes for this version 1.1:
Fixed the bankswitch code at location $FF96 instead of $FF7D
Changed the $5105 Nametable mapping code.

Changes for this version 1.1.2:
Added a new version number.
All emulators are now supported.

All emulators are now supported, but some emulators will show garbage.