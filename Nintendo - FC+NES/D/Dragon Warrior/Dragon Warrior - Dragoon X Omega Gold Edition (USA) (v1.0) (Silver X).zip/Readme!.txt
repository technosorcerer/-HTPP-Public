Changes list:

Version 1.0 (OMEGA)

Hacked the Battle Theme, the Flute song,and the Cave song. Rewrote the 
ending yet again,rewrote alot of the battle text,fixed some tiny bugs,
did a little work on some of the map layouts,rewrote a few parts of the
dialouge,and cleaned up (hopefully) all the bug problems. 


Version 0.98

Yet another little map error I found,only this time with the overworld.
It wasn't quite as bad as the previous bug in v 0.90,but it did suck.
Pretty much one of the biggest sub-quests in the game was pointless
because of this,so I fixed it in this version. I guess I really shouldn't
have cancelled the beta test phase after 2 days. I feel like an idiot
letting obvious crap like this slip past me.

This is a bigger update than 0.91,and among the new changes are:

Rewrote the ending.

Got rid of the ugly ass "shadow" tiles in the towns.

Made a few minor map fixes.

Redrew the metal brick walls.

Remapped some people on a few levels. (Now there shouldn't be any more
people in walls.)

Altered some of the monster and weapon/armor/shield stats.

Made the last battle MUCH harder.

Rewrote some of the dialouge to make some points of the plot make more
sense.

And a few small changes "under the hood" you probably won't notice.

I've personally went through the entire game myself,and everything looks
like it should now. This is the next-to last release of Dragoon X Omega,
so if you spot any small problems,such as spelling,ect,let me know and 
I'll be sure to fix them in version OMEGA,which should be out this fall
sometime hopefully. Now the game is where it should have been at the
time I first released it: basically lacking only the final music and
sfx changes.





Version 0.91

Wow,there was a room that once you took the stairs down,you couldn't 
get back out. What sucks worse is that this room holds one of the most
important items in the game,and you can't beat it without it.
And the funny thing is that I caught this bug a few weeks ago,and 
I was certain I'd fixed it. (Obviously not though.)

I did a quick run through with all the levels to make sure any other 
"little" errors like this were gone,and everything looks OK now.
So at least you should be able to beat the friggin' game now.


