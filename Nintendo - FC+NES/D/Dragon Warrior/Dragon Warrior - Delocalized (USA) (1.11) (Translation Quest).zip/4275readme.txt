DRAGON QUEST: DELOCALIZED


Thank you for checking out this Japanese style overhaul of Dragon Warrior for the NES.  The author has felt for some time that an uncensored and more direct contemporary English translation of the North American Dragon Warrior games would be an ideal way to experience them. While many have a love for the medieval style of the US localizations or the verbose, silly style of the contemporary English versions, the author hopes that players will also find value in a version of the game that closely represents the conventions and tone of Horii's original work.

For this version of Dragon Quest, all of the sprites of the game have been refashioned to represent the original graphics of the Japanese release, as opposed to the redone North American graphics. The original sprites have their own unique charm, create a better transition to the sequel, and also show just how much the series developed with each iteration. The author did take liberty in designing a custom 4 direction sprite for the Japanese hero in order to preserve the benefit of facing four directions while walking. Custom frames were designed for each weapon / shield configuration as well as carrying princess Laura.

Optional patches are included for reverting all the non-title screen graphics to that of the North American release. One option uses the standard North American palettes (grey wizard, blue maiden) while the other uses the Japanese palette choices (blue wizard, burgundy maiden). **Note: Apply dw_delocalized patch first. Then apply one of the graphics patches afterwards if you want to use NA graphics.

This patch is credited to the Translation Quest group, and was originally released by Chicken Knife on 12/16/2018. The authors give permission for any contents of this patch to be incorporated into other projects as long as credit is provided appropriately. 


VERSION INFO
1.11 released 8/1/20
-Fixed broken menu border during final battle.
-Made past tense consistent in battle text.
-minor adjustments to additional text.
-Improved translation of epilogue

1.10 released 7/7/20
-corrected a sprite mirroring flaw for maiden NPC with NA_gfx_J_palettes optional patch
-A handful of minor text revisions

1.09 released 6/17/20
-A few minor text revisions

1.08 released 4/29/20
-major overhaul of script with well over 100 improvements over previous version
-did away with previous graphical compromises by implementing all elements of Japanese sprites and original color palettes
-subtle improvements to custom four-way hero sprite and frames while holdling princess
-improved spear wielding guard by animating both legs instead of only one per Famicom
-improvements to the title screen, including a more logical golden window border and better speckled background tiles
-minor adjustments to spell names
-included two optional patches, one that reverts graphics to that of the standard North American version. Another does the same thing but adjusts the NPC wizard and maiden sprite to match the palettes of the famicom version and sequel
***apply one of these after the main patch if you wish to use them
-numerous comma issues were fixed for this update. Special thanks to KiloRH and AdamDravian for pointing out that issue, ultimately culminating in this very significant update

1.07 released 3/2/19
-completely changed spell names to offer English meaning while maintaining style original Japanese spell names
-minor text updates

1.06 released 2/04/19
-updates to battle and miscellaneous text
-minor revisions to NPC text 

1.05 released 1/30/19
-dialogue typo fix
-changed the wizard type enemies to Wizard, Sorcerer and Grand Wizard. The names of magic users had to be revaluated for all the games we are working on in order to make sure translations were consistent and the best fit possible
-changed Drackeema to Drackyma for consistency
-changed Meda enemies to Eyeba. The Japanese name is a truncated word for Eyeball, hence the equivalency
-changed Mark of Roto to Emblem of Roto. Mark was an incorrect interpretation of the use of the underlying word

1.04 released 1/21/19
-fixed minor graphical bug on copywrite screen
-touched up a line of npc text and capitalized the word power on the rest screen to make it match

1.03 released 1/20/19
HUGE UPDATE
-entirely rewritten script (for the second time), based on the capabilities of abw's ABCDE insertion/extraction software and through close collaboration with Japanese translator nejimakipiyo. The first rewrite was full of compromises based on line spacing. This rewrite was unencumbered but those restrictions and also includes the final removal of North American localization conventions like Dragonlord, Imperial Scrolls of Honor, and many others
-touched up dragon graphic that appears on title screen
-touched up 4 direction hero sprite graphics along with hero carrying Princess Laura
-did away with some foreign background tile graphics that had worked their way into the previous versions due to an unfortunately alterered base rom

1.02 released 12/21/18
-improved a couple additional lines of text
-additional minor title screen tweaks

1.01 released 12/20/18
-improved appx 20 miscellaneous lines of text including phrasing, adherence to Japanese text, and punctuation
-minor tweaks to the pixel art of the title screen
-updated Red Slime to She Slime since Japanese Slime Besu indicates female (subsequently altered to Slime Bess for an even more accurate translation)

1.00 released 12/16/18
-initial release


CREDITS AND THANKS

nejimakipiyo: For being a tremendous partner in writing and translation. The descendant of Roto might have had to go it alone, but the author is most grateful for such a companion on our quest for professional grade Dragon Quest translations. 

abw: for providing invaluable technical assistance, especially in the required know-how to overcome obstacles with the title screen, as well as providing critical support in assisting a non-technically oriented person like the author in the use of the insertion / extraction software abcde. This support could not be more appreciated.

Dattebayo: The author might bother him a little less than nejimakipiyo these days, but there are times the support of a native Japanese speaker is so critical (especially with unravelling the nuances of those obscure expressions!) Thanks for his great support and unwavering love of DQ.

Lady Cannock & "Some girl named Erinn": Big thanks to both of them for all the excellent contributions to our new spell naming system

Choppasmith: The author is grateful for him taking the time to answer questions and collaborate in spite being busy with their own cool "Project RE-Quest"

x_loto: for providing a translation document for the Japanese script into English. This team has eventually gone in different directions on numerous occasions, but this work served as a great initial base for the project.

Chris Wilder: for your support, enthusiasm and dedication to testing DQ: Delocalized.

Paul Acevedo: It's always great to have a friend who is a seasoned writer and English teacher when taking on the monstrous threat of grammar issues

Chris Markham: for convincing the author that Roto, not Loto is the official Japanese name of the legendary hero. (In a nutshell, every official reproduction of his legendary equipment made in Japan has the english letters ROTO inscribed on it)

Shaun Pendergast: For motivating the author to stay true to the warts and all approach.


GRAPHICAL CHANGES:


Custom designed 4 direction Japanese hero sprite.

Other NPCs were restored to their front facing famicom version. The following improvements were made:

Famicom guard was fixed so that both legs animate instead of one.

Corrected Famicom hero sprite's hilt sticking out from his hand which became 3x longer when sword was in diagnol position.

Altered foot animation of sprite carrying princess to make consistent with other foot animation.

Added coastal water tile graphics for NA release reverted to original Japanese graphics.

Custom title screen with Dragon Warrior changed to Dragon Quest. Overcoming of technical obstacles by abw, original title screen art by Choppasmith, numerous graphical touch ups by the author. 


ITEMS


(original names in parenthesis)

Bamboo Pole
Club
Copper Sword
Iron Axe (Hand Axe)
Steel Sword (Broad Sword)
Flame Sword
Sword of Roto (Erdrick's Sword)
Linen Clothes (Clothes)
Leather Armor
Chain Mail
Iron Armor (Half Plate)
Steel Armor (Full Plate)
Magic Armor
Armor of Roto (Erdrick's Armor)
Leather Shield (Small Shield)
Iron Shield (Large Shield)
Mirror Shield (Silver Shield)(*)
Medical Herb (from Herb)
Torch
Dragon's Scale
Chimera Wing (Wings)
Magic Key
Holy Water (Fairy Water)
Orb of Light (Ball of Light)
Stone Tablet (Tablet)
Fairy Flute
Silver Harp
Raincloud Staff (Staff of Rain)
Stone of Sunlight (Stones of Sunlight)
Laura's Love (Gwaelin's Love)
Rainbow Drop
Cursed Belt
Death Necklace
Warrior's Ring (Fighter's Ring)
Emblem of Roto (Erdrick's Token)

*1 - Mirror Shield was originally 'mikagami no tate' in Japanese. 
The word they were going for is 'mizukagami no tate'. Most likely truncated due to space constraints.
This means 'shield of reflective water'. 
It means that the shield is meant to be reflective like water but it's likely made out of a metal like mithril.
Mirror shield seemed closest to the intent of the Japanese name because of the 'kagami' being the head of the word.


MONSTERS 


Slime
Slime Bess (Red Slime)
Dracky (Drakee)
Ghost
Wizard (Magician)
Dracky Mage (Magidrakee)
Giant Scorpion (Scorpion)
Eyeba (Druin)
Metro Ghost (Poltergeist)
Droll
Drackyma (Drakeema)
Skeleton
Sorcerer (Warlock) 
Iron Scorpion (Metal Scorpion)
Werewolf (Wolf)
Wraith
Metal Slime
Hell Ghost (Spector)
Dire Werewolf (Wolflord)*
Eyeba Lord (Druinlord)
Droll Mage (Drollmagi)
Chimera (from Wyvern)
Death Scorpion (Rogue Scorpion)
Wraith Knight 
Golem
Goldman
Armored Knight (Knight)
Chimera Mage (Magiwyvern)
Shadow Knight (Demon Knight)
Killer Werewolf (Werewolf)
Dragon (Green Dragon)
Star Chimera (from Star Wyvern)
Grand Wizard (from Wizard)
Demon Knight (Axe Knight)
Kith Dragon (Blue Dragon)
Stoneman
Reaper Knight (Armored Knight)
Darth Dragon (Red Dragon)
Dragon King (Dragonlord)

*Dire Werewolf is "lycant mammal" in the Japanese (and the other wolf enemies are also called Lycant)
But for this one we decided on something that sounds better, over strict accuracy. 


SPELLS


Heali (Heal)
Flara (Hurt)
Slumbari (Sleep)
Luminara (Radiant)
Stopmaju (Stopspell)
Vacatara (Outside)
Flyra (Return)
Abatetoil (Repel)
Helimi (Healmore)
Flarama (Hurtmore)

*The translation team understands that the renaming of spells can be controversial, but they truly feel that neither the original English localization nor the contemporary localization come anywhere near representing the Japanese spell names accurately. Therefore, the formation of a new English system was deemed a necessary part of the retranslation. The vast majority of Japanese spell names throughout the series are formed by fragments of meaningful words or contorted version of those words, followed by exotic suffixes (and occaisionally prefixes) that expand in a way that signifies increasing power within a family of spells. In nearly all cases, the authors looked for a word in English that best represented the meaning of the Japanese base word, altered that word in an equivalent manner, and utilized the same style of suffixes that were used for the Japanese spell names. Adjustments were made for the purpose of creating words that sound good in English. The translation team hopes that the net result is a highly accurate set of names that are also memorable and fun.


Locations


Ladatorm Castle (Tantegel Castle)
Ladatorm (Brecconary)
Garai (Garinham)
Maira (Kol)
Rimuldar
Domdora (Hauksness)
Melkido (Cantlin)
Dragon King's Fortress (Charlock Castle)
