Dragon Warrior Modernizer 1.0
=============================
by Nathan "gblues" Strong

This patch makes the following changes:

1. Spell names are (mostly) renamed to align with modern Dragon Quest localizations.
2. Spell names are now mixed-case.

The only spell name I could not update was REPEL, which is now called "Holy Protection."
The new spell name is too long to fit into the menu, and I'm not a fan of abbreviations
like "HolyProt", so the utilitarian name is kept.

APPLYING:

The IPS was generated against the Dragon Warrior ROM with MD5 hash of 25cf03eb7ac2dec4ef332425c151f373