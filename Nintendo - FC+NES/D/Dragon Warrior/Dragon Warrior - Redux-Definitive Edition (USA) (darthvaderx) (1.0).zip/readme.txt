
  Dragon Quest Redux/Definitive Edition (Dragon Warrior).

  The objective of 'Dragon Warrior Delocalized' is simply to restore all the elements changed from the Japanese version to the American version (with the option of keeping some of the latter). And also adding the following improvements:

-DW Delocalized hack v1.18 by Translation Quest.

https://www.romhacking.net/hacks/4275/

-DW DX hack v1.0 by LastduaL (sprites from GBC version).

https://www.romhacking.net/hacks/3963/

-DW Updated Command Menu hack v1.1 by Pterias.

https://www.romhacking.net/hacks/7258/

-DW Doubled XP & Gold hack v1.0 by Psyklax.

https://www.romhacking.net/hacks/3830/
