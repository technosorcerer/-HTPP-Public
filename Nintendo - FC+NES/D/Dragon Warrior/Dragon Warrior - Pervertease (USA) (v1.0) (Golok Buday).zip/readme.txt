~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Dragon Warrior Pervertease translation and mature graphic changes:
v. 1.0000000.0000000.111111.222222.3.44.555.66.7777.888.89999.9.10 Alpha Beta Ceta Delta-Omega release.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Have fun with this one, it is a real funny hack and I hope you enjoy it, and understand the amount of effort myself (Gölök) and ~aStROcReEp 2000~ put into this.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
1. Credits
	1.0 Gölök The Mental Midget Slayer: Project Administrator, re-writer, and Graphic 		editing.
	1.1 ~aStROcReEp2000~: On HEX.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~2. Special Thanks to:
	2.0 Sardu, for implementing a tile editor in the NESticle (nesticle.parodius.com).
	2.1 TyphoonZ, for putting up my Dragon Warrior 97 hack.
	2.2 Skunko, for puttin up all my past hacks.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~3. Rules:
	3.0 Only for use on the NESticle, any other EMU is not worthy.
	3.1 Have fun.
	3.2 No info, ROM, emuralated requests.  Praise or Comments are welcome.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
4. Disclaimer:
	4.0 I am not responsible for any offence that this hack may cause, if you have no fuck'n 		sense of humour, kiss my hairy ass!  Complain to me at: your@nazi.fag.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
5. Censorship Sucks: 
	5.0 http://www.eff.org/blueribbon.html
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
6. DW Pervertease by:
	6.0 Gölök (Zoltán Leenderdt Franco Buday) The Mental Midget Slayer.
		6.01 zbuday@lightspeed.bc.ca
		6.02 http://www.dragonfire.net/~GolokZLFBuday/
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
7. In Partnership with:
	7.1 ~aStROcReEp2000~ (Jason Leonard).
		7.10 jason1@ipa.net
		7.11 http://members.tripod.com/~jaleonard/
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~