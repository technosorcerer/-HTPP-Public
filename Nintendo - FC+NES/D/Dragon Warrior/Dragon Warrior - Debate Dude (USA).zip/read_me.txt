				Rom Hack Info

NAME OF HACK -			 Debate Dude
NAME OF ORIGINAL -		 Dragon Warrior
NAMING CONVENTION -		 I'm not quite sure what you mean by proper(Good) naming convention rom
 		          		 name. If you mean the file type like .txt, then it's .nes and the patch is a
                                                		*SURPRISE* .ips
SYSTEM-				 NES
E-MAIL ADDRESS-			 slanderton@hotmail.com
WEBSITE-			 http://www.geocities.com/snorrisage
OTHER INFO-		1)	 I haven't tested the entire hack, so I'm not sure If I'll need to make any updates
				or not.