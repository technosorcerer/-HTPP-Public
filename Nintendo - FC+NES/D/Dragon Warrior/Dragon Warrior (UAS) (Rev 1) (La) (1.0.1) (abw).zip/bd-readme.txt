Dragon Warrior Latin Translation
by abw
Version 1.0.1
Release Date: August 21, 2018

Checksums (unpatched):
GoodNES File Name: Dragon Warrior (U) (PRG1) [!].nes
File MD5      25CF03EB7AC2DEC4EF332425C151F373
File SHA-1    1ECC63AAAC50A9612EAA8B69143858C3E48DD0AE
File CRC32    D4D5F5D7
ROM MD5       E0413C76F69F5ACA4A1F5336B86851B6
ROM SHA-1     240E445AB95C3A5AFBEF63E9239EACC9F9FE1E19
ROM CRC32     2545214C

Checksums (patched):
File MD5      D40673AAEF97207ACD6D885D7125BADC
File SHA-1    73AC8E786512E1747AEB960D123D056270FC44CC
File CRC32    B0886C77
ROM MD5       3C149C7060676EFBD20E79A387F5EA2B
ROM SHA-1     F386CBFE93CA628C82710725940299C93D4EC071
ROM CRC32     4118B8EC


To Apply the Patch:
	You will need: a copy of the Dragon Warrior ROM and an IPS patching utility. If you don't have the ROM, go ask Google how to get it. If you don't have a patcher, I can recommend Lunar IPS (http://www.romhacking.net/utilities/240/), so snag that too. Then simply follow your chosen patcher's instructions to apply the patch to the ROM. Now that that's done, fire up your favourite NES emulator and prepare yourself for some Latin-ey goodness!

About the Patch:
	"Buy thy radishes today!"

	I guess you could almost say I translated this game by accident - while attempting to assist werewolfslayr925 with various aspects, technical and otherwise, of a Spanish translation of Dragon Warrior, I found myself creating one partial extraction and/or insertion script after another as we moved through the separate sections of the game's text. By the time I was done, I was able to combine all those partial scripts into one and ended up with a complete text dump all ready and waiting to be re-inserted, so I said to myself: "Self, we might just as well translate this into Latin!". So that's what I did :p.

Progress:
	Aside from the fancy "The End" text after the end credits, which were in English even in the original Japanese release, the remainder of the game is entirely in Latin.

Contact:
	Fan mail, insults, comments, suggestions and the like can all be sent to tempestas.caput@gmail.com where they will almost certainly all be read (unless they get filtered as spam). That said, I have been known to go for extremely long periods of time without checking my mail, so don't be upset if you don't receive a response in a timely manner!

Thanks to:
* All the helpful people who wrote the utilities and documentation I've used, particularly:
** The FCE(U/X/XD/SP/etc.) development team - this patch would have been more annoying to create without a quality debugging emulator.
** William A. Whitaker and his WORDS program for providing the world with a Latin spell-checker.
** Yy (albeit grudgingly this time). Why does "click on tile" + "Copy" + "Paste" = "rotated palette"? Grr.