Super Mario Remix 2 - Bowser Has Kinopio!
By Shawn Huckabay (Omniverse) and Jeremy Mikus (Shaku)
v0.10

Done Thus Far
    Few enemies
    A bit of dialogue
    Many gfx
    All weapon/armor names
    Some mapping

To Do
    Rest of enemies
    Rest of dialogue
    Rest of gfx
    Rest of mapping
    Cost/Power of Weapons/Armors

Contacting Me
    E-Mail		omniverse@smtinspection.com
	Web			http://www.emucamp.com/omniverse/