             -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
                  Drunken Warrior v.30     
              A text hack for Dragon Warrior
                         By Neil_
             -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

"To the best of my knowledge, the only hack
     with a drunk ips file!"

I. Who?
II. What?
III. Where?
IV. When?
V. Why?
VI. How?

I. Who made this piece of utter...

Well, Neil_ did the h4x0ring, dialogue rewrite, etc,
etc, etc. Gema2k and the #DragonQuest of EFNet crew
helped him along by inadvertantly giving him the idea.
Many of the concepts expressed here in are products of
the very strange mind of Gema2k. ;)

II. What is this thing?

It's a text hack of the old NES game Dragon Warrior. It
changes the story a bit at this point. However, it is not
complete, and it probably never will be. I long ago lost
interest in continuing this project, however one of these
days I might just pick it up again. Yes, there are some
bugs with text allignment and pointer problems... But you
know what? This thing took me like an hour to do, including
making the table file and thinking up stuff... so it's not
as if I suck enough to have wasted months trying to fix these
bugs. Truth be known, I made no attempt to. ;) If you feel the
urge to continue this thing, go right ahead, just give credit
where credit is due.

III. Where can I get the romh?

I dunno. Dont' ask me!

IV. When did you work on this utter piece of krap?

The version of this hack you see in that ips patch was created
Thursday, October 07, 1999 @ 11:19:34 AM. The ips patch itself
was created and released on November 30th.

V. Why?

I have no clue.

VI. How?

I made the table by hand.
I used DeJap's classic SearchR v.01
For hex editing I used Hex Workshop and Hexposure.

             -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
                        THE END
             -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
