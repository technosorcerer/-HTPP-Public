~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  Dragon Warrior I USA Version
  For Nintendo Family Computer
  Arabic Translation Patch
  Version 1.0.3

  Created by Athbi S (q8fft) Translation and Hacking : q8fft2 [@] gmail [dot] com .
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

CREDITS to
-----------------
  Yasser Hamouda
   he is Legendary Game hacking, to supprt TEXT ROUTINE 
   to right to left (RTL Hack).
   Email:https://www.facebook.com/yassertof
   
   A7med Bamatraf
   he is Create محول الحروف 
   Email:A7med.bamatraf@gmail.com

   Thanks to Help:
   - Yasser Hamouda
   - Mouhssine Megamanz
   - Mansour Lagaffe
   - Wes Snyder
   - Mohannad-sword Ali
   - Pease Eagle
   - زياد مكية
   - DragonArab
   - Banzin
   - Extraordinary TEAM
   - dragon quest
   * Big Thanks for romhacking.net
   * And All

Project History:
-----------------

Febr 25, 2017
  really i dont know what i say,  The beginning of adventure.
  This is the first time in history the One Series Dragon Warrior Games is translated into Arabic
  And I'm glad I'm this person ^^, This game has completely changed the direction of the text to,
  accept Arabic in an excellent way to Right to Left (RTL).
  
  واخيراً انتهيت من تعريب لعبة دراجون وارير او دراجون كويست الجزء الأول على منصة نينتندو العائلة
  الذي استغرق تقريباً شهرين من العمل المتواصل مع أن من الممكن يتم الانتهاء من هذا المشروع بوقت
  أقل جداً لنا اللعبة لا تحتوي على الكثير من النصوص غير انها قصة كلاسيكية جميلة
  لكن تحليل اللعبة ومعرفة كافة تفاصيلها احتاج إلى هذا الوقت وغير اني لست جيد في تعريب الالعاب
  إلى ان كانت التجربة أكثر من رائعة وانا مستمتع حقيقة اثناء عملي على هذا المشروع الجميل
  وايضاً تم تهكير اللعبة وجعلها جميع النصوص تخرج من اليمين إلى اليسار لتناسب اللغة العربية الجميلة.
  وانا سعيد حقاً بأني أول شخص في التاريخ يعرب أحد سلسلة ألعاب دراجون وارير وينتهي منها.
  وهذا طبعاً يأتي اولاً التوفيق من الله سبحانه ثم جميع المشاركين في التعريب والمساعدة وعلى رأسهم السيد ياسر
  الذي جعل المستحيل ممكنناً وحتى اصدقكم القول اني لم افكر ان من الممكن يتم قلب اتجاه سريان النص إلى اليمين!
  واخيراً شكراً لكل من شارك سواء في المساعدة او لم يشارك اهم شي حصلنا على مبتغانا ولله الحمد.
  والسلام عليكم ورحمة الله وبركاته..
  
Version History:
-----------------
	Version 1.0.3,    Jun 7, 2017 [ bytes]
	- اصلاح ترجمة الحالة سقطت سهواً
	وهنا شرح الاختصارات باللغة العربية
	LV = م.س تعني مستوى
	HP = ن.ص تعني نقاط الصحة
	MP = ن.س تعني نقاط السحر
	G = ذهب
	E = خبرة
	
	Version 1.0.2,    Jun 7, 2017 [ bytes]
  - اصلاح وتنسيق بعض النصوص.
  - ترجمة كلمة اسم في شاشة كتابة الاسم، لقد غفلت عنها ولم اترجمها.

  Version 1.0.1,    ? ?, 2017 [ bytes]
  - تنسيق بعض النصوص. أمرك.

  Version 1.0,    May 4, 2017 [ bytes]
  - تحديثات بسيطة وهم:
  - اضافة رمز * عند بداية جملة  دلاله على بداية جملة جديدة مثال النسخة اليابانية.
  - اصلاح رسم بعض الحروف العربية.
  - إضافة الارقام الهندية.

  Version 0.99,    April 26, 2017 [ bytes]
   Done. Go. Play. NOW.

Change log:
-----------------

- Done

TODO:
	- ????

What's left:
-----------------
  - مشكلة الارقام لم تعكس ولا اعرف ان كان استطيع حلها او لا.
  - مشكلة العتاد في صندوق النصوص ايضاً لم تنعكس الامر معقد.
  - شاشة البداية او شعار اللعبة الذي فضلته ان يبقي كما هو.
  - لكن في الاخير اللعبة قابلة للعب دون مشاكل.


Game Notes:
-----------------
  .......


Copyrights
-----------------
  Dragon Warrior, and all other names are trademarked to
  Nintendo and Square Enix of Japan.


Disclaimer
-----------------
  There is no videogame company or any other company associated with
  Athbi S. In no event shall Athbi S be liable or responsible for
  any damages that may occur from direct, indirect or consequential results
  of the ability or disability to use or misuse any material it provides.

  In other words, you'd better own the cart for the rom that you're patching,
  and if something goes wrong, don't blame me!
