This Patch Just Make Game Supprt RTL. I make this patch For those who want to know how to change the direction of the text.

All CREDITS to Yasser.