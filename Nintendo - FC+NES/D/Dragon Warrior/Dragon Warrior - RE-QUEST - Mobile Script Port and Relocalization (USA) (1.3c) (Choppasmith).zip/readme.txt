Dragon Warrior - Project RE-Quest Edition Readme
Version 1.1

What's New?
-----------
1.3c (1-19-2019)
-Did a THOROUGH search and fixed a few more dialog breaks. That SHOULD be the end to that.
-Overlooked a couple of lines retaining their DW original dialog. Using the Rainbow Drop and selling items.

1.3b (1-15-2019)
-Thanks to abw who devised some new ASM to properly enable/disable non-indented third person dialog on the fly. This fixes the ending, some of Dragonlord's dialog, and the sage with the Rainbow Drop. Silent third person narration is no longer an issue!
-Fixed a typo for a Kol NPC and a Cantlin NPC (thanks laserlambert)
-Tweaked more dialog breaks (Princess' Pledge and various buy/sell and yes/no prompts should no longer require an extra button press)
-Fixed scrambled, out of order dialog when bringing Gwaelin to the King.


1.3 (1-9-2019)
-More battle message tweaks. Fizzle-related messages should be fixed and stat increases on level up are a little smoother
-Stone Golem typo fixed
-Various script tweaks, mostly adding new pause and line breaks. Added some missing dialog for Princess' Pledge item. The merchant in Rimuldar (by the key shop) and the twin guards in Galenholm now have updated dialog. This now leaves the Nester cameo in Cantlin as the only unchanged NPC.
-More logo tweaks by Chicken Knife
-Updated End Credits with a small change to reflect new translation (also changed "Character Designed" to "Character Design").
-Lack of silent third person narration added to "issues".
-Checked and tweaked Inn dialog when carrying Gwaelin (thanks High Score Girl anime!)


1.2 (12-19-2018)
-Fixed an inaccurate pointer which scrambled some NPC dialog among Galenholm, Kol, and Rimuldar (thanks AustNerevar).
-Fixed the dialog for discovering items like the faerie flute that was referring to the hidden staircase in Dragonlord's Castle. Also changed the name of said staircase to "hidden stairway" because the game doesn't like displaying item words longer than 8 letters (thanks laserlambert!).
-Fixed "new spell learned" dialog and changed an old line referring to a "treasure box" to "treasure chest".

1-1 (12-11-2018)
-Slight iprovement tweaks to logo (thanks to Chicken Knife who's a far better pixel artist than me)
-Patch is now XDelta which should avoid any sort of copyright issues AND should be better compatible with other patches (thanks Count Buggula)
-Added some pauses to the King's dialog for better readability. 



  
So, what is this?
-----------------


I'm a Dragon Quest fan. Yeah I played the original Dragon Warrior for NES, but it wasn't until Square-Enix's recent releases and completely overhauled localization that really made me a hardcore Dragon Quest fan. Square-Enix released some decent remakes of the Erdrick trilogy (I-III) on Mobile devices based on the Super Famicom remakes (DQ I+II getting a bit more visual polish). The upside is that these featured a lush, extravagant translation that mixed the old school Olde English dialog of the NES games with a bit more flair and charm of Modern Dragon Quest releases. These releases are also consistent with other games that reference them directly like Dragon Quest Builders. The downside to these mobile exclusives are... well, they're exclusive to mobile devices, and from a technical standpoint... they're not the best. No controller support, stuck in portrait mode! Yuck! What if I just want to play the games the good ol' fashioned way? 

And this is where PROJECT RE-QUEST comes in. Inspired by the likes of 121J and Chaos Rush and recently being able to extract the scripts from the three mobile games, I now have the means to port the scripts to the three Dragon Quest games.




What�s all changed?
-------------------
Well, the big thing is the script. Thanks to ROM Expansion, the script is now doubled in size from 15 KB to 30 KB! If you haven�t played the mobile port, you�re in for a treat with richer, more robust dialog. Items, monsters, and spell names are also updated to their modern Square Enix localization.

 We�ve also got a new title screen properly calling the game Dragon QUEST using the authentic font Nintendo and Enix used, Rustikalis.




Hey! What gives? That�s not the REAL Dragon Quest logo! Can�t you just copy the original over from the Japanese version or something?


-------------------
Sadly, it�s a technical issue that makes it almost impossible (especially for an amateur like me). The game received a big graphical overhaul for the American release, there would have to be some significant reprogramming from scratch. Never say never though, if it�s ever done, I�ll add it in an update.




Any other problems I should know about?
--------------------
The remake really shuffles and adds material not found in the NES original and I did my best to compensate. Whether it�s repeated dialog shared among NPCs or removing �functionality� and �behavior�. Another thing is my de-censored Puff Puff scene. In the original Japanese version, you�d pay a girl in Rimuldar 20 G for a Puff Puff. For the west, sher dialog was changed to be a simple message about tomatoes. In the remake the girl is in Kol instead. To avoid any complicated issues in reprogramming the NPC, I took a cue from Dragon Quest Builders and just made it an offer with an implied decline from the Hero. Future DW games don�t have this significant programming change. Still, in the long run, I�d say this is still a 95% accurate and complete port of the mobile script.





Special Thanks
--------------------



abw - This hack wouldn�t be nearly as robust without his gracious help. Between helping me expand the rom and knowing how to make longer enemy names. He was incredibly patient and helpful. I feel like a lot of this hack is as much his as it is mine.


Aerynb - For the encouragement in finally getting those script rips as well as her Dragon Warrior �script� which detailed who said what where that helped me know where to put the new script in.


Dwaine - For discovering the Rustikalis font used in the Dragon Warrior logo (and TheRaven81 for providing it)


Torridgristle- For the nice tip in removing the black bar on the title screen


aluigi - Creator of QuickBMS who also made the script for ripping DQ 1-3 mobile possible!
Everyone else on the Romhacking.net and Dragons Den communities for their support.



