This is a simple patch for Dragon Warrior that reduces some of the flashing effects found in the game. It aims to help those sensitive to flashing effects experience the game.
There are two known effects that have been reduced by this patch.
1. The enemy sprites flashing when you do damage to them in combat.
2. The full screen flash that happens when you step onto a poison swamp tile.

This is an IPS patch created against the Rev 1 USA version of the game. It can be patched using something like Lunar IPS or the Online ROM patcher on ROMhacking.net.

Database match: Dragon Warrior (USA) (Rev 1)
Database: No-Intro: Nintendo Entertainment System (v. 20210216-231042)
File SHA-1: 1ECC63AAAC50A9612EAA8B69143858C3E48DD0AE
File CRC32: D4D5F5D7
ROM SHA-1: 240E445AB95C3A5AFBEF63E9239EACC9F9FE1E19
ROM CRC32: 2545214C

I don't have access to other versions of the game to determine if the patch would be work on them. 

If you are uncomfortable applying a patch to a rom from a novice patcher, the following Game Genie codes can be used to do the same things as the patch.
ATOTKTAZ - Remove full screen red flash when stepping in poison swamps
ATUVENOZ - Stop enemy sprites from flashing when you hit them