Dragon Warrior 2000: Beta Gamma Delta Version 1.2.2.0.33131123123123.1231231231123131231225446648776978.4324325
Release -12

Changes are minor, it's based on DW97; text changes and palette changes are in the making.
I basicaly got tired of uninventive crap like red slime, metal slime, blah blah blah.

Thanks to "THE MCA / ELITE" for SNES Tool.
Blood Lust Software for his brilliant emulator and its pixel editor.
The creator of pasofami (which I used to put DW4 tiles on DW97 in 1997).
Thanks to Translation Station's creators, great for text editing.

The Upgrade Patch is an Upgrade from DW97 [The origional DW97, not the other guy's DW97].


Black Magus/Black Jester/Mental Midget Slayer/The Voltairian/The Egomaniac
http://courtjester.dragonfire.net/
http://myegotimes.virtualave.net/
http://blackmagus.virtualave.net/



Donations: Donations can be made in the form of a beautiful woman without a gag reflex 
to G�l�k Buday.

Ps: Do not ask me from Roms or about new releases; Zophar's domain will be the official 
distributer with exception of my site "The Official Black Jester Web Site," don't bother 
Zophar's staff either; if a new release is available it will be mentioned.