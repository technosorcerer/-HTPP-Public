Dragoon X Final                          
Hacked by Sliver X (sliverx@hotmail.com)
Original game: Dragon Warrior
***************************************************
What you need:

An unaltered rom of Dragon Warrior.

An IPS patching program.

This IPS file.
***************************************************
It's finally done, not that I expect too many people to care.
Have fun.
***************************************************
What the hell's new in this version?

I finished rewriting all the dialogue, finished the unchanged enemies,
messed around with a few existing changes, such as some enemies and
the townsmen for aesthetic reasons, made a few pallete changes by
altering the attribute table, renamed all the items, weapons, ect.
Basically everything in the game is altered, except a few of the 
dungeon levels, which I didn't feel like screwing with, and the over
world, which I have no idea how to hack into.

***************************************************
Things that really piss me off about this hack.

1. My artistic abilities.
2. Some of the palletes, such as the guards at the end of the game.
3. The way some blocks of text get repeated by three different people
at different points in their dialogue, and the small amount of text
space. But what can I expect? This game IS older than hell.


Other than that, I'm pretty happy about this hack. I had alot of fun
doing it, and that's all that really matters to me. Hopefully you'll
get at least 10 minutes of enjoyment out of this.
****************************************************
What's next?

Uh, I have no idea. It takes forever doing an extensive hack with
only one person working on it. I might try something with Astyanax or
Clash at Demon Head, once I get some free time.
Anyway, hope you like this, and I'm probably wasting my time asking 
this, but email me if you find any spelling errors, just plain fucked
up shit, or actually have any comments on this. 

Sliver X  12/26/98
http://members.citynet.net/sliverx/index.html