SRW2 - 30th Anniversary Patch

NES version "Super Robot Wars 2" 30th anniversary IPS patch.

SRW2_30th_AnnPatch.ips
-------------------- changes ---------------------
- Face graphic of all pilots
- Coolly adjust the facial expressions of Gundam MS
--------------------------------------------------

SRW2_FontChange.ips
-------------------- changes ---------------------
- Alphanumerics and each story title
--------------------------------------------------

SRW2_Easyer.ips
-------------------- changes ---------------------
- Reducing SP consumption and item price
  So that light users can also enjoy it ;D
--------------------------------------------------

P.S.
"SRW2_30th_AnnPatch.ips" and "SRW2_Easyer.ips" can also be applied to the translated version.

Dai-2-Ji Super Robot Taisen (EN)
https://www.romhacking.net/translations/221/

