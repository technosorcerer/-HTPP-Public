"Dai-2-ji Super Robot Taisen" o "Super Robot Wars 2"
Traducción al Español Ver. 1.0 (24/01/2021)
por Max1323 (maxmuruchi@gmail.com)
Basada en el gran trabajo de Aeon Genesis.
---------------------------------------------------
Descripción:
Super Robot Wars 2 fue desarrollado por WinkySoft y 
fue el primer juego de la saga para una consola de sobremesa.
El juego continua con lo ocurrido en entrega pasada, está vez el 
enemigo es el DC (Divine Crusaders).
Su líder Bian Zoldark, predijó que habrá una invasión alienígena 
y para ello necesitará un Super Robot, Valsion y su ejercito el 
DC. Aunque necesitaban más robots, empezaron a capturarlos uno 
por uno.
Solo 3 Super Robots lograron escapar y crearon una resistencia 
que pueda hacerle frente al DC.

Desarrollado: WinkySoft
Publicado:    Banpresto
Lanzamiento:  19/12/1991 (JAP)
---------------------------------------------------
Acerca del proyecto:
-Se tradujo los textos y los gráficos.
-Se agregó los acentos, la ñ , ¿ y ¡.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS

Dai-2-ji Super Robot Taisen (Japan).nes
File size     512 KB
File MD5      F5D5B8001C9F1DD804F8EDA5CB8ECDC6        
File SHA-1    9882F323FB11BE792E8037034DD1C56CC49AA26B
File CRC32    62C5D10C