--- Patching ---

The ips file labeled "Mario World NTSC v1.0 (Japan) (Rev 1).ips" must be patched onto a Devil World rom titled as "Devil World (Japan) (Rev 1).nes" or something similar to that.

The PAL version ips file "Mario World PAL v1.0.ips" was built using the rom file "Devil World (E) [!].nes". 

--- About Mario World ---

The Mushroom Kingdom is never safe with Mario at large! Help the lowly Galoomba (or two Galoombas with Player 2) take over Mario's world, grab fire flowers to defeat Shy Guys under Mario's control and grab all the power dots, collect ? boxes and return them to the ! base to send Mario packing! Watch out for Toad, he is immune to fire flowers. Rumor has it Luigi sometimes makes an appearance too. Go for the high score in this thrilling Mario maze game! 

Mario World came about from a passing thought, "how could Devil World have possibly been localized for the USA market in the 80s?". Well, put in Mario characters of course! This is just a graphics, palette and text hack. The maze layouts are unchanged. I originally built this hack on a PAL Devil World rom, I don't know why. Recently I ported it to a Japan NTSC Rev 1 rom, so this hack has an NTSC and PAL (speed unoptimized) version, enjoy.

sucrose1 2023 /end of file