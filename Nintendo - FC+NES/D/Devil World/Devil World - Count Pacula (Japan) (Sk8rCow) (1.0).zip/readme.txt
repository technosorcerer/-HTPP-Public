Count Pacula
2024 Sk8rCow

Happy Halloween!

In this hack of Devil World, you play as Count Pacula, who is a blight on the good Pac family name. In order to rid the countryside of this embarrassing pest once and for all and clear the good Pac name, Pac-Man decided to truce with Blinky, who agreed to help take Pacula down. Since the rest of Blinky’s gang declined the truce, he brought along old friends Harry and Rocky. Pac-Man and the newly assembled ghost gang (and their clones, apparently) met at the ancient Pac mansion. At nightfall, Count Pacula leaves his coffin to enter the mansion. When in the mansion, he eats all the red dots that appear on each floor and returns to his coffin before daybreak. He has done this every night for centuries. But not tonight. Tonight is different. Tonight when he enters the mansion, he is startled by Pac-Man and his new gang. He runs frantically through the mansion, trying not to get crushed by the walls and fleeing the ghost gang. When he picks up a moon, he is able to eat the red pac-dots and fire bats at the ghosts, which shrinks them and allows you to eat them.

This hack is loosely based off of a cancelled pitch by Midway for a video pinball hybrid game similar to Baby Pac-Man. Of course, I couldn't make it EXACTLY like the original for obvious reasons.

(story slightly modified from the original pitch. Most of the insanity from the original, however, has been preserved.)

Patch the rom to an NES rom of Devil World

FUN FAX!
- The two "new" ghosts Harry and Rocky come from the Japanese pop up store "Pac-Store." I originally planned to add the rest of the ghosts, but there are only three enemies in devil world. 

- I would've added Terry (also from Pac-Store) instead of blinky, but the enemy that I wanted to replace with him shared Pac-Man (or the devil)'s color palette.

- Before I added the ghosts from Pac-Store, I wanted Pac-Man's family to be the enemies, as they were in the original pitch. Unfortunately, it didn't work as I wanted it to and had to be scrapped.

-All of Pac-Man's sprites were modified from Pac-Land, except for his shrinking animation, which uses sprites from Super Mario Maker, Pac-Man, and Crazy Otto (which was modified to remove his eye and legs). His front facing sprites were made by me and were PAINFUL to make. (I suck at pixel art.)

CREDITS:
Me - Hacking
Midway - original concept
Brianfan - Logo font (ingame, slightly modified).
RingoStarr39 - Logo font (on pretty much everything else)
Pac-Man is owned by Bandai Namco Entertainment
