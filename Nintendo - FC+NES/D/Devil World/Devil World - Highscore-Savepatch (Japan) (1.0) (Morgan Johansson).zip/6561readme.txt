Devil World
===========

If you have intentions of selling cartridges with this patch applied, please don't!

Version: 1.0


What's this?
============
This patch adds highscore-saving to "Devil World".


Usage
=====
Apply the patch to the file "Devil World (J) [!].nes".


Author
======
Feel free to contact me with ideas, suggestions or even some kind words. :)
I spend *alot* of time with these hacks and if you feel you'd like to support
my work, feel free to use the Paypal-button on my website.
E-mail: morjoh@live.se


Website
=======
All my hacks are available at my website, currently http://nes.goondocks.se.
The site will sometimes load a little slow, but have patience.


History
=======
v1.0	2013-06-12	* First release!

.-----------------------------------------------------------------------.
| My releases                                                           |
+-----------------------------------------------------------------------+
|                                                                       |
| 001. Mario Bros Classic Series (E)..............Highscore saving      |
| 002. Excitebike (VS)............................NES-patch             |
| 003. Pinball (VS)...............................NES-patch             |
| 004. Ice Climber (VS)...........................NES-patch             |
| 005. Duck Hunt (VS).............................NES-patch             |
| 006. VS Goonies (VS)............................NES-patch             |
| 007. Mario Bros (JU) [!]........................Highscore saving      |
| 008. Excitebike (JU) [!]........................Track saving          |
| 009. Castlevania (VS)...........................NES-patch             |
| 010. Popeye (J) (PRG0) [!]......................Highscore saving      |
| 011. Hogan's Alley (VS).........................NES-patch             |
| 012. Donkey Kong (JU)...........................Highscore saving      |
| 013. Donkey Kong (original edition).............Highscore saving      |
| 014. Donkey Kong Jr (J) (PRG0) [!]..............Highscore saving      |
| 015. New Clu Clu Land...........................FDS conversion        |
| 016. Ice Climber (FDS)..........................FDS conversion        |
| 017. Devil World (J) [!]........................Highscore saving      |
|                                                                       |
+-----. .-------------------------------------------------------. .-----+
      |_|                                                       |_|