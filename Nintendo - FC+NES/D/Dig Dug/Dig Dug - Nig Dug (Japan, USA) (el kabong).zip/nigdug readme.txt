NIG DUG by el kabong
licensed exclusively to baddesthacks.net


I forget the quote that started this, but it was something about cloning
dig dug and renaming it to "nig dug", with relation to prison escaping


anyways, this is a hack of dig dug, in the grand tradition of making
everything offensive as fuck

if you are offended, too bad, cry to someone who gives a shit


changes I can think of:
. "1 player" and "2 player" changed to "1 nignog" and "2 nignogs"
. namcot logo replaced with KADONG logo (this was a bitch to edit)
.
 copyright text
. the player is now a black guy
. pookas are now awkward looking policemen
. fygars are now firemen (as in, they make fire with flamethrowers)
. 
fire sprites lazily edited to look like they're coming out of the flamethrower
. rock sprites are gray now
. stage flowers changed to "RIP COP" tombstone and "
FBI WANTED" poster
. font changed because i felt like it
. drop shadow added to sprite font for readability
. "player 1" and "player 2" sprite text changed to 
"negro 1"/"negro 2"
. pump changed to a dong (quite lazily, i might add)
. title logo changed
  (when you're lazy and don't want to edit tiles, this is what you get)


some notes:
. this game uses 8x16 sprites, which is annoying, but warranted
  it really sucks for notifications like "player 1 ready" though;
  
all those blank tiles wasted as an alcoholic on a sunday morning
. the player's pump is colored in with solid blocks that appear under the
  player sprite; 
i could have technically changed this but it's more effort
  than it's worth for a hack of this caliber :D
. the enemy sprites are lazy hacks of the player character
.
 the flamethrower guy is my favorite set of sprites in the hack
  i really love the fistpumping he does before he fires

- el kadong
