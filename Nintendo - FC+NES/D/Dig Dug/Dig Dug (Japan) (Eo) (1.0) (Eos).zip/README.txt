Dig Dug Esperanto Translation by Eos
The translation is mostly complete, just missing "PLAYER 1/2 READY!" & "GAME OVER"

Apply over Japanese ROM.