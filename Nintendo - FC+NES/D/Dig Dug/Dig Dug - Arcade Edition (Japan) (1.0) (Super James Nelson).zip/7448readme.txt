Hi ok so basically, you see, to play this hack you need to:
-------------------------------------------------------------
 
1. Get a copy of "Dig Dug (Japan).nes"
                                                                      
2. Pick your rom of choice
   *Famicom deflation speed 
   *Arcade deflation speed

3. Apply the IPS patch to the "Dig Dug (Japan).nes" rom
    
4. Load up the hack, and have fun!                   
 
------------------------------------------------------------- 
