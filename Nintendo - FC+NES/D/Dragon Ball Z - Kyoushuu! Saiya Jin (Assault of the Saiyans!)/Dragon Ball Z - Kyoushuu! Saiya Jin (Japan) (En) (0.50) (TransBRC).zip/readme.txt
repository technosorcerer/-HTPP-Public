transBRC PROUDLY PRESENTS

GAME NAME : DRAGON BALL Z #1
SYSTEM    : NES
GAME TYPE : RPG
TYPE      : TRANSLATION
VERSION   : .50 alpha
STATUS    : 50%
RELEASE   : APR 10 1999 
HACK      : BLIBBER
SCRIPT    : LEMON / JOSUI KATAYAMA / BLIBBER
-----------------------------------------------------------------------------
     
NOTES:  Well this is the second official release of this project.  Although
two preliminary's were leaked Mar of 98 and Mar of 99.  This state has most if
not all of the items done, the five mini games done, most of the combat,
the world vs battle, and most of the first adventure.

Share and Enjoy 

blibber - blibber@sprint.ca

Web site - http://www.emucamp.com/transbrc

Thank you's : Thanks to Omi, BigD, Zoop, Lemon, Josui, more to come.
