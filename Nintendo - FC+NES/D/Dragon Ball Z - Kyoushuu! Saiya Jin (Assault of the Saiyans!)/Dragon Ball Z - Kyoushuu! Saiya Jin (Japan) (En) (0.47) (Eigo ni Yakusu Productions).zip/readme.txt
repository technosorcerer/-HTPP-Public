!#@*(&$#*(^%#(#&^#@&^@^&*#@^%#@&*^%#&*%#@^&*%#@^%#^&#@*(^(!^(&*^#@&*
!(#@%         Eigo ni Yakusu Productions Proudly Presents      %@*(@
*()((              Dragon Ball Z: Kyoushuu! Saiyajin           #(&%!
@*($*            (c) 1991 Bandai/Bird Studio/Shueisha          #&*$)
$#*(&*@%$@^*&^!&*#^$*&$#@%$#&*%$#&*$#%^$@#^%&*%$#@$#%^*%$#@^$%^&#@%@

Translator: Sgt. Bowhack
Hacker: Sgt. Bowhack
Font: oyn/Sgt. Bowhack
Special thanks: demi (for a little help in understanding Japanese)
		Omniverse (for the competition, trying to make
		 DBZ2 better than this... hahaha)
		(Note: Omniverse has since left *the scene*.)
		The army of people who have been behind me
		 since the first patch, your support is always
		 appreciated.
Greetz go out to: #romhack regs (the scene), blibber for doing
 his DBZ1 trans, MadHacker/animefx for pointer info, necrosaro
 for thingy, Sardu for NESticle, fanwen for fwNES and loopy for
 loopyNES.
What do you expect to be able to do with this translation?:
 Hopefully, it will be 100% someday.
Why do you wanna translate it?: Boredom, and I love the game.
How do I use this translation?: Find the ROM (which I will not give
 you), and use an IPS patcher (SNEStool, IPS.exe, or the like).
You suck! This translation sucks! SD3 forever!: Okie dokie, then
 who's the idiot who downloaded it, eh?
Where can I find the ROM?: Don't ask me. (Seriously, don't ask.)

Percent completed:
------------------
Main Text-99%
Battles-50%
Names-100%
Moves-100%
Cards-100%
Plot Summary-60%
Budoukai-10%
Menus-??% (I assume there're some I haven't encountered yet)
Status-100%
General stuff-??% (I keep finding new stuff all the time)
-Game Over texts-100% (At least, I think so)
-Training points-0% (I am now aware of them at least)

What to expect in the next patch:
---------------------------------
Who knows.  I'm really not up to setting goals as to what
 people should expect from me anymore; the game is now
 playable.  Whatever is left is really just padding.  I've
 talked to people who've beaten it with an earlier patch
 who don't speak any Japanese at all and they had no
 problems.  Who really needs a plot summary of something
 you've already read anyway? :)

Your typical Q&As
-----------------
"Why did you release this patch?" Well, I just thought I'd show
 everyone what's going on, i've spent a lot of time on this.
 The project started Aug. 1, and not a whole lot went on after
 August 10th or so, due to a change in priorities.  This patch
 was made Oct. 18th.
"Is this just an update to your old patch?" No. This was started
 from scratch on August 1st.  Some things that were in the old one
 aren't in this one, and vice versa.  The text in this one is a bit
 farther (gets past Raditz), and a lot more text has been translated,
 but not hacked in.
"Is there something I can do?" Probably not. Translation is going
 smoothly, though there's a lot of things I'm stuck on.  If you're
 fluent in Japanese, you might be of some help.
"Why is there gibberish?" Some of the text hasn't changed, although
 the font has been.  Don't let this fool you- it's not that I can't
 translate that text, it's just that it hasn't been put in yet.
 (Well, that, and some I don't know, but I'll get to that later.)
"Why is this patch so much better than your old attempt?" This patch
 uses "newer" techniques such as changing pointers, so there is
 basically unlimited space in the ROM for the text, the only limit
 is the window size, which I still don't know how to change, but
 that's not really worth it anyway in this, except for a couple
 cases.  There's also a few new little tricks I tried in this,
 like fitting:
Plot
   Summary
 where it was originally (in Japanese)
 (Plot)- 4 characters long.
 Now if only I knew how to make the passwords look good... *sigh*.