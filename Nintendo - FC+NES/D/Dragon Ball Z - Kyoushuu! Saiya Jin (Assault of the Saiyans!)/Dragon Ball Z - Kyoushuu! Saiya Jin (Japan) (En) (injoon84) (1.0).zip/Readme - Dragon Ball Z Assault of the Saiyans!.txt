Dragon Ball Z - Assault of the Saiyans!
---------------------------------------


Info:
1) This English translation addendum is based on RedComet's v0.99.
2) Unlike their final v1.01, this one has limited space for text but fewer bugs.
3) Now it has been fully translated except for the credits and probably bug-free together with a working password and sram too!


Emulator compatibility:
Either use mapper16 for VirtualNES or mapper159 for FCEUX. Other than these two, you'll have to try it yourself!


2 ips patches were provided:
1) Dragon Ball Z - Assault of the Saiyans! [T-Eng-completed_RedComet] [m16_sram].ips
2) Dragon Ball Z - Assault of the Saiyans! [T-Eng-completed_RedComet] [m159_sram].ips


ROM / ISO Information:
Database match: Dragon Ball Z - Kyoushuu! Saiya Jin (Japan)
Database: No-Intro: Nintendo Entertainment System (v. 20210216-231042)
File SHA-1: 375604EE5CC7CA7569FF4807C9ED5BA643002E87
File CRC32: 62FA9F0A
ROM SHA-1: 4037DB53D45DB20E3A131D722DCD317ADC966DEB
ROM CRC32: 183859D2


How to patch:
Use Lunar IPS and choose one of the ips file to patch it with the original ROM.
Or
If you find it difficult to find a verified good dump, use HxD and change the starting offset (hex) to:
4E 45 53 1A 10 20 00 10 00 00 00 00 00 00 00 00
Then, use Lunar IPS and choose one of the ips file to patch it with the original ROM.


Software needed:
1) Lunar IPS
2) Compatible NES Emulator
3) Software that can extract 'zip' extension file (e.g. Peazip, WinRAR, WinZip, etc)


Software involved:
1) FCEUX Emulator
2) HxD
3) Lunar IPS
4) Peazip
5) TLP
6) VirtualNES Emulator
7) WindHex


Personal opinion:
Surely, you must be wondering why didn't I just make an addendum to their v1.01?
Well, I did, but it didn't turn out well because I wasn't able to fix their bugs and most of the typos.
So I have to resolve it by using v0.99 instead.
I created and rearranged RedComet's v0.99 tiles using TLP as their lower case tiles mostly affected the password system.
By doing so, I have to readjust their whole script again. I use WindHex as it goes well with tbl.
Then, I use v0.99 as a reference to make any necessary adjustments to my addendum.
It was not an easy task, but I did it anyway.
If anyone is not satisfied with my choice of words, feel free to improvise it with the details that I have provided below.


Hacking Info:
Change mapper	: 16 to 16 / 159 (with working SRAM)
Offset (hex)	: 6
Hex (Original)	: 00 10
Hex (Edited1)	: 02 18 (Mapper 16 with working SRAM for VirtualNES)
Hex (Edited2)	: F2 98 (Mapper 159 with working SRAM for FCEUX)

T-Eng0.99_RedComet
Offset (hex) from 00000 to 40000
Additional info:
E0=Etc0
E1=Etc1
E5=Goku??
E6=training
E7=Kaio
E8=Piccolo??
E9=Dragonball
EA=Card
EB=Garlic
EC=Saiyan
ED=Vegeta??
EE=Zwarriors
EF=Roshi
F0=Raditz
F1=Gohan
F2=Star
F3=Kaioken Kamehameha x3
F4=Pumpkin??
F5=Tail
F6=Saiba
F7=Goku
F8=Nappa
F9=Vegeta
FA=Enma
FB=Piccolo
FC=Fierce Makoho
FD=Chaozu
FE=Energy Bullets
FF=Pumpkin

New Game, Con't & Budokai started at 
Offset (hex)	: 8148
New Game, Con't & Budokai ended at
Offset (hex)	: 81AA

The word 'Story' in recap started at 
Offset (hex)	: 85E6
The word 'Story' in recap ended at
Offset (hex)	: 85EA

The word 'Fight' & 'Run' for Clone Training started at
Offset (hex)1	: 267AC
The word 'Fight' & 'Run' for Clone Training ended at
Offset (hex)2	: 267C2

The word 'Stats' in password system started at
Offset (hex)1	: 285AB
The word 'Stats' in password system ended at
Offset (hex)2	: 286DB

Story_part1 started at 
Offset (hex)	: 2C1CF
Story_part1 ended at
Offset (hex)	: 2F136

Story_part2 started at
Offset (hex)	: 2FBB9
Story_part2 ended at
Offset (hex)	: 3000A

Battle started at
Offset (hex)	: 30283
Battle ended at
Offset (hex)	: 307C8

Card description started at
Offset (hex)	: 307C9
Card description ended at
Offset (hex)	: 30C3B

Kaio's Training Stage 3 started at
Offset (hex)	: 30C3C
Kaio's Training Stage 3 ended at
Offset (hex)	: 30CC9

Menu story and save started at
Offset (hex)	: 30CCA
Menu story and save ended at
Offset (hex)	: 30D31

Tournament started at
Offset (hex)	: 30D32
Tournament ended at
Offset (hex)	: 30EEC

Training started at
Offset (hex)	: 30F25
Training ended at
Offset (hex)	: 31443

Bubbles & Gregory Training started at
Offset (hex)	: 31444
Bubbles & Gregory Training ended at
Offset (hex)	: 3155C

Snake Way Training started at
Offset (hex)	: 3155D
Snake Way Training ended at
Offset (hex)	: 31616

Card games started at
Offset (hex)	: 31617
Card games ended at
Offset (hex)	: 31891

Healing station started at
Offset (hex)	: 31892
Healing station ended at
Offset (hex)	: 31925

Game Over started at
Offset (hex)	: 31926
Game Over ended at
Offset (hex)	: 319ED

Story Recap_part1 started at
Offset (hex)	: 319EE
Story Recap_part1 ended at
Offset (hex)	: 31C46

Debug Menu started at
Offset (hex)	: 33141
Debug Menu ended at
Offset (hex)	: 332B7

Story Recap_part2 started at
Offset (hex)	: 33590
Story Recap_part2 ended at
Offset (hex)	: 33BB0

Shenron cutscene started at
Offset (hex)	: 33BB1
Shenron cutscene ended at
Offset (hex)	: 33CB9

The word 'Go' after selecting a card for movement in map started at
Offset (hex)	: 3498F
The word 'Go' after selecting a card for movement in map ended at
Offset (hex)	: 34990

Stats started at
Offset (hex)	: 35F18
Stats ended at
Offset (hex)	: 363F6

Password input started at
Offset (hex)	: 3711A
Password input ended at
Offset (hex)	: 371B1

Card Skills started at
Offset (hex)	: 38EC0
Card Skills ended at
Offset (hex)	: 38ED1

Card Btl, Map, Use, Info started at
Offset (hex)	: 39821
Card Btl, Map, Use, Info ended at
Offset (hex)	: 3983F

Names & Etc_part1 started at
Offset (hex)	: 3D9F2
Names & Etc_part1 ended at
Offset (hex)	: 3DCD9

Names & Etc_part2 started at
Offset (hex)	: 3FA20
Names & Etc_part2 ended at
Offset (hex)	: 3FB1F


Some samples of what has been done:
01) New Game
Offset (hex)	: 8148
Hex (RedComet)	: 11 48 5A 01 0A 44 50 48 01
Hex (Edited)	: 11 22 5A 01 0A 1E 2A 22 01

02) Continue	-> Con't (Note: The reason why this needs to be cut short because it only allowed 7 letters)
Offset (hex)	: 81A3
Hex (RedComet)	: 21 06 52 51 57 4C 51 58 48 01 0F
Hex (Edited)	: 21 06 2C 2B 41 31 01 01 FF 01 0F

03) Tenkai	-> Budokai
Offset (hex)1	: 8176
Hex (RedComet)	: 17 48 51 4E 44 4C 01 01 01
Hex (Edited)	: 05 58 21 2C 28 1E 26 01 01
Offset (hex)2	: 363ED
Hex (RedComet)	: 17 48 51 4E 44 4C 7D 01 01
Hex (Edited)	: 05 58 21 2C 28 1E 26 7D 01

04) Password	: Stats (with custom tiles 'tats')
Offset (hex)1	: 285AA
Hex (RedComet)	: 1C 06 2B 3A 0B 04 00
Hex (Edited)	: 01 16 55 56 57 04 00
Offset (hex)2	: 286D7
Hex (RedComet)	: 1C 06 2B 3A 0B 00 FF
Hex (Edited)	: 01 16 55 56 57 00 FF

05) Password	: Is this Ok? Yes No (Alignment)
Offset (hex)1	: 30D73
Hex (RedComet)	: 0C 56 01 57 4B 4C 56 01 12 4E 7C 02 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 1C 48 56 03 11 52 00 
Hex (Edited)	: 0C 30 01 31 25 26 30 01 12 28 7C 02 02 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 1C 22 30 03 11 2C 00

06) loser is	-> winner is (with a custom tile 'in')
Offset (hex)	: 30E80
Hex (RedComet)	: 01 4F 52 56 48 55 01 4C 56 02
Hex (Edited)	: 01 5A 6B 2B 22 2F 01 26 30 02

07) runner-up is	-> champion is
Offset (hex)	: 30E92
Hex (RedComet)	: 55 58 51 51 48 55 43 58 53 01 4C 56 02
Hex (Edited)	: 20 25 1E 2A 2D 26 2C 2B 01 26 30 01 02

08) Piccolo (5 hex value with custom tiles 'iccolo')
Offset (hex)	: 3D9F7
Hex (RedComet)	: 13 1E 1F 20 21 52 00
Hex (Edited)	: 13 44 45 46 47 00 00

09) Krillin (5 hex value with custom tiles 'll' & 'in')
Offset (hex)	: 3DA0B
Hex (RedComet)	: 0E 55 4C 5F 4C 51 00
Hex (Edited)	: 0E 2F 26 5F 6B 00 00

10) Yamcha (5 hex value with custom tiles 'cha')
Offset (hex)	: 3DA36
Hex (RedComet)	: 1C 44 50 46 4B 44 00
Hex (Edited)	: 1C 1E 2A 6C 6D 00 00

11) Chaozu (5 hex value with custom tiles 'ozu')
Offset (hex)	: 3DA42
Hex (RedComet)	: 06 4B 44 52 5D 58 00
Hex (Edited)	: 06 25 1E 6E 6F 00 00

12) hi-Chi	-> Bubbles (with a custom tile 'le')
Offset (hex)	: 3DA98
Hex (RedComet)	: 06 4B 4C 43 06 4B 4C 00
Hex (Edited)	: 00 05 58 1F 1F 54 30 00

13) Kaioken Kamehameha (custom tiles)
Offset (hex)1	: 3DB80 (Kaioken Kamehameha)
Hex (RedComet)	: 25 26 27 28 29 2A 2B 2C 2D 2E 2F 30 31 00
Hex (Edited)	: 4B 4C 4D 4E 4F 4B 50 51 52 50 51 52 53 00
Offset (hex)2	: 3DB99 (Kaioken Kamehameha x2)
Hex (RedComet)	: 25 26 27 28 29 2A 2B 2C 2D 2E 2F 30 31 5B 82 00 00
Hex (Edited)	: 4B 4C 4D 4E 4F 4B 50 51 52 50 51 52 53 5B 82 00 00
Offset (hex)3	: 3DBB5 (Kaioken Kamehameha x3)
Hex (RedComet)	: 25 26 27 28 29 2A 2B 2C 2D 2E 2F 30 31 5B 83 00 00
Hex (Edited)	: 4B 4C 4D 4E 4F 4B 50 51 52 50 51 52 53 5B 83 00 00
Offset (hex)4	: 3DBC6 (Kaioken Kamehameha x4)
Hex (RedComet)	: 25 26 27 28 29 2A 2B 2C 2D 2E 2F 30 31 5B 84 00 00
Hex (Edited)	: 4B 4C 4D 4E 4F 4B 50 51 52 50 51 52 53 5B 84 00 00

14) Guided Energy Ball-> Spirit Ball (with a custom tile 'll')
Offset (hex)	: 3FA31
Hex (RedComet)	: 0A 58 4C 47 48 47 01 08 51 48 55 4A 5C 01 05 44 5F 00
Hex (Edited)	: 16 2D 26 2F 26 31 01 05 1E 5F 00 00 00 00 00 00 00 00

15) Z Warriors	-> Zwarriors (with custom tiles 'warriors')
Offset (hex)	: 3FB11
Hex (RedComet)	: 1D 01 1A 44 55 55 4C 52 55 56 00
Hex (Edited)	: 1D 66 67 68 69 6A 00 00 00 00 00


Fixed Text on Debug Mode:
01) Debug Mode	: P1's HP won't drop		Yes  No
Offset (hex)	: 33141
Hex (RedComet)	: 23 09 13 1C 8A 8D 90 20 2A 18 05 03 03 03 03 03 03 03 03 03 03 1D 05 03 03 05 05 07 02
Hex (Edited)	: 13 81 41 30 03 8A 8D 03 5A 2C 2B 41 31 03 21 2F 2C 2D 03 03 1C 22 30 03 03 11 2C 03 02

02) Debug Mode	: COM's HP won't drop		Yes  No
Offset (hex)	: 3315E
Hex (RedComet)	: 16 0A 1C 8A 8D 90 20 2A 18 05 03 03 03 03 03 03 03 03 03 03 03 1D 05 03 03 05 05 07 02
Hex (Edited)	: 06 12 10 41 30 03 8A 8D 03 5A 2C 2B 41 31 03 21 2F 2C 2D 03 1C 22 30 03 03 11 2C 03 02

03) Debug Mode	: All Assist Cards		Yes  No
Offset (hex)	: 3317B
Hex (RedComet)	: 98 31 A1 1C 08 13 10 0C 49 43 B7 90 03 03 03 03 03 03 03 03 03 04 2C 03 03 18 05 02
Hex (Edited)	: 04 5F 03 04 30 30 26 30 31 03 06 1E 2F 21 30 03 03 03 03 03 1C 22 30 03 03 11 2C 02

04) Debug Mode	: Assist Card Inf.		Yes  No
Offset (hex)	: 33197
Hex (RedComet)	: 08 13 10 0C 49 43 B7 90 20 2A 18 05 03 03 03 03 03 03 03 03 03 1D 05 03 03 05 05 07 02
Hex (Edited)	: 04 30 30 26 30 31 03 06 1E 2F 21 03 0C 2B 23 7E 03 03 03 03 1C 22 30 03 03 11 2C 03 02

05) Debug Mode	: Card always open		Yes  No
Offset (hex)	: 331B4
Hex (RedComet)	: 50 49 46 53 43 9D 09 18 2A 97 49 43 B7 30 1E 3A 06 96 03 03 03 10 2C 03 03 0F 18 05 02
Hex (Edited)	: 06 1E 2F 21 03 1E 29 5A 1E 5C 30 03 2C 2D 22 2B 03 03 03 03 1C 22 30 03 03 11 2C 03 02

06) Debug Mode	: Control Battle		Yes  No
Offset (hex)	: 331D1
Hex (RedComet)	: B8 57 6C 4A 78 6A 90 AF 7A 45 50 56 73 77 4B 9D 06 94 0B 03 03 1D 05 03 03 05 05 07 02
Hex (Edited)	: 06 2C 2B 31 2F 2C 29 03 05 1E 31 31 29 22 03 03 03 03 03 03 1C 22 30 03 03 11 2C 03 02

07) Debug Mode	: Show COM's HP			Yes  No
Offset (hex)	: 331EE
Hex (RedComet)	: B8 57 6C 9D 56 4A 1C 8A 8D 30 1E 3A 06 96 03 03 03 03 03 03 03 10 2C 03 03 0F 18 05 02
Hex (Edited)	: 16 25 2C 5A 03 06 12 10 41 30 03 8A 8D 03 03 03 03 03 03 03 1C 22 30 03 03 11 2C 03 02

08) Debug Mode	: COM always use skill		Yes  No		(with a custom tile 'll')
Offset (hex)	: 3320B
Hex (RedComet)	: 16 0A 1C 49 43 B7 1D 1E 37 0E 15 2F 95 9A 0C 03 03 03 03 03 03 1D 05 03 03 05 05 07 00
Hex (Edited)	: 06 12 10 03 1E 29 5A 1E 5C 30 03 58 30 22 03 30 28 26 5F 03 1C 22 30 03 03 11 2C 03 00

09) Debug Mode	: Battle can Pause		Yes  No
Offset (hex)	: 33228
Hex (RedComet)	: B8 57 6C 14 39 06 C1 43 B0 90 03 03 03 03 03 03 03 03 03 03 03 0A 0B 03 03 0A 09 18 05 02
Hex (Edited)	: 05 1E 31 31 29 22 03 20 1E 2B 03 13 1E 58 30 22 03 03 03 03 1C 22 30 03 03 11 2C 03 03 02

10) Debug Mode	: Game Flag		B	Up   Dn
Offset (hex)	: 33246
Hex (RedComet)	: AC 43 64 5F 6A AB 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 06 07 03 03 0F 13 02
Hex (Edited)	: 0A 1E 2A 22 03 09 29 1E 24 03 03 03 03 03 03 03 03 03 03 03 03 18 2D 03 03 07 2B 02 

11) Debug Mode	: Select change Map		Yes  No
Offset (hex)	: 33262
Hex (RedComet)	: 62 77 BF 30 51 6D 4B 57 9D 20 31 0D 06 03 03 03 03 03 03 03 03 10 2C 03 03 0F 18 05 02
Hex (Edited)	: 16 22 29 22 20 31 03 20 25 1E 2B 24 22 03 10 1E 2D 03 03 03 1C 22 30 03 03 11 2C 03 02

12) Debug Mode	: P2's A move Map		Yes  No
Offset (hex)	: 3327F
Hex (RedComet)	: 62 77 BF 30 AF 7A 45 82 47 43 9D 05 9E 06 03 03 03 03 03 03 03 10 2C 03 03 0F 18 05 02
Hex (Edited)	: 13 82 41 30 03 04 03 2A 2C 59 22 03 10 1E 2D 03 03 03 03 03 1C 22 30 03 03 11 2C 03 02

13) Debug Mode	: Enter/Exit Battle		Yes  No		(with a custom tile '/')
Offset (hex)	: 3329C
Hex (RedComet)	: B8 57 6C 19 1D 05 2C 7E 9D 2C 03 03 03 03 03 03 03 03 03 03 03 04 2B 03 03 18 0F 00
Hex (Edited)	: 08 2B 31 22 2F 70 08 5B 26 31 03 05 1E 31 31 29 22 03 03 03 1C 22 30 03 03 11 2C 00


Credits:
1) https://gesato.com/fc/dbz1/top.html
2) https://tcrf.net/Dragon_Ball_Z:_Kyoushuu!_Saiya_Jin
3) RedComet from Twilight Translations
4) Twilight Translations from ROMhacking.com


Written by injoon84:
27/07/2025
DD/MM/YYYY
