For our international users - We've translated the game into Portuguese. If you speak another Latin language like Spanish, Italian, or French and would like to help translate the game into your language, please contact us.

---

## Informações do Jogo

Título: Dragon Ball Z: Kyōshū! Saiyajin (ドラゴンボールZ 強襲!サイヤ人)
Título traduzido: Dragon Ball Z: Invasão Saiyajin
Plataforma: Famicom / NES
Desenvolvedora: Bandai
Gênero: RPG
Lançamento do jogo: 27/10/1990


## Informações da ROM para aplicar o patch

Dragon Ball Z - Kyoushuu! Saiya Jin (Japan)
Database: No-Intro: Nintendo Entertainment System (v. 20210216-231042)
File SHA-1: AA8FBA68F1CA8CD8015677E9DD12F06F17A1BA7A
File CRC32: 292B41D
ROM SHA-1: 4037DB53D45DB20E3A131D722DCD317ADC966DEB
ROM CRC32: 183859D2

Você pode utilizar esta ferramenta online para aplicar o patch:
https://www.marcrobledo.com/RomPatcher.js/


## Equipe

Tradução e Rom Hacking: Taihen
Gráficos e fontes: Sliter

Taihen's Hextinkers - https://hextinkers.org

Este trabalho foi desenvolvido por fãs com o objetivo de aprendizado e preservação da obra, sem absolutamente nenhum fim lucrativo. A comercialização desta tradução não é permitida em nenhuma hipótese. Todos os direitos reservados aos autores e detentores de marca da série Dragon Ball.

Se encontrar erros ou bugs, entre em contato por taihendarou[a]gmail.com ou pelo Discord: taihendarou

## Sobre a tradução

Tradução lançada em 27 de setembro de 2023. O projeto teve início em 26 de julho de 2023, baseando-se no jogo original em japonês. Para evitar abreviações, ajustamos o layout das interfaces do jogo para acomodar palavras mais extensas, mas sempre buscando preservar a originalidade do jogo.

Toda a narrativa, termos e mensagens foram traduzidos. Os gráficos que contêm texto também receberam tradução. As cartas de batalha, na sua parte inferior, originalmente exibiam números em japonês que indicam o valor de defesa; esses números foram adaptados para os algarismos ocidentais.

Mantivemos os ideogramas que indicam a facção dos personagens nas cartas, visto que esse aspecto é mencionado no anime e mangá. 

Introduzimos um sistema de paginação nas telas narrativas, permitindo textos extensos com continuação em páginas subsequentes, sem avançar para a próxima cena. Também reconfiguramos o layout de um menu, que originalmente apresentava páginas com seis itens distribuídos em duas colunas. O novo layout exibe três itens por página em uma única coluna, possibilitando nomes de itens mais longos. Utilizamos DTE para comprimir os textos, de modo a se ajustarem à memória disponível do jogo.

Versão 1.1 (7/6/2024) - Correção de dois textos

## Sobre o jogo

Este foi o primeiro jogo da fase Z de Dragon Ball para console e foi lançado em 1990, somente no Japão. A narrativa começa na Saga dos Saiyajins, terminando na batalha contra Vegeta. Existem muitas diferenças comparado com a história original do mangá e do anime, como por exemplo, personagens que existem no anime como fillers, mas neste jogo são usados em outro contexto. Outra mudança interessante é que incorporaram a história do primeiro filme de Dragon Ball Z (Dragon Ball Z: Dead Zone) e colocaram no jogo logo após a batalha contra Raditz. Uma mudança cronológica que se tornou algo exclusivo do jogo.

É um jogo do gênero RPG, com batalhas por turno, itens e mudança de nível. Há também as famosas cartas, típicas de muitos jogos de Dragon Ball da época. A dinâmica das cartas é mais simples do que parece. O número de estrelas na parte superior indica a força de ataque, enquanto o ideograma japonês central representa a facção do personagem (recorde os símbolos nos uniformes dos personagens do anime). Usar uma carta correspondente à sua facção potencializa o ataque, tornando-o mais forte. Já o número na parte inferior da carta indica o poder de defesa.

Os gráficos são considerados avançados para o NES, sendo que o cartucho possui 512kb de tamanho.

Apesar de ser antigo e de terem sido lançados diversos outros jogos que retratam praticamente a mesma história, vale a pena conhecer para quem se interessa pela história dos videogames e também pelo enredo de Dragon Ball.