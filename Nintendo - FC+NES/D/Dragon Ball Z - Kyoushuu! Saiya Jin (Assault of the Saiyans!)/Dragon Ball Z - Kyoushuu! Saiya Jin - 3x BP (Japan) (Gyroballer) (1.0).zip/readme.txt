Dragonball Z: Assault of the Saiyans!
3x EXP Gain Hack
Version 1.00
Current Release: Feb. 2, 2019
Intial Release: Feb. 2, 2019
by Gyroballer
copyright 2019
--------------------------------------

1. Introduction
2. Patch History
3. Known Bugs
4. Acknowledgements

--------------------------------------

1. Introduction

--------------------------------------

DBZ: Assault of the Saiyans for the Famicom 
is a card-based RPG. You have a hand of 5
cards that you use for both movement on the map
and for attacking in combat. Match the symbol
on the card to your character's symbol to do
extra damage that turn. There are many DB/Z 
games in this vein.
(6 on the Famicom alone, as far as I know).

This one is perhaps the most tedious because
of the low experience gain. In the first map,
Goku and Piccolo start around 400 BP and need to
get close to 1500 BP each to take on Raditz, who
has a BP of 1500 as opposed to 1200 in this game.

The weakest enemy gives 3 BP and can show up
at best with 3 of them and a Saiyan helper who
gives 7 BP. That's an optimistic 16 BP out of the
1100 you should probably gain. The best possible
battle would give 105 BP if the 9 BP-granting
Saiyan goes Oozaru for 90 BP and is accompanied
with 3 Cucumbers, who give 5 BP each.

Unfortunately, enemies that give good BP often
seem to run away in this game. Furthermore, it's
rare that Onion, the aforementioned Saiyan, will
use "Monkey Change", so he'll just give 9 BP and
he's a frustrating opponent before you've gained
substantial BP.

In other words, it'd take 10-11 astronomically
unlikely battles to occur or more likely around
75-150 battles to occur before you could face
Raditz. ~75 would be if you usually fought against
3 Cucumbers (15 BP). It could take as many as 
~367 battles against 1 Kaiware (3 BP).

Again, this is to clear the first map of the game.
After that, separate teams of 2 need to gain
between 1500 and 3500 BP to be effective in the
next arc. After that, it'd be recommended to
gain at least another 5000 BP. You can see
where this would become an issue.

To remedy this, the 3x EXP patch was created.
The math isn't perfect, and it does make the game
a lot shorter, but it also makes it feel like a
more modern RPG by removing artificial inflation.

Large BP gains (like 5,600 against Kaio or
10,000 against Vegeta) were left alone because
giving Goku 16,800 (almost Vegeta's 18000 BP)
would break the balance of the game. Giving the
Z-Fighters 30,000 at the end of the game would
break the tournament mode and may cause balance
issues when porting passwords to DBZ 2.

Every other enemy should give 3x their typical
experience. Hopefully this will make the game
more enjoyable for you. 

This release comes with 3 .IPS format patches:
-----------------------------------------------
dbz1nes_3xBP_UtoU.ips:
- Takes RedComet's v1.01 patch and adds the
  3x BP hack to it.

dbz1nes_3xBP_JtoU.ips:
- Takes the original Japanese rom and adds
  both the translation patch and 3x BP.

dbz1nes_3xBP_JtoJ.ips:
- Adds the 3x BP hack while retaining the
  original Japanese language.
-----------------------------------------------

If you notice any bugs, or...
If an enemy does not give enough experience, 
or if it gives too much, then feel free to send
a screenshot and/or a savestate to:
 - maruku115@gmail.com.

"Use your favorite IPS patching program and apply this
to a CLEAN copy of the Japanese rom."
- Quoting RedComet here

Alternatively, patch RedComet's v1.01 rom with the
dbz1nes_3xBP_UtoU.ips patch.

--------------------------------------

2. Patch History

-Version 1.00
 Gives 3x BP/experience on every battle
 except for against King Kai and Vegeta
 and can be applied to the Japanese game
 retaining language, or using RedComet's
 v1.01 English patch. It can also be
 applied to the Japanese version and
 give the patch and hack at once.

--------------------------------------

3. Known Bugs

--------------------------------------

Technically Onion should supply 27 BP
now, and 270 BP in Oozaru/Monkey form,
but I noticed he gave 30 BP in his
normal form and couldn't replicate the
issue. Again, if you notice anything,
send me an email.

--------------------------------------

4. Acknowledgements

--------------------------------------

I definitely have people to thank:

-Myself(Gyroballer): Performed the quick experience
 table changes.

-Romhacking.net: Inspiration, documents, tools, etc. 

-RedComet: Amazing translation of the game.

-My fiance: For supporting me no matter what.

Thanks to all the fans of DBZ because without you, I
made this patch for no one but me! Enjoy it!