Double Dragon
Mapper Conversion Patch
FROM Mapper 1 (MMC1) TO Mapper 5 (MMC5)
Converted by Dracula X
RELEASE DATE: 11/27/19
Modified: 5/14/2021


MMC5 setup is located at $3FF10
CHR is located at $40010

PRG Bankswitch Routine is at $FEEE

To switch banks from $C000 - $FFFF, use like so:

LDA bank_number
JSR $FFEE
JMP to any location in $8000-$BFFF




CHR Sprite Bankswitch Routine (Left side of PPU) is at $FE9E

To switch sprite pages, use like so:

LDA page_number
JSR $FE9E




CHR Background Bankswitch Routine (Right side of PPU) is at $FEC6

To switch background pages, use like so:

LDA page_number
JSR $FEC6




Nametable Mapping Routine (one of its uses is mirroring) is at $FE76

To change mirroring for instance, use like so:

LDA mirroring_number (#$50 for Horizontal, #$44 for Vertical)
JSR $FE76

This patch does not work for:
Double Dragon (Europe)

This patch also works for:
Sou Setsu Ryuu (Japan)

Hacks supported:
All!
Note: to get Double Dragon Remasted to work just add the changes
that I made to CHR Bank 1 and MMC5 setup and thats it.

Hacks not supported:
Double Dragon - MMC1 to MMC3

Use Delta Patcher to patch the xdelta file to the ROM. 
Ignore the checksum and then patch the file.

Changes for this version 1.0a
Fixed the PPU Viewer CHR Left and all hacks are now supported.

Changes for this version 1.0b
Fixed mmc5 setup and added Upper CHR Bank bits to CHR Bank 1
and all emulators are now supported.

Credits:
Rockman or RetroRain: for info on how to convert the mapper!
Disch: for his mapper docs and a better MMC5 startup!

All emulators are now supported!