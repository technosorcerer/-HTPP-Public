Double Dragon (NES)
Traducción al Español v1.1 (09/01/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Mejorado título, selección de personajes y traducido gráfico "PLAYER" en modo 2 jugadores

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Double Dragon (USA).nes
MD5: 79aa819580967ffb27a9698efbf493b9
SHA1: 84698b12f4e56a37c67bb47359758124c9b012bb
CRC32: 62afe166
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --