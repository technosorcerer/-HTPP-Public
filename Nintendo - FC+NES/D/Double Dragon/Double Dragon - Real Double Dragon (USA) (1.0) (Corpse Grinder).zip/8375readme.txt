
; ------------------------------------------------------------------

	Real Double Dragon (U) [v1.0]

; ------------------------------------------------------------------

changes:
	- add second player
	- removed fighting mode
	- add credits
	- from MMC1 to MMC3
; ------------------------------------------------------------------

hacking by
	corpse grinder - programmer
	mark - tester
	uuuser - tester
; ------------------------------------------------------------------

support:
	paypal - corpsehumengrinder@gmail.com
; ------------------------------------------------------------------

discord - https://discord.gg/Hhh5Hxy3SJ
; ------------------------------------------------------------------

	14.01.2024