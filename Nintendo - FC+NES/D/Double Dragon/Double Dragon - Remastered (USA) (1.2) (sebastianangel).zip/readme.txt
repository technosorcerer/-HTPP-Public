Double Dragon - (remastered)
This patch improves many of the color palettes in this game to make it look better, using double dragon 2 sprites for enemies, includes a new abobo sprite! This update is 1.1 and fixes all the bugs of version 1.0 by adding new sprite for mariam using MMC5 mapper.
In IPS format, you can use LunarIPS or Floating IPS.
File used:
Double Dragon.nes

The IPS patch must be used on a NES ROM