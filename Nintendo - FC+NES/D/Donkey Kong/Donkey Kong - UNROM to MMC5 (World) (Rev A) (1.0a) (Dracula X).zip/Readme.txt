Donkey Kong
Mapper Conversion Patch
FROM Mapper 0 (NROM) TO Mapper 5 (MMC5)
Converted by Dracula X
RELEASE DATE: 05/1/2021
Last Modified: 05/2/2021

The main game of $C000-$FFFF is now located at $0010-$4010

MMC5 Setup is at $1FF10

Reset is at $FA70

PRG Bankswitch Routine is at $FA7D

To switch banks from $C000 - $FFFF, use like so:

LDA page_number
JSR $FA7D
JMP to anywhere in $8000-$BFFF




CHR bank 0 (Left side of PPU) is at $FA55

To switch sprite pages, use like so:

LDA page_number
JSR $FA55




CHR bank 1 (Right side of PPU) is at $FA59

To switch background pages, use like so:

LDA page_number
JSR $FA59



Nametable Mapping Routine (one of its uses is mirroring) is at $FA51

To change mirroring for instance, use like so:

LDA mirroring_number (#$44 for Vertical, #$50 for Horizontal)
JSR $FA51

8KB CHR-ROM pages is located at $20000

The settings that was at $FA48 is located at Bank 1 at $8000.

Donkey Kong (Japan) is also supported!

Supported Hacks:
All hacks are supported

Hacks not Supported:
NROM to MMC3
Donkey Kong (save-patch)
Donkey Kong (Original Edition) savepatch

Use Delta Patcher to patch the xdelta file to the ROM. 
Ignore the checksum and then patch the file. If something
not right, then patch your hack ROM with your IPS file to the hack.
Apply your hack to the xdelta file and then reapply the ips to
the file.

Credits:
Rockman or RetroRain: for info on how to convert the mapper!
Disch: for his mapper docs and a better MMC5 startup!
infidelity: for info on how to convert NROM to MMC5.

Changes for this version 1.0a:
Added supported hacks.


All emulators works!