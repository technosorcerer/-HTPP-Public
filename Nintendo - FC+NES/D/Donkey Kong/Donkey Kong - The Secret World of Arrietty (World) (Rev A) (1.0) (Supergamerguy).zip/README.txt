The Secret World of Arrietty (Version 1.0)
by Supergamerguy
Title Screen Logo by Cryin Onion


Table of Contents:
1. How to patch
2. Changelog
3. Background Info
4. Tools Used
5. Explanation of changes






How to patch:
1. Download a patching program like Lunar IPS
2. Download Donkey Kong (World) (Rev A).nes
3. Use patching program to apply "The Secret World of Arrietty (Version 1.0).ips" to your
Donkey Kong NES ROM
4. Rename new file to whatever you want (Example: The Secret World of Arrietty (Donkey Kong NES Hack))
5. Use a NES emulator like FCEUX or the FCEUMM core in Retroarch to play!






Changelog:

Version 1.0:
- Edited all graphics and text (and CryinOnion finished the Title Screen Logo)





Background Info:
The Secret World of Arrietty is not the best of Ghibli's work, 
but it is a solid movie that I still enjoy enough to give it its 
own game. Donkey Kong seemed perfect for the role: a game starring 
a big Ape that steals a helpless girl, where a small man then has 
to climb up things to save her. Switch out Donkey Kong with an 
overzealous human housekeeper, the girl with a paranoid Borrower 
mother, and the small man with a Borrower adventurer girl, and you 
have a recipe for a perfect project fit! Hope you guys enjoy my work!





Tools Used:
- FCEUX (NES emulator - used to test game and edit color pallettes)
- YY-CHR (used to edit most of the sprites and sprite layouts)
- Tile Layer Pro - Used to edit all Donkey Kong sprites





Explanations of changes:

Here's some clarifications of which characters and enemies, items, 
and stages were changed.



Character and Enemy Changes:
- Jumpman (Mario): Arrietty
- Pauline: Homily (Arrietty's mom)
- Donkey Kong: Ms. Hara (the housekeeper)
- Fireball (enemy - stages 1 and 2): Roly-Polys (beetles)
- Fire-tailed guys (stage 3): Crickets


Item Changes:
- Hammer: Yellow Thumbpin (Arrietty's weapon)
- Barrels and Stacked Barrels: Jars (with Cloth Caps)
- Purse: Sugar Cube
- Umbrella: Small Hand-Lamp (used by Pod, Arrietty's dad)
- Springs: Cooking Pot (the golden one from the dollhouse)


Stage Changes:
- First and Second Stage: Wall Themed (as if they take places 
inside the walls)
- Third Stage: Kitchen Themed
- Ladders: Nail Ladders
- Oil Barrel: Crumbling Flowerpot (complete with plant overgrow)
- Fire coming out of the Barrel: A Beetle's head poking out
- Pulleys (second level): Rock Pulleys (like the ones used inside 
the walls).