Hack Name: Badly Drawn Donkey Kong

A Hack Of: Donkey Kong (Japan)

Hacked By: Metal64

Youtube channel: https://www.youtube.com/user/MetalOverlord64

2 Youtube channel: https://www.youtube.com/channel/UCPVhjP2tmdRVpqfD5TOymKA


About the hack

I just redraw all the sprites of this game as badly as I could