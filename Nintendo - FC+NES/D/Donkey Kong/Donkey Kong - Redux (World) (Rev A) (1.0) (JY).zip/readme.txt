 ___    _  _    ___    ____   ___    _  _   _    _
|   \  | |/ /  |   \  | ___| |   \  | || | \ \  / /
| |  | |   /   | | /  |  _|  | |  | | || |  \ \/ /
| |  | | | \   | | \  | |__  | |  | | || |  / /\ \
|___/| |_|\_\  |_|\_\ |____| |___/| |\__/| /_//\\_\
|__|/  |_|\||  |_|\|| |____| |__|/  \|__|/ ||/  \||

   Ver. 1.0, for Nintendo Entertainment System
---------------------------------------------------
Author:
*JY Co.

Software used:
*Paint.NET, used for drawing the custom sprites seen in-game
*YY-CHR, used for applying custom sprites to the rom
*Cygnus Hex Editor, used for altering in-game palettes
*FCEUX, used for testing the game
*Floating IPS (Flips), used for creating the patch

---------------------------------------------------

A full-on graphics update for the 1983 port of Donkey Kong to the NES/FC.

All in-game tiles have been replaced in this hack; most existing sprites have since been redrawn completely for the sake of this project, while a smaller portion of the graphics have just been altered to bring a bit more flair to the hack.

Development on this hack started at the very end of June 2018 and finished in August that same year.

---------------------------------------------------

Author's Notes:
*this hack is not compatible with the 2010 release "Donkey Kong Original Edition", nor do I intend to start working on a version of this hack for the Original Edition (at least not at the time of typing this, anyway)

*I've found that upon loading the rom, the wrong palette is loaded for the the Mario sprite that appears on the title screen. Starting a new game or simply letting the gameplay demo play out will give Mario his intended palette. The correct palette is maintained after a game over or a console reset.

---------------------------------------------------

Thanks for downloading; I hope you enjoy the hack and appreciate the effort that went into completely redrawing a classic. -JY