Hello everybody again I have created a patch and this time it is to commemorate the 40th anniversary of Donkey Kong but with Luigi and using as a base the original rom that shows the second 
level not shown in NES (pie factory or cement factory).

This game recently turned 40 years old so I decided to do something to commemorate it (although the whole game remains the same) but these were the following changes:

-Luigi is the protagonist instead of Mario (initially known as Jumpman). Luigi has his own sprite to give more originality to his appearance.

-Now it's Daisy the damsel in distress instead of Pauline (she was given the classic look in the dress).

-Some texts and dates were changed on the start screen.

-The color palettes on some objects have been changed to highlight the prominence of Luigi.

-Pauline's umbrella and bag have been replaced by the tennis racket and the flower as collectibles referencing Daisy's first appearances in the Mario universe (Mario Tennis 64 and
Super Mario Land).

-This patch adds Top Score saving for Donkey Kong (Original Edition), the version that comes with the additional pie factory level.

To patch use the ROM: Donkey Kong Original Edition.nes

Happy 40th anniversary Donkey Kong!!!!!!!

Thanks for playing this hack, Enjoy the game!!!