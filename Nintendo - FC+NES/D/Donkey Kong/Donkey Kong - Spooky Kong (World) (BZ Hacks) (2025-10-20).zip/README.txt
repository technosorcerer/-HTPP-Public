Spooky Kong wants to spend Halloween with the Wicked Hot Witch, and Frank ain't havin' none of that!

Patch to Donkey Kong (World) (Rev A).nes