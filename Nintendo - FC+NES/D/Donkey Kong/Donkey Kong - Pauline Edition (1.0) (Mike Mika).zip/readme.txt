DK Pauline Edition!

Using xdelta, apply the patch file "49AEC658 to F6DB268C.xdelta3" to the .NES file dump of the 2010 Donkey Kong NES ROM. This is the ROM that comes with the UK release of the Super Mario Collection.

Enjoy!

