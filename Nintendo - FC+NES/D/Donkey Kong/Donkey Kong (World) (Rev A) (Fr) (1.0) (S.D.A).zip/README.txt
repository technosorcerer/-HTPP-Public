DONKEY KONG (FR)

Une traduction fran�aise de "Donkey Kong" pour la NES au format .ips.
Utilisez Lunar IPS pour appliquer des correctifs.

-S.D.A.

PS: J'ai oubli� de traduire une petite partie du jeu. C'est maintenant corrig�.