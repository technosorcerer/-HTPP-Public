
Visit https://www.youtube.com/channel/UCKgNcvTtNkbT2hzIUZPHeuw to know other works of the author of this hack!


   #############################################
   #                                           #
   #                                           #
   #                PABLO KONG                 #
   #                                           #
   #                 VER.1.0                   #
   #                                           #
   #############################################


	

	1) Introduction/features list:

	2) How to choose gender and political affinity

	3) Tips

_______________________________________________________________________________________________________________________________________________________


1) Introduction/features list:


	First of all, thanks for download this hack, which is the first of a project divided into five parts.The concept is to make a criticism/parody
        of the electoral model of the current political parties, based on division, confrontation, caricaturing the rival and turning something as serious
        as deciding which parties will take better care of your interests, into a question as childish as "who are the good guys and who are the bad guys".
        The hack contains the following changes:

	Ver.1.0

		● Edited title screen, replacing "Donkey" in this case with the name of a spanish politician with an ideology close to social-communism.
                  The color palette is also changed for another one easily associated with the said politician.

		● The sprite of the main villain is replaced by a caricature of the politician mentioned in the title screen. 

		● Mario's sprite is replaced by "The Citizen", being able to choose both his gender and his political affinity, represented by the color
		  of his clothes.

		● The sprites of the barrels thrown by Pablo Kong are replaced by people who support his party. A metaphor as simple as that:
                  Using your supporters as a weapon.

		● Enemy sprites and bonus items have been replaced by social-communist iconography and silly topics. For example, in the original game,
                  Donkey Kong throws wooden barrels at a burning barrel, creating flames that chase us. In this version, social-communist supporters are
                  thrown into the fire to become "evil social-communist devils", including horns and pitchfork. The only weapon available in the game,
                  the hammer is replaced by a "crucifix".

                ● Many other changes. Just take a look and enjoy! The remaining four parts of the project will soon be available, each replacing
                  the main villain with a different political leader.



_______________________________________________________________________________________________________________________________________________________


2) How to choose gender and political affinity

	Each copy of this hack includes 8 different patches so you can choose the one that best suits your preferences, ordered by two letters
	which indicate first the gender and then the color as follows:

		● M= Man
		● W= Woman

		● B= Blue
		● G= Green
		● O= Orange
		● R= Red

	So if we want to play with a man of the red party, we'll use the patch with the "MR" tag, if we want the woman of the orange party "WO", etc.

_______________________________________________________________________________________________________________________________________________________


3) Tips

	To run this hack correctly, we must apply the patch with a program like "LunarIPS" (which you can find at www.romhacking.net) on a unmodified copy
	of the "Donkey Kong (U) (PRG1) [!].nes" rom. It has not been tested with other versions, so there is no guarantee that it will work.