
Visite https://www.youtube.com/channel/UCKgNcvTtNkbT2hzIUZPHeuw para ver outros trabalhos do autor deste hack!


   #############################################
   #                                           #
   #                                           #
   #                PABLO KONG                 #
   #                                           #
   #                 VER.1.0                   #
   #                                           #
   #############################################


	

	1) Introdução/lista de melhorias

        2) Como escolher o gênero e a afinidade política

	3) Dicas de uso

_______________________________________________________________________________________________________________________________________________________


1) Introdução/lista de melhorias:

	Antes de tudo, obrigado por baixar este hack, que é o primeiro de um projeto de cinco partes. A idéia é fazer uma revisão/paródia do modelo eleitoral
	dos partidos políticos atuais, baseado na divisão, no confronto, na caricaturação do rival e na transformação de algo sério como decidir quais partes
	cuidarão melhor de seus interesses, em algo tão pueril como "quem são os bons e quem são os maus". O hack contém as seguintes mudanças:

	Ver.1.0

		● Tela de título editada, substituindo " Donkey" neste caso pelo nome de um político espanhol com uma ideologia próxima ao social-comunismo.
                  A paleta de cores também é trocada por outra facilmente associada com o referido político.

		● O sprite do vilão principal é substituído por uma caricatura do político mencionado na tela de título. 

		● O sprite de Mario é substituído por "O Cidadão", podendo escolher tanto seu gênero quanto sua afinidade política, representada pela
		  cor  de suas roupas.

		● Os sprites dos barris lançados por Pablo Kong são substituídos por pessoas que apóiam seu partido. Uma metáfora tão simples quanto esta:
		  Usando seus apoiadores como uma arma.

		● Os sprites inimigos e itens de bônus foram substituídos por iconografia social-comunista e tópicos bobos. Por exemplo, no jogo original,
		  Donkey Kong arroja barris de madeira em um barril em chamas, criando chamas que nos perseguem. Nesta versão, os partidários social-comunistas
		  são lançados ao fogo para se tornarem "demônios social-comunistas malignos", incluindo cornos e forquilhas. A única arma disponível no jogo,
		  o martelo é substituído por um "crucifixo ".

                ● Muitas outras mudanças. Basta dar uma olhada e desfrutar! As quatro partes restantes do projeto estarão disponíveis em breve, cada uma
		  substituindo o principal vilão com um líder político diferente.


_______________________________________________________________________________________________________________________________________________________


2) Como escolher o gênero e a afinidade política

	Cada cópia deste hack inclui 8 patches diferentes para que você possa escolher aquele que melhor se adapte às suas preferências, ordenado por duas letras
	que indicam primeiro o sexo e depois a cor, como se segue:

		● M= Homem
		● W= Mulher

		● B= Azul
		● G= Verde
		● O= Laranja
		● R= Vermelho

	Portanto, se quisermos jogar com um homem da partido politico vermelho, usaremos o adesivo com a etiqueta "MR", se quisermos a mulher da partido
	laranja "WO", etc.


_______________________________________________________________________________________________________________________________________________________


3) Dicas de uso

	Para executar este hack corretamente, devemos aplicar o patch com um programa como o "LunarIPS" (que você pode encontrar em www.romhacking.net) em uma cópia
	não modificada do "Donkey Kong (U) (PRG1) [!].nes" rom. Ele não foi testado com outras versões, portanto não há garantia de que funcionará.
