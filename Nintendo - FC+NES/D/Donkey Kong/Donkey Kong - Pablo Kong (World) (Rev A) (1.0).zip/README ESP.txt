
¡Visita https://www.youtube.com/channel/UCKgNcvTtNkbT2hzIUZPHeuw para conocer otros trabajos del autor de este hack!


   #############################################
   #                                           #
   #                                           #
   #                PABLO KONG                 #
   #                                           #
   #                 VER.1.0                   #
   #                                           #
   #############################################




        1) Introducción/lista de mejoras

        2) Como elegir género y afinidad política

	3) Consejos de uso

_______________________________________________________________________________________________________________________________________________________


1) Introducción/lista de mejoras:

	Primero de todo, gracias por descargarte este hack, que es el primero de un proyecto dividido en cinco partes. La idea es hacer una crítica/parodia
        del modelo electoral de los partidos políticos actuales, basado en la división, la confrontación, en caricaturizar el rival y convertir algo tan
        serio como decidir qué partidos cuidarán mejor de tus intereses, en algo tan pueril como "quienes son los buenos y quienes los malos". El hack
	contiene los siguientes cambios:

	Ver.1.0

		● Pantalla de título editada, reemplazando "Donkey" en este caso por el nombre de cierto político español de ideología próxima al
                  social-communismo. También se cambia la paleta de colores por otra fácilmente asociable a dicho político y su partido.

		● El sprite del villano principal se reemplaza por una caricatura del político mencionado en la pantalla de título.

		● El sprite de Mario es reemplazado por "El Ciudadano", pudiendo escoger tanto su género como su afinidad política, representada
		  por el color de sus ropas.

		● Los sprites de los barriles que lanza Pablo Kong se reemplazan por simpatizantes de su partido: Una metáfora tan simple como eso:
                  Usar a la gente que te da apoyo como munición.

		● Los sprites de los enemigos y objetos de bonus se reemplazan por iconografía y tópicos de la ideología social-comunista. Por ejemplo,
                  en el juego original, Donkey Kong lanza barriles de madera contra un bidón ardiendo, lo que los convierte en llamas que te persiguen.
                  En esta versión, los simpatizantes son arrojados al fuego para convertirse en "malvados demonios comunistas", con cuernos, tridente y todo.
		  La única arma disponible en el juego, el martillo, es reemplazado por un "crucifijo".

                ● Otros muchos cambios. ¡Echadle un ojo y a disfrutar! Las cuatro partes restantes del proyecto estarán disponibles pronto,
                  reemplazando en cada una al villano principal por un líder político diferente.

_______________________________________________________________________________________________________________________________________________________


2) Como elegir género y afinidad política:

	Cada copia de este hack incluye 8 parches distintos para poder elegir el que mejor se ajuste a tus preferencias, ordenados con dos letras
	que indican primero el género y luego el color de la siguiente forma:

		● M= Hombre
		● W= Mujer

		● B= Azul
		● G= Verde
		● O= Naranja
		● R= Rojo

	Así que si queremos jugar con "El Ciudadano" del partido rojo usaremos el parche con la coletilla "MR", si queremos a "La Ciudadana" del
	partido naranja "WO", etc.

_______________________________________________________________________________________________________________________________________________________


3) Consejos de uso:

	Para que este hack se ejecute correctamente, debemos aplicarlo con un programa como "LunarIPS" (que puedes encontrar en www.romhacking.net) sobre una
        copia sin modificar de la rom "Donkey Kong (U) (PRG1) [!].nes". No se ha testeado con otras versiones, por lo que no se puede garantizar que funcione.
