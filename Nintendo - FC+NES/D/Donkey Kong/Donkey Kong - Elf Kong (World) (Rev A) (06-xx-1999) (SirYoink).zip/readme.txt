               ************************************
               *                                  *
               *         Klepto Software          *
               *                                  *
               ************************************
               *      http://klepto.r8.org        *
               ************************************
                            PRESENTS

                   Elf Kong: A Donkey Kong Hack
                           06/??/1999


About this Patch
__________________________________

My first ever romhack, thought to be long gone until I googled it.  Man, 
was I wrong!  This thing's been floating around hundreds of sites for 
the better part of ten years!  So here it is, in all it's... erm, glory. 

This hack replaces Mario in Donkey Kong with T.A.C. - that thieving ninja 
burglar originally from Kirby Super Star.  T.A.C. appears here in the 
version found in our Aertaroo games - a grey and white recolor minus the 
satchel.


PROGRESS
__________________________________

It is what it is, and it's as complete as it's gonna get!


USING THIS PATCH
__________________________________

This patch is for the NES version of Donkey Kong.  The unpatched rom
should be 24,719 bytes in size.

If you are unfamiliar with how to patch a rom, romhacking.net has an 
excellent FAQ on the subject:
http://www.romhacking.net/faq/


CREDITS
__________________________________

Hacking/Graphics:
SirYoink

