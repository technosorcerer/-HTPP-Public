I've made this hack to be able to select any item in the game.
You do so by pressing and holding select before you select your inventory.
By doing this, you will access an alternate inventory. Everytime you repeat
the process you will access the next page.
If you want to keep the current page, do the same, but press and hold start.
To have the desired item in the real inventory, just select it with the A button.
Then enter the inventory normally and you will have that item.

Remember to enter your inventory normally before you equip the items, or you will
get dummy items on the equip menu. The same goes if you want to sell an item.
Another point to note is that you must have at least one empty slot on your inventory
before you select an item on the alternate inventory, or the game will freeze.
You can also use any item on the alternate inventory, for example medical herbs or
any other usable item.

I've also hacked the game so you have max stats for all your characters, included
the extras, all the extras have the Metal Babble equip set, you can walk through
most things inside dungeons and towns, and you have max and infinite gold and
casino coins.

Thanks to:
Ugetab: He made the walk through walls code.
gedowsky: He made some extras stats and equipment codes.
Paulygon: He made some extras stats and equipment codes, and the allways terrific blow code. 

History:

3.0: Corrected a bug with the first page of items that made the digits go up by one.
     Changed all extras strength to 255.
     Added Stilleto Earrings effect to any weapon (unarmed included). You will attack
     twice a group of monsters.
     Added Paulygon allways inflict a terrific blow code.

2.1: Corrected a bug where alternate inventory shows up ramdomly.

2.0: Now you can equip any item on any character. Just select the equipped item
     on the alternate inventory and that character will have it equipped.
     The Stilleto Earrings, now make 150 damage. Very Usefull, because they allways
     connect 2 hits. This isn't really a new addition, its just I forgot to list it
     here las time :P.