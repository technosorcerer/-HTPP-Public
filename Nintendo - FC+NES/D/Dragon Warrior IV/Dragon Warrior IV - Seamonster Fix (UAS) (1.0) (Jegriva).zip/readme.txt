SEA MONSTER BUGFIX
for
DRAGON WARRIOR IV (USA) (or Dragon Warrior (U)[!])



This patch fixes the 5 unused sea enemies and the 4 very rare enemies (which appear only when exiting the Shrine of Breaking Waves). This bug was corrected in the PlayStation and Nintendo DS remakes (and most probably the iOS version which is a port from DS).
I copy-paste the technical details from the Dragon Warrior page from The Cutting Room Floor as for 06/10/2017 (or 10/06/2017, for you uncivilized illogical Americans ;)

"
The reason so many sea enemies don't appear anywhere, while others only appear under specific and strange conditions is, not surprisingly, because of a bug in the code that calculates what encounter zone you're in. The encounter zones for each roughly screen-sized section of world map (16 by 16 squares) are packed into a single byte, with the land encounter table index in the lower 6 bits and the sea encounter table index in the upper 2 bits. The bugged code starts in bank 18, address 9C5A (offset 61C6A in a headered .nes ROM image):

18/9C5A: AD 45 A2      lda $A245 ; lo byte of ptr to world map encounter table
18/9C5D: 85 00         sta $00
18/9C5F: AD 46 A2      lda $A246 ; hi byte of ptr to world map encounter table
18/9C62: 85 01         sta $01
18/9C64: A5 42         lda $42 ; player's X position in map squares
18/9C66: 4A            lsr
18/9C67: 4A            lsr
18/9C68: 4A            lsr
18/9C69: 4A            lsr
18/9C6A: 85 06         sta $06
18/9C6C: A5 43         lda $43 ; player's Y position in map squares
18/9C6E: 29 F0         and #$F0
18/9C70: 05 06         ora $06
18/9C72: A8            tay
18/9C73: B1 00         lda ($00),y ; read packed encounter table indexes
18/9C75: AE 15 05      ldx $0515 ; current vehicle (0 = on foot, 1 = ship, 2 = balloon)
18/9C78: E0 01         cpx #$01
18/9C7A: F0 05         beq ship
18/9C7C: 29 3F         and #$3F ; the land encounter table is in the lower 6 bits
18/9C7E: 4C 88 9C      jmp storeit
ship:
18/9C81: A5 07         lda $07 ; bug! this variable hasn't been initialized yet
18/9C83: 0A            asl
18/9C84: 2A            rol
18/9C85: 2A            rol
18/9C86: 29 03         and #$03 ; the sea encounter table is in the upper 2 bits
storeit:
18/9C88: 85 07         sta $07

The uninitialized variable $07 contains the index of the encounter table that was checked the previous step. So each step you take on the ocean, the game uses the index of the previous encounter table divided by 64 as the current encounter table. As a result, the only time a table other than table 00 gets used is when you have an encounter immediately upon moving from an area with an encounter table index of 64 or greater. The only such area that you can move directly into the sea from is the Shrine of Breaking Waves.

The four enemies that you can encounter via the Shrine of Breaking Waves method are in encounter table 01. If there were a dungeon with an encounter table index of 128 or greater that was accessible by ship, you could encounter the remaining five enemies (all of which are in encounter table 02), but the encounter tables used by the game don't go that high.

To fix the bug, change the byte at ROM offset 61C8B from 05 to 07 (i.e. change the destination of the beq so it skips over the bogus lda $07). A Game Genie code for the bug fix is YANOUGIA. 
"