             Dragon Warrior IV 
              
             Graphical Uncensoring
          Version 1.0, February 03 2024


__________

     General Info:


This patch for the NES US version of Dragon Warrior IV uncensors all the
graphics that were censored by reverting them to their Japanese counterparts.
Full list of changes:

- Restores the cross on Cristo's hat
- Restores the priests NPC
- Restores the cross tiles related to the churches
- Restores the tombstones to their original crosses
- Restores dead party members to coffins rather than ghosts
- Restores the cross logo next to the name of dead characters
- Restores the overworld tile  for shrines
- Restores the cross at the Royal Crypt
- Restores the bunny girls NPC
- Restores Vivian (bunny girl enemy)

See also the TCRF page for a full comparison:
https://tcrf.net/Dragon_Warrior_IV_(NES)/Regional_Differences

It is a graphical hack only and as such text remains untouched. 
Therefore all text censoring related to religion or sex are still censored.
I do not speak Japanese so I am not the best person suited to take care of this,
but I would welcome someone else making either an update to this hack or an addendum.
There is a text editor for the game on RHDN if you can figure out how to work with it.


__________

     Patching:

Using a patching tool such as Lunar IPS, patch the rom:
Dragon Warrior IV (U) [!].nes

This patch is compatible with the "Seamonsters bugfix" patch. Order of patching does not matter.

__________

     Credits:

Hacking: Ness aka MetHy