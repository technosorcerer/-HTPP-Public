 Dragon Quest IV Redux/Definitive Edition (Dragon Warrior IV) (Beta 0.4)

  The objective of 'Dragon Warrior Delocalized' is simply to restore all the elements changed from the Japanese version to the American version and also adding the following improvements:

-DW IV Dragon Quest IV title hack v1.0d by darthvaderx (with a big help from Pterias).

-DW IV Graphical Uncensoring hack v1.0 by MetHy.

https://www.romhacking.net/hacks/8426/

-DW IV Seamonsters fix hack v1.0 by Jegriva.

https://www.romhacking.net/hacks/3760/

-DW IV Doubled XP & Gold hack v1.0 by Psyklax.

The hack is not complete because the translation update by the 'Translation Quest' team is still pending. When it is released, I will provide an update.