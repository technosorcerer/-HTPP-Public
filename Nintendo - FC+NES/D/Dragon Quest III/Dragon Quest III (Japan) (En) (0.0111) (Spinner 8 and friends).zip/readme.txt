Dragon Quest III - version 0.0111
released 3 January 1999
by Spinner 8 (spinner_8@softhome.net)
http://www.digitalsorcery.net/warkwarkwark/

Here's a patch to translate Dragon Quest 3 into english.

Made by me (Spinner 8) with little/no help, and damn, does it show.

Release History:
0.0111: changed the readme a little bit.. I don't want to quit while
        my readme says it's still on hold...
0.011:  initial release

Status:
Dead. Dead dead dead dead dead dead dead. Big surprise.
Oh, and visit the BRILLIANT translation section at emucamp plzthx

How to apply:
unzip dq3.ips and ips.exe into the directory with your DQ3 rom that
you want to patch. now type in the command prompt:
ips.exe (here's where you put the name of your DQ3 rom, so don't really type this OK).nes dq3.ips
when it says "Patching Complete!" then congratulations. you're done
and stuff.

What is done:
The font is replaced with the Dragon Warrior 3 font. You might
encounter some Japanese characters here and there, but don't worry
about em, I never bothered to tidy up.
Command menus(talk, spell) are translated about 70%.
Battle menus(fight, run) are translated about 20%.
File menus(new game, continue) are translated about 90%.
No dialogue, items, spells etc. Very primitive patch, obviously.

Emulators:
486 owners rejoice, Nesticle runs Dragon Quest 3 perfectly.
Just be sure to set mirroring to vertical.
I haven't tried it with any other emulator, since my computer sucks.

Thanks to:
Neil_ for making me think that I could actually do this.

No thanks to:
Everyone else. It only makes sense, right?

Disclaimer:
This patch is legal, since this contains no copyrighted stuff. What YOU do with it is
none of my business, and I therefore hold no responsibility whatsoever for what you do or
whatever happens to you.
Enix definitely does not endorse this patch, and I am not affiliated with Enix in any way
at all. byebye