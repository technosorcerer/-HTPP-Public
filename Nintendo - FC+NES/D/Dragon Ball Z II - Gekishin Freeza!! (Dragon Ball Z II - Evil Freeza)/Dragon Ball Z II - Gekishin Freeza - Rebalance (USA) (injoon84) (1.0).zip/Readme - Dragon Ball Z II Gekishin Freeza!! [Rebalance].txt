Dragon Ball Z II: Gekishin Freeza!! (Rebalance)
--------------------------------------------------------

Info:
1) This ROM Hack rebalance the DBZ Warriors.
2) BP is adjusted so that Goku will not be too OP while Piccolo and Vegeta will have decent level up to level 25 (Max 40).
3) Reduce BP experience gains from the Gravity Machine Training before reaching level 31.
4) Adjustment regarding BP experience gains also been made for training like agility, rock and body split.
5) Modification on both optional bosses' BP experience gains were also included.
6) As for the HP, the value will now always end with either 0 or 5 when level up. Tenshinhan's HP at Level 36 is fixed too.
7) Fixed Gyroballer's English Patch v1.02 password system by adding ' while removing the unnecessary ' and etc.
8) All the details are inside the xls file. There is Cheat Code explaining how to make Vegeta fully playable too.

Emulator compatibility:
You have to test it yourself. VirtualNES will not work. To be safe, use FCEUX.

2 patches were provided:
1) Dragon Ball Z II - Gekishin Freeza!! (J) [Rebalance].ips
2) Dragon Ball Z II - Tyrant Freeza!! (J) [Rebalance] [T+Eng1.02_Gyroballer].ips

How to patch:
Use Lunar IPS and choose one of the ips file to patch it with the original ROM.
Database match: Dragon Ball Z II - Gekishin Freeza!! (Japan) (Rev 1)
Database: No-Intro: Nintendo Entertainment System (v. 20210216-231042)
File SHA-1: 1D1E2B5F97A0BDB4823FDC43308AB65BAB2A5152
File CRC32: D396D28A
ROM SHA-1: 111D38E2FB41D0B43753E18757D427A91B0DBCB9
ROM CRC32: A9541452

Software needed:
1) Lunar IPS
2) Compatible Nes Emulator
3) Software that can extract 'zip' extension file (e.g. Peazip, WinRAR, WinZip, etc)

Software involved:
1) https://www.aconvert.com/image/merge/
2) https://imageresizer.com/resize-png
3) https://www.rapidtables.com/calc/math/hex-calculator.html
4) FCEUX Emulator
5) HxD
6) Lunar IPS
7) Peazip
8) Software that can open and create 'xls' file (e.g. Microsoft Excel, WPS Office, etc)

Credits:
1) http://lucifer.s14.xrea.com/hobby/reizouko/
2) https://docs.google.com/document/d/1LO71sumL1XMlDnoQzo7Z1JMZnTJjYuTitvOTiJaB9WA/edit?tab=t.0
3) https://dragonball.fandom.com/wiki/Dragon_Ball_Z_II:_Gekishin_Freeza#Maps
4) https://gesato.com/fc/dbz2/data.html
5) Gyroballer from ROMhacking.net
6) Twilight Translations from ROMhacking.net


Written by injoon84:
12/07/2025
DD/MM/YYYY
      