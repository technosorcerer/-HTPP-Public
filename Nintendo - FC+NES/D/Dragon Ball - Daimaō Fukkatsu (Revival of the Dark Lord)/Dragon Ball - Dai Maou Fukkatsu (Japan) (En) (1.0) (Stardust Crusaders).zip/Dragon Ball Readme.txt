===============Dragon Ball============================
==========Revival of the Dark Lord====================
==================V1.00===============================
Genre: RPG

Source language: Japanese

Patch language: English

Author: Pennywise/Tom

E-mail: yojimbogarrett@gmail.com
http://yojimbo.eludevisibility.org/
 
======================================================
Dragon Ball: Revival of the Dark Lord
======================================================
Background: Work on this game began in late October 2010
when I contacted Tom to see if he would be interested in
translating this game. I respected the translations that
he had done and knew he translated a few Dragon Ball related
games, so I figured why not. So he said yes and translated
most of the text in a relatively short period of time.
Main hacking on this game wrapped up in the beginning of January,
but the project lingered around near completion until now.

This is the second Dragon Ball game for the NES and it has
the distinction of being the first good one. The first one
was a rather terrible action-RPG, but this game took out
the action and became more of a card battle RPG. I'm
fairly certain that its sequels continued with this style
and improved upon it. The game also likes to throw instant
death at you if you don't pick the right option.

The story for this game doesn't follow the manga/anime. It
kind of does at the beginning, but deviates entirely away
from it by the end. It's pretty easy to spot and should
shine new light upon old material.

======================================================
Game Tips
======================================================

* Press the select button on the world map to access
your status, map, inventory and passwords.

* To move to another "section" of the map, stand on
a "location" icon. Goku's position indicator will
blink. At that time, you can move Goku to another
line on the world map.

* To activate ally cards, press the B button after
you've confirmed which cards you will use. Your
ally will say something to you, and then you can
press the A button to activate that ally card.
You can use the up/down buttons to switch ally cards
at this time.

* When you smash the root of evil, you can rescue a
"cute girl" and she will become your ally.

* Also there is a special password that takes you to the
end of the game with everything maxed out.
It is as follows:

Uu:Top?   C'OSsps
PmHuNLi   DKD((CD

======================================================
Notes from the translator
======================================================

This game was fairly easy (and fun) to translate. I
tested it very thoroughly, so I do hope that you don't
encounter any glaring errors. It was a pleasure working
with Pennywise, and I hope to work with him again in
the future.

For the most part, the dialogue in the game was very
straight-forward, since it was intended to be for
children, but there were a few interesting
points for me as a translator, and I'd like to
mention this one in particular.

This game just might be one of the first games with a
theme song at the end. Of course, it's not voiced, but
there are words at the bottom of the screen, set to
a bleep-boop melody.

You were supposed to be able to sing along with the
ending. (I think that is really cool!) If anybody's
aware of any other sing-along NES or Famicom
games, please let me know.

Unfortunately, the poetic melody of songs meant that
this sing-along feature wouldn't really carry over
into the English patch. I could create entirely new
English lyrics to match the melody, or I could try
to create lyrics that matched up with the meaning
of the original.

Knowing this was agonizing as a translator, because
one way or another, something was going to be lost.

In the end, I decided to mix these two options.
I created a poetic re-interpretation of the song
that matched the meaning of the original as
closely as possible... But I made it rhyme, so
it would at least seem more like a song (even if
it didn't match up with the bleeps and boops
exactly).

The names themselves do not follow the Americanized
scheme. Tenshinhan is there in his unabbreviated glory.
Also, the naming system follows the English format.
First name, and then last name.

I hope you enjoy the translation.

-Tom
(translatortom@hotmail.com)

======================================================
Patching Instructions
======================================================
If choosing to apply the IPS patch, the PRG-ROM will
first need to expanded. It can be done manually in a
hex editor or with a few programs such as nflate or
preferrably with ROM Expander Pro. Please see this
site for more details:

http://dvdtranslations.eludevisibility.org/rom_expander_pro.html

Also included is a BPS patch that can be applied to the
original ROM with no extra steps. All you need to do is
apply the patch with beat.

http://byuu.org/programming/

We would be highly grateful, if you find some time to 
contact us with proposals or corrections. Information
on found bugs or corrections would be highly 
appreciated.   

P.S.

Support the game industry by buying used games!

Even if the money doesn't go to the developers
directly, as the games become rare and harder
to find, the price goes up, and people become
more inclined to buy new releases "while they can!"

======================================================

Credits go to:

Pennywise - main hacking, testing.

Tom - translation, testing.

aishsha - title screen design, advice

sin_batsu - graphic design

DvD - ROM Expander Program

ReyVGM - Special Thanks

All those who contributed into this process.

======================================================


Compiled by Pennywise. April 2011.
