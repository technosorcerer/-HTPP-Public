﻿--------------------------Info---------------------------
Game name: Darkwing Duck
Console: Nintendo entertainment system
Game region USA: (U)
Patch: SP (Solid patch)
Patcher: Solid patcher
Patcher download link:
 Windows: https://romhackplaza.org/utilities/solid-patcher-utility/
 Linux: https://romhackplaza.org/utilities/solid-patcher-utility-2/
 https://rgcorp.ucoz.net/load/console_soft/solid_patcher/2-1-0-97
----------------------------------------------------------
--------------------------patch------------------------
The patch adds the following change:
 
 Unlocked 6 levels at start of the game.

----------------------------------------------------------
If the ROM checksum does not match, skip or disable it's verification.

----------------------------------------------------------
Author by: spiiin
e-mail: sanya.boyko@gmail.com
https://www.patreon.com/CadEditor