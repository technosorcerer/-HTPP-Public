The original Darkwing Duck Advance was a nice idea for a Darkwing Duck hack.
Everybody wanted to see Darkwing's most fearsome rival Negaduck but it felt like unachivable dream.
So in the year 2012 sergi & evgeny released the hack which added a new level to this game with Negaduck becoming
final boss. There was one problem however. It was way too hard.
It was way too different from other levels in the game. And while it was not a problem for people who like 
hardcore games it became a nightmare for those who wanted to see just a new Darkwing Duck level with Negaduck in it.

This patch fixes the difficulty problem. Now casual players can also enjoy the Negaduck level.

Changes:
- Reduced health for all enemies (Birds and Bats - 2 Hit Points, Spiders - 1-2 hit point, Negaduck Drones - 1 hit point)
- Removed spikes from Negaduck boss fight.

This patch must be applied to the patched rom of Darkwing Duck. 
First you must apply original Advance version and only then Rebalance.


Enjoy the game!