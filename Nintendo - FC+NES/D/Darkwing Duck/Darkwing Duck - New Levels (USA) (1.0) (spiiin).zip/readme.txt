Darkwing Duck New Levels.
Authors: Emsi D & spiiin

created in CadEditor http://romhacking.net./utilities/967/

- New levels.
- New arena for the boss fights
- New bonus at every level.
- More powerful Heavy and Thunder Gases
- Six levels are open at start
- Some graphics redrawn.
- New Title screen.

email for feedback:
sanya.boyko@gmail.com