"Darkwing Duck"
Traducci�n al Espa�ol v1.0 (11/04/2017)
 POR JONNYVILLA2088(jonathan)

1. Sobre Darkwing Duck
2. Notas del Proyecto
3. Fallos Conocidos
4. Instrucciones de Parcheo
5. Derechos

---------------------
1. Sobre Darkwing Duck
---------------------
"Darkwing Duck" fue un juego hecho por Capcom 1992. Basado en la serie Duck Darkwing(Pato Darkwing en latinoamerica).La historia se trata de Una ola de crimenes 
misteriosos afectaron a St. Canard y S.H.U.S.H solicitan los servicios del Pato Darkwing para detener a una organizacion criminal llamada F.O.W.L. y a su agente
Steelbeak. Contrataron a los Seis mayores rivales de Darkwing para sembrar caos en diferentes Areas de St. Canard, Darkwing debe ir a detenerlos uno por uno hasta
encontrar a Steelbeak.  
---------------------
2. Notas del Proyecto
---------------------
Fue un trabajo traducirlas con el traductor hexadecimal y modificar ciertos tiles del juego.
El juego fue traducido al espa�ol al 96%. 

--------------------------------------------
3. Fallos Conocidos
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a jonathanjavier208@gmail.com 

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Debes utilizar el rom:

Darkwing Duck (U) [!].nes recomiendo buscarla en la p�gina: https://www.freeroms.com

-----------
5. Derechos
-----------
Darkwing Duck NES es propiedad de Capcom (c) 1992.
Traducci�n al espa�ol por JONNYVILLA2088.
Licencia de Nintendo.
No distribuir la rom y el parche unidos.

Saludos y espero que disfruten del juego.