                                                                
                                        .:+/                                    
                                     `/yhs/`                                    
                                    :ssh/                                       
                                  `so:y:                                        
                                  oo`y:    `..                                  
                              ``  y/-h` `/yho-                                  
                             `/ys:s/`o/.+yh/.oy.  o-   `/`                      
                              -s:::` `.-:.o+oyy`.+hs  `oh`                      
                           ./o/.           ```:///s+ -oys                       
                         -o+-`        -::-`      :s/+++o:-:-.                   
                       .+o-          :ssyhho-`    ``-oohy/.````                 
                     ./o:`           `-://::/+.     .:/h.  `:y:                 
                  .:++-`            -+:-..-/+.        `+//++oh.                 
               -/+:-`               s--:::-`.o:       `:+o++oo/-                
            ./+:.`                 `o:.`.-:+-.y`     -+:.`...`./o-              
          -o/.                     :/ `oyy+`o:h.     ``/+/:::++.-y.             
      `-/+y+:-.                    +- /s.od-`oh-      `.`     :s`y-             
     .s+-.``..:+-                  +: :ssyo` .h/             `+o/s              
     s/        `y.                 .+:.---..-/o:      ``   `:oso+`              
     ++        .y`                  .//////+/`       `s:/+//+/:`                
     `/+.     -o-                    `.-::::.         /+y/                      
       .+o:-++/`                          `          /o/:``..                   
        /sss+-`                       `.:/:         `-++ooss:                   
        y. /o::+o/:---..........--::+//-.`         `+//+::-`                    
        //:o/``+s----.------+s/-/s/.:+`            ./oso`                       
          `.-::/..-:////:::::+y: .o/`-o.```        :o+/.                        
                      ```......o/ `o+ -y/:/+/.    .+/+oy`                       
                               `s- `y- /+  `-o+   /o. `:`                       
                                :o  ++ .y    `y/ -+`                            
                                -y/::- //     oo o-                             
                               `s:.-/+o/      s/ y`                             
                                :o//::y:     -h.`y`                             
                        ``      -o/+shhh.   `s/ `y.                             
                     -//::++:`   `oo+o.+/   +o`  +o` -`..                       
                    `s.`.//yy++-`  ..  -s  -y.   `/++y+sh-                      
                     .:+o-:o:+`:+:`   `.h-/y-       `s+sy-`                     
                        .-/++.   -+/+//:/ydo.`````````.soos:                    
                                   .:///:++.:+ss+/::-  -:h-                     
                                     ```s+     .:++-`   `h-                     
                                   `:++yo         `:+/   +s                     
                                   s+` y-      `:+++++/- `h-                    
                                  .y` `h.     /s:.    `:o`s/                    
                                 `-s.` +o    -h.        /+s/                    
                                -y/... `so.  -y         .hy`                    
                                `++++/+o+:/+//s:.      `+s`                     
                                    ```    +s.  `   `./o+`                      
                                           `:++++++++/-`                        
                                                                                      
==========================================================================      

                             ABOMENAJ ZIZELOJ                      
                          Darkwing Duck ESPERANTO
                                 (NES, U)

==========================================================================                                            


La flikaĵo estas farita en formato .IPS. Por apliki ĝin, vi devas havi 
.NES imagon de la ludo Darkwing Duck por Nintendo Entertament System.


Versio 1.0
--------------------------------------------------------------------------

La unua eldono.
Estis tradukita la tuta teksto kaj bildoj.
Se vi trovos eraron, ni korektos ĝin kaj diros al vi dankon :)



Dum tradukado averiis sekvaj zizeloj:
--------------------------------------------------------------------------
Rompado de kodo:
ololo

Tradukado de teksto, dezajno de bildoj:
Trand

Ni estas zizeloj kaj ni aĉe abomenas!
Sed ni longe penis... ;)


www.zizeloj.org
zizeloj@gmail.com
https://www.reddit.com/user/abomenajzizeloj
https://www.youtube.com/@abomenajzizeloj