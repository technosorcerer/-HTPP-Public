Darkwing Duck Version 0.99

The world's first DUTCH NES translation! (i've never seen one before though)
Game translated: Darkwing Duck (NES, US) by Capcom
Translated by Little Mac.
punch_outt@hotmail.com
http://macroms.cjb.net

I've chosen for Darkwing Duck because I think it's a very good game for the NES and not very hard to translate (it's the first time i do this so...).

For the Dutch people:
Ik heb deze vertaling eigenlijk alleen gemaakt als tijdverdrijf maar het beviel me goed.
Alhoewel deze vertaling niet erg moeilijk was. In de toekomst zal ik zeker proberen meer spellen van het Engels naar het Nederlands te vertalen.
Ik waardeer het erg als ik reacties zou krijgen op deze vertaling, positief maar ook negatief.

Little Mac wants to thank:

Innocent Bystander (for telling me where the first bonus level is situated). Visit his site http://www.innocentemu.com

Sardius (for having one of the best NES-sites on the net, go there!) http://sardius.cjb.net

Digitoxin (for creating NEStoy and ROM-floods) http://nestoy.cjb.net
Lugnut, BootGod, Ian-E, Harry Kunhaker and more for ROMs.
Loopy, Sardu, Fanwen and more for emulators.
SnowBro (for the excellent tool Hexposure)
LavosSpawn (for HEXcalibur)
Nintendo and Capcom
Band Zonder Banaan (for creating the coolest music ever!  http://www.bzb.nl )
Retrogames and Zophar's Domain.
Snestool

You will need the original ROM, the IPS-patch included in this ZIP-file and Snestool to get the ROM in Dutch, that's easy and I think you already know how to do that. If not e-mail me at punch_outt@hotmail.com .

