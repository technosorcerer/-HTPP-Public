Lunar Pool (NES)
Traducci�n al Espa�ol v1.0 (28/03/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Lunar Pool (U) [!].nes
MD5: 60be0b2ff5484e6271c48f5b9e229356
SHA1: 79d35b9e5497a32200f56f9f86c7a0ebbe2dc52b
CRC32: fa96cba2
24.592 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --