Oh shoot, someone's actually reading this. Um...hi?

======================================================

FOREWORD:

If you haven't played Little Samson unaltered...
maybe do that first? Either way, the four intro
stages should teach (or at least hint at) what
all the characters can do, with two exceptions:

1) The second playable character won't slide on ice.

2) The fourth character won't sink in the swamp.

Each exception only has one level it can be used in, 
so take advantage of them when you can!

Heck, the ice level is skipped entirely if you
beat the evening-mountain stage with the first 
character NOT at full health! Not sure why the
developers programmed it that way.

Also, play on NORMAL mode, or you won't be able to 
play the last few levels (or see the good ending).

======================================================

BACKWORD:

Well, if you've discovered my little pet project,
you're probably wondering at least one of these things:


Q) Why? Why did you even make this? Honestly.

A) Well, ever since I discovered that these types of
hacks were a thing, I wanted some kind of parody of
them to exist. However, despite my lack of research,
I never found one. Eventually, it occured to me that
if I really wanted a parody to exist, I'd probably 
have to make one myself, so I did.

With that said, I'm aware that I'm walking a pretty
fine line by making one of these. It could easily be
interpreted as tactless, or even as an earnest entry
into what I'm supposed to be making a parody of, and
I wouldn't be surprised if I somehow failed on both 
counts. I guess I'll never know until I get feedback,
but even if this does end up universally panned, I
won't be too torn up about it. I mean, it's just a
simple sprite hack, after all.


Q) Why are there two patches?

A) One is for the U.S. version, and the other is for
the Japanese version. Both versions are basically the 
same, so just pick whichever one is most convenient
for you (in fact, the patch for the U.S. version 
should also work on the European version).


Q) No, I mean why did you make another patch just for
the other version?

A) Because I COULD. Is that good enough for you?


Q) But just because you CAN do something doesn't mean
you SHOULD do it.

A) Sh--shut up...


Q) Where are the altered sprites from?

A) In order of appearance:

TITLE HACK: Basically the same as the original, but
with the occasional erased line or new line to change
which letters the pixel clusters represent. Those
crappy explosion sprites are custom, though.

MY AVATAR: Lavos Battlefield from Chrono Trigger.
https://www.spriters-resource.com/snes/chronotrigger/sheet/56946/
(fun fact: this sprite wasn't there in 2012, so I had 
to rip my avatar myself)

LOADING WHEEL: partly custom, but heavily-based on the
one from Windows 7

KING KNIGHT: Shovel Knight
https://www.spriters-resource.com/pc_computer/shovelknight/sheet/67070/

WINDOWS LOGO: custom sprite

EXPLOSION EFFECT: Megaman Zero
https://www.spriters-resource.com/game_boy_advance/mmzero/sheet/28966/

SMARTPHONE: custom sprite

NOTIFICATION BELL: Google image search
https://cdn4.iconfinder.com/data/icons/notifications-1/32/505-01-512.png

CHARACTER SELECT SCREEN: slightly altered the game's
original brick sprite to be isometric. The banner
on the pillar is custom (and the change in color is 
totally intentional!).

LUIGI: Super Mario All-Stars + Super Mario World
https://www.spriters-resource.com/snes/smarioworld/sheet/53665/
(unfortunately not as distinct from Mario as Super
Luigi is to Super Mario. Oh well)

LUIGI'S PAUSE ICON: Mario Tennis (GBC)
https://www.spriters-resource.com/game_boy_gbc/mariotennis/sheet/12784/

BASS: Megaman and Bass/Rockman and Forte
https://www.spriters-resource.com/snes/megamanbassrockmanforte/sheet/6614/
https://www.spriters-resource.com/game_boy_advance/mmnbass/sheet/15729/

BASS'S PAUSE ICON: Megaman 10
https://gamecola.net/wp-content/uploads/2010/04/mm10-dlc-06.PNG
(another sprite I ripped myself, but this time because 
I wanted the outline to be visible; turns out, I only 
needed what was in that image! Oh well)

BASS'S DAMAGE EFFECT: Megaman 1-6
https://www.spriters-resource.com/nes/mm/sheet/36582/

RAYMAN and RAYMAN'S PAUSE ICON: Mini-Rayman from Rayman Advance
https://www.spriters-resource.com/game_boy_advance/raymanadv/sheet/24892/

COMMON ENEMY PROJECTILES and RAYMAN'S PUNCH EFFECT: Also 
from Rayman Advance, but I had to rip it myself, so I 
have nothing to link to.

BOMBERMAN and BOMBERMAN'S PAUSE ICON: Bomberman Tournament
https://www.spriters-resource.com/game_boy_advance/bombertourn/sheet/8115/

E-TANK: Megaman ZX
https://megaman.fandom.com/wiki/Tank

HEART TANK: Megaman X
https://www.spriters-resource.com/snes/mmx/sheet/21390/

1UP: Castlevania - Rondo of Blood
https://castlevania.fandom.com/wiki/One-Up

SLIME: Freedom Planet
https://www.spriters-resource.com/pc_computer/freedomplanet/sheet/62529/
(the stench lines are custom, though, for what it's
worth (which is not much, really))

U.F.O.: Kirby and the Amazing Mirror
https://www.spriters-resource.com/game_boy_advance/kirbyandtheamazingmirror/sheet/32598/

GEEMER/ZOOMER/WHATEVER THE OTHER PALETTES ARE CALLED: Super Metroid
https://www.spriters-resource.com/snes/smetroid/sheet/1719/

KIRBY: Kirby Super Star Ultra
https://www.spriters-resource.com/ds_dsi/kssu/sheet/14758/

NAMELESS CAT: Trip World
https://www.spriters-resource.com/game_boy_gbc/tripworld/sheet/76157/
(the perked-ears part of the sprite is slightly custom)

MOZZIETRON MK2: Knuckles' Chaotix
https://www.spriters-resource.com/genesis_32x_scd/knuckleschaotix32x/sheet/10070/

CORE-X and X PARASITE: Metroid Fusion
https://www.spriters-resource.com/game_boy_advance/metfusion/sheet/30125/
https://www.spriters-resource.com/game_boy_advance/metfusion/sheet/31161/
(I had to rip the X Parasite's spawning sprites since
they weren't in the sheet (probably because it's just a
stretched version of the default sprites))

THE TRINE: Trine
https://trine.wikia.com/wiki/The_Trine

WADDLE DOO: Kirby Super Star Ultra
https://www.spriters-resource.com/ds_dsi/kssu/sheet/14791/

STAR MAN: Megaman V (NES)
https://www.spriters-resource.com/nes/mm5/sheet/4712/

LARGE STAR PROJECTILE: Jermungandr's Star Rod Kirby
https://www.spriters-resource.com/custom_edited/kirbycustoms/sheet/16759/
(the particular sprite I used may be taken from an 
official Kirby sprite somewhere, but that sheet is where
I got it from)

VENUS FIRE TRAP: Super Mario Advance 4
https://www.spriters-resource.com/game_boy_advance/sma4/sheet/22919/

VENUS FIRE TRAP'S LEAVES: Super Mario World
http://old.smwiki.net/wiki/Vine
(I got the animation from SMBX, but I couldn't find a rip
of it online; sorry)

MOUSE CURSOR: Windows 10
(personal rip)

GROUCHO MARX GLASSES: Google image search
(I don't remember which one I used as a base for this 
sprite, though)

EVIR: Super Metroid
https://www.spriters-resource.com/snes/smetroid/sheet/1719/

SPEAR-MASKS: Wario Land 4
https://www.spriters-resource.com/game_boy_advance/wl4/sheet/22769/

MAGNET DRONE: Megaman - The Wily Wars
This is another sprite I had to rip myself (though it
turns out the sprite isn't that much different from its
Megaman III counterpart; go figure).

BOMB: Metal Slug
https://www.spriters-resource.com/neo_geo_ngcd/ms/sheet/20577/
(It's near the bottom)

BAR WAYING: Megaman X2
http://www.sprites-inc.co.uk/sprite.php?local=X/X2/Enemy/

CLIPPY/CLIPPIT: Microsoft Office '97
https://www.deviantart.com/thenoahguy1/art/Clippy-spritesheet-440806457

TELLY R and BIG TELLY: Megaman and Bass/Rockman and Forte
https://www.spriters-resource.com/game_boy_advance/mmnbass/sheet/15745/

NAVAL PIRANHA: Yoshi's Island
https://www.spriters-resource.com/snes/yoshiisland/sheet/4765/

KARBINE: Donkey Kong Country 3 (and Donkey Kong Land 3)
https://www.spriters-resource.com/snes/dkc3/sheet/40003/
https://www.spriters-resource.com/game_boy_gbc/dkland3/sheet/43843/

GEEGA: Super Metroid
https://www.spriters-resource.com/snes/smetroid/sheet/1719/

KAOS: Donkey Kong Country 3
https://www.spriters-resource.com/snes/dkc3/sheet/12183/

DATA CRYSTAL: RHDN Wiki
http://datacrystal.romhacking.net/
(Mario is from SMB1, by the way)

MEDUSA/GORGON HEADS: Castlevania - Symphony of the Night and the DS games
https://www.spriters-resource.com/ds_dsi/cstlevniaprtraitofruin/sheet/19266/

CUCKOO CONDOR: Wario Land 4
https://www.spriters-resource.com/game_boy_advance/wl4/sheet/32600/
(a.k.a. the reason the red palette became brown)

HELICOPTER BLADES: Metal Slug
https://www.spriters-resource.com/neo_geo_ngcd/ms/sheet/20578/

LINK: Super Mario Bros. X
https://www.spriters-resource.com/pc_computer/supermariobrosx/sheet/96393/

MAKKUN: Sutte Hakkun
https://www.spriters-resource.com/snes/sutte/sheet/13925/
(it's there, you just can't see it. Really!)

SUNGLASSES: custom sprite

TANK TREADS: Advance Wars 2
https://www.spriters-resource.com/game_boy_advance/advancewars2blackholerising/sheet/45526/

GHOST: Sonic and Knuckles
https://www.spriters-resource.com/genesis_32x_scd/snk/sheet/42879/

TOP HAT and MONOCLE: Google image search
http://www.moneycle.com/images/monocle-cigar-442_540.jpeg

GUY FAWKES MASK: Google image search
https://hottopic.scene7.com/is/image/HotTopic/10177021_hi?$pdp_hero_standard$
(Yes, it's really supposed to be that mask. I'm just
happy I was able to make it look like *A* mask/face)

ANGEL EMOTICON and SPEECH BUBBLES and PAPER: Simple Machines Forum 2.0
http://www.romhacking.net/smf/Smileys/newyabb/angel.gif
https://custom.simplemachines.org/themes/index.php?action=download;lemma=2874;id=17893;image
http://www.romhacking.net/forum/Themes/boss/images/post/xx.gif

WINK EMOJI: Google image search
https://cdn.shopify.com/s/files/1/1061/1924/products/Wink_Emoji_large.png?v=1480481060

THWIMP: Super Mario Advance 4
https://www.spriters-resource.com/game_boy_advance/sma4/sheet/22919/
(The solid tiles that somewhat resemble Thwimps are
custom (or at least as custom as they can be while
still intentionally resembling Thwimps))

SPINNING THINKING EMOJI: Google image search
https://media1.tenor.com/images/4b7399689d7c8d618b7ea21bcec6be6d/tenor.gif

DRAGON TEAR: Chrono Cross
https://chrono.fandom.com/wiki/Dragon_Tear

EDIT TAB and HAND CURSOR: custom

CLOSE BUTTON: custom

CASTLE BOSS PHASE 1: take a wild guess

CASTLE BOSS PHASE 2: The tile-editing window of Tile Layer Pro
(custom rip)

BUILDINGS: Donkey Kong 1994
https://www.spriters-resource.com/game_boy_gbc/dk/sheet/30087/

AIRPLANES: Mario Paint
https://www.spriters-resource.com/snes/mariopaint/sheet/57988/

AIRPORT TOWER: Advance Wars 2
https://www.spriters-resource.com/game_boy_advance/advancewars2blackholerising/sheet/11827/

SUPPORT BEAM/GIRDER: Advance Wars 2
https://www.spriters-resource.com/game_boy_advance/advancewars2blackholerising/sheet/11816/

MEGA MAN: Megaman 1-6
https://www.spriters-resource.com/nes/mm/sheet/36582/

SONIC ICON: Sonic the Hedgehog
https://www.spriters-resource.com/genesis_32x_scd/sonicth1/sheet/21628/

SOMA CRUZ: Castlevania - Aria of Sorrow 
https://www.spriters-resource.com/game_boy_advance/cvaos/sheet/4361/

AXEL: Streets of Rage 2
https://www.spriters-resource.com/genesis_32x_scd/sor2/sheet/10976/

MILK: Nuts and Milk
https://www.spriters-resource.com/nes/nutsmilk/sheet/60704/

PINEAPPLE: Tile Molester icon
https://www.romhacking.net/utilities/screenshots/991screenshot1.png
(may or may not be a general-Java-application icon)

GREAT HUSK SENTRY: Hollow Knight
https://www.reddit.com/r/HollowKnight/comments/6m4kok/spoilers_game_sprite_sheets_and_textures/
https://i.imgur.com/W5KpzVY.jpg

MAX: Streets of Rage 2
https://www.spriters-resource.com/genesis_32x_scd/sor2/sheet/28758/

TEXT WINDOW: Chrono Trigger
https://www.spriters-resource.com/snes/chronotrigger/sheet/26682/
(Used here to represent a picture and picture frame)

FLAMER: Kirby and the Amazing Mirror
https://www.spriters-resource.com/game_boy_advance/kirbyandtheamazingmirror/sheet/32598/

HARD HAT and BLUEPRINTS: Tile Layer Pro icon
https://www.romhacking.net/utilities/screenshots/108screenshot1.jpg

LARGE HEALTH PICK-UP: Super Metroid
https://www.spriters-resource.com/snes/smetroid/sheet/31610/

BOMBERMAN'S EPILOGUE SPRITES: Bomberman Tournament
https://www.spriters-resource.com/game_boy_advance/bombertourn/sheet/8138/
https://www.spriters-resource.com/game_boy_advance/bombertourn/sheet/8113/

LUIGI'S EPILOGUE SPRITES: Google Image Search
https://luigismansion.nintendo.com/assets/img/characters/char-luigi-3.png
http://3.bp.blogspot.com/-QNdYjFOJ6k0/TcqynRkLu3I/AAAAAAAAAUc/ybQR8Kvmt3Q/s1600/nsmb-luigi-jumping.jpg

FANCY FIN: Google Image Search
https://www.flickr.com/photos/56590546@N03/15572797796/lightbox/

(all other epilogue sprites were either from previously-
linked sprite sheets or were based on the existing
ending graphic).

There, I gave credit. Are you happy, TSR members?

======================================================

Support the used game industry by buying used games!

Even if the money doesn't go to the developers
directly, it DOES go to me directly!

Er, I mean: as digital distribution becomes more common 
and physical copies of games become rare and harder to 
find, the price for physical copies goes up, and people become
less inclined to buy physical releases "while they can"
because they know they can just wait for a price drop
on the digital version, and...where was I going with this?