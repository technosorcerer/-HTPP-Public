      
            Little Samson - quick character switch V 1.0 / hack by The Jabu  2025
        ------------------------------------------------------------------------------
   
          
           This simple hack lets you switch characters by pressing the select button.      
        



        
  


     Apply the IPS file to "Little Samson (U).nes" and have fun!!!
