Laser Invasion (NES)
Traducción al Español v1.0 (17/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Laser Invasion (U) [!].nes
MD5: cc1a269194eea71e1c79e6541fcb13a1
SHA1: 62fac07016d534852c9da61c060e8bd19ba5e6f0
CRC32: e39e0be2
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --