Thank you for downloading NES Lemmings Improvement!

This hack features:
  - Improved color palettes
  - Improved music and sound effects
  - Simultaneous music and sound effects
  - More useful HUD
  - More appealing font for menu screens
  - More appealing toolbar design
  - Tweaked lemming animations
  - Various bug fixes and gameplay tweaks
  - Altered levels to work with those gameplay tweaks

We hope this is more enjoyable to play!

NOTICE: BOTH the NTSC-optimized version AND the PAL-optimized
version MUST be applied to the USA release of the game!!!

Updated 2024 by Nintendo Lemmings Improvement Team.
Designed by The Tomato Watcher and MisaeRockabout!

-----------------------------------------------------------------

Version History:

  Ver. 1.4:
  - Added the classic "Let's Go!" speech sample at the start of
    every level (without increasing the ROM size!)
  - Fixed an issue where repeatedly pausing could cause the
    Lemmings to slowly desync from one another
  - Fixed a bug preventing the Lemming status "DROWNER" from
    appearing in the HUD
  - Fixed a bug causing the first frame of the chain trap
    animation to be skipped
  - Added the ability to mash the d-pad to navigate the skill bar
    quicker
  - Implemented the skill bar logic in the password screen to
    make it less annoying to enter them
  - Tweaked some title screen graphics
  - Tweaked some graphics in the end credits
  - Updated end credits

  Ver. 1.3:
  - Greatly improved cursor movement; it now accelerates to a
    top speed of 3px/frame the longer you hold a direction,
    rather than stiffly moving at a constant speed of 2px/frame
  - Altered cursor graphics for better contrast
  - Improved audio mixing
  - Better Bomber sound effect and animation
  - Better Skill Assignment sound effect
  - Added Steel sound effect
  - Fixed some very small timing issues
  - Fixed a very minor audio bug where sound effects would
    nullify any pitch bend effects for the channel it played on
    until a new pitch bend effect was loaded
  - Several small changes to skillsets
  - Game now initializes all of memory at power-on
    (yes, the original game didn't do that, and it executed
    several uninitialized memory reads, albeit inconsequential)
  - Provided a PAL-optimized patch with corrected audio
  - Updated end credits

  Ver. 1.2:
  - Fixed a bug where assigning a Basher to a left-facing Miner
    would result in the Basher deleting part of the Miner ramp,
    making it impossible to walk up without using more skills
  - Enabled skipping the intro cutscene without having to wait
  - Swapped the terrain of Fun 18 to match that of Mayhem 14
    rather than Tricky 1, as the solutions for Fun 18 and Tricky
    1 were identical
  - Increased time limit of Tricky 6 from 3 minutes to 6 minutes
  - Altered the Faller animation to face in one direction
    rather than flipping back and forth

  Ver. 1.1:
  - Enabled assigning skills while the game is paused
  - Altered skillset and save requirement of Mayhem 25 to be
    less annoying
  - Removed two small lava objects in Tricky 8 to avoid
    PPU OAMADDR bug when hatches open

  Ver. 1.0:
  - Enabled switching skills while the game is paused
  - Pausing the game no longer obscures the HUD
  - Skills assigned to Climbers pulling up onto a ledge are
    no longer eaten and are instead queued as normal
  - Builders now bounce off walls/ramps and continue building
    in the opposite direction, including when they are
    first assigned to a Walker about to hit a wall
  - In any situation where a Builder cannot build at all
    (e.g. hitting a ceiling or being assigned between two ramps)
    he will ALWAYS turn around before reverting to a Walker
  - Builders assigned to Bashers near a ledge no longer get eaten
  - Bashers can no longer phase through tiles
    without destroying them