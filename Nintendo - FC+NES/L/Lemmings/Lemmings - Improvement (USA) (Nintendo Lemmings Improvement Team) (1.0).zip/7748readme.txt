Thank you for downloading NES Lemmings Improvement!

***ONLY DESIGNED FOR THE USA VERSION OF THE GAME***

This hack features:
  - Improved color palettes
  - Improved music and sound effects
  - Simultaneous music and sound effects
  - More useful HUD
  - More appealing font for menu screens
  - More appealing toolbar design
  - Tweaked lemming animations
  - Various bug fixes and gameplay tweaks (more detail at bottom)
  - Altered levels to work with those gameplay tweaks

We hope this is more enjoyable to play!

Released 2023 by Nintendo Lemmings Improvement Team.
Designed by The Tomato Watcher and CindySparks.

-----------------------------------------------------------------

Gameplay tweaks:
  - Enabled switching skills while the game is paused
  - Pausing the game no longer obscures the HUD
  - Skills assigned to Climbers pulling up onto a ledge are
    no longer eaten and are instead queued as normal
  - Builders now bounce off walls/ramps and continue building
    in the opposite direction, including when they are
    first assigned to a Walker about to hit a wall
  - In any situation where a Builder cannot build at all
    (e.g. hitting a ceiling or being assigned between two ramps)
    he will ALWAYS turn around before reverting to a Walker
  - Builders assigned to Bashers near a ledge no longer get eaten
  - Bashers can no longer phase through tiles
    without destroying them