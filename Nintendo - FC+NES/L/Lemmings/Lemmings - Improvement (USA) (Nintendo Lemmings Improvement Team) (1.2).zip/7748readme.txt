Thank you for downloading NES Lemmings Improvement!

***ONLY DESIGNED FOR THE USA VERSION OF THE GAME***

This hack features:
  - Improved color palettes
  - Improved music and sound effects
  - Simultaneous music and sound effects
  - More useful HUD
  - More appealing font for menu screens
  - More appealing toolbar design
  - Tweaked lemming animations
  - Various bug fixes and gameplay tweaks
  - Altered levels to work with those gameplay tweaks

We hope this is more enjoyable to play!

Released 2023 by Nintendo Lemmings Improvement Team.
Designed by The Tomato Watcher and CindySparks.

-----------------------------------------------------------------

Version History:

  Ver. 1.2:
  - Fixed a bug where assigning a Basher to a left-facing Miner
    would result in the Basher deleting part of the Miner ramp,
    making it impossible to walk up without using more skills
  - Enabled skipping the intro cutscene without having to wait
  - Swapped the terrain of Fun 18 to match that of Mayhem 14
    rather than Tricky 1, as the solutions for Fun 18 and Tricky
    1 were identical
  - Increased time limit of Tricky 6 from 3 minutes to 6 minutes
  - Altered the Faller animation to face in one direction
    rather than flipping back and forth

  Ver. 1.1:
  - Enabled assigning skills while the game is paused
  - Altered skillset and save requirement of Mayhem 25 to be
    less annoying
  - Removed two small lava objects in Tricky 8 to avoid
    PPU OAMADDR bug when hatches open

  Ver. 1.0:
  - Enabled switching skills while the game is paused
  - Pausing the game no longer obscures the HUD
  - Skills assigned to Climbers pulling up onto a ledge are
    no longer eaten and are instead queued as normal
  - Builders now bounce off walls/ramps and continue building
    in the opposite direction, including when they are
    first assigned to a Walker about to hit a wall
  - In any situation where a Builder cannot build at all
    (e.g. hitting a ceiling or being assigned between two ramps)
    he will ALWAYS turn around before reverting to a Walker
  - Builders assigned to Bashers near a ledge no longer get eaten
  - Bashers can no longer phase through tiles
    without destroying them