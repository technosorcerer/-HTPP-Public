This is a Legend of Zelda mod that not only makes a more unique and archaic font, but also rewrites the original game while retaining some of the original points.
The game not only used the original japanese script as a basis, but has in addition a bit from the english translation and a few new lines by me.
You can use the font used here for the base of your hack if you like, just credit me for it.

\/ IMPORTANT IF YOU'RE GOING TO USE THIS ON OTHER HACKS \/

THE PATCH FontModAddendum IS THE PATCH SPECIFICALLY DESIGNED TO BE INCORPERATED INTO OTHER LOZ1 HACKS. THERE IS ALSO A NON-TRANSLATED VERSION WITH JUST THE FONT BEING THE ONLY CHANGED CALLED FontModUntranslated, JUST IN CASE THE HACK CHANGES THE TEXT AS WELL.

/\ IMPORTANT IF YOU'RE GOING TO USE THIS ON OTHER HACKS /\

Included within the zip is 5 things:
1. The readme you're reading right now.
2. FontModStandalone, which is the font and translation alongside other additions, as seen below. If you just want to play Zelda 1 retranslated with a few added niches here and there, you use this patch.
3. FontModAddendum, which is just the font and translation, that can be used on any compatible rom hacks (specifically, the ones that use the PRG0 version of the game).
4. FontModUntranslated, which is just the font and nothing else (if you plan to use it as a base or the rom hack you want to use it on is already translated).
5. FontModTranslationOnly, which is just the translation and nothing else (if you find the font unappealing for some reason).

The FontModStandalone has a few other changes aside from the font and retranslated text:
1. The hack incorperates the Automap Plus mod by Snarfblam (million thanks to him), which includes an accurate and unfolding world map, a health meter represented in eights (due to blue and red rings) and faster health refills.
2. Instead of hearts, the 3rd shop type now sells Fairies for 25 rupees instead, seeing as how selling individual hearts is kinda tedious. Just a neat touch.
3. The title screen has a TM added, for consistency with the other official versions of the game (like the virtual consoles).
4. The old man's sprites have been made more consistent, as his sprites were different in dungeons (for some reason).
5. Zelda's sprites have been made to look similar to Link's, with similar eyes and mouths. Nothing too radical, but a neat touch I felt like doing.
6. The piece of paper that Link holds at the end of the intro crawl has been partially restored to look more similar to the original japanese sprite.
7. The palette for the Triforce on the title screen has been tinkered a bit, in order to be more shiny and gold-looking.
8. Link's other tunics have a harder/softer tone of blue/red respectively, so that they don't look as harsh, and resemble more his green tunic.
9. Palettes of the intro crawl, the save screen, and Level 3 (Swasti- MANJI, I MEAN MANJI) are now more consistent with Link's in-game color.

None of these features are in any of the other patches in order to not conflict with the hack you're using the font or translation with.

I hope you enjoy this little side project I worked on. It's my first published ROM hack, though, so please leave a constructive critique or review on the hack. Helps me improve.