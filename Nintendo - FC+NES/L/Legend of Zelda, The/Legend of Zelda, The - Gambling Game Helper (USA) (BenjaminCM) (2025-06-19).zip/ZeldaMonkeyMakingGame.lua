-- Zelda I: Gambling Game Helper
-- Written by: benjamincm
-- Purpose: See the results of Money Making Game before it happens.

-- Constants
local ADDR_FIRST_ENEMY = 0x0350;
local ADDR_GAMBLING_ST = 0x0448;
local ADDR_GAMBLING_END = ADDR_GAMBLING_ST + 0x0002;
local IND_GAMB_OLD_MAN = 112;
local BASE_X_COOR = 50;
local BASE_Y_COOR_SEC_ROW = 70;
local X_COOR_OFFSET = 40;

while true do

	local first_enemy = memory.read_u8( ADDR_FIRST_ENEMY );

	if first_enemy == IND_GAMB_OLD_MAN then -- Gambling old man.

		gui.text( BASE_X_COOR, BASE_X_COOR, "GAMBLING GAME HELPER: " )
		local x_coor = BASE_X_COOR;
		
		for addr = ADDR_GAMBLING_ST, ADDR_GAMBLING_END, 0x0001 do

			local value = memory.read_u8( addr );
			local color = nil

			if value == 50 or value == 20 then -- Positive in the base game
				color = 'green'
				value = '+' .. value
			end
			if value == 10 or value == 40 then -- Negative in the base game (Like each others)
				color = 'red'
				value = '-' .. value
			end

			gui.text( x_coor, BASE_Y_COOR_SEC_ROW, value, color );
			x_coor = x_coor + X_COOR_OFFSET;

		end

	end

	emu.frameadvance();

end