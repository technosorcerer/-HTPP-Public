---------------------------
Title: Cute Legend of Zelda
Version: 1.0
Author: Crabby Gabby (crabbygab@yahoo.com)
Group: CuteRomz (http://cuteromz.cjb.net)
Date: February 24, 2001
---------------------------

About Cute Zelda:
-----------------
	You are probably aware that there are a great many hacks of "The Legend of Zelda".
So why bother creating yet another? Well, I beleive that even at this hack's early stages
of development, it surpasses many others in terms of graphical enhancement. The graphical
additions are borrowed largely from "Link's Awakening", but in some cases, are improvised
following the tradition of modern (post 1990) Nintendo graphic art. A slight amount of text
has been varied, and there have been no dungeon or overworld changes to date, although once
I have completed updating the graphics, you can expect to see a separate version containing
the "third" and "fourth" quests, possibly with a few added enemies and characters.


What you need to install and run "Cute Zelda 1.0":
--------------------------------------------------
- An IPS patcher, such as the one found on my site (http://cuteromz.cjb.net)
- A NES emulator, my recommendation being Nesticle x.xx, which can also be found on my site.
- The NES rom "The Legend of Zelda". I cannot give you this, but if you are resourceful,
	it can be yours.
- Correct usage of IPS.EXE, as follows:
	ips.exe <name of your zelda rom>.nes cutez10.ips

Credits, without which, this project would not exist:
-----------------------------------------------------
Nintendo, for creating "The Legend of Zelda", copyright 1986.
Kent Hansen, for creating Hexposure 0.44b and Tile Layer 0.50b, both of which were used to hack this game

Version 1.0:
------------
The following Characters have been changed:
- Link (Yes, EVERY single frame of him)
- Zelda (But not her lifting the triforce)
- The old man in the dungeon is now the owl
- The old man in the overworld is now a frog
- The old woman has been changed
- The shopkeeper has been changed

The following Enemies have been changed:
- Tektite
- Octorok
- Leever
- Peahat
- Molblin
- Armos
- Ghini
- Lynel
- Zora
- Zol
- Gel
- Rope
- Vire
- Keese
- Stalfos
- Goriya
- Wizzrobe
- Darknut
- Pols Voice
- Like Like
- Gibdo
- Bubble
- Traps

Also, bits and pieces of landscape have been replaced,
- trees
- rocks
- tombstones
- dessert

	Any comments, suggestions, or criticisms can be sent to crabbygab@yahoo.com, it would be greatly appreciated.
Until the next version, Gabby signs off.