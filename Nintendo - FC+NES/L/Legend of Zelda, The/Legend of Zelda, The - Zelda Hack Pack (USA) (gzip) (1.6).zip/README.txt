Legend of Zelda Hack Pack

This is a collection of various standalone patches that can be applied to almost
any Legend of Zelda hack.

The collection contains the following patches:

b_button_text.ips - Simplify the B button text in the HUD (gzip)

better_font.ips - Use a tighter, cleaner font (gzip)

dungeon_music.ips - Dungeon music from Zelda: A New Light (gzip)

fast_fill.ips - Fill hearts faster from fairy and potions (snarfblam)

fix_wand_melee_bug.ips - Fixes the strange wand behavior which strikes enemies behind Link (gzip)

flute_kills_pols.ips - Play the flute to kill all Pols Voice (Stratoform)

full_health.ips - Start the game with full health (ShadowOne333, kalita-kun, gzip)

hud_flicker.ips - Removes the hud flicker when entering and exiting caves (minucce)

hud_save.ips - Press Up+A to save from the HUD screen (ShadowOne333)

level_to_dungeon.ips - Change the LEVEL text in dungeons to DUNGEON (gzip)

like_like_rupees.ips - Like-Likes eat rupees instead of the Magical Shield (gzip)

low_hearts_sound.ips - Change the low hearts sound to a softer heartbeat sound (gzip)

no_rupee_flash.ips - Remove the flashing effect from rupees (ShadowOne333)

not_lost.ips - Modifies the lost hills and lost woods to become normal screens (gzip)

pale_link.ips - Fixes pale link palette in level 3 (ShadowOne333)

select_item.ips - Use the select button to cycle through the B item (ShadowOne333, gzip)

slow_waterfall.ips - Modifies the waterfall in the intro screen (gzip)

text_speed.ips - Speed up the in game text a bit (gzip)
