Ola,

my name is André Mena Calavia, known in Romhacking.net as RetGal, acronym of "Retro Galicia".

This is a fully functional Galician translation patch for The Legend of Zelda for NES.

It surprised me that there were still no translation into Galician of this game, when there is even a translation of Zelda 2 into the same language, so I decided to try it.

It became pretty easy to see why there were no other before: ROM has no direct translation, and some of the tools available to hack the game produce undesirable glitches. But, after paying attention and creating a table on my own in my notebook (yeah, with pen and paper) I managed to use the broken tools to my advantage and succeed in the translation.

I said "succeed" since this translation took me less than 24 hours of real life, 12 hours of real work. I am pretty confident that there are no glitches (at least the common ones), so I decided to put this translation directly as "fully playable". However, ending and final credits have no been tested, so if any error exists due to translation it is most likely to be found there. 

Feel free to let me know if there is any glitch during your playthrough; Galician may not be the most popular language, but is my mother language and any product related with it may have the best quality.


-- Tools used --

• TheLegendOfZeldaTextEditor.exe -- produces undesirable glitches, it has been just used to check that all texts of the ROM where translated.
• Zelda Character Text Editor.exe -- works fine even if produces some broken lines since sometimes forgets to add the end-line code and/or end-message code (these were solved by hand).
• ZSE.exe -- this has been the best of all, no glitches and allowed me to change properly the most difficult part of the ROM, the intro story.


--Patches--

Due to the use of these tools, that work properly with the USA version of the game, the Galician patch has been created for the ROM "Legend of Zelda, The (USA).nes".

Either way, another version has been created for "Legend of Zelda, The (Europe).nes", since the only difference is the tempo of the music (as far as I have checked).

I assume you know how to apply a patch.


-- What do these patches change --

♠ Title screen
♠ Story text
♠ Treasure names
♠ Registration texts (Galician alfabet order)
♠ HUD texts
♠ Game Over texts
♠ NPC messages (some have been made more comprensive)
♠ Ending texts
♠ Staff texts (respected all members of the original staff)
♠ Translation credit (the image after the treasure roll)

♠ Add the Galician stressed vowels Á É Í Ó Ú
♠ The "K" and "Y" are respected due to "Hyrule" and "Link", but moved aside from the Galician alfabet (check photo provided)

♠ As far as I know, the only difference between NTSC and PAL versions is the tempo f the music; I tried the NTSC patch in the PAL ROM and the other way round (PAL patch in NTSC version) and both are equily playable (just changed the tempo).


-- Work in progress (undone things needed to improve) --

♣ Checksum OK (is there a Checksum in the NES to begin with? I do not know)
♣ Check all texts (none checked but the ones of the begining, before any dungeon)


-- Contact --

If you find any glich or want to mail me for reasons, you can do it through my Romhacking.net profile --> https://www.romhacking.net/forum/index.php?action=profile;u=91332

Have a nice day 🎮🐈 