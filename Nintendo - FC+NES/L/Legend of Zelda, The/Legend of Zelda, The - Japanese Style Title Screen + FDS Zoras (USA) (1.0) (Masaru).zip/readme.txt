Japanese Style Title Screen + FDS Zoras
by Masaru

The name basically resumes it. This romhack features a Japanese styled title screen for The Legend of Zelda made by Graphicus,
it also restores the Zora's sprites back to their FDS counterpart, now they don't look awful to look at. Nothing else was changed.

Patch for the following rom:
Database match: Legend of Zelda, The (USA)
Database: No-Intro: Nintendo Entertainment System (v. 20210216-231042)
File SHA-1: 799459548F9636DD263200DA494F04058F5540E2
File CRC32: 316CFF69
ROM SHA-1: A12D74C73A0481599A5D832361D168F4737BBCF6
ROM CRC32: 3FE272FB