The Legend of Super Mario
By: NesDraug

Welcome to Mushroom Kingdom, where Bowser has captured
Princess Toadstool and thrown the Kingdom into tyranny. 
It is up to a heroic plumber named Mario to find all Starmen, 
become super and save the day! 

Along the way you'll be challenged by Goombas, Koopas and an endless array
of ruthless creatures who will stop at nothing to prevent you from finding the
8 Starmen of power. Please hurry up and rescue Peach!

Patch Legend of Zelda, The (U) (PRG0) [!].nes with one ips file. 

Version 1.2 from 2023-09-22 is an updated version that takes care of some minor bugs and issues. 

The (old version) from 2023-08-31 is still included in the zip file since it is beatable, a bit easier and for the sake of preservation. Complete list of changes in the changelog provided in the same link as the manual.   

Playtesters:
IceBlue
MetalMachine
ptux
ok impala!
Emptyeye
xavierbelmont
GoogieToons

Special thanks to MetalMachine for creating the Zelda Reloaded Maker.

RANDOMIZED VERSION
Soon there will be a randomized version available at Zelda Reloaded Retro. Keep an eye out for Zelda Reloaded Randomizer v2 as Randomizers will probably be available by October 2023 at https://www.reloadedretro.com/

Check the manual for more info and hints. 

ARTWORK AND MANUAL:
https://www.dropbox.com/scl/fo/hq1xvef5gds8hr2s4q002/h?rlkey=wvfwvcvxo5a7g2v9lk54qs71o&dl=1

