===============
1. Introduction
===============

Zelda: Ancient Dungeon is a completely new way to play the original The Legend of Zelda on NES.  This romhack makes The Legend of Zelda play like a roguelike.  Venture through a randomized, ever-changing dungeon with progressive difficulty the further you go.  Collect classic items and upgrades, and battle familiar foes throughout your journey.  Every playthrough is different.  Ganon is lurking deep within the dungeon, but beware, for if you perish, you'll have to start all over from the beginning.  Are you up to the challenge?

==================
2. Getting Started
==================

Zelda: Ancient Dungeon is distributed as an .ips patch.
Use your favorite patching program (I use Floating IPS) to apply the patch.
You must use the Rev-A (or PRG1) version of the Zelda ROM.

==============
3. How To Play
==============

The game takes place entirely inside the dungeon.  You begin each dungeon dive with your wood sword as well as arrows (but no bow to use them).  Every time you step through a door, you are presented with a new room layout and enemy arrangement, even if you backtrack.  Defeat all the enemies to open the doors, then proceed to the next room.  The rooms will contain more deadly enemy groups the further you go.

===========
4. Controls
===========

Zelda: Ancient Dungeon has the same familiar combat controls as the classic The Legend of Zelda, with only a few changes:
- The subscreen has been completely disabled.
- The Start button now pauses the game, instead of Select.
- The Select button cycles through your B button equipment, so any item swapping happens during active gameplay.

==========
5. Options
==========

At the start of every game, you can choose from several options from a menu:

Play Random:
This is the base game.  All rooms and enemies are generated randomly as you go, and if you die, the game is over.

Play Seed:
Choosing this selection lets you play a game based on a user-selected seed value.  Each seed has its rooms predetermined.  The only things that can vary in a seed are boss encounters as they are always determined at runtime.  This mode is designed for racing to give all players a similar experience.  Seeded mode also includes a continue feature where you can resume play from the last boss defeated.  Not only does this make races more interesting, but it also provides a more casual option where you don't have to worry about restarting all over.

Quest:
Choose from either a 1st Quest or 2nd Quest playthrough.  The 2nd Quest has many difficulty tweaks and changes that make the game much harder!

Music:
Select either the standard dungeon music, the overworld music, or no music at all.  Sound effects will still play if the music is turned off.

===================
6. Special Features
===================

Roguelike Gameplay:  Every playthrough is different and it is all included directly in the ROM file.  No external randomization programs needed, just load and play!

Dynamic Enemy Loading:  Normally the overworld and each dungeon have a specific set of enemies available.  In Ancient Dungeon, new enemies are loaded dynamically during every room transition.  This means there are no restrictions in the combinations of enemies you may encounter in the dungeon.

Room Generation:  New to version 3.0, now the dungeon room designs themselves are randomized!  They may be made up of pieces of existing rooms or with randomized blocks.  Care has been taken to ensure that all doorways and room items are reachable regardless of room arrangement.

Additional Item Abilities:  Some special items, like the raft, have no use in the dungeons and are not included in this hack.  However the items that are included may have some additional utility in this game.  See the items section below for more details on these changes.

In-game Timer:  A built-in timer keeps track of your playtime and is shown at the end of every run, win or lose.  Best times are saved when you win the Play Random mode!

Shops:  Periodically the old man will appear to sell you an item.  You can buy the item if you can afford it or abandon it there, but if you leave it, it's gone for the rest of the run.

========
7. Items
========

There are three kinds of items in Ancient Dungeon:
    1. Enemy drops:  These are the base items that you'll find a lot inside the Dungeon.  The drops are the same as the original game.
    2. Room drops:  Clearing a room will sometimes leave an item behind.  These can be the basic items or better, and occasionally you'll find a really nice item.
    3. Special items:  These can appear as a rare room drop, but most likely you'll find these after defeating a boss.

Most of the special items will only appear once per run.  Below is the item list.  Most behave the same way as the original game, but a few have additional new features.

Heart Container:  Adds one heart to Link's maximum health.

Blue Potion:  Can be used one time to refill Link's health.  There are two blue potions in the game and collecting both gives you a double-use Red Potion.

White Sword:  Deals twice as much damage to enemies as the Wood Sword you start with.

Magical Sword:  Deals four times the damage of the Wood Sword, or twice the White Sword.

Magical Shield:  This is a rare room drop only.  Can block stronger projectiles like swords and some fireballs.

Boomerang:  Used to defeat weak enemies or stun some stronger ones.

Magical Boomerang:  It has longer range than the standard boomerang.

Bow:  Can fire arrows across the screen.  Costs 1 rupee per arrow.  Link begins with arrows in Ancient Dungeon, you do not have to collect them separately.  Arrows deal twice as much damage as the Wood Sword.  Gohma may appear as a boss when Link has the bow.

Silver Arrow:  Does twice as much damage as regular arrows.  This is necessary to defeat Ganon and it will always be provided before the final battle.

Blue Candle:  Tosses a strong flame one time per room.  Not used to light up rooms.  The attack power has been buffed in Ancient Dungeon, now flames deal two damage instead of one, increasing by one point for each sword upgrade you collect.  This also applies to Link, so be careful!

Red Candle:  Unlike the Blue Candle, this can be used as much as you like, with the same attack power increase.

Blue Ring:  Enemy attacks deal 1/2 as much damage to Link.

Red Ring:  Enemy attacks deal 1/4 as much damage as Link, twice as strong as the Blue Ring.

Recorder:  This has multiple features, two completely new to Ancient Dungeon:
    1.  Allows Digdogger to appear as a boss.
    2.  The tune forces Peahats to land.
    3.  The tune defeats Pols Voice instantly.

Stepladder:  Allows Link to cross single water tiles.

Magical Rod:  Fires a wave of energy across the screen that hurts some enemies.  The wand itself can be used as a melee attack.

Magical Book:  Adds a flame to the end of the beam attack.  The attack power of the flame is buffed just like the Blue and Red Candles.

Key:  Appears as a room drop only.  Makes locked doors appear.  You can use the locked doors to skip a room without defeating all enemies first.  The more keys Link has, the more likely locked doors will appear.

======
8. FAQ
======

Q: If I pass up an item, can I find it again later?
A: Once a major item is encountered, it is removed from the item pool.  So if you leave an item behind from any room, including the shop item, it is gone for the rest of the run.  There are a few exceptions.  The Magical Shield is a rare drop and not part of the item pool, so while unlikely, you may see it more than once.  Also, the items needed to defeat Ganon are forced drops at the end of the game if you don't already have them.  Those items are specially handled to keep the shutters closed until you collect them so that you cannot accidentally leave them behind.

Q: What happens if I don't have the right equipment to fight a boss?
A: The game makes sure you have what you need to fight any boss.  For example, Gohma won't appear until after you get a Bow, and have enough rupees to fight it.  The way the boss logic works, typically once you get the item necessary for a boss, especially late in the game, that boss will show up right away anyway.

Q: What if I don't get the bow and/or silver arrow?  How can I defeat Ganon?
A: Both the Bow and Silver Arrow are given out as a forced room drop just before Ganon, no matter if you already encountered them in the dungeon already or not.

Q: Can I accidentally skip an item using a key?
A: No, key doors will not appear in rooms that drop a powerful item.

Q: Does this have an end?
A: Yes!  Zelda is waiting in Room 255.  And yes, that number was intentionally chosen.  :)

Q: Why aren't some enemies in the game?
A: Pretty much all Zelda 1 enemies in the original game that make sense to have are included somewhere in the dungeon, with a few notable exceptions:
    - Wallmasters:  I dislike the idea of them sending you back so many rooms if you get caught.  Plus, I don't like needing to sit against the wall to bait them out.
    - Spike Traps:  With the shutters locking you in, it's unfair to get spiked immediately entering a new room.

Q: Are there push block secrets in the game?
A: No

Q: Are there bombable walls, or walk-through walls?
A: No

=============
9. References
=============

Data Crystal Wiki:
Very useful resources here!
https://datacrystal.romhacking.net/wiki/The_Legend_of_Zelda

Disassembly by Aldo Núñez:
Absolutely essential to understanding everything about the game
https://github.com/aldonunez/zelda1-disassembly

=============
10. Changelog
=============

v3.1 - 2024/01/05

Added:
    - Added one final recovery option in seeded games
        - You can get full hearts and full bombs, in addition to the red potion, on further deaths

Changed:
    - The in-game timer was completely overhauled and is now much more accurate
        - Note: It is impossible to account for slowdown, but should otherwise be accurate

Fixed:
    - Fixed a bug in seeded games where the recovery potion could be placed out of reach
    - Fixed a bug on the timing of enemy graphics updates that caused a lag frame
    - Fixed a bug where the increased enemy counts near the end of the game was delayed by one room

-----------------------------------------------------------

v3.0 - 2023/08/09

Added:
    - New room generation algorithm
        - Room layouts can be made up of parts of existing rooms and/or purely randomized
        - Each palette color is assigned preferred settings used for generating the room
        - Rooms are guaranteed to have all exits and room item drops reachable
        - The pool of base rooms used in generation increases during play
    - Room drop locations are also randomized
        - Items will try to be placed in or near a corner, or in front of a doorway as a last resort
    - Fastest completion time is saved in random mode
        - Times are saved separately for both 1st and 2nd quests
        - Fastest time is displayed after completing the game
        - This does not apply to seeded games, only random games
    - New recovery method for seeded games
        - Each room is rated based on difficulty
        - Every time Link dies before completing the next boss, the room difficulty rating is added to a total
        - At a certain threshold, potions are given at the checkpoint to help
        - This should help aid progress if stuck in a seed
    - New peahat algorithm
        - Peahats are forced to land after a random number of checks
        - They still have a random chance to land like usual, increased from the original game
        - This prevents the rare runaway peahat that never seems to land
    - New shop text
        - The old man in the shop now has many more things to say
        - Many of these require meeting certain conditions or situations
        - There are 32 pieces of shop text total, see how many you can find!

Changed:
    - Doubled the scrolling speed between rooms
    - Removed flashing effects
        - Collecting the triforce after Ganon no longer flashes the room
        - Ending sequence with Zelda also bypasses full screen flashing
    - Existing rooms were modified to replace non-firing statues with solid blocks
    - Zelda's room was modified to be accessible from all doorways
        - As a result, Zelda no longer appears in the triforce room
    - Enemy spawn order is randomized for every room
        - This makes seeded games a bit more consistent
    - Global drop counter resets to 0 when starting a new game
    - Some optimizations were made to reduce lag in busy rooms
        - Existing logic to limit the number of enemies with projectiles has not been changed
    - Ganon's triforce graphics have been slightly altered
    - Zora underwater and Blue Leever underground palettes change depending on room palette to make them more visible
    - Quest and Music settings are now saved on the battery
    - The default seed on the options menu is more randomized
    - Fireball statues have a small, randomized delay before first firing
    - Flying Ghini begin moving in a random direction instead of always down

Fixed:
    - The in-game timer now caps at 9:59:59
    - Item swapping now works in doorways
    - Link's sword is restored after continuing from a checkpoint if it was locked by the red bubble
    - Enemy timers are reset before entering a new room
        - This fixes a bug where Ghini could start off flashing and unable to be defeated
        - There may be other rare interaction bugs fixed by this change as well
    - Defeating Ghini also defeats uninitialized Flying Ghini, as a workaround to the above bug fix
    - Fixed a bug where Goriyas would move while throwing a boomerang if an Armos was in the next enemy slot
    - Fixed a bug where Zora would stay in the room if all enemies were defeated but Link was standing on water with the stepladder
    - Fixed a bug in seeded games where losing the bow when loading a checkpoint would still display arrows in the B button box

-----------------------------------------------------------

v2.1 - 2023/03/31

Added:
    - Continue option on seeded games
        - Continue point is from the last boss defeated
        - Random games retain permadeath, can only continue from a seeded game

Changed:
    - Shop text speed greatly increased
    - For forced bow and silver arrow drops at the end of the game, the shutters stay closed until collected
    - In-game timer behavior tweaked to accomodate continuing in seeded games
    - Gleeok no longer appears before Room 32
    - Updated final credits screen to show quest, seed number, and death counter in seeded games

Fixed:
    - Fixed a bug that could cause shops to rarely or never appear

-----------------------------------------------------------

v2.0 - 2023/02/23

Added:
    - New options menu
        - Press Select to change rows, use the D-pad to update options on selected row
        - Menu items:
            - Play Random: Same mode as before, randomized throughout play
            - Play Seed: Choose a custom seed, perfect for racing!
            - Quest: Choose either 1st or 2nd quest, no more title screen code
            - Music: Play either normal dungeon music, overworld music, or turn music off
    - New internal RNG for better randomization in both random and seeded modes
    - Palette randomization
        - Dungeon color palette changes after every boss fight
        - Uses the light/dark screen transition to gently change room colors
        - There's a mix of traditional and custom palettes, 18 in total
    - New endgame sequence
        - Near the end of the game, change to Level 9 music and palette, with increased enemy counts
    - Item list is displayed at the end of a failed run
        - Items are shown in color if collected, grayscale if not collected or encountered
        - In a Random game, the full list of 16 is displayed
        - In a Seeded game, only the items encountered are shown, no spoilers!
            - NOTE: Dying in a room with an unseen special item drop will reveal that item
    - Added keys and key doors
        - Opening a key door lets Link advance to the next room without defeating all enemies
        - Keys have been added to the room drop pool
        - The more keys Link has, the more likely a key door will appear
        - Key doors not permitted in boss rooms, nor if there's a special room item
    - Added 5 unused rooms to room pool
        - 4 rooms have slight changes from vanilla game to make them work
        - 1 room (the weird moat room) has been redesigned

Changed:
    - Water rooms and fireball rooms are colored more appropriately
    - Sprite palette updated to make Blue Moblins and Zoras match overworld colors
        - This affects the colors of some other enemies and effects in minor ways
    - Item swapping allowed when the game is paused
    - Modified the square room to allow access to the center
    - Bosses are shuffled a little more aggressively in 2nd quest
    - Wand and Book not guaranteed to be progressive in 2nd quest
    - Statues will not fire at Link if he is holding up a new item
    - Shops are now enterable from above and Link is no longer blocked from the top of shops
        - NOTE: Link can take damage from the flames!  The shopkeeper deals no damage
    - Moldorm's room palette changed
    - Candle and Wand flame buffed, now does extra damage that scales up with Link's sword
        - NOTE: The extra damage also applies to Link!

Fixed:
    - Fixed a rare bug where you could continue the game after defeat with a frame perfect Start press
    - Fixed some rare softlock situations with the clock item
    - Zora will now leave the room if item drops (and/or bubbles) are present

-----------------------------------------------------------

v1.1 - 2022/12/26

Added:
    - Version numbering appears on the title screen
    - Fast/Dark Keese added to 2nd Quest, replacing regular Keese in the enemy pool

Changed: 
    - Peahats are more likely to land
    - Updated forced item rooms at the end of the game: Bow in 251, Silver Arrow in 252, Rupee in 253
    - The default boss is only circle Patra
    - Patras are now progressive in the boss pool, oval Patra before circle Patra
    - 2nd Quest Changes:
        - Boss and Item shuffles use 1st Quest logic
        - Red Ring, Magical Sword, and Silver Arrows are replaced with Heart Containers in the item pool (Silver Arrows are still a forced drop at the end)
        - Updated shop pricing algorithm

Fixed:
    - Gleeok no longer appears in the square room, the square water room, or either fireball room
    - Zora now leaves the room properly if only bubbles are present
    - Room items no longer flicker if left behind
    - The in-game timer now runs when the game is paused

-----------------------------------------------------------

v1.0 - 2022/12/08

Initial Version