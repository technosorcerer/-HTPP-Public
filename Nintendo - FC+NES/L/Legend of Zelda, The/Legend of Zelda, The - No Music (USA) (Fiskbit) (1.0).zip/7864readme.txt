This mod removes the background music in The Legend of Zelda. Thank you very much to Fiskbit from the ZeldaOne Discord server for making these patches and giving Readmit permission to upload them here.

Inside the folder called Extras, there are 2 patches: Zelda No Music PRG0.ips and Zelda No Music PRG1.ips, as well as the original .asm files that provide descriptions for each patch.

These are Readmit's findings after having tested the patches: For roms labeled PRG0 or 1.0, the PRG0.ips patch works fine, and it is also compatible with the Legend of Zelda Redux (the Patcher64+ tool is the most user-friendly way to make a redux rom), just make sure to apply the No Music patch after applying the redux and not before. For roms labeled PRG1 or 1.1, both the PRG0.ips and PRG1.ips patches work, however, the PRG1.ips mod is not compatible with the redux, but the PRG0.ips is. In conclusion, you can make a PRG0 (1.0), or PRG1 (1.1) No Music rom, you can combine the No Music patch with the redux, so long as you run the No Music patch after applying the redux, and the PRG0.ips patch can make a 1.1 redux rom into a 1.1 redux + No Music rom, but the PRG1.ips patch won't be able to do so.

This mod is compatible on both emulator and original hardware.

Please also visit Readmit's user page for other No-Music hacks.
https://www.romhacking.net/community/8095/