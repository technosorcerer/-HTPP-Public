This is a patch for "Lion King 5/6", which removes the terrifying game over animations, such as Simba hanging himself.

This patch will only work if you have these roms:
"Lion King 5, The - Timon & Pumbaa (Asia) (En) (Pirate).nes"
"Lion King 6, The - Timon & Pumbaa (Asia) (En) (Pirate).nes"