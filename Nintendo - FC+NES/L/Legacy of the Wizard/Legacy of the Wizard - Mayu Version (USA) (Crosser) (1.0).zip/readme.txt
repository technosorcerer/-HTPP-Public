			
Dragon Slayer IV / Legacy of The Wizard

		Mayu Edition

by: Crosser
9-30-2025

Overview:

This is a simple graphics hack of the Falcom developed Famicom / NES game Legacy of
the Wizard / Dragon Slayer IV - Drasle Family that replaces the family dog /
monster character Pochi with the cat girl monster Mayu, This hack also removes
the son / Ranger Roas' helmet to better match the other early Dragon Slayer 
protagonists as well as his official artwork on the box and manual. This hack 
should also be compatible with most others for this game as well.

Please apply the patch file as listed below using an IPS patcher such as lunarIPS:
-Drasle4 Mayu ver.ips ... Dragon Slayer IV - Drasle Family (japan).nes
-LOTW Mayu ver.ips ... Legacy of The Wizard (USA).nes

Changes:
-Edited dog sprites to a cat to match Mayu's catlike appearance, including
the ending sequence.
-New sprites for Mayu jumping, falling, dying, and dying.
-Edited Roas (Royas) sprites to better match other Drasle games and official art.

Disclaimer:

This patch is not for sale or reproduction. If I would not pay for this thing,
then why should you? If you have paid for it, then you have been duped, my friend.

If you wish to use this hack in another project, please give credit to the author.

Credits:

Author - Crosser (please email any bugs or errors to cjd5673@gmail.com)
Original Game - Falcom
Published by - Namcot / Bandai Namco
Special Thanks - cmdrsho for the inspiration (please check out their yt at
https://www.youtube.com/@cmdrsho if interested in more Drasle 4).