Removes pulsing in the title screen. Removes flashing after picking up a cross, after selecting a character, after entering a boss area, after a boss dies, and after exiting a boss area.


----------------------------

Details of changes made:

1AF02: 8D0182 -> EAEAEA : removes pulsing in the title screen

1C543: 30 -> 0F : removes flashing after picking up a cross

1C546: 9D8001 -> EAEAEA : removes flashing after selecting a character, entering a boss area, after a boss dies, and exiting a boss area