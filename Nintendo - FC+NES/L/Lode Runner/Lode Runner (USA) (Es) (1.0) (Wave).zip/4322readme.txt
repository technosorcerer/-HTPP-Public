Lode Runner (NES)
Traducci�n al Espa�ol v1.0 (16/03/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Lode Runner (U) [!].nes
MD5: 8e074813a094594c29c1d4c43e4bdbc5
SHA1: ea09aec11efc4b42ebc644ea243c2284001fe34f
CRC32: cd4bf911
24.592 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --