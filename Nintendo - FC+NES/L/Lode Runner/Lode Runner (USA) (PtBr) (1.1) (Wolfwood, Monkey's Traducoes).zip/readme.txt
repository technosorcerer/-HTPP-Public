---------------------- Informa��es ----------------------

Nome do jogo: Lode Runner (U).
Plataforma: Nintendo Enternament System.
G�nero: Estrat�gia / Plataforma.
Vers�o da Rom: Americana (U).
CRC32: CD4BF911.
Lan�amento da Patch 1.1: 02 de Julho de 2009.
Status: 100%
Grupo de Tradu��o: Monkey's Tradu��es.
Respons�vel: Wolfwood.
E-mail: ikkidefenixalemao_@hotmail.com

---------------------- Inserindo o Patch ----------------------

Leia a seguinte documenta��o:
http://www.romhacking.trd.br/index.php?topic=5095.0