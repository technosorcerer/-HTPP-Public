---------------------- Informa��es ----------------------

Nome do jogo: Lode Runner.
Plataforma: Nintendo Enternament System.
G�nero: Estrat�gia.
Desenvolvedor: Douglas E. Smith.
Distribuidor: Br�derbund & Ariolasoft.
Vers�o da Rom: Americana (U).
CRC32: CD4BF911.
Lan�amento da Patch 1.0: 22 de Fevereiro de 2009.
Status: 99%
Grupo de Tradu��o: Monkey's Tradu��es.
E-mail: ikkidefenixalemao_@hotmail.com

---------------------- Como inserir o arquivo IPS na ROM original ----------------------
Itens:
 -O arquivo .exe que veio junto com este arquivo.
 - ROM Original.
***************************************
O que fazer:
*Abra o arquivo .exe.
*V� em Browse.
*Selecione a ROM Original.

Pronto! o seu jogo vai estar traduzido.
Para jog�-lo, basta ter um Emulador de Nintendo 8 Bits(NES.).

---------------------- Observa��es ----------------------

Conheci o jogo ontem, traduzi hoje, e estou lan�ando hoje tamb�m. LOL
Tudo foi traduzido, existem algumas "gambiarras" feias no jogo, mas fiz o que pude para deixar o melhor poss�vel. Se n�o gostaram, v�o jogar em ingl�s.

---------------------- Agradecimentos----------------------

*Minha m�e - COEH! Sem ela eu n�o estaria aqui, entregando essa tradu��o para voc�s. XD
*#Dandy-BR - Serviu de Beta-Tester.
*Marvin Dalkiri - Por ter esperado eu lan�ar a tradu. lol
*Meu amigo Felipe(aka Harry.), que me mostrou o jogo, traduzi em sua homenagem, um grande amigo de inf�ncia.
*Minha ex, que ainda amo, apesar de... melhor nem falar nada. Mais eu ainda amo ela, de qualquer forma! (Espero que ela n�o veja isso.)
*Membros da Monkey's Tradu��es.
*Membros e Colegas do FUT(F�rum Unificado de ROMHacking e Tradu��o.).
E todos aqueles que gostaram da tradu��o.