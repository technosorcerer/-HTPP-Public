---------------------- Informa��es ----------------------

Nome do jogo: Lode Runner Kai (Hack).
Plataforma: Nintendo Enternament System.
G�nero: Estrat�gia / Plataforma.
Vers�o da Rom: Japonesa (J).
CRC32: 807B77F5.
Lan�amento da Patch 1.1: 02 de Julho de 2009.
Status: 100%
Grupo de Tradu��o: Monkey's Tradu��es.
Respons�vel: Wolfwood.
E-mail: ikkidefenixalemao_@hotmail.com

---------------------- Observa��es ----------------------

O patch � para ser inserido na ROM: Lode Runner (J).

---------------------- Inserindo o Patch ----------------------

Leia a seguinte documenta��o:
http://www.romhacking.trd.br/index.php?topic=5095.0