War on Wheels (NES)
Traducción al Español v1.0 (12/06/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
War on Wheels (USA) (Proto).nes
MD5: 78f32910637e57790f2c11714980fc5e
SHA1: 0ad7a3c76760cdc053bf2bf5ae053fa820bd254b
CRC32: c957dcb0
393232 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --