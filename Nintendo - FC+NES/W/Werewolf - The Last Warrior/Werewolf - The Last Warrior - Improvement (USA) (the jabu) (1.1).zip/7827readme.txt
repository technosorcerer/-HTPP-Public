       Werewolf - The Last Warrior Improvement V 1.1/ hack by The Jabu  2023
      ---------------------------------------------------------------------
        This hack was created to make the game less frustrating,A and B button has been swapped ,
        so now B is attack and A is jump, adjusting a little bit the the way  you control the 
        Werewolf, and changing the moment that some enemies appears, making them less annoying.
   

    Changes:


     - A and B buttons has been swapped , so now B is attack and A is jump.
  
     - You can do the super jump while walking.

     - To jump away from walls press the d-pad on the opposite direction of the wall you are climbing.

     - Now is easier to grab onto the ceilings.

     - Now you can move faster while hanging from the ceilings.

     - Now the werewolf's special attack you can do it only if your first life bar is full.

     - While on Werewolf form, if your life is less than 4 points,you will return to human form.

     - Now you got more invulnerability time after been hit.

     - changing the moment that some enemies appears on the screen.

     - Added the missing tiles of the final boss.

     
   V 1.1:

     - Press SELECT to transform into Super Werewolf (you need 5 orbs). You can cancel the
       transformation by pressing SELECT again.

     - The alarm sound on level 3 has been changed to the default music track.
       
     - Some levels have minor changes to balance the difficulty.
      

  

  


  Apply the IPS file to "Werewolf - The Last Warrior (U).nes" and have fun!!!

    

   