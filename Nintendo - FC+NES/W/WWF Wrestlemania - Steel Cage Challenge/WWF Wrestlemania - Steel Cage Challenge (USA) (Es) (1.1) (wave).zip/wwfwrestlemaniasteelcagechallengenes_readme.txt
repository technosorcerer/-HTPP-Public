WWF Wrestlemania Steel Cage Challenge (NES)
Traducción al Español v1.1 (05/02/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
v1.1:Arreglado bug aleatorio en combate.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
WWF Wrestlemania Steel Cage Challenge (USA).nes
MD5: e158896b7f44d83096fd1051d9558795
SHA1: 12e3489a5242c1fb67479046056e87efda056abd
CRC32: 0b436108
393232 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --