Wild Gunman (NES)
Traducci�n al Espa�ol v1.0 (23/03/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Wild Gunman (U) (PRG0) [!].nes
MD5: 9c3b8be45a37c945c39c1f009fc7eb81
SHA1: de63926d0a4c81cc21c89120d82130584cf5326a
CRC32: daa4236c
24.592 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --