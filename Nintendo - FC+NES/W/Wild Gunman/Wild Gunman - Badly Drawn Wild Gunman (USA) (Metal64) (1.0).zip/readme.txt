Hack Name: Badly Drawn Wild Gunman

A Hack Of: Wild Gunman (Japan, USA)

Hacked By: Metal64

Youtube channel: https://www.youtube.com/user/MetalOverlord64

2 Youtube channel: https://www.youtube.com/channel/UCPVhjP2tmdRVpqfD5TOymKA


About the hack

I just redraw all the sprites of this game as badly as I could