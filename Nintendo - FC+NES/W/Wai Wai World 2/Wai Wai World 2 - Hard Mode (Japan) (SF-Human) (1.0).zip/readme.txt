Wai Wai World 2 - Hard Mode patch

This hack enables the anti-piracy mode by default (which features more enemies in platforming levels), but you will no longer being thrown back to World 3 after completing World 8. The scrolling speed in the autoscrollers of World 1 and 5 are also doubled to make them more challanging. 

Patch it on a clean Wai Wai World 2 ROM and you're done. 

Filename: Wai Wai World 2 - SOS!! Paseri Jou (J) [!].nes
CRC-32: ebd96a66
SHA-1: b02e31bf773cec8e01a105ebe552d1e1d3a4d7da

SF-Human