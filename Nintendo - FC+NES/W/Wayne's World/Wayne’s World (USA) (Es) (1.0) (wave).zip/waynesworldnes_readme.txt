Wayne's World (NES)
Traducción al Español v1.0 (11/03/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Wayne's World (USA).nes
MD5: 9ee4505180745223c0f90f6ebebbe561
SHA1: 7363720e0bc3eb2e138df9d11e816a7176705efc
CRC32: 9a5e089d
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --