~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
~---- Wanpaku Kokkun no Gourmet World With US+EU Character Graphics ----~
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Patch version: v1.0

Author: Riggles

Date: 2024-01-11

--- About ---------------------------------------------------------------

This patch replaces the Japanese graphics for Chef Cookie with the 
mustachioed gentleman seen in the NTSC-U and PAL Region 
releases of the game. Other graphical differences remain untouched.

Other than the main character the Japanese version has other differences
such as stage layouts.

--- Patching Instructions -----------------------------------------------

Either apply this patch to an untouched Japanese ROM, or apply it to a 
ROM that's had the v1.01 English translation patch by Stardust Crusaders 
applied to it already.

Lunar IPS can be used to apply the patch.

--- Base ROMs confirmed to work with the translation and this -----------

Wanpaku Kokkun no Gourmet World (Japan).nes (No-Intro Headered)
CRC32: 6ED1B405
MD5: ECE980EA03B0C1C2B0E83DD611A832A2
SHA-1: 66F413D2E95C096AB9AA43F9F0559E3BE27C58BF

Wanpaku Kokkun no Gourmet World (J).nes (Headered)
CRC32: FFFB5EAD
MD5: 29DA48E6A9BEF7131233CEC0EEB43A01
SHA-1: 7124B65B810A4E817B9401AA08CD7E8C5CB3029E

--- Tools ---------------------------------------------------------------

Tile Layer Pro, developed by SnowBro/Kent Hansen.

--- Thanks --------------------------------------------------------------
  
Stardust Crusaders/Pennywise for the English Translation.  
Zipplet for playtesting.