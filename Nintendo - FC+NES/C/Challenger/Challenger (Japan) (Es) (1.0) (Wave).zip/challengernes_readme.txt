Challenger (NES)
Traducción al Español v1.0 (28/01/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Challenger (Japan).nes
MD5: 835ecf22f6c5d1d80d5aa1dc57410009
SHA1: accea2ec5216ec05090c2d15d3f373eb4a41472b
CRC32: 94339dff
40976 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --