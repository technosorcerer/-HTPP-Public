City Trouble - Better Sprites Hack
by Pineapplefish
v1.0

--How to Use--
Apply IPS patch to original ROM using appropriate program, such as Flips or the Romhacking.net online patching utility.

--About--

City Trouble is a 41k NROM NES game by Den Kat Games, published in 2017 by Mega Cat Studios. The game is consistently fun to play and uses Kung Fu as its main inspiration (aka Kung Fu Master) while incoporating more jumping action. It was made freeware on December 31st, 2018.

Its visual design is overall competent, with solid character design and great backgrounds. My aim was simply to enhance what was already there.

My objectives:
- improve visual clarity;
- add more individuality and expressiveness to the characters.

This hack is strictly an exercise in pixel-pushing. No code modification was done.

<May 16th 2024>
Initial release

City Trouble official homepage:
http://www.denny-r-walter.de/city.html

City Trouble, by Denny R. Walter
Original graphics by Katrin Kaisel

