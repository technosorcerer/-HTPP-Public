ICE Trans
http://icetrans.emuviews.com
Rom Translations & Hacks
Copyright 2000 

Well here is ICE Trans' first 100% patch in a while. This game is a crazy shooter so go and try it out. Sanity was kept 
during hacking & beta testing by the sweet beats of Hardknox(Hardknox), Fatboy Slim(On The Floor Of The Big Beat Boutique), 
Prodigy(Experiences), and Orbital(The Middle Of Nowhere). Grab the Rom for the site if you need it. That is all.


CHUKA TAISEN  - 100% Complete Final Patch
----------------------------------------------------
- Everything is complete except for the vases but I think it looks better the way they are so that's why I left them.


CREDITS
--------

TEXT         - iceman X
GRAPHICS     - iceman X, crazyahmed
TRANSLATIONS - Zackman, Mo
BETA TESTING - me(icemanX), apolo