Castelian Palette Fix by Dwedit (2024-06-01)
This removes all use of the forbidden color 0D (Blacker than Black) from the game, replacing it with normal black 0F.
Use of the forbidden 0D color causes sync problems on some TVs.