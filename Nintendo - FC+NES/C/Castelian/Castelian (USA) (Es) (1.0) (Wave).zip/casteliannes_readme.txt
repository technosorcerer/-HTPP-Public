Castelian (NES)
Traducci�n al Espa�ol v1.0 (29/12/2018)
(C) 2018 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Castelian (U) [!].nes
MD5: 2e0d9726ba9e69fe548fb1924d3db2f9
SHA1: 3def6ccb01b4e571939d57bd65658db27da71d4f
CRC32: 39ef1ad6
131.088 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --