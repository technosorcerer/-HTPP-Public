Cybernoid - The Fighting Machine (NES)
Traducci�n al Espa�ol v1.0 (22/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Cybernoid - The Fighting Machine (U) [!].nes
MD5: d92b83dc05a5addbd1c0afde2126ce8f
SHA1: 7310c85d5abadf9ce2e0bc830e2b4b9c2121b24c
CRC32: e3a6d7f6
65.552 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --