Championship Bowling (Brunswick Bowling Edition)

This is just a simple hack that adds the Brunswick Bowling Logo onto the US version of Championship Bowling as the Japan version has Athena on the pinsetter.

I've thought of this as Rom Star never added their logo on the US Version as it's the same game but it looked boring as it was plain.