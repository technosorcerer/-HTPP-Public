Choujikuu Yousai - Macross (NES)
Traducción al Español v1.1 (14/11/2021)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1:Arreglado "ALTA-MARCA" al llegar a los 100.000 puntos.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Choujikuu Yousai - Macross (Japan).nes
MD5: 9540cf70c91352a80b5e067bceada717
SHA1: e653510ae99433a13dbb7db019a5cdb51766dc73
CRC32: a3ca24d2
24592 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --