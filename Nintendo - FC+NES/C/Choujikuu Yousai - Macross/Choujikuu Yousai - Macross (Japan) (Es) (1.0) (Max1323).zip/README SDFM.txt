"Choujikuu Yousai Macross" o "The Super Dimension Fortress Macross"
Traducci�n al Espa�ol Ver. 1.0 (05/06/2018)
por Max1323 (maxmuruchi@gmail.com)
---------------------------------------------------
Descripci�n:
Basado en el anime de "The Super Dimension Fortress Macross"
o mejor conocido afuera de Jap�n como "Robotech". 
El juego es un shoot'em up, donde controlas al VF-1 Valkyrie 
en una interminable batalla contra los Zentradi.
Durante el juego puedes transformar al Valkyrie:
Bot�n A + Arriba = GERWALK mode
Bot�n A + Atr�s  = Battroid mode
Bot�n A + Adelante = Fighter mode
Bot�n Select = Multiples misiles
Desarrollado por Namco
Distribuido por Bandai
Lanzamiento 10 Diciembre 1985 (Solo en Jap�n)
---------------------------------------------------
Acerca del proyecto:
Eran poco los textos y estaba en ingl�s.
Faltaban palabras como "J, Q y Z"
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS

Choujikuu Yousai - Macross (J).nes
File MD5   F8534E279B4FBDF10F17646122410BAB        
File SHA-1 8041C67ED01CC49C6DD6FF28C28F046A7DFDBD86
File CRC32 6761553A                                
Tama�o     25 KB   




