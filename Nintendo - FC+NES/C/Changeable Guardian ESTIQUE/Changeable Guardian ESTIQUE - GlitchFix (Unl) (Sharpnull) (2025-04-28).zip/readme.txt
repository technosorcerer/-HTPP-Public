Changeable Guardian ESTIQUE (World) (NTSC) (Aftermarket) (Unl).nes
-------------*-----------------------------------------
              NES 2.0
 4E 45 53 1A 10 20 40 08 00 00 07 00 00 00 00 01 
-------------*-----------------------------------------
Mapper Number: 4 = Nintendo TxROM/HKROM (MMC3)
PRG ROM  Size:   256 KiB =   262144 B
CHR ROM  Size:   256 KiB =   262144 B
Mirroring    : Horizontal
4-screen VRAM: No
Battery      : No
Trainer      : No
Console Type : NES/Famicom/Dendy (#0)
TV system    : N/A
PRG RAM  Size: N/A
-------------*-----------------------------------------
Submapper    : 0
PRG RAM  Size:     8 KiB =     8192 B
CHR RAM  Size:     0 KiB =        0 B
PRG Save Size:     0 KiB =        0 B
CHR Save Size:     0 KiB =        0 B
Frame Timing : NTSC (#0)
Console Ext. : N/A
VS PPU       : N/A
VS Type      : N/A
Misc ROMs    : 0
Expansion    : Standard Controllers (#1)
-------------*-----------------------------------------
File    CRC32: 6944469B | Size: 524304
        MD5  : 910ABB1381C273494A7E043824D4C08B
        SHA-1: C70DC38D88E58062D84C5E8AF86F7FAC6C20A65C
-------------*-----------------------------------------
ROM     CRC32: 2AB4A36D | Size: 524288
        MD5  : 9AB861FE5B28F0CE9D05D2030C934D99
        SHA-1: D33DA6C44B09C959D509845600FBAEE7AF11E776
-------------*-----------------------------------------
PRG ROM CRC32: 9A07779F | Size: 262144
        MD5  : D16B4BCEEF9DA14956AF297229FCD288
        SHA-1: E2349D3B07B88E522BE7346A7B18A3122E4379DE
-------------*-----------------------------------------
CHR ROM CRC32: B4010888 | Size: 262144
        MD5  : 5987457D4A08B016CA8FC34E11D761B7
        SHA-1: FC67B849B04F6C30C097930E26975DA4F806F264
