Casino Kid II (NES)
Traducción al Español v1.0 (31/10/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Casino Kid II (USA).nes
MD5: f0fc1494f7094fc7b0b250cf26a51625
SHA1: 1e3fae5258ff1206527f7f4278f29ce2be198234
CRC32: b0de7b5f
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --