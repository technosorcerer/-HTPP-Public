Cabal (NES)
Traducci�n al Espa�ol v1.0 (14/05/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Cabal (U) [!].nes
MD5: c75cf9d1f0aac7343be5ef0e03c98795
SHA1: 2ca85d4d144a9c61bc9e14580b66ebcc68b7dab9
CRC32: 4d5f2eb0
131.088 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --