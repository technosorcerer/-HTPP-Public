Cowboy Kid
Terjemah Bahasa Indonesia oleh Rue
Patch v2.0


Deskripsi:
----------
Terjemahan Bahasa Indonesia lengkap dari Cowboy Kid untuk Nintendo Entertainment System (NES). Semua teks dialog dalam permain ini telah diterjemahkan sepenuhnya, dan beberapa bagian grafis hanya sedikit diterjemahkan.

Terdapat dua file patch dalam berkas ini, pilih salah satu patch antara format ips atau bps. Bagi pengguna Android untuk menerapkan filenya ke dalam ROM bisa mengggunakan UniPatcher atau bisa juga menggunakan ROM Patcher, lalu untuk PC bisa gunakan Lunar IPS, Beat, Floating IPS dan sebagainya. 




Kendali:
--------
Tombol D-pad untuk berjalan
Tombol A untuk melompat
Tombol B untuk menyerang
Tombol START untuk jeda permainan
Tombol SELECT untuk ganti senjata


Berkas dalam ZIP:
-----------------
1. CowboyKid(ID).txt
2. CowboyKid2.0(ID).ips
3. CowboyKidv2.0(ID).bps



Informasi ROM:
--------------
No-Intro Name: 
Cowboy Kid (USA).nes 

File SHA-1:
3F12E2AC5E074E7970735D896331BB7E5EF5BB73
ROM SHA-1:
FBF9CFC78A76F27E537E585BDF08DF389F57E8E9
File CRC32:B150AE9A
ROM CRC32:D18E6BE3




Kontak
------
Apabila ada typo, bug dan semacamnya bisa langsung hubungi saya ke:
https://retro-nesgb.blogspot.com/p/kontak.html
