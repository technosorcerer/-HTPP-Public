 .==================.
( CYCLE RACE ROADMAN )
 '=================='

Full english translation.
The game was already in english except a few things:
-Title screen
-Town name on arrival screen

This patch must be applied on the NO-INTRO ROM:

Cycle Race - Road Man (Japan).nes
CRC32: 468D1A2E
MD5: 90A0BC783FBE56748989D8FAD9AE48ED
SHA-1: 3CDFCFB1A88D0CBFEB1C7B12751409FAF69BBA02
SHA-256: 5D8520EE6DEA9A6A07C4329B39E3E51CE4B479AEFF357270505222655B405A09

Staff:
FlashPV: Hacking, graphic work

Version history:

V 1.0: Final Release