This is a Ninja Gaiden themed romhack of Color a Dinosaur. 

All dinosaurs have been replaced with custom images from the Ninja Gaiden community that are fully color-able. Two bonus memes included!

Shoutouts to Beerfullofbelly and Rufford for the idea.

Simply apply the included ips patch to the original Color a Dinosaur ROM. You can apply this ips patch with a tool like LunarIps. 

Happy coloring! :)