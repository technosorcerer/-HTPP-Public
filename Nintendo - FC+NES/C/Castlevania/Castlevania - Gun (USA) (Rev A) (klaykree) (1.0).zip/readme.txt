I can not defeat this game:
The whip is replaced by a gun weapon, all subweapons remain.

One bullet may be on screen at a time.
Simon is able to 'pisol whip' secret wall blocks.

Small graphical changes to Simon to reflect new weapon.

There are no other changes.


Thanks to:
 - NES development forums and tutorials
 - Sites with 6502 instruction set information
 - Developers of FCEUX
 - Optomon for their 'Castlevania Enemy Data' document
 - wiki.nesdev.com