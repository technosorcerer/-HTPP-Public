
Castlevania - Localization Fix
-------------------------------------------------------


By spiffy (http://www.romhacking.net/community/3923/)


This patch simply alters the graphics in the end credit sequence to read 'Simon Belmont' (his official English name) instead of 'Simon Belmondo', his official Japanese name.

Included are patches for all four regional releases of the game on the NES:

- Japanese NTSC 'Akumajou Dracula' (CRC32:93F0488C)
- Original American NTSC or PRG0 (CRC32:39C879BB)
- Revised American NTSC or PRG1 (CRC32:856114C8
- European PAL (CRC32:9A3CF4D6)

As an added bonus (more of a curiosity if anything else), I've also included a special variant of the patch (one for each region) that not only changes 'Belmont' to 'Belmondo', but also updates several of the enemy names in the end credits to their current and slightly more accurate English translations:

- Frankenstein -> Franken (since at least CV3)
- Hunch Back -> Flea Man
- Armor -> Armor Knight

...so there's that, if you're really interested.


Changelog & Updates
---------------------

- v1.0 - initial release (13/2/2018)


How to Apply
--------------

Select the IPS patch you wish to use and then apply it to a corresponding clean rom of whichever regional variant of Castlevania you possess using any IPS patching utility (e.g. Lunar IPS - https://www.romhacking.net/utilities/240/). CRC32 checksums are outlined in the intro above.


Acknowledgements & Special Thanks
-----------------------------------

- Dan (http://www.romhacking.net/community/487/) for their comprehensive 'Stake' CV1 NES editor (http://www.romhacking.net/utilities/247/)


Copyrights
-----------

Akumajou Densetsu, Castlevania, and all other names are trademarked to Konami of Japan.

