This hack is great to test your Rom and toy around. Have fun!

	If you like to make changes the source Code is there. Put a PRG1 Castlevania ROM in the ROM folder. 
	Name the ROM CastlevaniaPRG1.nes so the PatchMain.bat will find it. When double clicking the bat file
	it will run all the asm file listed in the main asm file.


			Functions
			
			TitleScreen:	
			Start will lunch the game normaly
			Press Select to choose a sections. B or A to run it.
			Left and Right will alternate bettween second and first quest
			
			PlayMode When game is paused:
			Right will give/Take whip upgrade
			Up will give/Take you MultiShot
			Down will give you next Subweapon
			Left Increade health and loop
			
			Hold A+Right will move sprite right
			Hold A+Down will move sprite down
			Hold B+Right will fully Fill heart (!!Visual is Bugged till you use or get heart)
			Hold B+Left incincable
			Hold start + select + B Will Reset
			
						
						This hack was done by bogaabogaa
						More infos about hacking are in my discord