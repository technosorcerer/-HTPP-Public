NewVersion:
	This hack is for speedrunners. 
		Features:
			In game menu when pressing START (pause)
			
			- reset to beginning of the current level
			- level Select 
			- game mode
				- 00 "off" (no mods are loaded)
				- 01 "scroll gl" glitch practice (fundamentals: https://docs.google.com/document/d/1vlOruABkiWSLGQA5we1cPI0VDxqRrCMcJGgQWCriD2I/edit)
				- 02 "timer fra" (framecounter does also lag with the game)
				- 03 "pos viewer" shows xPos and yPos of the player
				- 04 "loop mode" does save gear and cam options to SRAM and reload as you spawn
				- 05 "stair fnd" does find stairs and displays them on screen. Room color encoded 
				- 06 "beer" does make you jump to the top of the screen when pressing select
				- 07 "map sta" select goes to map. Pressing up/down tries to put simon in stairmode. (likely to crash the game)
				- 08 "zoom fa" does fack scroll to show the whole nametable. Press hold select.
				- 09 "door find" will display doors as the stairs before	
			
			- give all (refill everything)
			- game loop (switch first and second quest)
			- slow motion (lags the game to observe what is going on)
			- color mode (set itensivite color or black/white)
			- give items..
			- place holder will load some sound when pressing B and exit the menu
			
			
			clear SRAM:
			- Holding A and B at titlescreen. Will reload the code to SRAM that could be damaged after a crash

OldVersion:

This hack is great to test your Rom and toy around. Have fun!

	If you like to make changes the source Code is there. Put a PRG1 Castlevania ROM in the ROM folder. 
	Name the ROM CastlevaniaPRG1.nes so the PatchMain.bat will find it. When double clicking the bat file
	it will run all the asm file listed in the main asm file.


			Functions
			
			TitleScreen:	
			Start will lunch the game normaly
			Press Select to choose a sections. B or A to run it.
			Left and Right will alternate bettween second and first quest
			
			PlayMode When game is paused:
			Right will give/Take whip upgrade
			Up will give/Take you MultiShot
			Down will give you next Subweapon
			Left Increade health and loop
			
			Hold A+Right will move sprite right
			Hold A+Down will move sprite down
			Hold B+Right will fully Fill heart (!!Visual is Bugged till you use or get heart)
			Hold B+Left incincable
			Hold start + select + B Will Reset
			
						
						This hack was done by bogaabogaa
						More infos about hacking are in my discord