Castlevania - Random Weapon Drop Hack by magusRE
----------------------------------------
This Hack randomize the Weapon Drops on Candles, including Candles which usually drop a Large Heart, 400/700 Money Bags. 400/700 Money Bags are excluded from the random drop.

Whats included as random drop:
- Large Heart
- Dagger
- Throwing Cross
- Holy Water
- Axe
- Holy Cross
- Invisibility Potion
- Watch (Time Stop)
- Double/Triple Shot

1.1:
- Crash fix when entering a door while using Invisibility Potion
- Removed the white flashing on the character while using Invisibility Potion to prevent graphic glitches

--------------------
Required ROM:
--------------------
Database match: Castlevania (USA) (Rev 1)
Database: No-Intro: Nintendo Entertainment System (v. 20210216-231042)
File SHA-1: 4E3EF47DE86A941C37359BB3ACFA5542A0FA7876
File CRC32: 12A6CB14
ROM SHA-1: 3DCB69A8C861C041AEB56C04E39ADF6D332EDA3A
ROM CRC32: B668C7FC

--------------------
Thanks and Credits:
--------------------
www.romhacking.net