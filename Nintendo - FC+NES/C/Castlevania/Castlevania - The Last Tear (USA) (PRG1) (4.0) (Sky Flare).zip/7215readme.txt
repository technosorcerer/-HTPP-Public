/////////////////////////////////////////////////////////////////////////////
######################## Castlevania - The Last Tear ########################

//// The Trilogy (1 by 3) ////

by SkyFlare 2022 - 2023

————————————————————————————————————————————

Updated Ver. 4.0_DEFINITIVE!!!

With this important update, many things have changed, in a correct,
more enjoyable and above all very well looked after way!!
And finally, in this case the Trilogy "The Last" begins!!

Credit goes to IDarkReaderW for the strict
overall supervision and some well-arranged graphics!!!

- Also attached file IPS: "TLT_Definitive (PAL SIMON)
(...for those who love Simon's palettes like the original!!...) ^_^

- Also attached file.PAL: ACCURATE PAL, to load on your emulator (FCEUX)
for a perfect color profile of this game!!
Example if you can't see very dark gray (which will make black)...

——————————————————————————————————————————————————————————————————————————

Hope you enjoy this game
I put my heart and soul into it with passion to make it happen
this project...
without anyone's help :(

When it comes to graphics; few told me that
are "too dark" and contrasted ...
But in fact I've been putting a lot of care into it for a long time
this graphics on purpose "gothic" style...
I've always put my heart and soul into it too!!

In fact, I had two first recommendations "NO"
and it seemed strange to me...
It is probably due to this case, few (I don't know)
prefer simple graphics...

Fake candles (Raven behavior) are made for it
for a new thing; in perfect location...
just have a little calm and attention while relaxing, many said
which are very annoying ... in fact they are, but not exaggeratedly!

———————————————————————————————————————————————————————————————————————————

--->>> IDarkReaderW's GALLERY: <<<---

https://www.deviantart.com/idarkreaderw

———————————————————————————————————————————————————————————

Let us know, and if you want to contact me
Discord: SkyFlare#2933

SkyFlare

