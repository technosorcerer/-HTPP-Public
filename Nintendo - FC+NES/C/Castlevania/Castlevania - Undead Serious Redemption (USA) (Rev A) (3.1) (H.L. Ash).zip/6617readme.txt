			==+CASTLEVANIA UNDEAD SERIOUS REDEMPTION+== 

INTRODUCTION
===========

The original Castlevania game was, and still is, a great game. What keeps it from being even better is that, although considered tough by less experienced players (like most games of the time), for being usually short, the difficulty was increased to make it last longer. Still, once the controls, patterns, placements and timings were memorized, the challenge would drop dramatically. That's exactly the main motivation for the making of this hack: bringing back the experience of playing Castlevania as a beginner again, but this time taking much longer to master it.

Heavily inspired by games like Ghouls & Ghosts, Ninja Gaiden, Chakan... it is focused on precise jumps, well timed attacks, exploration and puzzle solving. All screens were very thought-out and vastly tested to present a good (and mostly fair) challenge, if given enough time and practice. 

UPDATES
=======

v2.0

- Improved Simon's design and animation
- A few unintentional shortcuts removed
- Enhanced visual and level design in some areas
- Included some items to help Simon on his task
- Fixed general small bugs.

v3.0

- Easier to identify the background structure on the first level
- Lots of changes on the scenery of the first level
- Blocks better distributed and some puzzles changed for the second level
- Traps, optional paths, puzzles added and more on the third level
- Many improvements on the fourth and fifth level design (bridge session)
- Necessary changes on the sixth level, Clock Tower and Dracula's Chamber design and appearance
- Some items, enemies and structure added, switched and better positioned 
- Small bug fixes (wrong stairs pointers, platforms, shortcuts...) and refinements, making it more faithful to the purpose and balance of the hack, resulting in a more polished experience.

v3.1

- More bug fixes in some stages
- Some changes on the last fight against Dracula
- Fixed a typo on the end credits
