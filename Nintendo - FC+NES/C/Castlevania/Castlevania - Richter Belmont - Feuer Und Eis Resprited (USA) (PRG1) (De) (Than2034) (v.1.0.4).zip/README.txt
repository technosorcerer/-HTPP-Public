Castlevania – Richter Belmont: Feuer – Eis (Resprited)
============================================
Romhack von THAN2034.
Grafikidee: Beyond Remaster.

Basierend auf der Castlevania-Saga (Teil 1, 2 und 3) und der gleichnamigen TV-Serie, animiert von Fans, verspricht dieses Spiel ein Dracula-Abenteuer zu werden, in dem sich Simon Belmont vom Feuer zum Eis verwandelt – ganz im Stil des bekannten Abenteuers aus dem japanischen Videospiel Akumajō Dracula (悪魔城ドラキュラ Akumajō Dorakyura, wörtlich: „Draculas Dämonenburg“). Es erzählt die Geschichte des Vampirjägers Simon Belmont, der von seinem Vater eine Peitsche voller heiliger Kraft geerbt hat.

Das Spiel enthält nur einen Charakter, und folgende Änderungen wurden vorgenommen:

– Der Titelbildschirm wurde überarbeitet.
– Alle Sprites und die einiger dämonischer Charaktere wurden angepasst.
– Für ein verbessertes Gameplay und mehr Manövrierfähigkeit wurde die Fähigkeit „Bewegung in der Luft“ (EN) implementiert (Entwicklung durch NaOH – ROMhack).
– Grafik- und Kompatibilitätsfehler wurden behoben.
– Die Grafik wurde überarbeitet.
– Die entsprechenden Übersetzungen für das lateinamerikanische (spanischsprachige) Publikum wurden erstellt.
– Es wurde eine STAGES-Version erstellt, die ein Castlevania mit neuen Levels enthält. Gameplay, Grafik und die Spezialangriffe „Bewegung in der Luft“ bleiben unverändert. Kompatibilitätsprobleme wurden behoben und Debugger-Fehler korrigiert (basierend auf der Arbeit von mimikyudis).


Siehe auch:  

Englische Version (Klassisch)
Castlevania – Richter Belmont (8-Bit) v.1.0.4, Hack von Than2034 (neu gestaltet) (en)
Spanische Version – LA (Klassisch)
Castlevania – Richter Belmont (8-Bit) v.1.0.4, Hack von Than2034 (neu gestaltet) (es)
Englische Version (STAGES – AAA)
Castlevania – Richter Belmont (8-Bit) v.1.0.4, Hack von Than2034 (neu gestaltet) (en) (STAGES)

Viel Spaß mit der ROM! 🙂

THAN.-