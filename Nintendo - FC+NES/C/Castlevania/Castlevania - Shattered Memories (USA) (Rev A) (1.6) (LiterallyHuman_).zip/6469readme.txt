Castlevania Shattered Memories
By: LiterallyHuman_
Developed using the simple yet
powerful Stake, the Castlevania Editor.
-----------------------------------------
Update Version 1.5:
-Change some annoying level layout like the
 moving spike in level 2 stage 06, and change
 some enemy placement.
-The clock now cost 5 hearts again
 (why was it 15 in the first place?).
-Edit the Gallery so that each level has
 exactly 4 image representing them
 (Except level 6 & 7).
-Change some background to look more
 pleasing in the eye and not distracting.
Also, thanks to the youtube channel
"The Videogame Anthologist" for doing
a commentary on this hack. Don't worry,
your voice was heard :)

Castlevania Shattered Memories is a hack
that change the level layout and some
minor things to make your trip toward the
gravity defying Dracula's Chamber more
enjoyable. Below are the complete list
of the changes:
-Completely changes the level layout
 and make necessary changes to the
 level layout that wasn't changed.
 For example: There is a room
 in level 2 where if you jump
 and get hit by a medusa head,
 you will land on the platform
 above you. I lowered the platform
 below so you can't do it anymore.

-Your whip upgrade is permanent,
 even after you get a game over.

-No knockback

-Move the location of breakable blocks.

-In the original Castlevania and
 Castlevania 3, the further you get
 through the game, the enemies inflict
 more damage than previously.
 In this hack, it's reversed, so the
 further you get through the game,
 enemies inflict less damage.

-Food now restored all of your health.

-There are invisible stairs scattered
 across Dracula's ever changing
 castle, with some of them letting you
 skip certain part of the level.

The patch is an .ips file, so use
Lunar IPS or something of it's kind to
patch the hack.

If you have trouble getting through this
game, you can read the "Hints" text file
included with the patch. Also included
is a Gallery folder, containing footage
of Dracula's chaotic castle and his servants
that lurk within the wall of the castle.

Try this hack if you like the gameplay of
the original Castlevania, but find it too
hard.

Special Thanks:
Dan (For making Stake. Seriously, this software is awesome!)