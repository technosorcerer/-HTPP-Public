BOSS RUSH CASTLEVANIA


Welcome, This hack is a level/boss hack with different music settings as well as increased values with items and damage amounts.



Pallates have been swapped out as well.




This hack works with the rom version "Castlevania (U) (PRG 0)"





This version 1.1 fixes two bugs that made it unwinnable...

Before the final level, A staircase would go to a glitchy room with no escspe.

and upon loading Dracula, The game would crash into a screen full of trash data.

