Castlevania: Stairs of DOOM.

Hack by Alucard @ 2012

This is the hack of CV1 that pumps up all the juice from Stake the castlevania editor.

ROM to patch: Castlevania (U) (PRG1) [!]

This hack has MANY staircases, including crossing ones. Also there is a total of 95 breakable blocks.
Can you find them all?

Difficulty: About the same as CV1 on first quest plus improved Second quest. Expect Grim Reaper and Dracula fights with Medusa Heads spawning all around.

Known bugs and issues:

 Some candles and enemies enjoy despawning, especially in the Second quest when approaching bosses.

 Medusa Heads have glitched graphics at Castle Keep in 2nd quest. They look like Killer Mantles from Aria of Sorrow.

 Sometimes Simon can fall throgh floor into spiked pit right after beginning of block 4-2. This can happen only once per game due to cutscene sheinangans.

 Spikes as well as water in blocks 1-1 and 4-3 are just decoration for death pits. I have little to no ASM knowledge.

A couple more notes:

 There is a puzzle in each block X-3 that Rewards you with best subweapon for the stage`s boss.

 The ending is almost unedited.

 I have tried to get sky getting darker as levels progressing from bright blue in 1-1 to pitch black at 6-3.

Credits:

 Dan for Stake the castlevnia editor,
 Konami for original game. 