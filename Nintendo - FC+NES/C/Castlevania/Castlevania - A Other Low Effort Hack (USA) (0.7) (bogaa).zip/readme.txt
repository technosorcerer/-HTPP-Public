patching: 
	- if your emulator supports it you can softpatch when drag/drop the ips on your emulator while the game is playing.
	- else use a patching tool like this one: https://romhacks.org/utilities/floating-ips-utility/
	
	you need to patch this ROM:
		Database match: Castlevania (USA) (Rev 1)
		Database: No-Intro: Nintendo Entertainment System (v. 20210216-231042)
		File SHA-1: 7A20C44F302FB2F1B7ADFFA6B619E3E1CAE7B546
		File CRC32: 856114C8
		ROM SHA-1: 3DCB69A8C861C041AEB56C04E39ADF6D332EDA3A
		ROM CRC32: B668C7FC

playing:
	- This is a level hack with new music and some tweaks! Have fun!
	
	
src/source file:
	- famiStudio engine is shared with ASM6 ready to compile.. I would recommend to start new with CA65 and make a cleaner template to share.
	- Castlevania (U) (PRG 1).ini goes into your stakes data folder in case you like to edit this ROM. 
	- Castlevania (U) (PRG1) [!].xml is a resource file for Tilemolester to view some of the Roms content by using bookmarks.
	- If you are confused about assembly patching you can also joine my discord and ask questions there. https://imgur.com/d70lVMb
	- In general make.bat will build a project from main.asm (my project tend to be a bit messy..)
	
credits:
	- spiderDave for SDasm, and all the other tool creators. You can look them up and this project would not exist without them.
	- special thanks to the famiStudio community to share projects I could use and learn from. 
	- naoki kodaka and relizc arranged the boss music I just had to snag and insert.. so you could be able to do the same for your projects. 