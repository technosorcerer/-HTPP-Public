Castlevania Mapper Conversion
From UNROM to MMC5 (from Mapper 2 to Mapper 5)
by RetroRain

RELEASE DATE: March 02, 2015
TIME SPAN FROM START TO FINISH: 1 Day

The Bankswitch Routine is located at $FFF0.  To use it, all you have to do is select a bank and jump to it.

Example:

LDA bank_number
JSR $FFF0

Only the basic MMC5 mapper registers were enabled to get the game to run, however it is entirely possible to add others to make full use of the new mapper's capabilities.

In order to do this mapper conversion, I had to expand the ROM, because Castlevania had very little free space in the hardwired bank.  The PRG-ROM was doubled in size, however, with this new mapper, it may be possible to expand it even more.  If you wish to use more of the mapper's capabilities, you can add them at $E028 in the new free bank (0x3e038).  Just move the existing code down so you can add your own code.  This ROM was tested to work on FCEUX 2.2.2.  I have not tested it on other emulators.

You may use this patch as a base for your Castlevania hacks.  Credit is not necessary, but it is appreciated.

Have fun!

acmlm.kafuka.org