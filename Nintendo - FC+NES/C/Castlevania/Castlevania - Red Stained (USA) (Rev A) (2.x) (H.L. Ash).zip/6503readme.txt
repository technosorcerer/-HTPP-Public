                                      ==+CASTLEVANIA: RED STAINED+==

The original Castlevania has many elements of an old horror movie. From the title screen, with details on the top and bottom resembling a movie tape, some of the bosses (Medusa, Frankenstein, Dracula...) and the final credits, replacing the names of the programmers by "funny" altered ones of famous actors from the past, related to that movie genre.

Inspired by this concept, the Castlevania Red Stained mod was created in a black and white style, as a classic horror film but, with the inclusion of some shades of red on specific objects and enemies during the whole game, providing a reasonable different experience.

Besides those changes, many others were made, such as: new traps added, increased difficulty, many graphical details corrected, fixed some rough areas, reduced unnecessary items (breakable blocks, candles...) and also allowing the treasure before the boss fight against the Mummies of the third stage - "The Crumbling Tower" - to be accessed.

Still, an optional patch was included, maintaining the same difficulty and level design as the original game, with just minor adjustments. 

============

UPDATE v2.X

- A second patch included with the original difficulty restored and new traps removed

UPDATE v2.0

- Increased damage done by enemies
- Turkey recovers more life
- New traps added to most stages
- Some enemies added to empty areas 
- More excessive candles removed
- Stronger sub-weapons are more scarce and harder to get
- Ground color of the Crumbling Tower is more distinguishable now
- Better use of red tones on the laboratory level
- Fixed the letter "a" of the title screen to capital
- Lots of small graphical changes and fixes


UPDATE v1.5

- Fixed a visual bug on the title screen, showing up after the demo of the gameplay ends
- Improved the ending screen colors and some details
- Many small changes on the appearance of the Laboratory level: less repetitive patterns of the frames and a few different position for curtains, pillars, blocks... at the boss room
- Altered the water effect, pillars and some strange background textures of the stairs on the Underground level, as long as some blocks of the boss fight screen were adjusted to better match the new colors of the game
- A few more details added for the CV fans to spot.
