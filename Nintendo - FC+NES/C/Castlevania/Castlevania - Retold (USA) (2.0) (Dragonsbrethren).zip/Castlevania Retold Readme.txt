											    |Version 2.0 - 6/24/04
											    |Hack by Dragonsbrethren
											    |Presented by TEKHacks
											    |http://www.tekhacks.net
____________________________________________________________________________________________|________________________________

Document is to be viewed maximized in 1020x740 resolution, anything less is for the sightless...
-----------------------------------------------------------------------------------------------------------------------------

___________________________
			   \
 Contents:		   |
---------------------------|
  I.   Introduction	   |
  II.  Changes		   |
  III. How-to use          |
  IV.  Not-so FAQs	   |
  V.   Special Thanks	   |
  VI.  Contact Information |
___________________________/

_____________________________________________________________________________________________________________________________

 I. Introduction
-----------------------------------------------------------------------------------------------------------------------------

  Castlevania Retold 2.0 is a hack of the NES classic, Castlevania.  It features brand new levels with new enemy and item  placement.  If you've played previous versions you're recognize many areas, but there are plenty of new things as well.

_____________________________________________________________________________________________________________________________

 II. Changes
-----------------------------------------------------------------------------------------------------------------------------
 Here's what's changed:

  *100% brand new levels designs.
  *100% brand new enemy and candle placement.
  *99% brand new (ripped) graphics.
  *Bugfixes from previous versions

_____________________________________________________________________________________________________________________________

 III. How-to use
-----------------------------------------------------------------------------------------------------------------------------

 First things first, you will need to download three things:

  1. Lunar IPS (http://fusoya.cg-games.net)
  2. FCE Ultra (http://xodnizel.net/fceultra)
  3. A Castlevania ROM (Can't provide this, sorry)


 How to use the IPS patch:

  If this is your first time using Lunar IPS you will have to do the following:
   
   *Run Lunar IPS
   *Click on Apply IPS Patch
   *Find the IPS patch made for your version of the ROM (Castlevania Retold (PRG 0).ips or Castlevania Retold (PRG 1).ips)
   *Select it
   *Make a copy of your Castlevania ROM
   *Select it
   *Apply the patch

  Your ROM is now patched, rename it Castlevania Retold.nes
  If you don't know which version of the ROM you have try them both.

  If you've used Lunar IPS before you can simply run the IPS and follow the patching steps.

 How to run it in FCE Ultra:

 (If you're reading this maybe you shouldn't be playing a hack just yet... but I'll assume you're just a newbie to FCE Ultra)

   *Run fceu.exe
   *Configure the emulator to your liking. Also, make sure to load fX3's palette if you want to use it.
   *When you're ready open the ROM through the file menu
   *Enjoy!

  Of course, if you want you can use different IPS patching programs or emulators, those are just my favorites.
_____________________________________________________________________________________________________________________________

 IV. Not-so FAQs
-----------------------------------------------------------------------------------------------------------------------------

 Q: Why is this section called "Not-so FAQs?"

 A: No one has actually asked me any of these questions, I predict people will, however.

 Q: No custom palette in this version?

 A: Nope, too many complaints.  It should look good using any NES palette, I suggest the one made by fX3.

 Q: Why are all the new graphics ripped?

 A: You would not want to play with my custom graphics, trust me.

 Q: The first door you come to is broken...

 A: No it's not, it's locked, the answer lies below your feet...

 Q: I ripped up the carpet and there was nothing there, what gives?

 A: Ugh, there's a second door below the locked one...

 Q: Where's this "CVC Revision" you've been talking about at?

 A: I handed that task off to redrum, I am no CV master, and I think he'll do a better job with it.

 Q: I found a glitch, what do I do?

 A: Unless it's a major gameplay glitch, I will not be fixing any glitches, this is the last version of CV Retold.

 Q: It's too hard, can you make an easy version?

 A: I was making an easy version called the "Craptacular Players Edition (CPE)" but I canceled it.

 Q: It's too easy, can you make a hard version?

 A: One is in the works, it's called the "CVC Revision" (For the guys at the Castlevania Corner)
 
 Q: Why are the levels/moving platforms/spike crushers placement so similar to the original game?

 A: When this hack was started Stake couldn't edit those last two things and I wasn't that good with the editor yet.

 Q: Why didn't you fix them in this version?

 A: I did, somewhat, but many people liked my original levels designs so I left most of them intact.

 Q: Any new CV hacks planned for the future?

 A: Yes, a new CV Retold-style hack without all the problems found in this one.  That's all I'm saying.

_____________________________________________________________________________________________________________________________

 V. Special Thanks
-----------------------------------------------------------------------------------------------------------------------------

 These are the people I must thank for helping to make this hack possible:

 Dan: The author of Stake, THE Castlevania editor.

 Dragonsbrethren: The creator of this hack, a kick ass guy who talks about himself in the third person sometimes.

 redrum: My number one beta tester, always willing to help.  Inspired the CVC Revivision, and is going to make it.

 solid-tbone: Helped a lot in the early days of this hack. 

 Bit-Blade: Also helped a lot in the early days.

 Moonchilde: Made a revamped version of my title screen graphic for redrum's hack.  I used it in this one as well.

 Morgoth: At first he was here for the new cross style, but I removed that.  Helped beta test and gave suggestions.

_____________________________________________________________________________________________________________________________

 VI. Contact Information
-----------------------------------------------------------------------------------------------------------------------------

 E-mail: dragonsbrethren@earthlink.net (You probably won't be able to get past my spam filters)
 AIM:    Dragonsbrethren (I'm NEVER on)
 Forum:  http://www.tekhacks.net/bored (This is the one you want)

-----------------------------------------------------------------------------------------------------------------------------
 I just realized it's been almost a year since this hack was started, it's been a good experience.  This is my favorite hack   out of all I've done, and is the first I finished.