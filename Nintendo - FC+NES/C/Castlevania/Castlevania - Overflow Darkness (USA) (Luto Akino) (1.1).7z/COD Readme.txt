Hi, this is my first (and my last, i think) Hack. like a lot of people, i love the Castlevania serie. And that best opportunity that this. With the first game of the serie.

Special thanks to Dan, creator of the stake editor. make the edition of the game much more easy. and open the gates to other people can do it. 

Enjoy it.

------------------------------------------------------------------------------------------

Hola, Soy Luto y este es mi primer (y mi �ltimo creo) Hack. al igual que a mucha gente, me encanta la serie Castlevania. Y que mejor oportunidad de demostrarlo, que esta. Con el primer juego de la serie.

Un agradecimiento especial a Dan, creador del editor de juego. Hace la edici�n del juego mucho m�s f�cil. y abrir las puertas a que otras personas que no tengan un total entendimieto en la programacion puedan hacerlo.

Que lo disfruten.Y VIVA M�XICO CABRONES!!! =)