+ CASTLEVANIA REVAMPED +                                                                                                                             
This is a tribute to this great classic game. One of the ( if not THE ) best of the entire series.
APPLYING THE PATCH
To make this file playable, you need the original uncompressed rom  "Castlevania (U) (PGR 1).nes"  and an IPS patcher like "Lunar IPS" (freeware).  Place the patch and the original rom in the same folder, click  "Apply IPS Patch", select the Castlevania Revamped IPS file first, hit "Open",  then the Original Castlevania rom. Click "Open" again and the file is ready to play.
NEW FEATURES
. Lots of redesigned graphics
. New and innovative challenges, including all the bosses
. Different puzzles and hidden places
. Alternate paths
. Slightly more difficult but never feeling unfair or broken 
. Just enough candles, more strategic  gameplay
. All the hidden treasures of the first round maintained
. New texts... and much more. 

UPDATE v2.0
. Many level design changes, making better use of the available area on the screen
. Second stage boss, "Queen Medusa", puts up a better fight 
. Bug fixed on the final stage by removing the elevated floor which caused Dracula's second form to eventually get stuck
. Changes in some levels design to prevent the Medusa Heads from having an erratic behavior
. Some enemies are better placed
. More puzzles included and others tweaked
. Graphical updates adding more visual details in many areas of the game
. Bug fixed on the bridge stage, with the physics of the character corrected if falling off
. More "flying candles" removed and better positioned
. Other minor adjustments throughout the game


