5/26/12
UPDATE 7/16/13
infidelity

Castlevania UNROM to MMC3

MMC3 Bankswap Routine To Insert Into ROM = 0A48A9068D0080688D0180090148A9078D0080688D018060

$1C1A6 loads bank id from $1C010-$1C017
$1C1A9-$1C1AE performs a double STA,Y to $C000

So, find a free location in the rom to place the bankswap routine, then, at $1C1A9, put...
20####EAEAEA, and thats it.

Done!

UPDATE 7-16-13

Now works on an actual NES!

I've placed the Bankswap routine and the CHR register setup within the DPCM of when Simon gets hit. It's barely noticeable to me, but if someone is willing to do a thorough runthrough of this game, to find a good amount of unused space within the HW bank, i'll be more than happy to relocate my work out of Simon's DPCM sample.

$1C039 = 2058FF EA
$1C1A9 = 2040FF EAEAEA
$1FF43 (chr values) = 000204050607

Following Is Witin Simon's DPCM Sample
$1FF50-$1FF67 (Bankswap) = 0A48A9068D0080688D0180090148A9078D0080688D018060
$1FF68 (CHR Routine JSR'd From Reset Vector) = A2058E0080BD33FF8D0180CA10F4A906852460
END

UPDATE 7/20/13

ISSUE REGARDING MIRRORING

Need to add Mirroring Mode within Reset Vector. For Castlevania it starts as Vertical

$1FF76 = A900 8D00A0 A906 8524 60
END