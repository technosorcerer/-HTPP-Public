Castlevania Extreme version 0.42
By Inccubus

This is an extensive graphics and palette hack of Castlevania for the NES.

2/6/01
What's Done:
Simon sprites and colors edited.
Enemy sprites and colors edited.
Level 1 - Edited layout and slight palette modification. Changed drapes to look darker
		and more velvety. Doors fixed to match those on all other levels.
Level 2 - Edited layout and major palette work done to the background. Medusa statues
		are more detailed.
Level 3 - Edited layout. No palette changes yet.
Level 4 - Edited layout. No palette changes.
Level 5 - Unchanged.
Level 6 - Unchanged.

All work on this hack has been done using TileLayer/TileLayerPro, Nesticle, Hexposure, and
CVedit. Thanks to the talented programmers that made these helpful utilities. And thanks to
Kevin and Javier for letting me torture... I mean letting me use them as 'hack testers'.
Well, I hope you all enjoy playing this hack as much as I'm enjoying making it.