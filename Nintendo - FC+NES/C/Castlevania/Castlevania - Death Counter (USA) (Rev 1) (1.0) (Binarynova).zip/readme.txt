[Name]
"Castlevania [Death Counter].ips" v1.0

[Author]
Binarynova

[Date]
March 14, 2022 (PI DAY!)

[Description]
This hack repurposes the life counter in Castlevania into a death counter. You begin the game with zero deaths, and each time you die the counter increases by 1 (up to 99). This effectively gives you infinite lives but more than just a simple cheat code, it also modifies the in-game UI to help players keep track of deaths and encourage trying to have as few deaths as possible.

[Installation]
Use your favorite IPS patcher to apply this patch to the US (Rev 1) version of the game.

[Changes]
- Repurposes the lives counter as a death counter.
- Death counter starts at 0.
- Dying increases the counter.
- Getting extra lives (either from points or the hidden 1up) plays the jingle but has no effect.
- Added a little skull icon to the UI to indicate deaths instead of lives.
- At 256 deaths the counter loops back to 99 to prevent a Game Over caused by an overflow.