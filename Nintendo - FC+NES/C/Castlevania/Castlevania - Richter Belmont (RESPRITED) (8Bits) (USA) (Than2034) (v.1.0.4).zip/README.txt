Castlevania - Richter Belmont: Fire - Ice (Resprited)
======================================================
Romhack by THAN2034.
Graphic Idea: Beyond Remaster.

Based on the Castlevania I, II, and III saga and the TV series, and animated by fan gamers, this promises to be a Dracula-style adventure where Simon Belmont transforms from Fire to Ice in the familiar adventure from the original Japanese video game Akumajō Dracula (悪魔城ドラキュラ Akumajō Dorakyura, lit. "Dracula's Demon Castle"). It describes the exploits of a vampire hunter named Simon Belmont, who inherited a whip brimming with sacred power from his father.

The game features only one character, and the following changes were made:

– The title screen was modified.
– All sprites and those of some demonic characters were modified.
– For improved gameplay and maneuverability, "moving in the air" was implemented (work done by NaOH - ROMhack).
– Graphical and compatibility errors were corrected.
– The graphics were modified.
– The corresponding translations were made for the Latin American (Spanish-speaking) audience.
– A BETA version was created, featuring a Castlevania with new stages. The gameplay, graphics, and "moving in the air" special moves remain unchanged. Compatibility issues were resolved, and debugger errors were corrected, based on the work of mimikyudis.

English Version (Classic)
Castlevania - Richter Belmont (8-bit) v.1.0.4, Hack by Than2034 (resprited) (en)
Spanish Version – LA (Classic)
Castlevania - Richter Belmont (8-bit) v.1.0.4, Hack by Than2034 (resprited) (es)
English Version (BETA - AAA)
Castlevania - Richter Belmont (8-bit) v.1.0.4, Hack by Than2034 (resprited) (en) (BETA)

Enjoy the ROM!
