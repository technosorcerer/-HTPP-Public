Castlevania: Stairs of DOOM.

Hack by Alucard @ 2012

This is the hack of CV1 that pumps up all the juice from Stake the castlevania editor.

ROM to patch: Castlevania (U) (PRG1) [!]

Version History:

 v1.0: Initial release.

 V1.1:
  Added more time in most stages.
  Reenabled castle introduction scene and edited it a bit.
  Fixed bug with cutscene in 4-2.
  Rearranged enemies in various levels to avoid "cheap" hits and deaths in first quest.
  Fixed castle door at the beginning.

This hack has MANY staircases, including crossing ones. Also there is a total of 95 breakable blocks.
Can you find them all?

Difficulty: About the same as CV1 on first quest plus improved Second quest. Expect Grim Reaper and Dracula fights with Medusa Heads spawning all around.

Known bugs and issues:

 Some candles and enemies enjoy despawning, especially in the Second quest when approaching bosses.

 Medusa Heads have glitched graphics at Castle Keep in 2nd quest. They look like Killer Mantles from Aria of Sorrow.

 Spikes as well as water in blocks 1-1 and 4-3 are just decoration for death pits. I have little to no ASM knowledge.

 Hidden items (flashing treasures that appear when you do illogical actions) retain their original positions. Stake does not support editing them and it`s help file just lies about it.

A couple more notes:

 There is a puzzle in each block X-3 that rewards you with best subweapon for the stage`s boss.

 The ending is almost unedited.

 I have tried to get sky getting darker as levels progressing from bright blue in 1-1 to pitch black at 6-3.

Credits:

 Dan for Stake the castlevnia editor,
 Konami for original game. 