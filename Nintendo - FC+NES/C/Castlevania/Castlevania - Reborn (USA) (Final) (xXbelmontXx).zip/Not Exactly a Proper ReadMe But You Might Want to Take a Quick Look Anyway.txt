I didn't make this hack, but the person who did (xXbelmontXx) messed up the upload for it on RomHacking.net; instead of uploading the IPS patch file, they uploaded an .html file of the download page of the filehosting service where the HACKED ROM is stored.

Of course, the filehosting service doesn't allow direct downloads from the download page, so the uploaded html file is worthless.

Also RomHacking.net severely frowns upon such naughtiness as sharing the ACTUAL ROM: hacked or not.

So, I made 2 IPS patch files from the hacked rom (which was a bit tricky to find) One for each version of the original game's roms:

Castlevania (U) (PRG0) [!].nes
Castlevania (U) (PRG1) [!].nes

Just check your GoodNES set for one of those 2 roms and use the corresponding IPS patch for it.

Any decent NES emulator can softpatch your Castlevania rom.

However, to hardpatch it, use LunarIPS which is free and can be found here:
http://fusoya.eludevisibility.org/lips/

Or here:
http://www.romhacking.net/utilities/240/

There was no proper readme included with the hacked rom, but some information on it can be found here:
http://www.romhacking.net/hacks/1107/

And so far, there are 2 videos on YouTube, one of them a video walkthrough:
http://www.youtube.com/watch?v=YYdRjbt9XPg
http://www.youtube.com/watch?v=gjJ0CF4OYoE

Finally, I TAKE NO CREDIT/BLAME FOR THE HACK, all I did was make a patch/working download for it

The hack itself was made by xXbelmontXx.
So go praise/criticize them.


****************************************

TL;DR

I made an IPS patch for somebody else's hacked rom which they uploaded to RomHacking.net, but since they failed to do that properly, the download link wasn't working anyway.

So, fixed that too.

The person who created the hack itself is xXbelmontXx, not me.



