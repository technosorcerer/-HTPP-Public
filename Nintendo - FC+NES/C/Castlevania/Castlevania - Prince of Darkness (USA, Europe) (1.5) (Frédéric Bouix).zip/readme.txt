----------------
Hidden Treasures
----------------


Note: an asterisk (*) denotes an item that is only found in the second quest after you have defeated Dracula.


LEVEL 1

Stage 01 - *. Outside, crouch in front of the black way for 1000 pts.
           1. Jump over the entrance to the castle for 1000 pts.
           *. Stand in front of the window at the top of the three raised platforms for 1000 pts.

Stage 02 - 1. At the end of the underground section, crouch on the most to the right low block for 1000 pts.

Stage 03 - None


LEVEL 2

Stage 04 - *. Climb first stairs, whip blocks on the right, then walk into the gap for 2000 pts.

Stage 05 - 1. Stand on the two raised blocks for a couple seconds for 2000 pts.

Stage 06 - *. Stand between right and center spiked ceilings for a few seconds for a 1-up!
           1. After climbing the stairs, wait between the 2nd and 3rd pillars, counting from the right, for 1000 pts.


LEVEL 3

Stage 07 - *. Crouch on the platform at the top of the stairs at the beginning of the second section for 4000 pts.
           1. Before you reach the last White Skeleton, duck (or fall) on one of the lowest platforms for 1000 pts.

Stage 08 - 1. After climbing the stairs, crouch just before the 2nd candle. Go left for 1000 pts.

Stage 09 - 1. In the Mummies' room, keep walking left against the first platform for 1000 pts.


LEVEL 4

Stage 10 - None

Stage 11 - None

Stage 12 - None


LEVEL 5

Stage 13 - 1. From the left high plateform on the last screen of the stage, jump to the left to take an invisible bridge. Jump over invisibles holes (!) and keep walking left into the wall for a 1-up!

Stage 14 - 1. After taking the first set of stairs leading downward, wait in the middle of the hollow to the right for 1000 pts.
           *. Whip the closed door and wait beside the wall for 1000 pts.
           2. Take the final set of stairs leading upward, then go right, and land on the two isolated blocks for 1000 pts.

Stage 15 - None


LEVEL 6

Stage 16 - None

Stage 17 - 1. After going downstairs to the third screen, head right instead of going left. On the right end of the gear, crouch for 1000 pts.

Stage 18 - None