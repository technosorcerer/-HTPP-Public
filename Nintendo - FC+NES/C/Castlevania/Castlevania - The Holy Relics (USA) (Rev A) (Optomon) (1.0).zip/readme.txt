

Castelvania: The Holy Relics.
(READ ME)

EDIT: 


-----------------------------
Version 1.0 as of 12/07/17

*small level revisions
*makes sure Simon's head
 doesn't get stuck in the 
 ceiling when jumping.
-----------------------------


This is a complete hack of Castlevania 1.
For now this is brief, I'll let the wolves
play a little and see what happens. I don't 
have too much time, it is a very new game,
please play.

Dedicated to my brother Patrick, on December 1st 2017,
on the occasion of his 40th birthday, for quickly 
mastering our family's first NES game at the 
age of 10 back in 1987.



=======================================================================
STORY
=======================================================================

In 1291, the last of the crusaders attempted a raid on the holy 
land and were soundly defeated by Arabian warriors. While their 
mission failed, they returned to Europe with seven treasures 
with biblical blessings. On their journey back to their native 
lands, they discovered that they possessed magical healing powers. 
Corrupted and demoralized, they began using them for selfish desires, 
and sought to be worshiped with the help of a devil incarnate, Ba'Mendes. 
Their attempt at this also was also repelled by courage of good people, 
and they were exiled to the mountains of Transylvania to be forgotten.

Four hundred years later, it was rumored that these relics ended up in 
the possession of Count Dracula himself, and that they were among the 
many treasures in his opulent collection that gave him the power to 
oppress Transylvania with demons. After his defeat at the hands of 
Simon Belmont, however, his castle crumbled to a heap in the mountains, 
and the relics were thought to have never existed.

Shortly after, Lord Ghulash, an old acquaintance of Dracula who practiced 
necromancy at the academy of Scholomance, scavenged the ruins of Castlevania 
in search of the rumored relics, and found all but one. He started to use 
their powers to terrorize Transylvania much in the same way that Dracula 
had, resurrecting the souls of vile creatures and wicked men. The seventh 
relic, a cross that burns away demons, had secretly been in possession of 
the Belmont family for centuries.

Now, in 1693, Transylvania is once again infected by rampaging monsters 
under the command of a dark lord whose ambition is to enslave all of humanity. 
Simon, a proven hero, must once again deliver his homeland from the forces of evil.


=======================================================================
WEAPONS / ITEMS
=======================================================================

The weapons are the same, except the dagger was changed to an oak stake, 
which is much slower and much more powerful; probably best to not to mention the dagger. 
The axe was modified also, but it shouldn't have anything different about it, other 
than maybe it is "more powered up".

Hearts, money bags, pork chops, whip upgrades, and double / triple shot items still 
exists as they always did in Castlevania. There are two new items, the key and the blue 
heart. The key allows the player to get through doors, the blue heart is a currency 
for using the power of a relic.

Then there are the holy relics. There are officially seven of them. You collect one 
for defeating a boss.

CROSS: is the default relic, with the same function that existed in the original game, 
killing all enemies on screen.

CROWN: allows the player to have an extremely powerful whip for a short period of 
time. You collect it from defeating Arachne in the Denis Woods.

BAG: allows the player to collect an extreme amount of points from enemies when 
activated. You collect it from defeating Hydra in the Andra River.

BASKET: gives player invincibility and stifles the movement of most enemies. 
You collect it from defeating Camilla in the Camilla Crypt.

MUG: restores the players health. You collect it from defeating the Grim Reaper in 
Deborah Cliff.

SHOES: causes the player to drop from above (e.g. the top of the screen). 
They're useless most of the time, but it can be helpful in unusual situations, 
like skipping large sections of levels, or exploring inaccessible areas. You 
collect it from defeating Goliath in the Temnita Tower.

BIBLE: received when defeating Ghulash and Ba'mendes, the final boss combo.
This scripture is the most powerful of all relics!

There are also numerous hidden treasure chest items worth 1000 points each. 

=======================================================================
MENU
=======================================================================

Before starting a stage, the player is presented with a menu screen. This menu allows them to first select a stage, 
then select a relic to take as a weapon for that stage. 

If a player presses the B button while selecting a relic, they will be able to re-select a stage. 
If the player has already completed a stage, it will appear as greyed out and become unselectable. 
After the player has completed the five initial stages, the final stage will become accessible.

Stages: 

Denis Woods - A forest stage, the default stage, is also the easiest to complete and contains 
mostly introductory elements.

Camilla Crypt - A graveyard stage.

Andra River - A water stage.

Deborah Cliff - A wasteland / cave looking stage.

Temnita Tower - A castle looking stage.

Vrad Manor - The final stage, a mansion looking place that becomes selectable after completing the other five stages.




=======================================================================
ADDITIONAL INFO
=======================================================================



ON BUGS, ISSUES, AND OTHER MESSAGES:

Please email important messages to optomon@optovania.com



ON REPROS:

Do not do repro this without my permission.
The game has official cover art and a manual. 
Please use them.



TO SETZ, BIT-BLADE, DR. MARIO, and IVAR:

Thanks guys, I hope your unused material 
is appreciated as it has been brought to life here.
Sorry for not saying much here.




