THIS IS A FANMADE GAME MADE WITH STAKE� BASED ON CASTLEVANIA� WHICH IS OWNED BY NINTENDO�, WHOM I AM NOT AFFILIATED WITH IN ANY WAY!

Ok, so I had to patch a small glitch in the last version of the game, but here is the patched version with a working emulator so you don't have to go download one. All you have to do to play is open the .zip file, open the VirtuaNES, click File and Load, select my game, and play. You can save by going to Edit and then Save State, and load by clicking Load State, but be careful where you save because it instantly saves directly where you save at. Have fun and please tell me what, if anything, needs fixing or could be better.

~GAME INFO~ (PLEASE READ IF YOU HAVE NEVER PLAYED A CASTLEVANIA GAME BEFORE!)

CONTROLS:
Up, Down, Left, Right: Arrow keys
Jump: Z
Whip: X
Going up or down stairs: Press up/down at the base/top of the stairs
Using subweapon: Hold up and press X
Pause: Enter

Falling off of a cliff or draining your health (Player) bar completely will cause you to die, and as long as you still have extra lives, you will respawn at your last checkpoint. (Which are usually doors, the only ones that aren't are the very beginning of the game and an area half way through level 4 where you come up some stairs out from underground.) If you die without any extra lives, you will respawn at the beginning of the level you are currently on. The goal of each level is to defeat the boss and obtain the orb which he drops. You require hearts to use subweapons, which can be found in candles or when you defeat enemies. You start out with 10 each time you respawn, and each subweapon only costs one heart to use, except for the stopwatch, which costs five. For every 30000 points you earn, you will earn an extra life. Points are obtained by killing enemies, collecting money bags, and at the end of each stage, 100 points is rewarded for each heart you have remaining. Some walls can be broken with your whip, and have useful things inside of them, they are placed in random places, but sometimes there are small indications of them near them. Look for patterns.

~ITEMS~
[SUBWEAPONS]
Knife- Can be horizontally thrown completely across the screen at a fast speed. A good ranged attack. Low damage.

Axe- Can be thrown upwards in an arc. Good for taking out overhead enemies and hard to reach candles. Moderate damage.

Cross- Can be thrown horizontally 3/4 of the way across the screen, and comes back like a boomerang. You can hit enemies twice with a cross because it deals damage on the way back to you as well. Good for many purposes, and an effective ranged weapon. Moderate damage (x2 if hits on the way back as well).

Holy Water- Can be thrown a small distance forward and hits the ground, creating a damaging/stunning fire where it lands. Good against stationary enemies, and can also be used as a trap for enemies that come toward you. Effective against most bosses. Moderate damage, multiple hits.

Stopwatch- Stops time and all enemies for approximately 4.5 seconds, leaving them vulnerable for attacking. Costs five hearts to use. Does not work on bosses. ([II] and [III] Items do not work with the Stopwatch. They give you points, as they do if you have no subweapon)

[OTHER ITEMS]
Small Heart- Small hearts that flutter back and forth until they reach the ground. Found in most candles and dropped by enemies. These add one heart to your heart count. (Not to be mistaken with your health bar).

Big Heart- Adds five hearts to your heart count. Heavy, and falls straight to the ground. Found in some candles and breakable walls. Rarely dropped by Skele-Dragons.

Whip Upgrade- Comes from candles containing small hearts or enemies when your whip is not upgraded fully. Appears as a chain looking whip and falls straight to the ground. The first time you collect one, your whip becomes more powerful, and changes into a morning star whip. The second time you collect one, your whip becomes longer. Your whip upgrades reset every time you die.

Invincibility Potion- Provides invincibility to the player for approximately 7.5 seconds when collected. Allows the player to walk through, or easily destroy any enemy in his/her path while active. Can be found in some candles and breakable walls.

Red Money bag- Adds 100 points to the player's score when collected. Commonly found in some candles and dropped by some enemies.

Purple Money Bag- Adds 400 points to the player's score when collected. Uncommonly found in some candles and some breakable walls. Skele-Dragons can also drop them.

White Money Bag- Adds 700 points to the player's score when collected. Rarely found in some candles.

x2 Item- Allows the player to have 2 subweapons on screen at a time. Found in some candles, breakable walls, and dropped by some enemies. Looks roughly like this -> [II] Does not work with a stopwatch.

x3 Item- Allows the player to have 3 subweapons on screen at a time. Found in some candles, breakable walls, and dropped by some enemies. Looks roughly like this -> [III] Does not work with a stopwatch.

Meat slab- Restores 8 hit points to the Player bar when collected. Found in some breakable walls.

Rosary- Destroys all enemies on screen when collected. Found in some candles.

Subweapons- Used as an alternate weapon in combination with your whip. Found in some candles and dropped by some enemies. Some subweapons are better than others in different situations.

~SECRET SPOILERS~ DON'T LOOK HERE IF YOU WANT TO FIND SECRETS ON YOUR OWN!!!!!!!!!







Ok, so here I'll list the secret points items and hidden areas in the game. Most of these are fairly difficult to find on your own, so if you look here to find them, I'm not surprised. Here is a list of the secret spots in the game, and how to get to them, and claim their reward.
1. Jumping over the door in the opening area will spawn a 1000 point money bag on the other side, which you must jump back over the door to get. It's kinda tricky to jump the door just right, but it's definitely possible.
2. When you go outside to the water area with the fishmen in the first level, you can fall down to a platform on the water, and go down a set of stairs, leading you to a semi-secret area filled with candles... and fishmen. Go right and when you come across a dip in the ground, destroy the block on the right side that you can hit with your whip. Go to the end of the lower platform and crouch, spawning a 1000 point money bag back on the higher platform. Quickly get back to it before it dissapears, dodging fishmen on the way.
3. At the very beginning of level 2, crouch at the end of the small platform you start on and whip the platform in front of you, destorying both  of the top blocks in front of you. One of them contains a x2/x3 Item. Jump across and use the staircase to get up and destroy the wall on the right. Walk just far enough off of it to spawn the 2000 point crown, but not far enough to fall off. When the chest spawns, go back and crouch ontop of it to collect it.
4. In level 2, in the area after you've already gone through one door, on the bottom layer, there is a pit you must jump to a platform in the bottom of. On the top of the left side, stand on the very edge for a few seconds until a 2000 point treasure chest spawns. In order to obtain it, you must jump down and jump across to the right side, grabbing it at the top of your jump.
5. There is a secret booster place right before the Dracula fight, it contains subweapons, hearts, and x2/x3 Items. To access it, Jump across to the floating platforms across from the top of the stairs, and press down at the far right edge like you are going down a flight of stairs. This should help you prepare better for the Dracula fight.

There's a whole lot more, but I don't have the time to write them, so if you really would like to know, just ask.