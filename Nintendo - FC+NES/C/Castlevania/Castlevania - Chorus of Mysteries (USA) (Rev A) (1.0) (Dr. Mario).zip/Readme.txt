*************************************************
*                                               *
* CastleVania: Chorus of Mysteries              *
* A Castlevania Hack by optomon and Dr. Mario   *
* chorusofmysteries@gmail.com                   *
*                                               *
*************************************************

Files in the archive:

README.txt  ->I hope you know what this is...
CVCoM v1.IPS  ->The IPS patch


How to patch this file:

SNESTL12- For the old people
Make sure you have a Castlevania (PRG 1) ROM.
Put the ROM in the same folder as CVOoD v1.IPS and SNESTL12.EXE. Open up SNESTL12.EXE 
and go to the "Use IPS" option. Select CVD.IPS Next select the Castlevania ROM, and BAM! 
Your ROM just got kicked up a notch!

LunarIPS- For those up to speed
Have your Castlevania rom. Open up LunarIPS, and select apply IPS patch. Open up the IPS patch, 
and then open up the rom. BOOM! You're done!

STORY:
1476, Romania. A terrifying castle rises up from the mist. Along with the castle rose a 
dark powerful being named Count Dracula Vlad Tepes. A man named Trevor Belmont was fated 
to defeat the powerful vampire, aided by a witch named Sypha, Dracula's own son Alucard, 
and a pirate named Grant DeNasty. Together the team traversed the dark halls of Castlevania,
defeating the count and his countless minions.

In 1777 a young child was born, and abandoned on a merchant ship with nothing but a 
headband with a mysterious crest, and the name Armund. The sailors raised the child on the 
high seas, and taught him the ways of being a sailor. Armund grew to be one of the greatest
men that the merchant ship ever saw.

Late 1797, word started to spread of the legends of Count Dracula, and his tyranny in the 
land of Romania. It was about that time, that Armund ran into an old Romanian man in Serbia.
The old man knew a lot about the history of Count Dracula, and his reign of terror in 
Romania. The old man recognized the crest on Armund's bandanna, and told him that it 
belonged to the DeNasty clan, and that his ancestor helped defeat Dracula. Armund decided 
to leave his life on the high seas to seek out more answers about his ancestry.

Romania, 1800. It's been 3 years since Alucard defeated his father in battle and has gone 
into eternal slumber. Armund's search has taken him to the mountains of Romania, not far 
from the town of Jova. A mysterious letter hinted that he might be able to find answers in 
the castle of Count Olrox, a servant of Count Dracula's. Armund set out of Olrox's castle, 
armed only with an enchanted barbed rope from Serbia. This will truly be the greatest and 
most arduous adventure of Armund DeNasty's life.


ITEMS:

Barbed Rope of Siberia- The enchanted rope has the strength to destroy creatures of the 
                        night.

Upgrade- Make the rope stronger!

Hearts- Get more use out of sub-weapons

Money Bags- Good for points

Treasure- Hidden all over the place

Meat- Gives you health

Knife- Toss it through your enemy's heart

Holy Water- Toss it through the air and watch the flames rise!

Axe- Good for airborne guys, and very strong

Laurels- At the cost of 8 hearts, you can become temporarily invincible

Cross Boomerang- Throw it just right and it comes back to you every time

Multi-Shot- Lets you use sub-weapons two, or three at a time

1-up- Gives you an extra life

Enchanted Skull- One of two Legendary Treasures. The Enchanted Skull will grant you enough
                 points to gain many extra lives

Warp Medallion- The Warp Medallion is the second Legendary Treasure. The Warp Medallion
                changes reality around you, flinging you to another part of the castle.

Magic Jar- Refills your health, and ends the level

CHARACTERS:

Armund DeNasty- The hero of this story. Armund is a descendant of Grant DeNasty

Count Olrox- Count Olrox seems to be hiding something about Armund's mysterious past


Special Thanks
-Nintendo
-Konami
-Setz
-Bit Blade
-Dan
-Redrum
-Googie
-Dragonsbretheren
-Mr. P
-Anyone that plays this hack


DISCLAIMER:
Not to be used for profit. I am not affiliated with Nintendo or Konami
I just play a lot of viedo games. I am also not responsible for any damage that occurs 
to your computer due to my hack, but if damage occurs e-mail me and I'll have a good laugh 
about it!