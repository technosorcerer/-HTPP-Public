Cool World (NES)
Traducción al Español v1.0 (11/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Cool World (U) [!].nes
MD5: b9c84310c8c577febfc26b44cbd3e1ef
SHA1: 62b7bf0c95f77e5d49e7f9bf6879c3fe32699416
CRC32: ba898162
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --