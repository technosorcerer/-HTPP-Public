Corre Benny (NES)
Traducción al Español v1.0 (30/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Corre Benny (Spain) (Gluk Video) (Unl).nes
MD5: 555f4591dc1eee05d90a2e90eeb86a3d
SHA1: d20b29414c3f10351b1b55711f23fba192c9eb92
CRC32: c92325a0
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --