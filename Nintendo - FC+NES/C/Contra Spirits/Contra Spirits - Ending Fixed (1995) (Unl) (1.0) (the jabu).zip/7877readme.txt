             Contra Spirits (NES) ending fixed / hack by The Jabu    
             -------------------------------------------------------
      This hack fixes the misspelled "THEND" on the end screen, also changes the text in the intro,
     and fixes the order of the levels.












   Apply the IPS file to  "Contra Spirits (1996) (Unl) [!].nes", and have fun!!!