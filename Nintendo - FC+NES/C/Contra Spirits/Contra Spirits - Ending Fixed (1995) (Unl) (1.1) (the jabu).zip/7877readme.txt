             Contra Spirits (NES) ending fixed v1.1/ hack by The Jabu    
             -------------------------------------------------------
      This hack fixes the misspelled "THEND" on the end screen, also changes the text in the intro,
     and fixes the order of the levels.


    V1.1
  
    - Fixed the problem that caused the sprite to face the wrong way when you jump.

    - The problem with the victory jingle has been fixed. 












   Apply the IPS file with "LunarIPS" to the rom  "Contra Spirits (1996) (Unl) [!].nes", and have fun!!!



Filename: Contra Spirits (1996) (Unl) [!].nes
File SHA-1: C8805D0B3428D4DCEFB6E899112357525C7557A9
File CRC32: CEA432BE
ROM SHA-1: 6DDA48AA919874783A01D120E064CCB22C19D695
ROM CRC32: 814E984A