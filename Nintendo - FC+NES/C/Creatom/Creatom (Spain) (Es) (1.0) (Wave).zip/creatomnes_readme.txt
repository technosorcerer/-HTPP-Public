Creatom (NES)
Traducción al Español v1.0 (30/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Creatom (Spain) (Gluk Video) (Unl).nes
MD5: ed0e7daae8a16777b3a95a2af2696f61
SHA1: 6a6568bbe5db9a6cfa554c736ec259eee6a59b5d
CRC32: 7d43d880
98320 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --