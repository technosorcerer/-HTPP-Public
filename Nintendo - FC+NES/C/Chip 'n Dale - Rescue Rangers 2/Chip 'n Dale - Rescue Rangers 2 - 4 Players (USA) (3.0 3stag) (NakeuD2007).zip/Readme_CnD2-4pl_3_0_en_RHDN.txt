Chip n Dale 2 - 4 players -- CnD2-4pl

Mod/hack adds fourth and third (1-8) players to Chip n Dale 2 (NES, U-version) 
	to make possible to play the game with four (8) people at the same time.

Also: 
Balance: bosses, enemies. Level select. Mini-games select.


------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
CnD2-4pl_3.0	(19.12.19)

Changes:
4 players concept.
8 players concept.
Optional original modification:
	balance of enemies and bosses.
	level select.
Objext limit has been extended to 16.

Bugs:
8pl rom: choose  6 players mod to avoid 8pl bugs.
Stars bonus can reset the game. Wait for timer.
Front sight pollen.
Some exits or buttons are not triggered.
Second phase of the last boss.
Added phase on the boss-lizard at Orig.

Notes:
3 roms: 1) for regular emulator, 2) for moded emulator (Mednafen), 3) for 8pl mod of Mednafen.
Boss-lizard: according to the idea at x2 - many blocks are gained and only then are used.


-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Mod creator: NakeuD2007

Special thanks to: CaH4e3
Thanks to: Doomday


-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
ROM (GoodNes 3.14) SHA-1:
a60ba28aca558fe3527d46b0df33bdd038d4c635 *Chip 'n Dale Rescue Rangers 2 (U) [!].nes
Mod SHA-1:
bc16289dc108fd49161f7677bd733cdf113b56d5 *CnD2-4pl_3.0 regEmul 3stages.nes


-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
CnD2-4pl, BTDD4p and BT4p topic:
www.emu-land.net/forum/index.php/topic,77237.0.html

A few CnD2-4pl, BTDD4p and BT4p-releated videos:
www.youtube.com/channel/UCF3WssHzjr8AZ8Dqi-uXTMQ


-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Possible future hacks:
Ninja Gaiden II: The Dark Sword of Chaos - 4 players.


-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Donate:
PayPal:			paypal.me/nakeud2007
Patreon			patreon.com/nakeud2007