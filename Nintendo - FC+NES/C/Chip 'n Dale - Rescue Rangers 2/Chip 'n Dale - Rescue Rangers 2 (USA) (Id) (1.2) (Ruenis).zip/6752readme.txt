Chip 'n Dale: Rescue Rangers 2
Terjemah Bahasa Indonesia oleh Rue
Patch v1.2


Deskripsi:
----------
Terjemahan Bahasa Indonesia dari Chip 'n Dale: Rescue Rangers 2 untuk Nintendo Entertainment System (NES). Semua teks dialog dalam permain ini telah diterjemahkan sepenuhnya. Untuk bagian grafis sementara ini tidak di terjemahkan.

Terdapat dua file patch dalam berkas ini, pilih salah satu patch antara format ips atau bps. Bagi pengguna Android untuk menerapkan filenya ke dalam ROM bisa mengggunakan UniPatcher atau bisa juga menggunakan ROM Patcher, lalu untuk PC bisa gunakan Lunar IPS, Beat, Floating IPS dan sebagainya. 



Kendali:
--------
D-pad Kiri dan Kanan untuk berjalan
D-Pad bawah untuk merunduk
Tombol A untuk melompat
Tombol B untuk megambil dan melempar balok kayu
START untuk jeda permainan
SELECT untuk melihat status



Berkas dalam ZIP:
-----------------
1. Chip&Dale2(ID).txt
2. Chip&Dale2(ID).ips
2. Chip&Dale2(ID).bps



Informasi ROM:
--------------
No-Intro Name: 
Chip 'n Dale - Rescue Rangers 2 (USA).nes

File MD5:
E78EB3226A9E09113BE319FEE1A84F4D
ROM MD5:
71E7EF754A716CED5B306A1E5B6E93C1
File CRC32:91E4A289
ROM CRC32:FC5783A7



Kontak
------
Apabila ada typo, bug dan semacamnya bisa langsung hubungi saya ke:
https://retro-nesgb.blogspot.com/p/kontak.html
