Castlequest (NES)
Traducci�n al Espa�ol v1.0 (22/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Castlequest (U) [!].nes
MD5: 11ba427c870a7ee72cfbb8e6adad19e1
SHA1: 600b0d2ae76722a62b42be02c0b0becd7ff0a178
CRC32: 5dbb7c78
65.552 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --