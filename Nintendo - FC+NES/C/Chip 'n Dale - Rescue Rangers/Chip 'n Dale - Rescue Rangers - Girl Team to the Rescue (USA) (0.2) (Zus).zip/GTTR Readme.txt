Girl Team to the Rescue
Modded by Zus
V0.2 2016

This is a graphics patch to "Chip 'n Dale - Rescue Rangers (USA).nes"

SHA:	39a5fdb7efd4425a8769fd3073b00dd85f6cd574
MD5:	785b8003d146cdcc9f3df1c29ea18ead

Ever wanted to play as Gadget?
This hack gives you the ability to rush through the game either as Gadget or Foxglove.
Also changed the plot and replaced some text/graphics for consistency.

No changes to the gameplay at all.

Modded by Zus.
October 20, 2016

------------------------------------