=====================
DISNEY'S CHIP 'N DALE RESCUE RANGERS
PATCH BAHASA INDONESIA by Anubis-chan
=====================

-For English readme, please scroll below-

Terima kasih sudah mendownload patch ini. Ini adalah patch bahasa Indonesia untuk game CHIP 'N DALE : Rescue Rangers (USA) v1.0. 

Silakan ikuti langkah berikut ini untuk mengaplikasikan file patch IPS ini:

1. Download ROM game "CHIP 'N DALE : Rescue Rangers" versi US, bisa dicari di situs penyedia ROM game NES. Pastikan sizenya adalah 257KB.

2. Download program IPS patcher seperti Lunar IPS (https://fusoya.eludevisibility.org/lips/download/lips102.zip)

3. Pilih apply patch, dan pilih file IPS bahasa Indonesia, dan pilih ROM game "CHIP 'N DALE : Rescue Rangers" (USA)

4. Bila betul maka semua teks akan berubah menjadi bahasa Indonesia saat dimainkan (tested via Nester, Nestopia & FCEUX).

5. Adapun bagian yang ditranslasi hanyalah:
a. Prolog dan dialog saat cutscene
b. Layar Ending & Copyright.

Bagi yang menemukan bug atau typo, silakan kirim email ke cmartika@gmail.com. Terima kasih!

=========ENGLISH README VERSION=========

Thank you for downloading this patch. This is an Indonesian patch for the "CHIP 'N DALE : Rescue Rangers" game.

Please follow the steps below to apply this IPS patch file:

1. Download the "CHIP 'N DALE : Rescue Rangers" (USA) ROM, you can find it on the NES game ROM provider site. Make sure the size is 257KB.

2. Download an IPS patcher program such as Lunar IPS (https://fusoya.eludevisibility.org/lips/download/lips102.zip)

3. Select apply patch, and select the Indonesian IPS file, and select the Japanese version of the "CHIP 'N DALE : Rescue Rangers" (USA) game ROM.

4. If correct, all texts will change to Indonesian when played (tested via Nester, FCEUX, NESTOPIA).

5. The parts that are translated are:
a. Prologue and Dialogue during cutscenes
b. Ending screen.

For those who find bugs, errors, or typos, please send an email to cmartika@gmail.com. Thank you!