+-----------------------------+
| Chip 'n Dale Rescue Rangers |
+-----------------------------+

  Deutscher �bersetzungspatch f�r Chip 'n Dale Rescue Rangers
  f�r das Nintendo Entertainment System von Tischl.DeckDich.

--------------------------------------------------------------------------------
 Versionen
--------------------------------------------------------------------------------

  Version 1.00: (08.01.2012)
        + Durch blackerking konnte nun auch das "Dale" im Select-Men�
          durch die deutsche Variante ersetzt werden. Vielen Dank!
        + Readme aktualisiert

  Version 0.99: (21.11.2011)
	+ Kleinere Textfehler behoben.
	+ Titelbildschirm �bersetzt (Danke, KillBill_158!)
	+ Readme aktualisiert

  Version 098: (05.11.2011)
	+ �bersetzung aller Dialogboxen. 
	+ Englische Originalnamen durch deutsche Seriennamen ersetzt.
	+ Kleinbuchstaben in den Zeichensatz hinzugef�gt.
	+ Zeichensatz mit Umlauten.
	+ Untertitel des Titelbildschirms �bersetzt.
 
  Bekannte Probleme:
	  
	+ Patch funktioniert nur mit der Europ�ischen, nicht mit der US-Version.
          blackerking hat 2 sfv-Dateien generiert, durch die man feststellen
          kann ob alles seine Richtigkeit hat. 

          Chip 'n Dale Rescue Rangers (E).sfv
          Chip 'n Dale Rescue Rangers (E) [T+Ger1.00_TischlDeckDich].sfv

  Falls ihr noch Fehler finden solltet, dann kontaktiert mich bitte.
  Helfer werden in der Readme erw�hnt, Spiel-Credits gibt es leider keine.
  
  http://snes-projects.de
  http://nuckes.emubase.de/forum
  Tischl.DeckDich [bei] gmail [Punkt] com
 
--------------------------------------------------------------------------------
 Kommentar des Autors:
--------------------------------------------------------------------------------

  Der �bersetzungspatch zu diesem kleinen Spiel ist f�r eine besonders liebe
  Person entstanden. Die bisherige �bersetzung von TOMY (Star Trans) war leider
  nicht wirklich das Gelbe vom Ei, darum habe ich mich spontan f�r eine
  Neu�bersetzung entschieden. Um das Spiel etwas aufzuwerten habe ich dem
  Zeichensatz noch Kleinbuchstaben hinzugef�gt. Leider musste die �bersetzung an
  manchen Stellen etwas gek�rzt oder abge�ndert werden, die n�tigsten 
  Informationen sind aber weiterhin vorhanden.
  
  Wirklich kein gro�es Projekt, aber es hat Spa� gemacht.

  --Tischl.DeckDich (05.11.2011)

--------------------------------------------------------------------------------
 Credits:
--------------------------------------------------------------------------------

  �bersetzung: Tischl.DeckDich
     Grafiken: Tischl.DeckDich und KillBill_158
    Beta-Test: KillBill_158

--------------------------------------------------------------------------------
         [ Nuckes Translations ] [ SNES-PROJECTS ] [TischleinDeckDich]
--------------------------------------------------------------------------------



