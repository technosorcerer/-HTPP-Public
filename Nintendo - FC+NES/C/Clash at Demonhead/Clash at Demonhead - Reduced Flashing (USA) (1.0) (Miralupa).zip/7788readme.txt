Removes title screen flashing, removes super shop cursor and text flashing, removes water and lava animations, remove flashing when magic stone is used, removes flashing related to ending mini-game, and removes pulsing on The End screen.


----------------------------
spoilers below
----------------------------

Details of changes made:

04933: BC -> 60 : removes water and lava animation

0A245: CE0706AD0706 -> A9008D070660 : removes flashing when failing to disarm the bomb

0A2C6: 8E39028E3D028E41028E4502 -> EAEAEAEAEAEAEAEAEAEAEAEA : removes flashing on the bomb countdown

0BFAA: EEAE05 -> EAEAEA : removes flashing on the super shop text

0BFD6: 4901 -> EAEA : removes flashing on the super shop cursor

0EED5: 0F301628300330 -> 16161616161616 : removes title screen flashing

0FDA3: 028538EE -> 0085388D : removes pulsing on The End screen

1988D: 85 -> 60 : removes flashing when using the magic stone at the statue on route 40

198AB: 49 -> 60 : removes flashing when using the magic stone when beneath the ground on route 40