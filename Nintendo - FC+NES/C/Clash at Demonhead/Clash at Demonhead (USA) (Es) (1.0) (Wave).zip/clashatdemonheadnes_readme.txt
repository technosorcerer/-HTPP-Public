Clash at Demonhead (NES)
Traducción al Español v1.0 (12/12/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Clash at Demonhead (USA).nes
MD5: cd319a366a8ab61df05b020a64809321
SHA1: cd484ab73278d8d58e8068ccdceac6eefba12f68
CRC32: ef1c8906
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --