Crisis Force (NES)
Traducción al Español v1.0 (13/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Crisis Force (J) [!].nes
MD5: 4cda9b5f7d06f336a3434c9e1adc1c2e
SHA1: 9603210def5a0fe251d0dd48ebb82728ad626d88
CRC32: c4520781
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --