Castle Excellent CNROM to MMC3 (NES)

Hacked by Andrei Vdovin a.k.a. Chronix
Email me if you find any glitches in my hack.
Thanks in advance!
chronix@bk.ru

Changes:

* This patch converts Castle Excellent (J) mapper from CNROM to MMC3.
* Start with 50 lives (like in Castlequest)

Original ROM:
-----------------------
Castle Excellent (J).nes
File size: 65 552

 PRG ROM:    2 x 16KiB
 CHR ROM:    4 x  8KiB
 ROM CRC32:  0x7fa2cc55
 ROM MD5:  0xa437cb8f2794d8e61458820c13154157
 Mapper #:  3
 Mapper name: CNROM
 Mirroring: Vertical
 Battery-backed: No
 Trained: No