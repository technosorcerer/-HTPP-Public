Cosmo Police Galivan (NES)
Traducción al Español v1.0 (06/03/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en el de Jair.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Cosmo Police Galivan (Japan).nes
MD5: cdf1f060f467f88c25eb3efb783541e2
SHA1: 6f38d0ada341f86f3055f689dd0f90c62556d91e
CRC32: bccada80
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --