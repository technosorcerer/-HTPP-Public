Code Name - Viper (U)  (NES)
Persian Translation Patch

� 2022 by Hossein Kashani 
noshigan@Gmail.com


The translation of this game was done completely. It took me a long time to finish the translation, fortunately 
I succeeded.
I hope you enjoy this game

=====================
Version Info
=====================
Version              1.0
Release Date      11 Jun 2022
Status                100% Translated

=====================
Patching Instructions
=====================
1. Download Lunar IPS 
2. Apply CNVP.ips to the Code Name - Viper (U) [!].nes
3.CNVP  (CODE NAME VIPER PERSIAN)
4. Enjoy!

=====================
Original USA ROM Info
=====================
File SHA1	C166841D70F5F2DD31BA20CFE13E299E8BCD5F1E
ROM SHA1	C6475BEAE0944727076469129227CC04299F3FF6
File MD5	1B70B0A227A96E267B78E8953A03F8E1
ROM MD5	D2CAAD88069BCB713EE13505EF0F801D
File CRC32	27254C10
ROM CRC32	DB64482
PRG-ROM:      128k
CHR-ROM:      128k

And finally special thanks to the Stargazers, without their help, how could we have succeeded?