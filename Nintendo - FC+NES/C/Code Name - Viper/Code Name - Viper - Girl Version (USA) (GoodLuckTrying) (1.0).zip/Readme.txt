The Human Weapon: Dead Fox Girl Edition v1.0 - by GoodLuckTrying (https://github.com/GoodLuckTrying)

This is an addendum to BlackPaladin's English Re-Localization

The original girl sprites were made by someone who went by AmidE.

Their work is no longer legally obtainable—only old patched ROMs remain online.

Because of that, this addendum patch came to be to make the sprites compatible with BlackPaladin’s 1.0 re-localization of the game.

**How The Addendum Patch Works**

The patch is meant to be applied on top of a ROM that has already been patched with BlackPaladin 1.0’s translation.

The patches provided are:
- Addendum Patches [To use on Rom already patched with BlackPaladin's patch]
  - The Human Weapon – Dead Fox – Girl Version.ips
  - The Human Weapon – Dead Fox – Girl Version.bps

Both expect a translated ROM, not a clean one.

Required ROM (After Applying BlackPaladin’s Patch):
File SHA-1: C71699B048598A151ABB93A7BE20C236208BA327
File CRC32: DCC8C8E3
ROM SHA-1: 69AD9968DFFAC202AADCEF2DBDE51AF019E8DC7A
ROM CRC32: 1C003AC

**Standalone Patch Option**
GoodLuckTrying also provides standalone patches that can be applied directly to the original U.S. Code Name: Viper ROM, and these already include BlackPaladin's 1.0 translation.

The patches provided are:
- Standalone Patches [For USA Rom]
  - The Human Weapon - Dead Fox - Girl Version.ips
  - The Human Weapon - Dead Fox - Girl Version.bps

These expect this clean ROM:
Database match: Code Name - Viper (USA)
Database: No-Intro: Nintendo Entertainment System (v. 20210216-231042)
File SHA-1: 4C86AE577454B6DE9A3FE48ACBB7F095C8B82D3B
File CRC32: 5988DA29
ROM SHA-1: 220939191A48FB2CF3A73C8FD713A60AD2EE34DF
ROM CRC32: E2313813

**Addendum vs. Standalone Patches**

It is advised patching with the addendum version, because:
- The Addendum patches are designed to be applied on top of BlackPaladin’s own patch files.
- If BlackPaladin ever updates his translation (e.g., fixes typos, adjusts text, adds improvements), my Standalone patch will immediately become outdated because it contains the old 1.0 version of his work.
- The Addendum patches, on the other hand, will continue to work simply by applying them over the latest version of his translation, making them future-proof.