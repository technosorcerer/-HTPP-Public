Code Name - Viper (NES)
Traducción al Español v1.0 (26/06/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Code Name - Viper (USA).nes
MD5: 0c4e15d7a4683f18a0ec7d1c3a14172e
SHA1: 3f7428865ea2e95632e32e8c3638207fed12bb52
CRC32: c8a23081
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --