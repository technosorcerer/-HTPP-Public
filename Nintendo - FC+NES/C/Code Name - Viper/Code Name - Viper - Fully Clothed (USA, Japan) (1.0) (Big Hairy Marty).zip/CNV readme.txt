Code Name Viper - Fully Clothed hack
Modified by Big Hairy Marty


In the original Code Name Viper, the main character looks like he isn't 
wearing anything below the waist except his shoes, due to the fact his 
trousers are the same colour as his skin. This modification changes it 
so that his trousers match the rest of his combat gear.


This download contains patches for both the American and Japanese versions.


If you wish to, you may follow me on twitter here.
http://www.twitter.com/bighairymarty/
