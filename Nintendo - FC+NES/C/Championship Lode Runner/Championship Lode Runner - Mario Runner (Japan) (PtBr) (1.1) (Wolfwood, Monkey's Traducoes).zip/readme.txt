---------------------- Informa��es ----------------------

Nome do jogo: Mario Runner by Y.Project (Championship Lode Runner Hack).
Plataforma: Nintendo Enternament System.
G�nero: Estrat�gia / Plataforma.
Vers�o da Rom: Japonesa (J).
CRC32: CFA85F7C.
Lan�amento da Patch 1.1: 02 de Julho de 2009.
Status: 100%
Grupo de Tradu��o: Monkey's Tradu��es.
Respons�vel: Wolfwood.
E-mail: ikkidefenixalemao_@hotmail.com

---------------------- Observa��es ----------------------

O patch � para ser inserido na ROM: Championship Lode Runner (J).

---------------------- Inserindo o Patch ----------------------

Leia a seguinte documenta��o:
http://www.romhacking.trd.br/index.php?topic=5095.0