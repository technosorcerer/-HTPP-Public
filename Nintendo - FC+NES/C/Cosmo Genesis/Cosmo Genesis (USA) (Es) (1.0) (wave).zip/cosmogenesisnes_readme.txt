Cosmo Genesis (NES)
Traducción al Español v1.0 (05/12/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en el de Aeon Genesis.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Cosmo Genesis (Japan).nes
MD5: 4ec83b7883dbf58e2118626f66b87e0a
SHA1: a0c0c76c25e40a4f573fe3d46d0cfa483faf57c2
CRC32: d5c8ee20
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --