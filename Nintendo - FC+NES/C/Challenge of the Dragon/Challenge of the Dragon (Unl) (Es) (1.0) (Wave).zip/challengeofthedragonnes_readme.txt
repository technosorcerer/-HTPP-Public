Challenge of the Dragon (NES)
Traducci�n al Espa�ol v1.0 (16/03/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Challenge of the Dragon (Color Dreams) [!].nes
MD5: 2f5c2cd43bbad1b5c66240f678f62494
SHA1: 0c150d01f7344775358d2fdd40c494fb39ba7548
CRC32: e737a11f
131.088 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --