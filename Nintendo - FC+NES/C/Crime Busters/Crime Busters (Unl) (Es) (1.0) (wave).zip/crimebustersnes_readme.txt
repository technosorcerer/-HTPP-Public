Crime Busters (NES)
Traducción al Español v1.0 (18/05/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Crime Busters (Unknown) (Unl).nes
MD5: 04fcb819539910ad1ee79f5b1fa11abe
SHA1: 434341fd20b215ebf4ebf9d6d9ca51345079d33a
CRC32: 86c7d81e
163856 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --