Hi, if you encounter any glitches, bugs, or typos (most spacing typos are intentional and due to limitations),
let me know!

thank you for trying this dumb little hack out <3