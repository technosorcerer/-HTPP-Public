Start with 0 hearts.
All weapon, subweapon damage lowered except for Alucard.
Monsters life increased and or adjusted.
All characters take increased damage.
Throwing dagger does as much damage as axe or boomerang.
Boomerang costs 2 hearts.
Holy Water damage reduced to 1/3, costs 2 hearts, no double/triple shot.
Ice magic can damage bosses, costs 2 hearts.
Lightning magic costs 3 hearts.
Double, triple shot removed from monster drops.
Added, changed some monster locations.
