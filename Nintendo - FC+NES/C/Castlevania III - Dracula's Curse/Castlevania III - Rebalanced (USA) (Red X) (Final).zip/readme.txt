This patch attempts to make all 4 characters in the game strong enough to 
beat the entire game on their own. You must use a headered ROM for the
patch to work.

Character Changes

Trevor
Leather whip does 50% more damage 
Chain whip   does double damage
Dagger does 50% more damage

Cross costs 2 hearts
Holy Water costs 2 hearts
Watch costs 3 hearts

Grant
Attack does  50% more damage
Dagger does 100% more damage than Trevor's dagger
Grant axe    33% more damage than Trevor's dagger

Syfa
Ice Spell Freezes enemies and water areas about twice as long as before
Ice Spell does as much damage as leather whip against bosses, it can hit
multiple times if you are close enough to the enemy. 
Fire spell is removed from game, instead ice and lit spells are more common

Alucard
Fireball does double damage
Heart consumption of bat form reduced by 50%

Other Changes

Defense
Alcuard and Trevor can take 1 more hit before dying in the final few stages

Changes to Double/Triple
If you have Holy Water, you can't get double
Grant can't get double
Triple is removed from the game


This is the final version of this patch. If you have any comments or issues
please email me at sethmjackson@gmail.com
