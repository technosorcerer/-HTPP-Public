Castlevania III: Dracula's Curse (Enhanced Colors)
This patch improves many of the color palettes in this game to make it look better by removing bright colors in the backgrounds! This 1.2 update fixes color bugs on some stages, and adds new stage tiles.
In IPS format, you can use LunarIPS or Floating IPS.
File used:
Castlevania III: Dracula's Curse(USA)

The IPS patch must be used on a Nes ROM