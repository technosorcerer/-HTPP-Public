Castlevania III: Curse of the Moon Hack ROM by TheLV, Richter Rizer and Red X

List of changes (ENGLISH)
(-) means both versions
(CV3) means CV3 US only
(AD) means Akumajou Densetsu only

*Visual/Graphics
-All four Bloodstained Curse of the Moon characters with prefixed colors, 4 colors (CotM) to 3 (NES)
-Character portraits
-Animated endings (Miriam and Gebel)
-Characters Meeting (buggy in AD)
-Enhanced ''HUD''
-Subweapon icons
-Double and Triple changed to Moon icons.
-Enemies from CotM (Medusa, Zombie, wall dragon, Bloodless boss, Gremory...)
-Recolor for enemies
-Recolor for all stages (Different recolor per version)
-New Castle Keep Moon (Different per version)
-Special ''candles'' for subweapons.

*Gameplay/Mechanics
(CV3) Curse severity: Miriam and Gebel (3 HP in all levels), Alfred and Zang (3 HP in early and mid levels, 4 HP in later levels)
(AD) Curse severity: Miriam and Gebel (3 HP for all enemies), Alfred and Zang (3 HP for weak and mid enemies, 4 HP for strong enemies)
-Double easier to get, Triple only can be obtained in Walls.
(CV3) Increased Weapon consumption in Bat form
-Increased ''price'' for subweapons: Dagger 2, Axe 3, Dark flow 4 (5 in AD), Scythe 4 (5 in AD), Stopwatch 5, Ice 4, Fire 4 (5 in AD), Lit 4 (6 in AD)
(CV3) Damage modifiers (I.E. Miriam/Zang can kill Bloodless boss in 11 hits, Alfred/Gebel in 16 hits): Leather whip 49, Chain whip 60, Alfred staff 49, Zang sword 50, Gebel 29 per hit (up to 3 hits), Dagger 60, Axe 60, Dark Flow 20 per hit (up to 6 hits), Scythe 60 per hit (up to 2 hits), Ice 60 per hit to bosses (up to 6 hits), Fire C0, Lit B0 per hit (up to 3 hits).
-Added shortcuts.
-Different and more enemies in the worst places possible.
-Harder pre-pendulums room.

*Extras
(CV3) New Prelude, Meetings and Endings.
-1UP in harder places/check-points (Water Dragons, Sunken City, Leviathan in Alucard path, Doppelganger, Clock tower 2/Pressure, etc.)
-Subweapons Hall in specific places, choose wisely.
-Cheats: Gebel attack in stairs RAM patch 0086:0A and 0088:01, enable ONLY when you have Gebel as ally and use it as subweapon, Miriam long whip 008E:02, Gebel 3 fire balls 008F:02
-Update v 1.1 enhanced Miriam, Zangetsu and Gebel sprites, fixed wrong warp in Sunken City (US), fixed door glitch in Cause Way (AD), harder pre -pendulum room in USA version, removed debug mode.
-Update v 1.2 new tiles in Deja Vu and riddle, modified Castle Keep moon (from Stage 9), NO more updates to AD (at least in level layout, issues with revamp.)
-Update 1.3 (US only) Ship of fools with CotM graphics, restored colors in clock tower, removed auto scroll in Clock tower 1, increased Gebel attack, cheaper sub-weapons.

*ROM: Castlevania III - Dracula's Curse (U) [!]
Akumajou Densetsu (J)
 
Colors may change from emulator to emulator, FCEUX was used for recoloring (unfiltered).

CV3 to CotM 'team''
TheLV (Hacking, Sprite reworks, testing)
Richter Rizer (Zangetsu sprite rework)
Red X (Internal code)