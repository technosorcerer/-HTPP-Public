Version 1.2

Added a Japanese harder mode patch.
All weapon damage adjusted.
All monsters life adjusted.
Bone Dragon, Bone Pillar, and Axe Knight get a small life increase.
All bosses have increased life, and a small damage increase.
Sypha Ice Magic damages bosses, staff damage lowered.
Alucard does the 3rd most damage for companions.
Grant is still good, but has the lowest dps of the 3 companions.
All enemy attacks do an additional bar of damage.
Difficulty is about on par with the US version maybe slightly harder.

Version 1.1 

US patch only.
Alucard damage lowered 1 point.
Some monster's life lowered 1 point.
A few more map changes to bring it more inline with the Japanese version.
Tweaked Alucard bat form heart costs.

Version 1.0

Alucard Better fireballs, increased damage both patches, and bat form costs less hearts in US patch.
Grant throwing dagger damage increased US patch only.
Trevor dagger damage increased both patches, holy water damage adjusted to JP version for US patch.
Syfa Ice Spell can damage bosses now both patches.
Added, changed a few Subweapon drops so it's closer to the Japanese version for the US patch.



