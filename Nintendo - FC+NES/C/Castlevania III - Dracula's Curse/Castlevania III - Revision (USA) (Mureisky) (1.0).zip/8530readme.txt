Alucard Better fireballs, increased damage both patches, and bat form costs less hearts in US patch.
Grant throwing dagger damage increased US patch only.
Trevor dagger damage increased both patches, holy water damage adjusted to JP version for US patch.
Syfa Ice Spell can damage bosses now both patches.
Added, changed a few Subweapon drops so it's closer to the Japanese version for the US patch.
There's patches for both the US, and Japanese version of Castlevania 3.


