Version 1.9

Added Grant skip to falling block area Block 7-05.
Fixed slowdown in Akumajou Densetsu Block A-01.
Updated COTM style candles.
Removed hard mode patches.
Added optional patches to increased Dagger speed.
Added optional patch to convert Subweapon candles in US to be closer to the JP version.

Version 1.8

Alucard Fireball Delay Fix
Lowers the delay on Alucard shooting a Fireball to that of other Subweapons.

Fire Spell Less Delay Fix
Sypha's Fire Spell now has the same delay that Ice, and Lightning have.

Adjusted speed on Oak Stake Holy Relics Dagger.
Fixed a few of the boss exploits for the hard mode patches.
Adjusted Akumajou Denesetu hard mode Boss HP's so you do only 1 bar or 1/2 bar of damage.
Few bug fixes.

Version 1.7

Made hack more customizable like my Improvements hack. Should work with most other hacks that exists.

Alucard/Grant/Sypha AD Patch
Lets you start with any of the 3 partners. Kind of like using the US passwords for the Japanese version.

Alucard Fireball Damage
Increases Alucard's Fireball damage US only, and adjusts monster HP for Alucard's Fireball damage.

Alucard Fireball Revision
Alucard's Fireballs are less spread out.

Bat Form Less Hearts US Patch.
Lowers the rate that Alucard's Bat Form drains your Hearts.

Better Ice Magic
Ice Magic now damages monsters including bosses.

Bloodlines COTM Style Subweapon Candles.
All Subweapons are stored in different kind of candles to differentiate them from other candle drops.

Dagger Increased Damage
Increases Throwing Daggers to do the same damage as non Holy Water Subweapons.

Dagger Less Delay
Daggers have slightly less delay when you throw them.

Help Me AD Patch.
Starts with 9 lives kind of like using the Help Me password for the Japanese version.

JP Holy Water US Patch
Lowers US Holy Water damage to the same that the JP version has.

Oak Stake Holy Relics Style Trevor Dagger.
Trevor can throw a slower, but more powerful Dagger that does increased damage.

Piercing Daggers.
Throwing Daggers can pierce through monsters like all other Subweapons.


Version 1.6

All Subweapons are contained in lantern drops except for the Ghost Ship where there stored in candles. Similar to how it works in Castlevania Bloodlines, and Bloodstained Curse of the Moon.
A few minor bug fixes.

Version 1.5

US Version

Normal Version
Ice, and Lightning Magic cost 2 hearts for normal version.
Throwing Daggers can pierce like all other Subweapons.

Easy Mode Patch
Optional patch that should work with most other hacks, and vanilla rom.
Trevor/Alucard take 2 damage early mid levels, and 3 damage for late levels.
Grant/Sypha take 3 damage early mid levels, and 4 damage for late levels.
Lowered lifebars of Axe Knight, Bone Tower, and Bone Dragon to the Japanese/Europe values. 

Hard Version
Based on normal version.
Holy Water, Alucard Fireball damage lowered 1.
Fire damage lowered 4.
Lightning damage lowered 6.
All characters take an additional 1 lifebar of damage.
Most Bosses non magic damage only does 1 lifebar of damage.
Few Bosses weapons deal only 1/2 a lifebar of damage.
Boomerang, Holy Water, Ice cost 2 hearts, Lightning costs 3 hearts.
Double/Triple Shot removed from monster drops only found in walls.
Holy Water has no Double/Triple Shot.

Japanese Version
Ice, and Lightning Magic cost 2 hearts for both versions.
Whip, Staff, Grant Dagger damage reverted back to vanilla damage for the normal patch.

Version 1.4

Japanese non hardmode patch only.
Lowered Trevor's Whip, Grant's Throwing Daggers, and Syfa's Staff damage by 1.
Alucard Fireball damage reverted back to 1 damage.
Adjusted some monster's life values due to the above changes.

Version 1.3

Improved better Alucard Fireballs.

Version 1.2

Added a Japanese harder mode patch.
All weapon damage adjusted.
All monsters life adjusted.
Bone Dragon, Bone Pillar, and Axe Knight get a small life increase.
All bosses have increased life, and a small damage increase.
Sypha Ice Magic damages bosses, staff damage lowered.
Alucard does the 3rd most damage for companions.
Grant is still good, but has the lowest dps of the 3 companions.
All enemy attacks do an additional bar of damage.
Difficulty is about on par with the US version maybe slightly harder.

Version 1.1 

US patch only.
Alucard damage lowered 1 point.
Some monster's life lowered 1 point.
A few more map changes to bring it more inline with the Japanese version.
Tweaked Alucard bat form heart costs.

Version 1.0

Alucard Better fireballs, increased damage both patches, and bat form costs less hearts in US patch.
Grant throwing dagger damage increased US patch only.
Trevor dagger damage increased both patches, holy water damage adjusted to JP version for US patch.
Syfa Ice Spell can damage bosses now both patches.
Added, changed a few Subweapon drops so it's closer to the Japanese version for the US patch.

double block

block
brown
brown
block
brown
brown
brown

