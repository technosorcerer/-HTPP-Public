Castlevania III: Dracula's Curse (enhanced colors)
This patch improves many of the color palettes in this game to make it look better, eliminating the dull colors in backgrounds and sprites! This update 1.1 fixes color errors of some stages, title screen and password, adds new sprites for skeletons , zombies and our protagonist
In IPS format, you can use LunarIPS or Floating IPS.
File used:
Castlevania III: Dracula's Curse

The IPS patch must be used on a Nes ROM