"Cross Fire"
Traducci�n al Espa�ol v1.0 (23/03/2017)
 POR JONYVILLA2088

---------------------------
1. Sobre Cross Fire
2. Notas del Proyecto
3. Fallos
4. Instrucciones de Parcheo
5. Derechos
---------------------------

---------------------
1. Sobre Cross Fire
---------------------
"Cross Fire" fue un juego hecho por kyugo en 1990 basado en algo parecido a Metal Gear.
El personaje de esta trama es Eric, un soldado que lucha contra el mal en diferentes lugares de Vietnam hasta Shatol(son 6 niveles).
Conforme gana arma o medallas su barra de vida aumenta (ya que comienzas con pu�os y granadas).
---------------------
2. Notas del Proyecto
---------------------
ESte juego fue traducido al 98%, ya que algunas cosas no fueron traducidas sea texto por hexadecimal o por gr�ficos.
No conten�a tantos textos solo cuando ganas el juego y otros datos.
Las palabras Press GAME OVER, ROUND 1-6, no se han podido traducir (al menos mediante tablas). 
--------------------------------------------
3. Fallos Conocidos
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a jonathanjavier208@gmail.com 

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Debes utilizar el rom:

Cross Fire (U) (Prototype) [!].nes recomiendo buscarla en la p�gina: https://www.freeroms.com
-----------
5. Derechos
-----------
Cross Fire (U) (Prototype) NES es propiedad de Kyugo (c) 1990.
Traducci�n al espa�ol por JONYVILLA2088.
No distribuir la rom y el parche unidos.

Saludos y que disfruten del juego.
