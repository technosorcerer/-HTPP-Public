Cross Fire
De-Engrish Hack V 1.0
Copyright 2009 by The Stardust Crusaders
yojimbo.eludevisibility.org

Table of Contents

1.About Cross Fire
2.Patch History
3.Patch Credits
4.Known Issues

---------------------------
1.About Cross Fire
---------------------------
This game appears to be some sort of a Metal Gear/Rambo rip-off. I guess you basically go around the world fighting terrorists and blowing shit up. Anyway one of the bosses is really out of place and that's about all I can think of.
---------------
2.Patch History
---------------
What's done:

-Everything

---------------
3.Patch Credits
---------------

Me- Hacking

--------------
4.Known Issues
--------------
None

--------------
5.Contact
--------------
Comments and questions can be sent to

yojimbogarrett at gmail dot com 

or at my site

yojimbo.eludevisibility.org
