Completed translation of Chaos World (NES)

Based on Aeon Genesis Translation.
Made by Andrei Vdovin a.k.a. Chronix.
Email me if you find any glitches in this game.
Thanks in advance!
chronix@bk.ru

All ingame text was translated.
Main font was improved.
All bugs were fixed.

Enjoy this NES RPG gem!!!
