"City Adventure Touch: Mystery of Triangle" 
Traducci�n al Espa�ol ver 1.0 (07/05/2018)
por Max1323.
 Basado en la traducci�n al ingl�s de 
 filler (Traducci�n) y supper (Hacking). 
---------------------------------------------------
Agradecimiento:
Gracias a Wave y a su programa pude llegar a terminar la traducci�n del juego, la traducci�n la tenia a un 2% desde hace 3 meses, pero gracias a su programa pude hacerlo en 6 d�as.
Gracias Wave.

P�gina de Wave: http://traduccioneswave.blogspot.com.es/
---------------------------------------------------
Descripci�n:
City Adventure Touch: Mystery of Triangle lanzado el 14/03/1987 para la Nintendo Famicom desarrollado por Compile y distribuida por Toho exclusivamente en Jap�n.
Basado en los personajes del manga "Touch", por Mitsuru Adachi.
El objetivo del juego es salvar a 10 cachorros, pero para eso, vas a tener que buscar y recolectar objetos por los distintos pueblos, y pelear contra todo tipo de enemigos y jefes. 
---------------------------------------------------
Acerca del Proyecto:
Se tradujo el texto del juego, pero puede que algunas partes esten cortadas, ya que el m�ximo de palabras es de 10 por cada fila.
Ademas hay textos que no llegue a ver, porque hay calles donde conecta con otra, puede que una calle este bloqueada o
que haya lugares secretos.
---------------------------------------------------
Gu�a:
Como hay muchas calles en el juego y no tuve un mapa como para saber donde estoy, les dejo la gu�a del juego.

https://www.youtube.com/watch?v=DQr1YhbXADw

---------------------------------------------------
Fallos:
Si llega a pasar en cualquier caso, pueden contactarme a maxmuruchi@gmail.com
---------------------------------------------------
Instrucciones del Parche:  
Utilizar Lunar IPS

File MD5    04A16A549EAE62B9172CE9839BF5016C
File SHA-1    82BCC1BCCDCF3CC393A22C9E3016D03FAF5A41BC
File CRC32    8B3D3804
Tama�o 128 KB