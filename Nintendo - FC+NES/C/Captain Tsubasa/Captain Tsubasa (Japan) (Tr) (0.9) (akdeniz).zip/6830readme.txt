This patch is akdeniz's Turkish translation work for Captain Tsubasa/Tecmo Cup Soccer Game (J)

Game scenes are properly translated. There are a few missing parts(some cutscenes and rare strings) that won't affect gameplay. 

Fully playable version is soon...

Thanks to Hikaru Matsuyama for some cutscene translations in his game analysis.
Thanks to DevilTi for his translation for foreign names in Katakana.

My personal website:
http://zamanlar.sozdesozluk.com/

Our Captain Tsubasa forum:
http://tsubasa.sozdesozluk.com/