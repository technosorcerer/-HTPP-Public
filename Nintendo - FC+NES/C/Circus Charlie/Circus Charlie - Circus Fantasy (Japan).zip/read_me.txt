				Rom Hack Info

NAME OF HACK -			 Circus Fantasy
NAME OF ORIGINAL -		 Circus Charlie
NAMING CONVENTION -		 The rom is a .nes and the patch is a .ips
SYSTEM-				 NES
E-MAIL ADDRESS-			slanderton@hotmail.com
WEBSITE-			http://www.geocities.com/snorrisage
OTHER INFO-			Nothing significant.