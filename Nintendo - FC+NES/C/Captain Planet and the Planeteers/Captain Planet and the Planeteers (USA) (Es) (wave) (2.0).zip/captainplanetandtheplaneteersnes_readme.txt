Captain Planet and the Planeteers (NES)
Traducción al Español v2.0 (13/07/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Traducido subtítulo de la pantalla de título
-Traducida licencia y créditos iniciales
-Añadidos caracteres españoles y guion revisado
-Cambiado PASSWORD por CLAVE
-Traducido SCORE en menú de pausa
-Traducidos gráficos ELEPHANT RESERVE
-Traducidos poderes al invocar al Capitán Planeta

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Captain Planet and the Planeteers (USA).nes
MD5: f16f442f364331e8019bdbc292c0aca8
SHA1: 8b399632ccbb98104864ef5163f7cffdea99d802
CRC32: 21d34187
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --