Chubby Cherub (NES)
Traducci�n al Espa�ol v1.0 (02/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Chubby Cherub (U) [!].nes
MD5: 52c6aff708fa0578d56531cbaf387d2a
SHA1: 0b4ee7ff417f28a7fac603f6273f24cda985cfa8
CRC32: 90f12ac8
40.976 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --