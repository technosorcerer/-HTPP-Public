----------------------------------------------------------------------------------
-BlackPaladin's "Super Planetary War Chronicle - Metafight" NES Translation Patch-
----------------------------------------------------------------------------------

******************************
*Chou-Wakusei Senki Metafight*
******************************

I was taking a brief break from one project when I decided to take this little project on.  It's a simple title screen translation patch for Metafight.  For those who don't know, this game was localized and moderately edited under the name "Blaster Master".  

So, there's no frog named Fred.  There's no mutants buried underneath Earth.  This takes place on a faraway planet called "Sofia the 3rd" in the Espilon Galazy, where the Ivem Dark Star Army, ruled by Goez wants to take over the planet.  However, a tank called "Metal Attacker", piloted by Kane Gardner (His name wasn't "Jason") was fight the evil army and save "Sofia the 3rd".

The patch comes in two flavors...

Super Planetary War Chronicle - Metafight (English).ips
--This patch requires a clean and unaltered Metafight NES ROM (IPS Format)
Super Planetary War Chronicle - Metafight (English).bps
--This patch requires a clean and unaltered Metafight NES ROM (BPS Format)

Be sure to use either patch to the following NES ROM (with a header) with the following hashes...

File SHA-1: DB2E5EE4DCB76416F1075FC9EF9CCF2DB279899F
File CRC32: FF02811A
ROM SHA-1: 9DC65B4848FFBB9E6D23986D1987803E7250337C
ROM CRC32: 39B4A9C

After applying either patch, it should have the following hashes. (Don't use both patches.)

Database match: not found
Database: No-Intro: Nintendo Entertainment System (v. 20210216-231042)
File SHA-1: 18F9898EA014D708517DF29584F6054DC8889EFD
File CRC32: 7EAF843C
ROM SHA-1: 0DFBEEDB1EC477F0F92AE891D33EBDD8E006DB2F
ROM CRC32: 82364FBA

What has been translated?

The title screen... that's it, really.

1.0

Initial Release

Special Thanks:

FCE Ultra Team (Used their hex editor)
YY-Char Team (used this for edited graphics)

All credit to "Chou-Wakusei Senki - Metafight" belong to Sunsoft and their respective creators and programmers.  This patch is mainly for pure entertainment for those who cannot enjoy the game.  All rights reserved.  (Sunsoft, please don't come after me!)