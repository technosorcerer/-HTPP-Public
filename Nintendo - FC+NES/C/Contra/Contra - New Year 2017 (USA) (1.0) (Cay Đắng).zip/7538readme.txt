Info File
Name Contra New Year 2017
魂斗罗2017金鹰贺岁版
Contra 2017 Golden Eagle Lunar New Year Edition

Author: Jin Ying He Sui , Natsu Time
-Faster enemies, more HP
-Color change, mainly yellow
-Increased gameplay and difficulty
- Enemies bigger bullets, stage 3 is horizontal
Hack make in china
Gmail caydang254