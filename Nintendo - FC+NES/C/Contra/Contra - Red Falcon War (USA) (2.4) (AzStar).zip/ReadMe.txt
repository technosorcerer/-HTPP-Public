﻿
该系列为红隼战争系列，为红隼战争简单版以及其延后的几个带有Trax游戏风格新改版。
其难度也是有分级的，我在rom名称上面都有标，或者你可以依照1，2，3这个顺序理解它们的难度排序。但其实玩法都是一样的，射击，考验你的反应。
简单版的都是基于原版修改了地形，没有做出其他改变。
迷你版的也是基于原版修改了地形，但是添加了Trax以前提供的Hard Mode IPS。
红隼战争是基于红隼的复仇为基础版本进行修改的版本，除了修改地形以外，还添加了一些新的代码。

This series  is the "Red Falcon War Series",contained with the easy ver. and several new versions inspired by Trax. 
There are some level marks on the rom's name,and you can make out the difficulty by the order "1-,2-,3-".However,All of them are still the same playing,just shoot and test your reaction.
In the easy version,just did some map and enemy's position hack.
In the mini version,patch a Hard Mode IPS by Trax.
"Red Falcon War" is a hack based on the "Revenge of the Red Falcon".Besides,it contained some new stuffs.

版本介绍：

Introduction:

红隼系列简单版：
玩法，敌人属性等和原版一样。此处就不多作文章了。

Easy version:
Except some map and enemy's position hack,same as the original version.

红隼系列迷你版：
1.地形和简单版一样，或许有些有小部分修改；
2.敌人位置基本一样，或许有些地方有新增的敌人；
3.敌人攻击方式变强了，子弹变快了；
4.修改了3D关卡的boss页的炮台攻击方式;
5.增加了第五关炮车的新的攻击方式。
6.玩家的初始子弹和F弹在一个屏幕内都可以发射8发（原版只能4发）
7.带上S弹的玩家时，有些敌人攻击方式会变得更强，或者说频率更高。

Mini ver.
1.Map:same as the easy ver..May have some redesigns.
2.Enemy:same as the easy ver..May add some new in some places.
3.Enemy attacks frequently and quickly.
4.Modifies the attack of the Triple Cannon.
5.Adds the new attack of the Tank.
6.Increases the normal/F weapon shooting bullets.
7.when you use Weapon S,some enemies will become more frequently attacking.

红隼战争V1.0：
1.可以视为每个关卡为迷你版的完整版，会变得很长，你甚至可以在关卡中试图寻找和迷你版一样的地形。
2.部分敌人攻击方式有些修改，其他同迷你版攻击方式。
3.Nerf了带上S弹的玩家时游戏的难度Buff。

Red Falcon War ver1.0:
1.You can consider it as the full version of the mini ver..
2.Modifies several enemies attack.
3.Decreases the enemy's buff when you're using Weapon S.

红隼战争V2.1：
1.在1.0的基础上给第七关增加了难度（修改了地形并且在路程中安放了Boss页的炮台）（By CZX）
2.添加了双枪和B装保留系统。(使用选择键可以换枪，每个玩家只能带两把枪，可以随时切换，当你被敌人子弹击中时，你会失去当前使用的枪，另外一把枪不会失去；当你获得B弹的时候，你不会像原版一样立即使用B，该系统会把B存起来，当你要使用或者说激活B时，你长按选择键1-2秒松开，B将激活，每个玩家只能存一个B，如果一个关卡有两个B，那么你应该在第二个B出来之前先把第一个B使用掉，否则你获得了新的B和没获得没什么区别。PS：如果你存有而没有使用而被敌人子弹击中了，那么你仍然可以使用B，你甚至可以存着B到其他关卡使用)(By MagusLOGS)
3.修改了双人模式的屏幕移动。

Red Falcon War ver2.1:
1.Adds some Mortar Launcher on the path.(IPS By CZX)
2.Adds a Secondary Weapon Slot for both players and the ability to activate Barrier when ever you want.
(Switch to Secondary Weapon Slot: Press [select] 
Activate Remote Barrier: Hold [select] for more than 2 seconds, triggered on release)(IPS by MagusLOGS)
3.Modifies the 2P mode screen moving.

红隼战争V2.4：
1.修改了1，3-7关一些地形设计。
2.修改了第6关的地板颜色。
3.恢复双人模式的屏幕移动。
4.6-8关有一些隐藏的武器补给，试试看能不能找到XD。

Red Falcon War ver2.4:
1.Modifies some level designs of the Stage 1 and Stage 3-7.
2.Modifies some colors of the Stage 6.
3.Restore the modification of the 2P mode screen moving.
4.There are some weapons hidden in Stage 6-8,try to find them out.XD

在此感谢基础版本作者Trax，
解锁第七关炮台终止页限制的CZX，
制作出双枪系统的Magus，
以及提供给简单和迷你版编辑的编辑器的零晨星光.
以上，希望对你有所帮助，祝你游戏愉快。

Special Thanks for 
Trax(Orig. Hack's Author and Editor Provider),
CZX(Facilitator,Editor Provider,Title Modifier and IPS Provider),
Magus(IPS Provider),
Welicn(Guider and Editor Provider).
That's all,thanks for playing.

2019-10-20 Az星に/AzStar(tie)