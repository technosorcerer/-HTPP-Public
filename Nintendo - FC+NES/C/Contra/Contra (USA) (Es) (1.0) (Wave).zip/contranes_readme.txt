Contra (NES)
Traducción al Español v1.0 (25/08/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Contra (U) [!].nes
MD5: 7bdad8b4a7a56a634c9649d20bd3011b
SHA1: c9ea66bb7cb30ad5343f1721b1d4d3219859319b
CRC32: c50a8304
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --