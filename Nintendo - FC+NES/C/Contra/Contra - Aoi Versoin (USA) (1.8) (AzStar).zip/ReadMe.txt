﻿
“Contra Aoi Version” is a hack of Contra on the NES based on “Revenge of the Red Falcon”. The difficulty level is quite higher than the original game. 
The level designs are mixed with some designs from the original game, “Revenge of the Red Falcon”, “Red Falcon War” and some new designs. 
Level order was modified, stage 1 is still Jungle, but stage 2 is Snowfield, and stage 3 is… 
Enemy AI is not completely the same as “Revenge of the Red Falcon”. The enemy’s bullets are slower than it.Some enemies will shoot like weapon S… 
And it allowed you for only 3 attempts to complete all 8 levels.
Weapons are better than the original game except weapon S(Because weapon S is really useful), and L+R is a new weapon type of Laser. However you cannot keep the weapon to next stage. So be good at using any weapons to run through every stage…

Game Type: FC-Shooter
Name: Contra Aoi Version
Version: 1.8
Language: English
Available for X Player(s): X=1
Hack By: AzStar
Assist By: CZXInc，CodeName
No Miss Play Through: Possible
Difficulty: 
Stage 1 Jungle: Normal
Stage 2 Snowfield: Hard
Stage 3 Waterfall: Easy Demon
Stage 4 Outpost: Insane
Stage 5 Warehouse: Harder
Stage 6 Station: Meidum Demon
Stage 7 Energy Zone: Medium Demon
Stage 8 the Lair: Hard Demon
Video of Play-through: https://www.bilibili.com/video/av85756834?from=search&seid=9902984656318619425
Weapon distribution: 
Stage 1 Jungle: F,R,Eagle,M+R,S,R,L
Stage 2 Snowfield: F,R,L+Eagle+S,M,R
Stage 3 Waterfall: F,L,R,F,R
Stage 4 Outpost: R,B,F,R,Eagle
Stage 5 Warehouse: M(Hidden),R,S,F(Hidden)
Stage 6 Station: R,B,F,M,Eagle,M,R,Eagle
Stage 7 Energy Zone: L(Hidden),S,F,R
Stage 8 the Lair: R+S,S,R,L(Hidden),M+R

PS: 
Ver1.6 is available for two players, but level order is the original. Weapon L+R is still the original weapon type.
Ver1.7 is hard mode and only available for 1 player，update for anyone who wanna challengeXD.
Protip: Set a button for auto fire, it will be easier if you use the button well.
Secret:B↓→AA↓←↓→B(10 Lives)

Special Thanks for 
Trax(Orig. Enemies' Attribute Hacking),
CZXInc(Weapon Hacking and Enemies' Attribute Hacking),
CodeName(Level Order Adjustment and Title Hacking)
That's all, thanks for playing.

--------------------------------------------------------------------------------------------------------------------------------

青版（Contra Aoi Version）是基于红隼的复仇（Revenge of the Red Falcon by Trax）为基础版本进行修改的版本，结合红隼的复仇精简版的地形布置，除了修改地形以外，还添加了一些新的代码。

游戏类型：FC-射击类
名字：魂斗罗:青版
版本号：1.8
游戏语言：英语
游戏最大人数：1，（1.6为2）
作者：Az星に
协助者：CZXInc，CodeName
一命通关：可以
单关难度：
第一关(Stage 1 Jungle)：普通
第二关(Stage 2 Snowfield)：困难
第三关(Stage 3 Waterfall)：更加疯狂
第四关(Stage 4 Outpost)：疯狂
第五关(Stage 5 Warehouse)：非常困难
第六关(Stage 6 Station)：炼狱
第七关(Stage 7 Energy Zone)：恶魔
第八关(Stage 8 the Lair)：炼狱
通关演示：https://www.bilibili.com/video/av85756834?from=search&seid=9902984656318619425

版本介绍：
1.武器强化（L弹获得R之后会有新的攻击方式）
2.过关初始化武器（即你使用除白弹外的武器过关，下个关卡仍然初始化为白弹）
3.取消奖命机制（也就是说你只有3次失误机会）
4.关卡顺序调整（丛林→雪原→瀑布→前哨→机库→据点→能源→巢穴）
5.仅支持单人游戏。（考虑到大量敌人和子弹，双人模式会很卡，且一个人玩的情况比较多）
6.地形为原版，红隼战争，红隼复仇三个版本的一些地形加上一些新地形。
7.第5，7和8关有部分隐藏武器补给，适当使用可以降低关卡难度。
8.初始3命，秘籍10命（B↓→AA↓←↓→B，即KOF2002kyo的一个基础连招：重拳+七十五式+大蛇薙）
9.大量敌人强化，比如小兵会开S弹，红色兵，墙炮攻击间隔小，子弹速度快（了一点）等等。

关卡安排/攻略：

第一关：丛林
第一关属于新手关卡，主要是让玩家熟悉各种枪械，整关难点只有Boss，偏速通。
开局：一开始过了炸桥之后会有一把F，可以考虑不要，F主要是为了走下路增大攻击威力对墙炮用的。结合后面给的R使得输出更快。
第一断桥：断桥前会有M+R补给，建议全拿，因为M除了输出高，也会使得墙炮攻击频率和转速变低，方便后面的红隼战争地形进行StarH跑法。
第二断桥：断桥下面有把S，没什么卵用，但是打boss还是比M强点。
Boss：Boss前会有武器空投，是一把L，建议拿上这把L（除非你S弹玩得很厉害），先把Boss上面的红兵打掉，接下来就看你的走位啦XD。

第二关：雪原
雪原没什么难度，主要也是让玩家熟悉各种枪械的作用，并且如果知道的话，可以见识一下L+R的威力。注意一下Boss发飞碟发很快，要适应好。
开局：一把F记得拿，这对后面水部分的不利地形很有用。
Boss-坦克：如果你是初始子弹，最好站最左端打，如果是S/L，随便打，如果是M/F，有两个站位可以打，坦克前趴着或者站在距离坦克3个身位打。
Boss-飞碟：派生飞碟有点快，注意一下就行了，血量比较厚，要打比较久。（但是L+R可以秒了XD）如果翻车了，那记得不要站在Boss下面打，最好侧1-2个身位。

第三关：瀑布
瀑布是指定F/L+R武器通关的关卡，关卡里面只有F/L/R这些武器和一个震天鹰。
瀑布难度非常高，估计这一关会劝退不少玩家XD，首先是地形是从下往上爬的，除了背板上面的出兵顺序，更多的是操作。
难点1：双色炮点，注意拖住墙炮的攻击方向，然后向右跳到炮台（下方有F，可以考虑不拿）
难点2：双石台点，注意上方石台移速比较快，中间有L空投，可以拿
难点3：双墙炮点，有F就跳跃一下勾引左边的墙炮并秒掉，之后再处理右边的，不过同时要注意上面的红色兵
难点4：大瀑布点，注意先处理掉红兵。
难点5：3短间隔火点，注意石头和杂兵。
难点6：4短间隔火点，注意红色兵。
难点7：杂兵红兵夹击点，先清理红兵后注意小兵的S弹
难点8：Boss前的红兵/小兵注意提前清理（靠背板）

第四关：前哨基地
基地是指定（F+R）/R武器通关的关卡，关卡里面只有武器R，一个B和震天鹰。
因为指定（F+R）/R武器通关，所以难度很高。难点是第四，五障碍和Boss，1-5障碍的武器补给分别是R，B，F，R，E。
第一障碍：可以趴下等R，或者直接站中间打掉大核心。
第二障碍：先清理掉左边或者右边的墙炮，然后站中间旁边打掉大核心。
第三障碍：站中间有规律地趴着躲子弹和站着打掉大核心。
第四障碍：先处理掉左边或者右边的墙炮，然后再清理相应相反位置的墙炮，需要注意手榴弹和子弹分布。
第五障碍：绿兵循环比较长，可以考虑等震天鹰出来然后拿掉清理敌人，建议背板。
Boss：看你技术啦XD

第五关：飞机库
飞机库是指定M/F/S+R武器通关的关卡，关卡里面只有武器M/F（隐藏），S，R和震天鹰（隐藏）。
不知道怎么说，反正很难就是了QwQ，毕竟路程上各种机关和Boss的炮台。
难点1：第一多爪子点：下路要多开几枪，我建议在前面的地方走上路，因为下路太危险了，有小兵一直刷出来，还要一直趴着前进。另外，上路还有隐藏的武器M补给。
难点2：第三多爪子点：建议在前面陷阱门出来时踩上去并跳到爪子堆上方的平台，不然下面也很难，毕竟有一些爪子你趴着也会挨打而且还有一些小兵不断出现，不仅如此，过完这个地方后还有Boss炮台要处理掉，而上路有个隐藏的震天鹰可以清除Boss炮台。
难点3：第四多爪子点：10个长爪子的那个地方，看清规律就可以啦
难点4：双Boss炮台三爪子点：第一个必须打掉，第二个要找时间跳过去，看你抓的时机是否正确，第三个直接跳过QwQ
难点5：高低双Boss炮台点：利用红隼战争跑法走过去（极小概率翻车），或者为了求稳可以先把第一个炮台打掉。
难点6：Boss：首先是由于还要先打掉下面两个Boss炮台才能打十字架通关，所以这个Boss不会很容易，推荐用F弹打（前提是你能找到F），站在第一个Boss炮台偏右侧跳起来向下打，输出完毕后向第二炮台斜角输出，然后清理掉门的小兵，之后就自己找机会打了XD（毕竟随机性很高）

第六关：据点
据点是指定M+R武器通关的关卡，关卡里面只有武器M，R和震天鹰。
据点按照第N障碍打爆N个点，整体难度比较平均，但是Boss比较难，比较考验操作。
补给顺序是R，B，F，M，E，M，R，E
建议拿上M+R打Boss，不然的话更容易GG的QwQ。

第七关：能源站
能源站是指定L/F+R武器通关的关卡，关卡里面武器有L(隐藏)，F，S（不建议拿）和R。
难点有很多，主要是喷火。
难点1：死亡门：死亡门技巧性很高，除了解决好随机小兵外，还要处理时间，早跳或者晚跳都会GG，具体还是看视频吧QwQ。
难点2：双反序喷火点：站在比较靠边的位置上，在上面的火收回来的同时跳跃避开下面的火。
难点3：三感应喷火点：在属性0喷火和属性4喷火前应该跳跃跳到中间，然后清理迫击炮并且有规律地匍匐前进，到了边缘时，找时间跳过去。
难点4：死亡楼点：在这个2随机喷火和2规律喷火交融的点，需要你放弃S武器，在这个点前有3个喷火，抓准自己跳下来之后直接跳跃进入死亡楼并且在跳跃过程中向上攻击把红色兵清理掉，之后按规律上楼就行了。
难点5：战场原点：双火点，抓准时机，在上面喷火收回完的同时跳跃下去。
难点6：死亡楼梯点：慢慢过。XD
难点7：死亡跳跃点：也就是尾杀4喷点，这个Umm，不知道怎么说，抓时机吧，具体看视频。

第八关：巢穴
巢穴是指定M+R武器通关的关卡，关卡里有武器M/S/L（隐藏），R和震天鹰。
个人不建议拿S+R打最终Boss，除非你对自己的S弹能力非常自信，至于L弹，看你的能力啦，反正我是做不到使用L+R打Boss的啦。
整关难度比较平均，但是Boss比较难，比较考验操作。
Boss真实看运气和自己的操作QwQ
XDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD

在此感谢基础版本作者Trax，
武器强化&敌人强化的CZXInc，
关卡顺序调整&标题修改的CodeName。
以上，希望对你有所帮助，祝你游戏愉快。

2012-01-30 Az星に/AzStar(tie)
