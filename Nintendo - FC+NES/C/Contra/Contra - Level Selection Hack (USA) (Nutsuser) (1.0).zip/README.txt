* Title: Contra � Level Selection Hack
* Author: extr1m (registered on romhacking.net as Nutsuser)
* Game: Contra (U) [!] (NES)
* Release date: 19.08.2025

* Description:

* A challenging reimagining of Contra where players must survive with only one life instead of the standard three.
* A built-in level select menu allows players to jump directly to any stage.
* The jump height has been slightly increased for smoother gameplay and expanded movement options.
* Weapons are now retained after taking damage, reducing frustration and encouraging more aggressive play.
* This hack balances higher difficulty with fair mechanics, creating a tense but rewarding Contra experience.

* Patch is intended for: Contra (U) [!].nes