It's Contra iikorihack!
hacked on and off from 12/2022 to 02/2024
This hack is made for the seasoned Contra players out there.
Those who can play the original game through tens of times before eventually running out of continues and lives.

I lost count of added features a long time ago and I did not really never track them to begin with, this hack has at least:

* Lap counter (see if you figure out where it is)
* A menu that let's you decide how hard of Contra game you want
* Enemy pattern randomization
* Weapon drop randomization
* Getting 1 ups if you collect the same weapon drop twice
* Color palette randomization
* Boss pattern randomization
* Musket mode for the real Lances and Bills out there.
* expiremental 2 player vs mode
* bugs that are there on purpose
* bugs that are there that might be fixed in the future
* bugs for you to find!

Background:
I used to play contra every workday during coffee breaks with my coworkers. This led to everyone getting steadily more better at the game until we finally started to play for laps, eventually getting to around 20 laps without the game really giving any more challenge. 
So obviously something had to be done.

Greetings to:
Alien Testicles Crew
TIKE Marine Corps
lance_bean and LutroLago
Madam mayor
Mr President
His holiness, the Pope
The King of Norway
and our other honored guests.

Changelog:
2024-02-29:
Fixed a bug where player 2 spawns to a fixed position in 3d tunnel levels
Fixed a bug where kill counter does not reset between game overs.
