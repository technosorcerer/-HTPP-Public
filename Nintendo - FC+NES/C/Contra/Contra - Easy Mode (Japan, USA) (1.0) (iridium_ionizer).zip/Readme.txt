
CONTRA: Easy Mode
  by iridium_ionizer

***
Special Thanks to Displaced Gamers (https://www.youtube.com/channel/UCWoSKWs8h6lFdiEDAjuIfpA), DANGER X, Trax, and Barret (and Bongo` for the document upload). 
***

Description
--------------
Contra is one of the best games on the NES. It is difficult though. If your skills are not sharp, you will get hit frequently by stray bullets. Upon death you lose your awesome gun that you waited half of the level for and revert back to the pea shooter. 

This hack attempts to make Contra easier for the semi-skilled individual by allowing you to either revert to the machine gun upon death or keep your previous weapon (your choice). Also the regular game lives have increased to 10, Konami code lives have increased to 50, and 3 continues have increased to 9 continues. A few of the harder non-boss enemies have had their hitpoints decreased to about 75% of their original values. 

Any half-way skilled player should now be able to beat Contra - even with a lesser skilled player stealing their lives for half of the level. You can use the main patch or the customizable patches. Patches are include for both the USA version and Stardust Crusaders' excellent translation of the Japanese version (https://www.romhacking.net/translations/1451/). 

This comprehensive easy mode hack utilizes many byte value changes, but also include an opcode change for the keep weapon hack. This is more elegant, more compatible with other hacks, and less glitchy than the Game Genie code. Also a Hacking Notes document is included in the zip file. 


Patching Instructions
---------------------
Determine if you are patching the USA or the Japan version of Contra. If you use Japan version, then patch on top of the Stardust Crusaders' EN translation. 

Do you want to use the complete hack, or do you want to leave out some aspects of the hack (customizable)? Do you want to keep your weapon after you die (easier) or revert to the machine gun? 

Choose the ips patch that you want to use and apply it to the proper ROM file using the Lunar IPS.exe patching program. 


Base ROM Files
---------------
Database match: Contra (Japan)
Database: No-Intro: Nintendo Entertainment System (v. 20180803-121122)
File SHA-1: 376836361F404C815D404E1D5903D5D11F4EFF0E
File CRC32: 8A96A3C4
ROM SHA-1: BE9DD65BE8DB897978DD34533DD3A037784A8EE9
ROM CRC32: B27B8CF4


Database match: Contra (USA)
Database: No-Intro: Nintendo Entertainment System (v. 20180803-121122)
File SHA-1: C9EA66BB7CB30AD5343F1721B1D4D3219859319B
File CRC32: C50A8304
ROM SHA-1: 979494E7869AC7AB4815FDBD1DC99F893F713FBF
ROM CRC32: F6035030


