Contra 2p scroll fix.

Changed how camera works in two players mode on horizontal levels (1,5,6,7,8).
In original version camera scrolled only when both players near to the right side of the screen.

v1 - scroll at center like 1 player mode / Contra Force.

v2 (alternate version) - if one player is on the right and the second player on the left, the second player can scroll the screen.


Also patches for expanded ROM's (for_256Kb_roms), such as "Revenge of the Red Falcon" (for which the patch was actually conceived).