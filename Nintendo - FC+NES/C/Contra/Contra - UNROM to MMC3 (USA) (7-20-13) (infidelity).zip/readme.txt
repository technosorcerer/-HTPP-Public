5/26/12
UPDATE 7/16/13
infidelity

Contra UNROM to MMC3

MMC3 Bankswap Routine To Insert Into ROM at $1FBF8 = 0A48A9068D0080688D0180090148A9078D0080688D018060

$1C14F LDA,Y's the bank table at $1FFE0-7
$1C152 STA,Y's the bank number at that exact table

So, at $1C152, insert JSR to 20E8FB, and that's it.

Done!
UPDATE 7-16-13

Now works on an actual NES!
$1C01D = 20CFFB EA
$1FBDF = A205 8E0080 BDE2FB 8D0180 CA 10F4 A900 8518 60 00 02 04 05 06 07
END

UPDATE 7/20/13

ISSUE REGARDING MIRRORING

Need to add Mirroring Mode within Reset Vector. For Contra it starts as Vertical

$1C01D = 20CAFB
$1FBDA = A900 8D00A0
END
