--------------------------Info---------------------------
Game name: Contra
Console: Nintendo entertainment system
Game region USA: (U)
Patcher: Cheat Patcher v0.9 or higher.
----------------------------------------------------------
--------------------------patch------------------------
The patch allows to set following parametres:
 
 Players lives
 Default weapon
 Secondary Weapon Slot and Remote Barrier
  *Switch weapon - SELECT button.
  *Activate Remote Barrier - hold SELECT button for more than 2 seconds, triggered on release.

--------------------Cheat Patcher------------------
Download link:
http://www.romhacking.net/utilities/1112/
----------------------------------------------------------
Authors by: Mr2, MagusLOGS.
e-mail: fsocp@land.ru
http://rgcorp.ucoz.net/
https://www.romhacking.net/hacks/2961/