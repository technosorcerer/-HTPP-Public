=========================Contra==========================
=========================V 1.01==========================
Genre: Action

Source language: Japanese

Platform: Famicom

Patch language: English

Author: Pennywise

E-mail: yojimbogarrett@gmail.com
http://yojimbo.eludevisibility.org/
 
======================================================
About Contra
======================================================
Background: 

The Japanese version of Contra is different from the
US version in that it actually contained a story.
Way back in the day the MadHacker translated it,
but it had a few issues included an untranslated
secret message. Years later I stepped in redo the
translation from scratch and present to you the
ideal NES version of Contra.

The initial release had some minor palette issues
and hackishness going on with the sound test.
I had to fix the issues no matter how minor and
have an updated patch for all. Now you may be asking
yourself why I bothered to update the patch for a
minor fix several years. It's an imperfection that
needed to be fixed. Sure, people might not play the
latest version, but that doesn't concern me.

======================================================
Game Tips
======================================================
* The classic Konami Code for 30 lives - 
At the Title Screen press Up, Up, Down, Down, Left, Right,
Left, Right, B, A, Start.

* Stage select - At the title screen, press and hold Up, Left
and the A button. While holding these buttons, press Start
and immediately hold Select.

* During the ending, before the closing credits starts rolling,
press and hold the Select and Start and keep on holding until the
credits are over. If done correctly, you will receive a message
from Red Falcon, vowing his revenge.

======================================================
Patching Instructions
======================================================
Apply either patch to the Japanese version of the ROM.
Some of the older ROM sites have it listed as
Gryzor (J) etc.

P.S.

Support the game industry by buying used games!

Even if the money doesn't go to the developers
directly, as the games become rare and harder
to find, the price goes up, and people become
more inclined to buy new releases "while they can!"

======================================================

Credits go to:

Pennywise - hacking

Jonny2x4 - translation

FlashPV - title screen animation

ReyVGM - testing

All those who contributed into this process.

======================================================


Compiled by Pennywise. November 2013.