﻿Contra (J) Simplified Chinese Patch by Jixun

-------------------

V2 Update:
* Fixed the lag was on V1.
* Translated "other ending" message.

-------------------

My first ever translated nes game, Contra.

Not much text involved, so I give it a try.

I don't understand much Japanese, so I referred to the English patched version,
Wiki, and other resources available on the internet to help me understand what
was going on.

Reusability of Chinese in nes game is horrible. Really.

Know issues:
* ~~Map screen will have a small lag.~~ Fixed!
* Palette issue on the title screen.

That's all.

-------------------

Translate, Code, Test: Jixun
Proofreading: Jixun, InSB

-------------------

Find me:
    Blog <https://jixun.moe/>
