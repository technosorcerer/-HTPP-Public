﻿ 
Game Type: FC-Shooting
Name: Contra: 93' Optimized
Version: 1.40/1.41
Language: English
Available for X Player(s): X=1
Hacked By: AzStar
Assist By: CZXInc
Orig. hacking: Trax(enemies hacking), MagusLOGS(weapon slot hacking)
No Miss Play Through: Possible
Difficulty: 
Stage 1: Normal
Stage 2: Hard
Stage 3: Harder
Stage 4: Hard
Stage 5: Harder
Stage 6: Harder
Stage 7: Harder
Stage 8: Insane

Features of the hack:
1.Enemies HP hacking
2.Enemies new attack hacking(Enemies shooting shot gun, Boss 2 genrating Bomb, etc)
3.Boss 1 & 7 Protection hacking(need to destory all the mortar launchers or turrets at first)
4.No bonus of rests[lives]

Weapon system: (For v1.40 or v1.41)
1.weapon slots[Like Contra 4, press SELECT to switch the weapon slots when gaming](Bugfix)
2.weapon upgraded system:
Default		(4 bullets)	
D+R		(6 bullets, Rapid)
M		(Turbo, Random, 8*1 bullets, Delay=05)
M+R		(Turbo, Random, 6*2 bullets, Delay=03, Rapid)
F		(Penetration, 4 bullets)	
F+R		(Penetration, 6 bullets, Rapid)
S		(3*3 bullets)
S+R		(5*3 bullets, Rapid)
L		(Penetration, 4*1 bullets, Shot type=Original)	
L+R		(Penetration, 4*2 bullets, Shot type=S)
3.One of the weapon slots will be reset in new the stage.
If Stage=Stage+1, Weapon(A, B)=Weapon(Default, B).

Tip or Others:
1.←→←→←→←→←→(15 lives)
2.weapon upgraded system: (For v1.20, adjust for 2 players)
Default		(4 bullets)	
D+R		(6 bullets, Rapid)
M		(Turbo, Random, 6*1 bullets, Delay=08)
M+R		(Turbo, Random, 8*1 bullets, Delay=03, Rapid)
F		(4 bullets)	
F+R		(Penetration, 6 bullets, Rapid)
S		(3*2 bullets)
S+R		(5*2 bullets, Rapid)
L		(4*1 bullets)	
L+R		(Penetration, 4*1 bullets)
PS: Remain a bug of penetration when switching weapons.
Modify: offset(3E3D8H) C2→39 can avoid this bug. 
But F/L will have penetration without upgraded.(Like this ↓)
F		(Penetration, 4 bullets)	
F+R		(Penetration, 6 bullets, Rapid)
L		(Penetration, 4*1 bullets)	
L+R		(Penetration, 4*1 bullets, No change)

Special Thanks for 
Trax(Orig. Enemies' Attribute Hacking),
CZXInc(Bugfix, Weapon Hacking and Enemies' Attribute Hacking),
CodeName(Orig. 1 player mode locked hacking),
MagusLOGS(Orig. Secondary Weapon Slot Hacking)
That's all, thanks for playing.