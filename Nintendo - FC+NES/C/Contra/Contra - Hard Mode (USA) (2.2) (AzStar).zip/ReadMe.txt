﻿
Game Type: FC-Shooter
Name: Hard Mode of Contra
Version: 2.2
Language: English
Available for X Player(s): X=2
Hacked By: AzStar
Assist By: CZXInc
Orig. Hacking: Trax
No Miss Play Through: Possible
Difficulty: 
Stage 1 Jungle: Easy
Stage 2 Base 1: Normal
Stage 3 Waterfall: Harder
Stage 4 Base 2: Hard
Stage 5 Snow Field: Harder
Stage 6 Energy Zone: Harder
Stage 7 Hangar: Insane
Stage 8 the Lair: Insane

Tip:
1.you need to destroyed the mortar launchers at first in stage 7 boss.
2.B A B A B A B A B A(10 lives)
PS: "Hard Mode of Contra[Improvement]" is an improvement that could patch to other hacks. 
(FOR modify enemy positions and level designs and not expand ONLY)
It can switch some hack into the hard mode. If you patch it to the original game... 
Umm, yeah it will be a little different with "Hard Mode of Contra". 
"Hard Mode of Contra: Special Version" ? XD

-----------------------------------------------------------------------------------------------------------------

游戏类型：(FC-射击类）
名字：魂斗罗：强化版/魂斗罗：困难模式
版本号：2.2
游戏语言：英语
游戏最大人数：2
作者：Az星に
协助者：CZX
起源：基于Trax的红隼复仇
一命通关：可以
难度：
第一关：简单
第二关：普通
第三关：更难
第四关：困难
第五关：更难
第六关：更难
第七关：疯狂
第八关：疯狂

提示：
1.第七关Boss需要先打掉下面两个炮台才能打十字架门。
2.B A B A B A B A B A(10命秘籍)
PS：改良型补丁（Hard Mode of Contra[Improvement]）可以应用于各种仅修改地图敌人位置而且非扩容的改版，可以称为那个改版的强化版（困难模式）。
不过应用前，先检查$[3D90, 3FFF]以及$[1F650, 1FA4F]是否为空，如果是，直接应用，如果不是，可以利用JSR/JMP指令修改一下程序块的位置，问题不大XD。
当然如果你把它打进原版上，那也可以是强化版，只不过这个强化版和作品型的有一丢丢差异（像是1/3关坦克转速快了一点吖，2/4/8关有差异性吖），特别强化版？XD

2019-12-02 Hard Mode of Contra[Complete]
2020-02-10 Hard Mode of Contra[Improvement]

2020-02-10 Az星に/AzStar(tie)