Aside from the gender swap work I did, credit goes to:

Pennywise
 - all the original and difficult hacking
MFerraro (@mferraro.bsky.social)
 - new title screen animation
 - new translations
 - some additional hacking of a couple pointers
 and timers, and reverse-engineering the original hacks
 to build over them and separate the title screen.


Change-log:

v0.1.1

	* Fixed running animation in bases (stage 2 and 4), it looks better now (more natural)
	* Fixed guns in both versions of the cut-scenes, to be more similar
	* Fixed issue with alignment in sprite (noticeable in bosses 2 and 4)

v0.1.0
	
	* Changed the dialog for all cut-scenes. I'm no comedian but hopefully they'll make someone chuckle

v0.0.2:

	* Fixed Bella hair in cut-scene 1
	* Minor changes in small sprites for Bella/Lana

v0.0.1:

	* Title screen done
	* ID cards (military files/IDs or whatever they are) are done (the intro story)
	* All small sprites of Bill and Lance (Bella and Lana) are pretty much done
	* All cut-scenes are done
