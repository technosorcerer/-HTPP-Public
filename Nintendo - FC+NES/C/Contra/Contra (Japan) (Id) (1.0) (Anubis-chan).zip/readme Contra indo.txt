=====================
CONTRA - PATCH BAHASA INDONESIA by Anubis-chan
=====================

-For English readme, please scroll below-

Terima kasih sudah mendownload patch ini. Ini adalah patch bahasa Indonesia untuk game CONTRA (JP) v1.0. 

Silakan ikuti langkah berikut ini untuk mengaplikasikan file patch IPS ini:

1. Download ROM game CONTRA versi Jepang (bukan versi USA), bisa dicari di situs penyedia ROM game NES. Pastikan sizenya adalah 257KB.

2. Download program IPS patcher seperti Lunar IPS (https://fusoya.eludevisibility.org/lips/download/lips102.zip)

3. Pilih apply patch, dan pilih file IPS bahasa Indonesia, dan pilih ROM game CONTRA versi bahasa Jepang.

4. Bila betul maka semua teks akan berubah menjadi bahasa Indonesia saat dimainkan (tested via Nester & FCEUX, gagal di NESTOPIA - unsupported mapper).

5. Adapun bagian yang ditranslasi hanyalah:
a. Prolog dan Dialog saat cutscene
b. Layar judul & copyright.
c. Cheat menu Sound Test dan Level Select.
Sedangkan lokasi game dan credit tidak dirubah untuk menjaga keaslian terminologi dan nama-nama creator game ini.

Bagi yang menemukan bug atau typo, silakan kirim email ke cmartika@gmail.com. Terima kasih!

=========ENGLISH README VERSION=========

Thank you for downloading this patch. This is an Indonesian patch for the Contra JP v1.0 game.

Please follow the steps below to apply this IPS patch file:

1. Download the Japanese version of the CONTRA JP game ROM (not the USA version), you can find it on the NES game ROM provider site. Make sure the size is 257KB.

2. Download an IPS patcher program such as Lunar IPS (https://fusoya.eludevisibility.org/lips/download/lips102.zip)

3. Select apply patch, and select the Indonesian IPS file, and select the Japanese version of the CONTRA game ROM.

4. If true, all texts will change to Indonesian when played (tested via Nester & FCEUX, NOT WORK IN NESTOPIA - unsupported mapper).

5. The parts that are translated are:
a. Prologue and Dialogue during cutscenes
b. Title & copyright screen.
c. Cheat menu, including Sound test and Level Select.
Meanwhile, the game location and credits have not been changed to maintain the authenticity of the terminology and names of the game creators.

For those who find bugs, errors, or typos, please send an email to cmartika@gmail.com. Thank you!