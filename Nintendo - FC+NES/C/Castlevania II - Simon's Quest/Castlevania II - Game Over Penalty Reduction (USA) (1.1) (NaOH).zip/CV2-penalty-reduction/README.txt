This hack reduces the game over penalty by making it so that hearts are cut in half instead of set to zero.

Two versions of the patch are included.

penalty-reduction.ips:
	Intended for most users. Not compatible with bisqwit's Castlevania 2 retranslation + map patch. 

penalty-reduction-bisqwit.ips:
	Only compatible with bisqwit's Castlevania 2 retranslation + map patch.
	https://www.romhacking.net/hacks/1032/
	Ensure that the retranslation patch is applied BEFORE the penalty reduction patch.

You may also be interested in this improved controls patch: https://www.romhacking.net/hacks/4150/

Enjoy!

-NaOH