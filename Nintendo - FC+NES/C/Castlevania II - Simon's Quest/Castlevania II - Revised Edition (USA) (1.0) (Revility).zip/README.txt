Castlevania 2: Rev Edition (Revised Edition)
By Revility
revility@yahoo.com
Release date: 10.27.19

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
BASE ROM USED INFO
Database match: Castlevania II - Simon's Quest (USA)
Database: No-Intro: Nintendo Entertainment System (v. 20180803-121122)
File SHA-1: D6B96FD98AE480C694A103FE9A5D7D84EEAFB6F7
File CRC32: A9C2C503
ROM SHA-1: 2447D6133573F7ED2CC49DC95B3130427BD4DC35
ROM CRC32: C471E42D
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

Tools used:
photo shop
yychr
cursed

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

Hack Description:
	This hack mainly changes the graphics for Castlevania 2 for the nes.  Other tweaks have also been done.  This includes palette changes, and dialogue and minor map changes.
	
	The main goal was to connect Castlevania 2 more to Castlevania 3.  Some sprites are straight from cv3, others are modified versions of cv3, and cv2 ones.  A few have been done from scratch.
	
	Simon's new sprite is similar to his Chronicles look.  Boss sprites have been changed or updated.  Orlox from SOTN now replaces Death.  Carmilla now rides upon her mask like in other CV titles.  Death replaces Dracula at the end... his sprite always looked closer to Death than Drac.  
	
	The prologue, general story, and ending have been modified for the above changes.  In the wake of Dracula's defeat, Death has cursed the land and now controls the remaining hordes of Dracula's Army.  In order to rid the curse; Simon must seek out relics from the past of those who have defeated Death before.  This includes weapons and objects from Trevor Belmont and is companions.

	Current plan is to only patch if any bugs are found... but you never know.
	
	Feel free to use the graphics and or changes in your hacks or as a base for another hack.  
	I only ask you e-mail me a link to the hack so I may put it on my tumblr or save it for myself to play. :) 
	
	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
How to install:
The hack comes in the form of a .ips patch.  To install the patch, first you need to install/download Lunar Ips or a similar nes rom patching program.
You also need a copy of the north American version of Zelda 2 for nes. I will not provide or tell you where to find it ;)
Once you have both, use Ips program to apply the ips file into the rom file.  
Lunar ips is a small & quick download. 
You can find it at https://www.romhacking.net/utilities/240/ or doing a google search.

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

Special Thanks:
romhacking.net
data crystal
bisqwit & his excellent Retranslation site.


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
CHANGE LOG:
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

build 1.0.0 
10.27.19

General:
	+Updated Simon sprite to chronicles style
	+Updated simon's palette
	+Updated or adjusted almost all villager sprites.
	+Updated palettes for all villagers
	+Fake blocks are now transparent
	+breakable blocks now appear cracked.
	+Updated ending text
	+Updated prologue text
	+Updated main title screen text for Rev edition
	+Changed a few pallet colors on title screens.
	+Updated Simon ending sprites and palettes

Items:
	+Dracula's rib is now Alucard's shield
	+Dracula's ring is now Sypha's wedding ring
	+Dracula's eye is now Belnades staff
	+Dracula's nail is now Trevor's bracelet
	+Dracula's heart is now Alucard's sword
	+Magic Cross is now Trevor's cross
	+dracula's knife now reffered to as Grant's knife
	+Diamond now reffered to as Sypha's diamond
	+Books are now referred to as Sypha's Diary.
	+Sacred Flame referred to as Sypha's Flame
	+Half heart changed to double heart?

Text Updates:
	+Various fixes and adjustments to text from bad translations
	+fixed typos in text.
	+modified a few hints
	+updated text to refer to renamed items
	+updated text to refer to Death's riddle instead of Dracula.
	+Updated text to refer to adjusted back story.

Enemies:
	+Eyeball now cv3 ghost
	+Medusa cv3 style
	+Merman cv3 style
	+Forest bat cv3 style
	+Zombie modified cv3 zombie
	+Mummy cv3's Dhuron 
	+Skull cv3 style
	+Tweaked skeleton's face
	+Devils now man bats.
	+Bone dragon updated to cv3
	+Replaced double header with slogra
	+Replaced fire guy with cv3 version
	+Changed harpy face and tweaked arms.
	+Inverted spider colors
	+Outlined crows
	+Inverted colors on hawks
	+Some skeletons in mansion are now cv3 armored skeletons
	+Freddie replaced by jawless cv3 zombie with dagger
	+Replaced graveyard hands
	+Replaced plant with pillar of bones
	+Updated Mansion bats.  Easier to see.

Bosses:
	+Updated Carmilla's mask sprite: she now rides on top similar to other Castlevania games.
	+Changed Death to Orlox
	+Started changing Dracula to Death

Maps:
	+Bordia mountains: invisible stairs now seen
	+Bordia mountains: free laurel merchant replaces the skeleton at the end.
	+Flame whip gypsy moved to top of cave map
	+adjusted flame whip gypsy cave a little bit in return for the above.
	+Yubia Lake: removed single block
	+Denis woods: removed some poison marsh on lower path.
	+Denis Woods: removed head knocker parts of lower path.
	+Jova woods: removed head knockers on lower path
	+All Mansions: closed most gaps between ceilings and walls.
	+Many invisible blocks removed from mansions and replaced with background images
	+Minor visual tweaks to some mansion areas.
	+Moved a couple enemies in woods on ledges near water which were extremely hard to kill.
	+Rover Mansion: adjustments to layout to no allow skipping half the mansion.
	+Rover Mansion: Breakable floor near end for faster exiting of mansion.
	+Adjusted colors for all mansions.
	+Moved a few enemies on small platforms to remove cheap deaths.
	+removed some un needed pits, walls, etc from maps to encourage multiple routes and gameplay flow.