CASTLEVANIA II: SIMON'S QUEST
The Captain Obvious Edtion 1.0
A hack by DTM666

Fair bit of warning; there is a lot of reading here.

*** WHAT THIS IS ***
Castlevania II: Simon's Quest: The Captain Obvious Edition is a ROM hack of Castlevania II: Simon's Quest whose original intention was to modify all the text from the original somewhat incomprehensible gibberish to slightly more comprehensible gibberish that both helps and mocks you, sometimes at the same time. It has since evolved into something more, with remade color palette, somewhat modified levels, removed items, changes in placement of enemies and vendors, even books have been shuffled around somewhat... and there's also a nifty save function from a prior patch that I can no longer excise, so it stays. Call it a spoof, call it a mockery, but what it isn't is "easier."

*** WHAT YOU NEED ***
 - Castlevania II: Simon's Quest ROM (not included)
 - IPS patching program (not included)
 - IPS ROM patch (included)

*** HOW TO PATCH ***
This document assumes you know what an IPS patching program is. This document also assumes you know hot to use an IPS patching program. I recommend the Lunar ISP program because it is a quick, simple, and straightforward patching program that is easy to use.

*** LIST OF CHANGES ***
The following is a list of changes made to the game by this patch.

** ALL TEXT CHANGED **
The original intent of the Captain Obvious edition was simple; replace all the text in the game with new text that would both help the player and mock the player. In the original Simon's Quest, there were bits of dialogue that were either difficult to decipher, flat out lies, or just nonsense. While there is a patch (Simon's Redaction) that alters the text in this regard, it also makes the game easier by flat out telling you how to play in a sorta handholding way. To some who needed Nintendo Power, this was fine, I guess. But for folks who had beaten Simon's Quest without the need of a guide (or a tornado, for that matter), this was like playing Contra on easy.

Text has been altered to the point where you'll find some helpful advice, ranging from less vague clues to obvious hints (hence the name of this patch), sometimes you'll find advice that is delivered in a less than helpful fashion, and then you'll run into folks that simply do not like you or don't care about the quest you're on. It goes without saying that some "naughty" words are used here, so discretion is advised.

** COLOR PALETTE CHANGES **
At some point, I began tinkering with the color palette to something a little more, partly to give the world a different heir, partly to try and tweak the overall appearance. In the end, there are some drastic color changes (mansions) and there are less than drastic (great outdoors). Night is darker than before, almost black and greys than anything. Only interiors such as caves and mansions retain their usual lighting.

** SAVE FUNCTION **
This hack makes use of Matrixz's CV2 SRAM patch, which essentially replaces the game's original password system with a quick and easy save function. So now, you can save your game (only one) and resume at a later time without much hassle, although much like the passwords, you start at the town of Jova.

** REMOVAL OF GOOD WEAPONS **
Some items that makes the game "easier" have been removed. In their usual hiding spots are text messages that will mock you. And yes, this includes laurels. The use of a save function is nice, but it's a way to cut down on cheating by using a password to get items that normally wouldn't be gained from the main game...

** LEVEL MODIFICATIONS **
Some sections of the game have been modified to either a minor or major degree. Because there are no laurels, poisonous marshes are all but excised from the game (you'll still find a hint of it in the forests) and replaced with new terrain or bits of water. Some other changes include previously closed paths being opened and led to another part of the world, similar to a one-way warp. And then, there's... well, you'll see.

** PLACEMENT CHANGES **
Where did the White Crystal vendor go? Moved to another town. Where do I find the Thorn Whip vendor? In a mansion. Got that Holy Water handy? You'll need it. In addition to changing places, there are also changes in enemy placements. Where you would normal find skeletons patrolling the area are now inhabited by warewolves, fire wolves, and other once-rarely used creatures. If nothing else, it adds a bit to the difficulty, but also increases grinding opportunities.

** SLIGHT GRAPHICAL CHANGES **
There are... "slight" graphical changes. Not immediately noticeable, but they are slight. And a chunk of ending is missing, but it's for the "worst" ending (the ending you get if you took too damn long), so it works... I guess.

That's all I got for now. There might future updates or tweaks, but for now, this is it and it turned out alright for the most part. Good enough for public consumption, at least.

Good night,
DTM
dtmblog2012(at)gmail(dot)com
dtm(six)(six)(six)(dot)com
