Castlevania II - Simon's Quest
Mapper Conversion Patch
FROM Mapper 1 (MMC1) TO Mapper 5 (MMC5)
Converted by Dracula X
RELEASE DATE: 10/10/19
Last Modified: 5/12/2020




PRG Bankswitch Routine is at $C183

To switch banks from $C000 - $FFFF, use like so:

LDA bank_number
JSR $C183
JMP to any location in $8000-$BFFF




CHR Sprite Bankswitch Routine (Left side of PPU) is at $C156

To switch sprite pages, use like so:

LDA page_number
JSR $C156




CHR Background Bankswitch Routine (Right side of PPU) is at $C16C

To switch background pages, use like so:

LDA page_number
JSR $C16C




Nametable Mapping Routine (one of its uses is mirroring) is at $C140

To change mirroring for instance, use like so:

LDA mirroring_number (#$50 for Horizontal, #$44 for Vertical)
JSR $C140

Hacks supported:
All!

A note about Super Castlevania 2 hack, on the hack file go to Hex location $05 and change
$08 to $10 and at ROM location $30010, in Hex Workshop, in Edit, go to insert and on the
Insert Bytes, insert number of bytes 10000 in Hex and fill the hex byte with 0's then save
the file. And now patch my MMC5 xdelta hack to your hack and now your hack will work with
my MMC5 hack.

Hacks not supported:
Castlevania II retranslation - Simon's Quest suomeksi
or
Castlevania II (Simon's Quest) - Multilingual enhancement

Use Delta Patcher to patch the xdelta file to the ROM. 
Ignore the checksum and then patch the file.

Credits:
Rockman or RetroRain: for info on how to convert the mapper!
Disch: for his mapper docs and a better MMC5 startup!
Bregalad: for info about the game keeps on crashing!

Changes for this version 1.1a
Fixed something in the MMC5 Setup that will allow Simon's Quest: Lame Edition
hack to work!

Changes for this version 1.1
Changed the bankswitch code to $C183. I was able to add the code
into PRG swapping.

Original Mapper Converter
Bisqwit
None of his work have not been used in this hack.

Non Supported Emulators:
Nintendulator
RockNES
VirtuaNES