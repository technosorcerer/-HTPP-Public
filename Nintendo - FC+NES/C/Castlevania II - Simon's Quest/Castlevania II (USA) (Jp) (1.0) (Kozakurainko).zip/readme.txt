               
This is an NES/Famicom  Japanese Translation for Castlevania II Siomon's Quest
----------------------------------------------------------------------------------------------------------------------

Just patch this to the following rom, Castlevania II - Simon's Quest (U) [!]


ALL CREDIT FOR THIS WORK GOES TO THE FOLLOWING

Kozakurainko    :  Translating

http://www.geocities.jp/hlc6502/Kozakura.htm
 --------------------------------------------------------------------------------------------------------------------- 

Castlevania II Siomon's Quest was only released in Japan as an FDS game. 

Its original title is Dracula II: Noroi no Fuin