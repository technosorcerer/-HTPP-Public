




CastleVania II Remix v0.85

Hacked by P.B.E (aka Thaddeus) 
totmacher_2001@yahoo.com

04/23/02



cv2_remix.zip includes two separate IPS; cv2remix_a.ips (CV2Remix with hacked/modified music/SE) 
and cv2remix_b.ips (CV2Remix, without hacked music/SE). - I'm doing this because some of you 
may not like Castlevania II Remix's new music.



- What's new in v0.85?


Everything, basically. The levels, graphics - everything has been vastly improved.

*Dracula's Tomb is now accessable.

*Many special items have been temporarily removed to make your playing experience a miserable 
one; there are also new areas to explore and puzzles to solve. 

*Fixed text box/pause screen.

*Edited more enemy sprites; removed a few monsters as well.

*Updated Mansions 3, 4, and 5.

*Edited the area where you obtain the Flame Whip.

*Changed Dracula's Tomb/Crumbled Castle to resemble the first level of Castlevania Remix.

*Edited some text.


The game is by no means complete; there's a lot that hasn't been hacked. There are levels
that need work.... Some areas are currently unaccessible. Certain special items,
cannot be obtained in this version. More enemy data needs to be found. The music and graphics
really suck at this point. And, I haven't had a chance to thoroughly test this hack for bugs, 
either. 

PLAY AT YOUR OWN RISK!




-Thaddeus







Special thanks to:

My pal, BrandonKoopa. His Castlevania II level editor saved me a great deal of trouble. 
Especially with editing those friggin' mansions... it would have taken me years to do all that
crap with Hex Workshop alone! 

Kent Hansen aka SnowBro, of course - whose utilities made this hack even 
possible... I hope he digs this Castlevania II edit as much as he did CVRemix. :)

Eric Roman, Anapan, and all the guys from the CV forums(CVI/DCTMB!); my fellow Castlevania 
fanatics -this hack's for you. :P



---------------------------------------------------------------------------------------







