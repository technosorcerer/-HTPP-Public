+------------------------------------------------------------------------------+
| Title: Castlevania 2 - Simon's Quest (U) [Moody Colors]                      |
| Author: F0                     |                                             |
| Version: 1.0                                                                 |
| Date: 7 Jan 2012                                                             |
|                                                                              |
|------------------------------------------------------------------------------|
| About:                                                                       |
|------------------------------------------------------------------------------|
| A cosmetic patch for giving a moody look to Castlevania 2 Simon's Quest (U)  |
|                                                                              |
|                                                                              |
|------------------------------------------------------------------------------|
| In more detail:                                                              |
|------------------------------------------------------------------------------|
| - Enphasizes the mood of the scenes                                          |
|                                                                              |
| - Makes the scenes more convincing regarding the way in which a light source |
| at different times of the day would change the colors in each scene.         |
|                                                                              |
| - Enhances perspective by separating planes by hue and by making colors      |
| considered belonging in the same distance plane more analog -specially the   |
| backgrounds- while shifting hues and contrasting values in the the closer    |
| planes in order to give them a bit of air in between them.                   |
|                                                                              |
|                                                                              |
|------------------------------------------------------------------------------|
| What you need to use this patch:                                             |
|------------------------------------------------------------------------------|
| - A (USA) rom of Castlevania 2 - Simon's Quest (U) 262,160 bytes; I leave    |
| you alone on this one, but maybe Google...                                   |
|                                                                              |
| - A NES emulator. Whatever you use should work, but If you ask me, I prefer  |
| VirtuaNES: http://virtuanes.s1.xrea.com/bin/virtuanes097e.zip                |
|                                                                              |
| - An IPS patcher such as Lunar IPS:                                          |
| http://fusoya.eludevisibility.org/lips/download/lips102.zip                  |
|                                                                              |
|------------------------------------------------------------------------------|
|  What this zip contains:                                                     |
|------------------------------------------------------------------------------|
| - The patch itself in .ips format                                            |
| - The readme (this file)                                                     |
| - The palette I made for use in your favorite emulator (it *should* look     |
| better with this but it's completely optional)                               |
|                                                                              |
|------------------------------------------------------------------------------|
|  A quick help on patching:                                                   |
|------------------------------------------------------------------------------|
| If you don't know how to patch, then download Lunar IPS:                     |
| http://fusoya.eludevisibility.org/lips/download/lips102.zip                  |
|                                                                              |
| - Extract all files (it's ok if you put them toghether)                      |
| - Run "Lunar IPS.exe"                                                        |
| - Click on "Apply IPS Patch" and select this patch (the .ips file)*          |
| - Then select the rom file**, mine is:"Castlevania 2 - Simon's Quest (U).nes"|
| - Enjoy                                                                      |
|                                                                              |
| *Note that you have to navigate to the files' respective paths if they are   |
| not in the same folder than Lunar IPS, and both, the ips and the rom must    |
| be in decompressed form.                                                     |
|                                                                              |
| **My rom's size is 262,160 bytes (not the size on disk) so if the patch does |
| not work for you, your rom is not the right one, so try please another one.  |
|                                                                              |
|                                                                              |
|------------------------------------------------------------------------------|
| What was modded:                                                             |
|------------------------------------------------------------------------------|
| All color palettes.                                                          |
|                                                                              |
|                                                                              |
|------------------------------------------------------------------------------|
| Closing:                                                                     |
|------------------------------------------------------------------------------|
| This is my first mod, I hope you like it, Bye.                               |
| F0.                                                                          |
|                                                                              |
+------------------------------------------------------------------------------+