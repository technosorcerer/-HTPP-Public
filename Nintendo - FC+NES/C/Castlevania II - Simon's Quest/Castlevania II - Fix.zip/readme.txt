cv2a.zip = scrambled > fixed
cv2b.zip = fixed > scrambled