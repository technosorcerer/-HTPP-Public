=== CV2 Simon restore & Good looking life bar hack ===

This hack does two things :
1) Restore Simon Belmont in CV2 to what it looked like in CV1 by means of palette swapping
2) Change the lifebar to look better and be more accurate (now 1 pixel = 1 HP, in the original it was 1 dash = 4 HP).

The palette swap also alters some others elements in the game but I made sure it still looked right after the change.

THIS HACK IS TO BE APPLIED OVER A NTSC-USA Castlevania II (U).nes ROM.

This hack is suitable to be applied in combination with most CV2 hacks released. Versions 2.1 (and above) of this patch are compatible with the retranslation v.1.4 (and above).

WARNING : To have this hack applied in combination with the CV2 Moody hack by F0 it is nessesarly to FIRST patch CV2 Moody, THEN use this patch. Doing it the other way arround will produce incorrect colours on the screen.
For other known hacks, the order of patching does not matter, including with the retranslation.

Versions :

v2.1 January 6th 2013
I changed the life bar system again this time only 4 sprites are used, so the free BG tiles are still free, and this hack is now compatible with the retranslation.

v2.0 December 23rd 2012
I did some ASM hacking to make new looking life bar, using the 20 BG tiles that were left unused from the FDS->NES transition. (this also frees the 6 tiles used for the old life bar)
Now the "flame" palette remains unaffeted, making this closer to the original game.

v1.1 December 21st 2012
Fixed some palettes of other sprites that shared the palette with Simon that were left as-it in v.1.0
(namely the book, bum and bag sprites weren't fixed)

v1.0 December 17th 2012
Initial (and very likely only) release