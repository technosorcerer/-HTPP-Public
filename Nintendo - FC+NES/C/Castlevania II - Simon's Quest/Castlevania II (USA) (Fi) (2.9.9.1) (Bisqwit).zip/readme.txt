Castlevania II Finnish translation and English Re-translation
By Bisqwit

==Features of this patch==
NTSC version (there is also a PAL option)
VRC6 chipset (there is also a MMC1 option)
Added dialog in select locations - Small changes that will improve the game experience without changing the nature of the game.
The Japanese version of the returning functions - Contains the extended text ending, as well as Konami-style Start beginning text on the screen.
Map function - A map is included. It showed how these places are connected to each other, compensating for the lack of actual game manual that shows the same. Press the select button to view the map.
Advanced password encryption - Passwords that are encrypted with extended functionality, can be decoded by the original (English) versions of the game. The function expands the repertoire of passwords.
Language - Finnish.