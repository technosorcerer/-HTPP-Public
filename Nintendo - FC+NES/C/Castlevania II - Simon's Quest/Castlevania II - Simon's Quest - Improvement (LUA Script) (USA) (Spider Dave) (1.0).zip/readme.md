Emulator Lua scripts for use with FCEUX.  FCEUX 2.3.0 is recommended.  Get it at http://fceux.com/web/download.html

Castlevania 2 Lua Script:

You will need:
* Windows
* FCEUX
* Castlevania 2 Rom (No-intro version)
* The script (or just run update.exe).

How to use:
* Place the "update.exe" file in the "LuaScripts" folder inside the FCEUX folder.
* Run "update.exe" and press "Update" button.
* Run FCEUX
* "File" --> "Open Rom... --> "Castlevania II - Simon's Quest (USA).nes"
* "File" --> "Lua" --> "New Lua Script Window..." --> "Browse..." --> (select a script such as SpiderDave_Castlevania2.lua) --> "Run"

Note: There are a lot of things unfinished, broken or exploitable at the moment :(

----
 Super Mario Bros Framework Lua Script:
 Follow the instructions as above, except the updater is updateSMB.exe and use "Super Mario Bros. (World).nes".