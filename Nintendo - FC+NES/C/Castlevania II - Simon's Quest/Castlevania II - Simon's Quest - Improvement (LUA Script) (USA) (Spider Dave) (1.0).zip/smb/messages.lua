local toad = {
    {
        {
            {2,10, "TOAD: SORRY _player_ BUT YOUR"},
            {2,11, "SZECHUAN MCNUGGET DIPPING"},
            {2,12, "SAUCE IS IN ANOTHER CASTLE."},
        },
        {
            {2, 14, "_player_: I WANT THAT MULAN"},
            {2, 15, "MCNUGGET SAUCE TOAD."},
            {2, 16, "THATS MY  SERIES ARC."},
        }
    },
    {
        {{8,10, "THANK YOU _player_!"}},
        {
            {1, 14, "BUT OUR PRINCESS IS IN ANOTHER"},
            {1, 15, "CASTLE...LOOK YOU SHOULD REALLY"},
            {1, 16, "KNOW THIS BY NOW.  SHES IN 8-4."},
        }
    },
    {
        {
            {2,10, "OUR PRINCESS IS IN ANOTHER"},
            {2,11, "CASTLE BUT I HAVE GOOD NEWS"},
        },
        {
            {2, 14, "I JUST SAVED A BUNCH OF MONEY"},
            {2, 15, "ON MY CAR INSURANCE BY"},
            {2, 16, "SWITCHING TO GEICO."},
        }
    },
    {
        {{8,10, "IM NOT TOAD."}},
        {
            {1, 14, "I GUESS WE ALL LOOK ALIKE TO"},
            {1, 15, "YOU.  RACIST."},
        }
    },
    {
        {{9,10, "SORRY  NOTHING"}},
    },
    {
        {{8,10, "THANK YOU _player_!"}},
        {
            {5, 14, "BUT OUR PRINCESS IS IN"},
            {5, 16, "ANOTHER ROMHACK!"},
        }
    },
    {
        {{8,10, "THANK YOU _player_!"}},
        {
            {5, 14, "BUT OUR PRINCESS IS IN"},
            {5, 16, "ANOTHER CASTLE!"},
            {9, 19, "IM THE BEST!"},
        }
    },
    {
        {{8,10, "THANK YOU _player_!"}},
        {
            {5, 14, "BUT PLEASE STOP STARING"},
            {5, 16, "AT MY HEAD LIKE THAT."},
            {5, 19, "IT'S CREEPING ME OUT."},
        }
    },
}

--local princess = {
--    {
--        {{8,10, "THANK YOU _player_!"}},
--        {
--            {7, 13, "YOUR QUEST IS OVER."},
--            {3, 15, "WE PRESENT YOU A NEW QUEST."},
--            {10, 18, "PUSH BUTTON B"},
--            {8, 20, "TO SELECT A WORLD"},
--        }
--    },
--}

local princess = {
    {
        {{8,10, "THANK YOU _player_!"}},
        {
            {7, 13, "YOUR QUEST IS OVER."},
            {3, 15, "WE PRESENT YOU A NEW QUEST."},
            {10, 18, "NEW QUEST DLC"},
            {7, 20, "ONLY 49.99 ORDER NOW!"},
        }
    },
    {
        {{8,10, "THANK YOU _player_!"}},
        {
            {5, 14, "BUT OUR MUSHROOM RETAINER"},
            {5, 16, "IS IN ANOTHER CASTLE!"},
        }
    },
    {
        {{8,10, "THANK YOU _player_!"}},
        {
            {5, 14, "BUT MY LUGGAGE IS IN"},
            {5, 16, "ANOTHER CASTLE!"},
            {8, 20, "GO GET IT."},
        }
    },
    {
        {{8,10, "THANK YOU _player_!"}},
        {
            {7, 13, "YOUR QUEST IS OVER."},
            {3, 17, "NOW BRING THE ROYAL CARRIAGE"},
            {3, 19, "AND A PROPER ENTOURAGE."},
        }
    },
}

messages = {toad = toad, princess = princess}

return messages