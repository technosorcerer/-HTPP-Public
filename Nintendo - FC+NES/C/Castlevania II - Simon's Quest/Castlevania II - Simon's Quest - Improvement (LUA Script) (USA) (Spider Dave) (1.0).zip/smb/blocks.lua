local blocks = {
    brickTop = {
        image = "brickTop",
        tile = 0x51,
    },
    custom = {
        image = "customBlock",
        tile = 0x61,
    },
    test = {
        image = "test",
        tile = 0x61,
    },
}

return blocks