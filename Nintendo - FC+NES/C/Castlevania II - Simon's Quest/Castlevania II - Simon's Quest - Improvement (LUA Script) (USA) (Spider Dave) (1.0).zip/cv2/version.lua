version={stage="beta", date="2019.06.11", time=" 4:19:18.56"}
