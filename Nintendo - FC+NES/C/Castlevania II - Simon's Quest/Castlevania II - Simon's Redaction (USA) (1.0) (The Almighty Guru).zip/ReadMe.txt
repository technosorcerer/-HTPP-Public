Simon's Redaction
------- ---------
by TheAlmightyGuru

This patch fixes up some problems with Simon's Quest to make it more enjoyable. Apply it using Lunar IPS,
available in RHDN's "Utilities" section.

Dialog Changes

    All of the "false hints" have been removed. This game is hard enough to figure out on its own, and
    the items are too costly to waste.
    Some of the dialog has been moved around in the game to make it flow smoother. Thus, you are no
    longer told, halfway through the game, that churches heal you.
    Someone in each town will tell you which town you're in. This makes navigation easier.
    Place names now match those found in the game's literature. Ondol is now properly Oldon; Alba is
    Aldra; etc.
    The really vague hints have been made clearer. You no longer need to know what "a flame flickers
    inside the ring of fire" means.
    Several more hints have been added throughout the game that help explain what you need to do and
    where you need to go next.
    Signs are much more descriptive. They tell you the direction to other towns, mansions, and landmarks.
    The prologue explains the story much better.
    The endings have been rewritten so that they are now fitting for how well you do.

Program Changes

    Text is written to the screen a lot faster so you don't have to wait as long to read the messages.
    The transition from day to night is much faster. I took it from 10 seconds down to 4 seconds.
    The Grim Reaper has twice as many hit points as before, though he's still pathetically easy.

Graphic Changes

    A couple extra symbols have been added to the font including arrows and an ampersand. These make the
    sign dialog more concise.
    Dracula's face has been redrawn. Many people complained that he looked like Death, so I replaced his
    face with the vampire graphic from the password screen.
