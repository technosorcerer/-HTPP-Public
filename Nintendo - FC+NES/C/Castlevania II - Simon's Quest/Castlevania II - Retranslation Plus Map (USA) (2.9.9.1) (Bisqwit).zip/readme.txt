Castlevania II Finnish translation and English Re-translation
By Bisqwit

==Features of this patch==
*NTSC (American) 
*MMC1 (NES)
*Added dialog selected locations - Small changes that will improve 
the game experience without changing the nature of the game.
*The Japanese version of the returning functions - Contains the extended 
end of the text, as well as Konami-style Start beginning of the text on the screen.
*Map function - Original Japanese release about the game were sold in the instructions. 
The instructions were involved mm. a map showing how to play these places 
are connected to each other. Western publications, including Finnish (which 
was in English), the map, however, was missing, and this is one of the reasons 
why the game is haukuttu too difficult to understand. I added the Finnish 
translation of the in-game map feature. Press the select button to view the map.
*Advanced password encryption - Passwords that are encrypted with extended 
functionality, are refundable in the original (English) in the game. Function 
in practice, but to expand the repertoire of passwords.
*Password features (Location of the return) - Save Your may, in certain circumstances, 
generating passwords, the basis of which the game is not practically possible to 
continue later. For example, Simon returns to the middle of the lake, even if the 
password had been made ??on the beach.
*Language - Finland Retranslated English