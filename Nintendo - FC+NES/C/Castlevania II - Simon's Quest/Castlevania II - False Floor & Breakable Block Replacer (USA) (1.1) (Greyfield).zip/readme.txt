*************************************************************
*** Castlevania II False Floor & Breakable Block Replacer ***
***            V1.1, 09/07/2020, By Greyfield             ***
*************************************************************

Included are two small patches that change the tiles associated with false floors/walls and breakable blocks in Castlevania II: Simon’s Quest. In the base game these look just like every other block, which compels players to throw holy water on every surface to progress and avoid significant backtracking. For mansions where they are most prevalent, one can assume the intent was to make them dangerous places full of traps and secret passages, but its implementation feels unfair and designed to frustrate.

The two patches change the tile graphics in different ways:

Conspicuous Color and Pattern Changes.ips - This patch changes false floors/walls and breakable blocks in pretty clear and obvious ways. False floor/wall tiles have been made monochrome and flat in appearance to look more like the background objects they are, while breakable blocks look cracked and, well, breakable. This is intended for, say, younger players, or those who simply don’t want to be troubled with this aspect of the game. Images are included of these new tiles appearances.

Subtle Pattern Change.ips - This patch changes false floors/walls and breakable blocks in a uniform and more subtle way, which is more consistent with the traps and secrets part of the original game. With this patch, players should still watch where they’re walking, and stop frequently to look at their surroundings, especially in mansions. Players will also want to test these surfaces with holy water to distinguish between the two types of tiles. No image is included of this new tile appearance.

************************
*** Additional Notes ***
************************

This patch should be compatible with most others, so long as the location of tile sets or the behaviors of tiles have not been modified.

That said, Bisqwit’s Castlevania II English Re-translation (+Map) hack (https://www.romhacking.net/reviews/5026/) adds new tile sets, so I've included versions that modify those as well.  These patches were built off his English v2.12.0.1 patch with the default options; see his hack page and personal website for details.  Apply one of the Bisqwit compatible patches to ROM that has been already been patched with his hack.

I would be remiss not to mention that this this patch was inspired by tkempkes’ Castlevania II Annoyances Fixes (https://www.romhacking.net/hacks/912/). One of his patches removes, instead of replaces, most, but not all, false floors from the game. This is my expanded take on it.

This patch was made using YY-CHR tile editor, CursEd Castlevania II level editor, and Lunar IPS. Apply to the ROM below using an IPS patcher, e.g., Lunar IPS or Floating IPS.

Castlevania II - Simon's Quest (U) [!].nes
CRC32: A9C2C503
MD5: 1B827C602C904D8C846499C9F54B93E0
SHA-1: D6B96FD98AE480C694A103FE9A5D7D84EEAFB6F7
SHA-256: F045D72683D3156555ECCBB56090888F03A15E5B25E59DB49DCA7A87330472D3

Updates:

V1.1: Added patches for Bisqwit's Re-translation (+Map) hack.
