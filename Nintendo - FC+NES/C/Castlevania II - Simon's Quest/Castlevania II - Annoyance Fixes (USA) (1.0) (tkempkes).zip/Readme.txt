4.8.2012
Castlevania II: Simon's Quest Annoyance Fixes, by tkempkes

Change Log
==========
4.8.2012: Initial release

These patches were tested with the following ROM:
Filename: Castlevania II - Simon's Quest (U).nes
CRC32: 0xc471e42d
MD5: 0x755f9086b0567243b3ce25cc8a6dfd17

Recommend using Lunar IPS to apply these patches.

This package includes a number of individual patches which are intended to improve some of the more annoying features of Castlevania II.  The patches have been kept separate in order to make it easy for players to leave out any undesired changes.

The changes include:

- 'CV2 Double Hearts.ips': Doubles the heart values in order to allow the game to progress faster.

- 'CV2 False Floors.ips': Effectively removes the false floors by replacing them with empty space.  This is intended to save the frustration of having to throw holy water all over the mansions.

- 'CV2 Fast Transition.ips': Completely removes the infamous "horrible night" dialog box, making the day/night transitions much faster.  Note that when used together with the fantastic 'Simon's Redaction' hack, some players may find that the day/night transitions happen uncomfortably fast.  This is because 'Simon's Redaction' speeds up the rate of the fade out and fade in during the transition.  To address this, an additional ips has been included ('CV2 Fast Transition, Redaction.ips') to restore the fade rate back to its original state.
