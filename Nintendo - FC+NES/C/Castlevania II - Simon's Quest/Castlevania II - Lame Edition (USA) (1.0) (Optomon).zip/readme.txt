SIMON'S QUEST: LAME EDITION

Nothing too special about this game, 
really. I just made it as practice 
to familiarize myself with the CV2
engine. I'm supposed to be working 
on a legitimate Simon's Quest game, 
but for now this cheeseball hack
have to do.

The game is confined to a small area. 
And, yes, it is possible to beat.

--optomon 05/22/10