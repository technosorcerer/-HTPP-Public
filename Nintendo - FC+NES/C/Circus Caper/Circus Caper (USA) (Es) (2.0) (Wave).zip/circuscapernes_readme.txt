Circus Caper (NES)
Traducción al Español v2.0 (23/03/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Traducida licencia y título
-Guion retraducido
-Traducida barra de estado
-Traducido GAME OVER
-Traducido THE END
-Traducidos minijuegos
-Nueva fuente en minúsculas

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Circus Caper (USA).nes
MD5: 216c212ed02b8cb4122aaaaa13ca8d23
SHA1: 43e94e0eb5c9f568ae78149963a9118506bfdf9d
CRC32: bce1da2c
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --