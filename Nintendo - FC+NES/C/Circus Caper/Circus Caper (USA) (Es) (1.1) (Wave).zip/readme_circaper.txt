Circus Caper
Traducci�n al Espa�ol v1.1 (08/05/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Circus Caper
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Circus Caper
-----------------
Un plataformas con buenas ideas con unas colisiones y f�sicas que desgraciadamente arruinan el juego :(
Este parche lo traduce completamente al espa�ol excepto pantalla de inicio y de juego.

v1.1: Revisi�n de script y fallos en minijuegos.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es original y solo a�ade min�sculas y caracteres especiales.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Circus Caper (U) [!].nes
262.160 bytes
CRC32: bce1da2c
MD5: 216c212ed02b8cb4122aaaaa13ca8d23	
SHA1: 43e94e0eb5c9f568ae78149963a9118506bfdf9d

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n al Espa�ol

-- END OF README --