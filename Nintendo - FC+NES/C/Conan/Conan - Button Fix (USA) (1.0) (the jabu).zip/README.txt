
   Conan  (Button Fix) V 1.0 / hack by The Jabu    
 ------------------------------------------------
   This is a hack for the game "Conan - The Mysteries of Time" for the NES,
  that fix the strange configuration of the controller, so now the game is
  more playable.


 CHANGES:

V 1.0

 - Changed the configuration of the buttons:


       LEFT/RIGHT : Move Conan left or right.

       UP : Jump straight up.

       UP+LEFT / UP+RIGHT :  Jump forward in direction facing.

       UP then LEFT or RIGHT : Controlled jump.

       DOWN : Crouch down  and pick up items.

       START : Enter item menu.

       B : Kick.

       A : Punch.

       Hold A or B  then UP : Jump kick.





Apply the IPS file to  "Conan - The Mysteries of Time (U) [!].nes" , and have fun!!!



note 1: sorry for my english , but english is not my native language.
 
  