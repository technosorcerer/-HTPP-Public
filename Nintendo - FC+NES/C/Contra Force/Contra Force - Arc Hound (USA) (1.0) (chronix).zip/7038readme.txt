Arc Hound (NES)

Alternative title screen for Contra Force.

Made by Andrei Vdovin a.k.a. Chronix.
Email me if you find glitches in this game.
Thanks in advance!
chronix@bk.ru

Original ROM:
-----------------------
Contra Force (U) [!].nes
File size: 262 160

 PRG ROM:    8 x 16KiB
 CHR ROM:   16 x  8KiB
 ROM CRC32:  0xa94591b0
 ROM MD5:  0x2f2cb4ec9936d23f370f9991e84cce98
 Mapper #:  4
 Mapper name: MMC3
 Mirroring: Horizontal
 Battery-backed: No
 Trained: No
