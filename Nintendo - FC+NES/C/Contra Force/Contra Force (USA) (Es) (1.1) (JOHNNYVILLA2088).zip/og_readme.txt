"Contra Force"
Traducci�n al Espa�ol v1.1 (28/04/2019)
 POR JONYVILLA2088

1. Sobre Contra Force
2. Notas del Proyecto
3. Fallos
4. Instrucciones de Parcheo
5. Derechos

---------------------
1. Sobre Contra Force
---------------------
"Contra Force" fue el juego que en Jap�n se iba a llamar Arc Hound, pero fue cancelado. fue rebautizado con el nombre Contra Force, y lanzado s�lo en Am�rica.
---------------------
2. Notas del Proyecto
---------------------
Fue uno de mis primeras traducciones ya que habia pero la borraron, fue algo dif�cil reconocer los textos con el traductor hexadecimal.
Las palabras command select, wait, player select (al menos mediante tablas) y otro texto que faltaba se han traducido . 


--------------------------------------------
3. Fallos Conocidos
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a jonathanjavier208@gmail.com 

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Debes utilizar el rom:

Contra Force (USA) recomiendo buscarla en la p�gina: https://www.emuparadise.me

-----------
5. Derechos
-----------
Contra Force NES es propiedad de konami.co (c) 1992.
Traducci�n al espa�ol por JONYVILLA2088.
Licencia de Nintendo de Am�rica INC.
No distribuir la rom y el parche unidos.



Saludos y espero que disfrutes del juego.