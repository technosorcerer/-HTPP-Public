Captain Tsubasa Vol. II - Super Striker (J)

This translation was made by hayabusakun
http://www.youtube.com/profile?user=hayabusakun
http://www.freewebs.com/okonogi/

He granted me the permission to make an ips patch from his work.
So here's its it �.�.

About the game:

This game is based in the popular anime series. Some events in it
doesn't occur in the series, and some of the shots were created for
the game.
The game has a long plot, lots of animations, great effects for the
special shots and an awesome soundtrack. If you liked the first game
for the NES you'll surelly love this one.

I want to congratulate and give my thanks to hayabusakun for making
this great work and for allowing me to make the patch based in it.

