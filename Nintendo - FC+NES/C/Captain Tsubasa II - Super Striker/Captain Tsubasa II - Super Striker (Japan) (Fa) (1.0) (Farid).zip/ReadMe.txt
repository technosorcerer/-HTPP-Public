Captain Tsubasa II: Super Striker (NES)
Persian Translation Patch
� 2015 by Farid 
Faridman1364@hotmail.com
http://www.microbaz.blogfa.com

Translating this NES game was my childhood dream, now it is fulfilled!
It is fully translated and playable!
If you find any bug or any untranslated sentence please inform me.
Cheers!

=====================
Version Info
=====================
Version              1.0
Release Date      30 January 2016
Status                100% Translated

=====================
Patching Instructions
=====================
1. Download Lunar IPS from : http://fusoya.eludevisibility.org/lips/index.html
2. Apply CTII (Fa).ips to the Captain Tsubasa Vol. II - Super Striker (J) [!].nes
3. Enjoy!

=====================
Original Japanese ROM Info
=====================
CRC:          31B44C65
SHA-1:        AD2EC724D6E2DC8E396995431DD2E10995222ED8
System:       Famicom
Board:        HVC-TLROM, Mapper 4
PRG-ROM:      256k
CHR-ROM:      128k

=====================
Thanks to (A~Z)
=====================
A.F.H
ADNAN
CAH4E3
ExtraOrdinary
FAROUK
FELIX
KingMike
Mahmood S. Lattouf
MR_KP
OLIVEIRA
SINA
SODAGAR
YAHIKO

And finally special thanks to the Stargazers, without their help, how could we have succeeded?