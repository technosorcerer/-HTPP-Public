Crayon Shin-Chan: Ora to Poi Poi (NES)
English patch v.0.1 by Alcy
http://alcy.tenkeimedia.com/
October 20, 2003
______________________________________

DISCLAIMER: Only use this patch if you own the actual game cartridge. I am not supporting piracy, nor am I providing ROMs to go with any patches. I am not responsible for any damage caused by use or misuse of this patch (though that would be nearly impossible).

This is my first translation project, and it's going pretty fast. (I started about four days ago). Please note that this patch is for the standard dump of the ROM, not the [01] version. Before you flame me, the glitches were there before the game reached my hands. (Hint: If you can't get the first level to load, hit start during the dialogue between Shin-chan and Shiro)

Due to limited space, I've had to abbreviate a few names. Most of these should be obvious, but I'll list them here just in case.

Ne'sMa = Nene's Mama
Shin= Shin-chan (Shinnosuke)

To apply patch: Get an IPS utility program (I recommend SNESTool.), rename the patch to match your ROM (Have crayon.nes? Make the patch crayon.ips), run it through (check your IPS program's instructions.).
______________________________________
Version 0.1 (approx 15-20% complete)

-Names: Shin, Shiro, Nene, Ne'sMa inserted
-Dialogue from first course about 70% complete
-Several title graphics translated
______________________________________
Questions/Suggestions/Comments? Send them to me at tenmanokami@aol.com. Make sure you include "Translation" in the subject line!