Crystal Mines (USA) (Unl).nes
Traducido por koda 2024

------------------------------------------------------------------------------------------
INDICE
------------------------------------------------------------------------------------------

1. INSTRUCCIONES
2. VERSIONES
3. ERRORES CONOCIDOS
4. CONTACTO

-------------------------------------------------------------------------------------------
1. INSTRUCCIONES
-------------------------------------------------------------------------------------------

La ROM es:

Database match: Crystal Mines (USA) (Unl)
Database: No-Intro: Nintendo Entertainment System (v. 20210216-231042)
File SHA-1: 4D068EA8F41675D3D2471211DF1B4709D07C4FE7
File CRC32: 245AB38B
ROM SHA-1: 7D92E71E23B35943147C513CAAB7AAB4B4927DD6
ROM CRC32: 72E66392

Utilizen "Lunar IPS" o "Floating IPS"
Pueden descargarlo de acá:
https://www.romhacking.net/utilities/240/

-------------------------------------------------------------------------------------------
2. VERSIONES
-------------------------------------------------------------------------------------------

versión 1.0 (19/02/2024):

- Traducción completa.
- Graficos editados.

versión 1.1 (20/02/2024):

- Traducida pantalla final.

-------------------------------------------------------------------------------------------
3. ERRORES CONOCIDOS
-------------------------------------------------------------------------------------------

- No que yo sepa, informar alguno.

-------------------------------------------------------------------------------------------
4. CONTACTO
-------------------------------------------------------------------------------------------

Traducción hecha por rodrigo muñoz, alias koda
Cualquier error enviar un mensaje a mi correo rodrigo.23luis@gmail.com