Commando
Traducci�n al Espa�ol v1.0 (06/07/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Notas del Proyecto
2. Fallos Conocidos (o: Bugs que no son bugs)
3. Instrucciones de Parcheo
4. Cr�ditos del Parche

---------------------
1. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
2. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
3. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Commando (U) [!].nes
131.088	bytes
CRC32: 41492df6
MD5: 04763afda47b3d10375059c7dbed8bd2
SHA1: b665b128215f7cf0dcdf91e7ba75fc406885216c

----------------------
4. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --