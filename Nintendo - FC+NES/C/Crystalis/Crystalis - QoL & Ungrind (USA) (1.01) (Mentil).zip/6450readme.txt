Instructions: apply either the 'Crystalis QOL & ungrind.ips' or 'Crystalis QOL.ips' patch to a headered Crystalis (U) ROM,
	OR the 'God Slayer QOL & ungrind (Stardust Crusaders).ips' or 'God Slayer QOL (Stardust Crusaders).ips' patch to a God Slayer ROM patched with Stardust Crusaders' translation. Note that due to differing locations in ROM, none of these will work with a stock God Slayer (J) ROM.


Changes:

Equipping orbs and bracelets is no longer necessary. Upon exiting the inventory screen, the respective Power will go into effect for your equipped sword.

Attempting to cast a spell with insufficient MP now leads to a single error beep and no interruption of gameplay, rather than a pause and a window opening up.

There is now an additional way to get Tornel to return home, that is a more reasonable prerequisite. In the God Slayer version of this patch, Stom now gives a hint to this instead of a red herring; a hint was also changed for how to progress at Mt. Sable to reflect a different stumbling block.

Dialog boxes should no longer cause screen wobbling on certain emulators (credit to steve_hacks for inspiration/vector). Running on Fceux/Mednafen is confirmed fixed, at least. If your emulator of choice (such as gnes) now has wobble or other issues when it didn't before, use the respective anti_antiwobble IPS for your ROM version.

Fixed a bug preventing one from using level 3 charge attacks when current MP was exactly equal to their MP cost. Additionally, level 3 Bolt had its flashing toned down (it couldn't be fully removed yet still display the associated graphics).

Fixed the Skeleton so that it now has paralysis immunity instead of poison, and shoots bones instead of webs. (I suspect someone typed in data from the line above in the spreadsheet (Blue Spider) here.)



Additionally, in the ungrind patches:

Most enemies had their gold and xp rewards increased to 200-300% of their original values, so almost no grinding should be required in order to progress or complete the game, if you defeat every enemy that crosses your path.

Several enemies had their damage nerfed to more-reasonable levels, and some damage sponges were adjusted so that they should no longer require more than ~6 hits to defeat (at expected levels/equipment). A few enemies had their elemental resistances modified.

Bosses had their level requirements lowered to 1, so there should be fewer cases of encountering a level gate. Note: despite this, late-game bosses have high defense that is insurmountable at too low a level, which isn't fixable without substantially nerfing them (or some recoding effort that'd have broad balance implications). This precludes completing the game below approximately level 14.

Halved MP costs for level 3 charged sword attacks. They should be more useful relative to other spells now.


Changelog:
1.01	Fixed water jelly, mummy, & scorpion XP in ungrind patches

This hack may be modified or used as a base for other hacks, with attribution. Hack made by Mentil.