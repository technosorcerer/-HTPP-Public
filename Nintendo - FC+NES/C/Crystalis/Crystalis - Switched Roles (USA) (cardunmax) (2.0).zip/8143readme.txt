This file is for those who wished for Mesia and Simea to have been switched around for reasons of the imagination.

Needless to say Mesia can be named whatever you wish now as this Crystalis version exists in another dimension.

As such to make the plot fit the town graphics and dialog have been re-arranged with some people renamed to fit the original plot.  

For instance, the biggest hurdle is Amazones, the town of women who hate men.  It is now the town of Monistar the town of abstinate Monks.

Stom and Akahana are also gender swapped to fit this element and half the Draygonian Guard who patrol the town are now women.

See the game to discover other details.

Special Thanks To Zynk