The main purpose of this patch is to remove the boss level check, which
eliminates the need for grinding and makes low level runs possible. I also
made small changes to sword damage and magic spell costs.
You must use a headered ROM for the patch to work.


Gameplay Changes

The game determines if you can injure a boss based solely on your level, this level
check has been removed

You don't have to equip elemental balls to get level 2 sword charges
just having them in your inventory will activate their effect.


Sword Damage

Wind Sword
no charge 1
1 charge  2->3 
2 charge  3->5 
3 charge  6->7 

Fire Sword
no charge 2
1 charge  3->4 
2 charge  4->5 
3 charge  4->5 

Water Sword
no charge 4
1 charge  4->6  
2 charge  6->8  
3 charge  8->10 

Thunder Sword
no charge 8
1 charge  6->8 
2 charge  8->10 
3 charge  8->12 

Sword level 3 charge costs. 

wind Sword 8->2
Fire Sword 16->4
Ice Sword  16->8
Thunder Sword 40->16

Magic Changes

Telapathy spell cost 08->02
Barrier spell cost   01->02
change spell cost    20->10

Item Changes
deo pendant increases mp much faster than before


This is the final version of this patch. If you have any comments or issues
please email me at sethmjackson@gmail.com

