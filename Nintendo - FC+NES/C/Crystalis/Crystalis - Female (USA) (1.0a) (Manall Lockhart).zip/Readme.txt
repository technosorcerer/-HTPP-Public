###########################################

          --- Crystalis ---
		 FEMALE

         http://manallsmods.net

   ... for patch notes, updates, and
       news about my other projects.

###########################################

To install, apply my .ips patch to an unmodified "Crystalis.nes" rom file, then get yourself an NES emulator if you don't have one.


- With this patch you have the option of using the Warrior Ring right from the beginning of the game if you choose Continue. This provides a soft address to the grind, and you won't need to charge your weapon the entire time you're exploring!

Thanks to Mentil, this patch also merges your equipped orb effect to automatically match which sword you are using, regardless of what orb is equipped on the menu.