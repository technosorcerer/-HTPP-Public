Panic At The Mario Disco
by: Jroweboy and Nesdraug

Travel through 5 groovy levels as both Peach and Mario in the search for the ultimate Discothèque!

This hack was made in 10 days during the SMB Jam 2023.  

If it doesn't boot and you are on FCEUX, download FCEUX 2.6.5 

