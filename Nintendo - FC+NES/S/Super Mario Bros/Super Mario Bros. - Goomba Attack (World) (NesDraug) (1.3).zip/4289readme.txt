Super Mario Bros - Goomba Attack by NesDraug V1.3

Lots of fast enemies are lurking in the "background". They can jump out to surprise you at any moment! Try kicking them and use them as a shield. What’s even worse is that the fire flower is not as strong as it used to be.

Changes: 
Version 1.3
- World selector (use A)
- Slightly altered levels to fit the new game mechanics 
- Slightly altered music
- Different colors
- Faster flag
- Timer counts actual seconds

- Faster enemies
- More goombas
- Enemies are in the background
- Enemies go through objects
- Enemies and mushrooms bounce 
- Only bouncing enemies die by stomping
- Piranha plants are replaced by Koopas
- Bullet Bills are now Goombas
- Firebars are the correct length

- Powerups move faster
- Powerups go through objects 
- No Starman
- Fire Mario becomes Super Mario when hit (patch by w7n)
- Spiny egg patch (patch by GoldS) 
- Slow fireballs (will disappear if there’s more than two)
- Higher jumps
- Fast Swimming
- Warps are ”out of order” and you can get lost in glitch world 

Special thanks to Eden.GT for the 100+ collection of patches and feedback.

ROM: Super Mario Bros. (W) [!] - [NES] - GoodNES V3.23b