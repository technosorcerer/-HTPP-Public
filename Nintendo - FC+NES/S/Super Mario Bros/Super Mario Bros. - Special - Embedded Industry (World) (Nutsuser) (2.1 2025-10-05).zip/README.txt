Title: Super Mario Bros. � Special Edition Embedded Industry 
Version: 2.1 
Author: extr1m (registered on romhacking.net as Nutsuser)
Game: Super Mario Bros. (NES) Release date: 04.06.2025

 Description: Special Edition with a unique �Embedded Industry� style � a dark atmosphere, faster tempo, deep visual redesign, and a hack concept that goes beyond the boundaries of traditional Mario. This version also serves as a base template for future SMB1 hacks, featuring a strict, redesigned visual style and palette. Ideal for creators seeking a consistent and clean graphical foundation. This is a refined and improved version of the classic Super Mario Bros., with careful visual tweaks and design enhancements aimed at creating a richer gameplay atmosphere.

 Gameplay changes: 
1) 1 - 2: Lift platforms shortened. 
2) 4 - 2: Two extra non-functional pipes were added to the Warp Zone � they lead to glitch worlds. 
3) A used block was added, and one pipe now comes from a pit. 
4) A Blooper was added to hint at the glitchy abandoned zones. 
5) 5 - 2: One pipe now exits from a pit instead of the floor. 
6) 8 - 3: The pipe comes out of the abyss, not from the ground
7) 8 - 4: Added mushroom block 


 Graphics and visual updates:  
1) Complete palette overhaul � all colors were carefully rebalanced for a richer visual experience. 
2) Clouds and bushes are now more aesthetic and smoothly shaped. 
3) Coins are rounder and slightly larger, adjusted pixel-by-pixel. 
4) Bricks have no white stripe anymore � making them almost invisible against castle walls. 
5) Bowser�s and the Hammer Bros.� hammers were redesigned. 
6) Princess Peach features a completely different sprite (inspired by other hackers). 
7) The flag and the character shown on it have been completely redesigned. 
8) Bowser�s fire breath now correctly points to the right, as it should physically. 
9) Piranha Plants have a completely new look (inspired by other hackers). 
10) 1UP icons and score indicators were redrawn. 
11) Water surface now looks like light waves � visually improved. 
12) Blocks show �squinted eyes� when hit, hinting at shock endurance. 
13) Castle walls and blocks were visually improved. 
14) A slight visual conflict with 8-4�s underwater castle now looks artistically better. 
15) Mushroom platform bases and tops were redesigned. 
16) The axe at the end of castles has been replaced with a bomb (Bob). 
17) Background trees and poles were adjusted for visual harmony...
18) Cannons have been fine-tuned. 
19) Previously invisible blocks are now visible.

Patch is intended for Super Mario Bros. (W) [!]