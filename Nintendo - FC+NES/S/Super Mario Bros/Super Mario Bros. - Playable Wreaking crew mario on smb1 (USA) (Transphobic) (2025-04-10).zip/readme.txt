use lunar ips in order to apply this patch because Marcrobledo's Rom Patcher fucking sucks
