This is one of the first romhacks I remember playing. I don't know who created it, but I would think many people remember this. The problem is, it doesn't work on modern emulators. It turns out, by editing a single sprite (tile 0), it causes the game to freeze. The video below describes how this works (the entire video is worth watching it's great.)


https://youtu.be/emA7nkA-EqM?t=703


I copied the original graphics and made a custom title screen.


Tools used:
DOSbox and Nesticle to see if the game even works.
FCEUX for testing and debugging.
Tile Layer Pro for editing some tiles.
SMB Title Editor to make editing the title screen easy.
