SUPER REX DASH - Hack of Super Mario Bros. 

This is a hack that I've been producing, on and off,
for the past few years now. This is a modification of
Super Mario Bros. called Super Rex Dash. 

In the game, you play as the young, adventurous boy
named Rex, who is on a journey to save his beloved
sister, Sophia, from the clutches of a nameless
mechanical tyrant. As you play through the levels, you
will see the vast amounts of robotic fighters and
sentinels, put there for the sole purpose of stopping
Rex. 

Here are some of the general features of this game: 
-New character: Rex
-New levels
-Redone Graphics designed to have a new, minimal feel
-New physics designed to match that of Mario in Super
 Mario Bros. 3

The coolest thing about this hack is that it was done
entirely without assembly hacking. Thanks to Mesen,
fceux, SMB Remodeler, SMBED, SMB Graphics Workshop,
SMBUtil, and my hex editing skills for making that
possible!

Lastly, thank you for playing. I hope you appreciate
my work :)

Patching instructions: 
1. Find a No-Intro Super Mario Bros. (World).nes ROM
2. Patch the ips to it using a tool such as Lunar IPS

DONE!

If you have any questions or support, please contact
me at pgattic@gmail.com


Changelog: 

v1.00 - Initial public release
Features:
-Custom title screen
-Many graphics changed
-Player is always small size
-Custom levels through World 1

v1.06 - 2nd public release
Features:
-Almost all remaining sprites changed
 -All except spiny and buzzy beetle
-NEW: Checkpoint flags version 1
-Improved end castle (looks very nice)
-More customized levels
-Points system divided by 10

v1.07 - 3rd public release
Features:
-Two more custom levels
-Some miscellaneous fixes
