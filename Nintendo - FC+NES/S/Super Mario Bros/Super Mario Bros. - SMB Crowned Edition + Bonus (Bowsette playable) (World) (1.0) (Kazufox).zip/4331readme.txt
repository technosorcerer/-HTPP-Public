Hey everyone, Kazufox here to bring another Super Crown project. This set varies plenty from enemies being the Super Crown variants, Bowsette being playable, or Toads being the primary enemies. See below what each offers. I include a graph chart to better simplify things.

V1.0 - "Crowned Edition"
Crowned Edition offers a variety of skins in the Bowsette boss fight. Choose from: Blonde, Redhead, Dry Bowsette, Daisy, Peach, Rosalina, and Classic Green Bowser colors.
-Replaced Bowser with Bowsette
-Replaced Super Mushroom with Super Crown (because why not)
-Patched Lakitu to properly throw Spiny enemies (for all versions)
-Changed text after completing a castle level
-Replaced all enemies and Toad with Super Crown counterparts

Bonus Content: (differences and special versions)
-Slight variation in other sprites such as hammers, firebreath, and bridge ax or enemy colors in Peach, Daisy, Rosalina, and Dry Bowser versions. Dry Bowsette is also more flat chested.
-Koopa Peach version changes Bowser to Koopa Peach/Princess Bowser which also changes the text when saving "Toad" and the ending.
-Boosette version swaps Mario, Bowsette, and Peach with Luigi, Boosette, and Daisy. Changes the ending and saving "Toad" text.
-Boosette version has changes to background tiles to be more spooky.

"Peach's Counterattack"
Mario and Bowsette come up with a plan to make the princess jealous. It goes well...a little too well. Peach has Bowsette locked up and her army of Toads stand in Mario's way. What's worse is that Yoshi on her side in order to avoid jail for tax evasion! Can Mario save Bowsette from an angry (and highly confused) Princess Peach?
-Most enemies replaced with a Toad variant.
-Replaced castle Toad with a special guest.
-Koopas are replaced by Yoshi (remember to do your taxes, kids).

"VS Dark Bowsette"
The Mushroom Kingdom has been invaded by Dark Bowsette and her evil army. Mario...has gone missing. The only one who can stop her now...is the original Bowsette.
-Bowsette is playable in this version. Blonde variant is player 1 and redhead is player 2.
-All enemies in Super Crown form like Crowned Edition.
-Toad has been replaced by a special guest and friend of Bowsette.
=
ROM Info:
    File Name: Super Mario Bros. (JU) (PRG0) [!].nes
    No-Intro Name: Super Mario Bros. (World)
    (No-Intro version 20130731-235630)
    File MD5: 811B027EAF99C2DEF7B933C5208636DE
    File SHA-1: EA343F4E445A9050D4B4FBAC2C77D0693B1D0922
    File CRC32: 3337EC46
    ROM MD5: 8E3630186E35D477231BF8FD50E54CDD
    ROM SHA-1: FACEE9C577A5262DBE33AC4930BB0B58C8C037F7
    ROM CRC32: D445F698
=
Contact:
If you need to reach me about anything, I'm around on a few places.
Discord: Kazufox#0035
DA: https://www.deviantart.com/kazufox
FA: https://www.furaffinity.net/user/kazufox/
=
Special Thanks:
To the various anons on 4Chan/4Channel's /bowgen/
MFGG
RomHacking.net
tcrf.net 
GoldS (for SMB Spiny patch)
JohnRiggs (for tutorials)
AYYK92
Nintendo
Any and all supporters of the project!
This is #3 in the Super Crown related ROM Hacks released. I look forward to bringing you all more Bowsette related content in the future.

Fun fact, you can play as Bowsette in other various versions if you patch the ROM file after using the "VS Dark Bowsette" patch. Mix and match to see what fun stuff you can get.