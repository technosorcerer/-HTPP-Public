
Batman Bros. Co-Op. by NesDraug (version 1.2)

Story
Bruce Wayne has grown old. He is no longer the Batman he used to be and he still needs to rescue Robin since he got captured by the Penguin. In order to cope he created a Batclone. An almost identical Batman. A brother, if you like. A Batbro.

- Two player co-op mode
- Players are Batman
- Enemies are altered
- Slightly altered levels
- Changed warps
- All colors are changed  
- Mushrooms are now bat masks 
- Fire flower is now Batarang
- Mushrooms are batmask with blue eyes
- Stars are now bats
- Coins are bats
- Bat flag
- Backgrounds are altered
- Game over bat symbol 
- New title screen
- 50 Coins to get 1UP

Process: 
- Sprite editing in NES CHR Editor
- Sprite editing in Tile Layer Pro 
- HEX-editing in FCEUX to fix the colors
- The first buggy version was released in December 2018
- SMB Utility to change levels (in original SMB)
- HxD to import the level data into the Two player hack
- The finished version 1.2 was released in August 2019

This hack is based on the Super Mario Bros. - Two Players Hack by Corpse Grinder and Ti
https://www.romhacking.net/hacks/4180/


Apply the ips file to Super Mario Bros. (W) [!] with Lunar IPS or Multipatch