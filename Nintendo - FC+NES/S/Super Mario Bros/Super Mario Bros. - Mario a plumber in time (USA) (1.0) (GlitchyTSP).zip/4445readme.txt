If you are reading me, first off thank you for even looking at this. 
  
Second off,  
  
This hack has been my main focus for a while and I'm glad it's done and finished now. 
  
Shout outs/credits to:  
  
Oxi (https://www.youtube.com/c/oxiriark), Dynasty Lobster for playtesting 
  
TheCesarVD for a few of the sprites

U1 for the SMB1 music patches 

AP for the SMB3 Mario in SMB1 patch

w7n for the Fire Mario to Big Mario when hit patch
  
Basicaly everyone in the Mario Making Mods discord server

And anyone else who supported me one way or another.


Story: 
Mario and Luigi were helping Professor E. Gad move his ghost lab to a new location,  
however, while they are doing so, they accidently activate E. Gads new and improved 
time machine and the bros are sent back far in time, to a time where Kameks father 
-The elder Koopa wizard- ruled the mushroom kingdom. once they arrive, they are 
immediately noticed by a few castle guards, not knowing what it is, they take the 
time machine back to the main castle for investigation, in fear of being trapped in 
the past forever, Mario makes chasse on his own, leaving Luigi behind. 