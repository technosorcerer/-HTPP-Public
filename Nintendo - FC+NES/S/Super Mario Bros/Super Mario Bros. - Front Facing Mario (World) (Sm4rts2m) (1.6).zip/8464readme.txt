This is a very cursed hack
Small Mario based on Mario from Super Mario Maker.
Super Mario based off SMB1 concept art