Supreme Shit Brothers v1.0
--------------------------
A hack of Super Mario Brothers with some new music and sound effects, as well as enhanced graphics.

System
------
Nintendo Entertainment System

IPS Details
-----------
This IPS patch can be used to patch either the good ROM dump or the well-known bad ROM dump of Super Mario Brothers 1.

Contact Details
---------------
Author: DEMUX
Email: jhumbucker@yahoo.com

Additional Info
---------------
Some information on the music data format is included in the file SMB_MUSIC.TXT.