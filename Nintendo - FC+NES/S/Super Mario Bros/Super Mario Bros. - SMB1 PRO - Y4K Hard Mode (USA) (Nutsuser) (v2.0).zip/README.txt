Description:

Super Mario Pro � Y4K # Hard Mode is a fast-paced and brutally difficult ROM hack of the original Super Mario Bros. (NES).
Designed for maximum speed, precision, and focus � this is a truly insane hardcore experience.
Every jump is calculated down to the smallest detail. There�s no room for mistakes � only pure momentum and forward drive.

This new version expands the game from 6 worlds to a full 8 worlds, bringing the original concept to absolute perfection.

Features:

* Brutal, unforgiving difficulty
* Optimized for ultra-fast, high-pressure gameplay
* Dense and relentless level design
* Now with 8 complete worlds for the ultimate challenge

Patch is intended for **Super Mario Bros. (W) [!].
