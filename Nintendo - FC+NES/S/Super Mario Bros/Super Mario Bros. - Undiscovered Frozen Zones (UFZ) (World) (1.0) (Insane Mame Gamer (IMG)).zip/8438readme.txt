

NOTE: Apply patch over prepatched Super Mario Bros. 4: The Undiscovered Zones V2 ROM.

(Patch to Super Mario Bros. 4: The Undiscovered Zones V2 ROM)
Database match: Super Mario Bros. (World)
Database: No-Intro: Nintendo Entertainment System (v. 20180803-121122)
File SHA-1: EA343F4E445A9050D4B4FBAC2C77D0693B1D0922
File CRC32: 3337EC46
ROM SHA-1: FACEE9C577A5262DBE33AC4930BB0B58C8C037F7
ROM CRC32: D445F698