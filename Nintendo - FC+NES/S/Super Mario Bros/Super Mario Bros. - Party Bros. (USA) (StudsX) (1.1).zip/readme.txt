ver10 -> The version that was released during the jam's period
ver11 -> Version done on 08.23.(easier levels, low epylepsy mode)