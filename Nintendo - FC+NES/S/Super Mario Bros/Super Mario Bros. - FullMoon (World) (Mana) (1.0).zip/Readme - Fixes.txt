Hack: Le Avventure di Mario 3
Created by: Silver/Wakana
Release Date: 2011-2012
Exits: 59
Fixed by: SimFan96

This is the fixed version of Le Avventure di Mario 3 by Wakana. This version fixes the latest released version of the hack including broken music and other issues.

Fixes provided:
* Fixed broken music included in the game originally which would crash on console and accurate emulators.
* Brightness codes have been adjusted to match the brightness to inaccurate emulators.
* The hack uses fastrom, however the majority of long addresses didn't use fastrom addressing. This has been fixed and will further reduce slowdown in the hack.
* L+R scrolling right before an autoscrolling sprite will no longer softlock the game.
* There will no longer be a small flash of color before the Nintendo Presents screen or on level load.
* Fixed a glitch where Layer 2 data in the second room of Dark Mario's Lair would be read by the HDMA patch, which would generate a glitchy HDMA effect that causes the level to darken and the background to glitch. After encountering this effect, it would carry over to other levels and cause other effects such as glitchy overworld transitions and the entire screen to darken upon a save game prompt or when a message box appears. The dark room effect will still be present in this room, while the background and other side effects from this glitch have been fixed.
* Due to the nature of the code that stops the status bar from being generated on the screen, this would also disable the life limit. If the current player's live value eventually becomes a minus value, Mario will immediately game over upon dying. Mario's life counter will now correctly stop at 99 preventing this glitch from occuring.
* Updated the "One File, One Player" patch used in the hack so it now displays the correct amount of exits.
* The coin sprite never utilizes the Sub_Off_Screen routine, meaning if the player encounters many of these sprites, it would fill the sprite table preventing other sprites from spawning unless if these coins were collected. This has been fixed so the sprite now correctly runs the Sub_Off_Screen routine.

Known issues:
* Rare occurances of slowdown occur (mainly in Dark Passage when shooting many projectiles)

Notes:
* Music was reinserted using AddMusicKFF.
* SFX Echo re-added to levels and other fixes implemented using UberASM patch.
* This hack fix was tested with both BSNES+ and Snes9x 1.60.

If you find any other issues with this fixed version of the hack don't hesitate to message me on SMWCentral or Talkhaus. Thanks for reading!

Credits:
---------------------------------------------------
Special Thanks:
* Wakana/Silver for creating the Le Avventure di Mario series!

Patches Used:
* ASAR FastROM patch by Ersanio, adapted for Asar by This Eye O' Mine
* Autoscroll ($1411) + L/R Softlock Fix by Telinc1
* HDMA 3.5 by Ice Man
* Load Flash Fix by ASMagician Maks/Super Maks 64
* One File, One Player by Noobish Noobsicle