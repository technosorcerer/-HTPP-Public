Lauri's Hack
************

Lauri's Hack is my attempt at creating levels that feel similar to original SMB and SMB2j. 
Difficulty wise this hack falls somewhere between those two; this hack shouldn't be as hard as SMB2j is.

Version:    1.0

File SHA1	AC85C68F27C5AE22A51D0142B7A5B3789A423A65
ROM SHA1	EABD41F4B407BC2423B24190B476CBCBE8C6555E
File MD5	F5CEA365CD7AD6EE47C7BE256D7C9427
ROM MD5	    1B2BF107FFDB58176428C69074648A25
File CRC32	B887719B
ROM CRC32	5FF56B45
