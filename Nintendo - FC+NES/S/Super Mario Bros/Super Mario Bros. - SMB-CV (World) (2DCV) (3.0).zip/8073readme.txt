INTRODUCTION
============
Re-experience the mystery of CV1 through the eyes of our favorite plumber, now with updated GFX and more.


STORY
=====
Not too many people know it...

But when Simon made his mythic quest to defeat the count, none other than Mario himself had set out to do just the same (he was just a little late). So it was, that Mario tasked himself with cleaning up Simon's leftovers. No glory necessary; he does it because he likes to!


TIPS & HINTS
============
Count on using save states casually unless you want the full challenge as I was not able to get checkpoints to work correctly. Expect to be back at the start of a level when you die. I think the layout of CV levels is too different from what the SMB engine expects and I just don't know enough to make them work.

Try to rely on your CV memories. I tried to locate power-ups/secrets in the original locations. CV veterans may be rewarded for their intuition but, rest asure, there are even more secrets scattered throughout. Also, there are two warps to be found and a few alternate routes.

For best appearance and overall experience, I highly recommended using FCEUX with the NTSC_2X Filter. And last, I recommend turning down the sound on this and playing some old-school CV tracks!


SPECIAL THANKS/TOOLS USED (Big thanks to the creators of these!)
================================================================
I used these to modify the base ROM.

GreatEd 1.5.2       Makes level creation a snap! I edited the title screen and game text prior due to conversion to MMC3 by the editor.

FCEUX 2.2.3         All testing was done in this.

YY-CHR              Helped immensely with the pixel-work.

SMB Remodeler       Used to change many aspects of the game. An extremely useful hacking tool.

SMBED               Used to change background layouts & block-type properties.

HxD                 Used extensively along with Altap Salamander to import changes from SMBED & SMB Remodeler.

Altap Salamander    Used for it's binary file-compare tool.

Title/Text Editor   Can't remember which ones but they worked.

In addition , thanks to The Spriters Resource & NESMaps.com and, specifically, their users SuperJustinBros, MisterMike & SmithyGCN (TSR) and Rick N. Bruns (NESMaps) for their contributions which I used for reference frequently.


=============
RELEASE NOTES
=============

1.0
===
Hacked Levels, Title Screen, Palettes & Demo Sequence

-GreatEd was most instrumental in the creation of the 1.0 release

2.0
===
Tiles/sprites reworked
Palette grouping bytes reassigned
Various improvements & fixes

-YY-CHR & SMB Remodeler were instrumental in the creation of the 2.0 release

3.0
===
Background graphics changed
Many new alternate secret areas added (usually placed early in levels)
An alternate axe can now be found in level 1
Changed area types to allow for better soundtrack flow
Underwater areas now play the castle/dungeon music
Mario goes up & down pipes a little quicker
? blocks are now usable in underwater areas
Stage-Select is now available at the main menu
New tombstone-backed font
Changed timer to be much closer to "real time" (& CV time)
A more generous amount time is now given
Used the "unused climbable object" as a climbable chain
Piranha plant speed has changed
P. Plants now appear in level 1 (Mario now perishes in the demo)
Hidden 1ups always appear (sadly, in overworld-type areas only)
Mario death sprite changed to SML death sprite (because it's cute)
Bowser fireball endurance changed to 13
Bowser is now the "real" bowser when killed with fireballs
Changed enemy stomped time (Goomba tombstomes stick around longer)
Changed castle area blocks to purple CV-style blocks
	
-SMBED & SMB Remodeler were instrumental in the creation of the 3.0 release
