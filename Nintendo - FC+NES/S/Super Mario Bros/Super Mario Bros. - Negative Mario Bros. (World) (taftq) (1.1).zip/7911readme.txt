Negative Mario Bros. information guide

This is a ROM hack of the original Super Mario Bros. that inverts the colors and... that's about it, actually.
More information below, as well as a guide on how to play it.

How to Play:
To play this hack, you'll need an NES emulator, such as FCEUX or Mesen, as well as a ROM patcher, such as Flips.
If you have both of those (and know how to use them),  you're good to go!

Changelog:
Version 1.1
Fixed the coin on the HUD having normal colors during screen transitions
Various color corrections

Version 1.0
Inital release

Note:
Colors were tested using the Mesen palette. Results may vary depending on what emulator you use.

Development time: About two hours

Super Mario Bros. is a property of Nintendo. This hack and its creator are not affiliated with them in any way. 
Please don't steal this hack and claim it to be your own.