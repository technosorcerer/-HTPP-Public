SUPER MARO INVALIDO COLD (FRIO)
FUN OR FLEE
Hacked by RetroRuco
2019

--------------
Date Released:
--------------
March 2019
changes
v1.0 Graphics, levels edition and enemies hablities.
v1.1 Lakitu movement patch
v1.2 create patch for weird mario and bowsette
v1.3 fix level 5-1
v1.4 fix level 6-2
v1.5 fix level 1-1
v1.6 change spiny for crabs sidesteppers
v1.7 create patch for more 128 lifes and score counter double digit
V1.8 patch power ups and damage over Mario, minors fixes
v2.0 change levels 1-2, 2-1, 2-2, 2-3, 3-4, 4-2, 4-4, 5-2, 7-1, 7-4 ;) 8-3, 8-4 XD
v2.1 fix levels 4-2, 6-2, 8-3 and hard mode speed

------------
Description:
------------
The game was modified in the stages for make it more fun like the original spirit of SMB, no stupidity hard, you can try out the fun challenge or only flee to finish every stage.
The physical of movements are a little diferent and graphics are actualized to a wheelchair and crutches, the enemies too.

The goombas are now "tecolotes" a terrible enemies
The koopas are "tortuguitas", funnier.
The bloopers are "squidward".
The cheep-cheep try to be "Nemo and Dory".
Spiny are sidestepper.
The lakitu movement is patched and is la "nubecita".
The lifes score 99, and support more 128.
The hammer bros are a "caveman" with axes.
Bowser is now "Bowsette", but you can choose, if don't like it, you can change Mario Weird Invalido to Mario "weird" only, and from Bowsette return to the bowser, with a pair of patch's.
Only repatch the patched version Suppa Maro Invalido Cold with one or both aditional patches and will be change the characteres.
And surprises. 

---------
ZIP file:
---------
* Super_Maro_Invalido_Frio Folder
  * Super_Maro_Invalido_Frio.ips
* Patches_for_Invalido Folder
  * Bowsette_to_Bowser.ips
  * To_Maro_Weird.ips
* This Readme file

----------------
ROM Information:
----------------
File Name: Super Mario Bros. (JU) (PRG0) [!].nes
No-Intro Name: Super Mario Bros. (World)
(No-Intro version  20130731-235630)
File MD5:      811B027EAF99C2DEF7B933C5208636DE
File SHA-1:    EA343F4E445A9050D4B4FBAC2C77D0693B1D0922
File CRC32:    3337EC46
ROM MD5:       8E3630186E35D477231BF8FD50E54CDD
ROM SHA-1:     FACEE9C577A5262DBE33AC4930BB0B58C8C037F7
ROM CRC32:     D445F698

--------
Credits:
--------
RetroRuco - Hacking
Mario Weird - Idea Base
Mario Cold - Idea Base

---------------
Special Thanks:
---------------
Romhacking.net - for hosting the patch

--------
Contact:
--------
https://www.youtube.com/channel/UCYitwl04DhcqTkq3uyEMEaw
https://www.youtube.com/channel/RetroRuco

----------------------------
Disclaimer and Terms of Use:
----------------------------
* RetroRuco is not related or affiliated with Nintendo and the publisher of the original game.
* Do not sell this patch and the contents with it.
* Do not sell the pre-patched ROM into reproduction cartridges.
* You may distribute or host this patch provided that all files that come with it are intact.