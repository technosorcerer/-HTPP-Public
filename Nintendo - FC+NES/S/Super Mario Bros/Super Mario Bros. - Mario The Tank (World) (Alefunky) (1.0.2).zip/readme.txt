Mario is now a tank. You will get the flash boots from question blocks when big.

Changelog:
1.0.2:
- Reduced bricks particles from 8 * 4 to 4 * 4
- Converted game from MMC5 to MMC3, hopefully removing all compatibility issues.
- Laggggg fixes.
1.0.1b:
- Fix a bowser crash
1.0.1a:
- Fix a collision bug
1.0.1:
- Add more bricks chunks on screen
1.0
- Initial release