this is a hack that gives luigi his palettes from mario maker 2.
credits to 4matsy and Szemigi for making the coding for separated palettes.