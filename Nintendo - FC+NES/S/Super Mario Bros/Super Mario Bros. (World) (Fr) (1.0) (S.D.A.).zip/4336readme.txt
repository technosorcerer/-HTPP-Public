SUPER MARIO BROS. (FR)

Ce patch est pour le v�rsion europ�enne de "Super Mario Bros." pour la NES.
100% traduit en fran�ais, avec quelques modifications dans la palette et les graphiques pour rendre le jeu encore meilleur.
Un grand NES classique, maintenant en langue fran�aise!
J'esp�re que vous appr�cierez le jeu.

-S.D.A.

UPDATE: J'ai ajout� un patch aussi pour la version am�ricaine. Il sera principalement distribu� au Canada (Qu�bec) et aux �tats-Unis. Il a un patch qui fait que Lakitu jette les �ufs �pineux correctement.