Changes made for patch version 1.0a:

♣ Removed my name from title screen and changed with dates and "Nintendo", so at least it is more pleasing for the eye
♣ Added shadows to the letters, so the look nicer

_____________________

Original readme from patch version 1.0:


Ola,

my name is André Mena Calavia, known in Romhacking.net as RetGal, acronym of "Retro Galicia".

This is a fully functional Galician translation patch for Super Mario Bros for the original Super Nintendo NES.

It has been only a few days since my last translation (SMW for the SNES) but I still had the "Mario-translation itch", so I checked if thre was any SMB Galician translation of the game and try it.

This has been quite easy, as other translators say this game is quite sort (40KB) and has almost no text so is really fast to complete, as fast as a whole playthrough.

Indeed, it has so little text that I did not know where to put my "credentials"; at the very end of the game was quite cheap for my taste (it is the Princess kind-of-dialogue) and at the very begining thre was almost no "pretty" place, so in the end I sacrificed the "1985 Nintendo" and placed it there; still quite cheap but not very intrusive.

Feel free to let me know if there is any glitch during your playthrough; Galician may not be the most popular language, but is my mother language and any product related with it may have the best quality.


-- Tools used --

Usual:

♦ Tiny Hexer, as usual for reading hex and apply tables.
♦ CrystalTile2, easy enough tool to see and insert modified graphic tiles.
♦ Paint.net, my esential to modify graphics.
♦ Paper and pens.

Specific for this project:

♦ No need (as stated, quite short and easy to find text)


-- What does this patch change --

• Title screen
• Time and World
• Game over screen
• Time up screen
• Toad text
• Princess text and ending
• Everything translatable in the game, to um up (I have only left the "UP" of the 1UP untranslated).

• Add special some Galician words (Á, É, Ó)


-- Contact --

If you find any glich or want to mail me for reasons, you can do it through my Romhacking.net profile --> https://www.romhacking.net/forum/index.php?action=profile;u=91332

Have a nice day