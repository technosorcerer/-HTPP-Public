**Hack by CakeWarden**

Installation
------------
Patch to ROM with CRC:3337EC46

My Neighbour Totoro: Mei is Missing
-----------------------------------
Mei has gone missing again and Totoro has to go on an journey to find her. Totoro will encounter spirits and creatures
during his journey to find Mei.

Features
--------
14 new levels
4 hidden levels
4 new songs
Originally drawn graphics.
Auto scrolling levels
New platform movement

Notes
-----
This has been sat on my hard drive for a couple of years. I set out to do a sprite swap of Mario to Totoro but took it
a bit further. At this point, I'm not going to do any more significant work on this and release it 'as is' as some folks 
might get a kick out of it. If you want to use/alter/update this, then please feel free.

Thanks
------
Eden GT - Thanks for providing guidance and resources.
FCandChill - Thanks for providing music convertion software.

All the tools like SMB Utility and resources like w7n's music guide.

Other IPS Patches used
----------------------
Can step enemy - Masa&Yuu
FireM becomes SuperM when injured - w7n
Hammer Mario - βetaworld
Lift - ATA
No Bubble - Masa&Yuu
Reviving Goomba - Eden GT
Scroll - ATA
Star~Paul - Tanaka
UpBlock_NoDemo - masa&yuu