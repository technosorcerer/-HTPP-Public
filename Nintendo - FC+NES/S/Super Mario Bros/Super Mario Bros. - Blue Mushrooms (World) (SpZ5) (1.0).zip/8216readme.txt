

Super Mario Bros. is an original game by Nintendo and Mario Bros. is its property.




--- Blue Mushrooms 1.0 --- Rom Hack by SpZ5

hi, ty for downloading and playing! (sorry if my english is not that good :c)

here I'll write the Rom Hack info and what I've changed of the original game. :p

-- Features --

- New 32 levels
- Some sprites and color palette have been modified
- Mario, Goombas, Koopas... Almost everyone are a bit faster!
- Red mushroom it's a bit more powerful; you can throw (slow) fireballs!
- Goombas now can revive if you crush them
- Coins value are now 2 instead of 1

-- Plot --

Now that Bowser was defeated, there's one more thing Mario (and Luigi maybe) must do... Save the last Toad... So our heroes will need to explore the new areas beyond the unknown, where the Sun's illumination doesn't show. :o

-- Difficulty --

I think this Rom Hack has a intermediate difficulty thanks to the new red mushroom, or the modified speed, but maybe some areas could be hard due to the enemies or the timing of the jumps, and maybe the Mario's speed could be a trouble sometimes... so, be careful!