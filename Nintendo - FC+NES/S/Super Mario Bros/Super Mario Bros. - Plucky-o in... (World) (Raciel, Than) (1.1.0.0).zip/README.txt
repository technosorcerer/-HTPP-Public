Plucky-o In Super Mario Bros. by THAN & Raciel _V.1.1.0.0
Based on the classic Super Mario Bros. 1 (SBM1) and animated by fan gamers, our character Plucky, or Plucky-o, based on the fan game "Super Pluckyo Bros." (https://gamejolt.com/games/pluckyo/95430), embarks on a new adventure in the Champignon world -of Don Perignon-, this time in Max Montana's Inferno, to rescue Princess Shirley (the loon). It's a graphic allegory that gives the player a fresh experience, allowing them to revisit one of their favorite games.

The game features our character Plucky-o and slight graphical changes, including:

- A modified title screen.
- Completely redesigned sprites.
- Changed colors -intro- (see: https://alberto-luviano.itch.io/nes-color-switching-demo)
- Other graphical elements.
Enjoy the ROM!

(NOTE: If you have any suggestions, please feel free to write to us: https://formsubmit.co/el/zahoza)

Gamers Unidos
