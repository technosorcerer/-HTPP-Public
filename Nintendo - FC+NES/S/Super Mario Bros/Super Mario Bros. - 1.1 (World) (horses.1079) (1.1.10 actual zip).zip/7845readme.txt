Super Mario Bros. 1.1 is a romhack of the origional Super Mario Bros.

It features:
- Updated Mario and Luigi Graphics -
- New Dark Background -
- New Text -

Changelog:
V 1.1.8 - Brand New Autumn Theme
V 1.1.9 - Time Up Message Updated
V 1.1.10 - Make Player Get Small Fire/Double Death After Beating Any Normal Castle Level

Current Version: 1.1.10

SMB1.1 is made by Horses.1079 in 2023.