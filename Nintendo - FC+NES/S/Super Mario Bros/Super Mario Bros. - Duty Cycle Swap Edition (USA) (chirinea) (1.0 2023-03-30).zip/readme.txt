Super Mario Bros. Duty Cycle Swap Edition

v.1.0 (30/03/2023)

WHY THIS HACK WAS MADE?

Famiclones usually have CPU chips designed with the 25% and 50% duty cycles of their pulse wave channels swapped. This leads to music and sound effects being played differently from how the original NES or Famicom play them. In Super Mario Bros., composer Koji Kondo used the 50% duty cycle to play all the music, which has a darker, hollower sound. On clone consoles, the music is played using the 25% duty cycle, which has a brighter sound.

WHAT DOES THIS HACK DO?

It replaces the 50% duty cycle instructions in all Super Mario Bros. music with 25% duty cycle instructions. If the hacked ROM is played on original NES or Famicom consoles, the game will sound as if it was being played on a clone console. Conversely, if it is played on a Famiclone, it will sound as it would if played on an original Famicom or NES.

WHAT DOES THIS HACK DOESN'T DO?

At this time it doesn't change the sound effects (which are also affected by the Famiclones' CPU bug). If I ever learn how to swap the cycles for the sound effects, this hack will be updated (if you know how to do it, please, let me know!).

ACKNOWLEDGEMENTS

This hack was only possible because of w7n's "Super Mario Bros. Music Hacking Guide (New Version)".

2023 chirinea