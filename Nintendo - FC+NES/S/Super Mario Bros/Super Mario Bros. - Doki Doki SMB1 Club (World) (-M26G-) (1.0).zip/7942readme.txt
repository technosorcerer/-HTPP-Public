Doki Doki SMB1 Club
------------------------------------------------------------------------------------------------------
Table of contents

I.  Presentation
II. Character Abilities (Compared to Mario)
	a. Monika
	b. Yuri
	c. Sayori
	d. Natsuki

------------------------------------------------------------------------------------------------------
I.  Presentation

Doki Doki SMB1 Club is a pack of four mods created by M26G featuring the four girls of
Doki Doki Literature Club, with their own abilities.

Feel free to use these mods for yours as long as you give credit.

The sprite sets of the four characters were made by Valis Emma, ​​then ported (redrawn with YY-CHR)
into the original SMB1 by M26G.

------------------------------------------------------------------------------------------------------
II. Character Abilities (Compared to Mario)

	a. Monika

Monika is faster and jumps higher. She can also throw balls of fire, even while crouching. However,
be careful. Monika can effortlessly jump over a flagpole.

	b. Yuri

Yuri's fireballs are faster, but she can only throw one at a time. She also runs slower but jumps
higher.

	c. Sayori

Sayori's fall is slower. The same goes for the fireballs she throws. If an enemy is too close to
Sayori, she cannot eliminate it with a fireball.

	d. Natsuki

Natsuki, known for her bad temper, runs all the time. Her fireballs are faster and bounce higher
and fall faster. Also, Natsuki slides like Luigi.

