Hi! 

Thank you very much for downloading
SUPER TERRIBLE PROJECT
version 4!

The original hack came out in 2021.
This is just the 'definitive' edition.

For more information, you can visit my website:

https://coffeebug.neocities.org/stuff.html#stp

Anyways, thank you for playing my game!
I hope you enjoy it :)




















Check the first pipe in 1-1 for an easy skip.