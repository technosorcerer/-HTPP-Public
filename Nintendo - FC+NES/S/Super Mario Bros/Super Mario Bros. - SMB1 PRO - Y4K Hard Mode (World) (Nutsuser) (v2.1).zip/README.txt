* Title: SMB1 PRO - Y4K # Hard Mode
* Version: 2.1
* Author: extr1m (registered on romhacking.net as Nutsuser)
* Game: Super Mario Bros. (NES)
* Release date: 02.06.2025

* Description:

* Super Mario Bros. Pro � Y4K # Hard Mode is a fast-paced and brutally difficult ROM hack of the original Super Mario Bros. (NES).
* Designed for maximum speed, precision, and focus � this is a truly insane hardcore experience.
* Every jump is calculated down to the smallest detail.
* There�s no room for mistakes � only pure momentum and forward drive.
* This new version expands the game from 6 worlds to a full 8 worlds, bringing the original concept to absolute perfection.

* Features:

* Increased the game from 6 worlds to 8 worlds for a longer and more complete experience.
* Adjusted and polished level layouts to perfectly match the intended �ultra speed� gameplay style.
* Improved difficulty balance while keeping the original brutal challenge intact.
* Enhanced level flow for better momentum and precision-based jumps.
* Minor visual and structural tweaks to ensure consistent performance on emulators and real hardware.
* Brutal, unforgiving difficulty
* Optimized for ultra-fast, high-pressure gameplay
* Dense and relentless level design
* Now with 8 complete worlds for the ultimate challenge

* Update Report:
* ~ SMB1 PRO - Y4K Hard Mode v2.1 (SMB1 Hack.nes)
* Version: v2.1
* Type: ROM Hack of Super Mario Bros. (NES)

* Short description: 

* Complete rework and extension of all levels; new routes added through pipes and flags, increasing both variability and difficulty.

* Key Changes:

* All levels � revised and extended: expanded sections, added new platforms and timings, increased obstacle density for higher difficulty.
* Partial level redesigns � certain levels received geometry changes (block rearrangements, added/removed enemies, hidden passages).
* Pipes � many new pipe connections added, leading to various areas:
* Some pipes shorten the path (quick access to bosses/secrets).
* Some pipes lengthen the path (extra branches with obstacles and rewards).
* Flags and exit points � flags and triggers added/modified to sometimes extend the route (intentional difficulty increase), sometimes in contrast to the pipes.
* Route variety � with the combination of pipes and flags, players can now experience both shorter and longer/harder paths, making route choice a part of the challenge.

* Gameplay Balance and Difficulty:

* The hack is designed as Hard Mode � more difficult than the original.
* Balancing: increased number of enemies in key zones; adjusted jump timings and platform distances for greater precision.
* Certain areas now require advanced mechanics (precise jumps, multi-level jump usage), staying true to the �Y4K Hard Mode� concept.

* Testing

* Playthroughs of main worlds (1�8) were conducted to verify new routes.

* Verified:

* Correct pipe teleportation (no soft-locks/freezes).
* Proper flag/exit trigger activation.
* Correct enemy and item spawning in modified zones.
* Results confirmed baseline playability; further testing with limited-life modes is recommended to catch �edge case� situations.
* Compatibility and Requirements

* Format: standard NES ROM (.nes).

* Compatibility: tested on popular NES emulators.

* Note: behavior may vary depending on emulator (sprite priority, speed, PPU quirks).
* Known Issues / Limitations
* Rarely, quick switching between pipes/flags may cause minor visual artifacts in some emulators � further testing on real hardware is required to eliminate this fully.
* Potential unintended �shortcuts� via glitches � not yet confirmed, but possible.
* Enemy density in narrow areas may require fine-tuning after tester feedback.
* Recommendations for Moderator
* Accept the update into test branch/pull request with the tag Hard Mode � playtest required.
* Request several independent testers (different skill levels) to play through and report:
* blocking/soft-lock areas,
* overly hard/easy sections,
* emulator compatibility issues.
* If stability is confirmed � promote to public release with a note about increased difficulty and altered routing.
* Additional Information (if available)
* List of specific levels with major redesigns (e.g., 1-1, 3-2, etc.).
* Tools/editors used (FCEUX, Lunar Magic, etc. if applicable) and NES ROM base version (original PRG/CHR).
* Detailed changelog with patch files/instructions (IPS/BPS)
* Final Description (English)

* Title: SMB1 PRO � Y4K Hard Mode
* Version: 2.1
* Author: extr1m (registered on romhacking.net as Nutsuser)
* Game: Super Mario Bros. (NES)
* Release date: 14.09.2025

* Description:

* Super Mario Bros. PRO � Y4K Hard Mode is a fast-paced and brutally difficult ROM hack of the original Super Mario Bros. (NES).
* Designed for maximum speed, precision, and focus � this is a truly insane hardcore experience where every jump is calculated down to the smallest detail.
* There�s no room for mistakes � only pure momentum and forward drive.
* Version 2.0 originally expanded the hack from 6 to 8 complete worlds, refining layouts to match the intended �ultra-speed� gameplay while keeping the original brutal challenge intact.
* The new v2.1 update takes this concept even further:
* All levels have been fully reworked and lengthened, with denser enemy placement and extended platforming sections.
* Partial redesigns introduce new geometry, obstacles, and enemy configurations for greater variety.
* Pipes (warp routes) are now widely connected to alternate areas � some shorten the path, while others extend it, forcing players to adapt and choose their routes wisely.
* Flags and checkpoints can sometimes extend the journey rather than end it, creating surprising twists and a layered progression system.
* The result is a hack with multiple paths, where routes may be shorter or much longer depending on the choices you make.

* Features:

* Extended from 6 worlds to 8 worlds for a full, complete challenge.
* Lengthened and polished levels with new alternate routes.
* Pipe network redesign: some pipes cut down time, others prolong it.
* Flag mechanics reworked to sometimes extend paths instead of finishing them.
* Ultra-fast, high-pressure gameplay preserved from v2.0.
* Brutal, unforgiving difficulty with tighter platforming demands.
* Consistent performance on both emulators and hardware.

* Notes:

* Tested on several popular NES emulators for stability and playability.
* This is SMB1 PRO � Y4K Hard Mode v2.1: a merciless, extended, and deeply reimagined version of the hack � now with branching paths, surprises, and more ways than ever to suffer.
* Patch is intended for Super Mario Bros. (W) [!]. 