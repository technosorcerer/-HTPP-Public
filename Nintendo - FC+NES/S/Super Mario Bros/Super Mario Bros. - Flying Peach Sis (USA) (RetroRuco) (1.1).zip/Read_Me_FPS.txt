Flying_Peach_Sis
Hacked by RetroRuco
2022

--------------
Date Released:
--------------
March 2022
changes
v1.0 Change Graphics
v1.1 Change levels edition and skills.

------------
Description:
------------
It's a new adventure where Princess Peach and Daisy literally fly to the castle where they must save... erhh, a princess who has been kidnapped by the classic Bowser.

A mini-adventure where the difficulty level quickly escalates from beginner to hell. Peach and Daisy are the only ones with the ability to fly, which is necessary to overcome these levels.
And surprises.

I made this mod in 2022 and now I want to share it. Please note that as long as you own the original game, you cannot use the original game title or the company name to impersonate them. Modifying a game you own is completely legal, as long as it's free and you only share the .ips file.

---------
ZIP file:
---------
* Flying_Peach_Sis
  * Flying_Peach_Sis_Maria.ips
* This Readme file

----------
Other ROMS
----------
SUPER MARO INVALIDO FRIO (COLD)
https://www.romhacking.net/hacks/4387/

----------------
ROM Information:
----------------
File Name: Super Mario Bros. (JU) (PRG0) [!].nes
No-Intro Name: Super Mario Bros. (World)
(No-Intro version  20130731-235630)
File MD5:      811B027EAF99C2DEF7B933C5208636DE
File SHA-1:    EA343F4E445A9050D4B4FBAC2C77D0693B1D0922
File CRC32:    3337EC46
ROM MD5:       8E3630186E35D477231BF8FD50E54CDD
ROM SHA-1:     FACEE9C577A5262DBE33AC4930BB0B58C8C037F7
ROM CRC32:     D445F698

--------
Credits:
--------
RetroRuco - Hacking
Power_Peach_Sis Hack by SiWu - Rom Base

---------------
Special Thanks:
---------------
Romhacking.net - for hosting the patch

--------
Contact:
--------
https://www.youtube.com/channel/UCHWPnHR_yKmom4D_OH9Urpg
https://www.youtube.com/@YoSoyRetroClassicGames

----------------------------
Disclaimer and Terms of Use:
----------------------------
* RetroRuco is not related or affiliated with Nintendo and the publisher of the original game.
* Do not sell this patch and the contents with it.
* Do not sell the pre-patched ROM into reproduction cartridges.
* You may distribute or host this patch provided that all files that come with it are intact.