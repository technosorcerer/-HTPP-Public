Yo!

This hack is a sequel to an upcoming hack called Mario, A plumber in time.

Esentualy, this is Luigis side of the story, and he even gets his own jump, slide, and fireball physics.

And in Luigi Fasion, this hack is somewhat difficult, not insanely difficult, I mean, I beat it and I suck as games so you should be fine.
But it definetly isn't a walk in the park let me tell ya.

To play it, you'll need to apply the IPS patch to Super Mario Bros. (JU) (PRG0) [!]

And if you don't know what that means, I suggest a quick internet search on what lunar.ips is.

Bye~

GlitchyTSP