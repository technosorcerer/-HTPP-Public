Super Mario Bros. 1.1 is a romhack of the origional Super Mario Bros.

It features:
- Updated Mario and Luigi Graphics -
- New Dark Background -
- New Text -

Changelog:
V 1.1.8 - Brand New Autumn Theme
V 1.1.9 - Time Up Message Updated
V 1.1.10 - Make Player Get Small Fire/Double Death After Beating Any Normal Castle Level
W 1.1.11 - Secret World 9 Warp Zone + 1-2 Easier Minus World Clip

Note: In 9-3 after seeing the hammer bro, press B to go to the title screen and unlock 2nd quest + world select.

Current Version: 1.1.11

SMB1.1 is made by Horses.1079 in 2023.