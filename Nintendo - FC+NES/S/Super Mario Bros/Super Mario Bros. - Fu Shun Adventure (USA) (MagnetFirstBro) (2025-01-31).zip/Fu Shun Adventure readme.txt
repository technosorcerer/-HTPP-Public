This is a hack for FC/NES Super Mario Bros. You need to apply the IPS patch to the original ROM.

The changes in this hack are as follows:
· Deleted "2 Player Game"
· Eight levels, each with about 16 screens
· The protagonist is Fushun from the mobile game "Azur Lane"
· Some improvements to the map graphics
· You can complete the game without TAS

That's all, have fun!