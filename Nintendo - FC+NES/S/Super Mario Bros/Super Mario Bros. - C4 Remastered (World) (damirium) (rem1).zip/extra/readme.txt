Readme file for C4 Remastered
-----------------------------
NOTICE

This is a kaizo hack that requires not only great skill but great knowledge of SMB1 mechanics. 
Play at your own risk. Player discretion is advised.
-----------------------------
CONTENTS OF .ZIP

In the .zip file, you will find:
 - "c4_remastered1.ips" - the new, remastered version of C4
 - "extra\c4_OLD_2.ips" - the original C4 ver.2 as released in 2004
 - "extra\readme.txt" - this file

-----------------------------
STORY OF C4 REMASTERED

C4 is a kaizo hack released in 2004 by a Japanese ROMhacker who went by Himajin. Not much is known about this hack nor this hacker. There is another SMB hack which is easier to find known as "Minigame" which is also signed by a Himajin, but it is unknown whether it is the same Himajin. Himajin in Japanese means "slob", and is also used by a Mega Man hacker, so is by no means an unique name. A Japanese site that originally hosted "Minigame", smbarchives, also refered to its author as Kanjin-san.

But, unlike Minigame, C4 is (as I'm writing this) or was (as you're reading this) incredibly hard to obtain. I have no idea where I got it from. I have hundreds of hacks on my PC. According to the "date modified" of my file, I got it in 2022. But I did get it. Recently I have been playing these hacks. Scrolling through my folder, I come across a file named "c4.nes". "What's this?", I wonder. I open it. Plain title screen, not much info except the author, year and version. Even whether C4 was its original name remains a mystery, as the title screen just had the classic SMB logo. 

I play it. It's a kaizo hack. And I usually don't enjoy kaizo hacks. But this one was different. I loved it. Unlike most kaizo hacks, it wasn't stingy with powerups, nor obsessed with controlling your powerup state. There often was more than one way to solve a specific puzzle. There was no kaizo blocks, absolutely none. Unlike most kaizo hacks, this is a kaizo hack that you play by your own rules. 

Now is the hack difficult? Oh boy, yes. Keeping your speed after changing direction, obscure clips using coins... It's hard. But it isn't obnoxious. It doesn't spam you with hammer bros and enemies, and its puzzles come as separate elements, one by one. 

So, in short, I loved it, so I researched it. What I found is what I detailed in the first paragraph of this chapter. Basically, it was impossible to find online. While we do have a good candidate for the mysterious Himajin (the author of Minigame), I couldn't find any other hacks of the same author. 

So I decided I wanted to share it with the world. But tough! RHDN doesn't allow submissions without contact info for the author. And Himajin wasn't in the authors database. Ofcourse I don't know this guy's contact info, the only lead I had was smbarchives, and that site is half dead anyways, and doesn't contain any contact info in the first place. 

I was faced with a dilemma. I could leave the hack to sit and remain unobtainable (or at least not easily obtainable). But I didn't want to do that because it was too good to face that destiny. Another option was, I could've released it under my name. But I didn't want to do that either, because that would be scummy and disrespectful to the author of this masterpiece. But then it dawned on me. I could improve it, make it better, to justify the fact I'd be releasing it with my name on it. It was good in the first place, but I could polish it, give it a nice title screen, do some ASM mods, do some graphics work etc. Appropriately, it's the hack's 20th anniversaty, anyways!

And that's how C4 Remastered was born.

-----------------------------

HACK INFO

Original features of C4 (2004):
 - 6 new kaizo levels
 - SMB2J style graphics
 - Two endings

New features in C4 Remastered (2024):
 - New original title screen
 - Starting number of lives increased to 20
 - Implemented cheat code: A + START to start with infinite lives
 - Redundant world display replaced with a simpler level display
 - Graphics work