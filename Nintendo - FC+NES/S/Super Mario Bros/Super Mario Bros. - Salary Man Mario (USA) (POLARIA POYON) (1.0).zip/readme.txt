SALARY MAN MARIO

Developed by POLARIA POYON 2023

Story:

Mario's just an everyday salary man, and now's the time to prove yourself! Bowser has kidnapped
your boss, and it's up to you to rescue him! Do a good enough job, and you might just get a
bonus for your trouble!

Gameplay:

There are 4 worlds that are immediately selectable from the title screen. There are coins
scattered throughout the stages, and when you collect 20 you gain brief invincibility. A new
powerup has been added, as well as custom music and enemies/hazards. You don't immediately go
to Small Mario upon getting hit as Fire Mario, and there's auto scrolling stages as well.

Playtesters:
Yoshi Milkman
Nanodrive
Nikki+
Forple
Netyasha Roozi