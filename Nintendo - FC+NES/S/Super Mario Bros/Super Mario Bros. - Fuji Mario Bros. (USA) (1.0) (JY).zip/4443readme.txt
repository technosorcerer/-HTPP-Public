  ___ _ _   _ _
 /  _| | |_| | |
 |  _| | | | | |
 |_| \__/'\__/_|
  __ __ ___ ___ _ ___   ___ ___ ___  ___
 |  V  |   |   | |   | |   \   |   ||   |
 | | | | | | | | | | | | | / | | | ||_\_|
 | | | |   |   < | | | | | \   < | || \ |_
 |_|_|_|_|_|_|_|_|___| |___/_|_|___||___|_|
                                  2019 JY
============================================
[ORIGINAL GAME BY]	       [RELEASED]
Nintendo		    April 5, 2019
============================================
[DESCRIPTION]
“Fuji Mario Bros.” is a complete facelift
for the first Super Mario Bros., in which
everything is redrawn to match the art
style of its sequel.
============================================
[CREDITS]
JY
-hacking
-graphics
   *worked on custom tiles, edits of
    original SMB2 ripped tiles and sprites

Cruise Elroy (of MFGG)
-graphics 
   *their sprites for Mario and most
    enemies were used in this hack
   *shout-outs to Cruise Elroy
===========================================
[UTILITIES USED]
-YY-CHR			  -SMB Remodeler
-SMB Graphics Workshop v0.1.1
-SMBED		-SMB Title Screen Editor
===========================================
[CHANGES IN THIS VERSION]
-Fixed an oversight that made the game's
 logo read "SUPER MARIO RROS. on the title
 screen. How embarrassing!
===========================================