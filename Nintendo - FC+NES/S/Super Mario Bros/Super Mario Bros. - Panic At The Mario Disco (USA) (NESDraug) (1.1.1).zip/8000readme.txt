
Panic At The Mario Disco

----

Travel through 5 groovy levels as both Peach and Mario in the search for the ultimate Discothèque!

Experience a brand new enemy, the disco Lakitu, a hip cat who can either drop helpful power ups or dangerous foes. 

A new P-Wing power up will let Mario and Peach swim through the skies!

----

This hack was made in 10 days during the SMB Jam 2023.

----

Version 1.1.1 - Add text to the error screen to let users know that they need to use a modern emulator to play this hack.

Version 1.1 is now live! Keeping with the spirit of a hack made in a game jam, the new update was coded in a single day of crunch plus a second day of overtime ;)

*NEW* 

- Mario and Peach now have unique abilities.
  - Mario is invincible while rising in his jump and Peach has her traditional float abillity.
  - Press select at any time to switch between Mario and Peach
- Fire Power is not lost on damage, only on death.
- Level 5 is slightly reworked to accommodate their individual abilities better

*Bug Fixes*

- Floatey text for 1 ups properly working again
- Add missing halfway points for levels
- Fix fast death sometimes happening for regular levels

