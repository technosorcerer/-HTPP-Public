Thanks for downloading!
DELUXE EDITION (v2.00) Release:
As much positive feedback the game has got, I feel like there are still several issues that gained the game some unvocal detractors:
>The game doesn't play like Mario
>The game is hard for those who can't overcome the learning curve
>MORE CONTENT!!
For issue 1, well, it's a Celeste mimic anyway. If you want a traditional Mario game, buy Mario Maker. This game aims to be different.
The other 2 issues, though, are legitimate beefs. Hence the 2 major additions:
- ASSIST MODE (in the original course), where you can breeze through stages you find too hard, and
- A collection of courses with unique gimmicks, known as CELESTE ARCHIVE!
The course additions:
- Duality Mario
- Spelunker Mario
- Celeste Mario's Splat and Splash!
- Mario Is You
- A-Button Challenge
- Final Destination
- Rainbow Dash Stage
- Celeste Maker, but everything has a price tag
- Romance of the Mushroom Kingdom
- Worst Minichallenges for Masochists
- FAREWELL (unlockable with a total rank of 80 in the previous minigames)
- Driller Mario (Standalone game with Roguelike elements)
- [Ideas to come in future versions]
So anyway, enjoy this version! If you're writing a review, feel free to write which ideas work best and which ideas don't.
NOTE:
>To activate assist mode in the original course, either enter the Konami Code on the main title, or hit the first hint block you encounter in the game.
>If you're gonna stream this game, consider using versions post-v2.01 for best experience - which will most likely come within this month. For updates, visit https://smbarena.com/public/hack?id=3742 (Also updated on rhpz.org, romhacking.net, romhack.ing etc.)

2025 w7n et al.


CREDITS (DLC additions only, see the v1.00 release for the original game's credits):
Programmer: w7n

New graphics: Morshu, w7n, Eden GT, Ficus et al.

Main music (cover artist): w7n
CELESTE MAKER track transcription: studsX

Level design: w7n

References & Inspirations for Game/Level Design:
SMB1 HACKS:
Hard Relay Mario by Mana et al.
Kamikaze Mario series by 79
OTHER GAMES:
Spelunker (C) Ilem
Splatoon series (C) Nintendo
Mr. Driller (C) Namco
Baba Is You (C) Hempuli Oy
Tower of the Sorcerer (C) N.W.
(New) Magic Tower 1 by cos105hk

Special Thanks:
TitanOfPlasma, iProgramInCpp, kandowontu, crm0622,
Polari, AuburnRDM, and all other playtesters

All rights belong to the respective owners / authors. If you like 2D Mario games or any games referenced by this ROM hack, support the original creators!



CHANGELOG:

v2.00b: Bug hotfixes.

v2.00: First release (2025)

v1.00: Original release (2023)



--v1.00 Release readme--
This is a hastily done minihack of SMB1 (with levels designed within 2 months) that features Celeste-styled gameplay.

Please apply .bps patch with beat.

Emulator compatibility: Compatible with newer emulators like FCEUX, BizHawk and Mesen. Not compatible with VirtuaNES due to that emulator defaulting undocumented MMC5 ROMs to use only 8KiB of extra RAM.

Controls: (You can just read the in-game tutorials!)
A: Jump
B: Dash (B is not used for running.)
A while on wall: Wall kick
UP+A while on wall: Wall jump (consumes stamina)

2023 w7n et al.



--FOOTNOTES--
Q: What are those weird blocks in the room at the end of World 1 in the vanilla game?
A: The room is meant to celebrate over 20 years of SMB Hacking history. To break down each of the special blocks in sequential order:
-Kamikaze Mario series, by 79 (1999~2003)
-Falling Mario axe, by Wa (2001)
-Hidden block, present since Hard Relay Mario and many other glitchfest hacks of the early to mid-2000s
-Full Moon, by Mana (2003)
-Bumper, by ATA (2005)
-Extra Mario Bros, by ATA (2005)
-Fake ground block, present in Sakura and Nullpo, by Faisoft (2005)
-(α-2 block) Rohrleitung Gate, by w7n (2013)
-Super Mario Unlimited, by frantik & Dr. Floppy (2012)


Q: What happened to your ys168 drive?
A: That site will be indefinitely closed.
Why?
Real-info authentication.
Basically, if you think multibillion-dollar companies (e.g. that company that starts with a G) stealing your info is already bad enough, imagine if such info stealing is near MANDATED.
Roughly mid-2024, ys168.com, which had been easily accessible, started requesting admins to bind their account with phones. One of the last sanctuaries of Chinese online sharing services fell.
Now, people would claim I'm exaggerating this "small" problem while nonetheless registering with real info on other mainstream sites.
Yes, I did. Doesn't mean I'm content.
And it's exactly because even this "small" problem has to be "fixed", did I feel the need to make this just one chance to give out my word:
"I will never be content with my info being exposed, sold and sorted into databases, no matter what 'greater good' those collectivists would boast of."
To those who sneer "privacy is dead anyway", PROVE IT. Give me your phone and all your photos and start streaming yourself 24/7, and you'd have a shot at justifying that. Can't do that? Then why defend VENDING YOURSELF with a passion? Or in my own tongue: 你等知不知“龟”字怎写？
The slippery slope is real.