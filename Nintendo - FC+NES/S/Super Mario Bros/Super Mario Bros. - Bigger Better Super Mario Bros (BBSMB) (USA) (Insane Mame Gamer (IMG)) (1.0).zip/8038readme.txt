BIGGER AND BETTER SUPER MARIO BROS

credits: (Trinsic) recoloring of the stages 
credit (Szemigi) ASM modification & level creation for world 9


Simply patch the included ips files to:

ROM / ISO Information:
Database match: Super Mario Bros. (World)
Database: No-Intro: Nintendo Entertainment System (v. 20210216-231042)
File SHA-1: EA343F4E445A9050D4B4FBAC2C77D0693B1D0922
File CRC32: 3337EC46
ROM SHA-1: FACEE9C577A5262DBE33AC4930BB0B58C8C037F7
ROM CRC32: D445F698

IMPORTANT
-Mario starts big, causes some unusual and unexpected things to happen. For example after passing a level while mario is enlargened or has fire power will cause mario to either lose his ability for the next stage or to shrink, however he can still be hit in such a case without losing a life. After taking a hit he will instead do the opposite, he will enlargen instead of shrink. After mario is hit and begins to enlargen he will lose a life instead of going tiny if he's hit once more. The only way to reset the patch back to its original mechanics is to lose one life. Keep in mind, if or when the following thing happens after passing stages it shouldn't inhibit or hinder game play. Although not free of flaws, the mario starts big patch still proves to be an invaluble and useful thing and hence the reason for including it. 

The stage selector runs automatically and the automation contained within its operation and or functionality is intentional. I'm considering or at least looking into the possibility of having it changed to being able to do it manually, like by pressing B-button to select Stage 9; in a later release. 


The fact that Mario turns white when getting a Fire Flower, is something that just sort of happened by mistake after the game was recolored and not something the author has control over. The "Y" in "BIGBOY" drifting over to the "LEVEL" screen as if it has a mind of its own, making it "LEVELY" is not intentional either. If this irritates you and you wish to have it removed you can do this by simply downloading and applying the skip black screen patch that's located on the RHDN website, however once you do this you will no loger be able to see the level displayer nor how many lives are displayed upon dying in the game. Please be advised that when patching ips files onto game roms, it may have unintended consequences that may or may not inhibit graphics and game play or in some cases render the game unplayable. 

