Mario Seasons is an unfinished hack by Dahrk Daiz. It was abandoned early in development as Dahrk Daiz decided to change to the SMB3 engine and eventually go on create Mario Adventure. Some of the ideas in Mario Adventure like changing weather are also present in this hack. Mario Seasons features (6) colorful levels with animation, a new power up and a new enemy. 

* Mario Seasons features six colorful animated levels, a new power-up, and a new enemy, offering a glimpse into the ideas that would later evolve into larger projects.

This release is an improvement-focused hack of Super Mario Bros. that reinterprets the game�s architectural level style, fixes critical issues present in the original release, and fully preserves the original gameplay physics. The difficulty is intentionally light but prolonged, creating a more endurance-based and methodical experience rather than a fast or punishing one.

* Improved Presentation

Expect subtle graphical adjustments, polished visual elements, and aesthetic refinements that enhance the overall presentation while staying true to the original game�s identity.

* Project Philosophy

Mario Seasons is the result of careful, detail-oriented work. It is not intended as a full level redesign or a radical gameplay overhaul. Instead, it serves as a respectful homage to the original Mario Seasons by Dahrk Daiz., offering a visually refreshed and technically improved way to replay one of the most iconic video games ever created.

* Additional Information

 
The hack contains hidden shortcuts, engine-based traps, and a few surprises for fans. In two rare sections, speedrunner-style techniques may be required to progress.
Patch is intended for: Super Mario Bros. (World) [!] 



Release date: 31.12.2025.

