This hack is an direct sequel to Bowser's Crown

Story: After Mario defeated Bowser, he accidentally destroyed the fire crown in four pieces. The power of the fire crown spread to four mystery lands, causing chaos in these worlds. The chaos that came out of the fire crown made Mario unconscious. While in that state, Mario saw a mystery character that looked exactly like Bowser. He saw him taking all four parts of the crown. You need to retrieve all parts of the crown.
The main villain of this hack is Bruce, brother of Bowser. He appeared first in SMB2j in levels 8–4 and D–4 before the final fight with Bowser.
World 1 is a prologue that happens right after Mario gets out of Bowser's castle in World 8 from Bowser's Crown 1.

Complete rom hack to Super Mario Bros. that changes:

-All levels,
-Very slightly modified music,
-Graphics,
-Some single gameplay mechanics.

1.1 Fixes single glitches. It also gives question mark blocks with power-up a new graphic, an exclamation mark block. It also makes invisible blocks visible by giving them a new unique graphic.