Hi!

Thank you very much for downloading
SUPER TERRIBLE PROJECT:
HALLOWEEN HACK
version 1!

This version came out on October 31st, 2022.
It will probably be updated with an extra world in the future.

For more information, you can visit my website:

https://coffeebug.neocities.org/stuff.html#stphh

Anyways, thank you for playing my game!
I hope you enjoy it :)

If you have any questions, please comment on my Neocities or email me at karayniko@gmail.com.

Don't get on the ceiling in 8-4.
