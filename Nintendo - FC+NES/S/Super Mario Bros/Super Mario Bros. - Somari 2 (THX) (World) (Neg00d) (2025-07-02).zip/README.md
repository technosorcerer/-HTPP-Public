# SOMARI-2
A simple ROM-Hack/IPS-Patch for Super Mario Bros. (World)
SOMARI – The beloved bootleg legend returns! After all these years, he's finally getting a brand-new adventure. Experience 32 remixed (and sometimes barely recognizable) levels in a minimalist and slightly humorous style that every bootleg could only dream of! Will you help Somari break the Bootleg Curse?

WHAT'S NEW?!

+ 32 (semi new) levels
+ updated graphics
+ no mid-stages checkpints
+ start with 5 lifes
+ new text & UI
+ slightly faster physics
+ glitched enemy designs
+ updated power up behavior
+ new water stages
+ a story (placed in the EXTRAS-folder)

This project is also a sequel to my other SMB. hack: 'Super Mario Bros. ARCADE PLUS'!
