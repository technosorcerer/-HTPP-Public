# SMB-ARCADE-EDITION
ROM-Hack/IPS-Patch for Super Mario Bros. (World)

NEW:
+ start with only one life
+ less time to traverse stages
+ new (partially humorous) text & UI
+ overall faster physics
+ different color palettes
+ updated power-ups
+ differnet score values
+ enemies are far more aggressive
+ MASTER MODE!!!
+ water stages are actually fun now
+ Luigi was named to Lario

This ROM-Hack gives you the feeling of playing for your inserted coins, so every life counts - don't skip any stages, actually unless you're a extremly talented SMB-player of course ;P!
![Screenshot (21)](https://github.com/user-attachments/assets/bca8433e-c23f-4bb7-aaf6-99ff294ccd17)
![Screenshot (20)](https://github.com/user-attachments/assets/2d4dc76f-2e63-4993-9aa5-727c4ff7f3bd)
![Screenshot (17)](https://github.com/user-attachments/assets/34d6bf2a-0023-4c50-806a-1242e26fd635)
![Screenshot (18)](https://github.com/user-attachments/assets/7024a31d-f30c-4c2e-b63a-16cb56b02407)
![Screenshot (19)](https://github.com/user-attachments/assets/6cedb71a-e33e-458d-8b36-12dec260ae6b)
