Hi.
Thank you for downloading.
I made Frozen Mario.




I don't think this patch is necessary (but how you use it is up to you)








I used SMB Utility,SMB Remodeler,YY-CHR,Google Translate,Nestopia,FCEUX,VirtuaNES,Kasion's NES Palette.
Thank You!!!!!!!!



by Xur(YJG)