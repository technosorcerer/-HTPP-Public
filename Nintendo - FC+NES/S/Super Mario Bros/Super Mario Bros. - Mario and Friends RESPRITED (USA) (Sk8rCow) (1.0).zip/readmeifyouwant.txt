This is a quick hack of ThroughT1m3's Mario and Friends that graphically improves many things. If you aren't familiar with Mario and Friends, it's a hack that adds an SMB2 style character select screen to SMB1. Like SMB2, each character has their own unique physics.

Here are a list of the things I've improved.

-Toad's sprites are more accurate to SMM2 and move better in terms of animation.

-Luigi's sprites have been replaced with ones modified from RatherNoiceSprites' sprite sheet
https://www.spriters-resource.com/custom_edited/mariocustoms/sheet/121757/

-Peach's sprites have been replaced with ones modified from Zugarix' sprite sheet
https://www.spriters-resource.com/custom_edited/mariocustoms/sheet/246060/

-Replaced the game's overall sprites with ones from SMB2J. The only exception is the gate sprite, which looked better to me than the brown mushroom. The ground tile is also the unused one and looks way better (imo) than the used one.

I hastily made this for myself as something to put on my everdrive but figured that other people may be interested in it. Because of this, there may be things left unchanged and some graphical glitches here and there. I admittedly haven't played through the whole hack. Yes, I got ThroughT1m3's permission to post this. 

CREDITS WOAHHHHHHHH

Luigi sprites: RatherNoiceSprites on TSR
Peach sprites: Zugarix on TSR
Original hack by ThroughT1m3