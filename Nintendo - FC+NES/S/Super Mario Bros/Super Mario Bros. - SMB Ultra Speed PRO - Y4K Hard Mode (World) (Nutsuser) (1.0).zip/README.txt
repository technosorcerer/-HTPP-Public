Title: Super Mario Bros. � Special: Embedded Industrybr 
Version: 1.0 
Author: extr1m (registered on romhacking.net as Nutsuser)
Game: Super Mario Bros. (NES) Release date: 02.06.2025 

Description: 

Ultra Speed Pro � Y4K ? Hard Mode is a fast-paced and brutally difficult ROM hack of
the original Super Mario Bros. (NES).
Designed for maximum speed, precision, and focus, this is a truly insane hardcore
experience.
Every jump is calculated. There�s no room for mistakes � only momentum.

 

 Features: 

Brutal, unforgiving difficulty
Optimized for ultra-fast, high-pressure gameplay
Dense and relentless level design 


Patch is intended for Super Mario Bros. (W) [!]