Mushroom Pipe Dream - Super Mario Bros.
©1985 Nintendo
2023 - 2024 Aether Knight

--------------------------
INTRODUCTION
--------------------------

Thank you for downloading the IPS patch "Mushroom Pipe Dream - Super Mario Bros." for the NES. This patch contains reconstructed levels for all 32 worlds of Super Mario Bros. for the NES.

----------------------------------
PATCHING THE ROM
----------------------------------

First you will need a patching tool. This can be found at zopharsdomain.net or through
a search at google.com for "IPS Patching". Please apply this patch to one of the following...

Super Mario Bros. (JU) (PRG0)
Super Mario Bros. (JU) (PRG1)

The patch MAY work on Super Mario USA (E). It will NOT work on the PC10 version or Vs. Super Mario Bros. version.

--------------------------------------------------------------
ABOUT MUSHROOM PIPE DREAM PATCH
--------------------------------------------------------------

This hack was started back in late 2021. Worked on sparringly until the end of 2022 and most of it was worked on during all of 2023. 

This is an extensive hack of the original SMB with all 32 worlds changed. Also virtually all sub areas are aligned with the main areas so you won't gain any shortcuts in the level by using them but you can usually find more coins/1UPs in these areas. (although if you lose a life in some of these sub areas you will be sent to the beginning of the world even if you passed a checkpoint prior however some sub areas may send you TO the checkpoint after losing a life.). As always it's a good idea to spend time collecting coins/1UPs in earlier worlds to use in later worlds. Lastly virtually all castles have multiple paths. These, like the sub areas, are aligned with the main castle area.

Keep in mind that some areas and coins/1UPs/? blocks can only be accessed depending whether or not you are small, big, or fiery Mario. These are all optional and you can complete each world regardless of Mario/Luigi's power-up status.

-----------------------
KNOWN BUGS
-----------------------

One to note is sometimes while getting hit from a fire bar with another enemy nearby will cause that enemy to walk backwards. This appears to just be a visual bug as the enemy will still act the same.

Climbing the rope to the top and holding left/right to drop sometimes causes you to fall through a solid block. Try holding up in addition to left/right to
have a better chnace of landing on a solid block.

----------------
NOTES
----------------

 - This hack, like many others, plays like the original SMB. So if a glitch worked in the original, it will probably work here too.

 - The climbing rope in some of the stages may act a bit wonky sometimes if you aren't facing it when jumping onto it. You also want to climb to the highest point of the rope and hold right to safely land on some platforms. This is especially true if you are big or fiery Mario. 

- There are checkpoints in all castle levels. However if you pass a checkpoint and lose a life in any sub area where you passed a checkpoint, you will start again at the checkpoint unlike some normal worlds where sometimes you will be sent back to the beginning of the world. (or in some cases sent to the checkpoint)

----------------
VERSIONS
----------------

v1.0 - 	Initial release

----------------------------
SPECIAL THANKS
----------------------------

 - ALXR, author of the Super Mario Bros. "GreatED" editor.
 - Contributors to the Super Mario Bros. Data Crystal.
 - Yy, author of YY-CHR.