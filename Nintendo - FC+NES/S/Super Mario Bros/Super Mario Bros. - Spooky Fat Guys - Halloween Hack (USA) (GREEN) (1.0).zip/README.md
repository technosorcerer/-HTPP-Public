# Spooky-Fat-Guys-Super-Mario-Bros-NES-Halloween-Hack
This hack replaces all character sprites and certain blocks/background elements with spooky, Halloween-themed content; it also changes the text to match. Time is disabled, and you start with 9X lives. You play as "Fatty," a middle-aged balding man, and must fight ghosts, aliens, grim reapers, and Jason Vorhees to save the Witch Queen!
