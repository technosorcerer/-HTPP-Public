﻿Title: Super Mario Bros. – Special: Embedded Industry
 Version: 1.0
Author: extr1m (registered on romhacking.net as NutsUser)
Game: Super Mario Bros. (NES)
Release date: 04.06.2025

 

 Description:
Special Edition with a unique "Embedded Industry" style — a dark atmosphere, faster tempo, deep visual redesign, and a hack concept that goes beyond the boundaries of traditional Mario.
This version also serves as a base template for future SMB1 hacks, featuring a strict, redesigned visual style and palette. Ideal for creators seeking a consistent and clean graphical foundation.

This is a refined and improved version of the classic Super Mario Bros., with careful visual tweaks and design enhancements aimed at creating a richer gameplay atmosphere. 


 
Gameplay changes:

1-2: Lift platforms shortened.

 
4-2: Two extra non-functional pipes were added to the Warp Zone for fun — they lead to glitch worlds. 

A used block was added, and one pipe now comes from a pit. 

A Blooper was added to hint at the glitchy abandoned zones.

 
5-2: One pipe now exits from a pit instead of the floor.


 
Graphics and visual updates:

Complete palette overhaul — all colors were carefully rebalanced for a richer visual experience.

 
 Clouds and bushes are now more aesthetic and smoothly shaped.

 
 Coins are rounder and slightly larger, adjusted pixel-by-pixel. 


 Bricks have no white stripe anymore — making them almost invisible against castle walls. 


 Bowser's and the Hammer Bros.' hammers were redesigned.

 
 Princess Peach features a completely different sprite (inspired by other hackers).

 
 The flag and the character shown on it have been completely redesigned.

 
 Bowser’s fire breath now correctly points to the right, as it should physically. 


 Piranha Plants have a completely new look (inspired by other hackers). 

 
1UP icons and score indicators were redrawn.

 Water surface now looks like light waves — visually improved.

 
 Blocks show “squinted eyes” when hit, hinting at shock endurance.

 
 Castle walls and blocks were visually improved.
A slight visual conflict with 8-4's underwater castle now looks artistically better.

 
 Mushroom platform bases and tops were redesigned.

 
 The axe at the end of castles has been replaced with a bomb (Bob).

 
 Background trees and poles were adjusted for visual harmony.

 
 Cannons have been fine-tuned. 


 Previously invisible blocks are now visible. 



Patch is intended for:
Super Mario Bros. (W) [!]