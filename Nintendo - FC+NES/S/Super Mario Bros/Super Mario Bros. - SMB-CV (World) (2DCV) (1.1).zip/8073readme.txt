INTRODUCTION
============
Re-experience the mystery of CV1 through the eyes of our favorite plumber, now with updated GFX.

STORY
=====
Not too many people know it...

But when Simon made his mythic quest to defeat the count, none other than Mario himself had set out to do just the same (he was just a little late). So it was, that Mario tasked himself with cleaning up Simon's leftovers. No glory necessary; he does it because he likes to!

TIPS & HINTS
============
Count on using save states casually unless you want the full challenge as I was not able to get checkpoints to work correctly. Expect to be back at the start of a level when you die. I think the layout of CV levels is too different from what the SMB engine expects and I just don't know enough to make them work.

Try to rely on your CV memories. I tried to locate power-ups/secrets in the original locations. CV veterans may be rewarded for their intuition but, rest asure, there are even more secrets scattered throughout. Also, there are two warps to be found and a few alternate routes.

For best appearance and overall experience, I highly recommended using FCEUX with the NTSC_2X Filter. And last, I recommend turning down the sound on this and playing some old-school CV tracks!


SPECIAL THANKS/TOOLS USED (Big thanks to the creators of these!)
================================================================
I used these to modify the base ROM.

GreatEd 1.5.2     (Very easy to use!)
FCEUX 2.2.3       (All testing was done in this)
YY-CHR            (Made the pixel-work easy
SMB Remodeler     (Used alongside with HxD & Altap Salamander to find addresses in GreatEd hacks)
HxD               (Used mostly to change the palette grouping bytes on various tiles)
Altap Salamander  (Used for it's binary file-compare tool)
Title/Text Editor (Can't remember which ones but they worked)


RELEASE NOTES
=============
1.0	09/10/23	Initial Release
2.0	11/12/23	Graphical Update/Improvement/Bugfix (1.0 patch included)
