This hack is a sequel to Bowser's Crown 2: Broken Crown and Bowser's Crown 1.

Story: Months have passed since Mario had defeated Bruce and taken the last part of the fire crown. Everything seemed to be fine, until one day, the shocking news spread across Mushroom Kingdom.
It turns out that Bruce, with all four parts of the broken fire crown, wanted to reborn his brother, Bowser. While Mario did stop him, the rebirth process had already begun. Bowser is reborn with the power of the fire crown. If he is reborn fully, he'll be unstoppable. It's time to defeat Bowser once and for all! The drain of power from the fire crown caused it to change into a phantom crown.

This hack is the third and final part of the ROM hack series "Bowser's Crown".

A complete rom hack for Super Mario Bros. that:

Changes all levels,
Very slightly modifies music,
Changes graphics,
Changes some single gameplay mechanics

1.1 Fixes bugs in single levels.

1.2 Changes 4-8 boss fight.