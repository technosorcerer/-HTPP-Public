 ___           ___
/   \ |\   /| |   \  /|        /|  
|     | \ / | |   / / |       / |  
\___  |  |  | |__/    |         |  
    \ |  |  | |  \    |         |  
    | |     | |   \   |    _    |  
\___/ |     | |___/ __|__ |_| __|__

Super Mario Bros. 1.1 is a romhack of the original Super Mario Bros.

Story:
One day there's a bad news: Princess Peach and 9 helmet-wearing turtles (who are Mario and Luigi's friends) are gone!
Looks like Bowser is up to his tricks the 25th time!
Can Mario (or Luigi) save them?

It features:
- Updated Mario and Luigi Graphics -
- New Dark Background -
- New Text -
- New Luigi Version -

Changelog:
V 1.1.8 - Brand New Autumn Theme
V 1.1.9 - Time Up Message Updated
V 1.1.10 - Make Player Get Small Fire/Double Death After Beating Any Normal Castle Level
V 1.1.11 - Secret World 9 Warp Zone + 1-2 Easier Minus World Clip
V 1.1.11.1 - Gives Player 5 Lives, Text Editing, Bug Fix
V 1.1.11.2 - Luigi Version Bug Fix

Note: In 9-3 after seeing the hammer bro, press B to go to the title screen and unlock 2nd quest + world select.
Luigi jumps higher in the Luigi version.

Current Version: 1.1.11.2

SMB1.1 is made by Horses.1079 in 2023.