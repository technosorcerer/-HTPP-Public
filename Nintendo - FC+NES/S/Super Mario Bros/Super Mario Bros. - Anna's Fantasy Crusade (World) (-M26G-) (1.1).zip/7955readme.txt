ANNA'S FANTASY CRUSADE - README.TXT
-----------------------------------
© 1985 NINTENDO      2022-2023 M26G
___________________________________________________________________________________________________________________________________________
O. Table of contents

I.   Hack Presentation
II.  Synopsis
III. Changelog
IV.  Level Names
V.   Level Design Explanations

___________________________________________________________________________________________________________________________________________
I. Hack Presentation

Anna's Fantasy Crusade is a SMB1 Hack made by M26G.

It features 8 worlds with 8 levels each, which makes a total of 64 levels. Every levels are unique, no level appears a second
time in hard mode. Moreover, each world have its unique theme.

In this hack, you play as Anna, one of the twins from the Lost Kingdom. The second player will play as her fantasy sister, Kate.

Don't hesitate to tell me if you find any bug or glitch in the hack.

___________________________________________________________________________________________________________________________________________
II. Synopsis

The adventure takes place in Anna's dreams, where Mario has been captured by the evil Bowser, who wants to use the powers of the
famous plumber to turn all dreams into nightmares. You will have to travel through 8 fantasy environments to save Mario from the
clutches of Bowser, and put an end to his evil plans.

___________________________________________________________________________________________________________________________________________
III. Changelog

1.0 - Initial Release

___________________________________________________________________________________________________________________________________________
IV. Level Names

World 1 : Nightsky Grasslands			World 2 : Sunset Seas				World 3 : Bluelands
1-1 : Greenway Meadow.........[GROUND]		2-1 : Grassway Shoals.........[GROUND]		3-1 : Blues Valley............[UNDERGROUND]
1-2 : Vegetal Cavern..........[UNDERGROUND]	2-2 : Spiny Flows.............[GROUND]		3-2 : Pipeline Plains.........[UNDERGROUND]
1-3 : Treeway Chasm...........[GROUND]		2-3 : Submerged Catacombs.....[UNDERWATER]	3-3 : Koopa Troopa Frontline..[UNDERGROUND]
1-4 : Bullet-Bill Banks.......[GROUND]		2-4 : Cheep Bridge Ocean......[GROUND]		3-4 : Navy Canopy.............[UNDERGROUND]
1-5 : Shroom Road.............[GROUND]		2-5 : Waterflow Cliffs........[GROUND]		3-5 : Brick Wasteland.........[UNDERGROUND]
1-6 : Cheep Coral Cove........[UNDERWATER]	2-6 : Fluid n' Flood Ruins....[UNDERGROUND]	3-6 : Lakitu Lake.............[UNDERGROUND]
1-7 : Cheep Leap Bridgeway....[GROUND]		2-7 : Rise n' Fall Treeway....[GROUND]		3-7 : Blue-Cubed Pyramids.....[UNDERGROUND]
1-8 : Burning Tree Garbage....[CASTLE]		2-8 : Fiery Stronghold........[CASTLE]		3-8 : Dry Citadel.............[CASTLE]


World 4 : Autumn Goldway			World 5 : Snowy Fields				World 6 : Underground Burrows
4-1 : Spike Rain Redlands.....[GROUND]		5-1 : Koopa Troopa Tundra.....[GROUND]		6-1 : Pipeline Sewers.........[UNDERGROUND]
4-2 : Koopa Troopa Grove......[GROUND]		5-2 : Chilly Meadows..........[GROUND]		6-2 : Tree Cranny.............[UNDERGROUND]
4-3 : Bloxpile Undergrounds...[UNDERGROUND]	5-3 : Bullet-Bill Breeze......[GROUND]		6-3 : Plant Rope Grotto.......[UNDERGROUND]
4-4 : Mushroom Canyon.........[GROUND]		5-4 : Freezing Tree Road......[GROUND]		6-4 : Mushroom Mine...........[UNDERGROUND]
4-5 : Bridgeway Banks.........[GROUND]		5-5 : Piranha Plant Palace....[GROUND]		6-5 : Basement Garden.........[UNDERGROUND]
4-6 : Shroomway Peaks.........[GROUND]		5-6 : Cold Lake Lands.........[GROUND]		6-6 : Hollow Blue Caves.......[UNDERGROUND]
4-7 : Stronghold Yard.........[CASTLE]		5-7 : Frosting Facades........[GROUND]		6-7 : Bullet Bill Base........[UNDERGROUND]
4-8 : Maze Mayhem Chapel......[CASTLE]		5-8 : Burnout Bastion.........[CASTLE]		6-8 : Moss Mansion............[CASTLE]


World 7 : Overwhelmed Mountains			World 8 : Magmatic Hellway
7-1 : Aquatic Canyon..........[UNDERWATER]	8-1 : Ruined Redways..........[GROUND]
7-2 : Flooded Treeway.........[UNDERWATER]	8-2 : Basalt Caves............[UNDERGROUND]
7-3 : Nostalgic Floodlands....[UNDERWATER]	8-3 : Blazed Trees Heights....[GROUND]
7-4 : Spike Fall Ways.........[UNDERWATER]	8-4 : Fire Keepyard...........[GROUND]
7-5 : Lake Tunnel.............[UNDERGROUND]	8-5 : Momentum Factory........[CASTLE]
7-6 : Coral Canopy............[UNDERWATER]	8-6 : Overflow Garbage........[UNDERWATER]
7-7 : Mushroom Waterworld.....[UNDERWATER]	8-7 : Tubular Labyrinth.......[CASTLE]
7-8 : Lost Ruin...............[CASTLE]		8-8 : The Final Fight.........[CASTLE]

___________________________________________________________________________________________________________________________________________
V.   Level Design Explanations

Compared to the original SMB1, in addition to question blocks, there are blocks with an exclamation point. These blocks
contains an item and question blocks contains a coin.

Some underground levels ends with a glitchy area when entering the final pipe. To prevent this glitch, it was therefore
necessary to end the level with a flagpole directly in the underground area.

There are [?] and [!] blocks in some underwater levels. They are present in these levels only to decorate because they cannot
be hit.