Thanks for downloading!
This is a hastily done minihack of SMB1 (with levels designed within 2 months) that features Celeste-styled gameplay.

Please apply .bps patch with beat.

Emulator compatibility: Compatible with newer emulators like FCEUX, BizHawk and Mesen. Not compatible with VirtuaNES due to that emulator defaulting undocumented MMC5 ROMs to use only 8KiB of extra RAM.

Controls: (You can just read the in-game tutorials!)
A: Jump
B: Dash (B is not used for running.)
A while on wall: Wall kick
UP+A while on wall: Wall jump (consumes stamina)

2023 w7n et al.