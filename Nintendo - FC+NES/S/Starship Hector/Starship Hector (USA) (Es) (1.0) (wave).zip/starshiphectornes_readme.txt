Starship Hector (NES)
Traducción al Español v1.0 (10/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Starship Hector (USA).nes
MD5: 5cc3e410259ba4daf17fc449a1dcf8dc
SHA1: eedcbd3fd1cea8f249f6fbb5322bb004b5fe5bba
CRC32: ac4af6a0
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --