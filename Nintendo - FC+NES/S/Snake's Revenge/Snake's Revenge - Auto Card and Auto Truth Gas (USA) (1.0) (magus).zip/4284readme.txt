--------------------------------------------------------------------------------
Snake's Revenge | NES | USA
Auto Card and Auto Truth Gas 1.0 | 2018-12-20
MagusLOGS | https://maguslogs.blogspot.com
--------------------------------------------------------------------------------

These patches allow to use Cards and Truth Gases automatically 
without selecting them as long you have it in your inventory.

Both patches can be applied separately and are available as BPS and IPS.


Instruction
--------------------------------------------------------------------------------
Auto Card:
- Walk into a Card required door and it will open without having a Card selected

Truth Gas:
- Talk to a Commander and he will tell you the truth without having Gas selected


Changelog
--------------------------------------------------------------------------------
1.0:
Added: Automatically open doors when the required Card is in the inventory
Added: Automatically use of Truth Gas when Truth Gas is in the inventory


Checksum
--------------------------------------------------------------------------------
No-Intro Name: Snake's Revenge (USA)
File MD5      17262CB7B1F1EA96055D93B83BAC379E
File SHA-1    49F1369C0E3926DA1AE4EF9BAA6C41F8C649B893
File CRC32    255A25FE
ROM MD5       C381AE61CA0F76CBC68F9F6B71AFE140
ROM SHA-1     1B2F59243D2B076369DE163D2A52E7077166CD9E
ROM CRC32     48E904D0                             


Credits and Notes
--------------------------------------------------------------------------------
www.romhacking.net
www.fceux.com

Feel free to use this patch in your projects.