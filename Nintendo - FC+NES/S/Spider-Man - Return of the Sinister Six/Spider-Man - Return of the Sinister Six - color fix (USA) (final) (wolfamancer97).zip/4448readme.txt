Colors,graphics and font edited. With great power comes great responsibility.
R.I.P. Stan Lee. �Excelsior!�.
You can also download my hacks from my facebook group: MVH - (NES rom hacks).
wolfamancer97 \m/.