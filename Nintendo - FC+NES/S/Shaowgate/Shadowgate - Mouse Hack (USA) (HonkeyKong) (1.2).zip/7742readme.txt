Shadowgate Mouse Hack
Version 2
By Ryan Souders, AKA "HonkeyKong"

Version 2 includes a new mouse driver that can detect whether you're using a Hyperkin or Nintendo mouse and adjust the sensitivity accordingly, as I found the Nintendo mouse didn't have nearly enough sensitivity by default. Patch this over the "Shadowgate (USA).nes" ROM with md5sum 00d418519d02d55848596f525ed15d18.

As with the Maniac Mansion hack, this new version includes two patches. One patch is for playing on hardware, the other is for playing on emulators. The only difference is that the emulator version doesn't compensate for the lack of sensitivity on the Nintendo mouse, so it moves better on PCs.

Do you like Shadowgate?
Do you hate the D-pad controls?
Then this hack is for you!
Just use your SNES to NES adapter cable to plug your SNES mouse into port 2, and click away!

Left mouse clicks (Like the A button)
Right mouse deselects (Like the B button)

On the save/load menus, the right mouse button toggles menu selections, and the left mouse button confirms.

If you don't have a SNES adapter, you can make one easily or buy one from one of these stores:
https://www.raphnet-tech.com/products/snes_to_nes_cable/index.php
https://misteraddons.com/products/snes-controller-to-nes-console-adapter