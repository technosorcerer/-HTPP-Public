Shadowgate Mouse Hack
Version 1
By Ryan Souders, AKA "HonkeyKong"

This one took a bit longer and was more involved with the Maniac Mansion hack, and it's still a bit buggy, but I think it's in a good enough state that I can put it out here for people to play. Patch this over the "Shadowgate (USA).nes" ROM with md5sum 00d418519d02d55848596f525ed15d18.

Do you like Shadowgate?
Do you hate the D-pad controls?
Then this hack is for you!
Just use your SNES to NES adapter cable to plug your SNES mouse into port 2, and click away!

Left mouse clicks (Like the A button)
Right mouse deselects (Like the B button)

On the save/load menus, the right mouse button toggles menu selections, and the left mouse button confirms.