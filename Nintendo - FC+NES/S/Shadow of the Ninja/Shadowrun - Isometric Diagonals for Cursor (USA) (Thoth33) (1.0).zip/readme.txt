This adjust the movement speeds of the cursor so that when moving diagonally it follows the isometric tiles instead of moving at 45 degree angles.

In vanilla the cursor has a vertical and horizontal movement speed of 3.
This changes the horizontal speed to 4 and the vertical speed to 2.

That's all it does. 

It not lining up with the tiles really bothered me, so I changed it. 