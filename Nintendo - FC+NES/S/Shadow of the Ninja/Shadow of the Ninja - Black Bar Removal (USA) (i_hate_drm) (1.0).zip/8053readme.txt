DOCUMENTATION

6502 Instruction Set:
https://www.masswerk.at/6502/6502_instruction_set.html

MAME Debugging:
mame nes -cart roms\sotn.nes -debug


SHOW MENU AFTER COMPANY LOGO:

1F89F:						CHANGE:
F88F  lda $0e		A5 0E		|
F891  bne $f89e		D0 0B		|
F893  lda #$0f		A9 0F		|	F893  lda #$1c		A9 1C
F895  sta $0105		8D 05 01	|	F895  sta $0e , nop	85 0E EA	// $0E = 1C
F898  sta $0106		8D 06 01	|	F898  nop nop nop	EA EA EA
F89B  sta $0107		8D 07 01	|	F89B  nop nop nop	EA EA EA


DISABLE BLACK BAR:

1E3E7:						CHANGE:
E3D7  lda #$18		A9 18 		|	E3D7  lda #$1e		A9 1E		// $09 = 1E... This gets stored in $2001 (PPUMASK)
E3D9  sta $09		85 09		|


FIX LEFT ARTIFACTING:

1F115:						CHANGE:
F105  lda $36		A5 36		|
F107  sbc $06c2, x	FD C2 06	|
F10A  sta $36		85 36		|
F10C  lda $37		A5 37		|
F10E  sbc $06d2, x	FD D2 06	|	F10E  jsr $9fa3		20 A3 9F	// Jump to below (if screen is scrolling left,
F111  sta $37		85 37		|	F111  nop nop		EA EA		//		  or it has reached left limit)
F113  jsr $f2b9		20 B9 F2

1DFB3:						CHANGE:
9FA3  brk brk		00 00		|	9FA3  sbc $06d2, x	FD D2 06
9FA5  brk brk		00 00		|	9FA6  cmp $27		C5 27		// $37 (current screen-x) - $27 (screen-x left limit)
9FA7  brk brk		00 00		|	9FA8  bpl $9fb0		10 06
9FA9  brk brk		00 00		|	| 9FAA  lda #$00	A9 00		// $37 is lower than $27. Not allowed.
9FAB  brk brk		00 00		|	| 9FAC  sta $36		85 36		// $36 = 00
9FAD  brk brk		00 00		|	| 9FAE  lda $27		A5 27		// $37 = $27
9FAF  brk brk		00 00		|	9FB0  sta $37		85 37
9FB1  brk brk		00 00		|	9FB2  rts		60


Free Space: 1DFB3 - 1E000