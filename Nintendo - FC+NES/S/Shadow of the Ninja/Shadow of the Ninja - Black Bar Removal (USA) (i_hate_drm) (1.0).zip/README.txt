Shadow of the Ninja - Black Bar Removal

This hack removes the black bar on the left side of the screen.
It fixes any artifacting hidden underneath.
Also let's you start the game right after the company logo.

This hack is compatible with the USA ROM of Shadow of the Ninja.

You can apply this patch using Lunar IPS.

Documentation has been included.

Hope you enjoy.