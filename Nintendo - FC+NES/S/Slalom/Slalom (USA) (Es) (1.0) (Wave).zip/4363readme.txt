Slalom (NES)
Traducci�n al Espa�ol v1.0 (02/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Slalom (U) [!].nes
MD5: 9364857a19ae29420dbb09ce6ab53324
SHA1: 35076dd398d52b3c51f451baf834c3f494c19ec5
CRC32: 6115164d
40.976 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --