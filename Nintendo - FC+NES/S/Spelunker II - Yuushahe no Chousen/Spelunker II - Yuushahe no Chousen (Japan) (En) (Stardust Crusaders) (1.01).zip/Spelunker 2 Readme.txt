===============Spelunker 2============================
==========A Hero's Challenge==========================
==================V1.01===============================
Genre: RPG

Source language: Japanese

Patch language: English

Author: Pennywise

E-mail: yojimbogarrett@gmail.com
http://yojimbo.eludevisibility.org/
 
 
======================================================
Spelunker 2 A Hero's Challenge
======================================================
Background: I originally intended this translation to be a
addedenum patch to an older translation released around
2003. I had posted the original Japanese script alongside
the fan translation asking if someone could look over it.
I was planning on editing and cleaning up the script, but
wanted to cover my bases before I did that. However the
talented translator Paul Jensen looked over the translation
and found that the fan translation was pretty bad and so
he retranslated the game from scratch and produced a really
good script for me to work with.

Hacking the game was pretty straight-forward and easy.
The ROM expansion to allow for the full script was trivial
to implement. All said, this translation didn't take too
long to finish. I do recall some confusion on just who
exactly the end boss was. Turns out you fight the guy who
killed the villain or something. Apparently even the
Japanese didn't really know what's going on.

The game is a Japan-only sequel to a game that was
originally developed stateside, I believe. I hear
Spelunker was quite the icon back in the day in Japan.
The game itself consists of 3 rounds, which can take
some time to clear. Gameplay additions include a virtue
meter and a simple class selection. The class's don't
have much bearing on the game aside from what the dead
spirits give you in round 2. Also the game has multiple
endings that depend on how long it takes you to beat the
game and how high/low your virtue meter is.
======================================================
Version History
======================================================
1.0 - initial release
1.01 - fixed timer and other fixes

======================================================
Patching Instructions
======================================================
Due to limitations in the IPS format and the changes I
made to the ROM, I'm only supporting BPS and xdelta formats
for this game.

Apply either patch to the original Japanese version of the game.

Spelunker 2 - Yuusha heno Chousen (Japan).nes

We would be highly grateful, if you find some time to 
contact us with proposals or corrections. Information
on found bugs or corrections would be highly 
appreciated as this patch hasn't been fully tested.

Enjoy the playing and do buy the game, if you like it!

======================================================

Credits go to:

Pennywise - main hacking, testing.

Paul Jensen - translation

sin_batsu - graphic design

aishsha - special thanks

calico - testing

All those who contributed into this process.

======================================================


Compiled by Pennywise. September 2025.
