Welcome to Bunny-Bunny Panic!!

Pt 1: Patching the ROM
Pt 2: Playing Notes
Pt 3: Special Thanks

--- Pt 1: Patching the ROM ---

There are two BPS files in the ZIP file:

- The regular patch has unlimited lives. Continues do not matter, and you receive a checkpoint at every new door or screen entry, but not for jar entries. Intended for first play :)
- Challenge Mode has limited lives (start with 4 extra lives). Continues matter (you have 6), and when you continue, you will start again at the start of the current level you're on. When you run out, you game over and must restart the game. You receive a checkpoint at every new door or screen entry, but not for jar entries. NOT intended for first play :)

Open your file patcher. You can use Floating IPS, but I recommend this online one since it will let you view the checksums of your ROM:
https://www.marcrobledo.com/RomPatcher.js/

NOTE: You MUST patch Bunny-Bunny Panic to a SMB2 USA (PRG0) ROM. The patch can be applied to other copies of SMB2-USA, but it will not load levels right and will likely glitch. The PRG0 rom is also the same one that was used in GlitchCat7's "Return to Subcon," so if you have successfully patched that game, you can also use it for this hack.

Upload SMB2-USA (PRG0) to marcrobledo.com, and it should return the following checksums:

CRC32:	7d3f6f3d
MD5:	71576d8339bd63198fcfc51a92016d58
SHA-1:  7df0f595b074f587c6a1d8f47e031f045d540dae

Do not check the 'remove header' box. Upload the BPS file as "Patch File", and then click "Apply Patch" to download a patched version of your ROM.

--- Pt 2: Playing Notes ---

- This hack is a 15-level Kaizo adventure, with a heavy emphasis on platforming and exploring the themes of SMB2.
- This hack was designed when I didn't know much about SMB2, so it is intended to be doable by players with limited experience in SMB2.
- Thanks to CircleFriendo, each unique area (ex: 1-1-1, 1-1-2, etc) has information on the pause screen! This tech was developed as we were making Bunny-Bunny Panic, meaning that this is the first ever hack to use this :)
- The hack takes a lot of inspiration from GlitchCat7's "Return to Subcon" and carries over its philosophy regarding damage. Most segments in this game are designed to allow you to damage-boost through one obstacle, and the checkpoints are generous.
- There are a few jars throughout the game that can warp you to the next world if you're in subspace!
- My final dev time for Bunny-Bunny Panic Challenge Mode was 52:00. Let me know if you beat that time :)

--- Pt 3: Special Thanks ---

- CircleFriendo, both for playtesting and developing every cool patch and piece of ASM for this hack. Thank you so much, this hack wouldn't be nearly what it is without your help.
- The SMB2 hacking discord, for providing motivation and help when I was about to give up on development. This discord has grown a lot in the past couple of months and has all kinds of fun projects, so if you're interested in developing your own stuff, feel free to join! https://discord.gg/fFdUmxMB
- princessbunbun_ for being an amazing wife and source of inspiration. I hope your fourth hack is the best one yet and I hope you like your new floaty power in this one :3 I love you!
- dtothefourth, for making SMB2Edit such an easy-to-use program. Thank you for this as well as everything else you do for the Mario community!
- GlitchCat7, for being the reason I checked out SMB2 in the first place. Your energy for the game helped me see how cool it actually is, and I can't wait for Subcon 2 :)
- my playtesters: CircleFriendo, redfeatherz, and Amethyst_Rocks. Thank you all so much for your help on this project and helping me see what needed to be tuned up before release. I am always eternally grateful :)