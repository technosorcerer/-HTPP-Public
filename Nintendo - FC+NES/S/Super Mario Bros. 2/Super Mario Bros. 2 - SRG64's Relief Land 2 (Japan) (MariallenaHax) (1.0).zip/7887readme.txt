WARNING: I USED DEEPL.COM

-------------------------------------------------
SRG64'S RELIEF LAND 2 
     README
-------------------------------------------------

Thank you for downloading this hackrom.
This readme contains descriptions of additional features.
Please patch your Super Mario USA and play with it.

... Before I go any further, I would like to say a few things.
1. Please do not play with pirated ROMs by applying patches to them. downloading pirated games is a serious crime.

2. It may be possible to apply the patch to the North American version of SMB2(European Version doesn't work), but in that case, please apply the patch to Rev.1.
If you apply the patch to Rev.0, it will probably break.

3. If you apply the patch, it is recommended to apply it to the dump from the VC version if possible.

4. Pause and release on a vertical scrolling area may cause a freeze.

The end of what I want to say

--------------------------------------------------

Table of Contents

1.Story

2.Additional features and changed features

3. Player Characters

4.Enemy characters

5.More Fun Contents

--------------------------------------------------

1.Story



A few months have passed since that deadly battle with Bowser in Dinosaur Land.
SRG64 returned to his normal routine and decided to go out to the riverbed to take a short break.
SRG64 "... ... Hmm?"
When he looked down the riverbed, he saw a girl lying on the ground.
The girl was badly injured and seemed to be unable to move, barely able to stand.
SRG64 patched her up.
Girl "Thank you..."
SRG64 "I'm glad she's healed. Be that as it may, why were you lying here?"
Girl "Actually..."
The girl then began to tell a story.
The Girl said, "Wart came back to life in Subcon. I tried to punish him, but I was toothless. Then I found myself here..."
I still have the power to go to Subcon. Please punish Wart on my behalf!"
When SRG64 heard this story, he immediately gathered his friends and told them about this.
He then hurried to the dream world where the Wart awaited him...







--------------------------------------------------

2.Additional features and changed features



Here we will talk about the elements that have been changed.

1. First, saving is now possible.
When you clear a stage and enter the character selection screen, the stage is automatically saved.
The saved data can be erased by pressing the select button on the title screen.
Note that erased data cannot be restored.
Also, if you start from the saved data, the initial remaining balance without saved data is 50, but it will be lowered to 30.

2. The suicide command can now be executed without requiring 2 controls.

3. BGM has been mostly changed.

4. A space area has been added. in space area, you can't small jump,large jump only. However, the space journey will soon be over.

5. All stages have been hacked (of course).



--------------------------------------------------

3.Player Characters

	SRG64 - A character with excellent jumping ability. Pickup speed is the same as Mario.

	JACKL - A fluffy but low jumping character. Pickup speed is the same as Luigi.

	Toadette - A little fluffy character. Pickup speed is the same as Toad.

	Daisy - The character is less able to fly than Peach. Pickup speed is the same as Peach.

	The speed at which the character holds things is the same as the original character.

--------------------------------------------------

4. Enemy character

	Shy guy - He throwable.

	Snifit - A nasty enemy that spits balls.

	Ninji - This time, they're going to take you by surprise! Watch out!

	Beezo - beezo red flying wildly appears immediately. More Beezo Madness!!

	Bob-omb - This time it's the ones that come out of the jar that are tricky. Stay calm and avoid them.

	Phanto - They'll chase you persistently, so you'll have to toss the key and pick it repeatedly to go to door.

	Pidgit - Is it on yet? git?

	Tweeter - Throw it at the boss and get rid of it!

	Trouter - Fish in a Subcon. 
	Be careful about the ones that appear on the quicksand because they will be dragged into the quicksand if you keep riding on them!

	Cobrat - Apparently, he can hide in places that aren't jars as long as there are mushrooms on top.

	Pokey - No Comment.

	Birdo - This time, the three brothers Pink, Red, and Green may attack you!

	Mouser - They recently covered their residence in needles. It hurts!

	Metal Mouser - A metalic Mouser revived by Wart. It is hardest, so use a star attack to defeat it!

	TryClyde - A transparent individual was recently discovered. Let's bump the eggs of the accompanying Birdo!

	Fry Guy - A fire with a soul. Why are you in this cold place!

	Clawgrip - He is amazingly fast at throwing rocks!

	Wart - A demon king who rules the Subcon. After using the Dream Machine to create so many monsters, he finally destroyed it.


--------------------------------------------------


5.More Fun Contents

The rest of this section contains spoilers about the world. Please read this after you have completed the hackrom.






























This story is an AU derived from the BS Super Mario USA Power Challenge... In other words, there were as many sub-cons as people could dream of seeing, where Wart and his friends were doing all the evil they could do. Remember this.

Wart was thought to have been defeated this time by Mario's success. But Wart was not defeated; he had escaped to another Subcon and was repeating his evil deeds.

Wart was not resurrected, but merely appeared in that Subcon... .it was only with the help of SRG64 that he finally fell this time.

The name of the girl in the instructions is Emul. She is actually a priestess who lives in Germania, JACKL's hometown, and is the guardian of ALF ALDEIA.

Germania is divided into six regions based on Norse mythology. However, even JACKL does not know about the regions other than ALF ALDEIA.

She supports Germania by praying and can even create a path leading to the dream world. But she has no power to fight. That is why she was toothless.

It is said that there are six priestesses, including Emul.

The reason why only the player character remains in the NES version while the enemies and terrain are in the SNES version order is to show that the enemies have been powered up.

Some graphics from Spriters Resource are used, and the credit notation required to use them is written at the end of the graphics area of the ROM. (You can check with HxD, etc.)

By the way, how can there be 2 and not 1? I think some people will say. Yes, it is not there now. It was being made, but it ended up unfinished.