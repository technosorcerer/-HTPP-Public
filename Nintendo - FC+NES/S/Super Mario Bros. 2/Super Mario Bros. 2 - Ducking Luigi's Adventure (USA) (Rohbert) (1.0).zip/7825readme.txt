Ducking Luigi's Ducking Adventure 1.0
by Rohbert
https://www.twitch.tv/rohbertgames

---Patch Instructions---
Use your desired .ips patching program and use the included SMB2_DuckingLuigi.ips file on a Super Mario Bros. 2 (U) (PRG0) [!].nes rom.

Play using your preferred emulator or flash cart. (This romhack has NOT been fully tested on real hardware)

--Summary---
Ducking Luigi's Ducking Adventure  is a romhack of Super Mario Bros. 2 USA for NES. It follows Luigi's story after the events of SMB2U. Luigis all across the multiverse have been kidnapped and it is up to Prime Luigi and friends to save them. Red Luigi, Waluigi and Louise will join Luigi in this ducking adventure. Good Luck!

This hack features 18 original levels. All the levels are inspired by their vanilla counterparts, so sections may seem familiar. However, every level is much harder than vanilla.  There are 3 warps. The first 2 are in their vanilla levels and take you to the same worlds and are optional. However, level 6-1 features a third warp that is  required and takes you to world 7.  All 18 levels contain 2 power up mushrooms and at least 1 one-up. Some levels contain multiple 1-up mushrooms. (YES it is possible to collect more than 1 per level) Each level features a unique color palette. All levels are complete-able with all characters. Oh yeah, also all characters behave exactly the same. They all behave like vanilla Luigi. Their differences are cosmetic only. You begin with 9 lives and 9 continues.

--Version 1.0 Info---
Initial Full Release - May 28, 2023

---Tips---
* If you ever lose a key, you can re-spawn it in its original spot if you simply walk 2-3 screen away and come back.
* If a hawkmouth exit despawns, you can simply walk 2-3 screen away and come back and it will respawn and even open if you already grabbed the orb. 
* If you see a cherry, get a cherry. Several sections are easier with a star power up and a few birdos and bosses can be star killed.
* All levels have 2 power-up mushrooms. (Highly recommended to collect them)
* Power-up mushrooms will always be between two identical palm tress OR in odd background structures. 
* Ladder jumps ARE REQUIRED. To jump off a ladder hold right or left while on a ladder and press jump right as you let go to jump off. 
* These characters can jump high and far. Take advantage. 
* Picking up 1-up mushrooms under low floating platforms will behave strangely...

---Thank You---
StewieCartman - Testing
dtothefourth - Incredible SMB2 editor (SMB2Edit)