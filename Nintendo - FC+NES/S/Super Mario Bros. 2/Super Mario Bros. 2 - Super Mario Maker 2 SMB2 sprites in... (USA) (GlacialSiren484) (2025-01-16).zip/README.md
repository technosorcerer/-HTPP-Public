Super Mario Maker 2 Sprites in Super Mario Bros 2 by GlacialSiren484

This patch changes the in-game player sprites for Mario, Luigi and Toad to match their Super Mario Maker 2 appearances. These changes also extend to their small sprites. Some of Peach's sprites were also edited. 
I reccomend using the US version of Super Mario Bros 2 when using this patch since that's what I used when creating it.
