Kuso Daydreams is a romhack of Super Mario Bros 2 centered around puzzles, weird glitches, and other oddities. "Kuso" is a genre of level design (traditionally within Super Mario World romhacking) that presents weird puzzles, often requiring glitch knowledge, without directly explaining the glitch within the level. 

Each level in this hack is composed of a single screen, or sometimes 2 screens - this is often a tradition within Kuso romhacks, as the stage can focus entirely on a distinct puzzle or trick. 

While all of the levels can be solved through experimentation and general puzzle-solving abilities, even without prior SMB2 knowledge, there may be some tricky spots if you aren't familiar with SMB2 glitches. If you wish, you can read up on SMB2 glitches beforehand via a few resources here: 

https://www.mariowiki.com/List_of_Super_Mario_Bros._2_glitches
https://tasvideos.org/GameResources/NES/SuperMarioBros2
https://strategywiki.org/wiki/Super_Mario_Bros._2/Glitches


===============
=Help / Hints=
===============
If you've opted to solve the levels organically, and you get stuck in a certain level, there are a few options available for you. If you'd prefer to have a HINT only, which does not reveal the full solution, there is a subfolder included within the download called "Level Hints", which includes txt files that reveal hints for each level. 

Additionally, if you'd prefer to simply be told the solution, you can check the "Level Solutions" subfolder. Note that, if you are only looking for a hint, and not the outright solution, I would recommend checking the "Level Hints" folder rather than this one. This should only be a last resort if you've given up on solving the puzzle completely. Lastly, you can always check the clear video uploaded to my YT channel. 

I've also created a playlist with the intended solution for each video in case you don't want to get accidentally spoiled (or you're supremely lazy):
https://www.youtube.com/watch?v=EQgwMuf__6s&list=PLkqd6SxspZkvOQ0QNOw9DVapi-doKdFqJ 

=======================
=Patching Instructions=
=======================
To patch, you'll need a clean ROM of the original game (USA and REV0; DO NOT USE REV1). The CRC32 header of the vanilla ROM you need to use is 43507232. You can use this tool to check what the CRC32 header of your original ROM is: https://www.marcrobledo.com/RomPatcher.js/ 

Next, make sure you have FLIPS downloaded: https://www.smwcentral.net/?a=details&id=11474&p=section

Open FLIPS and select "apply patch". Next, select the Kuso Daydreams patch for the patch to use, and the clean original ROM for the original unmodified ROM to use. 

============
=Misc. Info=
============
If you pause and hold UP and A and B together at the same time, you'll instantly die, which is useful for resetting puzzles quickly or getting out of a softlock. 

SMB2 DOES NOT SAVE WHATSOEVER. If you need to leave the game and come back to it, make sure to place a savestate down. 

=========
=Credits=
=========
Tools: dtothefourth
ASM: CircleFriendo, dtothefourth
Testing: LouisDoucet, MiracleWater
Inspiration: MST, GlitchCat7, abc_ore

Thanks for playing - good luck and have fun! 

==============
=V1.1 Changes=
==============
- Fixed places where you could clip into the ceiling with a vine (thanks Redfeatherz for pointing out)
- Added a 2nd breakable block to the start of 7-2 to prevent you from getting suck in a 1 tile area
- Fixed a break in 7-2
- Adjusted 2-2 to be less cryptic
- Fixed a break in 4-3
