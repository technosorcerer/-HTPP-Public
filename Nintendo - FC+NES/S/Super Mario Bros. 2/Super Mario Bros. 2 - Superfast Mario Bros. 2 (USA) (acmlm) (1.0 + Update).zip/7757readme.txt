Superfast Mario Bros. 2 hack by acmlm



Instant maximum acceleration, various delays cut out or speed values increased, nearly instant level clear.

It's about as fast as acmlm could make it go, and was meant mostly for a silly TAS, but turns out to be actually beatable too!

Origin: http://acmlm.rustedlogic.net/ips/



ROM to patch: Super Mario Bros. 2 (USA)
Database: No-Intro: Nintendo Entertainment System (v. 20210216-231042)
File SHA-1: 7DF0F595B074F587C6A1D8F47E031F045D540DAE
File CRC32: 7D3F6F3D
ROM SHA-1: 43AC7C7AAF1846EAD7B544302BB9131E4964FD32
ROM CRC32: 57AC67AF



MIT License