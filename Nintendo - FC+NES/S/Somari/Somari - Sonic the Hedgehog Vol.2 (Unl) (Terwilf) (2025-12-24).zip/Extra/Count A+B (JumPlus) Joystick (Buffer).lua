-- Configuración inicial
local countA = 0
local countB = 0
local prevA = false
local prevB = false
local prevSelect = false
local maxYVelocity = 0          -- Valor máximo registrado de Y
local jumpBufferTimer = 0
local JUMP_BUFFER_FRAMES = 6    -- Buffer de 6 frames (~100ms a 60FPS)
local Y_VELOCITY_THRESHOLD = 4  -- Umbral original de velocidad Y
local lastYOnJump = nil         -- Valor de Y al presionar A/B

-- Dirección de RAM para velocidad Y (ejemplo: $0015)
local ADDR_Y_VELOCITY = 0x0015

-- Función para resetear contadores
function ResetCounters()
    countA = 0
    countB = 0
    maxYVelocity = 0
    lastYOnJump = nil
end

-- Detecta pulsaciones y gestiona el jump buffer
function UpdateInputs()
    local input = joypad.get(1)
    local currentYVelocity = memory.readbyte(ADDR_Y_VELOCITY)
    
    -- Actualizar máxima velocidad Y registrada
    if currentYVelocity > maxYVelocity then
        maxYVelocity = currentYVelocity
    end

    -- Contar pulsación A (salto)
    if input.A and not prevA then
        countA = countA + 1
        jumpBufferTimer = JUMP_BUFFER_FRAMES
        lastYOnJump = currentYVelocity  -- Guardar Y al presionar
    end
    prevA = input.A

    -- Contar pulsación B (salto, misma lógica que A)
    if input.B and not prevB then
        countB = countB + 1
        jumpBufferTimer = JUMP_BUFFER_FRAMES
        lastYOnJump = currentYVelocity  -- Guardar Y al presionar
    end
    prevB = input.B

    -- Resetear contadores con SELECT
    if input.select and not prevSelect then
        ResetCounters()
    end
    prevSelect = input.select

    -- Lógica del Jump Buffer
    if jumpBufferTimer > 0 then
        jumpBufferTimer = jumpBufferTimer - 1
        if currentYVelocity < Y_VELOCITY_THRESHOLD then
            -- ¡Salto válido! (simulado)
            print("¡Salto ejecutado! (Y al presionar: " .. (lastYOnJump or "N/A") .. ", Y actual: " .. currentYVelocity .. ")")
            jumpBufferTimer = 0
        end
    end
end

-- Dibuja información en pantalla
function DrawHUD()
    local currentYVelocity = memory.readbyte(ADDR_Y_VELOCITY)
    
    -- Contadores de botones
    gui.text(10, 10, "A: " .. countA, "white")
    gui.text(58, 10, "B: " .. countB, "white")
    gui.text(180, 218, "SELECT: Reset", "yellow")

    -- Datos de velocidad Y
    gui.text(166, 208, "Y: " .. currentYVelocity, "cyan")
    gui.text(201, 208, "MaxY: " .. maxYVelocity, "orange")
    gui.text(204, 20, "Buffer: " .. jumpBufferTimer, jumpBufferTimer > 0 and "green" or "red")
    gui.text(171, 198, "Y On Jump: " .. (lastYOnJump or "N/A"), "yellow")  -- Nuevo: Y al presionar A/B

    -- Estado del salto (debug)
    if currentYVelocity < Y_VELOCITY_THRESHOLD then
        gui.text(189, 10, "Jump: Enable", "lime")
    else
        gui.text(189, 10, "Jump: Disable", "red")
    end
end

-- Resetear al cargar savestate
local lastFrameCount = emu.framecount()
emu.registerafter(function()
    if math.abs(emu.framecount() - lastFrameCount) > 1 then
        ResetCounters()
    end
    lastFrameCount = emu.framecount()

    UpdateInputs()
    DrawHUD()
end)