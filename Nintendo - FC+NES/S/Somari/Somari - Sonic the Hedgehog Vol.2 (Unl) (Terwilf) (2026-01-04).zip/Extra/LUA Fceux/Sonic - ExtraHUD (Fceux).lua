-- Variables globales para el estado del script
local maxOxygen = 0
local stage1Active = true
local stage2Active = false

while (true) do
    -- Leer dirección 0x81 para verificar si debemos cambiar de etapa
    local stageCheck = memory.readbyte(0x0081)
    
    -- ETAPA 1: Registrar valor máximo
    if stage1Active then
        local currentOxygen = memory.readbyte(0x009a)
        
        -- Solo registrar si el valor es mayor que 0 y mayor que el máximo actual
        if currentOxygen > 0 and currentOxygen > maxOxygen then
            maxOxygen = currentOxygen
        end
        
        -- Verificar si debemos pasar a la etapa 2
        if stageCheck == 0x34 then
            stage1Active = false
            stage2Active = true
        end
        
        -- Mostrar en modo registro (compacto)
        gui.text(22, 43, string.format("max: %d", maxOxygen))
        
    -- ETAPA 2: Mostrar cuenta regresiva (compacto)
    elseif stage2Active then
        local currentOxygen = memory.readbyte(0x009a)
        local oxygenDisplay = maxOxygen - currentOxygen
        
        -- Asegurarnos de que no sea negativo
        if oxygenDisplay < 0 then
            oxygenDisplay = 0
        end
        
        -- Mostrar en modo cuenta regresiva (compacto)
        gui.text(22, 43, string.format("air: %d", oxygenDisplay))
    end

    -- Resto del HUD (mantengo tu formato original en hexadecimal)
    personaje = memory.readbyte(0x00032b)
    enemigo = memory.readbyte(0x00032c)
    
    fondo1 = memory.readbyte(0x00032d)
    fondo2 = memory.readbyte(0x00032e)
    fondo3 = memory.readbyte(0x00032f)
    fondo4 = memory.readbyte(0x000330)
    
    gui.text(210, 224, string.format("sonic: %02X", personaje))
    gui.text(170, 224, string.format("obj: %02X", enemigo))
    
    gui.text(3, 224, "grx:")
    gui.text(25, 224, string.format("%02X", fondo1))
    gui.text(40, 224, string.format("%02X", fondo2))
    gui.text(55, 224, string.format("%02X", fondo3))
    gui.text(70, 224, string.format("%02X", fondo4))
    
    emu.frameadvance()
end