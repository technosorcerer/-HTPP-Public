-- Script para alternar 0001:FE basado en el offset $9A

local direccionTruco = 0x0001    -- Dirección a modificar
local direccionControl = 0x009A  -- Dirección de control
local valorOriginal = memory.readbyte(direccionTruco)
local valorTruco = 0xFE
local estadoAnterior = nil

while true do
    -- Leer el valor de control del offset $9A
    local valorControl = memory.readbyte(direccionControl)
    
    -- Activar truco si $9A ≠ $00, desactivar si $9A = $00
    if valorControl ~= 0x00 then
        -- Activar truco
        if estadoAnterior ~= true then
            memory.writebyte(direccionTruco, valorTruco)
            estadoAnterior = true
            gui.text(5, 214, "select: on")  -- 214 = 224 - 10 (margen inferior)
        end
    else
        -- Desactivar truco
        if estadoAnterior ~= false then
            memory.writebyte(direccionTruco, valorOriginal)
            estadoAnterior = false
            gui.text(5, 214, "select: off")  -- 214 = 224 - 10 (margen inferior)
        end
    end
    
    emu.frameadvance()
end