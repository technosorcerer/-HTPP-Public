Solstice - Return to the Kastlerock
Made by JP32
Final 1.0 HOTFIX 1 (05.04.2024)

This is hack of Sosltice on nes, 
it features brand new, made from scratch, all new map to explore!
Along with some new enemies and some (minor) unused stuff from the original game.

This hack is harder than the original, but nothing kaizo.
I recommend playing the original before this one.
---

Known issues: (May contain spoilers)

-Circling spike ball has incorrect hitbox, its bit taller than it should be

-Some enemies starts at wrong sprite for one frame before correcting themselves

-Sometimes enemies/players are visible when they should be behind the player, this is bug with the game

-In the final maze due to bizarre bug with the original game, the in-game minimap bugs out and auto-fills rooms player has not entered yet. This happens when you enter room #E1 or #DC in the final maze, rooms #E2, #E5, #E4(when you enter room #E8) and #E6 auto fills. At least the completion % fixes itself when you enter room E4. This is not that big of an deal since in both 100% and low% runs you need to enter all of those rooms anyway.
I tired many ways to fix this, I spend many hours of rearranging the rooms and in many other ways but it seems to always happen.



Change log: (May contain spoilers)

Final 1.0 HOTFIX 1 (05.04.2024) (public)
-Fixed deathloop in room #3C when entering to it from room #3B
-Fixed dates on changelog

Final 1.0 (05.04.2024) (public)
-All rooms are done
-The Final maze area added
-Added path to the ending
-Many old rooms got redesigned
-Added new area to the Caves area #3
-Remains of the old caslte got rework
-Moved some items around
-You start with two extra lives and after from continue
-Edited some text


Beta 2.5 (07.02.2024) (public)
-Gameplay demos are now fully implemented
-Added 19 more rooms
-Adjusted/moved some item/enemy locations
-Adjusted some wall/block/floor graphics in some rooms
-Some areas has more rooms in them
-Some adjustments and redesigns in some old rooms
-Added secret way to get into one certain area..
-Fixed the off center logo at the boot
-Edited text(intro, story, got-all-staff-pieces, credits..)
--

Beta 2.0: (13.01.2024) (private)
-added tons of new rooms(133), areas, some custom sprites
-potions gives now full amount instead of half when picked up
-room to ending opens with 6 staff pieces and gives the invincibility effect
-some adjustments, redesigns on old rooms
-edited "got all staff pieces" message
-some minor text edits
-Shortened the cheat code
--

Beta 1.5: (10.02.2023) (public)
-redesigned rooms #44, #54, #62
-made the currently WIP area less empty(still placeholder)
-fixed some minor issues and some minor adjustments on some other rooms
-more palette edits
-room to ending now opens up after obtaining all three staff pieces
-three staff pieces now gives the invincibility effect + potion refill
-in-game credits are now edited
--

Beta 1.0:  (31.12.2022) (private)
-34 rooms added
-redesigned rooms #08, #0C, #0D, #0E and #0F
-fixed credit checkpoints
-text edits are now properly in disassembly and not lazily edited after compile
-some palette edits
--

Alpha 1.0: (10.07.2022) (private)
-Initial release for beta testers
---

Special thanks to:
Cyneprepou4uk for the disassembly
Guillaume Saint-Amant for the map of the original game
Pbandpickle for some additional data
(You) for beta testing!

Patch the rom into following:
"Solstice - The Quest for the Staff of Demnos (USA).nes"
(No-intro set)
CRC32: 1D60732E
MD5: A42E31D875D0573BA858DE365628F608
SHA-1: 992DA7FAC9248204CDDCDF2E37412007359603BA
SHA-256: BCE351F5C84DFAC92C3B97BB5F59DBCD116CA2E3984DBA205041BE42161567AC
---



Password for the map is "Solstice" backwards ;).