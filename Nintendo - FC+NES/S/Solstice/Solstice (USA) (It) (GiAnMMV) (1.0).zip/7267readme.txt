===SOLSTICE ITA===
Traduzione amatoriale di GiAnMMV.

==Informazioni sulla ROM.
Database match: Solstice - The Quest for the Staff of Demnos (USA)
Database: No-Intro: Nintendo Entertainment System (v. 20210216-231042)
File SHA-1: E21F7982913B11933B3A6730316C81026575C70D
File CRC32: B802387C
ROM SHA-1: DB8A165B40542394C6F13914F4722743CD5AB511
ROM CRC32: EDCF1B71

==Cronologia delle versioni.
v1.0 - 12 apr 2024: Launch.

==Strumenti usati.
- "YY-CHR" by YY
- "Mesen"
- "WindHex32" by Bongo`

Nel caso riscontraste un qualunque errore, non esitate a contattarmi!