CHRONO TRIGGER
NES BOOTLEG VERSION
MENU TRANSLATION PATCH

This patch translates some basic elements of the NES bootleg of Chrono Trigger, or "Shi Kong Zhi Lun". 
The main purpose of this patch is to make the game somewhat more playable. The story is not translated.
By no means is this comprehensive. If you want to know the story, play the real Chrono Trigger instead.

How to apply patch:
You're gonna need to find a rom of this somewhere. Can't help you as regards to where.
The rom's CRC should be 382F65CC, if you want to know. After that, apply the patch to the rom with Lunar IPS, and you can then play.

Translated:
Character names
Purchasable consumable names/descriptions
Start menu
Most battle messages

Untranslated:
Equipment names/descriptions
Status screen
Tech names
Pretty much everything else

(I find-replaced the character names in the actual dialogue for fun. Beware of extra spaces or names getting shortened.)

Some gameplay tips if you want to venture into bootleg land:
*This game is *slow*. Playing on 2x speed is a good idea.
*ATB exists! Unfortunately, it's wonky and you can't move the cursor during animations.
*You can't swap around your party. Crono's always around, and when given the choice in the original the bootleggers just give you Marle. Robo and Ayla have almost no availability.
*The weaponry in the shop gets obsoleted by enemy drops later on. Check your equipment whenever anything drops.
*Fight everything. You need every experience point you can get. Crank the speed higher while you grind.
*The money cap is only 65535. You will frequently run into it once you reach the End of Time. Be sure to buy a bunch of consumables to free up space in the wallet.
*The devs only made the game go up to Magus. No, you can't use him. Yes, you'll need to grind. No, you'll never see Zeal.

This patch was made by Darrman. If you want to use it as a base for a better patch, then go ahead.
It's more designed to have the game be playable than comprehensively translated.
Disclaimer: I do not know Chinese and appropriate SNES Chrono Trigger names have been used.