SD Gundam - Gachapon Senshi 3 - English Translation Project
VERSION 1.0
4/22/19

Modified by MrRichard999 & Dr.Floppy
Translated by TheMajinZenki
Title Screen by FlashPV
Help in bug fixes by SlidellJohn ([J])

Here is a full translation for the game SD Gundam - Gachapon Senshi 3. Now you can navigate through the entire game in English without the language barriers!  