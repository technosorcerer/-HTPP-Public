- Put your ROM in this folder and rename it to "Super Loopz (J).smc"
- If it has a external 0x200 byte header. Remove it and check if you have the rigth ROM. 
- Double click make.bat to patch main.asm to ROM. You find modefied ROM in the root directory. 

Filename: Super Loopz (J).smc
Database match: Super Loopz (Japan)
Database: No-Intro: Super Nintendo Entertainment System (v. 20210222-050638)
File/ROM SHA-1: 26EA349AEFA5926DC94B493284ECE8052A86B7A8
File/ROM CRC32: 49601821
