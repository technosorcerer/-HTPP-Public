Street Fighter II - The World Warrior (NES)
Traducción al Español v1.0 (27/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Street Fighter II - The World Warrior (Unl) [!].nes
MD5: 46bc89fdec67561afbbcb2ea239bab99
SHA1: b58650e3579e8a0787764bc3ed3ce6166951f130
CRC32: 123096ac
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --