
Thanks to : 
Bluefinch - p-switch activates wooden blocks instead of coins patch.
WiP- wilson penn- Hammer Suit sliding ability , infinite lives, and no bonus games patches.
RussianmanSMWC  - stomping on goomba shoe doesn't kill the shoe patch. 
orangeexpo - quick death and death counter patches. 
Gmario3792 - bomb throwing lakitu patch. 
maCobra52 -  quarter donut block fall time patch. 
Koopa - Gilligan's Island theme music
smb3 prime discord
