==============================================================================================                                   
    //   ) )  //   )) //   )) /__  ___/     ///   ))  // ||     /|    //||     //   )) 
   //___/ /  //   // //   //    //         //        //__||    //|   // ||    //___//  
  / __  (   //   // //   //    //         //        / ___ |   // |  //  ||   / ____/   
 //    ) ) //   // //   //    //         //        //    ||  //  | //   ||  //          
//____/ / ((___// ((___//    //         ((____//  //     || //   |//    || //    
============================================================================================== 
BOOT CAMP
A Microhack by BlueFinch, 2023
------------------------------------------------

What is a microhack?
It's a word I made up to describe the type of project I was conceiving to produce.

	A microhack is a single world hack whose levels revolve around 
	various core changes to the engine of the game. There are changed tiles and 
	levels and overworld maps, sure; but there are also changed enemies, changed 
	gameplay, changed powerups, changed technical abilities, changed flow of 
	events in the larger story arc, etc… all in a smaller format (1 single world).
				— From the README of Super Flyin' Again by BlueFinch (May, 2020)

------------------------------------------------

Introduction:
This is a Kuribo Boot hack.
It involves augmented mechanics to the Kuribo's/Goomba's Shoe/Boot.
The differences are described in the next section.
This boot is used constantly, with very few moments of non-bootedness.

It is a medium-hard / hard, non-kaizo hack that demands precision.
(There is one shell jump in this game that is mandatory. Learn it, then!)

The levels are not wide and open, but tend to be closed and tight.
This is not a run-and-gun hack, but it is a precision one.

I tried to make all of the setups fair, but also challenging.
The difficulty generally grades upward till the end.

------------------------------------------------

Gameplay:
You will need to double jump all throughout this hack.
How? Well, you get upward acceleration coming off of a hit enemy.
With the White Boot, if you release jump while in the air
then press it again, you get a bonus jump.
Awkward at first, but then you get used to it.

This along with various other situations outlined below
in the attributes and abilities of the boot make for an 
interesting and fun mechanic to explore across a dozen levels.

Have fun. I think you will enjoy it!




------------------------------------------------

The White Boot Attributes and Abilities:
1) additional air jump post-hitting enemy.
2) additional air jump coming out of pipe.
3) can climb vines
4) can hold and throw objects
5) able to bounce on Spike's spikeball
6) Munchers are now dangerous to the boot! (lore: they eat through the boot because it is lighter)
7) Palette for boot is white throughout game (and ghostly white when in the fortress or certain other situations)

All of these together drastically alter the gameplay
making this concept interesting enough to make into
a microhack.

------------------------------------------------

Mods Included: 
(ASM) means i did the modification from the disassembly
(HEX) means i did it from FCEUX's HEX editor


QuickDeath (ASM):
Mario quickly returns to overworld post-death.

Quick Credits (HEX):
After the Princesses Chambers, the curtain drops and we immediately get "THE END"
without  cycling all the world maps and their names.

Fast Vine Climbing (ASM):
You don't have to climb vines by pressing up (though you can), but can simply repeatedly jump while in front of them to climb.

Auto Powerup (ASM):
I developed an auto-powerup mod that gives Mario a certain powerup / status at a certain point in the level (or takes it away)
If you want to use this, please do. Ask for most current version please! This mod should be very popular for creators!

Conveyors (and for Plains tileset) (ASM):
1) now carry enemies. (why they didn't before, who knows?!)
2) enemies become shelled when they land on conveyor (when applicable). 
I did this because Red Koopa Troopas refused to exit the platform at the end due to their fear of falling.

Infinite Enemies from Pipes (ASM):
Instead of goombas proceeding from a left or right pipe, I made it randomly choose
between Green Koopa Troopas, Buzzy Beetles, and Spinies. Also, a random palette is assigned
to each of them when they spawn. (I have a way to make this even better, but don't plan on it. Don't need it!)

Thwomps (HEX):
hitboxes now edge-to-edge for sure boot landing 100%. 
Otherwise, stock, it's abour 1/3 of the time the boot will make contact and not pass through the Thwomp. 
OrangeExpo's lua script helped me see what i was doing here.
NEB gave the great idea of assigning thwomp a distinct unused hitbox.

Hungry Vines (ASM):
this vine eats through solid tiles, and thus allows you passage to the other side of the level. 
they are marked with a bouncing vine on a block, so there is no question about what they are when you find them. 
I made this in the Super Flyin' Again era.

------------------------------------------------

General Credits:
	Captain Southbird for the SMB3 Disassembly
	SMB3 Prime Discord for the community


Specific Credits:
	Brian H (Double Bass): Idea to use giant goomba for title screen
	OrangeExpo: lua script to show hitboxes helped me improve thwomp hitbox
	NEB: idea to give thwomp his own hitbox, unshared with boom boom and bowser. 


Playtesting:
	NEB
	RetroHax
	Dave Marley Music
 




