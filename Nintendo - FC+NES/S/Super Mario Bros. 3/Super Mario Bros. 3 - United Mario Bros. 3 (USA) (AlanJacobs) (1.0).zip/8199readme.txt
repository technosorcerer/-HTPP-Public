United Mario Bros. 3 (Version 1.0)

November 3rd, 2023

----------------------------------
ROM Type:
----------------------------------
Works best with SMB3 (U) (PRG1) ROM

----------------------------------
About United Mario Bros. 3
----------------------------------

It's Super Mario Bros. 3! This time, it has 8 brand new worlds for Mario and Luigi 
to explore. Jumping on goomba's, kicking turtle shells and some small surprises as well, 
this has everything you love about the original game but taken a step further. The 
difficulty is on par with the original game. With the help of many familiar people 
from the SMB3 Prime community, this will hopefully bring you back to a time when you 
first played the original game with all its wonder and challenges. 

To sum up, the goal of this project is to keep the original format and gameplay while 
creating 8 brand new worlds for Mario and Luigi to explore. Each world has its own theme 
with custom levels, music and graphics. 

Contributors include Mari 42, Bluecrush, JoeSmo, Bluefinch, KP, RussianmanSMWC, Zacmario, 
Quick Curly, Googie, Koopa, Evilelf, Anas, Actiongamer, Vincent Hernandez and AlanJacobs. 

Enjoy!

----------------------------------
About Making United Mario Bros. 3
----------------------------------

A welcome invitation to AlanJacobs' SBM3 project turned into a collaboration
of many skilled hackers and level designers, all of which brought together for 
the first time by Discord. All contributing level designers submitted their 
levels upon approval by AlanJacobs and, with permission, subject to small design 
tweaks to improve the difficulty curve (it's tough to be consistent with many 
designers in one project!)    

-------------------------------------------------------
Brief History Behind this Hack as told by AlanJacobs
-------------------------------------------------------

In late 2017, I had an interest in possibly creating another project with the same 
'8 new worlds' premise as 'A New Journey' but make it much easier for the casual 
player. I worked together with Mari42 (who helped polished 'A New Journey' a year 
prior) and came up with many ideas on how to move the project forward.

Mari42 created our own Discord Channel in April, 2018. It primarily focused on SMB3 
hacking and our new project. The first person to join our server was Koopa who, little 
did we know at the time, is a skilled and valuable hacker who primarily focused on 
music for SMB3 and volunteered to do music for this project. Mari42 and myself split
the level design responsibilities. As more people joined the server, our little 
community grew as well as interest in our project. To take advantage of the community
and lighten our load a bit, I proposed to extend an invitation to those who are 
interested in helping our project. ActionGamer, Vincent Hernandez, ZacMario, Bluecrush, 
and Quick Curly designed levels for us. If memory serves me right, we had 
about 100 members in the one year our server was opened.

In April, 2019, we officially combined our Discord community with another SMB3 hacking
server led by Joe Smo (Known as SMB3 Prime later on...). The SMB3 hacking 
community grew substantially around this time. This was the first time we
practically had everyone in the SMB3 hacking community together in one place!
KP, Bluefinch, JoeSmo, Anas, Googie, RussianManSMWC and Evilelf made their 
contributions. We officially named the project 'United Mario Bros. 3'

I'll be honest, I felt a bit over my head leading this project. This, along with 
personal life interfering with hacking created many huge voids in it's development, 
three years to be exact. I've always kept this unfinished project in the back of my 
mind and it bugged me that it wasn't done. In late 2022, I secretly picked it back up 
and in February, 2023, I released the trailer and announced interest in testing. It was 
released on November 3, 2023! 
  
World Level Themes:

World 1: Autumn Forest
World 2: Ancient Ruins
World 3: Violet Slopes
World 4: Retrowave
World 5: Twilight Tundra
World 6: Sugar Land
World 7: Rainbow Road
World 8: ?

----------------------------------
CREDITS
----------------------------------

Main Title Screen-     KP
Muncher Fix-           RussianManSMWC
Sledge Bro-            RussianManSMWC
Underwater Attack-     Bluefinch
Shooting Cheep Cheep-  Bluefinch
Overworld Bridges-     JoeSmo
Mushroom House Timer-  AlanJacobs
Ending-                AlanJacobs
Patch Compilation-     Bluefinch

All music composed by Koopa 
*except for Plains, Athletic and Overworlds 3,4,5,6 and 7 composed by AlanJacobs

Autoscrolling by Mari42 and AlanJacobs

All graphics drawn by AlanJacobs
*except title screen by KP and Hilly Theme from an unused hack provided by Googie

Programs used with credits...

FCEUXD-               bbitmaster
SMB3 Map Editor-      Beneficii
SMB3 Foundry-         Michael
Workshop-             hukka
Object TSA Editor-    DahrkDaiz
YYCHR-                Yy



Level Design Credits:

World 1

1-  ZacMario
2-  *Based off a Level from AlanJacobs' abandoned Super Mario World Hack
3-  ZacMario
4-  *Based off a Level from AlanJacobs' abandoned Super Mario World Hack
F-  ZacMario
5-  AlanJacobs
6-  AlanJacobs
S-  Mari42


World 2

1-  Mari42
T1- Mari42
2-  AlanJacobs
3-  ZacMario
F1- Mari42
4-  ActionGamer
5-  ZacMario
6-  Mari42
F2- Bluecrush
T2- Mari42
S-  Mari42


World 3

1-  Mari42
2-  Mari42
3-  ZacMario
F1- Quick Curly
4-  Mari42
5-  Mari42
6-  Mari42
7-  Mari42
8-  Mari42
F2- Mari42
9-  Mari42
S-  Mari42


World 4

1-  AlanJacobs
2-  AlanJacobs
3-  AlanJacobs
F1- AlanJacobs
4-  *Based off a Level from abandoned SMB3 hack 'DM Mario 3' provided by Googie
5-  Bluecrush
6-  *Based off an unused level from SMB3 hack 'A New Journey'
F2- Mari42
7-  AlanJacobs
S-  Mari42


World 5

1-  Bluecrush
2-  Bluecrush
3-  AlanJacobs
F1- AlanJacobs
4-  AlanJacobs
5-  AlanJacobs
F2- AlanJacobs
6-  AlanJacobs
7-  Bluecrush
8-  AlanJacobs
S-  Mari42


World 6

1-  AlanJacobs
2-  AlanJacobs
3-  AlanJacobs
F1- Bluecrush
4-  AlanJacobs
5-  Vincent Hernandez
6-  Anas
7-  Bluecrush
F2- AlanJacobs
8-  AlanJacobs
9-  RussianManSMWC
10- Bluecrush
F3- AlanJacobs
S-  AlanJacobs


World 7

1-  AlanJacobs
2-  Evilelf
3-  *Based off a Level from abandoned SMB3 hack 'DM Mario 3' provided by Googie
F1- *Based off a Level from AlanJacobs' abandoned Super Mario World Hack
4-  Googie
5-  AlanJacobs
6-  AlanJacobs
7-  RussianManSMWC
8-  AlanJacobs
F2- *Based off an unused level from SMB3 hack 'A New Journey'
9-  AlanJacobs
S-  AlanJacobs


World 8

All Levels designed by AlanJacobs except the following...

F1- Mari42
2-  Googie


I wish to thank the following for their consideration and support...

Insectual
TDW (The Dark Warrior)
jiandao

Testers:
Mari42
Bluefinch
ZacMario
RetroHax
Joe Smo

If you wish to contact me for anything, especially if you have questions or want 
to report bugs, please do so at alanjakubs@gmail.com (notice that 'Jacobs' is 
spelled differently). Thank you!

-Alan Jacobs
