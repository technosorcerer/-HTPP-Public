V1.1 Update (4/20/2025)
Fixed a bug where you could accidentally die at the start of 8-2 holding left
(thanks GigaCrash for the bug report)

Thanks for downloading Wetland Trials! This hack is a challenging (non-kaizo) journey through 39 stages across 5 worlds. 
----------------------------------------------------------------------------------------------------------------------------
Overview

Within the download, you'll find 4 different versions of the romhack. These versions are all completely identical except 
for the life count. You can choose whether you want to play with limited lives (25, 50, or 90) or with infinite lives. 

If you aren't familiar with SMB3, the way the game works is that game-overs send you back to the start of the world you 
are in. Levels will all be reset. However, fortress locks and map rocks will remain broken or unlocked.

***Note that SMB3 DOES NOT SAVE by default. Unlike SMW, you cannot simply save the game and come back to it. You will need 
to place a savestate down or leave the console/emulator open if you'd like to continue a playsession. 
----------------------------------------------------------------------------------------------------------------------------
Patching

There are several different versions of the clean SMB3 ROM. To play this hack, you will need the PRG1 (U) version. 

To patch the hack, simply use Flips and patch with the clean PRG1 (U) ROM.
Flips download link: https://www.smwcentral.net/?p=section&a=details&id=11474

If you don't have an NES emulator, I recommend Bizhawk. 
Bizhawk download link: https://tasvideos.org/BizHawk
----------------------------------------------------------------------------------------------------------------------------
Credits

Testing:
Lazy
Lui
MiracleWater
Squirrely

Tools:
Michael Nix
Joe Smo
Beneficii
never-obsolete

ASM:
Lui
Russianman

Level Design Inspiration:
Adam
Jolpe
lolyoshi
Lui
Morsel
rextep
SIG
Truxton
Wagokoro

Special Thanks:
Lazy & MiracleWater - for various level design advice
Lui - for ASM assistance
Quick Curly - for very helpful hex editing tutorials


-hack by gbreeze-