	The Land of a Thousand Boom Booms (prg-1 SMB3)

	by BlueFinch, 2019
	bluefinch2012@gmail.com

A Microhack of medium difficulty
which demands a good grasp of traditional mechanics.

A sequel is in the works which contains 3 new species of Boom Booms 
and vastly improved Boom Boom abilities overall.

Inquire further on the SMB3 Prime Discord

----------------------------------------------------------

What's the lore? I need a story!
*ahem* Here we go...

Alright, so Bowser's koopalings discovered oil in the terrace garden of his old castle while burying a dead...tree... 
So, he did what any other Bowser would do and sold the drilling rights to Big Oil. 

With all that new oil money...
He bought himself a nice big plot of unwanted swamp land.
He illegally built upon said swampland a shiny new castle within shouting distance of the Mushroom Kingdom Capitol.
He encompassed himself round about with a bunch of dungeons.
And of course, he kidnapped himself a cute princess.

Go get her back, and shut down the evil empire once and for all.
(Also, raid his vault. He's loaded, Mario. LOADED!)

----------------------------------------------------------

