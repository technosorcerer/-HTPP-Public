Superfast Mario Bros. 3 hack by acmlm



Instant maximum acceleration, various delays cut out or speed values increased, nearly instant level clear.

It's about as fast as acmlm could make it go, and was meant mostly for a silly TAS, but turns out to be actually beatable too!

Origin: http://acmlm.rustedlogic.net/ips/



ROM to patch: Super Mario Bros. 3 (USA)
Database: No-Intro: Nintendo Entertainment System (v. 20210216-231042)
File SHA-1: A03E7E526E79DF222E048AE22214BCA2BC49C449
File CRC32: 85A79D9C
ROM SHA-1: A611B90B4833B20A364BF06EE3BE3B9093EA4DF9
ROM CRC32: A0B0B742



MIT License