Nintendo Entertainment System

256×240 (256×224 also acceptable with over scan cut off)