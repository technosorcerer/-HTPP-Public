Grumpy Mario Bros by Neb
Read Me (or don't!)

24 exits of chocolaty SMB3 kaizo. Intermediate to advanced difficulty. 

All of the asm not attributed to someone else below was made by me. I am happy to share anything I've made if asked (and if feasible).

Credits

Playtesting:
LzyTom
GrumpyJake
NerdAlert
SlothbearMillionaire

Music:
NerdAlert

Asm and sprites (detailed attribution in SPOILERS section below):
RussianMan
Captain Southbird
Bluefinch
WilsonPenn
MaCobra52

SMB3 Disassembly:
Captain Southbird

Tools:
Michael and Joe Smo


SPOILERS BELOW



-

-


Asm/Sprite attribution (some additional modifications to some of these sprites/asm by me):

Russianman: pay coin to jump, pipe munchers on jump, balloons, cloud generator, crazy chomp, disco shell, exploding platforms, shy guys, swoopers, upsidedown nipper
Captain Southbird: SMB2 spark enemies
Bluefinch: Auto-powerup, rechargeable flight
WilsonPenn: quick death, muncher fix, airship death blocks
MaCobra52: clipping fix



