Hey, the name's Kazufox. Here's my contribution to Bowsette replacing Bowser in the final boss battle. Other changes have been made as well. This version keeps all the other enemies and gameplay in tact as is.
=
V1.0 - Bowsette Boss Battle
-Replaced Bowser sprites with Bowsette
-Replaced Super Mushroom with Super Crown just because
-Minor changes to text of end of World 7 letter and ending
=
Base build:
Super Mario Bros. 3 (USA)
File SHA-1: A03E7E526E79DF222E048AE22214BCA2BC49C449
ROM SHA-1: A611B90B4833B20A364BF06EE3BE3B9093EA4DF9
Super Mario Bros. 3 (USA) Rev A
File SHA-1: 6BD518E85EB46A4252AF07910F61036E84B020D1
ROM SHA-1: BB894D104C796F69BA16587EB66C0275F5C2FC02
=
Available now is the V2.0 with most of the enemies replaced with a Super Crown version. 

Super Mario Bros. 3 Crowned Edition.
https://www.romhacking.net/hacks/4296/
=
Contact:
If you need to reach me about anything, I'm around on a few places.
Discord: Kazufox#0035
DA: https://www.deviantart.com/kazufox
FA: https://www.furaffinity.net/user/kazufox/