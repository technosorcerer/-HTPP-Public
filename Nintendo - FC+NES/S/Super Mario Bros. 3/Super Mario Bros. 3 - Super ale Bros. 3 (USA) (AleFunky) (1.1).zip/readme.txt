Super Ale Bros. 3 help:
For any bug report or questions, contact me on twitter: @AleFunky890