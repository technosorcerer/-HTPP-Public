   _____  ___________.____    .____    ________            
  /     \ \_   _____/|    |   |    |   \_____  \           
 /  \ /  \ |    __)_ |    |   |    |    /   |   \          
/    Y    \|        \|    |___|    |___/    |    \         
\____|__  /_______  /|_______ \_______ \_______  /         
        \/        \/         \/       \/       \/          
  _________ ___ ______________.____    .____    ________   
 /   _____//   |   \_   _____/|    |   |    |   \_____  \  
 \_____  \/    ~    \    __)_ |    |   |    |    /   |   \ 
 /        \    Y    /        \|    |___|    |___/    |    \
/_______  /\___|_  /_______  /|_______ \_______ \_______  /
        \/       \/        \/         \/       \/       \/ 

-------------------------------------------------------------
Mello Shello
A Microhack by BlueFinch, 2025

Series:		Mello Shello (1 of 2)
Adornment: 	Chocolate
Difficult: 	Kaizo
Type: 		Microhack (Serial)
Patch:		Rev1



Table of Contents
1) INTRODUCTION
2) MODS
3) CREDITS

------------------------------------------------

1) INTRODUCTION
This game includes 16 levels. 
It is part 1 of a planned 2 part series.

The game uses standard tech and mechanics, other than the following:
1) Super Flight 
2) Vertical Screenwrap on some levels.

It plays like a kaizo hack. 
The levels are all moderate length and mostly 1-area (no in-level pipe transition), and mostly grade upward in difficulty over the length of the hack.
Many of the setups are intuitive, but some demand a bit of testing to figure out.
I won't apologize for that! 
That is why it is a microhack of 16 levels and not a 60-level behemoth! :-) 

The game will seem traditional aesthetically and a bit non-traditional game play-wise.



------------------------------------------------
------------------------------------------------



2) MODS:
(ASM) means i did the modification from the disassembly
(CHR) means there was a graphics change involved.
(HEX) means i did it from a HEX editor. 

	Contents:
	2.1) Meta 
	2.2) Tech
	2.3) Enemy
	2.4) Tile and Block  


------------------------------------------------

2.1) Meta Mods:
Hack Name in HUD (ASM) (CHR)
Infinite Lives (ASM) (CHR)
No End Credits World Maps / Curtain Drops to "THE END" (HEX) (CHR)

------------------------------------------------
------------------------------------------------

2.2) Tech Mods:
The Super Flight (ASM):
The Super Flight tech (see Super Flyin' series by BlueFinch, 2020) makes an appearance in one level.
1) Reset flight timer after landing on stompable enemies.
2) Can fly indefinitely as long as new enemies spawn to be hit.

Throw-up & Place-down Shells (ASM) by 0r4ng33xp0:
Shells / bricls can be thrown upward, or dropped. 
This tech is used to throw shells and bricks upward, and also to drop held shells.

Vertical Screenwrapping (ASM) by BlueFinch:
If Mario falls into a pit in Plains or Sky tileset, he appears in the sky above to continue his descent.

*Super Flight ported to SMB3 by BlueFinch, developed by Nintendo for the Mario Maker franchise.

------------------------------------------------
------------------------------------------------

2.3) Enemy Mods:
Disco Shell (ASM) by RussianMan and BlueFinch:
Color-cycling shell you can bounce on indefinitely.
If the disco shell touches lava, interesting things happen!

Yellow Koopa (ASM) by BlueFinch:
This special Koopa can be bounced on and shelled. 
Then in its shelled state, it can be continually bounced-on (and shoot off one direction or the other).

Rider Beetle (ASM) by BlueFinch:
A hopping black beetle you can ride, and steer by pressing B.
You can gain p speed by running on top of him.

Flying Toggle Koopas (ASM) by BlueFinch:
If you hit a Red Flying Koopa, it turns into a Green Flying Koopa — changing direction and color.
It happens the other way as well, with Green turning into Red.

Platform Thwomps (ASM) by Captain Southbird and BlueFinch:
Thwomps can be stood upon.

Boom Boom / Fireball Boom Boom (ASM) by BlueFinch and Or4ng33xp0:
Can have multiple Boom Booms in an arena. Last one gives the orb. 
Many changes to Boom Boom's functionality. 

------------------------------------------------
------------------------------------------------

2.4) Tile and Block Mods:
Row Munchers in some tilesets where they didn't exist.

Custom overworld tiles, like Level T (skippable), and Bonus 1 and 2


------------------------------------------------



3) CREDITS

Credits:
	Nintendo: Thank you for Super Mario Bros. 3
	Captain Southbird: Thank you for the SMB3 Disassembly
	
	TikTok for the thriving Mario 3 kaizo streaming community
	Including Boonie Veteran, Berna Lark, Dani El Master
	Retro Video Gamer, KAWA Mario, Newfie — The Mushroom Kingdom, J Miguel Gamer, and others.
	
	Mitch Flower Power for streaming Mario 3 romhacks on his platform.
	
	TikTok viewers / supporters / friends who contribute in interest.

 	Michael who invented and maintains Foundry and Scribe, the preeminent tools for Mario 3 hacking.

	Jesus Christ, Son of God, the author of life and all creation. 
	John 3:16-17, Acts 2:14-41, 2nd Peter 1:3-15


Playtesters: 
	Brandon Ch33s3Burg3r, Frank the Tank, Woody (early)


Tools:
	Notepad++
	The 'Captain Southbird' Disassembly of Super Mario Bros. 3 (NES)
	Foundry (Michael's Level Editor)
	Beneficii's Map Editor
	MESEN (Hex editor / Emulator)
	ASM 6502 Opcodes website reference for doing hex editing.

	All Mario-related tools available on Romhacking.net


