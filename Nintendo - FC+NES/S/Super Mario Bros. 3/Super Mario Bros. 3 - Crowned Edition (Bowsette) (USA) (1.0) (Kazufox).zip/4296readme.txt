Hey, the name's Kazufox. Thanks again for taking time to play SMB3 Crowned Edition. I appreciate it; it took me over a month nearly working crazy to get this together. So here's what's in the Crowned Edition (V2.0) over the original SMB3 replacing Bowser with Bowsette (V1.0):
=
V1.0 - Bowsette Boss Battle
-Replaced Bowser with Bowsette
-Replaced Super Mushroom with Super Crown
-Minor changes to text of end of World 7 letter
=
V2.0 - "Crowned Edition"
-Updated colors and slight tweaks to some of Bowsette's sprites.
-Replaced missed Mushroom sprites with Super Crown. (Including the Mario Bros. battle mini game.)
-Replaced 55 additional characters with a Super Crown counterpart! (Could list them all, but it's better to see for yourself. It's pretty much ALL the enemies also Toad. Yes, Boom-Boom and the Koopalings are included in this change. Even the Mario Bros. VS minigame has changes too.)

Additional changes:
-Title screen.
-Bonus game Toad.
-Map item changes: Hammer Bros., Fortresses, and Bowsette's Castle.
-Changed all the Princess' letters messages.
-Changed various sprites in ending to be Super Crown versions.
-Changed the Mushroom fireworks to Super Crown.
-Replaced Mushroom in Spade House slot minigame to a Super Crown.

Bonus Content:
Applying the KoopaPeach.bps patch to changes the final battle against Bowsette to Koopa Peach (or Princess/Peach Bowser, the one from the official Mario Odyssey art book) with changed letter after World 7, boss sprites, and ending scene.
=
Contact:
If you need to reach me about anything, I'm around on a few places.
Discord: Kazufox#0035
DA: https://www.deviantart.com/kazufox
FA: https://www.furaffinity.net/user/kazufox/

Special Thanks:
To the various anons on 4Chan/4Channel's /bowgen/
MFGG
RomHacking.net
AYYK92
Nintendo
Any and all supporters of the project!
I look forward to bringing you all more Bowsette related content in the future.