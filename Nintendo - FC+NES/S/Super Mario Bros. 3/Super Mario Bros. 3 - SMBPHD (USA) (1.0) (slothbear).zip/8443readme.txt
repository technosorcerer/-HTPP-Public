SMBPHD by Sloth Bear Millionaire (slothbear)
Released February 14, 2024


Requires Super Mario Bros. 3 (U) (PRG1)
Patch with Lunar IPS or preferred utility

-=-=--=-=-=-=-=-=--=-=-=-=-=-=--=-=-=-=-=-=--=-=

SMBPHD is a modern kaizo with 7 main worlds plus an unlockable 8th world
that requires finishing World 7 with 7 secret keys in your inventory. 

You are strongly advised not to start your kaizo journey with this game,
unless you are ready for an intense challenge.

Players that are new to SMB3 kaizo should consider starting with Git Gud by Wilson Penn. 

-=-=--=-=-=-=-=-=--=-=-=-=-=-=--=-=-=-=-=-=--=-=

Special thanks to candydiscord for her incredible, unfailing support <3

Special thanks to Wilson Penn for extensive ASM, design assistance, playtesting, friendship & support. Without Wilson, this game would have been
far less unique and possibly never released at all.

Credits:
or4nge33xp0 - ASM
macobra52 - ASM 
BlueFinch - ASM
MitchFlowerPower - extensive playtesting
lzytom - extensive playtesting
link_7777 - extensive playtesting
jabemx - playtesting
chr1570ph3r - playtesting
kangaroos_are_cool - playtesting
narfman - playtesting




