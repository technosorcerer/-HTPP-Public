Econo v1 Readme

Econo is an SMB3 Kaizo Hack. I aimed for a difficulty that can roughly be described as "intermediate." I made it using a USA Rev1 version of SMB3, and I cannot guarantee that it works with other versions. You can watch the trailer here, but it does contain spoilers (of course): https://www.youtube.com/watch?v=RSv4RPyHEEo. 

This hack is loosely inspired by and dedicated to the music of the Minutemen. I hope you enjoy it. 

Special thanks to the following people who directly contributed to the hack. 

WilsonPenn: Many integral patches, custom asm, asm support and debugging help, and general inspiration from his hack "Git Up Git Out Git Gud"
GrumpyJake: The first person to playtest the whole hack, and the person who had to deal with the worst of the jank
BlueFinch: Patches, custom asm, and  playtesting
Kurbo: Playtesting
MitchFlowerPower: Playtesting
JoeSmo: A key patch, and helping get the patch to work in my hack. Also, I built the hack using a JoeSmo branch of the Foundry creation tool.
MaCobra52: Very many patches
or4ng33xp0: Patches
Captain Southbird: SMB3 disassembly
Loop_Hazard: Music in the hack trailer

Thanks also to the entire SMB3 Prime discord server, and to various Mario Maker 2 friends who inspired me to make levels. 

If you have any questions about making SMB3 hacks or about any of the patches/asm used in the hack, feel free to reach out. And if you encounter any trolls, cheap deaths, or jank, I don't know how they got there.
