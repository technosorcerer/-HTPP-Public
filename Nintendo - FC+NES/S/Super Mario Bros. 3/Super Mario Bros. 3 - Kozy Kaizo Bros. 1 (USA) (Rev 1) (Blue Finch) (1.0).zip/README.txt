



Kozy Kaizo Bros. 1 
A Microhack by BlueFinch, 2024

Series:		Kozy Kaizo Bros. (1 of 3)
Adornment: 	Vanilla+ (feels mostly stock but isn't)
Difficult: 	Kaizo
Type: 		Microhack (Serial)
Patch:		Both Rev1 and Rev0 patch included



Table of Contents
1) INTRODUCTION
2) MODS
3) CREDITS

------------------------------------------------

1) INTRODUCTION
This game includes 15 levels. 
It is part 1 of a planned 3 part series.
At the time of the release of this hack, the second is already in the works.

The game uses standard tech and mechanics, other than the following:
1) Super Boot 2) Super Flight and 3) Ballooki Suit. These are explained below.

It plays like a kaizo hack. 
The levels are all moderate length and 1-area (no in-level pipe transition), and mostly grade upward in difficulty over the length of the hack.
Many of the setups are intuitive, but some demand a bit of testing to figure out.
I won't apologize for that! 
That is why it is a microhack of 15 levels and not a 60-level behemoth! :-) 

The game will seem traditional aesthetically and game play-wise, other than the changes to player tech in 5 of the levels.



------------------------------------------------
------------------------------------------------



2) MODS:
(ASM) means i did the modification from the disassembly
(CHR) means there was a graphics change involved.
(HEX) means i did it from a HEX editor. 

	Contents:
	2.1) Meta 
	2.2) Tech
	2.3) Enemy
	2.4) Tile and Block  


------------------------------------------------

2.1) Meta Mods:
Hack Name in HUD (ASM) (CHR)
Quick Death (ASM)
No Skidback Post-Death (HEX)
Infinite Lives (ASM) (CHR)
No End Credits World Maps / Curtain Drops to "THE END" (HEX) (CHR)

------------------------------------------------
------------------------------------------------

2.2) Tech Mods:
The Super Boot (ASM) (CHR):
The Super Boot (see Boot Camp microhack by BlueFinch, 2023) makes an appearance in 2 levels.
1) additional air jump post-hitting enemy.
2) Munchers are now dangerous to the boot! (lore: they eat through the boot because it is lighter)

The Super Flight (ASM):
The Super Flight tech (see Super Flyin' series by BlueFinch, 2020) makes an appearance in one level.
1) Reset flight timer after landing on stompable enemies.
2) Can fly indefinitely as long as new enemies spawn to be hit.

The Ballooki (Balloon Tanooki) (ASM) (CHR):
This suit makes its first appearance here and is found in 2 levels!
1) Uses down+B to become balloon. (I could've made it us up+B but i wanted it to feel familiar)
2) Uses speed / direction you have at the point of transformation to direct balloon / determine speed.
3) Same timer as Tanooki's statue.
4) While ballooned, gains upward momentum if bouncing off stompable enemies.

*Super Boot developed and programmed by BlueFinch.
*Super Flight ported to SMB3 by BlueFinch, developed by Nintendo for the Mario Maker franchise.
*Balloon Tanooki (Balooki) developed and programmed by BlueFinch.

------------------------------------------------
------------------------------------------------

2.3) Enemy Mods:
Lakitu Throws X Enemy (ASM):
Instead of throwing spiny eggs, Lakitu throws a certain enemy depending on the level he is used in.
Only used in one level here, where he throws paragoombas.

ParaBeetle (ASM) (CHR):
If a parabeetle spawns to the player's left, it is a fast green one.

Thwomps (ASM):
Hitboxes now edge-to-edge for added difficulty. 
This also, for some reason, helps the Kuribo boot land on Thwomp better. 
This alone was the original intent for this change.

Boom Boom (ASM):
Can have multiple Boom Booms in an arena. Last one gives the orb. 
Many changes to Boom Boom's functionality. 

------------------------------------------------
------------------------------------------------

2.4) Tile and Block Mods:
Slope Munchers (ASM) (CHR):
Used one of the slope types in Underground tileset to add some mini-munchers to the slopes!

Lava Height Adjustment (ASM) (CHR):
Changed the "hitbox" of lava to not be to the very top. This feels fair. Changed it visually to reflect this

Quicksand in Desert Tileset (ASM):
Quicksand normally appears in Hilly tileset. I added this functionality to an unused tile in the desert.

Additional Background Tiles (HEX):
There are several other instances of using unused / weird tiles / block generators for background adornment.



------------------------------------------------



3) CREDITS

General Credits:
	Nintendo
	Captain Southbird for the SMB3 Disassembly
	
	SMB3 Prime Discord for the amazing community.
	Many highly knowledgeable and skilled romhackers can be found here!

	TikTok for the thriving Mario 3 kaizo streaming community
	Including Dani El Master, Boonie Veteran, Berna Lark
	Retro Video Gamer, Newfie — The Mushroom Kingdom, and others.

 	Michael who invented and maintains Foundry and Scribe, the preeminent tools for Mario 3 hacking.

	Jesus Christ, Son of God, the author of life and all creation. 
	John 3:16-17, Acts 2:14-41, 2nd Peter 1:3-15



Playtesting Team:
	Boonie Veteran (TikTok / Twitch)
	Dani El Master (TikTok / Twitch)
	Wilson Penn (aka WiP) (Twitch)

	The playtesting team provided valuable live and recorded insights into
	what needed to be changed / improved / reconceptualized.

	Among all three of these playtesters, there is well over 40 hours of 
	gameplay and testing that has gone into the careful analysis of KKB1.

	Thank you all very much / Muchas gracias a todos ustedes


	
Tools:
	Notepad++
	The 'Captain Southbird' Disassembly of Super Mario Bros. 3 (NES)
	Foundry (Michael's Level Editor)
	Beneficii's Map Editor
	MESEN (Hex editor / Emulator)
	ASM 6502 Opcodes website reference for doing hex editing.

	All Mario-related tools available on Romhacking.net
