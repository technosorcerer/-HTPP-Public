This Ips was not made by me! This is the site I found the download: https://themushroomkingdom.net/smb3_lost.shtml 
Thanks for reading!