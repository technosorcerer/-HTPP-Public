Thank you for downloading my hackrom!

This is my second hack and it was very fun to make. Also, it's a kind of "sequel" to Tacos Bros.

If something it's wrong whit the hack, let me know.

Please, enjoy playing it!