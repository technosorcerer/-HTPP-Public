Bill Cosby's space Rape

hack of: Super Maruo
hacker: Masked X