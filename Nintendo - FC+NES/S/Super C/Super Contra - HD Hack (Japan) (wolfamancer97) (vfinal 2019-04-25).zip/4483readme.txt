Title Screen,text,font,graphics and a lot of colors edited.
This hack is for the japanese version of 'Super C' on the NES, which is called:
'Super Contra (Japan)', enjoy.
wolfamancer97 \m/.