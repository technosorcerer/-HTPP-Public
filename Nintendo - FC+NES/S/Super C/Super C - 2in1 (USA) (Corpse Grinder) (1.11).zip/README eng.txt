
---------------------------------------------------------------------------

	Contra 2in1 (U) [v1.11]

---------------------------------------------------------------------------

Changes:
	- various bugs have been fixed
	- various points have been improved
---------------------------------------------------------------------------

07.09.2025

---------------------------------------------------------------------------

	Contra 2in1 (U) [v1.0]

---------------------------------------------------------------------------

Changes:
	- two contras in 1
	- fixed some original bugs
---------------------------------------------------------------------------

Info:
	- the hack is based on super c, so some objects may not 
	create (in the first part there are 16 objects, in the second - 14)
---------------------------------------------------------------------------

Hacking by:
	Corpse Grinder - programming and all stuff
	DimelNEX - initiator, tester
	Hobbot - tester
	Mark - tester
	Ent_Pavel- tester
---------------------------------------------------------------------------

For questions, please contact us here:
	discord - https://discord.gg/Hhh5Hxy3SJ
	telegram - https://t.me/+tWMWVtus3lViNTcy
---------------------------------------------------------------------------

Donate:
	donatepay - https://new.donatepay.ru/@corpse_grinder
	paypal - corpsehumengrinder@gmail.com
---------------------------------------------------------------------------

04.09.2025