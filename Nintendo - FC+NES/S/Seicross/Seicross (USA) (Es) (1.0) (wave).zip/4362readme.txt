Seicross (NES)
Traducci�n al Espa�ol v1.0 (02/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Seicross (U) [!].nes
MD5: ff1432776bd87a128876546a22b0db57
SHA1: c2591a5d6dd1bb43218e90a045bee0d8f8a68235
CRC32: c0d823ed
40.976 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --