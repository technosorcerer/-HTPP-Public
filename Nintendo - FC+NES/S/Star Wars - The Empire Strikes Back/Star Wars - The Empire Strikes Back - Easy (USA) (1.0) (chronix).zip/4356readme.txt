Star Wars - The Empire Strikes Back Easy (NES)

Hacked by Andrei Vdovin a.k.a. Chronix
chronix@bk.ru

* First level isn't slippery.
* Cold water doesn't kill Tauntaun instantly.
* Luke can be moved left or right while falling down.
* Some enemies and bosses have less power and less hitpoints.

Original ROM:
-----------------------
Star Wars - The Empire Strikes Back (U) [!p].nes
File size: 524 304

 PRG ROM:   16 x 16KiB
 CHR ROM:   32 x  8KiB
 ROM CRC32:  0x240de736
 ROM MD5:  0x9f8286fb3cb61583bfc92c82d848e5d9
 Mapper #:  4
 Mapper name: MMC3
 Mirroring: Horizontal
 Battery-backed: No
 Trained: No