
SQOON - Debarnacled v1.0
graphics hack (and a little bit more)
🚢
by iridium_ionizer 
(released 17 Sep 2023)


⚓Introduction⚓
-----------------

Sqoon stands apart from other shoot 'em up (or shmup) games on the NES for a few reasons. First, this game has an aquatic theme. Second, this game has a rescue mechanic (which was employed by previous games such as Defender and Choplifter but only for extra points). In this game when you rescue 9 humans and take them to an allied watercraft on the surface, after they climb aboard (by the player repeatedly pressing the B button) the watercraft will drop a gun upgrade item. 

Third, there is an alternate fire or bombing mechanism (which had previously appeared in Xevious) that fires diagonally down (B button) and can defeat some enemies which are impervious to the regular forward attack projectile (A button). The bombing mechanism is balanced by a slower rate of fire and the fact that it does not work when you are near the surface. Fourth, there is a fuel mechanic (previously seen in River Raid) by which a player must destroy a crab with a bomb, get the resulting item drop before the crab respawns, and then go to the surface to the allied watercraft, and grab the different fuel item drop coming from the allied watercraft. Alternately the player fuel is also replenished when they get the gun upgrade. 

Some players might not like the fuel mechanic or the resue / gun upgrade mechanic, but in my opinion they all work together to make this a complex and unique shmup game for the NES. But I will admit that it is a lot to keep track of for a beginner shmup player, especially with only 3 lives. 

--

This hack intends to clean up the graphics so they are easier to identify (especially the power-ups) and better match the aquatic theme. Most of graphics were left unmodified because of their higher quality. The mermaid is censored for less controversial play around children. The introductory text is altered to clarify the merfolks' motivations and also to clarify your mission. 

-- 

There are still some problems with the base game, specifically frequent screen flashes, lack of autofire, and slightly too long of a time to load your rescued humans onto the allied watercraft. 


🧜Patching Information🧜
--------------------------
Database match: Sqoon (USA)
Database: No-Intro: Nintendo Entertainment System (v. 20210216-231042)
File SHA-1: 4F1D13418ADABCC8B96CBA6B2DE7CF75F6917289
File CRC32: A3815BAC
ROM SHA-1: D2327AC8751BA04B09E420B6E259BA21B3FFFF81
ROM CRC32: 44F34172

• Use LunarIPS.exe (or similiar program) apply the file Sqoon (USA) - Debarnacled v1.0.ips to the appropriate rom file. 

• Use the Separate Folder to apply different individual patches. 

• Use the Sqoon (USA) - decensor.ips to decensor the mermaid but keep the other altered graphics. 


🐟Graphics Notes🐟 
----------------------------
- changed opening story text
- changed old man's face sprites
- improved ground texture
- changed crab's square into a square with an "F" for Fuel
- changed fuel drop into a circle with an "F" for Fuel
- changed gun upgrade power-up into a circle with a "G" for Guns
- improved allied watercraft (for refuel / gun power-ups) sprites
- improved improved angler fish sprites
- improved sea turtles sprites
- changed weird symbol into star fish
- changed floating spikes (urchins?) into jelly fish
- changed strange skeleton enemy into skeleton fish
- censored mermaid's nipple with bikini top and fixed tail (a decensor patch is included)
- changed mermaid's title screen palette. 
- changed cross necklace to anchor necklace
- slightly altered Sqoon submarine

- default cheats: 15 lives and don't lose humans upon death (it seems like this cheat only works when the player has the base gun, not an upgraded gun)


🦑🦐Hacking Notes🧜🐙 
----------------------------
Graphics modified using Tile Layer Pro v1.1
Animation visualizations using Aesprite v1.2.25-x64
Text and Lives modified using FCEUX v2.2.3
Don't Lose People Hack using Game Genie Guy v20150313

Extra Lives: 
x000BCD:    02  -->  08
RAM  $00002F


Never lose humans on dying
GXEAKKSE + GXSUZXSE
GXSUZXSE - 32EA:8D:2C
GXEAKKSE - C94:8D:2C


8D=STA -- ABSOLUTE
2C=BIT -- ABSOLUTE = test bits in memory with accumulator

RAM  $0005A7
