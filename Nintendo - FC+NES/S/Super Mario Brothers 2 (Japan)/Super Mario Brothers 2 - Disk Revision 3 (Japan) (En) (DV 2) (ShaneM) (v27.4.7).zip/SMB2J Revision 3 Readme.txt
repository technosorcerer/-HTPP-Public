sm2main  = 32768 bytes
sm2data2 = 3631 bytes    Memory = C470
sm2data3 = 3279 bytes    Memory = C5D0
sm2data4 = 3916 bytes    Memory = C2B4


Build #3
-Worked on sm2data3.asm and finished optimizing code but not level data
-Added high score saving after finishing World 8 and D (but not stars for the latter)

Build #4
-Fixed platform screen loop glitch
-Fixed upside-down pipe entry glitch
-Fixed Blooper collision with big Mario on ground
-Player starts off with 5 lives like in SMAS
-Live cap set to #19 (as originally intended)

Build #5
-optimized code
-added SFX for Flying Cheep-Cheep and Podoboo

Build #6
-Fixed upside-down pipe entry glitch (take 2)
-Fixed block buffer code with invisible block glitch (SMAS)
-Fixed moonwalking Koopa with Firebar glitch (SMAS)
-Fixed Spiny Egg glitch
-Adjusted Hard World to match SMAS version
-Adjusted Big Mario Firebar collision (like SM35)
-Made shooting fireballs pause when player takes damage (like SM35)
-Fixed crouching Mario then swimming and not shooting fireballs glitch
-Optimized code

Build #7
-Fixed platform collision on bonus stages
-Fixed vine of the dead glitch
-Fixed small fiery Mario glitch
-Fixed death when entering pipe and getting hit with hammer
-Fixed "Thank you dead Mario" glitch
-Fixed Starman kills fanfare glitch
-Fixed inside the enemy glitch
-Gave Mario/Luigi unique fiery palettes
-Fixed award timer 999 seconds glitch on X-4 stages
-Adjusted death by hole to set master timer control (like in SMAS)
-Fixed the demo action glitch if trying to load hard worlds
-Fixed hammer immunity glitch
-Finished correcting second part of crouching while swimming fireball glitch
-Fixed the double jump glitch
-Fixed "Mario Cooperfield" glitch
-Fixed hammer double death jingle
-Fixed enemy too low shell float glitch
-Fixed Goomba double death glitch
-Fixed sprite wraparound glitch
-Fixed "Powerful Wind" glitch
-Fixed skid sfx mute when wind sfx plays

Build #8
-Corrected Princess Toadstool's sprite in sm2char2
-Added beta cactus (Palette0_MTiles)

Build #9
-Finished adding beta ground tiles (Palette1_MTiles)
-Optimized palette data
-Revised X-4 end text data
-Added comma tile, star tile for sky and lava tile to sm2char1
-Added starry night data to Palette3_MTiles

Build #10
-Working stars at night finished
-Water/lava tiles finished to work underground and in castle type stages
-Water/lava palette data finished
-Day/night palette set for bonus stage used on 2-1, 3-1 and 4-1
-Optimized levels 1-1 through 4-4 and all bonus rooms in between
-Adjusted Podoboo jump height to match SNES version
-Added render all ground terrain with 3-D blocks
-Added sfx for jumpspring
-Added sfx for hammer object
-Added sfxs for loop pass correct/incorrect
-Added sfx for Lakitu tossing Spinys
-Fixed coin cancel powerup on B-3
-Fixed the balance platform glitch fest
-Adjusted upsidedown Piranha Plant boundbox data "BoundBoxCtrlData:"
-Fixed floatey number wraparound glitch

Build #11
-Added vine climbing (up) sfx
-Adjusted Bowser rightward movement toward axe
-Optimized sm2char1
-Removed Piranha Plant extra stem frame and optimized Bowser sprite
-Optimized levels 5-1 through 9-4 and all bonus rooms in between
-Optimized levels A-1 through D-4 and all bonus rooms in between
-Finished proofing worlds 1-4
-Finished proofing worlds 5-9
-Optimized data
-Finished proofing worlds A-D
-Reverted Upside-Down Piranha boundbox

Build #12
-Fixed Flying Paratroopas' hard mode speed when demoted
-Fixed stunned enemy's revival facing direction
-A-3 Cheep Cheep ending fixed

Build #13
-Corrected the jumpspring palette on World B

Build #14
-Corrected Game Over 'Quit' text

Build #15
-Corrected reverse 'L' pipe tiles in sm2char1
-Optimized code/data
-Fixed demoted Red Flying Paratroopas walking off edge
-Improved player-to-hammer collision code

Build #16
-Fixed vine climbing tile collision when triggering a powerup item and vine active (3-1 & 8-2)
-Adjusted the wind to stop when an enemy kills the player
-Adjusted Upside-Down Piranha Plant boundbox data
-Colorized 7-3 and C-3

Build #17
-Fixed vine climbing tile collision when triggering a powerup item and vine active (8-3)
-Adjusted bush level data on 8-1

Build #18
-Removed cloud breakoff on 1-3
-Added shadow to Bowser's spikes in sm2char1

Build #19
-Fixed cloud cutoff on A-3
-Corrected Podoboo interval timer

Build #20
-Corrected level inconsistencies in SM2MAIN
-Corrected level inconsistencies in SM2DATA2
-Corrected level inconsistencies in SM2DATA4

Build #21
-Adjusted the enemy hitbox to not take damage when player hits from beneath
-Adjusted player's Y speed when taking damage and going downward

Build #22
-Adjusted fiery Mario/Luigi time up palette to standard palettes (like in SMAS & SMB Deluxe)
-Adjusted Piranha Plant stems to be completely visible (like in SMB Deluxe)

Build #23
-Added eyes to Fire Flower
-Adjusted scenery on 5-1

Build #23.1
-Freed up some space

Build #23.2
-Made the player power down like in Super Mario 35
-Ups the player's status to big and fiery regardless of current status when grabbing Fire Flower
-Fixed SM2DATA3.asm byte alignment
-Corrected 5-1 warp zone area clouds and 8-2 shrub scenery
-Corrected various issues with SM2DATA3 and World 9 data on SM2MAIN
-Corrected scenery on SM3DATA3 World 9 levels
-Reverted World D-4 outdoors scenery portion

Build #23.3
-Fixed World A-D enemy load bug
-Fixed 4-1 bush cutoff
-Fixed 9-2 scroll stop

Build #24
-Lives cap to 99 lives

Build #25
-Fix max score code

Build#25.1
-Fixed 9-2 ending level data

Build#25.2
-Optimized code

Build#25.3
-Added Title screen music
-Optimized code
-Fixed jumping when initiating a new screen (new fix for "Mario Cooperfield" glitch)
-Fixed player walking animation when sometimes entering pipes to always crouch

Build#25.4
-Made Starman always bounce up when coming out of block
-Optimized wind code

Build#25.5
-Optimized the star invincibility timer at flagpole

Build#25.6
-Optimized double jump fix
-Fixed powerup theme playing right before 1UP Mushroom from block

Build#25.7
-Fixed an endless loop caused by the double jump refix
-Optimized sprite shuffler code

Build#25.8
-Refixed pulley platform fix
-Improved player crouching while entering pipe

Build#25.9
-Made use of residual powerup grab data

Build#26
-Fixed mushroom powerup jump if star is canceled by powerup
-Changed the lives cap to 100, making 100 lives have double crown sprites
-optimized vertical pipe entry and flagpole routine code
-optimized more code
-Added my initials

Build#26.1
-Redid balance platform fixes
 *invisible platform
 *wrong enemies being loaded into platform code
 *values not being cleared
-Optimized more code
-Moved my initials and build time to sm2data4

Build#26.2
-Improved area music envelope data (from Vs. SMB)
-Fixed the Flagpole not lowering glitch
-Readded fix for Bullet On A String glitch
-Fixed flagpole softlock "FlagpoleRoutine" where code wasn't residual
-Used Player X coordinate rather than OAM for Firbar collision
-Small graphical tweaks to Buzzy Beetle, its shell and Hammer Bros.

Build#26.3
-Improved Hammer Bros. code to fix minor glitches
-Optimized more code

Build#26.4
-Optimized code for faster program
-Made frenzy Bullet Bills more consistent with cannon ones with enemy collision
-Corrected 2-3 level data at the beginning to match original
-Blank tiles ($fc) are now kept offscreen to ease the 8 sprites per scanline limit
-Improved the vine climb code fix for if powerup is spawned over vine
-Improved floatey number wraparound fix
-Added check to offscreen bounds to see if the enemy is active first, to prevent enemies from being erased twice.
-Fixed Lakitu respawn bug if end enemy frenzy object is activated
-Corrected easy world Lakitu's initial Y position to be consistent (as later installments)

Build#26.5
-Optimized code
-Adjusted jumping Green Koopa Paratroopa to SMB Deluxe horizontal speed
-Added SFX for hitting an enemy beneath a block like in SMB Deluxe
-Adjusted flagpole slide positioning to that of SMAS
-Used timer tick SFX for flying Cheep-Cheep and enemy stomp SFX for Podoboo
-Undid 8 scale line OAM trick
-Corrected a missing pixel with player's super form fist when jumping
-Corrected level data at the end of 7-2
-Corrected green Paratroopa data for 2-3
-Fixed padding issue with SM2DATA3
-Corrected Red Koopa turning glitch where it kept changing directions on a platform edge when player dies on Hard Mode

Build#26.6
-Optimized code
-Fixed floatey number wrap from hitting coin blocks leftmost or bricks with coins above
-Fixed coin wrap from hitting multi coin block in bonus rooms on 5-1 & 7-1
-Fixed brick chunks not spawning if brick partially hidden offscreen (leftmost)
-Undid music envelope enhancement

Build#26.7
-Optimized code
-Fixed fireball bouncing over pit glitch
-Fixed fireball explosion OAM wraparound glitch

Build#26.8
-Optimized code for a faster program
-Fixed an incorrect value in "CoinBlock:" code
-Corrected blocks at end of 3-2 & 6-2 underwater section
-Corrected Koopa Paratroopa enemy position on C-1

Build#26.9
-Optimized code for a faster program
-Fixed Hammer Bros. shell collision glitch (SMAS)
-Improved floatey number wraparound fix

Build#26.9.1
-Cleaned up loop data code
-Added clearing PlatformCollisionFlag from EraseEnemyObject (SMAS)
-Corrected fire shooting GFX to have proper frames when jumping/swimming (like SMAS)
-Corrected head collision data value for when hitting block right below status bar
-Fixed high player air bounce from clipping an enemy at an angle (like a green leaping Paratroopa)

Build#26.9.2
-Corrected error in air bounce fix

Build#26.9.3
-Corrected out-of-bounds Red Koopa Troopa on A-1
-Added BG collision to Jumping Green Paratroopa like in SMB Deluxe
-Optimized code

Build#26.9.4
-Corrected Spinys getting stuck in BG on 9-2

Build#26.9.5
-Optimized code
-Added underwater enemy collision as in SMB Deluxe GBC
-Made bubbles stop moving when player is offscreen/dead (like SMAS)
-Corrected a glitch by wrong branching in "DrawBubble:"
-Made question blocks breakable underwater on 9-1 (like SMB Deluxe GBC)
-Fixed bug in "ContinueOrRetry:"
-Optimized fix for Spinys on 9-2
-Implemented fix for B-1, C-3 and D-2 jumpsprings
-Improved timing of playing SFX by hammers thrown

Build#26.9.6
-Optimized code
-Made duplicate vine enemy flag to erase upon going offscreen, thus making room for more enemies in the buffer

Build#26.9.7
-Optimized code
-Proofread ASM files

Build#26.9.8
-Optimized code
-Redid castle award timer points underflow fix
-Adjusted Green Piranha Plant range data (GBC)
-Changed 3-1 scenery according to SMAS

Build#26.9.9
-Optimized code (and fixed a few errors with last optimization)
-Allow multiple powerups on screen at once

Build#27
-Optimized code
-Corrected powerups being overwritten by vine on 3-1, 8-2 and 8-3

Build#27.1
-Awards 1000 pts. to defeated Hammer Bro. by shell defeat (SMAS)

Build#27.2
-Awards 0 pts. to "defeated" Podoboo by shell "defeat" (fix)

Build#27.2.1
-Code optimization for faster program

Build#27.2.2
-Code optimization

Build#27.3
-Fixed short vine object on stages like 4-1 where they'd ghost on a new screen and play vine grow SFX again

Build#27.4
-Optimized code
-Fixed the walljump glitch
-Fixed wall clipping from leftmost of the screen
-Reverted loop command data organization to fix bug
-Redid floatey number wraparound glitch fix

Build#27.4.1
-Improved wall clipping fix code
-Fixed master timer control glitch with axe and set an amount for invincibility timer if player took damage
-Improved walljump fix code

Build#27.4.2
-Optimized code
-Redid fix for making all powerups come out right when leaving boxes (including stars)
-Fixed walljump code value

Build#27.4.3
-Undid walljump fix
-Optimized code

Build#27.4.4
-Fixed walljump & other feet collision codes
-Made small player still be able to move left/right while pressing down (like SMB Deluxe)
-Fixed catching powerup before it spawns glitch (corrected side collision code)
-Optimized code

Build#27.4.5
-Optimized code
-Remove ImpedePlayerMovement for side platforms (like SMB Deluxe)
-Fixed low gravity Mario glitch
-Properly fixed out-of-bounds Red Koopa Troopa glitch

Build#27.4.5.1
-HOTFIX Low gravity Mario glitch fix added underwater check
-Optimized code for a faster program

Build#27.4.5.2
-Optimized code last time for a faster program

Build#27.4.5.3
-Proofread code
-Added back RTS to "CheckSfx2Buffer:"

Build#27.4.5.4
-HOTFIX Improved the side collision code to be more vanilla


Build#27.4.5.5
-HOTFIX Clear player star invincible timer upon time up
-Changed line 1413 from BNE to JMP for a faster program

Build#27.4.5.6
-HOTFIX Adjusted underwater current on 6-2
-HOTFIX Removed cloud over poison mushroom on D-1

Build#27.4.5.7
-HOTFIX Fixed broken enemy fall code since build #7
-Optimized code for faster program (line 6531)

Build#27.4.5.8
-Fixed a Nintendo original glitch with Hammber Bros. sometimes jumping through solid ground to defeat (8-1)

Build#27.4.5.9
-HOTFIX Fixed glitch with multi path SFX
-Reverted breakable blocks in Fantasy World
-Optimized code for a faster program

Build#27.4.5.9a
-Corrected Fantasy World flagpole animation to omit swimming frames when sliding like SMAS
-Optimized code for a faster program

Build#27.4.5.9b
-Adjusted walljump fix right data value

Build#27.4.5.9c
-Optimized code for a faster program
-Corrected underwater currents pushing player through blocks
-Modified player not being able to stand on vertical platforms underwater (like SMB Deluxe)
-Cleared injury timer upon time up to correct player still flashing
-Added limit to vertical whirlpool suction force
-Improved underwater vertical platform to player collision to act like they do in SMB Deluxe GBC
-Corrected current on B-2
-Corrected maximum vertical swim height to not come out of water
-Proofread code

Build#27.4.5.9d
-Corrected loading hard worlds while in demo in rare instances
-Corrected occurrences of sound freezing when switching to hard worlds

Build#27.4.5.9e
-Optimized code
-Improved platform side collision to match SMB Deluxe GBC
-Proofread code

Build#27.4.5.9f
-Optimized code
-Corrected screen time transition to be consistent (only for when pipe intros load)
-Optimized screen scrolling to not run when master timer control set (also corrects issue with dying on moving platform)
-Proofread code

Build#27.4.6
-Optimized code
-Corrected Podoboo SFX from playing twice upon loading
-Proofread code

Build#27.4.6.1
-Optimized code in SM2DATA3
-Moved Podoboo SFX to before JSR to InitPodoboo
-Made the player become super if small before princess scene on 8-4 & D-4
-Corrected enemy data on 8-2
-Corrected level data for whirlpool at 6-2 end
-Fixed a pause glitch before SM2DATA3 loads
-Fixed a glitch with event music not being cleared before return to title screen after saving
-Improved fix for side platform player-wall collision

Build#27.4.6.2
-Optimized code
-Fixed data offset error
-Proofread code

Build#27.4.6.3
-Improved upside down Piranha Plant bounding box in SM2DATA4


Build#27.4.6.4
-Further corrected pause SFX issue at princess door scene
-Optimized code on SM2DATA3

Build#27.4.6.5a
-Again corrected pause SFX issue at princess door scene
-Fixed OG broken whirlpool on 6-1 water portion

Build#27.4.6.5b
-Again corrected pause SFX issue at princess door scene (verified fix)

Build#27.4.6.5c
-Adjusted OW pausing to match SMB Deluxe

Build#27.4.6.5d
-Proofread code
-Cleaned up code

Build#27.4.6.5e
-Proofread code
-Optimized code

Build#27.4.6.5f
-Proofread code
-Optimized code in SM2DATA2 and SM2DATA4

Build#27.4.6.5g
-Improved Lakitu respawn oversight and cleaned up TimeUpOn code
-Added comma to Thank You player message at the end of victory scene

Build#27.4.6.5h
-Proofread code
-Corrected 8-1 underwater castle tiles oversight by Nintendo

Build#27.4.7
*Final Build - SM
-Proofread code
-Optimized code for a faster program
-Corrected pixel on big Mario/Luigi's shoe sticking outside pipe when entering sideways pipe
-Corrected big Mario/Luigi to continue crouching when falling if already crouching (like SMB Deluxe)