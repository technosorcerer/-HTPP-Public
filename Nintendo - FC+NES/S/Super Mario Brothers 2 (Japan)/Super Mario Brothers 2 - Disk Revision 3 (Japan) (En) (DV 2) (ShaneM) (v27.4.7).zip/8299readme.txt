Readme
------
Super Mario Bros. 2: The Lost Levels (Disk Revision #3)
Build#27.4.6.5h

This is a bugfix version of SMB2J that corrects pretty much every known glitch.
There is no such thing as a perfect game but this comes close.
There is currently 1 known revision of SMB2J released by Nintendo that corrects loading code.
This version is based off and builds on that one.
There shouldn't be any issues with this game but please reach out to me on the forums if something arises. -ShaneM

Included are two patches. The headered patch includes the dummy bytes used on an actual disk (65,536 bytes).

ROM/patching info:
Database match: Super Mario Brothers 2 (Japan) (En) (DV 2)
Database: No-Intro: Famicom Disk System (v. 20210111-132854)
File SHA-1: 0A2397F6C99FB2356A77E03EE032F8EEDF2845C3
File CRC32: AB7652B7
ROM SHA-1: 08927227B6FF67F42E759505D176CD924931BD14
ROM CRC32: 5C419EE8

-Added high score saving after finishing World 8 and D (but not stars for the latter)
-High score capped at 9,999,990
-Optimized code in program to run faster, save on cycles and save on PRG
-Fixed player walking animation when sometimes entering pipes to always crouch
-Added Title screen music
-Fixed platform screen loop glitch
-Fixed upside-down pipe entry glitch
-Fixed Blooper collision with big Mario on ground
-Player starts off with 5 lives like in SMAS
-Live cap set to #100 (Double Crown after 99)
-Adjusted upsidedown Piranha Plant boundbox data "BoundBoxCtrlData:"
-Fixed floatey number wraparound glitch
-Added SFX for Flying Cheep-Cheep, Podoboo, jumpspring, Hammer Bros., castle oop pass correct/incorrect, Lakitu tossing Spinys, vine climbing (up)
-Added SFX for hitting an enemy beneath a block like in SMB Deluxe
-Fixed coin cancel powerup on B-3
-Fixed block buffer code with invisible block glitch (SMAS)
-Fixed moonwalking Koopa with Firebar glitch (SMAS)
-Fixed Spiny Egg glitch
-Adjusted Hard World to match SMAS version
-Adjusted Big Mario Firebar collision (like SM35)
-Made shooting fireballs pause when player takes damage (like SM35)
-Fixed crouching Mario then swimming and not shooting fireballs glitch
-Fixed platform collision on bonus stages
-Fixed vine of the dead glitch
-Fixed small fiery Mario glitch
-Fixed death when entering pipe and getting hit with hammer
-Fixed "Thank you dead Mario" glitch
-Fixed Starman kills fanfare glitch
-Fixed inside the enemy glitch
-Gave Mario/Luigi unique fiery palettes
-Fixed award timer 999 seconds glitch on X-4 stages
-Adjusted death by hole to set master timer control (like in SMAS)
-Fixed the demo action glitch if trying to load hard worlds
-Fixed hammer immunity glitch
-Fixed the double jump glitch
-Fixed "Mario Cooperfield" glitch
-Fixed hammer double death jingle
-Fixed enemy too low shell float glitch
-Fixed Goomba double death glitch
-Fixed sprite wraparound glitch
-Fixed "Powerful Wind" glitch
-Fixed skid sfx mute when wind sfx plays
-Corrected Princess Toadstool's sprite
-Added beta cactus scenary and beta ground tiles (underground/underwater)
-Revised X-4 end text data like SMB Deluxe
-Added stars to night sky
-Added separate water/lava tiles (lava tiles set to work underground and in castle type stages)
-Adjusted Podoboo jump height to match SNES version
-Adjusted Bowser rightward movement toward axe
-Removed Piranha Plant extra stem frame and optimized Bowser sprite
-Corrected the jumpspring palette on World B (like SMAS)
-Corrected Game Over 'Quit' text
-Fixed demoted Red Flying Paratroopas walking off edge
-Improved player-to-hammer collision code
-Corrected reverse 'L' pipe tiles
-Fixed vine climbing tile collision when triggering a powerup item and vine active (3-1, 8-2 & 8-3)
-Colorized 7-3 and C-3 (like SMAS)
-Adjusted the wind to stop when an enemy kills the player (like SMAS)
-Adjusted the enemy hitbox to not take damage when player hits from beneath
-Adjusted player's Y speed when taking damage and going downward
-Adjusted fiery Mario/Luigi time up palette to standard palettes (like in SMAS & SMB Deluxe)
-Adjusted Piranha Plant stems to be completely visible (like in SMB Deluxe)
-Added eyes to Fire Flower
-Made the player power down like in Super Mario 35
-Ups the player's status to big and fiery regardless of current status when grabbing Fire Flower
-Fixed World A-D enemy load bug
-Fixed consistency of scroll stops and various level scenary
-Made Starman always bounce up when coming out of block
-Optimized the star invincibility timer at flagpole
-Fixed powerup theme playing right before 1UP Mushroom from block
-Improved player crouching while entering pipe
-Made use of residual powerup grab data
-Fixed mushroom powerup jump if star is canceled by powerup
-Redid balance platform fixes
 *invisible platform
 *wrong enemies being loaded into platform code
 *values not being cleared
-Fixed the Flagpole not lowering glitch
-Readded fix for Bullet On A String glitch
-Used Player X coordinate rather than OAM for Firbar collision
-Small graphical tweaks to Buzzy Beetle, its shell and Hammer Bros.
-Improved Hammer Bros. code to fix minor glitches
-Made frenzy Bullet Bills more consistent with cannon ones with enemy collision
-Added check to offscreen bounds to see if the enemy is active first, to prevent enemies from being erased twice.
-Fixed Lakitu respawn bug if end enemy frenzy object is activated
-Corrected easy world Lakitu's initial Y position to be consistent (as later installments)
-Adjusted jumping Green Koopa Paratroopa to SMB Deluxe horizontal/vertical speed
-Adjusted flagpole slide positioning to that of SMAS
-Corrected a missing pixel with player's super form fist when jumping
-Corrected Red Koopa turning glitch where it kept changing directions on a platform edge when player dies (Hard Mode A-D)
-Fixed floatey number wrap from hitting coin blocks leftmost or bricks with coins above
-Fixed coin wrap from hitting multi coin block in bonus rooms on 5-1 & 7-1
-Fixed brick chunks not spawning if brick partially hidden offscreen (leftmost)
-Fixed fireball bouncing over pit glitch
-Fixed fireball explosion OAM wraparound glitch
-Fixed Hammer Bros. shell collision glitch (SMAS)
-Added clearing PlatformCollisionFlag from EraseEnemyObject (SMAS)
-Corrected fire shooting GFX to have proper frames when jumping/swimming (like SMAS)
-Corrected head collision data value for when hitting block right below status bar
-Fixed high player air bounce from clipping an enemy at an angle (like a green leaping Paratroopa)
-Added BG collision to Jumping Green Paratroopa like in SMB Deluxe
-Corrected Spinys getting stuck in BG on 9-2
-Added underwater enemy collision as in SMB Deluxe GBC
-Made bubbles stop moving when player is offscreen/dead (like SMAS)
-Implemented fix for B-1, C-3 and D-2 jumpsprings
-Made duplicate vine enemy flag to erase upon going offscreen, thus making room for more enemies in the buffer
-Adjusted Green Piranha Plant range data (GBC)
-Allow multiple powerups on screen at once
-Awards 1000 pts. to defeated Hammer Bro. by shell defeat (SMAS)
-Awards 0 pts. to "defeated" Podoboo by shell "defeat" (fix)
-Fixed short vine object on stages like 4-1 where they'd ghost on a new screen and play vine grow SFX again
-Fixed the walljump glitch
-Fixed wall clipping from leftmost of the screen
-Fixed master timer control glitch with axe and set an amount for invincibility timer if player took damage
-Made small player still be able to move left/right while pressing down (like SMB Deluxe)
-Fixed catching powerup before it spawns glitch (corrected side collision code)
-Remove ImpedePlayerMovement for side platforms (like SMB Deluxe)
-Fixed low gravity Mario glitch
-Properly fixed out-of-bounds Red Koopa Troopa glitch (like A-1)
-Corrected Fantasy World flagpole animation to omit swimming frames when sliding (like SMAS)
-Optimized code for a faster program
-Corrected underwater currents pushing player through blocks
-Modified player not being able to stand on vertical platforms underwater (like SMB Deluxe)
-Cleared injury timer upon time up to correct player still flashing
-Added limit to vertical whirlpool suction force
-Improved underwater vertical platform to player collision to act like they do in SMB Deluxe GBC
-Corrected maximum vertical swim height to not come out of water
-Corrected loading hard worlds while in demo in rare instances
-Corrected occurrences of sound freezing when switching to hard worlds
-Corrected screen time transition to be consistent (only for when pipe intros load)
-Optimized screen scrolling to not run when master timer control set (also corrects issue with dying on moving platform)
-Made the player become super if small before princess scene on 8-4 & D-4
-Fixed a pause glitch before SM2DATA3 loads
-Adjusted OW pausing to match SMB Deluxe
-Fixed a glitch with event music not being cleared before return to title screen after saving
-Added comma to Thank You player message at the end of victory scene
-Corrected 8-1 underwater castle tiles oversight by Nintendo