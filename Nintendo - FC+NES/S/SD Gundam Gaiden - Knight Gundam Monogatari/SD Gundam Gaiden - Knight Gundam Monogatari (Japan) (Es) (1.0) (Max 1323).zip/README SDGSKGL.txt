"SD Gundam Story: Knight Gundam Legend"
Traducción al Español Ver. 1.0 (31/05/2024)
por Max1323 (Traducciones Max1323).
Basada en la gran traducción de Stardust Crusaders y aishsha.
---------------------------------------------------
Descripción:
En una galaxia lejana, había un pacífico mundo llamado Saddrac.
Pero una sombra ha caído en ese mundo, este era Satan Gundam.
El rey de Lacroix llamó a un héroe, a Knight Gundam para salvar a su hija y a este mundo.
Y así comienza la historia...

Desarrollado: TOSE
Publicado:    Bandai
Lanzamiento:  11/08/1990 (JAP)
---------------------------------------------------
Acerca del proyecto:
- La traducción fue hecha gracias a aishsha, Pennywise, KingMike, blipform, TheMajinZenki, Ryusui, FlashPV, OMorty, cccmar, y Xanathis.

-La mayoría de los textos están traducidos. Se agregaron
los caracteres españoles a excepción de algunas Mayúsculas 
por temas de la fuente.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS (PC)
Utilizar UniPatcher (Android)
Utilizar Rom Patcher JS (Parcheador Online):
https://www.romhacking.net/patch/

Archivo IPS
SD Gundam Gaiden - Knight Gundam Monogatari (Japan).nes
File Size     384 KB
File MD5      B6A052296F60D94903DB6277FC267A62        
File SHA-1    100767E59CABFF7575FD5A2CE4D5FD67102384FC
File CRC32    A6D80B60