A hack of Short Order/Eggsplode where you feed animals shit sandwiches and run your hands through luscious 8 bit grass.

Break out a Powerpad and get to touchin'!


Patch to Short Order + Egg-Splode! (USA).nes