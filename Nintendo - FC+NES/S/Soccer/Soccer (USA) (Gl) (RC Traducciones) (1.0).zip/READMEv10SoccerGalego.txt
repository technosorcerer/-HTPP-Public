////////////////////////
/                      /
/       SOCCER         /
/                      /
/ Galician translation /
/                      /
////////////////////////


( 1. MAIN INFO
(( 2. VERSION HISTORY
((( 3. LINKS



( 1. MAIN INFO
------------------------------
This translation to galician language was made by Manuel Riguera for "RC Translations",
part of "La Retrocaverna".

This patches the original Nintendo NES European PAL version game rom "SOCCER"
to galician language.



(( 2. VERSION HISTORY
------------------------------
v1.0 22 JUL 2014
Every text translated.



((( 3. LINKS
-------------------------------------------------
WEB: http://laretrocaverna.es
YOUTUBE: https://www.youtube.com/c/laretrocaverna
