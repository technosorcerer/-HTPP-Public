- Replaced music and sound effects (taken from the 1943 game).
- Different music is selected for different levels, and there is also a boss theme.
- Fixed loading the level during scrolling from the original, 
now there is no sharp change in the top row of tiles on the screen.