1942
Traducci�n al Espa�ol v1.0 (20/04/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre 1942
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre 1942
-----------------
Arcade de aviones port de recreativa.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
1942 (JU) [!].nes
40.976 bytes
CRC32: e9cf747f
MD5: 4f90905fd77c1c9456bd5dfe1ceddc34
SHA1: dfb068f72e9eb44e8dbdb181c235da6ccf6fb4bc

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --