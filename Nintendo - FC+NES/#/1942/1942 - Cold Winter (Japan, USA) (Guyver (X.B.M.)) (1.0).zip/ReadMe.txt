Description:
In this hack I have changed the levels, palette, the amount of lives (25 lives), the amount of rolls (25 rolls) and game logo.

ROM / ISO Information:
1942 (JU) [!].nes - GOODNES 3.14
CRC32: E9CF747F
MD5: 4F90905FD77C1C9456BD5DFE1CEDDC34
SHA-1: DFB068F72E9EB44E8DBDB181C235DA6CCF6FB4BC

My NES hacks: http://famicom.byethost7.com