Hack Name: 1919
A Hack Of: 1942.nes
Hacked By: Me_Dave
email: Klowner@myway.com
Website: http://meklowner.tripod.com/klownersromhackingpage/index.html


In 1919 we took a little trip across the great alantic, just to sink the titanic,am kidding that was 1912. And yes for all 
mistakes and purposes we know world war 1 ended in the 1918 (cease-fire), with the peace treaty signed on june 28 1919. But 
just maybe we ripped it up and America said it's thier turn to invade germany and stop hitler bofore he comes to power thus 
preventing world war 2 from ever happening. Yeah right but anyway it's a hack. I really would have liked to say that I used 
Matrixz's Schnapsidee program in the making of this hack but I don't know enough about how it works exactly, He didn't make 
it clear in the read me. I can't even tell how you exit the program let alone know how to use it. The specifics of it just 
are not there, So did every thing myself. Changed the palete's, The title sreen, misc gharpics, all in all it looks better 
than the original game 1942. The bad news is no one will ever play far enough into the game to see all that is changed. This
1942 is in dire need of some asm hacking. Also there are two versions of my hack Normal and Hard. The hard version gives you 
one life and 9 rolls, the reason for this is I thought why not see how many planes you can shoot down with one plane. The 
only side effect is it only works for one player if you select two players neither player will ever die even though both only 
have one life after getting shot down they just start over to play again, Continuing endlessly so I recommend not selecting 
two players while playing the hard version, that way you can die like normal and can find out how many planes you shot down.


What you need to play this hack an IPS patcher program I used Lunar IPS the rom 1942 (U) [!].nes one of the below patches.
1919Normal.ips the normal version with no bugs or known side effects
1919Hard.ips see above text for the detailed side effect.


That is it enjoy, I may write a document that could help others hack this game futher,like I have secret codes which I used 
in the making of this hack which enabled me to play through the entire game. And I also stumbled upon a few sound bytes not 
that I know what to do with them. The doc is my next project so the info will be avalible in the future if all goes well.

Have Fun....

And no it's not done in gray scale maybe next time, Why didn't I do that too damn it. lol

  

 
