Here it is 1493 - The Year After

A hack of 1943 The Battle Of Midway, it has a whole new story, new Title Screen, and some game code changes. The complete text changes include a Binary Code, A plot twist, and Religious Reference, plus has a new Fake Ending, a new Real Ending, and new After Ending texts.    

Your quest is to pursue and perhaps destroy Christopher Columbus as he Voyages to discover America, just as he departs on his 2nd voyage you enter from the Nes Time Warp to stop him. 

We will not tell the long back story of why this was Made, However the fact that Columbus never made a Final Voyage comes to mind. In addiction to the normal patch there is included the Time Warp patch that includes some distortion through the use of apparent glitches that are there because that is what it is suppose to do. Is Not a Bug..


Some text was not changed like the part used for the powering up of your Airplane seemed unreasonable to change, Also I would avoid Powerup's they will disable the cheat weapon that your airplane is already equipped with. If you shoot the power up enough eventually it'll stop changing and then you can collect it to regain power. 

I'm retiring from rom hacking at 37, or am taking a prolonged sabbatical from the hobby. Making this my Final Hack. I hope it is enjoyed.

BASE ROM

1943 - The Battle of Midway (USA).nes		No-Intro	iNES1.0 Header
1943 - The Battle of Midway (U) [!].nes		GoodNES


Rom ISO Info
No-Intro Name: 1943 - The Battle of Midway (USA)
1943 - The Battle of Midway (U) [!].nes
CRC32: 12c6d5c7 (Unheadered)***
MD5: 190d10a3685f87ba32135ac595283f36
SHA1: 1E76A86398F069DA43B25351EF419BE664D630C5




 




