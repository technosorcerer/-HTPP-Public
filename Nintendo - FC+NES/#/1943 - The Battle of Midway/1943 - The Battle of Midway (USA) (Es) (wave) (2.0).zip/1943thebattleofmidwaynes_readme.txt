1943 - The Battle of Midway (NES)
Traducción al Español v2.0 (07/12/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Añadidos caracteres españoles
-Guion retraducido

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
1943 - The Battle of Midway (USA).nes
MD5: deeaf9d51fc3f13f11f8e1a65553061a
SHA1: 443d235fbdd0e0b3adb1dcf18c6caa7eceec8bee
CRC32: d131bf15
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --