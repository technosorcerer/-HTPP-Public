Porco Rosso (Version 1.0)
by Supergamerguy
Art by Cryin Onion


Table of Contents:
1. How to patch
2. Changelog
3. Background Info
4. Tools Used
5. Explanation of changes






How to patch:
1. Download a patching program like Lunar IPS
2. Download 1943 - The Battle of Midway (USA).nes
3. Use patching program to apply "Porco Rosso Enhanced Edition.ips" to your
1943 NES ROM
4. Rename new file to whatever you want (Example: Porco Rosso Enhanced Edition)
5. Use a NES emulator like FCEUX or the FCEUMM core in Retroarch to play!






Changelog:

Version 2.0/Enhanced Edition
- Cryin Onion edited all large images/art, including a brand new 
title screen, powerup screen, password screen, and ending screen, 
all with beautiful new designs that fit my hack perfectly!

Version 1.0:
- Edited all Ending/Transition text and Finished "Good Ending
Cutscene"

Version 0.9:
- Finished all sprite edits and replaced most graphics





Background Info:
I wanted to make another Ghibli hack after my Castle in the Sky
project, and I wanted to do a hack that wasn't based on a 
platformer, and since the NES port of 1943 is one of the best
shoot-em-ups on the console (and is set close to the time period
where Porco Rosso takes place), I decided to make it happen!
I consider Porco Rosso to be one of the most underrated Ghibli
movies in their catalog and deserving of some love in modern day.

NOTE: This is my second ROMHACK, so I'm sure it's not perfect (I didn't edit any hitboxes so the 
sprites and the hitboxes might be a bit out of line).





Tools Used:
- FCEUX (NES emulator - used to test game and edit color pallettes)
- YY-CHR (used to edit most of the sprites and sprite layouts)





Explanations of changes:

Here's some clarifications of which planes, items, and enemies are 
changed and what they currently represent.

NOTE: This hack is set after Porco and Curtis' fight, but before
Fio's monologue at the end of the movie.

Main Plane Changes:
- P.38 Bomber: Porco's S.21 Savoia Plane

Item Changes:
- POW Item: PIG Item
- Shotgun Powerup: Porco's (sun)Glasses
- 3 Way shot Powerup: Wine Glass
- Machine-Gun-like Powerup: Old Bucket
- Missile Powerup: Wine Bottle
- Side Fighters (the ones that fly beside both wings of the plane):
Curtis' Plane
- Bamboo Sprout (leveling powerup): Small Wine Bottle (like the
one Fio drinks out of when she and Porco stop to get fuel)
- Yaschichi (Capcom's token pinwheel item - maximum energy 
replenishment): Fuel Barrel
- Big Energy Tanks: Bullet Cartridges
- Small Energy Tanks: Flower Boquet
- Holstein (cow item): a cartoonish Pig
- Star (partial energy replenishment): a (open) Cigarette Pack
- Barrel: Leather Suitcase
- Elephant: Apple
- Lucky Cat: Radio
- Dragonfly: Umbrella
- Mobi-chan (little spacesuit guy with gun): Money Bag (from the
bet between Porco and Curtis)


Enemy Changes:
- Regular Planes (the first ones you encounter): Italian Air Force
planes (similar to Ferrari's plane design)
- (Medium-sized) Black and Gray Plane: Metal Pirate Plane (the
shiny one that the Pirate Gang that handles the money in the 
Dogfight match flies, specifically the one from the top of this
image: https://images6.fanpop.com/image/photos/40700000/Porco-Rosso-Concept-Art-studio-ghibli-40763761-1129-1050.jpg).
- Big "Bombing Squadron" Plane: the Mamma Auito gang seaplane
(the green, camoflauged one)
- The Planes that the "Bombing Squadron" plane spits out: the Plane
from the cartoon black and white movie that Porco and Ferrari go to watch
(the one that the Rabbit flies).
- Spinning Planes (the ones that do corkscrews in the air): the 
Planes that have two cockpits under the large wings (can be seen
flying over Milan and with the Italian Air Force at the end of the movie).
- Smaller Bombers (the ones in the Idle Intro Cutscene and the ones
that sometiems dip below the line of fire when stationary): one of
the planes from a Pirate Gang (specifically the Green and Orange
one from the bottom of this image: https://i.pinimg.com/originals/f7/31/73/f73173436f60a20fe569381678606f29.jpg) 
- Jet-Engine-like Planes (the ones that fly in horizontally from
the sides of the screen): Security Planes from Cruise Ship (the
ones that protect the cruise ship from attack and the ones that
get shot down by Curtis, specifically the one from this image:
https://i.pinimg.com/originals/56/a2/2d/56a22dc1ce900818c6a5f9e9ff13fe9a.jpg)
- The Planes that will circle around the screen (some even seek
the character out, no matter where you are on the screen): Gina's
plane (her personal one that she flies in to the dogfight)
- Rocket Planes (the ones that corkscrew around and fly very fast
down the screen): WW1-styled Italian fighters (from Porco's war
flashbacks).
- Flat Winged Planes (with slanted wings, show up in level 16):
The Adriano (Marco and Gina's plane in Gina's flashback) 

- Boss Planes: a commandeered "Leisure Cruise" Plane (like the one
that Porco mistakes for the Mamma Auito gang seaplane, that's actually
full of women shouting his name). The "lore" behind this is that
higher ups in the Italian Air Force have taken control of a civilian 
plane and are using it to watch the upcoming battle from a safe distance.
***NOTE: Since the original sprite for the Boss Planes had 2 engines
per wing, and the new plane only has 1 per wing, a rickety crack
has been added in place of the second engine on both wings.


Other Changes:
- The Islands have been modified to reflect the lush, green islands
of the Mediterranean
- The Title Screen Logo is faithful to the original promotional 
art and includes a well made redention of Porco's face.
- The Small Logo on the Password screen now matches the Pirate Leader of the Mamma Auito Gang.
- The Cutscene image on the leveling screen now matches the scene 
where Piccolo charges Porco money for his plane repairs.
- The Idle Cutscene now adheres to the story given at the end of 
the movie (Fio's monologue), at least text wise.
- All dialogue and mission text has been edited to include lines
from the movie (from Porco specifically).
- The names of the Boss Planes and Ships have been changed to 
adhere to Italian naval and air force names, some even being 
historically accurate to the time period (right before WW2).
- The Final Cutscene Image (the fading photo) now matches the 
scene where Gina looks off into the distance, thinking about Porco. 