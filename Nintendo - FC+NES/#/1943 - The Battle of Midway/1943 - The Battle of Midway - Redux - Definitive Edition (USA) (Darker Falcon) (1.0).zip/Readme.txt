1943 - The Battle of Midway Redux/Definitive Edition by Darker Falcon:

1943 - The Battle of Midway is surely considered a massive improvement over 1942. Smoother gameplay, responsive controls, awesome music (thanks to Kumi Yamaga) and the new RPG-like power-up system is very interesting. It has some nipicks, but it's a blast to play!

This hack tries to make the already-great experience even better with the addition of the following hacks:

- UNROM to MMC3 Hack ver 1.0 by S. K. Dumbbus:

https://www.romhacking.net/hacks/7247/

Here is a Patch that will make 1943 work as MMC3 Mapper 4

--------------------------------------------------------------------------

- Update ver 1.0 by DamienC:

https://www.romhacking.net/hacks/714/

This hack of 1943 changes the ship names to those in the arcade version/real life, and also includes a re-written intro, “fake ending,” and ending that is loosely based on the actual Battle of Midway from World War II.

--------------------------------------------------------------------------

- Energy Decrease Rate Halved ver 1.0 by baochan120:

https://www.romhacking.net/hacks/6832/

Energy level and Special Weapon time remaining decrease at half the normal speed, making the game slightly easier.

Includes optional patches to only affect Energy or SW individually, and another to remove the automatic decrease of Energy entirely.

Note: the patches used here are the SW time decrease halved and the energy decrease removal.

--------------------------------------------------------------------------

- Rapidfire ver 1.0 by baochan120:

https://www.romhacking.net/hacks/4327/

Adds a moderate rapid-fire capability to the basic weapon and shotgun special weapon (”cheerios”). It is intentionally slightly less effective than the 3-way weapon’s rapidfire (one less bullet fired per button press), but much easier on the thumb than one bullet per press, and still allows charging of the laser while the gun is firing (which a rapidfire controller would not). This should make the game significantly easier.

--------------------------------------------------------------------------

- No Panic Music ver 1.0 by samspot:

https://www.romhacking.net/hacks/8298/

1943’s soundtrack is amazing, but quickly spoiled when you are below 20 energy and the warning music plays. This hack removes the warning music so you can enjoy Kumi Yamaga’s stage music without interruption.

Note: Wouldn't you want to deal with that annoying, ear-grating and repetitive warning music, do you?

--------------------------------------------------------------------------

Plus some addition I made exclusively in this hack:
- Restored game's title graphic with the subtitle from the Japanese Prototype version.
- Cleaned up some typos: "PASS WORD" to "PASSWORD" and "LICENCED" to "LICENSED"
- Changed Energy and SW stats values with Ti's 1943 stats editor (https://www.romhacking.net/utilities/1750/):
Energy Values (which indicates the maxinum energy you can have during gameplay):
L1: 64 -> 100
L2: 70 -> 120
L3: 80 -> 140
L4: 100 -> 160
L5: 120 -> 180
L6: 140 -> 200

SW Time Limit (which indicates the maxinum amount of time of your special weapon during gameplay):
L1: 60 (same as the original)
L2: 72 -> 80
L3: 84 -> 100
L4: 96 -> 120
L5: 108 -> 140
L6: 110 -> 160

--------------------------------------------------------------------------

You'll need a USA ROM to use this patch.

--------------------------------------------------------------------------

ROM / ISO Information:

Database match: 1943 - The Battle of Midway (USA)
Database: No-Intro: Nintendo Entertainment System (v. 20210216-231042)
File SHA-1: 443D235FBDD0E0B3ADB1DCF18C6CAA7ECEEC8BEE
File CRC32: D131BF15
ROM SHA-1: 1E76A86398F069DA43B25351EF419BE664D630C5
ROM CRC32: 12C6D5C7

--------------------------------------------------------------------------

Enjoy :)

DarkerFalcon