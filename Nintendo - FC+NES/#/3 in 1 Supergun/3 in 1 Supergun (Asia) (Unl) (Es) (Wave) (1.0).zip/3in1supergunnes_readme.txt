3 in 1 Supergun (NES)
Traducción al Español v1.0 (08/05/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
3 in 1 Supergun (Asia) (Unl).nes
MD5: 1bdeb2a534447cb18b32fe4bb136f09c
SHA1: 385d82b41049cacc4ec9cd2cec2259e962f7e6ce
CRC32: 3b95bc4e
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --