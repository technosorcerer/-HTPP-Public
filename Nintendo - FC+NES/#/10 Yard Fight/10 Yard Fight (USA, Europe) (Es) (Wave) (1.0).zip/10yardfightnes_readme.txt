10-Yard Fight (NES)
Traducción al Español v1.0 (31/07/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
10-Yard Fight (USA, Europe).nes
MD5: 8caac792d5567da81e6846dbda833a57
SHA1: 6416170dd2b2a741cfdade7ebec1cefb664e99e4
CRC32: c38b62cb
40976 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --