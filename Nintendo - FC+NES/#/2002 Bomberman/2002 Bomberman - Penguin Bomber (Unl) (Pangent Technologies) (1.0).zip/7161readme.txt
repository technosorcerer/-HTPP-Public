Penguin Bomber

Hack by Pangent Technologies (pangenttech)

  You are the Penguin Bomber. It's Christmas at the South Pole - your favorite time of year - and you're trapped in a maze in the frozen Antarctic. You are being pursued by arctic foxes, polar bears, and walruses. Set bombs to destroy enemies and ice blocks, clearing a path for yourself to find the hidden exit to each maze. Hidden powerups will help you along the way. You can set one bomb at a time. Don't blow yourself up!

  Similar to the original Bomberman by Hudson Soft, this is a hack of "2002 Bomberman," a Christmas-themed copycat game by Nice Code, AKA Bomberman 2002. This was also released in variant forms as Detonation, Dejectil, Bomb Time 2004, and Undersea 2004. Nice Code also released "Bomberman 2" which is a more complex, larger ROM.

Database match: 2002 Bomberman (Unl)
Database: Nintendo Entertainment System
File SHA-1: 0BB254F8EF30ECAC90FED3AE9809DCF63BA5FFBE
File CRC32: 444AD6B8
ROM SHA-1: B69537BBB9FE7A3541F79104083CADE76EE7E76C
ROM CRC32: A338CC66
