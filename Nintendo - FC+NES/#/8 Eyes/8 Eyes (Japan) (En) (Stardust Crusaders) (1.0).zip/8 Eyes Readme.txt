==========================================================
==========================8 Eyes==========================
==========================V 1.00==========================

Genre: Action/Plaformer

Source language: Japanese

Platform: Famicom

Patch language: English

Author: Pennywise

E-mail: antoniusblocko@protonmail.com
		
http://yojimbo.eludevisibility.org/
 
======================================================
About 8 Eyes
======================================================
Project History:

This project was started on a whim and finished in
about a day or so with the help of Ryusui. The Japanese
version of 8 Eyes has an ending that makes many
religious references and because of Nintendo's
censorship policies, that all had to be changed when
it was released in the US.

======================================================
Patching Instructions
======================================================
You can apply the patch from here:

https://www.romhacking.net/patch/

Apply the patch to the Japanese ROM:

8 Eyes (Japan).nes

We would be highly grateful, if you find some time to 
contact us with proposals or corrections. Information
on found bugs or corrections would be highly 
appreciated.

P.S.

Support the game industry by buying used games!

Even if the money doesn't go to the developers
directly, as the games become rare and harder
to find, the price goes up, and people become
more inclined to buy new releases "while they can!"

======================================================

Credits go to:

Pennywise - hacking, text editing

Ryusui - translation

All those who contributed into this process.

======================================================


Compiled by Pennywise. April 2022