RoadBlasters (NES)
Auto Accelerate
Ver 1.0, 20 Jul 2017

By baochan120 at shootthecastle.com

Makes the vehicle accelerate automatically, without having to hold "up" on 
the dpad. A variation allows maintaining current speed (cruise control) if 
up is held. 


Source ROM Name:    RoadBlasters (U) [!].nes
Source ROM CRC32:   e76915b9
Source ROM MD5:     88882ebda15b2fef3f3c869df4b1c2a0
Source ROM SHA-1:   9652d375e9ce2dc4a0e51e1e5b6d8ddba9ff0cfa
Source Rom SHA-256: 38c3d949c70b20f1d24ab6e7e1e5775e64a12aa6c1a8efe23acad5414aa5ca24

Patched ROM (No Cruise Control) CRC32:   02cd55ed
Patched ROM (No Cruise Control) MD5:     a0d55c12c3c9491d4a2cfbc483b07887
Patched ROM (No Cruise Control) SHA-1:   3e95e65a3dede26cc1af09e0b2240712965d1ad4
Patched ROM (No Cruise Control) SHA-256: c4db530b227863495b174c3b1a2cf35ec2f32650a3f3fc55c75d64436a2c39f7

Patched ROM (Cruise Control) CRC32:   51aef021
Patched ROM (Cruise Control) MD5:     8b3121eed37164e4aa7f67d558367bc5
Patched ROM (Cruise Control) SHA-1:   c8477d492d3426b14f457279603bcb4ed397f565
Patched ROM (Cruise Control) SHA-256: 190bc732be920df04aec531d56d480a2f751808f8d90e0054b4dc743388e0b62
