Thanks for taking the time to read this! I put this together, with help from Z-9 Lurker, in about 4 days.
It was just an impromptu idea I had while daydreaming. I've done character replacement hacks before, specifically
with the never before released Metal Man IV, which is included in this file if you want to experience my work back
when it was exclusively made by agonizingly editing pixel-by-pixel in TLP. (Shudder)

This hack is visual-only, and while a patch has been provided, (DISCLAIMER: THE PATCH ONLY WORKS WITH JAPANESE ROMS!) 
I have not tested this with any other Rockman 5 hacks out there. Ingame text and palettes are unchanged, as trying to do so 
proved to be... absolutely not worth it for this project. 
If you want Darkman to be grey, do it yourself. Open a palette editor and try not to accidentally screw up all the palettes, 
or make the entire stage select greyscale because Megaman's palette is the same as the background.
(Internal Screaming)

Oh and Megaman was removed from the intro because we didn't feel like making a custom sprite for that, and then tailoring it
for the oh-so limited space provided.

Have Fun!

Credits:
Lord Louie - made most of the frames (which z-9 later polished up), put the graphics in the rom, and tweaked them to better fit in.
Z-9 Lurker - made the title screen, gorgeous mugshot, 1UP icon, and climb sprites. 

