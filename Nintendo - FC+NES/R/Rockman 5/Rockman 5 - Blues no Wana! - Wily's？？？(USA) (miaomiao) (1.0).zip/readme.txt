Weapon Mechanics:

------------------------------------
Wave: Can be fired in midair.

Gyro: Can be fired in 8 directions, just like Metal Blade in Mega Man 2.

Crystal: Will bounce forward and roll, explode when hitting an enemy.

Napalm: Will bounce back when hitting a wall.

Arrow: Stand on it and press the B button to take you forward, and can be used as a pedal without pressing anything.

Stone: Sends out three light balls that always point to the right.

Gravity: Every three times it is used, it can restore health, and at the same time, the background flash changes to the character's color change. (Photosensitive epilepsy said: "This is great:D", of course this may just be my guess:P)

Charge: You can gain invincibility when used, and you can accelerate the slide without energy, but you are not invincible.

Star: Press and hold the B button to jump high, and when you hit a bullet or an enemy while holding the B button, you can keep the high jump state.

Use it again to hit a bullet or an enemy to resume the jumping state, and the consumption mode is changed to consume two grids of energy every 5 jumps. By the way, hitting bullets or monsters will also consume energy.

Rush Jet: Based on Mega Man 3, it can move freely instead of moving forward all the time.

Beat: Same as the original version, but with a passive skill that can increase the invincibility time without knockback.

When Beat is not summoned, it can convert the damage of injury into deducting one energy without losing blood.

(Note that this invincibility time extension and no knockback are global buffs, and the password to obtain Beat has been deleted by Miaomiao)

------------------------------------------------------------------------

Other mechanisms:

------------------------------------
It comes with an energy balancer (the conditional logic is not well implemented, for me), and it can restore blood to three energy for each weapon. (Not affected by difficulty)

Poison water loses one blood every 26 frames.

In Easy difficulty, death can restore weapon energy, and as long as you got five lives and more, you can restore full HP like Mega Man Maker.
You will not die if you touch a spike, but you will lose 10 HP.

Normal difficulty: In addition to accumulating nine lives to restore full HP, the mechanism is the same as the original.

Hard difficulty: Gather nine lives to restore full HP, and when you have five or more E tanks, you can trigger the passive skill of E resurrection armor. (Reference from League of Legends?) If you have less than five E tanks, there will be no passive.
Before turning on this passive, you need to select the E tank icon in the weapon selection interface and press the Select key. (If a "ding" sound is emitted, it means it is turned on, and if an buzz sound appears, it means it is turned off)

Escape Unit: You can exit and return to the Boss selection interface in the 8 Bosses level that has been passed. (The number next to EXIT indicates the difficulty, 1 is Easy, 2 is Normal, and 3 is Hard)

However, please do not use it in levels other than the 8 Bosses level, otherwise bad things may happen. (Don't ask me how I know)

Also, Miaomiao may not care about this hack anymore... (Maybe there will be exceptions?)

------Written by 2024.07.08 MagnetFirstBro------