﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace bmani
{
    class BinaryManipulatorBuffer
    {
        //constant
        private const int ciDefaultSize = 128;
        private const int ciMaxLength = 0x1000000; //16M

        //field
        private int iLength;
        private int iAllocatedSize;
        private byte[] abData;
        private bool bEnabled_body;
        static UInt32[] auiCRCTable;

        //constructor
        public BinaryManipulatorBuffer()
        {
            Initialize();
            if (auiCRCTable == null)
            {
                auiCRCTable = new UInt32[256];
                for (UInt32 i = 0; i < 256; i++)
                {
                    UInt32 c = i;
                    for (int j = 0; j < 8; j++)
                    {
                        c = ((c & 1) == 1) ? (0xEDB88320 ^ (c >> 1)) : (c >> 1);
                    }
                    auiCRCTable[i] = c;
                }
            }
        }
        //property
        public int Length
        {
            get { return iLength; }
            set {
                for (int i = iLength; i < value; i++)
                {
                    this[i] = 0x00;
                }
                iLength = value;
            }
        }
        public bool Enabled
        {
            get { return bEnabled_body; }
        }
        //operator
        public byte this[int index]
        {
            set
            {
                if (index < 0) { throw new Exception("BMB:インデックスが負数です。"); }
                for (; index >= iAllocatedSize;)
                {
                    iAllocatedSize *= 2;
                    if (iAllocatedSize > ciMaxLength) { throw new Exception("BMB:インデックスが最大サイズを上回りました"); }
                    Array.Resize(ref abData, iAllocatedSize);
                }
                if (index >= iLength) { iLength = index + 1; }
                abData[index] = value;
                bEnabled_body = true;
            }
            get
            {
                if ( !bEnabled_body || index < 0 || index >= iLength) { return default(byte); }
                return abData[index];
            }
        }
        //method
        public void Initialize()
        {
            iLength = 0;
            iAllocatedSize = ciDefaultSize;
            abData = new byte[iAllocatedSize];
            bEnabled_body = false;
        }
        public byte[] Export()
        {
            if (!Enabled) { return null; }
            byte[] abOut = new byte[iLength];
            Buffer.BlockCopy(abData, 0, abOut, 0, iLength);
            return abOut;
        }
        public void BlockCopyExport(int iSrcLocation, byte[] abDest, int iDestLocation, int iSize)
        {
            Buffer.BlockCopy(abData, iSrcLocation, abDest, iDestLocation, iSize);
        }
        public int IndexOf(byte value,int startindex)
        {
            int iRV = Array.IndexOf(abData, value, startindex);
            if( iRV>= iLength) { iRV = -1; }
            return iRV;
        }

        // https://ja.wikipedia.org/wiki/%E5%B7%A1%E5%9B%9E%E5%86%97%E9%95%B7%E6%A4%9C%E6%9F%BB#CRC-32
        public UInt32 GetCRC32()
        {
            UInt32 c = 0xFFFFFFFF;
            for( int i=0; i<iLength; i++ )
            {
                c = auiCRCTable[(c ^ abData[i]) & 0xFF] ^ (c >> 8);
            }
            return c ^ 0xFFFFFFFF;
        }
        public void Load(ref byte[] abSrc)
        {
            Length = abSrc.Length;
            Buffer.BlockCopy(abSrc, 0, abData, 0, Length);
            bEnabled_body = true;
        }
        public void Save(string filename)
        {
            byte[] abTmp = new byte[iLength];
            Buffer.BlockCopy(abData, 0, abTmp, 0, Length);
            System.IO.File.WriteAllBytes(filename, abTmp);
        }
        public void Fill(int iOffset, int iSize, byte bData)
        {
            for (int i = 0; i < iSize; i++)
            {
                this[i + iOffset] = bData;
            }
        }
        public void Copy(BinaryManipulatorBuffer src, int iSrcOffset, int iDestOffset, int iSize)
        {
            Buffer.BlockCopy( src.abData, iSrcOffset, abData, iDestOffset , iSize);
            bEnabled_body = true;
        }
    }
}
