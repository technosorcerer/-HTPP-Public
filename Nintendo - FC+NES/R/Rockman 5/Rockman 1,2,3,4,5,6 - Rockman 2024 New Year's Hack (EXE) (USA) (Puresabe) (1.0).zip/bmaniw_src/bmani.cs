﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Diagnostics;

namespace bmani
{
    class BinaryManipulator
    {
        public readonly string version = "1.01";
        protected const int cMaxBuffer = 256;
        protected BinaryManipulatorBuffer[] aBuffer = new BinaryManipulatorBuffer[cMaxBuffer];

        public BinaryManipulator()
        {
            InitializeBuffers();
        }
        public void InitializeBuffers()
        {
            for (int i = 0; i < cMaxBuffer; i++)
            {
                aBuffer[i] = new BinaryManipulatorBuffer();
            }
        }
        public string ProcessLine(string strLine)
        {
            string strStdOut = "";
            string strLineEff = strLine ;
            {
                //コメント
                int iOffset = strLineEff.IndexOf(';');
                if (iOffset >= 0)
                {
                    strLineEff = strLineEff.Substring(0, iOffset);
                }
            }
            char[] acSpace = {' ','\t'};
            string[] astrToken = strLineEff.Split(acSpace, StringSplitOptions.RemoveEmptyEntries);
            int[] aiToken = new int[astrToken.Length];
            if (astrToken.Length==0) { return strStdOut; }

            try
            {
                switch (astrToken[0].ToLower())
                {
                    case "load":
                        strStdOut += CmdLoad(ref astrToken, ref aiToken);
                        break;
                    case "save":
                        strStdOut += CmdSave(ref astrToken, ref aiToken);
                        break;
                    case "crc32":
                        strStdOut += CmdCRC32(ref astrToken, ref aiToken);
                        break;
                    case "fill":
                    case "f":
                        CmdFill(ref astrToken, ref aiToken);
                        break;
                    case "setsize":
                        CmdSetSize(ref astrToken, ref aiToken);
                        break;
                    case "copy":
                    case "c":
                        CmdCopy(ref astrToken, ref aiToken);
                        break;
                    case "xor":
                    case "x":
                        CmdXor(ref astrToken, ref aiToken);
                        break;
                    default:
                        throw new Exception(string.Format("コマンド{0}は認識できません。", astrToken[0]));
                }
            }
            catch(Exception e)
            {
                string strErr = string.Format("\n内容:{0}\n", strLine);
                strErr += e.ToString();
                throw new Exception(strErr);
            }
            return strStdOut;
        }
        public string ProcessFile(string strFilename)
        {
            string strStdOut = "";
            using (StreamReader sr = new StreamReader(strFilename, Encoding.GetEncoding("UTF-8")))
            {
                for ( int iLine=1 ; ; iLine++ )
                {
                    string strTmp = sr.ReadLine();
                    if( strTmp == null) { break; }
                    try
                    {
                        strStdOut += ProcessLine(strTmp);
                    }
                    catch(Exception e)
                    {
                        string strErr = string.Format("\nファイル:{0}\nライン:{1}\n", strFilename,iLine);
                        strErr += e.ToString();
                        throw new Exception(strErr);
                    }
                }
            }
            return strStdOut;
        }
        protected void TestArgument(string strType, ref string[] astrToken , ref int[] aiToken)
        {
            if (strType.Length != astrToken.Length-1)
            {
                throw new Exception("引数の数が不正です。");
            }
            Debug.Assert(astrToken.Length == aiToken.Length);
            for (int i = 1; i < strType.Length+1; i++)
            {
                aiToken[i] = default(int);
                switch (strType[i-1])
                {
                    case 'x': //hex
                        try
                        {
                            aiToken[i] = Convert.ToInt32(astrToken[i], 16);
                        }
                        catch(FormatException)
                        {
                            throw new Exception(string.Format("引数{0}({1})を16進数に変換できません。", i, astrToken[i]));
                        }
                        break;
                    case 'b': //buffer
                        try
                        {
                            aiToken[i] = Convert.ToInt32(astrToken[i], 16);
                        }
                        catch (FormatException)
                        {
                            throw new Exception(string.Format("引数{0}({1})を16進数に変換できません。", i, astrToken[i]));
                        }
                        if (aiToken[i] < 0 || aiToken[i] >= cMaxBuffer)
                        {
                            throw new Exception(string.Format("引数{0}({1})がバッファ番号として不適切です。", i, astrToken[i]));
                        }
                        break;
                    case 'f': //filename
                        // :*?"<>| が含まれているとエラー(/\は許容)
                        if (astrToken[i].Contains(":") ||
                            astrToken[i].Contains("*") ||
                            astrToken[i].Contains("?") ||
                            astrToken[i].Contains("\"") ||
                            astrToken[i].Contains("<") ||
                            astrToken[i].Contains(">") ||
                            astrToken[i].Contains("|") )
                        {
                            throw new Exception(string.Format("引数{0}({1})にファイル名として不適切な文字が含まれています。",i,astrToken[i]));
                        }
                        break;
                    case 's': //string
                        //特に何もしない
                        break;
                    default:
                        throw new Exception("内部エラー(引数タイプ指定が不正です)");
                }
            }
        }
        protected string CmdLoad(ref string[] astrToken, ref int[] aiToken)
        {
            TestArgument("bf", ref astrToken, ref aiToken);
            byte[] abTmp = System.IO.File.ReadAllBytes(astrToken[2]);
            string strTmp = "ファイル" + astrToken[2] + "が読み込まれます。\n";
            aBuffer[aiToken[1]].Load(ref abTmp);
            return strTmp;
        }
        protected string CmdSave(ref string[] astrToken, ref int[] aiToken)
        {
            TestArgument("bf", ref astrToken, ref aiToken);
            string strTmp = "ファイル" + astrToken[2] + "に出力されます。\n";
            aBuffer[aiToken[1]].Save(astrToken[2]);
            return strTmp;
        }
        protected string CmdCRC32(ref string[] astrToken, ref int[] aiToken)
        {
            TestArgument("bxss", ref astrToken, ref aiToken);
            UInt32 uiCRC32 = aBuffer[aiToken[1]].GetCRC32();
            string strTmp = string.Format("CRC32:{0:X8} Correct:{1:X8} ", uiCRC32, aiToken[2]);
            if( uiCRC32 == (UInt32)aiToken[2] )
            {
                strTmp += string.Format("{0}", astrToken[3]);
            }
            else
            {
                strTmp += string.Format("{0}", astrToken[4]);
            }
            strTmp += "\n";
            return strTmp;
        }
        protected void CmdFill(ref string[] astrToken, ref int[] aiToken)
        {
            TestArgument("bxxx", ref astrToken, ref aiToken);
            aBuffer[aiToken[1]].Fill(aiToken[2], aiToken[3], (byte)aiToken[4]);
        }
        protected void CmdSetSize(ref string[] astrToken, ref int[] aiToken)
        {
            TestArgument("bx", ref astrToken, ref aiToken);
            aBuffer[aiToken[1]].Length = aiToken[2];
        }
        protected void CmdCopy(ref string[] astrToken, ref int[] aiToken)
        {
            TestArgument("bxbxx", ref astrToken, ref aiToken);
            aBuffer[aiToken[3]].Copy(aBuffer[aiToken[1]], aiToken[2], aiToken[4], aiToken[5]);
        }
        protected void CmdXor(ref string[] astrToken, ref int[] aiToken)
        {
            TestArgument("bxxs", ref astrToken, ref aiToken);
            if (astrToken[4].Length % 2 == 1)
            {
                throw new Exception(string.Format("文字列{0}の長さが奇数です。", astrToken[4]));
            }
            int iSrcLength = astrToken[4].Length / 2;
            byte[] abXorTable = new byte[iSrcLength];
            for( int i=0; i<iSrcLength; i++)
            {
                string strTmp = astrToken[4].Substring(i * 2, 2);
                try
                {
                    abXorTable[i] = Convert.ToByte(strTmp, 16);
                }
                catch(FormatException)
                {
                    throw new Exception(string.Format("文字列{0}に含まれる{1}が16進数に変換できません。", astrToken[4],strTmp));
                }
            }
            for( int i=0; i<aiToken[3]; i++)
            {
                aBuffer[aiToken[1]][aiToken[2] + i] ^= abXorTable[i % iSrcLength];
            }
        }
    }
}
