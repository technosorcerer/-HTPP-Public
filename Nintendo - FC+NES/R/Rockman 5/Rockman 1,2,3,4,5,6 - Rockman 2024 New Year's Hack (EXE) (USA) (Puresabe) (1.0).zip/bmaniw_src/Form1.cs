﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using bmani;
namespace bmaniw
{
    public partial class Form1 : Form
    {
        BinaryManipulator BM = new BinaryManipulator();
        private string PatchFileName = "patch.txt";
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //バージョン表示
            this.Text = "Binary Manipulator Ver." + BM.version;
            //info.txtの読み込み
            loadInfo(textBox1);
        }
        private void loadInfo(TextBox dest)
        {
            try
            {
                string tmp = File.ReadAllText("info.txt", System.Text.Encoding.GetEncoding("UTF-8"));
                dest.Text = tmp ;
            }
            catch (Exception e)
            {
                string tmp = "ここにはinfo.textが表示されます。\r\nこのテキストが表示されている場合は、恐らくinfo.txtが存在していません。\r\n(\"info.txt\" is missing!)\r\n以下のエラーが発生しました。\r\n\r\n";
                tmp += e.ToString();
                dest.Text = tmp;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string strTmp = "";
            try
            {
                strTmp = BM.ProcessFile(PatchFileName);
            }
            catch (Exception ex)
            {
                strTmp = "エラーが発生しました。(Error!)\r\n\r\nエラー情報\r\n" + ex.ToString();
            }
            strTmp = strTmp.Replace("\r\n", "\n").Replace("\n", "\r\n");
            textBox1.Text = strTmp;
        }
    }
}
