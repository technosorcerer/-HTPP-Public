Rad Racer: VW Beetle Edition

v.1.0 (06/03/2024)

WHY THIS HACK WAS MADE?

Rad Racer features the player controlling a Ferrari 328 against 8 different car models. The player has the option of choosing an F1 racing car, but cannot play with any of the oponent cars. This hack was made to allow the player to drive the first oponent car, the VW Beetle.

WHAT DOES THIS HACK DO?

It replaces all the Ferrari 328's sprites for VW Beetle ones. Although the sprite used is based on the original VW Beetle sprite, changes were made to make it resemble the 60's model instead of the 70's present in game. The color scheeme stays the same as the Ferrari. It also replaces the Ferrari in the car selection screen and the one in the ending cutscene.

WHAT DOES THIS HACK DOESN'T DO?

No changes were made to the gameplay. Fidling with the acceleration or top speed was beyond the author's knowledge at the time of this release.

ACKNOWLEDGEMENTS

This hack was made using Tyle Layer Pro 1.1 and mirkes.de Tiny Hexer 1.8.1.6.

2024 chirinea