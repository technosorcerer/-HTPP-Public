Romance of the Three Kingdoms II
Restoration Patch
by the_wizard_666

v. 1.0 

This patch came about as a result of a conversation I had with a friend of mine.  I had mentioned that it'd
be nice if someone would fix the numerous typos with the character list.  During that conversation, he noted
that the Japanese release used princesses instead of jewels as war spoils, and would like to see that part of
the game restored as well.  So I figured that since nobody else was doing it, I'd just have to do it myself.

Changes:

38 character names have been edited.  The full list is at the end of the file.
One of the advisor quotes also contained a misspelled name, and has been corrected.
Princesses have been restored to the war spoils list, and the graphic for them has been reinserted.

Credits:

the_wizard_666 - All coding, edits, and assorted work has been done by myself.

Thanks to my good friend Basil, who planted the seed in my head to actually make this patch in the first 
place.  

And a special shout out to the NESDev Discord server for their help with learning how to actually find the 
data I was looking for, and just generally helping me learn. Specifically the users sylvie, jroweboy, and
TakuikaNinja, who each helped me understand what I was looking at in the debugger.  I couldn't have made this 
patch without your aid!



EDITED GENERALS:
Original name    Corrected Name
Tao Quian        Tao Qian
Hai Fu           Han Fu
Liu Yong         Liu Yao
Jia Xue          Jia Xu
Han Ze           Kan Ze
Wen Pin          Wen Ping
Yue Jiou         Yue Jiu
Wu Anquo         Wu Anguo
Xu Xin           Hua Xin
Yuan Pu          Yan Pu
Huan Cheng       Huan Sheng
Chen Xi          Chen Yi
Chun Yuquiong    Chunyu Qiong
Zhao Yue         Zhao Yun
Zhang Hing       Zhang Meng
Deng Qian        Deng Xian
Li Zhan          Li Kan
Liu Zong         Liu Cong
Xu Zhu           Xu Chu
Niou Jin         Niu Jin
Shang Quang      Xiang Chong
Xingdao Rong     Xing Daorong
Zhang Xiou       Zhang Xiu (2)
Shang Long       Xiang Lang
Yang Kai         Yong Kai
Ma Xu            Ma Su
Fei Wei          Fei Yi
Duo Si           Duosi
A Hui Nan        Ahuinan
Jinhuan Jie      Jinhuan Sanjie
Fan Jiang        Fan Qiang
Pan Tun          Pan Jun
Dong Tuno        Dongtuna
Shamo Ke         Shamoke
Zhang He (2)     Zhang Hu
Dong Ai          Deng Ai
Zhuge Luo        Zhuge Ke
Liu Chan         Liu Shan