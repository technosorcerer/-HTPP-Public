NOTE: This is the sequel to Rockman 2 YJ.

Plot Synopsis:
In the "YJ Rebellion" of a certain year, Rockman reached "The End" and defeated Dr. Wily.
However, Dr. Wily discovered a "meme".
Afterwards, he decided to use the "meme" to defeat Rockman.
As a result, Rockman found himself once again facing a difficult battle.

Weapons:
Heatman: Cai XuKun's Balls
-Cai Xukun's basketball has the ability to perform a double power-up.

Airman: Ii yo, koi yo
-It can "stink enemies to death". (in a certain sense)

Woodman: Cirno's ⑨Ball
-Generate a "⑨ ball" shield at one's own position that can be shot in four directions: up, down, left, and right.

Bubbleman: "Warpman" Generator
-This weapon allows you to "teleport upwards" to approximately one-third of the screen's height.
-With proper usage, it can be used to phase through walls or reach elevated areas.

Quickman: YEE~~~
-It shoots out small Yee darts, although the trajectory can be a bit peculiar :/

Flashman: Ubisoft's adaptation of the Famicom
-Achieve a slowing effect on enemies by causing lag, which proves highly effective against 8 bosses.

Metalman: Aoligei（Feces:/）
-Throw feces at the enemies to eat. (without malice)

Clashman: Bunshin（Doppelgänger）
-Shoot out a clone of oneself that explodes upon contact with walls or certain enemies.

2023/12/25
-Written by MagnetFB-