README (written 9/9/24)


Fanmade Weapon Names:

* Clash Bomb ~ (Fury Cracker)
* Air Shooter ~ (Iceberg Bijou)
* Quick Boomerang ~ (Quench Cleave)
* Metal Blade ~ (Stellar Slice)
* Atomic Fire ~ [mistake] (working name until bug is fixed)
* Leaf Shield ~ (Circling Puckapuckers)
* Bubble Lead ~ (Aquamarine Hurtle)
* Time Stopper ~ (Kibosh Standstill)


Weakness Chain:

* Bubble Man ~ (Kibosh Standstill)/(Circling Puckapuckers)
* Wood Man ~ (Quench Cleave)
* Heat Man ~ (Stellar Slice)
* Air Man ~ (Stellar Slice)/(Circling Puckapuckers)/(Quench Cleave)/(Fury Cracker)
* Flash Man ~ (Quench Cleave)
* Metal Man ~ (Iceberg Bijou)
* Clash Man ~ (Aquamarine Hurtle)
* Quick Man ~ (Fury Cracker)
* Mecha Dragon ~ (unchanged)
* Piko Piko-kun ~ Mega Buster/(Fury Cracker)
* Guts Tank ~ (Circling Puckapuckers)
* Boobeam Trap ~ (Fury Cracker)
* Wily Machine ~ unchanged


Known Bugs/Issues:

* First and foremost, the password system has been disabled for some reason.
* Atomic Fire will trigger a CPU crash, hence the new name. Unfortunately, I don't know how to deal with the technical aspects of video games, so be careful when switching weapons.
* The Wily Machine has glitched graphics. Although fabiansummers stated that this fight was impossible to win in the original version, in reality DENTOROMAN just removed a layer of the floor so that the player can't reach Wily's cockpit. I restored the ground to address this issue.
* The Alien is weak to a weapon that the player doesn't have enough of, so that spells the end of the road for this romhack. Either that, or DENTOROMAN didn't finish the boss' new weakness.


Tips:

* The easiest starting points are Clash Man, Flash Man, Wood Man and Bubble Man. Flash Man in particular is able to jump so far that he gets stuck in a loop of walljumping.
* For some strange reason, I am unable to rearrange the Sniper Joe placement in Wily 1. I have tried my best. Use Quick Boomerang or outrun them.
* Keep in mind that although the player can outrun the fast Tellies compared to the original version of Venom, the Tellies will make sharper turns than them. This means that if you're too close, they have already clung onto you. Also be wary of the fact that their spawn times are half of what they were in the vanilla game. DENTOROMAN would just spam these guys to Hell and back (as with every other enemy in the game), so I had to remove half of their appearances in the game. Because Petit Goblins (baby Air Tikis) share the same behavior as Tellies, they will also lock onto the player.
* I don't recommend going after Quick Man or Air Man first. They are completely unavoidable, and will kill the player before the boss theme reaches the 1-minute mark.
* Heat Man is unusually smart, predicting your location even when he's charging. Use the ladder if you have to.
* All Piko Piko-kuns will fly at max speed.
* The Sniper Joes are incredibly aggressive, shooting almost a dozen bullets at once. I made sure the player isn't forced to stand in front of them while defeating them. 
* It is now possible to jump across Anko because it spawns more Shrinks than usual. 
* Like Anko, Scworms will generate more frequently.
* The M-445 section of Bubble Man's stage was replaced with a simple spike challenge.
* Pipi spawns much sooner, but the player is fast enough to outrun both the egg and the Copipis.
* The Moles in Metal Man's stage were removed to allow the player to focus on avoiding the Presses. The Moles in Wily 2 were kept because there is nothing else interfering with them in that stage.
* All Blockies were removed from the game due to being unavoidable.
* Mets go berserk upon detecting the player, permanently chasing and shooting simultaneously. However, the level design allows the player to lure some of them into a pit.
* To no surprise, the Shotman is a complete douchebag, but I have tweaked the level design to make it easier to fight them.


2009 ~ 2024














