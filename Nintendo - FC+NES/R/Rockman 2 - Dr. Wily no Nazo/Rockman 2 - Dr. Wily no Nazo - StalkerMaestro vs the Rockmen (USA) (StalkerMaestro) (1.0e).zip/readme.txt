Rockman 2 - StalkerMaestro vs The Rockmen by StalkerMaestro
08/09/2022

After the release of Rockman 5 Metropolis, I made this project to be able to experiment with Rockman 2. The construction of this game took approximately 2 months. This project started with modifying the music tracks, after that modifying the AI ​​of the enemies, and finally building levels.
This installment aims to test your speed skills as well as have fun with its new levels and the new gameplay of a fast rockman.

Play Testers:
Informal Tom: https://www.youtube.com/c/TomLyman
MegaRobDad: https://www.youtube.com/user/ultramegablobman

Greetings, thank you for downloading the game I am very grateful

They have been edited:
-Gameplay (StalkerMaestro style)
-Maps
-Weapons
-AI of enemies
-Colors
-Music

New Moves:
-Dash (slide) by Kuja Killer

Graphics come from other megaman games among others

Facebook page:
https://www.facebook.com/stalkermaestrohacks/

StalkerMaestro on Youtube:
https://www.youtube.com/channel/UCOIrNaVN-wHD1HWDp2R-jDQ

-STK-