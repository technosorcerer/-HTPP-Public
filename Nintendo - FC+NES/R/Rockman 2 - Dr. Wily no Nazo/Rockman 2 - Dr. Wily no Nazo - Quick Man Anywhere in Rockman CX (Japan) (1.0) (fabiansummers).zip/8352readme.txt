README

Play as Quick Man or Rock Man anywhere in Rockman CX or Mega Man CX. Press start to enter the pause menu, then press select to
summon Quick Man. Press Start during gameplay as Quick Man to switch back to Rock Man.

Known issues: Visual bugs can occur in the reshuffled areas in Light's lab if you switch characters midway through this section.
Minor, temporary visual bugs can occur when switching characters at the final boss.