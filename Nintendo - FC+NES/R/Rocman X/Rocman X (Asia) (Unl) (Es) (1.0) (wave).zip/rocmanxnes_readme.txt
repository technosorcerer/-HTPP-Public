Rocman X (NES)
Traducción al Español v1.0 (05/12/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rocman X (Asia) (Unl).nes
MD5: 9a79e9caeadb8cfa0a0714a06672fcb7
SHA1: eb4afc4f262d1ec702624670d8ed0aa2cda6c865
CRC32: fa9727fd
524304 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --