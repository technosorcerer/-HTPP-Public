apply this patch to River City Ransom NES ROM

Pussy City Pimps...PCP... what can i say about it.  This was my first ROM hack, 
from wwwwaaaaaayyyyy back in 1999.  I forgot all about it until 2004 when i stumbled 
upon it again on the internet and found out it had taken on a life of its own and done 
quite well for itself without me.  It was my big joke on wholesome old NES games and 
the strange way characters sometimes talk in video games.  Really though, what could 
possibly be funnier than getting ambushed by street gangs that are trying to pummel 
you to death.... with giant dildos!  At the time of it's creation, it was probably the 
most obscene hack in existence (that title now belongs to Little Remo).  I was a terrible 
artist back in 1999, so mostly text is changed, and what little art was changed looks 
bad (not that i'm a great artist now, but i am much better than i was back in 1999).  
If i was doing this project today i'd redo more of the graphics.  Probably every hack i 
make from now to eternity will be compared to this one and come up short.  I'm amazed that 
this thing has a cult following, i've actually received fan mail about PCP, and have had 
several different strangers quote lines from PCP to me.  Maybe one day i'll make a sequel to 
PCP, when i have less projects on my plate.  Till then i hope this makes you laugh....  

Jomb