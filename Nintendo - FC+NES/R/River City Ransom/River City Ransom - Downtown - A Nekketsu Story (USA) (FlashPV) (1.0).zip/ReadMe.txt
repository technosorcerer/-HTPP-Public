DOWNTOWN - A NEKKETSU STORY version 1.0

Here's an attempt to make River City Ransom closer of its japanese counterpart.
This is based on River City Ransom Nekketsu Hack 1.2 and adds a modified title screen and a translation for the mugshots.

Apply this .ips file on a clean No-Intro ROM (headered):
River City Ransom (USA).nes (ROM CRC32: e9c387ec)

Credits:
FlashPV: Title screen and Mugshots graphic edition
FANS: Script hacking and other graphics