This hack adds different colors to Pacnsac Games Mario Kart hack.

By DarthVaderX.