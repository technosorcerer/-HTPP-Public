Rampage (NES) - Reduce Flicker
Ver 1.0, 06 Jan 2024

By baochan120 at shootthecastle.com

Reduces the screen flicker effect during the cutscenes where states are
wiped off the map. 

Source ROM Name:     Rampage (USA).nes
Source ROM CRC32:    628fe3c9
Source ROM MD5:      37ef6a6b4fa1ed6fbe1facb5f2a1cde5
Source ROM SHA-1:    fafafb1f7d3e0cb0c46a81bbe7521473ac851537

