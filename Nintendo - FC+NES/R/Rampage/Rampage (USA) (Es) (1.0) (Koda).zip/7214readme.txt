RAMPAGE(USA)
Traducido por koda 2024

------------------------------------------------------------------------------------------
INDICE
------------------------------------------------------------------------------------------

1. INTRODUCCIÓN
2. INSTRUCCIONES
3. VERSIONES
4. MOTIVACIÓN
5. AGRADECIMIENTOS
6. CONTACTO

-------------------------------------------------------------------------------------------
1. INSTRUCCIONES
-------------------------------------------------------------------------------------------

Este parche debe ser aplicado a la versión americana.

La ROM original es:

Database match: Rampage (USA)
Database: No-Intro: Nintendo Entertainment System (v. 20210216-231042)
File SHA-1: FAFAFB1F7D3E0CB0C46A81BBE7521473AC851537
File CRC32: 628FE3C9
ROM SHA-1: CF3EE859EDAC2D22B508F71242D03BF4E8F70249
ROM CRC32: 263AC8A0


Utilizen "Lunar IPS" o "Floating IPS"
Pueden descargarlo de acá:
https://www.romhacking.net/utilities/240/

-------------------------------------------------------------------------------------------
2. VERSIONES
-------------------------------------------------------------------------------------------

version 1.0 (09/02/2024):

- Traducción completa.
- Agregadas fuentes necesarias.
- Traducción Letreros de Edificios como "Bank"
- Traducción de algunos "sprites" de letreros luminosos al español.
- "Albuquerque" y "Peoria" ahora están bien escritas, originalmente existe un error en
  su escritura.
-------------------------------------------------------------------------------------------
3. ERRORES CONOCIDOS
-------------------------------------------------------------------------------------------

- No que yo sepa, reportar si se encuentra alguno.

-------------------------------------------------------------------------------------------
4. INFORMACIÓN ADICIONAL

-------------------------------------------------------------------------------------------

OFFSETS

1D948 -> GAME OVER
1D794 -> CONTINUE
1CBD1 -> PAUSE
SEARCH  BONUS (HUD) -> 01F2A2

-------------------------------------------------------------------------------------------
5. CONTACTO
-------------------------------------------------------------------------------------------

Traducción hecha por rodrigo muñoz, alias koda
Cualquier error enviar un mensaje a mi correo rodrigo.23luis@gmail.com