--------------------------------------------------
Have you ever seen Roll-Chan in Rockman Claw? Now you can play as her in the game!
Introducing... Roll-Chan in Rockman Claw!
A romhack where you play as Roll.
Defeat robot masters in order to defeat Dr. Wily
--------------------------------------------------
Have fun playing as Roll-Chan in the Romhack!
