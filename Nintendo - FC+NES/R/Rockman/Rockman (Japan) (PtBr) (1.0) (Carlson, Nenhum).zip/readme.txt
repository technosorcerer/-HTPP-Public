Aplicar na ROM: Rockman (J).nes

Antes de aplicar o IPS na sua ROM fa�a uma c�pia de seguran�a da mesma.