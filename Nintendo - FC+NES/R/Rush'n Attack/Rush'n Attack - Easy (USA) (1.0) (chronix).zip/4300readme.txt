Rush'n Attack Easy (NES)

Hacked by Andrei Vdovin a.k.a. Chronix
Email me if you find any glitches in my hack.
Thanks in advance!
chronix@bk.ru

Changes:

* Title screen was changed to "Green Beret"
* Main font was changed
* No "delays" and "steps back" when you lose a life
* Start with 5 lives
* Weapon Power-Ups give 5 shots

Original ROM:
-----------------------
Rush'n Attack (U) [!].nes
File size: 131 088

 PRG ROM:    8 x 16KiB
 CHR ROM:    0 x  8KiB
 ROM CRC32:  0xde25b90f
 ROM MD5:  0x0b423bf38720009871742388b9414878
 Mapper #:  2
 Mapper name: UNROM
 Mirroring: Vertical
 Battery-backed: No
 Trained: No
