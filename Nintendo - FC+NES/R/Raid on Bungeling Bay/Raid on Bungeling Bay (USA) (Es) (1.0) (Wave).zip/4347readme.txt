Raid on Bungeling Bay (NES)
Traducci�n al Espa�ol v1.0 (28/03/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Raid on Bungeling Bay (U) [!].nes
MD5: 7728550357cc8f6bde097627885000ac
SHA1: 31c0f267ff8246db4c206c460ca6c99cd3390f8d
CRC32: b1155ae3
24.592 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --