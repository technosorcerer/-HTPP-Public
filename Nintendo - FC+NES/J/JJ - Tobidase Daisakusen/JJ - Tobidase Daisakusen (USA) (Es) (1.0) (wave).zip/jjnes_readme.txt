JJ (NES)
Traducción al Español v1.0 (02/01/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
JJ (Japan).nes
MD5: 922b994012a7da34d55119e94a93d463
SHA1: 13b9019aa9a0ea39f00b4dd4954c080a5aef6e92
CRC32: 8093ec6f
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --