==============================================================================
BLUE LAKE WOODS I -- VERSION 1.00
Kid Chameleon MAP4A port to James Pond 3
Created by Saxman
February 20, 2024
==============================================================================

For fun, I ported Blue Lake Woods I from Kid Chameleon over to James Pond 3.
Use an IPS patcher to apply the patch to the original James Pond 3 ROM. I have
also included the LVL file for use with Chedditor, or for playing with the
Amiga port of James Pond 3.

I used Chedditor to reconstruct the level, and K-E to view the original level
from Kid Chameleon. Once I finished building the map, I decompressed it with
Pond Packer and modified the uncompressed file in HxD to set the width and
height (something not yet supported in Chedditor). Then I compressed it again
and inserted it into the James Pond 3 ROM.

I would be very interested to see other levels converted over to James Pond 3
to see how well they play. I've created all the tools necessary to make it
happen, so if anyone wants to see that happen, go for it!

- Saxman
