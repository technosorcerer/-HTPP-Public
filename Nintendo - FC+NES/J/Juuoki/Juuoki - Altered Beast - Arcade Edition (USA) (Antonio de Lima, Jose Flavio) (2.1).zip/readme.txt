Altered Beast/Juuoki - Arcade Edition by José Flavio and Antonio de Lima

This hack enhances the Famicom/NES version of Altered Beast (Juuoki), making it visually closer to the arcade and Sega Genesis versions. The goal is to deliver a more authentic look by updating key elements throughout the game.

    Character and Enemy Sprites: Several character sprites, along with some enemy sprites spread across the game, have been redesigned to match the style and proportions of the arcade and Genesis versions.

    Color Palette Adjustments: The color palette of the first stage has been modified to better reflect the tones from the original arcade version, giving the scene a more vibrant and accurate feel.

This hack brings a refined visual experience, making the Famicom/NES version of Altered Beast (Juuoki) more reminiscent of the iconic arcade and Sega Genesis aesthetics.

Note: Update 2.0 brings several improvements such as a new hud for all stages, new sprites for many enemies, correction of a bug in fall detection in the fourth stage, among others.

Update 2.1: Optional patch with the original credits and hud (with a slight touch-up).

To be applied on the Juuoki (Japan) or Juuoki (J) [!] ROM.