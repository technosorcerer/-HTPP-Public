Altered Beast/Juuoki - Arcade Edition by José Flavio, Antonio de Lima and DarthVaderX.

This hack enhances the Famicom/NES version of Altered Beast (Juuoki), making it visually closer to the arcade and Sega Genesis versions. The goal is to deliver a more authentic look by updating key elements throughout the game.

    Character and Enemy Sprites: Several character sprites, along with some enemy sprites spread across the game, have been redesigned to match the style and proportions of the arcade and Genesis versions.

    Color Palette Adjustments: The color palette of the first stage has been modified to better reflect the tones from the original arcade version, giving the scene a more vibrant and accurate feel.

This hack brings a refined visual experience, making the Famicom/NES version of Altered Beast (Juuoki) more reminiscent of the iconic arcade and Sega Genesis aesthetics.

"Gold Version Update": New version with several graphical improvements, while the original (2.2) remains available.

To be applied on the Juuoki (Japan) or Juuoki (J) [!] ROM.

--------------------------------------------------------------------

Bonus:

Cheats:

Hard Game: After the game ends and the credits are over, wait 30 seconds in the "Asmik" logo and press Start to begin a much harder game.

Sound Test: At the title screen, hold Down and press Reset. The title screen should now have the phrase "Free Play". Once you see that, hold Up and press Start.

Stage Jump: This can only work on the "continue" screen (when the hero is dead). Press SELECT button the input a stage jump function, press it once to skip current stage, press twice to skip current and next stages and so on, then press START to appear in that stage.

Stage Select: At the title screen, hold Down and press Reset. The title screen should now have the phrase "Free Play". Once you see that, press Select the number of times (minus 1) of the stage you want to start in. 

Game Genie Codes:

Infinite Health (Against Bosses Only): SZXUGZSA
Infinite Health (Except Against Bosses): SXNZPPSA 
Infinite Lives: SXVNOZVG 