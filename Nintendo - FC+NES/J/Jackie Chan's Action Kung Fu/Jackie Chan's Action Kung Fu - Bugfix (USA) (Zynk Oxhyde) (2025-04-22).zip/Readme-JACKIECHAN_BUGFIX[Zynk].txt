JACKIE CHAN'S ACTION KUNG FU
Hacked by Zynk Oxhyde
2025

---------------
Date Released:
---------------
v1.0 April 16, 2025

------------
Description:
------------
This is a patch for Jackie Chan's Action Kung Fu for the NES that fixes one of the sprites of the 360° kick facing left. 
This is based on the USA version but its also compatible with the Japan and Europe ROM versions.

--------
Changes:
--------
(v1.0 - 04/16/2025) - initial release
* fixes one of the sprites of the 360° kick facing left.

---------
ZIP file:
---------
1. This readme
2. JACKIECHAN_BUGFIX.ips patch

--------
Contact:
--------
Email: zynkoxhyde@yahoo.com

----------------
ROM Information:
----------------
Database match: Jackie Chan's Action Kung Fu (USA).nes
Database: No-Intro: Nintendo - Nintendo Entertainment System (Headerless) (v. 20250311-142929)
Format: Headered rom
File Header: 4e 45 53 1a 08 10 40 00 00 00 00 00 00 00 00 00
File SHA-1: 48308ad01ed49b928e38ee7de18feb9f917a6c1e
File CRC32: 8204226e
ROM SHA-1: a602168cd5e0143f28ebc59b914f84c0aba352c2
ROM CRC32: 58550259

--------
Credits:
--------
Zynk Oxhyde - Hacking

--------
Contact:
--------
Email: zynkoxhyde@yahoo.com

---------
Websites:
---------
https://romhacking.net/forum/index.php?action=profile;u=13199
https://www.youtube.com/c/ZynkOxhyde
https://twitter.com/Zynk_Oxhyde
https://facebook.com/zynk.oxhyde
https://deviantart.com/zynkoxhide
https://pixiv.net/en/users/14021789

---------
Donation:
---------
https://ko-fi.com/zynkoxhyde
https://paypal.me/zynkoxhyde0

-----------
Disclaimer:
-----------
* Zynk Oxhyde is not related or affiliated with Nintendo and the publisher of the original game.
* Do not sell this patch and the contents with it.
* Do not sell the pre-patched ROM into reproduction cartridges.
* Do not redistribute this patch and the contents with it on other sites without expressed permission from Zynk Oxhyde.