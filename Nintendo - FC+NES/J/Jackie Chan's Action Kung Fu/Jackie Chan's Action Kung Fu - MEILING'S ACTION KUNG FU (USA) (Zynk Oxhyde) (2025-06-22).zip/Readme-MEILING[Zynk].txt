MEILING'S ACTION KUNG FU
Hacked by Zynk Oxhyde
2025

---------------
Date Released:
---------------
v1.0 June 8, 2025

------------
Description:
------------
This is a player sprite hack of Jackie Chan's Action Kung Fu for the NES!
This hack changes Jackie's sprites into his girlfriend Meiling and vice versa!

------
Story:
------
This project follows the Japanese version.

On a sunny afternoon with the sun blazing brightly, Jackie was on a date with his lover, Meiling. 
It was their first date, and Jackie's face was slightly stiff with nervousness. 
Suddenly, the evil sorcerer Mujo Doji, awakened from a 3,000-year slumber, appeared. 
Mujo Doji had revived in the present world to take revenge on the descendants of the righteous sorcerer who had sealed him deep underground. 
And, astonishingly, that descendant was none other than Meiling. The brave and fearless Jackie stood up to Mujo Doji to protect Meiling.

At that moment, the sorcery unleashed by the Mujo Doji struck Jackie!! Tragically, Jackie was defeated and was then abducted by the evil sorcerer. 
Coming to her senses, Meiling set out to train under the Master to gain the strength needed to rescue Jackie.


--------
Changes:
--------
(v1.0 - 06/08/2025) - initial release
-Changed the player sprites changed to Meiling
-Meiling sprites changed to Jackie
-Titlescreen is modded
-JP version has a Japanese titlescreen

---------
ZIP file:
---------
1. This readme
2. MEILING(U).ips patch
3. MEILING(J).ips patch

--------
Contact:
--------
Email: zynkoxhyde@yahoo.com

----------------
ROM Information:
----------------
Database match: Jackie Chan's Action Kung Fu (USA)
Database: No-Intro: Nintendo Entertainment System (v. 20210216-231042)
File SHA-1: 48308AD01ED49B928E38EE7DE18FEB9F917A6C1E
File CRC32: 6F371F16
ROM SHA-1: A602168CD5E0143F28EBC59B914F84C0ABA352C2
ROM CRC32: 45A41784

Database match: Jackie Chan (Japan)
Database: No-Intro: Nintendo Entertainment System (v. 20210216-231042)
File SHA-1: BF1A81A5F1C28A2609DBC825ED9E866261087505
File CRC32: 73BB037E
ROM SHA-1: 651EEB93D4781C578E21A34893A4D7906F564C26
ROM CRC32: 59280BEC

--------
Credits:
--------
Zynk Oxhyde - Hacking and sprites

--------
Contact:
--------
Email: zynkoxhyde@yahoo.com

---------
Websites:
---------
https://romhacking.net/forum/index.php?action=profile;u=13199
https://www.youtube.com/c/ZynkOxhyde
https://twitter.com/Zynk_Oxhyde
https://facebook.com/zynk.oxhyde
https://deviantart.com/zynkoxhide
https://pixiv.net/en/users/14021789

---------
Donation:
---------
https://ko-fi.com/zynkoxhyde
https://paypal.me/zynkoxhyde0

-----------
Disclaimer:
-----------
* Zynk Oxhyde is not related or affiliated with Nintendo and the publisher of the original game.
* Do not sell this patch and the contents with it.
* Do not sell the pre-patched ROM into reproduction cartridges.
* Do not redistribute this patch and the contents with it on other sites without expressed permission from Zynk Oxhyde.