The Terminator - Journey to Silius hack
---------------------------------------------------------
-= Complete hack v4.0 =-
Apply 'The Terminator - Journey to Silius hack v4.0' directly to  'Journey to Silius (U) [!].nes'
---------------------------------------------------------


What this hack does:
---------------------------------------------------------
Sunsoft originally planned to make a Terminator game for the NES. They lost the license, and we all got the crappy Terminator game from Mindscape. Sunsoft changed a few things (mainly the main character, and the story), and released Journey to Silius. The game is very awesome, with a killer soundtrack, great gameplay, and cool graphics. This hack aims to try to turn Journey to Silius back into The Terminator. This hack replaces the title screen, cutscenes and story, ending, character graphics, as well as altering some enemies and bosses to look more Terminator-like. A big thank you to Kamaal Brown and PasthorRothers, who helped with the spritework, James Proveaux, who colorized the title screen, and 8-bit fan, who smoothed out and tweaked various things in the game! Enjoy!!!
---------------------------------------------------------


Version 4.0 changes:
---------------------------------------------------------
Restored, cleaned up, and improved various graphics in the game including the final boss.
---------------------------------------------------------

Version 3.0 changes:
---------------------------------------------------------
Title Screen - Cleaned up sprites on Arnold's face and added the CSM-101 text on his sunglasses.
Kyle Reese - Added the 2nd jumping frame back so the jumping animation should be more lively now. Tiny change to his hair, face and gun.
Pause Screen - Restored colors. Changed to shades of green to match terminal text colors.
Stage 1 - Restored poster. Changed from a goofy one to texts to fit the style. Fixed hole in the wall graphics. Fixed bullet from the 2nd cannon. Fixed 1st cannon's graphics.
Boss 1 - Restored pulsing colors and added blinking lights on its rear wings to match the Hunter Killers from the movies. Fixed up and smoothed out sprites.
Stage 3 - Restored hovering graphics. Made the sprite for Terminator edoskeleton more intimidating by giving it a larger frame. Restored and fixed blinking eyes/sprites to hovering enemy.
Stage 4 - Fixed hopping enemy graphics. Fixed edoskeleton enemy as in Stage 3. Flying Terminator, fixed his skull to look more attached to its torso. Pre-boss enemy, restored to original as the previous sprite looked frail and strange. It now looks like other Terminator models such as the T-infinity.
Final Boss - Fixed up Arnold's sprites, gave him glowing red eyes. Restored background, but changed the room from being in space with the planets to Skynet's time portal room with walls, holograms and the time machine.
Ending - Restored planet graphics. Restored color palettes, dashes and cursors.
---------------------------------------------------------



Tools and resources used:
---------------------------------------------------------
FlexHEX, Tile Layer Pro, FCEUX, and romhacking.net.
---------------------------------------------------------


Credits and thanks:
---------------------------------------------------------
pacnsacdave - Project Lead
Kamaal Brown - Sprite
PasthorRothers - Sprite
James Proveaux - Title Screen
8-bit fan - Sprite, mechanics
---------------------------------------------------------

Files included in zip:
---------------------------------------------------------
The Terminator - Journey to Silius hack v4.0.ips
The Terminator readme.txt
---------------------------------------------------------

Other info:
---------------------------------------------------------
http://pacnsacdave.weebly.com/
https://www.romhacking.net/community/1425/
http://www.8bitfan.info/
https://www.romhacking.net/hacks/3925/
---------------------------------------------------------


2019.3.12 - v3.0 by 8-bit fan / 8.bit.fan / butz
2021.1.11 - v4.0 by 8-bit fan / 8.bit.fan / butz