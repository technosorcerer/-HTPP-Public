Journey to Silius - Boss Run
Platform: Famicom/NES
2019.2.20 Quest Games
V1.3

Table of Contents
-----------------
1. About Journey to Silius - Boss Run
2. Hack Details
3. Patch History
4. Known Issues
5. IPS File
-----------------

1. ABOUT

Journey to Silius - Boss Run simply takes the player straight to all the boss stages, skipping the scrolling platforming stages.

2. HACK DETAILS

The following changes have been made:

� After the title screen, the player is taken straight to Stage 1 Boss (no story demo) and subsequent bosses after that
� Player only has 1 life and no continues
� Health / Weapon gauge do not refill between stages (may cause bugs; not in v1.3)
� All weapons are available from start
� Though the options menu is still accessable by pressing 'B' 33 times at the title screen, the number of continues can only be increased by '1'

3. PATCH HISTORY

1.0 First complete patch
1.1 Fixed a glaring bug that crashed the game between stages. Apparently this happened on all emulators except an old version of FCE Ultra, which I was testing on. I also made a change to the title screen this time.
1.2 Fixes some sketchy code
1.3 Reverts all the weapon/health refill events (which were likely the cause of all the glitches)

4. KNOWN ISSUES

As of 1.2, it has been reported that the patch still causes the game to freeze.


5. IPS FILE

Apply the IPS file to 'Journey to Silius (U)'--This patch may also work on 'Raf World (J)' but it has gone mostly untested and ruins the title screen and will freeze if you don't press 'START' in time.