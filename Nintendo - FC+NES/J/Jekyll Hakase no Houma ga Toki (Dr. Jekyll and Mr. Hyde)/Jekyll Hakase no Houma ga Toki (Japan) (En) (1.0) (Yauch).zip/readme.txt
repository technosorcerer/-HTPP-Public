Hey, what's up.

It's 4 AM on Halloween. 4 hours ago I thought, wouldn't it be funny to translate Dr. Jekyll and Mr. Hyde.
A few hours and a few beers later here you have it. 
According to Dr. Sparkle there are a few different levels in this, the Japanese release.
If you're a sadist you will enjoy them, if not I don't know why you are playing this game.

Wouldn't it be awesome if some reproduction maker wasted his time on this?

Send any bugs, complaints, props to yauch701@gmail.com

Next time I promise, sweet ASCI art in the readme.