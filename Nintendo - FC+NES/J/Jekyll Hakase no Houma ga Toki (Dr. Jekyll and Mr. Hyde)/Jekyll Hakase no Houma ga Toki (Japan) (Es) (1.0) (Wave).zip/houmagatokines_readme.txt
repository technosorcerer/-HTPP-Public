Houma ga Toki (NES)
Traducci�n al Espa�ol v1.0 (10/08/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Houma ga Toki (J).nes
131.088 bytes
MD5: dfe9bd158718eaf176b3f4b6415aa5b3
SHA1: 6094bfd8d492da61c8d07f250c26a7fed43c9ccb
CRC32: a5b34384

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --