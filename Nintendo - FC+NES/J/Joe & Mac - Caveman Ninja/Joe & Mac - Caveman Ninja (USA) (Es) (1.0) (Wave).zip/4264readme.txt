Joe & Mac - Caveman Ninja (NES)
Traducci�n al Espa�ol v1.0 (19/02/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Joe & Mac - Caveman Ninja (U) [!].nes
MD5: fa45f240b40310fb3b4a7f76e7612886
SHA1: 36bafdf6f8d531fecb3553c1923eeafac4a05c28
CRC32: 0c4000be
262.160 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --