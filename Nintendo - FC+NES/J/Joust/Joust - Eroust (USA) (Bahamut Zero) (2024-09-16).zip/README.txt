Fend off the incoming smurf invasion! But don't let the pterodactyl bite your dick off!

patch to a Joust (USA).nes rom