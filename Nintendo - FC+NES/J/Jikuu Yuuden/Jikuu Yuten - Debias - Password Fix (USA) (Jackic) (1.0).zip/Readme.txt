Simple Password fix for the game Jikuu Yuten: Debias on the famicom so it can be completed on real hardware on more than one sitting.

Needs to be applied to an already patched english 1.2 version of the game by Gil Galad and Steve Martin (not that one):

Platform           Nintendo Entertainment System           
ROM format         INES                                    
External Header    Yes                                     
File Size          327696 (50010)                          
ROM Size           327680 (50000)                          
ROM CRC32          41F510D9                                
ROM SHA-1          4EBAF67FA5868B14C6F399F022E555734946D5D0
