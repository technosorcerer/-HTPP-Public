from . import config

__all__ = [
            'Cfg',
          ]

Cfg = config.Cfg
