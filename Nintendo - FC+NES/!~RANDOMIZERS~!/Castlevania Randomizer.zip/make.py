from SpiderDaveAsm import sdasm

filename = 'Castlevania (U) (PRG1) [!].nes'

sdasm.assemble('project.asm', filename+'_output.nes', binFile = filename)

