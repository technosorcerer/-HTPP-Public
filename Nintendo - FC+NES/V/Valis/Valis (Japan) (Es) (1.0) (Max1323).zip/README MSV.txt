"The Fantasm Soldier Valis"
Traducción al Español Ver. 1.0 (02/08/2024)
por Max1323 (Traducciones Max1323).
Basada en la gran traducción de Sliver X y satsu.
---------------------------------------------------
Descripción:
Yuko es elegida como la guerrera Valis y portadora de 
la mística espada Valis para proteger la Tierra, la tierra
de los espíritus y el mundo de Sueño de Vecanti del
malvado demonio Rogles.

Desarrollado: Nippon Telenet
Publicado:    Tokuma Shoten
Lanzamiento:  21/08/1987 (JAP)
---------------------------------------------------
Acerca del proyecto:
-La mayoría de los textos están traducidos. Se agregaron
los caracteres españoles.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS (PC)
Utilizar UniPatcher (Android)
Utilizar Rom Patcher JS (Parcheador Online):
https://www.romhacking.net/patch/

Archivo IPS
Mugen Senshi Valis (Japan).nes
File Size     129 KB
File MD5      19C6DDAB908704735F0EA465C9705A68        
File SHA-1    166AC59DFBFA9EB7DDAFEFBFAA5000E01E9F5286
File CRC32    F4637EC0