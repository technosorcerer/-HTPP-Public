Volleyball (NES)
Traducci�n al Espa�ol v1.0 (16/03/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Volleyball (UE) [!].nes
MD5: 5ed70d6ad25c9970c0c86057246cca4c
SHA1: dca8c5e5072a813aa96547e12bc8c44d7a156987
CRC32: c0056ceb
40.976 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --