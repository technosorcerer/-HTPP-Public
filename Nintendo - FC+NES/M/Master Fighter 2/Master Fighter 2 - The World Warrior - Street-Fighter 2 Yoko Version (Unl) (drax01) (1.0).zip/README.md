# -NES-Street-Fighter-2-Yoko-Version
Graphic improvements have been made:

1. The "CAPCOM" logo has been added at startup.
2. The color palette in the opening cinematic has been improved.
3. The game's name has been corrected and redesigned. It is now called "Street Fighter 2" and not "Master Fighter 2".
4. The character portraits have been redesigned.
5. The fighters' color palettes have been improved.
6. New stage designs have been implemented.
7. The ending scene has been improved.
8. And more...

9. apply the patch to the rom:

Filename: Master Fighter II (Unl) [!].nes

CRC-32:31c69f9f

SHA-1: 3a0d0593003df6c116e0c13f1f062f1dcec142ed
