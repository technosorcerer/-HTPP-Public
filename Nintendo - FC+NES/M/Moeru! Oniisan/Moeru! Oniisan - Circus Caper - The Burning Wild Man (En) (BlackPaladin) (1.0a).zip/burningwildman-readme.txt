-------------------------------------------------
-BlackPaladin's Moeru1 Oniisan Translation Patch-
-------------------------------------------------

**********************
*The Burning Wild Man*
**********************

"Moeru! Oniisan" is a gag manga and anime, created by Kenji Terada.  It's about a boy named Kenichi Kokujou who was lost in the wilderness as a toddler and rescued by an old man who taught him karate at a young age but clueless to modern life.  He later returns to his family after being absent for 13 years, and hijinx ensues as a result.

One of Kenji Terada's accomplishments include writing the scripts for the first three Final Fantasy games, among others.

Patching Instructions:

This translation patch comes in two flavors...

The Burning Wild Man (English 1.0a).ips
--This patch is for the Japanese "Moeru! Oniisan" NES ROM (IPS format)
The Burning Wild Man (English 1.0a).bps
--This patch is for the Japanese "Moeru! Oniisan" NES ROM (BPS format)

For the patches...
The Burning Wild Man (English 1.0a).ips
The Burning Wild Man (English 1.0a).bps

Use the ROM with the following hashes. (Don't use both.)

File SHA-1: 5F0F21920C9C23C188E5840BC2F6669DB640864D
File CRC32: 5F4CC4E
ROM SHA-1: 85FC84B1E9031631A437A0BA47A0B1FA1256A808
ROM CRC32: F96D07C8

THe end results is a patched ROM with the following hashes...

File SHA-1: 3EE72AA944021DE6DB20A8457A90B0019BE4FDD2
File CRC32: 56D68658
ROM SHA-1: AFD0FED4DF3D95FFF2F84FEFD7B12C7AF01449A6
ROM CRC32: 5DD48E03

What changes have been done:

v1.0
Translated Title Screen
The game's script has been translated to English
Power-up icons that depicted Japanese text were changed to icons
Word bubbles that appear briefly when a stage begins were translated to English
Ending credits translated

v1.0a
Fixed typo in the ending

Special Thanks:
Ratty (She translated the game's script files)
cccmar (Beta Testing)
Clover (Beta Testing)
YY-CHAR team (Tool used for editing graphics)
FCE Ultra Team (Emulator uses in testing the patch)

All credit to "Moeru! Oniisan" belong to Toho, Kenji Terada, and their respective creators and programers.  This patch is mainly used for pure enjoyment for those who cannot enjoy this game.  All rights reserved.  (Toho and Terada-san, please don't come after me!)