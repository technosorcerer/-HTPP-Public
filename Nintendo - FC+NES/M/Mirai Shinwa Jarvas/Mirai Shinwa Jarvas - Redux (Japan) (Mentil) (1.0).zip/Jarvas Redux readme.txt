Jarvas Redux 1.0, by Mentil


Game premise: As an astronaut arriving on a future post-apocalyptic Earth, it's up to you to recruit allies in order to storm the castles and overthrow the Evil Monarchs reigning over the seven continents.


Instructions: Apply the appropriate patch depending on the version of Mirai Shinwa Jarvas you would like patched. As Jarvas Redux moves some game data around, it's only offered in .bps format. To patch a ROM that has already been patched with Stardust Crusaders' 1.00 English translation patch (CRC 85F6D496), use "Jarvas Redux U 1.0.bps". To patch the original Japanese ROM (CRC 7F9DAB41), use "Jarvas Redux J 1.0.bps".
Afterwards, if you wish, you can apply any of the optional patches included:

"Jarvas Redux - nogold.ips" - defeating monsters no longer grants the player any gold, which is how things are in the original game. All gold must be obtained from doing quests, which are all repeatable. Note: this will be tedious until the midgame.

"Jarvas Redux - imbalanced.ips" - reverts some of the balance changes, to give more of the original difficulty. It specifically reverts: all 'difficulty smoothing' changes, the Drug's HP restoration amount, and the buff to Leather Garb. Other reversions would be too extreme (e.g. duelist touch damage) or reintroduce softlocks (e.g. the changes to Drafts.)



Major changes:
*Collision detection with the background has been completely reworked. You should get hung up on the scenery less often.

*All known softlocks have been resolved. In order to achieve this, some paths have been modified or added so that if you have the means to reach a location, you also have the means to continue or return. Relatedly, an ability that was very difficult to find has been made much easier to come across. This enables one to activate certain things that were formerly activated using a different, inappropriate ability, and to leave an area formerly thought inescapable. Existing game walkthroughs and maps are thus rendered somewhat inaccurate.

*The framerate has been improved from 20 to 30fps. Speeds/delays have been adjusted accordingly for everything except the player's movement, which is no longer sluggish.

*Spells now cast from a new MP stat (instead of from XP). Maximum MP is set to 1 + half your level, and can be restored with Drugs. Spell cost is equal to spell rank. Mages now learn spells 5 levels earlier, thus they start with a spell at Level 0.

*Visiting a Wizard hut (aka House of Shoshin) now restores your MP. Inns of Illusion now live up to their name by restoring your HP and playing a little trick on you. They will both no longer warp you across the world, now letting you exit normally.

*Boathouse interiors now look the part, rather than expositing that you've entered one. They can now be exited, and there is now a confirmation prior to setting sail.

*Monsters now drop Gold. The difficulty curve has also been smoothed, nerfing some inexplicably-difficult enemies. Purists can disable these via optional patches.

*NPCs in towns now spawn in doorways and other appropriate entry points, when such a point is onscreen.

*Quests no longer need to be accepted in order to be turned in, fixing a notorious early-game softlock. They now give rebalanced rewards specific to the quest, rather than for the area where you turned them in.

*Touching a duelist now only does 2/3 as much damage as the first boss, rather than doing as much as the final boss. Winning duels now grants 5x as much Fame, and some dueling exploits were fixed.

*The stats screen was rearranged. It now shows XP required to level up, current and max MP, and your total Attack and Defense factoring in equipment. (Contrary to popular belief, equipment always did work, but its effectiveness is only equal to about half of your base stat.)

*A Draft will now permanently unlock passage through a gate, from both sides. Their price was doubled to compensate for this, however. Note there may still be a toll. Allies will no longer leave you when you cross a gate.

*Mapper change from X1-005 to the more-common MMC3 to aid compatibility.



Minor changes:
*The Start button now opens the quick menu instead of pausing the game. The B button is now always set to fire projectiles.

*The Status screen's info is now shown on the quick menu, with a spot for current & max MP.

*Changing Guilds now resets your XP (after pending level-ups) instead of Fame. People still recognize you despite your change in attire.

*Defeating a castle boss now grants 20 Fame.

*Unlockable areas that once seemed pointless now contain suitable rewards.

*The camera now starts scrolling when the player is closer to the center of the screen, and the left border now renders, giving more situational awareness when traveling.

*Fixed a few glitches, and made various minor graphical improvements. Player jumping is now smoother.

*Player attacks now linger longer, to reduce stunlocking of enemies and reliance on button mashing/turbo buttons. Slightly sped up the slowest projectiles.

*Slowed down helpful overworld NPCs, so they're now easier to approach.

*Closing the quick menu no longer causes you to engage in conversation with people in buildings. That's now only enabled by selecting the Speak command.



Known issues:
*In order to provide proper signposting associated with certain softlock fixes, certain level chunks were altered in a way that is not seamless, due to technical limitations.

*There is a potential midgame softlock if you take the indirect route to Euron with no Drafts, without having previously unlocked the gate between Lycanthus and Euron. Using the warp cheat is advisable in this case.

*The player character's movement speed was unable to be properly adjusted (for an optional patch) since it'd require substantial code changes just to re-enable sluggish gameplay.

*An effort to replace the sound engine was abandoned, so the music is still grating & repetitive. Playing with the sound off is recommended.



Hints:
*You must return to a Guild in order to level up. If you get stuck, try changing classes to obtain better gear or a higher defense stat. A few enemies must be outran/outmaneuvered when first encountered, although they give excellent XP once you're able to defeat them. If a path is too difficult, try a different path; expect it to take you two or three trips around the world to finish the game. Spawning is completely deterministic, which can be taken advantage of for farming purposes.


Release history:
1.0	November 2024

Work was performed on this hack between July 2023 and November 2024, encompassing about four months of solid work by one person. The author hopes to demonstrate that no game with solid fundamentals is beyond redemption, and that the results will inspire and encourage other ROM hackers to improve other games.