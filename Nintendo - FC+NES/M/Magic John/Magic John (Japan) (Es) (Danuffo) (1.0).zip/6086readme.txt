
----------------------------MAGIC JOHN en español (por danuffo)--------------------------



Esta es la traducción del juego "Magic John" que en EEUU llegó bajo el nombre "Totally Rad" y con diversos cambios como las caras de los personajes, y los diálogos.

La versión estadounidense "Totally Rad", que está en inglés, contiene mucha jerga estadounidense juvenil de los años 1980, bueno no sé mucho a detalle
 qué tipo de personas hablan así, pero es cierto, hay mucha palabra "dude" y mucha palabra "totally", así como alguna otra expresión figurada de la cual nosotros los 
traductores novatos no podamos detectar con facilidad , a veces cometemos el error de traducir todo tan literalmente.


Ahora, esta versión japonesa antes de ser traducida al español por mí, ya se había traducido al inglés por una persona(usuario KingMike), cuya traducción parece ser que se
deshizo de esas jergas aunque no por eso me confié, tuve el cuidado de investigar y releer los diálogos, aún contenía como unas 2 o 3 expresiones en total y las he traducido 
en su signficado real. 

Ejemplo: "Knock the socks off" = Impresionar/Asombrar.


Las jergas en inglés como esa que no tienen equivalencia en español, las he escrito en sentido no figurado.
Los diálogos son idénticos al juego Totally Rad pero si hay unos cuantos muy diferentes, y me basé unicamente en la retraducción inglesa de Magic Jhon.


¿Tipo de español?
El tipo de español en general no parece ser exclusivo a un país porque la mayoría del juego se habla en modo singular, solo hasta que alguien se expresa en segunda persona plural es 
cuando se nota si el estilo es español americano o español europeo, en este caso es el americano, pero solo son tres renglones de diálogo, es una traducción entendible para todos.

¿ROM parcheable?
Busca la rom "Magic John (J).nes" a este debes aplicarle el parche en formato .ips que te he dejado, se aplica usando algún programa parcheador, te recomiendo Lunar IPS.

Si tienes algún obstáculo grande al encontrar el rom correcto(que no debería de pasar) o ves algún fallo técnico, hazmelo saber en danuffpizza@gmail.com 




