METROID CONFRONTATION 2 - RETURN TO SR388

This is a NES Metroid hack, based on Gameboy's Metroid 2 and a little bit inspired by AM2R.
Made using the Editroid program (created by Snarfblam).

A lot of things has ben modified: All graphics (backgrounds and sprites), all map, text and music; to look like Metroid 2. 
Unarmored samus sprites were based on rogue dawn hack.

Can you defeat all Metroids and face the Queen?

Please check the old trailer. A lot of things have changed since then, but it's still worth getting the feeling.

https://youtu.be/w9Y-79S6EDE?si=M1GsBDMnoLEjKLVr

or

https://www.youtube.com/watch?v=w9Y-79S6EDE

Thank you so much for testing the game. Hope you like it.

Comes with FULL MAP in the zip.