Orphan Moon ROM hack by Doc Remedy

This ROM hack is mainly all graphical, as I don't pretend to be a guru at HEX editing or Assembly but some HEX editing was still done. I hope you enjoy the graphics and story created before you. The Orphan Moon (Remastered Game Sountrack) is available on most streaming music providers and a direct download of the soundtrack (with the 8-bit versions included int eh download version) are available here:

https://docremedy.bandcamp.com/album/orphan-moon-recomposed-game-soundtrack-8-bit-soundtrack

What you'll find:
-All new sprites and graphics to just about every tile in the game
-All new music for each stage
-Save Game states (no passwords)
-Wave Beam & Ice Beam can be combined
-New respawn points for each stage (not just the areas elevator)
-Since most of the original ROM build is still intact, majority of Game Genie cheats still work for this game!

What I wish I could of done to bring my FULL VISION to life:
-Created larger bosses with new movement patterns and projetiles
-Create new Boss Music Themes for entering Boss rooms
-Created a second Missle (Super Missle) that could be used on specific doors and the final boss, cycling between the two missle types and default weapon when Select is pushed
-Custom full screen graphical cut scenes for the intro, enerting boss fights or new areas and the game ending
-Have "lava" tiles hurt you when touching them, regardless where they are placed on the screen
-Have tiles that heal you when touched


-----------------------------------------------


Tools used and credits:
Editroid 4.0beta & Editroid 3.7 by Snarfblam
Metroid + Saving + Map Editor by Snarfblam
MetTuner by Snarfblam
YY-CHR by YY
Lunar IPS by FuSoYa's Niche
HxD by Maël Hörz


-----------------------------------------------


Orphan Moon: A Metroid Story
Galactic lifeform scans have discovered potential Metroid existence in a very unusual place. Sometime after the complete destruction of Zebes, it's large moon was found adrift, now in orbit around the host star FS-176. A genetics lab has been detected beneath the surface, along with Chozo technologies. This off-site moon base was used by someone to enhance the DNA of various species of life, active to Zebes, in attempts to find a perfect hybrid formula for fusing beings with Metroid DNA. Find this lab and destroy it.

Metroid Orphan Moon - AREAS AND BOSSES:

Maihkuh: The surface of the large moon of Zebes plentiful with rich vegetation, organic structures, fresh water and th apparent presence of Chozo's in both structural displays and ancient technology. This stage was named after Doc Remedy's son, Micah. The level design was highly inspired by Tallon IV, from Metroid Prime and the stage 3 Waterfall in Contra 1 for NES.

CeeSee H: Holding cells and chambers built for the purpose of torturing and keeping Chozo warriors prisoner. You will find deceased Chozo and their Power Suits hanging throughout the area. Named after Doc Remedy's son, Christian, using his initials CCH. Level design inspired by a mixture of Clive Barker and Ninja Gaiden 3, specifically Act 3 and Act 4 elements.

Necrol Ferun: Underground temple hidden below Ceesee H. It's built above a diamond core deposit, blocking transmissions and map scans. The word Ferun, in Chozo translates to mean "altar". At it's depths you will encounter Necrol Feather, the areas boss. This level design was inspired by both Mega Man 5's Crystal Man stage and Castlevania 1 for NES.

Necrol Ferun Boss: Necrol Feather
Unsuccessful Clone attempt of a Chozo Warrior (Mawkin Tribe).  This expirementation was a genetic  attempt to regain the wings Ancient Chozo used to have on their backs. The regenerative cells within it's Metroid DNA injection failed and keep it in a constant state between death and reanimation. Be cautious when approaching Necrol Feather.

Vulcarva: The molten magma core of the large moon of Zebes. The creatures here not only display a resemblance to Metroid characteristics physically, but you will also encounter several monstrocities including incarnations (yes, plural) of the areas boss, the Chozotroid. Level design was inspired by the terrains of games like Starcraft 2 and Diablo 2.

Vulcarva Boss: Chozotroid
The Chozotroid, a hybrid experiment aimed at creating a perfect balance to weaponizing both Chozo and Metroid likeness. Just as a Metroid absorbs energy for power and survival, the Chozotroid clones can absorb the thermal energy from the molten core, with varying results in strength. Many attempts at this amalgamation can be found.

*A statue of 2 creatures found in Maihkuh block the way to the final area and requires the DNA from each specimen to advance to the subterraneous AI genetics command center below the surface of the large moon of Zebes.

AI Clone Lab - Hidden deep beneath the surface, this area is rich in Chozo technology. Fully functional with cloning and testing stations, your mission is to find and destroy what's at the center hub of this lab. Level design was greatly inspired by elements seen in  the opening level of Metroid Prime, particularly, the display of various creatures in stasis inside of devices.

Final Boss: Alpha Chozotroid
The Alpha Chozotroid, a clever clone of the Mother Brain AI, using various genetic tests to construct a more suitable physical host body to house it's brilliant mastermind. Displays a resilience to extreme temperatures and most concussive blasts. Almost complete on it's journey to become the perfect weapon, destroy it before the rest of the body is complete!

