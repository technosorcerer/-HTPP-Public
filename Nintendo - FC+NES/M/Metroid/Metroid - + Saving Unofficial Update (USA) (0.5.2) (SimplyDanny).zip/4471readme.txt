Okay, first off, just to clarify:
(Basic) is for any vanilla Metroid ROM. It will overwrite any data that the original ROM had with relocated data and new data.
(ExpandedROM) is for any Metroid ROM that has been expanded to accomodate more space.This can be used on any ROM hack of choice as long as it's expanded.
(Note: Hacks with the save patch and/or animated background are already expanded; otherwise, you can download the latest version of Editroid to expand hacks that aren't.)

Second off, the original + Saving was NOT made by me, but rather, Snarfblam. I just added more content onto it, some of it also being his work as well.

So, what do these .ips files add? (*NEW* means that they are features not present in version 0.4):
- The password system has been replaced with a whole new save system
- Pausing now brings up a scrollable 7x7 minimap
- Ice and wave beams can now stack, meaning both can be used at once
- Ice beam and bombs have been improved (by dealing more damage and having more control over, relatively)
- You can now walljump (although only once in the air)
- A 3x3 minimap is displayed in the corner
- *NEW* UI has been fixed graphically
- *NEW* Red doors now cost 1 rocket while yellow and purple doors cost 5
- *NEW* Save anytime while paused by pressing Up + A (this sends you to the game over screen though, so be careful)
- *NEW* RNG has been reevamped and reverted to its more advanced Japanese counterpart
- *NEW* Door transitions have been sped up quite substancially
- *NEW* Unmorphing clipping glitch fixed for hacking purposes (not in original game due to level design preventing it from occuring)
- *NEW* Refills all of your health, including energy tanks, instead of starting off at 30 HP every time
- *NEW* Missile pickups now drop more frequently and give you 5 missiles instead of 2.