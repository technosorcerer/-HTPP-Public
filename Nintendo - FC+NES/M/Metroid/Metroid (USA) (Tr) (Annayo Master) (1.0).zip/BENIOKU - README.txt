	METROID - NES, 1986

��in T�rk�e �eviri/Turkish Translation

�eviren/Translated By: Annayo Master

Durumu/Status: 100%

v1.0, Tarih/Date: 08.07.2024 (DD/MM/YYYY)

================================

	!==-- D�KKAT --==!

  Bu �eviri dosyas�, NINTENDO'nun
hi�bir  telifli  �r�n�n�n  hi�bir
kesitini  yasal  olmayan  �ekilde
sunmamaktad�r.

  Bu yaman�n,  kullan�c�ya ait olan
kopya �zerine, ���nc� parti yaz�l�m
arac�l���yla    entegre    edilmesi
gerekmektedir.  T�m  kullan�c�lar�n
yamay�  sahip  olduklar�   orijinal
kopya  �zerine   ger�ekle�tirmeleri
temenni olunur.


	!==-- KURULUM --==!

  Yamay� program kullanarak ya da
internete "rom patcher" arat�p
orijinal oyun dosyan�z ve bu yamay�
se�erek kurabilirsiniz.

  Yamay� .ips ya da .bps uzant�l�
dosyayla yapabilirsiniz. Yaln�zca
birini kullan�n.

================================

	!==-- WARNING --==!

  This translation file doesn't
include any of copyrighted work
of NINTENDO.

  It is suggested to use the patch
with your own original copy.


