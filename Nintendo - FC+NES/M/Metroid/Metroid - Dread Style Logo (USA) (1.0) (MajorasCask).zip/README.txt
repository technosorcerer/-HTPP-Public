Metroid - Dread Style Logo
By MajorasCask
v1.0

---------------------------------------------------------

Changes the title screen logo to reselmble ones from the rest of the
series, specifically the Samus Returns and Dread version of the logo,
while also retaining some design elements from the original.

---------------------------------------------------------

Special thanks to:

- SnowBro
- Dirty McDingus

For their efforts on the Metroid source code disassembly, with which I
was able to identify unused data for extra tiles right above where the
logo graphics are stored.