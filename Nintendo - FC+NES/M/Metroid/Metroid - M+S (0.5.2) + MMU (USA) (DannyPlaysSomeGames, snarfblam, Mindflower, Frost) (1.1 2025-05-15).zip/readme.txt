Version 1.1:
A few frames were added for the item acquisition, so it does not feel abruptly interrupted. (Shout outs to Mindflower for pointing this and helping).
Any doubt? Did you found anything broken? Need help? Contact me through Discord with "frost16md"
