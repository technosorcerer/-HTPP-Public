To clarify the two patches:
(Basic) is for any vanilla Metroid ROM. It will overwrite all data that the original ROM had with relocated and new data.
(ExpandedROM) is for any Metroid ROM that has already been expanded to accommodate more space. This can be used on any ROM hack of choice as long as it's expanded.
Hacks with the older save patch and/or animated background are already expanded; otherwise, you can download the latest version of Editroid to expand hacks that aren't.
Both patches should give the same result. If you're unsure of which one to use, check the ROM size. Non-expanded should be ~128KB, expanded should be ~384 KB.

So, what do these .ips files add? (*NEW* means that they are features not present in version 0.4):
- Password system has been replaced with a functional, battery-based save system.
- Pausing now brings up a scrollable 7x7 minimap of all of Zebes.
- Ice and wave beams can now stack, meaning both can be used at once.
- Ice beam and bombs have been improved (by dealing more damage and having more control over, relatively).
- Walljumping akin to Zero Mission has been implemented.
- 3x3 minimap is displayed in the corner during gameplay.
- *NEW* UI has been fixed graphically.
- *NEW* Red doors now cost 1 rocket while yellow and purple doors cost 5.
- *NEW* Save anytime while paused by pressing Up + A (this sends you to the game over screen where you can save).
- *NEW* RNG has been reverted to its more varied Japanese counterpart, restoring missing enemy AI actions.
- *NEW* Door transitions have been sped up substantially (kudos to ShadowOne333 for improving this feature).
- *NEW* Clipping glitch while unmorphing fixed for hacking purposes (not in original game due to level design preventing it from occurring).
- *NEW* Continues refill all of your health, including energy tanks, instead of starting off at 30 HP every time.
- *NEW* Missile pickups now drop more frequently from enemies, and give you 5 missiles instead of 2.

Credit to Snarfblam for making the original Metroid + Saving patches, and MetConst as a whole for resources such as the disassembly.