Murder Club Girl Cute

NES "J.B. Harold Murder Club" IPS patch. Makes the face of a female character cute.

[Revision history]
- Created 28 Jul 2022
First edition created.

- Updated 20 Feb. 2024
Re-designed the GUI.
Slightly modified the female's faces.
Used Misaki font.
Changed password characters (Kana to Lower case alphabet).

EOF
