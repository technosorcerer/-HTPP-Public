Please use the patch on Mega Man 3 (USA) or Rockman 3 - Dr. Wily no Saigo! (Japan),


This patch replaces Shadow Blade with Screw Crusher from MMIII or MM10.


Something else.