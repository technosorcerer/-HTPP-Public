Megaman 3 Enemy Lifebar Hack source by bbitmaster

I originally made this hack back in 2002, but it was a little different then. Originally, I
expanded the rom and placed this in an empty bank. I even had the a *.bat file set up to
tell the x816 assembler to assemble it, and make a valid rom in one click.

This sat here on my hard drive for 2 years, but now I think I'll modify it a bit and release it.
along with the source code. This version is a bit different. Since with FCEUXD I now know where
all the free space in the rom is, I no longer have to expand the rom. I'll just manually
place it in some free space in the rom.

To apply this manualy, just assemble this file with x816 and place it at $1D110 in the
megaman3.nes file and change offset $3F2CB to A90E85F4206bFF20009160 which is machine code
to tell the game to jump to this assembled routine. Also change 3F2B9 to 06, and 3F2BE to 05.

Otherwise, just use the ips file.