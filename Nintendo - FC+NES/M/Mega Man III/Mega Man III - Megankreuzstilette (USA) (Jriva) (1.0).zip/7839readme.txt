Megankreuzstilette.
Jriva 2019-2023

It is a hack of Megaman 3 whose main novelty is the use of Megaman 3 Improvement. which allowed among other things:

-Different graphics for all stages

-Longer stages

-Animated graphics

-Multiple paths

-Different music in each of the 18 levels.

Its name is a clear allusion to Rosenkreuzstilette, because its theme will be medieval fantasy in the design of the stages.

For everything else, it is a vanilla hack, to enjoy Megaman 3 as always.

Visit my blog for more information on this and other projects.

http://megamanhyperion.blogspot.com/

Special Thanks: Kuja Killer for the Megaman 3 Improvement, the music, and a lot of help