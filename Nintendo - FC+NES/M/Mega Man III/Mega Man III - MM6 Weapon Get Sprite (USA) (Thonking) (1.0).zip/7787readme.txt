Patch is for MM3 not RM3.


Replaces the MM3 Weapon get sprite with MM6 Weapon get.


Enjoy!