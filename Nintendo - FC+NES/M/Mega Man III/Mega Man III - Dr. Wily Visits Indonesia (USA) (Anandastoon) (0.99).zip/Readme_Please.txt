++++++++++++++++
+ INTRODUCTION +
++++++++++++++++

---<(ASSALAMU'ALAIKUM WR. WB)>---

 I'm beginner hacker from Indonesia.
 My age is still 17 years old when I submitted this.

+++++++++++++++++++
+ GREAT THANKS TO +
+++++++++++++++++++

 1. Matrixz's MegaFLEX, CSA, and his "Capcom '6C80' Sound Engine/Music Format Documentation".
 2. A little bit datas from Kuja Killer.
 3. Rockman 3 Editor by Rock5Easily.
 4. YY-CHR, the great tile editor.
 5. FCEUX, great emulator for searching ASM datas.
 6. Narak-Narakmak and Insectduel as tester.
 7. RHDN, the great place of ROMHacks.

++++++++++++
+ PATCHING +
++++++++++++

 (I'm Indonesian, sorry for my English)
 Please patch this ips file into Mega Man III, not Rockman 3.

++++++++++++++++++++++
+ WHAT'S DIFFERENTS? +
++++++++++++++++++++++

---<( I. GRAPHIC )>---

 All level with new graphics and...
 Yes, some graphics which describing Indonesia and some tilesets made by me.
 It's really fun to change NES graphic.

---<( II. MUSIC AND SOUND )>---

 Urrgghh, hacking this section is a major nightmare for n00b like me.
 Really, I don't know any NES music ASM until I found Matrixz's document about
 "Capcom '6C80' Music Format Documentation" and some practices.
 Finally, changing the NES music is really, really, and really easy by translating
 notes one by one. But I'm very tired when adjusting the tempo, instrument and notes'
 transpose.
 And the musics from not compatible engine (so, I must open PianoRoll Editor to
 translating note one by one. Very easy even with jump, loop and break instruction...
 But kinda tired), they are :
  1. Mega Man 9 : Opening 3 (as get weapon)
  2. Mega Man 8 : Stage Select (as stage select. Uurrrgghh, Terrible ripping)
  3. Sonic The Hedgehog : Level Clear (as beating boss, with brutal tempo due its timing)
  4. Sonic The Hedgehog : Spring Yard Zone (as Needle Man stage. Sorry if it's terrible)
  5. Sonic The Hedgehog : Star Light Zone (as 1-2 Wily stage. Again, Sorry if it's crappy)
  6. Mega Man 2 : Quick Man's Stage (as Spark Man stage)
  7. Mega Man 1 : Final Boss (as 5-6 Wily stage, with drums up)
  8. Super Mario Bros. : Flagpole (as beating game. Honestly, it's kinda horrible in My MM3 hack)
 And all I use sound effect from MM5 (just 3 sound effects).

---<( III. LEVEL )>---

---<( IV. TEXT )>---

 The most text entirely changed in global language (English), althrough I'm suck at
 English grammar.

---<( V. GAMEPLAY )>---

 Major AI changed, more sliding and climbing speed, also some enemies' speed are brutal.
 But, my hack is easy enough. And there is many secrets in my hack, like you can kill
 Needle Man instantly by certain weapon at Needle Man's certain action. The weapons'
 AI are changed too (except Spark Shock).
 Finding these codes in FCEUX breakpoint are super duper easy. I've found many, many
 codes by reading RAM only and using Read/Write Breakpoints, myself. Especially the LDA,
 ADC, SBC, and STA instruction.

---<( VI. OTHER )>---

 - Faster vertical scrolling like MM5 (the original is slower)
 - Y register for sprite speed addition (variation horizontal speed)
 - No delay recovering (this is very painful to search the code)
 - Faster fading (by changing LDY value to 02)
 - MM5 teleportation method (for Rushes)
 - Sound Effect addition (MM5 Gravity Switch, MM5 Gravity Hold and MM5 Power Stone)
 - Maximum E-tank is just 5 (because the difficulty are easy enough)
 - The robot master area and weaknesses is all about my country, Indonesia (as knowledge)
 - Cannon sprite assembly from MM10 (extremely different)

+++++++++++++
+ KNOWN BUG +
+++++++++++++

 1. In parallax scroling (Original like Gemini Man's stage, but in my hack not) after you die,
    the background moved to the scary position while 'READY' appeared. But, it's actually
    an original bug, I mean, it really happen in Gemini Man's stage too.
 2. Original bug too, but cause with emulator, the pause menu gltched (perhaps because scanline
    read problem) in parallax scrolling and second battle with Gamma (cause by Gamma's Hand).
    Solved if you're use FCEUX emulator.
 3. If you're lucky, you'll see one frame graphical glitch happen in Wily 1 boss, and First gamma.
    The glitch happened when they're appearing. And moving rail too... (I guess it also from
    original)

+++++++++++
+ CONFIDE +
+++++++++++

 I'm sorry if my hack is terrible enough, because I just sharing what is in my mind and I just a
 n00b.
 Really, I don't know any ASM languages, and I just self-taught other ASM documentations. But it's
 very, very hard to applying in the NES rom, until FCEUX come with its breakpoints feature...
 My hack is easy enough to deal with, and I hope the new re-modified weapons are more useful than
 original ones.
 
 - Why v0.99 ?
 This is only for bugs. If you find bugs in my hack, report me immediately. I will improve it and
 change the version soon.

 ~Enjoy...

++++++++++++++
+ CHANGE LOG +
++++++++++++++

Not really a problem... Just improve the graphic error and music, especially from Sonic The Hedgehog,
and also enemy placements. 

+++++++++++
+ CONTACT +
+++++++++++
 
 1. http://www.facebook.com/Anandastoon
 2. mailto:anandastoon@gmail.com