This is hack for Mega Man 3 that implements the charging mechanic from later games (based off of MM5's in particular). Its code is a port from Mega Man 5, so it should be fairly accurate to that game. Unfortunately, the hitbox size for the charged shot is the same as the standard shot due to a limitation with MM3's engine where the same 8x8 hitbox is shared between all projectile weapons. This is something I might look into fixing in a future update.

Feel free to use this mod in your own MM3 projects, no credit is necessary.


6/18/25 1.1 UPDATE:
-Fixed a bug where entering a boss door would erase your charge.
-Implemented a fade out for the charging sound, ported from MetHy's MM5 Charge Shot Fade Out patch (https://www.romhacking.net/hacks/5066/).

10/26/25 1.2 UPDATE:
-Fixed some major bugs, including one that caused the hack to crash on more accurate emulators due to a small oversight I made when porting the code from MM5. I've tested the hack in Mesen it doesn't seem to crash anymore. The other bugs fixed were Spark Shock only freezing bosses instead of damaging them and the Charge Shot facing the wrong direction if you immediately turned around from slide and fired a Charge Shot.


Techincal information / Useful information for hackers:

-The code for chaging is stored at 0x40010-0x400F3 in the ROM.

-This hack uses RAM Address $76 for the charge counter.

-This hack overwrites the unused SFX IDs 0x21 and 0x29 and adds a new one, 0x41.

-The table for Mega Man's palette while charging is stored at 0x40280-0x40297. 

-The charged shot just adds two extra damage points to the damage dealt by the standard shot, something that should probably be kept in mind when editing damage tables.