++++ Angry Birds - Level hack by Googie ++++

I saw this on You Tube as Angry Birds 2, someone on there that goes by the name of maxzhou88 dumped the ROM. I like the premise of the game so I decided to hack it...

It's a short hack of about 12 levels, since you start at level 2 for some odd reason. There are a few tricky parts in this hack that'll keep you on your toes, but you won't bang your head on your keyboard. ;)

The only graphics I changed in the hack were the clouds, so they can stick out more. Well, enjoy this hack of Moai Kun! Moai Senpai was the editor I used to make this hack, the editor was created by Legato. 

~ Googie    