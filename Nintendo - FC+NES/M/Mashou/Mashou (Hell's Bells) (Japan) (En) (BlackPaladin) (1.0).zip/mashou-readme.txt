-----------------------------------------------
-BlackPaladin's Hell's Bells Translation Patch-
-----------------------------------------------

********
*Mashou*
********

Mashou is an action RPG, released by Irem in 1986.  You play the role of Prince Myer who must face against Rubas to protect his kingdom.

Rubas plan to ring seven bells to summons demons take over the kingdom of Willner.  Prior to his Prince Myer's coronation, he receives a message from a mysterious being, telling him that he must go to Rubas' castle in the northern mountains and burn down the seven bell towers and vanquish Rubas once and for all.

This game was released released in the United States under the name, "Deadly Towers".  This patch was made almost entirely out of boredom and curiosity.

This patch come in four flavors.

Hell's Bells (English).ips
--English translation patch for the Japanese ROM (IPS Patch)
Hell's Bells (English).bps
--English translation patch for the Japanese ROM (BPS Patch)
Hell's Bells B (English).ips
--English translation patch for the USA ROM (IPS Patch)
Hell's Bells B (English).bps
--English translation patch for the USA ROM (IPS Patch)

If you're using the Japanese ROM for patching, you'll need the ROM with the following hashes for either IPS or BPS "Hell's Bells (English)" patch.  (Don't use both patches.)

File SHA-1: 2F5CD17FE7895A88866058BC9E2989AEF92BBAB2
File CRC32: D288E8C0
ROM SHA-1: A6B1A2ACAE1E4034C5E048D1318541D67A86F17C
ROM CRC32: A21E675C

If you're using the USA Deadly Towers ROM for patching, you'll need the ROM with the following hashes for either IPS or BPS "Hell's Bells B (English)" patch.  (Again, don't use both patches.)

File SHA-1: 5954B8E3C45DE1EB3C98E2EF4C71D069C078CF79
File CRC32: B2E583AC
ROM SHA-1: 764C9A41DB58D9A0F8DD56499CF1EA84C10ADDF8
ROM CRC32: C2730C30

The end result should be the following patched ROM with the following hashes.

File SHA-1: BA6EA71A2F58ABF58AF39DE0ED18399421D313C8
File CRC32: F8D5B162
ROM SHA-1: 61D9797598F4E7DA75723B8F9568DF9D6199A6AA
ROM CRC32: 88433EFE

What's done

Translated Title Screen
New font applied
English intro and ending text re-written
Item Use/Throw Away messages translated
"Helmet" is renamed "Helm"
"Necklace" is renamed "Pendant"

Special Thanks
FCE Ultra Team (Emulator was used to test the translation patch)
Mesen Team (Emulator was used to test the translation patch)
Nestopia Team (Emulator was used to test the translation patch)
YY-Char Team (This program was used to edit the graphics in the game)
R-K (Beta Testing and Assitance)

All credits to "Hell's Bells" belong to their respective creators and programmers.  This patch is mainly for pure entertainment for those who cannot enjoy the game.  All right reserved.  (Irem, please don't come after me!)