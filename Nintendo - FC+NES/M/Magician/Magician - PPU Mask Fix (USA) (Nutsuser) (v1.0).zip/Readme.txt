~ Magician (PPU Mask Fix)
This hack fixes the dark image issue in Magician by disabling NES PPU color emphasis at the hardware level.
The game now displays with correct brightness on all levels, including shops and special screens, without altering palettes or gameplay logic. 

* Patch is intended for Magician (U) [!].

30.12.2025.
