Magic Johnson's Fast Break (NES)
Traducción al Español v1.0 (29/06/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Magic Johnson's Fast Break (USA).nes
MD5: 0f2d281dbf375db833fcd3644f9243a4
SHA1: 8aacb58a54986df80d93c8263ae88d5ee13771f2
CRC32: 4d42a98c
196624 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --