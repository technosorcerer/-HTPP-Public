Mystery Quest (NES)
Traducción al Español v1.0 (05/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mystery Quest (USA).nes
MD5: 84e59e49113d890c4a9364d30725ecc7
SHA1: 0c8c6c2085786131ae8e390560977d3041e49f4c
CRC32: faf994be
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --