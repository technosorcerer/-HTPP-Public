# NES Monopoly Quality of Life Patch

Made to fix issues and feature a 2008-style ruleset and look

Proudly ROM Hacked by Devan Wolf of Sobble Entertainment Inc.

Requires: Monopoly (U) [!]
### Fixes:
* Insufficient Rent/Luxury Tax Skip Exploit Workaround: don't check for control pad, only check for A/B/Start to return to board overview (EYOEEENY)
* Correction: $200 from Vermont and Oriental Avenue have O instead of 0 (PANUOKPP+PANUXKPP+PEELSKPP+PEELVKPP)
* Added missing pixels from Chance and GO tiles of board overview
### International-based Changes:
* Removed 10% option from Income Tax (now a flat $200)
* Luxury Tax increased from $75 to $100 (IOOAVKZO)
* Changed color group of Mediterranean and Baltic Avenue from Purple to Brown
* Changed color of GO from Red to Black
* Changed $ symbol to the Monopoly Dollar standard
* Renamed "Parker Brothers Real Estate" to "Fast-Dealing Property"

A separate "skip legal screen" version is also available for those who hate that 4-second nag. Alternatively, use Game Genie code AAOZUOXY (Thanks Brad Corrupts).

![](titlescreen.png) ![](screenshot1.png) ![](screenshot2.png) ![](screenshot3.png)