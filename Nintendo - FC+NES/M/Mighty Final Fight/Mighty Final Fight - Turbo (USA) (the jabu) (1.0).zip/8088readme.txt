          Mighty Final Fight Turbo  V 1.0/ hack by The Jabu    2023
      ---------------------------------------------------------------------
    In celebration of Mighty Final Fight's 30th anniversary, this hack simplifies the special attack
    commands,making them easier to execute and available from the start of the game, and changes
    some details on sprites and palettes.

      
   

    Changes:

   - Changed special attack commands.
   - Added Haggar's Hammer Attack.
   - Special attacks are available from the beginning of the game. 
   - Minor sprite changes.
   - Changed level palettes. 
  
 

   SPECIAL ATTACKS:

 CODY
  
 Tornado Sweep : Press B , then FORWARD (almost at the same time)

 uppercut : While Cody is charging the Tornado Sweep, press UP for an Uppercut or
             press DOWN for an  Uppercut in the opposite direction.
  


 GUY

 Tornado kick: Press B , then FORWARD (almost at the same time). Hold the B button
           until the tornado kick ends to perform a Flying Kick in the opposite direction.

 Flying  Kick: Jump and press BACK and hold the B button until you land. 
               If you perform the Flying Kick correctly, hold UP to perform a Flash Kick when
               you land.



 HAGGAR

 Running Clothesline: Press B and then FORWARD (almost at the same time).

 Hammer Attack: while performing a Running Clothesline, press DOWN at any time during the move.
   





  Apply the IPS file to " Mighty Final Fight (USA).nes" and have fun!!!

    

   