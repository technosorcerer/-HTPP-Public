Mega Man FamiTracker Patch
v1.0

By Justin Olbrantz (Quantam)

The mm1ft patch adds FamiTracker Module playback support to Mega Man/Rockman, both making it far easier to compose and import custom music for hacks and providing a far more powerful sound engine. This engine is added on top of the Capcom 2 sound engine used by MM/RM, and both C2 and FT format music may be used in a single hack.

Basic Features:
- Support for FamiTracker Modules as implemented by bhop (https://github.com/zeta0134/bhop)
  - Supports basic FT features including channel volume, instruments, volume/pitch/arpeggio/mode envelopes, true tempo, etc.
  - Supports effects 0 (arpeggio), 1/2 (pitch slide), 3 (portamento), 4 (vibrato), 7 (tremolo), A (volume slide), B (go to order), C (halt), D (go to row in next order), F (speed/tempo), G (note delay), L (delayed release), P (fine pitch), Q/R (pitch slide to note), S (delayed cut), V (mode), Y (DPCM sample offset), Z (DPCM delta counter)
  - Supports all base (2A03) channels except DPCM
  - Does NOT support expansion chips, linear pitch mode, hi-pitch envelopes, or effects E (old-style volume), EE (toggle hardware envelope/length counter), E (length counter), H/I (hardware sweep), M (delayed volume), S (set linear counter), T (delayed transpose), W (DPCM pitch), X (DPCM retrigger)
- Supports unique tracks for all Wily stages
- Supports stage-specific boss music
- Multi-bank support for both FT and C2 music (but not SFX)
- Expands ROM size to 256 KB, almost half of which is available for music and other hacks
- Expands the track table to 80 entries, leaving 27 new track numbers available for hack-specific purposes
- Incorporates mm1spritelag to help offset the increased CPU usage

HOW IT WORKS

The basic principle of operation of mm1ft is simple. mm1ft runs both the original sound engine and bhop in parallel, mixing the output based on which engine is playing and which channels are currently in use by sound effects (which always use the C2 sound engine).

Under the hood, mm1ft adds a second track table: the track map table. This table specifies 4 key pieces of information: what ROM bank the track is in, where in the bank the module/track begins, which track index within that module the track is (though for C2 tracks it's simply the track's index in the C2 track address table), and which engine to use to play it. The details are not relevant to most users, so it won't be described further.

CAVEATS

The 1 notable caveat of mm1ft is that it uses additional CPU as compared to the C2 sound engine; FamiTracker is much more powerful than the C2 engine, and that power isn't free. Further work needs to be done to fully understand the performance of bhop vs C2 and how FT tracks can be written to minimize CPU usage, but mm1ft typically adds about 5% total CPU usage when playing an FT track compared to playing a C2 track. To partially offset this increase, mm1ft incorporates mm1spritelag, a patch that reduces CPU usage related to the sprite buffer by about 3%.

Why Not MMC3?

Unlike mm2ft, mm1ft continues to use the UxROM mapper of the original game, which prevents some of the value-added features present in mm2ft. This decision was made for performance reasons. The MMC1 mapper used by MM2 is very inefficient and changing banks takes much more time than on UxROM and slightly more time than on MMC3. This meant that not only could MM2 be converted to a more powerful mapper but doing so would be a slight performance improvement as well. In contrast, converting MM from UxROM to MMC3 would add significant slowdown (several % of the CPU), and MM lacks the gross sprite buffer inefficiency that allowed the MM2 Sprite Lag Reduction patch to trivially free up a massive 8% of the CPU (the MM equivalent of that patch only reduces it by 3%). Thus the decision was made to favor speed over power, and mm1ft was left UxROM.

REQUIREMENTS

Mega Man (USA):
PRG-ROM CRC32 6EE4BB0A / MD5 4DE82CFCEADBF1A5E693B669B1221107
File CRC32 5DED683E / MD5 4D4FFDFE7979B5F06DEC2CF3563440AD

Rockman (Japan):
PRG-ROM CRC32 D31DC910 / MD5 8D5A61F42D92EE61D05083263A11FCA1
File CRC32 E0141A24 / MD5 8824842070A569E9BA7287BCDEA045A3

The makeftrom utility (https://www.romhacking.net/utilities/1800/) is used to import music. Note that some of the mm1ft files (in particular the .ftcfg files) are required by makeftrom to produce mm1ft ROMs.

Additionally, while the easiest way to patch is to simply use the RHDN online patcher, offline patching can be done with a BPS patching utility such as beat, Floating IPS, and others.

PATCHING

mm1ft contains two pairs of patches: mm1ft.bps and mm1ftdemo.bps, applied to the US Mega Man, and their Rockman equivalents e.g. rm1ft.bps. mm1ft.bps produces mm1ft.nes, which is the base that will be used for further hacking, including importing music via makeftrom. mm1ftdemo.bps produces a playable demo that replaces many of the game's tracks with assorted different music; this demo 1. includes the changes from mm1ft.bps, and 2. cannot be used for further hacking as makeftrom cannot be run on a file that already has imported music.

The simplest way to apply these patches is to simply use the RHDN "Patch Online Now" function.

Additionally, mm1ft comes with another small patch: mm1enabletitle.ips (and its rm1 equivalent). When applied on top of mm1ft.nes this patch enables title screen music (by default mm1ft.nes has this turned off to match the original game).

COMPATIBILITY

Care must be taken when combining mm1ft with other, non-music changes.

mm1ft substantially reorganizes the MM track data. While the bank 4 level data, C2 engine code, and track address table are in their original locations, all music and SFX tracks have been moved around within the bank.

Additionally, UxROM, like most other mappers, requires the common bank (addresses c000-ffff) to be the final bank in the ROM. As such, in addition to any specific changes, the ENTIRE 1c010-2000f file region (bank 7) has been relocated to 3c010-4000f (bank $f). As such, ANY other hack that modifies the 1c010-2000f region will not work when patched, as the patch is modifying the wrong location. However, many of these hacks should work correctly when manually applied to the proper new locations.

mm1ft/mm1spritelag use the following RAM ranges that were previously free:
- 50-51 (used as NMI temporaries and maybe be used elsewhere in the NMI)
- c1
- f6-fb
- 100-1d1
- 3a3-3bd ($12 bytes left)
- 7b1-7f6 (9 left)

mm1ft/mm1spritelag use the following ROM ranges that were previously free:
- 13e70-13fd6 (3a left)
- 17f86-18002 (d left)
- All of new bank 7
- 3ff10-3ff37 (b8 left)

As well, mm1ft/mm1spritelag free up the following ROM ranges:
- 3d573-3d57d (b bytes)

Finally, mm1ft/mm1spritelag substantially modify the following ROM ranges in a way that may break compatibility:
- 1d14c-1d150
- 3c018-3c02a
- 3d55c-3d572
- 4000c-4000f

PRODUCING DERIVATIVE HACKS

The general process of producing hacks using mm1ft looks like this:
1. Hacking done prior to applying mm1ft.bps (optional). Any such hacking can increase the chance of conflicts with mm1ft.bps, but for projects that already have work done, it's probably preferable to not start again from scratch. But do make sure to save a copy before applying mm1ft.bps, in case patch conflicts arise and suddenly your work in progress ROM no longer works.
2. Apply mm1ft.bps
3. Apply mm1enabletitle.bps if title screen music is desired (optional). Fire Man's track is used as the placeholder for the title screen music.
4. Further non-music hacking (optional)
5. Run makeftrom to import the music

This order is important because makeftrom cannot be run on a ROM that already has imported music, and as such it must either be the last step in the process or you must preserve a copy of the pre-makeftrom ROM you can use to continue your hacking work after doing a test run with makeftrom.

Most of the process of using makeftrom is left to the makeftrom user guide, but there are a couple important pieces of information.

The MM-specific list of track names that can be assigned using makeftrom; it is not necessary to know the track numbers, they are provided simply to allow those already familiar with MM track numbers to associate them with their names:
0: GameClear
1: StageSelect
2: StageSelected
3: GameOver
4: StageClear
5: CutMan
6: Title
7: FireMan
8: BombMan
9: ElecMan
a: GutsMan
b: WilyBoss
c: Wily1
d: Boss
e: Ending
f: IceMan
10: Wily3
33: Wily2
34: Wily4

As can be seen, track 6 is designated Title. In the original game this is an unused copy of Fire Man's stage, but if the optional title screen music enable patch is applied, this will play as the title screen music.

Additionally, tracks 35-4f are unused and can be used for boss tracks or any other purpose that may be hacked into the game. These tracks have names, e.g. Track35 and Track4f.

As well, the following boss fight names may have music assigned to them in the boss_track_map section:
CutMan
IceMan
BombMan
FireMan
ElecMan
GutsMan
Wily1
Wily2
Wily3
Wily4

These boss names apply to the bosses in their own stages only; mm1ft does not add music to refights.

Finally, please mention the use of mm1ft wherever you list credits for your hack.

BUGS

- Bugs or incomplete features may exist in bhop. The most noticeable known issue is that bhop does not currently implement pitch effects (e.g. pitch slide) on the noise channel. This causes some drum sounds to sound incorrect. This can be worked around using pitch or arpeggio envelopes instead.

CREDITS

Research, reverse-engineering, and programming: Justin Olbrantz (Quantam)
Music used by the demo: cookiefonster, SUPAH METUL, others

Thanks to the NesDev and Classic Mega Man Science communities for the occasional piece of information or advice.

VERSION HISTORY
v1.0
- Update bhop to version 964e31de
- Support multiple FTMs per bank for much greater FT music capacity
- Support different music for all stages including Wily stages
- Support stage-specific boss music
- More than double the max number of music tracks
- Fix "long tink" bug
- Switch to BPS patch format due to better support on RHDN
