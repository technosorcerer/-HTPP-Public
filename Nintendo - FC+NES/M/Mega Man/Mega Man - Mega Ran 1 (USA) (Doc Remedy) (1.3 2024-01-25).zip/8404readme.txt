Created by Doc Remedy

Utilities Used:
Rock and Roll Editor
yychr
HxD

Description : Mega Man is now Mega Ran for starters! Mainly a graphic hack, some level redesign and Boss weakness changes with secondary weaknesses were applied. An homage to one of the coolest people in the Nerdcore community, Mega Ran.  It was only fitting to customize the original Mega Man (and more to follow?) around the legacy.  Enjoy!


Special Thanks to ROMHACKINg.net submission personnel who recommended I change HEX #08 to HEX #18 on the skin tones.

Application Type: IPS Patch fo Origninal ROM

Version 1.3

Mega Ran 1 Hack v1.3 Changelog
-Redrew all the sprites for Mega Ran and gave him a new fresh look from version 1.2
-Swapped color palette positions for Life Capsules since they mirror the palette used for "skin tones" and the skin tone change to Mega Ran gave them a brown look.
-Redrew the Mega Ran 1-Up Icon, both, in game and the "Lives" icon in the Weapon Menu. Also redrew the weapon icons from solid black silhouettes I had in v1.2 to black and white 2-tone icons.
-Weapon color palettes changed a little since version 1.2 for most the weapons.  Elec Man's Thunder Beam now also resembles the original Electro costume (Spider-Man villain) color scheme just as the stage palettes were changed in v1.2
-Made minor changes to stages for Elec Man, Guts Man and Ice Man.
-Rebalanced some of the enemy weaknesses and secondary weaknesses.


Mega Ran 1 Hack v1.2 Changelog
- Mega Man is now Mega Ran for starters! Some enemy sprites use the same color palette so making Mega Man into Mega Ran changed their skin tones as well.
- The colors Mega Ran changes into while having a weapon active have changed.  Like the Magnet Beam being the same colors as the M Buster always annoyed me.  A few others too like Guts Man's Super Arm now favoring Incredible Hulk colors!
- Life and Energy drop graphics have been updated to the ones used in Mega Man 2 and beyond for continuity.  The Mega Man 1 versions are just weird!
- Minor changes and re-balance has been done to Boss Weaknesses including some weapons acting as secondary weaknesses or even NULL damage.  Some of the original bugged me!
- Changed the Weapon letters in the start menu to simple icons, also something that bugged me from the original
- Most stages have new color palettes, slight structure revamping or new small puzzles to explore.  The ElecMan stage colors were inspired by the original Electro costume (Spider-Man villain) and most the game has a darker color feel now.  I did NOT dive in and edit the actual graphics themselves, just colors palettes.  
- There are a few minor glitches you'll find as well, but oh well, this was a quick fun hack to pay respect to my friend Mega Ran who deserves this hack to enjoy!