Mega Man - Restore Health with Score Points and Instant Glitch Hack by magusRE
----------------------------------------
This Hack adds a function to restore your Health at any point in the game like the E-Tanks in later Mega Man Games do but for a certain number of Score Points similar to Duck Tales with the Money and changes the Pause Glitch to be instantly without pausing/unpausing the game.

It works with all versions of the game (Japan, USA, Europe) and is compatible with some hacks which haven't removed the Score Points and Pause function. It comes in 3 variation, 300k, 200k and 100k Score Points requirement for restoring Health.

To restore your Health, hold Dpad UP and press Select.

Duck Tales and how the restoring Health works in this game by paying 300k Money for full Health was the inspiration behind creating this hack.

--------------------
Required ROM:
--------------------
Database match: Rockman (Japan) (En)
Database: No-Intro: Nintendo Entertainment System (v. 20210216-231042)
File SHA-1: A62F997DA28E2776DC4FE7B6A32F9179E971E4C0
File CRC32: 77D3C5F8
ROM SHA-1: EA93F3F2FD561C1CEE59AD51CFCB10F3DD83766F
ROM CRC32: D31DC910

Database match: Mega Man (USA)
Database: No-Intro: Nintendo Entertainment System (v. 20210216-231042)
File SHA-1: 51A9FE7B5CB82833FC416E0F29B965495D9CE49A
File CRC32: CA2AB7E2
ROM SHA-1: 6047E52929DFE8ED4708D325766CCB8D3D583C7D
ROM CRC32: 6EE4BB0A

Database match: Mega Man (Europe)
Database: No-Intro: Nintendo Entertainment System (v. 20210216-231042)
File SHA-1: 061D59D52E816600DB1BCEEC0321A3A9AB9F0CFA
File CRC32: 700A69C7
ROM SHA-1: FDB6818E0EFCBBD33CB9D17F1CCA251734E268A5
ROM CRC32: 94476A70

--------------------
Thanks and Credits:
--------------------
www.romhacking.net