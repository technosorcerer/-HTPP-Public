Ms. Pac-Man (Tengen) (NES)
Traducción al Español v1.0 (17/09/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ms. Pac-Man (USA) (Unl).nes
MD5: 56d7922eb5fc9a31b8addaef400deedf
SHA1: 93010514aa1300499abc8f145d6abcdbf3084090
CRC32: a4a116f1
40976 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --