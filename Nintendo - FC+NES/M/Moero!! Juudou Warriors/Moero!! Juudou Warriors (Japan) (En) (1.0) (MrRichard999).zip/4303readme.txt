Moero!! Juudou Warriors ENGLISH Translation Patch
Version 1.0
3/7/2019

Modified by MrRichard999
Translations by TheMajinZenki
Title Screen by FlashPV

Here is a full English translation for Moero!! Juudou Warriors. All the dialogues, menus, and text.

Currently the password system still retains the Japanese characters over the letters but everything else is complete!


Please apply the BPS patch to the following ROM with the matching hash info below.

Moero!! Juudou Warriors (Japan)
CRC32: 0A186CD1
MD5: 8A1B591D066AFEA9010EA40F52090568
SHA-1: 31BDA7025CDD017C55CC3A44DC03BE2EC50B4A42
SHA-256: 670A9A05B01236312E08F03E6E6617C6794B8D12FE7D60DAC6A12933121F223D
