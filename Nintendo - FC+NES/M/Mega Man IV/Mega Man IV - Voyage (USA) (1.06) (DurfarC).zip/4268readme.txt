Mega Man 4 Voyage
Version 1.06
- by DurfarC, MartsINY, Golden-Shades, RRThiel et al.
(Readme written by DurfarC)
--------------------------------------------------

This is a ROM hack of Capcom's Mega Man 4 for the NES. All levels have been completely redesigned, new music has been composed, graphics have been changed, weapons have been altered, existing enemies and bosses have been edited and some new enemies, bosses, items and stage gimmicks have been programmed from scratch.

Mega Man 4 Voyage strives to be one of the most extensive Mega Man ROM hacks to be 100% completed and released to date, with an original storyline, new places to explore, reprogrammed robot master AIs, new fortress bosses and an enormous soundtrack with almost 40 original songs to accompany it all. At the same time, it still tries to stick to the "run, jump and shoot" formula of the original classic Mega Man games. The hack should be suitable for veterans and casual players alike; it is more difficult than the original Mega Man 4, but easier than most other ROM hacks and fan games out there.

What started as a one-man project has resulted in a fine collaboration between DurfarC (main author, level design, programming, music), MartsINY (main boss designer, programming) and chiptune composers Golden Shades, RRThiel, Cosmic Gem and MarkTherence. Furthermore, the hack incorporates patches, programming assets and graphics from a wide range of people.

----
------
--------

CONTENTS:

1. VERSION HISTORY
2. BACKGROUND
3. HOW TO PLAY
4. STORY
5. GAMEPLAY CHANGES
---CAUTION: The following sections contain direct or indirect spoilers, read them later if you want to explore and discover everything by yourself---
6. WEAPONS
7. FAQ
8. KNOWN BUGS/GLITCHES/PROBLEMS
9. LIST OF BOSSES (+ authors)
10. LIST OF NEW SONGS (+ authors)
11. CREDITS/THANKS TO
12. CONTACT / FOLLOW
13. DISCLAIMER

--------
------
----

1. Version history:

Version 1.06 (7 Feb, 2019)
- Wily Machine 3 was unbeatable in the previous version. When defeated, the game would glitch.

Version 1.05 (28 Jan, 2019)
- Pausing the game after Suzak & Fenix were killed could sometimes mess up the graphics a bit
- Rush Jet flashes before disappearing during the Mecha Dragon fight, to warn the player.
- Wily Machine phase 2 can't spawn a flash stopper orb if Mega Man is already frozen.
- Mega Man doesn't have to go that far to activate Wily Machine phase 2's ground pound anymore.
- Pharaoh Shot kills Wily Capsule phase 2's skull bomb in one hit instead of two.

Version 1.04 (1 Jan, 2019)
- All unused gamepad #2 inputs would bring up the pause menu in version 1.03.
- Using gamepad #2 for weapon switching in force beam areas could result in glitched weapon projectiles for a few seconds.

Version 1.03 (27 Dec, 2018)
- New feature: The A and B buttons for gamepad #2 can now switch weapons just like the select button
- Health and weapon energy now fill up instantly
- Wily 1-4 boss room has been changed to make it more obvious that you can slide
- Dive Man could, under extremely specific circumstances, crash the game
- The red Concrete Platforms could sometimes clip Mega Man to the absolute bottom of the screen
- Skull Shield now disappears if Mega Man dies
- Skull Shield didn't kill Wall Blasters instantly (like it kills every other enemy in the game)
- Wily 1-2 boss is now immune to Pharaoh Gust
- Rush Coil will now only work when Mega Man jumps on top of him (in the original game, you could just walk into Rush Coil and Mega Man would still jump)

Version 1.02 (16 Dec, 2018)
- Fixed a bug associated with Wily Alien (in Wily 1-4) getting killed at the same time as Mega Man is damaged
- If Flash Stopper had just been used when Mega Man Clone's phase 1 (in Wily 2-1) was killed, the colors would get stuck at the color pallette of the Flash Stopper's flash
- Mega Man Clone's Drill Blaster attack has been slowed down a few frames
- Skull Shield didn't work on Mega Man Clone's brick blocks, even though it's his weakness
- Skull Shield also didn't work on Shadow Man Archive's Shadow Blade, even though it's his weakness
- If you jumped and then started falling right before entering Mecha Dragon's boss room door, Mega Man would die instead of getting rescued by Rush Jet
- Dive Missile restored to how it was in v1.0 (and in the original game) because of unexpected problems
- Suspicious looking pit in the Hover + Battonton room in Drill Man's stage was removed
- Reduced Drill Man's Drill bomb's hitbox slightly
- Reduced Drill-in-a-box's hitbox a tiny bit

Version 1.01 (14 Dec, 2018)
- Moving ceiling in Wily 2-2 could kill Mega Man even though he stood clear and shouldn't get crushed.
- Dive Missile now homes in on enemies even if they're immune to it
- Final laser room in Wily 2-2 has spikes on the floor now, to make it more obvious that going further down means instant death
- Arrow markers for rocks etc. were centered

Version 1.0 (13 Dec, 2018)
- Initial release

------

2. Background:

When I completed my last hack in 2011 (Mega Man 3: The Battle of Gamma), I decided that next time I make a Mega Man hack, I should try to make some more changes to it than the usual stuff. My plan back then was to create not only new levels and music, but also change the graphics and do some minor changes to the enemies, such as editing speed and damage settings. Making more changes than that would require learning the programming language of the NES, something I never ever thought I would have time, skills and patience to accomplish. However, in one cold and snowy january, I decided to give the so-called 6502 assembly language a go anyway, and in combination with pre-existing, heavy documentation on Mega Man 4, I started to get some results, slowly but surely.

As time went by, however, not only did my programming knowledge increase, but so did my own as well as everyone else's expectations for the final product. If MM4 Voyage was to become as extensive as I wanted, I would need help. Luckily, in early 2017, expert programmer MartsINY offered to join in, designing and programming most robot masters and fortress bosses, as well as helping me get rid of many bugs and annoyances. At the same time, I involved chiptune composers Golden Shades, RRThiel, Cosmic Gem and MarkTherence to help me with the soundtrack. Their contributions, however, raised the bars even higher, so I had to go back and improve some of my older level design and graphics usage, delaying the hack's release further.

It's now late 2018, and almost 7 years of joy and frustration, smiles and tears are over: Mega Man 4 Voyage is finally completed! The hack is not revolutionary like Rockman 4 Minus Infinity or all the fan games that popped up for the last few years, but it certainly does change more than the average hack, so I hope it can entertain you anyway, just a little bit.

The difficulty level of this hack is obviously a bit higher than that of the original Mega Man 4. However, as this hack has its main focus on new contents rather than difficulty, the level design shouldn't be as unforgiving as in my older hacks. I tried to make the hack hard enough for some challenge, but not so hard that people must use save states to complete it. This means that there are no rooms you can't get past without taking damage, no traps that are totally non-obvious and no extremely tight jumps that cannot be bypassed in an alternative manner.

During the process of making the hack I have received so much help and support from the ROM hacking community and the Mega Man community, something I'm extremely thankful for. Special thanks go to not only the co-authors, but also the people behind editors, documents, patches and graphics that I used, as well as all those who came to me with various ideas and suggestions. Please take the time to read the credits section in this document after playing; it's important to me that everyone is noticed!

------

3. How to play:

Keep in mind that this is a ROM hack, not a standalone fan game with an exe file. In order to play it, you will need:
- An original, unmodified Mega Man 4 ROM (NTSC/USA version, not Rockman 4!)
- An NES emulator (I highly recommend using FCEUX. Nestopia is also fine. Other emulators display some colors quite differently)
- An IPS patching software (I recommend Lunar IPS or Floating IPS)
- The IPS file you just downloaded

Make a copy of the original, unmodified ROM, rename it if you wish and patch the IPS file to the newly created file with the IPS patching software. Open your NES emulator and load the ROM, and you're ready to go!

------

4. Story:

Dr. Wily is at it again, and is attempting to take over the world once more. He felt that Dr. Cossack's old robots, which Mega Man defeated earlier, had further potential, and decided to repair and upgrade them and send them to different corners of the world to wreak havoc. Once again, Mega Man has to go on a journey - a voyage - to stop them. What kind of nasty surprises will Mega Man encounter this time?

------

5. Gameplay changes:

A few minor changes have been made to the game engine:

- The select button can be used to switch weapons without the use of the pause menu. Pressing select alone switches to the next weapon (in pause menu order), pressing select while holding down switches to the previous weapon and pressing start while holding select switches directly to the Mega Buster. Alternatively, the A and B buttons on the NES's gamepad #2 can do the same; if you play on an emulator, have an USB gamepad with more buttons than the original NES gamepad and are used to back and forth-weaponswitching from fan games, just set gamepad #2's A and B inputs to the same USB gamepad as your normal, gamepad #1 inputs.
- The charge shot has been edited to match the one in Mega Man 5. This means that its hitbox is bigger, but it also means that taking damage will reset the charge counter.
- Pausing while riding Rush Marine is safe (unless you select a different weapon).
- Rush Marine consumes far less weapon energy than in the original game, making it more useful in Dive Man's stage. Riding Rush Marine is also a requirement in one of the castle stages, so it helps there as well.

------

6. Weapons:

- Bright Flash: Summons a bright flash which stops most enemies in their place for a few seconds, just like in the original game. However, it also has an additional function; it can relight dark areas.
- Rain Flush: A screen clearing weapon, same as in the original game, but it's more powerful now and therefore consumes more weapon energy than before.
- Drill Blaster: The strongest weapon of them all. It kills all normal enemies in one or two hits. It also pierces through shields.
- Pharaoh Gust: A fast, automatic weapon that can be fired in 6 different directions.
- Ring Orbiter: Sends out a ring that goes around you in circles. You can hold the B button for continous use.
- Dust Spread: Sends 4 pieces of dust forward. The dust needs half a second to separate into these 4 pieces.
- Dive Missile: Homes in on enemies just like in the original game, but it's faster and more precise than before.
- Skull Shield: A shield weapon that never disappears unless its weapon energy is out or Mega Man walks into an invincible or shielded enemy. It will insta-kill all normal enemies, using as much weapon energy as that particular enemy's HP.

7. FAQ:

You might have questions about how how you solve this, how I did this or that or how I came up with this and that. For your convenience, here's a small list of random questions you might have, and my answers to them:

Q: Why does the charge shot reset when you get hit by an enemy? It doesn't do that in the original game?
A: This is because I prefer the Mega Man 5 edition of the charge shot over MM4s. As expected, I think the bigger shot from MM5 is better looking and more useful against enemies with small hitboxes. However, if the charge shot does NOT reset when taking damage, there's never a reason to NOT use it. With the MM5 edition of the charge shot, the player has to think through whether it's sensible to charge or use normal shots for each and every situation.

Q: Why is Toad Man's level an ice level?
A: When I started working on the hack I didn't care about the stage and robot master themes not matching, as I was simply going for new levels with new graphics. When the project became more ambitious I made sure that the other robot masters got a more fitting environment, but since Toad Man's level was already done I didn't really want to revert it, as I did want an ice level in my hack. I also thought about renaming and redrawing all the robot masters, but since I'm not a good sprite artist I quickly decided not to do so.

Q: Game developers almost always make their games in less than 7 years. How can you use such a long time on a simple ROM hack?
A: The reasons are many: Real life, full time job, friends and family, other interests, gaming fatigue. Still, I spent a lot - A LOT - of my free time on Voyage. Do keep in mind that what would take 5 minutes in Game Maker (which most modern MM fan games are made in), might take hours or even days to edit in a ROM. Even something as simple as the introduction screens for the Wily castles, including their paths, took like 10-20 hours to make. Other tedious tasks include, but are not limited to, sprite assembly and music conversion.

Q: What documentation did you use in order to change as much in the hack as you did?
A: Check http://www.romhacking.net/ for Matrixz and MartsINY's MM4 Comprehensive Document. I also used some documents by Infidelity, showing where various enemy parameters such as speed, HP etc. are located. I can't remember where I got them, but you might be able to find them with a Google search.

Q: How did you make enemy X? Can you help me put enemy X in my hack?
A: Unfortunately, probably not. Not because I do not want to help, but simply because I didn't document any of the programming I did, and as time has passed I have forgotten where nearly everything I made is located in the ROM or how it works. Actually I do have a few notes, but looking at them today, they all look like gibberish even to me (lots of numbers here and there and barely any descriptions of what things mean - and it's all in Norwegian anyway). This is something I regret today, and if I can recommend something to fellow ROM hackers, it is that you should always, always document what you are doing - it will make continuing where you left off at some point ten times easier. If you should have any questions about the game mechanics you can contact me (look further down this document) and ask anyway: I don't mind being asked at all, just don't count on a very helpful answer.

------

8. Known bugs/glitches/problems:

- The password system doesn't save the acquisition of the energy balancer, so if you decide to use passwords as a means of saving the game and then continue on playing later, you will have to re-fetch it. Since we all play on emulators these days and use save states if we want to continue on playing later, I found it unnecessary to learn how the password data works only because of this.

------

9. List of bosses:

Below is a list of all the bosses in the hack, and who designed and programmed them.

- Bright Man: DurfarC
- Toad Man: DurfarC and MartsINY (leaf attack)
- Drill Man: MartsINY
- Pharaoh Man: MartsINY
- Ring Man: MartsINY
- Dust Man: MartsINY
- Dive Man: MartsINY
- Skull Man: DurfarC
------
- Old Skull Castle 1 boss: MartsINY
- Old Skull Castle 2 bosses: MartsINY
- Old Skull Castle 3 bosses: MartsINY
- Old Skull Castle 4 boss: MartsINY
- New Skull Castle 1 boss: MartsINY
- New Skull Castle 2 bosses: MartsINY
- New Skull Castle 3 boss: DurfarC (movement) and MartsINY (weapons and projectiles)
- New Skull Castle 4 boss: DurfarC (phase 1) and MartsINY (phase 2)

------

10. List of songs:

Below is a list of all the music in the hack, and their composers.

- Intro 1: Golden Shades
- Intro 2: DurfarC
- Title screen: Golden Shades
- Password: Golden Shades
- Stage select: Cosmic Gem
- Stage selected: DurfarC & Golden Shades
- Boss fight: RRThiel
- Victory: Golden Shades
- Weapon get: RRThiel
- Game over: DurfarC
- Balloon/Wire pickup: Golden Shades
------
- Bright Man: RRThiel
- Toad Man: DurfarC
- Drill Man: Golden Shades & DurfarC
- Pharaoh Man: DurfarC
- Ring Man: DurfarC
- Dust Man: MarkTherence
- Dive Man: DurfarC
- Skull Man: DurfarC
------
- Hidden areas: RRThiel
------
- Old Skull Castle 1: DurfarC
- Old Skull Castle 2: DurfarC
- Old Skull Castle 3: DurfarC
- Old Skull Castle 4: DurfarC
- New Skull Castle 1: DurfarC
- New Skull Castle 2: Golden Shades
- New Skull Castle 3: Golden Shades
- New Skull Castle 4: Golden Shades
------
- Old Skull Castle intro: DurfarC
- Old Skull Castle boss fights: RRThiel
- Wily Alien fight: RRThiel
- Dr. Wily appears: Cosmic Gem
- New Skull Castle intro: Golden Shades
- New Skull Castle boss fights: RRThiel
- Wily Machine: Golden Shades
- Final battle: Golden Shades
- Victory over Wily: Golden Shades
- Epilogue: Golden Shades
- Ending 1: DurfarC
- Ending 2: Golden Shades & RRThiel

Note: All the songs have been converted to ROM format by me, based on the composers' original FamiTracker arrangements. I tried to recreate them as accurately as possible, but since the music data in a ROM works differently from FamiTracker modules, they will not sound exactly the same.

------

11. Credits/Thanks to:

CREDITS
- DurfarC - Main author, programming, level design, music, a few bosses
- MartsINY - Main boss programmer, programming, minor level design, quality control
- Golden Shades - Music, testing
- RRThiel - Music, testing
- Cosmic Gem - Music
- MarkTherence - Music

As stated earlier, this hack has lots of indirect contributors and wouldn't be posssible without the help and generosity of others. Below is a list of people who have either directly helped me out, shared documents and enhancement patches on their websites or romhacking.net for everyone to use or just inspired me in general. I really hope I have remembered everyone (though I don't necessarily remember what everyone helped me with), but should you feel that you are missing from this list, don't hesistate to contact me.

Once again, special thanks go to the following people and websites:

UTILITIES/PROGRAMMING
- Matrixz - For making MegaFLE X and the text documents I used in order to learn how the game mechanics and music format work
- Puresabe - For his Rockman 4 enhancement patches that, among other things, improve the game performance, fix a lot of bugs and add the weapon switch function to the select button
- MartsINY - For his Capcom Music Editor (for MM3-6) that I used to arrange many of the songs into the ROM
- Rock5easily - For his Rockman 4 enhancement patches that had with scrolling and some other effects to do
- infidelity - For useful documents on enemies and bosses
- Kuja Killer - Co-author of Mega FLE X and always helpful and supportive
- Insectduel - For some pause menu and invisible block code

GRAPHICS
- Mega Man 1-6, 9 and 10
- Various NES games, including:
	- Batman
	- Batman - Return of the Joker
	- Bionic Commando
	- Blaster Master
	- James Bond Jr.
	- Little Mermaid
	- Power Blade
	- Shatterhand
	- Tale Spin
	- A few others I unfortunately forgot the names of
- Rockman 8 FC (in Dive Man's stage)
- NemZ ("NemZ's tileset emporium", used in Pharaoh Man's stage)
- MiniMacro (Cossack 4 foreground tiles, custom made)
- NARFNra (Cossack 2 background tiles, custom made)
- Golden Shades (Second Wily Castle, custom made)
- Rockman & Forte FC (Brick tiles in Pharaoh)

BETA TESTING
- Shinryu - Countless ideas and suggestions, testing the hack thoroughly before release
- NARFNra - Testing the hack multiple times during early development and coming up with many great ideas
- MartsINY- Testing during development
- Golden Shades - Testing during development
- RRThiel - Testing during development
- megaMARINO - Testing of version 1,03

MISCELLANEOUS
- Capcom - Without them, this hack wouldn't exist!
- Mathew Valente - His Famitracker module of Mega Man 9's sound effects made it easier to recreate the MM9 sounds I needed
- Anandastoon - His MM5 hack (Indonesian Artifact) and his (unfortunately) cancelled MM4 hack have inspired me a lot
- ThanatosZero - Suggestions
- VirtualWolf12 - Suggestions
- ShadeUsher - Suggestions
- Ness - Suggestions
- NaOH - Suggestions
- Zynk - Suggestions
- retroverse - Suggestions
- Sprites Inc. - http://www.sprites-inc.co.uk/
- VGMaps.com - http://vgmaps.com/
- The Spriters Resource - http://www.spriters-resource.com/
- Lots of YouTubers out there - Their Let's Plays of Mega Man hacks and fan games have shown me weaknesses in other hacks that I (tried to) avoid(ed)

------

12. Contact / Follow:

If you have any questions or comments you can contact me via private messages on the following forums (my account name is DurfarC on all three):
- board2 - http://acmlm.kafuka.org/board/
- ROMhacking.net's forums - http://www.romhacking.net/forum/
- Sprites Inc's forums - http://www.sprites-inc.co.uk/forum.php

I don't have an e-mail outside my personal one unfortunately.

Make sure to follow and subscribe to our YouTube channels!
- DurfarC - https://www.youtube.com/user/Firebounce
- MartsINY - https://www.youtube.com/user/MartsINY
- Golden Shades - https://www.youtube.com/user/sebamkfan
- RRThiel - https://www.youtube.com/user/rrthiel
- Cosmic Gem - https://www.youtube.com/channel/UCRimElPGccPl_gJk7L7avXQ
- MarkTherence - https://www.youtube.com/user/ILikeYourSTICK

------

13. Disclaimer:

Mega Man is the copyrighted property of Capcom. Graphics imported from other games are owned by their respective developers and/or publishers. I do not claim legal rights to anything in this hack. Do not sell or distribute commercially.

------

DurfarC et al. - 2012-2018