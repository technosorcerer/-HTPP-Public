Hey.
This was made with RussianManSMWC's Disassembly, As it gives more
Freedom for editing, only bad thing is that you need to know asm.
Fortunately, i know.
So Yeah... I made this with a disassembly.
Hope you enjoy and...
Have a Nice Day!
-JackfeldSeinfeld