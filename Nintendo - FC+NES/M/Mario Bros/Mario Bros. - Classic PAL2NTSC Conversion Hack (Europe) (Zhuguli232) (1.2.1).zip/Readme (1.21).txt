Thanks for downloading Mario Bros. (NES) "Classic Serie" re-release/European Revision PAL-to-NTSC Conversion hack!

This hack changes the "Classic Serie" re-release/European Revision version to adjusts the music and gameplay speed back to match the 60Hz NTSC refresh rate, everything is now smooth at 60Hz just like original version and has missing contents from the original Arcade game like Kaettekita Mario Bros. (a Japanese-only updated version for the Famicom Disk System port)

To apply this patch, apply this to "Classic Serie" re-release/European Revision version rom, it should be like this:
Database match: Mario Bros. (Europe) (PAL-MC-0, Classic Series).nes
Database: No-Intro: Nintendo - Nintendo Entertainment System (Headerless) (v. 20250311-142929)
Format: Headered rom
File Header: 4e 45 53 1a 02 01 01 00 00 00 00 00 00 00 00 00
File SHA-1: cc660baa474baaadcfce5c502b5a119ab07158e7
File CRC32: 46b2c0de
ROM SHA-1: dbd1bf833a9d89a9ac41ccced0fb508074a489d1
ROM CRC32: a1c0da00

For now, it's compatible with infidelity's Super Mario All-Stars for NES, by applying this patch: Zhuguli232's MBC PAL2NTSC for infidelity's SMASNES.ips, it can only worked with the latest version in both variants (20200323)

Update History:

1.21 (2025/12/19): fully finished version
-Fixed Sidestepper's spawn sound effect pitch
-Added the patch for Infidelity's NES Super Mario All-Stars (20200323 latest version only, both emu and real variants), replacing his NTSC conversion with my own (Zhuguli232's MBC PAL2NTSC for infidelity's SMASNES.ips)

1.2 (2025/11/12): 
-Fixed enemies movement speed (taken from the NTSC version)
-Moved the player and enemie location a bit to avoiding occur the bug in intermissions in some emulators after changing enemies speed
-Falling after jumping speed has been adjusted to be close to the original arcade version as possible
-Fixed slipice freezing sprites platform by sawpping ppu data where parts of Sidestepper in this version and Kaettekita Mario Bros are -actually originally freezing sprites in the original version. [Optional, a separate patch without conversion to NTSC (Slipice freezing sprites fix for Mario Bros. Classic.ips) also made and included here.]
-NSF file is included here as a bonus.

1.01 (2025/11/1) Day One/Minor Update:
-Fixed it won't run on FCEUX emulator
-Added Reset Fix
-Changed the header to auto detect as NTSC

1.0 (2025/11/1):
-Initial release, but soon got quickly updated due to unplayable on FCEUX

DO NOT patch this to the original version roms which are not compatible.

This patch also can be applied on Hacks where used this version as basis.

Tested on BizHawk (under NESHawk Core), FCEUX, Mesen, Nestopia and VirtuaNES emulators and works very well, I haven't tested this on real hardware due to I don't own a real console and flash carts such as Everdrive.

I hope you enjoy it.

Credits:
Infidelity - Thanks for modification of pitch table in music data in Mario Bros. from Super Mario All-Stars (NES), and the inspiration of this PAL2NTSC conversion for me
TakuikaNinja - for reset bug ifx
Zhuguli232 - for correcting the tempo, fixing slipice freezing sprites, porting some codes from NTSC versions

Version 1.21
Zhuguli232, 2025/11/1-/12/19