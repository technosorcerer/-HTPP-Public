this is a hack that replaces Mario and Luigi with my sona and an oc, T-Bone and L-Bone. the title screen still says "MARIO BROS" because i don't know how to edit big text like that, an update may come in the future if i ever figure out how.

small credit to infidelity for making an MMC3 conversion of Mario Bros. that i used. https://www.romhacking.net/hacks/2680/