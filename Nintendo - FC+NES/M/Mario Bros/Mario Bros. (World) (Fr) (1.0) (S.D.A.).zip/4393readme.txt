MARIO BROS. (NES)

Ce patch est pour la version internationale de Mario Bros. pour la NES.
Il est au format .ips, donc pour le patcher, utilisez Lunar IPS.
Si vous souhaitez soumettre un avis, �crivez-le sur romhacking.net.

-S.D.A.