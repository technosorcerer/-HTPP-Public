Thanks for downloading Mario Bros. (NES) Classic Serie/European Revision PAL-to-NTSC hack.

This hack changes the Classic Serie/European Revision version to adjusts the music and gameplay speed back to match the 60Hz NTSC refresh rate, everything is now smooth at 60Hz just like original version and has missing contents from the original Arcade game like Kaettekita Mario Bros. (a Japanese-only updated Famicom Disk System port of the NES port)

To apply this patch, apply this to Classic Serie/European Revision version rom, it should be like this:
Database match: Mario Bros. (Europe) (PAL-MC-0, Classic Series).nes
Database: No-Intro: Nintendo - Nintendo Entertainment System (Headerless) (v. 20250311-142929)
Format: Headered rom
File Header: 4e 45 53 1a 02 01 01 00 00 00 00 00 00 00 00 00
File SHA-1: cc660baa474baaadcfce5c502b5a119ab07158e7
File CRC32: 46b2c0de
ROM SHA-1: dbd1bf833a9d89a9ac41ccced0fb508074a489d1
ROM CRC32: a1c0da00

Minor Update: Fixed it won't run on FCEUX emulator, added Reset Fix, changed the header to auto detect as NTSC

DO NOT patch this to the original version roms which are not compatible.

This patch also can be applied on Hacks where used this version as basis.

Tested on BizHawk (under NESHawk Core) emulator and works very well, I haven't tested this on real hardware due to I don't own a real console and flash carts such as Everdrive.

Version 1.01
Zhuguli232, 2025/11/1