Removes flashing on flag sprites, removes pulsing on bonus text, removes pulsing on score text, and removes flashing G O A L at the end of the first stage.


----------------------------

Details of changes made:

07B79: 251606 -> 3c1201 : removes flashing on flag sprites

07818: 0212223211211101 -> 1212121212121212 : removes bonus and score-related pulsings

19910: 20F0783C1E0F -> 000000000000
19918: E0F0F83C1E0F -> 000000000000
19929: 1F7F7F78783C1F0F -> 0000000000000000
19946: 783C1E0FBFFCF0C0 -> 0000000000000000
19950: 783C1E0F07030100 -> 0000000000000000
1995B: 3C1E0F87C0E0C000 -> 0000000000000000
19964: 80C0E0F078FCFEEF -> 0000000000000000
1997E: 071F1F1E1E0F -> 000000000000 : these 8 changes remove flashing G O A L at end of first stage
