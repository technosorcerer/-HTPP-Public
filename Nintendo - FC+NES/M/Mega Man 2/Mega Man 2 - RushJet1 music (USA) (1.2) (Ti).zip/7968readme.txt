changelog:

v1.2:
+ samples changed to PCM (higher quality than DPCM), new kick and snare samples.
+ added VRC6 volume control.
+ updated 'Quickman's song so that the melody is not interrupted by lasers.
+ fixed ending credits song playing intro twice.
+ added a music pause when the boss door closes.

v1.1:
+ Wily5 song works as intended by RushJet1.
+ fixed buzz sound before bosses.
+ Wily6 song no longer stops.
+ Wily�s stages boss tunes as intended by RushJet1.

----------------------------------------------------

supported emulators:
FCEUX (v2.6.6 recommended)
PuNes v0.110
Ares
Mednafen
Bizhawk (QuickNES)

not supported emulators:
*Mesen
*Nestopia
**Nintendulator
VirtuaNES
NNNesterJ (samples doesn't work in v1.2)

* change source files to expand mapper #26 to 512 kb prg-rom limit.
** change source files to allow chr-ram for mapper #26.

carts:
Evedrive N8 Pro (only Pro, standart needs custom mapper file).
PowerPak
InviteNES

Note, if using NES you need to do mod to hear VRC audio, Famicom doesn't needs any mods, Dendy clones may or may not work.

If using PAL/DENDY, some tracks may sound incorrect, title for example, so using PAL is not recommended.
