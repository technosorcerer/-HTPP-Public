Mega Man 2 FamiTracker Patch
v1.0.1

By Justin Olbrantz (Quantam)

The mm2ft patch adds FamiTracker Module playback support to Mega Man 2, both making it far easier to compose and import custom music for hacks and providing a far more powerful sound engine. This engine is added on top of the Capcom 2 sound engine used by MM2, and both C2 and FT format music may be used in a single hack.

Basic Features:
- Supports for FamiTracker Modules as implemented by bhop (https://github.com/zeta0134/bhop)
	- Supports basic FT features including channel volume, instruments, volume/pitch/arpeggio/mode envelopes, true tempo, etc.
	- Supports effects 0 (arpeggio), 1/2 (pitch slide), 3 (portamento), 4 (vibrato), 7 (tremolo), A (volume slide), B (go to order), C (halt), D (go to row in next order), F (speed/tempo), G (note delay), L (delayed release), P (fine pitch), Q/R (pitch slide to note), S (delayed cut), V (mode), Y (DPCM sample offset), Z (DPCM delta counter)
	- Supports all base (2A03) channels including DPCM
	- Does NOT support expansion chips, linear pitch mode, hi-pitch envelopes, or effects E (old-style volume), EE (toggle hardware envelope/length counter), E (length counter), H/I (hardware sweep), M (delayed volume), S (set linear counter), T (delayed transpose), W (DPCM pitch), X (DPCM retrigger)
- 1.5 KB available for DPCM samples
- Supports unique tracks for all Wily stages
- Supports stage-specific boss music, including separate refight music
- Increases the maximum number of tracks from 33 to 128
- Multi-bank support for both FT and C2 music, allowing up to 8 KB per track
- Expands ROM size to 512 KB, almost half of which is available for music and other hacks
- Adds 8 KB PRG-RAM, most of which is available for other hacks
- Incorporates mm2mmc3 which converts MM2 to MMC3, fixes the delay-scroll bug, and provides a scanline interrupt timer derivative hacks may use
- Incorporates mm2scrollfix for smooth, artifact-free vertical scrolling
- Incorporates the MM2 Sprite Lag Reduction Patch for significantly reduced CPU usage to more than compensate for the increased usage from FT playback

HOW IT WORKS

The basic principle of operation of mm2ft is simple. mm2ft runs both the original sound engine and bhop in parallel, mixing the output based on which engine is playing and which channels are currently in use by sound effects (which always use the C2 sound engine).

The hardware design of DPCM in the NES brings some additional complexity and required changes in unexpected places. The DPCM DMA can intermittently corrupt reads from various other hardware, chiefly the controller input and reading from VRAM. Working around this required modification of both the controller read function and the various functions that read from VRAM, mainly related to tile palettes and level streaming. In fact mm2scrollfix was originally written as a part of mm2ft's solution to the DPCM DMA problems, but was ultimately split off as it is useful even without mm2ft.

Under the hood, mm2ft adds a second track table: the track map table. This table specifies 4 key pieces of information: what ROM bank the track is in, where in the bank the module begins (FTMs only), which track index within that module the track is (though for C2 tracks it's simply the track's index in the C2 track address table), and which engine to use to play it. The details are not relevant to most users, so it won't be described further.

REQUIREMENTS

Mega Man 2 (USA):
PRG-ROM CRC32 0FCFC04D / MD5 0527A0EE512F69E08B8DB6DC97964632
File CRC32 5E268761 / MD5 8E4BC5B03FFBD4EF91400E92E50DD294
File CRC32 80E08660 / MD5 302761A666AC89C21F185052D02127D3
File CRC32 A9BD44BC / MD5 CAAEB9EE3B52839DE261FD16F93103E6

Rockman 2:
PRG-ROM CRC32 6150517C / MD5 770D55A19AE91DCAA9560D6AA7321737
File CRC32 30B91650 / MD5 055FB8DC626FB1FBADC0A193010A3E3F

The makeftrom utility ( https://www.romhacking.net/utilities/1800/ ) is used to import music. Note that some of the mm2ft files (in particular the .ftcfg files) are required by makeftrom to produce mm2ft ROMs.

Additionally, while the easiest way to patch is to simply use the RHDN online patcher, offline patching can be done with a BPS patching utility such as beat, Floating IPS, and others.

PATCHING

mm2ft contains two pairs of patches: mm2ft.bps and mm2ftdemo.bps, applied to the US Mega Man 2, and their Rockman 2 equivalents e.g. rm2ft.bps. mm2ft.bps produces mm2ft.nes, which is the base that will be used for further hacking, including importing music via makeftrom. mm2ftdemo.bps produces a playable demo that replaces many of the game's tracks with assorted different music; this demo 1. includes the changes from mm2ft.bps, and 2. cannot be used for further hacking as makeftrom cannot be run on a file that already has imported music.

The simplest way to apply these patches is to simply use the RHDN "Patch Online Now" function.

COMPATIBILITY

Care must be taken when combining mm2ft with other, non-music changes.

mm2ft substantially reorganizes the MM2 track data. All tracks both music and sound effects have been moved around and divided between 8-KB banks $18, $19, $1e, and $1f. Importantly, the C2 sound engine code and global data are at the same locations as in the base game.

Additionally, MMC3, like most other mappers, requires the common banks (addresses c000-ffff) be the final banks in the ROM. As such, in addition to any specific changes, the ENTIRE 3c010-4000f file region (MMC1 bank F) has been relocated to 7c010-8000f (MMC3 banks 3e-3f). As such ANY other hack that modifies the 3c010-4000f region will not work when patched, as the patch is modifying the wrong location. However, many of these hacks should work correctly when manually applied to the proper new locations.

mm2ft/mm2mmc3/mm2scrollfix/mm2spritelag use the following RAM ranges that were previously free (or repurpose existing ranges):
- c2-c3: NMI temporaries. It should be safe to use them elsewhere as NMI temporaries.
- c4-c7: Out of interrupt temporaries. It should be safe to use them elsewhere as out of interrupt temporaries.
- 57e
- 7d80-7fff

6000-7d7f is available for derivative hacks.

They use the following ranges that were previously free (when 2 ranges are given the left is for MM2, right is for RM2):
- 2bb46-2bb6d (4a2 left)
- 3bd34-3be61 (1ae left)
- 7f310-7f90f (DPCM area)

As well, they free up the following ranges:
- 312e4-3200f (d2c). Any new SFX must go here in the C2 code bank, as SFX cannot be banked the way music can.
- 33f06-3400f (10a)
- 38053-38060 (e)
- 7ca26-7cb1b / 7ca23-7cb18 (f6)
- 7d0e7-7d104 / 7d0e4-7d101 (1e)
- 7d1a2-7d1ee / 7d19f-7d1eb (4d)

Finally, they substantially modify the following ranges in a way that may break compatibility:
- 38038-3804e
- 38061-38066
- 7c010-7c060
- 7c06d-7c080
- 7c92b-7c97a
- 7d09d-7d0e6 / 7d09a-7d0e3
- 7d279-7d2fa

With the exception of new SFX (which must necessarily be in bank $18), it is advisable to consider banks $18, $19, $1e, and $1f the property of mm2ft. These banks have a significant chance of changing in future versions of mm2ft, and not placing your own data there will reduce the labor necessary to upgrade the mm2ft version for an existing hack.

PRODUCING DERIVATIVE HACKS

As stated, mm2ft incorporates the mm2mmc3 conversion. For information on using the API provided by mm2mmc3, see its readme (https://www.romhacking.net/hacks/7478/).

The general process of producing hacks using mm2ft looks like this:
1. Hacking done prior to applying mm2ft.bps (optional). Any such hacking can increase the chance of conflicts with mm2ft.bps, but for projects that already have work done, it's probably preferable to not start again from scratch. But do make sure to save a copy before applying mm2ft.bps, in case patch conflicts arise and suddenly your work in progress ROM no longer works.
2. Apply mm2ft.bps
3. Further non-music hacking (optional)
4. Run makeftrom to import the music

This order is important because makeftrom cannot be run on a ROM that already has imported music, and as such it must either be the last step in the process or you must preserve a copy of the pre-makeftrom ROM you can use to continue your hacking work after doing a test run with makeftrom.

Most of the process of using makeftrom is left to the makeftrom user guide, but there are a couple important pieces of information.

The MM2-specific list of track names that can be assigned using makeftrom; it is not necessary to know the track numbers, they are provided simply to allow those already familiar with MM2 track numbers to associate them with their names:
0: FlashMan
1: WoodMan
2: CrashMan
3: HeatMan
4: AirMan
5: MetalMan
6: QuickMan
7: BubbleMan
8: Wily1
9: Wily3
a: StageSelected
b: Boss
c: StageSelect
d: Title
e: Intro
f: GameOver
10: Password
11: WilyCastle
12: WilyCapsule
13: Ending
14: Credits
15: StageClear
16: GameClear
17: GetWeapon
18: Wily2
19: Wily4
1a: Wily5
1b: Wily6

Additionally, tracks 1c-20 and 43-7f are not used in the original game and can be used for boss tracks or any other purpose that may be hacked into the game. These tracks have names e.g. Track1c and Track7f.

As well, the following boss fight names may have music assigned to them in the boss_track_map section: 
FlashMan
WoodMan
CrashMan
HeatMan
AirMan
MetalMan
QuickMan
BubbleMan
Wily1
Wily2
Wily3
Wily4
FlashManRefight
WoodManRefight
CrashManRefight
HeatManRefight
AirManRefight
MetalManRefight
QuickManRefight
BubbleManRefight
Wily5 (the Wily machine)
Wily6

BUGS

- Bugs or incomplete features may exist in bhop. The most noticeable known issue is that bhop does not currently implement pitch effects (e.g. pitch slide) on the noise channel. This causes some drum sounds to sound incorrect. This can be worked around using pitch or arpeggio envelopes instead.

FAQ

Why Does Heat Man's Stage Sound Different?

If you have the Mega Man soundtracks memorized and a good ear, you may be able to notice that the Heat Man stage music sounds slightly different. This is actually a bug fix, though the explanation is a bit technical.

In the C2 engine vibrato and tremolo are part of the instrument definition (sometimes called "modulation"), and applied to a note by changing the current instrument. Heat Man, as well as a couple other tracks that do not have any audible bug (e.g. stage select) lack an instrument table at their end; instead their instrument table pointer points to the very end of the track - the first byte of the next track. What probably happened is that because these tracks do not use vibrato/tremolo and do not ever set the instrument, the composer thought no instrument table was needed and a few bytes were saved.

However, the instrument table is read in one other scenario as well. To save RAM, C2 gives each channel only a single set of variables for vibrato and tremolo which are shared by both music and SFX. When a SFX begins, it reinitializes those variables, and when the SFX ends they are reloaded from the current music instrument. It is in fact the stage SFX (especially the beaming in SFX) that triggers the bug in Heat Man, which can be confirmed by hacking the original ROM to play Heat Man's music at e.g. stage select. What is actually happening is that one channel in Heat Man's stage has invalid vibrato settings that cause the pitch to fall on some notes.

It is very likely that the composer did not intend this, and it was causing far more audible problems in combination with some SFX not found in the Heat Man stage, so mm2ft added an instrument table to all such tracks, fixing the bug once and for all.

CREDITS

Research, reverse-engineering, and programming: Justin Olbrantz (Quantam)
FamiTracker playback library (bhop): Zeta
Music used by the demo: cookiefonster, nicetas_c, retrotails, ZeroJanitor, SUPAH METUL, others

Thanks to the NesDev and Classic Mega Man Science communities for the occasional piece of information or advice.

VERSION HISTORY

v1.0.1
- Switch to BPS patches and simplify patching process to better support RHDN online patching and non-Windows users
- Additional readme.txt information

v1.0
- Update bhop to df7fd4e7 + additional changes not yet picked up upstream
- Support multiple FTMs per bank, increasing ROM usage efficiency
- Restore Famicom expansion support that was removed at some point
- Switch to using IPS for greater user convenience

v0.3
- Update bhop from 6040bf9e to bf4a6699
- For convenience integrate MM2 Sprite Lag Reduction patch
- Fix the "long tink" bug causing sound effects to sometimes play too long on the triangle channel
- Support unique music for each refight
- Support fade in/out in FT tracks
- Reduce zero page RAM usage to leave more for derivative hacks
- Fix format errors in three tracks in the original game. This will slightly change the sound of the Heat Man track (as the track is no longer affected by the error), but the error could cause the tracks to sound very bad when used outside their native habitats (especially during boss fights).

v0.2
- Switch to new unified makeftrom
- Fix popping on triangle channel at reset
- Implement level-specific boss music
- Increase maximum tracks to 128
- Update bhop from e77e0e36 to 6040bf9e