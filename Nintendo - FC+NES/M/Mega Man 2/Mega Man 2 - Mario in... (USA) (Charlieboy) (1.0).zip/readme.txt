This is a simple graphics swap for Mario to be the playable character in Mega Man 2

use an .ips patcher to patch the base rom for Mega Man 2.

Graphics made by Charlieboy