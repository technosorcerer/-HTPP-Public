Mega Man 2 Optimization - by LSM

This patch include 4 files, they both have different meaning.

Mega Man 2 Optimization is used for US version, aka Mega Man 2.

Rockman 2 Optimization is used for JP version, aka Rockman 2.

MMC1 and MMC3 means patched ROM's mapper.

All of MMC3 patches aren't extended, but you can extend it later.

These patches are free of use.

-- Features --

1. Enable WRAM to optimize stage scrolling and TSA running.
2. Optimize sprite ASMs (No delay animation and be longer i-frames even if full OAMs.)
3. Others (Most of QoLs, remove pause playing, increase climb ladder speed, refill instantly and etc.)
4. Bug fix (Fix "Cannot continue when Mega Man drop into pits in specific conditions and back to checkpoint.")

-- How to use it --

Please prepare the clean Mega Man 2/Rockman 2 ROM and patch it from correct ips.
Don't patch any in progress, abandoned or finished work. Please aware of your own risk. (mess graphic, hardlock or unknown bug.)

-- Instruction --

This part is about hacking instruction from the patch.

1. Stage checkpoints.
Due to some of checkpoint ASM subroutine is same as scrolling, please use Rockman 2 Editor by Rock5easily to calculate the left and right map read address first, then edit it.
If the result is $84E0, please type to $64E0. (just change the first number to 6.) Either it will cause mess graphic.

2.Weapon status value read range.

It depends on weapon actual use maximum status value range.
e.g. Buster status limited use maximum is 3 on screen, so the actual use maximum status value range is 3+1=4. +1 means ASM cannot read/cross boss status RAM.
The actual use maximum status value range's address depend on which mapper version used. In MMC1, address at $3F501-$3F50C. In MMC3, address at $3F540-$3F54B.
The arrangement is same as weapon in menu: Buster, Heat, Air, Wood, Bubble, Quick, Flash, Metal, Crash, Item 1, Item 2 and Item 3.

Special thanks:

Puresabe
Rock5easily
Himajin Jichiku
nesdev.com
6502.org

2023.8.29