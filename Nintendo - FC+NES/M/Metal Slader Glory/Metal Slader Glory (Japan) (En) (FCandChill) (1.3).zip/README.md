[//]: <> (This readme is in the markdown format. Please preview in a markdown parser.)

# Metal Slader Glory FC: English Version 1.0

Source code: [https://github.com/romh-acking/metal-slader-glory-fc-en](https://github.com/romh-acking/metal-slader-glory-fc-en)

Discord: [https://discord.gg/st5T8HXv2K](https://discord.gg/st5T8HXv2K)

## About
This is a translation patch for Metal Slader Glory on the Famicom. If you're going to play the game for the first time, make sure to read the manual beforehand because it covers events preceeding the game.

Apparently, a prequel to this game was intended to be released on the 64DD but was cancelled. If you want the series to continue, consider showing your appreciation for it to the game's creator, Yoshimiru. You can do this by buying some Metal Slader Glory merch from his store and giving him a follow on Twitter:

Store: [https://mc-berrys.booth.pm/](https://mc-berrys.booth.pm/)

Twitter: [https://twitter.com/yoshimiru_SS/](https://twitter.com/yoshimiru_SS/)

He sells books detailing the games' development, including the 64DD prequel. You can't find scans of these books anywhere online.

Also, work is underway for the SNES port, so stayed tuned! For those who prefer the NES version's OST, there will be an MSU-1 patch.

## Patching Instructions
The patch is a [Beat patch](https://www.romhacking.net/utilities/893/). Either use the Beat patcher or patch your rom here:

[https://www.romhacking.net/patch/](https://www.romhacking.net/patch/)

No IPS patches will be provided as the rom was expanded to 1.5MB.

There's two version of the Famicom version: one is the original 1991 release and one is the Virtual Console release. Please patch the former.
The Virtual Console release appears to only make changes to accommodate people with epilepsy. The translation patch is incompatible with the Virtual Console release. Patching over it will disable all screen flashing. This actually may be desirable considering a handful of scenes in the VC release still have intense flashing.

Dumps online commonly have an incorrect header which indicate the game uses a battery backup when it does not. Change 0x6 from $52 to $50 to correct this in your favorite hex editor. The header should be as follows before patching:

`4E 45 53 1A 20 40 50 00 00 00 00 00 00 00 00 00`

The translation was tested on the EverDrive N8 Pro. Firmware version 2.03 is incompatible with it while firmware version 2.10 is compatible.

## Translation Changes

**Spoilers up ahead!**

### Text Speed

Easily the biggest change for the translation. The text speed was greatly increased, so you don't have to constantly hold down the **B** button to have the text print at a reasonable pace. However, in the original game, a character's voice sound effect played after each letter was printed. In order to avoid the sound effect from getting grating with the sped up text, the voice sound effects are selectively played after a certain amount of letters are printed. Additionally, the mouths were slowed down too.

If the text speed ever get a bit too fast for you, don't be afraid to pause the game with the **Start** button.

### Font

The font is the chicago font. If you like Chrono Trigger, you'll be pleased to know this translation's font is based on the font from the game. It's 16x8 and has a shadow.

### Music Cues

The game's AGL (Adventure Game Language) contains a function that basically says "process the next line of code once the music stops". This was an issue in a couple of places. Because of the increased text speed, the game would hang for dozens of seconds after the text was printed. As a result, the function was dummied out in a couple of places, so certain music tracks will be truncated.

The ending cutscene's music cue was also adjusted to be earlier to accommodate for the increased text speed.

### Chapter 7 Timer

The timer in the final battle counted down from 60 seconds. Because of the increased text speed, it was reduced to 45 seconds.

### Ellipsis

The original script used *a lot* of ellipses, which isn't uncommon for Japanese scripts. This doesn't translate well to English, so all unnecessary instances were removed. 

### Azusa

Azusa in the original game talks in third person. [This is a cultural thing](https://en.wikipedia.org/wiki/Burikko); it's done because it's considered cute, however, this doesn't really translate to cute in English, therefore, this was changed. Additionally, Azusa called Tadashi "onii-chan" a lot. All instances were changed to "Tadashi".

But wait, Azusa isn't the only one that talks in third person, Ai, one of the mechanics, does too. In fact, it's part of a joke. Ai talks in third person and as a result, Azusa chimes in third person as well. 

| Japanese | English |
| :--- | :--- |
| 　﹡　「アイちゃんもね‥‥‥<br />ぜんぜん　わかんないの‥‥‥」<br />あずさ　「あずさも　わかんない」| ﹡: Me neither.<br />I don't know anything about Slader<3$<br />Azusa: Same here<3$|

To preserve this minor joke, a heart was added to both of their lines to indicate they talk in the same cute manner.

### Vivace or Vivach?

When the party arrives at the restaurant "Vivace", Elina mispronounces the restaurant name as "Vi-vace" but it's actually supposed to be pronounced "Vi-vah-che". This doesn't really make sense in English. So instead of Elina mispronouncing the restaurant name as "Vi-vace", she misreads the sign as "Vivach"; cursive signs aren't exactly easy to read after all!

### Knock Knock

In chapter 5, you can examine various objects with the "knock" option. Using this option on objects like pieces of paper doesn't make much sense, so this option was adjusted to "check" by changing the game's AGL bytecode.

### Debug Menu

All the scene names in the debug menu were changed to be more meaningful. Almost all the scene options were something along the lines of "S1-6".

### Chapter 7 Option

Not much of a change and more like an unavoidable little bug. In chapter 7, the option for Catty's group overlaps with the cursor leading to the next page.

### Elina's Battle Summary

In the last chapter, Elina for a couple of battles gives a summary of what kind of aliens are coming after you. The alien names are stringed together rather than being separate dialogue entries. The result is a sentence without commas or compound words; in other words, not a grammatically correct sentence! This logic is handled by an AGL script. One idea was to recycle the text entries and print premade grammatically correct sentences, however, this proved to be too cumbersome. As a result, the logic was dummied out in the AGL bytecode, and Elina says a static line instead.

To properly fix this, it would require reverse engineering HAL's Adventure Game Language and creating a compiler and decompiler. Additionally, it would require storing the new bytecode in freed up space and directing the game's existing bytecode to the new script as it would probably take up more space. All of this to change seven instances where the script is executed. [One of the game's programmers, Seika Abe, made a presentation on HAL's technologies and showcased an AGL source code snippet from the game.](https://web.archive.org/web/20170531070139/http://cl-www.msi.co.jp/reports/wblcl.pdf)

### Manual Headers

The original Japanese manual has headings spanning two pages. The translated manual contains headers to one page.

### Manual Precaution Page

In the Japanese manual, the precaution page has copyright text and other text below the precaution panel. This text was a bit difficult to edit out, so the panel was extended.

## Differences From the Stardust Crusader's Translation

### Text Speed

This was covered above, but the other translation's text prints at a snail's pace, forcing you to hold down **B** a lot.

### Font

This was covered above. Stardust Crusader's translation uses a font that more resembles the Japanese version's font.

### Mouth Bug

The reason the game remained untranslated for so many years was because of:

1. the script's size
2. the extreme amount of control codes in the game's script

These control codes manage a lot of aspects including character portraits and character sprites. One notable control code is the endquote control code. One of the control code's roles is to close the mouth of the character who is currently talking. Aside from two instances, the Stardust Crusader's translation removes all 4,299 instances of this control code. As a result, almost every scene is bugged and often has characters with their mouths wide open.

Also, this is nitpicky, but the table indicating how certain letters are processed were not adjusted. As a result, the ellipsis in Stardust's translation invokes mouth movement and a character voice sound effect (even though an ellipsis should denote silence). The table in this translation was adjusted accordingly.

### Unremoved Indenting

For the missing person report scene, the indenting for the dialogue at the top of the screen wasn't removed, unlike the main dialogue. This translation removes the indentation.

### Script Differences

There was originally a writeup to illustrate the differences between the two, however, it's probably best if you make your own judgments and comparisons.

## Manual
Much thanks to ozidual from Gaming Alexandria for providing the scans of the manual. Check out the original scans here:

[https://www.gamingalexandria.com/wp/2020/07/metal-slader-glory/](https://www.gamingalexandria.com/wp/2020/07/metal-slader-glory/)

## Changelog
* 2025 September 1st, 1.3
    * One of the passwords incorrectly displayed as "Let's go to Colony 35" instead of "Let's go back to Colony 35".
	* Thanks to @solrocknroll for spotting this.
* 2025 March 10th, 1.2
	* Syncing with SNES translation release changes
		* Script changes
		* Properly implemented mouth pattern patch
		* Mising person report text speed bug fix
		* Cleaned up ellipses
* 2021 October 3rd: 1.1
    * The countdown timer in stage 7 was adjusted. The colon was turned into a period as it's more appropriate for the `seconds.milliseconds` format.
* 2021 August 30th: 1.0
    * Initial release

## Credits

### Main Team
* FCandChill
    * Initial ASM work
    * Utilities
    * Localizer
    * Proofreader
    * Manual
* Her-saki
    * Advanced ASM work
    * Font
    * Initial translation

### Support
* kartes
    * Maker of the script dumper tool in RHDN's abandoned section
* tashi
    * Character identification
* Matatabi#8541
    * Onspot translation checks
* danke#6948
    * Onspot translation checks
    * Localization feedback
* Pennywise#4430
    * Localization feedback
* kaio#4229
    * Localization feedback
* HGwells628#6941
    * Localization feedback
* Aerdan#3244
    * Localization feedback
* Kajitani-Eizan#9804
    * Localization feedback
* Gideon|Web#7436
    * Localization feedback
* Kadalyn#2959 (YasaSheep):
    * Manual feedback
* inactive#4484
    * Was there

### Beta Testers
* ccmar#6676
    * Typos
    * Suggestions
    * Onspot translations
* blueskyrunner#6087
    * Typos
    * Suggestions
* marklincadet#0878
    * Typos
    * Suggestions
* ppltoast#5820
    * Suggestions
* jekuthiel#9153
    * Real hardware tester
* MrNorbert1994#5955
    * Header fix
* Satoshi_Matrix#4487
    * Suggestions
* ParadiseAlive#3928
    * Was there
* xWhyohwhyx#4581
    * Was there
