Notice: Currently, the Demo 1 version of this hack is only available in Chinese. Other language versions will be implemented in the full release, so non-Chinese players may need to wait a while.

This hack is a spin-off of my Rockman 3: Gaming Realm Expedition, featuring Sunaookami Shiroko from Blue Archive as the protagonist.
The story is set during Mega Man's journey across game universes to resolve anomalies. Shiroko steps up when other students in Kivotos fall under the influence of these distortions, defeating enemies who exploit the chaos to save the academy.
Yet beyond Kivotos' immediate crisis, an external threat looms...

Demo modifications (subject to change in the final version):
・Replaced protagonist sprites with Shiroko
・Adjusted Shiroko's (originally Mega Man's) gameplay mechanics
・Adjusted Mega Buster (now called "White Fang 765") bullet speed
・Set 3-stage charge shot damage to 2
・Replaced Dr. Light with Sensei (may look slightly abstract)
・Overhauled all weapons and item movements, including sprites
・Modified some enemy AI
・Modified all Boss AI
・Revised 8 Bosses' weaknesses (based on Blue Archive's affinity system)
・Rewrote story text
・"Adjusted" BGM (I'm terrible at music editing)

As this is a demo version, minor bugs or inconsistencies may exist. Your understanding is appreciated.

------2025 MagnetFirstBro------