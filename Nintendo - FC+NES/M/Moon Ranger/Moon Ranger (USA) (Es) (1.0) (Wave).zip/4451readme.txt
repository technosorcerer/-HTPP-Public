Moon Ranger (NES)
Traducci�n al Espa�ol v1.0 (22/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Moon Ranger (Bunch) [!].nes
MD5: 4985db289f6a739a70b48ae43091d468
SHA1: 1eadd4ff160fd225f0159504ac5d7659c2eca894
CRC32: 22172117
131.088 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --