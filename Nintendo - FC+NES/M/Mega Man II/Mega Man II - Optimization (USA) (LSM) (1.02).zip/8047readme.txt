Mega Man 2 Optimization - by LSM

Last update: 2023.9.2 (v1.01)

This patch include 4 files, they both have different meaning.

Mega Man 2 Optimization is used for US version, aka Mega Man 2.

Rockman 2 Optimization is used for JP version, aka Rockman 2.

MMC1 and MMC3 means patched ROM's mapper.

All of MMC3 patches aren't extended, but you can extend it later.

These patches are free of use.

-- Features --

1. Enable WRAM to optimize stage scrolling and TSA running.
2. Optimize sprite ASMs (No delay animation and be longer i-frames even if full OAMs.)
3. Others (Most of QoLs, remove pause playing, increase climb ladder speed, refill instantly and etc.)
4. Bug fix (Fix "Cannot continue when Mega Man drop into pits in specific conditions and back to checkpoint.")

-- How to use it --

Please prepare the clean Mega Man 2/Rockman 2 ROM and patch it from correct ips.
Don't patch any in progress, abandoned or finished work. Please aware of your own risk. (mess graphic, hardlock or unknown bug.)

Special thanks:

Puresabe
Rock5easily
Himajin Jichiku
nesdev.com
6502.org

-- logs --

v1.0 - 2023.8.29

First release.

v1.01 - 2023.9.2

1.Reprogamming ASM to remove instruction.
2.Remove flash on screen during ending.

v1.02 - 2023.9.6

1.Remove unnecessary code, reduce 3 CPU cycles.
2.Scrolling fixed (Rockman 2 MMC3 Optimization.)