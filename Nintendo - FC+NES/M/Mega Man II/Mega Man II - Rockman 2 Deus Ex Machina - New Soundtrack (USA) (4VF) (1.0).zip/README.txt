April 16, 2025 by 4VF

This is an addendum to Rockman Deus Ex Machina (originally programmed by Misty and IKA), for which I've arranged a new soundtrack - just for fun! The only modifications I've made are to the soundtrack, and the title screeen graphics. Otherwise, the game plays exactly like the original hack.

IPS patches are available for both the Normal and Hard versions of Rockman Deus Ex Machina. You will need to patch Misty's hack to the Japanese version of Rockman 2 first, and then apply my patch respectively.



Below is the tracklist of the new soundtrack, along with sources:



Opening: Excerpt from Concerto in B Minor Op. 6 No. 12 (Movement 1) by George Frideric Handel

Title: Courante from Suite in B Minor by Johann Pachelbel

Password/Continue: Induction - Darius Gaiden

Stage Select: Excerpt from Merry Go 'Round by Kacey Musgraves

Stage Start: Excerpt from Cosmic Air Way - Darius

Flash Man: Stage 3 "Ropes and Roper" - Battletoads & Double Dragon (NES)

Wood Man: Unknown (Track 12) - Kandume Monsters

Metal Man: Ronald Duel - Pokémon Trading Card Game

Heat Man: Keys The Ruin - Sonic Adventure 2

Air Man: Path of Goddess Claire - Klonoa 2: Lunatea's Veil

Quick Man: Palmtree Panic Bad Future (Japanese Version) - Sonic The Hedgehog CD

Bubble Man/Credits: Leave A Trace by CHVRCHES

Crash Man/Wily Stages 1-2: Trespasser - Sonic Adventure 2

Boss Battle: Cool Battle - Lil' Monster

Stage Clear: Excerpt from The Lord Our Enemy Has Slain (Esther) by George Frideric Handel

Get Weapon/Wily Stages 3-5: Grand Master Duel - Pokémon Trading Card Game

Wily Saucer: Capsule - Mega Man X3

Wily Map: Folgers Coffee Jingle

Final Bosses: Excerpt from Sinfonia (Agrippina) by George Frideric Handel

Wily Stage 6: Grand Master Duel (at a different starting point) - Pokémon Trading Card Game

Game Clear: Excerpt from Hallelujah! (Messiah) by George Frideric Handel

Ending: Excerpt from Concerto in B Minor Op. 6 No. 12 (Movement 3) by George Frideric Handel
