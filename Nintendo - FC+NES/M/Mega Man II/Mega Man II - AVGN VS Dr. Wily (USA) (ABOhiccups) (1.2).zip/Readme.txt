Thanks for downloading AVGN VS Dr. Wily.



Note:

The Original Rom Version of Mega Man II was Copyright by 1988 Capcom.

This is a Hack Rom Version of Mega Man II. Mega Man Sprites are changed into AVGN Sprites. The texts are changed too. The Levels are very difficult.

I think this game will be the Best Hack Rom Game I ever made.

Enjoy the game. :-)



How to load this game?

1) You need NES Emulator, Mega Man II.nes, and AVGN VS Dr. Wily.ips

2) Open your NES Emulator then click on "Load" then click on Mega Man II.nes.

3) Click on "Load" again then click on AVGN VS Dr. Wily.ips.

Then you're ready!



About the game:

This game is one of the hardest ROM hacks I�ve ever made. It�s very hard and challenging.

This is a Hack sequel to Mega Man II, set after Mega Man defeated Dr. Wily again.

Dr. Wily set up a trap to kill Mega Man. Mega Man was subsequently killed by Dr. Wily. So now Dr. Wily rebuilt all eight Robot Masters again, and made all stages much more difficult.

However, only one hero can stop the evil Dr. Wily and save the world. He is� Angry Video Game Nerd!