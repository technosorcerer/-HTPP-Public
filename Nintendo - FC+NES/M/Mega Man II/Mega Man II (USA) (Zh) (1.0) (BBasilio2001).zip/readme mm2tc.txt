Mega Man 2 - Traditional Chinese Translation
Author: BBasilio2001

------------
Instructions
------------
Download the patch file and patch the rom with the RHDN patcher, ensure you also have a Mega Man 2 (USA) rom.
Install an NES emulator (FCEUX recommended), load the ROM and play it.

Emulator: https://fceux.com/web/download.html
Patcher: https://www.romhacking.net/patch/

------------
Contact/Help
------------
If you have any questions, feel free to send me an email.
Email address: bbasilio2001@gmail.com


洛克人2 威利博士之謎 - 繁體中文翻譯
翻譯者: BBasilio2001

--------
安裝說明
--------

下載修補程檔案並使用RHDN的修補程式修補rom，確保您有《洛克人2 威利博士之謎》(美版) ROM。
安裝紅白機模擬器（推薦FCEUX），載入檔案就可以玩了。

模擬器: https://fceux.com/web/download.html
修補程式: https://www.romhacking.net/patch/

--------
聯絡方式
--------
如果您有任何問題，可以隨時給我發電子郵件。
電子郵件地址: bbasilio2001@gmail.com