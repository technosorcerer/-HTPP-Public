Eat! Gather sex objects! Fight dick monsters! Find love! With your ass!

Patch to the Namco version of Ms. Pac-Man (USA).nes