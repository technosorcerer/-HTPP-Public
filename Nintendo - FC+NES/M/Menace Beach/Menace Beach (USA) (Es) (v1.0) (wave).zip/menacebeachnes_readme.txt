Menace Beach (NES)
Traducción al Español v1.0 (08/01/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Menace Beach (USA) (Unl).nes
MD5: 48b8758715b0f60c1840e87bdbfaf124
SHA1: e68f1ad1982e7419162d84564bfdf3d7c7ba2c10
CRC32: 14985531
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --