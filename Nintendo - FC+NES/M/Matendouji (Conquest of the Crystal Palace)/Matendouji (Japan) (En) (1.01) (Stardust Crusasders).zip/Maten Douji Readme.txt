======================================================
==================Maten Douji=========================
=====================V1.01============================
Genre: Action

Source language: Japanese

Patch language: English

Author: Pennywise/Eien Ni Hen

E-mail: yojimbogarrett@gmail.com
http://yojimbo.eludevisibility.org/
 
======================================================
Maten Douji
======================================================
Background: 

Maten Douji was released in the US as Conquest of the
Crystal Palace. At the first glance the games seem
the same, but there are some differences. The first
stage has this skull monkey creature that was changed
to a slug. The biggest difference is in the third stage.
The Japanese version is much more creepy and they really
toned it down by changing the background and altering these
blue ghost babies that puke at you to these spider-like
creatures. It's quite noticable. I'm assuming this was
due to Nintendo's strict content policy that prohibited
"offsensive" content.

I've wanted to do this game for a while, but I never
got around to asking Eien Ni Hen until recently despite
knowing that her avatar on RHDN was from this game for
a few years now. I think it goes without saying that
my hacking work is very impressive and looks mighty fine.
Naturally I consider it to be far more superior than the
official localization which wasn't exactly terrible, but
it's limited by a few things. The main limiting factor is
a lack of space in the ROM to fit the english text. I was
easily able to bypass this by expanding the ROM something
that wasn't possible for the localization due to what I
believe was ultimately a cost issue. The other limiting
factor is that the game only displayed 2 lines of text
per screen. Not a big deal for the story stuff, but it
makes a huge difference in the shop text.

Now that I've got all that out of the way, I highly
recommend that this game be played because it's
awesome and really cool. I would describe it as
an arcade style action game with a clear oriential
influence. You can't go wrong and can easily beat it
in an afternoon.


======================================================
Game Tips
======================================================

* To reach a secret area in Stage 2, after the mid-point
(of where you fight the dog and the soldier at the stairway),
go to the area where Kim's second shop is. Continue right
and find some pits. Jump down the second pit.

* In the course of your journey, you can piss off the shop
girl or make her fall in love with you. Not sure if the latter
leads to discounts, but play around with her to find out.

======================================================
Notes from the translator
======================================================
This game was originally released in English as
"Conquest of the Crystal Palace", and a lot was changed
from the Japanese version. The story stayed the same
(sort of), but the characters' names and locations in
the game were completely changed. This was probably due
to Nintendo's censorship standards, as the Japanese
version has a ton of religious overtones.

When comparing the original localization with the
Japanese version, it really isn't terrible--just
heavily censored and shortened drastically.

Also surprising was the fact that very few of the on-
screen kanji were actually translated in the first
English release, including kanji at the beginning
of each stage and on various weapons. I opted not
to have some of them translated in our version
for space reasons, and because they look darn cool.
Below are the kanji that were left in:

�� (Symbol on the Lively Orb) - Swallow (the bird)
�� (Symbol the Dummy Orb - Drunk
�h (Symbol on the Firecracker - Awe

You can also obtain items with the kanji �� (profit),
�� (energy), �� (strength), �� (orb), �� (body), and
�� (leap).

The giant �V that appears on the floor in the opening
scene means "Heaven", and in the last stage an 
abbreviated version of the symbol �� ("demon") can
be seen in the background.

Also, some of the item names are actually Japanese
puns, a fact that was completely ignored in the
previous translation. I tried to keep the flavor of
the original names, so that's why some of the item
names (Good and Plenty Herb, for example), seem kind
of silly.

I hope you enjoy playing the game as much as I've
enjoyed translating it!

======================================================
Version History
======================================================
V 1.0 - Initial release
V 1.01 - Minor update that removes an unnecessary 0
======================================================
Patching Instructions
======================================================
The patch is in the BPS format and needs to be applied
with byuu's patcher, beat.

These are some of the links where you can download it.
The patching process is the same as IPS.

http://byuu.org/programming/beat/
http://www.romhacking.net/utilities/893/
http://www.smwcentral.net/?p=section&a=details&id=5917

Apparently beat has issues working on XP, but I've been
told the third link works on XP.

Apply the patch to the original Japanese version of the
ROM:

Matendouji (Japan).nes

P.S.

Support the game industry by buying used games!

Even if the money doesn't go to the developers
directly, as the games become rare and harder
to find, the price goes up, and people become
more inclined to buy new releases "while they can!"

======================================================

Credits go to:

Pennywise - main hacking, testing

Eien Ni Hen - translation, testing

DvD - title screen design and hacking, misc graphics

Sin Batsu - misc graphics

aishsha - thanks

All those who contributed into this process.

======================================================


Compiled by Pennywise. October 2013.
