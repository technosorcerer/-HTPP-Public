=====================
MATENDOUJI / CONQUEST OF THE CRYSTAL PALACE 
PATCH BAHASA INDONESIA by Anubis-chan
=====================

-For English readme, please scroll to the bottom!-

Terima kasih sudah mendownload patch ini. Ini adalah patch bahasa Indonesia untuk game Matendouji (JP) v1.0. Game ini juga dikenal dengan judul Conquest of the Crystal Palace, tapi patch ini untuk versi ROM Jepangnya. 

Silakan ikuti langkah berikut ini untuk mengaplikasikan file patch IPS ini:

1. Download ROM game Matendouji versi Jepang (bukan versi USA), bisa dicari di situs penyedia ROM game NES. Pastikan sizenya adalah 385KB.

2. Download program IPS patcher seperti Lunar IPS (https://fusoya.eludevisibility.org/lips/download/lips102.zip)

3. Pilih apply patch, dan pilih file IPS bahasa Indonesia, dan pilih ROM game Matendouji versi bahasa Jepang.

4. Bila betul maka semua teks akan berubah menjadi bahasa Indonesia saat dimainkan (tested via Nester, FCEUX, dan Nestopia).

5. Adapun bagian yang ditranslasi hanyalah:
a. Prolog dan Dialog saat event.
b. Layar judul & copyright.
c. Semua dialog di Toko milik Kim / Lin.
Sedangkan lokasi game dan credit tidak dirubah untuk menjaga keaslian terminologi dan nama-nama creator game ini.

6. Bila membutuhkan akses cheat, silakan coba kode ini:
- SOUND TEST: Di layar judul tahan A+B dan tekan start.
- MASTER CHEAT: Di layar judul, tekan A+Select, B+Select, A+select, dan langsung tekan start. Bila betul, saat game dimulai kamu bisa mengaktifkan beberapa cheat ini:
a. Kebal 10 detik: Tahan Select + tekan tombol kanan.
b. Uang ekstra: Tahan Select + tekan tombol kiri.
c. Sepatu pegas: Tahan Select + tekan atas.
d. Pulihkan health: Tahan Select + tekan bawah.
e. Tambah nyawa: Tahan Select + tekan kanan-atas.
f. Pedang panjang: Tahan Select + tekan kiri-bawah.
g. Cermin Bulan: Tahan select + tekan kiri-atas.
h. Pulihkan Health anjing: Tahan Select + tekan kanan-bawah
- TAMBAH CREDIT CONTINUE: Di layar judul, tekan Select+B. Lalu tekan A+B bersamaan beberapa kali sampai jumlah Credit di layar judul terus bertambah.

Bagi yang menemukan bug atau typo, silakan kirim email ke cmartika@gmail.com. Terima kasih!

=========ENGLISH README VERSION=========

Thank you for downloading this patch. This is an Indonesian patch for the Matendouji JP v1.0 game.

Please follow the steps below to apply this IPS patch file:

1. Download the Japanese version of the Matendouji JP game ROM (not the USA version), you can find it on the NES game ROM provider site. Make sure the size is 385KB.

2. Download an IPS patcher program such as Lunar IPS (https://fusoya.eludevisibility.org/lips/download/lips102.zip)

3. Select apply patch, and select the Indonesian IPS file, and select the Japanese version of the Matendouji game ROM.

4. If true, all texts will change to Indonesian when played (tested via Nester, FCEUX, NESTOPIA).

5. The parts that are translated are:
a. Prologue and Dialogue during cutscenes
b. Title & copyright screen.
c. All dialogue, item description, and breaking news in Lin / Kim's shop.
Meanwhile, the game location and credits have not been changed to maintain the authenticity of the terminology and names of the game creators.

6. If you need cheat, try this code:
- SOUND TEST: On the Title screen, hold A+B and press start.
- MASTER CHEAT: On the Title screen, press Select+A, select+B, select+A, and immediately press start. If you do it correctly, you can perform these cheats while playing.
a. Coins: Hold Select, and press left
b. Energy: Hold Select, and press down.
c. Lives: Hold Select, and press up-right.
d. Invincibility: Hold Select, and press Right.
e. Jumping Shoes: Hold Select, and press Up.
f. Moon Mirror: Hold Select, and press Up-left.
g. Sword: Hold Select, and press down-left.
h. Dog Energy: Hold select, and press down-right.
- EXTRA CREDIT: On the Title screen, press Select+B. Then press A+B multiple times until the credit increased.

For those who find bugs, errors, or typos, please send an email to cmartika@gmail.com. Thank you!