·You can find more hacks from Crying Onion at this link:
https://www.romhacking.net/?page=hacks&genre=&platform=&game=&category=&perpage=20&order=&dir=&title=&author=crying+onion&hacksearch=Go

·You can also find him on Youtube, showing his projects (and those of others) here:
https://www.youtube.com/channel/UCKgNcvTtNkbT2hzIUZPHeuw

·And you can also contact the authors of the hack via Twitter:
@CryingOnion3
@ProtoPixelArt


#################################################
#						#
#						#
#	:::: Lupin III Gentle Thief ::::	#
#						#
#	::::	     ver.1.0	    ::::	#	
#						#
#################################################


1) Introduction

2) Features list

3) Patches and their features

4) Acknowledgements

____________________________________________________________________________________________________________________________________________


1) Introduction


Firstly, thanks for downloading this hack, which is the second collaboration between Crying Onion and Protopixel. This time, the project is
born from an idea of Protopixel, who is also in charge of the design of the title screen, sprites and objects. Crying Onion is in charge of
the implementation and after discussing it with its partner, the project is divided into two versions in which everyone can give free rein to
their creative freedom.

Mappy is a game co-developed and distributed by Namco, which was a huge hit in the arcades in 1983. A year later it was ported to the
Nintendo Famicom. Its mechanics are inspired by the children's game of cat and mouse (or cops and robbers): as the cute mouse-cop mentioned
in the title, we must recover valuable objects while dodging thieving cats. In some ways, being the thief and the enemies our pursuers makes
more sense, so it's the perfect basis for a hack starring the grandson of the most famous thief of all time.


2) Features list


Lupin III: Gentle Thief ver. 1.0


·The *.rar file contains two patches. Each patch pretends to be the western and Japanese version of the game, with several changes that make
them unique.

·Each version has a unique title, as was common in the Nintendo NES era, with the western title being "Lupin III: Gentle Thief" and the
Japanese title being "Lupin Sansei: Mugen no Teitaku", which can be translated as "Lupin 3rd: The Infinite Mansion".

·New title screens drawn by Protopixel and (in the case of the western version) partially redrawn by Crying Onion

·New sprites and items drawn by Protopixel inspired by the work of Monkey Punch
	
·Additional sprites and items for the western version and improvements in the background by Crying Onion


3) Patches and their features


·Lupin III Gentle Thief.ips -----------> Western version of the hack, with a unique title screen and several exclusive features

·Lupin Sansei Mugen no Teitaku.ips ----> Japanese version of the hack, with a unique title screen and several exclusive features


4) Acknowledgements


Especially to Ssicosomatic/Terwilf, for his teachings and help locating some elusive hex values. Also to Super Buni, colleague of both
creators who is always there with his suggestions and good vibes.