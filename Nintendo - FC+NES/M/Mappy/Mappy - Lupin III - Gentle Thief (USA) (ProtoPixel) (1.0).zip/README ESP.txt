·Puedes encontrar más hacks de Crying Onion en este link:
https://www.romhacking.net/?page=hacks&genre=&platform=&game=&category=&perpage=20&order=&dir=&title=&author=crying+onion&hacksearch=Go

·También puedes encontrarle en Youtube, mostrando sus trabajos (y los de otros) aquí:
https://www.youtube.com/channel/UCKgNcvTtNkbT2hzIUZPHeuw

·Y también puedes contactar a los autores y conocer su trabajo a través de Twitter:
@CryingOnion3
@ProtoPixelArt


#################################################
#						#
#						#
#	:::: Lupin III Gentle Thief ::::	#
#						#
#	::::	     ver.1.0	    ::::	#	
#						#
#################################################


1) Introducción

2) Lista de cambios

3) Parches y sus características

4) Agradecimientos

_______________________________________________________________________________________________________________________________________________________


1) Introducción


En primer lugar, gracias por descargar este hack, el cual es la segunda colaboración entre Crying Onion y Protopixel. En esta ocasión, el
proyecto nace de una idea de Protopixel que además, se hace cargo del diseño de la pantalla de título, sprites y objetos. Crying Onion se
encarga de la implementación y tras hablarlo con su socio, el proyecto se divide en dos versiones en la que cada cual puede dar rienda suelta
a su libertad creativa.

Mappy es un juego co-desarrollado y distribuido por Namco, que cosechó un gran éxito en los salones recreativos en 1983. Un año más tarde
es portado a Nintendo Famicom. Sus mecánicas se inspiran en el juego infantil del gato y el ratón (o policias y ladrones): como el simpático
policía-ratón mencionado en el título, deberemos recuperar objetos de gran valor mientras esquivamos a los gatos ladrones. En cierto modo,
ser nosotros el ladrón y los enemigos nuestros perseguidores tiene más sentido, por lo que es la base perfecta para un hack protagonizado
por el nieto del ladrón más famoso de todos los tiempos.


2) Lista de cambios


Lupin III: Gentle Thief ver. 1.0


·El archivo comprimido contiene dos parches: cada uno de ellos simula ser la versión occidental y japonesa del juego, con varios
cambios que las hacen únicas

·Cada versión tiene un título único, como era bastante habitual en la Nintendo NES, siendo el título occidental "Lupin III: Gentle Thief"
y el título japonés "Lupin Sansei: Mugen no Teitaku", que puede traducirse como "Lupin 3º: La Mansión Infinita"

·Nuevas pantallas de título dibujadas por Protopixel y (en el caso de la versión occidental) parcialmente rediseñada por Crying Onion

·Nuevos sprites y objetos dibujados por Protopixel inspirados en la obra de Monkey Punch
	
·Sprites y objetos adicionales para la versión occidental y mejoras en los escenarios a cargo de Crying Onion


3) Parches y sus características


·Lupin III Gentle Thief.ips -----------> Versión occidental del hack, con pantalla de título y varios elementos únicos

·Lupin Sansei Mugen no Teitaku.ips ----> Versión japonesa del hack, con pantalla de título y varios elementos únicos


4) Agradecimientos


En especial a Ssicosomatico/Terwilf, por sus enseñanzas y ayudar a localizar algunos valores hexadecimales que resultaban esquivos.
También a Super Buni, colega de ambos creadores que siempre está ahí con sus sugerencias y su buena energía