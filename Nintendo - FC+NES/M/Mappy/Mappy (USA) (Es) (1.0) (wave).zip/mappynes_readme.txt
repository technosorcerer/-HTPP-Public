Mappy (NES)
Traducción al Español v1.0 (25/10/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mappy (Japan).nes
MD5: b0ba60bc0866efc73ccd62defc0120d5
SHA1: 30a06c63f13d33dc5bb307f15d4be7d4478740af
CRC32: 3f0e8e0a
24592 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --