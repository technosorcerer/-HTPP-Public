Maniac Mansion Mouse Hack
Version 4
By Ryan Souders, AKA "HonkeyKong"

This hack allows you to play Maniac Mansion for NES with the SNES Mouse connected to controller port 2. This can be done by way of a simple adapter. One can be constructed from a couple of NES/SNES extension cables, as it's just straight wiring, or one can be purchased from Raphnet or MisterAddons at the links below.

https://www.raphnet-tech.com/products/snes_to_nes_cable/index.php
https://misteraddons.com/products/snes-controller-to-nes-console-adapter

Version 4 introduces a new mouse driver as well as a new input subroutine, as there were issues with using the official SNES mouse and the sensitivity being too low. The new version not only detects the mouse, but detects whether it's a Hyperkin or Nintendo mouse, and adjusts sensitivity accordingly. The drawback here is that adjusting the sensitivity to an acceptable threshold on the Nintendo mouse causes it to be way too sensitive in emulators.

To remedy this situation, I've created two versions of the patch. One is for hardware, and is compatible with both mice. The other is for emulators, and treats the mouse like a stock SNES mouse.

Version 3 fixes some issues with sluggishness reading the start and select buttons on controller 1, as well as changes the functionality of the right click on the mouse, to cycle through commonly used commands. The mouse driver has also been updated to hopefully function more smoothly, and fall back better if no mouse is detected.

If you have any issues or suggestions, feel free leave a comment on the RHDN entry or the following forum thread.

https://www.romhacking.net/forum/index.php?topic=36913.0