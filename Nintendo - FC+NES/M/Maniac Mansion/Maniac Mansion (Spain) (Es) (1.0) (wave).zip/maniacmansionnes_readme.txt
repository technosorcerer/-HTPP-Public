Maniac Mansion (NES)
Traducción al Español v1.0 (03/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basada en la versión española del juego con algunos cambios:
-Reinsertados ÁÉÍÓÚÜ y modificadas las fuentes, por algún motivo los caracteres estaban en la rom pero no se usaban al traducir el guion a la NES.
-Traducido "LICENSED BY NINTENDO" y "ALL RIGHTS RESERVED".
-Arreglados algunos bugs de líneas demasiado largas.
-Añadidos algunos acentos no presentes en el guion original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Maniac Mansion (S) [!].nes
MD5: 0bfa6ddeb5cc8f2baff76118194a208e
SHA1: b50d386f17de65f682b0d6e85e4258c178e59823
CRC32: 901d691d
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --