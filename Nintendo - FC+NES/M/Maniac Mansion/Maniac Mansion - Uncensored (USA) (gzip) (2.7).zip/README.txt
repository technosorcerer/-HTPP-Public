Maniac Mansion for the Nintendo Entertainment System was heavily censored prior to its release.
This hack seeks to replace as much censored content as possible from the original Commodore 64 version.
The following changes are included:

Graphics and Gameplay

- The skeleton is added to the dungeon (never before seen in the NES version)
- The Kill Thrill arcade game is replaced (never before seen in the NES version), with optional patch
for Douglas Crockford's Muff Diver (first seen in previous hack)
- The pennant is added in Weird Ed's room (first seen in previous hack)
- The surplus body parts are now in Cousin Ted's room (never before seen in the NES version)
- The poster and calendar are back in Cousin Ted's room (never before seen in the NES version), with optional graphics and text patch
- The Disco Sucks poster is restored in Green Tentacle's room
- The shower text, for a good time, is restored
- The statue in the hallway is restored
- Green Tentacle kills the player after hearing the tentacle mating call recording (never before seen in the NES version)

Text Changes

- Edna: Dungeon dialog (I should have tied you to my bed etc.)
- Edna: Phone dialog (heavy breathing etc.)
- Ed: He hasn't eaten in 5 years
- Dr. Fred: getting your pretty brains sucked out.
- Dr. Fred: The meteor is going to be pissed!
- Dr. Fred: You're going to piss off the meteor.
- Dr. Fred: Don't be a smart ass!
- Green Tentacle: I think I'll kill myself!
- Purple Tentacle: Kill him.
- Meteor: Dr. Fred, release the women, all the women.
- Meteor: Prepare to die!
- Player: Damn! I broke it! (for Ed's piggy bank)
- Calendar text in Ted's room
- Brain diagram's Chewy carmel center
- SCUMM System and NES SCUMM version in credits

Other Fixes

- The glitched graphics in the room under the house are fixed
- The glitched coin box graphics in the arcade are fixed
- The glitched graphics for the developer under the house are fixed
- The leftover pennant object in Weird Ed's room is removed
- The leftover keypad object in the hallway is removed
- The interactivity for the radioactive slime in the basement is restored
- The fence mask is fixed in the starting screen so that the player is completely behind it
- The colors for the right-side gargoyle on the stairs are corrected
- The border color is fixed when selecting Michael on the character select screen
- The meteor's sprite graphics are fixed
- The Lucasfilm logo is centered vertically and the misplaced shine sprite is fixed
- I don't want my tape back text correctly assigned to Green Tentacle instead of player

This hack is built upon the Maniac Mansion Decoded hack and also includes the Maniac Mansion Mouse Hack.


Optional Patches

The following optional patches are included.

- char_select.ips * - Applies rounded corners to the character select screen.
- fridge.ips * - Rearranges the fridge to recolor the lettuce green and the batteries brown.
- hasnt_slept.ips - Use the censored text "hasn't slept in 5 years".
- lflu_rah.ips - Change the pennant text to read L.F.L.U. Rah! like the original.
- muff_diver.ips - Rename the censored arcade game to Muff Diver as suggested by Douglas Crockford.
- original_dungeon.ips - Remove the skeleton and layout changes in the dungeon.
- playmummy.ips - Use the censored text and graphics from the prototype for Ted's calendar.
- portraits.ips * - Improves the various portraits in the house, including Fred in Edna's room, Edna in Fred's room, Fred in Edna's attic, and the family portrait in the den.
- remove_mouse.ips - Remove the mouse driver.
- statue.ips * - Improves the graphics of the statue in the hallway.
- star_wars_poster.ips * - Add the Star Wars poster to the arcade room.
- title_screen.ips - Uses the title screen from the Japanese version, which is based on the C64 graphics.
- under_house_enhanced.ips * - Improves the post and valve graphics and fixes the background mask.

* Patch is applied by default. You can select the base patch to omit these additions.

Contact

Overlooked something? Want more optional patches? Glitches? PM gzip.


Patching

Use the online patcher at romhacking.net (or the patcher of your choice) to apply either of the bps patch to:

ROM info:

Database match: Maniac Mansion (USA)

File SHA-1: 7317D1F1096B57F6AB8F3001BCDD35665C291B1A
File CRC32: 68309D06
ROM SHA-1: 8A8BBECC77FDF59826257754F357D38A7F825971
ROM CRC32: D9F5BD1
