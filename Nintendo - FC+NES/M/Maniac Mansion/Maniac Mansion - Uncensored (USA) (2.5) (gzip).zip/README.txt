Maniac Mansion for the Nintendo Entertainment System was heavily censored prior to its release.
This hack seeks to replace as much censored content as possible from the original Commodore 64 version.
The following changes are included:

Graphics and gameplay:

- The skeleton is added to the dungeon (never before seen in the NES version)
- The Kill Thrill arcade game is replaced (never before seen in the NES version), with optional patch
for Douglas Crockford's Muff Diver (first seen in previous hack)
- The pennant is added in Weird Ed's room (first seen in previous hack)
- The surplus body parts are now in Cousin Ted's room (never before seen in the NES version)
- The poster and calendar are back in Cousin Ted's room (never before seen in the NES version), with optional graphics and text patch
- The Disco Sucks poster is restored in Green Tentacle's room
- The shower text, for a good time, is restored
- The statue in the hallway is restored
- Green Tentacle kills the player after hearing the tentacle mating call recording (never before seen in the NES version)

Text changes:

- Edna: Dungeon dialog (I should have tied you to my bed etc.)
- Edna: Phone dialog (heavy breathing etc.)
- Ed: He hasn't eaten in 5 years
- Dr. Fred: getting your pretty brains sucked out.
- Dr. Fred: The meteor is going to be pissed!
- Dr. Fred: You're going to piss off the meteor.
- Dr. Fred: Don't be a smart ass!
- Green Tentacle: I think I'll kill myself!
- Purple Tentacle: Kill him.
- Meteor: Dr. Fred, release the women, all the women.
- Meteor: Prepare to die!
- Player: Damn! I broke it! (for Ed's piggy bank)
- Calendar text in Ted's room
- Brain diagram's Chewy carmel center
- SCUMM System and NES SCUMM version in credits

Other fixes:

- The glitched graphics in the room under the house are fixed
- The glitched coin box graphics in the arcade are fixed
- I don't want my tape back text correctly assigned to Green Tentacle instead of player
- The fence mask is fixed in the starting screen so that the player is completely behind it
- The colors for the right-side gargoyle on the stairs are fixed
- The border color is fixed when selecting Michael on the character select screen
- The glitched graphics for the puddle of developer under the house are fixed
- Interactivity with the radioactive slime in the basement is restored

This hack is built upon the Maniac Mansion Decoded hack and also includes the Maniac Mansion Mouse Hack.

Optional Patches:

The following optional patches are included:

- lflu_rah.ips - Change the pennant text to read L.F.L.U. Rah! like the original.
- muff_diver.ips - Rename the censored arcade game to Muff Diver as suggested by Douglas Crockford.
- original_dungeon.ips - Remove the skeleton and layout changes in the dungeon.
- playmummy.ips - Use the censored text and graphics from the prototype for Ted's calendar.
- remove_mouse.ips - Remove the mouse driver.
- star_wars_poster.ips - Add the Star Wars poster to the arcade room.

Contact:

Overlooked something? Want more optional patches? Glitches? PM gzip.

Patching:

Use the online patcher at romhacking.net (or the patcher of your choice) to apply the bps patch to:

ROM info:

Database match: Maniac Mansion (USA)

File SHA-1: 7317D1F1096B57F6AB8F3001BCDD35665C291B1A
File CRC32: 68309D06
ROM SHA-1: 8A8BBECC77FDF59826257754F357D38A7F825971
ROM CRC32: D9F5BD1
