2.5
Update mouse driver: right-click skips cutscenes, no more cursor wrapping.
Include fixes from Maniac Mansion Decoded: developer puddle graphics, radioactive slime interactivity.

2.4
Fix interaction with Star Wars poster so that it's readable.

2.3
Update mouse driver and include fixes from Maniac Mansion Decoded.

2.2
Add optional patches for Star Wars poster, original dungeon, and mouse driver removal.
Rearrange calendar graphics and optional patch so that the uncensored version is default.

2.1
Include optional patches.

2.0
Initial release.
