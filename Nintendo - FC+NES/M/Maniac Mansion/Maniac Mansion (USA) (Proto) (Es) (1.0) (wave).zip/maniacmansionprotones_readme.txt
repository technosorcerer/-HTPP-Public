Maniac Mansion (Prototipo)
Traducci�n al Espa�ol v1.0 (01/06/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Maniac Mansion (Prototipo)
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Maniac Mansion (Prototipo)
-----------------
Traducci�n del prototipo sin censura de la aventura gr�fica para NES.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Maniac Mansion (U) (Prototype) [!].nes
262.160	bytes
CRC32: bba3ef7e
MD5: 6033f75e5a55e0ec14bc4eb1d915c01f
SHA1: ea68e251bad98cc492e5b88b27f19cfa0d981b3e

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --