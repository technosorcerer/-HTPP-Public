Miracle Ropit's - 2100 Nen no Daibouken (NES)
Traducción al Español v1.0 (26/12/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Miracle Ropit's - 2100 Nen no Daibouken (Japan).nes
MD5: fcf6691ed579997e8908c18f948f1600
SHA1: 2e3cbd35b2d12f46dccbc82b6ea55cdfb03d6c19
CRC32: ac8ae5ef
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --