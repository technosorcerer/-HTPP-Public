"Pocket Zaurus: Swords of the Ten Kings"
Traducción al Español Ver. 1.0 (13/12/2024)
por Max1323 (Traducciones Max1323).
Basada en la gran traducción de DvD Translations.
---------------------------------------------------
Descripción:
El Maestro Hashimoto fue convertido en Pocket Zaurus por Salamander. Pocket Zaurus deberá atravezar por diferentes eras
para derrotar a los comandantes de Salamander y llegar hasta
él para devolverlo a la normalidad.

Desarrollado: TOSE
Publicado:    Bandai
Lanzamiento:  27/02/1987 (JAP)
---------------------------------------------------
Acerca del proyecto:
-La mayoría de los textos están traducidos. Se agregaron
los caracteres españoles.
-La mayoría de los gráficos están traducidos.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS (PC)
Utilizar UniPatcher (Android)
Utilizar Rom Patcher (Parcheador Online):
https://romhackplaza.org/patch/

Archivo IPS
Pocket Zaurus - Juu Ouken no Nazo (Japan).nes
File Size     256 KB
File MD5      C5DA64A3549C9D3458BE2D0CD07A99CE        
File SHA-1    B0BC4361A044C64F605AFAF9487253E9C56D7BC5
File CRC32    62E7AEC5