Edited: graphics,font,text and lots of colors.
Hope you like it \m/.
wolfamancer97 a.k.a.MVH.