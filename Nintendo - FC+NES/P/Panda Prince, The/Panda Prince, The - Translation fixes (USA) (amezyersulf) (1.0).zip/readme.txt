The Panda Prince - translation fixes
====================================

This is a patch intended for fixing the text in the cutscenes, which had Chinese poorly translated to English.

VERSION 1.0
Patch by amezyersulf (amazeyourself)