Gird your loins, it's time for Skinball!

Features:

Better balls
Better colors
Dick flippers
Babes
Cocks & Beavers
And the infamous WALLLLLL OF BUTTS

Patch to Pinball (World).nes rom