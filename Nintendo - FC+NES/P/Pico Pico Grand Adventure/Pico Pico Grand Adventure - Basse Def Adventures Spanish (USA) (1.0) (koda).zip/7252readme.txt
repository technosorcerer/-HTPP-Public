Basse Def Adventures (USA Europe) (Fr) (Aftermarket) (Unl)
Traducido por koda 2024

------------------------------------------------------------------------------------------
INDICE
------------------------------------------------------------------------------------------

1. INSTRUCCIONES
2. VERSIONES
3. ERRORES CONOCIDOS
4. INFORMACIÓN ADICIONAL
5. CONTACTO

-------------------------------------------------------------------------------------------
1. INSTRUCCIONES
-------------------------------------------------------------------------------------------

Este parche debe ser aplicado a la versión americana o europea.

La ROM debe tener el nombre: Basse Def Adventures (USA Europe) (Fr) (Aftermarket) (Unl)
no ocupar la versión WORLD.

La ROM es:

Database match: not found
Database: No-Intro: Nintendo Entertainment System (v. 20210216-231042)
File SHA-1: 68270F3C00E9690363B0D6DCD8006E47472E61E8
File CRC32: 5006C82F
ROM SHA-1: C84FD1CFFC340647D0FC40215D68034BC041ED5D
ROM CRC32: F8253658

Utilizen "Lunar IPS" o "Floating IPS"
Pueden descargarlo de acá:
https://www.romhacking.net/utilities/240/

-------------------------------------------------------------------------------------------
2. VERSIONES
-------------------------------------------------------------------------------------------

version 1.0 (23/03/2024):

- Traducción completa al español.


-------------------------------------------------------------------------------------------
3. ERRORES CONOCIDOS
-------------------------------------------------------------------------------------------

- Ninguno que yo sepa, informar de alguno.

-------------------------------------------------------------------------------------------
4. INFORMACIÓN ADICIONAL

-------------------------------------------------------------------------------------------

La traducción no fue muy dificil, sin embargo hay una parte que no traduje porque no vi que
fuera parte del juego, mas bien parece ser un easter egg. Si lo logran hacer aparecer
enviarme un correo.

-------------------------------------------------------------------------------------------
5. CONTACTO
-------------------------------------------------------------------------------------------

Traducción hecha por rodrigo muñoz, alias koda
Cualquier error enviar un mensaje a mi correo rodrigo.23luis@gmail.com