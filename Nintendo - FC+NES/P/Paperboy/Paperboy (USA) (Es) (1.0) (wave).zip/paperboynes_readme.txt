Paperboy (NES)
Traducción al Español v1.0 (02/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Paperboy (USA).nes
MD5: c82b4e3cfb6f56845b8064b5da780124
SHA1: ca7641ae940cf656c12e8e697a50c34959f1d468
CRC32: eb171d77
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --