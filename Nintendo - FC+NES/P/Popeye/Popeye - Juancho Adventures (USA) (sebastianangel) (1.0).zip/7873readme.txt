Juancho Adventures
This patch replaces the well known characters with others of my own (juancho and his friends),
changes many color palettes and replaces sprites and tiles and adds the possibility to control the enemy 
with the controller B a hack created by (Morgan Johansson) 
and special thanks to Terwilf who introduced the new title screen!