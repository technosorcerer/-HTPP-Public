

● You can find many more hacks from the same author at this link:
https://www.romhacking.net/?page=hacks&genre=&platform=&game=&category=&perpage=20&order=&dir=&title=&author=crying+onion&hacksearch=Go

● You can also find him on Youtube, showing his work (and that of others) here:
https://www.youtube.com/channel/UCKgNcvTtNkbT2hzIUZPHeuw

● And of course, if you want to follow closely his current projects, you can do it through their twitter account, where he usually share
screenshots, videos, thougts, etc:
@CryingOnion3
                    
                    
                     
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ ⣀⣠⡤⣤⣤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ ⢀⡴⠞⢉⣠⡴⣶⣿⣧⡈⠙⠶⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ ⢀⡴⠋⣤⢾⡏⣈⠀⠘⣿⡏⠙⠳⡄⠙⢦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ ⢀⡟⢠⣼⣧⢏⣁⣇⡿⣿⢿⣧⣄⠀⢿⣸⡄⢻⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀       
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ ⣸⢁⠇⣿⠋⡉⠀⣍⡙⢡⣿⣇⣙⣾⣶⡍⢣⡄⢷⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀        
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ ⢠⡏⢸⠛⡇⠀⢦⡈⠉⣽⣿⣿⣿⣿⣷⣿⣿⡀⣧⠸⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀                   ##############################################
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ ⢸⣿⡿⡄⣧⠈⠉⠳⣬⣹⣿⡞⠋⠚⠀⣀⣥⡜⣮⠇⣧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣠⠀⠀⠀⠀⠀⠀⠀                 #                                            # #
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ ⠸⡿⢆⣿⡇⠉⠉⣑⣿⣯⣿⣇⣛⣺⡿⠛⣿⣿⣶⠂⠻⣆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡴⣷⠇⠀⠀⠀⠀⠀⠀⠀               #                                            #   #
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ ⢷⢨⣿⣷⢦⣾⠛⣩⣟⣽⣟⢯⣝⢿⠛⣿⠉⣷⣿⣧⡈⢧⣀⠀⠀⠀⠀⠀⠀⠀⣠⣾⠟⢁⣀⣀⣀⠀⠀⠀⠀⠀             #  :::: Resident Evil 3: Chibi Edition ::::  #    #
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ ⢸⢶⣻⣾⣿⠉⣴⣿⡟⣿⡟⣷⣬⡛⠉⠙⣤⣿⢸⣿⣿⡷⣌⠙⢦⣄⠀⠀⠀⢞⣵⢛⣫⠉⣇⢋⣯⣍⣟⢦⣄⠀           #                                            #     #
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ ⠸⣦⣿⣿⣽⣸⣿⣿⣿⣷⣷⣿⡿⣿⡆⢰⣿⡃⣼⣇⢹⣿⣿⣇⡀⠬⣝⠲⠶⣯⣟⡳⠛⡴⣻⣶⣆⡀⠿⣷⡝⣦         #   ::::           ver.1.0            ::::   #       #
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠀⢰⡇⠀⠀⠀ ⠈⠉⢻⣿⣿⣷⣿⡉⠉⡏⠏⠸⠂⠉⠙⣷⢸⢹⡇⣸⣿⣧⣿⣿⡿⢿⣾⡾⢍⠓⣦⠈⡉⣛⠿⣿⣿⣿⣷⡘⡷⠇⣹       #                                            #        #
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡇⢸⠃⠀⠀⠀⠀⠀ ⢸⣼⣿⣿⢿⣧⣤⣵⣰⣠⣴⠶⢾⣿⠸⣶⢿⣿⣷⣅⣾⣿⣷⣄⡛⠛⣿⣿⣬⣓⡆⣈⠛⣼⣟⣻⠶⠾⣿⣷⣿      #                                            #         #
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡖⠒⠒⠂⣠⢴⣶⣿⣻⣿⠈⣿⣿⣷⣽⣿⣿⣿⣿⢿⢠⣿⣿⣿⣿⣿⣝⡻⠿⢿⣿⣾⣿⣿⢻⣛⠧⡾⣿⣿⢷⣾⡉⢹⣿⡏⠙     ##############################################           #
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠁⠀⢠⣾⠿⣭⣿⣿⣿⣿⣦⡉⠛⠉⠛⠻⠿⠟⠛⣡⣼⣿⢻⣷⡮⢷⣻⠿⣎⢳⡺⣽⠁⣘⢮⣯⣿⣿⣽⣿⣿⣿⣷⠞⡁⠀⠀     #                                            #           #
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠤⠤⠤⢤⣏⣰⣷⣿⣿⣿⣿⣿⣿⣿⣄⡀⣀⣀⣀⣤⣾⣿⣿⣿⣧⣿⣧⣛⠛⣷⣈⠳⣄⣤⣸⣿⣷⣯⣳⣭⣘⣷⢟⣢⠵⠚⠁⠀⠀     #                                            #           #
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣉⣉⣭⠭⣽⣾⣿⣿⣿⡿⡟⢡⣽⣿⣿⣟⣿⣿⡿⣿⣿⣿⣿⣿⣿⡯⢉⣚⣿⣿⣾⣺⣷⣾⡟⠿⠿⢹⡴⠟⣻⡯⠖⠋⠁⠀⠀⠀⠀⠀     #      1) Introduction                       #           #
⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡤⠖⣋⡩⠶⣶⡞⣡⣾⣿⣿⢏⣾⣷⣿⣿⣿⣿⣿⣿⣏⣸⣿⠿⢿⣏⡻⣾⣿⣿⣿⣿⡿⠏⠙⠉⣻⣵⣶⡿⠿⠞⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀     #                                            #           #
⠀⠀⠀⠀⠀⠀⠀⣠⡴⠋⢒⡴⢯⣤⡿⢋⡼⣻⣿⡿⣻⣿⣿⣿⡿⡿⣥⣿⣿⠟⣹⣿⣗⣀⣰⣿⢿⡟⣿⡉⠉⠀⠀⠀⠀⠀⢹⣄⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀      #      2) Features list                      #           #
⠀⠀⠀⠀⠀⣰⠞⣱⣴⠿⣫⠇⣤⠟⣠⣿⣡⠟⢠⣾⣽⣯⣾⠁⡀⣠⣿⣿⡽⣑⣻⡾⢿⣛⣿⠭⠙⠚⠛⢳⡄⠀⠀⠀⣀⣀⠀⢻⣷⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀      #                                            #         #
⠀⠀⠀⠀⣾⡟⣱⣿⣥⣾⣅⣰⢏⣼⡟⠷⠏⠠⢿⣽⣯⠬⠵⠿⠾⠓⠋⠈⠉⠁⠉⠳⢯⣀⢀⠀⠀⠀⠀⠀⢻⡀⠀⣾⡟⣋⣙⡆⢿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀       #⠀     3) Patches and their features         #       #
⠀⠀⢀⣾⣽⢠⣿⣡⣿⣦⣾⢃⡾⠁⠉⢛⣻⣿⣿⠟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⢿⠇⠀⠀⠀⠀⠈⢷⡈⠿⢿⡿⠿⣃⣬⡾⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀       #                                            #      #
⠀⠀⡾⣸⢧⣏⣿⣿⢟⡿⣱⠏⠀⠁⣰⡿⠻⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠀⠀⠀⠀⠀⠀⠈⠷⠤⠶⠞⠛⠉⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀        #      4) Acknowledgements                   #    #
⠀⣸⣱⣿⢻⢿⡟⣴⡟⣱⠃⠀⠀⢠⡿⠓⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀         #                                            #   #
⠀⡿⣿⡏⣼⣿⣸⢟⣴⡇⢤⣤⣖⣿⣤⠤⢄⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀         #                                            # #
⢸⣯⣿⣷⣿⣿⣻⢿⣿⣵⣯⡍⠁⢤⣿⣷⣿⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀         ##############################################
⠈⢿⣏⣿⣼⣿⢿⣼⡇⠉⠁⠀⠀⠀⠈⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠈⣯⡎⢿⣿⣻⣿⠆



______________________________________________________________________________________________________________________________________________


1) Introduction


	Firstly, thanks for downloading this hack that started as a joke between buddies and has become the first collaboration between
	Protopixel (sprites) and Crying Onion (programming and additional graphics).

	"Popeye" is a Nintendo video game based on the eponymous character, which after being a huge hit in the arcades in 1982, was ported
	only a year later to the beloved Famicom.

	Being a game developed and published in the early days of the Famicom, it is needless to say that we are talking about a pretty
	straightforward game, although we should not underestimate the fun that can be found in its 24 kylobites of memory, nor the group of
	crazy guys who thought it was a good idea to create this crossover.


2) Features list


	Resident Evil 3: Chibi Edition ver. 1.0

		● Redesigned title screen inspired by Capcom's well-known franchise.

		● Two versions of the hack have been made, with the franchise title localized to the Western and Japanese markets.
		
		● New text font (Calderon Majuscule Roman, created by James Calderon and available from RHDN).

		● New sprites of Jill Valentine, Leon S. Kennedy, Carlos Oliveira and of course, the deadly Nemesis.

		● Stages have been redrawn to make them feel more in tune with the RE/BH universe.

		● A bunch of references and some easter eggs have been added for the enjoyment of fans of this saga.


3) Patches and their features


	● RE3 CHIBI.ips ---------> Title screen localized for western audiences

	● BH3 CHIBI.ips ---------> Title screen localized for Japanese audiences


4) Acknowledgements

	● To Super Buni, who had the original idea for this project

	● To Protopixel, for providing his pixelart skills

	● And of course, to all those who support me from my Youtube channel, Twitter and the RHDN Community