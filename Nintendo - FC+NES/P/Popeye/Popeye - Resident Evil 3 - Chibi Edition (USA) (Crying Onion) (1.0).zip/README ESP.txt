

● Puedes encontrar más hacks del mismo autor en este link:
https://www.romhacking.net/?page=hacks&genre=&platform=&game=&category=&perpage=20&order=&dir=&title=&author=crying+onion&hacksearch=Go

● También puedes encontrarle en Youtube, mostrando sus trabajos (y los de otros) aquí:
https://www.youtube.com/channel/UCKgNcvTtNkbT2hzIUZPHeuw

● Y por supuesto, si quieres seguir de cerca proyectos en curso puedes hacerlo a través de su cuenta de Twitter, donde suele compartir
capturas de pantalla, videos, pensamientos, etc:
@CryingOnion3
                    
                    
                     
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ ⣀⣠⡤⣤⣤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ ⢀⡴⠞⢉⣠⡴⣶⣿⣧⡈⠙⠶⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ ⢀⡴⠋⣤⢾⡏⣈⠀⠘⣿⡏⠙⠳⡄⠙⢦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ ⢀⡟⢠⣼⣧⢏⣁⣇⡿⣿⢿⣧⣄⠀⢿⣸⡄⢻⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀       
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ ⣸⢁⠇⣿⠋⡉⠀⣍⡙⢡⣿⣇⣙⣾⣶⡍⢣⡄⢷⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀        
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ ⢠⡏⢸⠛⡇⠀⢦⡈⠉⣽⣿⣿⣿⣿⣷⣿⣿⡀⣧⠸⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀                   ##############################################
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ ⢸⣿⡿⡄⣧⠈⠉⠳⣬⣹⣿⡞⠋⠚⠀⣀⣥⡜⣮⠇⣧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣠⠀⠀⠀⠀⠀⠀⠀                 #                                            # #
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ ⠸⡿⢆⣿⡇⠉⠉⣑⣿⣯⣿⣇⣛⣺⡿⠛⣿⣿⣶⠂⠻⣆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡴⣷⠇⠀⠀⠀⠀⠀⠀⠀               #                                            #   #
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ ⢷⢨⣿⣷⢦⣾⠛⣩⣟⣽⣟⢯⣝⢿⠛⣿⠉⣷⣿⣧⡈⢧⣀⠀⠀⠀⠀⠀⠀⠀⣠⣾⠟⢁⣀⣀⣀⠀⠀⠀⠀⠀             #  :::: Resident Evil 3: Chibi Edition ::::  #    #
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ ⢸⢶⣻⣾⣿⠉⣴⣿⡟⣿⡟⣷⣬⡛⠉⠙⣤⣿⢸⣿⣿⡷⣌⠙⢦⣄⠀⠀⠀⢞⣵⢛⣫⠉⣇⢋⣯⣍⣟⢦⣄⠀           #                                            #     #
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ ⠸⣦⣿⣿⣽⣸⣿⣿⣿⣷⣷⣿⡿⣿⡆⢰⣿⡃⣼⣇⢹⣿⣿⣇⡀⠬⣝⠲⠶⣯⣟⡳⠛⡴⣻⣶⣆⡀⠿⣷⡝⣦         #   ::::           ver.1.0            ::::   #       #
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠀⢰⡇⠀⠀⠀ ⠈⠉⢻⣿⣿⣷⣿⡉⠉⡏⠏⠸⠂⠉⠙⣷⢸⢹⡇⣸⣿⣧⣿⣿⡿⢿⣾⡾⢍⠓⣦⠈⡉⣛⠿⣿⣿⣿⣷⡘⡷⠇⣹       #                                            #        #
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡇⢸⠃⠀⠀⠀⠀⠀ ⢸⣼⣿⣿⢿⣧⣤⣵⣰⣠⣴⠶⢾⣿⠸⣶⢿⣿⣷⣅⣾⣿⣷⣄⡛⠛⣿⣿⣬⣓⡆⣈⠛⣼⣟⣻⠶⠾⣿⣷⣿      #                                            #         #
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡖⠒⠒⠂⣠⢴⣶⣿⣻⣿⠈⣿⣿⣷⣽⣿⣿⣿⣿⢿⢠⣿⣿⣿⣿⣿⣝⡻⠿⢿⣿⣾⣿⣿⢻⣛⠧⡾⣿⣿⢷⣾⡉⢹⣿⡏⠙     ##############################################           #
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠁⠀⢠⣾⠿⣭⣿⣿⣿⣿⣦⡉⠛⠉⠛⠻⠿⠟⠛⣡⣼⣿⢻⣷⡮⢷⣻⠿⣎⢳⡺⣽⠁⣘⢮⣯⣿⣿⣽⣿⣿⣿⣷⠞⡁⠀⠀     #                                            #           #
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠤⠤⠤⢤⣏⣰⣷⣿⣿⣿⣿⣿⣿⣿⣄⡀⣀⣀⣀⣤⣾⣿⣿⣿⣧⣿⣧⣛⠛⣷⣈⠳⣄⣤⣸⣿⣷⣯⣳⣭⣘⣷⢟⣢⠵⠚⠁⠀⠀     #                                            #           #
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣉⣉⣭⠭⣽⣾⣿⣿⣿⡿⡟⢡⣽⣿⣿⣟⣿⣿⡿⣿⣿⣿⣿⣿⣿⡯⢉⣚⣿⣿⣾⣺⣷⣾⡟⠿⠿⢹⡴⠟⣻⡯⠖⠋⠁⠀⠀⠀⠀⠀     #      1) Introducción                       #           #
⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡤⠖⣋⡩⠶⣶⡞⣡⣾⣿⣿⢏⣾⣷⣿⣿⣿⣿⣿⣿⣏⣸⣿⠿⢿⣏⡻⣾⣿⣿⣿⣿⡿⠏⠙⠉⣻⣵⣶⡿⠿⠞⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀     #                                            #           #
⠀⠀⠀⠀⠀⠀⠀⣠⡴⠋⢒⡴⢯⣤⡿⢋⡼⣻⣿⡿⣻⣿⣿⣿⡿⡿⣥⣿⣿⠟⣹⣿⣗⣀⣰⣿⢿⡟⣿⡉⠉⠀⠀⠀⠀⠀⢹⣄⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀      #      2) Lista de cambios                   #           #
⠀⠀⠀⠀⠀⣰⠞⣱⣴⠿⣫⠇⣤⠟⣠⣿⣡⠟⢠⣾⣽⣯⣾⠁⡀⣠⣿⣿⡽⣑⣻⡾⢿⣛⣿⠭⠙⠚⠛⢳⡄⠀⠀⠀⣀⣀⠀⢻⣷⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀      #                                            #         #
⠀⠀⠀⠀⣾⡟⣱⣿⣥⣾⣅⣰⢏⣼⡟⠷⠏⠠⢿⣽⣯⠬⠵⠿⠾⠓⠋⠈⠉⠁⠉⠳⢯⣀⢀⠀⠀⠀⠀⠀⢻⡀⠀⣾⡟⣋⣙⡆⢿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀       #⠀     3) Parches y sus características      #       #
⠀⠀⢀⣾⣽⢠⣿⣡⣿⣦⣾⢃⡾⠁⠉⢛⣻⣿⣿⠟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⢿⠇⠀⠀⠀⠀⠈⢷⡈⠿⢿⡿⠿⣃⣬⡾⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀       #                                            #      #
⠀⠀⡾⣸⢧⣏⣿⣿⢟⡿⣱⠏⠀⠁⣰⡿⠻⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠀⠀⠀⠀⠀⠀⠈⠷⠤⠶⠞⠛⠉⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀        #      4) Agradecimientos                    #    #
⠀⣸⣱⣿⢻⢿⡟⣴⡟⣱⠃⠀⠀⢠⡿⠓⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀         #                                            #   #
⠀⡿⣿⡏⣼⣿⣸⢟⣴⡇⢤⣤⣖⣿⣤⠤⢄⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀         #                                            # #
⢸⣯⣿⣷⣿⣿⣻⢿⣿⣵⣯⡍⠁⢤⣿⣷⣿⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀         ##############################################
⠈⢿⣏⣿⣼⣿⢿⣼⡇⠉⠁⠀⠀⠀⠈⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠈⣯⡎⢿⣿⣻⣿⠆



______________________________________________________________________________________________________________________________________________


1) Introducción


	Antes que nada, gracias por descargar este Hack, que nació como una broma entre amigos y se ha convertido en la primera colaboración
        entre Protopixel (sprites) y Crying Onion (programación y gráficos adicionales).

	"Popeye" es un videojuego de Nintendo basado en el personaje homónimo, que tras gozar de gran éxito en los salones recreativos en 1982,
	fue portado sólo un año más tarde a la queridísima Famicom.

	Al tratarse de un juego desarrollado y publicado en los primeros meses de vida de la consola, sobra decir que nos encontramos ante un
	juego extremadamente sencillo, aunque no hay que subestimar la diversión que podemos encontrar en sus 24 kylobites de memoria, ni al
	grupo de locos a los que les pareció buena idea crear este crossover.


2) Lista de cambios


	Resident Evil 3: Chibi Edition ver. 1.0

		● Pantalla de título totalmente remodelada inspirada en la conocida franquicia de Capcom

		● Se han hecho dos versiones del hack, con el título de la franquicia localizado al mercado occidental y japonés
		
		● Nueva fuente de texto (Calderon Majuscule Roman, creada por James Calderon y disponible en RHDN)

		● Nuevos sprites de Jill Valentine, Leon S. Kennedy, Carlos Oliveira y por supuesto, el letal Nemesis

		● Los escenarios han sido redibujados para que se sientan más acordes con el universo RE/BH

		● Se han añadido multitud de referencias y algún huevo de Pascua para disfrute de los fans de la saga


3) Parches y sus características


	● RE3 CHIBI.ips ---------> Versión con la pantalla de título localizada a la versión occidental

	● BH3 CHIBI.ips ---------> Versión con la pantalla de título localizada a la versión japonesa


4) Agradecimientos

	● A Super Buni, quién aportó la idea original para este proyecto

	● A Protopixel, por aportar su arte sobre el pixelart

	● Y por supuesto, a todos los que me apoyan desde mi canal de Youtube, Twitter y los foros de la comunidad Romhacking