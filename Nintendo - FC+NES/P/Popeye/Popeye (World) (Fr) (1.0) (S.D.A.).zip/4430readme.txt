POPEYE (FR)

En Ips format, voici une patch fran�aise du "Popeye" pour la NES.
Utilisez sur la "World" ROM.

-S.D.A.