Popeye (NES)
Traducci�n al Espa�ol v1.0 (05/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Popeye (W) (PRG1) [!].nes
MD5: 984bf61f1c679928d4a116f0d0334e44
SHA1: 53ca7541404e51c248d10fab198154f9970479b9
CRC32: fb1a91d0
24.592 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --