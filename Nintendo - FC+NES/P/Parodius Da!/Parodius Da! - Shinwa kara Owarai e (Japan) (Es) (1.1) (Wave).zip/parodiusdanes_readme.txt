Parodius da! (NES)
Traducci�n al Espa�ol v1.1 (17/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking est� basado en la traducci�n de Stardust Crusaders.
V1.1: Arreglada seleccion AUTO-MANUAL.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Parodius da! (J) [!].nes
MD5: 295d8781c9981651cc6fafd3f4b9a3ce
SHA1: ec945a05f32a81d3070ac18f11834f514d60f1be
CRC32: ec8aeffc
262.160 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

Contributor	Type of contribution	Listed credit
Pennywise	Hacking	
Tom	Translation	
sin_batsu	Graphics	Title Screen Design

-- FIN --