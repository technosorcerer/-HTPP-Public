Peter Pan & The Pirates (NES)
Traducción al Español v1.0 (24/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Peter Pan & The Pirates (U) [!].nes
MD5: 2886eca334e1621399ea63c787ba3e64
SHA1: faf1e63eaf03dba975d9f40cccbe446a71386ab2
CRC32: d21e83bb
196624 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --