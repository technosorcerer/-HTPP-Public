"Patlabor Mobile Police"
Traducción al Español Ver. 1.0 (02/02/2024)
por Max1323 (Traducciones Max1323).
Basada en la gran traducción de Vice Translations.
---------------------------------------------------
Descripción:
Basado en el manga y anime del mismo nombre.
El juego es un plataformero de acción en el cual controlaremos
a Noa Izumi y a Isao Ota. Consta de 5 actos en los cuales debemos
rescatar a los civiles. Una vez que se rescataron a los civiles,
se podrá acceder al jefe de dicho acto.

Desarrollado: Advance Communication Company
Publicado:    Bandai
Lanzamiento:  24/01/1989 (JAP)
---------------------------------------------------
Acerca del proyecto:
-La mayoría de los textos están traducidos. Se usó algunos
gráficos para comprimir los textos, por ejemplo Energía.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS (PC)
Utilizar UniPatcher (Android)
Utilizar Rom Patcher JS (Parcheador Online):
https://www.romhacking.net/patch/

Archivo IPS
Patlabor The Mobile Police - Dai 2 Shoutai Shutsudou Seyo! (Japan) [b].fds (Sin Header)
File Size     128 KB
File MD5      0EE9AE58E760378FB98A01EE3AC46280        
File SHA-1    900278726D30688E3A7AD6F3281BD290FDB4C5F7
File CRC32    4611D200