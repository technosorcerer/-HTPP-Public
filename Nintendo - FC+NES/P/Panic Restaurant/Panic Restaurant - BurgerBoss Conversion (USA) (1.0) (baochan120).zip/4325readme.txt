Panic Restaurant (NES)
BurgerBoss Conversion
Ver 1.0, 9 Feb 2018

By baochan120 at shootthecastle.com

Changes the title screen to look like the legendary arcade game, BurgerBoss. 
The villain's name was changed to Pesto for good measure as well. All gameplay, 
enemies, and items remain unchanged. 


Source ROM Name:     Panic Restaurant (U) [!].nes
Source ROM CRC32:    69c9e654
Source ROM MD5:      0e1a559f0e7f31e961413c7466cf6113
Source ROM SHA-1:    e6ad766b7f42113325deb96917ccd81da92eefa7
Source Rom SHA-256:  3f09a26b3b3eb1beefc14ed90f87916cb40a3ffd63a0d0cc2eedda8a3bd7bda0

Patched ROM CRC32:   2e8f1d71
Patched ROM MD5:     e4d4d0c78d9bf3999e39e289d500fec0
Patched ROM SHA-1:   bd2e33c5b62ab6c3b7ecdee28b422f8345ef8474
Patched ROM SHA-256: c7e280cce2ef8a6e703db7ac8fce23cd9762a8280752eabdcf11ea29a867b092
