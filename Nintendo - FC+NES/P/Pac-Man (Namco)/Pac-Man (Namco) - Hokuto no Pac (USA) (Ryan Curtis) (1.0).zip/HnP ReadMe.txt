Hokuto no Pac
By Ryan Curtis
Ver. 1.0
[SLIGHT FLASHING LIGHTS WARNING]
-----------------------------------
DISCLAIMER: This ROM hack is not affiliated with Toei, Namco, or Lunar IPS. No money is being made from this.
-----------------------------------
For use with NES Pac-Man ROMs only.
-----------------------------------
How to Set Up

1. Locate and download a PAC-MAN (NES) ROM.
2. Unzip the patch file and move to desired location.
3. Use a patcher like Lunar IPS to install the patch.
4. Enjoy!

-----------------------------------
What this hack changes

Nothing much except for a few cosemtic changes like the logo and PAC-MAN now having Kenshiro's hair.