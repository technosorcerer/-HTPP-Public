CLYDE (for the NES)
2024 Sk8rCow

Yes, CLYDE is back! And he's as lovable and hungry as ever before. If you remember the incredible excitement he generated, you're ready to relive the phenomenon. And if you missed him the first time around, you're in for the most fun you've ever had!

CLYDE is ready at your command to blaze around the baffling maze, gobbling up dots, swallowing the occasional clydes and racking up points in a big way. Clyde, Clyde, Clyde and Blinky, the not-so-friendly ghosts, are dying to do some gobbling, too. Except their favorite food is CLYDE! His only defense is to eat the energizers, special pellets which enable CLYDE to gobble the ghosts - but only for a short while! With each level, the energizers effectiveness decreases. As you clear each maze, the ghosts move faster. Remember, it's a jungle out there. So gobble - or get gobbled!

In all seriousness. this is a dumb little joke hack I made based on MrMcScrewUp's hack of the arcade version of Pac-Man.

I don't need to tell you how to play, if you're downloading this you already know how to play Pac-Man.

Patch the rom to an NES rom of Pac-Man, preferably Pac-Man (Japan), which this rom was built upon. Other roms (Tengen, Hometek, etc) may work but haven't been tested.

FUN FAX!
I don't know how to change the color when the maze blinks after finishing a round, so it turns blue. It does that in most hacks of this game though.
This is my second published rom hack.

CREDITS:
Me - Hacking, Making the label, that's it because it honestly doesn't take much to hack the NES version of Pac-Man.
MrMcScrewup - Original hack.
CosmicToons - Original Clyde logo which I recreated in higher quality for this hack.
Brianfan - Logo font (ingame).
RingoStarr39 - Logo font (on pretty much everything else)
Pac-Man (and Clyde) are owned by Bandai Namco Entertainment

Expect Clyde 2: Sue and maybe an FDS port.

Rest in power romhacking.net