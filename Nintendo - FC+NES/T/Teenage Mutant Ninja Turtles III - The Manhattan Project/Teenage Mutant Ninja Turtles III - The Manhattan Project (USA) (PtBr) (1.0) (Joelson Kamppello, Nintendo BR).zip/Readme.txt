-----------------------------------------------------------
---------------NINTENDO  BR  TRADU��ES  2011---------------
-----------------------------------------------------------
             www.nbr-traducoes.blogspot.com.br
                nintendo-brasil@hotmail.com
-----------------------------------------------------------
---Teenage Mutant Ninja Turtles 3: the Manhhatan Project---
-----------------------------------------------------------
		         Vers�o: 1.0
                     In�cio:  11/12/2010
		     T�rmino: 02/01/2010
		       Progresso: 096%
		       - Textos:  100%
		     - Acentua��o:  100%
		      - Gr�ficos:  090%
                       - Revis�o: 100%
-----------------------------------------------------------
-----------------Sobre a tradu��o  (v 1.0)-----------------
-----------------------------------------------------------
	Aspectos  relevantes, alguns  ponteiros  n�o  foram 
editados, pois  n�o  consegui  localiz�-los. O  trecho "the 
Manhhatan  Project" ficou  sem  tradu��o, pois n�o consegui 
localizar os tilemaps, ent�o  decidi  deix�-lo  em  ingl�s,
quando tiver mais conhecimento, tento edit�-lo novamente.
	Esse  jogo  tem  um  detalhe "estranho", sempre que 
editava o menu principal, no final da fase 6, o  Destruidor 
ficava imortal. Algu�m do PoBRE me informou o local exato e
o porque disso ocorrer, n�o sei quem foi,  mas  agrade�o  a 
essa pessoa.
-----------------------------------------------------------
------------------------OBSERVA��ES------------------------ 	
-----------------------------------------------------------
	Essa  tradu��o  deve  ser   aplicada  sobre  a  ROM 
"Teenage Mutant Ninja Turtles 3 (U)", n�o  aplique-a  sobre 
outras vers�es da ROM, pois, caso funcione,  poder� ocorrer 
algum problema futuramente.
-----------------------------------------------------------
-------------------CONSIDERA��ES FINAIS--------------------
-----------------------------------------------------------
-----Caso encontre algum erro ou tenha alguma sugest�o-----
----envie-me um email,  caso queira fazer um coment�rio----
------------sobre a tradu��o, acesse nosso blog------------
-----------------------------------------------------------
	 blog:  www.nbr-traducoes.blogspot.com.br
      email para contato: nintendo-brasil@hotmail.com
		    Tradutor: KAMPPELLO
-----------------------------------------------------------
----------------NINTENDO BR TRADU��ES  2011----------------
-----------------------------------------------------------