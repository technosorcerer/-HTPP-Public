-----------------------------------------------------------
---------------NINTENDO  BR  TRADU��ES  2011---------------
-----------------------------------------------------------
             www.nbr-traducoes.blogspot.com.br
                nintendo-brasil@hotmail.com
-----------------------------------------------------------
--------As Tartarugas Ninjas 3: o Projeto Manhattan--------
-----------------------------------------------------------
-------------------------Vers�o: 1.3-----------------------
-----------------------------------------------------------
                     In�cio:  14/07/2011
		     T�rmino: 14/07/2011
		       Progresso: 100%
		       - Textos:  100%
		     - Acentua��o:  100%
		      - Gr�ficos:  100%
                       - Revis�o: 100%
-----------------------------------------------------------
-------------------------Vers�o: 1.2-----------------------
-----------------------------------------------------------
                     In�cio:  14/07/2011
		     T�rmino: 14/07/2011
		       Progresso: 100%
		       - Textos:  100%
		     - Acentua��o:  100%
		      - Gr�ficos:  100%
                       - Revis�o: 100%
-----------------------------------------------------------
-------------------------Vers�o: 1.1-----------------------
-----------------------------------------------------------
                     In�cio:  03/01/2011
		     T�rmino: 03/01/2011
		       Progresso: 100%
		       - Textos:  100%
		     - Acentua��o:  100%
		      - Gr�ficos:  100%
                       - Revis�o: 100%
-----------------------------------------------------------
-------------------------Vers�o: 1.0-----------------------
-----------------------------------------------------------
                     In�cio:  11/12/2010
		     T�rmino: 02/01/2010
		       Progresso: 096%
		       - Textos:  100%
		     - Acentua��o:  100%
		      - Gr�ficos:  090%
                       - Revis�o: 100%
-----------------------------------------------------------
-----------------Sobre a tradu��o  (v 1.3)-----------------
-----------------------------------------------------------
	Mais uma vez agrade�o ao Devilfox por ter reportado
o �ltimo erro ortogr�fico do jogo.
-----------------------------------------------------------
-----------------Sobre a tradu��o  (v 1.2)-----------------
-----------------------------------------------------------
	Foram corrigidos  os erros reportados por Devilfox.
Obrigrado por t�-los reportado.
-----------------------------------------------------------
-----------------Sobre a tradu��o  (v 1.1)-----------------
-----------------------------------------------------------
	Editada finalmente a tela de titulo,  alcan�ando  o
progresso 100%.
-----------------------------------------------------------
-----------------Sobre a tradu��o  (v 1.0)-----------------
-----------------------------------------------------------
	Aspectos  relevantes, alguns  ponteiros  n�o  foram 
editados, pois  n�o  consegui  localiz�-los. O  trecho "the 
Manhhatan  Project" ficou  sem  tradu��o, pois n�o consegui 
localizar os tilemaps, ent�o  decidi  deix�-lo  em  ingl�s,
quando tiver mais conhecimento, tento edit�-lo novamente.
	Esse  jogo  tem  um  detalhe "estranho", sempre que 
editava o menu principal, no final da fase 6, o  Destruidor 
ficava imortal. Algu�m do PoBRE me informou o local exato e
o porque disso ocorrer, n�o sei quem foi,  mas  agrade�o  a 
essa pessoa.
-----------------------------------------------------------
------------------------OBSERVA��ES------------------------ 	
-----------------------------------------------------------
	Essa  tradu��o  deve  ser   aplicada  sobre  a  ROM 
Teenage Mutant Ninja Turtles  III  -  The Manhattan Project 
(U) [!], com CRC 32: DBB3BC30, n�o  aplique-a  sobre outras
vers�es da ROM, pois poder� danificar as mesmas.
-----------------------------------------------------------
-------------------CONSIDERA��ES FINAIS--------------------
-----------------------------------------------------------
-----Caso encontre algum erro ou tenha alguma sugest�o-----
----envie-me um email,  caso queira fazer um coment�rio----
------------sobre a tradu��o, acesse nosso blog------------
-----------------------------------------------------------
	 blog:  www.nbr-traducoes.blogspot.com.br
      email para contato: nintendo-brasil@hotmail.com
		    Tradutor: KAMPPELLO
-----------------------------------------------------------
----------------NINTENDO BR TRADU��ES  2011----------------
-----------------------------------------------------------