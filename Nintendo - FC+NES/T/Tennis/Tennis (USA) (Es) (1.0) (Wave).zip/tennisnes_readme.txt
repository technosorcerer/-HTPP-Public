Tennis (NES)
Traducci�n al Espa�ol v1.0 (06/03/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tennis (JU) [!].nes
MD5: 32fb31ae20f0d01bc74baad9f3a9672b
SHA1: 80d99c035e6a5ab9718e413ec25cbe094f085962
CRC32: 5f457c00
24.592 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --