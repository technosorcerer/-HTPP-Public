-----------------------------------
Tennis (JU) [!].nes
-----------------------------------
File MD5      32FB31AE20F0D01BC74BAAD9F3A9672B
File SHA-1    80D99C035E6A5AB9718E413EC25CBE094F085962
File CRC32    5F457C00

ROM MD5       32A5E44B320AE588F560196E49BA13C6
ROM SHA-1     DC851C8DD5F7D6B402D1402C4239400A88382A1F
ROM CRC32     D4D9E21A

----------------------------------
Registro de cambios
----------------------------------
1.1
Se crearon fuentes personalizadas.
Se editaron punteros.
Se optimizaron los gr�ficos.

----------------------------------
Contacto |Errores |Bugs |Recursos!
----------------------------------
deviantart.com/terwilf
spriters-resource.com/submitter/Terwilf
twitter.com/ssicosomatic
youtube.com/user/ssicosomatico
