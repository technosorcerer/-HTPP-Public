Dynasty WLAF/USFL Tecmo Super Bowl
Version 1.0
By Denny & Jstout

This is a Dynasty WLAF and USFL Tecmo Super Bowl edit for NES. A lot of stuff was changed to transform TSB into WLAF/USFL. We kept the schedule the same and the divisions are almost accurate as far as their original division assortments go. Keep in mind this is a Dyanasty edit so you may see an occasional player that's on more than one team. We tried to select teams to help prevent this so we can provide a more enjoyable experience.

If you are unfamiliar with the USFL (United States Football League) and the WLAF (World League of American Football), checkout these two sites for more information....

USFL - http://www.thisistheusfl.com/
WLAF - http://www.geocities.com/Colosseum/1871

We have combined pretty much each team from these leagues (except the Arizona Outlaws, Orlando Renegades and the Raligh-Durham Skyhawks) and we decided to call the league the "Spring Football League" or "SFL" for short. Both these leagues were springtime leagues and we felt this was a good idea due to the "NFL" all over in the rom, we had to replace it with something. The AFC and NFC as well as Division names remain in tact though.

NOTE: Feel free to update the attributes on your copy any way you like.

VERSION 1.0
----------------------------------------------
- Updated Various Menu Tecmo background colors.
- Updated Player Status Backgrounds.
- Changed Jerseys to USFL/WLAF Jerseys.
- Updated all mini-helmets.
- Division Champ & Conference Champ screens updated.
- Team Rosters/Team Names & Player Photos Updated to Dynasty USFL/WLAF teams (see list below).
- Various Text Changes.
- Formations now set at (2 RB, 2 WR, 1 TE) for all teams except Denver, Houston, and NY/NJ which have Run & Shoot offenses that they ran under Mouse Davis. 
- Simulation Stats Updated.
- Player Attributes Updated to reflect their stats/physical conditions from their team's season.
- Default Playbooks Changed.
- Large Helmets updated to USFL/WLAF helmets.
- Pro Bowl Rosters updated (The AFC is the WLAF All-Stars and the NFC is the USFL All-Stars)
- Endzones Updated (One on the Left is Dark Blue and says "WLAF" and the one on the Right is Dark Red and says "USFL")
- Kick and Punt Returners Updated.
- NFL Text is replaced by SFL (Spring Football League)
- Super Bowl is now called the "World Bowl"
- NFL and Tecmo field logos replaced with USFL and WLAF logos.
- Opening intro screens updated.
- NFL logo used on main menu screen replaced with a USFL/WLAF combo logo.

NOTE: There may be a changes I forgot to put in the list 


Team List 
--------------------------- 
This is the complete list of the teams in the Dynasty WLAF/USLF Edit. We tried selecting each teams best year, some years were chosen to prevent a massive amount of duplicate players. In game all teams have their full team name. No years are dignified in their tecmo name so the 85 Generals are setup as just the New Jersey Generals in game. This was to prevent new people to these leagues from getting confused and it looks better this way.

10 WLAF (1991-92) Teams 
18 USFL (1983-85) Teams 

AFC EAST - WLAF 
------------------
1992 Birmingham Fire
1992 Orlando Thunder
1992 Ohio Glory
1992 Sacramento Surge
1992 San Antonio Riders

NFC EAST - WLAF 
------------------
1991 Barcelona Dragons
1991 London Monarchs
1991 Frankfurt Galaxy
1991 Montreal Machine
1992 New York/New Jersey Knights (It's "NY NJ Knights" in game)

AFC CENTRAL - USFL 
------------------
1985 Oakland Invaders
1984 Los Angeles Express
1985 Denver Gold
1983 Arizona Wranglers

AFC WEST - USFL
------------------
1983 Michigan Panthers
1983 Chicago Blitz
1984 Houston Gamblers
1984 San Antonio Gunslingers (Had To Be Shortened to Slingers in game, Name Was Too Long)
1984 Oklahoma Outlaws

NFC CENTRAL - USFL
------------------
1984 Tampa Bay Bandits
1984 Birmingham Stallions
1985 Jacksonville Bulls
1985 Memphis Showboats
1983 Boston Breakers

NFC WEST - USFL
------------------
1984 Pittsburgh Maulers
1984 Philadelphia Stars
1985 New Jersey Generals
1983 Washington Federals

Enjoy The Edit Guys! :)
Denny