
-------------------------------------------------------------------------------------
-BlackPaladin's Transformers: The Mystery of Optimus Prime English Translation Patch-
-------------------------------------------------------------------------------------

******************************
*Transformers: Convoy no Nazo*
******************************

This patch was made out of boredom for a game that has, by many players, to be the epitome of "kusoge".  It's for the run n' gun Transformers game made for the Famicom and has never been release outside of Japan.  (And rightfully so!)

Note:  "Convoy" was the Japanese name for "Optimus Prime".  Thus, the title screen reflects this change.

The patch comes in two flavors...

Transformers - The Mystery of Optimus Prime (English).ips
--English Translation patch (IPS Format)
Transformers - The Mystery of Optimus Prime (English).bps
--English Translation patch (BPS Format)

The patch requires the ROM with the following hashes...

File SHA-1: 2C7C3E50725C8F9689FF29685E9244FE9B4F8C14
File CRC32: 8B75BA7E
ROM SHA-1: 57F9DB2F47FCE34C5EA255BA3A9105279D41215F
ROM CRC32: EA89963F

Use either the IPS or the BPS patch to get the ROM with the following hashes.  (Don't use both.)

File SHA-1: 7A169EBA6204FB55F13330BF13192583DA9D156C
File CRC32: 156D8B2D
ROM SHA-1: 2CAEEE8E421CD9E1F54EEA04996F7BBD2AD18903
ROM CRC32: 7491A76C

What's done

Translated title screen
All endings translated

v1.0

Initial Release

Special Thanks

FCE Ultra Team (Emulator was used to test the translation patch)
Mesen Team (Emulator was used to test the translation patch)
YY-Char Team (This program was used to edit the graphics in the game)
Takara (This company created this game in the first place)
Hasbro (The company for bringing Transformers to English audiences)

All credits to "Transformers: The Mystery of Optimus Prime" belong to their respective creators and programmers.  This patch is mainly for pure entertainment for those who cannot enjoy the game.  All right reserved.  (Takara and Hasbro, please don't come after me!)