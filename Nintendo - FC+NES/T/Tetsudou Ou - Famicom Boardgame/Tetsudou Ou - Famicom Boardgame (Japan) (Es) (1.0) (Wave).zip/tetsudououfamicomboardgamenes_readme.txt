Tetsudou Ou - Famicom Boardgame (NES)
Traducci�n al Espa�ol v1.0 (12/02/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking est� basada en la de Jink640, MrRichard999 y Proveaux.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tetsudou Ou - Famicom Boardgame (J) [!].nes
MD5: fff69b962158a8b4084700572365595f
SHA1: 45d30cad96b471910f656c4df8df05cd2397b891
CRC32: 774f460d
65.552 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

MrRichard999	Hacking	Recoding of ROM.
Proveaux	Graphics	Title Screen Graphics.
LastBossKiller	Translation	Usage of translated phrases from FAQ on GameFAQS site.
Jink640	Translation	Spot Translation.
Rg-Soft	Original Hacking	Usage of their layout from their hacked ROM.

-- FIN --