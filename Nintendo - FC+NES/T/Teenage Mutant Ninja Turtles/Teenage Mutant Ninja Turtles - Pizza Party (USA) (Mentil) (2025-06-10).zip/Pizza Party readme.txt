TMNT - Pizza Party v1.0

Instructions: Apply to a standard headered ROM, likely titled 'Teenage Mutant Ninja Turtles (U) [!].nes'. Also compatible with the 'Return to New York' hack, tested with v1.81. Other regions are untested.


Changes:
- Picking up pizza now gives its health restoration to all non-captured Turtles. It isn't divided among them, so you gain more benefit the more injured Turtles you have; this encourages you to switch and spread the damage around.

- All knockback from enemies is eliminated; no more getting knocked off of ledges/ladders.

- Hitting your head on the ceiling when jumping no longer halts horizontal movement. As a side effect, this also makes it easier to get up ledges. (Note: ledge physics are slightly glitchy, and you can now make it through/into some small crevices; a few minor map changes were thus made to prevent getting softlocked from getting stuck in crevices. In order to prevent getting stuck in walls, this change is only in effect when holding Left or Right, and not holding Attack.)

- Level 2's timer was extended slightly (from 2:20 to 2:35)

- The corridor prior to the final boss had half of its (tough) enemies removed, making it far more reasonable to get through.



This hack may be modified or used as a base for other hacks, with attribution. Hack made by Mentil.