Teenage Mutant Ninja Turtles (.nes)
4/10/2024
V1.0
Mirage Edition - Hack
By: Micjohvan

Changelog:

Graphics Changes:

1) Turtles all now wear RED masks as shown on the cover of the game and box.  The cover artwork is the cover of
the 4th original issue of TMNT by Mirage and at that time all the turtles had red masks.  Many of the enemies in the game are based off the original comics as the cartoon had JUST started when this game was made in the late 80s.  Thats why many of the enemies seem out of place such as giant frogs, robots, and chainsaw dudes.  

2) Turtle Sprites for the overhead sections and platforming sections all are red masks.

3) Turtle sprites during intro cutscence that plays at the title screen have all been edited to wear red, the
graphics for Leo are edited in Tile Layer Pro as they used the green background color for his mask, there was no way to edit that color of the mask without swapping the katana blue to the mask and changing it to red.

4) Turtle Sprites in the pause menu now show the red masks for the turtle icons. Colored backgrounds for each turtle feature their signature color.

5) Title Screen Edit

6) Turtle Swimming sprites all now wear red masks

7) Turtle blimp boarding sprites all now wear red masks

