The Terminator - EasyType Hack by magusRE
----------------------------------------
A small EasyType Hack for this game to make it a bit more enjoyable by increasing the Vertical Jump 
for the platforming sections and few value changes to the Player and Enemies for smoother gameplay.

+ Increased Vertical Jump
+ Added Off-Screen death protection at the top of the Screen.
+ 50k Score also restores the Players HP.

--------------------
Changed Values:
--------------------
Start Lives: 5 -> 3
Max Lives: 6 -> 9
Hearts: 20 -> 40
Grenades: 8 -> 20

--------------------
Changed Damage:
--------------------
Acid/Water: 16 -> 8
Arnold/Turret: 16 -> 12
T-Skeleton: 36 -> 18
Spikes: 7 -> 4
Dog Jump: 24 -> 12
Green Car: 11 -> 8

--------------------
Changed Enemy HP:
--------------------
Punks: 79 -> 31
Arnold/Police: 127 -> 47
Airship/Robot: 127 -> 96

Note: Some enemies are reskinned version of previous enemies and share the same HP/Damage value.

--------------------
Required ROM:
--------------------
File SHA1	AA97B923DE879B42DD70D00335C8196CFF38D6A8
ROM SHA1	B57C4E9CE3212F4E75B71A733FF2907970521D40
File MD5	0B644A48B28649C8CA5988FE9190CC7E
ROM MD5		81BDEC267B0A1793E2AF6B4D9F236148
File CRC32	8B666C72
ROM CRC32	6272C549

--------------------
Thanks and Credits:
--------------------
www.romhacking.net