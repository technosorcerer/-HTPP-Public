hola a todos, esta es una traduccion de todo lo que tiene en ingles y japones al español este videojuego,
cabe resaltar que tiene diferencias con la version americana, por esto me dedique a hacer este trabajo.

Cambios:
Traduccion de pantalla de titulo (Palabras, el nombre del personaje arriba del logo, logo y mi credito)
Pantalla de Game over (Juego acabado)
Menu de Seleccion de item (Palabras en ingles y nombres de isla que estaban en japones)
Dialogo de Madre ptera (el pajaro rojo)
Dialogo de Great nosy (el pajaro azul)
Pantalla de seleccion de mundos
Dialogo al rescatar a tina
Creditos finales

Dedicado a los curiosos que quieren saber las diferencias aclaradas que tiene con su version occidental,
espero que lo disfruten,  saludos.

Rockymitsu 2024