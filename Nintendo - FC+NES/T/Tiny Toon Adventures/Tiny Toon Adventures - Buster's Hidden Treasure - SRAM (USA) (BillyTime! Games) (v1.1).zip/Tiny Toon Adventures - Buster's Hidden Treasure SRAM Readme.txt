Tiny Toon Adventures - Buster's Hidden Treasure SRAM
Aug. 25th 2021
BillyTime! Games
--------------------
This patch is designed to add a simple saving mechanism to Tiny Toon Adventures - Buster's Hidden Treasure.


How to use:
--------------------
Saving:
Game saves at the start of every level.

Loading:
Enter options screen, press up. Exit and start your game.

NOTE:
Game will produce a black screen if no prior save is detected.
Boss levels can now be replayed (9/8/2025)

Bug Fix 9/8/2025:
Levels completed now load properly

How to Patch:
--------------------
1.Grab a copy of Tiny Toon Adventures - Buster's Hidden Treasure(USA).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file