---------------------------------------------------------------
Square's Tom Sawyer - Jim Design Fix

Cosmetic ROM hack made by Yoni Arousement
---------------------------------------------------------------
Here's a ROM hack where Jim's appearance is changed to resemble
his appearance in the anime.

You can patch it on a Square no Tom Sawyer (Japan) ROM.
---------------------------------------------------------------
Credits

Pixeltomia drew Jim's new portraits.

Bavi_H found the locations of where the overworld tiles assign
their palettes. I give huge thanks!
---------------------------------------------------------------