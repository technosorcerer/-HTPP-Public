+-------------------------------------------------+
| Tetris (Famicom): Conventional-Controls Edition |
+-------------------------------------------------+

  | Overview
  +--------------------------------------
    The first Tetris game that was ever released on a Nintendo system is still overlooked due to its unusual control scheme.  This romhack updates the game to have the standard controls that players have come to expect from a classic Tetris game.


  | Features
  +--------------------------------------
    - Hard drop (A button)—remapped to Up on the D-pad.
    - Rotate counterclockwise (Down on D-pad)—remapped to B button.
    - Soft drop—newly added; mapped to Down on D-pad.
    - Rotate clockwise—newly added; mapped to A button.
    - Bonus: exploit patched—holding down any button after a hard drop no longer stalls the game indefinitely.

    For a demonstration of these features, see the video section below.


  | Known Issues
  +--------------------------------------
    The ending graphics were partially repurposed to store code for the hack, due to the limited size of the game ROM.  As a result, the ending graphics are slightly garbled.  Although this was not ideal, it is the price of admission of this hack.


  | Video
  +--------------------------------------
    https://www.youtube.com/watch?v=zX7uoStDZUM


  | Tools Used
  +--------------------------------------
    - FCEUX
    - MesenS
    - TBLater
    - Lunar IPS


  | Platform
  +--------------------------------------
    Nintendo Famicom


  | Game Credits
  +--------------------------------------
    - Alexey Pajitnov, creator of Tetris.
    - Bullet Proof Software (BPS), developer and publisher of this game on different platforms including the Famicom.
    - Nintendo, licensor of the original game and producer of the Famicom.


  | Version History
  +--------------------------------------
    Version 1.0 created March 28 and July 2-4 and submitted on July 5, 2023.
  
  
  | Developemnt History
  +--------------------------------------
    - July 4, 2023
      - Patched stalling exploit
      - Updated game menu

    - July 2-3, 2023
      - Implemented rotate clockwise

    - March 28, 2023 
      - Remapped hard drop
      - Remapped rotate counterclockwise
      - Implemented soft drop


  | License
  +--------------------------------------
    MIT License


  | Creator
  +--------------------------------------
    clymax
    https://twitter.com/clymax