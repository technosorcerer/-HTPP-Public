Titan Warriors (NES)
Traducción al Español v1.0 (24/12/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Titan Warriors (USA) (Proto).nes
MD5: d05f27ce21c3d8e31461f95ca19d62f4
SHA1: 55a39358954fc57f5e04361e583f112cbdc2a834
CRC32: b06f1c46
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --