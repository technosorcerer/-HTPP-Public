Patch di traduzione per Tetris NES - ver. 1.0 - Gennaio 2024

Per supportare le mie traduzioni: www.paypal.me/rulesless

Scaricato da: Le traduzioni di Rulesless - Contatto: ruleless@tin.it

INDICE:
1- ATTENZIONE
2- GUIDA ALLA MODIFICA
3- NOTE LEGALI

1-ATTENZIONE
I giochi patchati possono essere STREAMMATI in diretta o su YOUTUBE e le patch CONDIVISE a patto di CITARE SEMPRE LA FONTE: 
 "https://letraduzionidirulesless.wordpress.com"

2-GUIDA ALLA MODIFICA
Avvia Flips (allegato) o un servizio online per applicare la patch .bps;
La patch si applica alla versione americana del gioco.
Seleziona "PATCHA" e scegli il file di patch indicando poi la rom alla quale applicare la patch,
 estratta dalla cartuccia originale di cui sei proprietario.
Clicca infine su "SALVA" per procedere alla modifica ed ottenere la rom tradotta.

 NOTE
α)  verifica che la rom funzioni prima di patcharla.
β)  se la rom usata è della versione segnalata, non è stata modificata e soddisfa tutti i parametri segnalati,
    le patch di traduzione funzionerà correttamente e non avrai nessun problema ad applicarla. 
γ)  patchare sempre la rom base pulita, senza modifiche, neanche se si tratta di precedenti versioni della mia traduzione.
γ1) i salvataggi di gioco effettuati con una versione della patch restano funzionanti con i successivi aggiornamenti.
δ)  in caso di problemi "prova a spegnere e riaccendere"!

Come sempre buon divertimento!

3-NOTE LEGALI
a) Le presente patch vanno utilizzate esclusivamente sui giochi originali, legittimamente detenuti, per i quali sono state create.
b) È assolutamente vietato vendere o cedere a terzi a qualsiasi titolo i giochi già patchati;
   i trasgressori potranno essere puniti, ai sensi dell’art. 171bis, legge sul diritto d’autore, con la reclusione da 6 mesi a 3 anni.
c) Si declina la responsabilità derivante dall’uso scorretto di questo programma da parte di terzi.
d) Queste patch non contengono porzioni di codice dei programma dei gioco; gli elementi che le formano non sono dotati di autonomia funzionale.
e) Per la creazione di queste patch non è stato necessario violare sistemi di protezione informatica,
   né dalla sua applicazione viene messa in atto tale condotta.
f) Le patch sono un prodotto amatoriale, pertanto l’autore declina la responsabilità di possibili malfunzionamenti; 
   l’utilizzo delle stesse è da intendersi a vostro rischio e pericolo.
g) Le traduzioni sono proprietà giuridicamente riconosciuta del loro autore, l’elaborazione creativa dell’opera d’ingegno originaria,
   tutelate con una norma speciale ed autonoma che definisce i diritti del traduttore distinti da quelli che spettano all’autore dell’opera.
   L’art. 4 della legge 22 aprile 1941, n. 633 ("Protezione del diritto di autore e di altri diritti connessi al suo esercizio") infatti recita:
   "Senza pregiudizio dei diritti esistenti sull’opera originaria, sono protette le elaborazioni di carattere creativo dell’opera stessa,
   quali le traduzioni in altra lingua".
h) Le presenti traduzioni sono cedute ad uso gratuito personale, per qualsiasi eventuale diffusione, va sempre citata la fonte.
i) Si ricorda infine che i diritti sul gioco (software) appartengono ai rispettivi proprietari.

EN) This patch does not contain copyrighted material, has no functional autonomy, and you must have your own backup copy to apply it.
    You can play it on original SG-1000 and NES console.
    All game rights, intellectual property, logos/names/images are property of their respective owners.