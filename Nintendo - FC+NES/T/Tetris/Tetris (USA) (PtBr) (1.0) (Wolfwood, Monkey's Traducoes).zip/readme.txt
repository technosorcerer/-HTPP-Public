---------------------- Informa��es ----------------------

Nome do jogo: Tetris.
Plataforma: NES (Nintendo Entertainment System).
G�nero: Quebra-cabe�as.
Vers�o da Rom: Americana (U)
Vers�o: 1.0.
Lan�amento do Patch 1.0: 24 de Dezembro de 2010.
CRC32: 6D72C53A.
Status: 99%.
Respons�vel: Wolfwood.
Grupo de Tradu��o: Monkeys Tradu��es.
E-mail para contato: ikkidefenixalemao_@hotmail.com

---------------------- Como inserir os patches na ROM original ----------------------

Para saber mais informa��es sobre como inserir os patches na ROM original, baixe o seguinte tutorial:

http://www.romhackers.org/modules/PDdownloads1/singlefile.php?cid=67&lid=291
http://www.romhacking.trd.br/index.php?topic=5095.0
http://www.mandamais.com.br/download/0ovt112010173420

OBS: Para jogar a tradu��o, basta inserir UM dos patches, basta escolher o de sua prefer�ncia.

---------------------- Coment�rios ----------------------

Tetris � um jogo cl�ssico e vi a necessidade de fazer a tradu��o de uma das vers�es desse jogo, tanto que ele � o meu segundo jogo preferido (atr�s somente de Final Fantasy VI).

Enfim, tinha a tradu��o aqui no meu HD, por�m, decidi recome��-la do zero e a deixei bem melhor que a tradu��o que estava aqui, espero que gostem e que joguem tamb�m, � claro.

Tetris owna e � da Nintendo.

---------------------- Links ----------------------

Mem�rias de um Lobo de Madeira: http://memoriasdeumlobodemadeira.blogspot.com/
F�rum Unificado de ROMHacking e Tradu��o: http://www.romhacking.trd.br/index.php
Twitter do Wolfwood: https://twitter.com/Lobim666
Monkeys Tradu��es: http://www.monkeystraducoes.com/
Po.B.R.E.: http://www.romhackers.org/modules/news/
Game Stark: http://www.gamestark.org/index.php
SnesBr: http://www.snesbr.com/

---------------------- Agradecimentos ----------------------

- Minha m�e - COEH! Sem ela eu n�o estaria aqui, entregando essa tradu��o para voc�s.
- Membros da Monkeys Tradu��es.
- Heero Yui, pode sempre ter me ajudado no tempo em que esteve presente entre n�s.
- Snaw da N Party, por ter tido a paci�ncia de ouvir meus coment�rios infames.
- Aqueles que por algum motivo esqueci de citar aqui.
- E todos aqueles que jogaram e gostaram da tradu��o.