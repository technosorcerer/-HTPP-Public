Tag Team Wrestling (NES)
Traducci�n al Espa�ol v1.0 (05/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tag Team Wrestling (U) [!].nes
MD5: 07647c00bb2ab5965bf6530f6f347ce4
SHA1: a27e193fffef36f49203af4d27ca588d62a2ff07
CRC32: 41f82f6e
40.976 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --