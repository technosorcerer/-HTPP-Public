Saludos, este es un parche del juego y una pequeña descripcion acerca del articulo.
Se ha traducido todo lo que tiene de diferente a la version americana, tanto el nombre del protagonista como
detalles en ingles, todo traducido al español. pueden jugar ya sabiendo que usan a takahashi como jugador!