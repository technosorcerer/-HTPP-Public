﻿--------------------------Info---------------------------
Game name: Teenage Mutant Ninja Turtles - Tournament Fighters (U)
Hack name: Tournament Edition 2.0
Console: Nintendo entertainment system
Game region USA: (U)
Patch: SP (Solid patch)
Patcher: Solid patcher
Patcher download link:
 Windows: https://romhackplaza.org/utilities/solid-patcher-utility/
 Linux: https://romhackplaza.org/utilities/solid-patcher-utility-2/
 https://rgcorp.ucoz.net/load/console_soft/solid_patcher/2-1-0-97
----------------------------------------------------------
--------------------------patch------------------------
In this Hack, the tournament balance is automatically set and many bugs that ruin normal gameplay have 
been eliminated. 

Namely:
- Hot-Hot fight is open.
- Tournament and balance options are automatically set at the start of game: turbo speed, time is 45 and 
  balance of characters strengts is: LEO - 6, RAPH - 5, MIKE - 7, DON - 6, CASEY - 7, HOT - 4, SHREDDER - 4.
- Removed immortality for Don and Casey.
- Fixed bug with characters "sticking" to each other, when both stand each other and press "back".
- Removed most of unintentional specials (for example, I wanted to throw from run, but instead did a special).
- Fixed ball flying through the first player and does not hurt him, when the first player hits the second.
- Removed hardcoded advantage of the second player because of which second was always 1 frame faster, 
  now the advantage is transferred to the player with lower HP.
- Added a counter of the number of victories in battles during the game.

----------------------------------------------------------
Author by: Shredder.
https://www.nesx.ru/viewtopic.php?t=31
https://vk.com/topic-156126390_50369937