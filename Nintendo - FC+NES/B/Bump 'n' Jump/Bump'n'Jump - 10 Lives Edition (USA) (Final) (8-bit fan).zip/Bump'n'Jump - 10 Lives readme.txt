Bump'n'Jump - 10 Lives

-= Complete hack =-

Apply 'Bump'n'Jump - 10 Lives.ips' directly to 'Bump'n'Jump (U) [!].nes- GoodNES 3.14'


What this hack does:

Bump'n'Jump is a fast'n'fun game where you buggy your popper through 16 levels to rescue your girlfriend by bumping and jumping into enemy vehicles. The only problem: the lack of extra lives! No 1-up items, no extensions via high scores. Nothing. There is a continue code but it's complicated and annoying to pull off, plus you run the risk of messing it up and having to start over. The game has 16 stages and having just 3 lives initially actually makes this a very hard game to complete. This hack attempts to rectify that situation by giving the player 10 lives at the start!


List of features, additions and changes:

1) 10 lives at start of the game! ;)


Tools and resources used:
FCEUX, nestopia, everdrive, and romhacking.net.


Acknowledgements and Credits:
Data East and Sakata SAS for this very fun NES game.
Vic Tokai for releasing the game in the US.
Nintendo for licensing the game in the US.

2018.4.25 v.final by 8-bit fan / 8.bit.fan / butz