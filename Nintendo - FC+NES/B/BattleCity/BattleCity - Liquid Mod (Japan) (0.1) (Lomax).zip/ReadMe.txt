--------------------------Info---------------------------
Game name: Battle City
Console: Nintendo entertainment system
Game region JAP: (J)
Patcher: Cheat Patcher v0.9 or higher.
----------------------------------------------------------
--------------------------patch------------------------
The patch allows to set following parametres:
 
 Players lives
 Tank upgrade  
 Friendly fire
 Amount of enemy tanks
 6 enemy tanks in battle
 Fast enemy respawn
 High frequency of enemy fire
 Base disabled

--------------------Cheat Patcher------------------
Download link:
http://www.romhacking.net/utilities/1112/
----------------------------------------------------------
Authors by: Lomax, Guyver XBM, Mr2.
e-mail: fsocp@land.ru
http://rgcorp.ucoz.net/