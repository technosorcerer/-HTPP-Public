----------------------------------------------------------------------------
BinaryCity patch v0.999
----------------------------------------------------------------------------
BINARY CITY is a comprehensive ROM hack of classic NES game Battle City.

A lot of things have been modified, e.g. now there's twice more code
than was in original Battle City ROM. So this is practically a new game.
Although graphically it is planned to look like original Battle City.

The genre of this game now is Action-puzzle.
Your aim in each level is to defeat all enemies, but sometimes it requires
unorthodox thinking, every other level is more and more peculiar.

Unfortunately, some of these puzzles can be ruined by abusing
savestates, so I don't recommend to use them until absolutely necessary.

The game offers 38 levels divided into 6 theme chapters.
First 5 chapters are pretty easy, the game can be played on real console.
But 6th chapter is special. It's the chapter where savestates are not enough.
Struggling trough it, you'll be learning the way of Tool-Assisted Superplay.

http://en.wikipedia.org/wiki/Tool-assisted_speedrun

----------------------------------------------------------------------------
---------------
Controls
---------------
1 player mode (main game):
 D-pad - move green tank
  (yellow tank's movement depends on current Mode - Reverse/Impulse)
 A - shoot
 B - hold it to keep both tanks in sync
 Select - change current Mode (if allowed by level's rules)
 Start - pause (go plan tactics!)
  ALSO HOLD START MORE THAN A SECOND TO DESTROY HQ AND RESET PUZZLE!

2 players mode (bonus game):
 D-pad - move your tank
 A - make other player shoot:
  1ST JOYPAD SHOOTS FOR 2ND TANK
  2ND JOYPAD SHOOTS FOR 1ST TANK
 Start - pause, hold Start to make suicide

---------------
Emulation
---------------
For first 5 chapters you can use any NES emulator, even oldest ones.
For 6th chapter (if you dare) I recommend FCEUX (fceux.com) or VirtuaNES.

For more comfortable TASing you might want to redefine some hotkeys.

In FCEUX:
 Config -> Map Hotkeys -> Speed Up
 Config -> Map Hotkeys -> Speed Down
 Config -> Map Hotkeys -> Pause
 Config -> Map Hotkeys -> Frame Advance

In VirtuaNES:

 Option(C) -> Shortcut key(K) -> Pause(Toggle)
 Option(C) -> Shortcut key(K) -> One step(Pause)

----------------------------------------------------------------------------
---------------
Authors
---------------
Game design, programming, music, gfx
 AnS

Testing:
 Chronix
 TiberiyLTim
 evgeny

Special thanks:
 Griever (source)
 Dan (Quarrel)

---------------
Contact
---------------
 ansmail2000@mail.ru
 http://shedevr.org.ru
----------------------------------------------------------------------------
