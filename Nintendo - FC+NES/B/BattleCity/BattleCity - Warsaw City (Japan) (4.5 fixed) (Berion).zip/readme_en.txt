===============
= About patch =
===============

Warsaw City is a complete hack of very popular few years ago in Poland "Tanks". The only modification wasn't translation, but also some graphic changes (tiles, new design of levels).

We have to apologise for not including the list of changes. Dear player, believe us, that Battle City has changed a lot and actually is codenamed as v4.5.
 
Patch is dedicated to Japanese version of Battle City (iNES).


======================
= Visible Changes :) =
======================

Main two differences between versions: in levels (battles, streets... you know what) and in colour palette.

- Polish localization
- Damages of the walls added.
- Gfx modifications: tanks, lives counter, bricked walls, force fields, respawn points, bullets, explosions, eagle (polish eagle). 
- Version depended color map changes (different set for every edition).
- Version depended respawn points locations (different set for every edition).
- Hostile vehicles armor upgrade (+4/+5).
- 35 (36) completely redesigned levels (different set for every edition).
- Insane vehicles count. ;)
- Insane difficulty leves (multi mode suggested). :P


==================
= Special Thanks =
==================

- Dragon Eye Studios for coded Quarrel - the great map editor.
- Docent14 for translation previous readme file.



Berion & Dr00id88 (24-VIII-2008)