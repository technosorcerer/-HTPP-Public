======================
= Informacje o �acie =
======================

Warsaw City to kompletny hack niegdy� popularnych w naszym kraju "Tank�w". Modyfikacje obejmuj� nie tylko lokalizacj� gry, ale przede wszystkim grafik� (w tym ca�kowicie nowy design leveli).

Musimy przeprosi� za brak szczeg�owej listy zmian. Drogi graczu (graczko?), uwierz nam na s�owo, �e nasze Battle City du�o ju� przesz�o i obecnie zatrzyma�o si� na wersji 4.5.

Patch przeznaczony jest na poprawny dump, japo�skiej wersji Battle City (iNES).


==========
= Zmiany =
==========

R�nice pomi�dzy poszczeg�lnymi wersjami s� w zasadzie dwie: w budowie poziom�w (bitw, ulic... jak to tam sobie nazwiesz) i palecie kolor�w.

- Kompletna lokalizacja wszystkich wyraz�w wyst�puj�cych w grze. T�umaczenie NIE jest wierne i takie te� mia�o by�.
- Dodane uszkodzenia ceglanych murk�w.
- Modyfikacje graficzne ikon (czo�gi, �ycia, lv), betonowych murk�w, pola si�owego, respawn point�w, pocisk�w, eksplozji. Orze�ek z PW.
- Zmianie uleg�a r�wnie� paleta kolor�w (zale�nie od edycji).
- Zmiana rozmieszczenia respawn point�w (zale�nie od edycji).
- Upgrade pancerza wrogich pojazd�w (+4/+5).
- 35 (36) Ca�kowicie przemodelowanych leveli (dla ka�dej edycji inny zestaw).
- Przesadzona ilo�� pojazd�w ;P
- Chory stopie� trudno�ci (multiplayer wskazany) ;P


===========================
= Specjalne podzi�kowania =
===========================

- dla Dragon Eye Studios za napisanie �wietnego edytora map.
- dla Docent14 za angielskie t�umaczenie readme do poprzednej wersji.




Mi�ej zabawy �ycz�:
- dra� Berion i Dr00id88 (24-VIII-2008)