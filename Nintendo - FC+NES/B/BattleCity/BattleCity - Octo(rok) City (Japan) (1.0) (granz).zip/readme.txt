Octo(rok) City v1.0

This is a pretty basic hack of Battle City for NES. Changes include graphics,
text and a select few stage layouts. Mostly, it was just a random idea
executed as a result of insomnia.

With that said, if anyone likes the concept and wants to improve upon it, be
my guest. You may feel free to use anything I've done as a basis for a
derivative hack. You don't necessarily need to credit me.

Instructions:
Apply the included IPS patch to the Japanese ROM. (e.g. "Battle City (J).nes")

--------------------------------

Excuse plot:

Otis and Ollie were two ordinary octoroks who roamed across the vast
wildernesses of the Hyrule surface world. Continually thwarted by Link during
his various journeys, Otis and Ollie grew weary of being conscripts in Ganon's
dubious plot to control Hyrule.

One day, they ventured into the labyrinthine underworld and stumbled upon an
unguarded fragment of the Triforce. Aware of the power it possessed, the two
quickly made off with the artifact and defected from Ganon's forces
altogether. Ganon, unwilling to concede to this betrayal, summoned an army of
his most loyal octorok minions to seek out Otis and Ollie and reclaim the
stolen Triforce fragment; but has Ganon underestimated the two? Can Otis and
Ollie defeat their former allies and free themselves from Ganon's clutches
once and for all?

--------------------------------

Complete list of changes:

 - All tanks are now octoroks. Enemy octoroks feature various patterns on
 their backs to help the player distinguish among them. (each type of enemy
 has its own special ability, such as extra speed or fire power)

 - Power-up graphics have been replaced with icons more respective of the
 Zelda series, such as swords and hearts. Their respective functions are:
 SWORD - increases your fire power, HEART - erects a force field around your
 Triforce fragment, SHIELD - erects a shield that protects you from enemy fire
 temporarily, CLOCK - temporarily freezes enemy octoroks, BOMB - destroys all
 enemy octoroks currently on the screen, 1UP - increases the player's life
 stock by 1.

 - A select few level layouts have been changed. In the original game, some
 layouts were based on Namco characters, such as those from the series Bubble
 Bobble and Dig-Dug. These levels now include Zelda characters instead, such
 as Ganon and Link.

 - HUD icons representing tanks now represent octoroks instead.

 - The title screen text was changed from BATTLE CITY to OCTO CITY. This
 consequently affects the demo level as well.

 - The flag icon that represents the current stage number has been replaced
 with the more generic "STAGE" text. The flag didn't really seem to fit the
 whole Zelda theme I was going for.

 - Various palette changes, namely to represent actual octorok colors that
 appear in the LoZ series.