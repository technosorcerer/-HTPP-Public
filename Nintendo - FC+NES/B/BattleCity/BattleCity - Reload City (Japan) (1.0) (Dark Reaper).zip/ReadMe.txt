Just us LIPS to add this ips file to an original copy of Battle City. 

This changes some of the palletes and every single level as well as the amount of starting lives to 9 (from 2)

Enjoy :)

-Dark Reaper