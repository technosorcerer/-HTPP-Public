This a 99% translated game because of the limited letters in the CHR and Arabic letters require a lot of space.

Neptune Ringgs