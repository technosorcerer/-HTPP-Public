这个改版是Battle City(J)的改版，所以请把补丁用在原版的Battle City(J)。
具体改变如下：

·关卡设计
·配色
·部分贴图

享受！

This is a hack of Battle City (J), so please apply the patch to the original Battle City (J) version.
Specific changes are as follows:

· Level design
· Color scheme
· Some textures

Enjoy!