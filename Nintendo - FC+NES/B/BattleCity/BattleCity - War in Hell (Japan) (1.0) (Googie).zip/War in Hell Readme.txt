WAR IN HELL
Battle City Hack by Googie & Quick Curly
2008-2010
--------------------------------------------------------------
Notes:

 Googie started  this hack back  in 2008 before sending  it to
Quick Curly to finish. :)

 The levels and graphics  have been edited in this Battle City
hack.  Googie edited the graphics and the first 8 levels,  and
Quick ended up finishing the remaining levels on his birthday!
:P

 You play as  an octorok  and have to  battle your  way out of
HELL!!!!!
--------------------------------------------------------------
Instructions:

 Use a  patching utility  such as Lunar IPS  to apply  the IPS
patch of the WiH hack included with this readme to a copy of a
"Battle City (J)" ROM.

 After you've done that, load up the ROM in your favourite NES
emulator and enjoy! :D

 Want to double the fun?  Grab a friend and play the hack with
2 players!
--------------------------------------------------------------
Special Thanks To:

    bbitmaster - For FCEUXD.
           Dan - For Quarrel.
        FuSoYa - For Lunar IPS.
          Gear - For beta testing.
       SnowBro - For Tile Layer Pro.
Vicious Poetry - For beta testing.
            YY - For YY-CHR.
--------------------------------------------------------------
Googie Thanks:

 Everyone who has  had my back  with this hack.  I'm confident
people will dig it!  There aren't  many Battle City hacks,  so
enjoy this hack!  Eeee! >8)
--------------------------------------------------------------
Quick Curly Thanks:

    Googie - For letting me be a part of this fun hack! :)

Intruder X - For the music and everything else!

...As well as:

 8sebastian,  BlackBlooper64,  ChaoticTyme,  cuberootinbinary,
DVLIAC,   errijnde,   flash276,  Gamers110,   Gear,   GUngan7, 
Insectduel, JcDizon,  JMFSpike, metalchains48/GoombaParaKoopa, 
Static S, Vicious Poetry, and the YouTube Crew.
--------------------------------------------------------------
Contacts:

     Googie - http://www.youtube.com/user/GoogieToons
            - http://acmlm.no-ip.org/board/profile.php?id=22
            - http://www.romhacking.net/community/569/
            - hispanikpanik(REMOVE)@yahoo.com 

Quick Curly - http://www.youtube.com/user/Qu1ckCur1y
            - http://acmlm.no-ip.org/board/profile.php?id=1121
            - http://www.romhacking.net/community/1051/
            - quickcurly[at]yahoo[dot]ca

 Intruder X - http://www.myspace.com/intruderxmusic
            - http://www.youtube.com/user/intruderxmusic
            - http://www.cdbaby.com/Artist/IntruderX

      GRENADE STUDIOS - Musical instruction/instrument repair/
             recording studio.
      Email: livegrenade@sympatico.ca