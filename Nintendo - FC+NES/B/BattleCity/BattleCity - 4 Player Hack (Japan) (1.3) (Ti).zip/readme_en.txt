**** BATTLE CITY 4-PLAYERS HACK README ****
This hack is for play only 3 or 4 players. It's not designed for 1-2 player.
Compatible with both Nes-Four-Score and Famicom 4-player adapter.


Options description:
 Friendly Fire - No: players no hit in each other.
 AI Use Bonus - AI can pick up bonuses.
 5 Bonus Tank - AI five bonus tanks instead of 3.
 Bonus shots - when hit in AI bonus armored tank, it no lose bonus ability.
 8 AI Tanks - up to 8 AI tanks at once instead of 6.
 40 AI Total - 40 AI tanks on stage.
 AI Tank Armor - in all AI tanks needs at least 2 hits.
 Swap Palettes - player 3 and 4 will use 'blinking' pals (orange and brown).
 New Bonuses - new bonus - ship and pistol.
 
Bonus description:
 Ship allows to move through water and gives an extra armor.
 Pistol will give ability to destroy trees.
For AI:
 Helm work, same as for players, but twice lower time.
 Shovel remove HQ defence.
 Star - all AI tanks on screen gains +1 armor.
 Bomb - destroy all players tanks.
 Watch - stop players, but they can continue shooting.
 Ship - same as for players.
 Pistol - all AI tanks on screen can destroy iron blocks.
 Life - AI gains 4 extra tanks to reinforcements.
 
If player collects 3 stars, when he's takes damage, loses stars, instead of death.

Players respawn:
 If player loses all lifes, and other players picks bonus, he's gain life and
 respawns. (If ally gain life for score, he's returns on a next stage).

Life for scores: players 1 and 3 has shared scores, for first 20k player3 gains
extra life, for next 20k - player1.  
Same for players 2 and 4 (in 3pl game - player 2 recieves every 20k).

In game 70 stages - 35 original and 35 from Tank1990.
Enemy Respawn speed increased from level 1 to 35, and from 36 from 70.

Comparing to original, respawn speed increased, and AI gains temporary invulnerability.
In 4-players game respawn speed faster, than in 3 players game.

In 40 AI tanks mode, AI also doubles bonus tanks quanity.