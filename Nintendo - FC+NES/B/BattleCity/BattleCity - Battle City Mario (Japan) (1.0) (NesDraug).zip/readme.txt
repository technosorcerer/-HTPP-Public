**** BATTLE CITY MARIO (4-PLAYERS) README ****

INFO: 
This hack is for 3 or 4 players. It's not designed for 1-2 player.
Compatible with both Nes-Four-Score and Famicom 4-player adapter.


CRED: 
The Battle City 4-player hack was originally made by Ti. This is a graphics update with some gameplay changes by Nesdraug and #.


OPTION DESCRIPTION:
 Friendly fire  	YES: players can hit each other
 Enemy powers  		YES: Enemies can pick up power-ups
 5+ Bonus enemies  	YES: 5 bonus enemies instead of 3
 Tough enemy 		YES: Enemies with question block power-ups take more hits
 8+ enemies		YES: Up to 8 enemies at once instead of 6
 40 enemies		YES: Total of 40 enemies in every stage*
 Enemy armor 		YES: All enemies take at least 2 hits.
 New power-ups 		YES: new powers - flower and cloud
*In 40 Enemies mode, Bonus enemies also doubles.
 

POWER-UP DESCRIPTION:
 Star 		- Invincibility
 Music box 	- Stop enemies
 Tanooki 	- Castle defence
 Question block - Gain more armor and fire power
 POW 		- Destroy all enemies on screen
 Mushroom	- 1up
 Flower  	- Destroy trees
 Cloud 		- Move through water and extra armor


ENEMY POWER-UPS:
 Star 		- Invincibility
 Music box 	- Stop players
 Tanooki 	- Remove castle defence
 Question block - All enemies on screen gain armor
 POW 		- Destroy all players
 Mushroom	- 4 extra enemies
 Flower  	- Destroy ice blocks
 Cloud 		- Move through water and extra armor

 
PLAYER RESPAWN:
 If a player loses all lives and another players picks up a bonus, they will gain a respawn. In 4-players game respawn speed is faster than in 3 players game.

SCORES: 
Players 1 and 3 has shared scores, for first 20k player3 gains
extra life, for next 20k - player1. Same for players 2 and 4 (in 3pl game - player 2 recieves every 20k).

STAGES: 
70 stages - 35 original and 35 from Tank1990. Enemy Respawn speed increased from level 1 to 35, and from 36 from 70.

