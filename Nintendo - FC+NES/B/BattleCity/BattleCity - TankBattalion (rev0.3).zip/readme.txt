see http://www.age.jp/~k-matsu/Games/HackRom/TankBattalion/
