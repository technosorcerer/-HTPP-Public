Beetlejuice (NES)
Traducción al Español v1.0 (30/10/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Beetlejuice (USA).nes
MD5: e2c5df63af6617474b3338f968a21ffb
SHA1: cd3c92b7c27940c53da8ed11b905048af439942a
CRC32: 1b2bad13
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --