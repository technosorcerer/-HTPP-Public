Baseball Stars 2014 Bases Reloaded
v1.0
hack by shadowinthelight
circular_illogic@yahoo.com

BBS_14BR.IPS patch requres No-Intro ROM file Baseball Stars (USA).nes
ROM CRC32:	40D159B6
ROM MD5:	657933B8730E30A080A85C4C04C15D38
ROM SHA-1:	3DE60E3341975C5E96C194A5ABBF20C0D62C4C8D

This game is what my 2010 hack that didn't go far enough should have been. All
hacking was done in Hexecute and yy-char. The following is what has been changed
from the original game.

* computer teams
  - all stats not already at 15 boosted
  - logos have been retouched or completely redone
  - minor change to World Powers and major changes to Ghastly Monsters linups
  - worst team (SNK Crushers) replaced with a new team more challenging than the
    improved American Dreams
* player created teams
  - new uniform colors (not a single color repeated)
  - new logos
  - default team names match the new logos
* other changes
  - new fonts all over the place
  - miscellaneous changes like new cursors and other minor tweaks
  - a few other text changes


*** The Story ***

  A lot has happened since the last season. Although everyone trained hard
to improve, the SNK Crushers fell so far behind that the owner decided to
disband the team. At the same time, fueled by growing frustrations of limiting
himself playing for the mortal team the World Powers, the god of thunder Zeus
finally quit. Urged by fellow philosopher Plato, Zeno tried out and was able to
fill the empty slot.

  Zeus put out the call to his fellow ancient gods and monsters. Taking
advantage of the hole left by the absence of the Crushers, he vowed to create a
new team that would be unbeatable by mere mortals. Taking advantage of her free
agent status, Medusa was one of the first to sign along with her Gorgon sister
Stheno. Gods, Titans, and monsters soon lined up for a chance to share in the
glory.

  The unexpected consequence was the chaos that followed within the Ghastly
Monsters clubhouse. Inspired by Medusa, Cyclops quit to join Zeus�s new team
(but unfortunately didn�t make the cut due to his lack of depth perception).
Angry at being abandoned by his fellow Greeks, Cerberus lost control. In his
rampage he mauled several teammates and was subsequently fired. Only a handful
of players stayed after the attack leading to a worldwide recruiting effort for
new spooky players.

The path before you is a challenging one worthy of Heracles himself. Do you have
what it takes to put together a team capable of beating not only the greatest
humans to ever play the game of baseball, but taking on immortal rulers of
Olympus?


















































*** SPOILER ALERT ***
Scroll down for the answers to the secret powered up team questions


















































WHO HACK
ED THIS?

SHADOWIN
THELIGHT

KAN I
HAZ LOL?

HELL
NO!!!