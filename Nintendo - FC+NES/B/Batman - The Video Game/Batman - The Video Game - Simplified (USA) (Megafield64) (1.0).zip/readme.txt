Thank you for downloading Batman Simplified.

This ROM hack of the classic Batman NES game has the majority of the levels edited to be easier and less hazardess than the originals.  None of the enemies have been changed, only the level layouts.