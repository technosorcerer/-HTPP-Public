--------------------------------------------------------------------------
Batman - Black Edition Ver. Ultima by DarthVaderX
--------------------------------------------------------------------------
This hack combines various elements from other hacks and graphical edits to present a unique experience:

    Color Fix ver.1.2 by Macbee: This hack changes Batman’s blue color scheme to gray to be more faithful to the original movie.
    Batman Game Prototype Cutscenes: All in-game cutscenes have been replaced with those from the prototype, which are completely different from the final version, including the ending scenes. These scenes were also recolored to represent the darker tone of Batman’s sprite as well as the title screen.

This hack is based on the prototype of the original game, which has greater difficulty in boss fights.

Box Art by Antonio de Lima.

Note: It is recommended to use the MESEN emulator to get a real view of the game’s colors, such as Batman’s sprite and its true shades of gray, among others.

To be applied on the Batman (U) [!] or Batman - The Video Game (USA) ROM.
--------------------------------------------------------------------------
Bonus:
--------------------------------------------------------------------------
Cheats codes:

"Infinite Health" = "00B7:08"

"Infinite weapons, all 3 kinds" = "00B8:63"
--------------------------------------------------------------------------
Debug Controls

Press the following button(s) on controller 2 to activate these features:

    A - Skips to the next stage
    B - Refills health/turns on invincibility
    Down - Freezes gameplay
    Right + B - Turns off invincibility
--------------------------------------------------------------------------