*****************************************************************
*		BATMAN - Deutsche �bersetzung            			  	*
*		----------------------------------						*
*																*
*			NEXUS Translation									*
*			Nuckes Translation 									*
*			blackerking											*
*																*
*	Spielangaben:												*
*	*************												*
*	Batman f�r das NES ist eines, der besten Spiele				*
*	f�r das Nintendo Entertainment System(NES).					*
*	Mit den F�higkeiten eines Ninja und verschiedenen			*
*	technischen Hilfsmitteln, muss es Batman schaffen			*
*	den Joker zu besiegen. 										*
*																*
*	Allgemeine Infos:											*
*	*****************											*
*	Die �bersetzung ist Entstanden weil eine Andere				*
*	sich nicht fertig stellen lie�.								*
*	Dieses Spiel ist technisch gesehen, einfach zu 				*
*	�bersetzen. So konnte ich ohne Schwierigkeiten 				*
*	zus�tzliche Buchstaben einf�gen und verwenden.				*
*	Sollte jemand Hilfe beim �bersetzen des Spieles				*
*	brauchen, so findet er in unseren Forum alle				*
*	Informationen die er braucht.								*
*																*
*	Release Angaben:											*
*	****************											*
*	original ROM: Datei: BATMAN (U).NES							*
*	CRC-32: 395569ec											*
*	MD4: 9a2c58dc52c3c3430b1892748e7c1672						*
*	MD5: 2e9f52556273aa735d0e75649541d812						*
*	SHA-1: 73b33e67e3c9e1116f9fcb021b10bb1171b8696a				*
*																*
*	Patchdatei: BATMAN.ips										*
*	CRC-32: c2212c7f											*
*	MD4: 69b1512551de523076f7be3b77ba795c						*
*	MD5: 00f04de0769fd2c02b0c523efe5993b1						*
*	SHA-1: 4089bc21039d280bb92d8b71e9749da61f47b965				*
*																*
*																*
*	�bersetzt:													*
*	<->Alle Texte 												*
*	<->Deutsche Buchstaben: ���									*
*	<->Intro und Ending											*
*																*
*	Zum Patchen wird das Programm: LunaIPS empfohlen.			*
*	http://www.zophar.net/utilities/patchutil.html				*
*																*
*	*************												*
*	Danksagungen:												*
*	*************												*
*	Danke an Streen f�r die durch mich verlorenen				*
*	Nerven.														*
*																*
*																*
*																*
*	http://black.bplaced.net/forum/phpBB3/						*
*	Original Download: 	http://nuckes.emubase.de/				*
*	Autor Website:		http://blackerking.de/					*
*																*
*	Disclaimer:													*
*	***********													*
*	Das Verwenden des Patches oder der angegebenen				*
*	Programme geschieht auf eigene Gefahr. Es gibt				*
*	KEINE Haftung f�r Datenverlust und oder Sch�den!			*
*																*
*****************************************************************