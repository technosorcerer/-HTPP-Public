Batman - The Dark Knight (V2.9) by Color.
This hack provides the following features:

- New scenarios.
- New color palette on the backgrounds.
- New color palette for Batman.
- New Portraits.
- Graphic Mods for some sprites.

Just patch the IPS file with Lunar Ips in a clear Rom of Batman (Ej: Batman (U) [!].nes) and enjoy the game.