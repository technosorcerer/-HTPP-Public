Batman - The Video Game (NES)
Traducción al Español v2.0 (03/12/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Cambiada P por J en la barra de estado
-Guion revisado (Mayúscula faltante, tú no acentuado, etc)
-Agrandada tilde de la licencia
-Traducido gráfico 'DON'T WALK'
-Traducido gráfico 'GOTHAM CITY HALL'

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Batman - The Video Game (USA).nes
MD5: 2e9f52556273aa735d0e75649541d812
SHA1: 73b33e67e3c9e1116f9fcb021b10bb1171b8696a
CRC32: 395569ec
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --