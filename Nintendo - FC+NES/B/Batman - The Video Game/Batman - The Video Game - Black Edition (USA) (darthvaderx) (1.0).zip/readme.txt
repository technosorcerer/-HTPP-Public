--------------------------------------------------------------------------
Batman - Black Edition by DarthVaderX:
--------------------------------------------------------------------------
This hack combines various elements from other hacks and graphical edits to present a unique experience:

    Color Fix ver.1.0 by Macbee: This hack changes Batman's blue color scheme to gray to be more faithful to the original movie.

    Title screen from Tweaked Edition ver.1.0 by Turambar: The title screen was inspired by this hack, with some additional graphic edits.

    Batman Game Prototype Cutscenes: All in-game cutscenes have been replaced with those from the prototype, which are completely different from the final version, including the ending scenes. These scenes were also recolored to represent the darker tone of Batman's sprite.

    Easy Hack ver.1.0 by Hiro1112: This is a hack aimed at making the Batman NES game much easier and more beatable than the original. Most levels (including boss levels) were edited to be easier and include shortcuts, rather than forcing players to always progress through predefined paths. Many traps were removed, and platforms were added to help avoid them. Enemy health was adjusted to make them easier to defeat, as well as boss health. Lastly, the amount of ammunition and health gained from upgrades has also been increased.

Note: A bug introduced by this hack in stage 2.3 that caused a game glitch has been fixed.

To be applied on the Batman (U) [!] or Batman - The Video Game (USA) ROM.
--------------------------------------------------------------------------
Bonus:
--------------------------------------------------------------------------
Cheats codes:

"Infinite Health" = "00B7:08"

"Infinite weapons, all 3 kinds" = "00B8:63"
--------------------------------------------------------------------------
Debug Controls

Press the following button(s) on controller 2 to activate these features:

    A - Skips to the next stage
    B - Refills health/turns on invincibility
    Down - Freezes gameplay
    Right + B - Turns off invincibility
--------------------------------------------------------------------------