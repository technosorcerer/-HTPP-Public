

BATTLETOADS (U) [NES] - UNUSED MUSIC PATCH


Well, after the marvelous job that Ti has made concerning to the original Hack for fixing the bugs in Battletoads (U), some people have talked about enabling an unused music.

Of course that some people might say: oh, all you must do it's just enable a game genie code... but it doesn't sound / seem natural, that's the reason for this hack.

To the Battletoads fans, this is a fantastic improvement, because Battletoads has the same background music shared in the following Stages:

Stage # 05 - Surf City
Stage # 09 - Terra Tubes

With this patch, the unused music now is the music for the Surf City stage and the original one is kept to the Terra Tubes Stage, giving to Battletoads 12 musics to its 12 stages.   


REMARKS: This patch will not work if applied directly to the original Battletoads (U).

See the instructions in the readme file for patching correctly.
 

--------------
CORRECT USAGE
--------------

Get the following rom:

Battletoads (U) [!].nes (GoodNes 3.23b)
CRC32: BA9164E7
MD5: BBAFEAD19C25B38A5A129BB8C51AAF8D
SHA-1: 5C3A497A82BE60704DEDF45248B6AD9B32C855AB


1 - Apply Ti's hack on the original Battletoads (U) -> https://www.romhacking.net/hacks/2528/

2 - After applying Ti's hack, apply this hack to the modified rom;

3 - Use LunarIPS for patching;

4 - Enjoy;


----------
THANKS TO:
----------

Ti         - for the bugfix hack;

RaidouJFlo - for the music patch;




