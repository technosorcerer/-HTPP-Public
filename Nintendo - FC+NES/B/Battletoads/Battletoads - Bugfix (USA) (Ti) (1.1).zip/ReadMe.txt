[NES] BattleToads (U) - bugfix changelog:

Patch version 1.1
34) fixed bug on Terra tubes if playing alone as Zitz.
35) fixed palette bug when level restarts in a same time as palette being changed (If one player dies while other jumps to Dark Queen).


Patch version 1.0 (23 Aug 2015)

1) fixed error in code (creates "level 4 stick bug", and possible others). (same as in 'E')
2) fixed clinger-winger for 2 players. (same as in 'E')
3) fixed Volkmire�s Inferno (Fire Zone) Missiles/Rockets hit in down screen border. (same as in 'E')
4) fixed bug when player 2 can fall and die out of screen, when jump to Robo-manus boss. (same as in 'E')
5) turbo tunnel obstacles changed from pink to yellow.
6) fixed Terra tubes glitch "jump through wall" at start (same as in 'E').
7) Right+Left simultaneously no longer move toads by Y coordinate on 2d-levels.
8) fixed bug when Hornhead eat player picked by other player.
9) fixed wrong sprite when you pick player or enemy and sit down on 2d-levels (was correct only in ice caverns).
10) no more walking when sit with hold object (but this bug worked only in ice caverns, because of bug #8).
11) no longer can break game in turbo tunnel, if die on bike without taking checkpoint.
12) fixed various bugs when player 2 throw player 1 at the same time as get hit from enemy (same as in 'J').
13) when player re spawns he's no longer do last animation (example: die in water with special movement in surf city).
14) when player take damage while taken by slug, it's correctly unlinks. (same as in 'E')
15) when slug killed with a stick while hold other player, it's correctly unlinks.
16) when slug hold one player, it can't start hold other player.
17) no more two slug's on one player at once.
18) stick now dropped when slug hold player.
19) slug #id in player state clears on checkpoint restart (if one player dies, while other taken by slug).
20) you can't throw other player through ceiling in Terra tubes. (same as in 'E')
21) corrected ice caverns moving horizontal platform hit-box. (sprite center position)
22) sit style for all 2d levels, except ice caverns, changed to Revolution (level 12) /BTDD style - when toad sit down it stops moving, and no running bug allowed, but still can move by 1 pix step.
23) fixed incorrect sprite mask for player taken by other player in terra tubes (on tubes joint).
24) fixed a way to stuck in Terra tubes if get hit from shark while on propeller.
25) corrected toad sprite position on jet's. (Volkmire�s Inferno)
26) fixed glitch, when 3rd Rat can run through wall and disappear at last platform. (same as in 'E')
27) fixed level2 (Wookie Hole) game freeze on some NES clones.
28) attributes corrected on title screen and toad's pictures.
29) added boss theme music for Big Blag.
30) you can't longer hold other player when swim.
31) fixed electricity glitch, when player hold by other receive immunity.
32) on restart level electricity state also cleared.
33) no more rat race rat kill bug.