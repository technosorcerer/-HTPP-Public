Battletoads- (colors changed)
This patch changes many of the color palettes in this game, sky blue toads and some stages with colors similar to SNES.version 1.1 fixes bugs in colors of the first level
In IPS format, you can use LunarIPS or Floating IPS.
File used:
Battletoads (United States) .Nes

The IPS patch must be used on a NES ROM
