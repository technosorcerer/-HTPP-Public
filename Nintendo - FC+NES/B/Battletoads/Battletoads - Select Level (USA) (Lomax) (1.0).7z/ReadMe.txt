﻿--------------------------Info---------------------------
Game name: Battletoads
Console: Nintendo entertainment system
Game region USA: (U)
Patch: SP (Solid patch)
Patcher: Solid patcher
Patcher download link:
 Windows: https://romhackplaza.org/utilities/solid-patcher-utility/
 Linux: https://romhackplaza.org/utilities/solid-patcher-utility-2/
 https://rgcorp.ucoz.net/load/console_soft/solid_patcher/2-1-0-97
----------------------------------------------------------
--------------------------patch------------------------
The patch adds the following changes:
 
 Select level using the SELECT button on the title screen.
 The player 2 control on level 11 (Clinger-Winger) is fixed.

----------------------------------------------------------
Author by: Lomax