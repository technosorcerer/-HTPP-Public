BattleToads 4 players - BT4p 2.3_256_spr

Mod/hack adds fourth (and third) player to Battletoads (NES, U-version) to make possible to play the game with four
	people at the same time.
There are can be a few minor graphical glitches.

For version - 2.2 / 2.3_256_spr:
Levels available: 1-6.

For version 2.2 (standart version, not emulator-specific):
Supported emulators: fceuxdsp 1.07, nestopia 1.40, jnes 1.1.
With 4 toads there are slowdowns (with 3 almost ok). Characters and enemyes can flicker in the reason of sprites limitation.

For version 2.3_256_spr (aditional version, emulator-specific alongside a version that is not emulator-specific):
Boosted version. Sprite limitation has been reduced. (there is need for special boosted emulator, there is configured one in the archive).
Supported emulators: Mednafen_nes_128_overclock_SMD_x7.
Goes well. Characters dont flicker.


Mod creator: NakeuD2007

Special thanks to: Ti_ 
Thanks to: Doomday


-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
ROM\Mod SHA-1:
5c3a497a82be60704dedf45248b6ad9b32c855ab *Battletoads (U) [!].nes
1598f362056d2f5e5e9aff8a566594742a8a8994 *Battletoads_4_players_-_BT4p_2.2.nes
0da34b970f5f480c1720b13416441c84af6cff31 *Battletoads_4_players_-_BT4p_2.3_256_spr.nes


-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
A few BT4p-releated videos, including some glithes from development:
www.youtube.com/channel/UCF3WssHzjr8AZ8Dqi-uXTMQ


-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Donate:
PayPal:			paypal.me/nakeud2007
