Battletoads
* Genre: Beat 'em up
* Platform: Nintendo Entertainment System
* Developer: Rare Ltd.
* Year: 1991
    * Hacking, graphics, translation: Ginny
    * Testing: Ginny , Coregon 
* Progress: 100%
* Release date: February 2, 2007
* Date updated: October 9, 2015
* ROM: Battletoads (U).nes (according to some data Battletoads (U) [p1].nes)
* MD5: bbafead19c25b38a5a129bb8c51aaf8d
* Patch version: 1.3
* Patch: Download (25.03 Kb)
* Number of downloads: 1598
* Description:
       Like many American superheroes, Battletoads originated from comic books. In our case, these comics were published in Nintendo Power magazine.
       The backstory is this: three players who played a game called “Battle Toads” turned into real fighting toads as a result of the illegal actions of a simple technician servicing a virtual reality machine. Morgan Ziegler became Zitz, Dave Share became Rash, and George Pie became a toad named Pimple. Now they have numerous adventures that are revealed to us not only in comics and games on NES, SNES, Game Boy and arcade machines, but even in cartoons! Unfortunately, the pilot cartoon did not become as popular as, say, a regular comic book column in Gamepro magazine. Over the hill they also sold fighting toad dolls, special cards (like baseball cards) and even Halloween costumes!
       Let's return to our wonderful game: its plot revolves around the fact that the Black Queen kidnapped Pimple and Princess Angelica and imprisoned them on her planet. Now the remaining two toads will have to, having defeated Robo-Manus and Big Blag along the way, free their friends. Of course, it’s somewhat banal, but the same cannot be said about the gameplay: for about four or five levels it seems that each level is a new game built on one common engine. It's surprising that toads can not only hit enemies with their fists, improvised objects, and other enemies. You can ride a dragon and spit fire! A huge number of tricks, techniques and Warps (sort of teleporters to other levels) add spice to the gameplay. Until recently, only one thing stood in the way - the amazing complexity of the game. I remember there were only two people in the school who reached Karnath's Lair and both were unanimously recognized as game gods. Before my eyes, two of my friends got into a fight because one threw the other off a flying motorcycle in his last life. And all this happened so loudly that the neighbors began to ring the doorbell! Ah, youth. The situation is the same in other countries - even the creators of the Battle Toads fan site were unable to beat the game on the original console. Fortunately, now ordinary gamers have at their disposal saving at any second of the game, time dilation, Game Genie codes, and finally, just Cheat Searches that will make your life much easier.
       If you have never played this game, then it is definitely worth a try. So many people cut into it day and night for a reason.