BattleToads 4 players - BT4p

Mod/hack adds fourth (and third) player to Battletoads (NES, U-version) to make possible to play the game with four people at the same time.

 Also:
Custom respawn (for choice), color select for toads (including extended palettes),
oneshot deals damage instead (for choice), friendly fire (for choice), change of interaction with lower edge of the screen,
different finishing hits to use, multiplier and difficulty of enemies (for choice), level select.

To play as it intended, use moded emulator (with extended capacity or "blast processing") with 256_spr rom.
https://www.patreon.com/posts/moded-emulator-34560541
https://www.emu-land.net/forum/index.php/topic,77237.0.html


------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
BattleToads 4 players - BT4p 3.9_256_spr / 3.8	(18.12.18)

Changes:
Custom respawn (for choice).
Other changes.

Notes:
About "Custom Respawn" (CR):
After death player appears near other player, regardless of the stage (throw back on the check point does not happen).
Living players can choose (press Select while there is an animation of death) to whom the dead player will be teleported.
Player can refuse respawn near other player (by pressing Select during own death). In that case respawn occurs as in the original.
CR mode also activates lives share. In that case Continue restores lives to all players.
Continue screen can occur only on BeatEmUp sections.
Loss of all lives on platforming and race sections throw back on the check point with restoration of lives (the quantity varies on stages).
The same occurs if all players dies at the same time.





BattleToads 4 players - BT4p 3.7_256_spr / 3.6	(21.09.17)
Notes:
Added color mode "v256 select" needs new verison of modifyed Mednafen by DoomDay.
	(0.9.45.1 in archive in head of BT4p topic: http://www.emu-land.net/forum/index.php/topic,77237.0.html).
	Other color modes stays the same and works on old boosted emulator (and regular emulator) .
To add player (especially concerns stages after 0) press Start 1 time. There is the sound. Other presses from same player will skip scenes between stages.
	Players can press Start sequentially (not at the same time).
One of the added hits - weight (for players 1 and 3). Players 2 and 4 can break through (with powerUp) hit immunity of some enemies.
Yellow terminators have immunity to crown and punch powerStrikes - spawns after x4.
Green liquidator have immunity to crown powerStrike - spawns after x8.
Enemy multiplier and difficulty concern stages: 1,2,3,Surf City,Inferno. Also concern bosses and some separate enemies (rat on RatRace).
Additional enemies spawns after player lost life on beatemup stages (same stages)(on x2 x4 x8).
Colors of modify behaviour enemies can vary from types of enemies.
Changes:
Added color mode "v256 select": now color of every toad (including additional colors from extended palettes) can be changed during the game.
	To change the color hold hit and press Select (third color - Chameleon)
In "v256 select" mode remain broken tiles are corrected with additional video-memory.
Changed sound of hit about prickle (and hit about lower edge of the screen in Revolution) to eliminate lags.
Added timer before next pause activation.
Friendly fire mode can be changed during the game. Hold hit and jump, press Select.
OneUp aslo fills hits.
Damage restored for weight powerStrike (because of overlapping with fan and gas).
Bug, when divided weight powerStrike hits other player and enters him into lag (on stage 2), is corrected differently.
Ducks and fans doesnt have terminators armor.
Some correction in entrance to Robomanus.
Some changes in TerraTubes weel (on water weels there is the cunning).
When fan with divided damage, which chews the player, is broke apart, the player is released (not enters into lag).
Correction of TurboTunnel wall, when it is broke apart.
Correction of capture of player by snakeFlower in stage 2.
Correction of the bike of fourth player.
Additional enemies changed (from liquidators to runners).
Walkers on first boss has been changed (now whithout armor).
Other changes





BattleToads 4 players - BT4p 3.5_256_spr / 3.4	(06.08.17)
Changes:
Change of interaction with lower edge of the screen (on Arctic level - doesnt kill, on Revolution - throws up and so forth)
Different finishing hits (hold hit button and tap two consecutive directions)
Change of respawn of some enemies
Addition of behaviour of some enemies
Flyes are weird
Addition of option menu
Friendly fire (for choice)
Level select
Instant kill deals damage instead (for choice)
Enemies - multiplier and difficulty (for choice)
Chameleon color (for choice)
Some changes of first level boss
Correction of helicopter on Tubes level (ferst toad doesnt automaticly start flight up)
Correction of animation and linking, remaining from some objects (such as fan)
On stick on Revolution level can hang on several toads
Other changes





BattleToads 4 players - BT4p 3.3_256_spr / 3.2	(06.08.17)
Changes:
Camera correction (in levels with free camera)
Camera correction on axis X (priority shift between players)
Camera lock correction (befor bike races in Turbo tunnel and Inferno)
Change of camera on Exluder
Change of camera on Winger level (now on leader player)





BattleToads 4 players - BT4p 3.1_256_spr	(21.04.17)

Mod/hack adding fourth (and third) player to Battletoads (NES, U-version) to make possible to play the game with four
	people at the same time.
Levels available: all.
There are can be a few minor graphical glitches.


-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
For version - demo_2.2 / demo_2.3_256_spr:
Levels available: 1-6.
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


For version 3.0 / 2.2:
Supported emulators: fceuxdsp 1.07, nestopia 1.40, jnes 1.1.
With 4 toads there are slowdowns (with 3 almost ok). Characters and enemyes can flicker in the reason of sprites limitation.

For version 3.1_256_spr / 2.3_256_spr:
Boosted version. Sprite limitation has been reduced. (there is need for special boosted emulator, there is configured one in the archive).
Supported emulators: Mednafen_nes_128_overclock_SMD_x7.
Goes well. Characters dont flicker.


Mod creator: NakeuD2007

Special thanks to: Ti_ 
Thanks to: Doomday


-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
A few BT4p-releated videos, including some glitches from development:
www.youtube.com/channel/UCF3WssHzjr8AZ8Dqi-uXTMQ


-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Donate:
PayPal:			paypal.me/nakeud2007
Patreon:			patreon.com/nakeud2007