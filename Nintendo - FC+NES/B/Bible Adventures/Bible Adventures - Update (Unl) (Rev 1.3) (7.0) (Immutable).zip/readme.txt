BIBLE ADVENTURES (VERSION 7.0 HACK) 

CHANGES:

1) NEW TEXT FONT AND TITLE FONT

2) COLOR CHANGES 
	- GREEN CLOUDS ARE WHITE 
	- THE SCORPIONS IN THE GAME, "DAVID AND GOLIATH" NOW HAVE THE WHITES OF THEIR EYES RESTORED
	- BLUE STONE NARRATIVE TABLETS ARE GRAY (ONE PATCH HAS A "GRANITE TEXTURE"; THE OTHER ONE IS PLAIN GRAY).

3) TEXT CORRECTIONS FROM THE ORIGINAL GAME.
	- NOAH'S INTRO - THE BIBLE VERSE REFERENCE NOW STATES THE CHAPTER NUMBER.
	- "BLACK BIRDS" ARE NOW "BLACKBIRDS" (ONE WORD, NOT TWO).
	- "COYOTES" ARE NOW LISTED AS "FOXES".

4) THE GAME OF "BABY MOSES" HAS BEEN SLIGHTLY ALTERED TO PLAY AS "HARD LABOR". I COULDN'T STAND SEEING A BABY BEING TOSSED INTO A RIVER... REPEATEDLY... SO "BABY MOSES" HAS BEEN REPLACED WITH A PILE OF BRICKS, AND MIRIAM IS WORKING FOR THE EGYPTIANS. THE INTRO TEXT WAS ALSO CHANGED TO ANOTHER BIBLE PASSAGE TO ACCOMPANY THE GAMEPLAY. 

5) NEW TEXT CHARACTERS ADDED FOR THE NARRATION - ROMAN NUMERALS ONE (I) AND TWO (II).

6) THE BIBLE VERSES NOW COMPLIMENT THE KJV/MKJV BIBLES. SOME VERSES WERE SHORTENED SINCE THE GAME DID NOT ALLOW ENOUGH ROOM FOR ALL THE TEXT.

ABBREVIATIONS: 

BA = THE ORIGINAL GAME TEXT (FROM THE NEW INTERNATIONAL VERSION BIBLE UNLESS OTHERWISE NOTED)

KJV/MKJV = KING JAMES VERSION/MODERN KING JAMES VERSION (FOR COMPARISON)

EDIT = TEXT IN 7.0


PROVERBS 1:33 -

BA - 

BUT WHOEVER LISTENS TO ME WILL LIVE IN SAFETY AND BE AT EASE, WITHOUT FEAR OF HARM.

MKJV - 

BUT WHOEVER LISTENS TO ME SHALL DWELL SAFELY, AND SHALL BE QUIET FROM FEAR OF EVIL.

EDIT - 

BUT WHOEVER LISTENS TO ME SHALL DWELL SAFELY, AND BE QUIET FROM FEAR OF EVIL.



PROVERBS 8:18,19 -

BA - 

WITH ME ARE RICHES AND HONOR, ENDURING WEALTH AND PROSPERITY. MY FRUIT IS BETTER THAN FINE GOLD; WHAT I YIELD SURPASSES CHOICE SILVER.

MKJV - 

RICHES AND HONOR ARE WITH ME; ENDURING RICHES AND RIGHTEOUSNESS.�MY FRUIT IS BETTER THAN GOLD, YEA, THAN FINE GOLD; AND WHAT I GIVE IS BETTER THAN CHOICE SILVER.

EDIT - 

RICHES AND HONOR ARE WITH ME; ENDURING RICHES AND RIGHTEOUSNESS. MY FRUIT IS BETTER THAN GOLD, YEA, THAN FINE GOLD....




PROVERBS 13:25 -

BA -

THE RIGHTEOUS EAT TO THEIR HEARTS' CONTENT, BUT THE STOMACH OF THE WICKED GOES HUNGRY.

MKJV - 

THE RIGHTEOUS EATS TO THE SATISFYING OF HIS SOUL, BUT THE BELLY OF THE WICKED SHALL LACK.

EDIT -

THE RIGHTEOUS EATS TO THE SATISFYING OF HIS SOUL, BUT... THE WICKED SHALL LACK.




HEBREWS 10:36 -

BA - 

YOU NEED TO PRESEVERE SO THAT WHEN YOU HAVE DONE THE WILL OF GOD, YOU WILL RECEIVE WHAT HE HAS PROMISED.

MKJV - 

FOR YOU HAVE NEED OF PATIENCE, SO THAT AFTER YOU HAVE DONE THE WILL OF GOD YOU MIGHT RECEIVE THE PROMISE.

EDIT - 

YOU HAVE NEED OF PATIENCE, SO THAT AFTER YOU HAVE DONE THE WILL OF GOD YOU MIGHT RECEIVE THE PROMISE.



GENESIS 6:21 -

BA - 

YOU ARE TO TAKE EVERY KIND OF FOOD THAT IS TO BE EATEN AND STORE IT AWAY...

MKJV - 

AND TAKE FOR YOURSELF ALL FOOD THAT IS EATEN, AND YOU SHALL GATHER FOR YOURSELF. AND IT SHALL BE FOR FOOD, FOR YOU AND FOR THEM.

EDIT -

TAKE FOR YOURSELF ALL FOOD THAT IS EATEN, AND... GATHER FOR YOURSELF....




GENESIS 7:2 - 

BA - 

TAKE WITH YOU SEVEN OF EVERY KIND OF CLEAN ANIMAL, A MALE AND ITS MATE...

MKJV - 

You shall take with you every clean animal by sevens, the male and female. And take two of the animals that are not clean, the male and female.�

EDIT - 

TAKE WITH YOU EVERY CLEAN ANIMAL BY SEVENS, THE MALE AND FEMALE....




ECCLECIASTES 3:13 -

BA - 

THAT EVERYONE MAY EAT AND DRINK, AND FIND SATISFACTION IN ALL HIS TOIL - THIS IS THE GIFT OF GOD.

MKJV - 

And also that every man should eat and drink, and enjoy the good of all his labor, it is the gift of God.�

EDIT -

THAT EVERY MAN SHOULD EAT AND DRINK, AND ENJOY THE GOOD OF ALL HIS LABOR, IT IS... OF GOD.




PSALM 147:14 -

BA - 

HE GRANTS PEACE TO YOUR BORDERS AND SATISFIES YOU WITH THE FINEST OF WHEAT.

MKJV - 

He makes peace in your borders and fills you with the finest of the wheat.

EDIT -

HE MAKES PEACE IN YOUR BORDERS AND FILLS YOU WITH THE FINEST OF WHEAT.



PROVERBS 15:15 -

BA - 

ALL THE DAYS OF THE OPPRESSED ARE WRETCHED, BUT THE CHEERFUL HEART HAS A CONTINUAL FEAST.

MKJV - 

All the days of the afflicted are evil, but gladness of heart is a continual feast.�

EDIT -

ALL THE DAYS OF THE AFFLICTED ARE EVIL, BUT GLADNESS OF HEART IS A CONTINUAL FEAST.



PSALM 111:5 -

BA - 

HE PROVIDES FOOD FOR THOSE WHO FEAR HIM: HE REMEMBERS HIS COVENANT FOREVER.

MKJV -

He has given food to those who fear Him; He will always be mindful of His covenant.�

EDIT - 

HE HAS GIVEN FOOD TO THOSE WHO FEAR HIM; HE WILL [KNOW] HIS COVENANT.




JOB 5:22 - 

BA - 

YOU WILL LAUGH AT DESTRUCTION AND FAMINE, AND NEED NOT FEAR THE BEASTS OF THE EARTH.

MKJV -

At destruction and famine you shall laugh; neither shall you be afraid of the beasts of the earth.�

EDIT -

AT DESTRUCTION AND FAMINE YOU SHALL LAUGH; NEITHER SHALL YOU BE AFRAID....



PSALM 31:24 -

BA - 

BE STRONG AND TAKE HEART, ALL YOU WHO HOPE IN THE LORD.

MKJV -

Be strong, and He will make your heart stronger, all you who hope in Jehovah.�

EDIT -

BE STRONG, AND HE WILL MAKE YOUR HEART STRONGER...




2 CORINTHIANS 4:16 - 

BA - 

THEREFORE WE DO NOT LOSE HEART. THOUGH OUTWARDLY WE ARE WASTING AWAY, YET INWARDLY WE ARE BEING RENEWED DAY BY DAY.

KJV -

FOR WHICH CAUSE WE FAINT NOT; BUT THOUGH OUR OUTWARD MAN PERISH, YET THE INWARD MAN IS RENEWED DAY BY DAY.

MKJV - 

FOR THIS CAUSE WE DO NOT FAINT; BUT THOUGH OUR OUTWARD MAN PERISHES, YET THE INWARD MAN IS BEING RENEWED DAY BY DAY.

EDIT - 

FOR WHICH CAUSE WE FAINT NOT; BUT THOUGH OUR OUTWARD MAN PERISH, YET THE INWARD MAN IS RENEWED DAY BY DAY.





1 SAMUEL 17:34 & 35 -

BA - 

DAVID SAID... "WHEN A LION OR A BEAR CAME AND CARRIED OFF A SHEEP FROM THE FLOCK, I WENT AFTER IT, STRUCK IT AND RESCUED THE SHEEP..."

KJV - 

And David said unto Saul, Thy servant kept his father's sheep, and there came a lion, and a bear, and took a lamb out of the flock:�
And I went out after him, and smote him, and delivered it out of his mouth: and when he arose against me, I caught him by his beard, and smote him, and slew him.�

MKJV - 

And David said to Saul, Your servant kept his father's sheep, and there came a lion and a bear, and took a lamb out of the flock.�
And I went out after it and struck it, and delivered the lamb out of its mouth. And when it rose against me, I caught it by the beard, and struck it and killed it.��

EDIT -

DAVID SAID... "A LION TOOK A LAMB OUT OF THE FLOCK: AND I WENT OUT AFTER HIM AND SMOTE HIM AND DELIVERED IT OUT OF HIS MOUTH..." 





PROVERBS 12:10 -

BA - 

A RIGHTEOUS MAN CARES FOR THE NEED OF HIS ANIMAL, BUT THE KINDEST ACTS OF THE WICKED ARE CRUEL.

KJV - 

A righteous man regardeth the life of his beast: but the tender mercies of the wicked are cruel.�

MKJV - 

A righteous one understands the soul of his animal; but the tender mercies of the wicked are cruel.�

EDIT -

A RIGHTEOUS MAN REGARDS THE LIFE OF HIS BEAST: BUT THE [MERCIES] OF THE WICKED ARE CRUEL. 





PSALM 23:4 -

BA - 

EVEN THOUGH I WALK THROUGH THE VALLEY OF THE SHADOW OF DEATH, I WILL FEAR NO EVIL, FOR YOU ARE WITH ME; YOUR ROD AND YOUR STAFF, THEY COMFORT ME.

KJV - 

Yea, though I walk through the valley of the shadow of death, I will fear no evil: for thou art with me; thy rod and thy staff they comfort me.

MKJV - 

Yea, though I walk through the valley of the shadow of death, I will fear no evil; for You are with me; Your rod and Your staff, they comfort me.

EDIT - 

YEA, THOUGH I WALK THROUGH THE VALLEY OF THE SHADOW OF DEATH, I WILL FEAR NO EVIL: FOR THOU ART WITH ME; THY ROD AND THY STAFF THEY COMFORT ME.




PSALM 128:1,2 -

BA - 

BLESSED ARE ALL WHO FEAR THE LORD, WHO WALK IN HIS WAYS... BLESSING AND PROSPERITY WILL BE YOURS.

MKJV - **NOTE THE DIFFERENCE IN VERSE 2 - NOT ENOUGH ROOM - USE VERSE 1 ONLY** 

[VERSE 1] Blessed is everyone who fears Jehovah, who walks in His ways.�

[VERSE 2] For you shall surely eat the labor of your hands; you shall be happy, and all is well with you.�

EDIT - 

BLESSED IS EVERYONE WHO FEARS [THE LORD], WHO WALKS IN HIS WAYS.




1 SAMUEL 17:40 -

BA - 

THEN [DAVID]... WITH HIS SLING IN HAND, APPROACHED THE PHILISTINE.

KJV - 

And he took his staff in his hand, and chose him five smooth stones out of the brook, and put them in a shepherd's bag which he had, even in a scrip; and his sling was in his hand: and he drew near to the Philistine.�

EDIT -

HIS SLING WAS IN HIS HAND: [DAVID] DREW NEAR TO THE PHILISTINE.



PSALM 34:19 -

BA - 

A RIGHTEOUS MAN MAY HAVE MANY TROUBLES, BUT THE LORD DELIVERS HIM FROM THEM ALL.

KJV - 

Many are the afflictions of the righteous: but the LORD delivereth him out of them all.�

MKJV -

Many are the afflictions of the righteous, but Jehovah delivers him out of them all.�

EDIT -

MANY ARE THE AFFLICTIONS OF THE RIGHTEOUS: BUT THE LORD DELIVERS HIM....




PSALM 37:24 -

BA - 

THOUGH HE STUMBLE, HE WILL NOT FALL, FOR THE LORD UPHOLDS HIM WITH HIS HAND.

KJV -

Though he fall, he shall not be utterly cast down: for the LORD upholdeth him with his hand.�

MKJV - 

Though he fall, he shall not be cast down; for Jehovah upholds his hand.�

EDIT -

THOUGH HE FALL, HE SHALL NOT BE UTTERLY CAST DOWN: THE LORD UPHOLDS HIM....




1 SAMUEL 17:37 -

BA - 

THE LORD WHO DELIVERED ME FROM THE PAW OF THE LION AND THE PAW OF THE BEAR WILL DELIVER ME FROM THE HAND OF THIS PHILISTINE.

KJV - 

David said moreover, The LORD that delivered me out of the paw of the lion, and out of the paw of the bear, he will deliver me out of the hand of this Philistine. And Saul said unto David, Go, and the LORD be with thee.�

MKJV -

And David said, Jehovah who has delivered me out of the paw of the lion and out of the paw of the bear, He will deliver me out of the hand of this Philistine. And Saul said to David, Go, and may Jehovah be with you.�

EDIT -

THE LORD THAT DELIVERED ME OUT OF THE PAW OF THE LION... HE WILL DELIVER ME OUT OF THE HAND OF THIS PHILISTINE.




1 SAMUEL 17:49 -

BA -

REACHING INTO HIS BAG AND TAKING OUT A STONE, [DAVID] SLUNG IT AND STRUCK THE PHILISTINE ON THE FOREHEAD. THE STONE SANK INTO HIS FOREHEAD, AND HE FELL FACEDOWN ON THE GROUND.

MKJV - 

And David put his hand into his bag and took a stone from there, and slung it and struck the Philistine in his forehead, so that the stone sank into his forehead. And he fell on his face to the earth.��

EDIT -

DAVID PUT HIS HAND INTO HIS BAG AND TOOK A STONE FROM THERE, AND SLUNG IT AND STRUCK THE PHILISTINE IN HIS FOREHEAD... 
AND HE FELL ON HIS FACE TO THE EARTH.




PSALM 46:1 -

BA - 

GOD IS OUR REFUGE AND STRENGTH, AN EVER-PRESENT HELP IN TROUBLE.

MKJV - 

God is our refuge and strength, a very present help in trouble.�

EDIT -

GOD IS OUR REFUGE AND STRENGTH, A VERY PRESENT HELP IN TROUBLE.





PSALM 138:7 -

BA - 

THOUGH I WALK IN THE MIDST OF TROUBLE, YOU PRESERVE MY LIFE: YOU STRETCH OUT YOUR HAND AGAINST THE ANGER OF MY FOES.

MKJV - 

If I walk in the midst of trouble, You will give me life; You shall stretch forth Your hand against the wrath of my enemies, and Your right hand shall save me.��

EDIT -

IF I WALK IN THE MIDST OF TROUBLE, YOU WILL GIVE ME LIFE... AND YOUR RIGHT HAND SHALL SAVE ME.




2 KINGS 17:39 - 

BA - 

RATHER, WORSHIP THE LORD YOUR GOD; IT IS HE WHO WILL DELIVER YOU FROM THE HAND OF ALL YOUR ENEMIES.

MKJV - 

And you shall fear Jehovah your God. And He shall deliver you out of the hand of all your enemies.�

EDIT -

AND YOU SHALL FEAR JEHOVAH YOUR GOD. AND HE SHALL DELIVER YOU OUT OF THE HAND OF ALL YOUR ENEMIES.



DEUTERONOMY 20:4 -

BA - 

FOR THE LORD YOUR GOD IS THE ONE WHO GOES WITH YOU TO FIGHT FOR YOU AGAINST YOUR ENEMIES TO GIVE YOU VICTORY.

KJV -

For the LORD your God is he that goeth with you, to fight for you against your enemies, to save you.

MKJV - 

For Jehovah your God is He who goes with you to fight for you against your enemies, to save you.�

EDIT - 

FOR THE LORD YOUR GOD IS HE WHO GOES WITH YOU TO FIGHT FOR YOU AGAINST YOUR ENEMIES, TO SAVE YOU.




HEBREWS 13:6 - 

BA - ** "MAY" SHOULD HAVE BEEN REPLACED WITH "SAY" **

SO WE MAY WITH CONFIDENCE, "THE LORD IS MY HELPER, I WILL NOT BE AFRAID. WHAT CAN MAN DO TO ME?" 

KJV -

So that we may boldly say, The Lord is my helper, and I will not fear what man shall do unto me.

MKJV - 

So that we may boldly say, "The Lord is my helper, and I will not fear what man shall do to me."

EDIT -

SO THAT WE MAY BOLDLY SAY, THE LORD IS MY HELPER, I WILL NOT FEAR WHAT MAN SHALL DO UNTO ME.




PSALM 71:5 - 

BA -

FOR YOU HAVE BEEN MY HOPE, O SOVEREIGN LORD, MY CONFIDENCE SINCE MY YOUTH.

MKJV - 

For You are my hope, O Lord God, my trust from my youth.�

EDIT -

FOR YOU ARE MY HOPE, O LORD GOD, MY TRUST FROM MY YOUTH.




EXODUS 19:4 -

BA - 

YOU YOURSELVES HAVE SEEN WHAT I DID UNTO THE EGYPTIANS, AND HOW I BARE YOU ON EAGLES' WINGS, AND BROUGHT YOU UNTO MYSELF.

MKJV -

You have seen what I did to the Egyptians, and I bore you on eagles' wings and brought you to Myself.

EDIT - 

YOU HAVE SEEN WHAT I DID TO THE EGYPTIANS, AND I BORE YOU ON EAGLES' WINGS AND BROUGHT YOU TO MYSELF.�




MATTHEW 24:13 -

BA -

BUT HE WHO STANDS FIRM TO THE END WILL BE SAVED.

KJV -

But he that shall endure unto the end, the same shall be saved.

MKJV - 

But he who endures to the end, the same shall be kept safe.

EDIT - 

BUT HE WHO ENDURES TO THE END SHALL BE SAVED.




PROV. 4:14 -

BA - 

DO NOT SET FOOT ON THE PATH OF THE WICKED OR WALK IN THE WAY OF EVIL MEN.

MKJV -

Enter not into the path of the wicked, and go not into the way of evil.

EDIT -

ENTER NOT INTO THE PATH OF THE WICKED, AND GO NOT INTO THE WAY OF EVIL.





GENESIS 6:12-19 (ORIGINALLY IN BA AS "GENESIS 12-14,17,19") -

BA - ** ADD CHAPTER NUMBER TO THE ORIGINAL TEXT ** 

GOD SAW HOW CORRUPT THE EARTH HAD BECOME ... AND SAID TO NOAH, "I AM GOING TO PUT AN END TO ALL THE PEOPLE, ... I AM SURELY GOING TO DESTROY BOTH THEM AND THE EARTH.  SO MAKE YOURSELF AN ARK ... I AM GOING TO BRING FLOODWATERS ON THE EARTH ... YOU ARE TO BRING INTO THE ARK TWO OF ALL LIVING CREATURES, MALE AND FEMALE ..."

MKJV - ** USING GENESIS 6:12-14,17,19 AS REFERENCE **

And God looked upon the earth. And, behold, it was corrupted! For all flesh had corrupted its way upon the earth.�
And God said to Noah, The end of all flesh has come before Me, for the earth is filled with violence through them. And, behold, I will destroy them with the earth.�Make an ark of cyprus timbers. You shall make rooms in the ark. And you shall pitch it inside and outside with pitch.�And this is the way you shall make it. The length of the ark shall be three hundred cubits, the breadth of it shall be fifty cubits and its height thirty cubits.�You shall make a window in the ark, and you shall finish it above to a cubit. And you shall set the door of the ark in the side of it. You shall make it with lower, second and third stories.�And behold! I, even I, am bringing a flood of waters upon the earth in order to destroy all flesh (in which is the breath of life) from under the heavens. Everything which is in the earth shall die.�But I will establish My covenant with you. And you shall come into the ark, you and your sons and your wife and your sons' wives with you.�And you shall bring into the ark two of every kind, of every living thing of all flesh, to keep them alive with you. They shall be male and female.�

EDIT - 

AND GOD LOOKED UPON THE EARTH. AND, BEHOLD, IT WAS CORRUPTED! AND GOD SAID TO NOAH... "THE EARTH IS FILLED WITH VIOLENCE... BEHOLD, I 
WILL DESTROY THEM WITH THE EARTH... MAKE AN ARK... AND YOU SHALL BRING INTO THE ARK TWO OF EVERY KIND, OF EVERY LIVING THING OF ALL 
FLESH... MALE AND FEMALE."




EXODUS 1:8,13,14 (IN PLACE OF BABY MOSES' STORY IN EXODUS 1:22,2:1-3)

BA (ORIGINAL INTRO TEXT - EXODUS 1:22,2:1-3) -

... PHARAOH GAVE THIS ORDER TO ALL HIS PEOPLE: "EVERY BOY THAT IS BORN YOU MUST THROW INTO THE NILE, BUT LET EVERY GIRL LIVE." ... A MAN OF THE HOUSE OF LEVI MARRIED A LEVITE WOMAN, AND SHE BECAME PREGNANT AND GAVE BIRTH TO A SON. WHEN SHE SAW THAT HE WAS A FINE 
CHILD, SHE HID HIM FOR THREE MONTHS. BUT WHEN SHE COULD HIDE HIM NO LONGER, SHE GOT A PAPYRUS BASKET FOR HIM ... AND PLACED THE CHILD IN IT AND PUT IT ... ALONG THE BANK OF THE NILE.

MKJV ("HARD LABOR" STORYLINE - EXODUS 1:8,13,14) -

And there arose a new king over Egypt, who did not know Joseph. And the Egyptians made the sons of Israel serve with harshness.�And they made their lives bitter with hard work in mortar and in bricks, and in all kinds of work in the field; all their work in which they made them do was with harshness.�

EDIT -

AND THERE AROSE A NEW KING OVER EGYPT, WHO DID NOT KNOW JOSEPH. AND THE EGYPTIANS MADE THE SONS OF ISRAEL SERVE WITH HARSHNESS. AND THEY MADE THEIR LIVES BITTER WITH HARD WORK IN MORTAR AND IN BRICKS, AND IN ALL KINDS OF WORK IN THE FIELD; ALL THEIR WORK IN WHICH 
THEY MADE THEM DO WAS WITH HARSHNESS.

***ADDED GAME OBJECTIVE***

"BRING THE BRICKS TO THE RIGHT SIDE OF THE LEVEL."

***IF ONE FORGETS THE BRICKS...***

"YOU FORGOT THE BRICKS!"




I SAMUEL 17:32-35

BA -

DAVID SAID TO SAUL, "LET NO ONE LOSE HEART ON ACCOUNT OF THIS PHILISTINE; YOUR SERVANT WILL GO AND FIGHT HIM." SAUL REPLIED, "YOU ARE NOT ABLE TO ... FIGHT HIM; YOU ARE ONLY A BOY, AND HE HAS BEEN A FIGHTING MAN FROM HIS YOUTH." BUT DAVID SAID TO SAUL, "YOUR SERVANT HAS BEEN KEEPING HIS FATHER'S SHEEP. WHEN A LION OR A BEAR CAME ... I WENT AFTER IT, STRUCK IT AND RESCUED THE SHEEP ..."

MKJV -

And David said to Saul, Let no man's heart fail because of him. Your servant will go and fight with this Philistine.�
And Saul said to David, You are not able to go against this Philistine to fight with him. For you are but a youth, and he is a man of war from his youth. And David said to Saul, Your servant kept his father's sheep, and there came a lion and a bear, and took a lamb out of the flock.�And I went out after it and struck it, and delivered the lamb out of its mouth. And when it rose against me, I caught it by the beard, and struck it and killed it.�

EDIT - 

AND DAVID SAID TO SAUL, "[I] WILL GO AND FIGHT WITH THIS PHILISTINE." SAUL SAID, "YOU ARE NOT ABLE TO GO AGAINST THIS PHILISTINE... YOU ARE BUT A YOUTH, AND HE IS A MAN OF WAR FROM HIS YOUTH." AND DAVID SAID TO SAUL, "YOUR SERVANT KEPT HIS FATHER'S SHEEP... [A LION] 
TOOK A LAMB OUT OF THE FLOCK. I WENT AFTER IT AND STRUCK IT, AND DELIVERED THE LAMB OUT OF ITS MOUTH..."




BA (NARRATIVE FROM "NOAH'S ARK" GAMEPLAY) -

"PLENTY OF FOOD IS NEEDED FOR THE LONG JOURNEY..."

EDIT -

"NOAH NEEDS PLENTY OF FOOD FOR THE ANIMALS...."




BA (NARRATIVE FOR THE ENDING OF "NOAH'S ARK" - NO BIBLE REFERENCE WAS USED) - 

HAVING GATHERED ALL THAT WAS REQUESTED OF HIM, NOAH AND HIS FAMILY WERE SEALED IN THE ARK BY GOD. THE EARTH WAS FLOODED AND ALL 
LIVING THINGS DIED. NOAH AND THOSE WITH HIM CAME OUT WHEN THE SURFACE OF THE GROUND WAS DRY.

MKJV (GENESIS 8:4,5;9:8,15) -

And in the seventh month, on the seventeenth day of the month, the ark rested upon the mountains of Ararat.�
And the waters decreased continually until the tenth month. And the tops of the mountains were seen in the tenth month on the first day of the month. And God spoke to Noah, and to his sons with him, saying, And I will remember My covenant which is between Me and you and every living creature of all flesh; and the waters shall no more become a flood to destroy all flesh.�

EDIT (GENESIS 8:4,5;9:8,15) - 

THE ARK RESTED UPON THE MOUNTAINS OF ARAFAT. AND THE WATERS DECREASED CONTINUALLY... AND GOD SPOKE TO NOAH... "THE WATERS SHALL NO MORE BECOME A FLOOD TO DESTROY ALL FLESH."





PROV 14:32 -

BA - 

WHEN CALAMITY COMES, THE WICKED ARE BROUGHT DOWN, BUT EVEN IN DEATH THE RIGHTEOUS HAVE A REFUGE.

MKJV -

The wicked is driven away in his wickedness, but the righteous has hope in his death.

EDIT -

THE WICKED IS DRIVEN AWAY IN HIS WICKEDNESS, BUT THE RIGHTEOUS HAS HOPE IN HIS DEATH.
�