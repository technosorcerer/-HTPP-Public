        The Bard's Tale - Tales of the Unknown 
              Famicom version

             Bracers 6 Fix
          Version 1.0, January 19 2024


__________

     General Info:


This patch is for the Japanese Famicom version of
The Bard's Tale - Tales of the Unknown.


The equipment "Bracers6" only offered 4 defense points, 
therefore making it identical to "Bracers4". 
Everything indicates that there is an oversight and that
"Bracers6" should give 6 defense points. 
This patch remedies this and gives it 6 defense points.

The patch is also compatible with the English translation 
of the game I released, but not with the official US
version. Who would still want to play that version anyway?!
Don't ask me to make one for it, I won't.


__________

     Patching:

Using a patching tool such as Lunar IPS, patch the rom:
Bard's Tale, The - Tales of the Unknown (J).nes

__________

     Credits:

Hacking: Ness aka MetHy
