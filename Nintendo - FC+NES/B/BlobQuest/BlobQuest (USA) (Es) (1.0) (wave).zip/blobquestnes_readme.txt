BlobQuest (NES)
Traducción al Español v1.0 (17/04/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
BlobQuest.nes
MD5: 024745233ae04b536bd461bf03ca55bd
SHA1: eb815d83679571cc6f86de6b457877b80dba61b1
CRC32: e3ac2b6d
32784 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --