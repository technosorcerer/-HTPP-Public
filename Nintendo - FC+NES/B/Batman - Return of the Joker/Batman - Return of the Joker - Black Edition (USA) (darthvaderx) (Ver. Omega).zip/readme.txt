--------------------------------------------------------------------------
Batman - Return Of The Joker Black Edition Ver. Omega by DarthVaderX
--------------------------------------------------------------------------
Just like in the first game, this hack also combines various elements from other hacks and graphical edits to deliver a unique experience:

    Title Screen Graphics Edited.
    Palette Hack ver.1.0 by Devilfox: Modifies the color palette of the character sprite and cutscenes to give them a darker tone.
    Movement Hack ver.1.0 by omega_rugal: This hack reduces the delay the character experiences when starting to walk and also reduces the slippery controls.. Reduced delay when starting the walking animation.

    . Batman stops sliding earlier.

    . No longer gets stunned when hit.

A huge thank-you to SATY for their invaluable help.

Box Art by Antonio de Lima.

To be applied on the Batman - Return Of The Joker (U) [!] or Batman - Return Of The Joker (USA) ROM.
--------------------------------------------------------------------------
Bonus:
--------------------------------------------------------------------------
Level Passwords

    Level 1-2: MDRR
    Level 2-1: NMLL
    Level 2-2: NWKL
    Level 3-1: LGZQ
    Level 3-2: GPTW
    Level 4-1: GNXF
    Level 4-2: KHCN
    Level 5-1: QGVN
    Level 5-2: WBZT
    Level 6-1: FFHG
    Level 6-2: CKQG
    Level 7-1: GPZT
--------------------------------------------------------------------------