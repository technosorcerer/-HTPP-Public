Batman Returns (NES)
Traducción al Español v2.0 (27/02/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Añadidos acentos
-Traducido título
-Traducidos créditos
-Revisión de script
-Traducido STAGE

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Batman Returns (USA).nes
MD5: 1fe9c970c5c04aec359a833820718e6a
SHA1: 43a0fee6878cdf35288395524923cb8c61e6974a
CRC32: e625e398
393232 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --