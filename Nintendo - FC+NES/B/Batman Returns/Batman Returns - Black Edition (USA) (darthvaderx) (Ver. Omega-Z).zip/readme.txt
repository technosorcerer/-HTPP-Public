Batman Returns: Black Edition Ver. Omega-Z by DarthVaderX

With this release, we conclude the “Black Edition” trilogy of Batman games for the NES. Like the others, this hack combines various elements from other hacks and graphical edits to deliver a unique experience.
Features

This hack incorporates the following base modifications:
Anti-Antipiracy Hack v1.0 by MetHy:

This hack removes the numerous and particularly nasty copy control mechanisms in the game. It ensures that other ROM hackers can use this as a base, allowing title screen modifications without fear of triggering the game’s copy protection.

The original copy protection could:

    Double the damage dealt to the player.
    Prevent progress by keeping the exit of stage 3-1 closed, causing the stage to loop endlessly.
    Generate invalid passwords.
    Block valid passwords from working.

A total of seven pieces of code related to copy protection were disabled.
Bugfix & Hard Mode Hack v1.0 by MetHy:

This hack provides several bug fixes and polish, along with an optional Hard Mode.

Bug fixes and improvements include:

    Added Batman’s missing face sprite in three animations.
    Enhancements to the HUD (I also made a small modification to it).
    Pixel improvements on Batman and a few bosses.
    Corrected the wrong palette used for the motorcycle enemy in stage 3-2.

The Hard Mode, originally part of the copy protection, was turned into an actual feature. It doubles all damage dealt to the player. To activate it, press “SELECT” on the “START – PASSWORD” screen. The bat cursor will turn red, and a sound will confirm activation.
Improved Controls Hack v1.0 by MetHy:

A simple 5-byte hack that makes the controls less stiff:

    Reduced the delay between pressing the punch button and executing a punch.
    Slightly reduced the delay before you can punch again after completing a combo or single punch.
    Enabled turning around while holding the punch button.
    Slightly reduced the delay before movement resumes after landing from a jump kick.
    Slightly reduced the delay before movement resumes after using the A+B special, making it more viable.

Additional Edits by DarthVaderX:

    New title screens.
    Updated colors for Batman’s sprites, the Batmobile, some enemies, items, the HUD, several stages, and cutscenes to reflect the “dark” atmosphere of this version.
    With two patch options.

        Batman Returns Black Edition: The Original hack.
        Batman Returns Turbo Edition: The same as the Black Edition, but with Batman moving much faster.

    Each version is distinguishable by its unique title screen.

_________________________________________________________________________
Special Thanks

A huge thank-you to SATY for their invaluable help. Without their assistance, I wouldn’t have been able to finish this hack the way I envisioned. I hope you enjoy the final result—it was a lot of work, but worth it!

And the wonderful box art done by Antonio de Lima

_________________________________________________________________________

Note: It is recommended to use the MESEN emulator to get a real view of the game's colors, such as Batman's sprite and its true shades of gray, among others.

To be applied on the Batman Returns (U) [!] or Batman Returns (USA) ROM.

_________________________________________________________________________

Bonuses:

Cheats:

Extra Batarangs:
Between levels and during a cutscene, hold Start on Controller 1 and A+B on Controller 2 altogether and press Select on Controller 1. This will skip the cutscene or you can wait until the cutscene ends. If done right, you'll begin with 10 Batarangs on the next stage. This will not work for the scene prior to the first stage.

View Ending Again:
After beating the game and watching the ending, while the copyright screen appears, press Left, A, and B on Player 2's controller to see the ending a second time.

Unlockables:

    Endings
    In this game, you'll find that your health - specifically how often you're hit and how many times you die - determine the ending. Taking hits and dying adds points to a counter:
    - a hit basic enemies: +8
    - a hit from middle grade enemies: +12, +16, +18 or +24
    - a hit from bosses (Penguin excluded): +48
    - a hit from Penguin (both boss fights): +80
    - dying: +1,024 (overwhelmingly the greater influence).

    Basically, outside of dying, the points added to the counter are proportional to damage recieved.

    When you finish the final stage, depending on the values of this counter, you will get a different ending.<p />

    The estimates in regards to number of deaths are merely estimates, as taking a certain number of hits is still equivalent to a loss of life.
    Unlockable	How to Unlock
    Ending #1 - Worst	Counter is above 14,848 (equivalent to dying about 15 times)
    Ending #2 - Bad	Counter is between 9,984 to 14,848 (equivalent to dying 10-14 times)
    Ending #3 - Good	Counter is between 5,376 to 9,984 (equivalent to 6-9 deaths)
    Ending #4 - Best	Counter is less than 5,376 (equivalent to dying 5 or less times)
    
Easter Eggs:

    Credits Easter Egg
    Hold START during the credits to see either the strongman boss spin across the bottom of the screen.
    If you got the good endings, it will be Catwoman running accross the bottom of the screen instead.
 
Secrets:

    Life boxes:
    There are at least two additional life boxes you can acquire through the game.
    The first one is located in Stage 3-1: in the second room that you can enter through the window, the one where you fight the two green enemies wielding pitchforks, use the grappling gun on the chandelier and a life box should fall     down. You need to make sure that both enemies are dead before hitting the chandelier, if they're still alive a big heart will spawn instead of a life box.

    The second one is located just before the final boss fight. At the end of the scroll, an item will spawn. The type of item that spawns depends on how your score ends:

    00: Batarang
    10: Small Heart
    20: Life Box
    30: Big Heart
    40: Big Heart
    50: Small Heart
    60: Batarang
    70: Life Box
    80: Big Heart
    90: Big Heart

    Just before the item will spawn, you will fight two of the most basic enemies. You can manipulate the score against them in order to try and make sure you get a life box: depending on whether or not you damage enemies with the last punch of a combo, the score outcome will be different.
    The maximum number of Life Boxes you can have is 3.
 
    Test Tube:
    In stage 2-2, you can acquire a test tube which will diminish Catwoman's HP during the bossfight against her. Here is how to get it:
    At some point during the stage, you will see big cat heads near the top of the screen. Using the grappling hook on the cats' eyes will spawn items:
    - the first cat spawns nothing
    - the second cat spawns a small heart
    - the third cat either spawns a big heart, or the test tube
    In order to make sure that the third cat spawns the test tube, you have to kill the two red enemies wielding pitchforks first. If you use the grappling hook on the cat's eye before killing the two enemies, it will spawn the big heart instead.
 
--------------------------------------------------------------------------

    Level Passwords:
    
    1-1	= Y433 43 53B3 73
    1-1 (w/ an extra life bar) = 1111-11-1111-1*
    1-1 (w/ Invincibility)     = 1995 14 BBBB 51
    2-1	                       = D957 65 849B 55
    2-2	                       = 5958 65 8Y1B Z9
    2-2                        = ZD7! 87 XX9X 28
    3-1	                       = X95! 65 BB51 66
    3-1 (w/ Invincibility)     = 199! 14 BBBB 18
    3-2                        = 2D7D XZ Y76B 9!
    3-2                        = 8117 61 77D3 23
    4-1	                       = 1D7Z X7 Y!52 X9
    4-2	                       = 2D7* X7 Y966 *9
    5-1 (w/ Invincibility)     = 199* 14 BBBB 89
    6-1 (w/ Invincibility)     = 1992 14 BBBB 21
    6-2 (w/ Invincibility)     = 1993 14 BBBB 64
    

    Maxed Passwords:
    The passwords below will allow you to reach the named stage. All passwords will make you have the maximum number of health boxes and health, and all will give you the test tube item from partway through the game. Each password will also bring you within the conditions for a certain ending based on your hit/death count (see the "Unlockables" for more): your damage is minimized to keep it as easy as possible to obtain that ending. You will also be able to use a "Level Select" debug cheat: press Left or Right on Controller 2 to go up levels as high as 4-2.
    Certain passwords - they are noted - will also enable invulnerability. Do not use those passwords if you intend to keep a semblance the challenge of the real game. This was also a debug-only function.
    
    (Not Invulnerable) Bad Ending - Stage 1-1   	4331 41 *1*8 D3
    (Not Invulnerable) Bad Ending - Stage 1-2	        4332 41 *1*8 Y3
    (Not Invulnerable) Bad Ending - Stage 2-1   	4333 41 *1*8 Z3
    (Not Invulnerable) Bad Ending - Stage 2-2   	4334 41 *1*8 *3
    (Not Invulnerable) Bad Ending - Stage 2-3   	4335 41 *1*8 13
    (Not Invulnerable) Bad Ending - Stage 3-1   	4336 41 *1*8 23
    (Not Invulnerable) Bad Ending - Stage 3-2   	4337 41 *1*8 33
    (Not Invulnerable) Bad Ending - Stage 3-3   	4338 41 *1*8 43
    (Not Invulnerable) Bad Ending - Stage 4-1   	4339 41 *1*8 53
    (Not Invulnerable) Bad Ending - Stage 4-2   	433! 41 *1*8 63
    (Not Invulnerable) Bad Ending - Stage 4-3   	433B 41 *1*8 73
    (Not Invulnerable) Bad Ending - Stage 5-1   	433X 41 *1*8 83
    (Not Invulnerable) Bad Ending - Stage 5-2   	433D 41 *1*8 93
    (Not Invulnerable) Bad Ending - Stage 6-1	        433Y 41 *1*8 !3
    (Not Invulnerable) Bad Ending - Stage 6-2	        433Z 41 *1*8 B3
    (Not Invulnerable) Best Ending - Stage 1-1  	4331 41 *1*1 41
    (Not Invulnerable) Best Ending - Stage 1-2  	4332 41 *1*1 51
    (Not Invulnerable) Best Ending - Stage 2-1  	4333 41 *1*1 61
    (Not Invulnerable) Best Ending - Stage 2-2  	4334 41 *1*1 71
    (Not Invulnerable) Best Ending - Stage 2-3	        4335 41 *1*1 81
    (Not Invulnerable) Best Ending - Stage 3-1	        4336 41 *1*1 91
    (Not Invulnerable) Best Ending - Stage 3-2	        4337 41 *1*1 !1
    (Not Invulnerable) Best Ending - Stage 3-3	        4338 41 *1*1 B1
    (Not Invulnerable) Best Ending - Stage 4-1  	4339 41 *1*1 X1
    (Not Invulnerable) Best Ending - Stage 4-2  	433! 41 *1*1 D1
    (Not Invulnerable) Best Ending - Stage 4-3   	433B 41 *1*1 Y1
    (Not Invulnerable) Best Ending - Stage 5-1	        433X 41 *1*1 Z1
    (Not Invulnerable) Best Ending - Stage 5-2	        433D 41 *1*1 *1
    (Not Invulnerable) Best Ending - Stage 6-1	        433Y 41 *1*1 11
    (Not Invulnerable) Best Ending - Stage 6-2	        433Z 41 *1*1 21
    (Not Invulnerable) Good Ending - Stage 1-1	        4331 49 *7*7 92
    (Not Invulnerable) Good Ending - Stage 1-2	        4332 49 *7*7 !2
    (Not Invulnerable) Good Ending - Stage 2-1	        4333 49 *7*7 B2
    (Not Invulnerable) Good Ending - Stage 2-2	        4334 49 *7*7 X2
    (Not Invulnerable) Good Ending - Stage 2-3	        4335 49 *7*7 D2
    (Not Invulnerable) Good Ending - Stage 3-1	        4336 49 *7*7 Y2
    (Not Invulnerable) Good Ending - Stage 3-2  	4337 49 *7*7 Z2
    (Not Invulnerable) Good Ending - Stage 3-3	        4338 49 *7*7 *2
    (Not Invulnerable) Good Ending - Stage 4-1	        4339 49 *7*7 12
    (Not Invulnerable) Good Ending - Stage 4-2	        433! 49 *7*7 22
    (Not Invulnerable) Good Ending - Stage 4-3	        433B 49 *7*7 32
    (Not Invulnerable) Good Ending - Stage 5-1	        433X 49 *7*7 42
    (Not Invulnerable) Good Ending - Stage 5-2	        433D 49 *7*7 52
    (Not Invulnerable) Good Ending - Stage 6-1	        433Y 49 *7*7 62
    (Not Invulnerable) Good Ending - Stage 6-2	        433Z 49 *7*7 72
    (Not Invulnerable) Worst Ending - Stage 1-1 	4331 4* **** **
    (Not Invulnerable) Worst Ending - Stage 1-2	        4332 4* **** 1*
    (Not Invulnerable) Worst Ending - Stage 2-1 	4333 4* **** 2*
    (Not Invulnerable) Worst Ending - Stage 2-2	        4334 4* **** 3*
    (Not Invulnerable) Worst Ending - Stage 2-3 	4335 4* **** 4*
    (Not Invulnerable) Worst Ending - Stage 3-1 	4336 4* **** 5*
    (Not Invulnerable) Worst Ending - Stage 3-2  	4337 4* **** 6*
    (Not Invulnerable) Worst Ending - Stage 3-3	        4338 4* **** 7*
    (Not Invulnerable) Worst Ending - Stage 4-1	        4339 4* **** 8*
    (Not Invulnerable) Worst Ending - Stage 4-2	        433! 4* **** 9*
    (Not Invulnerable) Worst Ending - Stage 4-3	        433B 4* **** !*
    (Not Invulnerable) Worst Ending - Stage 5-1	        433X 4* **** B*
    (Not Invulnerable) Worst Ending - Stage 5-2	        433D 4* **** X*
    (Not Invulnerable) Worst Ending - Stage 6-1	        433Y 4* **** D*
    (Not Invulnerable) Worst Ending - Stage 6-2  	433Z 4* **** Y*
    (With Invulnerability) Bad Ending - Stage 1-1	X331 X1 *1*8 D3
    (With Invulnerability) Bad Ending - Stage 1-2	X332 X1 *1*8 Y3
    (With Invulnerability) Bad Ending - Stage 2-1	X333 X1 *1*8 Z3
    (With Invulnerability) Bad Ending - Stage 2-2	X334 X1 *1*8 *3
    (With Invulnerability) Bad Ending - Stage 2-3	X335 X1 *1*8 13
    (With Invulnerability) Bad Ending - Stage 3-1	X336 X1 *1*8 23
    (With Invulnerability) Bad Ending - Stage 3-2	X337 X1 *1*8 33
    (With Invulnerability) Bad Ending - Stage 3-3	X338 X1 *1*8 43
    (With Invulnerability) Bad Ending - Stage 4-1	X339 X1 *1*8 53
    (With Invulnerability) Bad Ending - Stage 4-2	X33! X1 *1*8 63
    (With Invulnerability) Bad Ending - Stage 4-3	X33B X1 *1*8 73
    (With Invulnerability) Bad Ending - Stage 5-1	X33X X1 *1*8 83
    (With Invulnerability) Bad Ending - Stage 5-2	X33D X1 *1*8 93
    (With Invulnerability) Bad Ending - Stage 5-2	X33Z X1 *1*8 B3
    (With Invulnerability) Bad Ending - Stage 6-1	X33Y X1 *1*8 !3
    (With Invulnerability) Best Ending - Stage 1-1	X331 X1 *1*1 41
    (With Invulnerability) Best Ending - Stage 1-2	X332 X1 *1*1 51
    (With Invulnerability) Best Ending - Stage 2-1	X333 X1 *1*1 61
    (With Invulnerability) Best Ending - Stage 2-2	X334 X1 *1*1 71
    (With Invulnerability) Best Ending - Stage 2-3	X335 X1 *1*1 81
    (With Invulnerability) Best Ending - Stage 3-1	X336 X1 *1*1 91
    (With Invulnerability) Best Ending - Stage 3-2	X337 X1 *1*1 !1
    (With Invulnerability) Best Ending - Stage 3-3	X338 X1 *1*1 B1
    (With Invulnerability) Best Ending - Stage 4-1	X339 X1 *1*1 X1
    (With Invulnerability) Best Ending - Stage 4-2	X33! X1 *1*1 D1
    (With Invulnerability) Best Ending - Stage 4-3	X33B X1 *1*1 Y1
    (With Invulnerability) Best Ending - Stage 5-1	X33X X1 *1*1 Z1
    (With Invulnerability) Best Ending - Stage 5-2	X33D X1 *1*1 *1
    (With Invulnerability) Best Ending - Stage 6-1	X33Y X1 *1*1 11
    (With Invulnerability) Best Ending - Stage 6-2	X33Z X1 *1*1 21
    (With Invulnerability) Good Ending - Stage 1-1	X331 X9 *7*7 92
    (With Invulnerability) Good Ending - Stage 1-2	X332 X9 *7*7 !2
    (With Invulnerability) Good Ending - Stage 2-1	X333 X9 *7*7 B2
    (With Invulnerability) Good Ending - Stage 2-2	X334 X9 *7*7 X2
    (With Invulnerability) Good Ending - Stage 2-3	X335 X9 *7*7 D2
    (With Invulnerability) Good Ending - Stage 3-1	X336 X9 *7*7 Y2
    (With Invulnerability) Good Ending - Stage 3-2	X337 X9 *7*7 Z2
    (With Invulnerability) Good Ending - Stage 3-3	X338 X9 *7*7 *2
    (With Invulnerability) Good Ending - Stage 4-1	X339 X9 *7*7 12
    (With Invulnerability) Good Ending - Stage 4-2	X33! X9 *7*7 22
    (With Invulnerability) Good Ending - Stage 4-3	X33B X9 *7*7 32
    (With Invulnerability) Good Ending - Stage 5-1	X33X X9 *7*7 42
    (With Invulnerability) Good Ending - Stage 5-2	X33D X9 *7*7 52
    (With Invulnerability) Good Ending - Stage 6-1	X33Y X9 *7*7 62
    (With Invulnerability) Good Ending - Stage 6-2	X33Z X9 *7*7 72
    (With Invulnerability) Worst Ending - Stage 1-1	X331 X* **** **
    (With Invulnerability) Worst Ending - Stage 1-2	X332 X* **** 1*
    (With Invulnerability) Worst Ending - Stage 2-1	X333 X* **** 2*
    (With Invulnerability) Worst Ending - Stage 2-2	X334 X* **** 3*
    (With Invulnerability) Worst Ending - Stage 2-3	X335 X* **** 4*
    (With Invulnerability) Worst Ending - Stage 3-1	X336 X* **** 5*
    (With Invulnerability) Worst Ending - Stage 3-2	X337 X* **** 6*
    (With Invulnerability) Worst Ending - Stage 3-3	X338 X* **** 7*
    (With Invulnerability) Worst Ending - Stage 4-1	X339 X* **** 8*
    (With Invulnerability) Worst Ending - Stage 4-2	X33! X* **** 9*
    (With Invulnerability) Worst Ending - Stage 4-3	X33B X* **** !*
    (With Invulnerability) Worst Ending - Stage 5-1	X33X X* **** B*
    (With Invulnerability) Worst Ending - Stage 5-2	X33D X* **** X*
    (With Invulnerability) Worst Ending - Stage 6-1	X33Y X* **** D*
    (With Invulnerability) Worst Ending - Stage 6-2	X33Z X* **** Y*

--------------------------------------------------------------------------

Game Genie Codes:

Infinite Health                           = SZEGLVSE
Invincible                                = AAEXANAA
                                            AAEXZNAG   
Hearts Worth Double the Amount of Health  = AXSAPPAP
One Hit Kills                             = GZOZIZEL
Infinite Batarangs                        = SXSKGKVK

