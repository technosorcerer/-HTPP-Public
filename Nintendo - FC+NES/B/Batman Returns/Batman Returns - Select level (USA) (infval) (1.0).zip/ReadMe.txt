﻿--------------------------Info---------------------------
Game name: Batman Returns
Console: Sega Genesis
Game region WORLD: (W)
Patch: SP (Solid patch)
Patcher: Solid patcher
Patcher download link:
 Windows: https://romhackplaza.org/utilities/solid-patcher-utility/
 Linux: https://romhackplaza.org/utilities/solid-patcher-utility-2/
 https://rgcorp.ucoz.net/load/console_soft/solid_patcher/2-1-0-97
----------------------------------------------------------
--------------------------patch------------------------
The patch adds the following change:

 Start the level select menu.
 *Select the "Options" menu item, hold RIGHT button and pressing START.

----------------------------------------------------------
Author by: infval