Bad Dudes Facelift (NES)

Hacked by Andrei Vdovin a.k.a. Chronix
Email me if you find any glitches in my hack.
Thanks in advance!
chronix@bk.ru

Changes:

* Minor facelift (title screen, fonts, sprites, etc.)
* Blade and Striker have different palettes
* Buttons swapped (B-punch, A-jump)

Original ROM:
-----------------------
Bad Dudes (U) [!].nes
File size: 262 160

 PRG ROM:    8 x 16KiB
 CHR ROM:   16 x  8KiB
 ROM CRC32:  0x161d717b
 ROM MD5:  0xb30a3f09b86f3adab09a36bfe674544c
 Mapper #:  4
 Mapper name: MMC3
 Mirroring: Horizontal
 Battery-backed: No
 Trained: No
