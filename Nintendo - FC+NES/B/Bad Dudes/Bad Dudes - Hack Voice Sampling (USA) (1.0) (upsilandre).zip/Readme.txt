-------------------------------------
 Bad Dudes - NES Hack Voice Sampling
-------------------------------------

Release By: upsilandre
Release Date: 2022-06-19 (v1.0)

ROM to patch (No-Intro):
Database: Nintendo - Nintendo Entertainment System (Headered) (v.20220620-100820)
ROM name: Bad Dudes (USA).nes
ROM CRC-32 : ada49341
ROM MD5 : 1c1e436fcd3d53408764a83d4b08f98c
ROM SHA-1: 26e184e350f50bfa06038379a84f3b685b7509b8
ROM SHA-256: 1286ed51643a4627e7b6f389be1d589827b94d626df569c7044e607b8eeacc3c

ROM to patch (GoodSet):
Database: GoodNES
ROM name: Bad Dudes (U) [!].nes
ROM CRC-32: 3c8e79e9
ROM MD5: e5f71b547f6a8c6166c55b1baa7d21c5
ROM SHA-1: f19ededc60d3925b75bae71b72448757fd59c3db
ROM SHA-256: ad0ba0b8b4f6dc25d0244cf649a1a60e240c86218e4069dd40a3beff04fd9860

FR :
Lors du portage de ces 2 jeux NES Data East, ils ont fait l'effort de préserver un peu du voice sampling de la version arcade (un seul sample chacun) mais en le faisant très mal.
Je me suis donc amusé à trouver, décoder et extraire les samples originaux de la version arcade de la ROM de ces jeux pour ensuite les utiliser pour améliorer les versions NES.
Il s'agit juste du sample "I'm Bad!"  dans Bad Dudes et "Heavy Barrel!" dans Heavy Barrel. Je les ai réencodés proprement pour être exploitable par la NES et en modifiant un peu le driver audio afin d'obtenir quelque chose de très proche des samples arcade. Et tout ça sans augmenter la ROM originale qui reste la même, je suis resté dans les clous de ce qui était disponible.
C'était donc quelque chose de tout à fait faisable à l'époque. La façon dont ça a été bâclé est assez surprenante (c'est pas le seul truc bâclé dans ce portage, la gestion des sprites est particulière aussi).
J'avais fait ces hacks en 2020 mais je n'avais jamais pris le temps de les partager (comme plein d'autres hack).

EN :
When porting these 2 NES Data East games, they made the effort to preserve some of the voice sampling of the arcade version (only one sample each) but they did it very badly.
So I had fun finding, decoding and extracting the original samples of the arcade version from the ROM of these games and using them to improve the NES versions.
It's just the "I'm Bad!" sample in Bad Dudes and "Heavy Barrel!" in Heavy Barrel. I re-encoded them cleanly to be usable by the NES and modified the audio driver a bit to get something very close to the arcade samples. And all this without increasing the original ROM size which remains the same, I stayed within the limits of what was available.
So it was something that was quite feasible at the time. The way it was botched is quite surprising (it's not the only botched thing in this port, the sprite management is peculiar too).
I made these hacks in 2020 but never took the time to share them (like many other hacks).


Youtube : https://www.youtube.com/watch?v=f_Ox4pqcPwk
Twitter : https://twitter.com/upsilandre/status/1538825100417540098