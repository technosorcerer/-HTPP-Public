Bad Dudes (NES)
Traducción al Español v2.0 (09/11/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Guion retraducido
-Añadidos caracteres españoles
-Pantalla de título traducida
-Traducido PRESENTS
-Traducidos STAGE CLEAR y GO TO NEXT STAGE

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bad Dudes (USA).nes
MD5: e5f71b547f6a8c6166c55b1baa7d21c5
SHA1: f19ededc60d3925b75bae71b72448757fd59c3db
CRC32: 3c8e79e9
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --