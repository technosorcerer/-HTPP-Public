Bio Senshi Dan - Increaser Tono Tatakai
Traducci�n al Espa�ol v1.2 (14/03/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Bio Senshi Dan - Increaser Tono Tatakai
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Bio Senshi Dan - Increaser Tono Tatakai
-----------------
Curioso plataformas/aventura sobre alien�genas, un poco como el metroid.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking esta basada en la de Abstract Crouton Productions.
V1.1: Revisi�n de los di�logos.
V1.2: Arreglo barra superior en las salas.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Bio Senshi Dan - Increaser Tono Tatakai (J) [!].nes
262.160	bytes
CRC32: 5b2d91d0
MD5: e4a79e79934d51be7d55ed9a75a4d52b
SHA1: 887d98bf5eda6edbe6b02b0a396cdc363d7c1943

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

Original:
Contributor	    Type of contribution	Listed credit
occluded hairdo	Hacking	                Translation, graphics

-- END OF README --