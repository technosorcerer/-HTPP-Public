Banana (NES)
Traducción al Español v1.0 (28/01/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Banana (Japan).nes
MD5: a0f5e9f767c156660ead8d25d0831482
SHA1: 02c1ece08c0c9655a34b058100a1005a2742ee22
CRC32: 5ac41464
49168 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.
Sensenic - Traducción del japonés.

-- FIN --