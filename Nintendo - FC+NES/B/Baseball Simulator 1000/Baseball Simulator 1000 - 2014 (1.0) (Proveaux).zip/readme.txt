addendum patch to
"Baseball Simulator 2014" by keithisgood