addendum patch to
"Baseball Simulator 2013" by keithisgood