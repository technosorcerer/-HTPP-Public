README -- Baseball Simulator 2014

hacked by keithisgood (www.keithisgood.com)

Apply "BASEBALL SIMULATOR 2014.ips" to a clean copy of "Baseball Simulator 1000.nes"

Baseball Simulator 2014 updates Baseball Simulator 1.000 with 18 MLB teams: BOS, DET, CLE, ATL, SFG, WAS, TEX, KCR, NYY, LAD, CIN, PIT, TBR, OAK, BAL, SDP, ARI and STL.
The .sav file included in this archive adds six teams into the game's edit slots: LAA, SEA, TOR, NYM, MIL and COL

All player stats from rotochamp.com and fangraphs.com, projections current as of 2014.04.23

--DISCLAIMER--
All use/distribution of Baseball Simulator 2013 is undertaken under fair use standards.
keithisgood Electronic Media assumes no liability for any malfunction, litigation, zombie invasion etc. arising from use of the BASEBALL SIMULATOR 2013.ips patch.

