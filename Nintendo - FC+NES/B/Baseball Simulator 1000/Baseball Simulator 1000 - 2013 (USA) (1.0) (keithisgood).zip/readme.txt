README -- Baseball Simulator 2013

hacked by keithisgood (keithisgood.blogspot.com)
title screen palette assist by Proveaux

apply "BASEBALL SIMULATOR 2013.ips" to a clean copy of "Baseball Simulator 1000.nes"

All player stats from rotochamp.com and fangraphs.com, projections current as of 2013.03.18

Data for 24 of the 32 MLB teams is already in the rom file. To swap one team for another, simply change the values at the locatins indicated in the "BBSIM_2013_DATA_LOACTIONS.xcf" file included in this archive.

--DISCLAIMER--
All use/distribution of Baseball Simulator 2013 is undertaken under fair use standards.
keithisgood Electronic Media assumes no liability for any malfunction, litigation, zombie invasion etc. arising from use of the BASEBALL SIMULATOR 2013.ips patch.

