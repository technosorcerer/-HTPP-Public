The Bugs Bunny Birthday Blowout (NES)
Traducci�n al Espa�ol v1.0 (19/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bugs Bunny Birthday Blowout, The (U) [!].nes
MD5: 96ae665d902eaa69c7a36979b7ef530d
SHA1: 1fa4f11f5a5b39e0f9ac4323e681a07cab9b80c9
CRC32: 38fdb7f4
262.160 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --