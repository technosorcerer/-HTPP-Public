El Bloque Magico (NES)
Traducción al Español v1.0 (30/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bloque Magico, El (Spain) (Gluk Video) (Unl).nes
MD5: 2013d7e28da250028f98ca5c5bdfb405
SHA1: a2d5976e97c43fb080328a505c1c8ad606ce1df8
CRC32: f587ef3d
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --