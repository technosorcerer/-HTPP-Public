PROYECTO BANDIT KING OF ANCIENT CHINA AL ESPAÑOL, BY ATOM TRADUCCIONES V0.9

Consola: Nintendo Entertainment System (NES)
Fecha de Lanzamiento de la Versión:27/01/24 (27 de Enero de 2024)
Estado:(Jugable, con algunos detalles no traducidos)

IMPORTANTE:
-Esta Rom, y este proyecto aún están en Modo Beta, aunque prometo traer el trabajo completo.

REQUISITOS:
-Una Rom de Bandit Kings Of Ancient China Americana (Ejemplo:Bandit Kings Of Ancient China (USA), nombre de la rom original donde se trabajó la traducción)

RESUMEN:
Bandit Kings of Ancient China, también conocido como Suikoden: Tenmei no Chikai (水滸伝・天命の誓い, Margen de Agua: Juramento del Destino) en Japón, es un videojuego de estrategia por turnos desarrollado y publicado por Koei en 1990 para Nintendo Entertainment System.

RESUMEN-GAMEPLAY:
El objetivo del juego es construir, mantener y comandar un ejército de tropas para capturar a Gao Qiu antes de la Invasión Jurchen en enero de 1127. Los jugadores poseen ciertos atributos como fuerza, destreza y sabiduría. Los jugadores también deben hacer frente a otras situaciones como los impuestos, el cuidado de las tropas, el mantenimiento y la sustitución de armas y equipo, las fuerzas de la naturaleza y el malestar y la deserción de las tropas.
Los campos de batalla se desarrollan en cuadrículas hexagonales, donde los jugadores mueven sus ejércitos por diversos terrenos para enfrentarse estratégicamente al ejército enemigo y derrotarlo. Las tropas pueden luchar con armas cuerpo a cuerpo, arcos y flechas, magia o duelos de espadas, así como prender fuego a las casillas. Cuando un jugador derrota a un ejército enemigo, tiene la opción de reclutar, encarcelar, exiliar o ejecutar a las tropas enemigas capturadas. El atacante tiene 30 días para derrotar a todas las tropas enemigas desplegadas, capturar al comandante o ser derrotado automáticamente. El juego termina en derrota para el jugador o jugadores cuando el Calendario del Juego llega a Enero de 1127.El mapa del juego muestra el imperio compuesto por 49 prefecturas.

INSTRUCCIONES:
1._Descargar el parche.
2._Descomprimirlo con algún progama como Winrar.
3._Aplicar el parche a la rom original (.nes) anteriormente dicha.
3.1._Usar en "Online Rom Patcher" de Romhacking.net o Lunar IPS.
4._Descarga el emulador a tu gusto, ¡Y a jugar!
 
Paz.

