Baby Boomer (NES)
Traducción al Español v1.0 (06/09/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Baby Boomer (Color Dreams) [!].nes
MD5: 7f1c00dbdf9dc473ea9c0063802403f8
SHA1: 3603dcdd69a12be5b8d00caa0a76cd96c1ee417c
CRC32: ed58dddd
81936 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --