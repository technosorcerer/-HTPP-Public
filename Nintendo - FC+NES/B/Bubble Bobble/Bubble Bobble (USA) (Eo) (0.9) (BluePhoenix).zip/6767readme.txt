Bubble Bobble (NES)
Traduko al Esperanto v1.0 (27/12/2022)

ENKONDUKO
---------
Ĉi tiu projekto estas Esperanta traduko de Bubble Bobble,
videoludo por la Nintendo Entertainment System. La retpaĝo
por la projekto estas

    http://github.com/tboronczyk/bubblebobble

PRISKRIBO DE LUDO
-----------------
Jen la rakonto de du malsataj brontosaŭroj, kiuj pensas nur
pri bobelbataloj. Vi kaj viaj du amikoj, la brontosaŭroj
Bab kaj Bob, estas en profunda problemo. Vi devas alfronti
tutajn batalionojn da minaculoj, blovante kaj papante
miliardojn da vezikoj. Estas freneza bankedo tra pli ol 100
niveloj de vezika ŝaŭmo. Se vi havas apetiton por amuzo...
ekblovu!

INFORMOJ PRI ROM
----------------
Vi devas posedi fizikan kopion de la kartoĉo de Bubble
Bobble. Alŝulti ROM-on de videoludo, kiun vi ne posedas,
povas esti pirateco.

Bubble Bobble (USA).nes
CRC32: 5E900522

NOTOJ
-----
La esperanta alfabeto estas uzata de la pasvorta sistemo,
kaj tiel iu ajn pasvorto, kiun vi trovas en la interreto,
ne plu funkcias en ĉi tiu traduko. Validaj pasvortoj por
niveloj 1-99 de ambaŭ facilecoj (malsuperaj kaj superaj)
estas inkluzivita. Vidu la dosieron pasvortoj.txt.

HISTORIO
--------
v1.0    27/12/2022
 - Unua eldono

KONTRIBUANTOJ
-------------
Timoteo BORONCZYK/bluephoenix
 - Tradukado, programado

Zerbie HYNSON/Terpomo11
 - Traduka konsultisto
