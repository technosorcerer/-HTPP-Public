			Bubble Bobble Arcade Edition

Overview. AKA Why I did it.

This all stems from when I was a kid and first got Bubble Bobble for the NES.
We had Christmas money from relatives and looking in Boots (a Large British
Chemist shop that, at the time sold games, incidentally they now don't) we
noticed this cutesy platformer. It wasn't cheap, about �25, but it looked 
sweet and was definitely something worth getting.  In fact it turned out to
be one of the best things I ever did, and played it non stop.   

About 18 months later, we noticed that there was a C64 version of Bubble Bobble 
on tape from a stall in the market. It cost about �3 (Hit squads budget range, 
licensed from Firebird Software) and seeing that it was at pocket money prices,
of course it had to come home with me.  
Loading it up on the old C64, took ages, and when it did load we found that it
was quite a bit different to the NES version I enjoyed (much harder for starters)
and couldn't work out why the levels were changed.  

Gone were the ones in the shape of the characters, gone were absolute horrors
like Level 43 and 57 and gone was the forgiving gameplay of the NES version,
and its generous provision of extra lives (though you did start with 8 credits).
It wasn't until a family holiday to Cornwall that we found out that this
is how Bubble Bobble actually plays and that it was the NES version has a lot 
changed to it.

I forgot all about this and it wasn't until much later when a stray post
on the Forums at Romhacking.net asking for ideas for game hacking for those
with no skills at all.  Initially, my main idea was to add the levels
from Bubble Bobble Neo to the NES version but seeing as the main game is just a
better looking version of the arcade game, we decided to look and see what had
been changed in the NES version and add it back if it was truly possible.     

Looking on RHDN they had a few level editors where the truly unskilled like
me can with a bit of poking make their own levels.  Downloading a few of these
I soon got to grips with editing the level data and moving stuff around.

So after 4 weeks hard work and beta testing I give you..

Bubble Bobble Arcade edition.



Whats in it.

Most of the levels have had there colours tweaked so that they resemble
its arcade parent more closely, of course where they were completely
different they've been changed to fit.    

Bubble Sprites are now filled instead of being clear, its harder to
enter passwords now but shame we're not changing them back.

Enemy and item placements now match their arcade parents, unless they
glitch the game, then they've been changed to the nearest appropriate 
type*.

New secret road levels. 
Routes A0-B2 are all new, incidentally some of the levels here were based 
on the arcade levels, we even added back the dreaded level 57 minus its
invader sprites.

Stuff not Implemented. 

Most of the bonus point scoring is off in the NES version, unless enemies
are hit by a special object or special balloon, or are bubbled enemies then
all bonuses are between 100 - 900 points.

The bonus rooms.  Level 99 is the only place where the door appears in 
the NES version. Not dying until you reach Levels 20,40 or 50 will do 
nothing in the NES version, where as in the arcade version will actually
gain you access to secret rooms.  To be fair though you get an extra 12 levels
in the NES version and Super Bubble Bobble mode which of course you don't
get in the Arcade version.


Patching.

Grab your favourite patching tool and AS LONG AS ITS NOT THE FDS VERSION
you can patch it without problems.  

Credits.

A big thanks to all at RHDN for their support and tools.
A major thanks for AdamDawes.com for his Bubble Bobble play guide and
level maps and videos.  They really helped with enemy placement and level
making. 
Finally this was tested in FCE Ultra and Nestopia and contains no real
glitches.
MontyMole 2011. BonesOnboard@googlemail.com

*If you are seriously going to replicate something like this then, don't place: 

Pul Puls on levels 49-66
Drunks on levels 68 to the mid 80's
Invaders and Mightas in the special rounds otherwise THEY WILL GLITCH.
(Yeah a skilled programmer could alter the code for this so it doesn't, but
I'm not a programmer so go figure). 