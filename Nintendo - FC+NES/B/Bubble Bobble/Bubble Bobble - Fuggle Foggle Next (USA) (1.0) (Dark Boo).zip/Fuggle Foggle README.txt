FUGGLE FOGGLE NEXT v1.0

by Dark Boo


* This is a hack of the original NES version of Bubble Bobble. All enemies, items, palettes and level layouts have been changed.

* As the story goes, Jean and Jules are magical frogs sent to the cave of monsters to defeat the evil Master Noddy and save their friends!

* All levels and level palettes were edited with Bubbled by Klone.

* Graphics and palettes were also edited using Tile Layer Pro (by SnowBro) and FCEUX (by Zeromus and Sebastian Porst).

* Use this IPS patch on an unmodified copy of Bubble Bobble (USA). 



**Fuggle Foggle Next**
**(c) 2021 Matt Bolliger, aka Dark Boo**

