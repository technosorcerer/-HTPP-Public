Hi ok so basically, you see, to play this hack you need to:     
-------------------------------------------------------------       
                                                                          
1. Get a copy of "Bubble Bobble (USA).nes"                          
                                                                      
2. Pick your rom of choice (New music, yay or nay?)                  
                                                                    
3. Apply the IPS patch to the "Bubble Bobble (USA).nes" rom           
                                                                     
4. Load up the hack, and have fun!                                 
                                                                     
-------------------------------------------------------------       
