Bubble Bobble
Traducci�n al Espa�ol v1.0 (25/05/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Bubble Bobble
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Bubble Bobble
-----------------
Adaptaci�n del cl�sico de arcade.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Bubble Bobble (U) [!].nes
163.856	bytes
CRC32: d3a91b41
MD5: e6cb4e0faf2e944b2a0c8d78a399ac7f
SHA1: 0e40052299ada46f6c2d1172323366f872f90570

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n
Gynion - Testing

-- END OF README --