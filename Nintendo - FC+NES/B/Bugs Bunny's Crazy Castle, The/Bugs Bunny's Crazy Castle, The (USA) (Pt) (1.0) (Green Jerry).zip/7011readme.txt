Informações:
------------

Nome: The Bugs Bunny Crazy Castle
Região: EUA
Plataforma: Nintendo Entertainment System (NES)
Desenvolvedora: Kemco
Distribuidora: Kemco
Gênero: Plataforma, Quebra-cabeça
Jogadores: 1
Lançamento: ??/08/1989

Descrição:
----------
Honey Bunny foi raptada por Wile E. Coyote, Eufrazino, Patolino e Frajola. Pernalonga precisa passar das 60 fases para poder resgatá-la. Para passar de cada fase, Pernalonga precisa recolher todas as 8 cenouras em cada fase.

Status da tradução:
-------------------

Geral: 100%
Textos: 100%
Acentos: 100%
Gráficos: 100%

Notas:
------

Os tijolos na tela do final não estão perfeitos, pois o tilemap usa uma compressão RLE.

Ferramentas utilizadas:
-----------------------

YY-CHR: Edição dos gráficos.
Djinn Tile Mapper: Edição das telas de títlo e do final, e dos textos.
CadEditor: Correção de erro gráfico nas portas em um dos temas das fases ao adicionar o gráfico da palavra "aperte".

Sobre a ROM:
------------

Nome: The Bugs Bunny Crazy Castle (U) [!].nes (GoodNES) / Bugs Bunny Crazy Castle, The (USA).nes (No-Intro)
CRC32 (arquivo): DB0C3656
CRC32 (ROM): E50A9130
MD5 (arquivo): 9AE4058CCED0D2514A169ECA3311E5D0
MD5 (ROM): 6BC8F54DC358AA35F6259715E5143B37
SHA-1 (arquivo): 3769F52F919019098C4DD3CE81E029A015E720DD
SHA-1 (ROM): 94B1E56B1745A84872F0F8C28B5866DAED19C337
Tamanho: 96 KB (98,320 bytes)

Instalação da tradução:
-----------------------

O patch está no formato .ips, use um programa compatível com patches .ips como o Lunar IPS (https://fusoya.eludevisibility.org/lips/) ou o Floating IPS (https://www.smwcentral.net/?p=section&a=details&id=4883) para aplicar o patch na ROM original.