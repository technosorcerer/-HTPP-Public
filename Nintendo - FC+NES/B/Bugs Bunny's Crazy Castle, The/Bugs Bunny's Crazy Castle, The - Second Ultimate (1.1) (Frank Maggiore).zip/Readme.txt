The Ultimate Second Bugs Bunny Crazy Castle, �  Frank Maggiore, 2006

Version 1.1

The Bugs Bunny Crazy Castle hack, NES

Contact:  golden_road15@hotmail.com
Site:  http://www.geocities.com/plinko50000/hacks.html