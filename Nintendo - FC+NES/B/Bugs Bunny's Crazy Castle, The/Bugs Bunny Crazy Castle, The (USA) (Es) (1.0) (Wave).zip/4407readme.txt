The Bugs Bunny Crazy Castle (NES)
Traducci�n al Espa�ol v1.0 (16/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bugs Bunny Crazy Castle, The (U) [!].nes
MD5: 9ae4058cced0d2514a169eca3311e5d0
SHA1: 3769f52f919019098c4dd3ce81e029a015e720dd
CRC32: db0c3656
98.320 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --