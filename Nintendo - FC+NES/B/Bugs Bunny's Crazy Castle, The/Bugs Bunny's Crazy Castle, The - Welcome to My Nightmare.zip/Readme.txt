Thank you for downloading Welcome to My Nightmare, the latest hack of the Bugs Bunny Crazy Castle.

There are three patches included in this package.  The Graphics Patch includes new graphics featuring Alice Cooper.  This patch may be applied to any BBCC rom or hack with the original graphics left unchanged.
The Level Patch may be applied to any BBCC rom or hack with the original unchanged levels which features 64 all new challenging levels.
The Full Game patch includes both the new levels and new graphics.