______________________________________________________________

Proveaux Hack 2013
______________________________________________________________

Apply "B2R070513" to "Bugs Bunny Crazy Castle, The (U) [!].nes" and enjoy! :D
______________________________________________________________

Changes:

-Imported tiles from "Roger Rabbit (1989)(Kemco)(J).fds"
-Shifted down and removed items from Kemco Presents screen
-Push Start screen
-Push Start screen music (Hamtaro126)
-Palettes
-Animation for characters
-Characters speed
-Added Rescue screen (MottZilla)
-Rogers hand and bow tie on Rescue screen
-The End screen
______________________________________________________________

Thanks go out to:

BouncekDeLemos for concept, manual, and labels
Hamtaro129 for Push Start music change
MottZilla for Rescue screen
______________________________________________________________

This patch is for personal use only. Not to be used for profit, sale, or trade in any form.
______________________________________________________________