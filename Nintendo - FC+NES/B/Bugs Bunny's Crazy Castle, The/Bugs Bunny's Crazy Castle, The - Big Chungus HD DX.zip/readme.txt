Big Chungus HD DX

author: Popehentai
hack of The Bugs bunny Crazy Castle (u)


shitty meme is shit. So is the hack it inspired.
Big Chungus. The game you always knew you never wanted.